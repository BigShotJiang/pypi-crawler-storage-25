"""
ExposedPoints.py
================
Identifies which surface points of a particle are exposed to a collimated
light beam and computes the angle of incidence at each exposed point.

Geometry convention
-------------------
  - The beam travels in the XZ plane, at angle `incidence` from the +Z axis.
  - Beam direction unit vector:
        d = [sin(incidence), 0, -cos(incidence)]
    i.e. incidence=0   → beam travels along -Z (straight down)
         incidence=90  → beam travels along +X
  - A point is EXPOSED if the beam hits the outer face of the surface:
        d · n_hat < 0
    (beam opposes the outward normal → light is incident on that face)
  - Angle of incidence at each exposed point (measured from the surface
    normal, standard optics convention):
        alpha = arccos( -d · n_hat )      in [0°, 90°]

Usage
-----
    from sphere import DeformedSphere
    from ExposedPoints import ExposedPoints

    # Load particle yourself, then pass points and normals directly
    particle = DeformedSphere(load='particle1.npz')

    ep = ExposedPoints(points=particle.points,
                       normals=particle.normals,
                       incidence=30.0)

    exposed_points   = ep.points    # list of [x, y, z]
    incidence_angles = ep.angles    # list of float (degrees)

    ep.info()
    ep.plot()
"""

import sys
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D    # noqa: F401


class ExposedPoints:
    """
    Find the surface points of a particle that are exposed to a collimated
    light beam and compute the angle of incidence at each exposed point.

    Parameters
    ----------
    points    : array-like (N, 3)  — Cartesian surface point coordinates,
                                     e.g. particle.points from DeformedSphere
    normals   : array-like (N, 3)  — outward unit normal vectors at each point,
                                     e.g. particle.normals from DeformedSphere
    incidence : float              — beam angle in degrees from the +Z axis;
                                     beam lies in the XZ plane
                                     0°  → beam along -Z (top illumination)
                                     45° → beam at 45° in XZ plane
                                     90° → beam along +X (side illumination)

    Attributes
    ----------
    points  : list of [x, y, z]  — Cartesian coordinates of exposed surface points
    angles  : list of float      — angle of incidence in degrees at each exposed point
                                   (measured from the outward normal, range 0°–90°)

    Methods
    -------
    info()          print summary
    plot()          3-panel visualisation of exposed points
    """

    def __init__(self, points, normals, incidence: float):

        # ── validate inputs ───────────────────────────────────────────────────
        errors = []

        pts_arr  = np.asarray(points,  dtype=float)
        nrm_arr  = np.asarray(normals, dtype=float)

        if pts_arr.ndim != 2 or pts_arr.shape[1] != 3:
            errors.append(f"'points' must be shape (N, 3), got {pts_arr.shape}.")
        if nrm_arr.ndim != 2 or nrm_arr.shape[1] != 3:
            errors.append(f"'normals' must be shape (N, 3), got {nrm_arr.shape}.")
        if pts_arr.shape != nrm_arr.shape:
            errors.append(
                f"'points' and 'normals' must have the same shape, "
                f"got {pts_arr.shape} vs {nrm_arr.shape}.")
        if not (0.0 <= incidence <= 180.0):
            errors.append(
                f"'incidence' must be in [0, 180] degrees, got {incidence}.")

        if errors:
            print("\n[ExposedPoints ERROR]")
            for e in errors:
                print(f"  • {e}")
            print()
            sys.exit(1)

        self.incidence_deg = incidence
        self.incidence_rad = np.radians(incidence)

        # store full surface arrays (numpy) for internal use
        self._all_pts   = pts_arr
        self._all_norms = nrm_arr

        # ── beam direction unit vector (travels in XZ plane) ──────────────────
        # d = [sin(incidence), 0, -cos(incidence)]
        self._beam_dir = np.array([
            np.sin(self.incidence_rad),
            0.0,
            -np.cos(self.incidence_rad)
        ])

        # ── find exposed points ───────────────────────────────────────────────
        self._compute()

    # ── core computation ──────────────────────────────────────────────────────
    def _compute(self):
        """
        For each surface point, compute d · n_hat.
        Exposed condition : d · n_hat < 0  (beam opposes outward normal).
        Angle of incidence: alpha = arccos(-d · n_hat), in degrees.
        """
        # dot product of beam direction with every normal: shape (N,)
        dot  = self._all_norms @ self._beam_dir

        # exposed mask
        mask = dot < 0.0

        # extract exposed points and their dot values
        exp_pts = self._all_pts[mask]       # (M, 3)
        exp_dot = dot[mask]                 # (M,)  all negative

        # angle of incidence: arccos(-d · n) → [0°, 90°]
        cos_alpha = np.clip(-exp_dot, 0.0, 1.0)
        alpha_deg = np.degrees(np.arccos(cos_alpha))

        # store as Python lists as required
        self.points = exp_pts.tolist()      # list of [x, y, z]
        self.angles = alpha_deg.tolist()    # list of float (degrees)

        # keep numpy arrays internally for plotting and info
        self._exp_pts   = exp_pts
        self._alpha_deg = alpha_deg
        self._mask      = mask

    # ── info ──────────────────────────────────────────────────────────────────
    def info(self):
        """Print a summary of the exposure calculation."""
        N_total   = len(self._all_pts)
        N_exposed = len(self.points)
        frac      = N_exposed / N_total * 100

        print("=" * 60)
        print("  EXPOSED POINTS SUMMARY")
        print("=" * 60)
        print(f"  Beam angle (incidence) : {self.incidence_deg}°  from +Z axis")
        print(f"  Beam direction d       : {self._beam_dir}")
        print("─" * 60)
        print(f"  Total surface pts  : {N_total:,}")
        print(f"  Exposed points     : {N_exposed:,}  ({frac:.1f}% of surface)")
        print(f"  Shadow points      : {N_total - N_exposed:,}")
        print("─" * 60)
        print(f"  Incidence angles:")
        print(f"    min  : {self._alpha_deg.min():.4f}°")
        print(f"    max  : {self._alpha_deg.max():.4f}°")
        print(f"    mean : {self._alpha_deg.mean():.4f}°")
        print("─" * 60)
        print(f"  First exposed point    : {self.points[0]}")
        print(f"  First incidence angle  : {self.angles[0]:.6f}°")
        print("=" * 60)

    # ── plot ──────────────────────────────────────────────────────────────────
    def plot(self, save_path=None, show=True, elev=25, azim=45):
        """
        3-panel figure:
          Panel 1 — 3D view: exposed points (coloured by incidence angle)
                    overlaid on shadowed points (grey)
          Panel 2 — histogram of incidence angles
          Panel 3 — XZ cross-section showing beam direction arrow
                    and exposed (coloured) vs shadow (grey) points

        Parameters
        ----------
        save_path : str   — file path to save figure (None = don't save)
        show      : bool  — call plt.show() (default True)
        elev, azim: float — 3D viewing angles
        """
        all_pts  = self._all_pts
        exp_pts  = self._exp_pts
        alpha    = self._alpha_deg
        mask     = self._mask

        # estimate r_eff from the data for axis limits
        r_eff_est = np.linalg.norm(all_pts, axis=1).mean()

        fig = plt.figure(figsize=(15, 5))
        fig.suptitle(
            f"Exposed surface points  |  "
            f"incidence θ={self.incidence_deg}°  |  "
            f"{len(self.points):,} / {len(all_pts):,} points exposed",
            fontsize=11)

        # ── Panel 1: 3D scatter ───────────────────────────────────────────────
        ax1 = fig.add_subplot(131, projection='3d')

        shadow_pts = all_pts[~mask]
        stride = max(1, len(shadow_pts) // 3000)
        ax1.scatter(shadow_pts[::stride, 0],
                    shadow_pts[::stride, 1],
                    shadow_pts[::stride, 2],
                    c='lightgrey', s=1, alpha=0.3, depthshade=True)

        stride2 = max(1, len(exp_pts) // 3000)
        sc = ax1.scatter(exp_pts[::stride2, 0],
                         exp_pts[::stride2, 1],
                         exp_pts[::stride2, 2],
                         c=alpha[::stride2], cmap='hot_r',
                         s=3, alpha=0.8, depthshade=True,
                         vmin=0, vmax=90)
        plt.colorbar(sc, ax=ax1, label='Incidence angle (°)',
                     shrink=0.6, pad=0.02)

        # beam arrow
        lim = r_eff_est * 1.5
        arrow_scale = r_eff_est * 0.8
        ax1.quiver(-self._beam_dir[0] * lim * 0.8, 0,
                   -self._beam_dir[2] * lim * 0.8,
                    self._beam_dir[0] * arrow_scale, 0,
                    self._beam_dir[2] * arrow_scale,
                    color='royalblue', linewidth=2, arrow_length_ratio=0.3)

        ax1.set_xlim(-lim, lim); ax1.set_ylim(-lim, lim); ax1.set_zlim(-lim, lim)
        ax1.set_xlabel('X (µm)', fontsize=8)
        ax1.set_ylabel('Y (µm)', fontsize=8)
        ax1.set_zlabel('Z (µm)', fontsize=8)
        ax1.set_title('3D: exposed (hot) vs shadow (grey)', fontsize=9)
        ax1.view_init(elev=elev, azim=azim)
        ax1.tick_params(labelsize=7)

        # ── Panel 2: incidence angle histogram ────────────────────────────────
        ax2 = fig.add_subplot(132)
        ax2.hist(alpha, bins=45, range=(0, 90),
                 color='darkorange', edgecolor='none', alpha=0.85)
        ax2.set_xlabel('Angle of incidence (°)', fontsize=9)
        ax2.set_ylabel('Number of surface points', fontsize=9)
        ax2.set_title('Distribution of incidence angles', fontsize=10)
        ax2.set_xlim(0, 90)
        ax2.axvline(alpha.mean(), color='red', lw=1.5, ls='--',
                    label=f'mean = {alpha.mean():.1f}°')
        ax2.legend(fontsize=8)
        ax2.tick_params(labelsize=8)
        ax2.grid(True, lw=0.4, alpha=0.4)

        # ── Panel 3: XZ cross-section ─────────────────────────────────────────
        ax3 = fig.add_subplot(133)

        y_range = all_pts[:, 1].max() - all_pts[:, 1].min()
        tol = 0.06
        mask_xz = np.abs(all_pts[:, 1]) < tol * y_range
        while mask_xz.sum() < 20 and tol < 0.4:
            tol += 0.02
            mask_xz = np.abs(all_pts[:, 1]) < tol * y_range

        shadow_xz = all_pts[mask_xz & ~mask]
        if len(shadow_xz) > 0:
            ax3.scatter(shadow_xz[:, 0], shadow_xz[:, 2],
                        c='lightgrey', s=6, alpha=0.5, label='Shadow')

        exp_xz_mask = mask_xz & mask
        if exp_xz_mask.sum() > 0:
            exp_xz_pts  = all_pts[exp_xz_mask]
            exp_xz_dot  = self._all_norms[exp_xz_mask] @ self._beam_dir
            exp_xz_alpha = np.degrees(np.arccos(np.clip(-exp_xz_dot, 0, 1)))
            sc3 = ax3.scatter(exp_xz_pts[:, 0], exp_xz_pts[:, 2],
                              c=exp_xz_alpha, cmap='hot_r', s=8,
                              alpha=0.9, vmin=0, vmax=90, label='Exposed')
            plt.colorbar(sc3, ax=ax3, label='Incidence angle (°)', pad=0.02)

        # beam arrow in XZ
        ax3.annotate('',
                     xy=(0, 0),
                     xytext=(-self._beam_dir[0] * r_eff_est * 1.3,
                             -self._beam_dir[2] * r_eff_est * 1.3),
                     arrowprops=dict(arrowstyle='->', color='royalblue', lw=2))
        ax3.text(-self._beam_dir[0] * r_eff_est * 1.45,
                 -self._beam_dir[2] * r_eff_est * 1.45,
                 f'beam\nθ={self.incidence_deg}°',
                 fontsize=8, color='royalblue', ha='center')

        ang_ref = np.linspace(0, 2 * np.pi, 300)
        ax3.plot(r_eff_est * np.cos(ang_ref), r_eff_est * np.sin(ang_ref),
                 'k--', lw=0.8, alpha=0.4, label=f'r_eff≈{r_eff_est:.1f}')

        ax3.set_aspect('equal')
        lim3 = r_eff_est * 1.7
        ax3.set_xlim(-lim3, lim3); ax3.set_ylim(-lim3, lim3)
        ax3.set_xlabel('X (µm)', fontsize=9)
        ax3.set_ylabel('Z (µm)', fontsize=9)
        ax3.set_title('XZ cross-section', fontsize=10)
        ax3.legend(fontsize=7, loc='upper right')
        ax3.tick_params(labelsize=8)
        ax3.grid(True, lw=0.4, alpha=0.4)

        plt.tight_layout()

        if save_path is not None:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            print(f"[ExposedPoints] Figure saved to '{save_path}'")
        if show:
            plt.show()
        return fig
