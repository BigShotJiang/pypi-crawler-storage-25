"""goscat package

Expose the main particle-shape and scattering classes through a single
package namespace so the code can be imported as:
    import goscat as gs

Then use:
    gs.DeformedSphere
    gs.ExposedPoints
    gs.ScatCalc

Also expose lower-level helper functions from the sphere module.
"""

__version__ = "1.0.1"

from .sphere import (
    DeformedSphere,
    compute_normals,
    generate_random_particle,
    particle_metrics,
)
from .ExposedPoints import ExposedPoints
from .scattCalc import ScatCalc

__all__ = [
    "DeformedSphere",
    "ExposedPoints",
    "ScatCalc",
    "compute_normals",
    "generate_random_particle",
    "particle_metrics",
]
