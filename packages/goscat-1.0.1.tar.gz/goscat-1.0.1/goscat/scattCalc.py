"""
scattCalcV2.py
==============
Improved geometric-optics scattering calculator.

This version corrects the Fresnel transmittance calculation for absorbing media
and adds a direct efficiency calculator for Q_sca, Q_abs, Q_ext and related
quantities from the scattered intensity output.

The ray-tracing approach is still based on sampled surface points, so the hit
finding remains approximate for a point-cloud/mesh representation.
"""

import sys
import numpy as np
import matplotlib.pyplot as plt


# ──────────────────────────────────────────────────────────────────────────────
#  HELPER FUNCTIONS
# ──────────────────────────────────────────────────────────────────────────────

def _unit(v):
    m = np.linalg.norm(v)
    return v / m if m > 1e-14 else np.zeros_like(v)


def _cart_to_spherical(d):
    d = _unit(d)
    theta = np.degrees(np.arccos(np.clip(d[2], -1.0, 1.0)))
    phi = np.degrees(np.arctan2(d[1], d[0])) % 360.0
    return theta, phi


def _fresnel(cos_i, n1, n2_complex):
    cos_i = np.clip(abs(cos_i), 0.0, 1.0)
    sin_i = np.sqrt(max(0.0, 1.0 - cos_i**2))

    sin_t = (n1 / n2_complex) * sin_i
    cos_t = np.sqrt(1.0 - sin_t**2 + 0j)

    rs = (n1 * cos_i - n2_complex * cos_t) / (n1 * cos_i + n2_complex * cos_t)
    rp = (n2_complex * cos_i - n1 * cos_t) / (n2_complex * cos_i + n1 * cos_t)

    Rs = abs(rs)**2
    Rp = abs(rp)**2

    ts = 2.0 * n1 * cos_i / (n1 * cos_i + n2_complex * cos_t)
    tp = 2.0 * n1 * cos_i / (n2_complex * cos_i + n1 * cos_t)

    denom = n1 * cos_i
    Re_n2_cos_t = (n2_complex * cos_t).real
    if denom > 1e-14 and Re_n2_cos_t > 0.0:
        Ts = (Re_n2_cos_t / denom) * abs(ts)**2
        Tp = (Re_n2_cos_t / denom) * abs(tp)**2
    else:
        Ts = 0.0
        Tp = 0.0

    return Rs, Rp, max(Ts, 0.0), max(Tp, 0.0), cos_t


def _refract_direction(d_in, n_hat, n1, n2_complex):
    n2r = n2_complex.real
    eta = n1 / n2r

    if np.dot(d_in, n_hat) > 0:
        n_hat = -n_hat

    cos_i = -np.dot(d_in, n_hat)
    sin2_t = eta**2 * max(0.0, 1.0 - cos_i**2)

    if sin2_t > 1.0:
        return np.zeros(3), False

    cos_t = np.sqrt(1.0 - sin2_t)
    d_out = eta * d_in + (eta * cos_i - cos_t) * n_hat
    return _unit(d_out), True


def _reflect_direction(d_in, n_hat):
    if np.dot(d_in, n_hat) > 0:
        n_hat = -n_hat
    cos_i = -np.dot(d_in, n_hat)
    return _unit(d_in + 2.0 * cos_i * n_hat)


def _beer_lambert(I, k, wavelength_um, path_length_um):
    if k <= 0.0:
        return I
    alpha = 4.0 * np.pi * k / wavelength_um
    return I * np.exp(-alpha * path_length_um)


def _find_next_hit(current_idx, ray_dir, all_pts, all_norms):
    origin = all_pts[current_idx]
    diffs = all_pts - origin
    fwd = diffs @ ray_dir
    perp2 = np.sum(diffs**2, axis=1) - fwd**2
    perp2 = np.maximum(perp2, 0.0)
    dot_n = all_norms @ ray_dir

    valid = (fwd > 1e-6) & (dot_n > 0.1)
    valid[current_idx] = False

    if not np.any(valid):
        return current_idx, 0.0

    perp2_valid = np.where(valid, perp2, np.inf)
    idx = int(np.argmin(perp2_valid))
    path_len = float(np.linalg.norm(all_pts[idx] - origin))
    return idx, path_len


def _bin_direction(theta, phi, d_theta, d_phi):
    tb = (np.floor(theta / d_theta) + 0.5) * d_theta
    pb = (np.floor(phi / d_phi) + 0.5) * d_phi
    return round(tb, 6), round(pb, 6)


class ScatCalc:
    """
    Geometric optics scattering calculator with corrected Fresnel transmittance.

    Attributes
    ----------
    Iscatt : list of [theta_bin, phi_bin, I_s, I_p, I_total]
    Q_sca, Q_abs, Q_ext : scattering efficiencies
    C_geo, C_inc, C_refl, C_sca, C_abs, C_ext : cross-sections
    albedo : single-scattering albedo
    """

    def __init__(self,
                 points,
                 normals,
                 exp_points,
                 incidence,
                 n=1.5,
                 k=0.0,
                 wavelength=0.535,
                 beam_theta=30.0,
                 d_theta=1.0,
                 d_phi=1.0,
                 I_cutoff=None,
                 point_weights=None):

        self._all_pts = np.asarray(points, dtype=float)
        self._all_norms = np.asarray(normals, dtype=float)
        self._exp_pts = np.asarray(exp_points, dtype=float)
        self._inc_ang = np.asarray(incidence, dtype=float)

        if self._all_pts.ndim != 2 or self._all_pts.shape[1] != 3:
            raise ValueError("'points' must be shape (N, 3).")
        if self._all_norms.shape != self._all_pts.shape:
            raise ValueError("'normals' must have the same shape as 'points'.")
        if self._exp_pts.ndim != 2 or self._exp_pts.shape[1] != 3:
            raise ValueError("'exp_points' must be shape (M, 3).")
        if len(self._inc_ang) != len(self._exp_pts):
            raise ValueError("'incidence' length must match 'exp_points' length.")
        if n <= 0:
            raise ValueError("'n' must be > 0.")
        if k < 0:
            raise ValueError("'k' must be >= 0.")
        if point_weights is not None:
            weights = np.asarray(point_weights, dtype=float)
            if weights.ndim != 1 or weights.shape[0] != self._all_pts.shape[0]:
                raise ValueError("'point_weights' must be shape (N,) matching points.")
            self._point_weights = weights
        else:
            self._point_weights = None

        self.n = n
        self.k = k
        self.m = complex(n, k)
        self.wavelength = wavelength
        self.beam_theta = beam_theta
        self.d_theta = d_theta
        self.d_phi = d_phi
        self.I_cutoff = I_cutoff if I_cutoff is not None else 1.0 / np.e
        self._cos_inc = np.cos(np.radians(self._inc_ang))

        bt = np.radians(self.beam_theta)
        self._beam_dir = np.array([np.sin(bt), 0.0, -np.cos(bt)])

        self._bins = {}
        self._exp_indices = np.array([self._closest_idx(p) for p in self._exp_pts],
                                     dtype=int)
        self._exit_fractions = np.zeros(len(self._exp_pts), dtype=float)
        self._trace_all()

        self.Iscatt = []
        for (tb, pb), (Is, Ip) in sorted(self._bins.items()):
            self.Iscatt.append([tb, pb, Is, Ip, Is + Ip])

        self.Q_sca = None
        self.Q_abs = None
        self.Q_ext = None
        self.C_geo = None
        self.C_inc = None
        self.C_refl = None
        self.C_sca = None
        self.C_abs = None
        self.C_ext = None
        self.albedo = None
        self.Q_sca_diff = None
        self.Q_ext_diff = None
        self.albedo_diff = None

    def _closest_idx(self, pos):
        dists = np.linalg.norm(self._all_pts - pos, axis=1)
        return int(np.argmin(dists))

    def _accumulate(self, ray_dir, I_s, I_p):
        theta, phi = _cart_to_spherical(ray_dir)
        tb, pb = _bin_direction(theta, phi, self.d_theta, self.d_phi)
        if (tb, pb) not in self._bins:
            self._bins[(tb, pb)] = [0.0, 0.0]
        self._bins[(tb, pb)][0] += I_s
        self._bins[(tb, pb)][1] += I_p

    def _trace_all(self):
        N_exp = len(self._exp_pts)
        print(f"[ScatCalc] Tracing {N_exp:,} exposed points ...")
        for i in range(N_exp):
            self._trace_one(i)
            if (i + 1) % max(1, N_exp // 10) == 0:
                print(f"  {i+1:,} / {N_exp:,} done  ({(i+1)/N_exp*100:.0f}%)")
        print(f"[ScatCalc] Done. {len(self._bins):,} non-empty direction bins.")

    def _trace_one(self, exp_idx):
        pos = self._exp_pts[exp_idx]
        inc = self._inc_ang[exp_idx]

        surf_idx = self._closest_idx(pos)
        n_hat = _unit(self._all_norms[surf_idx])

        cos_i = np.cos(np.radians(inc))
        Rs, Rp, Ts, Tp, cos_t = _fresnel(cos_i, 1.0, self.m)

        I_s = 0.5 * Ts
        I_p = 0.5 * Tp
        if I_s + I_p < 1e-12:
            return

        d_refr, valid = _refract_direction(self._beam_dir, -n_hat, 1.0, self.m)
        if not valid:
            return

        current_idx = surf_idx
        ray_dir = d_refr
        max_bounces = 50

        exit_total = 0.0

        # Front-surface reflection is also part of the scattered field.
        # The reflected energy does not enter the particle.
        I_s_ref = 0.5 * Rs
        I_p_ref = 0.5 * Rp
        if I_s_ref + I_p_ref > 1e-14:
            d_refl = _reflect_direction(self._beam_dir, n_hat)
            self._accumulate(d_refl, I_s_ref, I_p_ref)
            exit_total += I_s_ref + I_p_ref

        for bounce in range(max_bounces):
            if I_s <= self.I_cutoff * 0.5 and I_p <= self.I_cutoff * 0.5:
                break

            next_idx, path_len = _find_next_hit(current_idx, ray_dir,
                                                self._all_pts, self._all_norms)
            if next_idx == current_idx or path_len < 1e-9:
                break

            I_s = _beer_lambert(I_s, self.k, self.wavelength, path_len)
            I_p = _beer_lambert(I_p, self.k, self.wavelength, path_len)

            n_hit = _unit(self._all_norms[next_idx])
            cos_i_int = np.clip(np.dot(ray_dir, n_hit), 0.0, 1.0)

            Rs_int, Rp_int, Ts_int, Tp_int, _ = _fresnel(cos_i_int,
                                                     self.n,
                                                     complex(1.0, 0.0))

            d_exit, valid_exit = _refract_direction(ray_dir, -n_hit,
                                                    self.n,
                                                    complex(1.0, 0.0))
            if valid_exit:
                I_s_exit = I_s * Ts_int
                I_p_exit = I_p * Tp_int
                if I_s_exit + I_p_exit > 1e-14:
                    self._accumulate(d_exit, I_s_exit, I_p_exit)
                    exit_total += I_s_exit + I_p_exit

            I_s *= Rs_int
            I_p *= Rp_int
            if I_s <= self.I_cutoff * 0.5 and I_p <= self.I_cutoff * 0.5:
                break

            ray_dir = _reflect_direction(ray_dir, -n_hit)
            current_idx = next_idx

        self._exit_fractions[exp_idx] = exit_total

    def compute_efficiencies(self, r_eff, point_weights=None, surface_area=None):
        r_eff = float(r_eff)
        self.C_geo = np.pi * r_eff**2

        if self.C_geo <= 0.0:
            raise ValueError("r_eff must be positive.")

        n_particle = complex(self.n, self.k)
        N_total = len(self._all_pts)

        weights = None
        if point_weights is not None:
            weights = np.asarray(point_weights, dtype=float)
            if weights.ndim != 1 or weights.shape[0] != N_total:
                raise ValueError("'point_weights' must be shape (N,) matching points.")
        elif self._point_weights is not None:
            weights = self._point_weights
        else:
            weights = self._estimate_spherical_point_weights()

        if weights is None:
            if surface_area is not None:
                weights = np.full(N_total, float(surface_area) / N_total)
            else:
                mean_r = np.mean(np.linalg.norm(self._all_pts, axis=1))
                weights = np.full(N_total, 4.0 * np.pi * mean_r**2 / N_total)

        exp_weights = weights[self._exp_indices]

        C_inc = np.sum(self._cos_inc * exp_weights)
        C_refl = 0.0
        for cos_i, w in zip(self._cos_inc, exp_weights):
            Rs, Rp, Ts, Tp, _ = _fresnel(cos_i, 1.0, n_particle)
            R_unpol = 0.5 * (Rs + Rp)
            C_refl += R_unpol * cos_i * w

        self.C_inc = C_inc
        self.C_refl = C_refl
        self.C_sca = np.sum(self._exit_fractions * self._cos_inc * exp_weights)
        self.C_abs = max(self.C_inc - self.C_refl - self.C_sca, 0.0)
        self.C_ext = self.C_sca + self.C_abs

        self.Q_sca = self.C_sca / self.C_geo
        self.Q_abs = self.C_abs / self.C_geo
        self.Q_ext = self.C_ext / self.C_geo
        self.albedo = (self.Q_sca / self.Q_ext) if self.Q_ext > 0 else 0.0

        self.Q_sca_diff = self.Q_sca + 1.0
        self.Q_ext_diff = self.Q_ext + 1.0
        self.albedo_diff = (self.Q_sca_diff / self.Q_ext_diff) if self.Q_ext_diff > 0 else 0.0

        return {
            'C_geo': self.C_geo,
            'C_inc': self.C_inc,
            'C_refl': self.C_refl,
            'C_sca': self.C_sca,
            'C_abs': self.C_abs,
            'C_ext': self.C_ext,
            'Q_sca': self.Q_sca,
            'Q_abs': self.Q_abs,
            'Q_ext': self.Q_ext,
            'albedo': self.albedo,
            'Q_sca_diff': self.Q_sca_diff,
            'Q_ext_diff': self.Q_ext_diff,
            'albedo_diff': self.albedo_diff,
        }

    def _estimate_spherical_point_weights(self):
        """Estimate equal-area weights for a spherical grid of points."""
        N_total = len(self._all_pts)
        if N_total == 0:
            return None

        radii = np.linalg.norm(self._all_pts, axis=1)
        r_mean = np.mean(radii)
        if r_mean <= 0.0:
            return None

        if np.max(np.abs(radii - r_mean)) / r_mean > 1e-4:
            return None

        theta = np.arccos(np.clip(self._all_pts[:, 2] / r_mean, -1.0, 1.0))
        phi = np.mod(np.arctan2(self._all_pts[:, 1], self._all_pts[:, 0]), 2.0 * np.pi)

        theta_u = np.unique(np.round(theta, 8))
        phi_u = np.unique(np.round(phi, 8))
        if theta_u.size * phi_u.size != N_total:
            return None

        if theta_u.size > 1:
            dtheta = np.median(np.diff(theta_u))
        else:
            dtheta = 2.0 * np.pi
        if phi_u.size > 1:
            dphi = np.median(np.diff(phi_u))
        else:
            dphi = 2.0 * np.pi

        if dtheta <= 0.0 or dphi <= 0.0:
            return None

        weights = (r_mean**2) * np.sin(theta) * dtheta * dphi
        return weights

    def info(self):
        if not self.Iscatt:
            print("[ScatCalc] No scattering data computed yet.")
            return

        I_tot = np.array([row[4] for row in self.Iscatt])
        I_s = np.array([row[2] for row in self.Iscatt])
        I_p = np.array([row[3] for row in self.Iscatt])

        print("=" * 60)
        print("  SCATTERING CALCULATION SUMMARY")
        print("=" * 60)
        print(f"  Refractive index (n, k) : ({self.n}, {self.k})")
        print(f"  Wavelength              : {self.wavelength} µm")
        print(f"  Beam angle theta        : {self.beam_theta}°")
        print(f"  Exposed points traced   : {len(self._exp_pts):,}")
        print(f"  Intensity cutoff (1/e)  : {self.I_cutoff:.6f}")
        print(f"  Bin size (dθ × dφ)     : {self.d_theta}° × {self.d_phi}°")
        print("─" * 60)
        print(f"  Non-empty direction bins: {len(self.Iscatt):,}")
        print(f"  Total scattered I_s     : {I_s.sum():.6f}")
        print(f"  Total scattered I_p     : {I_p.sum():.6f}")
        print(f"  Total scattered I_total : {I_tot.sum():.6f}")
        print(f"  Peak I_total            : {I_tot.max():.6f}  "
              f"at (θ={self.Iscatt[int(np.argmax(I_tot))][0]:.1f}°, "
              f"φ={self.Iscatt[int(np.argmax(I_tot))][1]:.1f}°)")
        print("=" * 60)
        if self.Q_ext is not None:
            print("Quantities without diffraction effect:")
            print(f"  Q_sca = {self.Q_sca:.6f}")
            print(f"  Q_abs = {self.Q_abs:.6f}")
            print(f"  Q_ext = {self.Q_ext:.6f}")
            print(f"  albedo = {self.albedo:.6f}")
            if self.Q_ext_diff is not None:
                print("─" * 60)
                print("Quantities with diffraction correction:")
                print(f"  Q_sca_diff = {self.Q_sca_diff:.6f}")
                print(f"  Q_ext_diff = {self.Q_ext_diff:.6f}")
                print(f"  albedo_diff = {self.albedo_diff:.6f}")
            print("=" * 60)

    def plot(self, save_path=None, show=True):
        if not self.Iscatt:
            print("[ScatCalc] Nothing to plot.")
            return

        data = np.array([[r[0], r[1], r[2], r[3], r[4]]
                         for r in self.Iscatt])
        thetas = data[:, 0]
        phis = data[:, 1]
        I_s = data[:, 2]
        I_p = data[:, 3]
        I_tot = data[:, 4]

        fig = plt.figure(figsize=(15, 5))
        fig.suptitle(
            f"Scattering pattern  |  n={self.n}  k={self.k}  "
            f"λ={self.wavelength}µm  θ_beam={self.beam_theta}°",
            fontsize=11)

        ax1 = fig.add_subplot(131, polar=True)
        theta_bins = np.unique(thetas)
        I_phi_int = np.array([I_tot[thetas == tb].sum()
                               for tb in theta_bins])
        if I_phi_int.max() > 0:
            I_phi_int /= I_phi_int.max()

        ax1.plot(np.radians(theta_bins), I_phi_int,
                 lw=1.5, color='darkorange')
        ax1.fill(np.radians(theta_bins), I_phi_int,
                 alpha=0.25, color='darkorange')
        ax1.set_title('Scattered intensity\n(φ-integrated, normalised)',
                      fontsize=9)
        ax1.tick_params(labelsize=7)

        ax2 = fig.add_subplot(132)
        sc = ax2.scatter(phis, thetas, c=np.log10(I_tot + 1e-12),
                         cmap='hot', s=8, alpha=0.8)
        plt.colorbar(sc, ax=ax2, label='log₁₀(I_total)')
        ax2.set_xlabel('φ (°)', fontsize=9)
        ax2.set_ylabel('θ (°)', fontsize=9)
        ax2.set_xlim(0, 360)
        ax2.set_ylim(0, 180)
        ax2.set_title('Scattering map  (θ vs φ)', fontsize=10)
        ax2.tick_params(labelsize=8)
        ax2.grid(True, lw=0.3, alpha=0.4)

        ax3 = fig.add_subplot(133)
        Is_int = np.array([I_s[thetas == tb].sum() for tb in theta_bins])
        Ip_int = np.array([I_p[thetas == tb].sum() for tb in theta_bins])

        ax3.plot(theta_bins, Is_int, lw=1.5, color='steelblue', label='I_s')
        ax3.plot(theta_bins, Ip_int, lw=1.5, color='darkorange', label='I_p')
        ax3.plot(theta_bins, Is_int + Ip_int, lw=1.5,
                 color='black', ls='--', label='I_total')
        ax3.set_xlabel('θ (°)', fontsize=9)
        ax3.set_ylabel('Intensity (φ-integrated)', fontsize=9)
        ax3.set_title('I_s and I_p vs scattering angle', fontsize=10)
        ax3.legend(fontsize=8)
        ax3.set_yscale('log')
        ax3.tick_params(labelsize=8)
        ax3.grid(True, lw=0.4, alpha=0.4)

        plt.tight_layout()
        if save_path is not None:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            print(f"[ScatCalc] Figure saved to '{save_path}'")
        if show:
            plt.show()
        return fig
