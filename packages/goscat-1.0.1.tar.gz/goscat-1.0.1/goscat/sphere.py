"""
sphere_shape.py
===============
Wraps the original sphere-only particle generator (shape.py v0) inside a
clean class interface so it can be used as a module in a main code.

THE CORE ALGORITHM IS COMPLETELY UNCHANGED — every line of
generate_random_particle() and compute_normals() is identical to shape.py v0.

New features added as class methods (none touch the core):
  shape = DeformedSphere(r_eff, L_max, sigma, spectral_decay, N_theta, N_phi, seed)
  shape = DeformedSphere(load='filename.npz')

  shape.points       →  (N_theta*N_phi, 3)  flat Cartesian surface points
  shape.normals      →  (N_theta*N_phi, 3)  flat outward unit normals
  shape.r            →  (N_theta, N_phi)    radius grid  (spherical coords)
  shape.theta        →  (N_theta,)          polar angle grid
  shape.phi          →  (N_phi,)            azimuthal angle grid
  shape.X, .Y, .Z    →  (N_theta, N_phi)    Cartesian mesh grids

  shape.info()           print summary metrics
  shape.plot(...)        3-panel figure (identical style to shape.py v0)
  shape.save('f.npz')    save to NumPy binary file
  shape.load('f.npz')    load from file  (also usable in constructor)
"""

import sys
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D          # noqa: F401

try:
    from scipy.special import sph_harm
except ImportError:
    from scipy.special import sph_harm_y as _shy
    def sph_harm(m, l, phi, theta):               # noqa: E302
        return _shy(l, m, theta, phi)


# ══════════════════════════════════════════════════════════════════════════════
#  CORE FUNCTIONS  —  IDENTICAL TO shape.py v0, NOT MODIFIED
# ══════════════════════════════════════════════════════════════════════════════

def generate_random_particle(r_eff, L_max=6, sigma=0.15, spectral_decay=2.0,
                              N_theta=120, N_phi=240, seed=None):
    """
    Generate a random irregular particle surface r(theta, phi) using
    spherical harmonic perturbations, then rescale to enforce volume = (4/3)pi*r_eff^3.

    Parameters
    ----------
    r_eff        : float  - Volume-equivalent effective radius (any unit, e.g. microns)
    L_max        : int    - Maximum spherical harmonic degree (roughness control)
                           Low (2-3) = gently deformed blob
                           High (6-8) = complex, multi-scale bumps
    sigma        : float  - Overall deformation amplitude (fraction of r_eff)
                           0.05-0.10 = nearly spherical
                           0.15-0.25 = moderately irregular
                           0.30-0.40 = strongly irregular
    spectral_decay: float - How fast higher-l modes are suppressed (larger = smoother)
                           1.0 = weak suppression (rough)
                           2.0 = moderate suppression (natural)
                           3.0 = strong suppression (smooth)
    N_theta      : int    - Polar angle grid points
    N_phi        : int    - Azimuthal angle grid points
    seed         : int    - Random seed (None = different shape every run)

    Returns
    -------
    theta  : (N_theta,)           polar angles [0, pi]
    phi    : (N_phi,)             azimuthal angles [0, 2*pi]
    r      : (N_theta, N_phi)     particle radius at each (theta, phi)
    V_eff  : float                target volume
    V_actual: float               volume after rescaling (should equal V_eff)
    normals : (N_theta, N_phi, 3) outward unit normal vectors at each surface point
    """
    rng = np.random.default_rng(seed)

    # Target volume
    V_eff = (4.0 / 3.0) * np.pi * r_eff**3

    # Angular grids
    theta = np.linspace(1e-6, np.pi - 1e-6, N_theta)   # avoid poles
    phi   = np.linspace(0,    2 * np.pi,    N_phi, endpoint=False)
    TH, PH = np.meshgrid(theta, phi, indexing='ij')     # shape: (N_theta, N_phi)

    # ── Build perturbation field ──────────────────────────────────────────────
    perturbation = np.zeros((N_theta, N_phi))

    for l in range(2, L_max + 1):                       # skip l=0 (volume), l=1 (centroid)
        # Amplitude decreases with degree: a_l ~ sigma / l^(spectral_decay/2)
        amp = sigma / (l ** (spectral_decay / 2.0))

        for m in range(-l, l + 1):
            # Draw complex coefficient from N(0, amp^2)
            a_lm_re = rng.normal(0, amp)
            a_lm_im = rng.normal(0, amp) if m != 0 else 0.0

            # scipy sph_harm(m, l, phi, theta) returns complex Y_l^m
            Y = sph_harm(abs(m), l, PH, TH)            # complex spherical harmonic

            # Convert to real spherical harmonics
            if m > 0:
                Y_real = np.sqrt(2) * (-1)**m * np.real(Y)
            elif m < 0:
                Y_real = np.sqrt(2) * (-1)**m * np.imag(Y)
            else:
                Y_real = np.real(Y)

            perturbation += a_lm_re * Y_real

    # ── Build raw surface ─────────────────────────────────────────────────────
    r_raw = r_eff * (1.0 + perturbation)

    # Ensure no negative radii (very rare, but guard against it)
    r_raw = np.clip(r_raw, 0.05 * r_eff, None)

    # ── Volume rescaling ──────────────────────────────────────────────────────
    # V = (1/3) ∫∫ r(θ,φ)^3 sinθ dθ dφ
    dtheta = theta[1] - theta[0]
    dphi   = phi[1]   - phi[0]
    sin_th = np.sin(TH)

    integrand = (r_raw**3) * sin_th
    V_raw     = (1.0 / 3.0) * np.sum(integrand) * dtheta * dphi

    scale  = (V_eff / V_raw) ** (1.0 / 3.0)
    r      = r_raw * scale                              # volume-corrected surface

    # Verify
    V_actual = (1.0 / 3.0) * np.sum((r**3) * sin_th) * dtheta * dphi

    # ── Surface normals ───────────────────────────────────────────────────────
    normals = compute_normals(r, theta, phi, TH, PH)

    return theta, phi, r, V_eff, V_actual, normals


def compute_normals(r, theta, phi, TH, PH):
    """
    Compute outward unit normal vectors at each surface point.

    For a surface r(θ,φ) in spherical coords, the normal is:
        n = r_hat - (1/r)(dr/dθ) θ_hat - (1/(r sinθ))(dr/dφ) φ_hat
    then normalised.

    Returns: normals array of shape (N_theta, N_phi, 3)  [Cartesian x,y,z]

    Note on boundary conditions
    ---------------------------
    theta is NOT periodic (runs 0→pi), so np.gradient with its default
    clamped (one-sided) edges is correct along axis=0.

    phi IS periodic (runs 0→2pi with endpoint=False), so we must use
    periodic central differences at the wrap boundary (phi=0 / phi=2pi).
    np.gradient does NOT know about this periodicity and applies clamped
    one-sided differences at phi[0] and phi[-1], producing wrong normals
    at those two columns. We replace dr_dphi with a manually computed
    periodic central-difference array to fix this.
    """
    dtheta = theta[1] - theta[0]
    dphi   = phi[1]   - phi[0]

    # Theta derivative — clamped BCs are correct (theta is not periodic)
    dr_dtheta = np.gradient(r, dtheta, axis=0)

    # Phi derivative — MUST use periodic BCs because phi is 2pi-periodic.
    # Central difference: dr/dphi[i] = (r[:,i+1] - r[:,i-1]) / (2*dphi)
    # At boundaries: i=-1 wraps to i=0, and i=N wraps to i=1.
    dr_dphi = (np.roll(r, -1, axis=1) - np.roll(r, 1, axis=1)) / (2.0 * dphi)

    sin_th = np.sin(TH)
    cos_th = np.cos(TH)
    sin_ph = np.sin(PH)
    cos_ph = np.cos(PH)

    # Cartesian components of each basis vector
    # r_hat = (sinθcosφ, sinθsinφ, cosθ)
    # θ_hat = (cosθcosφ, cosθsinφ, -sinθ)
    # φ_hat = (-sinφ,    cosφ,       0  )

    nx = (r * sin_th * cos_ph
          - dr_dtheta * cos_th * cos_ph
          + dr_dphi   * sin_ph / np.where(sin_th == 0, 1e-12, sin_th))

    ny = (r * sin_th * sin_ph
          - dr_dtheta * cos_th * sin_ph
          - dr_dphi   * cos_ph / np.where(sin_th == 0, 1e-12, sin_th))

    nz = (r * cos_th
          + dr_dtheta * sin_th)

    # Normalise
    mag = np.sqrt(nx**2 + ny**2 + nz**2)
    mag = np.where(mag == 0, 1e-12, mag)

    normals = np.stack([nx / mag, ny / mag, nz / mag], axis=-1)
    return normals


def particle_metrics(r, theta, phi, r_eff):
    """
    Compute basic shape metrics for the generated particle.
    """
    TH, _ = np.meshgrid(theta, phi, indexing='ij')
    sin_th  = np.sin(TH)
    dtheta  = theta[1] - theta[0]
    dphi    = phi[1]   - phi[0]

    # Volume
    V = (1.0/3.0) * np.sum((r**3) * sin_th) * dtheta * dphi

    # Surface area (numerical)
    dr_dtheta = np.gradient(r, dtheta, axis=0)
    dr_dphi   = np.gradient(r, dphi,   axis=1)
    dS = np.sqrt(r**4 * sin_th**2
                 + r**2 * dr_dtheta**2 * sin_th**2
                 + r**2 * dr_dphi**2)
    A = np.sum(dS) * dtheta * dphi

    r_equiv       = (3*V / (4*np.pi))**(1/3)
    r_min, r_max  = r.min(), r.max()
    asphericity   = (r_max - r_min) / r_eff   # 0 = perfect sphere

    return dict(volume=V, surface_area=A,
                r_equiv=r_equiv, r_min=r_min, r_max=r_max,
                asphericity=asphericity)


# ══════════════════════════════════════════════════════════════════════════════
#  CLASS WRAPPER  —  only adds the module interface, no algorithm changes
# ══════════════════════════════════════════════════════════════════════════════

class DeformedSphere:
    """
    Randomly perturbed irregular sphere particle.

    Calls the original generate_random_particle() core unchanged.
    Adds a clean module interface on top.

    Constructor
    -----------
    # Generate a new shape:
    shape = DeformedSphere(r_eff=10.0, L_max=6, sigma=0.20,
                        spectral_decay=2.0, N_theta=120, N_phi=240, seed=None)

    # Load a previously saved shape:
    shape = DeformedSphere(load='filename.npz')

    Properties (read-only)
    ----------------------
    shape.r            (N_theta, N_phi)     radius grid in spherical coords
    shape.theta        (N_theta,)           polar angle grid  [0, pi]
    shape.phi          (N_phi,)             azimuthal angle grid  [0, 2pi]
    shape.normals      (N_theta, N_phi, 3)  outward unit normals — 2-D grid form
    shape.points       (N_theta*N_phi, 3)   flat Cartesian surface points
    shape.norm         (N_theta*N_phi, 3)   flat normals  (alias for ray-tracer)
    shape.X, .Y, .Z    (N_theta, N_phi)     Cartesian mesh grids
    shape.V_eff        float                target volume
    shape.V_actual     float                actual volume after rescaling

    Methods
    -------
    shape.info()                     print full summary
    shape.plot(save_path, show,
               elev, azim)           3-panel figure — identical to shape.py v0
    shape.save('filename.npz')       save to NumPy binary
    shape.load('filename.npz')       load from NumPy binary  (also in constructor)
    """

    # ── constructor ──────────────────────────────────────────────────────────
    def __init__(self, r_eff=None, L_max=6, sigma=0.15, spectral_decay=2.0,
                 N_theta=120, N_phi=240, seed=None, load=None):

        if load is not None:
            self.load(load)
            return

        # validate
        if r_eff is None:
            print("\n[DeformedSphere ERROR]\n  • 'r_eff' must be specified.\n")
            sys.exit(1)
        if r_eff <= 0:
            print(f"\n[DeformedSphere ERROR]\n  • 'r_eff' must be > 0, got {r_eff}.\n")
            sys.exit(1)

        # store parameters
        self.r_eff          = r_eff
        self.L_max          = L_max
        self.sigma          = sigma
        self.spectral_decay = spectral_decay
        self.N_theta        = N_theta
        self.N_phi          = N_phi
        self.seed           = seed

        # ── call the original core — completely unchanged ─────────────────────
        (self._theta, self._phi,
         self._r,
         self._V_eff, self._V_actual,
         self._normals_grid) = generate_random_particle(
            r_eff          = r_eff,
            L_max          = L_max,
            sigma          = sigma,
            spectral_decay = spectral_decay,
            N_theta        = N_theta,
            N_phi          = N_phi,
            seed           = seed,
        )

        # pre-compute Cartesian mesh and flat arrays
        self._compute_cartesian()

    # ── internal: build Cartesian grids and flat arrays ───────────────────────
    def _compute_cartesian(self):
        """Build X/Y/Z mesh and flat points/normals from the spherical r-grid."""
        TH, PH = np.meshgrid(self._theta, self._phi, indexing='ij')
        self._X = self._r * np.sin(TH) * np.cos(PH)
        self._Y = self._r * np.sin(TH) * np.sin(PH)
        self._Z = self._r * np.cos(TH)
        # flat (N,3) arrays for ray-tracing
        self._points = np.stack(
            [self._X.ravel(), self._Y.ravel(), self._Z.ravel()], axis=-1)
        self._normals_flat = self._normals_grid.reshape(-1, 3)

    # ── properties ───────────────────────────────────────────────────────────

    @property
    def r(self):
        """(N_theta, N_phi) radius grid in spherical coordinates."""
        return self._r

    @property
    def theta(self):
        """(N_theta,) polar angle grid [0, pi] in radians."""
        return self._theta

    @property
    def phi(self):
        """(N_phi,) azimuthal angle grid [0, 2*pi] in radians."""
        return self._phi

    @property
    def X(self):
        """(N_theta, N_phi) Cartesian X mesh."""
        return self._X

    @property
    def Y(self):
        """(N_theta, N_phi) Cartesian Y mesh."""
        return self._Y

    @property
    def Z(self):
        """(N_theta, N_phi) Cartesian Z mesh."""
        return self._Z

    @property
    def normals(self):
        """
        (N_theta*N_phi, 3) flat array of outward unit normal vectors.
        normals[i] = [nx, ny, nz] at surface point points[i].
        sqrt(nx^2 + ny^2 + nz^2) = 1.0 for every row.
        Same shape as points — identical indexing, use for ray-tracing.
        """
        return self._normals_flat

    @property
    def normals_grid(self):
        """
        (N_theta, N_phi, 3) outward unit normals on the 2-D spherical grid.
        normals_grid[i, j] = normal at theta[i], phi[j].
        Use only when you need the structured grid form.
        """
        return self._normals_grid

    @property
    def norm(self):
        """Alias for normals — (N_theta*N_phi, 3) flat unit normals."""
        return self._normals_flat

    @property
    def points(self):
        """
        (N_theta*N_phi, 3) flat array of Cartesian surface point coordinates.
        points[i] = [x, y, z] of surface point i.
        Same shape as normals — identical indexing, use for ray-tracing.
        """
        return self._points

    @property
    def V_eff(self):
        """Target volume = (4/3) pi r_eff^3."""
        return self._V_eff

    @property
    def V_actual(self):
        """Actual volume after spherical-harmonic perturbation + volume rescaling."""
        return self._V_actual

    # ── info ─────────────────────────────────────────────────────────────────
    def info(self):
        """Print a full summary of the particle shape and metrics."""
        m = particle_metrics(self._r, self._theta, self._phi, self.r_eff)
        print("=" * 60)
        print("  SPHERE SHAPE SUMMARY")
        print("=" * 60)
        print(f"  r_eff            = {self.r_eff}")
        print(f"  L_max            = {self.L_max}")
        print(f"  sigma            = {self.sigma}")
        print(f"  spectral_decay   = {self.spectral_decay}")
        print(f"  N_theta × N_phi  = {self.N_theta} × {self.N_phi}"
              f"  ({self.N_theta * self.N_phi:,} surface points)")
        print(f"  seed             = {self.seed}")
        print("─" * 60)
        print(f"  Volume (target)  = {self._V_eff:.6f}")
        print(f"  Volume (actual)  = {self._V_actual:.6f}")
        print(f"  Volume error     = {abs(self._V_actual - self._V_eff)/self._V_eff*100:.6f} %")
        print(f"  r_equiv (from V) = {m['r_equiv']:.6f}  (should = r_eff)")
        print(f"  r_min            = {m['r_min']:.4f}")
        print(f"  r_max            = {m['r_max']:.4f}")
        print(f"  Asphericity      = {m['asphericity']:.4f}  (0 = perfect sphere)")
        print(f"  Surface area     = {m['surface_area']:.4f}")
        print(f"  Sphere ref. area = {4*np.pi*self.r_eff**2:.4f}")
        print("─" * 60)
        print(f"  shape.r              {self._r.shape}         radius grid (spherical)")
        print(f"  shape.points         {self._points.shape}   flat Cartesian surface points")
        print(f"  shape.normals        {self._normals_flat.shape}   flat unit normals  (same shape as points)")
        print(f"  shape.normals_grid   {self._normals_grid.shape}  unit normals on 2-D grid")
        print("=" * 60)

    # ── plot ─────────────────────────────────────────────────────────────────
    def plot(self, save_path=None, show=True, elev=25, azim=45):
        """
        3-panel figure — visually identical to plot_particle() in shape.py v0.

          Panel 1 : 3D surface coloured by local radius (plot_surface)
          Panel 2 : equatorial cross-section r(phi)  — polar plot
          Panel 3 : meridional cross-section r(theta) — polar plot

        Parameters
        ----------
        save_path : str   path to save the figure (None = don't save to file)
        show      : bool  call plt.show() (default True)
        elev      : float 3-D view elevation in degrees (default 25)
        azim      : float 3-D view azimuth  in degrees (default 45)
        """
        r     = self._r
        theta = self._theta
        phi   = self._phi
        r_eff = self.r_eff

        fig = plt.figure(figsize=(13, 5))
        fig.suptitle(
            f"Irregular sphere  |  $r_{{eff}}$={r_eff}  |  "
            f"σ={self.sigma}  |  L_max={self.L_max}  |  seed={self.seed}",
            fontsize=10)

        # ── Panel 1: 3D surface coloured by radius ────────────────────────────
        ax1 = fig.add_subplot(131, projection='3d')
        ax1.plot_surface(
            self._X, self._Y, self._Z,
            facecolors=plt.cm.RdYlBu_r((r - r.min()) / (r.max() - r.min())),
            alpha=0.92, linewidth=0, antialiased=True)

        ax1.set_title(f'Irregular particle\n$r_{{eff}}$ = {r_eff} µm', fontsize=10)
        ax1.set_xlabel('X (µm)', fontsize=8)
        ax1.set_ylabel('Y (µm)', fontsize=8)
        ax1.set_zlabel('Z (µm)', fontsize=8)
        lim = r_eff * 1.4
        ax1.set_xlim(-lim, lim); ax1.set_ylim(-lim, lim); ax1.set_zlim(-lim, lim)
        ax1.view_init(elev=elev, azim=azim)
        ax1.tick_params(labelsize=7)

        # ── Panel 2: equatorial cross-section r(phi) ──────────────────────────
        ax2 = fig.add_subplot(132, polar=True)
        idx_eq = len(theta) // 2          # equatorial slice θ ≈ π/2
        r_eq   = r[idx_eq, :]
        ax2.plot(phi, r_eq, lw=1.5, color='steelblue')
        ax2.fill(phi, r_eq, alpha=0.25, color='steelblue')
        ax2.plot(phi, np.full_like(phi, r_eff), 'r--', lw=1,
                 label=f'Sphere $r_{{eff}}$={r_eff}')
        ax2.set_title('Equatorial\ncross-section', fontsize=10)
        ax2.legend(fontsize=7, loc='upper right')
        ax2.tick_params(labelsize=7)

        # ── Panel 3: meridional cross-section — polar plot (XZ plane) ──────────
        #
        # Strategy: build the true (x, z) Cartesian contour of the XZ cross-
        # section (same as before, guaranteed continuous), then convert it to
        # 2-D polar coordinates (angle, radius) where:
        #
        #   angle  = arctan2(x, z)   — measured from the +Z axis (north pole)
        #                               so 0° = north, 90° = +X side,
        #                               180° = south, 270° = -X side
        #   radius = sqrt(x² + z²)   — true 2-D distance from the origin
        #                               in the XZ plane
        #
        # This is geometrically correct: the polar plot radius is the actual
        # distance from the particle centre, just like the equatorial panel.
        # The previous wrong versions plotted the 3-D spherical r(theta) as the
        # polar radius, which is incorrect because r·sin(theta) ≠ r in general.

        idx_phi0   = 0
        idx_phi_pi = len(phi) // 2          # phi[N//2] ≈ pi

        r_right = r[:, idx_phi0]            # r at phi=0   (right arc, +X side)
        r_left  = r[:, idx_phi_pi]          # r at phi=pi  (left arc,  -X side)

        # Build Cartesian (x, z) contour — north→south on right, south→north on left
        x_right =  r_right * np.sin(theta)
        z_right =  r_right * np.cos(theta)
        x_left  = -r_left[::-1] * np.sin(theta[::-1])
        z_left  =  r_left[::-1] * np.cos(theta[::-1])

        x_contour = np.concatenate([x_right, x_left, [x_right[0]]])
        z_contour = np.concatenate([z_right, z_left, [z_right[0]]])

        # Convert to 2-D polar coordinates in the XZ plane
        # arctan2(x, z): angle from +Z axis, increasing toward +X
        angle_mer = np.arctan2(x_contour, z_contour)   # range (-pi, pi]
        rho_mer   = np.sqrt(x_contour**2 + z_contour**2)

        # Reference circle: for a perfect sphere, rho = r_eff at all angles
        ang_ref = np.linspace(-np.pi, np.pi, 360)
        rho_ref = np.full_like(ang_ref, r_eff)

        ax3 = fig.add_subplot(133, polar=True)
        ax3.plot(angle_mer, rho_mer, lw=1.5, color='darkorange')
        ax3.fill(angle_mer, rho_mer, alpha=0.25, color='darkorange')
        ax3.plot(ang_ref, rho_ref, 'r--', lw=1,
                 label=f'Sphere $r_{{eff}}$={r_eff}')
        ax3.set_title('Meridional\ncross-section', fontsize=10)
        ax3.legend(fontsize=7, loc='upper right')
        ax3.tick_params(labelsize=7)

        plt.tight_layout()

        if save_path is not None:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            print(f"[DeformedSphere] Figure saved to '{save_path}'")
        if show:
            plt.show()
        return fig

    # ── save ─────────────────────────────────────────────────────────────────
    def save(self, filename=None):
        """
        Save the particle to a NumPy binary file (.npz).

        Saves all parameters AND the computed arrays so the shape can be
        reloaded and used immediately without regenerating.

        Usage:  shape.save('my_particle.npz')
        """
        if filename is None:
            filename = f"deformed_sphere_r{self.r_eff}_L{self.L_max}_s{self.sigma}_d{self.spectral_decay}_nt{self.N_theta}_np{self.N_phi}"
        if not filename.endswith('.npz'):
            filename += '.npz'
        np.savez_compressed(
            filename,
            # parameters
            r_eff          = np.array(self.r_eff),
            L_max          = np.array(self.L_max),
            sigma          = np.array(self.sigma),
            spectral_decay = np.array(self.spectral_decay),
            N_theta        = np.array(self.N_theta),
            N_phi          = np.array(self.N_phi),
            seed           = np.array(-1 if self.seed is None else self.seed),
            # computed arrays
            r              = self._r,
            theta          = self._theta,
            phi            = self._phi,
            normals_grid   = self._normals_grid,
            V_eff          = np.array(self._V_eff),
            V_actual       = np.array(self._V_actual),
        )
        print(f"[DeformedSphere] Saved to '{filename}'  "
              f"({self.N_theta * self.N_phi:,} surface points)")

    # ── load ─────────────────────────────────────────────────────────────────
    def load(self, filename):
        """
        Load a previously saved particle from a .npz file.

        After loading, all properties (shape.points, shape.normals, etc.)
        are immediately available — no regeneration needed.

        Usage:
            shape.load('my_particle.npz')           # on existing object
            shape = DeformedSphere(load='my_particle.npz')  # in constructor
        """
        if not filename.endswith('.npz'):
            filename += '.npz'
        try:
            data = np.load(filename, allow_pickle=True)
        except FileNotFoundError:
            print(f"\n[DeformedSphere ERROR]\n  • File '{filename}' not found.\n")
            sys.exit(1)

        # restore parameters
        self.r_eff          = float(data['r_eff'])
        self.L_max          = int(data['L_max'])
        self.sigma          = float(data['sigma'])
        self.spectral_decay = float(data['spectral_decay'])
        self.N_theta        = int(data['N_theta'])
        self.N_phi          = int(data['N_phi'])
        seed_val            = int(data['seed'])
        self.seed           = None if seed_val == -1 else seed_val

        # restore computed arrays
        self._r             = data['r']
        self._theta         = data['theta']
        self._phi           = data['phi']
        self._normals_grid  = data['normals_grid']
        self._V_eff         = float(data['V_eff'])
        self._V_actual      = float(data['V_actual'])

        # rebuild Cartesian grids and flat arrays
        self._compute_cartesian()

        print(f"[DeformedSphere] Loaded '{filename}'  "
              f"({self.N_theta * self.N_phi:,} surface points)")