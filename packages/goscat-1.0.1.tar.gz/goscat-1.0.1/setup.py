#!/usr/bin/env python
"""
Setup script for goscat package.
"""

from setuptools import setup, find_packages

setup(
    name="goscat",
    version="1.0.1",
    author="Dwaipayan Deb",
    author_email="dwaipayandeb@yahoo.co.in",
    description="Geometric optics light scattering for randomly-shaped particles.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    license="BSD-3-Clause",
    url="https://github.com/DwaipayanDeb/goscat",  
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.24",
        "scipy>=1.8",
        "matplotlib>=3.0",
    ],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: BSD License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering :: Physics",
        "Topic :: Scientific/Engineering :: Mathematics",
    ],
    keywords="light scattering geometric optics particle ray tracing spherical harmonics",
)
