"Direct stdout and stderr to a file for debugging"

import contextlib
import multiprocessing
import os
import sys
import time


# Print if possible
def pprint(*objs):
    "Catch exception if print not possible while running in the background"
    with contextlib.suppress(Exception):
        print(*objs)


class Debug:
    "Redirect stdout to a file for debugging"

    instance = None

    stdout = None
    stderr = None
    file = None
    name = ""
    mode = ""

    workers = 1

    def __new__(cls, name="", mode=""):
        "Create a singleton instance of Debug"
        if cls.instance is None:
            cls.instance = super().__new__(cls)
        return cls.instance

    def __init__(self, name="", mode=""):
        if isinstance(sys.stdout, Debug):
            # Restore stdout since child inherits parent's Debug instance on Linux
            sys.stderr = sys.stdout.stderr
            sys.stdout = sys.stdout.stdout

        self.stdout = sys.stdout
        self.stderr = sys.stderr
        if len(name) != 0:
            self.name = name
            self.mode = mode
        self.reopen()

    def reopen(self):
        "Restart debug redirection - can be called after self.close()"
        sys.stdout = self
        sys.stderr = self
        if len(self.name) != 0:
            self.file = open(self.name, self.mode)

    def close(self):
        "Turn off debug redirection"
        sys.stdout = self.stdout
        sys.stderr = self.stderr
        if len(self.name) != 0:
            self.file.close()

    def write(self, data):
        "Write data to debug file and stdout"
        if self.file is not None:
            with contextlib.suppress(Exception):
                self.file.write(data)
        if self.stdout is not None:
            self.stdout.write(data)
        self.flush()

    def flush(self):
        "Flush data to debug file and stdout after write"
        if self.file is not None:
            self.file.flush()
            os.fsync(self.file.fileno())
        if self.stdout is not None:
            self.stdout.flush()

    def print(self, msg):
        "Print message to stdout and debug file if open"
        # Process name prefix only in multi-worker mode
        prefix = ""
        if self.workers > 1:
            prefix = multiprocessing.current_process().name + ": "
        # Include call stack for diagnostics
        tree = ""
        offset = 0
        while True:
            try:
                offset += 1
                if offset > 2:
                    tree = "/" + sys._getframe(offset).f_code.co_name + tree
                if offset > 4:
                    break
            except ValueError:
                break
        sys.stdout.write(prefix + str(int(time.time())) + ": " + tree + ": " + msg + "\n")

    def get_print(self):
        "Get self.print() method to call directly as print(msg)"
        return self.print


def dprint(msg):
    "Print debug message if debug is enabled"
    if Debug.instance is not None:
        Debug.instance.print(msg)
