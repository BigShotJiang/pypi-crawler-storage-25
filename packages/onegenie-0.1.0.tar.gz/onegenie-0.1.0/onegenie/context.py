from dataclasses import dataclass
from typing import List, Dict, Any, Callable


class LLMTools:
    def __init__(self, gen_stream: Callable, gen: Callable):
        self.gen_stream = gen_stream
        self.gen = gen


class FSTools:
    def __init__(self, upload_file: Callable):
        self.upload_file = upload_file


@dataclass
class Context:
    messages: List[Dict[str, Any]]
    extra_params: Dict[str, Any]
    llm: LLMTools
    fs: FSTools
    mcp: Any
