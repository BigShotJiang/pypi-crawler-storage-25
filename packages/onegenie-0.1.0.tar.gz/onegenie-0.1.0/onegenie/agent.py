from typing import List, Callable, Optional, Dict, Any
from pydantic import BaseModel
from .context import Context


class ModelConfig(BaseModel):
    id: str
    features: Optional[Dict[str, Any]] = None


class Agent:
    def __init__(
        self,
        id: str,
        name: str,
        desc: str,
        models: List[ModelConfig],
        extra_params: Any = None,
        survey: Any = None,
    ):
        self.id = id
        self.name = name
        self.desc = desc
        self.models = models
        self.extra_params = extra_params
        self.survey = survey
        self._run_handler: Optional[Callable[[Context], Any]] = None

    def on_run(self, func: Callable[[Context], Any]):
        self._run_handler = func
        return func

    def serve(self):
        if not self._run_handler:
            raise ValueError("Missing @agent.on_run")

        agent_card = {
            "id": self.id,
            "name": self.name,
            "desc": self.desc,
            "models": [m.model_dump(exclude_none=True) for m in self.models],
        }

        agent_card["extra_params"] = self.extra_params or {}

        if self.survey is not None:
            agent_card["extra_params"]["survey"] = self.survey

        from .daemon import start_daemon

        start_daemon(agent_card, self._run_handler)
