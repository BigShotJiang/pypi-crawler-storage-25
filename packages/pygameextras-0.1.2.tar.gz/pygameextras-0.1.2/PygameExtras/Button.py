import pygame

class Button:
    def __init__(self, rect: pygame.Rect, text: str="", onClick=None, bgColor: tuple[int, int, int]=(70, 70, 70), hoverColor: tuple[int, int, int]=(100, 100, 100), pressedColor: tuple[int, int, int]=(130, 130, 130), textColor: tuple[int, int, int]=(255, 255, 255), font: pygame.font.Font | None=None):
        self.rect = rect
        self.text = text
        self.onClick = onClick

        self.bgColor = bgColor
        self.hoverColor = hoverColor
        self.pressedColor = pressedColor
        self.textColor = textColor
        
        self.font = font or pygame.font.SysFont("arial", 24)

        self.hovered = False
        self.pressed = False

        # Pre-render text
        self.textSurface = self.font.render(self.text, True, self.textColor)
        self.textRect = self.textSurface.get_rect(center=self.rect.center)

    def HandleEvent(self, event: pygame.event.Event):
            if event.type == pygame.MOUSEMOTION:
                self.hovered = self.rect.collidepoint(event.pos)
            
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1 and self.hovered:
                    self.pressed = True
            
            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1 and self.pressed and self.hovered:
                    self.pressed = False
                    if self.onClick:
                        self.onClick()
                else:
                    self.pressed = False
        
    def Draw(self, surface: pygame.Surface):
            color = self.pressedColor if self.pressed else self.hoverColor if self.hovered else self.bgColor
            pygame.draw.rect(surface, color, self.rect)
            surface.blit(self.textSurface, self.textRect)