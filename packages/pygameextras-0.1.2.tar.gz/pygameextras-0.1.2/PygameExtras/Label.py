import pygame

class Label:
    def __init__(self, rect: pygame.Rect, text: str, textColor: tuple[int, int, int] = (255, 0, 0), font: pygame.font.Font | None = None, bgColor: tuple[int, int, int] | None = None) -> None:
        self.rect = rect
        self.text = text
        self.textColor = textColor
        self.font = font or pygame.font.SysFont("arial", 24)
        self.bgColor = bgColor

        # Pre-render text
        self.RenderText()
    
    def RenderText(self) -> None:
        self.textSurface = self.font.render(self.text, True, self.textColor)
        self.textRect = self.textSurface.get_rect(center=self.rect.center)

    def Change(self, text: str | None = None, textColor: tuple[int, int, int] | None = None, font: pygame.font.Font | None = None, bgColor: tuple[int, int, int] | None = (-1, -1, -1)):
        if text: self.text = text
        if textColor: self.textColor = textColor
        if font: self.font = font
        if bgColor != (-1, -1, -1): self.bgColor = bgColor
        self.RenderText()

    def ChangeText(self, text: str) -> None:
        self.text = text
        self.RenderText()
    
    def ChangeTextColor(self, textColor: tuple[int, int, int]) -> None:
        self.textColor = textColor
        self.RenderText()
    
    def ChangeFont(self, font: pygame.font.Font) -> None:
        self.font = font
        self.RenderText()

    def Draw(self, surface: pygame.Surface) -> None:
        if self.bgColor:
            pygame.draw.rect(surface, self.bgColor, self.textRect)
        surface.blit(self.textSurface, self.textRect)