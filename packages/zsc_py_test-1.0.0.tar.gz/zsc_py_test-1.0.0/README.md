# Zettel Store Client (Python Version)

## Projektbeschreibung

Dieses Projekt ist ein Python-Client für den [Zettelstore](https://zettelstore.de/home/doc/trunk/www/index.wiki), der die Nutzung des Zettelstores in Python-Projekten vereinfacht. Die Bibliothek ermöglicht das Erstellen, Abrufen, Bearbeiten und Verwalten von Zetteln ohne selber HTTP Requests schreiben zu müssen. Der Fokus liegt auf einer einfachen Integration, guter Dokumentation sowie stabiler und wartbarer Funktionalität.

## Installationsanleitung

Öffne deine Kommandozeile in deinem Python-Projekt und installiere das Paket via pip.

```bash
pip install zsc_py_test
```

Jetzt musst du das Paket nur noch via `import zsc_py_test` importieren.

### Quickstart

```python
import zsc_py_test

client = zsc_py_test.ZettelstoreClient()
listeAllerZettel = client.list_zettel()
client.create_zettel({"title":"Neuer Zettel"}, "Neuer Inhalt")
```

## Wichtigste Funktionen

| Funktion                                          | Code                                                                          |
| ------------------------------------------------- | ----------------------------------------------------------------------------- |
| Zettel im Zettelstore erstellen                   | `client.create_zettel({"title":"Neuer Zettel"}, "Neuer Inhalt")`              |
| Zettel im Zettelstore löschen                     | `client.delete_zettel("<zettelid>")`                                          |
| Vorhandene Zettel im Zettelstore ändern           | `client.update_zettel("<zettelid>", {"title":"Neuer Titel"}, "Neuer Inhalt")` |
| Eine Liste aller Vorhanden Zettel mit Id bekommen | `client.list_zettel()`                                                        |

Für eine generauer Beschreibung aller Funktionen schaue in [Dokumentation aller Funktionalitäten](docs/dokumentation_funktionaliäten.md) oder gib in den IDE (Vscode, Pycharm etc.) deiner Wahl `client.` ein und gehe die ausgegeben Optionen durch.

## Weiterentwicklung

Allgemein Repository installieren:

Link zum genauerem Setup: [Weiterentwicklungsguide](docs/weiterentwicklungs_guide.md)
