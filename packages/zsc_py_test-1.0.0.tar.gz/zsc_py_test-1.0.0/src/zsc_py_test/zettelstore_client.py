# -----------------------------------------------------------------------------
#  Copyright (c) 2026-present Authors in AUTHORS.txt

# This file is part of zsc_py_test.

# The zettelstore python client is licensed under the latest version of the EUPL (European Union
# Public License). Please see file LICENSE.txt for your rights and obligations
# under this license.

# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2026-present  Contributors (see AUTHORS.txt)
# -----------------------------------------------------------------------------

from requests import Session

from zsc_py_test.apis.auth_api import AuthApi
from zsc_py_test.apis.zettel_api import ZettelApi
from zsc_py_test.services.auth_service import AuthService
from zsc_py_test.services.transport_service import TransportService
from zsc_py_test.transport_adapter import TransportAdapter
from zsc_py_test.services.zettel_service import ZettelService
from zsc_py_test.types import ZettelstoreClientConfig


class ZettelstoreClient(AuthApi, ZettelApi):
    def __init__(
        self,
        config: dict[str, str | int | bool] | ZettelstoreClientConfig | None = None,
    ) -> None:
        if not isinstance(config, ZettelstoreClientConfig):
            config = ZettelstoreClientConfig.build_from_dict(config)

        self._session = Session()
        self._transport_service = TransportService(
            config=config,
            session=self._session,
            transport_adapter=TransportAdapter(),
        )
        self._auth_service = AuthService(
            config=config,
            transport_service=self._transport_service,
        )
        self._transport_service.set_auth_service(
            auth_service=self._auth_service,
        )
        self._zettel_service = ZettelService(
            config=config,
            transport_service=self._transport_service,
        )
