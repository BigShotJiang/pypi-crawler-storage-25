# -----------------------------------------------------------------------------
#  Copyright (c) 2026-present Authors in AUTHORS.txt

# This file is part of zsc_py_test.

# The zettelstore python client is licensed under the latest version of the EUPL (European Union
# Public License). Please see file LICENSE.txt for your rights and obligations
# under this license.

# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2026-present  Contributors (see AUTHORS.txt)
# -----------------------------------------------------------------------------

import requests
from requests import Response, Session


class TransportAdapter:
    def request(
        self,
        session: Session,
        url: str = "",
        method: str = "GET",
        headers: dict[str, str] | None = None,
        body: str | None = None,
        auth: tuple[str, str] | None = None,
        timeout: tuple[int, int] | None = None,
        allow_redirects: bool = False,
    ) -> Response:
        try:
            return session.request(
                method=method,
                url=url,
                auth=auth,
                headers=headers,
                data=body,
                timeout=timeout,
                allow_redirects=allow_redirects,
            )
        except requests.exceptions.Timeout:
            raise requests.exceptions.Timeout
