# -----------------------------------------------------------------------------
#  Copyright (c) 2026-present Authors in AUTHORS.txt

# This file is part of zsc_py_test.

# The zettelstore python client is licensed under the latest version of the EUPL (European Union
# Public License). Please see file LICENSE.txt for your rights and obligations
# under this license.

# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2026-present  Contributors (see AUTHORS.txt)
# -----------------------------------------------------------------------------

"""
ZettelStore Client (zsc-py)

This package provides a client interface for using the ZettelStore API in a python application.
It offers an interface for retrieving, creating, updating and deleting zettel from a Zettelstore instance.

"""

from zsc_py_test.types import ZettelQuery, ZettelstoreClientConfig
from zsc_py_test.zettelstore_client import ZettelstoreClient

__version__ = "0.0.1"

__all__ = [
    "ZettelQuery",
    "ZettelstoreClient",
    "ZettelstoreClientConfig",
    "__version__",
]
