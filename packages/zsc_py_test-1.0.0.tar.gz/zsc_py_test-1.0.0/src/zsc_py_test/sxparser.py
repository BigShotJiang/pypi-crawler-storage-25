#!/usr/bin/env python3
#
# Copyright (c) 2025-present Detlef Stern
#
# This file is part of sxpy.
#
# sxpy is licensed under the latest version of the EUPL (European Union
# Public License). Please see file LICENSE.txt for your rights and obligations
# under this license.
#
# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2025-present Detlef Stern

"""This module provides a simple parser for symbolic expressions."""

import re
from typing import Union, List, Tuple, Optional, Any

SxValue = Union[int, str, "Symbol", "Cons", None]
PyValue = Union[int, str, "Symbol", List["PyValue"], Tuple["PyValue", "PyValue"], None]


class Cons:  # pylint: disable=too-few-public-methods
    """
    A Lisp cons cell: (car . cdr).

    Attributes:
        car (SxValue): The first element of the cons cell.
        cdr (Optional[SxValue]): The second element or the rest of the list.
    """

    car: SxValue
    cdr: Optional[SxValue]

    __slots__ = ("car", "cdr")

    def __init__(self, car: SxValue, cdr: Optional[SxValue]):
        """
        Initialize a cons cell with car and cdr values.

        Args:
            car (SxValue): The first element.
            cdr (Optional[SxValue]): The second element.
        """
        self.car = car
        self.cdr = cdr

    def __repr__(self) -> str:
        """
        Return string representation of the cons cell.

        Returns:
            str: The formatted S-expression string.
        """
        parts = []
        cur: SxValue = self
        while isinstance(cur, Cons):
            # Strings mit doppelten Anführungszeichen
            if isinstance(cur.car, str):
                parts.append(f'"{cur.car}"')
            else:
                parts.append(repr(cur.car))
            cur = cur.cdr
        if cur is None:
            return f"({' '.join(parts)})"
        # Auch für dotted pairs
        if isinstance(cur, str):
            return f'({" ".join(parts)} . "{cur}")'
        return f"({' '.join(parts)} . {repr(cur)})"


def to_python(obj: SxValue) -> PyValue:
    """
    Convert a Cons-based structure into a Python structure.

    Converts Cons cells into Python lists and tuples.

    Args:
        obj (SxValue): The S-expression structure to convert.

    Returns:
        PyValue: The resulting Python list, tuple, or atom.
    """
    if obj is None:
        return []

    if isinstance(obj, Cons):
        items: List[PyValue] = []
        cur: SxValue = obj
        while isinstance(cur, Cons):
            car: PyValue = to_python(cur.car) if isinstance(cur.car, Cons) else cur.car
            items.append(car)
            cur = cur.cdr
        if cur is None:
            return items
        tail = to_python(cur) if isinstance(cur, Cons) else cur
        if len(items) == 1:
            return (items[0], tail)
        return items[:-1] + [(items[-1], tail)]

    return obj


def from_python(obj: PyValue) -> SxValue:
    """
    Convert a nested Python list / tuple into nested cons lists.

    Args:
        obj (PyValue): The Python structure to convert.

    Returns:
        SxValue: The resulting Cons-based structure.

    Raises:
        ValueError: If a tuple does not have exactly two elements.
    """
    if isinstance(obj, list):
        if not obj:
            return NIL
        head = from_python(obj[0])
        tail = from_python(obj[1:])
        return Cons(head, tail)

    if isinstance(obj, tuple):
        if len(obj) != 2:
            raise ValueError("need tuple of length 2 to interpret as dotted pair")
        return Cons(from_python(obj[0]), from_python(obj[1]))

    return obj


NIL = None


class Symbol:
    """
    Represents a symbol.

    Attributes:
        name (str): The name of the symbol.
    """

    name: str  # Added for pydoclint visibility
    __slots__ = ("name",)

    def __init__(self, name: str):
        """
        Initialize a symbol with a name.

        Args:
            name (str): The name for the symbol.
        """
        self.name = name

    def __repr__(self) -> str:
        """
        Return string representation of the symbol.

        Returns:
            str: The symbol name.
        """
        return self.name

    def __eq__(self, other: Any) -> bool:
        """
        Check equality with another symbol.

        Args:
            other (Any): The object to compare with.

        Returns:
            bool: True if equal, False otherwise.
        """
        return isinstance(other, Symbol) and self.name == other.name


class SxParser:
    """Encapsulate the whole parsing, manage the parsing state."""

    def __init__(self, s: str) -> None:
        """
        Initialize the parser with a string to parse.

        Args:
            s (str): The input string to be parsed.
        """
        self.tokens = self.tokenize(s)
        self.pos = 0

    def tokenize(self, s: str) -> List[str]:
        """
        Transform the string into a list of tokens.

        Args:
            s (str): The raw input string.

        Returns:
            List[str]: A list of tokens found in the string.
        """
        pattern = r"""\s*(,@|[('`)]|"(?:\\.|[^"\\])*"|[^\s('"`,;)]*)"""
        tokens = [t for t in re.findall(pattern, s) if t and not t.isspace()]
        return tokens

    def current(self) -> Optional[str]:
        """
        Return the current token.

        Returns:
            Optional[str]: The token at the current position or None.
        """
        return self.tokens[self.pos] if self.pos < len(self.tokens) else None

    def advance(self) -> None:
        """Advance to the next token."""
        self.pos += 1

    def parse(self) -> SxValue:
        """
        Parse a value and check for excess tokens.

        Returns:
            SxValue: The parsed symbolic expression.

        Raises:
            SyntaxError: If tokens remain after parsing one expression.
        """
        expr = self.parse_expr()
        if self.current() is not None:
            raise SyntaxError(f"unexpected token: {self.current()}")
        return expr

    def parse_expr(self) -> SxValue:
        """
        Parse any symbolic expression.

        Returns:
            SxValue: The parsed atom or list.

        Raises:
            SyntaxError: If input ends prematurely or is invalid.
        """
        tok = self.current()
        if tok is None:
            raise SyntaxError("unexpected end of input")
        if tok == "(":
            return self.parse_list()
        if tok == ")":
            raise SyntaxError("unexpected ')'")
        if tok == ".":
            raise SyntaxError("unexpected '.' outside a list")
        if tok.startswith('"') and tok.endswith('"'):
            self.advance()
            return tok[1:-1]
        self.advance()
        try:
            return int(tok)
        except ValueError:
            pass
        return Symbol(tok)

    def parse_list(self) -> SxValue:
        """
        Parse a list into a Cons list.

        Returns:
            SxValue: The parsed list as a Cons chain.

        Raises:
            SyntaxError: If the list is improperly terminated.
        """
        self.advance()  # '('
        if self.current() == ")":
            self.advance()
            return NIL

        first = self.parse_expr()

        if self.current() == ".":
            self.advance()
            second = self.parse_expr()
            if self.current() != ")":
                raise SyntaxError("missing ')' after dotted pair")
            self.advance()
            return Cons(first, second)
        return Cons(first, self.parse_list_tail())

    def parse_list_tail(self) -> SxValue:
        """
        Parse the tail of a list.

        Returns:
            SxValue: The rest of the Cons list.

        Raises:
            SyntaxError: If a dotted pair is malformed.
        """
        if self.current() == ")":
            self.advance()
            return NIL
        first = self.parse_expr()
        if self.current() == ".":
            self.advance()
            second = self.parse_expr()
            if self.current() != ")":
                raise SyntaxError("missing ')' after dotted pair")
            self.advance()
            return Cons(first, second)
        return Cons(first, self.parse_list_tail())


def parse(s: str) -> SxValue:
    """
    Parse a string into a Sx list.

    Args:
        s (str): The string to parse.

    Returns:
        SxValue: The resulting S-expression.
    """
    return SxParser(s).parse()
