# -----------------------------------------------------------------------------
#  Copyright (c) 2026-present Authors in AUTHORS.txt

# This file is part of zsc_py_test.

# The zettelstore python client is licensed under the latest version of the EUPL (European Union
# Public License). Please see file LICENSE.txt for your rights and obligations
# under this license.

# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2026-present  Contributors (see AUTHORS.txt)
# -----------------------------------------------------------------------------

#  TODO: anti-pattern imo, at best there shouldn't be a need for utils

from typing import Any
from zsc_py_test.sxparser import Symbol
from zsc_py_test.types import SzZettel
from zsc_py_test.constants import PART_CONTENT, PART_META


def to_metadata_dict(data: Any) -> dict[str, Any]:
    result: dict[str, Any] = {}

    if not isinstance(data, list):
        return result

    entries = (
        data[1:]
        if data and isinstance(data[0], Symbol) and data[0].name.lower() == "meta"
        else data
    )

    for item in entries:
        if isinstance(item, tuple) and len(item) == 2:
            key, value = item
        elif isinstance(item, list):
            if len(item) == 2:
                key, value = item
            elif len(item) >= 3:
                _, key, *values = item
                value = values[0] if len(values) == 1 else values
            else:
                continue
        else:
            continue

        if isinstance(key, Symbol):
            key = key.name

        if isinstance(key, str):
            result[key] = value

    return result


def to_sz_zettel(data: Any, part: str) -> SzZettel:
    if part == PART_CONTENT:
        if (
            isinstance(data, list)
            and data
            and isinstance(data[0], Symbol)
            and data[0].name.lower() in {"content", "block"}
        ):
            data = data[1] if len(data) == 2 else data[1:]
        return SzZettel(content=data)

    if part == PART_META:
        return SzZettel(metadata=to_metadata_dict(data))

    metadata: dict[str, Any] = {}
    content: Any = None

    sections = (
        data[1:]
        if isinstance(data, list)
        and data
        and isinstance(data[0], Symbol)
        and data[0].name.lower() == "zettel"
        else data
    )

    if isinstance(sections, list):
        for section in sections:
            if not isinstance(section, list) or not section:
                continue

            if not isinstance(section[0], Symbol):
                continue

            section_name = section[0].name.lower()

            if section_name == "meta":
                metadata.update(to_metadata_dict(section))
            elif section_name in {"content", "block"}:
                content = section[1] if len(section) == 2 else section[1:]

    if metadata or content is not None:
        return SzZettel(metadata=metadata, content=content)

    metadata = to_metadata_dict(data)
    return SzZettel(metadata=metadata, content=metadata.get("body"))


def to_sz_dict_list(data: Any, part: str) -> list[dict[str, Any]]:
    return [to_sz_zettel(data, part).to_dict()]
