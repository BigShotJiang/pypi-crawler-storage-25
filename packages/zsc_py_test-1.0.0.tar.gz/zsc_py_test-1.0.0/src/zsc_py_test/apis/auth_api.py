# -----------------------------------------------------------------------------
#  Copyright (c) 2026-present Authors in AUTHORS.txt
#
# This file is part of zsc_py_test.
#
# The zettelstore python client is licensed under the latest version of the EUPL (European Union
# Public License). Please see file LICENSE.txt for your rights and obligations
# under this license.
#
# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2026-present  Contributors (see AUTHORS.txt)
# -----------------------------------------------------------------------------

from zsc_py_test.services.auth_service import AuthService


class AuthApi:
    _auth_service: "AuthService"

    def set_auth(self, username: str, password: str) -> None:
        """Set credentials to be used for authenticated requests to the zettelstore.

        This stores or configures the username/password pair in the authentication service.
        So authenticated requests can be made to the zettelstore.

        Arguments:
            username (str): The username to set for authentication.
            password (str): The password associated with username.

        Returns:
            None

        Raises:
            ValueError: If username or password are empty

        Example:
            client = zsc_py_test.ZettelstoreClient()
            client.set_auth("zettler", "PASSWORD123456789")
        """
        return self._auth_service.set_auth(username=username, password=password)

    def authenticate(self) -> None:
        """Perform authentication using currently configured credentials.

        This triggers an authentication flow in the underlying AuthService.

        Returns:
            None

        Raises:
            ValueError: If password or username are not set
            APIError: If some other error occurs during authentication (network,
                protocol error, etc.).

        Example:
            client = zsc_py_test.ZettelstoreClient()
            client.set_auth("zettler", "PASSWORD123456789")
            client.authenticate()
        """
        return self._auth_service.authenticate()

    def update_token(self) -> None:
        """Refresh or update the authentication token.

        Use this to explicitly request a token refresh when token-based auth is
        used.

        Returns:
            None

        Raises:
            ValueError: If password or username are not set
            APIError: If some other error occurs during authentication (network,
                protocol error, etc.).

        Example:
            client = zsc_py_test.ZettelstoreClient()
            client.update_token()
        """
        return self._auth_service.update_token()

    def get_administrative_data(self) -> dict[str, int | str]:
        """Retrieve the current zettelstore version.

        Returns:
            dict[str, int | str]: Parsed administrative data, including the
                runtime configuration zettel identifier.

        Raises:
            APIError: If the administrative data cannot be retrieved.

        Example:
            client = zsc_py_test.ZettelstoreClient()
            admin_info = client.get_administrative_data()
        """
        return self._auth_service.get_administrative_data()
