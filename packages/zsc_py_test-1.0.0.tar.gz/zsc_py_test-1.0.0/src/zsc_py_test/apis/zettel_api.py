# -----------------------------------------------------------------------------
#  Copyright (c) 2026-present Authors in AUTHORS.txt
#
# This file is part of zsc_py_test.
#
# The zettelstore python client is licensed under the latest version of the EUPL (European Union
# Public License). Please see file LICENSE.txt for your rights and obligations
# under this license.
#
# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2026-present  Contributors (see AUTHORS.txt)
# -----------------------------------------------------------------------------


from zsc_py_test.constants import PART_ZETTEL
from zsc_py_test.types import ZettelEncoding, ZettelQuery
from zsc_py_test.services.zettel_service import ZettelService


class ZettelApi:
    _zettel_service: "ZettelService"

    def get_zettel(
        self,
        zettel_id: str,
        part: str = PART_ZETTEL,
        enc: str = str(ZettelEncoding.PLAIN),
        as_object: bool = False,
        as_dict: bool = False,
    ):
        """Retrieve a zettel by its ID.

        Allows specifying which part of the zettel to retrieve, the encoding,
        and the desired output form.

        Arguments:
            zettel_id (str): The ID of the zettel to retrieve.
            part (str): The part of the zettel to retrieve. Common values are
                'zettel' (all), 'meta', and 'content'. Defaults to the full zettel.
            enc (str): The encoding format. Common values are representation constants
                defined in `ZettelEncoding`. Defaults to ZettelEncoding.PLAIN.
            as_object (bool): If True, return the zettel as a Python object (service-dependent).
            as_dict (bool): If True, return the zettel as a dictionary (service-dependent).

        Returns:
            The result returned by the underlying zettel service. This is typically
            a string, but may be an object or dict depending on as_object / as_dict.

        Raises:
            TypeError: If `zettel_id` is falsy or of an unexpected type.
            ValueError: If the requested encoding or part is invalid.
            APIError: If the zettel does not exist or the service reports an error.

        Example:
            client = zsc_py_test.ZettelstoreClient()
            z = client.get_zettel("00010000000000")
        """
        return self._zettel_service.get_zettel(
            zettel_id=zettel_id,
            part=part,
            enc=enc,
            as_object=as_object,
            as_dict=as_dict,
        )

    def create_zettel(self, metadata: dict[str, str] = dict(), body: str = ""):
        """Create a new zettel with the provided headers and body.

        Arguments:
            metadata (dict[str, str]): Metadata headers for the new zettel.
            body (str): The content/body of the zettel.

        Returns:
            The zettelid of the newly created zettel as a string

        Raises:
            ValueError: If required header values are missing or the body is invalid.
            APIError: If the service reports an error creating the zettel.

        Example:
            client = zsc_py_test.ZettelstoreClient()
            created = client.create_zettel({"title": "Note"}, "This is the body.")
        """
        return self._zettel_service.create_zettel(metadata=metadata, body=body)

    def get_configuration_zettel(
        self,
        part: str = PART_ZETTEL,
        enc: str = str(ZettelEncoding.PLAIN),
    ):
        """Retrieve the configuration zettel.

        This returns the special configuration zettel used by the zettelstore.

        Arguments:
            part (str): The part of the configuration zettel to retrieve.
                Defaults to the full zettel.
            enc (str): The encoding format to request. Defaults to `ZettelEncoding.PLAIN`.

        Returns:
            The configuration zettel as returned by the underlying service, typically a string.

        Raises:
            ValueError: If the requested encoding or part is invalid.
            APIError: If the service cannot retrieve the configuration zettel.

        Example:
            client = zsc_py_test.ZettelstoreClient()
            cfg = client.get_configuration_zettel()
        """
        return self._zettel_service.get_configuration_zettel(part=part, enc=enc)

    def delete_zettel(self, zettel_id: str) -> None:
        """Delete a zettel by its ID.

        Arguments:
            zettel_id (str): The ID of the zettel to delete.

        Returns:
            None

        Raises:
            TypeError: If `zettel_id` is falsy or of an unexpected type.
            APIError: If the zettel does not exist or the service reports an error.

        Example:
            client = zsc_py_test.ZettelstoreClient()
            client.delete_zettel("00010000000000")
        """
        self._zettel_service.delete_zettel(zettel_id=zettel_id)

    def update_zettel(self, zettel_id: str, metadata: dict[str, str], body: str):
        """Update an existing zettel.

        Replace or update the metadata and body of an existing zettel.

        Arguments:
            zettel_id (str): The ID of the zettel to update.
            metadata (dict[str, str]): New or updated metadata headers.
            body (str): New content/body for the zettel.

        Returns:
            None

        Raises:
            TypeError: If `zettel_id` is falsy or of an unexpected type.
            ValueError: If provided headers/body are invalid.
            APIError: If the service reports an error updating the zettel.

        Example:
            client = zsc_py_test.ZettelstoreClient()
            client.update_zettel("00010000000000", {"title": "Updated"}, "New body")
        """
        self._zettel_service.update_zettel(
            zettel_id=zettel_id, metadata=metadata, body=body
        )

    def list_zettel(self) -> str:
        """List available zettels.

        Returns:
            A listing of zettels as returned by the underlying service (string).

        Raises:
            APIError: If the service reports an error while listing zettels.

        Example:
            client = zsc_py_test.ZettelstoreClient()
            ls = client.list_zettel()
        """
        return self._zettel_service.list_zettel()

    def query_zettel(self, query: str | ZettelQuery) -> str:
        """Query zettels using a query string or ZettelQuery object.

        Accepts either a raw query string or a pre-constructed `ZettelQuery`.
        If a string is provided, it will be converted to `ZettelQuery`.

        Arguments:
            query (str | ZettelQuery): The query to run against the zettel store.

        Returns:
            The query result as returned by the underlying service (typically a string).

        Raises:
            ValueError: If the query string cannot be parsed into a ZettelQuery.
            APIError: If the service reports an error executing the query.

        Example:
            client = zsc_py_test.ZettelstoreClient()
            result = client.query_zettel('title:"notes"')
        """
        if isinstance(query, str):
            query = ZettelQuery.from_str(query)
        return self._zettel_service.query_zettel(query=query)

    def tag_zettel(self, tag: str) -> list[str]:
        """Retrieve zettel IDs that have the given tag.

        Arguments:
            tag (str): The tag to filter zettels by.

        Returns:
            A list of zettel IDs (strings) that are associated with the provided tag.

        Raises:
            TypeError: If `tag` is falsy or not a string.
            APIError: If the underlying service reports an error while fetching tagged zettels.

        Example:
            client = zsc_py_test.ZettelstoreClient()
            todos = client.tag_zettel(\"todo\")
        """
        return self._zettel_service.tag_zettel(tag=tag)

    def role_zettel(self, role: str) -> list[str]:
        """Retrieve zettel IDs associated with a specific role.

        Arguments:
            role (str): The role name to filter zettels by.

        Returns:
            A list of zettel IDs (strings) that are associated with the provided role.

        Raises:
            APIError: If the underlying service reports an error while fetching role-based zettels.

        Example:
            client = zsc_py_test.ZettelstoreClient()
            admin_zettels = client.role_zettel(\"admin\")
        """
        return self._zettel_service.role_zettel(role=role)

    def get_zettel_uri(self, zettel_id: str) -> str:
        """Retrieve the URI reference for a zettel by its ID.

        Arguments:
            zettel_id (str): The ID of the zettel to retrieve the URI for.

        Returns:
            The URI reference for the zettel as returned by the underlying service.

        Raises:
            TypeError: If `zettel_id` is falsy or of an unexpected type.
            APIError: If the underlying service reports an error while fetching the URI.

        Example:
            client = zsc_py_test.ZettelstoreClient()
            uri = client.get_zettel_uri("00001012053211")
        """
        return self._zettel_service.get_zettel_uri(zettel_id=zettel_id)

    def get_random_zettel(self, amount: int = 1) -> list[str]:
        """Retrieve one or more random zettel IDs.

        Arguments:
            amount (int): The number of random zettels to request. Defaults to 1.

        Returns:
            A list of randomly selected zettel IDs as returned by the underlying service.

        Raises:
            ValueError: If `amount` is invalid for the underlying query.
            APIError: If the underlying service reports an error while fetching random zettels.

        Example:
            client = zsc_py_test.ZettelstoreClient()
            random_zettels = client.get_random_zettel(2)
        """
        return self._zettel_service.get_random_zettel(amount=amount)

    def get_zettel_links(self, zettel_id: str) -> dict:
        """Retrieve all references of a zettel grouped by reference type.

        Arguments:
            zettel_id (str): The ID of the zettel to retrieve links for.

        Returns:
            A dictionary containing the zettel ID and lists of referenced zettel IDs
            grouped by reference type (folge, forward, back, backward, precursor,
            sequel, subordinate, successor).

        Example:
            client = zsc_py_test.ZettelstoreClient()
            links = client.get_zettel_links("00001012053300")
        """
        return self._zettel_service.get_zettel_links(zettel_id=zettel_id)
