# -----------------------------------------------------------------------------
#  Copyright (c) 2026-present Authors in AUTHORS.txt

# This file is part of zsc_py_test.

# The zettelstore python client is licensed under the latest version of the EUPL (European Union
# Public License). Please see file LICENSE.txt for your rights and obligations
# under this license.

# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2026-present  Contributors (see AUTHORS.txt)
# -----------------------------------------------------------------------------

# TODO: Future add Zettel type that can represent a zettel also in sz, therefore remove SzZettel

from dataclasses import dataclass, field
from typing import Any


@dataclass
class SzZettel:
    metadata: dict[str, Any] = field(default_factory=dict)
    content: Any = None

    @property
    def body(self) -> Any:
        return self.content if self.content is not None else self.metadata.get("body")

    def get(self, key: str, default: Any = None) -> Any:
        return self.metadata.get(key, default)

    def to_dict(self) -> dict[str, Any]:
        result = dict(self.metadata)
        if self.content is not None and "body" not in result:
            result["body"] = self.content
        return result

    def __getattr__(self, name: str) -> Any:
        if name.startswith("__"):
            raise AttributeError(name)
        return self.metadata.get(name, None)
