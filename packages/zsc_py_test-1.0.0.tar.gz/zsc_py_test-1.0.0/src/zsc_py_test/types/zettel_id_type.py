# -----------------------------------------------------------------------------
#  Copyright (c) 2026-present Authors in AUTHORS.txt

# This file is part of zsc_py_test.

# The zettelstore python client is licensed under the latest version of the EUPL (European Union
# Public License). Please see file LICENSE.txt for your rights and obligations
# under this license.

# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2026-present  Contributors (see AUTHORS.txt)
# -----------------------------------------------------------------------------

from dataclasses import dataclass
from datetime import datetime
from zsc_py_test.constants import (
    LENGTH_ZID,
    MAX_ZID,
    TIMESTAMP_LAYOUT,
)


@dataclass(slots=True)
class ZettelId:
    zettel_id: str

    def __post_init__(self) -> None:
        normalized_zettel_id = self.zettel_id.strip()

        if len(normalized_zettel_id) != LENGTH_ZID:
            raise TypeError(
                f"Zid must be {LENGTH_ZID} characters long, got {len(normalized_zettel_id)}"
            )

        if not normalized_zettel_id.isdigit():
            raise TypeError(f"{normalized_zettel_id} is not a integer")

        zettel_id_int = int(normalized_zettel_id)
        if not 0 <= zettel_id_int <= MAX_ZID:
            raise TypeError(f"Zid value outside of the allowed range: {zettel_id_int}")

        self.zettel_id = normalized_zettel_id

    def __str__(self) -> str:
        return self.zettel_id

    @classmethod
    def new(cls) -> "ZettelId":
        return cls(datetime.now().strftime(TIMESTAMP_LAYOUT))
