# -----------------------------------------------------------------------------
#  Copyright (c) 2026-present Authors in AUTHORS.txt

# This file is part of zsc_py_test.

# The zettelstore python client is licensed under the latest version of the EUPL (European Union
# Public License). Please see file LICENSE.txt for your rights and obligations
# under this license.

# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2026-present  Contributors (see AUTHORS.txt)
# -----------------------------------------------------------------------------

from enum import Enum


class ApiMode(str, Enum):
    """
    Contains all api modes available from the zettelstore api
    """

    AUTH = "a"  # authentication / token
    REF = "r"  # references
    EXEC = "x"  # admin / commands
    ZETTEL = "z"  # zettel operations

    def __str__(self) -> str:
        return self.value
