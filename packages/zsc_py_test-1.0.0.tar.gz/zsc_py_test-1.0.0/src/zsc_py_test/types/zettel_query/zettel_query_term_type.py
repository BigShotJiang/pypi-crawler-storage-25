# -----------------------------------------------------------------------------
#  Copyright (c) 2026-present Authors in AUTHORS.txt

# This file is part of zsc_py_test.

# The zettelstore python client is licensed under the latest version of the EUPL (European Union
# Public License). Please see file LICENSE.txt for your rights and obligations
# under this license.

# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2026-present  Contributors (see AUTHORS.txt)
# -----------------------------------------------------------------------------

from dataclasses import dataclass
import re


def quote_query_value(value: str) -> str:
    if value == "":
        return '""'

    if re.fullmatch(r'[^\s|"]+', value):
        return value

    escaped = value.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'


@dataclass(slots=True)
class ZettelQueryTerm:
    field: str | None
    operator: str = ""
    value: str | None = None

    def query_string(self) -> str:
        if self.field is None:
            if self.value is None:
                raise ValueError("Full-text search terms require a value.")
            return f"{self.operator}{quote_query_value(self.value)}"

        if self.operator in {"?", "!?"}:
            return f"{self.field}{self.operator}"

        if not self.value:
            return f"{self.field}{self.operator}"

        return f"{self.field}{self.operator}{quote_query_value(self.value)}"
