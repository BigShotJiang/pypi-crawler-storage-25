# -----------------------------------------------------------------------------
#  Copyright (c) 2026-present Authors in AUTHORS.txt

# This file is part of zsc_py_test.

# The zettelstore python client is licensed under the latest version of the EUPL (European Union
# Public License). Please see file LICENSE.txt for your rights and obligations
# under this license.

# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2026-present  Contributors (see AUTHORS.txt)
# -----------------------------------------------------------------------------

from dataclasses import dataclass, field
import re
import shlex

from zsc_py_test.constants import (
    LENGTH_ZID,
    QUERY_DIRECTIVE_ARGUMENTS,
    QUERY_DIRECTIVE_NAMES,
    QUERY_LONGEST_OPERATORS,
    QUERY_SEARCH_MODIFIERS,
    QUERY_SEARCH_OPERATOR_CHARS,
)
from zsc_py_test.types.zettel_query.zettel_query_action_type import ZettelQueryAction
from zsc_py_test.types.zettel_query.zettel_query_clause_type import ZettelQueryClause
from zsc_py_test.types.zettel_query.zettel_query_directive_type import ZettelQueryDirective
from zsc_py_test.types.zettel_query.zettel_query_order_type import ZettelQueryOrder
from zsc_py_test.types.zettel_query.zettel_query_term_type import ZettelQueryTerm

_METADATA_KEY_RE = re.compile(r"^[A-Za-z][A-Za-z0-9-]*$")
_ZETTEL_ID_RE = re.compile(rf"^\d{{{LENGTH_ZID}}}$")


def _tokenize_query(query: str) -> list[str]:
    lexer = shlex.shlex(query, posix=True, punctuation_chars="|")
    lexer.whitespace_split = True
    lexer.commenters = ""
    return list(lexer)


def _parse_operator(text: str) -> tuple[str, str]:
    for operator in QUERY_LONGEST_OPERATORS:
        if text.startswith(operator):
            return operator, text[len(operator) :]
    return "", text


@dataclass(slots=True)
class ZettelQuery:
    seed_ids: list[str] = field(default_factory=list)
    directives: list[ZettelQueryDirective] = field(default_factory=list)
    clauses: list[ZettelQueryClause] = field(default_factory=list)
    order: ZettelQueryOrder | None = None
    random: bool = False
    pick: int | None = None
    offset: int | None = None
    limit: int | None = None
    actions: list[ZettelQueryAction] = field(default_factory=list)

    @classmethod
    def from_str(cls, query: str) -> "ZettelQuery":
        tokens = _tokenize_query(query.strip())
        query_obj = cls()

        if not tokens:
            return query_obj

        if "|" in tokens:
            pipe_index = tokens.index("|")
            search_tokens = tokens[:pipe_index]
            action_tokens = tokens[pipe_index + 1 :]
        else:
            search_tokens = tokens
            action_tokens = []

        index = 0
        while index < len(search_tokens) and _ZETTEL_ID_RE.fullmatch(
            search_tokens[index]
        ):
            query_obj.seed_ids.append(search_tokens[index])
            index += 1

        while (
            query_obj.seed_ids
            and index < len(search_tokens)
            and search_tokens[index] in QUERY_DIRECTIVE_NAMES
        ):
            directive_name = search_tokens[index]
            index += 1
            arguments: list[str] = []
            while index < len(search_tokens):
                token = search_tokens[index]
                if token == "OR" or token in QUERY_SEARCH_MODIFIERS:
                    break
                if token in QUERY_DIRECTIVE_NAMES:
                    break
                if not _is_directive_argument(directive_name, token):
                    break
                arguments.append(token)
                index += 1
            query_obj.directives.append(
                ZettelQueryDirective(name=directive_name, arguments=arguments)
            )

        current_clause = ZettelQueryClause()

        while index < len(search_tokens):
            token = search_tokens[index]

            if token == "OR":
                if current_clause.terms:
                    query_obj.clauses.append(current_clause)
                    current_clause = ZettelQueryClause()
                index += 1
                continue

            if token == "PICK":
                index += 1
                query_obj.pick = _parse_positive_int(search_tokens, index, "PICK")
                index += 1
                continue

            if token == "ORDER":
                index += 1
                reverse = False
                if index < len(search_tokens) and search_tokens[index] == "REVERSE":
                    reverse = True
                    index += 1
                if index >= len(search_tokens):
                    raise ValueError("ORDER must be followed by a metadata key.")
                query_obj.order = ZettelQueryOrder(
                    field=search_tokens[index], reverse=reverse
                )
                index += 1
                continue

            if token == "RANDOM":
                query_obj.random = True
                index += 1
                continue

            if token == "OFFSET":
                index += 1
                query_obj.offset = _parse_positive_int(search_tokens, index, "OFFSET")
                index += 1
                continue

            if token == "LIMIT":
                index += 1
                query_obj.limit = _parse_positive_int(search_tokens, index, "LIMIT")
                index += 1
                continue

            current_clause.terms.append(_parse_search_term(token))
            index += 1

        if current_clause.terms:
            query_obj.clauses.append(current_clause)

        query_obj.actions = [
            ZettelQueryAction(name=token) for token in action_tokens if token.strip()
        ]
        return query_obj

    def query_string(self) -> str:
        parts: list[str] = []

        parts.extend(self.seed_ids)
        parts.extend(directive.query_string() for directive in self.directives)

        if self.clauses:
            clause_strings = [
                clause.query_string()
                for clause in self.clauses
                if clause.query_string()
            ]
            if clause_strings:
                parts.append(" OR ".join(clause_strings))

        if self.order is not None:
            parts.append(self.order.query_string())
        elif self.random:
            parts.append("RANDOM")

        if self.pick is not None:
            parts.append(f"PICK {self.pick}")

        if self.order is not None and self.random:
            parts.append("RANDOM")

        if self.offset is not None:
            parts.append(f"OFFSET {self.offset}")

        if self.limit is not None:
            parts.append(f"LIMIT {self.limit}")

        query_string = " ".join(part for part in parts if part)

        if self.actions:
            actions = " ".join(action.query_string() for action in self.actions)
            if query_string:
                return f"{query_string} | {actions}"
            return f"| {actions}"

        return query_string

    def __str__(self) -> str:
        return self.query_string()


def _looks_like_search_term(token: str) -> bool:
    if token in {"OR", "REVERSE"} or token in QUERY_SEARCH_MODIFIERS:
        return False

    if not token:
        return False

    if token[0] in QUERY_SEARCH_OPERATOR_CHARS:
        return True

    for index, character in enumerate(token):
        if character in QUERY_SEARCH_OPERATOR_CHARS:
            key = token[:index]
            return bool(_METADATA_KEY_RE.fullmatch(key))

    return True


def _is_directive_argument(directive_name: str, token: str) -> bool:
    allowed_arguments = QUERY_DIRECTIVE_ARGUMENTS.get(directive_name)
    if allowed_arguments is None:
        return False
    return token in allowed_arguments or token.isdigit()


def _parse_positive_int(tokens: list[str], index: int, keyword: str) -> int:
    if index >= len(tokens):
        raise ValueError(f"{keyword} must be followed by a positive integer.")

    value = tokens[index]
    if not value.isdigit():
        raise ValueError(f"{keyword} must be followed by a positive integer.")

    return int(value)


def _parse_search_term(token: str) -> ZettelQueryTerm:
    first_operator_index = next(
        (
            index
            for index, character in enumerate(token)
            if character in QUERY_SEARCH_OPERATOR_CHARS
        ),
        -1,
    )

    if first_operator_index == -1:
        return ZettelQueryTerm(field=None, operator="", value=token)

    if first_operator_index > 0:
        field_candidate = token[:first_operator_index]
        if _METADATA_KEY_RE.fullmatch(field_candidate):
            operator, value = _parse_operator(token[first_operator_index:])
            if operator in {"?", "!?"}:
                return ZettelQueryTerm(
                    field=field_candidate, operator=operator, value=None
                )
            return ZettelQueryTerm(
                field=field_candidate, operator=operator, value=value
            )

    operator, value = _parse_operator(token)
    return ZettelQueryTerm(field=None, operator=operator, value=value)
