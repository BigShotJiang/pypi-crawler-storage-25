# -----------------------------------------------------------------------------
#  Copyright (c) 2026-present Authors in AUTHORS.txt

# This file is part of zsc_py_test.

# The zettelstore python client is licensed under the latest version of the EUPL (European Union
# Public License). Please see file LICENSE.txt for your rights and obligations
# under this license.

# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2026-present  Contributors (see AUTHORS.txt)
# -----------------------------------------------------------------------------

from dataclasses import dataclass, field

from zsc_py_test.types.zettel_query.zettel_query_term_type import quote_query_value


@dataclass(slots=True)
class ZettelQueryDirective:
    name: str
    arguments: list[str] = field(default_factory=list)

    def query_string(self) -> str:
        pieces = [self.name]
        pieces.extend(quote_query_value(argument) for argument in self.arguments)
        return " ".join(pieces)
