# -----------------------------------------------------------------------------
#  Copyright (c) 2026-present Authors in AUTHORS.txt

# This file is part of zsc_py_test.

# The zettelstore python client is licensed under the latest version of the EUPL (European Union
# Public License). Please see file LICENSE.txt for your rights and obligations
# under this license.

# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2026-present  Contributors (see AUTHORS.txt)
# -----------------------------------------------------------------------------

from dataclasses import dataclass

from zsc_py_test.constants import RUNTIME_CONFIGURATION_ZETTEL_ID


@dataclass(slots=True, frozen=True)
class AdministrativeData:
    major: int
    minor: int
    patch: int
    info: str
    build: str
    config_zettel_id: str = RUNTIME_CONFIGURATION_ZETTEL_ID

    def __post_init__(self) -> None:
        if not all(
            isinstance(value, int) for value in (self.major, self.minor, self.patch)
        ):
            raise ValueError(
                "Administrative response must contain integer major, minor, and patch values."
            )
        if not isinstance(self.info, str) or not isinstance(self.build, str):
            raise ValueError(
                "Administrative response must contain string info and build values."
            )
        if not isinstance(self.config_zettel_id, str):
            raise ValueError(
                "Administrative response must contain a string config zettel id value."
            )

    def to_dict(self) -> dict[str, int | str]:
        return {
            "major": self.major,
            "minor": self.minor,
            "patch": self.patch,
            "info": self.info,
            "build": self.build,
            "config_zettel_id": self.config_zettel_id,
        }
