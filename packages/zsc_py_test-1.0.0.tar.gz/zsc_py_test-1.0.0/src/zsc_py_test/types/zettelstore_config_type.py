# -----------------------------------------------------------------------------
#  Copyright (c) 2026-present Authors in AUTHORS.txt

# This file is part of zsc_py_test.

# The zettelstore python client is licensed under the latest version of the EUPL (European Union
# Public License). Please see file LICENSE.txt for your rights and obligations
# under this license.

# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2026-present  Contributors (see AUTHORS.txt)
# -----------------------------------------------------------------------------

from dataclasses import dataclass
from urllib.parse import urlparse

from zsc_py_test.constants import BASEURL, DEFAULT_TIMEOUT_CONNECT, DEFAULT_TIMEOUT_READ


@dataclass(slots=True, frozen=True)
class ZettelstoreClientConfig:
    base_url: str = BASEURL
    timeout_connect: int = DEFAULT_TIMEOUT_CONNECT
    timeout_read: int = DEFAULT_TIMEOUT_READ
    follow_redirect: bool = False

    def __post_init__(self) -> None:
        object.__setattr__(self, "base_url", _clean_base_url(self.base_url))

    @property
    def timeout(self) -> tuple[int, int]:
        return (self.timeout_connect, self.timeout_read)

    @classmethod
    def build_from_dict(
        cls, config: dict[str, str | int | bool] | None
    ) -> "ZettelstoreClientConfig":
        if config is None:
            return cls()

        return cls(
            base_url=str(config.get("base_url", BASEURL)),
            timeout_connect=int(config.get("timeout_connect", DEFAULT_TIMEOUT_CONNECT)),
            timeout_read=int(config.get("timeout_read", DEFAULT_TIMEOUT_READ)),
            follow_redirect=bool(config.get("follow_redirect", False)),
        )


def _clean_base_url(url: str) -> str:
    parsed_url = urlparse(url.strip())
    if not parsed_url.scheme or not parsed_url.hostname:
        raise ValueError(f"Base URL must include scheme and host: {url}")

    netloc = parsed_url.hostname
    if parsed_url.port is not None:
        netloc += f":{parsed_url.port}"

    return f"{parsed_url.scheme}://{netloc}"
