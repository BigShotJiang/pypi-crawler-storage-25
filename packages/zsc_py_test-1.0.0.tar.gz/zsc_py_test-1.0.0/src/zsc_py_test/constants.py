# -----------------------------------------------------------------------------
#  Copyright (c) 2026-present Authors in AUTHORS.txt

# This file is part of zsc_py_test.

# The zettelstore python client is licensed under the latest version of the EUPL (European Union
# Public License). Please see file LICENSE.txt for your rights and obligations
# under this license.

# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2026-present  Contributors (see AUTHORS.txt)
# -----------------------------------------------------------------------------

BASEURL = "http://localhost:23123"

# Consts for zettel id
MAX_ZID = 99999999999999
LENGTH_ZID = 14
TIMESTAMP_LAYOUT = "%Y%m%d%H%M%S"
RUNTIME_CONFIGURATION_ZETTEL_ID = "00000000000100"

SUPPORTEDZETTELENCODINGS = {"html", "md", "shtml", "sz", "text", "zmk", "plain", "data"}
# Zettel Parts options
PART_META = "meta"
PART_CONTENT = "content"
PART_ZETTEL = "zettel"

DEFAULT_TIMEOUT_CONNECT = 3
DEFAULT_TIMEOUT_READ = 10

# Query parsing and rendering
QUERY_SEARCH_OPERATOR_CHARS = "!~=[]:<>?"
QUERY_SEARCH_MODIFIERS = {"PICK", "ORDER", "RANDOM", "OFFSET", "LIMIT"}
QUERY_DIRECTIVE_NAMES = {
    "CONTEXT",
    "THREAD",
    "FOLGE",
    "SEQUEL",
    "IDENT",
    "ITEMS",
    "UNLINKED",
}
QUERY_DIRECTIVE_ARGUMENTS = {
    "CONTEXT": {"FULL", "BACKWARD", "FORWARD", "DIRECTED", "COST", "MAX", "MIN"},
    "THREAD": {"BACKWARD", "FORWARD", "DIRECTED"},
}
QUERY_LONGEST_OPERATORS = (
    "!?",
    "!~",
    "!=",
    "![",
    "!]",
    "!:",
    "!<",
    "!>",
    "!",
    "?",
    "~",
    "=",
    "[",
    "]",
    ":",
    "<",
    ">",
)
