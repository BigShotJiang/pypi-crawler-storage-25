# -----------------------------------------------------------------------------
#  Copyright (c) 2026-present Authors in AUTHORS.txt

# This file is part of zsc_py_test.

# The zettelstore python client is licensed under the latest version of the EUPL (European Union
# Public License). Please see file LICENSE.txt for your rights and obligations
# under this license.

# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2026-present  Contributors (see AUTHORS.txt)
# -----------------------------------------------------------------------------

from datetime import datetime, timedelta
from http import HTTPStatus
from typing import cast

from zsc_py_test.services.transport_service import TransportService
from zsc_py_test.sxparser import parse, to_python
from zsc_py_test.types import AdministrativeData, ApiMode, ZettelstoreClientConfig


class AuthService:
    def __init__(
        self,
        config: ZettelstoreClientConfig,
        transport_service: TransportService,
    ) -> None:
        self._config = config
        self._transport_service = transport_service

        self.username = ""
        self.password = ""
        self.token = ""
        self.token_type = ""
        self.expires = datetime.min

    def set_auth(self, username: str, password: str) -> None:
        if username == "" or password == "":
            raise ValueError("Username and password can not be empty.")
        self.username = username
        self.password = password
        self.token = ""
        self.token_type = ""
        self.expires = datetime.min

    def authenticate(self) -> None:
        if not self.username or not self.password:
            raise ValueError("Username and password must be set before authentication.")

        response = self._transport_service.request(
            url=f"{self._config.base_url}/{ApiMode.AUTH}",
            method="POST",
            auth=(self.username, self.password),
            requires_auth=False,
            expected_status_codes=(HTTPStatus.OK,),
        )
        token_type, token, expires_in = self._parse_auth_info(response.text)
        self.token_type = token_type
        self.token = token
        self.expires = datetime.now() + timedelta(seconds=expires_in)

    def update_token(self):
        if self.token != "" and self.expires > (datetime.now() - timedelta(minutes=-1)):
            self.renew_token()
        elif self.username and self.password and self.expires <= datetime.now():
            self.authenticate()
        else:
            return

    def renew_token(self):
        response = self._transport_service.request(
            url=f"{self._config.base_url}/{ApiMode.AUTH}",
            method="PUT",
            headers={"Authorization": f"{self.token_type} {self.token}"},
            requires_auth=False,
            expected_status_codes=(HTTPStatus.OK,),
        )
        token_type, token, expires_in = self._parse_auth_info(response.text)
        self.token_type = token_type
        self.token = token
        self.expires = datetime.now() + timedelta(seconds=expires_in)

    def get_administrative_data(self) -> dict[str, int | str]:
        response = self._transport_service.request(
            url=f"{self._config.base_url}/{ApiMode.EXEC}",
            method="GET",
            expected_status_codes=(HTTPStatus.OK,),
        )
        admin_info = to_python(parse(response.text))

        if not isinstance(admin_info, list) or len(admin_info) != 5:
            raise ValueError(
                "Administrative response must contain major, minor, patch, info, and build."
            )

        return AdministrativeData(
            major=cast(int, admin_info[0]),
            minor=cast(int, admin_info[1]),
            patch=cast(int, admin_info[2]),
            info=cast(str, admin_info[3]),
            build=cast(str, admin_info[4]),
        ).to_dict()

    def get_auth_headers(self) -> dict[str, str]:
        self.update_token()
        if not self.token:
            if not self.username or not self.password:
                return {}
            self.authenticate()

        return {"Authorization": f"{self.token_type} {self.token}"}

    def _parse_auth_info(self, response_text: str) -> tuple[str, str, int]:
        sx_obj = parse(response_text)
        auth_info = to_python(sx_obj)
        if not isinstance(auth_info, list) or len(auth_info) != 3:
            raise ValueError(
                "Authentication response must contain token type, token, and expires_in."
            )

        token_type, token, expires_in = auth_info
        if not isinstance(token_type, str) or not isinstance(token, str):
            raise ValueError(
                "Authentication response must contain string token fields."
            )
        if not isinstance(expires_in, int):
            raise ValueError(
                "Authentication response must contain an integer expires_in."
            )

        return token_type, token, expires_in
