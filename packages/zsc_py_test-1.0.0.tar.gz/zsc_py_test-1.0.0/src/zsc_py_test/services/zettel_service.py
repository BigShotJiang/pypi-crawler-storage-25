# -----------------------------------------------------------------------------
#  Copyright (c) 2026-present Authors in AUTHORS.txt
#
# This file is part of zsc_py_test.
#
# The zettelstore python client is licensed under the latest version of the EUPL (European Union
# Public License). Please see file LICENSE.txt for your rights and obligations
# under this license.
#
# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2026-present  Contributors (see AUTHORS.txt)
# -----------------------------------------------------------------------------

from http import HTTPStatus
from urllib.parse import quote

from zsc_py_test.constants import (
    PART_CONTENT,
    PART_META,
    PART_ZETTEL,
    RUNTIME_CONFIGURATION_ZETTEL_ID,
    SUPPORTEDZETTELENCODINGS,
)
from zsc_py_test.services.transport_service import TransportService
from zsc_py_test.sxparser import parse, to_python
from zsc_py_test.types import (
    ApiMode,
    ZettelEncoding,
    ZettelId,
    ZettelQuery,
    ZettelstoreClientConfig,
)
from zsc_py_test.utils import to_sz_dict_list, to_sz_zettel


def _to_id_list(value) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        return value.split()
    return []


class ZettelService:
    def __init__(
        self,
        config: ZettelstoreClientConfig,
        transport_service: TransportService,
    ) -> None:
        self._config = config
        self._transport_service = transport_service

    def get_zettel(
        self,
        zettel_id: str,
        part: str = PART_ZETTEL,
        enc: str = str(ZettelEncoding.PLAIN),
        as_object: bool = False,
        as_dict: bool = False,
    ):
        z_id = ZettelId(zettel_id)

        if enc not in SUPPORTEDZETTELENCODINGS:
            raise ValueError(
                f"{enc} is not a supported argument. Only {', '.join(str(e) for e in ZettelEncoding)}"
            )

        if part not in {PART_ZETTEL, PART_META, PART_CONTENT}:
            raise ValueError(
                f"{part} is not a supported argument. Only {PART_ZETTEL}, {PART_META} or {PART_CONTENT} are supported"
            )

        if as_object and as_dict:
            raise ValueError(
                "as_object and as_dict cannot both be True at the same time."
            )

        if as_object or as_dict:
            enc = str(ZettelEncoding.SZ)

        response = self._transport_service.request(
            url=f"{self._config.base_url}/{ApiMode.ZETTEL}/{z_id}?enc={enc}&part={part}",
            method="GET",
            expected_status_codes=(HTTPStatus.OK,),
        ).text

        if as_object:
            py_obj, part = self._parse_sz_response(response, part)
            return to_sz_zettel(py_obj, part)
        elif as_dict:
            py_obj, part = self._parse_sz_response(response, part)
            return to_sz_dict_list(py_obj, part)

        return response

    def get_zettel_object(
        self,
        zettel_id: str,
        part: str = PART_ZETTEL,
    ):
        return self.get_zettel(zettel_id, part=part, as_object=True)

    def get_zettel_dict(
        self,
        zettel_id: str,
        part: str = PART_ZETTEL,
    ):
        return self.get_zettel(zettel_id, part=part, as_dict=True)

    def get_configuration_zettel(
        self,
        part: str = PART_ZETTEL,
        enc: str = str(ZettelEncoding.PLAIN),
    ):
        return self.get_zettel(RUNTIME_CONFIGURATION_ZETTEL_ID, part=part, enc=enc)

    def create_zettel(self, metadata: dict[str, str] = dict(), body: str = ""):

        if not metadata.get("title"):
            metadata["title"] = "New Zettel"
        metadata_text = "\n".join(f"{key}: {value}" for key, value in metadata.items())
        body = f"{metadata_text}\n\n{body}" if metadata_text else body

        response = self._transport_service.request(
            url=f"{self._config.base_url}/{ApiMode.ZETTEL}",
            method="POST",
            headers={"Content-Type": "text/plain; charset=utf-8"},
            body=body,
            expected_status_codes=(HTTPStatus.CREATED,),
        )
        return response.text

    def delete_zettel(self, zettel_id: str) -> None:
        z_id = ZettelId(zettel_id)
        self._transport_service.request(
            url=f"{self._config.base_url}/{ApiMode.ZETTEL}/{z_id}",
            method="DELETE",
            expected_status_codes=(HTTPStatus.NO_CONTENT,),
        )

    def update_zettel(self, zettel_id: str, metadata: dict[str, str], body: str):
        z_id = ZettelId(zettel_id)
        metadata_text = "\n".join(f"{key}: {value}" for key, value in metadata.items())
        body = f"{metadata_text}\n\n{body}" if metadata_text else body

        self._transport_service.request(
            url=f"{self._config.base_url}/{ApiMode.ZETTEL}/{z_id}",
            method="PUT",
            headers={"Content-Type": "text/plain; charset=utf-8"},
            body=body,
            expected_status_codes=(HTTPStatus.NO_CONTENT,),
        )

    def list_zettel(self) -> str:
        response = self._transport_service.request(
            url=f"{self._config.base_url}/{ApiMode.ZETTEL}",
        )
        return response.text

    def query_zettel(self, query: ZettelQuery) -> str:
        query_string = quote(query.query_string(), safe="")
        response = self._transport_service.request(
            url=f"{self._config.base_url}/{ApiMode.ZETTEL}?q={query_string}",
            method="GET",
            expected_status_codes=(HTTPStatus.OK, HTTPStatus.NO_CONTENT),
        )
        return response.text

    def _parse_sz_response(self, response_text: str, part: str):
        sx_obj = parse(response_text.strip())
        py_obj = to_python(sx_obj)
        return py_obj, part

    def tag_zettel(self, tag: str) -> list[str]:
        normalized_tag = tag if tag.startswith("#") else f"#{tag}"
        response = self.query_zettel(ZettelQuery.from_str(f"tags:{normalized_tag}"))

        return [
            line.split(maxsplit=1)[0] for line in response.splitlines() if line.strip()
        ]

    def role_zettel(self, role: str) -> list[str]:
        response = self.query_zettel(ZettelQuery.from_str(f"role:{role}"))

        return [
            line.split(maxsplit=1)[0] for line in response.splitlines() if line.strip()
        ]

    def get_role_zettel(self, role: str):
        response = self._transport_service.request(
            url=f"{self._config.base_url}/{ApiMode.ZETTEL}?qrole={role}",
            method="GET",
            expected_status_codes=(HTTPStatus.FOUND,),
        )
        return response.text

    def get_zettel_uri(self, zettel_id):
        z_id = ZettelId(zettel_id)
        response = self._transport_service.request(
            url=f"{self._config.base_url}/{ApiMode.REF}/{z_id}",
            method="GET",
            expected_status_codes=(HTTPStatus.OK, HTTPStatus.NO_CONTENT),
        )
        return response.text

    def get_random_zettel(self, amount = 1):
        response = self.query_zettel(ZettelQuery.from_str(f"PICK {amount}"))
        return [
            line.split(maxsplit=1)[0] for line in response.splitlines() if line.strip()
        ]

    def get_zettel_links(self, zettel_id: str) -> dict:
        zettel = self.get_zettel_object(zettel_id, part=PART_META)

        reference_keys = (
            "folge",
            "forward",
            "back",
            "backward",
            "precursor",
            "predecessor",
            "sequel",
            "subordinate",
            "successor",
        )

        result: dict = {"zid": zettel_id}
        for key in reference_keys:
            result[key] = _to_id_list(zettel.get(key))

        return result
