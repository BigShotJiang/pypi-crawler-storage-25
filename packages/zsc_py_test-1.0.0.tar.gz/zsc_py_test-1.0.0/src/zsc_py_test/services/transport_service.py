# -----------------------------------------------------------------------------
#  Copyright (c) 2026-present Authors in AUTHORS.txt
#
# This file is part of zsc_py_test.
#
# The zettelstore python client is licensed under the latest version of the EUPL (European Union
# Public License). Please see file LICENSE.txt for your rights and obligations
# under this license.
#
# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2026-present  Contributors (see AUTHORS.txt)
# -----------------------------------------------------------------------------

from http import HTTPStatus
from typing import Protocol

from requests import Response, Session

from zsc_py_test.error import HttpError
from zsc_py_test.transport_adapter import TransportAdapter
from zsc_py_test.types import ZettelstoreClientConfig


class AuthHeaderProvider(Protocol):
    def get_auth_headers(self) -> dict[str, str]: ...


class TransportService:
    def __init__(
        self,
        config: ZettelstoreClientConfig,
        session: Session,
        transport_adapter: TransportAdapter,
    ) -> None:
        self._config = config
        self._session = session
        self._transport_adapter = transport_adapter
        self._auth_service: AuthHeaderProvider | None = None

    def set_auth_service(self, auth_service: AuthHeaderProvider) -> None:
        self._auth_service = auth_service

    def request(
        self,
        url: str = "",
        method: str = "GET",
        headers: dict[str, str] | None = None,
        body: str | None = None,
        auth: tuple[str, str] | None = None,
        requires_auth: bool = True,
        expected_status_codes: tuple[int, ...] = (HTTPStatus.OK,),
    ) -> Response:
        request_headers = dict(headers or {})

        if requires_auth:
            if self._auth_service is None:
                raise RuntimeError("Auth service is not configured.")
            request_headers.update(self._auth_service.get_auth_headers())

        response = self._transport_adapter.request(
            session=self._session,
            method=method,
            url=url,
            auth=auth,
            headers=request_headers or None,
            body=body,
            timeout=self._config.timeout,
            allow_redirects=self._config.follow_redirect,
        )

        if response.status_code not in expected_status_codes:
            raise HttpError(response.status_code, response.text)

        return response
