# -----------------------------------------------------------------------------
#  Copyright (c) 2026-present Authors in AUTHORS.txt

# This file is part of zsc_py_test.

# The zettelstore python client is licensed under the latest version of the EUPL (European Union
# Public License). Please see file LICENSE.txt for your rights and obligations
# under this license.

# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2026-present  Contributors (see AUTHORS.txt)
# -----------------------------------------------------------------------------


class HttpError(Exception):
    def __init__(self, statuscode: int, message: str) -> None:
        self.statuscode = statuscode
        self.message = message

    def __str__(self) -> str:
        return f"Statuscode: {self.statuscode}, Error Message: {self.message}"
