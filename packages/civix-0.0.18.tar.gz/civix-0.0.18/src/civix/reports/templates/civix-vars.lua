-- civix-vars.lua — Pandoc/Quarto Lua filter
-- Part of civix.reports.templates
--
-- Reads the `civix-defaults:` block (from _quarto.yml) and the
-- `civix:` block (from the notebook raw cell), merges them with
-- notebook values taking priority, then emits \renewcommand calls
-- into header-includes so civix-preamble.tex can use them.
--
-- Why two keys?
--   Quarto replaces (not deep-merges) custom metadata keys when
--   a notebook also defines them.  Using separate keys avoids this:
--     _quarto.yml    →  civix-defaults: { company: "Hesco", ... }
--     notebook cell  →  civix: { calc_for: "Beam B-01", ... }
--   The filter merges both, with civix: overriding civix-defaults:.

-- Map from YAML key → LaTeX command name
local field_map = {
  company    = "civixCompany",
  project    = "civixProject",
  calc_for   = "civixCalcFor",
  project_no = "civixProjectNo",
  approved   = "civixApproved",
  made_by    = "civixMadeBy",
  date       = "civixDate",
  revision   = "civixRevision",
  logo       = "civixLogo",
  subtitle   = "civixSubtitle",
  border     = "civixBorder",
  footer     = "civixFooter",
}

--- Safely stringify a Pandoc MetaValue to a plain string.
--- @param val any  Pandoc MetaValue (MetaInlines, MetaString, etc.)
--- @return string
local function meta_to_string(val)
  if val == nil then
    return ""
  end
  return pandoc.utils.stringify(val)
end

--- Escape special LaTeX characters in a string.
--- @param s string
--- @return string
local function latex_escape(s)
  s = s:gsub("\\", "\\textbackslash{}")
  s = s:gsub("&", "\\&")
  s = s:gsub("%%", "\\%%")
  s = s:gsub("%$", "\\$")
  s = s:gsub("#", "\\#")
  s = s:gsub("_", "\\_")
  s = s:gsub("{", "\\{")
  s = s:gsub("}", "\\}")
  s = s:gsub("~", "\\textasciitilde{}")
  s = s:gsub("%^", "\\textasciicircum{}")
  return s
end

function Meta(meta)
  -- ── Merge civix-defaults and civix ──────────────────────────────
  -- Start with defaults, then overlay notebook-level overrides.
  local defaults = meta["civix-defaults"] or {}
  local overrides = meta["civix"] or {}

  -- Build merged table: defaults first, then overrides win
  local merged = {}
  for yaml_key, _ in pairs(field_map) do
    -- Try override first, fall back to default
    local val = overrides[yaml_key]
    if val == nil then
      val = defaults[yaml_key]
    end
    if val ~= nil then
      merged[yaml_key] = val
    end
  end

  -- ── Emit LaTeX \renewcommand calls ─────────────────────────────
  local lines = {}

  for yaml_key, latex_cmd in pairs(field_map) do
    local val = merged[yaml_key]
    if val ~= nil then
      local str = meta_to_string(val)
      if str ~= "" then
        -- Logo paths and border values should NOT be LaTeX-escaped
        if yaml_key == "logo" or yaml_key == "border" then
          table.insert(lines, "\\renewcommand{\\" .. latex_cmd .. "}{" .. str .. "}")
        else
          table.insert(lines, "\\renewcommand{\\" .. latex_cmd .. "}{" .. latex_escape(str) .. "}")
        end
      end
    end
  end

  -- Auto-date: if date is "auto" or missing, use \today
  local date_str = meta_to_string(merged["date"])
  if date_str == "" or date_str == "auto" then
    table.insert(lines, "\\renewcommand{\\civixDate}{\\today}")
  end

  if #lines > 0 then
    local latex_block = table.concat(lines, "\n")
    local raw = pandoc.RawBlock("latex", latex_block)

    -- Append to header-includes
    if meta["header-includes"] == nil then
      meta["header-includes"] = pandoc.MetaList({raw})
    else
      meta["header-includes"]:insert(raw)
    end
  end

  return meta
end
