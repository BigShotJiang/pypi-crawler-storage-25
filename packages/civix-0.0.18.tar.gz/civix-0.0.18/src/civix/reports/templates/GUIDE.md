# Civix Calcsheet Template — Setup & Usage Guide

> **Module**: `civix.reports.templates`
> **Purpose**: Produce professional structural calculation PDFs from Jupyter notebooks
> using Quarto, with a Tekla Tedds–style header on every page.

---

## What You Get

A PDF report rendered from a `.ipynb` notebook with:

- A **header table** on every page (company, project, calc-for, made-by, date, sheet #, revision)
- An optional **company logo** (top-right of header)
- A **configurable subtitle** (default: "Calculation sheet")
- A **table of contents** on its own page (before the calculation body)
- A **bottom rule** separating content from the footer
- A **footer** with confidentiality notice (left) and page count (right)

---

## Files

These 3 files do all the work — they go in the **same folder** as your notebooks:

| File | What it does |
|---|---|
| `civix-preamble.tex` | LaTeX preamble. Defines the TikZ header table, bottom rule, and footer via `fancyhdr`. |
| `civix-vars.lua` | Pandoc Lua filter. Merges `civix-defaults:` (from `_quarto.yml`) with `civix:` (from notebook raw cell) and injects `\renewcommand` calls into LaTeX. |
| `_quarto.yml` | Project-level Quarto config. Sets paper size, margins, and shared `civix-defaults:` values. |

Source location in civix repo:

```
src/civix/reports/templates/
├── civix-preamble.tex
├── civix-vars.lua
├── _quarto.yml
├── sample-calcsheet.ipynb
└── GUIDE.md
```

---

## Prerequisites

1. **Quarto** ≥ 1.4 installed and on `PATH`
   ```bash
   quarto --version
   ```
   If missing: https://quarto.org/docs/get-started/

2. **TinyTeX** (or a full TeX Live distribution) — Quarto will prompt to install TinyTeX
   on first PDF render if no LaTeX is found. The required LaTeX packages (`fancyhdr`,
   `tikz`, `lastpage`, `etoolbox`, `graphicx`) are all standard and auto-installed by
   TinyTeX.

3. **Python ≥ 3.12** with a Jupyter kernel registered for your project:
   ```bash
   uv add ipykernel
   uv run python -m ipykernel install --user --name civix
   ```

---

## Step-by-Step Setup

### Step 1 — Create a notebook folder

Create a folder for your project's calculation notebooks:

```
my-calcs/
├── _quarto.yml              ← project defaults
├── civix-preamble.tex       ← header/footer/border LaTeX
├── civix-vars.lua           ← YAML → LaTeX bridge
├── logo.png                 ← optional: your company logo
├── beam-B01.ipynb
├── column-C03.ipynb
└── footing-F02.ipynb
```

### Step 2 — Copy the 3 template files

Copy from the civix repo:

```bash
cp src/civix/reports/templates/civix-preamble.tex  my-calcs/
cp src/civix/reports/templates/civix-vars.lua      my-calcs/
cp src/civix/reports/templates/_quarto.yml          my-calcs/
```

### Step 3 — Edit `_quarto.yml` (project-wide defaults)

Open `_quarto.yml` and fill in your project-wide defaults under **`civix-defaults:`**:

```yaml
project:
  type: default

format:
  pdf:
    documentclass: article
    papersize: a4
    toc: true
    geometry:
      - left=20mm
      - right=20mm
      - top=45mm
      - bottom=25mm
    include-in-header:
      - civix-preamble.tex
    filters:
      - civix-vars.lua

civix-defaults:
  company: "Hesco"
  project: "Red Sea"
  calc_for: ""
  project_no: "C1680"
  approved: "MAT"
  made_by: "MAT"
  date: "auto"
  revision: "0"
  logo: "Logo.png"
  subtitle: "Calculation sheet"
  border: "thick"
  footer: "CONFIDENTIAL — For internal use only"
```

> **IMPORTANT**: Use `civix-defaults:` (not `civix:`) in `_quarto.yml`.
> This prevents Quarto from replacing the entire block when a notebook
> also defines `civix:`. The Lua filter merges both automatically.

### Step 4 — Add a raw YAML cell to each notebook

In Jupyter (or VS Code), add a **Raw** cell as the **very first cell** of your notebook.

> **Cell type must be Raw**, not Code or Markdown.
> In JupyterLab: click the cell type dropdown → Raw.

Only include the fields you want to **override** for this specific notebook:

```yaml
---
civix:
  calc_for: "Beam B-01 Flexure Check"
  date: "2026-04-02"
---
```

The Lua filter merges this with `civix-defaults:` from `_quarto.yml`.
Fields in the raw cell override the defaults; everything else is inherited.

> **Do NOT repeat the `format:` block** in the raw cell.
> It is already defined in `_quarto.yml` and duplicating it can cause
> unexpected behavior.

### Step 5 — Write your calculation

Below the raw cell, write your calculation as normal Jupyter notebook cells
(Markdown headings, Code cells with Python, LaTeX equations, plots, etc.).

> **Tip**: Use `##` headings (not `#`) for section titles. A single `#`
> heading may trigger Quarto's title page rendering, which competes
> with the header table.

### Step 6 — Render to PDF

From the terminal, in your notebook folder:

```bash
quarto render beam-B01.ipynb --to pdf
```

This produces `beam-B01.pdf` in the same folder.

Render all notebooks at once:

```bash
quarto render *.ipynb --to pdf
```

---

## How the YAML Merge Works

```
┌──────────────────────────────────┐
│  _quarto.yml                     │
│  civix-defaults:                 │
│    company: "Hesco"              │  ← shared defaults
│    project: "Red Sea"            │
│    made_by: "MAT"                │
│    ...                           │
└───────────────┬──────────────────┘
                │
                │  Lua filter merges
                │
┌───────────────▼──────────────────┐
│  notebook raw cell               │
│  civix:                          │
│    calc_for: "Beam B-01"         │  ← per-notebook overrides
│    date: "2026-04-02"            │
└───────────────┬──────────────────┘
                │
                ▼
┌──────────────────────────────────┐
│  Merged result                   │
│    company:  "Hesco"        (default)
│    project:  "Red Sea"      (default)
│    made_by:  "MAT"          (default)
│    calc_for: "Beam B-01"    (override)
│    date:     "2026-04-02"   (override)
│    ...                           │
└──────────────────────────────────┘
```

---

## Configuration Reference

All fields below can go in either `civix-defaults:` (_quarto.yml) or `civix:` (raw cell).

| Field | Default | Description |
|---|---|---|
| `company` | `""` | Company name (centered, bold, header row 1) |
| `project` | `""` | Project name |
| `calc_for` | `""` | What this calculation covers |
| `project_no` | `""` | Project number / code |
| `approved` | `""` | Approver name or initials |
| `made_by` | `""` | Author name or initials |
| `date` | `"auto"` | `"auto"` = LaTeX `\today`, or a fixed string like `"2026-04-02"` |
| `revision` | `"0"` | Revision number |
| `logo` | `""` | Path to logo image relative to the notebook folder |
| `subtitle` | `"Calculation sheet"` | Subtitle row text |
| `border` | `"thick"` | Bottom rule weight: `"thick"` (1.5pt), `"thin"` (0.6pt), `"none"` |
| `footer` | `""` | Footer text (left-aligned, italic) |

---

## Fine-Tuning (if needed)

All layout values live in `civix-preamble.tex`:

| What to adjust | Where | How |
|---|---|---|
| Header table row heights | `\def\CompH{14}`, `\def\SubH{5}`, `\def\RH{6}` | Values in mm |
| Column widths | `\def\xB{24.5}` ... `\def\xF{151.1}` | x-positions in mm |
| Table of contents | `toc: true` in `_quarto.yml` under `format: pdf:` | Remove to disable TOC |
| Footer vertical position | `\setlength{\footskip}{11mm}` | Decrease = raise footer |
| Bottom rule position | `12mm` in `\civixPageBorder` shift | Increase = raise the line |
| Top margin / head spacing | `\setlength{\topmargin}{-18mm}` | Adjust if header clips |
| Outer border line weight | `\civixOuterRule` in `\civixApplyBorder` | Change pt values |
| Inner grid line weight | `\civixInnerRule` in `\civixApplyBorder` | Change pt values |

---

## Troubleshooting

**Page 1 has no header / shows a title instead**
→ The preamble overrides LaTeX's `plain` page style, so the header appears on all
pages including page 1. If you still see a title, check for a `title:` key in your
raw cell or `_quarto.yml` — remove it. Also avoid using a single `#` heading as the
first markdown cell (Quarto may interpret it as a document title).

**Some header fields are blank**
→ Check that `_quarto.yml` uses `civix-defaults:` (not `civix:`).
If both files use `civix:`, Quarto replaces the entire block instead of merging.

**"civix-preamble.tex not found"**
→ Make sure `civix-preamble.tex` is in the same folder as your notebook.

**Logo doesn't appear**
→ Verify the `logo:` path is relative to the notebook folder. Supported: PNG, JPG, PDF.

**Quarto validation error about `title: false`**
→ Remove any `title: false` line from `_quarto.yml`. Quarto ≥ 1.8 requires title
to be a string, not a boolean.

**"LaTeX Error: Too many unprocessed floats"**
→ Add `\clearpage` between large sections (general LaTeX issue).
