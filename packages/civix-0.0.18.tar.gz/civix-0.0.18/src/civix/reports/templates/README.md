# civix.reports.templates — Structural Calculation Sheet

Quarto + LaTeX templates that produce Tekla Tedds–style calculation sheet PDFs
from Jupyter notebooks, with a professional header table on every page.

## Files

| File | Purpose |
|---|---|
| `civix-preamble.tex` | LaTeX preamble: TikZ header table, bottom rule, footer via `fancyhdr` |
| `civix-vars.lua` | Lua filter: merges `civix-defaults:` + `civix:` YAML → LaTeX commands |
| `_quarto.yml` | Project-level Quarto config with shared header defaults |
| `sample-calcsheet.ipynb` | Working example notebook |
| `GUIDE.md` | Comprehensive setup & usage manual |

## Quick Start

### 1. Copy templates to your notebook folder

```
my-calcs/
├── _quarto.yml              ← project defaults (civix-defaults:)
├── civix-preamble.tex       ← header/footer LaTeX
├── civix-vars.lua           ← YAML → LaTeX bridge
├── logo.png                 ← your company logo (optional)
├── beam-B01.ipynb
└── column-C03.ipynb
```

### 2. Edit `_quarto.yml` with your project defaults

Use **`civix-defaults:`** (not `civix:`) for shared values:

```yaml
project:
  type: default

format:
  pdf:
    documentclass: article
    papersize: a4
    toc: true
    geometry:
      - left=20mm
      - right=20mm
      - top=45mm
      - bottom=25mm
    include-in-header:
      - civix-preamble.tex
    filters:
      - civix-vars.lua

civix-defaults:
  company: "Hesco"
  project: "Red Sea"
  project_no: "C1680"
  approved: "MAT"
  made_by: "MAT"
  date: "auto"
  logo: "Logo.png"
  border: "thick"
  footer: "CONFIDENTIAL — For internal use only"
```

### 3. Add a raw YAML cell at the top of each notebook

In Jupyter, insert a **Raw** cell (not Code, not Markdown) as the very first cell.
Only include fields you want to **override** for this notebook:

```yaml
---
civix:
  calc_for: "Beam B-01 Flexure Check"
  date: "2026-04-02"
---
```

The Lua filter merges `civix-defaults:` from `_quarto.yml` with `civix:` from
the notebook, with notebook values taking priority.

> **Do NOT repeat the `format:` block in the raw cell** — it is already in `_quarto.yml`.

### 4. Render

```bash
quarto render beam-B01.ipynb --to pdf
```

## Configuration Reference

Fields can go in `civix-defaults:` (`_quarto.yml`) or `civix:` (raw cell).

| Field | Default | Description |
|---|---|---|
| `company` | `""` | Company name (centered, bold, header row 1) |
| `project` | `""` | Project name |
| `calc_for` | `""` | What this calculation covers |
| `project_no` | `""` | Project number / code |
| `approved` | `""` | Approver name or initials |
| `made_by` | `""` | Author name or initials |
| `date` | `"auto"` | `"auto"` = LaTeX `\today`, or fixed like `"2026-04-02"` |
| `revision` | `"0"` | Revision number |
| `logo` | `""` | Path to logo image (relative to notebook folder) |
| `subtitle` | `"Calculation sheet"` | Subtitle row text |
| `border` | `"thick"` | Bottom rule: `"thick"` / `"thin"` / `"none"` |
| `footer` | `""` | Footer text (left-aligned, italic) |

## Features

- Header table on **every page** (including first page and TOC page)
- Table of contents with automatic page break before content
- Configurable company logo (top-right)
- Auto-incrementing sheet (page) number
- Configurable bottom rule weight
- Footer with confidentiality notice and page count

## Requirements

- **Quarto** ≥ 1.4
- **LaTeX** (TinyTeX or TeX Live) — packages `fancyhdr`, `tikz`, `lastpage`,
  `etoolbox`, `graphicx` are all standard
- **Python** ≥ 3.12 with a Jupyter kernel

## Documentation

See **[GUIDE.md](GUIDE.md)** for the full step-by-step setup manual, architecture
overview, fine-tuning reference, and troubleshooting.
