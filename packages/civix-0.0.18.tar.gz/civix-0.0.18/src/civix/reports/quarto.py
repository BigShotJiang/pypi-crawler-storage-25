
"""Quarto report helpers.

Thin wrapper around the `quarto` CLI.
"""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

from ..core.errors import ReportError

def render_report(src: str | Path, fmt: str = "pdf") -> Path:
    """Render a .ipynb or .qmd to the desired format using Quarto CLI.

    Args:
        src: source file
        fmt: output format (e.g., "pdf", "html", "docx")
    Returns:
        Path of rendered artifact.
    """
    if shutil.which("quarto") is None:  # pragma: no cover
        raise ReportError("Quarto CLI not found. See https://quarto.org to install.")
    src = Path(src)
    cmd = ["quarto", "render", str(src), "--to", fmt]
    try:
        subprocess.check_call(cmd)
    except subprocess.CalledProcessError as exc:  # pragma: no cover
        raise ReportError(f"Quarto render failed: {exc}") from exc
    # Quarto writes next to source by default
    # We return the most likely output path (heuristic)
    stem = src.with_suffix("")
    out = stem.with_suffix("." + fmt)
    return out
