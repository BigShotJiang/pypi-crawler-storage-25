
"""Interactive database table helpers."""
from __future__ import annotations

import numpy as np

from ..core.errors import ETABSError

def db_get(sap_model, table: str) -> np.ndarray:
    """Fetch a table for display as a NumPy array of strings."""
    try:
        ret, csv = sap_model.DatabaseTables.GetTableForDisplayCSVString(table)
        if ret != 0:
            raise ETABSError(f"GetTableForDisplayCSVString failed (ret={ret})")
        # simple CSV split (ETABS returns commas and newlines)
        rows = [line.split(',') for line in csv.strip().splitlines()]
        return np.array(rows, dtype=object)
    except Exception as exc:  # pragma: no cover
        raise ETABSError(str(exc)) from exc

def db_apply(sap_model) -> None:
    """Apply edited tables queued in the model."""
    try:
        ret = sap_model.DatabaseTables.ApplyEditedTables()
        if ret != 0:
            raise ETABSError(f"ApplyEditedTables failed (ret={ret})")
    except Exception as exc:  # pragma: no cover
        raise ETABSError(str(exc)) from exc
