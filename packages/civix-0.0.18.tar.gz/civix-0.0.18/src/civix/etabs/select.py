
"""Selection/read helpers for ETABS."""
from __future__ import annotations

from ..core.errors import ETABSError

def get_selected_frames(sap_model) -> list[str]:
    """Return names of selected frame objects."""
    try:
        _, count, names = sap_model.SelectObj.GetSelected("Frame", 0, [""], [""])
        return list(names)  # type: ignore[return-value]
    except Exception as exc:  # pragma: no cover
        raise ETABSError(str(exc)) from exc
