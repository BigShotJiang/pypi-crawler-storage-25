
"""ETABS session management via pythonnet and ETABS .NET API.

The API shipped with ETABS v22+ is a .NET Standard 2.0 AnyCPU DLL named ``ETABSv1.dll``.
This module initializes pythonnet with CoreCLR and then loads ETABS API to create/attach
a session. See ETABS docs for CreateObjectProgID/GetObject patterns.
"""
from __future__ import annotations

from dataclasses import dataclass

from ..core.errors import ETABSError, MissingDependencyError
from ..core.logging import get_logger

LOG = get_logger(__name__)

_SINGLETON = None

@dataclass(slots=True)
class EtabsHandles:
    """Container to hold references to OAPI and SapModel."""
    etabs_lib: object
    oapi: object
    sap_model: object

class EtabsSession:
    """Singleton + context manager to hold an ETABS connection.

    Example:
        >>> with EtabsSession(attach=False) as s:
        ...     sm = s.handles.sap_model
        ...     # do work
    """

    def __init__(self, attach: bool = False,auto_exit:bool = False ,dll_path:str|None = None, program_path: str | None = None,
                 prog_id: str = "CSI.ETABS.API.ETABSObject") -> None:
        self.attach = attach
        self.auto_exit = auto_exit
        self.dll_path = dll_path
        self.program_path = program_path
        self.prog_id = prog_id
        self.handles: EtabsHandles | None = None

    # -- context manager -------------------------------------------------
    def __enter__(self) -> EtabsSession:
        self.connect()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        try:
            self.disconnect()
        except Exception as ex:  # pragma: no cover - defensive
            LOG.exception("Failed to disconnect ETABS cleanly: {}", ex)

    # -- lifecycle -------------------------------------------------------
    def connect(self) -> None:
        """Create or attach to an ETABS OAPI and store SapModel handle."""
        global _SINGLETON
        if _SINGLETON is not None:
            # Prevent multiple live sessions
            raise ETABSError("An EtabsSession is already active.")

        try:
            try:
                from pythonnet import load  # type: ignore
                load("coreclr")  # prefer CoreCLR runtime
            except Exception as exc:
                raise MissingDependencyError(
                    "pythonnet is required for ETABS automation") from exc

            import clr  # type: ignore
            # ETABSv1.DLL should be in PATH or registered by ETABS installer
            # Users may also add reference by absolute path if needed.
            # We rely on Helper() to start/attach.
            clr.AddReference(self.dll_path)  # ty:ignore[unresolved-attribute]
            import ETABSv1 as etabs_lib  # type: ignore

            # create API helper object
            helper = etabs_lib.cHelper(etabs_lib.Helper())

            if self.attach:
                oapi = etabs_lib.cOAPI(helper.GetObject(self.prog_id))
            else:
                if self.program_path:
                    oapi = etabs_lib.cOAPI(helper.CreateObject(self.program_path))
                else:
                    oapi = etabs_lib.cOAPI(helper.CreateObjectProgID(self.prog_id))
                oapi.ApplicationStart()
            sap_model = etabs_lib.cSapModel(oapi.SapModel)
            self.handles = EtabsHandles(etabs_lib=etabs_lib,oapi=oapi, sap_model=sap_model)
            _SINGLETON = self
            LOG.info("ETABS session established.")
        except MissingDependencyError:
            raise
        except Exception as exc:  # pragma: no cover
            LOG.exception("Failed to start/attach ETABS: {}", exc)
            raise ETABSError(str(exc)) from exc

    def disconnect(self) -> None:
        """Exit ETABS application and clear handles."""
        global _SINGLETON
        if self.handles is None:
            return

        try:
            if self.auto_exit:
                self.handles.oapi.ApplicationExit(False)  # ty:ignore[unresolved-attribute]
        except Exception as exc:  # pragma: no cover
            LOG.warning("ApplicationExit raised: {}", exc)
        finally:
            self.handles = None
            _SINGLETON = None
            LOG.info("ETABS session closed.")
