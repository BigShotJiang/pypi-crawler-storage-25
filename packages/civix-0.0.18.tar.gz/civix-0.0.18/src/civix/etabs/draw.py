
"""Functional drawing helpers for ETABS.

These functions accept ``EtabsHandles`` for consistent access to the OAPI.
"""
from __future__ import annotations

from typing import Tuple

from ..core.errors import ETABSError
from .session import EtabsHandles


def add_frame_by_coord(
        handles: EtabsHandles,
        p1: Tuple[float, float, float],
        p2: Tuple[float, float, float],
        frame_user_name: str = '',
        prop_name: str = 'Default',
        ) -> str:
    """Add a frame object between two points and assign a section property. (Global Coordinates System)"""
    try:
        coordinate_system = 'Global'
        frame_name = ''
        frame_obj = handles.etabs_lib.cFrameObj(handles.sap_model.FrameObj)  # ty:ignore[unresolved-attribute]
        [ret, frame_name] = frame_obj.AddByCoord(*p1, *p2, frame_name, prop_name,
                                                 frame_user_name, coordinate_system)
        if ret != 0:
            raise ETABSError(f"Failed to add frame object '{frame_user_name}' (ret={ret})")
        return frame_name
    except ETABSError:
        raise
    except Exception as exc:
        raise ETABSError(str(exc)) from exc