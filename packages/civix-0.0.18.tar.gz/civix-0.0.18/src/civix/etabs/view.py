
"""ETABS Views."""
from __future__ import annotations

from ..core.errors import ETABSError
from .session import EtabsHandles


def refresh_view(handles: EtabsHandles) -> None:
    """Refresh the ETABS view and reset zoom."""
    try:
        view = handles.etabs_lib.cView(handles.sap_model.View)  # ty:ignore[unresolved-attribute]
        ret = view.RefreshView(0, False)
        if ret != 0:
            raise ETABSError(f"RefreshView failed (ret={ret})")
    except ETABSError:
        raise
    except Exception as exc:  # pragma: no cover
        raise ETABSError(str(exc)) from exc