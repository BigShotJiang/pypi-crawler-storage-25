
"""Change unit system for ETABS."""
from __future__ import annotations

from ..core.errors import ETABSError
from .session import EtabsHandles

# Subset of ETABS eUnits enum codes. Extend as needed.
_UNITS = dict(kN_m_C=6, N_mm_C=9)
_UNITS_REVERSE = {v: k for k, v in _UNITS.items()}


def set_unit(handles: EtabsHandles, unit: str) -> None:
    code = _UNITS.get(unit)
    if code is None:
        raise ETABSError(f"Unknown unit '{unit}'. Available: {list(_UNITS.keys())}")
    ret = handles.sap_model.SetPresentUnits(handles.etabs_lib.eUnits(code))  # ty:ignore[unresolved-attribute]
    if ret != 0:
        raise ETABSError(f"SetPresentUnits failed for '{unit}' (ret={ret})")


def get_unit(handles: EtabsHandles) -> str:
    raw = handles.sap_model.GetPresentUnits()  # ty:ignore[unresolved-attribute]
    return _UNITS_REVERSE.get(int(raw), str(raw))