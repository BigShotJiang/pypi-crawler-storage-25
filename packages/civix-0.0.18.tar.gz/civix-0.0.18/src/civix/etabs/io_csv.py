
"""NumPy CSV helpers."""
from __future__ import annotations

from pathlib import Path

import numpy as np

def save_csv(path: str | Path, data: np.ndarray, fmt: str = "%s") -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    np.savetxt(p, data, fmt=fmt, delimiter=",")
    return p

def load_csv(path: str | Path, dtype=object) -> np.ndarray:
    p = Path(path)
    return np.genfromtxt(p, dtype=dtype, delimiter=",", autostrip=True)
