
"""Grasshopper-friendly snippets.

Functions are pure Python/NumPy and do not depend on Rhino/Grasshopper to import.
"""
from __future__ import annotations

from collections.abc import Callable

import numpy as np


def rk4(f: Callable[[float, np.ndarray], np.ndarray], t0: float, y0: np.ndarray,
        h: float, steps: int) -> np.ndarray:
    """Runge-Kutta 4th order integrator.

    Args:
        f: dy/dt function
        t0: initial time
        y0: initial state vector
        h: step size
        steps: number of steps
    Returns:
        Array of shape (steps+1, len(y0)) with the trajectory.
    """
    y = np.zeros((steps+1, y0.size), dtype=float)
    y[0] = y0
    t = t0
    for n in range(steps):
        k1 = f(t, y[n])
        k2 = f(t + 0.5*h, y[n] + 0.5*h*k1)
        k3 = f(t + 0.5*h, y[n] + 0.5*h*k2)
        k4 = f(t + h, y[n] + h*k3)
        y[n+1] = y[n] + (h/6.0)*(k1 + 2*k2 + 2*k3 + k4)
        t += h
    return y

def gh_tree_to_list(tree) -> list:
    """Convert a Grasshopper DataTree to nested Python lists.

    If *tree* does not look like a GH tree, it is returned as-is.
    """
    try:
        # Minimal duck-typing to avoid importing ghpythonlib
        items = []
        for path in tree.Paths:  # type: ignore[attr-defined]
            items.append([x for x in tree.Branch(path)])  # type: ignore[attr-defined]
        return items
    except Exception:
        return list(tree) if hasattr(tree, '__iter__') else [tree]
