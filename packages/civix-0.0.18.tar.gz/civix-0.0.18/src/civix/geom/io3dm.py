
"""Write scenes to .3dm files using rhino3dm (optional)."""
from __future__ import annotations

from pathlib import Path

from ..core.errors import GeometryError, MissingDependencyError

try:
    import rhino3dm  # type: ignore
except Exception:  # pragma: no cover
    rhino3dm = None  # type: ignore

def write_3dm(path: str | Path, objects: list) -> Path:
    if rhino3dm is None:  # pragma: no cover
        raise MissingDependencyError("rhino3dm is required to write .3dm files")
    try:
        model = rhino3dm.File3dm()
        for obj in objects:
            model.Objects.Add(obj)
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        model.Write(str(p), 8)
        return p
    except Exception as exc:  # pragma: no cover
        raise GeometryError(str(exc)) from exc
