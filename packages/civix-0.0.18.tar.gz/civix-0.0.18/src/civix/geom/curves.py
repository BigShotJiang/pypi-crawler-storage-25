
"""Create curves using rhino3dm (optional)."""
from __future__ import annotations

from typing import Tuple

from ..core.errors import GeometryError, MissingDependencyError

try:
    import rhino3dm  # type: ignore
except Exception:  # pragma: no cover - optional
    rhino3dm = None  # type: ignore

def make_line(p0: Tuple[float, float, float], p1: Tuple[float, float, float]):
    if rhino3dm is None:  # pragma: no cover
        raise MissingDependencyError("rhino3dm is required for geometry helpers")
    try:
        return rhino3dm.LineCurve(rhino3dm.Point3d(*p0), rhino3dm.Point3d(*p1))
    except Exception as exc:  # pragma: no cover
        raise GeometryError(str(exc)) from exc
