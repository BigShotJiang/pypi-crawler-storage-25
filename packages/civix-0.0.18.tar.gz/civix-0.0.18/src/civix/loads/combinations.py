
"""Load combination generator.

Define load patterns with categories and generate combos by rules.
"""
from __future__ import annotations

from dataclasses import dataclass
from itertools import product
from typing import Dict, Iterable, List

@dataclass(slots=True)
class LoadPattern:
    name: str
    category: str

@dataclass(slots=True)
class LoadCombo:
    name: str
    factors: Dict[str, float]

DEFAULT_FACTORS = {
    "Dead": 1.2,
    "SuperDead": 1.2,
    "Live": 1.6,
    "Wind": 0.8,
}

def generate_basic(patterns: Dict[str, str]) -> List[LoadCombo]:
    """Generate a small set of ULS combos for Dead+Live±Wind.

    Args:
        patterns: mapping from pattern name to category (e.g., {"SW":"Dead", "L1":"Live", "W1":"Wind"}).
    """
    by_cat: Dict[str, List[str]] = {}
    for p, cat in patterns.items():
        by_cat.setdefault(cat, []).append(p)

    dead = by_cat.get("Dead", []) + by_cat.get("SuperDead", [])
    live = by_cat.get("Live", [])
    wind = by_cat.get("Wind", [])

    combos: List[LoadCombo] = []
    # Dead + Live
    for L in (live or [None]):
        factors: Dict[str, float] = {}
        for D in dead:
            factors[D] = DEFAULT_FACTORS.get(patterns[D], 1.2)
        if L:
            factors[L] = DEFAULT_FACTORS.get("Live", 1.6)
        combos.append(LoadCombo(name=f"ULS_D+L{'' if not L else '_'+L}", factors=factors))

    # ±Wind
    for W in (wind or [None]):
        if not W:
            continue
        for sign in (+1, -1):
            factors: Dict[str, float] = {}
            for D in dead:
                factors[D] = DEFAULT_FACTORS.get(patterns[D], 1.2)
            factors[W] = DEFAULT_FACTORS.get("Wind", 0.8) * sign
            combos.append(LoadCombo(name=f"ULS_D+{('+' if sign>0 else '-')}{W}", factors=factors))
    return combos
