
"""IFC IO helpers using IfcOpenShell.

Optional dependency: ``ifcopenshell``.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from ..core.errors import IFCError, MissingDependencyError
from ..core.logging import get_logger

LOG = get_logger(__name__)

try:  # optional import
    import ifcopenshell  # type: ignore
except Exception:  # pragma: no cover - optional
    ifcopenshell = None  # type: ignore

def open_ifc(path: str | Path) -> Any:
    """Open an IFC file and return the IfcOpenShell model.

    Raises:
        MissingDependencyError: if ifcopenshell is not installed.
        IFCError: on IO or parsing errors.
    """
    if ifcopenshell is None:  # pragma: no cover - optional
        raise MissingDependencyError(
            "ifcopenshell is required: install with `pip install ifcopenshell`.")
    try:
        p = Path(path)
        if not p.exists():
            raise IFCError(f"IFC file not found: {p}")
        LOG.info("Opening IFC: {}", p)
        model = ifcopenshell.open(str(p))
        return model
    except Exception as exc:  # pragma: no cover - optional
        LOG.exception("Failed to open IFC: {}", exc)
        raise IFCError(str(exc)) from exc

def save_ifc(model: Any, path: str | Path) -> Path:
    """Save the IFC model to *path*.

    Args:
        model: IfcOpenShell file object.
        path: Output path.
    """
    if ifcopenshell is None:  # pragma: no cover - optional
        raise MissingDependencyError(
            "ifcopenshell is required: install with `pip install ifcopenshell`.")
    try:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        model.write(str(p))
        LOG.info("Saved IFC: {}", p)
        return p
    except Exception as exc:  # pragma: no cover
        LOG.exception("Failed to save IFC: {}", exc)
        raise IFCError(str(exc)) from exc
