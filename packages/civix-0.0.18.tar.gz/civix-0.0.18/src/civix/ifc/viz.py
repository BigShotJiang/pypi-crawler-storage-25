
"""Plotly Mesh3d notebook visualization."""
from __future__ import annotations

from typing import Iterable

import numpy as np

from ..core.logging import get_logger
from .geometry import Mesh

import plotly.graph_objects as go

LOG = get_logger(__name__)

def show_meshes_in_notebook(meshes: Iterable[Mesh]) -> None:
    """Display meshes in a Jupyter notebook using Plotly Mesh3d.

    Args:
        meshes: Iterable of :class:`Mesh`.
    """
    fig = go.Figure()
    for m in meshes:
        x, y, z = m.vertices.T
        i, j, k = m.faces.T
        fig.add_trace(go.Mesh3d(x=x, y=y, z=z, i=i, j=j, k=k, opacity=0.5))
    fig.update_layout(scene_aspectmode="data")
    fig.show()
