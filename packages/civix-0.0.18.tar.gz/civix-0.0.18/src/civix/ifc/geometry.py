
"""Utility adapters between IFC and simple mesh structures.

This module intentionally implements a minimal path: for display/preview we triangulate 
faces if needed and return a simple mesh dict ``{"vertices": np.ndarray (N,3), "faces": np.ndarray (M,3)}``.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from ..core.errors import IFCError

@dataclass(slots=True)
class Mesh:
    """Simple mesh container."""
    vertices: np.ndarray  # (N, 3)
    faces: np.ndarray     # (M, 3) indices

def as_mesh(vertices: np.ndarray, faces: np.ndarray) -> Mesh:
    """Create a :class:`Mesh` with validation."""
    if vertices.ndim != 2 or vertices.shape[1] != 3:
        raise IFCError("vertices must be (N,3)")
    if faces.ndim != 2 or faces.shape[1] != 3:
        raise IFCError("faces must be (M,3)")
    return Mesh(vertices=np.asarray(vertices, float), faces=np.asarray(faces, int))
