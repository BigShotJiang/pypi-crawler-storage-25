
"""Extraction helpers for common IFC queries."""
from __future__ import annotations

from typing import Any, Iterable, List

from ..core.errors import MissingDependencyError
from ..core.logging import get_logger

LOG = get_logger(__name__)

try:  # optional import
    import ifcopenshell  # type: ignore
    import ifcopenshell.util.element as ifc_element  # type: ignore
except Exception:  # pragma: no cover - optional
    ifcopenshell = None  # type: ignore
    ifc_element = None  # type: ignore

def by_type(model: Any, type_name: str) -> List[Any]:
    """Return all entities of the given IFC type name."""
    if ifcopenshell is None:  # pragma: no cover
        raise MissingDependencyError("ifcopenshell not installed")
    return list(model.by_type(type_name))

def get_psets(entity: Any) -> dict:
    """Return properties and quantities for an entity.

    Returns a nested dict like ``{"Pset_WallCommon": {"FireRating": "2HR", ...}}``
    """
    if ifc_element is None:  # pragma: no cover
        raise MissingDependencyError("ifcopenshell.util not available")
    return ifc_element.get_psets(entity)
