"""civix package (v0.1).

Structural engineering tools for Python notebooks and scripts.
"""

import numpy


def hello(n: int) -> str:
    """Greet the sum from 0 to n (exclusive end)."""
    sum_n = numpy.arange(n).sum()
    return f"Hello {sum_n}!"


__all__ = [
    "__version__",
]

__version__ = "0.0.17"