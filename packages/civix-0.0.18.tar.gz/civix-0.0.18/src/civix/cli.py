
"""Command line entrypoints (scripts declared in pyproject).

- ``civix-health``: quick environment & dependency check.
- ``civix-init-config``: write a YAML config scaffold.
"""
from __future__ import annotations

import importlib
import os
import platform
import sys
from pathlib import Path
from typing import Optional

import numpy as np

from . import __version__
from .core.config import load_config, write_default_config
from .core.logging import get_logger

LOG = get_logger(__name__)

def _optional_version(modname: str) -> Optional[str]:
    try:
        mod = importlib.import_module(modname)
        ver = getattr(mod, "__version__", None)
        if ver is None and hasattr(mod, "version"):
            ver = getattr(mod, "version")  # type: ignore[attr-defined]
        return str(ver) if ver else "installed"
    except Exception:
        return None

def health_cmd() -> None:
    """Health check command.

    Prints versions and basic environment diagnostics. Non-fatal warnings for optional deps.
    """
    try:
        print("civix v" + __version__)
        print(f"Python: {platform.python_version()} ({sys.executable})")
        print(f"Platform: {platform.platform()}")
        # Core deps
        print(f"numpy: {np.__version__}")

        # Optional deps
        for name in ["loguru", "pyyaml", "ifcopenshell", "pythonnet", "rhino3dm", "ruff"]:
            ver = _optional_version(name)
            print(f"{name}: {ver or 'not installed'}")

        # Try load config if present
        for guess in ("civix.yaml", "./config/civix.yaml"):
            p = Path(guess)
            if p.exists():
                cfg = load_config(p)
                print(f"Loaded config: {p.resolve()}")
                logs_dir = cfg.get("paths", "logs_dir", default="./logs")
                print(f"logs_dir: {logs_dir}")
                break
        print("Health check completed.")
    except Exception as exc:  # pragma: no cover - defensive
        LOG.exception("Health check failed: {}", exc)
        raise SystemExit(1) from exc

def init_config_cmd() -> None:
    """Initialize a default YAML config in the current directory.

    If ``civix.yaml`` exists, it will be overwritten.
    """
    try:
        target = Path("civix.yaml")
        write_default_config(target)
        print(f"Wrote {target.resolve()}")
    except Exception as exc:  # pragma: no cover
        LOG.exception("Init-config failed: {}", exc)
        raise SystemExit(1) from exc
