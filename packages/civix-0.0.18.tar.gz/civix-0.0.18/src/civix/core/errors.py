
"""Custom exception hierarchy for civix.

All public functions should raise these errors with helpful messages.
"""
from __future__ import annotations

class CivixError(Exception):
    """Base error for civix."""

class ConfigError(CivixError):
    """Configuration-related error."""

class MissingDependencyError(CivixError):
    """Raised when an optional dependency is required but not installed."""

class IFCError(CivixError):
    """IFC read/write or geometry error."""

class ETABSError(CivixError):
    """ETABS session or API error."""

class ReportError(CivixError):
    """Quarto/report rendering error."""

class GeometryError(CivixError):
    """rhino3dm geometry error."""
