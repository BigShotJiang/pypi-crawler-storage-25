
"""YAML configuration loader/saver for civix.

The schema is intentionally lightweight. Missing keys are tolerated with sensible defaults.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from .errors import ConfigError

DEFAULT_CONFIG = {
    "version": 0,
    "etabs": {
        "dll_path": r"C:/Program Files/Computers and Structures/ETABS 23/ETABSv1.dll",
        "program_path": r"C:/Program Files/Computers and Structures/ETABS 23/ETABS.exe",
        "prefer_attach": True,
    },
    "paths": {
        "logs_dir": "./logs",
        "temp_dir": "./.civix_tmp",
    },
    "ifc": {
        "default_schema": "IFC4",
    },
    "reports": {
        "default_format": "pdf",
        "template": "basic-structural-report.qmd",
    },
}

@dataclass(slots=True)
class CivixConfig:
    """Typed view over the configuration dictionary."""

    data: dict[str, Any]

    def get(self, *keys: str, default: Any = None) -> Any:
        cur: Any = self.data
        for k in keys:
            if not isinstance(cur, dict) or k not in cur:
                return default
            cur = cur[k]
        return cur

def load_config(path: str | Path) -> CivixConfig:
    """Load a YAML configuration file.

    Args:
        path: Path to YAML file.
    Raises:
        ConfigError: on parsing or IO problems.
    """
    try:
        p = Path(path)
        if not p.exists():
            raise ConfigError(f"Config file not found: {p}")
        with p.open("r", encoding="utf-8") as fh:
            raw = yaml.safe_load(fh) or {}
        # shallow merge with defaults
        def merged(a: dict[str, Any], b: dict[str, Any]) -> dict[str, Any]:
            out = dict(a)
            for k, v in (b or {}).items():
                if isinstance(v, dict) and isinstance(out.get(k), dict):
                    out[k] = merged(out[k], v)
                else:
                    out[k] = v
            return out
        data = merged(DEFAULT_CONFIG, raw)
        return CivixConfig(data=data)
    except Exception as exc:  # pragma: no cover - defensive
        raise ConfigError(str(exc)) from exc

def write_default_config(path: str | Path) -> Path:
    """Write a default configuration scaffold to *path*.

    Returns:
        The path written.
    """
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", encoding="utf-8") as fh:
        yaml.safe_dump(DEFAULT_CONFIG, fh, sort_keys=False)
    return p
