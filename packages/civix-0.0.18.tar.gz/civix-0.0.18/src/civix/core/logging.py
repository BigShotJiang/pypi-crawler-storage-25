
"""Loguru logger factory.

Uses a stderr sink and an optional rotating file sink.
"""
from __future__ import annotations

import os
from pathlib import Path

from loguru import logger

_CONFIGURED = False

def _ensure_config(log_dir: str | None = None) -> None:
    """Ensure the global logger is configured once.

    Args:
        log_dir: Optional directory for file logs. If provided, a rotating file sink is added.
    """
    global _CONFIGURED
    if _CONFIGURED:
        return

    logger.remove()  # remove default handler
    logger.add(
        sink=lambda m: print(m, end=""),
        colorize=True,
        backtrace=True,
        diagnose=False,
        level="INFO",
        format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level}</level> | "
               "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - "
               "<level>{message}</level>",
    )
    if log_dir:
        Path(log_dir).mkdir(parents=True, exist_ok=True)
        logger.add(
            os.path.join(log_dir, "civix_{time}.log"),
            rotation="10 MB",
            retention="14 days",
            compression="zip",
            level="DEBUG",
            enqueue=True,
        )
    _CONFIGURED = True

def get_logger(name: str, log_dir: str | None = None):
    """Return a configured Loguru logger for the given *name*.

    Args:
        name: Logger name (usually ``__name__``).
        log_dir: Optional directory to write rotating log files.
    """
    _ensure_config(log_dir)
    return logger.bind(module=name)
