
"""Path helpers."""
from __future__ import annotations

from pathlib import Path


def ensure_dir(path: str | Path) -> Path:
    """Ensure directory exists and return a ``Path``.

    Args:
        path: The directory path.
    """
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p
