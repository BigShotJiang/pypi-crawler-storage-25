
"""Simplified column helpers (placeholders for v0.1)."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class AxialResult:
    phi: float
    Pn: float
    phiPn: float

def axial_capacity_tied(fc: float, Ag: float, Ast: float, phi: float = 0.65) -> AxialResult:
    """Very simplified tied column axial capacity: Pn = 0.85*fc*(Ag - Ast) + fy*Ast.
    Returned strength is phi * Pn.
    """
    # Placeholder — fy not provided; users can refine later.
    fy = 60000.0
    Pn = 0.85*fc*(Ag - Ast) + fy*Ast
    return AxialResult(phi=phi, Pn=Pn, phiPn=phi*Pn)
