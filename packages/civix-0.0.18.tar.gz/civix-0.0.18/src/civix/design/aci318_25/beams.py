
"""ACI 318-25 beam design helpers (simplified manual checks).

These functions are intentionally simple and suited for notebook use.
Units are consistent (kips-in or N-mm etc.).
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class FlexureResult:
    phi: float
    Mn: float
    phiMn: float
    a: float
    c: float
    rho: float

def beta1(fc: float) -> float:
    """Return ACI beta1 as a function of fc (in the same units)."""
    # Simple approximation bounded between 0.65 and 0.85
    b1 = 0.85 - 0.05 * max((fc - 4000.0) / 1000.0, 0.0)
    return float(min(0.85, max(0.65, b1)))

def phi_flexure(tension_controlled: bool = True) -> float:
    """Return strength reduction factor for flexure."""
    return 0.90 if tension_controlled else 0.75

def phiMn_rect_beam(b: float, d: float, fc: float, fy: float, As: float,
                     beta1_override: float | None = None,
                     phi: float | None = None) -> FlexureResult:
    """Compute nominal and design flexural strength for a singly reinforced rectangular beam.

    Args:
        b: width
        d: effective depth
        fc: concrete compressive strength (e.g., psi)
        fy: steel yield (e.g., psi)
        As: tensile steel area
        beta1_override: optional code beta1 override
        phi: optional override for strength reduction factor
    Returns:
        FlexureResult with phi, Mn, phiMn, a, c, rho
    """
    b1 = beta1_override if beta1_override is not None else beta1(fc)
    a = As * fy / (0.85 * fc * b)
    c = a / b1
    jd = d - a / 2.0
    Mn = As * fy * jd
    phi_val = phi if phi is not None else phi_flexure(True)
    return FlexureResult(phi=phi_val, Mn=Mn, phiMn=phi_val * Mn, a=a, c=c, rho=As/(b*d))
