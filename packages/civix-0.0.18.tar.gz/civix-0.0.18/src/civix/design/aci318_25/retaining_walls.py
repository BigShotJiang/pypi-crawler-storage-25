
"""Retaining wall simplified helpers (placeholder)."""
from __future__ import annotations

from dataclasses import dataclass

@dataclass(slots=True)
class ActivePressure:
    Ka: float
    Pa: float

def rankine_active(gamma: float, H: float, phi_deg: float) -> ActivePressure:
    import math
    phi = math.radians(phi_deg)
    Ka = (1 - math.sin(phi)) / (1 + math.sin(phi))
    Pa = 0.5 * Ka * gamma * H**2
    return ActivePressure(Ka=Ka, Pa=Pa)
