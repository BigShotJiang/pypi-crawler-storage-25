
"""Spread footing quick checks (placeholder)."""
from __future__ import annotations

from dataclasses import dataclass

@dataclass(slots=True)
class BearingCheck:
    q_allow: float
    q_actual: float
    ok: bool

def bearing_ok(Pu: float, B: float, L: float, q_allow: float) -> BearingCheck:
    q = Pu/(B*L)
    return BearingCheck(q_allow=q_allow, q_actual=q, ok=(q <= q_allow))
