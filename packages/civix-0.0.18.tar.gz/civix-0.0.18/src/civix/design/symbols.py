"""Standard LaTeX symbol mappings for handcalcs rendering.

Use apply_symbols() at the top of a notebook to register all common
structural engineering variable names so handcalcs renders them correctly
(especially multi-underscore names that would otherwise nest subscripts).

Usage in a notebook cell:
    from civix.design.symbols import apply_symbols
    apply_symbols()
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# ACI 318-25 common variable names → LaTeX
# ---------------------------------------------------------------------------
# Naming convention in Python:  lowercase with underscores
# The dict value is the LaTeX string that handcalcs will use.
#
# Add new entries as needed — keep alphabetical within each section.
# ---------------------------------------------------------------------------

ACI318_SYMBOLS: dict[str, str] = {
    # ── concrete ──────────────────────────────────────────────────────────
    "f_c":            r"f'_c",
    "f_prime_c":      r"f'_c",
    "f_c_min":        r"f'_{c,min}",
    "f_prime_c_min":  r"f'_{c,min}",
    "f_c_max":        r"f'_{c,max}",
    "f_prime_c_max":  r"f'_{c,max}",
    "f_r":            r"f_r",
    "f_ct":           r"f_{ct}",
    "E_c":            r"E_c",
    "lambda_c":       r"\lambda_c",
    "lambda_s":       r"\lambda_s",
    "beta_1":         r"\beta_1",
    "beta_1_val":     r"\beta_1",
    "alpha_1":        r"\alpha_1",
    "epsilon_cu":     r"\varepsilon_{cu}",

    # ── steel ─────────────────────────────────────────────────────────────
    "f_y":            r"f_y",
    "f_yt":           r"f_{yt}",
    "f_u":            r"f_u",
    "E_s":            r"E_s",
    "epsilon_y":      r"\varepsilon_y",
    "epsilon_t":      r"\varepsilon_t",
    "epsilon_s":      r"\varepsilon_s",

    # ── reinforcement areas ───────────────────────────────────────────────
    "A_s":            r"A_s",
    "A_s_min":        r"A_{s,min}",
    "A_s_max":        r"A_{s,max}",
    "A_s_req":        r"A_{s,req}",
    "A_s_prov":       r"A_{s,prov}",
    "A_prime_s":      r"A'_s",
    "A_st":           r"A_{st}",
    "A_v":            r"A_v",
    "A_v_min":        r"A_{v,min}",
    "A_v_req":        r"A_{v,req}",
    "A_v_prov":       r"A_{v,prov}",
    "A_g":            r"A_g",
    "A_tr":           r"A_{tr}",

    # ── geometry / section ────────────────────────────────────────────────
    "b_w":            r"b_w",
    "b_e":            r"b_e",
    "b_eff":          r"b_{eff}",
    "h_f":            r"h_f",
    "d_b":            r"d_b",
    "d_s":            r"d_s",
    "d_prime":        r"d'",
    "c_c":            r"c_c",
    "c_b":            r"c_b",
    "s_max":          r"s_{max}",
    "s_min":          r"s_{min}",
    "l_n":            r"l_n",
    "l_d":            r"l_d",
    "l_dh":           r"l_{dh}",

    # ── flexure ───────────────────────────────────────────────────────────
    "M_u":            r"M_u",
    "M_n":            r"M_n",
    "M_cr":           r"M_{cr}",
    "phi_M_n":        r"\phi M_n",
    "phi_Mn":         r"\phi M_n",

    # ── shear ─────────────────────────────────────────────────────────────
    "V_u":            r"V_u",
    "V_n":            r"V_n",
    "V_c":            r"V_c",
    "V_s":            r"V_s",
    "V_c_min":        r"V_{c,min}",
    "V_s_max":        r"V_{s,max}",
    "phi_V_n":        r"\phi V_n",
    "phi_Vn":         r"\phi V_n",

    # ── axial / column ────────────────────────────────────────────────────
    "P_u":            r"P_u",
    "P_n":            r"P_n",
    "P_o":            r"P_o",
    "P_n_max":        r"P_{n,max}",
    "phi_P_n":        r"\phi P_n",
    "phi_Pn":         r"\phi P_n",
    "e_min":          r"e_{min}",
    "k_lu":           r"k l_u",
    "l_u":            r"l_u",
    "r_g":            r"r_g",
    "rho_g":          r"\rho_g",
    "rho_t":          r"\rho_t",
    "rho_min":        r"\rho_{min}",
    "rho_max":        r"\rho_{max}",
    "rho_b":          r"\rho_b",

    # ── torsion ───────────────────────────────────────────────────────────
    "T_u":            r"T_u",
    "T_n":            r"T_n",
    "T_cr":           r"T_{cr}",
    "A_oh":           r"A_{oh}",
    "A_o":            r"A_o",
    "p_h":            r"p_h",
    "A_t":            r"A_t",
    "A_l":            r"A_l",
    "A_l_min":        r"A_{l,min}",

    # ── foundations ────────────────────────────────────────────────────────
    "q_u":            r"q_u",
    "q_all":          r"q_{all}",
    "q_net":          r"q_{net}",
    "q_max":          r"q_{max}",
    "sigma_soil":     r"\sigma_{soil}",
    "v_c":            r"v_c",
    "v_u":            r"v_u",
    "b_o":            r"b_o",
    "d_f":            r"d_f",

    # ── retaining walls ───────────────────────────────────────────────────
    "K_a":            r"K_a",
    "K_p":            r"K_p",
    "K_o":            r"K_o",
    "P_a":            r"P_a",
    "P_p":            r"P_p",
    "gamma_s":        r"\gamma_s",
    "gamma_c":        r"\gamma_c",
    "gamma_w":        r"\gamma_w",
    "phi_soil":       r"\phi_{soil}",
    "FS_ot":          r"FS_{ot}",
    "FS_sl":          r"FS_{sl}",
    "FS_br":          r"FS_{br}",

    # ── strength reduction factors ────────────────────────────────────────
    "phi_f":          r"\phi_f",
    "phi_v":          r"\phi_v",
    "phi_c":          r"\phi_c",
    "phi_t":          r"\phi_t",
    "phi_b":          r"\phi_b",

    # ── load combinations ─────────────────────────────────────────────────
    "D_L":            r"D",
    "L_L":            r"L",
    "W_L":            r"W",
    "E_Q":            r"E",
    "S_L":            r"S",
}


def apply_symbols(extra: dict[str, str] | None = None) -> None:
    """Register symbol mappings with handcalcs.

    Call once at the top of a notebook:
        from civix.design.symbols import apply_symbols
        apply_symbols()

    Args:
        extra: additional or override mappings to merge in.
    """
    try:
        import handcalcs
    except ImportError:
        raise ImportError(
            "handcalcs is required for symbol rendering.  "
            "Install with:  uv add handcalcs"
        )

    symbols = dict(ACI318_SYMBOLS)
    if extra:
        symbols.update(extra)

    handcalcs.set_option("custom_symbols", symbols)
