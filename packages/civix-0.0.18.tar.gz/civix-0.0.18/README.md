# civix
python tools for Civil and Structural Engineering

## Release workflow

### 1. Pre-release checks (run locally)

Ruff is not enforced in CI — run manually before merging:

```bash
uv tool run ruff check .        # lint (Pyflakes F-rules)
uv tool run ruff format .       # auto-format
uv run pytest                   # all tests green
```

### 2. Merge feature branch → develop (squash)

```bash
git checkout develop
git merge --squash feature/<branch-name>
git commit -m "squashed: <short description>"
```

### 3. Bump version

Edit `version` in `pyproject.toml`, then commit:

```bash
git add pyproject.toml
git commit -m "bump version to <new-version>"
```

### 4. Merge develop → main

```bash
git checkout main
git merge develop
git push origin main
```

CI detects the version change on `main`, creates the tag, runs tests, builds, and publishes to PyPI automatically.

## Streamlit app

```bash
uv run streamlit run streamlit_app/app.py
```

## Installation

```bash
pip install civix                      # core only (numpy, loguru, pyyaml, plotly, openpyxl)
pip install "civix[etabs]"             # + ETABS automation (Windows)
pip install "civix[ifc]"              # + IFC parsing (ifcopenshell)
pip install "civix[geom]"             # + Rhino/Grasshopper geometry
pip install "civix[notebook]"         # + Jupyter notebook + handcalcs rendering
pip install "civix[streamlit]"        # + Streamlit app
pip install "civix[all]"              # everything
```

With `uv`:

```bash
uv add civix
uv add "civix[etabs,ifc,geom]"
uv add "civix[all]"
```
