"""Tests for ladon-nous server tools against an in-memory DuckDB."""

from __future__ import annotations

import json
from datetime import datetime, timezone

import duckdb
import pytest

import ladon_nous.server as srv

_NOW = datetime(2026, 5, 18, 12, 0, 0, tzinfo=timezone.utc)
_RUN_ID = "run-test-001"


def _make_db(tmp_path: pytest.TempPathFactory) -> str:  # type: ignore[type-arg]
    db_path = str(tmp_path / "test.db")  # type: ignore[operator]
    con = duckdb.connect(db_path)

    con.execute("""
        CREATE TABLE mimir_articles (
            run_id TEXT NOT NULL, page_id INTEGER PRIMARY KEY,
            title TEXT NOT NULL, summary TEXT NOT NULL,
            full_text TEXT NOT NULL, categories TEXT NOT NULL,
            last_modified TIMESTAMPTZ NOT NULL,
            word_count INTEGER NOT NULL, url TEXT NOT NULL
        )
    """)
    con.execute("""
        CREATE TABLE ladon_runs (
            run_id TEXT PRIMARY KEY, category TEXT NOT NULL,
            started_at TIMESTAMPTZ NOT NULL, finished_at TIMESTAMPTZ,
            status TEXT NOT NULL,
            articles_fetched INTEGER NOT NULL DEFAULT 0,
            articles_failed  INTEGER NOT NULL DEFAULT 0
        )
    """)

    con.execute(
        "INSERT INTO ladon_runs VALUES (?, ?, ?, ?, ?, ?, ?)",
        [_RUN_ID, "Mathematical finance", _NOW, _NOW, "done", 3, 0],
    )

    articles = [
        (1, "Black–Scholes model", "BSM summary", "BSM full text",
         json.dumps(["Mathematical finance"]), 1200,
         "https://en.wikipedia.org/wiki/Black%E2%80%93Scholes_model"),
        (2, "Monte Carlo method", "MC summary", "MC full text",
         json.dumps(["Computational methods"]), 2300,
         "https://en.wikipedia.org/wiki/Monte_Carlo_method"),
        (3, "Stochastic calculus", "SC summary", "SC full text here",
         json.dumps(["Mathematics"]), 900,
         "https://en.wikipedia.org/wiki/Stochastic_calculus"),
    ]
    for page_id, title, summary, full_text, cats, wc, url in articles:
        con.execute(
            "INSERT INTO mimir_articles VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [_RUN_ID, page_id, title, summary, full_text, cats, _NOW, wc, url],
        )

    con.close()
    return db_path


@pytest.fixture(autouse=True)
def use_test_db(tmp_path: pytest.TempPathFactory) -> None:  # type: ignore[type-arg]
    srv.configure(_make_db(tmp_path))


class TestArticleSearch:
    def test_matches_title(self) -> None:
        results = srv.article_search("Black")
        assert len(results) == 1
        assert results[0]["title"] == "Black–Scholes model"

    def test_matches_summary(self) -> None:
        results = srv.article_search("MC summary")
        assert any(r["title"] == "Monte Carlo method" for r in results)

    def test_matches_full_text(self) -> None:
        results = srv.article_search("SC full text")
        assert any(r["title"] == "Stochastic calculus" for r in results)

    def test_case_insensitive(self) -> None:
        results = srv.article_search("MONTE")
        assert len(results) == 1
        assert results[0]["title"] == "Monte Carlo method"

    def test_returns_categories_as_list(self) -> None:
        results = srv.article_search("Black")
        assert isinstance(results[0]["categories"], list)
        assert "Mathematical finance" in results[0]["categories"]

    def test_limit(self) -> None:
        results = srv.article_search("s", limit=2)
        assert len(results) <= 2

    def test_no_match_returns_empty(self) -> None:
        results = srv.article_search("xyzzy_no_match")
        assert results == []

    def test_ordered_by_word_count_desc(self) -> None:
        results = srv.article_search("m")
        word_counts = [r["word_count"] for r in results]
        assert word_counts == sorted(word_counts, reverse=True)


class TestRunList:
    def test_returns_run(self) -> None:
        runs = srv.run_list()
        assert len(runs) == 1
        assert runs[0]["run_id"] == _RUN_ID
        assert runs[0]["status"] == "done"
        assert runs[0]["articles_fetched"] == 3

    def test_limit(self) -> None:
        runs = srv.run_list(limit=0)
        assert runs == []


class TestCrawlStatus:
    def test_existing_run(self) -> None:
        result = srv.crawl_status(_RUN_ID)
        assert result["status"] == "done"
        assert result["articles_fetched"] == 3
        assert result["category"] == "Mathematical finance"

    def test_missing_run(self) -> None:
        result = srv.crawl_status("nonexistent-run-id")
        assert "error" in result


class TestArticleResource:
    def test_existing_article(self) -> None:
        content = srv.article_resource(1)
        assert "Black–Scholes model" in content
        assert "## Summary" in content
        assert "## Full Text" in content

    def test_missing_article(self) -> None:
        content = srv.article_resource(999)
        assert "not found" in content
