"""MCP server for ladon-nous — tools and resources over a mimir DuckDB."""

from __future__ import annotations

import json
from typing import Any

import duckdb
import fastmcp

_DB_PATH: str = "mimir.db"

mcp = fastmcp.FastMCP(
    "ladon-nous",
    instructions=(
        "Ladon knowledge server. Use article_search to find Wikipedia articles "
        "crawled by ladon-mimir. Use run_list to see crawl history and "
        "crawl_status to check a specific run."
    ),
)


def _conn() -> duckdb.DuckDBPyConnection:
    return duckdb.connect(_DB_PATH, read_only=True)


def configure(db_path: str) -> None:
    """Set the DuckDB path before serving. Called by the CLI."""
    global _DB_PATH
    _DB_PATH = db_path


@mcp.tool()
def article_search(
    query: str,
    limit: int = 10,
) -> list[dict[str, Any]]:
    """Search crawled Wikipedia articles by keyword.

    Matches against title, summary, and full text (case-insensitive).
    Returns up to `limit` results ordered by word count descending.
    Each result includes: page_id, title, summary, categories, word_count, url.
    """
    sql = """
        SELECT page_id, title, summary, categories, word_count, url
        FROM mimir_articles
        WHERE lower(title)     LIKE lower(?)
           OR lower(summary)   LIKE lower(?)
           OR lower(full_text) LIKE lower(?)
        ORDER BY word_count DESC
        LIMIT ?
    """
    pattern = f"%{query}%"
    with _conn() as con:
        rows = con.execute(sql, [pattern, pattern, pattern, limit]).fetchall()

    return [
        {
            "page_id": r[0],
            "title": r[1],
            "summary": r[2],
            "categories": json.loads(r[3]),
            "word_count": r[4],
            "url": r[5],
        }
        for r in rows
    ]


@mcp.tool()
def run_list(limit: int = 20) -> list[dict[str, Any]]:
    """List recent Ladon crawl runs, newest first.

    Returns: run_id, category, status, started_at, finished_at,
    articles_fetched, articles_failed.
    """
    sql = """
        SELECT run_id, category, status, started_at, finished_at,
               articles_fetched, articles_failed
        FROM ladon_runs
        ORDER BY started_at DESC
        LIMIT ?
    """
    with _conn() as con:
        rows = con.execute(sql, [limit]).fetchall()

    return [
        {
            "run_id": r[0],
            "category": r[1],
            "status": r[2],
            "started_at": str(r[3]),
            "finished_at": str(r[4]) if r[4] else None,
            "articles_fetched": r[5],
            "articles_failed": r[6],
        }
        for r in rows
    ]


@mcp.tool()
def crawl_status(run_id: str) -> dict[str, Any]:
    """Get the status of a specific crawl run by run_id.

    Returns run detail including status, timing, and article counts.
    Returns {"error": "..."} if the run_id is not found.
    """
    sql = """
        SELECT run_id, category, status, started_at, finished_at,
               articles_fetched, articles_failed
        FROM ladon_runs
        WHERE run_id = ?
    """
    with _conn() as con:
        row = con.execute(sql, [run_id]).fetchone()

    if row is None:
        return {"error": f"run_id '{run_id}' not found"}

    return {
        "run_id": row[0],
        "category": row[1],
        "status": row[2],
        "started_at": str(row[3]),
        "finished_at": str(row[4]) if row[4] else None,
        "articles_fetched": row[5],
        "articles_failed": row[6],
    }


@mcp.resource("ladon://articles/{page_id}")
def article_resource(page_id: int) -> str:
    """Full content of a single crawled article by Wikipedia page_id.

    Returns a Markdown document with metadata header, summary, and full text.
    """
    sql = """
        SELECT title, summary, full_text, categories, word_count, url, last_modified
        FROM mimir_articles
        WHERE page_id = ?
    """
    with _conn() as con:
        row = con.execute(sql, [page_id]).fetchone()

    if row is None:
        return f"Article {page_id} not found."

    cats = json.loads(row[3])
    return (
        f"# {row[0]}\n\n"
        f"**Categories**: {', '.join(cats)}\n"
        f"**Word count**: {row[4]}\n"
        f"**Last modified**: {row[6]}\n"
        f"**URL**: {row[5]}\n\n"
        f"## Summary\n{row[1]}\n\n"
        f"## Full Text\n{row[2]}"
    )
