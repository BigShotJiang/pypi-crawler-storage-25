"""ladon-nous — MCP server exposing Ladon crawl data to AI agents."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("ladon-nous")
except PackageNotFoundError:
    __version__ = (
        "0.1.0"  # editable install without metadata — bump with every release
    )

__all__ = ["__version__"]
