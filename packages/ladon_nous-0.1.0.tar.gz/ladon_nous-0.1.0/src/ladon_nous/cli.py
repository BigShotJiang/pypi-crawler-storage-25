"""CLI entrypoint for ladon-nous: `ladon-nous serve --db <path>`."""

from __future__ import annotations

import argparse
import sys


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="ladon-nous",
        description="MCP server exposing Ladon crawl data to AI agents.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    serve = sub.add_parser("serve", help="Start the MCP server")
    serve.add_argument(
        "--db",
        required=True,
        metavar="PATH",
        help="Path to the mimir DuckDB file",
    )
    serve.add_argument(
        "--transport",
        choices=["stdio", "sse"],
        default="stdio",
        help="MCP transport (default: stdio for Claude Desktop)",
    )

    args = parser.parse_args()

    if args.command == "serve":
        from ladon_nous import server

        server.configure(args.db)
        server.mcp.run(transport=args.transport)
    else:
        parser.print_help()
        sys.exit(1)
