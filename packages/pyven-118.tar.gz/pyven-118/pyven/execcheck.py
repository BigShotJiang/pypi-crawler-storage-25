import os

execmask = 0x49
magic = '#!'

def execcheck(paths):
    for path in paths:
        basename = os.path.basename(path)
        executable = bool(os.stat(path).st_mode & execmask)
        with open(path) as f:
            hasmagic = f.readline().startswith(magic)
        for prefix in 'test', 'stress':
            if basename.lower().startswith(prefix):
                if not basename.startswith(f"{prefix}_"):
                    raise Exception(f"Inconsistent name: {path}") # Note pyflakes already checks for duplicate method names.
                if executable:
                    raise Exception(f"Should not be executable: {path}")
                if hasmagic:
                    raise Exception(f"Using {magic} is obsolete: {path}")
                break
        else:
            if executable != hasmagic:
                raise Exception(path)
