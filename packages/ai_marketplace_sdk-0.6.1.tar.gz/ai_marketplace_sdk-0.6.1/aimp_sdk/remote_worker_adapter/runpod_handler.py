"""Runpod Serverless handler for AIMP runtime images."""

from __future__ import annotations

import atexit
import os
from typing import Any

from .runner_bridge import (
    RemoteWorkerAdapterError,
    RunnerBridge,
    format_provider_result,
)

_BRIDGE = RunnerBridge(
    module_path=os.environ.get("MODEL_ENTRYPOINT", "").strip() or "/app/main.py"
)
atexit.register(_BRIDGE.shutdown)


def handler(job: dict[str, Any]) -> dict[str, Any]:
    """Run one Runpod job through the canonical AIMP model runner."""
    try:
        response = _BRIDGE.execute(job)
    except RemoteWorkerAdapterError as exc:
        return {"success": False, "output": None, "error": str(exc)}
    return format_provider_result(response)


def main() -> None:
    """Start the Runpod Serverless worker loop."""
    import runpod

    runpod.serverless.start({"handler": handler})


if __name__ == "__main__":
    main()
