"""AI Marketplace Python SDK."""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING, Any

from .components import Component
from .decorators import (
    ModeArgSpec,
    boolean,
    file,
    image,
    integer,
    json,
    number,
    select,
    text,
    text_param,
    video,
    audio,
)
from .exceptions import SDKError
from .execution_assets import ExecutionArtifactContractError
from .execution_assets import ModelLoadError
from .execution_assets import resolve_execution_bundle_payload_dir

from .model_runtime_loader import (
    load_model_contract,
    load_model_entry_class,
    load_model_vector_contract,
)
from .loader import execute_from_env, load_contract, load_model_class
from .media_types import (
    AudioRef,
    FileRef,
    ImageRef,
    JsonRef,
    MediaLoadError,
    MediaRef,
    SearchResult,
    IndexResult,
    TextRef,
    VideoRef,
    TYPE_KIND_MAP,
    get_kind_for_type,
)
from .model import Model
from .model import Model as ModelBase
from .mode import ModeError, mode
from .stream import (
    STREAM_STATES,
    Stream,
    StreamState,
    TextStream,
    canonical_status_payload,
)
from .runtime import (
    AcceleratorInfo,
    ExecutionLimits,
    ProcessContext,
    RuntimeContext,
    VectorExecutionContext,
)
from .settings import Settings, VectorRef
from .vector_store import (
    Metric,
    BooleanField as VectorBooleanField,
    FloatField as VectorFloatField,
    IntegerField as VectorIntegerField,
    JsonField as VectorJsonField,
    StringField as VectorStringField,
    TextField as VectorTextField,
    Vector,
    VectorKnowledge,
    Hit,
)
from .tuning import (
    ArtifactDescriptor,
    FileArtifact,
    FileArtifact as TuningFileArtifactOutput,
    FineTuneSchema,
    JsonArtifact,
    JsonArtifact as TuningJsonArtifact,
    Metric,
    TuneArtifacts,
    TuneMetrics,
    AudioField as TuningAudioField,
    FileField as TuningFileField,
    ImageField as TuningImageField,
    TuneResult,
    TunedResult,
    TuningDatasetView,
    TuningContext,
    TuningParams,
    TuningSession,
    JsonField as TuningJsonField,
    TextField as TuningTextField,
    VideoField as TuningVideoField,
    load_model_tuning_contract,
    load_tuning_schema_class,
    load_tuning_schema_contract,
)
from .vector import (
    JsonPrimitive,
    JsonValue,
    VectorClient,
    VectorClientError,
    VectorSearchResult,
)
from aimp_framework.base import (
    BooleanField,
    Engine,
    IntegerField,
    JsonField,
    ListField,
    MessagesField,
    NumberField,
    Schema,
    SelectField,
    StringField,
    TextField,
)

ImageField = TuningImageField
AudioField = TuningAudioField
VideoField = TuningVideoField
FileField = TuningFileField

if TYPE_CHECKING:
    from .client import Client, FineTuneJob
    from .tuning_data import (
        LoadedTuningBundle,
        TuningBundleError,
        TuningBundlePayload,
        build_tuning_dataset_bundle,
        load_tuning_dataset_bundle,
    )

_LAZY_EXPORTS = {
    "Client": (".client", "Client"),
    "FineTuneJob": (".client", "FineTuneJob"),
    "LoadedTuningBundle": (".tuning_data", "LoadedTuningBundle"),
    "TuningBundleError": (".tuning_data", "TuningBundleError"),
    "TuningBundlePayload": (".tuning_data", "TuningBundlePayload"),
    "build_tuning_dataset_bundle": (".tuning_data", "build_tuning_dataset_bundle"),
    "load_tuning_dataset_bundle": (".tuning_data", "load_tuning_dataset_bundle"),
    # Playground DSL
    "PlaygroundSpec": (".playground", "PlaygroundSpec"),
    "PlaygroundChat": (".playground", "PlaygroundChat"),
    "PlaygroundParams": (".playground", "PlaygroundParams"),
    "PlaygroundSources": (".playground", "PlaygroundSources"),
    "PlaygroundComputed": (".playground", "PlaygroundComputed"),
    "source": (".playground", "source"),
    "computed": (".playground", "computed"),
    "When": (".playground", "When"),
    "SectionRole": (".playground", "SectionRole"),
    "ViewBase": (".playground", "ViewBase"),
    "Image": (".playground", "Image"),
    "Cards": (".playground", "Cards"),
    "Markdown": (".playground", "Markdown"),
    "Text": (".playground", "Text"),
    "Table": (".playground", "Table"),
}


def __getattr__(name: str) -> Any:
    """Load optional SDK exports lazily to keep lightweight flows dependency-free."""
    target = _LAZY_EXPORTS.get(name)
    if target is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

    module_name, attribute_name = target
    module = importlib.import_module(module_name, __name__)
    value = getattr(module, attribute_name)
    globals()[name] = value
    return value


__all__ = [
    # Exceptions
    "SDKError",
    "ExecutionArtifactContractError",
    "ModelLoadError",
    "resolve_execution_bundle_payload_dir",
    # Core classes
    "Model",
    "ModelBase",
    "Engine",
    "mode",
    "Component",
    "Settings",
    "Schema",
    "Metric",
    "Vector",
    "VectorRef",
    "VectorKnowledge",
    "StringField",
    "IntegerField",
    "NumberField",
    "BooleanField",
    "JsonField",
    "ListField",
    "MessagesField",
    "SelectField",
    "TextField",
    "VectorStringField",
    "VectorIntegerField",
    "VectorFloatField",
    "VectorBooleanField",
    "VectorJsonField",
    "VectorTextField",
    "Hit",
    "text",
    "image",
    "audio",
    "video",
    "file",
    "json",
    "text_param",
    "integer",
    "number",
    "boolean",
    "select",
    "ModeArgSpec",
    "ModeError",
    "Stream",
    "StreamState",
    "TextStream",
    "STREAM_STATES",
    "canonical_status_payload",
    "MediaRef",
    "ImageRef",
    "AudioRef",
    "VideoRef",
    "FileRef",
    "TextRef",
    "JsonRef",
    "MediaLoadError",
    "SearchResult",
    "IndexResult",
    "TYPE_KIND_MAP",
    "get_kind_for_type",
    "AcceleratorInfo",
    "ExecutionLimits",
    "ProcessContext",
    "RuntimeContext",
    "VectorExecutionContext",
    "VectorClient",
    "VectorClientError",
    "VectorSearchResult",
    "JsonPrimitive",
    "JsonValue",
    "FineTuneSchema",
    "ArtifactDescriptor",
    "JsonArtifact",
    "FileArtifact",
    "TuneArtifacts",
    "TuningJsonArtifact",
    "TuningFileArtifactOutput",
    "TuneMetrics",
    "Metric",
    "TuningImageField",
    "TuningAudioField",
    "TuningVideoField",
    "TuningFileField",
    "TuningTextField",
    "TuningJsonField",
    "ImageField",
    "AudioField",
    "VideoField",
    "FileField",
    "TuneResult",
    "TunedResult",
    "TuningDatasetView",
    "TuningContext",
    "TuningParams",
    "TuningSession",
    "load_model_tuning_contract",
    "load_tuning_schema_class",
    "load_tuning_schema_contract",
    "execute_from_env",
    "load_contract",
    "load_model_contract",
    "load_model_vector_contract",
    "load_model_class",
    "load_model_entry_class",
    "Client",
    "FineTuneJob",
    "LoadedTuningBundle",
    "TuningBundleError",
    "TuningBundlePayload",
    "build_tuning_dataset_bundle",
    "load_tuning_dataset_bundle",
    # Playground DSL
    "PlaygroundSpec",
    "PlaygroundChat",
    "PlaygroundParams",
    "PlaygroundSources",
    "PlaygroundComputed",
    "source",
    "computed",
    "When",
    "SectionRole",
    "ViewBase",
    "Image",
    "Cards",
    "Markdown",
    "Text",
    "Table",
]
