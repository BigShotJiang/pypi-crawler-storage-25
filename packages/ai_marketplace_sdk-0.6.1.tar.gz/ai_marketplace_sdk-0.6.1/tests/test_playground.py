import sys
from pathlib import Path

import pytest

SDK_ROOT = Path(__file__).resolve().parents[1]
FRAMEWORK_ROOT = SDK_ROOT.parents[0] / "framework"
sys.path.insert(0, str(SDK_ROOT))
sys.path.insert(0, str(FRAMEWORK_ROOT))

from aimp_framework.base import JsonField, Schema, TextField
from aimp_sdk.playground import (
    Cards,
    Image,
    Markdown,
    PlaygroundChat,
    PlaygroundComputed,
    PlaygroundSources,
    PlaygroundSpec,
    SectionRole,
    When,
    _resolve_field_name,
    computed,
    source,
    validate_mode_playground,
)


# ---------------------------------------------------------------------------
# Fixtures — minimal schema stubs
# ---------------------------------------------------------------------------


class _FakeField:
    def __init__(
        self,
        name: str,
        *,
        schema_role: str | None = None,
        kind: str | None = None,
        multiple: bool = False,
    ) -> None:
        self.name = name
        self.schema_role = schema_role
        self.kind = kind
        self.multiple = multiple


class _FakeOutputs:
    _fields = {
        "results": _FakeField("results"),
        "article": _FakeField("article", kind="text"),
        "sources": _FakeField("sources"),
        "indexed": _FakeField("indexed"),
        "messages": _FakeField("messages"),
        "data": _FakeField("data"),
        "images": _FakeField("images"),
    }


class _FakeInputs:
    _fields = {
        "image": _FakeField("image", schema_role="inputs", kind="image"),
        "images": _FakeField("images", schema_role="inputs", kind="image", multiple=True),
        "prompt": _FakeField("prompt", schema_role="inputs", kind="text"),
        "message": _FakeField("message", schema_role="inputs", kind="text"),
        "tone": _FakeField("tone", schema_role="inputs", kind="text"),
        "history": type("_HistoryField", (), {"name": "history", "kind": "messages"})(),
        "messages": type("_MessagesField", (), {"name": "messages", "kind": "messages"})(),
    }


class _FakeParams:
    _fields = {
        "temperature": type("_TemperatureField", (), {"name": "temperature", "kind": "number"})(),
        "max_tokens": type("_MaxTokensField", (), {"name": "max_tokens", "kind": "integer"})(),
    }


class _FakeSDKOutputs:
    fields = {
        "results": object(),
        "indexed": object(),
    }


class _FakeSDKInputs:
    fields = {
        "image": object(),
        "history": type("_HistoryDecl", (), {"kind": "messages"})(),
        "messages": type("_MessagesDecl", (), {"kind": "messages"})(),
    }


class SourceCard(Schema):
    asset_ref = TextField(required=True)
    title = TextField(required=True)
    snippet = TextField(required=False)


class _TypedOutputs(Schema.Outputs):
    sources = JsonField(schema=SourceCard, multiple=True, required=False)


_results = _FakeField("results")
_article = _FakeField("article")
_sources = _FakeField("sources")
_indexed = _FakeField("indexed")
_message = _FakeField("message", schema_role="inputs", kind="text")
_tone = _FakeField("tone", schema_role="inputs", kind="text")
_temperature = _FakeField("temperature", schema_role="params")
_max_tokens = _FakeField("max_tokens", schema_role="params")
_image = _FakeField("image", schema_role="inputs", kind="image")
_images = _FakeField("images", schema_role="inputs", kind="image", multiple=True)


# ---------------------------------------------------------------------------
# _resolve_field_name
# ---------------------------------------------------------------------------


class TestResolveFieldName:
    def test_field_object_returns_name(self):
        assert _resolve_field_name(_results, "label") == "results"

    def test_string_returns_stripped_name(self):
        assert _resolve_field_name("  results  ", "label") == "results"

    def test_empty_string_raises(self):
        with pytest.raises(ValueError, match="non-empty"):
            _resolve_field_name("", "label")

    def test_unknown_type_raises(self):
        with pytest.raises(TypeError, match="Schema Field reference"):
            _resolve_field_name(42, "label")


# ---------------------------------------------------------------------------
# View presets
# ---------------------------------------------------------------------------


class TestCardsView:
    def test_validate_valid_field(self):
        view = Cards(_results, title="filename", metrics=["score"])
        view.validate_against_outputs(_FakeOutputs)

    def test_contract_includes_when_and_role(self):
        view = Cards(
            _results,
            title="filename",
            when=When.HAS_CONTENT,
            role=SectionRole.SECONDARY,
        )
        view.validate_against_outputs(_FakeOutputs)
        c = view.to_contract()
        assert c["when"] == "has_content"
        assert c["role"] == "secondary"

    def test_typed_cards_reject_string_title(self):
        view = Cards(
            _TypedOutputs.sources,
            title="oops",
        )
        with pytest.raises(TypeError, match="typed field reference"):
            view.validate_against_outputs(_TypedOutputs)

    def test_typed_cards_image_asset_ref(self):
        view = Cards(
            _TypedOutputs.sources,
            title=SourceCard.title,
            image=Image.asset_ref(SourceCard.asset_ref),
        )
        view.validate_against_outputs(_TypedOutputs)
        c = view.to_contract()
        assert c["title"] == {"kind": "field", "name": "title"}
        assert c["image"]["semantic"] == "asset_ref"
        assert c["image"]["field"] == "asset_ref"

    def test_untyped_cards_image_asset_ref_accepts_string_field(self):
        view = Cards(
            _results,
            image=Image.asset_ref("image_id", badges=["score"]),
            metrics=["score"],
        )
        view.validate_against_outputs(_FakeOutputs)
        c = view.to_contract()
        assert c["image"] == {
            "field": "image_id",
            "semantic": "asset_ref",
            "badges": ["score"],
        }
        assert c["metrics"] == ["score"]


class TestMarkdownView:
    def test_stream_true_in_contract(self):
        view = Markdown(_article, stream=True)
        view.validate_against_outputs(_FakeOutputs)
        assert view.to_contract()["stream"] is True


# ---------------------------------------------------------------------------
# Sources / computed bindings
# ---------------------------------------------------------------------------


class TestSourceBinding:
    def test_chat_history_contract(self):
        b = source.chat_history()
        assert b.source == "chat_history"
        assert b.to_contract()["source"] == "chat_history"


class TestComputedBinding:
    def test_asset_ref_contract(self):
        b = computed.asset_ref(_image)
        assert b.kind == "asset_ref"
        assert b.from_field == "image"
        assert b.to_contract()["kind"] == "asset_ref"

    def test_asset_refs_requires_multiple(self):
        with pytest.raises(TypeError, match="multiple=True"):
            computed.asset_refs(_image)

    def test_asset_refs(self):
        b = computed.asset_refs(_images)
        assert b.kind == "asset_refs"


class TestPlaygroundSources:
    def test_chat_history(self):
        pi = PlaygroundSources(history=source.chat_history())
        pi.validate_against_inputs(_FakeInputs)

    def test_contract(self):
        pi = PlaygroundSources(history=source.chat_history())
        assert pi.to_contract()["history"]["source"] == "chat_history"


class TestPlaygroundComputed:
    def test_asset_ref(self):
        pc = PlaygroundComputed(thumb=computed.asset_ref(_image))
        pc.validate_against_inputs(_FakeInputs)
        assert pc.to_contract()["thumb"]["kind"] == "asset_ref"


# ---------------------------------------------------------------------------
# PlaygroundSpec
# ---------------------------------------------------------------------------


class TestPlaygroundSpec:
    def test_sources_and_computed_in_contract(self):
        class Spec(PlaygroundSpec):
            sources = PlaygroundSources(history=source.chat_history())
            computed = PlaygroundComputed(thumb=computed.asset_ref(_image))
            response = Markdown(_article)

        Spec.validate_against_mode(_FakeInputs, _FakeOutputs, _FakeParams)
        c = Spec.to_contract()
        assert "sources" in c
        assert "computed" in c
        assert "overrides" not in c


class TestValidateModePlayground:
    def _make_mode_cls(self, outputs=_FakeOutputs, inputs=_FakeInputs, params=_FakeParams):
        class FakeMode:
            schema = type(
                "FakeSchema",
                (),
                {"Inputs": inputs, "Outputs": outputs, "Params": params},
            )

        return FakeMode

    def test_valid_spec(self):
        class Spec(PlaygroundSpec):
            response = Cards(_results)

        mode_cls = self._make_mode_cls()
        validate_mode_playground(mode_cls, Spec)
