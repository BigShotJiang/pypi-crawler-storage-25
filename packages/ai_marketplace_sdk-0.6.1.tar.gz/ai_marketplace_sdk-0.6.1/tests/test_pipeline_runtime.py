"""Tests for functional mode -> model orchestration runtime."""

from __future__ import annotations

import io
import json
import os
from pathlib import Path
import selectors
import subprocess
import shutil
import sys
import base64

import pytest

SDK_ROOT = Path(__file__).resolve().parents[1]
FRAMEWORK_ROOT = SDK_ROOT.parents[0] / "framework"
sys.path.insert(0, str(SDK_ROOT))

from aimp_sdk import build_tuning_dataset_bundle  # noqa: E402
from aimp_sdk.model_runtime_loader import load_model_contract  # noqa: E402
from aimp_sdk.model_runner import ModelRunner  # noqa: E402


def _write_modes_model(
    tmp_path: Path,
    template_name: str = "pipeline_runtime_model.py",
) -> str:
    model_dir = tmp_path / "app"
    model_dir.mkdir(parents=True, exist_ok=True)
    (model_dir / "__init__.py").write_text("", encoding="utf-8")
    (model_dir / "pyproject.toml").write_text(
        "[project]\n"
        'name = "semantic-search"\n'
        'version = "1.0.0"\n'
        'description = "Semantic search over documents"\n\n'
        "[tool.aimp.project]\n"
        'author = "username"\n',
        encoding="utf-8",
    )
    template_root = (
        Path(__file__).resolve().parents[2]
        / "framework"
        / "aimp_framework"
        / "project_template"
        / "test_modules"
    )
    shutil.copy2(template_root / template_name, model_dir / "main.py")
    return str(model_dir / "main.py")


def _write_streaming_model(tmp_path: Path) -> str:
    model_dir = tmp_path / "streaming-app"
    model_dir.mkdir(parents=True, exist_ok=True)
    (model_dir / "__init__.py").write_text("", encoding="utf-8")
    (model_dir / "pyproject.toml").write_text(
        "[project]\n"
        'name = "streaming-model"\n'
        'version = "1.0.0"\n'
        'description = "Streaming test model"\n\n'
        "[tool.aimp.project]\n"
        'author = "username"\n',
        encoding="utf-8",
    )
    (model_dir / "main.py").write_text(
        "from __future__ import annotations\n\n"
        "from aimp_sdk import Model, Schema, Stream, TextField, mode\n\n"
        "class ChatEngine:\n"
        "    def load(self):\n"
        "        pass\n\n"
        "class ChatSchema:\n"
        "    class Inputs(Schema.Inputs):\n"
        "        prompt = TextField(required=True)\n\n"
        "    class Outputs(Schema.Outputs):\n"
        "        answer = TextField(required=True)\n\n"
        "    class Params(Schema.Params):\n"
        "        pass\n\n"
        "class StreamModel(Model):\n"
        "    engine = ChatEngine\n\n"
        "    @mode(name='chat')\n"
        "    async def chat(self, inputs: ChatSchema.Inputs, params: ChatSchema.Params) -> ChatSchema.Outputs:\n"
        "        del params\n"
        "        stream = Stream.text(text=ChatSchema.Outputs.answer)\n"
        "        stream.write('Hello')\n"
        "        stream.write(' there')\n"
        "        return stream.done(final_text=f'{inputs.prompt} world')\n",
        encoding="utf-8",
    )
    return str(model_dir / "main.py")


def _write_streaming_model_with_status(tmp_path: Path) -> str:
    model_dir = tmp_path / "streaming-status-app"
    model_dir.mkdir(parents=True, exist_ok=True)
    (model_dir / "__init__.py").write_text("", encoding="utf-8")
    (model_dir / "pyproject.toml").write_text(
        "[project]\n"
        'name = "streaming-status"\n'
        'version = "1.0.0"\n'
        'description = "Streaming status test model"\n\n'
        "[tool.aimp.project]\n"
        'author = "username"\n',
        encoding="utf-8",
    )
    (model_dir / "main.py").write_text(
        "from __future__ import annotations\n\n"
        "from aimp_sdk import JsonField, Model, Schema, Stream, TextField, mode\n\n"
        "class ChatEngine:\n"
        "    def load(self):\n"
        "        pass\n\n"
        "class ChatSchema:\n"
        "    class Inputs(Schema.Inputs):\n"
        "        prompt = TextField(required=True)\n\n"
        "    class Outputs(Schema.Outputs):\n"
        "        answer = TextField(required=True)\n"
        "        status = JsonField(required=False)\n\n"
        "    class Params(Schema.Params):\n"
        "        pass\n\n"
        "class StreamModel(Model):\n"
        "    engine = ChatEngine\n\n"
        "    @mode(name='chat')\n"
        "    async def chat(self, inputs: ChatSchema.Inputs, params: ChatSchema.Params) -> ChatSchema.Outputs:\n"
        "        del params\n"
        "        stream = Stream.text(text=ChatSchema.Outputs.answer, status=ChatSchema.Outputs.status)\n"
        "        stream.status('queued')\n"
        "        stream.status('generating')\n"
        "        stream.write('Hello')\n"
        "        stream.write(' world')\n"
        "        return stream.done(final_text=f'{inputs.prompt} world')\n",
        encoding="utf-8",
    )
    return str(model_dir / "main.py")


def _execution_context(tmp_path: Path, *, request_id: str) -> dict[str, object]:
    return {
        "model_id": "model-123",
        "request_id": request_id,
        "artifacts_dir": str(tmp_path / "artifacts"),
        "tuning_artifacts_dir": str(tmp_path / request_id / "tuning-artifacts"),
        "tuning_output_dir": str(tmp_path / request_id / "tuning-output"),
        "cache_dir": str(tmp_path / "cache"),
        "work_dir": str(tmp_path / request_id),
        "limits": {"cpu": "1", "memory_mb": 128, "timeout_seconds": 30},
        "accelerator": {"kind": "cpu", "backend": None, "count": 0, "identifiers": []},
    }


def _write_tuning_model(tmp_path: Path) -> str:
    model_dir = tmp_path / "tuning-app"
    model_dir.mkdir(parents=True, exist_ok=True)
    (model_dir / "__init__.py").write_text("", encoding="utf-8")
    (model_dir / "pyproject.toml").write_text(
        "[project]\n"
        'name = "tuning-model"\n'
        'version = "1.0.0"\n'
        'description = "Tuning output contract test model"\n\n'
        "[tool.aimp.project]\n"
        'author = "username"\n',
        encoding="utf-8",
    )
    (model_dir / "main.py").write_text(
        "from __future__ import annotations\n\n"
        "from aimp_sdk import FineTuneSchema, JsonArtifact, Metric, Model, Schema, TextField, TuneArtifacts, TuneMetrics, TuneResult, TuningSession, mode\n\n"
        "class DemoEngine:\n"
        "    def load(self):\n"
        "        pass\n\n"
        "class EchoSchema:\n"
        "    class Inputs(Schema.Inputs):\n"
        "        prompt = TextField(required=True)\n\n"
        "    class Outputs(Schema.Outputs):\n"
        "        answer = TextField(required=True)\n\n"
        "    class Params(Schema.Params):\n"
        "        pass\n\n"
        "class DemoDataset(FineTuneSchema):\n"
        "    prompt = TextField(required=True)\n"
        "    completion = TextField(required=True)\n\n"
        "class DemoArtifacts(TuneArtifacts):\n"
        "    memory = JsonArtifact(required=True)\n\n"
        "class DemoMetrics(TuneMetrics):\n"
        "    accuracy = Metric(goal='maximize', required=True)\n\n"
        "class DemoTuning:\n"
        "    dataset_schema = DemoDataset\n"
        "    artifacts_schema = DemoArtifacts\n"
        "    metrics_schema = DemoMetrics\n\n"
        "class DemoModel(Model):\n"
        "    engine = DemoEngine\n"
        "    tuning = DemoTuning\n\n"
        "    @mode(name='echo')\n"
        "    async def echo(self, inputs: EchoSchema.Inputs, params: EchoSchema.Params) -> EchoSchema.Outputs:\n"
        "        del params\n"
        "        return {'answer': inputs.prompt}\n\n"
        "    async def run_tuning(self, session: TuningSession):\n"
        "        artifact = session.artifacts.memory.write_json({'output_dir': str(session.output_dir)})\n"
        "        return TuneResult(artifacts=DemoArtifacts(memory=artifact), metrics=DemoMetrics(accuracy=1.0))\n",
        encoding="utf-8",
    )
    return str(model_dir / "main.py")


def test_mode_based_model_runner_dispatches_to_handlers(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    module_path = _write_modes_model(tmp_path)
    monkeypatch.setenv("AIMP_MODEL_ID", "model-123")
    runner = ModelRunner(module_path)
    runner.start()

    index_response = runner.handle_request(
        {
            "request_id": "idx-1",
            "mode": "find",
            "input": {"items": ["one", "three", "seven"]},
            "parameters": {},
            "execution_context": _execution_context(tmp_path, request_id="req-1"),
            "vector_context": None,
        }
    )
    search_response = runner.handle_request(
        {
            "request_id": "search-1",
            "mode": "search",
            "input": {"query": "four"},
            "parameters": {"top_k": 2},
            "execution_context": _execution_context(tmp_path, request_id="req-2"),
            "vector_context": None,
        }
    )
    runner.shutdown()

    assert index_response["output"] == {"indexed": {"kind": "integer", "content": 3}}
    assert search_response["output"] == {
        "results": {"kind": "text", "content": ["one", "three"]},
        "count": {"kind": "integer", "content": 2},
    }


def test_model_runner_module_emits_ready_and_stays_alive(tmp_path: Path) -> None:
    module_path = _write_modes_model(tmp_path)
    python_path_entries = [str(SDK_ROOT), str(FRAMEWORK_ROOT)]
    existing_python_path = os.environ.get("PYTHONPATH", "").strip()
    if existing_python_path:
        python_path_entries.append(existing_python_path)

    process = subprocess.Popen(
        [
            sys.executable,
            "-m",
            "aimp_sdk.model_runner",
            "--module",
            module_path,
        ],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,
        env={**os.environ, "PYTHONPATH": os.pathsep.join(python_path_entries)},
    )
    try:
        assert process.stdout is not None
        assert process.stderr is not None
        selector = selectors.DefaultSelector()
        selector.register(process.stdout, selectors.EVENT_READ)
        events = selector.select(timeout=5)
        if not events:
            stderr = process.stderr.read()
            raise AssertionError(f"model_runner did not emit readiness output. stderr={stderr!r}")
        ready_line = process.stdout.readline().strip()
        assert ready_line, process.stderr.read()
        assert json.loads(ready_line) == {"type": "ready", "protocol_version": 2}
        assert process.poll() is None
    finally:
        process.terminate()
        process.wait(timeout=5)


def test_model_runner_writes_interleaved_chunk_messages_before_terminal_response(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    module_path = _write_streaming_model(tmp_path)
    monkeypatch.setenv("AIMP_MODEL_ID", "model-123")
    runner = ModelRunner(module_path)
    runner.start()

    output_stream = io.StringIO()
    response = runner.handle_request(
        {
            "request_id": "stream-1",
            "mode": "chat",
            "input": {"prompt": "Hello"},
            "parameters": {},
            "execution_context": _execution_context(tmp_path, request_id="stream-req-1"),
            "vector_context": None,
        },
        output_stream=output_stream,
    )
    runner.shutdown()

    lines = [json.loads(line) for line in output_stream.getvalue().splitlines() if line.strip()]
    assert [line["type"] for line in lines] == ["event", "event"]
    assert all(line["protocol_version"] == 2 for line in lines)
    assert lines[0]["payload"] == {
        "op": "append",
        "target": "answer",
        "content": "Hello",
        "metadata": {},
    }
    assert lines[1]["payload"] == {
        "op": "append",
        "target": "answer",
        "content": " there",
        "metadata": {},
    }
    assert response["type"] == "response"
    assert response["protocol_version"] == 2
    assert response["output"] == {"answer": {"kind": "text", "content": "Hello world"}}


def test_model_runner_emits_status_and_stream_events_in_order(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    module_path = _write_streaming_model_with_status(tmp_path)
    monkeypatch.setenv("AIMP_MODEL_ID", "model-123")
    runner = ModelRunner(module_path)
    runner.start()

    output_stream = io.StringIO()
    response = runner.handle_request(
        {
            "request_id": "stream-status-1",
            "mode": "chat",
            "input": {"prompt": "Hello"},
            "parameters": {},
            "execution_context": _execution_context(tmp_path, request_id="stream-status-req"),
            "vector_context": None,
        },
        output_stream=output_stream,
    )
    runner.shutdown()

    lines = [json.loads(line) for line in output_stream.getvalue().splitlines() if line.strip()]
    assert len(lines) == 5
    assert all(line["type"] == "event" for line in lines)
    assert lines[0]["payload"]["op"] == "replace"
    assert lines[0]["payload"]["target"] == "status"
    assert lines[0]["payload"]["content"]["state"] == "queued"
    assert lines[1]["payload"]["content"]["state"] == "generating"
    assert lines[2]["payload"]["op"] == "append"
    assert lines[3]["payload"]["op"] == "append"
    assert lines[4]["payload"]["op"] == "replace"
    assert lines[4]["payload"]["content"]["state"] == "completed"
    assert response["output"]["answer"] == {"kind": "text", "content": "Hello world"}
    assert response["output"]["status"]["content"]["state"] == "completed"


def test_load_model_contract_generates_modes_metadata_from_code(tmp_path: Path) -> None:
    module_path = _write_modes_model(tmp_path)

    contract = load_model_contract(module_path)

    assert contract["schema_version"] == 5
    assert contract["package"]["name"] == "semantic-search"
    assert contract["resources"]["vector_db"] == {
        "collections": [
            {
                "alias": "docs",
                "name": "Documents",
                "description": "Document embeddings used by vector-backed modes.",
                "dimension": 1536,
                "metric": "cosine",
            }
        ]
    }
    assert sorted(contract["modes"]) == ["find", "search"]
    assert contract["modes"]["search"]["outputs"] == [
        {"name": "results", "kind": "text", "required": True, "multiple": True},
        {"name": "count", "kind": "integer", "required": True},
    ]
    assert "parameters" not in contract
    assert "parameters" in contract["modes"]["search"]
    assert contract["modes"]["search"]["parameters"]["top_k"] == {
        "kind": "integer",
        "default": 5,
        "min": 1,
        "max": 20,
    }


def test_mode_runtime_emits_typed_list_outputs_as_json(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    module_path = _write_modes_model(tmp_path, "typed_list_runtime_model.py")
    monkeypatch.setenv("AIMP_MODEL_ID", "model-123")
    runner = ModelRunner(module_path)
    runner.start()

    response = runner.handle_request(
        {
            "request_id": "search-typed-list",
            "mode": "search",
            "input": {"query": "cat"},
            "parameters": {},
            "execution_context": _execution_context(tmp_path, request_id="req-typed-list"),
            "vector_context": None,
        }
    )
    runner.shutdown()

    assert response["output"] == {
        "matches": {
            "kind": "json",
            "content": [
                {
                    "image_id": "cat-1",
                    "filename": "cat.png",
                    "score": 0.91,
                }
            ],
        },
        "count": {"kind": "integer", "content": 1},
    }


def test_model_runner_tuning_uses_runtime_output_dir(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    module_path = _write_tuning_model(tmp_path)
    monkeypatch.setenv("AIMP_MODEL_ID", "model-123")
    runner = ModelRunner(module_path)
    runner.start()

    dataset_path = tmp_path / "dataset.json"
    dataset_path.write_text(
        json.dumps(
            {
                "records": [
                    {"prompt": "hello", "completion": "world"},
                    {"prompt": "bye", "completion": "moon"},
                ]
            }
        ),
        encoding="utf-8",
    )
    bundle = build_tuning_dataset_bundle(
        schema_contract={
            "fields": [
                {"key": "prompt", "type": "text", "required": True, "multiple": False},
                {
                    "key": "completion",
                    "type": "text",
                    "required": True,
                    "multiple": False,
                },
            ],
        },
        bundle_path=dataset_path,
    )
    bundle_path = tmp_path / bundle.file_name
    with bundle_path.open("wb") as handle:
        bundle.stream.seek(0)
        handle.write(bundle.stream.read())

    response = runner.handle_request(
        {
            "request_id": "tune-1",
            "mode": "tune",
            "input": {
                "dataset_path": str(bundle_path),
                "validation": {"mode": "auto_split", "ratio": 0.5},
            },
            "parameters": {},
            "execution_context": _execution_context(tmp_path, request_id="tune-request"),
            "vector_context": None,
        }
    )
    runner.shutdown()

    artifacts = response["output"]["artifacts"]
    assert artifacts["memory"]["path"] == "memory.json"
    encoded_payload = artifacts["memory"]["inline_base64"]
    decoded_payload = json.loads(base64.b64decode(encoded_payload).decode("utf-8"))
    assert decoded_payload["output_dir"].endswith("/tune-request/tuning-output")
