"""
Notification backends for kim: platform-specific notifications and Slack.
"""

import json
import os
import platform
import shutil
import subprocess
import urllib.error
import urllib.request
from typing import Optional

from .core import log
from .sound import play_sound_file


# ── Linux environment ─────────────────────────────────────────────────────────
def _linux_env():
    uid = os.getuid()
    env = os.environ.copy()
    env.setdefault("DISPLAY", ":0")
    env.setdefault("DBUS_SESSION_BUS_ADDRESS", f"unix:path=/run/user/{uid}/bus")
    env.setdefault("XDG_RUNTIME_DIR", f"/run/user/{uid}")
    return env


# ── Platform-specific notification functions ──────────────────────────────────
def _notify_linux(title, message, urgency, sound, sound_file=None):
    env = _linux_env()
    u = urgency if urgency in ("low", "normal", "critical") else "normal"
    try:
        subprocess.run(
            ["notify-send", "--urgency", u, title, message],
            env=env,
            check=True,
            timeout=5,
        )
    except FileNotFoundError:
        log.error("notify-send not found. Install libnotify.")
    except subprocess.TimeoutExpired:
        log.warning("notify-send timed out")
    except Exception as e:
        log.error("notify-send: %s", e)

    if sound:
        if sound_file:
            play_sound_file(sound_file, "Linux")
        else:
            for cmd in (
                ["canberra-gtk-play", "--id=bell"],
                ["paplay", "/usr/share/sounds/freedesktop/stereo/bell.oga"],
            ):
                if shutil.which(cmd[0]):
                    subprocess.Popen(cmd, env=env, stderr=subprocess.DEVNULL)
                    break


def _notify_mac(title, message, urgency, sound, sound_file=None):
    # Escape for AppleScript string literals: backslash first, then double-quote
    def _as(s):
        return (
            s.replace("\\", "\\\\")
            .replace('"', '\\"')
            .replace("\n", " ")
            .replace("\r", "")
        )

    t = _as(title)
    m = _as(message)

    if sound and sound_file:
        # Show toast without built-in sound; play custom file separately via afplay
        snd = ""
    else:
        snd = 'sound name "Glass"' if sound else ""

    try:
        subprocess.run(
            ["osascript", "-e", f'display notification "{m}" with title "{t}" {snd}'],
            check=True,
            timeout=5,
        )
    except FileNotFoundError:
        log.error("osascript not found. Is this macOS?")
    except subprocess.TimeoutExpired:
        log.warning("osascript timed out")
    except Exception as e:
        log.error("osascript: %s", e)

    if sound and sound_file:
        play_sound_file(sound_file, "Darwin")


def _notify_windows(title, message, urgency, sound, sound_file=None):
    # Try WinRT Toast notification (Windows 10/11 native — lands in Action Center)
    _toast_ok = False
    try:
        # Escape single-quotes for PowerShell string literals
        t = title.replace("'", "''").replace("\n", " ")
        m = message.replace("'", "''").replace("\n", " ")
        # Use PowerShell app ID so Windows associates toasts with a known executable
        app_id = "{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\\WindowsPowerShell\\v1.0\\powershell.exe"
        ps = f"""
[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
[Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] | Out-Null
$template = [Windows.UI.Notifications.ToastTemplateType]::ToastText02
$xml = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent($template)
$nodes = $xml.GetElementsByTagName('text')
$nodes.Item(0).AppendChild($xml.CreateTextNode('{t}')) | Out-Null
$nodes.Item(1).AppendChild($xml.CreateTextNode('{m}')) | Out-Null
$toast = [Windows.UI.Notifications.ToastNotification]::new($xml)
$notifier = [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('{app_id}')
$notifier.Show($toast)
"""
        result = subprocess.run(
            ["powershell", "-WindowStyle", "Hidden", "-Command", ps],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            timeout=10,
        )
        if result.returncode == 0:
            _toast_ok = True
            log.debug("Windows WinRT toast sent: %s", title)
        else:
            err = result.stderr.decode(errors="replace").strip()
            log.warning("WinRT toast failed (rc=%d): %s", result.returncode, err)
    except FileNotFoundError:
        log.error("powershell not found. Is this Windows?")
    except subprocess.TimeoutExpired:
        log.warning("WinRT toast timed out")
    except Exception as e:
        log.warning("WinRT toast exception: %s", e)

    # Fallback: NotifyIcon balloon (Windows 7/8 / older environments)
    if not _toast_ok:
        try:
            t2 = title.replace("'", "''").replace("\n", " ")
            m2 = message.replace("'", "''").replace("\n", " ")
            ps2 = f"""
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$n = New-Object System.Windows.Forms.NotifyIcon
$n.Icon = [System.Drawing.SystemIcons]::Information
$n.Visible = $true
$n.BalloonTipIcon = 'Info'
$n.BalloonTipTitle = '{t2}'
$n.BalloonTipText = '{m2}'
$n.ShowBalloonTip(5000)
Start-Sleep -Seconds 6
$n.Visible = $false
$n.Dispose()
"""
            subprocess.Popen(
                ["powershell", "-WindowStyle", "Hidden", "-Command", ps2],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            log.debug("Windows balloon fallback sent: %s", title)
        except Exception as e:
            log.warning("Balloon notification fallback failed: %s", e)

    # For critical urgency, also show a console pop-up via msg.exe so the
    # reminder is visible even when Focus Assist / Do Not Disturb suppresses
    # toast banners.
    if urgency == "critical":
        try:
            popup_text = f"{title}\n\n{message}"
            subprocess.Popen(
                ["msg", "*", "/TIME:30", popup_text],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except FileNotFoundError:
            pass  # msg.exe not available (e.g. Windows Home without it)
        except Exception as e:
            log.debug("msg.exe popup failed: %s", e)

    # Play a beep as fallback/confirmation — only when sound is enabled
    if sound:
        try:
            subprocess.run(
                ["powershell", "-Command", "[console]::beep(800,200)"],
                capture_output=True,
                timeout=2,
            )
        except Exception:
            pass

    # Play sound file or system default when sound is enabled
    if sound:
        play_sound_file(sound_file, "Windows")


# ── Main notify dispatcher ────────────────────────────────────────────────────
def notify(
    title: str,
    message: str,
    urgency: str = "normal",
    sound: bool = True,
    sound_file: Optional[str] = None,
    slack_config: Optional[dict] = None,
):
    system = platform.system()
    log.debug("notify [%s] -> %s", urgency, title)
    if system == "Linux":
        _notify_linux(title, message, urgency, sound, sound_file)
    elif system == "Darwin":
        _notify_mac(title, message, urgency, sound, sound_file)
    elif system == "Windows":
        _notify_windows(title, message, urgency, sound, sound_file)
    else:
        log.warning("Unsupported platform for notifications: %s", system)

    if slack_config and slack_config.get("enabled"):
        if slack_config.get("webhook_url"):
            _notify_slack_webhook(title, message, slack_config["webhook_url"])
        elif slack_config.get("bot_token") and slack_config.get("channel"):
            _notify_slack_bot(
                title,
                message,
                slack_config["bot_token"],
                slack_config["channel"],
                urgency,
            )


# ── Slack notification helpers ────────────────────────────────────────────────
def _notify_slack_webhook(title: str, message: str, webhook_url: str) -> None:
    try:
        payload = {
            "text": f"*{title}*\n{message}",
            "username": "kim reminder",
            "icon_emoji": ":bell:",
        }

        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            webhook_url, data=data, headers={"Content-Type": "application/json"}
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            body = resp.read().decode("utf-8", errors="replace").strip()
        # Slack Incoming Webhooks return "ok" on success; anything else is an error
        if body and body != "ok":
            log.warning("Slack webhook returned unexpected response: %r", body)
        log.debug("Slack webhook notification sent")
    except urllib.error.HTTPError as e:
        # Do NOT log webhook_url — it is a secret
        log.error("Slack webhook HTTP error: %s %s", e.code, e.reason)
    except urllib.error.URLError as e:
        log.error("Slack webhook network error: %s", e.reason)
    except Exception as e:
        log.error("Slack webhook failed: %s", type(e).__name__)


def _notify_slack_bot(
    title: str, message: str, bot_token: str, channel: str, urgency: str = "normal"
) -> None:
    try:
        urgency_emoji = {
            "low": ":information_source:",
            "normal": ":bell:",
            "critical": ":rotating_light:",
        }
        emoji = urgency_emoji.get(urgency, ":bell:")

        payload = {
            "channel": channel,
            "text": f"{emoji} *{title}*\n{message}",
            "username": "kim reminder",
            "icon_emoji": ":bell:",
        }

        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            "https://slack.com/api/chat.postMessage",
            data=data,
            headers={
                "Content-Type": "application/json",
                # bot_token deliberately not logged anywhere
                "Authorization": f"Bearer {bot_token}",
            },
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            body = resp.read().decode("utf-8", errors="replace")
        try:
            result = json.loads(body)
            if not result.get("ok"):
                log.warning(
                    "Slack bot API returned ok=false: %s",
                    result.get("error", "unknown"),
                )
        except (json.JSONDecodeError, AttributeError):
            log.warning("Slack bot returned non-JSON response: %r", body[:200])
        log.debug("Slack bot notification sent")
    except urllib.error.HTTPError as e:
        log.error("Slack bot HTTP error: %s %s", e.code, e.reason)
    except urllib.error.URLError as e:
        log.error("Slack bot network error: %s", e.reason)
    except Exception as e:
        log.error("Slack bot failed: %s", type(e).__name__)
