"""FastAPI exception handler that maps ``ServiceError`` to ``APIErrorResponse``.

Register with ``configure_versioned_api``::

    from csrd.service import ServiceError, service_exception_handler
    from csrd.versioning import VersionedApiConfig

    configure_versioned_api(
        app,
        version_mapping=VERSIONS,
        config=VersionedApiConfig(
            ex_handlers=[(ServiceError, service_exception_handler)],
        ),
    )

Or register directly on a plain FastAPI app::

    app.add_exception_handler(ServiceError, service_exception_handler)
"""

from __future__ import annotations

import contextlib
import datetime
import uuid
from datetime import UTC

from fastapi import Request
from fastapi.responses import JSONResponse

from csrd.models.errors import APIErrorResponse, APIVersion, Error, ErrorMeta

from ._errors import ServiceError


def _get_request_id(request: Request) -> str:
    """Best-effort extraction of request ID from scope, falling back to a UUID."""
    try:
        return str(request.scope["_request_context"]["hit_id"])
    except (KeyError, TypeError):
        return str(uuid.uuid4())


def _get_api_version(request: Request) -> APIVersion:
    served = None
    with contextlib.suppress(AttributeError, TypeError):
        served = request.scope.get("api_version")  # type: ignore[union-attr]
    return APIVersion(served=served)


async def service_exception_handler(request: Request, exc: ServiceError) -> JSONResponse:
    """Convert a :class:`ServiceError` into a structured ``APIErrorResponse``."""
    errors: list[Error] = []
    if exc.detail or exc.code:
        errors.append(Error(title=exc.message, detail=exc.detail, code=exc.code))

    body = APIErrorResponse(
        meta=ErrorMeta(
            status=exc.status_code,
            error=exc.message,
            method=request.method,
            path=request.url.path,
            request_id=_get_request_id(request),
            timestamp=datetime.datetime.now(UTC),
            api_version=_get_api_version(request),
        ),
        errors=errors,
    )

    return JSONResponse(
        status_code=exc.status_code,
        content=body.as_dict(by_alias=True, mode="json"),
    )


__all__ = ("service_exception_handler",)
