"""
FlowBuilder - Assemble and write .tfl files.
"""

import json
import uuid
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Any


@dataclass
class NodeSpec:
    """Specification for a node in the flow."""
    node_id: str
    node_type: str
    name: str
    data: Dict[str, Any] = field(default_factory=dict)
    next_nodes: List[str] = field(default_factory=list)


class FlowBuilder:
    """
    Build Tableau Prep Flow (.tfl) files programmatically.

    Example:
        builder = FlowBuilder()
        input_id = builder.add_input_csv("sales.csv", "Sales Data")
        clean_id = builder.add_clean_step("Transform", input_id, actions=[...])
        output_id = builder.add_output_csv("output.csv", "Results", clean_id)
        builder.save("my_flow.tfl")
    """

    def __init__(self):
        self.nodes: Dict[str, NodeSpec] = {}
        self.connections: List[tuple] = []
        self.initial_nodes: List[str] = []

    def _generate_id(self) -> str:
        """Generate a UUID for node identification."""
        return str(uuid.uuid4())

    def add_node(self, node_type: str, name: str, data: dict = None,
                 input_nodes: List[str] = None) -> str:
        """
        Add a generic node to the flow.

        Args:
            node_type: Tableau node type (e.g., ".v1.LoadCsv")
            name: Human-readable name
            data: Node-specific data
            input_nodes: List of node IDs this node receives input from

        Returns:
            Node ID
        """
        node_id = self._generate_id()

        spec = NodeSpec(
            node_id=node_id,
            node_type=node_type,
            name=name,
            data=data or {}
        )

        self.nodes[node_id] = spec

        # Track connections
        if input_nodes:
            for input_id in input_nodes:
                if input_id in self.nodes:
                    self.nodes[input_id].next_nodes.append(node_id)
                    self.connections.append((input_id, node_id))
        else:
            # No inputs = initial node
            self.initial_nodes.append(node_id)

        return node_id

    def add_input_csv(self, file_path: str, name: str) -> str:
        """Add a CSV input node."""
        return self.add_node(
            node_type=".v1.LoadCsv",
            name=name,
            data={
                "connectionId": self._generate_id(),
                "filePath": file_path,
                "baseType": "input"
            }
        )

    def add_input_excel(self, file_path: str, name: str, sheet: str = None) -> str:
        """Add an Excel input node."""
        data = {
            "connectionId": self._generate_id(),
            "filePath": file_path,
            "baseType": "input"
        }
        if sheet:
            data["sheet"] = sheet
        return self.add_node(
            node_type=".v1.LoadExcel",
            name=name,
            data=data
        )

    def add_clean_step(self, name: str, input_node: str,
                       actions: List[dict] = None) -> str:
        """Add a clean/transform step."""
        return self.add_node(
            node_type=".v1.Container",
            name=name,
            data={
                "baseType": "transform",
                "actions": actions or []
            },
            input_nodes=[input_node]
        )

    def add_calculated_field(self, name: str, input_node: str,
                             column_name: str, expression: str) -> str:
        """Add a calculated field (AddColumn)."""
        return self.add_node(
            node_type=".v1.AddColumn",
            name=name,
            data={
                "baseType": "transform",
                "columnName": column_name,
                "expression": expression
            },
            input_nodes=[input_node]
        )

    def add_rename(self, name: str, input_node: str,
                   renames: Dict[str, str]) -> str:
        """Add a rename step."""
        actions = [
            {"type": "rename", "columnName": old, "newName": new}
            for old, new in renames.items()
        ]
        return self.add_clean_step(name, input_node, actions)

    def add_filter(self, name: str, input_node: str,
                   field: str, operator: str, value: Any) -> str:
        """Add a filter step."""
        return self.add_node(
            node_type=".v1.Filter",
            name=name,
            data={
                "baseType": "transform",
                "conditions": [{
                    "field": field,
                    "operator": operator,
                    "value": value
                }]
            },
            input_nodes=[input_node]
        )

    def add_remap(self, name: str, input_node: str,
                  column_name: str, values: Dict[str, List[str]]) -> str:
        """Add a remap (value replacement) step."""
        return self.add_node(
            node_type=".v2018_3_3.Remap",
            name=name,
            data={
                "baseType": "transform",
                "columnName": column_name,
                "values": values
            },
            input_nodes=[input_node]
        )

    def add_join(self, name: str, left_node: str, right_node: str,
                 join_type: str = "inner",
                 left_key: str = None, right_key: str = None) -> str:
        """Add a join step."""
        data = {
            "baseType": "transform",
            "joinType": join_type
        }
        if left_key and right_key:
            data["joinClauses"] = [{
                "leftColumn": left_key,
                "rightColumn": right_key
            }]
        return self.add_node(
            node_type=".v2018_2_3.SuperJoin",
            name=name,
            data=data,
            input_nodes=[left_node, right_node]
        )

    def add_union(self, name: str, input_nodes: List[str]) -> str:
        """Add a union step."""
        return self.add_node(
            node_type=".v2018_2_3.SuperUnion",
            name=name,
            data={"baseType": "transform"},
            input_nodes=input_nodes
        )

    def add_aggregate(self, name: str, input_node: str,
                      group_by: List[str],
                      aggregations: List[Dict[str, str]]) -> str:
        """
        Add an aggregate step.

        Args:
            name: Step name
            input_node: Input node ID
            group_by: List of columns to group by
            aggregations: List of {"field": "col", "function": "sum"}
        """
        return self.add_node(
            node_type=".v1.SuperAggregate",
            name=name,
            data={
                "baseType": "transform",
                "groupByColumns": group_by,
                "aggregations": aggregations
            },
            input_nodes=[input_node]
        )

    def add_pivot(self, name: str, input_node: str,
                  pivot_columns: List[str],
                  var_name: str = "variable",
                  value_name: str = "value") -> str:
        """Add a pivot (columns to rows) step."""
        return self.add_node(
            node_type=".v1.Pivot",
            name=name,
            data={
                "baseType": "transform",
                "pivotType": "columns_to_rows",
                "pivotColumns": pivot_columns,
                "variableName": var_name,
                "valueName": value_name
            },
            input_nodes=[input_node]
        )

    def add_output_csv(self, file_path: str, name: str, input_node: str) -> str:
        """Add a CSV output node."""
        return self.add_node(
            node_type=".v1.WriteToCsv",
            name=name,
            data={
                "baseType": "output",
                "filePath": file_path
            },
            input_nodes=[input_node]
        )

    def add_output_excel(self, file_path: str, name: str, input_node: str) -> str:
        """Add an Excel output node."""
        return self.add_node(
            node_type=".v1.WriteToExcel",
            name=name,
            data={
                "baseType": "output",
                "filePath": file_path
            },
            input_nodes=[input_node]
        )

    def build_flow_json(self) -> dict:
        """Build the flow JSON structure."""
        nodes_dict = {}

        for node_id, spec in self.nodes.items():
            node_data = {
                "nodeType": spec.node_type,
                "name": spec.name,
                "id": node_id,
                "baseType": spec.data.get("baseType", "transform"),
                "nextNodes": [
                    {"namespace": "Default", "nextNodeId": nid, "nextNamespace": "Default"}
                    for nid in spec.next_nodes
                ],
                "serialize": False,
                "description": None,
                **{k: v for k, v in spec.data.items() if k != "baseType"}
            }
            nodes_dict[node_id] = node_data

        return {
            "parameters": {"parameters": {}},
            "initialNodes": self.initial_nodes,
            "nodes": nodes_dict,
            "connections": {},
            "connectionIds": [],
            "nodeProperties": {},
            "selection": [],
            "majorVersion": 2024,
            "minorVersion": 1,
            "documentId": self._generate_id()
        }

    def build_display_settings(self) -> dict:
        """Build display settings JSON."""
        return {
            "version": "1.0",
            "nodes": {}
        }

    def build_metadata(self) -> dict:
        """Build maestro metadata JSON."""
        return {
            "version": "2024.1",
            "buildNumber": "20241"
        }

    def save(self, output_path: str):
        """
        Save the flow to a .tfl file.

        Args:
            output_path: Path for the output .tfl file
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        flow_json = self.build_flow_json()
        display_settings = self.build_display_settings()
        metadata = self.build_metadata()

        with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            zf.writestr('flow', json.dumps(flow_json, indent=2))
            zf.writestr('displaySettings', json.dumps(display_settings, indent=2))
            zf.writestr('maestroMetadata', json.dumps(metadata, indent=2))

        return output_path
