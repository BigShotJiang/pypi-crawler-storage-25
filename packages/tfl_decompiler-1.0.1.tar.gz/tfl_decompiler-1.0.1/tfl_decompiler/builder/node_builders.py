"""
Node Builders - Fluent API for building specific node types.
"""

from typing import Any, Dict, List


class BaseNodeBuilder:
    """Base class for node builders."""

    def __init__(self, name: str):
        self.name = name
        self.data = {}

    def build(self) -> dict:
        """Build the node data dictionary."""
        return self.data.copy()


class InputNodeBuilder(BaseNodeBuilder):
    """Builder for input nodes."""

    def __init__(self, name: str):
        super().__init__(name)
        self.data["baseType"] = "input"

    def csv(self, file_path: str) -> "InputNodeBuilder":
        self.data["nodeType"] = ".v1.LoadCsv"
        self.data["filePath"] = file_path
        return self

    def excel(self, file_path: str, sheet: str = None) -> "InputNodeBuilder":
        self.data["nodeType"] = ".v1.LoadExcel"
        self.data["filePath"] = file_path
        if sheet:
            self.data["sheet"] = sheet
        return self

    def json(self, file_path: str) -> "InputNodeBuilder":
        self.data["nodeType"] = ".v1.LoadJson"
        self.data["filePath"] = file_path
        return self

    def database(self, connection_string: str, query: str) -> "InputNodeBuilder":
        self.data["nodeType"] = ".v1.LoadSql"
        self.data["connectionString"] = connection_string
        self.data["query"] = query
        return self


class CleanNodeBuilder(BaseNodeBuilder):
    """Builder for clean/transform nodes."""

    def __init__(self, name: str):
        super().__init__(name)
        self.data["baseType"] = "transform"
        self.data["nodeType"] = ".v1.Container"
        self.data["actions"] = []

    def rename(self, old_name: str, new_name: str) -> "CleanNodeBuilder":
        self.data["actions"].append({
            "type": "rename",
            "columnName": old_name,
            "newName": new_name
        })
        return self

    def remove_column(self, column_name: str) -> "CleanNodeBuilder":
        self.data["actions"].append({
            "type": "remove",
            "columnName": column_name
        })
        return self

    def change_type(self, column_name: str, new_type: str) -> "CleanNodeBuilder":
        self.data["actions"].append({
            "type": "changeType",
            "columnName": column_name,
            "newType": new_type
        })
        return self

    def filter(self, field: str, operator: str, value: Any) -> "CleanNodeBuilder":
        self.data["actions"].append({
            "type": "filter",
            "field": field,
            "operator": operator,
            "value": value
        })
        return self

    def replace(self, column_name: str, old_value: Any, new_value: Any) -> "CleanNodeBuilder":
        self.data["actions"].append({
            "type": "replace",
            "columnName": column_name,
            "oldValue": old_value,
            "newValue": new_value
        })
        return self

    def calculated_field(self, column_name: str, expression: str) -> "CleanNodeBuilder":
        self.data["actions"].append({
            "type": "calculate",
            "name": column_name,
            "expression": expression
        })
        return self

    def split(self, column_name: str, delimiter: str) -> "CleanNodeBuilder":
        self.data["actions"].append({
            "type": "split",
            "columnName": column_name,
            "delimiter": delimiter
        })
        return self

    def merge(self, columns: List[str], new_name: str, separator: str = "") -> "CleanNodeBuilder":
        self.data["actions"].append({
            "type": "merge",
            "columns": columns,
            "newName": new_name,
            "separator": separator
        })
        return self

    def fill_null(self, column_name: str, value: Any) -> "CleanNodeBuilder":
        self.data["actions"].append({
            "type": "fillNull",
            "columnName": column_name,
            "value": value
        })
        return self

    def drop_null(self, column_name: str = None) -> "CleanNodeBuilder":
        action = {"type": "dropNull"}
        if column_name:
            action["columnName"] = column_name
        self.data["actions"].append(action)
        return self

    def trim(self, column_name: str) -> "CleanNodeBuilder":
        self.data["actions"].append({
            "type": "trim",
            "columnName": column_name
        })
        return self

    def uppercase(self, column_name: str) -> "CleanNodeBuilder":
        self.data["actions"].append({
            "type": "uppercase",
            "columnName": column_name
        })
        return self

    def lowercase(self, column_name: str) -> "CleanNodeBuilder":
        self.data["actions"].append({
            "type": "lowercase",
            "columnName": column_name
        })
        return self


class JoinNodeBuilder(BaseNodeBuilder):
    """Builder for join nodes."""

    def __init__(self, name: str):
        super().__init__(name)
        self.data["baseType"] = "transform"
        self.data["nodeType"] = ".v2018_2_3.SuperJoin"
        self.data["joinClauses"] = []

    def inner(self) -> "JoinNodeBuilder":
        self.data["joinType"] = "inner"
        return self

    def left(self) -> "JoinNodeBuilder":
        self.data["joinType"] = "left"
        return self

    def right(self) -> "JoinNodeBuilder":
        self.data["joinType"] = "right"
        return self

    def outer(self) -> "JoinNodeBuilder":
        self.data["joinType"] = "outer"
        return self

    def on(self, left_column: str, right_column: str) -> "JoinNodeBuilder":
        self.data["joinClauses"].append({
            "leftColumn": left_column,
            "rightColumn": right_column
        })
        return self


class UnionNodeBuilder(BaseNodeBuilder):
    """Builder for union nodes."""

    def __init__(self, name: str):
        super().__init__(name)
        self.data["baseType"] = "transform"
        self.data["nodeType"] = ".v2018_2_3.SuperUnion"

    def remove_mismatched(self, remove: bool = True) -> "UnionNodeBuilder":
        self.data["removeMismatched"] = remove
        return self

    def field_mapping(self, mappings: Dict[str, str]) -> "UnionNodeBuilder":
        self.data["fieldMappings"] = mappings
        return self


class AggregateNodeBuilder(BaseNodeBuilder):
    """Builder for aggregate nodes."""

    def __init__(self, name: str):
        super().__init__(name)
        self.data["baseType"] = "transform"
        self.data["nodeType"] = ".v1.SuperAggregate"
        self.data["groupByColumns"] = []
        self.data["aggregations"] = []

    def group_by(self, *columns: str) -> "AggregateNodeBuilder":
        self.data["groupByColumns"].extend(columns)
        return self

    def sum(self, column: str, alias: str = None) -> "AggregateNodeBuilder":
        self.data["aggregations"].append({
            "field": column,
            "function": "sum",
            "outputName": alias or f"{column}_sum"
        })
        return self

    def avg(self, column: str, alias: str = None) -> "AggregateNodeBuilder":
        self.data["aggregations"].append({
            "field": column,
            "function": "avg",
            "outputName": alias or f"{column}_avg"
        })
        return self

    def count(self, column: str, alias: str = None) -> "AggregateNodeBuilder":
        self.data["aggregations"].append({
            "field": column,
            "function": "count",
            "outputName": alias or f"{column}_count"
        })
        return self

    def count_distinct(self, column: str, alias: str = None) -> "AggregateNodeBuilder":
        self.data["aggregations"].append({
            "field": column,
            "function": "countd",
            "outputName": alias or f"{column}_countd"
        })
        return self

    def min(self, column: str, alias: str = None) -> "AggregateNodeBuilder":
        self.data["aggregations"].append({
            "field": column,
            "function": "min",
            "outputName": alias or f"{column}_min"
        })
        return self

    def max(self, column: str, alias: str = None) -> "AggregateNodeBuilder":
        self.data["aggregations"].append({
            "field": column,
            "function": "max",
            "outputName": alias or f"{column}_max"
        })
        return self

    def median(self, column: str, alias: str = None) -> "AggregateNodeBuilder":
        self.data["aggregations"].append({
            "field": column,
            "function": "median",
            "outputName": alias or f"{column}_median"
        })
        return self


class PivotNodeBuilder(BaseNodeBuilder):
    """Builder for pivot nodes."""

    def __init__(self, name: str):
        super().__init__(name)
        self.data["baseType"] = "transform"
        self.data["nodeType"] = ".v1.Pivot"

    def columns_to_rows(self, columns: List[str],
                        var_name: str = "variable",
                        value_name: str = "value") -> "PivotNodeBuilder":
        self.data["pivotType"] = "columns_to_rows"
        self.data["pivotColumns"] = columns
        self.data["variableName"] = var_name
        self.data["valueName"] = value_name
        return self

    def rows_to_columns(self, index: List[str], columns: str,
                        values: str, aggfunc: str = "first") -> "PivotNodeBuilder":
        self.data["pivotType"] = "rows_to_columns"
        self.data["index"] = index
        self.data["columns"] = columns
        self.data["values"] = values
        self.data["aggfunc"] = aggfunc
        return self


class FilterNodeBuilder(BaseNodeBuilder):
    """Builder for filter nodes."""

    def __init__(self, name: str):
        super().__init__(name)
        self.data["baseType"] = "transform"
        self.data["nodeType"] = ".v1.Filter"
        self.data["conditions"] = []

    def equals(self, field: str, value: Any) -> "FilterNodeBuilder":
        self.data["conditions"].append({
            "field": field,
            "operator": "equals",
            "value": value
        })
        return self

    def not_equals(self, field: str, value: Any) -> "FilterNodeBuilder":
        self.data["conditions"].append({
            "field": field,
            "operator": "notEquals",
            "value": value
        })
        return self

    def greater_than(self, field: str, value: Any) -> "FilterNodeBuilder":
        self.data["conditions"].append({
            "field": field,
            "operator": "greaterThan",
            "value": value
        })
        return self

    def less_than(self, field: str, value: Any) -> "FilterNodeBuilder":
        self.data["conditions"].append({
            "field": field,
            "operator": "lessThan",
            "value": value
        })
        return self

    def contains(self, field: str, value: str) -> "FilterNodeBuilder":
        self.data["conditions"].append({
            "field": field,
            "operator": "contains",
            "value": value
        })
        return self

    def is_null(self, field: str) -> "FilterNodeBuilder":
        self.data["conditions"].append({
            "field": field,
            "operator": "isNull"
        })
        return self

    def is_not_null(self, field: str) -> "FilterNodeBuilder":
        self.data["conditions"].append({
            "field": field,
            "operator": "isNotNull"
        })
        return self

    def in_list(self, field: str, values: List[Any]) -> "FilterNodeBuilder":
        self.data["conditions"].append({
            "field": field,
            "operator": "in",
            "value": values
        })
        return self


class OutputNodeBuilder(BaseNodeBuilder):
    """Builder for output nodes."""

    def __init__(self, name: str):
        super().__init__(name)
        self.data["baseType"] = "output"

    def csv(self, file_path: str) -> "OutputNodeBuilder":
        self.data["nodeType"] = ".v1.WriteToCsv"
        self.data["filePath"] = file_path
        return self

    def excel(self, file_path: str, sheet: str = None) -> "OutputNodeBuilder":
        self.data["nodeType"] = ".v1.WriteToExcel"
        self.data["filePath"] = file_path
        if sheet:
            self.data["sheet"] = sheet
        return self

    def database(self, connection_string: str, table: str,
                 mode: str = "replace") -> "OutputNodeBuilder":
        self.data["nodeType"] = ".v1.WriteToSql"
        self.data["connectionString"] = connection_string
        self.data["tableName"] = table
        self.data["writeMode"] = mode
        return self

    def hyper(self, file_path: str) -> "OutputNodeBuilder":
        self.data["nodeType"] = ".v1.WriteToHyper"
        self.data["filePath"] = file_path
        return self
