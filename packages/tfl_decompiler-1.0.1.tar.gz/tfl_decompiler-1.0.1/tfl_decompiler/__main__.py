"""
Allow running as: python -m tfl_decompiler
"""

from .main import main

if __name__ == "__main__":
    main()
