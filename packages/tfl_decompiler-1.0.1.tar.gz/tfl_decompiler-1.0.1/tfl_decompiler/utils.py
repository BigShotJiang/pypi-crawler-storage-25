"""
Utility functions for TFL Decompiler.
"""

import re
from typing import Any


def sanitize_variable_name(name: str) -> str:
    """
    Convert a string to a valid Python variable name.

    Args:
        name: Original string (e.g., "Sales Data 2024")

    Returns:
        Valid Python identifier (e.g., "sales_data_2024")
    """
    # Replace spaces and special chars with underscores
    sanitized = re.sub(r'[^a-zA-Z0-9_]', '_', name)
    # Remove consecutive underscores
    sanitized = re.sub(r'_+', '_', sanitized)
    # Remove leading/trailing underscores
    sanitized = sanitized.strip('_')
    # Ensure it starts with a letter or underscore
    if sanitized and sanitized[0].isdigit():
        sanitized = 'df_' + sanitized
    # Default name if empty
    if not sanitized:
        sanitized = 'df_step'
    return sanitized.lower()


def indent_code(code: str, level: int = 1) -> str:
    """
    Indent code by a specified number of levels (4 spaces each).

    Args:
        code: Code string to indent
        level: Number of indentation levels

    Returns:
        Indented code string
    """
    indent = '    ' * level
    lines = code.split('\n')
    return '\n'.join(indent + line if line.strip() else line for line in lines)


def escape_string(s: str) -> str:
    """
    Escape a string for use in Python code.

    Args:
        s: String to escape

    Returns:
        Escaped string safe for code generation
    """
    return s.replace('\\', '\\\\').replace("'", "\\'").replace('"', '\\"')


def deep_get(obj: dict, path: str, default: Any = None) -> Any:
    """
    Get a nested value from a dictionary using dot notation.

    Args:
        obj: Dictionary to search
        path: Dot-separated path (e.g., "node.action.type")
        default: Default value if path not found

    Returns:
        Value at path or default
    """
    keys = path.split('.')
    current = obj
    for key in keys:
        if isinstance(current, dict) and key in current:
            current = current[key]
        else:
            return default
    return current


def find_keys_containing(obj: dict, substring: str) -> list:
    """
    Find all keys in a dictionary (recursively) that contain a substring.

    Args:
        obj: Dictionary to search
        substring: Substring to look for in keys

    Returns:
        List of matching keys with their paths
    """
    matches = []

    def search(d, path=""):
        if isinstance(d, dict):
            for key, value in d.items():
                current_path = f"{path}.{key}" if path else key
                if substring.lower() in key.lower():
                    matches.append(current_path)
                search(value, current_path)
        elif isinstance(d, list):
            for i, item in enumerate(d):
                search(item, f"{path}[{i}]")

    search(obj)
    return matches


def detect_file_type(path: str) -> str:
    """
    Detect file type from path/extension.

    Args:
        path: File path string

    Returns:
        File type identifier
    """
    path_lower = path.lower()
    if path_lower.endswith('.csv'):
        return 'csv'
    elif path_lower.endswith(('.xlsx', '.xls')):
        return 'excel'
    elif path_lower.endswith('.json'):
        return 'json'
    elif path_lower.endswith('.parquet'):
        return 'parquet'
    elif path_lower.endswith('.hyper'):
        return 'hyper'
    else:
        return 'unknown'


def format_dict_for_code(d: dict, indent_level: int = 0) -> str:
    """
    Format a dictionary as Python code.

    Args:
        d: Dictionary to format
        indent_level: Starting indentation level

    Returns:
        Formatted dictionary string
    """
    if not d:
        return '{}'

    indent = '    ' * indent_level
    inner_indent = '    ' * (indent_level + 1)

    items = []
    for key, value in d.items():
        if isinstance(value, str):
            items.append(f"{inner_indent}'{escape_string(key)}': '{escape_string(value)}'")
        elif isinstance(value, dict):
            items.append(f"{inner_indent}'{escape_string(key)}': {format_dict_for_code(value, indent_level + 1)}")
        elif isinstance(value, list):
            items.append(f"{inner_indent}'{escape_string(key)}': {value}")
        else:
            items.append(f"{inner_indent}'{escape_string(key)}': {value}")

    return '{\n' + ',\n'.join(items) + f'\n{indent}}}'
