"""
Flow Parser - Parse flow JSON into a graph of nodes.

Handles:
- Extracting nodes from flow JSON
- Building node connections/dependencies
- Topological sort for execution order
"""

from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple

from .nodes.base import BaseNode
from .node_registry import registry


@dataclass
class FlowGraph:
    """Represents the parsed flow as a graph of nodes."""
    nodes: Dict[str, BaseNode] = field(default_factory=dict)
    connections: List[Tuple[str, str]] = field(default_factory=list)
    execution_order: List[str] = field(default_factory=list)
    input_nodes: List[str] = field(default_factory=list)
    output_nodes: List[str] = field(default_factory=list)


class FlowParser:
    """
    Parses Tableau Prep flow JSON into a structured graph.

    Handles adaptive discovery of flow structure for different
    Tableau Prep versions and formats.
    """

    # Common key names for nodes array
    NODE_KEYS = ['nodes', 'steps', 'elements', 'items', 'objects']

    # Common key names for connections array
    CONNECTION_KEYS = ['connections', 'links', 'edges', 'transitions', 'flows']

    def __init__(self, flow_data: dict):
        """
        Initialize parser with flow JSON data.

        Args:
            flow_data: Parsed flow JSON from TFL file
        """
        self.flow_data = flow_data
        self.discovered_structure = {}

    def parse(self) -> FlowGraph:
        """
        Parse the flow data into a graph structure.

        Returns:
            FlowGraph with nodes, connections, and execution order
        """
        graph = FlowGraph()

        # Extract nodes
        raw_nodes = self._extract_nodes()
        for node_id, node_data in raw_nodes.items():
            handler = registry.create_node(node_data, node_id)
            graph.nodes[node_id] = handler

        # Extract connections
        graph.connections = self._extract_connections()

        # Apply connections to nodes
        for source_id, target_id in graph.connections:
            if source_id in graph.nodes and target_id in graph.nodes:
                graph.nodes[source_id].add_output_connection(target_id)
                graph.nodes[target_id].add_input_connection(source_id)

        # Identify input and output nodes
        graph.input_nodes = self._find_input_nodes(graph.nodes)
        graph.output_nodes = self._find_output_nodes(graph.nodes)

        # Build execution order
        graph.execution_order = self._topological_sort(graph)

        return graph

    def _extract_nodes(self) -> Dict[str, dict]:
        """
        Extract nodes from flow data.

        Handles both array-based and dictionary-based node structures.
        For Tableau format, only extracts top-level nodes (not nested
        container contents) to maintain proper connection graph.

        Returns:
            Dictionary of node_id -> node_data
        """
        nodes = {}

        # Try known keys for nodes
        for key in self.NODE_KEYS:
            if key in self.flow_data:
                raw_nodes = self.flow_data[key]
                if isinstance(raw_nodes, list):
                    for i, node in enumerate(raw_nodes):
                        if isinstance(node, dict):
                            node_id = self._get_node_id(node, i)
                            nodes[node_id] = node
                    self.discovered_structure['nodes_key'] = key
                    return nodes
                elif isinstance(raw_nodes, dict):
                    # Tableau format: nodes is a dict with UUIDs as keys
                    # Only extract top-level nodes to maintain proper flow
                    for node_id, node_data in raw_nodes.items():
                        if isinstance(node_data, dict):
                            nodes[node_id] = node_data
                    self.discovered_structure['nodes_key'] = key
                    return nodes

        # Adaptive discovery - look for arrays with node-like objects
        for key, value in self.flow_data.items():
            if isinstance(value, list) and value:
                first_item = value[0]
                if isinstance(first_item, dict):
                    if self._looks_like_node(first_item):
                        for i, node in enumerate(value):
                            if isinstance(node, dict):
                                node_id = self._get_node_id(node, i)
                                nodes[node_id] = node
                        self.discovered_structure['nodes_key'] = key
                        return nodes

        # If no nodes array found, treat top-level as single implicit flow
        if not nodes and self._looks_like_node(self.flow_data):
            nodes['root'] = self.flow_data

        return nodes

    def _extract_nested_nodes(self, node: dict, nodes: Dict[str, dict]):
        """
        Extract nested nodes from containers (loomContainer).

        Args:
            node: Parent node that may contain nested nodes
            nodes: Dictionary to add extracted nodes to
        """
        # Check for loomContainer (Tableau's nested container format)
        if 'loomContainer' in node:
            container = node['loomContainer']
            if isinstance(container, dict) and 'nodes' in container:
                nested_nodes = container['nodes']
                if isinstance(nested_nodes, dict):
                    for nested_id, nested_data in nested_nodes.items():
                        if isinstance(nested_data, dict):
                            nodes[nested_id] = nested_data
                            # Recursively extract from deeper nesting
                            self._extract_nested_nodes(nested_data, nodes)

        # Check for other container formats
        for container_key in ['container', 'children', 'subNodes', 'innerNodes']:
            if container_key in node:
                container = node[container_key]
                if isinstance(container, dict) and 'nodes' in container:
                    nested = container['nodes']
                    if isinstance(nested, dict):
                        for nid, ndata in nested.items():
                            if isinstance(ndata, dict):
                                nodes[nid] = ndata
                                self._extract_nested_nodes(ndata, nodes)
                    elif isinstance(nested, list):
                        for i, ndata in enumerate(nested):
                            if isinstance(ndata, dict):
                                nid = self._get_node_id(ndata, i)
                                nodes[nid] = ndata
                                self._extract_nested_nodes(ndata, nodes)

    def _extract_connections(self) -> List[Tuple[str, str]]:
        """
        Extract connections between nodes.

        Handles:
        - Array-based connections
        - Dictionary-based connections (Tableau format)
        - Inline connections from nextNodes in each node

        Returns:
            List of (source_id, target_id) tuples
        """
        connections = []

        # Try known keys for connections
        for key in self.CONNECTION_KEYS:
            if key in self.flow_data:
                raw_conns = self.flow_data[key]
                if isinstance(raw_conns, list):
                    for conn in raw_conns:
                        parsed = self._parse_connection(conn)
                        if parsed:
                            connections.append(parsed)
                    self.discovered_structure['connections_key'] = key
                elif isinstance(raw_conns, dict):
                    # Tableau format: connections is a dict with UUIDs as keys
                    for conn_id, conn_data in raw_conns.items():
                        if isinstance(conn_data, dict):
                            parsed = self._parse_connection(conn_data)
                            if parsed:
                                connections.append(parsed)
                    self.discovered_structure['connections_key'] = key

        # Always extract inline connections from nodes (nextNodes)
        nodes_key = self.discovered_structure.get('nodes_key')
        if nodes_key and nodes_key in self.flow_data:
            raw_nodes = self.flow_data[nodes_key]
            if isinstance(raw_nodes, dict):
                # Dictionary-based nodes (Tableau format)
                for node_id, node_data in raw_nodes.items():
                    if isinstance(node_data, dict):
                        inline_conns = self._extract_inline_connections(node_data, node_id)
                        connections.extend(inline_conns)
                        # Also extract from nested containers
                        self._extract_nested_connections(node_data, connections)
            elif isinstance(raw_nodes, list):
                for i, node in enumerate(raw_nodes):
                    if isinstance(node, dict):
                        node_id = self._get_node_id(node, i)
                        inline_conns = self._extract_inline_connections(node, node_id)
                        connections.extend(inline_conns)

        # Remove duplicates while preserving order
        seen = set()
        unique_connections = []
        for conn in connections:
            if conn not in seen:
                seen.add(conn)
                unique_connections.append(conn)

        return unique_connections

    def _extract_nested_connections(self, node: dict, connections: List[Tuple[str, str]]):
        """
        Extract connections from nested containers.

        Args:
            node: Node that may contain nested nodes
            connections: List to append connections to
        """
        if 'loomContainer' in node:
            container = node['loomContainer']
            if isinstance(container, dict) and 'nodes' in container:
                nested_nodes = container['nodes']
                if isinstance(nested_nodes, dict):
                    for nested_id, nested_data in nested_nodes.items():
                        if isinstance(nested_data, dict):
                            inline_conns = self._extract_inline_connections(nested_data, nested_id)
                            connections.extend(inline_conns)
                            self._extract_nested_connections(nested_data, connections)

    def _parse_connection(self, conn: dict) -> Optional[Tuple[str, str]]:
        """
        Parse a single connection object.

        Args:
            conn: Connection data

        Returns:
            (source_id, target_id) tuple or None
        """
        if not isinstance(conn, dict):
            return None

        source = None
        target = None

        # Try different key names for source
        for key in ['source', 'from', 'sourceNode', 'fromId', 'inputNode', 'sourceId']:
            if key in conn:
                source = str(conn[key])
                break

        # Try different key names for target
        for key in ['target', 'to', 'targetNode', 'toId', 'outputNode', 'targetId']:
            if key in conn:
                target = str(conn[key])
                break

        if source and target:
            return (source, target)

        return None

    def _extract_inline_connections(self, node: dict, node_id: str) -> List[Tuple[str, str]]:
        """
        Extract connections that are defined inline within a node.

        Handles Tableau's nextNodes format:
        "nextNodes": [{"nextNodeId": "...", "namespace": "..."}]

        Args:
            node: Node data
            node_id: This node's ID

        Returns:
            List of connections
        """
        connections = []

        # Check for inputs array
        for key in ['inputs', 'inputNodes', 'sources', 'dependencies']:
            if key in node:
                inputs = node[key]
                if isinstance(inputs, list):
                    for inp in inputs:
                        if isinstance(inp, str):
                            connections.append((inp, node_id))
                        elif isinstance(inp, dict):
                            inp_id = self._get_node_id(inp)
                            if inp_id:
                                connections.append((inp_id, node_id))
                elif isinstance(inputs, str):
                    connections.append((inputs, node_id))

        # Handle Tableau's nextNodes format
        if 'nextNodes' in node:
            next_nodes = node['nextNodes']
            if isinstance(next_nodes, list):
                for next_item in next_nodes:
                    if isinstance(next_item, dict):
                        # Tableau format: {"nextNodeId": "...", "namespace": "..."}
                        next_id = next_item.get('nextNodeId') or next_item.get('nextNode')
                        if next_id:
                            connections.append((node_id, next_id))
                    elif isinstance(next_item, str):
                        connections.append((node_id, next_item))

        # Check for other nextNode variations
        for key in ['nextNode', 'output', 'target', 'downstream']:
            if key in node:
                next_node = node[key]
                if isinstance(next_node, str):
                    connections.append((node_id, next_node))
                elif isinstance(next_node, list):
                    for n in next_node:
                        if isinstance(n, str):
                            connections.append((node_id, n))

        return connections

    def _get_node_id(self, node: dict, fallback_index: int = 0) -> str:
        """
        Extract node ID from node data.

        Args:
            node: Node data dictionary
            fallback_index: Index to use if no ID found

        Returns:
            Node ID string
        """
        for key in ['nodeId', 'id', 'stepId', 'uid', 'name']:
            if key in node:
                return str(node[key])
        return f"node_{fallback_index}"

    def _looks_like_node(self, obj: dict) -> bool:
        """
        Check if an object looks like a flow node.

        Args:
            obj: Dictionary to check

        Returns:
            True if object appears to be a node
        """
        if not isinstance(obj, dict):
            return False

        # Node indicators
        node_indicators = [
            'nodeId', 'id', 'type', 'stepType', 'nodeType',
            'name', 'actions', 'inputs', 'outputs',
            'connection', 'filePath', 'tableName'
        ]

        obj_keys_lower = {k.lower() for k in obj.keys()}
        indicator_lower = {ind.lower() for ind in node_indicators}

        return bool(obj_keys_lower & indicator_lower)

    def _find_input_nodes(self, nodes: Dict[str, BaseNode]) -> List[str]:
        """
        Find nodes that are inputs (no incoming connections).

        Args:
            nodes: Dictionary of nodes

        Returns:
            List of input node IDs
        """
        input_nodes = []
        for node_id, node in nodes.items():
            if not node.input_connections:
                # Also check if node type is input-like
                node_type = node.get_node_type()
                if any(x in node_type for x in ['input', 'source', 'load', 'read']):
                    input_nodes.append(node_id)
                elif not node.input_connections:
                    input_nodes.append(node_id)

        return input_nodes

    def _find_output_nodes(self, nodes: Dict[str, BaseNode]) -> List[str]:
        """
        Find nodes that are outputs (no outgoing connections).

        Args:
            nodes: Dictionary of nodes

        Returns:
            List of output node IDs
        """
        output_nodes = []
        for node_id, node in nodes.items():
            if not node.output_connections:
                # Also check if node type is output-like
                node_type = node.get_node_type()
                if any(x in node_type for x in ['output', 'write', 'export', 'publish']):
                    output_nodes.append(node_id)
                elif not node.output_connections:
                    output_nodes.append(node_id)

        return output_nodes

    def _topological_sort(self, graph: FlowGraph) -> List[str]:
        """
        Compute topological order for node execution.

        Uses Kahn's algorithm for stable ordering.

        Args:
            graph: FlowGraph with nodes and connections

        Returns:
            List of node IDs in execution order
        """
        # Build adjacency list and in-degree count
        in_degree = defaultdict(int)
        adjacency = defaultdict(list)

        for node_id in graph.nodes:
            in_degree[node_id] = 0

        for source, target in graph.connections:
            if source in graph.nodes and target in graph.nodes:
                adjacency[source].append(target)
                in_degree[target] += 1

        # Initialize queue with nodes that have no dependencies
        queue = deque()
        for node_id in graph.nodes:
            if in_degree[node_id] == 0:
                queue.append(node_id)

        # Process nodes
        result = []
        while queue:
            node_id = queue.popleft()
            result.append(node_id)

            for neighbor in adjacency[node_id]:
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)

        # Check for cycles
        if len(result) != len(graph.nodes):
            # There's a cycle - fall back to simple ordering
            remaining = set(graph.nodes.keys()) - set(result)
            result.extend(sorted(remaining))

        return result
