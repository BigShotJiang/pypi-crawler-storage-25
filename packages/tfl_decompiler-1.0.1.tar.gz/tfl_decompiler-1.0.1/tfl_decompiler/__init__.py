"""
TFL Decompiler - Convert Tableau Prep Flow files to Python/pandas scripts.

This package provides a complete pipeline to:
1. Extract and parse .tfl files (ZIP archives with JSON)
2. Parse flow structure into a node graph
3. Convert each node type to pandas operations
4. Generate clean, executable Python code
"""

__version__ = "1.0.0"
__author__ = "TFL Decompiler"

from .extractor import TFLExtractor
from .flow_parser import FlowParser
from .code_generator import CodeGenerator
from .main import decompile

__all__ = [
    "TFLExtractor",
    "FlowParser",
    "CodeGenerator",
    "decompile",
]
