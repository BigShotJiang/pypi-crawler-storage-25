"""
Filter Node - Handle row filtering operations.

Maps Tableau filter operations to pandas:
- Boolean conditions -> df[condition]
- Expression filtering -> df.query()
"""

from .base import BaseNode, NodeContext
from ..utils import escape_string


class FilterNode(BaseNode):
    """Handler for Tableau Prep filter nodes."""

    NODE_TYPE = "filter"

    # Map Tableau operators to Python
    OPERATOR_MAP = {
        'equals': '==',
        'eq': '==',
        '=': '==',
        'notequals': '!=',
        'ne': '!=',
        '!=': '!=',
        '<>': '!=',
        'greaterthan': '>',
        'gt': '>',
        '>': '>',
        'lessthan': '<',
        'lt': '<',
        '<': '<',
        'greaterthanorequal': '>=',
        'gte': '>=',
        'ge': '>=',
        '>=': '>=',
        'lessthanorequal': '<=',
        'lte': '<=',
        'le': '<=',
        '<=': '<=',
        'contains': 'contains',
        'startswith': 'startswith',
        'endswith': 'endswith',
        'isnull': 'isnull',
        'isnotnull': 'notnull',
        'in': 'isin',
        'notin': 'not_isin',
    }

    def __init__(self, node_data: dict, node_id: str = ""):
        super().__init__(node_data, node_id)
        self.filter_conditions = self._extract_conditions()
        self.keep_or_exclude = self._check_keep_exclude()

    def _extract_conditions(self) -> list:
        """Extract filter conditions from node data."""
        conditions = []

        # Check for conditions array
        for key in ['conditions', 'filters', 'filterConditions', 'criteria']:
            if key in self.node_data:
                raw_conditions = self.node_data[key]
                if isinstance(raw_conditions, list):
                    for cond in raw_conditions:
                        parsed = self._parse_condition(cond)
                        if parsed:
                            conditions.append(parsed)
                    return conditions
                elif isinstance(raw_conditions, dict):
                    parsed = self._parse_condition(raw_conditions)
                    if parsed:
                        conditions.append(parsed)
                    return conditions

        # Check for single condition
        parsed = self._parse_condition(self.node_data)
        if parsed:
            conditions.append(parsed)

        # Check in actions
        for action in self.actions:
            if isinstance(action, dict):
                parsed = self._parse_condition(action)
                if parsed:
                    conditions.append(parsed)

        return conditions

    def _parse_condition(self, cond: dict) -> dict:
        """Parse a single filter condition."""
        if not isinstance(cond, dict):
            return None

        # Extract field
        field = None
        for key in ['field', 'column', 'columnName', 'fieldName']:
            if key in cond:
                field = cond[key]
                break

        # Extract operator
        operator = None
        for key in ['operator', 'op', 'comparison', 'type']:
            if key in cond:
                op_raw = str(cond[key]).lower().replace('_', '').replace(' ', '')
                operator = self.OPERATOR_MAP.get(op_raw, op_raw)
                break

        # Extract value(s)
        value = None
        for key in ['value', 'values', 'compareValue', 'filterValue']:
            if key in cond:
                value = cond[key]
                break

        # Extract expression (alternative to field/operator/value)
        expression = None
        for key in ['expression', 'filter', 'condition', 'formula']:
            if key in cond:
                expression = cond[key]
                break

        if expression:
            return {'type': 'expression', 'expression': expression}
        elif field and operator:
            return {
                'type': 'simple',
                'field': field,
                'operator': operator,
                'value': value
            }

        return None

    def _check_keep_exclude(self) -> str:
        """Check if filter is keep or exclude."""
        for key in ['mode', 'action', 'filterMode']:
            if key in self.node_data:
                mode = str(self.node_data[key]).lower()
                if 'exclude' in mode or 'remove' in mode:
                    return 'exclude'
        return 'keep'

    def get_description(self) -> str:
        """Get description for code comment."""
        num_conditions = len(self.filter_conditions)
        mode = "Keep rows" if self.keep_or_exclude == 'keep' else "Exclude rows"
        return f"Filter: {mode} matching {num_conditions} condition(s)"

    def get_imports(self) -> list:
        """Get required imports."""
        return ["import pandas as pd"]

    def to_pandas_code(self, ctx: NodeContext) -> str:
        """Generate pandas filter code."""
        var = ctx.variable_name
        input_var = ctx.input_variables[0] if ctx.input_variables else "df_input"
        indent = "    " * ctx.indent_level

        lines = []

        if not self.filter_conditions:
            lines.append(f"{indent}# Filter: No conditions found")
            lines.append(f"{indent}{var} = {input_var}.copy()")
            return '\n'.join(lines)

        # Build filter mask
        mask_parts = []
        for i, cond in enumerate(self.filter_conditions):
            if cond['type'] == 'expression':
                from ..expression_parser import ExpressionParser
                parser = ExpressionParser()
                expr = parser.parse(cond['expression'], input_var)
                mask_parts.append(f"({expr})")
            else:
                mask = self._build_simple_condition(input_var, cond)
                if mask:
                    mask_parts.append(f"({mask})")

        if not mask_parts:
            lines.append(f"{indent}{var} = {input_var}.copy()")
            return '\n'.join(lines)

        # Combine conditions with AND
        combined_mask = ' & '.join(mask_parts)

        if self.keep_or_exclude == 'exclude':
            combined_mask = f"~({combined_mask})"

        lines.append(f"{indent}_mask = {combined_mask}")
        lines.append(f"{indent}{var} = {input_var}[_mask].copy()")

        return '\n'.join(lines)

    def _build_simple_condition(self, df_var: str, cond: dict) -> str:
        """Build a simple pandas boolean condition."""
        field = cond['field']
        operator = cond['operator']
        value = cond.get('value')

        safe_field = escape_string(field)
        col_ref = f"{df_var}['{safe_field}']"

        if operator in ('==', '!=', '>', '<', '>=', '<='):
            if isinstance(value, str):
                return f"{col_ref} {operator} '{escape_string(value)}'"
            elif value is None:
                if operator == '==':
                    return f"{col_ref}.isna()"
                else:
                    return f"{col_ref}.notna()"
            else:
                return f"{col_ref} {operator} {value}"

        elif operator == 'contains':
            if isinstance(value, str):
                return f"{col_ref}.str.contains('{escape_string(value)}', na=False)"
            return f"{col_ref}.str.contains(str({value}), na=False)"

        elif operator == 'startswith':
            if isinstance(value, str):
                return f"{col_ref}.str.startswith('{escape_string(value)}', na=False)"
            return f"{col_ref}.str.startswith(str({value}), na=False)"

        elif operator == 'endswith':
            if isinstance(value, str):
                return f"{col_ref}.str.endswith('{escape_string(value)}', na=False)"
            return f"{col_ref}.str.endswith(str({value}), na=False)"

        elif operator == 'isnull':
            return f"{col_ref}.isna()"

        elif operator == 'notnull':
            return f"{col_ref}.notna()"

        elif operator == 'isin':
            if isinstance(value, list):
                values_str = ', '.join(
                    f"'{escape_string(v)}'" if isinstance(v, str) else str(v)
                    for v in value
                )
                return f"{col_ref}.isin([{values_str}])"
            return f"{col_ref}.isin({value})"

        elif operator == 'not_isin':
            if isinstance(value, list):
                values_str = ', '.join(
                    f"'{escape_string(v)}'" if isinstance(v, str) else str(v)
                    for v in value
                )
                return f"~{col_ref}.isin([{values_str}])"
            return f"~{col_ref}.isin({value})"

        else:
            return f"# Unknown operator: {operator}"
