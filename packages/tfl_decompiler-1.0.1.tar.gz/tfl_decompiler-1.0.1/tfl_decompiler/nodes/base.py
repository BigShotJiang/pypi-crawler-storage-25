"""
Base node class for all Tableau Prep node types.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class NodeContext:
    """Context information for code generation."""
    variable_name: str
    step_number: int
    input_variables: list = field(default_factory=list)
    indent_level: int = 1
    param_name: Optional[str] = None  # Parameter name for configurable paths


class BaseNode(ABC):
    """
    Abstract base class for all Tableau Prep node handlers.

    Each subclass maps a specific Tableau node type to pandas operations.
    """

    # Node type identifier (set by subclasses)
    NODE_TYPE: str = "base"

    def __init__(self, node_data: dict, node_id: str = ""):
        """
        Initialize node with raw data from flow JSON.

        Args:
            node_data: Raw node data from flow JSON
            node_id: Node identifier
        """
        self.node_data = node_data
        self.node_id = node_id or self._extract_id()
        self.name = self._extract_name()
        self.actions = self._extract_actions()
        self.input_connections = []
        self.output_connections = []

    def _extract_id(self) -> str:
        """Extract node ID from various possible keys."""
        for key in ['nodeId', 'id', 'nodeID', 'stepId', 'uid']:
            if key in self.node_data:
                return str(self.node_data[key])
        return ""

    def _extract_name(self) -> str:
        """Extract human-readable name from node data."""
        for key in ['name', 'caption', 'label', 'title', 'displayName']:
            if key in self.node_data:
                return str(self.node_data[key])
        return f"Step_{self.node_id}"

    def _extract_actions(self) -> list:
        """Extract actions/operations from node data."""
        for key in ['actions', 'operations', 'transforms', 'beforeActionAnnotations']:
            if key in self.node_data:
                val = self.node_data[key]
                return val if isinstance(val, list) else [val]
        return []

    def get_node_type(self) -> str:
        """Get the node type from data or subclass."""
        for key in ['type', 'nodeType', 'stepType', 'kind']:
            if key in self.node_data:
                return str(self.node_data[key]).lower()
        return self.NODE_TYPE

    @abstractmethod
    def to_pandas_code(self, ctx: NodeContext) -> str:
        """
        Generate pandas code for this node.

        Args:
            ctx: Context with variable names and step info

        Returns:
            Python/pandas code string
        """
        pass

    @abstractmethod
    def get_description(self) -> str:
        """
        Get a human-readable description of what this node does.

        Returns:
            Description string for comments
        """
        pass

    def get_imports(self) -> list:
        """
        Get required imports for this node's generated code.

        Returns:
            List of import statements
        """
        return []

    def get_dependencies(self) -> list:
        """
        Get IDs of nodes this node depends on.

        Returns:
            List of node IDs
        """
        return [conn for conn in self.input_connections]

    def add_input_connection(self, source_id: str):
        """Add an input connection from another node."""
        if source_id not in self.input_connections:
            self.input_connections.append(source_id)

    def add_output_connection(self, target_id: str):
        """Add an output connection to another node."""
        if target_id not in self.output_connections:
            self.output_connections.append(target_id)

    def get_field_value(self, *keys: str, default: Any = None) -> Any:
        """
        Get a value from node_data trying multiple possible keys.

        Args:
            *keys: Keys to try in order
            default: Default value if none found

        Returns:
            Found value or default
        """
        for key in keys:
            if key in self.node_data:
                return self.node_data[key]
            # Try case-insensitive
            for k, v in self.node_data.items():
                if k.lower() == key.lower():
                    return v
        return default

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(id={self.node_id}, name={self.name})"
