"""
Output Node - Handle data output/export operations.

Maps Tableau output operations to pandas:
- CSV -> df.to_csv()
- Excel -> df.to_excel()
- PostgreSQL -> df.to_sql()
- MySQL -> df.to_sql()
- SAP HANA -> df.to_sql()
"""

from .base import BaseNode, NodeContext
from ..utils import escape_string


class OutputNode(BaseNode):
    """Handler for Tableau Prep output nodes."""

    NODE_TYPE = "output"

    # Map connection types to output methods
    OUTPUT_MAP = {
        'csv': 'csv',
        'text': 'csv',
        'excel': 'excel',
        'xlsx': 'excel',
        'xls': 'excel',
        'parquet': 'parquet',
        'json': 'json',
        'postgresql': 'sql',
        'postgres': 'sql',
        'mysql': 'sql',
        'saphana': 'sql',
        'hana': 'sql',
        'database': 'sql',
    }

    def __init__(self, node_data: dict, node_id: str = ""):
        super().__init__(node_data, node_id)
        self.output_type = self._detect_output_type()
        self.output_path = self._extract_output_path()
        self.table_name = self._extract_table_name()
        self.connection_info = self._extract_connection_info()
        self.write_mode = self._extract_write_mode()

    def _detect_output_type(self) -> str:
        """Detect the type of output."""
        # Check nodeType first (Tableau's primary type indicator, e.g. ".v1.WriteToCsv")
        if 'nodeType' in self.node_data:
            nt = str(self.node_data['nodeType']).lower()
            if 'writetocsv' in nt:
                return 'csv'
            elif 'writetoexcel' in nt or 'writetoxls' in nt:
                return 'excel'
            elif 'writetojson' in nt:
                return 'json'
            elif 'writetoparquet' in nt:
                return 'parquet'
            elif 'writetohyper' in nt or 'writetohydra' in nt:
                return 'csv'  # Hyper is proprietary; decompile as CSV

        for key in ['outputType', 'type', 'format', 'connectionType']:
            if key in self.node_data:
                out_type = str(self.node_data[key]).lower()
                for pattern, mapped in self.OUTPUT_MAP.items():
                    if pattern in out_type:
                        return mapped

        # Check file path extension
        path = self._extract_output_path()
        if path:
            path_lower = path.lower()
            if path_lower.endswith('.csv'):
                return 'csv'
            elif path_lower.endswith(('.xlsx', '.xls')):
                return 'excel'
            elif path_lower.endswith('.json'):
                return 'json'
            elif path_lower.endswith('.parquet'):
                return 'parquet'
            elif path_lower.endswith('.hyper'):
                return 'csv'  # Hyper is proprietary; decompile as CSV

        # Check for database indicators
        if any(key in self.node_data for key in ['server', 'host', 'database', 'tableName']):
            return 'sql'

        return 'csv'  # Default

    def _extract_output_path(self) -> str:
        """Extract output file path."""
        for key in ['path', 'filePath', 'fileName', 'file', 'outputPath', 'directory',
                    'hyperOutputFile', 'tdsOutput']:
            if key in self.node_data:
                return str(self.node_data[key])
        return ''

    def _extract_table_name(self) -> str:
        """Extract database table name."""
        for key in ['table', 'tableName', 'outputTable', 'targetTable']:
            if key in self.node_data:
                return str(self.node_data[key])
        return ''

    def _extract_connection_info(self) -> dict:
        """Extract database connection parameters."""
        info = {}
        param_keys = [
            ('server', ['server', 'host', 'hostname']),
            ('port', ['port']),
            ('database', ['database', 'dbname', 'schema']),
            ('username', ['username', 'user', 'uid']),
            ('password', ['password', 'pwd']),
            ('schema', ['schema', 'schemaname']),
            ('db_type', ['connectionType', 'dbType', 'driver']),
        ]

        for target, keys in param_keys:
            for key in keys:
                if key in self.node_data:
                    info[target] = self.node_data[key]
                    break
                if 'connection' in self.node_data:
                    conn = self.node_data['connection']
                    if isinstance(conn, dict) and key in conn:
                        info[target] = conn[key]
                        break

        return info

    def _extract_write_mode(self) -> str:
        """Extract write mode (append, replace, fail)."""
        for key in ['writeMode', 'mode', 'ifExists', 'insertMode']:
            if key in self.node_data:
                mode = str(self.node_data[key]).lower()
                if 'append' in mode:
                    return 'append'
                elif 'replace' in mode or 'overwrite' in mode:
                    return 'replace'
                elif 'fail' in mode:
                    return 'fail'
        return 'replace'  # Default

    def get_description(self) -> str:
        """Get description for code comment."""
        if self.output_type == 'sql':
            db_type = self.connection_info.get('db_type', 'database')
            return f"Output to {db_type} table: {self.table_name or 'output_table'}"
        else:
            return f"Output to {self.output_type.upper()} file: {self.output_path or 'output file'}"

    def get_imports(self) -> list:
        """Get required imports."""
        imports = ["import pandas as pd", "import os", "from pathlib import Path"]

        if self.output_type == 'sql':
            imports.append("from sqlalchemy import create_engine")

            db_type = self.connection_info.get('db_type', '').lower()
            if 'postgres' in db_type:
                imports.append("# Requires: pip install psycopg2-binary")
            elif 'mysql' in db_type:
                imports.append("# Requires: pip install mysql-connector-python")
            elif 'hana' in db_type or 'sap' in db_type:
                imports.append("# Requires: pip install hdbcli")

        return imports

    def to_pandas_code(self, ctx: NodeContext) -> str:
        """Generate pandas output code."""
        input_var = ctx.input_variables[0] if ctx.input_variables else "df_output"
        indent = "    " * ctx.indent_level
        param_name = ctx.param_name

        if self.output_type == 'csv':
            return self._generate_csv_output(input_var, indent, param_name)
        elif self.output_type == 'excel':
            return self._generate_excel_output(input_var, indent, param_name)
        elif self.output_type == 'json':
            return self._generate_json_output(input_var, indent, param_name)
        elif self.output_type == 'parquet':
            return self._generate_parquet_output(input_var, indent, param_name)
        elif self.output_type == 'sql':
            return self._generate_sql_output(input_var, indent)
        else:
            return f"{indent}# TODO: Unsupported output type: {self.output_type}\n{indent}print({input_var})"

    def _generate_csv_output(self, var: str, indent: str, param_name: str = None) -> str:
        """Generate CSV output code."""
        lines = []
        if param_name:
            lines.append(f'{indent}os.makedirs(Path({param_name}).parent, exist_ok=True)')
            lines.append(f'{indent}{var}.to_csv({param_name}, index=False)')
        else:
            path = self.output_path or "output.csv"
            safe_path = escape_string(path)
            lines.append(f'{indent}os.makedirs(Path("{safe_path}").parent, exist_ok=True)')
            lines.append(f'{indent}{var}.to_csv("{safe_path}", index=False)')
        return '\n'.join(lines)

    def _generate_excel_output(self, var: str, indent: str, param_name: str = None) -> str:
        """Generate Excel output code."""
        lines = []
        if param_name:
            lines.append(f'{indent}os.makedirs(Path({param_name}).parent, exist_ok=True)')
            lines.append(f'{indent}{var}.to_excel({param_name}, index=False)')
        else:
            path = self.output_path or "output.xlsx"
            safe_path = escape_string(path)
            lines.append(f'{indent}os.makedirs(Path("{safe_path}").parent, exist_ok=True)')
            lines.append(f'{indent}{var}.to_excel("{safe_path}", index=False)')
        return '\n'.join(lines)

    def _generate_json_output(self, var: str, indent: str, param_name: str = None) -> str:
        """Generate JSON output code."""
        lines = []
        if param_name:
            lines.append(f'{indent}os.makedirs(Path({param_name}).parent, exist_ok=True)')
            lines.append(f'{indent}{var}.to_json({param_name}, orient="records", indent=2)')
        else:
            path = self.output_path or "output.json"
            safe_path = escape_string(path)
            lines.append(f'{indent}os.makedirs(Path("{safe_path}").parent, exist_ok=True)')
            lines.append(f'{indent}{var}.to_json("{safe_path}", orient="records", indent=2)')
        return '\n'.join(lines)

    def _generate_parquet_output(self, var: str, indent: str, param_name: str = None) -> str:
        """Generate Parquet output code."""
        lines = []
        if param_name:
            lines.append(f'{indent}os.makedirs(Path({param_name}).parent, exist_ok=True)')
            lines.append(f'{indent}{var}.to_parquet({param_name}, index=False)')
        else:
            path = self.output_path or "output.parquet"
            safe_path = escape_string(path)
            lines.append(f'{indent}os.makedirs(Path("{safe_path}").parent, exist_ok=True)')
            lines.append(f'{indent}{var}.to_parquet("{safe_path}", index=False)')
        return '\n'.join(lines)

    def _generate_sql_output(self, var: str, indent: str) -> str:
        """Generate SQL database output code."""
        lines = []

        # Build connection string
        conn_str = self._build_connection_string()
        engine_var = "_output_engine"

        lines.append(f'{indent}{engine_var} = create_engine("{conn_str}")')

        table = self.table_name or "output_table"
        safe_table = escape_string(table)
        mode = self.write_mode

        lines.append(f'{indent}{var}.to_sql("{safe_table}", {engine_var}, if_exists="{mode}", index=False)')

        return '\n'.join(lines)

    def _build_connection_string(self) -> str:
        """Build SQLAlchemy connection string."""
        info = self.connection_info
        db_type = str(info.get('db_type', 'postgresql')).lower()

        if 'postgres' in db_type:
            driver = 'postgresql+psycopg2'
        elif 'mysql' in db_type:
            driver = 'mysql+mysqlconnector'
        elif 'hana' in db_type or 'sap' in db_type:
            driver = 'hana'
        else:
            driver = db_type

        user = info.get('username', 'user')
        password = info.get('password', 'password')
        host = info.get('server', 'localhost')
        port = info.get('port', '')
        database = info.get('database', 'database')

        if port:
            return f"{driver}://{user}:{password}@{host}:{port}/{database}"
        else:
            return f"{driver}://{user}:{password}@{host}/{database}"
