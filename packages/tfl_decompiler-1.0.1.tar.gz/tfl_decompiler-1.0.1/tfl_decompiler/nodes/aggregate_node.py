"""
Aggregate Node - Handle groupby and aggregation operations.

Maps Tableau aggregate operations to pandas:
- Group by + aggregations -> df.groupby().agg()
- Supports: SUM, AVG, COUNT, MIN, MAX, MEDIAN, STDEV, etc.
"""

from .base import BaseNode, NodeContext
from ..utils import escape_string


class AggregateNode(BaseNode):
    """Handler for Tableau Prep aggregate nodes."""

    NODE_TYPE = "aggregate"

    # Map Tableau aggregation functions to pandas
    AGG_MAP = {
        'sum': 'sum',
        'avg': 'mean',
        'average': 'mean',
        'mean': 'mean',
        'count': 'count',
        'countd': 'nunique',
        'countdistinct': 'nunique',
        'min': 'min',
        'max': 'max',
        'median': 'median',
        'stdev': 'std',
        'stddev': 'std',
        'var': 'var',
        'variance': 'var',
        'first': 'first',
        'last': 'last',
        'mode': lambda x: x.mode().iloc[0] if len(x.mode()) > 0 else None,
    }

    def __init__(self, node_data: dict, node_id: str = ""):
        super().__init__(node_data, node_id)
        self.group_by_columns = self._extract_group_by()
        self.aggregations = self._extract_aggregations()

    def _extract_group_by(self) -> list:
        """Extract group by columns from node data."""
        for key in ['groupByColumns', 'groupBy', 'dimensions', 'groupFields', 'keys']:
            if key in self.node_data:
                cols = self.node_data[key]
                return cols if isinstance(cols, list) else [cols]

        # Check in actions
        for action in self.actions:
            if isinstance(action, dict):
                for key in ['groupBy', 'groupByColumns', 'dimensions']:
                    if key in action:
                        cols = action[key]
                        return cols if isinstance(cols, list) else [cols]

        return []

    def _extract_aggregations(self) -> list:
        """Extract aggregation definitions from node data."""
        aggregations = []

        # Check for aggregations array
        for key in ['aggregations', 'measures', 'aggregateFields', 'calculations']:
            if key in self.node_data:
                agg_data = self.node_data[key]
                if isinstance(agg_data, list):
                    for agg in agg_data:
                        parsed = self._parse_single_aggregation(agg)
                        if parsed:
                            aggregations.append(parsed)
                    return aggregations

        # Check in actions
        for action in self.actions:
            if isinstance(action, dict):
                for key in ['aggregations', 'measures', 'fields']:
                    if key in action:
                        agg_data = action[key]
                        if isinstance(agg_data, list):
                            for agg in agg_data:
                                parsed = self._parse_single_aggregation(agg)
                                if parsed:
                                    aggregations.append(parsed)

        # Check for individual field+aggregation
        field = self.get_field_value('field', 'columnName', 'column')
        agg_func = self.get_field_value('aggregation', 'function', 'aggType')
        if field and agg_func:
            aggregations.append({
                'field': field,
                'function': agg_func.lower(),
                'output_name': f"{field}_{agg_func.lower()}"
            })

        return aggregations

    def _parse_single_aggregation(self, agg: dict) -> dict:
        """Parse a single aggregation definition."""
        if not isinstance(agg, dict):
            return None

        field = None
        for key in ['field', 'column', 'columnName', 'sourceField']:
            if key in agg:
                field = agg[key]
                break

        func = None
        for key in ['function', 'aggregation', 'aggType', 'type']:
            if key in agg:
                func = str(agg[key]).lower()
                break

        output_name = None
        for key in ['outputName', 'name', 'alias', 'as']:
            if key in agg:
                output_name = agg[key]
                break

        if field and func:
            return {
                'field': field,
                'function': func,
                'output_name': output_name or f"{field}_{func}"
            }

        return None

    def get_description(self) -> str:
        """Get description for code comment."""
        group_cols = ', '.join(self.group_by_columns[:3])
        agg_count = len(self.aggregations)
        return f"Aggregate by [{group_cols}] with {agg_count} aggregations"

    def get_imports(self) -> list:
        """Get required imports."""
        return ["import pandas as pd"]

    def to_pandas_code(self, ctx: NodeContext) -> str:
        """Generate pandas groupby/aggregate code."""
        var = ctx.variable_name
        input_var = ctx.input_variables[0] if ctx.input_variables else "df_input"
        indent = "    " * ctx.indent_level

        lines = []

        if not self.group_by_columns and not self.aggregations:
            lines.append(f"{indent}# Aggregate: No group by or aggregations found")
            lines.append(f"{indent}{var} = {input_var}.copy()")
            return '\n'.join(lines)

        # Build aggregation dictionary
        agg_dict = {}
        for agg in self.aggregations:
            field = agg['field']
            func = agg['function']
            pandas_func = self.AGG_MAP.get(func, func)

            if field not in agg_dict:
                agg_dict[field] = []
            agg_dict[field].append(pandas_func)

        if self.group_by_columns:
            # Build group by clause
            if len(self.group_by_columns) == 1:
                groupby_str = f"'{escape_string(self.group_by_columns[0])}'"
            else:
                cols_str = ', '.join(f"'{escape_string(c)}'" for c in self.group_by_columns)
                groupby_str = f"[{cols_str}]"

            # Build aggregation dictionary string
            agg_items = []
            for field, funcs in agg_dict.items():
                if len(funcs) == 1:
                    agg_items.append(f"'{escape_string(field)}': '{funcs[0]}'")
                else:
                    funcs_str = ', '.join(f"'{f}'" for f in funcs)
                    agg_items.append(f"'{escape_string(field)}': [{funcs_str}]")

            if agg_items:
                agg_dict_str = '{' + ', '.join(agg_items) + '}'
                lines.append(f"{indent}{var} = {input_var}.groupby({groupby_str}).agg({agg_dict_str}).reset_index()")

                # Flatten column names if multiple aggregations per field
                has_multi_agg = any(len(funcs) > 1 for funcs in agg_dict.values())
                if has_multi_agg:
                    lines.append(f"{indent}# Flatten multi-level column names")
                    lines.append(f"{indent}if hasattr({var}.columns, 'levels'):")
                    lines.append(f"{indent}    {var}.columns = ['_'.join(col).strip('_') if isinstance(col, tuple) else col for col in {var}.columns]")
            else:
                # Just group by, no aggregation (unique combinations)
                lines.append(f"{indent}{var} = {input_var}.groupby({groupby_str}).size().reset_index(name='count')")
        else:
            # No group by, aggregate entire dataframe
            if agg_dict:
                agg_items = []
                for field, funcs in agg_dict.items():
                    for func in funcs:
                        agg_items.append(f"'{escape_string(field)}_{func}': {input_var}['{escape_string(field)}'].{func}()")

                lines.append(f"{indent}{var} = pd.DataFrame({{")
                for item in agg_items:
                    lines.append(f"{indent}    {item},")
                lines.append(f"{indent}}}, index=[0])")
            else:
                lines.append(f"{indent}{var} = {input_var}.copy()")

        return '\n'.join(lines)
