"""
Join Node - Handle table join operations.

Maps Tableau join operations to pandas:
- Inner join -> pd.merge(how='inner')
- Left join -> pd.merge(how='left')
- Right join -> pd.merge(how='right')
- Full outer join -> pd.merge(how='outer')
"""

from .base import BaseNode, NodeContext
from ..utils import escape_string


class JoinNode(BaseNode):
    """Handler for Tableau Prep join nodes."""

    NODE_TYPE = "join"

    # Map Tableau join types to pandas
    JOIN_TYPE_MAP = {
        'inner': 'inner',
        'left': 'left',
        'leftouter': 'left',
        'left outer': 'left',
        'right': 'right',
        'rightouter': 'right',
        'right outer': 'right',
        'outer': 'outer',
        'full': 'outer',
        'fullouter': 'outer',
        'full outer': 'outer',
        'cross': 'cross',
    }

    def __init__(self, node_data: dict, node_id: str = ""):
        super().__init__(node_data, node_id)
        self.join_type = self._extract_join_type()
        self.join_clauses = self._extract_join_clauses()

    def _extract_join_type(self) -> str:
        """Extract the type of join."""
        for key in ['joinType', 'type', 'how']:
            if key in self.node_data:
                join_type = str(self.node_data[key]).lower().replace('_', '')
                return self.JOIN_TYPE_MAP.get(join_type, 'inner')

        # Check in actions
        for action in self.actions:
            if isinstance(action, dict):
                for key in ['joinType', 'type']:
                    if key in action:
                        join_type = str(action[key]).lower().replace('_', '')
                        return self.JOIN_TYPE_MAP.get(join_type, 'inner')

        return 'inner'  # Default

    def _extract_join_clauses(self) -> list:
        """Extract join clauses (column mappings)."""
        clauses = []

        # Try various key names
        for key in ['joinClauses', 'clauses', 'conditions', 'on', 'joinConditions']:
            if key in self.node_data:
                raw_clauses = self.node_data[key]
                if isinstance(raw_clauses, list):
                    for clause in raw_clauses:
                        parsed = self._parse_clause(clause)
                        if parsed:
                            clauses.append(parsed)
                    return clauses
                elif isinstance(raw_clauses, dict):
                    parsed = self._parse_clause(raw_clauses)
                    if parsed:
                        clauses.append(parsed)
                    return clauses
                elif isinstance(raw_clauses, str):
                    # Simple column name (same on both sides)
                    clauses.append({'left': raw_clauses, 'right': raw_clauses})
                    return clauses

        # Check in actions
        for action in self.actions:
            if isinstance(action, dict):
                for key in ['joinClauses', 'clauses', 'conditions']:
                    if key in action:
                        raw_clauses = action[key]
                        if isinstance(raw_clauses, list):
                            for clause in raw_clauses:
                                parsed = self._parse_clause(clause)
                                if parsed:
                                    clauses.append(parsed)

        return clauses

    def _parse_clause(self, clause: dict) -> dict:
        """Parse a single join clause."""
        if isinstance(clause, str):
            return {'left': clause, 'right': clause}

        if not isinstance(clause, dict):
            return None

        left = None
        right = None

        # Try different key names for left side
        for key in ['leftColumn', 'left', 'leftField', 'sourceField', 'from']:
            if key in clause:
                left = clause[key]
                break

        # Try different key names for right side
        for key in ['rightColumn', 'right', 'rightField', 'targetField', 'to']:
            if key in clause:
                right = clause[key]
                break

        # Sometimes stored as expression
        if not left and not right and 'expression' in clause:
            expr = clause['expression']
            if '=' in expr:
                parts = expr.split('=')
                if len(parts) == 2:
                    left = parts[0].strip().strip('[]"\'')
                    right = parts[1].strip().strip('[]"\'')

        if left and right:
            return {'left': left, 'right': right}
        elif left:
            return {'left': left, 'right': left}

        return None

    def get_description(self) -> str:
        """Get description for code comment."""
        join_cols = ', '.join(f"{c['left']}={c['right']}" for c in self.join_clauses[:2])
        return f"{self.join_type.capitalize()} join on: {join_cols}"

    def get_imports(self) -> list:
        """Get required imports."""
        return ["import pandas as pd"]

    def to_pandas_code(self, ctx: NodeContext) -> str:
        """Generate pandas merge code."""
        var = ctx.variable_name
        indent = "    " * ctx.indent_level

        # Need at least 2 inputs for join
        if len(ctx.input_variables) < 2:
            return f"{indent}# Join: Expected 2 inputs, got {len(ctx.input_variables)}\n{indent}{var} = {ctx.input_variables[0] if ctx.input_variables else 'pd.DataFrame()'}"

        left_var = ctx.input_variables[0]
        right_var = ctx.input_variables[1]

        lines = []

        # Determine join parameters
        if not self.join_clauses:
            # No explicit clauses - use common columns
            lines.append(f"{indent}# Auto-detect join columns (common column names)")
            lines.append(f"{indent}common_cols = list(set({left_var}.columns) & set({right_var}.columns))")
            lines.append(f"{indent}{var} = pd.merge({left_var}, {right_var}, on=common_cols, how='{self.join_type}')")
        else:
            # Check if left and right columns are the same
            left_cols = [c['left'] for c in self.join_clauses]
            right_cols = [c['right'] for c in self.join_clauses]

            if left_cols == right_cols:
                # Same column names on both sides - use 'on'
                if len(left_cols) == 1:
                    on_str = f"'{escape_string(left_cols[0])}'"
                else:
                    cols_str = ', '.join(f"'{escape_string(c)}'" for c in left_cols)
                    on_str = f"[{cols_str}]"

                lines.append(f"{indent}{var} = pd.merge({left_var}, {right_var}, on={on_str}, how='{self.join_type}')")
            else:
                # Different column names - use left_on and right_on
                if len(left_cols) == 1:
                    left_on_str = f"'{escape_string(left_cols[0])}'"
                    right_on_str = f"'{escape_string(right_cols[0])}'"
                else:
                    left_on_str = '[' + ', '.join(f"'{escape_string(c)}'" for c in left_cols) + ']'
                    right_on_str = '[' + ', '.join(f"'{escape_string(c)}'" for c in right_cols) + ']'

                lines.append(f"{indent}{var} = pd.merge({left_var}, {right_var}, left_on={left_on_str}, right_on={right_on_str}, how='{self.join_type}')")

        return '\n'.join(lines)
