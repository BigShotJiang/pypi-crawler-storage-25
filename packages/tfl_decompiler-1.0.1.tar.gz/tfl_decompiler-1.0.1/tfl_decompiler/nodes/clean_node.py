"""
Clean Node - Handle data transformation operations.

Maps Tableau Clean step operations to pandas:
- Rename field -> df.rename()
- Remove field -> df.drop()
- Change type -> df.astype()
- Filter -> df[condition]
- Replace values -> df.replace()
- Split field -> str.split()
- Merge fields -> string concatenation
- Fill nulls -> df.fillna()
- Remove nulls -> df.dropna()
- Calculated field -> new column
"""

from .base import BaseNode, NodeContext
from ..utils import escape_string


class CleanNode(BaseNode):
    """Handler for Tableau Prep clean/transform nodes."""

    NODE_TYPE = "clean"

    # Map Tableau action types to handler methods
    ACTION_HANDLERS = {
        'rename': '_handle_rename',
        'remove': '_handle_remove',
        'drop': '_handle_remove',
        'changetype': '_handle_change_type',
        'convert': '_handle_change_type',
        'filter': '_handle_filter',
        'replace': '_handle_replace',
        'remap': '_handle_remap',  # Tableau value replacement
        'split': '_handle_split',
        'merge': '_handle_merge',
        'concat': '_handle_merge',
        'fillna': '_handle_fill_null',
        'fillnull': '_handle_fill_null',
        'dropna': '_handle_drop_null',
        'removeempty': '_handle_drop_null',
        'calculate': '_handle_calculated_field',
        'addcalculation': '_handle_calculated_field',
        'addcolumn': '_handle_calculated_field',  # Tableau AddColumn
        'group': '_handle_group_values',
        'cluster': '_handle_group_values',
        'trim': '_handle_trim',
        'uppercase': '_handle_case',
        'lowercase': '_handle_case',
        'propercase': '_handle_case',
    }

    def __init__(self, node_data: dict, node_id: str = ""):
        super().__init__(node_data, node_id)
        self.parsed_actions = self._parse_actions()

    def _parse_actions(self) -> list:
        """Parse and normalize actions from node data.

        Handles both:
        - actions array (standard format)
        - Direct node properties (Tableau format like columnName + expression)
        """
        parsed = []

        # Parse from actions array
        for action in self.actions:
            if isinstance(action, dict):
                action_type = self._get_action_type(action)
                parsed.append({
                    'type': action_type,
                    'data': action
                })
            elif isinstance(action, str):
                parsed.append({
                    'type': action.lower(),
                    'data': {}
                })

        # Handle Tableau-specific node properties (action is in node itself)
        # AddColumn: columnName + expression
        if 'expression' in self.node_data and 'columnName' in self.node_data:
            parsed.append({
                'type': 'addcolumn',
                'data': {
                    'columnName': self.node_data.get('columnName'),
                    'expression': self.node_data.get('expression'),
                    'name': self.node_data.get('name', self.node_data.get('columnName'))
                }
            })

        # Remap: columnName + values (value replacement mapping)
        if 'values' in self.node_data and 'columnName' in self.node_data and 'expression' not in self.node_data:
            parsed.append({
                'type': 'remap',
                'data': {
                    'columnName': self.node_data.get('columnName'),
                    'values': self.node_data.get('values')
                }
            })

        return parsed

    def _get_action_type(self, action: dict) -> str:
        """Extract action type from action data."""
        for key in ['type', 'actionType', 'operation', 'kind', 'action']:
            if key in action:
                return str(action[key]).lower().replace('-', '').replace('_', '')
        return 'unknown'

    def get_description(self) -> str:
        """Get description for code comment."""
        if not self.parsed_actions:
            return f"Clean step: {self.name}"

        action_types = [a['type'] for a in self.parsed_actions]
        return f"Clean step ({len(action_types)} operations): {', '.join(action_types[:3])}"

    def get_imports(self) -> list:
        """Get required imports."""
        imports = ["import pandas as pd"]

        # Check if numpy is needed
        for action in self.parsed_actions:
            if action['type'] in ('calculate', 'addcalculation', 'filter'):
                imports.append("import numpy as np")
                break

        return list(set(imports))

    def to_pandas_code(self, ctx: NodeContext) -> str:
        """Generate pandas code for all clean operations."""
        var = ctx.variable_name
        input_var = ctx.input_variables[0] if ctx.input_variables else "df_input"
        indent = "    " * ctx.indent_level

        lines = []

        # Start with copying input
        lines.append(f"{indent}{var} = {input_var}.copy()")

        # Generate code for each action
        for action in self.parsed_actions:
            action_type = action['type']
            action_data = action['data']

            handler_name = self.ACTION_HANDLERS.get(action_type)
            if handler_name:
                handler = getattr(self, handler_name, None)
                if handler:
                    code = handler(var, action_data, indent)
                    if code:
                        lines.append(code)
            else:
                # Unknown action - add as comment
                lines.append(f"{indent}# TODO: Unsupported action type: {action_type}")

        return '\n'.join(lines)

    def _handle_rename(self, var: str, action: dict, indent: str) -> str:
        """Generate rename column code."""
        rename_map = {}

        # Try different structures for rename data
        if 'columnName' in action and 'newName' in action:
            rename_map[action['columnName']] = action['newName']
        elif 'oldName' in action and 'newName' in action:
            rename_map[action['oldName']] = action['newName']
        elif 'renames' in action:
            rename_map = action['renames']
        elif 'field' in action and 'to' in action:
            rename_map[action['field']] = action['to']
        elif 'name' in action:
            # Single field rename
            if 'rename' in action:
                rename_map[action['name']] = action['rename']

        if rename_map:
            rename_str = ', '.join(
                f"'{escape_string(k)}': '{escape_string(v)}'"
                for k, v in rename_map.items()
            )
            return f"{indent}{var} = {var}.rename(columns={{{rename_str}}})"

        return f"{indent}# Rename: Could not parse rename mapping"

    def _handle_remove(self, var: str, action: dict, indent: str) -> str:
        """Generate remove column code."""
        columns = []

        if 'columnName' in action:
            columns = [action['columnName']]
        elif 'columns' in action:
            columns = action['columns']
        elif 'field' in action:
            columns = [action['field']]
        elif 'fields' in action:
            columns = action['fields']
        elif 'name' in action:
            columns = [action['name']]

        if columns:
            cols_str = ', '.join(f"'{escape_string(c)}'" for c in columns)
            return f"{indent}{var} = {var}.drop(columns=[{cols_str}])"

        return f"{indent}# Remove: Could not parse column names"

    def _handle_change_type(self, var: str, action: dict, indent: str) -> str:
        """Generate data type conversion code."""
        field = action.get('columnName') or action.get('field') or action.get('name')
        new_type = action.get('newType') or action.get('type') or action.get('dataType')

        if not field or not new_type:
            return f"{indent}# ChangeType: Missing field or type info"

        new_type_lower = str(new_type).lower()
        safe_field = escape_string(field)

        # Map Tableau types to pandas/Python types
        type_map = {
            'string': 'str',
            'text': 'str',
            'integer': 'int',
            'int': 'int',
            'number': 'float',
            'decimal': 'float',
            'float': 'float',
            'real': 'float',
            'boolean': 'bool',
            'bool': 'bool',
            'date': 'datetime',
            'datetime': 'datetime',
        }

        pandas_type = type_map.get(new_type_lower, new_type_lower)

        if pandas_type == 'datetime':
            return f"{indent}{var}['{safe_field}'] = pd.to_datetime({var}['{safe_field}'])"
        else:
            return f"{indent}{var}['{safe_field}'] = {var}['{safe_field}'].astype('{pandas_type}')"

    # Map Tableau operators to Python
    OPERATOR_MAP = {
        'equals': '==',
        'eq': '==',
        '=': '==',
        'notequals': '!=',
        'ne': '!=',
        '!=': '!=',
        '<>': '!=',
        'greaterthan': '>',
        'gt': '>',
        '>': '>',
        'lessthan': '<',
        'lt': '<',
        '<': '<',
        'greaterthanorequal': '>=',
        'gte': '>=',
        '>=': '>=',
        'lessthanorequal': '<=',
        'lte': '<=',
        '<=': '<=',
    }

    def _handle_filter(self, var: str, action: dict, indent: str) -> str:
        """Generate filter/row selection code."""
        from ..expression_parser import ExpressionParser

        condition = action.get('expression') or action.get('filter') or action.get('condition')

        if not condition:
            # Check for structured filter
            field = action.get('field') or action.get('columnName')
            raw_operator = action.get('operator', '==')
            # Map Tableau operator names to Python operators
            operator = self.OPERATOR_MAP.get(raw_operator.lower(), raw_operator) if isinstance(raw_operator, str) else raw_operator
            value = action.get('value')

            if field and value is not None:
                safe_field = escape_string(field)
                if isinstance(value, str):
                    return f"{indent}{var} = {var}[{var}['{safe_field}'] {operator} '{escape_string(value)}']"
                else:
                    return f"{indent}{var} = {var}[{var}['{safe_field}'] {operator} {value}]"

            return f"{indent}# Filter: Could not parse filter condition"

        # Parse Tableau expression to pandas
        parser = ExpressionParser()
        pandas_expr = parser.parse(condition, var)
        return f"{indent}{var} = {var}[{pandas_expr}]"

    def _handle_replace(self, var: str, action: dict, indent: str) -> str:
        """Generate value replacement code."""
        field = action.get('columnName') or action.get('field')
        old_value = action.get('oldValue') or action.get('from')
        new_value = action.get('newValue') or action.get('to')

        if field and old_value is not None:
            safe_field = escape_string(field)
            if new_value is None:
                new_value = ''

            # Format values appropriately
            if isinstance(old_value, str):
                old_str = f"'{escape_string(old_value)}'"
            else:
                old_str = str(old_value)

            if isinstance(new_value, str):
                new_str = f"'{escape_string(new_value)}'"
            else:
                new_str = str(new_value)

            return f"{indent}{var}['{safe_field}'] = {var}['{safe_field}'].replace({old_str}, {new_str})"

        # Global replace
        if 'replacements' in action:
            replacements = action['replacements']
            return f"{indent}{var} = {var}.replace({replacements})"

        return f"{indent}# Replace: Could not parse replacement values"

    def _handle_remap(self, var: str, action: dict, indent: str) -> str:
        """Generate Tableau Remap (value grouping/replacement) code.

        Tableau Remap format:
        {
            "columnName": "Discounts",
            "values": {
                "\"0\"": ["\"0\"", "\"None\""]  # Map "0" and "None" to "0"
            }
        }
        """
        field = action.get('columnName') or action.get('field')
        values = action.get('values', {})

        if not field or not values:
            return f"{indent}# Remap: Missing field or values"

        safe_field = escape_string(field)

        # Build replacement mapping
        # Tableau format: target_value -> [source_values]
        # We need to invert: source_value -> target_value
        mapping = {}
        for target, sources in values.items():
            # Remove quotes from target
            clean_target = target.strip('"\'')
            if isinstance(sources, list):
                for source in sources:
                    clean_source = source.strip('"\'')
                    if clean_source != clean_target:
                        mapping[clean_source] = clean_target
            else:
                clean_source = str(sources).strip('"\'')
                if clean_source != clean_target:
                    mapping[clean_source] = clean_target

        if not mapping:
            return f"{indent}# Remap: No value changes detected"

        mapping_str = ', '.join(f"'{escape_string(k)}': '{escape_string(v)}'" for k, v in mapping.items())
        return f"{indent}{var}['{safe_field}'] = {var}['{safe_field}'].replace({{{mapping_str}}})"

    def _handle_split(self, var: str, action: dict, indent: str) -> str:
        """Generate string split code."""
        field = action.get('columnName') or action.get('field')
        delimiter = action.get('delimiter') or action.get('separator', ',')
        num_splits = action.get('numSplits') or action.get('maxSplit')

        if not field:
            return f"{indent}# Split: Missing field name"

        safe_field = escape_string(field)
        safe_delim = escape_string(delimiter)

        lines = []
        if num_splits:
            lines.append(f"{indent}split_cols = {var}['{safe_field}'].str.split('{safe_delim}', n={num_splits}, expand=True)")
        else:
            lines.append(f"{indent}split_cols = {var}['{safe_field}'].str.split('{safe_delim}', expand=True)")

        lines.append(f"{indent}split_cols.columns = [f'{safe_field}_{{i+1}}' for i in range(split_cols.shape[1])]")
        lines.append(f"{indent}{var} = pd.concat([{var}, split_cols], axis=1)")

        return '\n'.join(lines)

    def _handle_merge(self, var: str, action: dict, indent: str) -> str:
        """Generate field merge/concatenation code."""
        fields = action.get('columns') or action.get('fields') or []
        new_name = action.get('newName') or action.get('outputField', 'merged_field')
        separator = action.get('separator', '')

        if len(fields) < 2:
            return f"{indent}# Merge: Need at least 2 fields to merge"

        safe_new = escape_string(new_name)
        safe_sep = escape_string(separator)

        field_refs = [f"{var}['{escape_string(f)}'].astype(str)" for f in fields]
        concat_expr = f" + '{safe_sep}' + ".join(field_refs)

        return f"{indent}{var}['{safe_new}'] = {concat_expr}"

    def _handle_fill_null(self, var: str, action: dict, indent: str) -> str:
        """Generate fillna code."""
        field = action.get('columnName') or action.get('field')
        value = action.get('value') or action.get('fillValue', 0)

        if field:
            safe_field = escape_string(field)
            if isinstance(value, str):
                return f"{indent}{var}['{safe_field}'] = {var}['{safe_field}'].fillna('{escape_string(value)}')"
            else:
                return f"{indent}{var}['{safe_field}'] = {var}['{safe_field}'].fillna({value})"
        else:
            if isinstance(value, str):
                return f"{indent}{var} = {var}.fillna('{escape_string(value)}')"
            else:
                return f"{indent}{var} = {var}.fillna({value})"

    def _handle_drop_null(self, var: str, action: dict, indent: str) -> str:
        """Generate dropna code."""
        field = action.get('columnName') or action.get('field')

        if field:
            safe_field = escape_string(field)
            return f"{indent}{var} = {var}.dropna(subset=['{safe_field}'])"
        else:
            return f"{indent}{var} = {var}.dropna()"

    def _handle_calculated_field(self, var: str, action: dict, indent: str) -> str:
        """Generate calculated field code."""
        from ..expression_parser import ExpressionParser

        # Prioritize columnName (actual column to create) over name (step name)
        name = action.get('columnName') or action.get('name') or action.get('fieldName') or 'calculated_field'
        expression = action.get('expression') or action.get('calculation') or action.get('formula')

        if not expression:
            return f"{indent}# Calculated field: No expression found"

        safe_name = escape_string(name)
        parser = ExpressionParser()
        pandas_expr = parser.parse(expression, var)

        return f"{indent}{var}['{safe_name}'] = {pandas_expr}"

    def _handle_group_values(self, var: str, action: dict, indent: str) -> str:
        """Generate value grouping/clustering code."""
        field = action.get('columnName') or action.get('field')
        groups = action.get('groups') or action.get('clusters') or {}

        if not field or not groups:
            return f"{indent}# Group values: Missing field or group mapping"

        safe_field = escape_string(field)

        # Build replacement dictionary
        mapping = {}
        for group_name, values in groups.items():
            for value in values:
                mapping[value] = group_name

        mapping_str = ', '.join(f"'{escape_string(k)}': '{escape_string(v)}'" for k, v in mapping.items())
        return f"{indent}{var}['{safe_field}'] = {var}['{safe_field}'].map({{{mapping_str}}})"

    def _handle_trim(self, var: str, action: dict, indent: str) -> str:
        """Generate string trim code."""
        field = action.get('columnName') or action.get('field')

        if field:
            safe_field = escape_string(field)
            return f"{indent}{var}['{safe_field}'] = {var}['{safe_field}'].str.strip()"
        else:
            # Trim all string columns
            return f"{indent}{var} = {var}.apply(lambda x: x.str.strip() if x.dtype == 'object' else x)"

    def _handle_case(self, var: str, action: dict, indent: str) -> str:
        """Generate case conversion code."""
        field = action.get('columnName') or action.get('field')
        case_type = action.get('type', 'lowercase').lower()

        if not field:
            return f"{indent}# Case conversion: Missing field name"

        safe_field = escape_string(field)

        if 'upper' in case_type:
            return f"{indent}{var}['{safe_field}'] = {var}['{safe_field}'].str.upper()"
        elif 'lower' in case_type:
            return f"{indent}{var}['{safe_field}'] = {var}['{safe_field}'].str.lower()"
        elif 'proper' in case_type or 'title' in case_type:
            return f"{indent}{var}['{safe_field}'] = {var}['{safe_field}'].str.title()"
        else:
            return f"{indent}# Case conversion: Unknown case type: {case_type}"
