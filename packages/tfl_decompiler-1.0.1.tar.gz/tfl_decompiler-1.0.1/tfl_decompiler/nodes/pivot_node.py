"""
Pivot Node - Handle pivot operations.

Maps Tableau pivot operations to pandas:
- Columns to rows -> pd.melt()
- Rows to columns -> df.pivot() / df.pivot_table()
"""

from .base import BaseNode, NodeContext
from ..utils import escape_string


class PivotNode(BaseNode):
    """Handler for Tableau Prep pivot nodes."""

    NODE_TYPE = "pivot"

    def __init__(self, node_data: dict, node_id: str = ""):
        super().__init__(node_data, node_id)
        self.pivot_type = self._detect_pivot_type()
        self.pivot_config = self._parse_pivot_config()

    def _detect_pivot_type(self) -> str:
        """Detect if this is a columns-to-rows or rows-to-columns pivot."""
        pivot_type = self.get_field_value('pivotType', 'type', 'direction', default='')

        if pivot_type:
            pivot_type_lower = str(pivot_type).lower()
            if 'row' in pivot_type_lower or 'melt' in pivot_type_lower or 'unpivot' in pivot_type_lower:
                return 'columns_to_rows'
            elif 'col' in pivot_type_lower or 'wide' in pivot_type_lower:
                return 'rows_to_columns'

        # Check for indicators
        if 'pivotColumns' in self.node_data or 'columnsToPivot' in self.node_data:
            return 'columns_to_rows'
        elif 'indexColumns' in self.node_data or 'index' in self.node_data:
            return 'rows_to_columns'

        return 'columns_to_rows'  # Default to melt

    def _parse_pivot_config(self) -> dict:
        """Parse pivot configuration from node data."""
        config = {
            'id_vars': [],
            'value_vars': [],
            'var_name': 'variable',
            'value_name': 'value',
            'index': [],
            'columns': [],
            'values': '',
            'aggfunc': 'first'
        }

        # Columns to pivot (melt)
        for key in ['pivotColumns', 'columnsToPivot', 'valueCols', 'pivotFields']:
            if key in self.node_data:
                cols = self.node_data[key]
                config['value_vars'] = cols if isinstance(cols, list) else [cols]
                break

        # ID columns (stay fixed)
        for key in ['idColumns', 'fixedColumns', 'groupColumns', 'keepColumns']:
            if key in self.node_data:
                cols = self.node_data[key]
                config['id_vars'] = cols if isinstance(cols, list) else [cols]
                break

        # Names for unpivoted columns
        config['var_name'] = self.get_field_value('variableName', 'pivotedFieldName', default='variable')
        config['value_name'] = self.get_field_value('valueName', 'pivotedValueName', default='value')

        # For pivot (rows to columns)
        for key in ['index', 'indexColumns', 'rowFields']:
            if key in self.node_data:
                cols = self.node_data[key]
                config['index'] = cols if isinstance(cols, list) else [cols]
                break

        for key in ['columns', 'columnFields', 'pivotOn']:
            if key in self.node_data:
                cols = self.node_data[key]
                config['columns'] = cols if isinstance(cols, list) else [cols]
                break

        config['values'] = self.get_field_value('values', 'valueField', 'aggregateField', default='')
        config['aggfunc'] = self.get_field_value('aggregation', 'aggfunc', default='first')

        return config

    def get_description(self) -> str:
        """Get description for code comment."""
        if self.pivot_type == 'columns_to_rows':
            cols = self.pivot_config.get('value_vars', [])
            return f"Pivot columns to rows (unpivot): {', '.join(cols[:3])}"
        else:
            cols = self.pivot_config.get('columns', [])
            return f"Pivot rows to columns: {', '.join(cols[:3])}"

    def get_imports(self) -> list:
        """Get required imports."""
        return ["import pandas as pd"]

    def to_pandas_code(self, ctx: NodeContext) -> str:
        """Generate pandas pivot code."""
        var = ctx.variable_name
        input_var = ctx.input_variables[0] if ctx.input_variables else "df_input"
        indent = "    " * ctx.indent_level

        if self.pivot_type == 'columns_to_rows':
            return self._generate_melt_code(var, input_var, indent)
        else:
            return self._generate_pivot_code(var, input_var, indent)

    def _generate_melt_code(self, var: str, input_var: str, indent: str) -> str:
        """Generate pd.melt() code for columns-to-rows pivot."""
        config = self.pivot_config
        lines = []

        id_vars = config.get('id_vars', [])
        value_vars = config.get('value_vars', [])
        var_name = config.get('var_name', 'variable')
        value_name = config.get('value_name', 'value')

        # Build melt arguments
        args = []

        if id_vars:
            id_vars_str = ', '.join(f"'{escape_string(c)}'" for c in id_vars)
            args.append(f"id_vars=[{id_vars_str}]")

        if value_vars:
            value_vars_str = ', '.join(f"'{escape_string(c)}'" for c in value_vars)
            args.append(f"value_vars=[{value_vars_str}]")

        args.append(f"var_name='{escape_string(var_name)}'")
        args.append(f"value_name='{escape_string(value_name)}'")

        args_str = ', '.join(args)
        lines.append(f"{indent}{var} = pd.melt({input_var}, {args_str})")

        return '\n'.join(lines)

    def _generate_pivot_code(self, var: str, input_var: str, indent: str) -> str:
        """Generate df.pivot() or df.pivot_table() code for rows-to-columns pivot."""
        config = self.pivot_config
        lines = []

        index = config.get('index', [])
        columns = config.get('columns', [])
        values = config.get('values', '')
        aggfunc = config.get('aggfunc', 'first')

        # Use pivot_table for aggregation, pivot for simple reshape
        if aggfunc and aggfunc != 'first':
            # pivot_table with aggregation
            args = []

            if index:
                if len(index) == 1:
                    args.append(f"index='{escape_string(index[0])}'")
                else:
                    idx_str = ', '.join(f"'{escape_string(c)}'" for c in index)
                    args.append(f"index=[{idx_str}]")

            if columns:
                if len(columns) == 1:
                    args.append(f"columns='{escape_string(columns[0])}'")
                else:
                    col_str = ', '.join(f"'{escape_string(c)}'" for c in columns)
                    args.append(f"columns=[{col_str}]")

            if values:
                args.append(f"values='{escape_string(values)}'")

            args.append(f"aggfunc='{aggfunc}'")

            args_str = ', '.join(args)
            lines.append(f"{indent}{var} = {input_var}.pivot_table({args_str}).reset_index()")
        else:
            # Simple pivot
            args = []

            if index:
                if len(index) == 1:
                    args.append(f"index='{escape_string(index[0])}'")
                else:
                    idx_str = ', '.join(f"'{escape_string(c)}'" for c in index)
                    args.append(f"index=[{idx_str}]")

            if columns:
                if len(columns) == 1:
                    args.append(f"columns='{escape_string(columns[0])}'")
                else:
                    col_str = ', '.join(f"'{escape_string(c)}'" for c in columns)
                    args.append(f"columns=[{col_str}]")

            if values:
                args.append(f"values='{escape_string(values)}'")

            args_str = ', '.join(args)
            lines.append(f"{indent}{var} = {input_var}.pivot({args_str}).reset_index()")

        # Flatten column names if multi-level
        lines.append(f"{indent}if hasattr({var}.columns, 'levels'):")
        lines.append(f"{indent}    {var}.columns = ['_'.join(map(str, col)).strip('_') for col in {var}.columns.values]")

        return '\n'.join(lines)
