"""
Union Node - Handle union/append operations.

Maps Tableau union operations to pandas:
- Stack tables -> pd.concat([df1, df2], axis=0)
- Handle mismatched columns
"""

from .base import BaseNode, NodeContext
from ..utils import escape_string


class UnionNode(BaseNode):
    """Handler for Tableau Prep union nodes."""

    NODE_TYPE = "union"

    def __init__(self, node_data: dict, node_id: str = ""):
        super().__init__(node_data, node_id)
        self.field_mappings = self._extract_field_mappings()
        self.remove_mismatched = self._check_remove_mismatched()

    def _extract_field_mappings(self) -> dict:
        """Extract column mappings for union (when columns have different names)."""
        mappings = {}

        for key in ['fieldMappings', 'columnMappings', 'mappings', 'fieldMap']:
            if key in self.node_data:
                raw_mappings = self.node_data[key]
                if isinstance(raw_mappings, dict):
                    return raw_mappings
                elif isinstance(raw_mappings, list):
                    for mapping in raw_mappings:
                        if isinstance(mapping, dict):
                            src = mapping.get('source') or mapping.get('from') or mapping.get('original')
                            tgt = mapping.get('target') or mapping.get('to') or mapping.get('rename')
                            if src and tgt:
                                mappings[src] = tgt

        return mappings

    def _check_remove_mismatched(self) -> bool:
        """Check if mismatched columns should be removed."""
        for key in ['removeMismatched', 'keepOnlyMatching', 'dropUnmatched']:
            if key in self.node_data:
                return bool(self.node_data[key])
        return False

    def get_description(self) -> str:
        """Get description for code comment."""
        return f"Union (append) datasets vertically"

    def get_imports(self) -> list:
        """Get required imports."""
        return ["import pandas as pd"]

    def to_pandas_code(self, ctx: NodeContext) -> str:
        """Generate pandas concat code."""
        var = ctx.variable_name
        indent = "    " * ctx.indent_level

        if not ctx.input_variables:
            return f"{indent}{var} = pd.DataFrame()"

        if len(ctx.input_variables) == 1:
            return f"{indent}{var} = {ctx.input_variables[0]}.copy()"

        lines = []

        # If there are field mappings, rename columns first
        if self.field_mappings:
            lines.append(f"{indent}# Apply column mappings for union")
            union_dfs = []

            for i, input_var in enumerate(ctx.input_variables):
                temp_var = f"_{input_var}_mapped"
                rename_dict = {k: v for k, v in self.field_mappings.items()}
                if rename_dict:
                    rename_str = ', '.join(f"'{escape_string(k)}': '{escape_string(v)}'" for k, v in rename_dict.items())
                    lines.append(f"{indent}{temp_var} = {input_var}.rename(columns={{{rename_str}}})")
                    union_dfs.append(temp_var)
                else:
                    union_dfs.append(input_var)

            dfs_str = ', '.join(union_dfs)
        else:
            dfs_str = ', '.join(ctx.input_variables)

        # Build concat
        if self.remove_mismatched:
            # Inner join on columns (keep only matching columns)
            lines.append(f"{indent}# Keep only columns present in all dataframes")
            lines.append(f"{indent}_union_dfs = [{dfs_str}]")
            lines.append(f"{indent}_common_cols = set(_union_dfs[0].columns)")
            lines.append(f"{indent}for _df in _union_dfs[1:]:")
            lines.append(f"{indent}    _common_cols &= set(_df.columns)")
            lines.append(f"{indent}_common_cols = list(_common_cols)")
            lines.append(f"{indent}{var} = pd.concat([_df[_common_cols] for _df in _union_dfs], axis=0, ignore_index=True)")
        else:
            # Outer join on columns (keep all columns)
            lines.append(f"{indent}{var} = pd.concat([{dfs_str}], axis=0, ignore_index=True)")

        return '\n'.join(lines)
