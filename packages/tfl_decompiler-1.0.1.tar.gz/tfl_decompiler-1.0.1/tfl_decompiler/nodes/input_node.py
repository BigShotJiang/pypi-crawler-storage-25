"""
Input Node - Handle data source connections.

Maps Tableau input sources to pandas read operations:
- CSV -> pd.read_csv()
- Excel -> pd.read_excel()
- JSON -> pd.read_json()
- PostgreSQL -> pd.read_sql()
- MySQL -> pd.read_sql()
- SAP HANA -> pd.read_sql()
"""

from .base import BaseNode, NodeContext
from ..utils import escape_string, sanitize_variable_name


class InputNode(BaseNode):
    """Handler for Tableau Prep input/data source nodes."""

    NODE_TYPE = "input"

    # Map connection types to pandas/sqlalchemy
    CONNECTION_MAP = {
        # File types
        'csv': 'csv',
        'text': 'csv',
        'excel': 'excel',
        'xlsx': 'excel',
        'xls': 'excel',
        'json': 'json',
        'parquet': 'parquet',
        # Database types
        'postgres': 'postgresql',
        'postgresql': 'postgresql',
        'mysql': 'mysql',
        'mariadb': 'mysql',
        'saphana': 'saphana',
        'hana': 'saphana',
        'sqlserver': 'mssql',
        'oracle': 'oracle',
        'snowflake': 'snowflake',
        'bigquery': 'bigquery',
        'redshift': 'redshift',
    }

    def __init__(self, node_data: dict, node_id: str = ""):
        super().__init__(node_data, node_id)
        self.connection_type = self._detect_connection_type()
        self.file_path = self._extract_file_path()
        self.table_name = self._extract_table_name()
        self.query = self._extract_query()
        self.connection_info = self._extract_connection_info()

    def _detect_connection_type(self) -> str:
        """Detect the type of data connection."""
        # Check nodeType first (Tableau's primary type indicator, e.g. ".v1.LoadCsv")
        if 'nodeType' in self.node_data:
            nt = str(self.node_data['nodeType']).lower()
            if 'loadcsv' in nt or 'loadcsvinputunion' in nt:
                return 'csv'
            elif 'loadexcel' in nt or 'loadxls' in nt:
                return 'excel'
            elif 'loadjson' in nt:
                return 'json'
            elif 'loadparquet' in nt:
                return 'parquet'
            elif 'loadsql' in nt or 'loaddatabase' in nt:
                return 'postgresql'

        # Check explicit type fields
        for key in ['connectionType', 'type', 'connectionKind', 'class']:
            if key in self.node_data:
                conn_type = str(self.node_data[key]).lower()
                for pattern, mapped in self.CONNECTION_MAP.items():
                    if pattern in conn_type:
                        return mapped

        # Check file path extension
        path = self._extract_file_path()
        if path:
            path_lower = path.lower()
            if path_lower.endswith('.csv'):
                return 'csv'
            elif path_lower.endswith(('.xlsx', '.xls')):
                return 'excel'
            elif path_lower.endswith('.json'):
                return 'json'
            elif path_lower.endswith('.parquet'):
                return 'parquet'

        # Check for database indicators
        if any(key in self.node_data for key in ['server', 'host', 'database', 'schema']):
            return 'postgresql'  # Default to postgres for DB connections

        return 'csv'  # Default fallback

    def _extract_file_path(self) -> str:
        """Extract file path from node data."""
        for key in ['path', 'filePath', 'fileName', 'file', 'uri', 'directory']:
            if key in self.node_data:
                return str(self.node_data[key])

        # Check connectionAttributes (real Tableau Prep format)
        if 'connectionAttributes' in self.node_data:
            attrs = self.node_data['connectionAttributes']
            if isinstance(attrs, dict):
                for key in ['filename', 'path', 'directory']:
                    if key in attrs:
                        return str(attrs[key])

        # Check nested connection object
        if 'connection' in self.node_data:
            conn = self.node_data['connection']
            if isinstance(conn, dict):
                for key in ['filename', 'path', 'directory']:
                    if key in conn:
                        return str(conn[key])

        return ''

    def _extract_table_name(self) -> str:
        """Extract database table name."""
        for key in ['table', 'tableName', 'relation', 'dbname']:
            if key in self.node_data:
                return str(self.node_data[key])
        return ''

    def _extract_query(self) -> str:
        """Extract custom SQL query if present."""
        for key in ['query', 'sql', 'customSql', 'customQuery']:
            if key in self.node_data:
                return str(self.node_data[key])
        return ''

    def _extract_connection_info(self) -> dict:
        """Extract database connection parameters."""
        info = {}
        param_keys = [
            ('server', ['server', 'host', 'hostname']),
            ('port', ['port']),
            ('database', ['database', 'dbname', 'schema']),
            ('username', ['username', 'user', 'uid']),
            ('password', ['password', 'pwd']),
            ('schema', ['schema', 'schemaname']),
        ]

        for target, keys in param_keys:
            for key in keys:
                if key in self.node_data:
                    info[target] = self.node_data[key]
                    break
                # Check in nested connection object
                if 'connection' in self.node_data:
                    conn = self.node_data['connection']
                    if isinstance(conn, dict) and key in conn:
                        info[target] = conn[key]
                        break

        return info

    def get_description(self) -> str:
        """Get description for code comment."""
        if self.connection_type in ('csv', 'excel', 'json', 'parquet'):
            return f"Load data from {self.connection_type.upper()} file: {self.file_path or 'input file'}"
        else:
            db_name = self.connection_info.get('database', 'database')
            if self.table_name:
                return f"Load data from {self.connection_type} table: {self.table_name}"
            elif self.query:
                return f"Load data from {self.connection_type} using custom SQL"
            else:
                return f"Load data from {self.connection_type} ({db_name})"

    def get_imports(self) -> list:
        """Get required imports."""
        imports = ["import pandas as pd"]

        if self.connection_type in ('postgresql', 'mysql', 'saphana', 'mssql', 'oracle'):
            imports.append("from sqlalchemy import create_engine")

        if self.connection_type == 'postgresql':
            imports.append("# Requires: pip install psycopg2-binary")
        elif self.connection_type == 'mysql':
            imports.append("# Requires: pip install mysql-connector-python")
        elif self.connection_type == 'saphana':
            imports.append("# Requires: pip install hdbcli")

        return imports

    def to_pandas_code(self, ctx: NodeContext) -> str:
        """Generate pandas code for loading data."""
        var = ctx.variable_name
        indent = "    " * ctx.indent_level
        param_name = ctx.param_name

        if self.connection_type == 'csv':
            return self._generate_csv_code(var, indent, param_name)
        elif self.connection_type == 'excel':
            return self._generate_excel_code(var, indent, param_name)
        elif self.connection_type == 'json':
            return self._generate_json_code(var, indent, param_name)
        elif self.connection_type == 'parquet':
            return self._generate_parquet_code(var, indent, param_name)
        elif self.connection_type in ('postgresql', 'mysql', 'saphana'):
            return self._generate_sql_code(var, indent)
        else:
            return f"{indent}# TODO: Unsupported input type: {self.connection_type}\n{indent}{var} = pd.DataFrame()"

    def _generate_csv_code(self, var: str, indent: str, param_name: str = None) -> str:
        """Generate pd.read_csv() code."""
        if param_name:
            return f'{indent}{var} = pd.read_csv({param_name})'
        path = self.file_path or "input.csv"
        safe_path = escape_string(path)
        return f'{indent}{var} = pd.read_csv("{safe_path}")'

    def _generate_excel_code(self, var: str, indent: str, param_name: str = None) -> str:
        """Generate pd.read_excel() code."""
        # Check for sheet name
        sheet = self.get_field_value('sheet', 'sheetName', 'worksheet', default=0)
        if param_name:
            if isinstance(sheet, str):
                return f'{indent}{var} = pd.read_excel({param_name}, sheet_name="{escape_string(sheet)}")'
            return f'{indent}{var} = pd.read_excel({param_name})'
        path = self.file_path or "input.xlsx"
        safe_path = escape_string(path)
        if isinstance(sheet, str):
            return f'{indent}{var} = pd.read_excel("{safe_path}", sheet_name="{escape_string(sheet)}")'
        return f'{indent}{var} = pd.read_excel("{safe_path}")'

    def _generate_json_code(self, var: str, indent: str, param_name: str = None) -> str:
        """Generate pd.read_json() code."""
        if param_name:
            return f'{indent}{var} = pd.read_json({param_name})'
        path = self.file_path or "input.json"
        safe_path = escape_string(path)
        return f'{indent}{var} = pd.read_json("{safe_path}")'

    def _generate_parquet_code(self, var: str, indent: str, param_name: str = None) -> str:
        """Generate pd.read_parquet() code."""
        if param_name:
            return f'{indent}{var} = pd.read_parquet({param_name})'
        path = self.file_path or "input.parquet"
        safe_path = escape_string(path)
        return f'{indent}{var} = pd.read_parquet("{safe_path}")'

    def _generate_sql_code(self, var: str, indent: str) -> str:
        """Generate database connection and read code."""
        lines = []

        # Connection string
        conn_var = f"{var}_engine"
        conn_str = self._build_connection_string()

        lines.append(f'{indent}{conn_var} = create_engine("{conn_str}")')

        # Query or table
        if self.query:
            safe_query = escape_string(self.query)
            lines.append(f'{indent}{var} = pd.read_sql("""{safe_query}""", {conn_var})')
        elif self.table_name:
            safe_table = escape_string(self.table_name)
            lines.append(f'{indent}{var} = pd.read_sql_table("{safe_table}", {conn_var})')
        else:
            lines.append(f'{indent}# TODO: Specify table name or SQL query')
            lines.append(f'{indent}{var} = pd.read_sql("SELECT * FROM your_table", {conn_var})')

        return '\n'.join(lines)

    def _build_connection_string(self) -> str:
        """Build SQLAlchemy connection string."""
        info = self.connection_info

        if self.connection_type == 'postgresql':
            driver = 'postgresql+psycopg2'
        elif self.connection_type == 'mysql':
            driver = 'mysql+mysqlconnector'
        elif self.connection_type == 'saphana':
            driver = 'hana'
        else:
            driver = self.connection_type

        user = info.get('username', 'user')
        password = info.get('password', 'password')
        host = info.get('server', 'localhost')
        port = info.get('port', '')
        database = info.get('database', 'database')

        if port:
            return f"{driver}://{user}:{password}@{host}:{port}/{database}"
        else:
            return f"{driver}://{user}:{password}@{host}/{database}"
