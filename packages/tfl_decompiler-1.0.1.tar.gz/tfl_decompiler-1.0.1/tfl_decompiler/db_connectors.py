"""
Database Connectors - Helper classes for database connections.

Provides standardized connection handling for:
- PostgreSQL (via psycopg2)
- MySQL (via mysql-connector-python)
- SAP HANA (via hdbcli)
"""

from dataclasses import dataclass
from typing import Optional
from urllib.parse import quote_plus


@dataclass
class ConnectionConfig:
    """Database connection configuration."""
    host: str = "localhost"
    port: Optional[int] = None
    database: str = ""
    username: str = ""
    password: str = ""
    schema: Optional[str] = None
    extra_params: dict = None

    def __post_init__(self):
        if self.extra_params is None:
            self.extra_params = {}


class BaseConnector:
    """Base class for database connectors."""

    DRIVER = ""
    DEFAULT_PORT = 0

    def __init__(self, config: ConnectionConfig):
        """
        Initialize connector with configuration.

        Args:
            config: ConnectionConfig instance
        """
        self.config = config

    def get_connection_string(self) -> str:
        """
        Build SQLAlchemy connection string.

        Returns:
            Connection string for SQLAlchemy create_engine()
        """
        config = self.config
        port = config.port or self.DEFAULT_PORT

        # URL-encode password for special characters
        password = quote_plus(config.password) if config.password else ""
        user = quote_plus(config.username) if config.username else ""

        base_url = f"{self.DRIVER}://{user}:{password}@{config.host}:{port}/{config.database}"

        # Add extra parameters
        if config.extra_params:
            params = '&'.join(f"{k}={v}" for k, v in config.extra_params.items())
            base_url = f"{base_url}?{params}"

        return base_url

    def generate_read_code(self, table_or_query: str, var_name: str = "df") -> str:
        """
        Generate pandas read code for this connection.

        Args:
            table_or_query: Table name or SQL query
            var_name: Variable name for DataFrame

        Returns:
            Python code string
        """
        conn_str = self.get_connection_string()
        is_query = table_or_query.strip().upper().startswith('SELECT')

        if is_query:
            return f'''engine = create_engine("{conn_str}")
{var_name} = pd.read_sql("""{table_or_query}""", engine)'''
        else:
            return f'''engine = create_engine("{conn_str}")
{var_name} = pd.read_sql_table("{table_or_query}", engine)'''

    def generate_write_code(self, table_name: str, var_name: str = "df",
                            if_exists: str = "replace") -> str:
        """
        Generate pandas write code for this connection.

        Args:
            table_name: Target table name
            var_name: DataFrame variable name
            if_exists: Behavior if table exists ('replace', 'append', 'fail')

        Returns:
            Python code string
        """
        conn_str = self.get_connection_string()
        return f'''engine = create_engine("{conn_str}")
{var_name}.to_sql("{table_name}", engine, if_exists="{if_exists}", index=False)'''


class PostgreSQLConnector(BaseConnector):
    """PostgreSQL database connector using psycopg2."""

    DRIVER = "postgresql+psycopg2"
    DEFAULT_PORT = 5432

    def get_imports(self) -> list:
        """Get required imports for PostgreSQL."""
        return [
            "from sqlalchemy import create_engine",
            "# pip install psycopg2-binary"
        ]


class MySQLConnector(BaseConnector):
    """MySQL database connector using mysql-connector-python."""

    DRIVER = "mysql+mysqlconnector"
    DEFAULT_PORT = 3306

    def get_imports(self) -> list:
        """Get required imports for MySQL."""
        return [
            "from sqlalchemy import create_engine",
            "# pip install mysql-connector-python"
        ]


class SAPHANAConnector(BaseConnector):
    """SAP HANA database connector using hdbcli."""

    DRIVER = "hana"
    DEFAULT_PORT = 30015

    def get_connection_string(self) -> str:
        """
        Build SAP HANA connection string.

        SAP HANA uses a different format than standard SQLAlchemy.
        """
        config = self.config
        port = config.port or self.DEFAULT_PORT

        # SAP HANA connection string format
        return f"hana://{config.username}:{config.password}@{config.host}:{port}"

    def get_imports(self) -> list:
        """Get required imports for SAP HANA."""
        return [
            "from sqlalchemy import create_engine",
            "# pip install hdbcli sqlalchemy-hana"
        ]


def create_connector(db_type: str, config: ConnectionConfig) -> BaseConnector:
    """
    Factory function to create appropriate connector.

    Args:
        db_type: Database type ('postgresql', 'mysql', 'saphana')
        config: Connection configuration

    Returns:
        Appropriate connector instance
    """
    connectors = {
        'postgresql': PostgreSQLConnector,
        'postgres': PostgreSQLConnector,
        'mysql': MySQLConnector,
        'mariadb': MySQLConnector,
        'saphana': SAPHANAConnector,
        'hana': SAPHANAConnector,
    }

    connector_class = connectors.get(db_type.lower(), PostgreSQLConnector)
    return connector_class(config)


def parse_connection_info(node_data: dict) -> ConnectionConfig:
    """
    Parse connection info from Tableau node data.

    Args:
        node_data: Node data dictionary from flow

    Returns:
        ConnectionConfig instance
    """
    config = ConnectionConfig()

    # Map of our fields to possible Tableau field names
    field_mappings = {
        'host': ['server', 'host', 'hostname', 'serverName'],
        'port': ['port', 'serverPort'],
        'database': ['database', 'dbname', 'databaseName', 'catalog'],
        'username': ['username', 'user', 'uid', 'userName'],
        'password': ['password', 'pwd', 'pass'],
        'schema': ['schema', 'schemaName', 'defaultSchema'],
    }

    for our_field, tableau_fields in field_mappings.items():
        for tf in tableau_fields:
            if tf in node_data:
                setattr(config, our_field, node_data[tf])
                break
            # Check nested connection object
            if 'connection' in node_data:
                conn = node_data['connection']
                if isinstance(conn, dict) and tf in conn:
                    setattr(config, our_field, conn[tf])
                    break

    return config
