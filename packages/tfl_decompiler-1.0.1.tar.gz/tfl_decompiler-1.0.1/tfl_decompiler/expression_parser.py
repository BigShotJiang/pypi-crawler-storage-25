"""
Expression Parser - Convert Tableau calculation syntax to Python/pandas expressions.

Handles:
- [Field Name] -> df['Field Name']
- IF...THEN...ELSE...END -> np.where() or ternary
- CONTAINS(), LEFT(), RIGHT(), MID() -> str methods
- DATEADD(), DATEDIFF() -> datetime operations
- ZN(), IFNULL() -> fillna()
- CASE WHEN -> np.select()
"""

import re
from typing import List, Tuple


class ExpressionParser:
    """
    Parser for converting Tableau calculation expressions to Python/pandas.
    """

    def __init__(self):
        # Function mappings: Tableau function -> (pandas equivalent, num_args)
        self.function_map = {
            # String functions
            'contains': ('str.contains', 2),
            'left': ('str[:{}]', 2),
            'right': ('str[-{}:]', 2),
            'mid': ('str[{}:{}]', 3),
            'len': ('str.len()', 1),
            'length': ('str.len()', 1),
            'upper': ('str.upper()', 1),
            'lower': ('str.lower()', 1),
            'trim': ('str.strip()', 1),
            'ltrim': ('str.lstrip()', 1),
            'rtrim': ('str.rstrip()', 1),
            'replace': ('str.replace', 3),
            'split': ('str.split', 2),
            'find': ('str.find', 2),
            'startswith': ('str.startswith', 2),
            'endswith': ('str.endswith', 2),

            # Null handling
            'zn': ('fillna(0)', 1),
            'ifnull': ('fillna', 2),
            'isnull': ('isna()', 1),
            'isnotnull': ('notna()', 1),

            # Math functions
            'abs': ('abs', 1),
            'round': ('round', 2),
            'floor': ('np.floor', 1),
            'ceiling': ('np.ceil', 1),
            'ceil': ('np.ceil', 1),
            'power': ('np.power', 2),
            'sqrt': ('np.sqrt', 1),
            'log': ('np.log', 1),
            'log10': ('np.log10', 1),
            'exp': ('np.exp', 1),
            'min': ('min', 2),
            'max': ('max', 2),

            # Date functions
            'today': ("pd.Timestamp.today().normalize()", 0),
            'now': ('pd.Timestamp.now()', 0),
            'year': ('dt.year', 1),
            'month': ('dt.month', 1),
            'day': ('dt.day', 1),
            'hour': ('dt.hour', 1),
            'minute': ('dt.minute', 1),
            'second': ('dt.second', 1),
            'datepart': ('dt.{}', 2),
            'dateadd': ('+ pd.DateOffset', 3),
            'datediff': ('-', 2),

            # Type conversion
            'int': ('astype(int)', 1),
            'float': ('astype(float)', 1),
            'str': ('astype(str)', 1),
            'date': ('pd.to_datetime', 1),
        }

        # Operator mappings
        self.operator_map = {
            ' AND ': ' & ',
            ' OR ': ' | ',
            ' NOT ': ' ~',
            '<>': '!=',
            '=': '==',  # Only when not part of >= or <=
        }

    def parse(self, expression: str, df_var: str = "df") -> str:
        """
        Parse a Tableau expression and convert to pandas.

        Args:
            expression: Tableau calculation expression
            df_var: DataFrame variable name to use

        Returns:
            Pandas-compatible Python expression
        """
        if not expression:
            return "True"

        result = expression

        # Handle IF...THEN...ELSE...END first (handles AND/OR in conditions internally)
        result = self._convert_if_then_else(result, df_var)

        # Handle CASE WHEN
        result = self._convert_case_when(result, df_var)

        # Handle field references [Field Name]
        result = self._convert_field_references(result, df_var)

        # Handle functions
        result = self._convert_functions(result, df_var)

        # Handle simple operators (for non-IF expressions)
        result = self._convert_operators(result)

        return result

    def _convert_field_references(self, expr: str, df_var: str) -> str:
        """
        Convert [Field Name] to df['Field Name'].
        """
        pattern = r'\[([^\]]+)\]'

        def replace_field(match):
            field_name = match.group(1)
            return f"{df_var}['{field_name}']"

        return re.sub(pattern, replace_field, expr)

    def _convert_if_then_else(self, expr: str, df_var: str) -> str:
        """
        Convert IF...THEN...ELSE...END to np.where().

        Handles nested IF statements and ELSEIF.
        """
        result = expr

        # First, convert ELSEIF to nested IF structure
        # IF cond1 THEN val1 ELSEIF cond2 THEN val2 ELSE val3 END
        # -> IF cond1 THEN val1 ELSE IF cond2 THEN val2 ELSE val3 END END
        elseif_pattern = r'\bELSEIF\b'
        elseif_count = len(re.findall(elseif_pattern, result, re.IGNORECASE))
        result = re.sub(elseif_pattern, 'ELSE IF', result, flags=re.IGNORECASE)

        # Add extra END for each ELSEIF we converted
        if elseif_count > 0:
            result = result + ' END' * elseif_count

        # Pattern for IF...THEN...ELSE...END (case insensitive)
        # Use non-greedy matching from inside out
        pattern = r'\bIF\s+(.+?)\s+THEN\s+(.+?)\s+ELSE\s+(.+?)\s+END\b'

        def replace_if(match):
            condition = match.group(1).strip()
            then_value = match.group(2).strip()
            else_value = match.group(3).strip()

            # Recursively handle nested IFs
            condition = self._convert_if_then_else(condition, df_var)
            then_value = self._convert_if_then_else(then_value, df_var)
            else_value = self._convert_if_then_else(else_value, df_var)

            # Convert AND/OR in condition to proper Python operators with parentheses
            condition = self._convert_condition_operators(condition)

            return f"np.where({condition}, {then_value}, {else_value})"

        # Keep replacing until no more IF statements
        prev_result = None
        while prev_result != result and re.search(pattern, result, re.IGNORECASE):
            prev_result = result
            result = re.sub(pattern, replace_if, result, flags=re.IGNORECASE)

        # Clean up any remaining END keywords
        result = re.sub(r'\s*\bEND\b', '', result, flags=re.IGNORECASE)

        return result

    def _convert_condition_operators(self, condition: str) -> str:
        """
        Convert AND/OR operators in a condition to Python & and | with proper parentheses.
        """
        result = condition

        # Replace <> with !=
        result = result.replace('<>', '!=')

        # Replace = with == (but not >=, <=, !=, ==, and not keyword args)
        result = re.sub(r'(?<![<>=!\w])=(?![=\w])', ' == ', result)

        # Handle AND - wrap each part in parentheses
        if re.search(r'\bAND\b', result, re.IGNORECASE):
            parts = re.split(r'\s+AND\s+', result, flags=re.IGNORECASE)
            if len(parts) > 1:
                result = ' & '.join(f'({p.strip()})' for p in parts)

        # Handle OR - wrap each part in parentheses
        if re.search(r'\bOR\b', result, re.IGNORECASE):
            parts = re.split(r'\s+OR\s+', result, flags=re.IGNORECASE)
            if len(parts) > 1:
                result = ' | '.join(f'({p.strip()})' for p in parts)

        # Replace NOT with ~
        result = re.sub(r'\bNOT\s+', '~', result, flags=re.IGNORECASE)

        return result

    def _convert_case_when(self, expr: str, df_var: str) -> str:
        """
        Convert CASE WHEN...THEN...ELSE...END to np.select().
        """
        # Check if expression contains CASE WHEN
        if 'CASE' not in expr.upper():
            return expr

        # Pattern for full CASE statement
        case_pattern = r'\bCASE\s+(WHEN.+?)\s+END\b'
        match = re.search(case_pattern, expr, re.IGNORECASE | re.DOTALL)

        if not match:
            return expr

        case_body = match.group(1)

        # Extract WHEN...THEN pairs
        when_pattern = r'\bWHEN\s+(.+?)\s+THEN\s+(.+?)(?=\s+WHEN|\s+ELSE|\s*$)'
        when_matches = re.findall(when_pattern, case_body, re.IGNORECASE)

        # Extract ELSE value
        else_pattern = r'\bELSE\s+(.+?)(?:\s*$)'
        else_match = re.search(else_pattern, case_body, re.IGNORECASE)
        else_value = else_match.group(1).strip() if else_match else 'None'

        if not when_matches:
            return expr

        # Build np.select
        conditions = []
        choices = []

        for condition, value in when_matches:
            conditions.append(condition.strip())
            choices.append(value.strip())

        conditions_str = ', '.join(conditions)
        choices_str = ', '.join(choices)

        replacement = f"np.select([{conditions_str}], [{choices_str}], default={else_value})"

        return re.sub(case_pattern, replacement, expr, flags=re.IGNORECASE | re.DOTALL)

    def _convert_functions(self, expr: str, df_var: str) -> str:
        """
        Convert Tableau functions to pandas equivalents.
        """
        result = expr

        # CONTAINS([Field], 'value') -> df['Field'].str.contains('value')
        pattern = r'\bCONTAINS\s*\(\s*(.+?)\s*,\s*(.+?)\s*\)'
        result = re.sub(
            pattern,
            lambda m: f"{m.group(1)}.str.contains({m.group(2)}, na=False)",
            result,
            flags=re.IGNORECASE
        )

        # LEFT([Field], n) -> df['Field'].str[:n]
        pattern = r'\bLEFT\s*\(\s*(.+?)\s*,\s*(\d+)\s*\)'
        result = re.sub(
            pattern,
            lambda m: f"{m.group(1)}.str[:{m.group(2)}]",
            result,
            flags=re.IGNORECASE
        )

        # RIGHT([Field], n) -> df['Field'].str[-n:]
        pattern = r'\bRIGHT\s*\(\s*(.+?)\s*,\s*(\d+)\s*\)'
        result = re.sub(
            pattern,
            lambda m: f"{m.group(1)}.str[-{m.group(2)}:]",
            result,
            flags=re.IGNORECASE
        )

        # MID([Field], start, length) -> df['Field'].str[start-1:start-1+length]
        pattern = r'\bMID\s*\(\s*(.+?)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)'
        result = re.sub(
            pattern,
            lambda m: f"{m.group(1)}.str[{int(m.group(2))-1}:{int(m.group(2))-1+int(m.group(3))}]",
            result,
            flags=re.IGNORECASE
        )

        # LEN([Field]) -> df['Field'].str.len()
        pattern = r'\bLEN\s*\(\s*(.+?)\s*\)'
        result = re.sub(
            pattern,
            lambda m: f"{m.group(1)}.str.len()",
            result,
            flags=re.IGNORECASE
        )

        # UPPER([Field]) -> df['Field'].str.upper()
        pattern = r'\bUPPER\s*\(\s*(.+?)\s*\)'
        result = re.sub(
            pattern,
            lambda m: f"{m.group(1)}.str.upper()",
            result,
            flags=re.IGNORECASE
        )

        # LOWER([Field]) -> df['Field'].str.lower()
        pattern = r'\bLOWER\s*\(\s*(.+?)\s*\)'
        result = re.sub(
            pattern,
            lambda m: f"{m.group(1)}.str.lower()",
            result,
            flags=re.IGNORECASE
        )

        # TRIM([Field]) -> df['Field'].str.strip()
        pattern = r'\bTRIM\s*\(\s*(.+?)\s*\)'
        result = re.sub(
            pattern,
            lambda m: f"{m.group(1)}.str.strip()",
            result,
            flags=re.IGNORECASE
        )

        # ZN([Field]) -> df['Field'].fillna(0)
        pattern = r'\bZN\s*\(\s*(.+?)\s*\)'
        result = re.sub(
            pattern,
            lambda m: f"{m.group(1)}.fillna(0)",
            result,
            flags=re.IGNORECASE
        )

        # IFNULL([Field], value) -> df['Field'].fillna(value)
        pattern = r'\bIFNULL\s*\(\s*(.+?)\s*,\s*(.+?)\s*\)'
        result = re.sub(
            pattern,
            lambda m: f"{m.group(1)}.fillna({m.group(2)})",
            result,
            flags=re.IGNORECASE
        )

        # ISNULL([Field]) -> df['Field'].isna()
        pattern = r'\bISNULL\s*\(\s*(.+?)\s*\)'
        result = re.sub(
            pattern,
            lambda m: f"{m.group(1)}.isna()",
            result,
            flags=re.IGNORECASE
        )

        # ABS([Field]) -> df['Field'].abs()
        pattern = r'\bABS\s*\(\s*(.+?)\s*\)'
        result = re.sub(
            pattern,
            lambda m: f"np.abs({m.group(1)})",
            result,
            flags=re.IGNORECASE
        )

        # ROUND([Field], decimals) -> df['Field'].round(decimals)
        pattern = r'\bROUND\s*\(\s*(.+?)\s*,\s*(\d+)\s*\)'
        result = re.sub(
            pattern,
            lambda m: f"{m.group(1)}.round({m.group(2)})",
            result,
            flags=re.IGNORECASE
        )

        # YEAR([Field]) -> df['Field'].dt.year
        pattern = r'\bYEAR\s*\(\s*(.+?)\s*\)'
        result = re.sub(
            pattern,
            lambda m: f"{m.group(1)}.dt.year",
            result,
            flags=re.IGNORECASE
        )

        # MONTH([Field]) -> df['Field'].dt.month
        pattern = r'\bMONTH\s*\(\s*(.+?)\s*\)'
        result = re.sub(
            pattern,
            lambda m: f"{m.group(1)}.dt.month",
            result,
            flags=re.IGNORECASE
        )

        # DAY([Field]) -> df['Field'].dt.day
        pattern = r'\bDAY\s*\(\s*(.+?)\s*\)'
        result = re.sub(
            pattern,
            lambda m: f"{m.group(1)}.dt.day",
            result,
            flags=re.IGNORECASE
        )

        # TODAY() -> pd.Timestamp.today().normalize()
        result = re.sub(
            r'\bTODAY\s*\(\s*\)',
            "pd.Timestamp.today().normalize()",
            result,
            flags=re.IGNORECASE
        )

        # NOW() -> pd.Timestamp.now()
        result = re.sub(
            r'\bNOW\s*\(\s*\)',
            "pd.Timestamp.now()",
            result,
            flags=re.IGNORECASE
        )

        # MAKEDATE(year, month, day) -> pd.to_datetime()
        pattern = r'\bMAKEDATE\s*\(\s*(.+?)\s*,\s*(.+?)\s*,\s*(.+?)\s*\)'
        result = re.sub(
            pattern,
            lambda m: f"pd.to_datetime({{{{'year': {m.group(1)}, 'month': {m.group(2)}, 'day': {m.group(3)}}}}})",
            result,
            flags=re.IGNORECASE
        )

        # SPLIT(field, delimiter, index) -> str.split(delimiter)[index-1]
        pattern = r'\bSPLIT\s*\(\s*(.+?)\s*,\s*["\'](.+?)["\']\s*,\s*(\d+)\s*\)'
        result = re.sub(
            pattern,
            lambda m: f"{m.group(1)}.str.split('{m.group(2)}').str[{int(m.group(3))-1}]",
            result,
            flags=re.IGNORECASE
        )

        # STR([Field]) -> astype(str)
        pattern = r'\bSTR\s*\(\s*(.+?)\s*\)'
        result = re.sub(
            pattern,
            lambda m: f"{m.group(1)}.astype(str)",
            result,
            flags=re.IGNORECASE
        )

        # INT([Field]) -> astype(int)
        pattern = r'\bINT\s*\(\s*(.+?)\s*\)'
        result = re.sub(
            pattern,
            lambda m: f"{m.group(1)}.astype(int)",
            result,
            flags=re.IGNORECASE
        )

        # FLOAT([Field]) -> astype(float)
        pattern = r'\bFLOAT\s*\(\s*(.+?)\s*\)'
        result = re.sub(
            pattern,
            lambda m: f"{m.group(1)}.astype(float)",
            result,
            flags=re.IGNORECASE
        )

        # DATE([Field]) -> pd.to_datetime()
        pattern = r'\bDATE\s*\(\s*(.+?)\s*\)'
        result = re.sub(
            pattern,
            lambda m: f"pd.to_datetime({m.group(1)})",
            result,
            flags=re.IGNORECASE
        )

        return result

    def _convert_operators(self, expr: str) -> str:
        """
        Convert Tableau operators to Python operators.
        Only handles simple cases; complex AND/OR in conditions are handled by _convert_condition_operators.
        """
        result = expr

        # Replace <> with !=
        result = result.replace('<>', '!=')

        # Replace = with == (but not >=, <=, !=, ==, and not keyword args like na=False)
        # Don't replace = when preceded by a word character (keyword arg) or followed by word char
        result = re.sub(r'(?<![<>=!\w])=(?![=\w])', ' == ', result)

        # Simple AND/OR replacement (when not wrapped in np.where)
        # Only do this if not already processed by condition operators
        if 'np.where' not in result:
            if re.search(r'\bAND\b', result, re.IGNORECASE):
                parts = re.split(r'\s+AND\s+', result, flags=re.IGNORECASE)
                if len(parts) > 1:
                    result = ' & '.join(f'({p.strip()})' for p in parts)

            if re.search(r'\bOR\b', result, re.IGNORECASE):
                parts = re.split(r'\s+OR\s+', result, flags=re.IGNORECASE)
                if len(parts) > 1:
                    result = ' | '.join(f'({p.strip()})' for p in parts)

        # Replace NOT with ~
        result = re.sub(r'\bNOT\s+', '~', result, flags=re.IGNORECASE)

        return result
