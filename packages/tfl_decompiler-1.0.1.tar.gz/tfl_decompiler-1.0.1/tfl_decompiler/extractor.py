"""
TFL Extractor - Extract and parse Tableau Prep Flow files.

.tfl files are ZIP archives containing:
- flow (JSON): Complete data flow definition
- displaySettings (JSON): UI layout information
- maestroMetadata (JSON): Version info and metadata
"""

import json
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


@dataclass
class TFLContent:
    """Represents extracted content from a .tfl file."""
    flow: dict = field(default_factory=dict)
    display_settings: dict = field(default_factory=dict)
    metadata: dict = field(default_factory=dict)
    raw_files: dict = field(default_factory=dict)
    source_path: str = ""


class TFLExtractor:
    """
    Extracts and parses Tableau Prep Flow (.tfl) files.

    Uses adaptive discovery to handle different .tfl versions and structures.
    """

    # Known file names in .tfl archives (without extensions)
    KNOWN_FILES = ['flow', 'displaySettings', 'maestroMetadata']

    # Alternative names that might appear
    ALTERNATIVE_NAMES = {
        'flow': ['flow', 'flowDefinition', 'main', 'workflow'],
        'displaySettings': ['displaySettings', 'display', 'layout', 'ui'],
        'metadata': ['maestroMetadata', 'metadata', 'meta', 'info']
    }

    def __init__(self, tfl_path: str):
        """
        Initialize extractor with path to .tfl file.

        Args:
            tfl_path: Path to the .tfl file
        """
        self.tfl_path = Path(tfl_path)
        if not self.tfl_path.exists():
            raise FileNotFoundError(f"TFL file not found: {tfl_path}")
        if not self.tfl_path.suffix.lower() in ['.tfl', '.tflx']:
            raise ValueError(f"Expected .tfl or .tflx file, got: {self.tfl_path.suffix}")

    def extract(self) -> TFLContent:
        """
        Extract and parse the .tfl file.

        Returns:
            TFLContent object with parsed JSON data
        """
        content = TFLContent(source_path=str(self.tfl_path))

        try:
            with zipfile.ZipFile(self.tfl_path, 'r') as zf:
                file_list = zf.namelist()
                content.raw_files = {name: True for name in file_list}

                # Extract known files
                content.flow = self._extract_json(zf, file_list, 'flow')
                content.display_settings = self._extract_json(zf, file_list, 'displaySettings')
                content.metadata = self._extract_json(zf, file_list, 'metadata')

                # If flow is empty, try adaptive discovery
                if not content.flow:
                    content.flow = self._discover_flow_structure(zf, file_list)

        except zipfile.BadZipFile:
            # Maybe it's a plain JSON file (some older versions)
            try:
                with open(self.tfl_path, 'r', encoding='utf-8') as f:
                    content.flow = json.load(f)
            except json.JSONDecodeError:
                raise ValueError(f"Cannot parse {self.tfl_path} as ZIP or JSON")

        return content

    def _extract_json(self, zf: zipfile.ZipFile, file_list: list,
                      target: str) -> dict:
        """
        Extract and parse a JSON file from the archive.

        Args:
            zf: ZipFile object
            file_list: List of files in archive
            target: Target file type to find

        Returns:
            Parsed JSON as dictionary
        """
        alternatives = self.ALTERNATIVE_NAMES.get(target, [target])

        for alt_name in alternatives:
            # Try exact match (no extension)
            if alt_name in file_list:
                try:
                    data = zf.read(alt_name).decode('utf-8')
                    return json.loads(data)
                except (json.JSONDecodeError, UnicodeDecodeError):
                    continue

            # Try with .json extension
            json_name = f"{alt_name}.json"
            if json_name in file_list:
                try:
                    data = zf.read(json_name).decode('utf-8')
                    return json.loads(data)
                except (json.JSONDecodeError, UnicodeDecodeError):
                    continue

        return {}

    def _discover_flow_structure(self, zf: zipfile.ZipFile,
                                  file_list: list) -> dict:
        """
        Adaptively discover flow structure when standard files aren't found.

        Args:
            zf: ZipFile object
            file_list: List of files in archive

        Returns:
            Discovered flow structure
        """
        flow_data = {}

        # Try to find any JSON file that looks like a flow
        for filename in file_list:
            if filename.startswith('__') or filename.startswith('.'):
                continue

            try:
                data = zf.read(filename).decode('utf-8')
                parsed = json.loads(data)

                # Check if this looks like a flow definition
                if self._looks_like_flow(parsed):
                    flow_data = parsed
                    break

            except (json.JSONDecodeError, UnicodeDecodeError):
                continue

        return flow_data

    def _looks_like_flow(self, data: dict) -> bool:
        """
        Heuristically determine if JSON data looks like a flow definition.

        Args:
            data: Parsed JSON data

        Returns:
            True if data appears to be a flow definition
        """
        if not isinstance(data, dict):
            return False

        # Look for common flow indicators
        flow_indicators = [
            'nodes', 'steps', 'elements', 'actions',
            'connections', 'links', 'edges',
            'inputs', 'outputs', 'transforms'
        ]

        data_keys_lower = {k.lower() for k in data.keys()}

        for indicator in flow_indicators:
            if indicator in data_keys_lower:
                return True

        # Check nested structures
        for value in data.values():
            if isinstance(value, list) and len(value) > 0:
                if isinstance(value[0], dict):
                    # Check if list items have node-like properties
                    first_item = value[0]
                    node_indicators = ['id', 'nodeId', 'type', 'name', 'action']
                    if any(ind in first_item or ind.lower() in {k.lower() for k in first_item.keys()}
                           for ind in node_indicators):
                        return True

        return False

    def get_flow_summary(self, content: Optional[TFLContent] = None) -> dict:
        """
        Get a summary of the flow structure for analysis.

        Args:
            content: TFLContent object (extracts if not provided)

        Returns:
            Summary dictionary with structure info
        """
        if content is None:
            content = self.extract()

        summary = {
            'source_file': str(self.tfl_path),
            'files_in_archive': list(content.raw_files.keys()),
            'has_flow': bool(content.flow),
            'has_display_settings': bool(content.display_settings),
            'has_metadata': bool(content.metadata),
            'flow_keys': list(content.flow.keys()) if content.flow else [],
            'discovered_structure': self._analyze_structure(content.flow)
        }

        return summary

    def _analyze_structure(self, flow: dict) -> dict:
        """
        Analyze the structure of the flow to understand its schema.

        Args:
            flow: Flow dictionary

        Returns:
            Structure analysis
        """
        if not flow:
            return {}

        analysis = {
            'top_level_keys': list(flow.keys()),
            'arrays': {},
            'objects': {},
            'potential_nodes_key': None,
            'potential_connections_key': None
        }

        for key, value in flow.items():
            if isinstance(value, list):
                analysis['arrays'][key] = {
                    'count': len(value),
                    'item_type': type(value[0]).__name__ if value else 'empty',
                    'sample_keys': list(value[0].keys())[:5] if value and isinstance(value[0], dict) else []
                }

                # Detect nodes array
                if value and isinstance(value[0], dict):
                    first_keys = {k.lower() for k in value[0].keys()}
                    if any(ind in first_keys for ind in ['nodeid', 'id', 'type', 'steptype']):
                        analysis['potential_nodes_key'] = key
                    if any(ind in first_keys for ind in ['source', 'target', 'from', 'to']):
                        analysis['potential_connections_key'] = key

            elif isinstance(value, dict):
                analysis['objects'][key] = list(value.keys())[:5]

        return analysis
