"""
Node Registry - Maps node types to handler classes.

Provides automatic detection and instantiation of the correct node handler
based on the node type in the flow JSON.
"""

from typing import Dict, Type, Optional

from .nodes.base import BaseNode
from .nodes.input_node import InputNode
from .nodes.clean_node import CleanNode
from .nodes.pivot_node import PivotNode
from .nodes.aggregate_node import AggregateNode
from .nodes.join_node import JoinNode
from .nodes.union_node import UnionNode
from .nodes.filter_node import FilterNode
from .nodes.output_node import OutputNode


class NodeRegistry:
    """
    Registry for mapping node types to handler classes.

    Supports both exact matches and pattern-based matching for
    different Tableau Prep versions and naming conventions.
    """

    # Default mappings from node type to handler class
    DEFAULT_MAPPINGS: Dict[str, Type[BaseNode]] = {
        # Input types
        'input': InputNode,
        'datasource': InputNode,
        'source': InputNode,
        'connection': InputNode,
        'load': InputNode,
        'read': InputNode,
        'import': InputNode,

        # Clean/Transform types
        'clean': CleanNode,
        'transform': CleanNode,
        'step': CleanNode,
        'action': CleanNode,
        'modify': CleanNode,
        'calculate': CleanNode,

        # Pivot types
        'pivot': PivotNode,
        'unpivot': PivotNode,
        'melt': PivotNode,
        'transpose': PivotNode,

        # Aggregate types
        'aggregate': AggregateNode,
        'group': AggregateNode,
        'groupby': AggregateNode,
        'summarize': AggregateNode,
        'rollup': AggregateNode,

        # Join types
        'join': JoinNode,
        'merge': JoinNode,
        'lookup': JoinNode,

        # Union types
        'union': UnionNode,
        'append': UnionNode,
        'concat': UnionNode,
        'stack': UnionNode,

        # Filter types
        'filter': FilterNode,
        'select': FilterNode,
        'where': FilterNode,
        'keep': FilterNode,
        'exclude': FilterNode,

        # Output types
        'output': OutputNode,
        'write': OutputNode,
        'export': OutputNode,
        'publish': OutputNode,
        'save': OutputNode,
        'destination': OutputNode,
    }

    def __init__(self):
        """Initialize registry with default mappings."""
        self.mappings = dict(self.DEFAULT_MAPPINGS)
        self.custom_handlers = {}

    def register(self, node_type: str, handler_class: Type[BaseNode]):
        """
        Register a custom handler for a node type.

        Args:
            node_type: Type string to match
            handler_class: Handler class to use
        """
        self.mappings[node_type.lower()] = handler_class
        self.custom_handlers[node_type.lower()] = handler_class

    # Tableau-specific nodeType patterns
    TABLEAU_TYPE_MAP = {
        # Input types - Tableau uses LoadCsv, LoadExcel, LoadSql, etc.
        'loadsql': InputNode,
        'loadcsv': InputNode,
        'loadcsvinputunion': InputNode,  # CSV for union input
        'loadexcel': InputNode,
        'loadfile': InputNode,
        'loadtext': InputNode,
        'connection': InputNode,
        'datasource': InputNode,

        # Output types - Tableau uses WriteToHyper, WriteToFile, etc.
        'writetohydra': OutputNode,
        'writetohyper': OutputNode,
        'writetofile': OutputNode,
        'writetocsv': OutputNode,
        'writeto': OutputNode,
        'publish': OutputNode,
        'export': OutputNode,
        'output': OutputNode,

        # Transform types
        'addcolumn': CleanNode,
        'removecolumn': CleanNode,
        'renamecolumn': CleanNode,
        'remap': CleanNode,
        'cleanstep': CleanNode,
        'transform': CleanNode,
        'calculation': CleanNode,
        'filter': FilterNode,

        # Join/Union - Tableau uses SuperJoin, SuperUnion
        'superjoin': JoinNode,
        'join': JoinNode,
        'superunion': UnionNode,
        'union': UnionNode,
        'append': UnionNode,

        # Aggregate
        'aggregate': AggregateNode,
        'groupby': AggregateNode,
        'superaggregate': AggregateNode,

        # Pivot
        'pivot': PivotNode,
        'unpivot': PivotNode,
        'superpivot': PivotNode,

        # Container (treat as clean/passthrough)
        'container': CleanNode,
    }

    def get_handler(self, node_type: str) -> Type[BaseNode]:
        """
        Get the handler class for a node type.

        Handles Tableau's versioned nodeType format like:
        - .v1.AddColumn
        - .v2018_3_3.Remap
        - .v1.Container

        Args:
            node_type: Node type string from flow JSON

        Returns:
            Handler class for this node type
        """
        if not node_type:
            return CleanNode  # Default fallback

        # Strip version prefix (e.g., ".v1." or ".v2018_3_3.")
        clean_type = node_type
        if clean_type.startswith('.'):
            parts = clean_type.split('.')
            # Take the last part which is the actual type
            clean_type = parts[-1] if parts else clean_type

        normalized = clean_type.lower().replace('_', '').replace('-', '').replace(' ', '')

        # Check Tableau-specific mappings first
        for pattern, handler in self.TABLEAU_TYPE_MAP.items():
            if pattern in normalized:
                return handler

        # Exact match in default mappings
        if normalized in self.mappings:
            return self.mappings[normalized]

        # Partial match - check if any key is contained in the type
        for key, handler in self.mappings.items():
            if key in normalized or normalized in key:
                return handler

        # Pattern-based detection for common variations
        if any(x in normalized for x in ['input', 'source', 'load', 'read', 'connect', 'file']):
            return InputNode
        elif any(x in normalized for x in ['output', 'write', 'export', 'publish', 'save']):
            return OutputNode
        elif any(x in normalized for x in ['pivot', 'unpivot', 'melt', 'transpose']):
            return PivotNode
        elif any(x in normalized for x in ['aggregate', 'group', 'summarize', 'rollup']):
            return AggregateNode
        elif any(x in normalized for x in ['join', 'merge', 'lookup', 'superjoin']):
            return JoinNode
        elif any(x in normalized for x in ['union', 'append', 'concat', 'stack']):
            return UnionNode
        elif any(x in normalized for x in ['filter', 'where', 'keep', 'exclude']):
            return FilterNode
        elif any(x in normalized for x in ['clean', 'transform', 'step', 'action', 'add', 'remove', 'rename', 'remap', 'column']):
            return CleanNode

        # Default to CleanNode for unknown types
        return CleanNode

    def create_node(self, node_data: dict, node_id: str = "") -> BaseNode:
        """
        Create a node handler instance from node data.

        Automatically detects the node type and instantiates the
        appropriate handler.

        Args:
            node_data: Raw node data from flow JSON
            node_id: Node identifier

        Returns:
            Instantiated node handler
        """
        # Try to detect node type from data
        node_type = self._detect_type(node_data)
        handler_class = self.get_handler(node_type)

        return handler_class(node_data, node_id)

    def _detect_type(self, node_data: dict) -> str:
        """
        Detect node type from node data.

        Handles Tableau's format with nodeType and baseType fields.

        Args:
            node_data: Raw node data dictionary

        Returns:
            Detected node type string
        """
        # Try nodeType first (Tableau's primary type indicator)
        if 'nodeType' in node_data:
            return str(node_data['nodeType'])

        # Try other type keys
        for key in ['type', 'stepType', 'kind', 'class', 'operation']:
            if key in node_data:
                return str(node_data[key])

        # Check baseType (Tableau's general category)
        if 'baseType' in node_data:
            base_type = str(node_data['baseType']).lower()
            if base_type == 'input' or base_type == 'datasource':
                return 'input'
            elif base_type == 'output' or base_type == 'publish':
                return 'output'
            elif base_type == 'transform':
                # More specific detection for transform types
                if 'expression' in node_data and 'columnName' in node_data:
                    return 'addcolumn'  # Calculated field
                elif 'values' in node_data:
                    return 'remap'  # Value replacement
                return 'clean'
            elif base_type == 'container':
                return 'container'

        # Check for type indicators in actions
        if 'actions' in node_data:
            actions = node_data['actions']
            if isinstance(actions, list) and actions:
                first_action = actions[0]
                if isinstance(first_action, dict):
                    for key in ['type', 'actionType', 'operation']:
                        if key in first_action:
                            return str(first_action[key])

        # Check for Tableau-specific transform fields
        if 'expression' in node_data and 'columnName' in node_data:
            return 'addcolumn'
        if 'values' in node_data and 'columnName' in node_data:
            return 'remap'

        # Check for specific fields that indicate type
        if any(k in node_data for k in ['filePath', 'path', 'connection', 'connectionType']):
            if any(k in node_data for k in ['outputPath', 'outputType', 'destination']):
                return 'output'
            return 'input'

        if 'joinClauses' in node_data or 'joinType' in node_data:
            return 'join'

        if 'groupByColumns' in node_data or 'aggregations' in node_data:
            return 'aggregate'

        if 'pivotColumns' in node_data or 'pivotType' in node_data:
            return 'pivot'

        if 'conditions' in node_data or 'filterConditions' in node_data:
            return 'filter'

        # Default
        return 'clean'

    def list_registered_types(self) -> Dict[str, str]:
        """
        List all registered type mappings.

        Returns:
            Dictionary of type -> handler class name
        """
        return {
            node_type: handler.__name__
            for node_type, handler in self.mappings.items()
        }


# Global registry instance
registry = NodeRegistry()
