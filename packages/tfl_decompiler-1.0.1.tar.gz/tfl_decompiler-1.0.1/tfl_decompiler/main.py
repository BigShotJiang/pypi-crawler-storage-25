#!/usr/bin/env python3
"""
TFL Decompiler - Main entry point.

Convert Tableau Prep Flow files (.tfl) to Python/pandas scripts.

Usage:
    python -m tfl_decompiler input.tfl -o output.py
    python -m tfl_decompiler input.tfl --analyze
"""

import argparse
import json
import sys
from pathlib import Path

from .extractor import TFLExtractor
from .flow_parser import FlowParser
from .code_generator import CodeGenerator, generate_code


def decompile(tfl_path: str, output_path: str = None, analyze: bool = False) -> str:
    """
    Decompile a .tfl file to Python code.

    Args:
        tfl_path: Path to input .tfl file
        output_path: Path for output .py file (optional)
        analyze: If True, only analyze structure without generating code

    Returns:
        Generated Python code string
    """
    # Extract TFL contents
    extractor = TFLExtractor(tfl_path)
    content = extractor.extract()

    if analyze:
        # Return analysis instead of code
        summary = extractor.get_flow_summary(content)
        return json.dumps(summary, indent=2, default=str)

    # Parse flow structure
    parser = FlowParser(content.flow)
    graph = parser.parse()

    # Generate Python code
    code = generate_code(graph, source_file=tfl_path)

    # Write to output file if specified
    if output_path:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(code)
        print(f"Generated: {output_path}")

    return code


def main():
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Convert Tableau Prep Flow (.tfl) files to Python/pandas scripts",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Basic conversion
    python -m tfl_decompiler my_flow.tfl -o my_flow.py

    # Analyze structure without generating code
    python -m tfl_decompiler my_flow.tfl --analyze

    # Print generated code to stdout
    python -m tfl_decompiler my_flow.tfl

    # Batch conversion
    for f in *.tfl; do python -m tfl_decompiler "$f" -o "${f%.tfl}.py"; done
"""
    )

    parser.add_argument(
        "input",
        help="Input .tfl file path"
    )

    parser.add_argument(
        "-o", "--output",
        help="Output .py file path (default: stdout)"
    )

    parser.add_argument(
        "--analyze",
        action="store_true",
        help="Analyze TFL structure and print summary (no code generation)"
    )

    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Verbose output"
    )

    parser.add_argument(
        "--version",
        action="version",
        version="TFL Decompiler 1.0.0"
    )

    args = parser.parse_args()

    try:
        # Validate input file
        input_path = Path(args.input)
        if not input_path.exists():
            print(f"Error: File not found: {args.input}", file=sys.stderr)
            sys.exit(1)

        if not input_path.suffix.lower() in ['.tfl', '.tflx']:
            print(f"Warning: Expected .tfl or .tflx file, got {input_path.suffix}", file=sys.stderr)

        # Process
        result = decompile(
            tfl_path=str(input_path),
            output_path=args.output,
            analyze=args.analyze
        )

        # Output result
        if not args.output:
            print(result)

        if args.verbose:
            print(f"\nProcessed: {args.input}", file=sys.stderr)
            if args.output:
                print(f"Output: {args.output}", file=sys.stderr)

    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
