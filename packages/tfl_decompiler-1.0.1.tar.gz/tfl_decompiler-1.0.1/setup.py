#!/usr/bin/env python3
"""
Setup script for TFL Decompiler.
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read() if fh else ""

setup(
    name="tfl-decompiler",
    version="1.0.1",
    author="TFL Decompiler",
    description="Convert Tableau Prep Flow files to Python/pandas scripts",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/your-repo/tfl-decompiler",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Database",
        "Topic :: Scientific/Engineering :: Information Analysis",
    ],
    python_requires=">=3.9",
    install_requires=[
        "pandas>=2.0.0",
        "numpy>=1.24.0",
        "sqlalchemy>=2.0.0",
        "openpyxl>=3.1.0",
    ],
    extras_require={
        "postgresql": ["psycopg2-binary>=2.9.0"],
        "mysql": ["mysql-connector-python>=8.0.0"],
        "saphana": ["hdbcli>=2.10.0"],
        "all": [
            "psycopg2-binary>=2.9.0",
            "mysql-connector-python>=8.0.0",
            "hdbcli>=2.10.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "tfl-decompile=tfl_decompiler.main:main",
        ],
    },
)
