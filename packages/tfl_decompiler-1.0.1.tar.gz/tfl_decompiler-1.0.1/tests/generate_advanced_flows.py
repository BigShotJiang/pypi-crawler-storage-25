#!/usr/bin/env python3
"""
Generate 40 advanced and complex .tfl files for testing the decompiler.
Covers unconventional patterns, edge cases, and advanced use cases.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from tfl_decompiler.builder import FlowBuilder


def generate_all_advanced_flows():
    """Generate all advanced sample .tfl files."""
    output_dir = Path(__file__).parent / "generated_flows" / "advanced"
    output_dir.mkdir(parents=True, exist_ok=True)

    flows = [
        # Complex branching patterns
        ("01_triple_diamond.tfl", generate_triple_diamond),
        ("02_fan_out_fan_in.tfl", generate_fan_out_fan_in),
        ("03_parallel_pipelines.tfl", generate_parallel_pipelines),
        ("04_cascading_branches.tfl", generate_cascading_branches),
        ("05_merge_diverge_merge.tfl", generate_merge_diverge_merge),

        # Deep nesting and chaining
        ("06_deep_transform_chain.tfl", generate_deep_transform_chain),
        ("07_nested_aggregations.tfl", generate_nested_aggregations),
        ("08_sequential_joins_10x.tfl", generate_sequential_joins),
        ("09_filter_cascade.tfl", generate_filter_cascade),
        ("10_transform_gauntlet.tfl", generate_transform_gauntlet),

        # Complex expressions
        ("11_complex_calculations.tfl", generate_complex_calculations),
        ("12_nested_conditionals.tfl", generate_nested_conditionals),
        ("13_string_manipulation_heavy.tfl", generate_string_manipulation),
        ("14_date_calculations.tfl", generate_date_calculations),
        ("15_null_handling_patterns.tfl", generate_null_handling),

        # Advanced aggregations
        ("16_multi_level_rollup.tfl", generate_multi_level_rollup),
        ("17_running_totals.tfl", generate_running_totals),
        ("18_percentile_analysis.tfl", generate_percentile_analysis),
        ("19_yoy_comparison.tfl", generate_yoy_comparison),
        ("20_cohort_analysis.tfl", generate_cohort_analysis),

        # Complex joins
        ("21_self_join.tfl", generate_self_join),
        ("22_cross_join_simulation.tfl", generate_cross_join),
        ("23_anti_join_pattern.tfl", generate_anti_join),
        ("24_semi_join_pattern.tfl", generate_semi_join),
        ("25_bridge_table_join.tfl", generate_bridge_table_join),

        # Data quality patterns
        ("26_deduplication_flow.tfl", generate_deduplication),
        ("27_data_validation.tfl", generate_data_validation),
        ("28_outlier_detection.tfl", generate_outlier_detection),
        ("29_data_profiling.tfl", generate_data_profiling),
        ("30_completeness_check.tfl", generate_completeness_check),

        # ETL patterns
        ("31_slowly_changing_dim.tfl", generate_scd),
        ("32_incremental_load.tfl", generate_incremental_load),
        ("33_full_refresh.tfl", generate_full_refresh),
        ("34_data_vault_hub.tfl", generate_data_vault_hub),
        ("35_star_schema_build.tfl", generate_star_schema),

        # Edge cases
        ("36_empty_transform.tfl", generate_empty_transform),
        ("37_single_column_flow.tfl", generate_single_column),
        ("38_wide_table_100_cols.tfl", generate_wide_table),
        ("39_unicode_handling.tfl", generate_unicode_handling),
        ("40_special_characters.tfl", generate_special_characters),
    ]

    for filename, generator in flows:
        filepath = output_dir / filename
        try:
            generator(filepath)
            print(f"Generated: {filepath.name}")
        except Exception as e:
            print(f"FAILED: {filepath.name} - {e}")

    print(f"\nGenerated {len(flows)} advanced .tfl files in {output_dir}")


# === Complex Branching Patterns ===

def generate_triple_diamond(output_path: Path):
    """Three sequential diamond patterns (split-merge-split-merge-split-merge)."""
    builder = FlowBuilder()

    source = builder.add_input_csv("data/transactions.csv", "Transactions")

    # Diamond 1: Split by amount
    high = builder.add_filter("High Value", source, "amount", "greaterThan", 1000)
    low = builder.add_filter("Low Value", source, "amount", "lessThan", 1000)
    merge1 = builder.add_union("Merge 1", [high, low])

    # Diamond 2: Split by region
    east = builder.add_filter("East Region", merge1, "region", "equals", "East")
    west = builder.add_filter("West Region", merge1, "region", "equals", "West")
    merge2 = builder.add_union("Merge 2", [east, west])

    # Diamond 3: Split by status
    active = builder.add_filter("Active", merge2, "status", "equals", "active")
    inactive = builder.add_filter("Inactive", merge2, "status", "equals", "inactive")
    merge3 = builder.add_union("Final Merge", [active, inactive])

    builder.add_output_csv("output/triple_diamond.csv", "Output", merge3)
    builder.save(str(output_path))


def generate_fan_out_fan_in(output_path: Path):
    """Single source fans out to 6 branches, all merge back."""
    builder = FlowBuilder()

    source = builder.add_input_csv("data/sales.csv", "Sales")

    # Fan out to 6 different aggregations
    by_region = builder.add_aggregate("By Region", source, ["region"],
        [{"field": "amount", "function": "sum", "outputName": "region_total"}])
    by_product = builder.add_aggregate("By Product", source, ["product"],
        [{"field": "amount", "function": "sum", "outputName": "product_total"}])
    by_customer = builder.add_aggregate("By Customer", source, ["customer_id"],
        [{"field": "amount", "function": "sum", "outputName": "customer_total"}])
    by_date = builder.add_aggregate("By Date", source, ["date"],
        [{"field": "amount", "function": "sum", "outputName": "daily_total"}])
    by_channel = builder.add_aggregate("By Channel", source, ["channel"],
        [{"field": "amount", "function": "sum", "outputName": "channel_total"}])
    by_category = builder.add_aggregate("By Category", source, ["category"],
        [{"field": "amount", "function": "sum", "outputName": "category_total"}])

    # Fan in: union all summaries
    all_summaries = builder.add_union("All Summaries",
        [by_region, by_product, by_customer, by_date, by_channel, by_category])

    builder.add_output_csv("output/fan_out_fan_in.csv", "Combined Summaries", all_summaries)
    builder.save(str(output_path))


def generate_parallel_pipelines(output_path: Path):
    """4 completely independent pipelines from different sources."""
    builder = FlowBuilder()

    # Pipeline 1: Sales
    sales = builder.add_input_csv("data/sales.csv", "Sales")
    sales_clean = builder.add_clean_step("Clean Sales", sales, [
        {"type": "rename", "columnName": "amt", "newName": "amount"}
    ])
    sales_agg = builder.add_aggregate("Sales Summary", sales_clean, ["region"],
        [{"field": "amount", "function": "sum", "outputName": "total_sales"}])
    builder.add_output_csv("output/sales_summary.csv", "Sales Output", sales_agg)

    # Pipeline 2: Inventory
    inventory = builder.add_input_csv("data/inventory.csv", "Inventory")
    inv_clean = builder.add_clean_step("Clean Inventory", inventory, [
        {"type": "changeType", "columnName": "quantity", "newType": "integer"}
    ])
    inv_agg = builder.add_aggregate("Inventory Summary", inv_clean, ["warehouse"],
        [{"field": "quantity", "function": "sum", "outputName": "total_stock"}])
    builder.add_output_csv("output/inventory_summary.csv", "Inventory Output", inv_agg)

    # Pipeline 3: Customers
    customers = builder.add_input_csv("data/customers.csv", "Customers")
    cust_clean = builder.add_clean_step("Clean Customers", customers, [
        {"type": "trim", "columnName": "email"}
    ])
    builder.add_output_csv("output/customers_clean.csv", "Customers Output", cust_clean)

    # Pipeline 4: Products
    products = builder.add_input_csv("data/products.csv", "Products")
    prod_filter = builder.add_filter("Active Products", products, "active", "equals", True)
    builder.add_output_csv("output/active_products.csv", "Products Output", prod_filter)

    builder.save(str(output_path))


def generate_cascading_branches(output_path: Path):
    """Each branch spawns more branches, creating a tree structure."""
    builder = FlowBuilder()

    source = builder.add_input_csv("data/orders.csv", "Orders")

    # Level 1: Split by order type
    retail = builder.add_filter("Retail", source, "order_type", "equals", "retail")
    wholesale = builder.add_filter("Wholesale", source, "order_type", "equals", "wholesale")

    # Level 2: Split retail by region
    retail_east = builder.add_filter("Retail East", retail, "region", "equals", "East")
    retail_west = builder.add_filter("Retail West", retail, "region", "equals", "West")

    # Level 2: Split wholesale by size
    wholesale_large = builder.add_filter("Wholesale Large", wholesale, "amount", "greaterThan", 10000)
    wholesale_small = builder.add_filter("Wholesale Small", wholesale, "amount", "lessThan", 10000)

    # Level 3: Aggregate each leaf
    agg1 = builder.add_aggregate("Retail East Summary", retail_east, ["customer"],
        [{"field": "amount", "function": "sum", "outputName": "total"}])
    agg2 = builder.add_aggregate("Retail West Summary", retail_west, ["customer"],
        [{"field": "amount", "function": "sum", "outputName": "total"}])
    agg3 = builder.add_aggregate("Wholesale Large Summary", wholesale_large, ["customer"],
        [{"field": "amount", "function": "sum", "outputName": "total"}])
    agg4 = builder.add_aggregate("Wholesale Small Summary", wholesale_small, ["customer"],
        [{"field": "amount", "function": "sum", "outputName": "total"}])

    # Output all
    builder.add_output_csv("output/retail_east.csv", "Retail East Out", agg1)
    builder.add_output_csv("output/retail_west.csv", "Retail West Out", agg2)
    builder.add_output_csv("output/wholesale_large.csv", "Wholesale Large Out", agg3)
    builder.add_output_csv("output/wholesale_small.csv", "Wholesale Small Out", agg4)

    builder.save(str(output_path))


def generate_merge_diverge_merge(output_path: Path):
    """Two sources merge, diverge into 3 branches, then merge again."""
    builder = FlowBuilder()

    source1 = builder.add_input_csv("data/online_sales.csv", "Online Sales")
    source2 = builder.add_input_csv("data/store_sales.csv", "Store Sales")

    # First merge
    all_sales = builder.add_union("All Sales", [source1, source2])

    # Diverge into 3 aggregations
    by_day = builder.add_aggregate("Daily", all_sales, ["date"],
        [{"field": "amount", "function": "sum", "outputName": "daily_total"}])
    by_week = builder.add_aggregate("Weekly", all_sales, ["week"],
        [{"field": "amount", "function": "sum", "outputName": "weekly_total"}])
    by_month = builder.add_aggregate("Monthly", all_sales, ["month"],
        [{"field": "amount", "function": "sum", "outputName": "monthly_total"}])

    # Join all time periods together
    day_week = builder.add_join("Day+Week", by_day, by_week, "left", "date", "date")
    all_periods = builder.add_join("All Periods", day_week, by_month, "left", "date", "date")

    builder.add_output_csv("output/time_analysis.csv", "Time Analysis", all_periods)
    builder.save(str(output_path))


# === Deep Nesting and Chaining ===

def generate_deep_transform_chain(output_path: Path):
    """15 sequential transformation steps."""
    builder = FlowBuilder()

    current = builder.add_input_csv("data/raw_data.csv", "Raw Data")

    # Chain of 15 transformations
    current = builder.add_clean_step("Step 01 - Trim", current, [
        {"type": "trim", "columnName": "name"}])
    current = builder.add_clean_step("Step 02 - Uppercase", current, [
        {"type": "uppercase", "columnName": "code"}])
    current = builder.add_clean_step("Step 03 - Rename", current, [
        {"type": "rename", "columnName": "old_field", "newName": "new_field"}])
    current = builder.add_clean_step("Step 04 - Remove", current, [
        {"type": "remove", "columnName": "temp_col"}])
    current = builder.add_clean_step("Step 05 - Change Type", current, [
        {"type": "changeType", "columnName": "amount", "newType": "float"}])
    current = builder.add_calculated_field("Step 06 - Calc 1", current, "doubled", "[amount] * 2")
    current = builder.add_calculated_field("Step 07 - Calc 2", current, "tripled", "[amount] * 3")
    current = builder.add_filter("Step 08 - Filter", current, "amount", "greaterThan", 0)
    current = builder.add_clean_step("Step 09 - Fill Null", current, [
        {"type": "fillNull", "columnName": "category", "value": "Unknown"}])
    current = builder.add_clean_step("Step 10 - Lowercase", current, [
        {"type": "lowercase", "columnName": "description"}])
    current = builder.add_clean_step("Step 11 - Replace", current, [
        {"type": "replace", "columnName": "status", "oldValue": "N/A", "newValue": "Unknown"}])
    current = builder.add_calculated_field("Step 12 - Calc 3", current, "half", "[amount] / 2")
    current = builder.add_clean_step("Step 13 - Remove 2", current, [
        {"type": "remove", "columnName": "internal_id"}])
    current = builder.add_clean_step("Step 14 - Trim 2", current, [
        {"type": "trim", "columnName": "address"}])
    current = builder.add_clean_step("Step 15 - Final Clean", current, [
        {"type": "dropNull", "columnName": "required_field"}])

    builder.add_output_csv("output/deep_chain.csv", "Output", current)
    builder.save(str(output_path))


def generate_nested_aggregations(output_path: Path):
    """Aggregate, then aggregate again, then again."""
    builder = FlowBuilder()

    source = builder.add_input_csv("data/transactions.csv", "Transactions")

    # Level 1: Daily by product
    daily = builder.add_aggregate("Daily Product Sales", source, ["date", "product"],
        [{"field": "amount", "function": "sum", "outputName": "daily_amount"},
         {"field": "quantity", "function": "sum", "outputName": "daily_qty"}])

    # Level 2: Monthly by product (aggregate daily)
    monthly = builder.add_aggregate("Monthly Product Sales", daily, ["month", "product"],
        [{"field": "daily_amount", "function": "sum", "outputName": "monthly_amount"},
         {"field": "daily_qty", "function": "sum", "outputName": "monthly_qty"}])

    # Level 3: Yearly totals (aggregate monthly)
    yearly = builder.add_aggregate("Yearly Totals", monthly, ["year"],
        [{"field": "monthly_amount", "function": "sum", "outputName": "yearly_amount"},
         {"field": "monthly_qty", "function": "sum", "outputName": "yearly_qty"},
         {"field": "product", "function": "countd", "outputName": "unique_products"}])

    builder.add_output_csv("output/nested_agg.csv", "Yearly Summary", yearly)
    builder.save(str(output_path))


def generate_sequential_joins(output_path: Path):
    """10 sequential left joins to build a wide table."""
    builder = FlowBuilder()

    # Main table
    main = builder.add_input_csv("data/main_entity.csv", "Main Entity")

    # 10 lookup tables
    lookups = []
    for i in range(1, 11):
        lookup = builder.add_input_csv(f"data/lookup_{i}.csv", f"Lookup {i}")
        lookups.append(lookup)

    # Chain of joins
    current = main
    for i, lookup in enumerate(lookups, 1):
        current = builder.add_join(
            f"Join Lookup {i}",
            current, lookup,
            join_type="left",
            left_key="entity_id",
            right_key="entity_id"
        )

    builder.add_output_csv("output/wide_joined.csv", "Fully Enriched", current)
    builder.save(str(output_path))


def generate_filter_cascade(output_path: Path):
    """8 sequential filters, each narrowing the dataset."""
    builder = FlowBuilder()

    current = builder.add_input_csv("data/all_records.csv", "All Records")

    # Cascade of filters
    current = builder.add_filter("Filter 1 - Active", current, "status", "equals", "active")
    current = builder.add_filter("Filter 2 - Year", current, "year", "greaterThan", 2020)
    current = builder.add_filter("Filter 3 - Amount", current, "amount", "greaterThan", 100)
    current = builder.add_filter("Filter 4 - Region", current, "region", "notEquals", "Unknown")
    current = builder.add_filter("Filter 5 - Category", current, "category", "equals", "Premium")
    current = builder.add_filter("Filter 6 - Channel", current, "channel", "equals", "Online")
    current = builder.add_filter("Filter 7 - Verified", current, "is_verified", "equals", True)
    current = builder.add_filter("Filter 8 - Final", current, "score", "greaterThan", 80)

    builder.add_output_csv("output/filtered_records.csv", "Filtered Output", current)
    builder.save(str(output_path))


def generate_transform_gauntlet(output_path: Path):
    """Every type of transformation in sequence."""
    builder = FlowBuilder()

    current = builder.add_input_csv("data/raw.csv", "Raw Input")

    # Every transform type
    current = builder.add_clean_step("Rename", current, [
        {"type": "rename", "columnName": "a", "newName": "alpha"},
        {"type": "rename", "columnName": "b", "newName": "beta"}])
    current = builder.add_clean_step("Remove", current, [
        {"type": "remove", "columnName": "temp1"},
        {"type": "remove", "columnName": "temp2"}])
    current = builder.add_clean_step("Change Types", current, [
        {"type": "changeType", "columnName": "amount", "newType": "float"},
        {"type": "changeType", "columnName": "date", "newType": "datetime"}])
    current = builder.add_clean_step("String Ops", current, [
        {"type": "trim", "columnName": "name"},
        {"type": "uppercase", "columnName": "code"},
        {"type": "lowercase", "columnName": "email"}])
    current = builder.add_clean_step("Null Handling", current, [
        {"type": "fillNull", "columnName": "optional", "value": "N/A"},
        {"type": "dropNull", "columnName": "required"}])
    current = builder.add_clean_step("Replace Values", current, [
        {"type": "replace", "columnName": "status", "oldValue": "Y", "newValue": "Yes"},
        {"type": "replace", "columnName": "status", "oldValue": "N", "newValue": "No"}])
    current = builder.add_calculated_field("Add Calculation", current, "total", "[price] * [quantity]")
    current = builder.add_filter("Filter Rows", current, "total", "greaterThan", 0)
    current = builder.add_remap("Remap Values", current, "category", {
        "Electronics": ["Electronics", "Tech", "Gadgets"],
        "Clothing": ["Clothing", "Apparel", "Fashion"]
    })

    builder.add_output_csv("output/gauntlet.csv", "Gauntlet Output", current)
    builder.save(str(output_path))


# === Complex Expressions ===

def generate_complex_calculations(output_path: Path):
    """Multiple complex calculated fields."""
    builder = FlowBuilder()

    source = builder.add_input_csv("data/financials.csv", "Financials")

    # Multiple complex calculations
    c1 = builder.add_calculated_field("Gross Profit", source, "gross_profit",
        "[revenue] - [cost_of_goods]")
    c2 = builder.add_calculated_field("Gross Margin", c1, "gross_margin",
        "([revenue] - [cost_of_goods]) / [revenue] * 100")
    c3 = builder.add_calculated_field("Operating Income", c2, "operating_income",
        "[gross_profit] - [operating_expenses]")
    c4 = builder.add_calculated_field("EBITDA", c3, "ebitda",
        "[operating_income] + [depreciation] + [amortization]")
    c5 = builder.add_calculated_field("Net Income", c4, "net_income",
        "[ebitda] - [interest] - [taxes]")
    c6 = builder.add_calculated_field("EPS", c5, "eps",
        "[net_income] / [shares_outstanding]")
    c7 = builder.add_calculated_field("PE Ratio", c6, "pe_ratio",
        "[stock_price] / [eps]")
    c8 = builder.add_calculated_field("ROE", c7, "roe",
        "[net_income] / [shareholder_equity] * 100")

    builder.add_output_csv("output/financial_metrics.csv", "Financial Metrics", c8)
    builder.save(str(output_path))


def generate_nested_conditionals(output_path: Path):
    """Deeply nested IF/ELSEIF/ELSE expressions."""
    builder = FlowBuilder()

    source = builder.add_input_csv("data/customers.csv", "Customers")

    # Nested conditionals
    c1 = builder.add_calculated_field("Customer Tier", source, "tier",
        "IF [total_spend] > 100000 THEN 'Platinum' ELSEIF [total_spend] > 50000 THEN 'Gold' ELSEIF [total_spend] > 10000 THEN 'Silver' ELSEIF [total_spend] > 1000 THEN 'Bronze' ELSE 'Standard' END")

    c2 = builder.add_calculated_field("Risk Score", c1, "risk_score",
        "IF [payment_history] = 'Excellent' THEN 10 ELSEIF [payment_history] = 'Good' THEN 7 ELSEIF [payment_history] = 'Fair' THEN 4 ELSE 1 END")

    c3 = builder.add_calculated_field("Priority Level", c2, "priority",
        "IF [tier] = 'Platinum' THEN 'Critical' ELSEIF [tier] = 'Gold' THEN 'High' ELSEIF [tier] = 'Silver' THEN 'Medium' ELSE 'Normal' END")

    builder.add_output_csv("output/customer_segments.csv", "Customer Segments", c3)
    builder.save(str(output_path))


def generate_string_manipulation(output_path: Path):
    """Heavy string manipulation operations."""
    builder = FlowBuilder()

    source = builder.add_input_csv("data/addresses.csv", "Addresses")

    # String manipulations
    c1 = builder.add_calculated_field("Full Address", source, "full_address",
        "[street] + ', ' + [city] + ', ' + [state] + ' ' + [zip]")
    c2 = builder.add_calculated_field("State Code", c1, "state_code",
        "UPPER(LEFT([state], 2))")
    c3 = builder.add_calculated_field("Zip Prefix", c2, "zip_prefix",
        "LEFT([zip], 3)")
    c4 = builder.add_calculated_field("Clean Phone", c3, "clean_phone",
        "REPLACE(REPLACE(REPLACE([phone], '-', ''), '(', ''), ')', '')")
    c5 = builder.add_clean_step("Trim All", c4, [
        {"type": "trim", "columnName": "street"},
        {"type": "trim", "columnName": "city"},
        {"type": "uppercase", "columnName": "state"}])

    builder.add_output_csv("output/clean_addresses.csv", "Clean Addresses", c5)
    builder.save(str(output_path))


def generate_date_calculations(output_path: Path):
    """Date-based calculations and transformations."""
    builder = FlowBuilder()

    source = builder.add_input_csv("data/orders.csv", "Orders")

    # Date calculations
    c1 = builder.add_calculated_field("Order Year", source, "order_year", "YEAR([order_date])")
    c2 = builder.add_calculated_field("Order Month", c1, "order_month", "MONTH([order_date])")
    c3 = builder.add_calculated_field("Order Day", c2, "order_day", "DAY([order_date])")
    c4 = builder.add_calculated_field("Days Since Order", c3, "days_since",
        "TODAY() - [order_date]")
    c5 = builder.add_calculated_field("Delivery Days", c4, "delivery_days",
        "[delivery_date] - [order_date]")
    c6 = builder.add_calculated_field("Is Weekend", c5, "is_weekend",
        "IF DAYOFWEEK([order_date]) = 1 THEN 'Yes' ELSEIF DAYOFWEEK([order_date]) = 7 THEN 'Yes' ELSE 'No' END")
    c7 = builder.add_calculated_field("Quarter", c6, "quarter",
        "IF [order_month] <= 3 THEN 'Q1' ELSEIF [order_month] <= 6 THEN 'Q2' ELSEIF [order_month] <= 9 THEN 'Q3' ELSE 'Q4' END")

    builder.add_output_csv("output/date_analysis.csv", "Date Analysis", c7)
    builder.save(str(output_path))


def generate_null_handling(output_path: Path):
    """Various null handling patterns."""
    builder = FlowBuilder()

    source = builder.add_input_csv("data/incomplete_data.csv", "Incomplete Data")

    # Null handling
    c1 = builder.add_calculated_field("Safe Amount", source, "safe_amount", "ZN([amount])")
    c2 = builder.add_calculated_field("Default Category", c1, "default_category",
        "IFNULL([category], 'Uncategorized')")
    c3 = builder.add_calculated_field("Has Email", c2, "has_email",
        "IF ISNULL([email]) THEN 'No' ELSE 'Yes' END")
    c4 = builder.add_clean_step("Fill Nulls", c3, [
        {"type": "fillNull", "columnName": "quantity", "value": 0},
        {"type": "fillNull", "columnName": "status", "value": "Unknown"}])
    c5 = builder.add_clean_step("Drop Null Required", c4, [
        {"type": "dropNull", "columnName": "customer_id"}])

    builder.add_output_csv("output/null_handled.csv", "Null Handled", c5)
    builder.save(str(output_path))


# === Advanced Aggregations ===

def generate_multi_level_rollup(output_path: Path):
    """Multiple aggregation levels output separately."""
    builder = FlowBuilder()

    source = builder.add_input_csv("data/sales.csv", "Sales")

    # Different rollup levels
    by_detail = builder.add_aggregate("Detail Level", source,
        ["region", "category", "product", "date"],
        [{"field": "amount", "function": "sum", "outputName": "total"}])

    by_product = builder.add_aggregate("Product Level", source,
        ["region", "category", "product"],
        [{"field": "amount", "function": "sum", "outputName": "total"}])

    by_category = builder.add_aggregate("Category Level", source,
        ["region", "category"],
        [{"field": "amount", "function": "sum", "outputName": "total"}])

    by_region = builder.add_aggregate("Region Level", source,
        ["region"],
        [{"field": "amount", "function": "sum", "outputName": "total"}])

    grand_total = builder.add_aggregate("Grand Total", source, [],
        [{"field": "amount", "function": "sum", "outputName": "grand_total"}])

    # Output all levels
    builder.add_output_csv("output/rollup_detail.csv", "Detail", by_detail)
    builder.add_output_csv("output/rollup_product.csv", "Product", by_product)
    builder.add_output_csv("output/rollup_category.csv", "Category", by_category)
    builder.add_output_csv("output/rollup_region.csv", "Region", by_region)
    builder.add_output_csv("output/rollup_total.csv", "Total", grand_total)

    builder.save(str(output_path))


def generate_running_totals(output_path: Path):
    """Running totals and cumulative calculations."""
    builder = FlowBuilder()

    source = builder.add_input_csv("data/daily_sales.csv", "Daily Sales")

    # Add date parts for ordering
    c1 = builder.add_calculated_field("Sort Key", source, "sort_key",
        "YEAR([date]) * 10000 + MONTH([date]) * 100 + DAY([date])")

    # Aggregate by day
    daily = builder.add_aggregate("Daily Totals", c1, ["date", "sort_key"],
        [{"field": "amount", "function": "sum", "outputName": "daily_total"}])

    # Calculate month-to-date
    mtd = builder.add_calculated_field("Month", daily, "month", "MONTH([date])")

    builder.add_output_csv("output/running_totals.csv", "Running Totals", mtd)
    builder.save(str(output_path))


def generate_percentile_analysis(output_path: Path):
    """Percentile and distribution analysis."""
    builder = FlowBuilder()

    source = builder.add_input_csv("data/scores.csv", "Scores")

    # Multiple aggregations for distribution
    stats = builder.add_aggregate("Score Statistics", source, ["category"],
        [{"field": "score", "function": "min", "outputName": "min_score"},
         {"field": "score", "function": "max", "outputName": "max_score"},
         {"field": "score", "function": "avg", "outputName": "avg_score"},
         {"field": "score", "function": "median", "outputName": "median_score"},
         {"field": "score", "function": "count", "outputName": "count"}])

    # Calculate range
    c1 = builder.add_calculated_field("Score Range", stats, "score_range",
        "[max_score] - [min_score]")

    builder.add_output_csv("output/percentile_analysis.csv", "Percentile Analysis", c1)
    builder.save(str(output_path))


def generate_yoy_comparison(output_path: Path):
    """Year-over-year comparison."""
    builder = FlowBuilder()

    current_year = builder.add_input_csv("data/sales_2024.csv", "Sales 2024")
    prior_year = builder.add_input_csv("data/sales_2023.csv", "Sales 2023")

    # Aggregate both years
    cy_agg = builder.add_aggregate("CY Summary", current_year, ["category"],
        [{"field": "amount", "function": "sum", "outputName": "cy_amount"}])
    py_agg = builder.add_aggregate("PY Summary", prior_year, ["category"],
        [{"field": "amount", "function": "sum", "outputName": "py_amount"}])

    # Join
    comparison = builder.add_join("YoY Comparison", cy_agg, py_agg, "left", "category", "category")

    # Calculate change
    c1 = builder.add_calculated_field("YoY Change", comparison, "yoy_change",
        "[cy_amount] - [py_amount]")
    c2 = builder.add_calculated_field("YoY Pct", c1, "yoy_pct",
        "([cy_amount] - [py_amount]) / [py_amount] * 100")

    builder.add_output_csv("output/yoy_comparison.csv", "YoY Analysis", c2)
    builder.save(str(output_path))


def generate_cohort_analysis(output_path: Path):
    """Customer cohort analysis."""
    builder = FlowBuilder()

    customers = builder.add_input_csv("data/customers.csv", "Customers")
    transactions = builder.add_input_csv("data/transactions.csv", "Transactions")

    # Get first purchase date per customer
    first_purchase = builder.add_aggregate("First Purchase", transactions, ["customer_id"],
        [{"field": "date", "function": "min", "outputName": "first_purchase_date"}])

    # Add cohort month
    cohort = builder.add_calculated_field("Cohort Month", first_purchase, "cohort_month",
        "YEAR([first_purchase_date]) * 100 + MONTH([first_purchase_date])")

    # Join back to transactions
    with_cohort = builder.add_join("With Cohort", transactions, cohort, "left",
        "customer_id", "customer_id")

    # Aggregate by cohort
    cohort_summary = builder.add_aggregate("Cohort Summary", with_cohort, ["cohort_month"],
        [{"field": "customer_id", "function": "countd", "outputName": "cohort_size"},
         {"field": "amount", "function": "sum", "outputName": "total_revenue"}])

    builder.add_output_csv("output/cohort_analysis.csv", "Cohort Analysis", cohort_summary)
    builder.save(str(output_path))


# === Complex Joins ===

def generate_self_join(output_path: Path):
    """Self-join to find related records."""
    builder = FlowBuilder()

    employees = builder.add_input_csv("data/employees.csv", "Employees")

    # Create a copy for manager lookup
    managers = builder.add_clean_step("Manager Copy", employees, [
        {"type": "rename", "columnName": "employee_id", "newName": "manager_id"},
        {"type": "rename", "columnName": "name", "newName": "manager_name"}])

    # Self join
    with_manager = builder.add_join("With Manager", employees, managers, "left",
        "reports_to", "manager_id")

    builder.add_output_csv("output/org_hierarchy.csv", "Org Hierarchy", with_manager)
    builder.save(str(output_path))


def generate_cross_join(output_path: Path):
    """Simulate cross join for all combinations."""
    builder = FlowBuilder()

    products = builder.add_input_csv("data/products.csv", "Products")
    regions = builder.add_input_csv("data/regions.csv", "Regions")

    # Add a dummy key for cross join
    prod_key = builder.add_calculated_field("Product Key", products, "cross_key", "'1'")
    region_key = builder.add_calculated_field("Region Key", regions, "cross_key", "'1'")

    # Join on dummy key (cross join)
    cross = builder.add_join("Cross Join", prod_key, region_key, "inner", "cross_key", "cross_key")

    # Remove dummy key
    clean = builder.add_clean_step("Remove Key", cross, [
        {"type": "remove", "columnName": "cross_key"}])

    builder.add_output_csv("output/product_region_combos.csv", "All Combinations", clean)
    builder.save(str(output_path))


def generate_anti_join(output_path: Path):
    """Anti-join pattern: find records NOT in another table."""
    builder = FlowBuilder()

    all_customers = builder.add_input_csv("data/all_customers.csv", "All Customers")
    active_customers = builder.add_input_csv("data/active_customers.csv", "Active Customers")

    # Add flag to active customers
    flagged = builder.add_calculated_field("Add Flag", active_customers, "is_active", "'Y'")

    # Left join
    joined = builder.add_join("Left Join", all_customers, flagged, "left",
        "customer_id", "customer_id")

    # Filter for null (anti-join)
    inactive = builder.add_calculated_field("Check Inactive", joined, "inactive_flag",
        "IF ISNULL([is_active]) THEN 'Inactive' ELSE 'Active' END")

    anti_join_result = builder.add_filter("Inactive Only", inactive, "inactive_flag", "equals", "Inactive")

    builder.add_output_csv("output/inactive_customers.csv", "Inactive Customers", anti_join_result)
    builder.save(str(output_path))


def generate_semi_join(output_path: Path):
    """Semi-join pattern: keep records that exist in another table."""
    builder = FlowBuilder()

    orders = builder.add_input_csv("data/orders.csv", "Orders")
    vip_customers = builder.add_input_csv("data/vip_customers.csv", "VIP Customers")

    # Add flag
    flagged = builder.add_calculated_field("VIP Flag", vip_customers, "is_vip", "'Y'")

    # Inner join (semi-join)
    vip_orders = builder.add_join("VIP Orders", orders, flagged, "inner",
        "customer_id", "customer_id")

    # Remove the flag (keep original columns)
    clean = builder.add_clean_step("Clean", vip_orders, [
        {"type": "remove", "columnName": "is_vip"}])

    builder.add_output_csv("output/vip_orders.csv", "VIP Orders", clean)
    builder.save(str(output_path))


def generate_bridge_table_join(output_path: Path):
    """Many-to-many join using bridge table."""
    builder = FlowBuilder()

    students = builder.add_input_csv("data/students.csv", "Students")
    courses = builder.add_input_csv("data/courses.csv", "Courses")
    enrollments = builder.add_input_csv("data/enrollments.csv", "Enrollments")

    # Join through bridge
    student_enroll = builder.add_join("Student Enrollments", students, enrollments, "inner",
        "student_id", "student_id")
    full_join = builder.add_join("Full Details", student_enroll, courses, "inner",
        "course_id", "course_id")

    builder.add_output_csv("output/student_courses.csv", "Student Courses", full_join)
    builder.save(str(output_path))


# === Data Quality Patterns ===

def generate_deduplication(output_path: Path):
    """Deduplication workflow."""
    builder = FlowBuilder()

    source = builder.add_input_csv("data/duplicates.csv", "With Duplicates")

    # Add row number for dedup
    with_rownum = builder.add_calculated_field("Row Number", source, "row_num",
        "1")  # Simplified - real dedup would use window function

    # Clean data first
    cleaned = builder.add_clean_step("Standardize", with_rownum, [
        {"type": "trim", "columnName": "email"},
        {"type": "lowercase", "columnName": "email"},
        {"type": "trim", "columnName": "name"}])

    # Aggregate to get first record
    deduped = builder.add_aggregate("Deduplicate", cleaned, ["email"],
        [{"field": "name", "function": "first", "outputName": "name"},
         {"field": "phone", "function": "first", "outputName": "phone"},
         {"field": "address", "function": "first", "outputName": "address"}])

    builder.add_output_csv("output/deduplicated.csv", "Deduplicated", deduped)
    builder.save(str(output_path))


def generate_data_validation(output_path: Path):
    """Data validation and error flagging."""
    builder = FlowBuilder()

    source = builder.add_input_csv("data/raw_data.csv", "Raw Data")

    # Add validation flags
    v1 = builder.add_calculated_field("Email Valid", source, "email_valid",
        "IF CONTAINS([email], '@') THEN 'Valid' ELSE 'Invalid' END")
    v2 = builder.add_calculated_field("Phone Valid", v1, "phone_valid",
        "IF LEN([phone]) >= 10 THEN 'Valid' ELSE 'Invalid' END")
    v3 = builder.add_calculated_field("Amount Valid", v2, "amount_valid",
        "IF [amount] > 0 THEN 'Valid' ELSE 'Invalid' END")
    v4 = builder.add_calculated_field("Overall Valid", v3, "is_valid",
        "IF [email_valid] = 'Valid' AND [phone_valid] = 'Valid' AND [amount_valid] = 'Valid' THEN 'Valid' ELSE 'Invalid' END")

    # Split valid/invalid
    valid = builder.add_filter("Valid Records", v4, "is_valid", "equals", "Valid")
    invalid = builder.add_filter("Invalid Records", v4, "is_valid", "equals", "Invalid")

    builder.add_output_csv("output/valid_records.csv", "Valid", valid)
    builder.add_output_csv("output/invalid_records.csv", "Invalid", invalid)
    builder.save(str(output_path))


def generate_outlier_detection(output_path: Path):
    """Statistical outlier detection."""
    builder = FlowBuilder()

    source = builder.add_input_csv("data/measurements.csv", "Measurements")

    # Calculate statistics
    stats = builder.add_aggregate("Statistics", source, [],
        [{"field": "value", "function": "avg", "outputName": "mean_value"},
         {"field": "value", "function": "min", "outputName": "min_value"},
         {"field": "value", "function": "max", "outputName": "max_value"}])

    # Cross join stats back (using dummy key)
    source_key = builder.add_calculated_field("Source Key", source, "key", "'1'")
    stats_key = builder.add_calculated_field("Stats Key", stats, "key", "'1'")

    with_stats = builder.add_join("With Stats", source_key, stats_key, "inner", "key", "key")

    # Flag outliers
    flagged = builder.add_calculated_field("Outlier Flag", with_stats, "is_outlier",
        "IF [value] > [mean_value] * 3 THEN 'High Outlier' ELSEIF [value] < [mean_value] / 3 THEN 'Low Outlier' ELSE 'Normal' END")

    builder.add_output_csv("output/outlier_detection.csv", "Outlier Analysis", flagged)
    builder.save(str(output_path))


def generate_data_profiling(output_path: Path):
    """Data profiling statistics."""
    builder = FlowBuilder()

    source = builder.add_input_csv("data/to_profile.csv", "Source Data")

    # Profile numeric field
    numeric_stats = builder.add_aggregate("Numeric Profile", source, [],
        [{"field": "amount", "function": "count", "outputName": "count"},
         {"field": "amount", "function": "min", "outputName": "min"},
         {"field": "amount", "function": "max", "outputName": "max"},
         {"field": "amount", "function": "avg", "outputName": "avg"},
         {"field": "amount", "function": "sum", "outputName": "sum"}])

    # Profile categorical field
    category_profile = builder.add_aggregate("Category Profile", source, ["category"],
        [{"field": "id", "function": "count", "outputName": "count"}])

    # Output both
    builder.add_output_csv("output/numeric_profile.csv", "Numeric", numeric_stats)
    builder.add_output_csv("output/category_profile.csv", "Category", category_profile)
    builder.save(str(output_path))


def generate_completeness_check(output_path: Path):
    """Check data completeness by field."""
    builder = FlowBuilder()

    source = builder.add_input_csv("data/check_completeness.csv", "Source")

    # Check each field for nulls
    c1 = builder.add_calculated_field("Name Present", source, "name_present",
        "IF ISNULL([name]) THEN 0 ELSE 1 END")
    c2 = builder.add_calculated_field("Email Present", c1, "email_present",
        "IF ISNULL([email]) THEN 0 ELSE 1 END")
    c3 = builder.add_calculated_field("Phone Present", c2, "phone_present",
        "IF ISNULL([phone]) THEN 0 ELSE 1 END")
    c4 = builder.add_calculated_field("Address Present", c3, "address_present",
        "IF ISNULL([address]) THEN 0 ELSE 1 END")

    # Aggregate completeness
    completeness = builder.add_aggregate("Completeness Stats", c4, [],
        [{"field": "name_present", "function": "sum", "outputName": "names_present"},
         {"field": "email_present", "function": "sum", "outputName": "emails_present"},
         {"field": "phone_present", "function": "sum", "outputName": "phones_present"},
         {"field": "address_present", "function": "sum", "outputName": "addresses_present"},
         {"field": "name_present", "function": "count", "outputName": "total_records"}])

    builder.add_output_csv("output/completeness_report.csv", "Completeness", completeness)
    builder.save(str(output_path))


# === ETL Patterns ===

def generate_scd(output_path: Path):
    """Slowly Changing Dimension Type 2 pattern."""
    builder = FlowBuilder()

    current_dim = builder.add_input_csv("data/dim_customer_current.csv", "Current Dimension")
    new_records = builder.add_input_csv("data/customer_updates.csv", "New Records")

    # Compare and find changes
    comparison = builder.add_join("Compare", current_dim, new_records, "outer",
        "customer_id", "customer_id")

    # Flag record types
    flagged = builder.add_calculated_field("Change Type", comparison, "change_type",
        "IF ISNULL([customer_id_left]) THEN 'INSERT' ELSEIF ISNULL([customer_id_right]) THEN 'DELETE' ELSEIF [name_left] != [name_right] THEN 'UPDATE' ELSE 'NO_CHANGE' END")

    # Filter by type
    inserts = builder.add_filter("Inserts", flagged, "change_type", "equals", "INSERT")
    updates = builder.add_filter("Updates", flagged, "change_type", "equals", "UPDATE")

    builder.add_output_csv("output/scd_inserts.csv", "Inserts", inserts)
    builder.add_output_csv("output/scd_updates.csv", "Updates", updates)
    builder.save(str(output_path))


def generate_incremental_load(output_path: Path):
    """Incremental load pattern with watermark."""
    builder = FlowBuilder()

    source = builder.add_input_csv("data/source_system.csv", "Source System")
    watermark = builder.add_input_csv("data/watermark.csv", "Watermark")

    # Get last loaded timestamp
    wm_value = builder.add_aggregate("Get Watermark", watermark, [],
        [{"field": "last_loaded", "function": "max", "outputName": "watermark_value"}])

    # Add key for join
    source_key = builder.add_calculated_field("Source Key", source, "wm_key", "'1'")
    wm_key = builder.add_calculated_field("WM Key", wm_value, "wm_key", "'1'")

    # Join to get watermark
    with_wm = builder.add_join("With Watermark", source_key, wm_key, "inner", "wm_key", "wm_key")

    # Filter for new records
    new_records = builder.add_calculated_field("Is New", with_wm, "is_new",
        "IF [updated_at] > [watermark_value] THEN 'Y' ELSE 'N' END")
    incremental = builder.add_filter("New Only", new_records, "is_new", "equals", "Y")

    builder.add_output_csv("output/incremental_load.csv", "Incremental", incremental)
    builder.save(str(output_path))


def generate_full_refresh(output_path: Path):
    """Full refresh with truncate-and-load pattern."""
    builder = FlowBuilder()

    # Multiple sources
    source1 = builder.add_input_csv("data/system_a.csv", "System A")
    source2 = builder.add_input_csv("data/system_b.csv", "System B")
    source3 = builder.add_input_csv("data/system_c.csv", "System C")

    # Clean each source
    clean1 = builder.add_clean_step("Clean A", source1, [
        {"type": "rename", "columnName": "id", "newName": "entity_id"},
        {"type": "rename", "columnName": "val", "newName": "value"}])
    clean2 = builder.add_clean_step("Clean B", source2, [
        {"type": "rename", "columnName": "entity_id", "newName": "entity_id"},
        {"type": "rename", "columnName": "amount", "newName": "value"}])
    clean3 = builder.add_clean_step("Clean C", source3, [
        {"type": "rename", "columnName": "key", "newName": "entity_id"},
        {"type": "rename", "columnName": "data", "newName": "value"}])

    # Add source tags
    tag1 = builder.add_calculated_field("Tag A", clean1, "source", "'System A'")
    tag2 = builder.add_calculated_field("Tag B", clean2, "source", "'System B'")
    tag3 = builder.add_calculated_field("Tag C", clean3, "source", "'System C'")

    # Union all
    combined = builder.add_union("Combined", [tag1, tag2, tag3])

    # Add load timestamp
    final = builder.add_calculated_field("Load Time", combined, "loaded_at", "NOW()")

    builder.add_output_csv("output/full_refresh.csv", "Full Refresh", final)
    builder.save(str(output_path))


def generate_data_vault_hub(output_path: Path):
    """Data Vault Hub table pattern."""
    builder = FlowBuilder()

    source = builder.add_input_csv("data/customer_source.csv", "Customer Source")

    # Create hub key (hash of business key)
    hub = builder.add_calculated_field("Hub Key", source, "customer_hk",
        "[customer_id]")  # Simplified - real would be MD5/SHA hash

    # Add metadata
    h1 = builder.add_calculated_field("Load Date", hub, "load_date", "NOW()")
    h2 = builder.add_calculated_field("Record Source", h1, "record_source", "'CRM_SYSTEM'")

    # Select hub columns only
    final = builder.add_clean_step("Select Hub Cols", h2, [
        {"type": "remove", "columnName": "name"},
        {"type": "remove", "columnName": "email"},
        {"type": "remove", "columnName": "phone"}])

    builder.add_output_csv("output/hub_customer.csv", "Hub Customer", final)
    builder.save(str(output_path))


def generate_star_schema(output_path: Path):
    """Star schema fact and dimension building."""
    builder = FlowBuilder()

    # Source tables
    transactions = builder.add_input_csv("data/transactions.csv", "Transactions")
    products = builder.add_input_csv("data/products.csv", "Products")
    customers = builder.add_input_csv("data/customers.csv", "Customers")
    dates = builder.add_input_csv("data/dates.csv", "Date Dim")

    # Build dimension keys
    prod_dim = builder.add_calculated_field("Product SK", products, "product_sk", "[product_id]")
    cust_dim = builder.add_calculated_field("Customer SK", customers, "customer_sk", "[customer_id]")
    date_dim = builder.add_calculated_field("Date SK", dates, "date_sk", "[date_key]")

    # Build fact table
    fact = builder.add_join("Fact + Product", transactions, prod_dim, "inner", "product_id", "product_id")
    fact = builder.add_join("Fact + Customer", fact, cust_dim, "inner", "customer_id", "customer_id")
    fact = builder.add_join("Fact + Date", fact, date_dim, "inner", "transaction_date", "date_value")

    # Output star schema
    builder.add_output_csv("output/dim_product.csv", "Dim Product", prod_dim)
    builder.add_output_csv("output/dim_customer.csv", "Dim Customer", cust_dim)
    builder.add_output_csv("output/dim_date.csv", "Dim Date", date_dim)
    builder.add_output_csv("output/fact_sales.csv", "Fact Sales", fact)

    builder.save(str(output_path))


# === Edge Cases ===

def generate_empty_transform(output_path: Path):
    """Flow with empty transform steps (passthrough)."""
    builder = FlowBuilder()

    source = builder.add_input_csv("data/input.csv", "Input")

    # Empty transforms (no actions)
    pass1 = builder.add_clean_step("Passthrough 1", source, [])
    pass2 = builder.add_clean_step("Passthrough 2", pass1, [])
    pass3 = builder.add_clean_step("Passthrough 3", pass2, [])

    builder.add_output_csv("output/passthrough.csv", "Output", pass3)
    builder.save(str(output_path))


def generate_single_column(output_path: Path):
    """Flow that reduces to single column."""
    builder = FlowBuilder()

    source = builder.add_input_csv("data/wide_data.csv", "Wide Data")

    # Remove all but one column
    clean = builder.add_clean_step("Remove Columns", source, [
        {"type": "remove", "columnName": "col_a"},
        {"type": "remove", "columnName": "col_b"},
        {"type": "remove", "columnName": "col_c"},
        {"type": "remove", "columnName": "col_d"},
        {"type": "remove", "columnName": "col_e"}])

    builder.add_output_csv("output/single_column.csv", "Single Column", clean)
    builder.save(str(output_path))


def generate_wide_table(output_path: Path):
    """Flow with many columns (100+ columns via calculations)."""
    builder = FlowBuilder()

    source = builder.add_input_csv("data/base.csv", "Base")

    # Add many calculated columns
    current = source
    for i in range(1, 51):
        current = builder.add_calculated_field(
            f"Calc {i}", current, f"calc_{i}", f"[value] * {i}")

    builder.add_output_csv("output/wide_table.csv", "Wide Output", current)
    builder.save(str(output_path))


def generate_unicode_handling(output_path: Path):
    """Flow with unicode field names and values."""
    builder = FlowBuilder()

    source = builder.add_input_csv("data/unicode_data.csv", "Unicode Data")

    # Rename with unicode-safe names
    clean = builder.add_clean_step("Unicode Clean", source, [
        {"type": "rename", "columnName": "名前", "newName": "name_jp"},
        {"type": "rename", "columnName": "địa_chỉ", "newName": "address_vn"},
        {"type": "rename", "columnName": "город", "newName": "city_ru"}])

    builder.add_output_csv("output/unicode_clean.csv", "Unicode Output", clean)
    builder.save(str(output_path))


def generate_special_characters(output_path: Path):
    """Flow with special characters in field names."""
    builder = FlowBuilder()

    source = builder.add_input_csv("data/special_chars.csv", "Special Chars")

    # Handle special character fields
    clean = builder.add_clean_step("Clean Special", source, [
        {"type": "rename", "columnName": "field with spaces", "newName": "field_with_spaces"},
        {"type": "rename", "columnName": "field-with-dashes", "newName": "field_with_dashes"},
        {"type": "rename", "columnName": "field.with.dots", "newName": "field_with_dots"},
        {"type": "rename", "columnName": "field/with/slashes", "newName": "field_with_slashes"}])

    builder.add_output_csv("output/special_clean.csv", "Special Output", clean)
    builder.save(str(output_path))


if __name__ == "__main__":
    generate_all_advanced_flows()
