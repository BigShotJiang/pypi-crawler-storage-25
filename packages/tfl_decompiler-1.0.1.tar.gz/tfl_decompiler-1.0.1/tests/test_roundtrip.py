#!/usr/bin/env python3
"""
Comprehensive round-trip tests for TFL Decompiler.

Uses the FlowBuilder (cwprep) to generate .tfl files,
then decompiles them and verifies the output.
"""

import tempfile
from pathlib import Path

import pytest

from tfl_decompiler import decompile
from tfl_decompiler.builder import FlowBuilder
from tfl_decompiler.extractor import TFLExtractor
from tfl_decompiler.flow_parser import FlowParser
from tfl_decompiler.code_generator import generate_code


class TestInputNodes:
    """Test input node types."""

    def test_csv_input(self):
        """Test CSV input node decompilation."""
        builder = FlowBuilder()
        input_id = builder.add_input_csv("data/sales.csv", "Sales Data")
        output_id = builder.add_output_csv("output/result.csv", "Output", input_id)

        with tempfile.NamedTemporaryFile(suffix=".tfl", delete=False) as f:
            builder.save(f.name)
            code = decompile(f.name)

        assert "pd.read_csv" in code
        assert "sales.csv" in code
        assert "to_csv" in code
        compile(code, "<string>", "exec")

    def test_excel_input(self):
        """Test Excel input node decompilation."""
        builder = FlowBuilder()
        input_id = builder.add_input_excel("data/report.xlsx", "Report", sheet="Sheet1")
        output_id = builder.add_output_csv("output/result.csv", "Output", input_id)

        with tempfile.NamedTemporaryFile(suffix=".tfl", delete=False) as f:
            builder.save(f.name)
            code = decompile(f.name)

        assert "pd.read_excel" in code
        assert "report.xlsx" in code
        compile(code, "<string>", "exec")

    def test_multiple_inputs(self):
        """Test multiple input sources."""
        builder = FlowBuilder()
        input1 = builder.add_input_csv("data/sales.csv", "Sales")
        input2 = builder.add_input_csv("data/products.csv", "Products")
        join_id = builder.add_join("Join", input1, input2, "inner", "product_id", "id")
        output_id = builder.add_output_csv("output/result.csv", "Output", join_id)

        with tempfile.NamedTemporaryFile(suffix=".tfl", delete=False) as f:
            builder.save(f.name)
            code = decompile(f.name)

        assert code.count("pd.read_csv") == 2
        assert "pd.merge" in code
        compile(code, "<string>", "exec")


class TestCleanNodes:
    """Test clean/transform node types."""

    def test_rename_action(self):
        """Test rename action decompilation."""
        builder = FlowBuilder()
        input_id = builder.add_input_csv("data/input.csv", "Input")
        clean_id = builder.add_rename("Rename Step", input_id, {
            "old_name": "new_name",
            "old_col": "new_col"
        })
        output_id = builder.add_output_csv("output/result.csv", "Output", clean_id)

        with tempfile.NamedTemporaryFile(suffix=".tfl", delete=False) as f:
            builder.save(f.name)
            code = decompile(f.name)

        assert ".rename(" in code
        assert "'old_name'" in code
        assert "'new_name'" in code
        compile(code, "<string>", "exec")

    def test_calculated_field(self):
        """Test calculated field decompilation."""
        builder = FlowBuilder()
        input_id = builder.add_input_csv("data/input.csv", "Input")
        calc_id = builder.add_calculated_field(
            "Add Total",
            input_id,
            "Total",
            "[Price] * [Quantity]"
        )
        output_id = builder.add_output_csv("output/result.csv", "Output", calc_id)

        with tempfile.NamedTemporaryFile(suffix=".tfl", delete=False) as f:
            builder.save(f.name)
            code = decompile(f.name)

        assert "'Total'" in code
        compile(code, "<string>", "exec")

    def test_filter_action(self):
        """Test filter action decompilation."""
        builder = FlowBuilder()
        input_id = builder.add_input_csv("data/input.csv", "Input")
        filter_id = builder.add_filter("Filter Active", input_id, "status", "equals", "active")
        output_id = builder.add_output_csv("output/result.csv", "Output", filter_id)

        with tempfile.NamedTemporaryFile(suffix=".tfl", delete=False) as f:
            builder.save(f.name)
            code = decompile(f.name)

        assert "==" in code or "filter" in code.lower()
        compile(code, "<string>", "exec")

    def test_remap_values(self):
        """Test value remap decompilation."""
        builder = FlowBuilder()
        input_id = builder.add_input_csv("data/input.csv", "Input")
        remap_id = builder.add_remap("Clean Status", input_id, "status", {
            '"Active"': ['"Active"', '"active"', '"ACTIVE"']
        })
        output_id = builder.add_output_csv("output/result.csv", "Output", remap_id)

        with tempfile.NamedTemporaryFile(suffix=".tfl", delete=False) as f:
            builder.save(f.name)
            code = decompile(f.name)

        assert ".replace(" in code
        compile(code, "<string>", "exec")


class TestJoinNodes:
    """Test join node types."""

    def test_inner_join(self):
        """Test inner join decompilation."""
        builder = FlowBuilder()
        left = builder.add_input_csv("data/orders.csv", "Orders")
        right = builder.add_input_csv("data/customers.csv", "Customers")
        join_id = builder.add_join("Join", left, right, "inner", "customer_id", "id")
        output_id = builder.add_output_csv("output/result.csv", "Output", join_id)

        with tempfile.NamedTemporaryFile(suffix=".tfl", delete=False) as f:
            builder.save(f.name)
            code = decompile(f.name)

        assert "pd.merge" in code
        assert "how='inner'" in code
        compile(code, "<string>", "exec")

    def test_left_join(self):
        """Test left join decompilation."""
        builder = FlowBuilder()
        left = builder.add_input_csv("data/orders.csv", "Orders")
        right = builder.add_input_csv("data/customers.csv", "Customers")
        join_id = builder.add_join("Left Join", left, right, "left", "customer_id", "id")
        output_id = builder.add_output_csv("output/result.csv", "Output", join_id)

        with tempfile.NamedTemporaryFile(suffix=".tfl", delete=False) as f:
            builder.save(f.name)
            code = decompile(f.name)

        assert "pd.merge" in code
        assert "how='left'" in code
        compile(code, "<string>", "exec")

    def test_outer_join(self):
        """Test outer join decompilation."""
        builder = FlowBuilder()
        left = builder.add_input_csv("data/orders.csv", "Orders")
        right = builder.add_input_csv("data/customers.csv", "Customers")
        join_id = builder.add_join("Outer Join", left, right, "outer", "customer_id", "id")
        output_id = builder.add_output_csv("output/result.csv", "Output", join_id)

        with tempfile.NamedTemporaryFile(suffix=".tfl", delete=False) as f:
            builder.save(f.name)
            code = decompile(f.name)

        assert "pd.merge" in code
        assert "how='outer'" in code
        compile(code, "<string>", "exec")


class TestUnionNodes:
    """Test union node types."""

    def test_simple_union(self):
        """Test simple union decompilation."""
        builder = FlowBuilder()
        input1 = builder.add_input_csv("data/sales_q1.csv", "Q1 Sales")
        input2 = builder.add_input_csv("data/sales_q2.csv", "Q2 Sales")
        union_id = builder.add_union("Union Sales", [input1, input2])
        output_id = builder.add_output_csv("output/result.csv", "Output", union_id)

        with tempfile.NamedTemporaryFile(suffix=".tfl", delete=False) as f:
            builder.save(f.name)
            code = decompile(f.name)

        assert "pd.concat" in code
        compile(code, "<string>", "exec")

    def test_triple_union(self):
        """Test union with three inputs."""
        builder = FlowBuilder()
        input1 = builder.add_input_csv("data/region1.csv", "Region 1")
        input2 = builder.add_input_csv("data/region2.csv", "Region 2")
        input3 = builder.add_input_csv("data/region3.csv", "Region 3")
        union_id = builder.add_union("Union Regions", [input1, input2, input3])
        output_id = builder.add_output_csv("output/result.csv", "Output", union_id)

        with tempfile.NamedTemporaryFile(suffix=".tfl", delete=False) as f:
            builder.save(f.name)
            code = decompile(f.name)

        assert "pd.concat" in code
        assert code.count("pd.read_csv") == 3
        compile(code, "<string>", "exec")


class TestAggregateNodes:
    """Test aggregate node types."""

    def test_simple_aggregate(self):
        """Test simple aggregation decompilation."""
        builder = FlowBuilder()
        input_id = builder.add_input_csv("data/sales.csv", "Sales")
        agg_id = builder.add_aggregate(
            "Sales Summary",
            input_id,
            group_by=["category"],
            aggregations=[
                {"field": "amount", "function": "sum"},
                {"field": "quantity", "function": "avg"}
            ]
        )
        output_id = builder.add_output_csv("output/result.csv", "Output", agg_id)

        with tempfile.NamedTemporaryFile(suffix=".tfl", delete=False) as f:
            builder.save(f.name)
            code = decompile(f.name)

        assert ".groupby(" in code
        assert ".agg(" in code
        compile(code, "<string>", "exec")

    def test_multi_group_aggregate(self):
        """Test aggregation with multiple group by columns."""
        builder = FlowBuilder()
        input_id = builder.add_input_csv("data/sales.csv", "Sales")
        agg_id = builder.add_aggregate(
            "Sales by Region/Category",
            input_id,
            group_by=["region", "category"],
            aggregations=[
                {"field": "amount", "function": "sum"},
                {"field": "amount", "function": "count"}
            ]
        )
        output_id = builder.add_output_csv("output/result.csv", "Output", agg_id)

        with tempfile.NamedTemporaryFile(suffix=".tfl", delete=False) as f:
            builder.save(f.name)
            code = decompile(f.name)

        assert ".groupby(" in code
        assert "'region'" in code
        assert "'category'" in code
        compile(code, "<string>", "exec")


class TestPivotNodes:
    """Test pivot node types."""

    def test_columns_to_rows(self):
        """Test pivot columns to rows (unpivot/melt)."""
        builder = FlowBuilder()
        input_id = builder.add_input_csv("data/quarterly.csv", "Quarterly Data")
        pivot_id = builder.add_pivot(
            "Pivot Quarters",
            input_id,
            pivot_columns=["Q1", "Q2", "Q3", "Q4"],
            var_name="Quarter",
            value_name="Revenue"
        )
        output_id = builder.add_output_csv("output/result.csv", "Output", pivot_id)

        with tempfile.NamedTemporaryFile(suffix=".tfl", delete=False) as f:
            builder.save(f.name)
            code = decompile(f.name)

        assert "pd.melt" in code
        assert "'Quarter'" in code
        assert "'Revenue'" in code
        compile(code, "<string>", "exec")


class TestOutputNodes:
    """Test output node types."""

    def test_csv_output(self):
        """Test CSV output decompilation."""
        builder = FlowBuilder()
        input_id = builder.add_input_csv("data/input.csv", "Input")
        output_id = builder.add_output_csv("output/result.csv", "Results", input_id)

        with tempfile.NamedTemporaryFile(suffix=".tfl", delete=False) as f:
            builder.save(f.name)
            code = decompile(f.name)

        assert ".to_csv(" in code
        assert "result.csv" in code
        compile(code, "<string>", "exec")

    def test_excel_output(self):
        """Test Excel output decompilation."""
        builder = FlowBuilder()
        input_id = builder.add_input_csv("data/input.csv", "Input")
        output_id = builder.add_output_excel("output/report.xlsx", "Report", input_id)

        with tempfile.NamedTemporaryFile(suffix=".tfl", delete=False) as f:
            builder.save(f.name)
            code = decompile(f.name)

        assert ".to_excel(" in code
        assert "report.xlsx" in code
        compile(code, "<string>", "exec")


class TestComplexFlows:
    """Test complex multi-step flows."""

    def test_etl_pipeline(self):
        """Test a complete ETL pipeline."""
        builder = FlowBuilder()

        # Extract
        sales = builder.add_input_csv("data/sales.csv", "Sales Data")
        products = builder.add_input_csv("data/products.csv", "Product Catalog")

        # Transform
        clean_sales = builder.add_rename("Clean Sales", sales, {"prod_id": "product_id"})
        joined = builder.add_join("Enrich Sales", clean_sales, products, "inner", "product_id", "id")
        aggregated = builder.add_aggregate(
            "Summarize",
            joined,
            group_by=["category"],
            aggregations=[
                {"field": "amount", "function": "sum"},
                {"field": "quantity", "function": "sum"}
            ]
        )

        # Load
        output_id = builder.add_output_csv("output/summary.csv", "Summary Report", aggregated)

        with tempfile.NamedTemporaryFile(suffix=".tfl", delete=False) as f:
            builder.save(f.name)
            code = decompile(f.name)

        # Verify all operations present
        assert "pd.read_csv" in code
        assert ".rename(" in code
        assert "pd.merge" in code
        assert ".groupby(" in code
        assert ".to_csv(" in code
        compile(code, "<string>", "exec")

    def test_union_then_aggregate(self):
        """Test union followed by aggregation."""
        builder = FlowBuilder()

        # Multiple sources
        q1 = builder.add_input_csv("data/q1.csv", "Q1")
        q2 = builder.add_input_csv("data/q2.csv", "Q2")
        q3 = builder.add_input_csv("data/q3.csv", "Q3")
        q4 = builder.add_input_csv("data/q4.csv", "Q4")

        # Union all
        all_data = builder.add_union("All Quarters", [q1, q2, q3, q4])

        # Aggregate
        summary = builder.add_aggregate(
            "Annual Summary",
            all_data,
            group_by=["product"],
            aggregations=[
                {"field": "revenue", "function": "sum"},
                {"field": "units", "function": "sum"}
            ]
        )

        output_id = builder.add_output_csv("output/annual.csv", "Annual Report", summary)

        with tempfile.NamedTemporaryFile(suffix=".tfl", delete=False) as f:
            builder.save(f.name)
            code = decompile(f.name)

        assert code.count("pd.read_csv") == 4
        assert "pd.concat" in code
        assert ".groupby(" in code
        compile(code, "<string>", "exec")

    def test_multiple_joins(self):
        """Test flow with multiple joins."""
        builder = FlowBuilder()

        orders = builder.add_input_csv("data/orders.csv", "Orders")
        customers = builder.add_input_csv("data/customers.csv", "Customers")
        products = builder.add_input_csv("data/products.csv", "Products")

        # First join
        with_customer = builder.add_join(
            "Add Customer Info",
            orders, customers,
            "left", "customer_id", "id"
        )

        # Second join
        with_product = builder.add_join(
            "Add Product Info",
            with_customer, products,
            "left", "product_id", "id"
        )

        output_id = builder.add_output_csv("output/enriched.csv", "Enriched Orders", with_product)

        with tempfile.NamedTemporaryFile(suffix=".tfl", delete=False) as f:
            builder.save(f.name)
            code = decompile(f.name)

        assert code.count("pd.merge") == 2
        compile(code, "<string>", "exec")


class TestEdgeCases:
    """Test edge cases and special scenarios."""

    def test_passthrough_clean_step(self):
        """Test clean step with no actions (passthrough)."""
        builder = FlowBuilder()
        input_id = builder.add_input_csv("data/input.csv", "Input")
        clean_id = builder.add_clean_step("No-Op", input_id, actions=[])
        output_id = builder.add_output_csv("output/result.csv", "Output", clean_id)

        with tempfile.NamedTemporaryFile(suffix=".tfl", delete=False) as f:
            builder.save(f.name)
            code = decompile(f.name)

        assert ".copy()" in code
        compile(code, "<string>", "exec")

    def test_long_chain(self):
        """Test a long chain of transformations."""
        builder = FlowBuilder()

        current = builder.add_input_csv("data/input.csv", "Input")

        for i in range(5):
            current = builder.add_rename(f"Rename {i}", current, {f"col{i}": f"renamed_{i}"})

        output_id = builder.add_output_csv("output/result.csv", "Output", current)

        with tempfile.NamedTemporaryFile(suffix=".tfl", delete=False) as f:
            builder.save(f.name)
            code = decompile(f.name)

        assert code.count(".rename(") == 5
        compile(code, "<string>", "exec")


class TestGeneratedTFLFiles:
    """Generate and save .tfl files for manual testing."""

    def test_generate_sample_flows(self, tmp_path):
        """Generate sample .tfl files in tests directory."""
        output_dir = Path("tests/generated_flows")
        output_dir.mkdir(exist_ok=True)

        # Simple ETL flow
        builder = FlowBuilder()
        input_id = builder.add_input_csv("data/sales.csv", "Sales")
        clean_id = builder.add_rename("Rename Cols", input_id, {"old": "new"})
        agg_id = builder.add_aggregate("Summary", clean_id, ["category"], [
            {"field": "amount", "function": "sum"}
        ])
        output_id = builder.add_output_csv("output/summary.csv", "Output", agg_id)
        builder.save(output_dir / "simple_etl.tfl")

        # Join flow
        builder = FlowBuilder()
        left = builder.add_input_csv("data/orders.csv", "Orders")
        right = builder.add_input_csv("data/customers.csv", "Customers")
        join_id = builder.add_join("Join", left, right, "inner", "customer_id", "id")
        output_id = builder.add_output_csv("output/joined.csv", "Output", join_id)
        builder.save(output_dir / "join_flow.tfl")

        # Union flow
        builder = FlowBuilder()
        input1 = builder.add_input_csv("data/region1.csv", "Region 1")
        input2 = builder.add_input_csv("data/region2.csv", "Region 2")
        input3 = builder.add_input_csv("data/region3.csv", "Region 3")
        union_id = builder.add_union("Union All", [input1, input2, input3])
        output_id = builder.add_output_csv("output/combined.csv", "Output", union_id)
        builder.save(output_dir / "union_flow.tfl")

        # Pivot flow
        builder = FlowBuilder()
        input_id = builder.add_input_csv("data/quarterly.csv", "Quarterly")
        pivot_id = builder.add_pivot("Pivot", input_id, ["Q1", "Q2", "Q3", "Q4"])
        output_id = builder.add_output_csv("output/pivoted.csv", "Output", pivot_id)
        builder.save(output_dir / "pivot_flow.tfl")

        # Complex flow
        builder = FlowBuilder()
        sales = builder.add_input_csv("data/sales.csv", "Sales")
        returns = builder.add_input_csv("data/returns.csv", "Returns")
        products = builder.add_input_csv("data/products.csv", "Products")

        sales_with_products = builder.add_join("Add Products", sales, products, "left", "product_id", "id")
        returns_clean = builder.add_filter("Active Returns", returns, "status", "equals", "approved")
        joined = builder.add_join("Add Returns", sales_with_products, returns_clean, "left", "order_id", "order_id")
        aggregated = builder.add_aggregate("Summary", joined, ["category", "region"], [
            {"field": "amount", "function": "sum"},
            {"field": "return_amount", "function": "sum"}
        ])
        output_id = builder.add_output_csv("output/analysis.csv", "Analysis", aggregated)
        builder.save(output_dir / "complex_flow.tfl")

        print(f"Generated .tfl files in {output_dir}")
        assert (output_dir / "simple_etl.tfl").exists()
        assert (output_dir / "join_flow.tfl").exists()
        assert (output_dir / "union_flow.tfl").exists()
        assert (output_dir / "pivot_flow.tfl").exists()
        assert (output_dir / "complex_flow.tfl").exists()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
