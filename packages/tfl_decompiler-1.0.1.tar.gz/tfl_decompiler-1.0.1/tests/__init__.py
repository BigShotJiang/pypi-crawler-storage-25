"""
Tests for TFL Decompiler.
"""
