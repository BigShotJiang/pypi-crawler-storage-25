#!/usr/bin/env python3
"""
Generate a mega .tfl file that combines ALL constructs and nodes.
This is the ultimate stress test for the decompiler.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from tfl_decompiler.builder import FlowBuilder


def generate_mega_flow():
    """Generate the ultimate complex flow with every feature."""
    output_dir = Path(__file__).parent / "generated_flows"
    output_dir.mkdir(exist_ok=True)

    builder = FlowBuilder()

    # ==========================================
    # LAYER 1: Multiple Input Sources (8 inputs)
    # ==========================================

    # CSV inputs
    sales_2023 = builder.add_input_csv("data/sales_2023.csv", "Sales 2023")
    sales_2024 = builder.add_input_csv("data/sales_2024.csv", "Sales 2024")

    # Excel inputs
    products = builder.add_input_excel("data/products.xlsx", "Products", sheet="Products")
    categories = builder.add_input_excel("data/products.xlsx", "Categories", sheet="Categories")

    # More CSV inputs
    customers = builder.add_input_csv("data/customers.csv", "Customers")
    regions = builder.add_input_csv("data/regions.csv", "Regions")
    returns = builder.add_input_csv("data/returns.csv", "Returns")
    promotions = builder.add_input_csv("data/promotions.csv", "Promotions")

    # ==========================================
    # LAYER 2: Initial Cleaning & Transformation
    # ==========================================

    # Clean Sales 2023 - multiple operations
    sales_2023_clean = builder.add_clean_step("Clean Sales 2023", sales_2023, [
        {"type": "rename", "columnName": "amt", "newName": "amount"},
        {"type": "rename", "columnName": "qty", "newName": "quantity"},
        {"type": "changeType", "columnName": "amount", "newType": "float"},
        {"type": "changeType", "columnName": "order_date", "newType": "datetime"},
        {"type": "trim", "columnName": "customer_id"},
        {"type": "fillNull", "columnName": "discount", "value": 0},
    ])

    # Clean Sales 2024 - same structure
    sales_2024_clean = builder.add_clean_step("Clean Sales 2024", sales_2024, [
        {"type": "rename", "columnName": "amt", "newName": "amount"},
        {"type": "rename", "columnName": "qty", "newName": "quantity"},
        {"type": "changeType", "columnName": "amount", "newType": "float"},
        {"type": "changeType", "columnName": "order_date", "newType": "datetime"},
        {"type": "trim", "columnName": "customer_id"},
        {"type": "fillNull", "columnName": "discount", "value": 0},
    ])

    # Add year tag to each
    sales_2023_tagged = builder.add_calculated_field(
        "Tag 2023", sales_2023_clean, "fiscal_year", "'2023'"
    )
    sales_2024_tagged = builder.add_calculated_field(
        "Tag 2024", sales_2024_clean, "fiscal_year", "'2024'"
    )

    # Clean products
    products_clean = builder.add_clean_step("Clean Products", products, [
        {"type": "trim", "columnName": "product_name"},
        {"type": "uppercase", "columnName": "sku"},
        {"type": "fillNull", "columnName": "weight", "value": 0},
        {"type": "changeType", "columnName": "price", "newType": "float"},
    ])

    # Clean customers with remap
    customers_clean = builder.add_remap("Standardize Customer Status", customers, "status", {
        "Active": ["Active", "A", "active", "ACTIVE"],
        "Inactive": ["Inactive", "I", "inactive", "INACTIVE"],
        "Pending": ["Pending", "P", "pending", "PENDING"],
    })

    # Clean regions
    regions_clean = builder.add_clean_step("Clean Regions", regions, [
        {"type": "uppercase", "columnName": "region_code"},
        {"type": "trim", "columnName": "region_name"},
    ])

    # Filter returns to approved only
    returns_approved = builder.add_filter(
        "Approved Returns Only", returns, "status", "equals", "approved"
    )

    # Filter active promotions
    promotions_active = builder.add_filter(
        "Active Promotions", promotions, "is_active", "equals", True
    )

    # ==========================================
    # LAYER 3: Union Sales Data
    # ==========================================

    all_sales = builder.add_union("Union All Sales", [sales_2023_tagged, sales_2024_tagged])

    # ==========================================
    # LAYER 4: Complex Calculated Fields
    # ==========================================

    # Net amount calculation
    sales_with_net = builder.add_calculated_field(
        "Calculate Net Amount", all_sales, "net_amount",
        "[amount] - [discount]"
    )

    # Profit calculation
    sales_with_profit = builder.add_calculated_field(
        "Calculate Profit", sales_with_net, "profit",
        "[net_amount] - ([quantity] * [unit_cost])"
    )

    # Profit margin
    sales_with_margin = builder.add_calculated_field(
        "Calculate Margin", sales_with_profit, "profit_margin",
        "[profit] / [net_amount] * 100"
    )

    # Customer tier based on nested conditions
    sales_with_tier = builder.add_calculated_field(
        "Customer Tier", sales_with_margin, "order_tier",
        "IF [net_amount] > 10000 THEN 'Enterprise' ELSEIF [net_amount] > 1000 THEN 'Business' ELSEIF [net_amount] > 100 THEN 'Professional' ELSE 'Starter' END"
    )

    # Date parts
    sales_with_dates = builder.add_calculated_field(
        "Extract Month", sales_with_tier, "order_month",
        "MONTH([order_date])"
    )

    sales_with_quarter = builder.add_calculated_field(
        "Calculate Quarter", sales_with_dates, "order_quarter",
        "IF [order_month] <= 3 THEN 'Q1' ELSEIF [order_month] <= 6 THEN 'Q2' ELSEIF [order_month] <= 9 THEN 'Q3' ELSE 'Q4' END"
    )

    # ==========================================
    # LAYER 5: Multi-way Joins
    # ==========================================

    # Join sales with products
    sales_products = builder.add_join(
        "Join Products", sales_with_quarter, products_clean,
        join_type="left", left_key="product_id", right_key="id"
    )

    # Join with categories
    sales_products_cat = builder.add_join(
        "Join Categories", sales_products, categories,
        join_type="left", left_key="category_id", right_key="id"
    )

    # Join with customers
    sales_full = builder.add_join(
        "Join Customers", sales_products_cat, customers_clean,
        join_type="left", left_key="customer_id", right_key="id"
    )

    # Join with regions
    sales_with_regions = builder.add_join(
        "Join Regions", sales_full, regions_clean,
        join_type="left", left_key="region_id", right_key="id"
    )

    # Left join returns (to identify returned orders)
    sales_with_returns = builder.add_join(
        "Join Returns", sales_with_regions, returns_approved,
        join_type="left", left_key="order_id", right_key="order_id"
    )

    # Left join promotions
    sales_complete = builder.add_join(
        "Join Promotions", sales_with_returns, promotions_active,
        join_type="left", left_key="promo_code", right_key="code"
    )

    # ==========================================
    # LAYER 6: Post-Join Calculations
    # ==========================================

    # Flag returned orders
    with_return_flag = builder.add_calculated_field(
        "Return Flag", sales_complete, "is_returned",
        "IF ISNULL([return_id]) THEN 'No' ELSE 'Yes' END"
    )

    # Flag promoted orders
    with_promo_flag = builder.add_calculated_field(
        "Promo Flag", with_return_flag, "has_promotion",
        "IF ISNULL([promo_id]) THEN 'No' ELSE 'Yes' END"
    )

    # Final net revenue
    with_final_revenue = builder.add_calculated_field(
        "Final Revenue", with_promo_flag, "final_revenue",
        "IF [is_returned] = 'Yes' THEN 0 ELSE [net_amount] - IFNULL([promo_discount], 0) END"
    )

    # ==========================================
    # LAYER 7: Branching - Multiple Aggregations
    # ==========================================

    # Branch 1: Summary by Region and Category
    agg_region_category = builder.add_aggregate(
        "Agg by Region-Category", with_final_revenue,
        group_by=["region_name", "category_name", "fiscal_year"],
        aggregations=[
            {"field": "final_revenue", "function": "sum", "outputName": "total_revenue"},
            {"field": "profit", "function": "sum", "outputName": "total_profit"},
            {"field": "order_id", "function": "count", "outputName": "order_count"},
            {"field": "customer_id", "function": "countd", "outputName": "unique_customers"},
            {"field": "quantity", "function": "sum", "outputName": "total_units"},
        ]
    )

    # Branch 2: Summary by Customer Tier
    agg_customer_tier = builder.add_aggregate(
        "Agg by Customer Tier", with_final_revenue,
        group_by=["order_tier", "fiscal_year", "order_quarter"],
        aggregations=[
            {"field": "final_revenue", "function": "sum", "outputName": "total_revenue"},
            {"field": "final_revenue", "function": "avg", "outputName": "avg_order_value"},
            {"field": "order_id", "function": "count", "outputName": "order_count"},
            {"field": "profit_margin", "function": "avg", "outputName": "avg_margin"},
        ]
    )

    # Branch 3: Summary by Product
    agg_product = builder.add_aggregate(
        "Agg by Product", with_final_revenue,
        group_by=["product_name", "sku", "category_name"],
        aggregations=[
            {"field": "quantity", "function": "sum", "outputName": "units_sold"},
            {"field": "final_revenue", "function": "sum", "outputName": "revenue"},
            {"field": "profit", "function": "sum", "outputName": "profit"},
            {"field": "order_id", "function": "count", "outputName": "orders"},
        ]
    )

    # Branch 4: Monthly Trend
    agg_monthly = builder.add_aggregate(
        "Monthly Trend", with_final_revenue,
        group_by=["fiscal_year", "order_month"],
        aggregations=[
            {"field": "final_revenue", "function": "sum", "outputName": "monthly_revenue"},
            {"field": "profit", "function": "sum", "outputName": "monthly_profit"},
            {"field": "order_id", "function": "count", "outputName": "monthly_orders"},
        ]
    )

    # Branch 5: Returns Analysis
    returns_analysis = builder.add_filter(
        "Returned Orders", with_final_revenue, "is_returned", "equals", "Yes"
    )
    agg_returns = builder.add_aggregate(
        "Returns by Category", returns_analysis,
        group_by=["category_name", "fiscal_year"],
        aggregations=[
            {"field": "order_id", "function": "count", "outputName": "return_count"},
            {"field": "net_amount", "function": "sum", "outputName": "return_value"},
        ]
    )

    # ==========================================
    # LAYER 8: Post-Aggregation Calculations
    # ==========================================

    # Add profit percentage to region-category
    region_cat_with_pct = builder.add_calculated_field(
        "Profit Percentage", agg_region_category, "profit_pct",
        "[total_profit] / [total_revenue] * 100"
    )

    # Add revenue per customer
    region_cat_final = builder.add_calculated_field(
        "Revenue Per Customer", region_cat_with_pct, "revenue_per_customer",
        "[total_revenue] / [unique_customers]"
    )

    # Add average order value to product summary
    product_with_aov = builder.add_calculated_field(
        "Avg Order Value", agg_product, "avg_order_value",
        "[revenue] / [orders]"
    )

    # Add profit per unit
    product_final = builder.add_calculated_field(
        "Profit Per Unit", product_with_aov, "profit_per_unit",
        "[profit] / [units_sold]"
    )

    # ==========================================
    # LAYER 9: Pivot Operations
    # ==========================================

    # Pivot monthly data - columns to rows for visualization
    monthly_pivoted = builder.add_pivot(
        "Pivot Monthly Metrics", agg_monthly,
        pivot_columns=["monthly_revenue", "monthly_profit", "monthly_orders"],
        var_name="metric_name",
        value_name="metric_value"
    )

    # ==========================================
    # LAYER 10: Final Filters and Cleanup
    # ==========================================

    # Filter region summary for significant revenue
    region_significant = builder.add_filter(
        "Significant Regions", region_cat_final,
        "total_revenue", "greaterThan", 10000
    )

    # Filter products with good margins
    products_profitable = builder.add_filter(
        "Profitable Products", product_final,
        "profit_per_unit", "greaterThan", 0
    )

    # Clean up tier analysis
    tier_clean = builder.add_clean_step("Clean Tier Analysis", agg_customer_tier, [
        {"type": "fillNull", "columnName": "avg_margin", "value": 0},
    ])

    # ==========================================
    # LAYER 11: Secondary Unions
    # ==========================================

    # Create a summary of summaries
    # First, add a tag to each summary
    region_tagged = builder.add_calculated_field(
        "Tag Region Summary", region_significant, "summary_type", "'Region-Category'"
    )

    tier_tagged = builder.add_calculated_field(
        "Tag Tier Summary", tier_clean, "summary_type", "'Customer-Tier'"
    )

    # ==========================================
    # LAYER 12: Cross-Analysis Joins
    # ==========================================

    # Join returns analysis back to region summary
    region_with_returns = builder.add_join(
        "Region with Returns", region_tagged, agg_returns,
        join_type="left", left_key="category_name", right_key="category_name"
    )

    # Calculate return rate
    region_return_rate = builder.add_calculated_field(
        "Return Rate", region_with_returns, "return_rate",
        "IFNULL([return_count], 0) / [order_count] * 100"
    )

    # ==========================================
    # LAYER 13: Multiple Outputs
    # ==========================================

    # Output 1: Regional Performance
    builder.add_output_csv(
        "output/regional_performance.csv",
        "Regional Performance",
        region_return_rate
    )

    # Output 2: Customer Tier Analysis
    builder.add_output_csv(
        "output/customer_tiers.csv",
        "Customer Tiers",
        tier_tagged
    )

    # Output 3: Product Performance
    builder.add_output_csv(
        "output/product_performance.csv",
        "Product Performance",
        products_profitable
    )

    # Output 4: Monthly Trends (pivoted)
    builder.add_output_csv(
        "output/monthly_trends.csv",
        "Monthly Trends",
        monthly_pivoted
    )

    # Output 5: Returns Analysis
    builder.add_output_csv(
        "output/returns_analysis.csv",
        "Returns Analysis",
        agg_returns
    )

    # Output 6: Full Detail Data
    builder.add_output_csv(
        "output/full_detail.csv",
        "Full Detail",
        with_final_revenue
    )

    # Output 7: Excel output for executives
    builder.add_output_excel(
        "output/executive_summary.xlsx",
        "Executive Summary",
        region_return_rate
    )

    # Save the mega flow
    output_path = output_dir / "mega_flow_all_constructs.tfl"
    builder.save(str(output_path))
    print(f"Generated mega flow: {output_path}")

    # Print statistics
    print(f"\nFlow Statistics:")
    print(f"  - Input nodes: 8")
    print(f"  - Clean/Transform steps: 15+")
    print(f"  - Calculated fields: 20+")
    print(f"  - Joins: 8")
    print(f"  - Unions: 1")
    print(f"  - Aggregations: 5")
    print(f"  - Pivots: 1")
    print(f"  - Filters: 5")
    print(f"  - Output nodes: 7")
    print(f"  - Total nodes: {len(builder.nodes)}")

    return output_path


if __name__ == "__main__":
    generate_mega_flow()
