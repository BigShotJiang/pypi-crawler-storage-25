#!/usr/bin/env python3
"""
Test suite for TFL Decompiler.

Run with: python -m pytest tests/
"""

import json
import tempfile
import zipfile
from pathlib import Path

import pytest


# Sample flow JSON structure for testing
SAMPLE_FLOW = {
    "nodes": [
        {
            "nodeId": "input_1",
            "type": "input",
            "name": "Sales Data",
            "filePath": "data/sales.csv"
        },
        {
            "nodeId": "clean_1",
            "type": "clean",
            "name": "Transform",
            "actions": [
                {
                    "type": "rename",
                    "columnName": "old_col",
                    "newName": "new_col"
                },
                {
                    "type": "filter",
                    "field": "status",
                    "operator": "equals",
                    "value": "active"
                }
            ]
        },
        {
            "nodeId": "agg_1",
            "type": "aggregate",
            "name": "Summary",
            "groupByColumns": ["category"],
            "aggregations": [
                {"field": "amount", "function": "sum"},
                {"field": "quantity", "function": "avg"}
            ]
        },
        {
            "nodeId": "output_1",
            "type": "output",
            "name": "Results",
            "filePath": "output/results.csv"
        }
    ],
    "connections": [
        {"source": "input_1", "target": "clean_1"},
        {"source": "clean_1", "target": "agg_1"},
        {"source": "agg_1", "target": "output_1"}
    ]
}


def create_test_tfl(flow_data: dict) -> Path:
    """Create a temporary .tfl file for testing."""
    temp_dir = tempfile.mkdtemp()
    tfl_path = Path(temp_dir) / "test_flow.tfl"

    with zipfile.ZipFile(tfl_path, 'w') as zf:
        # Write flow JSON without extension (as Tableau does)
        zf.writestr('flow', json.dumps(flow_data))
        zf.writestr('displaySettings', json.dumps({"version": "1.0"}))
        zf.writestr('maestroMetadata', json.dumps({"version": "2024.1"}))

    return tfl_path


class TestTFLExtractor:
    """Tests for TFLExtractor."""

    def test_extract_valid_tfl(self):
        """Test extracting a valid .tfl file."""
        from tfl_decompiler.extractor import TFLExtractor

        tfl_path = create_test_tfl(SAMPLE_FLOW)
        extractor = TFLExtractor(str(tfl_path))
        content = extractor.extract()

        assert content.flow is not None
        assert "nodes" in content.flow
        assert len(content.flow["nodes"]) == 4

    def test_extract_summary(self):
        """Test flow summary extraction."""
        from tfl_decompiler.extractor import TFLExtractor

        tfl_path = create_test_tfl(SAMPLE_FLOW)
        extractor = TFLExtractor(str(tfl_path))
        content = extractor.extract()
        summary = extractor.get_flow_summary(content)

        assert summary["has_flow"] is True
        assert "nodes" in summary["flow_keys"]


class TestFlowParser:
    """Tests for FlowParser."""

    def test_parse_nodes(self):
        """Test parsing nodes from flow."""
        from tfl_decompiler.flow_parser import FlowParser

        parser = FlowParser(SAMPLE_FLOW)
        graph = parser.parse()

        assert len(graph.nodes) == 4
        assert "input_1" in graph.nodes
        assert "clean_1" in graph.nodes
        assert "agg_1" in graph.nodes
        assert "output_1" in graph.nodes

    def test_parse_connections(self):
        """Test parsing connections."""
        from tfl_decompiler.flow_parser import FlowParser

        parser = FlowParser(SAMPLE_FLOW)
        graph = parser.parse()

        assert len(graph.connections) == 3
        assert ("input_1", "clean_1") in graph.connections

    def test_topological_sort(self):
        """Test execution order is correct."""
        from tfl_decompiler.flow_parser import FlowParser

        parser = FlowParser(SAMPLE_FLOW)
        graph = parser.parse()

        # Input should come first
        assert graph.execution_order.index("input_1") < graph.execution_order.index("clean_1")
        assert graph.execution_order.index("clean_1") < graph.execution_order.index("agg_1")
        assert graph.execution_order.index("agg_1") < graph.execution_order.index("output_1")


class TestNodeRegistry:
    """Tests for NodeRegistry."""

    def test_get_handler_input(self):
        """Test input node handler lookup."""
        from tfl_decompiler.node_registry import registry
        from tfl_decompiler.nodes.input_node import InputNode

        handler = registry.get_handler("input")
        assert handler == InputNode

    def test_get_handler_variations(self):
        """Test handler lookup with variations."""
        from tfl_decompiler.node_registry import registry
        from tfl_decompiler.nodes.aggregate_node import AggregateNode

        assert registry.get_handler("aggregate") == AggregateNode
        assert registry.get_handler("groupby") == AggregateNode
        assert registry.get_handler("summarize") == AggregateNode


class TestExpressionParser:
    """Tests for ExpressionParser."""

    def test_field_reference(self):
        """Test [Field Name] conversion."""
        from tfl_decompiler.expression_parser import ExpressionParser

        parser = ExpressionParser()
        result = parser.parse("[Sales Amount]", "df")

        assert "df['Sales Amount']" in result

    def test_contains_function(self):
        """Test CONTAINS() conversion."""
        from tfl_decompiler.expression_parser import ExpressionParser

        parser = ExpressionParser()
        result = parser.parse("CONTAINS([Name], 'test')", "df")

        assert ".str.contains" in result

    def test_if_then_else(self):
        """Test IF...THEN...ELSE...END conversion."""
        from tfl_decompiler.expression_parser import ExpressionParser

        parser = ExpressionParser()
        result = parser.parse("IF [Amount] > 100 THEN 'High' ELSE 'Low' END", "df")

        assert "np.where" in result

    def test_operators(self):
        """Test operator conversion."""
        from tfl_decompiler.expression_parser import ExpressionParser

        parser = ExpressionParser()

        assert "&" in parser.parse("[A] AND [B]", "df")
        assert "|" in parser.parse("[A] OR [B]", "df")
        assert "!=" in parser.parse("[A] <> [B]", "df")


class TestCodeGenerator:
    """Tests for CodeGenerator."""

    def test_generate_complete_script(self):
        """Test full code generation."""
        from tfl_decompiler.flow_parser import FlowParser
        from tfl_decompiler.code_generator import generate_code

        parser = FlowParser(SAMPLE_FLOW)
        graph = parser.parse()
        code = generate_code(graph, "test_flow.tfl")

        # Check for expected elements
        assert "import pandas as pd" in code
        assert "import numpy as np" in code
        assert "def main(" in code
        assert "pd.read_csv" in code
        assert ".groupby(" in code
        assert ".to_csv(" in code
        assert 'if __name__ == "__main__"' in code


class TestNodeHandlers:
    """Tests for individual node handlers."""

    def test_input_node_csv(self):
        """Test InputNode for CSV."""
        from tfl_decompiler.nodes.input_node import InputNode
        from tfl_decompiler.nodes.base import NodeContext

        node_data = {
            "type": "input",
            "filePath": "data/test.csv"
        }
        node = InputNode(node_data, "test_input")
        ctx = NodeContext(variable_name="df_test", step_number=1, indent_level=1)

        code = node.to_pandas_code(ctx)
        assert "pd.read_csv" in code
        assert "data/test.csv" in code

    def test_clean_node_rename(self):
        """Test CleanNode rename action."""
        from tfl_decompiler.nodes.clean_node import CleanNode
        from tfl_decompiler.nodes.base import NodeContext

        node_data = {
            "type": "clean",
            "actions": [
                {"type": "rename", "columnName": "old", "newName": "new"}
            ]
        }
        node = CleanNode(node_data, "test_clean")
        ctx = NodeContext(
            variable_name="df_clean",
            step_number=1,
            input_variables=["df_input"],
            indent_level=1
        )

        code = node.to_pandas_code(ctx)
        assert ".rename(" in code
        assert "'old'" in code
        assert "'new'" in code

    def test_aggregate_node(self):
        """Test AggregateNode."""
        from tfl_decompiler.nodes.aggregate_node import AggregateNode
        from tfl_decompiler.nodes.base import NodeContext

        node_data = {
            "type": "aggregate",
            "groupByColumns": ["category"],
            "aggregations": [
                {"field": "amount", "function": "sum"}
            ]
        }
        node = AggregateNode(node_data, "test_agg")
        ctx = NodeContext(
            variable_name="df_agg",
            step_number=1,
            input_variables=["df_input"],
            indent_level=1
        )

        code = node.to_pandas_code(ctx)
        assert ".groupby(" in code
        assert ".agg(" in code
        assert "'sum'" in code

    def test_join_node(self):
        """Test JoinNode."""
        from tfl_decompiler.nodes.join_node import JoinNode
        from tfl_decompiler.nodes.base import NodeContext

        node_data = {
            "type": "join",
            "joinType": "inner",
            "joinClauses": [
                {"leftColumn": "id", "rightColumn": "customer_id"}
            ]
        }
        node = JoinNode(node_data, "test_join")
        ctx = NodeContext(
            variable_name="df_joined",
            step_number=1,
            input_variables=["df_left", "df_right"],
            indent_level=1
        )

        code = node.to_pandas_code(ctx)
        assert "pd.merge(" in code
        assert "how='inner'" in code


class TestUtils:
    """Tests for utility functions."""

    def test_sanitize_variable_name(self):
        """Test variable name sanitization."""
        from tfl_decompiler.utils import sanitize_variable_name

        assert sanitize_variable_name("Sales Data") == "sales_data"
        assert sanitize_variable_name("123_test") == "df_123_test"
        assert sanitize_variable_name("valid_name") == "valid_name"
        assert sanitize_variable_name("Name With Spaces!") == "name_with_spaces"


class TestIntegration:
    """Integration tests."""

    def test_full_decompile_pipeline(self):
        """Test complete decompilation pipeline."""
        from tfl_decompiler import decompile

        tfl_path = create_test_tfl(SAMPLE_FLOW)
        code = decompile(str(tfl_path))

        # Verify code is syntactically valid Python
        compile(code, "<string>", "exec")

        # Check for expected components
        assert "def main(" in code
        assert "import pandas" in code


CASES_DIR = Path(__file__).parent


def _iter_cases():
    """Yield (num, name, tfl_path, py_path, unzip_dir) for every case_XX folder."""
    for case_dir in sorted(CASES_DIR.glob("case_*")):
        if not case_dir.is_dir():
            continue
        tfls = sorted(case_dir.glob("*.tfl"))
        pys = sorted(case_dir.glob("*.py"))
        if not tfls or not pys:
            continue
        tfl = tfls[0]
        py = pys[0]
        stem = tfl.stem
        unzip_dir = case_dir / stem
        yield case_dir.name, tfl, py, unzip_dir


class TestCaseFolders:
    """Validate each tests/case_XX/ folder: .tfl, .py reference, and unzipped contents."""

    def test_all_cases_have_required_files(self):
        """Every case_XX folder must contain a .tfl, a .py, and an unzipped subdirectory."""
        cases = list(_iter_cases())
        assert len(cases) > 0, "No case_XX folders found"
        for case_name, tfl, py, unzip_dir in cases:
            assert tfl.exists(), f"{case_name}: missing .tfl file"
            assert py.exists(), f"{case_name}: missing .py reference file"
            assert unzip_dir.is_dir(), f"{case_name}: missing unzipped folder {unzip_dir.name}"
            assert (unzip_dir / "flow").exists(), f"{case_name}: unzipped folder missing 'flow' entry"

    def test_unzipped_folder_matches_tfl(self):
        """The unzipped folder contents must match what is inside the .tfl archive."""
        for case_name, tfl, py, unzip_dir in _iter_cases():
            with zipfile.ZipFile(tfl, 'r') as zf:
                archive_names = set(zf.namelist())
            disk_names = {p.name for p in unzip_dir.iterdir()}
            missing = archive_names - disk_names
            assert not missing, f"{case_name}: unzipped folder missing entries: {missing}"

    def test_reference_py_is_valid_python(self):
        """Every reference .py file must be syntactically valid Python."""
        for case_name, tfl, py, unzip_dir in _iter_cases():
            source = py.read_text()
            try:
                compile(source, str(py), "exec")
            except SyntaxError as e:
                pytest.fail(f"{case_name}: reference .py has syntax error: {e}")

    def test_decompiler_produces_valid_python_for_each_case(self):
        """Running the decompiler on each .tfl must produce valid Python."""
        from tfl_decompiler import decompile
        for case_name, tfl, py, unzip_dir in _iter_cases():
            code = decompile(str(tfl))
            try:
                compile(code, "<string>", "exec")
            except SyntaxError as e:
                pytest.fail(f"{case_name}: decompiler output has syntax error: {e}")

    def test_decompiler_output_matches_reference(self):
        """Decompiler output must match the committed reference .py (ignoring timestamp line)."""
        from tfl_decompiler import decompile
        for case_name, tfl, py, unzip_dir in _iter_cases():
            code = decompile(str(tfl))
            reference = py.read_text()

            def strip_volatile(s: str) -> str:
                lines = s.splitlines()
                return "\n".join(
                    l for l in lines
                    if not l.startswith("Generated at:")
                    and not l.startswith("Auto-generated from:")
                ).rstrip()

            assert strip_volatile(code) == strip_volatile(reference), (
                f"{case_name}: decompiler output differs from {py.name}"
            )

    def test_real_tableau_flow_has_input_parameters(self):
        """Case 16 (real Tableau Prep tutorial) must produce a main() with input parameters."""
        from tfl_decompiler import decompile
        case16_tfl = CASES_DIR / "case_16" / "16_tableau_prep_tutorial.tfl"
        if not case16_tfl.exists():
            pytest.skip("case_16 not present")
        code = decompile(str(case16_tfl))
        assert "input_orders_central" in code, "Missing Orders_Central parameter"
        assert "input_orders_west" in code, "Missing Orders_West parameter"
        assert "output_output" in code, "Missing output parameter"
        assert "pd.read_csv(input_orders_central)" in code

    def test_connectionattributes_filename_extracted(self):
        """InputNode must read paths from connectionAttributes.filename."""
        from tfl_decompiler.nodes.input_node import InputNode
        node_data = {
            "nodeType": ".v1.LoadCsv",
            "name": "Sales",
            "connectionAttributes": {"filename": "/data/sales.csv"},
        }
        node = InputNode(node_data, "n1")
        assert node.file_path == "/data/sales.csv"
        assert node.connection_type == "csv"

    def test_writetohyper_detected_as_csv(self):
        """OutputNode for WriteToHyper must fall back to CSV output type."""
        from tfl_decompiler.nodes.output_node import OutputNode
        node_data = {
            "nodeType": ".v1.WriteToHyper",
            "name": "Out",
            "hyperOutputFile": "/tmp/result.hyper",
        }
        node = OutputNode(node_data, "n2")
        assert node.output_type == "csv"
        assert node.output_path == "/tmp/result.hyper"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
