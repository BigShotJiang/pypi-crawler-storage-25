#!/usr/bin/env python3
"""
Generate sample .tfl files for testing the decompiler.
"""

import sys
from pathlib import Path

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from tfl_decompiler.builder import FlowBuilder


def generate_all_flows():
    """Generate all sample .tfl files."""
    output_dir = Path(__file__).parent / "generated_flows"
    output_dir.mkdir(exist_ok=True)

    flows = [
        ("01_simple_csv_etl.tfl", generate_simple_csv_etl),
        ("02_excel_processing.tfl", generate_excel_processing),
        ("03_multi_input_union.tfl", generate_multi_input_union),
        ("04_inner_join.tfl", generate_inner_join),
        ("05_left_right_joins.tfl", generate_left_right_joins),
        ("06_full_outer_join.tfl", generate_full_outer_join),
        ("07_aggregation_pipeline.tfl", generate_aggregation_pipeline),
        ("08_pivot_columns_to_rows.tfl", generate_pivot_columns_to_rows),
        ("09_filter_and_clean.tfl", generate_filter_and_clean),
        ("10_calculated_fields.tfl", generate_calculated_fields),
        ("11_remap_values.tfl", generate_remap_values),
        ("12_multi_step_transform.tfl", generate_multi_step_transform),
        ("13_diamond_pattern.tfl", generate_diamond_pattern),
        ("14_sales_analytics.tfl", generate_sales_analytics),
        ("15_customer_360.tfl", generate_customer_360),
    ]

    for filename, generator in flows:
        filepath = output_dir / filename
        generator(filepath)
        print(f"Generated: {filepath}")

    print(f"\nGenerated {len(flows)} .tfl files in {output_dir}")


def generate_simple_csv_etl(output_path: Path):
    """Simple CSV input -> clean -> output flow."""
    builder = FlowBuilder()

    input_id = builder.add_input_csv("data/raw_data.csv", "Raw Data")
    clean_id = builder.add_clean_step("Clean Data", input_id, actions=[
        {"type": "rename", "columnName": "old_col", "newName": "new_col"}
    ])
    builder.add_output_csv("output/cleaned_data.csv", "Cleaned Output", clean_id)

    builder.save(str(output_path))


def generate_excel_processing(output_path: Path):
    """Excel input with sheet selection."""
    builder = FlowBuilder()

    input_id = builder.add_input_excel("data/workbook.xlsx", "Sheet1 Data", sheet="Sheet1")
    clean_id = builder.add_clean_step("Transform", input_id, actions=[
        {"type": "remove", "columnName": "temp_column"},
        {"type": "rename", "columnName": "ID", "newName": "record_id"}
    ])
    builder.add_output_csv("output/excel_export.csv", "CSV Export", clean_id)

    builder.save(str(output_path))


def generate_multi_input_union(output_path: Path):
    """Union of 4 CSV files."""
    builder = FlowBuilder()

    input1 = builder.add_input_csv("data/q1_sales.csv", "Q1 Sales")
    input2 = builder.add_input_csv("data/q2_sales.csv", "Q2 Sales")
    input3 = builder.add_input_csv("data/q3_sales.csv", "Q3 Sales")
    input4 = builder.add_input_csv("data/q4_sales.csv", "Q4 Sales")

    union_id = builder.add_union("All Quarters", [input1, input2, input3, input4])
    builder.add_output_csv("output/yearly_sales.csv", "Yearly Sales", union_id)

    builder.save(str(output_path))


def generate_inner_join(output_path: Path):
    """Simple inner join between two tables."""
    builder = FlowBuilder()

    orders = builder.add_input_csv("data/orders.csv", "Orders")
    customers = builder.add_input_csv("data/customers.csv", "Customers")

    joined = builder.add_join(
        "Join Orders-Customers",
        orders, customers,
        join_type="inner",
        left_key="customer_id",
        right_key="id"
    )
    builder.add_output_csv("output/orders_with_customers.csv", "Orders Detail", joined)

    builder.save(str(output_path))


def generate_left_right_joins(output_path: Path):
    """Left join followed by right join."""
    builder = FlowBuilder()

    main = builder.add_input_csv("data/main_table.csv", "Main Table")
    lookup1 = builder.add_input_csv("data/lookup1.csv", "Lookup 1")
    lookup2 = builder.add_input_csv("data/lookup2.csv", "Lookup 2")

    left_joined = builder.add_join(
        "Left Join Lookup1",
        main, lookup1,
        join_type="left",
        left_key="code",
        right_key="code"
    )

    right_joined = builder.add_join(
        "Right Join Lookup2",
        left_joined, lookup2,
        join_type="right",
        left_key="category",
        right_key="cat_id"
    )

    builder.add_output_csv("output/enriched_data.csv", "Enriched Data", right_joined)

    builder.save(str(output_path))


def generate_full_outer_join(output_path: Path):
    """Full outer join to find mismatches."""
    builder = FlowBuilder()

    system_a = builder.add_input_csv("data/system_a_records.csv", "System A Records")
    system_b = builder.add_input_csv("data/system_b_records.csv", "System B Records")

    outer_joined = builder.add_join(
        "Full Outer Join",
        system_a, system_b,
        join_type="outer",
        left_key="record_id",
        right_key="record_id"
    )

    builder.add_output_csv("output/reconciliation.csv", "Reconciliation Report", outer_joined)

    builder.save(str(output_path))


def generate_aggregation_pipeline(output_path: Path):
    """Aggregation with multiple measures."""
    builder = FlowBuilder()

    transactions = builder.add_input_csv("data/transactions.csv", "Transactions")

    agg_id = builder.add_aggregate(
        "Aggregate by Region",
        transactions,
        group_by=["region", "product_category"],
        aggregations=[
            {"field": "amount", "function": "sum", "outputName": "total_amount"},
            {"field": "amount", "function": "avg", "outputName": "avg_amount"},
            {"field": "quantity", "function": "sum", "outputName": "total_qty"},
            {"field": "transaction_id", "function": "count", "outputName": "num_transactions"}
        ]
    )

    builder.add_output_csv("output/regional_summary.csv", "Regional Summary", agg_id)

    builder.save(str(output_path))


def generate_pivot_columns_to_rows(output_path: Path):
    """Pivot wide format to long format."""
    builder = FlowBuilder()

    wide_data = builder.add_input_csv("data/monthly_metrics.csv", "Monthly Metrics")

    pivot_id = builder.add_pivot(
        "Unpivot Months",
        wide_data,
        pivot_columns=["jan", "feb", "mar", "apr", "may", "jun",
                       "jul", "aug", "sep", "oct", "nov", "dec"],
        var_name="month",
        value_name="metric_value"
    )

    builder.add_output_csv("output/long_format.csv", "Long Format Data", pivot_id)

    builder.save(str(output_path))


def generate_filter_and_clean(output_path: Path):
    """Filter rows and clean data."""
    builder = FlowBuilder()

    raw = builder.add_input_csv("data/raw_logs.csv", "Raw Logs")

    # Filter for errors only
    filtered = builder.add_filter(
        "Filter Errors",
        raw,
        field="log_level",
        operator="equals",
        value="ERROR"
    )

    # Clean the filtered data
    cleaned = builder.add_clean_step("Clean Logs", filtered, actions=[
        {"type": "remove", "columnName": "debug_info"},
        {"type": "rename", "columnName": "msg", "newName": "error_message"},
        {"type": "changeType", "columnName": "timestamp", "newType": "datetime"}
    ])

    builder.add_output_csv("output/error_logs.csv", "Error Logs", cleaned)

    builder.save(str(output_path))


def generate_calculated_fields(output_path: Path):
    """Multiple calculated fields."""
    builder = FlowBuilder()

    sales = builder.add_input_csv("data/sales_data.csv", "Sales Data")

    # Add profit calculation
    calc1 = builder.add_calculated_field(
        "Calculate Profit",
        sales,
        "profit",
        "[revenue] - [cost]"
    )

    # Add margin percentage
    calc2 = builder.add_calculated_field(
        "Calculate Margin",
        calc1,
        "margin_pct",
        "([revenue] - [cost]) / [revenue] * 100"
    )

    # Add category flag
    calc3 = builder.add_calculated_field(
        "High Value Flag",
        calc2,
        "is_high_value",
        "IF [revenue] > 1000 THEN 'Yes' ELSE 'No' END"
    )

    builder.add_output_csv("output/sales_with_metrics.csv", "Sales Metrics", calc3)

    builder.save(str(output_path))


def generate_remap_values(output_path: Path):
    """Remap/replace values in columns."""
    builder = FlowBuilder()

    survey = builder.add_input_csv("data/survey_responses.csv", "Survey Responses")

    # Remap satisfaction values
    remap1 = builder.add_remap(
        "Standardize Satisfaction",
        survey,
        column_name="satisfaction",
        values={
            "Very Satisfied": ["Very Satisfied", "Excellent", "5"],
            "Satisfied": ["Satisfied", "Good", "4"],
            "Neutral": ["Neutral", "OK", "3"],
            "Dissatisfied": ["Dissatisfied", "Poor", "2"],
            "Very Dissatisfied": ["Very Dissatisfied", "Terrible", "1"]
        }
    )

    # Remap region codes
    remap2 = builder.add_remap(
        "Expand Region Codes",
        remap1,
        column_name="region",
        values={
            "North America": ["NA", "N.A.", "North America"],
            "Europe": ["EU", "EMEA", "Europe"],
            "Asia Pacific": ["APAC", "AP", "Asia Pacific"]
        }
    )

    builder.add_output_csv("output/standardized_survey.csv", "Standardized Survey", remap2)

    builder.save(str(output_path))


def generate_multi_step_transform(output_path: Path):
    """Multiple transformation steps in sequence."""
    builder = FlowBuilder()

    raw = builder.add_input_csv("data/employee_data.csv", "Employee Data")

    # Step 1: Rename fields
    step1 = builder.add_rename("Rename Fields", raw, {
        "emp_id": "employee_id",
        "fname": "first_name",
        "lname": "last_name",
        "dept": "department"
    })

    # Step 2: Filter active employees
    step2 = builder.add_filter(
        "Filter Active",
        step1,
        field="status",
        operator="equals",
        value="active"
    )

    # Step 3: Add calculated field
    step3 = builder.add_calculated_field(
        "Full Name",
        step2,
        "full_name",
        "[first_name] + ' ' + [last_name]"
    )

    # Step 4: Clean up
    step4 = builder.add_clean_step("Final Cleanup", step3, actions=[
        {"type": "remove", "columnName": "first_name"},
        {"type": "remove", "columnName": "last_name"},
        {"type": "remove", "columnName": "status"}
    ])

    builder.add_output_csv("output/employee_directory.csv", "Employee Directory", step4)

    builder.save(str(output_path))


def generate_diamond_pattern(output_path: Path):
    """Diamond pattern: split then rejoin."""
    builder = FlowBuilder()

    # Single source
    source = builder.add_input_csv("data/transactions.csv", "All Transactions")

    # Split into two branches
    high_value = builder.add_filter(
        "High Value Transactions",
        source,
        field="amount",
        operator="greaterThan",
        value=1000
    )

    low_value = builder.add_filter(
        "Low Value Transactions",
        source,
        field="amount",
        operator="lessThan",
        value=1000
    )

    # Process each branch differently
    high_agg = builder.add_aggregate(
        "Aggregate High Value",
        high_value,
        group_by=["customer_id"],
        aggregations=[
            {"field": "amount", "function": "sum", "outputName": "high_value_total"}
        ]
    )

    low_agg = builder.add_aggregate(
        "Aggregate Low Value",
        low_value,
        group_by=["customer_id"],
        aggregations=[
            {"field": "amount", "function": "sum", "outputName": "low_value_total"}
        ]
    )

    # Rejoin
    combined = builder.add_join(
        "Combine Summaries",
        high_agg, low_agg,
        join_type="outer",
        left_key="customer_id",
        right_key="customer_id"
    )

    builder.add_output_csv("output/customer_segments.csv", "Customer Segments", combined)

    builder.save(str(output_path))


def generate_sales_analytics(output_path: Path):
    """Complete sales analytics pipeline."""
    builder = FlowBuilder()

    # Input sources
    orders = builder.add_input_csv("data/orders.csv", "Orders")
    products = builder.add_input_csv("data/products.csv", "Products")
    customers = builder.add_input_csv("data/customers.csv", "Customers")
    returns = builder.add_input_csv("data/returns.csv", "Returns")

    # Join orders with products
    orders_products = builder.add_join(
        "Add Product Info",
        orders, products,
        join_type="left",
        left_key="product_id",
        right_key="id"
    )

    # Join with customers
    orders_full = builder.add_join(
        "Add Customer Info",
        orders_products, customers,
        join_type="left",
        left_key="customer_id",
        right_key="id"
    )

    # Left join returns
    with_returns = builder.add_join(
        "Add Returns",
        orders_full, returns,
        join_type="left",
        left_key="order_id",
        right_key="order_id"
    )

    # Calculate metrics
    with_metrics = builder.add_calculated_field(
        "Calculate Net Revenue",
        with_returns,
        "net_revenue",
        "[amount] - IFNULL([return_amount], 0)"
    )

    # Aggregate by region and category
    summary = builder.add_aggregate(
        "Regional Category Summary",
        with_metrics,
        group_by=["region", "category"],
        aggregations=[
            {"field": "net_revenue", "function": "sum", "outputName": "total_revenue"},
            {"field": "order_id", "function": "count", "outputName": "order_count"},
            {"field": "return_amount", "function": "sum", "outputName": "total_returns"}
        ]
    )

    builder.add_output_csv("output/sales_analytics.csv", "Sales Analytics", summary)

    builder.save(str(output_path))


def generate_customer_360(output_path: Path):
    """Customer 360 view - combining multiple data sources."""
    builder = FlowBuilder()

    # Core customer data
    customers = builder.add_input_csv("data/customers.csv", "Core Customer Data")

    # Transaction history
    transactions = builder.add_input_csv("data/transactions.csv", "Transactions")

    # Support tickets
    tickets = builder.add_input_csv("data/support_tickets.csv", "Support Tickets")

    # Web activity
    web_activity = builder.add_input_csv("data/web_activity.csv", "Web Activity")

    # Aggregate transactions per customer
    txn_summary = builder.add_aggregate(
        "Transaction Summary",
        transactions,
        group_by=["customer_id"],
        aggregations=[
            {"field": "amount", "function": "sum", "outputName": "total_spend"},
            {"field": "amount", "function": "avg", "outputName": "avg_transaction"},
            {"field": "transaction_id", "function": "count", "outputName": "transaction_count"}
        ]
    )

    # Aggregate support tickets
    ticket_summary = builder.add_aggregate(
        "Ticket Summary",
        tickets,
        group_by=["customer_id"],
        aggregations=[
            {"field": "ticket_id", "function": "count", "outputName": "ticket_count"},
            {"field": "resolution_time", "function": "avg", "outputName": "avg_resolution_time"}
        ]
    )

    # Aggregate web activity
    web_summary = builder.add_aggregate(
        "Web Activity Summary",
        web_activity,
        group_by=["customer_id"],
        aggregations=[
            {"field": "page_views", "function": "sum", "outputName": "total_page_views"},
            {"field": "session_id", "function": "countd", "outputName": "unique_sessions"}
        ]
    )

    # Join all summaries to customer
    with_txn = builder.add_join(
        "Add Transactions",
        customers, txn_summary,
        join_type="left",
        left_key="id",
        right_key="customer_id"
    )

    with_tickets = builder.add_join(
        "Add Tickets",
        with_txn, ticket_summary,
        join_type="left",
        left_key="id",
        right_key="customer_id"
    )

    customer_360 = builder.add_join(
        "Add Web Activity",
        with_tickets, web_summary,
        join_type="left",
        left_key="id",
        right_key="customer_id"
    )

    # Add customer segment calculation
    with_segment = builder.add_calculated_field(
        "Calculate Segment",
        customer_360,
        "customer_segment",
        "IF [total_spend] > 10000 THEN 'Premium' ELSEIF [total_spend] > 1000 THEN 'Standard' ELSE 'Basic' END"
    )

    builder.add_output_csv("output/customer_360.csv", "Customer 360 View", with_segment)

    builder.save(str(output_path))


if __name__ == "__main__":
    generate_all_flows()
