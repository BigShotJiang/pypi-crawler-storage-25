"""
Diagnostic: comparer modeles d'enthalpie liquide a T[0]=261K, P=27.49 bar

HYPOTHESES A TESTER:
  A) Watson actuel : h = H_ig(x) - sum(x_i * dHvap_DIPPR_i)         [no H_dep liquid]
  B) Full PR       : h = H_ig(x) + H_dep_PR(x, liquid)               [PR both phases]
  C) PR - Watson   : h = H_ig(x) - sum(x_i * dHvap_DIPPR_i)          [current]
                      => correctif: ajouter H_dep_PR_liq - sum(x_i*H_dep_PR_pure_i_liq)

  Delphi reference (Case 1): H[0]-h[0] implique = 11752.37 kJ/kmol
  Python Watson (Case 1):    H[0]-h[0]           = 11310.64 kJ/kmol
  Ecart a expliquer:                              =   +441.73 kJ/kmol
"""

import sys, os
import numpy as np

_src = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
if _src not in sys.path:
    sys.path.insert(0, _src)

from Distillation.Deethanizer import Deethanizer

# =============================================================================
# Donnees reference Case 1
# =============================================================================
QC_REF = 4_133_587.91  # kJ/h
QR_REF = 22_854_385.49
D_REF  = 562.1          # kmol/h
V1_REF = 868.3
L0_REF = 306.2
DELTA_HVAP_IMPL = 11_752.37  # kJ/kmol => cible Delphi pour H[0]-h[0]

# =============================================================================
# Convergence Python Case 1
# =============================================================================
print("=" * 70)
print("Convergence Python Case 1 ...")
print("=" * 70)
col = Deethanizer()
col.solve(case=1)

eos = col.eos
N   = col.N
P_Pa = col.P      # Pa
P_bar = P_Pa / 1e5

T0   = col.T[0]   # K
T1   = col.T[1]

# Compositions normalises
def xnorm(j): z = col.l[:, j]; return z / z.sum()
def ynorm(j): z = col.v[:, j]; return z / z.sum()

x0 = xnorm(0); y0 = ynorm(0)
x1 = xnorm(1); y1 = ynorm(1)

L0 = col.l[:, 0].sum()
V1 = col.v[:, 1].sum()

print(f"  T[0] = {T0:.3f} K  ({T0-273.15:.2f} C)")
print(f"  T[1] = {T1:.3f} K  ({T1-273.15:.2f} C)")
print(f"  P    = {P_bar:.3f} bar")
print(f"  L[0] = {L0:.2f} kmol/h  |  V[1] = {V1:.2f} kmol/h")

# =============================================================================
# PARTIE 1 — Decomposition complete H_dep pour les 3 modeles
# =============================================================================
print("\n" + "=" * 70)
print("PARTIE 1 — H_dep_PR (vapeur vs liquide) a T[0]")
print("=" * 70)

H_ig_y0 = eos.ideal_gas_enthalpy(T0, y0)
H_ig_x0 = eos.ideal_gas_enthalpy(T0, x0)
H_dep_vap = eos.enthalpy_departure(T0, P_Pa, y0, 'vapor')
H_dep_liq = eos.enthalpy_departure(T0, P_Pa, x0, 'liquid')

H0_pr  = eos.mixture_enthalpy(T0, P_Pa, y0, 'vapor')   # H[0] (identique pour tous les modeles)
h0_A   = eos.pure_component_enthalpy(T0, P_Pa, x0, 'liquid')  # Modele A (Watson, actuel)
h0_B   = eos.mixture_enthalpy(T0, P_Pa, x0, 'liquid')          # Modele B (Full PR liquide)

dHvap_Watson = H_ig_x0 - h0_A   # = sum(x_i * dHvap_DIPPR_i)

print(f"\n  H_ig(y[0])                = {H_ig_y0:>12.3f} kJ/kmol")
print(f"  H_ig(x[0])                = {H_ig_x0:>12.3f} kJ/kmol")
print(f"  H_ig(y) - H_ig(x)         = {H_ig_y0-H_ig_x0:>+12.3f} kJ/kmol  [composition y vs x]")
print(f"\n  H_dep_PR(y[0], vapeur)    = {H_dep_vap:>+12.3f} kJ/kmol")
print(f"  H_dep_PR(x[0], liquide)   = {H_dep_liq:>+12.3f} kJ/kmol")
print(f"  H_dep_liq - H_dep_vap     = {H_dep_liq - H_dep_vap:>+12.3f} kJ/kmol")
print(f"\n  sum(x_i*dHvap_DIPPR_i) [Watson] = {dHvap_Watson:>+12.3f} kJ/kmol")
print(f"  H_dep_PR(liquide)               = {H_dep_liq:>+12.3f} kJ/kmol")
print(f"  Rapport |H_dep_liq| / Watson    = {abs(H_dep_liq)/dHvap_Watson:>+12.4f}")

print(f"\n  H[0] (vapeur, PR)         = {H0_pr:>12.3f} kJ/kmol  [identique pour tous modeles]")
print(f"\n  h[0] Modele A (Watson)    = {h0_A:>12.3f} kJ/kmol")
print(f"  h[0] Modele B (Full PR)   = {h0_B:>12.3f} kJ/kmol")
print(f"  Difference B-A            = {h0_B-h0_A:>+12.3f} kJ/kmol  [H_dep_liq + Watson]")

H0_h0_A = H0_pr - h0_A
H0_h0_B = H0_pr - h0_B

print(f"\n  H[0]-h[0] Modele A (Watson)  = {H0_h0_A:>12.3f} kJ/kmol")
print(f"  H[0]-h[0] Modele B (Full PR) = {H0_h0_B:>12.3f} kJ/kmol")
print(f"  H[0]-h[0] Delphi IMPLIQUE    = {DELTA_HVAP_IMPL:>12.3f} kJ/kmol")
print(f"\n  Ecart A vs Delphi   = {H0_h0_A - DELTA_HVAP_IMPL:>+10.3f} kJ/kmol  ({(H0_h0_A/DELTA_HVAP_IMPL-1)*100:>+.2f}%)")
print(f"  Ecart B vs Delphi   = {H0_h0_B - DELTA_HVAP_IMPL:>+10.3f} kJ/kmol  ({(H0_h0_B/DELTA_HVAP_IMPL-1)*100:>+.2f}%)")

# =============================================================================
# PARTIE 2 — Calcul QC pour chaque modele
# =============================================================================
print("\n" + "=" * 70)
print("PARTIE 2 — QC implique par chaque modele de h[0]")
print("=" * 70)

H1_pr = eos.mixture_enthalpy(T1, P_Pa, y1, 'vapor')
H_dep_vap1 = eos.enthalpy_departure(T1, P_Pa, y1, 'vapor')

def compute_QC(H0, h0, H1, V1, L0, D):
    """QC = V1*(H1-H0) + L0*(H0-h0)  [condenseur partiel]"""
    A = V1 * (H1 - H0)
    B = L0 * (H0 - h0)
    return A + B, A, B

QC_A, A_A, B_A = compute_QC(H0_pr, h0_A, H1_pr, V1, L0, D_REF)
QC_B, A_B, B_B = compute_QC(H0_pr, h0_B, H1_pr, V1, L0, D_REF)

print(f"\n  Modele A (Watson actuel):")
print(f"    Terme A = V1*(H1-H0) = {A_A:>13,.1f} kJ/h  ({A_A/QC_A*100:.1f}%)")
print(f"    Terme B = L0*(H0-h0) = {B_A:>13,.1f} kJ/h  ({B_A/QC_A*100:.1f}%)")
print(f"    QC_A                 = {QC_A:>13,.1f} kJ/h  [err={( QC_A/QC_REF-1)*100:>+.2f}%]")

print(f"\n  Modele B (Full PR liquide):")
print(f"    Terme A = V1*(H1-H0) = {A_B:>13,.1f} kJ/h  ({A_B/QC_B*100:.1f}%)")
print(f"    Terme B = L0*(H0-h0) = {B_B:>13,.1f} kJ/h  ({B_B/QC_B*100:.1f}%)")
print(f"    QC_B                 = {QC_B:>13,.1f} kJ/h  [err={( QC_B/QC_REF-1)*100:>+.2f}%]")

print(f"\n  Delphi reference:        QC_ref = {QC_REF:>13,.1f} kJ/h")

# =============================================================================
# PARTIE 3 — Analyse composant par composant du H_dep PR liquide
# =============================================================================
print("\n" + "=" * 70)
print("PARTIE 3 — Decomposition H_dep_PR liquide par composant a T[0]")
print("=" * 70)
print(f"  T[0] = {T0:.2f} K  |  P = {P_bar:.2f} bar")
print(f"\n  {'Comp':>5}  {'x[0]':>7}  {'dHvap_DIPPR':>12}  {'H_dep_PR_liq':>14}  {'H_dep_PR_vap':>14}  {'Delta(liq-vap)':>15}")
print(f"  {'-'*75}")

nc = eos.nc
names = eos.names
total_dippr = 0.0; total_dep_liq = 0.0; total_dep_vap = 0.0

for i in range(nc):
    if x0[i] < 1e-4:
        continue
    T = T0; Tc_i = eos.Tc[i]

    # Pure DIPPR dHvap at T0
    if T < Tc_i:
        try:
            dHvap_i = eos._Hvap[i].T_dependent_property(T)
            if dHvap_i is None:
                dHvap_i = float('nan')
        except Exception:
            dHvap_i = float('nan')
    else:
        dHvap_i = 0.0  # supercritique

    # H_dep_PR pure component (liquide et vapeur)
    x_pure = np.zeros(nc); x_pure[i] = 1.0
    try:
        h_dep_l = eos.enthalpy_departure(T, P_Pa, x_pure, 'liquid')
        h_dep_v = eos.enthalpy_departure(T, P_Pa, x_pure, 'vapor')
    except Exception:
        h_dep_l = h_dep_v = float('nan')

    c_dippr   = x0[i] * (dHvap_i if not np.isnan(dHvap_i) else 0.0)
    c_dep_liq = x0[i] * h_dep_l
    c_dep_vap = x0[i] * h_dep_v
    total_dippr   += c_dippr
    total_dep_liq += c_dep_liq
    total_dep_vap += c_dep_vap

    print(f"  {names[i]:>5}  {x0[i]:>7.4f}  {dHvap_i if not np.isnan(dHvap_i) else 0:>12.2f}  "
          f"{h_dep_l:>14.2f}  {h_dep_v:>14.2f}  {h_dep_l-h_dep_v:>15.2f}  kJ/kmol (xi-weighted: x={x0[i]:.4f})")

print(f"\n  Contributions ponderees x[0]*valeur_pure:")
print(f"    sum(x*dHvap_DIPPR_pure)     = {total_dippr:>12.3f} kJ/kmol")
print(f"    sum(x*H_dep_PR_pure_liq)    = {total_dep_liq:>12.3f} kJ/kmol")
print(f"    sum(x*H_dep_PR_pure_vap)    = {total_dep_vap:>12.3f} kJ/kmol")
print(f"\n  Comparaison avec valeurs de melanges:")
print(f"    H_dep_PR melange  (liquide)  = {H_dep_liq:>12.3f} kJ/kmol  [via eos.enthalpy_departure(x,'liquid')]")
print(f"    H_dep_PR melange  (vapeur)   = {H_dep_vap:>12.3f} kJ/kmol  [via eos.enthalpy_departure(y,'vapor')]")
print(f"    sum(x_i*Watson_DIPPR_i)      = {dHvap_Watson:>12.3f} kJ/kmol  [= H_ig(x) - h0_Watson]")

# =============================================================================
# PARTIE 4 — Verifier DIPPR a plusieurs T vs Watson (T_normal_boiling)
# =============================================================================
print("\n" + "=" * 70)
print("PARTIE 4 — dHvap DIPPR detail C2 et C3 en fonction de T")
print("=" * 70)

c2_idx = names.index('C2') if 'C2' in names else None
c3_idx = names.index('C3') if 'C3' in names else None

for comp_name, idx in [('C2', c2_idx), ('C3', c3_idx)]:
    if idx is None:
        continue
    Tc_i = eos.Tc[idx]
    Pc_i = eos.Pc[idx]
    omega_i = eos.omega[idx]
    hvap_obj = eos._Hvap[idx]

    print(f"\n  {comp_name}: Tc={Tc_i:.2f} K  Pc={Pc_i/1e5:.2f} bar  omega={omega_i:.4f}")
    print(f"  {'T(K)':>8}  {'Tr':>7}  {'dHvap_DIPPR':>14}  {'H_dep_PR_vap':>14}  "
          f"{'H_dep_liq_mix note':>18}")
    print(f"  {'-'*70}")
    x_pure = np.zeros(nc); x_pure[idx] = 1.0
    for T_test in [200., 220., 240., 255., 261., 270., 280., 290., 300.]:
        if T_test >= Tc_i:
            print(f"  {T_test:>8.1f}  {T_test/Tc_i:>7.4f}  {'(supercritique)':>14}  ---")
            continue
        try:
            dh = hvap_obj.T_dependent_property(T_test)
            dhv = eos.enthalpy_departure(T_test, P_Pa, x_pure, 'vapor')
            dhl = eos.enthalpy_departure(T_test, P_Pa, x_pure, 'liquid')
        except Exception as e:
            print(f"  {T_test:>8.1f}  ERREUR: {e}")
            continue
        # Watson approximation from Tb
        print(f"  {T_test:>8.1f}  {T_test/Tc_i:>7.4f}  {dh if dh else 0:>14.2f}  {dhv:>14.2f}  "
              f"{dhl:>14.2f}  kJ/kmol")

# =============================================================================
# PARTIE 5 — Modele C: Watson mais avec correction H_dep PR liquide AUSSI
# =============================================================================
print("\n" + "=" * 70)
print("PARTIE 5 — Modele C: h = H_ig(x) - Watson + H_dep_PR(x,liq) [hybride]")
print("=" * 70)
print("  (Ce serait le cas si Delphi utilise Watson pour ΔHvap ET H_dep_PR liquide)")
print()

# Modele C: h = H_ig - Watson + H_dep_liq
# => H[0]-h[0] = (H_ig_y + H_dep_vap) - (H_ig_x - Watson + H_dep_liq)
#              = (H_ig_y - H_ig_x) + H_dep_vap - H_dep_liq + Watson
h0_C = H_ig_x0 - dHvap_Watson + H_dep_liq   # H_ig(x) - Watson + H_dep_PR(x,liq)
H0_h0_C = H0_pr - h0_C
QC_C, A_C, B_C = compute_QC(H0_pr, h0_C, H1_pr, V1, L0, D_REF)

print(f"  h[0] Modele C (Watson + H_dep_liq) = {h0_C:>12.3f} kJ/kmol")
print(f"  H[0]-h[0] Modele C                 = {H0_h0_C:>12.3f} kJ/kmol  [cible: {DELTA_HVAP_IMPL:.3f}]")
print(f"  Ecart C vs Delphi   = {H0_h0_C - DELTA_HVAP_IMPL:>+10.3f} kJ/kmol  ({(H0_h0_C/DELTA_HVAP_IMPL-1)*100:>+.2f}%)")
print(f"  QC_C = {QC_C:>13,.1f} kJ/h  [err={( QC_C/QC_REF-1)*100:>+.2f}%]")

# =============================================================================
# PARTIE 6 — Reverse engineer: quelle valeur de H_dep_liq ferme le bilan ?
# =============================================================================
print("\n" + "=" * 70)
print("PARTIE 6 — Reverse engineering: H_dep_liq requis pour matcher Delphi")
print("=" * 70)

# H[0]-h[0]_target = H_ig_y + H_dep_vap - H_ig_x - H_dep_liq_target
# => H_dep_liq_target = H_ig_y - H_ig_x + H_dep_vap - DELTA_HVAP_IMPL
H_dep_liq_needed = (H_ig_y0 - H_ig_x0) + H_dep_vap - DELTA_HVAP_IMPL
# Also: if Watson is kept and only H_dep_liq is added:
# H[0]-h[0]_target = (H_ig_y-H_ig_x) + H_dep_vap - (-Watson + H_dep_liq)
# => H_dep_liq = H_deg_vap + Watson - DELTA_HVAP_IMPL + (H_ig_y-H_ig_x)

print(f"\n  Pour Modele B (Full PR, h = H_ig_x + H_dep_liq):")
print(f"    H_dep_liq Python  = {H_dep_liq:>+12.3f} kJ/kmol")
print(f"    H_dep_liq requis  = {H_dep_liq_needed:>+12.3f} kJ/kmol  [pour H[0]-h[0]={DELTA_HVAP_IMPL:.2f}]")
print(f"    Ecart             = {H_dep_liq - H_dep_liq_needed:>+12.3f} kJ/kmol")
print(f"    Ecart relatif     = {(H_dep_liq/H_dep_liq_needed-1)*100:>+10.3f}%")

print(f"\n  Pour Modele C (Watson + H_dep_liq, h = H_ig_x - Watson + H_dep_liq):")
# H[0]-h[0]_target = (H_ig_y-H_ig_x) + H_dep_vap + Watson - H_dep_liq_C
# => H_dep_liq_C = (H_ig_y-H_ig_x) + H_dep_vap + Watson - DELTA_HVAP_IMPL
H_dep_liq_needed_C = (H_ig_y0 - H_ig_x0) + H_dep_vap + dHvap_Watson - DELTA_HVAP_IMPL
print(f"    H_dep_liq Python  = {H_dep_liq:>+12.3f} kJ/kmol")
print(f"    H_dep_liq requis  = {H_dep_liq_needed_C:>+12.3f} kJ/kmol")
print(f"    Ecart             = {H_dep_liq - H_dep_liq_needed_C:>+12.3f} kJ/kmol")

# =============================================================================
# PARTIE 7 — Test sur les 3 cas
# =============================================================================
print("\n" + "=" * 70)
print("PARTIE 7 — Resume 3 cas: Watson vs Full PR")
print("=" * 70)
print(f"\n  {'Cas':>3}  {'QC_ref':>13}  {'QC_Watson':>13}  {'err_W%':>7}  "
      f"{'QC_FullPR':>13}  {'err_PR%':>8}  {'h0_B-h0_A':>10}")

CASES_QC_REF = {1: 4_133_587.91, 2: 4_125_130.56, 3: 3_340_734.13}

for case_num in [1, 2, 3]:
    col2 = Deethanizer()
    col2.solve(case=case_num)
    eos2 = col2.eos
    P2 = col2.P
    T02 = col2.T[0]; T12 = col2.T[1]
    x02 = col2.l[:, 0] / col2.l[:, 0].sum()
    y02 = col2.v[:, 0] / col2.v[:, 0].sum()
    x12 = col2.l[:, 1] / col2.l[:, 1].sum()
    y12 = col2.v[:, 1] / col2.v[:, 1].sum()
    L02 = col2.l[:, 0].sum()
    V12 = col2.v[:, 1].sum()
    D2  = col2.v[:, 0].sum()

    H0_vap2 = eos2.mixture_enthalpy(T02, P2, y02, 'vapor')
    h0_W2   = eos2.pure_component_enthalpy(T02, P2, x02, 'liquid')
    h0_PR2  = eos2.mixture_enthalpy(T02, P2, x02, 'liquid')
    H1_vap2 = eos2.mixture_enthalpy(T12, P2, y12, 'vapor')

    QC_W2,  _, _ = compute_QC(H0_vap2, h0_W2,  H1_vap2, V12, L02, D2)
    QC_PR2, _, _ = compute_QC(H0_vap2, h0_PR2, H1_vap2, V12, L02, D2)

    qref = CASES_QC_REF[case_num]
    print(f"  {case_num:>3}  {qref:>13,.1f}  {QC_W2:>13,.1f}  {(QC_W2/qref-1)*100:>+7.2f}%  "
          f"{QC_PR2:>13,.1f}  {(QC_PR2/qref-1)*100:>+8.2f}%  {h0_PR2-h0_W2:>+10.1f}")

# =============================================================================
# PARTIE 8 — Comparer dHvap_DIPPR par composant vs valeurs NIST (litterature)
# =============================================================================
print("\n" + "=" * 70)
print("PARTIE 8 — dHvap DIPPR vs NIST a T[0]=261K et T_sat(P_col)")
print("=" * 70)
print()
print("  NOTE: Watson DIPPR = correlation T-dependante (DIPPR 106 ou Watson).")
print("  NIST valeurs approx pour comparaison (lecture manuelle WebBook):")
print()

# C2H6 at 261K: from NIST WebBook saturated properties
# Psat(C2H6, 261K) ~22.8 bar
# Hvap(C2H6, 261K) ~ 9.36 kJ/mol = 9360 kJ/kmol  (NIST)
# But at P=27.5 bar (compressed liq): different than at Psat

# C3H8 at 261K: from NIST
# Psat(C3H8, 261K) ~5.3 bar
# Hvap(C3H8, 261K) ~16.8 kJ/mol = 16800 kJ/kmol  (NIST)

nist_manual = {
    'C2': {'T': 261., 'dHvap_NIST': 9360.,  'note': 'NIST Webbook C2H6, Tsat, interp.'},
    'C3': {'T': 261., 'dHvap_NIST': 16800., 'note': 'NIST Webbook C3H8, Tsat, interp.'},
}

print(f"  {'Comp':>5}  {'x[0]':>7}  {'T(K)':>7}  {'dHvap_DIPPR':>14}  {'dHvap_NIST':>12}  {'err%':>7}  Note")
print(f"  {'-'*90}")
for cn, d in nist_manual.items():
    if cn not in names:
        continue
    idx = names.index(cn)
    try:
        dh_dippr = eos._Hvap[idx].T_dependent_property(d['T'])
    except Exception:
        dh_dippr = float('nan')
    err = (dh_dippr / d['dHvap_NIST'] - 1) * 100 if d['dHvap_NIST'] else float('nan')
    print(f"  {cn:>5}  {x0[idx]:>7.4f}  {d['T']:>7.1f}  {dh_dippr if dh_dippr else 0:>14.2f}  "
          f"{d['dHvap_NIST']:>12.1f}  {err:>+7.2f}%  {d['note']}")

# Re-run detailed C2 and C3 to get exact DIPPR at T0
print(f"\n  DIPPR exact a T[0]={T0:.2f} K:")
for cn in ['C2', 'C3', 'iC4', 'nC4']:
    if cn not in names:
        continue
    idx = names.index(cn)
    Tc_i = eos.Tc[idx]
    if T0 >= Tc_i:
        print(f"    {cn:>5}: SUPERCRITIQUE (Tc={Tc_i:.1f}K < T0={T0:.1f}K)")
        continue
    try:
        dh = eos._Hvap[idx].T_dependent_property(T0)
    except Exception as e:
        dh = None
    print(f"    {cn:>5}: Tc={Tc_i:.1f}K  Tr={T0/Tc_i:.3f}  "
          f"dHvap_DIPPR(T0)={dh if dh else 0:.2f} kJ/kmol"
          f"  x={x0[idx]:.4f}  contrib={x0[idx]*(dh if dh else 0):.2f} kJ/kmol")

# =============================================================================
# PARTIE 9 — Synthese finale
# =============================================================================
print("\n" + "=" * 70)
print("PARTIE 9 — SYNTHESE FINALE")
print("=" * 70)
print(f"""
  MODELES TESTES (Case 1, condenseur partiel):
  ┌─────────────────────────────────────────────────────────────────┐
  │ Modele             │ h[0]          │ H[0]-h[0]  │ QC          │
  ├────────────────────┼───────────────┼────────────┼─────────────┤
  │ A Watson (actuel)  │ {h0_A:>+13.2f} │ {H0_h0_A:>10.2f} │ {QC_A:>11,.1f} │
  │ B Full PR (liquide)│ {h0_B:>+13.2f} │ {H0_h0_B:>10.2f} │ {QC_B:>11,.1f} │
  │ C Watson+H_dep_liq │ {h0_C:>+13.2f} │ {H0_h0_C:>10.2f} │ {QC_C:>11,.1f} │
  │ REF Delphi         │      ?        │ {DELTA_HVAP_IMPL:>10.2f} │ {QC_REF:>11,.1f} │
  └─────────────────────────────────────────────────────────────────┘

  INTERPRETATION:
    Modele A (Watson seul, no H_dep liq):
      err QC = {(QC_A/QC_REF-1)*100:>+.2f}% → {'+' if QC_A>QC_REF else ''} ecart = {abs(QC_A-QC_REF):,.0f} kJ/h

    Modele B (full PR pour liquide, h = H_ig + H_dep_liq):
      err QC = {(QC_B/QC_REF-1)*100:>+.2f}% → {'MEILLEUR' if abs(QC_B-QC_REF) < abs(QC_A-QC_REF) else 'MOINS BON'}

    Modele C (Watson + H_dep_liq):
      err QC = {(QC_C/QC_REF-1)*100:>+.2f}%

    Conclusion:
      {'=> Modele B (Full PR) est plus proche de Delphi !' if abs(QC_B-QC_REF) < abs(QC_A-QC_REF) else '=> Modele A (Watson) est deja le meilleur des 3'}
""")
