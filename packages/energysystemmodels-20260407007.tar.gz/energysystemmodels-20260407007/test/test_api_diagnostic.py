"""
Script de diagnostic détaillé pour tester la clé API OpenWeatherMap
"""

import sys
import os
import requests

# Ajouter le chemin du module OpenWeatherMap
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src', 'OpenWeatherMap'))

import get_weather

def test_api_detailed():
    print("=" * 80)
    print("DIAGNOSTIC DÉTAILLÉ DE LA CLÉ API OPENWEATHERMAP")
    print("=" * 80)
    
    # 1. Récupérer la clé API
    print("\n📋 ÉTAPE 1 : Vérification de la configuration")
    print("-" * 80)
    try:
        api_key = get_weather.get_api_key()
        print(f"✓ Clé API récupérée depuis config.ini")
        print(f"  Clé complète : {api_key}")
        print(f"  Longueur     : {len(api_key)} caractères")
        
        # Vérifier le format
        if len(api_key) != 32:
            print(f"⚠️  ATTENTION : La clé devrait avoir 32 caractères, elle en a {len(api_key)}")
        if not api_key.isalnum():
            print(f"⚠️  ATTENTION : La clé contient des caractères non alphanumériques")
    except Exception as e:
        print(f"✗ Erreur : {e}")
        return False
    
    # 2. Test direct de l'API
    print("\n🌐 ÉTAPE 2 : Test direct de l'API OpenWeatherMap")
    print("-" * 80)
    
    # Test avec Paris
    lat, lon = 48.8566, 2.3522
    url = f"http://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={api_key}"
    
    print(f"URL testée : {url}")
    print("\n⏳ Envoi de la requête...")
    
    try:
        response = requests.get(url, timeout=10)
        print(f"\n📊 Réponse reçue :")
        print(f"  Code HTTP : {response.status_code}")
        print(f"  Statut    : {response.reason}")
        
        if response.status_code == 200:
            print("\n✅ SUCCÈS ! La clé API fonctionne correctement.")
            data = response.json()
            print("\n📍 Données météo reçues pour Paris :")
            print(f"  Ville       : {data.get('name', 'N/A')}")
            print(f"  Pays        : {data.get('sys', {}).get('country', 'N/A')}")
            print(f"  Température : {data.get('main', {}).get('temp', 0) - 273.15:.1f} °C")
            print(f"  Ressenti    : {data.get('main', {}).get('feels_like', 0) - 273.15:.1f} °C")
            print(f"  Description : {data.get('weather', [{}])[0].get('description', 'N/A')}")
            print(f"  Humidité    : {data.get('main', {}).get('humidity', 'N/A')} %")
            print(f"  Pression    : {data.get('main', {}).get('pressure', 'N/A')} hPa")
            print(f"  Vent        : {data.get('wind', {}).get('speed', 'N/A')} m/s")
            print(f"  Nuages      : {data.get('clouds', {}).get('all', 'N/A')} %")
            return True
            
        elif response.status_code == 401:
            print("\n❌ ERREUR 401 : CLÉ API NON AUTORISÉE")
            try:
                error_data = response.json()
                print(f"\n📝 Message d'erreur de l'API :")
                print(f"  {error_data.get('message', 'Pas de message')}")
            except:
                print(f"  Contenu brut : {response.text}")
            
            print("\n🔍 Causes possibles :")
            print("  1. La clé API n'est pas encore activée (peut prendre quelques heures)")
            print("  2. La clé API est invalide ou a expiré")
            print("  3. La clé API n'a pas les permissions nécessaires")
            print("  4. Le compte OpenWeatherMap a été suspendu")
            
            print("\n💡 Solutions recommandées :")
            print("  1. Vérifiez votre compte sur https://home.openweathermap.org/api_keys")
            print("  2. Assurez-vous que la clé est 'Active'")
            print("  3. Si la clé vient d'être créée, attendez 1-2 heures")
            print("  4. Générez une nouvelle clé API si nécessaire")
            return False
            
        elif response.status_code == 404:
            print("\n❌ ERREUR 404 : Localisation non trouvée")
            return False
            
        elif response.status_code == 429:
            print("\n❌ ERREUR 429 : Limite de requêtes dépassée")
            print("  Trop de requêtes ont été effectuées. Attendez quelques minutes.")
            return False
            
        else:
            print(f"\n❌ ERREUR {response.status_code} : {response.reason}")
            try:
                print(f"  Message : {response.json()}")
            except:
                print(f"  Contenu : {response.text}")
            return False
            
    except requests.exceptions.Timeout:
        print("\n❌ ERREUR : Timeout de connexion")
        print("  La requête a pris trop de temps. Vérifiez votre connexion Internet.")
        return False
        
    except requests.exceptions.ConnectionError:
        print("\n❌ ERREUR : Impossible de se connecter à l'API")
        print("  Vérifiez votre connexion Internet.")
        return False
        
    except Exception as e:
        print(f"\n❌ ERREUR INATTENDUE : {e}")
        import traceback
        traceback.print_exc()
        return False
    
    # 3. Test avec l'ancienne clé pour comparaison
    print("\n🔄 ÉTAPE 3 : Test avec l'ancienne clé (pour comparaison)")
    print("-" * 80)
    old_api_key = "7b18d48745ae006628ff1ee161be2b69"
    url_old = f"http://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={old_api_key}"
    
    print(f"Test de l'ancienne clé : {old_api_key[:10]}...{old_api_key[-10:]}")
    
    try:
        response_old = requests.get(url_old, timeout=10)
        print(f"  Code HTTP de l'ancienne clé : {response_old.status_code}")
        
        if response_old.status_code == 200:
            print("  ✓ L'ancienne clé fonctionne toujours")
        elif response_old.status_code == 401:
            print("  ✗ L'ancienne clé ne fonctionne plus non plus")
        else:
            print(f"  ? L'ancienne clé retourne : {response_old.status_code}")
    except Exception as e:
        print(f"  Erreur lors du test de l'ancienne clé : {e}")

if __name__ == "__main__":
    print("\n")
    try:
        success = test_api_detailed()
        print("\n" + "=" * 80)
        if success:
            print("✅ DIAGNOSTIC TERMINÉ : La clé API fonctionne correctement !")
        else:
            print("❌ DIAGNOSTIC TERMINÉ : La clé API ne fonctionne pas correctement")
        print("=" * 80)
        print("\n")
    except KeyboardInterrupt:
        print("\n\n⚠️  Diagnostic interrompu par l'utilisateur")
        sys.exit(1)
