"""
Script de test pour vérifier le fonctionnement de la clé API OpenWeatherMap
"""


from OpenWeatherMap import get_weather

def test_api_key():
    print("=" * 70)
    print("TEST DE LA CLÉ API OPENWEATHERMAP")
    print("=" * 70)
    
    # 1. Récupérer la clé API depuis config.ini
    print("\n1️⃣  Récupération de la clé API...")
    try:
        api_key = get_weather.get_api_key()
        print(f"✓ Clé API chargée : {api_key[:10]}...{api_key[-10:]}")
        print(f"  Longueur de la clé : {len(api_key)} caractères")
    except Exception as e:
        print(f"✗ Erreur lors de la récupération de la clé : {e}")
        return False
    
    # 2. Récupérer la localisation par défaut
    print("\n2️⃣  Récupération de la localisation par défaut...")
    try:
        location = get_weather.get_location()
        town, lat, lon = location
        print(f"✓ Localisation : {town}")
        print(f"  Latitude  : {lat}")
        print(f"  Longitude : {lon}")
    except Exception as e:
        print(f"✗ Erreur lors de la récupération de la localisation : {e}")
        return False
    
    # 3. Tester l'appel API avec Paris (coordonnées fiables)
    print("\n3️⃣  Test d'appel API avec Paris...")
    test_locations = [
        ("Paris", 48.8566, 2.3522),
        ("Londres", 51.5074, -0.1278),
        ("New York", 40.7128, -74.0060)
    ]
    
    for city, test_lat, test_lon in test_locations:
        print(f"\n📍 Test avec {city} (lat={test_lat}, lon={test_lon})")
        try:
            weather = get_weather.get_weather(api_key, city, test_lat, test_lon)
            
            if weather:
                print(f"✓ Réponse API reçue pour {city}")
                print(f"  Température : {weather.get('main', {}).get('temp', 'N/A')} K")
                print(f"  Description : {weather.get('weather', [{}])[0].get('description', 'N/A')}")
                print(f"  Humidité    : {weather.get('main', {}).get('humidity', 'N/A')} %")
                print(f"  Pression    : {weather.get('main', {}).get('pressure', 'N/A')} hPa")
                print(f"  Vent        : {weather.get('wind', {}).get('speed', 'N/A')} m/s")
                
                # Convertir température en Celsius
                temp_k = weather.get('main', {}).get('temp', 0)
                if temp_k:
                    temp_c = temp_k - 273.15
                    print(f"  Temp (°C)   : {temp_c:.1f} °C")
            else:
                print(f"✗ Aucune réponse reçue pour {city}")
                return False
                
        except Exception as e:
            print(f"✗ Erreur lors de l'appel API pour {city} : {e}")
            print(f"  Type d'erreur : {type(e).__name__}")
            return False
    
    # 4. Résultat final
    print("\n" + "=" * 70)
    print("✅ TOUS LES TESTS SONT PASSÉS AVEC SUCCÈS !")
    print("=" * 70)
    print("\n💡 La nouvelle clé API OpenWeatherMap fonctionne correctement.")
    print(f"   Clé API : {api_key}")
    print("=" * 70)
    
    return True

if __name__ == "__main__":
    try:
        success = test_api_key()
        if not success:
            print("\n" + "=" * 70)
            print("❌ ÉCHEC DES TESTS")
            print("=" * 70)
            print("\n🔍 Vérifications suggérées :")
            print("   1. Vérifiez que la clé API est correcte dans config.ini")
            print("   2. Vérifiez votre connexion Internet")
            print("   3. Vérifiez que la clé API est active sur openweathermap.org")
            print("=" * 70)
            sys.exit(1)
    except KeyboardInterrupt:
        print("\n\n⚠️  Test interrompu par l'utilisateur")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ ERREUR CRITIQUE : {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
