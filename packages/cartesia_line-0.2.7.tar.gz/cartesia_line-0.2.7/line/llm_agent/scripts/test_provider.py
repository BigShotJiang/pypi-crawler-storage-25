#!/usr/bin/env python3
"""
Test script for LlmProvider integration with real API keys.

Usage:
    uv run python line/llm_agent/scripts/test_provider.py [OPTIONS]

Options:
    --tests TESTS       Comma-separated list of tests to run. Available tests:
                        streaming, introduction, tools, web_search,
                        web_search_fn, mcp, reset, all (default: all)
    --runs N            Number of iterations for eval tests (default: 3)
    --model MODEL       Only test specific model (e.g., "gpt-4o-mini")

Examples:
    # Run all tests
    uv run python line/llm_agent/scripts/test_provider.py

    # Run only end_call evaluation tests
    uv run python line/llm_agent/scripts/test_provider.py --tests end_call,end_call_eval,form_eval

    # Run form evaluation with more iterations
    uv run python line/llm_agent/scripts/test_provider.py --tests form_eval --runs 5

Environment variables:
    OPENAI_API_KEY      - For OpenAI models (gpt-4o, gpt-4o-mini)
    ANTHROPIC_API_KEY   - For Anthropic models (anthropic/claude-sonnet-4-20250514)
    GEMINI_API_KEY      - For Google models (gemini/gemini-2.5-flash-preview-09-2025)

MCP Tests:
    MCP tests use a local dice-rolling MCP server (line/llm_agent/scripts/test_mcp_server.py)
    that exposes a roll tool via stdio transport.

The script will test whichever providers have API keys set.
"""

import argparse
import asyncio
import json
import logging
import os
import pathlib
import sys
from typing import Annotated, TypedDict
import warnings

import litellm
from loguru import logger

from line.agent import TurnEnv
from line.events import (
    AgentSendText,
    AgentToolCalled,
    AgentToolReturned,
    CallStarted,
    UserTextSent,
)
from line.llm_agent import (
    LlmAgent,
    LlmConfig,
    end_call,
    loopback_tool,
    mcp_tool,
    web_search,
)
from line.llm_agent.provider import LlmProvider, Message
from line.llm_agent.schema_converter import function_tool_to_litellm

# =============================================================================
# Test Tools
# =============================================================================


@loopback_tool
async def get_weather(ctx, city: Annotated[str, "City name"]) -> str:
    """Get the current weather for a city."""
    # Simulated weather data
    weather_data = {
        "new york": "72°F, partly cloudy",
        "san francisco": "65°F, foggy",
        "london": "55°F, rainy",
        "tokyo": "80°F, sunny",
    }
    city_lower = city.lower()
    return weather_data.get(city_lower, f"Weather data not available for {city}")


@loopback_tool
async def calculate(ctx, expression: Annotated[str, "Math expression to evaluate"]) -> str:
    """Evaluate a mathematical expression."""
    try:
        # Safe eval for simple math
        allowed = set("0123456789+-*/.() ")
        if all(c in allowed for c in expression):
            result = eval(expression)
            return f"{expression} = {result}"
        return "Invalid expression"
    except Exception as e:
        return f"Error: {e}"


# =============================================================================
# Nested Object Tools (TypedDict vs list[dict])
# =============================================================================


class MenuItem(TypedDict):
    """A menu item for ordering."""

    menu_item_id: str
    quantity: int
    modifiers: list[str]


@loopback_tool
async def add_to_order(
    ctx,
    items: Annotated[list[MenuItem], "List of menu items to add to the order"],
) -> str:
    """Add items to a restaurant order. Uses TypedDict for proper schema generation."""
    return json.dumps({"success": True, "items_added": len(items), "items": items})


@loopback_tool
async def add_to_order_broken(
    ctx,
    items: Annotated[list[dict], "List of menu items with format [{'menu_item_id': str, 'quantity': int}]"],
) -> str:
    """Add items using list[dict]. Fails strict schema conversion unless strict_tool_schemas=False."""
    return json.dumps({"success": True, "items_added": len(items), "items": items})


# =============================================================================
# Test Functions
# =============================================================================


async def test_api_key(model: str, api_key: str) -> bool:
    """Test that API key is valid and has permissions."""
    print("\n" + "=" * 60)
    print(f"Testing API key for {model}")
    print("=" * 60)

    provider = LlmProvider(model=model, api_key=api_key)

    messages = [Message(role="user", content="Say 'ok'")]

    try:
        async for chunk in provider.chat(messages):
            if chunk.text:
                print(f"✓ API key valid - got response: {chunk.text.strip()}")
                return True
        print("✓ API key valid")
        return True
    except Exception as e:
        print(f"✗ API key error: {e}")
        return False


async def test_streaming_text(model: str, api_key: str):
    """Test basic streaming text response."""
    print("\n" + "=" * 60)
    print(f"Testing streaming text with {model}")
    print("=" * 60)

    provider = LlmProvider(model=model, api_key=api_key)

    messages = [Message(role="user", content="Say 'Hello, World!' and nothing else.")]

    print("Response: ", end="", flush=True)
    async for chunk in provider.chat(messages):
        if chunk.text:
            print(chunk.text, end="", flush=True)
    print("\n✓ Streaming text test passed")


async def test_tool_calling(model: str, api_key: str):
    """Test tool calling with LlmAgent."""
    print("\n" + "=" * 60)
    print(f"Testing tool calling with {model}")
    print("=" * 60)

    agent = LlmAgent(
        model=model,
        api_key=api_key,
        tools=[get_weather, calculate],
        config=LlmConfig(
            system_prompt="You are a helpful assistant. Use tools when needed.",
        ),
    )

    env = TurnEnv()
    user_message = "What's the weather in Tokyo? Also, what's 25 * 4?"
    event = UserTextSent(
        content=user_message,
        history=[UserTextSent(content=user_message)],
    )

    print("User: What's the weather in Tokyo? Also, what's 25 * 4?")
    print("\nAgent response:")

    tool_calls_made = []
    async for output in agent.process(env, event):
        if isinstance(output, AgentSendText):
            print(output.text, end="", flush=True)  # Prints the entire text response
        elif isinstance(output, AgentToolCalled):
            tool_calls_made.append(output.tool_name)
            print(f"\n  [Tool call]: {output.tool_name}({output.tool_args})]")
        elif isinstance(output, AgentToolReturned):
            print(f"  [Tool result]: {output.result}]")

    print()

    if tool_calls_made:
        print(f"✓ Tool calling test passed (tools used: {', '.join(tool_calls_made)})")
    else:
        print("⚠ No tools were called (model may have answered directly)")


async def test_introduction(model: str, api_key: str):
    """Test introduction message on CallStarted."""
    print("\n" + "=" * 60)
    print(f"Testing introduction with {model}")
    print("=" * 60)

    agent = LlmAgent(
        model=model,
        api_key=api_key,
        config=LlmConfig(
            introduction="Hello! I'm your AI assistant. How can I help you today?",
        ),
    )

    env = TurnEnv()
    event = CallStarted()

    print("Event: CallStarted")
    print("Introduction: ", end="")

    async for output in agent.process(env, event):
        if isinstance(output, AgentSendText):
            print(output.text)

    print("✓ Introduction test passed")


async def test_web_search(model: str, api_key: str, search_context_size: str = "medium"):
    """Test web search tool integration."""
    print("\n" + "=" * 60)
    if search_context_size != "medium":
        print(f"Testing web search with {model} (context_size={search_context_size}")
    else:
        print(f"Testing web search with {model}")
    print("=" * 60)

    agent = LlmAgent(
        model=model,
        api_key=api_key,
        tools=[web_search(search_context_size=search_context_size)],
        config=LlmConfig(
            system_prompt="You are a helpful assistant with web search capabilities."
            + " Use web search to find current information.",
        ),
    )

    env = TurnEnv()
    user_message = "What is the current weather in New York City? Search the web for this information."
    event = UserTextSent(
        content=user_message,
        history=[UserTextSent(content=user_message)],
    )

    print(f"User: {user_message}")
    print("\nAgent response:")

    web_search_used = False
    async for output in agent.process(env, event):
        if isinstance(output, AgentSendText):
            print(output.text, end="", flush=True)
        elif isinstance(output, AgentToolCalled):
            if output.tool_name == "web_search":
                web_search_used = True
            print(f"\n  [Tool call]: {output.tool_name}({output.tool_args})")
        elif isinstance(output, AgentToolReturned):
            # Truncate long results for display
            result_preview = output.result[:200] + "..." if len(output.result) > 200 else output.result
            print(f"  [Tool result]: {result_preview}")

    print()

    if web_search_used:
        print("✓ Web search test passed (web_search tool was called)")
    else:
        print("⚠ Web search tool was not explicitly called (model may use native web search)")
    print("✓ Web search test completed")


async def test_function_tools_with_web_search(model: str, api_key: str):
    """Test combining function calling tools with web search.

    This reproduces the scenario from examples/basic_chat/main.py where
    both end_call (a function tool) and web_search are passed together.
    Some models (e.g. Gemini 3) don't support combining native web search
    with function calling tools in the same request.
    """
    print("\n" + "=" * 60)
    print(f"Testing function tools + web search with {model}")
    print("=" * 60)

    agent = LlmAgent(
        model=model,
        api_key=api_key,
        tools=[end_call, web_search],
        config=LlmConfig(
            system_prompt="You are a helpful assistant. Use web search when needed. "
            "Use end_call when the user says goodbye.",
        ),
    )

    env = TurnEnv()
    user_message = "Hi, how are you?"
    event = UserTextSent(
        content=user_message,
        history=[UserTextSent(content=user_message)],
    )

    print(f"User: {user_message}")
    print("\nAgent response:")

    async for output in agent.process(env, event):
        if isinstance(output, AgentSendText):
            print(output.text, end="", flush=True)
        elif isinstance(output, AgentToolCalled):
            print(f"\n  [Tool call]: {output.tool_name}({output.tool_args})")
        elif isinstance(output, AgentToolReturned):
            result_preview = output.result[:200] + "..." if len(output.result) > 200 else output.result
            print(f"  [Tool result]: {result_preview}")

    print()
    print("✓ Function tools + web search test passed")


def _local_mcp_server_command() -> str:
    """Return the command to launch the local test MCP server."""
    server_path = pathlib.Path(__file__).parent / "test_mcp_server.py"
    return f"{sys.executable} {server_path}"


async def test_mcp_list_tools(model: str, api_key: str):
    """Test MCP tool listing with the local test MCP server."""
    print(f"\n{'=' * 60}")
    print(f"Testing MCP tool listing with {model}")
    print("=" * 60)

    agent = LlmAgent(
        model=model,
        api_key=api_key,
        tools=[
            mcp_tool(
                name="dice",
                command=_local_mcp_server_command(),
            )
        ],
        config=LlmConfig(
            system_prompt="You are a helpful assistant with access to an MCP server. "
            "Use the available tools when asked.",
        ),
    )

    env = TurnEnv()
    user_message = "What tools are available?"
    event = UserTextSent(
        content=user_message,
        history=[UserTextSent(content=user_message)],
    )

    print(f"User: {user_message}")
    print("\nAgent response:")

    mcp_tool_used = False
    async for output in agent.process(env, event):
        if isinstance(output, AgentSendText):
            print(output.text, end="", flush=True)
        elif isinstance(output, AgentToolCalled):
            if output.tool_name == "mcp_dice":
                mcp_tool_used = True
            print(f"\n  [Tool call]: {output.tool_name}({output.tool_args})")
        elif isinstance(output, AgentToolReturned):
            result_preview = output.result[:400] + "..." if len(output.result) > 400 else output.result
            print(f"  [Tool result]: {result_preview}")

    print()

    if mcp_tool_used:
        print("✓ MCP tool listing test passed (mcp_dice tool was called)")
    else:
        print("⚠ MCP tool was not called (model may have answered directly)")


async def test_mcp_tool_execution(model: str, api_key: str):
    """Test MCP tool execution with the local test MCP server."""
    print(f"\n{'=' * 60}")
    print(f"Testing MCP tool execution with {model}")
    print("=" * 60)

    agent = LlmAgent(
        model=model,
        api_key=api_key,
        tools=[
            mcp_tool(
                name="dice",
                command=_local_mcp_server_command(),
            )
        ],
        config=LlmConfig(
            system_prompt="You are a helpful assistant with access to an MCP server. "
            "First list available tools, then use them as requested.",
        ),
    )

    env = TurnEnv()
    user_message = "Roll 3 six-sided dice for me."
    event = UserTextSent(
        content=user_message,
        history=[UserTextSent(content=user_message)],
    )

    print(f"User: {user_message}")
    print("\nAgent response:")

    mcp_tool_calls = []
    async for output in agent.process(env, event):
        if isinstance(output, AgentSendText):
            print(output.text, end="", flush=True)
        elif isinstance(output, AgentToolCalled):
            if output.tool_name == "mcp_dice":
                mcp_tool_calls.append(output.tool_args)
            print(f"\n  [Tool call]: {output.tool_name}({output.tool_args})")
        elif isinstance(output, AgentToolReturned):
            result_preview = output.result[:200] + "..." if len(output.result) > 200 else output.result
            print(f"  [Tool result]: {result_preview}")

    print()

    if mcp_tool_calls:
        print(f"✓ MCP tool execution test passed ({len(mcp_tool_calls)} tool calls made)")
    else:
        print("⚠ MCP tool was not called (model may have answered directly)")
    print("✓ MCP tool execution test completed")


async def test_conversation_reset(model: str, api_key: str):
    """Test resetting a conversation to an earlier point.

    Exercises the WebSocket provider's divergence detection by:
    1. Running a 2-turn conversation (user sets a secret word, assistant acks).
    2. Asking the model to recall the secret word (turn 3).
    3. Resetting: re-sending turns 1-2 with a *different* secret word,
       then asking the model to recall it again (turn 3').
    4. Verifying the model answers with the *new* secret word, confirming
       the provider rolled back correctly.
    """
    print("\n" + "=" * 60)
    print(f"Testing conversation reset with {model}")
    print("=" * 60)

    provider = LlmProvider(model=model, api_key=api_key)

    async def collect_text(stream) -> str:
        parts = []
        async for chunk in stream:
            if chunk.text:
                parts.append(chunk.text)
        return "".join(parts)

    # Turn 1: shared greeting — captures the real assistant response.
    history = [Message(role="user", content="Hi, I'm testing multi-turn. Just say OK.")]
    print("--- Turn 1: greeting ---")
    turn1_reply = await collect_text(provider.chat(history))
    print(f"Model says: {turn1_reply.strip()}")
    history.append(Message(role="assistant", content=turn1_reply))

    # Turn 2 (branch A): set secret word = banana.
    history.append(Message(role="user", content="The secret word is 'banana'. Just say OK."))
    print("--- Turn 2a: secret word = banana ---")
    turn2a_reply = await collect_text(provider.chat(history))
    print(f"Model says: {turn2a_reply.strip()}")
    history.append(Message(role="assistant", content=turn2a_reply))

    # Turn 3 (branch A): ask for the secret word.
    history.append(
        Message(role="user", content="What is the secret word? Reply with ONLY the word, nothing else.")
    )
    print("--- Turn 3a: recall ---")
    response_a = await collect_text(provider.chat(history))
    print(f"Model says: {response_a.strip()}")

    # Branch B: rewind to after turn 1, set a different secret word.
    # Keeps the first two messages (user + real assistant reply) intact,
    # so divergence happens at message index 2.
    history_b = history[:2]  # user greeting + real assistant reply
    history_b.append(Message(role="user", content="The secret word is 'giraffe'. Just say OK."))
    print("--- Turn 2b (reset at message 2): secret word = giraffe ---")
    turn2b_reply = await collect_text(provider.chat(history_b))
    print(f"Model says: {turn2b_reply.strip()}")
    history_b.append(Message(role="assistant", content=turn2b_reply))

    # Turn 3 (branch B): ask for the secret word again.
    history_b.append(
        Message(role="user", content="What is the secret word? Reply with ONLY the word, nothing else.")
    )
    print("--- Turn 3b: recall after reset ---")
    response_b = await collect_text(provider.chat(history_b))
    print(f"Model says: {response_b.strip()}")

    a_ok = "banana" in response_a.lower()
    b_ok = "giraffe" in response_b.lower()

    if a_ok and b_ok:
        print("✓ Conversation reset test passed")
    elif not a_ok:
        raise AssertionError(f"Branch A failed — expected 'banana', got: {response_a.strip()!r}")
    else:
        raise AssertionError(f"Branch B failed — expected 'giraffe', got: {response_b.strip()!r}")


async def test_nested_objects(model: str, api_key: str):
    """Test tool calling with nested objects using TypedDict.

    This test validates that:
    1. TypedDict generates proper JSON schemas with all properties defined
    2. The schema includes additionalProperties: false for OpenAI compatibility
    3. The LLM can correctly call tools with nested object parameters

    Use TypedDict instead of list[dict]: with strict tool schemas (default), bare dict
    shapes fail at conversion before any API call.
    """
    print("\n" + "=" * 60)
    print(f"Testing nested objects (TypedDict) with {model}")
    print("=" * 60)

    agent = LlmAgent(
        model=model,
        api_key=api_key,
        tools=[add_to_order],
        config=LlmConfig(
            system_prompt="""You are a restaurant order assistant.
When the user wants to order food, use the add_to_order tool.

Available menu items:
- item_001: Grilled Oysters ($15)
- item_002: Lobster Roll ($25)
- item_003: Fish Tacos ($12)

Always include menu_item_id, quantity, and modifiers (can be empty list).""",
        ),
    )

    env = TurnEnv()
    user_message = "I'd like to order 2 grilled oysters please"
    event = UserTextSent(
        content=user_message,
        history=[UserTextSent(content=user_message)],
    )

    print(f"User: {user_message}")
    print("\nAgent response:")

    tool_called = False
    tool_args = None
    error_occurred = False

    try:
        async for output in agent.process(env, event):
            if isinstance(output, AgentSendText):
                print(f"  Text: {output.text}")
            elif isinstance(output, AgentToolCalled):
                tool_called = True
                tool_args = output.tool_args
                print(f"  [Tool call]: {output.tool_name}")
                print(f"  [Tool args]: {json.dumps(output.tool_args, indent=4)}")
            elif isinstance(output, AgentToolReturned):
                print(f"  [Tool result]: {output.result}")
    except Exception as e:
        error_occurred = True
        print(f"  [ERROR]: {e}")
    finally:
        await agent.cleanup()

    # Validate results
    print("\n--- Validation ---")
    if error_occurred:
        print("✗ Test failed: Error occurred during tool call")
        return False
    elif not tool_called:
        print("✗ Test failed: Tool was never called")
        return False
    elif tool_args is None or "items" not in tool_args:
        print("✗ Test failed: 'items' not in tool arguments")
        return False
    elif not tool_args["items"]:
        print("✗ Test failed: 'items' is empty")
        return False
    else:
        # Validate item structure
        items = tool_args["items"]
        valid = True
        for item in items:
            if "menu_item_id" not in item or "quantity" not in item:
                valid = False
                break
        if valid:
            print(f"✓ Nested objects test passed (items: {items})")
            return True
        else:
            print("✗ Test failed: Item structure is invalid")
            return False


async def test_nested_objects_without_typeddict(model: str, api_key: str):
    """list[dict] under default strict schemas raises at conversion; opt-out path still works.

    First asserts ``function_tool_to_litellm(..., strict=True)`` raises. Then runs the agent
    with ``LlmConfig(strict_tool_schemas=False)`` so non-strict tool definitions are allowed.
    """
    print("\n" + "=" * 60)
    print(f"Testing nested objects WITHOUT TypedDict (list[dict]) with {model}")
    print("=" * 60)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        try:
            function_tool_to_litellm(add_to_order_broken)
        except ValueError as e:
            print(f"✓ Strict conversion rejected list[dict] as expected: {e!s}")
        else:
            print("✗ Expected ValueError from function_tool_to_litellm(strict=True)")
            return False

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        litellm_tool = function_tool_to_litellm(add_to_order_broken, strict=False)
    fn = litellm_tool["function"]
    assert fn.get("strict") is not True
    items_param = fn["parameters"]["properties"]["items"]
    assert items_param["type"] == "array"
    assert items_param["items"] == {"type": "object"}
    print("✓ With strict=False: tool spec has untyped object array items (as expected)")

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        agent = LlmAgent(
            model=model,
            api_key=api_key,
            tools=[add_to_order_broken],
            config=LlmConfig(
                strict_tool_schemas=False,
                system_prompt="""You are a restaurant order assistant.
When the user wants to order food, use the add_to_order_broken tool.

Available menu items:
- item_001: Grilled Oysters ($15)

Always include menu_item_id and quantity.""",
            ),
        )

    env = TurnEnv()
    user_message = "Order 2 grilled oysters"
    event = UserTextSent(
        content=user_message,
        history=[UserTextSent(content=user_message)],
    )

    print(f"User: {user_message}")
    print("\nAgent response:")

    tool_called = False
    tool_args = None
    error_occurred = False
    try:
        async for output in agent.process(env, event):
            if isinstance(output, AgentSendText):
                print(f"  Text: {output.text}")
            elif isinstance(output, AgentToolCalled):
                tool_called = True
                tool_args = output.tool_args
                print(f"  [Tool call]: {output.tool_name}")
                print(f"  [Tool args]: {json.dumps(output.tool_args, indent=4)}")
            elif isinstance(output, AgentToolReturned):
                print(f"  [Tool result]: {output.result}")
    except Exception as e:
        error_occurred = True
        print(f"  [ERROR]: {e}")
    finally:
        await agent.cleanup()

    print("\n--- Validation ---")
    if error_occurred:
        print("✗ Test failed: Error occurred during agent run")
        return False
    if not tool_called:
        print("✗ Test failed: Tool was never called")
        return False
    if tool_args is None or "items" not in tool_args or not tool_args["items"]:
        print("✗ Test failed: missing or empty 'items' in tool arguments")
        return False
    for item in tool_args["items"]:
        if "menu_item_id" not in item or "quantity" not in item:
            print("✗ Test failed: item structure invalid")
            return False
    print(f"✓ list[dict] path passed (items: {tool_args['items']})")
    return True


# =============================================================================
# Main
# =============================================================================

MODELS = [
    ("OPENAI_API_KEY", "openai/gpt-5.2"),
    ("OPENAI_API_KEY", "openai/gpt-5.4"),
    ("OPENAI_API_KEY", "openai/gpt-5.4-mini"),
    ("OPENAI_API_KEY", "openai/gpt-5.4-nano"),
    ("OPENAI_API_KEY", "openai/gpt-realtime"),
    ("ANTHROPIC_API_KEY", "anthropic/claude-haiku-4-5"),
    ("GEMINI_API_KEY", "gemini/gemini-2.5-flash"),
    ("GEMINI_API_KEY", "gemini/gemini-3-flash-preview"),
]

# Available test names
AVAILABLE_TESTS = [
    "streaming",  # test_streaming_text
    "introduction",  # test_introduction
    "tools",  # test_tool_calling
    "nested_objects",  # test_nested_objects (TypedDict support)
    "nested_objects_fail",  # test_nested_objects_without_typeddict (strict rejects; opt-out live call)
    "web_search",  # test_web_search
    "web_search_fn",  # test_function_tools_with_web_search
    "mcp",  # test_mcp_list_tools and test_mcp_tool_execution
    "reset",  # test_conversation_reset
]


def parse_args():
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description="Test LlmProvider integration with real API keys.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--tests",
        type=str,
        default="all",
        help=f"Comma-separated tests. Available: {', '.join(AVAILABLE_TESTS)}, all",
    )
    parser.add_argument(
        "--runs",
        type=int,
        default=3,
        help="Number of iterations for eval tests (default: 3)",
    )
    parser.add_argument(
        "--model",
        type=str,
        default=None,
        help="Only test specific model (e.g., 'openai/gpt-5-2')",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug logging",
    )
    return parser.parse_args()


async def main(args):
    print("LLM Provider Integration Test")
    print("=" * 60)

    # Parse which tests to run
    if args.tests == "all":
        tests_to_run = set(AVAILABLE_TESTS)
    else:
        tests_to_run = {t.strip() for t in args.tests.split(",")}
        invalid_tests = tests_to_run - set(AVAILABLE_TESTS)
        if invalid_tests:
            print(f"⚠ Unknown tests: {', '.join(invalid_tests)}")
            print(f"Available tests: {', '.join(AVAILABLE_TESTS)}")
            return 1

    print(f"Tests to run: {', '.join(sorted(tests_to_run))}")
    print(f"Eval iterations: {args.runs}")

    # Find available models
    available = []
    for env_var, model in MODELS:
        if args.model and model != args.model:
            continue
        if os.getenv(env_var):
            available.append((env_var, model))
            print(f"✓ {env_var} found - will test {model}")
        else:
            print(f"✗ {env_var} not set - skipping {model}")

    if not available:
        print("\n⚠ No API keys found. Set at least one of:")
        for env_var, _model in MODELS:
            print(f"  export {env_var}=your-key-here")
        return 1

    failures: list[tuple[str, str, str]] = []  # (model, test_name, error)

    # First, validate all API keys
    print("\n" + "=" * 60)
    print("PHASE 1: Validating API Keys")
    print("=" * 60)

    valid_models = []
    for env_var, model in available:
        api_key = os.environ[env_var]
        if await test_api_key(model, api_key):
            valid_models.append((env_var, model))
        else:
            failures.append((model, "api_key", "API key validation failed"))

    if not valid_models:
        print("\n⚠ No valid API keys. Check your keys and permissions.")

    # Run full tests only for models with valid keys
    if valid_models:
        print("\n" + "=" * 60)
        print("PHASE 2: Running Full Tests")
        print("=" * 60)

    for env_var, model in valid_models:
        api_key = os.environ[env_var]

        test_plan: list[tuple[str, ...]] = []
        if "streaming" in tests_to_run:
            test_plan.append(("streaming", test_streaming_text, model, api_key))
        if "introduction" in tests_to_run:
            test_plan.append(("introduction", test_introduction, model, api_key))
        if "tools" in tests_to_run:
            test_plan.append(("tools", test_tool_calling, model, api_key))
        if "nested_objects" in tests_to_run:
            test_plan.append(("nested_objects", test_nested_objects, model, api_key))
        if "nested_objects_fail" in tests_to_run:
            test_plan.append(("nested_objects_fail", test_nested_objects_without_typeddict, model, api_key))
        if "web_search" in tests_to_run:
            test_plan.append(("web_search", test_web_search, model, api_key))
            test_plan.append(("web_search (high)", test_web_search, model, api_key, "high"))
        if "web_search_fn" in tests_to_run:
            test_plan.append(("web_search_fn", test_function_tools_with_web_search, model, api_key))
        if "mcp" in tests_to_run:
            test_plan.append(("mcp_list_tools", test_mcp_list_tools, model, api_key))
            test_plan.append(("mcp_tool_execution", test_mcp_tool_execution, model, api_key))
        if "reset" in tests_to_run:
            test_plan.append(("reset", test_conversation_reset, model, api_key))

        for test_entry in test_plan:
            test_name, test_fn, *test_args = test_entry
            try:
                await test_fn(*test_args)
            except Exception as e:
                print(f"\n✗ Error in {test_name} for {model}: {e}")
                import traceback

                traceback.print_exc()
                failures.append((model, test_name, str(e)))

    print("\n" + "=" * 60)
    if failures:
        print(f"DONE — {len(failures)} failure(s):")
        for model, test_name, error in failures:
            print(f"  ✗ {model} / {test_name}: {error}")
    else:
        print("All tests passed!")
    print("=" * 60)
    return 1 if failures else 0


if __name__ == "__main__":
    # Parse arguments first (before suppressing output)
    args = parse_args()

    # Suppress noisy warnings from litellm/pydantic
    warnings.filterwarnings("ignore", category=ResourceWarning)
    warnings.filterwarnings("ignore", category=UserWarning, module="pydantic")
    logging.getLogger("asyncio").setLevel(logging.CRITICAL)
    logging.getLogger("LiteLLM").setLevel(logging.CRITICAL)

    # Suppress litellm colored output
    litellm.suppress_debug_info = True

    # Suppress loguru output unless --debug
    if not args.debug:
        logger.disable("line")

    try:
        exit_code = asyncio.run(main(args))
    except KeyboardInterrupt:
        print("\nInterrupted")
        exit_code = 1
    finally:
        # Suppress SSL cleanup errors on exit
        devnull = open(os.devnull, "w")
        sys.stderr = devnull

    sys.exit(exit_code)
