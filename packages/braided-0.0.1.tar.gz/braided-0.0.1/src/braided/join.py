from collections import defaultdict
from typing import Any, Iterator, Sequence

from braided.strand import AnyMapping, ManyToMany


class Join[T: AnyMapping](ManyToMany[T]):
    def __init__(self, join_column: str) -> None:
        self.join_column = join_column

    def __call__(
        self, left: Sequence[AnyMapping], right: Sequence[AnyMapping]
    ) -> Iterator[T]:
        right_by_key: dict[Any, list[AnyMapping]] = defaultdict(list)
        for row in right:
            right_by_key[row[self.join_column]].append(row)

        for left_row in left:
            key = left_row[self.join_column]
            for right_row in right_by_key.get(key, ()):
                yield {**left_row, **right_row}  # type: ignore[misc]


def join(column: str) -> Join[AnyMapping]:
    return Join[AnyMapping](column)
