import os
import pickle
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Iterator, Sequence

from braided.strand import AnyMapping, ManyToMany


class CacheSerializer(ABC):
    @abstractmethod
    def filename(self) -> str: ...

    @abstractmethod
    def dump_stream(self, items: Iterator[Any], path: Path) -> Iterator[Any]: ...

    @abstractmethod
    def load_stream(self, path: Path) -> Iterator[Any]: ...


class PickleSerializer(CacheSerializer):
    def filename(self) -> str:
        return "cache.pkl"

    def dump_stream(self, items: Iterator[Any], path: Path) -> Iterator[Any]:
        with open(path, "wb") as f:
            for item in items:
                pickle.dump(item, f)
                yield item

    def load_stream(self, path: Path) -> Iterator[Any]:
        with open(path, "rb") as f:
            while True:
                try:
                    yield pickle.load(f)
                except EOFError:
                    return


class Cache[T: AnyMapping](ManyToMany[T]):
    def __init__(
        self,
        cache_path: str,
        serializer: CacheSerializer | None = None,
    ) -> None:
        self.cache_path = cache_path
        self.serializer = serializer or PickleSerializer()

    def __call__(self, items: Sequence[T]) -> Iterator[T]:
        root = Path(os.path.expanduser(self.cache_path))
        path = root / self.serializer.filename()
        if path.exists():
            yield from self.serializer.load_stream(path)
            return

        root.mkdir(parents=True, exist_ok=True)
        yield from self.serializer.dump_stream(iter(items), path)
