from __future__ import annotations

import functools
from abc import ABC, abstractmethod
from enum import Enum
from typing import Any, Callable, ClassVar, Iterator, Mapping


class StrandKind(Enum):
    ONE_TO_ONE = "one_to_one"
    ONE_TO_MANY = "one_to_many"
    MANY_TO_MANY = "many_to_many"


type AnyMapping = Mapping[str, Any]

class Strand[T: AnyMapping](ABC):
    kind: ClassVar[StrandKind]

    @classmethod
    def OneToOne(cls) -> type[OneToOne[T]]:
        return OneToOne[T]

    @classmethod
    def OneToMany(cls) -> type[OneToMany[T]]:
        return OneToMany[T]

    @classmethod
    def ManyToMany(cls) -> type[ManyToMany[T]]:
        return ManyToMany[T]

    @abstractmethod
    def __call__(self, *args: Any, **kwargs: Any) -> Any: ...


class OneToOne[T: AnyMapping](Strand[T]):
    kind: ClassVar[StrandKind] = StrandKind.ONE_TO_ONE

    @abstractmethod
    def __call__(self, *args: Any, **kwargs: Any) -> T: ...


class OneToMany[T: AnyMapping](Strand[T]):
    kind: ClassVar[StrandKind] = StrandKind.ONE_TO_MANY

    @abstractmethod
    def __call__(self, *args: Any, **kwargs: Any) -> Iterator[T]: ...


class ManyToMany[T: AnyMapping](Strand[T]):
    kind: ClassVar[StrandKind] = StrandKind.MANY_TO_MANY

    @abstractmethod
    def __call__(self, *args: Any, **kwargs: Any) -> Iterator[T]: ...


class _FunctionOneToOne[T: AnyMapping](OneToOne[T]):
    def __init__(self, func: Callable[..., T]) -> None:
        self._func = func
        functools.update_wrapper(self, func, updated=())

    def __call__(self, *args: Any, **kwargs: Any) -> T:
        return self._func(*args, **kwargs)


class _FunctionOneToMany[T: AnyMapping](OneToMany[T]):
    def __init__(self, func: Callable[..., Iterator[T]]) -> None:
        self._func = func
        functools.update_wrapper(self, func, updated=())

    def __call__(self, *args: Any, **kwargs: Any) -> Iterator[T]:
        return self._func(*args, **kwargs)


class _FunctionManyToMany[T: AnyMapping](ManyToMany[T]):
    def __init__(self, func: Callable[..., Iterator[T]]) -> None:
        self._func = func
        functools.update_wrapper(self, func, updated=())

    def __call__(self, *args: Any, **kwargs: Any) -> Iterator[T]:
        return self._func(*args, **kwargs)


class _StrandDecorator:
    def __call__[T: AnyMapping](self, func: Callable[..., T]) -> OneToOne[T]:
        return _FunctionOneToOne(func)

    @staticmethod
    def one_to_many[T: AnyMapping](func: Callable[..., Iterator[T]]) -> OneToMany[T]:
        return _FunctionOneToMany(func)

    @staticmethod
    def many_to_many[T: AnyMapping](func: Callable[..., Iterator[T]]) -> ManyToMany[T]:
        return _FunctionManyToMany(func)


strand = _StrandDecorator()
