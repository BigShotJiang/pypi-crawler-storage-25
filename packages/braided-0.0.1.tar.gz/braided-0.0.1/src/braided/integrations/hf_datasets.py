# pyright: reportUnknownMemberType=false, reportUnknownVariableType=false, reportUnknownArgumentType=false, reportUnknownLambdaType=false
from pathlib import Path
from typing import Any, Callable, Iterator, Sequence, cast, overload

from datasets import Dataset, load_from_disk

from braided.cache import CacheSerializer
from braided.pipeline import PipelineInput
from braided.strand import AnyMapping


class DatasetInput[T: AnyMapping](PipelineInput[T]):
    def __init__(self, dataset: Dataset) -> None:
        self._ds = dataset

    def __len__(self) -> int:
        return len(self._ds)

    def __iter__(self) -> Iterator[T]:
        for row in self._ds:
            yield row  # type: ignore[misc]

    @overload
    def __getitem__(self, index: int) -> T: ...
    @overload
    def __getitem__(self, index: slice) -> Sequence[T]: ...
    def __getitem__(self, index: int | slice) -> T | Sequence[T]:
        return self._ds[index]  # type: ignore[return-value]


def _materialize(seqs: tuple[Sequence[Any], ...]) -> tuple[Sequence[Any], ...]:
    return tuple(s if isinstance(s, Dataset) else list(s) for s in seqs)


def _hf_map(fn: Callable[..., Any], *seqs: Sequence[Any]) -> Sequence[Any]:
    if len(seqs) == 1 and isinstance(seqs[0], Dataset):
        ds = cast(Dataset, seqs[0])
        return cast(
            Sequence[Any],
            ds.map(lambda row: fn(row), remove_columns=ds.column_names),
        )

    materialized = _materialize(seqs)

    def generate(fn: Any, seqs: tuple[Sequence[Any], ...]) -> Iterator[Any]:
        for aligned in zip(*seqs, strict=True):
            yield fn(*aligned)

    return cast(
        Sequence[Any],
        Dataset.from_generator(
            generate, gen_kwargs={"fn": fn, "seqs": materialized}
        ),
    )


def _hf_flat_map(fn: Callable[..., Any], *seqs: Sequence[Any]) -> Sequence[Any]:
    if len(seqs) == 1 and isinstance(seqs[0], Dataset):
        ds = cast(Dataset, seqs[0])

        def batch_fn(batch: dict[str, list[Any]]) -> dict[str, list[Any]]:
            row = {k: v[0] for k, v in batch.items()}
            out_rows = list(fn(row))
            if not out_rows:
                return {k: [] for k in batch}
            return {k: [r[k] for r in out_rows] for k in out_rows[0]}

        return cast(
            Sequence[Any],
            ds.map(
                batch_fn,
                batched=True,
                batch_size=1,
                remove_columns=ds.column_names,
            ),
        )

    materialized = _materialize(seqs)

    def generate(fn: Any, seqs: tuple[Sequence[Any], ...]) -> Iterator[Any]:
        for aligned in zip(*seqs, strict=True):
            yield from fn(*aligned)

    return cast(
        Sequence[Any],
        Dataset.from_generator(
            generate, gen_kwargs={"fn": fn, "seqs": materialized}
        ),
    )


def _hf_many_to_many(
    fn: Callable[..., Any], *seqs: Sequence[Any]
) -> Sequence[Any]:
    materialized = _materialize(seqs)

    def generate(fn: Any, seqs: tuple[Sequence[Any], ...]) -> Iterator[Any]:
        yield from fn(*seqs)

    return cast(
        Sequence[Any],
        Dataset.from_generator(
            generate, gen_kwargs={"fn": fn, "seqs": materialized}
        ),
    )


def hf_map_funcs() -> dict[str, Callable[..., Sequence[Any]]]:
    return {
        "map": _hf_map,
        "flat_map": _hf_flat_map,
        "many_to_many": _hf_many_to_many,
    }


class HFDatasetSerializer(CacheSerializer):
    def filename(self) -> str:
        return "dataset"

    def dump_stream(self, items: Iterator[Any], path: Path) -> Iterator[Any]:
        items_list = list(items)
        Dataset.from_list(items_list).save_to_disk(str(path))
        yield from items_list

    def load_stream(self, path: Path) -> Iterator[Any]:
        ds = load_from_disk(str(path))
        yield from ds
