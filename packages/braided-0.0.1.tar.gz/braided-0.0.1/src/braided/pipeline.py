from __future__ import annotations

import warnings
from abc import ABC, abstractmethod
from collections.abc import Iterator
from typing import Any, Callable, Sequence, cast, get_args, overload

from braided.spec import Node, NodeSpec, validate_dag
from braided.strand import AnyMapping, StrandKind
from braided.type_check import BraidedTypeWarning, type_check


type MapFn = Callable[..., Sequence[Any]]


class PipelineInput[T: AnyMapping](Sequence[T], ABC):
    @abstractmethod
    def __len__(self) -> int: ...

    @abstractmethod
    def __iter__(self) -> Iterator[T]: ...

    @overload
    def __getitem__(self, index: int) -> T: ...
    @overload
    def __getitem__(self, index: slice) -> Sequence[T]: ...
    @abstractmethod
    def __getitem__(self, index: int | slice) -> T | Sequence[T]: ...


class SequenceInput[T: AnyMapping](PipelineInput[T]):
    def __init__(self, items: Sequence[T]) -> None:
        self._items = items

    def __len__(self) -> int:
        return len(self._items)

    def __iter__(self) -> Iterator[T]:
        return iter(self._items)

    @overload
    def __getitem__(self, index: int) -> T: ...
    @overload
    def __getitem__(self, index: slice) -> Sequence[T]: ...
    def __getitem__(self, index: int | slice) -> T | Sequence[T]:
        return self._items[index]


def _recover_element_type(name: str, inp: PipelineInput[Any]) -> type | None:
    orig_class = getattr(inp, "__orig_class__", None)
    if orig_class is None:
        warnings.warn(
            f"Input '{name}': PipelineInput instance is not parameterized "
            f"(use e.g. SequenceInput[IntDict](...)); skipping type check.",
            BraidedTypeWarning,
            stacklevel=3,
        )
        return None
    args = get_args(orig_class)
    if not args:
        return None
    return args[0]


class LazySequence[T](Sequence[T]):
    def __init__(self, producer: Callable[[], Sequence[T]]) -> None:
        self._producer = producer
        self._materialized: Sequence[T] | None = None

    def _resolve(self) -> Sequence[T]:
        if self._materialized is None:
            self._materialized = self._producer()
        return self._materialized

    def __len__(self) -> int:
        return len(self._resolve())

    def __iter__(self) -> Iterator[T]:
        return iter(self._resolve())

    @overload
    def __getitem__(self, index: int) -> T: ...
    @overload
    def __getitem__(self, index: slice) -> Sequence[T]: ...
    def __getitem__(self, index: int | slice) -> T | Sequence[T]:
        return self._resolve()[index]


def _default_map(fn: Callable[..., Any], *seqs: Sequence[Any]) -> Sequence[Any]:
    return [fn(*items) for items in zip(*seqs, strict=True)]


def _default_flat_map(
    fn: Callable[..., Any], *seqs: Sequence[Any]
) -> Sequence[Any]:
    out: list[Any] = []
    for items in zip(*seqs, strict=True):
        out.extend(fn(*items))
    return out


def _default_many_to_many(
    fn: Callable[..., Any], *seqs: Sequence[Any]
) -> Sequence[Any]:
    return list(fn(*seqs))


def execute_pipeline[OutT: AnyMapping](
    nodes: NodeSpec[OutT],
    inputs: dict[str, PipelineInput[Any]],
    *,
    map: MapFn | None = None,
    flat_map: MapFn | None = None,
    many_to_many: MapFn | None = None,
) -> Sequence[OutT]:
    input_specs: dict[str, type] = {}
    for name, seq in inputs.items():
        elem = _recover_element_type(name, seq)
        if elem is not None:
            input_specs[name] = elem

    validate_dag(nodes, {name: object for name in inputs})
    type_check(nodes, input_specs)

    map_fn = map or _default_map
    flat_map_fn = flat_map or _default_flat_map
    m2m_fn = many_to_many or _default_many_to_many

    cache: dict[str, Sequence[Any]] = {}

    def lazy_for(name: str) -> LazySequence[Any]:
        return LazySequence(lambda: resolve(name))

    def resolve(name: str) -> Sequence[Any]:
        if name in inputs:
            return inputs[name]
        if name in cache:
            return cache[name]

        node = cast(Node[Any], nodes[name])
        strand_obj = node["function"]
        arg_seqs: list[Sequence[Any]] = [lazy_for(arg) for arg in node["args"]]

        match strand_obj.kind:
            case StrandKind.ONE_TO_ONE:
                _check_aligned_lengths(name, node["args"], arg_seqs)
                result = map_fn(strand_obj, *arg_seqs)
            case StrandKind.ONE_TO_MANY:
                _check_aligned_lengths(name, node["args"], arg_seqs)
                result = flat_map_fn(strand_obj, *arg_seqs)
            case StrandKind.MANY_TO_MANY:
                result = m2m_fn(strand_obj, *arg_seqs)

        cache[name] = result
        return result

    return resolve("out")


def _check_aligned_lengths(
    name: str, args: Sequence[str], seqs: Sequence[Sequence[Any]]
) -> None:
    if len(seqs) <= 1:
        return
    lengths = [len(s) for s in seqs]
    if len(set(lengths)) > 1:
        details = ", ".join(f"{arg}={length}" for arg, length in zip(args, lengths))
        warnings.warn(
            f"Node '{name}': aligned inputs have mismatched lengths ({details}).",
            UserWarning,
            stacklevel=3,
        )
