from __future__ import annotations

import collections.abc
import inspect
import typing
import warnings
from dataclasses import dataclass
from typing import Any, TypeAliasType, TypeVar, get_args, get_origin, get_type_hints

from braided.spec import NodeSpec
from braided.strand import AnyMapping, ManyToMany, OneToMany, OneToOne, Strand


class BraidedTypeWarning(UserWarning):
    pass


@dataclass
class StrandSignature:
    param_element_types: list[type]
    return_element_type: type


@dataclass
class _CallableInfo:
    target: Any
    hints: dict[str, Any]
    has_variadic: bool


def _resolve_callable_info(strand_obj: Strand[Any]) -> _CallableInfo:
    wrapped = getattr(strand_obj, "__wrapped__", None)
    target = wrapped if wrapped is not None else strand_obj.__call__
    hints = get_type_hints(target, include_extras=True)
    try:
        sig = inspect.signature(target)
        has_variadic = any(
            p.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD)
            for p in sig.parameters.values()
        )
    except (TypeError, ValueError):
        has_variadic = False
    return _CallableInfo(target=target, hints=hints, has_variadic=has_variadic)


_ITERATOR_ORIGINS = {
    collections.abc.Iterator,
    collections.abc.Generator,
    collections.abc.Iterable,
}
_SEQUENCE_ORIGINS = {collections.abc.Sequence, list}


def _unwrap_iterator(tp: Any) -> Any | None:
    origin = get_origin(tp)
    if origin in _ITERATOR_ORIGINS:
        args = get_args(tp)
        return args[0] if args else None
    return None


def _unwrap_sequence(tp: Any) -> Any | None:
    origin = get_origin(tp)
    if origin in _SEQUENCE_ORIGINS:
        args = get_args(tp)
        return args[0] if args else None
    return None


def _element_return_type(
    name: str, strand_obj: Strand[Any], return_type: Any
) -> Any | None:
    if isinstance(strand_obj, OneToOne):
        return return_type
    unwrapped = _unwrap_iterator(return_type)
    if unwrapped is None:
        kind_label = (
            "one-to-many" if isinstance(strand_obj, OneToMany) else "many-to-many"
        )
        warnings.warn(
            f"Node '{name}': {kind_label} strand must return Iterator[...]; "
            f"got {return_type!r}.",
            BraidedTypeWarning,
            stacklevel=4,
        )
        return None
    return unwrapped


def _param_element_types(
    name: str, strand_obj: Strand[Any], param_types: list[Any]
) -> list[type] | None:
    if not isinstance(strand_obj, ManyToMany):
        return param_types

    elems: list[type] = []
    for p in param_types:
        unwrapped = _unwrap_sequence(p)
        if unwrapped is None:
            warnings.warn(
                f"Node '{name}': many-to-many parameter must be Sequence[...]; "
                f"got {p!r}.",
                BraidedTypeWarning,
                stacklevel=4,
            )
            return None
        elems.append(unwrapped)
    return elems


def _introspect(name: str, strand_obj: Strand[Any]) -> StrandSignature | None:
    try:
        info = _resolve_callable_info(strand_obj)
    except Exception as exc:
        warnings.warn(
            f"Node '{name}': could not introspect type hints ({exc}).",
            BraidedTypeWarning,
            stacklevel=3,
        )
        return None

    if info.has_variadic:
        return None

    if "return" not in info.hints:
        warnings.warn(
            f"Node '{name}': missing return annotation.",
            BraidedTypeWarning,
            stacklevel=3,
        )
        return None

    return_elem = _element_return_type(name, strand_obj, info.hints["return"])
    if return_elem is None:
        return None

    raw_params = [info.hints[p] for p in info.hints if p != "return"]
    param_elems = _param_element_types(name, strand_obj, raw_params)
    if param_elems is None:
        return None

    return StrandSignature(param_elems, return_elem)


def _is_jaxtyping_array(tp: Any) -> bool:
    try:
        import jaxtyping  # pyright: ignore[reportMissingImports]
    except ImportError:
        return False
    return isinstance(tp, type) and issubclass(tp, jaxtyping.AbstractArray)  # pyright: ignore[reportUnknownMemberType,reportUnknownArgumentType]


def _compatible_jaxtyping(producer: Any, consumer: Any) -> bool:
    import jaxtyping  # pyright: ignore[reportMissingImports]

    if not (
        isinstance(producer, type)
        and isinstance(consumer, type)
        and issubclass(producer, jaxtyping.AbstractArray)  # pyright: ignore[reportUnknownMemberType,reportUnknownArgumentType]
        and issubclass(consumer, jaxtyping.AbstractArray)  # pyright: ignore[reportUnknownMemberType,reportUnknownArgumentType]
    ):
        return False
    if producer.array_type is not consumer.array_type:  # pyright: ignore[reportUnknownMemberType]
        return False
    if producer.dtypes != consumer.dtypes:  # pyright: ignore[reportUnknownMemberType]
        return False
    return len(producer.dim_str) == len(consumer.dim_str)  # pyright: ignore[reportUnknownMemberType,reportUnknownArgumentType]


def _is_typeddict(tp: Any) -> bool:
    return isinstance(tp, type) and typing.is_typeddict(tp)


def _typeddict_compatible(producer: Any, consumer: Any) -> bool:
    producer_hints = get_type_hints(producer)
    consumer_hints = get_type_hints(consumer)
    for key, consumer_tp in consumer_hints.items():
        if key not in producer_hints:
            return False
        if not _is_subtype(producer_hints[key], consumer_tp):
            return False
    return True


def _typeddict_fits_mapping(producer: Any, consumer: Any) -> bool:
    c_args = get_args(consumer)
    if len(c_args) != 2:
        return False
    key_tp, value_tp = c_args
    if not _is_subtype(str, key_tp):
        return False
    for tp in get_type_hints(producer).values():
        if not _is_subtype(tp, value_tp):
            return False
    return True


def _unwrap_alias(tp: Any) -> Any:
    if isinstance(tp, TypeAliasType):
        return tp.__value__
    return tp


def _is_subtype(producer: Any, consumer: Any) -> bool:
    producer = _unwrap_alias(producer)
    consumer = _unwrap_alias(consumer)

    if producer == consumer:
        return True
    if consumer is Any:
        return True
    # Unresolved class-level TypeVars leak through get_type_hints when a
    # built-in strand (e.g. Join, Cache) types its signature with its own
    # class's T. Treating them permissively avoids false positives; real type
    # mismatches are still caught between concrete types.
    if isinstance(consumer, TypeVar) or isinstance(producer, TypeVar):
        return True

    p_origin = get_origin(producer)
    c_origin = get_origin(consumer)
    if p_origin is not None and c_origin is not None and p_origin is c_origin:
        p_args = get_args(producer)
        c_args = get_args(consumer)
        if len(p_args) == len(c_args):
            return all(_is_subtype(pa, ca) for pa, ca in zip(p_args, c_args))

    if _is_typeddict(producer) and _is_typeddict(consumer):
        return _typeddict_compatible(producer, consumer)

    if _is_typeddict(producer) and c_origin is collections.abc.Mapping:
        return _typeddict_fits_mapping(producer, consumer)

    if _is_jaxtyping_array(producer) and _is_jaxtyping_array(consumer):
        return _compatible_jaxtyping(producer, consumer)

    return False


def _get_producer_element_type(
    arg: str,
    input_specs: dict[str, type],
    introspected: dict[str, StrandSignature | None],
) -> Any | None:
    if arg in input_specs:
        return input_specs[arg]
    sig = introspected.get(arg)
    return sig.return_element_type if sig is not None else None


def type_check[OutT: AnyMapping](
    nodes: NodeSpec[OutT], input_specs: dict[str, type]
) -> None:
    introspected: dict[str, StrandSignature | None] = {
        name: _introspect(name, node["function"])
        for name, node in nodes.items()
    }

    for consumer_name, node in nodes.items():
        sig = introspected[consumer_name]
        if sig is None:
            continue

        args = node["args"]
        param_types = sig.param_element_types
        if len(param_types) != len(args):
            warnings.warn(
                f"Node '{consumer_name}': function takes {len(param_types)} "
                f"parameter(s) but node declares {len(args)} arg(s).",
                BraidedTypeWarning,
                stacklevel=2,
            )
            continue

        for arg, expected in zip(args, param_types):
            producer_type = _get_producer_element_type(arg, input_specs, introspected)
            if producer_type is None:
                continue
            if not _is_subtype(producer_type, expected):
                warnings.warn(
                    f"Node '{consumer_name}': arg '{arg}' has element type "
                    f"{producer_type!r}, which is not compatible with expected "
                    f"parameter type {expected!r}.",
                    BraidedTypeWarning,
                    stacklevel=2,
                )
