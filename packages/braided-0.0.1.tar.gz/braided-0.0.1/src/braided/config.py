# pyright: reportUnknownMemberType=false, reportUnknownVariableType=false, reportUnknownArgumentType=false
import json
from pathlib import Path
from typing import Any, Callable, Sequence, cast

import yaml
from jsonargparse import ArgumentParser

from braided.pipeline import MapFn, PipelineInput, execute_pipeline
from braided.spec import Node, NodeSpec
from braided.strand import AnyMapping, Strand


class ConfigError(ValueError):
    pass


def execute_pipeline_from_config(
    path: str,
    *,
    map: MapFn | None = None,
    flat_map: MapFn | None = None,
    many_to_many: MapFn | None = None,
) -> Sequence[AnyMapping]:
    nodes, inputs = load_config(path)
    return execute_pipeline(
        nodes, inputs, map=map, flat_map=flat_map, many_to_many=many_to_many
    )


def load_config(
    path: str,
) -> tuple[NodeSpec[Any], dict[str, PipelineInput[Any]]]:
    raw = _read_file(path)
    if not isinstance(raw, dict):
        raise ConfigError(f"Config at '{path}' must be a mapping.")
    return resolve_pipeline(raw.get("nodes", {}), raw.get("inputs", {}))


def resolve_pipeline(
    nodes_raw: dict[str, Any],
    inputs_raw: dict[str, Any],
) -> tuple[NodeSpec[Any], dict[str, PipelineInput[Any]]]:
    nodes: NodeSpec[Any] = {
        name: _resolve_node(name, node_raw)  # type: ignore[misc]
        for name, node_raw in nodes_raw.items()
    }
    inputs: dict[str, PipelineInput[Any]] = {
        name: _resolve_input(input_raw)
        for name, input_raw in inputs_raw.items()
    }
    return nodes, inputs


def _read_file(path: str) -> Any:
    text = Path(path).read_text()
    if path.endswith(".json"):
        return json.loads(text)
    return yaml.safe_load(text)


def _resolve_node(name: str, raw: dict[str, Any]) -> Node[Any]:
    parser = ArgumentParser()
    parser.add_argument("--function", type=Callable)
    parser.add_argument("--args", type=list[str])
    cfg = parser.parse_object(raw)
    cfg = parser.instantiate_classes(cfg)

    fn = cfg.function
    if not isinstance(fn, Strand):
        raise ConfigError(
            f"Node '{name}': function must resolve to a Strand instance; "
            f"got {type(fn).__name__}."
        )
    return Node(function=cast(Strand[Any], fn), args=list(cfg.args))


def _resolve_input(raw: dict[str, Any]) -> PipelineInput[Any]:
    parser = ArgumentParser()
    parser.add_subclass_arguments(PipelineInput, "input", fail_untyped=False)
    cfg = parser.parse_object({"input": raw})
    cfg = parser.instantiate_classes(cfg)
    return cast(PipelineInput[Any], cfg.input)
