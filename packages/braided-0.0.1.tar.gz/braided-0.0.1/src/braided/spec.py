from typing import Any, cast

from typing_extensions import TypedDict

from braided.strand import AnyMapping, Strand


class Node[T: AnyMapping](TypedDict):
    function: Strand[T]
    args: list[str]


class NodeSpec[OutT: AnyMapping](TypedDict, extra_items=Node[Any]):
    out: Node[OutT]


class DagValidationError(ValueError):
    pass


def validate_dag[OutT: AnyMapping](
    nodes: NodeSpec[OutT], input_specs: dict[str, type]
) -> None:
    node_keys = set(nodes.keys())
    input_keys = set(input_specs.keys())
    overlap = node_keys & input_keys
    if overlap:
        raise DagValidationError(
            f"Node keys overlap with input keys: {sorted(overlap)}"
        )

    for name, raw_node in nodes.items():
        node = cast(Node[Any], raw_node)
        for arg in node["args"]:
            if arg not in node_keys and arg not in input_keys:
                raise DagValidationError(
                    f"Node '{name}' references unknown arg '{arg}'."
                )

    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(name: str) -> None:
        if name in visited or name in input_keys:
            return
        if name in visiting:
            raise DagValidationError(f"Cycle detected involving node '{name}'.")
        visiting.add(name)
        for arg in cast(Node[Any], nodes[name])["args"]:
            visit(arg)
        visiting.remove(name)
        visited.add(name)

    for name in nodes:
        visit(name)
