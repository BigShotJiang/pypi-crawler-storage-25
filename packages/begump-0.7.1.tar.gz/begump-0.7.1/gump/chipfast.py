"""CHIPFAST — Gate placement via coupling."""
import numpy as np

def place(gates, connections, grid_size=None):
    """Place gates using force-directed layout."""
    n = len(gates)
    if n < 2: return {'error':'Need >= 2 gates'}
    if grid_size is None: side = int(np.ceil(np.sqrt(n))); grid_size = (side, side)
    pos = np.random.RandomState(42).uniform(0, grid_size[0], (n, 2))
    for _ in range(200):
        forces = np.zeros((n, 2))
        for i in range(n):
            for j in range(i+1, n):
                d = pos[i]-pos[j]; dist = np.sqrt(np.sum(d**2))+0.01
                f = 2.0/dist**2; forces[i] += d/dist*f; forces[j] -= d/dist*f
        for a,b in connections:
            if a>=n or b>=n: continue
            d = pos[b]-pos[a]; dist = np.sqrt(np.sum(d**2))+0.01
            f = dist*0.1; forces[a] += d/dist*f; forces[b] -= d/dist*f
        pos += forces*0.1; pos = np.clip(pos, 0, grid_size[0])
    wl = sum(np.sqrt(np.sum((pos[a]-pos[b])**2)) for a,b in connections if a<n and b<n)
    aw = wl/max(1,len(connections))
    return {'positions':{gates[i]:(round(float(pos[i,0]),2),round(float(pos[i,1]),2)) for i in range(n)},
            'total_wire':round(float(wl),2),'K_compactness':round(float(1/(1+aw)),4),'n_gates':n}
