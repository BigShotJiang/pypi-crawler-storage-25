"""
CORE — K/R/E/T measurement for any data.
==========================================
from gump.core import k_measure
result = k_measure([1, 2, 3, 2, 1, 2, 3])
"""
import numpy as np

KT_LN2 = 2.87e-21


def k_measure(data, sample_rate=1.0):
    """Measure K, R, E, T for any time series.

    K = coupling (autocorrelation at lag 1)
    R = synchronization (spectral coherence)
    E = energy (information content in bits)
    T = tension (K - R)
    """
    x = np.asarray(data, dtype=np.float64).ravel()
    n = len(x)
    if n < 3:
        return {'K': 0, 'R': 0, 'E': 0, 'T': 0, 'n': n}

    mu, sigma = np.mean(x), np.std(x)
    if sigma < 1e-15:
        return {'K': 1, 'R': 1, 'E': 0, 'T': 0, 'n': n, 'verdict': 'CONSTANT'}
    xn = (x - mu) / sigma

    K = float(abs(np.corrcoef(xn[:-1], xn[1:])[0, 1]))
    K = max(0, min(1, K))

    fft = np.abs(np.fft.rfft(xn)[1:]) ** 2
    if len(fft) > 0 and np.sum(fft) > 0:
        p = fft / np.sum(fft)
        H = -np.sum(p * np.log2(p + 1e-15))
        H_max = np.log2(len(p))
        R = float(max(0, min(1, 1 - H / H_max))) if H_max > 0 else 0
    else:
        R = 0

    hist, _ = np.histogram(xn, bins=min(50, max(3, n // 3)), density=True)
    hist = hist[hist > 0]
    E_bits = float(abs(-np.sum(hist * np.log2(hist + 1e-15)) * (xn.max() - xn.min()) / len(hist)))

    T = max(0, K - R)

    if K > 0.8 and R > 0.6:
        verdict = 'COUPLED'
    elif K > 0.5:
        verdict = 'PARTIAL'
    elif K < 0.1:
        verdict = 'RANDOM'
    else:
        verdict = 'WEAK'

    return {'K': round(K, 4), 'R': round(R, 4), 'E_bits': round(E_bits, 4),
            'T': round(T, 4), 'n': n, 'verdict': verdict}


from math import sqrt

# Constants needed by other modules
PHI = (1 + 5 ** 0.5) / 2
K_CEILING = 1.868
LANDAUER_PER_BIT = 2.87e-21


class EnergyTracker:
    """Track energy cost of computation in Landauer bits."""
    def __init__(self):
        self.bits_erased = 0
        self.operations = 0
    def erase(self, n_bits=1):
        self.bits_erased += n_bits
        self.operations += 1
    def cost_joules(self, T=300):
        return self.bits_erased * LANDAUER_PER_BIT
    def summary(self):
        return {'bits_erased': self.bits_erased, 'operations': self.operations,
                'joules': self.cost_joules()}


def tensions(data, top_k=10):
    """Find tensions in a dataset (what wants to couple but hasn't)."""
    x = np.asarray(data, dtype=np.float64)
    if x.ndim == 1:
        x = x.reshape(-1, 1)
    n = len(x)
    edges = [(i, j) for i in range(n) for j in range(i+1, n)
             if np.linalg.norm(x[i] - x[j]) < np.std(x) * 2]
    td = _TensionDetector(n, edges)
    return td.tensions(top_k)


def redundancies(data, top_k=10):
    """Find redundancies (what's coupled but shouldn't be)."""
    x = np.asarray(data, dtype=np.float64)
    if x.ndim == 1:
        x = x.reshape(-1, 1)
    n = len(x)
    edges = [(i, j) for i in range(n) for j in range(i+1, n)
             if np.linalg.norm(x[i] - x[j]) < np.std(x) * 2]
    td = _TensionDetector(n, edges)
    return td.redundancies(top_k)


def place(nodes, edges, weights=None):
    """Spectral placement of nodes."""
    td = _TensionDetector(len(nodes), edges, weights)
    return td.coords.tolist()


def clusters(data, k=None):
    """Find clusters via spectral decomposition."""
    x = np.asarray(data, dtype=np.float64)
    if x.ndim == 1:
        x = x.reshape(-1, 1)
    n = len(x)
    edges = [(i, j) for i in range(n) for j in range(i+1, n)
             if np.linalg.norm(x[i] - x[j]) < np.std(x)]
    td = _TensionDetector(n, edges)
    return td.clusters(k)


def resolution_path(data, node_i, top_k=10):
    """Find resolution path from a node."""
    x = np.asarray(data, dtype=np.float64)
    if x.ndim == 1:
        x = x.reshape(-1, 1)
    n = len(x)
    edges = [(i, j) for i in range(n) for j in range(i+1, n)
             if np.linalg.norm(x[i] - x[j]) < np.std(x) * 2]
    td = _TensionDetector(n, edges)
    return td.resolution_path(node_i, top_k)


def interval_cost(interval_ratio):
    """Landauer cost of a musical interval."""
    if interval_ratio <= 0:
        return float('inf')
    return abs(np.log2(interval_ratio)) * LANDAUER_PER_BIT


def coupling_energy(K, R, n):
    """Energy of a coupled system."""
    return K * R * n * LANDAUER_PER_BIT


def detect_crash(data, window=50, threshold=0.8):
    """Detect crash conditions (R exceeds threshold)."""
    x = np.asarray(data, dtype=np.float64)
    warnings = []
    for i in range(window, len(x)):
        chunk = x[i-window:i]
        r = k_measure(chunk)
        if r['R'] > threshold:
            warnings.append({'position': i, 'R': r['R'], 'K': r['K']})
    return warnings


def watch_training(train_loss, test_loss, window=20):
    """Watch training for grokking."""
    from gump.aitrainer import detect_grokking
    return detect_grokking(train_loss, test_loss, window)

class _TensionDetector:
    """Spectral tension detection via Laplacian eigenvectors."""

    def __init__(self, n, edges, weights=None, n_vecs=8, seed=42):
        self.n = n
        self.edges = edges
        self.edge_set = set()
        for i, j in edges:
            self.edge_set.add((min(i, j), max(i, j)))

        ci = np.array([e[0] for e in edges], dtype=int)
        cj = np.array([e[1] for e in edges], dtype=int)
        w = np.array(weights, dtype=float) if weights is not None else np.ones(len(edges))

        if len(edges) == 0 or n < 3:
            self.coords = np.random.RandomState(seed).randn(n, max(1, n_vecs)) * 0.01
            return

        # Build sparse Laplacian and compute eigenvectors
        try:
            from scipy.sparse import csr_matrix
            from scipy.sparse.linalg import lobpcg
            import warnings
            warnings.filterwarnings('ignore')

            data = np.concatenate([w, w])
            row = np.concatenate([ci, cj])
            col = np.concatenate([cj, ci])
            A = csr_matrix((data, (row, col)), shape=(n, n))
            degree = np.array(A.sum(axis=1)).ravel()
            D = csr_matrix((degree, (np.arange(n), np.arange(n))), shape=(n, n))
            L = D - A

            k = min(n_vecs + 1, n - 1)
            rng = np.random.RandomState(seed)
            X0 = rng.randn(n, k)
            M_diag = 1.0 / np.maximum(degree, 1.0)
            M = csr_matrix((M_diag, (np.arange(n), np.arange(n))), shape=(n, n))

            eigenvalues, eigenvectors = lobpcg(L, X0, M=M, tol=1e-3,
                                                maxiter=60, largest=False,
                                                verbosityLevel=0)
            order = np.argsort(eigenvalues)
            self.coords = eigenvectors[:, order[1:]]
            self.eigenvalues = eigenvalues[order]
        except ImportError:
            # Fallback: power iteration (no scipy needed)
            degree = np.zeros(n)
            np.add.at(degree, ci, w)
            np.add.at(degree, cj, w)
            d_max = np.max(degree) + 1

            def shifted_mul(v):
                result = d_max * v - degree * v
                np.add.at(result, ci, w * v[cj])
                np.add.at(result, cj, w * v[ci])
                return result

            vecs = []
            rng = np.random.RandomState(seed)
            v0 = np.ones(n) / sqrt(n)
            vecs.append(v0)

            for _ in range(min(n_vecs, n - 1)):
                v = rng.randn(n)
                for prev in vecs:
                    v -= np.dot(v, prev) * prev
                v /= np.linalg.norm(v)
                for _ in range(60):
                    v = shifted_mul(v)
                    for prev in vecs:
                        v -= np.dot(v, prev) * prev
                    nm = np.linalg.norm(v)
                    if nm > 1e-10:
                        v /= nm
                vecs.append(v)

            self.coords = np.column_stack(vecs[1:]) if len(vecs) > 1 else np.zeros((n, 1))
            self.eigenvalues = None

    def _dist(self, i, j):
        return float(np.linalg.norm(self.coords[i] - self.coords[j]))

    def tensions(self, top_k=20):
        results = []
        for i in range(self.n):
            dists = np.linalg.norm(self.coords - self.coords[i], axis=1)
            nearest = np.argsort(dists)
            for j in nearest[1:min(50, self.n)]:
                if j <= i:
                    continue
                pair = (min(i, j), max(i, j))
                if pair not in self.edge_set:
                    d = float(dists[j])
                    if d > 0:
                        results.append((d, int(i), int(j), 1.0 / d))
        results.sort()
        return results[:top_k]

    def redundancies(self, top_k=20):
        results = []
        for i, j in self.edges:
            results.append((self._dist(i, j), int(i), int(j)))
        results.sort(reverse=True)
        return results[:top_k]

    def clusters(self, k=None):
        if self.eigenvalues is not None and k is None:
            gaps = np.diff(self.eigenvalues[1:])
            k = int(np.argmax(gaps)) + 2 if len(gaps) > 0 else 2
        if k is None:
            k = 2
        from scipy.cluster.vq import kmeans2
        coords = self.coords[:, :min(k, self.coords.shape[1])]
        _, labels = kmeans2(coords, k, minit='points')
        return labels, k

    def resolution_path(self, node_i, top_k=10):
        dists = np.linalg.norm(self.coords - self.coords[node_i], axis=1)
        order = np.argsort(dists)
        path = []
        for j in order[1:]:
            pair = (min(node_i, j), max(node_i, j))
            path.append({
                'node': int(j),
                'distance': float(dists[j]),
                'connected': pair in self.edge_set,
                'tension': pair not in self.edge_set,
            })
            if len(path) >= top_k:
                break
        return path


# ═══ PUBLIC API ═══
