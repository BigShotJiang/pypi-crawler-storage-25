"""SENSOR — K/R/E/T for time series with windowed analysis."""
import numpy as np
from gump.core import k_measure

def measure_kret(data, sample_rate=1.0):
    """Measure K/R/E/T for a time series."""
    return k_measure(data, sample_rate)

def scan(data, window=100, step=None):
    """Sliding window K/R/E/T scan."""
    x = np.asarray(data, dtype=np.float64).ravel()
    if step is None: step = max(1, window // 4)
    return [dict(k_measure(x[i:i+window]), position=i) for i in range(0, len(x)-window+1, step)]

def detect_regime_change(data, window=100, threshold=0.3):
    """Find where K changes significantly."""
    tl = scan(data, window)
    return [{'position': tl[i]['position'], 'delta_K': round(abs(tl[i]['K']-tl[i-1]['K']),4)}
            for i in range(1, len(tl)) if abs(tl[i]['K']-tl[i-1]['K']) > threshold]
