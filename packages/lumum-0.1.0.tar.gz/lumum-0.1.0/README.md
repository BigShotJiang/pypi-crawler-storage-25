# lumum

A unified shell for running local LLM inference across multiple engines.

On **macOS 26+ with Apple Silicon**, lumum works out of the box — no model downloads, no setup — using the built-in Apple Intelligence model via the `FoundationModels` framework.

lumum provides a single interactive CLI that wraps Apple Intelligence, Ollama, MLX, and other local inference backends behind a common interface. Switch between engines and models with a single command.

## Install

**One command, no install** (requires [uv](https://docs.astral.sh/uv/)):

```bash
uvx lumum
```

**Install permanently** so you can just run `lumum`:

```bash
uv tool install lumum
lumum
```

To uninstall: `uv tool uninstall lumum`

## Development setup

```bash
git clone https://github.com/rosh-studio/lumum
cd lumum
uv sync
uv run lumum
```

## Requirements

- [uv](https://docs.astral.sh/uv/) — Python package manager
- At least one inference engine installed:
  - **Apple Intelligence** — zero setup on macOS 26+ with Apple Silicon (auto-detected)
  - [Ollama](https://ollama.com) — easiest cross-platform option
  - [MLX](https://github.com/ml-explore/mlx-lm) — Apple Silicon optimized (`uv sync --extra mlx`)

## Usage

### Interactive shell

```
$ lumum

  lumum v0.1.0
  Engines: ollama (ready), mlx (not available)
  No model loaded — use /use engine:model

lumum [no model]> /use ollama:llama3.2:1b
Loading ollama:llama3.2:1b...
Ready.

lumum [ollama:llama3.2:1b]> Hello!
Hi there! How can I help you today?
```

### One-shot mode

```bash
lumum -m ollama:llama3.2:1b -c "Explain quicksort in one sentence"
```

### CLI commands

```bash
lumum                          # interactive shell
lumum -m ollama:llama3.2       # start with a model loaded
lumum -c "prompt"              # one-shot (requires -m)
lumum engines                  # list available engines
lumum models                   # list available models
```

### Shell commands

| Command              | Description                |
|----------------------|----------------------------|
| `/use engine:model`  | Load a model               |
| `/engines`           | List engines and status    |
| `/models`            | List available models      |
| `/history`           | Show conversation history  |
| `/clear`             | Clear conversation         |
| `/help`              | Show help                  |
| `/quit`              | Exit                       |

## Engines

| Engine  | Status      | Platform        | Notes                                          |
|---------|-------------|-----------------|------------------------------------------------|
| Apple   | Working     | macOS 26+ / AS  | Built-in Apple Intelligence, no setup needed   |
| Ollama  | Working     | macOS/Linux/Win | Requires `ollama` installed and running        |
| MLX     | Scaffolded  | Apple Silicon   | `uv sync --extra mlx`                          |
| BitNet  | Planned     | macOS/Linux     | 1-bit LLM inference                            |

Engines degrade gracefully — lumum auto-detects what's available at startup and skips engines that aren't installed or supported on the current platform.

## Architecture

```
src/lumum/
├── __main__.py          # entry point
├── cli.py               # argument parsing
├── shell.py             # interactive REPL
├── config.py            # settings (TOML)
└── engine/
    ├── base.py          # abstract Engine interface
    ├── apple.py         # Apple Intelligence (FoundationModels, macOS 26+)
    ├── ollama.py        # Ollama backend
    └── mlx.py           # MLX backend
```

All engines implement a common async interface — `generate()` returns an `AsyncIterator[str]` for streaming tokens. Adding a new engine means implementing one class with five methods.

## Configuration

Optional config file at `~/.config/lumum/config.toml`:

```toml
[default]
engine = "ollama"
model = "llama3.2:1b"

[engines.ollama]
host = "http://localhost:11434"

[engines.bitnet]
path = "~/dev/lumum/engine/bitnet"
```

## License

MIT
