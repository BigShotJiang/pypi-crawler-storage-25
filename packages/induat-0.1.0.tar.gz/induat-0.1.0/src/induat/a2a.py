"""Agent2Agent (A2A) protocol surface for induat.

Lets external agents call induat over HTTP without installing it or
running the CLI. They:

  1. Discover induat via the Agent Card at ``/.well-known/agent.json``.
  2. Send a JSON-RPC ``message/send`` request to ``/a2a`` with a
     ``data`` part describing the stack to measure (and optional
     custom probes).
  3. Receive a completed Task whose artifact contains the full
     ``ReliabilityReport`` as a structured JSON payload.

Spec reference: https://google-a2a.github.io/A2A/

The implementation here is intentionally minimal — just enough to be
A2A-compatible for a single ``measure`` skill. Streaming, push
notifications, and stateful task history are advertised as unsupported
in the Agent Card (``capabilities.streaming = false`` etc.) so clients
won't try to use them.
"""
from __future__ import annotations

import logging
import uuid
from typing import Any

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

from induat import __version__
from induat.plugins import context as context_pkg
from induat.plugins import search as search_pkg
from induat.reports import ReliabilityReport
from induat.runner import StackConfig, run_gauntlet
from induat.tasks import (
    CURATED_TASK_IDS,
    DEMO_TASKS,
    Task,
    gate_for_category,
    get_aver_tasks,
    get_curated_aver_tasks,
)

# Back-compat: integration probes were previously a separate list; now
# they live inside DEMO_TASKS. Anywhere this module references the old
# name, point it at the unified pack.
INTEGRATION_DEMO_TASKS = []  # noqa: F811 — kept for A2A back-compat

log = logging.getLogger("induat.a2a")

router = APIRouter()


# ─────────────────────────── Agent Card

def build_agent_card(public_base_url: str | None = None) -> dict[str, Any]:
    """Build the AgentCard dict served at /.well-known/agent.json.

    ``public_base_url`` overrides the URL advertised to clients — useful
    when induat sits behind a reverse proxy. If None, clients should
    POST back to whatever host they used to fetch the card.
    """
    url = (public_base_url.rstrip("/") + "/a2a") if public_base_url else "/a2a"
    return {
        "name": "induat",
        "description": (
            "Pre-production reliability test suite for AI agents. "
            "Measures detection, diagnosis, and recovery on a curated "
            "library of failure-mode probes; returns a structured "
            "ReliabilityReport with a production-readiness verdict."
        ),
        "url": url,
        "version": __version__,
        "provider": {"organization": "induat", "url": "https://induat.com"},
        "capabilities": {
            "streaming": False,
            "pushNotifications": False,
            "stateTransitionHistory": False,
        },
        "defaultInputModes": ["application/json", "text/plain"],
        "defaultOutputModes": ["application/json"],
        "skills": [
            {
                "id": "measure",
                "name": "Measure agent reliability",
                "description": (
                    "Run the gauntlet against a described agent stack "
                    "and return a ReliabilityReport with capability + "
                    "self-awareness scores, per-dimension breakdown, "
                    "and a production-readiness verdict."
                ),
                "tags": ["evaluation", "reliability", "benchmark", "aver"],
                "inputModes": ["application/json"],
                "outputModes": ["application/json"],
                "examples": [
                    "Measure gemini-2.5-flash on the curated 12-task pack.",
                    "Run my custom probes against claude-haiku-4-5.",
                    "Test my agent stack (model + qontext + tavily) on the demo set.",
                ],
            },
            {
                "id": "list_tasks",
                "name": "List available probes",
                "description": (
                    "Return the catalog of built-in probes (curated, demo, "
                    "and full AVER suite) so the calling agent can pick "
                    "which subset to run."
                ),
                "tags": ["catalog", "discovery"],
                "inputModes": ["application/json"],
                "outputModes": ["application/json"],
                "examples": ["What probes are available?", "List the curated tasks."],
            },
        ],
    }


# ─────────────────────────── JSON-RPC dispatch

JSONRPC_VERSION = "2.0"


def _rpc_error(req_id: Any, code: int, message: str, data: Any = None) -> dict:
    err: dict[str, Any] = {"code": code, "message": message}
    if data is not None:
        err["data"] = data
    return {"jsonrpc": JSONRPC_VERSION, "id": req_id, "error": err}


def _rpc_result(req_id: Any, result: Any) -> dict:
    return {"jsonrpc": JSONRPC_VERSION, "id": req_id, "result": result}


def _extract_skill_input(message: dict) -> tuple[str | None, dict, str]:
    """Pull the requested skill + structured input out of an A2A Message.

    A2A messages have ``parts``; we look at:
      - The ``data`` part (preferred) for structured input.
      - Any ``text`` part for natural-language hints (we don't parse it
        deeply — we just surface it as the prompt for log/debug).

    Skill selection priority:
      1. ``message.metadata.skill`` (explicit)
      2. ``data.skill`` (explicit, embedded in the data part)
      3. Default to ``measure`` if any data is present.

    Returns (skill_id, data_dict, freeform_text).
    """
    metadata = message.get("metadata") or {}
    skill = metadata.get("skill")
    parts = message.get("parts") or []
    data: dict = {}
    text_buf: list[str] = []
    for p in parts:
        ptype = p.get("type") or p.get("kind")
        if ptype == "data":
            payload = p.get("data") or {}
            if isinstance(payload, dict):
                data = {**data, **payload}
        elif ptype == "text":
            text_buf.append(p.get("text", ""))
    if not skill:
        skill = data.get("skill") or ("measure" if data else "measure")
    return skill, data, "\n".join(text_buf).strip()


async def _handle_message_send(req_id: Any, params: dict) -> dict:
    """Handle a JSON-RPC ``message/send`` call.

    Returns a JSON-RPC response dict ready to serialize. The result
    follows A2A's Task shape — ``id``, ``status.state``, and
    ``artifacts`` carrying the structured output.
    """
    message = params.get("message") or {}
    if not message:
        return _rpc_error(req_id, -32602, "Missing 'message' in params")

    skill, data, freeform = _extract_skill_input(message)

    task_id = str(uuid.uuid4())

    if skill == "list_tasks":
        return _rpc_result(req_id, _build_completed_task(task_id, _list_tasks_artifact()))

    if skill == "measure":
        try:
            artifact = await _run_measure(data, freeform)
        except _A2AInputError as e:
            return _rpc_error(req_id, -32602, str(e))
        except Exception as e:  # noqa: BLE001
            log.exception("measure skill crashed")
            return _rpc_error(req_id, -32603, f"internal error: {e}")
        return _rpc_result(req_id, _build_completed_task(task_id, artifact))

    return _rpc_error(req_id, -32601, f"unknown skill: '{skill}'")


def _build_completed_task(task_id: str, artifact: dict) -> dict:
    """Wrap an artifact in A2A's completed-Task envelope."""
    return {
        "id": task_id,
        "status": {"state": "completed"},
        "artifacts": [artifact],
        "history": [],
    }


# ─────────────────────────── skill: list_tasks

def _list_tasks_artifact() -> dict:
    """Return the catalog of available probes as a structured artifact."""
    curated_set = set(CURATED_TASK_IDS)
    items: list[dict] = []
    for t in DEMO_TASKS:
        items.append({
            "id": t.gate_id,
            "name": t.gate,
            "domain": t.domain,
            "kind": "demo",
            "curated": False,
        })
    for t in get_aver_tasks():
        items.append({
            "id": t.task_id,
            "name": t.task_id,
            "domain": t.domain,
            "category": t.category,
            "difficulty": t.difficulty,
            "kind": "aver",
            "curated": t.task_id in curated_set,
        })
    return {
        "name": "induat-task-catalog",
        "parts": [
            {
                "type": "data",
                "data": {
                    "total": len(items),
                    "curated_count": sum(1 for x in items if x["curated"]),
                    "demo_count": sum(1 for x in items if x["kind"] == "demo"),
                    "aver_count": sum(1 for x in items if x["kind"] == "aver"),
                    "tasks": items,
                },
            }
        ],
    }


# ─────────────────────────── skill: measure

class _A2AInputError(ValueError):
    """Raised when an A2A request is malformed in a way the client should fix."""


async def _run_measure(data: dict, freeform: str) -> dict:
    """Resolve the request into a StackConfig + task list, run the gauntlet."""
    model = data.get("model")
    if not model:
        raise _A2AInputError("'model' is required (e.g. 'gemini-2.5-flash').")

    context_name = data.get("context", "none")
    search_name = data.get("search", "none")
    domains = data.get("domains")
    api_keys = data.get("api_keys") or {}
    use_curated = bool(data.get("curated", False))
    custom_probes = data.get("probes") or []
    concurrency = int(data.get("concurrency", 1))
    request_delay = float(data.get("request_delay_s", 1.5))

    try:
        context_cls = context_pkg.REGISTRY[context_name]
        search_cls = search_pkg.REGISTRY[search_name]
    except KeyError as e:
        raise _A2AInputError(
            f"unknown plugin: {e}. "
            f"Available context: {sorted(context_pkg.REGISTRY)}; "
            f"search: {sorted(search_pkg.REGISTRY)}"
        ) from None

    try:
        context_plugin = context_cls(api_key=api_keys.get("qontext")) \
            if api_keys.get("qontext") else context_cls()
    except TypeError:
        context_plugin = context_cls()
    try:
        search_plugin = search_cls(api_key=api_keys.get("tavily")) \
            if api_keys.get("tavily") else search_cls()
    except TypeError:
        search_plugin = search_cls()

    # Resolve the task list.
    tasks: list[Task] = []
    if use_curated:
        for at in get_curated_aver_tasks():
            _, _, axis = gate_for_category(at.category)
            tasks.append(Task(
                gate_id=at.task_id,
                gate=at.task_id,
                axis="both",
                domain=at.domain,
                prompt=at.task_description,
            ))

    # Inline custom probes from the request body.
    for p in custom_probes:
        if not isinstance(p, dict):
            continue
        try:
            tasks.append(Task(
                gate_id=p["id"],
                gate=p.get("gate") or p["id"],
                axis=p.get("axis", "both"),
                domain=p.get("domain", "custom"),
                prompt=p["prompt"],
                must=list(p.get("must") or []),
                must_not=list(p.get("must_not") or []),
                expected=p.get("expected", ""),
            ))
        except KeyError as e:
            raise _A2AInputError(f"custom probe missing required field: {e}") from None

    if not tasks:
        # No curated, no probes — fall back to the demo pack so the call
        # always produces something runnable.
        tasks = list(DEMO_TASKS)

    config = StackConfig(
        model=model,
        context=context_plugin,
        search=search_plugin,
        domains=list(domains) if domains else None,
        concurrency=max(1, concurrency),
        request_delay_s=max(0.0, request_delay),
        api_keys=api_keys,
    )

    log.info("a2a measure: model=%s tasks=%d curated=%s probes=%d",
             model, len(tasks), use_curated, len(custom_probes))
    report: ReliabilityReport = await run_gauntlet(config, tasks_override=tasks)
    return _report_artifact(report)


def _report_artifact(report: ReliabilityReport) -> dict:
    """Wrap a ReliabilityReport in an A2A artifact."""
    return {
        "name": "induat-reliability-report",
        "parts": [
            {
                "type": "data",
                "data": report.model_dump(mode="json"),
            }
        ],
    }


# ─────────────────────────── routes

@router.post("/a2a")
async def a2a_endpoint(request: Request) -> JSONResponse:
    """JSON-RPC 2.0 endpoint for the A2A protocol."""
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return JSONResponse(_rpc_error(None, -32700, "Parse error"), status_code=400)

    if not isinstance(body, dict):
        return JSONResponse(_rpc_error(None, -32600, "Invalid Request"), status_code=400)

    req_id = body.get("id")
    method = body.get("method")
    params = body.get("params") or {}

    if body.get("jsonrpc") != JSONRPC_VERSION:
        return JSONResponse(_rpc_error(req_id, -32600, "jsonrpc must be '2.0'"))

    if method in ("message/send", "tasks/send"):
        return JSONResponse(await _handle_message_send(req_id, params))

    if method == "tasks/get":
        # We don't persist task history — return a 'method not found' so
        # well-behaved clients fall back to using the inline result.
        return JSONResponse(_rpc_error(
            req_id, -32601,
            "tasks/get not supported — induat returns completed Task synchronously from message/send",
        ))

    return JSONResponse(_rpc_error(req_id, -32601, f"unknown method: {method}"))


@router.get("/.well-known/agent.json")
async def agent_card(request: Request) -> JSONResponse:
    """A2A discovery endpoint."""
    base = str(request.base_url).rstrip("/")
    return JSONResponse(build_agent_card(public_base_url=base))


# Some A2A clients use the newer `agent-card.json` filename.
@router.get("/.well-known/agent-card.json")
async def agent_card_alt(request: Request) -> JSONResponse:
    base = str(request.base_url).rstrip("/")
    return JSONResponse(build_agent_card(public_base_url=base))
