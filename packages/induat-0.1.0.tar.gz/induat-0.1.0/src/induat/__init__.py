"""induat — pre-production reliability test suite for AI agents.

Plug in your stack. Run the gauntlet. Get a verdict.
"""

__version__ = "0.1.0"

from induat.reports import (
    GateResult,
    DomainResult,
    ReliabilityReport,
    Verdict,
)
from induat.runner import StackConfig, run_gauntlet

__all__ = [
    "__version__",
    "GateResult",
    "DomainResult",
    "ReliabilityReport",
    "Verdict",
    "StackConfig",
    "run_gauntlet",
]
