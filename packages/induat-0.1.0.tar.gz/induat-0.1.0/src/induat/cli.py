"""induat CLI — beautiful animated terminal output.

Examples:

    # Quick smoke run with one domain
    induat measure --model gemini-2.5-flash --domain demo

    # Full stack demo
    induat measure \\
        --model gemini-2.5-flash \\
        --context qontext \\
        --search tavily \\
        --tools none \\
        --domain demo --domain healthcare

    # Pipe-friendly JSON output for scripts / CI
    induat measure --model gemini-2.5-flash --domain demo --json

API keys come from environment:
    GEMINI_API_KEY, ANTHROPIC_API_KEY, OPENAI_API_KEY, DEEPSEEK_API_KEY,
    QONTEXT_API_KEY, TAVILY_API_KEY
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import sys

import click

from induat import __version__
from induat.plugins import context as context_pkg
from induat.plugins import search as search_pkg
from induat.runner import GATES, StackConfig, run_gauntlet


def _quiet_noisy_loggers() -> None:
    """Silence third-party loggers that bleed into the animated CLI.

    We surface our own status through rich. Provider stack traces and
    LiteLLM "Give Feedback" banners belong in --json mode or debug logs,
    not on top of the spinner.
    """
    for name in (
        "LiteLLM", "litellm", "litellm.utils", "litellm.cost_calculator",
        "httpx", "httpcore", "openai", "anthropic", "google",
        "induat.llm", "induat.runner",
    ):
        logging.getLogger(name).setLevel(logging.CRITICAL)
    # Root logger too — covers anything we missed.
    logging.getLogger().setLevel(logging.CRITICAL)


# ─── Tools registry placeholder ───────────────────────────────────────────
# The Tools axis (function-calling, MCP servers, browsers, sandboxes) is
# planned. For now `--tools` accepts a single value `none` so the CLI
# surface mirrors what's coming. Once the Tools plugin registry ships,
# this will read from `induat.plugins.tools` like the other axes do.
TOOLS_REGISTRY: dict[str, str] = {
    "none": "no tool augmentation (default)",
    # "composio":  "100+ pre-wired SaaS tools (planned)",
    # "mcp":       "MCP server passthrough (planned)",
    # "browserbase": "agent web browsing (planned)",
    # "e2b":       "sandboxed code execution (planned)",
}


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option(__version__, prog_name="induat")
def main() -> None:
    """Pre-production reliability test suite for AI agents.

    Bring your stack. Walk the gauntlet. Get a verdict.
    """


# ───────────────────────── measure ─────────────────────────


@main.command()
@click.option(
    "--model",
    required=True,
    help="Provider/model identifier. e.g. 'gemini-2.5-flash'.",
)
@click.option(
    "--context",
    "context_name",
    type=click.Choice(sorted(context_pkg.REGISTRY)),
    default="none",
    show_default=True,
    help="Context-layer plugin.",
)
@click.option(
    "--search",
    "search_name",
    type=click.Choice(sorted(search_pkg.REGISTRY)),
    default="none",
    show_default=True,
    help="Search plugin.",
)
@click.option(
    "--tools",
    "tools_name",
    type=click.Choice(sorted(TOOLS_REGISTRY)),
    default="none",
    show_default=True,
    help="Tools plugin (placeholder — Tools axis ships soon).",
)
@click.option(
    "--domain",
    "domains",
    multiple=True,
    help="Restrict to specific domains (repeatable). e.g. --domain demo --domain healthcare",
)
@click.option(
    "--limit",
    type=int,
    default=None,
    help="Cap the number of tasks (useful for quick demos).",
)
@click.option(
    "--concurrency",
    type=int,
    default=1,
    show_default=True,
    help="Parallel LLM calls. Default 1 stays under free-tier RPM caps.",
)
@click.option(
    "--delay",
    "request_delay",
    type=float,
    default=1.5,
    show_default=True,
    help="Seconds between LLM calls. Free-tier ~10 RPM = use ≥6.0; paid keys can drop to 0.",
)
@click.option(
    "--curated",
    is_flag=True,
    help="Use the curated 12-task pack — illustrative AVER scenarios across key domains.",
)
@click.option(
    "--stub",
    "force_stub",
    is_flag=True,
    help="Force deterministic stub scoring — no LLM calls. Useful for demos / when keys are rate-limited.",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Emit JSON to stdout instead of pretty output. Disables animation.",
)
@click.option(
    "--probes",
    "probes_path",
    type=click.Path(exists=True, dir_okay=False, readable=True),
    default=None,
    help="Path to a YAML file of custom probes. Run alongside (or instead of) AVER's built-in suite.",
)
@click.option(
    "--probes-only",
    "probes_only",
    is_flag=True,
    help="Run ONLY the custom --probes file. Skip AVER's built-in suite. Requires --probes.",
)
@click.option(
    "--ci",
    "ci_mode",
    is_flag=True,
    help="CI mode: machine-readable output, exit code 1 on NOT_READY/AMMIT, no animation.",
)
@click.option(
    "--threshold",
    "thresholds_str",
    default=None,
    help="CI thresholds. e.g. 'capability=0.8,self_awareness=0.6'. Used with --ci.",
)
@click.option(
    "--junit",
    "junit_path",
    type=click.Path(dir_okay=False, writable=True),
    default=None,
    help="Write JUnit XML report to this path. For GitHub Actions / GitLab CI / Jenkins.",
)
def measure(
    model: str,
    context_name: str,
    search_name: str,
    tools_name: str,
    domains: tuple[str, ...],
    limit: int | None,
    concurrency: int,
    request_delay: float,
    curated: bool,
    force_stub: bool,
    as_json: bool,
    probes_path: str | None,
    probes_only: bool,
    ci_mode: bool,
    thresholds_str: str | None,
    junit_path: str | None,
) -> None:
    """Run the gauntlet against your stack."""
    # Lazy imports — keeps the help text fast.
    from rich.console import Console

    _quiet_noisy_loggers()
    console = Console(highlight=False)

    # Honour --stub by stripping API keys for this run, so the runner's
    # ``_has_real_key`` returns False and we go down the stub path.
    if force_stub:
        os.environ.pop("GEMINI_API_KEY", None)
        os.environ.pop("ANTHROPIC_API_KEY", None)
        os.environ.pop("OPENAI_API_KEY", None)
        os.environ.pop("DEEPSEEK_API_KEY", None)
        os.environ.pop("GOOGLE_API_KEY", None)

    if probes_only and not probes_path:
        raise click.ClickException("--probes-only requires --probes <file>")

    # ── load + filter tasks ──
    if probes_only:
        # User-defined suite ONLY. The bring-your-own-probes path that
        # makes induat more than an AVER CLI.
        from induat.tasks import load_probes_yaml
        try:
            tasks_override = load_probes_yaml(probes_path)  # type: ignore[arg-type]
        except (ValueError, KeyError, OSError) as e:
            raise click.ClickException(f"Failed to load probes from {probes_path}: {e}") from e
    else:
        tasks_override = _load_tasks(domains, limit, curated=curated)
        if probes_path:
            from induat.tasks import load_probes_yaml
            try:
                custom = load_probes_yaml(probes_path)
            except (ValueError, KeyError, OSError) as e:
                raise click.ClickException(f"Failed to load probes from {probes_path}: {e}") from e
            tasks_override = list(tasks_override) + custom

    if not tasks_override:
        raise click.ClickException(
            "No tasks selected. Try removing --domain filters or --limit."
        )
    n_tasks = len(tasks_override)
    domain_set = sorted({t.domain for t in tasks_override})

    # ── build stack ──
    try:
        context_plugin = context_pkg.REGISTRY[context_name]()
        search_plugin = search_pkg.REGISTRY[search_name]()
    except RuntimeError as e:
        raise click.ClickException(str(e)) from e

    api_keys = {} if force_stub else _api_keys_from_env()

    config = StackConfig(
        model=model,
        context=context_plugin,
        search=search_plugin,
        api_keys=api_keys,
        concurrency=max(1, concurrency),
        request_delay_s=max(0.0, request_delay),
    )

    # ── CI mode: machine output, exit code, optional JUnit XML ──
    if ci_mode:
        thresholds = _parse_thresholds(thresholds_str)
        report = asyncio.run(run_gauntlet(config, tasks_override=tasks_override))
        # JSON to stdout for tools to ingest.
        click.echo(json.dumps(report.model_dump(mode="json"), indent=2, default=str))
        # Optional JUnit XML for CI dashboards.
        if junit_path:
            _write_junit_xml(report, junit_path, thresholds=thresholds)
            click.echo(f"# JUnit XML written to {junit_path}", err=True)
        # Exit code reflects the user's CI thresholds, NOT the report's
        # default verdict (so the CLI doesn't silently disagree with the
        # config the user actually passed).
        passed, fail_reasons = _ci_passes_thresholds(report, thresholds)
        click.echo(
            f"# capability={report.capability:.2f}  "
            f"self_awareness={report.self_awareness:.2f}  "
            f"thresholds=cap≥{thresholds['capability']:.2f},sa≥{thresholds['self_awareness']:.2f}",
            err=True,
        )
        if not passed:
            for reason in fail_reasons:
                click.echo(f"# CI FAIL: {reason}", err=True)
            sys.exit(1)
        click.echo("# CI PASS ✓", err=True)
        return

    # ── JSON mode: machine output, no animation ──
    if as_json:
        report = asyncio.run(run_gauntlet(config, tasks_override=tasks_override))
        click.echo(json.dumps(report.model_dump(mode="json"), indent=2, default=str))
        if junit_path:
            _write_junit_xml(report, junit_path, thresholds=_parse_thresholds(thresholds_str))
        return

    # ── pretty mode: animated demo ──
    _set_terminal_title(f"induat — {model}")
    _print_command_echo(console, model, context_name, search_name, tools_name, domains)
    _print_status_line(console, n_tasks, len(domain_set))
    console.print()

    # Animate while gauntlet runs.
    real_mode = _has_real_key_for(model, api_keys)
    report = _run_with_progress(
        console=console,
        config=config,
        tasks_override=tasks_override,
        n_tasks=n_tasks,
        real_mode=real_mode,
    )

    _print_pretty_summary(console, report)
    # Pretty mode also honours --junit, since you may want a CI artifact
    # alongside a human-readable run.
    if junit_path:
        _write_junit_xml(report, junit_path, thresholds=_parse_thresholds(thresholds_str))
        console.print(f"[dim]JUnit XML written to {junit_path}[/dim]")


def _load_tasks(domains: tuple[str, ...], limit: int | None, *, curated: bool = False):
    """Load AVER tasks (and demo tasks), filter, convert to runner Task dataclass.

    When ``curated=True``, only the hand-picked CURATED_TASK_IDS pack runs
    — 12 illustrative scenarios across domains, ideal for a 2-3 min demo.
    """
    from induat.tasks import (
        DEMO_TASKS,
        Task,
        gate_for_category,
        get_aver_tasks,
        get_curated_aver_tasks,
    )

    out = []
    want = set(domains) if domains else None

    if curated:
        # Curated pack: the 20-task demo across 7 domains (some Mem0,
        # some Tavily, some no-tool) followed by the 12 hand-picked
        # AVER scenarios for the more rigorous probes.
        for t in DEMO_TASKS:
            if want and t.domain not in want:
                continue
            out.append(t)
        for at in get_curated_aver_tasks():
            if want and at.domain not in want:
                continue
            _, _, axis = gate_for_category(at.category)
            out.append(Task(
                gate_id=at.task_id,
                gate=_humanize_aver_id(at.task_id, at.domain),
                axis="both",
                domain=at.domain,
                prompt=at.task_description,
            ))
        if limit:
            out = out[:limit]
        return out

    # Demo pack first (matches the UI's ordering).
    for t in DEMO_TASKS:
        if want and t.domain not in want:
            continue
        out.append(t)

    # Then AVER tasks.
    for at in get_aver_tasks():
        if want and at.domain not in want:
            continue
        _, _, axis = gate_for_category(at.category)
        out.append(Task(
            gate_id=at.task_id,
            gate=_humanize_aver_id(at.task_id, at.domain),
            axis="both",
            domain=at.domain,
            prompt=at.task_description,
        ))

    if limit:
        out = out[:limit]
    return out


def _humanize_aver_id(task_id: str, domain: str) -> str:
    """aver_airline_baggage_calc_3_045 → 'Baggage Calc' (domain shown separately)."""
    s = task_id
    if s.startswith("aver_"):
        s = s[5:]
    parts = s.split("_")
    while parts and parts[-1].isdigit():
        parts.pop()
    if parts and parts[0] == domain:
        parts = parts[1:]
    return " ".join(parts).title() if parts else task_id


def _api_keys_from_env() -> dict[str, str]:
    candidates = {
        "gemini":    "GEMINI_API_KEY",
        "anthropic": "ANTHROPIC_API_KEY",
        "openai":    "OPENAI_API_KEY",
        "pioneer":   "PIONEER_API_KEY",
        "mem0":      "MEM0_API_KEY",
        "qontext":   "QONTEXT_API_KEY",
        "tavily":    "TAVILY_API_KEY",
    }
    out: dict[str, str] = {}
    for slug, env_name in candidates.items():
        val = os.environ.get(env_name, "").strip()
        if val:
            out[slug] = val
    return out


def _has_real_key_for(model: str, api_keys: dict[str, str]) -> bool:
    m = model.lower()
    if "gemini" in m: return bool(api_keys.get("gemini"))
    if "claude" in m or "anthropic" in m: return bool(api_keys.get("anthropic"))
    if "pioneer" in m: return bool(api_keys.get("pioneer"))
    # OpenAI: gpt-* (incl. gpt-5, gpt-4.1) plus o-series (o1, o3, …).
    if m.startswith("gpt") or (len(m) >= 2 and m[0] == "o" and m[1].isdigit()):
        return bool(api_keys.get("openai"))
    return False


# ─── pretty rendering helpers ────────────────────────────────────────────


def _set_terminal_title(title: str) -> None:
    """Set the terminal tab title via ANSI escape (silently no-ops if unsupported)."""
    if sys.stdout.isatty():
        sys.stdout.write(f"\033]0;{title}\007")
        sys.stdout.flush()


def _print_command_echo(
    console,
    model: str,
    context: str,
    search: str,
    tools: str,
    domains: tuple[str, ...],
) -> None:
    """Echo the invocation line so the user sees what's about to run."""
    parts = ["induat measure", f"--model {model}"]
    if context != "none": parts.append(f"--context {context}")
    if search != "none":  parts.append(f"--search {search}")
    if tools != "none":   parts.append(f"--tools {tools}")
    for d in domains:
        parts.append(f"--domain {d}")
    cmd = " ".join(parts)
    console.print(f"[bold cyan]$[/bold cyan] [bold]{cmd}[/bold]")


def _print_status_line(console, n_tasks: int, n_domains: int) -> None:
    domains_word = "domain" if n_domains == 1 else "domains"
    probes_word = "probe" if n_tasks == 1 else "probes"
    console.print(f"[dim]running {n_tasks} {probes_word} across {n_domains} {domains_word}…[/dim]")


def _run_with_progress(*, console, config, tasks_override, n_tasks, real_mode):
    """Run the gauntlet with a live per-task progress display.

    Renders one row per task with a status icon, the task name, a
    sweeping bar for whichever task is currently in flight, and a
    colored score column once the task completes. The Live block
    redraws at ~12 fps so the running task feels alive even though
    individual LLM calls take seconds.

    Captures stderr while Live is active so LiteLLM / provider SDK
    noise can't pollute the animated output.
    """
    import io
    import time
    from contextlib import redirect_stderr
    from rich.console import Group
    from rich.live import Live
    from rich.text import Text

    label = "Walking the gauntlet" if real_mode else "Walking the gauntlet (stub)"

    # Shared state mutated by the progress callbacks.
    statuses: list[str] = ["pending"] * n_tasks  # "pending"|"running"|"passed"|"failed"
    scores: dict[int, float] = {}
    notes: dict[int, str] = {}
    names: list[str] = [_short_gate_name(t.gate, max_len=42) for t in tasks_override]
    domains: list[str] = [getattr(t, "domain", "") or "" for t in tasks_override]

    def on_task_start(idx, total, task):
        if 0 <= idx < n_tasks:
            statuses[idx] = "running"

    def on_task_done(idx, total, task, score, passed, note):
        if 0 <= idx < n_tasks:
            statuses[idx] = "passed" if passed else "failed"
            scores[idx] = float(score)
            notes[idx] = note or ""

    def render():
        return _render_live_panel(
            label=label,
            statuses=statuses,
            scores=scores,
            names=names,
            domains=domains,
            now=time.time(),
        )

    report = None

    async def _runner():
        nonlocal report
        report = await run_gauntlet(
            config,
            tasks_override=tasks_override,
            on_task_start=on_task_start,
            on_task_done=on_task_done,
        )

    sink = io.StringIO()
    refresh = 1.0 / 12

    with Live(render(), console=console, refresh_per_second=12, transient=False) as live:
        with redirect_stderr(sink):
            async def _drive():
                run_task = asyncio.create_task(_runner())
                while not run_task.done():
                    live.update(render())
                    await asyncio.sleep(refresh)
                # Surface any exception from the inner runner.
                await run_task
                live.update(render())

            asyncio.run(_drive())

    # Print one short blank line so the next summary block doesn't kiss
    # the bottom of the live panel.
    console.print()
    return report


def _render_live_panel(
    *, label: str, statuses, scores, names, domains, now: float,
):
    """Build the per-frame Group used by the Live block."""
    from rich.console import Group
    from rich.text import Text

    n = len(statuses)
    completed = sum(1 for s in statuses if s in ("passed", "failed"))
    running = sum(1 for s in statuses if s == "running")
    passed = sum(1 for s in statuses if s == "passed")
    failed = sum(1 for s in statuses if s == "failed")

    # ─── Header line ───
    header = Text()
    header.append(f"  {label}  ", style="bold yellow")
    header.append(f"[{completed}/{n}] ", style="bold")
    if passed:
        header.append(f"✓ {passed} passed  ", style="green")
    if failed:
        header.append(f"✗ {failed} failed  ", style="red")
    if running:
        header.append(f"◐ {running} running", style="yellow")

    # ─── Overall progress bar ───
    bar_w = 36
    filled = int(round((completed / n) * bar_w)) if n else 0
    pbar = Text()
    pbar.append("  ")
    pbar.append("│", style="dim")
    pbar.append("█" * filled, style="green")
    pbar.append("░" * (bar_w - filled), style="dim")
    pbar.append("│", style="dim")
    pct = (completed / n * 100) if n else 0
    pbar.append(f"  {pct:5.1f}%", style="bold")

    # ─── Per-task rows ───
    name_w = 44
    rows: list[Text] = []
    for i in range(n):
        status = statuses[i]
        line = Text()
        line.append("  ")  # left margin

        # status icon column (3 chars)
        if status == "pending":
            line.append("⋯  ", style="dim")
        elif status == "running":
            line.append(_running_spinner_char(now) + "  ", style="bold yellow")
        elif status == "passed":
            line.append("✓  ", style="bold green")
        else:  # failed
            line.append("✗  ", style="bold red")

        # name column
        nm = names[i].ljust(name_w)
        if len(nm) > name_w:
            nm = nm[: name_w - 1] + "…"
        if status == "pending":
            line.append(nm, style="dim")
        elif status == "running":
            line.append(nm, style="bold yellow")
        elif status == "passed":
            line.append(nm, style="green")
        else:
            line.append(nm, style="red")

        # domain pill / running bar / score (right column)
        if status == "running":
            line.append("  ")
            line.append(_sweep_bar(now, width=12), style="yellow")
        elif status in ("passed", "failed"):
            score = scores.get(i, 0.0)
            color = "green" if status == "passed" else "red"
            line.append(f"  {score:.2f}  ", style="bold " + color)
            line.append(("PASS" if status == "passed" else "FAIL"), style="bold " + color)
        else:
            dom = domains[i].replace("_", " ")
            line.append(f"  {dom}", style="dim")

        rows.append(line)

    return Group(header, pbar, Text(""), *rows)


def _running_spinner_char(now: float) -> str:
    """Cycle through Braille spinner characters at ~12 fps."""
    frames = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
    return frames[int(now * 10) % len(frames)]


def _sweep_bar(now: float, *, width: int = 12) -> str:
    """Sweeping highlight that travels left-to-right across a bar.

    Three-block highlight cycles every ~1.4s so the user can see the
    active task is making progress even when no per-task percentage is
    available (LLM calls are opaque).
    """
    span = width + 4
    pos = int((now * 9) % span) - 2
    out = []
    for i in range(width):
        out.append("█" if pos <= i < pos + 3 else "░")
    return "".join(out)


def _render_bar(value: float, *, width: int = 14, color: str = "green") -> str:
    """Render a colored progress bar like '████████░░░░░░'."""
    v = max(0.0, min(1.0, float(value)))
    filled = int(round(v * width))
    empty = width - filled
    return f"[{color}]{'█' * filled}[/{color}][dim]{'░' * empty}[/dim]"


def _color_for_score(value: float) -> str:
    if value >= 0.70: return "green"
    if value >= 0.40: return "yellow"
    return "red"


def _print_pretty_summary(console, report) -> None:
    """Render the final results panel matching the inDuat visual language.

    Bars animate from 0 → final value with a staggered ease-out fill so
    the reveal feels intentional. The verdict + footer print statically
    after the animation completes. Falls back to a static one-shot
    render if the terminal is non-interactive.
    """
    if _maybe_print_error_banner(console, report):
        return

    bars = _build_bar_spec(report)
    if not bars or not console.is_terminal:
        # Non-interactive (piped / tty=False) — render statically and bail.
        _print_summary_static(console, report, bars)
        _print_summary_tail(console, report)
        return

    _animate_summary(console, bars)
    _print_summary_tail(console, report)


def _build_bar_spec(report) -> list[dict]:
    """Build the list of bars to render in summary order.

    Each entry: {section, label, value, shown, width, label_pad, accent}
      - section: 'pillar' | 'dim_header' | 'dim' | 'composite'
      - shown=False renders an em-dash placeholder
      - accent: highlight color for the value text (composite uses yellow)
    """
    cap = float(report.capability or 0)
    aw  = float(report.self_awareness or 0)
    cap_count = int(getattr(report, "capability_count", 0) or 0)
    aw_count  = int(getattr(report, "awareness_count", 0) or 0)

    bars: list[dict] = []
    bars.append({
        "section": "pillar", "label": "Capability:",
        "value": cap, "shown": cap_count > 0,
        "width": 14, "label_pad": 16, "accent": None,
    })
    bars.append({
        "section": "pillar", "label": "Self-awareness:",
        "value": aw, "shown": aw_count > 0,
        "width": 14, "label_pad": 16, "accent": None,
    })

    dim_entries: list[tuple[str, float]] = []
    if int(getattr(report, "detection_count", 0) or 0) > 0:
        dim_entries.append(("Detection",     float(report.detection_avg or 0)))
    if int(getattr(report, "diagnosis_count", 0) or 0) > 0:
        dim_entries.append(("Diagnosis",     float(report.diagnosis_avg or 0)))
    if int(getattr(report, "recovery_count", 0) or 0) > 0:
        dim_entries.append(("Recovery",      float(report.recovery_avg or 0)))
    if int(getattr(report, "causal_chain_count", 0) or 0) > 0:
        dim_entries.append(("Causal chain",  float(report.causal_chain_pct or 0)))
    if int(getattr(report, "negative_control_count", 0) or 0) > 0:
        dim_entries.append(("FP resistance", float(report.fp_resistance or 0)))

    if dim_entries:
        bars.append({"section": "dim_header"})
        for label, val in dim_entries:
            bars.append({
                "section": "dim", "label": label, "value": val, "shown": True,
                "width": 10, "label_pad": 14, "accent": None,
            })
        bars.append({
            "section": "composite", "label": "Composite",
            "value": float(report.composite or 0), "shown": True,
            "width": 10, "label_pad": 14, "accent": "yellow",
        })
    return bars


def _ease_out_cubic(t: float) -> float:
    """Smooth deceleration ease — bars start fast, settle softly."""
    t = max(0.0, min(1.0, t))
    return 1 - (1 - t) ** 3


def _bar_line(b: dict, fill_frac: float) -> str:
    """Render a single bar row at the given fill fraction (0..1)."""
    if b["section"] == "dim_header":
        return "[dim]── dimensions ──[/dim]"

    indent = "  " if b["section"] in ("dim", "composite") else ""
    label = b["label"].ljust(b["label_pad"])

    if not b.get("shown", True):
        return f"{indent}[bold]{label}[/bold] [dim]—       (not measured)[/dim]"

    target = float(b["value"])
    color = _color_for_score(target)
    cur = target * fill_frac
    bar = _render_bar(cur, width=b["width"], color=color)
    accent = b.get("accent")
    if accent:
        value_str = f"[bold {accent}]{cur:.2f}[/bold {accent}]"
    else:
        value_str = f"[bold]{cur:.2f}[/bold]"
    return f"{indent}[bold]{label}[/bold] {value_str}  {bar}"


def _animate_summary(console, bars: list[dict]) -> None:
    """Animate the bars filling 0 → final with a slot-machine reveal."""
    import time
    from rich.console import Group
    from rich.live import Live
    from rich.text import Text

    # Stagger each bar slightly so they don't all fill at once — feels
    # more like reveal than a flash. Tuned for ~1s total runtime on a
    # 12-task summary.
    per_bar_s = 0.30
    stagger_s = 0.08
    fps = 30
    refresh = 1.0 / fps

    # Header indices: dim_header rows aren't animated, treat as instant.
    n = len(bars)
    total_s = stagger_s * max(0, n - 1) + per_bar_s + 0.05

    def render_frame(elapsed: float):
        lines = []
        for i, b in enumerate(bars):
            if b["section"] == "dim_header":
                # Reveal the header at the moment its first dim-bar starts.
                visible = elapsed >= i * stagger_s
                lines.append(_bar_line(b, 1.0) if visible else "")
                continue
            start_t = i * stagger_s
            t = (elapsed - start_t) / per_bar_s if per_bar_s > 0 else 1.0
            frac = _ease_out_cubic(t)
            lines.append(_bar_line(b, frac))
        return Group(*[Text.from_markup(line) for line in lines])

    with Live(
        render_frame(0.0),
        console=console,
        refresh_per_second=fps,
        transient=False,
    ) as live:
        elapsed = 0.0
        while elapsed < total_s:
            time.sleep(refresh)
            elapsed += refresh
            live.update(render_frame(elapsed))
        # Final frame at full fill — guarantees no rounding artifacts.
        live.update(render_frame(total_s + 1.0))


def _print_summary_static(console, report, bars: list[dict]) -> None:
    """Static fallback for non-interactive terminals (no animation)."""
    for b in bars:
        console.print(_bar_line(b, 1.0))


def _print_summary_tail(console, report) -> None:
    """Print the gates summary, verdict, and stub footer after the animated bars."""
    console.print()

    # ── gates summary ──
    passed = [g for g in report.gates if g.passed]
    failed = [g for g in report.gates if not g.passed]
    if failed:
        names = [_short_gate_name(g.gate) for g in failed[:4]]
        suffix = "" if len(failed) <= 4 else f" +{len(failed) - 4} more"
        names_str = ", ".join(names) + suffix
        console.print(
            f"[bold]Gates:[/bold] [green]{len(passed)} passed[/green] · "
            f"[red]{len(failed)} failed[/red]  [dim]({names_str})[/dim]"
        )
    else:
        console.print(
            f"[bold]Gates:[/bold] [green]{len(passed)} passed[/green]  [dim](all clear)[/dim]"
        )
    console.print()

    # ── verdict ──
    verdict = report.verdict.value if hasattr(report.verdict, "value") else str(report.verdict)
    verdict_label = {
        "production_ready": "PRODUCTION_READY",
        "not_ready":        "NOT_READY",
        "ammit":            "UNSAFE_TO_DEPLOY",
    }.get(verdict, verdict.upper())
    verdict_color = {
        "production_ready": "green",
        "not_ready":        "yellow",
        "ammit":            "red",
    }.get(verdict, "white")
    verdict_rationale = {
        "production_ready": "safe to ship.",
        "not_ready":        "iterate before deploying.",
        "ammit":            "agent is confidently wrong — do not ship.",
    }.get(verdict, "")

    console.print(
        f"[bold]Verdict:[/bold] "
        f"[bold {verdict_color}]{verdict_label}[/bold {verdict_color}] "
        f"[dim]— {verdict_rationale}[/dim]"
    )

    notes = getattr(report, "notes", None) or []
    if any("stub" in n.lower() for n in notes):
        console.print()
        console.print(
            "[yellow]⚠ stub mode[/yellow] [dim]— no LLM call made. "
            "Set GEMINI_API_KEY (or your provider) to run real measurements.[/dim]"
        )
    console.print()


def _maybe_print_error_banner(console, report) -> bool:
    """If most tasks failed with the same provider error, print a banner.

    Returns True when the banner is shown (and the caller should skip the
    normal score panel — those numbers would just be misleading zeros).
    Threshold: ≥50% of gates errored with the same kind.
    """
    gates = list(report.gates or [])
    if not gates:
        return False
    kinds: dict[str, int] = {}
    for g in gates:
        k = ((g.audit or {}).get("error_kind") or "").strip()
        if k:
            kinds[k] = kinds.get(k, 0) + 1
    if not kinds:
        return False

    top_kind, top_count = max(kinds.items(), key=lambda kv: kv[1])
    if top_count < max(1, len(gates) // 2):
        return False

    # Friendly copy per error kind. Each maps to a clear next step the
    # user can act on without re-reading provider docs.
    headlines = {
        "rate_limit":   ("Rate limit hit",
                         "Provider returned 429 on the majority of tasks. "
                         "Free-tier quotas (Gemini ~10 RPM) trip easily on parallel runs."),
        "auth":         ("Auth failed",
                         "Provider rejected the API key. Check the env var "
                         "(GEMINI_API_KEY / ANTHROPIC_API_KEY / OPENAI_API_KEY / DEEPSEEK_API_KEY)."),
        "timeout":      ("Provider timeout",
                         "The provider took too long to respond on most tasks."),
        "safety_block": ("Provider safety filter",
                         "Most tasks were blocked by the provider's safety filter. "
                         "AVER tasks include fraud, legal, and healthcare scenarios that "
                         "Gemini's filter is conservative about."),
        "other":        ("Provider error",
                         "Most tasks failed with a provider error. Re-run with --json to see details."),
    }
    title, body = headlines.get(top_kind, headlines["other"])
    suggestions = {
        "rate_limit": [
            "Looks like your daily quota is gone. Try again later, or:",
            "Add [bold]--stub[/bold] to see the full gauntlet output without burning quota.",
            "Switch model: [bold]--model gemini-1.5-flash[/bold] (separate quota), "
            "[bold]claude-haiku-4-5[/bold], or [bold]gpt-4o-mini[/bold].",
            "For real runs: drop concurrency ([bold]--concurrency 1[/bold]) "
            "or use a paid API key.",
        ],
        "auth": [
            "Confirm the env var is exported in this shell.",
            "Verify the key has access to the requested model.",
            "Add [bold]--stub[/bold] to demo the gauntlet without an LLM key.",
        ],
        "timeout": [
            "Re-run with [bold]--concurrency 1[/bold] to reduce contention.",
            "Try a smaller model (e.g. gemini-1.5-flash, claude-haiku-4-5).",
        ],
        "safety_block": [
            "Try a different model — Claude/GPT have different safety thresholds than Gemini.",
            "Or use [bold]--curated[/bold] (already filters out the most-blocked categories).",
            "[bold]--stub[/bold] also works to demo the gauntlet flow.",
        ],
        "other": [
            "Re-run with [bold]--json[/bold] to inspect the raw error per task.",
            "Add [bold]--stub[/bold] to demo the gauntlet without LLM calls.",
        ],
    }.get(top_kind, [])

    console.print(f"[bold red]✖ {title}[/bold red]  [dim]({top_count}/{len(gates)} tasks)[/dim]")
    console.print(f"[dim]{body}[/dim]")
    if suggestions:
        console.print()
        for s in suggestions:
            console.print(f"  • {s}")
    console.print()
    return True


def _short_gate_name(name: str, max_len: int = 28) -> str:
    """Trim a long task name for the gates summary line."""
    s = name.strip()
    if len(s) <= max_len:
        return s
    return s[: max_len - 1].rstrip() + "…"


# ───────────────────────── plugins / gates / serve ─────────────────────────


@main.command(name="plugins")
def plugins_cmd() -> None:
    """List available context + search plugins."""
    from rich.console import Console
    console = Console()
    console.print("[bold]context[/bold]")
    for name in sorted(context_pkg.REGISTRY):
        console.print(f"  · {name}")
    console.print()
    console.print("[bold]search[/bold]")
    for name in sorted(search_pkg.REGISTRY):
        console.print(f"  · {name}")
    console.print()
    console.print("[bold]tools[/bold] [dim](placeholder — coming soon)[/dim]")
    for name, desc in TOOLS_REGISTRY.items():
        console.print(f"  · {name}  [dim]{desc}[/dim]")


@main.command(name="gates")
def gates_cmd() -> None:
    """List the canonical gates of the gauntlet."""
    from rich.console import Console
    console = Console()
    console.print("[bold]The six gates[/bold]\n")
    for gate_id, gate_name in GATES:
        console.print(f"  [yellow]{gate_id:<16}[/yellow] {gate_name}")


@main.command()
@click.option("--host", default="0.0.0.0", show_default=True)
@click.option("--port", default=9090, show_default=True, type=int)
@click.option("--reload", is_flag=True, help="Enable auto-reload (development).")
def serve(host: str, port: int, reload: bool) -> None:
    """Start the FastAPI server (web UI + REST API)."""
    import uvicorn

    uvicorn.run(
        "induat.api:app",
        host=host,
        port=port,
        reload=reload,
        log_level="info",
    )


# ───────────────────────── add-probe ─────────────────────────


@main.command(name="add-probe")
@click.option(
    "--file",
    "out_path",
    type=click.Path(dir_okay=False, writable=True),
    default=None,
    help="YAML file to append the probe to. Defaults to ./probes.yaml.",
)
def add_probe_cmd(out_path: str | None) -> None:
    """Author a custom reliability probe interactively.

    Custom probes are *your* failure tests for *your* agent. AVER's 117
    built-in probes cover the general failure modes; this is how you
    encode the specific things you've seen go wrong in production.

    The resulting YAML file is plain text. Edit it. Commit it. Run it
    in CI:

        induat measure --probes ./probes.yaml --ci
    """
    from rich.console import Console

    console = Console()
    out_path = out_path or "probes.yaml"

    console.print()
    console.print("[bold]Author a reliability probe[/bold]")
    console.print(
        "[dim]One probe = one failure mode you want to catch before you ship.[/dim]"
    )
    console.print()

    probe_id = click.prompt(
        "Probe id (snake_case)",
        type=str,
        default="my_first_probe",
    )

    valid_gates = ["heart", "whispers", "hidden_things", "scales", "flame", "maat"]
    console.print()
    console.print("[bold]Pick a gate[/bold] (the failure-mode bucket):")
    console.print("  [yellow]heart[/yellow]          self-correction · 'is what I just said true?'")
    console.print("  [yellow]whispers[/yellow]       tool hallucination · invented tool output")
    console.print("  [yellow]hidden_things[/yellow]  missing info · should ask, doesn't")
    console.print("  [yellow]scales[/yellow]         numerical / factual precision")
    console.print("  [yellow]flame[/yellow]          adversarial · tempting-but-wrong answer")
    console.print("  [yellow]maat[/yellow]           policy compliance · rule adherence")
    console.print()
    gate = click.prompt(
        "Gate",
        type=click.Choice(valid_gates),
        default="heart",
    )

    domain = click.prompt(
        "Domain (free text — appears in per-domain breakdown)",
        type=str,
        default="custom",
    )

    console.print()
    console.print("[bold]Probe prompt[/bold] — what you'd send the agent.")
    console.print(
        "[dim]Multi-line: end with a single line containing only ':wq'.[/dim]"
    )
    prompt_lines: list[str] = []
    while True:
        line = click.prompt("", prompt_suffix=" ", default="", show_default=False)
        if line == ":wq":
            break
        prompt_lines.append(line)
    prompt = "\n".join(prompt_lines).strip()
    if not prompt:
        raise click.ClickException("Probe prompt cannot be empty.")

    console.print()
    console.print("[bold]'must' signals[/bold] (any one means PASS) — comma-separated:")
    must_raw = click.prompt(
        "must",
        type=str,
        default="",
        show_default=False,
    )
    must = [s.strip() for s in must_raw.split(",") if s.strip()]

    console.print()
    console.print("[bold]'must_not' signals[/bold] (any one means FAIL) — comma-separated:")
    must_not_raw = click.prompt(
        "must_not",
        type=str,
        default="",
        show_default=False,
    )
    must_not = [s.strip() for s in must_not_raw.split(",") if s.strip()]

    console.print()
    expected = click.prompt(
        "Expected behaviour (one sentence, for your future self)",
        type=str,
        default="",
        show_default=False,
    )

    probe_dict: dict = {
        "id": probe_id,
        "gate": gate,
        "domain": domain,
        "prompt": prompt,
    }
    if must:
        probe_dict["must"] = must
    if must_not:
        probe_dict["must_not"] = must_not
    if expected:
        probe_dict["expected"] = expected

    from induat.tasks import write_probe_yaml

    write_probe_yaml(out_path, probe_dict)

    console.print()
    console.print(f"[green]✓[/green] Saved [bold]{probe_id}[/bold] to [yellow]{out_path}[/yellow]")
    console.print()
    console.print("Run it:")
    console.print(f"  [cyan]induat measure --model gemini-2.5-flash --probes {out_path}[/cyan]")
    console.print()


# ───────────────────────── CI helpers ─────────────────────────


def _parse_thresholds(s: str | None) -> dict[str, float]:
    """Parse 'capability=0.8,self_awareness=0.6' → dict.

    Defaults match the conservative thresholds used by ReliabilityReport's
    verdict logic. Anything unparseable raises ClickException with a
    clear message rather than silently using defaults — CI users want to
    know when their config didn't take.
    """
    defaults = {"capability": 0.80, "self_awareness": 0.70}
    if not s:
        return defaults

    out = dict(defaults)
    for part in s.split(","):
        part = part.strip()
        if not part:
            continue
        if "=" not in part:
            raise click.ClickException(
                f"--threshold expected key=value, got: {part!r}"
            )
        key, val = part.split("=", 1)
        key = key.strip()
        if key not in defaults:
            raise click.ClickException(
                f"--threshold: unknown key {key!r}. "
                f"Valid: {sorted(defaults)}"
            )
        try:
            out[key] = float(val.strip())
        except ValueError as e:
            raise click.ClickException(
                f"--threshold {key!r} expected a float, got {val!r}"
            ) from e
    return out


def _ci_passes_thresholds(
    report, thresholds: dict[str, float]
) -> tuple[bool, list[str]]:
    """CI gate: any failed threshold or AMMIT verdict = build fails.

    Returns (passed, fail_reasons). Fail reasons are human-readable so
    they can be surfaced in the CI build log.
    """
    from induat.reports import Verdict

    reasons: list[str] = []
    if report.verdict == Verdict.AMMIT:
        reasons.append(
            "AMMIT verdict — self-awareness too low to ship regardless of capability"
        )
    cap_min = thresholds.get("capability", 0.8)
    sa_min = thresholds.get("self_awareness", 0.7)
    if report.capability < cap_min:
        reasons.append(
            f"capability {report.capability:.2f} < threshold {cap_min:.2f}"
        )
    if report.self_awareness < sa_min:
        reasons.append(
            f"self_awareness {report.self_awareness:.2f} < threshold {sa_min:.2f}"
        )
    return (not reasons, reasons)


def _write_junit_xml(report, path: str, thresholds: dict[str, float]) -> None:
    """Serialize the report as a JUnit XML file for CI dashboards.

    Each gate becomes a <testcase>; failed gates carry a <failure> tag
    with the prompt + response so you can debug from the CI artifact
    without re-running. Aggregate axes (capability, self_awareness)
    appear as additional synthetic testcases gated by the thresholds —
    this lets a passing per-gate run still fail the build if the
    aggregate score is below your bar.
    """
    import xml.etree.ElementTree as ET
    from xml.dom import minidom

    # Count failures upfront so the testsuite header is accurate. Most CI
    # dashboards lean on the per-element <failure> tags, but a few read
    # the suite-level attribute as the headline number.
    gate_fails = sum(1 for g in report.gates if not g.passed)
    aggregate_fails = sum(1 for axis_value, threshold in (
        (report.capability, thresholds.get("capability", 0.8)),
        (report.self_awareness, thresholds.get("self_awareness", 0.7)),
    ) if axis_value < threshold)

    suite = ET.Element("testsuite", {
        "name": "induat",
        "tests": str(len(report.gates) + 2),  # +2 for capability/self_awareness checks
        "failures": str(gate_fails + aggregate_fails),
        "timestamp": (
            report.finished_at.isoformat() if report.finished_at else report.started_at.isoformat()
        ),
    })

    properties = ET.SubElement(suite, "properties")
    for k, v in (
        ("model", report.stack.model),
        ("context", report.stack.context),
        ("search", report.stack.search),
        ("verdict", report.verdict.value),
        ("capability", f"{report.capability:.4f}"),
        ("self_awareness", f"{report.self_awareness:.4f}"),
        ("composite", f"{report.composite:.4f}"),
        ("threshold.capability", f"{thresholds.get('capability', 0.8):.4f}"),
        ("threshold.self_awareness", f"{thresholds.get('self_awareness', 0.7):.4f}"),
    ):
        ET.SubElement(properties, "property", {"name": str(k), "value": str(v)})

    # Per-gate test cases — one row per probe.
    for g in report.gates:
        case = ET.SubElement(suite, "testcase", {
            "classname": f"induat.{g.gate_id}",
            "name": g.gate or g.gate_id,
            "time": "0",
        })
        if not g.passed:
            failure = ET.SubElement(case, "failure", {
                "type": "ProbeFailed",
                "message": g.note or f"score={g.score:.2f}",
            })
            # Body of the failure includes the trace so it lands in the
            # CI dashboard's failure detail without needing the JSON.
            trace = []
            if g.prompt:
                trace.append("=== prompt ===")
                trace.append(g.prompt[:2000])
            if g.response:
                trace.append("=== response ===")
                trace.append(g.response[:2000])
            if trace:
                failure.text = "\n".join(trace)

    # Aggregate-axis synthetic testcases.
    for axis_name, value, threshold in (
        ("capability", report.capability, thresholds.get("capability", 0.8)),
        ("self_awareness", report.self_awareness, thresholds.get("self_awareness", 0.7)),
    ):
        case = ET.SubElement(suite, "testcase", {
            "classname": "induat.aggregate",
            "name": f"{axis_name} >= {threshold:.2f}",
            "time": "0",
        })
        if value < threshold:
            ET.SubElement(case, "failure", {
                "type": "ThresholdNotMet",
                "message": f"{axis_name}={value:.4f} < threshold {threshold:.4f}",
            })

    suites = ET.Element("testsuites")
    suites.append(suite)

    pretty = minidom.parseString(ET.tostring(suites, encoding="unicode")).toprettyxml(indent="  ")
    with open(path, "w") as f:
        f.write(pretty)


if __name__ == "__main__":
    main()
