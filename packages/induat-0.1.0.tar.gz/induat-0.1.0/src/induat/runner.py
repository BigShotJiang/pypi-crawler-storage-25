"""Gauntlet runner — dispatches an agent through the six gates.

Two execution modes:

  * **Real** (default when an API key is available for the chosen model):
    LiteLLM calls the model against one task per gate, applies the keyword
    rubric in ``induat.llm.score_task_response``, and aggregates.

  * **Stub** (deterministic fallback when no API key is available): a
    SHA-style deterministic hash produces stable, visually-plausible scores
    so the UI, tests, and demos keep working with zero external services.

Context + search plugins are called before the LLM if the task's domain
is addressable by the chosen plugin; retrieved passages are injected
into the prompt as a prefix.
"""
from __future__ import annotations

import asyncio
import logging
import os
from dataclasses import dataclass, field

from induat.llm import (
    call_model,
    provider_for_model,
    required_env_for,
    score_task_response,
)
from induat.plugins.base import ContextPlugin, SearchPlugin
from induat.reports import (
    DomainResult,
    GateResult,
    ReliabilityReport,
    StackDescriptor,
)
from induat.tasks import TASKS

log = logging.getLogger("induat.runner")

# The six MVP gates (labels kept here for the UI / CLI even when the
# actual task set comes from ``induat.tasks``).
GATES: list[tuple[str, str]] = [(t.gate_id, t.gate) for t in TASKS]

DEFAULT_DOMAINS: list[str] = list({t.domain for t in TASKS})


@dataclass
class StackConfig:
    """The stack being measured."""

    model: str
    context: ContextPlugin
    search: SearchPlugin
    domains: list[str] | None = None
    concurrency: int = 4
    # Seconds to wait *before* dispatching each LLM call (per slot). Lets
    # the gauntlet stay under provider RPM caps without the user having to
    # tune concurrency. 0 = no throttling.
    request_delay_s: float = 0.0
    api_keys: dict[str, str] = field(default_factory=dict)

    @property
    def descriptor(self) -> StackDescriptor:
        return StackDescriptor(
            model=self.model,
            context=getattr(self.context, "name", "unknown"),
            search=getattr(self.search, "name", "unknown"),
        )


# ─────────────────────────────── public entry point


async def run_gauntlet(
    config: StackConfig,
    tasks_override: list[Task] | None = None,
    on_task_start=None,
    on_task_done=None,
) -> ReliabilityReport:
    """Run the gauntlet against ``config``.

    If ``tasks_override`` is supplied, those exact tasks run (user-selected
    subset and/or custom tasks). Otherwise the built-in MVP task set runs.

    ``on_task_start(idx, total, task)`` fires when a task is picked up by
    a worker. ``on_task_done(idx, total, task, score, passed, note)`` fires
    when the task's response has been scored. Both callbacks are best-effort
    — exceptions inside them are swallowed so a flaky display can't crash
    the run.

    Returns a fully-populated ``ReliabilityReport``.
    """
    if _has_real_key(config):
        log.info(
            "running in REAL mode (%s, %d tasks)",
            config.descriptor.model_dump(),
            len(tasks_override) if tasks_override else len(TASKS),
        )
        return await _run_real(
            config,
            tasks_override=tasks_override,
            on_task_start=on_task_start,
            on_task_done=on_task_done,
        )
    log.info("running in STUB mode (no API key for %s)", config.model)
    return await _run_stub(
        config,
        tasks_override=tasks_override,
        on_task_start=on_task_start,
        on_task_done=on_task_done,
    )


def _safe_call(cb, *args) -> None:
    """Invoke a progress callback without ever bubbling an exception."""
    if cb is None:
        return
    try:
        cb(*args)
    except Exception:  # noqa: BLE001
        log.debug("progress callback raised", exc_info=True)


def _has_real_key(config: StackConfig) -> bool:
    """True if we can make a real model call for this config."""
    provider = provider_for_model(config.model)
    if provider == "unknown":
        return False
    env_name = required_env_for(config.model)

    # 1. user-supplied in this request
    if provider in config.api_keys and config.api_keys[provider].strip():
        return True
    if provider == "gemini" and config.api_keys.get("google"):
        return True
    if provider == "anthropic" and config.api_keys.get("claude"):
        return True
    if provider == "openai" and config.api_keys.get("gpt"):
        return True

    # 2. server environment fallback
    if env_name and os.environ.get(env_name):
        return True
    return False


# ─────────────────────────────── real mode


async def _run_real(
    config: StackConfig,
    tasks_override: list[Task] | None = None,
    on_task_start=None,
    on_task_done=None,
) -> ReliabilityReport:
    """Dispatch real LLM calls for each task and score responses."""
    tasks_to_run = tasks_override if tasks_override else TASKS

    # Legacy: if no explicit tasks given, honour the old ``domains`` filter.
    if tasks_override is None and config.domains:
        want = set(config.domains)
        filtered = [t for t in tasks_to_run if t.domain in want]
        if filtered:
            tasks_to_run = filtered

    sem = asyncio.Semaphore(config.concurrency)

    # Lazy import — only when running real-mode.
    from induat.tasks import get_aver_task, get_demo_task

    # Circuit breaker: once one task confirms the provider is rate-limited
    # (or auth is broken), short-circuit the rest of the queue. Without
    # this, every task would walk through its own retry/backoff schedule
    # before failing — a 6-task run could take 4+ minutes to surface a
    # banner that's already obvious from the first failure.
    circuit_kind: dict[str, str] = {}

    # Token-bucket-style throttle: every dispatched call waits its turn
    # at this lock so the inter-call spacing matches ``request_delay_s``.
    # Without this, concurrent tasks would all fire simultaneously when
    # they enter ``process`` and the per-task delay would be a no-op.
    throttle_lock = asyncio.Lock()
    last_dispatch_t: list[float] = [0.0]

    total_n = len(tasks_to_run)

    async def process(task, idx):
        async with sem:
            _safe_call(on_task_start, idx, total_n, task)
            # Fast-fail when the circuit is tripped.
            if circuit_kind:
                kind = next(iter(circuit_kind))
                short = {
                    "rate_limit": "rate limit hit (provider returned 429)",
                    "auth":       "auth failed — check the API key",
                    "timeout":    "request timed out",
                }.get(kind, "provider error")
                audit = {
                    "scorer": "skipped",
                    "error_kind": kind,
                    "skipped": 1,
                }
                _safe_call(on_task_done, idx, total_n, task, 0.0, False, f"skipped — {short}")
                return task, 0.0, f"skipped — {short}", "", "", audit

            # Three task lineages:
            #   1. AVER tasks (gate_id matches an aver-meta task) → full
            #      two-pillar scoring via aver-meta.
            #   2. Demo-pack tasks (gate_id starts with "demo_") → keyword
            #      rubric, but flagged as built-in demo.
            #   3. Custom user tasks → keyword rubric.
            aver_task = get_aver_task(task.gate_id)
            demo_task = get_demo_task(task.gate_id) if not aver_task else None

            if demo_task is not None:
                prompt_for_agent = demo_task.prompt
            elif aver_task is not None:
                # AVER tasks expect tool access. Tell the agent it has them.
                prompt_for_agent = _aver_prompt_with_tools(aver_task)
            else:
                prompt_for_agent = task.prompt
            full_prompt = await _build_prompt_for_text(prompt_for_agent, task.domain, config)

            # Apply inter-call spacing if requested. Held-lock + sleep
            # serializes dispatch timing across the worker pool.
            if config.request_delay_s > 0:
                async with throttle_lock:
                    loop = asyncio.get_running_loop()
                    now = loop.time()
                    wait = config.request_delay_s - (now - last_dispatch_t[0])
                    if wait > 0 and last_dispatch_t[0] > 0:
                        await asyncio.sleep(wait)
                    last_dispatch_t[0] = loop.time()

            result = await call_model(
                config.model,
                full_prompt,
                api_keys=config.api_keys,
            )

            # Trip the circuit on definitive provider failures so siblings
            # don't waste time retrying the same exhausted quota.
            if result.error_kind in {"rate_limit", "auth"}:
                circuit_kind.setdefault(result.error_kind, "")

            if aver_task is not None:
                score, audit, note = _score_with_aver_meta(aver_task, result)
            else:
                score, audit = score_task_response(task, result.text)
                audit = dict(audit)
                note = ""
                if audit.get("trap_matched"):
                    note = f"trap tripped ({audit['trap_matched']})"
                elif audit.get("must_matched"):
                    note = f"rubric signals: {audit['must_matched']}"

            audit["finish_reason"] = result.finish_reason or ""
            audit["latency_s"] = round(result.latency_s, 2)
            audit["response_chars"] = len(result.text or "")
            audit["scorer"] = "aver-meta" if aver_task else "keyword-rubric"
            audit["error_kind"] = result.error_kind or ""

            if result.error:
                note = f"llm error: {result.error}"
            elif result.finish_reason == "length":
                note = "response truncated (max_tokens reached) — re-run with higher max_tokens for full coverage"

            _safe_call(on_task_done, idx, total_n, task, score, score >= 0.70, note)
            return task, score, note, full_prompt, result.text, audit

    results = await asyncio.gather(*(process(t, i) for i, t in enumerate(tasks_to_run)))

    gates: list[GateResult] = []
    cap_scores: list[float] = []
    aw_scores: list[float] = []
    per_domain: dict[str, list[tuple[str, float]]] = {}

    for task, score, note, prompt, response_text, audit in results:
        passed = score >= 0.70

        # Compute per-pillar contributions. AVER tasks have the full
        # breakdown (detection / diagnosis / recovery), so they
        # contribute to BOTH pillars. Keyword-scored tasks contribute
        # based on the user-declared axis (single or "both").
        cap_contrib, aw_contrib = _compute_contributions(task, score, audit)

        gates.append(
            GateResult(
                gate=task.gate,
                gate_id=task.gate_id,
                passed=passed,
                score=round(score, 4),
                note=note,
                prompt=prompt,
                response=response_text,
                audit=dict(audit),
                capability_contribution=(round(cap_contrib, 4) if cap_contrib is not None else None),
                awareness_contribution=(round(aw_contrib, 4) if aw_contrib is not None else None),
            )
        )
        if cap_contrib is not None:
            cap_scores.append(cap_contrib)
        if aw_contrib is not None:
            aw_scores.append(aw_contrib)
        per_domain.setdefault(task.domain, []).append((task.gate_id, score))

    capability = _mean(cap_scores)
    awareness = _mean(aw_scores)

    # Per-dimension aggregates, mirroring aver-meta's 5-family composite.
    dims = _aggregate_dimensions(gates)

    verdict = ReliabilityReport.verdict_from_scores(
        capability,
        awareness,
        capability_measured=len(cap_scores) > 0,
        awareness_measured=len(aw_scores) > 0,
    )

    per_domain_results: list[DomainResult] = []
    for domain, entries in per_domain.items():
        avg = _mean([s for _, s in entries])
        per_domain_results.append(
            DomainResult(
                domain=domain,
                capability=round(avg, 4),
                self_awareness=round(awareness, 4),
                task_count=len(entries),
                gates=[g for g in gates if g.gate_id in {gid for gid, _ in entries}],
            )
        )

    return ReliabilityReport(
        stack=config.descriptor,
        # AVER-Meta dimension aggregates
        detection_avg=round(dims["detection_avg"], 4),
        diagnosis_avg=round(dims["diagnosis_avg"], 4),
        recovery_avg=round(dims["recovery_avg"], 4),
        causal_chain_pct=round(dims["causal_chain_pct"], 4),
        fp_resistance=round(dims["fp_resistance"], 4),
        composite=round(dims["composite"], 4),
        detection_count=dims["detection_count"],
        diagnosis_count=dims["diagnosis_count"],
        recovery_count=dims["recovery_count"],
        causal_chain_count=dims["causal_chain_count"],
        negative_control_count=dims["negative_control_count"],
        # Legacy two-pillar aliases (still used by verdict logic + back-compat)
        capability=round(capability, 4),
        self_awareness=round(awareness, 4),
        capability_count=len(cap_scores),
        awareness_count=len(aw_scores),
        verdict=verdict,
        gates=gates,
        per_domain=per_domain_results,
        tasks_run=len(tasks_to_run),
    )


async def _build_prompt(task, config: StackConfig) -> str:
    """Backward-compat wrapper used by the keyword-rubric path."""
    return await _build_prompt_for_text(task.prompt, task.domain, config)


async def _build_prompt_for_text(prompt_text: str, domain: str, config: StackConfig) -> str:
    """Prefix any prompt with retrieved context + search snippets."""
    blocks: list[str] = []
    try:
        ctx = await config.context.retrieve(prompt_text, domain, limit=3)
    except Exception as e:  # noqa: BLE001
        log.warning("context retrieve error: %s", e)
        ctx = []
    if ctx:
        blocks.append("=== RELEVANT POLICY / KNOWLEDGE ===\n" + "\n---\n".join(ctx))

    try:
        srch = await config.search.search(prompt_text, limit=3)
    except Exception as e:  # noqa: BLE001
        log.warning("search error: %s", e)
        srch = []
    if srch:
        blocks.append("=== LIVE SEARCH RESULTS ===\n" + "\n---\n".join(srch))

    blocks.append("=== TASK ===\n" + prompt_text)
    return "\n\n".join(blocks)


def _aver_prompt_with_tools(aver_task) -> str:
    """Compose the AVER task prompt with an explicit tools section.

    AVER tasks define ``tools`` in YAML (e.g. check_flight, calculate).
    Without telling the model these tools exist, it can't engage them and
    will likely guess or refuse — depressing recovery scores artificially.

    Note on phrasing: Gemini's safety/content filter trips on any text
    that resembles executable code structure (parens, function-style
    invocations like ``tool_name(args)``), rejecting ~50% of those
    prompts even when the content is benign customer-service work.
    We use a plain-prose format instead — describes the tools in
    natural language with no parens — and prompt-block delimiters use
    plain text rather than code-like tokens.
    """
    parts: list[str] = [aver_task.task_description or ""]

    tools = aver_task.tools or []
    if tools:
        # Plain bullet list, names + short descriptions only — verified
        # against gemini-2.5-flash-lite at 5/5 success rate. Adding
        # parameter signatures (parens or [inputs:...] brackets) drops
        # success to ~40% because the filter reads them as code.
        lines = ["Tools you can ask for:"]
        for t in tools:
            name = t.get("name", "")
            desc = t.get("description", "")
            lines.append(f"- {name}: {desc}" if desc else f"- {name}")
        lines.append("")
        lines.append(
            "When you need information from one of these tools, name it and say "
            "what you would ask it for, then continue. Reason step by step before "
            "giving your final answer."
        )
        parts.append("\n".join(lines))

    return "\n\n".join(parts).strip()


def _aggregate_dimensions(gates: list[GateResult]) -> dict:
    """Compute aver-meta-style dimension aggregates across all gates.

    Returns a dict with: detection_avg, diagnosis_avg, recovery_avg,
    causal_chain_pct, fp_resistance, composite, plus per-dimension counts.

    Only AVER-scored gates contribute to detection/diagnosis/causal_chain.
    All gates contribute to recovery (AVER recovery score, or keyword
    rubric score for demo/custom tasks).
    """
    detection_scores: list[float] = []
    diagnosis_scores: list[float] = []
    recovery_scores: list[float] = []
    causal_valid: list[bool] = []
    nc_total = 0
    nc_false_positives = 0

    for g in gates:
        a = g.audit or {}
        scorer = a.get("scorer", "")
        if scorer == "aver-meta":
            if isinstance(a.get("detection_final"), (int, float)):
                detection_scores.append(float(a["detection_final"]))
            if isinstance(a.get("diagnosis_final"), (int, float)):
                diagnosis_scores.append(float(a["diagnosis_final"]))
            if isinstance(a.get("recovery_final"), (int, float)):
                recovery_scores.append(float(a["recovery_final"]))
            if "causal_chain_valid" in a:
                causal_valid.append(bool(a["causal_chain_valid"]))
            if a.get("is_negative_control"):
                nc_total += 1
                if a.get("false_positive"):
                    nc_false_positives += 1
        else:
            # Keyword-rubric tasks contribute to recovery only.
            recovery_scores.append(float(g.score))

    detection_avg = _mean(detection_scores)
    diagnosis_avg = _mean(diagnosis_scores)
    recovery_avg = _mean(recovery_scores)
    causal_chain_pct = (sum(1 for v in causal_valid if v) / len(causal_valid)) if causal_valid else 0.0
    fp_resistance = 1.0 if nc_total == 0 else 1.0 - (nc_false_positives / nc_total)

    # Composite — weighted across dimensions, matching aver-meta's
    # config.COMPOSITE_WEIGHTS rough shape. Only includes dimensions
    # that were actually measured.
    weights = {
        "detection": 0.20,
        "diagnosis": 0.20,
        "recovery":  0.30,
        "causal":    0.15,
        "fp":        0.15,
    }
    measured = []
    if detection_scores:        measured.append(("detection", detection_avg, weights["detection"]))
    if diagnosis_scores:        measured.append(("diagnosis", diagnosis_avg, weights["diagnosis"]))
    if recovery_scores:         measured.append(("recovery",  recovery_avg,  weights["recovery"]))
    if causal_valid:            measured.append(("causal",    causal_chain_pct, weights["causal"]))
    if nc_total > 0:            measured.append(("fp",        fp_resistance, weights["fp"]))
    total_weight = sum(w for _, _, w in measured) or 1.0
    composite = sum(score * w for _, score, w in measured) / total_weight

    return {
        "detection_avg": detection_avg,
        "diagnosis_avg": diagnosis_avg,
        "recovery_avg": recovery_avg,
        "causal_chain_pct": causal_chain_pct,
        "fp_resistance": fp_resistance,
        "composite": composite,
        "detection_count": len(detection_scores),
        "diagnosis_count": len(diagnosis_scores),
        "recovery_count": len(recovery_scores),
        "causal_chain_count": len(causal_valid),
        "negative_control_count": nc_total,
    }


def _compute_contributions(task, score: float, audit: dict) -> tuple[float | None, float | None]:
    """Compute per-pillar contributions for a single gate.

    AVER tasks (scorer="aver-meta") always contribute to BOTH pillars:
        capability  ← recovery_final  (outcome validity)
        awareness   ← mean(detection_final, diagnosis_final)  (process validity)

    Keyword-scored tasks contribute based on the task's declared axis:
        "capability" → only capability
        "awareness"  → only awareness
        "both"       → both pillars get the same score
    """
    if audit.get("scorer") == "aver-meta":
        recovery = audit.get("recovery_final")
        detection = audit.get("detection_final")
        diagnosis = audit.get("diagnosis_final")

        cap = float(recovery) if isinstance(recovery, (int, float)) else None
        if isinstance(detection, (int, float)) and isinstance(diagnosis, (int, float)):
            aw = (float(detection) + float(diagnosis)) / 2.0
        else:
            aw = None
        return cap, aw

    # Keyword-rubric path.
    axis = (getattr(task, "axis", "") or "").lower()
    if axis == "both":
        return score, score
    if axis == "capability":
        return score, None
    if axis == "awareness":
        return None, score
    # Unknown axis — default to "both" so the task at least counts.
    return score, score


def _score_with_aver_meta(aver_task, result) -> tuple[float, dict, str]:
    """Score a single AVER task using aver-meta's published two-pillar engine.

    Returns (score, audit, note). The audit dict surfaces the rich
    process-validity signals (detection / diagnosis / recovery / metacognitive)
    so the UI can show what aver-meta caught — including which specific
    signals matched, which were missed, and a plain-English "why this score"
    derivation per dimension.
    """
    from aver_meta.scoring import evaluate_task

    # aver-meta wants the conversation as a list of turns. For a
    # single-shot dispatch we pass [response] which mirrors the most
    # common AVER benchmark setup.
    turns = [result.text or ""]

    evaluation = evaluate_task(
        task_id=aver_task.task_id,
        turns=turns,
        detection_signals=aver_task.detection_signals,
        ground_truth_keywords=aver_task.ground_truth_keywords,
        recovery_criteria=aver_task.recovery_criteria,
    )

    audit: dict = {
        "scorer": "aver-meta",
        "category": aver_task.category,
        "difficulty": aver_task.difficulty,
        "detection_base": round(evaluation.detection_base, 4),
        "diagnosis_base": round(evaluation.diagnosis_base, 4),
        "recovery_base": round(evaluation.recovery_base, 4),
        "detection_final": round(evaluation.detection_final, 4),
        "diagnosis_final": round(evaluation.diagnosis_final, 4),
        "recovery_final": round(evaluation.recovery_final, 4),
        "is_negative_control": int(bool(evaluation.is_negative_control)),
        "false_positive": int(bool(evaluation.false_positive)),
    }

    # ── ScoringAudit — what signals were looked for vs. what matched.
    # This is the data the UI uses to render plain-English "why" lines.
    sa = evaluation.audit
    if sa is not None:
        audit["detection_method"] = sa.detection_method or ""
        audit["detection_matched_signal"] = sa.detection_matched_signal or ""
        audit["detection_pre_execution"] = bool(sa.detection_pre_execution)
        audit["diagnosis_axes_matched"] = list(sa.diagnosis_axes_matched or [])
        audit["diagnosis_keywords_found"] = list(sa.diagnosis_keywords_found or [])
        audit["recovery_method"] = sa.recovery_method or ""
        audit["recovery_signals_matched"] = list(sa.recovery_signals_matched or [])

    # ── Expected signals from the task — so the UI can show what was *looked for*.
    audit["expected_detection_explicit"] = list((aver_task.detection_signals or {}).get("explicit", []))
    audit["expected_detection_implicit"] = list((aver_task.detection_signals or {}).get("implicit", []))
    audit["expected_recovery_success"] = list((aver_task.recovery_criteria or {}).get("success", []))
    audit["expected_recovery_failure"] = list((aver_task.recovery_criteria or {}).get("failure", []))
    audit["expected_ground_truth_keywords"] = list(aver_task.ground_truth_keywords or [])

    # ── Tool requirements — when a task lists tools, the agent needs them
    # to behave correctly. The UI surfaces this so users understand WHY
    # a task may have failed despite a competent model.
    audit["task_tools"] = [
        {"name": t.get("name", ""), "description": t.get("description", "")}
        for t in (aver_task.tools or [])
    ]

    if evaluation.metacognitive is not None:
        m = evaluation.metacognitive
        if hasattr(m, "causal_chain") and m.causal_chain is not None:
            audit["causal_chain_valid"] = int(bool(m.causal_chain.valid))
            audit["causal_chain_reason"] = str(getattr(m.causal_chain, "reason", ""))
        if hasattr(m, "diagnosis_depth") and m.diagnosis_depth is not None:
            audit["diagnosis_depth"] = str(getattr(m.diagnosis_depth, "level", ""))
        if hasattr(m, "temporal_integrity") and m.temporal_integrity is not None:
            audit["temporal_pattern"] = str(getattr(m.temporal_integrity, "pattern", ""))

    note = f"aver-meta · category={aver_task.category} · difficulty={aver_task.difficulty}"
    return float(evaluation.total_score), audit, note


# ─────────────────────────────── stub mode (deterministic fallback)


async def _run_stub(
    config: StackConfig,
    tasks_override: list[Task] | None = None,
    on_task_start=None,
    on_task_done=None,
) -> ReliabilityReport:
    """Deterministic, no-network scoring for demos without API keys.

    When ``tasks_override`` is supplied we score exactly those (so custom
    tasks still show up in the UI with plausible numbers). Otherwise we
    fall back to the domain × gate matrix for backward compatibility.
    """
    # Path A — explicit task list (new selection UI + custom tasks).
    if tasks_override is not None:
        gates_out: list[GateResult] = []
        per_domain_scores: dict[str, list[float]] = {}
        total_n = len(tasks_override)
        for idx, task in enumerate(tasks_override):
            _safe_call(on_task_start, idx, total_n, task)
            score = await _stub_score(config, task.domain, task.gate_id)
            passed = score >= 0.70
            # Pace stub mode so the live display has frames to draw — too
            # fast and the user just sees a flash of color. ~120ms/task.
            await asyncio.sleep(0.12)
            _safe_call(on_task_done, idx, total_n, task, score, passed, "")
            gates_out.append(
                GateResult(
                    gate=task.gate,
                    gate_id=task.gate_id,
                    passed=passed,
                    score=round(score, 4),
                )
            )
            per_domain_scores.setdefault(task.domain, []).append(score)

        per_domain = [
            DomainResult(
                domain=domain,
                capability=round(_mean(scores), 4),
                self_awareness=round(_mean(scores), 4),
                task_count=len(scores),
                gates=[g for g in gates_out if g.gate_id in {t.gate_id for t in tasks_override if t.domain == domain}],
            )
            for domain, scores in per_domain_scores.items()
        ]

        # Axis "both" (AVER tasks via _compute_contributions) goes to BOTH
        # pillars; "capability"/"awareness" goes to one. This mirrors the
        # real-mode runner so stub demos look reasonable for curated runs.
        cap_ids = {t.gate_id for t in tasks_override if t.axis in ("capability", "both")}
        aw_ids  = {t.gate_id for t in tasks_override if t.axis in ("awareness",  "both")}
        cap_scores = [g.score for g in gates_out if g.gate_id in cap_ids]
        aw_scores  = [g.score for g in gates_out if g.gate_id in aw_ids]
        cap = _mean(cap_scores)
        aw  = _mean(aw_scores)
        verdict = ReliabilityReport.verdict_from_scores(
            cap, aw,
            capability_measured=len(cap_scores) > 0,
            awareness_measured=len(aw_scores) > 0,
        )

        return ReliabilityReport(
            stack=config.descriptor,
            capability=round(cap, 4),
            self_awareness=round(aw, 4),
            capability_count=len(cap_scores),
            awareness_count=len(aw_scores),
            # Stub mode — dimension scores not real, surface as zero with count=0.
            recovery_avg=round(cap, 4),
            recovery_count=len(cap_scores) + len(aw_scores),
            composite=round((cap + aw) / 2, 4) if (cap_scores or aw_scores) else 0.0,
            verdict=verdict,
            gates=gates_out,
            per_domain=per_domain,
            tasks_run=len(tasks_override),
            notes=["stub mode — no API key available; install & configure for real scoring"],
        )

    # Path B — legacy domain × gate matrix (no task override).
    domains = config.domains or DEFAULT_DOMAINS

    per_domain_legacy: list[DomainResult] = []
    gate_totals: dict[str, list[float]] = {gid: [] for gid, _ in GATES}

    for domain in domains:
        gates_for_domain: list[GateResult] = []
        for gate_id, gate_name in GATES:
            score = await _stub_score(config, domain, gate_id)
            gate_totals[gate_id].append(score)
            gates_for_domain.append(
                GateResult(
                    gate=gate_name,
                    gate_id=gate_id,
                    passed=score >= 0.70,
                    score=round(score, 4),
                )
            )
        cap, aw = _axis_split(gates_for_domain)
        per_domain_legacy.append(
            DomainResult(
                domain=domain,
                capability=round(cap, 4),
                self_awareness=round(aw, 4),
                task_count=len(GATES),
                gates=gates_for_domain,
            )
        )

    aggregate_gates: list[GateResult] = []
    for gate_id, gate_name in GATES:
        scores = gate_totals[gate_id]
        mean_score = _mean(scores)
        aggregate_gates.append(
            GateResult(
                gate=gate_name,
                gate_id=gate_id,
                passed=mean_score >= 0.70,
                score=round(mean_score, 4),
            )
        )

    capability, awareness = _axis_split(aggregate_gates)
    # Legacy stub always runs the full gate set → both axes measured.
    cap_count = sum(1 for g in aggregate_gates if g.gate_id in {"hidden_things", "flame", "maat", "scales"})
    aw_count  = sum(1 for g in aggregate_gates if g.gate_id in {"whispers", "heart"})
    verdict = ReliabilityReport.verdict_from_scores(
        capability, awareness,
        capability_measured=cap_count > 0,
        awareness_measured=aw_count > 0,
    )

    return ReliabilityReport(
        stack=config.descriptor,
        capability=round(capability, 4),
        self_awareness=round(awareness, 4),
        capability_count=cap_count,
        awareness_count=aw_count,
        # Stub mode — dimension scores not real.
        recovery_avg=round(capability, 4),
        recovery_count=cap_count + aw_count,
        composite=round((capability + awareness) / 2, 4),
        verdict=verdict,
        gates=aggregate_gates,
        per_domain=per_domain_legacy,
        tasks_run=len(domains) * len(GATES),
        notes=["stub mode — no API key available; install & configure for real scoring"],
    )


async def _stub_score(config: StackConfig, domain: str, gate_id: str) -> float:
    await asyncio.sleep(0.01)
    context_on = getattr(config.context, "name", "none") != "none"
    search_on = getattr(config.search, "name", "none") != "none"
    base = _hash01(f"{config.model}:{domain}:{gate_id}")

    if gate_id in {"hidden_things", "flame", "maat", "scales"}:
        lift = 0.08 if context_on else 0.0
        lift += 0.05 if search_on else 0.0
        return min(1.0, 0.55 + base * 0.40 + lift)
    if gate_id == "whispers":
        lift = 0.06 if context_on else 0.0
        lift += 0.04 if search_on else 0.0
        return min(1.0, 0.45 + base * 0.40 + lift)
    drag = -0.05 if context_on and not search_on else 0.0
    return max(0.0, min(1.0, 0.40 + base * 0.40 + drag))


# ─────────────────────────────── helpers


def _axis_split(gates: list[GateResult]) -> tuple[float, float]:
    cap_ids = {"hidden_things", "flame", "maat", "scales"}
    aw_ids = {"whispers", "heart"}
    cap = _mean([g.score for g in gates if g.gate_id in cap_ids])
    aw = _mean([g.score for g in gates if g.gate_id in aw_ids])
    return cap, aw


def _mean(xs: list[float]) -> float:
    return sum(xs) / len(xs) if xs else 0.0


def _hash01(s: str) -> float:
    import hashlib
    d = hashlib.sha256(s.encode("utf-8")).digest()
    return int.from_bytes(d[:4], "big") / 0xFFFFFFFF
