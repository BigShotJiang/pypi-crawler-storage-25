"""Baseline search plugin — returns nothing."""
from __future__ import annotations


class NoneSearch:
    """Search plugin that returns an empty list for every query."""

    name = "none"

    async def search(
        self,
        query: str,  # noqa: ARG002
        *,
        limit: int = 5,  # noqa: ARG002
    ) -> list[str]:
        return []
