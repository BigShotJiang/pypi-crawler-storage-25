"""Tavily live-search adapter.

Wraps Tavily's search API:

    ``POST https://api.tavily.com/search``
    headers: Authorization: Bearer tvly-...
    body: {query, max_results, search_depth?, ...}
    response: {results: [{title, url, content, score}, ...]}

Reference: https://docs.tavily.com/docs/rest-api/api-reference

Notes on robustness:

  * Tavily caps the ``query`` field around 400 characters and returns
    HTTP 400 for longer payloads. The runner passes the agent's full
    task prompt to ``search(query, …)``, which can easily exceed that
    limit, so we truncate before sending.
  * We send the API key as both an ``Authorization: Bearer`` header
    (modern format) and the legacy ``api_key`` body field, so the
    plugin works against both old and new Tavily backends.
  * On error we log Tavily's response body, not just the HTTP status,
    so users can tell whether they hit rate limits, a quota issue, or
    a bad request.
"""
from __future__ import annotations

import logging
import os

import httpx

log = logging.getLogger("induat.tavily")

# Tavily's hard limit is around 400 chars; leave a small safety margin.
_MAX_QUERY_LEN = 380


class TavilySearch:
    """Live web search via Tavily."""

    name = "tavily"

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str = "https://api.tavily.com",
        search_depth: str = "basic",
        timeout: float = 15.0,
    ) -> None:
        self.api_key = api_key or os.environ.get("TAVILY_API_KEY")
        if not self.api_key:
            raise RuntimeError(
                "TavilySearch requires TAVILY_API_KEY env var or explicit api_key."
            )
        self.base_url = base_url.rstrip("/")
        self.search_depth = search_depth
        self.timeout = timeout

    async def search(
        self,
        query: str,
        *,
        limit: int = 5,
    ) -> list[str]:
        # Tavily 400s on long queries — trim before sending. Truncating
        # at a token-ish boundary (last whitespace) keeps the search
        # term meaningful instead of cutting mid-word.
        q = (query or "").strip()
        if len(q) > _MAX_QUERY_LEN:
            cutoff = q.rfind(" ", 0, _MAX_QUERY_LEN) or _MAX_QUERY_LEN
            q = q[:cutoff].rstrip()
        if not q:
            return []

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(
                    f"{self.base_url}/search",
                    headers={
                        "Authorization": f"Bearer {self.api_key}",
                        "Content-Type": "application/json",
                    },
                    json={
                        # Pass api_key in the body too — older Tavily
                        # accounts still authenticate this way.
                        "api_key": self.api_key,
                        "query": q,
                        "max_results": limit,
                        "search_depth": self.search_depth,
                    },
                )
        except httpx.RequestError as e:
            log.warning("tavily request failed (network/timeout): %s", e)
            return []

        if response.status_code >= 400:
            # Surface Tavily's own error message — much more useful than
            # the bare status line. Keep it short to stay readable in
            # the CLI's stderr capture.
            try:
                detail = response.json()
            except Exception:  # noqa: BLE001
                detail = response.text
            log.warning(
                "tavily %d for query (%d chars): %s",
                response.status_code, len(q),
                str(detail)[:200],
            )
            return []

        try:
            data = response.json()
        except Exception as e:  # noqa: BLE001
            log.warning("tavily returned non-JSON response: %s", e)
            return []

        results = data.get("results") or []
        return [r.get("content", "") for r in results if r.get("content")]
