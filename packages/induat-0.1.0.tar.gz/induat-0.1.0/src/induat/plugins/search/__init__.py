"""Search-tool plugin registry.

See ``induat.plugins.context.__init__`` for the same pattern.
"""
from __future__ import annotations

from induat.plugins.base import SearchPlugin
from induat.plugins.search.none import NoneSearch
from induat.plugins.search.tavily import TavilySearch

REGISTRY: dict[str, type[SearchPlugin]] = {
    NoneSearch.name: NoneSearch,
    TavilySearch.name: TavilySearch,
}

__all__ = ["REGISTRY", "NoneSearch", "TavilySearch"]
