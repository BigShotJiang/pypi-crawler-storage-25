"""Plugin system for induat.

Two plugin categories:
    * context — retrieve relevant passages given a query + domain
    * search  — live search / tool augmentation

Each plugin is a thin adapter (~30 lines). See `plugins.base` for the
protocols and the `context/` and `search/` packages for concrete
implementations and the registries.
"""

from induat.plugins.base import ContextPlugin, SearchPlugin
from induat.plugins import context, search

__all__ = ["ContextPlugin", "SearchPlugin", "context", "search"]
