"""Plugin protocols for induat.

Plugins are thin adapters between induat's gauntlet runner and external
infrastructure (context layers, search tools, custom retrievers).

Two protocols, both small on purpose:

    ContextPlugin.retrieve(query, domain, *, limit) -> list[str]
    SearchPlugin.search(query, *, limit) -> list[str]

A plugin returns ranked text passages. induat injects them into the
agent's prompt context before each task runs.

Implementations live in ``induat.plugins.context`` and
``induat.plugins.search`` and register themselves via their package
registries (see each ``__init__.py``).
"""
from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class ContextPlugin(Protocol):
    """Context-layer adapter.

    Implementations wrap a context service (Qontext, Mem0, Letta, ...)
    and return passages relevant to a given query within a domain.
    """

    name: str
    """Short identifier used in CLI + API. Lowercase, no spaces."""

    async def retrieve(
        self,
        query: str,
        domain: str,
        *,
        limit: int = 5,
    ) -> list[str]:
        """Return ranked text passages relevant to ``query`` in ``domain``.

        Must be async. Return an empty list when the adapter has no
        relevant knowledge (e.g. the baseline ``NoneContext``).
        """
        ...


@runtime_checkable
class SearchPlugin(Protocol):
    """Live-search adapter.

    Implementations wrap a search API (Tavily, Brave, custom) and
    return snippets relevant to a query.
    """

    name: str
    """Short identifier used in CLI + API. Lowercase, no spaces."""

    async def search(
        self,
        query: str,
        *,
        limit: int = 5,
    ) -> list[str]:
        """Return ranked search snippets relevant to ``query``."""
        ...
