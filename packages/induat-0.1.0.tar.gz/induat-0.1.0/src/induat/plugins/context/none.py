"""Baseline context plugin — returns nothing.

Used to establish a vanilla measurement against which augmentation
effects are compared. Pairs with ``search.none.NoneSearch`` for a fully
unaugmented baseline.
"""
from __future__ import annotations


class NoneContext:
    """Context plugin that returns an empty list for every query."""

    name = "none"

    async def retrieve(
        self,
        query: str,  # noqa: ARG002
        domain: str,  # noqa: ARG002
        *,
        limit: int = 5,  # noqa: ARG002
    ) -> list[str]:
        return []
