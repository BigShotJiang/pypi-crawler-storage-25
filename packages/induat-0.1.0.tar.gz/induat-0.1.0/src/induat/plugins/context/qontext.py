"""Qontext context-layer adapter.

Wraps Qontext's retrieval API. One vault per AVER domain; the adapter
maintains a ``domain -> vault_id`` mapping.

    ``POST https://api.qontext.ai/v1/retrieval``
    headers: X-API-Key: q_sk_...
    body: {vaultId, prompt, limit, depth?, includeSources}
    response: {passages: [{text, source, score}, ...]}

Reference: https://docs.qontext.ai/api-reference
"""
from __future__ import annotations

import os

import httpx


class QontextContext:
    """Retrieve passages from a Qontext vault."""

    name = "qontext"

    def __init__(
        self,
        api_key: str | None = None,
        vault_map: dict[str, str] | None = None,
        base_url: str = "https://api.qontext.ai/v1",
        timeout: float = 15.0,
    ) -> None:
        self.api_key = api_key or os.environ.get("QONTEXT_API_KEY")
        if not self.api_key:
            raise RuntimeError(
                "QontextContext requires QONTEXT_API_KEY env var or explicit api_key."
            )
        self.vault_map = vault_map or {}
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    async def retrieve(
        self,
        query: str,
        domain: str,
        *,
        limit: int = 5,
    ) -> list[str]:
        vault_id = self.vault_map.get(domain)
        if not vault_id:
            # No vault provisioned for this domain → return nothing.
            # Caller treats this the same as NoneContext for the domain.
            return []

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.post(
                f"{self.base_url}/retrieval",
                headers={"X-API-Key": self.api_key},
                json={
                    "vaultId": vault_id,
                    "prompt": query,
                    "limit": limit,
                    "includeSources": True,
                },
            )
            response.raise_for_status()
            data = response.json()

        passages = data.get("passages") or data.get("results") or []
        return [p.get("text", "") for p in passages if p.get("text")]
