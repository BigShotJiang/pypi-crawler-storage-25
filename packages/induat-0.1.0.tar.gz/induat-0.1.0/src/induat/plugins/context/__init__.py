"""Context-layer plugin registry.

Adapters go in this package; the ``REGISTRY`` maps plugin names to
classes (not instances — each run builds its own instance so credentials
and per-run config are fresh).

Register an adapter by adding it here. Built-in adapters register
themselves at import time.
"""
from __future__ import annotations

from induat.plugins.base import ContextPlugin
from induat.plugins.context.mem0_plugin import Mem0Context
from induat.plugins.context.none import NoneContext

# Qontext used to ship as a built-in context layer but the demo focus is
# Mem0; the Qontext adapter still lives at ``induat.plugins.context.qontext``
# for users who want to wire it up themselves.
REGISTRY: dict[str, type[ContextPlugin]] = {
    NoneContext.name: NoneContext,
    Mem0Context.name: Mem0Context,
}

__all__ = ["REGISTRY", "NoneContext", "Mem0Context"]
