"""Mem0 context-layer adapter.

Wraps Mem0's hosted memory layer (https://mem0.ai). On each task,
the runner calls ``retrieve(query, domain)`` to pull relevant
memories for the user/agent under test. Returns ranked text passages
that the runner injects into the prompt before the LLM call.

For the integration demos we ship a small built-in memory pack
(SEED_MEMORIES) that gets pushed into the user's Mem0 cloud once on
first use. That way the demo tasks have something to retrieve without
the user having to pre-seed anything by hand.
"""
from __future__ import annotations

import logging
import os
from typing import Any

log = logging.getLogger("induat.mem0")


# ─────────────────────────── seeded memories
# These get pushed into the user's Mem0 cloud the first time the
# plugin runs. They power the "tool toggle changes the verdict" demo
# tasks. Each list entry is a single fact the agent should be able
# to recall when its prompt mentions the relevant customer / project.

SEED_USER_ID = "induat-demo"

SEED_MEMORIES: list[str] = [
    # Customer Sarah Chen (chen_8821) — used by demo_mem0_customer_tier
    "Customer Sarah Chen (account ID chen_8821) is a 5-year platinum-tier subscriber.",
    "Customer chen_8821 has filed three prior refund requests, all approved.",
    "Customer chen_8821 prefers email contact and has flagged 'no phone calls' "
    "in their account preferences.",
    "Customer chen_8821 lives in Berlin and uses the German-language interface.",

    # Customer Marcus Park (park_4412) — used by demo_mem0_preference
    "Customer Marcus Park (account ID park_4412) is a free-tier user.",
    "Customer park_4412 prefers SMS notifications over email for urgent matters.",
    "Customer park_4412 is on a payment plan after a delinquent invoice in Q1 2026.",

    # Project context — used by demo_combined
    "Project Atlas migration target date is 2026-06-15. Decision-maker is Sarah Chen.",
    "Project Atlas budget cap is $42,000 EUR — anything above requires CFO approval.",
]


class Mem0Context:
    """Retrieve passages from Mem0 cloud memory.

    Cloud client is from the official ``mem0ai`` package. We use a
    single ``user_id`` for all retrieval — induat is run-as-a-service,
    so per-end-user memory is the agent integrator's concern, not ours.
    """

    name = "mem0"

    def __init__(
        self,
        api_key: str | None = None,
        user_id: str = SEED_USER_ID,
        seed: bool = True,
    ) -> None:
        self.api_key = api_key or os.environ.get("MEM0_API_KEY")
        if not self.api_key:
            raise RuntimeError(
                "Mem0Context requires MEM0_API_KEY env var or explicit api_key. "
                "Get a key at https://app.mem0.ai/dashboard/api-keys"
            )
        # Lazy import — keeps the module importable even when mem0ai
        # isn't installed (the plugin registry can still list it as
        # available; it'll fail fast at instantiation).
        from mem0 import MemoryClient

        self.client = MemoryClient(api_key=self.api_key)
        self.user_id = user_id
        if seed:
            self._seed_if_empty()

    def _unwrap(self, raw: Any) -> list[dict]:
        """Normalize Mem0 cloud responses to a flat list of items.

        v2 returns ``{'count': N, 'results': [...], 'next': ...}`` for
        list-style endpoints and ``{'results': [...]}`` for search.
        Older clients return a flat list. Handle both shapes.
        """
        if isinstance(raw, dict):
            return raw.get("results") or []
        return list(raw or [])

    def _seed_if_empty(self) -> None:
        """Push the demo seed pack the first time we see this user_id.

        Mem0 stores derived 'memories' from messages, not raw strings,
        so re-seeding is idempotent at the surface level (the same
        underlying facts dedupe). We still skip the call when memories
        already exist to keep the demo fast.

        Note: Mem0's add() is asynchronous on the cloud — memories take
        ~10–30s to be searchable. We don't block on that here; the
        first run after a fresh seed may return empty, and subsequent
        runs will see the populated memories.
        """
        try:
            try:
                raw = self.client.get_all(filters={"user_id": self.user_id}, version="v2")
            except TypeError:
                raw = self.client.get_all(user_id=self.user_id)
            existing = self._unwrap(raw)
        except Exception as e:  # noqa: BLE001
            log.warning("mem0 get_all failed during seed-check: %s", e)
            existing = []
        # Heuristic: if at least most of our seed pack is already there,
        # skip. Use a low bar so we don't re-add on every restart.
        if len(existing) >= max(3, len(SEED_MEMORIES) // 2):
            log.debug("mem0 seed skipped — %d memories already present", len(existing))
            return
        log.info("mem0 seeding %d demo memories for user_id=%s "
                 "(processing is async — searches may need a few seconds to populate)",
                 len(SEED_MEMORIES), self.user_id)
        for fact in SEED_MEMORIES:
            try:
                self.client.add(
                    messages=[{"role": "user", "content": fact}],
                    user_id=self.user_id,
                )
            except Exception as e:  # noqa: BLE001
                log.warning("mem0 add failed for fact %r: %s", fact[:60], e)

    async def retrieve(
        self,
        query: str,
        domain: str,
        *,
        limit: int = 5,
    ) -> list[str]:
        """Search Mem0 for memories relevant to ``query``.

        ``domain`` is unused at the protocol level — Mem0 organizes by
        ``user_id``, not domain. We accept it for API parity with the
        other context plugins.
        """
        # The cloud client is sync; offload to a thread to keep the
        # async runner unblocked.
        import asyncio
        loop = asyncio.get_running_loop()

        def _do_search() -> list[dict[str, Any]]:
            # v2 wants filters dict; older clients use top-level user_id.
            try:
                return self.client.search(
                    query=query,
                    filters={"user_id": self.user_id},
                    version="v2",
                    limit=limit,
                ) or []
            except TypeError:
                return self.client.search(
                    query=query, user_id=self.user_id, limit=limit
                ) or []

        try:
            raw = await loop.run_in_executor(None, _do_search)
        except Exception as e:  # noqa: BLE001
            log.warning("mem0 search failed: %s", e)
            return []

        results = self._unwrap(raw)
        passages: list[str] = []
        for r in results:
            if isinstance(r, dict):
                txt = r.get("memory") or r.get("text") or r.get("content") or ""
                if txt:
                    passages.append(str(txt))
        return passages
