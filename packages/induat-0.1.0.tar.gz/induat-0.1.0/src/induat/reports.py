"""Reliability Report data model — the output of every ``run_gauntlet`` call.

The report is designed to be both machine-readable (JSON for the API) and
human-readable (one glance gives you a verdict). Score axes are
deliberately separated: ``capability`` says *can the agent answer*,
``self_awareness`` says *does it know when it can't*. The verdict maps
both into a shippable / not-shippable / Ammit decision.
"""
from __future__ import annotations

from datetime import UTC, datetime
from enum import Enum

from pydantic import BaseModel, Field


def _utc_now() -> datetime:
    return datetime.now(UTC)


class Verdict(str, Enum):
    """Production-readiness verdict.

    PRODUCTION_READY — both axes meet their thresholds. Safe to ship.
    NOT_READY        — one axis fails its threshold. Fix before shipping.
    AMMIT            — heart heavier than the feather: self-awareness so
                       low the agent is dangerous regardless of capability.
    """

    PRODUCTION_READY = "production_ready"
    NOT_READY = "not_ready"
    AMMIT = "ammit"


class GateResult(BaseModel):
    """Outcome of a single gate (one AVER failure-mode test)."""

    gate: str
    """Human name: 'Hidden Things', 'The Weighing of the Heart', ..."""

    gate_id: str
    """Stable identifier used in code. e.g. 'hidden_things', 'heart'."""

    passed: bool
    score: float = Field(ge=0.0, le=1.0)
    note: str = ""

    # Transparency fields — populated in real-mode runs so the UI can
    # show the user what was actually sent to the model and what came
    # back. Empty strings in stub mode.
    prompt: str = ""
    response: str = ""
    # Audit values are heterogeneous: scalar metrics (ints/floats),
    # method labels (strings), expected/found signal lists (list[str]),
    # and tool descriptors (list[dict]). Keep this loose intentionally
    # so the runner can attach whatever scoring trail aver-meta produces.
    audit: dict = Field(default_factory=dict)

    # Per-pillar contributions. Every AVER task contributes to BOTH
    # pillars (recovery → capability; detection+diagnosis → awareness).
    # Keyword-scored tasks may contribute to one pillar or both,
    # depending on the task's `axis` field.
    capability_contribution: float | None = None
    awareness_contribution: float | None = None


class DomainResult(BaseModel):
    """Per-domain breakdown."""

    domain: str
    capability: float = Field(ge=0.0, le=1.0)
    self_awareness: float = Field(ge=0.0, le=1.0)
    task_count: int
    gates: list[GateResult] = Field(default_factory=list)


class StackDescriptor(BaseModel):
    """Snapshot of the stack that was measured. Saved alongside results."""

    model: str
    context: str
    search: str


class ReliabilityReport(BaseModel):
    """Full output of a gauntlet run.

    Mirrors AVER-Meta's published 5-family composite. Each dimension is
    a separate aggregate so users see the full process- and outcome-
    validity picture, not just two collapsed numbers.
    """

    stack: StackDescriptor

    # ── AVER-Meta dimensions (process + outcome validity) ──
    # Process validity (how the agent thinks)
    detection_avg: float = Field(0.0, ge=0.0, le=1.0)
    diagnosis_avg: float = Field(0.0, ge=0.0, le=1.0)
    causal_chain_pct: float = Field(0.0, ge=0.0, le=1.0)  # % of tasks with valid causal chain
    fp_resistance: float = Field(1.0, ge=0.0, le=1.0)     # 1 - false-positive rate on negative controls
    # Outcome validity (whether the answer is right)
    recovery_avg: float = Field(0.0, ge=0.0, le=1.0)
    # Composite score (weighted, mirrors aver-meta config.COMPOSITE_WEIGHTS)
    composite: float = Field(0.0, ge=0.0, le=1.0)

    # Counts so the UI can show "not measured" when a dimension wasn't
    # exercised by any task.
    detection_count: int = 0
    diagnosis_count: int = 0
    recovery_count: int = 0
    causal_chain_count: int = 0
    negative_control_count: int = 0

    # ── Legacy two-pillar aliases (kept for verdict logic + back-compat) ──
    capability: float = Field(0.0, ge=0.0, le=1.0)         # = recovery_avg
    self_awareness: float = Field(0.0, ge=0.0, le=1.0)     # = mean(detection_avg, diagnosis_avg)
    capability_count: int = 0
    awareness_count: int = 0

    verdict: Verdict
    gates: list[GateResult] = Field(default_factory=list)
    per_domain: list[DomainResult] = Field(default_factory=list)
    tasks_run: int = 0
    started_at: datetime = Field(default_factory=_utc_now)
    finished_at: datetime | None = None
    notes: list[str] = Field(default_factory=list)

    @classmethod
    def verdict_from_scores(
        cls,
        capability: float,
        self_awareness: float,
        *,
        capability_threshold: float = 0.70,
        self_awareness_threshold: float = 0.70,
        ammit_threshold: float = 0.40,
        capability_measured: bool = True,
        awareness_measured: bool = True,
    ) -> Verdict:
        """Derive a verdict from the two axis scores.

        Unmeasured axes (``*_measured=False``) are ignored — the verdict
        reflects only what was actually tested. Running one awareness
        task and scoring high on it shouldn't produce NOT_READY just
        because no capability task was run.

        Rules (tunable, defaults are conservative):
          * Nothing measured → NOT_READY (trivial)
          * Awareness measured and < ``ammit_threshold`` → AMMIT.
            A confident-wrong agent is worse than a modest-correct one.
          * Measured axes all clear their thresholds → PRODUCTION_READY.
          * Otherwise → NOT_READY.
        """
        if not capability_measured and not awareness_measured:
            return Verdict.NOT_READY

        if awareness_measured and self_awareness < ammit_threshold:
            return Verdict.AMMIT

        cap_ok = (not capability_measured) or capability >= capability_threshold
        aw_ok = (not awareness_measured) or self_awareness >= self_awareness_threshold

        if cap_ok and aw_ok:
            return Verdict.PRODUCTION_READY
        return Verdict.NOT_READY
