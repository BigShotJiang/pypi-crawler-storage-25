"""FastAPI surface for induat.

Endpoints:
    POST /run        — run the gauntlet against a described stack.
    GET  /plugins    — list context + search plugins available in this build.
    GET  /gates      — list the gates the gauntlet will run.
    GET  /health     — liveness probe for Docker / load balancer.

The API is intentionally small. Keys are read from environment — the
API never accepts secrets in request bodies.
"""
from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from induat import __version__
from induat.plugins import context as context_pkg
from induat.plugins import search as search_pkg
from induat.reports import ReliabilityReport
from induat.runner import GATES, StackConfig, run_gauntlet

WEB_DIR = Path(__file__).parent / "web"

log = logging.getLogger("induat.api")
logging.basicConfig(level=os.environ.get("INDUAT_LOG_LEVEL", "INFO"))


@asynccontextmanager
async def lifespan(app: FastAPI):  # noqa: ARG001
    log.info("induat %s starting up", __version__)
    yield
    log.info("induat shutting down")


app = FastAPI(
    title="induat",
    description="Pre-production reliability test suite for AI agents.",
    version=__version__,
    lifespan=lifespan,
)

# ─── A2A protocol surface ───
# Mount the Agent2Agent JSON-RPC + agent-card endpoints so external
# agents can discover and call induat without installing the package or
# running the CLI. Mounted BEFORE the StaticFiles catch-all so the
# /.well-known/agent.json + /a2a routes win.
from induat.a2a import router as a2a_router  # noqa: E402
app.include_router(a2a_router, tags=["a2a"])


# ─────────────────────────────── request/response models


class RunRequest(BaseModel):
    """Describe the stack to measure."""

    model: str = Field(
        ...,
        description="Provider/model identifier. e.g. 'gemini-2.5-flash'.",
    )
    context: str = Field(
        "none",
        description="Context-layer plugin name. See GET /plugins.",
    )
    search: str = Field(
        "none",
        description="Search plugin name. See GET /plugins.",
    )
    domains: list[str] | None = Field(
        None,
        description="Optional list of AVER domains to restrict the run to.",
    )
    api_keys: dict[str, str] = Field(
        default_factory=dict,
        description=(
            "Optional per-request API keys. Keys map provider slugs to raw "
            "keys, e.g. {'gemini': 'AIza...', 'qontext': 'q_sk_...'}. "
            "Keys are used for this request only — never logged, never "
            "persisted. If omitted, the server falls back to env vars."
        ),
    )
    tasks: list["TaskInput"] | None = Field(
        None,
        description=(
            "Explicit list of tasks to run. If omitted, the server runs all "
            "built-in tasks. Each task carries its own prompt + rubric, so "
            "users can add custom tasks or run a subset."
        ),
    )


class ModelInfo(BaseModel):
    id: str
    provider: str
    requires_key: str


class ModelsResponse(BaseModel):
    models: list[ModelInfo]


class TaskInfo(BaseModel):
    """Full task data — the UI selects and edits tasks client-side."""
    gate_id: str
    gate: str
    axis: str
    domain: str
    prompt: str
    must: list[str] = Field(default_factory=list)
    must_not: list[str] = Field(default_factory=list)
    expected: str = ""
    builtin: bool = True
    # True for the curated 12-task pack — UI renders these with a star.
    curated: bool = False
    # Tool dependency hint: "" / "mem0" / "tavily" — UI badges these.
    needs: str = ""


class TasksResponse(BaseModel):
    tasks: list[TaskInfo]


class TaskInput(BaseModel):
    """Task shape accepted in POST /run. Same fields as TaskInfo sans 'builtin'."""
    gate_id: str
    gate: str
    axis: str = "capability"
    domain: str = "custom"
    prompt: str
    must: list[str] = Field(default_factory=list)
    must_not: list[str] = Field(default_factory=list)
    expected: str = ""


class PluginsResponse(BaseModel):
    context: list[str]
    search: list[str]


class GatesResponse(BaseModel):
    gates: list[dict]


# ─────────────────────────────── endpoints


@app.get("/health", tags=["system"])
async def health() -> dict[str, str]:
    """Liveness probe. Returns 200 OK when the service is up."""
    return {"status": "ok", "version": __version__}


@app.get("/plugins", response_model=PluginsResponse, tags=["system"])
async def list_plugins() -> PluginsResponse:
    return PluginsResponse(
        context=sorted(context_pkg.REGISTRY.keys()),
        search=sorted(search_pkg.REGISTRY.keys()),
    )


@app.get("/gates", response_model=GatesResponse, tags=["system"])
async def list_gates() -> GatesResponse:
    return GatesResponse(
        gates=[{"id": gid, "name": name} for gid, name in GATES],
    )


@app.get("/models", response_model=ModelsResponse, tags=["system"])
async def list_models() -> ModelsResponse:
    from induat.llm import MODEL_CATALOG, provider_for_model, required_env_for

    out: list[ModelInfo] = []
    for mid in MODEL_CATALOG:
        out.append(
            ModelInfo(
                id=mid,
                provider=provider_for_model(mid),
                requires_key=required_env_for(mid) or "",
            )
        )
    return ModelsResponse(models=out)


@app.get("/tasks", response_model=TasksResponse, tags=["system"])
async def list_tasks() -> TasksResponse:
    """Expose the full aver-meta task library (117 tasks across 17 domains).

    Each task carries its full schema (prompt, ground-truth, detection
    signals, recovery criteria) so the UI can preview it and so users can
    see exactly what their agent will be tested against.
    """
    from induat.tasks import (
        CURATED_TASK_IDS,
        DEMO_TASKS,
        gate_for_category,
        get_aver_tasks,
    )

    curated_set = set(CURATED_TASK_IDS)
    # AVER curated pack used to ship hand-written labels; the pack now
    # resolves to DEMO_TASKS only, so the lookup is empty by design.
    curated_labels: dict[str, str] = {}
    out: list[TaskInfo] = []

    # Demo pack — 20 hand-tuned tasks across 7 real-world domains.
    # All flagged ``curated=True`` so the UI star-tags them. Tool
    # dependencies surface via ``needs`` so the UI can badge them.
    for t in DEMO_TASKS:
        out.append(
            TaskInfo(
                gate_id=t.gate_id,
                gate=t.gate.replace("Demo · ", "", 1),
                axis=t.axis,
                domain=t.domain,
                prompt=t.prompt,
                must=list(t.must),
                must_not=list(t.must_not),
                expected=t.expected,
                builtin=True,
                curated=True,
                needs=getattr(t, "needs", "") or "",
            )
        )

    # Then the full AVER library (117 tasks across 17 domains).
    for t in get_aver_tasks():
        gate_id, gate_name, axis = gate_for_category(t.category)
        # Humanize the AVER task_id into a readable label. Curated
        # tasks get a hand-written name; the rest go through the
        # algorithmic stripper. The mythology lives in the dimension
        # grid + verdict, not in task names — those need to be useful
        # at a glance.
        human_label = curated_labels.get(t.task_id) or _humanize_task_id(t.task_id, t.domain)
        # Detection-signal phrases as the "must" list; recovery as a softer must.
        must = list(t.detection_signals.get("explicit", []))[:6]
        # Misleading-text fragments as trap signals (must_not).
        ei = t.error_injection or {}
        ed = ei.get("error_data", {})
        misleading = ed.get("misleading_text", "") or ei.get("misleading_text", "")
        # Pull a few short phrases from the misleading text — light-weight.
        trap_phrases = [s.strip() for s in misleading.split(".") if 5 < len(s.strip()) < 80][:3]

        out.append(
            TaskInfo(
                gate_id=t.task_id,
                gate=human_label,
                axis=axis,
                domain=t.domain,
                prompt=t.task_description,
                must=must,
                must_not=trap_phrases,
                expected=ei.get("error_data", {}).get("ground_truth", "")[:160] or
                         ed.get("explanation", "")[:160] or
                         "Built-in reliability task — full ground-truth in scoring engine.",
                builtin=True,
                curated=t.task_id in curated_set,
            )
        )
    return TasksResponse(tasks=out)


def _humanize_task_id(task_id: str, domain: str) -> str:
    """Turn an AVER task_id into a readable display name.

    Examples:
        aver_airline_baggage_calc_3_045   →   Baggage Calc
        aver_healthcare_dose_calc_4_012   →   Dose Calc
        aver_hr_termination_2_044         →   Termination

    Strategy: strip the "aver_" prefix, drop the domain segment (UI
    shows it separately as a tag), drop trailing numeric segments
    (difficulty + index), title-case the remainder.
    """
    clean = task_id
    if clean.startswith("aver_"):
        clean = clean[5:]
    parts = clean.split("_")

    # Drop trailing pure-numeric segments (difficulty, index).
    while parts and parts[-1].isdigit():
        parts.pop()

    # Drop the leading domain segment (UI shows domain as a separate tag).
    if parts and parts[0] == domain:
        parts = parts[1:]

    if not parts:
        return task_id  # fallback if we stripped everything
    return " ".join(parts).title()


@app.post("/run", response_model=ReliabilityReport, tags=["measurement"])
async def run(req: RunRequest) -> ReliabilityReport:
    """Run the gauntlet against the described stack."""
    try:
        context_cls = context_pkg.REGISTRY[req.context]
    except KeyError:
        raise HTTPException(
            400,
            f"unknown context plugin: '{req.context}' "
            f"(available: {sorted(context_pkg.REGISTRY)})",
        ) from None

    try:
        search_cls = search_pkg.REGISTRY[req.search]
    except KeyError:
        raise HTTPException(
            400,
            f"unknown search plugin: '{req.search}' "
            f"(available: {sorted(search_pkg.REGISTRY)})",
        ) from None

    # Plugin credentials: prefer per-request keys, fall back to env.
    ctx_key = req.api_keys.get("qontext") or None
    search_key = req.api_keys.get("tavily") or None

    try:
        context_plugin = _instantiate(context_cls, key=ctx_key)
        search_plugin = _instantiate(search_cls, key=search_key)
    except RuntimeError as e:
        raise HTTPException(503, f"plugin init failed: {e}") from e

    config = StackConfig(
        model=req.model,
        context=context_plugin,
        search=search_plugin,
        domains=req.domains,
        api_keys=req.api_keys,
    )

    # Translate any explicit task list → runner's Task dataclass.
    tasks_override = None
    if req.tasks:
        from induat.tasks import Task as RunnerTask

        tasks_override = [
            RunnerTask(
                gate_id=t.gate_id,
                gate=t.gate,
                axis=t.axis,
                domain=t.domain,
                prompt=t.prompt,
                must=list(t.must),
                must_not=list(t.must_not),
                expected=t.expected,
            )
            for t in req.tasks
        ]

    # Log the stack + task count — never the keys or prompts.
    log.info(
        "run: %s (tasks=%s)",
        config.descriptor.model_dump(),
        len(tasks_override) if tasks_override else "default",
    )
    report = await run_gauntlet(config, tasks_override=tasks_override)
    return report


def _instantiate(plugin_cls, key: str | None = None):
    """Instantiate a plugin, threading a per-request API key if provided."""
    if key is None:
        return plugin_cls()
    try:
        return plugin_cls(api_key=key)
    except TypeError:
        # Plugin doesn't accept api_key (e.g. NoneContext) — init without.
        return plugin_cls()


# ─────────────────────────────── web UI
#
# Mounted last so explicit API routes above take precedence. StaticFiles
# with ``html=True`` serves ``web/index.html`` at ``/`` and any sibling
# files directly (e.g. future ``/favicon.ico``, ``/logo.png``).

if WEB_DIR.is_dir():
    app.mount("/", StaticFiles(directory=WEB_DIR, html=True), name="web")
else:
    log.warning("web directory not found at %s — UI disabled", WEB_DIR)
