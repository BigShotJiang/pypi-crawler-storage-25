"""LiteLLM dispatch + keyword scoring.

Thin wrapper around LiteLLM so the runner can call any model provider
(Gemini, Claude, GPT, DeepSeek, …) through a single code path.

No persistent state. API keys are passed per-call and never logged.
"""
from __future__ import annotations

import asyncio
import logging
import re
from dataclasses import dataclass

try:
    import litellm
    litellm.drop_params = True
    litellm.set_verbose = False
    # Silence the "Give Feedback / Get Help" banner LiteLLM prints on
    # exceptions, plus its info-level chatter. We surface our own error
    # messages — the user doesn't need to see LiteLLM's internals.
    litellm.suppress_debug_info = True
    for _name in ("LiteLLM", "litellm", "litellm.utils", "litellm.cost_calculator", "httpx"):
        logging.getLogger(_name).setLevel(logging.CRITICAL)
    LITELLM_AVAILABLE = True
except ImportError:  # pragma: no cover - handled at runtime
    LITELLM_AVAILABLE = False

from induat.tasks import Task

log = logging.getLogger("induat.llm")


# Which env-var name each model family needs.
_PROVIDER_ENV = {
    "gemini":    "GEMINI_API_KEY",
    "vertex_ai": "GEMINI_API_KEY",
    "claude":    "ANTHROPIC_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "gpt":       "OPENAI_API_KEY",
    "openai":    "OPENAI_API_KEY",
    "o1":        "OPENAI_API_KEY",
    "pioneer":   "PIONEER_API_KEY",
}


# Pioneer is treated as an OpenAI-compatible provider. The base URL is
# configurable via PIONEER_API_BASE so users can point at staging,
# self-hosted, or different regional endpoints without code changes.
PIONEER_DEFAULT_BASE = "https://api.pioneerapi.ai/v1"


# Catalog of models offered in the UI. Key = internal id; value = LiteLLM model string.
# Pioneer models route through LiteLLM's "openai/" prefix so we get the
# OpenAI-compatible request format with the custom api_base.
MODEL_CATALOG: dict[str, str] = {
    # ── Google Gemini — 2.5 family is the current stable lineup ──
    "gemini-2.5-pro":           "gemini/gemini-2.5-pro",
    "gemini-2.5-flash":         "gemini/gemini-2.5-flash",
    "gemini-2.5-flash-lite":    "gemini/gemini-2.5-flash-lite",

    # ── Anthropic Claude — 4.x family ──
    "claude-opus-4-7":          "anthropic/claude-opus-4-7",
    "claude-sonnet-4-6":        "anthropic/claude-sonnet-4-6",
    "claude-haiku-4-5":         "anthropic/claude-haiku-4-5-20251001",

    # ── OpenAI — GPT-5 + o-series reasoning ──
    "gpt-5":                    "openai/gpt-5",
    "gpt-5-mini":               "openai/gpt-5-mini",
    "gpt-4.1":                  "openai/gpt-4.1",
    "o3":                       "openai/o3",
    "o3-mini":                  "openai/o3-mini",

    # ── Pioneer — OpenAI-compatible custom endpoint ──
    "pioneer-flagship":         "openai/pioneer-flagship",
    "pioneer-fast":             "openai/pioneer-fast",
}


def provider_for_model(model_id: str) -> str:
    """Infer which provider a model belongs to — used for API-key routing."""
    mid = model_id.lower()
    if "gemini" in mid:   return "gemini"
    if "claude" in mid:   return "anthropic"
    if "pioneer" in mid:  return "pioneer"
    # OpenAI ships gpt-* (incl. gpt-5/4.1) plus the o-series reasoning
    # line (o1, o3, o4, ...). Match the leading letter+digit pattern.
    if mid.startswith("gpt") or (
        len(mid) >= 2 and mid[0] == "o" and mid[1].isdigit()
    ):
        return "openai"
    return "unknown"


def required_env_for(model_id: str) -> str | None:
    p = provider_for_model(model_id)
    return _PROVIDER_ENV.get(p)


@dataclass
class LLMResult:
    text: str
    model: str
    latency_s: float
    finish_reason: str = ""
    error: str | None = None
    # One of: "", "rate_limit", "auth", "timeout", "other"
    # Lets the CLI render a clean banner instead of a wall of provider noise.
    error_kind: str = ""


# Generous default so scoring runs against the complete response, never
# a truncated one. Reasoning models can sometimes exceed this — tune
# per-call if you're running o1 / DeepSeek-R1 style thinkers.
DEFAULT_MAX_TOKENS = 4096

# Retry knobs for transient errors (rate limit, timeout). Kept tight on
# purpose: when a key is genuinely exhausted, retries only delay the
# inevitable banner. The runner's circuit-breaker short-circuits the
# whole queue once one task confirms a rate-limit, so a single retry is
# enough to absorb spurious 429s without dragging out the failure path.
_RATE_LIMIT_MAX_RETRIES = 1
_RATE_LIMIT_BACKOFF_S = (3.0,)


def _classify_error(exc: Exception) -> str:
    """Map a LiteLLM exception to a short kind tag for clean error display."""
    name = type(exc).__name__.lower()
    msg = str(exc).lower()
    if "ratelimit" in name or "429" in msg or "resource_exhausted" in msg or "rate limit" in msg:
        return "rate_limit"
    if "auth" in name or "401" in msg or "403" in msg or "permission" in msg or "api key" in msg:
        return "auth"
    if "timeout" in name or "timeout" in msg:
        return "timeout"
    # 503 / "currently experiencing high demand" / "unavailable" — provider
    # overload. Treat as transient: retry once like a timeout.
    if "serviceunavailable" in name or "503" in msg or "unavailable" in msg or "overloaded" in msg:
        return "timeout"
    # Provider safety filters most often surface as IndexError when LiteLLM
    # tries to read choices[0] from an empty response, or as explicit
    # "blocked"/"safety" messages.
    if "indexerror" in name or "list index out of range" in msg \
       or "safety" in msg or "blocked" in msg or "content_filter" in msg:
        return "safety_block"
    return "other"


def _short_error(kind: str, exc: Exception) -> str:
    """Compact, user-friendly error string. No provider stack traces."""
    if kind == "rate_limit":
        return "rate limit hit (provider returned 429)"
    if kind == "auth":
        return "auth failed — check the API key"
    if kind == "timeout":
        return "request timed out"
    if kind == "safety_block":
        return "provider blocked the response (safety filter)"
    # Fall back to first line of the exception, capped.
    text = str(exc).splitlines()[0] if str(exc) else type(exc).__name__
    return text[:140]


async def call_model(
    model_id: str,
    prompt: str,
    api_keys: dict[str, str] | None = None,
    *,
    temperature: float = 0.2,
    max_tokens: int = DEFAULT_MAX_TOKENS,
    timeout_s: float = 90.0,
) -> LLMResult:
    """Single-shot LLM call via LiteLLM.

    ``api_keys`` maps provider slugs (``gemini``, ``anthropic``, ``openai``,
    ``deepseek``) to raw keys. Keys are passed per-call and never persisted.
    """
    if not LITELLM_AVAILABLE:
        return LLMResult(
            text="",
            model=model_id,
            latency_s=0.0,
            error="litellm not installed",
        )

    litellm_model = MODEL_CATALOG.get(model_id, model_id)
    provider = provider_for_model(model_id)

    # Route the key to LiteLLM per-call by setting the relevant kwarg.
    call_kwargs: dict[str, object] = {
        "model": litellm_model,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": temperature,
        "max_tokens": max_tokens,
        "timeout": timeout_s,
    }
    if api_keys:
        key = None
        if provider == "gemini":
            key = api_keys.get("gemini") or api_keys.get("google")
            if key: call_kwargs["api_key"] = key
        elif provider == "anthropic":
            key = api_keys.get("anthropic") or api_keys.get("claude")
            if key: call_kwargs["api_key"] = key
        elif provider == "openai":
            key = api_keys.get("openai") or api_keys.get("gpt")
            if key: call_kwargs["api_key"] = key
        elif provider == "pioneer":
            key = api_keys.get("pioneer")
            if key: call_kwargs["api_key"] = key

    # Pioneer is OpenAI-compatible at the wire level but lives at its own
    # base URL. Pass api_base explicitly so LiteLLM's "openai/" routing
    # POSTs to the Pioneer endpoint instead of openai.com.
    if provider == "pioneer":
        call_kwargs["api_base"] = os.environ.get(
            "PIONEER_API_BASE", PIONEER_DEFAULT_BASE,
        )

    loop = asyncio.get_running_loop()
    started = loop.time()
    last_exc: Exception | None = None
    safety_block_attempts = 0
    rate_limit_attempts = 0
    # Higher loop bound — individual error counters cap retries per kind.
    for attempt in range(6):
        try:
            resp = await litellm.acompletion(**call_kwargs)
            choices = resp.get("choices") if isinstance(resp, dict) else getattr(resp, "choices", None)
            if not choices:
                # Empty choices usually means Gemini's safety filter
                # rejected the response — and empirically it's flaky
                # (the same prompt succeeds ~50% of the time). Retry a
                # couple times before giving up so a single hiccup
                # doesn't tank a whole gauntlet run.
                safety_block_attempts += 1
                if safety_block_attempts <= 2:
                    await asyncio.sleep(1.0)
                    continue
                return LLMResult(
                    text="",
                    model=model_id,
                    latency_s=loop.time() - started,
                    error="provider blocked the response (safety filter)",
                    error_kind="safety_block",
                )
            choice = choices[0]
            msg = choice["message"] if isinstance(choice, dict) else choice.message
            text = (msg.get("content") if isinstance(msg, dict) else msg.content) or ""
            finish_reason = (
                choice.get("finish_reason") if isinstance(choice, dict)
                else getattr(choice, "finish_reason", "")
            ) or ""
            return LLMResult(
                text=text,
                model=model_id,
                latency_s=loop.time() - started,
                finish_reason=finish_reason,
            )
        except Exception as e:  # noqa: BLE001
            last_exc = e
            kind = _classify_error(e)
            # Only retry transient classes; auth / unknown failures fail fast.
            if kind in {"rate_limit", "timeout"} and rate_limit_attempts < _RATE_LIMIT_MAX_RETRIES:
                rate_limit_attempts += 1
                delay = _RATE_LIMIT_BACKOFF_S[
                    min(rate_limit_attempts - 1, len(_RATE_LIMIT_BACKOFF_S) - 1)
                ]
                log.debug("llm %s for %s — backing off %.1fs (attempt %d)",
                          kind, model_id, delay, rate_limit_attempts)
                await asyncio.sleep(delay)
                continue
            break

    kind = _classify_error(last_exc) if last_exc else "other"
    return LLMResult(
        text="",
        model=model_id,
        latency_s=loop.time() - started,
        error=_short_error(kind, last_exc) if last_exc else "unknown error",
        error_kind=kind,
    )


# ───────────────────────────── scoring


def _contains_any(text: str, patterns: list[str]) -> int:
    """Count how many of the patterns appear in text (case-insensitive)."""
    if not patterns:
        return 0
    low = text.lower()
    hits = 0
    for p in patterns:
        if re.search(re.escape(p.lower()), low):
            hits += 1
    return hits


def score_task_response(task: Task, response: str) -> tuple[float, dict]:
    """Return a (score 0-1, audit dict) for a single task response.

    Simple, defensible rubric:
      + 0.6 if at least one required phrase present
      + 0.2 scaling for multiple required phrases (up to 3)
      - 0.4 for any tripped trap phrase
      - 0.2 for empty / very short responses

    The audit dict exposes which signals matched for the UI / diagnostics.
    """
    if not response or len(response.strip()) < 15:
        return 0.15, {"reason": "empty_or_too_short", "hits_must": 0, "hits_must_not": 0}

    hits_must     = _contains_any(response, task.must)
    hits_must_not = _contains_any(response, task.must_not)

    score = 0.5
    if hits_must >= 1:
        score += 0.25 + min(0.15, 0.05 * (hits_must - 1))
    else:
        score -= 0.2
    if hits_must_not > 0:
        score -= 0.4

    score = max(0.0, min(1.0, score))
    return score, {
        "hits_must": hits_must,
        "hits_must_not": hits_must_not,
        "must_matched": hits_must,
        "trap_matched": hits_must_not,
    }
