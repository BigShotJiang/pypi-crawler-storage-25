from chatModelTask.type import CustomWeights
from langchain_core.prompts import ChatPromptTemplate
from typing import Optional 
from .type import ModelFilter
from langchain.chat_models import BaseChatModel
weight_data = {
    "popularity": 0.0,
    "reasoning": 0.4,
    "tools": 0.0,
    "reliability": 0.3,
    "cache": 0.0,
    "programming": 0.2,
    "science": 0.0,
    "technology": 0.1,
    "finance": 0.0,
    "marketing": 0.0,
    "translation": 0.0,
    "legal": 0.0,
    "health": 0.0,
    "roleplay": 0.0,
    "academia": 0.0,
    "marketing_seo": 0.0
}


system_instruction = """
You are an AI model-routing system.

Your task is to convert a user's request into optimized feature weights for selecting the best AI models.

Return ONLY valid JSON matching the schema.

AVAILABLE FEATURES

- reasoning
  Complex thinking, planning, logic, mathematics, multi-step reasoning.

- tools
  Function calling, APIs, workflows, agents, automation.

- reliability
  Stable outputs, low hallucinations, production consistency.

- programming
  Coding, debugging, software engineering.

- science
  Scientific and mathematical reasoning.

- technology
  IT, infrastructure, cloud, engineering topics.

- finance
  Financial analysis, spreadsheets, forecasting.

- marketing
  Copywriting, branding, creative content.

- translation
  Translation and multilingual tasks.

- legal
  Contracts, compliance, legal analysis.

- health
  Medical and biological knowledge.

- roleplay
  Creative writing, personas, conversational immersion.

- academia
  Research papers, scholarly writing, citations.

- marketing/seo
  SEO optimization and search-ranking content.

RULES

1. Return ONLY JSON.
2. All values must be floats between 0.0 and 1.0.
3. Total weights must sum to 1.0.
4. Give high weights only to the most relevant capabilities.
5. Leave irrelevant features at 0.0.
6. Prefer sparse, meaningful weights instead of spreading small values everywhere.
7. Focus on the user's real intent.

Examples:

Coding agent:
{{
  "reasoning": 0.3,
  "tools": 0.35,
  "reliability": 0.2,
  "programming": 0.15
}}

SEO blog writer:
{{
  "marketing": 0.45,
  "marketing/seo": 0.4,
  "reasoning": 0.1,
  "reliability": 0.05
}}
"""
def clean_weights(weights: dict) -> dict:
    
    cleaned = {}

    for key, value in weights.items():

        try:
            value = float(value)
        except:
            value = 0.0

        # prevent negatives
        value = max(0.0, value)

        cleaned[key] = value

    total = sum(cleaned.values())

    if total <= 0:
        return cleaned

    normalized = {
        k: round(v / total, 6)
        for k, v in cleaned.items()
    }

    return normalized
def getDefaultModel4TaskWeights(filter:Optional[ModelFilter]=None):
    
    from chatModelTask.chatModelTask import ChatModel4Task,ModelFilter
    
    filter = ModelFilter(max_1m_input_tokens_price=0.15,
                         max_1m_output_tokens_price=0.8,
                         require_structured=True,
                         exclude_free_models=True) if not filter else filter
    filter.require_structured = True 
    
    llm = ChatModel4Task( task_weights=weight_data,
                          filter=filter,
                          temperature=0.0)
    
    return llm 

def generateTaskWeights(task_description: str, model:Optional[BaseChatModel]=None,isNormalizeWeights:bool=True) -> dict:
    if(model):
        print(model,'sssssssssssssscccccmcm')
          
    llm = getDefaultModel4TaskWeights() if not model else model
     
    prompt = ChatPromptTemplate.from_messages([
        ("system", system_instruction),
        ("human", "User task:\n{task_description}")
    ])

    # Bind the Pydantic schema to force structured JSON output
    structured_llm = llm.with_structured_output(CustomWeights)

    # Combine into a runnable chain
    weight_generation_chain = prompt | structured_llm
    
    weights = weight_generation_chain.invoke({"task_description":task_description})
    w = {
        **weights.model_dump(),
        'cache':0,
        'popularity':'0'} if weights else {}
    
    return clean_weights(w) if isNormalizeWeights else w