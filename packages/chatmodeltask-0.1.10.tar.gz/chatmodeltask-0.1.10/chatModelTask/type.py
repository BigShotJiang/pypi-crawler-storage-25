from pydantic import BaseModel,Field
from typing import Optional,Literal,List

MODALITY = Literal['text','image','video','file','audio']
    #cache: Optional[float] = Field(default=0.0, description="Weight for prompt caching efficiency and cost savings.")
    #popularity: Optional[float] = Field(default=0.0, description="Weight for overall model usage volume.")

class CustomWeights(BaseModel):
    
    # Core cognitive capabilities
    reasoning: Optional[float] = Field(
        default=0.0,
        description="Complex reasoning, logic, planning, mathematics, and multi-step thinking."
    )

    tools: Optional[float] = Field(
        default=0.0,
        description="Function calling, external tools, agents, APIs, workflows, and autonomous execution."
    )

    reliability: Optional[float] = Field(
        default=0.0,
        description="Execution stability, low hallucination rate, structured consistency, and production safety."
    )

    # Specialized domains
    programming: Optional[float] = Field(
        default=0.0,
        description="Code generation, debugging, refactoring, software engineering, DevOps, scripting."
    )

    science: Optional[float] = Field(
        default=0.0,
        description="Scientific reasoning, physics, chemistry, biology, mathematics, and technical analysis."
    )

    technology: Optional[float] = Field(
        default=0.0,
        description="General technology, infrastructure, IT systems, networking, cloud, and engineering knowledge."
    )

    finance: Optional[float] = Field(
        default=0.0,
        description="Financial analysis, accounting, spreadsheets, forecasting, economics, and market reasoning."
    )

    marketing: Optional[float] = Field(
        default=0.0,
        description="Persuasive writing, advertising, branding, copywriting, social media, and creative campaigns."
    )

    translation: Optional[float] = Field(
        default=0.0,
        description="Translation quality, multilingual fluency, localization, and cross-language accuracy."
    )

    legal: Optional[float] = Field(
        default=0.0,
        description="Legal terminology, contracts, compliance, policy analysis, and regulatory interpretation."
    )

    health: Optional[float] = Field(
        default=0.0,
        description="Medical knowledge, healthcare information, biology, wellness, and clinical terminology."
    )

    roleplay: Optional[float] = Field(
        default=0.0,
        description="Creative storytelling, conversational immersion, fictional personas, and long-form dialogue consistency."
    )

    academia: Optional[float] = Field(
        default=0.0,
        description="Research papers, academic writing, citations, scholarly analysis, and formal educational content."
    )

    marketing_seo: Optional[float] = Field(
        default=0.0,
        alias="marketing/seo",
        description="SEO optimization, keyword targeting, search ranking strategies, metadata, and web-content optimization."
    )

    model_config = {
        "populate_by_name": True
    }
    
class ModelFilter(BaseModel):
    max_1m_input_tokens_price: Optional[float] = 1
    max_1m_output_tokens_price: Optional[float] = 2
    
    require_tools: Optional[bool] = None
    require_structured: Optional[bool] = None
    
    min_context_length: Optional[int] = None 
    
    exclude_free_models:Optional[bool] = False
    
    input_modality:Optional[List[MODALITY]]=['text']
    output_modality:Optional[List[MODALITY]]=['text']
    
    

TASK_TYPE= Literal['programming',
                    'roleplay',
                    'marketing','marketing_seo',
                    'technology','science',
                    'translation','legal','finance',
                    'health','trivia','academia']