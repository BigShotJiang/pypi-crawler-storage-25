/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2018-2026 BioInception PVT LTD
 * Algorithm Copyright (c) 2009-2026 Syed Asad Rahman
 *
 * Internal benchmark — NOT for public distribution.
 * Run manually: mvn test -Dtest=BenchmarkComparison
 */
package com.bioinception.smsd;

import com.bioinception.smsd.core.ChemOptions;
import com.bioinception.smsd.core.SMSD;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;

import java.util.Map;

/**
 * Internal-only benchmark for profiling SMSD MCS performance across representative molecule pairs.
 * Disabled by default — run with {@code mvn test -Dtest=BenchmarkComparison}.
 */
@EnabledIfSystemProperty(named = "smsd.benchmark", matches = "true")
@DisplayName("SMSD Internal Benchmark")
class BenchmarkComparison extends TestBase {

    private static final String[][] PAIRS = {
        // name, query SMILES, target SMILES
        {"benzene-toluene", "c1ccccc1", "Cc1ccccc1"},
        {"aspirin-acetaminophen", "CC(=O)Oc1ccccc1C(=O)O", "CC(=O)Nc1ccc(O)cc1"},
        {"morphine-codeine",
            "CN1CCC23C4C1CC5=C2C(=C(C=C5)O)OC3C(C=C4)O",
            "CN1CCC23C4C1CC5=C2C(=C(C=C5)OC)OC3C(C=C4)O"},
        {"ibuprofen-naproxen",
            "CC(C)Cc1ccc(cc1)C(C)C(=O)O",
            "COc1ccc2cc(CC(C)C(=O)O)ccc2c1"},
        {"caffeine-theophylline",
            "Cn1cnc2c1c(=O)n(c(=O)n2C)C",
            "Cn1cnc2c1c(=O)[nH]c(=O)n2C"},
        {"ATP-ADP",
            "c1nc(c2c(n1)n(cn2)C3C(C(C(O3)COP(=O)(O)OP(=O)(O)OP(=O)(O)O)O)O)N",
            "c1nc(c2c(n1)n(cn2)C3C(C(C(O3)COP(=O)(O)OP(=O)(O)O)O)O)N"},
        {"NAD+-NADH",
            "C1=CC(=C[N+](=C1)C2C(C(C(O2)COP(=O)(O)OP(=O)(O)OCC3C(C(C(O3)N4C=NC5=C4N=CN=C5N)O)O)O)O)C(=O)N",
            "C1C=CN(C=C1C(=O)N)C2C(C(C(O2)COP(=O)(O)OP(=O)(O)OCC3C(C(C(O3)N4C=NC5=C4N=CN=C5N)O)O)O)O"},
        {"paclitaxel-docetaxel",
            "CC1=C2C(C(=O)C3(C(CC4C(C3C(C(C2(C)C)(CC1OC(=O)C(C(C5=CC=CC=C5)NC(=O)C6=CC=CC=C6)O)O)OC(=O)C7=CC=CC=C7)(CO4)OC(=O)C)O)C)OC(=O)C",
            "CC1=C2C(C(=O)C3(C(CC4C(C3C(C(C2(C)C)(CC1OC(=O)C(C(C5=CC=CC=C5)NC(=O)OC(C)(C)C)O)O)OC(=O)C6=CC=CC=C6)(CO4)OC(=O)C)O)C)O"},
        {"erythromycin-azithromycin",
            "CCC1OC(=O)C(C)C(OC2CC(C)(OC)C(O)C(C)O2)C(C)C(OC2OC(C)CC(C2O)N(C)C)C(C)(O)CC(C)C(=O)C(C)C(O)C1(C)O",
            "CCC1C(C(C(N(CC(CC(C(C(C(C(C(=O)O1)C)OC2CC(C(C(O2)C)O)(C)OC)C)OC3C(C(CC(O3)C)N(C)C)O)(C)O)C)C)C)O)(C)O"},
        {"atorvastatin-rosuvastatin",
            "CC(C)C1=C(C(=C(N1CCC(CC(CC(=O)O)O)O)C2=CC=C(C=C2)F)C3=CC=CC=C3)C(=O)NC4=CC=CC=C4",
            "CC(C)C1=NC(=NC(=C1C=CC(CC(CC(=O)O)O)O)C2=CC=C(C=C2)F)N(C)S(=O)(=O)C"},
    };

    @Test
    @DisplayName("MCS benchmark — all pairs")
    void mcsBenchmark() throws Exception {
        System.out.println("\n=== SMSD MCS Benchmark (internal use only) ===");
        System.out.printf("%-30s %8s %8s %8s %6s%n",
            "Pair", "Best(ms)", "Med(ms)", "Mean(ms)", "MCS");
        System.out.println("-".repeat(70));

        ChemOptions opts = new ChemOptions();
        int warmup = 5;
        int runs = 10;

        for (String[] pair : PAIRS) {
            var q = mol(pair[1]);
            var t = mol(pair[2]);

            // Warmup
            for (int i = 0; i < warmup; i++) {
                new SMSD(q, t, opts, false).findMCS(true, true, 5000);
            }

            // Measure
            long[] times = new long[runs];
            int mcsSize = 0;
            for (int i = 0; i < runs; i++) {
                long t0 = System.nanoTime();
                SMSD smsd = new SMSD(q, t, opts, false);
                Map<Integer, Integer> result = smsd.findMCS(true, true, 5000);
                times[i] = System.nanoTime() - t0;
                if (i == 0 && result != null && !result.isEmpty()) {
                    mcsSize = result.size();
                }
            }

            java.util.Arrays.sort(times);
            long best = times[0];
            long median = times[runs / 2];
            long mean = 0;
            for (long ti : times) mean += ti;
            mean /= runs;

            System.out.printf("%-30s %8.2f %8.2f %8.2f %6d%n",
                pair[0],
                best / 1_000_000.0,
                median / 1_000_000.0,
                mean / 1_000_000.0,
                mcsSize);
        }
        System.out.println();
    }

    @Test
    @DisplayName("Substructure benchmark — all pairs")
    void substructureBenchmark() throws Exception {
        System.out.println("\n=== SMSD Substructure Benchmark (internal use only) ===");
        System.out.printf("%-30s %8s %8s %6s%n", "Pair", "Best(us)", "Med(us)", "Match");
        System.out.println("-".repeat(60));

        ChemOptions opts = new ChemOptions();
        int warmup = 20;
        int runs = 100;

        for (String[] pair : PAIRS) {
            var q = mol(pair[1]);
            var t = mol(pair[2]);

            // Warmup
            for (int i = 0; i < warmup; i++) {
                new SMSD(q, t, opts, false).isSubstructure();
            }

            // Measure
            long[] times = new long[runs];
            boolean match = false;
            for (int i = 0; i < runs; i++) {
                long t0 = System.nanoTime();
                SMSD smsd = new SMSD(q, t, opts, false);
                match = smsd.isSubstructure();
                times[i] = System.nanoTime() - t0;
            }

            java.util.Arrays.sort(times);
            long best = times[0];
            long median = times[runs / 2];

            System.out.printf("%-30s %8d %8d %6s%n",
                pair[0], best / 1000, median / 1000, match);
        }
        System.out.println();
    }

    @Test
    @DisplayName("ATP/ADP MCS detail — inspect mapping")
    void atpAdpMcsDetail() throws Exception {
        var atp = mol("c1nc(c2c(n1)n(cn2)C3C(C(C(O3)COP(=O)(O)OP(=O)(O)OP(=O)(O)O)O)O)N");
        var adp = mol("c1nc(c2c(n1)n(cn2)C3C(C(C(O3)COP(=O)(O)OP(=O)(O)O)O)O)N");

        System.out.println("\n=== ATP/ADP MCS Detail ===");
        System.out.println("ATP atoms: " + atp.getAtomCount());
        System.out.println("ADP atoms: " + adp.getAtomCount());

        ChemOptions opts = new ChemOptions();
        SMSD smsd = new SMSD(atp, adp, opts, false);
        Map<Integer, Integer> mapping = smsd.findMCS(true, true, 10000);

        if (mapping != null && !mapping.isEmpty()) {
            System.out.println("MCS size: " + mapping.size());
            System.out.println("\nMapping (ATP idx -> ADP idx):");
            for (var entry : mapping.entrySet()) {
                int qi = entry.getKey();
                int ti = entry.getValue();
                String qSym = atp.getAtom(qi).getSymbol();
                String tSym = adp.getAtom(ti).getSymbol();
                System.out.printf("  ATP[%2d] %s -> ADP[%2d] %s%n", qi, qSym, ti, tSym);
            }

            // Count by element
            Map<String, Integer> elements = new java.util.TreeMap<>();
            for (var entry : mapping.entrySet()) {
                String sym = atp.getAtom(entry.getKey()).getSymbol();
                elements.merge(sym, 1, Integer::sum);
            }
            System.out.println("\nMCS composition: " + elements);
        } else {
            System.out.println("NO MCS FOUND — this is a bug!");
        }
    }

    @Test
    @DisplayName("RASCAL screening benchmark")
    void rascalBenchmark() throws Exception {
        System.out.println("\n=== RASCAL Screening Benchmark (internal use only) ===");
        System.out.printf("%-30s %8s %8s %6s%n", "Pair", "Best(us)", "Med(us)", "UB");
        System.out.println("-".repeat(60));

        ChemOptions opts = new ChemOptions();
        int warmup = 50;
        int runs = 200;

        for (String[] pair : PAIRS) {
            var q = mol(pair[1]);
            var t = mol(pair[2]);

            // Warmup
            for (int i = 0; i < warmup; i++) {
                new SMSD(q, t, opts, false).similarityUpperBound();
            }

            // Measure
            long[] times = new long[runs];
            double ub = 0;
            for (int i = 0; i < runs; i++) {
                long t0 = System.nanoTime();
                ub = new SMSD(q, t, opts, false).similarityUpperBound();
                times[i] = System.nanoTime() - t0;
            }

            java.util.Arrays.sort(times);
            System.out.printf("%-30s %8d %8d %6.3f%n",
                pair[0], times[0] / 1000, times[runs / 2] / 1000, ub);
        }
        System.out.println();
    }
}
