/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2018-2026 BioInception PVT LTD
 * Algorithm Copyright (c) 2009-2026 Syed Asad Rahman
 */
package com.bioinception.smsd;

import static org.junit.jupiter.api.Assertions.*;

import com.bioinception.smsd.cli.SMSDcli.MolIO;
import com.bioinception.smsd.core.ChemOptions;
import com.bioinception.smsd.core.SMSD;
import com.bioinception.smsd.core.Standardiser;
import org.junit.jupiter.api.*;
import org.openscience.cdk.interfaces.IAtomContainer;

@DisplayName("MolIO I/O Tests")
class MolIOTest {

  @Nested
  @DisplayName("SMILES Loading")
  class SmilesLoading {

    @Test
    @DisplayName("Load benzene SMILES → 6 atoms, 6 bonds")
    void loadBenzene() throws Exception {
      MolIO.Query q = MolIO.loadQuery("SMI", "c1ccccc1");
      assertFalse(q.isSmarts);
      assertNotNull(q.container);
      assertEquals(6, q.container.getAtomCount());
      assertEquals(6, q.container.getBondCount());
    }

    @Test
    @DisplayName("Load ethanol SMILES → 3 heavy atoms")
    void loadEthanol() throws Exception {
      MolIO.Query q = MolIO.loadQuery("SMI", "CCO");
      assertEquals(3, q.container.getAtomCount());
    }

    @Test
    @DisplayName("Load target SMILES → valid molecule")
    void loadTarget() throws Exception {
      IAtomContainer t = MolIO.loadTarget("SMI", "c1ccccc1");
      assertNotNull(t);
      assertEquals(6, t.getAtomCount());
    }
  }

  @Nested
  @DisplayName("SMARTS Loading")
  class SmartsLoading {

    @Test
    @DisplayName("Load SMARTS → isSmarts=true, container=null")
    void loadSmarts() throws Exception {
      MolIO.Query q = MolIO.loadQuery("SIG", "[#6]");
      assertTrue(q.isSmarts);
      assertNull(q.container);
      assertEquals("[#6]", q.text);
    }

    @Test
    @DisplayName("Load complex SMARTS")
    void loadComplexSmarts() throws Exception {
      MolIO.Query q = MolIO.loadQuery("SIG", "[#6][#7]");
      assertTrue(q.isSmarts);
      assertEquals("[#6][#7]", q.text);
    }
  }

  @Nested
  @DisplayName("Error Handling")
  class ErrorHandling {

    @Test
    @DisplayName("Null query type → NullPointerException")
    void nullType() {
      assertThrows(NullPointerException.class, () -> MolIO.loadQuery(null, "C"));
    }

    @Test
    @DisplayName("Null query value → NullPointerException")
    void nullValue() {
      assertThrows(NullPointerException.class, () -> MolIO.loadQuery("SMI", null));
    }

    @Test
    @DisplayName("Null target type → NullPointerException")
    void nullTargetType() {
      assertThrows(NullPointerException.class, () -> MolIO.loadTarget(null, "C"));
    }

    @Test
    @DisplayName("Null target value → NullPointerException")
    void nullTargetValue() {
      assertThrows(NullPointerException.class, () -> MolIO.loadTarget("SMI", null));
    }

    @Test
    @DisplayName("Invalid SMILES → exception")
    void invalidSmiles() {
      assertThrows(Exception.class, () -> MolIO.loadQuery("SMI", "XYZ123!!!"));
    }

    @Test
    @DisplayName("SDF via loadTarget → IllegalArgumentException")
    void sdfViaLoadTarget() {
      assertThrows(IllegalArgumentException.class, () -> MolIO.loadTarget("SDF", "file.sdf"));
    }

    @Test
    @DisplayName("Unsupported type → IllegalArgumentException")
    void unsupportedType() {
      assertThrows(Exception.class, () -> MolIO.loadTarget("XYZ", "fake.xyz"));
    }

    @Test
    @DisplayName("Null SDF path → NullPointerException")
    void nullSdfPath() {
      assertThrows(NullPointerException.class, () -> MolIO.loadTargetsSDF(null));
    }

    @Test
    @DisplayName("Non-existent file → FileNotFoundException")
    void fileNotFound() {
      assertThrows(
          java.io.FileNotFoundException.class,
          () -> MolIO.loadTarget("MOL", "/nonexistent/path/fake.mol"));
    }
  }

  @Nested
  @DisplayName("Roundtrip Tests")
  class Roundtrip {

    @Test
    @DisplayName("Load two SMILES → substructure check works")
    void roundtripSubstructure() throws Exception {
      MolIO.Query q = MolIO.loadQuery("SMI", "c1ccccc1");
      IAtomContainer target = MolIO.loadTarget("SMI", "c1ccc(C)cc1");
      IAtomContainer qStd = Standardiser.standardise(q.container, Standardiser.TautomerMode.NONE);
      IAtomContainer tStd = Standardiser.standardise(target, Standardiser.TautomerMode.NONE);
      SMSD smsd = new SMSD(qStd, tStd, new ChemOptions());
      assertTrue(smsd.isSubstructure(), "Benzene should be substructure of toluene");
    }

    @Test
    @DisplayName("SMARTS query roundtrip")
    void smartsRoundtrip() throws Exception {
      MolIO.Query q = MolIO.loadQuery("SIG", "[#6]~[#6]");
      IAtomContainer target = MolIO.loadTarget("SMI", "CC");
      IAtomContainer tStd = Standardiser.standardise(target, Standardiser.TautomerMode.NONE);
      SMSD smsd = new SMSD(q.text, tStd, new ChemOptions());
      assertTrue(smsd.isSubstructure(), "C~C SMARTS should match ethane");
    }
  }
}
