package com.bioinception.smsd;

import static org.junit.jupiter.api.Assertions.*;

import com.bioinception.smsd.core.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.*;
import org.openscience.cdk.interfaces.IAtomContainer;

class AdversarialTest extends TestBase {

  // 1. SYMMETRIC MOLECULES
  @Test
  void cubaneSymmetry() throws Exception {
    IAtomContainer cubane = mol("C12C3C4C1C5C3C4C25");
    SMSD s = new SMSD(cubane, cubane, new ChemOptions());
    assertTrue(s.isSubstructure(5000));
  }

  @Test
  void adamantaneSelfMatch() throws Exception {
    IAtomContainer adam = mol("C1C2CC3CC1CC(C2)C3");
    SMSD s = new SMSD(adam, adam, new ChemOptions());
    assertTrue(s.isSubstructure(5000));
  }

  @Test
  void fullerelikeSymmetric() throws Exception {
    String c20 = "C".repeat(20);
    IAtomContainer q = mol(c20);
    IAtomContainer t = mol(c20);
    SMSD s = new SMSD(q, t, new ChemOptions());
    assertTrue(s.isSubstructure(5000));
  }

  // 2. AROMATIC EDGE CASES
  @Test
  void kekulizedVsAromaticBenzene() throws Exception {
    IAtomContainer kek = mol("C1=CC=CC=C1");
    IAtomContainer arom = mol("c1ccccc1");
    ChemOptions opts = new ChemOptions();
    opts.aromaticityMode = ChemOptions.AromaticityMode.FLEXIBLE;
    SMSD s = new SMSD(kek, arom, opts);
    assertTrue(s.isSubstructure(5000), "Kekulized should match aromatic in FLEXIBLE mode");
  }

  @Test
  void azuleneAromaticity() throws Exception {
    IAtomContainer azulene = mol("c1cc2cccccc2c1");
    assertNotNull(azulene, "Azulene should parse");
    assertEquals(10, azulene.getAtomCount());
  }

  @Test
  void furanVsPyrroleAromatic() throws Exception {
    IAtomContainer furan = mol("c1ccoc1");
    IAtomContainer pyrrole = mol("c1cc[nH]c1");
    SMSD s = new SMSD(furan, pyrrole, new ChemOptions());
    assertFalse(s.isSubstructure(5000), "Furan should NOT be substructure of pyrrole");
  }

  // 3. CHARGED / ZWITTERIONIC
  @Test
  void zwitterionGlycine() throws Exception {
    IAtomContainer neutral = mol("NCC(=O)O");
    IAtomContainer zwitter = mol("[NH3+]CC(=O)[O-]");
    ChemOptions opts = new ChemOptions();
    opts.matchFormalCharge = false;
    SMSD s = new SMSD(neutral, zwitter, opts);
    assertTrue(
        s.isSubstructure(5000), "Neutral glycine should match zwitterion with charge matching off");
  }

  @Test
  void zwitterionChargeOn() throws Exception {
    IAtomContainer neutral = mol("NCC(=O)O");
    IAtomContainer zwitter = mol("[NH3+]CC(=O)[O-]");
    ChemOptions opts = new ChemOptions();
    opts.matchFormalCharge = true;
    SMSD s = new SMSD(neutral, zwitter, opts);
    assertFalse(s.isSubstructure(5000), "Should NOT match with charge matching on");
  }

  // 4. DISCONNECTED MCS
  @Test
  void disconnectedMcsLarger() throws Exception {
    IAtomContainer q = mol("c1ccccc1.CCCC");
    IAtomContainer t = mol("c1ccccc1OCCCC");
    SMSD s1 = new SMSD(q, t, new ChemOptions());
    Map<Integer, Integer> connected = s1.findMCS(false, true, 5000);
    Map<Integer, Integer> disconnected = s1.findMCS(false, false, 5000);
    assertTrue(
        disconnected.size() >= connected.size(), "Disconnected MCS should be >= connected MCS");
  }

  // 5. VERY LARGE SYMMETRIC
  @Test
  void c60BuckminsterfullereneTimeout() throws Exception {
    String big = "C".repeat(60);
    IAtomContainer q = mol(big);
    IAtomContainer t = mol(big);
    long t0 = System.nanoTime();
    SMSD s = new SMSD(q, t, new ChemOptions());
    s.isSubstructure(2000);
    long elapsed = (System.nanoTime() - t0) / 1_000_000;
    assertTrue(
        elapsed < 5000, "Should not hang on large symmetric molecule, took " + elapsed + "ms");
  }

  // 6. SMARTS EDGE CASES
  @Test
  void recursiveSmartsComplex() throws Exception {
    IAtomContainer pyridine = mol("c1ccncc1");
    SMSD s = new SMSD("[n;R1]", pyridine, new ChemOptions());
    assertTrue(s.isSubstructure(5000), "Aromatic N in ring should match pyridine");
  }

  @Test
  void smartsNegation() throws Exception {
    IAtomContainer cyclohexane = mol("C1CCCCC1");
    SMSD s = new SMSD("[C;!a]", cyclohexane, new ChemOptions());
    assertTrue(s.isSubstructure(5000), "Non-aromatic C should match cyclohexane");
  }

  // 7. STEREO EDGE CASES
  @Test
  void cisTransAmide() throws Exception {
    IAtomContainer amide1 = mol("CC(=O)NC");
    IAtomContainer amide2 = mol("CC(=O)NC");
    SMSD s = new SMSD(amide1, amide2, new ChemOptions());
    assertTrue(s.isSubstructure(5000), "Same amide should self-match");
  }

  // 8. ATOM COUNT EDGE CASES
  @Test
  void singleBondQuery() throws Exception {
    IAtomContainer q = mol("CC");
    IAtomContainer t = mol("CCC");
    SMSD s = new SMSD(q, t, new ChemOptions());
    assertTrue(s.isSubstructure(5000));
  }

  @Test
  void noCommonAtoms() throws Exception {
    IAtomContainer q = mol("[Si]");
    IAtomContainer t = mol("CCCC");
    SMSD s = new SMSD(q, t, new ChemOptions());
    assertFalse(s.isSubstructure(5000), "Silicon should not match carbon chain");
  }

  // 9. MULTIPLE MAPPINGS
  @Test
  void multipleMappingsCount() throws Exception {
    IAtomContainer benzene = mol("c1ccccc1");
    IAtomContainer biphenyl = mol("c1ccc(-c2ccccc2)cc1");
    SMSD s = new SMSD(benzene, biphenyl, new ChemOptions());
    List<Map<Integer, Integer>> all = s.findAllSubstructures(100, 5000);
    assertTrue(all.size() >= 2, "Benzene in biphenyl should have >= 2 mappings, got " + all.size());
  }

  // 10. CAFFEINE vs THEOPHYLLINE MCS
  @Test
  void caffeineTheophyllineMcs() throws Exception {
    IAtomContainer caffeine = mol("Cn1cnc2c1c(=O)n(C)c(=O)n2C");
    IAtomContainer theophylline = mol("Cn1cnc2c1c(=O)[nH]c(=O)n2C");
    SMSD s = new SMSD(caffeine, theophylline, new ChemOptions());
    Map<Integer, Integer> mcs = s.findMCS(false, true, 5000);
    assertTrue(
        mcs.size() >= 10, "Caffeine/theophylline MCS should be >= 10 atoms, got " + mcs.size());
  }

  // 11. BIPHENYL vs NAPHTHALENE MCS
  @Test
  void biphenylNaphthaleneMcs() throws Exception {
    IAtomContainer biphenyl = mol("c1ccc(-c2ccccc2)cc1");
    IAtomContainer naphthalene = mol("c1ccc2ccccc2c1");
    SMSD s = new SMSD(biphenyl, naphthalene, new ChemOptions());
    Map<Integer, Integer> mcs = s.findMCS(false, true, 5000);
    assertTrue(mcs.size() >= 6, "Biphenyl/naphthalene MCS >= 6 atoms, got " + mcs.size());
  }

  // 12. OPPOSITE ENANTIOMERS
  @Test
  void oppositeEnantiomersChiralityOff() throws Exception {
    IAtomContainer r = mol("[C@@H](O)(F)Cl");
    IAtomContainer s_mol = mol("[C@H](O)(F)Cl");
    ChemOptions opts = new ChemOptions();
    opts.useChirality = false;
    SMSD smsd = new SMSD(r, s_mol, opts);
    assertTrue(smsd.isSubstructure(5000), "Enantiomers should match with chirality off");
  }

  // 13. E vs Z ISOMERS
  @Test
  void ezIsomersBondStereoOff() throws Exception {
    IAtomContainer eForm = mol("C/C=C/C");
    IAtomContainer zForm = mol("C/C=C\\C");
    ChemOptions opts = new ChemOptions();
    opts.useBondStereo = false;
    SMSD smsd = new SMSD(eForm, zForm, opts);
    assertTrue(smsd.isSubstructure(5000), "E/Z should match with bond stereo off");
  }

  // 14. CARBONATE DIANION
  @Test
  void carbonateDianionChargeOff() throws Exception {
    IAtomContainer carbonate = mol("C(=O)([O-])[O-]");
    IAtomContainer carbonicAcid = mol("OC(=O)O");
    ChemOptions opts = new ChemOptions();
    opts.matchFormalCharge = false;
    SMSD smsd = new SMSD(carbonate, carbonicAcid, opts);
    assertTrue(smsd.isSubstructure(5000), "Carbonate should match carbonic acid with charge off");
  }

  // 15. DISCONNECTED MCS drug pair
  @Test
  void disconnectedMcsLargerDrugPair() throws Exception {
    IAtomContainer phenylacetic = mol("c1ccc(CC(=O)O)cc1");
    IAtomContainer phenylbutyric = mol("c1ccc(CCCC(=O)O)cc1");
    SMSD s = new SMSD(phenylacetic, phenylbutyric, new ChemOptions());
    Map<Integer, Integer> connected = s.findMCS(false, true, 5000);
    Map<Integer, Integer> disconnected = s.findMCS(false, false, 5000);
    assertTrue(
        disconnected.size() >= connected.size(),
        "Disconnected MCS >= connected: disc=" + disconnected.size() + " conn=" + connected.size());
  }

  // 16. SELENIUM vs SULFUR
  @Test
  void seleniumVsSulfur() throws Exception {
    try {
      IAtomContainer selPh = mol("[Se]c1ccccc1");
      IAtomContainer thPh = mol("Sc1ccccc1");
      SMSD s = new SMSD(selPh, thPh, new ChemOptions());
      assertFalse(s.isSubstructure(5000), "Se should not match S");
    } catch (Exception e) {
      // Acceptable if CDK can't parse selenium
    }
  }

  // 17. SYMMETRIC SUBSTITUENTS
  @Test
  void symmetricSubstituents() throws Exception {
    IAtomContainer toluene = mol("Cc1ccccc1");
    IAtomContainer xylene = mol("Cc1ccc(C)cc1");
    SMSD s = new SMSD(toluene, xylene, new ChemOptions());
    assertTrue(s.isSubstructure(5000), "Toluene should be substructure of xylene");
  }

  // ---- NESTED GROUPS ----

  @Nested
  class KekuleVsAromaticSelfMatch {
    @Test
    void kekuleVsAromaticIndole() throws Exception {
      IAtomContainer kekule = mol("C1=CC2=CC=CC=C2N1");
      IAtomContainer aromatic = mol("c1cc2ccccc2[nH]1");
      ChemOptions opts = new ChemOptions();
      opts.aromaticityMode = ChemOptions.AromaticityMode.FLEXIBLE;
      SMSD s = new SMSD(kekule, aromatic, opts);
      assertTrue(
          s.isSubstructure(5000), "Kekule indole should match aromatic indole in FLEXIBLE mode");
    }

    @Test
    void kekuleVsAromaticPyridine() throws Exception {
      IAtomContainer kekule = mol("C1=CC=NC=C1");
      IAtomContainer aromatic = mol("c1ccncc1");
      ChemOptions opts = new ChemOptions();
      opts.aromaticityMode = ChemOptions.AromaticityMode.FLEXIBLE;
      SMSD s = new SMSD(kekule, aromatic, opts);
      assertTrue(
          s.isSubstructure(5000),
          "Kekule pyridine should match aromatic pyridine in FLEXIBLE mode");
    }

    @Test
    void kekuleVsAromaticThiophene() throws Exception {
      IAtomContainer kekule = mol("C1=CC=CS1");
      IAtomContainer aromatic = mol("c1ccsc1");
      ChemOptions opts = new ChemOptions();
      opts.aromaticityMode = ChemOptions.AromaticityMode.FLEXIBLE;
      SMSD s = new SMSD(kekule, aromatic, opts);
      assertTrue(
          s.isSubstructure(5000),
          "Kekule thiophene should match aromatic thiophene in FLEXIBLE mode");
    }
  }

  @Nested
  class ExplicitHBlocking {
    @Test
    void allExplicitHMethaneShouldNotMatchImplicit() throws Exception {
      IAtomContainer explicitH = mol("[H]C([H])([H])[H]");
      IAtomContainer implicitH = mol("C");
      SMSD s = new SMSD(explicitH, implicitH, new ChemOptions());
      assertFalse(
          s.isSubstructure(5000),
          "All-explicit-H methane (5 atoms) cannot be substructure of implicit methane (1 atom)");

      SMSD s2 = new SMSD(implicitH, explicitH, new ChemOptions());
      assertTrue(
          s2.isSubstructure(5000),
          "Implicit methane (1 atom) should be substructure of explicit-H methane (5 atoms)");
    }
  }

  @Nested
  class TautomerAdversarial {

    /** Nitro group N=O should NOT be treated as tautomeric. MCS = shared phenyl ring only. */
    @Test
    void nitroGroupFalsePositive() throws Exception {
      ChemOptions c = ChemOptions.tautomerProfile();
      IAtomContainer nitrobenzene = mol("[O-][N+](=O)c1ccccc1");
      IAtomContainer phenol = mol("Oc1ccccc1");
      SMSD smsd = new SMSD(nitrobenzene, phenol, c);
      var mcs = smsd.findMCS(true, false, 5000);
      assertTrue(mcs.size() <= 7,
          "Nitro N=O should not inflate MCS via tautomer rules, got " + mcs.size());
      assertTrue(mcs.size() >= 6,
          "Should still find shared phenyl ring (6 atoms), got " + mcs.size());
    }

    /** P=O should NOT match C=O as tautomeric. */
    @Test
    void phosphateFalsePositive() throws Exception {
      ChemOptions c = ChemOptions.tautomerProfile();
      IAtomContainer phosphoric = mol("OP(=O)(O)O");
      IAtomContainer carbonic = mol("OC(=O)O");
      SMSD smsd = new SMSD(phosphoric, carbonic, c);
      var mcs = smsd.findMCS(true, false, 5000);
      assertTrue(mcs.size() <= 3,
          "P=O should not match C=O as tautomeric, MCS got " + mcs.size());
    }

    /** S=O should NOT match C=O as tautomeric. */
    @Test
    void sulfonylFalsePositive() throws Exception {
      ChemOptions c = ChemOptions.tautomerProfile();
      IAtomContainer sulfone = mol("CS(=O)(=O)C");
      IAtomContainer acetone = mol("CC(=O)C");
      SMSD smsd = new SMSD(sulfone, acetone, c);
      var mcs = smsd.findMCS(true, false, 5000);
      assertTrue(mcs.size() <= 3,
          "S=O should not match C=O as tautomeric, MCS got " + mcs.size());
    }

    /** Tautomer mode should not break normal substructure: benzene in toluene. */
    @Test
    void tautomerModeDoesNotBreakSubstructure() throws Exception {
      ChemOptions c = ChemOptions.tautomerProfile();
      IAtomContainer benzene = mol("c1ccccc1");
      IAtomContainer toluene = mol("Cc1ccccc1");
      SMSD smsd = new SMSD(benzene, toluene, c);
      assertTrue(smsd.isSubstructure(5000),
          "Benzene should still be substructure of toluene with tautomer mode ON");
    }

    /** Acetylacetone diketo vs keto-enol: symmetric alpha-carbons, MCS >= 6. */
    @Test
    void symmetricTautomerAcetylacetone() throws Exception {
      ChemOptions c = ChemOptions.tautomerProfile();
      IAtomContainer diketo = mol("CC(=O)CC(=O)C");
      IAtomContainer ketoEnol = mol("CC(=O)/C=C(\\C)O");
      SMSD smsd = new SMSD(diketo, ketoEnol, c);
      var mcs = smsd.findMCS(true, false, 5000);
      assertTrue(mcs.size() >= 6,
          "Acetylacetone diketo vs keto-enol tautomers should share >= 6 atoms, got " + mcs.size());
    }

    /** Histidine imidazole ring: NH shifts between ring nitrogens. MCS >= 9 with tautomer mode. */
    @Test
    void histidineImidazoleRing() throws Exception {
      ChemOptions c = ChemOptions.tautomerProfile();
      IAtomContainer his1 = mol("OC(=O)C(N)Cc1c[nH]cn1");
      IAtomContainer his2 = mol("OC(=O)C(N)Cc1cnc[nH]1");
      SMSD smsd = new SMSD(his1, his2, c);
      var mcs = smsd.findMCS(true, false, 5000);
      assertTrue(mcs.size() >= 9,
          "Histidine imidazole tautomers should share >= 9 atoms, got " + mcs.size());
    }

    /** Molecule with both keto/enol AND amide tautomeric sites — classes should not interfere. */
    @Test
    void multipleTautomericSites() throws Exception {
      ChemOptions c = ChemOptions.tautomerProfile();
      // 3-oxo-propanamide (keto form) vs 3-hydroxy-propenamide (enol at C=O, amide unchanged)
      IAtomContainer ketoAmide = mol("NC(=O)CC(=O)C");
      IAtomContainer enolAmide = mol("NC(=O)/C=C(\\C)O");
      SMSD smsd = new SMSD(ketoAmide, enolAmide, c);
      var mcs = smsd.findMCS(true, false, 5000);
      assertTrue(mcs.size() >= 6,
          "Multiple tautomeric sites should not interfere, MCS >= 6, got " + mcs.size());
    }

    /** Pyridazine N-N: directly bonded ring nitrogens, caught by N-N fallback. */
    @Test
    void pyridazineDirectNN() throws Exception {
      ChemOptions c = ChemOptions.tautomerProfile();
      // Use valid kekulé SMILES (CDK cannot kekulise c1cc[nH]nc1)
      IAtomContainer pyridazineNH = mol("C1=CC=NN=C1");
      IAtomContainer pyridazine = mol("c1ccnnc1");
      SMSD smsd = new SMSD(pyridazineNH, pyridazine, c);
      var mcs = smsd.findMCS(true, false, 5000);
      assertTrue(mcs.size() >= 4,
          "Pyridazine N-N tautomers should share >= 4 atoms via N-N fallback, got " + mcs.size());
    }
  }

  @Nested
  class BondOrderLooseMode {
    @Test
    void etheneVsEthaneLooseMode() throws Exception {
      IAtomContainer ethene = mol("C=C");
      IAtomContainer ethane = mol("CC");
      ChemOptions loose = new ChemOptions();
      loose.matchBondOrder = ChemOptions.BondOrderMode.LOOSE;
      SMSD s = new SMSD(ethene, ethane, loose);
      assertTrue(s.isSubstructure(5000), "C=C should match C-C in LOOSE bond order mode");
    }

    @Test
    void etheneVsEthaneAnyMode() throws Exception {
      IAtomContainer ethene = mol("C=C");
      IAtomContainer ethane = mol("CC");
      ChemOptions any = new ChemOptions();
      any.matchBondOrder = ChemOptions.BondOrderMode.ANY;
      SMSD s = new SMSD(ethene, ethane, any);
      assertTrue(s.isSubstructure(5000), "C=C should match C-C in ANY bond order mode");
    }

    @Test
    void etheneVsEthaneStrictMode() throws Exception {
      IAtomContainer ethene = mol("C=C");
      IAtomContainer ethane = mol("CC");
      ChemOptions strict = new ChemOptions();
      strict.matchBondOrder = ChemOptions.BondOrderMode.STRICT;
      SMSD s = new SMSD(ethene, ethane, strict);
      assertFalse(s.isSubstructure(5000), "C=C should NOT match C-C in STRICT bond order mode");
    }
  }

  // ========================================================================
  // HARDEST KNOWN MCS ADVERSARIAL TEST CATEGORIES
  // ========================================================================

  @Nested
  @DisplayName("RDKit Known Failures")
  class RDKitKnownFailures {

    @Test
    @Timeout(10)
    @DisplayName("RDKit Issue #1585 - complex drug pair (23s in RDKit)")
    void rdkitIssue1585() throws Exception {
      long t0 = System.nanoTime();
      IAtomContainer mol1 = mol(
          "c1cc(c(c(c1)Cl)N2c3cc(cc(c3CNC2=O)c4ccc(cc4F)F)N5CCNCC5)Cl");
      IAtomContainer mol2 = mol(
          "CCNc1cc(c2c(c1)N(C(=O)NC2)c3ccc(cc3)n4ccc-5ncnc5c4)c6ccnnc6");
      SMSD s = new SMSD(mol1, mol2, new ChemOptions());
      Map<Integer, Integer> mcs = s.findMCS(false, true, 9000);
      long elapsed = (System.nanoTime() - t0) / 1_000_000;
      System.out.println("RDKit#1585 MCS=" + mcs.size() + " in " + elapsed + "ms");
      assertTrue(mcs.size() >= 8,
          "RDKit#1585 pair should share a chemically reasonable MCS >= 8, got " + mcs.size());
    }

    @Test
    @Timeout(10)
    @DisplayName("RDKit Issue #3965 - OOM pair (4GB+ in RDKit)")
    void rdkitIssue3965() throws Exception {
      // Stereo characters removed for CDK compatibility
      long t0 = System.nanoTime();
      IAtomContainer mol1 = mol(
          "CC(C)CNC(=O)C(C(C)C)CC(O)C(NC1=O)COCc(ccc2)cc2C(c3ccccc3)NC(=O)c(cc14)cc(c4)N(C)S(=O)(=O)C");
      IAtomContainer mol2 = mol(
          "CC(C)CNC(=O)C(C(C)C)CC(O)C(NC(=O)c(cc12)nc(c1)N(C)S(=O)(=O)C)COCc3cc(ccc3)C(NC2=O)c4ccccc4");
      SMSD s = new SMSD(mol1, mol2, new ChemOptions());
      Map<Integer, Integer> mcs = s.findMCS(false, true, 9000);
      long elapsed = (System.nanoTime() - t0) / 1_000_000;
      System.out.println("RDKit#3965 MCS=" + mcs.size() + " in " + elapsed + "ms");
      // These are very similar molecules - large shared scaffold expected
      assertTrue(mcs.size() >= 15,
          "RDKit#3965 pair should share large MCS >= 15, got " + mcs.size());
    }
  }

  @Nested
  @DisplayName("Symmetric Nightmares")
  class SymmetricNightmares {

    @Test
    @Timeout(10)
    @DisplayName("Adamantane self-match (48 automorphisms)")
    void adamantaneSelfMatchMcs() throws Exception {
      long t0 = System.nanoTime();
      IAtomContainer adam = mol("C1C2CC3CC1CC(C2)C3");
      assertEquals(10, adam.getAtomCount(), "Adamantane should have 10 heavy atoms");
      SMSD s = new SMSD(adam, adam, new ChemOptions());
      Map<Integer, Integer> mcs = s.findMCS(false, true, 9000);
      long elapsed = (System.nanoTime() - t0) / 1_000_000;
      System.out.println("Adamantane self-MCS=" + mcs.size() + " in " + elapsed + "ms");
      assertEquals(10, mcs.size(), "Adamantane self-match MCS should be 10");
    }

    @Test
    @Timeout(10)
    @DisplayName("Cubane self-match (Oh symmetry)")
    void cubaneSelfMatchMcs() throws Exception {
      long t0 = System.nanoTime();
      IAtomContainer cubane = mol("C12C3C4C1C5C3C4C25");
      assertEquals(8, cubane.getAtomCount(), "Cubane should have 8 heavy atoms");
      SMSD s = new SMSD(cubane, cubane, new ChemOptions());
      Map<Integer, Integer> mcs = s.findMCS(false, true, 9000);
      long elapsed = (System.nanoTime() - t0) / 1_000_000;
      System.out.println("Cubane self-MCS=" + mcs.size() + " in " + elapsed + "ms");
      assertEquals(8, mcs.size(), "Cubane self-match MCS should be 8");
    }

    @Test
    @Timeout(10)
    @DisplayName("Coronene self-match (D6h, 24 atoms)")
    void coroneneSelfMatchMcs() throws Exception {
      long t0 = System.nanoTime();
      IAtomContainer coronene = mol("c1cc2ccc3ccc4ccc5ccc6ccc1c7c2c3c4c5c67");
      assertEquals(24, coronene.getAtomCount(), "Coronene should have 24 heavy atoms");
      SMSD s = new SMSD(coronene, coronene, new ChemOptions());
      Map<Integer, Integer> mcs = s.findMCS(false, true, 9000);
      long elapsed = (System.nanoTime() - t0) / 1_000_000;
      System.out.println("Coronene self-MCS=" + mcs.size() + " in " + elapsed + "ms");
      assertEquals(24, mcs.size(), "Coronene self-match MCS should be 24");
    }
  }

  @Nested
  @DisplayName("Large Drug Molecules")
  class LargeDrugMolecules {

    @Test
    @Timeout(10)
    @DisplayName("Vancomycin self-match (66 atoms)")
    void vancomycinSelfMatch() throws Exception {
      long t0 = System.nanoTime();
      IAtomContainer vanc = mol(
          "CC1C(C(CC(O1)OC2C(C(C(OC2OC3=C4C=C5C=C3OC6=C(C=C(C=C6)"
          + "C(C(C(=O)NC(C(=O)NC5C(=O)NC7C8=CC(=C(C=C8)O)"
          + "C9=C(C=C(C=C9O)O)C(NC(=O)C(C(C1=CC(=C(O4)C=C1)Cl)O)"
          + "NC7=O)C(=O)O)CC(=O)N)NC(=O)C(CC(C)C)NC)O)Cl)CO)O)O)(C)N)O");
      int atomCount = vanc.getAtomCount();
      System.out.println("Vancomycin atom count: " + atomCount);
      assertTrue(atomCount >= 50, "Vancomycin should have >= 50 heavy atoms, got " + atomCount);
      SMSD s = new SMSD(vanc, vanc, new ChemOptions());
      Map<Integer, Integer> mcs = s.findMCS(false, true, 9000);
      long elapsed = (System.nanoTime() - t0) / 1_000_000;
      System.out.println("Vancomycin self-MCS=" + mcs.size() + " in " + elapsed + "ms");
      assertTrue(mcs.size() >= 30,
          "Vancomycin self-match MCS should be large (>= 30), got " + mcs.size());
    }

    @Test
    @Timeout(10)
    @DisplayName("Strychnine vs Quinine (different alkaloid scaffolds)")
    void strychnineVsQuinine() throws Exception {
      long t0 = System.nanoTime();
      IAtomContainer strychnine = mol("C1CN2CC3=CCOC4CC(=O)N5C6C4C3CC2C61C7=CC=CC=C75");
      IAtomContainer quinine = mol("COC1=CC2=C(C=CN=C2C=C1)C(C3CC4CCN3CC4C=C)O");
      SMSD s = new SMSD(strychnine, quinine, new ChemOptions());
      Map<Integer, Integer> mcs = s.findMCS(false, true, 9000);
      long elapsed = (System.nanoTime() - t0) / 1_000_000;
      System.out.println("Strychnine vs Quinine MCS=" + mcs.size() + " in " + elapsed + "ms");
      // Different scaffolds, small overlap expected
      assertTrue(mcs.size() >= 5,
          "Strychnine vs Quinine MCS should be >= 5, got " + mcs.size());
      assertTrue(mcs.size() <= 20,
          "Strychnine vs Quinine MCS should be <= 20 (different scaffolds), got " + mcs.size());
    }
  }

  @Nested
  @DisplayName("Polymer Chains")
  class PolymerChains {

    @Test
    @Timeout(10)
    @DisplayName("PEG-12 substructure of PEG-16")
    void peg12InPeg16() throws Exception {
      long t0 = System.nanoTime();
      // PEG-12: HO-(CH2-CH2-O)12-H = 12 ethylene-oxide units
      IAtomContainer peg12 = mol("OCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCO");
      IAtomContainer peg16 = mol("OCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCO");
      SMSD s = new SMSD(peg12, peg16, new ChemOptions());
      boolean isSub = s.isSubstructure(9000);
      long elapsed = (System.nanoTime() - t0) / 1_000_000;
      System.out.println("PEG-12 in PEG-16 substructure=" + isSub + " in " + elapsed + "ms");
      assertTrue(isSub, "PEG-12 should be substructure of PEG-16");
    }

    @Test
    @Timeout(10)
    @DisplayName("C30 substructure of C32")
    void c30InC32() throws Exception {
      long t0 = System.nanoTime();
      IAtomContainer c30 = mol("CCCCCCCCCCCCCCCCCCCCCCCCCCCCCC");
      IAtomContainer c32 = mol("CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC");
      assertEquals(30, c30.getAtomCount());
      assertEquals(32, c32.getAtomCount());
      SMSD s = new SMSD(c30, c32, new ChemOptions());
      boolean isSub = s.isSubstructure(9000);
      long elapsed = (System.nanoTime() - t0) / 1_000_000;
      System.out.println("C30 in C32 substructure=" + isSub + " in " + elapsed + "ms");
      assertTrue(isSub, "C30 should be substructure of C32");
    }

    @Test
    @Timeout(10)
    @DisplayName("PEG-12 vs PEG-16 MCS size")
    void peg12VsPeg16Mcs() throws Exception {
      long t0 = System.nanoTime();
      IAtomContainer peg12 = mol("OCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCO");
      IAtomContainer peg16 = mol("OCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCO");
      SMSD s = new SMSD(peg12, peg16, new ChemOptions());
      Map<Integer, Integer> mcs = s.findMCS(false, true, 9000);
      long elapsed = (System.nanoTime() - t0) / 1_000_000;
      System.out.println("PEG-12 vs PEG-16 MCS=" + mcs.size() + " in " + elapsed + "ms");
      // PEG-12 has all its atoms in PEG-16
      int peg12Atoms = peg12.getAtomCount();
      assertTrue(mcs.size() >= peg12Atoms - 2,
          "PEG MCS should cover most of PEG-12 (" + peg12Atoms + "), got " + mcs.size());
    }
  }

  @Nested
  @DisplayName("Nucleotide Pairs")
  class NucleotidePairs {

    @Test
    @Timeout(10)
    @DisplayName("ATP vs GTP MCS")
    void atpVsGtp() throws Exception {
      long t0 = System.nanoTime();
      IAtomContainer atp = mol(
          "C1=NC(=C2C(=N1)N(C=N2)C3C(C(C(O3)COP(=O)(O)OP(=O)(O)OP(=O)(O)O)O)O)N");
      IAtomContainer gtp = mol(
          "C1=NC2=C(N1C3C(C(C(O3)COP(=O)(O)OP(=O)(O)OP(=O)(O)O)O)O)NC(=NC2=O)N");
      SMSD s = new SMSD(atp, gtp, new ChemOptions());
      Map<Integer, Integer> mcs = s.findMCS(false, true, 9000);
      long elapsed = (System.nanoTime() - t0) / 1_000_000;
      System.out.println("ATP vs GTP MCS=" + mcs.size() + " in " + elapsed + "ms");
      // Share ribose + triphosphate + part of purine ring
      assertTrue(mcs.size() >= 18,
          "ATP vs GTP should share >= 18 atoms (ribose+triphosphate+purine), got " + mcs.size());
    }

    @Test
    @Timeout(10)
    @DisplayName("ATP self-match")
    void atpSelfMatch() throws Exception {
      long t0 = System.nanoTime();
      IAtomContainer atp = mol(
          "C1=NC(=C2C(=N1)N(C=N2)C3C(C(C(O3)COP(=O)(O)OP(=O)(O)OP(=O)(O)O)O)O)N");
      int atomCount = atp.getAtomCount();
      SMSD s = new SMSD(atp, atp, new ChemOptions());
      Map<Integer, Integer> mcs = s.findMCS(false, true, 9000);
      long elapsed = (System.nanoTime() - t0) / 1_000_000;
      System.out.println("ATP self-MCS=" + mcs.size() + "/" + atomCount + " in " + elapsed + "ms");
      assertEquals(atomCount, mcs.size(), "ATP self-match should be complete");
    }

    @Test
    @Timeout(10)
    @DisplayName("NAD+ vs FAD (simplified, uncharged)")
    void nadVsFad() throws Exception {
      long t0 = System.nanoTime();
      // Simplified NAD (nicotinamide riboside + ADP)
      IAtomContainer nad = mol(
          "NC(=O)c1ccc[n+](C2OC(COP(=O)(O)OP(=O)(O)OCC3OC(n4cnc5c(N)ncnc54)C(O)C3O)C(O)C2O)c1");
      IAtomContainer fad = mol(
          "Cc1cc2nc3c(=O)[nH]c(=O)nc3n(CC(O)C(O)C(O)COP(=O)(O)OP(=O)(O)OCC4OC(n5cnc6c(N)ncnc65)C(O)C4O)c2cc1C");
      SMSD s = new SMSD(nad, fad, new ChemOptions());
      Map<Integer, Integer> mcs = s.findMCS(false, true, 9000);
      long elapsed = (System.nanoTime() - t0) / 1_000_000;
      System.out.println("NAD vs FAD MCS=" + mcs.size() + " in " + elapsed + "ms");
      // Share ADP-ribose portion
      assertTrue(mcs.size() >= 15,
          "NAD vs FAD should share >= 15 atoms (ADP-ribose), got " + mcs.size());
    }
  }

  @Nested
  @DisplayName("Natural Products (complex fused rings)")
  class NaturalProducts {

    @Test
    @Timeout(10)
    @DisplayName("Strychnine self-match (24 atoms, 7 fused rings)")
    void strychnineSelfMatch() throws Exception {
      long t0 = System.nanoTime();
      IAtomContainer strychnine = mol("C1CN2CC3=CCOC4CC(=O)N5C6C4C3CC2C61C7=CC=CC=C75");
      int atomCount = strychnine.getAtomCount();
      System.out.println("Strychnine atom count: " + atomCount);
      SMSD s = new SMSD(strychnine, strychnine, new ChemOptions());
      Map<Integer, Integer> mcs = s.findMCS(false, true, 9000);
      long elapsed = (System.nanoTime() - t0) / 1_000_000;
      System.out.println("Strychnine self-MCS=" + mcs.size() + " in " + elapsed + "ms");
      assertEquals(atomCount, mcs.size(), "Strychnine self-match should be complete");
    }

    @Test
    @Timeout(10)
    @DisplayName("Paclitaxel vs Vinblastine (very different scaffolds)")
    void paclitaxelVsVinblastine() throws Exception {
      long t0 = System.nanoTime();
      // Simplified paclitaxel (taxol) core
      IAtomContainer paclitaxel = mol(
          "CC1=C2C(C(=O)C3(C(CC4C(C3C(C(C2(C)C)(CC1OC(=O)C(C(C5=CC=CC=C5)NC(=O)C6=CC=CC=C6)O)O)OC(=O)C7=CC=CC=C7)(CO4)OC(=O)C)O)C)OC(=O)C");
      // Vinblastine core
      IAtomContainer vinblastine = mol(
          "CCC1(CC2CC(C3=C(CCN(C2)C1)C4=CC=CC=C4N3)(C5=C(C=C6C(=C5)C78CCN9C7C(C=CC9)(C(C(C8N6C=O)(C(=O)OC)O)OC(=O)C)CC)OC)C(=O)OC)O");
      SMSD s = new SMSD(paclitaxel, vinblastine, new ChemOptions());
      Map<Integer, Integer> mcs = s.findMCS(false, true, 9000);
      long elapsed = (System.nanoTime() - t0) / 1_000_000;
      System.out.println("Paclitaxel vs Vinblastine MCS=" + mcs.size() + " in " + elapsed + "ms");
      // Very different scaffolds; small MCS expected
      assertTrue(mcs.size() >= 5,
          "Paclitaxel vs Vinblastine should share >= 5 atoms, got " + mcs.size());
    }

    @Test
    @Timeout(10)
    @DisplayName("Morphine vs Codeine (close analogues)")
    void morphineVsCodeine() throws Exception {
      long t0 = System.nanoTime();
      IAtomContainer morphine = mol("C1C2=CC=C3C4=C2C(CC1O)C5C4(CCN5C)C=C3O");
      IAtomContainer codeine = mol("C1C2=CC=C3C4=C2C(CC1O)C5C4(CCN5C)C=C3OC");
      SMSD s = new SMSD(morphine, codeine, new ChemOptions());
      Map<Integer, Integer> mcs = s.findMCS(false, true, 9000);
      long elapsed = (System.nanoTime() - t0) / 1_000_000;
      System.out.println("Morphine vs Codeine MCS=" + mcs.size() + " in " + elapsed + "ms");
      // Codeine = morphine + methyl group, should share most of morphine
      assertTrue(mcs.size() >= 15,
          "Morphine vs Codeine should share >= 15 atoms, got " + mcs.size());
    }
  }

  @Nested
  @DisplayName("Tautomer Stress Tests")
  class TautomerStress {

    @Test
    @Timeout(10)
    @DisplayName("Guanine keto vs enol (tautomer-aware full match)")
    void guanineKetoVsEnol() throws Exception {
      long t0 = System.nanoTime();
      ChemOptions c = ChemOptions.tautomerProfile();
      IAtomContainer ketoGuanine = mol("O=c1[nH]c(N)nc2[nH]cnc12");
      IAtomContainer enolGuanine = mol("Oc1nc(N)nc2[nH]cnc12");
      int atomCount = ketoGuanine.getAtomCount();
      System.out.println("Guanine atom count: " + atomCount);
      SMSD s = new SMSD(ketoGuanine, enolGuanine, c);
      Map<Integer, Integer> mcs = s.findMCS(true, false, 9000);
      long elapsed = (System.nanoTime() - t0) / 1_000_000;
      System.out.println("Guanine keto vs enol MCS=" + mcs.size() + " in " + elapsed + "ms");
      // With tautomer awareness, these should be near-complete match
      assertTrue(mcs.size() >= 8,
          "Guanine tautomers should share >= 8 atoms with tautomer profile, got " + mcs.size());
    }

    @Test
    @Timeout(10)
    @DisplayName("Barbital vs Phenobarbital (tautomer-aware)")
    void barbitalVsPhenobarbital() throws Exception {
      long t0 = System.nanoTime();
      ChemOptions c = ChemOptions.tautomerProfile();
      IAtomContainer barbital = mol("CCC1(C(=O)NC(=O)NC1=O)CC");
      IAtomContainer phenobarbital = mol("CCC1(C(=O)NC(=O)NC1=O)c2ccccc2");
      SMSD s = new SMSD(barbital, phenobarbital, c);
      Map<Integer, Integer> mcs = s.findMCS(true, false, 9000);
      long elapsed = (System.nanoTime() - t0) / 1_000_000;
      System.out.println("Barbital vs Phenobarbital MCS=" + mcs.size() + " in " + elapsed + "ms");
      // Share barbituric acid ring + one ethyl group
      assertTrue(mcs.size() >= 8,
          "Barbital vs Phenobarbital should share >= 8 atoms, got " + mcs.size());
    }

    @Test
    @Timeout(10)
    @DisplayName("Thymine keto vs enol tautomers")
    void thymineKetoVsEnol() throws Exception {
      long t0 = System.nanoTime();
      ChemOptions c = ChemOptions.tautomerProfile();
      IAtomContainer ketoThymine = mol("Cc1c[nH]c(=O)[nH]c1=O");
      IAtomContainer enolThymine = mol("CC1=CNC(=NC1O)O");
      SMSD s = new SMSD(ketoThymine, enolThymine, c);
      Map<Integer, Integer> mcs = s.findMCS(true, false, 9000);
      long elapsed = (System.nanoTime() - t0) / 1_000_000;
      System.out.println("Thymine keto vs enol MCS=" + mcs.size() + " in " + elapsed + "ms");
      assertTrue(mcs.size() >= 7,
          "Thymine tautomers should share >= 7 atoms with tautomer profile, got " + mcs.size());
    }

    @Test
    @Timeout(10)
    @DisplayName("Uracil vs Cytosine (different bases, limited tautomer overlap)")
    void uracilVsCytosine() throws Exception {
      long t0 = System.nanoTime();
      ChemOptions c = ChemOptions.tautomerProfile();
      IAtomContainer uracil = mol("O=c1cc[nH]c(=O)[nH]1");
      IAtomContainer cytosine = mol("Nc1cc[nH]c(=O)n1");
      SMSD s = new SMSD(uracil, cytosine, c);
      Map<Integer, Integer> mcs = s.findMCS(true, false, 9000);
      long elapsed = (System.nanoTime() - t0) / 1_000_000;
      System.out.println("Uracil vs Cytosine MCS=" + mcs.size() + " in " + elapsed + "ms");
      // Share pyrimidine ring core
      assertTrue(mcs.size() >= 5,
          "Uracil vs Cytosine should share >= 5 atoms (pyrimidine core), got " + mcs.size());
    }
  }
}
