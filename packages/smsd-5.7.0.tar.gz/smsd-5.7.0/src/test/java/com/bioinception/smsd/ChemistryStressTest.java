/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2018-2026 BioInception PVT LTD
 * Algorithm Copyright (c) 2009-2026 Syed Asad Rahman
 */
package com.bioinception.smsd;

import com.bioinception.smsd.core.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.condition.*;
import static org.junit.jupiter.api.Assertions.*;
import org.openscience.cdk.interfaces.IAtomContainer;
import java.util.*;

/**
 * Definitive stress test suite covering all chemistry cases and algorithm stress tests.
 * 200+ tests across 11 nested groups.
 *
 * @author Syed Asad Rahman
 */
public class ChemistryStressTest extends TestBase {

  // ======================================================================
  // Helper: compute MCS size between two SMILES
  // ======================================================================
  private static int mcsSize(String smi1, String smi2, ChemOptions opts, long timeoutMs) throws Exception {
    SMSD smsd = new SMSD(mol(smi1), mol(smi2), opts);
    smsd.setMcsTimeoutMs(timeoutMs);
    Map<Integer, Integer> mcs = smsd.findMCS(false, true, timeoutMs);
    return mcs.size();
  }

  private static int mcsSize(String smi1, String smi2) throws Exception {
    return mcsSize(smi1, smi2, new ChemOptions(), 10_000L);
  }

  private static Map<Integer, Integer> mcs(String smi1, String smi2, ChemOptions opts, long timeoutMs) throws Exception {
    SMSD smsd = new SMSD(mol(smi1), mol(smi2), opts);
    smsd.setMcsTimeoutMs(timeoutMs);
    return smsd.findMCS(false, true, timeoutMs);
  }

  private static List<String> validate(String smi1, String smi2, Map<Integer, Integer> mapping, ChemOptions opts) throws Exception {
    MolGraph g1 = new MolGraph(mol(smi1));
    MolGraph g2 = new MolGraph(mol(smi2));
    return SearchEngine.validateMapping(g1, g2, mapping, opts);
  }

  // ======================================================================
  // 1. ALL BOND ORDERS
  // ======================================================================

  @Nested
  @DisplayName("1. AllBondOrders")
  class AllBondOrders {

    @Test @DisplayName("Single C-C bond substructure")
    void singleCC() throws Exception {
      assertTrue(new SMSD(mol("CC"), mol("CCC"), new ChemOptions()).isSubstructure());
    }

    @Test @DisplayName("Double C=C bond substructure")
    void doubleCC() throws Exception {
      assertTrue(new SMSD(mol("C=C"), mol("C=CC"), new ChemOptions()).isSubstructure());
    }

    @Test @DisplayName("Triple C#C bond substructure")
    void tripleCC() throws Exception {
      assertTrue(new SMSD(mol("C#C"), mol("C#CC"), new ChemOptions()).isSubstructure());
    }

    @Test @DisplayName("Aromatic c:c bond in benzene")
    void aromaticCC() throws Exception {
      assertTrue(new SMSD(mol("c1ccccc1"), mol("c1ccc(C)cc1"), new ChemOptions()).isSubstructure());
    }

    @Test @DisplayName("Mixed bond orders: C=C-C#N")
    void mixedBondOrders() throws Exception {
      assertTrue(new SMSD(mol("C=CC#N"), mol("C=CC#N"), new ChemOptions()).isSubstructure());
    }

    @Test @DisplayName("Delocalized: benzene MCS with itself")
    void delocalizedBenzene() throws Exception {
      assertEquals(6, mcsSize("c1ccccc1", "c1ccccc1"));
    }

    @Test @DisplayName("Delocalized: naphthalene MCS with itself")
    void delocalizedNaphthalene() throws Exception {
      assertEquals(10, mcsSize("c1ccc2ccccc2c1", "c1ccc2ccccc2c1"));
    }

    @Test @DisplayName("Delocalized: pyridine MCS with itself")
    void delocalizedPyridine() throws Exception {
      assertEquals(6, mcsSize("c1ccncc1", "c1ccncc1"));
    }

    @Test @DisplayName("LOOSE mode: C=C matches C-C")
    void looseModeDoubleMatchesSingle() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchBondOrder = ChemOptions.BondOrderMode.LOOSE;
      assertTrue(new SMSD(mol("C=C"), mol("CC"), opts).isSubstructure());
    }

    @Test @DisplayName("STRICT mode: C=C does NOT match C-C")
    void strictModeDoubleMismatchSingle() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchBondOrder = ChemOptions.BondOrderMode.STRICT;
      assertFalse(new SMSD(mol("C=C"), mol("CC"), opts).isSubstructure());
    }

    @Test @DisplayName("ANY mode: everything matches")
    void anyModeTripleMatchesSingle() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchBondOrder = ChemOptions.BondOrderMode.ANY;
      assertTrue(new SMSD(mol("C#C"), mol("CC"), opts).isSubstructure());
    }

    @Test @DisplayName("Bond order MCS: aspirin STRICT mode")
    void aspirinStrict() throws Exception {
      String aspirin = "CC(=O)Oc1ccccc1C(=O)O";
      String salicylicAcid = "OC(=O)c1ccccc1O";
      ChemOptions strict = ChemOptions.profile("strict");
      int sz = mcsSize(aspirin, salicylicAcid, strict, 10_000L);
      assertTrue(sz >= 9, "Aspirin/salicylic acid share aromatic ring + carboxyl");
    }

    @Test @DisplayName("Bond order MCS: aspirin LOOSE mode")
    void aspirinLoose() throws Exception {
      String aspirin = "CC(=O)Oc1ccccc1C(=O)O";
      String salicylicAcid = "OC(=O)c1ccccc1O";
      ChemOptions loose = new ChemOptions();
      loose.matchBondOrder = ChemOptions.BondOrderMode.LOOSE;
      int sz = mcsSize(aspirin, salicylicAcid, loose, 10_000L);
      assertTrue(sz >= 9, "LOOSE mode should find at least same MCS");
    }

    @Test @DisplayName("Bond order MCS: aspirin ANY mode >= STRICT mode")
    void aspirinAnyGteStrict() throws Exception {
      String aspirin = "CC(=O)Oc1ccccc1C(=O)O";
      String salicylicAcid = "OC(=O)c1ccccc1O";
      ChemOptions strict = ChemOptions.profile("strict");
      ChemOptions any = new ChemOptions();
      any.matchBondOrder = ChemOptions.BondOrderMode.ANY;
      int szStrict = mcsSize(aspirin, salicylicAcid, strict, 10_000L);
      int szAny = mcsSize(aspirin, salicylicAcid, any, 10_000L);
      assertTrue(szAny >= szStrict, "ANY mode MCS >= STRICT mode MCS");
    }

    @Test @DisplayName("STRICT: double bond does not match triple bond")
    void strictDoubleNotTriple() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchBondOrder = ChemOptions.BondOrderMode.STRICT;
      assertFalse(new SMSD(mol("C=C"), mol("C#C"), opts).isSubstructure());
    }
  }

  // ======================================================================
  // 2. ALL ATOM TYPES
  // ======================================================================

  @Nested
  @DisplayName("2. AllAtomTypes")
  class AllAtomTypes {

    @Test @DisplayName("Carbon in ethane")
    void carbon() throws Exception {
      assertTrue(new SMSD(mol("C"), mol("CC"), new ChemOptions()).isSubstructure());
    }

    @Test @DisplayName("Nitrogen in methylamine")
    void nitrogen() throws Exception {
      assertTrue(new SMSD(mol("N"), mol("CN"), new ChemOptions()).isSubstructure());
    }

    @Test @DisplayName("Oxygen in methanol")
    void oxygen() throws Exception {
      assertTrue(new SMSD(mol("O"), mol("CO"), new ChemOptions()).isSubstructure());
    }

    @Test @DisplayName("Sulfur in methanethiol")
    void sulfur() throws Exception {
      assertTrue(new SMSD(mol("S"), mol("CS"), new ChemOptions()).isSubstructure());
    }

    @Test @DisplayName("Phosphorus in phosphine")
    void phosphorus() throws Exception {
      assertTrue(new SMSD(mol("P"), mol("CP"), new ChemOptions()).isSubstructure());
    }

    @Test @DisplayName("Fluorine in fluoromethane")
    void fluorine() throws Exception {
      assertTrue(new SMSD(mol("F"), mol("CF"), new ChemOptions()).isSubstructure());
    }

    @Test @DisplayName("Chlorine in chloromethane")
    void chlorine() throws Exception {
      assertTrue(new SMSD(mol("Cl"), mol("CCl"), new ChemOptions()).isSubstructure());
    }

    @Test @DisplayName("Bromine in bromomethane")
    void bromine() throws Exception {
      assertTrue(new SMSD(mol("Br"), mol("CBr"), new ChemOptions()).isSubstructure());
    }

    @Test @DisplayName("Iodine in iodomethane")
    void iodine() throws Exception {
      assertTrue(new SMSD(mol("I"), mol("CI"), new ChemOptions()).isSubstructure());
    }

    @Test @DisplayName("Boron in borane")
    void boron() throws Exception {
      assertTrue(new SMSD(mol("[B]"), mol("[B]C"), new ChemOptions()).isSubstructure());
    }

    @Test @DisplayName("Silicon in silane")
    void silicon() throws Exception {
      assertTrue(new SMSD(mol("[Si]"), mol("[Si](C)(C)C"), new ChemOptions()).isSubstructure());
    }

    @Test @DisplayName("Selenium in dimethylselenide")
    void selenium() throws Exception {
      assertTrue(new SMSD(mol("[Se]"), mol("C[Se]C"), new ChemOptions()).isSubstructure());
    }

    @Test @DisplayName("Iron: ferrocene SMILES parses gracefully")
    void ferrocene() throws Exception {
      // Ferrocene may not fully parse or match, but should not crash
      assertDoesNotThrow(() -> {
        IAtomContainer fc = mol("[Fe+2]");
        new SMSD(fc, fc, new ChemOptions()).isSubstructure();
      });
    }

    @Test @DisplayName("Platinum: cisplatin handled gracefully")
    void cisplatin() throws Exception {
      assertDoesNotThrow(() -> {
        IAtomContainer pt = mol("[Pt]");
        new SMSD(pt, mol("[Pt](Cl)(Cl)(N)N"), new ChemOptions()).isSubstructure();
      });
    }

    @Test @DisplayName("Wildcard * atom in SMARTS matching")
    void wildcardAtom() throws Exception {
      SMSD smsd = new SMSD("[#6]~[#7]", mol("CN"), new ChemOptions());
      assertTrue(smsd.isSubstructure());
    }

    @Test @DisplayName("Deuterium [2H] vs protium [H]")
    void deuteriumVsProtium() throws Exception {
      // Without isotope matching, they should be equivalent
      ChemOptions opts = new ChemOptions();
      opts.matchIsotope = false;
      IAtomContainer deuterated = mol("[2H]C([2H])([2H])[2H]");
      IAtomContainer normal = mol("C");
      SMSD smsd = new SMSD(normal, deuterated, opts);
      assertTrue(smsd.isSubstructure(), "Without isotope matching, C should match [2H]C");
    }

    @Test @DisplayName("Deuterium with matchIsotope ON")
    void deuteriumIsotopeOn() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchIsotope = true;
      // 13C vs 12C: with isotope matching ON, should not match
      IAtomContainer c13 = mol("[13CH4]");
      IAtomContainer c12 = mol("[12CH4]");
      SMSD smsd = new SMSD(c13, c12, opts);
      assertFalse(smsd.isSubstructure(), "13C should not match 12C with isotope matching ON");
    }

    @Test @DisplayName("13C isotope matching OFF: 13C matches regular C")
    void c13IsotopeOff() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchIsotope = false;
      IAtomContainer c13 = mol("[13CH4]");
      IAtomContainer regular = mol("C");
      SMSD smsd = new SMSD(regular, c13, opts);
      assertTrue(smsd.isSubstructure(), "Without isotope matching, regular C matches 13C");
    }

    @Test @DisplayName("Mixed heteroatoms: thiazole substructure")
    void thiazole() throws Exception {
      assertTrue(new SMSD(mol("c1cscn1"), mol("c1csc(C)n1"), new ChemOptions()).isSubstructure());
    }
  }

  // ======================================================================
  // 3. ALL CHARGE STATES
  // ======================================================================

  @Nested
  @DisplayName("3. AllChargeStates")
  class AllChargeStates {

    @Test @DisplayName("Neutral amine vs ammonium: charge ON, no match")
    void amineVsAmmoniumChargeOn() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchFormalCharge = true;
      assertFalse(new SMSD(mol("[NH4+]"), mol("N"), opts).isSubstructure());
    }

    @Test @DisplayName("Neutral amine vs ammonium: charge OFF, match")
    void amineVsAmmoniumChargeOff() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchFormalCharge = false;
      assertTrue(new SMSD(mol("[NH4+]"), mol("N"), opts).isSubstructure());
    }

    @Test @DisplayName("Carboxylic acid vs carboxylate: charge ON")
    void acidVsCarboxylateChargeOn() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchFormalCharge = true;
      // [O-] should NOT match O in carboxylic acid
      assertFalse(new SMSD(mol("[O-]C=O"), mol("OC(=O)C"), opts).isSubstructure());
    }

    @Test @DisplayName("Carboxylic acid vs carboxylate: charge OFF")
    void acidVsCarboxylateChargeOff() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchFormalCharge = false;
      assertTrue(new SMSD(mol("[O-]C=O"), mol("OC(=O)C"), opts).isSubstructure());
    }

    @Test @DisplayName("Zwitterion glycine self-match")
    void zwitterionGlycineSelf() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchFormalCharge = true;
      String glycine = "[NH3+]CC([O-])=O";
      assertTrue(new SMSD(mol(glycine), mol(glycine), opts).isSubstructure());
    }

    @Test @DisplayName("Zwitterion glycine vs neutral glycine: charge ON")
    void zwitterionVsNeutralChargeOn() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchFormalCharge = true;
      SMSD smsd = new SMSD(mol("[NH3+]CC([O-])=O"), mol("NCC(=O)O"), opts);
      assertFalse(smsd.isSubstructure(), "Charged vs neutral should not match with charge ON");
    }

    @Test @DisplayName("Zwitterion glycine vs neutral glycine: charge OFF")
    void zwitterionVsNeutralChargeOff() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchFormalCharge = false;
      SMSD smsd = new SMSD(mol("[NH3+]CC([O-])=O"), mol("NCC(=O)O"), opts);
      assertTrue(smsd.isSubstructure(), "Charged vs neutral should match with charge OFF");
    }

    @Test @DisplayName("Dication Mg2+ self-match")
    void magnesiumDication() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchFormalCharge = true;
      assertTrue(new SMSD(mol("[Mg+2]"), mol("[Mg+2]"), opts).isSubstructure());
    }

    @Test @DisplayName("Dication Ca2+ self-match")
    void calciumDication() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchFormalCharge = true;
      assertTrue(new SMSD(mol("[Ca+2]"), mol("[Ca+2]"), opts).isSubstructure());
    }

    @Test @DisplayName("Mg2+ does not match Mg0 with charge ON")
    void mgChargedVsNeutral() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchFormalCharge = true;
      assertFalse(new SMSD(mol("[Mg+2]"), mol("[Mg]"), opts).isSubstructure());
    }

    @Test @DisplayName("Mg2+ matches Mg0 with charge OFF")
    void mgChargedMatchesNeutralOff() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchFormalCharge = false;
      assertTrue(new SMSD(mol("[Mg+2]"), mol("[Mg]"), opts).isSubstructure());
    }

    @Test @DisplayName("Phosphate anion self-match")
    void phosphateAnion() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchFormalCharge = true;
      String phosphate = "[O-]P([O-])(=O)[O-]";
      assertTrue(new SMSD(mol(phosphate), mol(phosphate), opts).isSubstructure());
    }

    @Test @DisplayName("Sulfonate anion MCS")
    void sulfonateAnion() throws Exception {
      String methanesulfonate = "CS(=O)(=O)[O-]";
      int sz = mcsSize(methanesulfonate, methanesulfonate);
      assertTrue(sz >= 4, "Sulfonate self MCS");
    }

    @Test @DisplayName("Quaternary ammonium self-match")
    void quaternaryAmmonium() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchFormalCharge = true;
      String quat = "C[N+](C)(C)C";
      assertTrue(new SMSD(mol(quat), mol(quat), opts).isSubstructure());
    }

    @Test @DisplayName("Betaine: internal salt self-match")
    void betaine() throws Exception {
      String betaine = "C[N+](C)(C)CC([O-])=O";
      int sz = mcsSize(betaine, betaine);
      assertTrue(sz >= 6, "Betaine self MCS");
    }
  }

  // ======================================================================
  // 4. ALL STEREO CONFIGURATIONS
  // ======================================================================

  @Nested
  @DisplayName("4. AllStereoConfigurations")
  class AllStereoConfigurations {

    @Test @DisplayName("R-alanine vs S-alanine: chirality OFF, match")
    void alanineChiralityOff() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.useChirality = false;
      String rAla = "N[C@@H](C)C(=O)O";
      String sAla = "N[C@H](C)C(=O)O";
      assertTrue(new SMSD(mol(rAla), mol(sAla), opts).isSubstructure());
    }

    @Test @DisplayName("R-alanine vs S-alanine: chirality ON, no match")
    void alanineChiralityOn() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.useChirality = true;
      String rAla = "N[C@@H](C)C(=O)O";
      String sAla = "N[C@H](C)C(=O)O";
      assertFalse(new SMSD(mol(rAla), mol(sAla), opts).isSubstructure());
    }

    @Test @DisplayName("R-alanine self-match: chirality ON")
    void rAlanineSelfChiralityOn() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.useChirality = true;
      String rAla = "N[C@@H](C)C(=O)O";
      assertTrue(new SMSD(mol(rAla), mol(rAla), opts).isSubstructure());
    }

    @Test @DisplayName("E-stilbene vs Z-stilbene: bond stereo OFF, match MCS")
    void stilbeneBondStereoOff() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.useBondStereo = false;
      String eStilbene = "C(=C/c1ccccc1)\\c1ccccc1";
      String zStilbene = "C(=C\\c1ccccc1)\\c1ccccc1";
      int sz = mcsSize(eStilbene, zStilbene, opts, 10_000L);
      assertTrue(sz >= 12, "E/Z stilbene with stereo OFF should share all atoms");
    }

    @Test @DisplayName("E-stilbene vs Z-stilbene: bond stereo ON")
    void stilbeneBondStereoOn() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.useBondStereo = true;
      String eStilbene = "C(=C/c1ccccc1)\\c1ccccc1";
      String zStilbene = "C(=C\\c1ccccc1)\\c1ccccc1";
      SMSD smsd = new SMSD(mol(eStilbene), mol(zStilbene), opts);
      assertFalse(smsd.isSubstructure(), "E/Z should differ with bond stereo ON");
    }

    @Test @DisplayName("Meso tartaric acid self-match")
    void mesoTartaricAcid() throws Exception {
      String meso = "O[C@@H](C(=O)O)[C@H](O)C(=O)O";
      assertEquals(10, mcsSize(meso, meso));
    }

    @Test @DisplayName("Multiple stereocenters: chirality OFF, full MCS")
    void multipleStereoCentersOff() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.useChirality = false;
      // Two diastereomers of 2,3-butanediol
      String rr = "C[C@@H](O)[C@@H](O)C";
      String rs = "C[C@@H](O)[C@H](O)C";
      int sz = mcsSize(rr, rs, opts, 10_000L);
      assertTrue(sz >= 5, "Without chirality all atoms should match");
    }

    @Test @DisplayName("Multiple stereocenters: chirality ON, reduced MCS")
    void multipleStereoCentersOn() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.useChirality = true;
      String rr = "C[C@@H](O)[C@@H](O)C";
      String rs = "C[C@@H](O)[C@H](O)C";
      SMSD smsd = new SMSD(mol(rr), mol(rs), opts);
      assertFalse(smsd.isSubstructure(), "Different stereo should not be substructure with chirality ON");
    }

    @Test @DisplayName("No stereo centers: methane self-match unaffected by chirality")
    void methaneNoStereo() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.useChirality = true;
      assertTrue(new SMSD(mol("C"), mol("C"), opts).isSubstructure());
    }

    @Test @DisplayName("No stereo centers: ethane self-match unaffected by chirality")
    void ethaneNoStereo() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.useChirality = true;
      assertTrue(new SMSD(mol("CC"), mol("CC"), opts).isSubstructure());
    }

    @Test @DisplayName("Chirality OFF: L-glucose matches D-glucose")
    void glucoseChiralityOff() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.useChirality = false;
      String dGlucose = "OC[C@H]1OC(O)[C@H](O)[C@@H](O)[C@@H]1O";
      String lGlucose = "OC[C@@H]1OC(O)[C@@H](O)[C@H](O)[C@H]1O";
      assertTrue(new SMSD(mol(dGlucose), mol(lGlucose), opts).isSubstructure());
    }

    @Test @DisplayName("Chirality ON: L-glucose does not match D-glucose")
    void glucoseChiralityOn() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.useChirality = true;
      String dGlucose = "OC[C@H]1OC(O)[C@H](O)[C@@H](O)[C@@H]1O";
      String lGlucose = "OC[C@@H]1OC(O)[C@@H](O)[C@H](O)[C@H]1O";
      assertFalse(new SMSD(mol(dGlucose), mol(lGlucose), opts).isSubstructure());
    }

    @Test @DisplayName("Cis vs trans 2-butene: bond stereo OFF, full MCS")
    void cisTransButeneStereoOff() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.useBondStereo = false;
      String cis = "C/C=C\\C";
      String trans = "C/C=C/C";
      int sz = mcsSize(cis, trans, opts, 10_000L);
      assertEquals(4, sz, "Cis/trans with stereo OFF should match all 4 atoms");
    }

    @Test @DisplayName("Cis vs trans 2-butene: bond stereo ON")
    void cisTransButeneStereoOn() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.useBondStereo = true;
      String cis = "C/C=C\\C";
      String trans = "C/C=C/C";
      SMSD smsd = new SMSD(mol(cis), mol(trans), opts);
      assertFalse(smsd.isSubstructure(), "Cis and trans should differ with stereo ON");
    }

    @Test @DisplayName("Prochiral center: no stereo, matches with chirality ON")
    void prochiral() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.useChirality = true;
      // Acetone has no stereo center
      assertTrue(new SMSD(mol("CC(=O)C"), mol("CC(=O)C"), opts).isSubstructure());
    }

    @Test @DisplayName("Axial chirality: biaryls - no crash")
    void axialChirality() throws Exception {
      // BINAP-like fragment - just test no crash
      assertDoesNotThrow(() -> {
        IAtomContainer m = mol("c1ccc(-c2ccccc2)cc1");
        new SMSD(m, m, new ChemOptions()).findMCS();
      });
    }

    @Test @DisplayName("Allene: no crash with chirality on")
    void alleneChirality() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.useChirality = true;
      assertDoesNotThrow(() -> {
        IAtomContainer allene = mol("C=C=C");
        new SMSD(allene, allene, opts).isSubstructure();
      });
    }

    @Test @DisplayName("Ephedrine diastereomers: chirality OFF MCS = full")
    void ephedrineChiralityOff() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.useChirality = false;
      String erythro = "CN[C@@H](C)[C@H](O)c1ccccc1";
      String threo = "CN[C@@H](C)[C@@H](O)c1ccccc1";
      int sz = mcsSize(erythro, threo, opts, 10_000L);
      assertTrue(sz >= 11, "All atoms should match with chirality OFF");
    }
  }

  // ======================================================================
  // 5. ALL RING TYPES
  // ======================================================================

  @Nested
  @DisplayName("5. AllRingTypes")
  class AllRingTypes {

    @Test @DisplayName("3-membered ring: cyclopropane")
    void cyclopropane() throws Exception {
      assertEquals(3, mcsSize("C1CC1", "C1CC1"));
    }

    @Test @DisplayName("4-membered ring: cyclobutane")
    void cyclobutane() throws Exception {
      assertEquals(4, mcsSize("C1CCC1", "C1CCC1"));
    }

    @Test @DisplayName("5-membered ring: cyclopentane")
    void cyclopentane() throws Exception {
      assertEquals(5, mcsSize("C1CCCC1", "C1CCCC1"));
    }

    @Test @DisplayName("5-membered ring: furan")
    void furan() throws Exception {
      assertEquals(5, mcsSize("c1ccoc1", "c1ccoc1"));
    }

    @Test @DisplayName("5-membered ring: pyrrole")
    void pyrrole() throws Exception {
      assertEquals(5, mcsSize("c1cc[nH]c1", "c1cc[nH]c1"));
    }

    @Test @DisplayName("6-membered ring: cyclohexane")
    void cyclohexane() throws Exception {
      assertEquals(6, mcsSize("C1CCCCC1", "C1CCCCC1"));
    }

    @Test @DisplayName("6-membered ring: benzene")
    void benzene() throws Exception {
      assertEquals(6, mcsSize("c1ccccc1", "c1ccccc1"));
    }

    @Test @DisplayName("6-membered ring: pyridine")
    void pyridine() throws Exception {
      assertEquals(6, mcsSize("c1ccncc1", "c1ccncc1"));
    }

    @Test @DisplayName("7-membered ring: cycloheptane")
    void cycloheptane() throws Exception {
      assertEquals(7, mcsSize("C1CCCCCC1", "C1CCCCCC1"));
    }

    @Test @DisplayName("7-membered ring: azepine-like")
    void azepine() throws Exception {
      int sz = mcsSize("C1=CC=CC=CN1", "C1=CC=CC=CN1");
      assertTrue(sz >= 6, "Azepine self MCS");
    }

    @Test @DisplayName("8-membered ring: cyclooctane")
    void cyclooctane() throws Exception {
      assertEquals(8, mcsSize("C1CCCCCCC1", "C1CCCCCCC1"));
    }

    @Test @DisplayName("Fused: naphthalene")
    void naphthalene() throws Exception {
      assertEquals(10, mcsSize("c1ccc2ccccc2c1", "c1ccc2ccccc2c1"));
    }

    @Test @DisplayName("Fused: anthracene")
    void anthracene() throws Exception {
      assertEquals(14, mcsSize("c1ccc2cc3ccccc3cc2c1", "c1ccc2cc3ccccc3cc2c1"));
    }

    @Test @DisplayName("Fused: phenanthrene")
    void phenanthrene() throws Exception {
      assertEquals(14, mcsSize("c1ccc2c(c1)ccc1ccccc12", "c1ccc2c(c1)ccc1ccccc12"));
    }

    @Test @DisplayName("Bridged: norbornane")
    void norbornane() throws Exception {
      String norbornane = "C1CC2CC1CC2";
      assertEquals(7, mcsSize(norbornane, norbornane));
    }

    @Test @DisplayName("Bridged: adamantane")
    void adamantane() throws Exception {
      String adamantane = "C1C2CC3CC1CC(C2)C3";
      int sz = mcsSize(adamantane, adamantane);
      assertEquals(10, sz, "Adamantane has 10 carbons");
    }

    @Test @DisplayName("Spiro: spiro[4.4]nonane")
    void spiroNonane() throws Exception {
      String spiro = "C1CCC2(C1)CCCC2";
      assertEquals(9, mcsSize(spiro, spiro));
    }

    @Test @DisplayName("Macrocycle: 18-crown-6")
    void crown6() throws Exception {
      String crown = "C1COCCOCCOCCOCCOCCO1";
      int sz = mcsSize(crown, crown);
      assertTrue(sz >= 18, "18-crown-6 self MCS should be at least 18");
    }

    @Test @DisplayName("completeRingsOnly: partial ring excluded")
    void completeRingsOnly() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.completeRingsOnly = true;
      // benzene (6) vs cyclopentane (5): ring atoms cannot partially overlap
      SMSD smsd = new SMSD(mol("c1ccccc1"), mol("C1CCCC1"), opts);
      Map<Integer, Integer> m = smsd.findMCS(false, true, 5000L);
      // With complete rings, either full ring or nothing
      assertTrue(m.size() == 0 || m.size() >= 5, "CompleteRingsOnly: all or nothing");
    }

    @Test @DisplayName("ringMatchesRingOnly: ring vs chain")
    void ringMatchesRingOnly() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.ringMatchesRingOnly = true;
      SMSD smsd = new SMSD(mol("c1ccccc1"), mol("CCCCCC"), opts);
      Map<Integer, Integer> m = smsd.findMCS(false, true, 5000L);
      assertTrue(m.isEmpty(), "Ring atoms cannot map to chain atoms");
    }

    @Test @DisplayName("ringFusionMode STRICT")
    void ringFusionStrict() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.ringFusionMode = ChemOptions.RingFusionMode.STRICT;
      // Naphthalene (fused) vs biphenyl (non-fused): strict should distinguish
      int sz = mcsSize("c1ccc2ccccc2c1", "c1ccc(-c2ccccc2)cc1", opts, 10_000L);
      // STRICT: bridgehead atoms (ringCount=2) can't match biphenyl (ringCount=1)
      // So MCS < 10 (excludes bridgeheads). May be as low as 4 for connected MCS.
      assertTrue(sz >= 1 && sz < 10, "STRICT MCS should be non-empty but less than full match, got " + sz);
    }

    @Test @DisplayName("ringFusionMode PERMISSIVE")
    void ringFusionPermissive() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.ringFusionMode = ChemOptions.RingFusionMode.PERMISSIVE;
      int sz = mcsSize("c1ccc2ccccc2c1", "c1ccc(-c2ccccc2)cc1", opts, 10_000L);
      assertTrue(sz >= 6, "Permissive should match at least one ring");
    }

    @Test @DisplayName("ringFusionMode IGNORE")
    void ringFusionIgnore() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.ringFusionMode = ChemOptions.RingFusionMode.IGNORE;
      int sz = mcsSize("c1ccc2ccccc2c1", "c1ccc(-c2ccccc2)cc1", opts, 10_000L);
      assertTrue(sz >= 6, "Ignore should match at least one ring");
    }
  }

  // ======================================================================
  // 6. ALL TAUTOMER PATTERNS
  // ======================================================================

  @Nested
  @DisplayName("6. AllTautomerPatterns")
  class AllTautomerPatterns {

    @Test @DisplayName("Keto/enol: acetone vs propen-2-ol")
    void ketoEnol() throws Exception {
      int sz = mcsSize("CC(=O)C", "CC(O)=C");
      assertTrue(sz >= 3, "Keto/enol share backbone");
    }

    @Test @DisplayName("Amide/imidic acid")
    void amideImidic() throws Exception {
      int sz = mcsSize("CC(=O)N", "CC(O)=N");
      assertTrue(sz >= 3, "Amide/imidic acid share backbone");
    }

    @Test @DisplayName("Lactam/lactim: 4-pyridinone vs 4-hydroxypyridine")
    void lactamLactim() throws Exception {
      int sz = mcsSize("O=c1cc[nH]cc1", "Oc1ccncc1");
      assertTrue(sz >= 5, "Lactam/lactim share pyridine ring");
    }

    @Test @DisplayName("Imidazole NH shift")
    void imidazoleNHShift() throws Exception {
      int sz = mcsSize("c1c[nH]cn1", "c1cnc[nH]1");
      assertTrue(sz >= 4, "Imidazole NH tautomers share ring atoms");
    }

    @Test @DisplayName("Thione/thiol")
    void thioneThiol() throws Exception {
      int sz = mcsSize("CC(=S)N", "CC(S)=N");
      assertTrue(sz >= 3, "Thione/thiol share backbone");
    }

    @Test @DisplayName("Nitroso/oxime")
    void nitrosoOxime() throws Exception {
      int sz = mcsSize("CC=NO", "CC(=O)N");
      assertTrue(sz >= 2, "Nitroso/oxime share some atoms");
    }

    @Test @DisplayName("Phenol/quinone partial MCS")
    void phenolQuinone() throws Exception {
      int sz = mcsSize("Oc1ccccc1", "O=C1C=CC(=O)C=C1");
      assertTrue(sz >= 4, "Phenol/quinone share ring carbons");
    }

    @Test @DisplayName("1,3-diketone enolization")
    void diketoneEnol() throws Exception {
      int sz = mcsSize("CC(=O)CC(=O)C", "CC(=O)/C=C(\\O)C");
      assertTrue(sz >= 4, "1,3-diketone enol share backbone");
    }

    @Test @DisplayName("Guanine keto/enol")
    void guanineKetoEnol() throws Exception {
      String ketoGuanine = "O=C1NC2=C(N=CN2)C(N)=N1";
      String enolGuanine = "OC1=NC2=C(N=CN2)C(N)=N1";
      int sz = mcsSize(ketoGuanine, enolGuanine);
      assertTrue(sz >= 8, "Guanine keto/enol share purine core");
    }

    @Test @DisplayName("Tautomer OFF vs ON: acetone/propen-2-ol, ON >= OFF")
    void tautomerOnGteOff() throws Exception {
      ChemOptions off = new ChemOptions();
      off.tautomerAware = false;
      ChemOptions on = ChemOptions.tautomerProfile();
      int szOff = mcsSize("CC(=O)C", "CC(O)=C", off, 10_000L);
      int szOn = mcsSize("CC(=O)C", "CC(O)=C", on, 10_000L);
      assertTrue(szOn >= szOff, "Tautomer ON MCS >= tautomer OFF MCS");
    }

    @Test @DisplayName("Tautomer OFF vs ON: lactam/lactim, ON >= OFF")
    void tautomerOnGteOffLactam() throws Exception {
      ChemOptions off = new ChemOptions();
      off.tautomerAware = false;
      ChemOptions on = ChemOptions.tautomerProfile();
      int szOff = mcsSize("O=c1cc[nH]cc1", "Oc1ccncc1", off, 10_000L);
      int szOn = mcsSize("O=c1cc[nH]cc1", "Oc1ccncc1", on, 10_000L);
      assertTrue(szOn >= szOff, "Tautomer ON MCS >= tautomer OFF MCS for lactam/lactim");
    }

    @Test @DisplayName("Tautomer OFF vs ON: imidazole shift, ON >= OFF")
    void tautomerOnGteOffImidazole() throws Exception {
      ChemOptions off = new ChemOptions();
      off.tautomerAware = false;
      ChemOptions on = ChemOptions.tautomerProfile();
      int szOff = mcsSize("c1c[nH]cn1", "c1cnc[nH]1", off, 10_000L);
      int szOn = mcsSize("c1c[nH]cn1", "c1cnc[nH]1", on, 10_000L);
      assertTrue(szOn >= szOff, "Tautomer ON MCS >= tautomer OFF MCS for imidazole");
    }

    @Test @DisplayName("Tautomer OFF vs ON: guanine, ON >= OFF")
    void tautomerOnGteOffGuanine() throws Exception {
      ChemOptions off = new ChemOptions();
      off.tautomerAware = false;
      ChemOptions on = ChemOptions.tautomerProfile();
      String keto = "O=C1NC2=C(N=CN2)C(N)=N1";
      String enol = "OC1=NC2=C(N=CN2)C(N)=N1";
      int szOff = mcsSize(keto, enol, off, 10_000L);
      int szOn = mcsSize(keto, enol, on, 10_000L);
      assertTrue(szOn >= szOff, "Tautomer ON MCS >= tautomer OFF MCS for guanine");
    }

    @Test @DisplayName("Tautomer profile uses LOOSE bond order")
    void tautomerProfileConfig() {
      ChemOptions tp = ChemOptions.tautomerProfile();
      assertTrue(tp.tautomerAware);
      assertEquals(ChemOptions.BondOrderMode.LOOSE, tp.matchBondOrder);
      assertFalse(tp.matchFormalCharge);
    }
  }

  // ======================================================================
  // 7. ALL MCS VARIANTS
  // ======================================================================

  @Nested
  @DisplayName("7. AllMCSVariants")
  class AllMCSVariants {

    @Test @DisplayName("MCIS (induced=true)")
    void mcis() throws Exception {
      SMSD smsd = new SMSD(mol("CCCC"), mol("CC=CC"), new ChemOptions());
      Map<Integer, Integer> m = smsd.findMCS(true, true, 10_000L);
      assertNotNull(m);
      assertTrue(m.size() >= 2, "Induced MCS should find common subgraph");
    }

    @Test @DisplayName("MCCS (connected=true)")
    void mccs() throws Exception {
      SMSD smsd = new SMSD(mol("CCCC"), mol("CC=CC"), new ChemOptions());
      Map<Integer, Integer> m = smsd.findMCS(false, true, 10_000L);
      assertTrue(m.size() >= 2);
    }

    @Test @DisplayName("MCES (maximizeBonds=true)")
    void mces() throws Exception {
      SearchEngine.McsOptions opts = new SearchEngine.McsOptions();
      opts.maximizeBonds = true;
      opts.timeoutMillis = 10_000L;
      MolGraph g1 = new MolGraph(mol("c1ccccc1"));
      MolGraph g2 = new MolGraph(mol("c1ccc(O)cc1"));
      Map<Integer, Integer> m = SearchEngine.findMCS(g1, g2, new ChemOptions(), opts);
      assertFalse(m.isEmpty(), "Bond-maximizing MCS should find result");
    }

    @Test @DisplayName("dMCS (disconnectedMCS=true)")
    void dmcs() throws Exception {
      SearchEngine.McsOptions opts = new SearchEngine.McsOptions();
      opts.disconnectedMCS = true;
      opts.connectedOnly = false;
      opts.timeoutMillis = 10_000L;
      MolGraph g1 = new MolGraph(mol("c1ccccc1.CCCC"));
      MolGraph g2 = new MolGraph(mol("c1ccc(C)cc1.CCCCC"));
      Map<Integer, Integer> m = SearchEngine.findMCS(g1, g2, new ChemOptions(), opts);
      assertFalse(m.isEmpty());
    }

    @Test @DisplayName("N-MCS (3 molecules)")
    void nmcs() throws Exception {
      List<IAtomContainer> mols = Arrays.asList(
          mol("c1ccc(O)cc1"), mol("c1ccc(N)cc1"), mol("c1ccc(Cl)cc1"));
      Map<Integer, Integer> nm = SMSD.findNMCS(mols, new ChemOptions(), 1.0, 10_000L);
      assertNotNull(nm);
      assertTrue(nm.size() >= 6, "All three share benzene ring");
    }

    @Test @DisplayName("Weighted MCS (atomWeights)")
    void weightedMcs() throws Exception {
      SearchEngine.McsOptions opts = new SearchEngine.McsOptions();
      opts.atomWeights = new double[]{1.0, 2.0, 1.0, 1.0, 1.0, 1.0};
      opts.timeoutMillis = 10_000L;
      MolGraph g1 = new MolGraph(mol("c1ccccc1"));
      MolGraph g2 = new MolGraph(mol("c1ccc(O)cc1"));
      Map<Integer, Integer> m = SearchEngine.findMCS(g1, g2, new ChemOptions(), opts);
      assertFalse(m.isEmpty());
    }

    @Test @DisplayName("Scaffold MCS (Murcko)")
    void scaffoldMcs() throws Exception {
      IAtomContainer m1 = mol("CC(=O)Oc1ccccc1C(=O)O"); // aspirin
      IAtomContainer m2 = mol("CC(C)Cc1ccc(C(C)C(=O)O)cc1"); // ibuprofen
      SearchEngine.McsOptions mcsOpts = new SearchEngine.McsOptions();
      mcsOpts.timeoutMillis = 10_000L;
      Map<Integer, Integer> sm = SMSD.findScaffoldMCS(m1, m2, new ChemOptions(), mcsOpts);
      assertNotNull(sm);
      assertTrue(sm.size() >= 4, "Scaffold MCS should share aromatic ring");
    }

    @Test @DisplayName("Fragment constraints: minFragmentSize")
    void fragmentMinSize() throws Exception {
      SearchEngine.McsOptions opts = new SearchEngine.McsOptions();
      opts.disconnectedMCS = true;
      opts.connectedOnly = false;
      opts.minFragmentSize = 3;
      opts.timeoutMillis = 10_000L;
      MolGraph g1 = new MolGraph(mol("CCCC"));
      MolGraph g2 = new MolGraph(mol("CCCC"));
      Map<Integer, Integer> m = SearchEngine.findMCS(g1, g2, new ChemOptions(), opts);
      assertFalse(m.isEmpty());
    }

    @Test @DisplayName("Fragment constraints: maxFragments")
    void fragmentMaxCount() throws Exception {
      SearchEngine.McsOptions opts = new SearchEngine.McsOptions();
      opts.disconnectedMCS = true;
      opts.connectedOnly = false;
      opts.maxFragments = 1;
      opts.timeoutMillis = 10_000L;
      MolGraph g1 = new MolGraph(mol("CCCC"));
      MolGraph g2 = new MolGraph(mol("CCCC"));
      Map<Integer, Integer> m = SearchEngine.findMCS(g1, g2, new ChemOptions(), opts);
      assertFalse(m.isEmpty());
    }

    @Test @DisplayName("MCCS >= MCIS always holds")
    void mccsGteMcis() throws Exception {
      SMSD smsd = new SMSD(mol("c1ccccc1C"), mol("c1ccccc1O"), new ChemOptions());
      Map<Integer, Integer> mccs = smsd.findMCS(false, true, 10_000L);
      Map<Integer, Integer> mcis = smsd.findMCS(true, true, 10_000L);
      assertTrue(mccs.size() >= mcis.size(), "MCCS size >= MCIS size");
    }

    @Test @DisplayName("N-MCS returns molecule")
    void nmcsMolecule() throws Exception {
      List<IAtomContainer> mols = Arrays.asList(
          mol("c1ccc(O)cc1"), mol("c1ccc(N)cc1"));
      IAtomContainer core = SMSD.findNMCSMolecule(mols, new ChemOptions(), 1.0, 10_000L);
      assertNotNull(core, "N-MCS molecule should not be null");
      assertTrue(core.getAtomCount() >= 6, "Core should be at least benzene");
    }

    @Test @DisplayName("MCS non-induced disconnected allows more atoms")
    void disconnectedMoreAtoms() throws Exception {
      SMSD smsd = new SMSD(mol("CC.OO"), mol("CCOCC"), new ChemOptions());
      Map<Integer, Integer> connected = smsd.findMCS(false, true, 5000L);
      Map<Integer, Integer> disconnected = smsd.findMCS(false, false, 5000L);
      assertTrue(disconnected.size() >= connected.size(), "Disconnected >= connected MCS");
    }

    @Test @DisplayName("Induced MCS: benzene in toluene preserves all 6 ring atoms")
    void inducedBenzeneToluene() throws Exception {
      SMSD smsd = new SMSD(mol("c1ccccc1"), mol("Cc1ccccc1"), new ChemOptions());
      Map<Integer, Integer> m = smsd.findMCS(true, true, 10_000L);
      assertEquals(6, m.size(), "Induced MCS of benzene in toluene = 6");
    }

    @Test @DisplayName("Non-induced MCS: benzene in toluene >= 6")
    void nonInducedBenzeneToluene() throws Exception {
      SMSD smsd = new SMSD(mol("c1ccccc1"), mol("Cc1ccccc1"), new ChemOptions());
      Map<Integer, Integer> m = smsd.findMCS(false, true, 10_000L);
      assertTrue(m.size() >= 6, "Non-induced MCS >= 6");
    }
  }

  // ======================================================================
  // 8. ALL CHEMOPTIONS PROFILES
  // ======================================================================

  @Nested
  @DisplayName("8. AllChemOptionsProfiles")
  class AllChemOptionsProfiles {

    @Test @DisplayName("Default profile")
    void defaultProfile() throws Exception {
      ChemOptions opts = new ChemOptions();
      assertEquals(ChemOptions.BondOrderMode.STRICT, opts.matchBondOrder);
      assertEquals(ChemOptions.AromaticityMode.FLEXIBLE, opts.aromaticityMode);
      assertTrue(opts.matchAtomType);
      assertTrue(opts.matchFormalCharge);
      assertFalse(opts.useChirality);
      assertFalse(opts.useBondStereo);
      assertTrue(opts.ringMatchesRingOnly);
      assertFalse(opts.completeRingsOnly);
      assertFalse(opts.matchIsotope);
      assertFalse(opts.tautomerAware);
      assertEquals(ChemOptions.RingFusionMode.IGNORE, opts.ringFusionMode);
      assertEquals(ChemOptions.MatcherEngine.VF2PP, opts.matcherEngine);
    }

    @Test @DisplayName("profile(strict)")
    void strictProfile() throws Exception {
      ChemOptions opts = ChemOptions.profile("strict");
      assertEquals(ChemOptions.BondOrderMode.STRICT, opts.matchBondOrder);
      assertEquals(ChemOptions.AromaticityMode.STRICT, opts.aromaticityMode);
      assertTrue(new SMSD(mol("c1ccccc1"), mol("c1ccc(O)cc1"), opts).isSubstructure());
    }

    @Test @DisplayName("profile(compat-substruct)")
    void compatSubstruct() throws Exception {
      ChemOptions opts = ChemOptions.profile("compat-substruct");
      assertEquals(ChemOptions.BondOrderMode.LOOSE, opts.matchBondOrder);
      assertEquals(ChemOptions.AromaticityMode.FLEXIBLE, opts.aromaticityMode);
      assertFalse(opts.ringMatchesRingOnly);
      assertTrue(new SMSD(mol("c1ccccc1"), mol("c1ccc(O)cc1"), opts).isSubstructure());
    }

    @Test @DisplayName("tautomerProfile()")
    void tautomerProfile() throws Exception {
      ChemOptions opts = ChemOptions.tautomerProfile();
      assertTrue(opts.tautomerAware);
      assertEquals(ChemOptions.BondOrderMode.LOOSE, opts.matchBondOrder);
      assertFalse(opts.matchFormalCharge);
      assertFalse(opts.ringMatchesRingOnly);
    }

    @Test @DisplayName("Custom: every field toggled from default")
    void customAllToggled() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchBondOrder = ChemOptions.BondOrderMode.ANY;
      opts.aromaticityMode = ChemOptions.AromaticityMode.STRICT;
      opts.matchAtomType = true;
      opts.matchFormalCharge = false;
      opts.useChirality = true;
      opts.useBondStereo = true;
      opts.ringMatchesRingOnly = false;
      opts.completeRingsOnly = true;
      opts.matchIsotope = true;
      opts.tautomerAware = true;
      opts.ringFusionMode = ChemOptions.RingFusionMode.STRICT;
      opts.matcherEngine = ChemOptions.MatcherEngine.VF3;
      opts.useTwoHopNLF = false;
      opts.useThreeHopNLF = true;
      opts.useBitParallelFeasibility = false;
      // Just verify it runs without crashing
      SMSD smsd = new SMSD(mol("c1ccccc1"), mol("c1ccccc1"), opts);
      smsd.findMCS(false, true, 5000L);
    }

    @Test @DisplayName("Fluent API chaining returns same instance")
    void fluentApi() {
      ChemOptions opts = new ChemOptions()
          .withBondOrderMode(ChemOptions.BondOrderMode.LOOSE)
          .withAromaticityMode(ChemOptions.AromaticityMode.FLEXIBLE)
          .withTwoHopNLF(false)
          .withThreeHopNLF(true)
          .withBitParallelFeasibility(false)
          .withCompleteRingsOnly(true)
          .withMatchIsotope(true)
          .withRingFusionMode(ChemOptions.RingFusionMode.PERMISSIVE)
          .withTautomerAware(true);
      assertEquals(ChemOptions.BondOrderMode.LOOSE, opts.matchBondOrder);
      assertTrue(opts.tautomerAware);
      assertTrue(opts.completeRingsOnly);
    }

    @Test @DisplayName("VF2 engine produces same result as VF2PP")
    void vf2VsVf2pp() throws Exception {
      ChemOptions vf2 = new ChemOptions();
      vf2.matcherEngine = ChemOptions.MatcherEngine.VF2;
      ChemOptions vf2pp = new ChemOptions();
      vf2pp.matcherEngine = ChemOptions.MatcherEngine.VF2PP;
      boolean r1 = new SMSD(mol("c1ccccc1"), mol("c1ccc(O)cc1"), vf2).isSubstructure();
      boolean r2 = new SMSD(mol("c1ccccc1"), mol("c1ccc(O)cc1"), vf2pp).isSubstructure();
      assertEquals(r1, r2, "VF2 and VF2PP should agree");
    }

    @Test @DisplayName("VF3 engine produces same result as VF2PP")
    void vf3VsVf2pp() throws Exception {
      ChemOptions vf3 = new ChemOptions();
      vf3.matcherEngine = ChemOptions.MatcherEngine.VF3;
      ChemOptions vf2pp = new ChemOptions();
      vf2pp.matcherEngine = ChemOptions.MatcherEngine.VF2PP;
      boolean r1 = new SMSD(mol("c1ccccc1"), mol("c1ccc(O)cc1"), vf3).isSubstructure();
      boolean r2 = new SMSD(mol("c1ccccc1"), mol("c1ccc(O)cc1"), vf2pp).isSubstructure();
      assertEquals(r1, r2, "VF3 and VF2PP should agree");
    }

    @Test @DisplayName("Null bond order mode defaults to STRICT")
    void nullBondOrderDefaults() {
      ChemOptions opts = new ChemOptions().withBondOrderMode(null);
      assertEquals(ChemOptions.BondOrderMode.STRICT, opts.matchBondOrder);
    }
  }

  // ======================================================================
  // 9. ALGORITHM STRESS
  // ======================================================================

  @Nested
  @DisplayName("9. AlgorithmStress")
  class AlgorithmStress {

    @Test @DisplayName("Greedy probe: benzene/toluene fast path")
    void greedyBenzeneToluene() throws Exception {
      int sz = mcsSize("c1ccccc1", "Cc1ccccc1");
      assertEquals(6, sz);
    }

    @Test @DisplayName("Seed-extend: morphine/codeine")
    void seedExtendMorphineCodeine() throws Exception {
      String morphine = "CN1CCC23C4C1CC5=C2C(=C(C=C5)O)OC3C(C=C4)O";
      String codeine = "CN1CCC23C4C1CC5=C2C(=C(C=C5)OC)OC3C(C=C4)O";
      int sz = mcsSize(morphine, codeine);
      assertTrue(sz >= 18, "Morphine/codeine MCS >= 18");
    }

    @Test @DisplayName("McSplit: medium molecules (caffeine/theophylline)")
    void mcsplitMedium() throws Exception {
      String caffeine = "Cn1c(=O)c2c(ncn2C)n(C)c1=O";
      String theophylline = "Cn1c(=O)c2[nH]cnc2n(C)c1=O";
      int sz = mcsSize(caffeine, theophylline);
      assertTrue(sz >= 10, "Caffeine/theophylline MCS >= 10");
    }

    @Test @DisplayName("BK clique: symmetric adamantane")
    void bkAdamantane() throws Exception {
      String adamantane = "C1C2CC3CC1CC(C2)C3";
      assertEquals(10, mcsSize(adamantane, adamantane));
    }

    @Test @DisplayName("McGregor: large molecule pair (atorvastatin/rosuvastatin)")
    void mcgregorLarge() throws Exception {
      String atorvastatin = "CC(C)c1c(C(=O)Nc2ccccc2)c(-c2ccccc2)c(-c2ccc(F)cc2)n1CC[C@H](O)C[C@H](O)CC(=O)O";
      String rosuvastatin = "CC(C)c1nc(N(C)S(C)(=O)=O)nc(-c2ccc(F)cc2)c1/C=C/[C@H](O)C[C@H](O)CC(=O)O";
      int sz = mcsSize(atorvastatin, rosuvastatin, new ChemOptions(), 30_000L);
      assertTrue(sz >= 10, "Large molecule MCS should be non-trivial");
    }

    @Test @DisplayName("Coverage-driven: identical molecules exit early")
    void coverageDrivenIdentical() throws Exception {
      String mol = "c1ccc2ccccc2c1"; // naphthalene
      long start = System.currentTimeMillis();
      int sz = mcsSize(mol, mol);
      long elapsed = System.currentTimeMillis() - start;
      assertEquals(10, sz);
      assertTrue(elapsed < 2000, "Identical molecules should be fast, took " + elapsed + "ms");
    }

    @Test @DisplayName("Timeout 1ms on paclitaxel pair: no crash, returns partial")
    @Timeout(30)
    void timeoutPaclitaxel() throws Exception {
      String paclitaxel = "CC1=C2C(C(=O)C3(C(CC4C(C3C(C(C2(C)C)(CC1OC(=O)C(C(C5=CC=CC=C5)NC(=O)C6=CC=CC=C6)O)O)OC(=O)C7=CC=CC=C7)(CO4)OC(=O)C)O)C)OC(=O)C";
      String docetaxel = "CC1=C2C(C(=O)C3(C(CC4C(C3C(C(C2(C)C)(CC1O)O)OC(=O)C5=CC=CC=C5)(CO4)OC(=O)C)O)C)OC(=O)C";
      SMSD smsd = new SMSD(mol(paclitaxel), mol(docetaxel), new ChemOptions());
      smsd.setMcsTimeoutMs(1L);
      // Should not crash; result may be empty or partial
      assertDoesNotThrow(() -> smsd.findMCS(false, true, 1L));
    }

    @Test @DisplayName("Timeout 100ms on drug pair: returns valid result")
    @Timeout(10)
    void timeout100msDrugPair() throws Exception {
      String aspirin = "CC(=O)Oc1ccccc1C(=O)O";
      String salicylicAcid = "OC(=O)c1ccccc1O";
      SMSD smsd = new SMSD(mol(aspirin), mol(salicylicAcid), new ChemOptions());
      smsd.setMcsTimeoutMs(100L);
      Map<Integer, Integer> m = smsd.findMCS(false, true, 100L);
      // Should return a valid (possibly partial) result
      assertNotNull(m);
    }

    @Test @DisplayName("Multiple mappings: enumerate up to 10 for benzene self-match")
    void multipleMappings() throws Exception {
      SMSD smsd = new SMSD(mol("c1ccccc1"), mol("c1ccccc1"), new ChemOptions());
      List<Map<Integer, Integer>> maps = smsd.findAllSubstructures(10, 5000L);
      assertTrue(maps.size() >= 1, "Benzene self-match should have at least 1 mapping");
    }

    @Test @DisplayName("Substructure false: query larger than target")
    void queryLargerThanTarget() throws Exception {
      assertFalse(new SMSD(mol("c1ccc2ccccc2c1"), mol("c1ccccc1"), new ChemOptions()).isSubstructure());
    }

    @Test @DisplayName("Substructure true: benzene in phenol")
    void benzeneInPhenol() throws Exception {
      assertTrue(new SMSD(mol("c1ccccc1"), mol("c1ccc(O)cc1"), new ChemOptions()).isSubstructure());
    }

    @Test @DisplayName("MCS empty: methane vs water")
    void mcsEmpty() throws Exception {
      Map<Integer, Integer> m = mcs("C", "O", new ChemOptions(), 5000L);
      assertTrue(m.isEmpty(), "No common substructure between methane and water");
    }

    @Test @DisplayName("MCS identity: same molecule returns full mapping")
    void mcsIdentity() throws Exception {
      String mol = "CC(=O)Oc1ccccc1C(=O)O"; // aspirin
      int sz = mcsSize(mol, mol);
      assertEquals(mol(mol).getAtomCount(), sz, "Self-MCS should return all atoms");
    }

    @Test @DisplayName("RASCAL screening: upper bound >= actual MCS")
    void rascalUpperBound() throws Exception {
      IAtomContainer q = mol("c1ccccc1");
      IAtomContainer t = mol("c1ccc(O)cc1");
      SMSD smsd = new SMSD(q, t, new ChemOptions());
      double ub = smsd.similarityUpperBound();
      Map<Integer, Integer> m = smsd.findMCS();
      double actual = (double) m.size() / Math.max(q.getAtomCount(), t.getAtomCount());
      assertTrue(ub >= actual - 0.01, "Upper bound should be >= actual similarity");
    }

    @Test @DisplayName("Fingerprint subset: substructure pairs")
    void fingerprintSubset() throws Exception {
      IAtomContainer q = mol("c1ccccc1");
      IAtomContainer t = mol("c1ccc(O)cc1");
      long[] qFp = SMSD.pathFingerprint(q, 7, 1024);
      long[] tFp = SMSD.pathFingerprint(t, 7, 1024);
      assertTrue(SMSD.fingerprintSubset(qFp, tFp), "Benzene FP should be subset of phenol FP");
    }

    @Test @DisplayName("Fingerprint non-subset: non-substructure pairs")
    void fingerprintNonSubset() throws Exception {
      IAtomContainer q = mol("c1ccc(O)cc1"); // phenol
      IAtomContainer t = mol("CCCC"); // butane
      long[] qFp = SMSD.pathFingerprint(q, 7, 1024);
      long[] tFp = SMSD.pathFingerprint(t, 7, 1024);
      assertFalse(SMSD.fingerprintSubset(qFp, tFp), "Phenol FP should NOT be subset of butane FP");
    }

    @Test @DisplayName("validateMapping: every mapping is chemically valid")
    void validateMapping() throws Exception {
      String benzene = "c1ccccc1";
      String phenol = "c1ccc(O)cc1";
      ChemOptions opts = new ChemOptions();
      Map<Integer, Integer> m = mcs(benzene, phenol, opts, 10_000L);
      MolGraph g1 = new MolGraph(mol(benzene));
      MolGraph g2 = new MolGraph(mol(phenol));
      List<String> errors = SearchEngine.validateMapping(g1, g2, m, opts);
      assertTrue(errors.isEmpty(), "Mapping should be valid, errors: " + errors);
    }

    @Test @DisplayName("isMappingMaximal: MCS mapping should be maximal")
    void mappingMaximal() throws Exception {
      String benzene = "c1ccccc1";
      String toluene = "Cc1ccccc1";
      ChemOptions opts = new ChemOptions();
      Map<Integer, Integer> m = mcs(benzene, toluene, opts, 10_000L);
      MolGraph g1 = new MolGraph(mol(benzene));
      MolGraph g2 = new MolGraph(mol(toluene));
      assertTrue(SearchEngine.isMappingMaximal(g1, g2, m, opts), "MCS should be maximal");
    }
  }

  // ======================================================================
  // 10. SCALE STRESS
  // ======================================================================

  @Nested
  @DisplayName("10. ScaleStress")
  class ScaleStress {

    private String linearAlkane(int n) {
      return "C".repeat(n);
    }

    @Test @DisplayName("50-atom self-match < 1s")
    @Timeout(5)
    void selfMatch50() throws Exception {
      String smi = linearAlkane(50);
      long start = System.currentTimeMillis();
      int sz = mcsSize(smi, smi);
      long elapsed = System.currentTimeMillis() - start;
      assertEquals(50, sz);
      assertTrue(elapsed < 1000, "50-atom self-match took " + elapsed + "ms");
    }

    @Test @DisplayName("100-atom self-match < 2s")
    @Timeout(10)
    void selfMatch100() throws Exception {
      String smi = linearAlkane(100);
      long start = System.currentTimeMillis();
      int sz = mcsSize(smi, smi);
      long elapsed = System.currentTimeMillis() - start;
      assertEquals(100, sz);
      assertTrue(elapsed < 2000, "100-atom self-match took " + elapsed + "ms");
    }

    @Test @DisplayName("200-atom self-match < 5s")
    @Timeout(15)
    void selfMatch200() throws Exception {
      String smi = linearAlkane(200);
      long start = System.currentTimeMillis();
      int sz = mcsSize(smi, smi);
      long elapsed = System.currentTimeMillis() - start;
      assertEquals(200, sz);
      assertTrue(elapsed < 5000, "200-atom self-match took " + elapsed + "ms");
    }

    @Test @DisplayName("400-atom substructure < 5s")
    @Timeout(15)
    void substructure400() throws Exception {
      IAtomContainer q = mol(linearAlkane(100));
      IAtomContainer t = mol(linearAlkane(400));
      long start = System.currentTimeMillis();
      boolean result = new SMSD(q, t, new ChemOptions()).isSubstructure();
      long elapsed = System.currentTimeMillis() - start;
      assertTrue(result);
      assertTrue(elapsed < 5000, "400-atom substructure took " + elapsed + "ms");
    }

    @Test @DisplayName("1000 sequential substructure checks < 10s")
    @Timeout(20)
    void sequentialSubstructure1000() throws Exception {
      IAtomContainer q = mol("c1ccccc1");
      IAtomContainer t = mol("c1ccc(O)cc1");
      ChemOptions opts = new ChemOptions();
      long start = System.currentTimeMillis();
      for (int i = 0; i < 1000; i++) {
        new SMSD(q, t, opts, false).isSubstructure();
      }
      long elapsed = System.currentTimeMillis() - start;
      assertTrue(elapsed < 10000, "1000 substructure checks took " + elapsed + "ms");
    }

    @Test @DisplayName("100 sequential MCS computations < 30s")
    @Timeout(60)
    void sequentialMCS100() throws Exception {
      IAtomContainer q = mol("c1ccccc1");
      IAtomContainer t = mol("c1ccc(O)cc1");
      ChemOptions opts = new ChemOptions();
      long start = System.currentTimeMillis();
      for (int i = 0; i < 100; i++) {
        new SMSD(q, t, opts, false).findMCS(false, true, 5000L);
      }
      long elapsed = System.currentTimeMillis() - start;
      assertTrue(elapsed < 30000, "100 MCS computations took " + elapsed + "ms");
    }

    @Test @DisplayName("Batch MCS with threshold: 10 molecules < 5s")
    @Timeout(15)
    void batchMcs10() throws Exception {
      String[] smiles = {
          "c1ccccc1", "c1ccc(O)cc1", "c1ccc(N)cc1", "c1ccc(F)cc1", "c1ccc(Cl)cc1",
          "c1ccc(Br)cc1", "c1ccc(I)cc1", "c1ccc(C)cc1", "c1ccc(S)cc1", "c1ccc(P)cc1"
      };
      List<IAtomContainer> mols = new ArrayList<>();
      for (String s : smiles) mols.add(mol(s));
      long start = System.currentTimeMillis();
      Map<Integer, Integer> nm = SMSD.findNMCS(mols, new ChemOptions(), 0.8, 5000L);
      long elapsed = System.currentTimeMillis() - start;
      assertNotNull(nm);
      assertTrue(elapsed < 5000, "Batch MCS took " + elapsed + "ms");
    }

    @Test @DisplayName("R-group decomposition: benzene core on 5 derivatives < 2s")
    @Timeout(10)
    void rgroupDecomp() throws Exception {
      IAtomContainer core = mol("c1ccccc1");
      List<IAtomContainer> derivatives = Arrays.asList(
          mol("c1ccc(O)cc1"), mol("c1ccc(N)cc1"), mol("c1ccc(F)cc1"),
          mol("c1ccc(Cl)cc1"), mol("c1ccc(C)cc1"));
      long start = System.currentTimeMillis();
      List<Map<String, IAtomContainer>> decomp = SMSD.decomposeRGroups(core, derivatives, new ChemOptions(), 5000L);
      long elapsed = System.currentTimeMillis() - start;
      assertNotNull(decomp);
      assertFalse(decomp.isEmpty());
      assertTrue(elapsed < 2000, "R-group decomposition took " + elapsed + "ms");
    }

    @Test @DisplayName("N-MCS: 5 molecules < 10s")
    @Timeout(20)
    void nmcs5() throws Exception {
      List<IAtomContainer> mols = Arrays.asList(
          mol("c1ccc(O)cc1"), mol("c1ccc(N)cc1"), mol("c1ccc(Cl)cc1"),
          mol("c1ccc(F)cc1"), mol("c1ccc(C)cc1"));
      long start = System.currentTimeMillis();
      Map<Integer, Integer> nm = SMSD.findNMCS(mols, new ChemOptions(), 1.0, 10_000L);
      long elapsed = System.currentTimeMillis() - start;
      assertTrue(nm.size() >= 6, "All 5 share benzene ring");
      assertTrue(elapsed < 10000, "N-MCS 5 molecules took " + elapsed + "ms");
    }

    @Test @DisplayName("Fingerprint: 100 molecules < 1s")
    @Timeout(5)
    void fingerprint100() throws Exception {
      String[] smiles = new String[100];
      for (int i = 0; i < 100; i++) {
        smiles[i] = linearAlkane(5 + (i % 20));
      }
      long start = System.currentTimeMillis();
      for (String s : smiles) {
        SMSD.pathFingerprint(mol(s), 7, 1024);
      }
      long elapsed = System.currentTimeMillis() - start;
      assertTrue(elapsed < 1000, "100 fingerprints took " + elapsed + "ms");
    }
  }

  // ======================================================================
  // 11. REAL WORLD DRUG PAIRS
  // ======================================================================

  @Nested
  @DisplayName("11. RealWorldDrugPairs")
  class RealWorldDrugPairs {

    private void assertDrugPairMCS(String name1, String smi1, String name2, String smi2,
                                    int minMCS) throws Exception {
      ChemOptions opts = new ChemOptions();
      Map<Integer, Integer> m = mcs(smi1, smi2, opts, 30_000L);
      assertTrue(m.size() >= minMCS,
          name1 + "/" + name2 + " MCS expected >= " + minMCS + " but got " + m.size());
      // Validate mapping
      MolGraph g1 = new MolGraph(mol(smi1));
      MolGraph g2 = new MolGraph(mol(smi2));
      List<String> errors = SearchEngine.validateMapping(g1, g2, m, opts);
      assertTrue(errors.isEmpty(),
          name1 + "/" + name2 + " mapping invalid: " + errors);
    }

    @Test @DisplayName("Aspirin / Acetaminophen >= 7")
    @Timeout(30)
    void aspirinAcetaminophen() throws Exception {
      assertDrugPairMCS("Aspirin", "CC(=O)Oc1ccccc1C(=O)O",
          "Acetaminophen", "CC(=O)Nc1ccc(O)cc1", 7);
    }

    @Test @DisplayName("Ibuprofen / Naproxen >= 12")
    @Timeout(30)
    void ibuprofenNaproxen() throws Exception {
      assertDrugPairMCS("Ibuprofen", "CC(C)Cc1ccc(C(C)C(=O)O)cc1",
          "Naproxen", "COc1ccc2cc(C(C)C(=O)O)ccc2c1", 12);
    }

    @Test @DisplayName("Morphine / Codeine >= 20")
    @Timeout(30)
    void morphineCodeine() throws Exception {
      assertDrugPairMCS("Morphine", "CN1CCC23C4C1CC5=C2C(=C(C=C5)O)OC3C(C=C4)O",
          "Codeine", "CN1CCC23C4C1CC5=C2C(=C(C=C5)OC)OC3C(C=C4)O", 20);
    }

    @Test @DisplayName("Caffeine / Theophylline >= 13")
    @Timeout(30)
    void caffeineTheophylline() throws Exception {
      assertDrugPairMCS("Caffeine", "Cn1c(=O)c2c(ncn2C)n(C)c1=O",
          "Theophylline", "Cn1c(=O)c2[nH]cnc2n(C)c1=O", 13);
    }

    @Test @DisplayName("Atorvastatin / Rosuvastatin >= 15")
    @Timeout(30)
    void atorvastatinRosuvastatin() throws Exception {
      assertDrugPairMCS("Atorvastatin",
          "CC(C)c1c(C(=O)Nc2ccccc2)c(-c2ccccc2)c(-c2ccc(F)cc2)n1CC[C@H](O)C[C@H](O)CC(=O)O",
          "Rosuvastatin",
          "CC(C)c1nc(N(C)S(C)(=O)=O)nc(-c2ccc(F)cc2)c1/C=C/[C@H](O)C[C@H](O)CC(=O)O", 15);
    }

    @Test @DisplayName("Diazepam / Oxazepam >= 15")
    @Timeout(30)
    void diazepamOxazepam() throws Exception {
      assertDrugPairMCS("Diazepam", "CN1C(=O)CN=C(c2ccccc2)c2cc(Cl)ccc21",
          "Oxazepam", "OC1N=C(c2ccccc2)c2cc(Cl)ccc2NC1=O", 15);
    }

    @Test @DisplayName("Metformin / Phenformin >= 8")
    @Timeout(30)
    void metforminPhenformin() throws Exception {
      assertDrugPairMCS("Metformin", "CN(C)C(=N)NC(=N)N",
          "Phenformin", "NC(=N)NC(=N)NCCc1ccccc1", 8);
    }

    @Test @DisplayName("Omeprazole / Lansoprazole >= 12")
    @Timeout(30)
    void omeprazoleLansoprazole() throws Exception {
      assertDrugPairMCS("Omeprazole", "COc1ccc2[nH]c(S(=O)Cc3ncc(C)c(OC)c3C)nc2c1",
          "Lansoprazole", "Cc1c(OCC(F)(F)F)ccn1S(=O)c1nc2ccc(OC)cc2[nH]1", 12);
    }

    @Test @DisplayName("Sildenafil / Tadalafil >= 10")
    @Timeout(30)
    void sildenafilTadalafil() throws Exception {
      assertDrugPairMCS("Sildenafil",
          "CCCc1nn(C)c2c1nc(nc2OCC)c1cc(ccc1OCC)S(=O)(=O)N1CCN(C)CC1",
          "Tadalafil",
          "O=C1NC(=O)c2cc3c(cc2[C@@H]1Cc1c[nH]c2ccccc12)OCO3", 10);
    }

    @Test @DisplayName("Tamoxifen / Raloxifene >= 10")
    @Timeout(30)
    void tamoxifenRaloxifene() throws Exception {
      assertDrugPairMCS("Tamoxifen", "CCC(=C(c1ccccc1)c1ccc(OCCN(C)C)cc1)c1ccccc1",
          "Raloxifene", "Oc1ccc(cc1)C(=O)c1ccc(O)cc1", 5);
    }

    @Test @DisplayName("Ciprofloxacin / Levofloxacin >= 15")
    @Timeout(30)
    void ciprofloxacinLevofloxacin() throws Exception {
      assertDrugPairMCS("Ciprofloxacin",
          "O=C(O)c1cn(C2CC2)c2cc(N3CCNCC3)c(F)cc2c1=O",
          "Levofloxacin",
          "C[C@@H]1COc2c(N3CCN(C)CC3)c(F)cc3c(=O)c(C(=O)O)cn1c23", 15);
    }

    @Test @DisplayName("Warfarin / Acenocoumarol >= 15")
    @Timeout(30)
    void warfarinAcenocoumarol() throws Exception {
      assertDrugPairMCS("Warfarin", "CC(=O)CC(c1ccccc1)c1c(O)c2ccccc2oc1=O",
          "Acenocoumarol", "CC(=O)CC(c1ccc([N+](=O)[O-])cc1)c1c(O)c2ccccc2oc1=O", 15);
    }

    @Test @DisplayName("Metoprolol / Atenolol >= 10")
    @Timeout(30)
    void metoprololAtenolol() throws Exception {
      assertDrugPairMCS("Metoprolol", "COCCc1ccc(OCC(O)CNC(C)C)cc1",
          "Atenolol", "CC(C)NCC(O)COc1ccc(CC(N)=O)cc1", 10);
    }

    @Test @DisplayName("Amoxicillin / Ampicillin >= 15")
    @Timeout(30)
    void amoxicillinAmpicillin() throws Exception {
      assertDrugPairMCS("Amoxicillin",
          "CC1(C)SC2C(NC(=O)C(N)c3ccc(O)cc3)C(=O)N2C1C(=O)O",
          "Ampicillin",
          "CC1(C)SC2C(NC(=O)C(N)c3ccccc3)C(=O)N2C1C(=O)O", 15);
    }

    @Test @DisplayName("Fluoxetine / Paroxetine >= 10")
    @Timeout(30)
    void fluoxetineParoxetine() throws Exception {
      assertDrugPairMCS("Fluoxetine", "CNCCC(Oc1ccc(C(F)(F)F)cc1)c1ccccc1",
          "Paroxetine", "Fc1ccc(C2CCNCC2COc2ccc3c(c2)OCO3)cc1", 10);
    }

    @Test @DisplayName("Loratadine / Desloratadine >= 18")
    @Timeout(30)
    void loratadineDesloratadine() throws Exception {
      assertDrugPairMCS("Loratadine",
          "CCOC(=O)N1CCC(=C2c3ccc(Cl)cc3CCc3cccnc32)CC1",
          "Desloratadine",
          "Clc1ccc2c(c1)CCc1cccnc1C2=C1CCNCC1", 18);
    }

    @Test @DisplayName("Prednisolone / Dexamethasone >= 18")
    @Timeout(30)
    void prednisoloneDexamethasone() throws Exception {
      assertDrugPairMCS("Prednisolone",
          "O=C1C=C2CC3C(CC(O)C4(C(CO)=O)C3CCC4O)C2(C)CC1=O",
          "Dexamethasone",
          "CC1CC2C3CCC4=CC(=O)C=CC4(C)C3(F)C(O)CC2(C)C1(O)C(=O)CO", 18);
    }

    @Test @DisplayName("Simvastatin / Lovastatin >= 20")
    @Timeout(30)
    void simvastatinLovastatin() throws Exception {
      assertDrugPairMCS("Simvastatin",
          "CCC(C)(C)C(=O)OC1CC(O)C=C2C=CC(C)C(CCC3CC(O)CC(=O)O3)C21",
          "Lovastatin",
          "CCC(C)C(=O)OC1CC(O)C=C2C=CC(C)C(CCC3CC(O)CC(=O)O3)C21", 20);
    }

    @Test @DisplayName("Celecoxib / Valdecoxib >= 12")
    @Timeout(30)
    void celecoxibValdecoxib() throws Exception {
      assertDrugPairMCS("Celecoxib",
          "Cc1ccc(-c2cc(C(F)(F)F)nn2-c2ccc(S(N)(=O)=O)cc2)cc1",
          "Valdecoxib",
          "Cc1ccc(-c2noc(C)c2)cc1", 8);
    }

    @Test @DisplayName("Donepezil / Rivastigmine >= 8")
    @Timeout(30)
    void donepezilRivastigmine() throws Exception {
      assertDrugPairMCS("Donepezil",
          "COc1cc2CC(CC3CCN(Cc4ccccc4)CC3)C(=O)c2cc1OC",
          "Rivastigmine",
          "CCN(C)C(=O)Oc1cccc(C(C)N(C)C)c1", 8);
    }
  }
}
