/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2018-2026 BioInception PVT LTD
 * Algorithm Copyright (c) 2009-2026 Syed Asad Rahman
 */
package com.bioinception.smsd;

import static org.junit.jupiter.api.Assertions.*;

import com.bioinception.smsd.core.*;
import java.util.*;
import org.junit.jupiter.api.*;
import org.openscience.cdk.interfaces.IAtomContainer;
import org.openscience.cdk.interfaces.IBond;
import org.openscience.cdk.ringsearch.RingSearch;
import org.openscience.cdk.silent.Atom;
import org.openscience.cdk.silent.SilentChemObjectBuilder;

/**
 * Comprehensive tests covering all molecule types, reaction patterns, functional groups,
 * ChemOptions configurations, edge cases, and API methods.
 *
 * @author Syed Asad Rahman
 */
public class SMSDComprehensiveTest extends TestBase {

  // ======================================================================
  // 1. HETEROCYCLES (O, S, mixed)
  // ======================================================================

  @Nested
  @DisplayName("Heterocycle Substructure Tests")
  class HeterocycleTests {
    @Test
    void furanInBenzofuran() throws Exception {
      assertTrue(
          new SMSD(mol("c1ccoc1"), mol("c1ccc2occc2c1"), new ChemOptions()).isSubstructure());
    }

    @Test
    void thiopheneInBenzothiophene() throws Exception {
      assertTrue(
          new SMSD(mol("c1ccsc1"), mol("c1ccc2sccc2c1"), new ChemOptions()).isSubstructure());
    }

    @Test
    void imidazoleInHistidine() throws Exception {
      // Imidazole ring in histidine side chain
      assertTrue(
          new SMSD(mol("c1cnc[nH]1"), mol("NC(Cc1cnc[nH]1)C(=O)O"), new ChemOptions())
              .isSubstructure());
    }

    @Test
    void pyrimidineRingInCytosine() throws Exception {
      // Cytosine contains a pyrimidine ring — use the 1,3-diazine core
      SMSD smsd = new SMSD(mol("C=1C=NC=NC1"), mol("Nc1ccnc(=O)[nH]1"), new ChemOptions());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertTrue(mcs.size() >= 4, "Should share pyrimidine atoms");
    }

    @Test
    void morpholineInDrug() throws Exception {
      assertTrue(
          new SMSD(mol("C1COCCN1"), mol("O=C(N1CCOCC1)c1ccccc1"), new ChemOptions())
              .isSubstructure());
    }
  }

  // ======================================================================
  // 2. BRIDGED, SPIRO, COMPLEX RING SYSTEMS
  // ======================================================================

  @Nested
  @DisplayName("Complex Ring Systems")
  class ComplexRingTests {
    @Test
    void norbornaneSubstructure() throws Exception {
      // Bicyclo[2.2.1]heptane — bridged ring
      SMSD smsd = new SMSD(mol("C1CC2CC1C2"), mol("C1CC2CC1CC2C"), new ChemOptions());
      // Both are bridged, should find common subgraph
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 4, "Bridged ring MCS should find common atoms");
    }

    @Test
    void spiroCompoundMCS() throws Exception {
      // Spiro[4.4]nonane
      SMSD smsd = new SMSD(mol("C1CCC2(C1)CCCC2"), mol("C1CCC2(C1)CCCCC2"), new ChemOptions());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertTrue(mcs.size() >= 5, "Spiro MCS should share at least one ring");
    }
    // Removed: adamantaneSelfMatch — duplicated by AdversarialTest.adamantaneSelfMatch.
  }

  // ======================================================================
  // 3. FUNCTIONAL GROUPS — systematic substructure
  // ======================================================================

  @Nested
  @DisplayName("Functional Group Substructure")
  class FunctionalGroupTests {
    @Test
    void primaryAmineInAlanine() throws Exception {
      assertTrue(new SMSD(mol("CN"), mol("CC(N)C(=O)O"), new ChemOptions()).isSubstructure());
    }

    @Test
    void aldehydeInBenzaldehyde() throws Exception {
      assertTrue(new SMSD(mol("C=O"), mol("O=Cc1ccccc1"), new ChemOptions()).isSubstructure());
    }

    @Test
    void nitrileInAcetonitrile() throws Exception {
      assertTrue(new SMSD(mol("C#N"), mol("CC#N"), new ChemOptions()).isSubstructure());
    }

    @Test
    void nitroInNitrobenzene() throws Exception {
      assertTrue(
          new SMSD(mol("[N+](=O)[O-]"), mol("c1ccc([N+](=O)[O-])cc1"), new ChemOptions())
              .isSubstructure());
    }

    @Test
    void sulfonylInDMSO() throws Exception {
      assertTrue(new SMSD(mol("S=O"), mol("CS(=O)C"), new ChemOptions()).isSubstructure());
    }

    @Test
    void thioetherInMethionine() throws Exception {
      assertTrue(new SMSD(mol("CSC"), mol("CSCCC(N)C(=O)O"), new ChemOptions()).isSubstructure());
    }

    @Test
    void phenolNotInCyclohexanol() throws Exception {
      // Aromatic OH should not match aliphatic OH with strict aromaticity
      SMSD smsd = new SMSD(mol("Oc1ccccc1"), mol("OC1CCCCC1"), ChemOptions.profile("strict"));
      assertFalse(smsd.isSubstructure());
    }

    @Test
    void epoxideSubstructure() throws Exception {
      assertTrue(new SMSD(mol("C1OC1"), mol("C1OC1CC"), new ChemOptions()).isSubstructure());
    }
  }

  // ======================================================================
  // 4. REACTION / TRANSFORMATION MAPPING
  // ======================================================================

  @Nested
  @DisplayName("Reaction Transformation MCS")
  class ReactionTests {
    @Test
    void alcoholToAldehyde() throws Exception {
      // Oxidation: ethanol → acetaldehyde — share C-C backbone
      SMSD smsd = new SMSD(mol("CCO"), mol("CC=O"), new ChemOptions());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertTrue(mcs.size() >= 2, "Oxidation preserves C-C backbone");
    }

    @Test
    void acidToAmide() throws Exception {
      // Amide bond formation: acetic acid → acetamide
      SMSD smsd = new SMSD(mol("CC(=O)O"), mol("CC(=O)N"), new ChemOptions());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertTrue(mcs.size() >= 3, "Acid→amide preserves acyl group");
    }

    @Test
    void halogenationMCS() throws Exception {
      // Chlorination: benzene → chlorobenzene
      SMSD smsd = new SMSD(mol("c1ccccc1"), mol("Clc1ccccc1"), new ChemOptions());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertEquals(6, mcs.size(), "Benzene ring preserved in chlorination");
    }

    @Test
    void demethylation() throws Exception {
      // Codeine → morphine (loss of methyl from ether)
      SMSD smsd =
          new SMSD(
              mol("CN1CCC23C4C1CC5=C(C2C(C=C4)OC3)C=C(C=C5)O"),
              mol("CN1CCC23C4C1CC5=C(C2C(C=C4)O3)C=C(C=C5)O"),
              new ChemOptions());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 30000L);
      assertTrue(mcs.size() >= 19, "Demethylation preserves core scaffold");
    }

    @Test
    void ketoEnolTautomer() throws Exception {
      // Keto-enol: acetone ↔ propen-2-ol
      SMSD smsd = new SMSD(mol("CC(=O)C"), mol("CC(O)=C"), new ChemOptions());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertTrue(mcs.size() >= 3, "Tautomers share backbone");
    }

    @Test
    void ringOpeningMCS() throws Exception {
      // Ring opening: cyclopropane vs propane — need ring constraint OFF
      ChemOptions opts = new ChemOptions();
      opts.ringMatchesRingOnly = false;
      SMSD smsd = new SMSD(mol("C1CC1"), mol("CCC"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertTrue(mcs.size() >= 2, "Ring opening preserves C-C bonds when ring constraint off");
    }

    @Test
    void esterHydrolysis() throws Exception {
      // Ethyl acetate → acetic acid + ethanol (shared acyl)
      SMSD smsd = new SMSD(mol("CC(=O)OCC"), mol("CC(=O)O"), new ChemOptions());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertTrue(mcs.size() >= 3, "Ester hydrolysis preserves acyl group");
    }
  }

  // ======================================================================
  // 5. CHARGED SPECIES
  // ======================================================================

  @Nested
  @DisplayName("Charged Species")
  class ChargedTests {
    @Test
    void ammoniumNotMatchesAmine() throws Exception {
      // [NH4+] should NOT match NH3 with charge matching ON
      ChemOptions opts = new ChemOptions();
      opts.matchFormalCharge = true;
      assertFalse(new SMSD(mol("[NH4+]"), mol("N"), opts).isSubstructure());
    }

    @Test
    void ammoniumMatchesAmineChargeOff() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchFormalCharge = false;
      assertTrue(new SMSD(mol("[NH4+]"), mol("N"), opts).isSubstructure());
    }

    @Test
    void zwitterionSubstructure() throws Exception {
      // Glycine zwitterion
      ChemOptions opts = new ChemOptions();
      opts.matchFormalCharge = true;
      assertTrue(new SMSD(mol("[NH3+]CC([O-])=O"), mol("[NH3+]CC([O-])=O"), opts).isSubstructure());
    }
  }

  // ======================================================================
  // 6. CHEMOPTIONS CONFIGURATIONS
  // ======================================================================

  @Nested
  @DisplayName("ChemOptions Configuration Tests")
  class ChemOptionsTests {
    @Test
    void vf2MatcherEngine() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matcherEngine = ChemOptions.MatcherEngine.VF2;
      assertTrue(new SMSD(mol("c1ccccc1"), mol("c1ccc(O)cc1"), opts).isSubstructure());
    }

    @Test
    void vf2ppMatcherEngine() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matcherEngine = ChemOptions.MatcherEngine.VF2PP;
      assertTrue(new SMSD(mol("c1ccccc1"), mol("c1ccc(O)cc1"), opts).isSubstructure());
    }

    @Test
    void vf3MatcherEngine() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matcherEngine = ChemOptions.MatcherEngine.VF3;
      assertTrue(new SMSD(mol("c1ccccc1"), mol("c1ccc(O)cc1"), opts).isSubstructure());
    }

    @Test
    void bondOrderAny() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.matchBondOrder = ChemOptions.BondOrderMode.ANY;
      // Single bond query should match double bond target
      assertTrue(new SMSD(mol("CC"), mol("C=C"), opts).isSubstructure());
    }

    @Test
    void pruningTogglesTwoHop() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.useTwoHopNLF = false;
      assertTrue(new SMSD(mol("c1ccccc1"), mol("c1ccc(O)cc1"), opts).isSubstructure());
    }

    @Test
    void pruningTogglesThreeHop() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.useThreeHopNLF = false;
      assertTrue(new SMSD(mol("c1ccccc1"), mol("c1ccc(O)cc1"), opts).isSubstructure());
    }

    @Test
    void pruningTogglesBitParallel() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.useBitParallelFeasibility = false;
      assertTrue(new SMSD(mol("c1ccccc1"), mol("c1ccc(O)cc1"), opts).isSubstructure());
    }

    @Test
    void ringMatchDisabled() throws Exception {
      ChemOptions opts = new ChemOptions();
      opts.ringMatchesRingOnly = false;
      // With ring constraint OFF, cyclopentane (5) should map into cyclohexane (6)
      // because ring atoms are allowed to match non-ring atoms
      SMSD smsd = new SMSD(mol("C1CCCC1"), mol("CCCCCC"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertTrue(mcs.size() >= 4, "Ring match disabled allows ring-to-chain mapping in MCS");
    }

    @Test
    void fluentApi() throws Exception {
      ChemOptions opts =
          new ChemOptions()
              .withBondOrderMode(ChemOptions.BondOrderMode.LOOSE)
              .withAromaticityMode(ChemOptions.AromaticityMode.FLEXIBLE)
              .withTwoHopNLF(true)
              .withThreeHopNLF(false)
              .withBitParallelFeasibility(true);
      assertTrue(new SMSD(mol("c1ccccc1"), mol("c1ccc(O)cc1"), opts).isSubstructure());
    }
  }

  // ======================================================================
  // 7. EDGE CASES
  // ======================================================================

  @Nested
  @DisplayName("Edge Cases")
  class EdgeCaseTests {
    @Test
    void singleAtomQuery() throws Exception {
      assertTrue(new SMSD(mol("C"), mol("CCCC"), new ChemOptions()).isSubstructure());
    }

    @Test
    void singleAtomNoMatch() throws Exception {
      // Nitrogen not in all-carbon chain
      assertFalse(new SMSD(mol("N"), mol("CCCC"), new ChemOptions()).isSubstructure());
    }

    @Test
    void selfMatchSubstructure() throws Exception {
      IAtomContainer m = mol("c1ccc(O)cc1");
      assertTrue(new SMSD(m, m, new ChemOptions()).isSubstructure());
    }

    @Test
    void selfMatchMCS() throws Exception {
      IAtomContainer m = mol("c1ccc(O)cc1");
      Map<Integer, Integer> mcs = new SMSD(m, m, new ChemOptions()).findMCS(true, true, 5000L);
      assertEquals(m.getAtomCount(), mcs.size(), "Self-MCS should match all atoms");
    }

    @Test
    void noCommonAtomsMCS() throws Exception {
      // Methane (C) vs water (O) — no shared atoms with strict typing
      SMSD smsd = new SMSD(mol("C"), mol("O"), new ChemOptions());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 2000L);
      assertTrue(mcs.isEmpty(), "No common atoms between methane and water");
    }

    @Test
    void disconnectedQuery() throws Exception {
      assertTrue(new SMSD(mol("C.N"), mol("CCN"), new ChemOptions()).isSubstructure());
    }

    @Test
    void disconnectedMCSInduced() throws Exception {
      SMSD smsd = new SMSD(mol("CC.OO"), mol("CCOCC"), new ChemOptions());
      Map<Integer, Integer> mcs = smsd.findMCS(true, false, 5000L);
      assertNotNull(mcs);
    }

    @Test
    void veryShortTimeout() throws Exception {
      SMSD smsd = new SMSD(mol("c1ccccc1"), mol("c1ccc2ccccc2c1"), new ChemOptions());
      // Should not hang; may or may not find result
      smsd.findMCS(true, true, 1L);
    }
  }

  // ======================================================================
  // 8. SMSD API METHODS
  // ======================================================================

  @Nested
  @DisplayName("SMSD API Coverage")
  class ApiTests {
    @Test
    void findAllSubstructuresCount() throws Exception {
      SMSD smsd = new SMSD(mol("C"), mol("CCCCCC"), new ChemOptions());
      List<Map<Integer, Integer>> maps = smsd.findAllSubstructures(100, 5000L);
      assertEquals(6, maps.size(), "Single C should match all 6 positions in hexane");
    }

    @Test
    void findAllSubstructuresMaxLimit() throws Exception {
      SMSD smsd = new SMSD(mol("C"), mol("CCCCCC"), new ChemOptions());
      List<Map<Integer, Integer>> maps = smsd.findAllSubstructures(3, 5000L);
      assertEquals(3, maps.size(), "Should respect maxSolutions limit");
    }

    @Test
    void isSubstructureWithStatsReturnsData() throws Exception {
      SMSD smsd = new SMSD(mol("c1ccccc1"), mol("c1ccc2ccccc2c1"), new ChemOptions());
      SearchEngine.SubstructureResult res = smsd.isSubstructureWithStats(5000L);
      assertTrue(res.exists);
      assertTrue(res.stats.nodesVisited > 0, "Should report nodes visited");
      assertTrue(res.stats.timeMillis >= 0, "Should report elapsed time");
    }

    @Test
    void findAllSubstructuresWithStatsReturnsData() throws Exception {
      SMSD smsd = new SMSD(mol("c1ccccc1"), mol("c1ccc(O)cc1"), new ChemOptions());
      SearchEngine.SubstructureResult res = smsd.findAllSubstructuresWithStats(100, 5000L);
      assertTrue(res.exists);
      assertFalse(res.mappings.isEmpty());
      assertTrue(res.stats.solutions > 0);
    }

    @Test
    void timeoutSetters() throws Exception {
      SMSD smsd = new SMSD(mol("c1ccccc1"), mol("c1ccc2ccccc2c1"), new ChemOptions());
      smsd.setSubstructureTimeoutMs(100L);
      smsd.setMcsTimeoutMs(100L);
      // Should work with custom timeouts
      assertTrue(smsd.isSubstructure());
      assertNotNull(smsd.findMCS());
    }

    @Test
    void smartsConstructor() throws Exception {
      IAtomContainer target = mol("c1ccc(O)cc1");
      SMSD smsd = new SMSD("[OH]", target, new ChemOptions());
      assertTrue(smsd.isSubstructure(), "SMARTS [OH] should match phenol");
      assertThrows(UnsupportedOperationException.class, smsd::getQuery, "SMARTS query should throw on getQuery()");
    }

    @Test
    void smartsUnsupportedForEnumeration() throws Exception {
      IAtomContainer target = mol("CCO");
      SMSD smsd = new SMSD("[OH]", target, new ChemOptions());
      assertThrows(UnsupportedOperationException.class, () -> smsd.findAllSubstructures(10, 1000L));
    }

    @Test
    void smilesConvenienceConstructor() throws Exception {
      SMSD smsd = new SMSD("c1ccccc1", "c1ccc(O)cc1", new ChemOptions());
      assertTrue(smsd.isSubstructure());
      assertNotNull(smsd.getQuery());
      assertNotNull(smsd.getTarget());
    }
  }

  // ======================================================================
  // 9. NAMED SMARTS PREDICATES
  // ======================================================================

  @Nested
  @DisplayName("Named SMARTS Predicates")
  class PredicateTests {
    private boolean matchPredicate(String sig, String targetSmi) throws Exception {
      Standardiser.PredicateRegistry reg = new Standardiser.PredicateRegistry();
      String expanded = Standardiser.expandNamedPredicates(sig, reg);
      IAtomContainer t = mol(targetSmi);
      return !Standardiser.matchAll(expanded, t).isEmpty();
    }

    @Test
    void isKetone() throws Exception {
      assertTrue(matchPredicate("[C;$isKetone]", "CC(=O)C"));
    }

    @Test
    void isKetoneNotAldehyde() throws Exception {
      assertFalse(matchPredicate("[C;$isKetone]", "CC=O"));
    }

    @Test
    void isCarboxylC() throws Exception {
      assertTrue(matchPredicate("[C;$isCarboxylC]", "CC(=O)O"));
    }

    @Test
    void isEster() throws Exception {
      assertTrue(matchPredicate("[C;$isEster]", "CC(=O)OC"));
    }

    @Test
    void isHalogen() throws Exception {
      assertTrue(matchPredicate("[*;$isHalogen]", "CCCl"));
    }

    @Test
    void isHalogenBromine() throws Exception {
      assertTrue(matchPredicate("[*;$isHalogen]", "CCBr"));
    }
  }

  // ======================================================================
  // 10. MCS SCENARIOS
  // ======================================================================

  @Nested
  @DisplayName("MCS Scenarios")
  class McsScenarioTests {
    @Test
    void inducedDisconnected() throws Exception {
      SMSD smsd = new SMSD(mol("CC.CC"), mol("CCCCCC"), new ChemOptions());
      Map<Integer, Integer> mcs = smsd.findMCS(true, false, 5000L);
      assertNotNull(mcs);
      assertTrue(mcs.size() >= 2);
    }

    @Test
    void mccsVsMcis() throws Exception {
      // MCCS (non-induced) should be >= MCIS (induced)
      SMSD smsd = new SMSD(mol("CCCC"), mol("CC=CC"), new ChemOptions());
      Map<Integer, Integer> mccs = smsd.findMCS(false, true, 5000L);
      Map<Integer, Integer> mcis = smsd.findMCS(true, true, 5000L);
      assertTrue(mccs.size() >= mcis.size(), "MCCS >= MCIS");
    }

    @Test
    void ringVsChainMCS() throws Exception {
      // Benzene vs hexane with ring constraint
      ChemOptions opts = new ChemOptions();
      opts.ringMatchesRingOnly = true;
      SMSD smsd = new SMSD(mol("c1ccccc1"), mol("CCCCCC"), opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000L);
      assertTrue(mcs.isEmpty(), "Ring atoms should not map to chain atoms");
    }

    @Test
    void largeMolMCS() throws Exception {
      // Aspirin vs ibuprofen — share aromatic ring
      SMSD smsd =
          new SMSD(
              mol("CC(=O)Oc1ccccc1C(=O)O"), // aspirin
              mol("CC(C)Cc1ccc(C(C)C(=O)O)cc1"), // ibuprofen
              new ChemOptions());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 10000L);
      assertTrue(mcs.size() >= 6, "Should share at least a benzene ring");
    }
  }

  // ======================================================================
  // 11. DRUG MOLECULES — real-world pairs
  // ======================================================================

  @Nested
  @DisplayName("Drug Molecule Pairs")
  class DrugPairTests {
    @Test
    void caffeineContainsPurine() throws Exception {
      // Purine core in caffeine
      assertTrue(
          new SMSD(
                  mol("c1ncnc2[nH]cnc12"), // purine
                  mol("Cn1c(=O)c2c(ncn2C)n(C)c1=O"), // caffeine
                  ChemOptions.profile("compat-substruct"))
              .isSubstructure());
    }

    @Test
    void diazepamVsClonazepam() throws Exception {
      // Benzodiazepine core shared
      SMSD smsd =
          new SMSD(
              mol("c1ccc2c(c1)C(=NCC(=O)N2)c1ccccc1Cl"), // diazepam
              mol("c1cc2c(cc1[N+](=O)[O-])C(=NCC(=O)N2)c1ccccc1Cl"), // clonazepam
              new ChemOptions());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 15000L);
      assertTrue(mcs.size() >= 15, "Benzodiazepine core should be shared");
    }

    @Test
    void ibuprofenVsNaproxen() throws Exception {
      SMSD smsd =
          new SMSD(
              mol("CC(C)Cc1ccc(C(C)C(=O)O)cc1"), // ibuprofen
              mol("COc1ccc2cc(C(C)C(=O)O)ccc2c1"), // naproxen
              new ChemOptions());
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 10000L);
      assertTrue(mcs.size() >= 8, "Share propionic acid + aromatic");
    }
  }

  // ======================================================================
  // 12. ROBUSTNESS & EDGE CASE TESTS
  // ======================================================================

  @Nested
  @DisplayName("Robustness & Edge Case Tests")
  class RobustnessEdgeCaseTests {

    @Test
    @DisplayName("Null query molecule throws NullPointerException")
    void nullQueryMolecule() {
      IAtomContainer target = assertDoesNotThrow(() -> mol("C"));
      ChemOptions opts = new ChemOptions();
      assertThrows(NullPointerException.class, () -> new SMSD((IAtomContainer) null, target, opts));
    }

    @Test
    @DisplayName("Null target molecule throws NullPointerException")
    void nullTargetMolecule() {
      IAtomContainer query = assertDoesNotThrow(() -> mol("C"));
      ChemOptions opts = new ChemOptions();
      assertThrows(NullPointerException.class, () -> new SMSD(query, (IAtomContainer) null, opts));
    }

    @Test
    @DisplayName("Empty SMILES for both query and target does not throw")
    void emptySmilesBothMolecules() throws Exception {
      IAtomContainer q = SP.parseSmiles("");
      IAtomContainer t = SP.parseSmiles("");
      ChemOptions opts = new ChemOptions();
      SMSD smsd = new SMSD(q, t, opts);
      // Should not throw
      smsd.isSubstructure();
    }

    @Test
    @DisplayName("Single atom C in single atom C is substructure")
    void singleAtomCinC() throws Exception {
      assertTrue(new SMSD(mol("C"), mol("C"), new ChemOptions()).isSubstructure());
    }

    @Test
    @DisplayName("Single atom C in single atom N is not substructure")
    void singleAtomCinN() throws Exception {
      assertFalse(new SMSD(mol("C"), mol("N"), new ChemOptions()).isSubstructure());
    }

    @Test
    @DisplayName("Query larger than target: naphthalene not in benzene")
    void queryLargerThanTarget() throws Exception {
      assertFalse(
          new SMSD(mol("c1ccc2ccccc2c1"), mol("c1ccccc1"), new ChemOptions()).isSubstructure());
    }

    @Test
    @DisplayName("Timeout 1ms on large pair does not hang")
    void timeoutDoesNotHang() throws Exception {
      IAtomContainer q = mol("c1ccc2ccccc2c1"); // naphthalene
      IAtomContainer t = mol("c1ccc2cc3ccccc3cc2c1"); // anthracene
      ChemOptions opts = new ChemOptions();
      SMSD smsd = new SMSD(q, t, opts);
      smsd.setSubstructureTimeoutMs(1L);
      long start = System.currentTimeMillis();
      // May or may not find the result, but must not hang
      smsd.isSubstructure();
      long elapsed = System.currentTimeMillis() - start;
      assertTrue(elapsed < 5000, "Should complete within 5 seconds, took " + elapsed + "ms");
    }

    @Test
    @DisplayName("Molecules with explicit hydrogens: [H]O[H] water")
    void explicitHydrogensWater() throws Exception {
      IAtomContainer water = SP.parseSmiles("[H]O[H]");
      IAtomContainer target = SP.parseSmiles("[H]O[H]");
      ChemOptions opts = new ChemOptions();
      SMSD smsd = new SMSD(water, target, opts);
      // Should parse and check without error
      boolean result = smsd.isSubstructure();
      assertTrue(result, "Water should be substructure of itself");
    }

    @Test
    @DisplayName("3+ disconnected fragments: C.C.C in CCCC handled gracefully")
    void disconnectedFragments() throws Exception {
      IAtomContainer q = mol("C.C.C");
      IAtomContainer t = mol("CCCC");
      ChemOptions opts = new ChemOptions();
      SMSD smsd = new SMSD(q, t, opts);
      // Should handle gracefully without exception
      smsd.isSubstructure();
    }

    @Test
    @DisplayName("Very long chain: C*200 contains C*100 substructure, completes < 5s")
    void veryLongChainSubstructure() throws Exception {
      String longChain200 = "C".repeat(200);
      String longChain100 = "C".repeat(100);
      IAtomContainer q = SP.parseSmiles(longChain100);
      IAtomContainer t = SP.parseSmiles(longChain200);
      ChemOptions opts = new ChemOptions();
      SMSD smsd = new SMSD(q, t, opts);
      long start = System.currentTimeMillis();
      boolean result = smsd.isSubstructure();
      long elapsed = System.currentTimeMillis() - start;
      assertTrue(result, "C*100 should be substructure of C*200");
      assertTrue(elapsed < 5000, "Should complete within 5 seconds, took " + elapsed + "ms");
    }
  }

  // ======================================================================
  // 13. STANDARDISER & TAUTOMERMODE TESTS
  // ======================================================================

  @Nested
  @DisplayName("Standardiser & TautomerMode Tests")
  class StandardiserTautomerTests {

    @Test
    @DisplayName("Standardiser.standardise(null, NONE) throws NullPointerException")
    void standardiseNullThrows() {
      assertThrows(
          NullPointerException.class,
          () -> Standardiser.standardise(null, Standardiser.TautomerMode.NONE));
    }

    @Test
    @DisplayName("TautomerMode.NONE: standardise benzene preserves 6 atoms")
    void tautomerNoneBenzene() throws Exception {
      IAtomContainer benzene = SP.parseSmiles("c1ccccc1");
      IAtomContainer result = Standardiser.standardise(benzene, Standardiser.TautomerMode.NONE);
      assertEquals(6, result.getAtomCount(), "Benzene should have 6 atoms after standardisation");
    }

    @Test
    @DisplayName("Standardiser handles molecule without implicit H counts")
    void moleculeWithoutImplicitH() throws Exception {
      IAtomContainer mol = SilentChemObjectBuilder.getInstance().newAtomContainer();
      Atom c1 = new Atom("C");
      Atom c2 = new Atom("C");
      // Deliberately do NOT set implicit H count
      mol.addAtom(c1);
      mol.addAtom(c2);
      mol.addBond(0, 1, IBond.Order.SINGLE);
      // Should not throw
      IAtomContainer result = Standardiser.standardise(mol, Standardiser.TautomerMode.NONE);
      assertNotNull(result);
    }

    @Test
    @DisplayName("Standardiser preserves ring info for naphthalene")
    void preservesRingInfo() throws Exception {
      IAtomContainer naphthalene = SP.parseSmiles("c1ccc2ccccc2c1");
      IAtomContainer result = Standardiser.standardise(naphthalene, Standardiser.TautomerMode.NONE);
      RingSearch rs = new RingSearch(result);
      assertTrue(
          rs.numRings() >= 2, "Naphthalene should have at least 2 rings after standardisation");
    }

    @Test
    @DisplayName("Salt stripping: largest fragment of [Na+].[Cl-].c1ccccc1 has 6 carbons")
    void saltStripping() throws Exception {
      IAtomContainer saltMix = SP.parseSmiles("[Na+].[Cl-].c1ccccc1");
      IAtomContainer result = Standardiser.standardise(saltMix, Standardiser.TautomerMode.NONE);
      // Count carbon atoms in the result
      long carbonCount = 0;
      for (int i = 0; i < result.getAtomCount(); i++) {
        if ("C".equals(result.getAtom(i).getSymbol())) {
          carbonCount++;
        }
      }
      assertEquals(
          6, carbonCount, "After salt stripping, largest fragment should have 6 carbon atoms");
    }
  }
}
