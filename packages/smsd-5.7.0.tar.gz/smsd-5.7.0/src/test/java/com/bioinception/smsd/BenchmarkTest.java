/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2018-2026 BioInception PVT LTD
 * Algorithm Copyright (c) 2009-2026 Syed Asad Rahman
 */
package com.bioinception.smsd;

import static org.junit.jupiter.api.Assertions.*;

import com.bioinception.smsd.core.*;
import java.util.*;
import org.junit.jupiter.api.*;
import org.openscience.cdk.interfaces.IAtomContainer;

@DisplayName("Benchmark & Performance Regression Tests")
public class BenchmarkTest extends TestBase {

  @Test
  @DisplayName("Large molecule substructure completes under 200ms")
  void largeMolSubstructureRegression() throws Exception {
    IAtomContainer q = mol("C".repeat(50));
    IAtomContainer t = mol("C".repeat(70));
    long t0 = System.nanoTime();
    SMSD smsd = new SMSD(q, t, new ChemOptions());
    boolean result = smsd.isSubstructure(5000);
    long elapsed = (System.nanoTime() - t0) / 1_000_000;
    assertTrue(result, "C50 should be substructure of C70");
    assertTrue(elapsed < 200, "Should complete under 200ms, took " + elapsed + "ms");
  }

  @Test
  @DisplayName("Drug pair MCS completes under 5s")
  void drugMcsRegression() throws Exception {
    IAtomContainer aspirin = mol("CC(=O)Oc1ccccc1C(=O)O");
    IAtomContainer ibuprofen = mol("CC(C)Cc1ccc(cc1)C(C)C(=O)O");
    long t0 = System.nanoTime();
    SMSD smsd = new SMSD(aspirin, ibuprofen, new ChemOptions());
    Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000);
    long elapsed = (System.nanoTime() - t0) / 1_000_000;
    assertFalse(mcs.isEmpty(), "MCS should find common atoms");
    assertTrue(elapsed < 5000, "Should complete under 5s, took " + elapsed + "ms");
  }

  @Test
  @DisplayName("RASCAL upper bound >= actual MCS Tanimoto")
  void rascalCorrectnessInvariant() throws Exception {
    String[][] pairs = {
      {"c1ccccc1", "c1ccc(C)cc1"},
      {"CC(=O)O", "CC(=O)Nc1ccc(O)cc1"},
      {"c1ccc2ccccc2c1", "c1ccc2cc3ccccc3cc2c1"},
      {"CCO", "CCCO"},
      {"c1ccncc1", "c1ccoc1"},
    };
    ChemOptions opts = new ChemOptions();
    for (String[] p : pairs) {
      IAtomContainer m1 = mol(p[0]), m2 = mol(p[1]);
      double ub = SearchEngine.similarityUpperBound(m1, m2, opts);
      SMSD smsd = new SMSD(m1, m2, opts);
      Map<Integer, Integer> mcs = smsd.findMCS(false, true, 5000);
      int common = mcs.size();
      int total = m1.getAtomCount() + m2.getAtomCount() - common;
      double actual = total > 0 ? (double) common / total : 0.0;
      assertTrue(
          ub >= actual - 0.01,
          String.format(
              "RASCAL UB (%.3f) should be >= actual Tanimoto (%.3f) for %s vs %s",
              ub, actual, p[0], p[1]));
    }
  }

  @Test
  @DisplayName("Batch MCS completes and returns results")
  void batchMcsCompletes() throws Exception {
    List<IAtomContainer> mols = new ArrayList<>();
    mols.add(mol("c1ccccc1"));
    mols.add(mol("c1ccc(O)cc1"));
    mols.add(mol("c1ccc(N)cc1"));
    mols.add(mol("c1ccc(C)cc1"));
    mols.add(mol("c1ccc2ccccc2c1"));
    ChemOptions opts = new ChemOptions();
    long t0 = System.nanoTime();
    Map<Integer, Map<Integer, Integer>> results =
        SearchEngine.batchMCS(mols, opts, new SearchEngine.McsOptions(), 0.1);
    long elapsed = (System.nanoTime() - t0) / 1_000_000;
    assertNotNull(results, "Batch MCS should return results");
    assertFalse(results.isEmpty(), "Should find at least one pair above threshold");
    assertTrue(elapsed < 10000, "Batch of 5 should complete under 10s, took " + elapsed + "ms");
  }

  @Test
  @DisplayName("All MCS mappings are chemically valid and maximal")
  void mcsChemicalValidation() throws Exception {
    String[][] pairs = {
      {"c1ccccc1", "Cc1ccccc1", "benzene-toluene"},
      {"CC(=O)Oc1ccccc1C(=O)O", "CC(=O)Nc1ccc(O)cc1", "aspirin-acetaminophen"},
      {"CN1CCC23C4C1CC5=C2C(=CC=C5)OC3C(C=C4)O",
       "COC1=CC=C2C3CC4=CC=C(O)C5=C4C3(CCN2C)C=C51", "morphine-codeine"},
      {"CC(C)Cc1ccc(CC(C)C(=O)O)cc1", "COc1ccc2cc(CC(C)C(=O)O)ccc2c1", "ibuprofen-naproxen"},
      {"Cn1c(=O)c2c(ncn2C)n(C)c1=O", "Cn1c(=O)c2[nH]cnc2n(C)c1=O", "caffeine-theophylline"},
      {"Nc1ncnc2n(cnc12)C1OC(COP(=O)(O)OP(=O)(O)OP(=O)(O)O)C(O)C1O",
       "Nc1ncnc2n(cnc12)C1OC(COP(=O)(O)OP(=O)(O)O)C(O)C1O", "ATP-ADP"},
    };
    ChemOptions opts = new ChemOptions();
    for (String[] p : pairs) {
      MolGraph g1 = new MolGraph(mol(p[0]));
      MolGraph g2 = new MolGraph(mol(p[1]));
      Map<Integer, Integer> mcs = SearchEngine.findMCS(g1, g2, opts, new SearchEngine.McsOptions());
      List<String> errors = SearchEngine.validateMapping(g1, g2, mcs, opts);
      assertTrue(errors.isEmpty(),
          p[2] + " mapping has errors: " + errors);
      if (mcs.size() > 0) {
        boolean maximal = SearchEngine.isMappingMaximal(g1, g2, mcs, opts);
        // Note: not all MCS are maximal (coverage may not reach upperBound)
        // but we log it for awareness
        if (!maximal) System.out.println("INFO: " + p[2] + " MCS (" + mcs.size() + " atoms) is extensible");
      }
    }
  }
}
