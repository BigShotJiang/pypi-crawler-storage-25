/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2018-2026 BioInception PVT LTD
 * Algorithm Copyright (c) 2009-2026 Syed Asad Rahman
 */
package com.bioinception.smsd;

import static org.junit.jupiter.api.Assertions.*;

import com.bioinception.smsd.core.*;
import java.util.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.openscience.cdk.interfaces.IAtomContainer;

/**
 * Head-to-head benchmark suite for SMSD.
 *
 * <p>Disabled by default. Run with:
 *
 * <pre>
 *   mvn test -Dtest=HeadToHeadBenchmark -Dbenchmark=true
 * </pre>
 *
 * <p>Prints timing table to stdout for comparison with other MCS tools.
 */
@DisplayName("Head-to-Head Benchmark Suite")
@EnabledIfSystemProperty(named = "benchmark", matches = "true")
public class HeadToHeadBenchmark extends TestBase {

  private static final int WARMUP = 20;
  private static final int ITERS = 100;

  private static final String[][] PAIRS = {
    {"c1ccccc1", "Cc1ccccc1", "Benzene/Toluene"},
    {"CC(=O)Oc1ccccc1C(=O)O", "CC(=O)Nc1ccc(O)cc1", "Aspirin/Acetaminophen"},
    {
      "CN1CCC23C4C1CC5=C2C(=C(C=C5)O)OC3C(C=C4)O",
      "COC1=CC=C2C3CC4=CC(=C(C=C4C3(CCN2C)C1=O)O)OC",
      "Morphine/Codeine"
    },
    {
      "CC(C)Cc1ccc(CC(C)C(O)=O)cc1",
      "COc1ccc2cc(CC(C)C(O)=O)ccc2c1",
      "Ibuprofen/Naproxen"
    },
    {"Cn1cnc2c1c(=O)n(C)c(=O)n2C", "Cn1cnc2c1c(=O)[nH]c(=O)n2C", "Caffeine/Theophylline"},
    {
      "Nc1ncnc2n(cnc12)C1OC(COP(O)(=O)OP(O)(=O)OP(O)(O)=O)C(O)C1O",
      "Nc1ncnc2n(cnc12)C1OC(COP(O)(=O)OP(O)(O)=O)C(O)C1O",
      "ATP/ADP"
    },
    {
      "C1=CC(=C[N+](=C1)C2C(C(C(O2)COP(=O)(O)OP(=O)(O)OCC3C(C(C(O3)N4C=NC5=C4N=CN=C5N)O)O)O)O)C(=O)N",
      "C1C=CN(C=C1C(=O)N)C2C(C(C(O2)COP(=O)(O)OP(=O)(O)OCC3C(C(C(O3)N4C=NC5=C4N=CN=C5N)O)O)O)O",
      "NAD+/NADH"
    },
    {
      "CC1=C2C(C(=O)C3(C(CC4C(C3C(C(C2(C)C)(CC1OC(=O)C(C(C5=CC=CC=C5)NC(=O)C6=CC=CC=C6)O)O)OC(=O)C7=CC=CC=C7)(CO4)OC(=O)C)O)C)OC(=O)C",
      "CC1=C2C(C(=O)C3(C(CC4C(C3C(C(C2(C)C)(CC1OC(=O)C(C(C5=CC=CC=C5)NC(=O)OC(C)(C)C)O)O)OC(=O)C6=CC=CC=C6)(CO4)OC(=O)C)O)C)O",
      "Paclitaxel/Docetaxel"
    },
    {
      "CCC1OC(=O)C(C)C(OC2CC(C)(OC)C(O)C(C)O2)C(C)C(OC2OC(C)CC(C2O)N(C)C)C(C)(O)CC(C)C(=O)C(C)C(O)C1(C)O",
      "CCC1C(C(C(N(CC(CC(C(C(C(C(C(=O)O1)C)OC2CC(C(C(O2)C)O)(C)OC)C)OC3C(C(CC(O3)C)N(C)C)O)(C)O)C)C)C)O)(C)O",
      "Erythromycin/Azithromycin"
    },
    {
      "CC(C)C1=C(C(=C(N1CCC(CC(CC(=O)O)O)O)C2=CC=C(C=C2)F)C3=CC=CC=C3)C(=O)NC4=CC=CC=C4",
      "CC(C)C1=NC(=NC(=C1C=CC(CC(CC(=O)O)O)O)C2=CC=C(C=C2)F)N(C)S(=O)(=O)C",
      "Atorvastatin/Rosuvastatin"
    },
  };

  @Test
  @DisplayName("Substructure benchmark")
  void substructureBenchmark() throws Exception {
    System.out.println("\n=== SUBSTRUCTURE BENCHMARK ===");
    System.out.printf("%-30s %10s %10s %10s%n", "Pair", "Best(us)", "Med(us)", "Mean(us)");
    System.out.println("-".repeat(65));

    ChemOptions opts = new ChemOptions();
    for (String[] p : PAIRS) {
      IAtomContainer q = mol(p[0]), t = mol(p[1]);
      // Warmup
      for (int i = 0; i < WARMUP; i++) {
        SearchEngine.isSubstructure(q, t, opts, 5000);
      }
      // Timed
      long[] times = new long[ITERS];
      for (int i = 0; i < ITERS; i++) {
        long t0 = System.nanoTime();
        SearchEngine.isSubstructure(q, t, opts, 5000);
        times[i] = System.nanoTime() - t0;
      }
      Arrays.sort(times);
      long best = times[0] / 1000;
      long median = times[ITERS / 2] / 1000;
      long mean = 0;
      for (long x : times) mean += x;
      mean = mean / ITERS / 1000;
      System.out.printf("%-30s %,10d %,10d %,10d%n", p[2], best, median, mean);
    }
    assertTrue(true); // benchmark always passes
  }

  @Test
  @DisplayName("MCS benchmark")
  void mcsBenchmark() throws Exception {
    System.out.println("\n=== MCS BENCHMARK ===");
    System.out.printf("%-30s %10s %10s %10s %6s%n", "Pair", "Best(us)", "Med(us)", "Mean(us)", "MCS");
    System.out.println("-".repeat(72));

    ChemOptions opts = new ChemOptions();
    SearchEngine.McsOptions mcsOpts = new SearchEngine.McsOptions();
    mcsOpts.timeoutMillis = 10_000;

    for (String[] p : PAIRS) {
      IAtomContainer q = mol(p[0]), t = mol(p[1]);
      // Warmup
      for (int i = 0; i < WARMUP; i++) {
        SearchEngine.findMCS(q, t, opts, mcsOpts);
      }
      // Timed
      long[] times = new long[ITERS];
      int mcsSize = 0;
      for (int i = 0; i < ITERS; i++) {
        long t0 = System.nanoTime();
        Map<Integer, Integer> mcs = SearchEngine.findMCS(q, t, opts, mcsOpts);
        times[i] = System.nanoTime() - t0;
        mcsSize = mcs.size();
      }
      Arrays.sort(times);
      long best = times[0] / 1000;
      long median = times[ITERS / 2] / 1000;
      long mean = 0;
      for (long x : times) mean += x;
      mean = mean / ITERS / 1000;
      System.out.printf("%-30s %,10d %,10d %,10d %6d%n", p[2], best, median, mean, mcsSize);
    }
    assertTrue(true);
  }

  @Test
  @DisplayName("RASCAL screening benchmark")
  void rascalBenchmark() throws Exception {
    System.out.println("\n=== RASCAL SCREENING BENCHMARK ===");
    System.out.printf("%-30s %10s %10s %8s%n", "Pair", "Best(us)", "Med(us)", "UB");
    System.out.println("-".repeat(60));

    ChemOptions opts = new ChemOptions();
    for (String[] p : PAIRS) {
      IAtomContainer q = mol(p[0]), t = mol(p[1]);
      // Warmup
      for (int i = 0; i < WARMUP; i++) {
        SearchEngine.similarityUpperBound(q, t, opts);
      }
      // Timed
      long[] times = new long[ITERS];
      double ub = 0;
      for (int i = 0; i < ITERS; i++) {
        long t0 = System.nanoTime();
        ub = SearchEngine.similarityUpperBound(q, t, opts);
        times[i] = System.nanoTime() - t0;
      }
      Arrays.sort(times);
      long best = times[0] / 1000;
      long median = times[ITERS / 2] / 1000;
      System.out.printf("%-30s %,10d %,10d %8.4f%n", p[2], best, median, ub);
    }
    assertTrue(true);
  }

  @Test
  @DisplayName("MolGraph.Builder benchmark (CDK-free path)")
  void builderBenchmark() throws Exception {
    System.out.println("\n=== MOLGRAPH.BUILDER BENCHMARK (CDK-free) ===");
    System.out.printf("%-30s %10s %10s %6s%n", "Pair", "Best(us)", "Med(us)", "MCS");
    System.out.println("-".repeat(60));

    // Build benzene and phenol via Builder (no CDK)
    MolGraph benzene =
        new MolGraph.Builder()
            .atomCount(6)
            .atomicNumbers(new int[] {6, 6, 6, 6, 6, 6})
            .aromaticFlags(new boolean[] {true, true, true, true, true, true})
            .ringFlags(new boolean[] {true, true, true, true, true, true})
            .neighbors(new int[][] {{1, 5}, {0, 2}, {1, 3}, {2, 4}, {3, 5}, {4, 0}})
            .bondOrders(new int[][] {{4, 4}, {4, 4}, {4, 4}, {4, 4}, {4, 4}, {4, 4}})
            .bondRingFlags(
                new boolean[][] {
                  {true, true}, {true, true}, {true, true},
                  {true, true}, {true, true}, {true, true}
                })
            .bondAromaticFlags(
                new boolean[][] {
                  {true, true}, {true, true}, {true, true},
                  {true, true}, {true, true}, {true, true}
                })
            .build();

    MolGraph phenol =
        new MolGraph.Builder()
            .atomCount(7)
            .atomicNumbers(new int[] {6, 6, 6, 6, 6, 6, 8})
            .aromaticFlags(new boolean[] {true, true, true, true, true, true, false})
            .ringFlags(new boolean[] {true, true, true, true, true, true, false})
            .neighbors(
                new int[][] {{1, 5, 6}, {0, 2}, {1, 3}, {2, 4}, {3, 5}, {4, 0}, {0}})
            .bondOrders(
                new int[][] {{4, 4, 1}, {4, 4}, {4, 4}, {4, 4}, {4, 4}, {4, 4}, {1}})
            .bondRingFlags(
                new boolean[][] {
                  {true, true, false}, {true, true}, {true, true},
                  {true, true}, {true, true}, {true, true}, {false}
                })
            .bondAromaticFlags(
                new boolean[][] {
                  {true, true, false}, {true, true}, {true, true},
                  {true, true}, {true, true}, {true, true}, {false}
                })
            .build();

    ChemOptions opts = new ChemOptions();
    SearchEngine.McsOptions mcsOpts = new SearchEngine.McsOptions();
    mcsOpts.timeoutMillis = 5000;

    // Warmup
    for (int i = 0; i < WARMUP; i++) {
      SearchEngine.isSubstructure(benzene, phenol, opts, 5000);
      SearchEngine.findMCS(benzene, phenol, opts, mcsOpts);
    }

    // Substructure
    long[] times = new long[ITERS];
    for (int i = 0; i < ITERS; i++) {
      long t0 = System.nanoTime();
      SearchEngine.isSubstructure(benzene, phenol, opts, 5000);
      times[i] = System.nanoTime() - t0;
    }
    Arrays.sort(times);
    System.out.printf(
        "%-30s %,10d %,10d %6s%n",
        "Benzene->Phenol (sub)", times[0] / 1000, times[ITERS / 2] / 1000, "Y");

    // MCS
    times = new long[ITERS];
    int mcsSize = 0;
    for (int i = 0; i < ITERS; i++) {
      long t0 = System.nanoTime();
      Map<Integer, Integer> mcs = SearchEngine.findMCS(benzene, phenol, opts, mcsOpts);
      times[i] = System.nanoTime() - t0;
      mcsSize = mcs.size();
    }
    Arrays.sort(times);
    System.out.printf(
        "%-30s %,10d %,10d %6d%n",
        "Benzene/Phenol (MCS)", times[0] / 1000, times[ITERS / 2] / 1000, mcsSize);

    assertTrue(true);
  }
}
