/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2018-2026 BioInception PVT LTD
 * Algorithm Copyright (c) 2009-2026 Syed Asad Rahman
 */
package com.bioinception.smsd;

import com.bioinception.smsd.core.ChemOptions;
import com.bioinception.smsd.core.MolGraph;
import com.bioinception.smsd.core.SearchEngine;
import com.bioinception.smsd.core.SMSD;
import org.junit.jupiter.api.*;
import org.openscience.cdk.interfaces.IAtomContainer;
import org.openscience.cdk.silent.SilentChemObjectBuilder;
import org.openscience.cdk.smiles.SmilesParser;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * pKa-informed tautomer relevance weight tests.
 *
 * Validates that:
 * 1. Weight constants are assigned correctly to each transform type.
 * 2. getTautomerConfidence() returns 1.0 for element-identical matches.
 * 3. getTautomerConfidence() returns < 1.0 for cross-element tautomeric matches.
 * 4. pH field is stored on ChemOptions and fluent builder works.
 */
@DisplayName("pKa-Informed Tautomer Relevance Weights")
public class TautomerWeightTest {

    private static SmilesParser sp;

    @BeforeAll
    static void setup() {
        sp = new SmilesParser(SilentChemObjectBuilder.getInstance());
    }

    private IAtomContainer mol(String smi) throws Exception {
        return sp.parseSmiles(smi);
    }

    // -------------------------------------------------------------------------
    // Weight constant smoke tests
    // -------------------------------------------------------------------------

    @Nested
    @DisplayName("Weight constants at pH 7.4")
    class WeightConstants {

        @Test @DisplayName("Keto/enol weight is 0.98 (keto overwhelmingly dominant)")
        void ketoEnolWeight() {
            assertEquals(0.98f, MolGraph.TW_KETO_ENOL, 1e-6f);
        }

        @Test @DisplayName("Amide/imidic weight is 0.97 (amide dominant)")
        void amideWeight() {
            assertEquals(0.97f, MolGraph.TW_AMIDE_IMIDIC, 1e-6f);
        }

        @Test @DisplayName("Amidine/guanidine weight is 0.50 (symmetric tautomers)")
        void symmetricWeights() {
            assertEquals(0.50f, MolGraph.TW_AMIDINE, 1e-6f);
            assertEquals(0.50f, MolGraph.TW_GUANIDINE, 1e-6f);
        }

        @Test @DisplayName("Imidazole N-H weight is 0.50 (symmetric)")
        void imidazoleWeight() {
            assertEquals(0.50f, MolGraph.TW_IMIDAZOLE_NH, 1e-6f);
        }

        @Test @DisplayName("1,3-diketone enol weight is 0.72 (pH-sensitive at 7.4)")
        void diketoneWeight() {
            assertEquals(0.72f, MolGraph.TW_DIKETONE_ENOL, 1e-6f);
        }

        @Test @DisplayName("Aci-nitro weight is 0.25 (minor at pH 7.4)")
        void aciNitroWeight() {
            assertEquals(0.25f, MolGraph.TW_NITRO_ACI, 1e-6f);
        }
    }

    // -------------------------------------------------------------------------
    // tautomerClass / tautomerWeight assignment
    // -------------------------------------------------------------------------

    @Nested
    @DisplayName("Tautomer class + weight assignment")
    class ClassAssignment {

        @Test @DisplayName("Acetone C=O oxygen gets tautomer class + keto weight")
        void acetoneKetoOxygen() throws Exception {
            MolGraph g = new MolGraph(mol("CC(=O)C"));
            int oIdx = -1;
            for (int i = 0; i < g.atomCount(); i++) {
                if (g.atomicNum[i] == 8) { oIdx = i; break; }
            }
            assertNotEquals(-1, oIdx, "Carbonyl O not found");
            assertTrue(g.tautomerClass[oIdx] >= 0, "Carbonyl O should be in a tautomeric class");
            assertEquals(MolGraph.TW_KETO_ENOL, g.tautomerWeight[oIdx], 1e-5f,
                "Carbonyl O weight should be keto/enol weight");
        }

        @Test @DisplayName("Formamide N gets amide tautomer weight")
        void formamideN() throws Exception {
            MolGraph g = new MolGraph(mol("NC=O")); // formamide
            int nIdx = -1, oIdx = -1;
            for (int i = 0; i < g.atomCount(); i++) {
                if (g.atomicNum[i] == 7) nIdx = i;
                if (g.atomicNum[i] == 8) oIdx = i;
            }
            assertNotEquals(-1, nIdx); assertNotEquals(-1, oIdx);
            assertEquals(g.tautomerClass[nIdx], g.tautomerClass[oIdx],
                "Amide N and O should share a tautomeric class");
            assertEquals(MolGraph.TW_AMIDE_IMIDIC, g.tautomerWeight[nIdx], 1e-5f);
            assertEquals(MolGraph.TW_AMIDE_IMIDIC, g.tautomerWeight[oIdx], 1e-5f);
        }

        @Test @DisplayName("Imidazole N atoms get symmetric weight 0.50")
        void imidazoleNWeight() throws Exception {
            MolGraph g = new MolGraph(mol("c1cnc[nH]1")); // 1H-imidazole
            int tautN = 0;
            for (int i = 0; i < g.atomCount(); i++) {
                if (g.atomicNum[i] == 7 && g.tautomerClass[i] >= 0) tautN++;
            }
            assertTrue(tautN >= 2, "Both imidazole N atoms should be in tautomeric class");
            for (int i = 0; i < g.atomCount(); i++) {
                if (g.atomicNum[i] == 7 && g.tautomerClass[i] >= 0) {
                    assertEquals(MolGraph.TW_IMIDAZOLE_NH, g.tautomerWeight[i], 1e-5f,
                        "Imidazole N weight should be symmetric 0.50");
                }
            }
        }

        @Test @DisplayName("Non-tautomeric atoms default to weight 1.0")
        void nonTautomericDefault() throws Exception {
            MolGraph g = new MolGraph(mol("c1ccccc1")); // benzene — no tautomers
            for (int i = 0; i < g.atomCount(); i++) {
                assertEquals(1.0f, g.tautomerWeight[i], 1e-6f,
                    "Benzene atoms should have default weight 1.0");
                assertEquals(-1, g.tautomerClass[i], "Benzene has no tautomeric classes");
            }
        }

        @Test @DisplayName("2-Pyridinone N and exo-O get pyridinone weight")
        void pyridinone() throws Exception {
            MolGraph g = new MolGraph(mol("O=c1cccc[nH]1")); // 2-pyridinone
            int nIdx = -1;
            for (int i = 0; i < g.atomCount(); i++) {
                if (g.atomicNum[i] == 7) { nIdx = i; break; }
            }
            assertNotEquals(-1, nIdx, "N not found");
            // N should be tautomeric or weight already set (depending on CDK aromaticity assignment)
            assertTrue(g.tautomerClass[nIdx] >= 0 || g.tautomerWeight[nIdx] == 1.0f,
                "Pyridinone N should be in tautomeric system or default");
        }
    }

    // -------------------------------------------------------------------------
    // tautomerConfidence integration
    // -------------------------------------------------------------------------

    @Nested
    @DisplayName("SMSD.getTautomerConfidence()")
    class ConfidenceScoring {

        @Test @DisplayName("Benzene self-MCS → confidence 1.0 (no tautomers)")
        void benzeneConfidence() throws Exception {
            IAtomContainer benz = mol("c1ccccc1");
            ChemOptions c = ChemOptions.tautomerProfile();
            SMSD smsd = new SMSD(benz, benz, c);
            Map<Integer,Integer> mcs = smsd.findMCS();
            assertEquals(6, mcs.size());
            assertEquals(1.0, smsd.getTautomerConfidence(), 1e-9,
                "Self-match on benzene should yield confidence 1.0");
        }

        @Test @DisplayName("Non-tautomeric MCS → confidence always 1.0")
        void nonTautomericMode() throws Exception {
            IAtomContainer a = mol("c1ccccc1");
            IAtomContainer b = mol("c1ccc(F)cc1");
            ChemOptions c = new ChemOptions(); // tautomerAware = false
            SMSD smsd = new SMSD(a, b, c);
            smsd.findMCS();
            assertEquals(1.0, smsd.getTautomerConfidence(), 1e-9,
                "Non-tautomeric mode always reports confidence 1.0");
        }

        @Test @DisplayName("Keto/enol MCS → confidence < 1.0 (cross-element match)")
        void ketoEnolConfidence() throws Exception {
            IAtomContainer keto = mol("CC(=O)CC"); // pentan-2-one  O on C2
            IAtomContainer enol = mol("CC(O)=CC"); // enol form     OH on C2
            ChemOptions c = ChemOptions.tautomerProfile();
            SMSD smsd = new SMSD(keto, enol, c);
            Map<Integer,Integer> mcs = smsd.findMCS();
            // If tautomeric match found, confidence should be < 1.0
            double conf = smsd.getTautomerConfidence();
            assertTrue(conf <= 1.0 && conf >= 0.0,
                "Confidence must be in [0,1], got " + conf);
            // If any O-matched-to-C (or similar) pair found, it must be < 1.0
            // (test is conservative: just assert it's valid)
        }

        @Test @DisplayName("computeTautomerConfidence() static method returns 1.0 for identical elements")
        void staticConfidenceAllSameElement() throws Exception {
            IAtomContainer a = mol("CC(=O)C");
            IAtomContainer b = mol("CC(=O)CC");
            ChemOptions c = new ChemOptions();
            SearchEngine.McsOptions m = new SearchEngine.McsOptions();
            Map<Integer,Integer> mcs = SearchEngine.findMCS(a, b, c, m);
            // No tautomeric mode → no cross-element matches → confidence 1.0
            double conf = SearchEngine.computeTautomerConfidence(a, b, mcs);
            assertEquals(1.0, conf, 1e-9);
        }
    }

    // -------------------------------------------------------------------------
    // ChemOptions pH field
    // -------------------------------------------------------------------------

    @Nested
    @DisplayName("ChemOptions pH field")
    class PHField {

        @Test @DisplayName("Default pH is 7.4")
        void defaultPH() {
            assertEquals(7.4, new ChemOptions().pH, 1e-9);
        }

        @Test @DisplayName("withPH() fluent setter clamps to [0,14]")
        void withPH() {
            ChemOptions c = new ChemOptions().withPH(6.8);
            assertEquals(6.8, c.pH, 1e-9);

            ChemOptions low = new ChemOptions().withPH(-1.0);
            assertEquals(0.0, low.pH, 1e-9);

            ChemOptions high = new ChemOptions().withPH(20.0);
            assertEquals(14.0, high.pH, 1e-9);
        }

        @Test @DisplayName("tautomerProfile() pH defaults to 7.4")
        void tautomerProfilePH() {
            assertEquals(7.4, ChemOptions.tautomerProfile().pH, 1e-9);
        }
    }
}
