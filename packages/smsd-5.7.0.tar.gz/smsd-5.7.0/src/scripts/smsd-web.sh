#!/bin/bash
# SMSD Pro Web UI launcher — opens browser automatically
# Copyright (c) 2018-2026 Syed Asad Rahman — BioInception PVT LTD

DIR="$(cd "$(dirname "$0")" && pwd)"
JAR="$DIR/smsd-web.jar"
PORT="${SMSD_PORT:-7070}"

if [ ! -f "$JAR" ]; then
    echo "Error: $JAR not found"
    exit 1
fi

echo "Starting SMSD Pro Web UI on http://localhost:$PORT"
echo "Press Ctrl+C to stop."

# Open browser after a short delay
(sleep 2 && open "http://localhost:$PORT" 2>/dev/null || xdg-open "http://localhost:$PORT" 2>/dev/null || true) &

exec java -jar "$JAR" --port "$PORT"
