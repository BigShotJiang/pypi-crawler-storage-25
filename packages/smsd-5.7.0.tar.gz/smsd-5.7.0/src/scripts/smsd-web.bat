@echo off
REM SMSD Pro Web UI launcher for Windows
REM Copyright (c) 2018-2026 Syed Asad Rahman - BioInception PVT LTD

set DIR=%~dp0
set JAR=%DIR%smsd-web.jar
set PORT=7070

if not exist "%JAR%" (
    echo Error: %JAR% not found
    pause
    exit /b 1
)

echo Starting SMSD Pro Web UI on http://localhost:%PORT%
echo Press Ctrl+C to stop.

REM Open browser after delay
start "" cmd /c "timeout /t 2 >nul & start http://localhost:%PORT%"

java -jar "%JAR%" --port %PORT%
