/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2018-2026 BioInception PVT LTD
 * Algorithm Copyright (c) 2009-2026 Syed Asad Rahman
 */
package com.bioinception.smsd.core;

import java.util.List;
import java.util.Map;
import org.openscience.cdk.DefaultChemObjectBuilder;
import org.openscience.cdk.interfaces.IAtomContainer;
import org.openscience.cdk.smiles.SmilesParser;

/**
 * Main entry point for the SMSD library: substructure search, enumeration, and MCS computation.
 *
 * <p>Molecules are standardised on construction by default. For pre-standardised molecules, pass
 * {@code standardise=false} to skip preprocessing. For zero-overhead, call {@link SearchEngine}
 * directly.
 *
 * <pre>{@code
 * // Quick MCS example
 * SMSD smsd = new SMSD(mol1, mol2, new ChemOptions());
 * Map<Integer, Integer> mcs = smsd.findMCS();
 * System.out.println("MCS size: " + mcs.size());
 * }</pre>
 *
 * @author Syed Asad Rahman
 * @see ChemOptions
 * @see SearchEngine
 */
public final class SMSD {

  private final IAtomContainer query;
  private final IAtomContainer target;
  private final ChemOptions chem;
  private final String querySmarts;
  private final boolean selfMatch;
  private long substructureTimeoutMs = 8_000L;
  private long mcsTimeoutMs = 10_000L;
  /**
   * pKa-informed confidence of the most recent tautomer-aware MCS result, ∈ [0,1].
   * Updated automatically by every {@code findMCS()} call when {@code tautomerAware=true}.
   * Always {@code 1.0} for non-tautomeric searches.
   * @see #getTautomerConfidence()
   */
  private double tautomerConfidence = 1.0;

  /**
   * Create an SMSD instance from two molecule containers with automatic standardisation.
   *
   * <pre>{@code
   * IAtomContainer q = sp.parseSmiles("c1ccccc1");
   * IAtomContainer t = sp.parseSmiles("c1ccc(O)cc1");
   * SMSD smsd = new SMSD(q, t, new ChemOptions());
   * }</pre>
   *
   * @param query  the query molecule (smaller or equal in size to target for best performance)
   * @param target the target molecule to search or compare against
   * @param chem   chemical matching options; if {@code null}, defaults are used
   */
  public SMSD(IAtomContainer query, IAtomContainer target, ChemOptions chem) {
    this(query, target, chem, true);
  }

  /**
   * Create an SMSD instance with explicit control over standardisation.
   *
   * <p>Pass {@code standardise=false} for pre-processed molecules (~2-5x faster construction).
   *
   * <pre>{@code
   * // Skip standardisation for pre-processed molecules
   * SMSD smsd = new SMSD(preProcessedQuery, preProcessedTarget, opts, false);
   * }</pre>
   *
   * @param query       the query molecule
   * @param target      the target molecule
   * @param chem        chemical matching options; if {@code null}, defaults are used
   * @param standardise {@code true} to apply CDK standardisation (aromaticity, typing);
   *                    {@code false} to skip it for pre-processed molecules
   */
  public SMSD(IAtomContainer query, IAtomContainer target, ChemOptions chem, boolean standardise) {
    if (query == null) throw new NullPointerException("query");
    if (target == null) throw new NullPointerException("target");
    this.chem = chem != null ? chem : new ChemOptions();
    this.querySmarts = null;
    this.selfMatch = (query == target);
    this.query = standardise ? standardiseSafe(query) : query;
    this.target = this.selfMatch ? this.query : (standardise ? standardiseSafe(target) : target);
  }

  /**
   * Create an SMSD instance with a SMARTS query string. Target is standardised by default.
   *
   * <pre>{@code
   * SMSD smsd = new SMSD("[#6]~[#7]", targetMol, new ChemOptions());
   * boolean match = smsd.isSubstructure();
   * }</pre>
   *
   * @param querySmarts the SMARTS pattern to match against the target
   * @param target      the target molecule
   * @param chem        chemical matching options; if {@code null}, defaults are used
   */
  public SMSD(String querySmarts, IAtomContainer target, ChemOptions chem) {
    this(querySmarts, target, chem, true);
  }

  /**
   * Create an SMSD instance with a SMARTS query and explicit standardisation control.
   *
   * @param querySmarts the SMARTS pattern to match against the target
   * @param target      the target molecule
   * @param chem        chemical matching options; if {@code null}, defaults are used
   * @param standardise {@code true} to apply standardisation to the target molecule
   */
  public SMSD(String querySmarts, IAtomContainer target, ChemOptions chem, boolean standardise) {
    if (querySmarts == null || querySmarts.isEmpty())
      throw new IllegalArgumentException("querySmarts must not be null or empty");
    if (target == null) throw new NullPointerException("target");
    this.chem = chem != null ? chem : new ChemOptions();
    this.querySmarts = querySmarts;
    this.selfMatch = false;
    this.query = null;
    this.target = standardise ? standardiseSafe(target) : target;
  }

  /**
   * Convenience constructor: parse both SMILES strings and standardise.
   *
   * <pre>{@code
   * SMSD smsd = new SMSD("c1ccccc1", "c1ccc(O)cc1", new ChemOptions());
   * Map<Integer, Integer> mcs = smsd.findMCS();
   * }</pre>
   *
   * @param querySmiles  SMILES string for the query molecule
   * @param targetSmiles SMILES string for the target molecule
   * @param chem         chemical matching options; if {@code null}, defaults are used
   * @throws Exception if either SMILES string cannot be parsed
   */
  public SMSD(String querySmiles, String targetSmiles, ChemOptions chem) throws Exception {
    if (querySmiles == null || querySmiles.isEmpty())
      throw new IllegalArgumentException("querySmiles must not be null or empty");
    if (targetSmiles == null || targetSmiles.isEmpty())
      throw new IllegalArgumentException("targetSmiles must not be null or empty");
    SmilesParser sp = new SmilesParser(DefaultChemObjectBuilder.getInstance());
    this.chem = chem != null ? chem : new ChemOptions();
    this.querySmarts = null;
    this.selfMatch = false;
    String qSmi = this.chem.lenientSmiles ? MolGraph.sanitizeSmiles(querySmiles) : querySmiles;
    String tSmi = this.chem.lenientSmiles ? MolGraph.sanitizeSmiles(targetSmiles) : targetSmiles;
    this.query = standardiseSafe(sp.parseSmiles(qSmi));
    this.target = standardiseSafe(sp.parseSmiles(tSmi));
  }

  /**
   * Set the timeout for substructure search operations.
   *
   * <pre>{@code
   * smsd.setSubstructureTimeoutMs(5000); // 5 seconds
   * }</pre>
   *
   * @param ms timeout in milliseconds (default: 8000)
   */
  public void setSubstructureTimeoutMs(long ms) { this.substructureTimeoutMs = ms; }

  /**
   * Set the timeout for MCS computation operations.
   *
   * <pre>{@code
   * smsd.setMcsTimeoutMs(30000); // 30 seconds for complex molecules
   * }</pre>
   *
   * @param ms timeout in milliseconds (default: 10000)
   */
  public void setMcsTimeoutMs(long ms) { this.mcsTimeoutMs = ms; }

  // ---- Substructure ----

  /**
   * Check if the query is a substructure of the target using the default timeout.
   *
   * <pre>{@code
   * SMSD smsd = new SMSD(benzene, phenol, new ChemOptions());
   * boolean isSub = smsd.isSubstructure(); // true: benzene is in phenol
   * }</pre>
   *
   * @return {@code true} if the query is a substructure of the target
   */
  public boolean isSubstructure() {
    return isSubstructure(substructureTimeoutMs);
  }

  /**
   * Check if the query is a substructure of the target with a specified timeout.
   *
   * <pre>{@code
   * boolean found = smsd.isSubstructure(5000); // 5-second timeout
   * }</pre>
   *
   * @param timeoutMs maximum time in milliseconds before the search is abandoned
   * @return {@code true} if the query is a substructure of the target
   * @throws RuntimeException if SMARTS matching fails (for SMARTS-based queries)
   */
  public boolean isSubstructure(long timeoutMs) {
    if (querySmarts != null) {
      try { return !Standardiser.matchAll(querySmarts, target).isEmpty(); }
      catch (Exception e) { throw new RuntimeException("SMARTS matching failed", e); }
    }
    if (selfMatch) return true;
    return SearchEngine.isSubstructure(query, target, chem, timeoutMs);
  }

  /**
   * Enumerate all unique substructure mappings (query atom index to target atom index).
   *
   * <pre>{@code
   * List<Map<Integer, Integer>> maps = smsd.findAllSubstructures(10, 5000);
   * for (Map<Integer, Integer> m : maps) {
   *     System.out.println("Mapping: " + m);
   * }
   * }</pre>
   *
   * @param maxSolutions maximum number of mappings to return
   * @param timeoutMs    maximum time in milliseconds
   * @return list of atom-index mappings (query index to target index)
   * @throws UnsupportedOperationException if this instance was created with a SMARTS query
   */
  public List<Map<Integer, Integer>> findAllSubstructures(int maxSolutions, long timeoutMs) {
    requireMoleculeQuery("findAllSubstructures");
    return SearchEngine.findAllSubstructures(query, target, chem, maxSolutions, timeoutMs);
  }

  /**
   * Check substructure with telemetry (nodes visited, backtracks, pruning stats).
   *
   * <pre>{@code
   * SearchEngine.SubstructureResult result = smsd.isSubstructureWithStats(5000);
   * System.out.println("Match: " + result.exists);
   * System.out.println("Nodes visited: " + result.stats.nodesVisited);
   * }</pre>
   *
   * @param timeoutMs maximum time in milliseconds
   * @return result containing the match outcome and detailed search statistics
   * @throws UnsupportedOperationException if this instance was created with a SMARTS query
   */
  public SearchEngine.SubstructureResult isSubstructureWithStats(long timeoutMs) {
    requireMoleculeQuery("isSubstructureWithStats");
    return SearchEngine.isSubstructureWithStats(query, target, chem, timeoutMs);
  }

  /**
   * Enumerate substructure mappings with telemetry.
   *
   * <pre>{@code
   * SearchEngine.SubstructureResult result = smsd.findAllSubstructuresWithStats(100, 10000);
   * System.out.println("Found " + result.mappings.size() + " mappings");
   * System.out.println("Nodes: " + result.stats.nodesVisited);
   * }</pre>
   *
   * @param maxSolutions maximum number of mappings to enumerate
   * @param timeoutMs    maximum time in milliseconds
   * @return result containing mappings and detailed search statistics
   * @throws UnsupportedOperationException if this instance was created with a SMARTS query
   */
  public SearchEngine.SubstructureResult findAllSubstructuresWithStats(
      int maxSolutions, long timeoutMs) {
    requireMoleculeQuery("findAllSubstructuresWithStats");
    return SearchEngine.findAllSubstructuresWithStats(query, target, chem, maxSolutions, timeoutMs);
  }

  // ---- MCS ----

  /**
   * Find the Maximum Common Substructure using defaults (non-induced, connected, default timeout).
   *
   * <pre>{@code
   * SMSD smsd = new SMSD(mol1, mol2, new ChemOptions());
   * Map<Integer, Integer> mcs = smsd.findMCS();
   * System.out.println("MCS has " + mcs.size() + " atoms");
   * }</pre>
   *
   * @return mapping from query atom indices to target atom indices; empty if no common substructure
   */
  public Map<Integer, Integer> findMCS() {
    return findMCS(false, true, mcsTimeoutMs);
  }

  /**
   * Find the Maximum Common Substructure with full control over parameters.
   *
   * <pre>{@code
   * // Induced, connected MCS with 30-second timeout
   * Map<Integer, Integer> mcs = smsd.findMCS(true, true, 30000);
   * }</pre>
   *
   * @param induced       {@code true} for induced MCS (edge-preserving); {@code false} for
   *                      non-induced (allows edge mismatches)
   * @param connectedOnly {@code true} to require the MCS to be a connected subgraph
   * @param timeoutMs     maximum time in milliseconds for the computation
   * @return mapping from query atom indices to target atom indices; empty if no common substructure
   */
  public Map<Integer, Integer> findMCS(boolean induced, boolean connectedOnly, long timeoutMs) {
    SearchEngine.McsOptions opt = new SearchEngine.McsOptions();
    opt.induced = induced;
    opt.connectedOnly = connectedOnly;
    opt.timeoutMillis = timeoutMs;
    Map<Integer, Integer> result = SearchEngine.findMCS(query, target, chem, opt);
    // Compute pKa-informed tautomer confidence for tautomer-aware searches.
    tautomerConfidence = chem.tautomerAware
        ? SearchEngine.computeTautomerConfidence(query, target, result)
        : 1.0;
    return result;
  }

  /**
   * Returns the pKa-informed tautomer confidence of the most recent {@link #findMCS()} call.
   *
   * <p>Confidence ∈ [0,1]: product of per-pair relevance weights for every cross-element
   * tautomeric atom match in the MCS.  A value of {@code 1.0} means either no tautomeric
   * flexibility was exercised, or all matched tautomeric atoms have the same element type.
   * Values below 1.0 indicate the degree to which the MCS depends on low-probability
   * tautomeric forms at the configured {@link ChemOptions#pH} (default 7.4).
   *
   * <pre>{@code
   * ChemOptions c = ChemOptions.tautomerProfile();
   * SMSD smsd = new SMSD(ketoMol, enolMol, c);
   * Map<Integer,Integer> mcs = smsd.findMCS();
   * double conf = smsd.getTautomerConfidence(); // e.g. 0.97
   * }</pre>
   *
   * @return confidence score; always {@code 1.0} when {@code tautomerAware=false}
   */
  public double getTautomerConfidence() { return tautomerConfidence; }

  // ---- Similarity ----

  /**
   * Fast upper bound on Tanimoto atom similarity using atom-label frequency overlap.
   *
   * <p>Runs in O(V + E) time. Useful for pre-filtering molecule pairs in batch scenarios
   * before running expensive MCS computation.
   *
   * <pre>{@code
   * double ub = smsd.similarityUpperBound();
   * if (ub >= 0.5) {
   *     Map<Integer, Integer> mcs = smsd.findMCS(); // only compute MCS if promising
   * }
   * }</pre>
   *
   * @return upper bound on Tanimoto similarity in the range [0.0, 1.0]
   * @throws UnsupportedOperationException if this instance was created with a SMARTS query
   */
  public double similarityUpperBound() {
    requireMoleculeQuery("similarityUpperBound");
    return SearchEngine.similarityUpperBound(query, target, chem);
  }

  // ---- N-MCS (Multi-molecule) ----

  /**
   * Find the Maximum Common Substructure across multiple molecules with a coverage threshold.
   *
   * <pre>{@code
   * List<IAtomContainer> mols = Arrays.asList(mol1, mol2, mol3);
   * Map<Integer, Integer> nmcs = SMSD.findNMCS(mols, new ChemOptions(), 0.8, 10000);
   * System.out.println("Common core: " + nmcs.size() + " atoms");
   * }</pre>
   *
   * @param molecules list of molecules (at least 2)
   * @param chem      chemical matching options
   * @param threshold fraction of molecules that must contain the MCS (0.0 to 1.0)
   * @param timeoutMs timeout per pairwise MCS computation in milliseconds
   * @return identity mapping for the common core atom indices, or empty if no common core
   */
  public static Map<Integer, Integer> findNMCS(
      List<IAtomContainer> molecules, ChemOptions chem, double threshold, long timeoutMs) {
    if (molecules == null || molecules.isEmpty())
      throw new IllegalArgumentException("molecules must not be null or empty");
    if (threshold < 0.0 || threshold > 1.0)
      throw new IllegalArgumentException("threshold must be in [0, 1]");
    return SearchEngine.findNMCS(molecules, chem, threshold, timeoutMs);
  }

  /**
   * Find the N-molecule MCS and return the actual molecule representing the common core.
   *
   * <pre>{@code
   * IAtomContainer core = SMSD.findNMCSMolecule(mols, new ChemOptions(), 1.0, 10000);
   * if (core != null) {
   *     System.out.println("Core has " + core.getAtomCount() + " atoms");
   * }
   * }</pre>
   *
   * @param molecules list of molecules (at least 2)
   * @param chem      chemical matching options
   * @param threshold fraction of molecules that must contain the MCS (0.0 to 1.0)
   * @param timeoutMs timeout per pairwise MCS computation in milliseconds
   * @return the common core as an {@link IAtomContainer}; empty (zero atoms) if no common core
   */
  public static IAtomContainer findNMCSMolecule(
      List<IAtomContainer> molecules, ChemOptions chem, double threshold, long timeoutMs) {
    if (molecules == null || molecules.isEmpty())
      throw new IllegalArgumentException("molecules must not be null or empty");
    if (threshold < 0.0 || threshold > 1.0)
      throw new IllegalArgumentException("threshold must be in [0, 1]");
    return SearchEngine.findNMCSMolecule(molecules, chem, threshold, timeoutMs);
  }

  // ---- R-Group Decomposition ----

  /**
   * Decompose molecules into a core scaffold and R-groups.
   *
   * <pre>{@code
   * List<Map<String, IAtomContainer>> decomp =
   *     SMSD.decomposeRGroups(core, molecules, new ChemOptions(), 5000);
   * for (Map<String, IAtomContainer> d : decomp) {
   *     System.out.println("Core: " + d.get("core").getAtomCount());
   *     System.out.println("R1: " + d.getOrDefault("R1", null));
   * }
   * }</pre>
   *
   * @param core      the core scaffold molecule
   * @param molecules list of molecules to decompose
   * @param chem      chemical matching options
   * @param timeoutMs timeout for substructure matching in milliseconds
   * @return list of decomposition maps; each contains "core" and "R1", "R2", etc.
   */
  public static List<Map<String, IAtomContainer>> decomposeRGroups(
      IAtomContainer core, List<IAtomContainer> molecules, ChemOptions chem, long timeoutMs) {
    return SearchEngine.decomposeRGroups(core, molecules, chem, timeoutMs);
  }

  // ---- Fingerprint Pre-Screening ----

  /**
   * Compute a path-based fingerprint for pre-screening substructure candidates.
   *
   * <pre>{@code
   * long[] qFp = SMSD.pathFingerprint(query, 7, 1024);
   * long[] tFp = SMSD.pathFingerprint(target, 7, 1024);
   * if (SMSD.fingerprintSubset(qFp, tFp)) {
   *     // query might be a substructure of target; run full match
   * }
   * }</pre>
   *
   * @param mol        the molecule to fingerprint
   * @param pathLength maximum path length to enumerate
   * @param fpSize     fingerprint size in bits (should be a power of 2)
   * @return the fingerprint as a long array
   */
  public static long[] pathFingerprint(IAtomContainer mol, int pathLength, int fpSize) {
    if (mol == null) throw new NullPointerException("mol");
    if (pathLength <= 0) throw new IllegalArgumentException("pathLength must be > 0");
    if (fpSize <= 0) throw new IllegalArgumentException("fpSize must be > 0");
    return SearchEngine.pathFingerprint(mol, pathLength, fpSize);
  }

  /**
   * Check if a query fingerprint is a subset of a target fingerprint.
   *
   * <p>A subset relationship means the query could be a substructure of the target.
   * This is a necessary but not sufficient condition.
   *
   * <pre>{@code
   * boolean canMatch = SMSD.fingerprintSubset(queryFp, targetFp);
   * }</pre>
   *
   * @param query  the query fingerprint
   * @param target the target fingerprint
   * @return {@code true} if every bit set in the query is also set in the target
   */
  public static boolean fingerprintSubset(long[] query, long[] target) {
    if (query == null) throw new NullPointerException("query");
    if (target == null) throw new NullPointerException("target");
    return SearchEngine.fingerprintSubset(query, target);
  }

  // ---- MCS-Path Fingerprint ----

  /**
   * Compute an MCS-aware path fingerprint from a molecule.
   *
   * <p>Unlike simple path fingerprints, this uses chemical matching options to ensure
   * paths respect atom and bond compatibility rules.
   *
   * <pre>{@code
   * long[] fp = SMSD.mcsFingerprint(mol, new ChemOptions(), 7, 2048);
   * }</pre>
   *
   * @param mol        the molecule to fingerprint
   * @param chem       chemical matching options for path compatibility
   * @param pathLength maximum path length to enumerate
   * @param fpSize     fingerprint size in bits
   * @return the MCS-aware fingerprint as a long array
   */
  public static long[] mcsFingerprint(IAtomContainer mol, ChemOptions chem, int pathLength, int fpSize) {
    if (mol == null) throw new NullPointerException("mol");
    if (pathLength <= 0) throw new IllegalArgumentException("pathLength must be > 0");
    if (fpSize <= 0) throw new IllegalArgumentException("fpSize must be > 0");
    return SearchEngine.mcsFingerprint(mol, chem, pathLength, fpSize);
  }

  /**
   * Compute the Tanimoto coefficient between two MCS fingerprints.
   *
   * <pre>{@code
   * double sim = SMSD.mcsFingerprintSimilarity(fp1, fp2);
   * System.out.println("Similarity: " + sim); // 0.0 to 1.0
   * }</pre>
   *
   * @param fp1 first fingerprint
   * @param fp2 second fingerprint
   * @return Tanimoto coefficient in the range [0.0, 1.0]
   */
  public static double mcsFingerprintSimilarity(long[] fp1, long[] fp2) {
    return SearchEngine.mcsFingerprintSimilarity(fp1, fp2);
  }

  // ---- Scaffold MCS (Murcko) ----

  /**
   * Extract the Murcko scaffold (ring systems + linkers) from a molecule.
   *
   * <pre>{@code
   * IAtomContainer scaffold = SMSD.murckoScaffold(atorvastatin);
   * System.out.println("Scaffold atoms: " + scaffold.getAtomCount());
   * }</pre>
   *
   * @param mol the molecule to extract the scaffold from
   * @return the Murcko scaffold as an {@link IAtomContainer}
   */
  public static IAtomContainer murckoScaffold(IAtomContainer mol) {
    return SearchEngine.murckoScaffold(mol);
  }

  /**
   * Find the MCS between Murcko scaffolds of two molecules.
   *
   * <pre>{@code
   * SearchEngine.McsOptions mcsOpts = new SearchEngine.McsOptions();
   * mcsOpts.timeoutMillis = 10000;
   * Map<Integer, Integer> scaffoldMcs =
   *     SMSD.findScaffoldMCS(mol1, mol2, new ChemOptions(), mcsOpts);
   * }</pre>
   *
   * @param m1 the first molecule
   * @param m2 the second molecule
   * @param C  chemical matching options
   * @param M  MCS options (timeout, induced, connected, etc.)
   * @return mapping from scaffold atom indices (first molecule) to scaffold atom indices (second)
   */
  public static Map<Integer, Integer> findScaffoldMCS(
      IAtomContainer m1, IAtomContainer m2, ChemOptions C, SearchEngine.McsOptions M) {
    return SearchEngine.findScaffoldMCS(m1, m2, C, M);
  }

  // ---- Atom-Atom Mapping for Reactions ----

  /**
   * Compute atom-atom mapping between reactants and products via MCS.
   *
   * <pre>{@code
   * Map<Integer, Integer> aam =
   *     SMSD.mapReaction(reactants, products, new ChemOptions(), 10000);
   * for (var e : aam.entrySet()) {
   *     System.out.println("Reactant atom " + e.getKey() + " -> Product atom " + e.getValue());
   * }
   * }</pre>
   *
   * @param reactants the combined reactant molecule
   * @param products  the combined product molecule
   * @param chem      chemical matching options
   * @param timeoutMs timeout in milliseconds
   * @return mapping from reactant atom indices to product atom indices
   */
  public static Map<Integer, Integer> mapReaction(
      IAtomContainer reactants, IAtomContainer products, ChemOptions chem, long timeoutMs) {
    return SearchEngine.mapReaction(reactants, products, chem, timeoutMs);
  }

  // ---- Accessors ----

  /**
   * Return the standardised query molecule.
   *
   * @return the query molecule (never {@code null})
   * @throws UnsupportedOperationException if this instance was created with a SMARTS query
   */
  public IAtomContainer getQuery() {
    if (querySmarts != null)
      throw new UnsupportedOperationException("getQuery is not supported for SMARTS queries.");
    return query;
  }

  /**
   * Return the standardised target molecule.
   *
   * @return the target molecule (never {@code null})
   */
  public IAtomContainer getTarget() { return target; }

  // ---- Internal ----

  private static IAtomContainer standardiseSafe(IAtomContainer mol) {
    try { return Standardiser.standardise(mol, Standardiser.TautomerMode.NONE); }
    catch (Exception e) { return mol; }
  }

  private void requireMoleculeQuery(String method) {
    if (querySmarts != null)
      throw new UnsupportedOperationException(method + " is not supported for SMARTS queries.");
  }
}
