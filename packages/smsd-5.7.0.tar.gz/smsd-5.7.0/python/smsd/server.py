"""
SMSD Python web server — identical REST API to the Java/Javalin server.

Start with:
    python -m smsd.server [--port 7070] [--host 127.0.0.1]
or (if installed as a package with the web extras):
    smsd-web [--port 7070]

Required:
    smsd   (this package)
    flask  (pip install flask)

Optional — enables 2D molecule depiction with atom highlighting:
    rdkit  (pip install rdkit)
    Pillow (pip install Pillow)  — needed for PNG/PDF export

Without rdkit the server still works fully; SVG fields contain a small
placeholder that tells the user to install rdkit for rendered structures.
"""

from __future__ import annotations

import argparse
import io
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Set

# ---------------------------------------------------------------------------
# Flask — hard requirement for this module
# ---------------------------------------------------------------------------
try:
    from flask import Flask, Response, jsonify, request, send_from_directory
except ImportError:
    sys.exit(
        "Flask is required to run the SMSD web server.\n"
        "Install it with:  pip install flask\n"
        "Or install the web extras:  pip install 'smsd[web]'"
    )

# ---------------------------------------------------------------------------
# SMSD Python bindings
# ---------------------------------------------------------------------------
import smsd as _smsd_pkg
from smsd import (
    ChemOptions,
    McsOptions,
    find_mcs,
    is_substructure,
    mcs,
    parse_smiles,
    substructure_search,
)

# ---------------------------------------------------------------------------
# Optional RDKit — used for 2D depiction and molecular properties
# ---------------------------------------------------------------------------
try:
    from rdkit import Chem
    from rdkit.Chem import Descriptors, Draw, rdMolDescriptors
    from rdkit.Chem import AllChem as _AllChem
    from rdkit.Chem.Draw import rdMolDraw2D

    HAS_RDKIT = True
    _RDKIT_VERSION = Chem.rdBase.rdkitVersion  # type: ignore[attr-defined]
except ImportError:
    HAS_RDKIT = False
    _RDKIT_VERSION = None

# ---------------------------------------------------------------------------
# Static file resolution
# ---------------------------------------------------------------------------

def _find_static_dir() -> Optional[Path]:
    """
    Locate the shared static assets (index.html, app.js, style.css …).

    Search order:
    1. python/smsd/static/  — present in installed packages
    2. web/src/main/resources/static/ — dev checkout, relative to this file
    """
    here = Path(__file__).resolve().parent

    # Installed package puts static/ alongside this module
    pkg_static = here / "static"
    if pkg_static.is_dir() and (pkg_static / "index.html").exists():
        return pkg_static

    # Dev checkout layout:  python/smsd/server.py  →  ../../web/src/main/resources/static
    dev_static = here.parent.parent / "web" / "src" / "main" / "resources" / "static"
    if dev_static.is_dir() and (dev_static / "index.html").exists():
        return dev_static

    return None


STATIC_DIR: Optional[Path] = _find_static_dir()

# ---------------------------------------------------------------------------
# Flask application
# ---------------------------------------------------------------------------

app = Flask(__name__)

# ---------------------------------------------------------------------------
# Helpers — properties and depiction
# ---------------------------------------------------------------------------

_ELEMENT_MASS: Dict[int, float] = {
    1: 1.00794, 5: 10.811, 6: 12.011, 7: 14.007, 8: 15.999,
    9: 18.998, 14: 28.086, 15: 30.974, 16: 32.065, 17: 35.453,
    33: 74.922, 34: 78.96, 35: 79.904, 52: 127.60, 53: 126.904,
}
_ELEMENT_SYM: Dict[int, str] = {
    1: "H", 5: "B", 6: "C", 7: "N", 8: "O", 9: "F",
    14: "Si", 15: "P", 16: "S", 17: "Cl", 33: "As", 34: "Se",
    35: "Br", 52: "Te", 53: "I",
}


def _properties_from_rdkit(smiles: str) -> Optional[dict]:
    """Return molecular properties dict using RDKit."""
    if not HAS_RDKIT:
        return None
    mol = Chem.MolFromSmiles(smiles)  # type: ignore[union-attr]
    if mol is None:
        return None
    _AllChem.Compute2DCoords(mol)
    return {
        "canonical": Chem.MolToSmiles(mol, isomericSmiles=True),
        "formula": rdMolDescriptors.CalcMolFormula(mol),
        "mass": round(Descriptors.ExactMolWt(mol), 4),
        "atomCount": mol.GetNumAtoms(),
        "bondCount": mol.GetNumBonds(),
        "ringAtoms": sum(1 for a in mol.GetAtoms() if a.IsInRing()),
        "aromaticAtoms": sum(1 for a in mol.GetAtoms() if a.GetIsAromatic()),
    }


def _properties_from_smsd(smiles: str) -> dict:
    """Minimal properties using only the smsd MolGraph (no RDKit)."""
    try:
        mol = parse_smiles(smiles)
        n = getattr(mol, "n", None) or getattr(mol, "atom_count", None) or 0
    except Exception:
        n = 0
    return {
        "canonical": smiles,
        "atomCount": n,
        "formula": "?",
        "mass": 0.0,
        "bondCount": 0,
        "ringAtoms": 0,
        "aromaticAtoms": 0,
    }


def _placeholder_svg(smiles: str, width: int = 350, height: int = 250) -> str:
    """Plain SVG shown when RDKit is not installed."""
    label = (smiles[:55] + "…") if len(smiles) > 55 else smiles
    # Escape XML special characters
    label = label.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}">'
        f'<rect width="100%" height="100%" fill="#f8fafc" rx="8"/>'
        f'<text x="50%" y="42%" text-anchor="middle" dominant-baseline="middle" '
        f'font-family="ui-sans-serif,system-ui,sans-serif" font-size="12" fill="#94a3b8">'
        f'Install rdkit for 2D structure</text>'
        f'<text x="50%" y="60%" text-anchor="middle" dominant-baseline="middle" '
        f'font-family="ui-monospace,monospace" font-size="11" fill="#475569">'
        f'{label}</text>'
        f'</svg>'
    )


_COLORS = {
    "query":  (0.16, 0.38, 1.00),   # blue
    "target": (0.84, 0.00, 0.00),   # red
    "mcs":    (0.00, 0.59, 0.24),   # green
}


def _depict_svg(
    smiles: str,
    highlight: Optional[List[int]] = None,
    color: str = "query",
    width: int = 350,
    height: int = 250,
) -> str:
    """Render a molecule as SVG, with optional atom highlighting."""
    if not HAS_RDKIT:
        return _placeholder_svg(smiles, width, height)

    mol = Chem.MolFromSmiles(smiles)  # type: ignore[union-attr]
    if mol is None:
        return _placeholder_svg(smiles, width, height)

    _AllChem.Compute2DCoords(mol)
    drawer = rdMolDraw2D.MolDraw2DSVG(width, height)
    drawer.drawOptions().addAtomIndices = True  # type: ignore[attr-defined]

    if highlight:
        ha = list(set(highlight))
        c = _COLORS.get(color, _COLORS["query"])
        atom_cols = {i: c for i in ha}
        ha_set = set(ha)
        h_bonds: List[int] = []
        bond_cols: Dict[int, tuple] = {}
        for bond in mol.GetBonds():
            if bond.GetBeginAtomIdx() in ha_set and bond.GetEndAtomIdx() in ha_set:
                h_bonds.append(bond.GetIdx())
                bond_cols[bond.GetIdx()] = c
        drawer.DrawMolecule(
            mol,
            highlightAtoms=ha,
            highlightAtomColors=atom_cols,
            highlightBonds=h_bonds,
            highlightBondColors=bond_cols,
        )
    else:
        drawer.DrawMolecule(mol)

    drawer.FinishDrawing()
    return drawer.GetDrawingText()


def _tanimoto(q_n: int, t_n: int, common: int) -> float:
    denom = q_n + t_n - common
    return round(common / denom, 4) if denom > 0 else 0.0


def _mol_n(smiles: str) -> int:
    """Atom count — from RDKit if available, smsd MolGraph otherwise."""
    if HAS_RDKIT:
        mol = Chem.MolFromSmiles(smiles)  # type: ignore[union-attr]
        return mol.GetNumAtoms() if mol is not None else 0
    try:
        mg = parse_smiles(smiles)
        return int(getattr(mg, "n", 0) or getattr(mg, "atom_count", 0))
    except Exception:
        return 0


# ---------------------------------------------------------------------------
# Routes — static UI
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    if STATIC_DIR is None:
        return (
            "<h2>SMSD Python web server is running — but the static UI files were not found.</h2>"
            "<p>Clone the full repo so <code>web/src/main/resources/static/</code> is present, "
            "or install a package that bundles <code>smsd/static/</code>.</p>"
            "<p>The REST API is fully available at <code>/api/…</code></p>",
            200,
        )
    return send_from_directory(str(STATIC_DIR), "index.html")


@app.route("/static/<path:filename>")
def static_files(filename: str):
    if STATIC_DIR is None:
        return jsonify({"error": "static directory not found"}), 404
    return send_from_directory(str(STATIC_DIR), filename)


@app.route("/manifest.json")
def manifest():
    if STATIC_DIR is None:
        return jsonify({}), 404
    return send_from_directory(str(STATIC_DIR), "manifest.json")


# ---------------------------------------------------------------------------
# Routes — REST API  (same contract as ApiHandler.java)
# ---------------------------------------------------------------------------

@app.route("/api/validate", methods=["POST"])
def api_validate():
    body = request.get_json(force=True) or {}
    smiles = (body.get("smiles") or "").strip()
    if not smiles:
        return jsonify({"error": "Missing 'smiles' field"}), 400
    try:
        parse_smiles(smiles)  # raises on invalid SMILES
    except Exception as exc:
        return jsonify({"valid": False, "error": str(exc)})

    props = _properties_from_rdkit(smiles) or _properties_from_smsd(smiles)
    svg = _depict_svg(smiles, width=350, height=250)
    return jsonify({"valid": True, **props, "svg": svg})


@app.route("/api/depict")
def api_depict():
    smiles = (request.args.get("smiles") or "").strip()
    if not smiles:
        return Response(_placeholder_svg("", 600, 400), mimetype="image/svg+xml")

    width = int(request.args.get("width", 600))
    height = int(request.args.get("height", 400))
    hl_param = request.args.get("highlight", "")
    color = request.args.get("color", "query")

    atoms: Optional[List[int]] = None
    if hl_param:
        atoms = [int(x) for x in hl_param.split(",") if x.strip().lstrip("-").isdigit()]

    svg = _depict_svg(smiles, atoms, color, width, height)
    return Response(svg, mimetype="image/svg+xml")


@app.route("/api/sub", methods=["POST"])
def api_sub():
    body = request.get_json(force=True) or {}
    q_smi = (body.get("query") or "").strip()
    t_smi = (body.get("target") or "").strip()
    timeout_ms = int(body.get("timeout", 10000))
    if not q_smi or not t_smi:
        return jsonify({"error": "Both 'query' and 'target' SMILES are required"}), 400

    try:
        t0 = time.perf_counter()
        pairs = substructure_search(q_smi, t_smi, timeout_ms=timeout_ms)
        elapsed = round((time.perf_counter() - t0) * 1000, 1)

        common = len(pairs)
        q_n = _mol_n(q_smi)
        t_n = _mol_n(t_smi)
        q_hl = [p[0] for p in pairs]
        t_hl = [p[1] for p in pairs]

        return jsonify({
            "exists": common > 0,
            "mappingCount": 1 if common > 0 else 0,
            "timeMs": elapsed,
            "tanimoto": _tanimoto(q_n, t_n, common),
            "pairs": [[p[0], p[1]] for p in pairs],
            "querySvg": _depict_svg(q_smi, q_hl, "query"),
            "targetSvg": _depict_svg(t_smi, t_hl, "target"),
        })
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@app.route("/api/mcs", methods=["POST"])
def api_mcs():
    body = request.get_json(force=True) or {}
    q_smi = (body.get("query") or "").strip()
    t_smi = (body.get("target") or "").strip()
    timeout_ms = int(body.get("timeout", 10000))
    if not q_smi or not t_smi:
        return jsonify({"error": "Both 'query' and 'target' SMILES are required"}), 400

    try:
        t0 = time.perf_counter()
        mapping: Dict[int, int] = mcs(q_smi, t_smi, timeout_ms=timeout_ms)
        elapsed = round((time.perf_counter() - t0) * 1000, 1)

        common = len(mapping)
        q_n = _mol_n(q_smi)
        t_n = _mol_n(t_smi)
        q_hl = list(mapping.keys())
        t_hl = list(mapping.values())

        return jsonify({
            "mcsSize": common,
            "timeMs": elapsed,
            "tanimoto": _tanimoto(q_n, t_n, common),
            "pairs": [[k, v] for k, v in mapping.items()],
            "querySvg": _depict_svg(q_smi, q_hl, "mcs"),
            "targetSvg": _depict_svg(t_smi, t_hl, "mcs"),
        })
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@app.route("/api/export", methods=["POST"])
def api_export():
    body = request.get_json(force=True) or {}
    q_smi = (body.get("query") or "").strip()
    t_smi = (body.get("target") or "").strip()
    fmt = (body.get("format") or "smiles").lower()
    mode = (body.get("mode") or "mcs").lower()
    width = int(body.get("width", 800))
    height = int(body.get("height", 600))

    try:
        if mode == "sub":
            pairs = substructure_search(q_smi, t_smi)
            mapping = dict(pairs)
            color = "target"
        else:
            mapping = mcs(q_smi, t_smi)
            color = "mcs"

        common = len(mapping)
        q_n = _mol_n(q_smi)
        t_n = _mol_n(t_smi)
        tani = _tanimoto(q_n, t_n, common)

        if fmt == "smiles":
            lines = [
                f"Query:   {q_smi}",
                f"Target:  {t_smi}",
                f"Mode:    {mode.upper()}",
                f"Size:    {common}",
                f"Tanimoto:{tani:.4f}",
                "",
                "Atom mapping (query → target):",
            ]
            for k, v in sorted(mapping.items()):
                lines.append(f"  Q[{k}] → T[{v}]")
            text = "\n".join(lines) + "\n"
            return Response(
                text,
                mimetype="text/plain",
                headers={"Content-Disposition": "attachment; filename=smsd_result.txt"},
            )

        if fmt == "svg":
            t_hl = list(mapping.values())
            svg = _depict_svg(t_smi, t_hl, color, width, height)
            return Response(
                svg,
                mimetype="image/svg+xml",
                headers={"Content-Disposition": "attachment; filename=smsd_result.svg"},
            )

        if fmt in ("png", "pdf"):
            if not HAS_RDKIT:
                return jsonify({
                    "error": f"{fmt.upper()} export requires rdkit. "
                             "Install with: pip install rdkit"
                }), 422

            t_hl = list(mapping.values())
            rdmol = Chem.MolFromSmiles(t_smi)  # type: ignore[union-attr]
            if rdmol:
                _AllChem.Compute2DCoords(rdmol)
            drawer = rdMolDraw2D.MolDraw2DCairo(width, height)
            ha = list(set(t_hl))
            c = _COLORS.get(color, _COLORS["mcs"])
            atom_cols = {i: c for i in ha}
            ha_set = set(ha)
            h_bonds = [
                b.GetIdx() for b in rdmol.GetBonds()
                if b.GetBeginAtomIdx() in ha_set and b.GetEndAtomIdx() in ha_set
            ]
            bond_cols = {i: c for i in h_bonds}
            drawer.DrawMolecule(
                rdmol,
                highlightAtoms=ha,
                highlightAtomColors=atom_cols,
                highlightBonds=h_bonds,
                highlightBondColors=bond_cols,
            )
            drawer.FinishDrawing()
            data = drawer.GetDrawingText()
            mime = "image/png" if fmt == "png" else "application/pdf"
            return Response(
                data,
                mimetype=mime,
                headers={"Content-Disposition": f"attachment; filename=smsd_result.{fmt}"},
            )

        return jsonify({"error": f"Unknown format '{fmt}'. Supported: smiles, svg, png, pdf"}), 400

    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def _gpu_info() -> str:
    """Return a human-readable line describing GPU / CPU backend."""
    try:
        from smsd._smsd import gpu_is_available, gpu_device_info  # type: ignore[import]
        # deviceInfo() already includes full context ("GPU: ..." or "CPU: ...")
        return gpu_device_info()
    except (ImportError, AttributeError):
        pass
    # C++ extension not compiled with GPU bindings — report CPU count only
    import os
    ncpu = os.cpu_count() or 1
    return f"CPU: {ncpu} processors"


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="smsd-web",
        description="SMSD Python web server — same API as the Java server",
    )
    parser.add_argument("--port", type=int, default=7070, help="Port (default: 7070)")
    parser.add_argument("--host", default="127.0.0.1",
                        help="Bind address (default: 127.0.0.1; use 0.0.0.0 for LAN)")
    args = parser.parse_args()

    print("SMSD Python web server")
    print(f"  smsd     {_smsd_pkg.__version__}")
    print(f"  compute  {_gpu_info()}")
    if HAS_RDKIT:
        print(f"  rdkit    {_RDKIT_VERSION}  (2D depiction enabled)")
    else:
        print(f"  rdkit    not installed  (install for 2D depiction: pip install rdkit)")
    if STATIC_DIR:
        print(f"  static   {STATIC_DIR}")
    else:
        print(f"  static   not found (REST API available, UI missing)")
    print(f"  URL      http://{args.host}:{args.port}")
    print()

    app.run(host=args.host, port=args.port, debug=False)


if __name__ == "__main__":
    main()
