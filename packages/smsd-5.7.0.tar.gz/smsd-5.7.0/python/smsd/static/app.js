/* ============================================================
   SMSD 4.0.0 — Enhanced Frontend Application
   Pure vanilla JS, no frameworks, no dependencies
   ============================================================ */

const API = '';  // Same origin

// ---- State ----
let lastResult = null;
let currentMode = 'sub';

// ============================================================
//  THEME
// ============================================================

function initTheme() {
  const saved = localStorage.getItem('smsd-theme');
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const theme = saved || (prefersDark ? 'dark' : 'light');
  document.documentElement.setAttribute('data-theme', theme);
}

function toggleTheme() {
  const html = document.documentElement;
  const current = html.getAttribute('data-theme');
  const next = current === 'dark' ? 'light' : 'dark';
  html.setAttribute('data-theme', next);
  localStorage.setItem('smsd-theme', next);
}

// ============================================================
//  TOAST NOTIFICATIONS
// ============================================================

function showToast(message, type = 'info', duration = 3500) {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;

  const icons = {
    success: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>',
    error: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',
    info: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>'
  };

  toast.innerHTML = `<span class="toast-icon">${icons[type] || icons.info}</span><span>${escapeHtml(message)}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.classList.add('exit');
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ============================================================
//  API HELPERS
// ============================================================

async function post(url, body) {
  const res = await fetch(API + url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Server error' }));
    throw new Error(err.error || `HTTP ${res.status}`);
  }
  return res.json();
}

// ============================================================
//  FORMAT DETECTION
// ============================================================

function detectFormat(input) {
  if (!input || !input.trim()) return '';
  const s = input.trim();
  // MOL / SDF file
  if (s.includes('V2000') || s.includes('V3000') || s.includes('M  END')) return 'mol';
  // SMARTS patterns (contain special chars like [#6], $, ~, etc.)
  if (/\[#\d+\]/.test(s) || /[~$!]/.test(s) && /[\[\]]/.test(s)) return 'smarts';
  // Default to SMILES
  return 'smiles';
}

function updateFormatBadge(which) {
  const input = document.getElementById(which + '-input').value;
  const badge = document.getElementById(which + '-format');
  const fmt = detectFormat(input);
  badge.textContent = fmt.toUpperCase();
  badge.className = 'format-badge ' + fmt;
  if (!fmt) badge.textContent = '';
}

// ============================================================
//  MOLECULE INPUT
// ============================================================

async function validateMol(which) {
  const input = document.getElementById(which + '-input').value.trim();
  const propsEl = document.getElementById(which + '-props');
  const svgEl = document.getElementById(which + '-svg');

  if (!input) {
    propsEl.innerHTML = '<span class="prop-tag error">Enter a molecule</span>';
    svgEl.innerHTML = '';
    return;
  }

  propsEl.innerHTML = '<div class="spinner-overlay"><div class="spinner-ring"></div>Validating...</div>';
  svgEl.innerHTML = '';

  try {
    const data = await post('/api/validate', { smiles: input });
    if (data.valid) {
      propsEl.innerHTML = [
        tag(data.formula),
        tag(data.mass + ' Da'),
        tag(data.atomCount + ' atoms'),
        tag(data.bondCount + ' bonds'),
        tag(data.ringAtoms + ' ring'),
        tag(data.aromaticAtoms + ' arom'),
      ].join('');
      svgEl.innerHTML = data.svg;
      showToast(`${which.charAt(0).toUpperCase() + which.slice(1)} molecule validated`, 'success', 2000);
    } else {
      propsEl.innerHTML = `<span class="prop-tag error">${escapeHtml(data.error)}</span>`;
      svgEl.innerHTML = '';
      showToast(data.error, 'error');
    }
  } catch (e) {
    propsEl.innerHTML = '<span class="prop-tag error">Server error</span>';
    svgEl.innerHTML = '';
    showToast('Validation failed: ' + e.message, 'error');
  }
}

function tag(text) {
  return `<span class="prop-tag">${escapeHtml(text)}</span>`;
}

function clearPanel(which) {
  document.getElementById(which + '-input').value = '';
  document.getElementById(which + '-props').innerHTML = '';
  document.getElementById(which + '-svg').innerHTML = '';
  document.getElementById(which + '-format').textContent = '';
  document.getElementById(which + '-format').className = 'format-badge';
}

function swapMolecules() {
  const qi = document.getElementById('query-input');
  const ti = document.getElementById('target-input');
  const tmp = qi.value;
  qi.value = ti.value;
  ti.value = tmp;

  // Swap props
  const qp = document.getElementById('query-props');
  const tp = document.getElementById('target-props');
  const tmpH = qp.innerHTML;
  qp.innerHTML = tp.innerHTML;
  tp.innerHTML = tmpH;

  // Swap SVGs
  const qs = document.getElementById('query-svg');
  const ts = document.getElementById('target-svg');
  const tmpS = qs.innerHTML;
  qs.innerHTML = ts.innerHTML;
  ts.innerHTML = tmpS;

  // Update format badges
  updateFormatBadge('query');
  updateFormatBadge('target');

  showToast('Molecules swapped', 'info', 1500);
}

async function pasteFromClipboard(which) {
  try {
    const text = await navigator.clipboard.readText();
    if (text) {
      document.getElementById(which + '-input').value = text.trim();
      updateFormatBadge(which);
      showToast('Pasted from clipboard', 'success', 1500);
    }
  } catch (e) {
    showToast('Clipboard access denied', 'error');
  }
}

// ============================================================
//  EXAMPLES DROPDOWN
// ============================================================

function initExamplesDropdown() {
  const btn = document.getElementById('examples-btn');
  const menu = document.getElementById('examples-menu');

  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    menu.classList.toggle('open');
  });

  document.addEventListener('click', () => {
    menu.classList.remove('open');
  });

  menu.querySelectorAll('.dropdown-item').forEach(item => {
    item.addEventListener('click', () => {
      const q = item.dataset.query;
      const t = item.dataset.target;
      document.getElementById('query-input').value = q;
      document.getElementById('target-input').value = t;
      updateFormatBadge('query');
      updateFormatBadge('target');
      menu.classList.remove('open');
      showToast('Example loaded: ' + item.textContent.trim(), 'info', 2000);

      // Auto-validate both
      validateMol('query');
      validateMol('target');
    });
  });
}

// ============================================================
//  OPTIONS
// ============================================================

function initModeSelector() {
  const container = document.getElementById('mode-selector');
  container.querySelectorAll('.seg-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      container.querySelectorAll('.seg-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentMode = btn.dataset.value;
    });
  });
}

function initBondSelector() {
  const container = document.getElementById('bond-selector');
  if (!container) return;
  container.querySelectorAll('.seg-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      container.querySelectorAll('.seg-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });
}

function toggleAdvanced() {
  const adv = document.getElementById('advanced-options');
  const chevron = document.querySelector('.chevron-icon');
  if (adv.style.display === 'none') {
    adv.style.display = 'block';
    chevron.classList.add('open');
  } else {
    adv.style.display = 'none';
    chevron.classList.remove('open');
  }
}

function initTimeoutSlider() {
  const slider = document.getElementById('opt-timeout');
  const display = document.getElementById('timeout-display');
  if (!slider) return;
  slider.addEventListener('input', () => {
    display.textContent = (slider.value / 1000).toFixed(1) + 's';
  });
}

// ============================================================
//  TABS
// ============================================================

function initTabs() {
  document.querySelectorAll('#result-tabs .tab').forEach(tab => {
    tab.addEventListener('click', () => {
      // Deactivate all
      document.querySelectorAll('#result-tabs .tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      // Activate selected
      tab.classList.add('active');
      const panel = document.getElementById('tab-' + tab.dataset.tab);
      if (panel) panel.classList.add('active');
    });
  });
}

// ============================================================
//  COMPARE / MATCH
// ============================================================

async function runMatch() {
  const query = document.getElementById('query-input').value.trim();
  const target = document.getElementById('target-input').value.trim();
  const resultsEl = document.getElementById('results');
  const btn = document.getElementById('compare-btn');

  if (!query || !target) {
    showToast('Enter both query and target molecules', 'error');
    return;
  }

  // Show loading
  btn.disabled = true;
  btn.innerHTML = '<div class="spinner"></div> Computing...';
  resultsEl.style.display = 'block';
  document.getElementById('result-hero').innerHTML = '<div class="spinner-overlay"><div class="spinner-ring"></div>Computing match...</div>';
  document.getElementById('time-banner').style.display = 'none';
  clearResultTabs();

  // Scroll to results
  resultsEl.scrollIntoView({ behavior: 'smooth', block: 'start' });

  // Get options
  const timeout = parseInt(document.getElementById('opt-timeout').value) || 15000;
  const connected = document.getElementById('opt-connected').checked;
  const induced = document.getElementById('opt-induced').checked;

  try {
    const body = { query, target, timeout, connected, induced };
    const data = await post('/api/' + currentMode, body);

    if (data.error) {
      document.getElementById('result-hero').innerHTML = `<h2 style="color:var(--danger)">${escapeHtml(data.error)}</h2>`;
      btn.disabled = false;
      btn.innerHTML = svgPlay() + ' Compare';
      showToast('Error: ' + data.error, 'error');
      return;
    }

    lastResult = data;
    lastResult._mode = currentMode;
    lastResult._query = query;
    lastResult._target = target;

    renderResults(data);
    showToast('Comparison complete', 'success', 2500);
  } catch (e) {
    document.getElementById('result-hero').innerHTML = `<h2 style="color:var(--danger)">Error: ${escapeHtml(e.message)}</h2>`;
    showToast('Computation failed: ' + e.message, 'error');
  }

  btn.disabled = false;
  btn.innerHTML = svgPlay() + ' Compare';
}

function svgPlay() {
  return '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="5 3 19 12 5 21 5 3"/></svg>';
}

function clearResultTabs() {
  document.getElementById('summary-grid').innerHTML = '';
  document.getElementById('mapping-table-container').innerHTML = '';
  document.getElementById('result-query-svg').innerHTML = '';
  document.getElementById('result-target-svg').innerHTML = '';
  // Reset to summary tab
  document.querySelectorAll('#result-tabs .tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  document.querySelector('#result-tabs .tab[data-tab="summary"]').classList.add('active');
  document.getElementById('tab-summary').classList.add('active');
}

function renderResults(data) {
  const mode = currentMode;

  // Time banner
  if (data.timeMs !== undefined) {
    const banner = document.getElementById('time-banner');
    banner.style.display = 'inline-flex';
    document.getElementById('time-value').textContent =
      data.timeMs < 1000 ? data.timeMs + ' ms' : (data.timeMs / 1000).toFixed(2) + ' s';
  }

  // Hero title + stats
  let title = '';
  if (mode === 'sub') {
    title = data.exists ? 'Substructure Found' : 'No Substructure Match';
  } else {
    title = `MCS: ${data.mcsSize} atoms in common`;
  }

  let statsHtml = '';
  if (data.tanimoto !== undefined) {
    const pct = (data.tanimoto * 100).toFixed(1);
    const cls = data.tanimoto >= 0.7 ? 'green' : data.tanimoto >= 0.3 ? 'orange' : 'muted';
    statsHtml += `<span class="stat-chip ${cls}">Tanimoto: ${pct}%</span>`;
  }
  if (data.mappingCount !== undefined) {
    statsHtml += `<span class="stat-chip blue">${data.mappingCount} mapping${data.mappingCount !== 1 ? 's' : ''}</span>`;
  }
  if (data.mcsSize !== undefined) {
    statsHtml += `<span class="stat-chip blue">${data.mcsSize} MCS atoms</span>`;
  }

  document.getElementById('result-hero').innerHTML =
    `<h2 id="result-title">${escapeHtml(title)}</h2><div id="result-stats" class="result-stats">${statsHtml}</div>`;

  // Summary tab
  renderSummary(data);

  // Mapping tab
  renderMapping(data);

  // Structures tab
  if (data.querySvg) document.getElementById('result-query-svg').innerHTML = data.querySvg;
  if (data.targetSvg) document.getElementById('result-target-svg').innerHTML = data.targetSvg;
}

function renderSummary(data) {
  const grid = document.getElementById('summary-grid');
  const cards = [];

  if (data.tanimoto !== undefined) {
    const pct = (data.tanimoto * 100).toFixed(1);
    cards.push(summaryCard(pct + '%', 'Tanimoto Similarity', data.tanimoto >= 0.5 ? 'green' : 'orange'));
  }

  if (data.mcsSize !== undefined) {
    cards.push(summaryCard(data.mcsSize, 'MCS Size (atoms)', 'blue'));
  }

  if (data.mappingCount !== undefined) {
    cards.push(summaryCard(data.mappingCount, 'Mappings Found', 'accent'));
  }

  if (data.timeMs !== undefined) {
    const timeStr = data.timeMs < 1000 ? data.timeMs + ' ms' : (data.timeMs / 1000).toFixed(2) + ' s';
    cards.push(summaryCard(timeStr, 'Computation Time', 'blue'));
  }

  if (currentMode === 'sub' && data.exists !== undefined) {
    cards.push(summaryCard(data.exists ? 'Yes' : 'No', 'Substructure Match', data.exists ? 'green' : 'orange'));
  }

  if (data.pairs) {
    cards.push(summaryCard(data.pairs.length, 'Atom Pairs', 'accent'));
  }

  grid.innerHTML = cards.join('');
}

function summaryCard(value, label, colorClass) {
  return `<div class="summary-card">
    <div class="summary-value ${colorClass}">${escapeHtml(String(value))}</div>
    <div class="summary-label">${escapeHtml(label)}</div>
  </div>`;
}

function renderMapping(data) {
  const container = document.getElementById('mapping-table-container');
  if (!data.pairs || data.pairs.length === 0) {
    container.innerHTML = '<p style="text-align:center;color:var(--text-tertiary);padding:2rem;">No atom mappings found</p>';
    return;
  }

  let html = '<table><thead><tr><th>#</th><th>Query Atom</th><th></th><th>Target Atom</th></tr></thead><tbody>';
  data.pairs.forEach((p, i) => {
    html += `<tr>
      <td style="color:var(--text-tertiary)">${i + 1}</td>
      <td><span class="atom-badge query">${p[0]}</span></td>
      <td class="arrow-cell">&rarr;</td>
      <td><span class="atom-badge target">${p[1]}</span></td>
    </tr>`;
  });
  html += '</tbody></table>';
  container.innerHTML = html;
}

// ============================================================
//  EXPORT
// ============================================================

async function exportResult(format) {
  const query = document.getElementById('query-input').value.trim();
  const target = document.getElementById('target-input').value.trim();
  if (!query || !target) {
    showToast('No molecules to export', 'error');
    return;
  }

  // JSON export is client-side only
  if (format === 'json') {
    if (!lastResult) {
      showToast('Run a comparison first', 'error');
      return;
    }
    const blob = new Blob([JSON.stringify(lastResult, null, 2)], { type: 'application/json' });
    downloadBlob(blob, 'smsd-result.json');
    showToast('JSON exported', 'success', 2000);
    return;
  }

  const extMap = { svg: 'svg', png: 'png', pdf: 'pdf', smiles: 'txt' };
  try {
    showToast('Generating ' + format.toUpperCase() + '...', 'info', 2000);
    const res = await fetch(API + '/api/export', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, target, format, mode: currentMode, width: 800, height: 600 })
    });
    if (!res.ok) throw new Error('Export failed');
    const blob = await res.blob();
    downloadBlob(blob, 'smsd-result.' + (extMap[format] || 'txt'));
    showToast(format.toUpperCase() + ' exported', 'success', 2000);
  } catch (e) {
    showToast('Export failed: ' + e.message, 'error');
  }
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

// ============================================================
//  INIT
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
  // Theme
  initTheme();
  document.getElementById('theme-toggle').addEventListener('click', toggleTheme);

  // Input listeners
  ['query', 'target'].forEach(which => {
    const input = document.getElementById(which + '-input');
    input.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        validateMol(which);
      }
    });
    input.addEventListener('input', () => updateFormatBadge(which));
  });

  // Examples
  initExamplesDropdown();

  // Options
  initModeSelector();
  initBondSelector();
  initTimeoutSlider();

  // Tabs
  initTabs();

  // Keyboard shortcut: Ctrl/Cmd+Enter to compare
  document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      runMatch();
    }
  });
});
