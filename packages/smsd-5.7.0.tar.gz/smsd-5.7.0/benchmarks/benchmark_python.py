#!/usr/bin/env python3
"""
SMSD Python (C++ pybind11) vs RDKit — Fair Python-to-Python MCS Benchmark

Both tools are called from the same Python process with identical SMILES
inputs and matching parameters. This eliminates cross-language overhead
(no subprocess, no JVM startup) and gives a like-for-like comparison.

Usage:
    pip install smsd rdkit
    python3 benchmarks/benchmark_python.py

Output:
    - benchmarks/results_python.tsv   (machine-readable)
    - stdout: formatted comparison table
"""

import platform
import statistics
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import List, Tuple

# ---------------------------------------------------------------------------
# Imports
# ---------------------------------------------------------------------------

try:
    import smsd
except ImportError:
    sys.exit("ERROR: smsd not installed. Run: pip install smsd")

try:
    from rdkit import Chem
    from rdkit.Chem import rdFMCS
except ImportError:
    sys.exit("ERROR: rdkit not installed. Run: pip install rdkit")


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

WARMUP = 3
ITERS = 20
TIMEOUT_SEC = 10

SCRIPT_DIR = Path(__file__).resolve().parent

# ---------------------------------------------------------------------------
# 20 Molecule Pairs (identical to benchmark_all.py)
# ---------------------------------------------------------------------------

VANCOMYCIN = (
    "CC1C(C(CC(O1)OC2C(C(C(OC2CO)OC3=CC4=CC5=CC(=C(C(=C5C(=C4C(=C3)O)O)[C@@H]6C(=O)"
    "NC(C(=O)NC(C(=O)NC(C(=O)NC(C(=O)NC(C(=O)NC(C7=CC(=C(C(=C7)O)OC8=C(C=C(C=C8Cl)"
    "[C@H]([C@@H](C(=O)N6)NC(=O)[C@H](CC(=O)N)NC(=O)[C@@H]9CC(=O)C(N9)=O)O)O)Cl)"
    "CC(=O)N)CC(C)C)CC1=CC=C(C=C1)OC1=CC=CC(=C1Cl)O)C(C)O)CC(C)C)C(C)O)O)O)O)N)O"
)
PEG16 = "OCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCO"

PAIRS: List[Tuple[str, str, str, str]] = [
    # (smi1, smi2, name, category)
    ("C", "CC", "methane-ethane", "Trivial"),
    ("c1ccccc1", "Cc1ccccc1", "benzene-toluene", "Small aromatic"),
    ("c1ccccc1", "Oc1ccccc1", "benzene-phenol", "Heteroatom"),
    ("CC(=O)Oc1ccccc1C(=O)O", "CC(=O)Nc1ccc(O)cc1",
     "aspirin-acetaminophen", "Drug pair"),
    ("Cn1cnc2c1c(=O)n(C)c(=O)n2C", "Cn1cnc2c1c(=O)[nH]c(=O)n2C",
     "caffeine-theophylline", "N-methyl diff"),
    ("CN1CCC23C4C1CC5=C(C2C(C=C4)O3)C=C(C=C5)O",
     "CN1CCC23C4C1CC5=C(C2C(C=C4)OC3)C=C(C=C5)O",
     "morphine-codeine", "Alkaloid"),
    ("CC(C)Cc1ccc(CC(C)C(=O)O)cc1",
     "COc1ccc2cc(CC(C)C(=O)O)ccc2c1",
     "ibuprofen-naproxen", "NSAID"),
    ("C1=NC(=C2C(=N1)N(C=N2)C3C(C(C(O3)COP(=O)(O)OP(=O)(O)OP(=O)(O)O)O)O)N",
     "C1=NC(=C2C(=N1)N(C=N2)C3C(C(C(O3)COP(=O)(O)OP(=O)(O)O)O)O)N",
     "ATP-ADP", "Nucleotide"),
    ("C1=CC(=C[N+](=C1)C2C(C(C(O2)COP(=O)([O-])OP(=O)(O)OCC3C(C(C(O3)N4C=NC5=C(N=CN=C54)N)O)O)O)O)C(=O)N",
     "C1C=CN(C=C1C(=O)N)C2C(C(C(O2)COP(=O)(O)OP(=O)(O)OCC3C(C(C(O3)N4C=NC5=C4N=CN=C5N)O)O)O)O",
     "NAD-NADH", "Cofactor"),
    ("CC(C)C1=C(C(=C(N1CCC(CC(CC(=O)O)O)O)C2=CC=C(C=C2)F)C3=CC=CC=C3)C(=O)NC4=CC=CC=C4",
     "CC(C)C1=NC(=NC(=C1C=CC(CC(CC(=O)O)O)O)C2=CC=C(C=C2)F)N(C)S(=O)(=O)C",
     "atorvastatin-rosuvastatin", "Statin"),
    ("CC1=C2C(C(=O)C3(C(CC4C(C3C(C(C2(C)C)(CC1OC(=O)C(C(C5=CC=CC=C5)NC(=O)C6=CC=CC=C6)O)O)OC(=O)C7=CC=CC=C7)(CO4)OC(=O)C)O)C)OC(=O)C",
     "CC1=C2C(C(=O)C3(C(CC4C(C3C(C(C2(C)C)(CC1OC(=O)C(C(C5=CC=CC=C5)NC(=O)OC(C)(C)C)O)O)OC(=O)C6=CC=CC=C6)(CO4)OC(=O)C)O)C)O",
     "paclitaxel-docetaxel", "Taxane"),
    ("CCC1C(C(C(C(=O)C(CC(C(C(C(C(C(=O)O1)C)OC2CC(C(C(O2)C)O)(C)OC)C)OC3C(C(CC(O3)C)N(C)C)O)(C)O)C)C)O)(C)O",
     "CCC1C(C(C(N(CC(CC(C(C(C(C(C(=O)O1)C)OC2CC(C(C(O2)C)O)(C)OC)C)OC3C(C(CC(O3)C)N(C)C)O)(C)O)C)C)C)O)(C)O",
     "erythromycin-azithromycin", "Macrolide"),
    ("C1CN2CC3=CCOC4CC(=O)N5C6C4C3CC2C61C7=CC=CC=C75",
     "COC1=CC2=C(C=CN=C2C=C1)C(C3CC4CCN3CC4C=C)O",
     "strychnine-quinine", "Alkaloid scaffold"),
    (VANCOMYCIN, VANCOMYCIN, "vancomycin-self", "Self-match large"),
    ("C1C2CC3CC1CC(C2)C3", "C1C2CC3CC1CC(C2)C3",
     "adamantane-self", "Symmetric"),
    ("C12C3C4C1C5C4C3C25", "C12C3C4C1C5C4C3C25",
     "cubane-self", "Cage"),
    ("OCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCOCCO", PEG16,
     "PEG12-PEG16", "Polymer"),
    ("c1cc2ccc3ccc4ccc5ccc6ccc1c7c2c3c4c5c67",
     "c1cc2ccc3ccc4ccc5ccc6ccc1c7c2c3c4c5c67",
     "coronene-self", "PAH"),
    ("O=c1[nH]c(N)nc2[nH]cnc12", "Oc1nc(N)nc2[nH]cnc12",
     "guanine-keto-enol", "Tautomer"),
    ("c1cc(c(c(c1)Cl)N2c3cc(cc(c3CNC2=O)c4ccc(cc4F)F)N5CCNCC5)Cl",
     "CCNc1cc(c2c(c1)N(C(=O)NC2)c3ccc(cc3)n4ccc-5ncnc5c4)c6ccnnc6",
     "rdkit-1585-pair", "Known failure"),
]


# ---------------------------------------------------------------------------
# Data class
# ---------------------------------------------------------------------------

@dataclass
class Result:
    name: str
    category: str
    smsd_best_us: float  # microseconds
    smsd_median_us: float
    smsd_mcs: int
    rdkit_best_us: float
    rdkit_median_us: float
    rdkit_mcs: int
    rdkit_timed_out: bool


# ---------------------------------------------------------------------------
# Benchmark functions
# ---------------------------------------------------------------------------

def bench_smsd(smi1: str, smi2: str) -> Tuple[List[float], int]:
    """Benchmark SMSD Python MCS. Returns (times_us, mcs_size)."""
    g1 = smsd.parse_smiles(smi1)
    g2 = smsd.parse_smiles(smi2)
    opts = smsd.ChemOptions()
    mcs_opts = smsd.McsOptions()
    mcs_opts.timeout_ms = TIMEOUT_SEC * 1000

    # Warmup
    for _ in range(WARMUP):
        smsd.find_mcs(g1, g2, opts, mcs_opts)

    # Timed
    times = []
    mcs_size = 0
    for _ in range(ITERS):
        t0 = time.perf_counter_ns()
        mapping = smsd.find_mcs(g1, g2, opts, mcs_opts)
        dt = (time.perf_counter_ns() - t0) / 1000.0  # ns -> us
        times.append(dt)
        mcs_size = len(mapping)

    return times, mcs_size


def bench_rdkit(smi1: str, smi2: str) -> Tuple[List[float], int, bool]:
    """Benchmark RDKit FindMCS. Returns (times_us, mcs_size, timed_out)."""
    mol1 = Chem.MolFromSmiles(smi1)
    mol2 = Chem.MolFromSmiles(smi2)
    if mol1 is None or mol2 is None:
        return [float("inf")] * ITERS, -1, False

    # Warmup
    for _ in range(WARMUP):
        try:
            rdFMCS.FindMCS([mol1, mol2], timeout=TIMEOUT_SEC)
        except Exception:
            pass

    # Timed
    times = []
    mcs_size = 0
    timed_out = False
    for _ in range(ITERS):
        t0 = time.perf_counter_ns()
        try:
            result = rdFMCS.FindMCS([mol1, mol2], timeout=TIMEOUT_SEC)
            mcs_size = result.numAtoms
            if result.canceled:
                timed_out = True
        except Exception:
            mcs_size = -1
        dt = (time.perf_counter_ns() - t0) / 1000.0
        times.append(dt)

    return times, mcs_size, timed_out


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    print("=" * 120)
    print("SMSD Python (C++ pybind11) vs RDKit FindMCS — Like-for-Like Benchmark")
    print(f"Platform: {platform.system()} {platform.machine()}")
    print(f"Python:   {platform.python_version()}")
    print(f"SMSD:     {smsd.__version__}")
    print(f"RDKit:    {Chem.rdBase.rdkitVersion}")
    print(f"Protocol: {WARMUP} warmup + {ITERS} measured, median reported")
    print(f"Timeout:  {TIMEOUT_SEC}s per pair")
    print("=" * 120)
    print()

    hdr = (f" # {'Pair':<30s} {'Category':<20s} "
           f"{'SMSD(us)':>10s} {'RDKit(us)':>10s} "
           f"{'S.MCS':>5s} {'R.MCS':>5s} "
           f"{'Speedup':>10s} {'MCS Quality':<15s}")
    print(hdr)
    print("-" * 120)

    results: List[Result] = []
    smsd_wins = rdkit_wins = ties = 0
    mcs_smsd_better = mcs_rdkit_better = mcs_equal = 0

    for idx, (smi1, smi2, name, category) in enumerate(PAIRS, 1):
        # --- SMSD ---
        try:
            s_times, s_mcs = bench_smsd(smi1, smi2)
            s_best = min(s_times)
            s_median = statistics.median(s_times)
        except Exception as e:
            s_best = s_median = float("inf")
            s_mcs = -1

        # --- RDKit ---
        try:
            r_times, r_mcs, r_timeout = bench_rdkit(smi1, smi2)
            r_best = min(r_times)
            r_median = statistics.median(r_times)
        except Exception as e:
            r_best = r_median = float("inf")
            r_mcs = -1
            r_timeout = False

        # --- Speedup ---
        if r_timeout:
            speedup_str = "timeout"
            smsd_wins += 1
        elif s_median == 0 or r_median == 0:
            speedup_str = "N/A"
            ties += 1
        else:
            ratio = r_median / s_median
            if ratio > 1.1:
                speedup_str = f"SMSD {ratio:.1f}x"
                smsd_wins += 1
            elif ratio < 0.9:
                speedup_str = f"RDKit {1/ratio:.1f}x"
                rdkit_wins += 1
            else:
                speedup_str = "~tie"
                ties += 1

        # --- MCS quality ---
        if s_mcs > 0 and r_mcs > 0:
            if s_mcs > r_mcs:
                quality = f"SMSD +{s_mcs - r_mcs}"
                mcs_smsd_better += 1
            elif r_mcs > s_mcs:
                quality = f"RDKit +{r_mcs - s_mcs}"
                mcs_rdkit_better += 1
            else:
                quality = "equal"
                mcs_equal += 1
        elif s_mcs > 0 and (r_mcs <= 0 or r_timeout):
            quality = f"SMSD only ({s_mcs})"
            mcs_smsd_better += 1
        elif r_mcs > 0 and s_mcs <= 0:
            quality = f"RDKit only ({r_mcs})"
            mcs_rdkit_better += 1
        else:
            quality = "both failed"

        # --- Format times ---
        def fmt_us(val):
            if val == float("inf"):
                return "ERR"
            if val >= 1_000_000:
                return f"{val/1_000_000:.1f}s"
            if val >= 1_000:
                return f"{val/1_000:.2f}ms"
            return f"{val:.0f}us"

        r_display = "timeout" if r_timeout else fmt_us(r_median)

        print(f"{idx:2d} {name:<30s} {category:<20s} "
              f"{fmt_us(s_median):>10s} {r_display:>10s} "
              f"{s_mcs:>5d} {r_mcs:>5d} "
              f"{speedup_str:>10s} {quality:<15s}")

        results.append(Result(
            name=name, category=category,
            smsd_best_us=s_best, smsd_median_us=s_median, smsd_mcs=s_mcs,
            rdkit_best_us=r_best, rdkit_median_us=r_median, rdkit_mcs=r_mcs,
            rdkit_timed_out=r_timeout,
        ))

    print("-" * 120)
    print()
    print("SUMMARY")
    print(f"  Speed wins:  SMSD={smsd_wins}  RDKit={rdkit_wins}  tie={ties}")
    print(f"  MCS quality: equal={mcs_equal}  SMSD better={mcs_smsd_better}  RDKit better={mcs_rdkit_better}")

    # --- Write TSV ---
    tsv_path = SCRIPT_DIR / "results_python.tsv"
    with open(tsv_path, "w") as f:
        f.write("pair\tcategory\tsmsd_best_us\tsmsd_median_us\tsmsd_mcs\t"
                "rdkit_best_us\trdkit_median_us\trdkit_mcs\trdkit_timeout\n")
        for r in results:
            f.write(f"{r.name}\t{r.category}\t"
                    f"{r.smsd_best_us:.1f}\t{r.smsd_median_us:.1f}\t{r.smsd_mcs}\t"
                    f"{r.rdkit_best_us:.1f}\t{r.rdkit_median_us:.1f}\t{r.rdkit_mcs}\t"
                    f"{r.rdkit_timed_out}\n")
    print(f"\n  Results written to {tsv_path}")


if __name__ == "__main__":
    main()
