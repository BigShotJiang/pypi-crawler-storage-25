/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2018-2026 BioInception PVT LTD
 * Algorithm Copyright (c) 2009-2026 Syed Asad Rahman
 *
 * CUDA kernels for graph matching acceleration:
 *   1. Domain initialization (Nq × Nt atom compatibility)
 *   2. NLF batch compute (per-atom neighbor label histograms)
 *   3. Batch feasibility checks (degree + adjacency)
 */

#include <cuda_runtime.h>
#include <cstdint>
#include <cstdio>
#include <algorithm>

// Error checking macro (matches batch_screen.cu pattern)
#define SMSD_CUDA_CHECK(call) do { \
    cudaError_t err = (call); \
    if (err != cudaSuccess) { return false; } \
} while (0)

namespace smsd {
namespace gpu_kern {

// ============================================================================
// Runtime check
// ============================================================================

bool graphKernelsAvailable() noexcept {
    int count = 0;
    return cudaGetDeviceCount(&count) == cudaSuccess && count > 0;
}

// ============================================================================
// Kernel 1: Domain Initialization
// ============================================================================

__global__ void domainInitKernel(
    int Nq, int Nt, int tWords,
    const int* __restrict__ qAtomicNum,
    const int* __restrict__ qCharge,
    const int* __restrict__ qRing,
    const int* __restrict__ qAromatic,
    const int* __restrict__ tAtomicNum,
    const int* __restrict__ tCharge,
    const int* __restrict__ tRing,
    const int* __restrict__ tAromatic,
    bool matchAtomType, bool matchCharge, bool ringOnly, bool strictArom,
    unsigned long long* domainOut)  // uint64_t = unsigned long long on CUDA
{
    // 2D grid: blockIdx.y = query atom group, blockIdx.x = target atom group
    int qi = blockIdx.y * blockDim.y + threadIdx.y;
    int tj = blockIdx.x * blockDim.x + threadIdx.x;

    if (qi >= Nq || tj >= Nt) return;

    // Common-case atom compatibility (matches atomsCompatFast common path)
    bool ok = true;
    if (matchAtomType && qAtomicNum[qi] != tAtomicNum[tj]) ok = false;
    if (ok && matchCharge && qCharge[qi] != tCharge[tj]) ok = false;
    if (ok && strictArom && qAromatic[qi] != tAromatic[tj]) ok = false;
    if (ok && ringOnly && qRing[qi] && !tRing[tj]) ok = false;

    if (ok) {
        int word = tj >> 6;
        unsigned long long bit = 1ULL << (tj & 63);
        atomicOr(&domainOut[qi * tWords + word], bit);
    }
}

bool domainInit(
    int Nq, int Nt, int tWords,
    const int* qAtomicNum, const int* qCharge, const int* qRing, const int* qAromatic,
    const int* tAtomicNum, const int* tCharge, const int* tRing, const int* tAromatic,
    bool matchAtomType, bool matchCharge, bool ringOnly, bool strictArom,
    uint64_t* domainOut)
{
    // Allocate device buffers
    int* d_qAN = nullptr; int* d_qCh = nullptr; int* d_qRi = nullptr; int* d_qAr = nullptr;
    int* d_tAN = nullptr; int* d_tCh = nullptr; int* d_tRi = nullptr; int* d_tAr = nullptr;
    unsigned long long* d_dom = nullptr;

    size_t qBytes = Nq * sizeof(int);
    size_t tBytes = Nt * sizeof(int);
    size_t domBytes = static_cast<size_t>(Nq) * tWords * sizeof(unsigned long long);

    SMSD_CUDA_CHECK(cudaMalloc(&d_qAN, qBytes));
    SMSD_CUDA_CHECK(cudaMalloc(&d_qCh, qBytes));
    SMSD_CUDA_CHECK(cudaMalloc(&d_qRi, qBytes));
    SMSD_CUDA_CHECK(cudaMalloc(&d_qAr, qBytes));
    SMSD_CUDA_CHECK(cudaMalloc(&d_tAN, tBytes));
    SMSD_CUDA_CHECK(cudaMalloc(&d_tCh, tBytes));
    SMSD_CUDA_CHECK(cudaMalloc(&d_tRi, tBytes));
    SMSD_CUDA_CHECK(cudaMalloc(&d_tAr, tBytes));
    SMSD_CUDA_CHECK(cudaMalloc(&d_dom, domBytes));

    SMSD_CUDA_CHECK(cudaMemcpy(d_qAN, qAtomicNum, qBytes, cudaMemcpyHostToDevice));
    SMSD_CUDA_CHECK(cudaMemcpy(d_qCh, qCharge, qBytes, cudaMemcpyHostToDevice));
    SMSD_CUDA_CHECK(cudaMemcpy(d_qRi, qRing, qBytes, cudaMemcpyHostToDevice));
    SMSD_CUDA_CHECK(cudaMemcpy(d_qAr, qAromatic, qBytes, cudaMemcpyHostToDevice));
    SMSD_CUDA_CHECK(cudaMemcpy(d_tAN, tAtomicNum, tBytes, cudaMemcpyHostToDevice));
    SMSD_CUDA_CHECK(cudaMemcpy(d_tCh, tCharge, tBytes, cudaMemcpyHostToDevice));
    SMSD_CUDA_CHECK(cudaMemcpy(d_tRi, tRing, tBytes, cudaMemcpyHostToDevice));
    SMSD_CUDA_CHECK(cudaMemcpy(d_tAr, tAromatic, tBytes, cudaMemcpyHostToDevice));
    SMSD_CUDA_CHECK(cudaMemset(d_dom, 0, domBytes));

    dim3 block(32, 8);  // 256 threads
    dim3 grid((Nt + 31) / 32, (Nq + 7) / 8);

    domainInitKernel<<<grid, block>>>(
        Nq, Nt, tWords,
        d_qAN, d_qCh, d_qRi, d_qAr,
        d_tAN, d_tCh, d_tRi, d_tAr,
        matchAtomType, matchCharge, ringOnly, strictArom,
        d_dom);

    SMSD_CUDA_CHECK(cudaGetLastError());
    SMSD_CUDA_CHECK(cudaDeviceSynchronize());
    SMSD_CUDA_CHECK(cudaMemcpy(domainOut, d_dom, domBytes, cudaMemcpyDeviceToHost));

    cudaFree(d_qAN); cudaFree(d_qCh); cudaFree(d_qRi); cudaFree(d_qAr);
    cudaFree(d_tAN); cudaFree(d_tCh); cudaFree(d_tRi); cudaFree(d_tAr);
    cudaFree(d_dom);
    return true;
}

// ============================================================================
// Kernel 2: NLF Batch Build
// ============================================================================

static constexpr int MAX_NLF_LABELS = 32;  // max distinct neighbor labels per atom

__global__ void nlfBuildKernel(
    int totalAtoms,
    const int* __restrict__ neighborOffsets,
    const int* __restrict__ neighborList,
    const int* __restrict__ atomicNum,
    const int* __restrict__ aromatic,
    int* nlfPairsOut,
    int* nlfLengthsOut,
    int maxPairs)
{
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= totalAtoms) return;

    int start = neighborOffsets[idx];
    int end = neighborOffsets[idx + 1];
    int deg = end - start;

    // Build histogram in registers (small — typical degree 1-6)
    int labels[MAX_NLF_LABELS];
    int counts[MAX_NLF_LABELS];
    int nDistinct = 0;

    for (int e = start; e < end; ++e) {
        int nb = neighborList[e];
        int lab = (atomicNum[nb] << 1) | (aromatic[nb] ? 1 : 0);
        // Linear scan (degree is tiny)
        bool found = false;
        for (int k = 0; k < nDistinct; ++k) {
            if (labels[k] == lab) { counts[k]++; found = true; break; }
        }
        if (!found && nDistinct < MAX_NLF_LABELS) {
            labels[nDistinct] = lab;
            counts[nDistinct] = 1;
            nDistinct++;
        }
    }

    // Insertion sort by label
    for (int i = 1; i < nDistinct; ++i) {
        int kl = labels[i], kc = counts[i], j = i - 1;
        while (j >= 0 && labels[j] > kl) {
            labels[j + 1] = labels[j]; counts[j + 1] = counts[j]; --j;
        }
        labels[j + 1] = kl; counts[j + 1] = kc;
    }

    // Write output
    int outBase = idx * maxPairs * 2;
    int pairsWritten = min(nDistinct, maxPairs);
    for (int k = 0; k < pairsWritten; ++k) {
        nlfPairsOut[outBase + k * 2] = labels[k];
        nlfPairsOut[outBase + k * 2 + 1] = counts[k];
    }
    nlfLengthsOut[idx] = pairsWritten * 2;  // length in ints (pairs × 2)
}

bool nlfBatchBuild(
    int totalAtoms, int totalEdges,
    const int* neighborOffsets, const int* neighborList,
    const int* atomicNum, const int* aromatic,
    int* nlfPairsOut, int* nlfLengthsOut, int maxPairsPerAtom)
{
    int* d_offsets = nullptr; int* d_nbList = nullptr;
    int* d_atomNum = nullptr; int* d_arom = nullptr;
    int* d_nlfPairs = nullptr; int* d_nlfLens = nullptr;

    size_t offsetBytes = (totalAtoms + 1) * sizeof(int);
    size_t edgeBytes = totalEdges * sizeof(int);
    size_t atomBytes = totalAtoms * sizeof(int);
    size_t pairBytes = static_cast<size_t>(totalAtoms) * maxPairsPerAtom * 2 * sizeof(int);

    SMSD_CUDA_CHECK(cudaMalloc(&d_offsets, offsetBytes));
    SMSD_CUDA_CHECK(cudaMalloc(&d_nbList, edgeBytes));
    SMSD_CUDA_CHECK(cudaMalloc(&d_atomNum, atomBytes));
    SMSD_CUDA_CHECK(cudaMalloc(&d_arom, atomBytes));
    SMSD_CUDA_CHECK(cudaMalloc(&d_nlfPairs, pairBytes));
    SMSD_CUDA_CHECK(cudaMalloc(&d_nlfLens, atomBytes));

    SMSD_CUDA_CHECK(cudaMemcpy(d_offsets, neighborOffsets, offsetBytes, cudaMemcpyHostToDevice));
    SMSD_CUDA_CHECK(cudaMemcpy(d_nbList, neighborList, edgeBytes, cudaMemcpyHostToDevice));
    SMSD_CUDA_CHECK(cudaMemcpy(d_atomNum, atomicNum, atomBytes, cudaMemcpyHostToDevice));
    SMSD_CUDA_CHECK(cudaMemcpy(d_arom, aromatic, atomBytes, cudaMemcpyHostToDevice));
    SMSD_CUDA_CHECK(cudaMemset(d_nlfPairs, 0, pairBytes));

    int blocks = (totalAtoms + 255) / 256;
    nlfBuildKernel<<<blocks, 256>>>(
        totalAtoms, d_offsets, d_nbList, d_atomNum, d_arom,
        d_nlfPairs, d_nlfLens, maxPairsPerAtom);

    SMSD_CUDA_CHECK(cudaGetLastError());
    SMSD_CUDA_CHECK(cudaDeviceSynchronize());
    SMSD_CUDA_CHECK(cudaMemcpy(nlfPairsOut, d_nlfPairs, pairBytes, cudaMemcpyDeviceToHost));
    SMSD_CUDA_CHECK(cudaMemcpy(nlfLengthsOut, d_nlfLens, atomBytes, cudaMemcpyDeviceToHost));

    cudaFree(d_offsets); cudaFree(d_nbList); cudaFree(d_atomNum); cudaFree(d_arom);
    cudaFree(d_nlfPairs); cudaFree(d_nlfLens);
    return true;
}

// ============================================================================
// Kernel 3: Batch Feasibility Check
// ============================================================================

__global__ void feasibilityKernel(
    int numCandidates, int Nq, int Nt, int tWords,
    const int* __restrict__ qiList,
    const int* __restrict__ tjList,
    const int* __restrict__ qDegree,
    const int* __restrict__ tDegree,
    const unsigned long long* __restrict__ tAdjLong,
    const int* __restrict__ q2t,
    int* feasibleOut)
{
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= numCandidates) return;

    int qi = qiList[idx];
    int tj = tjList[idx];

    // Degree check
    if (tDegree[tj] < qDegree[qi]) { feasibleOut[idx] = 0; return; }

    // Mapped-neighbor adjacency: for each mapped neighbor of qi,
    // verify that tj is adjacent to the mapped target atom
    const unsigned long long* tAdj = &tAdjLong[tj * tWords];
    // Note: we can't iterate query neighbors on GPU without the neighbor list.
    // This kernel handles the degree check; full adjacency stays on CPU.
    feasibleOut[idx] = 1;
}

bool feasibilityBatch(
    int numCandidates,
    const int* qiList, const int* tjList,
    int Nq, int Nt, int tWords,
    const int* qDegree, const int* tDegree,
    const uint64_t* tAdjLong,
    const int* q2t,
    int* feasibleOut)
{
    int* d_qi = nullptr; int* d_tj = nullptr;
    int* d_qDeg = nullptr; int* d_tDeg = nullptr;
    unsigned long long* d_tAdj = nullptr;
    int* d_q2t = nullptr; int* d_result = nullptr;

    size_t candBytes = numCandidates * sizeof(int);
    size_t adjBytes = static_cast<size_t>(Nt) * tWords * sizeof(unsigned long long);

    SMSD_CUDA_CHECK(cudaMalloc(&d_qi, candBytes));
    SMSD_CUDA_CHECK(cudaMalloc(&d_tj, candBytes));
    SMSD_CUDA_CHECK(cudaMalloc(&d_qDeg, Nq * sizeof(int)));
    SMSD_CUDA_CHECK(cudaMalloc(&d_tDeg, Nt * sizeof(int)));
    SMSD_CUDA_CHECK(cudaMalloc(&d_tAdj, adjBytes));
    SMSD_CUDA_CHECK(cudaMalloc(&d_q2t, Nq * sizeof(int)));
    SMSD_CUDA_CHECK(cudaMalloc(&d_result, candBytes));

    SMSD_CUDA_CHECK(cudaMemcpy(d_qi, qiList, candBytes, cudaMemcpyHostToDevice));
    SMSD_CUDA_CHECK(cudaMemcpy(d_tj, tjList, candBytes, cudaMemcpyHostToDevice));
    SMSD_CUDA_CHECK(cudaMemcpy(d_qDeg, qDegree, Nq * sizeof(int), cudaMemcpyHostToDevice));
    SMSD_CUDA_CHECK(cudaMemcpy(d_tDeg, tDegree, Nt * sizeof(int), cudaMemcpyHostToDevice));
    SMSD_CUDA_CHECK(cudaMemcpy(d_tAdj, tAdjLong, adjBytes, cudaMemcpyHostToDevice));
    SMSD_CUDA_CHECK(cudaMemcpy(d_q2t, q2t, Nq * sizeof(int), cudaMemcpyHostToDevice));

    int blocks = (numCandidates + 255) / 256;
    feasibilityKernel<<<blocks, 256>>>(
        numCandidates, Nq, Nt, tWords,
        d_qi, d_tj, d_qDeg, d_tDeg, d_tAdj, d_q2t, d_result);

    SMSD_CUDA_CHECK(cudaGetLastError());
    SMSD_CUDA_CHECK(cudaDeviceSynchronize());
    SMSD_CUDA_CHECK(cudaMemcpy(feasibleOut, d_result, candBytes, cudaMemcpyDeviceToHost));

    cudaFree(d_qi); cudaFree(d_tj); cudaFree(d_qDeg); cudaFree(d_tDeg);
    cudaFree(d_tAdj); cudaFree(d_q2t); cudaFree(d_result);
    return true;
}

} // namespace gpu_kern
} // namespace smsd
