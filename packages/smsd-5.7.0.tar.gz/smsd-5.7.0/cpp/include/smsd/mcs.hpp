/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2018-2026 BioInception PVT LTD
 * Algorithm Copyright (c) 2009-2026 Syed Asad Rahman
 *
 * MCS (Maximum Common Substructure) engine -- header-only C++17 port.
 *
 * Coverage-driven funnel with 7 levels:
 *   L0    Label-frequency upper bound
 *   L0.25 Linear chain fast-path (PEG, polyethylene)
 *   L0.5  Tree fast-path (branched polymers, dendrimers, glycogen)
 *   L0.75 Greedy probe
 *   L1    Substructure containment check
 *   L1.5 Seed-and-extend (bond growth)
 *   L2   McSplit partition refinement (bidirectional, RRSplit maximality)
 *   L3   Bron-Kerbosch + Tomita pivoting + k-core reduction
 *   L4   McGregor extension (bond-grow + atom-frontier DFS + forced assignment)
 *   L5   Extra seeds (only when McSplit and BK disagree)
 *
 * Zero external dependencies -- pure C++17 standard library only.
 */
#pragma once

#include "smsd/mol_graph.hpp"
#include "smsd/vf2pp.hpp"

#include <algorithm>
#include <array>
#include <cassert>
#include <chrono>
#include <climits>
#include <cmath>
#include <cstdint>
#include <cstring>
#ifdef _MSC_VER
#include <intrin.h>
#endif
#include <functional>
#include <map>
#include <numeric>
#include <deque>
#include <set>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

namespace smsd {

// Uses detail::popcount64, detail::ctz64, TimeBudget from vf2pp.hpp
namespace detail {
} // namespace detail (popcount64/ctz64 from vf2pp.hpp)

// ---------------------------------------------------------------------------
// McsOptions
// ---------------------------------------------------------------------------
struct McsOptions {
    bool     induced         = false;
    bool     connectedOnly   = true;
    bool     disconnectedMCS = false;
    bool     maximizeBonds   = false;
    int      minFragmentSize = 1;
    int      maxFragments    = INT_MAX;
    double*  atomWeights     = nullptr;
    int64_t  timeoutMs       = 10000;
    bool     extraSeeds      = true;
    int      seedNeighborhoodRadius = 2;
    int      seedMaxAnchors  = 12;
    bool     useTwoHopNLFInExtension   = true;
    bool     useThreeHopNLFInExtension = false;
};

// TimeBudget reused from vf2pp.hpp (TimeBudget)
namespace detail {

// ---------------------------------------------------------------------------
// Scratch -- pre-allocated buffers reused across calls
// ---------------------------------------------------------------------------
struct Scratch {
    std::vector<int>  q2t, t2q;
    std::vector<int>  bestQ2T;
    std::vector<bool> usedQ, usedT;
    std::vector<int>  candBuf, bestCandBuf;
    std::vector<int>  qLabelFreq, tLabelFreq;
    std::vector<int>  jointQ, jointT;
    std::vector<bool> inFrontier;
    std::vector<int>  frontierBuf;
    std::vector<int>  forcedQ, forcedT;
    std::vector<int>  q2tMap;

    void resize(int n1, int n2, int freqSize) {
        q2t.assign(n1, -1);
        t2q.assign(n2, -1);
        bestQ2T.assign(n1, -1);
        usedQ.assign(n1, false);
        usedT.assign(n2, false);
        candBuf.resize(n2);
        bestCandBuf.resize(n2);
        qLabelFreq.assign(freqSize, 0);
        tLabelFreq.assign(freqSize, 0);
        jointQ.resize(n1);
        jointT.resize(n2);
        inFrontier.assign(n1, false);
        frontierBuf.resize(n1);
        forcedQ.resize(n1);
        forcedT.resize(n2);
        q2tMap.assign(n1, -1);
    }
};

// atomsCompatFast() and bondsCompatible() are defined in vf2pp.hpp (detail namespace)
// and reused here via the same include chain.

// ---------------------------------------------------------------------------
// NLF (Neighbour Label Frequency) check
// ---------------------------------------------------------------------------
inline bool nlfOk(const std::vector<int>& fq, const std::vector<int>& ft) {
    int fi = 0, ti = 0;
    int fqsz = static_cast<int>(fq.size());
    int ftsz = static_cast<int>(ft.size());
    while (fi < fqsz) {
        int fLabel = fq[fi], fFreq = fq[fi + 1];
        while (ti < ftsz && ft[ti] < fLabel) ti += 2;
        if (ti >= ftsz || ft[ti] != fLabel || ft[ti + 1] < fFreq) return false;
        fi += 2;
    }
    return true;
}

inline bool nlfCheckOk(int qi, int tj,
                       const std::vector<std::vector<int>>& qNLF1,
                       const std::vector<std::vector<int>>& tNLF1,
                       const std::vector<std::vector<int>>& qNLF2,
                       const std::vector<std::vector<int>>& tNLF2,
                       const std::vector<std::vector<int>>& qNLF3,
                       const std::vector<std::vector<int>>& tNLF3,
                       bool useTwoHop, bool useThreeHop) {
    if (!nlfOk(qNLF1[qi], tNLF1[tj])) return false;
    if (useTwoHop && !qNLF2.empty() && !nlfOk(qNLF2[qi], tNLF2[tj])) return false;
    if (useThreeHop && !qNLF3.empty() && !nlfOk(qNLF3[qi], tNLF3[tj])) return false;
    return true;
}

// Build NLF arrays from a MolGraph
inline std::vector<std::vector<int>> buildNLF(const MolGraph& g,
    std::function<void(const MolGraph&, int, std::map<int,int>&)> collector) {
    std::vector<std::vector<int>> nlf(g.n);
    for (int i = 0; i < g.n; ++i) {
        std::map<int,int> freq;
        collector(g, i, freq);
        nlf[i].reserve(freq.size() * 2);
        for (auto& [lab, cnt] : freq) {
            nlf[i].push_back(lab);
            nlf[i].push_back(cnt);
        }
    }
    return nlf;
}

// NLF label: atomicNum + aromaticity, WITHOUT ring bit — matches MolGraph::nlfLabel().
inline int mcsNlfLabel(const MolGraph& g, int idx) {
    return (g.atomicNum[idx] << 1) | (g.aromatic[idx] ? 1 : 0);
}

inline std::vector<std::vector<int>> buildNLF1(const MolGraph& g) {
    return buildNLF(g, [](const MolGraph& g, int idx, std::map<int,int>& freq) {
        for (int nb : g.neighbors[idx]) freq[mcsNlfLabel(g, nb)]++;
    });
}

inline std::vector<std::vector<int>> buildNLF2(const MolGraph& g) {
    return buildNLF(g, [](const MolGraph& g, int idx, std::map<int,int>& freq) {
        std::vector<bool> direct(g.n, false);
        direct[idx] = true;
        for (int nb : g.neighbors[idx]) direct[nb] = true;
        std::vector<bool> seen(g.n, false);
        for (int nb : g.neighbors[idx])
            for (int j : g.neighbors[nb]) {
                if (direct[j] || seen[j]) continue;
                seen[j] = true;
                freq[mcsNlfLabel(g, j)]++;
            }
    });
}

inline std::vector<std::vector<int>> buildNLF3(const MolGraph& g) {
    return buildNLF(g, [](const MolGraph& g, int idx, std::map<int,int>& freq) {
        std::vector<bool> level1(g.n, false);
        level1[idx] = true;
        for (int nb : g.neighbors[idx]) level1[nb] = true;
        std::vector<bool> level2(g.n, false);
        for (int nb : g.neighbors[idx])
            for (int j : g.neighbors[nb])
                if (!level1[j]) level2[j] = true;
        for (int v = 0; v < g.n; ++v) {
            if (!level2[v]) continue;
            for (int j : g.neighbors[v]) {
                if (!level1[j] && !level2[j]) freq[mcsNlfLabel(g, j)]++;
            }
        }
    });
}

// ---------------------------------------------------------------------------
// Upper bound: label-frequency (Level 0)
// ---------------------------------------------------------------------------
inline int ubLabel(const MolGraph& g, int i, const ChemOptions& C) {
    if (!C.matchAtomType) return 0;
    int key = g.atomicNum[i] << 2;
    if (C.aromaticityMode == ChemOptions::AromaticityMode::STRICT) key |= g.aromatic[i] ? 2 : 0;
    if (C.ringMatchesRingOnly) key |= g.ring[i] ? 1 : 0;
    return key;
}

inline int labelFrequencyUpperBound(const MolGraph& g1, const MolGraph& g2,
                                     const ChemOptions& C) {
    if (g1.n == 0 || g2.n == 0) return 0;
    std::unordered_map<int,int> freq1, freq2;
    for (int i = 0; i < g1.n; ++i) freq1[ubLabel(g1, i, C)]++;
    for (int j = 0; j < g2.n; ++j) freq2[ubLabel(g2, j, C)]++;
    int ub = 0;
    for (auto& [lab, cnt] : freq1) {
        auto it = freq2.find(lab);
        if (it != freq2.end()) ub += std::min(cnt, it->second);
    }
    return std::min(ub, std::min(g1.n, g2.n));
}

// ---------------------------------------------------------------------------
// Mapped-bond counter
// ---------------------------------------------------------------------------
inline int countMappedBonds(const MolGraph& g1, const std::map<int,int>& m) {
    int count = 0;
    for (auto& [qi, ti] : m)
        for (int qk : g1.neighbors[qi])
            if (qk > qi && m.count(qk)) ++count;
    return count;
}

// ---------------------------------------------------------------------------
// MCS scoring
// ---------------------------------------------------------------------------
inline int mcsScore(const MolGraph& g1, const std::map<int,int>& m,
                    const McsOptions& M) {
    if (M.atomWeights) {
        double w = 0.0;
        for (auto& [qi, ti] : m) w += M.atomWeights[qi];
        return static_cast<int>(w * 1000);
    }
    return M.maximizeBonds ? countMappedBonds(g1, m) : static_cast<int>(m.size());
}

// ---------------------------------------------------------------------------
// Largest connected component (in query graph induced by mapped atoms)
// ---------------------------------------------------------------------------
inline std::map<int,int> largestConnected(const MolGraph& g1,
                                           const std::map<int,int>& m) {
    if (m.empty()) return m;
    // BFS to find components
    std::unordered_set<int> mapped;
    for (auto& [qi, ti] : m) mapped.insert(qi);

    std::unordered_set<int> seen;
    std::vector<std::vector<int>> comps;
    for (auto& [qi, ti] : m) {
        if (seen.count(qi)) continue;
        std::vector<int> comp;
        std::vector<int> dq = {qi};
        seen.insert(qi);
        while (!dq.empty()) {
            int u = dq.back(); dq.pop_back();
            comp.push_back(u);
            for (int v : g1.neighbors[u]) {
                if (mapped.count(v) && !seen.count(v)) {
                    if (g1.hasBond(u, v)) {
                        seen.insert(v);
                        dq.push_back(v);
                    }
                }
            }
        }
        comps.push_back(std::move(comp));
    }
    // Pick largest
    int bestIdx = 0;
    for (int i = 1; i < static_cast<int>(comps.size()); ++i)
        if (comps[i].size() > comps[bestIdx].size()) bestIdx = i;

    if (comps[bestIdx].size() == m.size()) return m;
    std::map<int,int> result;
    for (int qi : comps[bestIdx]) result[qi] = m.at(qi);
    return result;
}

// ---------------------------------------------------------------------------
// Fragment constraints (dMCS)
// ---------------------------------------------------------------------------
inline std::map<int,int> applyFragmentConstraints(
    const MolGraph& g1, const std::map<int,int>& m,
    int minFragSize, int maxFrags) {
    if (m.empty() || (minFragSize <= 1 && maxFrags >= static_cast<int>(m.size()))) return m;

    std::unordered_set<int> mapped;
    for (auto& [qi, ti] : m) mapped.insert(qi);
    std::unordered_set<int> seen;
    std::vector<std::vector<int>> frags;
    for (auto& [qi, ti] : m) {
        if (seen.count(qi)) continue;
        std::vector<int> frag;
        std::vector<int> dq = {qi};
        seen.insert(qi);
        while (!dq.empty()) {
            int u = dq.back(); dq.pop_back();
            frag.push_back(u);
            for (int v : g1.neighbors[u]) {
                if (mapped.count(v) && !seen.count(v) && g1.hasBond(u, v)) {
                    seen.insert(v); dq.push_back(v);
                }
            }
        }
        frags.push_back(std::move(frag));
    }
    // Remove small fragments
    frags.erase(std::remove_if(frags.begin(), frags.end(),
        [minFragSize](const std::vector<int>& f) { return static_cast<int>(f.size()) < minFragSize; }),
        frags.end());
    // Sort descending by size
    std::sort(frags.begin(), frags.end(),
        [](const std::vector<int>& a, const std::vector<int>& b) { return a.size() > b.size(); });
    if (static_cast<int>(frags.size()) > maxFrags)
        frags.resize(maxFrags);

    std::map<int,int> result;
    for (auto& frag : frags)
        for (int qi : frag) result[qi] = m.at(qi);
    return result;
}

// ---------------------------------------------------------------------------
// Ring anchor guard
// ---------------------------------------------------------------------------
inline std::map<int,int> applyRingAnchorGuard(
    const MolGraph& g1, const MolGraph& g2,
    const std::map<int,int>& m, const ChemOptions& C) {
    if (!C.ringMatchesRingOnly || m.empty()) return m;
    bool qHasRing = false, tHasRing = false;
    for (int i = 0; i < g1.n; ++i) if (g1.ring[i]) { qHasRing = true; break; }
    for (int i = 0; i < g2.n; ++i) if (g2.ring[i]) { tHasRing = true; break; }
    if (qHasRing && !tHasRing) {
        int mappedRing = 0;
        for (auto& [qi, ti] : m) if (g1.ring[qi]) mappedRing++;
        if (mappedRing == 0) return {};
    }
    return m;
}

// ---------------------------------------------------------------------------
// Enforce complete rings
// ---------------------------------------------------------------------------
inline std::map<int,int> enforceCompleteRings(
    const MolGraph& g1, const MolGraph& g2, const std::map<int,int>& m) {
    if (m.empty()) return m;
    auto rings = const_cast<MolGraph&>(g1).computeRings();
    if (rings.empty()) return m;
    std::map<int,int> result = m;
    bool changed = true;
    while (changed) {
        changed = false;
        for (auto& ring : rings) {
            bool anyMapped = false, allMapped = true;
            for (int atom : ring) {
                if (result.count(atom)) anyMapped = true;
                else allMapped = false;
            }
            if (anyMapped && !allMapped) {
                for (int atom : ring) {
                    if (result.erase(atom)) changed = true;
                }
            }
        }
    }
    return result;
}

// ---------------------------------------------------------------------------
// Prune to induced subgraph
// ---------------------------------------------------------------------------
inline std::map<int,int> pruneToInduced(
    const MolGraph& g1, const MolGraph& g2,
    const std::map<int,int>& m, const ChemOptions& C) {
    if (m.empty()) return m;
    std::map<int,int> M = m;
    bool changed;
    do {
        changed = false;
        std::vector<int> keys;
        for (auto& [k,v] : M) keys.push_back(k);
        for (int i = 0; i < static_cast<int>(keys.size()) && !changed; ++i) {
            for (int j = i + 1; j < static_cast<int>(keys.size()) && !changed; ++j) {
                int qi = keys[i], qj = keys[j];
                int ti = M[qi], tj = M[qj];
                int qOrd = g1.bondOrder(qi, qj), tOrd = g2.bondOrder(ti, tj);
                bool qHas = qOrd != 0, tHas = tOrd != 0;
                bool ok = (qHas == tHas);
                if (ok && qHas) ok = bondsCompatible(g1, qi, qj, g2, ti, tj, C);
                if (!ok) {
                    if (g1.degree[qi] >= g1.degree[qj]) M.erase(qi); else M.erase(qj);
                    changed = true;
                }
            }
        }
    } while (changed);
    return M;
}

// ---------------------------------------------------------------------------
// Post-process MCS (ppx)
// ---------------------------------------------------------------------------
inline std::map<int,int> ppx(const MolGraph& g1, const MolGraph& g2,
                              std::map<int,int> ext,
                              const ChemOptions& C, const McsOptions& M) {
    // Iteratively apply filters until stable (filters can interact)
    bool changed = true;
    while (changed) {
        int startSize = (int)ext.size();
        if (M.induced) ext = pruneToInduced(g1, g2, ext, C);
        if (C.completeRingsOnly) ext = enforceCompleteRings(g1, g2, ext);
        if (!M.disconnectedMCS && M.connectedOnly) ext = largestConnected(g1, ext);
        changed = (int)ext.size() < startSize;
    }
    ext = applyRingAnchorGuard(g1, g2, ext, C);
    if (M.disconnectedMCS && (M.minFragmentSize > 1 || M.maxFragments < INT_MAX))
        ext = applyFragmentConstraints(g1, ext, M.minFragmentSize, M.maxFragments);
    return ext;
}

// ---------------------------------------------------------------------------
// Greedy probe (Level 0.75)
// ---------------------------------------------------------------------------
inline std::map<int,int> greedyProbe(const MolGraph& g1, const MolGraph& g2,
                                      const ChemOptions& C) {
    int n1 = g1.n, n2 = g2.n;
    if (n1 == 0 || n2 == 0) return {};

    // Sort query atoms: ring first, then descending degree
    std::vector<int> order(n1);
    std::iota(order.begin(), order.end(), 0);
    std::sort(order.begin(), order.end(), [&](int a, int b) {
        int sa = (g1.ring[a] ? 1000 : 0) + g1.degree[a];
        int sb = (g1.ring[b] ? 1000 : 0) + g1.degree[b];
        return sa > sb;
    });

    std::vector<bool> usedT(n2, false);
    std::map<int,int> mapping;

    for (int idx = 0; idx < n1; ++idx) {
        int qi = order[idx];
        int bestTj = -1, bestScore = -1;
        for (int tj = 0; tj < n2; ++tj) {
            if (usedT[tj]) continue;
            if (!atomsCompatFast(g1, qi, g2, tj, C)) continue;
            bool ok = true;
            for (int qk : g1.neighbors[qi]) {
                auto it = mapping.find(qk);
                if (it == mapping.end()) continue;
                int tk = it->second;
                int qOrd = g1.bondOrder(qi, qk), tOrd = g2.bondOrder(tj, tk);
                if ((qOrd==0) != (tOrd==0)) { ok = false; break; }
                if (qOrd != 0 && !bondsCompatible(g1, qi, qk, g2, tj, tk, C)) { ok = false; break; }
            }
            if (!ok) continue;
            int score = (g2.ring[tj] == g1.ring[qi] ? 100 : 0)
                      + (g2.degree[tj] == g1.degree[qi] ? 50 : 0)
                      + std::min(g1.degree[qi], g2.degree[tj]);
            if (score > bestScore) { bestScore = score; bestTj = tj; }
        }
        if (bestTj >= 0) { mapping[qi] = bestTj; usedT[bestTj] = true; }
    }
    return mapping;
}

// ---------------------------------------------------------------------------
// Greedy atom extend
// ---------------------------------------------------------------------------
inline std::map<int,int> greedyAtomExtend(
    const MolGraph& g1, const MolGraph& g2,
    const std::map<int,int>& seed,
    const ChemOptions& C, const McsOptions& M) {
    int n1 = g1.n, n2 = g2.n;
    std::vector<int> q2t(n1, -1), t2q(n2, -1);
    for (auto& [k,v] : seed) { q2t[k] = v; t2q[v] = k; }
    bool progress = true;
    while (progress) {
        progress = false;
        for (int qi = 0; qi < n1; ++qi) {
            if (q2t[qi] >= 0) continue;
            bool onFrontier = false;
            for (int nb : g1.neighbors[qi])
                if (q2t[nb] >= 0) { onFrontier = true; break; }
            if (!onFrontier) continue;

            int bestTj = -1, bestScore = -1;
            for (int tj = 0; tj < n2; ++tj) {
                if (t2q[tj] >= 0) continue;
                if (!atomsCompatFast(g1, qi, g2, tj, C)) continue;
                bool consistent = true;
                for (int qk : g1.neighbors[qi]) {
                    if (q2t[qk] < 0) continue;
                    int tk = q2t[qk];
                    int qOrd = g1.bondOrder(qi, qk), tOrd = g2.bondOrder(tj, tk);
                    if (qOrd != 0 && tOrd != 0) {
                        if (!bondsCompatible(g1, qi, qk, g2, tj, tk, C)) { consistent = false; break; }
                    } else if (M.induced && ((qOrd!=0) != (tOrd!=0))) { consistent = false; break; }
                }
                if (!consistent) continue;
                int score = (g2.ring[tj] && g1.ring[qi] ? 50 : 0)
                          + std::min(g1.degree[qi], g2.degree[tj]);
                if (score > bestScore) { bestScore = score; bestTj = tj; }
            }
            if (bestTj >= 0) {
                q2t[qi] = bestTj; t2q[bestTj] = qi;
                progress = true;
            }
        }
    }
    std::map<int,int> result;
    for (int i = 0; i < n1; ++i) if (q2t[i] >= 0) result[i] = q2t[i];
    return result;
}

// ---------------------------------------------------------------------------
// Label-frequency pruning check
// ---------------------------------------------------------------------------
inline bool isPruned(int curSize, int bestSize, const int* qLF, const int* tLF, int freqSize) {
    int potential = curSize;
    for (int lbl = 0; lbl < freqSize; ++lbl)
        if (qLF[lbl] > 0) potential += std::min(qLF[lbl], tLF[lbl]);
    return potential <= bestSize;
}

// ---------------------------------------------------------------------------
// Build frontier for McGregor DFS
// ---------------------------------------------------------------------------
inline int buildFrontier(const MolGraph& g1, const std::map<int,int>& cur,
                          const std::vector<bool>& usedQ,
                          std::vector<bool>& inFrontier,
                          int* frontierBuf, bool connectedOnly = true) {
    int count = 0;
    for (auto& [qk, tv] : cur)
        for (int qn : g1.neighbors[qk])
            if (!usedQ[qn] && !inFrontier[qn] && !cur.count(qn)) {
                inFrontier[qn] = true;
                frontierBuf[count++] = qn;
            }
    // Only jump to disconnected atoms if disconnected MCS is allowed
    if (count == 0 && !connectedOnly)
        for (int i = 0; i < g1.n; ++i)
            if (!usedQ[i] && !cur.count(i)) frontierBuf[count++] = i;
    for (int f = 0; f < count; ++f) inFrontier[frontierBuf[f]] = false;
    return count;
}

// ---------------------------------------------------------------------------
// Find best candidate for McGregor
// ---------------------------------------------------------------------------
inline int findBestCandidate(
    const MolGraph& g1, const MolGraph& g2, const ChemOptions& C,
    const std::map<int,int>& cur, const std::vector<bool>& usedT,
    const std::vector<std::vector<int>>& qNLF1,
    const std::vector<std::vector<int>>& tNLF1,
    const std::vector<std::vector<int>>& qNLF2,
    const std::vector<std::vector<int>>& tNLF2,
    const std::vector<std::vector<int>>& qNLF3,
    const std::vector<std::vector<int>>& tNLF3,
    bool useTwoHopNLF, bool useThreeHopNLF,
    int frontierCount, const int* frontierBuf,
    int* candBuf, int* bestCandBuf,
    int& outQi, int& outCandCount) {

    int bestQi = -1, bestCandSize = INT_MAX, bestCandCount = 0;
    for (int fi = 0; fi < frontierCount; ++fi) {
        int qi = frontierBuf[fi];
        int candCount = 0;
        for (int tj = 0; tj < g2.n; ++tj) {
            if (usedT[tj]) continue;
            if (!atomsCompatFast(g1, qi, g2, tj, C)) continue;
            if (!nlfCheckOk(qi, tj, qNLF1, tNLF1, qNLF2, tNLF2, qNLF3, tNLF3,
                            useTwoHopNLF, useThreeHopNLF)) continue;
            bool ok = true;
            for (int qk : g1.neighbors[qi]) {
                auto it = cur.find(qk);
                if (it == cur.end()) continue;
                int tl = it->second;
                int qOrd = g1.bondOrder(qi, qk), tOrd = g2.bondOrder(tj, tl);
                if ((qOrd==0) != (tOrd==0)) { ok = false; break; }
                if (qOrd != 0 && !bondsCompatible(g1, qi, qk, g2, tj, tl, C)) { ok = false; break; }
            }
            if (ok) candBuf[candCount++] = tj;
        }
        if (candCount == 0) continue;
        if (candCount < bestCandSize) {
            bestCandSize = candCount;
            bestQi = qi;
            bestCandCount = candCount;
            std::memcpy(bestCandBuf, candBuf, candCount * sizeof(int));
        }
    }
    outQi = bestQi;
    outCandCount = bestCandCount;
    return bestQi;
}

// ---------------------------------------------------------------------------
// Undo forced assignments
// ---------------------------------------------------------------------------
inline void undoForcedAssignments(
    int forcedCount, const int* forcedQ, const int* forcedT,
    std::map<int,int>& cur,
    std::vector<bool>& usedQ, std::vector<bool>& usedT,
    int* qLabelFreq, int* tLabelFreq,
    const int* jointQ, const int* jointT,
    int* q2tMap) {
    for (int f = forcedCount - 1; f >= 0; --f) {
        int fq = forcedQ[f], ft = forcedT[f];
        qLabelFreq[jointQ[fq]]++;
        tLabelFreq[jointT[ft]]++;
        cur.erase(fq);
        usedQ[fq] = false;
        usedT[ft] = false;
        if (q2tMap) q2tMap[fq] = -1;
    }
}

// ---------------------------------------------------------------------------
// McGregor DFS (Level 4 -- atom-frontier)
// ---------------------------------------------------------------------------
inline void mcGregorDFS(
    const MolGraph& g1, const MolGraph& g2, const ChemOptions& C,
    std::map<int,int>& cur, std::map<int,int>& best,
    const std::vector<std::vector<int>>& qNLF1,
    const std::vector<std::vector<int>>& tNLF1,
    const std::vector<std::vector<int>>& qNLF2,
    const std::vector<std::vector<int>>& tNLF2,
    const std::vector<std::vector<int>>& qNLF3,
    const std::vector<std::vector<int>>& tNLF3,
    bool useTwoHopNLF, bool useThreeHopNLF,
    TimeBudget& tb, int64_t localDeadlineNs, int depth,
    std::vector<bool>& usedQ, std::vector<bool>& usedT,
    int* candBuf, int* bestCandBuf,
    int* qLabelFreq, int* tLabelFreq, int freqSize,
    std::vector<bool>& inFrontier, int* frontierBuf,
    const int* jointQ, const int* jointT) {

    using Clock = std::chrono::steady_clock;
    auto now_ns = [&]() {
        return std::chrono::duration_cast<std::chrono::nanoseconds>(
            Clock::now().time_since_epoch()).count();
    };

    if (now_ns() >= localDeadlineNs || tb.expired()) return;
    if (static_cast<int>(cur.size()) > static_cast<int>(best.size())) {
        best = cur;
    }
    if (isPruned(static_cast<int>(cur.size()), static_cast<int>(best.size()),
                 qLabelFreq, tLabelFreq, freqSize)) return;

    int frontierCount = buildFrontier(g1, cur, usedQ, inFrontier, frontierBuf);
    if (frontierCount == 0) return;

    int bestQi = -1, bestCandCount = 0;
    findBestCandidate(g1, g2, C, cur, usedT, qNLF1, tNLF1, qNLF2, tNLF2, qNLF3, tNLF3,
                      useTwoHopNLF, useThreeHopNLF, frontierCount, frontierBuf,
                      candBuf, bestCandBuf, bestQi, bestCandCount);
    if (bestQi == -1) return;

    // Unit propagation (forced assignment)
    int forcedCount = 0;
    std::vector<int> forcedQ(g1.n), forcedT(g2.n);
    while (bestCandCount == 1 && !(now_ns() >= localDeadlineNs || tb.expired())) {
        int fq = bestQi, ft = bestCandBuf[0];
        cur[fq] = ft; usedQ[fq] = true; usedT[ft] = true;
        qLabelFreq[jointQ[fq]]--; tLabelFreq[jointT[ft]]--;
        forcedQ[forcedCount] = fq; forcedT[forcedCount] = ft;
        forcedCount++; depth++;
        if (static_cast<int>(cur.size()) > static_cast<int>(best.size())) best = cur;
        if (isPruned(static_cast<int>(cur.size()), static_cast<int>(best.size()),
                     qLabelFreq, tLabelFreq, freqSize)) break;

        frontierCount = buildFrontier(g1, cur, usedQ, inFrontier, frontierBuf);
        if (frontierCount == 0) break;
        findBestCandidate(g1, g2, C, cur, usedT, qNLF1, tNLF1, qNLF2, tNLF2, qNLF3, tNLF3,
                          useTwoHopNLF, useThreeHopNLF, frontierCount, frontierBuf,
                          candBuf, bestCandBuf, bestQi, bestCandCount);
        if (bestQi == -1) break;
    }

    if (bestQi != -1 && bestCandCount > 1) {
        int branchLimit = depth < 5 ? bestCandCount : std::min(bestCandCount, 16);
        for (int i = 0; i < branchLimit; ++i) {
            if (now_ns() >= localDeadlineNs || tb.expired()) break;
            int bestTj = bestCandBuf[i];
            cur[bestQi] = bestTj; usedQ[bestQi] = true; usedT[bestTj] = true;
            qLabelFreq[jointQ[bestQi]]--; tLabelFreq[jointT[bestTj]]--;
            mcGregorDFS(g1, g2, C, cur, best, qNLF1, tNLF1, qNLF2, tNLF2, qNLF3, tNLF3,
                        useTwoHopNLF, useThreeHopNLF, tb, localDeadlineNs, depth + 1,
                        usedQ, usedT, candBuf, bestCandBuf,
                        qLabelFreq, tLabelFreq, freqSize,
                        inFrontier, frontierBuf, jointQ, jointT);
            qLabelFreq[jointQ[bestQi]]++; tLabelFreq[jointT[bestTj]]++;
            cur.erase(bestQi); usedQ[bestQi] = false; usedT[bestTj] = false;
        }
    }

    undoForcedAssignments(forcedCount, forcedQ.data(), forcedT.data(), cur, usedQ, usedT,
                          qLabelFreq, tLabelFreq, jointQ, jointT, nullptr);
}

// ---------------------------------------------------------------------------
// McGregor bond-grow (Level 4 -- bond-oriented)
// ---------------------------------------------------------------------------
inline void mcGregorBondGrow(
    const MolGraph& g1, const MolGraph& g2, const ChemOptions& C,
    std::map<int,int>& cur, std::map<int,int>& best,
    const std::vector<std::vector<int>>& qNLF1,
    const std::vector<std::vector<int>>& tNLF1,
    bool useTwoHopNLF, bool useThreeHopNLF,
    const std::vector<std::vector<int>>& qNLF2,
    const std::vector<std::vector<int>>& tNLF2,
    const std::vector<std::vector<int>>& qNLF3,
    const std::vector<std::vector<int>>& tNLF3,
    TimeBudget& tb, int64_t localDeadlineNs, int depth,
    std::vector<bool>& usedQ, std::vector<bool>& usedT,
    int* qLabelFreq, int* tLabelFreq, int freqSize,
    int* q2tMap, std::vector<bool>& inFrontier, int* frontierBuf,
    int* candBuf, int* bestCandBuf,
    const int* jointQ, const int* jointT) {

    using Clock = std::chrono::steady_clock;
    auto now_ns = [&]() {
        return std::chrono::duration_cast<std::chrono::nanoseconds>(
            Clock::now().time_since_epoch()).count();
    };

    if (now_ns() >= localDeadlineNs || tb.expired()) return;
    if (static_cast<int>(cur.size()) > static_cast<int>(best.size())) best = cur;
    if (isPruned(static_cast<int>(cur.size()), static_cast<int>(best.size()),
                 qLabelFreq, tLabelFreq, freqSize)) return;

    // Find best frontier bond
    int bestQk = -1, bestQi_local = -1, bestCandSize = INT_MAX, bestCandCount = 0;
    for (auto& [qi, mappedTi_v] : cur) {
        int mappedTi = q2tMap[qi];
        for (int qk : g1.neighbors[qi]) {
            if (usedQ[qk] || inFrontier[qk]) continue;
            int candCount = 0;
            for (int tk : g2.neighbors[mappedTi]) {
                if (usedT[tk]) continue;
                int qOrd = g1.bondOrder(qi, qk), tOrd = g2.bondOrder(mappedTi, tk);
                if ((qOrd==0) != (tOrd==0)) continue;
                if (qOrd != 0 && !bondsCompatible(g1, qi, qk, g2, mappedTi, tk, C)) continue;
                if (!atomsCompatFast(g1, qk, g2, tk, C)) continue;
                if (!nlfCheckOk(qk, tk, qNLF1, tNLF1, qNLF2, tNLF2, qNLF3, tNLF3,
                                useTwoHopNLF, useThreeHopNLF)) continue;
                bool ok = true;
                for (int qn : g1.neighbors[qk]) {
                    if (qn == qi || !usedQ[qn]) continue;
                    int tn = q2tMap[qn];
                    int qOrd2 = g1.bondOrder(qk, qn), tOrd2 = g2.bondOrder(tk, tn);
                    if ((qOrd2==0) != (tOrd2==0)) { ok = false; break; }
                    if (qOrd2 != 0 && !bondsCompatible(g1, qk, qn, g2, tk, tn, C)) { ok = false; break; }
                }
                if (ok) candBuf[candCount++] = tk;
            }
            if (candCount > 0 && candCount < bestCandSize) {
                bestCandSize = candCount; bestQk = qk; bestQi_local = qi;
                bestCandCount = candCount;
                std::memcpy(bestCandBuf, candBuf, candCount * sizeof(int));
            }
        }
    }

    // Fallback: disconnected extension
    if (bestQk == -1) {
        for (int i = 0; i < g1.n; ++i) {
            if (usedQ[i]) continue;
            int candCount = 0;
            for (int tj = 0; tj < g2.n; ++tj) {
                if (usedT[tj]) continue;
                if (!atomsCompatFast(g1, i, g2, tj, C)) continue;
                if (!nlfCheckOk(i, tj, qNLF1, tNLF1, qNLF2, tNLF2, qNLF3, tNLF3,
                                useTwoHopNLF, useThreeHopNLF)) continue;
                candBuf[candCount++] = tj;
            }
            if (candCount > 0 && candCount < bestCandSize) {
                bestCandSize = candCount; bestQk = i; bestQi_local = -1;
                bestCandCount = candCount;
                std::memcpy(bestCandBuf, candBuf, candCount * sizeof(int));
            }
        }
    }
    if (bestQk == -1) return;

    // Unit propagation
    int forcedCount = 0;
    std::vector<int> forcedQ(g1.n), forcedT(g2.n);
    while (bestCandCount == 1 && !(now_ns() >= localDeadlineNs || tb.expired())) {
        int fq = bestQk, ft = bestCandBuf[0];
        cur[fq] = ft; usedQ[fq] = true; usedT[ft] = true; q2tMap[fq] = ft;
        qLabelFreq[jointQ[fq]]--; tLabelFreq[jointT[ft]]--;
        forcedQ[forcedCount] = fq; forcedT[forcedCount] = ft;
        forcedCount++; depth++;
        if (static_cast<int>(cur.size()) > static_cast<int>(best.size())) best = cur;
        if (isPruned(static_cast<int>(cur.size()), static_cast<int>(best.size()),
                     qLabelFreq, tLabelFreq, freqSize)) break;

        bestQk = -1; bestCandSize = INT_MAX; bestCandCount = 0;
        for (auto& [qi, mappedTi_v] : cur) {
            int mappedTi = q2tMap[qi];
            for (int qk : g1.neighbors[qi]) {
                if (usedQ[qk]) continue;
                int candCount = 0;
                for (int tk : g2.neighbors[mappedTi]) {
                    if (usedT[tk]) continue;
                    int qOrd = g1.bondOrder(qi, qk), tOrd = g2.bondOrder(mappedTi, tk);
                    if ((qOrd==0) != (tOrd==0)) continue;
                    if (qOrd != 0 && !bondsCompatible(g1, qi, qk, g2, mappedTi, tk, C)) continue;
                    if (!atomsCompatFast(g1, qk, g2, tk, C)) continue;
                    if (!nlfCheckOk(qk, tk, qNLF1, tNLF1, qNLF2, tNLF2, qNLF3, tNLF3,
                                    useTwoHopNLF, useThreeHopNLF)) continue;
                    bool ok = true;
                    for (int qn : g1.neighbors[qk]) {
                        if (qn == qi || !usedQ[qn]) continue;
                        int tn = q2tMap[qn];
                        int qOrd2 = g1.bondOrder(qk, qn), tOrd2 = g2.bondOrder(tk, tn);
                        if ((qOrd2==0) != (tOrd2==0)) { ok = false; break; }
                        if (qOrd2 != 0 && !bondsCompatible(g1, qk, qn, g2, tk, tn, C)) { ok = false; break; }
                    }
                    if (ok) candBuf[candCount++] = tk;
                }
                if (candCount > 0 && candCount < bestCandSize) {
                    bestCandSize = candCount; bestQk = qk; bestQi_local = qi;
                    bestCandCount = candCount;
                    std::memcpy(bestCandBuf, candBuf, candCount * sizeof(int));
                }
            }
        }
        if (bestQk == -1) break;
    }

    if (bestQk != -1 && bestCandCount > 1) {
        int branchLimit = depth < 5 ? bestCandCount : std::min(bestCandCount, 16);
        for (int i = 0; i < branchLimit; ++i) {
            if (now_ns() >= localDeadlineNs || tb.expired()) break;
            int btj = bestCandBuf[i];
            cur[bestQk] = btj; usedQ[bestQk] = true; usedT[btj] = true; q2tMap[bestQk] = btj;
            qLabelFreq[jointQ[bestQk]]--; tLabelFreq[jointT[btj]]--;
            mcGregorBondGrow(g1, g2, C, cur, best, qNLF1, tNLF1, useTwoHopNLF, useThreeHopNLF,
                             qNLF2, tNLF2, qNLF3, tNLF3, tb, localDeadlineNs, depth + 1,
                             usedQ, usedT, qLabelFreq, tLabelFreq, freqSize, q2tMap,
                             inFrontier, frontierBuf, candBuf, bestCandBuf, jointQ, jointT);
            qLabelFreq[jointQ[bestQk]]++; tLabelFreq[jointT[btj]]++;
            cur.erase(bestQk); usedQ[bestQk] = false; usedT[btj] = false; q2tMap[bestQk] = -1;
        }
    }

    undoForcedAssignments(forcedCount, forcedQ.data(), forcedT.data(), cur, usedQ, usedT,
                          qLabelFreq, tLabelFreq, jointQ, jointT, q2tMap);
}

// ---------------------------------------------------------------------------
// McGregor extend entry point (Level 4)
// ---------------------------------------------------------------------------
inline std::map<int,int> mcGregorExtend(
    const MolGraph& g1, const MolGraph& g2,
    const std::map<int,int>& seed, const ChemOptions& C,
    TimeBudget& tb, int64_t localMillis,
    bool useTwoHopNLF, bool useThreeHopNLF,
    bool connectedOnly = true) {

    using Clock = std::chrono::steady_clock;
    int64_t localDeadlineNs = std::chrono::duration_cast<std::chrono::nanoseconds>(
        (Clock::now() + std::chrono::milliseconds(localMillis)).time_since_epoch()).count();

    std::map<int,int> best = seed;
    auto qNLF1 = buildNLF1(g1), tNLF1 = buildNLF1(g2);
    std::vector<std::vector<int>> qNLF2, tNLF2, qNLF3, tNLF3;
    if (useTwoHopNLF) { qNLF2 = buildNLF2(g1); tNLF2 = buildNLF2(g2); }
    if (useThreeHopNLF) { qNLF3 = buildNLF3(g1); tNLF3 = buildNLF3(g2); }

    int n1 = g1.n, n2 = g2.n;
    std::vector<bool> usedQ(n1, false), usedT(n2, false);
    std::vector<int> candBuf(n2), bestCandBuf(n2);
    for (auto& [k,v] : seed) { usedQ[k] = true; usedT[v] = true; }

    int maxLabel = 0;
    for (int i = 0; i < n1; ++i) maxLabel = std::max(maxLabel, g1.label[i]);
    for (int j = 0; j < n2; ++j) maxLabel = std::max(maxLabel, g2.label[j]);
    int freqSize = maxLabel + 1;
    std::vector<int> qLabelFreq(freqSize, 0), tLabelFreq(freqSize, 0);
    std::vector<int> jointQ(n1), jointT(n2);
    for (int i = 0; i < n1; ++i) { jointQ[i] = g1.label[i]; if (!usedQ[i]) qLabelFreq[jointQ[i]]++; }
    for (int j = 0; j < n2; ++j) { jointT[j] = g2.label[j]; if (!usedT[j]) tLabelFreq[jointT[j]]++; }

    std::vector<bool> inFrontier(n1, false);
    std::vector<int> frontierBuf(n1);

    // Fast bail-out
    if (!seed.empty()) {
        bool hasExtensible = false;
        for (auto& [k,v] : seed) {
            for (int nb : g1.neighbors[k]) {
                if (usedQ[nb]) continue;
                for (int tj = 0; tj < n2; ++tj) {
                    if (usedT[tj]) continue;
                    if (atomsCompatFast(g1, nb, g2, tj, C)) { hasExtensible = true; goto bail_done; }
                }
            }
        }
        bail_done:
        if (!hasExtensible && connectedOnly) return best;
        // If disconnected MCS, skip bail-out — let frontier jump to new component
    }

    // Bond-growth first pass for larger molecules
    if (!seed.empty() && n2 >= 20) {
        std::vector<int> q2tMap(n1, -1);
        for (auto& [k,v] : seed) q2tMap[k] = v;
        std::map<int,int> bondBest = seed;
        int64_t bondDeadlineNs = std::chrono::duration_cast<std::chrono::nanoseconds>(
            (Clock::now() + std::chrono::milliseconds(std::max<int64_t>(1, std::min(localMillis / 10, (int64_t)20)))).time_since_epoch()).count();

        auto usedQCopy = usedQ;
        auto usedTCopy = usedT;
        auto qLFCopy = qLabelFreq;
        auto tLFCopy = tLabelFreq;
        auto inFCopy = inFrontier;
        std::map<int,int> curCopy = seed;

        mcGregorBondGrow(g1, g2, C, curCopy, bondBest, qNLF1, tNLF1,
                         useTwoHopNLF, useThreeHopNLF, qNLF2, tNLF2, qNLF3, tNLF3,
                         tb, bondDeadlineNs, 0,
                         usedQCopy, usedTCopy, qLFCopy.data(), tLFCopy.data(),
                         freqSize, q2tMap.data(), inFCopy, frontierBuf.data(),
                         candBuf.data(), bestCandBuf.data(), jointQ.data(), jointT.data());
        std::fill(inFrontier.begin(), inFrontier.end(), false);
        if (bondBest.size() > best.size()) best = bondBest;
    }

    {
        std::map<int,int> curDFS = seed;
        mcGregorDFS(g1, g2, C, curDFS, best, qNLF1, tNLF1, qNLF2, tNLF2, qNLF3, tNLF3,
                    useTwoHopNLF, useThreeHopNLF, tb, localDeadlineNs, 0,
                    usedQ, usedT, candBuf.data(), bestCandBuf.data(),
                    qLabelFreq.data(), tLabelFreq.data(), freqSize,
                    inFrontier, frontierBuf.data(), jointQ.data(), jointT.data());
    }
    return best;
}

// ===========================================================================
// GraphBuilder -- seeds for the MCS funnel
// ===========================================================================
class GraphBuilder {
    const MolGraph& g1_;
    const MolGraph& g2_;
    const ChemOptions& C_;
    bool induced_;

    static constexpr int64_t MAX_NODE_LIMIT  = 500000;
    static constexpr int64_t SEED_EXTEND_NODE_LIMIT = 100000;
    static constexpr int64_t MCSPLIT_NODE_LIMIT = 200000;

    struct PGNode { int qi, tj; };

public:
    GraphBuilder(const MolGraph& g1, const MolGraph& g2,
                 const ChemOptions& C, bool induced)
        : g1_(g1), g2_(g2), C_(C), induced_(induced) {}

    // -- Greedy bond extend (used by seed-and-extend) ----------------------
    static int greedyBondExtend(const MolGraph& g1, const MolGraph& g2,
                                 const ChemOptions& C,
                                 int* q2t, int* t2q, int n1, int n2, bool induced) {
        int mapSize = 0;
        for (int i = 0; i < n1; ++i) if (q2t[i] >= 0) mapSize++;
        bool progress = true;
        while (progress) {
            progress = false;
            for (int qi = 0; qi < n1; ++qi) {
                if (q2t[qi] >= 0) continue;
                int bestTj = -1, bestScore = -1;
                for (int nb : g1.neighbors[qi]) {
                    if (q2t[nb] < 0) continue;
                    int tNb = q2t[nb];
                    for (int tj : g2.neighbors[tNb]) {
                        if (t2q[tj] >= 0) continue;
                        if (!atomsCompatFast(g1, qi, g2, tj, C)) continue;
                        if (!bondsCompatible(g1, qi, nb, g2, tj, tNb, C)) continue;
                        bool consistent = true;
                        for (int qk : g1.neighbors[qi]) {
                            if (qk == nb || q2t[qk] < 0) continue;
                            int tk = q2t[qk];
                            int qOrd = g1.bondOrder(qi, qk), tOrd = g2.bondOrder(tj, tk);
                            if (qOrd != 0 && tOrd != 0) {
                                if (!bondsCompatible(g1, qi, qk, g2, tj, tk, C)) { consistent = false; break; }
                            } else if (induced && ((qOrd!=0) != (tOrd!=0))) { consistent = false; break; }
                        }
                        if (!consistent) continue;
                        int score = (g2.ring[tj] && g1.ring[qi] ? 50 : 0) + std::min(g1.degree[qi], g2.degree[tj]);
                        if (score > bestScore) { bestScore = score; bestTj = tj; }
                    }
                }
                if (bestTj >= 0) { q2t[qi] = bestTj; t2q[bestTj] = qi; mapSize++; progress = true; }
            }
        }
        return mapSize;
    }

    // -- Backtrack bond extend (used by seed-and-extend) -------------------
    static void backtrackBondExtend(
        const MolGraph& g1, const MolGraph& g2, const ChemOptions& C,
        int* q2t, int* t2q, int n1, int n2, bool induced,
        int* bestQ2T, int& bestSize, TimeBudget& tb, int64_t& nodeCount, int64_t nodeLimit) {
        int curSize = 0;
        for (int i = 0; i < n1; ++i) if (q2t[i] >= 0) curSize++;
        if (curSize > bestSize) { bestSize = curSize; std::memcpy(bestQ2T, q2t, n1 * sizeof(int)); }
        if (nodeCount > nodeLimit || tb.expired()) return;

        int frontier = 0;
        for (int qi = 0; qi < n1; ++qi) {
            if (q2t[qi] >= 0) continue;
            for (int nb : g1.neighbors[qi]) if (q2t[nb] >= 0) { frontier++; break; }
        }
        if (curSize + frontier <= bestSize) return;

        int bestQi = -1, bestConstraint = -1;
        for (int qi = 0; qi < n1; ++qi) {
            if (q2t[qi] >= 0) continue;
            int mappedNb = 0;
            for (int nb : g1.neighbors[qi]) if (q2t[nb] >= 0) mappedNb++;
            if (mappedNb == 0) continue;
            int constraint = mappedNb * 100 + (g1.ring[qi] ? 50 : 0) + g1.degree[qi];
            if (constraint > bestConstraint) { bestConstraint = constraint; bestQi = qi; }
        }
        if (bestQi < 0) return;

        int qi = bestQi;
        for (int nb : g1.neighbors[qi]) {
            if (q2t[nb] < 0) continue;
            for (int tj : g2.neighbors[q2t[nb]]) {
                if (t2q[tj] >= 0) continue;
                nodeCount++;
                if (nodeCount > nodeLimit || tb.expired()) return;
                if (!atomsCompatFast(g1, qi, g2, tj, C)) continue;
                bool consistent = true;
                for (int qk : g1.neighbors[qi]) {
                    if (q2t[qk] < 0) continue;
                    int tk = q2t[qk];
                    int qOrd = g1.bondOrder(qi, qk), tOrd = g2.bondOrder(tj, tk);
                    if (qOrd != 0 && tOrd != 0) {
                        if (!bondsCompatible(g1, qi, qk, g2, tj, tk, C)) { consistent = false; break; }
                    } else if (induced && ((qOrd!=0) != (tOrd!=0))) { consistent = false; break; }
                }
                if (!consistent) continue;
                q2t[qi] = tj; t2q[tj] = qi;
                backtrackBondExtend(g1, g2, C, q2t, t2q, n1, n2, induced, bestQ2T, bestSize, tb, nodeCount, nodeLimit);
                q2t[qi] = -1; t2q[tj] = -1;
                if (nodeCount > nodeLimit || tb.expired()) return;
            }
        }
    }

    // -- Seed-and-extend (Level 1.5) ---------------------------------------
    std::map<int,int> seedExtendMCS(TimeBudget& tb, int upperBound) {
        int n1 = g1_.n, n2 = g2_.n;
        if (n1 == 0 || n2 == 0) return {};

        int maxLabel = 0;
        for (int i = 0; i < n1; ++i) maxLabel = std::max(maxLabel, g1_.label[i]);
        for (int j = 0; j < n2; ++j) maxLabel = std::max(maxLabel, g2_.label[j]);
        std::vector<int> labelFreqG1(maxLabel + 1, 0), labelFreqG2(maxLabel + 1, 0);
        for (int i = 0; i < n1; ++i) labelFreqG1[g1_.label[i]]++;
        for (int j = 0; j < n2; ++j) labelFreqG2[g2_.label[j]]++;

        // Precompute compatible targets per query atom
        std::vector<std::vector<int>> compatT(n1);
        for (int i = 0; i < n1; ++i) {
            for (int j = 0; j < n2; ++j)
                if (atomsCompatFast(g1_, i, g2_, j, C_)) compatT[i].push_back(j);
        }

        // Collect bonds
        struct Bond { int u, v; };
        std::vector<Bond> g1Bonds;
        for (int i = 0; i < n1; ++i)
            for (int nb : g1_.neighbors[i])
                if (nb > i) g1Bonds.push_back({i, nb});

        int g1BondCount = static_cast<int>(g1Bonds.size());

        // Score and sort seeds
        std::vector<std::pair<int,int>> seedOrder(g1BondCount);
        for (int b = 0; b < g1BondCount; ++b) {
            int u = g1Bonds[b].u, v = g1Bonds[b].v;
            int totalAtoms = n1 + n2;
            int uFreq = labelFreqG1[g1_.label[u]]
                + (g1_.label[u] < static_cast<int>(labelFreqG2.size()) ? labelFreqG2[g1_.label[u]] : 0);
            int vFreq = labelFreqG1[g1_.label[v]]
                + (g1_.label[v] < static_cast<int>(labelFreqG2.size()) ? labelFreqG2[g1_.label[v]] : 0);
            int score = (totalAtoms * 2) / std::max(1, uFreq) + (totalAtoms * 2) / std::max(1, vFreq)
                + (n2 * 2) / std::max(1, static_cast<int>(compatT[u].size()))
                + (n2 * 2) / std::max(1, static_cast<int>(compatT[v].size()))
                + g1_.degree[u] + g1_.degree[v] + (g1_.ring[u] ? 10 : 0) + (g1_.ring[v] ? 10 : 0);
            seedOrder[b] = {b, score};
        }
        std::sort(seedOrder.begin(), seedOrder.end(),
            [](auto& a, auto& b) { return a.second > b.second; });

        std::vector<int> bestQ2T(n1, -1);
        int bestSize = 0;
        int64_t nodeCount = 0;
        int minN = std::min(n1, n2);
        int maxSeeds = std::min(g1BondCount, 10);
        std::vector<bool> atomUsedAsSeed(n1, false);
        std::set<int64_t> triedOrbitPairs;
        int seedsTried = 0;

        for (int si = 0; si < g1BondCount && seedsTried < maxSeeds; ++si) {
            if (tb.expired() || nodeCount > MAX_NODE_LIMIT) break;
            int bondIdx = seedOrder[si].first;
            int qu = g1Bonds[bondIdx].u, qv = g1Bonds[bondIdx].v;
            int oA = std::min(g1_.orbit[qu], g1_.orbit[qv]);
            int oB = std::max(g1_.orbit[qu], g1_.orbit[qv]);
            int64_t pairKey = (static_cast<int64_t>(oA) << 32) | oB;
            if (!triedOrbitPairs.insert(pairKey).second) continue;
            if (atomUsedAsSeed[qu] && atomUsedAsSeed[qv]) continue;
            atomUsedAsSeed[qu] = true; atomUsedAsSeed[qv] = true; seedsTried++;

            // Try qu->ta, qv->tb2 where ta compatible with qu, tb2 neighbor of ta compatible with qv
            for (int ta : compatT[qu]) {
                if (tb.expired() || nodeCount > MAX_NODE_LIMIT) break;
                for (int tb2 : g2_.neighbors[ta]) {
                    nodeCount++;
                    if (nodeCount > MAX_NODE_LIMIT || tb.expired()) break;
                    if (!atomsCompatFast(g1_, qv, g2_, tb2, C_)) continue;
                    if (!bondsCompatible(g1_, qu, qv, g2_, ta, tb2, C_)) continue;
                    std::vector<int> q2t(n1, -1), t2q(n2, -1);
                    q2t[qu] = ta; t2q[ta] = qu; q2t[qv] = tb2; t2q[tb2] = qv;
                    int mapSize = greedyBondExtend(g1_, g2_, C_, q2t.data(), t2q.data(), n1, n2, induced_);
                    nodeCount += mapSize;
                    if (mapSize > bestSize) { bestSize = mapSize; std::memcpy(bestQ2T.data(), q2t.data(), n1 * sizeof(int)); }
                }
            }
            // Reverse: try qv->ta, qu->tb2
            for (int ta : compatT[qv]) {
                if (tb.expired() || nodeCount > MAX_NODE_LIMIT) break;
                for (int tb2 : g2_.neighbors[ta]) {
                    nodeCount++;
                    if (nodeCount > MAX_NODE_LIMIT || tb.expired()) break;
                    if (!atomsCompatFast(g1_, qu, g2_, tb2, C_)) continue;
                    if (!bondsCompatible(g1_, qu, qv, g2_, tb2, ta, C_)) continue;
                    std::vector<int> q2t(n1, -1), t2q(n2, -1);
                    q2t[qu] = tb2; t2q[tb2] = qu; q2t[qv] = ta; t2q[ta] = qv;
                    int mapSize = greedyBondExtend(g1_, g2_, C_, q2t.data(), t2q.data(), n1, n2, induced_);
                    nodeCount += mapSize;
                    if (mapSize > bestSize) { bestSize = mapSize; std::memcpy(bestQ2T.data(), q2t.data(), n1 * sizeof(int)); }
                }
            }
            if (bestSize >= upperBound || bestSize >= minN) break;
            if (bestSize >= (upperBound * 19 / 20) && nodeCount > SEED_EXTEND_NODE_LIMIT / 2) break;
        }

        // Backtrack refinement
        if (bestSize > 0 && bestSize < minN && !tb.expired() && nodeCount < MAX_NODE_LIMIT) {
            std::vector<int> q2t(n1, -1), t2q(n2, -1);
            for (int i = 0; i < n1; ++i) if (bestQ2T[i] >= 0) { q2t[i] = bestQ2T[i]; t2q[bestQ2T[i]] = i; }
            backtrackBondExtend(g1_, g2_, C_, q2t.data(), t2q.data(), n1, n2, induced_,
                                bestQ2T.data(), bestSize, tb, nodeCount, MAX_NODE_LIMIT);
            bestSize = 0;
            for (int i = 0; i < n1; ++i) if (bestQ2T[i] >= 0) bestSize++;
        }

        std::map<int,int> result;
        for (int i = 0; i < n1; ++i) if (bestQ2T[i] >= 0) result[i] = bestQ2T[i];
        return result;
    }

    // -- McSplit (Level 2) -------------------------------------------------
private:
    static bool checkBondCompat(const MolGraph& g1, const MolGraph& g2,
                                 const ChemOptions& C, bool induced,
                                 int qi, int tj, const int* q2t) {
        for (int qk : g1.neighbors[qi]) {
            if (q2t[qk] < 0) continue;
            int tk = q2t[qk];
            int qOrd = g1.bondOrder(qi, qk), tOrd = g2.bondOrder(tj, tk);
            if (qOrd != 0 && tOrd != 0) {
                if (!bondsCompatible(g1, qi, qk, g2, tj, tk, C)) return false;
            } else if (induced && ((qOrd!=0) != (tOrd!=0))) return false;
        }
        return true;
    }

    // Hardware-accelerated bitset for McSplit partition classes.
    // Uses uint64_t words + ctz64 for ~64x faster nextSetBit vs vector<bool>.
    struct BitClass {
        std::vector<uint64_t> words;
        int card;
        int n_bits;
        BitClass() : card(0), n_bits(0) {}
        explicit BitClass(int n) : words((n + 63) / 64, 0), card(0), n_bits(n) {}
        void set(int i) {
            if (!(words[i >> 6] & (1ULL << (i & 63)))) {
                words[i >> 6] |= (1ULL << (i & 63));
                card++;
            }
        }
        void clear(int i) {
            if (words[i >> 6] & (1ULL << (i & 63))) {
                words[i >> 6] &= ~(1ULL << (i & 63));
                card--;
            }
        }
        bool get(int i) const { return (words[i >> 6] & (1ULL << (i & 63))) != 0; }
        bool empty() const { return card == 0; }
        int cardinality() const { return card; }
        int nextSetBit(int from) const {
            if (from >= n_bits) return -1;
            int w = from >> 6;
            uint64_t mask = ~0ULL << (from & 63);
            uint64_t bits = words[w] & mask;
            if (bits) return (w << 6) | ctz64(bits);
            int nw = static_cast<int>(words.size());
            for (++w; w < nw; ++w)
                if (words[w]) return (w << 6) | ctz64(words[w]);
            return -1;
        }
        BitClass andWith(const std::vector<bool>& adj, int n) const {
            BitClass r(n);
            for (int i = nextSetBit(0); i >= 0; i = nextSetBit(i + 1))
                if (adj[i]) r.set(i);
            return r;
        }
        BitClass andNotWith(const std::vector<bool>& adj, int n) const {
            BitClass r(n);
            for (int i = nextSetBit(0); i >= 0; i = nextSetBit(i + 1))
                if (!adj[i]) r.set(i);
            return r;
        }
    };

    static void mcSplitRecurse(
        const MolGraph& g1, const MolGraph& g2, const ChemOptions& C, bool induced,
        TimeBudget& tb,
        std::vector<BitClass>& qSets, std::vector<BitClass>& tSets, int numClasses,
        int* q2t, int* t2q, int curSize, int upperBound,
        int* bestQ2T, int& bestSize, int64_t& nodeCount,
        int n1, int n2, int depth, int maxDepth) {

        nodeCount++;
        if (nodeCount > MAX_NODE_LIMIT) return;
        if ((nodeCount & 15) == 0 && tb.expiredNow()) return;
        if (curSize > bestSize) { bestSize = curSize; std::memcpy(bestQ2T, q2t, n1 * sizeof(int)); }
        if (curSize + upperBound <= bestSize || depth >= maxDepth) return;

        if (curSize > 0) {
            bool canExtend = false;
            for (int c = 0; c < numClasses && !canExtend; ++c)
                if (!qSets[c].empty() && !tSets[c].empty()) canExtend = true;
            if (!canExtend) return;
        }

        // Select most constrained class
        int bestClass = -1, bestMin = INT_MAX, bestClassQC = 0, bestClassTC = 0;
        for (int c = 0; c < numClasses; ++c) {
            int qc = qSets[c].cardinality(), tc = tSets[c].cardinality();
            if (qc == 0 || tc == 0) continue;
            int m = std::min(qc, tc);
            if (m < bestMin) { bestMin = m; bestClass = c; bestClassQC = qc; bestClassTC = tc; }
        }
        if (bestClass == -1) return;

        // Bidirectional selection
        bool branchFromTarget = bestClassTC < bestClassQC;

        if (!branchFromTarget) {
            // Select qi with connectivity-aware ordering
            int qi = -1, qiBestScore = -1;
            for (int v = qSets[bestClass].nextSetBit(0); v >= 0; v = qSets[bestClass].nextSetBit(v + 1)) {
                bool conn = false;
                for (int nb : g1.neighbors[v]) if (q2t[nb] >= 0) { conn = true; break; }
                int score = (conn ? 1000 : 0) + (g1.ring[v] ? 100 : 0) + g1.degree[v] * 10;
                if (score > qiBestScore) { qiBestScore = score; qi = v; }
            }

            // RRSplit: try each orbit of target
            std::unordered_set<int> triedOrbits;
            for (int tj = tSets[bestClass].nextSetBit(0); tj >= 0; tj = tSets[bestClass].nextSetBit(tj + 1)) {
                nodeCount++;
                if (nodeCount > MAX_NODE_LIMIT || ((nodeCount & 15) == 0 && tb.expiredNow())) return;
                if (!triedOrbits.insert(g2.orbit[tj]).second) continue;

                if (!checkBondCompat(g1, g2, C, induced, qi, tj, q2t)) continue;

                q2t[qi] = tj; t2q[tj] = qi;
                refineAndRecurse(g1, g2, C, induced, tb, qSets, tSets, numClasses,
                                 q2t, t2q, curSize, bestQ2T, bestSize, nodeCount, n1, n2, depth, maxDepth, qi, tj);
                q2t[qi] = -1; t2q[tj] = -1;
            }

            // Skip qi branch
            mcSplitSkipVertex(g1, g2, C, induced, tb, qSets, tSets, numClasses,
                              q2t, t2q, curSize, bestQ2T, bestSize, nodeCount, n1, n2, depth, maxDepth,
                              bestClass, qi, true);
        } else {
            int tj = -1, tjBestScore = -1;
            for (int v = tSets[bestClass].nextSetBit(0); v >= 0; v = tSets[bestClass].nextSetBit(v + 1)) {
                bool conn = false;
                for (int nb : g2.neighbors[v]) if (t2q[nb] >= 0) { conn = true; break; }
                int score = (conn ? 1000 : 0) + (g2.ring[v] ? 100 : 0) + g2.degree[v] * 10;
                if (score > tjBestScore) { tjBestScore = score; tj = v; }
            }

            std::unordered_set<int> triedOrbits;
            for (int qi = qSets[bestClass].nextSetBit(0); qi >= 0; qi = qSets[bestClass].nextSetBit(qi + 1)) {
                nodeCount++;
                if (nodeCount > MAX_NODE_LIMIT || ((nodeCount & 15) == 0 && tb.expiredNow())) return;
                if (!triedOrbits.insert(g1.orbit[qi]).second) continue;

                // Check bond compat from target side
                bool bondOk = true;
                for (int tk : g2.neighbors[tj]) {
                    if (t2q[tk] < 0) continue;
                    int qk = t2q[tk];
                    int qOrd = g1.bondOrder(qi, qk), tOrd = g2.bondOrder(tj, tk);
                    if (qOrd != 0 && tOrd != 0) {
                        if (!bondsCompatible(g1, qi, qk, g2, tj, tk, C)) { bondOk = false; break; }
                    } else if (induced && ((qOrd!=0) != (tOrd!=0))) { bondOk = false; break; }
                }
                if (!bondOk) continue;

                q2t[qi] = tj; t2q[tj] = qi;
                refineAndRecurse(g1, g2, C, induced, tb, qSets, tSets, numClasses,
                                 q2t, t2q, curSize, bestQ2T, bestSize, nodeCount, n1, n2, depth, maxDepth, qi, tj);
                q2t[qi] = -1; t2q[tj] = -1;
            }

            mcSplitSkipVertex(g1, g2, C, induced, tb, qSets, tSets, numClasses,
                              q2t, t2q, curSize, bestQ2T, bestSize, nodeCount, n1, n2, depth, maxDepth,
                              bestClass, tj, false);
        }
    }

    static void refineAndRecurse(
        const MolGraph& g1, const MolGraph& g2, const ChemOptions& C, bool induced,
        TimeBudget& tb,
        std::vector<BitClass>& qSets, std::vector<BitClass>& tSets, int numClasses,
        int* q2t, int* t2q, int curSize,
        int* bestQ2T, int& bestSize, int64_t& nodeCount,
        int n1, int n2, int depth, int maxDepth, int qi, int tj) {

        // Build adjacency masks
        std::vector<bool> qiAdj(n1, false), tjAdj(n2, false);
        for (int nb : g1.neighbors[qi]) qiAdj[nb] = true;
        for (int nb : g2.neighbors[tj]) tjAdj[nb] = true;

        std::vector<BitClass> newQ, newT;
        int newUB = 0;
        newQ.reserve(numClasses * 2);
        newT.reserve(numClasses * 2);

        for (int c = 0; c < numClasses; ++c) {
            if (qSets[c].empty() || tSets[c].empty()) continue;
            BitClass qAdj = qSets[c].andWith(qiAdj, n1);
            qAdj.clear(qi);
            BitClass qNon = qSets[c].andNotWith(qiAdj, n1);
            qNon.clear(qi);
            BitClass tAdj = tSets[c].andWith(tjAdj, n2);
            tAdj.clear(tj);
            BitClass tNon = tSets[c].andNotWith(tjAdj, n2);
            tNon.clear(tj);

            if (qAdj.cardinality() > 0 && tAdj.cardinality() > 0) {
                newUB += std::min(qAdj.cardinality(), tAdj.cardinality());
                newQ.push_back(std::move(qAdj));
                newT.push_back(std::move(tAdj));
            }
            if (qNon.cardinality() > 0 && tNon.cardinality() > 0) {
                newUB += std::min(qNon.cardinality(), tNon.cardinality());
                newQ.push_back(std::move(qNon));
                newT.push_back(std::move(tNon));
            }
        }

        if (curSize + 1 + newUB > bestSize) {
            int newNum = static_cast<int>(newQ.size());
            mcSplitRecurse(g1, g2, C, induced, tb, newQ, newT, newNum,
                           q2t, t2q, curSize + 1, newUB,
                           bestQ2T, bestSize, nodeCount, n1, n2, depth + 1, maxDepth);
        }
    }

    static void mcSplitSkipVertex(
        const MolGraph& g1, const MolGraph& g2, const ChemOptions& C, bool induced,
        TimeBudget& tb,
        std::vector<BitClass>& qSets, std::vector<BitClass>& tSets, int numClasses,
        int* q2t, int* t2q, int curSize,
        int* bestQ2T, int& bestSize, int64_t& nodeCount,
        int n1, int n2, int depth, int maxDepth,
        int bestClass, int vertex, bool isQuery) {

        std::vector<BitClass> skipQ, skipT;
        int skipUB = 0;
        for (int c = 0; c < numClasses; ++c) {
            if (qSets[c].empty() || tSets[c].empty()) continue;
            if (c == bestClass) {
                BitClass reduced = isQuery ? qSets[c] : qSets[c];
                BitClass reducedT = isQuery ? tSets[c] : tSets[c];
                // Copy and remove vertex
                if (isQuery) { reduced = qSets[c]; reduced.clear(vertex); }
                else { reducedT = tSets[c]; reducedT.clear(vertex); }
                BitClass& checkSet = isQuery ? reduced : reducedT;
                if (!checkSet.empty()) {
                    int qCard = isQuery ? reduced.cardinality() : qSets[c].cardinality();
                    int tCard = isQuery ? tSets[c].cardinality() : reducedT.cardinality();
                    skipUB += std::min(qCard, tCard);
                    skipQ.push_back(isQuery ? reduced : qSets[c]);
                    skipT.push_back(isQuery ? tSets[c] : reducedT);
                }
            } else {
                skipUB += std::min(qSets[c].cardinality(), tSets[c].cardinality());
                skipQ.push_back(qSets[c]);
                skipT.push_back(tSets[c]);
            }
        }
        if (curSize + skipUB > bestSize) {
            int skipNum = static_cast<int>(skipQ.size());
            mcSplitRecurse(g1, g2, C, induced, tb, skipQ, skipT, skipNum,
                           q2t, t2q, curSize, skipUB,
                           bestQ2T, bestSize, nodeCount, n1, n2, depth + 1, maxDepth);
        }
    }

public:
    std::map<int,int> mcSplitSeed(TimeBudget& tb, int64_t& nodeCountOut) {
        int n1 = g1_.n, n2 = g2_.n;
        if (n1 == 0 || n2 == 0) return {};

        bool useMorgan = n1 >= 30 && n2 >= 30;
        if (useMorgan) {
            std::unordered_set<int> qDistinct;
            for (int i = 0; i < n1; ++i) qDistinct.insert(g1_.morganRank[i]);
            if (static_cast<int>(qDistinct.size()) > n1 * 3 / 4) useMorgan = false;
        }

        std::unordered_map<int, std::vector<int>> qGroups, tGroups;
        for (int i = 0; i < n1; ++i)
            qGroups[useMorgan ? g1_.morganRank[i] : g1_.label[i]].push_back(i);
        for (int j = 0; j < n2; ++j)
            tGroups[useMorgan ? g2_.morganRank[j] : g2_.label[j]].push_back(j);

        std::vector<BitClass> initQSets, initTSets;
        for (auto& [qlabel, qList] : qGroups)
            for (auto& [tlabel, tList] : tGroups) {
                if (qList.empty() || tList.empty()) continue;
                if (!atomsCompatFast(g1_, qList[0], g2_, tList[0], C_)) continue;
                BitClass qbs(n1), tbs(n2);
                for (int v : qList) qbs.set(v);
                for (int v : tList) tbs.set(v);
                initQSets.push_back(std::move(qbs));
                initTSets.push_back(std::move(tbs));
            }
        if (initQSets.empty()) return {};

        int numClasses = static_cast<int>(initQSets.size());
        int initUB = 0;
        for (int c = 0; c < numClasses; ++c)
            initUB += std::min(initQSets[c].cardinality(), initTSets[c].cardinality());

        std::vector<int> q2t(n1, -1), t2q(n2, -1);
        std::vector<int> bestQ2T(n1, -1);
        int bestSize = 0;
        int64_t nodeCount = 0;

        mcSplitRecurse(g1_, g2_, C_, induced_, tb, initQSets, initTSets, numClasses,
                       q2t.data(), t2q.data(), 0, initUB,
                       bestQ2T.data(), bestSize, nodeCount, n1, n2, 0, std::min(n1, n2) + 1);

        nodeCountOut = nodeCount;
        std::map<int,int> seed;
        for (int i = 0; i < n1; ++i) if (bestQ2T[i] >= 0) seed[i] = bestQ2T[i];
        return seed;
    }

    // -- Bron-Kerbosch + Tomita (Level 3) ----------------------------------
private:
    static void greedyClique(const std::vector<std::vector<uint64_t>>& adj, int N, int words,
                             std::vector<int>& clique) {
        int bestStart = 0, bestDeg = 0;
        for (int i = 0; i < N; ++i) {
            int deg = 0;
            for (int w = 0; w < words; ++w) deg += popcount64(adj[i][w]);
            if (deg > bestDeg) { bestDeg = deg; bestStart = i; }
        }
        clique.clear();
        clique.push_back(bestStart);
        std::vector<uint64_t> cand = adj[bestStart];
        while (true) {
            int bestV = -1, bestConn = -1;
            for (int w = 0; w < words; ++w) {
                uint64_t bits = cand[w];
                while (bits) {
                    int bit = ctz64(bits);
                    int v = (w << 6) | bit;
                    int conn = 0;
                    for (int cw = 0; cw < words; ++cw) conn += popcount64(adj[v][cw] & cand[cw]);
                    if (conn > bestConn) { bestConn = conn; bestV = v; }
                    bits &= bits - 1;
                }
            }
            if (bestV == -1) break;
            clique.push_back(bestV);
            for (int w = 0; w < words; ++w) cand[w] &= adj[bestV][w];
        }
    }

    static int colorBound(const uint64_t* P, const std::vector<std::vector<uint64_t>>& adj,
                           int words, int N) {
        std::vector<int> color(N, -1);
        int maxColor = 0;
        for (int w = 0; w < words; ++w) {
            uint64_t bits = P[w];
            while (bits) {
                int bit = ctz64(bits);
                int v = (w << 6) | bit;
                uint64_t usedColors = 0;
                for (int nw = 0; nw < words; ++nw) {
                    uint64_t nbits = adj[v][nw] & P[nw];
                    while (nbits) {
                        int nbit = ctz64(nbits);
                        int u = (nw << 6) | nbit;
                        if (color[u] >= 0 && color[u] < 64) usedColors |= 1ULL << color[u];
                        nbits &= nbits - 1;
                    }
                }
                color[v] = ctz64(~usedColors);
                if (color[v] > maxColor) maxColor = color[v];
                bits &= bits - 1;
            }
        }
        return maxColor + 1;
    }

    static std::vector<int> iterateBits(const uint64_t* words_ptr, int N, int words) {
        std::vector<int> result;
        for (int w = 0; w < words; ++w) {
            uint64_t bits = words_ptr[w];
            while (bits) {
                int bit = ctz64(bits);
                int v = (w << 6) | bit;
                if (v < N) result.push_back(v);
                bits &= bits - 1;
            }
        }
        return result;
    }

    void bronKerboschPivot(
        uint64_t* R, uint64_t* P, uint64_t* X,
        std::vector<std::vector<uint64_t>>& adj,
        std::vector<int>& currentBest, int N, int words,
        const int* equivClass, TimeBudget& tb,
        std::vector<std::vector<uint64_t>>& rStack,
        std::vector<std::vector<uint64_t>>& pStack,
        std::vector<std::vector<uint64_t>>& xStack,
        int depth, const std::vector<PGNode>& nodes) {

        if (tb.expired()) return;
        int rSize = 0, pSize = 0, xSize = 0;
        for (int w = 0; w < words; ++w) {
            rSize += popcount64(R[w]);
            pSize += popcount64(P[w]);
            xSize += popcount64(X[w]);
        }
        if (pSize == 0 && xSize == 0) {
            if (rSize > static_cast<int>(currentBest.size()))
                currentBest = iterateBits(R, N, words);
            return;
        }
        if (rSize + pSize <= static_cast<int>(currentBest.size())) return;

        // Partition bound
        if (pSize > 2) {
            std::vector<bool> qiSeen(g1_.n, false), tjSeen(g2_.n, false);
            for (int w = 0; w < words; ++w) {
                uint64_t bits = P[w];
                while (bits) {
                    int bit = ctz64(bits);
                    int v = (w << 6) | bit;
                    if (v < N) { qiSeen[nodes[v].qi] = true; tjSeen[nodes[v].tj] = true; }
                    bits &= bits - 1;
                }
            }
            int qiCard = 0, tjCard = 0;
            for (int i = 0; i < g1_.n; ++i) if (qiSeen[i]) qiCard++;
            for (int j = 0; j < g2_.n; ++j) if (tjSeen[j]) tjCard++;
            if (rSize + std::min(qiCard, tjCard) <= static_cast<int>(currentBest.size())) return;
        }

        if (pSize > 0 && rSize + colorBound(P, adj, words, N) <= static_cast<int>(currentBest.size())) return;

        // Choose pivot
        int pivot = -1, pivotConn = -1;
        for (int w = 0; w < words; ++w) {
            uint64_t bits = P[w] | X[w];
            while (bits) {
                int bit = ctz64(bits);
                int u = (w << 6) | bit;
                int conn = 0;
                for (int cw = 0; cw < words; ++cw) conn += popcount64(P[cw] & adj[u][cw]);
                if (conn > pivotConn) { pivotConn = conn; pivot = u; }
                bits &= bits - 1;
            }
        }

        std::vector<uint64_t> candidates(words);
        if (pivot >= 0)
            for (int w = 0; w < words; ++w) candidates[w] = P[w] & ~adj[pivot][w];
        else
            std::memcpy(candidates.data(), P, words * sizeof(uint64_t));

        std::unordered_set<int> triedClasses;
        for (int w = 0; w < words; ++w) {
            uint64_t bits = candidates[w];
            while (bits) {
                if (tb.expired()) return;
                int bit = ctz64(bits);
                int v = (w << 6) | bit;
                bits &= bits - 1;
                if (!triedClasses.insert(equivClass[v]).second) continue;

                uint64_t* newR; uint64_t* newP; uint64_t* newX;
                if (depth < static_cast<int>(rStack.size())) {
                    newR = rStack[depth].data();
                    newP = pStack[depth].data();
                    newX = xStack[depth].data();
                } else {
                    rStack.emplace_back(words, 0);
                    pStack.emplace_back(words, 0);
                    xStack.emplace_back(words, 0);
                    newR = rStack.back().data();
                    newP = pStack.back().data();
                    newX = xStack.back().data();
                }
                for (int cw = 0; cw < words; ++cw) {
                    newR[cw] = R[cw]; newP[cw] = P[cw] & adj[v][cw]; newX[cw] = X[cw] & adj[v][cw];
                }
                newR[v >> 6] |= 1ULL << (v & 63);
                bronKerboschPivot(newR, newP, newX, adj, currentBest, N, words,
                                  equivClass, tb, rStack, pStack, xStack, depth + 1, nodes);
                P[v >> 6] &= ~(1ULL << (v & 63));
                X[v >> 6] |= 1ULL << (v & 63);
            }
        }
    }

public:
    std::map<int,int> maximumCliqueSeed(TimeBudget& tb) {
        int n1 = g1_.n, n2 = g2_.n;
        std::vector<PGNode> nodes;
        for (int i = 0; i < n1; ++i)
            for (int j = 0; j < n2; ++j) {
                if (!atomsCompatFast(g1_, i, g2_, j, C_)) continue;
                if (!induced_ && g1_.degree[i] > g2_.degree[j]) continue;
                nodes.push_back({i, j});
            }
        int N = static_cast<int>(nodes.size());
        if (N == 0) return {};

        int words = (N + 63) >> 6;
        std::vector<std::vector<uint64_t>> adj(N, std::vector<uint64_t>(words, 0));

        for (int u = 0; u < N; ++u) {
            auto& nu = nodes[u];
            for (int v = u + 1; v < N; ++v) {
                if (tb.expired()) break;
                auto& nv = nodes[v];
                if (nu.qi == nv.qi || nu.tj == nv.tj) continue;
                int qOrd = g1_.bondOrder(nu.qi, nv.qi), tOrd = g2_.bondOrder(nu.tj, nv.tj);
                bool ok;
                if (qOrd != 0 && tOrd != 0)
                    ok = bondsCompatible(g1_, nu.qi, nv.qi, g2_, nu.tj, nv.tj, C_);
                else if (induced_)
                    ok = (qOrd == 0 && tOrd == 0);
                else
                    continue;
                if (ok) {
                    adj[u][v >> 6] |= 1ULL << (v & 63);
                    adj[v][u >> 6] |= 1ULL << (u & 63);
                }
            }
        }

        // Greedy clique
        std::vector<int> bestClique;
        greedyClique(adj, N, words, bestClique);

        // K-core reduction
        {
            int minDeg = std::max(2, static_cast<int>(bestClique.size()));
            bool changed = true;
            while (changed) {
                changed = false;
                for (int u = 0; u < N; ++u) {
                    int deg = 0;
                    for (int w = 0; w < words; ++w) deg += popcount64(adj[u][w]);
                    if (deg == 0 || deg >= minDeg) continue;
                    for (int w = 0; w < words; ++w) {
                        uint64_t bits = adj[u][w];
                        while (bits) {
                            int bit = ctz64(bits);
                            int v = (w << 6) | bit;
                            adj[v][u >> 6] &= ~(1ULL << (u & 63));
                            bits &= bits - 1;
                        }
                        adj[u][w] = 0;
                    }
                    changed = true;
                }
            }
        }

        // Equivalence classes (orbit-based)
        std::vector<int> equivClass(N);
        {
            std::unordered_map<int64_t, int> sig2class;
            int nextClass = 0;
            for (int i = 0; i < N; ++i) {
                auto& nd = nodes[i];
                int deg = 0;
                for (int w = 0; w < words; ++w) deg += popcount64(adj[i][w]);
                int64_t sig = (static_cast<int64_t>(g1_.orbit[nd.qi])          << 44)
                    | (static_cast<int64_t>(g2_.orbit[nd.tj])                  << 28)
                    | (static_cast<int64_t>(g1_.morganRank[nd.qi] & 0xFF)      << 20)
                    | (static_cast<int64_t>(g1_.degree[nd.qi])                 << 10) | deg;
                auto it = sig2class.find(sig);
                if (it == sig2class.end()) { sig2class[sig] = nextClass; equivClass[i] = nextClass++; }
                else equivClass[i] = it->second;
            }
        }

        // BK search
        std::vector<uint64_t> P(words, 0), X(words, 0), R(words, 0);
        for (int i = 0; i < N; ++i) {
            int deg = 0;
            for (int w = 0; w < words; ++w) deg += popcount64(adj[i][w]);
            if (deg > 0) P[i >> 6] |= 1ULL << (i & 63);
        }

        int maxDepth = std::min(N, 200);
        std::vector<std::vector<uint64_t>> rStack(maxDepth, std::vector<uint64_t>(words, 0));
        std::vector<std::vector<uint64_t>> pStack(maxDepth, std::vector<uint64_t>(words, 0));
        std::vector<std::vector<uint64_t>> xStack(maxDepth, std::vector<uint64_t>(words, 0));

        bronKerboschPivot(R.data(), P.data(), X.data(), adj, bestClique, N, words,
                          equivClass.data(), tb, rStack, pStack, xStack, 0, nodes);

        std::map<int,int> seed;
        std::unordered_set<int> usedQ, usedT;
        for (int u : bestClique) {
            auto& nd = nodes[u];
            if (!usedQ.count(nd.qi) && !usedT.count(nd.tj)) {
                seed[nd.qi] = nd.tj;
                usedQ.insert(nd.qi);
                usedT.insert(nd.tj);
            }
        }
        return seed;
    }

    // -- Ring anchor seed --------------------------------------------------
    std::map<int,int> ringAnchorSeed(TimeBudget& tb) {
        std::map<int,int> seed;
        std::vector<int> R1, R2;
        for (int i = 0; i < g1_.n; ++i) if (g1_.ring[i]) R1.push_back(i);
        for (int j = 0; j < g2_.n; ++j) if (g2_.ring[j]) R2.push_back(j);
        std::vector<bool> used(g2_.n, false);
        for (int i : R1) {
            int bestJ = -1, bestScore = INT_MIN;
            for (int j : R2) {
                if (used[j]) continue;
                if (!atomsCompatFast(g1_, i, g2_, j, C_)) continue;
                int score = (g1_.aromatic[i] && g2_.aromatic[j] ? 10 : 0) + std::min(g1_.degree[i], g2_.degree[j]);
                if (score > bestScore) { bestScore = score; bestJ = j; }
            }
            if (bestJ >= 0) { seed[i] = bestJ; used[bestJ] = true; }
            if (tb.expired()) break;
        }
        return seed;
    }

    // -- Label-degree anchor seed ------------------------------------------
    std::map<int,int> labelDegreeAnchorSeed(TimeBudget& tb) {
        std::map<int,int> seed;
        std::unordered_map<int,int> freq;
        for (int i = 0; i < g1_.n; ++i) freq[g1_.label[i]]++;
        std::vector<int> Q(g1_.n);
        std::iota(Q.begin(), Q.end(), 0);
        std::sort(Q.begin(), Q.end(), [&](int a, int b) {
            int ra = freq[g1_.label[a]], rb = freq[g1_.label[b]];
            return ra != rb ? ra < rb : g1_.degree[a] > g1_.degree[b];
        });
        std::vector<bool> used(g2_.n, false);
        for (int qi : Q) {
            int bestJ = -1, bestScore = INT_MIN;
            for (int tj = 0; tj < g2_.n; ++tj) {
                if (used[tj]) continue;
                if (!atomsCompatFast(g1_, qi, g2_, tj, C_)) continue;
                int score = 10 - std::abs(g1_.degree[qi] - g2_.degree[tj]);
                if (score > bestScore) { bestScore = score; bestJ = tj; }
            }
            if (bestJ >= 0) { seed[qi] = bestJ; used[bestJ] = true; }
            if (tb.expired()) break;
        }
        return seed;
    }
    // -- VF2++ neighborhood seed (shared implementation) --------------------

    std::map<int,int> vf2ppNeighborhoodSeed(
            TimeBudget& tb, int64_t millis, int /*radius*/, int maxAnchors,
            const std::vector<bool>& qCand, const std::vector<bool>& tCand) {
        struct AP { int qi, tj, score; };
        std::vector<AP> pairs;
        for (int i = 0; i < g1_.n; ++i) {
            if (!qCand[i]) continue;
            for (int j = 0; j < g2_.n; ++j) {
                if (!tCand[j]) continue;
                if (!atomsCompatFast(g1_, i, g2_, j, C_)) continue;
                int score = 100 - std::abs(g1_.degree[i] - g2_.degree[j]);
                if (g1_.aromatic[i] && g2_.aromatic[j]) score += 10;
                pairs.push_back({i, j, score});
            }
        }
        if (pairs.empty()) return {};
        std::sort(pairs.begin(), pairs.end(),
                  [](const AP& a, const AP& b) { return a.score > b.score; });
        if (static_cast<int>(pairs.size()) > maxAnchors)
            pairs.resize(maxAnchors);

        // Run VF2PP once with the full budget — anchor pairs are used for
        // scoring/ordering to select the best candidates, but the matcher
        // operates on the full graphs.  Running once avoids N redundant searches.
        if (tb.expired() || millis <= 0) return {};
        VF2PPMatcher m(g1_, g2_, C_, millis);
        std::vector<std::vector<std::pair<int,int>>> out;
        m.enumerate(1, out);
        if (out.empty()) return {};
        std::map<int,int> best;
        for (auto& [qi, tj] : out[0]) best[qi] = tj;
        return best;
    }

    // -- VF2++ ring skeleton seed -------------------------------------------

    std::map<int,int> vf2ppRingSkeletonSeed(TimeBudget& tb, int64_t millis,
                                             int radius, int maxAnchors) {
        std::vector<bool> qRing(g1_.n, false), tRing(g2_.n, false);
        bool qEmpty = true, tEmpty = true;
        for (int i = 0; i < g1_.n; ++i) if (g1_.ring[i]) { qRing[i] = true; qEmpty = false; }
        for (int j = 0; j < g2_.n; ++j) if (g2_.ring[j]) { tRing[j] = true; tEmpty = false; }
        if (qEmpty || tEmpty || millis <= 0) return {};
        return vf2ppNeighborhoodSeed(tb, millis, radius, maxAnchors, qRing, tRing);
    }

    // -- VF2++ heavy-atom core seed -----------------------------------------

    std::map<int,int> vf2ppCoreSeed(TimeBudget& tb, int64_t millis,
                                     int radius, int maxAnchors) {
        // Iteratively prune non-ring, non-aromatic leaf carbons
        std::vector<bool> qMask(g1_.n, true), tMask(g2_.n, true);
        auto prune = [](const MolGraph& g, std::vector<bool>& mask) {
            bool changed;
            do {
                changed = false;
                for (int i = 0; i < g.n; ++i) {
                    if (!mask[i] || g.ring[i] || g.aromatic[i]) continue;
                    int deg = 0;
                    for (int nb : g.neighbors[i]) if (mask[nb]) deg++;
                    if (deg <= 1 && g.atomicNum[i] == 6) { mask[i] = false; changed = true; }
                }
            } while (changed);
            bool empty = true;
            for (int i = 0; i < g.n; ++i) if (mask[i]) { empty = false; break; }
            if (empty) for (int i = 0; i < g.n; ++i) if (g.atomicNum[i] != 1) mask[i] = true;
        };
        prune(g1_, qMask);
        prune(g2_, tMask);
        bool qEmpty = true, tEmpty = true;
        for (int i = 0; i < g1_.n; ++i) if (qMask[i]) { qEmpty = false; break; }
        for (int j = 0; j < g2_.n; ++j) if (tMask[j]) { tEmpty = false; break; }
        if (qEmpty || tEmpty || millis <= 0) return {};
        return vf2ppNeighborhoodSeed(tb, millis, radius, maxAnchors, qMask, tMask);
    }
}; // class GraphBuilder

} // namespace detail

// ===========================================================================
// Public API
// ===========================================================================

/// Find the Maximum Common Substructure between two molecular graphs.
/// Returns a mapping from g1 atom indices to g2 atom indices.
inline std::map<int,int> findMCS(const MolGraph& g1, const MolGraph& g2,
                                  const ChemOptions& chem, const McsOptions& opts) {
    using namespace detail;

    static constexpr int GREEDY_PROBE_MAX_SIZE = 20;
    static constexpr int SEED_EXTEND_MAX_ATOMS = 50;
    static constexpr double BK_SKIP_RATIO = 0.8;

    TimeBudget tb(opts.timeoutMs);

    // Ensure canonical labeling / Morgan ranks are available (lazy init)
    g1.ensureCanonical();
    g2.ensureCanonical();
    if (chem.ringFusionMode != ChemOptions::RingFusionMode::IGNORE) {
        g1.ensureRingCounts();
        g2.ensureRingCounts();
    }

    int upperBound = labelFrequencyUpperBound(g1, g2, chem);
    std::map<int,int> best;
    int bestSize = 0, bestScore = 0;

    // Identity check — zero-allocation flat-array queue (handles symmetric molecules)
    if (&g1 == &g2 || (g1.n == g2.n && g1.n > 0 && g1.canonicalHash == g2.canonicalHash)) {
        std::map<int,int> id;
        if (&g1 == &g2) {
            for (int i = 0; i < g1.n; i++) id[i] = i;
        } else {
            std::vector<int> head(g2.n, -1), nxt(g2.n, -1);
            for (int j = g2.n - 1; j >= 0; j--) { nxt[j] = head[g2.canonicalLabel[j]]; head[g2.canonicalLabel[j]] = j; }
            for (int i = 0; i < g1.n; i++) { int cl = g1.canonicalLabel[i]; id[i] = head[cl]; head[cl] = nxt[head[cl]]; }
        }
        if (opts.disconnectedMCS && (opts.minFragmentSize > 1 || opts.maxFragments < INT_MAX))
            id = applyFragmentConstraints(g1, id, opts.minFragmentSize, opts.maxFragments);
        return id;
    }

    int minN = std::min(g1.n, g2.n);
    bool weightMode = opts.maximizeBonds || opts.atomWeights != nullptr;

    // --- Level 0.25: Linear chain fast-path ---
    // For chain-like molecules (max degree ≤ 2, e.g., PEG), the general MCS
    // algorithms suffer from O(n!) symmetry explosion because all internal
    // atoms are identical.  Detect this case and use O(n*m) longest-common-
    // subpath DP instead.
    if (!weightMode) {
        bool g1Chain = true, g2Chain = true;
        for (int i = 0; i < g1.n && g1Chain; ++i) if (g1.degree[i] > 2) g1Chain = false;
        for (int j = 0; j < g2.n && g2Chain; ++j) if (g2.degree[j] > 2) g2Chain = false;
        if (g1Chain && g2Chain && g1.n >= 2 && g2.n >= 2) {
            // Extract chain atom sequences by walking from an endpoint
            auto walkChain = [](const MolGraph& g) -> std::vector<int> {
                int start = -1;
                for (int i = 0; i < g.n; ++i)
                    if (g.degree[i] <= 1) { start = i; break; }
                if (start < 0) start = 0; // ring — pick any
                std::vector<int> seq;
                std::vector<bool> visited(g.n, false);
                int cur = start;
                while (cur >= 0) {
                    visited[cur] = true;
                    seq.push_back(cur);
                    int next = -1;
                    for (int nb : g.neighbors[cur])
                        if (!visited[nb]) { next = nb; break; }
                    cur = next;
                }
                return seq;
            };
            auto seq1 = walkChain(g1);
            auto seq2 = walkChain(g2);
            int n1 = static_cast<int>(seq1.size());
            int n2 = static_cast<int>(seq2.size());

            // DP: longest common subpath matching atom labels + bond orders
            // dp[i][j] = length of longest common suffix ending at seq1[i], seq2[j]
            std::vector<std::vector<int>> dp(n1 + 1, std::vector<int>(n2 + 1, 0));
            int bestLen = 0, bestI = 0, bestJ = 0;
            for (int i = 1; i <= n1; ++i) {
                int a1 = seq1[i - 1];
                for (int j = 1; j <= n2; ++j) {
                    int a2 = seq2[j - 1];
                    if (!atomsCompatFast(g1, a1, g2, a2, chem)) continue;
                    if (i > 1 && j > 1) {
                        int b1prev = seq1[i - 2], b2prev = seq2[j - 2];
                        if (dp[i - 1][j - 1] > 0 &&
                            bondsCompatible(g1, b1prev, a1, g2, b2prev, a2, chem)) {
                            dp[i][j] = dp[i - 1][j - 1] + 1;
                        } else {
                            dp[i][j] = 1; // start new subpath
                        }
                    } else {
                        dp[i][j] = 1;
                    }
                    if (dp[i][j] > bestLen) { bestLen = dp[i][j]; bestI = i; bestJ = j; }
                }
            }
            if (bestLen > 0) {
                std::map<int, int> chainMCS;
                for (int k = 0; k < bestLen; ++k)
                    chainMCS[seq1[bestI - bestLen + k]] = seq2[bestJ - bestLen + k];
                int chainScore = mcsScore(g1, chainMCS, opts);
                if (!weightMode ? bestLen >= bestSize : chainScore > bestScore) {
                    best = chainMCS; bestSize = bestLen; bestScore = chainScore;
                }
                if (bestLen >= upperBound) return best;
            }
        }
    }

    // --- Level 0.5: Tree fast-path (branched polymers, dendrimers, glycogen) ---
    // For acyclic connected molecules (trees) that have degree > 2, the general MCS
    // algorithms are expensive.  Detect tree topology (edges == atoms - 1) and use
    // Kilpelainen-Mannila style bottom-up DP on rooted trees: O(n1*n2*d^2).
    if (!weightMode && g1.n >= 10 && g2.n >= 10) {
        auto isTree = [](const MolGraph& g) -> bool {
            int edgeCount = 0;
            for (int i = 0; i < g.n; ++i)
                edgeCount += static_cast<int>(g.neighbors[i].size());
            edgeCount /= 2;
            if (edgeCount != g.n - 1) return false;
            std::vector<bool> vis(g.n, false);
            std::deque<int> bfs;
            bfs.push_back(0); vis[0] = true;
            int cnt = 1;
            while (!bfs.empty()) {
                int u = bfs.front(); bfs.pop_front();
                for (int v : g.neighbors[u])
                    if (!vis[v]) { vis[v] = true; ++cnt; bfs.push_back(v); }
            }
            return cnt == g.n;
        };

        if (isTree(g1) && isTree(g2)) {
            // Find centroid by iteratively peeling leaves
            auto findCentroid = [](const MolGraph& g) -> int {
                std::vector<int> deg(g.n);
                std::deque<int> leaves;
                for (int i = 0; i < g.n; ++i) {
                    deg[i] = static_cast<int>(g.neighbors[i].size());
                    if (deg[i] <= 1) leaves.push_back(i);
                }
                int remaining = g.n;
                while (remaining > 2) {
                    int sz = static_cast<int>(leaves.size());
                    remaining -= sz;
                    std::deque<int> newLeaves;
                    for (int i = 0; i < sz; ++i) {
                        int u = leaves[i];
                        for (int v : g.neighbors[u])
                            if (--deg[v] == 1) newLeaves.push_back(v);
                    }
                    leaves = std::move(newLeaves);
                }
                return leaves.front();
            };

            // Root tree at centroid, build children + postorder
            struct RootedTree {
                std::vector<int> parent;
                std::vector<std::vector<int>> children;
                std::vector<int> postorder;
                int root;
            };
            auto rootTree = [](const MolGraph& g, int root) -> RootedTree {
                RootedTree rt;
                rt.root = root;
                rt.parent.assign(g.n, -1);
                rt.children.resize(g.n);
                rt.postorder.reserve(g.n);
                std::vector<bool> vis(g.n, false);
                std::deque<int> bfs;
                bfs.push_back(root); vis[root] = true;
                std::vector<int> bfsOrder;
                bfsOrder.reserve(g.n);
                while (!bfs.empty()) {
                    int u = bfs.front(); bfs.pop_front();
                    bfsOrder.push_back(u);
                    for (int v : g.neighbors[u]) {
                        if (!vis[v]) {
                            vis[v] = true;
                            rt.parent[v] = u;
                            rt.children[u].push_back(v);
                            bfs.push_back(v);
                        }
                    }
                }
                rt.postorder.assign(bfsOrder.rbegin(), bfsOrder.rend());
                return rt;
            };

            int root1 = findCentroid(g1);
            int root2 = findCentroid(g2);
            auto rt1 = rootTree(g1, root1);
            auto rt2 = rootTree(g2, root2);

            int n1t = g1.n, n2t = g2.n;
            // dp[u][v] = max common subtree size rooted at (u in T1, v in T2)
            std::vector<std::vector<int>> dpTree(n1t, std::vector<int>(n2t, 0));
            // Backtrack: child matching indices for reconstruction
            std::vector<std::vector<std::vector<std::pair<int,int>>>> btTree(
                n1t, std::vector<std::vector<std::pair<int,int>>>(n2t));

            for (int u : rt1.postorder) {
                for (int v : rt2.postorder) {
                    if (!atomsCompatFast(g1, u, g2, v, chem)) {
                        dpTree[u][v] = 0;
                        continue;
                    }
                    const auto& ch1 = rt1.children[u];
                    const auto& ch2 = rt2.children[v];
                    if (ch1.empty() || ch2.empty()) {
                        dpTree[u][v] = 1;
                        continue;
                    }
                    // Greedy bipartite matching by descending dp value
                    int d1 = static_cast<int>(ch1.size());
                    int d2 = static_cast<int>(ch2.size());
                    struct CandEdge { int weight; int i; int j; };
                    std::vector<CandEdge> edges;
                    edges.reserve(d1 * d2);
                    for (int i2 = 0; i2 < d1; ++i2) {
                        for (int j2 = 0; j2 < d2; ++j2) {
                            int w = dpTree[ch1[i2]][ch2[j2]];
                            if (w > 0 && bondsCompatible(g1, u, ch1[i2], g2, v, ch2[j2], chem))
                                edges.push_back({w, i2, j2});
                        }
                    }
                    std::sort(edges.begin(), edges.end(),
                              [](const CandEdge& a, const CandEdge& b) { return a.weight > b.weight; });
                    std::vector<bool> usedI(d1, false), usedJ(d2, false);
                    int childSum = 0;
                    std::vector<std::pair<int,int>> matching;
                    for (auto& e : edges) {
                        if (usedI[e.i] || usedJ[e.j]) continue;
                        usedI[e.i] = true; usedJ[e.j] = true;
                        childSum += e.weight;
                        matching.push_back({e.i, e.j});
                    }
                    dpTree[u][v] = 1 + childSum;
                    btTree[u][v] = std::move(matching);
                }
            }

            // Find best root pair
            int treeBest = 0, bestU = -1, bestV = -1;
            for (int u = 0; u < n1t; ++u)
                for (int v = 0; v < n2t; ++v)
                    if (dpTree[u][v] > treeBest) { treeBest = dpTree[u][v]; bestU = u; bestV = v; }

            if (treeBest > bestSize) {
                std::map<int,int> treeMap;
                std::function<void(int, int)> reconstruct = [&](int u, int v) {
                    treeMap[u] = v;
                    for (auto& [ci, cj] : btTree[u][v])
                        reconstruct(rt1.children[u][ci], rt2.children[v][cj]);
                };
                reconstruct(bestU, bestV);

                int treeScore = mcsScore(g1, treeMap, opts);
                if (static_cast<int>(treeMap.size()) > bestSize) {
                    best = std::move(treeMap);
                    bestSize = static_cast<int>(best.size());
                    bestScore = treeScore;
                }
                if (bestSize >= upperBound) return best;
            }
        }
    }

    // --- Level 0.75: Greedy probe ---
    if (!weightMode && minN > 2 && minN < GREEDY_PROBE_MAX_SIZE && upperBound >= minN) {
        auto greedy = greedyProbe(g1, g2, chem);
        if (static_cast<int>(greedy.size()) >= upperBound) {
            auto greedyC = applyRingAnchorGuard(g1, g2,
                opts.connectedOnly ? largestConnected(g1, greedy) : greedy, chem);
            if (static_cast<int>(greedyC.size()) >= upperBound) return greedyC;
        }
    }

    // --- Level 1: Substructure containment ---
    if (!weightMode && g1.n > 0 && g2.n > 0
        && std::min(g1.n, g2.n) <= std::max(g1.n, g2.n) * 3 / 4) {
        const MolGraph& sml = g1.n <= g2.n ? g1 : g2;
        const MolGraph& lrg = g1.n <= g2.n ? g2 : g1;
        bool swapped = g1.n > g2.n;
        // Use VF2PP for substructure check
        auto subMap = findSubstructure(sml, lrg, chem, tb.remainingMs());
        if (!subMap.empty()) {
            if (!swapped) {
                std::map<int,int> result;
                for (auto& [k,v] : subMap) result[k] = v;
                return result;
            }
            std::map<int,int> full;
            for (auto& [k,v] : subMap) full[v] = k;
            return full;
        }
    }

    // --- Level 1.5: Seed-and-extend ---
    GraphBuilder GB(g1, g2, chem, opts.induced);
    if (minN >= 4 && std::max(g1.n, g2.n) <= SEED_EXTEND_MAX_ATOMS && !tb.expired()) {
        auto seSeed = GB.seedExtendMCS(tb, upperBound);
        int seScore = mcsScore(g1, seSeed, opts);
        if (weightMode ? seScore > bestScore : static_cast<int>(seSeed.size()) > bestSize) {
            best = seSeed; bestSize = static_cast<int>(seSeed.size()); bestScore = seScore;
        }
        if (!weightMode && bestSize >= upperBound) return ppx(g1, g2, best, chem, opts);
    }

    // --- Level 2: McSplit ---
    bool mcSplitExhaustive;
    int mcSplitSize;
    {
        int64_t nodeCount = 0;
        auto mcSeed = GB.mcSplitSeed(tb, nodeCount);
        mcSplitSize = static_cast<int>(mcSeed.size());
        int mcScore = mcsScore(g1, mcSeed, opts);
        if (weightMode ? mcScore > bestScore : static_cast<int>(mcSeed.size()) > bestSize) {
            best = mcSeed; bestSize = static_cast<int>(mcSeed.size()); bestScore = mcScore;
        }
        mcSplitExhaustive = nodeCount < 200000;
    }
    if (!weightMode && mcSplitExhaustive && bestSize >= upperBound)
        return ppx(g1, g2, best, chem, opts);

    // Near-optimal fast path: greedy atom extension
    if (bestSize >= upperBound - 2 && bestSize > 0 && bestSize < upperBound && !tb.expired()) {
        auto ext = ppx(g1, g2, greedyAtomExtend(g1, g2, ppx(g1, g2, best, chem, opts), chem, opts), chem, opts);
        int extScore = mcsScore(g1, ext, opts);
        if (weightMode ? extScore > bestScore : static_cast<int>(ext.size()) > bestSize) {
            best = ext; bestSize = static_cast<int>(ext.size()); bestScore = extScore;
        }
        if (!weightMode && bestSize >= upperBound) return best;
    }

    // --- Level 3: Bron-Kerbosch ---
    int bkSize = 0;
    if (bestSize < static_cast<int>(upperBound * BK_SKIP_RATIO) && !tb.expired()) {
        auto cliqueSeed = GB.maximumCliqueSeed(tb);
        bkSize = static_cast<int>(cliqueSeed.size());
        int cScore = mcsScore(g1, cliqueSeed, opts);
        if (weightMode ? cScore > bestScore : static_cast<int>(cliqueSeed.size()) > bestSize) {
            best = cliqueSeed; bestSize = static_cast<int>(cliqueSeed.size()); bestScore = cScore;
        }
    }
    if (!weightMode && bestSize >= upperBound) return ppx(g1, g2, best, chem, opts);

    // --- Level 4: McGregor extension with seeds ---
    std::vector<std::map<int,int>> seeds;
    if (bestSize > 0) seeds.push_back(best);

    // --- Level 5: Extra seeds (only when McSplit and BK disagree) ---
    bool skipExtraSeeds = mcSplitSize > 0 && bkSize > 0 && mcSplitSize == bkSize;
    if (opts.extraSeeds && !skipExtraSeeds && bestSize < upperBound && !tb.expired()) {
        auto s = GB.ringAnchorSeed(tb);
        if (!s.empty()) seeds.push_back(s);
        if (!tb.expired()) {
            s = GB.labelDegreeAnchorSeed(tb);
            if (!s.empty()) seeds.push_back(s);
        }
        if (!tb.expired()) {
            s = GB.vf2ppRingSkeletonSeed(tb,
                std::max<int64_t>(1, tb.remainingMs() / 4), 2, 12);
            if (!s.empty()) seeds.push_back(s);
        }
        if (!tb.expired()) {
            s = GB.vf2ppCoreSeed(tb,
                std::max<int64_t>(1, tb.remainingMs() / 4), 2, 12);
            if (!s.empty()) seeds.push_back(s);
        }
    }

    int64_t perSeedMs = std::max<int64_t>(1, tb.remainingMs() / std::max<int64_t>(1, seeds.size()));
    for (auto& seed : seeds) {
        if (tb.expired()) break;
        auto ext = ppx(g1, g2,
            mcGregorExtend(g1, g2, seed, chem, tb, perSeedMs,
                           opts.useTwoHopNLFInExtension, opts.useThreeHopNLFInExtension, opts.connectedOnly),
            chem, opts);
        int seedScore = mcsScore(g1, ext, opts);
        if (weightMode ? seedScore > bestScore : static_cast<int>(ext.size()) > bestSize) {
            best = ext; bestSize = static_cast<int>(ext.size()); bestScore = seedScore;
        }
        if (!weightMode && bestSize >= upperBound) return best;
    }

    // Last resort: start from empty seed
    if (bestScore <= 0 && !tb.expired()) {
        best = ppx(g1, g2,
            mcGregorExtend(g1, g2, {}, chem, tb, tb.remainingMs(),
                           opts.useTwoHopNLFInExtension, opts.useThreeHopNLFInExtension, opts.connectedOnly),
            chem, opts);
    }
    return best;
}

/// Find the disconnected MCS (dMCS) between two molecular graphs.
inline std::map<int,int> findDisconnectedMCS(const MolGraph& g1, const MolGraph& g2,
                                              const ChemOptions& chem, const McsOptions& opts) {
    McsOptions dM = opts;
    dM.connectedOnly = false;
    dM.disconnectedMCS = true;
    return findMCS(g1, g2, chem, dM);
}

/// Compute RASCAL-style similarity upper bound (Tanimoto-like, 0.0--1.0).
inline double similarityUpperBound(const MolGraph& g1, const MolGraph& g2) {
    if (g1.n == 0 || g2.n == 0) return 0.0;
    std::unordered_map<int,int> count1, count2;
    for (int i = 0; i < g1.n; ++i) count1[g1.label[i]]++;
    for (int i = 0; i < g2.n; ++i) count2[g2.label[i]]++;
    int atomOverlap = 0;
    for (auto& [lab, cnt] : count1) {
        auto it = count2.find(lab);
        if (it != count2.end()) atomOverlap += std::min(cnt, it->second);
    }
    if (atomOverlap == 0) return 0.0;
    int total = g1.n + g2.n;
    return static_cast<double>(atomOverlap) / (total - atomOverlap);
}

// ===========================================================================
// validateMapping -- check that a mapping is chemically correct.
// Port of Java SearchEngine.validateMapping()
// Checks: injective, atoms compatible, bonds compatible for all mapped neighbors.
// ===========================================================================

inline std::vector<std::string> validateMapping(const MolGraph& g1, const MolGraph& g2,
                                                 const std::map<int,int>& mapping,
                                                 const ChemOptions& opts) {
    std::vector<std::string> errors;
    if (mapping.empty()) return errors;

    // Check injectivity: no target atom mapped twice
    std::unordered_set<int> usedT;
    for (auto& [qi, tj] : mapping) {
        if (qi < 0 || qi >= g1.n) {
            errors.push_back("query index " + std::to_string(qi) + " out of range [0," + std::to_string(g1.n) + ")");
            continue;
        }
        if (tj < 0 || tj >= g2.n) {
            errors.push_back("target index " + std::to_string(tj) + " out of range [0," + std::to_string(g2.n) + ")");
            continue;
        }
        if (!usedT.insert(tj).second) {
            errors.push_back("target atom " + std::to_string(tj) + " mapped twice (not injective)");
        }
        if (!detail::atomsCompatFast(g1, qi, g2, tj, opts)) {
            errors.push_back("atom mismatch: q" + std::to_string(qi) + "(" + std::to_string(g1.atomicNum[qi])
                            + ") -> t" + std::to_string(tj) + "(" + std::to_string(g2.atomicNum[tj]) + ")");
        }
    }

    // Check bonds: where both endpoints are mapped and both graphs have a bond
    for (auto& [qi, tj] : mapping) {
        if (qi < 0 || qi >= g1.n || tj < 0 || tj >= g2.n) continue;
        for (int qk : g1.neighbors[qi]) {
            auto it = mapping.find(qk);
            if (it == mapping.end()) continue;
            int tk = it->second;
            if (g1.bondOrder(qi, qk) != 0 && g2.bondOrder(tj, tk) != 0
                && !ChemOps::bondsCompatible(g1, qi, qk, g2, tj, tk, opts)) {
                errors.push_back("bond incompatible: q(" + std::to_string(qi) + "-" + std::to_string(qk)
                                + ") vs t(" + std::to_string(tj) + "-" + std::to_string(tk) + ")");
            }
        }
    }
    return errors;
}

// ===========================================================================
// isMappingMaximal -- check if no unmapped (qi,tj) pair can be added.
// Port of Java SearchEngine.isMappingMaximal()
// Try adding any unmapped pair -- if none can extend, it's maximal.
// ===========================================================================

inline bool isMappingMaximal(const MolGraph& g1, const MolGraph& g2,
                              const std::map<int,int>& mapping,
                              const ChemOptions& opts) {
    std::unordered_set<int> usedQ, usedT;
    for (auto& [qi, tj] : mapping) {
        usedQ.insert(qi);
        usedT.insert(tj);
    }

    for (int qi = 0; qi < g1.n; ++qi) {
        if (usedQ.count(qi)) continue;
        for (int tj = 0; tj < g2.n; ++tj) {
            if (usedT.count(tj)) continue;
            if (!detail::atomsCompatFast(g1, qi, g2, tj, opts)) continue;

            // Check that all mapped neighbors of qi have compatible bonds
            bool bondOk = true;
            for (int qk : g1.neighbors[qi]) {
                auto it = mapping.find(qk);
                if (it == mapping.end()) continue;
                int tk = it->second;
                if (g2.bondOrder(tj, tk) == 0
                    || !ChemOps::bondsCompatible(g1, qi, qk, g2, tj, tk, opts)) {
                    bondOk = false;
                    break;
                }
            }
            if (bondOk) return false; // found extensible pair -> not maximal
        }
    }
    return true;
}

// ===========================================================================
// findNMCS -- N-molecule MCS with threshold via sequential pairwise reduction.
// Port of Java SearchEngine.findNMCS() / findNMCSMolecule()
// Sort by size, compute MCS(mol[0], mol[1]), extract common subgraph,
// compute MCS(result, mol[2]), etc.
// ===========================================================================

inline std::map<int,int> findNMCS(const std::vector<MolGraph>& molecules,
                                   const ChemOptions& opts,
                                   double threshold,
                                   int64_t timeoutMs) {
    if (molecules.size() < 2) return {};

    // Sort molecule indices by atom count (ascending)
    std::vector<int> sortedIdx(molecules.size());
    std::iota(sortedIdx.begin(), sortedIdx.end(), 0);
    std::sort(sortedIdx.begin(), sortedIdx.end(), [&](int a, int b) {
        return molecules[a].n < molecules[b].n;
    });

    McsOptions mcsOpts;
    mcsOpts.timeoutMs = timeoutMs;
    mcsOpts.connectedOnly = true;

    // Start with the smallest molecule, tracking original atom indices
    MolGraph currentMCS = molecules[sortedIdx[0]];
    std::vector<int> originalIndices(currentMCS.n);
    std::iota(originalIndices.begin(), originalIndices.end(), 0);

    for (size_t i = 1; i < sortedIdx.size(); ++i) {
        auto mcs = findMCS(currentMCS, molecules[sortedIdx[i]], opts, mcsOpts);
        if (mcs.empty()) return {};

        // Extract common subgraph using query-side atom indices
        std::vector<int> queryIndices;
        queryIndices.reserve(mcs.size());
        for (auto& [qi, tj] : mcs) queryIndices.push_back(qi);
        std::sort(queryIndices.begin(), queryIndices.end());

        // Update provenance: map surviving local indices → original indices
        std::vector<int> newOriginal;
        newOriginal.reserve(queryIndices.size());
        for (int localIdx : queryIndices)
            newOriginal.push_back(originalIndices[localIdx]);
        originalIndices = std::move(newOriginal);

        currentMCS = extractSubgraph(currentMCS, queryIndices);
        if (currentMCS.n == 0) return {};
    }

    // Threshold check: verify MCS is substructure of enough molecules
    if (threshold < 1.0 && currentMCS.n > 0) {
        int requiredCount = static_cast<int>(std::ceil(threshold * molecules.size()));
        int matchCount = 0;
        for (auto& mol : molecules) {
            if (isSubstructure(currentMCS, mol, opts, timeoutMs)) matchCount++;
        }
        if (matchCount < requiredCount) return {};
    }

    // Return mapping: original atom index in molecules[sortedIdx[0]] → NMCS position
    std::map<int,int> result;
    for (int i = 0; i < currentMCS.n; ++i)
        result[originalIndices[i]] = i;
    return result;
}

// ===========================================================================
// findScaffoldMCS -- MCS on Murcko scaffolds of two molecules.
// Port of Java SearchEngine.findScaffoldMCS()
// ===========================================================================

inline std::map<int,int> findScaffoldMCS(const MolGraph& g1, const MolGraph& g2,
                                          const ChemOptions& opts, const McsOptions& mopts) {
    MolGraph s1 = murckoScaffold(g1);
    MolGraph s2 = murckoScaffold(g2);
    return findMCS(s1, s2, opts, mopts);
}

// ===========================================================================
// RGroupResult -- result of R-group decomposition for a single molecule.
// ===========================================================================

struct RGroupResult {
    MolGraph core;
    std::map<std::string, MolGraph> rgroups;
};

// ===========================================================================
// decomposeRGroups -- decompose molecules into core + R-groups.
// Port of Java SearchEngine.decomposeRGroups()
// For each molecule, find the core as a substructure, then BFS-flood
// connected components of non-core atoms as R1, R2, etc.
// ===========================================================================

inline std::vector<RGroupResult> decomposeRGroups(const MolGraph& core,
                                                    const std::vector<MolGraph>& molecules,
                                                    const ChemOptions& opts,
                                                    int64_t timeoutMs) {
    std::vector<RGroupResult> results;
    results.reserve(molecules.size());

    for (auto& mol : molecules) {
        RGroupResult decomp;

        // Find core as substructure of mol
        auto allMappings = findAllSubstructures(core, mol, opts, timeoutMs);
        if (allMappings.empty()) {
            results.push_back(std::move(decomp));
            continue;
        }

        // Use the first mapping (vector of pair<int,int>: query->target)
        auto& mapping = allMappings[0];
        std::unordered_set<int> coreAtomIndicesInMol;
        for (auto& [qi, tj] : mapping) {
            coreAtomIndicesInMol.insert(tj);
        }

        // Extract core subgraph from mol
        std::vector<int> coreIndices(coreAtomIndicesInMol.begin(), coreAtomIndicesInMol.end());
        std::sort(coreIndices.begin(), coreIndices.end());
        decomp.core = extractSubgraph(mol, coreIndices);

        // BFS to find connected R-group fragments
        int rGroupCounter = 1;
        std::unordered_set<int> processedNonCore;

        for (auto& [qi, molIdx] : mapping) {
            for (int neighborIdx : mol.neighbors[molIdx]) {
                if (coreAtomIndicesInMol.count(neighborIdx)) continue;
                if (processedNonCore.count(neighborIdx)) continue;

                // BFS flood to find this R-group's atoms
                std::vector<int> rGroupAtoms;
                std::deque<int> queue;
                queue.push_back(neighborIdx);
                std::unordered_set<int> visited;
                visited.insert(neighborIdx);

                while (!queue.empty()) {
                    int current = queue.front(); queue.pop_front();
                    if (coreAtomIndicesInMol.count(current)) continue;
                    rGroupAtoms.push_back(current);
                    processedNonCore.insert(current);

                    for (int nb : mol.neighbors[current]) {
                        if (!coreAtomIndicesInMol.count(nb) && !visited.count(nb)) {
                            visited.insert(nb);
                            queue.push_back(nb);
                        }
                    }
                }

                if (!rGroupAtoms.empty()) {
                    std::sort(rGroupAtoms.begin(), rGroupAtoms.end());
                    decomp.rgroups["R" + std::to_string(rGroupCounter++)] =
                        extractSubgraph(mol, rGroupAtoms);
                }
            }
        }

        results.push_back(std::move(decomp));
    }
    return results;
}

// ===========================================================================
// mapReaction -- atom-atom mapping between reactants and products via dMCS.
// Port of Java SearchEngine.mapReaction()
// Computes disconnected MCS between reactant and product atoms.
// ===========================================================================

inline std::map<int,int> mapReaction(const MolGraph& reactants, const MolGraph& products,
                                      const ChemOptions& opts, int64_t timeoutMs) {
    McsOptions mcsOpts;
    mcsOpts.disconnectedMCS = true;
    mcsOpts.connectedOnly = false;
    mcsOpts.timeoutMs = timeoutMs;
    return findMCS(reactants, products, opts, mcsOpts);
}

} // namespace smsd
