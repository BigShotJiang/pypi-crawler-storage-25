/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2018-2026 BioInception PVT LTD
 * Algorithm Copyright (c) 2009-2026 Syed Asad Rahman
 *
 * Header-only C++17 port of MolGraph / ChemOptions / ChemOps.
 * Zero external dependencies -- pure C++17 standard library.
 */
#pragma once
#ifndef SMSD_MOL_GRAPH_HPP
#define SMSD_MOL_GRAPH_HPP

#include "smsd/bitops.hpp"

#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <cstring>
#include <deque>
#include <functional>
#include <numeric>
#include <set>
#include <sstream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

namespace smsd {

// ============================================================================
// ChemOptions -- configuration for chemical matching constraints
// ============================================================================

struct ChemOptions {
    enum class BondOrderMode   { STRICT, LOOSE, ANY };
    enum class AromaticityMode { STRICT, FLEXIBLE };
    enum class MatcherEngine   { VF2, VF2PP, VF3 };
    enum class RingFusionMode  { IGNORE, PERMISSIVE, STRICT };
    enum class Solvent         { AQUEOUS, DMSO, METHANOL, CHLOROFORM };

    // Atom matching
    bool matchAtomType            = true;
    bool matchFormalCharge        = true;
    bool useChirality             = false;
    bool useBondStereo            = false;
    bool ringMatchesRingOnly      = true;

    // Ring completeness
    bool completeRingsOnly        = false;

    // Isotope matching
    bool matchIsotope             = false;

    // Ring fusion
    RingFusionMode ringFusionMode = RingFusionMode::IGNORE;

    // Tautomer matching
    bool   tautomerAware = false;
    /** Simulation pH for pKa-informed tautomer relevance scoring. Default 7.4 (physiological). */
    double pH            = 7.4;

    /** Set simulation pH, clamped to [0, 14]. */
    ChemOptions& withPH(double v) { pH = std::max(0.0, std::min(14.0, v)); return *this; }

    // Solvent for Tier 2 pKa-informed tautomer weight corrections
    Solvent solvent = Solvent::AQUEOUS;

    /** Set solvent for tautomer weight corrections (fluent). */
    ChemOptions& withSolvent(Solvent s) { solvent = s; return *this; }

    // Bond matching
    BondOrderMode  matchBondOrder  = BondOrderMode::STRICT;
    AromaticityMode aromaticityMode = AromaticityMode::FLEXIBLE;

    // Engine
    MatcherEngine matcherEngine   = MatcherEngine::VF2PP;

    // Pruning
    bool useTwoHopNLF             = true;
    bool useThreeHopNLF           = false;
    bool useBitParallelFeasibility = true;

    // Fluent setters
    ChemOptions& withAromaticityMode(AromaticityMode m) { aromaticityMode = m; return *this; }
    ChemOptions& withBondOrderMode(BondOrderMode m)     { matchBondOrder = m; return *this; }
    ChemOptions& withTwoHopNLF(bool on)                 { useTwoHopNLF = on; return *this; }
    ChemOptions& withThreeHopNLF(bool on)               { useThreeHopNLF = on; return *this; }
    ChemOptions& withBitParallelFeasibility(bool on)     { useBitParallelFeasibility = on; return *this; }
    ChemOptions& withCompleteRingsOnly(bool on)          { completeRingsOnly = on; return *this; }
    ChemOptions& withMatchIsotope(bool on)               { matchIsotope = on; return *this; }
    ChemOptions& withRingFusionMode(RingFusionMode m)    { ringFusionMode = m; return *this; }
    ChemOptions& withTautomerAware(bool on)              { tautomerAware = on; return *this; }

    // Named profiles
    static ChemOptions profile(const std::string& name) {
        ChemOptions opts;
        if (name == "strict") {
            opts.matchBondOrder  = BondOrderMode::STRICT;
            opts.aromaticityMode = AromaticityMode::STRICT;
        } else {
            // "compat-fmcs", "compat-substruct", default
            opts.matchBondOrder      = BondOrderMode::LOOSE;
            opts.aromaticityMode     = AromaticityMode::FLEXIBLE;
            opts.ringMatchesRingOnly = false;
        }
        return opts;
    }

    static ChemOptions tautomerProfile() {
        ChemOptions c;
        c.tautomerAware      = true;
        c.matchBondOrder      = BondOrderMode::LOOSE;
        c.aromaticityMode     = AromaticityMode::FLEXIBLE;
        c.matchFormalCharge   = false;
        c.ringMatchesRingOnly = false;
        return c;
    }

    /** Relaxed profile matching RDKit FMCS defaults — ring atoms may map to chain atoms,
     *  partial rings are accepted, bond orders and charges are not enforced.
     *  Produces numerically larger but topologically looser MCS than the strict default.
     *  Use for direct RDKit comparisons or when loose topology matching is required. */
    static ChemOptions fmcsProfile() {
        ChemOptions c;
        c.matchBondOrder      = BondOrderMode::LOOSE;
        c.ringMatchesRingOnly = false;
        c.completeRingsOnly   = false;
        c.matchFormalCharge   = false;
        return c;
    }
};

// ============================================================================
// MolGraph -- immutable molecular graph representation
// ============================================================================

struct MolGraph {

    static constexpr int SPARSE_THRESHOLD   = 200;
    static constexpr int HASH_PRIME         = 1000003;
    static constexpr int MAX_SEARCH_NODES   = 50000;
    static constexpr int CANON_SEARCH_LIMIT = 200;

    // --- Core atom arrays ---
    int n     = 0;   // atom count
    int words = 0;   // number of uint64_t words for bit-parallel adjacency

    std::vector<int>  atomicNum;
    std::vector<int>  formalCharge;
    std::vector<int>  massNumber;
    std::vector<int>  label;
    std::vector<bool> ring;
    std::vector<bool> aromatic;
    std::vector<int>  degree;
    mutable std::vector<int>  ringCount;
    mutable bool              ringCountsComputed_ = false;

    std::vector<std::vector<int>> neighbors;

    // --- Morgan / canonical / orbit (lazy — call ensureCanonical() before accessing) ---
    mutable std::vector<int>  morganRank;
    mutable std::vector<int>  canonicalLabel;
    mutable std::vector<int>  orbit;
    mutable int64_t           canonicalHash = 0;
    mutable bool              canonicalComputed_ = false;

    // --- Tautomer classes and per-atom pKa-informed relevance weights ---
    std::vector<int>   tautomerClass;   // -1 = not tautomeric
    std::vector<float> tautomerWeight;  // 1.0 = non-tautomeric; <1.0 = relevance at pH 7.4
    ChemOptions::Solvent solvent_ = ChemOptions::Solvent::AQUEOUS;

    // pKa-informed relevance weights at pH 7.4 (Sitzmann 2010)
    static constexpr float TW_KETO_ENOL          = 0.98f; // keto form dominant (pKa ~20)
    static constexpr float TW_AMIDE_IMIDIC        = 0.97f; // amide dominant (pKa ~25)
    static constexpr float TW_LACTAM_LACTIM       = 0.97f; // lactam dominant
    static constexpr float TW_UREA                = 0.96f; // urea dominant (pKa ~14)
    static constexpr float TW_PYRIDINONE          = 0.95f; // lactam form dominant (pKa ~1)
    static constexpr float TW_THIOAMIDE           = 0.94f; // thioamide dominant
    static constexpr float TW_THIONE_THIOL        = 0.94f; // thione dominant (pKa ~10-11)
    static constexpr float TW_ENAMINONE           = 0.85f; // vinylogous amide
    static constexpr float TW_HYDROXAMIC          = 0.85f; // hydroxamic acid (pKa ~8)
    static constexpr float TW_PHENOL_QUINONE      = 0.88f; // phenol dominant (pKa ~10)
    static constexpr float TW_HYDROXYPYRIMIDINE   = 0.90f; // hydroxy form dominant
    static constexpr float TW_PURINE_NH           = 0.78f; // purine N-H
    static constexpr float TW_DIKETONE_ENOL       = 0.72f; // pH-sensitive at 7.4 (pKa ~8-11)
    static constexpr float TW_NITROSO_OXIME       = 0.70f; // oxime slightly more stable
    static constexpr float TW_CYANAMIDE           = 0.80f; // cyanamide
    static constexpr float TW_IMIDE               = 0.92f; // imide NH (pKa ~9-10)
    static constexpr float TW_AMIDINE             = 0.50f; // symmetric tautomers
    static constexpr float TW_GUANIDINE           = 0.50f; // symmetric tautomers
    static constexpr float TW_IMIDAZOLE_NH        = 0.50f; // N1H/N3H symmetric
    static constexpr float TW_TRIAZOLE_NH         = 0.50f; // symmetric
    static constexpr float TW_TETRAZOLE_NH        = 0.50f; // 1H/2H symmetric
    static constexpr float TW_NITRO_ACI           = 0.25f; // aci-nitro minor at pH 7.4

    // --- Bit-parallel adjacency (n x words) ---
    std::vector<std::vector<uint64_t>> adjLong;

    // --- Bond storage: dense for small molecules, sparse for large ---
    std::vector<std::vector<int>>  bondOrdMatrix;   // dense n x n
    std::vector<std::vector<bool>> bondRingMatrix;
    std::vector<std::vector<bool>> bondAromMatrix;
    bool useDense = false;

    // Sparse bond props: key = bondKey(i,j), value = {order, inRing, aromatic}
    std::unordered_map<int64_t, std::array<int,3>> sparseBondProps;

    // --- Stereochemistry ---
    std::vector<int>              tetraChirality;
    std::vector<std::vector<int>> dbStereoConf;   // dense, only for n <= SPARSE_THRESHOLD
    bool hasDbStereo = false;

    // --- SSSR rings (lazy, mutable) ---
    mutable std::vector<std::vector<int>> sssrRings;
    mutable bool sssrComputed = false;

    // --- NLF caches (lazy, mutable for const-correct access) ---
    mutable std::vector<std::vector<int>> cachedNLF1, cachedNLF2, cachedNLF3;

    // ========================================================================
    // Bond key: pack two indices into one int64
    // ========================================================================

    static int64_t bondKey(int i, int j) {
        int lo = std::min(i, j), hi = std::max(i, j);
        return (static_cast<int64_t>(lo) << 32)
             | static_cast<int64_t>(static_cast<uint32_t>(hi));
    }

    // ========================================================================
    // Bond accessors
    // ========================================================================

    int bondOrder(int i, int j) const {
        if (useDense) return bondOrdMatrix[i][j];
        auto it = sparseBondProps.find(bondKey(i, j));
        return it != sparseBondProps.end() ? it->second[0] : 0;
    }

    bool bondInRing(int i, int j) const {
        if (useDense) return bondRingMatrix[i][j];
        auto it = sparseBondProps.find(bondKey(i, j));
        return it != sparseBondProps.end() && it->second[1] != 0;
    }

    bool bondAromatic(int i, int j) const {
        if (useDense) return bondAromMatrix[i][j];
        auto it = sparseBondProps.find(bondKey(i, j));
        return it != sparseBondProps.end() && it->second[2] != 0;
    }

    bool hasBond(int i, int j) const { return bondOrder(i, j) != 0; }

    int atomCount() const { return n; }

    int dbStereo(int i, int j) const {
        return hasDbStereo ? dbStereoConf[i][j] : 0;
    }

    const std::vector<int>& getOrbit() const          { return orbit; }
    const std::vector<int>& getCanonicalLabeling() const { return canonicalLabel; }
    int64_t getCanonicalHash() const                   { return canonicalHash; }

    // ========================================================================
    // Ring-count per atom
    // ========================================================================

    /** Compute ring counts from a given ring set (SSSR or RCB). */
    void computeRingCounts(const std::vector<std::vector<int>>& rings) const {
        std::fill(ringCount.begin(), ringCount.end(), 0);
        for (const auto& ring : rings) {
            for (int atom : ring) ringCount[atom]++;
        }
    }

    /** Default: compute ring counts from internal SSSR.
     *  For deterministic results on symmetric molecules, call
     *  computeRingCounts(smsd::computeRelevantCycles(*this)) after including ring_finder.hpp. */
    void computeRingCounts() const {
        computeRingCounts(computeRings());
    }

    // ========================================================================
    // SSSR ring computation (Horton-style shortest-path basis)
    // ========================================================================

    const std::vector<std::vector<int>>& computeRings() const {
        if (sssrComputed) return sssrRings;
        sssrComputed = true;
        if (n == 0) return sssrRings;

        // Edge count
        int edgeCount = 0;
        for (int i = 0; i < n; i++)
            edgeCount += static_cast<int>(neighbors[i].size());
        edgeCount /= 2;

        // Connected components via BFS
        std::vector<bool> visited(n, false);
        int components = 0;
        for (int i = 0; i < n; i++) {
            if (visited[i]) continue;
            components++;
            std::deque<int> bfsQ;
            bfsQ.push_back(i);
            visited[i] = true;
            while (!bfsQ.empty()) {
                int u = bfsQ.front(); bfsQ.pop_front();
                for (int v : neighbors[u])
                    if (!visited[v]) { visited[v] = true; bfsQ.push_back(v); }
            }
        }

        int cycleRank = edgeCount - n + components;
        if (cycleRank <= 0) return sssrRings;

        // For each edge (start, nb) with nb > start, find shortest path
        // from start to nb that avoids that direct edge.
        std::vector<std::vector<int>> candidates;
        for (int start = 0; start < n; start++) {
            for (int nb : neighbors[start]) {
                if (nb <= start) continue;
                std::vector<int> parent(n, -2);
                parent[start] = -1;
                std::deque<int> queue;
                queue.push_back(start);
                bool found = false;
                while (!queue.empty() && !found) {
                    int u = queue.front(); queue.pop_front();
                    for (int v : neighbors[u]) {
                        if (u == start && v == nb) continue;
                        if (v == start && u == nb) continue;
                        if (parent[v] != -2) continue;
                        parent[v] = u;
                        if (v == nb) { found = true; break; }
                        queue.push_back(v);
                    }
                }
                if (found) {
                    std::vector<int> path;
                    int cur = nb;
                    while (cur != start && cur != -1) { path.push_back(cur); cur = parent[cur]; }
                    if (cur == start) {
                        path.push_back(start);
                        if (path.size() >= 3 && path.size() <= 20)
                            candidates.push_back(std::move(path));
                    }
                }
            }
        }

        std::sort(candidates.begin(), candidates.end(),
            [](const std::vector<int>& a, const std::vector<int>& b) {
                return a.size() < b.size();
            });

        // Greedy basis: pick cycles that contribute at least one new edge
        std::vector<std::vector<int>> basis;
        std::vector<std::unordered_set<int64_t>> basisEdges;

        for (auto& cycle : candidates) {
            if (static_cast<int>(basis.size()) >= cycleRank) break;
            std::unordered_set<int64_t> edges;
            for (size_t i = 0; i < cycle.size(); i++) {
                int a = cycle[i], b = cycle[(i + 1) % cycle.size()];
                edges.insert(bondKey(std::min(a, b), std::max(a, b)));
            }
            std::unordered_set<int64_t> allBasis;
            for (auto& be : basisEdges) allBasis.insert(be.begin(), be.end());
            bool hasNewEdge = false;
            for (int64_t e : edges) {
                if (allBasis.find(e) == allBasis.end()) { hasNewEdge = true; break; }
            }
            if (hasNewEdge || basis.empty()) {
                basis.push_back(cycle);
                basisEdges.push_back(std::move(edges));
            }
        }

        sssrRings = std::move(basis);
        return sssrRings;
    }

    // ========================================================================
    // Relevant cycles (union of all minimum cycle bases)
    // ========================================================================

private:

    /** Find the lowest set bit position in a GF(2) vector. */
    static int findPivotBit(const std::vector<uint64_t>& vec) {
        for (size_t w = 0; w < vec.size(); w++) {
            if (vec[w] != 0) return static_cast<int>((w << 6) + smsd::ctz64(vec[w]));
        }
        return -1;
    }

    /** Reduce a GF(2) vector against a row echelon basis. Returns true if zero. */
    static bool reduceVectorGF2(std::vector<uint64_t>& vec,
                                const std::vector<std::vector<uint64_t>>& basis,
                                int basisSize) {
        for (int i = 0; i < basisSize; i++) {
            int pivot = findPivotBit(basis[i]);
            if (pivot >= 0 && ((vec[pivot >> 6] >> (pivot & 63)) & 1ULL) != 0) {
                for (size_t w = 0; w < vec.size(); w++) vec[w] ^= basis[i][w];
            }
        }
        for (auto w : vec) if (w != 0) return false;
        return true;
    }

    /** Add a GF(2) vector to row echelon basis if linearly independent. */
    static int addToBasisGF2(std::vector<uint64_t>& vec,
                             std::vector<std::vector<uint64_t>>& basis,
                             int basisSize) {
        for (int i = 0; i < basisSize; i++) {
            int pivot = findPivotBit(basis[i]);
            if (pivot >= 0 && ((vec[pivot >> 6] >> (pivot & 63)) & 1ULL) != 0) {
                for (size_t w = 0; w < vec.size(); w++) vec[w] ^= basis[i][w];
            }
        }
        bool nonZero = false;
        for (auto w : vec) if (w != 0) { nonZero = true; break; }
        if (nonZero) {
            if (basisSize >= static_cast<int>(basis.size())) basis.push_back(vec);
            else basis[basisSize] = vec;
            return basisSize + 1;
        }
        return basisSize;
    }

    /** Canonical edge-set key for cycle deduplication. */
    static std::vector<int64_t> canonicalCycleKey(const std::vector<int>& cycle) {
        std::vector<int64_t> keys;
        keys.reserve(cycle.size());
        for (size_t i = 0; i < cycle.size(); i++) {
            int a = cycle[i], b = cycle[(i + 1) % cycle.size()];
            int lo = std::min(a, b), hi = std::max(a, b);
            keys.push_back(static_cast<int64_t>(lo) * 100000 + hi);
        }
        std::sort(keys.begin(), keys.end());
        return keys;
    }

    /** Enumerate all shortest paths from root to target in a BFS tree. */
    static void buildPathsHelper(int root, int node, const std::vector<int>& dist,
                                 const std::vector<std::vector<int>>& parents,
                                 std::vector<int>& current,
                                 std::vector<std::vector<int>>& result, int limit) {
        if (static_cast<int>(result.size()) >= limit) return;
        if (node == root) {
            std::vector<int> path(current.rbegin(), current.rend());
            result.push_back(std::move(path));
            return;
        }
        for (int p : parents[node]) {
            if (dist[p] != dist[node] - 1) continue;
            current.push_back(p);
            buildPathsHelper(root, p, dist, parents, current, result, limit);
            current.pop_back();
        }
    }

    static std::vector<std::vector<int>> allShortestPathsCpp(int root, int target,
            const std::vector<int>& dist,
            const std::vector<std::vector<int>>& parents) {
        std::vector<std::vector<int>> result;
        std::vector<int> current = { target };
        buildPathsHelper(root, target, dist, parents, current, result, 50);
        return result;
    }

    // Union-Find helpers
    static int ufFind(std::vector<int>& parent, int i) {
        while (parent[i] != i) { parent[i] = parent[parent[i]]; i = parent[i]; }
        return i;
    }
    static void ufUnion(std::vector<int>& parent, int a, int b) {
        a = ufFind(parent, a); b = ufFind(parent, b);
        if (a != b) parent[a] = b;
    }

public:

    /**
     * Computes the set of relevant cycles (union of all minimum cycle bases).
     * A cycle is relevant if it cannot be expressed as the XOR (symmetric
     * difference) of strictly shorter cycles.
     */
    std::vector<std::vector<int>> computeRelevantCycles() const {
        auto& mcb = computeRings();
        if (mcb.empty()) return {};

        // Build edge index
        std::unordered_map<int64_t, int> edgeIndex;
        for (int i = 0; i < n; i++) {
            for (int j : neighbors[i]) {
                if (j > i) {
                    int64_t key = bondKey(std::min(i, j), std::max(i, j));
                    if (edgeIndex.find(key) == edgeIndex.end()) {
                        int idx = static_cast<int>(edgeIndex.size());
                        edgeIndex[key] = idx;
                    }
                }
            }
        }
        int numEdges = static_cast<int>(edgeIndex.size());
        int longWords = (numEdges + 63) >> 6;

        // Find max cycle length in MCB
        int maxLen = 0;
        for (auto& c : mcb) if (static_cast<int>(c.size()) > maxLen) maxLen = static_cast<int>(c.size());

        // Collect all short cycles
        std::set<std::vector<int64_t>> uniqueCycleSet;
        std::vector<std::vector<int>> allCycles;

        // Add MCB cycles
        for (auto& c : mcb) {
            auto key = canonicalCycleKey(c);
            if (uniqueCycleSet.insert(key).second) allCycles.push_back(c);
        }

        // Enumerate short cycles via BFS from each vertex
        for (int root = 0; root < n; root++) {
            std::vector<int> dist(n, -1);
            dist[root] = 0;
            std::vector<std::vector<int>> parents(n);
            std::deque<int> queue;
            queue.push_back(root);
            while (!queue.empty()) {
                int u = queue.front(); queue.pop_front();
                if (dist[u] >= maxLen / 2) continue;
                for (int v : neighbors[u]) {
                    if (dist[v] == -1) {
                        dist[v] = dist[u] + 1;
                        parents[v].push_back(u);
                        queue.push_back(v);
                    } else if (dist[v] == dist[u] + 1) {
                        parents[v].push_back(u);
                    }
                }
            }

            // Odd-length cycles from edges
            for (int u = 0; u < n; u++) {
                if (dist[u] == -1) continue;
                for (int v : neighbors[u]) {
                    if (v <= u || dist[v] == -1) continue;
                    int cycleLen = dist[u] + dist[v] + 1;
                    if (cycleLen < 3 || cycleLen > maxLen) continue;

                    auto pathsU = allShortestPathsCpp(root, u, dist, parents);
                    auto pathsV = allShortestPathsCpp(root, v, dist, parents);

                    for (auto& pu : pathsU) {
                        for (auto& pv : pathsV) {
                            std::unordered_set<int> puSet(pu.begin(), pu.end());
                            bool overlap = false;
                            for (size_t k = 1; k < pv.size(); k++) {
                                if (puSet.count(pv[k])) { overlap = true; break; }
                            }
                            if (overlap) continue;

                            std::vector<int> cycle;
                            cycle.reserve(pu.size() + pv.size() - 1);
                            for (int x : pu) cycle.push_back(x);
                            for (int k = static_cast<int>(pv.size()) - 2; k >= 0; k--)
                                cycle.push_back(pv[k]);

                            if (static_cast<int>(cycle.size()) >= 3 &&
                                static_cast<int>(cycle.size()) <= maxLen) {
                                auto key = canonicalCycleKey(cycle);
                                if (uniqueCycleSet.insert(key).second)
                                    allCycles.push_back(std::move(cycle));
                            }
                        }
                    }
                }
            }

            // Even-length cycles from two disjoint paths to same vertex
            for (int u = 0; u < n; u++) {
                if (dist[u] == -1 || static_cast<int>(parents[u].size()) < 2) continue;
                int cycleLen = 2 * dist[u];
                if (cycleLen < 3 || cycleLen > maxLen) continue;

                auto paths = allShortestPathsCpp(root, u, dist, parents);
                for (size_t pi = 0; pi < paths.size(); pi++) {
                    for (size_t pj = pi + 1; pj < paths.size(); pj++) {
                        auto& p1 = paths[pi]; auto& p2 = paths[pj];
                        std::unordered_set<int> p1Int;
                        for (size_t k = 1; k + 1 < p1.size(); k++) p1Int.insert(p1[k]);
                        bool disjoint = true;
                        for (size_t k = 1; k + 1 < p2.size(); k++) {
                            if (p1Int.count(p2[k])) { disjoint = false; break; }
                        }
                        if (!disjoint) continue;

                        std::vector<int> cycle;
                        cycle.reserve(cycleLen);
                        for (size_t k = 0; k < p1.size(); k++) cycle.push_back(p1[k]);
                        for (int k = static_cast<int>(p2.size()) - 2; k >= 1; k--)
                            cycle.push_back(p2[k]);

                        if (static_cast<int>(cycle.size()) >= 3 &&
                            static_cast<int>(cycle.size()) <= maxLen) {
                            auto key = canonicalCycleKey(cycle);
                            if (uniqueCycleSet.insert(key).second)
                                allCycles.push_back(std::move(cycle));
                        }
                    }
                }
            }
        }

        // Sort by length
        std::sort(allCycles.begin(), allCycles.end(),
            [](const std::vector<int>& a, const std::vector<int>& b) {
                return a.size() < b.size();
            });

        // Build GF(2) edge-incidence vectors
        std::vector<std::vector<uint64_t>> vectors(allCycles.size(),
            std::vector<uint64_t>(longWords, 0));
        for (size_t ci = 0; ci < allCycles.size(); ci++) {
            auto& c = allCycles[ci];
            for (size_t i = 0; i < c.size(); i++) {
                int a = c[i], b = c[(i + 1) % c.size()];
                int64_t key = bondKey(std::min(a, b), std::max(a, b));
                int idx = edgeIndex[key];
                vectors[ci][idx >> 6] ^= 1ULL << (idx & 63);
            }
        }

        // Filter relevant cycles via Gaussian elimination on GF(2)
        std::vector<std::vector<int>> relevant;
        std::vector<std::vector<uint64_t>> reducedBasis(numEdges,
            std::vector<uint64_t>(longWords, 0));
        int basisSize = 0;

        size_t ci = 0;
        while (ci < allCycles.size()) {
            int len = static_cast<int>(allCycles[ci].size());
            size_t cj = ci;
            while (cj < allCycles.size() && static_cast<int>(allCycles[cj].size()) == len) cj++;

            // Test each cycle against basis of strictly shorter cycles
            for (size_t k = ci; k < cj; k++) {
                auto vec = vectors[k];
                bool inSpan = reduceVectorGF2(vec, reducedBasis, basisSize);
                if (!inSpan) relevant.push_back(allCycles[k]);
            }

            // Add all cycles of this length to basis
            for (size_t k = ci; k < cj; k++) {
                auto vec = vectors[k];
                basisSize = addToBasisGF2(vec, reducedBasis, basisSize);
            }

            ci = cj;
        }

        return relevant;
    }

    /**
     * Computes Unique Ring Families (URFs). Two relevant cycles belong to the
     * same URF if one can be obtained from the other by a single edge exchange
     * (their symmetric difference has exactly two edges sharing a vertex).
     */
    std::vector<std::vector<std::vector<int>>> computeURFs() {
        auto rc = computeRelevantCycles();
        if (rc.empty()) return {};

        // Build edge index
        std::unordered_map<int64_t, int> edgeIndex;
        for (int i = 0; i < n; i++) {
            for (int j : neighbors[i]) {
                if (j > i) {
                    int64_t key = bondKey(std::min(i, j), std::max(i, j));
                    if (edgeIndex.find(key) == edgeIndex.end()) {
                        int idx = static_cast<int>(edgeIndex.size());
                        edgeIndex[key] = idx;
                    }
                }
            }
        }
        int numEdges = static_cast<int>(edgeIndex.size());
        int longWords = (numEdges + 63) >> 6;

        // Build reverse lookup
        std::vector<std::pair<int,int>> edgeByIndex(numEdges);
        for (auto& [key, idx] : edgeIndex) {
            edgeByIndex[idx] = { static_cast<int>(key >> 32),
                                 static_cast<int>(key & 0xFFFFFFFF) };
        }

        // Build edge-incidence vectors
        int nrc = static_cast<int>(rc.size());
        std::vector<std::vector<uint64_t>> vectors(nrc, std::vector<uint64_t>(longWords, 0));
        for (int ci = 0; ci < nrc; ci++) {
            auto& c = rc[ci];
            for (size_t i = 0; i < c.size(); i++) {
                int a = c[i], b = c[(i + 1) % c.size()];
                int64_t key = bondKey(std::min(a, b), std::max(a, b));
                int idx = edgeIndex[key];
                vectors[ci][idx >> 6] ^= 1ULL << (idx & 63);
            }
        }

        // Union-Find grouping
        std::vector<int> family(nrc);
        std::iota(family.begin(), family.end(), 0);

        for (int i = 0; i < nrc; i++) {
            for (int j = i + 1; j < nrc; j++) {
                if (rc[i].size() != rc[j].size()) continue;
                int popcount = 0;
                std::vector<uint64_t> xorVec(longWords);
                for (int w = 0; w < longWords; w++) {
                    xorVec[w] = vectors[i][w] ^ vectors[j][w];
                    popcount += smsd::popcount64(xorVec[w]);
                }
                if (popcount == 2) {
                    int diffEdges[2]; int di = 0;
                    for (int w = 0; w < longWords && di < 2; w++) {
                        uint64_t bits = xorVec[w];
                        while (bits != 0 && di < 2) {
                            int bit = smsd::ctz64(bits);
                            diffEdges[di++] = (w << 6) + bit;
                            bits &= bits - 1;
                        }
                    }
                    auto [u1, v1] = edgeByIndex[diffEdges[0]];
                    auto [u2, v2] = edgeByIndex[diffEdges[1]];
                    if (u1 == u2 || u1 == v2 || v1 == u2 || v1 == v2) {
                        ufUnion(family, i, j);
                    }
                }
            }
        }

        // Group by family
        std::unordered_map<int, std::vector<int>> groups;
        for (int i = 0; i < nrc; i++) groups[ufFind(family, i)].push_back(i);

        std::vector<std::vector<std::vector<int>>> result;
        for (auto& [rep, members] : groups) {
            std::vector<std::vector<int>> fam;
            for (int m : members) fam.push_back(rc[m]);
            result.push_back(std::move(fam));
        }
        return result;
    }

    // ========================================================================
    // Tautomer class detection — 15 pKa-informed transforms (Tier 1)
    // ========================================================================

    void computeTautomerClasses() {
        tautomerClass.assign(n, -1);
        tautomerWeight.assign(n, 1.0f);
        int classId = 0;

        // Helper: assign cls + weight to a set of atoms.
        // If any atom already belongs to an existing class, merge by reusing
        // that class for all atoms in the group (prevents class fracture when
        // tautomeric motifs overlap on shared atoms).
        auto tc = [&](std::initializer_list<int> atoms, int cls, float w) {
            // Check if any atom already has a class — if so, merge into it
            for (int a : atoms)
                if (tautomerClass[a] != -1) { cls = tautomerClass[a]; break; }
            for (int a : atoms) {
                tautomerClass[a] = cls;
                if (tautomerWeight[a] == 1.0f) tautomerWeight[a] = w;
            }
        };

        for (int i = 0; i < n; i++) {
            if (tautomerClass[i] != -1) continue;

            // ------------------------------------------------------------------
            // T1: Keto/enol  C=O ↔ C-OH
            //     Amide carbonyl (N on C) → TW_AMIDE_IMIDIC; else TW_KETO_ENOL
            // ------------------------------------------------------------------
            if (atomicNum[i] == 8 && !aromatic[i]) {
                for (int j : neighbors[i]) {
                    if (atomicNum[j] == 6 && bondOrder(i, j) == 2) {
                        bool hasN = false;
                        for (int k : neighbors[j]) {
                            if (k != i && atomicNum[k] == 7) { hasN = true; break; }
                        }
                        float w = hasN ? TW_AMIDE_IMIDIC : TW_KETO_ENOL;
                        int cls = -1;
                        for (int k : neighbors[j]) {
                            if (k != i && atomicNum[k] == 6 && !aromatic[k]) {
                                if (cls == -1) { cls = classId++; tautomerClass[i] = cls; tautomerWeight[i] = w; }
                                if (tautomerClass[k] == -1) { tautomerClass[k] = cls; if (tautomerWeight[k] == 1.0f) tautomerWeight[k] = w; }
                            }
                        }
                        for (int k : neighbors[j]) {
                            if (k != i && atomicNum[k] == 7) {
                                if (cls == -1) { cls = classId++; tautomerClass[i] = cls; tautomerWeight[i] = w; }
                                if (tautomerClass[k] == -1) { tautomerClass[k] = cls; if (tautomerWeight[k] == 1.0f) tautomerWeight[k] = w; }
                            }
                        }
                        if (cls != -1) break;
                    }
                }
            }

            // ------------------------------------------------------------------
            // T2: Thione/thiol  C=S ↔ C-SH
            //     Thioamide N-C(=S) → TW_THIOAMIDE; else TW_THIONE_THIOL
            // ------------------------------------------------------------------
            if (atomicNum[i] == 16 && !aromatic[i] && tautomerClass[i] == -1) {
                for (int j : neighbors[i]) {
                    if (atomicNum[j] == 6 && bondOrder(i, j) == 2) {
                        bool hasN = false;
                        for (int k : neighbors[j]) { if (k != i && atomicNum[k] == 7) { hasN = true; break; } }
                        float w = hasN ? TW_THIOAMIDE : TW_THIONE_THIOL;
                        int cls = -1;
                        for (int k : neighbors[j]) {
                            if (k != i && (atomicNum[k] == 6 || atomicNum[k] == 7)) {
                                if (cls == -1) { cls = classId++; tautomerClass[i] = cls; tautomerWeight[i] = w; }
                                if (tautomerClass[k] == -1) { tautomerClass[k] = cls; if (tautomerWeight[k] == 1.0f) tautomerWeight[k] = w; }
                            }
                        }
                        if (cls != -1) break;
                    }
                }
            }

            // ------------------------------------------------------------------
            // T3: Nitroso/oxime  C=N-OH ↔ C(=O)-NH
            //     Requires N=C double bond to avoid matching simple amide N-C=O
            // ------------------------------------------------------------------
            if (atomicNum[i] == 7 && !ring[i] && tautomerClass[i] == -1) {
                for (int j : neighbors[i]) {
                    if (atomicNum[j] == 6 && bondOrder(i, j) == 2) {
                        for (int k : neighbors[j]) {
                            if (k != i && atomicNum[k] == 8) {
                                int cls = classId++;
                                tc({i, k}, cls, TW_NITROSO_OXIME);
                                break;
                            }
                        }
                        if (tautomerClass[i] != -1) break;
                    }
                }
            }

            // ------------------------------------------------------------------
            // T4: Phenol/quinone  arom-C-OH ↔ para-C=O
            // ------------------------------------------------------------------
            if (atomicNum[i] == 8 && !aromatic[i] && tautomerClass[i] == -1) {
                for (int j : neighbors[i]) {
                    if (atomicNum[j] == 6 && aromatic[j] && ring[j]) {
                        for (int a : neighbors[j]) {
                            if (a != i && atomicNum[a] == 6 && aromatic[a] && ring[a]) {
                                for (int b : neighbors[a]) {
                                    if (b != j && atomicNum[b] == 6 && aromatic[b] && ring[b]) {
                                        for (int c : neighbors[b]) {
                                            if (c != a && c != j && atomicNum[c] == 6 && aromatic[c] && ring[c]) {
                                                int cls = classId++;
                                                tc({i, j, c}, cls, TW_PHENOL_QUINONE);
                                                for (int d : neighbors[c]) {
                                                    if (atomicNum[d] == 8 && !aromatic[d] && tautomerClass[d] == -1) {
                                                        tautomerClass[d] = cls; tautomerWeight[d] = TW_PHENOL_QUINONE;
                                                    }
                                                }
                                                break;
                                            }
                                        }
                                        if (tautomerClass[i] != -1) break;
                                    }
                                }
                                if (tautomerClass[i] != -1) break;
                            }
                        }
                        if (tautomerClass[i] != -1) break;
                    }
                }
            }

            // ------------------------------------------------------------------
            // T5: 1,3-diketone  C(=O)-C-C(=O)  enolisation  (pKa ~8-11)
            // ------------------------------------------------------------------
            if (atomicNum[i] == 8 && !aromatic[i] && tautomerClass[i] == -1) {
                for (int j : neighbors[i]) {
                    if (atomicNum[j] == 6 && bondOrder(i, j) == 2) {
                        for (int bridge : neighbors[j]) {
                            if (bridge != i && atomicNum[bridge] == 6 && !aromatic[bridge]) {
                                for (int m : neighbors[bridge]) {
                                    if (m != j && atomicNum[m] == 6) {
                                        for (int o2 : neighbors[m]) {
                                            if (o2 != bridge && atomicNum[o2] == 8 && !aromatic[o2]) {
                                                int cls = (tautomerClass[o2] != -1) ? tautomerClass[o2] : classId++;
                                                float w = TW_DIKETONE_ENOL;
                                                if (tautomerClass[i]      == -1) { tautomerClass[i]      = cls; tautomerWeight[i]      = w; }
                                                if (tautomerClass[bridge] == -1) { tautomerClass[bridge] = cls; tautomerWeight[bridge] = w; }
                                                if (tautomerClass[o2]     == -1) { tautomerClass[o2]     = cls; tautomerWeight[o2]     = w; }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // ------------------------------------------------------------------
            // T6: Pyridinone / lactam  aromatic N adjacent to exocyclic C=O
            // ------------------------------------------------------------------
            if (atomicNum[i] == 7 && aromatic[i] && ring[i] && tautomerClass[i] == -1) {
                for (int j : neighbors[i]) {
                    if (atomicNum[j] == 6 && aromatic[j]) {
                        for (int k : neighbors[j]) {
                            if (k != i && atomicNum[k] == 8 && !aromatic[k] && tautomerClass[k] == -1) {
                                int cls = classId++;
                                tc({i, k}, cls, TW_PYRIDINONE);
                            }
                        }
                    }
                }
            }

            // ------------------------------------------------------------------
            // T7: Imidazole / pyrazole  aromatic N-C-N or direct N-N in ring
            // ------------------------------------------------------------------
            if (atomicNum[i] == 7 && aromatic[i] && ring[i] && tautomerClass[i] == -1) {
                // Direct N-N bond (pyrazole / indazole)
                for (int j : neighbors[i]) {
                    if (atomicNum[j] == 7 && aromatic[j] && ring[j] && tautomerClass[j] == -1) {
                        int cls = classId++;
                        tc({i, j}, cls, TW_IMIDAZOLE_NH);
                        break;
                    }
                }
                // N-C-N through aromatic C (imidazole / benzimidazole)
                if (tautomerClass[i] == -1) {
                    for (int j : neighbors[i]) {
                        if (atomicNum[j] == 6 && aromatic[j] && ring[j]) {
                            for (int k : neighbors[j]) {
                                if (k != i && atomicNum[k] == 7 && aromatic[k] && ring[k] && tautomerClass[k] == -1) {
                                    int cls = classId++;
                                    tc({i, k}, cls, TW_IMIDAZOLE_NH);
                                    break;
                                }
                            }
                            if (tautomerClass[i] != -1) break;
                        }
                    }
                }
            }

            // ------------------------------------------------------------------
            // T8: Amidine  N=C-N ↔ N-C=N  (non-aromatic, symmetric, weight 0.50)
            // ------------------------------------------------------------------
            if (atomicNum[i] == 7 && !aromatic[i] && tautomerClass[i] == -1) {
                for (int j : neighbors[i]) {
                    if (atomicNum[j] == 6 && bondOrder(i, j) == 2) {
                        for (int k : neighbors[j]) {
                            if (k != i && atomicNum[k] == 7 && !aromatic[k]) {
                                int cls = classId++;
                                tc({i, j, k}, cls, TW_AMIDINE);
                                break;
                            }
                        }
                        if (tautomerClass[i] != -1) break;
                    }
                }
            }

            // ------------------------------------------------------------------
            // T9: Guanidine  C connected to ≥3 N  (symmetric, weight 0.50)
            // ------------------------------------------------------------------
            if (atomicNum[i] == 6 && tautomerClass[i] == -1) {
                std::vector<int> nNbrs;
                for (int j : neighbors[i]) { if (atomicNum[j] == 7 && !aromatic[j]) nNbrs.push_back(j); }
                if (nNbrs.size() >= 3) {
                    int cls = classId++;
                    tautomerClass[i] = cls; tautomerWeight[i] = TW_GUANIDINE;
                    for (int ni : nNbrs) {
                        if (tautomerClass[ni] == -1) { tautomerClass[ni] = cls; tautomerWeight[ni] = TW_GUANIDINE; }
                    }
                }
            }

            // ------------------------------------------------------------------
            // T10: Urea  O=C(-N)(-N)  — two N on same carbonyl C
            // ------------------------------------------------------------------
            if (atomicNum[i] == 8 && !aromatic[i] && tautomerClass[i] == -1) {
                for (int j : neighbors[i]) {
                    if (atomicNum[j] == 6 && bondOrder(i, j) == 2) {
                        std::vector<int> nn;
                        for (int k : neighbors[j]) { if (k != i && atomicNum[k] == 7) nn.push_back(k); }
                        if (nn.size() >= 2) {
                            int cls = classId++;
                            tautomerClass[i] = cls; tautomerWeight[i] = TW_UREA;
                            tautomerClass[j] = cls; tautomerWeight[j] = TW_UREA;
                            for (int ni : nn) {
                                if (tautomerClass[ni] == -1) { tautomerClass[ni] = cls; tautomerWeight[ni] = TW_UREA; }
                            }
                        }
                        break;
                    }
                }
            }

            // ------------------------------------------------------------------
            // T11: β-Enaminone  N-C=C-C=O  (vinylogous amide, weight 0.85)
            // ------------------------------------------------------------------
            if (atomicNum[i] == 7 && !aromatic[i] && tautomerClass[i] == -1) {
                bool found11 = false;
                for (int j : neighbors[i]) {
                    if (found11) break;
                    if (atomicNum[j] == 6 && bondOrder(i, j) == 1) {
                        for (int k : neighbors[j]) {
                            if (found11) break;
                            if (k != i && atomicNum[k] == 6 && bondOrder(j, k) == 2) {
                                for (int m : neighbors[k]) {
                                    if (found11) break;
                                    if (m != j && atomicNum[m] == 6) {
                                        for (int o : neighbors[m]) {
                                            if (o != k && atomicNum[o] == 8 && bondOrder(m, o) == 2) {
                                                int cls = classId++;
                                                tc({i, j, k, m, o}, cls, TW_ENAMINONE);
                                                found11 = true; break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // ------------------------------------------------------------------
            // T12: Imide  C(=O)-N-C(=O)  — N flanked by two carbonyls (pKa ~9-10)
            // ------------------------------------------------------------------
            if (atomicNum[i] == 7 && tautomerClass[i] == -1) {
                std::vector<int> carbonyls;
                for (int j : neighbors[i]) {
                    if (atomicNum[j] == 6) {
                        for (int k : neighbors[j]) {
                            if (k != i && atomicNum[k] == 8 && bondOrder(j, k) == 2) {
                                carbonyls.push_back(j); break;
                            }
                        }
                    }
                }
                if (carbonyls.size() >= 2) {
                    int cls = classId++;
                    tautomerClass[i] = cls; tautomerWeight[i] = TW_IMIDE;
                    for (int c : carbonyls) {
                        if (tautomerClass[c] == -1) { tautomerClass[c] = cls; tautomerWeight[c] = TW_IMIDE; }
                    }
                }
            }

            // ------------------------------------------------------------------
            // T13: Hydroxamic acid  N(-OH)-C=O ↔ NH-C(=O)-OH  (pKa ~8)
            // ------------------------------------------------------------------
            if (atomicNum[i] == 7 && tautomerClass[i] == -1) {
                int oh = -1;
                for (int j : neighbors[i]) {
                    if (atomicNum[j] == 8 && !aromatic[j] && bondOrder(i, j) == 1) { oh = j; break; }
                }
                if (oh != -1) {
                    for (int j : neighbors[i]) {
                        if (atomicNum[j] == 6) {
                            for (int k : neighbors[j]) {
                                if (k != i && atomicNum[k] == 8 && bondOrder(j, k) == 2) {
                                    int cls = classId++;
                                    tc({i, oh, j, k}, cls, TW_HYDROXAMIC);
                                    break;
                                }
                            }
                            if (tautomerClass[i] != -1) break;
                        }
                    }
                }
            }

            // ------------------------------------------------------------------
            // T14: Hydroxypyrimidine / purine  exocyclic OH on arom-C with ring-N
            // ------------------------------------------------------------------
            if (atomicNum[i] == 8 && !aromatic[i] && tautomerClass[i] == -1) {
                for (int j : neighbors[i]) {
                    if (atomicNum[j] == 6 && aromatic[j] && ring[j] && bondOrder(i, j) == 1) {
                        for (int k : neighbors[j]) {
                            if (k != i && atomicNum[k] == 7 && aromatic[k] && ring[k]) {
                                int cls = classId++;
                                tc({i, j, k}, cls, TW_HYDROXYPYRIMIDINE);
                                break;
                            }
                        }
                        if (tautomerClass[i] != -1) break;
                    }
                }
            }

            // ------------------------------------------------------------------
            // T15: Tetrazole / triazole N-H  (aromatic ring with ≥2 adjacent N)
            //      1H/2H symmetric, weight 0.50
            // ------------------------------------------------------------------
            if (atomicNum[i] == 7 && aromatic[i] && ring[i] && tautomerClass[i] == -1) {
                std::vector<int> adjN;
                for (int j : neighbors[i]) {
                    if (atomicNum[j] == 7 && aromatic[j] && ring[j]) adjN.push_back(j);
                }
                if (adjN.size() >= 2) {
                    for (int j : adjN) {
                        if (tautomerClass[j] == -1) {
                            int cls = classId++;
                            tc({i, j}, cls, TW_TETRAZOLE_NH);
                            break;
                        }
                    }
                }
            }
        }
    }

    // ========================================================================
    // Tier 2: Solvent-dependent tautomer weight corrections
    //
    // Aprotic/non-aqueous solvents shift keto-enol and related equilibria.
    // Literature pKa shifts (Bordwell 1988; Olmstead 1977):
    //   DMSO:       keto-enol +5 pKa units  -> enol more prevalent (shift -0.15)
    //               amide/lactam +3          -> imidic slightly more prevalent
    //   Methanol:   keto-enol +2             -> small shift (-0.05)
    //   Chloroform: keto-enol +8 (aprotic)   -> much more enol (-0.25)
    // ========================================================================

    /** Adjust tautomer weights for solvent effects. Call after computeTautomerClasses(). */
    void applySolventCorrection(ChemOptions::Solvent solvent) {
        if (solvent == ChemOptions::Solvent::AQUEOUS) return;

        float ketoShift  = 0.0f;
        float amideShift = 0.0f;
        float generalShift = 0.0f;

        if (solvent == ChemOptions::Solvent::DMSO) {
            ketoShift    = -0.15f;
            amideShift   = -0.08f;
            generalShift = -0.05f;
        } else if (solvent == ChemOptions::Solvent::CHLOROFORM) {
            ketoShift    = -0.25f;
            amideShift   = -0.12f;
            generalShift = -0.08f;
        } else if (solvent == ChemOptions::Solvent::METHANOL) {
            ketoShift    = -0.05f;
            amideShift   = -0.02f;
            generalShift = -0.01f;
        }

        for (int i = 0; i < n; i++) {
            if (tautomerClass[i] == -1) continue;
            float w = tautomerWeight[i];
            if (w >= 1.0f) continue;

            float shift;
            if (w >= 0.96f) {
                shift = (w >= 0.97f) ? amideShift : ketoShift;
                if (std::abs(w - TW_KETO_ENOL) < 0.005f) shift = ketoShift;
            } else if (w >= 0.93f) {
                shift = amideShift;
            } else if (w >= 0.84f) {
                shift = generalShift;
            } else {
                shift = generalShift;
            }

            tautomerWeight[i] = std::max(0.05f, std::min(0.99f, w + shift));
        }
    }

    // ========================================================================
    // Morgan rank computation
    // ========================================================================

    static std::vector<int> computeMorganRanks(
            int n, const std::vector<int>& initLabel,
            const std::vector<std::vector<int>>& neighbors) {
        std::vector<int> rank(initLabel.begin(), initLabel.end());
        std::vector<int> rankNew(n);
        std::vector<int> nbSorted;

        for (int iter = 0; iter < 8; iter++) {
            std::unordered_set<int> prevSet(rank.begin(), rank.end());
            int prevDistinct = static_cast<int>(prevSet.size());

            for (int v = 0; v < n; v++) {
                const auto& nbs = neighbors[v];
                int deg = static_cast<int>(nbs.size());
                nbSorted.resize(deg);
                for (int k = 0; k < deg; k++) nbSorted[k] = rank[nbs[k]];
                std::sort(nbSorted.begin(), nbSorted.end());
                int h = rank[v] * HASH_PRIME;
                for (int k = 0; k < deg; k++) h = h * 31 + nbSorted[k];
                rankNew[v] = h;
            }
            rank = rankNew;

            std::unordered_set<int> newSet(rank.begin(), rank.end());
            if (static_cast<int>(newSet.size()) <= prevDistinct) break;
        }
        return rank;
    }

    // ========================================================================
    // Union-Find helpers (reuse ufFind/ufUnion defined above)
    // ========================================================================

    static std::vector<int> buildOrbits(std::vector<int>& uf, int n) {
        std::vector<int> orb(n);
        for (int i = 0; i < n; i++) orb[i] = ufFind(uf, i);
        std::vector<int> orbitMin(n, n);
        for (int i = 0; i < n; i++) {
            int r = orb[i];
            if (i < orbitMin[r]) orbitMin[r] = i;
        }
        for (int i = 0; i < n; i++) orb[i] = orbitMin[orb[i]];
        return orb;
    }

    // ========================================================================
    // Canonical labeling (Bliss-style partition refinement + individualization)
    // ========================================================================

    static int findSmallestNonSingleton(int n, const std::vector<bool>& cellEnd) {
        int bestSize = n + 1, bestEnd = -1, cellStart = 0;
        for (int i = 0; i < n; i++) {
            if (cellEnd[i]) {
                int size = i - cellStart + 1;
                if (size > 1 && size < bestSize) { bestSize = size; bestEnd = i; }
                cellStart = i + 1;
            }
        }
        return bestEnd;
    }

    static void refinePartition(
            int n, std::vector<int>& perm, std::vector<bool>& cellEnd,
            const std::vector<std::vector<int>>& neighbors,
            const std::vector<int>& label, int /*targetPos*/) {
        std::vector<int> inv(n);
        for (int i = 0; i < n; i++) inv[perm[i]] = i;

        bool changed = true;
        int maxIter = n * 2 + 10;
        while (changed && maxIter-- > 0) {
            changed = false;
            int sStart = 0;
            for (int sEnd = 0; sEnd < n; sEnd++) {
                if (!cellEnd[sEnd]) continue;
                int cStart = 0;
                for (int cEnd = 0; cEnd < n; cEnd++) {
                    if (!cellEnd[cEnd]) continue;
                    int cSize = cEnd - cStart + 1;
                    if (cSize <= 1) { cStart = cEnd + 1; continue; }

                    std::vector<int> count(cSize);
                    for (int ci = 0; ci < cSize; ci++) {
                        int v = perm[cStart + ci], cnt = 0;
                        for (int nb : neighbors[v]) {
                            int nbPos = inv[nb];
                            if (nbPos >= sStart && nbPos <= sEnd) cnt++;
                        }
                        count[ci] = cnt;
                    }

                    bool allSame = true;
                    for (int ci = 1; ci < cSize; ci++) {
                        if (count[ci] != count[0]) { allSame = false; break; }
                    }
                    if (allSame) { cStart = cEnd + 1; continue; }

                    // Sort indices within the cell
                    std::vector<int> idx(cSize);
                    std::iota(idx.begin(), idx.end(), 0);
                    const int fcs = cStart;
                    std::sort(idx.begin(), idx.end(), [&](int a, int b) {
                        if (count[a] != count[b]) return count[a] < count[b];
                        if (label[perm[fcs + a]] != label[perm[fcs + b]])
                            return label[perm[fcs + a]] < label[perm[fcs + b]];
                        return perm[fcs + a] < perm[fcs + b];
                    });

                    std::vector<int> tmp(cSize);
                    for (int ci = 0; ci < cSize; ci++) tmp[ci] = perm[cStart + idx[ci]];
                    std::copy(tmp.begin(), tmp.end(), perm.begin() + cStart);
                    for (int ci = 0; ci < cSize; ci++) inv[perm[cStart + ci]] = cStart + ci;

                    for (int ci = 0; ci < cSize - 1; ci++) {
                        bool wasBoundary = (cStart + ci == cEnd);
                        bool newBoundary = (count[idx[ci]] != count[idx[ci + 1]]);
                        cellEnd[cStart + ci] = newBoundary || wasBoundary;
                        if (newBoundary && !wasBoundary) changed = true;
                    }
                    cellEnd[cEnd] = true;
                    cStart = cEnd + 1;
                }
                sStart = sEnd + 1;
            }
        }
    }

    static int comparePerm(
            const std::vector<int>& perm1, const std::vector<int>& perm2,
            int n, const std::vector<int>& label,
            const std::vector<std::vector<int>>& neighbors) {
        std::vector<int> inv1(n), inv2(n);
        for (int i = 0; i < n; i++) { inv1[perm1[i]] = i; inv2[perm2[i]] = i; }
        for (int pos = 0; pos < n; pos++) {
            int v1 = perm1[pos], v2 = perm2[pos];
            int c = label[v1] - label[v2];
            if (c != 0) return c;
            const auto& nb1 = neighbors[v1];
            const auto& nb2 = neighbors[v2];
            c = static_cast<int>(nb1.size()) - static_cast<int>(nb2.size());
            if (c != 0) return c;
            std::vector<int> cn1(nb1.size()), cn2(nb2.size());
            for (size_t k = 0; k < nb1.size(); k++) cn1[k] = inv1[nb1[k]];
            for (size_t k = 0; k < nb2.size(); k++) cn2[k] = inv2[nb2[k]];
            std::sort(cn1.begin(), cn1.end());
            std::sort(cn2.begin(), cn2.end());
            for (size_t k = 0; k < cn1.size(); k++) {
                c = cn1[k] - cn2[k];
                if (c != 0) return c;
            }
        }
        return 0;
    }

    static int partialCompare(
            const std::vector<int>& perm, const std::vector<int>& bestPerm,
            int n, const std::vector<bool>& cellEnd,
            const std::vector<int>& label,
            const std::vector<std::vector<int>>& /*neighbors*/) {
        int cellStart = 0;
        for (int pos = 0; pos < n; pos++) {
            if (cellEnd[pos]) {
                if (pos == cellStart) {
                    int c = label[perm[pos]] - label[bestPerm[pos]];
                    if (c != 0) return c;
                }
                cellStart = pos + 1;
            }
        }
        return 0;
    }

    struct CanonResult {
        std::vector<int> canonLabel;
        std::vector<int> orbit;
    };

    static CanonResult computeCanonicalLabeling(
            int n, const std::vector<int>& label,
            const std::vector<int>& degree,
            const std::vector<std::vector<int>>& neighbors) {
        if (n == 0) return {{}, {}};

        // Morgan-like refinement for initial ordering
        std::vector<int> mRank(label.begin(), label.end());
        std::vector<int> mNew(n);
        std::vector<int> scratch;

        for (int iter = 0; iter < 8; iter++) {
            std::unordered_set<int> s(mRank.begin(), mRank.end());
            int prevDistinct = static_cast<int>(s.size());
            for (int v = 0; v < n; v++) {
                const auto& nbs = neighbors[v];
                int d = static_cast<int>(nbs.size());
                scratch.resize(d);
                for (int k = 0; k < d; k++) scratch[k] = mRank[nbs[k]];
                std::sort(scratch.begin(), scratch.end());
                int h = mRank[v] * HASH_PRIME;
                for (int k = 0; k < d; k++) h = h * 31 + scratch[k];
                mNew[v] = h;
            }
            mRank = mNew;
            std::unordered_set<int> ns(mRank.begin(), mRank.end());
            if (static_cast<int>(ns.size()) <= prevDistinct) break;
        }

        // Union-find for orbit computation
        std::vector<int> uf(n);
        std::iota(uf.begin(), uf.end(), 0);

        // Initial partition: sort atoms by (label, degree, mRank)
        std::vector<int> sorted(n);
        std::iota(sorted.begin(), sorted.end(), 0);
        std::sort(sorted.begin(), sorted.end(), [&](int a, int b) {
            if (label[a] != label[b]) return label[a] < label[b];
            if (degree[a] != degree[b]) return degree[a] < degree[b];
            return mRank[a] < mRank[b];
        });

        std::vector<int> initPerm(sorted);
        std::vector<bool> initCellEnd(n, false);
        for (int i = 0; i < n - 1; i++) {
            int vi = sorted[i], vj = sorted[i + 1];
            initCellEnd[i] = (label[vi] != label[vj]
                           || degree[vi] != degree[vj]
                           || mRank[vi] != mRank[vj]);
        }
        initCellEnd[n - 1] = true;

        // For large molecules, skip individualization search
        if (n > CANON_SEARCH_LIMIT) {
            int cs = 0;
            for (int i = 0; i < n; i++) {
                if (initCellEnd[i]) {
                    for (int j = cs + 1; j <= i; j++)
                        ufUnion(uf, initPerm[cs], initPerm[j]);
                    cs = i + 1;
                }
            }
            std::vector<int> cl(n);
            for (int pos = 0; pos < n; pos++) cl[initPerm[pos]] = pos;
            return { cl, buildOrbits(uf, n) };
        }

        refinePartition(n, initPerm, initCellEnd, neighbors, label, -1);

        std::vector<int> bestPerm;
        int nodeCount = 0;
        bool budgetExceeded = false;

        std::deque<std::vector<int>>  permStack;
        std::deque<std::vector<bool>> cellEndStack;

        int targetCell = findSmallestNonSingleton(n, initCellEnd);
        if (targetCell < 0) {
            bestPerm = initPerm;
        } else {
            int cellStart = 0;
            for (int i = 0; i < n; i++) {
                if (i > 0 && initCellEnd[i - 1]) cellStart = i;
                if (i == targetCell) break;
            }
            for (int i = targetCell; i >= cellStart; i--) {
                auto p = initPerm;
                auto ce = initCellEnd;
                if (i != cellStart) {
                    int tmp = p[i];
                    std::copy_backward(p.begin() + cellStart,
                                       p.begin() + i,
                                       p.begin() + i + 1);
                    p[cellStart] = tmp;
                }
                ce[cellStart] = true;
                refinePartition(n, p, ce, neighbors, label, cellStart);
                permStack.push_front(std::move(p));
                cellEndStack.push_front(std::move(ce));
                nodeCount++;
            }
        }

        while (!permStack.empty() && !budgetExceeded) {
            auto perm = std::move(permStack.front()); permStack.pop_front();
            auto cellEnd = std::move(cellEndStack.front()); cellEndStack.pop_front();

            int nc = findSmallestNonSingleton(n, cellEnd);
            if (nc < 0) {
                if (bestPerm.empty()
                    || comparePerm(perm, bestPerm, n, label, neighbors) < 0) {
                    bestPerm = perm;
                } else if (comparePerm(perm, bestPerm, n, label, neighbors) == 0) {
                    for (int i = 0; i < n; i++)
                        ufUnion(uf, perm[i], bestPerm[i]);
                }
                continue;
            }
            if (!bestPerm.empty()
                && partialCompare(perm, bestPerm, n, cellEnd, label, neighbors) > 0)
                continue;

            int cellStart = 0;
            for (int i = 0; i < n; i++) {
                if (i > 0 && cellEnd[i - 1]) cellStart = i;
                if (i == nc) break;
            }
            int cellSize = nc - cellStart + 1;
            if (nodeCount + cellSize > MAX_SEARCH_NODES) {
                budgetExceeded = true; break;
            }

            for (int i = nc; i >= cellStart; i--) {
                auto p = perm;
                auto ce = cellEnd;
                if (i != cellStart) {
                    int tmp = p[i];
                    std::copy_backward(p.begin() + cellStart,
                                       p.begin() + i,
                                       p.begin() + i + 1);
                    p[cellStart] = tmp;
                }
                ce[cellStart] = true;
                refinePartition(n, p, ce, neighbors, label, cellStart);
                permStack.push_front(std::move(p));
                cellEndStack.push_front(std::move(ce));
                nodeCount++;
            }
        }

        if (bestPerm.empty()) bestPerm = initPerm;

        std::vector<int> cl(n);
        for (int pos = 0; pos < n; pos++) cl[bestPerm[pos]] = pos;

        // Merge initial partition orbits
        int cs = 0;
        for (int i = 0; i < n; i++) {
            if (initCellEnd[i]) {
                for (int j = cs + 1; j <= i; j++)
                    ufUnion(uf, initPerm[cs], initPerm[j]);
                cs = i + 1;
            }
        }
        return { cl, buildOrbits(uf, n) };
    }

    // ========================================================================
    // Canonical hash
    // ========================================================================

    static int64_t computeCanonicalHash(
            int n, const std::vector<int>& canonLabel,
            const std::vector<std::vector<int>>& neighbors,
            const std::vector<int>& label) {
        std::vector<int> inv(n);
        for (int i = 0; i < n; i++) inv[canonLabel[i]] = i;
        int64_t hash = 0;
        for (int cp = 0; cp < n; cp++)
            hash = hash * HASH_PRIME + label[inv[cp]];
        for (int cp = 0; cp < n; cp++) {
            int v = inv[cp];
            const auto& nbs = neighbors[v];
            std::vector<int> cNbs(nbs.size());
            for (size_t k = 0; k < nbs.size(); k++) cNbs[k] = canonLabel[nbs[k]];
            std::sort(cNbs.begin(), cNbs.end());
            for (int cn : cNbs) {
                hash = hash * HASH_PRIME
                     + (static_cast<int64_t>(std::min(cp, cn)) * n + std::max(cp, cn));
            }
        }
        return hash;
    }

    // ========================================================================
    // Canonical SMILES generation
    // ========================================================================

    static const std::unordered_map<int, std::string>& organicSymbols() {
        static const std::unordered_map<int, std::string> m = {
            {5,"B"},{6,"C"},{7,"N"},{8,"O"},{15,"P"},{16,"S"},
            {9,"F"},{17,"Cl"},{35,"Br"},{53,"I"}
        };
        return m;
    }

    static const char* elementSymbol(int z) {
        static const char* const syms[] = {
            "?","H","He","Li","Be","B","C","N","O","F","Ne",
            "Na","Mg","Al","Si","P","S","Cl","Ar","K","Ca",
            "Sc","Ti","V","Cr","Mn","Fe","Co","Ni","Cu","Zn",
            "Ga","Ge","As","Se","Br","Kr","Rb","Sr","Y","Zr",
            "Nb","Mo","Tc","Ru","Rh","Pd","Ag","Cd","In","Sn",
            "Sb","Te","I","Xe","Cs","Ba","La","Ce","Pr","Nd",
            "Pm","Sm","Eu","Gd","Tb","Dy","Ho","Er","Tm","Yb",
            "Lu","Hf","Ta","W","Re","Os","Ir","Pt","Au","Hg",
            "Tl","Pb","Bi","Po","At","Rn","Fr","Ra","Ac","Th",
            "Pa","U","Np","Pu","Am","Cm","Bk","Cf","Es","Fm",
            "Md","No","Lr","Rf","Db","Sg","Bh","Hs","Mt","Ds",
            "Rg","Cn","Nh","Fl","Mc","Lv","Ts","Og"
        };
        constexpr int count = static_cast<int>(sizeof(syms) / sizeof(syms[0]));
        return (z >= 0 && z < count) ? syms[z] : "?";
    }

    std::vector<int> sortedNeighborsByCanonical(int atom) const {
        auto sorted = neighbors[atom];
        std::sort(sorted.begin(), sorted.end(), [this](int a, int b) {
            return canonicalLabel[a] < canonicalLabel[b];
        });
        return sorted;
    }

    void writeAtom(int atom, std::string& sb) const {
        int z = atomicNum[atom], charge = formalCharge[atom];
        bool arom = aromatic[atom];
        auto& org = organicSymbols();
        auto it = org.find(z);
        if (it != org.end() && charge == 0) {
            const std::string& sym = it->second;
            if (arom)
                sb += static_cast<char>(
                    std::tolower(static_cast<unsigned char>(sym[0])));
            else
                sb += sym;
        } else {
            sb += '[';
            const char* elemSym = elementSymbol(z);
            if (arom) {
                sb += static_cast<char>(
                    std::tolower(static_cast<unsigned char>(elemSym[0])));
                if (elemSym[1] != '\0') sb += &elemSym[1];
            } else {
                sb += elemSym;
            }
            if (charge > 0) {
                sb += '+';
                if (charge > 1) sb += std::to_string(charge);
            } else if (charge < 0) {
                sb += '-';
                if (charge < -1) sb += std::to_string(-charge);
            }
            sb += ']';
        }
    }

    void writeBondSymbol(int from, int to, std::string& sb) const {
        int order = bondOrder(from, to);
        bool fromArom = aromatic[from], toArom = aromatic[to];
        if (order == 4 || (fromArom && toArom)) return;
        if (order == 2) sb += '=';
        else if (order == 3) sb += '#';
        else if (order == 1 && (fromArom != toArom)) sb += '-';
    }

    static void writeRingDigit(int rid, std::string& sb) {
        if (rid < 10) {
            sb += static_cast<char>('0' + rid);
        } else {
            sb += '%';
            sb += std::to_string(rid);
        }
    }

    // Ring closure info: {ringId, otherAtom}
    using RingClosureList = std::vector<std::vector<std::array<int,2>>>;

    void preScanDfs(int atom, int parent, std::vector<int>& color,
                     RingClosureList& rc,
                     std::unordered_set<int64_t>& ringEdges,
                     int& nextRing) const {
        color[atom] = 1;
        auto sorted = sortedNeighborsByCanonical(atom);
        int skippedParent = 0;
        for (int nb : sorted) {
            if (nb == parent && skippedParent == 0) {
                skippedParent = 1; continue;
            }
            if (color[nb] == 0) {
                preScanDfs(nb, atom, color, rc, ringEdges, nextRing);
            } else if (color[nb] == 1) {
                int rid = nextRing++;
                rc[nb].push_back({rid, atom});
                rc[atom].push_back({rid, nb});
                ringEdges.insert(bondKey(atom, nb));
            }
        }
        color[atom] = 2;
    }

    void emitSmiles(int atom, int /*parent*/, std::vector<bool>& visited,
                     std::string& sb, const RingClosureList& rc,
                     const std::unordered_set<int64_t>& ringEdges) const {
        visited[atom] = true;
        writeAtom(atom, sb);
        for (const auto& entry : rc[atom]) {
            if (!visited[entry[1]]) writeBondSymbol(atom, entry[1], sb);
            writeRingDigit(entry[0], sb);
        }
        auto sorted = sortedNeighborsByCanonical(atom);
        int childCount = 0;
        for (int nb : sorted) {
            if (!visited[nb]
                && ringEdges.find(bondKey(atom, nb)) == ringEdges.end())
                childCount++;
        }
        int childIdx = 0;
        for (int nb : sorted) {
            if (visited[nb]
                || ringEdges.find(bondKey(atom, nb)) != ringEdges.end())
                continue;
            childIdx++;
            bool needParen = childCount > 1 && childIdx < childCount;
            if (needParen) sb += '(';
            writeBondSymbol(atom, nb, sb);
            emitSmiles(nb, atom, visited, sb, rc, ringEdges);
            if (needParen) sb += ')';
        }
    }

    std::string toCanonicalSmiles() const {
        if (n == 0) return "";
        std::vector<int> inv(n);
        for (int i = 0; i < n; i++) inv[canonicalLabel[i]] = i;

        std::vector<int> color(n, 0);
        RingClosureList rc(n);
        std::unordered_set<int64_t> ringEdges;
        int nextRing = 1;

        for (int ci = 0; ci < n; ci++) {
            int start = inv[ci];
            if (color[start] == 0)
                preScanDfs(start, -1, color, rc, ringEdges, nextRing);
        }

        std::vector<bool> visited(n, false);
        std::string sb;
        for (int ci = 0; ci < n; ci++) {
            int start = inv[ci];
            if (visited[start]) continue;
            if (!sb.empty()) sb += '.';
            emitSmiles(start, -1, visited, sb, rc, ringEdges);
        }
        return sb;
    }

    // ========================================================================
    // NLF (Neighbor Label Frequency) helpers
    // ========================================================================

    static std::vector<int> freqMapToSortedArray(
            const std::unordered_map<int,int>& freq) {
        if (freq.empty()) return {};
        std::vector<std::pair<int,int>> pairs(freq.begin(), freq.end());
        std::sort(pairs.begin(), pairs.end());
        std::vector<int> arr(pairs.size() * 2);
        for (size_t i = 0; i < pairs.size(); i++) {
            arr[i * 2]     = pairs[i].first;
            arr[i * 2 + 1] = pairs[i].second;
        }
        return arr;
    }

    // NLF labels use atomicNum + aromaticity but NOT ring membership.
    // ring membership is a one-directional constraint (ring-query must match
    // ring-target, but non-ring-query CAN match ring-target), so including
    // the ring bit in NLF labels would over-prune valid substructure matches.
    static int nlfLabel(const MolGraph& g, int idx) {
        return (g.atomicNum[idx] << 1) | (g.aromatic[idx] ? 1 : 0);
    }

    static std::vector<int> buildNLF1(const MolGraph& g, int idx) {
        std::unordered_map<int,int> freq;
        for (int nb : g.neighbors[idx]) freq[nlfLabel(g, nb)]++;
        return freqMapToSortedArray(freq);
    }

    static std::vector<int> buildNLF2(const MolGraph& g, int idx) {
        std::unordered_map<int,int> freq;
        std::vector<bool> direct(g.n, false);
        for (int nb : g.neighbors[idx]) direct[nb] = true;
        std::vector<bool> seen(g.n, false);
        for (int nb : g.neighbors[idx]) {
            for (int j : g.neighbors[nb]) {
                if (j == idx || direct[j] || seen[j]) continue;
                seen[j] = true;
                freq[nlfLabel(g, j)]++;
            }
        }
        return freqMapToSortedArray(freq);
    }

    static std::vector<int> buildNLF3(const MolGraph& g, int idx) {
        std::unordered_map<int,int> freq;
        std::vector<bool> level1(g.n, false);
        for (int nb : g.neighbors[idx]) level1[nb] = true;

        std::vector<bool> level2(g.n, false);
        for (int i = 0; i < g.n; i++) {
            if (!level1[i]) continue;
            for (int j : g.neighbors[i])
                if (j != idx && !level1[j]) level2[j] = true;
        }
        std::vector<bool> level3(g.n, false);
        for (int i = 0; i < g.n; i++) {
            if (!level2[i]) continue;
            for (int j : g.neighbors[i])
                if (j != idx && !level1[j] && !level2[j]) level3[j] = true;
        }
        for (int j = 0; j < g.n; j++)
            if (level3[j]) freq[nlfLabel(g, j)]++;
        return freqMapToSortedArray(freq);
    }

    using NLFBuilder = std::vector<int>(*)(const MolGraph&, int);

    static std::vector<std::vector<int>> buildAllNLF(
            const MolGraph& g, NLFBuilder builder) {
        std::vector<std::vector<int>> nlf(g.n);
        for (int i = 0; i < g.n; i++) nlf[i] = builder(g, i);
        return nlf;
    }

    const std::vector<std::vector<int>>& getNLF1() const {
        if (cachedNLF1.empty() && n > 0)
            cachedNLF1 = buildAllNLF(*this, buildNLF1);
        return cachedNLF1;
    }

    const std::vector<std::vector<int>>& getNLF2() const {
        if (cachedNLF2.empty() && n > 0)
            cachedNLF2 = buildAllNLF(*this, buildNLF2);
        return cachedNLF2;
    }

    const std::vector<std::vector<int>>& getNLF3() const {
        if (cachedNLF3.empty() && n > 0)
            cachedNLF3 = buildAllNLF(*this, buildNLF3);
        return cachedNLF3;
    }

    static bool nlfOk(const std::vector<int>& fq, const std::vector<int>& ft) {
        size_t fi = 0, ti = 0;
        while (fi < fq.size()) {
            int fLabel = fq[fi], fFreq = fq[fi + 1];
            while (ti < ft.size() && ft[ti] < fLabel) ti += 2;
            if (ti >= ft.size() || ft[ti] != fLabel || ft[ti + 1] < fFreq)
                return false;
            fi += 2;
        }
        return true;
    }

    static bool nlfCheckOk(
            int qi, int tj,
            const std::vector<std::vector<int>>& qNLF1,
            const std::vector<std::vector<int>>& tNLF1,
            const std::vector<std::vector<int>>& qNLF2,
            const std::vector<std::vector<int>>& tNLF2,
            const std::vector<std::vector<int>>& qNLF3,
            const std::vector<std::vector<int>>& tNLF3,
            bool useTwoHop, bool useThreeHop) {
        if (!nlfOk(qNLF1[qi], tNLF1[tj])) return false;
        if (useTwoHop && !nlfOk(qNLF2[qi], tNLF2[tj])) return false;
        return !useThreeHop || nlfOk(qNLF3[qi], tNLF3[tj]);
    }

    // ========================================================================
    // initDerivedFields -- called after construction to compute all
    // derived data (adjLong, morgan, canonical label, orbits, tautomers, etc.)
    // ========================================================================

    void initDerivedFields() {
        words = (n + 63) >> 6;
        adjLong.assign(n, std::vector<uint64_t>(words, 0));
        for (int i = 0; i < n; i++) {
            for (int k : neighbors[i])
                adjLong[i][k >> 6] |= uint64_t(1) << (k & 63);
        }
        computeTautomerClasses();
        applySolventCorrection(solvent_);
        // Canonical labeling and ring counts are deferred; call
        // ensureCanonical() / ensureRingCounts() before accessing those fields.
    }

    /** Lazily compute Morgan ranks, canonical labeling, orbit, and canonical hash. */
    void ensureCanonical() const {
        if (canonicalComputed_) return;
        morganRank = computeMorganRanks(n, label, neighbors);
        auto clResult = computeCanonicalLabeling(n, label, degree, neighbors);
        canonicalLabel = std::move(clResult.canonLabel);
        orbit = std::move(clResult.orbit);
        canonicalHash = computeCanonicalHash(n, canonicalLabel, neighbors, label);
        canonicalComputed_ = true;
    }

    /** Lazily compute per-atom ring counts. */
    void ensureRingCounts() const {
        if (ringCountsComputed_) return;
        computeRingCounts();
        ringCountsComputed_ = true;
    }

    // ========================================================================
    // Builder -- CDK-free molecule construction via fluent API
    // ========================================================================

    class Builder {
    public:
        int n_ = 0;
        std::vector<int>  atomicNum_;
        std::vector<int>  formalCharge_;
        std::vector<int>  massNumber_;
        std::vector<bool> ring_;
        std::vector<bool> aromatic_;
        std::vector<std::vector<int>>  neighbors_;
        std::vector<std::vector<int>>  bondOrders_;
        std::vector<std::vector<bool>> bondRings_;
        std::vector<std::vector<bool>> bondAroms_;
        std::vector<int>               tetraChirality_;
        std::vector<std::vector<int>>  dbStereoConf_;
        ChemOptions::Solvent           solvent_ = ChemOptions::Solvent::AQUEOUS;

        Builder& atomCount(int n)                                         { n_ = n; return *this; }
        Builder& atomicNumbers(std::vector<int> v)                        { atomicNum_ = std::move(v); return *this; }
        Builder& formalCharges(std::vector<int> v)                        { formalCharge_ = std::move(v); return *this; }
        Builder& massNumbers(std::vector<int> v)                          { massNumber_ = std::move(v); return *this; }
        Builder& ringFlags(std::vector<bool> v)                           { ring_ = std::move(v); return *this; }
        Builder& aromaticFlags(std::vector<bool> v)                       { aromatic_ = std::move(v); return *this; }
        Builder& setNeighbors(std::vector<std::vector<int>> v)            { neighbors_ = std::move(v); return *this; }
        Builder& setBondOrders(std::vector<std::vector<int>> v)           { bondOrders_ = std::move(v); return *this; }
        Builder& bondRingFlags(std::vector<std::vector<bool>> v)          { bondRings_ = std::move(v); return *this; }
        Builder& bondAromaticFlags(std::vector<std::vector<bool>> v)      { bondAroms_ = std::move(v); return *this; }
        Builder& tetrahedralChirality(std::vector<int> v)                 { tetraChirality_ = std::move(v); return *this; }
        Builder& doubleBondStereo(std::vector<std::vector<int>> v)        { dbStereoConf_ = std::move(v); return *this; }
        Builder& solvent(ChemOptions::Solvent s)                            { solvent_ = s; return *this; }

        MolGraph build() const {
            assert(static_cast<int>(atomicNum_.size()) == n_
                   && "atomicNumbers must have length == atomCount");
            assert(static_cast<int>(neighbors_.size()) == n_
                   && "neighbors must have length == atomCount");

            MolGraph g;
            g.n = n_;
            g.words = (n_ + 63) >> 6;

            // Copy atom arrays
            g.atomicNum    = atomicNum_;
            g.formalCharge = formalCharge_.empty()
                             ? std::vector<int>(n_, 0) : formalCharge_;
            g.massNumber   = massNumber_.empty()
                             ? std::vector<int>(n_, 0) : massNumber_;

            if (ring_.empty())     g.ring.assign(n_, false);     else g.ring = ring_;
            if (aromatic_.empty()) g.aromatic.assign(n_, false); else g.aromatic = aromatic_;

            // Compute label = (atomicNum << 2) | (aromatic ? 2 : 0) | (ring ? 1 : 0)
            g.label.resize(n_);
            for (int i = 0; i < n_; i++) {
                g.label[i] = (g.atomicNum[i] << 2)
                            | (g.aromatic[i] ? 2 : 0)
                            | (g.ring[i] ? 1 : 0);
            }

            // Neighbors + degree
            g.neighbors = neighbors_;
            g.degree.resize(n_);
            for (int i = 0; i < n_; i++)
                g.degree[i] = static_cast<int>(g.neighbors[i].size());

            // Bond storage -- dense or sparse
            if (n_ <= SPARSE_THRESHOLD) {
                g.useDense = true;
                g.bondOrdMatrix.assign(n_, std::vector<int>(n_, 0));
                g.bondRingMatrix.assign(n_, std::vector<bool>(n_, false));
                g.bondAromMatrix.assign(n_, std::vector<bool>(n_, false));
                for (int i = 0; i < n_; i++) {
                    const auto& nbs = g.neighbors[i];
                    for (int k = 0; k < static_cast<int>(nbs.size()); k++) {
                        int j = nbs[k];
                        int ord = (!bondOrders_.empty()
                                   && i < static_cast<int>(bondOrders_.size())
                                   && k < static_cast<int>(bondOrders_[i].size()))
                                  ? bondOrders_[i][k] : 1;
                        bool inRing = (!bondRings_.empty()
                                       && i < static_cast<int>(bondRings_.size())
                                       && k < static_cast<int>(bondRings_[i].size()))
                                      ? bondRings_[i][k] : false;
                        bool arom = (!bondAroms_.empty()
                                     && i < static_cast<int>(bondAroms_.size())
                                     && k < static_cast<int>(bondAroms_[i].size()))
                                    ? bondAroms_[i][k] : false;
                        g.bondOrdMatrix[i][j]  = ord;
                        g.bondRingMatrix[i][j] = inRing;
                        g.bondAromMatrix[i][j] = arom;
                    }
                }
            } else {
                g.useDense = false;
                for (int i = 0; i < n_; i++) {
                    const auto& nbs = g.neighbors[i];
                    for (int k = 0; k < static_cast<int>(nbs.size()); k++) {
                        int j = nbs[k];
                        if (i >= j) continue;   // store each edge once
                        int ord = (!bondOrders_.empty()
                                   && i < static_cast<int>(bondOrders_.size())
                                   && k < static_cast<int>(bondOrders_[i].size()))
                                  ? bondOrders_[i][k] : 1;
                        int inRing = (!bondRings_.empty()
                                      && i < static_cast<int>(bondRings_.size())
                                      && k < static_cast<int>(bondRings_[i].size())
                                      && bondRings_[i][k]) ? 1 : 0;
                        int arom = (!bondAroms_.empty()
                                    && i < static_cast<int>(bondAroms_.size())
                                    && k < static_cast<int>(bondAroms_[i].size())
                                    && bondAroms_[i][k]) ? 1 : 0;
                        g.sparseBondProps[bondKey(i, j)] = {ord, inRing, arom};
                    }
                }
            }

            // Stereochemistry
            g.tetraChirality = tetraChirality_.empty()
                               ? std::vector<int>(n_, 0) : tetraChirality_;
            if (n_ <= SPARSE_THRESHOLD) {
                g.hasDbStereo = true;
                g.dbStereoConf.assign(n_, std::vector<int>(n_, 0));
                if (!dbStereoConf_.empty()) {
                    for (int i = 0; i < n_
                         && i < static_cast<int>(dbStereoConf_.size()); i++) {
                        for (int j = 0; j < n_
                             && j < static_cast<int>(dbStereoConf_[i].size()); j++) {
                            g.dbStereoConf[i][j] = dbStereoConf_[i][j];
                        }
                    }
                }
            }

            g.ringCount.assign(n_, 0);
            g.solvent_ = solvent_;
            g.initDerivedFields();
            return g;
        }
    };
};

// ============================================================================
// ChemOps -- atom and bond compatibility checks (static utility)
// ============================================================================

struct ChemOps {

    /// Atom compatibility check for substructure / MCS matching.
    static bool atomsCompatible(
            const MolGraph& gq, int qi,
            const MolGraph& gt, int tj,
            const ChemOptions& C) {
        // Tautomer-aware: relaxed matching for C/N/O/S in tautomeric positions
        if (C.tautomerAware
            && !gq.tautomerClass.empty() && !gt.tautomerClass.empty()
            && gq.tautomerClass[qi] != -1 && gt.tautomerClass[tj] != -1) {
            int aq = gq.atomicNum[qi], at = gt.atomicNum[tj];
            auto isTautElem = [](int z) { return z==6||z==7||z==8||z==16; };
            if (isTautElem(aq) && isTautElem(at)) {
                if (C.ringMatchesRingOnly && gq.ring[qi] && !gt.ring[tj])
                    return false;
                return true;
            }
        }
        if (C.matchAtomType && gq.atomicNum[qi] != gt.atomicNum[tj])
            return false;
        if (C.matchFormalCharge && gq.formalCharge[qi] != gt.formalCharge[tj])
            return false;
        if (C.aromaticityMode == ChemOptions::AromaticityMode::STRICT
            && gq.aromatic[qi] != gt.aromatic[tj])
            return false;
        if (C.ringMatchesRingOnly && gq.ring[qi] && !gt.ring[tj])
            return false;
        if (C.matchIsotope) {
            int qm = gq.massNumber[qi], tm = gt.massNumber[tj];
            if (qm != 0 && tm != 0 && qm != tm) return false;
        }
        if (C.useChirality) {
            int qs = gq.tetraChirality[qi], ts = gt.tetraChirality[tj];
            if (qs != 0 && ts != 0 && qs != ts) return false;
        }
        if (C.ringFusionMode == ChemOptions::RingFusionMode::STRICT
            && gq.ring[qi] && gt.ring[tj]) {
            if (gq.ringCount[qi] != gt.ringCount[tj]) return false;
        }
        return true;
    }

    /// Bond compatibility check for substructure / MCS matching.
    static bool bondsCompatible(
            const MolGraph& g1, int qi, int qk,
            const MolGraph& g2, int tj, int tk,
            const ChemOptions& C) {
        int qOrd = g1.bondOrder(qi, qk), tOrd = g2.bondOrder(tj, tk);
        if (qOrd == 0 || tOrd == 0) return false;

        // Tautomer-aware: both endpoints tautomeric => any order matches
        if (C.tautomerAware
            && !g1.tautomerClass.empty() && !g2.tautomerClass.empty()) {
            bool qBothTaut = g1.tautomerClass[qi] != -1
                          && g1.tautomerClass[qk] != -1;
            bool tBothTaut = g2.tautomerClass[tj] != -1
                          && g2.tautomerClass[tk] != -1;
            if (qBothTaut && tBothTaut) return true;
        }

        // Strict aromaticity: check bond aromaticity directly (no ring guard)
        if (C.aromaticityMode == ChemOptions::AromaticityMode::STRICT
            && g1.bondAromatic(qi, qk) != g2.bondAromatic(tj, tk))
            return false;

        if (C.useBondStereo) {
            int qConf = g1.dbStereo(qi, qk), tConf = g2.dbStereo(tj, tk);
            if (qConf != 0 && tConf != 0 && qConf != tConf) return false;
        }

        if (C.ringMatchesRingOnly
            && g1.bondInRing(qi, qk) && !g2.bondInRing(tj, tk))
            return false;

        if (C.matchBondOrder == ChemOptions::BondOrderMode::ANY)
            return true;
        if (qOrd == tOrd) return true;
        if (C.matchBondOrder == ChemOptions::BondOrderMode::LOOSE)
            return true;

        if (C.aromaticityMode == ChemOptions::AromaticityMode::FLEXIBLE) {
            bool qa = g1.bondAromatic(qi, qk), ta = g2.bondAromatic(tj, tk);
            if ((qa && ta)
                || (qa && (tOrd == 1 || tOrd == 2))
                || (ta && (qOrd == 1 || qOrd == 2)))
                return true;
        }
        return false;
    }
};

// ===========================================================================
// computeTautomerConfidence -- post-MCS tautomer match quality score ∈ (0,1].
//
// For each atom pair (qi→ti) in the MCS that is a cross-element tautomeric
// match (atomicNum differs but both atoms are in a tautomeric class), the
// confidence is multiplied by min(w_query, w_target).  Non-tautomeric pairs
// contribute 1.0 (no penalty).  Returns 1.0 for an empty mapping or when
// neither graph has tautomeric atoms.
// ===========================================================================

inline double computeTautomerConfidence(
        const MolGraph& gq,
        const MolGraph& gt,
        const std::unordered_map<int,int>& mcs) {
    if (mcs.empty()) return 1.0;
    double conf = 1.0;
    for (const auto& kv : mcs) {
        int qi = kv.first, ti = kv.second;
        if (!gq.tautomerClass.empty() && !gt.tautomerClass.empty()
            && gq.tautomerClass[qi] >= 0 && gt.tautomerClass[ti] >= 0
            && gq.atomicNum[qi] != gt.atomicNum[ti]) {
            float wq = gq.tautomerWeight.empty() ? 1.0f : gq.tautomerWeight[qi];
            float wt = gt.tautomerWeight.empty() ? 1.0f : gt.tautomerWeight[ti];
            conf *= static_cast<double>(std::min(wq, wt));
        }
    }
    return conf;
}

// ===========================================================================
// extractSubgraph -- extract a subgraph containing only the specified atom indices.
// Port of Java SearchEngine.extractSubgraph()
// ===========================================================================

inline MolGraph extractSubgraph(const MolGraph& mol, const std::vector<int>& atomIndices) {
    int subN = static_cast<int>(atomIndices.size());
    if (subN == 0) return MolGraph();

    // Build old-to-new index mapping
    std::unordered_map<int, int> oldToNew;
    oldToNew.reserve(subN);
    for (int k = 0; k < subN; ++k)
        oldToNew[atomIndices[k]] = k;

    std::vector<int> atomicNum(subN), formalCharge(subN, 0), massNumber(subN, 0);
    std::vector<bool> ring(subN, false), aromatic(subN, false);
    std::vector<std::vector<int>> neighbors(subN);
    std::vector<std::vector<int>> bondOrders(subN);
    std::vector<std::vector<bool>> bondRings(subN);
    std::vector<std::vector<bool>> bondAroms(subN);

    for (int k = 0; k < subN; ++k) {
        int oldIdx = atomIndices[k];
        atomicNum[k]    = mol.atomicNum[oldIdx];
        formalCharge[k]  = mol.formalCharge[oldIdx];
        massNumber[k]    = mol.massNumber[oldIdx];
        ring[k]          = mol.ring[oldIdx];
        aromatic[k]      = mol.aromatic[oldIdx];
    }

    // Copy bonds where both endpoints are in the subgraph
    for (int k = 0; k < subN; ++k) {
        int oldI = atomIndices[k];
        for (int oldJ : mol.neighbors[oldI]) {
            auto it = oldToNew.find(oldJ);
            if (it == oldToNew.end()) continue;
            int newJ = it->second;
            neighbors[k].push_back(newJ);
            bondOrders[k].push_back(mol.bondOrder(oldI, oldJ));
            bondRings[k].push_back(mol.bondInRing(oldI, oldJ));
            bondAroms[k].push_back(mol.bondAromatic(oldI, oldJ));
        }
    }

    return MolGraph::Builder()
        .atomCount(subN)
        .atomicNumbers(std::move(atomicNum))
        .formalCharges(std::move(formalCharge))
        .massNumbers(std::move(massNumber))
        .ringFlags(std::move(ring))
        .aromaticFlags(std::move(aromatic))
        .setNeighbors(std::move(neighbors))
        .setBondOrders(std::move(bondOrders))
        .bondRingFlags(std::move(bondRings))
        .bondAromaticFlags(std::move(bondAroms))
        .build();
}

// ===========================================================================
// murckoScaffold -- extract Murcko scaffold (ring systems + linkers).
// Port of Java SearchEngine.murckoScaffold()
// Strips all atoms not in rings and not on shortest paths between rings.
// ===========================================================================

inline MolGraph murckoScaffold(const MolGraph& mol) {
    if (mol.n == 0) return mol;

    // Identify ring atoms
    bool hasRing = false;
    for (int i = 0; i < mol.n; ++i) {
        if (mol.ring[i]) { hasRing = true; break; }
    }
    if (!hasRing) return mol;

    // Mark atoms to keep: all ring atoms + atoms on shortest paths between ring atoms
    std::vector<bool> keep(mol.n, false);
    std::vector<int> ringAtoms;
    for (int i = 0; i < mol.n; ++i) {
        if (mol.ring[i]) {
            keep[i] = true;
            ringAtoms.push_back(i);
        }
    }

    // BFS from each ring atom to find shortest paths to other ring atoms
    // through non-ring atoms (linkers)
    for (int src : ringAtoms) {
        std::vector<int> prev(mol.n, -1);
        std::vector<bool> seen(mol.n, false);
        std::deque<int> queue;
        queue.push_back(src);
        seen[src] = true;

        while (!queue.empty()) {
            int u = queue.front(); queue.pop_front();
            for (int v : mol.neighbors[u]) {
                if (seen[v]) continue;
                seen[v] = true;
                prev[v] = u;
                if (mol.ring[v] && v != src) {
                    // Trace back the path and mark all atoms on it
                    int cur = v;
                    while (cur != src && cur != -1) {
                        keep[cur] = true;
                        cur = prev[cur];
                    }
                }
                // Only continue BFS through non-ring atoms (looking for linkers)
                if (!mol.ring[v]) queue.push_back(v);
            }
        }
    }

    // Collect kept atom indices
    std::vector<int> keptIndices;
    for (int i = 0; i < mol.n; ++i) {
        if (keep[i]) keptIndices.push_back(i);
    }

    if (static_cast<int>(keptIndices.size()) == mol.n) return mol;

    return extractSubgraph(mol, keptIndices);
}

} // namespace smsd

#endif // SMSD_MOL_GRAPH_HPP
