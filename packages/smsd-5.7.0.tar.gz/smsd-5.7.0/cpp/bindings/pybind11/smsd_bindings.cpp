/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2018-2026 BioInception PVT LTD
 * Algorithm Copyright (c) 2009-2026 Syed Asad Rahman
 *
 * Python bindings for SMSD via pybind11.
 * Usage: import smsd; result = smsd.find_mcs(mol1, mol2)
 */

#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <pybind11/stl_bind.h>
#include "smsd/smsd.hpp"
#include "smsd/rascal.hpp"
#include "smsd/smiles_parser.hpp"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <map>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#if defined(_MSC_VER)
#include <intrin.h>
#endif

// Portable bit intrinsics (Ubuntu / macOS / Windows — no infinite recursion)
inline int smsd_popcount64(uint64_t x) {
#if defined(_MSC_VER)
    return static_cast<int>(__popcnt64(x));
#elif defined(__GNUC__) || defined(__clang__)
    return __builtin_popcountll(x);   // was: smsd_popcount64(x) — infinite recursion fix
#else
    x = x - ((x >> 1) & 0x5555555555555555ULL);
    x = (x & 0x3333333333333333ULL) + ((x >> 2) & 0x3333333333333333ULL);
    return static_cast<int>(((x + (x >> 4)) & 0x0F0F0F0F0F0F0F0FULL) * 0x0101010101010101ULL >> 56);
#endif
}

inline int smsd_ctz64(uint64_t x) {
#if defined(_MSC_VER)
    unsigned long index;
    if (_BitScanForward64(&index, x)) return static_cast<int>(index);
    return 64;
#elif defined(__GNUC__) || defined(__clang__)
    return __builtin_ctzll(x);
#else
    if (x == 0) return 64;
    int c = 0;
    if (!(x & 0xFFFFFFFFULL)) { c += 32; x >>= 32; }
    if (!(x & 0xFFFFULL)) { c += 16; x >>= 16; }
    if (!(x & 0xFFULL)) { c += 8; x >>= 8; }
    if (!(x & 0xFULL)) { c += 4; x >>= 4; }
    if (!(x & 0x3ULL)) { c += 2; x >>= 2; }
    if (!(x & 0x1ULL)) c += 1;
    return c;
#endif
}

namespace py = pybind11;

// ============================================================================
// Fingerprint implementation (ported from Java SearchEngine)
// ============================================================================

namespace {

// Hash a path of atomic numbers (path fingerprint, simpler variant).
// Computes forward and reverse hashes and takes the minimum for
// canonical (direction-independent) ordering.
int fpHashPath(const int* atomicNum, const int* path, int len) {
    int fwd = 17, rev = 17;
    for (int i = 0; i < len; ++i) {
        fwd = fwd * 31 + atomicNum[path[i]];
        rev = rev * 31 + atomicNum[path[len - 1 - i]];
    }
    return std::min(fwd & 0x7FFFFFFF, rev & 0x7FFFFFFF);
}

void fpSetBit(std::vector<uint64_t>& fp, int hash, int fpSize) {
    int bit = hash % fpSize;
    fp[bit >> 6] |= uint64_t(1) << (bit & 63);
}

void fpEnumeratePaths(const std::vector<std::vector<int>>& adj,
                      const std::vector<int>& atomicNum,
                      std::vector<uint64_t>& fp, int fpSize,
                      std::vector<bool>& visited, int* path,
                      int depth, int maxDepth) {
    int cur = path[depth - 1];
    for (int nb : adj[cur]) {
        if (visited[nb]) continue;
        path[depth] = nb;
        visited[nb] = true;
        fpSetBit(fp, fpHashPath(atomicNum.data(), path, depth + 1), fpSize);
        if (depth < maxDepth)
            fpEnumeratePaths(adj, atomicNum, fp, fpSize, visited, path,
                             depth + 1, maxDepth);
        visited[nb] = false;
    }
}

// MCS-aware atom hash: encodes element, ring, aromatic, tautomer class, degree.
int mcsAtomHash(const smsd::MolGraph& g, bool tautAware, int atom) {
    int h = 17;
    int label = g.atomicNum[atom];
    bool hasTautClass = !g.tautomerClass.empty() && g.tautomerClass[atom] >= 0;
    if (tautAware && hasTautClass) label = 999; // tautomer-invariant label
    h = h * 37 + label;
    h = h * 37 + (g.ring[atom] ? 1 : 0);
    h = h * 37 + (g.aromatic[atom] ? 1 : 0);
    int tc = (!g.tautomerClass.empty()) ? g.tautomerClass[atom] : -1;
    h = h * 37 + (tautAware ? 0 : tc);
    h = h * 37 + g.degree[atom];
    return h;
}

int mcsBondHash(const smsd::MolGraph& g, int from, int to) {
    int h = 17;
    h = h * 37 + g.bondOrder(from, to);
    h = h * 37 + (g.bondInRing(from, to) ? 1 : 0);
    h = h * 37 + (g.bondAromatic(from, to) ? 1 : 0);
    return h;
}

int mcsFpHashPath(const smsd::MolGraph& g, bool tautAware,
                  const int* path, int len) {
    int fwd = 17, rev = 17;
    for (int i = 0; i < len; ++i) {
        int fi = i, ri = len - 1 - i;
        int ahF = mcsAtomHash(g, tautAware, path[fi]);
        int ahR = mcsAtomHash(g, tautAware, path[ri]);
        fwd = fwd * 31 + ahF;
        rev = rev * 31 + ahR;
        if (i < len - 1) {
            int bondF = mcsBondHash(g, path[fi], path[fi + 1]);
            int bondR = mcsBondHash(g, path[ri], path[ri - 1]);
            fwd = fwd * 31 + bondF;
            rev = rev * 31 + bondR;
        }
    }
    return std::min(fwd & 0x7FFFFFFF, rev & 0x7FFFFFFF);
}

void mcsFpEnumeratePaths(const smsd::MolGraph& g, bool tautAware,
                         const std::vector<bool>& isHeavy,
                         std::vector<uint64_t>& fp, int fpSize,
                         std::vector<bool>& visited, int* path,
                         int depth, int maxDepth) {
    int cur = path[depth - 1];
    for (int nb : g.neighbors[cur]) {
        if (visited[nb] || !isHeavy[nb]) continue;
        path[depth] = nb;
        visited[nb] = true;
        fpSetBit(fp, mcsFpHashPath(g, tautAware, path, depth + 1), fpSize);
        if (depth < maxDepth)
            mcsFpEnumeratePaths(g, tautAware, isHeavy, fp, fpSize, visited,
                                path, depth + 1, maxDepth);
        visited[nb] = false;
    }
}

int popcount64(uint64_t x) {
#if defined(__GNUC__) || defined(__clang__)
    return smsd_popcount64(x);
#else
    x = x - ((x >> 1) & 0x5555555555555555ULL);
    x = (x & 0x3333333333333333ULL) + ((x >> 2) & 0x3333333333333333ULL);
    return (int)(((x + (x >> 4)) & 0x0F0F0F0F0F0F0F0FULL) * 0x0101010101010101ULL >> 56);
#endif
}

} // anonymous namespace

// ============================================================================
// Public fingerprint functions
// ============================================================================

// Path fingerprint: enumerates all simple paths up to pathLength bonds,
// hashes each path by atomic number sequence. Returns bit positions that
// are set.
static std::vector<int> pathFingerprint(const smsd::MolGraph& mol,
                                         int pathLength = 7,
                                         int fpSize = 2048) {
    int words = (fpSize + 63) / 64;
    std::vector<uint64_t> fp(words, 0);
    int n = mol.n;
    if (n == 0) return {};

    // Build heavy-atom adjacency (skip explicit H)
    std::vector<int> heavyMap(n, -1);
    int heavyCount = 0;
    for (int i = 0; i < n; ++i) {
        if (mol.atomicNum[i] != 1) { heavyMap[i] = heavyCount++; }
    }
    if (heavyCount == 0) return {};

    std::vector<int> heavyAtomicNum(heavyCount);
    std::vector<std::vector<int>> heavyAdj(heavyCount);
    for (int i = 0; i < n; ++i) {
        if (heavyMap[i] < 0) continue;
        int hi = heavyMap[i];
        heavyAtomicNum[hi] = mol.atomicNum[i];
        for (int nb : mol.neighbors[i]) {
            if (heavyMap[nb] >= 0) heavyAdj[hi].push_back(heavyMap[nb]);
        }
    }

    std::vector<int> pathBuf(pathLength + 1);
    std::vector<bool> visited(heavyCount, false);
    for (int start = 0; start < heavyCount; ++start) {
        pathBuf[0] = start;
        visited[start] = true;
        fpSetBit(fp, fpHashPath(heavyAtomicNum.data(), pathBuf.data(), 1), fpSize);
        fpEnumeratePaths(heavyAdj, heavyAtomicNum, fp, fpSize, visited,
                         pathBuf.data(), 1, pathLength);
        visited[start] = false;
    }

    // Collect set bit positions
    std::vector<int> bits;
    for (int w = 0; w < words; ++w) {
        uint64_t word = fp[w];
        while (word) {
            int bit = w * 64 + smsd_ctz64(word);
            if (bit < fpSize) bits.push_back(bit);
            word &= word - 1;
        }
    }
    return bits;
}

// MCS-aware fingerprint: encodes element, ring, aromatic, tautomer class,
// degree per atom; order, ring, aromatic per bond. Returns set bit positions.
static std::vector<int> mcsFingerprint(const smsd::MolGraph& mol,
                                        int pathLength = 7,
                                        int fpSize = 2048) {
    int words = (fpSize + 63) / 64;
    std::vector<uint64_t> fp(words, 0);
    int n = mol.n;
    if (n == 0) return {};

    std::vector<bool> isHeavy(n);
    int heavyCount = 0;
    for (int i = 0; i < n; ++i) {
        isHeavy[i] = (mol.atomicNum[i] != 1);
        if (isHeavy[i]) heavyCount++;
    }
    if (heavyCount == 0) return {};

    bool tautAware = !mol.tautomerClass.empty();
    std::vector<int> pathBuf(pathLength + 1);
    std::vector<bool> visited(n, false);
    for (int start = 0; start < n; ++start) {
        if (!isHeavy[start]) continue;
        pathBuf[0] = start;
        visited[start] = true;
        fpSetBit(fp, mcsFpHashPath(mol, tautAware, pathBuf.data(), 1), fpSize);
        mcsFpEnumeratePaths(mol, tautAware, isHeavy, fp, fpSize, visited,
                            pathBuf.data(), 1, pathLength);
        visited[start] = false;
    }

    std::vector<int> bits;
    for (int w = 0; w < words; ++w) {
        uint64_t word = fp[w];
        while (word) {
            int bit = w * 64 + smsd_ctz64(word);
            if (bit < fpSize) bits.push_back(bit);
            word &= word - 1;
        }
    }
    return bits;
}

// Check if fingerprint fp1 is a subset of fp2 (all bits in fp1 are set in fp2).
// Both are represented as sorted lists of set bit positions.
static bool fingerprintSubset(const std::vector<int>& fp1,
                               const std::vector<int>& fp2) {
    size_t j = 0;
    for (int bit : fp1) {
        while (j < fp2.size() && fp2[j] < bit) ++j;
        if (j >= fp2.size() || fp2[j] != bit) return false;
    }
    return true;
}

// Analyze fingerprint quality: density, number of set bits, expected
// collision rate.
static py::dict analyzeFpQuality(const std::vector<int>& fp, int fpSize = 2048) {
    int setBits = static_cast<int>(fp.size());
    double density = static_cast<double>(setBits) / fpSize;
    // Expected collision probability for random hashing
    double expectedCollisions = 1.0 - std::exp(-static_cast<double>(setBits) / fpSize);
    py::dict result;
    result["set_bits"] = setBits;
    result["fp_size"] = fpSize;
    result["density"] = density;
    result["expected_collision_rate"] = expectedCollisions;
    result["is_saturated"] = density > 0.75;
    return result;
}

// ============================================================================
// Module definition
// ============================================================================

PYBIND11_MODULE(_smsd, m) {
    m.doc() = "SMSD -- Substructure & MCS search for chemical graphs";

    // -----------------------------------------------------------------------
    // Enums
    // -----------------------------------------------------------------------
    py::enum_<smsd::ChemOptions::BondOrderMode>(m, "BondOrderMode")
        .value("STRICT", smsd::ChemOptions::BondOrderMode::STRICT)
        .value("LOOSE",  smsd::ChemOptions::BondOrderMode::LOOSE)
        .value("ANY",    smsd::ChemOptions::BondOrderMode::ANY)
        .export_values();

    py::enum_<smsd::ChemOptions::AromaticityMode>(m, "AromaticityMode")
        .value("STRICT",   smsd::ChemOptions::AromaticityMode::STRICT)
        .value("FLEXIBLE", smsd::ChemOptions::AromaticityMode::FLEXIBLE)
        .export_values();

    py::enum_<smsd::ChemOptions::RingFusionMode>(m, "RingFusionMode")
        .value("IGNORE",     smsd::ChemOptions::RingFusionMode::IGNORE)
        .value("PERMISSIVE", smsd::ChemOptions::RingFusionMode::PERMISSIVE)
        .value("STRICT",     smsd::ChemOptions::RingFusionMode::STRICT)
        .export_values();

    py::enum_<smsd::ChemOptions::Solvent>(m, "Solvent")
        .value("AQUEOUS",    smsd::ChemOptions::Solvent::AQUEOUS)
        .value("DMSO",       smsd::ChemOptions::Solvent::DMSO)
        .value("METHANOL",   smsd::ChemOptions::Solvent::METHANOL)
        .value("CHLOROFORM", smsd::ChemOptions::Solvent::CHLOROFORM)
        .export_values();

    // -----------------------------------------------------------------------
    // ChemOptions
    // -----------------------------------------------------------------------
    py::class_<smsd::ChemOptions>(m, "ChemOptions")
        .def(py::init<>())
        // Atom matching
        .def_readwrite("match_atom_type",       &smsd::ChemOptions::matchAtomType)
        .def_readwrite("match_formal_charge",   &smsd::ChemOptions::matchFormalCharge)
        .def_readwrite("match_isotope",         &smsd::ChemOptions::matchIsotope)
        .def_readwrite("use_chirality",         &smsd::ChemOptions::useChirality)
        .def_readwrite("use_bond_stereo",       &smsd::ChemOptions::useBondStereo)
        .def_readwrite("ring_matches_ring_only",&smsd::ChemOptions::ringMatchesRingOnly)
        // Ring completeness
        .def_readwrite("complete_rings_only",   &smsd::ChemOptions::completeRingsOnly)
        // Tautomer
        .def_readwrite("tautomer_aware",        &smsd::ChemOptions::tautomerAware)
        // Solvent
        .def_readwrite("solvent",               &smsd::ChemOptions::solvent)
        .def("with_solvent", &smsd::ChemOptions::withSolvent,
             py::arg("solvent"),
             "Set solvent for tautomer weight corrections (fluent)")
        // Bond matching
        .def_readwrite("match_bond_order",      &smsd::ChemOptions::matchBondOrder)
        .def_readwrite("aromaticity_mode",      &smsd::ChemOptions::aromaticityMode)
        // Ring fusion
        .def_readwrite("ring_fusion_mode",      &smsd::ChemOptions::ringFusionMode)
        // Named profiles
        .def_static("tautomer_profile", &smsd::ChemOptions::tautomerProfile,
                     "Create ChemOptions configured for tautomer-aware matching")
        .def_static("profile", &smsd::ChemOptions::profile,
                     py::arg("name") = "default",
                     "Create ChemOptions from named profile ('strict', 'default')")
        .def("__repr__", [](const smsd::ChemOptions& o) {
            return "<ChemOptions match_atom_type=" +
                   std::string(o.matchAtomType ? "True" : "False") +
                   " tautomer_aware=" +
                   std::string(o.tautomerAware ? "True" : "False") + ">";
        });

    // -----------------------------------------------------------------------
    // McsOptions
    // -----------------------------------------------------------------------
    py::class_<smsd::McsOptions>(m, "McsOptions")
        .def(py::init<>())
        .def_readwrite("induced",           &smsd::McsOptions::induced)
        .def_readwrite("connected_only",    &smsd::McsOptions::connectedOnly)
        .def_readwrite("disconnected_mcs",  &smsd::McsOptions::disconnectedMCS)
        .def_readwrite("maximize_bonds",    &smsd::McsOptions::maximizeBonds)
        .def_readwrite("min_fragment_size", &smsd::McsOptions::minFragmentSize)
        .def_readwrite("max_fragments",     &smsd::McsOptions::maxFragments)
        .def_readwrite("timeout_ms",        &smsd::McsOptions::timeoutMs)
        .def_readwrite("extra_seeds",       &smsd::McsOptions::extraSeeds)
        .def("__repr__", [](const smsd::McsOptions& o) {
            return "<McsOptions induced=" +
                   std::string(o.induced ? "True" : "False") +
                   " connected_only=" +
                   std::string(o.connectedOnly ? "True" : "False") +
                   " timeout_ms=" + std::to_string(o.timeoutMs) + ">";
        });

    // -----------------------------------------------------------------------
    // MolGraph
    // -----------------------------------------------------------------------
    py::class_<smsd::MolGraph>(m, "MolGraph")
        .def(py::init<>())
        .def_readonly("n",          &smsd::MolGraph::n)
        .def_readonly("atomic_num", &smsd::MolGraph::atomicNum)
        .def_readonly("degree",     &smsd::MolGraph::degree)
        .def_readonly("aromatic",   &smsd::MolGraph::aromatic)
        .def_readonly("ring",       &smsd::MolGraph::ring)
        .def_readonly("formal_charge", &smsd::MolGraph::formalCharge)
        .def_readonly("mass_number",   &smsd::MolGraph::massNumber)
        .def_readonly("label",         &smsd::MolGraph::label)
        .def_readonly("tautomer_class",&smsd::MolGraph::tautomerClass)
        .def_readonly("morgan_rank",   &smsd::MolGraph::morganRank)
        .def_readonly("canonical_label", &smsd::MolGraph::canonicalLabel)
        .def_readonly("orbit",         &smsd::MolGraph::orbit)
        .def("bond_order", &smsd::MolGraph::bondOrder,
             py::arg("i"), py::arg("j"),
             "Get bond order between atoms i and j (0 if no bond)")
        .def("bond_in_ring", &smsd::MolGraph::bondInRing,
             py::arg("i"), py::arg("j"))
        .def("bond_aromatic", &smsd::MolGraph::bondAromatic,
             py::arg("i"), py::arg("j"))
        .def("has_bond", &smsd::MolGraph::hasBond,
             py::arg("i"), py::arg("j"))
        .def("__repr__", [](const smsd::MolGraph& g) {
            return "<MolGraph n=" + std::to_string(g.n) + ">";
        })
        .def("__len__", [](const smsd::MolGraph& g) { return g.n; });

    // -----------------------------------------------------------------------
    // MolGraph.Builder
    // -----------------------------------------------------------------------
    py::class_<smsd::MolGraph::Builder>(m, "MolGraphBuilder")
        .def(py::init<>())
        .def("atom_count", [](smsd::MolGraph::Builder& b, int n) -> smsd::MolGraph::Builder& {
            return b.atomCount(n);
        }, py::arg("n"), py::return_value_policy::reference_internal,
             "Set the number of atoms")
        .def("atomic_numbers", [](smsd::MolGraph::Builder& b, std::vector<int> v) -> smsd::MolGraph::Builder& {
            return b.atomicNumbers(std::move(v));
        }, py::arg("nums"), py::return_value_policy::reference_internal,
             "Set atomic numbers for all atoms")
        .def("formal_charges", [](smsd::MolGraph::Builder& b, std::vector<int> v) -> smsd::MolGraph::Builder& {
            return b.formalCharges(std::move(v));
        }, py::arg("charges"), py::return_value_policy::reference_internal,
             "Set formal charges")
        .def("ring_flags", [](smsd::MolGraph::Builder& b, std::vector<bool> v) -> smsd::MolGraph::Builder& {
            return b.ringFlags(std::move(v));
        }, py::arg("flags"), py::return_value_policy::reference_internal,
             "Set ring membership flags")
        .def("aromatic_flags", [](smsd::MolGraph::Builder& b, std::vector<bool> v) -> smsd::MolGraph::Builder& {
            return b.aromaticFlags(std::move(v));
        }, py::arg("flags"), py::return_value_policy::reference_internal,
             "Set aromaticity flags")
        .def("neighbors", [](smsd::MolGraph::Builder& b, std::vector<std::vector<int>> v) -> smsd::MolGraph::Builder& {
            return b.setNeighbors(std::move(v));
        }, py::arg("adj"), py::return_value_policy::reference_internal,
             "Set adjacency lists")
        .def("bond_orders", [](smsd::MolGraph::Builder& b, std::vector<std::vector<int>> v) -> smsd::MolGraph::Builder& {
            return b.setBondOrders(std::move(v));
        }, py::arg("orders"), py::return_value_policy::reference_internal,
             "Set bond orders (parallel to neighbors)")
        .def("build", &smsd::MolGraph::Builder::build,
             "Build the immutable MolGraph");

    // -----------------------------------------------------------------------
    // ParseOptions (for lenient SMILES parsing)
    // -----------------------------------------------------------------------
    py::class_<smsd::ParseOptions>(m, "ParseOptions")
        .def(py::init<>())
        .def_readwrite("lenient", &smsd::ParseOptions::lenient,
                       "If true, recover from malformed SMILES instead of throwing");

    // -----------------------------------------------------------------------
    // SMILES parser / writer
    // -----------------------------------------------------------------------
    m.def("parse_smiles",
          static_cast<smsd::MolGraph (*)(const std::string&)>(&smsd::parseSMILES),
          py::arg("smiles"),
          "Parse a SMILES string into a MolGraph");
    m.def("parse_smiles_lenient",
          static_cast<smsd::MolGraph (*)(const std::string&, const smsd::ParseOptions&)>(&smsd::parseSMILES),
          py::arg("smiles"), py::arg("opts"),
          "Parse a SMILES string with options (e.g. lenient mode)");

    m.def("to_smiles", &smsd::toSMILES,
          py::arg("mol"),
          "Generate canonical SMILES from a MolGraph");

    // -----------------------------------------------------------------------
    // Substructure search
    // -----------------------------------------------------------------------
    m.def("is_substructure", &smsd::isSubstructure,
          py::arg("query"), py::arg("target"),
          py::arg("opts") = smsd::ChemOptions(),
          py::arg("timeout_ms") = 10000,
          "Check if query is a substructure of target");

    m.def("find_substructure", &smsd::findSubstructure,
          py::arg("query"), py::arg("target"),
          py::arg("opts") = smsd::ChemOptions(),
          py::arg("timeout_ms") = 10000,
          "Find one substructure mapping (query->target atom pairs)");

    // -----------------------------------------------------------------------
    // MCS search
    // -----------------------------------------------------------------------
    m.def("find_mcs", &smsd::findMCS,
          py::arg("g1"), py::arg("g2"),
          py::arg("chem") = smsd::ChemOptions(),
          py::arg("opts") = smsd::McsOptions(),
          "Find Maximum Common Substructure (returns dict of g1->g2 atom indices)");

    // -----------------------------------------------------------------------
    // RASCAL screening
    // -----------------------------------------------------------------------
    m.def("similarity_upper_bound", &smsd::similarityUpperBound,
          py::arg("g1"), py::arg("g2"),
          "RASCAL O(V+E) similarity upper bound");

    m.def("screen_targets", &smsd::screenTargets,
          py::arg("query"), py::arg("targets"), py::arg("threshold"),
          "Batch RASCAL screening: returns indices of targets above threshold");

    // -----------------------------------------------------------------------
    // Fingerprints
    // -----------------------------------------------------------------------
    m.def("path_fingerprint", &pathFingerprint,
          py::arg("mol"), py::arg("path_length") = 7, py::arg("fp_size") = 2048,
          "Compute path-based fingerprint. Returns list of set bit positions.");

    m.def("mcs_fingerprint", &mcsFingerprint,
          py::arg("mol"), py::arg("path_length") = 7, py::arg("fp_size") = 2048,
          "Compute MCS-aware path fingerprint. Returns list of set bit positions.");

    m.def("fingerprint_subset", &fingerprintSubset,
          py::arg("fp1"), py::arg("fp2"),
          "Check if fingerprint fp1 is a subset of fp2 (all bits in fp1 are set in fp2)");

    m.def("analyze_fp_quality", &analyzeFpQuality,
          py::arg("fp"), py::arg("fp_size") = 2048,
          "Analyze fingerprint quality: density, set bits, collision rate");

    // -----------------------------------------------------------------------
    // SMARTS writer
    // -----------------------------------------------------------------------
    m.def("to_smarts",
          [](const smsd::MolGraph& g,
             bool inclArom, bool inclCharge,
             bool inclRing, bool inclH, bool inclIso) {
              smsd::SmartsWriteOptions opts;
              opts.includeAromaticity = inclArom;
              opts.includeCharge      = inclCharge;
              opts.includeRingMember  = inclRing;
              opts.includeHCount      = inclH;
              opts.includeIsotope     = inclIso;
              return smsd::toSMARTS(g, opts);
          },
          py::arg("mol"),
          py::arg("include_aromaticity") = true,
          py::arg("include_charge")      = true,
          py::arg("include_ring_member") = false,
          py::arg("include_h_count")     = false,
          py::arg("include_isotope")     = false,
          "Generate canonical SMARTS with configurable predicates");

    // -----------------------------------------------------------------------
    // GPU / compute backend
    // -----------------------------------------------------------------------
    m.def("gpu_is_available",
          []() { return smsd::gpu::isAvailable(); },
          "True when a GPU is available at runtime (CUDA on Linux/Windows, "
          "Metal on macOS/Apple Silicon).");

    m.def("gpu_device_info",
          []() { return smsd::gpu::deviceInfo(); },
          "Human-readable compute backend string.\n"
          "Examples:\n"
          "  'GPU: Tesla T4 (compute 7.5)  [OpenMP 4.5, 8 threads]'\n"
          "  'Metal GPU: Apple M2 Pro  [OpenMP 5.0, 10 threads]'\n"
          "  'CPU: OpenMP 4.5, 16 threads'");

    // -----------------------------------------------------------------------
    // Parallel batch operations (OpenMP on CPU, CUDA on GPU when available)
    // -----------------------------------------------------------------------
    m.def("batch_substructure",
          [](const smsd::MolGraph& query,
             const std::vector<smsd::MolGraph>& targets,
             const smsd::ChemOptions& opts,
             int numThreads) {
              return smsd::batch::batchSubstructure(query, targets, opts, numThreads);
          },
          py::arg("query"), py::arg("targets"),
          py::arg("opts")        = smsd::ChemOptions(),
          py::arg("num_threads") = 0,
          py::call_guard<py::gil_scoped_release>(),
          "Parallel 1-query-vs-N substructure check. Returns list[bool]. "
          "num_threads=0 uses all available processors.");

    m.def("batch_mcs",
          [](const smsd::MolGraph& query,
             const std::vector<smsd::MolGraph>& targets,
             const smsd::ChemOptions& chem,
             const smsd::McsOptions& opts,
             int numThreads) {
              return smsd::batch::batchMCS(query, targets, chem, opts, numThreads);
          },
          py::arg("query"), py::arg("targets"),
          py::arg("chem")        = smsd::ChemOptions(),
          py::arg("opts")        = smsd::McsOptions(),
          py::arg("num_threads") = 0,
          py::call_guard<py::gil_scoped_release>(),
          "Parallel 1-query-vs-N MCS. Returns list[dict] of atom mappings. "
          "num_threads=0 uses all available processors.");
}
