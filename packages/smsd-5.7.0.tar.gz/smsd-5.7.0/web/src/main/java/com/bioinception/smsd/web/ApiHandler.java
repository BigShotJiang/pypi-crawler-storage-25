/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2018-2026 BioInception PVT LTD
 * Algorithm Copyright (c) 2009-2026 Syed Asad Rahman
 */
package com.bioinception.smsd.web;

import com.bioinception.smsd.core.ChemOptions;
import com.bioinception.smsd.core.SMSD;
import com.bioinception.smsd.core.Standardiser;
import io.javalin.http.Context;
import org.openscience.cdk.interfaces.IAtomContainer;
import org.openscience.cdk.smiles.SmiFlavor;
import org.openscience.cdk.smiles.SmilesGenerator;

import java.awt.Color;
import java.util.*;

/**
 * REST API handlers for SMSD Web.
 *
 * @author Syed Asad Rahman
 */
public class ApiHandler {

    private static final SmilesGenerator SMIGEN = new SmilesGenerator(
            SmiFlavor.Unique | SmiFlavor.UseAromaticSymbols);

    /** POST /api/validate — parse, validate, return properties + SVG */
    @SuppressWarnings("unchecked")
    public void validate(Context ctx) {
        try {
            Map<String, Object> body = ctx.bodyAsClass(Map.class);
            String smiles = (String) body.get("smiles");
            if (smiles == null || smiles.isBlank()) {
                ctx.status(400).json(Map.of("error", "Missing 'smiles' field"));
                return;
            }

            IAtomContainer mol = DepictService.parseAndLayout(smiles);
            Standardiser.standardise(mol, Standardiser.TautomerMode.NONE);
            String canonical = SMIGEN.create(mol);

            Map<String, Object> result = new LinkedHashMap<>();
            result.put("valid", true);
            result.put("canonical", canonical);
            result.putAll(DepictService.computeProperties(mol));
            result.put("svg", DepictService.depictSvg(mol, null, null, 350, 250, true));
            ctx.json(result);
        } catch (Exception e) {
            ctx.json(Map.of("valid", false, "error", e.getMessage()));
        }
    }

    /** GET /api/depict?smiles=...&highlight=0,1,2&width=400&height=300&format=svg|png|pdf */
    public void depict(Context ctx) {
        try {
            String smiles = ctx.queryParam("smiles");
            int w = ctx.queryParamAsClass("width", Integer.class).getOrDefault(600);
            int h = ctx.queryParamAsClass("height", Integer.class).getOrDefault(400);
            String hlParam = ctx.queryParam("highlight");
            boolean numbers = ctx.queryParamAsClass("numbers", Boolean.class).getOrDefault(true);
            String fmt = ctx.queryParamAsClass("format", String.class).getOrDefault("svg");

            Set<Integer> hl = new HashSet<>();
            if (hlParam != null && !hlParam.isBlank())
                for (String s : hlParam.split(",")) hl.add(Integer.parseInt(s.trim()));
            Set<Integer> hlSet = hl.isEmpty() ? null : hl;

            IAtomContainer mol = DepictService.parseAndLayout(smiles);
            switch (fmt.toLowerCase()) {
                case "png":
                    ctx.contentType("image/png")
                       .result(DepictService.depictPng(mol, hlSet, DepictService.QUERY_COLOR, w, h, numbers));
                    break;
                case "pdf":
                    ctx.contentType("application/pdf")
                       .header("Content-Disposition", "attachment; filename=molecule.pdf")
                       .result(DepictService.depictPdf(mol, hlSet, DepictService.QUERY_COLOR, w, h, numbers));
                    break;
                default:
                    ctx.contentType("image/svg+xml")
                       .result(DepictService.depictSvg(mol, hlSet, DepictService.QUERY_COLOR, w, h, numbers));
            }
        } catch (Exception e) {
            ctx.status(400).json(Map.of("error", e.getMessage()));
        }
    }

    /** POST /api/sub — substructure search with highlighted SVGs */
    @SuppressWarnings("unchecked")
    public void substructure(Context ctx) {
        try {
            Map<String, Object> body = ctx.bodyAsClass(Map.class);
            String qSmi = (String) body.get("query");
            String tSmi = (String) body.get("target");
            long timeout = body.containsKey("timeout") ? ((Number) body.get("timeout")).longValue() : 10000L;

            long t0 = System.nanoTime();
            SMSD smsd = new SMSD(qSmi, tSmi, new ChemOptions());
            List<Map<Integer, Integer>> mappings = smsd.findAllSubstructures(100, timeout);
            long elapsed = (System.nanoTime() - t0) / 1_000_000L;

            Map<String, Object> result = new LinkedHashMap<>();
            result.put("exists", !mappings.isEmpty());
            result.put("mappingCount", mappings.size());
            result.put("timeMs", elapsed);

            if (!mappings.isEmpty()) {
                Map<Integer, Integer> first = mappings.get(0);
                result.put("tanimoto", tanimoto(smsd.getQuery(), smsd.getTarget(), first.size()));

                // Build mapping pairs
                List<List<Integer>> pairs = new ArrayList<>();
                for (var e : first.entrySet()) pairs.add(List.of(e.getKey(), e.getValue()));
                result.put("pairs", pairs);

                // Generate highlighted SVGs
                Set<Integer> queryHL = new HashSet<>(first.keySet());
                Set<Integer> targetHL = new HashSet<>(first.values());

                IAtomContainer qMol = DepictService.parseAndLayout(qSmi);
                IAtomContainer tMol = DepictService.parseAndLayout(tSmi);

                result.put("querySvg", DepictService.depictSvg(qMol, queryHL,
                        DepictService.QUERY_COLOR, 350, 250, true));
                result.put("targetSvg", DepictService.depictSvg(tMol, targetHL,
                        DepictService.TARGET_COLOR, 350, 250, true));
            }
            ctx.json(result);
        } catch (Exception e) {
            e.printStackTrace();
            ctx.status(400).json(Map.of("error", e.getMessage() != null ? e.getMessage() : e.getClass().getName()));
        }
    }

    /** POST /api/mcs — MCS search with highlighted SVGs */
    @SuppressWarnings("unchecked")
    public void mcs(Context ctx) {
        try {
            Map<String, Object> body = ctx.bodyAsClass(Map.class);
            String qSmi = (String) body.get("query");
            String tSmi = (String) body.get("target");
            boolean induced = Boolean.TRUE.equals(body.get("induced"));
            boolean connected = body.containsKey("connected") ? Boolean.TRUE.equals(body.get("connected")) : true;
            long timeout = body.containsKey("timeout") ? ((Number) body.get("timeout")).longValue() : 10000L;

            long t0 = System.nanoTime();
            SMSD smsd = new SMSD(qSmi, tSmi, new ChemOptions());
            Map<Integer, Integer> mcs = smsd.findMCS(induced, connected, timeout);
            long elapsed = (System.nanoTime() - t0) / 1_000_000L;

            Map<String, Object> result = new LinkedHashMap<>();
            result.put("mcsSize", mcs.size());
            result.put("timeMs", elapsed);
            result.put("tanimoto", tanimoto(smsd.getQuery(), smsd.getTarget(), mcs.size()));

            List<List<Integer>> pairs = new ArrayList<>();
            for (var e : mcs.entrySet()) pairs.add(List.of(e.getKey(), e.getValue()));
            result.put("pairs", pairs);

            // Generate highlighted SVGs
            Set<Integer> queryHL = new HashSet<>(mcs.keySet());
            Set<Integer> targetHL = new HashSet<>(mcs.values());

            IAtomContainer qMol = DepictService.parseAndLayout(qSmi);
            IAtomContainer tMol = DepictService.parseAndLayout(tSmi);

            result.put("querySvg", DepictService.depictSvg(qMol, queryHL,
                    DepictService.MCS_COLOR, 350, 250, true));
            result.put("targetSvg", DepictService.depictSvg(tMol, targetHL,
                    DepictService.MCS_COLOR, 350, 250, true));

            ctx.json(result);
        } catch (Exception e) {
            ctx.status(400).json(Map.of("error", e.getMessage()));
        }
    }

    /** POST /api/export — export as smiles, svg, png, or pdf */
    @SuppressWarnings("unchecked")
    public void export(Context ctx) {
        try {
            Map<String, Object> body = ctx.bodyAsClass(Map.class);
            String qSmi = (String) body.get("query");
            String tSmi = (String) body.get("target");
            String format = ((String) body.getOrDefault("format", "smiles")).toLowerCase();
            String mode = (String) body.getOrDefault("mode", "mcs");
            int w = body.containsKey("width") ? ((Number) body.get("width")).intValue() : 800;
            int h = body.containsKey("height") ? ((Number) body.get("height")).intValue() : 600;

            SMSD smsd = new SMSD(qSmi, tSmi, new ChemOptions());

            // Get mapping based on mode
            Set<Integer> targetHL;
            Color hlColor;
            String textResult;
            if ("sub".equals(mode)) {
                List<Map<Integer, Integer>> maps = smsd.findAllSubstructures(100, 10000L);
                Map<Integer, Integer> first = maps.isEmpty() ? Collections.emptyMap() : maps.get(0);
                targetHL = new HashSet<>(first.values());
                hlColor = DepictService.TARGET_COLOR;
                textResult = "Query: " + SMIGEN.create(smsd.getQuery()) + "\n" +
                        "Target: " + SMIGEN.create(smsd.getTarget()) + "\n" +
                        "Substructure: " + !maps.isEmpty() + "\n" +
                        "Mappings: " + maps.size() + "\n" +
                        "Tanimoto: " + tanimoto(smsd.getQuery(), smsd.getTarget(), first.size()) + "\n";
            } else {
                Map<Integer, Integer> mcs = smsd.findMCS(false, true, 10000L);
                targetHL = new HashSet<>(mcs.values());
                hlColor = DepictService.MCS_COLOR;
                textResult = "Query: " + SMIGEN.create(smsd.getQuery()) + "\n" +
                        "Target: " + SMIGEN.create(smsd.getTarget()) + "\n" +
                        "MCS Size: " + mcs.size() + "\n" +
                        "Tanimoto: " + tanimoto(smsd.getQuery(), smsd.getTarget(), mcs.size()) + "\n";
            }

            IAtomContainer tMol = DepictService.parseAndLayout(tSmi);
            switch (format) {
                case "smiles":
                    ctx.contentType("text/plain").result(textResult);
                    break;
                case "svg":
                    ctx.contentType("image/svg+xml")
                       .result(DepictService.depictSvg(tMol, targetHL, hlColor, w, h, true));
                    break;
                case "png":
                    ctx.contentType("image/png")
                       .header("Content-Disposition", "attachment; filename=smsd-result.png")
                       .result(DepictService.depictPng(tMol, targetHL, hlColor, w, h, true));
                    break;
                case "pdf":
                    ctx.contentType("application/pdf")
                       .header("Content-Disposition", "attachment; filename=smsd-result.pdf")
                       .result(DepictService.depictPdf(tMol, targetHL, hlColor, w, h, true));
                    break;
                default:
                    ctx.status(400).json(Map.of("error", "Unknown format: " + format
                            + ". Supported: smiles, svg, png, pdf"));
            }
        } catch (Exception e) {
            ctx.status(400).json(Map.of("error", e.getMessage()));
        }
    }

    private static double tanimoto(IAtomContainer q, IAtomContainer t, int common) {
        int denom = q.getAtomCount() + t.getAtomCount() - common;
        return denom > 0 ? Math.round((double) common / denom * 1000.0) / 1000.0 : 0;
    }
}
