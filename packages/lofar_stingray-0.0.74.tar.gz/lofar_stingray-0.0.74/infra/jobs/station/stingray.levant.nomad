# Receives station statistics and meta data,
# publishes them on ZMQ, and records them as JSON on S3.
#
# repo: git.astron.nl/lofar2.0/stingray
# file: infra/jobs/station/stingray.levant.nomad

job "statistics" {
  region      = "[[ $.region ]]"
  datacenters = ["stat"]

  update {
    # this job takes a bit longer to become healthy
    max_parallel      = 3
    progress_deadline = "15m"
  }

  group "stingray-metadata" {
    count = 1

    restart {
      interval         = "10m"
      attempts         = 10
      delay            = "30s"
      mode             = "delay"
    }

    network {
      mode = "bridge"
    }

    task "stingray-record-metadata" {
      driver = "docker"

      config {
        image = "[[ $.registry.astron.url ]]/stingray:[[$.image_tag]]"

        entrypoint = [
          "l2ss-stingray-forward",
          "--datatype=json",
          "zmq+tcp://device-metadata.service.consul:6001/metadata?content-type=application%2Fjson",
          "s3://statistics/[[$.station]]/metadata?content-type=application%2Fjson"
        ]
      }

      template {
        destination = "secrets/env.txt"
        env         = true
        data = <<EOF
{{- with nomadVar "object-storage/local" }}
MINIO_ROOT_USER     = "{{ .username }}"
MINIO_ROOT_PASSWORD = "{{ .password }}"
{{- end }}
EOF
      }

      resources {
        cpu    = 10
        memory = 512
      }
    }
  }

  [[ range $af, $fields := $.stingray ]]
  [[   range $st, $ip := $fields ]]
  group "stingray-[[ $af ]]-[[ $st ]]" {
    count = 1

    restart {
      interval         = "10m"
      attempts         = 10
      delay            = "30s"
      mode             = "delay"
    }

    network {
      mode = "cni/statistics"

      cni {
        args = {
          IP = "[[ $ip ]]"
          GATEWAY = "10.99.250.250"
        }
      }
    }

    service {
      name = "statistics-[[ $af ]]-[[ $st ]]-zmq"
      port = 6001
      address_mode = "alloc"

      check {
        type = "tcp"
        interval = "20s"
        timeout = "5s"
        address_mode = "alloc"
      }
    }

    service {
      name = "statistics-[[ $af ]]-[[ $st ]]-udp"
      port = 5001
      address_mode = "alloc"
    }

    service {
      name = "stingray-[[ $af ]]-[[ $st ]]-publish-metrics"
      tags = ["scrape"]
      port = 8000
      address_mode = "alloc"
    }

    service {
      name = "stingray-[[ $af ]]-[[ $st ]]-record-metrics"
      tags = ["scrape"]
      port = 8001
      address_mode = "alloc"
    }

    task "wait-for-s3" {
      lifecycle {
        hook    = "prestart"
        sidecar = false
      }
      driver = "docker"

      config {
        image   = "[[ $.registry.astron.url ]]/busybox:stable"
        command = "sh"
        args    = ["-c", "while ! nc -z s3.service.consul 9000; do sleep 1; done"]
      }
    }

    task "stingray-publish-[[ $af ]]-[[ $st ]]" {
      driver = "docker"

      config {
        image = "[[ $.registry.astron.url ]]/stingray:[[ $.image_tag ]]"

        entrypoint = [
          "l2ss-stingray-publish",
          "[[ $.station ]]",
          "[[ $af ]]",
          "[[ $st ]]",
          "udp://0.0.0.0:5001?content-type=application%2Flofar.statistic",
          "--port=6001"
        ]
      }

      resources {
        cpu    = 10
        memory = 128
        memory_max = 256
      }
    }

    task "stingray-record-[[ $af ]]-[[ $st ]]" {
      driver = "docker"

      config {
          image = "[[ $.registry.astron.url ]]/stingray:[[$.image_tag]]"

          entrypoint = [
            "l2ss-stingray-forward",
            "zmq+tcp://localhost:6001/[[ $st ]]/[[ $af ]]/?content-type=application%2Fjson",
            "s3://statistics/[[$.station]]/[[ $st ]]/[[ $af ]]?content-type=application%2Favro.[[ $st ]]",
            "--metrics-port=8001"
          ]
      }

      template {
        destination = "secrets/env.txt"
        env         = true
        data = <<EOF
{{- with nomadVar "object-storage/local" }}
MINIO_ROOT_USER     = "{{ .username }}"
MINIO_ROOT_PASSWORD = "{{ .password }}"
{{- end }}
EOF
      }

      resources {
        cpu    = 10
        memory = 128
        memory_max = 2048
      }
    }
  }
  [[   end ]]
  [[ end ]]
}
