# Replicates statistics JSONs from station to central S3.
#
# repo: git.astron.nl/lofar2.0/stingray
# file: infra/jobs/station/stingray-bucket-replication.levant.nomad

job "statistics-bucket-replication" {
  region      = "[[ $.region ]]"
  datacenters = ["stat"]
  type        = "service"

  group "bucket-replication" {
    count = 1

    network {
      mode = "bridge"
    }

    task "initialise-buckets" {
      lifecycle {
        hook = "prestart"
      }

      driver = "docker"
      config {
        image   = "[[ $.registry.astron.url ]]/seaweedfs:[[.object_storage.seaweedfs.version]]"
        entrypoint = ["timeout"]
        args    = [
          "600",
          "/local/run.sh"
        ]
      }

      resources {
        cpu    = 10
        memory = 512
      }

      template {
        destination     = "${NOMAD_TASK_DIR}/run.sh"
        change_mode     = "noop"
        perms           = "755"
        data = <<EOF
#!/bin/sh
{{ range service "seaweed-master" }}
SHELL_MASTER={{ .Address }}:{{ .Port }}
{{   break }}
{{ else }}
exit 1
{{ end }}

echo "remote.unmount -dir=/buckets/statistics/[[ .station ]]" | weed shell -master=$SHELL_MASTER
until echo "remote.mount" | weed shell -master=$SHELL_MASTER | grep -q central-statistics; do
  echo "s3.bucket.delete -name=statistics" | weed shell -master=$SHELL_MASTER
  echo "remote.mount -dir=/buckets/statistics/[[ .station ]] -remote=central/central-statistics/[[ .station ]]" | weed shell -master=$SHELL_MASTER
  sleep 5
done
EOF
      }
    }

    task "replicate-statistics-downstream" {
      driver = "docker"
      config {
        image   = "[[ $.registry.astron.url ]]/seaweedfs:[[.object_storage.seaweedfs.version]]"
        entrypoint = ["sh"]
        args    = [
          "/local/run.sh"
        ]
      }

      resources {
        cpu    = 10
        memory = 512
      }

      template {
        destination     = "${NOMAD_TASK_DIR}/run.sh"
        change_mode     = "noop"
        data = <<EOF
{{ range service "seaweed-master" }}
SHELL_MASTER={{ .Address }}:{{ .Port }}
{{   break }}
{{ end }}

while true; do
  echo "remote.meta.sync -dir=/buckets/statistics/[[ .station ]]" | weed shell -master=$SHELL_MASTER
  echo "remote.uncache -dir=/buckets/statistics/[[ .station ]] -minAge=1" | weed shell -master=$SHELL_MASTER
  sleep 5m
done
EOF
      }
    }

    task "replicate-statistics-upstream" {
      driver = "docker"
      config {
        image   = "[[ $.registry.astron.url ]]/seaweedfs:[[.object_storage.seaweedfs.version]]"
        entrypoint = ["sh"]
        args    = [
          "/local/run.sh"
        ]
      }
     resources {
        cpu    = 100
        memory = 1024
        memory_max = 8192
      }

      template {
        destination     = "${NOMAD_TASK_DIR}/run.sh"
        change_mode     = "restart"
        data = <<EOF
{{ range service "seaweed-filer" }}
while true; do
  weed filer.remote.sync -filer={{ .Address }}:{{ .Port }} -dir=/buckets/statistics/[[ .station ]]
  sleep 1m
done
{{   break }}
{{ end }}
EOF
      }
    }
  }
}
