# Extracts station statistics JSON files and generates an HDF5 file
# containing their data and associated meta data.
#
# repo: git.astron.nl/lofar2.0/stingray
# file: infra/jobs/central/periodic-statistics-extract.levant.nomad

job "periodic-statistics-extract" {
  region      = "lofar-central"
  datacenters = ["nl-cit"]
  type        = "batch"
  namespace   = "statistics"

  periodic {
    crons            = ["1 * * * * *"]
    prohibit_overlap = true
  }

  vault {
  }

  group "generate-dynspec" {
    count = 1

    network {
      mode = "bridge"
    }

    ephemeral_disk {
      size = 512 # 1 hour BSTs are ~200 MByte, take plenty of room
    }

    task "fetch-antennafield-list" {
      lifecycle {
        sidecar = false
        hook = "prestart"
      }

      driver = "docker"
      config {
        image = "[[ $.registry.astron.url ]]/s3-query:[[$.image_tag]]"
        entrypoint = ["local/list-antennafields.sh"]

        mount {
          type   = "bind"
          source = "secrets/mc"
          target = "/root/.minio-client"
        }
      }

      resources {
        cpu    = 10
        memory = 512
      }

      template {
        destination  = "local/list-antennafields.sh"
        perms        = "755"
        data = <<EOF
#!/bin/bash -v

# List all (station antennafield) pairs for which directory
# central-statistics/station/bst/antennafield exists.

STATIONS=$(minio-client ls central/central-statistics/ --json | jq -r '.key|rtrimstr("/")')
(for STATION in $STATIONS; do
  ANTENNAFIELDS=$(minio-client ls central/central-statistics/$STATION/bst/ --json | jq -r '.key|rtrimstr("/")')

  for FIELD in $ANTENNAFIELDS; do
    echo $STATION $FIELD
  done
done) > ${NOMAD_ALLOC_DIR}/antennafields.txt

cat ${NOMAD_ALLOC_DIR}/antennafields.txt
EOF
      }

      template {
        destination     = "secrets/mc/config.json"
        change_mode     = "noop"
        data = <<EOF
{
  "aliases": {
    "central": {
      {{ range service "s3@lofar-central" }}
      "url": "{{ index .ServiceMeta "protocol" }}://{{ .Address }}:{{ .Port }}",
      {{   break }}
      {{ end }}
      {{ with secret "kv-v2/data/minio/station" }}
      "accessKey": "{{ .Data.data.username }}",
      "secretKey": "{{ .Data.data.password }}",
      {{ end }}
      "api": "s3v4",
      "path": "on"
    }
  }
}
EOF
      }
    }

    task "stingray" {
      driver = "docker"
      config {
        image = "[[ $.registry.astron.url ]]/stingray:[[$.image_tag]]"
        entrypoint = ["local/dynspec.sh"]
      }

      template {
        destination  = "local/dynspec.sh"
        perms        = "755"
        data = <<EOF
#!/bin/bash -v
{{ range service "s3" }}

# grab last full hour
BEGIN="$(date +%FT%H:00:00 -d '-1 hours')"
END="$(date +%FT%T -d '+1 hours '${BEGIN})"

echo "Converting BSTs between ${BEGIN} and ${END}"

cat ${NOMAD_ALLOC_DIR}/antennafields.txt | while read STATION ANTENNA_FIELD; do

echo "Gathering BST statistics for ${STATION} ${ANTENNA_FIELD} -> ${STATION}_${ANTENNA_FIELD}_bst.h5"

# extract statistics as HDF5
# NB: we don't actually know whether there are recent statistics, so this call could fail
l2ss-stingray-extract \
     --endpoint {{ .Address }}:{{ .Port }} \
{{-  if (eq (index .ServiceMeta "protocol") "https") }}
     --secure \
{{-  end }}
    "${STATION}" \
    "${ANTENNA_FIELD}" \
    "bst" \
    "${BEGIN}" \
    "${END}" \
    "s3://central-statistics" \
    "${STATION}_${ANTENNA_FIELD}_bst.h5" || continue

# generate BST (normalized)
OUTPUT_FILENAME=`echo "${STATION}_${ANTENNA_FIELD}_${BEGIN}_${END}_3600s_norm_dynspec.png" | tr ':' '_'`
echo "Plotting BST normalized dynamic spectrum for ${STATION} ${ANTENNA_FIELD} -> ${OUTPUT_FILENAME}"
l2ss-stingray-plot-bst \
     --endpoint {{ .Address }}:{{ .Port }} \
{{-  if (eq (index .ServiceMeta "protocol") "https") }}
     --secure \
{{-  end }}
    "${STATION}_${ANTENNA_FIELD}_bst.h5" \
    -d "s3://quality-monitoring/dynspec/${END}/${OUTPUT_FILENAME}" \
    --normalized

# generate BST (unnormalized)
OUTPUT_FILENAME=`echo "${STATION}_${ANTENNA_FIELD}_${BEGIN}_${END}_3600s_dynspec.png" | tr ':' '_'`
echo "Plotting BST dynamic spectrum for ${STATION} ${ANTENNA_FIELD} -> ${OUTPUT_FILENAME}"
l2ss-stingray-plot-bst \
     --endpoint {{ .Address }}:{{ .Port }} \
{{-  if (eq (index .ServiceMeta "protocol") "https") }}
     --secure \
{{-  end }}
    "${STATION}_${ANTENNA_FIELD}_bst.h5" \
    -d "s3://quality-monitoring/dynspec/${END}/${OUTPUT_FILENAME}" \
    --no-normalized

rm -f "${STATION}_${ANTENNA_FIELD}_bst.h5"
done

{{   break }}
{{ end }}
EOF
      }

      template {
        destination = "secrets/env.txt"
        env         = true

        data = <<EOH
        {{- with secret "kv-v2/minio/statistics-extract" -}}
        MINIO_ROOT_USER      = "{{ .Data.data.username }}"
        MINIO_ROOT_PASSWORD  = "{{ .Data.data.password }}"
        {{- end -}}
        EOH
      }

      resources {
        cpu    = 10
        memory = 512
        memory_max = 4096
      }
    }
  }
}
