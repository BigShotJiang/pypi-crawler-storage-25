import argparse
import logging
import sys
from datetime import datetime
from urllib.parse import urlparse

import numpy
from lofar_lotus.file_access import read_hdf5
from lofty.plotting import plot_bst_dynamic_spectrum

from lofar_stingray._logging import setup_logging_handler
from lofar_stingray._minio import add_minio_argument, get_minio_client
from lofar_stingray.statistics_data import BstStatisticsDataFile, BstStatisticsSet
from lofar_stingray.utils import url_write

logger = logging.getLogger()
logger.setLevel(logging.INFO)
logger.addHandler(setup_logging_handler())


def tile_beam_from_bst_dataset(dataset: BstStatisticsSet):
    """Return name of the tile beam to display for the given dataset."""

    non_zero_tile_beams = dataset.tile_beam_pointing_directions is not None and [
        d for d in dataset.tile_beam_pointing_directions if "(, )" not in d
    ]

    non_zero_digital_beams = dataset.digital_beam_pointing_directions is not None and [
        d for d in dataset.digital_beam_pointing_directions if "(, )" not in d
    ]

    if non_zero_tile_beams:
        tile_beam = non_zero_tile_beams[0]
    elif non_zero_digital_beams:
        tile_beam = non_zero_digital_beams[0]
    else:
        tile_beam = "???"

    return tile_beam


def make_bst_plot(
    bst_file: BstStatisticsDataFile, output_png_filename: str, normalized: bool
):
    """Generate a BST PNG plot from a BST HDF5 dataset."""

    logging.info("Reading input data")

    # read & merge all datasets into memory. each dataset is (beamlet, pol)
    datasets = [bst_file[k] for k in bst_file]
    bst_data = numpy.stack(datasets)

    # read & merge subband frequencies. each set is (subband,)
    frequencies = [bst_file[k].frequencies for k in bst_file]
    bst_frequencies = numpy.stack(frequencies)

    # read timestamps
    timestamps = numpy.array(
        [datetime.fromisoformat(bst_file[k].timestamp) for k in bst_file]
    )

    # fetch metadata
    station_name = bst_file.station_name
    antenna_field = bst_file.antenna_field
    tile_beam = tile_beam_from_bst_dataset(datasets[0]) if datasets else "???"

    # make plot
    logging.info("Making plot_bst_dynamic_spectrum...")
    plot_bst_dynamic_spectrum(
        bst_data,
        timestamps,
        pols=("I",),
        normalized=normalized,
        output_fname=output_png_filename,
        station_name=f"{station_name}{antenna_field}",
        tile_beam=tile_beam,
        beamlet_frequencies=bst_frequencies,
    )
    logging.info("Done making plot_bst_dynamic_spectrum")


def _create_parser():
    """Define the parser"""
    parser = argparse.ArgumentParser(description="Plot BST data")
    parser.add_argument(
        "--normalized",
        action=argparse.BooleanOptionalAction,
        help="Normalize the power in the plots",
        default=True,
    )
    parser.add_argument(
        "-d",
        "--destination",
        type=urlparse,
        help="URL of output figure [str]",
        default="file://bst-plot.png",
    )
    parser.add_argument("source", help="BST hdf5 filename", metavar="FILE")
    add_minio_argument(parser)

    return parser


def main(cli_args: list[str] | None = None) -> int:
    parser = _create_parser()
    args = parser.parse_args(cli_args)
    minio_client = get_minio_client(args or sys.argv[1:])

    logger.info("Input: %s", args.source)
    logger.info("Output: %s", args.destination)

    with read_hdf5(args.source, BstStatisticsDataFile) as bst_file:
        with url_write(args.destination, {}, minio_client, ".png") as output_filename:
            logger.info("Writing to %s", output_filename)

            make_bst_plot(bst_file, output_filename, normalized=args.normalized)

    return 0


if __name__ == "__main__":
    main()
