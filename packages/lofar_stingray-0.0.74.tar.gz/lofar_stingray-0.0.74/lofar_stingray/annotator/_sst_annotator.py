#  Copyright (C) 2026 ASTRON (Netherlands Institute for Radio Astronomy)
#  SPDX-License-Identifier: Apache-2.0

"""Class to aggregate SST statistics"""

from datetime import datetime
from typing import Iterable

import numpy

from lofar_stingray.statistics_data import (
    SstStatisticsSet,
    StatisticsDataFile,
)

from ._base import BaseAnnotator


class SstAnnotator(BaseAnnotator):
    """Class to aggregate SST statistics"""

    # Number of subbands per packet
    N_subbands = 512

    # Subband range encoded in packets
    SUBBAND_RANGE = list(range(N_subbands))

    def __init__(
        self,
        station: str,
        antenna_field: str,
        start_time: datetime,
        metadata_packets: Iterable,
        matrices: Iterable,
    ):  # pylint: disable=too-many-arguments,too-many-positional-arguments
        super().__init__(station, antenna_field, start_time, metadata_packets)
        self.matrices = matrices

    @property
    def mode(self):
        return "SST"

    def set_statisticsset_metadata(
        self, statisticsset: SstStatisticsSet, timestamp: datetime, matrix: dict
    ):
        super().set_statisticsset_metadata(statisticsset, timestamp, matrix)

        metadata = self.metadata.get_metadata(timestamp)
        sdp_metadata = metadata.get(self.sdp_device, {})

        subbands = self.SUBBAND_RANGE
        frequencies = sdp_metadata.get("subband_frequency_R", [[]])[0]
        statisticsset.subbands = subbands
        statisticsset.frequencies = [
            frequencies[sb] if sb < len(frequencies) else 0.0 for sb in subbands
        ]

    def write(self, statistics: StatisticsDataFile):
        self.set_file_header(statistics)

        for matrix in self.matrices:
            timestamp = datetime.fromisoformat(matrix["timestamp"])

            values = numpy.array(matrix["sst_data"], dtype=numpy.float32).view(
                SstStatisticsSet
            )

            self.set_statisticsset_metadata(values, timestamp, matrix)

            statistics[f"SST_{self.timestamp_dataset_name(timestamp)}"] = values
