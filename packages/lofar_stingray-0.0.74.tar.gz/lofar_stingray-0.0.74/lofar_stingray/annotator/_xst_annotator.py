#  Copyright (C) 2026 ASTRON (Netherlands Institute for Radio Astronomy)
#  SPDX-License-Identifier: Apache-2.0

"""Class to aggregate XST statistics"""

from datetime import datetime
from typing import Iterable

import numpy

from lofar_stingray.statistics_data import (
    StatisticsDataFile,
    XstStatisticsSet,
)

from ._base import BaseAnnotator


class XstAnnotator(BaseAnnotator):
    """Class to aggregate XST statistics packets."""

    def __init__(
        self,
        station: str,
        antenna_field: str,
        start_time: datetime,
        metadata_packets: Iterable,
        matrices: Iterable,
    ):  # pylint: disable=too-many-arguments,too-many-positional-arguments
        super().__init__(station, antenna_field, start_time, metadata_packets)
        self.matrices = matrices

    @property
    def mode(self):
        return "XST"

    def set_statisticsset_metadata(
        self, statisticsset: XstStatisticsSet, timestamp: datetime, matrix: dict
    ):
        super().set_statisticsset_metadata(statisticsset, timestamp, matrix)

        metadata = self.metadata.get_metadata(timestamp)
        sdp_metadata = metadata.get(self.sdp_device, {})
        digitalbeam_metadata = metadata.get(self.digitalbeam_device, {})

        subband = matrix["subband"]
        frequencies = sdp_metadata.get("subband_frequency_R", [[]])[0]
        statisticsset.subband = subband
        statisticsset.frequency = (
            frequencies[subband] if subband < len(frequencies) else 0.0
        )

        statisticsset.digital_beam_pointing_directions = digitalbeam_metadata.get(
            "Pointing_direction_str_R", []
        )
        statisticsset.digital_beam_tracking_enabled = digitalbeam_metadata.get(
            "Tracking_enabled_R", True
        )
        statisticsset.digital_beam_subbands = digitalbeam_metadata.get(
            "subband_select_RW", []
        )

    def write(self, statistics: StatisticsDataFile):
        self.set_file_header(statistics)

        for matrix in self.matrices:
            timestamp = datetime.fromisoformat(matrix["timestamp"])
            subband = matrix["subband"]

            real = numpy.array(matrix["xst_data_real"], dtype=numpy.float32)
            imag = numpy.array(matrix["xst_data_imag"], dtype=numpy.float32)
            values = (real + imag * 1j).view(XstStatisticsSet)

            self.set_statisticsset_metadata(values, timestamp, matrix)

            statistics[
                f"XST_{self.timestamp_dataset_name(timestamp)}_SB{subband:03}"
            ] = values
