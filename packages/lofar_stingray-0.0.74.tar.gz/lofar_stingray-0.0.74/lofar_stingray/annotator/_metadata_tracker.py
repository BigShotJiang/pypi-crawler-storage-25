#  Copyright (C) 2026 ASTRON (Netherlands Institute for Radio Astronomy)
#  SPDX-License-Identifier: Apache-2.0

"""Track metadata changes over time."""

from datetime import UTC, datetime
from functools import lru_cache
from typing import Dict

from lofar_lotus.dict import CaseInsensitiveDict


class MetadataTracker:
    MetadataDict = CaseInsensitiveDict[str, Dict[str, object]]

    def __init__(self):
        self.metadata: Dict[datetime, self.MetadataDict] = {}

    def add_packet(self, metadata_packet: dict):
        timestamp = datetime.fromisoformat(metadata_packet["ts"])

        # we assume data arrives in chronological order
        if self.metadata:
            last_timestamp = list(self.metadata.keys())[-1]
            if last_timestamp > timestamp:
                raise ValueError(
                    "Cannot process packets out of order. "
                    f"Received {timestamp.isoformat()} but "
                    f"newest item is {last_timestamp.isoformat()}"
                )

        # merge packet into datastructure
        metadata_for_timestamp = self.metadata.setdefault(
            timestamp, CaseInsensitiveDict()
        )

        # for each device, add or replace each value
        for device, data in metadata_packet.items():
            if device in ["ts"]:
                continue

            metadata_for_timestamp.setdefault(device, CaseInsensitiveDict()).update(
                data
            )

    @lru_cache(maxsize=16)
    def get_metadata(
        self, timestamp: datetime = datetime.max.replace(tzinfo=UTC)
    ) -> MetadataDict:
        """Return the metadata for a given timestamp, aggregating
        all changes until then."""

        metadata = CaseInsensitiveDict()
        self.update_metadata(metadata, datetime.min.replace(tzinfo=UTC), timestamp)
        return metadata

    def update_metadata(
        self, metadata: MetadataDict, from_timestamp: datetime, to_timestamp
    ):
        """Updates the metadata for a given timestamp, from an older
        set. More performant than get_metadata."""

        for metadata_timestamp, metadata_values in self.metadata.items():
            if metadata_timestamp <= from_timestamp:
                continue

            if metadata_timestamp > to_timestamp:
                break

            for device, data in metadata_values.items():
                metadata.setdefault(device, CaseInsensitiveDict()).update(data)
