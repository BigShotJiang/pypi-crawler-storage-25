#  Copyright (C) 2024 ASTRON (Netherlands Institute for Radio Astronomy)
#  SPDX-License-Identifier: Apache-2.0

"""Base annotator class"""

from abc import ABC, abstractmethod
from datetime import datetime, timedelta
from typing import Iterable

from lofar_stingray import __version__
from lofar_stingray.statistics_data import (
    StatisticsDataFile,
    StatisticsSet,
)

from ._metadata_tracker import MetadataTracker


class BaseAnnotator(ABC):
    """Base annotator class"""

    def __init__(
        self,
        station: str,
        antenna_field: str,
        start_time: datetime,
        metadata_packets: Iterable,
    ):
        self.station = station
        self.antenna_field = antenna_field
        self.start_time = start_time

        if self.antenna_field == "lba":
            self.antennafield_device = f"stat/afl/{antenna_field}"
        else:
            self.antennafield_device = f"stat/afh/{antenna_field}"

        self.sdp_device = f"stat/sdp/{antenna_field}"
        self.sdpfirmware_device = f"stat/sdpfirmware/{antenna_field}"
        self.digitalbeam_device = f"stat/digitalbeam/{antenna_field}"
        self.tilebeam_device = f"stat/tilebeam/{antenna_field}"
        self.calibration_device = f"stat/calibration/{antenna_field}"

        self.metadata = MetadataTracker()
        self.metadata_at_start_time = {}

        self._load_metadata(metadata_packets)

    def _load_metadata(self, metadata_packets):
        """Load and prepare the metadata"""
        for packet in metadata_packets:
            self.metadata.add_packet(packet)

        self.metadata_at_start_time = self.metadata.get_metadata(self.start_time)

    @staticmethod
    def round_datetime_ms(timestamp: datetime) -> datetime:
        """Round the given timestamp to the nearst millisecond."""
        subtract_us = timestamp.microsecond - round(timestamp.microsecond, -3)
        return timestamp - timedelta(microseconds=subtract_us)

    @staticmethod
    def timestamp_dataset_name(timestamp: datetime) -> str:
        """Convert the timestamp to its representation in the name of a dataset."""

        return (
            BaseAnnotator.round_datetime_ms(timestamp)
            .replace(tzinfo=None)
            .isoformat(timespec="milliseconds")
        )

    @abstractmethod
    def write(self, statistics: StatisticsDataFile):
        """Store the matrices and metadata into the StatisticsDataFile"""

    @property
    @abstractmethod
    def mode(self):
        """Return the current packet mode"""

    def set_file_header(self, statistics: StatisticsDataFile):
        """Returns the header fields per HDF5 file."""

        statistics.station_name = self.station.upper()
        # statistics.station_version = _get_station_version(self.antennafield_device)
        statistics.writer_version = __version__
        statistics.data_type = self.mode

        metadata = self.metadata_at_start_time
        antenna_field_metadata = metadata.get(self.antennafield_device, {})
        sdpfirmware_metadata = metadata.get(self.sdpfirmware_device, {})
        calibration_metadata = metadata.get(self.calibration_device, {})

        statistics.antenna_field = self.antenna_field.lower()
        statistics.antenna_type = self.antenna_field[:3].upper()
        statistics.antenna_names = antenna_field_metadata.get("Antenna_Names_R", [])
        statistics.antenna_status = antenna_field_metadata.get("Antenna_Status_R", [])
        statistics.antenna_usage_mask = antenna_field_metadata.get(
            "Antenna_Usage_Mask_R", []
        )
        statistics.antenna_reference_itrf = antenna_field_metadata.get(
            "Antenna_Reference_ITRF_R", []
        )
        statistics.pqr_to_etrs_rotation_matrix = antenna_field_metadata.get(
            "PQR_to_ETRS_rotation_matrix", []
        )

        statistics.antenna_to_sdp_mapping = antenna_field_metadata.get(
            "Antenna_to_SDP_Mapping_R", []
        )

        statistics.first_signal_input_index = sdpfirmware_metadata.get(
            "first_signal_input_index_R", -1
        )

        statistics.nr_signal_inputs = sdpfirmware_metadata.get("nr_signal_inputs_R", -1)

        statistics.fpga_firmware_version = sdpfirmware_metadata.get(
            "FPGA_firmware_version_R", []
        )
        statistics.fpga_hardware_version = sdpfirmware_metadata.get(
            "FPGA_hardware_version_R", []
        )

        statistics.rcu_pcb_id = antenna_field_metadata.get("RCU_PCB_ID_R", [])
        statistics.rcu_pcb_version = antenna_field_metadata.get("RCU_PCB_version_R", [])

        statistics.calibration_table_version = calibration_metadata.get(
            "Calibration_Version_R", []
        )

        statistics.calibration_table_md5 = calibration_metadata.get(
            "Calibration_Table_MD5_R", []
        )

        statistics.calibration_table_filename = calibration_metadata.get(
            "Calibration_Table_Filename_R", []
        )

    def set_statisticsset_metadata(
        self, statisticsset: StatisticsSet, timestamp: datetime, matrix: dict
    ):
        """Populate the metadata of the statisticsset with the given matrix."""
        statisticsset.timestamp = timestamp.isoformat(timespec="microseconds")

        statisticsset.integration_time = matrix["integration_interval"]
        statisticsset.observation_id = matrix["observation_id"]

        metadata = self.metadata.get_metadata(timestamp)
        antenna_field_metadata = metadata.get(self.antennafield_device, {})
        sdpfirmware_metadata = metadata.get(self.sdpfirmware_device, {})
        tilebeam_metadata = metadata.get(self.tilebeam_device, {})

        statisticsset.frequency_band = antenna_field_metadata.get(
            "Frequency_Band_RW", []
        )

        statisticsset.clock = sdpfirmware_metadata.get("clock_RW", 0.0)

        statisticsset.rcu_dithering_on = antenna_field_metadata.get("RCU_DTH_on_R", [])

        statisticsset.rcu_dithering_frequency = antenna_field_metadata.get(
            "RCU_DTH_freq_R", []
        )

        if tilebeam_metadata:
            statisticsset.tile_beam_pointing_directions = tilebeam_metadata.get(
                "Pointing_direction_str_R", []
            )
            statisticsset.tile_beam_tracking_enabled = tilebeam_metadata.get(
                "Tracking_enabled_R", True
            )
            statisticsset.tile_element_power = antenna_field_metadata.get(
                "HBAT_PWR_on_R", []
            )
