import logging
import os.path
import tempfile
from contextlib import contextmanager
from urllib.parse import ParseResult

from minio import Minio

logger = logging.getLogger()


@contextmanager
def url_write(
    destination: ParseResult,
    metadata: dict[str, str] | None = None,
    minio_client: Minio | None = None,
    temp_suffix: str = "",
):
    """Yields an output filename to be used to write data destined to
    go to "destination". Supported destination schemes are: s3, file, ''."""

    if destination.scheme in ["file", ""]:
        yield destination.netloc + destination.path
        return

    with tempfile.NamedTemporaryFile(
        prefix=os.path.basename(destination.path),
        suffix=temp_suffix,
        delete_on_close=False,
    ) as tf:
        logger.debug("Writing temporary data to %s", tf.name)

        yield tf.name

        if destination.scheme == "s3":
            tf.close()
            logger.info("Uploading to %s", destination.geturl())
            minio_client.fput_object(
                destination.netloc,
                destination.path,
                tf.name,
                metadata=metadata,
            )
            logger.info("Upload completed for %s", destination.geturl())
