#  Copyright (C) 2024 ASTRON (Netherlands Institute for Radio Astronomy)
#  SPDX-License-Identifier: Apache-2.0

# too-few-public-methods
# pylint: disable=R0903

"""
Models the structure of an HDF statistics file.
"""

import inspect
from collections.abc import Iterable
from typing import Any, Dict

from lofar_lotus.file_access import attribute
from numpy import ndarray


class StatisticsFileHeader:
    """
    Pythonic representation of the HDF statistics file header written by the statistics
    writer.
    """

    station_name: str = attribute(optional=True)
    """ Name of the station the statistics where recorded from """

    station_version: str = attribute()
    """ Lofar Station Control version """

    writer_version: str = attribute()
    """ Statistics Writer software version """

    data_type: str = attribute()
    """ Mode of the statistics writer (SST,XST,BST) """

    antenna_field: str = attribute(optional=True)
    """ Name of the antenna field """

    antenna_names: [str] = attribute(optional=True)
    """ Antenna names. """

    antenna_type: str = attribute(optional=True)
    """ The type of antenna in this field (LBA or HBA). """

    antenna_status: [str] = attribute(optional=True)
    """ The status of each antenna (BROKEN/OK/etc), as a string. """

    antenna_usage_mask: [bool] = attribute(optional=True)
    """ Whether each antenna would have been used. """

    antenna_reference_itrf: [str] = attribute(optional=True)
    """ Absolute reference position of each tile, in ITRF (XYZ). """

    pqr_to_etrs_rotation_matrix: [float] = attribute(optional=True)
    """ 3x3 rotation matrix to convert PQR coordinates to ETRS offsets. """

    antenna_to_sdp_mapping: [int] = attribute(optional=True)
    """ To which (FPGA, input) each antenna is mapped on SDP. """

    first_signal_input_index: int = attribute(optional=True)
    """ Internal signal index of the first input processed by the FPGA. """

    nr_signal_inputs: int = attribute(optional=True)
    """ Number of signal inputs processed by the FPGA. """

    fpga_firmware_version: [str] = attribute(optional=True)
    fpga_hardware_version: [str] = attribute(optional=True)

    rcu_pcb_id: [int] = attribute(optional=True)
    rcu_pcb_version: [str] = attribute(optional=True)

    calibration_table_version: [int] = attribute(optional=True)
    """ Version of the active calibration table. """

    calibration_table_md5: [str] = attribute(optional=True)
    """ MD5 sum of the HDF5 providing the active calibration table. """

    calibration_table_filename: [str] = attribute(optional=True)
    """ File names of the HDF5 providing the active calibration table. """

    def _get_attributes(self) -> list[Any]:
        return [
            a[0]
            for a in inspect.getmembers(__class__, lambda a: not inspect.isroutine(a))
            if not a[0].startswith("_")
        ]

    def _try_hash(self, obj: any) -> int:
        generated_hash = 0
        try:
            generated_hash = hash(obj)
        except TypeError:
            if isinstance(obj, Iterable):
                for elem in obj:
                    generated_hash = generated_hash ^ self._try_hash(elem)

        return generated_hash

    def __eq__(self, other):
        for attr in self._get_attributes():
            if not hasattr(self, attr) or not hasattr(other, attr):
                return False
            if getattr(self, attr) != getattr(other, attr):
                return False

        return True

    def __hash__(self):
        attributes = self._get_attributes()
        if len(attributes) == 0:
            return 0

        generated_hash = self._try_hash(getattr(self, attributes[0]))
        for attr in attributes[1:]:
            generated_hash = generated_hash ^ self._try_hash(getattr(self, attr))

        return generated_hash


class StatisticsSet(ndarray):
    """
    Pythonic representation of a dataset within an HDF statistics file for statistics.

    Contains the data array, and key packet information.
    """

    timestamp: str = attribute()
    """ Timestamp as ISO string. """

    integration_time: float = attribute(optional=True)
    """ Amount of samples accumulated for these statistics, in seconds. """

    observation_id: int = attribute(optional=True)
    """ Observation ID as reported by the payload. """

    frequency_band: [str] = attribute(optional=True)
    """ For which band the RECV and SDP are configured, f.e. 'LBA_10_90'. """

    clock: float = attribute(optional=True)
    """ Sample clock, in Hz. """

    rcu_dithering_on: [bool] = attribute(optional=True)
    """ Whether the RCU is dithering the signal. """

    rcu_dithering_frequency: [float] = attribute(optional=True)
    """ Dithering frequency. """

    tile_beam_pointing_directions: [str] = attribute(optional=True)
    """ Pointing direction of each HBA tile, f.e. 'J2000 (0deg, 0deg)'. """

    tile_beam_tracking_enabled: bool = attribute(optional=True)
    """ Whether the beam weights are periodically updated on the tile. """

    tile_element_power: [int] = attribute(optional=True)
    """ Whether each element in the tile was powered on. """


class StatisticsDataFile(Dict[str, StatisticsSet], StatisticsFileHeader):
    """
    Pythonic representation of the HDF statistics file written by the statistics
    writer.
    """


class BstStatisticsSet(StatisticsSet):
    """
    Pythonic representation of a dataset within an HDF statistics file for BSTs.
    """

    subbands: [int] = attribute()
    frequencies: [float] = attribute()

    digital_beam_pointing_directions: [str] = attribute(optional=True)
    """ Pointing direction of each beamlet in SDP, f.e. 'J2000 (0deg, 0deg)'. """

    digital_beam_tracking_enabled: bool = attribute(optional=True)
    """ Whether the SDP beam weights are periodically updated. """

    digital_beam_subbands: [int] = attribute(optional=True)
    """ Selected subband for each beamlet. """


class BstStatisticsDataFile(Dict[str, BstStatisticsSet], StatisticsFileHeader):
    """
    Pythonic representation of the HDF statistics file for BSTs written by
    the statistics writer.
    """


class SstStatisticsSet(StatisticsSet):
    """
    Pythonic representation of a dataset within an HDF statistics file for SSTs.
    """

    subbands: [int] = attribute()
    frequencies: [float] = attribute()


class SstStatisticsDataFile(Dict[str, SstStatisticsSet], StatisticsFileHeader):
    """
    Pythonic representation of the HDF statistics file for SSTs written by the
    statistics writer.
    """


class XstStatisticsSet(StatisticsSet):
    """
    Pythonic representation of a dataset within an HDF statistics file for XSTs.
    """

    subband: int = attribute()
    frequency: float = attribute()

    digital_beam_pointing_directions: [str] = attribute(optional=True)
    """ Pointing direction of each beamlet in SDP, f.e. 'J2000 (0deg, 0deg)'. """

    digital_beam_tracking_enabled: bool = attribute(optional=True)
    """ Whether the SDP beam weights are periodically updated. """

    digital_beam_subbands: [int] = attribute(optional=True)
    """ Selected subband for each beamlet. """


class XstStatisticsDataFile(Dict[str, XstStatisticsSet], StatisticsFileHeader):
    """
    Pythonic representation of the HDF statistics file for XSTs written by the
    statistics writer.
    """
