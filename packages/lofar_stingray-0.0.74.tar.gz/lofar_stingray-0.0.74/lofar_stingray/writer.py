#  Copyright (C) 2026 ASTRON (Netherlands Institute for Radio Astronomy)
#  SPDX-License-Identifier: Apache-2.0

"""Implements a storage class to write text data to a S3 backend in blocks"""

import io
import logging
import mimetypes
from datetime import datetime, timedelta, timezone
from typing import Optional

from minio import Minio

logger = logging.getLogger()


class Block(io.BytesIO):
    """Represents a block of data with a given duration"""

    def __init__(self, duration, *args, **kwargs):
        self.start = datetime.now(timezone.utc)
        self.duration = duration
        logger.info(
            "Start new block with start date %s and duration %s",
            self.start,
            self.duration,
        )
        super().__init__(*args, **kwargs)

    def expired(self):
        """Returns if the block duration is exhausted"""
        return self.start + self.duration < datetime.now(timezone.utc)


class Storage:
    """
    A storage class automatically slicing the data into blocks
    of n minutes and storing them on a S3 backend
    """

    def __init__(
        self,
        bucket: str,
        prefix: str,
        content_type,
        client: Minio,
        duration=timedelta(minutes=5),
    ):
        self._minio_client = client
        self.bucket = bucket
        self.content_type = content_type
        self.current_block: Optional[Block] = None
        self.prefix = prefix
        self.duration = duration
        self.num_bytes_written = 0
        self._init_bucket()

    def __enter__(self):
        self._start_new_block()
        return self

    def __exit__(self, *args):
        if self.current_block:
            block = self.current_block
            self._complete_current_block(block)
            self.current_block = None

    def _init_bucket(self):
        if not self._minio_client.bucket_exists(self.bucket):
            logger.debug("Create bucket %s", self.bucket)
            self._minio_client.make_bucket(self.bucket)

    def _start_new_block(self):
        self.current_block = Block(self.duration)

    def _complete_current_block(self, block):
        block.seek(io.SEEK_SET, 0)
        timestamp = datetime.now(timezone.utc)
        size = len(block.getvalue())

        if size == 0:
            logger.info("Discarding empty block %s", block.start)
            return

        logger.info("Write block %s", block.start)
        file_suffix = mimetypes.guess_extension(self.content_type)
        if file_suffix is None and self.content_type.startswith("application/avro"):
            file_suffix = ".avro"
        self._minio_client.put_object(
            self.bucket,
            f"{self.prefix}/{timestamp.year}/{timestamp.month:02d}/{timestamp.day:02d}/"
            f"{timestamp.isoformat()}{file_suffix}",
            block,
            size,
            content_type=self.content_type,
        )

    def flush_expired(self):
        if self.current_block.expired():
            logger.debug("Current block is expired, complete block and start new")
            block = self.current_block
            self.current_block = None
            self._complete_current_block(block)
            self._start_new_block()

    def write_data(self, data: bytes):
        """
        Write a line to the current block.
        If the block is expired it will be written to the next block.
        """
        self.flush_expired()

        self.current_block.write(data)
        self.num_bytes_written += len(data)
