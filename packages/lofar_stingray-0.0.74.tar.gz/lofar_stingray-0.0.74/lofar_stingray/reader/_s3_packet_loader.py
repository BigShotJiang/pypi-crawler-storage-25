#  Copyright (C) 2026 ASTRON (Netherlands Institute for Radio Astronomy)
#  SPDX-License-Identifier: Apache-2.0

"""
A storage class automatically slicing the data into blocks
of n minutes and storing them on a S3 backend
"""

import json
import logging
import time
from datetime import datetime, timedelta, timezone
from io import BytesIO
from typing import Any, Generator

import minio.datatypes
from avro.datafile import DataFileReader
from avro.io import DatumReader
from minio import Minio

logger = logging.getLogger()

# Interval with which to check the Minio store for data
MINIO_POLL_INTERVAL = timedelta(seconds=20)

# Delay with which blocks appear on S3 after being generated
# are the cumulation of:
#   - The max delay with which new lines are generated at the station.
#     This is the longest for metadata, with 10-minute intervals.
#   - The min delay with which data is written as JSON/AVRO on the station.
#     This is a 5-minute interval.
#   - The max delay with which data is copied to central.
#     This is a few seconds.
MAX_BLOCK_SYNC_DELAY = timedelta(minutes=15, seconds=10)


class S3PacketLoader:  # pylint: disable=too-few-public-methods
    """
    A storage class automatically slicing the data into blocks
    of n minutes and storing them on a S3 backend
    """

    def __init__(
        self,
        bucket: str,
        prefix: str,
        client: Minio,
        block_duration: timedelta = timedelta(minutes=5),
    ):
        self._minio_client = client
        self.bucket = bucket
        self.prefix = prefix.strip("/")
        self.block_duration = block_duration

    def _list_objects_after(
        self, timestamp: datetime
    ) -> Generator[minio.datatypes.Object, None, None]:
        """Return a list of objects that (should) contain packets of and after
        the given timestamp."""

        # NB: The timestamp in the filename is the time when the file was
        # completed, so after the last timestamp recorded in the file.
        return self._minio_client.list_objects(
            self.bucket,
            recursive=True,
            prefix=f"{self.prefix}",
            start_after=f"{self.prefix}/{timestamp.year}/{timestamp.month:02d}/"
            f"{timestamp.day:02d}/{timestamp.isoformat()}.avro",
        )

    def wait_for_filenames_after(self, timestamp: datetime) -> bool:
        """Wait until filenames with the given timestamp are on disk.

        Returns whether such files were found."""

        # if the packets are there, always return True
        if next(self._list_objects_after(timestamp), False):
            logger.info(
                "wait_for_filenames_after: Requested timestamp are available at startup"
            )
            return True

        # latest timestamp data can arrive
        max_arrival_time = timestamp + self.block_duration + MAX_BLOCK_SYNC_DELAY
        start_time = datetime.now(tz=timestamp.tzinfo)

        # wait for the end block to hit the disk, to make sure all data is there
        while (
            max_wait_time := max_arrival_time - datetime.now(tz=timestamp.tzinfo)
        ) > timedelta(0):
            logger.info(
                "wait_for_filenames_after: Requested timestamp are not available, "
                "will wait at most %s for them",
                max_wait_time,
            )
            # max_delay = max(timedelta(0), max_arrival_time - datetime.now())
            sleep_interval = min(max_wait_time, MINIO_POLL_INTERVAL)
            time.sleep(sleep_interval.total_seconds())

            if next(self._list_objects_after(timestamp), False):
                logger.info(
                    "wait_for_filenames_after: Requested timestamp appeared "
                    "after waiting %s",
                    datetime.now(tz=timestamp.tzinfo) - start_time,
                )
                return True

        logger.info(
            "wait_for_filenames_after: Requested timestamp are NOT available, "
            "even after waiting for %s",
            datetime.now(tz=timestamp.tzinfo) - start_time,
        )
        return False

    @staticmethod
    def read_as_json(stream):
        for line in stream:
            stripline = line.strip()
            if len(stripline) == 0:
                continue
            packet = json.loads(stripline)
            yield packet

    @staticmethod
    def read_as_avro(stream):
        # avro wants to seek, so we need to read the response into memory first
        buffer = BytesIO(stream.read())

        reader = DataFileReader(buffer, DatumReader())
        for obj in reader:
            yield obj

    def load_json(
        self, start: datetime, end: datetime, ts_field="timestamp"
    ) -> Generator[Any, None, None]:
        """Loads json lines from the S3 storage until no matching packets are found"""

        for obj in self._list_objects_after(start):
            packets = []
            response = None
            stop = False
            try:
                response = self._minio_client.get_object(self.bucket, obj.object_name)

                reader = (
                    self.read_as_json
                    if obj.object_name.endswith(".json")
                    else self.read_as_avro
                )

                for packet in reader(response):
                    packet_ts = datetime.fromisoformat(packet[ts_field])
                    packet_ts = packet_ts.replace(
                        tzinfo=packet_ts.tzinfo or timezone.utc
                    ).astimezone(timezone.utc)

                    if packet_ts < start:
                        continue
                    if packet_ts >= end:
                        stop = True
                        continue
                    packets.append(packet)
            finally:
                response.close()
                response.release_conn()

            if stop and len(packets) == 0:
                return

            yield from packets
