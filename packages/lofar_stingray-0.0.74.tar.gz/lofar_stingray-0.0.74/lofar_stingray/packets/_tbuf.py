#  Copyright (C) 2026 ASTRON (Netherlands Institute for Radio Astronomy)
#  SPDX-License-Identifier: Apache-2.0

# pylint: disable=too-many-instance-attributes,too-many-function-args,duplicate-code

"""TBuf raw transient data packet definitions"""

import struct
from datetime import datetime, timezone

import jax.numpy
import numpy
from lofar_lotus.instrument.constants import CLK_160_MHZ, CLK_200_MHZ, N_pol

from ._base import _BasePacketHeader
from ._tbuf_unpacking import unpack_raw_tbuf_payload
from ._utils import get_bit_value


class TBufHeader(_BasePacketHeader):
    """Models a TBuf UDP packet header from SDP.

    Packets are expected to be UDP payload only (so no Ethernet/IP/UDP headers).

    The following additional fields are exposed as properties & functions.

    antenna_input_index

        The antenna input index (0-96)

    nof_raw_data_per_packet

        The number of samples per packet.

    raw_sequence_number

        (Integer) timestamp of the data, in sampling intervals since 1970

    sample_width

        Width of a single sample, in bits

    antenna_band_index

        antenna type. 0 = low band, 1 = high band.

    nyquist_zone_index

        nyquist zone of filter

            - 0 =           0 -- 1/2 * t_adc Hz (low band),
            - 1 = 1/2 * t_adc -- t_adc Hz       (high band),
            - 2 =       t_adc -- 3/2 * t_adc Hz (high band).

    t_adc

        sampling clock. 0 = 160 MHz, 1 = 200 MHz.

    f_adc

        sampling frequency, in Hz (160_000_000 or 200_000_000)
    """

    # format string for the header, see unpack below
    HEADER_FORMAT = ">cBIHHxxxBHQ"
    HEADER_SIZE = struct.calcsize(HEADER_FORMAT)

    # location of the raw sequence number in the header,
    # for direct extraction within jax routines.
    RAW_SEQUENCE_NUMBER = slice(16, 24)

    def __init__(self, packet: bytes):
        self.antenna_input_index: int = 0
        self.antenna_band_index: int = 0
        self.nyquist_zone_index: int = 0
        self.t_adc: int = 0
        self.nof_raw_data_per_packet: int = 0
        self.sample_width: int = 0
        self.raw_sequence_number: int = 0
        super().__init__(packet)

    def __str__(self):
        return (
            f"TBufHeader("
            f"station={self.station_id}, field={self.antenna_field_name}, "
            f"gn_index={self.gn_index}, "
            f"timestamp={self.timestamp.strftime('%FT%T')}"
        )

    def unpack(self):
        """Unpack the packet into properties of this object."""

        # unpack fields
        try:
            (
                self.marker_raw,
                self.version_id,
                self.observation_id,
                self.station_info,
                self.source_info,
                self.antenna_input_index,
                self.nof_raw_data_per_packet,
                self.raw_sequence_number,
            ) = struct.unpack(self.HEADER_FORMAT, self.packet[: self.HEADER_SIZE])
        except struct.error as ex:
            raise ValueError("Error parsing beamlet packet") from ex

    def valid_markers(self):
        return [b"r"]

    def unpack_source_info(self):
        """Unpack the source_info field into properties of this object."""

        self.gn_index = get_bit_value(self.source_info, 0, 4)
        self.sample_width = get_bit_value(self.source_info, 8, 11) or 16
        self.t_adc = get_bit_value(self.source_info, 12)
        self.nyquist_zone_index = get_bit_value(self.source_info, 13, 14)
        self.antenna_band_index = get_bit_value(self.source_info, 15)

    @property
    def f_adc(self) -> int:
        """Returns the ADC sampling frequency, in Hz"""

        if self.t_adc == 0:
            return CLK_160_MHZ
        if self.t_adc == 1:
            return CLK_200_MHZ
        return None

    def expected_size(self) -> int:
        """The size this packet should be (header + payload), extracted from header."""

        return self.HEADER_SIZE + self.nof_statistics_per_packet

    @property
    def timestamp(self) -> datetime:
        """Returns the timestamp of the data in this packet.

        :return: datetime from raw_sequence_number and sampling frequency or
                 datetime.max if the timestamp cannot be represented in python
        """

        try:
            return datetime.fromtimestamp(
                self.raw_sequence_number / self.f_adc, timezone.utc
            )
        except ValueError:
            # Let's not barf anytime we want to print a header
            return datetime.max

    @property
    def nof_statistics_per_packet(self) -> int:
        """Compute number of statistics per packet."""

        return self.nof_raw_data_per_packet * N_pol * self.sample_width // 8

    def __iter__(self):
        """Return all the header fields as a dict."""
        for key, value in super().__iter__():
            if key == "source_info":
                yield key, {
                    **value,
                    "sample_width": self.sample_width,
                    "t_adc": self.t_adc,
                    "nyquist_zone_index": self.nyquist_zone_index,
                    "antenna_band_index": self.antenna_band_index,
                }
            else:
                yield key, value
        yield "antenna_input_index", self.antenna_input_index
        yield "nof_raw_data_per_packet", self.nof_raw_data_per_packet
        yield "raw_sequence_number", self.raw_sequence_number


class TBufPacket:
    """Models a TBuf UDP packet from SDP.

    Packets are expected to be UDP payload only (so no Ethernet/IP/UDP headers).

    """

    def __init__(self, header: TBufHeader, payload: bytes):
        self._header: TBufHeader = header
        self.payload_data: bytes = payload

    @staticmethod
    def parse_packet(packet_data: bytes) -> "TBufPacket":
        """Parses bytes into a TBufPacket"""
        header = TBufHeader(packet_data[0 : TBufHeader.HEADER_SIZE])
        return TBufPacket(header, packet_data[TBufHeader.HEADER_SIZE :])

    @property
    def raw(self) -> bytes:
        """Returns the raw packet bytes"""
        return self._header.raw + self.payload_data

    @property
    def header(self) -> TBufHeader:
        """Returns the packet header"""
        return self._header

    def payload(self) -> jax.numpy.ndarray:
        """Returns the payload as numpy array,
        given the proper shape and data format."""
        return unpack_raw_tbuf_payload(
            jax.numpy.array(numpy.frombuffer(self.payload_data, dtype=numpy.uint8))
        )
