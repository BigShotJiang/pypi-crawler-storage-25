#  Copyright (C) 2023 ASTRON (Netherlands Institute for Radio Astronomy)
#  SPDX-License-Identifier: Apache-2.0

# pylint: disable=too-many-instance-attributes

"""Base classes for package definitions"""

from abc import abstractmethod
from datetime import datetime, timezone
from typing import TypeVar

from ._utils import get_bit_value

N_COMPLEX = 2

Subfields = TypeVar("Subfields")


class _BasePacketHeader:
    """Models a UDP packet from SDP.

    Packets are expected to be UDP payload only (so no Ethernet/IP/UDP headers).

    The following fields are exposed as properties & functions. The _raw fields come
    directly from the packet, and have more user-friendly alternatives for
    interpretation:

    marker_raw

        packet marker as byte.

    marker

        packet marker as character. 'S' = SST, 'X' = XST, 'B' = BST

    version_id

        packet format version.

    observation_id

        observation identifier.

    station_info

        bit field with station information, encoding several other properties.

    station_id

        station identifier.

    antenna_field_index

        antenna field id. 0 = LBA/HBA/HBA0, 1 = HBA1

    source_info

        bit field with input information, encoding several other properties.

    gn_index

        global index of FPGA that emitted this packet.

    timestamp

        timestamp of the data, as a datetime object.

    """

    def __init__(self, packet: bytes):
        self.version_id: int = 0
        self.antenna_field_index: int = 0
        self.station_id: int = 0
        self.source_info: int = 0
        # self.source_info 5-8 are reserved
        self.gn_index: int = 0
        self.marker_raw: bytes = bytes()
        self.station_info: int = 0
        self.observation_id: int = 0

        self.packet = packet

        self.unpack()
        self.unpack_station_info()
        self.unpack_source_info()

        # Only parse valid statistics packets from SDP, reject everything else
        if self.marker_raw not in self.valid_markers():
            raise ValueError(
                f"Invalid packet of type {self.__class__.__name__}: packet marker"
                f"(first byte) is {self.marker}, "
                f"not one of {self.valid_markers()}."
            )

    def __str__(self):
        return (
            f"_BasePacketHeader(marker={self.marker}, "
            f"station={self.station_id}, field={self.antenna_field_name}, "
            f"gn_index={self.gn_index}, "
            f"timestamp={self.timestamp.strftime('%FT%T')}, "
            f"payload_error={self.payload_error})"
        )

    @property
    def raw(self) -> bytes:
        """Returns the raw packet header bytes"""
        return self.packet

    @abstractmethod
    def unpack(self):
        """Unpack the packet bytes struct"""

    @abstractmethod
    def valid_markers(self):
        """Returns the valid packet markers"""

    def unpack_station_info(self):
        """Unpack the station_info field into properties of this object."""

        self.station_id = get_bit_value(self.station_info, 0, 9)
        self.antenna_field_index = get_bit_value(self.station_info, 10, 15)

    def unpack_source_info(self):
        """Unpack the source_info field into properties of this object."""
        self.gn_index = get_bit_value(self.source_info, 0, 4)

    @abstractmethod
    def expected_size(self) -> int:
        """Determine packet size (header + payload) from the header"""

        # the generic header does not contain enough information to determine the
        # payload size
        raise NotImplementedError

    def size(self) -> int:
        """The actual size of this packet."""

        return len(self.packet)

    @property
    def marker(self) -> str:
        """Return the type of statistic:

        - 'S' = SST
        - 'B' = BST
        - 'X' = XST
        - 'b' = beamlet
        - 'r' = transient raw data (TBuf)
        """

        try:
            return self.marker_raw.decode("ascii")
        except UnicodeDecodeError:
            # non-ascii (>127) character, return as binary
            #
            # this is typically not visible to the user, as these packets are not SDP
            # statistics packets, which the constructor will refuse to accept.
            return str()

    @property
    def antenna_field_name(self) -> str:
        """Returns the name of the antenna field as one of LBA-#0, HBA-#0, HBA-#1."""

        antenna_band = ["LBA", "HBA"][self.antenna_band_index]

        # NB: This returns HBA-#0 for both HBA0 and HBA
        return f"{antenna_band}-#{self.antenna_field_index}"

    @property
    def timestamp(self) -> datetime:
        """Returns the timestamp of the data in this packet.

        :return: datetime from block_serial_number and block period but
                 datetime.min if the block_serial_number in the packet is not set
                 datetime.max if the timestamp cannot be represented in python
        """

        try:
            return datetime.fromtimestamp(
                self.block_serial_number * self.block_period, timezone.utc
            )
        except ValueError:
            # Let's not barf anytime we want to print a header
            return datetime.max

    def __iter__(self):
        """Return all the header fields as a dict."""
        yield "marker", self.marker
        yield "marker_raw", self.marker_raw[0]
        yield "version_id", self.version_id
        yield "observation_id", self.observation_id
        yield "station_id", self.station_id
        yield (
            "station_info",
            {
                "_raw": self.station_info,
                "station_id": self.station_id,
                "antenna_field_index": self.antenna_field_index,
            },
        )

        yield (
            "source_info",
            {
                "_raw": self.source_info,
                "gn_index": self.gn_index,
            },
        )
        yield "timestamp", self.timestamp


class _BeamPacketHeader(_BasePacketHeader):
    """Models a beamlet UDP packet from SDP.

    Packets are expected to be UDP payload only (so no Ethernet/IP/UDP headers).

    The following additional fields are exposed as properties & functions.

    block_period_raw

        block period, in nanoseconds.

    block_period

        block period, in seconds.

    block_serial_number

        timestamp of the data, in block periods since 1970.

    """

    def __init__(self, packet):
        self.block_serial_number: int = 0
        self.block_period_raw: int = 0
        super().__init__(packet)

    @property
    def block_period(self) -> float:
        """Return the block period, in seconds."""

        return self.block_period_raw / 1e9

    def __iter__(self):
        for key, value in super().__iter__():
            yield key, value

        yield "block_period_raw", self.block_period_raw
        yield "block_period", self.block_period
        yield "block_serial_number", self.block_serial_number
