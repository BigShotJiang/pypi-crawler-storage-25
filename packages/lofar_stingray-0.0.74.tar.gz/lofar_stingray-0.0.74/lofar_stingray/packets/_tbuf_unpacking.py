#  Copyright (C) 2026 ASTRON (Netherlands Institute for Radio Astronomy)
#  SPDX-License-Identifier: Apache-2.0

"""Code to unpack tightly-packed TBuf packets"""

import jax
import jax.numpy
from lofar_lotus.instrument.constants import N_pol


@jax.jit()
def unpack_raw_tbuf_payload(data: jax.numpy.ndarray) -> jax.numpy.ndarray:
    """
    Unpack tightly-packed transient-buffer bytes into numpy int16 array

    Parameters
    ----------
    data : jax.numpy.ndarray, shape (7000,), dtype=uint8
        The transient buffer payload (7000 bytes)

    Returns
    -------
    jax.numpy.ndarray, shape (2000, 2), dtype=int16
        The extracted samples of either polarisation

    Notes
    -----
    The raw transient-buffer (TB) data consists of 7000 bytes
    of tightly-packed 14-bit waveform data. This function takes
    the raw bytes as an input, and extracts the 14-bit data by
    treating sets of 4 samples (7 bytes), and applying appropriate
    shifting / masking to return the 2000 x 2 (samples x polarizations).
    """

    # Reshape into blocks of 7 bytes, which exactly hold
    # 4x 14-bit samples.
    blocks = data.reshape(-1, 7).astype(jax.numpy.int16)

    b1 = blocks[:, 0]
    b2 = blocks[:, 1]
    b3 = blocks[:, 2]
    b4 = blocks[:, 3]
    b5 = blocks[:, 4]
    b6 = blocks[:, 5]
    b7 = blocks[:, 6]

    # Extract 14-bit values (vectorized)
    val1 = (b1 << 6) | (b2 >> 2)
    val2 = ((b2 & 0x03) << 12) | (b3 << 4) | (b4 >> 4)
    val3 = ((b4 & 0x0F) << 10) | (b5 << 2) | (b6 >> 6)
    val4 = ((b6 & 0x3F) << 8) | b7

    # Stack into shape (1000, 4)
    vals = jax.numpy.stack([val1, val2, val3, val4], axis=1)

    # Sign correction for 14-bit signed values
    vals = jax.numpy.where(vals >= 8192, vals - 16384, vals)

    # Reshape to (2000, 2)
    return vals.reshape(-1, N_pol).astype(jax.numpy.int16)
