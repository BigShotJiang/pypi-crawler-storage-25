#  Copyright (C) 2026 ASTRON (Netherlands Institute for Radio Astronomy)
#  SPDX-License-Identifier: Apache-2.0
from importlib.resources import files
from urllib.parse import parse_qs, urlparse

import avro

from ._avro import AvroDataFormat
from ._base import DataFormat
from ._json import JsonDataFormat
from ._statistic import StatisticDataFormat


def create(uri: str, stream, writer: bool) -> DataFormat:
    parsed_url = urlparse(uri)
    content_type = parse_qs(parsed_url.query)["content-type"][0]

    match content_type:
        case "application/json":
            return JsonDataFormat(stream)
        case "application/lofar.statistic":
            return StatisticDataFormat(stream)
        case content_type if content_type.startswith("application/avro"):
            _, schema_name = content_type.split(".")
            schema = avro.schema.parse(
                files(__package__)
                .joinpath("avro_schemas", f"{schema_name}_schema.avsc")
                .open("r")
                .read()
            )
            return AvroDataFormat(stream, schema, writer)
        case _:
            raise ValueError(f"Provided content-type '{content_type}' is not supported")
