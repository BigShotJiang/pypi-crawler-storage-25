#  Copyright (C) 2026 ASTRON (Netherlands Institute for Radio Astronomy)
#  SPDX-License-Identifier: Apache-2.0
from abc import ABC, abstractmethod
from typing import Iterable


class DataStream:
    pass


class DataFormat(ABC):
    def __init__(self, stream):
        self._stream = stream

    @abstractmethod
    def read(self) -> Iterable:
        pass

    @abstractmethod
    def write(self, data):
        pass
