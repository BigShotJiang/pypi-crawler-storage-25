#  Copyright (C) 2026 ASTRON (Netherlands Institute for Radio Astronomy)
#  SPDX-License-Identifier: Apache-2.0
from argparse import ArgumentTypeError

from lofar_stingray.packets import StatisticsHeader, StatisticsPacket
from lofar_stingray.streams.data_formats import DataFormat


class StatisticDataFormat(DataFormat):
    HEADER_LENGTH = 32

    def write(self, data):
        self._stream.write_data(self.pack(data))

    def read(self):
        try:
            while True:
                yield self.get_packet(self._stream)
        except EOFError:
            return

    def get_packet(self, stream) -> StatisticsPacket:
        """Read exactly one statistics packet from the stream."""

        # read only the header, to compute the size of the packet
        header_data = stream.read_data(self.HEADER_LENGTH)
        header = StatisticsHeader(header_data)

        # read the rest of the packet (payload)
        payload_length = header.expected_size() - len(header_data)
        payload = stream.read_data(payload_length)

        # add payload to the header, and return the full packet
        return StatisticsPacket(header, payload)

    def pack(self, packet):
        if not hasattr(packet, "raw"):
            raise ArgumentTypeError("Can not repack binary packets")
        return packet.raw
