#  Copyright (C) 2026 ASTRON (Netherlands Institute for Radio Astronomy)
#  SPDX-License-Identifier: Apache-2.0
from typing import Iterable

from avro.datafile import DataFileWriter
from avro.io import DatumWriter

from lofar_stingray.streams._s3 import StorageStream
from lofar_stingray.streams.data_formats import DataFormat


class AvroDataFormat(DataFormat):
    def __init__(self, stream, schema=None, writer=False):
        super().__init__(stream)
        codec = "zstandard"
        self.schema = schema
        if writer:
            if isinstance(self._stream, StorageStream):
                self.writer = DataFileWriter(
                    self._stream.current_block, DatumWriter(), schema, codec
                )
                orig_ccb = self._stream._complete_current_block

                def new_complete_current_block(block):
                    self.writer.flush()
                    orig_ccb(block)

                self._stream._complete_current_block = new_complete_current_block
                orig_snb = self._stream._start_new_block

                def new_start_new_block():
                    orig_snb()
                    self.writer = DataFileWriter(
                        self._stream.current_block, DatumWriter(), schema, codec
                    )

                self._stream._start_new_block = new_start_new_block
            else:
                self.closed = False
                self.writer = DataFileWriter(self._stream, DatumWriter(), schema, codec)
                close_method = self._stream.close

                def new_close():
                    if not self.closed:
                        self.closed = True
                        self.writer.close()
                    close_method()

                self._stream.close = new_close
        else:
            raise NotImplementedError()

    def write(self, packet):
        if isinstance(self._stream, StorageStream):
            self._stream.flush_expired()
        self.writer.append(packet)

    def read(self) -> Iterable:
        raise NotImplementedError()
