#  Copyright (C) 2026 ASTRON (Netherlands Institute for Radio Astronomy)
#  SPDX-License-Identifier: Apache-2.0
import json

from ...utils import StingrayJsonEncoder
from ._base import DataFormat


class JsonDataFormat(DataFormat):
    def write(self, data):
        self._stream.write_data(self.pack(data))

    def read(self):
        while data := self._stream.get_json():
            yield data

    def pack(self, packet):
        return json.dumps(packet, cls=StingrayJsonEncoder).encode() + b"\n"
