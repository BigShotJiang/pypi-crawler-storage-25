#  Copyright (C) 2026 ASTRON (Netherlands Institute for Radio Astronomy)
#  SPDX-License-Identifier: Apache-2.0

"""FileStream"""

import os

from ._stream import Stream


class FileStream(Stream):
    """File receiver"""

    def __init__(self, filename, mode="r"):
        self.filename = filename
        self.fileno = None
        self.mode = mode
        super().__init__()

    def open(self):
        mode = 0
        if "r" in self.mode:
            mode |= os.O_RDONLY
        if "w" in self.mode:
            mode |= os.O_WRONLY | os.O_CREAT
        self.fileno = os.open(self.filename, mode)

    def close(self):
        if self.fileno:
            os.close(self.fileno)
            self.fileno = None

    @property
    def fdesc(self):
        return self.fileno
