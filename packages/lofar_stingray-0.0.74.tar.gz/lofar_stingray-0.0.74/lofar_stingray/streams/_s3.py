#  Copyright (C) 2026 ASTRON (Netherlands Institute for Radio Astronomy)
#  SPDX-License-Identifier: Apache-2.0

"""StorageStream"""

import json

from lofar_stingray.packets import StatisticsPacket
from lofar_stingray.utils import StingrayJsonEncoder
from lofar_stingray.writer import Storage


class StorageStream(Storage):
    """File receiver"""

    def put_packet(self, packet: StatisticsPacket):
        """Emit a packet."""

        # For most streams, this is in binary
        self.put_dict(dict(packet))

    def put_dict(self, data: dict):
        """Write a line of text to the stream."""
        self.write_data(json.dumps(data, cls=StingrayJsonEncoder).encode() + b"\n")

    def close(self):
        pass

    def write(self, data: bytes):
        self.write_data(data)
