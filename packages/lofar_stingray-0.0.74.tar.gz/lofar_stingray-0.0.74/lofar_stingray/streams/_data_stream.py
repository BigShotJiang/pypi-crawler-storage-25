#  Copyright (C) 2026 ASTRON (Netherlands Institute for Radio Astronomy)
#  SPDX-License-Identifier: Apache-2.0

import lofar_stingray.streams
import lofar_stingray.streams.data_formats


class DataStream:
    def __init__(self, uri: str, writer=False, minio_client=None):
        self.uri = uri
        self.writer = writer
        self.stream = lofar_stingray.streams.create(uri, writer, minio_client)
        self.with_stream = None

    def __enter__(self):
        """Open the stream as part of a context manager."""
        self.with_stream = self.stream.__enter__()
        self.data_format = lofar_stingray.streams.data_formats.create(
            self.uri, self.with_stream, self.writer
        )
        return self

    def __exit__(self, type_, value, exc):
        """Close the stream as part of a context manager."""
        if self.with_stream:
            self.with_stream.__exit__(type_, value, exc)
        return False

    def __del__(self):
        # Make sure we don't leak
        del self.stream

    def __iter__(self):
        """Iterates over all packets in the stream."""
        return self.data_format.read()

    def write(self, packet):
        self.data_format.write(packet)

    @property
    def num_bytes_read(self):
        return self.with_stream.num_bytes_read

    @property
    def num_bytes_written(self):
        return self.with_stream.num_bytes_written
