#  Copyright (C) 2026 ASTRON (Netherlands Institute for Radio Astronomy)
#  SPDX-License-Identifier: Apache-2.0

"""Create receiver based on uri"""

from typing import Optional
from urllib.parse import parse_qs, urlsplit

from minio import Minio

from ._file import FileStream
from ._s3 import StorageStream
from ._tcp import TCPStream
from ._udp import UDPStream
from ._zmq import ZeroMQReceiver


def create(uri, writer=False, minio_client: Optional[Minio] = None):
    """Create a Stream based on the given URI"""
    parsed = urlsplit(uri)
    if parsed.scheme == "tcp":
        return TCPStream(parsed.hostname, parsed.port)
    if parsed.scheme == "udp":
        return UDPStream(parsed.hostname, parsed.port, writer)
    if parsed.scheme == "file":
        return FileStream(parsed.path, "wb" if writer else "rb")
    if parsed.scheme == "s3":
        content_type = parse_qs(parsed.query)["content-type"][0]
        if "." in content_type:
            content_type, _ = content_type.split(".", 2)
        return StorageStream(parsed.netloc, parsed.path, content_type, minio_client)
    if parsed.scheme.startswith("zmq"):
        if writer:
            raise ValueError(f"Provided uri '{uri}' is not supported for writing")
        return ZeroMQReceiver(
            f"{parsed.scheme[4:]}://{parsed.netloc}", [parsed.path[1:]]
        )

    raise ValueError(f"Provided uri '{uri}' is not supported")
