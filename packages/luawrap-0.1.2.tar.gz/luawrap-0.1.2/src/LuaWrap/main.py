"""
LuaWrap core - internal implementation.
Import from the top-level package instead:
    from luawrap import lua, run_lua, lua_function, LuaBlock
"""

from functools import wraps
from typing import Optional

try:
    from lupa import LuaRuntime
except ImportError:
    raise ImportError(
        "\n[LuaWrap] The 'lupa' package is not installed!\n"
        "Fix it by running:\n"
        "    poetry add lupa\n"
    )


_runtime: Optional[LuaRuntime] = None


def _get_runtime() -> LuaRuntime:
    """Get (or create) the shared Lua runtime."""
    global _runtime
    if _runtime is None:
        _runtime = LuaRuntime(unpack_returned_tuples=True)
    return _runtime


def run_lua(code: str) -> object:
    """
    Run a string of Lua code and return the result.

    Example:
        run_lua("print('Hello from Lua!')")
        result = run_lua("return 2 + 2")
        print(result)  # 4
    """
    rt = _get_runtime()
    return rt.execute(code)


def lua(code: str) -> object:
    """
    Shorthand for run_lua(). Run Lua code from a Python string.

    Example:
        lua("print('Hello!')")
    """
    return run_lua(code)


def lua_function(func):
    """
    Decorator that turns a Python function into a Lua runner.
    The function should return a string of Lua code when called.

    Example:
        @lua_function
        def say_hello():
            return "print('Hello from a Lua function!')"

        say_hello()
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        lua_code = func(*args, **kwargs)
        if not isinstance(lua_code, str):
            raise TypeError(
                "[LuaWrap] @lua_function '{}' must return a string of Lua code, got {} instead.".format(
                    func.__name__, type(lua_code).__name__
                )
            )
        return run_lua(lua_code)
    return wrapper


class LuaBlock:
    """
    Context manager for writing a block of Lua code.
    Set lb.code inside the with-block and it runs automatically on exit.

    Example:
        with LuaBlock() as lb:
            lb.code = "print('Runs when the block exits!')"
    """

    def __init__(self):
        self.code: str = ""

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is None and self.code.strip():
            run_lua(self.code)
        return False