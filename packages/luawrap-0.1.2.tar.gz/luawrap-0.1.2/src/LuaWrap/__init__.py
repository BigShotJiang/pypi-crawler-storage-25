"""
LuaWrap - Write and run Lua code directly from Python files!

Import:
    from luawrap import lua, run_lua, lua_function, LuaBlock
"""

from .main import lua, run_lua, lua_function, LuaBlock

__version__ = "0.1.0"
__all__ = ["lua", "run_lua", "lua_function", "LuaBlock"]