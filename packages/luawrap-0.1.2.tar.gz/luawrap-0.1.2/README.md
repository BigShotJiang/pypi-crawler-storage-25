# LuaWrap

Write and run Lua code directly inside your Python files — no separate Lua install needed!

## Installation

```bash
poetry add lupa
poetry install
```

## Usage

```python
from LuaWrap import lua, run_lua, lua_function, LuaBlock

# Run Lua directly
lua("print('Hello from Lua!')")

# Get a return value back in Python
result = run_lua("return 2 + 2")
print(result)  # 4

# Decorator style
@lua_function
def my_script():
    return "print('I am a Lua function!')"

my_script()

# Context manager style
with LuaBlock() as lb:
    lb.code = "print('Runs when the block exits!')"
```

## API

| Function | Description |
|---|---|
| `lua(code)` | Run a Lua string |
| `run_lua(code)` | Same as `lua()`, alias |
| `@lua_function` | Decorator — function returns Lua code as a string |
| `LuaBlock` | Context manager — set `lb.code` to your Lua string |