"""Tests for Message model."""

from csrd.models import Message


class TestMessage:
    def test_create(self):
        m = Message(detail="hello")
        assert m.detail == "hello"

    def test_camel_case(self):
        """Message inherits BaseModel — verify aliasing works."""
        dumped = Message(detail="test").model_dump(by_alias=True)
        assert "detail" in dumped
