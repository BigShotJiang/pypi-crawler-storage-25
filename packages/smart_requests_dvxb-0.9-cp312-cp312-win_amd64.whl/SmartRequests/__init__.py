# __init__.py
from .session import SmartSession as smart_session

__author_email__ = "dharmik.vadher@xbyte.io"
__maintainer_email__ = "dharmik.vadher@xbyte.io"
__author__ = "dharmik.vadher@xbyte.io"
__maintainer__ = "dharmik.vadher@xbyte.io"

__all__ = ["smart_session"]
