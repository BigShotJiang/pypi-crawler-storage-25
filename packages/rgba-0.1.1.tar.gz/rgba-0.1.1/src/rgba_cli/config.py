"""rgba CLI — runtime config + on-disk credentials.

Two responsibilities:

  1. Resolve the API base URL (env override → Modal prod default).
  2. Persist the access/refresh token pair in `~/.rgba/credentials`
     with strict 0600 permissions so other unix users can't read it.

The credentials file is a single JSON document, written atomically via
a tempfile+rename so a crash mid-write can't leave a half-written file
on disk. Bumped on every refresh.
"""

from __future__ import annotations

import json
import os
import stat
import tempfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional

# Default points at the deployed Modal agent. Override at runtime with
# RGBA_API_URL=http://127.0.0.1:8001 for local development.
DEFAULT_API_URL = "https://lemontree-media-llc--rgba-agent-agent-app.modal.run"


def api_url() -> str:
    return os.environ.get("RGBA_API_URL", DEFAULT_API_URL).rstrip("/")


def config_dir() -> Path:
    override = os.environ.get("RGBA_CONFIG_DIR")
    if override:
        return Path(override)
    return Path.home() / ".rgba"


def credentials_path() -> Path:
    return config_dir() / "credentials"


@dataclass
class Credentials:
    access_token: str
    refresh_token: str
    expires_at: str
    refresh_expires_at: str
    api_url: str

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "Credentials":
        return cls(
            access_token=data["access_token"],
            refresh_token=data["refresh_token"],
            expires_at=data.get("expires_at", ""),
            refresh_expires_at=data.get("refresh_expires_at", ""),
            api_url=data.get("api_url", DEFAULT_API_URL),
        )


def load_credentials() -> Optional[Credentials]:
    path = credentials_path()
    if not path.exists():
        return None
    try:
        with path.open("r") as f:
            return Credentials.from_dict(json.load(f))
    except (OSError, json.JSONDecodeError, KeyError):
        # Corrupt or unreadable — treat as logged-out. The caller will
        # prompt to re-login rather than crash.
        return None


def save_credentials(creds: Credentials) -> None:
    """Atomic 0600 write into ~/.rgba/credentials."""
    config_dir().mkdir(parents=True, exist_ok=True)
    target = credentials_path()
    # NamedTemporaryFile in the same dir → rename is atomic on POSIX.
    fd, tmp_path = tempfile.mkstemp(
        prefix=".credentials.", dir=str(config_dir()), text=True
    )
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(creds.to_dict(), f, indent=2)
        os.chmod(tmp_path, stat.S_IRUSR | stat.S_IWUSR)  # 0600
        os.replace(tmp_path, target)
    except Exception:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


def clear_credentials() -> bool:
    """Delete ~/.rgba/credentials. Returns True if a file was removed."""
    path = credentials_path()
    if not path.exists():
        return False
    try:
        path.unlink()
        return True
    except OSError:
        return False
