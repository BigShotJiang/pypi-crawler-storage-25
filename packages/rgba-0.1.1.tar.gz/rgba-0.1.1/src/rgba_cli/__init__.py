"""rgba — command-line interface for the RGBA API."""

__version__ = "0.1.1"
