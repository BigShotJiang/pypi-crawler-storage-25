"""Thin HTTPS client for the RGBA API.

Layers:

  * ``ApiError`` — exception type carrying an HTTP status + a parsed
    error body. The CLI command layer prints this as ``rgba: <msg>``
    and exits non-zero.

  * ``RawClient`` — context-managed httpx client that knows the base
    URL and timeouts but nothing about auth.

  * ``Client`` — auth-aware façade. Reads/writes credentials, attaches
    the bearer header, and transparently refreshes access tokens on
    401 once per request. If the refresh also fails, raises
    ``NotLoggedIn`` so the CLI can prompt the user to re-login.

Long-lived operations (job polling, device-flow polling) live as helper
methods that loop with sleep — they don't need an event loop, the CLI
is synchronous by design.
"""

from __future__ import annotations

import json
import time
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any, Iterator, Optional

import httpx

from .config import Credentials, api_url, load_credentials, save_credentials


# Generous read timeout — single Higgsfield image gens take 30-90s,
# `--wait` batches can run several minutes inline, and video gens
# (Seedance / Kling 3.0) can take 10-20 min. Default to 1900s so the
# CLI outlasts the backend's AGENT_TOOL_TIMEOUT wall (1800s on prd)
# by a safety margin. Callers can override per-action with
# `--wait-timeout <seconds>` on `rgba sdk`. Connect timeout stays
# short so a wrong RGBA_API_URL fails fast.
DEFAULT_TIMEOUT_SECONDS = 1900.0
DEFAULT_TIMEOUT = httpx.Timeout(DEFAULT_TIMEOUT_SECONDS, connect=15.0)


class ApiError(Exception):
    """HTTP-shaped error from the RGBA API."""

    def __init__(self, status: int, body: Any):
        self.status = status
        self.body = body
        super().__init__(self._human(body))

    @staticmethod
    def _human(body: Any) -> str:
        if isinstance(body, dict):
            detail = body.get("detail", body)
            if isinstance(detail, dict):
                desc = detail.get("error_description") or detail.get("error")
                if desc:
                    return str(desc)
            if isinstance(detail, str):
                return detail
        return str(body)


class NotLoggedIn(Exception):
    """No usable credentials on disk — caller should run `rgba auth login`."""


# ---------------------------------------------------------------------------
# Raw (un-authed) client
# ---------------------------------------------------------------------------


@contextmanager
def raw_client(base: Optional[str] = None) -> Iterator[httpx.Client]:
    base_url = (base or api_url()).rstrip("/")
    with httpx.Client(base_url=base_url, timeout=DEFAULT_TIMEOUT) as cx:
        yield cx


def _decode(resp: httpx.Response) -> Any:
    if not resp.content:
        return None
    try:
        return resp.json()
    except ValueError:
        return resp.text


def _check(resp: httpx.Response) -> Any:
    if resp.status_code >= 400:
        raise ApiError(resp.status_code, _decode(resp))
    return _decode(resp)


# ---------------------------------------------------------------------------
# Device-flow helpers (no auth required)
# ---------------------------------------------------------------------------


@dataclass
class DeviceStart:
    device_code: str
    user_code: str
    verification_uri: str
    verification_uri_complete: str
    interval: int
    expires_in: int


def device_flow_start() -> DeviceStart:
    with raw_client() as cx:
        data = _check(cx.post("/cli/auth/device/start"))
    # ``verification_uri_complete`` is RFC 8628 §3.3.1 and was added to the
    # RGBA backend in a later release. Synthesize it client-side when the
    # server doesn't return it so older agents stay supported.
    if "verification_uri_complete" not in data:
        base = data["verification_uri"]
        sep = "&" if "?" in base else "?"
        data = {**data, "verification_uri_complete": f"{base}{sep}user_code={data['user_code']}"}
    return DeviceStart(**{k: data[k] for k in DeviceStart.__dataclass_fields__})


def device_flow_poll_once(device_code: str) -> Optional[dict]:
    """Single poll. Returns token-pair dict on success, None if pending.

    Raises ``ApiError`` on terminal errors (expired, consumed, …) so the
    caller can stop polling.
    """
    with raw_client() as cx:
        resp = cx.get(
            "/cli/auth/device/poll", params={"device_code": device_code}
        )
    if resp.status_code == 200:
        return resp.json()
    if resp.status_code == 400:
        body = _decode(resp)
        err = (body.get("detail") or {}).get("error") if isinstance(body, dict) else None
        if err == "authorization_pending":
            return None
        raise ApiError(resp.status_code, body)
    raise ApiError(resp.status_code, _decode(resp))


def device_flow_wait(
    device_code: str, interval: int, deadline_s: int = 600
) -> dict:
    """Block until tokens are issued or the device code expires.

    interval is the server-suggested poll interval. We clamp it to a
    sensible floor so a misconfigured server can't make the CLI hot-loop.
    """
    interval = max(1, int(interval))
    start = time.time()
    while True:
        tokens = device_flow_poll_once(device_code)
        if tokens is not None:
            return tokens
        if time.time() - start > deadline_s:
            raise ApiError(
                408,
                {"detail": {"error": "expired", "error_description": "Polling deadline reached"}},
            )
        time.sleep(interval)


def refresh_credentials(refresh_token: str) -> dict:
    with raw_client() as cx:
        return _check(cx.post("/cli/auth/refresh", json={"refresh_token": refresh_token}))


# ---------------------------------------------------------------------------
# Public catalog (no auth — pure metadata)
# ---------------------------------------------------------------------------


def list_sdk_actions() -> dict:
    """Fetch the live SDK action catalog from ``GET /sdk/actions``.

    Returns ``{"actions": [...], "missing_specs": [...]}``. Public endpoint
    so this works pre-login — agents can discover the surface before they
    have credentials.
    """
    with raw_client() as cx:
        return _check(cx.get("/sdk/actions"))


def describe_sdk_action(name: str) -> dict:
    """Fetch a single action's spec. Raises ``ApiError(404)`` if unknown."""
    with raw_client() as cx:
        return _check(cx.get("/sdk/actions", params={"action": name}))


# ---------------------------------------------------------------------------
# Authed client
# ---------------------------------------------------------------------------


class Client:
    """Auth-aware façade. Reads ~/.rgba/credentials, attaches Bearer,
    refreshes once on 401.
    """

    def __init__(self, creds: Credentials, timeout_seconds: float | None = None):
        self.creds = creds
        timeout = (
            httpx.Timeout(float(timeout_seconds), connect=15.0)
            if timeout_seconds is not None
            else DEFAULT_TIMEOUT
        )
        self._cx = httpx.Client(base_url=creds.api_url.rstrip("/"), timeout=timeout)

    def close(self) -> None:
        self._cx.close()

    def __enter__(self) -> "Client":
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    @classmethod
    def from_disk(cls, timeout_seconds: float | None = None) -> "Client":
        creds = load_credentials()
        if not creds:
            raise NotLoggedIn("No credentials found — run `rgba auth login` first.")
        return cls(creds, timeout_seconds=timeout_seconds)

    def _headers(self) -> dict:
        return {"Authorization": f"Bearer {self.creds.access_token}"}

    def _refresh(self) -> None:
        new = refresh_credentials(self.creds.refresh_token)
        # Preserve api_url (server doesn't echo it); replace token fields.
        self.creds = Credentials(
            access_token=new["access_token"],
            refresh_token=new["refresh_token"],
            expires_at=new["expires_at"],
            refresh_expires_at=new["refresh_expires_at"],
            api_url=self.creds.api_url,
        )
        save_credentials(self.creds)

    def request(self, method: str, path: str, **kwargs) -> Any:
        kwargs.setdefault("headers", {}).update(self._headers())
        resp = self._cx.request(method, path, **kwargs)
        if resp.status_code == 401:
            # One refresh + retry. If that fails, surface a 401 so the
            # caller can prompt re-login.
            try:
                self._refresh()
            except ApiError:
                raise ApiError(401, _decode(resp))
            kwargs["headers"]["Authorization"] = f"Bearer {self.creds.access_token}"
            resp = self._cx.request(method, path, **kwargs)
        return _check(resp)

    # Convenience verbs --------------------------------------------------

    def get(self, path: str, **kw) -> Any:
        return self.request("GET", path, **kw)

    def post(self, path: str, json: Any = None, **kw) -> Any:
        return self.request("POST", path, json=json, **kw)

    # Higher-level wrappers ---------------------------------------------

    def me(self) -> dict:
        return self.get("/sdk/me")

    def sdk_action(self, action: str, params: dict, *, wait: bool = True) -> Any:
        body = {"action": action, "params": params}
        suffix = "" if wait else "?wait=false"
        return self.post(f"/sdk/action{suffix}", json=body)

    def get_job(self, job_id: str) -> dict:
        return self.get(f"/sdk/jobs/{job_id}")

    def wait_job(self, job_id: str, poll_s: int = 3, deadline_s: int = 900) -> dict:
        start = time.time()
        while True:
            job = self.get_job(job_id)
            if job.get("status") in {"completed", "failed", "canceled"}:
                return job
            if time.time() - start > deadline_s:
                return job  # caller decides what to do with a stuck job
            time.sleep(poll_s)

    def logout(self) -> bool:
        try:
            resp = self.post("/cli/auth/logout")
        except ApiError:
            return False
        return bool(resp and resp.get("revoked"))
