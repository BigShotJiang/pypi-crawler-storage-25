"""rgba — Typer entry point.

Subcommands attach in `cmds/` and are imported here. Keeping the surface
flat — no nested groups beyond `rgba auth …` and `rgba jobs …` — means
new users don't have to memorize a tree to discover commands.
"""

from __future__ import annotations

import typer

from . import __version__
from .cmds import actions as actions_cmd
from .cmds import auth as auth_cmd
from .cmds import jobs as jobs_cmd
from .cmds import sdk as sdk_cmd

# Epilog is shown at the bottom of ``rgba --help``. Click paragraph-wraps
# the text, so keep it one short sentence per paragraph (separated by blank
# lines) — the detailed catalog lives in ``rgba actions``.
_ROOT_EPILOG = (
    "Run `rgba actions` to discover every /sdk/action endpoint with full "
    "param schemas and cost estimates — no auth required, ideal for AI agents "
    "introspecting the CLI surface before dispatching `rgba sdk <action>`."
)

app = typer.Typer(
    name="rgba",
    help="RGBA command-line interface. Try `rgba auth login` first.",
    epilog=_ROOT_EPILOG,
    add_completion=False,
    no_args_is_help=True,
)

app.add_typer(auth_cmd.app, name="auth", help="Sign in, sign out, check status.")
app.add_typer(jobs_cmd.app, name="jobs", help="Poll async job status.")


@app.command()
def version() -> None:
    """Print the installed rgba CLI version."""
    typer.echo(__version__)


# Top-level conveniences — these proxy to the corresponding subcommands so
# users can type `rgba me` instead of `rgba auth status` and `rgba sdk …`
# without the auth prefix.
app.command(name="me", help="Show the currently authenticated user.")(
    auth_cmd.status
)
app.command(
    name="sdk",
    help="Call /sdk/action — e.g. `rgba sdk query -p table=projects -p limit=2`.",
    epilog=(
        "Discover what actions exist: `rgba actions` (live catalog) or "
        "`rgba actions <name>` for one action's full param schema."
    ),
)(sdk_cmd.action)
app.command(
    name="actions",
    help="Discover /sdk/action endpoints. `rgba actions` lists everything; `rgba actions <name>` describes one.",
)(actions_cmd.actions)


def cli() -> None:  # pragma: no cover - thin entry point
    app()


if __name__ == "__main__":  # pragma: no cover
    cli()
