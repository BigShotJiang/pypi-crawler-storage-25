"""`rgba jobs …` — poll the async job surface."""

from __future__ import annotations

import json
import sys

import typer

from ..api import ApiError, Client, NotLoggedIn

app = typer.Typer(no_args_is_help=True, add_completion=False)


def _print(job: dict, json_out: bool) -> None:
    if json_out:
        json.dump(job, sys.stdout, indent=2)
        sys.stdout.write("\n")
        return
    typer.echo(f"id:         {job.get('id')}")
    typer.echo(f"kind:       {job.get('kind')}")
    typer.echo(f"status:     {job.get('status')}")
    if job.get("error"):
        typer.secho(f"error:      {job['error']}", fg=typer.colors.RED)
    if job.get("output_data"):
        typer.echo("output_data:")
        typer.echo(json.dumps(job["output_data"], indent=2))


@app.command()
def get(
    job_id: str = typer.Argument(...),
    json_out: bool = typer.Option(False, "--json"),
) -> None:
    """One-shot status read of a job."""
    try:
        with Client.from_disk() as cx:
            job = cx.get_job(job_id)
    except NotLoggedIn as exc:
        typer.secho(f"rgba: {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)
    except ApiError as exc:
        typer.secho(f"rgba: /sdk/jobs/{job_id} failed ({exc.status}): {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)
    _print(job, json_out)


@app.command()
def wait(
    job_id: str = typer.Argument(...),
    poll_seconds: int = typer.Option(3, "--poll", help="Polling interval in seconds."),
    deadline_seconds: int = typer.Option(
        900, "--deadline", help="Max wall time before giving up (s)."
    ),
    json_out: bool = typer.Option(False, "--json"),
) -> None:
    """Block until the job reaches a terminal state (or deadline)."""
    try:
        with Client.from_disk() as cx:
            job = cx.wait_job(job_id, poll_s=poll_seconds, deadline_s=deadline_seconds)
    except NotLoggedIn as exc:
        typer.secho(f"rgba: {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)
    except ApiError as exc:
        typer.secho(f"rgba: /sdk/jobs/{job_id} failed ({exc.status}): {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)
    _print(job, json_out)
    if job.get("status") == "failed":
        raise typer.Exit(2)
