"""`rgba auth …` subcommands.

  login    — kick off device flow, open a browser, poll for approval
  logout   — revoke + delete credentials
  status   — print whoami
"""

from __future__ import annotations

import webbrowser

import typer

from ..api import (
    ApiError,
    Client,
    NotLoggedIn,
    device_flow_start,
    device_flow_wait,
)
from ..config import Credentials, api_url, clear_credentials, save_credentials

app = typer.Typer(no_args_is_help=True, add_completion=False)


def _abort(msg: str, code: int = 1) -> None:
    typer.secho(f"rgba: {msg}", fg=typer.colors.RED, err=True)
    raise typer.Exit(code=code)


@app.command()
def login(
    no_browser: bool = typer.Option(
        False, "--no-browser", help="Print the approval URL instead of opening it."
    ),
) -> None:
    """Authenticate this machine with the RGBA backend (device flow)."""
    try:
        start = device_flow_start()
    except ApiError as exc:
        _abort(f"device-flow start failed ({exc.status}): {exc}")
        return  # unreachable but keeps mypy happy

    # Show the user_code prominently so it can be cross-checked on the
    # web side — defense against device-flow phishing.
    typer.echo()
    typer.secho("Your one-time code:", fg=typer.colors.CYAN)
    typer.secho(f"    {start.user_code}", fg=typer.colors.GREEN, bold=True)
    typer.echo()
    typer.echo("Open this URL and approve the session:")
    typer.secho(f"    {start.verification_uri_complete}", fg=typer.colors.BLUE)
    typer.echo()

    if not no_browser:
        # webbrowser.open is best-effort — failures are silent but we
        # don't promise a working browser. The URL is printed above.
        try:
            webbrowser.open(start.verification_uri_complete)
        except Exception:
            pass

    typer.echo("Waiting for approval… (Ctrl+C to abort)")
    try:
        tokens = device_flow_wait(start.device_code, interval=start.interval)
    except ApiError as exc:
        _abort(f"login failed: {exc}")
        return
    except KeyboardInterrupt:
        _abort("login cancelled", code=130)
        return

    save_credentials(
        Credentials(
            access_token=tokens["access_token"],
            refresh_token=tokens["refresh_token"],
            expires_at=tokens.get("expires_at", ""),
            refresh_expires_at=tokens.get("refresh_expires_at", ""),
            api_url=api_url(),
        )
    )

    # Print whoami so the user sees the token actually works.
    try:
        with Client.from_disk() as cx:
            me = cx.me()
        typer.secho(
            f"✓ Logged in as {me.get('email') or me.get('user_id')}",
            fg=typer.colors.GREEN,
        )
    except (ApiError, NotLoggedIn) as exc:
        # Credentials were written but /sdk/me failed — surface the error
        # but don't roll back the credentials file. The user can retry
        # `rgba me` later.
        typer.secho(
            f"✓ Token saved, but /sdk/me check failed: {exc}",
            fg=typer.colors.YELLOW,
            err=True,
        )


@app.command()
def logout() -> None:
    """Revoke the active token and delete local credentials."""
    revoked = False
    try:
        with Client.from_disk() as cx:
            revoked = cx.logout()
    except NotLoggedIn:
        pass
    except ApiError as exc:
        typer.secho(
            f"warning: server-side revoke failed ({exc}); deleting local creds anyway",
            fg=typer.colors.YELLOW,
            err=True,
        )
    removed = clear_credentials()
    if revoked or removed:
        typer.secho("✓ Logged out.", fg=typer.colors.GREEN)
    else:
        typer.echo("Already logged out.")


@app.command()
def status() -> None:
    """Print the currently authenticated user."""
    try:
        with Client.from_disk() as cx:
            me = cx.me()
    except NotLoggedIn as exc:
        _abort(str(exc))
        return
    except ApiError as exc:
        _abort(f"/sdk/me failed: {exc}")
        return
    typer.echo(f"user_id:   {me.get('user_id') or '(operator)'}")
    typer.echo(f"email:     {me.get('email') or '-'}")
    typer.echo(f"auth_mode: {me.get('auth_mode')}")
