"""`rgba sdk …` — generic /sdk/action dispatch.

The shape mirrors the JSON body of POST /sdk/action so anything the
backend supports is callable without the CLI needing to know about it.

  rgba sdk query -p table=projects -p limit=2
  rgba sdk query --params '{"table":"shots","filters":{"video_id":"…"}}'
  rgba sdk generate-image --params '{...}' --no-wait    # returns job_id

For action discovery, see ``rgba actions`` (lives in cmds/actions.py).
"""

from __future__ import annotations

import json
import sys
from typing import Any, List, Optional

import typer

from ..api import ApiError, Client, NotLoggedIn
from .actions import KNOWN_ACTIONS

_SDK_EPILOG = (
    "Discover the action surface:\n"
    "  rgba actions                      — list every action with cost + kind\n"
    "  rgba actions <name>               — full param schema for one action\n"
    "\n"
    "Known actions (run `rgba actions` for live params + costs):\n"
    + "\n".join(f"  {name:<30} {desc}" for name, desc in KNOWN_ACTIONS)
)


app = typer.Typer(
    no_args_is_help=True,
    add_completion=False,
    help=(
        "Call /sdk/action — generic dispatch. "
        "Run `rgba actions` to discover what actions exist."
    ),
    epilog=_SDK_EPILOG,
)


def _parse_param(item: str) -> tuple[str, Any]:
    """Parse a ``key=value`` token. Values are JSON-decoded when possible
    so users can pass numbers and bools without quoting magic
    (``-p limit=2`` → int, ``-p mock=true`` → bool, plain strings stay
    strings).
    """
    if "=" not in item:
        raise typer.BadParameter(f"--param expects key=value; got: {item!r}")
    key, _, raw = item.partition("=")
    if not key:
        raise typer.BadParameter(f"--param key is empty in {item!r}")
    try:
        value = json.loads(raw)
    except json.JSONDecodeError:
        value = raw
    return key, value


def action(
    action: str = typer.Argument(..., help="Action name, e.g. `query`, `generate-image`."),
    params: Optional[str] = typer.Option(
        None,
        "--params",
        help="JSON object with all params at once. Mutually exclusive with -p.",
    ),
    param: List[str] = typer.Option(
        [],
        "-p",
        "--param",
        help="Shorthand for one param: -p key=value. Repeatable. Numbers/bools auto-decoded.",
    ),
    wait: bool = typer.Option(
        True,
        "--wait/--no-wait",
        help="Block until the action returns (default). --no-wait returns {job_id, status}.",
    ),
    wait_timeout: int = typer.Option(
        1900,
        "--wait-timeout",
        help=(
            "Max seconds to wait on the HTTP request. Default 1900s — slightly "
            "more than the backend's AGENT_TOOL_TIMEOUT wall (1800s) so the "
            "CLI never gives up before the server. Bump for explainer / video "
            "gens that exceed 30 min; lower for chatty pipelines where you'd "
            "rather fail fast."
        ),
    ),
    json_out: bool = typer.Option(
        False,
        "--json",
        help="Emit the raw response with no pretty-printing — pipeable into jq.",
    ),
) -> None:
    """Call /sdk/action with the given action name + params."""
    if params and param:
        typer.secho(
            "rgba: --params and -p/--param are mutually exclusive", fg=typer.colors.RED, err=True
        )
        raise typer.Exit(2)

    if params:
        try:
            decoded = json.loads(params)
        except json.JSONDecodeError as exc:
            typer.secho(f"rgba: --params is not valid JSON: {exc}", fg=typer.colors.RED, err=True)
            raise typer.Exit(2)
        if not isinstance(decoded, dict):
            typer.secho("rgba: --params must be a JSON object", fg=typer.colors.RED, err=True)
            raise typer.Exit(2)
        params_dict = decoded
    else:
        params_dict = dict(_parse_param(p) for p in param)

    try:
        with Client.from_disk(timeout_seconds=wait_timeout) as cx:
            result = cx.sdk_action(action, params_dict, wait=wait)
    except NotLoggedIn as exc:
        typer.secho(f"rgba: {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)
    except ApiError as exc:
        typer.secho(f"rgba: /sdk/action failed ({exc.status}): {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)

    if json_out:
        json.dump(result, sys.stdout, indent=2)
        sys.stdout.write("\n")
    else:
        typer.echo(json.dumps(result, indent=2))
