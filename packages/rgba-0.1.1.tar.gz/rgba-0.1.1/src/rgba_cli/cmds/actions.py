"""``rgba actions`` — discover the /sdk/action surface.

Two shapes:

  rgba actions               → list every action (table) with kind + cost
  rgba actions <name>        → full param schema for one action

Both support ``--json`` for machine-readable output. Backed by the public
``GET /sdk/actions`` endpoint so an agent driving the CLI can introspect
the SDK before authenticating.

Kept as a sibling of ``rgba sdk`` (rather than ``rgba sdk list`` /
``rgba sdk describe``) because ``rgba sdk`` is a single-arg leaf that
accepts arbitrary action names — promoting it to a group would collide
with action names like ``query`` / ``upsert``.
"""

from __future__ import annotations

import json
import sys
from typing import Optional

import typer

from ..api import ApiError, describe_sdk_action, list_sdk_actions

# Static fallback list. Mirrors backend ACTIONS so ``rgba actions --help``
# is meaningful offline / pre-login. ``rgba actions`` (the command body)
# fetches the live catalog with full schemas.
KNOWN_ACTIONS = [
    ("query", "Read rows from a table."),
    ("upsert", "Insert or update rows."),
    ("upload", "Upload a file to S3."),
    ("search-images", "Web-search for images, mirror to S3."),
    ("resolve-shot-references", "Resolve one shot's reference URLs."),
    ("resolve-shot-reference-ids", "Persist resolved sibling shot ids for a video."),
    ("generate-images", "Generate N storyboard / end-frame images (paid)."),
    ("generate-shots", "Generate N video clips (Seedance / Kling / Remotion)."),
    ("generate-explainer-shots", "Per-shot Remotion render."),
    ("render-explainer-shots", "Render every shot of an explainer video in parallel."),
    ("build-holistic-video", "One-shot holistic video via Sora."),
    ("generate-voiceovers", "Per-shot voiceovers via ElevenLabs."),
    ("stitch-video", "ffmpeg-stitch every rendered shot into the final MP4."),
    ("build-explainer-video", "Composite: render → VO → re-render bumped → stitch."),
]


def _print_table(actions: list[dict]) -> None:
    """Two-column ``name  cost`` table grouped by kind. Tuned for terminal
    reading, not parsing — use ``--json`` for that.
    """
    by_kind: dict[str, list[dict]] = {}
    for a in actions:
        by_kind.setdefault(a.get("kind", "?"), []).append(a)

    # Stable kind order so output is reproducible.
    kind_order = ["sync", "batch", "async", "worker", "composite"]
    name_w = max((len(a["name"]) for a in actions), default=20)

    for kind in kind_order:
        bucket = by_kind.get(kind, [])
        if not bucket:
            continue
        typer.echo(f"\n[{kind}]")
        for a in bucket:
            cost = a.get("cost_estimate", "—")
            desc = (a.get("description") or "").split("\n")[0]
            typer.echo(f"  {a['name']:<{name_w}}  {cost}")
            typer.echo(f"  {'':<{name_w}}  {desc}")

    # Surface any catalog drift loudly so the agent sees it.
    # (The endpoint returns an empty list when in sync.)
    # Don't print the section at all when there's nothing to report.


def _print_describe(spec: dict) -> None:
    """Human-readable single-action spec. ``--json`` skips this path."""
    typer.echo(f"\n{spec['name']}  ({spec.get('kind', '?')})")
    typer.echo(f"  cost:  {spec.get('cost_estimate', '—')}")
    if spec.get("description"):
        typer.echo("")
        for line in spec["description"].splitlines():
            typer.echo(f"  {line}")

    params = spec.get("params") or []
    if params:
        typer.echo("\n  params:")
        for p in params:
            req = "required" if p.get("required") else "optional"
            type_ = p.get("type", "any")
            default = p.get("default")
            enum = p.get("enum")
            tail = f"  ({req}, {type_}"
            if enum:
                tail += f", enum={enum}"
            if default is not None:
                tail += f", default={default!r}"
            tail += ")"
            typer.echo(f"    {p['name']}{tail}")
            desc = (p.get("description") or "").strip()
            if desc:
                for line in desc.splitlines():
                    typer.echo(f"        {line}")

    example = spec.get("example")
    if example:
        typer.echo("\n  example:")
        typer.echo(f"    rgba sdk {example['action']} --params '{json.dumps(example.get('params', {}))}'")


def actions(
    name: Optional[str] = typer.Argument(
        None,
        help="Action name. Omit to list every action.",
    ),
    json_out: bool = typer.Option(
        False,
        "--json",
        help="Emit raw JSON for piping into jq / consuming from an agent.",
    ),
) -> None:
    """List or describe /sdk/action endpoints.

    Without an argument, prints the full catalog. With ``<name>``, prints
    the spec for one action (use this before composing a ``rgba sdk <name>``
    invocation to see exactly which params it accepts).
    """
    try:
        if name is None:
            result = list_sdk_actions()
            if json_out:
                json.dump(result, sys.stdout, indent=2)
                sys.stdout.write("\n")
                return
            _print_table(result.get("actions") or [])
            missing = result.get("missing_specs") or []
            if missing:
                typer.secho(
                    f"\n[warn] catalog drift — backend exposes actions with no spec: {missing}",
                    fg=typer.colors.YELLOW,
                    err=True,
                )
            return

        spec = describe_sdk_action(name)
        if json_out:
            json.dump(spec, sys.stdout, indent=2)
            sys.stdout.write("\n")
            return
        _print_describe(spec)
    except ApiError as exc:
        typer.secho(f"rgba: /sdk/actions failed ({exc.status}): {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)
