# rgba CLI

Thin HTTPS client for the RGBA API at `api.rgba.ai` (Modal-hosted).

## Install

```bash
pip install rgba             # from PyPI
pipx install rgba            # isolated user install (recommended for daily use)
```

After install you'll have a `rgba` command on your PATH.

## Usage

```bash
rgba auth login              # device-flow → opens https://rgba.ai/cli in your browser
rgba auth status             # show whoami
rgba auth logout             # revoke the active token

rgba me                      # alias for `auth status`
rgba actions                 # discover every /sdk/action with cost + params
rgba actions <name>          # full schema for one action
rgba sdk <action> -p key=val # call /sdk/action
rgba jobs get <job_id>       # poll a job
rgba jobs wait <job_id>      # poll until status is completed/failed
```

Credentials live in `~/.rgba/credentials` (mode 0600). The CLI never sees
your Supabase password — auth is brokered through a device-flow OAuth
against the RGBA backend.

## Environment

| var              | default                                                                  | use                                       |
|------------------|--------------------------------------------------------------------------|-------------------------------------------|
| `RGBA_API_URL`   | `https://lemontree-media-llc--rgba-agent-agent-app.modal.run`            | Override the API origin (e.g. localhost)  |
| `RGBA_CONFIG_DIR`| `~/.rgba`                                                                | Override credentials directory            |
