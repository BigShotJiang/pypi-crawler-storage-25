# BuildAI CLI

Typer-based CLI with two modes: standalone (PyPI, API-backed) and workspace (repo-local, DB-direct).

## Two Planes

| Mode | Install | Auth | DB Access |
|------|---------|------|-----------|
| Standalone (`buildai`) | `uv tool install buildai-cli` | API key / JWT | Through API |
| Workspace (`uv run buildai`) | Repo-local editable install | IAM / password | Direct via `db` |

## Key Commands

```bash
buildai auth whoami                                  # API auth inspection
buildai db query "SELECT count(*) FROM core.clips"   # DB-direct
buildai db schema tables                             # Schema introspection
buildai db schema describe core.clips                # Table details
buildai db --write migrate all                       # Run migrations
buildai db status                                    # Migration status
```

## Guards

- `db` subcommands require workspace install + gcloud IAM.
- Writes require `--write` flag.
- Production migrations prompt for confirmation.
- Worktree app/runtime targeting comes from explicit env vars and the repo Makefile, not a saved CLI context layer.
- `buildai db --env` selects the explicit DB lane: `production`, `dev`.

## Reference

CLI mode guide: docs site Engineering section (run `make docs`)
Database roles: docs site Operations section (run `make docs`)
