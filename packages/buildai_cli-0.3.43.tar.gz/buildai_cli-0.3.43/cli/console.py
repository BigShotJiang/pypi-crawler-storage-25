"""Rich console utilities for CLI output.

Two consoles:
- ``data_console`` → stdout (data output, piped to jq etc.)
- ``status_console`` → stderr (status messages, errors, warnings)

The legacy ``console`` alias points to ``status_console`` for backward compat.
"""

import sys

from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax

# Data output (stdout) — what downstream tools consume.
# highlight=False prevents Rich from adding ANSI color to JSON keys/values
# when piped to files or other commands (e.g., jq, > file.json).
data_console = Console(file=sys.stdout, highlight=False, markup=False)

# Status/errors/warnings (stderr) — never pollutes pipes
status_console = Console(file=sys.stderr)

# Backward-compat alias — existing code that imports ``console`` keeps working
console = status_console

# Verbose mode flag
_verbose: bool = False


def set_verbose(enabled: bool) -> None:
    """Enable or disable verbose mode."""
    global _verbose
    _verbose = enabled


def is_verbose() -> bool:
    """Check if verbose mode is enabled."""
    return _verbose


def success(message: str) -> None:
    """Print success message with green checkmark."""
    status_console.print(f"[green]\u2713[/green] {message}")


def error(message: str) -> None:
    """Print error message with red X."""
    status_console.print(f"[red]\u2717[/red] {message}")


def warning(message: str) -> None:
    """Print warning message with yellow icon."""
    status_console.print(f"[yellow]\u26a0[/yellow] {message}")


def info(message: str) -> None:
    """Print info message with cyan arrow."""
    status_console.print(f"[cyan]\u2192[/cyan] {message}")


def dim(message: str) -> None:
    """Print dimmed message."""
    status_console.print(f"[dim]{message}[/dim]")


def verbose(message: str) -> None:
    """Print message only in verbose mode."""
    if _verbose:
        status_console.print(f"[dim]{message}[/dim]")


def show_sql(sql: str) -> None:
    """Display SQL with syntax highlighting (verbose mode only)."""
    if not _verbose:
        return

    try:
        import sqlparse

        formatted = sqlparse.format(sql, reindent=True, keyword_case="upper")
    except ImportError:
        formatted = sql

    syntax = Syntax(formatted, "sql", theme="monokai", line_numbers=False)
    status_console.print(Panel(syntax, title="SQL Query", border_style="dim"))
