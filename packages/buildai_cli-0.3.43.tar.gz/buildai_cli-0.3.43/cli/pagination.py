"""CLI-local pagination helpers for SDK-backed command groups.

The workspace CLI should be able to page through API results without depending
on optional SDK model modules that may not be present in every install shape.
"""

from __future__ import annotations

from collections.abc import Callable, Iterator
from typing import Any


def _page_items(page: Any) -> list[Any]:
    """Extract the current page's item list from dict or object responses."""
    if isinstance(page, dict):
        data = page.get("data", [])
    else:
        data = getattr(page, "data", [])
    if isinstance(data, list):
        return data
    return []


def _page_next_cursor(page: Any) -> str | None:
    """Read the API pagination cursor from dict or object page payloads."""
    if isinstance(page, dict):
        pagination = page.get("pagination") or {}
        if isinstance(pagination, dict):
            return pagination.get("next_cursor")
        return None

    pagination = getattr(page, "pagination", None)
    if pagination is None:
        return None
    if isinstance(pagination, dict):
        return pagination.get("next_cursor")
    return getattr(pagination, "next_cursor", None)


def auto_paginate(fetch_page: Callable[..., Any], /, **kwargs: Any) -> Iterator[Any]:
    """Yield items across cursor-based pages until the API stops returning one."""
    params = dict(kwargs)
    cursor = params.pop("cursor", None)

    while True:
        if cursor is not None:
            params["cursor"] = cursor
        page = fetch_page(**params)
        items = _page_items(page)
        yield from items

        next_cursor = _page_next_cursor(page)
        if not next_cursor:
            return
        cursor = next_cursor
