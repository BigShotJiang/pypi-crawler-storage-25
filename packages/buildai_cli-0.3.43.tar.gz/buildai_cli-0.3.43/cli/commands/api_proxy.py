"""Raw API proxy — call any endpoint using CLI credentials."""

from __future__ import annotations

import json
import sys
from typing import Any
from urllib.parse import parse_qs, urlencode, urlparse, urlunparse

import httpx
import typer

from cli.config import resolve_api_url, resolve_credential
from cli.console import error, warning


def _build_url(base_url: str, path: str, query_params: list[str] | None) -> str:
    """Build a full URL from base, path, and optional query params.

    Handles both styles:
        buildai api /v1/clips --query page_size=3
        buildai api '/v1/clips?page_size=3'
    """
    # Normalize path
    if not path.startswith("/"):
        path = f"/{path}"

    # Parse any query string already in the path
    parsed = urlparse(path)
    clean_path = parsed.path
    existing_qs = parse_qs(parsed.query, keep_blank_values=True)

    # Merge --query params
    if query_params:
        for param in query_params:
            if "=" not in param:
                raise typer.BadParameter(f"Query param must be key=value, got: {param}")
            key, _, value = param.partition("=")
            existing_qs.setdefault(key, []).append(value)

    # Rebuild
    qs = urlencode(existing_qs, doseq=True) if existing_qs else ""
    full_path = urlunparse(("", "", clean_path, "", qs, ""))
    return f"{base_url}{full_path}"


def api(
    path: str = typer.Argument(
        ...,
        help="API path (e.g. /v1/clips, /v1/inference/contracts).",
    ),
    method: str = typer.Option(
        "GET",
        "-X",
        "--method",
        help="HTTP method: GET, POST, PATCH, DELETE.",
    ),
    body: str | None = typer.Option(
        None,
        "-d",
        "--body",
        help="JSON request body (for POST/PATCH).",
    ),
    query_param: list[str] | None = typer.Option(
        None,
        "-q",
        "--query",
        help="Query parameter as key=value. Repeatable. Avoids shell quoting issues.",
    ),
    raw: bool = typer.Option(
        False,
        "--raw",
        help="Include HTTP status and headers in output.",
    ),
) -> None:
    """Call any Build AI API endpoint directly.

    Uses your stored credential — no API key needed in the command.
    Output is always JSON to stdout (pipeable to jq, files, etc).

    Query parameters can be passed two ways:

        buildai api /v1/clips -q page_size=3 -q factory_id=UUID

        buildai api '/v1/clips?page_size=3'    # quote the URL in your shell

    Examples:

        buildai api /v1/clips -q page_size=3

        buildai api /v1/inference/contracts

        buildai api -X POST /v1/query -d '{"sql": "SELECT count(*) FROM core.clips"}'

        buildai api /v1/factories | jq '.data[].id'

        buildai api /v1/assets/ASSET_UUID/sign -X POST

        buildai api /v1/clips -q page_size=100 > clips.json
    """
    # --- Auth ---
    try:
        token = resolve_credential()
    except RuntimeError as exc:
        error(str(exc))
        raise typer.Exit(1) from exc

    # --- Build URL ---
    base_url = resolve_api_url()
    try:
        url = _build_url(base_url, path, query_param)
    except typer.BadParameter as exc:
        error(str(exc))
        raise typer.Exit(1) from exc

    # --- Headers ---
    headers: dict[str, str] = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
    }

    # --- Parse body ---
    parsed_body: Any = None
    if body:
        try:
            parsed_body = json.loads(body)
            headers["Content-Type"] = "application/json"
        except json.JSONDecodeError as exc:
            error(f"Invalid JSON in --body: {exc}")
            raise typer.Exit(1) from exc

    # --- Request ---
    try:
        with httpx.Client(timeout=60.0) as client:
            resp = client.request(
                method.upper(),
                url,
                headers=headers,
                json=parsed_body,
            )
    except httpx.ConnectError:
        error(f"Could not connect to {base_url}. Check your network or BUILDAI_API_URL.")
        raise typer.Exit(1)
    except httpx.TimeoutException:
        error("Request timed out (60s). Try a more specific query or increase timeout.")
        raise typer.Exit(1)

    # --- Output ---
    if raw:
        sys.stderr.write(f"HTTP {resp.status_code}\n")
        for k, v in resp.headers.items():
            sys.stderr.write(f"{k}: {v}\n")
        sys.stderr.write("\n")

    try:
        data = resp.json()
        sys.stdout.write(json.dumps(data, indent=2, default=str) + "\n")
    except Exception:
        sys.stdout.write(resp.text + "\n")

    # --- Error handling ---
    if resp.status_code >= 400:
        # Show a helpful message on stderr so stdout stays clean for piping
        try:
            err_data = resp.json()
            detail = err_data.get("detail") or err_data.get("error", {}).get("message")
            if detail:
                warning(f"API error {resp.status_code}: {detail}")
        except Exception:
            warning(f"API error {resp.status_code}")
        raise typer.Exit(1)
