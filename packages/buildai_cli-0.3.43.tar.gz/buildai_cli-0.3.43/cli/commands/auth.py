"""Build AI auth commands for API credentials and local developer auth state."""

from __future__ import annotations

import sys
import time
import webbrowser
from typing import Any

import httpx
import typer
from rich.table import Table

from cli.auth_local import (
    DEFAULT_ENVIRONMENT,
    AuthReport,
    bootstrap_commands,
    build_auth_report,
    report_as_jsonable,
    resolve_sanctioned_profile,
    sanctioned_auth_profiles,
)
from cli.config import clear_credential, resolve_api_url, save_cli_config
from cli.console import console, data_console, error, info, status_console, success, warning
from cli.internal_api import get_internal_api_client
from cli.output import Format, auto_format, format_option, render

app = typer.Typer(
    no_args_is_help=True,
    help="Inspect Build AI API auth, local Google auth, and sanctioned local-dev profiles.",
)


def _api_base_url() -> str:
    """Resolve the public API base URL once per command invocation."""

    return resolve_api_url()


def _raise_for_status(resp: httpx.Response) -> None:
    """Promote API login errors into user-facing Typer validation errors."""

    try:
        payload = resp.json()
    except Exception:
        payload = None

    message = None
    if isinstance(payload, dict):
        if isinstance(payload.get("detail"), str):
            message = payload["detail"]
        elif isinstance(payload.get("error"), dict):
            message = payload["error"].get("message")
    if not message:
        message = resp.text or f"HTTP {resp.status_code}"
    raise typer.BadParameter(message)


def _start_device_login(client: httpx.Client, client_name: str) -> dict[str, Any]:
    """Kick off the device-flow login used by the public API credential plane."""

    resp = client.post(
        f"{_api_base_url()}/v1/auth/cli/start",
        json={"client_name": client_name},
    )
    if resp.status_code >= 400:
        _raise_for_status(resp)
    return resp.json()


def _poll_device_login(client: httpx.Client, device_code: str) -> dict[str, Any]:
    """Poll the public API until the device-flow login is approved or expires."""

    resp = client.get(
        f"{_api_base_url()}/v1/auth/cli/poll",
        params={"device_code": device_code},
    )
    if resp.status_code == 429:
        retry_after = resp.headers.get("Retry-After")
        if retry_after:
            try:
                time.sleep(max(float(retry_after), 0.0))
            except ValueError:
                pass
        return {"status": "pending"}
    if resp.status_code >= 400:
        _raise_for_status(resp)
    return resp.json()


def _store_token(token: str, *, profile: str | None = None) -> None:
    """Persist a public API token in the normal CLI credentials location."""

    save_cli_config(profile=profile, api_key=token)
    success("Saved CLI credentials to ~/.buildai/credentials.json")


def _device_login(
    *,
    client_name: str = "buildai-cli",
    open_browser: bool = True,
    profile: str | None = None,
) -> None:
    """Run the browser-capable device flow used for Build AI API auth."""

    with httpx.Client(timeout=15.0) as client:
        try:
            start = _start_device_login(client, client_name)
        except typer.BadParameter as exc:
            error(str(exc))
            raise typer.Exit(1) from exc

        verification_url = start["verification_url"]
        user_code = start["user_code"]
        expires_in = int(start["expires_in"])
        poll_interval = max(int(start["poll_interval"]), 1)

        console.print(f"  code   : [cyan]{user_code}[/cyan]")
        console.print(f"  verify : [cyan]{verification_url}[/cyan]")
        info("Approve this login in the browser, then the CLI will finish automatically.")

        if open_browser:
            try:
                if webbrowser.open(verification_url):
                    info("Opened verification URL in your browser.")
                else:
                    warning("Could not open your browser automatically.")
            except Exception:
                warning("Could not open your browser automatically.")

        deadline = time.monotonic() + expires_in + poll_interval
        while time.monotonic() < deadline:
            try:
                poll = _poll_device_login(client, start["device_code"])
            except typer.BadParameter as exc:
                error(str(exc))
                raise typer.Exit(1) from exc

            status = poll.get("status")
            if status == "approved":
                token = poll.get("token")
                if not token:
                    error("CLI login completed without a token.")
                    raise typer.Exit(1)
                _store_token(token, profile=profile)
                return
            if status == "pending":
                time.sleep(poll_interval)
                continue
            if status == "expired":
                error("CLI login expired before approval.")
                raise typer.Exit(1)
            if status == "consumed":
                error("CLI login token was already consumed.")
                raise typer.Exit(1)
            error(f"Unexpected CLI login status: {status!r}")
            raise typer.Exit(1)

    error("CLI login timed out before approval.")
    raise typer.Exit(1)


def _profile_rows() -> list[dict[str, Any]]:
    """Flatten the sanctioned profile registry into one table-friendly shape."""

    rows: list[dict[str, Any]] = []
    for profile in sanctioned_auth_profiles():
        target = "requires --service <slug>" if profile.requires_service else "fixed target"
        rows.append(
            {
                "profile": profile.name,
                "audience": profile.audience,
                "target": target,
                "db_access": profile.db_access,
                "break_glass": profile.break_glass,
                "summary": profile.summary,
            }
        )
    return rows


def _render_profile_table() -> None:
    """Render sanctioned local auth profiles in a scan-friendly human table."""

    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("Profile")
    table.add_column("Audience")
    table.add_column("Target")
    table.add_column("DB")
    table.add_column("Break Glass")
    table.add_column("Summary")
    for row in _profile_rows():
        table.add_row(
            str(row["profile"]),
            str(row["audience"]),
            str(row["target"]),
            "yes" if row["db_access"] else "no",
            "yes" if row["break_glass"] else "no",
            str(row["summary"]),
        )
    data_console.print(table)


def _render_state_tables(report: AuthReport) -> None:
    """Show the combined API and local auth state without hiding drift."""

    api_table = Table(show_header=True, header_style="bold cyan", title="API Auth")
    api_table.add_column("Field")
    api_table.add_column("Value")
    api_table.add_row("status", report.state.api_status)
    api_table.add_row("display_name", report.state.api_display_name or "")
    api_table.add_row("subject", report.state.api_subject or "")
    api_table.add_row("error", report.state.api_error or "")

    local_table = Table(show_header=True, header_style="bold cyan", title="Local Auth")
    local_table.add_column("Field")
    local_table.add_column("Value")
    local_table.add_row("gcloud_account", report.state.gcloud_account or "")
    local_table.add_row("gcloud_project", report.state.gcloud_project or "")
    local_table.add_row(
        "gcloud_impersonation",
        report.state.gcloud_impersonate_service_account or "",
    )
    local_table.add_row("adc_path", report.state.adc_path)
    local_table.add_row("adc_type", report.state.adc_type or "")
    local_table.add_row(
        "adc_identity", report.state.adc_email or report.state.adc_target_principal or ""
    )
    local_table.add_row(
        "adc_token",
        "ok" if report.state.adc_access_token_ok else (report.state.adc_access_token_error or ""),
    )

    data_console.print(api_table)
    data_console.print(local_table)

    if report.profile is not None:
        profile_table = Table(
            show_header=True,
            header_style="bold cyan",
            title="Resolved Profile",
        )
        profile_table.add_column("Field")
        profile_table.add_column("Value")
        profile_table.add_row("name", report.profile.name)
        profile_table.add_row("audience", report.profile.audience)
        profile_table.add_row("environment", report.profile.environment)
        profile_table.add_row("service", report.profile.service_slug or "")
        profile_table.add_row("target_service_account", report.profile.target_service_account or "")
        profile_table.add_row("target_db_user", report.profile.target_db_user or "")
        data_console.print(profile_table)


def _render_check_table(report: AuthReport) -> None:
    """Render doctor/check results in a compact table with concrete fixes."""

    table = Table(show_header=True, header_style="bold cyan", title="Auth Checks")
    table.add_column("Status")
    table.add_column("Check")
    table.add_column("Summary")
    table.add_column("Fix")
    for check in report.checks:
        if check.ok:
            status = "ok"
        elif check.level == "warning":
            status = "warn"
        else:
            status = "fail"
        table.add_row(status, check.code, check.summary, check.fix or "")
    data_console.print(table)

    status_console.print("[dim]Next steps[/dim]")
    for step in report.next_steps:
        status_console.print(f"[dim]  {step}[/dim]")


def _emit_report(
    report: AuthReport, *, format: Format | None = None, include_state: bool = False
) -> None:
    """Render one auth report as either structured data or human-oriented tables."""

    fmt = format or auto_format()
    if fmt != Format.TABLE:
        render(report_as_jsonable(report), format=fmt)
        return
    if include_state:
        _render_state_tables(report)
    _render_check_table(report)


@app.command("login")
def login(
    token: bool = typer.Option(
        False,
        "--token",
        help="Read a token from stdin instead of running browser-based device login.",
    ),
    client_name: str = typer.Option(
        "buildai-cli",
        "--client-name",
        help="Client name sent to the API for device-login requests.",
    ),
    open_browser: bool = typer.Option(
        True,
        "--open-browser/--no-open-browser",
        help="Open the verification URL in your browser during device login.",
    ),
    profile: str | None = typer.Option(None, "--profile", hidden=True),
) -> None:
    """Log in to the public API using device flow or a piped CI token."""

    if token:
        value = sys.stdin.read().strip()
        if not value:
            error("Expected a token on stdin.")
            raise typer.Exit(1)
        _store_token(value, profile=profile)
        return
    _device_login(client_name=client_name, open_browser=open_browser, profile=profile)


@app.command("whoami")
def whoami(
    profile: str | None = typer.Option(
        None,
        "--profile",
        help="Optional local auth profile to resolve alongside current machine state.",
    ),
    service: str | None = typer.Option(
        None,
        "--service",
        help="Service slug for profiles that emulate one runtime surface.",
    ),
    env: str = typer.Option(
        DEFAULT_ENVIRONMENT,
        "--env",
        help="Behavioral environment to resolve profile-specific targets against.",
    ),
    format: Format = format_option(),
) -> None:
    """Show public API auth and local Google auth in one place."""

    report = build_auth_report(profile_name=profile, service=service, environment=env)
    _emit_report(report, format=format, include_state=True)
    if report.exit_code:
        raise typer.Exit(report.exit_code)


@app.command("profiles")
def profiles(
    format: Format = format_option(),
) -> None:
    """List the sanctioned local auth profiles and what each one is for."""

    if format != Format.TABLE:
        render(_profile_rows(), format=format)
        return
    _render_profile_table()


@app.command("check")
def check(
    profile: str = typer.Option(..., "--profile", help="Sanctioned local auth profile."),
    service: str | None = typer.Option(
        None,
        "--service",
        help="Service slug for profiles that emulate one runtime surface.",
    ),
    env: str = typer.Option(
        DEFAULT_ENVIRONMENT,
        "--env",
        help="Behavioral environment to validate against.",
    ),
    format: Format = format_option(),
) -> None:
    """Validate one named local auth workflow end to end."""

    report = build_auth_report(profile_name=profile, service=service, environment=env)
    _emit_report(report, format=format, include_state=False)
    if report.exit_code:
        raise typer.Exit(report.exit_code)


@app.command("bootstrap")
def bootstrap(
    profile: str | None = typer.Option(
        None,
        "--profile",
        help="Optional sanctioned profile to tailor the bootstrap output.",
    ),
    service: str | None = typer.Option(
        None,
        "--service",
        help="Service slug for runtime-like profiles.",
    ),
    env: str = typer.Option(
        DEFAULT_ENVIRONMENT,
        "--env",
        help="Behavioral environment to show bootstrap wiring for.",
    ),
    format: Format = format_option(),
) -> None:
    """Print the explicit bootstrap path instead of relying on ambient magic."""

    resolved_profile = None
    if profile is not None:
        try:
            resolved_profile = resolve_sanctioned_profile(
                profile,
                service=service,
                environment=env,
            )
        except Exception as exc:
            error(str(exc))
            raise typer.Exit(1) from exc

    payload = {
        "profile": (
            {
                "name": resolved_profile.name,
                "service_slug": resolved_profile.service_slug,
                "environment": resolved_profile.environment,
                "target_service_account": resolved_profile.target_service_account,
                "target_db_user": resolved_profile.target_db_user,
                "bootstrap_exports": resolved_profile.bootstrap_exports(),
            }
            if resolved_profile is not None
            else None
        ),
        "steps": list(bootstrap_commands(profile=resolved_profile)),
    }

    if format != Format.TABLE:
        render(payload, format=format)
        return

    status_console.print("[bold]Bootstrap path[/bold]")
    for index, step in enumerate(payload["steps"], start=1):
        status_console.print(f"  {index}. {step}")

    if resolved_profile is not None and resolved_profile.bootstrap_exports():
        status_console.print("")
        status_console.print("[bold]Profile env wiring[/bold]")
        for line in resolved_profile.bootstrap_exports():
            status_console.print(f"  {line}")


@app.command("logout")
def logout() -> None:
    """Remove the stored public API credential without touching local Google auth."""

    clear_credential()
    success("Removed ~/.buildai/credentials.json")


def public_api_whoami() -> None:
    """Retain the old API-only `whoami` path for callers that still want it."""

    client = get_internal_api_client()
    try:
        access = client.access.inspect()
    finally:
        client.close()

    render(
        {
            "principal_display_name": access.principal_display_name,
            "principal_subject": access.principal_subject,
            "principal_type": access.principal_type,
            "audience": access.audience,
            "mode": access.mode,
            "permissions": access.permissions,
            "boundary": access.boundary,
        },
        format=auto_format(),
        columns=[
            "principal_display_name",
            "principal_subject",
            "principal_type",
            "audience",
            "mode",
            "permissions",
            "boundary",
        ],
    )
