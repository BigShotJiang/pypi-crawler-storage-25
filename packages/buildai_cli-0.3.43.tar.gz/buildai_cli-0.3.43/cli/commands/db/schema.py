"""Schema management tools for the simplified DB surface."""

from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass, field
from typing import Any

import typer
from infra.settings import switch_environment
from rich.table import Table
from typing_extensions import Annotated

from cli.console import console, success, warning
from cli.context import get_connection

app = typer.Typer(
    name="schema",
    help="Schema inspection and comparison tools.",
    no_args_is_help=True,
)


def _schema_connection(settings):
    """Use the normal DB connection path for schema introspection."""

    return get_connection(settings)


@dataclass
class ColumnInfo:
    """Describe one database column in a schema snapshot."""

    name: str
    data_type: str
    is_nullable: bool
    column_default: str | None
    character_maximum_length: int | None = None


@dataclass
class TableInfo:
    """Describe one database table in a schema snapshot."""

    schema: str
    name: str
    columns: dict[str, ColumnInfo] = field(default_factory=dict)


@dataclass
class SchemaDiff:
    """Capture the differences between two schema snapshots."""

    tables_missing_in_target: list[str] = field(default_factory=list)
    tables_extra_in_target: list[str] = field(default_factory=list)
    column_type_diffs: dict[str, dict[str, tuple[str, str]]] = field(default_factory=dict)
    columns_missing_in_target: dict[str, list[str]] = field(default_factory=dict)
    columns_extra_in_target: dict[str, list[str]] = field(default_factory=dict)

    def is_empty(self) -> bool:
        """Return whether the compared schemas are identical."""

        return (
            not self.tables_missing_in_target
            and not self.tables_extra_in_target
            and not self.column_type_diffs
            and not self.columns_missing_in_target
            and not self.columns_extra_in_target
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the diff in JSON-friendly form."""

        return {
            "tables_missing_in_target": self.tables_missing_in_target,
            "tables_extra_in_target": self.tables_extra_in_target,
            "column_type_diffs": self.column_type_diffs,
            "columns_missing_in_target": self.columns_missing_in_target,
            "columns_extra_in_target": self.columns_extra_in_target,
        }


async def fetch_schema_info(env: str) -> dict[str, TableInfo]:
    """Fetch a schema snapshot from one configured environment."""

    settings = switch_environment(env)
    query = """
        SELECT
            t.table_schema,
            t.table_name,
            c.column_name,
            c.data_type,
            c.is_nullable,
            c.column_default,
            c.character_maximum_length
        FROM information_schema.tables t
        JOIN information_schema.columns c
            ON t.table_schema = c.table_schema
            AND t.table_name = c.table_name
        WHERE t.table_schema IN ('core', 'observations', 'ops', 'collections', 'auth', 'archive', 'agent')
            AND t.table_type = 'BASE TABLE'
        ORDER BY t.table_schema, t.table_name, c.ordinal_position
    """

    tables: dict[str, TableInfo] = {}
    async with _schema_connection(settings) as conn:
        rows = await conn.fetch(query)
        for row in rows:
            full_name = f"{row['table_schema']}.{row['table_name']}"
            if full_name not in tables:
                tables[full_name] = TableInfo(
                    schema=row["table_schema"],
                    name=row["table_name"],
                )
            tables[full_name].columns[row["column_name"]] = ColumnInfo(
                name=row["column_name"],
                data_type=row["data_type"],
                is_nullable=row["is_nullable"] == "YES",
                column_default=row["column_default"],
                character_maximum_length=row["character_maximum_length"],
            )
    return tables


def compare_schemas(source: dict[str, TableInfo], target: dict[str, TableInfo]) -> SchemaDiff:
    """Compare two schema snapshots and return the differences."""

    diff = SchemaDiff()
    source_tables = set(source.keys())
    target_tables = set(target.keys())
    diff.tables_missing_in_target = sorted(source_tables - target_tables)
    diff.tables_extra_in_target = sorted(target_tables - source_tables)

    for table_name in source_tables & target_tables:
        source_table = source[table_name]
        target_table = target[table_name]
        source_cols = set(source_table.columns.keys())
        target_cols = set(target_table.columns.keys())

        missing = sorted(source_cols - target_cols)
        if missing:
            diff.columns_missing_in_target[table_name] = missing

        extra = sorted(target_cols - source_cols)
        if extra:
            diff.columns_extra_in_target[table_name] = extra

        for col_name in source_cols & target_cols:
            source_type = source_table.columns[col_name].data_type
            target_type = target_table.columns[col_name].data_type
            if source_type != target_type:
                diff.column_type_diffs.setdefault(table_name, {})[col_name] = (
                    source_type,
                    target_type,
                )

    return diff


def print_diff_table(diff: SchemaDiff, source_env: str, target_env: str) -> None:
    """Render the schema diff in a small set of readable tables."""

    if diff.is_empty():
        success(f"Schemas are identical between {source_env} and {target_env}")
        return

    warning(f"Schema differences found between {source_env} and {target_env}")
    console.print()

    if diff.tables_missing_in_target:
        table = Table(title=f"Tables in {source_env} missing from {target_env}")
        table.add_column("Table", style="red")
        for item in diff.tables_missing_in_target:
            table.add_row(item)
        console.print(table)
        console.print()

    if diff.tables_extra_in_target:
        table = Table(title=f"Tables in {target_env} not in {source_env}")
        table.add_column("Table", style="yellow")
        for item in diff.tables_extra_in_target:
            table.add_row(item)
        console.print(table)
        console.print()

    if diff.column_type_diffs:
        table = Table(title="Column Type Differences")
        table.add_column("Table", style="cyan")
        table.add_column("Column", style="white")
        table.add_column(source_env, style="green")
        table.add_column(target_env, style="red")
        for table_name, cols in sorted(diff.column_type_diffs.items()):
            for column_name, (source_type, target_type) in sorted(cols.items()):
                table.add_row(table_name, column_name, source_type, target_type)
        console.print(table)
        console.print()


@app.command()
def compare(
    source: Annotated[
        str, typer.Option("--source", "-s", help="Source environment")
    ] = "development",
    target: Annotated[
        str, typer.Option("--target", "-t", help="Target environment")
    ] = "production",
    output_format: Annotated[
        str, typer.Option("--format", "-f", help="Output format: table, json")
    ] = "table",
) -> None:
    """Compare schemas between two database environments."""

    async def run() -> None:
        source_schema = await fetch_schema_info(source)
        target_schema = await fetch_schema_info(target)
        diff = compare_schemas(source_schema, target_schema)

        if output_format == "json":
            console.print(json.dumps(diff.to_dict(), indent=2))
            return
        print_diff_table(diff, source, target)

    asyncio.run(run())


@app.command("tables")
def tables(
    ctx: typer.Context,
    schema: Annotated[
        str | None, typer.Option("--schema", "-s", help="Optional schema filter")
    ] = None,
) -> None:
    """List tables in the selected database lane."""

    settings = ctx.obj["settings"]

    async def run() -> None:
        query = """
            SELECT
                table_schema,
                table_name,
                COUNT(*) AS column_count
            FROM information_schema.columns
            WHERE table_schema NOT IN ('pg_catalog', 'information_schema')
        """
        params: list[Any] = []
        if schema:
            query += " AND table_schema = $1"
            params.append(schema)
        query += """
            GROUP BY table_schema, table_name
            ORDER BY table_schema, table_name
        """

        async with _schema_connection(settings) as conn:
            rows = await conn.fetch(query, *params)

        table = Table(title="Tables")
        table.add_column("Schema", style="cyan")
        table.add_column("Table")
        table.add_column("Columns", justify="right")
        for row in rows:
            table.add_row(
                str(row["table_schema"]), str(row["table_name"]), str(row["column_count"])
            )
        console.print(table)

    asyncio.run(run())


@app.command("describe")
def describe(
    ctx: typer.Context,
    table_name: Annotated[str, typer.Argument(help="Fully qualified table name, e.g. core.clips")],
) -> None:
    """Describe one table in the selected database lane."""

    settings = ctx.obj["settings"]
    if "." not in table_name:
        raise typer.BadParameter("Use a schema-qualified table name like core.clips.")
    schema_name, relation_name = table_name.split(".", 1)

    async def run() -> None:
        query = """
            SELECT
                column_name,
                data_type,
                is_nullable,
                column_default,
                character_maximum_length
            FROM information_schema.columns
            WHERE table_schema = $1
              AND table_name = $2
            ORDER BY ordinal_position
        """
        async with _schema_connection(settings) as conn:
            rows = await conn.fetch(query, schema_name, relation_name)

        if not rows:
            raise typer.BadParameter(f"Table not found: {table_name}")

        table = Table(title=f"Schema: {table_name}")
        table.add_column("Column", style="cyan")
        table.add_column("Type")
        table.add_column("Nullable")
        table.add_column("Default")
        for row in rows:
            table.add_row(
                str(row["column_name"]),
                str(row["data_type"]),
                str(row["is_nullable"]),
                str(row["column_default"] or ""),
            )
        console.print(table)

    asyncio.run(run())
