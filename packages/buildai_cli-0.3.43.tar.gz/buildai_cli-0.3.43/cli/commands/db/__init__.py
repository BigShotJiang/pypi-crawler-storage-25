"""Database command surface for the simplified Build AI CLI."""

from __future__ import annotations

import typer

from . import migrate as migrate_mod
from . import query as query_mod
from . import schema as schema_mod
from . import status as status_mod

app = typer.Typer(
    name="db",
    help="Database utilities for local dev, schema inspection, and migrations.",
    no_args_is_help=True,
)

app.command("query")(query_mod.query)
app.command("status")(status_mod.status)
app.command("migrate")(migrate_mod.migrate)
app.add_typer(schema_mod.app, name="schema")
