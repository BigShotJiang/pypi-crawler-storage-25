"""Developer-utility commands for the modern local Build AI workflow."""

from __future__ import annotations

import shlex
import shutil
from typing import Any

import typer
from rich.table import Table

from cli.auth_local import DEFAULT_ENVIRONMENT, env_suffix, resolve_sanctioned_profile
from cli.console import data_console, error, status_console
from cli.output import Format, format_option, render

app = typer.Typer(
    no_args_is_help=True,
    help="Developer utilities for local shells, database tooling, and agent-friendly setup.",
)
db_app = typer.Typer(no_args_is_help=True, help="Database access recipes for local dev.")

_DEFAULT_DEV_INSTANCE_URI = (
    "projects/data-470400/locations/asia-south1/clusters/buildai-india-dev/"
    "instances/buildai-india-dev-primary"
)
_DEFAULT_DEV_DATABASE = "buildai_dev"


def _build_proxy_command(
    *,
    instance_uri: str,
    port: int,
    all_proxy: str | None,
) -> str:
    """Render one copyable AlloyDB Auth Proxy command line."""

    command = f"alloydb-auth-proxy {shlex.quote(instance_uri)} --port {port} --auto-iam-authn"
    if all_proxy:
        return f"ALL_PROXY={shlex.quote(all_proxy)} {command}"
    return command


def _db_info_payload(
    *,
    profile_name: str,
    service: str | None,
    env: str,
    all_proxy: str | None,
) -> dict[str, Any]:
    """Build the connection recipe shared by humans, agents, and desktop tools."""

    from infra.settings import Environment, ExecutionContext, Settings

    try:
        resolved_env = Environment(env)
    except ValueError as exc:
        raise typer.BadParameter("Use one of: development, preview, production, test.") from exc

    profile = resolve_sanctioned_profile(profile_name, service=service, environment=env)
    settings = Settings(app_env=resolved_env, execution_context=ExecutionContext.HUMAN)
    proxy_port = settings.effective_alloydb_auth_proxy_port
    proxy_host = settings.alloydb_auth_proxy_host
    db_user = profile.target_db_user
    if db_user is None:
        raise typer.BadParameter(f"Profile '{profile.name}' does not resolve to a DB login.")

    try:
        instance_uri = settings.alloydb_instance_uri
    except RuntimeError:
        if resolved_env == Environment.DEVELOPMENT:
            instance_uri = _DEFAULT_DEV_INSTANCE_URI
        else:
            raise

    try:
        database_name = settings.db_name
    except RuntimeError:
        if resolved_env == Environment.DEVELOPMENT:
            database_name = _DEFAULT_DEV_DATABASE
        else:
            raise

    private_only_note = None
    if resolved_env == Environment.DEVELOPMENT:
        private_only_note = (
            "The development AlloyDB cluster is private-only. "
            "If you are outside its VPC, run the Auth Proxy through an approved "
            "intermediary path such as ALL_PROXY / PSC / VPN."
        )

    proxy_command = _build_proxy_command(
        instance_uri=instance_uri,
        port=proxy_port,
        all_proxy=all_proxy,
    )
    suffix = env_suffix(env)
    proxy_env = {
        "APP_ENV": env,
        f"ALLOYDB_USER_{suffix}": db_user,
        f"ALLOYDB_IAM_AUTH_{suffix}": "true",
        f"ALLOYDB_USE_AUTH_PROXY_{suffix}": "true",
        "ALLOYDB_AUTH_PROXY_HOST": proxy_host,
        f"ALLOYDB_AUTH_PROXY_PORT_{suffix}": str(proxy_port),
    }

    return {
        "profile": profile.name,
        "service": profile.service_slug,
        "environment": env,
        "instance_uri": instance_uri,
        "database": database_name,
        "db_user": db_user,
        "service_account": profile.target_service_account,
        "proxy_host": proxy_host,
        "proxy_port": proxy_port,
        "all_proxy": all_proxy,
        "private_only_note": private_only_note,
        "adc_impersonation_command": (
            f"gcloud auth application-default login --impersonate-service-account={profile.target_service_account}"
            if profile.target_service_account
            else None
        ),
        "proxy_command": proxy_command,
        "proxy_binary": shutil.which("alloydb-auth-proxy"),
        "proxy_env": proxy_env,
        "psql": (
            f'psql "host={proxy_host} port={proxy_port} dbname={database_name} '
            f'user={db_user} sslmode=disable"'
        ),
        "desktop_tools": {
            "common": {
                "host": proxy_host,
                "port": proxy_port,
                "database": database_name,
                "user": db_user,
                "password": "",
                "ssl": "disable",
            },
            "dbeaver": {
                "driver": "PostgreSQL",
                "notes": "Run the AlloyDB Auth Proxy first, then connect to localhost with SSL disabled.",
            },
            "datagrip": {
                "driver": "PostgreSQL",
                "notes": "Use a standard PostgreSQL datasource pointed at the local proxy.",
            },
            "dbvisualizer": {
                "driver": "PostgreSQL",
                "notes": "Use the local proxy endpoint and leave password blank when auto IAM auth is enabled.",
            },
        },
    }


def _render_db_info(payload: dict[str, Any]) -> None:
    """Render one human-friendly local DB recipe with tool-specific guidance."""

    summary = Table(show_header=True, header_style="bold cyan", title="Local DB Recipe")
    summary.add_column("Field")
    summary.add_column("Value")
    for field in (
        "profile",
        "service",
        "environment",
        "instance_uri",
        "database",
        "db_user",
        "service_account",
        "proxy_host",
        "proxy_port",
    ):
        summary.add_row(field, str(payload.get(field) or ""))
    data_console.print(summary)

    tools = payload["desktop_tools"]
    common = tools["common"]
    tools_table = Table(show_header=True, header_style="bold cyan", title="Desktop Tools")
    tools_table.add_column("Tool")
    tools_table.add_column("Driver")
    tools_table.add_column("Host")
    tools_table.add_column("Port")
    tools_table.add_column("Database")
    tools_table.add_column("User")
    for tool_name in ("dbeaver", "datagrip", "dbvisualizer"):
        tool = tools[tool_name]
        tools_table.add_row(
            tool_name,
            str(tool["driver"]),
            str(common["host"]),
            str(common["port"]),
            str(common["database"]),
            str(common["user"]),
        )
    data_console.print(tools_table)

    status_console.print("[bold]Commands[/bold]")
    if payload.get("adc_impersonation_command"):
        status_console.print(f"  ADC impersonation: {payload['adc_impersonation_command']}")
    status_console.print(f"  Auth Proxy:        {payload['proxy_command']}")
    status_console.print(f"  psql:              {payload['psql']}")

    if not payload.get("proxy_binary"):
        status_console.print("")
        status_console.print(
            "[yellow]alloydb-auth-proxy is not on PATH yet. Install it before using the local DB recipe.[/yellow]"
        )

    status_console.print("")
    status_console.print("[bold]Proxy env[/bold]")
    for key, value in payload["proxy_env"].items():
        status_console.print(f"  export {key}={value}")

    if payload.get("private_only_note"):
        status_console.print("")
        status_console.print(f"[yellow]{payload['private_only_note']}[/yellow]")


@db_app.command("info")
def db_info(
    profile: str = typer.Option(
        "engineers-dev",
        "--profile",
        help="Sanctioned local DB profile.",
    ),
    service: str | None = typer.Option(
        None,
        "--service",
        help="Service slug when using the runtime-like profile.",
    ),
    env: str = typer.Option(
        DEFAULT_ENVIRONMENT,
        "--env",
        help="Behavioral environment for the connection recipe.",
    ),
    all_proxy: str | None = typer.Option(
        None,
        "--all-proxy",
        help="Optional intermediary SOCKS/HTTP proxy URL for private-only AlloyDB lanes.",
    ),
    format: Format = format_option(),
) -> None:
    """Print the exact local DB recipe for CLI, psql, and desktop SQL tools."""

    try:
        payload = _db_info_payload(
            profile_name=profile,
            service=service,
            env=env,
            all_proxy=all_proxy,
        )
    except typer.BadParameter as exc:
        error(str(exc))
        raise typer.Exit(1) from exc
    except ValueError as exc:
        error(str(exc))
        raise typer.Exit(1) from exc

    if format != Format.TABLE:
        render(payload, format=format)
        return
    _render_db_info(payload)


app.add_typer(db_app, name="db")
