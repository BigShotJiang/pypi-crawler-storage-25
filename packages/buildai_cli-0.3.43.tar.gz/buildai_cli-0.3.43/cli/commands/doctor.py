"""Doctor-style diagnostics for Build AI CLI and workspace health."""

from __future__ import annotations

import typer

from cli.auth_local import DEFAULT_ENVIRONMENT, build_auth_report
from cli.commands.auth import _emit_report
from cli.output import Format, format_option

app = typer.Typer(
    no_args_is_help=True,
    help="Diagnose Build AI CLI setup before auth or local-dev issues turn into folklore.",
)


@app.command("auth")
def doctor_auth(
    profile: str | None = typer.Option(
        None,
        "--profile",
        help="Optional sanctioned auth profile to validate after the base checks.",
    ),
    service: str | None = typer.Option(
        None,
        "--service",
        help="Service slug for runtime-like profiles.",
    ),
    env: str = typer.Option(
        DEFAULT_ENVIRONMENT,
        "--env",
        help="Behavioral environment to validate against.",
    ),
    format: Format = format_option(),
) -> None:
    """Run the auth doctor so failures surface as exact, actionable checks."""

    report = build_auth_report(profile_name=profile, service=service, environment=env)
    _emit_report(report, format=format, include_state=True)
    if report.exit_code:
        raise typer.Exit(report.exit_code)
