"""Small internal API client for CLI auth flows.

This intentionally lives inside the CLI instead of reusing the standalone data
SDK. The CLI needs Build AI-specific auth endpoints like `/v1/me` that are part
of the developer/operator surface rather than the public dataset SDK contract.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx
import typer

from cli.config import resolve_api_url, resolve_credential
from cli.console import error


@dataclass(frozen=True)
class AccessStatus:
    """Represent the principal summary returned by `/v1/me`."""

    principal_display_name: str | None
    principal_subject: str | None
    principal_type: str | None
    audience: str | None
    mode: str | None
    permissions: list[str]
    boundary: dict[str, Any] | None

    def model_dump(self, *, mode: str = "json") -> dict[str, Any]:
        """Return a pydantic-like dump shape for existing CLI rendering paths."""

        del mode
        return {
            "principal_display_name": self.principal_display_name,
            "principal_subject": self.principal_subject,
            "principal_type": self.principal_type,
            "audience": self.audience,
            "mode": self.mode,
            "permissions": self.permissions,
            "boundary": self.boundary,
        }


def _raise_for_status(resp: httpx.Response) -> None:
    """Surface API errors with a stable message shape for CLI callers."""

    try:
        payload = resp.json()
    except Exception:
        payload = None

    message = None
    if isinstance(payload, dict):
        detail = payload.get("detail")
        if isinstance(detail, str):
            message = detail
        elif isinstance(detail, dict):
            message = str(detail.get("message") or detail)
        elif isinstance(payload.get("error"), dict):
            message = str(payload["error"].get("message") or payload["error"])
    if not message:
        message = resp.text or f"HTTP {resp.status_code}"
    raise RuntimeError(message)


def _extract_envelope(payload: Any) -> Any:
    """Return envelope `data` when present, otherwise the payload itself."""

    if isinstance(payload, dict) and "data" in payload:
        return payload["data"]
    return payload


class AccessResource:
    """Read the authenticated principal summary from the API."""

    def __init__(self, http_client: httpx.Client) -> None:
        self._http = http_client

    def inspect(self) -> AccessStatus:
        """Return the current credential's principal/access summary."""

        resp = self._http.get("/v1/me")
        if resp.status_code >= 400:
            _raise_for_status(resp)
        payload = _extract_envelope(resp.json())
        if not isinstance(payload, dict):
            raise RuntimeError("Unexpected /v1/me payload")
        return AccessStatus(
            principal_display_name=payload.get("principal_display_name"),
            principal_subject=payload.get("principal_subject"),
            principal_type=payload.get("principal_type"),
            audience=payload.get("audience"),
            mode=payload.get("mode"),
            permissions=list(payload.get("permissions") or []),
            boundary=None,
        )


class InternalApiClient:
    """Very small sync API client used only by the CLI."""

    def __init__(self, *, api_key: str, base_url: str, timeout: float) -> None:
        self._http = httpx.Client(
            base_url=base_url.rstrip("/"),
            timeout=timeout,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Accept": "application/json",
            },
        )
        self.access = AccessResource(self._http)

    def close(self) -> None:
        """Close the underlying HTTP client."""

        self._http.close()


def get_internal_api_client() -> InternalApiClient:
    """Create the CLI's internal API client from normal credential resolution."""

    try:
        api_key = resolve_credential()
    except RuntimeError as exc:
        error(str(exc))
        raise typer.Exit(1) from exc

    return InternalApiClient(
        api_key=api_key,
        base_url=resolve_api_url(),
        timeout=float(__import__("os").environ.get("BUILDAI_API_TIMEOUT", "300")),
    )
