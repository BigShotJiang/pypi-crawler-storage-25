"""Output formatting helpers for CLI commands."""

from __future__ import annotations

import csv
import json
import sys
from enum import Enum
from typing import Any

import typer
from pydantic import BaseModel
from rich.table import Table

from cli.console import data_console, status_console


class OutputFormat(str, Enum):
    TABLE = "table"
    JSON = "json"
    JSONL = "jsonl"
    CSV = "csv"


Format = OutputFormat


def auto_format() -> OutputFormat:
    return OutputFormat.TABLE if sys.stdout.isatty() else OutputFormat.JSON


def detect_format() -> OutputFormat:
    return auto_format()


def format_option(default: OutputFormat | None = None) -> Any:
    return typer.Option(
        default,
        "--format",
        "-f",
        help="Output format: table, json, jsonl, csv (default: auto-detect from TTY).",
    )


def _to_plain_data(value: Any) -> Any:
    if isinstance(value, BaseModel):
        return value.model_dump(mode="json")
    if isinstance(value, list):
        return [_to_plain_data(item) for item in value]
    if isinstance(value, tuple):
        return [_to_plain_data(item) for item in value]
    if isinstance(value, dict):
        return {key: _to_plain_data(item) for key, item in value.items()}
    return value


def _to_rows(data: Any) -> list[dict[str, Any]]:
    plain = _to_plain_data(data)
    if plain is None:
        return []
    if isinstance(plain, list):
        rows: list[dict[str, Any]] = []
        for item in plain:
            if isinstance(item, dict):
                rows.append(item)
            else:
                rows.append({"value": item})
        return rows
    if isinstance(plain, dict):
        return [plain]
    return [{"value": plain}]


def render(
    data: Any,
    *,
    format: OutputFormat | None = None,
    columns: list[str] | None = None,
) -> None:
    fmt = format or auto_format()
    plain = _to_plain_data(data)
    rows = _to_rows(plain)

    if fmt == OutputFormat.JSON:
        sys.stdout.write(json.dumps(plain, indent=2, default=str) + "\n")
        sys.stdout.flush()
        return
    if fmt == OutputFormat.JSONL:
        for row in rows:
            sys.stdout.write(json.dumps(row, default=str) + "\n")
        sys.stdout.flush()
        return
    if fmt == OutputFormat.CSV:
        if not rows:
            return
        cols = columns or list(rows[0].keys())
        writer = csv.DictWriter(sys.stdout, fieldnames=cols, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key) for key in cols})
        sys.stdout.flush()
        return

    if not rows:
        status_console.print("[dim]No results[/dim]")
        return

    cols = columns or list(rows[0].keys())
    table = Table(show_header=True, header_style="bold cyan")
    for col in cols:
        table.add_column(col)
    for row in rows:
        table.add_row(
            *[
                json.dumps(row.get(col), default=str)
                if isinstance(row.get(col), (dict, list))
                else str(row.get(col, ""))
                for col in cols
            ]
        )
    data_console.print(table)
    status_console.print(f"[dim]{len(rows)} row(s)[/dim]")


def output(
    data: Any,
    format: OutputFormat | None = None,
    columns: list[str] | None = None,
) -> None:
    render(data, format=format, columns=columns)
