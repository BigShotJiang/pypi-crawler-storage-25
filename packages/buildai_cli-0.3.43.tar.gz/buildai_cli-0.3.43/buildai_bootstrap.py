"""Package-local bootstrap entrypoint for the published BuildAI CLI."""

from __future__ import annotations


def main() -> None:
    """Dispatch to the real CLI main function."""

    from cli.main import main as cli_main

    cli_main()
