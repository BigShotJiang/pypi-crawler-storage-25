// Copyright (c) 2026 Juancarlo Añez (apalala@gmail.com)
// SPDX-License-Identifier: MIT OR Apache-2.0

use crate::cfg::*;
use crate::json::error::JsonError;
use crate::json::tatsu::model::TatSuModel;
use crate::peg::exp::{ERef, Exp};
use crate::peg::grammar::{Grammar, GrammarDirectives};
use crate::peg::rule::{Rule, RuleRef};

impl TryFrom<TatSuModel> for ERef {
    type Error = JsonError;

    fn try_from(model: TatSuModel) -> Result<Self, Self::Error> {
        Ok(ERef::new(Exp::try_from(model)?))
    }
}

impl Grammar {
    pub fn serde_from_json(json: &str) -> Result<Self, JsonError> {
        let mut deserializer = serde_json::Deserializer::from_str(json);
        let model: TatSuModel = serde_path_to_error::deserialize(&mut deserializer)
            .map_err(|err| JsonError::JsonPath(err.path().to_string(), err.into_inner()))?;
        let grammar = Self::try_from(model)?;
        Ok(grammar)
    }
}

impl TryFrom<TatSuModel> for Grammar {
    type Error = JsonError;

    fn try_from(model: TatSuModel) -> Result<Self, Self::Error> {
        if let TatSuModel::Grammar {
            name,
            rules,
            directives,
            keywords,
            analyzed,
        } = model
        {
            let mut rule_vec: Vec<RuleRef> = vec![];
            for rule_model in rules {
                if let TatSuModel::Rule {
                    name,
                    params,
                    exp,
                    is_name,
                    is_tokn,
                    no_memo,

                    // NOTE:
                    //  these belong to lef-recursion analysis
                    //  they are here for legacy reasons
                    is_memo,
                    is_lrec,
                } = rule_model
                {
                    let rhs = Exp::try_from(*exp)?;
                    let rule = Rule::from_parts(
                        name, params, rhs, is_name, is_tokn, no_memo, is_memo, is_lrec,
                    );
                    rule_vec.push(rule.into());
                }
            }
            let str_directives: GrammarDirectives = directives
                .iter()
                .filter_map(|(k, v)| {
                    let val_str = v.as_str().map(|s| s.to_string()).unwrap_or(v.to_string());
                    Cfg::map(k.as_str(), val_str.as_str())
                })
                .collect();
            let mut grammar = Grammar::new(name.as_str(), rule_vec.as_slice());
            grammar.analyzed = analyzed;
            grammar.set_directives(str_directives);
            grammar.keywords = keywords;
            grammar.initialize();
            Ok(grammar)
        } else {
            Err(JsonError::InvalidRoot)
        }
    }
}

impl TryFrom<TatSuModel> for Exp {
    type Error = JsonError;

    fn try_from(model: TatSuModel) -> Result<Self, Self::Error> {
        match model {
            TatSuModel::EmptyClosure => Ok(Exp::empty_closure()),
            TatSuModel::Grammar { .. } | TatSuModel::Rule { .. } => {
                Err(JsonError::UnsupportedModel(format!("{:?}", model)))
            }
            TatSuModel::RuleInclude { name, exp: _ } => Ok(Exp::rule_include(&name)),
            TatSuModel::LeftJoin { .. } => Err(JsonError::UnsupportedModel("LeftJoin".into())),
            TatSuModel::RightJoin { .. } => Err(JsonError::UnsupportedModel("RightJoin".into())),

            // --- Core Terminals ---
            TatSuModel::Cut => Ok(Exp::cut()),
            TatSuModel::EOF => Ok(Exp::eof()),
            TatSuModel::EOL => Ok(Exp::eol()),
            TatSuModel::Void => Ok(Exp::void()),

            // --- Calls and Tokens ---
            TatSuModel::Call { name, .. } => Ok(Exp::call(name.as_str())),
            TatSuModel::Token { token } => Ok(Exp::token(token.as_str())),
            TatSuModel::Pattern { pattern } => Ok(Exp::pattern(pattern.as_str())),
            TatSuModel::Constant { literal } => Ok(Exp::constant(literal.as_str().unwrap_or(""))),
            TatSuModel::Alert { literal, level } => {
                Ok(Exp::alert(literal.as_str().unwrap(), level))
            }

            // --- Unary Operators ---
            TatSuModel::Group { exp } => Ok(Exp::group(Exp::try_from(*exp)?)),
            TatSuModel::Optional { exp } => Ok(Exp::optional(Exp::try_from(*exp)?)),
            TatSuModel::Option { exp } => Ok(Exp::alt(Exp::try_from(*exp)?)),
            TatSuModel::Closure { exp } => Ok(Exp::closure(Exp::try_from(*exp)?)),
            TatSuModel::PositiveClosure { exp } => Ok(Exp::positive_closure(Exp::try_from(*exp)?)),

            // --- Lookahead ---
            TatSuModel::Lookahead { exp } => Ok(Exp::lookahead(Exp::try_from(*exp)?)),
            TatSuModel::NegativeLookahead { exp } => {
                Ok(Exp::negative_lookahead(Exp::try_from(*exp)?))
            }
            TatSuModel::SkipTo { exp } => Ok(Exp::skip_to(Exp::try_from(*exp)?)),

            // --- N-ary Operators ---
            TatSuModel::Sequence { sequence } => {
                let exprs: Result<Vec<Exp>, JsonError> =
                    sequence.into_iter().map(Exp::try_from).collect();
                Ok(Exp::sequence(exprs?.as_slice().into()))
            }
            TatSuModel::Choice { options } => {
                let exprs: Result<Vec<Exp>, JsonError> =
                    options.into_iter().map(Exp::try_from).collect();
                Ok(Exp::choice(exprs?.as_slice().into()))
            }

            // --- Joins and Gathers ---
            TatSuModel::Join { exp, sep } => {
                Ok(Exp::join(Exp::try_from(*exp)?, Exp::try_from(*sep)?))
            }
            TatSuModel::PositiveJoin { exp, sep } => Ok(Exp::positive_join(
                Exp::try_from(*exp)?,
                Exp::try_from(*sep)?,
            )),
            TatSuModel::Gather { exp, sep } => {
                Ok(Exp::gather(Exp::try_from(*exp)?, Exp::try_from(*sep)?))
            }
            TatSuModel::PositiveGather { exp, sep } => Ok(Exp::positive_gather(
                Exp::try_from(*exp)?,
                Exp::try_from(*sep)?,
            )),
            TatSuModel::Named { name, exp } => Ok(Exp::named(name.as_str(), Exp::try_from(*exp)?)),
            TatSuModel::NamedList { name, exp } => {
                Ok(Exp::named_list(name.as_str(), Exp::try_from(*exp)?))
            }
            TatSuModel::Override { exp } => Ok(Exp::override_node(Exp::try_from(*exp)?)),
            TatSuModel::OverrideList { exp } => Ok(Exp::override_list(Exp::try_from(*exp)?)),
            TatSuModel::SkipGroup { exp } => Ok(Exp::skip_group(Exp::try_from(*exp)?)),
            TatSuModel::Fail => Ok(Exp::fail()),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_grammar_from_json() {
        let filename = "grammar/calc.json";
        let json = std::fs::read_to_string(filename).expect("calc.json missing");
        println!("CALC FROM JSON");
        println!("{:#}", json);

        let _grammar = Grammar::serde_from_json(&json).unwrap();
    }
}
