"""Agent workspace lifecycle management via local clones."""

from __future__ import annotations

import logging
import shutil
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)


def create_agent_worktree(mission_dir: Path, agent_id: str) -> Path:
    """Create an isolated workspace for an agent via git clone --local.

    Clones ``mission_dir`` to ``mission_dir / "worktrees" / agent_id``,
    then checks out a new branch ``{agent_id}-work``.

    The clone is self-contained (real .git directory) and can be safely
    mounted into Docker containers.

    Returns the workspace path.
    """
    workspace_path = mission_dir / "worktrees" / agent_id

    # Remove stale workspace from previous run (defensive)
    if workspace_path.exists():
        shutil.rmtree(workspace_path)

    # Clone mission_dir → workspace (hardlinks objects, fast)
    clone_result = subprocess.run(
        ["git", "clone", "--local", str(mission_dir), str(workspace_path)],
        capture_output=True,
        cwd=str(mission_dir),
    )
    if clone_result.returncode != 0:
        stderr_msg = clone_result.stderr.decode(errors="replace").strip()
        logger.error(
            "git clone --local failed (rc=%d) for %s: %s",
            clone_result.returncode,
            agent_id,
            stderr_msg,
        )
        raise subprocess.CalledProcessError(
            clone_result.returncode,
            clone_result.args,
            clone_result.stdout,
            clone_result.stderr,
        )

    # Inherit git user config from source repo (clones don't copy local config;
    # without this, git commit fails in CI where no global config exists).
    for key in ("user.email", "user.name"):
        result = subprocess.run(
            ["git", "config", key],
            cwd=mission_dir,
            capture_output=True,
            text=True,
        )
        if result.returncode == 0 and result.stdout.strip():
            subprocess.run(
                ["git", "config", key, result.stdout.strip()],
                cwd=workspace_path,
                capture_output=True,
            )

    # Create and checkout agent work branch
    subprocess.run(
        ["git", "checkout", "-b", f"{agent_id}-work"],
        cwd=workspace_path,
        capture_output=True,
        check=True,
    )

    logger.info("Created agent workspace for %s at %s", agent_id, workspace_path)
    return workspace_path


def sync_from_main(worktree_dir: Path) -> bool:
    """Fetch latest main from origin and rebase onto it.

    Returns True on success. If the rebase fails (e.g. conflicts), aborts
    and returns False.
    """
    # Fetch latest main from origin (= mission_dir)
    fetch = subprocess.run(
        ["git", "fetch", "origin", "main"],
        cwd=worktree_dir,
        capture_output=True,
    )
    if fetch.returncode != 0:
        logger.warning(
            "Fetch failed in %s: %s",
            worktree_dir,
            fetch.stderr.decode(errors="replace"),
        )
        return False

    result = subprocess.run(
        ["git", "rebase", "origin/main"],
        cwd=worktree_dir,
        capture_output=True,
    )

    if result.returncode != 0:
        logger.warning(
            "Rebase failed in %s, aborting: %s",
            worktree_dir,
            result.stderr.decode(errors="replace"),
        )
        subprocess.run(
            ["git", "rebase", "--abort"],
            cwd=worktree_dir,
            capture_output=True,
        )
        return False

    logger.info("Synced workspace %s from origin/main", worktree_dir)
    return True


def cleanup_worktree(mission_dir: Path, agent_id: str) -> None:
    """Remove an agent's workspace directory."""
    workspace_path = mission_dir / "worktrees" / agent_id
    if workspace_path.exists():
        shutil.rmtree(workspace_path)
        logger.info("Removed agent workspace at %s", workspace_path)
