import argparse
import getpass

from volcano_flink_client.auth.auth import AuthManager
from volcano_flink_client.api import ApiClient
from volcano_flink_client.projects.projects import ProjectManager
from volcano_flink_cli.common import print_header


def login(args: argparse.Namespace):
    auth_manager = AuthManager()
    access_key = args.ak or input("请输入 Access Key (AK): ").strip()
    secret_key = args.sk or getpass.getpass("请输入 Secret Key (SK): ").strip()
    if not access_key or not secret_key:
        print("❌ AK/SK 不能为空")
        return

    credentials = auth_manager.login(
        access_key=access_key,
        secret_key=secret_key,
        region=args.region,
    )
    print(f"✅ 登录成功！账号: {credentials.access_key}")


def logout():
    auth_manager = AuthManager()
    if auth_manager.logout():
        print("✅ 退出登录成功")
    else:
        print("❌ 退出登录失败")


def set_tos_jar_prefix(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    updated = auth_manager.set_tos_jar_prefix(args.tos_jar_prefix)
    print("✅ 已保存 TOS Jar 存储路径")
    print(f"TOS Jar Prefix: {updated.tos_jar_prefix}")


def set_region(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    region = str(args.region).strip()
    if not region:
        print("❌ region 不能为空")
        return
    updated = auth_manager.set_region(region)
    print("✅ 已保存默认 Region")
    print(f"Region: {updated.region}")


def show_config():
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    print_header("当前配置")
    print(f"Region: {credentials.region}")
    print(f"TOS Jar Prefix: {credentials.tos_jar_prefix or ''}")
    print(f"Default Project ID: {credentials.default_project_id or ''}")
    print(f"Default Project Name: {credentials.default_project_name or ''}")


def set_default_project(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    if args.project_id:
        updated = auth_manager.set_default_project_id(args.project_id, project_name=None)
        print("✅ 已保存默认项目")
        print(f"Default Project ID: {updated.default_project_id}")
        return
    project_name = getattr(args, "name", None) or getattr(args, "project_name", None)
    if not project_name:
        raise Exception("请提供 --project-id 或 --name")

    api_client = ApiClient(credentials)
    project_manager = ProjectManager(api_client)
    projects = project_manager.list_projects(search=project_name, page=1, page_size=200)

    exact = [p for p in projects if p.name == project_name]
    candidates = exact or projects
    if not candidates:
        raise Exception("未找到指定项目名称，请使用 projects list 确认名称或直接传 --project-id")
    match = candidates[0]
    updated = auth_manager.set_default_project_id(match.id, project_name=match.name)
    print("✅ 已保存默认项目")
    print(f"Default Project ID: {updated.default_project_id}")
    print(f"Project Name: {match.name}")


def attach_auth_and_config_subcommands(subparsers):
    login_parser = subparsers.add_parser("login", help="登录火山引擎账号")
    login_parser.add_argument("--ak", help="访问密钥 Access Key（不传则交互式输入）")
    login_parser.add_argument("--sk", help="安全密钥 Secret Key（不传则交互式输入）")
    login_parser.add_argument("--region", default="cn-beijing", help="区域 (默认: cn-beijing)")
    login_parser.set_defaults(func=login)

    logout_parser = subparsers.add_parser("logout", help="退出登录")
    logout_parser.set_defaults(func=lambda _args: logout())

    config_parser = subparsers.add_parser("config", help="配置管理")
    config_parser.set_defaults(func=lambda _args, p=config_parser: p.print_help())
    config_subparsers = config_parser.add_subparsers(title="配置子命令")

    config_show_parser = config_subparsers.add_parser("show", help="查看当前配置")
    config_show_parser.set_defaults(func=lambda _args: show_config())

    config_set_region_parser = config_subparsers.add_parser("set-region", help="设置默认 Region")
    config_set_region_parser.add_argument("--region", required=True, help="例如 cn-beijing")
    config_set_region_parser.set_defaults(func=set_region)

    config_set_tos_parser = config_subparsers.add_parser("set-tos-jar-prefix", help="设置 TOS Jar 存储路径")
    config_set_tos_parser.add_argument("--tos-jar-prefix", required=True, help="例如 tos://<bucket>/path/to/jars")
    config_set_tos_parser.set_defaults(func=set_tos_jar_prefix)

    config_set_project_parser = config_subparsers.add_parser("set-default-project", help="设置默认项目")
    config_set_project_parser.add_argument("--project-id", help="项目ID")
    config_set_project_parser.add_argument("-n", "--name", help="项目名称")
    config_set_project_parser.add_argument("--project-name", help="项目名称（兼容参数）")
    config_set_project_parser.set_defaults(func=set_default_project)
