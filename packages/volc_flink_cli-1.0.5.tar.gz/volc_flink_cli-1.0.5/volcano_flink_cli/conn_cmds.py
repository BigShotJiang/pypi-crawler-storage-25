import argparse
import getpass
import json
from datetime import datetime, timedelta
from typing import List, Optional

from volcano_flink_client.conn.kafka import KafkaConnectionManager, KafkaEndpointConfig, KafkaInstanceConfig
from volcano_flink_cli.common import print_header, print_table


def _prompt_optional_text(label: str, default: Optional[str] = None) -> Optional[str]:
    suffix = f" [{default}]" if default not in (None, "") else ""
    value = input(f"{label}{suffix}: ").strip()
    if value:
        return value
    return default if default not in (None, "") else None


def _prompt_required_text(label: str, default: Optional[str] = None) -> str:
    while True:
        value = _prompt_optional_text(label, default=default)
        if value:
            return value
        print(f"❌ {label} 不能为空")


def _mask_secret(value: Optional[str]) -> str:
    if not value:
        return ""
    text = str(value)
    if len(text) <= 4:
        return "*" * len(text)
    return text[:2] + "*" * (len(text) - 4) + text[-2:]


def _pick_from_options(label: str, options: List[str]) -> str:
    if not options:
        raise ValueError("无可选项")
    if len(options) == 1:
        return options[0]
    while True:
        print(f"{label}:")
        for index, item in enumerate(options, 1):
            print(f"  {index}. {item}")
        value = input("请输入序号: ").strip()
        if value.isdigit():
            pos = int(value)
            if 1 <= pos <= len(options):
                return options[pos - 1]
        print("❌ 无效序号，请重新输入")


def kafka_instance_add(args: argparse.Namespace):
    manager = KafkaConnectionManager()
    instance_name_arg = str(getattr(args, "name", None) or "").strip()
    instance_name = instance_name_arg or _prompt_required_text("Kafka instance 名称")
    existing = manager.get_instance(instance_name=instance_name)
    topic_arg = getattr(args, "topic", None)
    group_id_arg = getattr(args, "group_id", None)
    if topic_arg is not None:
        topic_value = str(topic_arg).strip() or None
    else:
        topic_value = _prompt_optional_text("默认 Topic", default=existing.topic if existing else None)
    if group_id_arg is not None:
        group_id_value = str(group_id_arg).strip() or None
    else:
        group_id_value = _prompt_optional_text("默认 Group ID", default=existing.group_id if existing else None)
    instance = KafkaInstanceConfig(
        name=instance_name,
        topic=topic_value,
        group_id=group_id_value,
        default_endpoint=existing.default_endpoint if existing else None,
        endpoints=list(existing.endpoints) if existing and existing.endpoints else [],
    )
    if instance.default_endpoint is None and instance.endpoints:
        instance.default_endpoint = instance.endpoints[0].name
    manager.save_instance(instance)
    print("✅ 已保存 Kafka instance 配置")
    print(f"Instance: {instance.name}")
    print(f"Default Topic: {instance.topic or ''}")
    print(f"Default Group ID: {instance.group_id or ''}")
    print(f"Default Endpoint: {instance.default_endpoint or ''}")
    print(f"Endpoints: {', '.join(item.name for item in instance.endpoints)}")


def kafka_instance_rm(args: argparse.Namespace):
    manager = KafkaConnectionManager()
    config = manager.load_config()
    if not config or not getattr(config, "instances", None):
        print("无数据")
        return
    instance_name = str(getattr(args, "instance", None) or "").strip() or None
    if not instance_name:
        instance_name = _pick_from_options("选择要删除的 Kafka instance", [item.name for item in config.instances])
    manager.clear_config(instance_name=instance_name)
    print(f"✅ 已删除 Kafka instance: {instance_name}")


def kafka_instance_list(_args: argparse.Namespace):
    manager = KafkaConnectionManager()
    config = manager.load_config()
    print_header("Kafka Instances")
    if not config or not getattr(config, "instances", None):
        print("无数据")
        return
    rows = []
    for inst in config.instances:
        endpoints = getattr(inst, "endpoints", []) or []
        rows.append([inst.name, inst.topic or "", inst.group_id or "", inst.default_endpoint or "", str(len(endpoints))])
    print_table(rows, ["Instance", "Topic", "GroupId", "DefaultEndpoint", "Endpoints"])
    print(f"\n📊 总计: {len(rows)} 个 instance")


def kafka_endpoint_list(args: argparse.Namespace):
    manager = KafkaConnectionManager()
    config = manager.load_config()
    print_header("Kafka Endpoints")
    if not config or not getattr(config, "instances", None):
        print("无数据")
        return
    target_instance = str(args.instance).strip() if getattr(args, "instance", None) else None
    rows = []
    for inst in config.instances:
        if target_instance and inst.name != target_instance:
            continue
        for ep in getattr(inst, "endpoints", []) or []:
            rows.append(
                [
                    inst.name,
                    ep.name,
                    ep.bootstrap_servers,
                    ep.security_protocol,
                    ep.sasl_mechanism or "",
                    ep.username or "",
                    "YES" if ep.password else "",
                ]
            )
    if not rows:
        print("无数据")
        return
    print_table(rows, ["Instance", "Endpoint", "BootstrapServers", "Protocol", "SASL", "Username", "PasswordSet"])
    print(f"\n📊 总计: {len(rows)} 个 endpoint")


def kafka_endpoint_detail(args: argparse.Namespace):
    manager = KafkaConnectionManager()
    print_header("Kafka Endpoint Detail")
    instance, endpoint = manager.resolve_instance_endpoint(
        instance_name=str(args.instance).strip() if getattr(args, "instance", None) else None,
        endpoint_name=str(args.endpoint).strip() if getattr(args, "endpoint", None) else None,
    )
    show_password = bool(getattr(args, "show_password", False))
    print(f"Instance: {instance.name}")
    print(f"Endpoint: {endpoint.name}")
    print(f"Bootstrap Servers: {endpoint.bootstrap_servers}")
    print(f"Security Protocol: {endpoint.security_protocol}")
    print(f"SASL Mechanism: {endpoint.sasl_mechanism or ''}")
    print(f"Username: {endpoint.username or ''}")
    if endpoint.password:
        if show_password:
            print(f"Password: {endpoint.password}")
        else:
            print(f"Password: {_mask_secret(endpoint.password)}")
            print("Password: 已设置（使用 --show-password 显示明文）")
    else:
        print("Password: ")


def kafka_endpoint_add(args: argparse.Namespace):
    manager = KafkaConnectionManager()
    instance_name = str(getattr(args, "instance", None) or "").strip()
    instance = manager.get_instance(instance_name=instance_name)
    if instance is None:
        raise ValueError(f"未找到 Kafka instance `{instance_name}`，请先执行 `volc_flink conn kafka instance add`")
    endpoints = list(getattr(instance, "endpoints", []) or [])

    interactive = not any(
        [
            getattr(args, "name", None) is not None,
            getattr(args, "bootstrap_servers", None) is not None,
            getattr(args, "security_protocol", None) is not None,
            getattr(args, "sasl_mechanism", None) is not None,
            getattr(args, "username", None) is not None,
            getattr(args, "password", None) is not None,
            bool(getattr(args, "set_default", False)),
        ]
    )

    endpoint_name_arg = str(getattr(args, "name", None) or "").strip() or None
    default_endpoint_name = f"endpoint-{len(endpoints) + 1}"
    if endpoint_name_arg:
        if any(item.name == endpoint_name_arg for item in endpoints):
            raise ValueError(f"Kafka instance `{instance.name}` 已存在 endpoint `{endpoint_name_arg}`")
        endpoint_name = endpoint_name_arg
    elif interactive:
        while True:
            endpoint_name = _prompt_required_text("Endpoint 名称", default=default_endpoint_name)
            if all(item.name != endpoint_name for item in endpoints):
                break
            print(f"❌ endpoint 名称 `{endpoint_name}` 已存在，请重新输入")
    else:
        endpoint_name = default_endpoint_name

    bootstrap_servers = str(getattr(args, "bootstrap_servers", None) or "").strip() or None
    if not bootstrap_servers:
        if interactive:
            bootstrap_servers = _prompt_required_text("Bootstrap Servers")
        else:
            raise ValueError("缺少参数: --bootstrap-servers")

    security_protocol = str(getattr(args, "security_protocol", None) or "").strip() or None
    if security_protocol:
        security_protocol_value = security_protocol
    else:
        security_protocol_value = (
            (_prompt_optional_text("Security Protocol", default="PLAINTEXT") or "PLAINTEXT") if interactive else "PLAINTEXT"
        )

    sasl_mechanism = str(getattr(args, "sasl_mechanism", None) or "").strip() or None
    if sasl_mechanism:
        sasl_mechanism_value = sasl_mechanism
    else:
        sasl_mechanism_value = _prompt_optional_text("SASL Mechanism") if interactive else None

    username_raw = getattr(args, "username", None)
    if username_raw is not None:
        username_value = str(username_raw).strip() or None
    else:
        username_value = _prompt_optional_text("Kafka 用户名") if interactive else None

    password = getattr(args, "password", None)
    if password is None and username_value and interactive:
        typed_password = getpass.getpass("Kafka 密码（可留空）: ")
        password = typed_password or None

    endpoints.append(
        KafkaEndpointConfig(
            name=endpoint_name,
            bootstrap_servers=bootstrap_servers,
            security_protocol=security_protocol_value,
            sasl_mechanism=sasl_mechanism_value,
            username=username_value,
            password=password,
        )
    )

    default_endpoint = instance.default_endpoint
    if getattr(args, "set_default", False) or not default_endpoint:
        default_endpoint = endpoint_name

    updated = KafkaInstanceConfig(
        name=instance.name,
        topic=instance.topic,
        group_id=instance.group_id,
        default_endpoint=default_endpoint,
        endpoints=endpoints,
    )
    manager.save_instance(updated)
    print("✅ 已保存 Kafka endpoint 配置")
    print(f"Instance: {updated.name}")
    print(f"Endpoint: {endpoint_name}")
    print(f"Default Endpoint: {updated.default_endpoint or ''}")


def kafka_endpoint_rm(args: argparse.Namespace):
    manager = KafkaConnectionManager()
    instance_name = str(getattr(args, "instance", None) or "").strip()
    instance = manager.get_instance(instance_name=instance_name)
    if instance is None:
        raise ValueError(f"未找到 Kafka instance `{instance_name}`")
    endpoints = list(getattr(instance, "endpoints", []) or [])
    if not endpoints:
        print("无数据")
        return
    endpoint_name = str(getattr(args, "endpoint", None) or "").strip() or None
    if not endpoint_name:
        endpoint_name = _pick_from_options("选择要删除的 endpoint", [item.name for item in endpoints])
    remaining = [item for item in endpoints if item.name != endpoint_name]
    if len(remaining) == len(endpoints):
        available_names = ", ".join(item.name for item in endpoints)
        raise ValueError(f"Kafka instance `{instance.name}` 未找到 endpoint `{endpoint_name}`，可选值: {available_names}")

    default_endpoint = instance.default_endpoint
    if default_endpoint == endpoint_name:
        default_endpoint = remaining[0].name if remaining else None

    updated = KafkaInstanceConfig(
        name=instance.name,
        topic=instance.topic,
        group_id=instance.group_id,
        default_endpoint=default_endpoint,
        endpoints=remaining,
    )
    manager.save_instance(updated)
    print("✅ 已删除 Kafka endpoint 配置")
    print(f"Instance: {updated.name}")
    print(f"Endpoint: {endpoint_name}")
    print(f"Default Endpoint: {updated.default_endpoint or ''}")


def kafka_messages_consume(args: argparse.Namespace):
    manager = KafkaConnectionManager()
    print_header("Kafka 消息消费")
    try:
        start_value = str(args.start) if getattr(args, "start", None) else (datetime.utcnow() - timedelta(hours=3)).strftime('%Y-%m-%dT%H:%M:%SZ')
        messages = manager.consume_messages(
            partition=int(args.partition) if getattr(args, "partition", None) is not None else None,
            start_time=start_value,
            end_time=str(args.end) if getattr(args, "end", None) else None,
            limit=int(args.limit),
            instance_name=str(args.instance).strip() if getattr(args, "instance", None) else None,
            endpoint_name=str(args.endpoint).strip() if getattr(args, "endpoint", None) else None,
            topic=str(args.topic).strip() if getattr(args, "topic", None) else None,
            group_id=str(args.group_id).strip() if getattr(args, "group_id", None) else None,
            poll_timeout=float(args.poll_timeout),
            max_idle_polls=int(args.max_idle_polls),
            offsets_timeout=float(args.offsets_timeout),
        )
        if getattr(args, "raw", False):
            print(json.dumps(messages, ensure_ascii=False, indent=2))
            return
        if not messages:
            print("无数据")
            return
        for index, item in enumerate(messages, 1):
            timestamp_ms = item.get("timestamp_ms")
            timestamp_text = "-"
            if timestamp_ms is not None:
                timestamp_text = datetime.fromtimestamp(timestamp_ms / 1000.0).strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
            print(f"\n[{index}] Topic: {item.get('topic')} Partition: {item.get('partition')} Offset: {item.get('offset')}")
            print(f"    Timestamp: {timestamp_text}")
            print(f"    Key: {item.get('key') or '-'}")
            print("    Value:")
            print(item.get("value") or "")
        print(f"\n📊 总计: {len(messages)} 条消息")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def attach_conn_subcommands(parent_parser: argparse.ArgumentParser):
    parent_parser.set_defaults(func=lambda _args, p=parent_parser: p.print_help())
    conn_subparsers = parent_parser.add_subparsers(title="连接子命令")

    kafka_parser = conn_subparsers.add_parser("kafka", help="Kafka 连接")
    kafka_parser.set_defaults(func=lambda _args, p=kafka_parser: p.print_help())
    kafka_subparsers = kafka_parser.add_subparsers(title="Kafka 子命令")

    kafka_instance_parser = kafka_subparsers.add_parser("instance", help="列出 Kafka instance")
    kafka_instance_parser.set_defaults(func=kafka_instance_list)
    kafka_instance_subparsers = kafka_instance_parser.add_subparsers(title="Kafka instance 子命令")

    kafka_instance_add_parser = kafka_instance_subparsers.add_parser("add", help="新增或更新 Kafka instance")
    kafka_instance_add_parser.add_argument("--name", help="Kafka instance 名称；不传则交互输入")
    kafka_instance_add_parser.add_argument("--topic", help="instance 级默认 Topic；不传则交互输入")
    kafka_instance_add_parser.add_argument("--group-id", help="instance 级默认 Group ID；不传则交互输入")
    kafka_instance_add_parser.set_defaults(func=kafka_instance_add)

    kafka_instance_rm_parser = kafka_instance_subparsers.add_parser("rm", help="删除 Kafka instance")
    kafka_instance_rm_parser.add_argument("--instance", help="Kafka instance 名称；不传则交互选择")
    kafka_instance_rm_parser.set_defaults(func=kafka_instance_rm)

    kafka_endpoint_parser = kafka_subparsers.add_parser("endpoint", help="列出 Kafka endpoint")
    kafka_endpoint_parser.add_argument("--instance", help="仅列出指定 Kafka instance 的 endpoints")
    kafka_endpoint_parser.set_defaults(func=kafka_endpoint_list)
    kafka_endpoint_subparsers = kafka_endpoint_parser.add_subparsers(title="Kafka endpoint 子命令")

    kafka_endpoint_detail_parser = kafka_endpoint_subparsers.add_parser("detail", help="查看 Kafka endpoint 详情")
    kafka_endpoint_detail_parser.add_argument("--instance", required=True, help="Kafka instance 名称")
    kafka_endpoint_detail_parser.add_argument("--endpoint", required=True, help="Kafka endpoint 名称")
    kafka_endpoint_detail_parser.add_argument("--show-password", action="store_true", help="显示 password 明文")
    kafka_endpoint_detail_parser.set_defaults(func=kafka_endpoint_detail)

    kafka_endpoint_add_parser = kafka_endpoint_subparsers.add_parser("add", help="为 Kafka instance 增加接入点")
    kafka_endpoint_add_parser.add_argument("--instance", required=True, help="Kafka instance 名称")
    kafka_endpoint_add_parser.add_argument("--name", help="Kafka endpoint 名称；不传则交互输入")
    kafka_endpoint_add_parser.add_argument("--bootstrap-servers", help="bootstrap servers；不传则交互输入")
    kafka_endpoint_add_parser.add_argument("--security-protocol", help="协议，默认 PLAINTEXT")
    kafka_endpoint_add_parser.add_argument("--sasl-mechanism", help="SASL 机制，默认不设置")
    kafka_endpoint_add_parser.add_argument("--username", help="用户名，默认不设置")
    kafka_endpoint_add_parser.add_argument("--password", help="密码，默认不设置")
    kafka_endpoint_add_parser.add_argument("--set-default", action="store_true", dest="set_default", help="将该 endpoint 设为默认")
    kafka_endpoint_add_parser.set_defaults(func=kafka_endpoint_add)

    kafka_endpoint_rm_parser = kafka_endpoint_subparsers.add_parser("rm", help="为 Kafka instance 删除接入点")
    kafka_endpoint_rm_parser.add_argument("--instance", required=True, help="Kafka instance 名称")
    kafka_endpoint_rm_parser.add_argument("--endpoint", help="Kafka endpoint 名称；不传则交互选择")
    kafka_endpoint_rm_parser.set_defaults(func=kafka_endpoint_rm)

    kafka_messages_parser = kafka_subparsers.add_parser("messages", help="Kafka 消息操作")
    kafka_messages_parser.set_defaults(func=lambda _args, p=kafka_messages_parser: p.print_help())
    kafka_messages_subparsers = kafka_messages_parser.add_subparsers(title="Kafka 消息子命令")

    kafka_messages_consume_parser = kafka_messages_subparsers.add_parser("consume", help="按时间范围消费消息")
    kafka_messages_consume_parser.add_argument("--partition", type=int, help="分区号；不传则从所有 partition 消费")
    kafka_messages_consume_parser.add_argument("--start", help="开始时间，如 2024-07-01T00:00:00Z；不传默认最近 3 小时")
    kafka_messages_consume_parser.add_argument("--end", help="结束时间，默认当前时间")
    kafka_messages_consume_parser.add_argument("--limit", type=int, default=10, help="最多返回条数，默认 10")
    kafka_messages_consume_parser.add_argument("--instance", help="Kafka instance 名称；存在多个 instance 时建议显式指定")
    kafka_messages_consume_parser.add_argument("--endpoint", help="Kafka endpoint 名称；不传则使用 instance 默认 endpoint")
    kafka_messages_consume_parser.add_argument("--topic", help="覆盖默认 Topic")
    kafka_messages_consume_parser.add_argument("--group-id", help="覆盖默认 Group ID")
    kafka_messages_consume_parser.add_argument("--poll-timeout", type=float, default=1.0, help="单次 poll 超时时间（秒），默认 1.0")
    kafka_messages_consume_parser.add_argument("--max-idle-polls", type=int, default=3, help="连续空轮询次数上限，默认 3")
    kafka_messages_consume_parser.add_argument("--offsets-timeout", type=float, default=10.0, help="按时间查找起始 offset 的超时时间（秒），默认 10")
    kafka_messages_consume_parser.add_argument("--raw", action="store_true", help="输出原始 JSON")
    kafka_messages_consume_parser.set_defaults(func=kafka_messages_consume)


def attach_conn_and_connection_subcommands(subparsers):
    conn_parser = subparsers.add_parser("conn", help="连接上下游资源")
    attach_conn_subcommands(conn_parser)

    connection_parser = subparsers.add_parser("connection", help="连接上下游资源（别名）")
    attach_conn_subcommands(connection_parser)
