import argparse
import json

from volcano_flink_client.auth.auth import AuthManager
from volcano_flink_client.api import ApiClient
from volcano_flink_client.sessions.sessions import SessionClusterManager
from volcano_flink_cli.common import _format_session_flinkui, _join_url, _parse_kv_list, _resolve_project_id, print_header, print_table


def sessions_list(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    manager = SessionClusterManager(api_client, project_id)
    print_header("Session 集群列表")
    try:
        clusters = manager.list_clusters(page=1, page_size=50)
        if getattr(args, "json", False):
            print(json.dumps([c.raw for c in clusters], ensure_ascii=False, indent=2))
            return
        rows = []
        for c in clusters:
            uri = SessionClusterManager.pick_uri_path(c.raw) if getattr(args, "with_uri", False) else ""
            rows.append([c.id, c.name, c.runtime_status, c.engine_version, c.resource_pool_name, c.cluster_id, c.account_id, uri])
        print_table(rows, ["Id", "Name", "RuntimeStatus", "EngineVersion", "ResourcePool", "ClusterId", "AccountId", "UriPath"])
        print(f"\n📊 总计: {len(clusters)} 个 Session 集群")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def sessions_create(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    manager = SessionClusterManager(api_client, project_id)
    print_header("创建 Session 集群")
    try:
        dynamic = {}
        if getattr(args, "dynamic_properties", None):
            dynamic.update(json.loads(args.dynamic_properties))
        dynamic.update(_parse_kv_list(getattr(args, "kv", None)))
        cluster = manager.create_cluster(
            name=args.name,
            resource_pool_id=args.resource_pool_id,
            vcu=args.vcu,
            min_replica=args.min_replica,
            max_replica=args.max_replica,
            engine_version=args.engine_version,
            properties=dynamic or None,
        )
        print("✅ 创建成功")
        print(f"Id: {cluster.id}")
        print(f"Name: {cluster.name}")
        print(f"RuntimeStatus: {cluster.runtime_status}")
        print(f"EngineVersion: {cluster.engine_version}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def sessions_start(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    manager = SessionClusterManager(api_client, project_id)
    print_header("启动 Session 集群")
    try:
        manager.start_cluster(args.id)
        print("✅ 已发起启动")
        print(f"Id: {args.id}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def sessions_stop(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    manager = SessionClusterManager(api_client, project_id)
    print_header("停止 Session 集群")
    try:
        manager.stop_cluster(args.id)
        print("✅ 已发起停止")
        print(f"Id: {args.id}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def sessions_ui(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    manager = SessionClusterManager(api_client, project_id)
    print_header("Session FlinkUI")
    try:
        clusters = manager.list_clusters(page=1, page_size=200)
        target = None
        if getattr(args, "id", None):
            target = next((c for c in clusters if c.id == args.id), None)
        else:
            target_name = str(args.name).strip()
            matches = [c for c in clusters if c.name == target_name]
            if len(matches) == 1:
                target = matches[0]
            elif len(matches) > 1:
                raise Exception("名称匹配到多个 Session 集群，请改用 --id")
        if not target:
            raise Exception("未找到指定 Session 集群")
        hit = target.raw if isinstance(target.raw, dict) else {}
        uri = SessionClusterManager.pick_uri_path(hit)
        complete = _format_session_flinkui(uri)
        if complete:
            print(f"FlinkUI: {complete}")
            return
        gateway = hit.get("Gateway") or {}
        endpoint = None
        if isinstance(gateway, dict):
            gw = gateway.get("Internal")
            if not isinstance(gw, dict):
                gw = gateway.get("Gateway")
            if isinstance(gw, dict):
                endpoint = SessionClusterManager.pick_gateway_endpoint(gw)
        if endpoint:
            root = _join_url(endpoint, "")
            print(f"Gateway: {root}")
            print(f"Jobs API: {_join_url(endpoint, '/jobs/overview')}")
            return
        raise Exception("未找到 FlinkUI 信息，可能集群尚未就绪")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def attach_sessions_subcommands(subparsers):
    sessions_parser = subparsers.add_parser("sessions", help="Session 集群")
    sessions_parser.set_defaults(func=lambda _args, p=sessions_parser: p.print_help())
    sessions_parser.add_argument("-p", "--project", help="项目名称（可省略，使用默认项目）")
    sessions_parser.add_argument("--project-id", help="项目ID（兼容参数）")
    sessions_subparsers = sessions_parser.add_subparsers(title="sessions 子命令")

    sessions_list_parser = sessions_subparsers.add_parser("list", help="列举 Session 集群")
    sessions_list_parser.add_argument("--raw", dest="json", action="store_true", help="输出原始 JSON")
    sessions_list_parser.add_argument("--with-uri", action="store_true", help="附带 UriPath")
    sessions_list_parser.set_defaults(func=sessions_list)

    sessions_create_parser = sessions_subparsers.add_parser("create", help="创建 Session 集群")
    sessions_create_parser.add_argument("--name", required=True, help="集群名称")
    sessions_create_parser.add_argument("--resource-pool-id", required=True, help="资源池ID")
    sessions_create_parser.add_argument("--vcu", type=int, required=True, help="VCU")
    sessions_create_parser.add_argument("--min-replica", type=int, required=True, help="最小副本数")
    sessions_create_parser.add_argument("--max-replica", type=int, required=True, help="最大副本数")
    sessions_create_parser.add_argument("--engine-version", required=True, help="引擎版本")
    sessions_create_parser.add_argument("--dynamic-properties", default="", help="DynamicProperties JSON")
    sessions_create_parser.add_argument("--kv", action="append", help="DynamicProperties 追加，格式 key=value，可重复")
    sessions_create_parser.set_defaults(func=sessions_create)

    sessions_start_parser = sessions_subparsers.add_parser("start", help="启动 Session 集群")
    sessions_start_parser.add_argument("--id", required=True, help="Session 集群 ID")
    sessions_start_parser.set_defaults(func=sessions_start)

    sessions_stop_parser = sessions_subparsers.add_parser("stop", help="停止 Session 集群")
    sessions_stop_parser.add_argument("--id", required=True, help="Session 集群 ID")
    sessions_stop_parser.set_defaults(func=sessions_stop)

    sessions_ui_parser = sessions_subparsers.add_parser("ui", help="输出 Session 集群 FlinkUI 地址")
    sessions_ui_id_group = sessions_ui_parser.add_mutually_exclusive_group(required=True)
    sessions_ui_id_group.add_argument("--id", required=False, help="Session 集群 ID")
    sessions_ui_id_group.add_argument("--name", required=False, help="Session 集群名称")
    sessions_ui_parser.set_defaults(func=sessions_ui)
