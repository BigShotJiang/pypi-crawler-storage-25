import argparse
import json
from pathlib import Path
from typing import Any, Dict, List

from volcano_flink_client.api import ApiClient
from volcano_flink_client.auth.auth import AuthManager
from volcano_flink_client.drafts.drafts import DraftManager
from volcano_flink_client.resource_pools.resource_pools import ResourcePoolManager
from volcano_flink_cli.common import (
    _draft_console_url,
    _job_manage_url,
    _resolve_project_id,
    print_header,
    print_table,
)


def list_drafts(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()

    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)

    print_header("草稿列表")
    try:
        apps = draft_manager.list_draft_applications(type="JOB")
        directory = str(getattr(args, "directory", "") or "").strip()
        if directory:
            if "/" in directory:
                path = "/" + "/".join([p for p in directory.strip("/").split("/") if p])
                apps = [a for a in apps if a.directory_path == path]
            else:
                apps = [a for a in apps if a.directory_name == directory]
        data = []
        for a in apps:
            data.append(
                [
                    a.id,
                    a.name,
                    a.job_type,
                    a.directory_path,
                    a.modified_time,
                    "true" if a.is_deployed else "false",
                    a.app_id or "",
                ]
            )
        print_table(data, ["草稿ID", "名称", "类型", "目录路径", "更新时间", "已部署", "AppId"])
        print(f"\n📊 总计: {len(apps)} 个草稿")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def list_draft_directories(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("草稿目录列表")
    try:
        directories = draft_manager.list_draft_directories(type="JOB")
        data = []
        for d in directories:
            data.append([d.id, d.name, d.path, d.parent_id or "", d.create_time])
        print_table(data, ["目录ID", "目录名称", "目录路径", "父目录ID", "创建时间"])
        print(f"\n📊 总计: {len(directories)} 个目录")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def create_draft_directory(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("创建草稿目录")
    try:
        result = draft_manager.ensure_directory_path(path=str(args.name), directory_type="JOB")
        print("✅ 创建成功")
        print(f"Path: {result.get('Path')}")
        print(f"Id: {result.get('Id')}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def delete_draft_directory(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("删除草稿目录")
    try:
        dir_id = str(getattr(args, "id", "") or "").strip()
        raw = str(getattr(args, "name", "") or "").strip()
        if not dir_id and not raw:
            raise Exception("请提供 --id 或 --name")
        if not dir_id:
            directories = draft_manager.list_draft_directories(type="JOB")
            want = "/" + "/".join([p for p in raw.strip("/").split("/") if p])
            hit = None
            for d in directories:
                if d.path == want:
                    hit = d
                    break
            if not hit or not hit.id:
                raise Exception("未找到目录路径，请使用 drafts dirs 查看可用目录")
            dir_id = hit.id
        draft_manager.delete_directory(dir_id)
        print("✅ 删除成功")
        if raw:
            print(f"Path: {raw}")
        print(f"Id: {dir_id}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def delete_draft_cmd(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("删除草稿")
    try:
        draft_id = str(getattr(args, "id", "") or "").strip()
        draft_ref = str(getattr(args, "name", "") or "").strip()
        if not draft_id and not draft_ref:
            raise Exception("请提供 --id 或 --name")
        if not draft_id:
            draft_id = draft_manager.resolve_draft_id(draft_ref)
        draft_manager.delete_draft(draft_id)
        print("✅ 删除成功")
        if draft_ref:
            print(f"Name: {draft_ref}")
        print(f"Id: {draft_id}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def get_draft_content(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("草稿内容")
    try:
        draft_ref = args.draft_id
        draft_id = draft_ref if str(draft_ref).isdigit() else draft_manager.resolve_draft_id(str(draft_ref))
        draft = draft_manager.get_draft(draft_id)
        content = draft_manager.get_draft_content(draft_id)
        print(f"草稿ID: {draft.id}")
        print(f"名称: {draft.name}")
        print(f"类型: {draft.type}")
        if content.sql:
            print("SQL:")
            print(content.sql)
        if content.jar_uris:
            print("JAR:")
            for u in content.jar_uris:
                print(u)
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def validate_draft_cmd(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("SQL 校验")
    try:
        draft_ref = args.draft_id
        draft_id = draft_ref if str(draft_ref).isdigit() else draft_manager.resolve_draft_id(str(draft_ref))
        draft = draft_manager.get_draft(draft_id)
        if "SQL" not in str(draft.type or "").upper():
            raise Exception(f"仅支持 SQL 类型草稿校验，当前 JobType={draft.type}")
        resp = draft_manager.validate_draft(draft_id)
        if getattr(args, "raw", False):
            print(json.dumps(resp, ensure_ascii=False, indent=2))
            return
        result: Dict[str, Any] = {}
        if isinstance(resp, dict) and isinstance(resp.get("Result"), dict):
            result = resp["Result"]
        elif isinstance(resp, dict) and "Data" in resp:
            result = resp
        ok = result.get("Data")
        vtype = str(result.get("Type") or "")
        reason = str(result.get("Reason") or "").strip()
        solution = str(result.get("Solution") or "").strip()
        msg = str(result.get("Message") or "").rstrip()
        if ok is True:
            print("✅ SQL 语法校验通过")
            return
        print("❌ SQL 校验失败")
        if vtype:
            print(f"Type: {vtype}")
        if reason:
            print(f"Reason: {reason}")
        if solution:
            print(f"Solution: {solution}")
        if msg:
            print(msg)
        else:
            print(json.dumps(result, ensure_ascii=False, indent=2))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def list_draft_apps(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("草稿列表")
    try:
        apps = draft_manager.list_draft_applications(type="JOB")
        if args.directory:
            directory = args.directory.strip()
            if "/" in directory:
                path = "/" + "/".join([p for p in directory.strip("/").split("/") if p])
                apps = [a for a in apps if a.directory_path == path]
            else:
                apps = [a for a in apps if a.directory_name == directory]
        data = []
        for a in apps:
            data.append(
                [
                    a.id,
                    a.name,
                    a.job_type,
                    a.directory_path,
                    a.modified_time,
                    "true" if a.is_deployed else "false",
                    a.app_id or "",
                ]
            )
        print_table(data, ["草稿ID", "名称", "类型", "目录路径", "更新时间", "已部署", "AppId"])
        print(f"\n📊 总计: {len(apps)} 个草稿")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def create_draft(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()

    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)

    print_header("创建草稿")
    try:
        job_type = args.job_type
        if not job_type:
            if args.type not in ("sql", "jar") or args.mode not in ("streaming", "batch"):
                raise Exception("请使用 --job-type 或同时提供 --type (sql|jar) 与 --mode (streaming|batch)")
            job_type = f"FLINK_{args.mode.upper()}_{args.type.upper()}"

        engine_version = args.engine_version
        engine_version_map = {
            "FLINK_1_16": "FLINK_VERSION_1_16",
            "FLINK_1_17": "FLINK_VERSION_1_17",
            "FLINK_1_20": "FLINK_VERSION_1_20",
        }
        engine_version = engine_version_map.get(engine_version, engine_version)

        directory_id = args.directory_id
        if not directory_id:
            directory = args.directory
            if not directory:
                raise Exception("请提供 --directory-id 或 --directory")
            directory_id = draft_manager.resolve_directory_id(directory)

        draft_id = draft_manager.create_application_draft(
            job_name=args.name,
            directory_id=directory_id,
            job_type=job_type,
            engine_version=engine_version,
        )

        sql_text = ""
        jar_uris = None

        if job_type.endswith("_SQL"):
            if args.sql:
                sql_text = args.sql
            elif args.sql_file:
                sql_text = Path(args.sql_file).expanduser().read_text(encoding="utf-8")
            elif args.sql_dir:
                sql_dir = Path(args.sql_dir).expanduser()
                files = sorted([p for p in sql_dir.rglob("*.sql") if p.is_file()])
                sql_text = "\n\n".join([p.read_text(encoding="utf-8") for p in files])
            else:
                raise Exception("SQL 作业需要提供 --sql 或 --sql-file 或 --sql-dir")

        if job_type.endswith("_JAR"):
            if not args.main_class:
                raise Exception("JAR 作业需要提供 --main-class")

            jar_tos = None
            jar_ref = getattr(args, "jar", None) or None
            if jar_ref:
                if str(jar_ref).strip().startswith("tos://"):
                    jar_tos = str(jar_ref).strip()
                else:
                    print("开始上传 JAR 到 TOS ...")
                    jar_tos = draft_manager.upload_jar_if_needed(str(jar_ref))
                    print(f"✅ 上传成功: {jar_tos}")
            elif args.jar_tos:
                jar_tos = args.jar_tos
            elif args.jar_path:
                print("开始上传 JAR 到 TOS ...")
                jar_tos = draft_manager.upload_jar_if_needed(args.jar_path)
                print(f"✅ 上传成功: {jar_tos}")
            else:
                raise Exception("JAR 作业需要提供 --jar/--jar-path 或 --jar-tos")

            jar_uris = [jar_tos] if jar_tos else None

        main_args = None
        if getattr(args, "main_arg", None):
            main_args = {}
            for item in args.main_arg:
                if "=" not in item:
                    raise Exception("MainArgs 参数格式错误，应为 key=value")
                k, v = item.split("=", 1)
                main_args[str(k)] = str(v)

        draft_manager.update_application_draft(
            draft_id=draft_id,
            sql_text=sql_text,
            jar_uris=jar_uris,
            jar=(jar_uris[0] if jar_uris else None),
            main_class=getattr(args, "main_class", None),
            args=getattr(args, "args", None),
            main_args=main_args,
        )
        print("✅ 草稿创建成功!")
        print(f"草稿ID: {draft_id}")
        print(f"作业类型: {job_type}")
        print(f"Web: {_draft_console_url(credentials.region, project_id, job_type, draft_id)}")
        print(f"发布命令: volc_flink drafts publish --draft-id {draft_id} --resource-pool YOUR_RESOURCE_POOL_NAME")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def publish_draft(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()

    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)

    print_header("发布草稿")
    try:
        resource_pool = args.resource_pool
        queue = args.queue
        resource_pool_id = args.resource_pool_id

        rpm = ResourcePoolManager(api_client, project_id)

        if resource_pool_id:
            if not resource_pool or not queue:
                pools = rpm.list_resource_pools(page=1, page_size=1000)
                match = next((p for p in pools if p.id == resource_pool_id), None)
                if not match:
                    raise Exception("未找到指定资源池ID")
                resource_pool = resource_pool or match.name
                queue = queue or match.id

        if resource_pool and not queue:
            pools = rpm.list_resource_pools(page=1, page_size=1000)
            matches = [p for p in pools if p.name == resource_pool]
            if len(matches) == 1:
                queue = matches[0].id
            elif len(matches) > 1:
                raise Exception("资源池名称不唯一，请使用资源池列表确认后再指定")
            else:
                raise Exception("未找到指定资源池名称，请使用 resource-pools list 查询")

        if not resource_pool and not queue:
            raise Exception("请提供 --resource-pool（资源池名称）")

        if not resource_pool:
            pools = rpm.list_resource_pools(page=1, page_size=1000)
            match = next((p for p in pools if p.id == queue), None)
            if not match:
                raise Exception("未找到指定资源池，请使用 resource-pools list 查询")
            resource_pool = match.name

        if not resource_pool or not queue:
            raise Exception("资源池解析失败，请检查资源池名称或使用 resource-pools list 查询")

        draft_ref = args.draft_id
        draft_id = draft_ref if str(draft_ref).isdigit() else draft_manager.resolve_draft_id(str(draft_ref))

        resp = draft_manager.publish_draft(
            draft_id=draft_id,
            resource_pool=resource_pool,
            queue=queue,
            priority=args.priority,
            schedule_policy=args.schedule_policy,
            schedule_timeout=args.schedule_timeout,
        )
        print("✅ 草稿发布请求已提交!")
        print(f"运维页面: {_job_manage_url(credentials.region, project_id)}")
        if isinstance(resp, dict):
            job_id = resp.get("AppId") or resp.get("JobId") or resp.get("Id")
            if job_id:
                print(f"JobId: {job_id}")
                print(f"启动命令: volc_flink jobs start --job-id {job_id}")
            else:
                print("未获取到 JobId，请打开运维页面在列表中查看任务ID后再启动")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def update_draft(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("更新草稿")
    try:
        sql_text = None
        jar_uris = None
        jar_tos = None

        if args.sql or args.sql_file or args.sql_dir:
            if args.sql:
                sql_text = args.sql
            elif args.sql_file:
                sql_text = Path(args.sql_file).expanduser().read_text(encoding="utf-8")
            elif args.sql_dir:
                sql_dir = Path(args.sql_dir).expanduser()
                files = sorted([p for p in sql_dir.rglob("*.sql") if p.is_file()])
                sql_text = "\n\n".join([p.read_text(encoding="utf-8") for p in files])

        jar_ref = getattr(args, "jar", None) or None
        if jar_ref or args.jar_tos or args.jar_path:
            if jar_ref:
                if str(jar_ref).strip().startswith("tos://"):
                    jar_tos = str(jar_ref).strip()
                else:
                    print("开始上传 JAR 到 TOS ...")
                    jar_tos = draft_manager.upload_jar_if_needed(str(jar_ref))
                    print(f"✅ 上传成功: {jar_tos}")
            elif args.jar_tos:
                jar_tos = args.jar_tos
            else:
                print("开始上传 JAR 到 TOS ...")
                jar_tos = draft_manager.upload_jar_if_needed(args.jar_path)
                print(f"✅ 上传成功: {jar_tos}")
            jar_uris = [jar_tos]

        if (
            sql_text is None
            and jar_uris is None
            and not args.main_class
            and not args.args
            and not getattr(args, "main_arg", None)
        ):
            raise Exception(
                "请至少提供一种更新内容：--sql/--sql-file/--sql-dir 或 --jar-path/--jar-tos 或 --main-class/--args/--main-arg"
            )

        draft_ref = args.draft_id
        draft_id = draft_ref if str(draft_ref).isdigit() else draft_manager.resolve_draft_id(str(draft_ref))
        draft = draft_manager.get_draft(draft_id)

        main_args = None
        if getattr(args, "main_arg", None):
            main_args = {}
            for item in args.main_arg:
                if "=" not in item:
                    raise Exception("MainArgs 参数格式错误，应为 key=value")
                k, v = item.split("=", 1)
                main_args[str(k)] = str(v)

        draft_manager.update_application_draft(
            draft_id=draft_id,
            sql_text=sql_text,
            jar_uris=jar_uris,
            jar=jar_tos,
            main_class=args.main_class,
            args=args.args,
            main_args=main_args,
        )
        print("✅ 草稿更新成功!")
        print(f"草稿ID: {draft_id}")
        print(f"Web: {_draft_console_url(credentials.region, project_id, draft.type, draft_id)}")
        publish_ref = f"--draft {draft_ref!r}" if not str(draft_ref).isdigit() else f"--draft-id {draft_id}"
        print(f"发布命令: volc_flink drafts publish {publish_ref} --resource-pool YOUR_RESOURCE_POOL_NAME")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def drafts_dependency_add(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("添加依赖")
    try:
        draft_ref = args.draft_id
        draft_id = draft_ref if str(draft_ref).isdigit() else draft_manager.resolve_draft_id(str(draft_ref))

        existing = draft_manager.list_dependency_jars(draft_id)
        to_add: List[str] = []
        for item in args.jar:
            if str(item).strip().startswith("tos://"):
                tos_path = str(item).strip()
            else:
                print("开始上传 JAR 到 TOS ...")
                tos_path = draft_manager.upload_jar_if_needed(str(item))
                print(f"✅ 上传成功: {tos_path}")
            if tos_path not in existing and tos_path not in to_add:
                to_add.append(tos_path)

        if not to_add:
            print("未新增依赖（已存在或未提供有效路径）")
            return

        new_list = existing + to_add
        draft_manager.update_application_draft(draft_id=draft_id, jar_uris=new_list)
        print("✅ 依赖已更新")
        print(json.dumps({"jars": new_list}, ensure_ascii=False, indent=2))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def drafts_dependency_remove(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("删除依赖")
    try:
        draft_ref = args.draft_id
        draft_id = draft_ref if str(draft_ref).isdigit() else draft_manager.resolve_draft_id(str(draft_ref))

        existing = draft_manager.list_dependency_jars(draft_id)
        remove_set = set([str(x).strip() for x in args.jar if str(x).strip()])
        new_list = [x for x in existing if x not in remove_set]

        if len(new_list) == len(existing):
            print("未删除任何依赖（未匹配到全路径）")
            return

        draft_manager.update_application_draft(draft_id=draft_id, jar_uris=new_list)
        print("✅ 依赖已更新")
        print(json.dumps({"jars": new_list}, ensure_ascii=False, indent=2))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def drafts_params_set(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("设置动态参数")
    try:
        draft_ref = args.draft_id
        draft_id = draft_ref if str(draft_ref).isdigit() else draft_manager.resolve_draft_id(str(draft_ref))

        if "=" not in args.kv:
            raise Exception("参数格式错误，应为 key=value")
        key, value = args.kv.split("=", 1)
        key = str(key).strip()
        value = str(value)
        if not key:
            raise Exception("参数 key 不能为空")

        draft_manager.update_application_draft(
            draft_id=draft_id,
            dynamic_options_updates={key: value},
        )
        current = draft_manager.get_dynamic_options(draft_id)
        print("✅ 动态参数已更新")
        print(json.dumps(current, ensure_ascii=False, indent=2, sort_keys=True))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def drafts_params_unset(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("删除动态参数")
    try:
        draft_ref = args.draft_id
        draft_id = draft_ref if str(draft_ref).isdigit() else draft_manager.resolve_draft_id(str(draft_ref))

        key = str(args.key).strip()
        if not key:
            raise Exception("参数 key 不能为空")

        draft_manager.update_application_draft(
            draft_id=draft_id,
            dynamic_options_updates={key: None},
        )
        current = draft_manager.get_dynamic_options(draft_id)
        print("✅ 动态参数已更新")
        print(json.dumps(current, ensure_ascii=False, indent=2, sort_keys=True))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def drafts_params_show(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    draft_manager = DraftManager(api_client, project_id)
    print_header("动态参数列表")
    try:
        draft_ref = args.draft_id
        draft_id = draft_ref if str(draft_ref).isdigit() else draft_manager.resolve_draft_id(str(draft_ref))
        current = draft_manager.get_dynamic_options(draft_id)
        print(json.dumps(current, ensure_ascii=False, indent=2, sort_keys=True))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def attach_drafts_subcommands(subparsers):
    draft_parser = subparsers.add_parser("drafts", help="草稿操作")
    draft_parser.set_defaults(func=lambda _args, p=draft_parser: p.print_help())
    draft_parser.add_argument("-p", "--project", help="项目名称（可省略，使用默认项目）")
    draft_parser.add_argument("--project-id", help="项目ID（兼容参数）")
    draft_subparsers = draft_parser.add_subparsers(title="草稿子命令")

    list_drafts_parser = draft_subparsers.add_parser("list", help="列举草稿（兼容命令）")
    list_drafts_parser.add_argument("--directory", help="按目录名称或路径过滤，例如 /a/b/c 或 tls-test")
    list_drafts_parser.set_defaults(func=list_drafts)

    dirs_parser = draft_subparsers.add_parser("dirs", help="列举草稿目录")
    dirs_parser.set_defaults(func=list_draft_directories)

    mkdir_parser = draft_subparsers.add_parser("mkdir", help="创建草稿目录")
    mkdir_parser.add_argument("--name", required=True, help="目录路径，例如 /a/b/c")
    mkdir_parser.set_defaults(func=create_draft_directory)

    rmr_parser = draft_subparsers.add_parser("rmr", help="删除草稿目录")
    rmr_id_group = rmr_parser.add_mutually_exclusive_group(required=True)
    rmr_id_group.add_argument("--id", required=False, help="目录ID")
    rmr_id_group.add_argument("--name", required=False, help="目录路径，例如 /a/b/c")
    rmr_parser.set_defaults(func=delete_draft_directory)

    apps_parser = draft_subparsers.add_parser("apps", help="列举草稿")
    apps_parser.add_argument("--directory", help="按目录名称或路径过滤，例如 /a/b/c 或 tls-test")
    apps_parser.set_defaults(func=list_draft_apps)

    content_parser = draft_subparsers.add_parser("content", help="获取草稿内容")
    content_id_group = content_parser.add_mutually_exclusive_group(required=True)
    content_id_group.add_argument("-i", "--draft-id", dest="draft_id", help="草稿ID 或草稿路径，例如 /a/b/c/test.sql")
    content_id_group.add_argument("--draft", dest="draft_id", help="草稿ID 或草稿路径（兼容参数）")
    content_parser.set_defaults(func=get_draft_content)

    rm_parser = draft_subparsers.add_parser("rm", help="删除草稿")
    rm_id_group = rm_parser.add_mutually_exclusive_group(required=True)
    rm_id_group.add_argument("--id", required=False, help="草稿ID")
    rm_id_group.add_argument("--name", required=False, help="草稿名称或路径，例如 my_draft 或 /a/b/c/my_draft.sql")
    rm_parser.set_defaults(func=delete_draft_cmd)

    validate_parser = draft_subparsers.add_parser("validate", help="SQL 草稿语法校验")
    validate_id_group = validate_parser.add_mutually_exclusive_group(required=True)
    validate_id_group.add_argument("-i", "--draft-id", dest="draft_id", help="草稿ID 或草稿路径，例如 /a/b/c/test.sql")
    validate_id_group.add_argument("--draft", dest="draft_id", help="草稿ID 或草稿路径（兼容参数）")
    validate_parser.add_argument("--raw", action="store_true", help="输出原始 JSON")
    validate_parser.set_defaults(func=validate_draft_cmd)

    create_draft_parser = draft_subparsers.add_parser("create", help="创建草稿")
    create_draft_parser.add_argument("-n", "--name", required=True, help="草稿名称")
    create_draft_parser.add_argument("--directory-id", help="草稿目录ID（可通过 drafts dirs 获取）")
    create_draft_parser.add_argument("--directory", help="草稿目录名称或路径，例如 /a/b/c 或 tls-test")
    create_draft_parser.add_argument(
        "--job-type",
        choices=["FLINK_STREAMING_SQL", "FLINK_STREAMING_JAR", "FLINK_BATCH_SQL", "FLINK_BATCH_JAR"],
        help="作业类型",
    )
    create_draft_parser.add_argument(
        "--engine-version",
        default="FLINK_VERSION_1_17",
        choices=[
            "FLINK_VERSION_1_16",
            "FLINK_VERSION_1_17",
            "FLINK_VERSION_1_20",
            "FLINK_1_16",
            "FLINK_1_17",
            "FLINK_1_20",
        ],
        help="Flink 引擎版本",
    )
    create_draft_parser.add_argument("-t", "--type", choices=["sql", "jar"], help="兼容参数：sql 或 jar")
    create_draft_parser.add_argument("--mode", choices=["streaming", "batch"], help="兼容参数：streaming 或 batch")
    create_draft_parser.add_argument("-s", "--sql", help="SQL 文本")
    create_draft_parser.add_argument("--sql-file", help="SQL 文件路径")
    create_draft_parser.add_argument("--sql-dir", help="SQL 文件目录（递归读取 *.sql）")
    create_draft_parser.add_argument("--jar", help="JAR 路径：本地路径或 tos://...（等价于 --jar-path/--jar-tos）")
    create_draft_parser.add_argument("--jar-path", help="本地 JAR 文件路径")
    create_draft_parser.add_argument("--jar-tos", help="TOS JAR 路径，例如 tos://<bucket>/path/to/jar.jar")
    create_draft_parser.add_argument("--main-class", help="JAR 作业主类（MainClass）")
    create_draft_parser.add_argument("--args", help="JAR 作业启动参数字符串（Args）")
    create_draft_parser.add_argument("--main-arg", action="append", help="JAR 作业 MainArgs，格式 key=value，可重复传入")
    create_draft_parser.set_defaults(func=create_draft)

    publish_draft_parser = draft_subparsers.add_parser("publish", help="发布草稿")
    publish_id_group = publish_draft_parser.add_mutually_exclusive_group(required=True)
    publish_id_group.add_argument("-i", "--draft-id", dest="draft_id", help="草稿ID 或草稿路径，例如 /a/b/c/test.sql")
    publish_id_group.add_argument("--draft", dest="draft_id", help="草稿ID 或草稿路径（兼容参数）")
    publish_draft_parser.add_argument("--resource-pool-id", help="资源池ID（兼容参数）")
    publish_draft_parser.add_argument("--resource-pool", help="资源池名称")
    publish_draft_parser.add_argument("--queue", help="资源池 Queue（兼容参数）")
    publish_draft_parser.add_argument("--priority", default="3", help="优先级 1-5，默认 3")
    publish_draft_parser.add_argument("--schedule-policy", default="GANG", choices=["GANG", "DRF"], help="调度策略")
    publish_draft_parser.add_argument("--schedule-timeout", type=int, default=60, help="调度超时秒数（GANG 时使用）")
    publish_draft_parser.set_defaults(func=publish_draft)

    update_draft_parser = draft_subparsers.add_parser("update", help="更新草稿内容")
    update_id_group = update_draft_parser.add_mutually_exclusive_group(required=True)
    update_id_group.add_argument("-i", "--draft-id", dest="draft_id", help="草稿ID 或草稿路径，例如 /a/b/c/test.sql")
    update_id_group.add_argument("--draft", dest="draft_id", help="草稿ID 或草稿路径（兼容参数）")
    update_draft_parser.add_argument("-s", "--sql", help="SQL 文本")
    update_draft_parser.add_argument("--sql-file", help="SQL 文件路径")
    update_draft_parser.add_argument("--sql-dir", help="SQL 文件目录（递归读取 *.sql）")
    update_draft_parser.add_argument("--jar", help="JAR 路径：本地路径或 tos://...（等价于 --jar-path/--jar-tos）")
    update_draft_parser.add_argument("--jar-path", help="本地 JAR 文件路径")
    update_draft_parser.add_argument("--jar-tos", help="TOS JAR 路径，例如 tos://<bucket>/path/to/jar.jar")
    update_draft_parser.add_argument("--main-class", help="JAR 作业主类（MainClass）")
    update_draft_parser.add_argument("--args", help="JAR 作业启动参数字符串（Args）")
    update_draft_parser.add_argument("--main-arg", action="append", help="JAR 作业 MainArgs，格式 key=value，可重复传入")
    update_draft_parser.set_defaults(func=update_draft)

    dependency_parser = draft_subparsers.add_parser("dependency", help="管理草稿依赖（Dependency.jars）")
    dependency_subparsers = dependency_parser.add_subparsers(title="dependency 子命令")

    dep_add_parser = dependency_subparsers.add_parser("add", help="添加依赖 JAR")
    dep_add_id_group = dep_add_parser.add_mutually_exclusive_group(required=True)
    dep_add_id_group.add_argument("-i", "--draft-id", dest="draft_id", help="草稿ID 或草稿路径，例如 /a/b/c/test.sql")
    dep_add_id_group.add_argument("--draft", dest="draft_id", help="草稿ID 或草稿路径（兼容参数）")
    dep_add_parser.add_argument("--jar", action="append", required=True, help="本地路径或 tos://...，可重复传入")
    dep_add_parser.set_defaults(func=drafts_dependency_add)

    dep_remove_parser = dependency_subparsers.add_parser("remove", help="删除依赖 JAR")
    dep_remove_id_group = dep_remove_parser.add_mutually_exclusive_group(required=True)
    dep_remove_id_group.add_argument("-i", "--draft-id", dest="draft_id", help="草稿ID 或草稿路径，例如 /a/b/c/test.sql")
    dep_remove_id_group.add_argument("--draft", dest="draft_id", help="草稿ID 或草稿路径（兼容参数）")
    dep_remove_parser.add_argument("--jar", action="append", required=True, help="依赖的 tos 全路径，可重复传入")
    dep_remove_parser.set_defaults(func=drafts_dependency_remove)

    params_parser = draft_subparsers.add_parser("params", help="管理草稿动态参数（DynamicOptions）")
    params_subparsers = params_parser.add_subparsers(title="params 子命令")

    params_set_parser = params_subparsers.add_parser("set", help="设置动态参数（覆盖或插入）")
    params_set_id_group = params_set_parser.add_mutually_exclusive_group(required=True)
    params_set_id_group.add_argument("-i", "--draft-id", dest="draft_id", help="草稿ID 或草稿路径，例如 /a/b/c/test.sql")
    params_set_id_group.add_argument("--draft", dest="draft_id", help="草稿ID 或草稿路径（兼容参数）")
    params_set_parser.add_argument("--kv", required=True, help="key=value")
    params_set_parser.set_defaults(func=drafts_params_set)

    params_unset_parser = params_subparsers.add_parser("unset", help="删除动态参数（按 key）")
    params_unset_id_group = params_unset_parser.add_mutually_exclusive_group(required=True)
    params_unset_id_group.add_argument("-i", "--draft-id", dest="draft_id", help="草稿ID 或草稿路径，例如 /a/b/c/test.sql")
    params_unset_id_group.add_argument("--draft", dest="draft_id", help="草稿ID 或草稿路径（兼容参数）")
    params_unset_parser.add_argument("--key", required=True, help="要删除的参数 key")
    params_unset_parser.set_defaults(func=drafts_params_unset)

    params_show_parser = params_subparsers.add_parser("show", help="查看动态参数（DynamicOptions）")
    params_show_id_group = params_show_parser.add_mutually_exclusive_group(required=True)
    params_show_id_group.add_argument("-i", "--draft-id", dest="draft_id", help="草稿ID 或草稿路径，例如 /a/b/c/test.sql")
    params_show_id_group.add_argument("--draft", dest="draft_id", help="草稿ID 或草稿路径（兼容参数）")
    params_show_parser.set_defaults(func=drafts_params_show)
