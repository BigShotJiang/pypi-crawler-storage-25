import argparse
import json

from volcano_flink_client.auth.auth import AuthManager
from volcano_flink_client.files.files import TOSFilesManager
from volcano_flink_cli.common import print_header, print_table


def files_list(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    mgr = TOSFilesManager(credentials)
    print_header("TOS 文件列表")
    try:
        sub_prefix = str(getattr(args, "prefix", "") or "").strip()
        limit = int(getattr(args, "limit", 200) or 200)
        objs = mgr.list(sub_prefix=sub_prefix, limit=limit)
        if getattr(args, "raw", False):
            print(json.dumps([o.__dict__ for o in objs], ensure_ascii=False, indent=2))
            return
        rows = []
        for o in objs:
            rows.append([o.key, str(o.size), o.last_modified, o.etag])
        print_table(rows, ["Key", "Size", "LastModified", "ETag"])
        print(f"\n📊 总计: {len(objs)} 个对象")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def files_upload(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    mgr = TOSFilesManager(credentials)
    print_header("上传文件到 TOS")
    try:
        file_path = str(args.file)
        name = str(getattr(args, "name", "") or "").strip() or None
        res = mgr.upload(file_path=file_path, name=name)
        print("✅ 上传成功")
        print(f"TOS: {res.get('tos_uri')}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def files_detail(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    mgr = TOSFilesManager(credentials)
    print_header("文件详情")
    try:
        res = mgr.head(name=str(args.name))
        print(json.dumps(res, ensure_ascii=False, indent=2))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def files_update(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    mgr = TOSFilesManager(credentials)
    print_header("更新文件（覆盖上传）")
    try:
        res = mgr.upload(file_path=str(args.file), name=str(args.name))
        print("✅ 更新成功")
        print(f"TOS: {res.get('tos_uri')}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def files_url(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    mgr = TOSFilesManager(credentials)
    print_header("获取文件链接")
    try:
        expires_in = int(getattr(args, "expires", 3600) or 3600)
        res = mgr.url(name=str(args.name), expires_in=expires_in)
        print(f"TOS: {res.get('tos_uri')}")
        print(f"URL: {res.get('url')}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def attach_files_subcommands(subparsers):
    files_parser = subparsers.add_parser("files", help="TOS 文件（基于 TOS Jar Prefix）")
    files_parser.set_defaults(func=lambda _args, p=files_parser: p.print_help())
    files_subparsers = files_parser.add_subparsers(title="files 子命令")

    files_list_parser = files_subparsers.add_parser("list", help="列出 TOS Jar Prefix 下的文件")
    files_list_parser.add_argument("--prefix", default="", help="子目录前缀（相对 tos_jar_prefix）")
    files_list_parser.add_argument("--limit", type=int, default=200, help="返回条数（默认 200）")
    files_list_parser.add_argument("--raw", action="store_true", help="输出原始 JSON")
    files_list_parser.set_defaults(func=files_list)

    files_upload_parser = files_subparsers.add_parser("upload", help="上传文件到 TOS Jar Prefix")
    files_upload_parser.add_argument("--file", required=True, help="本地文件路径")
    files_upload_parser.add_argument("--name", default="", help="对象名（相对 tos_jar_prefix，默认使用文件名）")
    files_upload_parser.set_defaults(func=files_upload)

    files_detail_parser = files_subparsers.add_parser("detail", help="查看文件详情（HeadObject）")
    files_detail_parser.add_argument("--name", required=True, help="对象名（相对 tos_jar_prefix）")
    files_detail_parser.set_defaults(func=files_detail)

    files_update_parser = files_subparsers.add_parser("update", help="更新文件（覆盖上传）")
    files_update_parser.add_argument("--name", required=True, help="对象名（相对 tos_jar_prefix）")
    files_update_parser.add_argument("--file", required=True, help="本地文件路径")
    files_update_parser.set_defaults(func=files_update)

    files_url_parser = files_subparsers.add_parser("url", help="获取下载链接（预签名 URL）")
    files_url_parser.add_argument("--name", required=True, help="对象名（相对 tos_jar_prefix）")
    files_url_parser.add_argument("--expires", type=int, default=3600, help="链接有效期秒（默认 3600）")
    files_url_parser.set_defaults(func=files_url)
