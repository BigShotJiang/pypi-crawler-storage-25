import argparse
import json
from datetime import datetime
from typing import Any, Dict, List, Optional

from volcano_flink_client.auth.auth import Credentials
from volcano_flink_client.api import ApiClient
from volcano_flink_client.projects.projects import ProjectManager


def print_header(title: str):
    print(f"\n{'=' * 60}")
    print(f"{title:^60}")
    print(f"{'=' * 60}")


def print_table(data: list, headers: list):
    if not data:
        print("无数据")
        return

    col_widths = []
    for i, header in enumerate(headers):
        max_width = len(header)
        for row in data:
            cell_width = len(str(row[i]))
            if cell_width > max_width:
                max_width = cell_width
        col_widths.append(max_width + 2)

    for i, header in enumerate(headers):
        print(f"{header:<{col_widths[i]}}", end="")
    print()

    for width in col_widths:
        print(f"{'-' * (width - 2):<{width}}", end="")
    print()

    for row in data:
        for i, cell in enumerate(row):
            print(f"{str(cell):<{col_widths[i]}}", end="")
        print()


def _format_epoch(ts: int) -> str:
    try:
        return datetime.fromtimestamp(int(ts)).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return str(ts)


def _downsample_avg(values: List[float], target_n: int) -> List[float]:
    n = len(values)
    if target_n <= 0 or n <= target_n:
        return values
    out: List[float] = []
    for i in range(target_n):
        start = int(i * n / target_n)
        end = int((i + 1) * n / target_n)
        if end <= start:
            end = min(n, start + 1)
        chunk = values[start:end]
        if not chunk:
            continue
        out.append(sum(chunk) / float(len(chunk)))
    return out


def _sparkline(values: List[float], width: int = 80) -> str:
    if not values:
        return ""
    vals = _downsample_avg(values, max(1, int(width)))
    lo = min(vals)
    hi = max(vals)
    levels = "▁▂▃▄▅▆▇█"
    if hi == lo:
        return levels[len(levels) // 2] * len(vals)
    out_chars: List[str] = []
    span = hi - lo
    for v in vals:
        idx = int((float(v - lo) / span) * (len(levels) - 1))
        if idx < 0:
            idx = 0
        if idx >= len(levels):
            idx = len(levels) - 1
        out_chars.append(levels[idx])
    return "".join(out_chars)


def _render_metrics_graph(resp: Any, width: int = 80) -> None:
    if not isinstance(resp, dict):
        print(json.dumps(resp, ensure_ascii=False, indent=2))
        return
    items = resp.get("Data") or []
    if not isinstance(items, list) or not items:
        print("无数据")
        return
    for metric in items:
        if not isinstance(metric, dict):
            continue
        metric_name = str(metric.get("MetricName") or "")
        unit = str(metric.get("Unit") or "")
        period = str(metric.get("Period") or "")
        results = metric.get("MetricDataResults") or []
        if not isinstance(results, list) or not results:
            continue
        for series in results:
            if not isinstance(series, dict):
                continue
            legend = str(series.get("Legend") or metric_name)
            dims = series.get("Dimensions") or []
            dims_kv = []
            if isinstance(dims, list):
                for d in dims:
                    if not isinstance(d, dict):
                        continue
                    n = d.get("Name")
                    v = d.get("Value")
                    if n is None or v is None:
                        continue
                    dims_kv.append(f"{n}={v}")
            dims_str = ", ".join(dims_kv)
            points = series.get("DataPoints") or []
            if not isinstance(points, list) or not points:
                continue
            pts = []
            for p in points:
                if not isinstance(p, dict):
                    continue
                ts = p.get("Timestamp")
                val = p.get("Value")
                if ts is None or val is None:
                    continue
                try:
                    pts.append((int(ts), float(val)))
                except Exception:
                    continue
            if not pts:
                continue
            pts.sort(key=lambda x: x[0])
            ts0, v0 = pts[0]
            ts1, v1 = pts[-1]
            values = [v for _, v in pts]
            line = _sparkline(values, width=width)
            title_parts = [x for x in [metric_name, legend] if x]
            title = " / ".join(title_parts)
            meta_parts = []
            if unit:
                meta_parts.append(unit)
            if period:
                meta_parts.append(period)
            meta = f" ({', '.join(meta_parts)})" if meta_parts else ""
            print(f"{title}{meta}")
            if dims_str:
                print(dims_str)
            print(line)
            print(f"{_format_epoch(ts0)} -> {_format_epoch(ts1)}  min={min(values)} max={max(values)} last={v1}")
            print()


def _parse_kv_list(values: Optional[List[str]]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    if not values:
        return out
    for raw in values:
        if raw is None:
            continue
        s = str(raw).strip()
        if not s:
            continue
        if "=" not in s:
            continue
        k, v = s.split("=", 1)
        k = k.strip()
        if not k:
            continue
        out[k] = v.strip()
    return out


def _format_session_flinkui(uri_path: str) -> str:
    s = str(uri_path or "").strip()
    if not s:
        return ""
    if s.startswith("http://") or s.startswith("https://"):
        return s
    if s.startswith("/"):
        return "https://console.volcengine.com" + s
    return "https://console.volcengine.com/" + s


def _join_url(endpoint: str, path: str) -> str:
    e = str(endpoint or "").strip()
    p = str(path or "").strip()
    if not e:
        return ""
    if not (e.startswith("http://") or e.startswith("https://")):
        e = "https://" + e
    e = e.rstrip("/")
    if not p:
        return e
    if p.startswith("/"):
        return e + p
    return e + "/" + p


def _resolve_project_id(args: argparse.Namespace, credentials: Credentials) -> str:
    project_id = getattr(args, "project_id", None)
    if project_id:
        return project_id

    project_name = getattr(args, "project", None) or getattr(args, "project_name", None)
    if project_name:
        api_client = ApiClient(credentials)
        project_manager = ProjectManager(api_client)
        projects = project_manager.list_projects(search=project_name, page=1, page_size=200)
        exact = [p for p in projects if p.name == project_name]
        if len(exact) == 1:
            return exact[0].id
        if len(exact) > 1:
            raise Exception("项目名称不唯一，请使用 projects list 确认并改用 --project-id")
        if projects:
            return projects[0].id
        raise Exception("未找到指定项目名称，请使用 projects list 确认名称")

    if credentials.default_project_id:
        return credentials.default_project_id
    if credentials.default_project_name:
        api_client = ApiClient(credentials)
        project_manager = ProjectManager(api_client)
        projects = project_manager.list_projects(search=credentials.default_project_name, page=1, page_size=200)
        exact = [p for p in projects if p.name == credentials.default_project_name]
        if len(exact) == 1:
            return exact[0].id
        if projects:
            return projects[0].id

    raise Exception("未指定项目，请设置默认项目或在命令中传入 -p/--project")


def _draft_console_url(region: str, project_id: str, job_type: str, draft_id: str) -> str:
    active_tab = "jarJob" if "JAR" in (job_type or "").upper() else "sqlJob"
    return (
        f"https://console.volcengine.com/flink/region:flink+{region}"
        f"/project/{project_id}/jobDev?activeModule=jobDev&activeTab={active_tab}-{draft_id}"
    )


def _job_manage_url(region: str, project_id: str) -> str:
    return f"https://console.volcengine.com/flink/region:flink+{region}/project/{project_id}/job/manage"


def _format_job_state(state: str) -> str:
    return (state or "").upper() or "UNKNOWN"


def _try_get_flink_ui_url(job_overview: dict) -> Optional[str]:
    if not isinstance(job_overview, dict):
        return None
    url = job_overview.get("CompleteRestUrl") or job_overview.get("RestUrl")
    if isinstance(url, str) and url.strip():
        return url.strip()
    return None


def _start_mode_label(start_type: str, savepoint_id: Optional[str] = None) -> str:
    if start_type == "FROM_LATEST":
        return "最新状态恢复"
    if start_type == "FROM_NEW":
        return "全新启动（丢弃状态）"
    if start_type == "FROM_SAVEPOINT":
        return f"Savepoint 恢复（{savepoint_id}）" if savepoint_id else "Savepoint 恢复"
    return start_type or "UNKNOWN"
