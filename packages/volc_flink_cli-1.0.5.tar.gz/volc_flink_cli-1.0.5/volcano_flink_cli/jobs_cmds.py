import argparse
import importlib.resources as importlib_resources
import json
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from volcano_flink_client.api import ApiClient
from volcano_flink_client.auth.auth import AuthManager
from volcano_flink_client.drafts.drafts import DraftManager
from volcano_flink_client.jobs.jobs import JobManager
from volcano_flink_cli.common import (
    _format_job_state,
    _job_manage_url,
    _render_metrics_graph,
    _resolve_project_id,
    _start_mode_label,
    _try_get_flink_ui_url,
    print_header,
    print_table,
)
from volcano_flink_cli.monitor_cmds import _parse_dt, _pick_instance_id


def list_jobs(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()

    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)

    print_header("任务列表")
    try:
        jobs = job_manager.list_jobs(
            page=args.page,
            page_size=args.page_size,
            status=args.status,
            type_filter=args.job_type,
            search=args.search,
        )
        data = []
        for job in jobs:
            data.append([job.id, job.name, job.type, job.status, job.create_time])

        print_table(data, ["任务ID", "名称", "类型", "状态", "创建时间"])
        print(f"\n📊 总计: {len(jobs)} 个任务")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def list_job_instances_cmd(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)

    print_header("任务实例列表")
    try:
        states = args.states
        state = args.state
        if state is None and not states:
            state = ""

        resp = job_manager.list_job_instances(
            job_id=args.job_id,
            state=state,
            states=states,
            page=args.page,
            page_size=args.page_size,
        )
        records = resp.get("Records") or []
        if not isinstance(records, list):
            records = []
        data = []
        for item in records[: int(args.limit)]:
            if not isinstance(item, dict):
                continue
            data.append(
                [
                    str(item.get("InstanceId") or item.get("Id") or ""),
                    str(item.get("State") or ""),
                    str(item.get("StartTime") or ""),
                    str(item.get("EndTime") or ""),
                    str(item.get("Duration") or ""),
                ]
            )
        print_table(data, ["InstanceId", "State", "StartTime", "EndTime", "Duration"])
        total = resp.get("Total")
        if total is None:
            total = len(records)
        print(f"\n📊 总计: {total} 条实例记录")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def get_job_events_cmd(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)

    print_header("任务事件")
    try:
        events = job_manager.get_job_events(job_id=args.job_id, limit=args.limit)
        events = events[: int(args.limit)]
        if getattr(args, "raw", False):
            print(json.dumps(events, ensure_ascii=False, indent=2))
            return
        data = []
        for item in events:
            if not isinstance(item, dict):
                continue

            def pick(keys: List[str]) -> str:
                for k in keys:
                    v = item.get(k)
                    if v is not None and str(v) != "":
                        return str(v)
                return ""

            data.append(
                [
                    pick(["Time", "EventTime", "Timestamp", "CreateTime", "LastTimestamp", "FirstTimestamp"]),
                    pick(["Level", "Type", "Severity", "EventType"]),
                    pick(["Collector", "Source", "Component", "Reason", "Name", "Title"]),
                    pick(["Message", "Msg", "Content", "Detail"]),
                ]
            )
        print_table(data, ["Time", "Level", "Collector", "Message"])
        print(f"\n📊 总计: {len(events)} 条事件记录")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def get_job_detail_cmd(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)

    print_header("任务详情")
    try:
        overview = job_manager.get_job_overview(args.job_id)
        details = None
        try:
            details_obj = job_manager.get_job_details(args.job_id)
            details = details_obj.__dict__ if hasattr(details_obj, "__dict__") else None
        except Exception:
            details = None

        if getattr(args, "raw", False):
            print(json.dumps({"overview": overview, "details": details}, ensure_ascii=False, indent=2))
            return

        manage_url = _job_manage_url(credentials.region, project_id)
        flink_ui = _try_get_flink_ui_url(overview)

        rows = []

        def add(k: str, v: Any):
            if v is None:
                return
            s = str(v)
            if s == "":
                return
            rows.append([k, s])

        add("JobId", overview.get("Id") or args.job_id)
        add("JobName", overview.get("JobName"))
        add("JobType", overview.get("JobType"))
        add("State", overview.get("State"))
        add("ProjectId", overview.get("ProjectId") or project_id)
        add("ResourcePool", overview.get("ResourcePool") or overview.get("Queue"))
        add("DraftId", overview.get("AppDraftId"))
        add("CreateTime", overview.get("CreateTime"))
        add("ModifiedTime", overview.get("ModifiedTime"))
        add("StartTime", overview.get("StartTime"))
        add("EndTime", overview.get("EndTime"))
        add("RestUrl", overview.get("RestUrl"))
        add("CompleteRestUrl", overview.get("CompleteRestUrl"))
        add("ManageUrl", manage_url)
        if flink_ui:
            add("FlinkUI", flink_ui)

        print_table(rows, ["Key", "Value"])

        if details and isinstance(details, dict):
            extras = []
            for k in (
                "resource_pool_id",
                "draft_id",
                "create_time",
                "update_time",
                "start_time",
                "end_time",
                "status",
                "type",
                "name",
            ):
                v = details.get(k)
                if v is None or str(v) == "":
                    continue
                extras.append([f"details.{k}", str(v)])
            if extras:
                print()
                print_table(extras, ["Key", "Value"])
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def get_job_uuid_cmd(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)

    print_header("任务 GtsJobUuid")
    try:
        overview = job_manager.get_job_overview(args.job_id)
        uuid = None
        for k in ("GtsJobUuid", "GTSJobUuid", "GtsJobUUID", "GTSJobUUID"):
            v = overview.get(k) if isinstance(overview, dict) else None
            if v is not None and str(v).strip():
                uuid = str(v).strip()
                break

        if getattr(args, "raw", False):
            print(json.dumps({"JobId": args.job_id, "GtsJobUuid": uuid, "overview": overview}, ensure_ascii=False, indent=2))
            return

        if not uuid:
            raise Exception("未在任务概览中找到 GtsJobUuid 字段，可使用 --raw 查看返回内容")
        print(uuid)
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def start_job(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()

    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)

    print_header("启动任务")
    try:
        job_id = args.job_id
        manage_url = _job_manage_url(credentials.region, project_id)
        print(f"运维页面: {manage_url}")

        printed_flink_ui = False

        try:
            current_overview = job_manager.get_job_overview(job_id)
        except Exception:
            current_overview = {}
        current_state = _format_job_state(str(current_overview.get("State") or ""))
        current_flink_ui = _try_get_flink_ui_url(current_overview)
        if current_flink_ui:
            print(f"FlinkUI: {current_flink_ui}")
            printed_flink_ui = True

        start_type = None
        savepoint_id = None
        if getattr(args, "from_mode", None):
            mode = args.from_mode
            if mode == "latest":
                start_type = "FROM_LATEST"
            elif mode == "new":
                start_type = "FROM_NEW"
            elif mode == "savepoint":
                start_type = "FROM_SAVEPOINT"
                savepoint_id = args.savepoint_id
                if not savepoint_id:
                    raise Exception("from=savepoint 时必须提供 --savepoint-id")
        if not start_type and args.start_type:
            start_type = args.start_type
        if not start_type:
            start_type = "FROM_NEW" if current_state == "CREATED" else "FROM_LATEST"
        if start_type == "FROM_SAVEPOINT" and not savepoint_id:
            savepoint_id = args.savepoint_id
            if not savepoint_id:
                raise Exception("FROM_SAVEPOINT 启动时必须提供 --savepoint-id")

        print(f"本次启动方式: {_start_mode_label(start_type, savepoint_id)}")

        if current_state == "RUNNING":
            print("✅ 任务已在 RUNNING，无需启动")
            return

        result = job_manager.start_job(job_id=job_id, start_type=start_type, savepoint_id=savepoint_id)
        print(f"✅ {result}")

        if args.inspect:
            timeout_seconds = int(args.timeout)
            if timeout_seconds <= 0:
                timeout_seconds = 300
            deadline = time.monotonic() + timeout_seconds
            start_at = time.monotonic()
            attempt = 0
            while True:
                attempt += 1
                try:
                    overview = job_manager.get_job_overview(job_id)
                except Exception:
                    overview = {}
                state = _format_job_state(str(overview.get("State") or ""))
                elapsed = int(time.monotonic() - start_at)
                remaining = max(0, timeout_seconds - elapsed)
                print(f"轮询中（{attempt}）状态: {state}（剩余 {remaining}s）")

                flink_ui = _try_get_flink_ui_url(overview)
                if flink_ui and not printed_flink_ui:
                    print(f"FlinkUI: {flink_ui}")
                    printed_flink_ui = True

                if state == "RUNNING":
                    print("✅ 任务已进入 RUNNING")
                    return
                if state in ("FAILED", "SUCCEEDED", "STOPPED"):
                    print(f"❌ 任务已进入终态: {state}")
                    job_name = overview.get("JobName") or ""
                    if job_name:
                        print(f"查询任务: volc_flink jobs list --search \"{job_name}\"")
                    print(f"查看事件/日志: volc_flink jobs ui --job-id {job_id}")
                    return

                if time.monotonic() >= deadline:
                    print(f"⏱ 已超时（{timeout_seconds}s），可继续在运维页面查看状态: {manage_url}")
                    return

                time.sleep(5)
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def stop_job(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()

    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)

    print_header("停止任务")
    try:
        job_id = args.job_id
        manage_url = _job_manage_url(credentials.region, project_id)
        print(f"运维页面: {manage_url}")

        try:
            current_overview = job_manager.get_job_overview(job_id)
        except Exception:
            current_overview = {}
        current_state = _format_job_state(str(current_overview.get("State") or ""))

        if current_state == "STOPPED":
            print("✅ 任务已在 STOPPED，无需停止")
            return

        savepoint_id = None
        if args.savepoint:
            existing_savepoint_ids = set()
            try:
                for sp in job_manager.list_start_savepoints(job_id):
                    spid = sp.get("SavepointId")
                    if spid:
                        existing_savepoint_ids.add(str(spid))
            except Exception:
                existing_savepoint_ids = set()

            result = job_manager.stop_job_with_savepoint(job_id=job_id)
            print(f"✅ {result}")
            print("制作快照中（Savepoint）...")
        else:
            result = job_manager.stop_job(job_id=job_id, force=args.force)
            print(f"✅ {result}")

        if args.inspect:
            timeout_seconds = int(args.timeout)
            if timeout_seconds <= 0:
                timeout_seconds = 300
            deadline = time.monotonic() + timeout_seconds
            start_at = time.monotonic()
            attempt = 0
            printed_savepoint = False
            while True:
                attempt += 1
                try:
                    overview = job_manager.get_job_overview(job_id)
                except Exception:
                    overview = {}
                state = _format_job_state(str(overview.get("State") or ""))
                elapsed = int(time.monotonic() - start_at)
                remaining = max(0, timeout_seconds - elapsed)
                print(f"轮询中（{attempt}）状态: {state}（剩余 {remaining}s）")

                if args.savepoint and not printed_savepoint:
                    try:
                        savepoints = job_manager.list_start_savepoints(job_id)
                    except Exception:
                        savepoints = []
                    new_ids = []
                    for sp in savepoints:
                        spid = sp.get("SavepointId")
                        status = str(sp.get("Status") or "")
                        if not spid:
                            continue
                        spid = str(spid)
                        if spid in existing_savepoint_ids:
                            continue
                        if status.upper() == "AVAILABLE":
                            new_ids.append(spid)
                    if new_ids:
                        savepoint_id = new_ids[0]
                        print(f"SavepointId: {savepoint_id}")
                        print(
                            f"Savepoint 恢复启动: volc_flink jobs start --job-id {job_id} --from savepoint --savepoint-id {savepoint_id}"
                        )
                        printed_savepoint = True

                if state == "STOPPED":
                    print("✅ 任务已进入 STOPPED")
                    if args.savepoint and not printed_savepoint:
                        print(f"查看快照列表: volc_flink jobs savepoint list --job-id {job_id}")
                    return

                if state in ("FAILED", "SUCCEEDED"):
                    print(f"✅ 任务已进入终态: {state}")
                    if args.savepoint and not printed_savepoint:
                        print(f"查看快照列表: volc_flink jobs savepoint list --job-id {job_id}")
                    return

                if time.monotonic() >= deadline:
                    print(f"⏱ 已超时（{timeout_seconds}s），可继续在运维页面查看状态: {manage_url}")
                    if args.savepoint and not printed_savepoint:
                        print(f"查询 Savepoint 列表: volc_flink jobs savepoint list --job-id {job_id}")
                    return

                time.sleep(5)
        else:
            if args.savepoint:
                print(f"查询 Savepoint 列表: volc_flink jobs savepoint list --job-id {args.job_id}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def restart_job(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()

    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)

    print_header("重启任务")
    try:
        job_id = args.job_id
        manage_url = _job_manage_url(credentials.region, project_id)
        print(f"运维页面: {manage_url}")

        start_type = None
        savepoint_id = None
        if getattr(args, "from_mode", None):
            mode = args.from_mode
            if mode == "latest":
                start_type = "FROM_LATEST"
            elif mode == "new":
                start_type = "FROM_NEW"
            elif mode == "savepoint":
                start_type = "FROM_SAVEPOINT"
                savepoint_id = args.savepoint_id
                if not savepoint_id:
                    raise Exception("from=savepoint 时必须提供 --savepoint-id")
        if not start_type and args.start_type:
            start_type = args.start_type
        if not start_type:
            start_type = "FROM_LATEST"
        if start_type == "FROM_SAVEPOINT" and not savepoint_id:
            savepoint_id = args.savepoint_id
            if not savepoint_id:
                raise Exception("FROM_SAVEPOINT 重启时必须提供 --savepoint-id")

        print(f"本次重启方式: {_start_mode_label(start_type, savepoint_id)}")

        result = job_manager.restart_job(job_id=job_id, start_type=start_type, savepoint_id=savepoint_id)
        print(f"✅ {result}")

        if args.inspect:
            timeout_seconds = int(args.timeout)
            if timeout_seconds <= 0:
                timeout_seconds = 300
            deadline = time.monotonic() + timeout_seconds
            start_at = time.monotonic()
            attempt = 0
            while True:
                attempt += 1
                try:
                    overview = job_manager.get_job_overview(job_id)
                except Exception:
                    overview = {}
                state = _format_job_state(str(overview.get("State") or ""))
                elapsed = int(time.monotonic() - start_at)
                remaining = max(0, timeout_seconds - elapsed)
                print(f"轮询中（{attempt}）状态: {state}（剩余 {remaining}s）")
                if state == "RUNNING":
                    print("✅ 任务已进入 RUNNING")
                    return
                if state in ("FAILED", "SUCCEEDED", "STOPPED"):
                    print(f"❌ 任务已进入终态: {state}")
                    return
                if time.monotonic() >= deadline:
                    print(f"⏱ 已超时（{timeout_seconds}s），请在运维页面查看状态: {manage_url}")
                    return
                time.sleep(5)
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def rescale_job(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)
    draft_manager = DraftManager(api_client, project_id)

    print_header("Rescale 任务")
    try:
        job_id = args.job_id
        overview = job_manager.get_job_overview(job_id)
        draft_id = overview.get("AppDraftId") or overview.get("AppDraftID")
        if not draft_id:
            raise Exception("未获取到 AppDraftId，无法定位草稿")
        draft_id = str(draft_id)

        deploy_request = overview.get("DeployRequest") if isinstance(overview.get("DeployRequest"), dict) else {}
        resource_pool = deploy_request.get("ResourcePool") or overview.get("ResourcePool") or ""
        queue = deploy_request.get("Queue") or overview.get("Queue") or ""
        if not resource_pool or not queue:
            raise Exception("未获取到资源池信息（ResourcePool/Queue），无法发布草稿")

        priority = str(deploy_request.get("Priority") or "3")
        schedule_policy = str(deploy_request.get("SchedulePolicy") or "GANG")
        schedule_timeout_raw = deploy_request.get("ScheduleTimeout") or 60
        try:
            schedule_timeout = int(schedule_timeout_raw)
        except Exception:
            schedule_timeout = 60

        def _parse_ratio(value: str) -> int:
            v = str(value or "").strip()
            if v in ("1:2", "2"):
                return 2
            if v in ("1:4", "4"):
                return 4
            if v in ("1:8", "8"):
                return 8
            raise Exception("CPU 内存配比仅支持 1:2 / 1:4 / 1:8")

        def _parse_spec(spec: str) -> Optional[Dict[str, int]]:
            if not spec:
                return None
            raw_spec = str(spec)
            cleaned = raw_spec.strip()
            if cleaned.endswith("\\"):
                cleaned = cleaned[:-1].strip()
            if (cleaned.startswith('"') and cleaned.endswith('"')) or (cleaned.startswith("'") and cleaned.endswith("'")):
                cleaned = cleaned[1:-1].strip()
            cleaned = re.sub(r"[\s\u200b\u200c\u200d\ufeff]+", "", cleaned)
            cleaned = re.sub(r"[^0-9cCgGbB]", "", cleaned)
            m = re.match(r"^(\d+)[cC](\d+)[gG][bB]$", cleaned)
            if not m:
                raise Exception(f"规格格式错误（收到: {raw_spec!r}），示例：1C2GB / 2C8GB / 4C16GB")
            cpu = int(m.group(1))
            mem = int(m.group(2))
            return {"cpu": cpu, "mem_gb": mem}

        allowed_cpu = {1, 2, 4, 8, 16}

        tm_cpu = args.tm_cpu
        tm_ratio = _parse_ratio(args.tm_mem_ratio) if args.tm_mem_ratio else None
        tm_spec = _parse_spec(args.tm_spec) if args.tm_spec else None
        if tm_spec:
            tm_cpu = tm_spec["cpu"]
            tm_ratio = None
            tm_mem_gb = tm_spec["mem_gb"]
            if tm_cpu not in allowed_cpu:
                raise Exception("TM CPU 仅支持 1/2/4/8/16")
            if tm_mem_gb % tm_cpu != 0 or (tm_mem_gb // tm_cpu) not in (2, 4, 8):
                raise Exception("TM CPU 内存配比仅支持 1:2 / 1:4 / 1:8")
        else:
            tm_mem_gb = None
            if tm_cpu is not None and tm_cpu not in allowed_cpu:
                raise Exception("TM CPU 仅支持 1/2/4/8/16")
            if tm_cpu is not None and tm_ratio is None and args.tm_mem_ratio is None:
                raise Exception("设置 TM CPU 时必须同时设置 --tm-mem-ratio 或使用 --tm-spec")
            if tm_cpu is not None and tm_ratio is not None:
                tm_mem_gb = int(tm_cpu) * int(tm_ratio)

        jm_cpu = args.jm_cpu
        jm_ratio = _parse_ratio(args.jm_mem_ratio) if args.jm_mem_ratio else None
        jm_spec = _parse_spec(args.jm_spec) if args.jm_spec else None
        if jm_spec:
            jm_cpu = jm_spec["cpu"]
            jm_ratio = None
            jm_mem_gb = jm_spec["mem_gb"]
            if jm_cpu not in allowed_cpu:
                raise Exception("JM CPU 仅支持 1/2/4/8/16")
            if jm_mem_gb % jm_cpu != 0 or (jm_mem_gb // jm_cpu) not in (2, 4, 8):
                raise Exception("JM CPU 内存配比仅支持 1:2 / 1:4 / 1:8")
        else:
            jm_mem_gb = None
            if jm_cpu is not None and jm_cpu not in allowed_cpu:
                raise Exception("JM CPU 仅支持 1/2/4/8/16")
            if jm_cpu is not None and jm_ratio is None and args.jm_mem_ratio is None:
                raise Exception("设置 JM CPU 时必须同时设置 --jm-mem-ratio 或使用 --jm-spec")
            if jm_cpu is not None and jm_ratio is not None:
                jm_mem_gb = int(jm_cpu) * int(jm_ratio)

        updates: Dict[str, Optional[str]] = {}
        if args.parallelism is not None:
            updates["parallelism.default"] = str(int(args.parallelism))
        if args.tm_slots is not None:
            updates["taskmanager.numberOfTaskSlots"] = str(int(args.tm_slots))
        if tm_cpu is not None:
            updates["kubernetes.taskmanager.cpu"] = str(int(tm_cpu))
        if tm_mem_gb is not None:
            updates["taskmanager.memory.process.size"] = f"{int(tm_mem_gb) * 1024}mb"
        if jm_cpu is not None:
            updates["kubernetes.jobmanager.cpu"] = str(int(jm_cpu))
        if jm_mem_gb is not None:
            updates["jobmanager.memory.process.size"] = f"{int(jm_mem_gb) * 1024}mb"

        if not updates:
            print("未指定任何 rescale 参数，将沿用原有配置")

        print(f"JobId: {job_id}")
        print(f"DraftId: {draft_id}")
        print(f"ResourcePool: {resource_pool}")
        print(f"Queue: {queue}")
        if updates:
            print("DynamicOptions 更新项:")
            print(json.dumps(updates, ensure_ascii=False, indent=2, sort_keys=True))

        if args.dry_run:
            print("✅ Dry-run 完成（未更新草稿/未发布/未重启）")
            return

        draft_manager.update_application_draft(draft_id=draft_id, dynamic_options_updates=updates)
        print("✅ 草稿配置已更新")

        resp = draft_manager.publish_draft(
            draft_id=draft_id,
            resource_pool=str(resource_pool),
            queue=str(queue),
            priority=priority,
            schedule_policy=schedule_policy,
            schedule_timeout=schedule_timeout,
        )
        print("✅ 草稿发布请求已提交")
        published_job_id = None
        if isinstance(resp, dict):
            published_job_id = resp.get("AppId") or resp.get("JobId") or resp.get("Id")
        if published_job_id:
            print(f"发布返回 JobId: {published_job_id}")

        target_job_id = str(published_job_id) if published_job_id else str(job_id)
        if target_job_id != str(job_id):
            print(f"将重启发布后的任务: {target_job_id}")

        result = job_manager.restart_job(job_id=target_job_id, start_type="FROM_LATEST", savepoint_id=None)
        print(f"✅ {result}")

        if args.inspect:
            timeout_seconds = int(args.timeout)
            if timeout_seconds <= 0:
                timeout_seconds = 300
            deadline = time.monotonic() + timeout_seconds
            start_at = time.monotonic()
            attempt = 0
            while True:
                attempt += 1
                try:
                    ov = job_manager.get_job_overview(target_job_id)
                except Exception:
                    ov = {}
                state = _format_job_state(str(ov.get("State") or ""))
                elapsed = int(time.monotonic() - start_at)
                remaining = max(0, timeout_seconds - elapsed)
                print(f"轮询中（{attempt}）状态: {state}（剩余 {remaining}s）")
                if state == "RUNNING":
                    print("✅ 任务已进入 RUNNING")
                    return
                if state in ("FAILED", "SUCCEEDED", "STOPPED"):
                    print(f"❌ 任务已进入终态: {state}")
                    return
                if time.monotonic() >= deadline:
                    print(f"⏱ 已超时（{timeout_seconds}s），请在运维页面查看状态: {_job_manage_url(credentials.region, project_id)}")
                    return
                time.sleep(5)
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def get_job_logs(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()

    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)

    print_header("任务日志")
    try:
        instance_id = str(getattr(args, "instance_id", "") or "").strip()
        if not instance_id:
            instance_id = _pick_instance_id(job_manager, str(args.job_id), None)
        component = str(getattr(args, "component", "") or "jobmanager").strip().lower() or "jobmanager"
        file_name = str(getattr(args, "file_name", "") or getattr(args, "file", "") or "").strip()
        level = getattr(args, "level", None)
        cursor = str(getattr(args, "cursor", "") or "").strip()
        page_size = int(getattr(args, "page_size", 500) or 500)
        page = int(getattr(args, "page", 1) or 1)
        if page <= 0:
            page = 1
        if page_size <= 0:
            page_size = 500

        now_ms = int(time.time() * 1000)
        start_ms = getattr(args, "start_time_ms", None)
        end_ms = getattr(args, "end_time_ms", None)
        if start_ms is None and getattr(args, "since", None):
            try:
                start_ms = int(_parse_dt(args.since).timestamp() * 1000)
            except Exception:
                start_ms = None
        if end_ms is None and getattr(args, "until", None):
            try:
                end_ms = int(_parse_dt(args.until).timestamp() * 1000)
            except Exception:
                end_ms = None
        if end_ms is None:
            end_ms = now_ms
        if start_ms is None:
            start_ms = int(end_ms) - 3600 * 1000
        start_ms = int(start_ms)
        end_ms = int(end_ms)
        if start_ms > end_ms:
            raise Exception("StartTime 不能大于 EndTime")

        def _filter_msgs(msgs: List[str]) -> List[str]:
            if not level:
                return msgs
            lv = str(level).upper()
            out = []
            for m in msgs:
                if lv in str(m).upper():
                    out.append(m)
            return out

        def fetch(cursor_in: str, end_override_ms: Optional[int], print_msgs: bool) -> str:
            end_use = int(end_override_ms) if end_override_ms is not None else end_ms
            resp = job_manager.list_gas_logs(
                instance_id=instance_id,
                component=component,
                level=level,
                start_time_ms=start_ms,
                end_time_ms=end_use,
                cursor=cursor_in,
                page_size=page_size,
                file_name=file_name,
            )
            msgs = resp.get("Messages") if isinstance(resp, dict) else None
            next_cursor = str(resp.get("Cursor") or "") if isinstance(resp, dict) else ""
            if isinstance(msgs, list):
                filtered = _filter_msgs([str(x) for x in msgs if x is not None])
                if print_msgs:
                    for m in filtered:
                        print(m)
            return next_cursor

        if page > 1 and not cursor:
            cur = ""
            for _ in range(page - 1):
                nxt = fetch(cur, None, False)
                if not nxt:
                    cur = ""
                    break
                cur = nxt
            cursor = cur

        if getattr(args, "follow", False):
            cur = cursor
            while True:
                now2 = int(time.time() * 1000)
                nxt = fetch(
                    cur,
                    now2
                    if getattr(args, "until", None) is None and getattr(args, "end_time_ms", None) is None
                    else None,
                    True,
                )
                if nxt:
                    cur = nxt
                time.sleep(float(getattr(args, "interval", 2.0) or 2.0))
        else:
            cursor_out = fetch(cursor, None, True)
            if cursor_out:
                print(f"\nCursor: {cursor_out}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def get_job_metrics(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()

    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)

    print_header("任务指标")
    try:
        metric_names = getattr(args, "metric_names", None) or getattr(args, "metric", None) or []
        metric_names = [str(x).strip() for x in metric_names if str(x).strip()]
        if not metric_names:
            raise Exception("必须指定至少一个指标名，例如 -m flink_jobmanager_job_uptime")

        resource_id = getattr(args, "gtsjobuuid", None) or getattr(args, "uuid", None)
        if resource_id:
            resource_id = str(resource_id).strip()
        job_id = getattr(args, "job_id", None)
        if not resource_id and job_id:
            overview = job_manager.get_job_overview(str(job_id))
            for k in ("GtsJobUuid", "GTSJobUuid", "GtsJobUUID", "GTSJobUUID", "ResourceID", "ResourceId"):
                v = overview.get(k) if isinstance(overview, dict) else None
                if v is not None and str(v).strip():
                    resource_id = str(v).strip()
                    break
            if not resource_id:
                raise Exception("未从 Job 概览中解析到 GtsJobUuid，请使用 jobs uuid --raw 检查字段")

        if not resource_id:
            raise Exception("必须指定 -u/--gtsjobuuid 或 -i/--job-id")

        now = int(time.time())
        start_time = getattr(args, "start_time", None)
        end_time = getattr(args, "end_time", None)
        if end_time is None:
            end_time = now
        if start_time is None:
            start_time = int(end_time) - 3600
        start_time = int(start_time)
        end_time = int(end_time)
        if start_time > end_time:
            raise Exception("StartTime 不能大于 EndTime")

        group_by = getattr(args, "group_by", None) or []
        group_by = [str(x).strip() for x in group_by if str(x).strip()]

        sub_namespace = getattr(args, "sub_namespace", None) or "overview"
        region = getattr(args, "region", None) or credentials.region

        body = {
            "MetricNames": metric_names,
            "StartTime": start_time,
            "EndTime": end_time,
            "Namespace": "VCM_Flink",
            "Instances": [{"Dimensions": [{"Name": "ResourceID", "Value": resource_id}]}],
            "GroupBy": group_by,
            "SubNamespace": str(sub_namespace),
            "Region": str(region),
        }
        resp = api_client.openapi_invoke(
            action="GetMetricsData",
            version="2018-01-01",
            service="Volc_Observe",
            method="POST",
            query_params=[],
            body=body,
        )
        if getattr(args, "graph", False):
            _render_metrics_graph(resp, width=int(getattr(args, "graph_width", 80) or 80))
        else:
            print(json.dumps(resp, ensure_ascii=False, indent=2))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def list_job_metrics_catalog(args: argparse.Namespace):
    print_header("可查询指标")
    try:
        raw = None
        try:
            raw = (
                importlib_resources.files("volcano_flink_client")
                .joinpath("vcm_flink_metrics_catalog.json")
                .read_text(encoding="utf-8")
            )
        except Exception:
            raw = None
        if raw is None:
            catalog_path = Path(__file__).resolve().parent.parent / "volcano_flink_client" / "vcm_flink_metrics_catalog.json"
            if not catalog_path.exists():
                raise Exception(f"未找到指标清单文件: {catalog_path}")
            raw = catalog_path.read_text(encoding="utf-8")
        catalog = json.loads(raw)
        items = catalog.get("items") if isinstance(catalog, dict) else None
        if not isinstance(items, list):
            items = []

        sub_ns = getattr(args, "sub_namespace", None)
        if sub_ns is not None:
            sub_ns = str(sub_ns).strip()
            if sub_ns == "":
                sub_ns = None

        rows = []
        for it in items:
            if not isinstance(it, dict):
                continue
            sub = str(it.get("sub_namespace") or "")
            if sub_ns and sub != sub_ns:
                continue
            name = str(it.get("metric_name") or "")
            dims = it.get("dimensions") or []
            if isinstance(dims, list):
                dims_str = ", ".join([str(d) for d in dims if d is not None and str(d) != ""])
            else:
                dims_str = str(dims)
            unit = str(it.get("unit") or "")
            rows.append([sub, name, unit, dims_str])

        rows.sort(key=lambda r: (r[0], r[1]))
        print_table(rows, ["SubNamespace", "MetricName", "Unit", "Dimensions"])
        print(f"\n📊 总计: {len(rows)} 个指标")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def job_ui(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)

    print_header("任务页面")
    manage_url = _job_manage_url(credentials.region, project_id)
    print(f"运维页面: {manage_url}")

    if args.job_id:
        try:
            overview = job_manager.get_job_overview(args.job_id)
            flink_ui = _try_get_flink_ui_url(overview)
            if flink_ui:
                print(f"FlinkUI: {flink_ui}")
        except Exception as e:
            print(f"❌ 错误: {str(e)}")


def list_job_savepoints(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)

    print_header("快照列表")
    try:
        items = job_manager.list_savepoints(args.job_id, status=args.status)
        data = []
        for sp in items:
            data.append(
                [
                    sp.get("SavepointId") or "",
                    sp.get("Status") or "",
                    sp.get("CreateTime") or "",
                    sp.get("CreateType") or "",
                    sp.get("SavepointPath") or "",
                ]
            )
        print_table(data, ["SavepointId", "状态", "创建时间", "类型", "路径"])
        print(f"\n📊 总计: {len(items)} 个快照")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def make_job_savepoint(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)

    print_header("制作快照")
    try:
        existing_ids = set()
        try:
            for sp in job_manager.list_savepoints(args.job_id):
                spid = sp.get("SavepointId")
                if spid:
                    existing_ids.add(str(spid))
        except Exception:
            existing_ids = set()

        resp = job_manager.make_savepoint(args.job_id, args.description)
        print("✅ 快照制作请求已提交!")
        instance_id = resp.get("InstanceId") if isinstance(resp, dict) else None
        if instance_id:
            print(f"InstanceId: {instance_id}")

        if args.inspect:
            timeout_seconds = int(args.timeout)
            if timeout_seconds <= 0:
                timeout_seconds = 300
            deadline = time.monotonic() + timeout_seconds
            start_at = time.monotonic()
            attempt = 0
            while True:
                attempt += 1
                elapsed = int(time.monotonic() - start_at)
                remaining = max(0, timeout_seconds - elapsed)
                print(f"轮询中（{attempt}）查询 Savepoint（剩余 {remaining}s）")
                try:
                    items = job_manager.list_savepoints(args.job_id)
                except Exception:
                    items = []
                new_ids = []
                for sp in items:
                    spid = sp.get("SavepointId")
                    status = str(sp.get("Status") or "")
                    if not spid:
                        continue
                    spid = str(spid)
                    if spid in existing_ids:
                        continue
                    if status.upper() == "AVAILABLE":
                        new_ids.append(spid)
                if new_ids:
                    savepoint_id = new_ids[0]
                    print(f"SavepointId: {savepoint_id}")
                    print(
                        f"Savepoint 恢复启动: volc_flink jobs start --job-id {args.job_id} --from savepoint --savepoint-id {savepoint_id}"
                    )
                    return
                if time.monotonic() >= deadline:
                    print(f"⏱ 已超时（{timeout_seconds}s），可稍后查询 Savepoint 列表: volc_flink jobs savepoint list --job-id {args.job_id}")
                    return
                time.sleep(5)
        else:
            print(f"查询 Savepoint 列表: volc_flink jobs savepoint list --job-id {args.job_id}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def list_job_start_available_savepoints(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)

    print_header("可恢复快照")
    try:
        info = job_manager.get_start_savepoint_info(args.job_id)
        methods = info.get("EnableStartMethods") or []
        if methods:
            print("可用启动方式: " + ", ".join([str(m) for m in methods]))
        items = info.get("AvailableSavepoints") or []
        if not isinstance(items, list):
            items = []
        data = []
        for sp in items:
            if not isinstance(sp, dict):
                continue
            data.append(
                [
                    sp.get("SavepointId") or "",
                    sp.get("Status") or "",
                    sp.get("CreateTime") or "",
                    sp.get("CreateType") or "",
                    sp.get("SavepointPath") or "",
                ]
            )
        print_table(data, ["SavepointId", "状态", "创建时间", "类型", "路径"])
        print(f"\n📊 总计: {len(data)} 个可恢复快照")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def attach_jobs_subcommands(subparsers):
    job_parser = subparsers.add_parser("jobs", help="任务操作")
    job_parser.set_defaults(func=lambda _args, p=job_parser: p.print_help())
    job_parser.add_argument("-p", "--project", help="项目名称（可省略，使用默认项目）")
    job_parser.add_argument("--project-id", help="项目ID（兼容参数）")
    job_subparsers = job_parser.add_subparsers(title="任务子命令")

    list_jobs_parser = job_subparsers.add_parser("list", help="列举任务")
    list_jobs_parser.add_argument("--page", type=int, default=1, help="页码（默认 1）")
    list_jobs_parser.add_argument("--page-size", type=int, default=50, help="每页大小（默认 50）")
    list_jobs_parser.add_argument(
        "--status",
        choices=["CREATED", "RUNNING", "STOPPED", "FAILED", "SUCCEEDED"],
        help="状态筛选",
    )
    list_jobs_parser.add_argument(
        "--job-type",
        choices=["FLINK_STREAMING_SQL", "FLINK_STREAMING_JAR", "FLINK_BATCH_SQL", "FLINK_BATCH_JAR"],
        help="类型筛选",
    )
    list_jobs_parser.add_argument("--search", help="按任务名称模糊搜索")
    list_jobs_parser.set_defaults(func=list_jobs)

    detail_parser = job_subparsers.add_parser("detail", help="获取任务详情")
    detail_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    detail_parser.add_argument("--raw", action="store_true", help="输出原始 JSON")
    detail_parser.set_defaults(func=get_job_detail_cmd)

    uuid_parser = job_subparsers.add_parser("uuid", help="获取任务的 GtsJobUuid（云监控 ResourceID）")
    uuid_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    uuid_parser.add_argument("--raw", action="store_true", help="输出原始 JSON")
    uuid_parser.set_defaults(func=get_job_uuid_cmd)

    instances_parser = job_subparsers.add_parser("instances", help="查询任务历史实例")
    instances_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    instances_parser.add_argument("--state", help="按状态筛选（单个）")
    instances_parser.add_argument("--states", action="append", help="按状态筛选（可重复）")
    instances_parser.add_argument("--page", type=int, default=1, help="页码（默认 1）")
    instances_parser.add_argument("--page-size", type=int, default=20, help="每页大小（默认 20）")
    instances_parser.add_argument("--limit", type=int, default=20, help="展示条数（默认 20）")
    instances_parser.set_defaults(func=list_job_instances_cmd)

    events_parser = job_subparsers.add_parser("events", help="查询任务运行事件")
    events_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    events_parser.add_argument("--limit", type=int, default=50, help="返回条数（默认 50）")
    events_parser.add_argument("--raw", action="store_true", help="输出原始 JSON")
    events_parser.set_defaults(func=get_job_events_cmd)

    start_job_parser = job_subparsers.add_parser("start", help="启动任务")
    start_job_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    start_job_parser.add_argument("--from", dest="from_mode", choices=["latest", "new", "savepoint"], help="启动方式")
    start_job_parser.add_argument("--savepoint-id", dest="savepoint_id", help="SavepointId（from=savepoint 时必填）")
    start_job_parser.add_argument(
        "--start-type",
        default=None,
        choices=["FROM_NEW", "FROM_LATEST", "FROM_SAVEPOINT"],
        help="启动类型（兼容参数）",
    )
    start_job_parser.add_argument("--inspect", action="store_true", help="启动后持续轮询任务状态")
    start_job_parser.add_argument("--timeout", type=int, default=300, help="inspect 超时时间秒（默认 300）")
    start_job_parser.set_defaults(func=start_job)

    stop_job_parser = job_subparsers.add_parser("stop", help="停止任务")
    stop_job_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    stop_job_parser.add_argument("-f", "--force", action="store_true", help="强制停止")
    stop_job_parser.add_argument("--savepoint", action="store_true", help="停止时制作快照（Savepoint）")
    stop_job_parser.add_argument("--inspect", action="store_true", help="停止后持续轮询任务状态")
    stop_job_parser.add_argument("--timeout", type=int, default=300, help="inspect 超时时间秒（默认 300）")
    stop_job_parser.set_defaults(func=stop_job)

    restart_job_parser = job_subparsers.add_parser("restart", help="重启任务")
    restart_job_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    restart_job_parser.add_argument("--from", dest="from_mode", choices=["latest", "new", "savepoint"], help="重启方式")
    restart_job_parser.add_argument("--savepoint-id", dest="savepoint_id", help="SavepointId（from=savepoint 时必填）")
    restart_job_parser.add_argument(
        "--start-type",
        default=None,
        choices=["FROM_NEW", "FROM_LATEST", "FROM_SAVEPOINT"],
        help="重启类型（兼容参数）",
    )
    restart_job_parser.add_argument("--inspect", action="store_true", help="重启后持续轮询任务状态")
    restart_job_parser.add_argument("--timeout", type=int, default=300, help="inspect 超时时间秒（默认 300）")
    restart_job_parser.set_defaults(func=restart_job)

    rescale_job_parser = job_subparsers.add_parser("rescale", help="调整任务并行度与规格并发布重启")
    rescale_job_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    rescale_job_parser.add_argument("--parallelism", type=int, help="并行度")
    rescale_job_parser.add_argument("--tm-spec", help="TM 规格，例如 1C4GB / 2C8GB")
    rescale_job_parser.add_argument("--tm-cpu", type=int, choices=[1, 2, 4, 8, 16], help="TM CPU（1/2/4/8/16）")
    rescale_job_parser.add_argument("--tm-mem-ratio", choices=["1:2", "1:4", "1:8"], help="TM CPU:内存 配比")
    rescale_job_parser.add_argument("--tm-slots", type=int, help="单个 TM slot 数")
    rescale_job_parser.add_argument("--jm-spec", help="JM 规格，例如 1C4GB / 2C8GB")
    rescale_job_parser.add_argument("--jm-cpu", type=int, choices=[1, 2, 4, 8, 16], help="JM CPU（1/2/4/8/16）")
    rescale_job_parser.add_argument("--jm-mem-ratio", choices=["1:2", "1:4", "1:8"], help="JM CPU:内存 配比")
    rescale_job_parser.add_argument("--dry-run", action="store_true", help="仅展示将要修改的配置，不执行更新/发布/重启")
    rescale_job_parser.add_argument("--inspect", action="store_true", help="重启后轮询任务状态")
    rescale_job_parser.add_argument("--timeout", type=int, default=300, help="inspect 超时时间秒（默认 300）")
    rescale_job_parser.set_defaults(func=rescale_job)

    logs_parser = job_subparsers.add_parser("logs", help="获取任务日志（GAS）")
    logs_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    logs_parser.add_argument("--instance-id", help="实例ID（不传默认选取最新实例）")
    logs_parser.add_argument("--component", default="jobmanager", choices=["jobmanager", "taskmanager"], help="日志组件")
    logs_parser.add_argument("--file", help="日志文件名")
    logs_parser.add_argument("--file-name", dest="file_name", help="日志文件名（兼容参数）")
    logs_parser.add_argument("-l", "--level", choices=["DEBUG", "INFO", "WARN", "ERROR"], help="日志级别（按文本过滤）")
    logs_parser.add_argument("--since", help="开始时间，格式 2025-01-01 12:00:00")
    logs_parser.add_argument("--until", help="结束时间，格式 2025-01-01 13:00:00")
    logs_parser.add_argument("--start-time-ms", dest="start_time_ms", type=int, help="开始时间（Unix 毫秒）")
    logs_parser.add_argument("--end-time-ms", dest="end_time_ms", type=int, help="结束时间（Unix 毫秒）")
    logs_parser.add_argument("--cursor", default="", help="游标（用于从上次位置继续拉取）")
    logs_parser.add_argument("-p", "--page", type=int, default=1, help="页码（cursor 未提供时按页跳过）")
    logs_parser.add_argument("-s", "--page-size", dest="page_size", type=int, default=500, help="返回条数（默认 500）")
    logs_parser.add_argument("--follow", action="store_true", help="实时 tail")
    logs_parser.add_argument("--interval", type=float, default=2.0, help="tail 间隔秒（默认 2）")
    logs_parser.set_defaults(func=get_job_logs)

    metrics_parser = job_subparsers.add_parser("metrics", help="任务指标查询")
    metrics_subparsers = metrics_parser.add_subparsers(title="metrics 子命令")
    metrics_list_parser = metrics_subparsers.add_parser("list", help="查询可用指标列表")
    metrics_list_parser.add_argument("--sub-namespace", default=None, help="SubNamespace 过滤")
    metrics_list_parser.set_defaults(func=list_job_metrics_catalog)

    metrics_parser.add_argument("-m", "--metric", dest="metric_names", action="append", help="指标名，可重复")
    metrics_parser.add_argument("-i", "--job-id", help="任务ID（用于自动解析 GtsJobUuid）")
    metrics_parser.add_argument("-u", "--gtsjobuuid", help="GtsJobUuid（云监控 ResourceID），优先级高于 job-id")
    metrics_parser.add_argument("--start-time", type=int, help="开始时间（Unix 秒）")
    metrics_parser.add_argument("--end-time", type=int, help="结束时间（Unix 秒）")
    metrics_parser.add_argument("--group-by", action="append", help="GroupBy 字段，可重复")
    metrics_parser.add_argument("--sub-namespace", default=None, help="SubNamespace（默认 overview）")
    metrics_parser.add_argument("--region", default=None, help="Region（默认使用当前登录 region）")
    metrics_parser.add_argument("--graph", action="store_true", help="以时序图形式输出")
    metrics_parser.add_argument("--graph-width", type=int, default=80, help="时序图宽度（默认 80）")
    metrics_parser.set_defaults(func=get_job_metrics)

    ui_parser = job_subparsers.add_parser("ui", help="输出任务运维与 FlinkUI 地址")
    ui_parser.add_argument("-i", "--job-id", help="任务ID（可选，用于输出 FlinkUI）")
    ui_parser.set_defaults(func=job_ui)

    savepoint_parser = job_subparsers.add_parser("savepoint", help="快照操作")
    savepoint_parser.set_defaults(func=lambda _args, p=savepoint_parser: p.print_help())
    savepoint_subparsers = savepoint_parser.add_subparsers(title="快照子命令")

    savepoint_make_parser = savepoint_subparsers.add_parser("make", help="制作快照")
    savepoint_make_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    savepoint_make_parser.add_argument("-d", "--description", required=True, help="快照描述")
    savepoint_make_parser.add_argument("--inspect", action="store_true", help="制作后轮询直到快照可用")
    savepoint_make_parser.add_argument("--timeout", type=int, default=300, help="inspect 超时时间秒（默认 300）")
    savepoint_make_parser.set_defaults(func=make_job_savepoint)

    savepoint_list_parser = savepoint_subparsers.add_parser("list", help="查询快照列表")
    savepoint_list_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    savepoint_list_parser.add_argument("--status", help="状态筛选（AVAILABLE/CREATING/FAIL 等）")
    savepoint_list_parser.set_defaults(func=list_job_savepoints)

    savepoint_available_parser = savepoint_subparsers.add_parser("start-available", help="查询可恢复快照")
    savepoint_available_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    savepoint_available_parser.set_defaults(func=list_job_start_available_savepoints)

    savepoints_parser = job_subparsers.add_parser("savepoints", help="查询快照列表（兼容命令）")
    savepoints_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    savepoints_parser.add_argument("--status", help="状态筛选（AVAILABLE/CREATING/FAIL 等）")
    savepoints_parser.set_defaults(func=list_job_savepoints)

