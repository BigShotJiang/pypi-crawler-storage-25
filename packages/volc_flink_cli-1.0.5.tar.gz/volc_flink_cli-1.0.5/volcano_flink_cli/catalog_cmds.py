import argparse
import json

from volcano_flink_client.auth.auth import AuthManager
from volcano_flink_client.api import ApiClient
from volcano_flink_client.catalogs.catalogs import CatalogManager
from volcano_flink_cli.common import _resolve_project_id, print_header, print_table


def _build_catalog_manager(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return None, None
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    return credentials, CatalogManager(api_client, project_id)


def _field(item, *names: str) -> str:
    if not isinstance(item, dict):
        return ""
    for name in names:
        value = item.get(name)
        if value not in (None, ""):
            return str(value)
    return ""


def _catalog_id(item) -> str:
    return _field(item, "CatalogId", "Id")


def _catalog_name(item) -> str:
    return _field(item, "CatalogName", "Name")


def _database_id(item) -> str:
    return _field(item, "DatabaseId", "Id")


def _database_name(item) -> str:
    return _field(item, "DatabaseName", "Name")


def _table_id(item) -> str:
    return _field(item, "TableId", "Id")


def _table_name(item) -> str:
    return _field(item, "TableName", "Name")


def _object_type(item) -> str:
    return _field(item, "Type")


def _redact_sensitive(data):
    if isinstance(data, dict):
        redacted = {}
        for key, value in data.items():
            normalized_key = str(key).lower()
            if normalized_key in {"accesskey", "secretkey", "password", "ak", "sk"}:
                redacted[key] = "***"
            else:
                redacted[key] = _redact_sensitive(value)
        return redacted
    if isinstance(data, list):
        return [_redact_sensitive(item) for item in data]
    return data


def _resolve_catalog_id(manager: CatalogManager, region: str, catalog_id: str = None, catalog_name: str = None) -> str:
    if catalog_id:
        return str(catalog_id).strip()
    if catalog_name:
        catalogs = manager.list_catalogs(region)
        target_name = str(catalog_name).strip()
        match = [item for item in catalogs if _catalog_name(item) == target_name]
        if not match:
            raise Exception("未找到指定 Catalog 名称")
        return _catalog_id(match[0])
    raise Exception("缺少 CatalogId 或 CatalogName")


def _find_catalog(manager: CatalogManager, region: str, catalog_id: str):
    catalogs = manager.list_catalogs(region)
    match = [item for item in catalogs if _catalog_id(item) == str(catalog_id).strip()]
    return match[0] if match else None


def _list_catalog_databases_with_fallback(manager: CatalogManager, region: str, catalog_id: str):
    databases = manager.list_catalog_databases(region, catalog_id)
    if databases:
        return databases
    catalog = _find_catalog(manager, region, catalog_id)
    if not isinstance(catalog, dict):
        return []
    nested_databases = catalog.get("CatalogDatabases")
    if isinstance(nested_databases, list):
        return [item for item in nested_databases if isinstance(item, dict)]
    return []


def _get_catalog_database_with_fallback(manager: CatalogManager, region: str, catalog_id: str, database_name: str):
    nested_detail = None
    databases = _list_catalog_databases_with_fallback(manager, region, catalog_id)
    target_name = str(database_name).strip()
    match = [item for item in databases if _database_name(item) == target_name]
    if match:
        nested_detail = match[0]
    try:
        detail = manager.get_catalog_database(region, catalog_id, database_name)
        if isinstance(detail, dict) and detail:
            merged = dict(nested_detail or {})
            merged.update(detail)
            return merged
    except Exception:
        pass
    if not nested_detail:
        raise Exception("未找到指定 Database")
    return nested_detail


def _list_catalog_tables_with_fallback(manager: CatalogManager, region: str, catalog_id: str, database_name: str):
    tables = manager.list_catalog_tables(region, catalog_id, database_name)
    if tables:
        return tables
    databases = _list_catalog_databases_with_fallback(manager, region, catalog_id)
    target_name = str(database_name).strip()
    match = [item for item in databases if _database_name(item) == target_name]
    nested_tables = match[0].get("CatalogTables") if match else None
    if not isinstance(nested_tables, list):
        database = _get_catalog_database_with_fallback(manager, region, catalog_id, database_name)
        nested_tables = database.get("CatalogTables")
    if isinstance(nested_tables, list):
        return [item for item in nested_tables if isinstance(item, dict)]
    return []


def _get_catalog_table_with_fallback(manager: CatalogManager, region: str, catalog_id: str, database_name: str, table_name: str):
    try:
        detail = manager.get_catalog_table(region, catalog_id, database_name, table_name)
        if isinstance(detail, dict) and detail:
            return detail
    except Exception:
        pass
    tables = _list_catalog_tables_with_fallback(manager, region, catalog_id, database_name)
    target_name = str(table_name).strip()
    match = [item for item in tables if _table_name(item) == target_name]
    if not match:
        raise Exception("未找到指定 Table")
    return match[0]


def catalog_tree(args: argparse.Namespace):
    credentials, manager = _build_catalog_manager(args)
    if manager is None or credentials is None:
        return
    region = str(credentials.region or "").strip()
    if not region:
        print("❌ 当前未配置 region，请先执行 `volc_flink config set-region --region <region>`")
        return
    level = getattr(args, "level", "table") or "table"
    catalog_id = getattr(args, "catalog_id", None)
    catalog_name = getattr(args, "catalog_name", None)
    database_name = getattr(args, "database", None)
    print_header("Catalog 树")
    try:
        catalogs = manager.list_catalogs(region)
        if catalog_name and not catalog_id:
            match = [c for c in catalogs if _catalog_name(c) == str(catalog_name).strip()]
            if not match:
                raise Exception("未找到指定 Catalog 名称")
            catalog_id = _catalog_id(match[0])
        selected_catalogs = catalogs
        if catalog_id:
            selected_catalogs = [c for c in catalogs if _catalog_id(c) == str(catalog_id).strip()]
            if not selected_catalogs:
                raise Exception("未找到指定 Catalog ID")
        if getattr(args, "raw", False):
            tree = []
            for c in selected_catalogs:
                current_catalog_id = _catalog_id(c)
                node = {"catalogId": current_catalog_id, "catalogName": _catalog_name(c), "type": _object_type(c), "databases": []}
                if level in ("database", "table"):
                    dbs = _list_catalog_databases_with_fallback(manager, region, current_catalog_id)
                    if database_name:
                        dbs = [d for d in dbs if _database_name(d) == str(database_name).strip()]
                    for d in dbs:
                        current_database_name = _database_name(d)
                        db_node = {"databaseId": _database_id(d), "databaseName": current_database_name, "type": _object_type(d), "tables": []}
                        if level == "table":
                            try:
                                tables = _list_catalog_tables_with_fallback(manager, region, current_catalog_id, current_database_name)
                            except Exception:
                                tables = []
                            for t in tables:
                                db_node["tables"].append({"tableId": _table_id(t), "tableName": _table_name(t), "type": _object_type(t)})
                        node["databases"].append(db_node)
                tree.append(node)
            print(json.dumps(tree, ensure_ascii=False, indent=2))
            return
        for c in selected_catalogs:
            current_catalog_id = _catalog_id(c)
            print(f"[CATALOG] {_catalog_name(c)} ({current_catalog_id})  type={_object_type(c)}")
            if level == "catalog":
                continue
            dbs = _list_catalog_databases_with_fallback(manager, region, current_catalog_id)
            if database_name:
                dbs = [d for d in dbs if _database_name(d) == str(database_name).strip()]
            if not dbs:
                print("  └─ 无 Database")
                continue
            db_rows = [[_database_name(d), _database_id(d), _object_type(d)] for d in dbs]
            print_table(db_rows, ["DatabaseName", "Id", "Type"])
            if level == "table":
                for d in dbs:
                    current_database_name = _database_name(d)
                    print(f"\n  [DB] {current_database_name}")
                    try:
                        tables = _list_catalog_tables_with_fallback(manager, region, current_catalog_id, current_database_name)
                    except Exception as e:
                        print(f"  ❌ 获取 Table 失败: {e}")
                        continue
                    tbl_rows = [[_table_name(t), _table_id(t), _object_type(t)] for t in tables]
                    print_table(tbl_rows, ["TableName", "Id", "Type"])
            print()
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def catalog_list_catalogs(args: argparse.Namespace):
    credentials, manager = _build_catalog_manager(args)
    if manager is None or credentials is None:
        return
    region = str(credentials.region or "").strip()
    if not region:
        print("❌ 当前未配置 region，请先执行 `volc_flink config set-region --region <region>`")
        return
    print_header("Catalog 列表")
    try:
        catalogs = manager.list_catalogs(region)
        if getattr(args, "raw", False):
            print(json.dumps(_redact_sensitive(catalogs), ensure_ascii=False, indent=2))
            return
        print_table([[_catalog_id(c), _catalog_name(c), _object_type(c)] for c in catalogs], ["CatalogId", "Name", "Type"])
        print(f"\n📊 总计: {len(catalogs)} 个 Catalog")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def catalog_show_catalog(args: argparse.Namespace):
    credentials, manager = _build_catalog_manager(args)
    if manager is None or credentials is None:
        return
    region = str(credentials.region or "").strip()
    if not region:
        print("❌ 当前未配置 region，请先执行 `volc_flink config set-region --region <region>`")
        return
    print_header("Catalog 详情")
    try:
        catalog_id = _resolve_catalog_id(manager, region, args.catalog_id, getattr(args, "catalog_name", None))
        detail = _find_catalog(manager, region, catalog_id)
        if not detail:
            raise Exception("未找到指定 Catalog")
        databases = _list_catalog_databases_with_fallback(manager, region, catalog_id)
        if getattr(args, "raw", False):
            print(json.dumps(_redact_sensitive({"catalog": detail, "databases": databases}), ensure_ascii=False, indent=2))
            return
        nested_databases = detail.get("CatalogDatabases")
        if isinstance(nested_databases, list) and nested_databases:
            database_count = len(nested_databases)
        else:
            database_count = len(databases)
        rows = [
            ["CatalogId", _catalog_id(detail)],
            ["CatalogName", _catalog_name(detail)],
            ["Type", _object_type(detail)],
            ["Description", _field(detail, "Description")],
            ["CreateTime", _field(detail, "CreateTime")],
            ["UpdateTime", _field(detail, "UpdateTime")],
            ["DatabaseCount", str(database_count)],
        ]
        print_table(rows, ["字段", "值"])
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def catalog_list_databases(args: argparse.Namespace):
    credentials, manager = _build_catalog_manager(args)
    if manager is None or credentials is None:
        return
    region = str(credentials.region or "").strip()
    if not region:
        print("❌ 当前未配置 region，请先执行 `volc_flink config set-region --region <region>`")
        return
    print_header("Database 列表")
    try:
        catalog_id = _resolve_catalog_id(manager, region, args.catalog_id, getattr(args, "catalog_name", None))
        databases = _list_catalog_databases_with_fallback(manager, region, catalog_id)
        if getattr(args, "raw", False):
            print(json.dumps(_redact_sensitive(databases), ensure_ascii=False, indent=2))
            return
        print_table([[_database_name(d), _database_id(d), _object_type(d)] for d in databases], ["DatabaseName", "Id", "Type"])
        print(f"\n📊 总计: {len(databases)} 个 Database")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def catalog_show_database(args: argparse.Namespace):
    credentials, manager = _build_catalog_manager(args)
    if manager is None or credentials is None:
        return
    region = str(credentials.region or "").strip()
    if not region:
        print("❌ 当前未配置 region，请先执行 `volc_flink config set-region --region <region>`")
        return
    print_header("Database 详情")
    try:
        catalog_id = _resolve_catalog_id(manager, region, args.catalog_id, getattr(args, "catalog_name", None))
        detail = _get_catalog_database_with_fallback(manager, region, catalog_id, args.database)
        tables = _list_catalog_tables_with_fallback(manager, region, catalog_id, args.database)
        if getattr(args, "raw", False):
            print(json.dumps(_redact_sensitive({"database": detail, "tables": tables}), ensure_ascii=False, indent=2))
            return
        nested_tables = detail.get("CatalogTables")
        if isinstance(nested_tables, list) and nested_tables:
            table_count = len(nested_tables)
        else:
            table_count = len(tables)
        rows = [
            ["CatalogId", _field(detail, "CatalogId")],
            ["DatabaseId", _database_id(detail)],
            ["DatabaseName", _database_name(detail)],
            ["Type", _object_type(detail)],
            ["Description", _field(detail, "Description")],
            ["CreateTime", _field(detail, "CreateTime")],
            ["UpdateTime", _field(detail, "UpdateTime")],
            ["TableCount", str(table_count)],
        ]
        print_table(rows, ["字段", "值"])
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def catalog_list_tables(args: argparse.Namespace):
    credentials, manager = _build_catalog_manager(args)
    if manager is None or credentials is None:
        return
    region = str(credentials.region or "").strip()
    if not region:
        print("❌ 当前未配置 region，请先执行 `volc_flink config set-region --region <region>`")
        return
    print_header("Table 列表")
    try:
        catalog_id = _resolve_catalog_id(manager, region, args.catalog_id, getattr(args, "catalog_name", None))
        tables = _list_catalog_tables_with_fallback(manager, region, catalog_id, args.database)
        if getattr(args, "raw", False):
            print(json.dumps(_redact_sensitive(tables), ensure_ascii=False, indent=2))
            return
        print_table([[_table_name(t), _table_id(t), _object_type(t)] for t in tables], ["TableName", "Id", "Type"])
        print(f"\n📊 总计: {len(tables)} 个 Table")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def catalog_show_table(args: argparse.Namespace):
    credentials, manager = _build_catalog_manager(args)
    if manager is None or credentials is None:
        return
    region = str(credentials.region or "").strip()
    if not region:
        print("❌ 当前未配置 region，请先执行 `volc_flink config set-region --region <region>`")
        return
    print_header("Table 详情")
    try:
        catalog_id = _resolve_catalog_id(manager, region, args.catalog_id, getattr(args, "catalog_name", None))
        detail = _get_catalog_table_with_fallback(manager, region, catalog_id, args.database, args.table)
        if getattr(args, "raw", False):
            print(json.dumps(_redact_sensitive(detail), ensure_ascii=False, indent=2))
            return
        columns = detail.get("Columns") or detail.get("ColumnList") or detail.get("Fields") or []
        rows = [
            ["CatalogId", _field(detail, "CatalogId")],
            ["DatabaseId", _field(detail, "DatabaseId")],
            ["DatabaseName", _field(detail, "DatabaseName")],
            ["TableId", _table_id(detail)],
            ["TableName", _table_name(detail)],
            ["Type", _object_type(detail)],
            ["Description", _field(detail, "Description")],
            ["CreateTime", _field(detail, "CreateTime")],
            ["UpdateTime", _field(detail, "UpdateTime")],
            ["ColumnCount", str(len(columns) if isinstance(columns, list) else 0)],
        ]
        print_table(rows, ["字段", "值"])
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def attach_catalog_subcommands(subparsers):
    catalog_parser = subparsers.add_parser("catalog", help="Catalog 元数据")
    catalog_parser.set_defaults(func=lambda _args, p=catalog_parser: p.print_help())
    catalog_parser.add_argument("-p", "--project", help="项目名称（可省略，使用默认项目）")
    catalog_parser.add_argument("--project-id", help="项目ID（兼容参数）")
    catalog_subparsers = catalog_parser.add_subparsers(title="catalog 子命令")
    catalog_tree_parser = catalog_subparsers.add_parser("tree", help="递归列出 Catalog/Database/Table 树")
    catalog_id_group = catalog_tree_parser.add_mutually_exclusive_group()
    catalog_id_group.add_argument("--catalog-id", help="只看某个 CatalogId")
    catalog_id_group.add_argument("--catalog-name", help="只看某个 CatalogName")
    catalog_tree_parser.add_argument("--database", help="只看某个 DatabaseName")
    catalog_tree_parser.add_argument("--level", choices=["catalog", "database", "table"], default="table", help="树展示层级，默认 table")
    catalog_tree_parser.add_argument("--raw", action="store_true", help="输出完整 JSON")
    catalog_tree_parser.set_defaults(func=catalog_tree)

    catalog_catalogs_parser = catalog_subparsers.add_parser("catalogs", help="Catalog 查询")
    catalog_catalogs_parser.set_defaults(func=lambda _args, p=catalog_catalogs_parser: p.print_help())
    catalog_catalogs_subparsers = catalog_catalogs_parser.add_subparsers(title="catalogs 子命令")
    catalog_catalogs_list = catalog_catalogs_subparsers.add_parser("list", help="列出 Catalog")
    catalog_catalogs_list.add_argument("--raw", action="store_true", help="输出原始 JSON")
    catalog_catalogs_list.set_defaults(func=catalog_list_catalogs)
    catalog_catalogs_show = catalog_catalogs_subparsers.add_parser("show", help="查看某个 Catalog 详情")
    catalog_catalogs_show_id_group = catalog_catalogs_show.add_mutually_exclusive_group(required=True)
    catalog_catalogs_show_id_group.add_argument("--catalog-id", required=False, help="CatalogId")
    catalog_catalogs_show_id_group.add_argument("--catalog-name", required=False, help="CatalogName")
    catalog_catalogs_show.add_argument("--raw", action="store_true", help="输出原始 JSON")
    catalog_catalogs_show.set_defaults(func=catalog_show_catalog)

    catalog_dbs_parser = catalog_subparsers.add_parser("databases", help="Database 查询")
    catalog_dbs_parser.set_defaults(func=lambda _args, p=catalog_dbs_parser: p.print_help())
    catalog_dbs_subparsers = catalog_dbs_parser.add_subparsers(title="databases 子命令")
    catalog_dbs_list = catalog_dbs_subparsers.add_parser("list", help="列出 Catalog 下的 Database")
    catalog_dbs_list_id_group = catalog_dbs_list.add_mutually_exclusive_group(required=True)
    catalog_dbs_list_id_group.add_argument("--catalog-id", required=False, help="CatalogId")
    catalog_dbs_list_id_group.add_argument("--catalog-name", required=False, help="CatalogName")
    catalog_dbs_list.add_argument("--raw", action="store_true", help="输出原始 JSON")
    catalog_dbs_list.set_defaults(func=catalog_list_databases)
    catalog_dbs_show = catalog_dbs_subparsers.add_parser("show", help="查看某个 Database 详情")
    catalog_dbs_show_id_group = catalog_dbs_show.add_mutually_exclusive_group(required=True)
    catalog_dbs_show_id_group.add_argument("--catalog-id", required=False, help="CatalogId")
    catalog_dbs_show_id_group.add_argument("--catalog-name", required=False, help="CatalogName")
    catalog_dbs_show.add_argument("--database", required=True, help="DatabaseName")
    catalog_dbs_show.add_argument("--raw", action="store_true", help="输出原始 JSON")
    catalog_dbs_show.set_defaults(func=catalog_show_database)

    catalog_tables_parser = catalog_subparsers.add_parser("tables", help="Table 查询")
    catalog_tables_parser.set_defaults(func=lambda _args, p=catalog_tables_parser: p.print_help())
    catalog_tables_subparsers = catalog_tables_parser.add_subparsers(title="tables 子命令")
    catalog_tables_list = catalog_tables_subparsers.add_parser("list", help="列出 Database 下的 Table")
    catalog_tables_list_id_group = catalog_tables_list.add_mutually_exclusive_group(required=True)
    catalog_tables_list_id_group.add_argument("--catalog-id", required=False, help="CatalogId")
    catalog_tables_list_id_group.add_argument("--catalog-name", required=False, help="CatalogName")
    catalog_tables_list.add_argument("--database", required=True, help="DatabaseName")
    catalog_tables_list.add_argument("--raw", action="store_true", help="输出原始 JSON")
    catalog_tables_list.set_defaults(func=catalog_list_tables)
    catalog_tables_show = catalog_tables_subparsers.add_parser("show", help="查看某个 Table 详情")
    catalog_tables_show_id_group = catalog_tables_show.add_mutually_exclusive_group(required=True)
    catalog_tables_show_id_group.add_argument("--catalog-id", required=False, help="CatalogId")
    catalog_tables_show_id_group.add_argument("--catalog-name", required=False, help="CatalogName")
    catalog_tables_show.add_argument("--database", required=True, help="DatabaseName")
    catalog_tables_show.add_argument("--table", required=True, help="TableName")
    catalog_tables_show.add_argument("--raw", action="store_true", help="输出原始 JSON")
    catalog_tables_show.set_defaults(func=catalog_show_table)
