import argparse

from volcano_flink_client.auth.auth import AuthManager
from volcano_flink_client.api import ApiClient
from volcano_flink_client.projects.projects import ProjectManager
from volcano_flink_cli.common import print_header, print_table


def list_projects(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return

    api_client = ApiClient(credentials)
    project_manager = ProjectManager(api_client)
    current_region = credentials.region

    print_header("项目列表")
    try:
        projects = project_manager.list_projects(
            page=args.page_num,
            page_size=args.page_size,
            search=args.search_key,
        )
        data = []
        for project in projects:
            data.append([project.id, project.name, project.status, project.create_time])

        print_table(data, ["项目ID", "项目名称", "状态", "创建时间"])
        print(f"\n📊 总计: {len(projects)} 个项目")
        if len(projects) == 0:
            print(f"💡 当前 Region: {current_region}")
            print("   projects list 是按 Region 查询的，空结果通常表示当前 Region 下没有项目")
            print("   可使用 `volc_flink config set-region --region <region>` 切换后重试")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def get_project_details(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return

    api_client = ApiClient(credentials)
    project_manager = ProjectManager(api_client)

    print_header("项目详情")
    try:
        project = project_manager.get_project_details(project_name=args.name)
        print(f"项目ID: {project.id}")
        print(f"项目名称: {project.name}")
        print(f"状态: {project.status}")
        print(f"创建时间: {project.create_time}")
        print(f"更新时间: {project.update_time}")
        if project.description:
            print(f"描述: {project.description}")
        if project.owner:
            print(f"Owner: {project.owner}")
        if isinstance(project.tags, dict) and project.tags:
            print("Tags:")
            for k, v in project.tags.items():
                print(f"  {k}: {v}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def attach_projects_subcommands(subparsers):
    project_parser = subparsers.add_parser("projects", help="项目操作")
    project_parser.set_defaults(func=lambda _args, p=project_parser: p.print_help())
    project_subparsers = project_parser.add_subparsers(title="项目子命令")

    list_projects_parser = project_subparsers.add_parser("list", help="列举项目")
    list_projects_parser.add_argument("--search-key", default="", help="按项目名称模糊搜索")
    list_projects_parser.add_argument("--page-size", type=int, default=50, help="每页大小 (默认: 50)")
    list_projects_parser.add_argument("--page-num", type=int, default=1, help="页码 (默认: 1)")
    list_projects_parser.set_defaults(func=list_projects)

    project_detail_parser = project_subparsers.add_parser("detail", help="查看项目详情")
    project_detail_parser.add_argument("-n", "--name", required=True, help="项目名称")
    project_detail_parser.set_defaults(func=get_project_details)
