import argparse
import json

from volcano_flink_client.auth.auth import AuthManager
from volcano_flink_client.api import ApiClient
from volcano_flink_client.resource_pools.resource_pools import ResourcePoolManager, ResourcePoolSpec
from volcano_flink_cli.common import _resolve_project_id, print_header, print_table


def list_resource_pools(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    resource_pool_manager = ResourcePoolManager(api_client, project_id)

    print_header("资源池列表")
    try:
        pools = resource_pool_manager.list_resource_pools(page=1, page_size=50)
        data = []
        for pool in pools:
            data.append([pool.id, pool.name, pool.type, pool.status, pool.vcores, pool.memory_gb])
        print_table(data, ["资源池ID", "名称", "类型", "状态", "CPU核数", "内存(GB)"])
        print(f"\n📊 总计: {len(pools)} 个资源池")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def create_resource_pool(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    resource_pool_manager = ResourcePoolManager(api_client, project_id)

    print_header("创建资源池")
    try:
        spec = ResourcePoolSpec(vcores=args.vcores, memory_gb=args.memory_gb, type="flink")
        pool = resource_pool_manager.create_resource_pool(
            name=args.name,
            description=args.description,
            spec=spec,
        )
        print("✅ 资源池创建成功!")
        print(f"ID: {pool.id}")
        print(f"名称: {pool.name}")
        print(f"状态: {pool.status}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def get_resource_pool_details(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return

    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    resource_pool_manager = ResourcePoolManager(api_client, project_id)

    print_header("资源池详情")
    try:
        ref = args.resource_pool_id or args.name
        pool = resource_pool_manager.get_resource_pool_details(ref)
        data = [
            ["资源池ID", pool.id],
            ["名称", pool.name],
            ["FullName", pool.full_name],
            ["类型", pool.type],
            ["状态", pool.status],
            ["CPU核数", str(pool.vcores)],
            ["内存(GB)", str(pool.memory_gb)],
            ["可用CPU核数", str(pool.available_vcores)],
            ["可用内存(GB)", str(pool.available_memory_gb)],
            ["描述", pool.description],
            ["创建时间", pool.create_time],
            ["更新时间", pool.update_time],
            ["标签", json.dumps(pool.tags, ensure_ascii=False) if pool.tags else ""],
        ]
        print_table(data, ["字段", "值"])

        extra_info = getattr(pool, "extra_info", None)
        if isinstance(extra_info, dict) and extra_info:
            print("\nExtraInfo:")
            print(json.dumps(extra_info, ensure_ascii=False, indent=2, sort_keys=True))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def attach_resource_pools_subcommands(subparsers):
    resource_pool_parser = subparsers.add_parser("resource-pools", help="资源池操作")
    resource_pool_parser.set_defaults(func=lambda _args, p=resource_pool_parser: p.print_help())
    resource_pool_parser.add_argument("-p", "--project", help="项目名称（可省略，使用默认项目）")
    resource_pool_parser.add_argument("--project-id", help="项目ID（兼容参数）")
    resource_pool_subparsers = resource_pool_parser.add_subparsers(title="资源池子命令")

    list_resource_pools_parser = resource_pool_subparsers.add_parser("list", help="列举资源池")
    list_resource_pools_parser.set_defaults(func=list_resource_pools)

    detail_resource_pools_parser = resource_pool_subparsers.add_parser("detail", help="查看资源池详情")
    detail_id_group = detail_resource_pools_parser.add_mutually_exclusive_group(required=True)
    detail_id_group.add_argument("-i", "--resource-pool-id", dest="resource_pool_id", help="资源池ID")
    detail_id_group.add_argument("-n", "--name", help="资源池名称")
    detail_resource_pools_parser.set_defaults(func=get_resource_pool_details)

    create_resource_pool_parser = resource_pool_subparsers.add_parser("create", help="创建资源池")
    create_resource_pool_parser.add_argument("-n", "--name", required=True, help="资源池名称")
    create_resource_pool_parser.add_argument("-d", "--description", help="资源池描述")
    create_resource_pool_parser.add_argument("-c", "--vcores", type=int, default=4, help="CPU核数 (默认: 4)")
    create_resource_pool_parser.add_argument("-m", "--memory-gb", type=int, default=16, help="内存GB (默认: 16)")
    create_resource_pool_parser.set_defaults(func=create_resource_pool)
