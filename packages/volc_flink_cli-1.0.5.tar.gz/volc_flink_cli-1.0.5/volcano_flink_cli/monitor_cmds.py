import argparse
import json
import time
from datetime import datetime
from typing import Any, Dict, List, Optional

import requests

from volcano_flink_client.api import ApiClient
from volcano_flink_client.auth.auth import AuthManager
from volcano_flink_client.jobs.jobs import JobManager
from volcano_flink_cli.common import _resolve_project_id, print_header, print_table


def _parse_dt(s: Optional[str]) -> Optional[datetime]:
    if not s:
        return None
    raw = str(s).strip()
    if not raw:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S"):
        try:
            return datetime.strptime(raw, fmt)
        except Exception:
            pass
    raise Exception("时间格式错误，示例：2025-01-01 12:00:00 或 2025-01-01T12:00:00")


def _fetch_flinkui_json(url: str, timeout_s: float = 15.0, verify_ssl: bool = True) -> Any:
    headers = {"open-platform-internal-flag": "true"}
    r = requests.get(url, timeout=float(timeout_s), verify=bool(verify_ssl), headers=headers)
    if r.status_code >= 400:
        raise Exception(f"HTTP {r.status_code}: {r.text}")
    try:
        return r.json()
    except Exception:
        try:
            return json.loads(r.text or "")
        except Exception:
            return {"raw": r.text or ""}


def _pick_instance_id(job_manager: JobManager, job_id: str, instance_id: Optional[str]) -> str:
    if instance_id:
        return str(instance_id)
    resp = job_manager.list_job_instances(job_id=job_id, state="RUNNING", page=1, page_size=1)
    records = resp.get("Records") or []
    if isinstance(records, list) and records:
        it = records[0]
        if isinstance(it, dict):
            iid = it.get("InstanceId") or it.get("Id")
            if iid:
                return str(iid)
    resp2 = job_manager.list_job_instances(job_id=job_id, page=1, page_size=1)
    records2 = resp2.get("Records") or []
    if isinstance(records2, list) and records2:
        it = records2[0]
        if isinstance(it, dict):
            iid = it.get("InstanceId") or it.get("Id")
            if iid:
                return str(iid)
    raise Exception("未找到实例，请检查 JobId 或稍后重试")


def _resolve_flinkui_base_url(job_manager: JobManager, job_id: str) -> str:
    iid = _pick_instance_id(job_manager, job_id, None)
    inst = job_manager.get_job_instance(iid)
    base = job_manager.get_instance_flink_proxy_base_url(inst)
    if not base:
        raise Exception("未获取到实例的 RestUrl/CompleteRestUrl，无法访问 FlinkUI")
    return str(base)


def _flinkui_url(job_manager: JobManager, base_url: str, path: str, api_prefix: str = "") -> str:
    prefix = str(api_prefix or "").strip().strip("/")
    p = str(path or "").strip()
    if not p.startswith("/"):
        p = "/" + p
    full_path = f"/{prefix}{p}" if prefix else p
    return job_manager.build_flink_proxy_url(base_url, full_path)


def monitor_events(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)
    print_header("任务事件")
    try:
        events = job_manager.get_job_events(job_id=args.job_id, limit=args.limit)
        events = events[: int(args.limit)]
        if getattr(args, "raw", False):
            print(json.dumps(events, ensure_ascii=False, indent=2))
            return

        data = []
        for item in events:
            if not isinstance(item, dict):
                continue

            def pick(keys: List[str]) -> str:
                for k in keys:
                    v = item.get(k)
                    if v is not None and str(v) != "":
                        return str(v)
                return ""

            data.append(
                [
                    pick(["Time", "EventTime", "Timestamp", "CreateTime", "LastTimestamp", "FirstTimestamp"]),
                    pick(["Level", "Type", "Severity", "EventType"]),
                    pick(["Collector", "Source", "Component", "Reason", "Name", "Title"]),
                    pick(["Message", "Msg", "Content", "Detail"]),
                ]
            )
        print_table(data, ["Time", "Level", "Collector", "Message"])
        print(f"\n📊 总计: {len(events)} 条事件记录")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def monitor_logs(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)
    print_header("任务日志")
    try:
        instance_id = str(getattr(args, "instance_id", "") or "").strip()
        if not instance_id:
            instance_id = _pick_instance_id(job_manager, str(args.job_id), None)
        component = str(args.component or "jobmanager").strip().lower() or "jobmanager"
        file_name = str(getattr(args, "file_name", "") or getattr(args, "file", "") or "").strip()

        now_ms = int(time.time() * 1000)
        start_ms = getattr(args, "start_time_ms", None)
        end_ms = getattr(args, "end_time_ms", None)

        if start_ms is None and getattr(args, "since", None):
            try:
                start_ms = int(_parse_dt(args.since).timestamp() * 1000)
            except Exception:
                start_ms = None
        if end_ms is None and getattr(args, "until", None):
            try:
                end_ms = int(_parse_dt(args.until).timestamp() * 1000)
            except Exception:
                end_ms = None

        if end_ms is None:
            end_ms = now_ms
        if start_ms is None:
            start_ms = int(end_ms) - 3600 * 1000

        start_ms = int(start_ms)
        end_ms = int(end_ms)
        if start_ms > end_ms:
            raise Exception("StartTime 不能大于 EndTime")

        cursor = str(getattr(args, "cursor", "") or "").strip()
        page_size = int(getattr(args, "page_size", 500) or 500)
        if page_size <= 0:
            page_size = 500

        def fetch_once(cursor_in: str, end_override_ms: Optional[int]) -> str:
            end_use = int(end_override_ms) if end_override_ms is not None else end_ms
            resp = job_manager.list_gas_logs(
                instance_id=instance_id,
                component=component,
                level=getattr(args, "level", None),
                start_time_ms=start_ms,
                end_time_ms=end_use,
                cursor=cursor_in,
                page_size=page_size,
                file_name=file_name,
            )
            msgs = resp.get("Messages") if isinstance(resp, dict) else None
            next_cursor = str(resp.get("Cursor") or "") if isinstance(resp, dict) else ""
            if isinstance(msgs, list):
                for m in msgs:
                    if m is None:
                        continue
                    print(str(m))
            return next_cursor

        if args.follow:
            cur = cursor
            while True:
                now2 = int(time.time() * 1000)
                cur2 = fetch_once(
                    cur,
                    now2
                    if getattr(args, "until", None) is None and getattr(args, "end_time_ms", None) is None
                    else None,
                )
                if cur2:
                    cur = cur2
                time.sleep(float(args.interval))
        else:
            cursor_out = fetch_once(cursor, None)
            if cursor_out:
                print(f"\nCursor: {cursor_out}")
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def monitor_flinkui_url(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)
    print_header("FlinkUI 地址")
    try:
        base = _resolve_flinkui_base_url(job_manager, str(args.job_id))
        print(base)
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def monitor_flinkui_overview(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)
    print_header("FlinkUI 作业概览")
    try:
        base = _resolve_flinkui_base_url(job_manager, str(args.job_id))
        url = _flinkui_url(job_manager, base, "/jobs/overview", api_prefix=str(args.api_prefix or ""))
        data = _fetch_flinkui_json(url, timeout_s=float(args.timeout), verify_ssl=not bool(args.insecure))
        selected_job = None
        selected_job_id = ""
        jobs = data.get("jobs") if isinstance(data, dict) else None
        if isinstance(jobs, list) and jobs:
            selected_job = jobs[0]
            if isinstance(selected_job, dict):
                selected_job_id = str(selected_job.get("jid") or selected_job.get("jobId") or "")
        out = {"overview": data, "selected_job": selected_job, "selected_job_id": selected_job_id, "flinkui": base}
        print(json.dumps(out, ensure_ascii=False, indent=2))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def monitor_flinkui_exceptions(args: argparse.Namespace):
    auth_manager = AuthManager()
    credentials = auth_manager.load_credentials()
    if not credentials:
        print("❌ 请先登录")
        return
    project_id = _resolve_project_id(args, credentials)
    api_client = ApiClient(credentials)
    job_manager = JobManager(api_client, project_id)
    print_header("FlinkUI 异常信息")
    try:
        base = _resolve_flinkui_base_url(job_manager, str(args.job_id))
        actual_job_id = str(args.flink_job_id or "").strip()
        if not actual_job_id:
            ov_url = _flinkui_url(job_manager, base, "/jobs/overview", api_prefix=str(args.api_prefix or ""))
            overview = _fetch_flinkui_json(ov_url, timeout_s=float(args.timeout), verify_ssl=not bool(args.insecure))
            jobs = overview.get("jobs") if isinstance(overview, dict) else None
            if isinstance(jobs, list) and jobs:
                first = jobs[0]
                if isinstance(first, dict):
                    actual_job_id = str(first.get("jid") or first.get("jobId") or "").strip()
        if not actual_job_id:
            raise Exception("未获取到 Flink JobId，请使用 --flink-job-id 指定")
        ex_url = _flinkui_url(
            job_manager,
            base,
            f"/jobs/{actual_job_id}/exceptions",
            api_prefix=str(args.api_prefix or ""),
        )
        data = _fetch_flinkui_json(ex_url, timeout_s=float(args.timeout), verify_ssl=not bool(args.insecure))
        out = {"job_id": actual_job_id, "exceptions": data, "flinkui": base}
        print(json.dumps(out, ensure_ascii=False, indent=2))
    except Exception as e:
        print(f"❌ 错误: {str(e)}")


def attach_monitor_subcommands(subparsers):
    monitor_parser = subparsers.add_parser("monitor", help="监控与日志查询")
    monitor_parser.set_defaults(func=lambda _args, p=monitor_parser: p.print_help())
    monitor_parser.add_argument("-p", "--project", help="项目名称（可省略，使用默认项目）")
    monitor_parser.add_argument("--project-id", help="项目ID（兼容参数）")
    monitor_subparsers = monitor_parser.add_subparsers(title="monitor 子命令")

    monitor_events_parser = monitor_subparsers.add_parser("events", help="查询任务运行事件")
    monitor_events_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    monitor_events_parser.add_argument("--limit", type=int, default=50, help="返回条数（默认 50）")
    monitor_events_parser.add_argument("--raw", action="store_true", help="输出原始 JSON")
    monitor_events_parser.set_defaults(func=monitor_events)

    monitor_logs_parser = monitor_subparsers.add_parser("logs", help="查询任务日志（支持历史实例、tail、时间范围、级别过滤）")
    monitor_logs_parser.add_argument("-i", "--job-id", required=True, help="任务ID")
    monitor_logs_parser.add_argument("--instance-id", help="实例ID（不传默认选取最新实例）")
    monitor_logs_parser.add_argument("--component", default="jobmanager", choices=["jobmanager", "taskmanager"], help="日志组件")
    monitor_logs_parser.add_argument("--taskmanager-id", help="taskmanager id（component=taskmanager 时可选）")
    monitor_logs_parser.add_argument("--file", help="日志文件名（用于 logs 列表模式）")
    monitor_logs_parser.add_argument("--file-name", dest="file_name", help="日志文件名（兼容参数）")
    monitor_logs_parser.add_argument("--level", choices=["DEBUG", "INFO", "WARN", "ERROR"], help="日志级别过滤")
    monitor_logs_parser.add_argument("--since", help="开始时间，格式 2025-01-01 12:00:00")
    monitor_logs_parser.add_argument("--until", help="结束时间，格式 2025-01-01 13:00:00")
    monitor_logs_parser.add_argument("--start-time-ms", dest="start_time_ms", type=int, help="开始时间（Unix 毫秒）")
    monitor_logs_parser.add_argument("--end-time-ms", dest="end_time_ms", type=int, help="结束时间（Unix 毫秒）")
    monitor_logs_parser.add_argument("--cursor", default="", help="游标（用于从上次位置继续拉取）")
    monitor_logs_parser.add_argument("--page-size", dest="page_size", type=int, default=500, help="返回条数（默认 500）")
    monitor_logs_parser.add_argument("--lines", type=int, default=200, help="展示末尾行数（默认 200）")
    monitor_logs_parser.add_argument("--follow", action="store_true", help="实时 tail")
    monitor_logs_parser.add_argument("--interval", type=float, default=2.0, help="tail 间隔秒（默认 2）")
    monitor_logs_parser.set_defaults(func=monitor_logs)

    monitor_flinkui_parser = monitor_subparsers.add_parser("flinkui", help="FlinkUI 查询（URL/overview/exceptions）")
    monitor_flinkui_parser.set_defaults(func=lambda _args, p=monitor_flinkui_parser: p.print_help())
    flinkui_subparsers = monitor_flinkui_parser.add_subparsers(title="flinkui 子命令")
    flinkui_common = argparse.ArgumentParser(add_help=False)
    flinkui_common.add_argument("-i", "--job-id", required=True, help="任务ID（用于定位实例 FlinkUI）")
    flinkui_common.add_argument("--api-prefix", default="", help="API 前缀（例如 /api，默认空）")
    flinkui_common.add_argument("--timeout", type=float, default=15.0, help="请求超时秒（默认 15）")
    flinkui_common.add_argument("--insecure", action="store_true", help="跳过 SSL 校验")

    flinkui_url_parser = flinkui_subparsers.add_parser("url", parents=[flinkui_common], help="输出 FlinkUI 基础地址")
    flinkui_url_parser.set_defaults(func=monitor_flinkui_url)

    flinkui_overview_parser = flinkui_subparsers.add_parser(
        "overview",
        parents=[flinkui_common],
        help="获取作业概览并选取第一个作业",
    )
    flinkui_overview_parser.set_defaults(func=monitor_flinkui_overview)

    flinkui_ex_parser = flinkui_subparsers.add_parser(
        "exceptions",
        parents=[flinkui_common],
        help="获取作业异常信息",
    )
    flinkui_ex_parser.add_argument("--flink-job-id", default="", help="Flink 作业 ID（不传则从 overview 取第一个）")
    flinkui_ex_parser.set_defaults(func=monitor_flinkui_exceptions)

