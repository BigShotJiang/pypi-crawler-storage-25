"""
资源池模块 - 处理资源池相关操作
Resource Pools Module - Handles resource pool-related operations
"""

from typing import List, Optional, Dict, Any
from dataclasses import dataclass
from datetime import datetime
from volcano_flink_client.api import ApiClient


@dataclass
class ResourcePool:
    """资源池信息类"""
    id: str
    name: str
    full_name: str
    type: str
    status: str
    description: str
    vcores: int
    memory_gb: int
    available_vcores: int
    available_memory_gb: int
    create_time: str
    update_time: str
    tags: Optional[Dict[str, str]] = None
    extra_info: Optional[Dict[str, Any]] = None
    resources: Optional[List[Dict[str, Any]]] = None
    raw: Optional[Dict[str, Any]] = None


@dataclass
class ResourcePoolSpec:
    """资源池规格配置类"""
    vcores: int
    memory_gb: int
    type: str = "flink"


class ResourcePoolManager:
    """
    资源池管理类，支持：
    1. 在项目中列举资源池
    2. 创建资源池
    3. 查看资源池详情
    4. 更新资源池
    5. 删除资源池
    """
    
    def __init__(self, api_client: ApiClient, project_id: str):
        self.api_client = api_client
        self.project_id = project_id
        self.service = "flink"
        self.version = "2022-06-01"
    
    def list_resource_pools(
        self,
        page: int = 1,
        page_size: int = 10,
        status: Optional[str] = None,
        type_filter: Optional[str] = None,
        name_key: Optional[str] = None,
    ) -> List[ResourcePool]:
        """
        列举项目中的资源池
        
        Args:
            page: 页码
            page_size: 每页大小
            status: 状态筛选
            type_filter: 类型筛选
            
        Returns:
            资源池列表
        """
        response = self.api_client.openapi_invoke(
            action="ListGMCSResourcePool",
            version=self.version,
            service=self.service,
            method="GET",
            query_params=[
                ("ProjectId", self.project_id),
                ("Name", ""),
                ("NameKey", str(name_key or "")),
                ("PageSize", page_size),
                ("PageNum", page),
            ],
        )
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")

        if isinstance(response, dict) and isinstance(response.get("Result"), dict):
            result = response["Result"]
        else:
            result = response if isinstance(response, dict) else {}

        raw_list = (
            result.get("DataList")
            or result.get("Items")
            or result.get("ResourcePools")
            or result.get("ResourcePoolList")
            or result.get("List")
            or []
        )

        resource_pools: List[ResourcePool] = []
        if isinstance(raw_list, list):
            for item in raw_list:
                if not isinstance(item, dict):
                    continue

                resources = item.get("Resources") if isinstance(item.get("Resources"), list) else []
                cpu_allocated = 0
                mem_allocated = 0
                for r in resources:
                    if not isinstance(r, dict):
                        continue
                    if r.get("Uri") == "cpu":
                        cpu_allocated = r.get("Allocated") or 0
                    if r.get("Uri") == "memory":
                        mem_allocated = r.get("Allocated") or 0

                def _format_time(value: Any) -> str:
                    if isinstance(value, (int, float)):
                        try:
                            return datetime.fromtimestamp(value / 1000).strftime("%Y-%m-%d %H:%M:%S")
                        except Exception:
                            return str(value)
                    return str(value or "")

                pool_id = (
                    item.get("ResourcePoolId")
                    or item.get("PoolId")
                    or item.get("ID")
                    or item.get("Id")
                    or item.get("id")
                )
                pool_name = (
                    item.get("Name")
                    or item.get("ResourcePoolName")
                    or item.get("name")
                    or pool_id
                )
                full_name = item.get("FullName") or item.get("Namespace") or pool_id or pool_name
                pool_type = item.get("ProductType") or item.get("Type") or item.get("type") or ""
                pool_status = item.get("Status") or item.get("status") or ""

                vcores = item.get("VCores") or item.get("Vcores") or item.get("vcores") or cpu_allocated or 0
                memory_gb = item.get("MemoryGB") or item.get("MemoryGb") or item.get("memory_gb") or mem_allocated or 0
                available_vcores = item.get("AvailableVCores") or item.get("available_vcores") or 0
                available_memory_gb = item.get("AvailableMemoryGB") or item.get("available_memory_gb") or 0

                resource_pools.append(ResourcePool(
                    id=str(pool_id or pool_name or ""),
                    name=str(pool_name or ""),
                    full_name=str(full_name or ""),
                    type=str(pool_type or ""),
                    status=str(pool_status or ""),
                    description=str(item.get("Description") or item.get("description") or ""),
                    vcores=int(vcores or 0),
                    memory_gb=int(memory_gb or 0),
                    available_vcores=int(available_vcores or 0),
                    available_memory_gb=int(available_memory_gb or 0),
                    create_time=_format_time(item.get("CreateTime") or item.get("CreatDate") or item.get("create_time")),
                    update_time=_format_time(item.get("UpdateTime") or item.get("update_time")),
                    tags=item.get("ResourceTags") or item.get("Tags") or item.get("tags"),
                    extra_info=item.get("ExtraInfo") if isinstance(item.get("ExtraInfo"), dict) else None,
                    resources=resources if isinstance(resources, list) else None,
                    raw=item,
                ))

        if status:
            resource_pools = [p for p in resource_pools if p.status == status]
        if type_filter:
            resource_pools = [p for p in resource_pools if p.type == type_filter]

        return resource_pools
    
    def get_resource_pool_details(self, resource_pool_id: str) -> ResourcePool:
        """
        获取资源池详情
        
        Args:
            resource_pool_id: 资源池 ID
            
        Returns:
            资源池详情对象
        """
        ref = str(resource_pool_id or "").strip()
        if not ref:
            raise Exception("资源池ID不能为空")

        pools = self.list_resource_pools(page=1, page_size=1000, name_key=ref)
        if not pools:
            pools = self.list_resource_pools(page=1, page_size=1000)

        id_matches = [p for p in pools if p.id == ref]
        if len(id_matches) == 1:
            return id_matches[0]
        if len(id_matches) > 1:
            raise Exception("资源池ID匹配到多条记录，请联系管理员确认数据")

        full_matches = [p for p in pools if p.full_name == ref]
        if len(full_matches) == 1:
            return full_matches[0]
        if len(full_matches) > 1:
            raise Exception("资源池FullName匹配到多条记录，请使用资源池ID查询")

        name_matches = [p for p in pools if p.name == ref]
        if len(name_matches) == 1:
            return name_matches[0]
        if len(name_matches) > 1:
            raise Exception("资源池名称匹配到多条记录，请使用资源池ID查询")

        raise Exception("未找到指定资源池，请先使用 resource-pools list 确认资源池ID")
    
    def create_resource_pool(self, name: str, description: str, spec: ResourcePoolSpec,
                           tags: Optional[Dict[str, str]] = None) -> ResourcePool:
        """
        创建资源池
        
        Args:
            name: 资源池名称
            description: 描述
            spec: 资源规格
            tags: 标签
            
        Returns:
            新创建的资源池对象
        """
        raise NotImplementedError("Resource pool create API is not implemented for OpenAPI mode")
    
    def update_resource_pool(self, resource_pool_id: str, name: Optional[str] = None,
                          description: Optional[str] = None,
                          spec: Optional[ResourcePoolSpec] = None,
                          tags: Optional[Dict[str, str]] = None) -> ResourcePool:
        """
        更新资源池
        
        Args:
            resource_pool_id: 资源池 ID
            name: 新名称（可选）
            description: 新描述（可选）
            spec: 新规格（可选）
            tags: 新标签（可选）
            
        Returns:
            更新后的资源池对象
        """
        raise NotImplementedError("Resource pool update API is not implemented for OpenAPI mode")
    
    def delete_resource_pool(self, resource_pool_id: str) -> bool:
        """
        删除资源池
        
        Args:
            resource_pool_id: 资源池 ID
            
        Returns:
            是否成功删除
        """
        raise NotImplementedError("Resource pool delete API is not implemented for OpenAPI mode")
    
    def get_resource_pool_metrics(self, resource_pool_id: str,
                                 start_time: str = None, end_time: str = None) -> Dict[str, Any]:
        """
        获取资源池指标
        
        Args:
            resource_pool_id: 资源池 ID
            start_time: 开始时间
            end_time: 结束时间
            
        Returns:
            指标数据
        """
        raise NotImplementedError("Resource pool metrics API is not implemented for OpenAPI mode")
