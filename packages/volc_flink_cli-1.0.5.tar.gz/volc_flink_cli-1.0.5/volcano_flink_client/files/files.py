from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import tos

from volcano_flink_client.auth.auth import Credentials


@dataclass
class TOSObject:
    key: str
    size: int
    last_modified: str
    etag: str


class TOSFilesManager:
    def __init__(self, credentials: Credentials):
        self.credentials = credentials
        self._auth = tos.Auth(credentials.access_key, credentials.secret_key, credentials.region)
        self._client = tos.TosClient(self._auth, self._endpoint(credentials.region))

    @staticmethod
    def _endpoint(region: str) -> str:
        return f"https://tos-{region}.volces.com"

    @staticmethod
    def _parse_tos_uri(tos_uri: str) -> Tuple[str, str]:
        raw = str(tos_uri or "").strip()
        if not raw.startswith("tos://"):
            raise ValueError("Invalid TOS uri, expect tos://<bucket>/<prefix>")
        rest = raw[len("tos://") :]
        if "/" in rest:
            bucket, key = rest.split("/", 1)
        else:
            bucket, key = rest, ""
        return bucket, key.strip("/")

    def _get_prefix(self) -> Tuple[str, str]:
        tos_prefix = str(self.credentials.tos_jar_prefix or "").strip()
        if not tos_prefix:
            raise Exception("TOS Jar Prefix 未配置，请先执行 volc_flink config set-tos-jar-prefix")
        return self._parse_tos_uri(tos_prefix)

    @staticmethod
    def _join_key(prefix: str, name: str) -> str:
        p = str(prefix or "").strip("/")
        n = str(name or "").lstrip("/")
        if not p:
            return n
        if not n:
            return p
        return f"{p}/{n}"

    @staticmethod
    def _fmt_dt(value: Any) -> str:
        if isinstance(value, datetime):
            return value.strftime("%Y-%m-%d %H:%M:%S")
        if value is None:
            return ""
        return str(value)

    def list(self, sub_prefix: str = "", limit: int = 200) -> List[TOSObject]:
        bucket, base_prefix = self._get_prefix()
        full_prefix = self._join_key(base_prefix, sub_prefix)
        full_prefix = full_prefix + "/" if full_prefix and not full_prefix.endswith("/") else full_prefix

        out: List[TOSObject] = []
        marker: Optional[str] = None
        max_keys = min(int(limit), 1000) if limit > 0 else 200

        while True:
            resp = self._client.list_objects(Bucket=bucket, Prefix=full_prefix, Marker=marker, MaxKeys=max_keys)
            objects = getattr(resp, "object_list", None)
            if not isinstance(objects, list):
                objects = getattr(resp, "contents", None)
            if not isinstance(objects, list):
                objects = getattr(resp, "Contents", None)
            if not isinstance(objects, list):
                objects = []

            for obj in objects:
                key = getattr(obj, "key", None) or getattr(obj, "Key", None) or ""
                size = getattr(obj, "size", None) or getattr(obj, "Size", None) or 0
                last_modified = getattr(obj, "last_modified", None) or getattr(obj, "LastModified", None) or ""
                etag = getattr(obj, "etag", None) or getattr(obj, "ETag", None) or ""
                out.append(
                    TOSObject(
                        key=str(key),
                        size=int(size) if str(size).isdigit() else int(size or 0),
                        last_modified=self._fmt_dt(last_modified),
                        etag=str(etag).strip('"'),
                    )
                )
                if limit > 0 and len(out) >= int(limit):
                    return out[: int(limit)]

            is_truncated = getattr(resp, "is_truncated", None)
            if is_truncated is None:
                is_truncated = getattr(resp, "IsTruncated", None)
            if is_truncated is None:
                is_truncated = getattr(resp, "truncated", None)
            if not is_truncated:
                return out

            marker2 = getattr(resp, "next_marker", None) or getattr(resp, "NextMarker", None)
            if marker2 is None:
                marker2 = getattr(resp, "next_marker_key", None) or getattr(resp, "NextMarkerKey", None)
            marker = str(marker2 or "").strip() or None
            if not marker:
                return out

    def head(self, name: str) -> Dict[str, Any]:
        bucket, base_prefix = self._get_prefix()
        key = self._join_key(base_prefix, name)
        resp = self._client.head_object(Bucket=bucket, Key=key)
        return {
            "bucket": bucket,
            "key": key,
            "tos_uri": f"tos://{bucket}/{key}",
            "etag": str(getattr(resp, "etag", "") or "").strip('"'),
            "content_length": int(getattr(resp, "content_length", 0) or 0),
            "content_type": str(getattr(resp, "content_type", "") or ""),
            "last_modified": self._fmt_dt(getattr(resp, "last_modified", "") or ""),
            "storage_class": str(getattr(resp, "storage_class", "") or ""),
            "meta": dict(getattr(resp, "meta", {}) or {}),
        }

    def upload(self, file_path: str, name: Optional[str] = None) -> Dict[str, Any]:
        bucket, base_prefix = self._get_prefix()
        p = Path(file_path).expanduser()
        if not p.exists() or not p.is_file():
            raise Exception(f"文件不存在: {p}")
        obj_name = str(name or p.name).lstrip("/")
        if not obj_name:
            raise Exception("name 不能为空")
        key = self._join_key(base_prefix, obj_name)
        with p.open("rb") as f:
            self._client.put_object(Bucket=bucket, Key=key, Body=f)
        return {"bucket": bucket, "key": key, "tos_uri": f"tos://{bucket}/{key}"}

    def url(self, name: str, expires_in: int = 3600) -> Dict[str, Any]:
        bucket, base_prefix = self._get_prefix()
        key = self._join_key(base_prefix, name)
        u = self._client.generate_presigned_url(Method="GET", Bucket=bucket, Key=key, ExpiresIn=int(expires_in))
        return {"bucket": bucket, "key": key, "tos_uri": f"tos://{bucket}/{key}", "url": str(u)}
