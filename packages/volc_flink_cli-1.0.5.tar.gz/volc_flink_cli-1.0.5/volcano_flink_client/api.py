"""
HTTP 请求基础模块 - 处理 API 调用
HTTP Base Module - Handles API calls
"""

import requests
import time
import hmac
import hashlib
import base64
import json
from urllib.parse import urlparse, urlencode
from typing import Optional, Dict, Any
from volcano_flink_client.auth.auth import Credentials
import volcenginesdkcore


class ApiClient:
    """API 请求客户端，负责发送 HTTP 请求并处理签名"""
    
    def __init__(self, credentials: Credentials):
        self.credentials = credentials
        self.session = requests.Session()
    
    def _generate_signature(self, method: str, url: str, timestamp: str, nonce: str, body: str) -> str:
        """
        生成火山引擎 API 请求签名
        
        Args:
            method: HTTP 方法
            url: 请求 URL
            timestamp: 时间戳
            nonce: 随机数
            body: 请求体
            
        Returns:
            签名字符串
        """
        parsed_url = urlparse(url)
        path = parsed_url.path
        
        # 构建签名字符串
        string_to_sign = (
            f"{method}\n"
            f"{path}\n"
            f"{timestamp}\n"
            f"{nonce}\n"
            f"{body}\n"
        )
        
        # 使用 HMAC-SHA256 签名
        signature = hmac.new(
            self.credentials.secret_key.encode('utf-8'),
            string_to_sign.encode('utf-8'),
            hashlib.sha256
        ).digest()
        
        return base64.b64encode(signature).decode('utf-8')
    
    def _get_headers(self, method: str, url: str, body: str) -> Dict[str, str]:
        """获取请求头"""
        timestamp = str(int(time.time()))
        nonce = str(int(time.time() * 1000))  # 使用时间戳作为随机数
        
        signature = self._generate_signature(method, url, timestamp, nonce, body)
        
        return {
            "Content-Type": "application/json",
            "X-Volc-Action": urlparse(url).path.split('/')[-1],
            "X-Volc-Date": timestamp,
            "X-Volc-Nonce": nonce,
            "X-Volc-Credential": f"{self.credentials.access_key}/{timestamp}",
            "X-Volc-Signature": signature,
            "X-Volc-Region": self.credentials.region,
        }
    
    def request(self, method: str, url: str, params: Optional[Dict] = None,
                data: Optional[Dict] = None) -> Dict[str, Any]:
        """
        发送 API 请求
        
        Args:
            method: HTTP 方法
            url: 请求 URL
            params: 查询参数
            data: 请求体数据
            
        Returns:
            响应数据
        """
        if params:
            url += "?" + urlencode(params)
        
        body_str = ""
        if data:
            body_str = requests.compat.json.dumps(data, ensure_ascii=False)
        
        headers = self._get_headers(method, url, body_str)
        
        try:
            if method.upper() == "GET":
                response = self.session.get(url, headers=headers, params=params, timeout=30)
            elif method.upper() == "POST":
                response = self.session.post(url, headers=headers, json=data, timeout=30)
            elif method.upper() == "PUT":
                response = self.session.put(url, headers=headers, json=data, timeout=30)
            elif method.upper() == "DELETE":
                response = self.session.delete(url, headers=headers, params=params, timeout=30)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")
            
            response.raise_for_status()
            return response.json()
        
        except requests.exceptions.HTTPError as e:
            print(f"HTTP Error: {e.response.status_code}")
            print(f"Error Response: {e.response.text}")
            raise
        except Exception as e:
            print(f"Request Error: {str(e)}")
            raise

    def openapi_invoke(
        self,
        action: str,
        version: str,
        service: str,
        method: str,
        query_params: Optional[list] = None,
        body: Optional[Dict[str, Any]] = None,
        host: str = "open.volcengineapi.com",
        headers: Optional[Dict[str, str]] = None,
        content_type: str = "application/json",
        accept: str = "application/json",
    ) -> Dict[str, Any]:
        configuration = volcenginesdkcore.Configuration()
        configuration.host = host
        configuration.ak = self.credentials.access_key
        configuration.sk = self.credentials.secret_key
        configuration.region = self.credentials.region
        configuration.client_side_validation = True

        client = volcenginesdkcore.ApiClient(configuration)
        header_params: Dict[str, str] = {}
        header_params["Accept"] = client.select_header_accept([accept])
        header_params["Content-Type"] = client.select_header_content_type([content_type])
        if headers:
            header_params.update(headers)

        true_path = f"/{action}/{version}/{service}/{method.lower()}/{content_type.lower().replace('/', '_')}"
        preload_content = "volcengine" in host

        response = client.call_api(
            true_path,
            method,
            {},
            query_params or [],
            header_params,
            body=body or {},
            post_params=[],
            files={},
            auth_settings=["volcengineSign"],
            async_req=False,
            response_type=object,
            _return_http_data_only=True,
            _preload_content=preload_content,
            _request_timeout=None,
            collection_formats={},
        )

        if not preload_content:
            try:
                response = json.loads(response.data)
            except ValueError:
                response = response.data

        return response
