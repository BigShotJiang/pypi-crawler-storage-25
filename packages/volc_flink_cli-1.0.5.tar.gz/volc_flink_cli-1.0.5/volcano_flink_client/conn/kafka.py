import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import dateutil.parser

try:
    from confluent_kafka import Consumer, KafkaException, TopicPartition
except ImportError:
    Consumer = None
    KafkaException = Exception
    TopicPartition = None

from volcano_flink_client.auth.auth import AuthManager


@dataclass
class KafkaEndpointConfig:
    name: str
    bootstrap_servers: str
    security_protocol: str = "PLAINTEXT"
    sasl_mechanism: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None


@dataclass
class KafkaInstanceConfig:
    name: str
    topic: Optional[str] = None
    group_id: Optional[str] = None
    default_endpoint: Optional[str] = None
    endpoints: List[KafkaEndpointConfig] = field(default_factory=list)


@dataclass
class KafkaConnectionConfig:
    instances: List[KafkaInstanceConfig] = field(default_factory=list)


class KafkaConnectionManager:
    def __init__(self, config_dir: Optional[str] = None):
        auth_manager = AuthManager(config_dir=config_dir)
        self.config_dir = Path(auth_manager.get_config_dir()).expanduser()
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.config_file = self.config_dir / "kafka_connection.json"

    def _normalize_optional(self, value: Optional[str]) -> Optional[str]:
        if value is None:
            return None
        text = str(value).strip()
        return text or None

    def _endpoint_from_dict(self, data: Dict[str, Any], default_name: str = "default") -> KafkaEndpointConfig:
        return KafkaEndpointConfig(
            name=str(data.get("name") or default_name),
            bootstrap_servers=str(data.get("bootstrap_servers") or data.get("bootstrap.servers") or ""),
            security_protocol=str(data.get("security_protocol") or "PLAINTEXT"),
            sasl_mechanism=self._normalize_optional(data.get("sasl_mechanism")),
            username=self._normalize_optional(data.get("username")),
            password=self._normalize_optional(data.get("password")),
        )

    def _instance_from_dict(self, data: Dict[str, Any], default_name: str = "default") -> KafkaInstanceConfig:
        raw_endpoints = data.get("endpoints") or []
        endpoints = [
            self._endpoint_from_dict(item, default_name=f"endpoint-{index + 1}")
            for index, item in enumerate(raw_endpoints)
            if isinstance(item, dict)
        ]
        return KafkaInstanceConfig(
            name=str(data.get("name") or default_name),
            topic=self._normalize_optional(data.get("topic")),
            group_id=self._normalize_optional(data.get("group_id")),
            default_endpoint=self._normalize_optional(data.get("default_endpoint")),
            endpoints=endpoints,
        )

    def _legacy_to_config(self, data: Dict[str, Any]) -> KafkaConnectionConfig:
        endpoint = self._endpoint_from_dict(
            {
                "name": "default",
                "bootstrap_servers": data.get("bootstrap_servers"),
                "security_protocol": data.get("security_protocol") or "PLAINTEXT",
                "sasl_mechanism": data.get("sasl_mechanism"),
                "username": data.get("username"),
                "password": data.get("password"),
            }
        )
        instance = KafkaInstanceConfig(
            name="default",
            topic=self._normalize_optional(data.get("topic")),
            group_id=self._normalize_optional(data.get("group_id")),
            default_endpoint="default",
            endpoints=[endpoint],
        )
        return KafkaConnectionConfig(instances=[instance])

    def save_config(self, config: KafkaConnectionConfig) -> KafkaConnectionConfig:
        with open(self.config_file, "w", encoding="utf-8") as f:
            json.dump(asdict(config), f, ensure_ascii=False, indent=2)
        return config

    def load_config(self) -> Optional[KafkaConnectionConfig]:
        if not self.config_file.exists():
            return None
        with open(self.config_file, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return KafkaConnectionConfig()
        if isinstance(data.get("instances"), list):
            instances = [
                self._instance_from_dict(item, default_name=f"instance-{index + 1}")
                for index, item in enumerate(data.get("instances") or [])
                if isinstance(item, dict)
            ]
            return KafkaConnectionConfig(instances=instances)
        if data.get("bootstrap_servers"):
            return self._legacy_to_config(data)
        return KafkaConnectionConfig()

    def save_instance(self, instance: KafkaInstanceConfig) -> KafkaInstanceConfig:
        config = self.load_config() or KafkaConnectionConfig()
        remaining = [item for item in config.instances if item.name != instance.name]
        remaining.append(instance)
        config.instances = sorted(remaining, key=lambda item: item.name)
        self.save_config(config)
        return instance

    def get_instance(self, instance_name: Optional[str] = None) -> Optional[KafkaInstanceConfig]:
        config = self.load_config()
        if not config or not config.instances:
            return None
        if instance_name:
            target_name = str(instance_name).strip()
            for item in config.instances:
                if item.name == target_name:
                    return item
            return None
        if len(config.instances) == 1:
            return config.instances[0]
        return None

    def clear_config(self, instance_name: Optional[str] = None) -> bool:
        if not self.config_file.exists():
            return True
        if not instance_name:
            self.config_file.unlink()
            return True
        config = self.load_config() or KafkaConnectionConfig()
        config.instances = [item for item in config.instances if item.name != str(instance_name).strip()]
        if config.instances:
            self.save_config(config)
        else:
            if self.config_file.exists():
                self.config_file.unlink()
        return True

    def resolve_instance_endpoint(
        self,
        instance_name: Optional[str] = None,
        endpoint_name: Optional[str] = None,
    ) -> Tuple[KafkaInstanceConfig, KafkaEndpointConfig]:
        config = self.load_config()
        if not config or not config.instances:
            raise ValueError("未找到 Kafka 配置信息，请先执行 `volc_flink conn kafka instance add` 与 `volc_flink conn kafka endpoint add`")

        target_instance = self.get_instance(instance_name=instance_name)
        if target_instance is None:
            available_names = ", ".join(item.name for item in config.instances)
            if instance_name:
                raise ValueError(f"未找到 Kafka instance `{instance_name}`，可选值: {available_names}")
            raise ValueError(f"存在多个 Kafka instance，请通过 `--instance` 指定，当前可选: {available_names}")
        if not target_instance.endpoints:
            raise ValueError(f"Kafka instance `{target_instance.name}` 未配置 endpoint，请执行 `volc_flink conn kafka endpoint add --instance {target_instance.name}`")

        target_endpoint_name = self._normalize_optional(endpoint_name) or target_instance.default_endpoint
        if target_endpoint_name:
            for item in target_instance.endpoints:
                if item.name == target_endpoint_name:
                    return target_instance, item
            available_endpoint_names = ", ".join(item.name for item in target_instance.endpoints)
            raise ValueError(
                f"Kafka instance `{target_instance.name}` 未找到 endpoint `{target_endpoint_name}`，可选值: {available_endpoint_names}"
            )
        return target_instance, target_instance.endpoints[0]

    def _parse_timestamp_ms(self, value: str) -> int:
        text = str(value).strip()
        if text.isdigit():
            raw = int(text)
            if raw < 20000000000:
                return raw * 1000
            return raw
        dt = dateutil.parser.parse(text)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return int(dt.timestamp() * 1000)

    def _decode_bytes(self, value: Optional[bytes]) -> str:
        if value is None:
            return ""
        try:
            return value.decode("utf-8")
        except UnicodeDecodeError:
            return value.hex()

    def _probe_bootstrap_hosts(self, bootstrap_servers: str) -> List[Dict[str, Any]]:
        probes: List[Dict[str, Any]] = []
        for entry in str(bootstrap_servers or "").split(","):
            entry = entry.strip()
            if not entry:
                continue
            host = entry.rsplit(":", 1)[0] if ":" in entry else entry
            try:
                addrinfo = __import__("socket").getaddrinfo(host, None)
                probes.append(
                    {
                        "entry": entry,
                        "host": host,
                        "ok": True,
                        "addr_count": len(addrinfo),
                        "sample": addrinfo[0][4][0] if addrinfo else None,
                    }
                )
            except Exception as e:
                probes.append({"entry": entry, "host": host, "ok": False, "error": str(e)})
        return probes

    def _probe_bootstrap_connectivity(self, bootstrap_servers: str) -> List[Dict[str, Any]]:
        probes: List[Dict[str, Any]] = []
        for entry in str(bootstrap_servers or "").split(","):
            entry = entry.strip()
            if not entry:
                continue
            host = entry
            port = None
            if ":" in entry:
                host, port_text = entry.rsplit(":", 1)
                try:
                    port = int(port_text)
                except ValueError:
                    port = None
            if port is None:
                probes.append({"entry": entry, "host": host, "ok": False, "error": "invalid port"})
                continue
            try:
                sock = __import__("socket").create_connection((host, port), timeout=3)
                sock.close()
                probes.append({"entry": entry, "host": host, "port": port, "ok": True})
            except Exception as e:
                probes.append({"entry": entry, "host": host, "port": port, "ok": False, "error": str(e)})
        return probes

    def _list_topic_partitions(self, consumer: Any, topic: str, timeout: float) -> List[int]:
        metadata = consumer.list_topics(topic=topic, timeout=timeout)
        topic_metadata = getattr(metadata, "topics", {}).get(topic)
        if topic_metadata is None:
            raise ValueError(f"未找到 Topic `{topic}`")
        partitions = sorted(int(partition_id) for partition_id in getattr(topic_metadata, "partitions", {}).keys())
        if not partitions:
            raise ValueError(f"Topic `{topic}` 没有可消费的 partition")
        return partitions

    def consume_messages(
        self,
        partition: Optional[int],
        start_time: str,
        end_time: Optional[str] = None,
        limit: int = 10,
        instance_name: Optional[str] = None,
        endpoint_name: Optional[str] = None,
        topic: Optional[str] = None,
        group_id: Optional[str] = None,
        poll_timeout: float = 1.0,
        max_idle_polls: int = 3,
        offsets_timeout: float = 10.0,
    ) -> List[Dict[str, Any]]:
        if Consumer is None or TopicPartition is None:
            raise ImportError("未安装 confluent-kafka，请先执行 `pip install confluent-kafka`（Python 3.12 需 >=2.3.0）")

        instance, endpoint = self.resolve_instance_endpoint(instance_name=instance_name, endpoint_name=endpoint_name)

        effective_topic = str(topic or instance.topic or "").strip()
        effective_group_id = str(group_id or instance.group_id or "").strip()
        if not effective_topic:
            raise ValueError("未配置 topic，请在 `conn kafka instance add` 时保存 instance 默认 topic 或通过 `--topic` 指定")
        if not effective_group_id:
            raise ValueError("未配置 group-id，请在 `conn kafka instance add` 时保存 instance 默认 group-id 或通过 `--group-id` 指定")

        consumer_config: Dict[str, Any] = {
            "bootstrap.servers": endpoint.bootstrap_servers,
            "group.id": effective_group_id,
            "enable.auto.commit": False,
            "auto.offset.reset": "earliest",
            "security.protocol": endpoint.security_protocol,
        }
        if endpoint.security_protocol.upper().startswith("SASL"):
            if endpoint.sasl_mechanism:
                consumer_config["sasl.mechanism"] = endpoint.sasl_mechanism
            if endpoint.username is not None:
                consumer_config["sasl.username"] = endpoint.username
            if endpoint.password is not None:
                consumer_config["sasl.password"] = endpoint.password
        dns_probes = self._probe_bootstrap_hosts(endpoint.bootstrap_servers)
        failed_hosts = [item for item in dns_probes if not item.get("ok")]
        if failed_hosts:
            first_failed = failed_hosts[0]
            raise ValueError(
                f"Kafka endpoint `{endpoint.name}` 的 bootstrap host `{first_failed.get('host')}` 当前无法解析：{first_failed.get('error')}。"
                f"如果这是私网/VPC endpoint，请在对应网络环境中执行，或改用可解析的公网 endpoint。"
            )
        connectivity_probes = self._probe_bootstrap_connectivity(endpoint.bootstrap_servers)

        consumer = Consumer(consumer_config)
        try:
            start_ms = self._parse_timestamp_ms(start_time)
            end_ms = self._parse_timestamp_ms(end_time) if end_time else int(datetime.now(timezone.utc).timestamp() * 1000)
            target_partitions = [int(partition)] if partition is not None else self._list_topic_partitions(
                consumer,
                effective_topic,
                timeout=min(offsets_timeout, 5.0),
            )
            offsets = consumer.offsets_for_times(
                [TopicPartition(effective_topic, partition_id, start_ms) for partition_id in target_partitions],
                timeout=offsets_timeout,
            )
            if not offsets:
                return []

            assigned_partitions: List[Any] = []
            active_partitions = set()
            for start_offset in offsets:
                if start_offset.offset is None or start_offset.offset < 0:
                    continue
                assigned_partitions.append(TopicPartition(effective_topic, start_offset.partition, start_offset.offset))
                active_partitions.add((effective_topic, start_offset.partition))

            if not assigned_partitions:
                return []
            consumer.assign(assigned_partitions)

            items: List[Dict[str, Any]] = []
            idle_polls = 0
            while len(items) < max(limit, 1) and active_partitions:
                msg = consumer.poll(poll_timeout)
                if msg is None:
                    idle_polls += 1
                    if idle_polls >= max_idle_polls:
                        break
                    continue
                idle_polls = 0
                if msg.error():
                    raise KafkaException(msg.error())

                partition_key = (msg.topic(), msg.partition())
                if partition_key not in active_partitions:
                    continue
                timestamp_type, timestamp_ms = msg.timestamp()
                if timestamp_ms is not None and timestamp_ms >= 0 and timestamp_ms > end_ms:
                    active_partitions.discard(partition_key)
                    consumer.pause([TopicPartition(msg.topic(), msg.partition())])
                    continue
                if timestamp_ms is not None and timestamp_ms >= 0 and timestamp_ms < start_ms:
                    continue

                items.append(
                    {
                        "topic": msg.topic(),
                        "partition": msg.partition(),
                        "offset": msg.offset(),
                        "timestamp_type": timestamp_type,
                        "timestamp_ms": timestamp_ms if timestamp_ms is not None and timestamp_ms >= 0 else None,
                        "key": self._decode_bytes(msg.key()),
                        "value": self._decode_bytes(msg.value()),
                    }
                )
            return sorted(
                items,
                key=lambda item: (
                    item.get("timestamp_ms") is None,
                    item.get("timestamp_ms") or 0,
                    item.get("partition") or 0,
                    item.get("offset") or 0,
                ),
            )[:max(limit, 1)]
        except Exception as e:
            if any(item.get("ok") for item in connectivity_probes):
                raise ValueError(
                    f"Kafka endpoint `{endpoint.name}` 的 bootstrap 地址可以连通，但 Kafka 元数据/offset 获取失败。"
                    f"当前配置为 security_protocol={endpoint.security_protocol}, sasl_mechanism={endpoint.sasl_mechanism or '-'}, "
                    f"username={'已设置' if endpoint.username else '未设置'}, password={'已设置' if endpoint.password else '未设置'}。"
                    f"这通常意味着 endpoint 的协议类型或认证信息与 broker 实际要求不一致。"
                ) from e
            raise
        finally:
            consumer.close()
