from typing import Any, Dict, List, Optional

from volcano_flink_client.api import ApiClient


class CatalogManager:
    def __init__(self, api_client: ApiClient, project_id: str):
        self.api_client = api_client
        self.project_id = str(project_id)
        self.service = "flink"
        self.version = "2021-06-01"

    def list_catalogs(self, region: str) -> List[Dict[str, Any]]:
        resp = self.api_client.openapi_invoke(
            action="ListCatalog",
            version=self.version,
            service=self.service,
            method="GET",
            query_params=[("ProjectId", self.project_id)],
            body={},
            headers={"X-Volc-Region": str(region)},
        )
        return self._pick_list(resp, keys=["Catalogs", "List", "Items", "Records", "Result"])

    def list_catalog_databases(self, region: str, catalog_id: str) -> List[Dict[str, Any]]:
        resp = self.api_client.openapi_invoke(
            action="ListCatalogDatabase",
            version=self.version,
            service=self.service,
            method="GET",
            query_params=[("ProjectId", self.project_id), ("CatalogId", str(catalog_id))],
            body={},
            headers={"X-Volc-Region": str(region)},
        )
        return self._pick_list(resp, keys=["Databases", "DatabaseList", "List", "Items", "Records", "Result"])

    def get_catalog_database(self, region: str, catalog_id: str, database_name: str) -> Dict[str, Any]:
        resp = self.api_client.openapi_invoke(
            action="GetCatalogDatabase",
            version=self.version,
            service=self.service,
            method="GET",
            query_params=[
                ("ProjectId", self.project_id),
                ("CatalogId", str(catalog_id)),
                ("DatabaseName", str(database_name)),
            ],
            body={},
            headers={"X-Volc-Region": str(region)},
        )
        return self._pick_obj(resp)

    def list_catalog_tables(self, region: str, catalog_id: str, database_name: str) -> List[Dict[str, Any]]:
        resp = self.api_client.openapi_invoke(
            action="ListCatalogTable",
            version=self.version,
            service=self.service,
            method="GET",
            query_params=[
                ("ProjectId", self.project_id),
                ("CatalogId", str(catalog_id)),
                ("DatabaseName", str(database_name)),
            ],
            body={},
            headers={"X-Volc-Region": str(region)},
        )
        return self._pick_list(resp, keys=["Tables", "TableList", "List", "Items", "Records", "Result"])

    def get_catalog_table(self, region: str, catalog_id: str, database_name: str, table_name: str) -> Dict[str, Any]:
        resp = self.api_client.openapi_invoke(
            action="GetCatalogTable",
            version=self.version,
            service=self.service,
            method="GET",
            query_params=[
                ("ProjectId", self.project_id),
                ("CatalogId", str(catalog_id)),
                ("DatabaseName", str(database_name)),
                ("TableName", str(table_name)),
            ],
            body={},
            headers={"X-Volc-Region": str(region)},
        )
        return self._pick_obj(resp)

    def _pick_obj(self, resp: Any) -> Dict[str, Any]:
        if isinstance(resp, dict):
            err = (resp.get("ResponseMetadata") or {}).get("Error")
            if isinstance(err, dict) and err.get("Code"):
                raise Exception(f"{err.get('Code')}: {err.get('Message')}")
            for k in ("Result", "Database", "Table", "Data"):
                v = resp.get(k)
                if isinstance(v, dict):
                    return v
            return resp
        raise Exception(f"Unexpected response: {resp}")

    def _pick_list(self, resp: Any, *, keys: List[str]) -> List[Dict[str, Any]]:
        if isinstance(resp, dict):
            err = (resp.get("ResponseMetadata") or {}).get("Error")
            if isinstance(err, dict) and err.get("Code"):
                raise Exception(f"{err.get('Code')}: {err.get('Message')}")
            candidates = [resp]
            result = resp.get("Result")
            if isinstance(result, dict):
                candidates.append(result)
            for obj in candidates:
                for k in keys:
                    v = obj.get(k)
                    if isinstance(v, list):
                        return [x for x in v if isinstance(x, dict)]
            for obj in candidates:
                if isinstance(obj.get("Records"), list):
                    return [x for x in obj.get("Records") if isinstance(x, dict)]
            return []
        if isinstance(resp, list):
            return [x for x in resp if isinstance(x, dict)]
        raise Exception(f"Unexpected response: {resp}")
