"""
项目模块 - 处理项目相关操作
Projects Module - Handles project-related operations
"""

from typing import List, Optional, Dict, Any
from dataclasses import dataclass
from volcano_flink_client.api import ApiClient


@dataclass
class Project:
    """项目信息类"""
    id: str
    name: str
    description: str
    status: str
    create_time: str
    update_time: str
    owner: Optional[str] = None
    tags: Optional[Dict[str, str]] = None


class ProjectManager:
    """项目管理类，支持列举项目和查看项目详情"""
    
    def __init__(self, api_client: ApiClient):
        self.api_client = api_client
        self.service = "flink"
        self.version = "2021-06-01"
    
    def list_projects(self, page: int = 1, page_size: int = 10, status: Optional[str] = None,
                      search: Optional[str] = None) -> List[Project]:
        """
        列举项目
        
        Args:
            page: 页码
            page_size: 每页大小
            status: 项目状态筛选
            search: 搜索关键词
            
        Returns:
            项目列表
        """
        query_params = [
            ("SearchKey", search or ""),
            ("PageSize", page_size),
            ("PageNum", page),
        ]
        response = self.api_client.openapi_invoke(
            action="ListGMSProject",
            version=self.version,
            service=self.service,
            method="GET",
            query_params=query_params,
        )
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")

        if isinstance(response, dict) and isinstance(response.get("Result"), dict):
            result = response["Result"]
        else:
            result = response if isinstance(response, dict) else {}

        raw_list = (
            result.get("Projects")
            or result.get("ProjectList")
            or result.get("Items")
            or result.get("List")
            or []
        )

        projects: List[Project] = []
        if isinstance(raw_list, list):
            for item in raw_list:
                if not isinstance(item, dict):
                    continue
                project_id = (
                    item.get("ProjectId")
                    or item.get("ID")
                    or item.get("Id")
                    or item.get("project_id")
                )
                project_name = (
                    item.get("ProjectName")
                    or item.get("Name")
                    or item.get("name")
                    or project_id
                )
                projects.append(Project(
                    id=str(project_id or project_name or ""),
                    name=str(project_name or ""),
                    description=str(item.get("Description") or item.get("description") or ""),
                    status=str(item.get("Status") or item.get("status") or ""),
                    create_time=str(item.get("CreateTime") or item.get("CreatDate") or item.get("create_time") or ""),
                    update_time=str(item.get("UpdateTime") or item.get("update_time") or ""),
                    owner=item.get("OwnerName") or item.get("Owner") or item.get("owner"),
                    tags=item.get("Tags") or item.get("tags"),
                ))

        if status:
            projects = [p for p in projects if p.status == status]

        return projects
    
    def get_project_details(self, project_name: str) -> Project:
        """
        获取项目详情
        
        Args:
            project_name: 项目名称
            
        Returns:
            项目详情对象
        """
        response = self.api_client.openapi_invoke(
            action="GetGMSProjectDetail",
            version=self.version,
            service=self.service,
            method="GET",
            query_params=[("ProjectName", project_name)],
        )
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")

        if isinstance(response, dict) and isinstance(response.get("Result"), dict):
            result = response["Result"]
        else:
            result = response if isinstance(response, dict) else None
        if not isinstance(result, dict):
            raise Exception(f"Failed to get project details: {response}")

        project_id = result.get("ProjectId") or result.get("ID") or result.get("Id") or result.get("project_id")
        name = result.get("ProjectName") or result.get("Name") or result.get("name") or project_name
        return Project(
            id=str(project_id or name or ""),
            name=str(name or ""),
            description=str(result.get("Description") or result.get("description") or ""),
            status=str(result.get("Status") or result.get("status") or ""),
            create_time=str(result.get("CreateTime") or result.get("CreatDate") or result.get("create_time") or ""),
            update_time=str(result.get("UpdateTime") or result.get("update_time") or ""),
            owner=result.get("OwnerName") or result.get("Owner") or result.get("owner"),
            tags=result.get("Tags") or result.get("tags"),
        )
    
    def get_project_tags(self, project_id: str) -> Dict[str, str]:
        """
        获取项目标签
        
        Args:
            project_id: 项目 ID
            
        Returns:
            标签字典
        """
        raise NotImplementedError("Project tags API is not implemented for OpenAPI mode")
