from typing import Any, Dict, List, Optional

from volcano_flink_client.api import ApiClient


class SessionClusterManager:
    def __init__(self, api_client: ApiClient, project_id: str):
        self.api_client = api_client
        self.project_id = str(project_id)
        self.service = "flink"
        self.version = "2021-06-01"

    def list_clusters(self) -> List[Dict[str, Any]]:
        resp = self.api_client.openapi_invoke(
            action="ListGWSSessionCluster",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[("ProjectId", self.project_id)],
            body={},
        )
        return self._pick_list(resp, keys=["Records", "Clusters", "Items", "List", "Result"])

    def create_cluster(self, spec: Dict[str, Any]) -> Dict[str, Any]:
        body: Dict[str, Any] = dict(spec or {})
        body.setdefault("ProjectId", self.project_id)
        resp = self.api_client.openapi_invoke(
            action="CreateGWSSessionCluster",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[("ProjectId", self.project_id)],
            body=body,
        )
        return self._pick_obj(resp)

    def start_cluster(self, cluster_id: str) -> Dict[str, Any]:
        resp = self.api_client.openapi_invoke(
            action="StartGWSSessionCluster",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[("ProjectId", self.project_id)],
            body={"Id": str(cluster_id)},
        )
        return self._pick_obj(resp)

    def stop_cluster(self, cluster_id: str) -> Dict[str, Any]:
        resp = self.api_client.openapi_invoke(
            action="StopGWSSessionCluster",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[("ProjectId", self.project_id)],
            body={"Id": str(cluster_id)},
        )
        return self._pick_obj(resp)

    def get_user_token(self, token_valid_seconds: int = 10800) -> str:
        def call(method: str) -> Any:
            return self.api_client.openapi_invoke(
                action="GetGMSUserToken",
                version=self.version,
                service=self.service,
                method=method,
                query_params=[("TokenValidSeconds", int(token_valid_seconds))],
                body={},
            )

        try:
            resp = call("POST")
        except Exception as e:
            if "POST" in str(e) and "not supported" in str(e).lower():
                resp = call("GET")
            else:
                raise
        obj = self._pick_obj(resp)
        for k in ("Token", "UserToken", "Data", "Result"):
            v = obj.get(k) if isinstance(obj, dict) else None
            if v is not None and str(v).strip():
                return str(v).strip()
        raise Exception(f"未获取到 token: {resp}")

    def get_gateway_service(
        self,
        cluster_id: str,
        account_id: str,
        service: str = "LOGIN",
        type_: str = "",
    ) -> Dict[str, Any]:
        def call(method: str) -> Any:
            return self.api_client.openapi_invoke(
                action="GetGatewayService",
                version=self.version,
                service=self.service,
                method=method,
                query_params=[
                    ("Service", str(service)),
                    ("Type", str(type_)),
                    ("ClusterId", str(cluster_id)),
                    ("AccountId", str(account_id)),
                ],
                body={},
            )

        try:
            resp = call("POST")
        except Exception as e:
            if "POST" in str(e) and "not supported" in str(e).lower():
                resp = call("GET")
            else:
                raise
        return self._pick_obj(resp)

    @staticmethod
    def pick_gateway_endpoint(gw: Dict[str, Any]) -> str:
        if not isinstance(gw, dict):
            return ""
        for k in ("Endpoint", "endpoint", "Host", "Url", "Address"):
            v = gw.get(k)
            if v is not None and str(v).strip():
                return str(v).strip()
        result = gw.get("Result")
        if isinstance(result, dict):
            for k in ("Endpoint", "endpoint", "Host", "Url", "Address"):
                v = result.get(k)
                if v is not None and str(v).strip():
                    return str(v).strip()
        return ""

    def _pick_obj(self, resp: Any) -> Dict[str, Any]:
        if isinstance(resp, dict):
            err = (resp.get("ResponseMetadata") or {}).get("Error")
            if isinstance(err, dict) and err.get("Code"):
                raise Exception(f"{err.get('Code')}: {err.get('Message')}")
            result = resp.get("Result")
            if isinstance(result, dict):
                return result
            return resp
        raise Exception(f"Unexpected response: {resp}")

    def _pick_list(self, resp: Any, *, keys: List[str]) -> List[Dict[str, Any]]:
        if isinstance(resp, dict):
            err = (resp.get("ResponseMetadata") or {}).get("Error")
            if isinstance(err, dict) and err.get("Code"):
                raise Exception(f"{err.get('Code')}: {err.get('Message')}")
            candidates = [resp]
            result = resp.get("Result")
            if isinstance(result, dict):
                candidates.append(result)
            for obj in candidates:
                for k in keys:
                    v = obj.get(k)
                    if isinstance(v, list):
                        return [x for x in v if isinstance(x, dict)]
            return []
        if isinstance(resp, list):
            return [x for x in resp if isinstance(x, dict)]
        raise Exception(f"Unexpected response: {resp}")

    @staticmethod
    def pick_uri_path(cluster: Dict[str, Any]) -> str:
        if not isinstance(cluster, dict):
            return ""
        for k in ("UriPath", "FlinkUI", "FlinkUi", "FlinkUIUrl", "RestUrl", "CompleteRestUrl", "Url"):
            v = cluster.get(k)
            if v is not None and str(v).strip():
                return str(v).strip()
        return ""
