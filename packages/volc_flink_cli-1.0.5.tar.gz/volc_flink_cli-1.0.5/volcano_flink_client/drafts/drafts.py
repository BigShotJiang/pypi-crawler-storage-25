"""
草稿模块 - 处理任务草稿相关操作
Drafts Module - Handles task draft-related operations
"""

import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Dict, Any
from volcano_flink_client.api import ApiClient
import tos


@dataclass
class Draft:
    """任务草稿信息类"""
    id: str
    name: str
    type: str
    status: str
    description: str
    project_id: str
    create_time: str
    update_time: str
    resource_pool_id: Optional[str] = None
    tags: Optional[Dict[str, str]] = None


@dataclass
class DraftContent:
    """草稿内容类"""
    sql: Optional[str] = None
    jar_path: Optional[str] = None
    jar_uris: Optional[List[str]] = None
    main_class: Optional[str] = None
    arguments: Optional[List[str]] = None
    python_path: Optional[str] = None
    python_entry: Optional[str] = None
    cdc_config: Optional[Dict[str, Any]] = None
    dependencies: Optional[List[str]] = None


class DraftManager:
    """
    草稿管理类，支持：
    1. 检查任务目录
    2. 创建各种类型的任务草稿（SQL、JAR、CDC、Python）
    3. 删除草稿
    4. 编辑草稿
    5. 提交/发布草稿
    """
    
    def __init__(self, api_client: ApiClient, project_id: str):
        self.api_client = api_client
        self.project_id = project_id
        self.service = "flink"
        self.version = "2021-06-01"
    
    @dataclass
    class DraftDirectory:
        id: str
        name: str
        path: str
        directory_type: str
        create_time: str
        parent_id: Optional[str] = None

    @dataclass
    class DraftApplication:
        id: str
        name: str
        job_type: str
        modified_time: str
        directory_id: str
        directory_name: str
        directory_path: str
        app_id: Optional[str] = None
        is_deployed: Optional[bool] = None

    def list_draft_directories(self, type: str = "JOB") -> List["DraftManager.DraftDirectory"]:
        response = self.api_client.openapi_invoke(
            action="ListGWSDirectory",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[
                ("ProjectId", self.project_id),
                ("Type", type),
            ],
            body={},
        )

        directories: List[DraftManager.DraftDirectory] = []

        def _walk(items: Any, parent_id: Optional[str] = None, parent_path: str = ""):
            if not isinstance(items, list):
                return
            for item in items:
                if not isinstance(item, dict):
                    continue
                dir_id = item.get("Id") or item.get("ID") or item.get("id")
                name = item.get("Name") or item.get("name") or ""
                directory_type = item.get("DirectoryType") or item.get("Type") or ""
                create_time = item.get("CreateTime") or ""
                item_parent_id = item.get("ParentId") or item.get("ParentID") or item.get("parentId") or item.get("parentID")
                current_path = f"{parent_path}/{name}" if parent_path else f"/{name}"
                directories.append(DraftManager.DraftDirectory(
                    id=str(dir_id or ""),
                    name=str(name or ""),
                    path=str(current_path),
                    directory_type=str(directory_type or ""),
                    create_time=str(create_time or ""),
                    parent_id=str(parent_id) if parent_id else (str(item_parent_id) if item_parent_id else None),
                ))
                _walk(item.get("ChildDirectoryDtoList"), parent_id=dir_id, parent_path=current_path)

        _walk(response)
        return directories

    def ensure_directory_path(self, path: str, directory_type: str = "JOB") -> Dict[str, Any]:
        raw = str(path or "").strip()
        if not raw:
            raise ValueError("path is empty")
        parts = [p for p in raw.strip("/").split("/") if p]
        if not parts:
            raise ValueError("path is invalid")

        directories = self.list_draft_directories(type=str(directory_type or "JOB"))
        by_path: Dict[str, DraftManager.DraftDirectory] = {d.path: d for d in directories if d.path}
        root_parent_id = None
        for d in directories:
            if d.path and d.path.count("/") == 1 and d.parent_id:
                root_parent_id = d.parent_id
                break

        current_parent_id = root_parent_id or ""
        current_path = ""
        created_any = False

        for name in parts:
            current_path = f"{current_path}/{name}" if current_path else f"/{name}"
            hit = by_path.get(current_path)
            if hit:
                current_parent_id = hit.id
                continue

            resp = None
            attempts: List[Optional[str]] = [current_parent_id]
            if not current_parent_id:
                attempts = [None, "", "0"]
            last_err: Optional[Exception] = None
            for pid in attempts:
                try:
                    resp = self.create_directory(name=name, parent_id=pid, directory_type=str(directory_type or "JOB"))
                    break
                except Exception as e:
                    last_err = e
                    if "parent directory not exist" in str(e).lower():
                        continue
                    raise
            if resp is None and last_err is not None:
                if "parent directory not exist" in str(last_err).lower() and not current_parent_id:
                    top_level = sorted([d.path for d in directories if d.path and d.path.count("/") == 1])
                    raise Exception(f"无法创建顶层目录，请使用已有顶层目录作为前缀，例如：{', '.join(top_level[:10])}")
                raise last_err
            new_id = None
            if isinstance(resp, dict):
                for k in ("Id", "ID", "id", "DirectoryId", "DirId"):
                    v = resp.get(k)
                    if v is not None and str(v).strip():
                        new_id = str(v).strip()
                        break
            if not new_id:
                directories = self.list_draft_directories(type=str(directory_type or "JOB"))
                by_path = {d.path: d for d in directories if d.path}
                hit2 = by_path.get(current_path)
                if not hit2 or not hit2.id:
                    raise Exception(f"创建目录后仍未找到: {current_path}")
                new_id = hit2.id
            by_path[current_path] = DraftManager.DraftDirectory(
                id=str(new_id),
                name=str(name),
                path=str(current_path),
                directory_type=str(directory_type or "JOB"),
                create_time="",
                parent_id=str(current_parent_id),
            )
            current_parent_id = str(new_id)
            created_any = True

        return {"Path": "/" + "/".join(parts), "Id": current_parent_id, "Created": bool(created_any)}

    def create_directory(self, name: str, parent_id: Optional[str], directory_type: str = "JOB") -> Dict[str, Any]:
        body: Dict[str, Any] = {"Name": str(name), "DirectoryType": str(directory_type)}
        if parent_id is not None:
            body["ParentId"] = str(parent_id)
        resp = self.api_client.openapi_invoke(
            action="CreateGWSDirectory",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[("ProjectId", self.project_id)],
            body=body,
        )
        if isinstance(resp, dict):
            error = (resp.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")
        if not isinstance(resp, dict):
            raise Exception(f"Unexpected create directory response: {resp}")
        result = resp.get("Result") if isinstance(resp.get("Result"), dict) else None
        return result if isinstance(result, dict) else resp

    def delete_directory(self, directory_id: str) -> Dict[str, Any]:
        resp = self.api_client.openapi_invoke(
            action="DeleteGWSDirectory",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[("ProjectId", self.project_id)],
            body={"Id": str(directory_id)},
        )
        if resp is True:
            return {"Success": True}
        if isinstance(resp, dict):
            error = (resp.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")
        if not isinstance(resp, dict):
            raise Exception(f"Unexpected delete directory response: {resp}")
        result = resp.get("Result") if isinstance(resp.get("Result"), dict) else None
        return result if isinstance(result, dict) else resp

    def list_draft_applications(self, type: str = "JOB") -> List["DraftManager.DraftApplication"]:
        response = self.api_client.openapi_invoke(
            action="ListGWSDirectory",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[
                ("ProjectId", self.project_id),
                ("Type", type),
            ],
            body={},
        )

        apps: List[DraftManager.DraftApplication] = []

        def _walk(items: Any, parent_path: str = ""):
            if not isinstance(items, list):
                return
            for item in items:
                if not isinstance(item, dict):
                    continue
                directory_id = str(item.get("Id") or item.get("ID") or item.get("id") or "")
                directory_name = str(item.get("Name") or item.get("name") or "")
                directory_path = f"{parent_path}/{directory_name}" if parent_path else f"/{directory_name}"

                raw_apps = item.get("Applications")
                if isinstance(raw_apps, list):
                    for a in raw_apps:
                        if not isinstance(a, dict):
                            continue
                        apps.append(DraftManager.DraftApplication(
                            id=str(a.get("Id") or a.get("ID") or a.get("id") or ""),
                            name=str(a.get("Name") or a.get("name") or ""),
                            job_type=str(a.get("JobType") or ""),
                            modified_time=str(a.get("ModifiedTime") or ""),
                            directory_id=directory_id,
                            directory_name=directory_name,
                            directory_path=directory_path,
                            app_id=a.get("AppId"),
                            is_deployed=a.get("IsDeployed"),
                        ))

                _walk(item.get("ChildDirectoryDtoList"), parent_path=directory_path)

        _walk(response)
        return apps

    def resolve_draft_id(self, draft_ref: str, type: str = "JOB") -> str:
        raw = (draft_ref or "").strip()
        if not raw:
            raise ValueError("draft_ref is empty")

        apps = self.list_draft_applications(type=type)

        def _strip_ext(name: str) -> str:
            if name.lower().endswith(".sql"):
                return name[:-4]
            if name.lower().endswith(".jar"):
                return name[:-4]
            return name

        if "/" in raw:
            parts = [p for p in raw.strip("/").split("/") if p]
            if not parts:
                raise Exception("草稿路径不合法")
            draft_name = _strip_ext(parts[-1])
            directory_path = "/" + "/".join(parts[:-1]) if len(parts) > 1 else ""
            candidates = [a for a in apps if a.name == draft_name and a.directory_path == directory_path]
            if len(candidates) == 1:
                return candidates[0].id
            if len(candidates) > 1:
                raise Exception("草稿名称不唯一，请使用 --draft-id 指定草稿ID；可用 drafts apps 查询草稿ID")
            raise Exception("未找到草稿路径，请使用 drafts apps 查询草稿ID")

        draft_name = _strip_ext(raw)
        candidates = [a for a in apps if a.name == draft_name]
        if len(candidates) == 1:
            return candidates[0].id
        if len(candidates) > 1:
            raise Exception("草稿名称重名，请使用 /a/b/c/test.sql 指定目录路径；或用 --draft-id 指定草稿ID（可用 drafts apps 查询）")
        raise Exception("未找到草稿名称，请使用 drafts apps 查询草稿ID")

    def resolve_directory_id(self, directory: str, type: str = "JOB") -> str:
        raw = (directory or "").strip()
        if not raw:
            raise ValueError("directory is empty")

        directories = self.list_draft_directories(type=type)
        by_path = {d.path: d for d in directories if d.path}
        by_name: Dict[str, List[DraftManager.DraftDirectory]] = {}
        for d in directories:
            by_name.setdefault(d.name, []).append(d)

        if "/" in raw:
            path = "/" + "/".join([p for p in raw.strip("/").split("/") if p])
            hit = by_path.get(path)
            if hit:
                return hit.id
            raise Exception("未找到目录路径，请使用 drafts dirs 查看可用目录")

        hits = by_name.get(raw) or []
        if len(hits) == 1:
            return hits[0].id
        if len(hits) > 1:
            raise Exception("目录名称不唯一，请使用 /a/b/c 形式指定目录路径")
        raise Exception("未找到目录名称，请使用 drafts dirs 查看可用目录")
    
    def list_drafts(self, page: int = 1, page_size: int = 10, status: Optional[str] = None,
                  type_filter: Optional[str] = None) -> List[Draft]:
        """
        列举项目中的任务草稿
        
        Args:
            page: 页码
            page_size: 每页大小
            status: 状态筛选
            type_filter: 类型筛选
            
        Returns:
            草稿列表
        """
        raise NotImplementedError("Draft list API is not implemented for OpenAPI mode")
    
    def create_draft(self, name: str, task_type: str, description: str, content: DraftContent,
                    resource_pool_id: Optional[str] = None,
                    tags: Optional[Dict[str, str]] = None) -> Draft:
        """
        创建任务草稿
        
        Args:
            name: 任务名称
            task_type: 任务类型（sql、jar、cdc、python）
            description: 描述
            content: 任务内容
            resource_pool_id: 资源池 ID
            tags: 标签
            
        Returns:
            新创建的草稿对象
        """
        raise NotImplementedError("Draft create API is not implemented for OpenAPI mode")
    
    def _serialize_content(self, content: DraftContent, task_type: str) -> Dict[str, Any]:
        """根据任务类型序列化内容"""
        serialized = {}
        
        if task_type == "sql":
            if content.sql:
                serialized["sql"] = content.sql
        
        elif task_type == "jar":
            if content.jar_path:
                serialized["jar_path"] = content.jar_path
            if content.main_class:
                serialized["main_class"] = content.main_class
            if content.arguments:
                serialized["arguments"] = content.arguments
            if content.dependencies:
                serialized["dependencies"] = content.dependencies
        
        elif task_type == "python":
            if content.python_path:
                serialized["python_path"] = content.python_path
            if content.python_entry:
                serialized["python_entry"] = content.python_entry
            if content.arguments:
                serialized["arguments"] = content.arguments
            if content.dependencies:
                serialized["dependencies"] = content.dependencies
        
        elif task_type == "cdc":
            if content.cdc_config:
                serialized["cdc_config"] = content.cdc_config
        
        return serialized
    
    def get_draft(self, draft_id: str) -> Draft:
        """
        获取草稿详情
        
        Args:
            draft_id: 草稿 ID
            
        Returns:
            草稿对象
        """
        response = self.api_client.openapi_invoke(
            action="GetGWSApplicationDraft",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[("ProjectId", self.project_id)],
            body={"Id": draft_id},
        )
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")

        if not isinstance(response, dict):
            raise Exception(f"Failed to get draft: {response}")

        return Draft(
            id=str(response.get("Id") or ""),
            name=str(response.get("JobName") or ""),
            type=str(response.get("JobType") or ""),
            status=str(response.get("State") or ""),
            description="",
            project_id=str(response.get("ProjectId") or self.project_id),
            resource_pool_id=None,
            create_time=str(response.get("CreateTime") or ""),
            update_time=str(response.get("ModifiedTime") or ""),
            tags=None,
        )
    
    def get_draft_content(self, draft_id: str) -> DraftContent:
        """
        获取草稿内容
        
        Args:
            draft_id: 草稿 ID
            
        Returns:
            草稿内容对象
        """
        response = self.api_client.openapi_invoke(
            action="GetGWSApplicationDraft",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[("ProjectId", self.project_id)],
            body={"Id": draft_id},
        )
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")

        if not isinstance(response, dict):
            raise Exception(f"Failed to get draft content: {response}")

        jar_uris: List[str] = []
        dependency_raw = response.get("Dependency") or "{}"
        try:
            dependency = json.loads(dependency_raw) if isinstance(dependency_raw, str) else dependency_raw
        except Exception:
            dependency = {}
        if isinstance(dependency, dict):
            jars = dependency.get("jars")
            if isinstance(jars, list):
                jar_uris = [str(x) for x in jars if x is not None]

        sql_text = response.get("SqlText") or None
        return DraftContent(
            sql=sql_text,
            jar_uris=jar_uris or None,
        )

    def list_dependency_jars(self, draft_id: str) -> List[str]:
        response = self.api_client.openapi_invoke(
            action="GetGWSApplicationDraft",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[("ProjectId", self.project_id)],
            body={"Id": draft_id},
        )
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")

        if not isinstance(response, dict):
            raise Exception(f"Failed to get draft: {response}")

        dependency_raw = response.get("Dependency") or "{}"
        try:
            dependency = json.loads(dependency_raw) if isinstance(dependency_raw, str) else dependency_raw
        except Exception:
            dependency = {}
        if not isinstance(dependency, dict):
            dependency = {}
        jars = dependency.get("jars")
        if not isinstance(jars, list):
            return []
        out: List[str] = []
        for x in jars:
            if x is None:
                continue
            s = str(x)
            if s and s not in out:
                out.append(s)
        return out

    def get_dynamic_options(self, draft_id: str) -> Dict[str, str]:
        response = self.api_client.openapi_invoke(
            action="GetGWSApplicationDraft",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[("ProjectId", self.project_id)],
            body={"Id": draft_id},
        )
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")
        if not isinstance(response, dict):
            raise Exception(f"Failed to get draft: {response}")

        raw = response.get("DynamicOptions") or "{}"
        try:
            options = json.loads(raw) if isinstance(raw, str) else raw
        except Exception:
            options = {}
        if not isinstance(options, dict):
            options = {}
        out: Dict[str, str] = {}
        for k, v in options.items():
            if k is None:
                continue
            out[str(k)] = "" if v is None else str(v)
        return out

    def create_application_draft(
        self,
        job_name: str,
        directory_id: str,
        job_type: str,
        engine_version: str = "FLINK_VERSION_1_17",
    ) -> str:
        body: Dict[str, Any] = {
            "JobName": job_name,
            "EngineVersion": engine_version,
            "ProjectId": self.project_id,
            "DirectoryId": directory_id,
            "JobType": job_type,
        }
        response = self.api_client.openapi_invoke(
            action="CreateGWSApplicationDraft",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[("ProjectId", self.project_id)],
            body=body,
        )
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")

        if isinstance(response, dict):
            draft_id = response.get("Id") or response.get("DraftId")
            if draft_id:
                return str(draft_id)
            result = response.get("Result")
            if isinstance(result, dict):
                draft_id = result.get("Id") or result.get("DraftId")
                if draft_id:
                    return str(draft_id)
        raise Exception(f"Failed to create draft: {response}")

    def update_application_draft(
        self,
        draft_id: str,
        sql_text: Optional[str] = None,
        jar_uris: Optional[List[str]] = None,
        jar: Optional[str] = None,
        main_class: Optional[str] = None,
        args: Optional[str] = None,
        main_args: Optional[Dict[str, str]] = None,
        dynamic_options_updates: Optional[Dict[str, Optional[str]]] = None,
    ) -> Dict[str, Any]:
        existing = self.api_client.openapi_invoke(
            action="GetGWSApplicationDraft",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[("ProjectId", self.project_id)],
            body={"Id": draft_id},
        )
        if not isinstance(existing, dict):
            raise Exception(f"Failed to load draft for update: {existing}")

        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        dependency_raw = existing.get("Dependency") or "{}"
        try:
            dependency = json.loads(dependency_raw) if isinstance(dependency_raw, str) else dependency_raw
        except Exception:
            dependency = {}
        if not isinstance(dependency, dict):
            dependency = {}
        if jar:
            dependency["jars"] = [str(jar)]
        if jar_uris is not None:
            dependency["jars"] = jar_uris

        dynamic_options_raw = existing.get("DynamicOptions") or "{}"
        try:
            dynamic_options = json.loads(dynamic_options_raw) if isinstance(dynamic_options_raw, str) else dynamic_options_raw
        except Exception:
            dynamic_options = {}
        if not isinstance(dynamic_options, dict):
            dynamic_options = {}
        if isinstance(dynamic_options_updates, dict):
            for k, v in dynamic_options_updates.items():
                if not k:
                    continue
                if v is None:
                    dynamic_options.pop(k, None)
                else:
                    dynamic_options[str(k)] = str(v)

        body = {
            "Id": existing.get("Id"),
            "ProjectId": self.project_id,
            "AccountId": existing.get("AccountId"),
            "UserId": existing.get("UserId"),
            "Platform": existing.get("Platform") or "StreamX",
            "JobName": existing.get("JobName"),
            "JobId": existing.get("JobId") or "",
            "State": existing.get("State") or "CREATED",
            "Options": existing.get("Options") or "{}",
            "CreateTime": existing.get("CreateTime") or current_time,
            "ModifiedTime": current_time,
            "K8sNamespace": existing.get("K8sNamespace") or "",
            "EngineVersion": existing.get("EngineVersion") or "FLINK_VERSION_1_17",
            "DirectoryId": existing.get("DirectoryId"),
            "DirectoryName": existing.get("DirectoryName") or "",
            "SqlText": existing.get("SqlText") if sql_text is None else sql_text,
            "Dependency": json.dumps(dependency, ensure_ascii=False),
            "Sources": existing.get("Sources") or [],
            "Sinks": existing.get("Sinks") or [],
            "DataConnectionGroups": existing.get("DataConnectionGroups") or [],
            "EnableDeepValidate": existing.get("EnableDeepValidate") or False,
            "JobType": existing.get("JobType") or "",
            "DynamicOptions": json.dumps(dynamic_options, ensure_ascii=False),
        }

        job_type = str(existing.get("JobType") or "")
        if job_type.endswith("_JAR"):
            if jar is not None:
                body["Jar"] = str(jar)
            else:
                existing_jar = existing.get("Jar")
                if existing_jar is not None:
                    body["Jar"] = existing_jar

            if main_class is not None:
                body["MainClass"] = str(main_class)
            else:
                existing_main_class = existing.get("MainClass")
                if existing_main_class is not None:
                    body["MainClass"] = existing_main_class

            if args is not None:
                body["Args"] = str(args)
            else:
                existing_args = existing.get("Args")
                if existing_args is not None:
                    body["Args"] = existing_args

            if main_args is not None:
                body["MainArgs"] = {str(k): str(v) for k, v in dict(main_args).items()}
            else:
                existing_main_args = existing.get("MainArgs")
                if isinstance(existing_main_args, dict):
                    body["MainArgs"] = existing_main_args

        response = self.api_client.openapi_invoke(
            action="UpdateGWSApplicationDraft",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[("ProjectId", self.project_id)],
            body=body,
        )
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")
        return response

    def deploy_application_draft(
        self,
        draft_id: str,
        resource_pool: str,
        queue: str,
        priority: str = "3",
        schedule_policy: str = "GANG",
        schedule_timeout: int = 60,
    ) -> Dict[str, Any]:
        response = self.api_client.openapi_invoke(
            action="DeployGWSApplicationDraft",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[
                ("ProjectId", self.project_id),
                ("Id", draft_id),
            ],
            body={
                "ResourcePool": resource_pool,
                "Priority": str(priority),
                "SchedulePolicy": str(schedule_policy),
                "Queue": queue,
                "ScheduleTimeout": int(schedule_timeout),
            },
        )
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")
        return response

    def _parse_tos_uri(self, tos_uri: str) -> Dict[str, str]:
        if not tos_uri.startswith("tos://"):
            raise ValueError("Invalid tos uri")
        rest = tos_uri[len("tos://"):]
        if "/" in rest:
            bucket, key = rest.split("/", 1)
        else:
            bucket, key = rest, ""
        return {"bucket": bucket, "key": key}

    def upload_jar_if_needed(self, jar_path_or_tos: str) -> str:
        if jar_path_or_tos.startswith("tos://"):
            return jar_path_or_tos

        credentials = self.api_client.credentials
        if not credentials.tos_jar_prefix:
            raise Exception("TOS Jar 存储路径未配置，请先设置 tos_jar_prefix")

        jar_path = Path(jar_path_or_tos).expanduser()
        if not jar_path.exists() or not jar_path.is_file():
            raise Exception(f"JAR 文件不存在: {jar_path}")

        prefix = self._parse_tos_uri(credentials.tos_jar_prefix)
        bucket = prefix["bucket"]
        base_key = prefix["key"].strip("/")
        key = f"{base_key}/{jar_path.name}" if base_key else jar_path.name

        endpoint = f"https://tos-{credentials.region}.volces.com"
        auth = tos.Auth(credentials.access_key, credentials.secret_key, credentials.region)
        client = tos.TosClient(auth, endpoint)
        with jar_path.open("rb") as f:
            client.put_object(bucket, key, Body=f)
        return f"tos://{bucket}/{key}"
    
    def update_draft(self, draft_id: str, name: Optional[str] = None,
                   description: Optional[str] = None,
                   content: Optional[DraftContent] = None,
                   resource_pool_id: Optional[str] = None,
                   tags: Optional[Dict[str, str]] = None) -> Draft:
        """
        更新任务草稿
        
        Args:
            draft_id: 草稿 ID
            name: 新名称（可选）
            description: 新描述（可选）
            content: 新内容（可选）
            resource_pool_id: 新资源池 ID（可选）
            tags: 新标签（可选）
            
        Returns:
            更新后的草稿对象
        """
        if name is not None or description is not None or resource_pool_id is not None or tags is not None:
            raise NotImplementedError("Only content update is supported for OpenAPI mode")
        if not content:
            raise ValueError("content is required")

        sql_text: Optional[str] = None
        jar_uris: Optional[List[str]] = None

        if content.sql is not None:
            sql_text = content.sql

        if content.jar_uris is not None:
            jar_uris = content.jar_uris
        elif content.jar_path is not None:
            jar_uris = [self.upload_jar_if_needed(content.jar_path)]

        self.update_application_draft(draft_id=draft_id, sql_text=sql_text, jar_uris=jar_uris)
        return self.get_draft(draft_id)
    
    def delete_draft(self, draft_id: str) -> bool:
        """
        删除任务草稿
        
        Args:
            draft_id: 草稿 ID
            
        Returns:
            是否成功删除
        """
        response = self.api_client.openapi_invoke(
            action="DeleteGWSApplicationDraft",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[("ProjectId", self.project_id)],
            body={"Id": str(draft_id)},
        )
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")
        return True
    
    def publish_draft(
        self,
        draft_id: str,
        resource_pool: str,
        queue: str,
        priority: str = "3",
        schedule_policy: str = "GANG",
        schedule_timeout: int = 60,
    ) -> Dict[str, Any]:
        """
        提交/发布任务草稿
        
        Args:
            draft_id: 草稿 ID
            job_name: 任务名称（可选）
            
        Returns:
            任务 ID
        """
        return self.deploy_application_draft(
            draft_id=draft_id,
            resource_pool=resource_pool,
            queue=queue,
            priority=priority,
            schedule_policy=schedule_policy,
            schedule_timeout=schedule_timeout,
        )
    
    def validate_draft(self, draft_id: str) -> Dict[str, Any]:
        """
        验证任务草稿
        
        Args:
            draft_id: 草稿 ID
            
        Returns:
            验证结果
        """
        draft = self.get_draft(draft_id)
        content = self.get_draft_content(draft_id)
        sql_text = content.sql or ""
        response = self.api_client.openapi_invoke(
            action="ValidateGWSApplicationDraft",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[("ProjectId", self.project_id)],
            body={
                "Id": str(draft_id),
                "JobType": str(draft.type or ""),
                "SqlText": str(sql_text),
            },
        )
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")
        if not isinstance(response, dict):
            raise Exception(f"Unexpected validate response: {response}")
        return response
