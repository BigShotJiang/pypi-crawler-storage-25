"""
任务模块 - 处理 Flink 任务相关操作
Jobs Module - Handles Flink job-related operations
"""

from typing import List, Optional, Dict, Any
from dataclasses import dataclass
from volcano_flink_client.api import ApiClient
from urllib.parse import urlparse, urlunparse, urlencode, parse_qsl


@dataclass
class Job:
    """任务信息类"""
    id: str
    name: str
    type: str
    status: str
    project_id: str
    resource_pool_id: str
    create_time: str
    update_time: str
    draft_id: Optional[str] = None
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    tags: Optional[Dict[str, str]] = None


@dataclass
class JobMetrics:
    """任务指标类"""
    job_id: str
    vcores: float
    memory_gb: float
    cpu_usage: float
    memory_usage: float
    task_count: int
    checkpoint_count: int
    checkpoint_success_rate: float
    data_processed_mb: float
    latency_ms: float


@dataclass
class JobLogEntry:
    """任务日志条目类"""
    timestamp: str
    level: str
    source: str
    message: str
    thread_name: Optional[str] = None


class JobManager:
    """
    任务管理类，支持：
    1. 启动任务
    2. 列举任务
    3. 停止任务
    4. 重启任务
    5. 查看任务详情
    6. 查看任务日志
    7. 查看任务指标
    """
    
    def __init__(self, api_client: ApiClient, project_id: str):
        self.api_client = api_client
        self.project_id = project_id
        self.service = "flink"
        self.version = "2021-06-01"
    
    def list_jobs(self, page: int = 1, page_size: int = 10, status: Optional[str] = None,
                 type_filter: Optional[str] = None, search: Optional[str] = None) -> List[Job]:
        """
        列举项目中的任务
        
        Args:
            page: 页码
            page_size: 每页大小
            status: 状态筛选
            type_filter: 类型筛选
            search: 搜索关键词
            
        Returns:
            任务列表
        """
        response = self.api_client.openapi_invoke(
            action="ListGWSApplication",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[
                ("PageSize", int(page_size)),
                ("PageNum", int(page)),
                ("SortField", "DeployTime"),
                ("SortOrder", "desc"),
            ],
            body={
                "ProjectId": self.project_id,
                "JobName": search or "",
                "ResourcePool": "",
                "JobType": type_filter or "",
            },
        )

        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")

        items = []
        if isinstance(response, dict):
            items = response.get("Records") or response.get("Applications") or []

        jobs: List[Job] = []
        if isinstance(items, list):
            for item in items:
                if not isinstance(item, dict):
                    continue
                job = Job(
                    id=str(item.get("Id") or ""),
                    name=str(item.get("JobName") or ""),
                    type=str(item.get("JobType") or ""),
                    status=str(item.get("State") or ""),
                    project_id=str(item.get("ProjectId") or self.project_id),
                    resource_pool_id=str(item.get("Queue") or item.get("ResourcePool") or ""),
                    draft_id=str(item.get("AppDraftId") or "") or None,
                    create_time=str(item.get("CreateTime") or ""),
                    update_time=str(item.get("ModifiedTime") or ""),
                    start_time=item.get("StartTime"),
                    end_time=item.get("EndTime"),
                    tags=None,
                )
                jobs.append(job)

        if status:
            jobs = [j for j in jobs if j.status == status]
        if type_filter:
            jobs = [j for j in jobs if j.type == type_filter]

        return jobs
    
    def get_job_details(self, job_id: str) -> Job:
        """
        获取任务详情
        
        Args:
            job_id: 任务 ID
            
        Returns:
            任务对象
        """
        response = self.api_client.openapi_invoke(
            action="GetGWSApplication",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[],
            body={"Id": job_id, "AccountId": ""},
        )
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")
        if not isinstance(response, dict):
            raise Exception(f"Failed to get job details: {response}")

        return Job(
            id=str(response.get("Id") or ""),
            name=str(response.get("JobName") or ""),
            type=str(response.get("JobType") or ""),
            status=str(response.get("State") or ""),
            project_id=str(response.get("ProjectId") or self.project_id),
            resource_pool_id=str((response.get("DeployRequest") or {}).get("Queue") or ""),
            draft_id=str(response.get("AppDraftId") or "") or None,
            create_time=str(response.get("CreateTime") or ""),
            update_time=str(response.get("ModifiedTime") or ""),
            start_time=response.get("StartTime"),
            end_time=response.get("EndTime"),
            tags=None,
        )
    
    def start_job(self, job_id: str, start_type: str = "FROM_NEW", savepoint_id: Optional[str] = None) -> str:
        """
        启动任务
        
        Args:
            job_id: 任务 ID
            resource_pool_id: 资源池 ID（可选）
            
        Returns:
            执行结果
        """
        body: Dict[str, Any] = {
            "Id": job_id,
            "Type": str(start_type),
        }
        if savepoint_id:
            body["SavepointId"] = str(savepoint_id)

        response = self.api_client.openapi_invoke(
            action="StartGWSApplication",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[("ProjectId", self.project_id)],
            body=body,
        )
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")
        return "Job start request submitted"

    def get_job_overview(self, job_id: str) -> Dict[str, Any]:
        response = self.api_client.openapi_invoke(
            action="ListGWSApplication",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[
                ("PageSize", 1),
                ("PageNum", 1),
                ("SortField", "DeployTime"),
                ("SortOrder", "desc"),
            ],
            body={
                "ProjectId": self.project_id,
                "Id": str(job_id),
            },
        )
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")

        if not isinstance(response, dict):
            raise Exception(f"Failed to get job overview: {response}")

        records = response.get("Records") or response.get("Applications") or []
        if isinstance(records, list) and records:
            record = records[0]
            if isinstance(record, dict):
                return record
        raise Exception("Job overview not found")
    
    def stop_job(self, job_id: str, force: bool = False) -> str:
        """
        停止任务
        
        Args:
            job_id: 任务 ID
            force: 是否强制停止
            
        Returns:
            执行结果
        """
        response = self.api_client.openapi_invoke(
            action="CancelGWSApplication",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[("ProjectId", self.project_id)],
            body={
                "Id": job_id,
            },
        )
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")
        return "Job stop request submitted"

    def stop_job_with_savepoint(self, job_id: str) -> str:
        response = self.api_client.openapi_invoke(
            action="StopGWSApplicationWithSp",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[("ProjectId", self.project_id)],
            body={
                "Id": job_id,
            },
        )
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")

        if not isinstance(response, dict):
            raise Exception(f"Failed to stop job with savepoint: {response}")

        success = response.get("Success")
        if success is False:
            raise Exception("Stop job with savepoint failed")
        return "Job stop with savepoint request submitted"

    def list_start_savepoints(self, job_id: str) -> List[Dict[str, Any]]:
        response = self.api_client.openapi_invoke(
            action="GWSStartSavepointList",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[("ProjectId", self.project_id)],
            body={
                "Id": str(job_id),
                "ProjectId": self.project_id,
            },
        )
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")

        if not isinstance(response, dict):
            raise Exception(f"Failed to list savepoints: {response}")

        result = response.get("Result") if isinstance(response.get("Result"), dict) else response
        items = result.get("AvailableSavepoints") if isinstance(result, dict) else None
        if items is None:
            return []
        if not isinstance(items, list):
            raise Exception(f"Unexpected savepoints response: {response}")
        return [i for i in items if isinstance(i, dict)]

    def get_start_savepoint_info(self, job_id: str) -> Dict[str, Any]:
        response = self.api_client.openapi_invoke(
            action="GWSStartSavepointList",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[("ProjectId", self.project_id)],
            body={
                "Id": str(job_id),
                "ProjectId": self.project_id,
            },
        )
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")

        if not isinstance(response, dict):
            raise Exception(f"Failed to get start savepoint info: {response}")

        result = response.get("Result") if isinstance(response.get("Result"), dict) else response
        if not isinstance(result, dict):
            raise Exception(f"Unexpected start savepoint response: {response}")
        return result

    def make_savepoint(self, job_id: str, description: str) -> Dict[str, Any]:
        response = self.api_client.openapi_invoke(
            action="GWSMakeSavepoint",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[("ProjectId", self.project_id)],
            body={
                "Id": int(job_id) if str(job_id).isdigit() else str(job_id),
                "Description": str(description),
            },
        )
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")

        if not isinstance(response, dict):
            raise Exception(f"Failed to make savepoint: {response}")

        result = response.get("Result")
        if isinstance(result, dict):
            success = result.get("Success")
            if success is False:
                raise Exception("Make savepoint failed")
            return result

        success = response.get("Success")
        if success is False:
            raise Exception("Make savepoint failed")
        return response

    def list_savepoints(self, job_id: str, status: Optional[str] = None) -> List[Dict[str, Any]]:
        query_params = [("ProjectId", self.project_id)]
        if status:
            query_params.append(("Status", str(status)))
        response = self.api_client.openapi_invoke(
            action="GWSSavepointList",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=query_params,
            body={
                "Id": int(job_id) if str(job_id).isdigit() else str(job_id),
            },
        )
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")

        if isinstance(response, list):
            return [i for i in response if isinstance(i, dict)]

        if not isinstance(response, dict):
            raise Exception(f"Failed to list savepoints: {response}")

        items = response.get("Result")
        if items is None:
            return []
        if not isinstance(items, list):
            raise Exception(f"Unexpected list savepoints response: {response}")
        return [i for i in items if isinstance(i, dict)]
    
    def restart_job(self, job_id: str, start_type: str = "FROM_LATEST", savepoint_id: Optional[str] = None) -> str:
        """
        重启任务
        
        Args:
            job_id: 任务 ID
            resource_pool_id: 资源池 ID（可选）
            
        Returns:
            执行结果
        """
        body: Dict[str, Any] = {
            "Id": job_id,
            "Type": str(start_type),
        }
        if savepoint_id:
            body["SavepointId"] = str(savepoint_id)

        response = self.api_client.openapi_invoke(
            action="RestartGWSApplication",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[("ProjectId", self.project_id)],
            body=body,
        )
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")
        return "Job restart request submitted"

    def list_job_instances(
        self,
        job_id: str,
        state: Optional[str] = None,
        states: Optional[List[str]] = None,
        job_types: Optional[List[str]] = None,
        page: int = 1,
        page_size: int = 20,
        resource_pool: Optional[str] = None,
        job_name: Optional[str] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {
            "ProjectId": self.project_id,
            "JobId": int(job_id) if str(job_id).isdigit() else str(job_id),
            "State": str(state or ""),
            "ResourcePool": str(resource_pool or ""),
            "JobName": str(job_name or ""),
            "States": [str(s) for s in states] if isinstance(states, list) else None,
            "JobTypes": [str(s) for s in job_types] if isinstance(job_types, list) else None,
            "PageNum": int(page),
            "PageSize": int(page_size),
            "Current": int(page),
            "Size": int(page_size),
        }
        body = {k: v for k, v in body.items() if v is not None}

        response = self.api_client.openapi_invoke(
            action="ListApplicationInstance",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[("ProjectId", self.project_id)],
            body=body,
        )
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")
        if not isinstance(response, dict):
            raise Exception(f"Failed to list instances: {response}")
        return response

    def get_job_instance(self, instance_id: str) -> Dict[str, Any]:
        response = self.api_client.openapi_invoke(
            action="GetApplicationInstance",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[("ProjectId", self.project_id)],
            body={"InstanceId": str(instance_id)},
        )
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")
        if not isinstance(response, dict):
            raise Exception(f"Failed to get instance: {response}")
        result = response.get("Result") if isinstance(response.get("Result"), dict) else response
        if not isinstance(result, dict):
            raise Exception(f"Unexpected get instance response: {response}")
        return result

    def get_job_events(self, job_id: str, limit: int = 50) -> List[Dict[str, Any]]:
        body: Dict[str, Any] = {
            "Id": str(job_id),
            "Limit": int(limit),
        }
        response = self.api_client.openapi_invoke(
            action="GWSGetEventList",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[("ProjectId", self.project_id)],
            body=body,
        )
        if isinstance(response, list):
            return [x for x in response if isinstance(x, dict)]
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")
        if not isinstance(response, dict):
            raise Exception(f"Failed to get events: {response}")

        result = response.get("Result") if isinstance(response.get("Result"), dict) else response
        if not isinstance(result, dict):
            return []
        for k in ("Events", "EventList", "Data", "Items", "List"):
            v = result.get(k)
            if isinstance(v, list):
                return [x for x in v if isinstance(x, dict)]
        if isinstance(result.get("Records"), list):
            return [x for x in result.get("Records") if isinstance(x, dict)]
        return []

    def get_instance_flink_proxy_base_url(self, instance: Dict[str, Any]) -> Optional[str]:
        if not isinstance(instance, dict):
            return None
        url = instance.get("CompleteRestUrl") or instance.get("RestUrl")
        if not url:
            return None
        return str(url)

    def build_flink_proxy_url(self, base_url: str, path: str, query: Optional[Dict[str, str]] = None) -> str:
        parsed = urlparse(str(base_url))
        base_path = parsed.path.rstrip("/")
        path = "/" + str(path or "").lstrip("/")
        merged_path = base_path + path
        q = dict(parse_qsl(parsed.query, keep_blank_values=True))
        if query:
            for k, v in query.items():
                if k:
                    q[str(k)] = "" if v is None else str(v)
        return urlunparse(parsed._replace(path=merged_path, query=urlencode(q)))

    def list_gas_logs(
        self,
        instance_id: str,
        component: str = "jobmanager",
        level: Optional[str] = None,
        start_time_ms: Optional[int] = None,
        end_time_ms: Optional[int] = None,
        cursor: str = "",
        page_size: int = 500,
        file_name: str = "",
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {
            "Application": f"s-{str(instance_id)}",
            "Project": self.project_id,
            "IndexType": "JOB",
            "PageSize": int(page_size),
            "Cursor": str(cursor or ""),
            "Properties": {"component": str(component or "jobmanager"), "fileName": str(file_name or "")},
        }
        if level:
            body["Level"] = str(level).upper()
        if start_time_ms is not None:
            body["StartTime"] = int(start_time_ms)
        if end_time_ms is not None:
            body["EndTime"] = int(end_time_ms)

        response = self.api_client.openapi_invoke(
            action="ListGASLogs",
            version=self.version,
            service=self.service,
            method="POST",
            query_params=[],
            body=body,
        )
        if isinstance(response, dict):
            error = (response.get("ResponseMetadata") or {}).get("Error")
            if isinstance(error, dict) and error.get("Code"):
                raise Exception(f"{error.get('Code')}: {error.get('Message')}")

        result = response.get("Result") if isinstance(response, dict) else None
        if not isinstance(result, dict):
            result = response if isinstance(response, dict) else {}

        next_cursor = str(result.get("Cursor") or "")
        logs = result.get("Logs") or []
        messages: List[str] = []
        if isinstance(logs, list):
            for it in logs:
                if not isinstance(it, dict):
                    continue
                msg = it.get("Message")
                if msg is None:
                    continue
                messages.append(str(msg))

        return {"Cursor": next_cursor, "Messages": messages, "Raw": result}
    
    def get_job_logs(self, job_id: str, level: Optional[str] = None,
                     source: Optional[str] = None, start_time: Optional[str] = None,
                     end_time: Optional[str] = None, page: int = 1,
                     page_size: int = 50) -> List[JobLogEntry]:
        """
        获取任务日志
        
        Args:
            job_id: 任务 ID
            level: 日志级别筛选
            source: 日志来源筛选
            start_time: 开始时间
            end_time: 结束时间
            page: 页码
            page_size: 每页大小
            
        Returns:
            日志条目列表
        """
        raise NotImplementedError("Job logs API is not implemented for OpenAPI mode")
    
    def get_job_metrics(self, job_id: str, start_time: Optional[str] = None,
                      end_time: Optional[str] = None, interval: str = "1m") -> JobMetrics:
        """
        获取任务指标
        
        Args:
            job_id: 任务 ID
            start_time: 开始时间
            end_time: 结束时间
            interval: 时间间隔
            
        Returns:
            任务指标对象
        """
        raise NotImplementedError("Job metrics API is not implemented for OpenAPI mode")
    
    def get_job_checkpoints(self, job_id: str, page: int = 1,
                          page_size: int = 10) -> List[Dict[str, Any]]:
        """
        获取任务检查点信息
        
        Args:
            job_id: 任务 ID
            page: 页码
            page_size: 每页大小
            
        Returns:
            检查点列表
        """
        raise NotImplementedError("Job checkpoints API is not implemented for OpenAPI mode")
    
    def get_job_tasks(self, job_id: str, page: int = 1, page_size: int = 10) -> List[Dict[str, Any]]:
        """
        获取任务的任务（Task）信息
        
        Args:
            job_id: 任务 ID
            page: 页码
            page_size: 每页大小
            
        Returns:
            任务信息列表
        """
        raise NotImplementedError("Job tasks API is not implemented for OpenAPI mode")
