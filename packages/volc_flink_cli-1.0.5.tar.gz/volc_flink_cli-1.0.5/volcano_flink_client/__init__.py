"""
火山引擎流式计算 Flink 版 Client 工具
Volcano Engine Flink Stream Computing Client
"""

__version__ = "1.0.0"
__author__ = "Volcano Engine"
__description__ = "A Python client for Volcano Engine Flink Stream Computing"

from typing import Optional


class Config:
    """配置类，存储客户端全局配置"""
    
    def __init__(self):
        self.base_url = "https://open.volcengineapi.com"
        self.region = "cn-beijing"
        self.timeout = 30
        self.debug = False
    
    def set_region(self, region: str):
        self.region = region
    
    def set_timeout(self, timeout: int):
        self.timeout = timeout
    
    def set_debug(self, debug: bool):
        self.debug = debug


# 全局配置实例
global_config = Config()