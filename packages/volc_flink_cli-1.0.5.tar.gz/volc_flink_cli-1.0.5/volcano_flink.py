#!/usr/bin/env python3
"""
火山引擎流式计算 Flink 版 Client 工具 - 命令行入口
Volcano Engine Flink Stream Computing Client - Command Line Interface
"""

import argparse
import sys
import re
from pathlib import Path

CURRENT_DIR = Path(__file__).resolve().parent
if str(CURRENT_DIR) not in sys.path:
    sys.path.insert(0, str(CURRENT_DIR))

from volcano_flink_cli.auth_config import attach_auth_and_config_subcommands
from volcano_flink_cli.catalog_cmds import attach_catalog_subcommands
from volcano_flink_cli.conn_cmds import attach_conn_and_connection_subcommands
from volcano_flink_cli.drafts_cmds import attach_drafts_subcommands
from volcano_flink_cli.files_cmds import attach_files_subcommands
from volcano_flink_cli.jobs_cmds import attach_jobs_subcommands
from volcano_flink_cli.monitor_cmds import attach_monitor_subcommands
from volcano_flink_cli.projects_cmds import attach_projects_subcommands
from volcano_flink_cli.resource_pools_cmds import attach_resource_pools_subcommands
from volcano_flink_cli.sessions_cmds import attach_sessions_subcommands


def _get_cli_version() -> str:
    try:
        from importlib.metadata import PackageNotFoundError, version  # type: ignore
    except Exception:
        try:
            from importlib_metadata import PackageNotFoundError, version  # type: ignore
        except Exception:
            version = None
            PackageNotFoundError = Exception

    if version is not None:
        try:
            return str(version("volc-flink-cli"))
        except PackageNotFoundError:
            pass
        except Exception:
            pass

    pyproject_path = CURRENT_DIR / "pyproject.toml"
    if pyproject_path.exists():
        try:
            content = pyproject_path.read_text(encoding="utf-8")
        except Exception:
            content = ""
        in_project = False
        for line in content.splitlines():
            stripped = line.strip()
            if stripped.startswith("[") and stripped.endswith("]"):
                in_project = stripped == "[project]"
                continue
            if not in_project:
                continue
            m = re.match(r'version\s*=\s*["\']([^"\']+)["\']', stripped)
            if m:
                return m.group(1)

    return "unknown"


def main():
    parser = argparse.ArgumentParser(description="火山引擎流式计算 Flink 版 Client 工具")
    subparsers = parser.add_subparsers(title="子命令", help="可用子命令")

    attach_auth_and_config_subcommands(subparsers)
    attach_conn_and_connection_subcommands(subparsers)
    attach_projects_subcommands(subparsers)
    attach_resource_pools_subcommands(subparsers)
    attach_catalog_subcommands(subparsers)
    attach_sessions_subcommands(subparsers)
    attach_files_subcommands(subparsers)
    attach_drafts_subcommands(subparsers)
    attach_monitor_subcommands(subparsers)
    attach_jobs_subcommands(subparsers)

    parser.add_argument("-v", "--version", action="version", version=f"volc-flink-cli v{_get_cli_version()}")

    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)

    args = parser.parse_args()
    try:
        args.func(args)
    except Exception as e:
        print(f"❌ 错误: {str(e)}")
        if hasattr(args, "debug") and args.debug:
            import traceback

            print(traceback.format_exc())
        sys.exit(1)


if __name__ == "__main__":
    main()
