#!/usr/bin/env bash
set -euo pipefail

repo_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

check_path_hint() {
    local local_bin
    local_bin="${HOME}/.local/bin"
    case ":${PATH}:" in
        *":${local_bin}:"*) ;;
        *)
            echo "PATH hint: add ${local_bin} to PATH to run pipx-installed commands."
            ;;
    esac
}

run_check() {
    local exe
    if ! exe="$(command -v eqdsk-from-cdf)"; then
        echo "FAILED: eqdsk-from-cdf is not on PATH"
        exit 1
    fi

    if ! eqdsk-from-cdf --help >/dev/null; then
        echo "FAILED: eqdsk-from-cdf --help did not succeed"
        exit 1
    fi

    if ! eqdsk-from-cdf validate >/dev/null; then
        echo "FAILED: eqdsk-from-cdf validate did not succeed"
        exit 1
    fi

    echo "OK: ${exe}"
}

if [[ "${1:-}" == "--check" ]]; then
    run_check
    exit 0
fi

if [[ "${1:-}" != "" ]]; then
    echo "Usage: ./install.sh [--check]"
    exit 1
fi

if ! command -v pipx >/dev/null; then
    echo "pipx is not installed."
    echo "Recommended:"
    echo "  python -m pip install --user pipx"
    echo "  python -m pipx ensurepath"
    echo "  pipx install eqdsk-from-cdf"
    echo
    echo "Fallback from this checkout:"
    echo "  python -m venv .venv"
    echo "  source .venv/bin/activate"
    echo "  python -m pip install ."
    exit 1
fi

check_path_hint
cd "${repo_dir}"
pipx install .
check_path_hint
echo "Installed eqdsk-from-cdf from ${repo_dir}"
