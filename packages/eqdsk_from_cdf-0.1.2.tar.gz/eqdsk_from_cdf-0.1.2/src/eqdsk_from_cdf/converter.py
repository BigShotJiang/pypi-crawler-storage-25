from __future__ import annotations

import io
import math
import re
from pathlib import Path as FilePath

import numpy as np
from matplotlib.path import Path
from scipy.interpolate import CloughTocher2DInterpolator, CubicSpline, RBFInterpolator
from scipy.io import netcdf_file

from . import eqdsk as eqdsk_io

_TWO_PI = 2.0 * np.pi

_UNIT_FACTORS = {
    "CM": (1.0e-2, "m"),
    "CM**2": (1.0e-4, "m^2"),
    "CM**3": (1.0e-6, "m^3"),
    "CM**-1": (1.0e2, "m^-1"),
    "CM**-2": (1.0e4, "m^-2"),
    "CM**-3": (1.0e6, "m^-3"),
    "CM/SEC": (1.0e-2, "m/s"),
    "CM**2/SEC": (1.0e-4, "m^2/s"),
    "AMPS/CM2": (1.0e4, "A/m^2"),
    "AMPS/CM^2": (1.0e4, "A/m^2"),
    "AMPS/CM**2": (1.0e4, "A/m^2"),
    "AMP*TESLA/CM2": (1.0e4, "A*T/m^2"),
    "TESLA*CM": (1.0e-2, "T*m"),
    "TESLA*CM2": (1.0e-4, "T*m^2"),
    "TESLA*CM^2": (1.0e-4, "T*m^2"),
    "TESLA*CM**2": (1.0e-4, "T*m^2"),
    "OHM*CM": (1.0e-2, "ohm*m"),
    "WATTS/CM3": (1.0e6, "W/m^3"),
    "N/CM3/SEC": (1.0e6, "1/(m^3*s)"),
    "N/CM**3": (1.0e6, "1/m^3"),
    "JLES/CM3": (1.0e6, "J/m^3"),
}

_DEFAULT_SIGNALS = (
    "XB",
    "PLFLX",
    "Q",
    "Q0",
    "GFUN",
    "BZXR",
    "PMHD_IN",
    "PMHD",
    "PTOWB",
    "RAXIS",
    "YAXIS",
    "PCUR",
    "RLIM",
    "YLIM",
    "CUR",
    "PLJB",
    "RMC00",
)

_CDF_HEADER_PATTERN = re.compile(r'(?P<shot>\d{5,})(?P<identifier>[A-Za-z]\d{2})')


def _mom2rz(rcos, rsin, zcos, zsin, ntheta=None, theta=None):
    if theta is None:
        if ntheta is None:
            raise ValueError("Provide either theta or ntheta")
        theta = np.linspace(0.0, _TWO_PI, ntheta, endpoint=True)
    else:
        theta = np.asarray(theta, dtype=float)

    nmom = np.asarray(rcos).shape[-1]
    angle = np.outer(np.arange(nmom), theta)
    cos = np.cos(angle)
    sin = np.sin(angle)

    r = np.tensordot(rcos, cos, axes=([-1, 0])) + np.tensordot(rsin, sin, axes=([-1, 0]))
    z = np.tensordot(zcos, cos, axes=([-1, 0])) + np.tensordot(zsin, sin, axes=([-1, 0]))
    return r, z


def _normalize_units(units):
    if units is None:
        return None
    if isinstance(units, bytes):
        units = units.decode("ascii", errors="ignore")
    units = units.strip()
    return units or None


def _convert_units(data, units):
    units = _normalize_units(units)
    if units is None:
        return np.asarray(data), None
    factor_units = _UNIT_FACTORS.get(units.upper())
    if factor_units is None:
        return np.asarray(data), units
    factor, converted = factor_units
    return np.asarray(data, dtype=float) * factor, converted


def _read_var(handle, name):
    var = handle.variables[name]
    if len(var.shape) == 0:
        return np.asarray(var.data)
    return np.asarray(var[:])


def _time_axis_for(var, handle, requested_time):
    if requested_time is None or len(var.shape) == 0:
        return None, None

    dims = tuple(var.dimensions)
    for preferred in ("TIME3", "TIME"):
        for axis, dim_name in enumerate(dims):
            if dim_name.upper() != preferred:
                continue
            coord = handle.variables.get(dim_name)
            if coord is None or len(coord.shape) != 1:
                continue
            return axis, np.asarray(coord[:], dtype=float)

    for axis, dim_name in enumerate(dims):
        coord = handle.variables.get(dim_name)
        if coord is None or len(coord.shape) != 1:
            continue
        values = np.asarray(coord[:], dtype=float)
        if values.size < 2 or not np.all(np.isfinite(values)):
            continue
        diffs = np.diff(values)
        if np.all(diffs >= 0.0) or np.all(diffs <= 0.0):
            return axis, values

    return None, None


def _interp_along_axis(data, axis, coord_values, target_time):
    coord_values = np.asarray(coord_values, dtype=float)
    data = np.asarray(data)

    if target_time <= coord_values[0]:
        return np.asarray(np.take(data, 0, axis=axis), dtype=float)
    if target_time >= coord_values[-1]:
        return np.asarray(np.take(data, coord_values.size - 1, axis=axis), dtype=float)

    index = int(np.searchsorted(coord_values, target_time, side="right") - 1)
    index = max(0, min(index, coord_values.size - 2))
    delta = coord_values[index + 1] - coord_values[index]
    frac = 0.0 if delta == 0.0 else (target_time - coord_values[index]) / delta
    left = np.asarray(np.take(data, index, axis=axis), dtype=float)
    right = np.asarray(np.take(data, index + 1, axis=axis), dtype=float)
    return (1.0 - frac) * left + frac * right


def _avg_along_axis(data, axis, coord_values, requested_time, avg_time):
    coord_values = np.asarray(coord_values, dtype=float)
    time_min = requested_time - avg_time
    time_max = requested_time + avg_time
    if (
        avg_time <= 0.0
        or coord_values.size < 2
        or time_max <= coord_values[0]
        or time_min >= coord_values[-1]
        or time_min >= time_max
    ):
        return _interp_along_axis(data, axis, coord_values, requested_time), [float(requested_time)]

    shape = list(np.asarray(data).shape)
    shape.pop(axis)
    averaged = np.zeros(shape, dtype=float)
    selected_times = []
    weight_sum = 0.0

    for index in range(coord_values.size - 1):
        start = max(time_min, float(coord_values[index]))
        stop = min(time_max, float(coord_values[index + 1]))
        if stop <= start:
            continue
        midpoint = 0.5 * (start + stop)
        weight = stop - start
        averaged += weight * _interp_along_axis(data, axis, coord_values, midpoint)
        weight_sum += weight
        selected_times.append(midpoint)

    if weight_sum <= 0.0:
        return _interp_along_axis(data, axis, coord_values, requested_time), [float(requested_time)]

    return averaged / weight_sum, selected_times


def _read_time_slice(handle, name, target_time, avg_time=0.0):
    if name not in handle.variables:
        raise KeyError(name)
    var = handle.variables[name]
    data = _read_var(handle, name)
    axis, coord_values = _time_axis_for(var, handle, target_time)
    selected_times = []
    if axis is not None and coord_values is not None and target_time is not None:
        data, selected_times = _avg_along_axis(data, axis, coord_values, target_time, avg_time)
    data, units = _convert_units(data, getattr(var, "units", None))
    return {
        "name": name,
        "data": np.asarray(data),
        "units": units,
        "dimensions": tuple(var.dimensions),
        "selected_times": selected_times,
    }


def _count_moments(handle, prefix, width):
    n = 0
    while True:
        name = f"{prefix}{n:0{width}d}" if width > 0 else f"{prefix}{n:d}"
        if name not in handle.variables:
            break
        n += 1
    return n


def _geqdsk_header_metadata(cdf_name, time_s):
    stem = FilePath(cdf_name).stem.upper()
    match = _CDF_HEADER_PATTERN.search(stem)
    if match is None:
        shot = 55555
        identifier = stem[:3] if stem else 'CDF'
        title = stem[:11] if stem else 'EQDSK'
    else:
        shot = int(match.group('shot'))
        identifier = match.group('identifier')
        title = f'{shot}{identifier}'[:11]
    time_ms = int(round(float(time_s) * 1000.0))
    return {
        'shot': shot,
        'identifier': identifier,
        'title': title,
        'time_s': float(time_s),
        'time_ms': time_ms,
        'stin': str(time_ms),
    }


def _read_moment_geometry_slice(cdf_name, target_time, avg_time=0.0, ntheta=361):
    with netcdf_file(str(FilePath(cdf_name)), "r", mmap=False) as handle:
        nmom = _count_moments(handle, "RMC", width=2)
        if nmom < 1:
            raise ValueError("No flux-surface moments in CDF")

        rmc0 = _read_time_slice(handle, "RMC00", target_time, avg_time=avg_time)
        nt_surface = int(np.asarray(rmc0["data"]).shape[0])
        rcos = np.zeros((nt_surface, nmom), dtype=float)
        rsin = np.zeros((nt_surface, nmom), dtype=float)
        zcos = np.zeros((nt_surface, nmom), dtype=float)
        zsin = np.zeros((nt_surface, nmom), dtype=float)
        rcos[:, 0] = np.asarray(rmc0["data"], dtype=float)
        zcos[:, 0] = np.asarray(_read_time_slice(handle, "YMC00", target_time, avg_time=avg_time)["data"], dtype=float)
        for j in range(1, nmom):
            rcos[:, j] = np.asarray(_read_time_slice(handle, f"RMC{j:02d}", target_time, avg_time=avg_time)["data"], dtype=float)
            zcos[:, j] = np.asarray(_read_time_slice(handle, f"YMC{j:02d}", target_time, avg_time=avg_time)["data"], dtype=float)
            rsin[:, j] = np.asarray(_read_time_slice(handle, f"RMS{j:02d}", target_time, avg_time=avg_time)["data"], dtype=float)
            zsin[:, j] = np.asarray(_read_time_slice(handle, f"YMS{j:02d}", target_time, avg_time=avg_time)["data"], dtype=float)
        surf_r, surf_z = _mom2rz(rcos, rsin, zcos, zsin, ntheta=ntheta)

        boundary_r = boundary_z = None
        if "RMCB0" in handle.variables and "YMCB0" in handle.variables:
            nbmom = _count_moments(handle, "RMCB", width=0)
            rb_cos = np.zeros(nbmom, dtype=float)
            rb_sin = np.zeros(nbmom, dtype=float)
            zb_cos = np.zeros(nbmom, dtype=float)
            zb_sin = np.zeros(nbmom, dtype=float)
            rb_cos[0] = float(np.asarray(_read_time_slice(handle, "RMCB0", target_time, avg_time=avg_time)["data"]).item())
            zb_cos[0] = float(np.asarray(_read_time_slice(handle, "YMCB0", target_time, avg_time=avg_time)["data"]).item())
            for j in range(1, nbmom):
                rb_cos[j] = float(np.asarray(_read_time_slice(handle, f"RMCB{j:d}", target_time, avg_time=avg_time)["data"]).item())
                zb_cos[j] = float(np.asarray(_read_time_slice(handle, f"YMCB{j:d}", target_time, avg_time=avg_time)["data"]).item())
                rb_sin[j] = float(np.asarray(_read_time_slice(handle, f"RMSB{j:d}", target_time, avg_time=avg_time)["data"]).item())
                zb_sin[j] = float(np.asarray(_read_time_slice(handle, f"YMSB{j:d}", target_time, avg_time=avg_time)["data"]).item())
            boundary_r, boundary_z = _mom2rz(rb_cos, rb_sin, zb_cos, zb_sin, ntheta=ntheta)

        return {
            "surf_r": np.asarray(surf_r, dtype=float)[:, :-1],
            "surf_z": np.asarray(surf_z, dtype=float)[:, :-1],
            "boundary_r": None if boundary_r is None else np.asarray(boundary_r, dtype=float)[:-1],
            "boundary_z": None if boundary_z is None else np.asarray(boundary_z, dtype=float)[:-1],
            "selected_times": rmc0["selected_times"],
        }


def read_transp_geqdsk_slice(cdf_name, target_time, avg_time=0.0, signals=None):
    signals = _DEFAULT_SIGNALS if signals is None else tuple(signals)
    result = {
        "cdf_name": str(cdf_name),
        "target_time": target_time,
        "avg_time": avg_time,
        "signals": {},
    }
    with netcdf_file(str(FilePath(cdf_name)), "r", mmap=False) as handle:
        for name in signals:
            if name not in handle.variables:
                continue
            result["signals"][name] = _read_time_slice(handle, name, target_time, avg_time=avg_time)
    return result


def _get_signal(slice_data, name, required=True):
    item = slice_data["signals"].get(name)
    if item is None:
        if required:
            raise KeyError(f"Signal {name!r} not available")
        return None
    return np.asarray(item["data"])


def _axis_extrapolate(values):
    values = np.asarray(values, dtype=float)
    if values.size < 2:
        return float(values[0])
    return float(values[0] + (values[0] - values[1]) / 3.0)


def _zone_to_surface(values):
    values = np.asarray(values, dtype=float)
    if values.size == 0:
        return values
    if values.size == 1:
        return np.asarray([values[0], values[0]], dtype=float)
    result = np.empty(values.size + 1, dtype=float)
    result[0] = values[0]
    result[1:-1] = 0.5 * (values[:-1] + values[1:])
    result[-1] = max(0.1 * values[-1], values[-1] - (result[-2] - values[-1]))
    return result


def build_transp_profile_set(slice_data, bt_sign, ip_sign):
    xb = np.asarray(_get_signal(slice_data, "XB"), dtype=float).ravel()
    plflx = np.asarray(_get_signal(slice_data, "PLFLX"), dtype=float).ravel()
    q_zone = np.asarray(_get_signal(slice_data, "Q"), dtype=float).ravel()
    q0 = float(np.asarray(_get_signal(slice_data, "Q0")).item())
    gfun = slice_data["signals"].get("GFUN")
    bzxr = slice_data["signals"].get("BZXR")
    pcur = float(np.asarray(_get_signal(slice_data, "PCUR")).item())
    r_axis = float(np.asarray(_get_signal(slice_data, "RAXIS")).item())
    z_axis = float(np.asarray(_get_signal(slice_data, "YAXIS")).item())

    rho_eq = np.concatenate([[0.0], xb])
    rho_eq[0] = 0.0
    rho_eq[-1] = 1.0

    psi_eq = np.concatenate([[0.0], plflx])
    q_eq = np.concatenate([[q0], q_zone])

    p_zone = None
    for name in ("PMHD_IN", "PMHD", "PTOWB"):
        item = slice_data["signals"].get(name)
        if item is not None:
            p_zone = np.asarray(item["data"], dtype=float).ravel()
            break
    if p_zone is None:
        raise ValueError("Missing pressure profile: PMHD_IN / PMHD / PTOWB")
    p_eq = _zone_to_surface(p_zone)

    if gfun is not None and bzxr is not None:
        g_zone = np.asarray(gfun["data"], dtype=float).ravel() * float(np.asarray(bzxr["data"]).item())
        g_eq = np.empty(rho_eq.size, dtype=float)
        g_eq[1:] = g_zone
        g_eq[0] = _axis_extrapolate(g_zone)
    else:
        pljb = slice_data["signals"].get("PLJB")
        cur = slice_data["signals"].get("CUR")
        if pljb is None or cur is None:
            raise ValueError("Missing toroidal field profile: need GFUN+BZXR or PLJB+CUR")
        pljb_values = np.asarray(pljb["data"], dtype=float).ravel()
        cur_values = np.asarray(cur["data"], dtype=float).ravel()
        safe_current = np.where(np.abs(cur_values) < 1.0e-12, np.nan, cur_values)
        rmc00 = np.asarray(_get_signal(slice_data, "RMC00"), dtype=float).ravel()
        g_eq = np.concatenate(
            [[pljb_values[0] / safe_current[0] * rmc00[0]], (pljb_values / safe_current) * rmc00]
        )

    return {
        "rho_eq": rho_eq,
        "psi_eq": psi_eq,
        "q_eq": q_eq,
        "p_eq": p_eq,
        "g_eq": g_eq,
        "r_axis": r_axis,
        "z_axis": z_axis,
        "current": float(ip_sign) * abs(pcur),
        "bt_sign": int(bt_sign),
        "ip_sign": int(ip_sign),
    }


def _smooth_periodic(values, nmodes_keep):
    values = np.asarray(values, dtype=float)
    n = values.size
    if nmodes_keep is None or nmodes_keep <= 0 or nmodes_keep >= n // 2:
        return values.copy()
    fft = np.fft.rfft(values)
    fft[nmodes_keep + 1 :] = 0.0
    return np.fft.irfft(fft, n=n)


def _edge_slope_nonuniform(values, rho, slope_avg_surfaces):
    values = np.asarray(values, dtype=float)
    rho = np.asarray(rho, dtype=float)
    n_segment = min(int(slope_avg_surfaces), values.shape[0] - 1)
    if n_segment < 1:
        raise ValueError("Need at least 2 surfaces for edge slope")
    deltas = np.diff(values[-(n_segment + 1) :], axis=0)
    drho = np.diff(rho[-(n_segment + 1) :])
    slopes = deltas / drho[:, None]
    return np.mean(slopes, axis=0)


def _fill_nan_with_rbf_extrapolation(rr, zz, psi, n_train=300, seed=0):
    psi = np.asarray(psi, dtype=float)
    mask = ~np.isfinite(psi)
    if not np.any(mask):
        return psi

    valid = np.isfinite(psi)
    points = np.column_stack([np.asarray(rr[valid], dtype=float), np.asarray(zz[valid], dtype=float)])
    values = np.asarray(psi[valid], dtype=float)
    query = np.column_stack([np.asarray(rr[mask], dtype=float), np.asarray(zz[mask], dtype=float)])
    if points.shape[0] == 0:
        return psi

    rng = np.random.default_rng(seed)
    n_use = min(int(n_train), points.shape[0])
    if n_use < points.shape[0]:
        keep = rng.choice(points.shape[0], size=n_use, replace=False)
        train_points = points[keep]
        train_values = values[keep]
    else:
        train_points = points
        train_values = values

    rbf = RBFInterpolator(
        train_points,
        train_values,
        neighbors=min(64, train_points.shape[0]),
        degree=2,
        smoothing=0.0,
    )
    filled = psi.copy()
    filled[mask] = rbf(query)
    return filled


def _geqdsk_roundtrip_array(values):
    array = np.asarray(values, dtype=float)
    flat = array.ravel()
    text = eqdsk_io._fmt(flat)
    parsed = np.fromiter((float(token) for token in eqdsk_io.get_generator(io.StringIO(text))), dtype=float, count=flat.size)
    return parsed.reshape(array.shape)


def _close_curve(r, z):
    r = np.asarray(r, dtype=float)
    z = np.asarray(z, dtype=float)
    if r.size == 0 or z.size == 0:
        return None, None
    if r[0] == r[-1] and z[0] == z[-1]:
        return r, z
    return np.concatenate([r, r[:1]]), np.concatenate([z, z[:1]])


def _select_limiter_from_slice(slice_data, close=True):
    rlim = slice_data["signals"].get("RLIM")
    zlim = slice_data["signals"].get("YLIM")
    if rlim is None or zlim is None:
        return None, None
    rpts = np.asarray(rlim["data"], dtype=float).ravel()
    zpts = np.asarray(zlim["data"], dtype=float).ravel()
    if close:
        return _close_curve(rpts, zpts)
    return rpts, zpts


def _dedupe_closed_points(points):
    if len(points) == 0:
        return points
    deduped = [points[0]]
    for point in points[1:]:
        if not np.allclose(point, deduped[-1], atol=1.0e-12):
            deduped.append(point)
    result = np.asarray(deduped, dtype=float)
    if len(result) > 1 and np.allclose(result[0], result[-1], atol=1.0e-12):
        result = result[:-1]
    return result


def _polyline_resample(points, count):
    closed = np.vstack([points, points[0]])
    seg = np.sqrt(np.sum(np.diff(closed, axis=0) ** 2, axis=1))
    arc = np.concatenate([[0.0], np.cumsum(seg)])
    targets = np.linspace(0.0, arc[-1], count)
    out = np.empty((count, 2), dtype=float)
    for i, value in enumerate(targets):
        index = np.searchsorted(arc, value, side="right") - 1
        index = min(index, len(seg) - 1)
        frac = 0.0 if seg[index] == 0.0 else (value - arc[index]) / seg[index]
        out[i] = closed[index] * (1.0 - frac) + closed[index + 1] * frac
    return out


def _insert_inboard_midplane_start(points):
    points = _dedupe_closed_points(points)
    if len(points) < 2:
        return points
    rmin = float(np.min(points[:, 0]))
    zmid = 0.5 * (float(np.min(points[:, 1])) + float(np.max(points[:, 1])))
    for index in range(len(points)):
        p1 = points[index]
        p2 = points[(index + 1) % len(points)]
        if abs(p1[0] - rmin) > 1.0e-12 or abs(p2[0] - rmin) > 1.0e-12:
            continue
        zlo = min(float(p1[1]), float(p2[1]))
        zhi = max(float(p1[1]), float(p2[1]))
        zstart = min(zhi, max(zlo, zmid))
        start = np.asarray([rmin, zstart], dtype=float)
        tail = points[(index + 1) :] if index + 1 < len(points) else np.empty((0, 2), dtype=float)
        head = points[: index + 1]
        return np.vstack([start, tail, head])
    return points


def _prefer_downward_orientation(points, count):
    forward = _polyline_resample(points, count)
    if len(points) >= 2:
        reverse_points = np.vstack([points[0], points[:0:-1]])
    else:
        reverse_points = points
    reverse = _polyline_resample(reverse_points, count)
    if len(forward) < 2:
        return forward
    forward_dz = float(forward[1, 1] - forward[0, 1])
    reverse_dz = float(reverse[1, 1] - reverse[0, 1])
    if forward_dz <= 0.0 and reverse_dz > 0.0:
        return forward
    if reverse_dz <= 0.0 and forward_dz > 0.0:
        return reverse
    return reverse if abs(reverse_dz) > abs(forward_dz) else forward


def _segment_intersection(p0, p1, q0, q1):
    p = np.asarray(p0, dtype=float)
    r = np.asarray(p1, dtype=float) - p
    q = np.asarray(q0, dtype=float)
    s = np.asarray(q1, dtype=float) - q
    matrix = np.array([[r[0], -s[0]], [r[1], -s[1]]], dtype=float)
    det = float(np.linalg.det(matrix))
    if abs(det) < 1.0e-14:
        return None
    t, u = np.linalg.solve(matrix, q - p)
    if t < -1.0e-12 or t > 1.0 + 1.0e-12 or u < -1.0e-12 or u > 1.0 + 1.0e-12:
        return None
    return float(t), float(u), p + t * r


def _xplasma_contour_data(polygon):
    r = np.asarray(polygon[:, 0], dtype=float)
    z = np.asarray(polygon[:, 1], dtype=float)
    if not np.allclose(polygon[0], polygon[-1], atol=1.0e-12, rtol=0.0):
        r = np.concatenate([r, [r[0]]])
        z = np.concatenate([z, [z[0]]])

    zmin = float(np.min(z[:-1]))
    zmax = float(np.max(z[:-1]))
    zmid = 0.5 * (zmin + zmax)
    crossings = []
    for index in range(len(r) - 1):
        z0 = float(z[index])
        z1 = float(z[index + 1])
        if (z0 < zmid <= z1) or (z0 > zmid >= z1):
            frac = 0.5 if z1 == z0 else (zmid - z0) / (z1 - z0)
            crossings.append(float(r[index] * (1.0 - frac) + r[index + 1] * frac))
    crossings.sort()
    r0 = 0.5 * (crossings[-1] + crossings[-2]) if len(crossings) >= 2 else float(np.mean(r[:-1]))
    z0 = zmid

    normals = np.empty((len(r), 2), dtype=float)
    consts = np.empty(len(r), dtype=float)
    lengths = np.empty(len(r), dtype=float)
    sign_sum = 0.0
    for index in range(len(r) - 1):
        dr = float(r[index + 1] - r[index])
        dz = float(z[index + 1] - z[index])
        theta = math.atan2(dz, dr)
        nx = -math.sin(theta)
        nz = math.cos(theta)
        const = r[index] * nx + z[index] * nz
        normals[index] = [nx, nz]
        consts[index] = const
        lengths[index] = dr * dr + dz * dz
        ztest = r0 * nx + z0 * nz - const
        sign_sum += (1.0 if ztest < 0.0 else -1.0) * math.sqrt(lengths[index])
    normals[-1] = normals[0]
    consts[-1] = consts[0]
    lengths[-1] = lengths[0]
    sign = -1.0 if sign_sum < 0.0 else 1.0
    return {"r": r, "z": z, "normals": normals, "consts": consts, "lengths": lengths, "sign": sign}


def _xplasma_contour_distance(point, contour):
    r = contour["r"]
    z = contour["z"]
    normals = contour["normals"]
    consts = contour["consts"]
    lengths = contour["lengths"]
    sign = float(contour["sign"])
    point = np.asarray(point, dtype=float)

    best_segment_dist = math.inf
    best_segment_point = np.asarray([r[0], z[0]], dtype=float)
    for index in range(len(r) - 1):
        nx, nz = normals[index]
        ztest = nx * point[0] + nz * point[1] - consts[index]
        distance = sign * ztest
        nearest = np.asarray([point[0] - nx * ztest, point[1] - nz * ztest], dtype=float)
        d0 = float(np.sum((nearest - np.asarray([r[index], z[index]], dtype=float)) ** 2))
        d1 = float(np.sum((nearest - np.asarray([r[index + 1], z[index + 1]], dtype=float)) ** 2))
        if max(d0, d1) <= float(lengths[index]) + 1.0e-12 and abs(distance) < abs(best_segment_dist):
            best_segment_dist = distance
            best_segment_point = nearest

    best_distance2 = best_segment_dist * best_segment_dist
    endpoint_index = -1
    for index in range(1, len(r)):
        dist2 = float((point[0] - r[index]) ** 2 + (point[1] - z[index]) ** 2)
        if dist2 < best_distance2:
            endpoint_index = index
            best_distance2 = dist2

    if endpoint_index == -1:
        return float(best_segment_dist), best_segment_point

    prev_index = endpoint_index - 1
    dist_sum = 0.0
    for index in (prev_index, endpoint_index):
        nx, nz = normals[index]
        dist_sum += sign * (nx * point[0] + nz * point[1] - consts[index])
    signed = math.sqrt(best_distance2)
    if dist_sum < 0.0:
        signed = -signed
    return float(signed), np.asarray([r[endpoint_index], z[endpoint_index]], dtype=float)


def _first_polyline_polygon_intersection(polyline, polygon):
    best_rank = None
    best_point = None
    for ip in range(len(polyline) - 1):
        p0 = polyline[ip]
        p1 = polyline[ip + 1]
        for iq in range(len(polygon)):
            q0 = polygon[iq]
            q1 = polygon[(iq + 1) % len(polygon)]
            hit = _segment_intersection(p0, p1, q0, q1)
            if hit is None:
                continue
            t, _, point = hit
            rank = (ip, t)
            if best_rank is None or rank < best_rank:
                best_rank = rank
                best_point = point
    return best_point


def _bisect_segment_signed_distance(p0, p1, d0, d1, contour, tol=1.0e-10, max_iter=80):
    left = np.asarray(p0, dtype=float)
    right = np.asarray(p1, dtype=float)
    left_dist = float(d0)
    right_dist = float(d1)
    if not (left_dist <= 0.0 and right_dist > 0.0):
        return 0.5 * (left + right)

    for _ in range(max_iter):
        mid = 0.5 * (left + right)
        mid_dist, _ = _xplasma_contour_distance(mid, contour)
        if abs(mid_dist) <= tol or float(np.linalg.norm(right - left)) <= tol:
            return mid
        if mid_dist <= 0.0:
            left = mid
            left_dist = mid_dist
        else:
            right = mid
            right_dist = mid_dist
        if left_dist > 0.0 or right_dist <= 0.0:
            break
    return 0.5 * (left + right)


def _sample_theta_line_contour(surface_r, surface_z, polygon, count, theta_grid=None):
    if surface_r.shape != surface_z.shape or surface_r.ndim != 2:
        return None
    nrho, ntheta = surface_r.shape
    if nrho < 2 or ntheta < 2:
        return None

    if theta_grid is None:
        theta_grid = np.linspace(0.0, _TWO_PI, ntheta, dtype=float)
    theta_grid = np.unwrap(np.asarray(theta_grid, dtype=float))
    if theta_grid.ndim != 1 or theta_grid.size != ntheta:
        return None
    theta_grid = theta_grid.copy()
    for index in range(1, theta_grid.size):
        if theta_grid[index] <= theta_grid[index - 1]:
            theta_grid[index:] += _TWO_PI
    theta_periodic = np.concatenate([theta_grid, [theta_grid[0] + _TWO_PI]])
    surface_r_periodic = np.concatenate([surface_r, surface_r[:, :1]], axis=1)
    surface_z_periodic = np.concatenate([surface_z, surface_z[:, :1]], axis=1)

    r_splines = [CubicSpline(theta_periodic, surface_r_periodic[i], bc_type="periodic") for i in range(nrho)]
    z_splines = [CubicSpline(theta_periodic, surface_z_periodic[i], bc_type="periodic") for i in range(nrho)]
    contour_data = _xplasma_contour_data(polygon)

    sample_coord = np.arange(count, dtype=float) * (ntheta - 1) / count
    contour = np.empty((count, 2), dtype=float)
    for index, coord in enumerate(sample_coord):
        left = int(math.floor(coord)) % (ntheta - 1)
        frac = coord - math.floor(coord)
        right = left + 1
        zchi = float(theta_grid[left] + frac * (theta_grid[right] - theta_grid[left]))
        polyline = np.column_stack(
            [
                np.asarray([spline(zchi) for spline in r_splines], dtype=float),
                np.asarray([spline(zchi) for spline in z_splines], dtype=float),
            ]
        )
        extended = np.empty((nrho + 1, 2), dtype=float)
        extended[1:] = polyline
        extended[0] = 2.0 * polyline[0] - polyline[1]

        dist = np.empty(nrho + 1, dtype=float)
        for j in range(nrho + 1):
            dist[j], _ = _xplasma_contour_distance(extended[j], contour_data)

        found = False
        for j in range(nrho):
            if dist[j] <= 0.0 and dist[j + 1] > 0.0:
                contour[index] = _bisect_segment_signed_distance(
                    extended[j], extended[j + 1], dist[j], dist[j + 1], contour_data
                )
                found = True
                break

        if not found:
            hit = _first_polyline_polygon_intersection(polyline, polygon)
            if hit is None:
                return None
            contour[index] = hit
    return contour


def _sample_unique_points(sample_r, sample_z, sample_psi):
    points = np.column_stack([sample_r, sample_z])
    order = np.lexsort((sample_psi, sample_z, sample_r))
    points = points[order]
    sample_psi = sample_psi[order]
    keep = np.ones(points.shape[0], dtype=bool)
    for index in range(1, points.shape[0]):
        same_point = (
            abs(points[index, 0] - points[index - 1, 0]) <= 1.0e-12
            and abs(points[index, 1] - points[index - 1, 1]) <= 1.0e-12
        )
        same_psi = abs(sample_psi[index] - sample_psi[index - 1]) <= 1.0e-12
        if same_point and same_psi:
            keep[index] = False
    return points[keep], sample_psi[keep]


def build_phys_psirz_from_transp(
    cdf_name,
    target_time,
    *,
    avg_time=0.0,
    bt_sign=1,
    ip_sign=1,
    ntheta=361,
    r_grid=None,
    z_grid=None,
    nr_out=301,
    nz_out=301,
    n_ghost=8,
    ghost_dr=None,
    slope_avg_surfaces=2,
    smooth_poloidal_modes=12,
    limiter_pad=0.02,
    mask_outside_limiter=False,
    rbf_n_train=300,
):
    slice_data = read_transp_geqdsk_slice(cdf_name, target_time, avg_time=avg_time)
    profiles = build_transp_profile_set(slice_data, bt_sign=bt_sign, ip_sign=ip_sign)
    geometry = _read_moment_geometry_slice(cdf_name, target_time, avg_time=avg_time, ntheta=ntheta)

    surf_r = np.asarray(geometry["surf_r"], dtype=float)
    surf_z = np.asarray(geometry["surf_z"], dtype=float)
    boundary_r = surf_r[-1] if geometry["boundary_r"] is None else np.asarray(geometry["boundary_r"], dtype=float)
    boundary_z = surf_z[-1] if geometry["boundary_z"] is None else np.asarray(geometry["boundary_z"], dtype=float)
    limiter_r, limiter_z = _select_limiter_from_slice(slice_data, close=True)

    theta = np.linspace(0.0, _TWO_PI, surf_r.shape[1], endpoint=False)
    rho_surfaces = np.asarray(profiles["rho_eq"][1:], dtype=float)
    psi_surfaces = np.asarray(profiles["psi_eq"][1:], dtype=float)
    psi_axis = float(profiles["psi_eq"][0])
    psi_bdry = float(profiles["psi_eq"][-1])
    r_axis = float(profiles["r_axis"])
    z_axis = float(profiles["z_axis"])

    if surf_r.shape[0] != rho_surfaces.size:
        raise ValueError("Moment surface count does not match XB/PLFLX surface count")

    if ghost_dr is None:
        ghost_dr = float(rho_surfaces[-1] - rho_surfaces[-2])

    edge_dr = _edge_slope_nonuniform(surf_r, rho_surfaces, slope_avg_surfaces)
    edge_dz = _edge_slope_nonuniform(surf_z, rho_surfaces, slope_avg_surfaces)
    edge_dr = _smooth_periodic(edge_dr, smooth_poloidal_modes)
    edge_dz = _smooth_periodic(edge_dz, smooth_poloidal_modes)
    dpsi_drho = _edge_slope_nonuniform(psi_surfaces[:, None], rho_surfaces, slope_avg_surfaces).item()

    ghost_rho = 1.0 + ghost_dr * np.arange(1, n_ghost + 1)
    ghost_psi = psi_bdry + (ghost_rho - 1.0) * dpsi_drho
    ghost_r = np.empty((n_ghost, surf_r.shape[1]), dtype=float)
    ghost_z = np.empty((n_ghost, surf_z.shape[1]), dtype=float)
    for index, drho in enumerate(ghost_rho - 1.0):
        ghost_r[index] = surf_r[-1] + drho * edge_dr
        ghost_z[index] = surf_z[-1] + drho * edge_dz

    sample_r = np.concatenate([[r_axis], surf_r.reshape(-1), ghost_r.reshape(-1)])
    sample_z = np.concatenate([[z_axis], surf_z.reshape(-1), ghost_z.reshape(-1)])
    sample_psi = np.concatenate([[psi_axis], np.repeat(psi_surfaces, surf_r.shape[1]), np.repeat(ghost_psi, surf_r.shape[1])])
    sample_points, sample_psi = _sample_unique_points(sample_r, sample_z, sample_psi)

    interp = CloughTocher2DInterpolator(sample_points, sample_psi, fill_value=np.nan)

    if r_grid is None or z_grid is None:
        if limiter_r is None or limiter_z is None:
            rmin = np.nanmin(np.concatenate([surf_r.reshape(-1), ghost_r.reshape(-1), [r_axis]])) - limiter_pad
            rmax = np.nanmax(np.concatenate([surf_r.reshape(-1), ghost_r.reshape(-1), [r_axis]])) + limiter_pad
            zmin = np.nanmin(np.concatenate([surf_z.reshape(-1), ghost_z.reshape(-1), [z_axis]])) - limiter_pad
            zmax = np.nanmax(np.concatenate([surf_z.reshape(-1), ghost_z.reshape(-1), [z_axis]])) + limiter_pad
            limiter_path = None
        else:
            rmin = float(np.nanmin(limiter_r) - limiter_pad)
            rmax = float(np.nanmax(limiter_r) + limiter_pad)
            zmin = float(np.nanmin(limiter_z) - limiter_pad)
            zmax = float(np.nanmax(limiter_z) + limiter_pad)
            limiter_path = Path(np.column_stack([limiter_r, limiter_z]))
        r_out = _geqdsk_roundtrip_array(np.linspace(rmin, rmax, nr_out))
        z_out = _geqdsk_roundtrip_array(np.linspace(zmin, zmax, nz_out))
    else:
        r_out = np.asarray(r_grid, dtype=float)
        z_out = np.asarray(z_grid, dtype=float)
        limiter_path = None if limiter_r is None or limiter_z is None else Path(np.column_stack([limiter_r, limiter_z]))

    rr, zz = np.meshgrid(r_out, z_out, indexing="xy")
    psi_out = interp(rr, zz)
    psi_out = _fill_nan_with_rbf_extrapolation(rr, zz, psi_out, n_train=rbf_n_train)

    if mask_outside_limiter and limiter_path is not None:
        inside = limiter_path.contains_points(np.column_stack([rr.ravel(), zz.ravel()])).reshape(rr.shape)
        psi_out = np.where(inside, psi_out, np.nan)

    return {
        "slice": slice_data,
        "profiles": profiles,
        "cdf_path": str(FilePath(cdf_name)),
        "time_used": float(target_time if not geometry["selected_times"] else np.mean(geometry["selected_times"])),
        "time_index": None,
        "R_grid": r_out,
        "Z_grid": z_out,
        "RR": rr,
        "ZZ": zz,
        "psirz": psi_out,
        "surf_r": surf_r,
        "surf_z": surf_z,
        "theta_surface": theta,
        "rho_surface": rho_surfaces,
        "psi_surface": psi_surfaces,
        "boundary_r": boundary_r,
        "boundary_z": boundary_z,
        "limiter_r": limiter_r,
        "limiter_z": limiter_z,
        "ghost_rho": ghost_rho,
        "ghost_psi": ghost_psi,
        "ghost_r": ghost_r,
        "ghost_z": ghost_z,
    }


def _natural_cubic_interp(x, y, xeval):
    cs = CubicSpline(np.asarray(x, dtype=float), np.asarray(y, dtype=float), bc_type="not-a-knot", extrapolate=True)
    return np.asarray(cs(np.asarray(xeval, dtype=float)), dtype=float)


def _geqdsk_uniform_derivatives(psi, fpol, pres):
    n = psi.size
    ffprim = np.zeros(n, dtype=float)
    pprime = np.zeros(n, dtype=float)
    if n < 3:
        return ffprim, pprime
    dpsii = 0.5 / (psi[1] - psi[0])
    ffprim[0] = dpsii * fpol[0] * (4.0 * fpol[1] - fpol[2] - 3.0 * fpol[0])
    pprime[0] = dpsii * (4.0 * pres[1] - pres[2] - 3.0 * pres[0])
    ffprim[1:-1] = dpsii * fpol[1:-1] * (fpol[2:] - fpol[:-2])
    pprime[1:-1] = dpsii * (pres[2:] - pres[:-2])
    ffprim[-1] = dpsii * fpol[-1] * (3.0 * fpol[-1] - 4.0 * fpol[-2] + fpol[-3])
    pprime[-1] = dpsii * (3.0 * pres[-1] - 4.0 * pres[-2] + pres[-3])
    return ffprim, pprime


def _geqdsk_resample_boundary(theta_in, r_in, z_in, nout):
    theta_in = np.asarray(theta_in, dtype=float)
    r_in = np.asarray(r_in, dtype=float)
    z_in = np.asarray(z_in, dtype=float)
    append_periodic = (
        abs((theta_in[-1] - theta_in[0]) - _TWO_PI) > 1.0e-8
        or abs(r_in[-1] - r_in[0]) > 1.0e-8
        or abs(z_in[-1] - z_in[0]) > 1.0e-8
    )
    if append_periodic:
        theta = np.concatenate([theta_in, [theta_in[0] + _TWO_PI]])
        rsrc = np.concatenate([r_in, [r_in[0]]])
        zsrc = np.concatenate([z_in, [z_in[0]]])
    else:
        theta = theta_in.copy()
        rsrc = r_in.copy()
        zsrc = z_in.copy()

    cs_r = CubicSpline(theta, rsrc, bc_type="periodic", extrapolate="periodic")
    cs_z = CubicSpline(theta, zsrc, bc_type="periodic", extrapolate="periodic")
    theta_start = theta[0]
    theta_end = theta[-1]
    theta_period = theta_end - theta_start
    theta_zero = theta_start if theta_start > 0.0 or theta_end < 0.0 else 0.0

    r_out = np.empty(nout, dtype=float)
    z_out = np.empty(nout, dtype=float)
    for index in range(nout - 1):
        theta_eval = theta_zero + index * theta_period / (nout - 1)
        while theta_eval < theta_start:
            theta_eval += theta_period
        while theta_eval > theta_end:
            theta_eval -= theta_period
        r_out[index] = float(cs_r(theta_eval))
        z_out[index] = float(cs_z(theta_eval))
    r_out[-1] = r_out[0]
    z_out[-1] = z_out[0]
    return r_out, z_out


def _geqdsk_resample_limiter(r_in, z_in, nout):
    r_in = np.asarray(r_in, dtype=float)
    z_in = np.asarray(z_in, dtype=float)
    nsrc = r_in.size
    if nsrc > 1 and abs(r_in[0] - r_in[-1]) <= 1.0e-10 and abs(z_in[0] - z_in[-1]) <= 1.0e-10:
        nsrc -= 1
    if nsrc < 2:
        raise ValueError("Limiter needs at least 2 distinct samples")
    rsrc = r_in[:nsrc]
    zsrc = z_in[:nsrc]
    if nsrc == nout:
        return rsrc.copy(), zsrc.copy()
    seg = np.empty(nsrc, dtype=float)
    seg[:-1] = np.sqrt(np.diff(rsrc) ** 2 + np.diff(zsrc) ** 2)
    seg[-1] = np.hypot(rsrc[0] - rsrc[-1], zsrc[0] - zsrc[-1])
    arc = np.concatenate([[0.0], np.cumsum(seg)])
    total = float(arc[-1])
    if total <= 0.0:
        raise ValueError("Limiter has zero perimeter")
    r_out = np.empty(nout, dtype=float)
    z_out = np.empty(nout, dtype=float)
    for index in range(nout):
        target = total * index / nout
        seg_index = int(np.clip(np.searchsorted(arc[1:-1], target, side="right"), 0, nsrc - 1))
        next_index = seg_index + 1 if seg_index + 1 < nsrc else 0
        frac = 0.0 if seg[seg_index] <= 0.0 else (target - arc[seg_index]) / seg[seg_index]
        r_out[index] = rsrc[seg_index] * (1.0 - frac) + rsrc[next_index] * frac
        z_out[index] = zsrc[seg_index] * (1.0 - frac) + zsrc[next_index] * frac
    return r_out, z_out


def build_geqdsk_from_transp(
    cdf_name,
    target_time,
    *,
    avg_time=0.0,
    bt_sign=1,
    ip_sign=1,
    ntheta=361,
    r_grid=None,
    z_grid=None,
    nr_out=129,
    nz_out=129,
    n_ghost=8,
    boundary_count=201,
    limiter_count=201,
    limiter_pad=0.02,
):
    psirz_result = build_phys_psirz_from_transp(
        cdf_name,
        target_time,
        avg_time=avg_time,
        bt_sign=bt_sign,
        ip_sign=ip_sign,
        ntheta=ntheta,
        r_grid=r_grid,
        z_grid=z_grid,
        nr_out=nr_out,
        nz_out=nz_out,
        n_ghost=n_ghost,
        limiter_pad=limiter_pad,
    )
    profiles = psirz_result["profiles"]
    psi_eq = np.asarray(profiles["psi_eq"], dtype=float)
    q_eq = np.asarray(profiles["q_eq"], dtype=float)
    p_eq = np.asarray(profiles["p_eq"], dtype=float)
    g_eq = np.asarray(profiles["g_eq"], dtype=float)
    r_grid = np.asarray(psirz_result["R_grid"], dtype=float)
    z_grid = np.asarray(psirz_result["Z_grid"], dtype=float)
    boundary_r = np.asarray(psirz_result["boundary_r"], dtype=float)
    boundary_z = np.asarray(psirz_result["boundary_z"], dtype=float)

    psi_uniform = np.linspace(float(psi_eq[0]), float(psi_eq[-1]), r_grid.size, dtype=float)
    g_uniform = _natural_cubic_interp(psi_eq, g_eq, psi_uniform)
    pres = _natural_cubic_interp(psi_eq, p_eq, psi_uniform)
    qpsi = _natural_cubic_interp(psi_eq, q_eq, psi_uniform)
    fpol = float(bt_sign) * np.abs(g_uniform)
    ffprim, pprime = _geqdsk_uniform_derivatives(psi_uniform, fpol, pres)

    theta_bdy = np.linspace(0.0, _TWO_PI, boundary_r.size, endpoint=False)
    rbdy, zbdy = _geqdsk_resample_boundary(theta_bdy, boundary_r, boundary_z, boundary_count)

    limiter_polygon_r, limiter_polygon_z = _select_limiter_from_slice(psirz_result["slice"], close=False)
    limiter_r = limiter_z = None
    if limiter_polygon_r is not None and limiter_polygon_z is not None and psirz_result["ghost_r"].shape[0] >= 1:
        surface_r = np.vstack([psirz_result["boundary_r"][None, :], psirz_result["ghost_r"]])
        surface_z = np.vstack([psirz_result["boundary_z"][None, :], psirz_result["ghost_z"]])
        limiter_probe = _sample_theta_line_contour(
            surface_r,
            surface_z,
            np.column_stack([limiter_polygon_r, limiter_polygon_z]),
            count=202,
            theta_grid=psirz_result["theta_surface"],
        )
        if limiter_probe is not None:
            limiter_r = limiter_probe[:, 0]
            limiter_z = limiter_probe[:, 1]
    if limiter_r is None or limiter_z is None:
        limiter_r, limiter_z = _select_limiter_from_slice(psirz_result["slice"], close=False)
    if limiter_r is None or limiter_z is None:
        raise ValueError("Limiter coordinates are required for GEQDSK writing")
    rlim, zlim = _geqdsk_resample_limiter(limiter_r, limiter_z, limiter_count)

    rdim = float(r_grid[-1] - r_grid[0])
    zdim = float(z_grid[-1] - z_grid[0])
    rleft = float(r_grid[0])
    zmid = 0.5 * (float(z_grid[0]) + float(z_grid[-1]))
    rcentr = 0.5 * (float(np.min(boundary_r)) + float(np.max(boundary_r)))
    bcentr = float(fpol[-1]) / max(rcentr, 1.0e-12)
    header = _geqdsk_header_metadata(cdf_name, psirz_result['time_used'])

    geq = {
        "mw": int(r_grid.size),
        "mh": int(z_grid.size),
        "r": r_grid,
        "z": z_grid,
        "rdim": rdim,
        "zdim": zdim,
        "rcentr": rcentr,
        "bcentr": bcentr,
        "rgrid1": rleft,
        "zmid": zmid,
        "rmagx": float(profiles["r_axis"]),
        "zmagx": float(profiles["z_axis"]),
        "ssimag": float(psi_eq[0]),
        "ssibry": float(psi_eq[-1]),
        "cpasma": float(profiles["current"]),
        "psirz": np.asarray(psirz_result["psirz"], dtype=float),
        "rhorz": np.sqrt(np.clip((psirz_result["psirz"] - psi_eq[0]) / (psi_eq[-1] - psi_eq[0]), 0.0, 1.0e6)),
        "fpol": fpol,
        "pres": pres,
        "ffprim": ffprim,
        "pprime": pprime,
        "qpsi": qpsi,
        "psin": np.linspace(0.0, 1.0, r_grid.size),
        "nbdry": int(rbdy.size),
        "rbdry": rbdy,
        "zbdry": zbdy,
        "nlim": int(rlim.size),
        "xlim": rlim,
        "ylim": zlim,
        "shot": int(header["shot"]),
        "header_title": header["title"],
        "identifier": header["identifier"],
        "time_s": float(header["time_s"]),
        "time_ms": int(header["time_ms"]),
        "stin": header["stin"],
    }

    return {
        "geqdsk": geq,
        "psirz_result": psirz_result,
        "profiles": profiles,
    }


def write_geqdsk_from_transp(output_path, cdf_name, target_time, **kwargs):
    result = build_geqdsk_from_transp(cdf_name, target_time, **kwargs)
    geq = result["geqdsk"]
    eqdsk_io.write(
        str(output_path),
        geq,
        shot=int(geq.get("shot", 55555)),
        stin=str(geq.get("stin", "50000")),
        title=str(geq.get("header_title", "EQDSK")),
    )
    return result


def compare_geqdsk_files(path_a, path_b):
    eq_a = eqdsk_io.read(str(path_a))
    eq_b = eqdsk_io.read(str(path_b))
    metrics = {}
    for name in (
        "rmagx",
        "zmagx",
        "ssimag",
        "ssibry",
        "bcentr",
        "cpasma",
        "fpol",
        "pres",
        "ffprim",
        "pprime",
        "psirz",
        "qpsi",
        "rbdry",
        "zbdry",
        "xlim",
        "ylim",
    ):
        left = np.asarray(eq_a[name], dtype=float)
        right = np.asarray(eq_b[name], dtype=float)
        if left.shape != right.shape:
            metrics[name] = {
                "shape": tuple(left.shape),
                "reference_shape": tuple(right.shape),
                "abs_max": None,
                "rms": None,
                "rel_rms": None,
                "status": "shape_mismatch",
            }
            continue
        diff = left - right
        rms = float(np.sqrt(np.mean(diff**2))) if diff.size else abs(float(diff))
        denom = float(np.sqrt(np.mean(right**2))) if diff.size else max(abs(float(right)), 1.0e-300)
        rel_rms = rms / max(denom, 1.0e-300)
        metrics[name] = {
            "shape": tuple(left.shape),
            "abs_max": float(np.max(np.abs(diff))) if diff.size else abs(float(diff)),
            "rms": rms,
            "rel_rms": rel_rms,
            "status": "ok",
        }
    return metrics


def sample_validation_thresholds():
    return {
        'rmagx_abs_max': 1.0e-5,
        'zmagx_abs_max': 1.0e-5,
        'ssibry_abs_max': 1.0e-4,
        'fpol_rel_rms': 1.0e-5,
        'pres_rel_rms': 1.0e-4,
        'qpsi_rel_rms': 5.0e-3,
        'psirz_rel_rms': 8.0e-2,
    }


def validate_sample_case(output_path=None):
    paths = package_sample_paths()
    if output_path is None:
        import tempfile

        output_path = FilePath(tempfile.gettempdir()) / 'eqdsk_from_cdf_validate.geq'
    out_path = FilePath(output_path)
    reference_path = FilePath(paths['geq']).resolve()
    if out_path.resolve() == reference_path:
        raise ValueError('Validation output path must differ from the bundled sample GEQ reference path')
    result = write_geqdsk_from_transp(
        out_path,
        paths['cdf'],
        17.50435,
        avg_time=0.0,
        bt_sign=1,
        ip_sign=1,
    )
    metrics = compare_geqdsk_files(out_path, paths['geq'])
    limits = sample_validation_thresholds()
    checks = {
        'rmagx_abs_max': metrics['rmagx']['abs_max'] < limits['rmagx_abs_max'],
        'zmagx_abs_max': metrics['zmagx']['abs_max'] < limits['zmagx_abs_max'],
        'ssibry_abs_max': metrics['ssibry']['abs_max'] < limits['ssibry_abs_max'],
        'fpol_rel_rms': metrics['fpol']['rel_rms'] < limits['fpol_rel_rms'],
        'pres_rel_rms': metrics['pres']['rel_rms'] < limits['pres_rel_rms'],
        'qpsi_rel_rms': metrics['qpsi']['rel_rms'] < limits['qpsi_rel_rms'],
        'psirz_rel_rms': metrics['psirz']['rel_rms'] < limits['psirz_rel_rms'],
    }
    return {
        'ok': all(checks.values()),
        'checks': checks,
        'limits': limits,
        'metrics': metrics,
        'output_path': out_path,
        'reference_path': reference_path,
        'cdf_path': FilePath(paths['cdf']),
        'result': result,
    }


def print_geqdsk_scalar_comparison(path_a, path_b, label_a="A", label_b="B"):
    eq_a = eqdsk_io.read(str(path_a))
    eq_b = eqdsk_io.read(str(path_b))
    scalar_keys = (
        "mw",
        "mh",
        "rdim",
        "zdim",
        "rcentr",
        "bcentr",
        "rgrid1",
        "zmid",
        "rmagx",
        "zmagx",
        "ssimag",
        "ssibry",
        "cpasma",
        "nbdry",
        "nlim",
        "rxpl",
        "zxpl",
        "rxpu",
        "zxpu",
    )
    print("GEQDSK scalar comparison")
    print(f"{'name':<10} {label_a:>16} {label_b:>16} {'abs_diff':>16}")
    for key in scalar_keys:
        aval = eq_a[key]
        bval = eq_b[key]
        if isinstance(aval, (int, np.integer)) and isinstance(bval, (int, np.integer)):
            diff = abs(int(aval) - int(bval))
            print(f"{key:<10} {int(aval):16d} {int(bval):16d} {diff:16d}")
        else:
            diff = abs(float(aval) - float(bval))
            print(f"{key:<10} {float(aval):16.8g} {float(bval):16.8g} {diff:16.8g}")


def plot_geqdsk_visual_comparison(
    path_a,
    path_b,
    *,
    label_a="generated",
    label_b="reference",
    n_levels=12,
    figsize=(15, 10),
    save_path=None,
):
    import matplotlib.pyplot as plt
    from matplotlib import gridspec

    eq_a = eqdsk_io.read(str(path_a))
    eq_b = eqdsk_io.read(str(path_b))

    psi_min = max(float(eq_a["ssimag"]), float(eq_b["ssimag"]))
    psi_max = min(float(eq_a["ssibry"]), float(eq_b["ssibry"]))
    if psi_max <= psi_min:
        psi_min = min(float(eq_a["ssimag"]), float(eq_b["ssimag"]))
        psi_max = max(float(eq_a["ssibry"]), float(eq_b["ssibry"]))
    levels = np.linspace(psi_min, psi_max, int(n_levels))

    fig = plt.figure(figsize=figsize)
    gs = gridspec.GridSpec(3, 3, figure=fig, width_ratios=[1.5, 1.0, 1.0], height_ratios=[1.0, 1.0, 1.0])

    ax_geom = fig.add_subplot(gs[:, 0])
    profile_axes = [
        fig.add_subplot(gs[0, 1]),
        fig.add_subplot(gs[0, 2]),
        fig.add_subplot(gs[1, 1]),
        fig.add_subplot(gs[1, 2]),
        fig.add_subplot(gs[2, 1]),
    ]
    ax_text = fig.add_subplot(gs[2, 2])

    cs_a = ax_geom.contour(eq_a["r"], eq_a["z"], eq_a["psirz"], levels=levels, colors="k", linewidths=1.0, linestyles="-")
    ax_geom.contour(eq_b["r"], eq_b["z"], eq_b["psirz"], levels=levels, colors="tab:red", linewidths=1.0, linestyles="--")
    if len(cs_a.levels):
        ax_geom.clabel(cs_a, cs_a.levels[:: max(1, len(cs_a.levels) // 6)], inline=True, fontsize=7, fmt="%.3f")

    ax_geom.plot(eq_a["rbdry"], eq_a["zbdry"], color="k", lw=1.3, ls="-", label=f"{label_a} boundary")
    ax_geom.plot(eq_b["rbdry"], eq_b["zbdry"], color="tab:red", lw=1.3, ls="--", label=f"{label_b} boundary")
    ax_geom.plot(eq_a["xlim"], eq_a["ylim"], color="tab:blue", lw=1.0, ls="-", label=f"{label_a} limiter")
    ax_geom.plot(eq_b["xlim"], eq_b["ylim"], color="tab:orange", lw=1.0, ls="--", label=f"{label_b} limiter")
    ax_geom.plot([], [], color="k", lw=1.0, ls="-", label=f"{label_a} PsiRZ")
    ax_geom.plot([], [], color="tab:red", lw=1.0, ls="--", label=f"{label_b} PsiRZ")
    ax_geom.set_xlabel("R [m]")
    ax_geom.set_ylabel("Z [m]")
    ax_geom.set_title("PsiRZ contours, boundary, limiter")
    ax_geom.set_aspect("equal")
    ax_geom.legend(loc="best", fontsize=8)

    profile_specs = (
        ("fpol", "fpol"),
        ("pres", "pres"),
        ("ffprim", "ffprim"),
        ("pprime", "pprime"),
        ("qpsi", "qpsi"),
    )
    for ax, (key, title) in zip(profile_axes, profile_specs):
        ax.plot(eq_a["psin"], eq_a[key], color="k", ls="-", lw=1.4, label=label_a)
        ax.plot(eq_b["psin"], eq_b[key], color="tab:red", ls="--", lw=1.4, label=label_b)
        ax.set_title(title)
        ax.set_xlabel("psin")
        ax.grid(True, alpha=0.25)
        if key in ("pres", "pprime"):
            ax.ticklabel_format(axis="y", style="sci", scilimits=(0, 0))
    profile_axes[0].legend(loc="best", fontsize=8)

    metrics = compare_geqdsk_files(path_a, path_b)
    summary_lines = []
    for key in ("rmagx", "zmagx", "ssibry", "fpol", "pres", "qpsi", "psirz", "xlim", "ylim"):
        metric = metrics[key]
        summary_lines.append(f"{key}:")
        if metric.get("status") == "shape_mismatch":
            summary_lines.append(f"  shape={metric['shape']}")
            summary_lines.append(f"  ref={metric['reference_shape']}")
        else:
            summary_lines.append(f"  abs_max={metric['abs_max']:.3g}")
            summary_lines.append(f"  rel_rms={metric['rel_rms']:.3g}")
    ax_text.axis("off")
    ax_text.set_title("Mismatch summary")
    ax_text.text(0.0, 1.0, "\n".join(summary_lines), va="top", ha="left", family="monospace", fontsize=9)

    fig.tight_layout()
    if save_path is not None:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
    return fig, metrics


def plot_conversion_overview(
    result,
    *,
    save_path=None,
    title='Conversion Overview',
    n_surface=12,
    n_levels=12,
    figure=None,
):
    import matplotlib.pyplot as plt
    from matplotlib import gridspec

    psirz_result = result['psirz_result']
    geq = result['geqdsk']
    profiles = result['profiles']

    rr = np.asarray(psirz_result['RR'], dtype=float)
    zz = np.asarray(psirz_result['ZZ'], dtype=float)
    psi = np.asarray(psirz_result['psirz'], dtype=float)
    surf_r = np.asarray(psirz_result['surf_r'], dtype=float)
    surf_z = np.asarray(psirz_result['surf_z'], dtype=float)
    boundary_r = np.asarray(psirz_result['boundary_r'], dtype=float)
    boundary_z = np.asarray(psirz_result['boundary_z'], dtype=float)
    limiter_r = psirz_result['limiter_r']
    limiter_z = psirz_result['limiter_z']
    psi_surface = np.asarray(psirz_result['psi_surface'], dtype=float)
    cdf_name = FilePath(psirz_result.get('cdf_path', 'input.CDF')).name

    if figure is None:
        fig = plt.figure(figsize=(15, 10))
    else:
        fig = figure
        fig.clear()
        fig.set_size_inches(15, 10, forward=False)
    gs = gridspec.GridSpec(3, 3, figure=fig, width_ratios=[1.6, 1.0, 1.0], height_ratios=[1.0, 1.0, 1.0])
    ax_geom = fig.add_subplot(gs[:, 0])
    profile_axes = [
        fig.add_subplot(gs[0, 1]),
        fig.add_subplot(gs[0, 2]),
        fig.add_subplot(gs[1, 1]),
        fig.add_subplot(gs[1, 2]),
        fig.add_subplot(gs[2, 1]),
    ]
    ax_text = fig.add_subplot(gs[2, 2])

    psi_bdry = float(geq['ssibry'])
    psi_max = float(np.nanmax(psi))
    if psi_max > psi_bdry:
        outer_levels = np.linspace(psi_bdry, psi_max, int(max(3, n_levels + 1)))[1:]
        ax_geom.contour(rr, zz, psi, levels=outer_levels, colors='0.6', linewidths=0.9)

    select = np.linspace(0, surf_r.shape[0] - 1, num=min(int(max(2, n_surface)), surf_r.shape[0]), dtype=int)
    select = np.unique(select)
    for index in select:
        ax_geom.plot(surf_r[index], surf_z[index], color='tab:blue', lw=1.1, alpha=0.85)
    ax_geom.plot(boundary_r, boundary_z, color='k', lw=1.5, label='Moment boundary')
    if limiter_r is not None and limiter_z is not None:
        ax_geom.plot(limiter_r, limiter_z, color='tab:orange', lw=1.2, label='Limiter')

    psi_levels = psi_surface[select]
    cs = ax_geom.contour(rr, zz, psi, levels=psi_levels, colors='tab:red', linewidths=1.0, linestyles='--')
    if len(cs.levels):
        ax_geom.plot([], [], color='tab:red', lw=1.0, ls='--', label='Psi(R,Z) contours at moment levels')
    ax_geom.plot([], [], color='tab:blue', lw=1.1, label='Moment surfaces')
    ax_geom.scatter([geq['rmagx']], [geq['zmagx']], color='k', s=20, zorder=5, label='Magnetic axis')
    ax_geom.set_title(title)
    ax_geom.set_xlabel('R [m]')
    ax_geom.set_ylabel('Z [m]')
    ax_geom.set_aspect('equal')
    ax_geom.legend(loc='best', fontsize=8)

    profile_specs = (
        ('fpol', 'fpol'),
        ('pres', 'pres'),
        ('ffprim', 'ffprim'),
        ('pprime', 'pprime'),
        ('qpsi', 'qpsi'),
    )
    for ax, (key, label) in zip(profile_axes, profile_specs):
        ax.plot(geq['psin'], geq[key], lw=1.4)
        ax.set_title(label)
        ax.set_xlabel('psin')
        ax.grid(True, alpha=0.25)
        if key in ('pres', 'ffprim', 'pprime'):
            ax.ticklabel_format(axis='y', style='sci', scilimits=(0, 0))

    scalar_lines = [
        f"cdf: {cdf_name}",
        f"time used: {psirz_result['time_used']:.5f} s",
        f"current: {geq['cpasma']:.6g} A",
        f"bcentr: {geq['bcentr']:.6g} T",
        f"bt_sign: {profiles['bt_sign']:+d}",
        f"ip_sign: {profiles['ip_sign']:+d}",
        f"rmagx: {geq['rmagx']:.6f} m",
        f"zmagx: {geq['zmagx']:.6f} m",
    ]
    ax_text.axis('off')
    ax_text.set_title('Scalars')
    ax_text.text(0.0, 1.0, '\n'.join(scalar_lines), va='top', ha='left', family='monospace', fontsize=10)

    fig.tight_layout()
    if save_path is not None:
        fig.savefig(save_path, dpi=150, bbox_inches='tight')
    return fig


def package_sample_paths():
    root = FilePath(__file__).resolve().parents[2]
    if not (root / "samples").exists():
        root = FilePath(__file__).resolve().parents[1]
    return {
        "cdf": root / "samples" / "123000X78.CDF",
        "geq": root / "samples" / "123000X78.geq",
    }


def visual_compare_sample_case(save_path="/tmp/123000X78_geqdsk_visual_compare.png"):
    paths = package_sample_paths()
    validation = validate_sample_case()
    out_path = validation["output_path"]
    result = validation["result"]
    metrics = validation["metrics"]
    print_geqdsk_scalar_comparison(out_path, paths["geq"], label_a="new", label_b="ref")
    fig, metrics = plot_geqdsk_visual_comparison(
        out_path,
        paths["geq"],
        label_a="new",
        label_b="ref",
        save_path=save_path,
    )
    return out_path, save_path, result, metrics, fig


if __name__ == "__main__":
    out_path, save_path, result, metrics, fig = visual_compare_sample_case()
    print(f"wrote {out_path}")
    print(f"saved {save_path}")
