from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .converter import (
    build_geqdsk_from_transp,
    compare_geqdsk_files,
    plot_conversion_overview,
    plot_geqdsk_visual_comparison,
    print_geqdsk_scalar_comparison,
    validate_sample_case,
    write_geqdsk_from_transp,
)

SIGN_CONVENTION = 'Viewed from above (+Z), +1 = counter-clockwise and -1 = clockwise.'
DEFAULT_NR = int(build_geqdsk_from_transp.__kwdefaults__['nr_out'])
DEFAULT_NZ = int(build_geqdsk_from_transp.__kwdefaults__['nz_out'])
ADVANCED_COMMANDS = {'compare', 'sample-path', 'validate'}
VALIDATION_FIELDS = {
    'rmagx_abs_max': ('rmagx', 'abs_max'),
    'zmagx_abs_max': ('zmagx', 'abs_max'),
    'ssibry_abs_max': ('ssibry', 'abs_max'),
    'fpol_rel_rms': ('fpol', 'rel_rms'),
    'pres_rel_rms': ('pres', 'rel_rms'),
    'qpsi_rel_rms': ('qpsi', 'rel_rms'),
    'psirz_rel_rms': ('psirz', 'rel_rms'),
}


def _parse_sign(value: str) -> int:
    try:
        sign = int(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError('must be -1 or 1') from exc
    if sign not in (-1, 1):
        raise argparse.ArgumentTypeError('must be -1 or 1')
    return sign


def _default_output_path(cdf_path: Path) -> Path:
    if cdf_path.suffix:
        return cdf_path.with_suffix('.geq')
    return cdf_path.with_name(f'{cdf_path.name}.geq')


def _samples_root() -> Path:
    package_root = Path(__file__).resolve().parents[2]
    repo_samples = package_root / 'samples'
    if repo_samples.exists():
        return repo_samples
    install_samples = Path(__file__).resolve().parents[1] / 'samples'
    return install_samples


def _bundled_sample_paths() -> tuple:
    samples_root = _samples_root().resolve()
    return (
        (samples_root / '123000X78.CDF').resolve(),
        (samples_root / '123000X78.geq').resolve(),
    )


def _build_convert_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog='eqdsk-from-cdf',
        description='Convert one TRANSP CDF equilibrium time slice to a G-EQDSK file.',
        epilog=(
            f'{SIGN_CONVENTION}\n\n'
            'Example:\n'
            '  eqdsk-from-cdf run.CDF --time 17.5 --bt-sign 1 --ip-sign 1 --out out.geq\n'
            '  eqdsk-from-cdf run.CDF --time 17.5 --bt-sign 1 --ip-sign 1 --nr 257 --nz 257 --plot conversion.png\n\n'
            'Advanced commands:\n'
            '  eqdsk-from-cdf validate              Run the bundled public sample self-check\n'
            '  eqdsk-from-cdf sample-path --kind cdf Print the installed bundled sample path\n'
            '  eqdsk-from-cdf compare A.geq B.geq --output compare.png'
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    parser.add_argument('cdf_path', metavar='CDF_PATH', type=Path, help='Input TRANSP CDF file.')
    parser.add_argument(
        '--out',
        type=Path,
        help='Output GEQDSK path. Default: CDF_PATH with a .geq suffix in the same directory.',
    )
    parser.add_argument('--time', type=float, required=True, help='Target TRANSP time slice in seconds.')
    parser.add_argument(
        '--bt-sign',
        type=_parse_sign,
        required=True,
        metavar='{-1,1}',
        help=f'Toroidal magnetic field sign. {SIGN_CONVENTION}',
    )
    parser.add_argument(
        '--ip-sign',
        type=_parse_sign,
        required=True,
        metavar='{-1,1}',
        help=f'Plasma current sign. {SIGN_CONVENTION}',
    )
    parser.add_argument(
        '--nr',
        type=int,
        default=DEFAULT_NR,
        help=f'Number of output GEQDSK R grid points. Larger values preserve more spatial detail. Default: {DEFAULT_NR}.',
    )
    parser.add_argument(
        '--nz',
        type=int,
        default=DEFAULT_NZ,
        help=f'Number of output GEQDSK Z grid points. Larger values preserve more spatial detail. Default: {DEFAULT_NZ}.',
    )
    parser.add_argument('--plot', type=Path, help='Save a diagnostic plot with moment surfaces, Psi(R,Z) contours, boundary, limiter, and profiles.')
    parser.add_argument('--show', action='store_true', help='Display the conversion diagnostic plot after writing the GEQDSK.')
    parser.add_argument('--force', action='store_true', help='Allow overwriting the bundled sample GEQ reference file.')
    parser.add_argument('--version', action='version', version='%(prog)s 0.1.2')
    return parser


def _build_compare_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog='eqdsk-from-cdf compare',
        description='Compare two GEQDSK files numerically and visually.',
    )
    parser.add_argument('first', type=Path, help='First GEQDSK file.')
    parser.add_argument('second', type=Path, help='Second GEQDSK file.')
    parser.add_argument('--output', type=Path, default=None, help='Save comparison plot to this path. If omitted, show it interactively.')
    parser.add_argument('--label-first', default='first', help='Plot/report label for the first file.')
    parser.add_argument('--label-second', default='second', help='Plot/report label for the second file.')
    parser.add_argument('--levels', type=int, default=12, help='Number of Psi(R,Z) contour levels in the comparison plot.')
    return parser


def _build_sample_path_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog='eqdsk-from-cdf sample-path',
        description='Print the bundled sample file path.',
    )
    parser.add_argument('--kind', choices=('cdf', 'geq'), default='cdf', help='Choose whether to print the sample CDF or reference GEQ path.')
    return parser


def _build_validate_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog='eqdsk-from-cdf validate',
        description='Generate the bundled sample GEQDSK and compare it against the bundled public reference file.',
    )
    parser.add_argument('--out', type=Path, help='Optional path for the generated validation GEQDSK. Default: a temporary file.')
    parser.add_argument('--plot', type=Path, help='Save a validation comparison plot to this path.')
    parser.add_argument('--show', action='store_true', help='Display the validation comparison plot.')
    return parser


def _run_convert(argv: list) -> int:
    parser = _build_convert_parser()
    args = parser.parse_args(argv)

    output_path = args.out if args.out is not None else _default_output_path(args.cdf_path)
    input_path = args.cdf_path.resolve()
    output_path = output_path.resolve()
    sample_cdf_path, sample_geq_path = _bundled_sample_paths()
    if input_path == sample_cdf_path and output_path == sample_geq_path and not args.force:
        parser.exit(
            2,
            'eqdsk-from-cdf: refusing to overwrite the bundled sample GEQ. '
            'Use --out for a new file or --force to replace the bundled reference.\n',
        )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        result = write_geqdsk_from_transp(
            output_path,
            args.cdf_path,
            args.time,
            avg_time=0.0,
            bt_sign=args.bt_sign,
            ip_sign=args.ip_sign,
            nr_out=args.nr,
            nz_out=args.nz,
        )
    except Exception as exc:
        parser.exit(1, f'eqdsk-from-cdf: {exc}\n')

    if args.plot is not None or args.show:
        fig = plot_conversion_overview(
            result,
            save_path=args.plot,
            title=f'Conversion Overview: {output_path.name}',
        )
        if args.show:
            import matplotlib.pyplot as plt

            plt.show()
        import matplotlib.pyplot as plt

        plt.close(fig)
    print(output_path)
    return 0


def _run_compare(argv: list) -> int:
    parser = _build_compare_parser()
    args = parser.parse_args(argv)

    print_geqdsk_scalar_comparison(
        args.first,
        args.second,
        label_a=args.label_first,
        label_b=args.label_second,
    )
    metrics = compare_geqdsk_files(args.first, args.second)
    for key in ('rmagx', 'zmagx', 'ssibry', 'fpol', 'pres', 'qpsi', 'psirz', 'xlim', 'ylim'):
        metric = metrics[key]
        if metric.get('status') == 'shape_mismatch':
            print(
                f"{key:<8} shape_mismatch shape={metric['shape']} "
                f"reference_shape={metric['reference_shape']}"
            )
            continue
        print(
            f"{key:<8} abs_max={metric['abs_max']:.6g} "
            f"rms={metric['rms']:.6g} rel_rms={metric['rel_rms']:.6g}"
        )
    fig, _ = plot_geqdsk_visual_comparison(
        args.first,
        args.second,
        label_a=args.label_first,
        label_b=args.label_second,
        n_levels=args.levels,
        save_path=args.output,
    )
    if args.output is None:
        import matplotlib.pyplot as plt

        plt.show()
    else:
        print(args.output)
    import matplotlib.pyplot as plt

    plt.close(fig)
    return 0


def _run_sample_path(argv: list) -> int:
    parser = _build_sample_path_parser()
    args = parser.parse_args(argv)
    samples_root = _samples_root()
    print(samples_root / ('123000X78.CDF' if args.kind == 'cdf' else '123000X78.geq'))
    return 0


def _run_validate(argv: list) -> int:
    parser = _build_validate_parser()
    args = parser.parse_args(argv)

    validation = validate_sample_case(output_path=args.out)
    for key, passed in validation['checks'].items():
        metric_name, quantity = VALIDATION_FIELDS[key]
        metric = validation['metrics'][metric_name]
        value = metric[quantity]
        limit = validation['limits'][key]
        status = 'OK' if passed else 'FAILED'
        print(f'{status:<7} {key:<16} value={value:.6g} limit={limit:.6g}')

    if args.plot is not None or args.show:
        fig, _ = plot_geqdsk_visual_comparison(
            validation['output_path'],
            validation['reference_path'],
            label_a='generated',
            label_b='bundled reference',
            save_path=args.plot,
        )
        if args.show:
            import matplotlib.pyplot as plt

            plt.show()
        import matplotlib.pyplot as plt

        plt.close(fig)

    if validation['ok']:
        print(f"OK: {validation['output_path']}")
        return 0
    print(f"FAILED: {validation['output_path']}")
    return 1


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] in ADVANCED_COMMANDS:
        command = argv.pop(0)
        if command == 'compare':
            return _run_compare(argv)
        if command == 'validate':
            return _run_validate(argv)
        return _run_sample_path(argv)
    return _run_convert(argv)


if __name__ == '__main__':
    raise SystemExit(main())
