"""

Read and write single-time G-EQDSK equilibria.

This module is the canonical G-EQDSK file API in this repository. Tree/server
equilibrium readers may use related signal names, but they are not parsed
G-EQDSK files until converted through this schema and written with write().

Format of G-EQDSK file is specified here:
  https://fusion.gat.com/THEORY/efit/g_eqdsk.html

Acknowledgement:
Inspiration and copy-paste from:
https://github.com/bendudson/pyTokamak/blob/master/tokamak/formats/geqdsk.py
https://eqtools.readthedocs.io/en/latest/_modules/eqtools/filewriter.html

"""

import re
import time

import matplotlib.pyplot as plt
import numpy as np
import scipy.interpolate as spi
from contourpy import contour_generator

try:
    from scipy.integrate import cumtrapz
except ImportError:
    from scipy.integrate import cumulative_trapezoid as cumtrapz


def read(f):
    """Read a single-time G-EQDSK file into the canonical repository dict.

    f = Input file. Can either be a file-like object,or a string.
        If a string, then treated as a file name and opened.
    """

    # generator to read numbers
    read_number = get_generator(f)

    # Read arrays
    def read_array(n):
        d = np.zeros([n])
        for j in np.arange(n):
            d[j] = float(next(read_number))
        return d

    def read_2d(nx, ny):
        d = np.zeros([nx, ny])
        for j in np.arange(nx):
            d[j, :] = read_array(ny)
        return d

    if isinstance(f, str):
        # If the input is a string, treat as file name
        with open(f) as fh:  # Ensure file is closed
            return read(fh)  # Call again with file object

    # Read the first line, which should contain the mesh sizes
    desc = f.readline()
    if not desc:
        raise OSError("Cannot read from input file")

    s = desc.split()  # Split by whitespace
    if len(s) < 3:
        raise OSError("First line must contain at least 3 numbers")

    nw = int(s[-2])
    nh = int(s[-1])

    xdim, zdim, rcentr, rgrid1, zmid = read_array(5)
    rmagx, zmagx, ssimag, ssibry, bcentr = read_array(5)
    cpasma, ssimag, xdum, rmagx, xdum = read_array(5)
    zmagx, xdum, ssibry, xdum, xdum = read_array(5)

    fpol = read_array(nw)
    pres = read_array(nw)
    ffprim = read_array(nw)
    pprime = read_array(nw)
    psirz = read_2d(nh, nw)
    qpsi = read_array(nw)

    # Read boundary and limiters, if present
    nbdry = int(next(read_number))
    nlim = int(next(read_number))

    if nbdry > 0:
        rbdry = np.zeros([nbdry])
        zbdry = np.zeros([nbdry])
        for i in range(nbdry):
            rbdry[i] = float(next(read_number))
            zbdry[i] = float(next(read_number))

        ii = np.argmin(zbdry)
        zxpl = zbdry[ii]
        rxpl = rbdry[ii]
        ii = np.argmax(zbdry)
        zxpu = zbdry[ii]
        rxpu = rbdry[ii]
    else:
        rbdry = [0]
        zbdry = [0]

    if nlim > 0:
        xlim = np.zeros([nlim])
        ylim = np.zeros([nlim])
        for i in range(nlim):
            xlim[i] = float(next(read_number))
            ylim[i] = float(next(read_number))
    else:
        xlim = [0]
        ylim = [0]

    # Construct R-Z mesh
    r = np.zeros(nw)
    z = np.zeros(nh)
    for i in range(nw):
        r[i] = rgrid1 + xdim * i / float(nw - 1)
    for j in range(nh):
        z[j] = (zmid - 0.5 * zdim) + zdim * j / float(nh - 1)

    rhorz = np.sqrt(np.clip((psirz - ssimag) / (ssibry - ssimag), 0, 1e5))
    psin = np.linspace(0, 1, qpsi.size)

    # Create dictionary of values to return
    result = {
        "mw": nw,
        "mh": nh,  # Number of horizontal and vertical points
        "r": r,
        "z": z,  # Location of the grid-poinst
        "rdim": xdim,
        "zdim": zdim,  # Size of the domain in meters
        "rcentr": rcentr,
        "bcentr": bcentr,  # Reference vacuum toroidal field (m, T)
        "rgrid1": rgrid1,  # R of left side of domain
        "zmid": zmid,  # Z at the middle of the domain
        "rmagx": rmagx,
        "zmagx": zmagx,  # Location of magnetic axis
        "ssimag": ssimag,  # Poloidal flux at the axis (Weber / rad)
        "ssibry": ssibry,  # Poloidal flux at plasma boundary (Weber / rad)
        "cpasma": cpasma,
        "psirz": psirz,  # Poloidal flux in Weber/rad on grid points
        "rhorz": rhorz,  # normalizer poloidal flux
        "fpol": fpol,  # Poloidal current function on uniform flux grid
        "pres": pres,  # Plasma pressure in nt/m^2 on uniform flux grid
        "ffprim": ffprim,  # ffprim
        "pprime": pprime,  # ffprim
        "qpsi": qpsi,  # q values on uniform flux grid
        "psin": psin,  # normalized poloidal flux
        "rhotor": psin_to_rhotor_from_q(psin, qpsi),
        "nbdry": nbdry,
        "rbdry": rbdry,
        "zbdry": zbdry,  # Plasma boundary
        "nlim": nlim,
        "xlim": xlim,
        "ylim": ylim,
        "rxpl": rxpl,
        "zxpl": zxpl,
        "rxpu": rxpu,
        "zxpu": zxpu,
    }  # Wall boundary

    return result


def write(f, eq, shot=55555, stin="50000", title="ASALMI"):
    """Write a G-EQDSK file"""

    if isinstance(f, str):
        # If the input is a string, treat as file name
        with open(f, "w") as fh:  # Ensure file is closed
            return write(
                fh, eq, shot=shot, stin=stin, title=title
            )  # Call again with file object

    nx = int(eq["mw"])
    ny = int(eq["mh"])

    # Write header description
    tunit = "ms"
    header = (
        title
        + (11 - len(title)) * " "
        + time.strftime("%m/%d/%Y")
        + "   "
        + str(shot)
        + " "
        + stin
        + tunit
    )
    header = header + (51 - len(header)) * " " + "3 " + str(nx) + " " + str(ny) + "\n"

    f.write(header)

    f.write(_fmt([eq["rdim"], eq["zdim"], eq["rcentr"], eq["rgrid1"], eq["zmid"]]))
    f.write(_fmt([eq["rmagx"], eq["zmagx"], eq["ssimag"], eq["ssibry"], eq["bcentr"]]))
    f.write(_fmt([eq["cpasma"], eq["ssimag"], 0.0, eq["rmagx"], 0.0]))
    f.write(_fmt([eq["zmagx"], 0.0, eq["ssibry"], 0.0, 0.0]))

    # Write the arrays
    f.write(_fmt(eq["fpol"].ravel()))
    f.write(_fmt(eq["pres"].ravel()))
    f.write(_fmt(eq["ffprim"].ravel()))
    f.write(_fmt(eq["pprime"].ravel()))
    f.write(_fmt(eq["psirz"].ravel()))
    f.write(_fmt(eq["qpsi"].ravel()))

    # limiter + boundary
    f.write("  " + str(eq["nbdry"]) + "  " + str(eq["nlim"]) + "\n")
    tmp = np.stack((eq["rbdry"], eq["zbdry"]))
    f.write(_fmt(tmp.T.ravel()))
    tmp = np.stack((eq["xlim"], eq["ylim"]))
    f.write(_fmt(tmp.T.ravel()))


def _fmt(val):
    """eq formatter for gfiles,"""
    try:
        temp = f"0{float(val) * 10: 0.8E}"
        out = "".join([temp[1], temp[0], temp[3], temp[2], temp[4:]])
    except TypeError:
        out = ""
        idx = 0
        for i in val:
            out += _fmt(i)
            idx += 1
            if idx == 5:
                out += "\n"
                idx = 0
        if idx != 0:
            out += "\n"
    return out


def get_generator(fp):
    """Generator to get numbers from a text file"""
    while True:
        line = fp.readline()
        if not line:
            break
        # Match numbers in the line using regular expression
        pattern = r"[+-]?\d*[\.]?\d+(?:[Ee][+-]?\d+)?"
        toklist = re.findall(pattern, line)
        yield from toklist


def rhotor_to_psin(eq, rhotor):
    """map user given rhotor to normalized psi poloidal"""
    q = eq["qpsi"]
    cum = cumtrapz(y=q, x=eq["psin"], initial=0)
    rhotor_vec = np.sqrt(cum / cum[-1])
    return spi.pchip_interpolate(rhotor_vec, eq["psin"], rhotor)


def psin_to_rhotor(eq, psin):
    """map normalized psi poloidal to rhotor"""
    q = eq["qpsi"]
    cum = cumtrapz(y=q, x=eq["psin"], initial=0)
    rhotor_vec = np.sqrt(cum / cum[-1])
    return spi.pchip_interpolate(eq["psin"], rhotor_vec, psin)


def psin_to_rhotor_from_q(psin, q):
    """Map psin to rhotor given psin and q arrays"""
    cum = cumtrapz(q, psin, initial=0)
    return np.sqrt(cum / cum[-1])


def plot(
    eq,
    color="k",
    rho=None,
    ax=None,
    plot_bdry=True,
    plot_lim=True,
    bdry_color="r",
    lim_color="b",
):
    if rho is None:
        rho = np.linspace(0.1, 1.05, 20)

    if isinstance(eq, str):
        eq = read(eq)

    psi_norm = (eq["psirz"] - eq["ssimag"]) / (eq["ssibry"] - eq["ssimag"])
    rhorz = np.sqrt(psi_norm)

    rr = np.linspace(eq["r"][0], eq["r"][-1], 250)
    zz = np.linspace(eq["z"][0], eq["z"][-1], 301)

    if ax is None:
        fig, ax = plt.subplots(1, 1, figsize=(7, 14))

    fun = spi.RectBivariateSpline(eq["z"], eq["r"], rhorz)
    ax.contour(rr, zz, fun(zz, rr), levels=rho, colors=color)

    if plot_bdry:
        ax.plot(eq["rbdry"], eq["zbdry"], "--", color=bdry_color)
    if plot_lim:
        ax.plot(eq["xlim"], eq["ylim"], color=lim_color)

    # return proxy Line for legend
    return plt.Line2D([], [], color=color)


def flux_surf_average(eq, psin):
    """Calculate FSA quantities <grad(psin)>, <|grad(psin)|**2>

    Args:
        eq (dict): g-eqdsk equilibrium for one time only
        psin (array): psin surfaces at which the FSA is requested
    """

    # try:
    #     psinrz = spi.RectBivariateSpline(
    #         eq["z"], eq["r"], eq["rhorz"] ** 2, kx=3, ky=3, s=0
    #     )
    # except ValueError:
    #     eq["rhorz"] = eq["rhorz"].T
    #     print("Transposing eqdsk rhorz to make it (z,r)")
    psinrz = spi.RectBivariateSpline(
        eq["z"], eq["r"], eq["rhorz"] ** 2, kx=3, ky=3, s=0
    )

    print("Contour ----------- above")
    g1, g2 = np.zeros_like(psin), np.zeros_like(psin)
    for i, x in enumerate(psin):
        r, z = get_contour(eq, rhopol=np.sqrt(x))

        # plt.plot(r, z, "k--")

        if r.size == 0:  # can be empty near axis
            continue

        dl = np.sqrt(np.diff(r) ** 2 + np.diff(z) ** 2)
        rr, zz = 0.5 * (r[1:] + r[:-1]), 0.5 * (z[1:] + z[:-1])

        # plt.plot(r, z, "k--")
        dpx = psinrz.ev(zz, rr, dx=1)
        dpy = psinrz.ev(zz, rr, dy=1)

        bpol_au = np.sqrt(dpx**2 + dpy**2) / rr

        dl_per_bp = dl / bpol_au
        norm = np.sum(dl_per_bp)

        g2_rz = dpx**2 + dpy**2
        g1_rz = np.sqrt(g2_rz)

        g1[i] = np.sum(dl_per_bp * g1_rz) / norm
        g2[i] = np.sum(dl_per_bp * g2_rz) / norm

    return g1, g2


def get_contour(eq, rhopol=0.95, pfr=False):
    """get flux surface r,z coordinates for the given rho.

    Args:
        eq (dict): efit equilibrium as returned by the above read() routine
        rhopol (float): rhopol surface at which the contour is requested
        pfr (boolean): rho surface at which the contour is requested
    Returns:
        r,z (array): location arrays with r[0] == r[-1] if closing on itself

    """

    # use hires data for better quality contours (abs err<2e-5)
    # rr = np.linspace(eq["r"].min(), eq["r"].max(), 250)
    # zz = np.linspace(eq["z"].min(), eq["z"].max(), 300)
    # x, y = np.meshgrid(rr, zz)

    # f = spi.RectBivariateSpline(eq["z"], eq["r"], eq["rhorz"])

    # z = np.asarray(f(zz, rr), dtype=np.float64)

    x, y = np.meshgrid(eq["r"], eq["z"])
    # x, y = np.meshgrid(eq["z"], eq["r"])  # for jet eq.. also ok for 201x201 west
    z = eq["rhorz"]
    # print(x.shape, z.shape)
    cg = contour_generator(x, y, z)
    vertices = cg.create_contour(rhopol)

    # from scipy.ndimage import zoom

    # # zoom factor: 2–4 gives good smoothness, higher = slower
    # zoom_factor = 3

    # z_fine = zoom(eq["rhorz"], zoom=zoom_factor, order=3)  # cubic spline
    # r_fine = zoom(eq["r"], zoom=zoom_factor, order=1)
    # zgrid_fine = zoom(eq["z"], zoom=zoom_factor, order=1)

    # x_fine, y_fine = np.meshgrid(r_fine, zgrid_fine)
    # cg = contour_generator(x_fine, y_fine, z_fine)
    # vertices = cg.create_contour(rhopol)

    longest = None
    maxlen = 0.0

    for line in vertices:
        r, z = line.T[0], line.T[1]
        closed = r[0] == r[-1] and z[0] == z[-1]

        if rhopol < 1:
            if closed:
                return r, z
            if pfr and np.all(z < eq["zxpl"]):
                return r, z
        else:
            # candidate for longest open contour
            length = np.sum(np.hypot(np.diff(r), np.diff(z)))
            if length > maxlen:
                maxlen = length
                longest = (r, z)

    # if rhopol > 1 and no closed found: return longest open
    if longest:
        return longest
    return np.array([]), np.array([])
