from __future__ import annotations

import os
import shutil
import stat
import subprocess
import sys
from pathlib import Path

import numpy as np

from eqdsk_from_cdf import eqdsk
from eqdsk_from_cdf.converter import compare_geqdsk_files, validate_sample_case, write_geqdsk_from_transp

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib

ROOT = Path(__file__).resolve().parents[1]
SAMPLE_CDF = ROOT / "samples" / "123000X78.CDF"
REFERENCE_GEQ = ROOT / "samples" / "123000X78.geq"


def run_cli(*args: str, cwd: Path = None) -> subprocess.CompletedProcess:
    env = os.environ.copy()
    env["PYTHONPATH"] = str(ROOT / "src")
    return subprocess.run(
        [sys.executable, "-m", "eqdsk_from_cdf.cli", *args],
        cwd=cwd or ROOT,
        env=env,
        text=True,
        capture_output=True,
        check=False,
    )


def test_cli_help_works() -> None:
    result = run_cli("--help")
    assert result.returncode == 0
    assert "Convert one TRANSP CDF equilibrium time slice to a G-EQDSK file." in result.stdout
    assert "Viewed from above (+Z), +1 = counter-clockwise and -1 = clockwise." in result.stdout


def test_contourpy_is_declared_as_direct_dependency() -> None:
    pyproject = tomllib.loads((ROOT / "pyproject.toml").read_text())
    dependencies = pyproject["project"]["dependencies"]

    assert any(dependency.split(">=", maxsplit=1)[0] == "contourpy" for dependency in dependencies)


def test_cli_default_output_path(tmp_path: Path) -> None:
    cdf_path = tmp_path / "123000X78.CDF"
    shutil.copy2(SAMPLE_CDF, cdf_path)

    result = run_cli(
        str(cdf_path),
        "--time",
        "17.50435",
        "--bt-sign",
        "1",
        "--ip-sign",
        "1",
    )

    output = tmp_path / "123000X78.geq"
    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == str(output)
    assert output.exists()

    written = eqdsk.read(str(output))
    assert written["mw"] == 129
    assert written["mh"] == 129


def test_cli_refuses_overwriting_bundled_sample_reference() -> None:
    result = run_cli(
        str(SAMPLE_CDF),
        "--time",
        "17.5",
        "--bt-sign",
        "1",
        "--ip-sign",
        "1",
    )

    assert result.returncode != 0
    assert "refusing to overwrite the bundled sample GEQ" in result.stderr


def test_cli_explicit_output_path(tmp_path: Path) -> None:
    output = tmp_path / "custom.geq"
    result = run_cli(
        str(SAMPLE_CDF),
        "--out",
        str(output),
        "--time",
        "17.50435",
        "--bt-sign",
        "1",
        "--ip-sign",
        "1",
    )

    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == str(output)
    assert output.exists()


def test_cli_custom_grid_size(tmp_path: Path) -> None:
    output = tmp_path / "grid.geq"
    result = run_cli(
        str(SAMPLE_CDF),
        "--out",
        str(output),
        "--time",
        "17.50435",
        "--bt-sign",
        "1",
        "--ip-sign",
        "1",
        "--nr",
        "64",
        "--nz",
        "96",
    )

    assert result.returncode == 0, result.stderr
    written = eqdsk.read(str(output))
    assert written["mw"] == 64
    assert written["mh"] == 96


def test_cli_plot_output(tmp_path: Path) -> None:
    output = tmp_path / "plot.geq"
    plot_path = tmp_path / "plot.png"
    result = run_cli(
        str(SAMPLE_CDF),
        "--out",
        str(output),
        "--time",
        "17.50435",
        "--bt-sign",
        "1",
        "--ip-sign",
        "1",
        "--plot",
        str(plot_path),
    )

    assert result.returncode == 0, result.stderr
    assert output.exists()
    assert plot_path.exists()


def test_cli_invalid_sign_fails_clearly() -> None:
    result = run_cli(
        str(SAMPLE_CDF),
        "--time",
        "17.50435",
        "--bt-sign",
        "0",
        "--ip-sign",
        "1",
    )

    assert result.returncode != 0
    assert "must be -1 or 1" in result.stderr


def test_cli_validate_succeeds(tmp_path: Path) -> None:
    output = tmp_path / "validated.geq"
    plot_path = tmp_path / "validated.png"
    result = run_cli("validate", "--out", str(output), "--plot", str(plot_path))

    assert result.returncode == 0, result.stderr
    assert "OK:" in result.stdout
    assert output.exists()
    assert plot_path.exists()


def test_install_check_succeeds_with_command_on_path(tmp_path: Path) -> None:
    bin_dir = tmp_path / "bin"
    bin_dir.mkdir()
    wrapper = bin_dir / "eqdsk-from-cdf"
    wrapper.write_text(
        "#!/usr/bin/env bash\n"
        f"cd {ROOT}\n"
        f"PYTHONPATH={ROOT / 'src'} exec {sys.executable} -m eqdsk_from_cdf.cli \"$@\"\n"
    )
    wrapper.chmod(wrapper.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    env = os.environ.copy()
    env["PATH"] = f"{bin_dir}:{env['PATH']}"

    result = subprocess.run(
        ["bash", str(ROOT / "install.sh"), "--check"],
        cwd=ROOT,
        env=env,
        text=True,
        capture_output=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr
    assert "OK:" in result.stdout
    assert str(wrapper) in result.stdout


def test_write_sample_geqdsk(tmp_path: Path) -> None:
    output = tmp_path / "sample.geq"
    write_geqdsk_from_transp(
        output,
        SAMPLE_CDF,
        17.50435,
        avg_time=0.0,
        bt_sign=1,
        ip_sign=1,
    )
    metrics = compare_geqdsk_files(output, REFERENCE_GEQ)
    assert metrics["fpol"]["rel_rms"] < 1.0e-5
    assert metrics["pres"]["rel_rms"] < 1.0e-4
    assert metrics["qpsi"]["rel_rms"] < 5.0e-3
    assert metrics["psirz"]["rel_rms"] < 8.0e-2

    written = eqdsk.read(str(output))
    assert written["rbdry"].max() > 1.0
    assert written["xlim"].max() > 1.0
    assert np.isfinite(written["psirz"]).all()
    assert written["psirz"].max() > written["ssibry"]
    with output.open() as handle:
        header = handle.readline()
    assert "123000X78" in header
    assert "123000" in header
    assert "17504ms" in header


def test_public_sample_validation_helper(tmp_path: Path) -> None:
    output = tmp_path / "helper.geq"
    validation = validate_sample_case(output)

    assert validation["ok"]
    assert validation["output_path"] == output
    assert output.exists()
    for metric in validation["metrics"].values():
        if metric["status"] != "ok":
            continue
        assert metric["abs_max"] == 0.0
        assert metric["rms"] == 0.0
        assert metric["rel_rms"] == 0.0


def test_regular_conversion_matches_validate_path(tmp_path: Path) -> None:
    regular = tmp_path / "regular.geq"
    validated = tmp_path / "validated.geq"

    write_geqdsk_from_transp(
        regular,
        SAMPLE_CDF,
        17.5,
        bt_sign=1,
        ip_sign=1,
    )
    validation = validate_sample_case(validated)
    metrics = compare_geqdsk_files(regular, validated)

    assert validation["ok"]
    for metric in metrics.values():
        if metric["status"] != "ok":
            continue
        assert metric["abs_max"] == 0.0
        assert metric["rms"] == 0.0
        assert metric["rel_rms"] == 0.0


def test_validate_refuses_reference_output_path() -> None:
    try:
        validate_sample_case(REFERENCE_GEQ)
    except ValueError as exc:
        assert "must differ" in str(exc)
    else:
        raise AssertionError("validate_sample_case should refuse using the bundled reference path as output")
