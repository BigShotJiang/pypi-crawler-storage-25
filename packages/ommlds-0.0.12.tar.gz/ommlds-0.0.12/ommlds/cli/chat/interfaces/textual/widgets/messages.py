import abc
import asyncio
import io
import typing as ta
import uuid

from omdev.tui import textual as tx
from omlish import check
from omlish import dataclasses as dc
from omlish import lang
from omlish.logs import all as logs


log, alog = logs.get_module_loggers(globals())


##


@dc.dataclass()
class MessageDividerClicked(tx.Event):
    event: tx.Click


class MessageDivider(
    tx.InitAddClass,
    tx.Static,
):
    init_add_class = 'message-divider'

    def __init__(
            self,
            *,
            left_text: str | None = None,
            center_text: str | None = None,
            right_text: str | None = None,
            line_style: ta.Any | None = None,
            text_style: ta.Any | None = None,
    ) -> None:
        super().__init__()

        self._left_text = left_text
        self._center_text = center_text
        self._right_text = right_text
        self._line_style = line_style
        self._text_style = text_style

        self._refresh()

    @classmethod
    def for_message(cls, msg: Message) -> MessageDivider:
        return cls(
            center_text=lang.localnow().strftime('%Y-%m-%d %H:%M:%S'),
            right_text=str(mu) if (mu := msg.message_uuid) is not None else None,
        )

    def on_click(self, event: tx.Click) -> None:
        if event.button != 1:
            return

        event.stop()

        self.post_message(MessageDividerClicked(event))

    def _refresh(self) -> None:
        if (text_style := self._text_style) is None:
            text_style = tx.RichStyle(color=self.rich_style.color)

        def make_text(s):
            return tx.Text(s, style=text_style) if s else ''  # noqa

        if (line_style := self._line_style) is None:
            line_style = tx.RichStyle(color=self.app.current_theme.primary)

        self.update(
            tx.RichTriRule(
                left=make_text(self._left_text),
                center=make_text(self._center_text),
                right=make_text(self._right_text),
                style=line_style,
                left_pad=1,
                right_pad=1,
            ),
        )


##


@dc.dataclass()
class MessageFinalized(tx.Event):
    widget: tx.Widget


class OnMountMessageFinalized(
    tx.Widget,
    lang.Abstract,
):
    __has_finalized = False

    @tx.on(tx.Mount)
    async def _on_mount_message_finalize(self, event: tx.Mount) -> None:
        if not self.__has_finalized:
            self.__has_finalized = True

            self.post_message(MessageFinalized(self))


##


class Message(
    tx.InitAddClass,
    tx.Static,
    lang.Abstract,
):
    init_add_class = 'message'

    def __init__(
            self,
            *,
            message_uuid: uuid.UUID | None = None,
            **kwargs: ta.Any,
    ) -> None:
        super().__init__(**kwargs)

        self._message_uuid = message_uuid

    @property
    @abc.abstractmethod
    def message_content(self) -> ta.Any | None:
        raise NotImplementedError

    @property
    def message_uuid(self) -> uuid.UUID | None:
        return self._message_uuid

    @tx.on(MessageDividerClicked)
    async def _on_message_divider_clicked(self, event: MessageDividerClicked) -> None:
        event.stop()

        content = self.message_content
        if content is None:
            return

        def handle_action(action: ta.Any | None) -> None:
            match action:
                case 'copy':
                    content  # noqa

                case _:
                    pass

        self.app.push_screen(
            tx.ActionMenuScreen(
                (event.event.screen_x, event.event.screen_y),
                [
                    ('Copy', 'copy'),
                ],
            ),
            handle_action,
        )


#


class StaticMessage(
    OnMountMessageFinalized,
    Message,
    lang.Abstract,
):
    pass


#


StreamMessageState: ta.TypeAlias = ta.Literal[  # noqa
    'new',
    'new_finalizing',
    'streaming',
    'finalized',
]


@dc.dataclass(frozen=True)
class StreamMessagePart(lang.Abstract):
    message_cls: type[StreamMessage]
    message_uuid: uuid.UUID


@dc.dataclass(frozen=True)
class ContentStreamMessagePart(StreamMessagePart):
    content: str


@dc.dataclass(frozen=True)
class FinalStreamMessagePart(StreamMessagePart):
    pass


class StreamMessage(Message, lang.Abstract):
    def __init__(
            self,
            *initial_contents: str,
            message_uuid: uuid.UUID | None = None,
    ) -> None:
        super().__init__(
            message_uuid=message_uuid,
        )

        self._initial_contents: list[str] = list(initial_contents)

        self._state: StreamMessageState = 'new'

    @property
    def state(self) -> StreamMessageState:
        return self._state

    #

    @property
    def message_content(self) -> ta.Any | None:
        match self._state:
            case 'new':
                return None
            case 'finalized':
                return self._final_content
            case _:
                return self._stream_content.getvalue()

    #

    _final_content: str

    @property
    def final_content(self) -> str:
        check.state(self._state == 'finalized')
        return self._final_content

    #

    _stream_content: io.StringIO

    @ta.final
    async def start_stream(self) -> None:
        check.state(self._state in ('new', 'new_finalizing'))

        self._stream_content = io.StringIO()

        await self._start_stream_content()

        if (ics := self._initial_contents):
            for ic in ics:
                self._stream_content.write(ic)
                await self._append_stream_content(ic)

        del self._initial_contents

        if self._state == 'new':
            self._state = 'streaming'

        elif self._state == 'new_finalizing':
            await self._finalize_stream()

        else:
            raise RuntimeError(f'unexpected state: {self._state}')

    @abc.abstractmethod
    async def _start_stream_content(self) -> None:
        raise NotImplementedError

    async def append_stream_content(self, content: str) -> None:
        if not content:
            return

        if self._state == 'new':
            self._initial_contents.append(content)

        elif self._state == 'streaming':
            self._stream_content.write(content)
            await self._append_stream_content(content)

        else:
            raise RuntimeError(f'unexpected state: {self._state}')

    @abc.abstractmethod
    async def _append_stream_content(self, c: str) -> None:
        raise NotImplementedError

    async def _finalize_stream(self) -> None:
        await self._finalize_stream_content()

        self._final_content = self._stream_content.getvalue()
        del self._stream_content

        self._state = 'finalized'

        self.post_message(MessageFinalized(self))

    @abc.abstractmethod
    async def _finalize_stream_content(self) -> None:
        raise NotImplementedError

    async def finalize_stream(self) -> None:
        if self._state == 'new':
            self._state = 'new_finalizing'

        elif self._state == 'streaming':
            await self._finalize_stream()

        else:
            raise RuntimeError(f'unexpected state: {self._state}')


#


class MarkdownStreamMessage(StreamMessage, lang.Abstract):
    _stream: tx.MarkdownStream

    async def _start_stream_content(self) -> None:
        self._stream = tx.Markdown.get_stream(self.query_one(tx.Markdown))

    async def _append_stream_content(self, c: str) -> None:
        await self._stream.write(c)

    async def _finalize_stream_content(self) -> None:
        await self._stream.stop()
        del self._stream


##


class WelcomeMessage(StaticMessage):
    init_add_class = 'welcome-message'

    def __init__(
            self,
            content: tx.VisualType,
            *,
            message_uuid: uuid.UUID | None = None,
    ) -> None:
        super().__init__(
            message_uuid=message_uuid,
        )

        self._content = content

    @property
    def message_content(self) -> ta.Any | None:
        return self._content

    def compose(self) -> tx.ComposeResult:
        with tx.Vertical(classes='welcome-message-outer message-outer'):
            yield tx.Static(self._content, classes='welcome-message-content')


##


class UserMessage(StaticMessage):
    init_add_class = 'user-message'

    def __init__(
            self,
            content: tx.VisualType,
            *,
            message_uuid: uuid.UUID | None = None,
    ) -> None:
        super().__init__(
            message_uuid=message_uuid,
        )

        self._content = content

    @property
    def message_content(self) -> ta.Any | None:
        return self._content

    def compose(self) -> tx.ComposeResult:
        with tx.Vertical(classes='user-message-divider-container message-divider-container'):
            yield MessageDivider.for_message(self)

            with tx.Horizontal(classes='user-message-outer message-outer'):
                yield tx.Static('> ', classes='user-message-glyph message-glyph')
                with tx.Vertical(classes='user-message-inner message-inner'):
                    yield tx.Static(self._content)


##


class AiMessage(Message, lang.Abstract):
    init_add_class = 'ai-message'

    def compose(self) -> tx.ComposeResult:
        with tx.Vertical(classes='ai-message-divider-container message-divider-container'):
            yield MessageDivider.for_message(self)

            with tx.Horizontal(classes='ai-message-outer message-outer'):
                yield tx.Static('< ', classes='ai-message-glyph message-glyph')
                with tx.Vertical(classes='ai-message-inner message-inner'):
                    yield from self._compose_content()

    @abc.abstractmethod
    def _compose_content(self) -> ta.Generator:
        raise NotImplementedError


##


class StaticAiMessage(StaticMessage, AiMessage):
    init_add_class = 'static-ai-message'

    def __init__(
            self,
            content: str,
            *,
            markdown: bool = False,
            message_uuid: uuid.UUID | None = None,
    ) -> None:
        super().__init__(
            message_uuid=message_uuid,
        )

        self._content = content
        self._markdown = markdown

    @property
    def message_content(self) -> ta.Any | None:
        return self._content

    def _compose_content(self) -> ta.Generator:
        if self._markdown:
            yield tx.Markdown(self._content)
        else:
            yield tx.Static(self._content)


##


class StreamAiMessage(AiMessage, MarkdownStreamMessage):
    init_add_class = 'stream-ai-message'

    def _compose_content(self) -> ta.Generator:
        yield tx.Markdown('')


##


class ToolConfirmationControls(
    tx.InitAddClass,
    tx.Static,
):
    init_add_class = 'tool-confirmation-controls'

    class ClickedAllow(tx.Message):
        pass

    class ClickedDeny(tx.Message):
        pass

    def compose(self) -> tx.ComposeResult:
        yield tx.Button('Allow (F10)', action='allow')
        yield tx.Button('Deny (F2)', action='deny')

    def action_allow(self) -> None:
        self.post_message(self.ClickedAllow())

    def action_deny(self) -> None:
        self.post_message(self.ClickedDeny())


class ToolConfirmationMessage(Message):
    init_add_class = 'tool-confirmation-message'

    def __init__(
            self,
            outer_content: tx.VisualType,
            inner_content: tx.VisualType,
            fut: asyncio.Future[bool],
            *,
            message_uuid: uuid.UUID | None = None,
    ) -> None:
        super().__init__(
            message_uuid=message_uuid,
        )

        self._outer_content = outer_content
        self._inner_content = inner_content
        self._fut = fut

        self._has_rendered = False
        self._has_responded = False

    @property
    def message_content(self) -> None:
        return None

    @property
    def has_rendered(self) -> bool:
        return self._has_rendered

    @property
    def has_responded(self) -> bool:
        return self._has_responded

    async def respond(self, allowed: bool) -> None:
        check.equal(self._fut.done(), self._has_responded)

        if self._has_responded:
            return
        self._has_responded = True

        inner = self.query_one('.tool-confirmation-message-inner')

        await inner.query_one(ToolConfirmationControls).remove()

        inner.remove_class('tool-confirmation-message-inner-open')
        inner.add_class('tool-confirmation-message-inner-closed')

        inner.query_one('.tool-confirmation-message-outer-content', tx.Static).update(
            f'Tool use {"allowed" if allowed else "denied"}.',
        )

        self._fut.set_result(allowed)

        self.post_message(MessageFinalized(self))

    def compose(self) -> tx.ComposeResult:
        with tx.Vertical(classes='tool-confirmation-message-divider-container message-divider-container'):
            yield MessageDivider.for_message(self)

            with tx.Horizontal(classes='tool-confirmation-message-outer message-outer'):
                yield tx.Static('? ', classes='tool-confirmation-message-glyph message-glyph')
                with tx.Vertical(classes=' '.join([
                    'tool-confirmation-message-inner',
                    'tool-confirmation-message-inner-open',
                    'message-inner',
                ])):
                    yield tx.Static(self._outer_content, classes='tool-confirmation-message-outer-content')
                    yield tx.Static(self._inner_content, classes='tool-confirmation-message-inner-content')

                    yield ToolConfirmationControls(classes='tool-confirmation-message-controls')

    def on_mount(self) -> None:
        def inner():
            self._has_rendered = True

        self.call_after_refresh(inner)

    @tx.on(ToolConfirmationControls.ClickedAllow)
    async def on_clicked_allow(self, event: ToolConfirmationControls.ClickedAllow) -> None:
        await self.respond(True)

    @tx.on(ToolConfirmationControls.ClickedDeny)
    async def on_clicked_deny(self, event: ToolConfirmationControls.ClickedDeny) -> None:
        await self.respond(False)


##


class UiMessage(StaticMessage):
    init_add_class = 'ui-message'

    def __init__(
            self,
            content: tx.VisualType,
            *,
            message_uuid: uuid.UUID | None = None,
    ) -> None:
        super().__init__(
            message_uuid=message_uuid,
        )

        self._content = content

    @property
    def message_content(self) -> ta.Any | None:
        return self._content

    def compose(self) -> tx.ComposeResult:
        with tx.Vertical(classes='ui-message-divider-container message-divider-container'):
            yield MessageDivider.for_message(self)

            with tx.Horizontal(classes='ui-message-outer message-outer'):
                yield tx.Static('~ ', classes='ui-message-glyph message-glyph')
                with tx.Vertical(classes='ui-message-inner message-inner'):
                    yield tx.Static(self._content)


##


class MessagesContainer(
    tx.InitAddClass,
    tx.ComposeOnce,
    tx.VerticalScroll,
):
    init_add_class = 'messages-container'

    def __init__(self, init_messages: ta.Sequence[Message] | None = None) -> None:
        super().__init__()

        self._messages_by_uuid: dict[uuid.UUID, Message] = {}

        if init_messages:
            self._pending_mount_messages = list(init_messages)

    #

    def _compose_once(self) -> tx.ComposeResult:
        return
        yield  # noqa

    #

    def _is_messages_at_bottom(self, threshold: int = 3) -> bool:
        return self.scroll_y >= (self.max_scroll_y - threshold)

    def _scroll_messages_to_bottom(self) -> None:
        self.scroll_end(animate=False)

    def _anchor_messages(self) -> None:
        if self.max_scroll_y:
            self.anchor()

    def _scroll_messages_to_bottom_and_anchor(self) -> None:
        self._scroll_messages_to_bottom()
        self._anchor_messages()

    #

    _pending_mount_messages: list[Message] | None = None

    async def enqueue_mount_messages(self, *messages: Message) -> None:
        if (lst := self._pending_mount_messages) is None:
            lst = self._pending_mount_messages = []

        lst.extend(messages)

    #

    async def append_stream_message_content(self, parts: ta.Sequence[StreamMessagePart]) -> None:
        mount_messages = False
        refresh = False
        scroll_to_bottom = False

        for part in parts:
            if isinstance(part, ContentStreamMessagePart):
                message_uuid = part.message_uuid
                content = part.content

                if (msg := self._messages_by_uuid.get(message_uuid)) is None:
                    aim = part.message_cls(content, message_uuid=message_uuid)

                    self._messages_by_uuid[message_uuid] = aim

                    await self.enqueue_mount_messages(aim)

                    mount_messages = True
                    refresh = True

                else:
                    aim = check.isinstance(msg, part.message_cls)

                    if aim.is_mounted:
                        scroll_to_bottom |= self._is_messages_at_bottom()

                    await aim.append_stream_content(content)

            elif isinstance(part, FinalStreamMessagePart):
                if (msg := self._messages_by_uuid.get(part.message_uuid)) is None:
                    continue

                aim = check.isinstance(msg, part.message_cls)

                await aim.finalize_stream()

            else:
                raise TypeError(part)

        if mount_messages:
            self.call_later(self.mount_messages)
        if scroll_to_bottom:
            self.call_after_refresh(self._scroll_messages_to_bottom_and_anchor)
        if refresh:
            self.refresh()

    #

    async def mount_messages(self, *messages: Message) -> None:
        was_at_bottom = self._is_messages_at_bottom()

        for msg in [*(self._pending_mount_messages or []), *messages]:
            if (mu := msg.message_uuid) is not None:
                try:
                    xm = self._messages_by_uuid[mu]
                except KeyError:
                    pass
                else:
                    if not (isinstance(msg, StreamMessage) and xm is msg):
                        raise ValueError(f'message uuid already in use: {mu}')

            await self.mount(msg)

            if mu is not None:
                self._messages_by_uuid[mu] = msg

            if isinstance(msg, StreamMessage):
                await msg.start_stream()

        self._pending_mount_messages = None

        self.call_after_refresh(self._scroll_messages_to_bottom)

        if was_at_bottom:
            self.call_after_refresh(self._anchor_messages)
