from omlish.__about__ import ProjectBase
from omlish.__about__ import SetuptoolsBase
from omlish.__about__ import __version__


class Project(ProjectBase):
    name = 'ommlds'
    description = 'ommlds'

    dependencies = [
        f'omlish == {__version__}',
    ]

    optional_dependencies = {
        'omdev': [
            f'omdev == {__version__}',
        ],

        #

        'backends': [
            # 'diffusers ~= 0.37',

            'llama-cpp-python ~= 0.3',

            'mlx ~= 0.31; sys_platform == "darwin"',
            'mlx-lm ~= 0.31; sys_platform == "darwin"',

            'sentencepiece ~= 0.2',

            'tiktoken ~= 0.12',

            # 'tinygrad @ git+https://github.com/tinygrad/tinygrad',
            'tinygrad ~= 0.12',

            'tokenizers ~= 0.22',

            'torch ~= 2.11',

            'transformers ~= 5.7',
            'sentence-transformers ~= 5.4',
        ],

        'huggingface': [
            'huggingface-hub ~= 1.13',
            'datasets ~= 4.8',
        ],

        'nanochat': [
            'regex >= 2026.4',
        ],

        'numpy': [
            'numpy >= 1.26',
        ],

        'ocr': [
            'pytesseract ~= 0.3',

            'rapidocr-onnxruntime ~= 1.4',
        ],

        'pillow': [
            'pillow ~= 12.2',
        ],

        'search': [
            'ddgs ~= 9.14',

            'tavily-python ~= 0.7',
        ],

        'wiki': [
            'mwparserfromhell ~= 0.7',

            'wikitextparser ~= 0.56',  # !! GPL
        ],

        'xml': [
            'lxml >= 6.1',
        ],
    }

    entry_points = {
        'omlish.manifests': {name: name},
    }


class Setuptools(SetuptoolsBase):
    rs = True

    find_packages = {
        'include': [Project.name, f'{Project.name}.*'],
        'exclude': [*SetuptoolsBase.find_packages['exclude']],
    }
