"""MCP server lookup for clients that expose MCP tools via PreToolUse.

Claude Code search order:
  1. ${cwd}/.mcp.json              — project-scoped servers
  2. ~/.claude.json projects[cwd]  — per-project servers in user state
  3. ~/.claude.json mcpServers     — global user-scoped servers

Codex search order mirrors runlayer-hook.sh:
  1. ~/.codex/config.toml
  2. ~/.codex/managed_config.toml
  3. /etc/codex/managed_config.toml
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Mapping, TypedDict, cast

if sys.version_info >= (3, 11):
    import tomllib
else:  # pragma: no cover - Python 3.10 fallback
    import tomli as tomllib


class MCPServer(TypedDict, total=False):
    url: str
    command: str


def lookup_mcp_server(server_name: str, cwd: str) -> MCPServer | None:
    """Resolve *server_name* to a URL or command string.

    Returns None if the server is not found in any config file.
    """
    project_mcp = Path(cwd) / ".mcp.json"
    result = _search_file(project_mcp, server_name)
    if result is not None:
        return result

    claude_json = Path.home() / ".claude.json"
    if claude_json.is_file():
        try:
            data = json.loads(claude_json.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return None

        project_servers = data.get("projects", {}).get(cwd, {}).get("mcpServers", {})
        result = _extract_server(project_servers, server_name)
        if result is not None:
            return result

        global_servers = data.get("mcpServers", {})
        result = _extract_server(global_servers, server_name)
        if result is not None:
            return result

    return None


def lookup_codex_mcp_server(server_name: str) -> MCPServer | None:
    """Resolve a Codex MCP server name from Codex TOML config files."""
    for path in _codex_mcp_config_paths():
        result = _search_codex_toml_file(path, server_name)
        if result is not None:
            return result
    return None


def lookup_cursor_mcp_server(
    server_name: str, payload: Mapping[str, Any]
) -> MCPServer | None:
    """Resolve a Cursor beforeMCPExecution server display name.

    Cursor can send only a server display name in ``command``. Mirror the
    shell hook by searching workspace .cursor/mcp.json files, then the global
    ~/.cursor/mcp.json, with Cursor's user- prefix and normalized-name fallback.
    """
    for path in _cursor_mcp_config_paths(payload):
        result = _search_cursor_file(path, server_name)
        if result is not None:
            return result
    return None


def resolve_cursor_before_mcp_payload(payload: dict[str, Any]) -> dict[str, Any]:
    """Return a Cursor MCP payload with display-name command resolved if found."""
    server_name = payload.get("command")
    if not isinstance(server_name, str) or not server_name or payload.get("url"):
        return payload

    server = lookup_cursor_mcp_server(server_name, payload)
    if server is None:
        return payload

    resolved = dict(payload)
    url = server.get("url")
    command = server.get("command")
    if url:
        resolved["url"] = url
        resolved.pop("command", None)
    elif command:
        resolved["command"] = command
        resolved.pop("url", None)
    return resolved


def _search_file(path: Path, server_name: str) -> MCPServer | None:
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
    return _extract_server(data.get("mcpServers", {}), server_name)


def _cursor_mcp_config_paths(payload: Mapping[str, Any]) -> list[Path]:
    paths: list[Path] = []
    seen: set[Path] = set()

    def add_path(root: object) -> None:
        if isinstance(root, str) and root:
            path = Path(root) / ".cursor" / "mcp.json"
            if path not in seen:
                seen.add(path)
                paths.append(path)

    workspace_roots = payload.get("workspace_roots")
    if isinstance(workspace_roots, list):
        for root in workspace_roots:
            add_path(root)
    add_path(payload.get("cwd"))

    home_path = Path.home() / ".cursor" / "mcp.json"
    if home_path not in seen:
        paths.append(home_path)
    return paths


def _codex_mcp_config_paths() -> tuple[Path, ...]:
    return (
        Path.home() / ".codex" / "config.toml",
        Path.home() / ".codex" / "managed_config.toml",
        Path("/etc/codex/managed_config.toml"),
    )


def _search_codex_toml_file(path: Path, server_name: str) -> MCPServer | None:
    if not path.is_file():
        return None
    try:
        with path.open("rb") as fb:
            data = tomllib.load(fb)
    except (OSError, tomllib.TOMLDecodeError):
        return None

    servers = data.get("mcp_servers", {})
    if not isinstance(servers, dict):
        return None

    result = _extract_server(servers, server_name)
    if result is not None:
        return result

    normalized_server_name = _normalized_name(server_name)
    for candidate_name in servers:
        if (
            isinstance(candidate_name, str)
            and _normalized_name(candidate_name) == normalized_server_name
        ):
            result = _extract_server(servers, candidate_name)
            if result is not None:
                return result
    return None


def _search_cursor_file(path: Path, server_name: str) -> MCPServer | None:
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None

    servers = data.get("mcpServers", {})
    if not isinstance(servers, dict):
        return None

    lookup_names = [server_name]
    if server_name.startswith("user-"):
        lookup_names.append(server_name.removeprefix("user-"))

    for lookup_name in lookup_names:
        result = _extract_server(servers, lookup_name)
        if result is not None:
            return result

    for lookup_name in lookup_names:
        normalized_lookup_name = _normalized_name(lookup_name)
        for candidate_name in servers:
            if (
                isinstance(candidate_name, str)
                and _normalized_name(candidate_name) == normalized_lookup_name
            ):
                result = _extract_server(servers, candidate_name)
                if result is not None:
                    return result

    return None


def _normalized_name(name: str) -> str:
    return "".join(ch for ch in name.lower() if ch.isalnum())


def _extract_server(servers: object, server_name: str) -> MCPServer | None:
    if not isinstance(servers, dict):
        return None
    servers_dict = cast(dict[str, Any], servers)
    entry = servers_dict.get(server_name)
    if not entry or not isinstance(entry, dict):
        return None
    # Different MCP clients spell the remote endpoint differently:
    #   url        — Claude Code, Cursor, .mcp.json spec
    #   serverUrl  — Windsurf
    #   uri        — Goose
    # Match the bash hook (runlayer-hook.sh) so Python and shell agree.
    url = entry.get("url") or entry.get("serverUrl") or entry.get("uri")
    if url:
        return MCPServer(url=str(url))
    command = entry.get("command")
    if command:
        args = entry.get("args", [])
        full = f"{command} {' '.join(str(a) for a in args)}".strip()
        return MCPServer(command=full)
    return None
