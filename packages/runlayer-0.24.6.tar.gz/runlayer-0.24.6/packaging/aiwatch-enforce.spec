# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec for the aiwatch-enforce frozen binary.

One-dir mode on purpose: same EDR rationale as aiwatch.spec — MDM-deployed
tools must not look like self-extracting droppers. `--onefile` writes dylibs
to $TMPDIR on every invocation, which triggers CrowdStrike/SentinelOne/Defender
ATP behavioral rules. `--onedir` installs once and every subsequent hook
invocation is an exec of an already-on-disk signed binary.

UPX is deliberately disabled — UPX-packed Mach-O/PE is a packer signal to
EDR behavioral rules and breaks macOS codesigning + notarization.

The hook closure is much smaller than aiwatch: no mcp/fastmcp/docker/anyio/
questionary. Only httpx + pyyaml + keyring for credential resolution.

Build:
  macOS (host arch):  pyinstaller packaging/aiwatch-enforce.spec
  Windows x64:        pyinstaller packaging/aiwatch-enforce.spec
"""

import platform
import sys

block_cipher = None

target_arch = None
if "--target-arch" in sys.argv:
    idx = sys.argv.index("--target-arch")
    if idx + 1 < len(sys.argv):
        target_arch = sys.argv[idx + 1]

a = Analysis(
    ["../runlayer_cli/hook/__main__.py"],
    pathex=[],
    binaries=[],
    datas=[],
    hiddenimports=[
        "keyring.backends.macOS" if platform.system() == "Darwin" else "keyring.backends.Windows",
        "runlayer_cli.hook",
        "runlayer_cli.hook.clients",
        "runlayer_cli.hook.file_policy",
        "runlayer_cli.hook.mcp_lookup",
        "runlayer_cli.hook.messages",
        "runlayer_cli.hook.relay",
        "runlayer_cli.hook._relay_worker",
        "runlayer_cli.config",
        "runlayer_cli.credential_store",
        "runlayer_cli.paths",
        "runlayer_cli.api",
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        "fastmcp",
        "docker",
        "mcp",
        "anyio",
        "questionary",
        "rich",
        "structlog",
        "dotenv",
        "python_dotenv",
        "json5",
        "tomli",
        "pytest",
        "ruff",
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe_kwargs = {
    "name": "aiwatch-enforce",
    "debug": False,
    "bootloader_ignore_signals": False,
    "strip": False,
    "upx": False,
    "console": True,
}

if target_arch:
    exe_kwargs["target_arch"] = target_arch

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    **exe_kwargs,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name="aiwatch-enforce",
)
