# Runlayer Client Hooks

Unified hook for AI coding clients (Cursor, Claude Code, Codex) that enforces MCP security policy and forwards telemetry events.

Installed via `runlayer setup hooks --install`. The setup command copies the hook binary (or script) into the client's config directory, wires it into the client's hook registration file, and installs ignore-file patterns.

## Architecture

The hook is implemented as a Python package (`runlayer_cli.hook`) and can be invoked two ways:

1. **Frozen binary** (`aiwatch-enforce` / `aiwatch-enforce.exe`) — PyInstaller onedir bundle. ~40-100 ms cold start. No Python interpreter or `jq` needed. Preferred for MDM and production.
2. **Python module** (`python -m runlayer_cli.hook`) — runs from the installed `runlayer` package. Requires Python on PATH.

All three clients call the hook directly via the `command` field in their hook config. No bash/cmd shim needed.

### Client invocation

- **Cursor**: `execve` direct — binary path in `hooks.json`
- **Claude Code**: `bash -c <command>` (macOS/Linux) or `powershell <command>` (Windows, via `"shell": "powershell"` in settings.json)
- **Codex**: `$SHELL -lc <command>` (macOS/Linux) or `%COMSPEC% /C <command>` (Windows)

### Client auto-detection

The hook detects which client invoked it via:
- **Cursor**: `CURSOR_VERSION` env var present
- **Codex**: hook binary path contains `/.codex/` or starts with `/etc/codex/`
- **Claude Code**: fallback when neither marker is present

### Third-party hook guard

Cursor loads hooks from `~/.claude/settings.json` by default. When both Cursor and Claude Code hooks are installed, Cursor would fire both — causing double enforcement and event forwarding. The hook guards against this by checking its own path: if the client is Cursor but the binary path does not contain a Cursor config dir (`.cursor/`, `Application Support/Cursor/`, `/etc/cursor/`, `ProgramData/Cursor/`), it outputs `{"permission":"allow"}` and exits immediately.

## Runtime config

A sibling `runlayer-config.json` is written next to the binary at install time:

```json
{"enforcement": true}
```

When `enforcement` is `false`, the hook skips all blocking checks and only forwards events (monitoring-only mode).

## Credentials

Credentials are resolved from `~/.runlayer/config.yaml` (written by `runlayer login`) — same as the rest of the CLI.

## Event flow

### Event name normalization

Cursor uses camelCase event names; Claude Code uses PascalCase. The hook normalizes all names to PascalCase for internal dispatch:

| Cursor (camelCase)    | Normalized (PascalCase) |
|-----------------------|-------------------------|
| `preToolUse`          | `PreToolUse`            |
| `postToolUse`         | `PostToolUse`           |
| `postToolUseFailure`  | `PostToolUseFailure`    |
| `stop`                | `Stop`                  |
| `sessionStart`        | `SessionStart`          |
| `sessionEnd`          | `SessionEnd`            |
| `subagentStart`       | `SubagentStart`         |
| `subagentStop`        | `SubagentStop`          |
| `beforeSubmitPrompt`  | `UserPromptSubmit`      |
| `preCompact`          | `PreCompact`            |

### Enforcement events (blocking)

**MCP tool calls:**
- Cursor `beforeMCPExecution`: input carries `url`/`command` directly → POST to `/api/v1/hooks/cursor`
- Claude Code `PreToolUse` with `mcp__*` prefix: uses MCP server lookup to resolve server identity → POST to `/api/v1/hooks/cursor`
- Codex `PreToolUse` with `mcp__*` prefix: uses Codex MCP server lookup to resolve server identity → POST to `/api/v1/hooks/cursor`

Return `allow` or `deny` based on response. Fail-closed: any error → deny.

**File reads** (`beforeReadFile` / `beforeTabFileRead` / `PreToolUse` with `Read` tool):

Local-only pattern matching blocks access to:
- `.env`, `.env.*`, `*.env`, `.envrc`
- `mcp.json`, `.mcp.json`, `mcp_config.json`, `mcp-config.json`, `mcp.yaml`, `mcp.yml`
- `.claude.json`, `claude_desktop_config.json`
- `~/.claude/settings.json` (path-scoped — other `settings.json` files are allowed)

No API call — pure filename matching.

**Shell commands** (`PreToolUse` with `Bash` tool / Cursor `beforeShellExecution`):

Scans the command string for references to the same protected file patterns above.

**Native/local tool calls** (`preToolUse` / `PreToolUse`, `postToolUse` / `PostToolUse`):

Non-MCP tool pre/post hooks synchronously POST to `/api/v1/hooks/tool/pre` and `/api/v1/hooks/tool/post` for backend scanning. MCP calls stay on the MCP enforcement path above; the hook does not locally decide whether an MCP server is Runlayer-managed.

### Observational events (fire-and-forget)

All other events are forwarded as best-effort detached POSTs to `/api/v1/hooks/events`.

**Stop events** additionally attach the last 512 KB of the transcript file when available.

## MCP server lookup

Claude Code and Codex name MCP tools as `mcp__<server>__<tool>`. The hook strips the prefix to extract the server name, then resolves it to a URL or command.

Claude Code lookup walks its config file hierarchy in priority order:

1. `${cwd}/.mcp.json` → `mcpServers[name]` — project-scoped
2. `~/.claude.json` → `projects[cwd].mcpServers[name]` — per-project in user state
3. `~/.claude.json` → `mcpServers[name]` — global user-scoped

Cursor usually sends `beforeMCPExecution` with a resolved `url`, but some versions only send a server/display name in `command`. For Cursor only, the hook resolves that name from workspace `.cursor/mcp.json` entries in `workspace_roots` / `cwd`, then `~/.cursor/mcp.json`. Matching allows exact names, `user-` prefixes, and normalized display names such as `Linear44` → `linear-44`.

Codex lookup reads `~/.codex/config.toml`, `~/.codex/managed_config.toml`, then `/etc/codex/managed_config.toml`, using `[mcp_servers.<name>]` sections. Matching allows exact names and normalized names such as `runlayer_local_stdio_smoke` → `runlayer-local-stdio-smoke`.

First match wins. For each file, the function checks for a `url` field (remote/streamable-HTTP server) or a `command` + `args` pair (stdio server). The result is included in the enforcement request to `/api/v1/hooks/cursor`.

For Cursor `beforeMCPExecution`, if no config file contains the server name, the unresolved payload is still sent to the backend. For Claude Code and Codex `PreToolUse`, unregistered MCP servers are denied locally because their resolved URL/command is required before backend verification.

## Deny response format

**Cursor:**
```json
{"permission": "deny", "continue": true, "user_message": "...", "agentMessage": "..."}
```

**Claude Code:**
```json
{"hookSpecificOutput": {"hookEventName": "PreToolUse", "permissionDecision": "deny", "permissionDecisionReason": "..."}}
```

**Codex `PreToolUse`:**
```json
{"decision": "block", "reason": "..."}
```

**Codex `PermissionRequest`:**
```json
{"hookSpecificOutput": {"hookEventName": "PermissionRequest", "decision": {"behavior": "deny", "message": "..."}}}
```

## Ignore files

The installer creates `~/.cursorignore` and `~/.claudeignore` (non-MDM, enforcement mode only) with managed patterns matching the same sensitive files the hook protects. Patterns are wrapped in `# >>> Runlayer managed` markers for idempotent updates. Uninstall removes the managed block.

## Installation modes

| Flag | Behavior |
|---|---|
| (default) | Enforcement hooks only. Event/session hooks are opt-in. |
| `--event-hooks` / `--all-events` | Enforcement + all event/session hooks |
| `--no-enforcement` | All hooks registered but enforcement skipped (monitoring only) |
| `--mdm` | Enterprise install location requiring elevated privileges. Cursor: `hooks.json` in `/Library/Application Support/Cursor` (macOS), `/etc/cursor` (Linux), `C:\ProgramData\Cursor` (Windows). Claude Code: `managed-settings.json` in `/Library/Application Support/ClaudeCode` (macOS), `/etc/claude-code` (Linux), `C:\Program Files\ClaudeCode` (Windows). Codex: `hooks.json` plus `managed_config.toml` in `/etc/codex` on macOS/Linux. MDM install migrates existing user-level hooks to the enterprise location where supported. |

### Registered hook events

**Cursor enforcement:** `beforeMCPExecution`, `beforeReadFile`, `beforeTabFileRead`, `beforeShellExecution`, `preToolUse`, `postToolUse`, `postToolUseFailure`

**Cursor event/session hooks:** `sessionStart`, `sessionEnd`, `beforeSubmitPrompt`, `afterAgentThought`, `afterAgentResponse`, `afterMCPExecution`, `afterShellExecution`, `subagentStart`, `subagentStop`, `afterFileEdit`, `afterTabFileEdit`, `stop`, `preCompact`

Cursor `stop` is also forwarded as a synthetic `sessionEnd` event with `reason` set from `reason`, `stop_reason`, or Cursor's `status` field. This lets Stop/Interrupt close the session without requiring backend-specific Cursor stop handling.

**Claude Code enforcement:** `PreToolUse`, `PostToolUse`, `PostToolUseFailure`

**Claude Code event/session hooks:** `SessionStart`, `SessionEnd`, `UserPromptSubmit`, `SubagentStart`, `SubagentStop`, `Stop`, `PreCompact`, `PermissionRequest`, `Notification`, `TeammateIdle`, `TaskCompleted`, `InstructionsLoaded`, `ConfigChange`, `WorktreeCreate`, `WorktreeRemove`

**Codex enforcement (limited):** `PreToolUse` / `PostToolUse` / `PostToolUseFailure` for all tools; MCP enforcement is supported for configured MCP servers, file/shell enforcement is supported when Codex emits Bash-backed tool calls, and `PermissionRequest` is Bash-only.

**Codex event/session hooks (limited):** `SessionStart`, `UserPromptSubmit`, `Stop`

## Dependencies

The frozen binary is self-contained — no external dependencies required.

When running as `python -m runlayer_cli.hook`, the hook uses `httpx` (for relay POSTs), `pyyaml` (for config), and `keyring` (for credential store) — all bundled with the `runlayer` package.

## Debugging

Set `RUNLAYER_HOOK_DEBUG=1` to write structural metadata (URL, sizes, status) to temp dir for each relay call.

## Building the frozen binary

```bash
# macOS (host arch)
cd cli && pyinstaller packaging/aiwatch-enforce.spec

# Windows x64
cd cli && pyinstaller packaging/aiwatch-enforce.spec
```

Output goes to `cli/dist/aiwatch-enforce/`. Same EDR/codesigning constraints as `aiwatch` apply — see `packaging/aiwatch.spec` docstring.
