import click
from typing import Any, Optional
from snippy_ng.cli.utils import AbsolutePath
from snippy_ng.cli.utils.globals import CommandWithGlobals, GlobalOption, add_snippy_global_options, check_outdir_callback
from pathlib import Path


@click.command(cls=CommandWithGlobals, context_settings={'show_default': True})
@click.option("--outdir", "-o", default=Path("tree"), required=False, type=click.Path(writable=True, readable=True, file_okay=False, dir_okay=True), help="Output directory for phylogenetic tree results", callback=check_outdir_callback, cls=GlobalOption)
@click.option("--prefix", "-p", default="tree", help="Prefix for output files", cls=GlobalOption)
@click.option("--ram", "-r", default=None, required=False, type=int, help="Try and keep RAM under this many GB", cls=GlobalOption)
@add_snippy_global_options(exclude=['prefix', 'outdir', 'ram'])
@click.argument("alignment", required=True, type=AbsolutePath(exists=True, readable=True))
@click.option("--model", type=click.STRING, default="GTR+G4", help="Substitution model to use for tree construction. Use 'TEST' to select the best model.")
@click.option("--bootstrap", type=click.INT, default=1000, help="Number of bootstrap replicates to perform")
@click.option("--fconst", type=click.STRING, default=None, help="Constant sites counts (string or path to file)")
@click.option("--fast", is_flag=True, default=False, help="Use fast mode for IQ-TREE (faster but less accurate)")
def tree(alignment: Path, model: str, bootstrap: int, fconst: Optional[str], fast: bool, outdir: Path, prefix: str, **context: Any):
    """
    Create phylogenetic tree from alignment

    Example usage:

        snippy-ng tree core.full.aln
    """
    from snippy_ng.context import Context
    from snippy_ng.pipelines.tree import TreePipelineBuilder
    from snippy_ng.logging import logger

    #if fconst is a path read the content
    if not fconst and Path(alignment).with_suffix(".fconst").exists():
        logger.debug("No fconst provided, but found .fconst file corresponding to the alignment. Using this file for constant sites counts.")
        fconst = Path(alignment).with_suffix(".fconst")

    if fconst and Path(fconst).is_file():
        with open(fconst, 'r') as f:
            fconst = f.read().strip()
    
    # Choose stages to include in the pipeline
    # this will raise ValidationError if config is invalid
    # we let this happen as we want to catch all config errors
    # before starting the pipeline
    pipeline = TreePipelineBuilder(
        aln=alignment,
        model=model,
        bootstrap=bootstrap,
        fconst=fconst,
        fast_mode=fast,
        prefix=prefix,
    ).build()

    # Run the pipeline
    context["outdir"] = outdir
    run_ctx = Context(**context)
    return pipeline.run(run_ctx)
