from pathlib import Path
from typing import Optional
from pydantic import Field

from snippy_ng.stages import BaseStage, BaseOutput
from snippy_ng.dependencies import seqkit


class CopyFileOutput(BaseOutput):
    copied_file: Path = Field(..., description="Copied output file")


class CopyFile(BaseStage):
    """
    Copy a file from input location to output location.
    """

    input: Path = Field(..., description="Input file to copy")
    output_path: Path = Field(..., description="Output file path")

    @property
    def output(self) -> CopyFileOutput:
        return CopyFileOutput(copied_file=self.output_path)

    def create_commands(self, ctx):
        return [
            self.shell_cmd(
                ["cp", str(self.input), str(self.output_path)],
                description=f"Copy {self.input} to {self.output_path}",
            )
        ]

class CopyFastaOutput(BaseOutput):
    fasta: Path = Field(..., description="Output FASTA file path")

class CopyFasta(CopyFile):
    """
    Copy a FASTA file from input location to output location.
    """

    header: Optional[str] = Field(None, description="Header for the FASTA file")

    _dependencies = [seqkit]

    @property
    def output(self) -> CopyFastaOutput:
        return CopyFastaOutput(fasta=self.output_path)

    def create_commands(self, ctx):
        if self.header:
            cmd = self.shell_cmd(
                    ["seqkit", "replace", "-p", ".*", "-r", self.header, str(self.input)],
                    description=f"Copy and rename FASTA {self.input} to {self.output_path}",
                    output_file=self.output.fasta,
                )
        else:
            cmd = self.shell_cmd(
                ["cp", str(self.input), str(self.output_path)],
                description=f"Copy {self.input} to {self.output_path}",
            )
        return [cmd]

class FinaliseFastaOutput(BaseOutput):
    fasta: Path = Field(..., description="Final masked pseudo-alignment FASTA file")

class FinaliseFasta(CopyFasta):
    """
    Final stage to copy the final masked pseudo-alignment FASTA file to the standard output location.
    """

    @property
    def output(self) -> FinaliseFastaOutput:
        return FinaliseFastaOutput(fasta=self.output_path)