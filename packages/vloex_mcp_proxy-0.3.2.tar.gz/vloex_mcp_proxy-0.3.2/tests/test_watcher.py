"""Tests for config watcher — start/stop, change detection, debounce."""

import json
import threading
import time
from pathlib import Path
from unittest.mock import MagicMock

from vloex_mcp_proxy.daemon.watcher import ConfigWatcher


def _create_config(path: Path, rewritten: bool = False) -> Path:
    """Create a minimal MCP config file.

    If rewritten=True, the server entry points at vloex-mcp-proxy so that
    is_already_rewritten() returns True — the watcher should then skip it.
    """
    if rewritten:
        server = {
            "command": "vloex-mcp-proxy",
            "args": [
                "--server-command",
                "npx",
                "--server-args",
                '["-y","@test/server"]',
                "--server-name",
                "test-server",
            ],
        }
    else:
        server = {
            "command": "npx",
            "args": ["-y", "@test/server"],
        }
    config = {"mcpServers": {"test-server": server}}
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(config))
    return path


class TestConfigWatcher:
    def test_start_stop(self, tmp_path: Path):
        config_path = _create_config(tmp_path / "config.json")
        callback = MagicMock()
        watcher = ConfigWatcher([config_path], callback)
        watcher.start()
        try:
            assert watcher.is_running  # watchdog is a dev dep, must be installed
        finally:
            watcher.stop()
        assert not watcher.is_running

    def test_stop_without_start(self, tmp_path: Path):
        """stop() should be safe to call without start()."""
        config_path = _create_config(tmp_path / "config.json")
        watcher = ConfigWatcher([config_path], MagicMock())
        watcher.stop()  # Should not raise

    def test_debounce_prevents_rapid_calls(self, tmp_path: Path):
        """_handle_change should debounce rapid calls."""
        config_path = _create_config(tmp_path / "config.json")
        callback = MagicMock()
        watcher = ConfigWatcher([config_path], callback, debounce=1.0)
        # Simulate two rapid changes
        watcher._handle_change(config_path.resolve())
        watcher._handle_change(config_path.resolve())
        # Only one call should have gone through
        assert callback.call_count == 1

    def test_debounce_allows_after_window(self, tmp_path: Path):
        """After debounce window, next change should fire."""
        config_path = _create_config(tmp_path / "config.json")
        callback = MagicMock()
        watcher = ConfigWatcher([config_path], callback, debounce=0.01)
        watcher._handle_change(config_path.resolve())
        time.sleep(0.02)  # Wait past debounce
        watcher._handle_change(config_path.resolve())
        assert callback.call_count == 2

    def test_nonexistent_path_ignored(self, tmp_path: Path):
        """Non-existent config paths should not crash."""
        callback = MagicMock()
        watcher = ConfigWatcher([tmp_path / "nonexistent.json"], callback)
        watcher.start()
        watcher.stop()
        # Should not crash

    def test_empty_config_list(self):
        """Empty config list should not crash."""
        callback = MagicMock()
        watcher = ConfigWatcher([], callback)
        watcher.start()
        watcher.stop()

    def test_skips_already_rewritten_config(self, tmp_path: Path):
        """A config whose only server is already routed through the proxy
        must NOT fire the callback — we don't want to rewrite our own writes
        (infinite loop)."""
        config_path = _create_config(tmp_path / "config.json", rewritten=True)
        callback = MagicMock()
        watcher = ConfigWatcher([config_path], callback, debounce=0.0)
        watcher._handle_change(config_path.resolve())
        assert callback.call_count == 0

    def test_unreadable_config_still_fires(self, tmp_path: Path):
        """Garbage/unreadable JSON should not crash; callback still fires
        so that rewrite_single can decide what to do."""
        config_path = tmp_path / "config.json"
        config_path.write_text("{not valid json")
        callback = MagicMock()
        watcher = ConfigWatcher([config_path], callback, debounce=0.0)
        watcher._handle_change(config_path.resolve())
        assert callback.call_count == 1

    def test_callback_exception_does_not_propagate(self, tmp_path: Path):
        """If on_change raises, the watcher must swallow it — losing a
        rewrite is better than killing the daemon thread."""
        config_path = _create_config(tmp_path / "config.json")

        def bad_callback(_path: Path) -> None:
            raise RuntimeError("boom")

        watcher = ConfigWatcher([config_path], bad_callback, debounce=0.0)
        # Should not raise
        watcher._handle_change(config_path.resolve())

    def test_filters_events_for_unwatched_files(self, tmp_path: Path):
        """Changes to files in the watched directory but not in the
        config_paths set must be ignored."""
        watched = _create_config(tmp_path / "watched.json")
        sibling = _create_config(tmp_path / "sibling.json")
        callback = MagicMock()
        watcher = ConfigWatcher([watched], callback, debounce=0.0)
        # Manually fire change for a sibling — it should be rejected by
        # the config_paths set check inside the handler, so we just verify
        # that _handle_change is never called for paths not in the set.
        assert sibling.resolve() not in watcher._config_paths
        assert watched.resolve() in watcher._config_paths

    def test_end_to_end_real_file_edit_triggers_callback(self, tmp_path: Path):
        """Integration test: start a real watchdog Observer, modify a file,
        and verify the callback fires within a reasonable window.

        This is the main path that protects against regressions in the
        watchdog wiring (handler type guards, parent dir scheduling, etc.).
        """
        config_path = _create_config(tmp_path / "config.json")
        fired = threading.Event()
        seen_paths: list[Path] = []

        def on_change(path: Path) -> None:
            seen_paths.append(path)
            fired.set()

        watcher = ConfigWatcher([config_path], on_change, debounce=0.0)
        watcher.start()
        try:
            assert watcher.is_running
            # Give the observer a moment to fully spin up before we edit
            time.sleep(0.2)
            # Flip the server command so the file is no longer "already rewritten"
            config_path.write_text(
                json.dumps(
                    {
                        "mcpServers": {
                            "test-server": {
                                "command": "uvx",
                                "args": ["some-mcp-server"],
                            }
                        }
                    }
                )
            )
            # Wait up to 5s for the watcher to notice
            assert fired.wait(timeout=5.0), "watcher did not fire on file edit"
            assert seen_paths[0] == config_path.resolve()
        finally:
            watcher.stop()
        assert not watcher.is_running
