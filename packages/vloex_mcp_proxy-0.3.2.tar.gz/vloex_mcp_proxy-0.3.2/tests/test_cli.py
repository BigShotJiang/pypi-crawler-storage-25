"""Tests for CLI argument parsing."""

from __future__ import annotations

import argparse
import json
from unittest.mock import MagicMock, patch

import pytest

from vloex_mcp_proxy.cli import _handle_daemon, main


def test_version_flag() -> None:
    """--version prints version and exits."""
    with pytest.raises(SystemExit) as exc_info:
        with patch("sys.argv", ["vloex-mcp-proxy", "--version"]):
            main()
    assert exc_info.value.code == 0


def test_missing_server_command() -> None:
    """Missing --server-command exits with error."""
    with pytest.raises(SystemExit) as exc_info:
        with patch("sys.argv", ["vloex-mcp-proxy"]):
            main()
    assert exc_info.value.code == 2  # argparse exits with 2


def _parse_server_args(raw: str) -> list[str]:
    """Replicate the arg parsing logic from cli.py for testing."""
    if raw and raw.startswith("["):
        try:
            parsed_args = json.loads(raw)
            return [str(a) for a in parsed_args] if isinstance(parsed_args, list) else []
        except json.JSONDecodeError:
            return [a for a in raw.split(",") if a]
    return [a for a in raw.split(",") if a] if raw else []


def _get_server_name(command: str, explicit_name: str | None) -> str:
    """Replicate the server name defaulting logic from cli.py."""
    return explicit_name or command.rsplit("/", 1)[-1]


def test_comma_separated_args() -> None:
    """Comma-separated --server-args are split correctly."""
    result = _parse_server_args("-y,@mcp/server-filesystem,/tmp")
    assert result == ["-y", "@mcp/server-filesystem", "/tmp"]


def test_json_array_args() -> None:
    """JSON array --server-args are parsed correctly."""
    args_json = json.dumps(["-y", "@mcp/server-filesystem", "/tmp"])
    result = _parse_server_args(args_json)
    assert result == ["-y", "@mcp/server-filesystem", "/tmp"]


def test_json_array_with_commas() -> None:
    """JSON array args containing commas are preserved correctly."""
    args_json = json.dumps(["--config", "a,b,c", "/tmp"])
    result = _parse_server_args(args_json)
    assert result == ["--config", "a,b,c", "/tmp"]


def test_malformed_json_falls_back_to_comma_split() -> None:
    """Malformed JSON starting with [ falls back to comma split."""
    result = _parse_server_args("[broken,json")
    assert result == ["[broken", "json"]


def test_empty_args() -> None:
    """Empty --server-args produces empty list."""
    assert _parse_server_args("") == []


def test_single_arg() -> None:
    """Single arg without commas works."""
    assert _parse_server_args("server.js") == ["server.js"]


def test_server_name_defaults_to_command_basename() -> None:
    """--server-name defaults to basename of --server-command."""
    assert _get_server_name("/usr/local/bin/npx", None) == "npx"


def test_server_name_simple_command() -> None:
    """Simple command without path uses the command itself."""
    assert _get_server_name("npx", None) == "npx"


def test_server_name_explicit() -> None:
    """Explicit --server-name is used as-is."""
    assert _get_server_name("npx", "my-mcp-server") == "my-mcp-server"


# ---------------------------------------------------------------------------
# Daemon start — backend URL resolution (env / flag / MDM fallback)
# ---------------------------------------------------------------------------


def _daemon_start_args(backend_url: str | None = None) -> argparse.Namespace:
    return argparse.Namespace(
        command="daemon",
        daemon_action="start",
        backend_url=backend_url,
        foreground=True,
        run_as=None,
    )


def test_daemon_start_prefers_cli_flag_over_env() -> None:
    """--backend-url CLI flag wins over VLOEX_BACKEND_URL env."""
    fake_svc = MagicMock()
    with patch("vloex_mcp_proxy.daemon.service.DaemonService", return_value=fake_svc) as cls:
        with patch("asyncio.run"):
            with patch.dict("os.environ", {"VLOEX_BACKEND_URL": "https://env.example"}):
                _handle_daemon(_daemon_start_args(backend_url="https://flag.example"))
    cls.assert_called_once()
    kwargs = cls.call_args.kwargs
    assert kwargs["backend_url"] == "https://flag.example"


def test_daemon_start_uses_env_when_no_flag() -> None:
    """VLOEX_BACKEND_URL is used when --backend-url is not set."""
    fake_svc = MagicMock()
    with patch("vloex_mcp_proxy.daemon.service.DaemonService", return_value=fake_svc) as cls:
        with patch("asyncio.run"):
            with patch.dict("os.environ", {"VLOEX_BACKEND_URL": "https://env.example"}):
                _handle_daemon(_daemon_start_args(backend_url=None))
    kwargs = cls.call_args.kwargs
    assert kwargs["backend_url"] == "https://env.example"


def test_daemon_start_falls_back_to_mdm_config() -> None:
    """With no flag and no env var, daemon reads MDM enterprise config.

    This is the .pkg / LaunchDaemon path — IT admins drop /etc/vloex/config.json,
    and the daemon should pick up backend_url from there on restart.
    """
    fake_svc = MagicMock()
    with patch("vloex_mcp_proxy.daemon.service.DaemonService", return_value=fake_svc) as cls:
        with patch("asyncio.run"):
            with patch.dict("os.environ", {}, clear=False):
                import os

                os.environ.pop("VLOEX_BACKEND_URL", None)
                with patch(
                    "vloex_mcp_proxy.backend.config.get_backend_url",
                    return_value="https://mdm.example",
                ):
                    _handle_daemon(_daemon_start_args(backend_url=None))
    kwargs = cls.call_args.kwargs
    assert kwargs["backend_url"] == "https://mdm.example"


def test_daemon_start_none_when_nothing_configured() -> None:
    """Backend URL is None when no source has a value."""
    fake_svc = MagicMock()
    with patch("vloex_mcp_proxy.daemon.service.DaemonService", return_value=fake_svc) as cls:
        with patch("asyncio.run"):
            with patch.dict("os.environ", {}, clear=False):
                import os

                os.environ.pop("VLOEX_BACKEND_URL", None)
                with patch(
                    "vloex_mcp_proxy.backend.config.get_backend_url",
                    return_value=None,
                ):
                    _handle_daemon(_daemon_start_args(backend_url=None))
    kwargs = cls.call_args.kwargs
    assert kwargs["backend_url"] is None
