"""Tests for uninstall CLI — restore configs, remove dir, keep-data."""

from pathlib import Path
from unittest.mock import MagicMock, patch

from vloex_mcp_proxy.discovery.rewriter import RestoreReport


def _make_args(keep_data: bool = False) -> MagicMock:
    args = MagicMock()
    args.keep_data = keep_data
    return args


class TestUninstallCLI:
    def test_restore_configs_called(self, tmp_path: Path):
        """Uninstall should call restore_all()."""
        mock_report = RestoreReport(configs_restored=0, details=["No backups found"])

        with (
            patch(
                "vloex_mcp_proxy.discovery.rewriter.restore_all",
                return_value=mock_report,
            ) as mock_restore,
            patch(
                "vloex_mcp_proxy.backend.config.get_vloex_dir",
                return_value=tmp_path,
            ),
            patch("vloex_mcp_proxy.daemon.service.DaemonService") as mock_daemon_cls,
        ):
            mock_daemon_cls.return_value.stop_external.return_value = False

            from vloex_mcp_proxy.cli import _handle_uninstall

            _handle_uninstall(_make_args())
            mock_restore.assert_called_once()

    def test_removes_vloex_dir(self, tmp_path: Path):
        """Without --keep-data, ~/.vloex should be removed."""
        vloex_dir = tmp_path / ".vloex"
        vloex_dir.mkdir()
        (vloex_dir / "device_id").write_text("test-id")
        mock_report = RestoreReport(configs_restored=0, details=[])

        with (
            patch(
                "vloex_mcp_proxy.discovery.rewriter.restore_all",
                return_value=mock_report,
            ),
            patch(
                "vloex_mcp_proxy.backend.config.get_vloex_dir",
                return_value=vloex_dir,
            ),
            patch("vloex_mcp_proxy.daemon.service.DaemonService") as mock_daemon_cls,
        ):
            mock_daemon_cls.return_value.stop_external.return_value = False

            from vloex_mcp_proxy.cli import _handle_uninstall

            _handle_uninstall(_make_args(keep_data=False))

        assert not vloex_dir.exists()

    def test_keeps_data_with_flag(self, tmp_path: Path):
        """With --keep-data, ~/.vloex should be preserved."""
        vloex_dir = tmp_path / ".vloex"
        vloex_dir.mkdir()
        (vloex_dir / "device_id").write_text("test-id")
        mock_report = RestoreReport(configs_restored=0, details=[])

        with (
            patch(
                "vloex_mcp_proxy.discovery.rewriter.restore_all",
                return_value=mock_report,
            ),
            patch(
                "vloex_mcp_proxy.backend.config.get_vloex_dir",
                return_value=vloex_dir,
            ),
            patch("vloex_mcp_proxy.daemon.service.DaemonService") as mock_daemon_cls,
        ):
            mock_daemon_cls.return_value.stop_external.return_value = False

            from vloex_mcp_proxy.cli import _handle_uninstall

            _handle_uninstall(_make_args(keep_data=True))

        assert vloex_dir.exists()

    def test_graceful_without_daemon_deps(self, tmp_path: Path):
        """Uninstall should not crash if daemon deps are missing."""
        mock_report = RestoreReport(configs_restored=0, details=[])

        with patch(
            "vloex_mcp_proxy.discovery.rewriter.restore_all",
            return_value=mock_report,
        ):
            from vloex_mcp_proxy.cli import _handle_uninstall

            # Should not raise
            _handle_uninstall(_make_args())

    def test_clears_device_token_from_keychain(self, tmp_path: Path):
        """Uninstall must clear keychain-stored device token, not just rmtree.

        Regression for: status command reported stale enrollment after
        uninstall+reinstall because device_token persisted in macOS keychain
        (com.vloex.mcp-proxy/device_token) while ~/.vloex/ was wiped.
        """
        vloex_dir = tmp_path / ".vloex"
        vloex_dir.mkdir()
        (vloex_dir / "device_id").write_text("test-id")
        mock_report = RestoreReport(configs_restored=0, details=[])

        with (
            patch(
                "vloex_mcp_proxy.discovery.rewriter.restore_all",
                return_value=mock_report,
            ),
            patch(
                "vloex_mcp_proxy.backend.config.get_vloex_dir",
                return_value=vloex_dir,
            ),
            patch("vloex_mcp_proxy.daemon.service.DaemonService") as mock_daemon_cls,
            patch(
                "vloex_mcp_proxy.backend.config.clear_device_token"
            ) as mock_clear,
        ):
            mock_daemon_cls.return_value.stop_external.return_value = False

            from vloex_mcp_proxy.cli import _handle_uninstall

            _handle_uninstall(_make_args(keep_data=False))

        mock_clear.assert_called_once_with(vloex_dir)
        assert not vloex_dir.exists()

    def test_does_not_clear_token_with_keep_data(self, tmp_path: Path):
        """With --keep-data, enrollment should be preserved (token + dir)."""
        vloex_dir = tmp_path / ".vloex"
        vloex_dir.mkdir()
        (vloex_dir / "device_id").write_text("test-id")
        mock_report = RestoreReport(configs_restored=0, details=[])

        with (
            patch(
                "vloex_mcp_proxy.discovery.rewriter.restore_all",
                return_value=mock_report,
            ),
            patch(
                "vloex_mcp_proxy.backend.config.get_vloex_dir",
                return_value=vloex_dir,
            ),
            patch("vloex_mcp_proxy.daemon.service.DaemonService") as mock_daemon_cls,
            patch(
                "vloex_mcp_proxy.backend.config.clear_device_token"
            ) as mock_clear,
        ):
            mock_daemon_cls.return_value.stop_external.return_value = False

            from vloex_mcp_proxy.cli import _handle_uninstall

            _handle_uninstall(_make_args(keep_data=True))

        mock_clear.assert_not_called()
        assert vloex_dir.exists()
