"""Vloex MCP Gateway — stdio proxy for MCP tool call governance."""

__version__ = "0.3.2"
