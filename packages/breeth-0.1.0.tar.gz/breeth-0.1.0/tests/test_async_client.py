"""Happy-path tests for the AsyncBreethClient."""
from __future__ import annotations

import httpx
import pytest
import respx

from breeth import AsyncBreethClient, BreethError


BASE = "https://api.thebreeth.com"
API_KEY = "ck_live_testtoken"


@pytest.mark.asyncio
@respx.mock
async def test_async_write_and_retrieve() -> None:
    respx.post(f"{BASE}/v1/episodes").mock(
        return_value=httpx.Response(
            200,
            json={
                "ok": True,
                "episode_name": "api_1",
                "extracted": {"entities": 1, "edges": 0},
                "group_id": "default",
            },
        )
    )
    respx.post(f"{BASE}/v1/search").mock(
        return_value=httpx.Response(
            200,
            json={
                "edges": [],
                "_cache": {
                    "tier": "hit",
                    "hot_hits": 0,
                    "cold_hits": 0,
                    "group_id": "default",
                },
                "note": "No matching edges and no profile available.",
            },
        )
    )

    async with AsyncBreethClient(api_key=API_KEY, base_url=BASE) as breeth:
        write_resp = await breeth.write("Recruiter prefers fast iteration.")
        search_resp = await breeth.retrieve("recruiter preferences")

    assert write_resp.episode_name == "api_1"
    assert search_resp.cache.tier == "hit"
    assert search_resp.edges == []


@pytest.mark.asyncio
@respx.mock
async def test_async_graph_list_entities() -> None:
    respx.get(f"{BASE}/v1/graph/entities").mock(
        return_value=httpx.Response(
            200,
            json={
                "entities": [
                    {
                        "uuid": "u-1",
                        "name": "Jane Doe",
                        "labels": ["Person"],
                        "edge_count": 3,
                        "episode_count": 1,
                    }
                ],
                "count": 1,
            },
        )
    )
    async with AsyncBreethClient(api_key=API_KEY, base_url=BASE) as breeth:
        resp = await breeth.graph.list_entities(query="Jane")
    assert resp.count == 1
    assert resp.entities[0].name == "Jane Doe"


@pytest.mark.asyncio
@respx.mock
async def test_async_error_maps_to_breeth_error() -> None:
    respx.get(f"{BASE}/v1/groups").mock(
        return_value=httpx.Response(
            401,
            json={"detail": {"error": "invalid_token", "message": "API key invalid"}},
        )
    )
    async with AsyncBreethClient(api_key=API_KEY, base_url=BASE) as breeth:
        with pytest.raises(BreethError) as excinfo:
            await breeth.groups()
    assert excinfo.value.status == 401
    assert excinfo.value.slug == "invalid_token"
