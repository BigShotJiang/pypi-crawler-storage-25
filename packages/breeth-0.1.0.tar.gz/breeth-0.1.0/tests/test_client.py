"""Happy-path tests for the synchronous BreethClient using respx."""
from __future__ import annotations

import httpx
import pytest
import respx

from breeth import BreethClient, BreethError


BASE = "https://api.thebreeth.com"
API_KEY = "ck_live_testtoken"


def _client() -> BreethClient:
    return BreethClient(api_key=API_KEY, base_url=BASE)


@respx.mock
def test_write_happy_path() -> None:
    route = respx.post(f"{BASE}/v1/episodes").mock(
        return_value=httpx.Response(
            200,
            json={
                "ok": True,
                "episode_name": "api_1700000000000",
                "extracted": {"entities": 3, "edges": 2},
                "group_id": "default",
                "warning": None,
                "cogram": {
                    "mode": "async",
                    "status": "pipeline_running_in_background",
                    "task_id": "tsk_abc",
                    "note": "running",
                },
                "intent_suggestion": None,
            },
        )
    )
    with _client() as breeth:
        resp = breeth.write(
            "Candidate has 4 years HR-tech experience at Workday.",
            group_id="recruiting",
        )

    assert route.called
    sent = route.calls.last.request
    assert sent.headers["authorization"] == f"Bearer {API_KEY}"
    assert resp.ok is True
    assert resp.extracted.entities == 3
    assert resp.cogram is not None
    assert resp.cogram.task_id == "tsk_abc"


@respx.mock
def test_retrieve_aliases_underscore_fields() -> None:
    respx.post(f"{BASE}/v1/search").mock(
        return_value=httpx.Response(
            200,
            json={
                "edges": [
                    {
                        "edge_uuid": "e-1",
                        "source_node": "n-a",
                        "target_node": "n-b",
                        "fact": "candidate worked at Workday",
                        "name": "WORKED_AT",
                        "intent_meta": {"cognitive_pattern": "prefers_hr_tech"},
                        "_tier": "cold",
                    }
                ],
                "_cache": {
                    "tier": "warmed",
                    "hot_hits": 0,
                    "cold_hits": 1,
                    "group_id": "default",
                },
                "note": None,
            },
        )
    )
    with _client() as breeth:
        resp = breeth.retrieve("HR-tech background", limit=5)

    assert resp.cache.tier == "warmed"
    assert resp.cache.cold_hits == 1
    assert resp.edges[0].tier == "cold"
    assert resp.edges[0].fact.startswith("candidate")


@respx.mock
def test_entity_narrative_default() -> None:
    respx.get(f"{BASE}/v1/entities/Workday").mock(
        return_value=httpx.Response(
            200,
            json={
                "entity_name": "Workday",
                "mode": "narrative",
                "narrative": [
                    {
                        "uuid": "u-1",
                        "name": "Workday",
                        "degree": 5,
                        "summary": "HR-tech vendor",
                        "narrative": "Common employer in candidate pool",
                        "confidence_stored": 0.8,
                        "confidence_decayed": 0.75,
                        "confidence_label": "high",
                    }
                ],
                "edges": None,
                "episodes": None,
                "note": None,
            },
        )
    )
    with _client() as breeth:
        resp = breeth.entity("Workday")
    assert resp.narrative is not None
    assert resp.narrative[0].name == "Workday"


@respx.mock
def test_entity_with_mode_and_limit() -> None:
    route = respx.get(f"{BASE}/v1/entities/Workday").mock(
        return_value=httpx.Response(
            200,
            json={
                "entity_name": "Workday",
                "mode": "edges",
                "narrative": None,
                "edges": [],
                "episodes": None,
                "note": "No edges connected to 'Workday' in your team's memory.",
            },
        )
    )
    with _client() as breeth:
        resp = breeth.entity("Workday", mode="edges", limit=50)
    assert route.calls.last.request.url.params["mode"] == "edges"
    assert route.calls.last.request.url.params["limit"] == "50"
    assert resp.note is not None


@respx.mock
def test_groups_list() -> None:
    respx.get(f"{BASE}/v1/groups").mock(
        return_value=httpx.Response(
            200,
            json={
                "groups": [
                    {
                        "group_id": "default",
                        "episodes": 10,
                        "entities": 18,
                        "patterns": 2,
                        "knots": 1,
                        "has_director_profile": True,
                    }
                ],
                "total": 1,
                "returned": 1,
                "query": None,
                "next_offset": None,
                "hint": None,
                "note": None,
            },
        )
    )
    with _client() as breeth:
        resp = breeth.groups()
    assert resp.total == 1
    assert resp.groups[0].group_id == "default"


@respx.mock
def test_graph_node_details() -> None:
    uid = "550e8400-e29b-41d4-a716-446655440000"
    respx.get(f"{BASE}/v1/graph/nodes/{uid}/details").mock(
        return_value=httpx.Response(
            200,
            json={
                "entity": {
                    "uuid": uid,
                    "name": "Candidate Jane Doe",
                    "labels": ["Person"],
                    "summary": "Senior HR recruiter",
                    "edge_count": 4,
                    "episode_count": 2,
                    "space": "individual",
                    "member_id": None,
                    "created_at": "2026-05-01T00:00:00Z",
                },
                "neighbors": [
                    {
                        "peer": "Workday",
                        "direction": "out",
                        "fact": "worked at Workday",
                        "cognitive_pattern": "prefers_hr_tech",
                        "intent_meta": {"why_connected": "5-year tenure"},
                        "edge_uuid": "e-99",
                    }
                ],
                "episodes": [
                    {"uuid": "ep-1", "name": "intake_call", "valid_at": "2026-05-01T00:00:00Z"}
                ],
            },
        )
    )
    with _client() as breeth:
        resp = breeth.graph.node_details(uid)
    assert resp.entity.name == "Candidate Jane Doe"
    assert resp.neighbors[0].peer == "Workday"


@respx.mock
def test_graph_list_entities_passes_params() -> None:
    route = respx.get(f"{BASE}/v1/graph/entities").mock(
        return_value=httpx.Response(200, json={"entities": [], "count": 0})
    )
    with _client() as breeth:
        resp = breeth.graph.list_entities(query="Jane", limit=25, offset=10)
    assert resp.count == 0
    params = route.calls.last.request.url.params
    assert params["query"] == "Jane"
    assert params["limit"] == "25"
    assert params["offset"] == "10"


@respx.mock
def test_graph_list_edges_omits_none_params() -> None:
    route = respx.get(f"{BASE}/v1/graph/edges").mock(
        return_value=httpx.Response(200, json={"edges": [], "count": 0})
    )
    with _client() as breeth:
        breeth.graph.list_edges()
    assert "query" not in route.calls.last.request.url.params
    assert "limit" not in route.calls.last.request.url.params


@respx.mock
def test_graph_list_episodes() -> None:
    respx.get(f"{BASE}/v1/graph/episodes").mock(
        return_value=httpx.Response(
            200,
            json={
                "episodes": [
                    {
                        "uuid": "ep-1",
                        "name": "intake_call",
                        "source_description": "api",
                        "content_excerpt": "candidate intake",
                        "group_id": "recruiting",
                        "valid_at": "2026-05-01T00:00:00Z",
                        "space": "individual",
                        "member_id": None,
                    }
                ],
                "count": 1,
            },
        )
    )
    with _client() as breeth:
        resp = breeth.graph.list_episodes()
    assert resp.count == 1


@respx.mock
def test_error_response_maps_to_breeth_error() -> None:
    respx.post(f"{BASE}/v1/episodes").mock(
        return_value=httpx.Response(
            429,
            json={
                "detail": {
                    "error": "quota_exceeded",
                    "message": "Monthly write quota exceeded.",
                }
            },
        )
    )
    with _client() as breeth:
        with pytest.raises(BreethError) as excinfo:
            breeth.write("test content")
    err = excinfo.value
    assert err.status == 429
    assert err.slug == "quota_exceeded"
    assert "Monthly write quota" in err.message


def test_missing_api_key_raises() -> None:
    import os

    saved = {k: os.environ.pop(k, None) for k in ("BREETH_API_KEY", "COGRAM_API_KEY")}
    try:
        with pytest.raises(BreethError) as excinfo:
            BreethClient()
        assert excinfo.value.slug == "missing_api_key"
    finally:
        for k, v in saved.items():
            if v is not None:
                os.environ[k] = v


def test_end_user_id_header_is_sent() -> None:
    with respx.mock(base_url=BASE) as router:
        route = router.get("/v1/groups").mock(
            return_value=httpx.Response(
                200,
                json={"groups": [], "total": 0, "returned": 0},
            )
        )
        with BreethClient(api_key=API_KEY, base_url=BASE, end_user_id="user-42") as breeth:
            breeth.groups()
        assert route.calls.last.request.headers["x-end-user-id"] == "user-42"
