"""Shared base utilities for the sync and async Breeth clients.

Both `BreethClient` and `AsyncBreethClient` are thin wrappers around
``httpx.Client`` / ``httpx.AsyncClient``. This module centralises:

* Base URL resolution (env var ``COGRAM_API_URL`` overrides the default).
* Authorization header construction.
* Optional ``X-End-User-Id`` passthrough for multi-end-user apps.
* HTTP error to ``BreethError`` mapping.

Note: ``X-Cogram-Team-Id`` is intentionally NOT set. The server resolves
the team from the ``ck_live_`` API key.
"""
from __future__ import annotations

import os
from typing import Any, Mapping, Optional

import httpx

from .errors import BreethError


DEFAULT_BASE_URL = "https://api.thebreeth.com"
API_PREFIX = "/v1"
DEFAULT_TIMEOUT = 30.0
USER_AGENT = "breeth-python/0.1.0"


def resolve_base_url(explicit: Optional[str]) -> str:
    """Pick the base URL in order: explicit arg, ``COGRAM_API_URL``,
    SDK default. Trailing slashes are stripped so URL joining is
    predictable."""
    raw = explicit or os.environ.get("COGRAM_API_URL") or DEFAULT_BASE_URL
    return raw.rstrip("/")


def resolve_api_key(explicit: Optional[str]) -> str:
    key = explicit or os.environ.get("BREETH_API_KEY") or os.environ.get("COGRAM_API_KEY")
    if not key:
        raise BreethError(
            "Missing API key. Pass api_key=... or set BREETH_API_KEY.",
            status=0,
            slug="missing_api_key",
        )
    return key


def build_headers(api_key: str, end_user_id: Optional[str]) -> dict[str, str]:
    headers = {
        "Authorization": f"Bearer {api_key}",
        "User-Agent": USER_AGENT,
        "Accept": "application/json",
    }
    if end_user_id:
        headers["X-End-User-Id"] = end_user_id
    return headers


def build_url(base_url: str, path: str) -> str:
    """Join the base URL, the /v1 prefix, and a route path. The path
    can be supplied with or without a leading slash."""
    suffix = path if path.startswith("/") else f"/{path}"
    return f"{base_url}{API_PREFIX}{suffix}"


def raise_for_status(response: httpx.Response) -> None:
    """Map any 4xx / 5xx response to a ``BreethError``.

    The API returns JSON shaped like
    ``{"detail": {"error": "<slug>", "message": "..."}}`` for handled
    errors, and FastAPI's default ``{"detail": "..."}`` for unhandled
    validation issues. We accept both and extract whatever we can.
    """
    if response.is_success:
        return

    slug: Optional[str] = None
    message: str = response.reason_phrase or "Request failed"
    body: Any = None
    try:
        body = response.json()
    except Exception:
        body = response.text or None

    if isinstance(body, dict):
        detail = body.get("detail", body)
        if isinstance(detail, dict):
            slug = detail.get("error") or detail.get("slug") or slug
            message = detail.get("message") or detail.get("detail") or message
        elif isinstance(detail, str):
            message = detail

    raise BreethError(message, status=response.status_code, slug=slug, body=body)


def merge_query(params: Optional[Mapping[str, Any]]) -> Optional[dict[str, Any]]:
    """Drop None-valued query parameters so callers can pass them
    unconditionally without polluting the URL."""
    if not params:
        return None
    out = {k: v for k, v in params.items() if v is not None}
    return out or None
