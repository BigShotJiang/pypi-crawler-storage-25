"""Pydantic v2 request and response models for the Breeth API.

These mirror the server schemas in cogram-core. Fields with a leading
underscore on the wire (e.g. ``_cache``, ``_tier``, ``_source``,
``_note``) use aliases so Python users can access them as normal
attributes (``response.cache`` rather than ``response["_cache"]``).
"""
from __future__ import annotations

from typing import Any, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field


# ---------------------------------------------------------------------------
# Write (POST /v1/episodes)
# ---------------------------------------------------------------------------

class ExtractedCounts(BaseModel):
    entities: int
    edges: int


class CogramTaskEnvelope(BaseModel):
    mode: str
    status: str
    task_id: Optional[str] = None
    note: Optional[str] = None


class IntentSuggestion(BaseModel):
    should_extract: bool = True
    confidence: float
    reason: str


class WriteResponse(BaseModel):
    ok: bool = True
    episode_name: str
    extracted: ExtractedCounts
    group_id: str
    warning: Optional[str] = None
    cogram: Optional[CogramTaskEnvelope] = None
    intent_suggestion: Optional[IntentSuggestion] = None


# ---------------------------------------------------------------------------
# Retrieve (POST /v1/search)
# ---------------------------------------------------------------------------

class EdgeHit(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    edge_uuid: Optional[str] = None
    source_node: str
    target_node: str
    fact: str
    name: Optional[str] = None
    intent_meta: Any = None
    tier: str = Field(alias="_tier")


class CacheStats(BaseModel):
    tier: str
    hot_hits: int
    cold_hits: int
    group_id: str


class PatternEvidence(BaseModel):
    name: str
    stored_confidence: float
    effective_confidence: float
    examples: list[dict] = Field(default_factory=list)


class DirectorProfileBlock(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    summary: str
    visions: list[str] = Field(default_factory=list)
    top_patterns: list[PatternEvidence] = Field(default_factory=list)
    source: str = Field(alias="_source")
    note: str = Field(alias="_note")


class RetrieveResponse(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    director_profile: Optional[DirectorProfileBlock] = None
    edges: list[EdgeHit] = Field(default_factory=list)
    cache: CacheStats = Field(alias="_cache")
    note: Optional[str] = None


# ---------------------------------------------------------------------------
# Entity (GET /v1/entities/{name})
# ---------------------------------------------------------------------------

EntityMode = Literal["narrative", "edges", "episodes", "all"]


class EntityNarrativeRow(BaseModel):
    uuid: str
    name: str
    degree: int
    summary: str
    narrative: Any
    confidence_stored: float
    confidence_decayed: float
    confidence_label: str


class EntityEdgeRow(BaseModel):
    a: str
    b: str
    fact: str
    intent_meta: Any = None


class EntityEpisodeRow(BaseModel):
    uuid: str
    name: str
    content_excerpt: str
    timestamp: Any = None


class EntityResponse(BaseModel):
    entity_name: str
    mode: str
    narrative: Optional[list[EntityNarrativeRow]] = None
    edges: Optional[list[EntityEdgeRow]] = None
    episodes: Optional[list[EntityEpisodeRow]] = None
    note: Optional[str] = None


# ---------------------------------------------------------------------------
# Graph (GET /v1/graph/*)
# ---------------------------------------------------------------------------

class GraphEntityRow(BaseModel):
    uuid: str
    name: str
    labels: list[str] = Field(default_factory=list)
    summary: Optional[str] = None
    edge_count: int = 0
    episode_count: int = 0
    space: str = "individual"
    member_id: Optional[str] = None
    created_at: Optional[str] = None
    knot_narrative: Optional[str] = None
    knot_score: Optional[float] = None
    knot_synthesized_at: Optional[float] = None
    knot_model: Optional[str] = None


class GraphEntityListResponse(BaseModel):
    entities: list[GraphEntityRow]
    count: int


class GraphEdgeRow(BaseModel):
    uuid: str
    fact: str
    source_name: str
    target_name: str
    cognitive_pattern: Optional[str] = None
    intent_meta: Optional[dict] = None
    retracted_at: Optional[str] = None
    space: str = "individual"
    member_id: Optional[str] = None
    created_at: Optional[str] = None


class GraphEdgeListResponse(BaseModel):
    edges: list[GraphEdgeRow]
    count: int


class GraphEpisodeRow(BaseModel):
    uuid: str
    name: str
    source_description: Optional[str] = None
    content_excerpt: str = ""
    group_id: str = ""
    valid_at: Optional[str] = None
    space: str = "individual"
    member_id: Optional[str] = None


class GraphEpisodeListResponse(BaseModel):
    episodes: list[GraphEpisodeRow]
    count: int


class NeighborRow(BaseModel):
    peer: str
    direction: str
    fact: Optional[str] = None
    cognitive_pattern: Optional[str] = None
    intent_meta: Optional[dict] = None
    edge_uuid: Optional[str] = None


class EpisodeMentionRow(BaseModel):
    uuid: str
    name: str
    valid_at: Optional[str] = None


class NodeDetailsResponse(BaseModel):
    entity: GraphEntityRow
    neighbors: list[NeighborRow]
    episodes: list[EpisodeMentionRow]


# ---------------------------------------------------------------------------
# Groups (GET /v1/groups)
# ---------------------------------------------------------------------------

class GroupRow(BaseModel):
    group_id: str
    episodes: int
    entities: int
    patterns: int
    knots: int
    has_director_profile: bool


class GroupsListResponse(BaseModel):
    groups: list[GroupRow]
    total: int
    returned: int
    query: Optional[str] = None
    next_offset: Optional[int] = None
    hint: Optional[str] = None
    note: Optional[str] = None
