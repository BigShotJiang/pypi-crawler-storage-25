"""Sync and async clients for the Breeth API.

Usage:

    from breeth import BreethClient

    with BreethClient(api_key="ck_live_...") as breeth:
        breeth.write("Recruiter prefers candidates with HR-tech experience.")
        hits = breeth.retrieve("HR-tech experience")

    # Async
    from breeth import AsyncBreethClient

    async with AsyncBreethClient(api_key="ck_live_...") as breeth:
        await breeth.write("...")
"""
from __future__ import annotations

from typing import Any, Optional

import httpx

from ._base import (
    DEFAULT_TIMEOUT,
    build_headers,
    build_url,
    merge_query,
    raise_for_status,
    resolve_api_key,
    resolve_base_url,
)
from .types import (
    EntityMode,
    EntityResponse,
    GraphEdgeListResponse,
    GraphEntityListResponse,
    GraphEpisodeListResponse,
    GroupsListResponse,
    NodeDetailsResponse,
    RetrieveResponse,
    WriteResponse,
)


# ---------------------------------------------------------------------------
# Sync client
# ---------------------------------------------------------------------------

class _GraphNamespace:
    """Nested namespace exposed as ``client.graph``. Reuses the parent
    client's httpx.Client so we don't open extra connections."""

    def __init__(self, client: "BreethClient") -> None:
        self._client = client

    def node_details(self, identifier: str) -> NodeDetailsResponse:
        data = self._client._get(f"/graph/nodes/{identifier}/details")
        return NodeDetailsResponse.model_validate(data)

    def list_entities(
        self,
        *,
        query: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> GraphEntityListResponse:
        params = merge_query({"query": query, "limit": limit, "offset": offset})
        data = self._client._get("/graph/entities", params=params)
        return GraphEntityListResponse.model_validate(data)

    def list_edges(
        self,
        *,
        query: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> GraphEdgeListResponse:
        params = merge_query({"query": query, "limit": limit, "offset": offset})
        data = self._client._get("/graph/edges", params=params)
        return GraphEdgeListResponse.model_validate(data)

    def list_episodes(
        self,
        *,
        query: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> GraphEpisodeListResponse:
        params = merge_query({"query": query, "limit": limit, "offset": offset})
        data = self._client._get("/graph/episodes", params=params)
        return GraphEpisodeListResponse.model_validate(data)


class BreethClient:
    """Synchronous client for the Breeth API.

    Args:
        api_key: ``ck_live_...`` token. Falls back to ``BREETH_API_KEY``
            then ``COGRAM_API_KEY``.
        base_url: Override the API host. Falls back to ``COGRAM_API_URL``
            then the SDK default (``https://api.thebreeth.com``).
        end_user_id: Optional ``X-End-User-Id`` header forwarded on
            every request. Useful when one API key fronts many end users.
        timeout: httpx timeout in seconds.
        http_client: Inject a pre-configured ``httpx.Client`` (for
            advanced transport, proxies, custom TLS, etc.). When supplied
            the SDK does not close it on ``__exit__``.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: Optional[str] = None,
        end_user_id: Optional[str] = None,
        timeout: float = DEFAULT_TIMEOUT,
        http_client: Optional[httpx.Client] = None,
    ) -> None:
        self._api_key = resolve_api_key(api_key)
        self._base_url = resolve_base_url(base_url)
        self._end_user_id = end_user_id
        self._headers = build_headers(self._api_key, end_user_id)
        self._owns_http = http_client is None
        self._http = http_client or httpx.Client(timeout=timeout)
        self.graph = _GraphNamespace(self)

    # ---- context manager ------------------------------------------------

    def __enter__(self) -> "BreethClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def close(self) -> None:
        if self._owns_http:
            self._http.close()

    # ---- low-level helpers ---------------------------------------------

    def _get(self, path: str, *, params: Optional[dict[str, Any]] = None) -> Any:
        response = self._http.get(
            build_url(self._base_url, path),
            headers=self._headers,
            params=params,
        )
        raise_for_status(response)
        return response.json()

    def _post(self, path: str, *, json: dict[str, Any]) -> Any:
        response = self._http.post(
            build_url(self._base_url, path),
            headers=self._headers,
            json=json,
        )
        raise_for_status(response)
        return response.json()

    # ---- public methods ------------------------------------------------

    def write(
        self,
        content: str,
        *,
        group_id: str = "default",
        source_description: str = "api",
        extract_intent: bool = False,
    ) -> WriteResponse:
        """Ingest a prose episode. The graph pipeline runs in the
        background server-side; this returns once the episode is
        persisted."""
        payload = {
            "content": content,
            "group_id": group_id,
            "source_description": source_description,
            "extract_intent": extract_intent,
        }
        data = self._post("/episodes", json=payload)
        return WriteResponse.model_validate(data)

    def retrieve(
        self,
        query: str,
        *,
        group_id: str = "default",
        limit: int = 10,
    ) -> RetrieveResponse:
        """Hybrid semantic + graph search. Returns edges plus, on
        first-person queries, the director profile block."""
        payload = {"query": query, "group_id": group_id, "limit": limit}
        data = self._post("/search", json=payload)
        return RetrieveResponse.model_validate(data)

    def entity(
        self,
        name: str,
        *,
        mode: Optional[EntityMode] = None,
        limit: Optional[int] = None,
    ) -> EntityResponse:
        """Look up an entity by name substring. ``mode`` selects which
        view to return (``narrative`` is the server default)."""
        params = merge_query({"mode": mode, "limit": limit})
        data = self._get(f"/entities/{name}", params=params)
        return EntityResponse.model_validate(data)

    def groups(
        self,
        *,
        query: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> GroupsListResponse:
        """List the memory groups visible to the current team / member."""
        params = merge_query({"query": query, "limit": limit, "offset": offset})
        data = self._get("/groups", params=params)
        return GroupsListResponse.model_validate(data)


# ---------------------------------------------------------------------------
# Async client
# ---------------------------------------------------------------------------

class _AsyncGraphNamespace:
    def __init__(self, client: "AsyncBreethClient") -> None:
        self._client = client

    async def node_details(self, identifier: str) -> NodeDetailsResponse:
        data = await self._client._get(f"/graph/nodes/{identifier}/details")
        return NodeDetailsResponse.model_validate(data)

    async def list_entities(
        self,
        *,
        query: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> GraphEntityListResponse:
        params = merge_query({"query": query, "limit": limit, "offset": offset})
        data = await self._client._get("/graph/entities", params=params)
        return GraphEntityListResponse.model_validate(data)

    async def list_edges(
        self,
        *,
        query: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> GraphEdgeListResponse:
        params = merge_query({"query": query, "limit": limit, "offset": offset})
        data = await self._client._get("/graph/edges", params=params)
        return GraphEdgeListResponse.model_validate(data)

    async def list_episodes(
        self,
        *,
        query: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> GraphEpisodeListResponse:
        params = merge_query({"query": query, "limit": limit, "offset": offset})
        data = await self._client._get("/graph/episodes", params=params)
        return GraphEpisodeListResponse.model_validate(data)


class AsyncBreethClient:
    """Asynchronous client for the Breeth API. Same surface as
    ``BreethClient`` but every method is a coroutine."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: Optional[str] = None,
        end_user_id: Optional[str] = None,
        timeout: float = DEFAULT_TIMEOUT,
        http_client: Optional[httpx.AsyncClient] = None,
    ) -> None:
        self._api_key = resolve_api_key(api_key)
        self._base_url = resolve_base_url(base_url)
        self._end_user_id = end_user_id
        self._headers = build_headers(self._api_key, end_user_id)
        self._owns_http = http_client is None
        self._http = http_client or httpx.AsyncClient(timeout=timeout)
        self.graph = _AsyncGraphNamespace(self)

    # ---- context manager ------------------------------------------------

    async def __aenter__(self) -> "AsyncBreethClient":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        if self._owns_http:
            await self._http.aclose()

    # ---- low-level helpers ---------------------------------------------

    async def _get(self, path: str, *, params: Optional[dict[str, Any]] = None) -> Any:
        response = await self._http.get(
            build_url(self._base_url, path),
            headers=self._headers,
            params=params,
        )
        raise_for_status(response)
        return response.json()

    async def _post(self, path: str, *, json: dict[str, Any]) -> Any:
        response = await self._http.post(
            build_url(self._base_url, path),
            headers=self._headers,
            json=json,
        )
        raise_for_status(response)
        return response.json()

    # ---- public methods ------------------------------------------------

    async def write(
        self,
        content: str,
        *,
        group_id: str = "default",
        source_description: str = "api",
        extract_intent: bool = False,
    ) -> WriteResponse:
        payload = {
            "content": content,
            "group_id": group_id,
            "source_description": source_description,
            "extract_intent": extract_intent,
        }
        data = await self._post("/episodes", json=payload)
        return WriteResponse.model_validate(data)

    async def retrieve(
        self,
        query: str,
        *,
        group_id: str = "default",
        limit: int = 10,
    ) -> RetrieveResponse:
        payload = {"query": query, "group_id": group_id, "limit": limit}
        data = await self._post("/search", json=payload)
        return RetrieveResponse.model_validate(data)

    async def entity(
        self,
        name: str,
        *,
        mode: Optional[EntityMode] = None,
        limit: Optional[int] = None,
    ) -> EntityResponse:
        params = merge_query({"mode": mode, "limit": limit})
        data = await self._get(f"/entities/{name}", params=params)
        return EntityResponse.model_validate(data)

    async def groups(
        self,
        *,
        query: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> GroupsListResponse:
        params = merge_query({"query": query, "limit": limit, "offset": offset})
        data = await self._get("/groups", params=params)
        return GroupsListResponse.model_validate(data)
