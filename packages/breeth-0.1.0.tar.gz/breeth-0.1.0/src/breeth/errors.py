"""Exception types raised by the Breeth SDK."""
from __future__ import annotations

from typing import Any, Optional


class BreethError(Exception):
    """Base error for every non-2xx response from the Breeth API.

    Attributes:
        status: HTTP status code (e.g. 401, 429, 500).
        slug: Stable machine-readable error code from the API
            (e.g. "quota_exceeded", "invalid_token"). May be None if
            the server returned a non-standard payload.
        message: Human-readable message from the API, falls back to a
            generic string.
        body: The full parsed response body for advanced inspection.
    """

    def __init__(
        self,
        message: str,
        *,
        status: int,
        slug: Optional[str] = None,
        body: Any = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.slug = slug
        self.message = message
        self.body = body

    def __repr__(self) -> str:
        return (
            f"BreethError(status={self.status}, slug={self.slug!r}, "
            f"message={self.message!r})"
        )
