"""Breeth: the official Python SDK for the Breeth memory API.

    from breeth import BreethClient

    breeth = BreethClient(api_key="ck_live_...")
    breeth.write("Recruiter prefers candidates with prior HR-tech roles.")
    results = breeth.retrieve("HR-tech background")
"""
from __future__ import annotations

from .client import AsyncBreethClient, BreethClient
from .errors import BreethError
from .types import (
    CacheStats,
    CogramTaskEnvelope,
    DirectorProfileBlock,
    EdgeHit,
    EntityEdgeRow,
    EntityEpisodeRow,
    EntityMode,
    EntityNarrativeRow,
    EntityResponse,
    EpisodeMentionRow,
    ExtractedCounts,
    GraphEdgeListResponse,
    GraphEdgeRow,
    GraphEntityListResponse,
    GraphEntityRow,
    GraphEpisodeListResponse,
    GraphEpisodeRow,
    GroupRow,
    GroupsListResponse,
    IntentSuggestion,
    NeighborRow,
    NodeDetailsResponse,
    PatternEvidence,
    RetrieveResponse,
    WriteResponse,
)

__version__ = "0.1.0"

__all__ = [
    "AsyncBreethClient",
    "BreethClient",
    "BreethError",
    "CacheStats",
    "CogramTaskEnvelope",
    "DirectorProfileBlock",
    "EdgeHit",
    "EntityEdgeRow",
    "EntityEpisodeRow",
    "EntityMode",
    "EntityNarrativeRow",
    "EntityResponse",
    "EpisodeMentionRow",
    "ExtractedCounts",
    "GraphEdgeListResponse",
    "GraphEdgeRow",
    "GraphEntityListResponse",
    "GraphEntityRow",
    "GraphEpisodeListResponse",
    "GraphEpisodeRow",
    "GroupRow",
    "GroupsListResponse",
    "IntentSuggestion",
    "NeighborRow",
    "NodeDetailsResponse",
    "PatternEvidence",
    "RetrieveResponse",
    "WriteResponse",
    "__version__",
]
