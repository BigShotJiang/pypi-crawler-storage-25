"""Ed25519 signing + verification using ``cryptography``.

Wire-compatible with the TypeScript SDK: signatures are computed over the
JCS-canonicalised receipt body with the ``signatures`` field omitted, and
encoded as base64url (no padding).
"""

from __future__ import annotations

import base64
from dataclasses import dataclass
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)

from .canonical import canonicalise_json
from .models import DraftReceipt, Receipt


@dataclass
class KeyPair:
    private_key: bytes  # 32 bytes raw
    public_key: bytes   # 32 bytes raw


def generate_keypair() -> KeyPair:
    sk = Ed25519PrivateKey.generate()
    pk = sk.public_key()
    return KeyPair(
        private_key=sk.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption(),
        ),
        public_key=pk.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        ),
    )


def public_key_to_base64(pub: bytes) -> str:
    return base64.urlsafe_b64encode(pub).rstrip(b"=").decode()


def public_key_from_base64(b64: str) -> bytes:
    padded = b64 + "=" * (-len(b64) % 4)
    return base64.urlsafe_b64decode(padded)


def _b64url(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def _b64url_decode(s: str) -> bytes:
    padded = s + "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(padded)


# ── Generic Ed25519 ────────────────────────────────────────────────────────


def sign_ed25519(payload: bytes | str, private_key: bytes) -> str:
    """Sign arbitrary bytes/string with an Ed25519 private key.

    Returns the base64url-encoded signature.
    """
    msg = payload.encode() if isinstance(payload, str) else payload
    sk = Ed25519PrivateKey.from_private_bytes(private_key)
    return _b64url(sk.sign(msg))


def verify_ed25519_signature(
    payload: bytes | str,
    signature_b64url: str,
    public_key: bytes,
) -> bool:
    """Verify an Ed25519 signature. Returns False on any failure (never raises)."""
    try:
        msg = payload.encode() if isinstance(payload, str) else payload
        pk = Ed25519PublicKey.from_public_bytes(public_key)
        pk.verify(_b64url_decode(signature_b64url), msg)
        return True
    except (InvalidSignature, ValueError):
        return False


# ── Receipt signing ────────────────────────────────────────────────────────


def _receipt_signing_payload(body: dict[str, Any]) -> bytes:
    return canonicalise_json(body).encode("utf-8")


def sign_receipt_as_buyer(draft: DraftReceipt, buyer_private_key: bytes) -> str:
    """Sign a draft receipt as the buyer. Returns base64url signature."""
    return sign_ed25519(_receipt_signing_payload(draft.to_signing_dict()), buyer_private_key)


def sign_receipt_as_seller(draft: DraftReceipt, seller_private_key: bytes) -> str:
    """Sign a draft receipt as the seller. Returns base64url signature."""
    return sign_ed25519(_receipt_signing_payload(draft.to_signing_dict()), seller_private_key)


@dataclass
class VerificationResult:
    valid: bool
    buyer_signature_valid: bool
    seller_signature_valid: bool
    issuer_signature_valid: bool | None
    errors: list[str]


def verify_receipt_signatures(
    receipt: Receipt,
    buyer_public_key: bytes,
    seller_public_key: bytes,
    issuer_public_key: bytes | None = None,
) -> VerificationResult:
    """Verify all signatures on a finalised receipt offline.

    Both buyer and seller sigs are computed over the *draft* body (the receipt
    with ``outcome='draft'`` and no ``finalisedAt``). We reconstruct that body
    here so runtime metadata changes don't invalidate signatures.
    """
    errors: list[str] = []
    body = receipt.to_dict()
    body.pop("signatures", None)
    body["outcome"] = "draft"
    body.pop("finalisedAt", None)
    payload = _receipt_signing_payload(body)

    buyer_ok = verify_ed25519_signature(payload, receipt.signatures.buyer, buyer_public_key)
    if not buyer_ok:
        errors.append("Invalid buyer signature")

    seller_ok = verify_ed25519_signature(payload, receipt.signatures.seller, seller_public_key)
    if not seller_ok:
        errors.append("Invalid seller signature")

    issuer_ok: bool | None = None
    if issuer_public_key is not None and receipt.signatures.issuer:
        issuer_ok = verify_ed25519_signature(
            payload, receipt.signatures.issuer, issuer_public_key,
        )
        if not issuer_ok:
            errors.append("Invalid issuer signature")

    return VerificationResult(
        valid=buyer_ok and seller_ok and (issuer_ok is not False),
        buyer_signature_valid=buyer_ok,
        seller_signature_valid=seller_ok,
        issuer_signature_valid=issuer_ok,
        errors=errors,
    )
