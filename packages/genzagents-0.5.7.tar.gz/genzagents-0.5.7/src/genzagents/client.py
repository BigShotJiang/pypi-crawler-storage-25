"""HTTP client for the GenZAgents API.

Wraps the same REST surface as the TS SDK. Synchronous by default; an async
twin can be added later if there's demand.

Quick start:

    client = GenZAgents(api_key=os.environ["GENZ_API_KEY"])
    draft = client.receipts.submit_draft(my_draft)
    receipt = client.receipts.countersign(draft.id, my_seller_signature)
    lookup = client.buyer.lookup_agent("did:genz:bafy...")
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx


@dataclass
class GenZAgentsClientOptions:
    api_key: str | None = None
    base_url: str = "https://genzagents-api.lemonflower-ad09ed88.uksouth.azurecontainerapps.io"
    timeout_seconds: float = 30.0


class _ReceiptsAPI:
    def __init__(self, http: httpx.Client) -> None:
        self._http = http

    def submit_draft(self, draft: Any) -> dict[str, Any]:
        body = draft.to_signing_dict() if hasattr(draft, "to_signing_dict") else dict(draft)
        body["signatures"] = {"buyer": getattr(draft, "buyer_signature", "")}
        return _unwrap(self._http.post("/v1/receipts/draft", json=body))

    def countersign(self, receipt_id: str, signature: str) -> dict[str, Any]:
        return _unwrap(
            self._http.post(
                f"/v1/receipts/{receipt_id}/countersign",
                json={"signature": signature, "outcome": "delivered"},
            )
        )

    def get(self, receipt_id: str) -> dict[str, Any]:
        return _unwrap(self._http.get(f"/v1/receipts/{receipt_id}"))

    def verify(self, receipt_id: str) -> dict[str, Any]:
        return _unwrap(self._http.get(f"/v1/receipts/{receipt_id}/verify"))

    def list_mine(self, limit: int = 50) -> list[dict[str, Any]]:
        data = _unwrap(self._http.get("/v1/receipts/mine", params={"limit": limit}))
        return list(data) if isinstance(data, list) else []

    def dispute(self, receipt_id: str, reason: str, evidence: str | None = None) -> dict[str, Any]:
        return _unwrap(
            self._http.post(
                f"/v1/receipts/{receipt_id}/dispute",
                json={"reason": reason, "evidence": evidence},
            )
        )


class _BuyerAPI:
    def __init__(self, http: httpx.Client) -> None:
        self._http = http

    def lookup_agent(self, query: str, query_type: str = "by-did") -> dict[str, Any]:
        return _unwrap(
            self._http.post(
                "/v1/buyer/lookup",
                json={"query": query, "queryType": query_type},
            )
        )

    def watchlist_add(self, agent_id: str) -> dict[str, Any]:
        return _unwrap(self._http.post("/v1/buyer/watchlist", json={"agentId": agent_id}))

    def evidence_pack(
        self,
        framework: str,
        agent_did: str,
        period_start: str,
        period_end: str,
        scope_notes: str | None = None,
    ) -> dict[str, Any]:
        return _unwrap(
            self._http.post(
                "/v1/buyer/evidence-pack",
                json={
                    "framework": framework,
                    "agentDid": agent_did,
                    "periodStart": period_start,
                    "periodEnd": period_end,
                    "scopeNotes": scope_notes,
                },
            )
        )

    def zk_rollup(
        self,
        seller_did: str,
        category: str,
        period_start: str,
        period_end: str,
        outcome: str = "delivered",
    ) -> dict[str, Any]:
        return _unwrap(
            self._http.post(
                "/v1/buyer/zk-rollup",
                json={
                    "sellerDid": seller_did,
                    "category": category,
                    "outcome": outcome,
                    "periodStart": period_start,
                    "periodEnd": period_end,
                },
            )
        )


class _AgentsAPI:
    def __init__(self, http: httpx.Client) -> None:
        self._http = http

    def list_mine(self) -> list[dict[str, Any]]:
        data = _unwrap(self._http.get("/v1/agents", params={"mine": "true"}))
        return list(data) if isinstance(data, list) else []

    def get(self, did: str) -> dict[str, Any]:
        return _unwrap(self._http.get(f"/v1/agents/{did}"))

    def trust_score(self, did: str) -> dict[str, Any]:
        return _unwrap(self._http.get(f"/v1/agents/{did}/trust-score"))


class GenZAgents:
    """Top-level client for the GenZAgents REST API."""

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str = "https://genzagents-api.lemonflower-ad09ed88.uksouth.azurecontainerapps.io",
        timeout_seconds: float = 30.0,
    ) -> None:
        headers: dict[str, str] = {"User-Agent": "genzagents-py/0.1.0"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        self._http = httpx.Client(
            base_url=base_url,
            headers=headers,
            timeout=timeout_seconds,
        )
        self.receipts = _ReceiptsAPI(self._http)
        self.buyer = _BuyerAPI(self._http)
        self.agents = _AgentsAPI(self._http)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> GenZAgents:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


def _unwrap(response: httpx.Response) -> Any:
    """Raise on HTTP error, then unwrap the ``{ ok, data }`` envelope."""
    if response.status_code >= 400:
        try:
            body = response.json()
            err = body.get("error", {})
            msg = err.get("message", response.text)
            code = err.get("code", "HTTP_ERROR")
        except (ValueError, AttributeError):
            msg = response.text or response.reason_phrase
            code = "HTTP_ERROR"
        raise GenZAgentsError(f"[{code}] {msg}", status_code=response.status_code)
    body = response.json()
    if isinstance(body, dict) and "data" in body:
        return body["data"]
    return body


class GenZAgentsError(Exception):
    """API call failed."""

    def __init__(self, message: str, status_code: int = 0) -> None:
        super().__init__(message)
        self.status_code = status_code
