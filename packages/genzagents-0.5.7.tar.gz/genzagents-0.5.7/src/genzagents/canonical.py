"""JCS (RFC 8785) canonicalisation — Python equivalent of the TS SDK.

Conformance:
  - Object keys sorted lexicographically by UTF-16 code unit (RFC 8785 §3.2.3)
  - No insignificant whitespace
  - Numbers serialised per ECMA-262 7.1.12.1 (RFC 8785 §3.2.2.3)
    — NaN, +Inf, -Inf, and -0 are normalised or rejected
  - Strings escaped per RFC 8259 §7 with lowercase hex (RFC 8785 §3.2.2.2)
  - ``None`` values, callables, and undefined-ish values are rejected
"""

from __future__ import annotations

import math
from typing import Any


def canonicalise_json(value: Any) -> str:
    """Return the JCS canonical form of ``value`` as a UTF-8 string."""
    return _canonicalise(value)


def _canonicalise(value: Any) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return _serialise_number(value)
    if isinstance(value, str):
        return _json_escape_string(value)
    if isinstance(value, (list, tuple)):
        parts = [_canonicalise(el) for el in value]
        return "[" + ",".join(parts) + "]"
    if isinstance(value, dict):
        # Drop ``None`` values per spec convention (matches TS impl)
        keys = sorted([k for k, v in value.items() if v is not None], key=_utf16_key)
        parts = [f"{_json_escape_string(k)}:{_canonicalise(value[k])}" for k in keys]
        return "{" + ",".join(parts) + "}"
    raise TypeError(f"JCS: unsupported value of type {type(value).__name__}")


def _serialise_number(n: int | float) -> str:
    if isinstance(n, bool):
        # bool is subclass of int — handled separately above
        raise TypeError("unreachable")
    if isinstance(n, float):
        if math.isnan(n) or math.isinf(n):
            raise ValueError(f"JCS: non-finite number {n} cannot be canonicalised")
        # Normalise -0.0 to 0
        if n == 0.0:
            return "0"
        # Match ECMA-262 ToString for finite floats: Python's repr is close but not
        # identical; for receipt-format values (timestamps as strings, integer
        # amounts as strings) this matters less. Use the JSON dumps shortest form.
        import json as _json

        return _json.dumps(n)
    return str(int(n))


def _utf16_key(s: str) -> tuple[int, ...]:
    return tuple(s.encode("utf-16-be")[i] << 8 | s.encode("utf-16-be")[i + 1]
                 for i in range(0, len(s.encode("utf-16-be")), 2))


def _json_escape_string(s: str) -> str:
    out: list[str] = ['"']
    for ch in s:
        code = ord(ch)
        if code == 0x22:  # "
            out.append('\\"')
        elif code == 0x5C:  # \
            out.append("\\\\")
        elif code == 0x08:
            out.append("\\b")
        elif code == 0x09:
            out.append("\\t")
        elif code == 0x0A:
            out.append("\\n")
        elif code == 0x0C:
            out.append("\\f")
        elif code == 0x0D:
            out.append("\\r")
        elif code < 0x20:
            out.append(f"\\u{code:04x}")
        else:
            out.append(ch)
    out.append('"')
    return "".join(out)
