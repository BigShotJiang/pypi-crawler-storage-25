"""Builder API for drafting and countersigning receipts.

Mirrors the TS ``ReceiptBuilder`` shape so the two SDKs feel identical.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, cast

import ulid

from .models import (
    DraftReceipt,
    Party,
    PartyType,
    PrivacyMode,
    Receipt,
    ReceiptOutcome,
    Settlement,
    SettlementRail,
    Signatures,
    Task,
    TaskCategory,
)
from .signing import sign_receipt_as_buyer, sign_receipt_as_seller


class ReceiptBuilder:
    """Fluent builder for a draft receipt.

    Usage:

        draft = (
            ReceiptBuilder(seller_did="did:genz:bafy...")
            .with_buyer("did:genz:bafy_buyer")
            .with_task(category="code-review", deliverable_hash="sha256:...")
            .with_settlement(amount="50", currency="GBP", rail="stripe")
            .with_privacy("private")
            .build(buyer_private_key=BUYER_PRIVKEY)
        )
    """

    def __init__(
        self,
        seller_did: str,
        seller_owner_human_id: str | None = None,
        seller_handle: str | None = None,
    ) -> None:
        self._seller = Party(
            type="agent",
            id=seller_did,
            owner_human_id=seller_owner_human_id,
            display_handle=seller_handle,
        )
        self._buyer: Party | None = None
        self._task: Task | None = None
        self._settlement: Settlement | None = None
        self._privacy: PrivacyMode = "private"
        self._evidence_pointer: str | None = None
        self._zk_commitment: str | None = None
        self._extensions: dict[str, Any] = {}

    def with_buyer(
        self,
        buyer_id: str,
        buyer_type: PartyType = "agent",
        owner_human_id: str | None = None,
        display_handle: str | None = None,
    ) -> "ReceiptBuilder":
        self._buyer = Party(
            type=buyer_type,
            id=buyer_id,
            owner_human_id=owner_human_id,
            display_handle=display_handle,
        )
        return self

    def with_task(
        self,
        category: TaskCategory,
        deliverable_hash: str,
        description: str | None = None,
        external_ref: str | None = None,
    ) -> "ReceiptBuilder":
        self._task = Task(
            category=category,
            deliverable_hash=deliverable_hash,
            description=description,
            external_ref=external_ref,
        )
        return self

    def with_settlement(
        self,
        amount: str | None = None,
        currency: str | None = None,
        rail: SettlementRail | None = None,
        tx_ref: str | None = None,
    ) -> "ReceiptBuilder":
        self._settlement = Settlement(
            amount=amount, currency=currency, rail=rail, tx_ref=tx_ref,
        )
        return self

    def with_privacy(self, mode: PrivacyMode) -> "ReceiptBuilder":
        self._privacy = mode
        return self

    def with_evidence_pointer(self, url: str) -> "ReceiptBuilder":
        self._evidence_pointer = url
        return self

    def with_zk_commitment(self, commitment: str) -> "ReceiptBuilder":
        self._zk_commitment = commitment
        return self

    def with_extension(self, key: str, value: Any) -> "ReceiptBuilder":
        self._extensions[key] = value
        return self

    def build(self, buyer_private_key: bytes) -> DraftReceipt:
        if self._buyer is None:
            raise ValueError("Buyer is required (call .with_buyer)")
        if self._task is None:
            raise ValueError("Task is required (call .with_task)")

        # In private mode we strip task.description and externalRef before
        # signing so the signed bytes match what third parties see. The full
        # values are kept locally only.
        task = self._task
        if self._privacy != "public":
            task = Task(
                category=task.category,
                deliverable_hash=task.deliverable_hash,
                description=None,
                external_ref=None,
            )

        receipt_id = f"rcpt_{ulid.new().str}"
        issued_at = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

        # Build the body that needs to be signed first (no signature yet)
        draft = DraftReceipt(
            version="0.1",
            id=receipt_id,
            issued_at=issued_at,
            buyer=self._buyer,
            seller=self._seller,
            task=task,
            settlement=self._settlement,
            outcome="draft",
            privacy=self._privacy,
            buyer_signature="",
            evidence_pointer=self._evidence_pointer,
            zk_commitment=self._zk_commitment,
            extensions=self._extensions,
        )
        sig = sign_receipt_as_buyer(draft, buyer_private_key)
        draft.buyer_signature = sig
        return draft


def countersign_receipt(
    draft: DraftReceipt,
    seller_private_key: bytes,
    outcome: ReceiptOutcome = "delivered",
) -> Receipt:
    """Counterparty signs and finalises the draft.

    Wire detail: the seller signs the *same* canonical bytes the buyer signed
    (the draft body, with ``outcome='draft'`` and no ``finalisedAt``). The
    finalised receipt presents updated metadata but the signatures cover the
    draft. ``verify_receipt_signatures`` reconstructs the draft body when
    verifying.
    """
    seller_sig = sign_receipt_as_seller(draft, seller_private_key)
    finalised_at = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    return Receipt(
        version=draft.version,
        id=draft.id,
        issued_at=draft.issued_at,
        finalised_at=finalised_at,
        buyer=draft.buyer,
        seller=draft.seller,
        task=draft.task,
        settlement=draft.settlement,
        outcome=cast(ReceiptOutcome, outcome),
        privacy=draft.privacy,
        signatures=Signatures(buyer=draft.buyer_signature, seller=seller_sig),
        evidence_pointer=draft.evidence_pointer,
        zk_commitment=draft.zk_commitment,
        extensions=draft.extensions,
    )
