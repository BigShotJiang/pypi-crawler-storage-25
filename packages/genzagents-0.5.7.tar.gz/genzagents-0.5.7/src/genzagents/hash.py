"""Hashing utilities — SHA-256 over UTF-8 NFC-normalised bytes."""

from __future__ import annotations

import hashlib
import unicodedata


def hash_deliverable(content: str | bytes) -> str:
    """Hash a deliverable for use in ``receipt.task.deliverable_hash``.

    Mirrors the TS SDK: UTF-8 NFC normalisation for strings, raw bytes
    otherwise. Returns ``sha256:<64-hex>``.
    """
    if isinstance(content, str):
        normalised = unicodedata.normalize("NFC", content).encode("utf-8")
    else:
        normalised = content
    digest = hashlib.sha256(normalised).hexdigest()
    return f"sha256:{digest}"


def verify_deliverable_hash(content: str | bytes, expected: str) -> bool:
    return hash_deliverable(content) == expected
