"""Receipt-Format-v0.1 data models — Python equivalents of the TS SDK.

Mirror the JSON Schema at https://spec.genzagents.io/receipt/v0.1.json.
Models are dataclasses for zero-dep simplicity; serialisation goes through
plain ``to_dict`` / ``from_dict`` to keep canonicalisation deterministic.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, TypedDict, cast

PartyType = Literal["agent", "human", "service"]
PrivacyMode = Literal["public", "private", "zk"]
ReceiptOutcome = Literal["draft", "delivered", "disputed", "rejected", "refunded"]
SettlementRail = Literal["stripe", "x402", "skyfire", "coinbase", "paypal", "off-rail"]
OnChainNetwork = Literal["base", "ethereum", "optimism", "arbitrum", "solana"]

TaskCategory = Literal[
    "code-review",
    "code-write",
    "content-write",
    "content-edit",
    "research",
    "data-analysis",
    "ops",
    "sdr-outbound",
    "customer-support",
    "trade",
    "translation",
    "design",
    "video",
    "audio",
    "scrape",
    "audit",
    "compliance-check",
    "other",
]

DisputeVia = Literal["llm-judge", "human-reviewer", "arbitrator-panel", "mutual-resolution"]


@dataclass
class Party:
    type: PartyType
    id: str
    owner_human_id: str | None = None
    public_key: str | None = None
    display_handle: str | None = None

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"type": self.type, "id": self.id}
        if self.owner_human_id is not None:
            out["ownerHumanId"] = self.owner_human_id
        if self.public_key is not None:
            out["publicKey"] = self.public_key
        if self.display_handle is not None:
            out["displayHandle"] = self.display_handle
        return out

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Party:
        return cls(
            type=cast(PartyType, data["type"]),
            id=data["id"],
            owner_human_id=data.get("ownerHumanId"),
            public_key=data.get("publicKey"),
            display_handle=data.get("displayHandle"),
        )


@dataclass
class Task:
    category: TaskCategory
    deliverable_hash: str
    description: str | None = None
    external_ref: str | None = None

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "category": self.category,
            "deliverableHash": self.deliverable_hash,
        }
        if self.description is not None:
            out["description"] = self.description
        if self.external_ref is not None:
            out["externalRef"] = self.external_ref
        return out

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Task:
        return cls(
            category=cast(TaskCategory, data["category"]),
            deliverable_hash=data["deliverableHash"],
            description=data.get("description"),
            external_ref=data.get("externalRef"),
        )


@dataclass
class Settlement:
    amount: str | None = None
    currency: str | None = None
    rail: SettlementRail | None = None
    tx_ref: str | None = None

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {}
        if self.amount is not None:
            out["amount"] = self.amount
        if self.currency is not None:
            out["currency"] = self.currency
        if self.rail is not None:
            out["rail"] = self.rail
        if self.tx_ref is not None:
            out["txRef"] = self.tx_ref
        return out

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Settlement:
        return cls(
            amount=data.get("amount"),
            currency=data.get("currency"),
            rail=cast("SettlementRail | None", data.get("rail")),
            tx_ref=data.get("txRef"),
        )


@dataclass
class DisputeOutcome:
    ruled_for: Literal["buyer", "seller"]
    via: DisputeVia
    reasoning: str
    resolved_at: str
    evidence_used: list[str] = field(default_factory=list)


@dataclass
class OnChainAnchor:
    chain: OnChainNetwork
    contract_address: str
    block_number: int
    tx_hash: str


@dataclass
class Signatures:
    buyer: str
    seller: str
    issuer: str | None = None

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"buyer": self.buyer, "seller": self.seller}
        if self.issuer is not None:
            out["issuer"] = self.issuer
        return out


class ReceiptDict(TypedDict, total=False):
    """Serialised receipt as it appears on the wire (camelCase keys)."""

    version: str
    id: str
    issuedAt: str
    finalisedAt: str | None
    buyer: dict[str, Any]
    seller: dict[str, Any]
    task: dict[str, Any]
    settlement: dict[str, Any] | None
    outcome: ReceiptOutcome
    privacy: PrivacyMode
    evidencePointer: str | None
    zkCommitment: str | None
    onChainAnchor: dict[str, Any] | None
    signatures: dict[str, str]
    extensions: dict[str, Any]


@dataclass
class Receipt:
    """Finalised receipt. Mirrors TS ``Receipt``."""

    version: Literal["0.1"]
    id: str
    issued_at: str
    finalised_at: str | None
    buyer: Party
    seller: Party
    task: Task
    settlement: Settlement | None
    outcome: ReceiptOutcome
    privacy: PrivacyMode
    signatures: Signatures
    evidence_pointer: str | None = None
    zk_commitment: str | None = None
    on_chain_anchor: OnChainAnchor | None = None
    extensions: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> ReceiptDict:
        out: dict[str, Any] = {
            "version": self.version,
            "id": self.id,
            "issuedAt": self.issued_at,
            "buyer": self.buyer.to_dict(),
            "seller": self.seller.to_dict(),
            "task": self.task.to_dict(),
            "outcome": self.outcome,
            "privacy": self.privacy,
            "signatures": self.signatures.to_dict(),
        }
        if self.finalised_at is not None:
            out["finalisedAt"] = self.finalised_at
        if self.settlement is not None:
            out["settlement"] = self.settlement.to_dict()
        if self.evidence_pointer is not None:
            out["evidencePointer"] = self.evidence_pointer
        if self.zk_commitment is not None:
            out["zkCommitment"] = self.zk_commitment
        if self.on_chain_anchor is not None:
            out["onChainAnchor"] = {
                "chain": self.on_chain_anchor.chain,
                "contractAddress": self.on_chain_anchor.contract_address,
                "blockNumber": self.on_chain_anchor.block_number,
                "txHash": self.on_chain_anchor.tx_hash,
            }
        if self.extensions:
            out["extensions"] = self.extensions
        return cast(ReceiptDict, out)


@dataclass
class DraftReceipt:
    """A draft (unsigned-by-seller) receipt — output of ``ReceiptBuilder.build``."""

    version: Literal["0.1"]
    id: str
    issued_at: str
    buyer: Party
    seller: Party
    task: Task
    settlement: Settlement | None
    outcome: Literal["draft"]
    privacy: PrivacyMode
    buyer_signature: str
    evidence_pointer: str | None = None
    zk_commitment: str | None = None
    extensions: dict[str, Any] = field(default_factory=dict)

    def to_signing_dict(self) -> dict[str, Any]:
        """Receipt body used for signature computation — signatures field omitted."""
        out: dict[str, Any] = {
            "version": self.version,
            "id": self.id,
            "issuedAt": self.issued_at,
            "buyer": self.buyer.to_dict(),
            "seller": self.seller.to_dict(),
            "task": self.task.to_dict(),
            "outcome": self.outcome,
            "privacy": self.privacy,
        }
        if self.settlement is not None:
            out["settlement"] = self.settlement.to_dict()
        if self.evidence_pointer is not None:
            out["evidencePointer"] = self.evidence_pointer
        if self.zk_commitment is not None:
            out["zkCommitment"] = self.zk_commitment
        if self.extensions:
            out["extensions"] = self.extensions
        return out
