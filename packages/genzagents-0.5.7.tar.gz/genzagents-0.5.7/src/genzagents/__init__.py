"""GenZAgents Python SDK — issue, sign, and verify AI agent work receipts.

Quick start:

    from genzagents import GenZAgents, ReceiptBuilder, hash_deliverable

    client = GenZAgents(api_key=os.environ["GENZ_API_KEY"])
    draft = (
        ReceiptBuilder(seller_did="did:genz:bafy...")
        .with_buyer("did:genz:bafy_buyer")
        .with_task(category="code-review", deliverable_hash=hash_deliverable("hello"))
        .with_settlement(amount="50", currency="GBP", rail="stripe")
        .with_privacy("private")
        .build()
    )
    receipt = client.receipts.submit_draft(draft)
"""

from .canonical import canonicalise_json
from .client import GenZAgents
from .hash import hash_deliverable, verify_deliverable_hash
from .models import (
    DraftReceipt,
    OnChainAnchor,
    Party,
    PrivacyMode,
    Receipt,
    ReceiptOutcome,
    Settlement,
    SettlementRail,
    Signatures,
    Task,
    TaskCategory,
)
from .receipt_builder import ReceiptBuilder, countersign_receipt
from .signing import (
    KeyPair,
    generate_keypair,
    public_key_from_base64,
    public_key_to_base64,
    sign_ed25519,
    sign_receipt_as_buyer,
    sign_receipt_as_seller,
    verify_ed25519_signature,
    verify_receipt_signatures,
)

__version__ = "0.1.0"

__all__ = [
    # Models
    "DraftReceipt",
    "OnChainAnchor",
    "Party",
    "PrivacyMode",
    "Receipt",
    "ReceiptOutcome",
    "Settlement",
    "SettlementRail",
    "Signatures",
    "Task",
    "TaskCategory",
    # Builder + countersign
    "ReceiptBuilder",
    "countersign_receipt",
    # Hashing + canonicalisation
    "hash_deliverable",
    "verify_deliverable_hash",
    "canonicalise_json",
    # Signing
    "KeyPair",
    "generate_keypair",
    "public_key_from_base64",
    "public_key_to_base64",
    "sign_ed25519",
    "verify_ed25519_signature",
    "sign_receipt_as_buyer",
    "sign_receipt_as_seller",
    "verify_receipt_signatures",
    # API client
    "GenZAgents",
]
