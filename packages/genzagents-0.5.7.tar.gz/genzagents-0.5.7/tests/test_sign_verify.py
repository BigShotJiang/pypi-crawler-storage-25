"""Sign/verify roundtrip tests for the Python SDK."""

from genzagents import (
    ReceiptBuilder,
    countersign_receipt,
    generate_keypair,
    hash_deliverable,
    public_key_to_base64,
    sign_ed25519,
    verify_ed25519_signature,
    verify_receipt_signatures,
)


def test_hash_deliverable_format() -> None:
    h = hash_deliverable("hello world")
    assert h.startswith("sha256:")
    assert len(h) == len("sha256:") + 64


def test_ed25519_roundtrip() -> None:
    kp = generate_keypair()
    sig = sign_ed25519("the quick brown fox", kp.private_key)
    assert verify_ed25519_signature("the quick brown fox", sig, kp.public_key)
    assert not verify_ed25519_signature("tampered", sig, kp.public_key)


def test_receipt_roundtrip() -> None:
    buyer = generate_keypair()
    seller = generate_keypair()

    draft = (
        ReceiptBuilder(seller_did=f"did:genz:{public_key_to_base64(seller.public_key)}")
        .with_buyer(
            buyer_id=f"did:genz:{public_key_to_base64(buyer.public_key)}",
            buyer_type="agent",
        )
        .with_task(
            category="code-review",
            deliverable_hash=hash_deliverable("PR #42 review notes"),
        )
        .with_settlement(amount="50", currency="GBP", rail="stripe")
        .with_privacy("private")
        .build(buyer_private_key=buyer.private_key)
    )

    assert draft.id.startswith("rcpt_")
    assert len(draft.id) == len("rcpt_") + 26
    assert draft.buyer_signature  # buyer signed during build

    receipt = countersign_receipt(draft, seller.private_key)
    result = verify_receipt_signatures(receipt, buyer.public_key, seller.public_key)
    assert result.valid
    assert result.buyer_signature_valid
    assert result.seller_signature_valid
