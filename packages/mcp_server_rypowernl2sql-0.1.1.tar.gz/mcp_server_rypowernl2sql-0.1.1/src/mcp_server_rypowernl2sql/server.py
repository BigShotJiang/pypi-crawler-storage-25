import json
import httpx
from typing import Any
import pymysql
import csv
from mcp.server.fastmcp import FastMCP

# 初始化 MCP 服务器
mcp = FastMCP("SQLServer")


@mcp.tool()
async def sql_inter(sql_query: str):
    """
    查询本地MySQL数据库，通过运行一段SQL代码来进行数据库查询。
    :param sql_query: 字符串形式的SQL查询语句，用于执行对MySQL中 Gongzhi_RAG2SQL 数据库中各张表进行查询，
    并获得各表中的各类相关信息
    :return: sql_queryz在MySQL中运行结果。
    """

    connection = pymysql.connect(
        host="localhost",
        user="root",
        password="guwenfei922716",
        database="Gongzhi_RAG2SQL",
        charset="utf8",
    )

    try:
        with  connection.cursor() as cursor:
            # SQL 查询语句
            sql = sql_query
            cursor.execute(sql)

            # 获取查询结果
            result = cursor.fetchall()

    finally:
        connection.close()

    return json.dumps(result)

@mcp.tool()
async def export_table_to_csv(table_name: str, output_file: str):
    """
    将 MySQL 数据库中的某个表导出为 CSV 文件。
    :param table_name: 需要导出的表名
    :return: output_file：输出的 CSV 文件路径。
    """
    # 连接 MySQL 数据库
    connection = pymysql.connect(
        host="localhost",
        user="root",
        password="guwenfei922716",
        database="Gongzhi_RAG2SQL",
        charset="utf8",
    )

    try:
        with  connection.cursor() as cursor:
            # 查询数据表的所有数据
            query = f"SELECT * FROM {table_name}"
            cursor.execute(query)

            # 获取所有列名
            column_names = [desc[0] for desc in cursor.description]

            # 获取查询结果
            rows = cursor.fetchall()

            # 将数据写入 CSV 文件
            with open(output_file, 'w', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)

                # 写入表头
                writer.writerow(column_names)

                # 写入数据
                writer.writerows(rows)
            print(f"数据表 {table_name} 已保存到 {output_file}")
    except Exception as e:
        print(f"导出数据表 {table_name} 到 CSV 文件时出错：{e}")

    finally:
        connection.close()

def main():
    """
    MCP 服务器入口函数
    """
    mcp.run(transport='stdio')


if __name__ == "__main__":
    main()