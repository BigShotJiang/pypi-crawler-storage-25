# postcraftin

AI-powered LinkedIn post generator using local LLMs via Ollama. Personalized ghostwriter with onboarding profile, Few-Shot prompting, and CLI interface.

## Features

- **Local LLMs** — runs fully on your machine via Ollama, no API costs, no data leaks
- **Personalized profiles** — onboarding wizard captures your role, audience, tone, and writing style
- **Few-Shot prompting** — provide example posts to calibrate the output to your voice
- **Post length control** — kurz (150–500), mittel (1.200–1.500), lang (1.900–2.500 Zeichen)
- **Multiple profiles** — manage different personas or clients

## Requirements

- Python 3.10+
- [Ollama](https://ollama.com) running locally

## Installation

```bash
pip install postcraftin
```

## Usage

```bash
# Create a profile (interactive wizard)
postcraftin onboard --name myprofile

# Generate a LinkedIn post
postcraftin generate --topic "The future of AI in software development"

# With options
postcraftin generate --topic "My topic" --profile myprofile --length lang

# List all profiles
postcraftin list-profiles
```

## Default Model

`qwen3.5:2b` — pull it with:

```bash
ollama pull qwen3.5:2b
```

## License

MIT