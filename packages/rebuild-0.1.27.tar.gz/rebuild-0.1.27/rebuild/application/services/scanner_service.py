from __future__ import annotations
import ast
import hashlib
import json
import re
import subprocess
from pathlib import Path
from typing import Dict, List, Optional

import httpx
import yaml

from ...domain.models import WalkConfig
from ...domain.endpoint import Endpoint
from .base import Service

class ScannerService(Service[Path, List[Endpoint]]):
    """
    Service for discovering API endpoints in a repository.

    Diff-aware caching (Sprint 3 / 2026-05-07)
    ------------------------------------------
    When a single ``ScannerService`` instance scans the same repository at
    multiple commits (the typical ``rebuild walk`` use case), the AST parse +
    decorator inspection of unchanged Python files is the dominant cost. To
    skip redundant work we cache discovered endpoints by **content hash**:

      * key:   SHA-1 of the file's bytes (cheap; ~1 µs/KB)
      * value: ``List[Endpoint]`` discovered in that file

    Across N commits where ~5% of files change per day, this typically yields
    a 10–20× speedup on the FastAPI-route scan path. See ``scripts/
    benchmark_walk.py`` for measurements.

    The cache is process-local and reset by :meth:`reset_cache`. There is no
    on-disk persistence; that is reserved for a later phase (Sprint 5+).
    """
    def __init__(self, config: WalkConfig):
        self.config = config
        # Content-hash → endpoints discovered in that file.
        self._file_cache: Dict[str, List[Endpoint]] = {}
        self._cache_hits = 0
        self._cache_misses = 0

    # ── Cache control ────────────────────────────────────────────────────

    def reset_cache(self) -> None:
        """Drop all cached file→endpoints mappings and reset hit/miss counters."""
        self._file_cache.clear()
        self._cache_hits = 0
        self._cache_misses = 0

    @property
    def cache_stats(self) -> Dict[str, int]:
        """Return ``{"hits", "misses", "size"}`` for the file cache."""
        return {
            "hits": self._cache_hits,
            "misses": self._cache_misses,
            "size": len(self._file_cache),
        }

    def execute(self, repo: Path) -> List[Endpoint]:
        endpoints: List[Endpoint] = []

        # 1. deta scan
        deta_endpoints = self._scan_via_deta(repo)
        if deta_endpoints:
            endpoints.extend(deta_endpoints)

        # 2. OpenAPI
        openapi_endpoints = self._scan_via_openapi(self.config.base_url, repo)
        if openapi_endpoints:
            existing = {(e.method, e.path) for e in endpoints}
            for ep in openapi_endpoints:
                if (ep.method, ep.path) not in existing:
                    endpoints.append(ep)
                    existing.add((ep.method, ep.path))

        # 3. Static FastAPI route scan (source-level fallback)
        static_routes = self._scan_via_fastapi_routes(repo)
        if static_routes:
            existing = {(e.method, e.path) for e in endpoints}
            for ep in static_routes:
                if (ep.method, ep.path) not in existing:
                    endpoints.append(ep)
                    existing.add((ep.method, ep.path))

        # 4. Fallback: docker-compose Traefik labels
        if not endpoints:
            endpoints.extend(self._scan_via_compose_labels(repo))

        # 5. Minimalny fallback: /api/health
        if not endpoints:
            endpoints.append(Endpoint(method="GET", path="/api/health", base_url=self.config.base_url))

        return endpoints

    def _scan_via_deta(self, repo: Path) -> List[Endpoint]:
        try:
            result = subprocess.run(
                ["deta", "scan", str(repo), "--formats", "json"],
                capture_output=True, text=True, timeout=30,
            )
            if result.returncode != 0:
                return []
            data = json.loads(result.stdout)
            return self._ports_to_endpoints(data, self.config.base_url)
        except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError):
            return []

    def _scan_via_fastapi_routes(self, repo: Path) -> List[Endpoint]:
        endpoints: List[Endpoint] = []
        seen: set = set()

        for py_file in self._iter_source_python_files(repo):
            for ep in self._endpoints_for_python_file(py_file):
                key = (ep.method, ep.path)
                if key in seen:
                    continue
                seen.add(key)
                endpoints.append(ep)

        return endpoints

    def _endpoints_for_python_file(self, py_file: Path) -> List[Endpoint]:
        """Return endpoints discovered in *py_file*, using the content-hash cache.

        The cache key is the SHA-1 of the file's raw bytes — stable across
        ``git checkout`` switches that don't actually change the file. On a
        cache hit, the AST parse + decorator walk are entirely skipped.
        """
        try:
            content = py_file.read_bytes()
        except Exception:
            return []

        content_sha = hashlib.sha1(content).hexdigest()
        cached = self._file_cache.get(content_sha)
        if cached is not None:
            self._cache_hits += 1
            # Return a shallow copy so callers can't mutate the cache.
            return list(cached)

        self._cache_misses += 1
        try:
            tree = ast.parse(content.decode("utf-8", errors="ignore"))
        except Exception:
            self._file_cache[content_sha] = []
            return []

        # Use a per-file ``seen`` set so caching is independent of caller order.
        per_file_seen: set = set()
        eps = self._fastapi_endpoints_from_tree(tree, per_file_seen)
        # Store an immutable copy so cache entries can't be mutated by callers.
        self._file_cache[content_sha] = list(eps)
        return list(eps)

    def _iter_source_python_files(self, repo: Path):
        excluded = {".git", ".venv", "venv", "__pycache__", "node_modules", "tests"}
        for py_file in repo.rglob("*.py"):
            if not any(part in excluded for part in py_file.parts):
                yield py_file

    def _parse_python_ast(self, py_file: Path) -> Optional[ast.AST]:
        # Retained for backward compatibility with subclasses / external callers.
        # New code paths should use :meth:`_endpoints_for_python_file` which
        # benefits from the content-hash cache.
        try:
            return ast.parse(py_file.read_text(encoding="utf-8", errors="ignore"))
        except Exception:
            return None

    def _fastapi_endpoints_from_tree(self, tree: ast.AST, seen: set) -> List[Endpoint]:
        router_prefixes = self._collect_router_prefixes(tree)
        endpoints: List[Endpoint] = []
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                endpoints.extend(self._fastapi_endpoints_from_function(node, router_prefixes, seen))
        return endpoints

    def _fastapi_endpoints_from_function(
        self,
        node: ast.FunctionDef | ast.AsyncFunctionDef,
        router_prefixes: dict,
        seen: set,
    ) -> List[Endpoint]:
        endpoints: List[Endpoint] = []
        for decorator in node.decorator_list:
            endpoint = self._endpoint_from_fastapi_decorator(node.name, decorator, router_prefixes)
            if endpoint is None:
                continue
            key = (endpoint.method, endpoint.path)
            if key in seen:
                continue
            seen.add(key)
            endpoints.append(endpoint)
        return endpoints

    def _endpoint_from_fastapi_decorator(
        self, function_name: str, decorator: ast.AST, router_prefixes: dict
    ) -> Optional[Endpoint]:
        methods = {"get", "post", "put", "delete", "patch"}
        if not isinstance(decorator, ast.Call):
            return None
        if not isinstance(decorator.func, ast.Attribute):
            return None

        method_name = decorator.func.attr.lower()
        raw_path = self._extract_route_path(decorator)
        if method_name not in methods or not raw_path or not raw_path.startswith("/"):
            return None

        router_name = (
            decorator.func.value.id if isinstance(decorator.func.value, ast.Name) else None
        )
        prefix = router_prefixes.get(router_name, "") if router_name else ""
        return Endpoint(
            method=method_name.upper(),
            path=self._join_route_path(prefix, raw_path),
            base_url=self.config.base_url,
            description=function_name,
        )

    def _collect_router_prefixes(self, tree: ast.AST) -> dict:
        prefixes = {}
        for node in ast.walk(tree):
            if not isinstance(node, ast.Assign):
                continue
            if not isinstance(node.value, ast.Call):
                continue

            func = node.value.func
            func_name = None
            if isinstance(func, ast.Name):
                func_name = func.id
            elif isinstance(func, ast.Attribute):
                func_name = func.attr

            if func_name != "APIRouter":
                continue

            prefix = ""
            for kw in node.value.keywords:
                if kw.arg == "prefix" and isinstance(kw.value, ast.Constant) and isinstance(kw.value.value, str):
                    prefix = kw.value.value
                    break

            for target in node.targets:
                if isinstance(target, ast.Name):
                    prefixes[target.id] = prefix

        return prefixes

    def _extract_route_path(self, decorator: ast.Call) -> Optional[str]:
        if decorator.args:
            arg = decorator.args[0]
            if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                return arg.value

        for kw in decorator.keywords:
            if kw.arg == "path" and isinstance(kw.value, ast.Constant) and isinstance(kw.value.value, str):
                return kw.value.value

        return None

    def _join_route_path(self, prefix: str, route: str) -> str:
        prefix = (prefix or "").strip()
        route = route.strip()
        if not prefix:
            return route
        if not prefix.startswith("/"):
            prefix = "/" + prefix
        return prefix.rstrip("/") + route

    def _ports_to_endpoints(self, data: dict, base_url: str) -> List[Endpoint]:
        endpoints = []
        services = data.get("services", [])
        for svc in services:
            name = svc.get("name", "unknown")
            ports = svc.get("ports", [])
            for port_info in ports:
                host_port = port_info.get("host_port")
                if host_port:
                    url = f"http://localhost:{host_port}"
                    for path in ("/api/health", "/health", "/"):
                        endpoints.append(Endpoint(
                            method="GET",
                            path=path,
                            base_url=url,
                            service=name,
                        ))
        return endpoints

    def _scan_via_openapi(self, base_url: str, repo: Path) -> List[Endpoint]:
        # In dry-run and accelerator mode prefer static OpenAPI from repo/worktree.
        # This makes endpoint discovery reproducible per commit.
        prefer_static = self.config.dry_run or getattr(self.config, "accelerator", False)
        if prefer_static:
            static = self._scan_via_openapi_file(repo)
            if static:
                return static

        # Fallback: probe live URL when static OpenAPI is unavailable.
        for path in ("/openapi.json", "/docs/openapi.json", "/api/openapi.json"):
            try:
                r = httpx.get(f"{base_url.rstrip('/')}{path}", timeout=5)
                if r.status_code == 200:
                    return self._parse_openapi(r.json(), base_url)
            except Exception:
                continue
        return []

    def _scan_via_openapi_file(self, repo: Path) -> List[Endpoint]:
        candidates = [
            repo / "openapi.json",
            repo / "docs" / "openapi.json",
            repo / "backend" / "openapi.json",
            repo / "api" / "openapi.json",
            repo / "generated" / "openapi.json",
        ]
        for candidate in candidates:
            if candidate.exists():
                try:
                    spec = json.loads(candidate.read_text())
                    return self._parse_openapi(spec, self.config.base_url)
                except Exception:
                    continue
        return []

    _PARAM_FALLBACKS: dict = {
        "id": "1",
        "pk": "1",
        "uuid": "00000000-0000-0000-0000-000000000001",
        "slug": "test",
        "name": "test",
        "table": "users",
        "model": "test",
        "version": "v1",
        "format": "json",
        "lang": "en",
        "locale": "en",
        "date": "2024-01-01",
        "year": "2024",
        "month": "01",
        "day": "01",
    }

    def _substitute_params(self, path_template: str, fixtures: dict) -> str:
        actual = path_template
        for param in re.findall(r"\{([^}]+)\}", path_template):
            value = fixtures.get(param) or self._PARAM_FALLBACKS.get(param.lower())
            if value is None:
                value = "1"
            actual = actual.replace(f"{{{param}}}", str(value))
        return actual

    def _parse_openapi(self, spec: dict, base_url: str) -> List[Endpoint]:
        endpoints = []
        paths = spec.get("paths", {})
        fixtures = self.config.test_fixtures

        for path_template, methods in paths.items():
            actual_path = self._substitute_params(path_template, fixtures)
            has_unresolved = "{" in actual_path

            for method, details in methods.items():
                if method.upper() in ("GET", "POST", "PUT", "DELETE", "PATCH"):
                    desc = details.get("summary", "")
                    resolved_body = self._resolve_test_body(method.upper(), actual_path, path_template)
                    ep = Endpoint(
                        method=method.upper(),
                        path=actual_path,
                        template_path=path_template if actual_path != path_template else None,
                        base_url=base_url,
                        description=desc,
                        body=resolved_body,
                    )
                    if has_unresolved:
                        ep.template_path = path_template
                    endpoints.append(ep)
        return endpoints

    def _resolve_test_body(self, method: str, actual_path: str, template_path: str) -> Optional[dict]:
        bodies = getattr(self.config, "test_bodies", {}) or {}
        candidates = [
            f"{method} {actual_path}",
            f"{method} {template_path}",
            actual_path,
            template_path,
        ]
        for key in candidates:
            value = bodies.get(key)
            if isinstance(value, dict):
                return value
        return None

    def _scan_via_compose_labels(self, repo: Path) -> List[Endpoint]:
        _TRAEFIK_RULE = re.compile(r"PathPrefix\(`([^`]+)`\)")
        for fname in ("docker-compose.yml", "docker-compose.yaml", self.config.compose_file):
            cf = repo / fname
            if not cf.exists():
                continue
            try:
                data = yaml.safe_load(cf.read_text())
            except yaml.YAMLError:
                continue

            endpoints = []
            services = (data or {}).get("services", {})
            for svc_name, svc_def in services.items():
                labels = svc_def.get("labels", [])
                if isinstance(labels, dict):
                    labels = list(labels.values())
                for label in labels:
                    for match in _TRAEFIK_RULE.finditer(str(label)):
                        prefix = match.group(1)
                        endpoints.append(Endpoint(
                            method="GET",
                            path=prefix,
                            base_url=self.config.base_url,
                            service=svc_name,
                        ))
            return endpoints
        return []
