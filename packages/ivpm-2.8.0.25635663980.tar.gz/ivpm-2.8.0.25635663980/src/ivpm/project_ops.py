#****************************************************************************
#* project_ops.py
#*
#* Copyright 2018-2024 Matthew Ballance and Contributors
#*
#* Licensed under the Apache License, Version 2.0 (the "License"); you may 
#* not use this file except in compliance with the License.  
#* You may obtain a copy of the License at:
#*
#*   http://www.apache.org/licenses/LICENSE-2.0
#*
#* Unless required by applicable law or agreed to in writing, software 
#* distributed under the License is distributed on an "AS IS" BASIS, 
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  
#* See the License for the specific language governing permissions and 
#* limitations under the License.
#*
#* Created on:
#*     Author: 
#*
#****************************************************************************
import logging
import os
import json
import dataclasses as dc
from typing import Tuple, List, Optional
from .package import Package
from .package_updater import PackageUpdater
from .handlers.package_handler_rgy import PackageHandlerRgy
from .project_ops_info import ProjectUpdateInfo, ProjectBuildInfo
from .update_event import UpdateEventDispatcher
from .update_tui import create_update_tui, RichUpdateTUI
from .utils import fatal, note, warning
from .package_lock import write_lock, check_lock_changes

_logger = logging.getLogger("ivpm.project_ops")


@dc.dataclass
class ProjectOps(object):
    root_dir : str
    debug : bool = False

    def update(self,
               dep_set : str = None,
               force_py_install : bool = False,
               skip_venv : bool = False,
               args = None,
               lock_file : str = None,
               refresh_all : bool = False,
               force : bool = False,
               cli_overrides = None):
        from .update_event import UpdateEvent, UpdateEventType
        
        proj_info, deps_dir, dep_set = self._init(dep_set, cli_overrides=cli_overrides)

        # Get log level from args for TUI selection
        log_level = getattr(args, 'log_level', 'NONE')
        verbose = getattr(args, 'verbose', 0)
        
        # Create event dispatcher and TUI
        event_dispatcher = UpdateEventDispatcher()
        tui = create_update_tui(log_level, verbose=verbose)
        event_dispatcher.add_listener(tui)
        
        # Determine if we should suppress output (Rich TUI mode)
        suppress_output = isinstance(tui, RichUpdateTUI)
        
        # Start the TUI if it's Rich-based
        if isinstance(tui, RichUpdateTUI):
            tui.start()
 
        try:
            _logger.info("Processing root package %s", proj_info.name)

            if self.debug:
                for self.dep_set in proj_info.dep_set_m.keys():
                    _logger.debug("DepSet: %s", self.dep_set)
                    for d in proj_info.dep_set_m[self.dep_set].packages.keys():
                        _logger.debug("  Package: %s", d)

            if lock_file:
                # Reproduction mode: use lock file as the sole package source
                from .package_lock import IvpmLockReader
                note("Reproducing workspace from lock file: %s" % lock_file)
                lock_reader = IvpmLockReader(lock_file)
                ds = lock_reader.build_packages_info()
            else:
                dep_set, ds = self._getDepSet(proj_info, dep_set)

                # Change detection: compare current specs against existing lock
                if not refresh_all and not force:
                    diffs = check_lock_changes(deps_dir, ds.packages)
                    if diffs:
                        note("The following packages have changed specs vs package-lock.json:")
                        for name, diff in diffs.items():
                            note("  %s: run with --refresh-all to re-fetch" % name)
                        note("No packages re-fetched. Use --refresh-all to update.")

            pkg_handler = PackageHandlerRgy.inst().mkHandler()
            updater = PackageUpdater(deps_dir, pkg_handler, args=args)
            
            # Configure event dispatcher on update_info
            updater.update_info.event_dispatcher = event_dispatcher
            
            # Suppress subprocess output when using Rich TUI
            updater.update_info.suppress_output = suppress_output
            updater.update_info._tui_ref = tui

            # Load existing lock data so packages can detect spec changes
            _lock_path = os.path.join(deps_dir, "package-lock.json")
            if os.path.isfile(_lock_path):
                try:
                    from .package_lock import read_lock as _read_lock
                    updater.update_info.lock_data = _read_lock(_lock_path)
                except Exception:
                    _logger.debug("Could not read lock file for change detection")

            # Build the handler update_info (with dispatcher wired in)
            handler_update_info = ProjectUpdateInfo(
                args, deps_dir,
                project_dir=self.root_dir,
                project_name=proj_info.name,
                force_py_install=force_py_install,
                skip_venv=skip_venv,
                suppress_output=suppress_output,
                event_dispatcher=event_dispatcher,
                python_config=proj_info.python_config,
                node_config=proj_info.node_config,
            )
            handler_update_info.handler_configs = proj_info.handler_configs
            handler_update_info._tui_ref = tui

            # Load previous handler state from ivpm.json (for stale-entry cleanup)
            _ivpm_json_path = os.path.join(deps_dir, "ivpm.json")
            _prev_ivpm = {}
            if os.path.isfile(_ivpm_json_path):
                try:
                    with open(_ivpm_json_path) as _fp:
                        _prev_ivpm = json.load(_fp)
                except Exception:
                    pass
            handler_update_info.handler_state = _prev_ivpm.get("handlers", {})

            # Root pre-load: let handlers initialise before any packages are fetched
            pkg_handler.on_root_pre_load(handler_update_info)

            # Prevent an attempt to load the top-level project as a depedency
            updater.all_pkgs[proj_info.name] = None
            pkgs_info = updater.update(ds)

            _logger.debug("Setup-deps: %s", str(pkgs_info.setup_deps))

            # Root post-load: handlers do their main work (venv, pip install, envrc, etc.)
            pkg_handler.on_root_post_load(handler_update_info)

            # Signal update complete
            updater.update_info.update_complete()

            # Write package-lock.json with resolved package versions
            handler_contributions = pkg_handler.get_lock_entries(deps_dir)
            write_lock(deps_dir, updater.all_pkgs, handler_contributions)

            # Write ivpm.json with dep-set and handler state
            ivpm_json = {"dep-set": dep_set}
            if proj_info.resolved_vars:
                ivpm_json["vars"] = proj_info.resolved_vars
            state_contributions = pkg_handler.get_state_entries()
            if state_contributions:
                ivpm_json["handlers"] = state_contributions
            with open(os.path.join(deps_dir, "ivpm.json"), "w") as fp:
                json.dump(ivpm_json, fp)
        finally:
            # Ensure TUI is stopped on exception
            if isinstance(tui, RichUpdateTUI):
                tui.stop()

    def build(self, dep_set : str = None, args = None, debug : bool = False):
        proj_info, deps_dir, dep_set = self._init(dep_set)

        dep_set, ds = self._getDepSet(proj_info, dep_set)

        pkg_handler = PackageHandlerRgy.inst().mkHandler()
        updater = PackageUpdater(deps_dir, pkg_handler, args=args, load=False)

        # Prevent an attempt to load the top-level project as a depedency
        updater.all_pkgs[proj_info.name] = None
        pkgs_info = updater.update(ds)

        # Now, run the actual build operation
        build_info = ProjectBuildInfo(args, deps_dir, debug=debug)

        pkg_handler.build(build_info)

        pass

    def status(self, dep_set: str = None, args=None):
        from .proj_info import ProjInfo
        from .pkg_status import PkgVcsStatus
        from .project_ops_info import ProjectStatusInfo
        from .pkg_types.pkg_type_rgy import PkgTypeRgy
        from .package_lock import read_lock

        proj_info = ProjInfo.mkFromProj(self.root_dir)
        if proj_info is None:
            fatal("Failed to locate IVPM meta-data (eg ivpm.yaml)")

        deps_dir = os.path.join(self.root_dir, proj_info.deps_dir)
        lock_path = os.path.join(deps_dir, "package-lock.json")

        if not os.path.isfile(lock_path):
            fatal("package-lock.json not found in %s — run 'ivpm update' first" % deps_dir)

        lock = read_lock(lock_path)
        packages = lock.get("packages", {})

        status_info = ProjectStatusInfo(args=args, deps_dir=deps_dir)
        rgy = PkgTypeRgy.inst()

        results = []
        for name, entry in packages.items():
            src = entry.get("src", "")
            if not rgy.hasPkgType(src):
                results.append(PkgVcsStatus(
                    name=name,
                    src_type=src,
                    path=os.path.join(deps_dir, name),
                    vcs="none",
                ))
                continue

            pkg = rgy.mkPackage(src, name, entry, None)
            pkg.path = os.path.join(deps_dir, name)
            result = pkg.status(status_info)
            if result is None:
                result = PkgVcsStatus(
                    name=name,
                    src_type=src,
                    path=pkg.path,
                    vcs="none",
                )
            results.append(result)

        return sorted(results, key=lambda r: r.name)

    def sync(self, dep_set: str = None, args=None):
        import asyncio
        import multiprocessing
        from .pkg_sync import PkgSyncResult, SyncOutcome
        from .project_ops_info import ProjectSyncInfo
        from .pkg_types.pkg_type_rgy import PkgTypeRgy
        from .package_lock import read_lock, patch_lock_after_sync
        from .proj_info import ProjInfo

        proj_info = ProjInfo.mkFromProj(self.root_dir)
        if proj_info is None:
            fatal("Failed to locate IVPM meta-data (eg ivpm.yaml)")

        deps_dir = os.path.join(self.root_dir, proj_info.deps_dir)
        lock_path = os.path.join(deps_dir, "package-lock.json")

        if not os.path.isfile(lock_path):
            fatal("package-lock.json not found in %s — run 'ivpm update' first" % deps_dir)

        lock = read_lock(lock_path)
        packages = lock.get("packages", {})

        dry_run          = getattr(args, "dry_run",          False) if args is not None else False
        packages_filter  = getattr(args, "packages_filter",  None)  if args is not None else None
        max_parallel     = getattr(args, "jobs",             0)     if args is not None else 0
        progress         = getattr(args, "_sync_progress",   None)  if args is not None else None

        sync_info = ProjectSyncInfo(
            args=args,
            deps_dir=deps_dir,
            dry_run=dry_run,
            packages_filter=packages_filter,
            max_parallel=max_parallel or 0,
            progress=progress,
        )
        rgy = PkgTypeRgy.inst()

        # Filter the package list once.
        pkg_items = [
            (name, entry) for name, entry in packages.items()
            if not packages_filter or name in packages_filter
        ]

        if not pkg_items:
            return []

        # ── Parallel execution ─────────────────────────────────────────────
        n_workers = sync_info.max_parallel or multiprocessing.cpu_count()

        async def _run_all():
            semaphore = asyncio.Semaphore(n_workers)
            loop = asyncio.get_event_loop()

            async def _run_one(name, entry):
                async with semaphore:
                    if progress:
                        progress.on_pkg_start(name)
                    src = entry.get("src", "")
                    # Normalize src aliases that appear in lock files but aren't
                    # registered directly (http archive types → "url").
                    if src in ("tgz", "txz", "zip", "jar", "http"):
                        src = "url"
                    if not rgy.hasPkgType(src):
                        result = PkgSyncResult(
                            name=name, src_type=src,
                            path=os.path.join(deps_dir, name),
                            outcome=SyncOutcome.SKIPPED,
                            skipped_reason=src or "non-git",
                        )
                    else:
                        pkg = rgy.mkPackage(src, name, entry, None)
                        pkg.path = os.path.join(deps_dir, name)
                        result = await loop.run_in_executor(
                            None, pkg.sync, sync_info
                        )
                    if progress:
                        progress.on_pkg_result(result)
                    return result

            return await asyncio.gather(
                *[_run_one(n, e) for n, e in pkg_items],
                return_exceptions=True,
            )

        raw = asyncio.run(_run_all())

        results = []
        for i, r in enumerate(raw):
            if isinstance(r, Exception):
                name = pkg_items[i][0]
                entry = pkg_items[i][1]
                err_result = PkgSyncResult(
                    name=name,
                    src_type=entry.get("src", ""),
                    path=os.path.join(deps_dir, name),
                    outcome=SyncOutcome.ERROR,
                    error=str(r),
                )
                if progress:
                    progress.on_pkg_result(err_result)
                results.append(err_result)
            else:
                results.append(r)

        if not dry_run:
            patch_lock_after_sync(lock_path, results)

        return sorted(results, key=lambda r: r.name)

    def _init(self, dep_set : str = None, cli_overrides=None) -> Tuple['ProjInfo', str, str]:
        from .proj_info import ProjInfo

        # Load persisted variables from a previous run
        persisted_vars = {}
        _pre_deps_dir = os.path.join(self.root_dir, "packages")  # default
        _pre_ivpm_json_path = os.path.join(_pre_deps_dir, "ivpm.json")
        if os.path.isfile(_pre_ivpm_json_path):
            try:
                with open(_pre_ivpm_json_path) as _fp:
                    _pre_ivpm = json.load(_fp)
                    persisted_vars = _pre_ivpm.get("vars", {})
            except Exception:
                pass

        proj_info = ProjInfo.mkFromProj(
            self.root_dir,
            cli_overrides=cli_overrides,
            persisted_vars=persisted_vars)

        if proj_info is None:
            fatal("Failed to locate IVPM meta-data (eg ivpm.yaml)")
            
        deps_dir = os.path.join(self.root_dir, proj_info.deps_dir)

        ivpm_json = {}

        if os.path.isfile(os.path.join(deps_dir, "ivpm.json")):
            with open(os.path.join(deps_dir, "ivpm.json"), "r") as fp:
                try:
                    ivpm_json = json.load(fp)
                except Exception as e:
                    warning("failed to read ivpm.json: %s" % str(e))

        if "dep-set" in ivpm_json.keys():
            if dep_set is None:
                dep_set = ivpm_json["dep-set"]
            elif dep_set != ivpm_json["dep-set"]:
                fatal("Attempting to update with a different dep-set than previously used")

        return (proj_info, deps_dir, dep_set)
    
    def _getDepSet(self, proj_info, dep_set):
        if dep_set is None:
            # Priority: 1) default-dep-set setting, 2) first dep-set in file
            if proj_info.default_dep_set is not None:
                dep_set = proj_info.default_dep_set
            elif len(proj_info.dep_set_m.keys()) > 0:
                dep_set = list(proj_info.dep_set_m.keys())[0]
            else:
                fatal("No dependency sets defined in project")

        if dep_set not in proj_info.dep_set_m.keys():
            raise Exception("Dep-set %s is not present" % dep_set)
        else:
            ds = proj_info.dep_set_m[dep_set]
        
        return dep_set, ds
