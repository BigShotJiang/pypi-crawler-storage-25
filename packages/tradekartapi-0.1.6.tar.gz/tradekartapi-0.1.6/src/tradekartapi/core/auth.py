from ..exceptions import AuthenticationError


class AccessTokenAuth:
    """Authentication using access token."""

    @staticmethod
    def validate(access_token: str) -> str:
        token = access_token.strip() if access_token else ""
        if not token:
            raise AuthenticationError("Access token is required")
        return token