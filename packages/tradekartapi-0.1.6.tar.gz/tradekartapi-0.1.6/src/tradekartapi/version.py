"""Version information for tradekart-groww-api."""

__version_info__ = (0, 1, 6)
__version__ = ".".join(str(v) for v in __version_info__)