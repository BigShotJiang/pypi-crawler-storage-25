from __future__ import annotations

from typing import Any, Optional


class GrowwApiWrapperError(Exception):
    """Base exception for the Tradekart Groww wrapper.
    All package-specific exceptions should inherit from this class so app code
    can catch one common parent when needed.
    """
    def __init__(
        self,
        message: str,
        *,
        status_code: Optional[int] = None,
        details: Optional[dict[str, Any]] = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.details = details

    def __str__(self) -> str:
        parts = [self.message]

        if self.status_code is not None:
            parts.append(f'status_code={self.status_code}')

        if self.details is not None:
            parts.append(f'details={self.details}')

        return '|'.join(parts)


class AuthenticationError(GrowwApiWrapperError):
    """Raised when access token is invalid or missing."""


class ValidationError(GrowwApiWrapperError):
    """Raised when input validation fails."""


class ServiceError(GrowwApiWrapperError):
    """Raised when an SDK service operation fails."""
    
    def __init__(
        self,
        message : str,
        *,
        status_code: Optional[int] = None,
        operation: Optional[str] = None,
        details: Optional[dict[str, Any]] = None
    ) -> None:
        merged_details = dict(details or {})
        if operation is not None:
            merged_details['operation'] = operation

        self.operation = operation
        self.status_code = status_code
        self.details = merged_details

        super().__init__(
            message,
            status_code=status_code,
            details=merged_details
        )


class HttpError(GrowwApiWrapperError):
    """Raised when an HTTP/API layer request fails."""

    def __init__(
        self,
        message: str,
        *,
        status_code: Optional[int] = None,
        details: Optional[dict[str, Any]] = None,
        response_body: Optional[Any] = None,
    ) -> None:
        merged_details = dict(details or {})

        if response_body is not None:
            merged_details['response_body'] = response_body

        super().__init__(
            message=message,
            status_code=status_code,
            details=merged_details,
        )

class RateLimitError(HttpError):
    """Raised when API rate limit is hit."""


class NotFoundError(HttpError):
    """Raised when requested resource is not found."""