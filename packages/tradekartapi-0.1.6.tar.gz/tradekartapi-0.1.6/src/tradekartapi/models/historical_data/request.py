from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from ..annexures import Exchange,Segment
from ...utils.validators import require_non_empty


@dataclass(frozen=True)
class HistoricalCandleDataRequest:
    groww_symbol : str
    exchange : Exchange
    segment : Segment
    start_time : str
    end_time : str
    candle_interval : str | None = None

    def __post_init__(self) -> None:
        require_non_empty(self.groww_symbol, 'groww_symbol')

    def to_payload(self) -> dict[str, Any]:
        payload = {
            'groww_symbol' : self.groww_symbol,
            'exchange' : self.exchange.value,
            'segment' : self.segment.value,
            'start_time' : self.start_time,
            'end_time' : self.end_time,
        }

        if self.candle_interval is not None:
            payload['candle_interval'] = self.candle_interval

        return payload