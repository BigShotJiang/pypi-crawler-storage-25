from dataclasses import dataclass

@dataclass(frozen=True)
class PlaceOrderResponse:
    pass


@dataclass(frozen=True)
class ModifyOrderResponse:
    pass

@dataclass(frozen=True)
class CancelOrderResponse:
    pass

@dataclass(frozen=True)
class OrderStatusResponse:
    pass

@dataclass(frozen=True)
class OrderListResponse:
    pass

@dataclass(frozen=True)
class OrderDetailResponse:
    pass

@dataclass(frozen=True)
class TradeResponse:
    pass