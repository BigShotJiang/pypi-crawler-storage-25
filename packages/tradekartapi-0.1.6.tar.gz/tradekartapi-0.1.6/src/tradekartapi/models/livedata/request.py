from __future__ import annotations

from dataclasses import dataclass
from ..annexures import Exchange, Segment
from typing import Tuple, Any


@dataclass(frozen=True)
class GetQuoteRequest:
    exchange: Exchange
    segment: Segment
    trading_symbol: str

    def to_payload(self) -> dict[str, Any]:
        return {
            'exchange': self.exchange,
            'segment': self.segment,
            'trading_symbol': self.trading_symbol,
        }


@dataclass(frozen=True)
class GetLTPRequest:
    segment: Segment
    exchange_trading_symbols: Tuple[str]  # Tuple of exchange trading symbols for single and multiple symbols(upto 50 symbols)

    def to_payload(self) -> dict[str, Any]:
        return {
            'segment': self.segment,
            'exchange_trading_symbols': self.exchange_trading_symbols,
        }

@dataclass(frozen=True)
class GetOHLCRequest:
    segment: Segment
    exchange_trading_symbols: Tuple[str]  # Tuple of exchange trading symbols for single and multiple symbols(upto 50 symbols)

    def to_payload(self) -> dict[str, Any]:
        return {
            'segment': self.segment,
            'exchange_trading_symbols': self.exchange_trading_symbols,
        }

@dataclass(frozen=True)
class GetOptionChainRequest:
    exchange: Exchange
    underlying: str
    expiry_date: str

    def to_payload(self) -> dict[str, Any]:
        return {
            'exchange': self.exchange,
            'underlying': self.underlying,
            'expiry_date': self.expiry_date,
        }

@dataclass(frozen=True)
class GetGreeksRequest:
    exchange: Exchange
    underlying: str
    trading_symbol: str
    expiry: str

    def to_payload(self) -> dict[str, Any]:
        return {
            'exchange': self.exchange,
            'underlying': self.underlying,
            'trading_symbol': self.trading_symbol,
            'expiry': self.expiry,
        }

    


