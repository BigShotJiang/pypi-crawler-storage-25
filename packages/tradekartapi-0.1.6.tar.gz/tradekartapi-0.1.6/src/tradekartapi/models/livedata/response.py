from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class GetQuoteResponse:
    raw: dict[str, Any]

@dataclass(frozen=True)
class GetLTPResponse:
    raw: dict[str, Any]

@dataclass(frozen=True)
class GetOHLCResponse:
    raw: dict[str, Any]

@dataclass(frozen=True)
class GetOptionChainResponse:
    raw: dict[str, Any]

@dataclass(frozen=True)
class GetGreeksResponse:
    raw: dict[str, Any]