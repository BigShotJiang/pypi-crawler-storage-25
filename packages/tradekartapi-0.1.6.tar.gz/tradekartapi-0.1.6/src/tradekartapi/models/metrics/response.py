from __future__ import annotations

from dataclasses import dataclass, field


#Todo convert in Pydantic models 
@dataclass
class HoldingMetricsResponse:
    trading_symbol: str
    quantity: float 
    average_price: float 
    ltp: float                  #last traded price
    previous_close: float 

    invested_amount: float 
    current_value: float 

    total_return: float 
    total_return_percent: float 

    one_day_return: float 
    one_day_return_percent: float 

    
@dataclass
class PortfolioSummaryResponse:
    total_invested_amount: float 
    total_current_value: float 
    total_return: float 
    total_return_percent: float 
    one_day_return: float 
    one_day_return_percent: float 
    holdings_count: int

@dataclass
class PortfolioMetricsResponse:
    summary: PortfolioSummaryResponse
    holdings: list[HoldingMetricsResponse] = field(default_factory=list)