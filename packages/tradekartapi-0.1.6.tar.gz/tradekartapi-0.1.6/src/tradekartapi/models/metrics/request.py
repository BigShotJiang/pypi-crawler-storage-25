from __future__ import annotations

from dataclasses import dataclass
from tradekartapi.services import PortfolioService, LiveDataService

@dataclass(frozen=True)
class GetPortfolioMetricsRequest: 
    """
    Empty because request is not take from the user it automatically handle itself for relief the user.
    """
    pass
