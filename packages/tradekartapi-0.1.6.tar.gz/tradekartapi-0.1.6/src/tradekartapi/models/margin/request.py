from __future__ import annotations

from dataclasses import dataclass
from typing import Any, List, Dict

from ...utils.validators import require_non_empty_list
from ..annexures import Segment


@dataclass(frozen=True)
class GetAvailableMarginRequest:
    def to_payload(self) -> dict[str, Any]:
        return {}


@dataclass(frozen=True)
class GetOrderMarginRequest:
    segment: Segment
    orders: List[Dict[str, Any]]

    def __post_init__(self) -> None:
        require_non_empty_list(self.orders, 'orders')

    def to_payload(self) -> dict[str, Any]:
        return {
            'segment': self.segment.value,
            'orders': self.orders,
        }
    
    