from __future__ import annotations

from typing import Any 

from ...exceptions import ServiceError
from ...models.metrics import HoldingMetricsResponse, PortfolioSummaryResponse, PortfolioMetricsResponse
from ...models.annexures import Segment
from ...models.livedata import GetLTPRequest, GetOHLCRequest, GetLTPResponse, GetOHLCResponse
from ...models.portfolio import GetHoldingsResponse, GetPositionsResponse


class PortfolioMetricsService:
    """
    Portfolio Metrics Service

    This service is responsible for calculating portfolio metrics.
    Holdings Metrics - 
    - invested_amount = average_price * quantity
    - current_value = ltp * quantity
    - total_return = current_value - invested_amount
    - total_return_percent = (total_return / invested_amount) * 100
    - one_day_return = (ltp - previous_close) * quantity
    - one_day_return_percent = (one_day_return / previous_close) * 100
    Total_portfolio_summary - 
    - total_invested_amount = sum(holding.invested_amount for holding in holdings)
    - total_current_value = sum(holding.current_value for holding in holdings)
    - total_return = total_current_value - total_invested_amount
    - total_return_percent = (total_return / total_invested_amount) * 100
    - one_day_return = sum(holding.one_day_return for holding in holdings)
    - one_day_return_percent = (one_day_return / total_current_value) * 100
    
    """
    def __init__(self, portfolio_service: Any, live_data_service: Any) -> None:
        self._portfolio_service = portfolio_service
        self._live_data_service = live_data_service

    def _extract_ltp(self, ltp_response: GetLTPResponse, exchange_trading_symbol: str) -> float:
        if hasattr(ltp_response, 'raw') and isinstance(ltp_response.raw, dict):
            if exchange_trading_symbol in ltp_response.raw:
                ltp_value = float(ltp_response.raw[exchange_trading_symbol])
                return ltp_value
        return 0.0

    def _extract_prev_close(self, ohlc_response: GetOHLCResponse, exchange_trading_symbol: str) -> float:
        if hasattr(ohlc_response, 'raw') and isinstance(ohlc_response.raw, dict):
            if exchange_trading_symbol in ohlc_response.raw:
                prev_close_value = float(ohlc_response.raw[exchange_trading_symbol]['close'])
                return prev_close_value
        return 0.0
        
    def _get_field(self, obj: Any, key: str, default: Any = None) -> Any:
        if isinstance(obj, dict):
            return obj.get(key, default)
        return getattr(obj, key, default)

    def _build_holding_metric(self, holding: Any) -> HoldingMetricsResponse:
        trading_symbol = self._get_field(holding, 'trading_symbol', '')
        quantity = float(self._get_field(holding, 'quantity', 0.0))
        average_price = float(self._get_field(holding, 'average_price', 0.0))

        exchange = 'NSE' # For getting the NSE_trading_symbol
        exchange_trading_symbol = f'{exchange}_{trading_symbol}'

        ltp_request = GetLTPRequest(
            segment=Segment.CASH,
            exchange_trading_symbols=exchange_trading_symbol,
        )
        ltp_response = self._live_data_service.get_ltp(ltp_request)

        ohlc_request = GetOHLCRequest(
            segment=Segment.CASH,
            exchange_trading_symbols=exchange_trading_symbol,
        )
        ohlc_response = self._live_data_service.get_ohlc(ohlc_request)

        ltp = self._extract_ltp(ltp_response, exchange_trading_symbol)
        prev_close = self._extract_prev_close(ohlc_response, exchange_trading_symbol)
        
        #Metrics
        invested_amount = average_price * quantity
        current_value = ltp * quantity
        total_return = current_value - invested_amount
        
        if invested_amount > 0:
            total_return_percent = (total_return / invested_amount) * 100
        else:
            total_return_percent = 0.0

        one_day_return = (ltp - prev_close) * quantity
        if prev_close > 0:
            one_day_return_percent = ((ltp - prev_close) / prev_close) * 100
        else:
            one_day_return_percent = 0.0

        return HoldingMetricsResponse(
            trading_symbol=trading_symbol,
            quantity=quantity,
            average_price=average_price,
            ltp=ltp,
            previous_close=prev_close,
            invested_amount=invested_amount,
            current_value=current_value,
            total_return=round(total_return, 2),
            total_return_percent=round(total_return_percent, 2),
            one_day_return=round(one_day_return, 2),
            one_day_return_percent=round(one_day_return_percent, 2),
        )

    def get_portfolio_metrics(self) -> PortfolioMetricsResponse:
        try:
            holdings_raw = self._portfolio_service.get_holdings()
            
            if isinstance(holdings_raw, dict):
                holdings = holdings_raw.get('holdings') or holdings_raw.get('data') or []
            elif isinstance(holdings_raw, list):
                holdings = holdings_raw
            else:
                holdings = []

            holding_metrics: list[HoldingMetricsResponse] = []
            
            total_invested_amount = 0.0 
            total_current_value = 0.0 
            total_one_day_return = 0.0 

            for holding in holdings:
                metric = self._build_holding_metric(holding)
                holding_metrics.append(metric)

                total_invested_amount += metric.invested_amount
                total_current_value += metric.current_value
                total_one_day_return += metric.one_day_return

            total_return = total_current_value - total_invested_amount

            if total_invested_amount > 0:
                total_return_percent = (total_return / total_invested_amount) * 100
            else:
                total_return_percent = 0.0

            previous_close_value = total_current_value - total_one_day_return
            if previous_close_value > 0:
                total_one_day_return_percent = (total_one_day_return / previous_close_value) * 100
            else:
                total_one_day_return_percent = 0.0

            summary = PortfolioSummaryResponse(
                total_invested_amount=total_invested_amount,
                total_current_value=total_current_value,
                total_return=total_return,
                total_return_percent=round(total_return_percent, 2),
                one_day_return=round(total_one_day_return, 2),
                one_day_return_percent=round(total_one_day_return_percent, 2),
                holdings_count=len(holding_metrics),
            )

            return PortfolioMetricsResponse(
                summary=summary,
                holdings=holding_metrics,
            )
            
        except Exception as exc:
            raise ServiceError(
                'Error in getting portfolio metrics',
                status_code=500,
                operation='GET_PORTFOLIO_METRICS',
                details={'reason': 'Error in get portfolio metrics method'},
            ) from exc