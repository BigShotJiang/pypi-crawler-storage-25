from __future__ import annotations

from typing import Any

from ...models.portfolio import GetHoldingsResponse, GetPositionsResponse
from ...models.annexures import Segment
from ...exceptions import ServiceError
from ...config import DEFAULT_TIMEOUT_SECONDS

class PortfolioService:
    def __init__(self, sdk: Any) -> None:
        self._sdk = sdk.client

    def get_holdings(self) -> list[GetHoldingsResponse]:
        try:
            response = self._sdk.get_holdings_for_user(timeout=DEFAULT_TIMEOUT_SECONDS)
            return response
        except Exception as exc:
            raise ServiceError(
                'Error in getting holdings',
                status_code=500,
                operation='GET_HOLDINGS',
                details={'reason': 'Error in get holdings method'},
            ) from exc

    def get_positions(self, segment: Segment | None = None) -> list[GetPositionsResponse]:
        try:
            if segment is None:
                response = self._sdk.get_positions_for_user()   # for all positions include cash, fno, commodity
            else:
                response = self._sdk.get_positions_for_user(segment=segment) # for positions of a specific segment
            return response
        except Exception as exc:
            raise ServiceError(
                'Error in getting positions',
                status_code=500,
                operation='GET_POSITIONS',
                details={'reason': 'Error in get positions method'},
            ) from exc
        
    def get_positions_for_symbol(self, trading_symbol: str, segment: Segment) -> list[GetPositionsResponse]:
        try:
            response = self._sdk.get_position_for_trading_symbol(trading_symbol=trading_symbol, segment=segment)
            return response
        except Exception as exc:
            raise ServiceError(
                'Error in getting positions for symbol',
                status_code=500,
                operation='GET_POSITIONS_FOR_SYMBOL',
                details={'reason': 'Error in get positions for symbol method'},
            ) from exc