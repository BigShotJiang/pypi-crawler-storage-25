import pytest

from tradekartapi.services import PortfolioMetricsService
from tradekartapi.exceptions import ServiceError


class FakeHolding:
    def __init__(self, trading_symbol, quantity, average_price):
        self.trading_symbol = trading_symbol
        self.quantity = quantity
        self.average_price = average_price


class FakePortfolioService:
    def get_holdings(self):
        return [
            FakeHolding('INFY', 10, 1500),
            FakeHolding('RELIANCE', 5, 2000),
        ]


class FakeLTPResponse:
    def __init__(self, symbol, ltp):
        self.raw = {
            symbol: ltp
        }


class FakeOHLCResponse:
    def __init__(self, symbol, prev_close):
        self.raw = {
            symbol: {
                'close': prev_close
            }
        }


class FakeLiveDataService:
    def __init__(self):
        self.called = []

    def get_ltp(self, request):
        self.called.append(('ltp', request.exchange_trading_symbols))

        if request.exchange_trading_symbols == 'NSE_INFY':
            return FakeLTPResponse('NSE_INFY', 1600)

        if request.exchange_trading_symbols == 'NSE_RELIANCE':
            return FakeLTPResponse('NSE_RELIANCE', 2100)

        return FakeLTPResponse(request.exchange_trading_symbols, 0)

    def get_ohlc(self, request):
        self.called.append(('ohlc', request.exchange_trading_symbols))

        if request.exchange_trading_symbols == 'NSE_INFY':
            return FakeOHLCResponse('NSE_INFY', 1550)

        if request.exchange_trading_symbols == 'NSE_RELIANCE':
            return FakeOHLCResponse('NSE_RELIANCE', 2050)

        return FakeOHLCResponse(request.exchange_trading_symbols, 0)

@pytest.fixture
def portfolio_service():
    return FakePortfolioService()


@pytest.fixture
def live_data_service():
    return FakeLiveDataService()


@pytest.fixture
def service(portfolio_service, live_data_service):
    return PortfolioMetricsService(portfolio_service, live_data_service)


def test_get_portfolio_metrics(service, live_data_service):
    result = service.get_portfolio_metrics()

    # -------- Holdings --------

    assert len(result.holdings) == 2

    infy = result.holdings[0]
    reliance = result.holdings[1]

    # INFY
    assert infy.trading_symbol == 'INFY', f"Expected 'INFY', got {infy.trading_symbol}"
    assert infy.quantity == 10, f"Expected 10, got {infy.quantity}"
    assert infy.average_price == 1500, f"Expected 1500, got {infy.average_price}"
    assert infy.ltp == 1600, f"Expected 1600, got {infy.ltp}"
    assert infy.previous_close == 1550, f"Expected 1550, got {infy.previous_close}"
    assert infy.invested_amount == 15000, f"Expected 15000, got {infy.invested_amount}"
    assert infy.current_value == 16000, f"Expected 16000, got {infy.current_value}"
    assert infy.total_return == 1000, f"Expected 1000, got {infy.total_return}"
    assert infy.total_return_percent == pytest.approx(6.67), f"Expected 6.67, got {infy.total_return_percent}"
    assert infy.one_day_return == 500, f"Expected 500, got {infy.one_day_return}"
    assert infy.one_day_return_percent == pytest.approx(3.23), f"Expected 3.23, got {infy.one_day_return_percent}"

    # RELIANCE
    assert reliance.trading_symbol == 'RELIANCE', f"Expected 'RELIANCE', got {reliance.trading_symbol}"
    assert reliance.quantity == 5, f"Expected 5, got {reliance.quantity}"
    assert reliance.average_price == 2000, f"Expected 2000, got {reliance.average_price}"
    assert reliance.ltp == 2100, f"Expected 2100, got {reliance.ltp}"
    assert reliance.previous_close == 2050, f"Expected 2050, got {reliance.previous_close}"
    assert reliance.invested_amount == 10000, f"Expected 10000, got {reliance.invested_amount}"
    assert reliance.current_value == 10500, f"Expected 10500, got {reliance.current_value}"
    assert reliance.total_return == 500, f"Expected 500, got {reliance.total_return}"
    assert reliance.total_return_percent == pytest.approx(5.0), f"Expected 5.0, got {reliance.total_return_percent}"
    assert reliance.one_day_return == 250, f"Expected 250, got {reliance.one_day_return}"
    assert reliance.one_day_return_percent == pytest.approx(2.44), f"Expected 2.44, got {reliance.one_day_return_percent}"

    # -------- Summary --------

    summary = result.summary

    assert summary.total_invested_amount == 25000, f"Expected 25000, got {summary.total_invested_amount}"
    assert summary.total_current_value == 26500, f"Expected 26500, got {summary.total_current_value}"
    assert summary.total_return == 1500, f"Expected 1500, got {summary.total_return}"
    assert summary.total_return_percent == pytest.approx(6.0), f"Expected 6.0, got {summary.total_return_percent}"
    assert summary.one_day_return == 750, f"Expected 750, got {summary.one_day_return}"
    assert summary.one_day_return_percent == pytest.approx(2.91), f"Expected 2.91, got {summary.one_day_return_percent}"
    assert summary.holdings_count == 2, f"Expected 2, got {summary.holdings_count}"

    # -------- API Call Validation --------

    assert ('ltp', 'NSE_INFY') in live_data_service.called, f"Expected ('ltp', 'NSE_INFY') in live_data_service.called"
    assert ('ltp', 'NSE_RELIANCE') in live_data_service.called, f"Expected ('ltp', 'NSE_RELIANCE') in live_data_service.called"
    assert ('ohlc', 'NSE_INFY') in live_data_service.called, f"Expected ('ohlc', 'NSE_INFY') in live_data_service.called"
    assert ('ohlc', 'NSE_RELIANCE') in live_data_service.called, f"Expected ('ohlc', 'NSE_RELIANCE') in live_data_service.called"


def test_get_portfolio_metrics_empty(service):
    service._portfolio_service.get_holdings = lambda: []

    result = service.get_portfolio_metrics()

    assert result.summary.total_invested_amount == 0, f"Expected 0, got {result.summary.total_invested_amount}"
    assert result.summary.total_current_value == 0, f"Expected 0, got {result.summary.total_current_value}"
    assert result.summary.total_return == 0, f"Expected 0, got {result.summary.total_return}"
    assert result.summary.holdings_count == 0, f"Expected 0, got {result.summary.holdings_count}"
    assert result.holdings == [], f"Expected [], got {result.holdings}"


def test_get_portfolio_metrics_wraps_exception():
    class BrokenPortfolioService:
        def get_holdings(self):
            raise RuntimeError('failure')

    service = PortfolioMetricsService(
        portfolio_service=BrokenPortfolioService(),
        live_data_service=FakeLiveDataService(),
    )

    with pytest.raises(ServiceError) as exc:
        service.get_portfolio_metrics()

    assert 'GET_PORTFOLIO_METRICS' in str(exc.value), f"Expected 'GET_PORTFOLIO_METRICS' in str(exc.value)"