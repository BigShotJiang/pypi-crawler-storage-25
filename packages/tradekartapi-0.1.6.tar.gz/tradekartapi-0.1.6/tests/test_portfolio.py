import pytest

from tradekartapi.services import PortfolioService
from tradekartapi.exceptions import ServiceError
from tradekartapi.models.annexures import Segment

class FakeSDK:
    def __init__(self):
        self.called = {}

    def get_holdings_for_user(self, timeout = None):
        self.called['get_holdings_for_user'] = {'timeout': timeout}
        return {'holdings': [{'trading_symbol': 'ABC', 'quantity': 1}]}

    def get_positions_for_user(self, segment=None):
        self.called['get_positions_for_user'] = {'segment': segment}
        return {'positions': [{'trading_symbol': 'ABC'}]}

    def get_position_for_trading_symbol(self, trading_symbol, segment):
        self.called['get_position_for_trading_symbol'] = {
            'trading_symbol': trading_symbol,
            'segment': segment,
        }
        return {'position': {'trading_symbol': trading_symbol}}

class FakeAdapter:
    def __init__(self, sdk):
        self.client = sdk

@pytest.fixture
def sdk():
    return FakeSDK()

@pytest.fixture
def service(sdk):
    return PortfolioService(FakeAdapter(sdk))

def test_get_holdings_sdk_response(service, sdk):
    result = service.get_holdings()
    assert isinstance(result, dict)
    assert 'holdings' in result
    assert sdk.called['get_holdings_for_user']

def test_get_positions_without_segment(service, sdk):
    result = service.get_positions()
    assert isinstance(result, dict)
    assert 'positions' in result
    assert sdk.called['get_positions_for_user']['segment'] is None

def test_get_positions_for_symbol(service, sdk):
    result = service.get_positions_for_symbol('INFY', Segment.CASH)
    assert isinstance(result, dict)
    assert result['position']['trading_symbol'] == 'INFY'
    assert sdk.called['get_position_for_trading_symbol']['trading_symbol'] == 'INFY'

def test_get_holdings_wraps_exception():
    class BrokenSDK(FakeSDK):
        def get_holdings_for_user(self, timeout=None):
            raise RuntimeError('sdk down')
    service = PortfolioService(FakeAdapter(BrokenSDK()))
    with pytest.raises(ServiceError) as exc:
        service.get_holdings()
    assert 'Error in getting holdings' in str(exc.value)