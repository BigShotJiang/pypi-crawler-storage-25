import pytest

from tradekartapi.services import MarginService
from tradekartapi.exceptions import ServiceError
from tradekartapi.models.margin import (
    GetAvailableMarginRequest,
    GetOrderMarginRequest,
)
from tradekartapi.models.annexures import Segment


class FakeSDK:
    def __init__(self):
        self.called = {}

    def get_available_margin_details(self):
        self.called['get_available_margin_details'] = True
        return {
            'clear_cash': 1000,
            'net_margin_used': 0,
        }

    def get_order_margin_details(self, segment, orders):
        self.called['get_order_margin_details'] = {
            'segment': segment,
            'orders': orders,
        }
        return {
            'total_required_margin': 500,
            'orders': orders,
        }



class FakeAdapter:
    def __init__(self, sdk):
        self.client = sdk


@pytest.fixture
def sdk():
    return FakeSDK()


@pytest.fixture
def service(sdk):
    return MarginService(FakeAdapter(sdk))


def test_get_available_margin(service, sdk):
    req = GetAvailableMarginRequest()

    result = service.get_available_margin(req)

    assert result is not None
    assert hasattr(result, 'raw')
    assert result.raw['clear_cash'] == 1000
    assert sdk.called.get('get_available_margin_details') is True



def test_get_order_margin(service, sdk):
    orders = [
        {
            'trading_symbol': 'RELIANCE',
            'quantity': 1,
        }
    ]

    req = GetOrderMarginRequest(
        segment=Segment.CASH,
        orders=orders,
    )

    result = service.get_order_margin(req)

    
    assert result is not None
    assert hasattr(result, 'raw')
    assert result.raw['total_required_margin'] == 500
    assert 'get_order_margin_details' in sdk.called
    assert sdk.called['get_order_margin_details']['segment'] == Segment.CASH.value
    assert sdk.called['get_order_margin_details']['orders'] == orders



def test_get_order_margin_empty_orders():
    with pytest.raises(Exception) as exc:
        GetOrderMarginRequest(segment=Segment.CASH, orders=[])

    assert 'orders' in str(exc.value).lower()



def test_get_available_margin_wraps_exception():
    class BrokenSDK(FakeSDK):
        def get_available_margin_details(self):
            raise RuntimeError('sdk down')

    service = MarginService(FakeAdapter(BrokenSDK()))

    with pytest.raises(ServiceError) as exc:
        service.get_available_margin(GetAvailableMarginRequest())

   
    assert 'Error in fetching available margin' in str(exc.value)
    assert 'GET_AVAILABLE_MARGIN' in str(exc.value)



def test_get_order_margin_wraps_exception():
    class BrokenSDK(FakeSDK):
        def get_order_margin_details(self, segment, orders):
            raise RuntimeError('sdk down')

    service = MarginService(FakeAdapter(BrokenSDK()))

    req = GetOrderMarginRequest(
        segment=Segment.CASH,
        orders=[{'trading_symbol': 'RELIANCE', 'quantity': 1}],
    )

    with pytest.raises(ServiceError) as exc:
        service.get_order_margin(req)

   
    assert 'Error in fetching order margin' in str(exc.value)
    assert 'GET_ORDER_MARGIN' in str(exc.value)