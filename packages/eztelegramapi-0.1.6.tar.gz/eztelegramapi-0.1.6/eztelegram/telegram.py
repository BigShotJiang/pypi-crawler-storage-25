import requests

def send_message(TOKEN: str, CHAT_ID: int, text: str):
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage?chat_id={CHAT_ID}&text={text}"
    return requests.get(url)