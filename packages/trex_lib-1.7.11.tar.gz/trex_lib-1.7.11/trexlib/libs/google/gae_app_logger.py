'''
Created on Feb 23, 2026

@author: jacklok
'''

import logging, os
import google.cloud.logging 
from flask import has_request_context, request

class AppLogger:
    _instance = None

    def __init__(self):
        # Detect if we are running on GAE or locally
        # GAE_ENV is 'standard' on App Engine
        self.is_gae = os.getenv('GAE_ENV', '') == 'standard'
        
        if self.is_gae:
            # PRODUCTION: Use Google Cloud Logging
            self.client = google.cloud.logging.Client()
            self.client.setup_logging()
        else:
            # LOCAL: Use standard Python logging to terminal
            logging.basicConfig(
                level=logging.INFO,
                format='%(levelname)s | %(name)s:%(lineno)d | %(message)s'
            )
        
        AppLogger._instance = self

    @staticmethod
    def get_logger(name=__name__):
        if AppLogger._instance is None:
            AppLogger()
        return logging.getLogger(name)

    @staticmethod
    def get_trace_id():
        # Check if we are actually inside a Flask route
        if not has_request_context():
            return None
            
        header = request.headers.get("X-Cloud-Trace-Context")
        if header:
            return header.split("/")[0]
        return None
