"""Matplotlib rendering pipeline for meme images."""

from __future__ import annotations

import textwrap
import threading
import warnings
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

import matplotlib.pyplot as plt
from matplotlib import patheffects
from matplotlib.font_manager import FontProperties, findfont, fontManager

from memeplotlib._cache import TemplateCache
from memeplotlib._config import DEFAULT_FIGSIZE_WIDTH, config
from memeplotlib._template import DEFAULT_TEXT_POSITIONS, Template, TextPosition
from memeplotlib._text import apply_style

if TYPE_CHECKING:
    from matplotlib.axes import Axes
    from matplotlib.backend_bases import RendererBase
    from matplotlib.figure import Figure, SubFigure
    from matplotlib.text import Text

# --- Constants ---

_WRAP_CHARS_PER_FULL_WIDTH = 25  # estimated chars that fill full figure width at ~36pt
_MIN_WRAP_WIDTH = 10  # minimum characters per wrapped line
_FIT_TOLERANCE = 1.1  # allow text to exceed box by 10% before shrinking
_FIT_MAX_ITERATIONS = 20  # maximum iterations for text-fitting loop
_FIT_SHRINK_FACTOR = 0.95  # multiply by this when shrinking font to fit
_MIN_TEXT_EXTENT = 0.01  # guard against near-zero text dimensions

# --- Font handling ---

_FONTS_DIR = Path(__file__).parent / "fonts"

_FONT_MAP = {
    "impact": "Impact",
    "arial": "Arial",
    "comic": "Comic Sans MS",
    "times": "Times New Roman",
    "courier": "Courier New",
}

_bundled_font_registered = False
_font_lock = threading.Lock()


def _register_bundled_fonts() -> None:
    """Register bundled fonts with matplotlib's font manager (once)."""
    global _bundled_font_registered
    if _bundled_font_registered:
        return
    with _font_lock:
        if _bundled_font_registered:
            return
        _bundled_font_registered = True

        if _FONTS_DIR.is_dir():
            for font_path in _FONTS_DIR.glob("*.ttf"):
                fontManager.addfont(str(font_path))


def _resolve_font(font: str) -> str:
    """Map a friendly font name to a system font family name.

    Falls back to the bundled Anton font (Impact-like), then to DejaVu Sans
    if neither the requested font nor the bundled font is available.

    Parameters
    ----------
    font : str
        Friendly font name (e.g., ``"impact"``, ``"comic"``).

    Returns
    -------
    str
        Resolved font family name suitable for matplotlib.
    """
    _register_bundled_fonts()

    name = _FONT_MAP.get(font.lower(), font)

    # Check if the requested font is available
    fp = FontProperties(family=name)
    path = findfont(fp, fallback_to_default=True)

    if "dejavu" in path.lower() and name.lower() not in ("dejavu", "dejavu sans"):
        # Requested font not found — try bundled Anton as Impact substitute
        if font.lower() in ("impact", _FONT_MAP.get("impact", "").lower()):
            anton_fp = FontProperties(family="Anton")
            anton_path = findfont(anton_fp, fallback_to_default=True)
            if "dejavu" not in anton_path.lower():
                return "Anton"

        warnings.warn(
            f"Font '{font}' not found. Using fallback font. "
            f"Install '{font}' for best results.",
            UserWarning,
            stacklevel=3,
        )

    return name


# --- Auto font sizing ---


def _auto_fontsize(
    text: str,
    box_width_frac: float,
    box_height_frac: float,
    base_size: float = 36.0,
) -> float:
    """Estimate an initial font size based on text length and box dimensions.

    This is a starting heuristic; :func:`_fit_text_to_box` refines it
    further using the actual renderer.

    Parameters
    ----------
    text : str
        The text to size.
    box_width_frac : float
        Bounding box width as a fraction of the figure (0.0 to 1.0).
    box_height_frac : float
        Bounding box height as a fraction of the figure (0.0 to 1.0).
    base_size : float, optional
        Starting font size in points (default: 36.0).

    Returns
    -------
    float
        Estimated font size in points.
    """
    num_lines = text.count("\n") + 1
    max_line_len = max(len(line) for line in text.split("\n"))

    # Scale down for longer text
    length_factor = max(0.3, 1.0 - max_line_len / 60)
    # Scale down for more lines
    lines_factor = max(0.4, 1.0 / (num_lines**0.5))
    # Scale by box area
    area_factor = (box_width_frac * box_height_frac) ** 0.25

    return float(base_size * length_factor * lines_factor * area_factor)


def _get_renderer(fig: Figure | SubFigure) -> RendererBase:
    """Get a renderer from a figure, handling API differences across versions.

    Parameters
    ----------
    fig : Figure or SubFigure
        The matplotlib figure (or subfigure) whose canvas should provide a
        renderer.

    Returns
    -------
    matplotlib.backend_bases.RendererBase
        The figure's renderer.
    """
    canvas = fig.canvas
    get_renderer = getattr(canvas, "get_renderer", None)
    if get_renderer is not None:
        try:
            return cast("RendererBase", get_renderer())
        except (RuntimeError, AttributeError):
            pass
    # Fallback: draw to create renderer
    canvas.draw()
    # mypy: get_renderer is documented on Agg/PDF/SVG canvases but not on
    # FigureCanvasBase; rely on duck typing here.
    return cast("RendererBase", canvas.get_renderer())  # type: ignore[attr-defined]


def _fit_text_to_box(
    ax: Axes,
    txt: Text,
    box_w: float,
    box_h: float,
    min_fontsize: float = 8.0,
) -> None:
    """Iteratively reduce font size until text fits within the bounding box.

    Uses matplotlib's renderer to measure actual text extent in axes
    coordinates.

    Parameters
    ----------
    ax : Axes
        The axes containing the text.
    txt : Text
        The matplotlib Text object to resize.
    box_w : float
        Maximum width in axes-fraction coordinates.
    box_h : float
        Maximum height in axes-fraction coordinates.
    min_fontsize : float, optional
        Minimum allowed font size in points (default: 8.0).
    """
    fig = ax.get_figure()
    if fig is None:
        return  # detached axes; nothing to render against
    renderer = _get_renderer(fig)

    for _ in range(_FIT_MAX_ITERATIONS):
        bbox = txt.get_window_extent(renderer=renderer)
        # Convert to axes fraction
        inv = ax.transAxes.inverted()
        bbox_axes = bbox.transformed(inv)
        text_w = bbox_axes.width
        text_h = bbox_axes.height

        if text_w <= box_w * _FIT_TOLERANCE and text_h <= box_h * _FIT_TOLERANCE:
            break

        # mpl's Text.get_fontsize() is annotated as float|str, but it returns
        # a numeric size at runtime once the text has been added to an axes.
        current = float(txt.get_fontsize())
        if current <= min_fontsize:
            break

        # Scale down proportionally
        scale = min(
            box_w / max(text_w, _MIN_TEXT_EXTENT),
            box_h / max(text_h, _MIN_TEXT_EXTENT),
        )
        new_size = max(min_fontsize, current * scale * _FIT_SHRINK_FACTOR)
        txt.set_fontsize(new_size)


# --- Core drawing ---


def _draw_meme_text(
    ax: Axes,
    text: str,
    x: float,
    y: float,
    pos: TextPosition,
    font: str = "impact",
    color: str = "white",
    outline_color: str = "black",
    outline_width: float = 2.0,
    fontsize: float | None = None,
    style: str = "upper",
    **text_kwargs: Any,
) -> Text:
    """Draw meme-style text with outline at the given axes-coordinate position.

    Parameters
    ----------
    ax : Axes
        The matplotlib axes to draw on.
    text : str
        The text to render.
    x : float
        X position in axes coordinates (0--1).
    y : float
        Y position in axes coordinates (0--1, 0=bottom).
    pos : TextPosition
        TextPosition describing the text box dimensions and alignment.
    font : str, optional
        Font family name (default: ``"impact"``).
    color : str, optional
        Text fill color (default: ``"white"``).
    outline_color : str, optional
        Text outline/stroke color (default: ``"black"``).
    outline_width : float, optional
        Outline stroke width (default: 2.0).
    fontsize : float or None, optional
        Font size in points. Auto-calculated if ``None``.
    style : str, optional
        Text style (``"upper"``, ``"lower"``, ``"none"``).
    **text_kwargs
        Additional keyword arguments forwarded to :meth:`Axes.text`. User
        values take precedence over the meme-specific defaults above.

    Returns
    -------
    Text
        The matplotlib Text object.
    """
    display_text = apply_style(text, style)

    # Word-wrap long text
    display_text = _smart_wrap(display_text, pos.scale_x)

    if fontsize is None:
        fontsize = _auto_fontsize(
            display_text, pos.scale_x, pos.scale_y, base_size=config["fontsize"]
        )

    font_family = _resolve_font(font)

    text_call_kwargs: dict[str, Any] = dict(
        transform=ax.transAxes,
        fontsize=fontsize,
        fontfamily=font_family,
        fontweight="bold",
        color=color,
        ha=pos.align,
        va="center",
        linespacing=1.1,
        path_effects=[
            patheffects.Stroke(linewidth=outline_width * 2, foreground=outline_color),
            patheffects.Normal(),
        ],
    )
    text_call_kwargs.update(text_kwargs)

    txt = ax.text(x, y, display_text, **text_call_kwargs)

    # Refine font size to fit the bounding box
    _fit_text_to_box(ax, txt, pos.scale_x, pos.scale_y)

    return txt


def _smart_wrap(text: str, box_width_frac: float) -> str:
    """Wrap text based on the available box width.

    Already-wrapped text (containing newlines) is left as-is.

    Parameters
    ----------
    text : str
        The text to potentially wrap.
    box_width_frac : float
        Available box width as a fraction of the figure (0.0 to 1.0).

    Returns
    -------
    str
        Text with newlines inserted at wrap points, if needed.
    """
    if "\n" in text:
        return text

    # Estimate characters that fit based on box width fraction
    # At ~36pt on a typical figure, ~20 chars fill the full width
    chars_per_line = max(_MIN_WRAP_WIDTH, int(box_width_frac * _WRAP_CHARS_PER_FULL_WIDTH))
    if len(text) <= chars_per_line:
        return text

    return "\n".join(textwrap.wrap(text, width=chars_per_line))


# --- Main rendering functions ---


def render_meme(
    template: Template,
    lines: list[str],
    ax: Axes | None = None,
    figsize: tuple[float, float] | None = None,
    dpi: int | None = None,
    font: str | None = None,
    color: str | None = None,
    outline_color: str | None = None,
    outline_width: float | None = None,
    fontsize: float | None = None,
    style: str | None = None,
    cache: TemplateCache | None = None,
    **text_kwargs: Any,
) -> tuple[Figure, Axes]:
    """Render a meme image using matplotlib.

    Parameters
    ----------
    template : Template
        The Template to render.
    lines : list of str
        Text lines for each text position.
    ax : Axes or None, optional
        Existing axes to render onto. A new figure is created if ``None``.
    figsize : tuple of (float, float) or None, optional
        Figure size in inches ``(width, height)``.
    dpi : int or None, optional
        Dots per inch for rendering.
    font : str or None, optional
        Font family name.
    color : str or None, optional
        Text fill color.
    outline_color : str or None, optional
        Text outline color.
    outline_width : float or None, optional
        Outline stroke width.
    fontsize : float or None, optional
        Font size in points (auto if ``None``).
    style : str or None, optional
        Text style (``"upper"``, ``"lower"``, ``"none"``).
    cache : TemplateCache or None, optional
        Template cache for image retrieval.
    **text_kwargs
        Additional keyword arguments forwarded to :meth:`Axes.text` for each
        rendered caption.

    Returns
    -------
    tuple of (Figure, Axes)
        The matplotlib Figure and Axes containing the rendered meme.
    """
    # Apply defaults from config
    dpi = dpi if dpi is not None else config["dpi"]
    font = font or config["font"]
    color = color or config["color"]
    outline_color = outline_color or config["outline_color"]
    outline_width = outline_width if outline_width is not None else config["outline_width"]
    style = style or config["style"]

    # Load the background image
    img = template.get_image(cache=cache)
    h, w = img.shape[:2]
    aspect = w / h

    if ax is None:
        if figsize is None:
            fig_w = DEFAULT_FIGSIZE_WIDTH
            fig_h = fig_w / aspect
            figsize = (fig_w, fig_h)
        fig, ax = plt.subplots(figsize=figsize, dpi=dpi)
    else:
        parent_fig = ax.get_figure()
        if parent_fig is None:
            raise RuntimeError("Provided ax has no associated Figure")
        # Drawing onto existing axes always renders into a real Figure (not a
        # SubFigure) at runtime, but the type checker can't know that.
        fig = cast("Figure", parent_fig)

    # Display the background image edge-to-edge
    ax.imshow(img, aspect="auto")
    ax.axis("off")
    fig.subplots_adjust(left=0, right=1, top=1, bottom=0)

    # Draw text for each line
    positions = template.text_positions
    for i, text in enumerate(lines):
        if not text or i >= len(positions):
            continue

        pos = positions[i]
        # Center of the text box in axes coordinates (y flipped: mpl 0=bottom)
        x = pos.anchor_x + pos.scale_x / 2
        y = 1.0 - (pos.anchor_y + pos.scale_y / 2)

        _draw_meme_text(
            ax,
            text,
            x,
            y,
            pos,
            font=font,
            color=color,
            outline_color=outline_color,
            outline_width=outline_width,
            fontsize=fontsize,
            style=style,
            **text_kwargs,
        )

    return fig, ax


def render_memify(
    fig: Figure,
    lines: list[str],
    position: str = "top-bottom",
    font: str | None = None,
    color: str | None = None,
    outline_color: str | None = None,
    outline_width: float | None = None,
    fontsize: float | None = None,
    style: str | None = None,
    **text_kwargs: Any,
) -> Figure:
    """Add meme text overlay to an existing matplotlib figure.

    Creates a transparent overlay axes spanning the full figure and draws
    meme-style text on top.

    Parameters
    ----------
    fig : Figure
        The matplotlib figure to add text to.
    lines : list of str
        Text lines to overlay.
    position : str, optional
        Layout preset -- ``"top-bottom"`` (default), ``"top"``,
        ``"bottom"``, or ``"center"``.
    font : str or None, optional
        Font family name.
    color : str or None, optional
        Text fill color.
    outline_color : str or None, optional
        Text outline color.
    outline_width : float or None, optional
        Outline stroke width.
    fontsize : float or None, optional
        Font size in points (auto if ``None``).
    style : str or None, optional
        Text style (``"upper"``, ``"lower"``, ``"none"``).
    **text_kwargs
        Additional keyword arguments forwarded to :meth:`Axes.text` for each
        rendered caption.

    Returns
    -------
    Figure
        The modified Figure with meme text overlay.
    """
    font = font or config["font"]
    color = color or config["color"]
    outline_color = outline_color or config["outline_color"]
    outline_width = outline_width if outline_width is not None else config["outline_width"]
    style = style or config["style"]

    # Determine text positions based on layout preset
    valid_positions = {"top-bottom", "top", "bottom", "center"}
    if position not in valid_positions:
        raise ValueError(
            f"Invalid position {position!r}. Must be one of: "
            f"{', '.join(sorted(valid_positions))}"
        )

    if position == "top-bottom":
        positions = list(DEFAULT_TEXT_POSITIONS)
    elif position == "top":
        positions = [DEFAULT_TEXT_POSITIONS[0]]
    elif position == "bottom":
        positions = [DEFAULT_TEXT_POSITIONS[1]]
    else:  # center
        positions = [TextPosition(anchor_x=0.0, anchor_y=0.4, scale_x=1.0, scale_y=0.2)]

    # Create a transparent overlay axes spanning the full figure
    overlay_ax = fig.add_axes((0.0, 0.0, 1.0, 1.0), facecolor="none")
    overlay_ax.set_xlim(0, 1)
    overlay_ax.set_ylim(0, 1)
    overlay_ax.axis("off")

    for i, text in enumerate(lines):
        if not text or i >= len(positions):
            continue

        pos = positions[i]
        x = pos.anchor_x + pos.scale_x / 2
        y = 1.0 - (pos.anchor_y + pos.scale_y / 2)

        _draw_meme_text(
            overlay_ax,
            text,
            x,
            y,
            pos,
            font=font,
            color=color,
            outline_color=outline_color,
            outline_width=outline_width,
            fontsize=fontsize,
            style=style,
            **text_kwargs,
        )

    return fig
