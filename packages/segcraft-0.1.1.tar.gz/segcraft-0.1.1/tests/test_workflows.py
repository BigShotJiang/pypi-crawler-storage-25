from segcraft.engine.workflows import evaluate, predict, train


def base_config(task_type="multiclass", num_classes=3):
    return {
        "task": {"type": task_type, "num_classes": num_classes},
        "model": {"name": "unet", "encoder": "resnet34", "pretrained": True},
        "data": {},
        "train": {"epochs": 3, "optimizer": "adam", "learning_rate": 1e-3, "loss": "auto"},
        "eval": {"metrics": []},
        "predict": {"input_path": "in", "output_path": "out", "overlay_alpha": 0.5},
        "runtime": {},
    }


def test_train_auto_loss_multiclass():
    summary = train(base_config())
    assert summary["train"]["loss"] == "cross_entropy_dice"
    assert summary["train"]["scheduler"] == "none"
    assert summary["train"]["status"] == "data_missing"


def test_train_auto_loss_binary():
    summary = train(base_config(task_type="binary", num_classes=1))
    assert summary["train"]["loss"] == "bce_dice"


def test_predict_and_evaluate_modes():
    cfg = base_config()
    assert evaluate(cfg)["mode"] == "evaluate"
    assert predict(cfg)["mode"] == "predict"


def test_predict_missing_input_reports_status_without_torch():
    summary = predict(base_config())
    assert summary["predict"]["status"] == "input_missing"
    assert "does not exist" in summary["predict"]["message"]


def test_evaluate_missing_data_reports_status_without_torch():
    summary = evaluate(base_config())
    assert summary["eval"]["status"] == "data_missing"
