"""CLI package for SegCraft."""
