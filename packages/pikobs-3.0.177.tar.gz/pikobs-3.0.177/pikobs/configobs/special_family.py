"""
pikobs.special_family
=====================
Central registry for observation family metadata.

Provides:
  - DICT_CODTYP     : BUFR type code → long name
  - FAMILY_CODES    : family key → list of BUFR type codes
  - FAMILY_SPECIAL_COL : family key → special grouping column in header
  - Helper functions for label resolution and special-column handling
"""

from __future__ import annotations
from typing import Dict, List, Optional, Tuple
import sqlite3


# ─────────────────────────────────────────────────────────────────────────────
# BUFR type codes → long names
# ─────────────────────────────────────────────────────────────────────────────

DICT_CODTYP: Dict[str, str] = {
     '12': 'SYNOP',         '13': 'SHIP',           '14': 'SYNOP MOBIL',
     '15': 'METAR',         '16': 'SPECI',           '18': 'DRIFTER',
     '32': 'PILOT',         '33': 'PILOT SHIP',      '34': 'PILOT MOBIL',
     '35': 'TEMP',          '36': 'TEMP SHIP',       '37': 'TEMP DROP',
     '38': 'TEMP MOBIL',    '42': 'AMDAR',           '128': 'AIREP',
    '134': 'PAOBS',        '135': 'TEMP + PILOT',   '136': 'TEMP + SYNOP',
    '139': 'TEMP SHIP + PILOT SHIP',                '143': 'SWOB-NONAUTO',
    '144': 'SWOB-AUTO',    '145': 'Patrol ship',    '146': 'ASYNOP',
    '147': 'BUOYS',        '148': 'SWOBNONAUTO-SPECIAL',
    '149': 'SWOBAUTO-SPECIAL',                      '157': 'BUFR',
    '159': 'TEMP PILOT MOBIL',                      '163': 'RADAR',
    '164': 'AMSUA',        '168': 'SSMIS',          '169': 'GPSRO',
    '177': 'ADS',          '181': 'AMSUB',          '182': 'MHS',
    '183': 'AIRS',         '185': 'CSR',             '186': 'IASI',
    '188': 'AMVS',         '189': 'GROUND BASED GPS',
    '192': 'ATMS',         '193': 'CRIS NSR',
    '195': 'constituants chimiques (remote)',
    '196': 'constituants chimiques (in-situ)',
    '198': 'NetWork of Network',
    '200': 'MWHS-2',       '202': 'CRIS FSR',       '254': 'SCAT',
}


# ─────────────────────────────────────────────────────────────────────────────
# Family → BUFR type codes
# ─────────────────────────────────────────────────────────────────────────────

FAMILY_CODES: Dict[str, List[str]] = {
    'ai':  ['42', '128', '157', '177'],
    'sf':  ['12', '13', '14', '15', '16', '18',
            '143', '144', '145', '146', '147', '148', '149', '198'],
    'gp':  ['189'],
    'csr': ['185'],
    'ua':  ['32', '33', '34', '35', '36', '37', '38', '135', '139'],
}


# ─────────────────────────────────────────────────────────────────────────────
# Family → special grouping column in header table
#
# Each entry defines:
#   column  : column name in the header SQLite table
#   labels  : optional dict mapping column values to human-readable strings
#             (None = use the raw value as label)
#
# To add a new family:
#   'myfam': {'column': 'MY_COLUMN', 'labels': {1: 'Type A', 2: 'Type B'}}
# ─────────────────────────────────────────────────────────────────────────────

FAMILY_SPECIAL_COL: Dict[str, Dict] = {
    'sw': {
        'column': 'WIND_COMP_METHOD',
        'labels': {
            1: 'IR channel',
            2: 'Visible channel',
            3: 'Water vapour channel',
            4: 'Multi-spectral',
            5: 'WV clear air',
            6: 'Ozone channel',
            7: 'WV cloud/clear unspecified',
        },
    },
    'ra': {
        'column': 'elevation',
        'labels': None,   # use raw elevation value as label
    },
}


# ─────────────────────────────────────────────────────────────────────────────
# Family → BUFR type codes (used to group id_stn by instrument type)
# ─────────────────────────────────────────────────────────────────────────────

FAMILY_CODES: Dict[str, List[str]] = {
    'ai':  ['42', '128', '157', '177'],
    'sf':  ['12', '13', '14', '15', '16', '18',
            '143', '144', '145', '146', '147', '148', '149', '198'],
    'gp':  ['189'],
    'csr': ['185'],
    'ua':  ['32', '33', '34', '35', '36', '37', '38', '135', '139'],
}


# ─────────────────────────────────────────────────────────────────────────────
# Helper functions
# ─────────────────────────────────────────────────────────────────────────────

def codtyp_label(id_stn: str) -> str:
    """Return a human-readable label for an id_stn value.

    If id_stn starts with a numeric code present in DICT_CODTYP
    (e.g. '35_XXXXX') returns 'TEMP (35_XXXXX)'.
    Otherwise returns id_stn unchanged.
    """
    code = str(id_stn).strip()
    if code in DICT_CODTYP:
        return f"{DICT_CODTYP[code]} ({code})"
    for c, name in DICT_CODTYP.items():
        if code.startswith(c + '_') or code.startswith(c + ' '):
            return f"{name} ({code})"
    return code


def get_special_col(family: str) -> Optional[str]:
    """Return the special grouping column name for a family, or None."""
    entry = FAMILY_SPECIAL_COL.get(family)
    return entry['column'] if entry else None


def get_special_label(family: str, value) -> str:
    """Return the human-readable label for a special column value."""
    entry = FAMILY_SPECIAL_COL.get(family)
    if entry is None:
        return str(value)
    labels = entry.get('labels')
    if labels is None:
        return str(value)
    try:
        return labels.get(int(value), str(value))
    except (ValueError, TypeError):
        return str(value)


def has_special_col(db_path: str, family: str) -> bool:
    """Return True if the moyenne table in db_path has the special column."""
    col = get_special_col(family)
    if col is None:
        return False
    try:
        with sqlite3.connect(db_path) as conn:
            cursor = conn.execute("PRAGMA table_info('moyenne');")
            cols = [row[1] for row in cursor.fetchall()]
        return col in cols
    except Exception:
        return False


def get_special_col_values(db_path: str, family: str) -> List:
    """Return sorted distinct values of the special column from moyenne."""
    col = get_special_col(family)
    if col is None:
        return []
    try:
        with sqlite3.connect(db_path) as conn:
            rows = conn.execute(
                f"SELECT DISTINCT {col} FROM moyenne "
                f"WHERE {col} IS NOT NULL ORDER BY {col};"
            ).fetchall()
        return [r[0] for r in rows]
    except Exception:
        return []


def special_col_sql_type(family: str) -> str:
    """Return the SQL type for the special column (for CREATE TABLE)."""
    col = get_special_col(family)
    if col is None:
        return ''
    # elevation is FLOAT, everything else INTEGER
    if col.lower() == 'elevation':
        return f', {col} FLOAT'
    return f', {col} INTEGER'


def iter_special_values(db_path: str, family: str,
                        enabled: bool) -> List[Optional[object]]:
    """Return the list of values to iterate over for special-column plots.

    Parameters
    ----------
    db_path : str
        Path to the aggregated SQLite database.
    family : str
        Observation family key (e.g. 'sw', 'ra').
    enabled : bool
        If False, return [None] — no special-column split, treat all together.
        If True, return the distinct values found in the DB.

    Returns
    -------
    List of values, one plot will be produced per value.
    [None] means a single plot with no special-column filter.
    """
    if not enabled:
        return [None]
    values = get_special_col_values(db_path, family)
    return values if values else [None]


def special_sql_filter(family: str, value) -> str:
    """Return SQL WHERE fragment for a given special column value.

    Returns '' if value is None (no filter).
    """
    if value is None:
        return ''
    col = get_special_col(family)
    if col is None:
        return ''
    return f" AND {col} = {value!r}"


def special_filename_tag(family: str, value) -> str:
    """Return a filename-safe tag for the special column value."""
    if value is None:
        return ''
    col = get_special_col(family)
    if col is None:
        return ''
    safe = str(value).replace(' ', '_').replace('/', '_')
    return f'_{col}_{safe}'


def special_title_tag(family: str, value) -> str:
    """Return a human-readable title fragment for the special column value."""
    if value is None:
        return ''
    return f'\n{get_special_col(family)}: {get_special_label(family, value)}'


def get_codtyp_groups(db_path: str, family: str
                      ) -> List[Tuple[str, str, str]]:
    """Return (code, label, sql_filter) tuples from CODTYP column in header.

    For families in FAMILY_CODES (ai, sf, ua, gp, csr), grouping is done
    by the CODTYP column in the header table — one plot per instrument type.

    Reads the distinct CODTYP values actually present in the DB so only
    types with real data are returned.

    Returns
    -------
    List of (code_str, label, sql_filter) where:
      code_str   : e.g. '42'
      label      : e.g. 'AMDAR (42)' — used in filename and web viewer
      sql_filter : e.g. "AND CODTYP = 42"

    Returns empty list if the family is not in FAMILY_CODES or if the
    CODTYP column does not exist in the DB.
    """
    if family not in FAMILY_CODES:
        return []
    allowed = set(FAMILY_CODES[family])
    try:
        with sqlite3.connect(db_path) as conn:
            # Check CODTYP exists in moyenne (aggregated from header)
            cols = [r[1] for r in
                    conn.execute("PRAGMA table_info('moyenne');").fetchall()]
            if 'CODTYP' not in cols:
                return []
            rows = conn.execute(
                "SELECT DISTINCT CODTYP FROM moyenne "
                "WHERE CODTYP IS NOT NULL ORDER BY CODTYP;"
            ).fetchall()
    except Exception:
        return []

    groups = []
    for (code,) in rows:
        code_str = str(int(code))
        if code_str not in allowed:
            continue
        name       = DICT_CODTYP.get(code_str, code_str)
        label      = f"{name} ({code_str})"
        sql_filter = f"AND CODTYP = {int(code)}"
        groups.append((code_str, label, sql_filter))
    return groups


def has_codtyp_groups(family: str) -> bool:
    """Return True if this family should be grouped by CODTYP."""
    return family in FAMILY_CODES
