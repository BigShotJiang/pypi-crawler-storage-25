#!/usr/bin/env python3
"""
================================================================
pikobs.pikobsburp2rdb — BURP to SQLite Conversion Module
================================================================
 
Convert meteorological **BURP** binary files into **SQLite RDB**
databases consumable by the Pikobs diagnostic pipeline.
 
The module wraps the external ``burp2rdb`` CMC binary and executes
many conversions in parallel through Dask. It is the typical first
step before running any other Pikobs module (``mapobs``, ``pipeline``,
``profile``, ...) on raw assimilation outputs.
 
For each ``(experience, family, date)`` triplet the module produces
one SQLite file::
 
    <pathwork>/<experience_name>/<YYYYMMDDHH>_<family>
 
:Author:        D. Lo / CMC pikobs maintainers
:Module:        ``pikobs.pikobsburp2rdb``
:Last revision: 2026-05
 
Highlights
----------
 
* **Single source of truth** for the ``burp2rdb`` binary, resolved via
  ``$BURP2RDB_BIN`` first, then ``shutil.which()``. The orchestrator
  refuses to start if it cannot find a working binary.
* **Hard timeout** on every ``subprocess.run`` call (default 30 min)
  so a stuck conversion can never block the whole job.
* **No PIPE deadlock** — stderr is merged into stdout and captured as
  bytes, avoiding the well-known full-PIPE hang when ``burp2rdb``
  emits large amounts of progress output.
* **No interactive prompt in parallel mode** — when ``--n_cpus > 1``
  the script never calls ``input()`` (which would hang waiting for
  stdin in a PBS batch job). ``--force_clean`` is required for those
  cases.
* **Automatic family discovery** when ``--family`` is not given,
  scanning the input directories for ``YYYYMMDDHH_<family>`` files.
* **Integrity verification** of every produced SQLite file before
  declaring the conversion successful.
 
.. note::
   This module shells out to the ``burp2rdb`` binary shipped by CMC.
   Make sure the matching SSM packages are loaded before launching.
   The wrapper ``run_pikobsburp2rdb.sh`` handles this for you.
 
---
 
1. How to run
=============
 
Download the example script, make it executable, and launch it. The
script submits itself to PBS automatically if run from a login node.
 
.. code-block:: bash
 
   wget https://gitlab.science.gc.ca/dlo001/Pikobs/-/raw/master/pikobs/script/run_pikobsburp2rdb.sh
   chmod +x run_pikobsburp2rdb.sh
   ./run_pikobsburp2rdb.sh
 
.. note::
   The script handles PBS submission and environment activation
   automatically. You do **not** need to call ``qsub`` yourself.
 
Expected output:
 
.. code-block:: text
 
   🚀 Launching from login node. Auto-submitting to qsub...
   ✅ Job submitted: 52919002.ppp8pbs-01-ib
   👀 Waiting for output...
   =================================================================
   🖥️  Running on: ppp8cn-046  JobID: 52919002.ppp8pbs-01-ib
   🐍 Python: 3.11.x  |  📦 Pikobs: 1.2.0
   =================================================================
   [burp2rdb] Converting 240 files on 40 workers...
   [burp2rdb] OK  2026020100_ua  →  experiment/2026020100_ua  (4.2s)
   [burp2rdb] OK  2026020106_ua  →  experiment/2026020106_ua  (3.9s)
   ...
   ✅ Process completed successfully.
   🏁 Job finished. Log: /home/.../burp2rdb_20260515_175019.log
 
---
 
2. Configuration
================
 
Open ``run_pikobsburp2rdb.sh`` and edit the ``USER SETTINGS`` block:
 
.. code-block:: bash
 
   # === USER SETTINGS — edit these ================================
   PATHWORK="/path/to/output_dir"            # where SQLite files go
   PATH_EXPERIENCE="/path/to/burp_files/"   # where raw BURP files live
   EXPERIENCE_NAME="your_experiment_label"  # subfolder name in PATHWORK
   DATESTART="2026020100"                   # YYYYMMDDHH (UTC)
   DATEEND="2026020200"                     # YYYYMMDDHH (UTC), inclusive
   FAMILY="ua sw ai sc ro"                  # space-separated, or leave
                                            # empty for auto-discovery
   N_CPUS=40                                # Dask workers
   WALLTIME="02:00:00"
   # ================================================================
 
+----------------------+--------------------------------------------------+
| Variable             | Description                                      |
+======================+==================================================+
| ``PATHWORK``         | Root output directory for SQLite RDB files       |
+----------------------+--------------------------------------------------+
| ``PATH_EXPERIENCE``  | Directory containing raw BURP binary files       |
+----------------------+--------------------------------------------------+
| ``EXPERIENCE_NAME``  | Subfolder name and label for the run             |
+----------------------+--------------------------------------------------+
| ``DATESTART``        | Start of the period ``YYYYMMDDHH``               |
+----------------------+--------------------------------------------------+
| ``DATEEND``          | End of the period ``YYYYMMDDHH`` (inclusive)     |
+----------------------+--------------------------------------------------+
| ``FAMILY``           | Observation families — leave empty to            |
|                      | auto-discover from the input directory           |
+----------------------+--------------------------------------------------+
| ``N_CPUS``           | Number of parallel Dask workers                  |
+----------------------+--------------------------------------------------+
| ``WALLTIME``         | PBS walltime limit ``HH:MM:SS``                  |
+----------------------+--------------------------------------------------+
 
---
 
3. Output
=========
 
After a successful run ``$PATHWORK`` contains::
 
   $PATHWORK/
   └── <experience_name>/
       ├── 2026020100_ua
       ├── 2026020100_sw
       ├── 2026020106_ua
       ├── 2026020106_sw
       └── ...
 
Each file is a valid SQLite database containing the ``header`` and
``DATA`` tables consumed by ``mapobs``, ``pipeline``, and all other
Pikobs diagnostic modules.
 
---
 
4. Support
==========
 
For bugs, feature requests or questions, open an issue at:
 
* **GitLab issues**:
  `<https://gitlab.science.gc.ca/dlo001/Pikobs/-/issues>`_
"""
from __future__ import annotations

import argparse
import datetime
import logging
import os
import shutil
import subprocess
import sys
from datetime import timedelta
from typing import List, Optional, Tuple

import dask
from dask.distributed import Client


# =============================================================================
# Module-level configuration
# =============================================================================

#: Per-conversion hard timeout (seconds). Prevents a stuck burp2rdb
#: process from holding up the whole job until PBS walltime.
SUBPROCESS_TIMEOUT_S: int = 30 * 60      # 30 minutes

#: Minimum BURP file size in bytes; smaller files are flagged as
#: probably empty and skipped (not an error, just a warning).
MIN_BURP_SIZE_BYTES: int = 100

#: SSM tip printed when burp2rdb is not found, to help the user.
_SSM_HINT = (
    "Load the burp2rdb SSM packages first, e.g.:\n"
    "    . r.load.dot cmd/cmda/utils/<DATE>/burp2rdb_<VER>_<ARCH>\n"
    "    . ssmuse-sh -d eccc/cmd/cmda/utils/<DATE>\n"
    "    . ssmuse-sh -d eccc/cmo/cmoi/base/<DATE>\n"
    "Or use the wrapper run_pikobsburp2rdb.sh."
)

logging.basicConfig(
    format="[%(levelname)s] %(message)s",
    level=logging.INFO,
)
log = logging.getLogger("pikobsburp2rdb")


# =============================================================================
# BURP type mapping
# =============================================================================

def get_burp_type(family_name: str) -> str:
    """Map a Pikobs family name to the ``-type`` argument of burp2rdb.

    Some family names carry suffixes (``_qc``, ``_allsky``, ``fsr1``,
    ``fsr2``) that are *not* part of the BURP type taxonomy understood
    by ``burp2rdb``. This function strips them and applies a small
    rename table for the few cases where the BURP type differs from
    the family name.

    :param family_name: Pikobs family name (e.g. ``"to_amsua_allsky"``).
    :returns: BURP type accepted by ``burp2rdb -type ...``
              (e.g. ``"amsua"``).
    :rtype: str
    """
    f = family_name.lower()
    for suffix in ("_qc", "_allsky", "fsr1", "fsr2"):
        f = f.replace(suffix, "")
    rename = {
        "to_amsua": "amsua",
        "to_amsub": "amsub",
        "gp":       "gbgps",
    }
    return rename.get(f, f)


# =============================================================================
# burp2rdb binary resolution
# =============================================================================

def _resolve_burp2rdb() -> Optional[str]:
    """Locate the ``burp2rdb`` binary.

    Resolution order:

    1. ``$BURP2RDB_BIN`` environment variable (the wrapper script sets
       this after ``r.load.dot``).
    2. ``shutil.which("burp2rdb")`` — searches the current ``$PATH``.

    :returns: Absolute path to a usable binary, or ``None`` if not found.
    """
    env_path = os.environ.get("BURP2RDB_BIN", "").strip()
    if env_path and os.path.isfile(env_path) and os.access(env_path, os.X_OK):
        return env_path
    return shutil.which("burp2rdb")


# =============================================================================
# Conversion engine
# =============================================================================

def _is_sqlite3_intact(filepath: str) -> bool:
    """Cheap integrity check on a SQLite file.

    Opens the file read-only and runs a trivial query against
    ``sqlite_master``. Any database-level error is reported as "not
    intact" — corrupted files, partially-written files and non-SQLite
    files all fail this check.

    :param filepath: file to check.
    :returns: ``True`` if the file opens and answers a SELECT.
    :rtype: bool
    """
    if not os.path.isfile(filepath):
        return False
    try:
        import sqlite3
        with sqlite3.connect(filepath, timeout=5) as conn:
            conn.execute("SELECT name FROM sqlite_master LIMIT 1;").fetchone()
        return True
    except sqlite3.DatabaseError:
        return False


def convert_single_file(f_in:     str,
                        exp_name: str,
                        family:   str,
                        f_out:    str,
                        fdate:    str) -> bool:
    """Convert one BURP file to SQLite via ``burp2rdb``.

    This function is invoked once per ``(experience, family, date)``
    triplet by Dask workers. It is **idempotent**: if ``f_out`` is
    already a valid SQLite file the function returns immediately.

    The conversion is **atomic**: ``burp2rdb`` writes to ``f_out.tmp``
    first; only if the produced file passes :func:`_is_sqlite3_intact`
    is it renamed to ``f_out``.

    :param f_in:     path to the input BURP file.
    :param exp_name: experiment label (for log messages).
    :param family:   Pikobs family name.
    :param f_out:    target SQLite path.
    :param fdate:    ``YYYYMMDDHH`` (for log messages only).
    :returns: ``True`` on success, ``False`` on any error.
    :rtype: bool
    """
    # Idempotency: skip if already converted.
    if _is_sqlite3_intact(f_out):
        log.info("OK    Already converted: %s/%s",
                 exp_name, os.path.basename(f_out))
        return True

    if not os.path.isfile(f_in):
        log.warning("Missing input: %s for %s in %s", fdate, family, exp_name)
        return False

    try:
        size = os.path.getsize(f_in)
    except OSError as exc:
        log.warning("Cannot stat %s: %s", f_in, exc)
        return False
    if size < MIN_BURP_SIZE_BYTES:
        log.warning("Probably-empty file %s (%d bytes); skipped.",
                    os.path.basename(f_in), size)
        return False

    burp2rdb_bin = _resolve_burp2rdb()
    if not burp2rdb_bin:
        log.error("burp2rdb binary not found in this worker.\n%s", _SSM_HINT)
        return False

    f_tmp = f_out + ".tmp"
    if os.path.isfile(f_tmp):
        try:
            os.remove(f_tmp)
        except OSError:
            pass

    log.info("RUN   %s (%s) for %s", fdate, family, exp_name)

    cmd = [burp2rdb_bin,
           "-in", f_in,
           "-type", get_burp_type(family),
           "-out", f_tmp]

    try:
        # Merge stderr into stdout to avoid a deadlock if burp2rdb
        # emits more than a pipe's worth on stderr.
        # capture_output=True keeps the parent's stderr clean.
        subprocess.run(
            cmd,
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=SUBPROCESS_TIMEOUT_S,
        )
    except subprocess.TimeoutExpired:
        log.error("TIMEOUT after %ds on %s (%s, %s)",
                  SUBPROCESS_TIMEOUT_S, fdate, family, exp_name)
        if os.path.isfile(f_tmp):
            os.remove(f_tmp)
        return False
    except subprocess.CalledProcessError as exc:
        out = exc.stdout.decode("utf-8", errors="ignore") if exc.stdout else ""
        log.error("burp2rdb failed for %s (%s, %s):\n%s",
                  fdate, family, exp_name, out.strip())
        if os.path.isfile(f_tmp):
            os.remove(f_tmp)
        return False

    if not _is_sqlite3_intact(f_tmp):
        log.error("Generated file is not a valid SQLite: %s", f_tmp)
        try:
            os.remove(f_tmp)
        except OSError:
            pass
        return False

    try:
        os.replace(f_tmp, f_out)
    except OSError as exc:
        log.error("Cannot move %s -> %s: %s", f_tmp, f_out, exc)
        return False

    return True


# =============================================================================
# Orchestrator
# =============================================================================

def _detect_families(paths: List[str]) -> List[str]:
    """Scan input directories for ``YYYYMMDDHH_<family>`` files.

    Returns the sorted union of every family seen in any directory.
    """
    detected: set = set()
    for path_exp in paths:
        if not os.path.isdir(path_exp):
            continue
        for item in os.listdir(path_exp):
            # Expected format: 10 digits + "_" + family
            if len(item) > 11 and item[10] == "_" and item[:10].isdigit():
                detected.add(item[11:])
    return sorted(detected)


def run_pikobsburp2db(args: argparse.Namespace) -> None:
    """Top-level orchestrator.

    Validates inputs, plans the (experience × family × date) task
    matrix, and dispatches the conversions through Dask.

    :param args: argparse namespace from :func:`arg_call`.
    """
    # --- Resolve binary up-front ---------------------------------------
    burp_bin = _resolve_burp2rdb()
    if not burp_bin:
        log.critical("burp2rdb not found.\n%s", _SSM_HINT)
        sys.exit(1)
    log.info("Using burp2rdb at: %s", burp_bin)
    # Propagate to workers via env var (Dask Client uses os.environ).
    os.environ["BURP2RDB_BIN"] = burp_bin

    # --- Date range ----------------------------------------------------
    try:
        dt_start = datetime.datetime.strptime(args.datestart, "%Y%m%d%H")
        dt_end   = datetime.datetime.strptime(args.dateend,   "%Y%m%d%H")
    except ValueError:
        log.critical("Dates must be in YYYYMMDDHH format.")
        sys.exit(1)
    if dt_end < dt_start:
        log.critical("--dateend (%s) precedes --datestart (%s).",
                     args.dateend, args.datestart)
        sys.exit(1)

    # --- Output directory ---------------------------------------------
    # Three cases:
    #   1. Doesn't exist        → create it.
    #   2. Exists + force_clean → wipe and recreate.
    #   3. Exists + interactive → ask; on "yes" wipe; on "no" keep
    #      existing files (only missing ones will be (re)produced).
    #   4. Exists + parallel    → refuse, demand --force_clean.
    #
    # We use ignore_errors=True on rmtree to survive stale NFS handles
    # on CMC shared filesystems.
    if not os.path.exists(args.pathwork):
        log.info("Creating output directory: %s", args.pathwork)
        os.makedirs(args.pathwork, exist_ok=True)
    else:
        if args.force_clean:
            log.info("Wiping existing output directory: %s", args.pathwork)
            shutil.rmtree(args.pathwork, ignore_errors=True)
            os.makedirs(args.pathwork, exist_ok=True)
        elif args.n_cpus > 1:
            log.critical(
                "Output dir '%s' already exists. "
                "Use --force_clean (mandatory in parallel mode).",
                args.pathwork,
            )
            sys.exit(1)
        else:
            ans = input(f"[?] Output dir '{args.pathwork}' exists. "
                        f"Delete? (yes/no): ")
            if ans.strip().lower() == "yes":
                shutil.rmtree(args.pathwork, ignore_errors=True)
                os.makedirs(args.pathwork, exist_ok=True)
            else:
                log.info("Keeping existing files; only missing ones "
                         "will be produced.")
                # Make sure the directory really exists (race-safe).
                os.makedirs(args.pathwork, exist_ok=True)

    # --- Family list ---------------------------------------------------
    families = args.family or _detect_families(args.path_experience_files)
    if not families:
        log.critical("No families given and none auto-detected in inputs.")
        sys.exit(1)
    log.info("Processing %d families: %s",
             len(families), ", ".join(families))

    # --- Build task list ----------------------------------------------
    tasks: List[Tuple[str, str, str, str, str]] = []
    current = dt_start
    while current <= dt_end:
        fdate = current.strftime("%Y%m%d%H")
        for path_exp, name_exp in zip(args.path_experience_files,
                                      args.experience_name):
            exp_out_dir = os.path.join(args.pathwork, name_exp)
            os.makedirs(exp_out_dir, exist_ok=True)
            for family in families:
                tasks.append((
                    os.path.join(path_exp, f"{fdate}_{family}"),
                    name_exp,
                    family,
                    os.path.join(exp_out_dir, f"{fdate}_{family}"),
                    fdate,
                ))
        current += timedelta(hours=6)

    log.info("Total tasks: %d (%d dates × %d experiments × %d families)",
             len(tasks),
             ((dt_end - dt_start).total_seconds() // 21600) + 1,
             len(args.experience_name),
             len(families))

    # --- Run -----------------------------------------------------------
    if args.n_cpus <= 1:
        log.info("Sequential mode (n_cpus=%d)", args.n_cpus)
        results = [convert_single_file(*t) for t in tasks]
    else:
        log.info("Parallel mode with %d Dask workers", args.n_cpus)
        with Client(processes=True,
                    threads_per_worker=1,
                    n_workers=args.n_cpus,
                    silence_logs=40):
            results = list(dask.compute(
                *[dask.delayed(convert_single_file)(*t) for t in tasks]
            ))

    n_ok   = sum(1 for r in results if r)
    n_fail = len(results) - n_ok
    log.info("Done. %d successful, %d failed/skipped, total %d.",
             n_ok, n_fail, len(results))
    if n_fail > 0:
        # Non-zero exit so the PBS job is marked as failed but the user
        # still gets all the successful files.
        sys.exit(2)


# =============================================================================
# CLI
# =============================================================================
from pikobs.pbs_submit import maybe_submit_to_pbs

def arg_call() -> None:
   
    """Parse CLI arguments and dispatch to :func:`run_pikobsburp2db`."""
    parser = argparse.ArgumentParser(
        prog="pikobs-burp2rdb",
        description="Mass-convert BURP files to SQLite RDB databases.",
    )
    parser.add_argument("--path_experience_files", nargs="+", required=True,
                        help="One or more directories containing BURP files "
                             "named YYYYMMDDHH_<family>.")
    parser.add_argument("--experience_name", nargs="+", required=True,
                        help="One label per input directory (same length).")
    parser.add_argument("--pathwork", required=True,
                        help="Output directory (one subfolder per experience).")
    parser.add_argument("--datestart", required=True,
                        help="Start date YYYYMMDDHH (UTC).")
    parser.add_argument("--dateend",   required=True,
                        help="End date YYYYMMDDHH (UTC), inclusive.")
    parser.add_argument("--n_cpus", type=int, default=1,
                        help="Number of Dask workers (default: 1 = sequential).")
    parser.add_argument("--family", nargs="+", default=[],
                        help="Families to convert. Empty = auto-detect from inputs.")
    parser.add_argument("--force_clean", action="store_true",
                        help="Wipe the output directory if it already exists. "
                             "Mandatory when --n_cpus > 1.")
    parser.add_argument('--no_submit', action='store_true',
                   help="Skip PBS auto-submission and run locally.")


    args = parser.parse_args()
    if len(args.path_experience_files) != len(args.experience_name):
        log.critical(
            "Number of --path_experience_files (%d) does not match "
            "--experience_name (%d).",
            len(args.path_experience_files), len(args.experience_name),
        )
        sys.exit(1)
    args = parser.parse_args()
    maybe_submit_to_pbs(args)

    run_pikobsburp2db(args)


if __name__ == "__main__":
    arg_call()
