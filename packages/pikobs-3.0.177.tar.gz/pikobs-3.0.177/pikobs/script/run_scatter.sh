#!/usr/bin/env bash
# ============================================================================
# run_scatter.sh
# ----------------------------------------------------------------------------
# Wrapper to generate geographic TILED statistics maps (omp, oma, nobs, obs,
# dens, bcorr, stdomp, stdoma) over a user-defined date range, optionally
# comparing two runs (experiment - control) as a relative percentage.
#
# Two ways to launch:
#   (a) Submit this script directly to PBS:  qsub run_scatter.sh
#       -> uses the #PBS directives below.
#   (b) Run it from a login node:            ./run_scatter.sh
#       -> Pikobs auto-submits to PBS via its built-in job manager
#          (unless --no_submit is uncommented to force local execution).
# ============================================================================

# ============================================================================
# 0. PBS RESOURCE REQUEST  (used only when launched with `qsub run_scatter.sh`)
# ----------------------------------------------------------------------------
#   -l select=N        : number of chunks (nodes)
#   -l ncpus=80        : CPUs per chunk          (must match N_CPUS below)
#   -l mpiprocs=80     : MPI ranks per chunk     (= ncpus for Dask workers)
#   -l ompthreads=1    : OpenMP threads per rank (1 -> pure Dask parallelism)
#   -l mem=185gb       : RAM per chunk
#   -l place=scatter   : spread chunks across distinct nodes
#   -l walltime=H:M:S  : maximum wall-clock time
#   -I -X              : interactive + X11 forwarding (drop for batch mode)
# ============================================================================
#PBS -N pikobs_scatter
#PBS -l select=4:ncpus=80:mpiprocs=80:ompthreads=1:mem=185gb
#PBS -l place=scatter
#PBS -l walltime=6:00:00
#PBS -j oe

set -eo pipefail

# ============================================================================
# 1. USER SETTINGS (Edit these parameters)
# ============================================================================

# ---- Inputs --------------------------------------------------------------
# Directory containing the SQLite obs databases (YYYYMMDDHH_<family>) for
# the EXPERIMENT run. Required.
PATH_EXPERIENCE_FILES="/home/dlo001/sites8/Data_pikobs/monitoring/"

# Label printed on the title of every generated figure for the experiment.
EXPERIENCE_NAME="experience"

# Optional CONTROL run for A/B comparison. Leave as "undefined" to render
# a single-run map. When set, every metric is plotted as experiment-control
# expressed as a relative percentage: (|m_exp| - |m_ctl|) / |m_ctl| * 100.
PATH_CONTROL_FILES="undefined"
CONTROL_NAME="undefined"

# ---- Output --------------------------------------------------------------
# Output directory. WARNING: wiped on each run to prevent ghost files.
# Will contain one subdir per family with the .db files and .png maps,
# plus an interactive HTML viewer at pikobs_scatter_viewer.html.
PATHWORK="/home/dlo001/sites8/pikobs_scatter"

# ---- Time window ---------------------------------------------------------
# Processing window in YYYYMMDDHH format (UTC). Inclusive on both ends,
# stepped every 6 hours internally.
DATESTART="2026021000"
DATEEND="2026021200"

# ---- Selection -----------------------------------------------------------
# Geographic region(s). Space-separated list. Examples:
#   Monde, HemisphereNord, HemisphereSud, Tropiques, Europe, Canada, ...
REGION="Monde"

# Observation family/families. Space-separated list.
#   e.g.  to_amsua_allsky  ai  sw  tmp  uv  ps  sc_atms  cris  iasi  ...
FAMILY="sw"

# Bitmask filter criteria ("all" = include everything; other typical
# values: "assimilee", "rejets", "bgckalt", ...). Single key.
FLAGS_CRITERIA="all"

# Metric(s) to compute and plot. Space-separated list. Available:
#   omp     -> Observation minus Prediction (background departure)
#   oma     -> Observation minus Analysis
#   stdomp  -> Standard deviation of OMP
#   stdoma  -> Standard deviation of OMA
#   nobs    -> Number of observations per tile
#   obs     -> Mean raw observation value
#   dens    -> Observation density (obs/km^2)
#   bcorr   -> Bias correction (satellite radiances only)
FONCTION="omp oma stdomp stdoma nobs obs dens"

# Optional varno filter (space-separated integer codes). Leave empty to
# use the family's default varno list.
VARNOS=""

# ---- Tiling --------------------------------------------------------------
# Tile size in DEGREES (lon x lat). Smaller -> finer maps but slower.
# Typical: 2x2 global, 1x1 regional, 5x5 for sparse data.
BOXSIZEX=2
BOXSIZEY=2

# Map projection(s). Space-separated list. Available:
#   cyl, OrthoN, OrthoS, robinson, Europe, Canada,
#   AmeriqueNord, Npolar, Spolar, reg
PROJECTION="cyl"

# Vertical layers to bin observations into, as a string of intervals in hPa.
# Empty parens means "all levels". Examples:
#   "[(,)]"              -> single map, all levels
#   "[(700,900)]"        -> one map, 700-900 hPa layer
#   "[(,),(700,900)]"    -> two maps: all levels AND 700-900 hPa
LAYER="[(,),(700,900)]"  

# ---- Per-plot grouping ---------------------------------------------------
# id_stn: all -> one plot per station ; join -> all stations pooled
ID_STN="G% M%"
# channel: all -> one plot per channel/vcoord ; join -> all pooled
CHANNEL="join"

# ---- Rendering -----------------------------------------------------------
# SIGMA -> standard stats mode (mu/sigma textbox on each map).
MODE="SIGMA"
# POINTS: OFF -> coloured tiles only ; ON -> text count on each tile
POINTS="OFF"

# ---- Parallelism ---------------------------------------------------------
# Number of parallel Dask workers. Must match ncpus requested in #PBS above.
N_CPUS=80

# ============================================================================
# 2. SYSTEM SETUP (Do not edit below this line)
# ============================================================================
# When launched via qsub, PBS cd's to $HOME by default; jump to the
# submission directory if it was provided.
[ -n "${PBS_O_WORKDIR}" ] && cd "${PBS_O_WORKDIR}"

source /home/${USER}/pikobs_install/load_pikobs.sh

# ============================================================================
# 3. EXECUTION
# ============================================================================
# Pikobs auto-submits this to PBS when run from a login node.
# Uncomment --no_submit to force local execution on a compute node.
python -c 'import pikobs; pikobs.scatter.arg_call()'                \
       --path_control_files    "${PATH_CONTROL_FILES}"              \
       --control_name          "${CONTROL_NAME}"                    \
       --path_experience_files "${PATH_EXPERIENCE_FILES}"           \
       --experience_name       "${EXPERIENCE_NAME}"                 \
       --pathwork              "${PATHWORK}"                        \
       --datestart             "${DATESTART}"                       \
       --dateend               "${DATEEND}"                         \
       --region                ${REGION}                            \
       --family                ${FAMILY}                            \
       --flags_criteria        "${FLAGS_CRITERIA}"                  \
       --fonction              ${FONCTION}                          \
       --boxsizex              "${BOXSIZEX}"                        \
       --boxsizey              "${BOXSIZEY}"                        \
       --projection            ${PROJECTION}                        \
       --mode                  "${MODE}"                            \
       --Points                "${POINTS}"                          \
       --id_stn                "${ID_STN}"                          \
       --channel               "${CHANNEL}"                         \
       --n_cpus                "${N_CPUS}"                          \
       --special_column         on                                 \
       --layer                 "${LAYER}"
       #       --no_submit    
