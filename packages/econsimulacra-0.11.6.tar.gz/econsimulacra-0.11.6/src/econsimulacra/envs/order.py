from typing import Optional


class Order:
    """Order class.

    In EconSimulacra, agents can submit an order by specifying the request in an dictionary format.
    Then, the environment will convert the dictionary into an Order object here and process it.

    See also: ``econsimulacra.envs.base.Environment._add_new_orders_and_proposals``
    """

    def __init__(
        self,
        agent_id: int,
        counterparty_id: int,
        item_name: str,
        item_amount: float | int,
        price: Optional[float],
        order_id: int,
        ttl: Optional[int] = None,
    ) -> None:
        """Initialization.

        Args:
            agent_id (int): The ID of the agent who submitted the order.
            counterparty_id (int): The ID of the counterparty agent.
            item_name (str): The name of the item being ordered.
            item_amount (float | int): The amount of the item being ordered.
            price (Optional[float]): The price of the item. If None, it means the price is determined by the market.
            order_id (int): The unique ID of the order.
            ttl (Optional[int]): Time to live for the order in terms of simulation steps. If None, it defaults to 2 steps.

        Note:
            Order instance is initialized by the environment through the
            ``_add_new_orders_and_proposals`` method, and the ``order_id`` is generated
            by the environment to ensure uniqueness.

            Order action example::

                {
                    "orders": [
                        {
                            "counterparty_id": int,
                            "counterparty_name": str,
                            "item_name": str,
                            "item_amount": float,
                            "ttl": int,
                        },
                        ...
                    ],
                }
        """
        self.agent_id: int = agent_id
        self.counterparty_id: int = counterparty_id
        self.item_name: str = item_name
        self.item_amount: float | int = item_amount
        self.price: Optional[float] = price
        self.order_id: int = order_id
        self.expire_in: int = ttl if ttl is not None else 2
        self.accepted_amount: float | int = 0

    def react(self, amount: float | int) -> None:
        """React to the order by accepting a certain amount of the item.

        Args:
            amount (float | int): The amount of the item accepted by the counterparty.
                Must be less than or equal to the remaining item amount in the order.

        Note:
            When the order is reacted by the counterparty, the environment
            with call this method to update the accepted amount.
            The accepted amount will be executed in the concurrent step.
            See also: ``econsimulacra.envs.base.Environment._process_reactions``
        """
        if amount > (self.item_amount - self.accepted_amount):
            raise ValueError(
                f"Cannot execute order for amount {amount} greater than remaining item amount {self.item_amount - self.accepted_amount}."
            )
        self.accepted_amount += amount

    def execute(self) -> None:
        """Execute the order by reducing the item amount by the accepted amount.

        Note:
            This should be called in the concurrent step after the reactions are processed.
            See also: ``econsimulacra.envs.base.Environment._process_orders_and_proposals``
        """
        self.item_amount -= self.accepted_amount
        self.accepted_amount = 0

    def update_time(self) -> None:
        """Update the time to live for the order.

        Note:
            This should be called in each simulation step to decrement the time to live.
            See also: ``econsimulacra.envs.base.Environment._update_time``
        """
        self.expire_in -= 1

    def is_fulfilled(self) -> bool:
        """Check if the order is fulfilled, which means either the item amount is fully accepted or the order has expired.

        Note:
            This should be called to determine if the order can be removed from the simulation.
            See also: ``econsimulacra.envs.base.Environment._remove_expired_orders_and_proposals``
        """
        return self.item_amount <= 0 or self.expire_in <= 0

    def is_expired(self) -> bool:
        """Check if the order is expired, which means the time to live has reached zero or below.

        Note:
            This should be called to determine if the order has expired and should be removed from the simulation.
            See also: ``econsimulacra.envs.base.Environment._remove_expired_orders_and_proposals``
        """
        return self.expire_in <= 0 and self.item_amount > 0

    def __repr__(self) -> str:
        return (
            f"Order(order_id={self.order_id}, agent_id={self.agent_id}, counterparty_id={self.counterparty_id}, "
            f"item_name='{self.item_name}', item_amount={self.item_amount}, accepted_amount={self.accepted_amount}, "
            f"price={self.price}, expire_in={self.expire_in})"
        )


class SwapProposal:
    """SwapProposal class.

    In EconSimulacra, agents can also submit a swap proposal by specifying the request in an dictionary format.
    Then, the environment will convert the dictionary into a SwapProposal object here and process it.

    See also: ``econsimulacra.envs.base.Environment._add_new_orders_and_proposals``
    """

    def __init__(
        self,
        proposer_agent_id: int,
        responder_agent_id: int,
        give_item_name: str,
        give_item_amount: float | int,
        get_item_name: str,
        get_item_amount: float | int,
        proposal_id: int,
        ttl: Optional[int] = None,
    ) -> None:
        """Initialization.

        Args:
            proposer_agent_id (int): The ID of the agent who submitted the swap proposal.
            responder_agent_id (int): The ID of the agent who is proposed to swap with.
            give_item_name (str): The name of the item the proposer is offering to give.
            give_item_amount (float | int): The amount of the item the proposer is offering to give.
            get_item_name (str): The name of the item the proposer wants to get in return.
            get_item_amount (float | int): The amount of the item the proposer wants to get in return.
            proposal_id (int): The unique ID of the swap proposal.
            ttl (Optional[int]): Time to live for the swap proposal in terms of simulation steps. If None, it defaults to 2 steps.

        Note:
            SwapProposal instance is initialized by the environment through the
            ``_add_new_orders_and_proposals`` method, and the ``proposal_id`` is generated
            by the environment to ensure uniqueness.

            Swap proposal action example::

                {
                    "proposals": [
                        {
                            "responder_agent_id": int,
                            "responder_agent_name": str,
                            "give_item_name": str,
                            "give_item_amount": float,
                            "get_item_name": str,
                            "get_item_amount": float,
                            "ttl": int,
                        },
                        ...
                    ]
                }
        """
        self.proposer_agent_id: int = proposer_agent_id
        self.responder_agent_id: int = responder_agent_id
        self.give_item_name: str = give_item_name
        self.give_item_amount: float | int = give_item_amount
        self.get_item_name: str = get_item_name
        self.get_item_amount: float | int = get_item_amount
        self.proposal_id: int = proposal_id
        self.expire_in: int = ttl if ttl is not None else 2
        self.accept: Optional[bool] = None

    def react(self, accept: bool) -> None:
        """React to the swap proposal by accepting or rejecting it.

        Args:
            accept (bool): Whether the responder agent accepts the swap proposal.

        Note:
            Different from Order, SwapProposal can only be accepted or rejected as a whole, and there is no partial acceptance.
            When the swap proposal is reacted by the responder agent,
            the environment will call this method to update the acceptance status.
            The accepted swap proposal will be executed in the concurrent step,
            while the rejected swap proposal will be removed in the next step.
            See also: ``econsimulacra.envs.base.Environment._process_reactions``
        """
        self.accept = accept

    def update_time(self) -> None:
        """Update the time to live for the swap proposal.

        Note:
            This should be called in each simulation step to decrement the time to live.
            See also: ``econsimulacra.envs.base.Environment._update_time``
        """
        self.expire_in -= 1

    def is_fulfilled(self) -> bool:
        """Check if the swap proposal is fulfilled, which means either it is accepted or it has expired.

        Returns:
            bool: whether the swap proposal is fulfilled.
        """
        return self.accept or self.expire_in <= 0

    def is_expired(self) -> bool:
        """Check if the swap proposal is expired, which means the time to live has reached zero or below.

        Note:
            This should be called to determine if the swap proposal has expired and should be removed from the simulation.
            See also: ``econsimulacra.envs.base.Environment._remove_expired_orders_and_proposals``
        """
        return self.expire_in <= 0 and self.accept is not True

    def __repr__(self) -> str:
        return (
            f"SwapProposal(proposal_id={self.proposal_id}, "
            f"proposer_agent_id={self.proposer_agent_id}, responder_agent_id={self.responder_agent_id}, "
            f"give_item_name='{self.give_item_name}', give_item_amount={self.give_item_amount}, "
            f"get_item_name='{self.get_item_name}', get_item_amount={self.get_item_amount}, "
            f"expire_in={self.expire_in}, accept={self.accept})"
        )
