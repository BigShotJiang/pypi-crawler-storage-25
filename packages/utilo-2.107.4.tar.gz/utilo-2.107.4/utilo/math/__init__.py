# =============================================================================
# C O P Y R I G H T
# -----------------------------------------------------------------------------
# Copyright (c) 2020-2024 by Helmut Konrad Schewe. All rights reserved.
# This file is property of Helmut Konrad Schewe. Any unauthorized copy,
# use or distribution is an offensive act against international law and may
# be prosecuted under federal law. Its content is company confidential.
# =============================================================================

import collections
import contextlib
import enum
import functools
import math
import statistics

# default number of digits to round
NDIGITS = 2


def roundme(
    *items: float,
    digits: int = NDIGITS,
    convert: bool = True,
    none: bool = False,
) -> float:
    """Round `items` to `NDIGITS.

    This method supports to round floats, tuple/list of floats. The
    passed datatype stays the same.

    >>> roundme(1.55, 2.50, 3.06, digits=1)
    [1.6, 2.5, 3.1]
    >>> roundme([1.5, 2.5, 3.2])
    [1.5, 2.5, 3.2]
    >>> roundme((1.53333, 2.5666, 3.21111), digits=3)
    (1.533, 2.567, 3.211)
    >>> roundme([10.5], digits=0, convert=False)
    [10.0]
    >>> roundme([10.5], digits=0)
    10.0
    >>> roundme([1.555, None, 3.222], none=True)
    [1.55, None, 3.22]
    >>> roundme([1.555, None, 3.222], none=False)
    Traceback (most recent call last):
        ...
    ValueError: require float, list or tuple, not: "(None,)", or none=True

    Args:
        items: list of floats or a single float
        digits(int): amount of numbers after dot
        convert(bool): convert single iter item to float
        none(bool): if True, do not raise Error if value is None
    Raises:
        ValueError: if no float or list/tuple of numbers is passed
    Returns:
        List of round `items` or a single rounded item.
    """
    assert digits >= 0, f'negative digits {digits}'
    result = None
    try:
        result = [
            round(item, digits) if none is False or item is not None else None  # pylint:disable=C2001
            for item in items
        ]
    except TypeError as error:
        # support roundme([1,2,3]); roundme((1.5,2.33,3.2))
        if not isinstance(items[0], (list, tuple)):
            msg = f'require float, list or tuple, not: "{items}", or none=True'
            raise ValueError(msg) from error
        result = [roundme(item, digits=digits, none=none) for item in items[0]]
        if isinstance(items[0], tuple):
            # ensure that input which was a tuple stays a tuple
            result = tuple(result)
    if len(result) == 1 and convert:
        return result[0]
    return result


def roundshe(func=None, *, digits=2, convert: bool = True):
    """\
    >>> @roundshe
    ... def hello(test:str):
    ...     return 1.3335
    >>> hello('hi')
    1.33
    >>> @roundshe(digits=5)
    ... def three():
    ...     return 1.36666666
    >>> three()
    1.36667
    """

    def decorating_function(user_function):

        @functools.wraps(func)
        def wrapper(*args, **kwds):
            result = user_function(*args, **kwds)
            result = roundme(result, digits=digits, convert=convert)
            return result

        return wrapper

    # support @decorator() and @decorator
    if func is None:
        return decorating_function
    return decorating_function(func)


def isascending(
    items: 'utilo.math.number.Numbers',
    *,
    strict: bool = True,
) -> bool:
    """Check that `items` are ascending numbers.

    >>> isascending([1, 2, 3, 4])
    True
    >>> isascending((5, 2.2, 5))
    False
    >>> isascending((0.6, 0.8, 1.0))
    True
    >>> isascending([1, 2, 2, 2, 3], strict=False)
    True
    """
    items = [float(item) for item in items]
    diff = [
        (after - current) for (current, after) in zip(items[:-1], items[1:])
    ]
    if strict:
        return all(item > 0 for item in diff)
    return all(item >= 0 for item in diff)


def modes(data: 'utilo.math.number.Numbers') -> 'utilo.math.number.Number':
    """Return the most common data point from discrete or nominal data.

    It is possible to have multiple common data points, there are sorted
    ascending.

    >>> modes((1, 1, 2, 2, 3))
    [1, 2]

    See: statistics.mode

    Args:
        data: list of numbers
    Raises:
        StatisticsError: if data is empty
    Returns:
        Most common number.
    """
    if not data:
        raise statistics.StatisticsError('no mode for empty data')
    table = _counts(data)
    if len(table) == 1:
        return table[0][0]
    current = sorted([item[0] for item in table])
    return current


def _counts(data):
    """\
    >>> _counts([])
    []
    """
    # HINT: COPIED FROM PYTHON
    # Generate a table of sorted (value, frequency) pairs.
    table = collections.Counter(iter(data)).most_common()
    if not table:
        return table
    # Extract the values with the highest frequency.
    maxfreq = table[0][1]
    for i in range(1, len(table)):  # pylint:disable=C0103
        if table[i][1] != maxfreq:
            table = table[:i]
            break
    return table


def mode(items, minimize: bool = False):
    """Determine single mode out of `items`.

    >>> mode((1, 1, 2, 2))
    2
    >>> mode((1, 1, 2, 2), minimize=True)
    1
    """
    result = modes(items)
    with contextlib.suppress(TypeError):
        return result[0] if minimize else result[-1]
    return result


def diff_mode(
    items: 'utilo.math.number.Numbers',
    max_diff: float = 2.0,
) -> 'utilo.math.number.Numbers':
    """Compute mode of `item` and determine matched `items` which does
    not more differ than `max_diff` from mode.

    >>> diff_mode([1,1,3,5])
    [1, 1, 3]

    Args:
        items(Numbers): items to filter
        max_diff(float): max difference to mode which matches the classifier
    Returns:
        matched items
    """
    mode_ = mode(items)
    matched = [item for item in items if math.fabs(item - mode_) <= max_diff]
    return matched


class Strategy(enum.Enum):
    LOWER = enum.auto()
    UPPER = enum.auto()
    LINEARISE = enum.auto()


def lookup(
    value: 'utilo.math.number.Number',
    table: list,
    strategy: Strategy = None,
    right_outranges_none: bool = True,
    left_outranges_none: bool = True,
) -> 'utilo.math.number.Number':
    """Use table lookup to determine holy value.

    Out of Bounds:
    >>> lookup(0, [(10,10), (20, 30), (30, 0.5)])
    >>> lookup(40, [(10,10), (20, 30), (30, 0.5)])

    Out of Bounds with backup:
    >>> lookup(40, [(10,10), (20, 30), (30, 0.5)], right_outranges_none=False)
    0.5
    >>> lookup(0, [(10,10), (20, 30), (30, 0.5)], left_outranges_none=False)
    10

    Different strategies:
    >>> lookup(30, [(10,10), (20, 30), (30, 0.5)], strategy = Strategy.UPPER)
    0.5
    >>> lookup(15, [(10,10), (20, 30), (30, 0.5)])
    10
    >>> lookup(15, [(10,10), (20, 30), (30, 0.5)], strategy = Strategy.LINEARISE)
    20.0
    >>> lookup(100, [(10,10), (20, 30), (30, 0.5)]) is None
    True

    Args:
        value: selector to determine holy value
        table: contains holy values to determine on given `value`.
        strategy: select left, right or linearise
        right_outranges_none: True: if lookup outranges return None
                              False: if lookup outrange use maxvalue
        left_outranges_none: True: if lookup outranges return None
                             False: if lookup outrange use minvalue
    Returns:
        determined value
    """
    # TODO: VERY SLOW
    assert len(table) >= 2, f'invalid data table: {table}'
    if strategy is None:
        strategy = Strategy.LOWER
    if value < table[0][0]:
        return None if left_outranges_none else table[0][1]
    if value > table[-1][0]:
        return None if right_outranges_none else table[-1][1]
    lower, result_lower = table[0]
    for upper, result_upper in table[1:]:
        if lower <= value <= upper:
            if strategy == Strategy.LINEARISE:
                diff = upper - lower
                mo = (result_upper - result_lower) / diff  # pylint:disable=C0103
                return result_lower + mo * (value - lower)
            if strategy == Strategy.LOWER:
                return result_lower
            return result_upper  # if strategy == Strategy.UPPER: always upper
        lower, result_lower = upper, result_upper
    # already checked at the beginning of the method
    return None  # pragma: no cover


def diffs(items: 'utilo.math.number.Numbers') -> 'utilo.math.number.Numbers':
    """Difference between current and successor.

    >>> diffs([1, 5, 10, 5.5])
    [4.0, 5.0, 4.5]
    """
    assert len(items) >= 2, f'no enough items: {len(items)}'
    result = [
        math.fabs(first - second) for first, second in zip(
            items[1:],
            items[0:-1],
        )
    ]
    return result


def gradient(items: list) -> list:
    """\
    >>> gradient((1, 2, 3, 4, 4, 4, 1.5, 0))
    [1, 1, 1, 0, 0, -2.5, -1.5]
    >>> gradient((1, 4))
    [3]
    >>> gradient((1,))
    []
    """
    result = [
        (after - current) for current, after in zip(items[0:-1], items[1:])
    ]
    result = [roundme(item) for item in result]
    return result
