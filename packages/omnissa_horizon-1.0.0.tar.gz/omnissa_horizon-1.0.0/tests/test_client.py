"""Unit tests for HorizonClient – no real server needed (uses responses mock)."""
import pytest
import responses as rsps_lib
from requests.exceptions import ConnectionError as ReqConnError
from omnissa_horizon import HorizonClient, HorizonAPIError

BASE = "https://horizon.test.local/rest"


def _make_client():
    return HorizonClient("https://horizon.test.local", verify_ssl=False)


@rsps_lib.activate
def test_login_success():
    rsps_lib.add(rsps_lib.POST, f"{BASE}/login",
                 json={"access_token": "acc123", "refresh_token": "ref456"}, status=200)
    client = _make_client()
    result = client.login("admin", "pass", "DOMAIN")
    assert result["access_token"] == "acc123"
    assert client._access_token == "acc123"
    assert client._refresh_token == "ref456"


@rsps_lib.activate
def test_login_failure_raises():
    rsps_lib.add(rsps_lib.POST, f"{BASE}/login",
                 json={"error": "Invalid credentials"}, status=401)
    client = _make_client()
    with pytest.raises(HorizonAPIError) as exc_info:
        client.login("admin", "wrong", "DOMAIN")
    assert exc_info.value.status_code == 401


@rsps_lib.activate
def test_logout_clears_tokens():
    rsps_lib.add(rsps_lib.POST, f"{BASE}/login",
                 json={"access_token": "a", "refresh_token": "r"}, status=200)
    rsps_lib.add(rsps_lib.POST, f"{BASE}/logout", status=200)
    client = _make_client()
    client.login("admin", "pass", "DOMAIN")
    client.logout()
    assert client._access_token is None
    assert client._refresh_token is None


@rsps_lib.activate
def test_token_refresh():
    rsps_lib.add(rsps_lib.POST, f"{BASE}/login",
                 json={"access_token": "old", "refresh_token": "r"}, status=200)
    rsps_lib.add(rsps_lib.POST, f"{BASE}/refresh",
                 json={"access_token": "new", "refresh_token": "r2"}, status=200)
    client = _make_client()
    client.login("admin", "pass", "DOMAIN")
    client.refresh_access_token()
    assert client._access_token == "new"
    assert client._refresh_token == "r2"


@rsps_lib.activate
def test_context_manager_auto_logout():
    rsps_lib.add(rsps_lib.POST, f"{BASE}/login",
                 json={"access_token": "a", "refresh_token": "r"}, status=200)
    rsps_lib.add(rsps_lib.POST, f"{BASE}/logout", status=200)
    with _make_client() as client:
        client.login("admin", "pass", "DOMAIN")
        assert client._access_token == "a"
    assert client._access_token is None


@rsps_lib.activate
def test_list_desktop_pools():
    rsps_lib.add(rsps_lib.POST, f"{BASE}/login",
                 json={"access_token": "a", "refresh_token": "r"}, status=200)
    rsps_lib.add(rsps_lib.GET, f"{BASE}/inventory/v1/desktop-pools",
                 json=[{"id": "pool-1", "name": "Win11-Pool"}], status=200)
    rsps_lib.add(rsps_lib.POST, f"{BASE}/logout", status=200)
    with _make_client() as client:
        client.login("admin", "pass", "DOMAIN")
        pools = client.inventory.list_desktop_pools()
    assert len(pools) == 1
    assert pools[0]["name"] == "Win11-Pool"


@rsps_lib.activate
def test_connection_server_monitors():
    rsps_lib.add(rsps_lib.POST, f"{BASE}/login",
                 json={"access_token": "a", "refresh_token": "r"}, status=200)
    rsps_lib.add(rsps_lib.GET, f"{BASE}/monitor/connection-servers",
                 json=[{"id": "cs-1", "name": "CS01", "status": "OK"}], status=200)
    rsps_lib.add(rsps_lib.POST, f"{BASE}/logout", status=200)
    with _make_client() as client:
        client.login("admin", "pass", "DOMAIN")
        servers = client.monitor.list_connection_server_monitors()
    assert servers[0]["name"] == "CS01"
    assert servers[0]["status"] == "OK"


@rsps_lib.activate
def test_404_raises_horizon_api_error():
    rsps_lib.add(rsps_lib.POST, f"{BASE}/login",
                 json={"access_token": "a", "refresh_token": "r"}, status=200)
    rsps_lib.add(rsps_lib.GET, f"{BASE}/inventory/v1/machines/bad-id",
                 json={"error": "Not found"}, status=404)
    client = _make_client()
    client.login("admin", "pass", "DOMAIN")
    with pytest.raises(HorizonAPIError) as exc:
        client.inventory.get_machine("bad-id")
    assert exc.value.status_code == 404
