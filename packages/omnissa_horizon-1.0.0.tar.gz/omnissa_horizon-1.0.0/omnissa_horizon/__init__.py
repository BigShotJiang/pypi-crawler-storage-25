# Copyright 2026 Abhilash Jha
# Contact: sshabhilash@gmail.com | abhilashjha25@gmail.com
# SPDX-License-Identifier: Apache-2.0
"""
omnissa-horizon — Python SDK for the Omnissa Horizon Connection Server REST API
================================================================================

Supports Horizon Server REST API v2603 (OpenAPI 3.0)
Auto-generated from the official Swagger specification:
  https://developer.omnissa.com/horizon-apis/horizon-server/versions/2603/

This is an independent, community-built SDK. Not officially affiliated
with or endorsed by Omnissa LLC.

Quick Start::

    from omnissa_horizon import HorizonClient, HorizonAPIError

    with HorizonClient("https://horizon.example.com", verify_ssl=False) as client:
        client.login("admin", "P@ssw0rd", "DOMAIN")

        # Monitor
        servers = client.monitor.list_connection_server_monitors()
        sessions = client.monitor.list_session_monitors()

        # Inventory
        pools = client.inventory.list_desktop_pools()

        # Config
        settings = client.config.get_global_settings()
"""

from omnissa_horizon.client import HorizonClient, HorizonAPIError

__version__ = "1.0.0"
__author__ = "Abhilash Jha"
__email__ = "sshabhilash@gmail.com, abhilashjha25@gmail.com"
__license__ = "Apache-2.0"
__all__ = ["HorizonClient", "HorizonAPIError"]
