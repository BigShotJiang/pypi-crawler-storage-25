# Copyright 2026 Abhilash Jha
# SPDX-License-Identifier: Apache-2.0

"""Entitlements API – auto-generated from Omnissa Horizon Server Swagger v2603."""
from typing import TYPE_CHECKING, Dict, Any, Optional, List

if TYPE_CHECKING:
    from omnissa_horizon.client import HorizonClient


class EntitlementsAPI:
    """APIs for Entitlements (tag: Entitlements)."""

    def __init__(self, client: "HorizonClient"):
        self._c = client

    def bulk_delete_application_pool_entitlements(self, body: dict = None):
        """
        Delete the bulk entitlements for a set of application pools

        DELETE /entitlements/v1/application-pools
        """
        return self._c.request("DELETE", "/entitlements/v1/application-pools", params=None, json_body=body)

    def list_application_pool_entitlements(self, page: str = None, size: str = None, filter: str = None):
        """
        Lists the entitlements for Application Pools in the environment.

        GET /entitlements/v1/application-pools
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        return self._c.request("GET", "/entitlements/v1/application-pools", params=params, json_body=None)

    def bulk_create_application_pool_entitlements(self, body: dict = None):
        """
        Create the bulk entitlements for a set of application pools

        POST /entitlements/v1/application-pools
        """
        return self._c.request("POST", "/entitlements/v1/application-pools", params=None, json_body=body)

    def get_application_pool_entitlements(self, id):
        """
        Returns the IDs of users or groups entitled to a given application pool.

        GET /entitlements/v1/application-pools/{id}
        """
        return self._c.request("GET", f"/entitlements/v1/application-pools/{id}", params=None, json_body=None)

    def delete_cloud_entitlements(self, body: dict = None):
        """
        Deletes cloud entitlements.

        DELETE /entitlements/v1/cloud-entitlements
        """
        return self._c.request("DELETE", "/entitlements/v1/cloud-entitlements", params=None, json_body=body)

    def list_cloud_entitlements(self):
        """
        Lists cloud entitlements.

        GET /entitlements/v1/cloud-entitlements
        """
        return self._c.request("GET", "/entitlements/v1/cloud-entitlements", params=None, json_body=None)

    def add_cloud_entitlements(self, body: dict = None):
        """
        Adds cloud entitlements.

        POST /entitlements/v1/cloud-entitlements
        """
        return self._c.request("POST", "/entitlements/v1/cloud-entitlements", params=None, json_body=body)

    def bulk_delete_desktop_pool_entitlements(self, body: dict = None):
        """
        Delete the bulk entitlements for a set of desktop pools

        DELETE /entitlements/v1/desktop-pools
        """
        return self._c.request("DELETE", "/entitlements/v1/desktop-pools", params=None, json_body=body)

    def list_desktop_pool_entitlements(self, page: str = None, size: str = None, filter: str = None):
        """
        Lists the entitlements for Desktop Pools in the environment.

        GET /entitlements/v1/desktop-pools
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        return self._c.request("GET", "/entitlements/v1/desktop-pools", params=params, json_body=None)

    def bulk_create_desktop_pool_entitlements(self, body: dict = None):
        """
        Create the bulk entitlements for a set of desktop pools

        POST /entitlements/v1/desktop-pools
        """
        return self._c.request("POST", "/entitlements/v1/desktop-pools", params=None, json_body=body)

    def bulk_update_desktop_pool_entitlements(self, body: dict = None):
        """
        Updates the bulk entitlements for a set of desktop pools

        PUT /entitlements/v1/desktop-pools
        """
        return self._c.request("PUT", "/entitlements/v1/desktop-pools", params=None, json_body=body)

    def get_desktop_pool_entitlements(self, id):
        """
        Returns the IDs of users or groups entitled to a given desktop pool.

        GET /entitlements/v1/desktop-pools/{id}
        """
        return self._c.request("GET", f"/entitlements/v1/desktop-pools/{id}", params=None, json_body=None)

    def bulk_delete_gae_entitlements(self, body: dict = None):
        """
        Delete the bulk entitlements for a set of Global Application Entitlements

        DELETE /entitlements/v1/global-application-entitlements
        """
        return self._c.request("DELETE", "/entitlements/v1/global-application-entitlements", params=None, json_body=body)

    def list_gae_entitlements(self, page: str = None, size: str = None, filter: str = None):
        """
        Lists the user or group entitlements for Global Application Entitlements in the environment.

        GET /entitlements/v1/global-application-entitlements
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        return self._c.request("GET", "/entitlements/v1/global-application-entitlements", params=params, json_body=None)

    def bulk_create_gae_entitlements(self, body: dict = None):
        """
        Create the bulk entitlements for a set of Global Application Entitlements

        POST /entitlements/v1/global-application-entitlements
        """
        return self._c.request("POST", "/entitlements/v1/global-application-entitlements", params=None, json_body=body)

    def get_gae_entitlement(self, id):
        """
        Gets the user or group entitlements for a Global Application Entitlement.

        GET /entitlements/v1/global-application-entitlements/{id}
        """
        return self._c.request("GET", f"/entitlements/v1/global-application-entitlements/{id}", params=None, json_body=None)

    def bulk_delete_gde_entitlements(self, body: dict = None):
        """
        Delete the bulk entitlements for a set of Global Desktop Entitlements

        DELETE /entitlements/v1/global-desktop-entitlements
        """
        return self._c.request("DELETE", "/entitlements/v1/global-desktop-entitlements", params=None, json_body=body)

    def list_gde_entitlements(self, page: str = None, size: str = None, filter: str = None):
        """
        Lists the user or group entitlements for Global Desktop Entitlements in the environment.

        GET /entitlements/v1/global-desktop-entitlements
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        return self._c.request("GET", "/entitlements/v1/global-desktop-entitlements", params=params, json_body=None)

    def bulk_create_gde_entitlements(self, body: dict = None):
        """
        Create the bulk entitlements for a set of Global Desktop Entitlements

        POST /entitlements/v1/global-desktop-entitlements
        """
        return self._c.request("POST", "/entitlements/v1/global-desktop-entitlements", params=None, json_body=body)

    def get_gde_entitlement(self, id):
        """
        Gets the user or group entitlements for a Global Desktop Entitlement.

        GET /entitlements/v1/global-desktop-entitlements/{id}
        """
        return self._c.request("GET", f"/entitlements/v1/global-desktop-entitlements/{id}", params=None, json_body=None)
