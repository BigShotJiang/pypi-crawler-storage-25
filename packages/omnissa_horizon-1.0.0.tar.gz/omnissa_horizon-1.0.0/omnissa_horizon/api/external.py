# Copyright 2026 Abhilash Jha
# SPDX-License-Identifier: Apache-2.0

"""External API – auto-generated from Omnissa Horizon Server Swagger v2603."""
from typing import TYPE_CHECKING, Dict, Any, Optional, List

if TYPE_CHECKING:
    from omnissa_horizon.client import HorizonClient


class ExternalAPI:
    """APIs for External (tag: External)."""

    def __init__(self, client: "HorizonClient"):
        self._c = client

    def list_ad_computers(self, exclude_registered_machines: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists AD computer information.

        GET /external/v1/ad-computers
        """
        params = {}
        if exclude_registered_machines is not None: params['exclude_registered_machines'] = exclude_registered_machines
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/external/v1/ad-computers", params=params, json_body=None)

    def list_ad_domains(self):
        """
        Lists information related to AD Domains of the environment.

        GET /external/v1/ad-domains
        """
        return self._c.request("GET", "/external/v1/ad-domains", params=None, json_body=None)

    def bind(self, body: dict = None):
        """
        Bind untrusted domain to the connection server.

        POST /external/v1/ad-domains/action/bind
        """
        return self._c.request("POST", "/external/v1/ad-domains/action/bind", params=None, json_body=body)

    def update_auxiliary_accounts(self, body: dict = None):
        """
        Update auxiliary accounts of the untrusted domain

        POST /external/v1/ad-domains/action/update-auxiliary-accounts
        """
        return self._c.request("POST", "/external/v1/ad-domains/action/update-auxiliary-accounts", params=None, json_body=body)

    def add_auxiliary_accounts(self, id, body: dict = None):
        """
        Add auxiliary accounts to the untrusted domain

        POST /external/v1/ad-domains/{id}/action/add-auxiliary-accounts
        """
        return self._c.request("POST", f"/external/v1/ad-domains/{id}/action/add-auxiliary-accounts", params=None, json_body=body)

    def delete_auxiliary_accounts(self, id, body: dict = None):
        """
        Specification to delete auxiliary accounts from the untrusted domain

        POST /external/v1/ad-domains/{id}/action/delete-auxiliary-accounts
        """
        return self._c.request("POST", f"/external/v1/ad-domains/{id}/action/delete-auxiliary-accounts", params=None, json_body=body)

    def unbind(self, id):
        """
        Unbind untrusted domain from the connection server.

        POST /external/v1/ad-domains/{id}/action/unbind
        """
        return self._c.request("POST", f"/external/v1/ad-domains/{id}/action/unbind", params=None, json_body=None)

    def update(self, id, body: dict = None):
        """
        Updates untrusted domain.

        POST /external/v1/ad-domains/{id}/action/update
        """
        return self._c.request("POST", f"/external/v1/ad-domains/{id}/action/update", params=None, json_body=body)

    def list_ad_containers(self, id, container_name: str = None, rdn: str = None, sub_tree_search: str = None):
        """
        List active directory containers for a specific domain.

        GET /external/v1/ad-domains/{id}/ad-containers
        """
        params = {}
        if container_name is not None: params['container_name'] = container_name
        if rdn is not None: params['rdn'] = rdn
        if sub_tree_search is not None: params['sub_tree_search'] = sub_tree_search
        return self._c.request("GET", f"/external/v1/ad-domains/{id}/ad-containers", params=params, json_body=None)

    def get_default_ad_container(self, id):
        """
        Get default AD container for specified domain.

        GET /external/v1/ad-domains/{id}/ad-containers/default
        """
        return self._c.request("GET", f"/external/v1/ad-domains/{id}/ad-containers/default", params=None, json_body=None)

    def get_ad_container(self, id, rdn):
        """
        Gets the AD container for specified domain.

        GET /external/v1/ad-domains/{id}/ad-containers/{rdn}
        """
        return self._c.request("GET", f"/external/v1/ad-domains/{id}/ad-containers/{rdn}", params=None, json_body=None)

    def list_ad_user_or_group_summary(self, group_only: str = None, page: str = None, size: str = None, filter: str = None):
        """
        Lists AD users or groups information.

        GET /external/v1/ad-users-or-groups
        """
        params = {}
        if group_only is not None: params['group_only'] = group_only
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        return self._c.request("GET", "/external/v1/ad-users-or-groups", params=params, json_body=None)

    def change_user_password(self, body: dict = None):
        """
        Changes the password of AD User

        POST /external/v1/ad-users-or-groups/action/change-user-password
        """
        return self._c.request("POST", "/external/v1/ad-users-or-groups/action/change-user-password", params=None, json_body=body)

    def bulk_hold_user_or_group(self, body: dict = None):
        """
        Put users on hold.

        POST /external/v1/ad-users-or-groups/action/hold
        """
        return self._c.request("POST", "/external/v1/ad-users-or-groups/action/hold", params=None, json_body=body)

    def bulk_release_hold_user_or_group(self, body: dict = None):
        """
        Release users from hold.

        POST /external/v1/ad-users-or-groups/action/release-hold
        """
        return self._c.request("POST", "/external/v1/ad-users-or-groups/action/release-hold", params=None, json_body=body)

    def validate_ad_user_encrypted_credentials(self, body: dict = None):
        """
        Validates the encrypted credentials of AD User

        POST /external/v1/ad-users-or-groups/action/validate-user-encrypted-credentials
        """
        return self._c.request("POST", "/external/v1/ad-users-or-groups/action/validate-user-encrypted-credentials", params=None, json_body=body)

    def list_held_users_or_groups(self):
        """
        List information related to Held Users.

        GET /external/v1/ad-users-or-groups/held-users-or-groups
        """
        return self._c.request("GET", "/external/v1/ad-users-or-groups/held-users-or-groups", params=None, json_body=None)

    def get_ad_user_or_group_info(self, id):
        """
        Get information related to AD User or Group

        GET /external/v1/ad-users-or-groups/{id}
        """
        return self._c.request("GET", f"/external/v1/ad-users-or-groups/{id}", params=None, json_body=None)

    def list_audit_events(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the audit events.

        GET /external/v1/audit-events
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/external/v1/audit-events", params=params, json_body=None)

    def get_agent_upgrade_history(self, from_time: str = None, to_time: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Gets the agent upgrade history.

        GET /external/v1/audit-events/agent-upgrade-history
        """
        params = {}
        if from_time is not None: params['from_time'] = from_time
        if to_time is not None: params['to_time'] = to_time
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/external/v1/audit-events/agent-upgrade-history", params=params, json_body=None)

    def audit_events_extended_attributes(self, ids: str):
        """
        Get extended attributes of audit events

        GET /external/v1/audit-events/extended-attributes
        """
        params = {}
        if ids is not None: params['ids'] = ids
        return self._c.request("GET", "/external/v1/audit-events/extended-attributes", params=params, json_body=None)

    def list_base_snapshots(self, vcenter_id: str, base_vm_id: str):
        """
        Lists all the VM snapshots from the vCenter for a given VM.

        GET /external/v1/base-snapshots
        """
        params = {}
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        if base_vm_id is not None: params['base_vm_id'] = base_vm_id
        return self._c.request("GET", "/external/v1/base-snapshots", params=params, json_body=None)

    def list_base_v_ms(self, vcenter_id: str, datacenter_id: str = None, filter_incompatible_vms: str = None):
        """
        Lists all the VMs from a vCenter or a datacenter in that vCenter which may be suitable as snapshots for instant clone desktop pool or farm creation.

        GET /external/v1/base-vms
        """
        params = {}
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        if datacenter_id is not None: params['datacenter_id'] = datacenter_id
        if filter_incompatible_vms is not None: params['filter_incompatible_vms'] = filter_incompatible_vms
        return self._c.request("GET", "/external/v1/base-vms", params=params, json_body=None)

    def list_capacity_providers(self):
        """
        Lists capacity providers added in the environment.

        GET /external/v1/capacity-providers
        """
        return self._c.request("GET", "/external/v1/capacity-providers", params=None, json_body=None)

    def add_capacity_provider(self, body: dict = None):
        """
        Adds a capacity provider

        POST /external/v1/capacity-providers
        """
        return self._c.request("POST", "/external/v1/capacity-providers", params=None, json_body=body)

    def list_regions(self):
        """
        Lists all the regions from AWS core

        GET /external/v1/capacity-providers/aws-core/regions
        """
        return self._c.request("GET", "/external/v1/capacity-providers/aws-core/regions", params=None, json_body=None)

    def remove_capacity_provider(self, id):
        """
        Removes a capacity provider

        DELETE /external/v1/capacity-providers/{id}
        """
        return self._c.request("DELETE", f"/external/v1/capacity-providers/{id}", params=None, json_body=None)

    def get_capacity_provider(self, id):
        """
        Gets capacity provider Information.

        GET /external/v1/capacity-providers/{id}
        """
        return self._c.request("GET", f"/external/v1/capacity-providers/{id}", params=None, json_body=None)

    def list_images(self, id):
        """
        Lists all the images from AWS core for the specific capacity provider id

        GET /external/v1/capacity-providers/{id}/aws-images
        """
        return self._c.request("GET", f"/external/v1/capacity-providers/{id}/aws-images", params=None, json_body=None)

    def list_bundles(self, id):
        """
        Lists all the bundles from AWS core for the specific capacity provider id

        GET /external/v1/capacity-providers/{id}/bundles
        """
        return self._c.request("GET", f"/external/v1/capacity-providers/{id}/bundles", params=None, json_body=None)

    def list_directories(self, id):
        """
        Lists all the directories from AWS core for the specific capacity provider id

        GET /external/v1/capacity-providers/{id}/directories
        """
        return self._c.request("GET", f"/external/v1/capacity-providers/{id}/directories", params=None, json_body=None)

    def list_capacity_provider_images(self, id):
        """
        Retrieves images available with the capacity provider.

        GET /external/v1/capacity-providers/{id}/images
        """
        return self._c.request("GET", f"/external/v1/capacity-providers/{id}/images", params=None, json_body=None)

    def list_networks(self, id):
        """
        Lists all the networks of the specific capacity provider id.

        GET /external/v1/capacity-providers/{id}/networks
        """
        return self._c.request("GET", f"/external/v1/capacity-providers/{id}/networks", params=None, json_body=None)

    def list_resource_containers(self, id):
        """
        Lists all the Resource Containers of the specific capacity provider id.

        GET /external/v1/capacity-providers/{id}/resource-containers
        """
        return self._c.request("GET", f"/external/v1/capacity-providers/{id}/resource-containers", params=None, json_body=None)

    def list_customization_specs(self, vcenter_id: str):
        """
        Lists all the customization specifications from the vCenter.

        GET /external/v1/customization-specifications
        """
        params = {}
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        return self._c.request("GET", "/external/v1/customization-specifications", params=params, json_body=None)

    def list_datacenters(self, vcenter_id: str, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists all the datacenters of a vCenter.

        GET /external/v1/datacenters
        """
        params = {}
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/external/v1/datacenters", params=params, json_body=None)

    def list_datastore_clusters(self, vcenter_id: str, host_or_cluster_id: str, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists all the datastore clusters from the vCenter for the given host or cluster.

        GET /external/v1/datastore-clusters
        """
        params = {}
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        if host_or_cluster_id is not None: params['host_or_cluster_id'] = host_or_cluster_id
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/external/v1/datastore-clusters", params=params, json_body=None)

    def list_datastore_paths(self, vcenter_id: str, datastore_id: str):
        """
        Lists all the folder paths within a Datastore from vCenter.

        GET /external/v1/datastore-paths
        """
        params = {}
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        if datastore_id is not None: params['datastore_id'] = datastore_id
        return self._c.request("GET", "/external/v1/datastore-paths", params=params, json_body=None)

    def listdatastores(self, vcenter_id: str, host_or_cluster_id: str, resource_type: str = None, resource_id: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists all the datastores from the vCenter for the given host or cluster.

        GET /external/v1/datastores
        """
        params = {}
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        if host_or_cluster_id is not None: params['host_or_cluster_id'] = host_or_cluster_id
        if resource_type is not None: params['resource_type'] = resource_type
        if resource_id is not None: params['resource_id'] = resource_id
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/external/v1/datastores", params=params, json_body=None)

    def compute_space_requirements(self, body: dict = None):
        """
        Computes the datastore space requirements for inventory resources.

        POST /external/v1/datastores/action/compute-requirements
        """
        return self._c.request("POST", "/external/v1/datastores/action/compute-requirements", params=None, json_body=body)

    def compute_vsan_cost(self, vcenter_id: str, pool_type: str, is_dedicated: str):
        """
        Computes the vsan cost for given pool type.

        POST /external/v1/datastores/action/compute-vsan-cost
        """
        params = {}
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        if pool_type is not None: params['pool_type'] = pool_type
        if is_dedicated is not None: params['is_dedicated'] = is_dedicated
        return self._c.request("POST", "/external/v1/datastores/action/compute-vsan-cost", params=params, json_body=None)

    def list_domains(self):
        """
        Returns a map of domain NETBIOS name and dns name for domains which are configured on connection server.

        GET /external/v1/domains
        """
        return self._c.request("GET", "/external/v1/domains", params=None, json_body=None)

    def list_hosts_or_clusters(self, vcenter_id: str, datacenter_id: str):
        """
        Lists all the hosts or clusters of the datacenter.

        GET /external/v1/hosts-or-clusters
        """
        params = {}
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        if datacenter_id is not None: params['datacenter_id'] = datacenter_id
        return self._c.request("GET", "/external/v1/hosts-or-clusters", params=params, json_body=None)

    def list_network_interface_cards(self, vcenter_id: str, base_vm_id: str = None, base_snapshot_id: str = None, vm_template_id: str = None):
        """
        Returns a list of network interface cards (NICs) suitable for configuration on a desktop pool/farm.

        GET /external/v1/network-interface-cards
        """
        params = {}
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        if base_vm_id is not None: params['base_vm_id'] = base_vm_id
        if base_snapshot_id is not None: params['base_snapshot_id'] = base_snapshot_id
        if vm_template_id is not None: params['vm_template_id'] = vm_template_id
        return self._c.request("GET", "/external/v1/network-interface-cards", params=params, json_body=None)

    def list_network_labels(self, vcenter_id: str, host_or_cluster_id: str, network_type: str = None):
        """
        Retrieves all network labels on the given host or cluster

        GET /external/v1/network-labels
        """
        params = {}
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        if host_or_cluster_id is not None: params['host_or_cluster_id'] = host_or_cluster_id
        if network_type is not None: params['network_type'] = network_type
        return self._c.request("GET", "/external/v1/network-labels", params=params, json_body=None)

    def list_resource_pools(self, vcenter_id: str, host_or_cluster_id: str):
        """
        Lists all the resource pools from the vCenter for the given host or cluster.

        GET /external/v1/resource-pools
        """
        params = {}
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        if host_or_cluster_id is not None: params['host_or_cluster_id'] = host_or_cluster_id
        return self._c.request("GET", "/external/v1/resource-pools", params=params, json_body=None)

    def list_virtual_disks(self, vcenter_id: str, datastore_id: str = None, populate_all_disks: str = None):
        """
        Lists Virtual disks from vCenter for a given datastore. If datastore_id is not specified, it lists the Virtual Disks for all datastores. If populate_all_disks is set to true, all virtual disks will be populated.

        GET /external/v1/virtual-disks
        """
        params = {}
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        if datastore_id is not None: params['datastore_id'] = datastore_id
        if populate_all_disks is not None: params['populate_all_disks'] = populate_all_disks
        return self._c.request("GET", "/external/v1/virtual-disks", params=params, json_body=None)

    def list_virtual_machines(self, vcenter_id: str, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists all the VMs from a vCenter.

        GET /external/v1/virtual-machines
        """
        params = {}
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/external/v1/virtual-machines", params=params, json_body=None)

    def list_vm_folders(self, vcenter_id: str, datacenter_id: str):
        """
        Lists all the VM folders from the vCenter for the given datacenter.

        GET /external/v1/vm-folders
        """
        params = {}
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        if datacenter_id is not None: params['datacenter_id'] = datacenter_id
        return self._c.request("GET", "/external/v1/vm-folders", params=params, json_body=None)

    def list_vm_templates(self, vcenter_id: str, datacenter_id: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists all the VM templates from a vCenter or a datacenter for the given vCenter which may be suitable for full clone desktop pool creation.

        GET /external/v1/vm-templates
        """
        params = {}
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        if datacenter_id is not None: params['datacenter_id'] = datacenter_id
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/external/v1/vm-templates", params=params, json_body=None)

    def list_ad_domains_v2(self):
        """
        Lists information related to AD Domains of the environment.

        GET /external/v2/ad-domains
        """
        return self._c.request("GET", "/external/v2/ad-domains", params=None, json_body=None)

    def bulk_hold_user_or_group_v2(self, body: dict = None):
        """
        Put users on hold.

        POST /external/v2/ad-users-or-groups/action/hold
        """
        return self._c.request("POST", "/external/v2/ad-users-or-groups/action/hold", params=None, json_body=body)

    def bulk_release_hold_user_or_group_v2(self, body: dict = None):
        """
        Release users from hold.

        POST /external/v2/ad-users-or-groups/action/release-hold
        """
        return self._c.request("POST", "/external/v2/ad-users-or-groups/action/release-hold", params=None, json_body=body)

    def get_ad_user_or_group_info_v2(self, id):
        """
        Get information related to AD User or Group

        GET /external/v2/ad-users-or-groups/{id}
        """
        return self._c.request("GET", f"/external/v2/ad-users-or-groups/{id}", params=None, json_body=None)

    def list_audit_events_v2(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the audit events.

        GET /external/v2/audit-events
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/external/v2/audit-events", params=params, json_body=None)

    def get_agent_upgrade_history_v2(self, from_time: str = None, to_time: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Gets the agent upgrade history.

        GET /external/v2/audit-events/agent-upgrade-history
        """
        params = {}
        if from_time is not None: params['from_time'] = from_time
        if to_time is not None: params['to_time'] = to_time
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/external/v2/audit-events/agent-upgrade-history", params=params, json_body=None)

    def list_base_snapshots_v2(self, vcenter_id: str, base_vm_id: str, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists all the VM snapshots from the vCenter for a given VM.

        GET /external/v2/base-snapshots
        """
        params = {}
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        if base_vm_id is not None: params['base_vm_id'] = base_vm_id
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/external/v2/base-snapshots", params=params, json_body=None)

    def list_base_v_ms_v2(self, vcenter_id: str, datacenter_id: str = None, filter_incompatible_vms: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists all the VMs from a vCenter or a datacenter in that vCenter which may be suitable as snapshots for instant clone desktop pool or farm creation.

        GET /external/v2/base-vms
        """
        params = {}
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        if datacenter_id is not None: params['datacenter_id'] = datacenter_id
        if filter_incompatible_vms is not None: params['filter_incompatible_vms'] = filter_incompatible_vms
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/external/v2/base-vms", params=params, json_body=None)

    def get_base_v_ms_v2(self, id, vcenter_id: str, datacenter_id: str = None):
        """
        Gets the specified VM information

        GET /external/v2/base-vms/{id}
        """
        params = {}
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        if datacenter_id is not None: params['datacenter_id'] = datacenter_id
        return self._c.request("GET", f"/external/v2/base-vms/{id}", params=params, json_body=None)

    def list_capacity_providers_v2(self):
        """
        Lists capacity providers added in the environment.

        GET /external/v2/capacity-providers
        """
        return self._c.request("GET", "/external/v2/capacity-providers", params=None, json_body=None)

    def add_capacity_provider_v2(self, body: dict = None):
        """
        Adds a capacity provider

        POST /external/v2/capacity-providers
        """
        return self._c.request("POST", "/external/v2/capacity-providers", params=None, json_body=body)

    def get_capacity_provider_v2(self, id):
        """
        Gets capacity provider Information.

        GET /external/v2/capacity-providers/{id}
        """
        return self._c.request("GET", f"/external/v2/capacity-providers/{id}", params=None, json_body=None)

    def update_capacity_provider_v2(self, id, body: dict = None):
        """
        Updates a capacity provider

        PUT /external/v2/capacity-providers/{id}
        """
        return self._c.request("PUT", f"/external/v2/capacity-providers/{id}", params=None, json_body=body)

    def compute_space_requirements_v2(self, body: dict = None):
        """
        Computes the datastore space requirements for inventory resources.

        POST /external/v2/datastores/action/compute-requirements
        """
        return self._c.request("POST", "/external/v2/datastores/action/compute-requirements", params=None, json_body=body)

    def list_network_interface_cards_v2(self, vcenter_id: str, base_vm_id: str = None, base_snapshot_id: str = None, vm_template_id: str = None):
        """
        Returns a list of network interface cards (NICs) suitable for configuration on a desktop pool/farm.

        GET /external/v2/network-interface-cards
        """
        params = {}
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        if base_vm_id is not None: params['base_vm_id'] = base_vm_id
        if base_snapshot_id is not None: params['base_snapshot_id'] = base_snapshot_id
        if vm_template_id is not None: params['vm_template_id'] = vm_template_id
        return self._c.request("GET", "/external/v2/network-interface-cards", params=params, json_body=None)

    def list_vm_templates_v2(self, vcenter_id: str, datacenter_id: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists all the VM templates from a vCenter or a datacenter for the given vCenter which may be suitable for full clone desktop pool creation.

        GET /external/v2/vm-templates
        """
        params = {}
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        if datacenter_id is not None: params['datacenter_id'] = datacenter_id
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/external/v2/vm-templates", params=params, json_body=None)

    def list_ad_domains_v3(self):
        """
        Lists information related to AD Domains of the environment.

        GET /external/v3/ad-domains
        """
        return self._c.request("GET", "/external/v3/ad-domains", params=None, json_body=None)

    def get_agent_upgrade_history_v3(self, from_time: str = None, to_time: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Gets the agent upgrade history.

        GET /external/v3/audit-events/agent-upgrade-history
        """
        params = {}
        if from_time is not None: params['from_time'] = from_time
        if to_time is not None: params['to_time'] = to_time
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/external/v3/audit-events/agent-upgrade-history", params=params, json_body=None)

    def list_base_snapshots_v3(self, vcenter_id: str, base_vm_id: str, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists all the VM snapshots from the vCenter for a given VM.

        GET /external/v3/base-snapshots
        """
        params = {}
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        if base_vm_id is not None: params['base_vm_id'] = base_vm_id
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/external/v3/base-snapshots", params=params, json_body=None)

    def list_base_v_ms_v3(self, vcenter_id: str, datacenter_id: str = None, filter_incompatible_vms: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists all the VMs from a vCenter or a datacenter in that vCenter which may be suitable as snapshots for instant clone desktop pool or farm creation.

        GET /external/v3/base-vms
        """
        params = {}
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        if datacenter_id is not None: params['datacenter_id'] = datacenter_id
        if filter_incompatible_vms is not None: params['filter_incompatible_vms'] = filter_incompatible_vms
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/external/v3/base-vms", params=params, json_body=None)

    def list_generic_capacity_providers(self):
        """
        Lists capacity providers.

        GET /external/v3/capacity-providers
        """
        return self._c.request("GET", "/external/v3/capacity-providers", params=None, json_body=None)

    def add_generic_capacity_provider(self, body: dict = None):
        """
        Adds a capacity provider.

        POST /external/v3/capacity-providers
        """
        return self._c.request("POST", "/external/v3/capacity-providers", params=None, json_body=body)

    def validate_generic_capacity_provider_certificate(self, server_name: str, deployment_type: str, port: str = None):
        """
        Validates the certificate for the capacity provider.

        POST /external/v3/capacity-providers/action/validate-certificate
        """
        params = {}
        if server_name is not None: params['server_name'] = server_name
        if port is not None: params['port'] = port
        if deployment_type is not None: params['deployment_type'] = deployment_type
        return self._c.request("POST", "/external/v3/capacity-providers/action/validate-certificate", params=params, json_body=None)

    def delete_generic_capacity_provider(self, id):
        """
        Deletes a capacity provider.

        DELETE /external/v3/capacity-providers/{id}
        """
        return self._c.request("DELETE", f"/external/v3/capacity-providers/{id}", params=None, json_body=None)

    def get_generic_capacity_provider(self, id):
        """
        Retrieves a capacity provider.

        GET /external/v3/capacity-providers/{id}
        """
        return self._c.request("GET", f"/external/v3/capacity-providers/{id}", params=None, json_body=None)

    def update_generic_capacity_provider(self, id, body: dict = None):
        """
        Updates a capacity provider.

        PUT /external/v3/capacity-providers/{id}
        """
        return self._c.request("PUT", f"/external/v3/capacity-providers/{id}", params=None, json_body=body)

    def list_ad_user_or_group_info_v4(self, group_only: str = None, detailed_info: str = None):
        """
        Lists AD users or groups information.

        GET /external/v4/ad-users-or-groups
        """
        params = {}
        if group_only is not None: params['group_only'] = group_only
        if detailed_info is not None: params['detailed_info'] = detailed_info
        return self._c.request("GET", "/external/v4/ad-users-or-groups", params=params, json_body=None)

    def get_ad_user_or_group_info_v4(self, id):
        """
        Get information related to AD User or Group

        GET /external/v4/ad-users-or-groups/{id}
        """
        return self._c.request("GET", f"/external/v4/ad-users-or-groups/{id}", params=None, json_body=None)

    def list_generic_capacity_providers_v2(self):
        """
        Lists capacity providers.

        GET /external/v4/capacity-providers
        """
        return self._c.request("GET", "/external/v4/capacity-providers", params=None, json_body=None)

    def add_generic_capacity_provider_v2(self, body: dict = None):
        """
        Adds a capacity provider.

        POST /external/v4/capacity-providers
        """
        return self._c.request("POST", "/external/v4/capacity-providers", params=None, json_body=body)

    def get_generic_capacity_provider_v2(self, id):
        """
        Retrieves a capacity provider.

        GET /external/v4/capacity-providers/{id}
        """
        return self._c.request("GET", f"/external/v4/capacity-providers/{id}", params=None, json_body=None)

    def update_generic_capacity_provider_v2(self, id, body: dict = None):
        """
        Updates a capacity provider.

        PUT /external/v4/capacity-providers/{id}
        """
        return self._c.request("PUT", f"/external/v4/capacity-providers/{id}", params=None, json_body=body)
