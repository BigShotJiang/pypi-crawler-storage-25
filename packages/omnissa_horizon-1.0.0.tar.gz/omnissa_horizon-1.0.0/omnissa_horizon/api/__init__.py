# Copyright 2026 Abhilash Jha
# SPDX-License-Identifier: Apache-2.0

"""Sub-API modules for omnissa-horizon SDK."""
from omnissa_horizon.api.auth import AuthAPI
from omnissa_horizon.api.config import ConfigAPI
from omnissa_horizon.api.inventory import InventoryAPI
from omnissa_horizon.api.monitor import MonitorAPI
from omnissa_horizon.api.entitlements import EntitlementsAPI
from omnissa_horizon.api.external import ExternalAPI
from omnissa_horizon.api.federation import FederationAPI
from omnissa_horizon.api.help_desk import HelpDeskAPI

__all__ = [
    "AuthAPI", "ConfigAPI", "InventoryAPI", "MonitorAPI",
    "EntitlementsAPI", "ExternalAPI", "FederationAPI", "HelpDeskAPI",
]
