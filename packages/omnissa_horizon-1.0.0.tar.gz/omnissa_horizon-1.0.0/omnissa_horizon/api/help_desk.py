# Copyright 2026 Abhilash Jha
# SPDX-License-Identifier: Apache-2.0

"""Help Desk API – auto-generated from Omnissa Horizon Server Swagger v2603."""
from typing import TYPE_CHECKING, Dict, Any, Optional, List

if TYPE_CHECKING:
    from omnissa_horizon.client import HorizonClient


class HelpDeskAPI:
    """APIs for Help Desk (tag: Help Desk)."""

    def __init__(self, client: "HorizonClient"):
        self._c = client

    def get_client_information(self, internal_session_id: str, pod_id: str = None):
        """
        Retrieves Client Display Topology Information.

        GET /helpdesk/v1/client
        """
        params = {}
        if internal_session_id is not None: params['internal_session_id'] = internal_session_id
        if pod_id is not None: params['pod_id'] = pod_id
        return self._c.request("GET", "/helpdesk/v1/client", params=params, json_body=None)

    def get_logon_segment_info(self, session_id: str, pod_id: str = None):
        """
        Retrieves the session timing data.

        GET /helpdesk/v1/logon-timing/logon-segment
        """
        params = {}
        if session_id is not None: params['session_id'] = session_id
        if pod_id is not None: params['pod_id'] = pod_id
        return self._c.request("GET", "/helpdesk/v1/logon-timing/logon-segment", params=params, json_body=None)

    def get_display_protocol_performance_info(self, session_id: str, pod_id: str = None):
        """
        Retrieves performance data of the current session display protocol (PCoIP or BLAST).

        GET /helpdesk/v1/performance/display-protocol
        """
        params = {}
        if session_id is not None: params['session_id'] = session_id
        if pod_id is not None: params['pod_id'] = pod_id
        return self._c.request("GET", "/helpdesk/v1/performance/display-protocol", params=params, json_body=None)

    def list_historical_performance_info(self, session_id: str, pod_id: str = None):
        """
        Retrieves historical performance data for the specific session in latest 15 minutes.

        GET /helpdesk/v1/performance/historical-data
        """
        params = {}
        if session_id is not None: params['session_id'] = session_id
        if pod_id is not None: params['pod_id'] = pod_id
        return self._c.request("GET", "/helpdesk/v1/performance/historical-data", params=params, json_body=None)

    def list_process_performance_info(self, session_id: str, pod_id: str = None, process_filter: str = None):
        """
        Retrieves the process information.

        GET /helpdesk/v1/performance/process
        """
        params = {}
        if session_id is not None: params['session_id'] = session_id
        if pod_id is not None: params['pod_id'] = pod_id
        if process_filter is not None: params['process_filter'] = process_filter
        return self._c.request("GET", "/helpdesk/v1/performance/process", params=params, json_body=None)

    def list_remote_application_performance_info(self, session_id: str, pod_id: str = None):
        """
        Retrieves the remote applications information.

        GET /helpdesk/v1/performance/remote-application
        """
        params = {}
        if session_id is not None: params['session_id'] = session_id
        if pod_id is not None: params['pod_id'] = pod_id
        return self._c.request("GET", "/helpdesk/v1/performance/remote-application", params=params, json_body=None)

    def end_remote_application(self, session_id: str, remote_application_id: str, pod_id: str = None):
        """
        Terminate an application running on virtual machine by session Id and the application Id.

        POST /helpdesk/v1/performance/remote-application/action/end-remote-application
        """
        params = {}
        if session_id is not None: params['session_id'] = session_id
        if remote_application_id is not None: params['remote_application_id'] = remote_application_id
        if pod_id is not None: params['pod_id'] = pod_id
        return self._c.request("POST", "/helpdesk/v1/performance/remote-application/action/end-remote-application", params=params, json_body=None)

    def get_remote_application_s4_b_pairing_mode(self, session_id: str, pod_id: str = None):
        """
        Retrieves the remote applications s4b pairing mode information.

        GET /helpdesk/v1/performance/remote-application/s4b-pairing-mode
        """
        params = {}
        if session_id is not None: params['session_id'] = session_id
        if pod_id is not None: params['pod_id'] = pod_id
        return self._c.request("GET", "/helpdesk/v1/performance/remote-application/s4b-pairing-mode", params=params, json_body=None)

    def end_remote_process(self, session_id: str, body: dict = None, pod_id: str = None):
        """
        Terminate a process running on virtual machine by session Id and the basic process information.

        POST /helpdesk/v1/performance/remote-process/action/end-remote-process
        """
        params = {}
        if session_id is not None: params['session_id'] = session_id
        if pod_id is not None: params['pod_id'] = pod_id
        return self._c.request("POST", "/helpdesk/v1/performance/remote-process/action/end-remote-process", params=params, json_body=body)

    def get_remote_assistant_ticket_info(self, session_id: str, pod_id: str = None):
        """
        Get a Microsoft Remote Assistance ticket by session Id.

        GET /helpdesk/v1/remote-assistant-ticket
        """
        params = {}
        if session_id is not None: params['session_id'] = session_id
        if pod_id is not None: params['pod_id'] = pod_id
        return self._c.request("GET", "/helpdesk/v1/remote-assistant-ticket", params=params, json_body=None)

    def get_agent_status(self, session_id: str, pod_id: str = None):
        """
        Retrieves ws1 assist agent status code.

        GET /helpdesk/v1/ws1-assist
        """
        params = {}
        if session_id is not None: params['session_id'] = session_id
        if pod_id is not None: params['pod_id'] = pod_id
        return self._c.request("GET", "/helpdesk/v1/ws1-assist", params=params, json_body=None)

    def initiate_ws1_assist(self, body: dict = None):
        """
        Initiates ws1 assist operation.

        POST /helpdesk/v1/ws1-assist
        """
        return self._c.request("POST", "/helpdesk/v1/ws1-assist", params=None, json_body=body)

    def get_logon_segment_info_v2(self, internal_session_id: str, pod_id: str = None):
        """
        Retrieves the session timing data.

        GET /helpdesk/v2/logon-timing/logon-segment
        """
        params = {}
        if internal_session_id is not None: params['internal_session_id'] = internal_session_id
        if pod_id is not None: params['pod_id'] = pod_id
        return self._c.request("GET", "/helpdesk/v2/logon-timing/logon-segment", params=params, json_body=None)

    def get_display_protocol_performance_info_v2(self, internal_session_id: str, pod_id: str = None):
        """
        Retrieves performance data of the current session display protocol (PCoIP or BLAST).

        GET /helpdesk/v2/performance/display-protocol
        """
        params = {}
        if internal_session_id is not None: params['internal_session_id'] = internal_session_id
        if pod_id is not None: params['pod_id'] = pod_id
        return self._c.request("GET", "/helpdesk/v2/performance/display-protocol", params=params, json_body=None)

    def list_historical_performance_info_v2(self, internal_session_id: str, pod_id: str = None):
        """
        Retrieves historical performance data for the specific session in latest 15 minutes.

        GET /helpdesk/v2/performance/historical-data
        """
        params = {}
        if internal_session_id is not None: params['internal_session_id'] = internal_session_id
        if pod_id is not None: params['pod_id'] = pod_id
        return self._c.request("GET", "/helpdesk/v2/performance/historical-data", params=params, json_body=None)

    def list_process_performance_info_v2(self, internal_session_id: str, pod_id: str = None, process_filter: str = None):
        """
        Retrieves the process information.

        GET /helpdesk/v2/performance/process
        """
        params = {}
        if internal_session_id is not None: params['internal_session_id'] = internal_session_id
        if pod_id is not None: params['pod_id'] = pod_id
        if process_filter is not None: params['process_filter'] = process_filter
        return self._c.request("GET", "/helpdesk/v2/performance/process", params=params, json_body=None)

    def list_remote_application_performance_info_v2(self, internal_session_id: str, pod_id: str = None):
        """
        Retrieves the remote applications information.

        GET /helpdesk/v2/performance/remote-application
        """
        params = {}
        if internal_session_id is not None: params['internal_session_id'] = internal_session_id
        if pod_id is not None: params['pod_id'] = pod_id
        return self._c.request("GET", "/helpdesk/v2/performance/remote-application", params=params, json_body=None)

    def get_remote_assistant_ticket_info_v2(self, internal_session_id: str, pod_id: str = None):
        """
        Get a Microsoft Remote Assistance ticket by session Id.

        GET /helpdesk/v2/remote-assistant-ticket
        """
        params = {}
        if internal_session_id is not None: params['internal_session_id'] = internal_session_id
        if pod_id is not None: params['pod_id'] = pod_id
        return self._c.request("GET", "/helpdesk/v2/remote-assistant-ticket", params=params, json_body=None)

    def get_logon_segment_info_v3(self, internal_session_id: str, pod_id: str = None):
        """
        Retrieves the session timing data.

        GET /helpdesk/v3/logon-timing/logon-segment
        """
        params = {}
        if internal_session_id is not None: params['internal_session_id'] = internal_session_id
        if pod_id is not None: params['pod_id'] = pod_id
        return self._c.request("GET", "/helpdesk/v3/logon-timing/logon-segment", params=params, json_body=None)

    def get_display_protocol_performance_info_v3(self, internal_session_id: str, pod_id: str = None):
        """
        Retrieves performance data of the current session display protocol (PCoIP or BLAST).

        GET /helpdesk/v3/performance/display-protocol
        """
        params = {}
        if internal_session_id is not None: params['internal_session_id'] = internal_session_id
        if pod_id is not None: params['pod_id'] = pod_id
        return self._c.request("GET", "/helpdesk/v3/performance/display-protocol", params=params, json_body=None)
