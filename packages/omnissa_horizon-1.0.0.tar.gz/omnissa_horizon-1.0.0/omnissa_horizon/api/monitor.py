# Copyright 2026 Abhilash Jha
# SPDX-License-Identifier: Apache-2.0

"""Monitor API – auto-generated from Omnissa Horizon Server Swagger v2603."""
from typing import TYPE_CHECKING, Dict, Any, Optional, List

if TYPE_CHECKING:
    from omnissa_horizon.client import HorizonClient


class MonitorAPI:
    """APIs for Monitor (tag: Monitor)."""

    def __init__(self, client: "HorizonClient"):
        self._c = client

    def list_ad_domain_monitors(self):
        """
        Lists monitoring information related to AD Domains of the environment.

        GET /monitor/ad-domains
        """
        return self._c.request("GET", "/monitor/ad-domains", params=None, json_body=None)

    def list_app_volumes_manager_monitor_info_v1(self):
        """
        Lists monitoring information related to App volumes managers registered in the environment.

        GET /monitor/app-volumes-managers
        """
        return self._c.request("GET", "/monitor/app-volumes-managers", params=None, json_body=None)

    def get_app_volumes_manager_monitor_info(self, id):
        """
        Retrieves information about an app volumes manager.

        GET /monitor/app-volumes-managers/{id}
        """
        return self._c.request("GET", f"/monitor/app-volumes-managers/{id}", params=None, json_body=None)

    def list_connection_server_monitors(self):
        """
        Lists monitoring information related to Connection Servers of the environment.

        GET /monitor/connection-servers
        """
        return self._c.request("GET", "/monitor/connection-servers", params=None, json_body=None)

    def list_desktop_monitors(self):
        """
        Lists monitoring information related to desktop pools in the environment.

        GET /monitor/desktops
        """
        return self._c.request("GET", "/monitor/desktops", params=None, json_body=None)

    def get_event_database_monitor(self):
        """
        Returns monitoring information related to Event database of the environment.

        GET /monitor/event-database
        """
        return self._c.request("GET", "/monitor/event-database", params=None, json_body=None)

    def list_farm_monitors(self):
        """
        Lists monitoring information related to Farms of the environment.

        GET /monitor/farms
        """
        return self._c.request("GET", "/monitor/farms", params=None, json_body=None)

    def list_gateway_monitor_info_v1(self):
        """
        Lists monitoring information related to Gateways registered in the environment.

        GET /monitor/gateways
        """
        return self._c.request("GET", "/monitor/gateways", params=None, json_body=None)

    def list_rds_server_monitors(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists monitoring information related to RDS Servers of the environment.

        GET /monitor/rds-servers
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/monitor/rds-servers", params=params, json_body=None)

    def list_saml_authenticator_monitors_v1(self):
        """
        Lists monitoring information related to SAML Authenticators of the environment.

        GET /monitor/saml-authenticators
        """
        return self._c.request("GET", "/monitor/saml-authenticators", params=None, json_body=None)

    def list_connection_server_schema_master_monitors(self):
        """
        Lists monitoring information related to current schema master of the environment.

        GET /monitor/v1/connection-servers/schema-master
        """
        return self._c.request("GET", "/monitor/v1/connection-servers/schema-master", params=None, json_body=None)

    def get_connection_server_monitor_info_v2(self, id):
        """
        Gets monitoring information related to Connection Server.

        GET /monitor/v1/connection-servers/{id}
        """
        return self._c.request("GET", f"/monitor/v1/connection-servers/{id}", params=None, json_body=None)

    def list_desktop_pool_or_farm_datastore_usage_info(self, vcenter_id: str, datastore_id: str, host_or_cluster_id: str):
        """
        Lists the Desktop pool or Farm and its usage details for a given datastore.

        GET /monitor/v1/datastores/usage-metrics
        """
        params = {}
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        if datastore_id is not None: params['datastore_id'] = datastore_id
        if host_or_cluster_id is not None: params['host_or_cluster_id'] = host_or_cluster_id
        return self._c.request("GET", "/monitor/v1/datastores/usage-metrics", params=params, json_body=None)

    def list_desktop_pool_metrics(self, ids: str):
        """
        Lists metrics of desktop pools (except RDS desktop pools).

        GET /monitor/v1/desktop-pools/metrics
        """
        params = {}
        if ids is not None: params['ids'] = ids
        return self._c.request("GET", "/monitor/v1/desktop-pools/metrics", params=params, json_body=None)

    def get_desktop_monitor_info(self, id):
        """
        Retrieves information related to a desktop pool.

        GET /monitor/v1/desktops/{id}
        """
        return self._c.request("GET", f"/monitor/v1/desktops/{id}", params=None, json_body=None)

    def get_farm_monitor_info(self, id):
        """
        Gets monitoring information related to farm.

        GET /monitor/v1/farms/{id}
        """
        return self._c.request("GET", f"/monitor/v1/farms/{id}", params=None, json_body=None)

    def get_gateway_monitor_info(self, id):
        """
        Gets monitoring information related to a Gateway.

        GET /monitor/v1/gateways/{id}
        """
        return self._c.request("GET", f"/monitor/v1/gateways/{id}", params=None, json_body=None)

    def list_global_desktop_entitlements_metrics(self, ids: str):
        """
        Lists metrics of global desktop entitlements.

        GET /monitor/v1/global-desktop-entitlements/metrics
        """
        params = {}
        if ids is not None: params['ids'] = ids
        return self._c.request("GET", "/monitor/v1/global-desktop-entitlements/metrics", params=params, json_body=None)

    def list_health_metrics_info(self):
        """
        Lists the health metrics related information for all the components.

        GET /monitor/v1/health-metrics
        """
        return self._c.request("GET", "/monitor/v1/health-metrics", params=None, json_body=None)

    def get_license_usage_metrics(self):
        """
        Get metrics of current and highest historical usage numbers of the product license.

        GET /monitor/v1/licenses/usage-metrics
        """
        return self._c.request("GET", "/monitor/v1/licenses/usage-metrics", params=None, json_body=None)

    def get_machine_state_count_metrics(self):
        """
        Gets the state count metrics of the machines.

        GET /monitor/v1/machines/count-metrics
        """
        return self._c.request("GET", "/monitor/v1/machines/count-metrics", params=None, json_body=None)

    def list_message_clients_monitors(self):
        """
        Lists monitoring information related to registered message clients in the environment.

        GET /monitor/v1/message-clients
        """
        return self._c.request("GET", "/monitor/v1/message-clients", params=None, json_body=None)

    def get_message_client_monitor(self, id):
        """
        Gets monitoring information related to registered message client.

        GET /monitor/v1/message-clients/{id}
        """
        return self._c.request("GET", f"/monitor/v1/message-clients/{id}", params=None, json_body=None)

    def list_pod_monitor_infos_v1(self):
        """
        Lists monitoring information related to the remote pods.

        GET /monitor/v1/pods
        """
        return self._c.request("GET", "/monitor/v1/pods", params=None, json_body=None)

    def get_pod_session_metrics_info(self):
        """
        Get the global session counts related to all Pods in the Pod Federation.

        GET /monitor/v1/pods/global-session-metrics
        """
        return self._c.request("GET", "/monitor/v1/pods/global-session-metrics", params=None, json_body=None)

    def get_pod_monitor_info_v2(self, id):
        """
        Gets monitoring information related to the remote pod.

        GET /monitor/v1/pods/{id}
        """
        return self._c.request("GET", f"/monitor/v1/pods/{id}", params=None, json_body=None)

    def get_rds_server_state_count_metrics(self):
        """
        Gets State Counts related to RDS Server.

        GET /monitor/v1/rds-servers/count-metrics
        """
        return self._c.request("GET", "/monitor/v1/rds-servers/count-metrics", params=None, json_body=None)

    def get_rds_server_monitors(self, id):
        """
        Gets monitoring information related to RDS Server.

        GET /monitor/v1/rds-servers/{id}
        """
        return self._c.request("GET", f"/monitor/v1/rds-servers/{id}", params=None, json_body=None)

    def get_saml_authenticator_monitor_info(self, id):
        """
        Gets Monitoring Information related to a SAML Authenticator

        GET /monitor/v1/saml-authenticators/{id}
        """
        return self._c.request("GET", f"/monitor/v1/saml-authenticators/{id}", params=None, json_body=None)

    def get_session_metrics(self):
        """
        Gets summary of local session metrics.

        GET /monitor/v1/sessions/metrics
        """
        return self._c.request("GET", "/monitor/v1/sessions/metrics", params=None, json_body=None)

    def get_system_metrics_info(self):
        """
        Gets the system metrics of all the components.

        GET /monitor/v1/system-metrics
        """
        return self._c.request("GET", "/monitor/v1/system-metrics", params=None, json_body=None)

    def list_true_sso_monitor_infos(self):
        """
        Lists monitoring information related to True SSO connectors.

        GET /monitor/v1/true-sso
        """
        return self._c.request("GET", "/monitor/v1/true-sso", params=None, json_body=None)

    def get_true_sso_monitor_info(self, id):
        """
        Gets monitoring information related to a True SSO connector.

        GET /monitor/v1/true-sso/{id}
        """
        return self._c.request("GET", f"/monitor/v1/true-sso/{id}", params=None, json_body=None)

    def get_view_composer_by_vc_id(self, vcId):
        """
        View Composer is no longer supported from Horizon version 2012 onwards.

        GET /monitor/v1/view-composers/{vcId}
        """
        return self._c.request("GET", f"/monitor/v1/view-composers/{vcId}", params=None, json_body=None)

    def get_virtual_center_monitor_info(self, id):
        """
        Gets monitoring information related to Virtual Center.

        GET /monitor/v1/virtual-centers/{id}
        """
        return self._c.request("GET", f"/monitor/v1/virtual-centers/{id}", params=None, json_body=None)

    def list_ad_domain_monitor_infos_v2(self):
        """
        Lists monitoring information related to AD Domains of the environment.

        GET /monitor/v2/ad-domains
        """
        return self._c.request("GET", "/monitor/v2/ad-domains", params=None, json_body=None)

    def list_app_volumes_manager_monitor_info_v2(self):
        """
        Lists monitoring information related to App volumes managers registered in the environment.

        GET /monitor/v2/app-volumes-managers
        """
        return self._c.request("GET", "/monitor/v2/app-volumes-managers", params=None, json_body=None)

    def get_app_volumes_manager_monitor_info_v2(self, id):
        """
        Retrieves information about an app volumes manager.

        GET /monitor/v2/app-volumes-managers/{id}
        """
        return self._c.request("GET", f"/monitor/v2/app-volumes-managers/{id}", params=None, json_body=None)

    def list_connection_server_monitors_v2(self):
        """
        Lists monitoring information related to Connection Servers of the environment.

        GET /monitor/v2/connection-servers
        """
        return self._c.request("GET", "/monitor/v2/connection-servers", params=None, json_body=None)

    def get_connection_server_monitor_info_v3(self, id):
        """
        Gets monitoring information related to Connection Server.

        GET /monitor/v2/connection-servers/{id}
        """
        return self._c.request("GET", f"/monitor/v2/connection-servers/{id}", params=None, json_body=None)

    def list_desktop_pool_metrics_v2(self, ids: str = None):
        """
        Lists metrics of desktop pools (except RDS desktop pools).

        GET /monitor/v2/desktop-pools/metrics
        """
        params = {}
        if ids is not None: params['ids'] = ids
        return self._c.request("GET", "/monitor/v2/desktop-pools/metrics", params=params, json_body=None)

    def list_desktop_monitor_infos_v2(self):
        """
        Lists monitoring information related to desktop pools in the environment (except RDS desktop pools).

        GET /monitor/v2/desktops
        """
        return self._c.request("GET", "/monitor/v2/desktops", params=None, json_body=None)

    def get_desktop_monitor_info_v2(self, id):
        """
        Retrieves information related to a desktop pool (except RDS desktop pools).

        GET /monitor/v2/desktops/{id}
        """
        return self._c.request("GET", f"/monitor/v2/desktops/{id}", params=None, json_body=None)

    def get_event_database_monitor_v2(self):
        """
        Returns monitoring information related to Event database of the environment.

        GET /monitor/v2/event-database
        """
        return self._c.request("GET", "/monitor/v2/event-database", params=None, json_body=None)

    def list_farm_monitors_v2(self):
        """
        Lists monitoring data related to Farms of the environment.

        GET /monitor/v2/farms
        """
        return self._c.request("GET", "/monitor/v2/farms", params=None, json_body=None)

    def get_farm_monitor_info_v2(self, id):
        """
        Gets monitoring data related to farm.

        GET /monitor/v2/farms/{id}
        """
        return self._c.request("GET", f"/monitor/v2/farms/{id}", params=None, json_body=None)

    def list_gateway_monitor_info_v2(self):
        """
        Lists monitoring information related to Gateways registered in the environment.

        GET /monitor/v2/gateways
        """
        return self._c.request("GET", "/monitor/v2/gateways", params=None, json_body=None)

    def get_gateway_monitor_info_v2(self, id):
        """
        Gets monitoring information related to a Gateway.

        GET /monitor/v2/gateways/{id}
        """
        return self._c.request("GET", f"/monitor/v2/gateways/{id}", params=None, json_body=None)

    def get_machine_state_count_metrics_v2(self, ids: str = None):
        """
        Gets the state count metrics of the machines.

        GET /monitor/v2/machines/count-metrics
        """
        params = {}
        if ids is not None: params['ids'] = ids
        return self._c.request("GET", "/monitor/v2/machines/count-metrics", params=params, json_body=None)

    def list_pod_monitor_infos_v2(self):
        """
        Lists monitoring information related to the remote pods.

        GET /monitor/v2/pods
        """
        return self._c.request("GET", "/monitor/v2/pods", params=None, json_body=None)

    def list_rds_server_monitors_v2(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists monitoring information related to RDS Servers of the environment.

        GET /monitor/v2/rds-servers
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/monitor/v2/rds-servers", params=params, json_body=None)

    def get_rds_server_monitors_v2(self, id):
        """
        Gets monitoring information related to RDS Server.

        GET /monitor/v2/rds-servers/{id}
        """
        return self._c.request("GET", f"/monitor/v2/rds-servers/{id}", params=None, json_body=None)

    def list_saml_authenticator_monitors_v2(self):
        """
        Lists monitoring information related to SAML Authenticators of the environment.

        GET /monitor/v2/saml-authenticators
        """
        return self._c.request("GET", "/monitor/v2/saml-authenticators", params=None, json_body=None)

    def get_system_metrics_info_v2(self):
        """
        Gets the system metrics of all the components.

        GET /monitor/v2/system-metrics
        """
        return self._c.request("GET", "/monitor/v2/system-metrics", params=None, json_body=None)

    def list_true_sso_monitor_infos_v2(self):
        """
        Lists monitoring information related to True SSO connectors.

        GET /monitor/v2/true-sso
        """
        return self._c.request("GET", "/monitor/v2/true-sso", params=None, json_body=None)

    def get_true_sso_monitor_info_v2(self, id):
        """
        Gets monitoring information related to a True SSO connector.

        GET /monitor/v2/true-sso/{id}
        """
        return self._c.request("GET", f"/monitor/v2/true-sso/{id}", params=None, json_body=None)

    def list_view_composer_monitors_v2(self):
        """
        View Composer is no longer supported from Horizon version 2012 onwards.

        GET /monitor/v2/view-composers
        """
        return self._c.request("GET", "/monitor/v2/view-composers", params=None, json_body=None)

    def list_virtual_center_monitors_v2(self):
        """
        Lists monitoring information related to Virtual Centers of the environment.

        GET /monitor/v2/virtual-centers
        """
        return self._c.request("GET", "/monitor/v2/virtual-centers", params=None, json_body=None)

    def list_ad_domain_monitor_infos_v3(self):
        """
        Lists monitoring information related to AD Domains of the environment.

        GET /monitor/v3/ad-domains
        """
        return self._c.request("GET", "/monitor/v3/ad-domains", params=None, json_body=None)

    def list_connection_server_monitors_v3(self):
        """
        Lists monitoring information related to Connection Servers of the environment.

        GET /monitor/v3/connection-servers
        """
        return self._c.request("GET", "/monitor/v3/connection-servers", params=None, json_body=None)

    def list_desktop_pool_metrics_v3(self, ids: str = None):
        """
        Lists metrics of desktop pools (except RDS desktop pools).

        GET /monitor/v3/desktop-pools/metrics
        """
        params = {}
        if ids is not None: params['ids'] = ids
        return self._c.request("GET", "/monitor/v3/desktop-pools/metrics", params=params, json_body=None)

    def get_event_database_monitor_v3(self):
        """
        Returns monitoring information related to Event database of the environment.

        GET /monitor/v3/event-database
        """
        return self._c.request("GET", "/monitor/v3/event-database", params=None, json_body=None)

    def list_gateway_monitor_info_v3(self):
        """
        Lists monitoring information related to Gateways registered in the environment.

        GET /monitor/v3/gateways
        """
        return self._c.request("GET", "/monitor/v3/gateways", params=None, json_body=None)

    def list_rds_server_monitors_v3(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists monitoring information related to RDS Servers of the environment.

        GET /monitor/v3/rds-servers
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/monitor/v3/rds-servers", params=params, json_body=None)

    def get_rds_server_monitors_v3(self, id):
        """
        Gets monitoring information related to RDS Server.

        GET /monitor/v3/rds-servers/{id}
        """
        return self._c.request("GET", f"/monitor/v3/rds-servers/{id}", params=None, json_body=None)

    def list_saml_authenticator_monitors_v3(self):
        """
        Lists monitoring information related to SAML Authenticators of the environment.

        GET /monitor/v3/saml-authenticators
        """
        return self._c.request("GET", "/monitor/v3/saml-authenticators", params=None, json_body=None)

    def get_saml_authenticator_monitor_info_v3(self, id):
        """
        Gets Monitoring Information related to a SAML Authenticator

        GET /monitor/v3/saml-authenticators/{id}
        """
        return self._c.request("GET", f"/monitor/v3/saml-authenticators/{id}", params=None, json_body=None)

    def list_virtual_center_monitors_v3(self):
        """
        Lists monitoring information related to Virtual Centers of the environment.

        GET /monitor/v3/virtual-centers
        """
        return self._c.request("GET", "/monitor/v3/virtual-centers", params=None, json_body=None)

    def get_virtual_center_monitor_info_v3(self, id):
        """
        Gets monitoring information related to Virtual Center.

        GET /monitor/v3/virtual-centers/{id}
        """
        return self._c.request("GET", f"/monitor/v3/virtual-centers/{id}", params=None, json_body=None)

    def list_ad_domain_monitor_infos_v4(self):
        """
        Lists monitoring information related to AD Domains of the environment.

        GET /monitor/v4/ad-domains
        """
        return self._c.request("GET", "/monitor/v4/ad-domains", params=None, json_body=None)

    def list_connection_server_monitors_v4(self):
        """
        Lists monitoring information related to Connection Servers of the environment.

        GET /monitor/v4/connection-servers
        """
        return self._c.request("GET", "/monitor/v4/connection-servers", params=None, json_body=None)

    def get_connection_server_monitor_info_v4(self, id):
        """
        Gets monitoring information related to Connection Server.

        GET /monitor/v4/connection-servers/{id}
        """
        return self._c.request("GET", f"/monitor/v4/connection-servers/{id}", params=None, json_body=None)

    def list_gateway_monitor_info_v4(self):
        """
        Lists monitoring information related to Gateways registered in the environment.

        GET /monitor/v4/gateways
        """
        return self._c.request("GET", "/monitor/v4/gateways", params=None, json_body=None)

    def get_gateway_monitor_info_v4(self, id):
        """
        Gets monitoring information related to a Gateway.

        GET /monitor/v4/gateways/{id}
        """
        return self._c.request("GET", f"/monitor/v4/gateways/{id}", params=None, json_body=None)

    def list_rds_server_monitors_v4(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists monitoring information related to RDS Servers of the environment.

        GET /monitor/v4/rds-servers
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/monitor/v4/rds-servers", params=params, json_body=None)

    def get_rds_server_monitors_v4(self, id):
        """
        Gets monitoring information related to RDS Server.

        GET /monitor/v4/rds-servers/{id}
        """
        return self._c.request("GET", f"/monitor/v4/rds-servers/{id}", params=None, json_body=None)

    def list_saml_authenticator_monitors_v4(self):
        """
        Lists monitoring information related to SAML Authenticators of the environment.

        GET /monitor/v4/saml-authenticators
        """
        return self._c.request("GET", "/monitor/v4/saml-authenticators", params=None, json_body=None)

    def get_saml_authenticator_monitor_info_v4(self, id):
        """
        Gets Monitoring Information related to a SAML Authenticator

        GET /monitor/v4/saml-authenticators/{id}
        """
        return self._c.request("GET", f"/monitor/v4/saml-authenticators/{id}", params=None, json_body=None)

    def list_virtual_center_monitors_v4(self):
        """
        Lists monitoring information related to Virtual Centers of the environment.

        GET /monitor/v4/virtual-centers
        """
        return self._c.request("GET", "/monitor/v4/virtual-centers", params=None, json_body=None)

    def get_virtual_center_monitor_info_v4(self, id):
        """
        Gets monitoring information related to Virtual Center.

        GET /monitor/v4/virtual-centers/{id}
        """
        return self._c.request("GET", f"/monitor/v4/virtual-centers/{id}", params=None, json_body=None)

    def list_gateway_monitor_info_v5(self):
        """
        Lists monitoring information related to Gateways registered in the environment.

        GET /monitor/v5/gateways
        """
        return self._c.request("GET", "/monitor/v5/gateways", params=None, json_body=None)

    def get_gateway_monitor_info_v5(self, id):
        """
        Gets monitoring information related to a Gateway.

        GET /monitor/v5/gateways/{id}
        """
        return self._c.request("GET", f"/monitor/v5/gateways/{id}", params=None, json_body=None)

    def list_virtual_center_monitors_v5(self):
        """
        Lists monitoring information related to Virtual Centers of the environment.

        GET /monitor/v5/virtual-centers
        """
        return self._c.request("GET", "/monitor/v5/virtual-centers", params=None, json_body=None)

    def get_virtual_center_monitor_info_v5(self, id):
        """
        Gets monitoring information related to Virtual Center.

        GET /monitor/v5/virtual-centers/{id}
        """
        return self._c.request("GET", f"/monitor/v5/virtual-centers/{id}", params=None, json_body=None)

    def list_view_composer_monitors_v1(self):
        """
        View Composer is no longer supported from Horizon version 2012 onwards.

        GET /monitor/view-composers
        """
        return self._c.request("GET", "/monitor/view-composers", params=None, json_body=None)

    def list_virtual_center_monitors(self):
        """
        Lists monitoring information related to Virtual Centers of the environment.

        GET /monitor/virtual-centers
        """
        return self._c.request("GET", "/monitor/virtual-centers", params=None, json_body=None)
