# Copyright 2026 Abhilash Jha
# SPDX-License-Identifier: Apache-2.0

"""Federation API – auto-generated from Omnissa Horizon Server Swagger v2603."""
from typing import TYPE_CHECKING, Dict, Any, Optional, List

if TYPE_CHECKING:
    from omnissa_horizon.client import HorizonClient


class FederationAPI:
    """APIs for Federation (tag: Federation)."""

    def __init__(self, client: "HorizonClient"):
        self._c = client

    def get_pod_federation(self):
        """
        Retrieves the pod federation details.

        GET /federation/v1/cpa
        """
        return self._c.request("GET", "/federation/v1/cpa", params=None, json_body=None)

    def update_pod_federation(self, body: dict = None):
        """
        Updates a Pod Federation.

        PUT /federation/v1/cpa
        """
        return self._c.request("PUT", "/federation/v1/cpa", params=None, json_body=body)

    def eject_pod(self, body: dict = None):
        """
        Removes a pod from Cloud Pod Federation.

        POST /federation/v1/cpa/action/eject
        """
        return self._c.request("POST", "/federation/v1/cpa/action/eject", params=None, json_body=body)

    def initialize_cpa(self):
        """
        Initialize Cloud Pod Federation.

        POST /federation/v1/cpa/action/initialize
        """
        return self._c.request("POST", "/federation/v1/cpa/action/initialize", params=None, json_body=None)

    def join_cpa(self, body: dict = None):
        """
        Join Cloud Pod Federation.

        POST /federation/v1/cpa/action/join
        """
        return self._c.request("POST", "/federation/v1/cpa/action/join", params=None, json_body=body)

    def rotate_key_pair(self, body: dict = None):
        """
        Request for an on demand CPA Key Pair rotation.

        POST /federation/v1/cpa/action/rotate-keypair
        """
        return self._c.request("POST", "/federation/v1/cpa/action/rotate-keypair", params=None, json_body=body)

    def uninitialize_cpa(self):
        """
        Uninitialize Cloud Pod Federation.

        POST /federation/v1/cpa/action/uninitialize
        """
        return self._c.request("POST", "/federation/v1/cpa/action/uninitialize", params=None, json_body=None)

    def unjoin_cpa(self):
        """
        Unjoin from Cloud Pod Federation.

        POST /federation/v1/cpa/action/unjoin
        """
        return self._c.request("POST", "/federation/v1/cpa/action/unjoin", params=None, json_body=None)

    def list_tasks(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists all the CPA tasks in the pod federation.

        GET /federation/v1/cpa/tasks
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/federation/v1/cpa/tasks", params=params, json_body=None)

    def get_task(self, id):
        """
        Retrieves the information for a given task.

        GET /federation/v1/cpa/tasks/{id}
        """
        return self._c.request("GET", f"/federation/v1/cpa/tasks/{id}", params=None, json_body=None)

    def delete_home_sites(self, body: dict = None):
        """
        Deletes the given home sites from the pod federation.

        DELETE /federation/v1/home-sites
        """
        return self._c.request("DELETE", "/federation/v1/home-sites", params=None, json_body=body)

    def list_home_sites(self, page: str = None, size: str = None, filter: str = None):
        """
        Lists all the home sites in the pod federation.

        GET /federation/v1/home-sites
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        return self._c.request("GET", "/federation/v1/home-sites", params=params, json_body=None)

    def create_home_sites(self, body: dict = None):
        """
        Creates the given home sites in the pod federation.

        POST /federation/v1/home-sites
        """
        return self._c.request("POST", "/federation/v1/home-sites", params=None, json_body=body)

    def resolve_home_sites(self, body: dict = None):
        """
        Resolves home sites for a user in the pod federation.

        POST /federation/v1/home-sites/action/resolve
        """
        return self._c.request("POST", "/federation/v1/home-sites/action/resolve", params=None, json_body=body)

    def get_home_site(self, id):
        """
        Retrieves a given home site in the pod federation.

        GET /federation/v1/home-sites/{id}
        """
        return self._c.request("GET", f"/federation/v1/home-sites/{id}", params=None, json_body=None)

    def list_pod_assignments(self, page: str = None, size: str = None, filter: str = None):
        """
        Lists all the pod assignments in the pod federation.

        GET /federation/v1/pod-assignments
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        return self._c.request("GET", "/federation/v1/pod-assignments", params=params, json_body=None)

    def get_pod_assignment(self, id):
        """
        Retrieves a given pod assignment from the pod federation.

        GET /federation/v1/pod-assignments/{id}
        """
        return self._c.request("GET", f"/federation/v1/pod-assignments/{id}", params=None, json_body=None)

    def list_pods(self):
        """
        Lists all the pods in the pod federation.

        GET /federation/v1/pods
        """
        return self._c.request("GET", "/federation/v1/pods", params=None, json_body=None)

    def get_pod(self, id):
        """
        Retrieves a given pod from the pod federation.

        GET /federation/v1/pods/{id}
        """
        return self._c.request("GET", f"/federation/v1/pods/{id}", params=None, json_body=None)

    def update_pod(self, id, body: dict = None):
        """
        Updates the given pod in the pod federation.

        PUT /federation/v1/pods/{id}
        """
        return self._c.request("PUT", f"/federation/v1/pods/{id}", params=None, json_body=body)

    def list_pod_endpoint(self, id):
        """
        Lists all the pod endpoints for the given pod.

        GET /federation/v1/pods/{id}/endpoints
        """
        return self._c.request("GET", f"/federation/v1/pods/{id}/endpoints", params=None, json_body=None)

    def get_pod_endpoint(self, id, endpointId):
        """
        Retrieves pod endpoint details for the given pod endpoint id in the given pod.

        GET /federation/v1/pods/{id}/endpoints/{endpointId}
        """
        return self._c.request("GET", f"/federation/v1/pods/{id}/endpoints/{endpointId}", params=None, json_body=None)

    def list_sites(self):
        """
        Lists all the sites in the pod federation.

        GET /federation/v1/sites
        """
        return self._c.request("GET", "/federation/v1/sites", params=None, json_body=None)

    def create_site(self, body: dict = None):
        """
        Creates a site.

        POST /federation/v1/sites
        """
        return self._c.request("POST", "/federation/v1/sites", params=None, json_body=body)

    def delete_site(self, id):
        """
        Deletes a site.

        DELETE /federation/v1/sites/{id}
        """
        return self._c.request("DELETE", f"/federation/v1/sites/{id}", params=None, json_body=None)

    def get_site(self, id):
        """
        Retrives a given site.

        GET /federation/v1/sites/{id}
        """
        return self._c.request("GET", f"/federation/v1/sites/{id}", params=None, json_body=None)

    def update_site(self, id, body: dict = None):
        """
        Updates a site.

        PUT /federation/v1/sites/{id}
        """
        return self._c.request("PUT", f"/federation/v1/sites/{id}", params=None, json_body=body)

    def get_pod_federation_v2(self):
        """
        Retrieves the pod federation details.

        GET /federation/v2/cpa
        """
        return self._c.request("GET", "/federation/v2/cpa", params=None, json_body=None)

    def update_pod_federation_v2(self, body: dict = None):
        """
        Updates a Pod Federation.

        PUT /federation/v2/cpa
        """
        return self._c.request("PUT", "/federation/v2/cpa", params=None, json_body=body)

    def delete_home_sites_v2(self, body: dict = None):
        """
        Deletes the given home sites from the pod federation.

        DELETE /federation/v2/home-sites
        """
        return self._c.request("DELETE", "/federation/v2/home-sites", params=None, json_body=body)

    def list_home_sites_v2(self, page: str = None, size: str = None, filter: str = None):
        """
        Lists all the home sites in the pod federation.

        GET /federation/v2/home-sites
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        return self._c.request("GET", "/federation/v2/home-sites", params=params, json_body=None)

    def create_home_sites_v2(self, body: dict = None):
        """
        Creates the given home sites in the pod federation.

        POST /federation/v2/home-sites
        """
        return self._c.request("POST", "/federation/v2/home-sites", params=None, json_body=body)

    def resolve_home_sites_v2(self, body: dict = None):
        """
        Resolves home sites for a user in the pod federation.

        POST /federation/v2/home-sites/action/resolve
        """
        return self._c.request("POST", "/federation/v2/home-sites/action/resolve", params=None, json_body=body)

    def get_home_site_v2(self, id):
        """
        Retrieves a given home site in the pod federation.

        GET /federation/v2/home-sites/{id}
        """
        return self._c.request("GET", f"/federation/v2/home-sites/{id}", params=None, json_body=None)

    def update_home_site_v2(self, id, body: dict = None):
        """
        Updates the given home sites from the pod federation.

        PUT /federation/v2/home-sites/{id}
        """
        return self._c.request("PUT", f"/federation/v2/home-sites/{id}", params=None, json_body=body)

    def list_sites_v2(self):
        """
        Lists all the sites in the pod federation.

        GET /federation/v2/sites
        """
        return self._c.request("GET", "/federation/v2/sites", params=None, json_body=None)

    def create_site_v2(self, body: dict = None):
        """
        Creates a site.

        POST /federation/v2/sites
        """
        return self._c.request("POST", "/federation/v2/sites", params=None, json_body=body)

    def delete_site_v2(self, id):
        """
        Deletes a site.

        DELETE /federation/v2/sites/{id}
        """
        return self._c.request("DELETE", f"/federation/v2/sites/{id}", params=None, json_body=None)

    def get_site_v2(self, id):
        """
        Retrives a given site.

        GET /federation/v2/sites/{id}
        """
        return self._c.request("GET", f"/federation/v2/sites/{id}", params=None, json_body=None)

    def update_site_v2(self, id, body: dict = None):
        """
        Updates a site.

        PUT /federation/v2/sites/{id}
        """
        return self._c.request("PUT", f"/federation/v2/sites/{id}", params=None, json_body=body)

    def list_sites_v3(self):
        """
        Lists all the sites in the pod federation.

        GET /federation/v3/sites
        """
        return self._c.request("GET", "/federation/v3/sites", params=None, json_body=None)

    def create_site_v3(self, body: dict = None):
        """
        Creates a site.

        POST /federation/v3/sites
        """
        return self._c.request("POST", "/federation/v3/sites", params=None, json_body=body)

    def delete_site_v3(self, id):
        """
        Deletes a site.

        DELETE /federation/v3/sites/{id}
        """
        return self._c.request("DELETE", f"/federation/v3/sites/{id}", params=None, json_body=None)

    def get_site_v3(self, id):
        """
        Retrieves a given site.

        GET /federation/v3/sites/{id}
        """
        return self._c.request("GET", f"/federation/v3/sites/{id}", params=None, json_body=None)

    def update_site_v3(self, id, body: dict = None):
        """
        Updates a site.

        PUT /federation/v3/sites/{id}
        """
        return self._c.request("PUT", f"/federation/v3/sites/{id}", params=None, json_body=body)
