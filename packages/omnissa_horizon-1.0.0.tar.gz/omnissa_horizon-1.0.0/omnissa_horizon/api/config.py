# Copyright 2026 Abhilash Jha
# SPDX-License-Identifier: Apache-2.0

"""Config API – auto-generated from Omnissa Horizon Server Swagger v2603."""
from typing import TYPE_CHECKING, Dict, Any, Optional, List

if TYPE_CHECKING:
    from omnissa_horizon.client import HorizonClient


class ConfigAPI:
    """APIs for Config (tag: Config)."""

    def __init__(self, client: "HorizonClient"):
        self._c = client

    def get_admin_users_or_groups_permissions(self, ad_user_or_group_id: str = None):
        """
        Gets permission information for logged in or other admin user or group.

        GET /config/v1/admin-users-or-groups/permissions
        """
        params = {}
        if ad_user_or_group_id is not None: params['ad_user_or_group_id'] = ad_user_or_group_id
        return self._c.request("GET", "/config/v1/admin-users-or-groups/permissions", params=params, json_body=None)

    def get_preferences(self):
        """
        Gets Horizon Console preferences for the logged in administrator.

        GET /config/v1/admin-users-or-groups/preferences
        """
        return self._c.request("GET", "/config/v1/admin-users-or-groups/preferences", params=None, json_body=None)

    def update_preferences(self, body: dict = None):
        """
        Updates the Horizon Console preferences for the logged in administrator.

        PUT /config/v1/admin-users-or-groups/preferences
        """
        return self._c.request("PUT", "/config/v1/admin-users-or-groups/preferences", params=None, json_body=body)

    def list_app_volumes_managers(self):
        """
        Lists the configured app volumes managers.

        GET /config/v1/app-volumes-manager
        """
        return self._c.request("GET", "/config/v1/app-volumes-manager", params=None, json_body=None)

    def add_app_volumes_manager(self, body: dict = None):
        """
        Add the app volumes manager

        POST /config/v1/app-volumes-manager
        """
        return self._c.request("POST", "/config/v1/app-volumes-manager", params=None, json_body=body)

    def unassign_farms(self, body: dict = None):
        """
        Unassign Farms to App Volumes Manager

        POST /config/v1/app-volumes-manager/action/unassign-farms
        """
        return self._c.request("POST", "/config/v1/app-volumes-manager/action/unassign-farms", params=None, json_body=body)

    def validate_avm_certificate(self, body: dict = None):
        """
        Validates App Volumes manager certificate.

        POST /config/v1/app-volumes-manager/action/validate-certificate
        """
        return self._c.request("POST", "/config/v1/app-volumes-manager/action/validate-certificate", params=None, json_body=body)

    def delete_app_volumes_manager(self, id):
        """
        deletes the given app volumes manager

        DELETE /config/v1/app-volumes-manager/{id}
        """
        return self._c.request("DELETE", f"/config/v1/app-volumes-manager/{id}", params=None, json_body=None)

    def get_app_volumes_manager(self, id):
        """
        Retrieves information about an app volumes manager.

        GET /config/v1/app-volumes-manager/{id}
        """
        return self._c.request("GET", f"/config/v1/app-volumes-manager/{id}", params=None, json_body=None)

    def update_app_volumes_manager(self, id, body: dict = None):
        """
        Updates the given app volumes manager.

        PUT /config/v1/app-volumes-manager/{id}
        """
        return self._c.request("PUT", f"/config/v1/app-volumes-manager/{id}", params=None, json_body=body)

    def assign_farms(self, id, body: dict = None):
        """
        Assign Farms to App Volumes Manager

        POST /config/v1/app-volumes-manager/{id}/action/assign-farms
        """
        return self._c.request("POST", f"/config/v1/app-volumes-manager/{id}/action/assign-farms", params=None, json_body=body)

    def override_certificate(self, id, body: dict = None):
        """
        Override the given app volumes manager certificate.

        POST /config/v1/app-volumes-manager/{id}/action/override-certificate
        """
        return self._c.request("POST", f"/config/v1/app-volumes-manager/{id}/action/override-certificate", params=None, json_body=body)

    def push_certificates(self, id):
        """
        Push cluster certificates to App Volumes Manager

        POST /config/v1/app-volumes-manager/{id}/action/push-certificates
        """
        return self._c.request("POST", f"/config/v1/app-volumes-manager/{id}/action/push-certificates", params=None, json_body=None)

    def get_ceip_info(self):
        """
        Get the CEIP Information.

        GET /config/v1/ceip
        """
        return self._c.request("GET", "/config/v1/ceip", params=None, json_body=None)

    def update_ceip_info(self, body: dict = None):
        """
        Update the CEIP Information.

        PUT /config/v1/ceip
        """
        return self._c.request("PUT", "/config/v1/ceip", params=None, json_body=body)

    def list_compute_profiles(self):
        """
        Lists the configured compute profiles.

        GET /config/v1/compute-profiles
        """
        return self._c.request("GET", "/config/v1/compute-profiles", params=None, json_body=None)

    def create_compute_profile(self, body: dict = None):
        """
        Creates a Compute Profile.

        POST /config/v1/compute-profiles
        """
        return self._c.request("POST", "/config/v1/compute-profiles", params=None, json_body=body)

    def delete_compute_profile(self, id):
        """
        Deletes a Compute Profile.

        DELETE /config/v1/compute-profiles/{id}
        """
        return self._c.request("DELETE", f"/config/v1/compute-profiles/{id}", params=None, json_body=None)

    def get_compute_profile(self, id):
        """
        Retrieves information about a Compute Profile.

        GET /config/v1/compute-profiles/{id}
        """
        return self._c.request("GET", f"/config/v1/compute-profiles/{id}", params=None, json_body=None)

    def update_compute_profile(self, id, body: dict = None):
        """
        Updates a Compute Profile.

        PUT /config/v1/compute-profiles/{id}
        """
        return self._c.request("PUT", f"/config/v1/compute-profiles/{id}", params=None, json_body=body)

    def list_connection_servers(self):
        """
        Lists the connection servers.

        GET /config/v1/connection-servers
        """
        return self._c.request("GET", "/config/v1/connection-servers", params=None, json_body=None)

    def back_up(self, body: dict = None):
        """
        Initiates immediate back up of Connection Servers

        POST /config/v1/connection-servers/action/backup
        """
        return self._c.request("POST", "/config/v1/connection-servers/action/backup", params=None, json_body=body)

    def delete_certificate(self, body: dict = None, delete_permanently: str = None):
        """
        Deletes both Machine and Cluster SSL certificates of connection server.

        DELETE /config/v1/connection-servers/action/certificates
        """
        params = {}
        if delete_permanently is not None: params['delete_permanently'] = delete_permanently
        return self._c.request("DELETE", "/config/v1/connection-servers/action/certificates", params=params, json_body=body)

    def disable_connection_servers(self, body: dict = None):
        """
        Disables the given list of connection server ids.

        POST /config/v1/connection-servers/action/disable
        """
        return self._c.request("POST", "/config/v1/connection-servers/action/disable", params=None, json_body=body)

    def enable_connection_servers(self, body: dict = None):
        """
        Enables the given list of connection server ids.

        POST /config/v1/connection-servers/action/enable
        """
        return self._c.request("POST", "/config/v1/connection-servers/action/enable", params=None, json_body=body)

    def export_certificate(self, body: dict = None):
        """
        Exports the in-use certificate of connection server

        POST /config/v1/connection-servers/action/export-certificate
        """
        return self._c.request("POST", "/config/v1/connection-servers/action/export-certificate", params=None, json_body=body)

    def generate_csr(self, body: dict = None):
        """
        Generate Certificate Signing Request(CSR).

        POST /config/v1/connection-servers/action/generate-csr
        """
        return self._c.request("POST", "/config/v1/connection-servers/action/generate-csr", params=None, json_body=body)

    def import_certificate(self, body: dict = None):
        """
        Imports both Machine and Cluster SSL certificate to connection server's certificate store.

        POST /config/v1/connection-servers/action/import-certificate
        """
        return self._c.request("POST", "/config/v1/connection-servers/action/import-certificate", params=None, json_body=body)

    def recover_certificates(self, body: dict = None):
        """
        Recover the deleted certificates.

        POST /config/v1/connection-servers/action/recover-certificates
        """
        return self._c.request("POST", "/config/v1/connection-servers/action/recover-certificates", params=None, json_body=body)

    def list_certificate_infos(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Retrieves the certificate details.

        GET /config/v1/connection-servers/certificates
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/config/v1/connection-servers/certificates", params=params, json_body=None)

    def get_security_configuration_info(self):
        """
        Retrieves the security configuration of connection server and secure gateway

        GET /config/v1/connection-servers/security-configuration
        """
        return self._c.request("GET", "/config/v1/connection-servers/security-configuration", params=None, json_body=None)

    def get_connection_server(self, id):
        """
        Retrieves information about a connection server.

        GET /config/v1/connection-servers/{id}
        """
        return self._c.request("GET", f"/config/v1/connection-servers/{id}", params=None, json_body=None)

    def update_connection_server(self, id, body: dict = None):
        """
        Updates the settings of the given Connection Server.

        PUT /config/v1/connection-servers/{id}
        """
        return self._c.request("PUT", f"/config/v1/connection-servers/{id}", params=None, json_body=body)

    def list_customization_specifications(self):
        """
        Lists the Customization Specifications.

        GET /config/v1/customization-specifications
        """
        return self._c.request("GET", "/config/v1/customization-specifications", params=None, json_body=None)

    def create_customization_specification(self, body: dict = None):
        """
        Creates a Customization Specification.

        POST /config/v1/customization-specifications
        """
        return self._c.request("POST", "/config/v1/customization-specifications", params=None, json_body=body)

    def delete_customization_specification(self, id):
        """
        Deletes a Customization Specification.

        DELETE /config/v1/customization-specifications/{id}
        """
        return self._c.request("DELETE", f"/config/v1/customization-specifications/{id}", params=None, json_body=None)

    def get_customization_specification(self, id):
        """
        Retrieves information about a Customization Specification.

        GET /config/v1/customization-specifications/{id}
        """
        return self._c.request("GET", f"/config/v1/customization-specifications/{id}", params=None, json_body=None)

    def update_customization_specification(self, id, body: dict = None):
        """
        Updates a Customization Specification.

        PUT /config/v1/customization-specifications/{id}
        """
        return self._c.request("PUT", f"/config/v1/customization-specifications/{id}", params=None, json_body=body)

    def get_environment(self):
        """
        Retrieves the environment settings.

        GET /config/v1/environment-properties
        """
        return self._c.request("GET", "/config/v1/environment-properties", params=None, json_body=None)

    def get_event_database(self):
        """
        Returns information about event database configuration.

        GET /config/v1/event-database
        """
        return self._c.request("GET", "/config/v1/event-database", params=None, json_body=None)

    def update_event_database_v1(self, body: dict = None):
        """
        Updates event database configuration.

        PUT /config/v1/event-database
        """
        return self._c.request("PUT", "/config/v1/event-database", params=None, json_body=body)

    def clear_event_database(self):
        """
        Deletes event database configuration.

        POST /config/v1/event-database/action/clear
        """
        return self._c.request("POST", "/config/v1/event-database/action/clear", params=None, json_body=None)

    def list_external_deployments(self):
        """
        Lists the configured external deployments.

        GET /config/v1/external-deployments
        """
        return self._c.request("GET", "/config/v1/external-deployments", params=None, json_body=None)

    def add_external_deployment(self, body: dict = None):
        """
        Add the external deployment

        POST /config/v1/external-deployments
        """
        return self._c.request("POST", "/config/v1/external-deployments", params=None, json_body=body)

    def refresh_external_deployment_keys(self, body: dict = None):
        """
        Refreshes public keys for external deployment feature.

        POST /config/v1/external-deployments/action/refresh-keys
        """
        return self._c.request("POST", "/config/v1/external-deployments/action/refresh-keys", params=None, json_body=body)

    def validate_external_deployment_certificate(self, body: dict = None):
        """
        Validates External Deployment connection server certificate.

        POST /config/v1/external-deployments/action/validate-certificate
        """
        return self._c.request("POST", "/config/v1/external-deployments/action/validate-certificate", params=None, json_body=body)

    def delete_external_deployment(self, id):
        """
        Deletes the given external deployment

        DELETE /config/v1/external-deployments/{id}
        """
        return self._c.request("DELETE", f"/config/v1/external-deployments/{id}", params=None, json_body=None)

    def get_external_deployment(self, id):
        """
        Retrieves information about an external deployment.

        GET /config/v1/external-deployments/{id}
        """
        return self._c.request("GET", f"/config/v1/external-deployments/{id}", params=None, json_body=None)

    def update_external_deployment(self, id, body: dict = None):
        """
        Updates the given external deployment.

        PUT /config/v1/external-deployments/{id}
        """
        return self._c.request("PUT", f"/config/v1/external-deployments/{id}", params=None, json_body=body)

    def list_federation_access_groups(self):
        """
        Lists all federation access groups.

        GET /config/v1/federation-access-groups
        """
        return self._c.request("GET", "/config/v1/federation-access-groups", params=None, json_body=None)

    def create_federation_access_group(self, body: dict = None):
        """
        Creates federation access group.

        POST /config/v1/federation-access-groups
        """
        return self._c.request("POST", "/config/v1/federation-access-groups", params=None, json_body=body)

    def delete_federation_access_group(self, id):
        """
        Deletes a federation access group.

        DELETE /config/v1/federation-access-groups/{id}
        """
        return self._c.request("DELETE", f"/config/v1/federation-access-groups/{id}", params=None, json_body=None)

    def get_federation_access_group(self, id):
        """
        Retrieves a federation access group.

        GET /config/v1/federation-access-groups/{id}
        """
        return self._c.request("GET", f"/config/v1/federation-access-groups/{id}", params=None, json_body=None)

    def delete_gateway_access_user_or_group(self, body: dict = None):
        """
        Deletes a specified gateway access user or group in the environment.

        DELETE /config/v1/gateway-access-users-or-groups
        """
        return self._c.request("DELETE", "/config/v1/gateway-access-users-or-groups", params=None, json_body=body)

    def list_gateway_access_user_or_group(self):
        """
        Lists gateway access users or group in the environment.

        GET /config/v1/gateway-access-users-or-groups
        """
        return self._c.request("GET", "/config/v1/gateway-access-users-or-groups", params=None, json_body=None)

    def create_gateway_access_user_or_group(self, body: dict = None):
        """
        Creates a specified gateway access user or group in the environment.

        POST /config/v1/gateway-access-users-or-groups
        """
        return self._c.request("POST", "/config/v1/gateway-access-users-or-groups", params=None, json_body=body)

    def list_gateways(self):
        """
        Lists the registered gateways.

        GET /config/v1/gateways
        """
        return self._c.request("GET", "/config/v1/gateways", params=None, json_body=None)

    def register_gateway(self, body: dict = None):
        """
        Register gateway.

        POST /config/v1/gateways
        """
        return self._c.request("POST", "/config/v1/gateways", params=None, json_body=body)

    def list_gateway_certificates_info(self):
        """
        Lists the information of the gateway certificates.

        GET /config/v1/gateways/certificates
        """
        return self._c.request("GET", "/config/v1/gateways/certificates", params=None, json_body=None)

    def add_gateway_certificate(self, body: dict = None):
        """
        Add the gateway certificate.

        POST /config/v1/gateways/certificates
        """
        return self._c.request("POST", "/config/v1/gateways/certificates", params=None, json_body=body)

    def delete_gateway_certificate(self, id):
        """
        Deletes the gateway certificate.

        DELETE /config/v1/gateways/certificates/{id}
        """
        return self._c.request("DELETE", f"/config/v1/gateways/certificates/{id}", params=None, json_body=None)

    def unregister_gateway(self, id):
        """
        Unregister gateway.

        DELETE /config/v1/gateways/{id}
        """
        return self._c.request("DELETE", f"/config/v1/gateways/{id}", params=None, json_body=None)

    def get_gateway(self, id):
        """
        Retrieves information about a registered gateway.

        GET /config/v1/gateways/{id}
        """
        return self._c.request("GET", f"/config/v1/gateways/{id}", params=None, json_body=None)

    def get_global_policies(self):
        """
        Returns the global policies in the environment.

        GET /config/v1/global-policies
        """
        return self._c.request("GET", "/config/v1/global-policies", params=None, json_body=None)

    def update_global_policies(self, body: dict = None):
        """
        Updates the global policies in the environment.

        PUT /config/v1/global-policies
        """
        return self._c.request("PUT", "/config/v1/global-policies", params=None, json_body=body)

    def list_gssapi_authenticators(self):
        """
        Lists the configured GSSAPI Authenticators.

        GET /config/v1/gssapi-authenticators
        """
        return self._c.request("GET", "/config/v1/gssapi-authenticators", params=None, json_body=None)

    def create_gssapi_authenticator(self, body: dict = None):
        """
        Creates a GSSAPI authenticator.

        POST /config/v1/gssapi-authenticators
        """
        return self._c.request("POST", "/config/v1/gssapi-authenticators", params=None, json_body=body)

    def delete_gssapi_authenticator(self, id, forced: str = None):
        """
        Deletes a GSSAPI Authenticator.

        DELETE /config/v1/gssapi-authenticators/{id}
        """
        params = {}
        if forced is not None: params['forced'] = forced
        return self._c.request("DELETE", f"/config/v1/gssapi-authenticators/{id}", params=params, json_body=None)

    def get_gssapi_authenticator(self, id):
        """
        Retrieves information about a GSSAPI Authenticator.

        GET /config/v1/gssapi-authenticators/{id}
        """
        return self._c.request("GET", f"/config/v1/gssapi-authenticators/{id}", params=None, json_body=None)

    def update_gssapi_authenticator(self, id, body: dict = None):
        """
        Updates a GSSAPI Authenticator.

        PUT /config/v1/gssapi-authenticators/{id}
        """
        return self._c.request("PUT", f"/config/v1/gssapi-authenticators/{id}", params=None, json_body=body)

    def list_ic_domain_accounts(self, page: str = None, size: str = None):
        """
        Lists instant clone domain accounts of the environment.

        GET /config/v1/ic-domain-accounts
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        return self._c.request("GET", "/config/v1/ic-domain-accounts", params=params, json_body=None)

    def create_ic_domain_account(self, body: dict = None):
        """
        Creates instant clone domain account.

        POST /config/v1/ic-domain-accounts
        """
        return self._c.request("POST", "/config/v1/ic-domain-accounts", params=None, json_body=body)

    def delete_ic_domain_account(self, id):
        """
        Deletes instant clone domain account.

        DELETE /config/v1/ic-domain-accounts/{id}
        """
        return self._c.request("DELETE", f"/config/v1/ic-domain-accounts/{id}", params=None, json_body=None)

    def get_ic_domain_account(self, id):
        """
        Gets instant clone domain account.

        GET /config/v1/ic-domain-accounts/{id}
        """
        return self._c.request("GET", f"/config/v1/ic-domain-accounts/{id}", params=None, json_body=None)

    def update_ic_domain_account(self, id, body: dict = None):
        """
        Updates instant clone domain account.

        PUT /config/v1/ic-domain-accounts/{id}
        """
        return self._c.request("PUT", f"/config/v1/ic-domain-accounts/{id}", params=None, json_body=body)

    def get_ad_sites_info(self, id):
        """
        Get all the available AD sites for the instant clone domain account.

        GET /config/v1/ic-domain-accounts/{id}/ad_sites
        """
        return self._c.request("GET", f"/config/v1/ic-domain-accounts/{id}/ad_sites", params=None, json_body=None)

    def list_im_assets(self, im_version_id: str = None, im_tag_id: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists image management assets.

        GET /config/v1/im-assets
        """
        params = {}
        if im_version_id is not None: params['im_version_id'] = im_version_id
        if im_tag_id is not None: params['im_tag_id'] = im_tag_id
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/config/v1/im-assets", params=params, json_body=None)

    def create_im_asset(self, body: dict = None):
        """
        Creates image management asset.

        POST /config/v1/im-assets
        """
        return self._c.request("POST", "/config/v1/im-assets", params=None, json_body=body)

    def create_im_assets(self, body: dict = None):
        """
        Creates one or more image management assets. Each of the index of result in the response, correspond to the index of the original asset.

        POST /config/v1/im-assets/action/bulk-create
        """
        return self._c.request("POST", "/config/v1/im-assets/action/bulk-create", params=None, json_body=body)

    def delete_im_asset(self, id):
        """
        Deletes image management asset.

        DELETE /config/v1/im-assets/{id}
        """
        return self._c.request("DELETE", f"/config/v1/im-assets/{id}", params=None, json_body=None)

    def get_im_asset(self, id):
        """
        Gets image management asset.

        GET /config/v1/im-assets/{id}
        """
        return self._c.request("GET", f"/config/v1/im-assets/{id}", params=None, json_body=None)

    def update_im_asset(self, id, body: dict = None):
        """
        Updates image management asset.

        PUT /config/v1/im-assets/{id}
        """
        return self._c.request("PUT", f"/config/v1/im-assets/{id}", params=None, json_body=body)

    def list_im_streams(self, vcenter_id: str = None, clone_type: str = None, image_type: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists image management streams.

        GET /config/v1/im-streams
        """
        params = {}
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        if clone_type is not None: params['clone_type'] = clone_type
        if image_type is not None: params['image_type'] = image_type
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/config/v1/im-streams", params=params, json_body=None)

    def create_im_stream(self, body: dict = None):
        """
        Creates image management stream.

        POST /config/v1/im-streams
        """
        return self._c.request("POST", "/config/v1/im-streams", params=None, json_body=body)

    def create_im_streams(self, body: dict = None):
        """
        Creates one or more image management streams. Each of the index of result in the response, correspond to the index of the original stream.

        POST /config/v1/im-streams/action/bulk-create
        """
        return self._c.request("POST", "/config/v1/im-streams/action/bulk-create", params=None, json_body=body)

    def delete_im_stream(self, id):
        """
        Deletes image management stream.

        DELETE /config/v1/im-streams/{id}
        """
        return self._c.request("DELETE", f"/config/v1/im-streams/{id}", params=None, json_body=None)

    def get_im_stream(self, id):
        """
        Gets image management stream.

        GET /config/v1/im-streams/{id}
        """
        return self._c.request("GET", f"/config/v1/im-streams/{id}", params=None, json_body=None)

    def update_im_stream(self, id, body: dict = None):
        """
        Updates image management stream.

        PUT /config/v1/im-streams/{id}
        """
        return self._c.request("PUT", f"/config/v1/im-streams/{id}", params=None, json_body=body)

    def list_im_tags(self, im_stream_id: str, vcenter_id: str = None, clone_type: str = None, image_type: str = None, fetch_available_assets_only: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists image management tags.

        GET /config/v1/im-tags
        """
        params = {}
        if im_stream_id is not None: params['im_stream_id'] = im_stream_id
        if vcenter_id is not None: params['vcenter_id'] = vcenter_id
        if clone_type is not None: params['clone_type'] = clone_type
        if image_type is not None: params['image_type'] = image_type
        if fetch_available_assets_only is not None: params['fetch_available_assets_only'] = fetch_available_assets_only
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/config/v1/im-tags", params=params, json_body=None)

    def create_im_tag(self, body: dict = None):
        """
        Creates image management tag.

        POST /config/v1/im-tags
        """
        return self._c.request("POST", "/config/v1/im-tags", params=None, json_body=body)

    def create_im_tags(self, body: dict = None):
        """
        Creates one or more image management tags. Each of the index of result in the response, correspond to the index of the original tag.

        POST /config/v1/im-tags/action/bulk-create
        """
        return self._c.request("POST", "/config/v1/im-tags/action/bulk-create", params=None, json_body=body)

    def delete_im_tag(self, id):
        """
        Deletes image management tag.

        DELETE /config/v1/im-tags/{id}
        """
        return self._c.request("DELETE", f"/config/v1/im-tags/{id}", params=None, json_body=None)

    def get_im_tag(self, id):
        """
        Gets image management tag.

        GET /config/v1/im-tags/{id}
        """
        return self._c.request("GET", f"/config/v1/im-tags/{id}", params=None, json_body=None)

    def update_im_tag(self, id, body: dict = None):
        """
        Updates image management tag.

        PUT /config/v1/im-tags/{id}
        """
        return self._c.request("PUT", f"/config/v1/im-tags/{id}", params=None, json_body=body)

    def list_im_versions(self, im_stream_id: str, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists image management versions.

        GET /config/v1/im-versions
        """
        params = {}
        if im_stream_id is not None: params['im_stream_id'] = im_stream_id
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/config/v1/im-versions", params=params, json_body=None)

    def create_im_version(self, body: dict = None):
        """
        Creates image management version.

        POST /config/v1/im-versions
        """
        return self._c.request("POST", "/config/v1/im-versions", params=None, json_body=body)

    def create_im_versions(self, body: dict = None):
        """
        Creates one or more image management versions. Each of the index of result in the response, correspond to the index of the original version.

        POST /config/v1/im-versions/action/bulk-create
        """
        return self._c.request("POST", "/config/v1/im-versions/action/bulk-create", params=None, json_body=body)

    def delete_im_version(self, id):
        """
        Deletes image management version.

        DELETE /config/v1/im-versions/{id}
        """
        return self._c.request("DELETE", f"/config/v1/im-versions/{id}", params=None, json_body=None)

    def get_im_version(self, id):
        """
        Gets image management version.

        GET /config/v1/im-versions/{id}
        """
        return self._c.request("GET", f"/config/v1/im-versions/{id}", params=None, json_body=None)

    def update_im_version(self, id, body: dict = None):
        """
        Updates image management version.

        PUT /config/v1/im-versions/{id}
        """
        return self._c.request("PUT", f"/config/v1/im-versions/{id}", params=None, json_body=body)

    def list_jwt_authenticators(self):
        """
        Lists the configured JWT authenticators.

        GET /config/v1/jwt-authenticators
        """
        return self._c.request("GET", "/config/v1/jwt-authenticators", params=None, json_body=None)

    def create_jwt_authenticator(self, body: dict = None):
        """
        Creates a JWT authenticator.

        POST /config/v1/jwt-authenticators
        """
        return self._c.request("POST", "/config/v1/jwt-authenticators", params=None, json_body=body)

    def delete_jwt_authenticator(self, id):
        """
        Deletes the given JWT authenticator.

        DELETE /config/v1/jwt-authenticators/{id}
        """
        return self._c.request("DELETE", f"/config/v1/jwt-authenticators/{id}", params=None, json_body=None)

    def get_jwt_authenticator(self, id):
        """
        Retrieves information about the given JWT authenticator.

        GET /config/v1/jwt-authenticators/{id}
        """
        return self._c.request("GET", f"/config/v1/jwt-authenticators/{id}", params=None, json_body=None)

    def update_jwt_authenticator(self, id, body: dict = None):
        """
        Updates the given JWT authenticator.

        PUT /config/v1/jwt-authenticators/{id}
        """
        return self._c.request("PUT", f"/config/v1/jwt-authenticators/{id}", params=None, json_body=body)

    def associate_jwt_authenticator_with_connection_servers(self, id, body: dict = None):
        """
        Associates JWT authenticator with multiple connection servers.

        POST /config/v1/jwt-authenticators/{id}/action/associate-connection-servers
        """
        return self._c.request("POST", f"/config/v1/jwt-authenticators/{id}/action/associate-connection-servers", params=None, json_body=body)

    def dissociate_jwt_authenticator_with_connection_servers(self, id, body: dict = None):
        """
        Dissociate JWT authenticator with multiple connection servers.

        POST /config/v1/jwt-authenticators/{id}/action/dissociate-connection-servers
        """
        return self._c.request("POST", f"/config/v1/jwt-authenticators/{id}/action/dissociate-connection-servers", params=None, json_body=body)

    def list_licenses(self):
        """
        Lists all licenses.

        GET /config/v1/licenses
        """
        return self._c.request("GET", "/config/v1/licenses", params=None, json_body=None)

    def reset_highest_usage_metrics(self):
        """
        The highest historical number of concurrent connections will be reset to the current number.

        POST /config/v1/licenses/action/reset-highest-usage-metrics
        """
        return self._c.request("POST", "/config/v1/licenses/action/reset-highest-usage-metrics", params=None, json_body=None)

    def reset_named_user_metrics(self):
        """
        The highest historical number of named users will be reset to zero.

        POST /config/v1/licenses/action/reset-named-user-metrics
        """
        return self._c.request("POST", "/config/v1/licenses/action/reset-named-user-metrics", params=None, json_body=None)

    def set_license_mode(self, body: dict = None):
        """
        Set the License Mode

        POST /config/v1/licenses/action/set-mode
        """
        return self._c.request("POST", "/config/v1/licenses/action/set-mode", params=None, json_body=body)

    def validate_license_key(self, body: dict = None):
        """
        Validates the License Key

        POST /config/v1/licenses/action/validate
        """
        return self._c.request("POST", "/config/v1/licenses/action/validate", params=None, json_body=body)

    def list_local_access_groups(self):
        """
        Lists all local access groups.

        GET /config/v1/local-access-groups
        """
        return self._c.request("GET", "/config/v1/local-access-groups", params=None, json_body=None)

    def create_local_access_group(self, body: dict = None):
        """
        Creates local access group.

        POST /config/v1/local-access-groups
        """
        return self._c.request("POST", "/config/v1/local-access-groups", params=None, json_body=body)

    def delete_local_access_group(self, id):
        """
        Deletes a local access group.

        DELETE /config/v1/local-access-groups/{id}
        """
        return self._c.request("DELETE", f"/config/v1/local-access-groups/{id}", params=None, json_body=None)

    def get_local_access_group(self, id):
        """
        Retrieves a local access group.

        GET /config/v1/local-access-groups/{id}
        """
        return self._c.request("GET", f"/config/v1/local-access-groups/{id}", params=None, json_body=None)

    def collect(self, body: dict = None):
        """
        Sends the log collection request for the set of targets

        POST /config/v1/log-collector/action/collect
        """
        return self._c.request("POST", "/config/v1/log-collector/action/collect", params=None, json_body=body)

    def get_log_levels(self, component_id: str, component_type: str):
        """
        Fetches feature wise log level information for a component.

        GET /config/v1/log-collector/log-levels
        """
        params = {}
        if component_id is not None: params['component_id'] = component_id
        if component_type is not None: params['component_type'] = component_type
        return self._c.request("GET", "/config/v1/log-collector/log-levels", params=params, json_body=None)

    def set_log_levels(self, body: dict = None):
        """
        Updates feature specific log level for a component.

        PUT /config/v1/log-collector/log-levels
        """
        return self._c.request("PUT", "/config/v1/log-collector/log-levels", params=None, json_body=body)

    def list_log_collector_tasks(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists Log Collector task information

        GET /config/v1/log-collector/tasks
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/config/v1/log-collector/tasks", params=params, json_body=None)

    def clean(self, body: dict = None):
        """
        A finish acknowledgement to notify the connection server for cleanup of collect complete log bundles or to terminate the collect operation if is in progress of collecting logs bundle.

        POST /config/v1/log-collector/tasks/action/clean
        """
        return self._c.request("POST", "/config/v1/log-collector/tasks/action/clean", params=None, json_body=body)

    def generate_download_ur_ls(self, body: dict = None):
        """
        Retrieves Download URL for each of specified log collector task.

        POST /config/v1/log-collector/tasks/action/generate-download-urls
        """
        return self._c.request("POST", "/config/v1/log-collector/tasks/action/generate-download-urls", params=None, json_body=body)

    def purge(self, body: dict = None):
        """
        Purges the log collection bundle for the provided list of targets.

        POST /config/v1/log-collector/tasks/action/purge
        """
        return self._c.request("POST", "/config/v1/log-collector/tasks/action/purge", params=None, json_body=body)

    def list_message_clients(self):
        """
        Lists the message clients in the environment.

        GET /config/v1/message-clients
        """
        return self._c.request("GET", "/config/v1/message-clients", params=None, json_body=None)

    def create_message_client(self, body: dict = None):
        """
        Creates a Message Client.

        POST /config/v1/message-clients
        """
        return self._c.request("POST", "/config/v1/message-clients", params=None, json_body=body)

    def delete_message_client(self, id):
        """
        Deletes a message client.

        DELETE /config/v1/message-clients/{id}
        """
        return self._c.request("DELETE", f"/config/v1/message-clients/{id}", params=None, json_body=None)

    def get_message_client(self, id):
        """
        Retrieves a message client.

        GET /config/v1/message-clients/{id}
        """
        return self._c.request("GET", f"/config/v1/message-clients/{id}", params=None, json_body=None)

    def update_message_client(self, id, body: dict = None):
        """
        Updates message client.

        PUT /config/v1/message-clients/{id}
        """
        return self._c.request("PUT", f"/config/v1/message-clients/{id}", params=None, json_body=body)

    def delete_permissions(self, body: dict = None):
        """
        Deletes permissions in bulk.

        DELETE /config/v1/permissions
        """
        return self._c.request("DELETE", "/config/v1/permissions", params=None, json_body=body)

    def list_permissions(self, ids: str = None):
        """
        Lists all permissions.

        GET /config/v1/permissions
        """
        params = {}
        if ids is not None: params['ids'] = ids
        return self._c.request("GET", "/config/v1/permissions", params=params, json_body=None)

    def create_permissions(self, body: dict = None):
        """
        Creates permissions in bulk.

        POST /config/v1/permissions
        """
        return self._c.request("POST", "/config/v1/permissions", params=None, json_body=body)

    def get_permission(self, id):
        """
        Retrieves a permission.

        GET /config/v1/permissions/{id}
        """
        return self._c.request("GET", f"/config/v1/permissions/{id}", params=None, json_body=None)

    def get_pre_logon_settings(self):
        """
        Gets the pre logon settings.

        GET /config/v1/pre-logon-settings
        """
        return self._c.request("GET", "/config/v1/pre-logon-settings", params=None, json_body=None)

    def list_selectable_privileges(self):
        """
        Lists all selectable privileges.

        GET /config/v1/privileges
        """
        return self._c.request("GET", "/config/v1/privileges", params=None, json_body=None)

    def list_radius_authenticators(self):
        """
        Lists the configured RADIUS Authenticators.

        GET /config/v1/radius-authenticators
        """
        return self._c.request("GET", "/config/v1/radius-authenticators", params=None, json_body=None)

    def create_radius_authenticator(self, body: dict = None):
        """
        Creates a RADIUS Authenticator.

        POST /config/v1/radius-authenticators
        """
        return self._c.request("POST", "/config/v1/radius-authenticators", params=None, json_body=body)

    def delete_radius_authenticator(self, id):
        """
        Deletes the given RADIUS Authenticator.

        DELETE /config/v1/radius-authenticators/{id}
        """
        return self._c.request("DELETE", f"/config/v1/radius-authenticators/{id}", params=None, json_body=None)

    def get_radius_authenticator(self, id):
        """
        Retrieves information about a RADIUS Authenticator.

        GET /config/v1/radius-authenticators/{id}
        """
        return self._c.request("GET", f"/config/v1/radius-authenticators/{id}", params=None, json_body=None)

    def update_radius_authenticator(self, id, body: dict = None):
        """
        Updates the given RADIUS Authenticator.

        PUT /config/v1/radius-authenticators/{id}
        """
        return self._c.request("PUT", f"/config/v1/radius-authenticators/{id}", params=None, json_body=body)

    def register_rcx_client(self, body: dict = None):
        """
        Registers the RCX client

        POST /config/v1/rcx/clients
        """
        return self._c.request("POST", "/config/v1/rcx/clients", params=None, json_body=body)

    def unregister_rcx_client(self, id):
        """
        Unregisters the given RCX Client

        DELETE /config/v1/rcx/clients/{id}
        """
        return self._c.request("DELETE", f"/config/v1/rcx/clients/{id}", params=None, json_body=None)

    def update_rcx_client(self, id, body: dict = None):
        """
        Updates the given RCX client.

        PUT /config/v1/rcx/clients/{id}
        """
        return self._c.request("PUT", f"/config/v1/rcx/clients/{id}", params=None, json_body=body)

    def list_rcx_servers(self):
        """
        Lists RCX servers of the cluster.

        GET /config/v1/rcx/servers
        """
        return self._c.request("GET", "/config/v1/rcx/servers", params=None, json_body=None)

    def list_roles(self):
        """
        Lists all roles.

        GET /config/v1/roles
        """
        return self._c.request("GET", "/config/v1/roles", params=None, json_body=None)

    def create_role(self, body: dict = None):
        """
        Creates a role.

        POST /config/v1/roles
        """
        return self._c.request("POST", "/config/v1/roles", params=None, json_body=body)

    def delete_role(self, id):
        """
        Deletes a role.

        DELETE /config/v1/roles/{id}
        """
        return self._c.request("DELETE", f"/config/v1/roles/{id}", params=None, json_body=None)

    def get_role(self, id):
        """
        Retrieves a role.

        GET /config/v1/roles/{id}
        """
        return self._c.request("GET", f"/config/v1/roles/{id}", params=None, json_body=None)

    def update_role(self, id, body: dict = None):
        """
        Updates a role.

        PUT /config/v1/roles/{id}
        """
        return self._c.request("PUT", f"/config/v1/roles/{id}", params=None, json_body=body)

    def list_saml_authenticators(self):
        """
        Lists the configured SAML authenticators.

        GET /config/v1/saml-authenticators
        """
        return self._c.request("GET", "/config/v1/saml-authenticators", params=None, json_body=None)

    def create_saml_authenticator(self, body: dict = None):
        """
        Creates a SAML authenticator.

        POST /config/v1/saml-authenticators
        """
        return self._c.request("POST", "/config/v1/saml-authenticators", params=None, json_body=body)

    def validate_saml_certificate(self, body: dict = None):
        """
        Validates SAML Authenticator certificate.

        POST /config/v1/saml-authenticators/action/validate-certificate
        """
        return self._c.request("POST", "/config/v1/saml-authenticators/action/validate-certificate", params=None, json_body=body)

    def delete_saml_authenticator(self, id):
        """
        Deletes a SAML Authenticator.

        DELETE /config/v1/saml-authenticators/{id}
        """
        return self._c.request("DELETE", f"/config/v1/saml-authenticators/{id}", params=None, json_body=None)

    def get_saml_authenticator(self, id):
        """
        Retrieves information about a SAML authenticator.

        GET /config/v1/saml-authenticators/{id}
        """
        return self._c.request("GET", f"/config/v1/saml-authenticators/{id}", params=None, json_body=None)

    def update_saml_authenticator(self, id, body: dict = None):
        """
        Updates a SAML Authenticator.

        PUT /config/v1/saml-authenticators/{id}
        """
        return self._c.request("PUT", f"/config/v1/saml-authenticators/{id}", params=None, json_body=body)

    def associate_saml_authenticator_with_connection_servers(self, id, body: dict = None):
        """
        Associates SAML authenticator with multiple connection servers with specified state.

        POST /config/v1/saml-authenticators/{id}/action/associate-connection-servers
        """
        return self._c.request("POST", f"/config/v1/saml-authenticators/{id}/action/associate-connection-servers", params=None, json_body=body)

    def dissociate_saml_authenticator_with_connection_servers(self, id, body: dict = None):
        """
        Dissociate SAML authenticator with multiple connection servers.

        POST /config/v1/saml-authenticators/{id}/action/dissociate-connection-servers
        """
        return self._c.request("POST", f"/config/v1/saml-authenticators/{id}/action/dissociate-connection-servers", params=None, json_body=body)

    def list_secondary_credentials(self, owner_id: str):
        """
        List the configured Secondary Credentials for given user.

        GET /config/v1/secondary-credentials
        """
        params = {}
        if owner_id is not None: params['owner_id'] = owner_id
        return self._c.request("GET", "/config/v1/secondary-credentials", params=params, json_body=None)

    def create_secondary_credential(self, body: dict = None):
        """
        Creates secondary credential.

        POST /config/v1/secondary-credentials
        """
        return self._c.request("POST", "/config/v1/secondary-credentials", params=None, json_body=body)

    def delete_secondary_credential(self, id):
        """
        Deletes a secondary credential.

        DELETE /config/v1/secondary-credentials/{id}
        """
        return self._c.request("DELETE", f"/config/v1/secondary-credentials/{id}", params=None, json_body=None)

    def get_secondary_credentials(self, id):
        """
        Get the configured secondary credentials for given id.

        GET /config/v1/secondary-credentials/{id}
        """
        return self._c.request("GET", f"/config/v1/secondary-credentials/{id}", params=None, json_body=None)

    def updatepassword(self, id, body: dict = None):
        """
        Update password.

        POST /config/v1/secondary-credentials/{id}/action/update-password
        """
        return self._c.request("POST", f"/config/v1/secondary-credentials/{id}/action/update-password", params=None, json_body=body)

    def get_settings(self):
        """
        Retrieves the configuration settings.

        GET /config/v1/settings
        """
        return self._c.request("GET", "/config/v1/settings", params=None, json_body=None)

    def update_settings(self, body: dict = None):
        """
        Updates the configuration settings.

        PUT /config/v1/settings
        """
        return self._c.request("PUT", "/config/v1/settings", params=None, json_body=body)

    def get_agent_restriction_settings(self):
        """
        Retrieves the agent restriction settings.

        GET /config/v1/settings/agent-restriction-settings
        """
        return self._c.request("GET", "/config/v1/settings/agent-restriction-settings", params=None, json_body=None)

    def update_agent_restriction_settings(self, body: dict = None):
        """
        Updates the agent restriction settings.

        PUT /config/v1/settings/agent-restriction-settings
        """
        return self._c.request("PUT", "/config/v1/settings/agent-restriction-settings", params=None, json_body=body)

    def get_client_settings(self):
        """
        Retrieves the client settings.

        GET /config/v1/settings/client-settings
        """
        return self._c.request("GET", "/config/v1/settings/client-settings", params=None, json_body=None)

    def update_client_settings(self, body: dict = None):
        """
        Updates the client settings.

        PUT /config/v1/settings/client-settings
        """
        return self._c.request("PUT", "/config/v1/settings/client-settings", params=None, json_body=body)

    def get_feature_settings(self):
        """
        Retrieves the feature settings.

        GET /config/v1/settings/feature
        """
        return self._c.request("GET", "/config/v1/settings/feature", params=None, json_body=None)

    def update_feature_settings(self, body: dict = None):
        """
        Updates the feature settings.

        PUT /config/v1/settings/feature
        """
        return self._c.request("PUT", "/config/v1/settings/feature", params=None, json_body=body)

    def get_general_settings(self):
        """
        Retrieves the general settings.

        GET /config/v1/settings/general
        """
        return self._c.request("GET", "/config/v1/settings/general", params=None, json_body=None)

    def update_general_settings(self, body: dict = None):
        """
        Updates the general settings.

        PUT /config/v1/settings/general
        """
        return self._c.request("PUT", "/config/v1/settings/general", params=None, json_body=body)

    def get_security_settings(self):
        """
        Retrieves the security settings.

        GET /config/v1/settings/security
        """
        return self._c.request("GET", "/config/v1/settings/security", params=None, json_body=None)

    def update_security_settings(self, body: dict = None):
        """
        Updates the security settings.

        PUT /config/v1/settings/security
        """
        return self._c.request("PUT", "/config/v1/settings/security", params=None, json_body=body)

    def get_syslog(self):
        """
        Gets Syslog information

        GET /config/v1/syslog
        """
        return self._c.request("GET", "/config/v1/syslog", params=None, json_body=None)

    def update_syslog(self, body: dict = None):
        """
        Updates Syslog configuration.

        PUT /config/v1/syslog
        """
        return self._c.request("PUT", "/config/v1/syslog", params=None, json_body=body)

    def list_true_sso_connectors(self):
        """
        Lists the TrueSSO Connectors.

        GET /config/v1/true-sso
        """
        return self._c.request("GET", "/config/v1/true-sso", params=None, json_body=None)

    def create_true_sso_connector(self, body: dict = None):
        """
        Creates a TrueSSO Connector.

        POST /config/v1/true-sso
        """
        return self._c.request("POST", "/config/v1/true-sso", params=None, json_body=body)

    def list_enrollment_servers(self):
        """
        Lists the paired TrueSSO Enrollment Servers.

        GET /config/v1/true-sso-enrollment-servers
        """
        return self._c.request("GET", "/config/v1/true-sso-enrollment-servers", params=None, json_body=None)

    def add_enrollment_server(self, body: dict = None):
        """
        Add a TrueSSO Enrollment Server.

        POST /config/v1/true-sso-enrollment-servers
        """
        return self._c.request("POST", "/config/v1/true-sso-enrollment-servers", params=None, json_body=body)

    def remove_enrollment_server(self, id):
        """
        Removes a paired TrueSSO Enrollment Server.

        DELETE /config/v1/true-sso-enrollment-servers/{id}
        """
        return self._c.request("DELETE", f"/config/v1/true-sso-enrollment-servers/{id}", params=None, json_body=None)

    def get_enrollment_server(self, id):
        """
        Retrieves information about a paired TrueSSO Enrollment Server.

        GET /config/v1/true-sso-enrollment-servers/{id}
        """
        return self._c.request("GET", f"/config/v1/true-sso-enrollment-servers/{id}", params=None, json_body=None)

    def delete_true_sso_connector(self, id):
        """
        Deletes a TrueSSO Connector.

        DELETE /config/v1/true-sso/{id}
        """
        return self._c.request("DELETE", f"/config/v1/true-sso/{id}", params=None, json_body=None)

    def get_true_sso_connector(self, id):
        """
        Retrieves information about a requested TrueSSO Connector.

        GET /config/v1/true-sso/{id}
        """
        return self._c.request("GET", f"/config/v1/true-sso/{id}", params=None, json_body=None)

    def update_true_sso_connector(self, id, body: dict = None):
        """
        Updates a TrueSSO Connector.

        PUT /config/v1/true-sso/{id}
        """
        return self._c.request("PUT", f"/config/v1/true-sso/{id}", params=None, json_body=body)

    def list_uem_servers(self):
        """
        Lists the configured UEM servers.

        GET /config/v1/uem-servers
        """
        return self._c.request("GET", "/config/v1/uem-servers", params=None, json_body=None)

    def add_uem_server(self, body: dict = None):
        """
        Add the UEM Server

        POST /config/v1/uem-servers
        """
        return self._c.request("POST", "/config/v1/uem-servers", params=None, json_body=body)

    def delete_uem_server(self, id):
        """
        deletes the given UEM Server.

        DELETE /config/v1/uem-servers/{id}
        """
        return self._c.request("DELETE", f"/config/v1/uem-servers/{id}", params=None, json_body=None)

    def get_uem_server(self, id):
        """
        Retrieves information about UEM Server.

        GET /config/v1/uem-servers/{id}
        """
        return self._c.request("GET", f"/config/v1/uem-servers/{id}", params=None, json_body=None)

    def update_uem_server(self, id, body: dict = None):
        """
        Updates the given UEM Server.

        PUT /config/v1/uem-servers/{id}
        """
        return self._c.request("PUT", f"/config/v1/uem-servers/{id}", params=None, json_body=body)

    def list_unauthenticated_access_users(self):
        """
        Lists unauthenticated access users in the environment.

        GET /config/v1/unauthenticated-access-users
        """
        return self._c.request("GET", "/config/v1/unauthenticated-access-users", params=None, json_body=None)

    def create_unauthenticated_access_user(self, body: dict = None):
        """
        Creates a specified unauthenticated access user in the environment.

        POST /config/v1/unauthenticated-access-users
        """
        return self._c.request("POST", "/config/v1/unauthenticated-access-users", params=None, json_body=body)

    def delete_unauthenticated_access_user(self, id):
        """
        Deletes a specified unauthenticated access user in the environment.

        DELETE /config/v1/unauthenticated-access-users/{id}
        """
        return self._c.request("DELETE", f"/config/v1/unauthenticated-access-users/{id}", params=None, json_body=None)

    def get_unauthenticated_access_user(self, id):
        """
        Retrieves a specified unauthenticated access user in the environment.

        GET /config/v1/unauthenticated-access-users/{id}
        """
        return self._c.request("GET", f"/config/v1/unauthenticated-access-users/{id}", params=None, json_body=None)

    def update_unauthenticated_access_user(self, id, body: dict = None):
        """
        Updates a specified unauthenticated access user in the environment.

        PUT /config/v1/unauthenticated-access-users/{id}
        """
        return self._c.request("PUT", f"/config/v1/unauthenticated-access-users/{id}", params=None, json_body=body)

    def list_url_setting_info(self):
        """
        Lists the URL Setting Information.

        GET /config/v1/url-redirection
        """
        return self._c.request("GET", "/config/v1/url-redirection", params=None, json_body=None)

    def create_url_setting(self, body: dict = None):
        """
        Creates a URL Redirection setting

        POST /config/v1/url-redirection
        """
        return self._c.request("POST", "/config/v1/url-redirection", params=None, json_body=body)

    def delete_url_setting(self, id):
        """
        Delete the URL Setting Information.

        DELETE /config/v1/url-redirection/{id}
        """
        return self._c.request("DELETE", f"/config/v1/url-redirection/{id}", params=None, json_body=None)

    def get_url_setting_info(self, id):
        """
        Get the URL Setting Information.

        GET /config/v1/url-redirection/{id}
        """
        return self._c.request("GET", f"/config/v1/url-redirection/{id}", params=None, json_body=None)

    def update_url_setting(self, id, body: dict = None):
        """
        updates the URL Setting Information.

        PUT /config/v1/url-redirection/{id}
        """
        return self._c.request("PUT", f"/config/v1/url-redirection/{id}", params=None, json_body=body)

    def list_users_or_groups_global_summary(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists global summary info of users or groups.

        GET /config/v1/users-or-groups-global-summary
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/config/v1/users-or-groups-global-summary", params=params, json_body=None)

    def get_users_or_groups_global_summary(self, id):
        """
        Gets global summary info related to AD User or Group.

        GET /config/v1/users-or-groups-global-summary/{id}
        """
        return self._c.request("GET", f"/config/v1/users-or-groups-global-summary/{id}", params=None, json_body=None)

    def list_users_or_groups_local_summary(self, entitled_only: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists local summary info of users or groups.

        GET /config/v1/users-or-groups-local-summary
        """
        params = {}
        if entitled_only is not None: params['entitled_only'] = entitled_only
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/config/v1/users-or-groups-local-summary", params=params, json_body=None)

    def get_storage_details(self, body: dict = None):
        """
        Gets Storage Details Information.

        POST /config/v1/virtual-center/action/get-storage-details
        """
        return self._c.request("POST", "/config/v1/virtual-center/action/get-storage-details", params=None, json_body=body)

    def list_vc_info(self):
        """
        Lists Virtual Centers configured in the environment.

        GET /config/v1/virtual-centers
        """
        return self._c.request("GET", "/config/v1/virtual-centers", params=None, json_body=None)

    def validate_virtual_center_certificate(self, body: dict = None):
        """
        Validates Virtual Center certificate.

        POST /config/v1/virtual-centers/action/validate-certificate
        """
        return self._c.request("POST", "/config/v1/virtual-centers/action/validate-certificate", params=None, json_body=body)

    def mark_datastores_for_archival(self, id, host_or_cluster_id: str, body: dict = None):
        """
        Sets archival datastore paths for the vCenter.

        POST /config/v1/virtual-centers/{id}/action/mark-datastores-for-archival
        """
        params = {}
        if host_or_cluster_id is not None: params['host_or_cluster_id'] = host_or_cluster_id
        return self._c.request("POST", f"/config/v1/virtual-centers/{id}/action/mark-datastores-for-archival", params=params, json_body=body)

    def get_settings_v10(self):
        """
        Retrieves the configuration settings.

        GET /config/v10/settings
        """
        return self._c.request("GET", "/config/v10/settings", params=None, json_body=None)

    def update_settings_v10(self, body: dict = None):
        """
        Updates the configuration settings.

        PUT /config/v10/settings
        """
        return self._c.request("PUT", "/config/v10/settings", params=None, json_body=body)

    def get_settings_v11(self):
        """
        Retrieves the configuration settings.

        GET /config/v11/settings
        """
        return self._c.request("GET", "/config/v11/settings", params=None, json_body=None)

    def update_settings_v11(self, body: dict = None):
        """
        Updates the configuration settings.

        PUT /config/v11/settings
        """
        return self._c.request("PUT", "/config/v11/settings", params=None, json_body=body)

    def get_preferences_v2(self):
        """
        Gets Horizon Console preferences for the logged in administrator.

        GET /config/v2/admin-users-or-groups/preferences
        """
        return self._c.request("GET", "/config/v2/admin-users-or-groups/preferences", params=None, json_body=None)

    def update_preferences_v2(self, body: dict = None):
        """
        Updates the Horizon Console preferences for the logged in administrator.

        PUT /config/v2/admin-users-or-groups/preferences
        """
        return self._c.request("PUT", "/config/v2/admin-users-or-groups/preferences", params=None, json_body=body)

    def list_app_volumes_managers_v2(self):
        """
        Lists the configured app volumes managers.

        GET /config/v2/app-volumes-manager
        """
        return self._c.request("GET", "/config/v2/app-volumes-manager", params=None, json_body=None)

    def add_app_volumes_manager_v2(self, body: dict = None):
        """
        Add the app volumes manager.

        POST /config/v2/app-volumes-manager
        """
        return self._c.request("POST", "/config/v2/app-volumes-manager", params=None, json_body=body)

    def delete_app_volumes_manager_v2(self, id):
        """
        Deletes the given app volumes manager.

        DELETE /config/v2/app-volumes-manager/{id}
        """
        return self._c.request("DELETE", f"/config/v2/app-volumes-manager/{id}", params=None, json_body=None)

    def get_app_volumes_manager_v2(self, id):
        """
        Retrieves information about an app volumes manager.

        GET /config/v2/app-volumes-manager/{id}
        """
        return self._c.request("GET", f"/config/v2/app-volumes-manager/{id}", params=None, json_body=None)

    def update_app_volumes_manager_v2(self, id, body: dict = None):
        """
        Updates the given app volumes manager.

        PUT /config/v2/app-volumes-manager/{id}
        """
        return self._c.request("PUT", f"/config/v2/app-volumes-manager/{id}", params=None, json_body=body)

    def list_connection_servers_v2(self):
        """
        Lists the connection servers.

        GET /config/v2/connection-servers
        """
        return self._c.request("GET", "/config/v2/connection-servers", params=None, json_body=None)

    def list_certificate_infos_v2(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Retrieves the certificate details.

        GET /config/v2/connection-servers/certificates
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/config/v2/connection-servers/certificates", params=params, json_body=None)

    def get_connection_server_v2(self, id):
        """
        Retrieves information about a connection server.

        GET /config/v2/connection-servers/{id}
        """
        return self._c.request("GET", f"/config/v2/connection-servers/{id}", params=None, json_body=None)

    def update_connection_server_v2(self, id, body: dict = None):
        """
        Updates the settings of the given Connection Server.

        PUT /config/v2/connection-servers/{id}
        """
        return self._c.request("PUT", f"/config/v2/connection-servers/{id}", params=None, json_body=body)

    def get_environment_v2(self):
        """
        Retrieves the environment settings.

        GET /config/v2/environment-properties
        """
        return self._c.request("GET", "/config/v2/environment-properties", params=None, json_body=None)

    def get_event_database_v2(self):
        """
        Returns information about event database configuration.

        GET /config/v2/event-database
        """
        return self._c.request("GET", "/config/v2/event-database", params=None, json_body=None)

    def update_event_database_v2(self, body: dict = None):
        """
        Updates event database configuration.

        PUT /config/v2/event-database
        """
        return self._c.request("PUT", "/config/v2/event-database", params=None, json_body=body)

    def clear_event_database_v2(self):
        """
        Deletes event database configuration.

        POST /config/v2/event-database/action/clear
        """
        return self._c.request("POST", "/config/v2/event-database/action/clear", params=None, json_body=None)

    def validate_service_account(self, body: dict = None):
        """
        Validates service account credentials.

        POST /config/v2/event-database/action/validate-service-account
        """
        return self._c.request("POST", "/config/v2/event-database/action/validate-service-account", params=None, json_body=body)

    def list_federation_access_groups_v2(self):
        """
        Lists all federation access groups.

        GET /config/v2/federation-access-groups
        """
        return self._c.request("GET", "/config/v2/federation-access-groups", params=None, json_body=None)

    def get_federation_access_group_v2(self, id):
        """
        Retrieves a federation access group.

        GET /config/v2/federation-access-groups/{id}
        """
        return self._c.request("GET", f"/config/v2/federation-access-groups/{id}", params=None, json_body=None)

    def list_ic_domain_accounts_v2(self, page: str = None, size: str = None):
        """
        Lists instant clone domain accounts of the environment.

        GET /config/v2/ic-domain-accounts
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        return self._c.request("GET", "/config/v2/ic-domain-accounts", params=params, json_body=None)

    def get_ic_domain_account_v2(self, id):
        """
        Gets instant clone domain account.

        GET /config/v2/ic-domain-accounts/{id}
        """
        return self._c.request("GET", f"/config/v2/ic-domain-accounts/{id}", params=None, json_body=None)

    def list_jwt_authenticators_v2(self):
        """
        Lists the configured JWT authenticators.

        GET /config/v2/jwt-authenticators
        """
        return self._c.request("GET", "/config/v2/jwt-authenticators", params=None, json_body=None)

    def create_jwt_authenticator_v2(self, body: dict = None):
        """
        Creates a JWT authenticator.

        POST /config/v2/jwt-authenticators
        """
        return self._c.request("POST", "/config/v2/jwt-authenticators", params=None, json_body=body)

    def delete_jwt_authenticator_v2(self, id):
        """
        Deletes the given JWT authenticator.

        DELETE /config/v2/jwt-authenticators/{id}
        """
        return self._c.request("DELETE", f"/config/v2/jwt-authenticators/{id}", params=None, json_body=None)

    def get_jwt_authenticator_v2(self, id):
        """
        Retrieves information about the given JWT authenticator.

        GET /config/v2/jwt-authenticators/{id}
        """
        return self._c.request("GET", f"/config/v2/jwt-authenticators/{id}", params=None, json_body=None)

    def update_jwt_authenticator_v2(self, id, body: dict = None):
        """
        Updates the given JWT authenticator.

        PUT /config/v2/jwt-authenticators/{id}
        """
        return self._c.request("PUT", f"/config/v2/jwt-authenticators/{id}", params=None, json_body=body)

    def list_licenses_v2(self):
        """
        Lists all licenses.

        GET /config/v2/licenses
        """
        return self._c.request("GET", "/config/v2/licenses", params=None, json_body=None)

    def set_license_key(self, body: dict = None):
        """
        Set the License Key

        POST /config/v2/licenses
        """
        return self._c.request("POST", "/config/v2/licenses", params=None, json_body=body)

    def list_local_access_groups_v2(self):
        """
        Lists all local access groups.

        GET /config/v2/local-access-groups
        """
        return self._c.request("GET", "/config/v2/local-access-groups", params=None, json_body=None)

    def get_local_access_group_v2(self, id):
        """
        Retrieves a local access group.

        GET /config/v2/local-access-groups/{id}
        """
        return self._c.request("GET", f"/config/v2/local-access-groups/{id}", params=None, json_body=None)

    def delete_permissions_v2(self, body: dict = None):
        """
        Deletes permissions in bulk.

        DELETE /config/v2/permissions
        """
        return self._c.request("DELETE", "/config/v2/permissions", params=None, json_body=body)

    def list_permissions_v2(self, ids: str = None):
        """
        Lists all permissions.

        GET /config/v2/permissions
        """
        params = {}
        if ids is not None: params['ids'] = ids
        return self._c.request("GET", "/config/v2/permissions", params=params, json_body=None)

    def create_permissions_v2(self, body: dict = None):
        """
        Creates permissions in bulk.

        POST /config/v2/permissions
        """
        return self._c.request("POST", "/config/v2/permissions", params=None, json_body=body)

    def get_permission_v2(self, id):
        """
        Retrieves a permission.

        GET /config/v2/permissions/{id}
        """
        return self._c.request("GET", f"/config/v2/permissions/{id}", params=None, json_body=None)

    def list_saml_authenticators_v2(self):
        """
        Lists the configured SAML authenticators.

        GET /config/v2/saml-authenticators
        """
        return self._c.request("GET", "/config/v2/saml-authenticators", params=None, json_body=None)

    def create_saml_authenticator_v2(self, body: dict = None):
        """
        Creates a SAML authenticator.

        POST /config/v2/saml-authenticators
        """
        return self._c.request("POST", "/config/v2/saml-authenticators", params=None, json_body=body)

    def delete_saml_authenticator_v2(self, id):
        """
        Deletes a SAML Authenticator.

        DELETE /config/v2/saml-authenticators/{id}
        """
        return self._c.request("DELETE", f"/config/v2/saml-authenticators/{id}", params=None, json_body=None)

    def get_saml_authenticator_v2(self, id):
        """
        Retrieves information about a SAML authenticator.

        GET /config/v2/saml-authenticators/{id}
        """
        return self._c.request("GET", f"/config/v2/saml-authenticators/{id}", params=None, json_body=None)

    def update_saml_authenticator_v2(self, id, body: dict = None):
        """
        Updates a SAML Authenticator.

        PUT /config/v2/saml-authenticators/{id}
        """
        return self._c.request("PUT", f"/config/v2/saml-authenticators/{id}", params=None, json_body=body)

    def get_settings_v2(self):
        """
        Retrieves the configuration settings.

        GET /config/v2/settings
        """
        return self._c.request("GET", "/config/v2/settings", params=None, json_body=None)

    def update_settings_v2(self, body: dict = None):
        """
        Updates the configuration settings.

        PUT /config/v2/settings
        """
        return self._c.request("PUT", "/config/v2/settings", params=None, json_body=body)

    def get_client_settings_v2(self):
        """
        Retrieves the client settings.

        GET /config/v2/settings/client-settings
        """
        return self._c.request("GET", "/config/v2/settings/client-settings", params=None, json_body=None)

    def update_client_settings_v2(self, body: dict = None):
        """
        Updates the client settings.

        PUT /config/v2/settings/client-settings
        """
        return self._c.request("PUT", "/config/v2/settings/client-settings", params=None, json_body=body)

    def get_feature_settings_v2(self):
        """
        Retrieves the feature settings.

        GET /config/v2/settings/feature
        """
        return self._c.request("GET", "/config/v2/settings/feature", params=None, json_body=None)

    def update_feature_settings_v2(self, body: dict = None):
        """
        Updates the feature settings.

        PUT /config/v2/settings/feature
        """
        return self._c.request("PUT", "/config/v2/settings/feature", params=None, json_body=body)

    def get_general_settings_v2(self):
        """
        Retrieves the general settings.

        GET /config/v2/settings/general
        """
        return self._c.request("GET", "/config/v2/settings/general", params=None, json_body=None)

    def update_general_settings_v2(self, body: dict = None):
        """
        Updates the general settings.

        PUT /config/v2/settings/general
        """
        return self._c.request("PUT", "/config/v2/settings/general", params=None, json_body=body)

    def get_security_settings_v2(self):
        """
        Retrieves the security settings.

        GET /config/v2/settings/security
        """
        return self._c.request("GET", "/config/v2/settings/security", params=None, json_body=None)

    def list_users_or_groups_local_summary_v2(self, entitled_only: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists local summary info of users or groups.

        GET /config/v2/users-or-groups-local-summary
        """
        params = {}
        if entitled_only is not None: params['entitled_only'] = entitled_only
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/config/v2/users-or-groups-local-summary", params=params, json_body=None)

    def get_users_or_group_local_summary_v2(self, id):
        """
        Gets local summary info related to AD User or Group.

        GET /config/v2/users-or-groups-local-summary/{id}
        """
        return self._c.request("GET", f"/config/v2/users-or-groups-local-summary/{id}", params=None, json_body=None)

    def list_vc_info_v2(self):
        """
        Lists Virtual Centers configured in the environment.

        GET /config/v2/virtual-centers
        """
        return self._c.request("GET", "/config/v2/virtual-centers", params=None, json_body=None)

    def list_connection_servers_v3(self):
        """
        Lists the connection servers.

        GET /config/v3/connection-servers
        """
        return self._c.request("GET", "/config/v3/connection-servers", params=None, json_body=None)

    def get_connection_server_v3(self, id):
        """
        Retrieves information about a connection server.

        GET /config/v3/connection-servers/{id}
        """
        return self._c.request("GET", f"/config/v3/connection-servers/{id}", params=None, json_body=None)

    def update_connection_server_v3(self, id, body: dict = None):
        """
        Updates the settings of the given Connection Server.

        PUT /config/v3/connection-servers/{id}
        """
        return self._c.request("PUT", f"/config/v3/connection-servers/{id}", params=None, json_body=body)

    def get_environment_v3(self):
        """
        Retrieves the environment settings.

        GET /config/v3/environment-properties
        """
        return self._c.request("GET", "/config/v3/environment-properties", params=None, json_body=None)

    def list_licenses_v3(self):
        """
        Lists all licenses.

        GET /config/v3/licenses
        """
        return self._c.request("GET", "/config/v3/licenses", params=None, json_body=None)

    def set_license_key_v3(self, body: dict = None):
        """
        Set the License Key

        POST /config/v3/licenses
        """
        return self._c.request("POST", "/config/v3/licenses", params=None, json_body=body)

    def delete_permissions_v3(self, body: dict = None):
        """
        Deletes permissions in bulk.

        DELETE /config/v3/permissions
        """
        return self._c.request("DELETE", "/config/v3/permissions", params=None, json_body=body)

    def list_permissions_v3(self, ids: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists all permissions.

        GET /config/v3/permissions
        """
        params = {}
        if ids is not None: params['ids'] = ids
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/config/v3/permissions", params=params, json_body=None)

    def create_permissions_v3(self, body: dict = None):
        """
        Creates permissions in bulk.

        POST /config/v3/permissions
        """
        return self._c.request("POST", "/config/v3/permissions", params=None, json_body=body)

    def get_permission_v3(self, id):
        """
        Retrieves a permission.

        GET /config/v3/permissions/{id}
        """
        return self._c.request("GET", f"/config/v3/permissions/{id}", params=None, json_body=None)

    def list_saml_authenticators_v3(self):
        """
        Lists the configured SAML authenticators.

        GET /config/v3/saml-authenticators
        """
        return self._c.request("GET", "/config/v3/saml-authenticators", params=None, json_body=None)

    def create_saml_authenticator_v3(self, body: dict = None):
        """
        Creates a SAML authenticator.

        POST /config/v3/saml-authenticators
        """
        return self._c.request("POST", "/config/v3/saml-authenticators", params=None, json_body=body)

    def delete_saml_authenticator_v3(self, id):
        """
        Deletes a SAML Authenticator.

        DELETE /config/v3/saml-authenticators/{id}
        """
        return self._c.request("DELETE", f"/config/v3/saml-authenticators/{id}", params=None, json_body=None)

    def get_saml_authenticator_v3(self, id):
        """
        Retrieves information about a SAML authenticator.

        GET /config/v3/saml-authenticators/{id}
        """
        return self._c.request("GET", f"/config/v3/saml-authenticators/{id}", params=None, json_body=None)

    def update_saml_authenticator_v3(self, id, body: dict = None):
        """
        Updates a SAML Authenticator.

        PUT /config/v3/saml-authenticators/{id}
        """
        return self._c.request("PUT", f"/config/v3/saml-authenticators/{id}", params=None, json_body=body)

    def get_settings_v3(self):
        """
        Retrieves the configuration settings.

        GET /config/v3/settings
        """
        return self._c.request("GET", "/config/v3/settings", params=None, json_body=None)

    def update_settings_v3(self, body: dict = None):
        """
        Updates the configuration settings.

        PUT /config/v3/settings
        """
        return self._c.request("PUT", "/config/v3/settings", params=None, json_body=body)

    def get_feature_settings_v3(self):
        """
        Retrieves the feature settings.

        GET /config/v3/settings/feature
        """
        return self._c.request("GET", "/config/v3/settings/feature", params=None, json_body=None)

    def update_feature_settings_v3(self, body: dict = None):
        """
        Updates the feature settings.

        PUT /config/v3/settings/feature
        """
        return self._c.request("PUT", "/config/v3/settings/feature", params=None, json_body=body)

    def get_general_settings_v3(self):
        """
        Retrieves the general settings.

        GET /config/v3/settings/general
        """
        return self._c.request("GET", "/config/v3/settings/general", params=None, json_body=None)

    def update_general_settings_v3(self, body: dict = None):
        """
        Updates the general settings.

        PUT /config/v3/settings/general
        """
        return self._c.request("PUT", "/config/v3/settings/general", params=None, json_body=body)

    def get_security_settings_v3(self):
        """
        Retrieves the security settings.

        GET /config/v3/settings/security
        """
        return self._c.request("GET", "/config/v3/settings/security", params=None, json_body=None)

    def update_security_settings_v3(self, body: dict = None):
        """
        Updates the security settings.

        PUT /config/v3/settings/security
        """
        return self._c.request("PUT", "/config/v3/settings/security", params=None, json_body=body)

    def list_users_or_groups_local_summary_v3(self, entitled_only: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists local summary info of users or groups.

        GET /config/v3/users-or-groups-local-summary
        """
        params = {}
        if entitled_only is not None: params['entitled_only'] = entitled_only
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/config/v3/users-or-groups-local-summary", params=params, json_body=None)

    def get_users_or_group_local_summary_v3(self, id):
        """
        Gets local summary info related to AD User or Group.

        GET /config/v3/users-or-groups-local-summary/{id}
        """
        return self._c.request("GET", f"/config/v3/users-or-groups-local-summary/{id}", params=None, json_body=None)

    def list_vc_info_v3(self):
        """
        Lists Virtual Centers configured in the environment.

        GET /config/v3/virtual-centers
        """
        return self._c.request("GET", "/config/v3/virtual-centers", params=None, json_body=None)

    def create_virtual_center(self, body: dict = None):
        """
        Creates a virtual center

        POST /config/v3/virtual-centers
        """
        return self._c.request("POST", "/config/v3/virtual-centers", params=None, json_body=body)

    def remove_virtual_center(self, id):
        """
        Removes a Virtual Center from the server

        DELETE /config/v3/virtual-centers/{id}
        """
        return self._c.request("DELETE", f"/config/v3/virtual-centers/{id}", params=None, json_body=None)

    def get_virtual_center(self, id):
        """
        Gets Virtual Center Information.

        GET /config/v3/virtual-centers/{id}
        """
        return self._c.request("GET", f"/config/v3/virtual-centers/{id}", params=None, json_body=None)

    def update_virtual_center(self, id, body: dict = None):
        """
        Updates virtual center.

        PUT /config/v3/virtual-centers/{id}
        """
        return self._c.request("PUT", f"/config/v3/virtual-centers/{id}", params=None, json_body=body)

    def list_licenses_v4(self):
        """
        Lists all licenses.

        GET /config/v4/licenses
        """
        return self._c.request("GET", "/config/v4/licenses", params=None, json_body=None)

    def set_license_key_v4(self, body: dict = None):
        """
        Set the License Key

        POST /config/v4/licenses
        """
        return self._c.request("POST", "/config/v4/licenses", params=None, json_body=body)

    def get_settings_v4(self):
        """
        Retrieves the configuration settings.

        GET /config/v4/settings
        """
        return self._c.request("GET", "/config/v4/settings", params=None, json_body=None)

    def update_settings_v4(self, body: dict = None):
        """
        Updates the configuration settings.

        PUT /config/v4/settings
        """
        return self._c.request("PUT", "/config/v4/settings", params=None, json_body=body)

    def get_feature_settings_v4(self):
        """
        Retrieves the feature settings.

        GET /config/v4/settings/feature
        """
        return self._c.request("GET", "/config/v4/settings/feature", params=None, json_body=None)

    def update_feature_settings_v4(self, body: dict = None):
        """
        Updates the feature settings.

        PUT /config/v4/settings/feature
        """
        return self._c.request("PUT", "/config/v4/settings/feature", params=None, json_body=body)

    def get_general_settings_v4(self):
        """
        Retrieves the general settings.

        GET /config/v4/settings/general
        """
        return self._c.request("GET", "/config/v4/settings/general", params=None, json_body=None)

    def update_general_settings_v4(self, body: dict = None):
        """
        Updates the general settings.

        PUT /config/v4/settings/general
        """
        return self._c.request("PUT", "/config/v4/settings/general", params=None, json_body=body)

    def get_security_settings_v4(self):
        """
        Retrieves the security settings.

        GET /config/v4/settings/security
        """
        return self._c.request("GET", "/config/v4/settings/security", params=None, json_body=None)

    def update_security_settings_v4(self, body: dict = None):
        """
        Updates the security settings.

        PUT /config/v4/settings/security
        """
        return self._c.request("PUT", "/config/v4/settings/security", params=None, json_body=body)

    def list_users_or_groups_local_summary_v4(self, entitled_only: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists local summary info of users or groups.

        GET /config/v4/users-or-groups-local-summary
        """
        params = {}
        if entitled_only is not None: params['entitled_only'] = entitled_only
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/config/v4/users-or-groups-local-summary", params=params, json_body=None)

    def get_users_or_group_local_summary_v4(self, id):
        """
        Gets local summary info related to AD User or Group.

        GET /config/v4/users-or-groups-local-summary/{id}
        """
        return self._c.request("GET", f"/config/v4/users-or-groups-local-summary/{id}", params=None, json_body=None)

    def list_vc_info_v4(self):
        """
        Lists Virtual Centers configured in the environment.

        GET /config/v4/virtual-centers
        """
        return self._c.request("GET", "/config/v4/virtual-centers", params=None, json_body=None)

    def create_virtual_center_v4(self, body: dict = None):
        """
        Creates a virtual center

        POST /config/v4/virtual-centers
        """
        return self._c.request("POST", "/config/v4/virtual-centers", params=None, json_body=body)

    def get_virtual_center_v4(self, id):
        """
        Gets Virtual Center Information.

        GET /config/v4/virtual-centers/{id}
        """
        return self._c.request("GET", f"/config/v4/virtual-centers/{id}", params=None, json_body=None)

    def update_virtual_center_v4(self, id, body: dict = None):
        """
        Updates virtual center.

        PUT /config/v4/virtual-centers/{id}
        """
        return self._c.request("PUT", f"/config/v4/virtual-centers/{id}", params=None, json_body=body)

    def get_settings_v5(self):
        """
        Retrieves the configuration settings.

        GET /config/v5/settings
        """
        return self._c.request("GET", "/config/v5/settings", params=None, json_body=None)

    def update_settings_v5(self, body: dict = None):
        """
        Updates the configuration settings.

        PUT /config/v5/settings
        """
        return self._c.request("PUT", "/config/v5/settings", params=None, json_body=body)

    def get_feature_settings_v5(self):
        """
        Retrieves the feature settings.

        GET /config/v5/settings/feature
        """
        return self._c.request("GET", "/config/v5/settings/feature", params=None, json_body=None)

    def update_feature_settings_v5(self, body: dict = None):
        """
        Updates the feature settings.

        PUT /config/v5/settings/feature
        """
        return self._c.request("PUT", "/config/v5/settings/feature", params=None, json_body=body)

    def get_general_settings_v5(self):
        """
        Retrieves the general settings.

        GET /config/v5/settings/general
        """
        return self._c.request("GET", "/config/v5/settings/general", params=None, json_body=None)

    def update_general_settings_v5(self, body: dict = None):
        """
        Updates the general settings.

        PUT /config/v5/settings/general
        """
        return self._c.request("PUT", "/config/v5/settings/general", params=None, json_body=body)

    def get_security_settings_v5(self):
        """
        Retrieves the security settings.

        GET /config/v5/settings/security
        """
        return self._c.request("GET", "/config/v5/settings/security", params=None, json_body=None)

    def update_security_settings_v5(self, body: dict = None):
        """
        Updates the security settings.

        PUT /config/v5/settings/security
        """
        return self._c.request("PUT", "/config/v5/settings/security", params=None, json_body=body)

    def list_users_or_groups_local_summary_v5(self, entitled_only: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists local summary info of users or groups.

        GET /config/v5/users-or-groups-local-summary
        """
        params = {}
        if entitled_only is not None: params['entitled_only'] = entitled_only
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/config/v5/users-or-groups-local-summary", params=params, json_body=None)

    def get_users_or_group_local_summary_v5(self, id):
        """
        Gets local summary info related to AD User or Group.

        GET /config/v5/users-or-groups-local-summary/{id}
        """
        return self._c.request("GET", f"/config/v5/users-or-groups-local-summary/{id}", params=None, json_body=None)

    def list_vc_info_v5(self):
        """
        Lists Virtual Centers configured in the environment.

        GET /config/v5/virtual-centers
        """
        return self._c.request("GET", "/config/v5/virtual-centers", params=None, json_body=None)

    def create_virtual_center_v5(self, body: dict = None):
        """
        Creates a virtual center

        POST /config/v5/virtual-centers
        """
        return self._c.request("POST", "/config/v5/virtual-centers", params=None, json_body=body)

    def remove_virtual_center_v5(self, id):
        """
        Removes a Virtual Center from the server

        DELETE /config/v5/virtual-centers/{id}
        """
        return self._c.request("DELETE", f"/config/v5/virtual-centers/{id}", params=None, json_body=None)

    def get_virtual_center_v5(self, id):
        """
        Gets Virtual Center Information.

        GET /config/v5/virtual-centers/{id}
        """
        return self._c.request("GET", f"/config/v5/virtual-centers/{id}", params=None, json_body=None)

    def update_virtual_center_v5(self, id, body: dict = None):
        """
        Updates virtual center.

        PUT /config/v5/virtual-centers/{id}
        """
        return self._c.request("PUT", f"/config/v5/virtual-centers/{id}", params=None, json_body=body)

    def get_settings_v6(self):
        """
        Retrieves the configuration settings.

        GET /config/v6/settings
        """
        return self._c.request("GET", "/config/v6/settings", params=None, json_body=None)

    def update_settings_v6(self, body: dict = None):
        """
        Updates the configuration settings.

        PUT /config/v6/settings
        """
        return self._c.request("PUT", "/config/v6/settings", params=None, json_body=body)

    def get_general_settings_v6(self):
        """
        Retrieves the general settings.

        GET /config/v6/settings/general
        """
        return self._c.request("GET", "/config/v6/settings/general", params=None, json_body=None)

    def update_general_settings_v6(self, body: dict = None):
        """
        Updates the general settings.

        PUT /config/v6/settings/general
        """
        return self._c.request("PUT", "/config/v6/settings/general", params=None, json_body=body)

    def get_security_settings_v6(self):
        """
        Retrieves the security settings.

        GET /config/v6/settings/security
        """
        return self._c.request("GET", "/config/v6/settings/security", params=None, json_body=None)

    def update_security_settings_v6(self, body: dict = None):
        """
        Updates the security settings.

        PUT /config/v6/settings/security
        """
        return self._c.request("PUT", "/config/v6/settings/security", params=None, json_body=body)

    def list_vc_info_v6(self):
        """
        Lists Virtual Centers configured in the environment.

        GET /config/v6/virtual-centers
        """
        return self._c.request("GET", "/config/v6/virtual-centers", params=None, json_body=None)

    def get_settings_v7(self):
        """
        Retrieves the configuration settings.

        GET /config/v7/settings
        """
        return self._c.request("GET", "/config/v7/settings", params=None, json_body=None)

    def update_settings_v7(self, body: dict = None):
        """
        Updates the configuration settings.

        PUT /config/v7/settings
        """
        return self._c.request("PUT", "/config/v7/settings", params=None, json_body=body)

    def get_general_settings_v7(self):
        """
        Retrieves the general settings.

        GET /config/v7/settings/general
        """
        return self._c.request("GET", "/config/v7/settings/general", params=None, json_body=None)

    def update_general_settings_v7(self, body: dict = None):
        """
        Updates the general settings.

        PUT /config/v7/settings/general
        """
        return self._c.request("PUT", "/config/v7/settings/general", params=None, json_body=body)

    def get_settings_v8(self):
        """
        Retrieves the configuration settings.

        GET /config/v8/settings
        """
        return self._c.request("GET", "/config/v8/settings", params=None, json_body=None)

    def update_settings_v8(self, body: dict = None):
        """
        Updates the configuration settings.

        PUT /config/v8/settings
        """
        return self._c.request("PUT", "/config/v8/settings", params=None, json_body=body)

    def get_settings_v9(self):
        """
        Retrieves the configuration settings.

        GET /config/v9/settings
        """
        return self._c.request("GET", "/config/v9/settings", params=None, json_body=None)

    def update_settings_v9(self, body: dict = None):
        """
        Updates the configuration settings.

        PUT /config/v9/settings
        """
        return self._c.request("PUT", "/config/v9/settings", params=None, json_body=body)
