# Copyright 2026 Abhilash Jha
# SPDX-License-Identifier: Apache-2.0

"""Auth API – auto-generated from Omnissa Horizon Server Swagger v2603."""
from typing import TYPE_CHECKING, Dict, Any, Optional, List

if TYPE_CHECKING:
    from omnissa_horizon.client import HorizonClient


class AuthAPI:
    """APIs for Auth (tag: Auth)."""

    def __init__(self, client: "HorizonClient"):
        self._c = client

    def key_agreement(self, body: dict = None):
        """
        Uses Diffie-Hellman algorithm to achieve encryption key agreement between client and server, which then can be used to encrypt and decrypt sensitive information.

        POST /key-agreement
        """
        return self._c.request("POST", "/key-agreement", params=None, json_body=body)

    def authenticate_smart_card(self, client_reference_id: str = None):
        """
        Logs in a user with smart card. Returns access and refresh tokens.

        GET /login
        """
        params = {}
        if client_reference_id is not None: params['client_reference_id'] = client_reference_id
        return self._c.request("GET", "/login", params=params, json_body=None)

    def login_user(self, body: dict = None, client_reference_id: str = None):
        """
        Logs in a user. Returns access token and refresh token.

        POST /login
        """
        params = {}
        if client_reference_id is not None: params['client_reference_id'] = client_reference_id
        return self._c.request("POST", "/login", params=params, json_body=body)

    def logout_user(self, body: dict = None):
        """
        Logs out a user.

        POST /logout
        """
        return self._c.request("POST", "/logout", params=None, json_body=body)

    def refresh_access_token(self, body: dict = None):
        """
        Refreshes access token from refresh token.

        POST /refresh
        """
        return self._c.request("POST", "/refresh", params=None, json_body=body)
