# Copyright 2026 Abhilash Jha
# SPDX-License-Identifier: Apache-2.0

"""Inventory API – auto-generated from Omnissa Horizon Server Swagger v2603."""
from typing import TYPE_CHECKING, Dict, Any, Optional, List

if TYPE_CHECKING:
    from omnissa_horizon.client import HorizonClient


class InventoryAPI:
    """APIs for Inventory (tag: Inventory)."""

    def __init__(self, client: "HorizonClient"):
        self._c = client

    def list_agent_installer_packages(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists agent installer packages.

        GET /inventory/v1/agent-installer-packages
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v1/agent-installer-packages", params=params, json_body=None)

    def register_agent_installer_package(self, body: dict = None):
        """
        Registers an agent installer package.

        POST /inventory/v1/agent-installer-packages/action/register
        """
        return self._c.request("POST", "/inventory/v1/agent-installer-packages/action/register", params=None, json_body=body)

    def get_agent_installer_package(self, id):
        """
        Retrieves an agent installer package.

        GET /inventory/v1/agent-installer-packages/{id}
        """
        return self._c.request("GET", f"/inventory/v1/agent-installer-packages/{id}", params=None, json_body=None)

    def unregister_agent_installer_package(self, id):
        """
        Unregisters an agent installer package.

        POST /inventory/v1/agent-installer-packages/{id}/action/unregister
        """
        return self._c.request("POST", f"/inventory/v1/agent-installer-packages/{id}/action/unregister", params=None, json_body=None)

    def list_application_icons(self, application_pool_id: str, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the application icons for the given application pool.

        GET /inventory/v1/application-icons
        """
        params = {}
        if application_pool_id is not None: params['application_pool_id'] = application_pool_id
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v1/application-icons", params=params, json_body=None)

    def create_application_icon(self, body: dict = None):
        """
        Creates an application icon.

        POST /inventory/v1/application-icons
        """
        return self._c.request("POST", "/inventory/v1/application-icons", params=None, json_body=body)

    def list_custom_application_icons(self, page: str = None, size: str = None):
        """
        Lists the custom application icons.

        GET /inventory/v1/application-icons/custom-icons
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        return self._c.request("GET", "/inventory/v1/application-icons/custom-icons", params=params, json_body=None)

    def delete_application_icon(self, id):
        """
        Deletes customized application icon.

        DELETE /inventory/v1/application-icons/{id}
        """
        return self._c.request("DELETE", f"/inventory/v1/application-icons/{id}", params=None, json_body=None)

    def get_application_icon(self, id):
        """
        Gets application icon.

        GET /inventory/v1/application-icons/{id}
        """
        return self._c.request("GET", f"/inventory/v1/application-icons/{id}", params=None, json_body=None)

    def list_application_pools(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the application pools in the environment.

        GET /inventory/v1/application-pools
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v1/application-pools", params=params, json_body=None)

    def create_application_pool(self, body: dict = None):
        """
        Creates an application pool.

        POST /inventory/v1/application-pools
        """
        return self._c.request("POST", "/inventory/v1/application-pools", params=None, json_body=body)

    def application_icon_bulk_associate(self, body: dict = None):
        """
        Associates a custom icon to given list of application pools.

        POST /inventory/v1/application-pools/action/associate
        """
        return self._c.request("POST", "/inventory/v1/application-pools/action/associate", params=None, json_body=body)

    def check_application_pool_name_availability(self, body: dict = None):
        """
        Checks if the given name is available for application pool creation.

        POST /inventory/v1/application-pools/action/check-name-availability
        """
        return self._c.request("POST", "/inventory/v1/application-pools/action/check-name-availability", params=None, json_body=body)

    def disable_application_pools(self, body: dict = None):
        """
        Disables the given list of application pool ids.

        POST /inventory/v1/application-pools/action/disable
        """
        return self._c.request("POST", "/inventory/v1/application-pools/action/disable", params=None, json_body=body)

    def enable_application_pools(self, body: dict = None):
        """
        Enables the given list of application pool ids.

        POST /inventory/v1/application-pools/action/enable
        """
        return self._c.request("POST", "/inventory/v1/application-pools/action/enable", params=None, json_body=body)

    def migrate_application_pools(self, target_farm_id: str, body: dict = None, source_farm_id: str = None):
        """
        Migrates the list of application pools to another farm

        POST /inventory/v1/application-pools/action/migrate
        """
        params = {}
        if target_farm_id is not None: params['target_farm_id'] = target_farm_id
        if source_farm_id is not None: params['source_farm_id'] = source_farm_id
        return self._c.request("POST", "/inventory/v1/application-pools/action/migrate", params=params, json_body=body)

    def application_icon_bulk_remove_association(self, body: dict = None):
        """
        Removes custom icon association from given list of application pools.

        POST /inventory/v1/application-pools/action/remove-association
        """
        return self._c.request("POST", "/inventory/v1/application-pools/action/remove-association", params=None, json_body=body)

    def update_allowed_access_path_app_pools(self, body: dict = None):
        """
        Updates allowed access path for the given list of application pool ids.

        POST /inventory/v1/application-pools/action/update-allowed-access-path
        """
        return self._c.request("POST", "/inventory/v1/application-pools/action/update-allowed-access-path", params=None, json_body=body)

    def delete_application_pool(self, id):
        """
        Deletes application pool.

        DELETE /inventory/v1/application-pools/{id}
        """
        return self._c.request("DELETE", f"/inventory/v1/application-pools/{id}", params=None, json_body=None)

    def get_application_pool(self, id):
        """
        Gets application pool.

        GET /inventory/v1/application-pools/{id}
        """
        return self._c.request("GET", f"/inventory/v1/application-pools/{id}", params=None, json_body=None)

    def update_application_pool(self, id, body: dict = None):
        """
        Updates application pool.

        PUT /inventory/v1/application-pools/{id}
        """
        return self._c.request("PUT", f"/inventory/v1/application-pools/{id}", params=None, json_body=body)

    def add_custom_icon(self, id, body: dict = None):
        """
        Associates a custom icon to the application pool.

        POST /inventory/v1/application-pools/{id}/action/add-custom-icon
        """
        return self._c.request("POST", f"/inventory/v1/application-pools/{id}/action/add-custom-icon", params=None, json_body=body)

    def remove_custom_icon(self, id):
        """
        Removes the associated custom icon from the application pool.

        POST /inventory/v1/application-pools/{id}/action/remove-custom-icon
        """
        return self._c.request("POST", f"/inventory/v1/application-pools/{id}/action/remove-custom-icon", params=None, json_body=None)

    def list_category_folders(self):
        """
        Lists the category folders.

        GET /inventory/v1/category-folders
        """
        return self._c.request("GET", "/inventory/v1/category-folders", params=None, json_body=None)

    def list_cp_desktop_pools(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the capacity provider Desktop Pools in the environment.

        GET /inventory/v1/cp-desktop-pools
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v1/cp-desktop-pools", params=params, json_body=None)

    def create_cp_desktop_pool(self, body: dict = None):
        """
        Creates a capacity provider desktop pool.

        POST /inventory/v1/cp-desktop-pools
        """
        return self._c.request("POST", "/inventory/v1/cp-desktop-pools", params=None, json_body=body)

    def delete_cp_desktop_pool(self, id, body: dict = None, enforce_associated_session_check: str = None):
        """
        Deletes a capacity provider desktop pool.

        DELETE /inventory/v1/cp-desktop-pools/{id}
        """
        params = {}
        if enforce_associated_session_check is not None: params['enforce_associated_session_check'] = enforce_associated_session_check
        return self._c.request("DELETE", f"/inventory/v1/cp-desktop-pools/{id}", params=params, json_body=body)

    def get_cp_desktop_pool(self, id):
        """
        Gets the capacity provider Desktop Pool information.

        GET /inventory/v1/cp-desktop-pools/{id}
        """
        return self._c.request("GET", f"/inventory/v1/cp-desktop-pools/{id}", params=None, json_body=None)

    def update_cp_desktop_pool(self, id, body: dict = None):
        """
        Updates capacity provider desktop pool.

        PUT /inventory/v1/cp-desktop-pools/{id}
        """
        return self._c.request("PUT", f"/inventory/v1/cp-desktop-pools/{id}", params=None, json_body=body)

    def cancel_cp_scheduled_push_image(self, id):
        """
        Request the cancellation of the current scheduled push image operation or cancellation of promoted secondary image on the specified instant/linked clone desktop pool.

        POST /inventory/v1/cp-desktop-pools/{id}/action/cancel-scheduled-push-image
        """
        return self._c.request("POST", f"/inventory/v1/cp-desktop-pools/{id}/action/cancel-scheduled-push-image", params=None, json_body=None)

    def cp_desktop_pool_promote_pending_image(self, id):
        """
        Promotes pending image to current image in the desktop pool.

        POST /inventory/v1/cp-desktop-pools/{id}/action/promote-pending-image
        """
        return self._c.request("POST", f"/inventory/v1/cp-desktop-pools/{id}/action/promote-pending-image", params=None, json_body=None)

    def schedule_cp_push_image(self, id, body: dict = None):
        """
        Schedule/reschedule a request to update the image in an automated desktop pool.

        POST /inventory/v1/cp-desktop-pools/{id}/action/schedule-push-image
        """
        return self._c.request("POST", f"/inventory/v1/cp-desktop-pools/{id}/action/schedule-push-image", params=None, json_body=body)

    def list_cp_farms(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Farms in the environment.

        GET /inventory/v1/cp-farms
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v1/cp-farms", params=params, json_body=None)

    def create_cp_farm(self, body: dict = None):
        """
        Creates a farm.

        POST /inventory/v1/cp-farms
        """
        return self._c.request("POST", "/inventory/v1/cp-farms", params=None, json_body=body)

    def disable_farms(self, body: dict = None):
        """
        Disables the given list of farm ids.

        POST /inventory/v1/cp-farms/action/disable
        """
        return self._c.request("POST", "/inventory/v1/cp-farms/action/disable", params=None, json_body=body)

    def disable_farm_provisioning(self, body: dict = None):
        """
        Disables provisioning for the given list of farm ids.

        POST /inventory/v1/cp-farms/action/disable-provisioning
        """
        return self._c.request("POST", "/inventory/v1/cp-farms/action/disable-provisioning", params=None, json_body=body)

    def enable_farms(self, body: dict = None):
        """
        Enables the given list of farm ids.

        POST /inventory/v1/cp-farms/action/enable
        """
        return self._c.request("POST", "/inventory/v1/cp-farms/action/enable", params=None, json_body=body)

    def enable_farm_provisioning(self, body: dict = None):
        """
        Enables provisioning for the given list of farm ids.

        POST /inventory/v1/cp-farms/action/enable-provisioning
        """
        return self._c.request("POST", "/inventory/v1/cp-farms/action/enable-provisioning", params=None, json_body=body)

    def delete_cp_farm(self, id):
        """
        Deletes a farm.

        DELETE /inventory/v1/cp-farms/{id}
        """
        return self._c.request("DELETE", f"/inventory/v1/cp-farms/{id}", params=None, json_body=None)

    def get_cp_farm(self, id):
        """
        Gets the Farm information.

        GET /inventory/v1/cp-farms/{id}
        """
        return self._c.request("GET", f"/inventory/v1/cp-farms/{id}", params=None, json_body=None)

    def update_cp_farm(self, id, body: dict = None):
        """
        Updates farm.

        PUT /inventory/v1/cp-farms/{id}
        """
        return self._c.request("PUT", f"/inventory/v1/cp-farms/{id}", params=None, json_body=body)

    def cp_farm_apply_image(self, id, body: dict = None, pending_image: str = None):
        """
        Applies the pending image or the current image to selected RDS servers in the farm.

        POST /inventory/v1/cp-farms/{id}/action/apply-image
        """
        params = {}
        if pending_image is not None: params['pending_image'] = pending_image
        return self._c.request("POST", f"/inventory/v1/cp-farms/{id}/action/apply-image", params=params, json_body=body)

    def cancel_cp_farm_scheduled_maintenance(self, id, body: dict = None):
        """
        Requests cancellation of the current scheduled maintenance on the specified farm.

        POST /inventory/v1/cp-farms/{id}/action/cancel-scheduled-maintenance
        """
        return self._c.request("POST", f"/inventory/v1/cp-farms/{id}/action/cancel-scheduled-maintenance", params=None, json_body=body)

    def cp_farm_promote_pending_image(self, id):
        """
        Promotes pending image to current image in the farm.

        POST /inventory/v1/cp-farms/{id}/action/promote-pending-image
        """
        return self._c.request("POST", f"/inventory/v1/cp-farms/{id}/action/promote-pending-image", params=None, json_body=None)

    def schedule_cp_farm_maintenance(self, id, body: dict = None):
        """
        Creates maintenance schedule for the specified farm.

        POST /inventory/v1/cp-farms/{id}/action/schedule-maintenance
        """
        return self._c.request("POST", f"/inventory/v1/cp-farms/{id}/action/schedule-maintenance", params=None, json_body=body)

    def list_desktop_pools(self):
        """
        Lists the Desktop Pools in the environment.

        GET /inventory/v1/desktop-pools
        """
        return self._c.request("GET", "/inventory/v1/desktop-pools", params=None, json_body=None)

    def create_desktop_pool(self, body: dict = None):
        """
        Creates a desktop pool.

        POST /inventory/v1/desktop-pools
        """
        return self._c.request("POST", "/inventory/v1/desktop-pools", params=None, json_body=body)

    def check_desktop_pool_name_availability(self, body: dict = None):
        """
        Checks if the given name is available for desktop pool creation.

        POST /inventory/v1/desktop-pools/action/check-name-availability
        """
        return self._c.request("POST", "/inventory/v1/desktop-pools/action/check-name-availability", params=None, json_body=body)

    def disable_desktop_pools(self, body: dict = None):
        """
        Disables the given list of desktop pool ids.

        POST /inventory/v1/desktop-pools/action/disable
        """
        return self._c.request("POST", "/inventory/v1/desktop-pools/action/disable", params=None, json_body=body)

    def disable_provisioning_for_desktop_pools(self, body: dict = None):
        """
        Disables provisioning for the given list of desktop pool ids.

        POST /inventory/v1/desktop-pools/action/disable-provisioning
        """
        return self._c.request("POST", "/inventory/v1/desktop-pools/action/disable-provisioning", params=None, json_body=body)

    def enable_desktop_pools(self, body: dict = None):
        """
        Enables the given list of desktop pool ids.

        POST /inventory/v1/desktop-pools/action/enable
        """
        return self._c.request("POST", "/inventory/v1/desktop-pools/action/enable", params=None, json_body=body)

    def enable_provisioning_for_desktop_pools(self, body: dict = None):
        """
        Enables provisioning for the given list of desktop pool ids.

        POST /inventory/v1/desktop-pools/action/enable-provisioning
        """
        return self._c.request("POST", "/inventory/v1/desktop-pools/action/enable-provisioning", params=None, json_body=body)

    def update_allowed_access_path_for_desktop_pools(self, body: dict = None):
        """
        Update allowed access path for the given list of desktop pool ids.

        POST /inventory/v1/desktop-pools/action/update-allowed-access-path
        """
        return self._c.request("POST", "/inventory/v1/desktop-pools/action/update-allowed-access-path", params=None, json_body=body)

    def validate_specified_names(self, body: dict = None):
        """
        Validates manually specified virtual machines. Ensures machine and user names are valid and aren't duplicated in the given desktop pool.

        POST /inventory/v1/desktop-pools/action/validate-specified-names
        """
        return self._c.request("POST", "/inventory/v1/desktop-pools/action/validate-specified-names", params=None, json_body=body)

    def list_user_policies_overrides(self, desktop_pool_id: str = None, unentitled_policies: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Returns policy overrides for entitled or unentitled users.

        GET /inventory/v1/desktop-pools/policies/overrides
        """
        params = {}
        if desktop_pool_id is not None: params['desktop_pool_id'] = desktop_pool_id
        if unentitled_policies is not None: params['unentitled_policies'] = unentitled_policies
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v1/desktop-pools/policies/overrides", params=params, json_body=None)

    def delete_desktop_pool(self, id, body: dict = None, enforce_associated_session_check: str = None):
        """
        Deletes a desktop pool.

        DELETE /inventory/v1/desktop-pools/{id}
        """
        params = {}
        if enforce_associated_session_check is not None: params['enforce_associated_session_check'] = enforce_associated_session_check
        return self._c.request("DELETE", f"/inventory/v1/desktop-pools/{id}", params=params, json_body=body)

    def get_desktop_pool(self, id):
        """
        Gets the Desktop Pool information.

        GET /inventory/v1/desktop-pools/{id}
        """
        return self._c.request("GET", f"/inventory/v1/desktop-pools/{id}", params=None, json_body=None)

    def update_desktop_pool(self, id, body: dict = None):
        """
        Updates desktop pool.

        PUT /inventory/v1/desktop-pools/{id}
        """
        return self._c.request("PUT", f"/inventory/v1/desktop-pools/{id}", params=None, json_body=body)

    def add_machines(self, id, body: dict = None):
        """
        Adds machines to the given manual desktop pool.

        POST /inventory/v1/desktop-pools/{id}/action/add-machines
        """
        return self._c.request("POST", f"/inventory/v1/desktop-pools/{id}/action/add-machines", params=None, json_body=body)

    def add_machines_by_name(self, id, body: dict = None):
        """
        Adds the named machines to the given desktop pool.

        POST /inventory/v1/desktop-pools/{id}/action/add-machines-by-name
        """
        return self._c.request("POST", f"/inventory/v1/desktop-pools/{id}/action/add-machines-by-name", params=None, json_body=body)

    def desktop_pool_apply_image(self, id, body: dict = None, pending_image: str = None):
        """
        Applies the pending image or the current image to selected machines in the desktop pool.

        POST /inventory/v1/desktop-pools/{id}/action/apply-image
        """
        params = {}
        if pending_image is not None: params['pending_image'] = pending_image
        return self._c.request("POST", f"/inventory/v1/desktop-pools/{id}/action/apply-image", params=params, json_body=body)

    def cancel_scheduled_push_image(self, id):
        """
        Request the cancellation of the current scheduled push image operation on the specified instant clone desktop pool.

        POST /inventory/v1/desktop-pools/{id}/action/cancel-scheduled-push-image
        """
        return self._c.request("POST", f"/inventory/v1/desktop-pools/{id}/action/cancel-scheduled-push-image", params=None, json_body=None)

    def desktop_pool_promote_pending_image(self, id):
        """
        Promotes pending image to current image in the desktop pool.

        POST /inventory/v1/desktop-pools/{id}/action/promote-pending-image
        """
        return self._c.request("POST", f"/inventory/v1/desktop-pools/{id}/action/promote-pending-image", params=None, json_body=None)

    def remove_machines(self, id, body: dict = None):
        """
        Removes machines from the given manual desktop pool.

        POST /inventory/v1/desktop-pools/{id}/action/remove-machines
        """
        return self._c.request("POST", f"/inventory/v1/desktop-pools/{id}/action/remove-machines", params=None, json_body=body)

    def schedule_push_image(self, id, body: dict = None):
        """
        Schedule/reschedule a request to update the image in an instant clone desktop pool.

        POST /inventory/v1/desktop-pools/{id}/action/schedule-push-image
        """
        return self._c.request("POST", f"/inventory/v1/desktop-pools/{id}/action/schedule-push-image", params=None, json_body=body)

    def validate_installed_applications_on_desktop_pool(self, id, body: dict = None):
        """
        Validates that each application in the given list is installed on the machines belonging to the specified desktop pool.

        POST /inventory/v1/desktop-pools/{id}/action/validate-installed-applications
        """
        return self._c.request("POST", f"/inventory/v1/desktop-pools/{id}/action/validate-installed-applications", params=None, json_body=body)

    def list_installed_applications_on_desktop_pool(self, id):
        """
        Lists the installed applications on the given desktop pool.

        GET /inventory/v1/desktop-pools/{id}/installed-applications
        """
        return self._c.request("GET", f"/inventory/v1/desktop-pools/{id}/installed-applications", params=None, json_body=None)

    def list_policies_on_desktop_pool(self, id):
        """
        Returns the policies on the given desktop pool.

        GET /inventory/v1/desktop-pools/{id}/policies
        """
        return self._c.request("GET", f"/inventory/v1/desktop-pools/{id}/policies", params=None, json_body=None)

    def updates_policies_on_desktop_pool(self, id, body: dict = None):
        """
        Updates the policies on the given desktop pool.

        PUT /inventory/v1/desktop-pools/{id}/policies
        """
        return self._c.request("PUT", f"/inventory/v1/desktop-pools/{id}/policies", params=None, json_body=body)

    def delete_policy_overrides_for_users(self, id, body: dict = None):
        """
        Deletes policies overrides for users on the given desktop pool.

        DELETE /inventory/v1/desktop-pools/{id}/policies/overrides
        """
        return self._c.request("DELETE", f"/inventory/v1/desktop-pools/{id}/policies/overrides", params=None, json_body=body)

    def create_policy_overrides_for_users(self, id, body: dict = None):
        """
        Creates policies overrides for users on the given desktop pool.

        POST /inventory/v1/desktop-pools/{id}/policies/overrides
        """
        return self._c.request("POST", f"/inventory/v1/desktop-pools/{id}/policies/overrides", params=None, json_body=body)

    def update_policy_overrides_for_users(self, id, body: dict = None):
        """
        Updates policies overrides for users on the given desktop pool.

        PUT /inventory/v1/desktop-pools/{id}/policies/overrides
        """
        return self._c.request("PUT", f"/inventory/v1/desktop-pools/{id}/policies/overrides", params=None, json_body=body)

    def list_desktop_pool_tasks(self, id):
        """
        Lists the tasks on the desktop pool.

        GET /inventory/v1/desktop-pools/{id}/tasks
        """
        return self._c.request("GET", f"/inventory/v1/desktop-pools/{id}/tasks", params=None, json_body=None)

    def get_desktop_pool_task(self, id, taskId):
        """
        Gets the task information on the desktop pool.

        GET /inventory/v1/desktop-pools/{id}/tasks/{taskId}
        """
        return self._c.request("GET", f"/inventory/v1/desktop-pools/{id}/tasks/{taskId}", params=None, json_body=None)

    def cancel_desktop_pool_task(self, id, taskId):
        """
        Cancels the instant clone desktop pool push image task.

        POST /inventory/v1/desktop-pools/{id}/tasks/{taskId}/action/cancel
        """
        return self._c.request("POST", f"/inventory/v1/desktop-pools/{id}/tasks/{taskId}/action/cancel", params=None, json_body=None)

    def pause_desktop_pool_task(self, id, taskId):
        """
        Pause the instant clone desktop pool push image task.

        POST /inventory/v1/desktop-pools/{id}/tasks/{taskId}/action/pause
        """
        return self._c.request("POST", f"/inventory/v1/desktop-pools/{id}/tasks/{taskId}/action/pause", params=None, json_body=None)

    def resume_desktop_pool_task(self, id, taskId, body: dict = None):
        """
        Resume the instant clone desktop pool push image task.

        POST /inventory/v1/desktop-pools/{id}/tasks/{taskId}/action/resume
        """
        return self._c.request("POST", f"/inventory/v1/desktop-pools/{id}/tasks/{taskId}/action/resume", params=None, json_body=body)

    def list_farms(self):
        """
        Lists the Farms in the environment.

        GET /inventory/v1/farms
        """
        return self._c.request("GET", "/inventory/v1/farms", params=None, json_body=None)

    def create_farm(self, body: dict = None):
        """
        Creates a farm.

        POST /inventory/v1/farms
        """
        return self._c.request("POST", "/inventory/v1/farms", params=None, json_body=body)

    def check_farm_name_availability(self, body: dict = None):
        """
        Checks if the given name is available for farm creation.

        POST /inventory/v1/farms/action/check-name-availability
        """
        return self._c.request("POST", "/inventory/v1/farms/action/check-name-availability", params=None, json_body=body)

    def delete_farm(self, id):
        """
        Deletes a farm.

        DELETE /inventory/v1/farms/{id}
        """
        return self._c.request("DELETE", f"/inventory/v1/farms/{id}", params=None, json_body=None)

    def get_farm(self, id):
        """
        Gets the Farm information.

        GET /inventory/v1/farms/{id}
        """
        return self._c.request("GET", f"/inventory/v1/farms/{id}", params=None, json_body=None)

    def update_farm(self, id, body: dict = None):
        """
        Updates farm.

        PUT /inventory/v1/farms/{id}
        """
        return self._c.request("PUT", f"/inventory/v1/farms/{id}", params=None, json_body=body)

    def add_rds_servers(self, id, body: dict = None):
        """
        Add RDS servers to the specified manual farm.

        POST /inventory/v1/farms/{id}/action/add-rds-servers
        """
        return self._c.request("POST", f"/inventory/v1/farms/{id}/action/add-rds-servers", params=None, json_body=body)

    def farm_apply_image(self, id, body: dict = None, pending_image: str = None):
        """
        Applies the pending image or the current image to selected RDS servers in the farm.

        POST /inventory/v1/farms/{id}/action/apply-image
        """
        params = {}
        if pending_image is not None: params['pending_image'] = pending_image
        return self._c.request("POST", f"/inventory/v1/farms/{id}/action/apply-image", params=params, json_body=body)

    def cancel_scheduled_maintenance(self, id, body: dict = None):
        """
        Requests cancellation of the current scheduled maintenance on the specified Instant Clone farm.

        POST /inventory/v1/farms/{id}/action/cancel-scheduled-maintenance
        """
        return self._c.request("POST", f"/inventory/v1/farms/{id}/action/cancel-scheduled-maintenance", params=None, json_body=body)

    def farm_promote_pending_image(self, id):
        """
        Promotes pending image to current image in the farm.

        POST /inventory/v1/farms/{id}/action/promote-pending-image
        """
        return self._c.request("POST", f"/inventory/v1/farms/{id}/action/promote-pending-image", params=None, json_body=None)

    def remove_rds_servers(self, id, body: dict = None):
        """
        Remove RDS servers from the specified farm.

        POST /inventory/v1/farms/{id}/action/remove-rds-servers
        """
        return self._c.request("POST", f"/inventory/v1/farms/{id}/action/remove-rds-servers", params=None, json_body=body)

    def schedule_maintenance(self, id, body: dict = None):
        """
        Creates maintenance schedule for the specified farm.

        POST /inventory/v1/farms/{id}/action/schedule-maintenance
        """
        return self._c.request("POST", f"/inventory/v1/farms/{id}/action/schedule-maintenance", params=None, json_body=body)

    def validate_installed_applications_on_farm(self, id, body: dict = None):
        """
        Validates that each application in the given list is installed on the RDS Servers belonging to the specified Farm.

        POST /inventory/v1/farms/{id}/action/validate-installed-applications
        """
        return self._c.request("POST", f"/inventory/v1/farms/{id}/action/validate-installed-applications", params=None, json_body=body)

    def list_app_volumes_applications_on_farm(self, id):
        """
        Lists the App Volumes applications on the given farm.

        GET /inventory/v1/farms/{id}/app-volumes-applications
        """
        return self._c.request("GET", f"/inventory/v1/farms/{id}/app-volumes-applications", params=None, json_body=None)

    def list_installed_applications_on_farm(self, id):
        """
        Lists the installed applications on the given farm.

        GET /inventory/v1/farms/{id}/installed-applications
        """
        return self._c.request("GET", f"/inventory/v1/farms/{id}/installed-applications", params=None, json_body=None)

    def list_global_application_entitlements(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Global Application Entitlements in the environment.

        GET /inventory/v1/global-application-entitlements
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v1/global-application-entitlements", params=params, json_body=None)

    def create_global_application_entitlement(self, body: dict = None):
        """
        Creates a Global Application Entitlement.

        POST /inventory/v1/global-application-entitlements
        """
        return self._c.request("POST", "/inventory/v1/global-application-entitlements", params=None, json_body=body)

    def delete_global_application_entitlement(self, id):
        """
        Deletes a Global Application Entitlement.

        DELETE /inventory/v1/global-application-entitlements/{id}
        """
        return self._c.request("DELETE", f"/inventory/v1/global-application-entitlements/{id}", params=None, json_body=None)

    def get_global_application_entitlement(self, id):
        """
        Gets the Global Application Entitlement in the environment.

        GET /inventory/v1/global-application-entitlements/{id}
        """
        return self._c.request("GET", f"/inventory/v1/global-application-entitlements/{id}", params=None, json_body=None)

    def update_global_application_entitlement(self, id, body: dict = None):
        """
        Updates a Global Application Entitlement.

        PUT /inventory/v1/global-application-entitlements/{id}
        """
        return self._c.request("PUT", f"/inventory/v1/global-application-entitlements/{id}", params=None, json_body=body)

    def list_compatible_backup_ga_es(self, id):
        """
        Lists the Global Application Entitlements that can be associated as backup Global Application Entitlement.

        GET /inventory/v1/global-application-entitlements/{id}/compatible-backup-global-application-entitlements
        """
        return self._c.request("GET", f"/inventory/v1/global-application-entitlements/{id}/compatible-backup-global-application-entitlements", params=None, json_body=None)

    def list_compatible_local_application_pools(self, id):
        """
        Lists Local Application Pools which are compatible with Global Application Entitlement.

        GET /inventory/v1/global-application-entitlements/{id}/compatible-local-application-pools
        """
        return self._c.request("GET", f"/inventory/v1/global-application-entitlements/{id}/compatible-local-application-pools", params=None, json_body=None)

    def remove_local_application_pools_from_gae(self, id, body: dict = None):
        """
        Removes Local Application Pools from Global Application Entitlement.

        DELETE /inventory/v1/global-application-entitlements/{id}/local-application-pools
        """
        return self._c.request("DELETE", f"/inventory/v1/global-application-entitlements/{id}/local-application-pools", params=None, json_body=body)

    def list_local_application_pools(self, id):
        """
        Lists Local Application Pools which are assigned to Global Application Entitlement.

        GET /inventory/v1/global-application-entitlements/{id}/local-application-pools
        """
        return self._c.request("GET", f"/inventory/v1/global-application-entitlements/{id}/local-application-pools", params=None, json_body=None)

    def add_local_application_pools_to_gae(self, id, body: dict = None):
        """
        Adds Local Application Pools to Global Application Entitlement.

        POST /inventory/v1/global-application-entitlements/{id}/local-application-pools
        """
        return self._c.request("POST", f"/inventory/v1/global-application-entitlements/{id}/local-application-pools", params=None, json_body=body)

    def list_global_desktop_entitlements(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Global Desktop Entitlements in the environment.

        GET /inventory/v1/global-desktop-entitlements
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v1/global-desktop-entitlements", params=params, json_body=None)

    def create_global_desktop_entitlement(self, body: dict = None):
        """
        Creates a Global Desktop Entitlement.

        POST /inventory/v1/global-desktop-entitlements
        """
        return self._c.request("POST", "/inventory/v1/global-desktop-entitlements", params=None, json_body=body)

    def delete_global_desktop_entitlement(self, id):
        """
        Deletes a Global Desktop Entitlement.

        DELETE /inventory/v1/global-desktop-entitlements/{id}
        """
        return self._c.request("DELETE", f"/inventory/v1/global-desktop-entitlements/{id}", params=None, json_body=None)

    def get_global_desktop_entitlement(self, id):
        """
        Gets the Global Desktop Entitlement in the environment.

        GET /inventory/v1/global-desktop-entitlements/{id}
        """
        return self._c.request("GET", f"/inventory/v1/global-desktop-entitlements/{id}", params=None, json_body=None)

    def update_global_desktop_entitlement(self, id, body: dict = None):
        """
        Updates a Global Desktop Entitlement.

        PUT /inventory/v1/global-desktop-entitlements/{id}
        """
        return self._c.request("PUT", f"/inventory/v1/global-desktop-entitlements/{id}", params=None, json_body=body)

    def list_compatible_backup_gd_es(self, id):
        """
        Lists the Global Desktop Entitlements that can be associated as backup Global Desktop Entitlement.

        GET /inventory/v1/global-desktop-entitlements/{id}/compatible-backup-global-desktop-entitlements
        """
        return self._c.request("GET", f"/inventory/v1/global-desktop-entitlements/{id}/compatible-backup-global-desktop-entitlements", params=None, json_body=None)

    def list_compatible_local_desktop_pools(self, id):
        """
        Lists Local Desktop Pools which are compatible with Global Desktop Entitlement.

        GET /inventory/v1/global-desktop-entitlements/{id}/compatible-local-desktop-pools
        """
        return self._c.request("GET", f"/inventory/v1/global-desktop-entitlements/{id}/compatible-local-desktop-pools", params=None, json_body=None)

    def remove_local_desktop_pools_from_gde(self, id, body: dict = None):
        """
        Removes Local Desktop Pools from Global Desktop Entitlement.

        DELETE /inventory/v1/global-desktop-entitlements/{id}/local-desktop-pools
        """
        return self._c.request("DELETE", f"/inventory/v1/global-desktop-entitlements/{id}/local-desktop-pools", params=None, json_body=body)

    def list_local_desktop_pools(self, id):
        """
        Lists Local Desktop Pools which are assigned to Global Desktop Entitlement.

        GET /inventory/v1/global-desktop-entitlements/{id}/local-desktop-pools
        """
        return self._c.request("GET", f"/inventory/v1/global-desktop-entitlements/{id}/local-desktop-pools", params=None, json_body=None)

    def add_local_desktop_pools_to_gde(self, id, body: dict = None):
        """
        Adds Local Desktop Pools to Global Desktop Entitlement.

        POST /inventory/v1/global-desktop-entitlements/{id}/local-desktop-pools
        """
        return self._c.request("POST", f"/inventory/v1/global-desktop-entitlements/{id}/local-desktop-pools", params=None, json_body=body)

    def query_global_sessions(self, user_id: str = None, pod_id: str = None, brokering_pod_id: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists global sessions in the environment for the given user, pod or brokering pod.

        GET /inventory/v1/global-sessions
        """
        params = {}
        if user_id is not None: params['user_id'] = user_id
        if pod_id is not None: params['pod_id'] = pod_id
        if brokering_pod_id is not None: params['brokering_pod_id'] = brokering_pod_id
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v1/global-sessions", params=params, json_body=None)

    def disconnect_global_sessions(self, body: dict = None):
        """
        Disconnects global sessions in the environment.

        POST /inventory/v1/global-sessions/action/disconnect
        """
        return self._c.request("POST", "/inventory/v1/global-sessions/action/disconnect", params=None, json_body=body)

    def log_off_global_sessions(self, body: dict = None, forced: str = None):
        """
        Logs off global sessions in the environment.

        POST /inventory/v1/global-sessions/action/logoff
        """
        params = {}
        if forced is not None: params['forced'] = forced
        return self._c.request("POST", "/inventory/v1/global-sessions/action/logoff", params=params, json_body=body)

    def reset_global_sessions(self, body: dict = None):
        """
        Resets machines of global sessions in the environment.

        POST /inventory/v1/global-sessions/action/reset
        """
        return self._c.request("POST", "/inventory/v1/global-sessions/action/reset", params=None, json_body=body)

    def restart_global_sessions(self, body: dict = None):
        """
        Restarts machines of global sessions in the environment.

        POST /inventory/v1/global-sessions/action/restart
        """
        return self._c.request("POST", "/inventory/v1/global-sessions/action/restart", params=None, json_body=body)

    def send_message_to_global_sessions(self, body: dict = None):
        """
        Sends message to global sessions in the environment.

        POST /inventory/v1/global-sessions/action/send-message
        """
        return self._c.request("POST", "/inventory/v1/global-sessions/action/send-message", params=None, json_body=body)

    def delete_machines(self, body: dict = None):
        """
        Deletes the specified machines.

        DELETE /inventory/v1/machines
        """
        return self._c.request("DELETE", "/inventory/v1/machines", params=None, json_body=body)

    def list_machines(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Machines in the environment.

        GET /inventory/v1/machines
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v1/machines", params=params, json_body=None)

    def archive_machines(self, body: dict = None):
        """
        Initiates machine archival process

        POST /inventory/v1/machines/action/archive
        """
        return self._c.request("POST", "/inventory/v1/machines/action/archive", params=None, json_body=body)

    def cancel_agent_upgrades(self, body: dict = None):
        """
        cancel agent upgrades.

        POST /inventory/v1/machines/action/cancel-agent-upgrade
        """
        return self._c.request("POST", "/inventory/v1/machines/action/cancel-agent-upgrade", params=None, json_body=body)

    def check_machine_prefix_availability(self, body: dict = None):
        """
        Checks if the given prefix is available for machine creation.

        POST /inventory/v1/machines/action/check-name-availability
        """
        return self._c.request("POST", "/inventory/v1/machines/action/check-name-availability", params=None, json_body=body)

    def enter_maintenance(self, body: dict = None, enforce: str = None):
        """
        Puts the machines into maintenance mode.

        POST /inventory/v1/machines/action/enter-maintenance
        """
        params = {}
        if enforce is not None: params['enforce'] = enforce
        return self._c.request("POST", "/inventory/v1/machines/action/enter-maintenance", params=params, json_body=body)

    def exit_maintenance(self, body: dict = None):
        """
        Puts the machines out of maintenance mode.

        POST /inventory/v1/machines/action/exit-maintenance
        """
        return self._c.request("POST", "/inventory/v1/machines/action/exit-maintenance", params=None, json_body=body)

    def rebuild_machines(self, body: dict = None):
        """
        Rebuilds the specified machines.

        POST /inventory/v1/machines/action/rebuild
        """
        return self._c.request("POST", "/inventory/v1/machines/action/rebuild", params=None, json_body=body)

    def recover_machines(self, body: dict = None, enforce: str = None):
        """
        Recovers the specified machines.

        POST /inventory/v1/machines/action/recover
        """
        params = {}
        if enforce is not None: params['enforce'] = enforce
        return self._c.request("POST", "/inventory/v1/machines/action/recover", params=params, json_body=body)

    def recreate_from_persistent_disk(self, body: dict = None):
        """
        Recreates machines from the specified persistent disks.

        POST /inventory/v1/machines/action/recreate-from-persistent-disk
        """
        return self._c.request("POST", "/inventory/v1/machines/action/recreate-from-persistent-disk", params=None, json_body=body)

    def reset_machines(self, body: dict = None, enforce: str = None):
        """
        Resets the specified machines.

        POST /inventory/v1/machines/action/reset
        """
        params = {}
        if enforce is not None: params['enforce'] = enforce
        return self._c.request("POST", "/inventory/v1/machines/action/reset", params=params, json_body=body)

    def restart_machines(self, body: dict = None, enforce: str = None):
        """
        Restarts the specified machines.

        POST /inventory/v1/machines/action/restart
        """
        params = {}
        if enforce is not None: params['enforce'] = enforce
        return self._c.request("POST", "/inventory/v1/machines/action/restart", params=params, json_body=body)

    def schedule_agent_for_upgrade(self, body: dict = None):
        """
        Schedule agents for upgrade.

        POST /inventory/v1/machines/action/schedule-agent-upgrade
        """
        return self._c.request("POST", "/inventory/v1/machines/action/schedule-agent-upgrade", params=None, json_body=body)

    def set_golden_image(self, body: dict = None):
        """
        Sets the given unmanaged machines as golden images

        POST /inventory/v1/machines/action/set-golden-image
        """
        return self._c.request("POST", "/inventory/v1/machines/action/set-golden-image", params=None, json_body=body)

    def shutdown_machines(self, body: dict = None, enforce: str = None):
        """
        Shutdown the specified machines.

        POST /inventory/v1/machines/action/shutdown
        """
        params = {}
        if enforce is not None: params['enforce'] = enforce
        return self._c.request("POST", "/inventory/v1/machines/action/shutdown", params=params, json_body=body)

    def list_agent_upgrade_tasks(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        List agent upgrade tasks information.

        GET /inventory/v1/machines/agent-upgrade-tasks
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v1/machines/agent-upgrade-tasks", params=params, json_body=None)

    def get_agent_upgrade_task(self, id):
        """
        Get agent upgrade task information.

        GET /inventory/v1/machines/agent-upgrade-tasks/{id}
        """
        return self._c.request("GET", f"/inventory/v1/machines/agent-upgrade-tasks/{id}", params=None, json_body=None)

    def list_unentitled_machines(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the unentitled machines in the environment.

        GET /inventory/v1/machines/unentitled
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v1/machines/unentitled", params=params, json_body=None)

    def delete_machine(self, id, body: dict = None):
        """
        Deletes the machine.

        DELETE /inventory/v1/machines/{id}
        """
        return self._c.request("DELETE", f"/inventory/v1/machines/{id}", params=None, json_body=body)

    def get_machine(self, id):
        """
        Gets the Machine information.

        GET /inventory/v1/machines/{id}
        """
        return self._c.request("GET", f"/inventory/v1/machines/{id}", params=None, json_body=None)

    def assign_machine_aliases(self, id, body: dict = None):
        """
        Assigns the specified aliases to the assigned users of the machine.

        POST /inventory/v1/machines/{id}/action/assign-aliases
        """
        return self._c.request("POST", f"/inventory/v1/machines/{id}/action/assign-aliases", params=None, json_body=body)

    def assign_users(self, id, body: dict = None):
        """
        Assigns the specified users to the machine.

        POST /inventory/v1/machines/{id}/action/assign-users
        """
        return self._c.request("POST", f"/inventory/v1/machines/{id}/action/assign-users", params=None, json_body=body)

    def attach_persistent_disk(self, id, body: dict = None):
        """
        Attaches the specified persistent disk to a machine.

        POST /inventory/v1/machines/{id}/action/attach-persistent-disk
        """
        return self._c.request("POST", f"/inventory/v1/machines/{id}/action/attach-persistent-disk", params=None, json_body=body)

    def detach_persistent_disk(self, id, body: dict = None):
        """
        Detaches the specified persistent disk from a machine.

        POST /inventory/v1/machines/{id}/action/detach-persistent-disk
        """
        return self._c.request("POST", f"/inventory/v1/machines/{id}/action/detach-persistent-disk", params=None, json_body=body)

    def unassign_machine_aliases(self, id, body: dict = None):
        """
        Un-assigns the aliases for the specified users from the machine.

        POST /inventory/v1/machines/{id}/action/unassign-aliases
        """
        return self._c.request("POST", f"/inventory/v1/machines/{id}/action/unassign-aliases", params=None, json_body=body)

    def unassign_users(self, id, body: dict = None):
        """
        Un-assigns the specified users from the machine.

        POST /inventory/v1/machines/{id}/action/unassign-users
        """
        return self._c.request("POST", f"/inventory/v1/machines/{id}/action/unassign-users", params=None, json_body=body)

    def list_persistent_disks(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists persistent disks.

        GET /inventory/v1/persistent-disks
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v1/persistent-disks", params=params, json_body=None)

    def create_persistent_disk(self, body: dict = None):
        """
        Creates a persistent disk.

        POST /inventory/v1/persistent-disks
        """
        return self._c.request("POST", "/inventory/v1/persistent-disks", params=None, json_body=body)

    def delete_persistent_disk(self, id):
        """
        Deletes persistent disk.

        DELETE /inventory/v1/persistent-disks/{id}
        """
        return self._c.request("DELETE", f"/inventory/v1/persistent-disks/{id}", params=None, json_body=None)

    def get_persistent_disk(self, id):
        """
        Retrieves information about a persistent disk.

        GET /inventory/v1/persistent-disks/{id}
        """
        return self._c.request("GET", f"/inventory/v1/persistent-disks/{id}", params=None, json_body=None)

    def update_persistent_disk(self, id, body: dict = None):
        """
        Updates persistent disk.

        PUT /inventory/v1/persistent-disks/{id}
        """
        return self._c.request("PUT", f"/inventory/v1/persistent-disks/{id}", params=None, json_body=body)

    def list_attachable_machines(self, id, filter_incompatible_machines: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists machines which can be attached to persistent disk.

        GET /inventory/v1/persistent-disks/{id}/attachable-machines
        """
        params = {}
        if filter_incompatible_machines is not None: params['filter_incompatible_machines'] = filter_incompatible_machines
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", f"/inventory/v1/persistent-disks/{id}/attachable-machines", params=params, json_body=None)

    def list_physical_machines(self, in_use: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Physical Machines in the environment.

        GET /inventory/v1/physical-machines
        """
        params = {}
        if in_use is not None: params['in_use'] = in_use
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v1/physical-machines", params=params, json_body=None)

    def register_physical_machine(self, body: dict = None):
        """
        Registers the Physical Machine.

        POST /inventory/v1/physical-machines/action/register
        """
        return self._c.request("POST", "/inventory/v1/physical-machines/action/register", params=None, json_body=body)

    def set_machine_as_golden_image(self, body: dict = None):
        """
        Sets the given unmanaged machines as golden images

        POST /inventory/v1/physical-machines/action/set-golden-image
        """
        return self._c.request("POST", "/inventory/v1/physical-machines/action/set-golden-image", params=None, json_body=body)

    def delete_physical_machine(self, id):
        """
        Deletes the Physical Machine.

        DELETE /inventory/v1/physical-machines/{id}
        """
        return self._c.request("DELETE", f"/inventory/v1/physical-machines/{id}", params=None, json_body=None)

    def get_physical_machine(self, id):
        """
        Gets the Physical Machine information.

        GET /inventory/v1/physical-machines/{id}
        """
        return self._c.request("GET", f"/inventory/v1/physical-machines/{id}", params=None, json_body=None)

    def list_rds_servers(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the RDS Servers in the environment.

        GET /inventory/v1/rds-servers
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v1/rds-servers", params=params, json_body=None)

    def cancel_rds_server_agent_upgrades(self, body: dict = None):
        """
        cancel agent upgrades.

        POST /inventory/v1/rds-servers/action/cancel-agent-upgrade
        """
        return self._c.request("POST", "/inventory/v1/rds-servers/action/cancel-agent-upgrade", params=None, json_body=body)

    def check_rds_server_prefix_availability(self, body: dict = None):
        """
        Checks if the given prefix is available for RDS Server creation.

        POST /inventory/v1/rds-servers/action/check-name-availability
        """
        return self._c.request("POST", "/inventory/v1/rds-servers/action/check-name-availability", params=None, json_body=body)

    def recover_rds_servers(self, body: dict = None):
        """
        Recovers the specified RDS Servers.

        POST /inventory/v1/rds-servers/action/recover
        """
        return self._c.request("POST", "/inventory/v1/rds-servers/action/recover", params=None, json_body=body)

    def register_rds_server(self, body: dict = None):
        """
        Registers the RDS Server.

        POST /inventory/v1/rds-servers/action/register
        """
        return self._c.request("POST", "/inventory/v1/rds-servers/action/register", params=None, json_body=body)

    def schedule_agent_for_upgrade_rds_server(self, body: dict = None):
        """
        Schedule agents for upgrade.

        POST /inventory/v1/rds-servers/action/schedule-agent-upgrade
        """
        return self._c.request("POST", "/inventory/v1/rds-servers/action/schedule-agent-upgrade", params=None, json_body=body)

    def list_rds_server_agent_upgrade_tasks(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        List agent upgrade tasks information.

        GET /inventory/v1/rds-servers/agent-upgrade-tasks
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v1/rds-servers/agent-upgrade-tasks", params=params, json_body=None)

    def get_rds_server_agent_upgrade_task(self, id):
        """
        Get agent upgrade task information.

        GET /inventory/v1/rds-servers/agent-upgrade-tasks/{id}
        """
        return self._c.request("GET", f"/inventory/v1/rds-servers/agent-upgrade-tasks/{id}", params=None, json_body=None)

    def delete_rds_server(self, id):
        """
        Deletes the RDS Server.

        DELETE /inventory/v1/rds-servers/{id}
        """
        return self._c.request("DELETE", f"/inventory/v1/rds-servers/{id}", params=None, json_body=None)

    def get_rds_server(self, id):
        """
        Gets the RDS Server information.

        GET /inventory/v1/rds-servers/{id}
        """
        return self._c.request("GET", f"/inventory/v1/rds-servers/{id}", params=None, json_body=None)

    def update_rds_server(self, id, body: dict = None):
        """
        Updates the RDS Server.

        PUT /inventory/v1/rds-servers/{id}
        """
        return self._c.request("PUT", f"/inventory/v1/rds-servers/{id}", params=None, json_body=body)

    def list_session_info(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the locally resourced Sessions in the environment

        GET /inventory/v1/sessions
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v1/sessions", params=params, json_body=None)

    def disconnect_sessions(self, body: dict = None):
        """
        Disconnects locally resourced user sessions.

        POST /inventory/v1/sessions/action/disconnect
        """
        return self._c.request("POST", "/inventory/v1/sessions/action/disconnect", params=None, json_body=body)

    def log_off_sessions(self, body: dict = None, forced: str = None):
        """
        Logs off locally resourced user sessions, if they are not locked.

        POST /inventory/v1/sessions/action/logoff
        """
        params = {}
        if forced is not None: params['forced'] = forced
        return self._c.request("POST", "/inventory/v1/sessions/action/logoff", params=params, json_body=body)

    def reset_sessions(self, body: dict = None):
        """
        Resets machine of locally resourced user sessions. The machine must be managed by Virtual Center and the session cannot be an application or an RDS desktop session.

        POST /inventory/v1/sessions/action/reset
        """
        return self._c.request("POST", "/inventory/v1/sessions/action/reset", params=None, json_body=body)

    def restart_sessions(self, body: dict = None):
        """
        Restarts machine of locally resourced user sessions. The machine must be managed by Virtual Center and the session cannot be an application or an RDS desktop session.

        POST /inventory/v1/sessions/action/restart
        """
        return self._c.request("POST", "/inventory/v1/sessions/action/restart", params=None, json_body=body)

    def send_message_to_sessions(self, body: dict = None):
        """
        Sends the message to locally resourced user sessions.

        POST /inventory/v1/sessions/action/send-message
        """
        return self._c.request("POST", "/inventory/v1/sessions/action/send-message", params=None, json_body=body)

    def get_session_info(self, id):
        """
        Gets the Session information for locally resourced session.

        GET /inventory/v1/sessions/{id}
        """
        return self._c.request("GET", f"/inventory/v1/sessions/{id}", params=None, json_body=None)

    def delete_application_pools_v10(self, body: dict = None):
        """
        Deletes the given application pools.

        DELETE /inventory/v10/application-pools
        """
        return self._c.request("DELETE", "/inventory/v10/application-pools", params=None, json_body=body)

    def list_application_pools_v10(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the application pools in the environment.

        GET /inventory/v10/application-pools
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v10/application-pools", params=params, json_body=None)

    def create_application_pool_v10(self, body: dict = None):
        """
        Creates an application pool.

        POST /inventory/v10/application-pools
        """
        return self._c.request("POST", "/inventory/v10/application-pools", params=None, json_body=body)

    def delete_application_pool_v10(self, id):
        """
        Deletes application pool.

        DELETE /inventory/v10/application-pools/{id}
        """
        return self._c.request("DELETE", f"/inventory/v10/application-pools/{id}", params=None, json_body=None)

    def get_application_pool_v10(self, id):
        """
        Gets application pool.

        GET /inventory/v10/application-pools/{id}
        """
        return self._c.request("GET", f"/inventory/v10/application-pools/{id}", params=None, json_body=None)

    def update_application_pool_v10(self, id, body: dict = None):
        """
        Updates application pool.

        PUT /inventory/v10/application-pools/{id}
        """
        return self._c.request("PUT", f"/inventory/v10/application-pools/{id}", params=None, json_body=body)

    def list_desktop_pools_v10(self, populate_additional_aws_fields: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the desktop pools in the environment.

        GET /inventory/v10/desktop-pools
        """
        params = {}
        if populate_additional_aws_fields is not None: params['populate_additional_aws_fields'] = populate_additional_aws_fields
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v10/desktop-pools", params=params, json_body=None)

    def create_desktop_pool_v10(self, body: dict = None):
        """
        Creates a desktop pool.

        POST /inventory/v10/desktop-pools
        """
        return self._c.request("POST", "/inventory/v10/desktop-pools", params=None, json_body=body)

    def delete_desktop_pool_v10(self, id, body: dict = None, enforce_associated_session_check: str = None):
        """
        Deletes a desktop pool.

        DELETE /inventory/v10/desktop-pools/{id}
        """
        params = {}
        if enforce_associated_session_check is not None: params['enforce_associated_session_check'] = enforce_associated_session_check
        return self._c.request("DELETE", f"/inventory/v10/desktop-pools/{id}", params=params, json_body=body)

    def get_desktop_pool_v10(self, id):
        """
        Gets the desktop pool information.

        GET /inventory/v10/desktop-pools/{id}
        """
        return self._c.request("GET", f"/inventory/v10/desktop-pools/{id}", params=None, json_body=None)

    def update_desktop_pool_v10(self, id, body: dict = None):
        """
        Updates desktop pool.

        PUT /inventory/v10/desktop-pools/{id}
        """
        return self._c.request("PUT", f"/inventory/v10/desktop-pools/{id}", params=None, json_body=body)

    def delete_machines_v10(self, body: dict = None):
        """
        Deletes the specified machines.

        DELETE /inventory/v10/machines
        """
        return self._c.request("DELETE", "/inventory/v10/machines", params=None, json_body=body)

    def list_machines_v10(self, group_id: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Machines in the environment.

        GET /inventory/v10/machines
        """
        params = {}
        if group_id is not None: params['group_id'] = group_id
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v10/machines", params=params, json_body=None)

    def delete_machine_v10(self, id, body: dict = None):
        """
        Deletes the machine.

        DELETE /inventory/v10/machines/{id}
        """
        return self._c.request("DELETE", f"/inventory/v10/machines/{id}", params=None, json_body=body)

    def get_machine_v10(self, id):
        """
        Gets the machine information.

        GET /inventory/v10/machines/{id}
        """
        return self._c.request("GET", f"/inventory/v10/machines/{id}", params=None, json_body=None)

    def list_desktop_pools_v11(self, populate_additional_aws_fields: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the desktop pools in the environment.

        GET /inventory/v11/desktop-pools
        """
        params = {}
        if populate_additional_aws_fields is not None: params['populate_additional_aws_fields'] = populate_additional_aws_fields
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v11/desktop-pools", params=params, json_body=None)

    def create_desktop_pool_v11(self, body: dict = None):
        """
        Creates a desktop pool.

        POST /inventory/v11/desktop-pools
        """
        return self._c.request("POST", "/inventory/v11/desktop-pools", params=None, json_body=body)

    def delete_desktop_pool_v11(self, id, body: dict = None, enforce_associated_session_check: str = None):
        """
        Deletes a desktop pool.

        DELETE /inventory/v11/desktop-pools/{id}
        """
        params = {}
        if enforce_associated_session_check is not None: params['enforce_associated_session_check'] = enforce_associated_session_check
        return self._c.request("DELETE", f"/inventory/v11/desktop-pools/{id}", params=params, json_body=body)

    def get_desktop_pool_v11(self, id):
        """
        Gets the desktop pool information.

        GET /inventory/v11/desktop-pools/{id}
        """
        return self._c.request("GET", f"/inventory/v11/desktop-pools/{id}", params=None, json_body=None)

    def update_desktop_pool_v11(self, id, body: dict = None):
        """
        Updates desktop pool.

        PUT /inventory/v11/desktop-pools/{id}
        """
        return self._c.request("PUT", f"/inventory/v11/desktop-pools/{id}", params=None, json_body=body)

    def list_desktop_pools_v12(self, populate_additional_aws_fields: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the desktop pools in the environment.

        GET /inventory/v12/desktop-pools
        """
        params = {}
        if populate_additional_aws_fields is not None: params['populate_additional_aws_fields'] = populate_additional_aws_fields
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v12/desktop-pools", params=params, json_body=None)

    def create_desktop_pool_v12(self, body: dict = None):
        """
        Creates a desktop pool.

        POST /inventory/v12/desktop-pools
        """
        return self._c.request("POST", "/inventory/v12/desktop-pools", params=None, json_body=body)

    def delete_desktop_pool_v12(self, id, body: dict = None, enforce_associated_session_check: str = None):
        """
        Deletes a desktop pool.

        DELETE /inventory/v12/desktop-pools/{id}
        """
        params = {}
        if enforce_associated_session_check is not None: params['enforce_associated_session_check'] = enforce_associated_session_check
        return self._c.request("DELETE", f"/inventory/v12/desktop-pools/{id}", params=params, json_body=body)

    def get_desktop_pool_v12(self, id):
        """
        Gets the desktop pool information.

        GET /inventory/v12/desktop-pools/{id}
        """
        return self._c.request("GET", f"/inventory/v12/desktop-pools/{id}", params=None, json_body=None)

    def update_desktop_pool_v12(self, id, body: dict = None):
        """
        Updates desktop pool.

        PUT /inventory/v12/desktop-pools/{id}
        """
        return self._c.request("PUT", f"/inventory/v12/desktop-pools/{id}", params=None, json_body=body)

    def list_agent_installer_packages_v2(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists agent installer packages.

        GET /inventory/v2/agent-installer-packages
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v2/agent-installer-packages", params=params, json_body=None)

    def register_agent_installer_package_v2(self, body: dict = None):
        """
        Registers an agent installer package.

        POST /inventory/v2/agent-installer-packages/action/register
        """
        return self._c.request("POST", "/inventory/v2/agent-installer-packages/action/register", params=None, json_body=body)

    def get_agent_installer_package_v2(self, id):
        """
        Retrieves an agent installer package.

        GET /inventory/v2/agent-installer-packages/{id}
        """
        return self._c.request("GET", f"/inventory/v2/agent-installer-packages/{id}", params=None, json_body=None)

    def list_application_pools_v2(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the application pools in the environment.

        GET /inventory/v2/application-pools
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v2/application-pools", params=params, json_body=None)

    def create_application_pool_v2(self, body: dict = None):
        """
        Creates an application pool.

        POST /inventory/v2/application-pools
        """
        return self._c.request("POST", "/inventory/v2/application-pools", params=None, json_body=body)

    def get_application_pool_v2(self, id):
        """
        Gets application pool.

        GET /inventory/v2/application-pools/{id}
        """
        return self._c.request("GET", f"/inventory/v2/application-pools/{id}", params=None, json_body=None)

    def update_application_pool_v2(self, id, body: dict = None):
        """
        Updates application pool.

        PUT /inventory/v2/application-pools/{id}
        """
        return self._c.request("PUT", f"/inventory/v2/application-pools/{id}", params=None, json_body=body)

    def list_cp_desktop_pools_v2(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the capacity provider Desktop Pools in the environment.

        GET /inventory/v2/cp-desktop-pools
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v2/cp-desktop-pools", params=params, json_body=None)

    def create_cp_desktop_pool_v2(self, body: dict = None):
        """
        Creates a capacity provider desktop pool.

        POST /inventory/v2/cp-desktop-pools
        """
        return self._c.request("POST", "/inventory/v2/cp-desktop-pools", params=None, json_body=body)

    def delete_cp_desktop_pool_v2(self, id, body: dict = None, enforce_associated_session_check: str = None):
        """
        Deletes a capacity provider desktop pool.

        DELETE /inventory/v2/cp-desktop-pools/{id}
        """
        params = {}
        if enforce_associated_session_check is not None: params['enforce_associated_session_check'] = enforce_associated_session_check
        return self._c.request("DELETE", f"/inventory/v2/cp-desktop-pools/{id}", params=params, json_body=body)

    def get_cp_desktop_pool_v2(self, id):
        """
        Gets the capacity provider Desktop Pool information.

        GET /inventory/v2/cp-desktop-pools/{id}
        """
        return self._c.request("GET", f"/inventory/v2/cp-desktop-pools/{id}", params=None, json_body=None)

    def update_cp_desktop_pool_v2(self, id, body: dict = None):
        """
        Updates capacity provider desktop pool.

        PUT /inventory/v2/cp-desktop-pools/{id}
        """
        return self._c.request("PUT", f"/inventory/v2/cp-desktop-pools/{id}", params=None, json_body=body)

    def list_cp_farms_v2(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Farms in the environment.

        GET /inventory/v2/cp-farms
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v2/cp-farms", params=params, json_body=None)

    def create_cp_farm_v2(self, body: dict = None):
        """
        Creates a farm.

        POST /inventory/v2/cp-farms
        """
        return self._c.request("POST", "/inventory/v2/cp-farms", params=None, json_body=body)

    def delete_cp_farm_v2(self, id):
        """
        Deletes a farm.

        DELETE /inventory/v2/cp-farms/{id}
        """
        return self._c.request("DELETE", f"/inventory/v2/cp-farms/{id}", params=None, json_body=None)

    def get_cp_farm2(self, id):
        """
        Gets the Farm information.

        GET /inventory/v2/cp-farms/{id}
        """
        return self._c.request("GET", f"/inventory/v2/cp-farms/{id}", params=None, json_body=None)

    def update_cp_farm2(self, id, body: dict = None):
        """
        Updates farm.

        PUT /inventory/v2/cp-farms/{id}
        """
        return self._c.request("PUT", f"/inventory/v2/cp-farms/{id}", params=None, json_body=body)

    def list_desktop_pools_v2(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the desktop pools in the environment.

        GET /inventory/v2/desktop-pools
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v2/desktop-pools", params=params, json_body=None)

    def create_desktop_pool_v2(self, body: dict = None):
        """
        Creates a desktop pool.

        POST /inventory/v2/desktop-pools
        """
        return self._c.request("POST", "/inventory/v2/desktop-pools", params=None, json_body=body)

    def list_user_policies_overrides_v2(self, desktop_pool_id: str = None, unentitled_policies: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Returns policy overrides for entitled or unentitled users.

        GET /inventory/v2/desktop-pools/policies/overrides
        """
        params = {}
        if desktop_pool_id is not None: params['desktop_pool_id'] = desktop_pool_id
        if unentitled_policies is not None: params['unentitled_policies'] = unentitled_policies
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v2/desktop-pools/policies/overrides", params=params, json_body=None)

    def get_desktop_pool_v2(self, id):
        """
        Gets the desktop pool information.

        GET /inventory/v2/desktop-pools/{id}
        """
        return self._c.request("GET", f"/inventory/v2/desktop-pools/{id}", params=None, json_body=None)

    def schedule_push_image_v2(self, id, body: dict = None):
        """
        Schedule/reschedule a request to update the image in an instant clone desktop pool.

        POST /inventory/v2/desktop-pools/{id}/action/schedule-push-image
        """
        return self._c.request("POST", f"/inventory/v2/desktop-pools/{id}/action/schedule-push-image", params=None, json_body=body)

    def list_farms_v2(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Farms in the environment.

        GET /inventory/v2/farms
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v2/farms", params=params, json_body=None)

    def create_farm_v2(self, body: dict = None):
        """
        Creates a farm.

        POST /inventory/v2/farms
        """
        return self._c.request("POST", "/inventory/v2/farms", params=None, json_body=body)

    def get_farm_v2(self, id):
        """
        Gets the Farm information.

        GET /inventory/v2/farms/{id}
        """
        return self._c.request("GET", f"/inventory/v2/farms/{id}", params=None, json_body=None)

    def update_farm_v2(self, id, body: dict = None):
        """
        Updates farm.

        PUT /inventory/v2/farms/{id}
        """
        return self._c.request("PUT", f"/inventory/v2/farms/{id}", params=None, json_body=body)

    def schedule_maintenance_v2(self, id, body: dict = None):
        """
        Creates maintenance schedule for the specified farm.

        POST /inventory/v2/farms/{id}/action/schedule-maintenance
        """
        return self._c.request("POST", f"/inventory/v2/farms/{id}/action/schedule-maintenance", params=None, json_body=body)

    def list_global_application_entitlements_v2(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Global Application Entitlements in the environment.

        GET /inventory/v2/global-application-entitlements
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v2/global-application-entitlements", params=params, json_body=None)

    def get_global_application_entitlement_v2(self, id):
        """
        Gets the Global Application Entitlement in the environment.

        GET /inventory/v2/global-application-entitlements/{id}
        """
        return self._c.request("GET", f"/inventory/v2/global-application-entitlements/{id}", params=None, json_body=None)

    def list_global_desktop_entitlements_v2(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Global Desktop Entitlements in the environment.

        GET /inventory/v2/global-desktop-entitlements
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v2/global-desktop-entitlements", params=params, json_body=None)

    def create_global_desktop_entitlement_v2(self, body: dict = None):
        """
        Creates a Global Desktop Entitlement.

        POST /inventory/v2/global-desktop-entitlements
        """
        return self._c.request("POST", "/inventory/v2/global-desktop-entitlements", params=None, json_body=body)

    def get_global_desktop_entitlement_v2(self, id):
        """
        Gets the Global Desktop Entitlement in the environment.

        GET /inventory/v2/global-desktop-entitlements/{id}
        """
        return self._c.request("GET", f"/inventory/v2/global-desktop-entitlements/{id}", params=None, json_body=None)

    def query_global_sessions_v2(self, user_id: str = None, pod_id: str = None, brokering_pod_id: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists global sessions in the environment for the given user, pod or brokering pod.

        GET /inventory/v2/global-sessions
        """
        params = {}
        if user_id is not None: params['user_id'] = user_id
        if pod_id is not None: params['pod_id'] = pod_id
        if brokering_pod_id is not None: params['brokering_pod_id'] = brokering_pod_id
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v2/global-sessions", params=params, json_body=None)

    def list_machines_v2(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Machines in the environment.

        GET /inventory/v2/machines
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v2/machines", params=params, json_body=None)

    def schedule_agent_for_upgrade_v2(self, body: dict = None):
        """
        Schedule agents for upgrade.

        POST /inventory/v2/machines/action/schedule-agent-upgrade
        """
        return self._c.request("POST", "/inventory/v2/machines/action/schedule-agent-upgrade", params=None, json_body=body)

    def list_agent_upgrade_tasks_v2(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        List agent upgrade tasks information.

        GET /inventory/v2/machines/agent-upgrade-tasks
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v2/machines/agent-upgrade-tasks", params=params, json_body=None)

    def get_agent_upgrade_task_v2(self, id):
        """
        Get agent upgrade task information.

        GET /inventory/v2/machines/agent-upgrade-tasks/{id}
        """
        return self._c.request("GET", f"/inventory/v2/machines/agent-upgrade-tasks/{id}", params=None, json_body=None)

    def get_machine_v2(self, id):
        """
        Gets the Machine information.

        GET /inventory/v2/machines/{id}
        """
        return self._c.request("GET", f"/inventory/v2/machines/{id}", params=None, json_body=None)

    def list_physical_machines_v2(self, in_use: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Physical Machines in the environment.

        GET /inventory/v2/physical-machines
        """
        params = {}
        if in_use is not None: params['in_use'] = in_use
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v2/physical-machines", params=params, json_body=None)

    def register_physical_machines_v2(self, body: dict = None):
        """
        Registers the Physical Machine.

        POST /inventory/v2/physical-machines/action/register
        """
        return self._c.request("POST", "/inventory/v2/physical-machines/action/register", params=None, json_body=body)

    def get_physical_machine_v2(self, id):
        """
        Gets the Physical Machine information.

        GET /inventory/v2/physical-machines/{id}
        """
        return self._c.request("GET", f"/inventory/v2/physical-machines/{id}", params=None, json_body=None)

    def list_rds_servers_v2(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the RDS Servers in the environment.

        GET /inventory/v2/rds-servers
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v2/rds-servers", params=params, json_body=None)

    def schedule_agent_for_upgrade_rds_server_v2(self, body: dict = None):
        """
        Schedule agents for upgrade.

        POST /inventory/v2/rds-servers/action/schedule-agent-upgrade
        """
        return self._c.request("POST", "/inventory/v2/rds-servers/action/schedule-agent-upgrade", params=None, json_body=body)

    def list_rds_server_agent_upgrade_tasks_v2(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        List agent upgrade tasks information.

        GET /inventory/v2/rds-servers/agent-upgrade-tasks
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v2/rds-servers/agent-upgrade-tasks", params=params, json_body=None)

    def get_rds_server_agent_upgrade_task_v2(self, id):
        """
        Get agent upgrade task information.

        GET /inventory/v2/rds-servers/agent-upgrade-tasks/{id}
        """
        return self._c.request("GET", f"/inventory/v2/rds-servers/agent-upgrade-tasks/{id}", params=None, json_body=None)

    def delete_rds_server_v2(self, id):
        """
        Deletes the RDS Server.

        DELETE /inventory/v2/rds-servers/{id}
        """
        return self._c.request("DELETE", f"/inventory/v2/rds-servers/{id}", params=None, json_body=None)

    def get_rds_server_v2(self, id):
        """
        Gets the RDS Server information.

        GET /inventory/v2/rds-servers/{id}
        """
        return self._c.request("GET", f"/inventory/v2/rds-servers/{id}", params=None, json_body=None)

    def update_rds_server_v2(self, id, body: dict = None):
        """
        Updates the RDS Server.

        PUT /inventory/v2/rds-servers/{id}
        """
        return self._c.request("PUT", f"/inventory/v2/rds-servers/{id}", params=None, json_body=body)

    def list_session_info_v2(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the locally resourced Sessions in the environment

        GET /inventory/v2/sessions
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v2/sessions", params=params, json_body=None)

    def list_agent_installer_packages_v3(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists agent installer packages.

        GET /inventory/v3/agent-installer-packages
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v3/agent-installer-packages", params=params, json_body=None)

    def get_agent_installer_package_v3(self, id):
        """
        Retrieves an agent installer package.

        GET /inventory/v3/agent-installer-packages/{id}
        """
        return self._c.request("GET", f"/inventory/v3/agent-installer-packages/{id}", params=None, json_body=None)

    def list_application_pools_v3(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the application pools in the environment.

        GET /inventory/v3/application-pools
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v3/application-pools", params=params, json_body=None)

    def create_application_pool_v3(self, body: dict = None):
        """
        Creates an application pool.

        POST /inventory/v3/application-pools
        """
        return self._c.request("POST", "/inventory/v3/application-pools", params=None, json_body=body)

    def get_application_pool_v3(self, id):
        """
        Gets application pool.

        GET /inventory/v3/application-pools/{id}
        """
        return self._c.request("GET", f"/inventory/v3/application-pools/{id}", params=None, json_body=None)

    def update_application_pool_v3(self, id, body: dict = None):
        """
        Updates application pool.

        PUT /inventory/v3/application-pools/{id}
        """
        return self._c.request("PUT", f"/inventory/v3/application-pools/{id}", params=None, json_body=body)

    def list_cp_desktop_pools_v3(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the capacity provider Desktop Pools in the environment.

        GET /inventory/v3/cp-desktop-pools
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v3/cp-desktop-pools", params=params, json_body=None)

    def create_cp_desktop_pool_v3(self, body: dict = None):
        """
        Creates a capacity provider desktop pool.

        POST /inventory/v3/cp-desktop-pools
        """
        return self._c.request("POST", "/inventory/v3/cp-desktop-pools", params=None, json_body=body)

    def delete_cp_desktop_pool_v3(self, id, body: dict = None, enforce_associated_session_check: str = None):
        """
        Deletes a capacity provider desktop pool.

        DELETE /inventory/v3/cp-desktop-pools/{id}
        """
        params = {}
        if enforce_associated_session_check is not None: params['enforce_associated_session_check'] = enforce_associated_session_check
        return self._c.request("DELETE", f"/inventory/v3/cp-desktop-pools/{id}", params=params, json_body=body)

    def get_cp_desktop_pool_v3(self, id):
        """
        Gets the capacity provider Desktop Pool information.

        GET /inventory/v3/cp-desktop-pools/{id}
        """
        return self._c.request("GET", f"/inventory/v3/cp-desktop-pools/{id}", params=None, json_body=None)

    def update_cp_desktop_pool_v3(self, id, body: dict = None):
        """
        Updates capacity provider desktop pool.

        PUT /inventory/v3/cp-desktop-pools/{id}
        """
        return self._c.request("PUT", f"/inventory/v3/cp-desktop-pools/{id}", params=None, json_body=body)

    def list_desktop_pools_v3(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the desktop pools in the environment.

        GET /inventory/v3/desktop-pools
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v3/desktop-pools", params=params, json_body=None)

    def get_desktop_pool_v3(self, id):
        """
        Gets the desktop pool information.

        GET /inventory/v3/desktop-pools/{id}
        """
        return self._c.request("GET", f"/inventory/v3/desktop-pools/{id}", params=None, json_body=None)

    def schedule_push_image_v3(self, id, body: dict = None):
        """
        Schedule/reschedule a request to update the image in an instant clone desktop pool.

        POST /inventory/v3/desktop-pools/{id}/action/schedule-push-image
        """
        return self._c.request("POST", f"/inventory/v3/desktop-pools/{id}/action/schedule-push-image", params=None, json_body=body)

    def list_farms_v3(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Farms in the environment.

        GET /inventory/v3/farms
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v3/farms", params=params, json_body=None)

    def create_farm_v3(self, body: dict = None):
        """
        Creates a farm.

        POST /inventory/v3/farms
        """
        return self._c.request("POST", "/inventory/v3/farms", params=None, json_body=body)

    def get_farm_v3(self, id):
        """
        Gets the Farm information.

        GET /inventory/v3/farms/{id}
        """
        return self._c.request("GET", f"/inventory/v3/farms/{id}", params=None, json_body=None)

    def update_farm_v3(self, id, body: dict = None):
        """
        Updates farm.

        PUT /inventory/v3/farms/{id}
        """
        return self._c.request("PUT", f"/inventory/v3/farms/{id}", params=None, json_body=body)

    def schedule_maintenance_v3(self, id, body: dict = None):
        """
        Creates maintenance schedule for the specified farm.

        POST /inventory/v3/farms/{id}/action/schedule-maintenance
        """
        return self._c.request("POST", f"/inventory/v3/farms/{id}/action/schedule-maintenance", params=None, json_body=body)

    def list_global_application_entitlements_v3(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Global Application Entitlements in the environment.

        GET /inventory/v3/global-application-entitlements
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v3/global-application-entitlements", params=params, json_body=None)

    def create_global_application_entitlement_v3(self, body: dict = None):
        """
        Creates a Global Application Entitlement.

        POST /inventory/v3/global-application-entitlements
        """
        return self._c.request("POST", "/inventory/v3/global-application-entitlements", params=None, json_body=body)

    def delete_global_application_entitlement_v3(self, id):
        """
        Deletes a Global Application Entitlement.

        DELETE /inventory/v3/global-application-entitlements/{id}
        """
        return self._c.request("DELETE", f"/inventory/v3/global-application-entitlements/{id}", params=None, json_body=None)

    def get_global_application_entitlement_v3(self, id):
        """
        Gets the Global Application Entitlement in the environment.

        GET /inventory/v3/global-application-entitlements/{id}
        """
        return self._c.request("GET", f"/inventory/v3/global-application-entitlements/{id}", params=None, json_body=None)

    def update_global_application_entitlement_v3(self, id, body: dict = None):
        """
        Updates a Global Application Entitlement.

        PUT /inventory/v3/global-application-entitlements/{id}
        """
        return self._c.request("PUT", f"/inventory/v3/global-application-entitlements/{id}", params=None, json_body=body)

    def list_global_desktop_entitlements_v3(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Global Desktop Entitlements in the environment.

        GET /inventory/v3/global-desktop-entitlements
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v3/global-desktop-entitlements", params=params, json_body=None)

    def create_global_desktop_entitlement_v3(self, body: dict = None):
        """
        Creates a Global Desktop Entitlement.

        POST /inventory/v3/global-desktop-entitlements
        """
        return self._c.request("POST", "/inventory/v3/global-desktop-entitlements", params=None, json_body=body)

    def delete_global_desktop_entitlement_v3(self, id):
        """
        Deletes a Global Desktop Entitlement.

        DELETE /inventory/v3/global-desktop-entitlements/{id}
        """
        return self._c.request("DELETE", f"/inventory/v3/global-desktop-entitlements/{id}", params=None, json_body=None)

    def get_global_desktop_entitlement_v3(self, id):
        """
        Gets the Global Desktop Entitlement in the environment.

        GET /inventory/v3/global-desktop-entitlements/{id}
        """
        return self._c.request("GET", f"/inventory/v3/global-desktop-entitlements/{id}", params=None, json_body=None)

    def update_global_desktop_entitlement_v3(self, id, body: dict = None):
        """
        Updates a Global Desktop Entitlement.

        PUT /inventory/v3/global-desktop-entitlements/{id}
        """
        return self._c.request("PUT", f"/inventory/v3/global-desktop-entitlements/{id}", params=None, json_body=body)

    def query_global_sessions_v3(self, user_id: str = None, pod_id: str = None, brokering_pod_id: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists global sessions in the environment for the given user, pod or brokering pod.

        GET /inventory/v3/global-sessions
        """
        params = {}
        if user_id is not None: params['user_id'] = user_id
        if pod_id is not None: params['pod_id'] = pod_id
        if brokering_pod_id is not None: params['brokering_pod_id'] = brokering_pod_id
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v3/global-sessions", params=params, json_body=None)

    def list_machines_v3(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Machines in the environment.

        GET /inventory/v3/machines
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v3/machines", params=params, json_body=None)

    def schedule_agent_for_upgrade_v3(self, body: dict = None):
        """
        Schedule agents for upgrade.

        POST /inventory/v3/machines/action/schedule-agent-upgrade
        """
        return self._c.request("POST", "/inventory/v3/machines/action/schedule-agent-upgrade", params=None, json_body=body)

    def list_agent_upgrade_tasks_v3(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        List agent upgrade tasks information.

        GET /inventory/v3/machines/agent-upgrade-tasks
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v3/machines/agent-upgrade-tasks", params=params, json_body=None)

    def get_agent_upgrade_task_v3(self, id):
        """
        Get agent upgrade task information.

        GET /inventory/v3/machines/agent-upgrade-tasks/{id}
        """
        return self._c.request("GET", f"/inventory/v3/machines/agent-upgrade-tasks/{id}", params=None, json_body=None)

    def get_machine_v3(self, id):
        """
        Gets the Machine information.

        GET /inventory/v3/machines/{id}
        """
        return self._c.request("GET", f"/inventory/v3/machines/{id}", params=None, json_body=None)

    def list_physical_machines_v3(self, in_use: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Physical Machines in the environment.

        GET /inventory/v3/physical-machines
        """
        params = {}
        if in_use is not None: params['in_use'] = in_use
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v3/physical-machines", params=params, json_body=None)

    def get_physical_machine_v3(self, id):
        """
        Gets the Physical Machine information.

        GET /inventory/v3/physical-machines/{id}
        """
        return self._c.request("GET", f"/inventory/v3/physical-machines/{id}", params=None, json_body=None)

    def update_physical_machines_v3(self, id, body: dict = None):
        """
        Updates the physical machine.

        PUT /inventory/v3/physical-machines/{id}
        """
        return self._c.request("PUT", f"/inventory/v3/physical-machines/{id}", params=None, json_body=body)

    def list_rds_servers_v3(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the RDS Servers in the environment.

        GET /inventory/v3/rds-servers
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v3/rds-servers", params=params, json_body=None)

    def list_rds_server_agent_upgrade_tasks_v3(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        List agent upgrade tasks information.

        GET /inventory/v3/rds-servers/agent-upgrade-tasks
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v3/rds-servers/agent-upgrade-tasks", params=params, json_body=None)

    def get_rds_server_agent_upgrade_task_v3(self, id):
        """
        Get agent upgrade task information.

        GET /inventory/v3/rds-servers/agent-upgrade-tasks/{id}
        """
        return self._c.request("GET", f"/inventory/v3/rds-servers/agent-upgrade-tasks/{id}", params=None, json_body=None)

    def delete_rds_server_v3(self, id):
        """
        Deletes the RDS Server.

        DELETE /inventory/v3/rds-servers/{id}
        """
        return self._c.request("DELETE", f"/inventory/v3/rds-servers/{id}", params=None, json_body=None)

    def get_rds_server_v3(self, id):
        """
        Gets the RDS Server information.

        GET /inventory/v3/rds-servers/{id}
        """
        return self._c.request("GET", f"/inventory/v3/rds-servers/{id}", params=None, json_body=None)

    def update_rds_server_v3(self, id, body: dict = None):
        """
        Updates the RDS Server.

        PUT /inventory/v3/rds-servers/{id}
        """
        return self._c.request("PUT", f"/inventory/v3/rds-servers/{id}", params=None, json_body=body)

    def list_session_info_v3(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the locally resourced Sessions in the environment

        GET /inventory/v3/sessions
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v3/sessions", params=params, json_body=None)

    def get_session_info_v3(self, id):
        """
        Gets the Session information for locally resourced session.

        GET /inventory/v3/sessions/{id}
        """
        return self._c.request("GET", f"/inventory/v3/sessions/{id}", params=None, json_body=None)

    def delete_application_pools(self, body: dict = None):
        """
        Deletes the given application pools.

        DELETE /inventory/v4/application-pools
        """
        return self._c.request("DELETE", "/inventory/v4/application-pools", params=None, json_body=body)

    def list_application_pools_v4(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the application pools in the environment.

        GET /inventory/v4/application-pools
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v4/application-pools", params=params, json_body=None)

    def get_application_pool_v4(self, id):
        """
        Gets application pool.

        GET /inventory/v4/application-pools/{id}
        """
        return self._c.request("GET", f"/inventory/v4/application-pools/{id}", params=None, json_body=None)

    def list_desktop_pools_v4(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the desktop pools in the environment.

        GET /inventory/v4/desktop-pools
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v4/desktop-pools", params=params, json_body=None)

    def get_desktop_pool_v4(self, id):
        """
        Gets the desktop pool information.

        GET /inventory/v4/desktop-pools/{id}
        """
        return self._c.request("GET", f"/inventory/v4/desktop-pools/{id}", params=None, json_body=None)

    def schedule_push_image_v4(self, id, body: dict = None):
        """
        Schedule/reschedule a request to update the image in an instant clone desktop pool.

        POST /inventory/v4/desktop-pools/{id}/action/schedule-push-image
        """
        return self._c.request("POST", f"/inventory/v4/desktop-pools/{id}/action/schedule-push-image", params=None, json_body=body)

    def list_farms_v4(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Farms in the environment.

        GET /inventory/v4/farms
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v4/farms", params=params, json_body=None)

    def get_farm_v4(self, id):
        """
        Gets the Farm information.

        GET /inventory/v4/farms/{id}
        """
        return self._c.request("GET", f"/inventory/v4/farms/{id}", params=None, json_body=None)

    def list_global_application_entitlements_v4(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Global Application Entitlements in the environment.

        GET /inventory/v4/global-application-entitlements
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v4/global-application-entitlements", params=params, json_body=None)

    def create_global_application_entitlement_v4(self, body: dict = None):
        """
        Creates a Global Application Entitlement.

        POST /inventory/v4/global-application-entitlements
        """
        return self._c.request("POST", "/inventory/v4/global-application-entitlements", params=None, json_body=body)

    def delete_global_application_entitlement_v4(self, id):
        """
        Deletes a Global Application Entitlement.

        DELETE /inventory/v4/global-application-entitlements/{id}
        """
        return self._c.request("DELETE", f"/inventory/v4/global-application-entitlements/{id}", params=None, json_body=None)

    def get_global_application_entitlement_v4(self, id):
        """
        Gets the Global Application Entitlement in the environment.

        GET /inventory/v4/global-application-entitlements/{id}
        """
        return self._c.request("GET", f"/inventory/v4/global-application-entitlements/{id}", params=None, json_body=None)

    def update_global_application_entitlement_v4(self, id, body: dict = None):
        """
        Updates a Global Application Entitlement.

        PUT /inventory/v4/global-application-entitlements/{id}
        """
        return self._c.request("PUT", f"/inventory/v4/global-application-entitlements/{id}", params=None, json_body=body)

    def list_global_desktop_entitlements_v4(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Global Desktop Entitlements in the environment.

        GET /inventory/v4/global-desktop-entitlements
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v4/global-desktop-entitlements", params=params, json_body=None)

    def create_global_desktop_entitlement_v4(self, body: dict = None):
        """
        Creates a Global Desktop Entitlement.

        POST /inventory/v4/global-desktop-entitlements
        """
        return self._c.request("POST", "/inventory/v4/global-desktop-entitlements", params=None, json_body=body)

    def delete_global_desktop_entitlement_v4(self, id):
        """
        Deletes a Global Desktop Entitlement.

        DELETE /inventory/v4/global-desktop-entitlements/{id}
        """
        return self._c.request("DELETE", f"/inventory/v4/global-desktop-entitlements/{id}", params=None, json_body=None)

    def get_global_desktop_entitlement_v4(self, id):
        """
        Gets the Global Desktop Entitlement in the environment.

        GET /inventory/v4/global-desktop-entitlements/{id}
        """
        return self._c.request("GET", f"/inventory/v4/global-desktop-entitlements/{id}", params=None, json_body=None)

    def update_global_desktop_entitlement_v4(self, id, body: dict = None):
        """
        Updates a Global Desktop Entitlement.

        PUT /inventory/v4/global-desktop-entitlements/{id}
        """
        return self._c.request("PUT", f"/inventory/v4/global-desktop-entitlements/{id}", params=None, json_body=body)

    def query_global_sessions_v4(self, user_id: str = None, pod_id: str = None, brokering_pod_id: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists global sessions in the environment for the given user, pod or brokering pod.

        GET /inventory/v4/global-sessions
        """
        params = {}
        if user_id is not None: params['user_id'] = user_id
        if pod_id is not None: params['pod_id'] = pod_id
        if brokering_pod_id is not None: params['brokering_pod_id'] = brokering_pod_id
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v4/global-sessions", params=params, json_body=None)

    def list_machines_v4(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Machines in the environment.

        GET /inventory/v4/machines
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v4/machines", params=params, json_body=None)

    def list_agent_upgrade_tasks_v4(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        List agent upgrade tasks information.

        GET /inventory/v4/machines/agent-upgrade-tasks
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v4/machines/agent-upgrade-tasks", params=params, json_body=None)

    def get_agent_upgrade_task_v4(self, id):
        """
        Get agent upgrade task information.

        GET /inventory/v4/machines/agent-upgrade-tasks/{id}
        """
        return self._c.request("GET", f"/inventory/v4/machines/agent-upgrade-tasks/{id}", params=None, json_body=None)

    def get_machine_v4(self, id):
        """
        Gets the machine information.

        GET /inventory/v4/machines/{id}
        """
        return self._c.request("GET", f"/inventory/v4/machines/{id}", params=None, json_body=None)

    def delete_physical_machines(self, body: dict = None):
        """
        Deletes the Physical Machines.

        DELETE /inventory/v4/physical-machines
        """
        return self._c.request("DELETE", "/inventory/v4/physical-machines", params=None, json_body=body)

    def list_physical_machines_v4(self, in_use: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Physical Machines in the environment.

        GET /inventory/v4/physical-machines
        """
        params = {}
        if in_use is not None: params['in_use'] = in_use
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v4/physical-machines", params=params, json_body=None)

    def get_physical_machine_v4(self, id):
        """
        Gets the Physical Machine information.

        GET /inventory/v4/physical-machines/{id}
        """
        return self._c.request("GET", f"/inventory/v4/physical-machines/{id}", params=None, json_body=None)

    def update_physical_machines_v4(self, id, body: dict = None):
        """
        Updates the physical machine.

        PUT /inventory/v4/physical-machines/{id}
        """
        return self._c.request("PUT", f"/inventory/v4/physical-machines/{id}", params=None, json_body=body)

    def list_rds_servers_v4(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the RDS Servers in the environment.

        GET /inventory/v4/rds-servers
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v4/rds-servers", params=params, json_body=None)

    def delete_rds_server_v4(self, id):
        """
        Deletes the RDS Server.

        DELETE /inventory/v4/rds-servers/{id}
        """
        return self._c.request("DELETE", f"/inventory/v4/rds-servers/{id}", params=None, json_body=None)

    def get_rds_server_v4(self, id):
        """
        Gets the RDS Server information.

        GET /inventory/v4/rds-servers/{id}
        """
        return self._c.request("GET", f"/inventory/v4/rds-servers/{id}", params=None, json_body=None)

    def update_rds_server_v4(self, id, body: dict = None):
        """
        Updates the RDS Server.

        PUT /inventory/v4/rds-servers/{id}
        """
        return self._c.request("PUT", f"/inventory/v4/rds-servers/{id}", params=None, json_body=body)

    def list_session_info_v4(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the locally resourced Sessions in the environment

        GET /inventory/v4/sessions
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v4/sessions", params=params, json_body=None)

    def get_session_info_v4(self, id):
        """
        Gets the Session information for locally resourced session.

        GET /inventory/v4/sessions/{id}
        """
        return self._c.request("GET", f"/inventory/v4/sessions/{id}", params=None, json_body=None)

    def delete_application_pools_v5(self, body: dict = None):
        """
        Deletes the given application pools.

        DELETE /inventory/v5/application-pools
        """
        return self._c.request("DELETE", "/inventory/v5/application-pools", params=None, json_body=body)

    def list_application_pools_v5(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the application pools in the environment.

        GET /inventory/v5/application-pools
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v5/application-pools", params=params, json_body=None)

    def create_application_pool_v5(self, body: dict = None):
        """
        Creates an application pool.

        POST /inventory/v5/application-pools
        """
        return self._c.request("POST", "/inventory/v5/application-pools", params=None, json_body=body)

    def get_application_pool_v5(self, id):
        """
        Gets application pool.

        GET /inventory/v5/application-pools/{id}
        """
        return self._c.request("GET", f"/inventory/v5/application-pools/{id}", params=None, json_body=None)

    def update_application_pool_v5(self, id, body: dict = None):
        """
        Updates application pool.

        PUT /inventory/v5/application-pools/{id}
        """
        return self._c.request("PUT", f"/inventory/v5/application-pools/{id}", params=None, json_body=body)

    def list_desktop_pools_v5(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the desktop pools in the environment.

        GET /inventory/v5/desktop-pools
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v5/desktop-pools", params=params, json_body=None)

    def get_desktop_pool_v5(self, id):
        """
        Gets the desktop pool information.

        GET /inventory/v5/desktop-pools/{id}
        """
        return self._c.request("GET", f"/inventory/v5/desktop-pools/{id}", params=None, json_body=None)

    def list_farms_v5(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Farms in the environment.

        GET /inventory/v5/farms
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v5/farms", params=params, json_body=None)

    def get_farm_v5(self, id):
        """
        Gets the Farm information.

        GET /inventory/v5/farms/{id}
        """
        return self._c.request("GET", f"/inventory/v5/farms/{id}", params=None, json_body=None)

    def list_global_application_entitlements_v5(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Global Application Entitlements in the environment.

        GET /inventory/v5/global-application-entitlements
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v5/global-application-entitlements", params=params, json_body=None)

    def list_global_desktop_entitlements_v5(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Global Desktop Entitlements in the environment.

        GET /inventory/v5/global-desktop-entitlements
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v5/global-desktop-entitlements", params=params, json_body=None)

    def create_global_desktop_entitlement_v5(self, body: dict = None):
        """
        Creates a Global Desktop Entitlement.

        POST /inventory/v5/global-desktop-entitlements
        """
        return self._c.request("POST", "/inventory/v5/global-desktop-entitlements", params=None, json_body=body)

    def delete_global_desktop_entitlement_v5(self, id):
        """
        Deletes a Global Desktop Entitlement.

        DELETE /inventory/v5/global-desktop-entitlements/{id}
        """
        return self._c.request("DELETE", f"/inventory/v5/global-desktop-entitlements/{id}", params=None, json_body=None)

    def get_global_desktop_entitlement_v5(self, id):
        """
        Gets the Global Desktop Entitlement in the environment.

        GET /inventory/v5/global-desktop-entitlements/{id}
        """
        return self._c.request("GET", f"/inventory/v5/global-desktop-entitlements/{id}", params=None, json_body=None)

    def update_global_desktop_entitlement_v5(self, id, body: dict = None):
        """
        Updates a Global Desktop Entitlement.

        PUT /inventory/v5/global-desktop-entitlements/{id}
        """
        return self._c.request("PUT", f"/inventory/v5/global-desktop-entitlements/{id}", params=None, json_body=body)

    def list_machines_v5(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Machines in the environment.

        GET /inventory/v5/machines
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v5/machines", params=params, json_body=None)

    def get_machine_v5(self, id):
        """
        Gets the machine information.

        GET /inventory/v5/machines/{id}
        """
        return self._c.request("GET", f"/inventory/v5/machines/{id}", params=None, json_body=None)

    def list_physical_machines_v5(self, in_use: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Physical Machines in the environment.

        GET /inventory/v5/physical-machines
        """
        params = {}
        if in_use is not None: params['in_use'] = in_use
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v5/physical-machines", params=params, json_body=None)

    def get_physical_machine_v5(self, id):
        """
        Gets the Physical Machine information.

        GET /inventory/v5/physical-machines/{id}
        """
        return self._c.request("GET", f"/inventory/v5/physical-machines/{id}", params=None, json_body=None)

    def update_physical_machines_v5(self, id, body: dict = None):
        """
        Updates the physical machine.

        PUT /inventory/v5/physical-machines/{id}
        """
        return self._c.request("PUT", f"/inventory/v5/physical-machines/{id}", params=None, json_body=body)

    def list_rds_servers_v5(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the RDS Servers in the environment.

        GET /inventory/v5/rds-servers
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v5/rds-servers", params=params, json_body=None)

    def delete_rds_server_v5(self, id):
        """
        Deletes the RDS Server.

        DELETE /inventory/v5/rds-servers/{id}
        """
        return self._c.request("DELETE", f"/inventory/v5/rds-servers/{id}", params=None, json_body=None)

    def get_rds_server_v5(self, id):
        """
        Gets the RDS Server information.

        GET /inventory/v5/rds-servers/{id}
        """
        return self._c.request("GET", f"/inventory/v5/rds-servers/{id}", params=None, json_body=None)

    def update_rds_server_v5(self, id, body: dict = None):
        """
        Updates the RDS Server.

        PUT /inventory/v5/rds-servers/{id}
        """
        return self._c.request("PUT", f"/inventory/v5/rds-servers/{id}", params=None, json_body=body)

    def list_session_info_v5(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the locally resourced Sessions in the environment

        GET /inventory/v5/sessions
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v5/sessions", params=params, json_body=None)

    def get_session_info_v5(self, id):
        """
        Gets the Session information for locally resourced session.

        GET /inventory/v5/sessions/{id}
        """
        return self._c.request("GET", f"/inventory/v5/sessions/{id}", params=None, json_body=None)

    def delete_application_pools_v6(self, body: dict = None):
        """
        Deletes the given application pools.

        DELETE /inventory/v6/application-pools
        """
        return self._c.request("DELETE", "/inventory/v6/application-pools", params=None, json_body=body)

    def list_application_pools_v6(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the application pools in the environment.

        GET /inventory/v6/application-pools
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v6/application-pools", params=params, json_body=None)

    def create_application_pool_v6(self, body: dict = None):
        """
        Creates an application pool.

        POST /inventory/v6/application-pools
        """
        return self._c.request("POST", "/inventory/v6/application-pools", params=None, json_body=body)

    def get_application_pool_v6(self, id):
        """
        Gets application pool.

        GET /inventory/v6/application-pools/{id}
        """
        return self._c.request("GET", f"/inventory/v6/application-pools/{id}", params=None, json_body=None)

    def update_application_pool_v6(self, id, body: dict = None):
        """
        Updates application pool.

        PUT /inventory/v6/application-pools/{id}
        """
        return self._c.request("PUT", f"/inventory/v6/application-pools/{id}", params=None, json_body=body)

    def list_desktop_pools_v6(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the desktop pools in the environment.

        GET /inventory/v6/desktop-pools
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v6/desktop-pools", params=params, json_body=None)

    def get_desktop_pool_v6(self, id):
        """
        Gets the desktop pool information.

        GET /inventory/v6/desktop-pools/{id}
        """
        return self._c.request("GET", f"/inventory/v6/desktop-pools/{id}", params=None, json_body=None)

    def list_farms_v6(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Farms in the environment.

        GET /inventory/v6/farms
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v6/farms", params=params, json_body=None)

    def create_farm_v6(self, body: dict = None):
        """
        Creates a farm.

        POST /inventory/v6/farms
        """
        return self._c.request("POST", "/inventory/v6/farms", params=None, json_body=body)

    def delete_farm_v6(self, id):
        """
        Deletes a farm.

        DELETE /inventory/v6/farms/{id}
        """
        return self._c.request("DELETE", f"/inventory/v6/farms/{id}", params=None, json_body=None)

    def get_farm_v6(self, id):
        """
        Gets the Farm information.

        GET /inventory/v6/farms/{id}
        """
        return self._c.request("GET", f"/inventory/v6/farms/{id}", params=None, json_body=None)

    def update_farm_v6(self, id, body: dict = None):
        """
        Updates farm.

        PUT /inventory/v6/farms/{id}
        """
        return self._c.request("PUT", f"/inventory/v6/farms/{id}", params=None, json_body=body)

    def list_global_application_entitlements_v6(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Global Application Entitlements in the environment.

        GET /inventory/v6/global-application-entitlements
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v6/global-application-entitlements", params=params, json_body=None)

    def create_global_application_entitlement_v6(self, body: dict = None):
        """
        Creates a Global Application Entitlement.

        POST /inventory/v6/global-application-entitlements
        """
        return self._c.request("POST", "/inventory/v6/global-application-entitlements", params=None, json_body=body)

    def delete_global_application_entitlement_v6(self, id):
        """
        Deletes a Global Application Entitlement.

        DELETE /inventory/v6/global-application-entitlements/{id}
        """
        return self._c.request("DELETE", f"/inventory/v6/global-application-entitlements/{id}", params=None, json_body=None)

    def get_global_application_entitlement_v6(self, id):
        """
        Gets the Global Application Entitlement in the environment.

        GET /inventory/v6/global-application-entitlements/{id}
        """
        return self._c.request("GET", f"/inventory/v6/global-application-entitlements/{id}", params=None, json_body=None)

    def update_global_application_entitlement_v6(self, id, body: dict = None):
        """
        Updates a Global Application Entitlement.

        PUT /inventory/v6/global-application-entitlements/{id}
        """
        return self._c.request("PUT", f"/inventory/v6/global-application-entitlements/{id}", params=None, json_body=body)

    def list_global_desktop_entitlements_v6(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Global Desktop Entitlements in the environment.

        GET /inventory/v6/global-desktop-entitlements
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v6/global-desktop-entitlements", params=params, json_body=None)

    def create_global_desktop_entitlement_v6(self, body: dict = None):
        """
        Creates a Global Desktop Entitlement.

        POST /inventory/v6/global-desktop-entitlements
        """
        return self._c.request("POST", "/inventory/v6/global-desktop-entitlements", params=None, json_body=body)

    def delete_global_desktop_entitlement_v6(self, id):
        """
        Deletes a Global Desktop Entitlement.

        DELETE /inventory/v6/global-desktop-entitlements/{id}
        """
        return self._c.request("DELETE", f"/inventory/v6/global-desktop-entitlements/{id}", params=None, json_body=None)

    def get_global_desktop_entitlement_v6(self, id):
        """
        Gets the Global Desktop Entitlement in the environment.

        GET /inventory/v6/global-desktop-entitlements/{id}
        """
        return self._c.request("GET", f"/inventory/v6/global-desktop-entitlements/{id}", params=None, json_body=None)

    def update_global_desktop_entitlement_v6(self, id, body: dict = None):
        """
        Updates a Global Desktop Entitlement.

        PUT /inventory/v6/global-desktop-entitlements/{id}
        """
        return self._c.request("PUT", f"/inventory/v6/global-desktop-entitlements/{id}", params=None, json_body=body)

    def list_machines_v6(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Machines in the environment.

        GET /inventory/v6/machines
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v6/machines", params=params, json_body=None)

    def get_machine_v6(self, id):
        """
        Gets the machine information.

        GET /inventory/v6/machines/{id}
        """
        return self._c.request("GET", f"/inventory/v6/machines/{id}", params=None, json_body=None)

    def list_physical_machines_v6(self, in_use: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Physical Machines in the environment.

        GET /inventory/v6/physical-machines
        """
        params = {}
        if in_use is not None: params['in_use'] = in_use
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v6/physical-machines", params=params, json_body=None)

    def get_physical_machine_v6(self, id):
        """
        Gets the Physical Machine information.

        GET /inventory/v6/physical-machines/{id}
        """
        return self._c.request("GET", f"/inventory/v6/physical-machines/{id}", params=None, json_body=None)

    def list_rds_servers_v6(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the RDS Servers in the environment.

        GET /inventory/v6/rds-servers
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v6/rds-servers", params=params, json_body=None)

    def delete_rds_server_v6(self, id):
        """
        Deletes the RDS Server.

        DELETE /inventory/v6/rds-servers/{id}
        """
        return self._c.request("DELETE", f"/inventory/v6/rds-servers/{id}", params=None, json_body=None)

    def get_rds_server_v6(self, id):
        """
        Gets the RDS Server information.

        GET /inventory/v6/rds-servers/{id}
        """
        return self._c.request("GET", f"/inventory/v6/rds-servers/{id}", params=None, json_body=None)

    def list_session_info_v6(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the locally resourced Sessions in the environment

        GET /inventory/v6/sessions
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v6/sessions", params=params, json_body=None)

    def get_session_info_v6(self, id):
        """
        Gets the Session information for locally resourced session.

        GET /inventory/v6/sessions/{id}
        """
        return self._c.request("GET", f"/inventory/v6/sessions/{id}", params=None, json_body=None)

    def delete_application_pools_v7(self, body: dict = None):
        """
        Deletes the given application pools.

        DELETE /inventory/v7/application-pools
        """
        return self._c.request("DELETE", "/inventory/v7/application-pools", params=None, json_body=body)

    def list_application_pools_v7(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the application pools in the environment.

        GET /inventory/v7/application-pools
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v7/application-pools", params=params, json_body=None)

    def create_application_pool_v7(self, body: dict = None):
        """
        Creates an application pool.

        POST /inventory/v7/application-pools
        """
        return self._c.request("POST", "/inventory/v7/application-pools", params=None, json_body=body)

    def delete_application_pool_v7(self, id):
        """
        Deletes application pool.

        DELETE /inventory/v7/application-pools/{id}
        """
        return self._c.request("DELETE", f"/inventory/v7/application-pools/{id}", params=None, json_body=None)

    def get_application_pool_v7(self, id):
        """
        Gets application pool.

        GET /inventory/v7/application-pools/{id}
        """
        return self._c.request("GET", f"/inventory/v7/application-pools/{id}", params=None, json_body=None)

    def update_application_pool_v7(self, id, body: dict = None):
        """
        Updates application pool.

        PUT /inventory/v7/application-pools/{id}
        """
        return self._c.request("PUT", f"/inventory/v7/application-pools/{id}", params=None, json_body=body)

    def list_desktop_pools_v7(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the desktop pools in the environment.

        GET /inventory/v7/desktop-pools
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v7/desktop-pools", params=params, json_body=None)

    def create_desktop_pool_v7(self, body: dict = None):
        """
        Creates a desktop pool.

        POST /inventory/v7/desktop-pools
        """
        return self._c.request("POST", "/inventory/v7/desktop-pools", params=None, json_body=body)

    def delete_desktop_pool_v7(self, id, body: dict = None, enforce_associated_session_check: str = None):
        """
        Deletes a desktop pool.

        DELETE /inventory/v7/desktop-pools/{id}
        """
        params = {}
        if enforce_associated_session_check is not None: params['enforce_associated_session_check'] = enforce_associated_session_check
        return self._c.request("DELETE", f"/inventory/v7/desktop-pools/{id}", params=params, json_body=body)

    def get_desktop_pool_v7(self, id):
        """
        Gets the desktop pool information.

        GET /inventory/v7/desktop-pools/{id}
        """
        return self._c.request("GET", f"/inventory/v7/desktop-pools/{id}", params=None, json_body=None)

    def update_desktop_poolv7(self, id, body: dict = None):
        """
        Updates desktop pool.

        PUT /inventory/v7/desktop-pools/{id}
        """
        return self._c.request("PUT", f"/inventory/v7/desktop-pools/{id}", params=None, json_body=body)

    def list_farms_v7(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Farms in the environment.

        GET /inventory/v7/farms
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v7/farms", params=params, json_body=None)

    def create_farm_v7(self, body: dict = None):
        """
        Creates a farm.

        POST /inventory/v7/farms
        """
        return self._c.request("POST", "/inventory/v7/farms", params=None, json_body=body)

    def delete_farm_v7(self, id):
        """
        Deletes a farm.

        DELETE /inventory/v7/farms/{id}
        """
        return self._c.request("DELETE", f"/inventory/v7/farms/{id}", params=None, json_body=None)

    def get_farm_v7(self, id):
        """
        Gets the Farm information.

        GET /inventory/v7/farms/{id}
        """
        return self._c.request("GET", f"/inventory/v7/farms/{id}", params=None, json_body=None)

    def update_farm_v7(self, id, body: dict = None):
        """
        Updates farm.

        PUT /inventory/v7/farms/{id}
        """
        return self._c.request("PUT", f"/inventory/v7/farms/{id}", params=None, json_body=body)

    def list_global_application_entitlements_v7(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Global Application Entitlements in the environment.

        GET /inventory/v7/global-application-entitlements
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v7/global-application-entitlements", params=params, json_body=None)

    def create_global_application_entitlement_v7(self, body: dict = None):
        """
        Creates a Global Application Entitlement.

        POST /inventory/v7/global-application-entitlements
        """
        return self._c.request("POST", "/inventory/v7/global-application-entitlements", params=None, json_body=body)

    def delete_global_application_entitlement_v7(self, id):
        """
        Deletes a Global Application Entitlement.

        DELETE /inventory/v7/global-application-entitlements/{id}
        """
        return self._c.request("DELETE", f"/inventory/v7/global-application-entitlements/{id}", params=None, json_body=None)

    def get_global_application_entitlement_v7(self, id):
        """
        Gets the Global Application Entitlement in the environment.

        GET /inventory/v7/global-application-entitlements/{id}
        """
        return self._c.request("GET", f"/inventory/v7/global-application-entitlements/{id}", params=None, json_body=None)

    def update_global_application_entitlement_v7(self, id, body: dict = None):
        """
        Updates a Global Application Entitlement.

        PUT /inventory/v7/global-application-entitlements/{id}
        """
        return self._c.request("PUT", f"/inventory/v7/global-application-entitlements/{id}", params=None, json_body=body)

    def list_global_desktop_entitlements_v7(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Global Desktop Entitlements in the environment.

        GET /inventory/v7/global-desktop-entitlements
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v7/global-desktop-entitlements", params=params, json_body=None)

    def create_global_desktop_entitlement_v7(self, body: dict = None):
        """
        Creates a Global Desktop Entitlement.

        POST /inventory/v7/global-desktop-entitlements
        """
        return self._c.request("POST", "/inventory/v7/global-desktop-entitlements", params=None, json_body=body)

    def delete_global_desktop_entitlement_v7(self, id):
        """
        Deletes a Global Desktop Entitlement.

        DELETE /inventory/v7/global-desktop-entitlements/{id}
        """
        return self._c.request("DELETE", f"/inventory/v7/global-desktop-entitlements/{id}", params=None, json_body=None)

    def get_global_desktop_entitlement_v7(self, id):
        """
        Gets the Global Desktop Entitlement in the environment.

        GET /inventory/v7/global-desktop-entitlements/{id}
        """
        return self._c.request("GET", f"/inventory/v7/global-desktop-entitlements/{id}", params=None, json_body=None)

    def update_global_desktop_entitlement_v7(self, id, body: dict = None):
        """
        Updates a Global Desktop Entitlement.

        PUT /inventory/v7/global-desktop-entitlements/{id}
        """
        return self._c.request("PUT", f"/inventory/v7/global-desktop-entitlements/{id}", params=None, json_body=body)

    def list_machines_v7(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Machines in the environment.

        GET /inventory/v7/machines
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v7/machines", params=params, json_body=None)

    def get_machine_v7(self, id):
        """
        Gets the machine information.

        GET /inventory/v7/machines/{id}
        """
        return self._c.request("GET", f"/inventory/v7/machines/{id}", params=None, json_body=None)

    def list_rds_servers_v7(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the RDS Servers in the environment.

        GET /inventory/v7/rds-servers
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v7/rds-servers", params=params, json_body=None)

    def delete_rds_server_v7(self, id):
        """
        Deletes the RDS Server.

        DELETE /inventory/v7/rds-servers/{id}
        """
        return self._c.request("DELETE", f"/inventory/v7/rds-servers/{id}", params=None, json_body=None)

    def get_rds_server_v7(self, id):
        """
        Gets the RDS Server information.

        GET /inventory/v7/rds-servers/{id}
        """
        return self._c.request("GET", f"/inventory/v7/rds-servers/{id}", params=None, json_body=None)

    def update_rds_server_v7(self, id, body: dict = None):
        """
        Updates the RDS Server.

        PUT /inventory/v7/rds-servers/{id}
        """
        return self._c.request("PUT", f"/inventory/v7/rds-servers/{id}", params=None, json_body=body)

    def list_session_info_v7(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the locally resourced Sessions in the environment

        GET /inventory/v7/sessions
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v7/sessions", params=params, json_body=None)

    def get_session_info_v7(self, id):
        """
        Gets the Session information for locally resourced session.

        GET /inventory/v7/sessions/{id}
        """
        return self._c.request("GET", f"/inventory/v7/sessions/{id}", params=None, json_body=None)

    def delete_application_pools_v8(self, body: dict = None):
        """
        Deletes the given application pools.

        DELETE /inventory/v8/application-pools
        """
        return self._c.request("DELETE", "/inventory/v8/application-pools", params=None, json_body=body)

    def list_application_pools_v8(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the application pools in the environment.

        GET /inventory/v8/application-pools
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v8/application-pools", params=params, json_body=None)

    def create_application_pool_v8(self, body: dict = None):
        """
        Creates an application pool.

        POST /inventory/v8/application-pools
        """
        return self._c.request("POST", "/inventory/v8/application-pools", params=None, json_body=body)

    def delete_application_pool_v8(self, id):
        """
        Deletes application pool.

        DELETE /inventory/v8/application-pools/{id}
        """
        return self._c.request("DELETE", f"/inventory/v8/application-pools/{id}", params=None, json_body=None)

    def get_application_pool_v8(self, id):
        """
        Gets application pool.

        GET /inventory/v8/application-pools/{id}
        """
        return self._c.request("GET", f"/inventory/v8/application-pools/{id}", params=None, json_body=None)

    def update_application_pool_v8(self, id, body: dict = None):
        """
        Updates application pool.

        PUT /inventory/v8/application-pools/{id}
        """
        return self._c.request("PUT", f"/inventory/v8/application-pools/{id}", params=None, json_body=body)

    def list_desktop_pools_v8(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the desktop pools in the environment.

        GET /inventory/v8/desktop-pools
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v8/desktop-pools", params=params, json_body=None)

    def create_desktop_pool_v8(self, body: dict = None):
        """
        Creates a desktop pool.

        POST /inventory/v8/desktop-pools
        """
        return self._c.request("POST", "/inventory/v8/desktop-pools", params=None, json_body=body)

    def delete_desktop_pool_v8(self, id, body: dict = None, enforce_associated_session_check: str = None):
        """
        Deletes a desktop pool.

        DELETE /inventory/v8/desktop-pools/{id}
        """
        params = {}
        if enforce_associated_session_check is not None: params['enforce_associated_session_check'] = enforce_associated_session_check
        return self._c.request("DELETE", f"/inventory/v8/desktop-pools/{id}", params=params, json_body=body)

    def get_desktop_pool_v8(self, id):
        """
        Gets the desktop pool information.

        GET /inventory/v8/desktop-pools/{id}
        """
        return self._c.request("GET", f"/inventory/v8/desktop-pools/{id}", params=None, json_body=None)

    def update_desktop_poolv8(self, id, body: dict = None):
        """
        Updates desktop pool.

        PUT /inventory/v8/desktop-pools/{id}
        """
        return self._c.request("PUT", f"/inventory/v8/desktop-pools/{id}", params=None, json_body=body)

    def list_farms_v8(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Farms in the environment.

        GET /inventory/v8/farms
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v8/farms", params=params, json_body=None)

    def create_farm_v8(self, body: dict = None):
        """
        Creates a farm.

        POST /inventory/v8/farms
        """
        return self._c.request("POST", "/inventory/v8/farms", params=None, json_body=body)

    def delete_farm_v8(self, id):
        """
        Deletes a farm.

        DELETE /inventory/v8/farms/{id}
        """
        return self._c.request("DELETE", f"/inventory/v8/farms/{id}", params=None, json_body=None)

    def get_farm_v8(self, id):
        """
        Gets the Farm information.

        GET /inventory/v8/farms/{id}
        """
        return self._c.request("GET", f"/inventory/v8/farms/{id}", params=None, json_body=None)

    def update_farm_v8(self, id, body: dict = None):
        """
        Updates farm.

        PUT /inventory/v8/farms/{id}
        """
        return self._c.request("PUT", f"/inventory/v8/farms/{id}", params=None, json_body=body)

    def delete_machines_v8(self, body: dict = None):
        """
        Deletes the specified machines.

        DELETE /inventory/v8/machines
        """
        return self._c.request("DELETE", "/inventory/v8/machines", params=None, json_body=body)

    def list_machines_v8(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Machines in the environment.

        GET /inventory/v8/machines
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v8/machines", params=params, json_body=None)

    def delete_machine_v8(self, id, body: dict = None):
        """
        Deletes the machine.

        DELETE /inventory/v8/machines/{id}
        """
        return self._c.request("DELETE", f"/inventory/v8/machines/{id}", params=None, json_body=body)

    def get_machine_v8(self, id):
        """
        Gets the machine information.

        GET /inventory/v8/machines/{id}
        """
        return self._c.request("GET", f"/inventory/v8/machines/{id}", params=None, json_body=None)

    def list_session_info_v8(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the locally resourced Sessions in the environment

        GET /inventory/v8/sessions
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v8/sessions", params=params, json_body=None)

    def get_session_info_v8(self, id):
        """
        Gets the Session information for locally resourced session.

        GET /inventory/v8/sessions/{id}
        """
        return self._c.request("GET", f"/inventory/v8/sessions/{id}", params=None, json_body=None)

    def delete_application_pools_v9(self, body: dict = None):
        """
        Deletes the given application pools.

        DELETE /inventory/v9/application-pools
        """
        return self._c.request("DELETE", "/inventory/v9/application-pools", params=None, json_body=body)

    def list_application_pools_v9(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the application pools in the environment.

        GET /inventory/v9/application-pools
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v9/application-pools", params=params, json_body=None)

    def create_application_pool_v9(self, body: dict = None):
        """
        Creates an application pool.

        POST /inventory/v9/application-pools
        """
        return self._c.request("POST", "/inventory/v9/application-pools", params=None, json_body=body)

    def delete_application_pool_v9(self, id):
        """
        Deletes application pool.

        DELETE /inventory/v9/application-pools/{id}
        """
        return self._c.request("DELETE", f"/inventory/v9/application-pools/{id}", params=None, json_body=None)

    def get_application_pool_v9(self, id):
        """
        Gets application pool.

        GET /inventory/v9/application-pools/{id}
        """
        return self._c.request("GET", f"/inventory/v9/application-pools/{id}", params=None, json_body=None)

    def update_application_pool_v9(self, id, body: dict = None):
        """
        Updates application pool.

        PUT /inventory/v9/application-pools/{id}
        """
        return self._c.request("PUT", f"/inventory/v9/application-pools/{id}", params=None, json_body=body)

    def list_desktop_pools_v9(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the desktop pools in the environment.

        GET /inventory/v9/desktop-pools
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v9/desktop-pools", params=params, json_body=None)

    def create_desktop_pool_v9(self, body: dict = None):
        """
        Creates a desktop pool.

        POST /inventory/v9/desktop-pools
        """
        return self._c.request("POST", "/inventory/v9/desktop-pools", params=None, json_body=body)

    def delete_desktop_pool_v9(self, id, body: dict = None, enforce_associated_session_check: str = None):
        """
        Deletes a desktop pool.

        DELETE /inventory/v9/desktop-pools/{id}
        """
        params = {}
        if enforce_associated_session_check is not None: params['enforce_associated_session_check'] = enforce_associated_session_check
        return self._c.request("DELETE", f"/inventory/v9/desktop-pools/{id}", params=params, json_body=body)

    def get_desktop_pool_v9(self, id):
        """
        Gets the desktop pool information.

        GET /inventory/v9/desktop-pools/{id}
        """
        return self._c.request("GET", f"/inventory/v9/desktop-pools/{id}", params=None, json_body=None)

    def update_desktop_pool_v9(self, id, body: dict = None):
        """
        Updates desktop pool.

        PUT /inventory/v9/desktop-pools/{id}
        """
        return self._c.request("PUT", f"/inventory/v9/desktop-pools/{id}", params=None, json_body=body)

    def list_farms_v9(self, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Farms in the environment.

        GET /inventory/v9/farms
        """
        params = {}
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v9/farms", params=params, json_body=None)

    def create_farm_v9(self, body: dict = None):
        """
        Creates a farm.

        POST /inventory/v9/farms
        """
        return self._c.request("POST", "/inventory/v9/farms", params=None, json_body=body)

    def delete_farm_v9(self, id):
        """
        Deletes a farm.

        DELETE /inventory/v9/farms/{id}
        """
        return self._c.request("DELETE", f"/inventory/v9/farms/{id}", params=None, json_body=None)

    def get_farm_v9(self, id):
        """
        Gets the Farm information.

        GET /inventory/v9/farms/{id}
        """
        return self._c.request("GET", f"/inventory/v9/farms/{id}", params=None, json_body=None)

    def update_farm_v9(self, id, body: dict = None):
        """
        Updates farm.

        PUT /inventory/v9/farms/{id}
        """
        return self._c.request("PUT", f"/inventory/v9/farms/{id}", params=None, json_body=body)

    def delete_machines_v9(self, body: dict = None):
        """
        Deletes the specified machines.

        DELETE /inventory/v9/machines
        """
        return self._c.request("DELETE", "/inventory/v9/machines", params=None, json_body=body)

    def list_machines_v9(self, group_id: str = None, page: str = None, size: str = None, filter: str = None, sort_by: str = None, order_by: str = None):
        """
        Lists the Machines in the environment.

        GET /inventory/v9/machines
        """
        params = {}
        if group_id is not None: params['group_id'] = group_id
        if page is not None: params['page'] = page
        if size is not None: params['size'] = size
        if filter is not None: params['filter'] = filter
        if sort_by is not None: params['sort_by'] = sort_by
        if order_by is not None: params['order_by'] = order_by
        return self._c.request("GET", "/inventory/v9/machines", params=params, json_body=None)

    def delete_machine_v9(self, id, body: dict = None):
        """
        Deletes the machine.

        DELETE /inventory/v9/machines/{id}
        """
        return self._c.request("DELETE", f"/inventory/v9/machines/{id}", params=None, json_body=body)

    def get_machine_v9(self, id):
        """
        Gets the machine information.

        GET /inventory/v9/machines/{id}
        """
        return self._c.request("GET", f"/inventory/v9/machines/{id}", params=None, json_body=None)
