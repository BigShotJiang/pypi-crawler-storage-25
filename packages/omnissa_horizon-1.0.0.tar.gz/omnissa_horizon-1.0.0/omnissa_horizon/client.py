# Copyright 2026 Abhilash Jha
# SPDX-License-Identifier: Apache-2.0

"""
Omnissa Horizon Connection Server REST API Client
Auto-generated from Swagger/OpenAPI spec v2603
"""
import requests
import urllib3
from typing import Optional, Dict, Any, List
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class HorizonAPIError(Exception):
    """Raised when the Horizon API returns an error response."""
    def __init__(self, status_code: int, message: str, response=None):
        self.status_code = status_code
        self.response = response
        super().__init__(f"HTTP {status_code}: {message}")


class HorizonClient:
    """
    Client for the Omnissa Horizon Connection Server REST API (v2603).

    Usage::

        client = HorizonClient("https://horizon.example.com")
        client.login("admin", "password", "DOMAIN")

        # Use sub-clients
        pools = client.inventory.list_desktop_pools()
        servers = client.monitor.list_connection_server_monitors()

        client.logout()

    Or use as a context manager::

        with HorizonClient("https://horizon.example.com") as client:
            client.login("admin", "password", "DOMAIN")
            pools = client.inventory.list_desktop_pools()
    """

    def __init__(
        self,
        server_url: str,
        verify_ssl: bool = True,
        timeout: int = 30,
        api_version: str = "2603",
    ):
        """
        Initialize the Horizon client.

        :param server_url: Base URL of the Horizon Connection Server (e.g. https://cs.domain.com)
        :param verify_ssl: Verify SSL certificates. Set False for self-signed certs in labs.
        :param timeout: Request timeout in seconds.
        :param api_version: API version string.
        """
        self.server_url = server_url.rstrip("/")
        self.base_url = f"{self.server_url}/rest"
        self.verify_ssl = verify_ssl
        self.timeout = timeout
        self.api_version = api_version
        self._access_token: Optional[str] = None
        self._refresh_token: Optional[str] = None
        self._session = requests.Session()
        self._session.verify = verify_ssl

        # Lazy-initialize sub-clients (imported locally to avoid circular imports)
        self._auth: Optional["AuthAPI"] = None
        self._config: Optional["ConfigAPI"] = None
        self._inventory: Optional["InventoryAPI"] = None
        self._monitor: Optional["MonitorAPI"] = None
        self._entitlements: Optional["EntitlementsAPI"] = None
        self._external: Optional["ExternalAPI"] = None
        self._federation: Optional["FederationAPI"] = None
        self._helpdesk: Optional["HelpDeskAPI"] = None

    # -------------------------------------------------------------------------
    # Auth helpers
    # -------------------------------------------------------------------------

    def login(self, username: str, password: str, domain: str) -> Dict[str, Any]:
        """
        Authenticate and store the access/refresh token pair.

        :param username: AD username.
        :param password: AD password.
        :param domain: AD domain name.
        :returns: Dict with ``access_token`` and ``refresh_token`` keys.
        """
        payload = {"username": username, "password": password, "domain": domain}
        resp = self._session.post(
            f"{self.base_url}/login",
            json=payload,
            verify=self.verify_ssl,
            timeout=self.timeout,
        )
        self._handle_response(resp)
        data = resp.json()
        self._access_token = data.get("access_token")
        self._refresh_token = data.get("refresh_token")
        self._session.headers.update({"Authorization": f"Bearer {self._access_token}"})
        return data

    def refresh_access_token(self) -> Dict[str, Any]:
        """Refresh the access token using the stored refresh token."""
        if not self._refresh_token:
            raise HorizonAPIError(401, "No refresh token available. Please login first.")
        resp = self._session.post(
            f"{self.base_url}/refresh",
            json={"refresh_token": self._refresh_token},
            verify=self.verify_ssl,
            timeout=self.timeout,
        )
        self._handle_response(resp)
        data = resp.json()
        self._access_token = data.get("access_token")
        self._refresh_token = data.get("refresh_token")
        self._session.headers.update({"Authorization": f"Bearer {self._access_token}"})
        return data

    def logout(self) -> None:
        """Invalidate the current session tokens."""
        if self._refresh_token:
            self._session.post(
                f"{self.base_url}/logout",
                json={"refresh_token": self._refresh_token},
                verify=self.verify_ssl,
                timeout=self.timeout,
            )
        self._access_token = None
        self._refresh_token = None
        self._session.headers.pop("Authorization", None)

    # -------------------------------------------------------------------------
    # Low-level request method
    # -------------------------------------------------------------------------

    def request(
        self,
        method: str,
        path: str,
        params: Optional[Dict] = None,
        json_body: Optional[Any] = None,
        data: Optional[Any] = None,
        headers: Optional[Dict] = None,
    ) -> Any:
        """
        Make an authenticated REST call.

        :param method: HTTP verb (GET, POST, PUT, PATCH, DELETE).
        :param path: API path, e.g. ``/inventory/v1/desktop-pools``.
        :param params: Query string parameters.
        :param json_body: Body serialised as JSON.
        :param data: Raw body bytes/str.
        :param headers: Extra headers.
        :returns: Parsed JSON, or ``None`` for 204 No Content responses.
        """
        url = f"{self.base_url}{path}"
        resp = self._session.request(
            method=method,
            url=url,
            params=params,
            json=json_body,
            data=data,
            headers=headers,
            verify=self.verify_ssl,
            timeout=self.timeout,
        )
        self._handle_response(resp)
        if resp.status_code == 204 or not resp.content:
            return None
        try:
            return resp.json()
        except ValueError:
            return resp.text

    @staticmethod
    def _handle_response(response: requests.Response) -> None:
        if response.status_code >= 400:
            try:
                message = response.json()
            except ValueError:
                message = response.text or response.reason
            raise HorizonAPIError(response.status_code, str(message), response)

    # -------------------------------------------------------------------------
    # Sub-client properties
    # -------------------------------------------------------------------------

    @property
    def auth(self) -> "AuthAPI":
        if self._auth is None:
            from omnissa_horizon.api.auth import AuthAPI
            self._auth = AuthAPI(self)
        return self._auth

    @property
    def config(self) -> "ConfigAPI":
        if self._config is None:
            from omnissa_horizon.api.config import ConfigAPI
            self._config = ConfigAPI(self)
        return self._config

    @property
    def inventory(self) -> "InventoryAPI":
        if self._inventory is None:
            from omnissa_horizon.api.inventory import InventoryAPI
            self._inventory = InventoryAPI(self)
        return self._inventory

    @property
    def monitor(self) -> "MonitorAPI":
        if self._monitor is None:
            from omnissa_horizon.api.monitor import MonitorAPI
            self._monitor = MonitorAPI(self)
        return self._monitor

    @property
    def entitlements(self) -> "EntitlementsAPI":
        if self._entitlements is None:
            from omnissa_horizon.api.entitlements import EntitlementsAPI
            self._entitlements = EntitlementsAPI(self)
        return self._entitlements

    @property
    def external(self) -> "ExternalAPI":
        if self._external is None:
            from omnissa_horizon.api.external import ExternalAPI
            self._external = ExternalAPI(self)
        return self._external

    @property
    def federation(self) -> "FederationAPI":
        if self._federation is None:
            from omnissa_horizon.api.federation import FederationAPI
            self._federation = FederationAPI(self)
        return self._federation

    @property
    def helpdesk(self) -> "HelpDeskAPI":
        if self._helpdesk is None:
            from omnissa_horizon.api.help_desk import HelpDeskAPI
            self._helpdesk = HelpDeskAPI(self)
        return self._helpdesk

    # -------------------------------------------------------------------------
    # Context manager
    # -------------------------------------------------------------------------

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.logout()
