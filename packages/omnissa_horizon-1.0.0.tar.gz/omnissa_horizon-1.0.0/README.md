# omnissa-horizon

[![PyPI version](https://img.shields.io/pypi/v/omnissa-horizon.svg)](https://pypi.org/project/omnissa-horizon/)
[![Python Versions](https://img.shields.io/pypi/pyversions/omnissa-horizon.svg)](https://pypi.org/project/omnissa-horizon/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**Python SDK for the [Omnissa Horizon Connection Server REST API](https://developer.omnissa.com/horizon-apis/horizon-server/versions/2603/)** (v2603 / OpenAPI 3.0).

Covers **714 endpoints** across 8 API groups:
`Auth` · `Config` · `Inventory` · `Monitor` · `Entitlements` · `External` · `Federation` · `Help Desk`

---

## Installation

```bash
pip install omnissa-horizon
```

### From source

```bash
git clone https://github.com/yourusername/omnissa-horizon.git
cd omnissa-horizon
pip install -e ".[dev]"
```

---

## Quick Start

```python
from omnissa_horizon import HorizonClient, HorizonAPIError

# Connect (use verify_ssl=False for self-signed lab certs)
client = HorizonClient("https://horizon.example.com", verify_ssl=False)

# Login
client.login("admin", "P@ssw0rd", "YOURDOMAIN")

# ── Monitor ──────────────────────────────────────────
servers  = client.monitor.list_connection_server_monitors()
sessions = client.monitor.list_session_monitors()
farms    = client.monitor.list_farm_monitors()

# ── Inventory ────────────────────────────────────────
pools    = client.inventory.list_desktop_pools()
machines = client.inventory.list_machines()
apps     = client.inventory.list_application_pools()

# ── Config ───────────────────────────────────────────
settings = client.config.get_global_settings()
cs_list  = client.config.list_connection_servers()

# ── Entitlements ─────────────────────────────────────
ents = client.entitlements.list_desktop_pool_entitlements()

# Logout
client.logout()
```

### Context manager (auto-logout)

```python
with HorizonClient("https://horizon.example.com", verify_ssl=False) as client:
    client.login("admin", "P@ssw0rd", "DOMAIN")
    pools = client.inventory.list_desktop_pools()
    for pool in pools:
        print(pool["id"], pool.get("name"))
```

---

## Error Handling

```python
from omnissa_horizon import HorizonClient, HorizonAPIError

with HorizonClient("https://horizon.example.com", verify_ssl=False) as client:
    try:
        client.login("admin", "wrong_password", "DOMAIN")
    except HorizonAPIError as e:
        print(f"Login failed [{e.status_code}]: {e}")

    try:
        machine = client.inventory.get_machine("invalid-id")
    except HorizonAPIError as e:
        if e.status_code == 404:
            print("Machine not found")
        elif e.status_code == 401:
            # Token expired – refresh and retry
            client.refresh_access_token()
```

---

## API Reference

All methods follow the naming pattern `{verb}_{resource}`, derived from the Swagger `operationId`.

### Auth (`client.auth`)

| Method | Description |
|--------|-------------|
| `login(username, password, domain)` | Authenticate, store tokens |
| `logout()` | Invalidate session |
| `refresh_access_token()` | Refresh expired access token |
| `authenticate_smart_card()` | Smart card login |
| `key_agreement(body)` | Diffie-Hellman key agreement |

### Monitor (`client.monitor`)

| Method | Description |
|--------|-------------|
| `list_connection_server_monitors()` | All Connection Server statuses |
| `list_session_monitors(**filters)` | Active sessions |
| `list_desktop_monitors()` | Desktop pool health |
| `list_farm_monitors()` | Farm health |
| `list_gateway_monitor_info_v1()` | UAG/gateway status |
| `list_ad_domain_monitors()` | AD domain health |
| `get_event_database_monitor()` | Event DB status |
| `list_saml_authenticator_monitors()` | SAML authenticator health |
| `list_rds_server_monitors()` | RDS server status |

### Inventory (`client.inventory`)

| Method | Description |
|--------|-------------|
| `list_desktop_pools(**params)` | List desktop pools |
| `get_desktop_pool(id)` | Get pool by ID |
| `create_desktop_pool(body)` | Create a desktop pool |
| `update_desktop_pool(id, body)` | Update a pool |
| `delete_desktop_pool(id)` | Delete a pool |
| `list_machines(**params)` | List all machines |
| `get_machine(id)` | Get machine details |
| `list_sessions(**params)` | List active sessions |
| `disconnect_session(body)` | Disconnect a session |
| `logoff_sessions(body)` | Log off sessions |
| `list_application_pools(**params)` | List application pools |
| `list_farms(**params)` | List RDS farms |
| `list_global_application_entitlements()` | Global app entitlements |

### Config (`client.config`)

| Method | Description |
|--------|-------------|
| `list_connection_servers()` | List Connection Servers |
| `get_connection_server(id)` | Get CS details |
| `get_global_settings()` | Global Horizon settings |
| `update_global_settings(body)` | Update global settings |
| `list_virtual_centers()` | List vCenter servers |
| `list_instant_clone_domain_accounts()` | IC domain accounts |
| `get_environment_properties()` | Pod environment info |
| `get_event_database()` | Event DB config |

### Entitlements (`client.entitlements`)

| Method | Description |
|--------|-------------|
| `list_desktop_pool_entitlements()` | Desktop pool entitlements |
| `bulk_create_desktop_pool_entitlements(body)` | Add entitlements |
| `bulk_delete_desktop_pool_entitlements(body)` | Remove entitlements |
| `list_application_pool_entitlements()` | App pool entitlements |
| `list_cloud_entitlements()` | Cloud entitlements |

### External (`client.external`)

| Method | Description |
|--------|-------------|
| `list_ad_domains()` | AD domains |
| `list_ad_users_or_groups(**params)` | AD users/groups |
| `list_base_vms(**params)` | vSphere base VMs |
| `list_datastores(**params)` | Available datastores |
| `list_hosts_or_clusters(**params)` | vSphere hosts/clusters |
| `list_networks(**params)` | vSphere networks |

### Federation (`client.federation`)

| Method | Description |
|--------|-------------|
| `get_pod_federation()` | CPA federation details |
| `initialize_c_p_a(body)` | Initialize Cloud Pod Architecture |
| `join_c_p_a(body)` | Join CPA |
| `list_pods()` | List all pods |
| `list_sites()` | List CPA sites |

### Help Desk (`client.helpdesk`)

| Method | Description |
|--------|-------------|
| `get_client_information()` | Client display topology |
| `list_process_performance_info()` | Process info |
| `get_display_protocol_performance_info()` | PCoIP/Blast stats |
| `list_historical_performance_info()` | Historical perf data |
| `send_message(body)` | Send message to session |

---

## Advanced Usage

### Custom raw requests

```python
# Direct low-level call — useful for endpoints not yet wrapped
result = client.request("GET", "/inventory/v1/desktop-pools", params={"page": 1, "size": 100})
```

### Token refresh on expiry

```python
import time
from omnissa_horizon import HorizonAPIError

def get_pools_safe(client):
    try:
        return client.inventory.list_desktop_pools()
    except HorizonAPIError as e:
        if e.status_code == 401:
            client.refresh_access_token()
            return client.inventory.list_desktop_pools()
        raise
```

### Disable SSL verification (lab / self-signed certs)

```python
client = HorizonClient("https://horizon.lab.local", verify_ssl=False)
```

---

## API Versions

| SDK Version | Horizon API Version | Omnissa Docs |
|-------------|--------------------|----|
| 1.0.x       | 2603               | [Link](https://developer.omnissa.com/horizon-apis/horizon-server/versions/2603/) |

---

## Contributing

Pull requests welcome! To add support for a new API version:

1. Download the new Swagger JSON from Omnissa Developer Portal
2. Re-run the code generator (`tools/generate.py`)
3. Update `__version__` and changelog

---

## License

MIT © Abhilash Jha
