from setuptools import setup, find_packages

setup(
    name="Palima",
    version="1.15.1",
    description="A Python-based 3D game engine by FELLOS-STUDIOS",
    author="FELLOS-STUDIOS",
    author_email="fellos.studios@gmail.com",
    url="https://github.com/EfayTheDeveloper/Palima-Engine",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
    ],
    python_requires=">=3.8",
    install_requires=[
        "pygame>=2.0.0",
        "PyOpenGL>=3.1.0",
        "PyOpenGL-accelerate>=3.1.0",
        "Pillow>=9.0.0",
    ],
)
