# Navian Pulse Python SDK

```bash
pip install navian-pulse
```

## Quick Start

```python
from navian_pulse import PulseConfig, NavianClient

# Load TOML config — syncs SDK with engine's event types and field definitions
config = PulseConfig.from_toml_file("config/fraud-comprehensive.toml")

# Generate typed event classes (run once, check into repo)
# navian-codegen config/fraud-comprehensive.toml --output my_events.py

from my_events import PulseEventFactory

# Connect to engine
client = NavianClient("localhost:50051", config)

# Send typed events — IDE catches missing fields, SDK validates before sending
event = PulseEventFactory.cash_deposit(entity_token="cust-001", amount=9400.0)
result = client.send(event)
print(result)  # SendResult(response='ALLOW', rules=25, score=1.00)
```

## Features

- **TOML config sync** — parses known_types, fields, policies, agent scopes
- **Code generation** — typed dataclass per event type with required payload fields
- **Pre-send validation** — unknown event types rejected before network call
- **Field protection** — HMAC-SHA-256 + AES-256-GCM + HKDF (cross-SDK conformance)
- **gRPC + HTTP fallback** — connects via gRPC, falls back to REST
