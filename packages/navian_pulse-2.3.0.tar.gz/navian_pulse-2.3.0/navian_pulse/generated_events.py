"""Auto-generated typed event classes from TOML config.
Tenant: fraud-comprehensive-demo (Navian Pulse — Comprehensive Fraud Demo)
Event types: 38
Fields: 26
Policies: 18
"""

# DO NOT EDIT — regenerate with:
#   python -m navian_pulse.codegen <toml_path> --output <output_path>

import time
import uuid
from dataclasses import dataclass, field
from typing import Any


TENANT_ID = "fraud-comprehensive-demo"
KNOWN_TYPES = ['WIRE_OUT', 'WIRE_IN', 'ACH_OUT', 'ACH_IN', 'CASH_DEPOSIT', 'CASH_WITHDRAWAL', 'CHECK_DEPOSIT', 'INTERNAL_TRANSFER', 'ACH_PRE_COMMIT_CHECK', 'WIRE_PRE_COMMIT_CHECK', 'ACH_RETURN_RECEIVED', 'WIRE_REJECT_RECEIVED', 'LOGIN_SUCCESS', 'LOGIN_FAILED', 'MFA_CHALLENGE', 'MFA_SUCCESS', 'MFA_FAILED', 'PASSWORD_RESET_REQUESTED', 'PASSWORD_RESET_COMPLETED', 'DEVICE_REGISTERED', 'SESSION_CREATED', 'ACCOUNT_OPENED', 'PHONE_CHANGED', 'EMAIL_CHANGED', 'ADDRESS_CHANGED', 'BENEFICIARY_ADDED', 'CREDIT_APPLICATION_SUBMITTED', 'KYC_COMPLETED', 'BUREAU_INQUIRY_FLAG', 'RETURN_MAIL_FLAGGED', 'CREDIT_LINE_DRAW', 'PAYMENT_RECEIVED', 'PAYMENT_DUE_PASSED', 'STATEMENT_GENERATED', 'UTILIZATION_SAMPLED', 'SAR_CANDIDATE_CREATED', 'SAR_ANALYST_REVIEWED', 'SAR_FILED']


@dataclass
class AccountOpenedEvent:
    """Event type: ACCOUNT_OPENED
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "ACCOUNT_OPENED"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class AchInEvent:
    """Event type: ACH_IN
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "ACH_IN"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class AchOutEvent:
    """Event type: ACH_OUT
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "ACH_OUT"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class AchPreCommitCheckEvent:
    """Event type: ACH_PRE_COMMIT_CHECK
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "ACH_PRE_COMMIT_CHECK"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class AchReturnReceivedEvent:
    """Event type: ACH_RETURN_RECEIVED
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "ACH_RETURN_RECEIVED"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class AddressChangedEvent:
    """Event type: ADDRESS_CHANGED
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "ADDRESS_CHANGED"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class BeneficiaryAddedEvent:
    """Event type: BENEFICIARY_ADDED
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "BENEFICIARY_ADDED"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class BureauInquiryFlagEvent:
    """Event type: BUREAU_INQUIRY_FLAG
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "BUREAU_INQUIRY_FLAG"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class CashDepositEvent:
    """Event type: CASH_DEPOSIT
    Required payload fields: amount
    """
    entity_token: str
    amount: float
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "CASH_DEPOSIT"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        payload["amount"] = self.amount
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class CashWithdrawalEvent:
    """Event type: CASH_WITHDRAWAL
    Required payload fields: amount
    """
    entity_token: str
    amount: float
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "CASH_WITHDRAWAL"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        payload["amount"] = self.amount
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class CheckDepositEvent:
    """Event type: CHECK_DEPOSIT
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "CHECK_DEPOSIT"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class CreditApplicationSubmittedEvent:
    """Event type: CREDIT_APPLICATION_SUBMITTED
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "CREDIT_APPLICATION_SUBMITTED"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class CreditLineDrawEvent:
    """Event type: CREDIT_LINE_DRAW
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "CREDIT_LINE_DRAW"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class DeviceRegisteredEvent:
    """Event type: DEVICE_REGISTERED
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "DEVICE_REGISTERED"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class EmailChangedEvent:
    """Event type: EMAIL_CHANGED
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "EMAIL_CHANGED"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class InternalTransferEvent:
    """Event type: INTERNAL_TRANSFER
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "INTERNAL_TRANSFER"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class KycCompletedEvent:
    """Event type: KYC_COMPLETED
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "KYC_COMPLETED"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class LoginFailedEvent:
    """Event type: LOGIN_FAILED
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "LOGIN_FAILED"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class LoginSuccessEvent:
    """Event type: LOGIN_SUCCESS
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "LOGIN_SUCCESS"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class MfaChallengeEvent:
    """Event type: MFA_CHALLENGE
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "MFA_CHALLENGE"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class MfaFailedEvent:
    """Event type: MFA_FAILED
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "MFA_FAILED"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class MfaSuccessEvent:
    """Event type: MFA_SUCCESS
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "MFA_SUCCESS"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class PasswordResetCompletedEvent:
    """Event type: PASSWORD_RESET_COMPLETED
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "PASSWORD_RESET_COMPLETED"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class PasswordResetRequestedEvent:
    """Event type: PASSWORD_RESET_REQUESTED
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "PASSWORD_RESET_REQUESTED"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class PaymentDuePassedEvent:
    """Event type: PAYMENT_DUE_PASSED
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "PAYMENT_DUE_PASSED"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class PaymentReceivedEvent:
    """Event type: PAYMENT_RECEIVED
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "PAYMENT_RECEIVED"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class PhoneChangedEvent:
    """Event type: PHONE_CHANGED
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "PHONE_CHANGED"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class ReturnMailFlaggedEvent:
    """Event type: RETURN_MAIL_FLAGGED
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "RETURN_MAIL_FLAGGED"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class SarAnalystReviewedEvent:
    """Event type: SAR_ANALYST_REVIEWED
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "SAR_ANALYST_REVIEWED"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class SarCandidateCreatedEvent:
    """Event type: SAR_CANDIDATE_CREATED
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "SAR_CANDIDATE_CREATED"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class SarFiledEvent:
    """Event type: SAR_FILED
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "SAR_FILED"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class SessionCreatedEvent:
    """Event type: SESSION_CREATED
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "SESSION_CREATED"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class StatementGeneratedEvent:
    """Event type: STATEMENT_GENERATED
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "STATEMENT_GENERATED"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class UtilizationSampledEvent:
    """Event type: UTILIZATION_SAMPLED
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "UTILIZATION_SAMPLED"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class WireInEvent:
    """Event type: WIRE_IN
    Required payload fields: amount
    """
    entity_token: str
    amount: float
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "WIRE_IN"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        payload["amount"] = self.amount
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class WireOutEvent:
    """Event type: WIRE_OUT
    Required payload fields: amount
    """
    entity_token: str
    amount: float
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "WIRE_OUT"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        payload["amount"] = self.amount
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class WirePreCommitCheckEvent:
    """Event type: WIRE_PRE_COMMIT_CHECK
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "WIRE_PRE_COMMIT_CHECK"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }

@dataclass
class WireRejectReceivedEvent:
    """Event type: WIRE_REJECT_RECEIVED
    """
    entity_token: str
    extra: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))

    EVENT_TYPE: str = "WIRE_REJECT_RECEIVED"

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.extra)
        return {
            "event_type": self.EVENT_TYPE,
            "entity_token": self.entity_token,
            "event_id": self.event_id,
            "occurred_at_ms": self.occurred_at_ms,
            "payload": payload,
        }


class PulseEventFactory:
    """Typed event builders for fraud-comprehensive-demo.
    Auto-complete and type-check at edit time."""

    @staticmethod
    def account_opened(entity_token: str, **extra: Any) -> AccountOpenedEvent:
        return AccountOpenedEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def ach_in(entity_token: str, **extra: Any) -> AchInEvent:
        return AchInEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def ach_out(entity_token: str, **extra: Any) -> AchOutEvent:
        return AchOutEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def ach_pre_commit_check(entity_token: str, **extra: Any) -> AchPreCommitCheckEvent:
        return AchPreCommitCheckEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def ach_return_received(entity_token: str, **extra: Any) -> AchReturnReceivedEvent:
        return AchReturnReceivedEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def address_changed(entity_token: str, **extra: Any) -> AddressChangedEvent:
        return AddressChangedEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def beneficiary_added(entity_token: str, **extra: Any) -> BeneficiaryAddedEvent:
        return BeneficiaryAddedEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def bureau_inquiry_flag(entity_token: str, **extra: Any) -> BureauInquiryFlagEvent:
        return BureauInquiryFlagEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def cash_deposit(entity_token: str, amount: float, **extra: Any) -> CashDepositEvent:
        return CashDepositEvent(entity_token=entity_token, amount=amount, extra=dict(extra))

    @staticmethod
    def cash_withdrawal(entity_token: str, amount: float, **extra: Any) -> CashWithdrawalEvent:
        return CashWithdrawalEvent(entity_token=entity_token, amount=amount, extra=dict(extra))

    @staticmethod
    def check_deposit(entity_token: str, **extra: Any) -> CheckDepositEvent:
        return CheckDepositEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def credit_application_submitted(entity_token: str, **extra: Any) -> CreditApplicationSubmittedEvent:
        return CreditApplicationSubmittedEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def credit_line_draw(entity_token: str, **extra: Any) -> CreditLineDrawEvent:
        return CreditLineDrawEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def device_registered(entity_token: str, **extra: Any) -> DeviceRegisteredEvent:
        return DeviceRegisteredEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def email_changed(entity_token: str, **extra: Any) -> EmailChangedEvent:
        return EmailChangedEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def internal_transfer(entity_token: str, **extra: Any) -> InternalTransferEvent:
        return InternalTransferEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def kyc_completed(entity_token: str, **extra: Any) -> KycCompletedEvent:
        return KycCompletedEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def login_failed(entity_token: str, **extra: Any) -> LoginFailedEvent:
        return LoginFailedEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def login_success(entity_token: str, **extra: Any) -> LoginSuccessEvent:
        return LoginSuccessEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def mfa_challenge(entity_token: str, **extra: Any) -> MfaChallengeEvent:
        return MfaChallengeEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def mfa_failed(entity_token: str, **extra: Any) -> MfaFailedEvent:
        return MfaFailedEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def mfa_success(entity_token: str, **extra: Any) -> MfaSuccessEvent:
        return MfaSuccessEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def password_reset_completed(entity_token: str, **extra: Any) -> PasswordResetCompletedEvent:
        return PasswordResetCompletedEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def password_reset_requested(entity_token: str, **extra: Any) -> PasswordResetRequestedEvent:
        return PasswordResetRequestedEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def payment_due_passed(entity_token: str, **extra: Any) -> PaymentDuePassedEvent:
        return PaymentDuePassedEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def payment_received(entity_token: str, **extra: Any) -> PaymentReceivedEvent:
        return PaymentReceivedEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def phone_changed(entity_token: str, **extra: Any) -> PhoneChangedEvent:
        return PhoneChangedEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def return_mail_flagged(entity_token: str, **extra: Any) -> ReturnMailFlaggedEvent:
        return ReturnMailFlaggedEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def sar_analyst_reviewed(entity_token: str, **extra: Any) -> SarAnalystReviewedEvent:
        return SarAnalystReviewedEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def sar_candidate_created(entity_token: str, **extra: Any) -> SarCandidateCreatedEvent:
        return SarCandidateCreatedEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def sar_filed(entity_token: str, **extra: Any) -> SarFiledEvent:
        return SarFiledEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def session_created(entity_token: str, **extra: Any) -> SessionCreatedEvent:
        return SessionCreatedEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def statement_generated(entity_token: str, **extra: Any) -> StatementGeneratedEvent:
        return StatementGeneratedEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def utilization_sampled(entity_token: str, **extra: Any) -> UtilizationSampledEvent:
        return UtilizationSampledEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def wire_in(entity_token: str, amount: float, **extra: Any) -> WireInEvent:
        return WireInEvent(entity_token=entity_token, amount=amount, extra=dict(extra))

    @staticmethod
    def wire_out(entity_token: str, amount: float, **extra: Any) -> WireOutEvent:
        return WireOutEvent(entity_token=entity_token, amount=amount, extra=dict(extra))

    @staticmethod
    def wire_pre_commit_check(entity_token: str, **extra: Any) -> WirePreCommitCheckEvent:
        return WirePreCommitCheckEvent(entity_token=entity_token, extra=dict(extra))

    @staticmethod
    def wire_reject_received(entity_token: str, **extra: Any) -> WireRejectReceivedEvent:
        return WireRejectReceivedEvent(entity_token=entity_token, extra=dict(extra))


# Runtime validation helper
VALID_EVENT_TYPES: set[str] = {'ACCOUNT_OPENED', 'ACH_IN', 'ACH_OUT', 'ACH_PRE_COMMIT_CHECK', 'ACH_RETURN_RECEIVED', 'ADDRESS_CHANGED', 'BENEFICIARY_ADDED', 'BUREAU_INQUIRY_FLAG', 'CASH_DEPOSIT', 'CASH_WITHDRAWAL', 'CHECK_DEPOSIT', 'CREDIT_APPLICATION_SUBMITTED', 'CREDIT_LINE_DRAW', 'DEVICE_REGISTERED', 'EMAIL_CHANGED', 'INTERNAL_TRANSFER', 'KYC_COMPLETED', 'LOGIN_FAILED', 'LOGIN_SUCCESS', 'MFA_CHALLENGE', 'MFA_FAILED', 'MFA_SUCCESS', 'PASSWORD_RESET_COMPLETED', 'PASSWORD_RESET_REQUESTED', 'PAYMENT_DUE_PASSED', 'PAYMENT_RECEIVED', 'PHONE_CHANGED', 'RETURN_MAIL_FLAGGED', 'SAR_ANALYST_REVIEWED', 'SAR_CANDIDATE_CREATED', 'SAR_FILED', 'SESSION_CREATED', 'STATEMENT_GENERATED', 'UTILIZATION_SAMPLED', 'WIRE_IN', 'WIRE_OUT', 'WIRE_PRE_COMMIT_CHECK', 'WIRE_REJECT_RECEIVED'}
