"""NavianEvent — the universal event type sent to Pulse."""

import time
import uuid
from dataclasses import dataclass, field
from typing import Any


@dataclass
class NavianEvent:
    event_type: str
    entity_token: str
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))
    payload: dict[str, Any] = field(default_factory=dict)

    def with_field(self, key: str, value: Any) -> "NavianEvent":
        self.payload[key] = value
        return self

    def with_fields(self, fields: dict[str, Any]) -> "NavianEvent":
        self.payload.update(fields)
        return self

    def with_occurred_at(self, ms: int) -> "NavianEvent":
        self.occurred_at_ms = ms
        return self
