import hashlib
import hmac
import os
from enum import Enum
from typing import Any

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes


class ProtectionMode(Enum):
    HASH = "HASH"
    ENCRYPT = "ENCRYPT"
    MASK_LAST4 = "MASK_LAST4"
    MASK_FIRST6 = "MASK_FIRST6"
    REDACT = "REDACT"
    PASS = "PASS"


_DOMAIN_MAP = {
    "pan": "pan",
    "ssn": "ssn",
    "routing_number": "routing",
    "account_number": "account",
    "email": "email-corr",
    "phone": "phone-corr",
    "entity_token": "entity",
}


class NavianFieldProtector:
    def __init__(self, hmac_key: bytes, aes_key: bytes,
                 field_map: dict[str, ProtectionMode]):
        if len(hmac_key) < 32:
            raise ValueError("HMAC key must be at least 32 bytes")
        if len(aes_key) != 32:
            raise ValueError("AES key must be exactly 32 bytes")
        self._hmac_key = bytearray(hmac_key)
        self._aes_key = bytearray(aes_key)
        self._field_map = dict(field_map)

    @classmethod
    def from_master_key(cls, master_key: bytes, tenant_id: str,
                        field_map: dict[str, ProtectionMode]) -> "NavianFieldProtector":
        hmac_key = cls._derive_key(master_key, f"pulse-hmac-v1:{tenant_id}", 48)
        aes_key = cls._derive_key(master_key, f"pulse-aes-v1:{tenant_id}", 32)
        return cls(hmac_key, aes_key, field_map)

    @staticmethod
    def _derive_key(ikm: bytes, info: str, length: int = 48) -> bytes:
        hkdf = HKDF(
            algorithm=hashes.SHA384(),
            length=length,
            salt=b"\x00" * 48,
            info=info.encode("utf-8"),
        )
        return hkdf.derive(ikm)

    def protect_entity_token(self, raw_value: str) -> str:
        return self._hmac_hex("entity", raw_value)

    def protect_field(self, field_name: str, raw_value: str) -> str:
        mode = self._field_map.get(field_name, ProtectionMode.PASS)

        if mode == ProtectionMode.HASH:
            domain = _DOMAIN_MAP.get(field_name, field_name)
            return f"HASH:{self._hmac_hex(domain, raw_value)}"
        elif mode == ProtectionMode.ENCRYPT:
            return self._encrypt(field_name, raw_value)
        elif mode == ProtectionMode.MASK_LAST4:
            if len(raw_value) <= 4:
                return raw_value
            return "*" * (len(raw_value) - 4) + raw_value[-4:]
        elif mode == ProtectionMode.MASK_FIRST6:
            if len(raw_value) <= 6:
                return raw_value
            return raw_value[:6] + "*" * (len(raw_value) - 6)
        elif mode == ProtectionMode.REDACT:
            return "[REDACTED]"
        else:
            return raw_value

    def protect_event(self, event: dict[str, Any]) -> dict[str, Any]:
        result = dict(event)
        if "entity_token" in result:
            result["entity_token"] = self.protect_entity_token(str(result["entity_token"]))
        if "payload" in result and isinstance(result["payload"], dict):
            result["payload"] = {
                k: self.protect_field(k, str(v))
                for k, v in result["payload"].items()
            }
        return result

    def decrypt_field(self, field_name: str, protected_value: str) -> str:
        if not protected_value.startswith("ENC:v1:"):
            raise ValueError("Not an encrypted value (expected ENC:v1: prefix)")
        rest = protected_value[7:]
        parts = rest.split(":", 2)
        if len(parts) != 3:
            raise ValueError("Malformed ENC:v1: value")

        nonce = bytes.fromhex(parts[0])
        ciphertext = bytes.fromhex(parts[1])
        tag = bytes.fromhex(parts[2])

        aesgcm = AESGCM(bytes(self._aes_key))
        plaintext = aesgcm.decrypt(nonce, ciphertext + tag, field_name.encode("utf-8"))
        return plaintext.decode("utf-8")

    def destroy(self) -> None:
        for i in range(len(self._hmac_key)):
            self._hmac_key[i] = 0
        for i in range(len(self._aes_key)):
            self._aes_key[i] = 0

    def _hmac_hex(self, domain: str, value: str) -> str:
        msg = f"{domain}:{value}".encode("utf-8")
        return hmac.new(bytes(self._hmac_key), msg, hashlib.sha384).hexdigest()

    def _encrypt(self, field_name: str, plaintext: str) -> str:
        nonce = os.urandom(12)
        aesgcm = AESGCM(bytes(self._aes_key))
        ct_and_tag = aesgcm.encrypt(nonce, plaintext.encode("utf-8"),
                                     field_name.encode("utf-8"))
        ct = ct_and_tag[:-16]
        tag = ct_and_tag[-16:]
        return f"ENC:v1:{nonce.hex()}:{ct.hex()}:{tag.hex()}"
