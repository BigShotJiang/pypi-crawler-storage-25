from .field_protector import NavianFieldProtector, ProtectionMode
from .config import PulseConfig, FieldDef, PolicyDef, WorkflowDef, AgentScope
from .event import NavianEvent
from .validation import validate_event, validate_batch, ValidationResult
from .client import NavianClient, SendResult, ValidationError

__all__ = [
    "NavianFieldProtector", "ProtectionMode",
    "PulseConfig", "FieldDef", "PolicyDef", "WorkflowDef", "AgentScope",
    "NavianEvent",
    "validate_event", "validate_batch", "ValidationResult",
    "NavianClient", "SendResult", "ValidationError",
]

# Lazy imports for optional groups — these only succeed if the user installed
# the corresponding extra (`pip install navian-pulse[mcp]` / `[llm]`).
# Raising ImportError here would break installations that opt out, so we
# defer to attribute access.

def __getattr__(name: str):  # noqa: D401 — module-level dunder
    """PEP 562 lazy import for optional extras."""
    if name in {"MCPClient", "MCPError", "MCPResponse"}:
        from .mcp_client import MCPClient, MCPError, MCPResponse  # noqa: F401
        return locals()[name]
    if name in {"LLMConfig", "LLMProvider", "make_provider"}:
        from .llm import LLMConfig, LLMProvider, make_provider  # noqa: F401
        return locals()[name]
    raise AttributeError(f"module 'navian_pulse' has no attribute {name!r}")
