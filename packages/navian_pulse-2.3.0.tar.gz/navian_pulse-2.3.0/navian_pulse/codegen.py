"""Generate typed Python event classes from a TOML config file.

Run this at build time (or as a pre-commit hook) to produce a typed
module that your IDE and mypy/pyright can check at edit time:

    python -m navian_pulse.codegen config/fraud-comprehensive.toml --output events.py

The generated module contains:
  - One class per event_type (e.g. CashDepositEvent) with typed payload fields
  - A PulseEventFactory with a method per event_type for auto-complete
  - Type errors if you pass wrong payload fields or miss required ones
"""

import sys
import textwrap
from pathlib import Path
from .config import PulseConfig


def generate_event_module(config: PulseConfig) -> str:
    lines: list[str] = []
    lines.append('"""Auto-generated typed event classes from TOML config.')
    lines.append(f'Tenant: {config.tenant_id} ({config.tenant_name})')
    lines.append(f'Event types: {len(config.known_types)}')
    lines.append(f'Fields: {len(config.fields)}')
    lines.append(f'Policies: {len(config.policies)}')
    lines.append('"""')
    lines.append('')
    lines.append('# DO NOT EDIT — regenerate with:')
    lines.append('#   python -m navian_pulse.codegen <toml_path> --output <output_path>')
    lines.append('')
    lines.append('import time')
    lines.append('import uuid')
    lines.append('from dataclasses import dataclass, field')
    lines.append('from typing import Any')
    lines.append('')
    lines.append('')
    lines.append(f'TENANT_ID = "{config.tenant_id}"')
    lines.append(f'KNOWN_TYPES = {config.known_types!r}')
    lines.append('')

    # Build per-event-type required payload fields
    required_by_type: dict[str, set[str]] = {}
    for fd in config.fields:
        if fd.source:
            for et in fd.set_on:
                required_by_type.setdefault(et, set()).add(fd.source)

    # Generate one dataclass per event type
    for et in sorted(config.known_types):
        class_name = _to_class_name(et)
        required = sorted(required_by_type.get(et, set()))

        lines.append('')
        lines.append('@dataclass')
        lines.append(f'class {class_name}:')
        lines.append(f'    """Event type: {et}')
        if required:
            lines.append(f'    Required payload fields: {", ".join(required)}')
        lines.append(f'    """')
        lines.append(f'    entity_token: str')

        # Required payload fields as typed parameters
        for rf in required:
            lines.append(f'    {rf}: float')

        # Optional extra payload
        lines.append(f'    extra: dict[str, Any] = field(default_factory=dict)')
        lines.append(f'    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))')
        lines.append(f'    occurred_at_ms: int = field(default_factory=lambda: int(time.time() * 1000))')
        lines.append('')
        lines.append(f'    EVENT_TYPE: str = "{et}"')
        lines.append('')
        lines.append(f'    def to_dict(self) -> dict[str, Any]:')
        lines.append(f'        payload = dict(self.extra)')
        for rf in required:
            lines.append(f'        payload["{rf}"] = self.{rf}')
        lines.append(f'        return {{')
        lines.append(f'            "event_type": self.EVENT_TYPE,')
        lines.append(f'            "entity_token": self.entity_token,')
        lines.append(f'            "event_id": self.event_id,')
        lines.append(f'            "occurred_at_ms": self.occurred_at_ms,')
        lines.append(f'            "payload": payload,')
        lines.append(f'        }}')

    # Generate the factory class
    lines.append('')
    lines.append('')
    lines.append('class PulseEventFactory:')
    lines.append(f'    """Typed event builders for {config.tenant_id}.')
    lines.append(f'    Auto-complete and type-check at edit time."""')
    lines.append('')

    for et in sorted(config.known_types):
        class_name = _to_class_name(et)
        method_name = et.lower()
        required = sorted(required_by_type.get(et, set()))

        params = ['entity_token: str']
        for rf in required:
            params.append(f'{rf}: float')
        params.append('**extra: Any')
        param_str = ', '.join(params)

        args = ['entity_token=entity_token']
        for rf in required:
            args.append(f'{rf}={rf}')
        args.append('extra=dict(extra)')
        args_str = ', '.join(args)

        lines.append(f'    @staticmethod')
        lines.append(f'    def {method_name}({param_str}) -> {class_name}:')
        lines.append(f'        return {class_name}({args_str})')
        lines.append('')

    # Generate the VALID_TYPES set for runtime double-check
    lines.append('')
    lines.append('# Runtime validation helper')
    lines.append(f'VALID_EVENT_TYPES: set[str] = {{{", ".join(repr(t) for t in sorted(config.known_types))}}}')
    lines.append('')

    return '\n'.join(lines)


def _to_class_name(event_type: str) -> str:
    """CASH_DEPOSIT → CashDepositEvent"""
    parts = event_type.lower().split('_')
    return ''.join(p.capitalize() for p in parts) + 'Event'


def main():
    if len(sys.argv) < 2:
        print("Usage: python -m navian_pulse.codegen <toml_path> [--output <path>]")
        sys.exit(1)

    toml_path = sys.argv[1]
    output_path = None
    if '--output' in sys.argv:
        idx = sys.argv.index('--output')
        if idx + 1 < len(sys.argv):
            output_path = sys.argv[idx + 1]

    config = PulseConfig.from_toml_file(toml_path)
    code = generate_event_module(config)

    if output_path:
        Path(output_path).write_text(code)
        print(f"Generated {output_path}: {len(config.known_types)} event types, "
              f"{len(config.fields)} fields, {len(config.policies)} policies")
    else:
        print(code)


if __name__ == '__main__':
    main()
