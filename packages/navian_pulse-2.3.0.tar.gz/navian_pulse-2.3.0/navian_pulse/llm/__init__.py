"""Model-agnostic LLM adapter layer.

The customer brings the model. This package gives you a single interface
(:class:`LLMProvider`) that wraps Anthropic, OpenAI, AWS Bedrock, GCP Vertex,
Azure OpenAI, and any OpenAI-compatible endpoint behind a uniform API. A
``none`` provider lets you run memory-grounded code paths offline without
any model calls — useful for CI, air-gapped deployments, and unit tests.

Configure via the ``[llm]`` block in your Pulse TOML:

    [llm]
    provider = "anthropic"
    model    = "claude-opus-4-7"
    api_key_env = "ANTHROPIC_API_KEY"

Or programmatically:

    from navian_pulse import LLMConfig, make_provider
    cfg = LLMConfig(provider="anthropic", model="claude-opus-4-7")
    provider = make_provider(cfg)
    completion = await provider.complete(messages=[...])

Switching providers requires only the TOML change — no Python edits.
"""

from .base import LLMConfig, LLMProvider, Message, Completion
from .factory import make_provider

__all__ = ["LLMConfig", "LLMProvider", "Message", "Completion", "make_provider"]
