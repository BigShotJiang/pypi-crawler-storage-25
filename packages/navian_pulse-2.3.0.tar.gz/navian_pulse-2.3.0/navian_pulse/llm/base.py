"""Provider-agnostic types — what every LLM backend needs to look like.

The interface is intentionally narrow: complete + stream + cost_estimate.
Tool-use, structured outputs, multimodal, etc. live on top of `complete`'s
``extras`` field rather than as separate methods, so a new provider can ship
without rewriting every consumer.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Optional


# ─── Configuration ─────────────────────────────────────────────────────


@dataclass
class LLMConfig:
    """Provider configuration parsed from the TOML ``[llm]`` block.

    Only ``provider`` and ``model`` are required. The rest are provider-
    specific; the factory dispatches based on ``provider`` and consumes
    only the fields that apply.
    """

    provider: str
    """One of: anthropic, openai, openai-compat, bedrock, vertex, azure, none."""

    model: str
    """Model identifier in the provider's namespace."""

    api_key_env: Optional[str] = None
    """Environment variable holding the API key. Looked up at provider init."""

    api_key: Optional[str] = None
    """Direct API key. Prefer ``api_key_env`` for everything except tests."""

    endpoint: Optional[str] = None
    """Custom endpoint URL — used by openai-compat (Ollama, vLLM, TGI), Azure
    (the resource endpoint), and anyone running a private model gateway."""

    region: Optional[str] = None
    """Cloud region — used by Bedrock and Vertex."""

    project: Optional[str] = None
    """GCP project — Vertex only."""

    default_max_tokens: int = 1024
    """Token budget when the caller doesn't specify."""

    default_temperature: float = 0.0
    """Temperature when the caller doesn't specify. Default 0.0 because most
    Pulse use cases (memory-grounded queries, signal explanations,
    investigation hypotheses) want determinism over creativity."""

    extras: dict[str, Any] = field(default_factory=dict)
    """Provider-specific knobs. Stored as a dict so unknown keys don't break
    older configs when newer providers ship."""


# ─── Wire types — provider-agnostic ────────────────────────────────────


@dataclass
class Message:
    """One chat message. ``role`` is one of ``system`` / ``user`` /
    ``assistant``; some providers also accept ``tool``. ``name`` is optional
    and used for multi-agent setups where messages come from named entities."""

    role: str
    content: str
    name: Optional[str] = None


@dataclass
class Completion:
    """Provider-agnostic completion result.

    ``text`` is the assistant's reply. ``prompt_tokens`` and
    ``completion_tokens`` are the post-call usage counts (used by Pulse's
    cost-cap enforcement). ``stop_reason`` is the provider's reason — one of
    ``end_turn`` / ``max_tokens`` / ``stop_sequence`` / ``content_filter`` /
    other. ``raw`` is the original provider response for debugging."""

    text: str
    prompt_tokens: int
    completion_tokens: int
    stop_reason: str
    model: str
    raw: Any = None


@dataclass
class StreamChunk:
    """One delta in a streaming completion."""

    text_delta: str
    is_final: bool = False
    raw: Any = None


# ─── Provider abstract base class ──────────────────────────────────────


class LLMProvider(ABC):
    """Implementations: AnthropicProvider, OpenAIProvider, BedrockProvider,
    VertexProvider, AzureProvider, OpenAICompatProvider, NoneProvider."""

    def __init__(self, config: LLMConfig):
        self.config = config

    @abstractmethod
    async def complete(
        self,
        messages: list[Message],
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        tools: Optional[list[dict]] = None,
    ) -> Completion:
        """Single-shot completion. Raises if the provider rejects the call."""

    @abstractmethod
    async def stream(
        self,
        messages: list[Message],
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        tools: Optional[list[dict]] = None,
    ) -> AsyncIterator[StreamChunk]:
        """Streaming completion. Yields :class:`StreamChunk` deltas; the last
        one has ``is_final=True``. Implementations should set ``text_delta``
        to ``""`` on the final chunk if no text was emitted (e.g. tool call)."""

    def cost_estimate(self, prompt_tokens: int, completion_tokens: int) -> float:
        """Estimated USD for a call with the given token counts. Default
        implementation returns 0.0; providers override to read their pricing
        tables. Used for Pulse's per-tenant cost reporting."""
        return 0.0

    def name(self) -> str:
        """Short identifier for logs / metrics. ``provider/model``."""
        return f"{self.config.provider}/{self.config.model}"
