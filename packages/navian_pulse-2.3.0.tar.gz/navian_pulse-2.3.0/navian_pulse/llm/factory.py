"""Provider factory — `LLMConfig.provider` → concrete LLMProvider."""

from __future__ import annotations

from .base import LLMConfig, LLMProvider


def make_provider(config: LLMConfig) -> LLMProvider:
    """Return the right LLMProvider for ``config.provider``.

    Raises ImportError if the user picked a provider whose extras aren't
    installed — keeping the error close to the configuration mistake."""
    p = config.provider.lower()

    if p == "none":
        from .none_provider import NoneProvider

        return NoneProvider(config)

    if p == "anthropic":
        from .anthropic_provider import AnthropicProvider

        return AnthropicProvider(config)

    if p in {"openai", "openai-compat", "ollama", "vllm", "tgi"}:
        from .openai_provider import OpenAIProvider, OpenAICompatProvider

        if p == "openai":
            return OpenAIProvider(config)
        return OpenAICompatProvider(config)

    if p == "bedrock":
        # Lazy implementation deferred — Phase 1 ships the interface only.
        # Phase 1 acceptance is "no-LLM mode runs without API keys"; the
        # Bedrock / Vertex / Azure providers are scaffolded as stubs so a
        # follow-up commit can fill them in without breaking the factory.
        raise NotImplementedError(
            "Bedrock provider scaffolded but not implemented. "
            "Track A3 follow-up. Use provider='openai-compat' with a "
            "Bedrock-via-LiteLLM proxy in the meantime."
        )

    if p == "vertex":
        raise NotImplementedError(
            "Vertex provider scaffolded but not implemented. Track A3 follow-up."
        )

    if p == "azure":
        raise NotImplementedError(
            "Azure provider scaffolded but not implemented — use provider='openai' "
            "with endpoint=<azure resource> + api_key_env=AZURE_OPENAI_API_KEY "
            "as a workaround."
        )

    raise ValueError(f"unknown LLM provider: {config.provider!r}")
