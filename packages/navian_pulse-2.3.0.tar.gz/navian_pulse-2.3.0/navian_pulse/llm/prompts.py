"""Prompt templates used by Pulse-grounded code paths.

Templates are plain strings with ``{slot}`` markers — keep them simple and
auditable. Values are formatted via ``str.format``, so use double braces to
include literal ones if a template ever needs them.

These are also what Visualize Q3 ("Explain this signal", per-tab AI assistant
drawer) will reuse — Memory ships them once, Visualize imports them. Keeps
voice + structure consistent across the dashboard and the SDK.
"""

from __future__ import annotations

# When the agent has pulled `pulse.memory.context` and wants the model to
# reason over the context card before producing an answer.
MEMORY_GROUNDED_QUERY = """\
You are answering a question about an entity in the Navian Pulse system.
You have been given a token-budgeted context card containing:
  • semantic baselines (what is normal for this entity)
  • episodic events (recent activity)
  • procedural rules (which policies have fired and why)

Context card:
{context_card}

Question:
{question}

Use only the information in the context card. If the answer is not in the
card, say so explicitly — do not speculate.
"""

# When an alert / drift / SLO breach fires and the operator wants prose.
EXPLAIN_SIGNAL = """\
A signal fired in the Navian Pulse {vertical} workflow.

Signal: {signal_name}
Stage: {stage}
Cohort: {cohort}
Today: {today_value}
Baseline: {baseline_value}
Delta: {delta}

Explain the signal in 2-3 sentences for a {persona}. Include:
  1. what happened in plain language,
  2. why this matters now (not a generic explanation),
  3. one specific next step.

Do not restate the numbers. Do not speculate about causes the data does not
support. If the delta is small, say so — don't manufacture severity.
"""

# When the operator clicks an entity and wants "what's odd right now"
# auto-summarized — used by Q4's investigation companion too.
INVESTIGATION_HYPOTHESIS = """\
Form an investigation hypothesis for {entity_id} in the {vertical} workflow.

Recent context (from pulse.memory.context):
{context_card}

Similar past alerts (from pulse.memory.recall, episodic):
{episodic}

Procedural rules currently watching this entity:
{procedural}

Output a one-paragraph hypothesis a {persona} would write. Format:
  • LEAD with the most likely cause given the data,
  • cite at least one specific signal or past event,
  • end with the single most diagnostic next query.

If multiple plausible causes exist with similar evidence, name them and rank
them. Don't pad with caveats.
"""
