"""OpenAI provider (and the OpenAI-compatible variant for vLLM / Ollama / TGI).

Two providers in one module because the wire shape is identical — only the
endpoint URL differs. Bedrock and Vertex are different enough to warrant
separate files.
"""

from __future__ import annotations

import os
from typing import AsyncIterator, Optional

from .base import Completion, LLMConfig, LLMProvider, Message, StreamChunk


class OpenAIProvider(LLMProvider):
    def __init__(self, config: LLMConfig):
        super().__init__(config)
        try:
            from openai import AsyncOpenAI  # type: ignore
        except ImportError as e:  # pragma: no cover
            raise ImportError(
                "OpenAIProvider requires the [llm] extra. "
                "Install with: pip install navian-pulse[llm]"
            ) from e

        api_key = config.api_key or (
            os.getenv(config.api_key_env or "OPENAI_API_KEY")
        )
        kwargs: dict = {"api_key": api_key}
        if config.endpoint:
            kwargs["base_url"] = config.endpoint
        self._client = AsyncOpenAI(**kwargs)

    async def complete(
        self,
        messages: list[Message],
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        tools: Optional[list[dict]] = None,
    ) -> Completion:
        chat_msgs = [
            {"role": m.role, "content": m.content}
            + ({"name": m.name} if m.name else {})
            for m in messages
        ]
        kwargs: dict = {
            "model": self.config.model,
            "messages": chat_msgs,
            "max_tokens": max_tokens or self.config.default_max_tokens,
            "temperature": temperature
            if temperature is not None
            else self.config.default_temperature,
        }
        if tools:
            kwargs["tools"] = tools

        resp = await self._client.chat.completions.create(**kwargs)
        choice = resp.choices[0]
        return Completion(
            text=choice.message.content or "",
            prompt_tokens=resp.usage.prompt_tokens if resp.usage else 0,
            completion_tokens=resp.usage.completion_tokens if resp.usage else 0,
            stop_reason=choice.finish_reason or "stop",
            model=resp.model,
            raw=resp,
        )

    async def stream(
        self,
        messages: list[Message],
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        tools: Optional[list[dict]] = None,
    ) -> AsyncIterator[StreamChunk]:
        chat_msgs = [{"role": m.role, "content": m.content} for m in messages]
        kwargs: dict = {
            "model": self.config.model,
            "messages": chat_msgs,
            "max_tokens": max_tokens or self.config.default_max_tokens,
            "temperature": temperature
            if temperature is not None
            else self.config.default_temperature,
            "stream": True,
        }
        if tools:
            kwargs["tools"] = tools

        stream = await self._client.chat.completions.create(**kwargs)
        async for chunk in stream:
            if chunk.choices and chunk.choices[0].delta.content:
                yield StreamChunk(
                    text_delta=chunk.choices[0].delta.content,
                    is_final=False,
                    raw=chunk,
                )
        yield StreamChunk(text_delta="", is_final=True)


class OpenAICompatProvider(OpenAIProvider):
    """For vLLM, Ollama, TGI, LM Studio, and any other OpenAI-API-compatible
    endpoint. Identical wire shape; the only difference is that ``endpoint``
    is required and ``api_key`` is optional (some local runtimes accept any
    string)."""

    def __init__(self, config: LLMConfig):
        if not config.endpoint:
            raise ValueError(
                "openai-compat provider requires `endpoint` "
                "(e.g. http://localhost:11434/v1 for Ollama)"
            )
        # Many local runtimes accept any non-empty string as the API key.
        # Normalize to "not-needed" so users don't have to set a fake env var.
        if not config.api_key and not config.api_key_env:
            config.api_key = "not-needed"
        super().__init__(config)
