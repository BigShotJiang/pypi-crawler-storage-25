"""``none`` provider — no model calls, ever.

Two real use cases:
  1. **CI without API keys.** The memory-grounded code paths still want to
     exercise prompt construction, scope filtering, and response handling;
     the ``none`` provider returns the constructed prompt verbatim so
     downstream code gets a deterministic Completion to react to.
  2. **Air-gapped deployments.** Some regulated customers refuse outbound
     model calls. With ``provider = "none"``, everything still works —
     no errors, just no model in the loop.

This provider records prompt+completion token counts honestly (computed from
character length / 4 as a rough heuristic) so cost-cap accounting still
behaves consistently.
"""

from __future__ import annotations

from typing import AsyncIterator, Optional

from .base import Completion, LLMConfig, LLMProvider, Message, StreamChunk


class NoneProvider(LLMProvider):
    """Implements LLMProvider without making any network calls."""

    def __init__(self, config: LLMConfig):
        super().__init__(config)

    async def complete(
        self,
        messages: list[Message],
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        tools: Optional[list[dict]] = None,
    ) -> Completion:
        # Echo the last user message back verbatim, prefixed with a marker
        # so callers can see at a glance that this came from the no-LLM path.
        last_user = next(
            (m.content for m in reversed(messages) if m.role == "user"),
            "",
        )
        text = f"[no-llm] {last_user}"
        prompt_tokens = sum(_rough_tokens(m.content) for m in messages)
        completion_tokens = _rough_tokens(text)
        return Completion(
            text=text,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            stop_reason="end_turn",
            model=self.config.model,
            raw={"provider": "none"},
        )

    async def stream(
        self,
        messages: list[Message],
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        tools: Optional[list[dict]] = None,
    ) -> AsyncIterator[StreamChunk]:
        completion = await self.complete(messages, max_tokens, temperature, tools)
        yield StreamChunk(text_delta=completion.text, is_final=True)


def _rough_tokens(s: str) -> int:
    """A token is ~4 characters in English. Close enough for cost-cap
    accounting on a path that doesn't actually call a model."""
    return max(1, len(s) // 4)
