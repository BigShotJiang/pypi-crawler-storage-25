"""Anthropic provider — Claude family.

Lazy-imports `anthropic` so the rest of the SDK still works when the user
installs without the ``[llm]`` extra. Reads the API key from the env var
named in ``LLMConfig.api_key_env`` (default ``ANTHROPIC_API_KEY``).
"""

from __future__ import annotations

import os
from typing import AsyncIterator, Optional

from .base import Completion, LLMConfig, LLMProvider, Message, StreamChunk


class AnthropicProvider(LLMProvider):
    def __init__(self, config: LLMConfig):
        super().__init__(config)
        try:
            from anthropic import AsyncAnthropic  # type: ignore
        except ImportError as e:  # pragma: no cover
            raise ImportError(
                "AnthropicProvider requires the [llm] extra. "
                "Install with: pip install navian-pulse[llm]"
            ) from e

        api_key = config.api_key or (
            os.getenv(config.api_key_env or "ANTHROPIC_API_KEY")
        )
        self._client = AsyncAnthropic(api_key=api_key)

    async def complete(
        self,
        messages: list[Message],
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        tools: Optional[list[dict]] = None,
    ) -> Completion:
        # Anthropic separates the system prompt from the message list.
        system_msgs = [m.content for m in messages if m.role == "system"]
        chat_msgs = [
            {"role": m.role, "content": m.content}
            for m in messages
            if m.role != "system"
        ]
        kwargs: dict = {
            "model": self.config.model,
            "max_tokens": max_tokens or self.config.default_max_tokens,
            "temperature": temperature
            if temperature is not None
            else self.config.default_temperature,
            "messages": chat_msgs,
        }
        if system_msgs:
            kwargs["system"] = "\n\n".join(system_msgs)
        if tools:
            kwargs["tools"] = tools

        resp = await self._client.messages.create(**kwargs)
        text = "".join(
            block.text
            for block in resp.content
            if hasattr(block, "text")
        )
        return Completion(
            text=text,
            prompt_tokens=resp.usage.input_tokens,
            completion_tokens=resp.usage.output_tokens,
            stop_reason=resp.stop_reason or "end_turn",
            model=resp.model,
            raw=resp,
        )

    async def stream(
        self,
        messages: list[Message],
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        tools: Optional[list[dict]] = None,
    ) -> AsyncIterator[StreamChunk]:
        system_msgs = [m.content for m in messages if m.role == "system"]
        chat_msgs = [
            {"role": m.role, "content": m.content}
            for m in messages
            if m.role != "system"
        ]
        kwargs: dict = {
            "model": self.config.model,
            "max_tokens": max_tokens or self.config.default_max_tokens,
            "temperature": temperature
            if temperature is not None
            else self.config.default_temperature,
            "messages": chat_msgs,
        }
        if system_msgs:
            kwargs["system"] = "\n\n".join(system_msgs)
        if tools:
            kwargs["tools"] = tools

        async with self._client.messages.stream(**kwargs) as stream:
            async for chunk in stream:
                if hasattr(chunk, "delta") and hasattr(chunk.delta, "text"):
                    yield StreamChunk(text_delta=chunk.delta.text, is_final=False)
            yield StreamChunk(text_delta="", is_final=True)
