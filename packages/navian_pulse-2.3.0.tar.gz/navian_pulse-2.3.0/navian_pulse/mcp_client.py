"""MCP (Model Context Protocol) client for Navian Pulse.

Connects to Pulse's `--mcp` server (SSE transport) and exposes the seven
memory tools as Python methods. Bearer auth from Phase 1 Track A1 is
supported via the ``token`` constructor argument.

Install with the optional dependency group:

    pip install navian-pulse[mcp]

Quickstart:

    from navian_pulse import MCPClient
    c = MCPClient("http://pulse.example/mcp", token="tok-abc-123")
    state = c.entity_state("entity-00001")
    card = c.context_card("entity-00001", token_budget=2000)
    c.memory_write("entity-00001", "fraud_score", 0.93,
                   confidence=0.95, ttl_hours=24)

The client is sync-by-default for notebook ergonomics; an async variant lives
in ``navian_pulse.mcp_async``. Both wrap the same wire protocol.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Optional

try:
    import httpx
except ImportError as e:  # pragma: no cover
    raise ImportError(
        "navian_pulse.mcp_client requires the [mcp] extra. "
        "Install with: pip install navian-pulse[mcp]"
    ) from e


@dataclass
class MCPResponse:
    """Decoded JSON-RPC response. ``result`` is the parsed JSON Pulse returned
    in the ``content[0].text`` field; ``raw`` is the full envelope for debugging."""

    result: Any
    raw: dict


class MCPError(Exception):
    """Raised when the server returns a JSON-RPC error envelope. Carries the
    original ``code``, ``message``, and ``data`` fields so callers can
    distinguish unauthorized (-32001), cost-cap (-32002), and other failures."""

    def __init__(self, code: int, message: str, data: Optional[dict] = None):
        super().__init__(f"MCP error {code}: {message}")
        self.code = code
        self.message = message
        self.data = data or {}


class MCPClient:
    """Sync MCP client over SSE / HTTP POST.

    Parameters
    ----------
    endpoint:
        URL of the Pulse MCP endpoint, e.g. ``"http://pulse.example/mcp"``.
    token:
        Bearer token. Required in production deployments where the engine has
        ``NAVIAN_MCP_AGENT_REGISTRY_TOML`` set; optional in dev mode.
    timeout_s:
        Per-request timeout. Defaults to 10s — memory operations are sub-2ms
        on the hot path, but the network round trip can dominate.
    """

    def __init__(
        self,
        endpoint: str,
        token: Optional[str] = None,
        timeout_s: float = 10.0,
    ):
        self.endpoint = endpoint.rstrip("/")
        self.token = token
        self._next_id = 1
        self._http = httpx.Client(timeout=timeout_s)

    # ── tool wrappers ───────────────────────────────────────────────────

    def entity_state(self, entity_id: str) -> dict:
        """Full entity state via the gRPC fast path. Sub-2ms typical."""
        return self._call("pulse.entity.state", {"entity_id": entity_id})

    def memory_recall(
        self,
        entity_id: str,
        memory_types: str = "semantic,episodic,procedural",
        token_budget: int = 2000,
    ) -> dict:
        """Recall typed memory for an entity, scope-filtered for the caller."""
        return self._call(
            "pulse.memory.recall",
            {
                "entity_id": entity_id,
                "memory_types": memory_types,
                "token_budget": token_budget,
            },
        )

    def memory_context(
        self,
        entity_id: str,
        token_budget: int = 4000,
        memory_types: Optional[str] = None,
    ) -> str:
        """Token-budgeted LLM-ready context card. Returns the rendered text."""
        args: dict[str, Any] = {"entity_id": entity_id, "token_budget": token_budget}
        if memory_types:
            args["memory_types"] = memory_types
        result = self._call("pulse.memory.context", args)
        # The handler returns a JSON object; the human-readable card is under
        # the ``card`` key when shaped as v2 contexts. Older builds returned
        # the raw text. Handle both.
        if isinstance(result, dict):
            return result.get("card") or json.dumps(result)
        return str(result)

    def memory_replay(self, entity_id: str, at_ms: Optional[int] = None) -> dict:
        """Point-in-time entity-state reconstruction.

        ``at_ms`` is a Unix milliseconds timestamp. When None, returns
        current state — equivalent to entity_state but via the replay code path."""
        args: dict[str, Any] = {"entity_id": entity_id}
        if at_ms is not None:
            args["at_ms"] = at_ms
        return self._call("pulse.memory.replay", args)

    def memory_write(
        self,
        entity_id: str,
        field: str,
        value: Any,
        confidence: Optional[float] = None,
        ttl_hours: Optional[int] = None,
    ) -> dict:
        """Write an attributed fact. ``agent_id`` is taken from the bearer
        token's resolved identity, not from this call. The server records
        ``_source_agent``, ``_confidence``, and ``_ttl_hours`` automatically."""
        args: dict[str, Any] = {
            "entity_id": entity_id,
            "field": field,
            "value": value,
        }
        if confidence is not None:
            args["confidence"] = confidence
        if ttl_hours is not None:
            args["ttl_hours"] = ttl_hours
        return self._call("pulse.memory.write", args)

    def memory_consolidate(self, entity_id: str) -> dict:
        """Run episodic → semantic consolidation for an entity."""
        return self._call("pulse.memory.consolidate", {"entity_id": entity_id})

    def context_card_legacy(self, entity_id: str) -> dict:
        """Legacy compact context card — risk level + signals + recent activity.

        Prefer ``memory_context`` for new integrations; this is kept for
        existing dashboards that built against the v1 shape."""
        return self._call("pulse.context_card", {"entity_id": entity_id})

    # ── transport ───────────────────────────────────────────────────────

    def _call(self, tool_name: str, arguments: dict) -> Any:
        """One JSON-RPC ``tools/call`` round trip. Raises MCPError on
        any error envelope (auth failure, scope denial, cost cap, etc.)."""
        request_id = self._next_id
        self._next_id += 1

        envelope = {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": "tools/call",
            "params": {"name": tool_name, "arguments": arguments},
        }

        headers = {"Content-Type": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"

        resp = self._http.post(self.endpoint, json=envelope, headers=headers)
        resp.raise_for_status()
        body = resp.json()

        if "error" in body and body["error"] is not None:
            err = body["error"]
            raise MCPError(
                code=err.get("code", -1),
                message=err.get("message", "unknown error"),
                data=err.get("data"),
            )

        # Pulse wraps the actual result in result.content[0].text as JSON.
        result = body.get("result", {})
        content = result.get("content")
        if isinstance(content, list) and content and "text" in content[0]:
            try:
                return json.loads(content[0]["text"])
            except (json.JSONDecodeError, TypeError):
                return content[0]["text"]
        return result

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._http.close()

    def __enter__(self) -> "MCPClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
