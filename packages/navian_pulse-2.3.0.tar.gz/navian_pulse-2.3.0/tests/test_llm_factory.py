"""Track A3 acceptance test — provider factory works against the no-LLM path
without any network access or API keys configured. CI runs this in the
no-extras lane.
"""

import asyncio

from navian_pulse.llm import LLMConfig, Message, make_provider


def test_none_provider_no_network() -> None:
    cfg = LLMConfig(provider="none", model="echo")
    provider = make_provider(cfg)

    async def _go() -> None:
        completion = await provider.complete(
            messages=[Message(role="user", content="hello world")]
        )
        assert completion.text == "[no-llm] hello world"
        assert completion.prompt_tokens > 0
        assert completion.completion_tokens > 0
        assert completion.stop_reason == "end_turn"

    asyncio.run(_go())


def test_none_provider_streams() -> None:
    cfg = LLMConfig(provider="none", model="echo")
    provider = make_provider(cfg)

    async def _go() -> list[str]:
        chunks = []
        async for chunk in provider.stream(
            messages=[Message(role="user", content="streamed")]
        ):
            chunks.append(chunk.text_delta)
        return chunks

    chunks = asyncio.run(_go())
    assert any("streamed" in c for c in chunks)


def test_unknown_provider_rejected() -> None:
    cfg = LLMConfig(provider="this-doesnt-exist", model="x")
    try:
        make_provider(cfg)
    except ValueError as e:
        assert "unknown LLM provider" in str(e)
    else:
        raise AssertionError("expected ValueError")


def test_factory_reports_helpful_error_for_unimplemented() -> None:
    """Bedrock/Vertex/Azure are scaffolded but not implemented in Phase 1.
    The factory should reject them with a clear NotImplementedError, not
    crash with an obscure attribute error."""
    for name in ("bedrock", "vertex", "azure"):
        cfg = LLMConfig(provider=name, model="x")
        try:
            make_provider(cfg)
        except NotImplementedError as e:
            assert "scaffolded" in str(e).lower() or "follow-up" in str(e).lower()
        else:
            raise AssertionError(f"expected NotImplementedError for {name}")
