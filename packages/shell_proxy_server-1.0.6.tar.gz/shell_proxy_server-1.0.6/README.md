# shell-proxy-server

Http Shell Proxy Server - Web-based shell command execution server.

## Install

```bash
pip install shell-proxy-server
```

## Usage

### Command Line

```bash
shell-proxy-server --host 0.0.0.0 --port 7862 --username root --password 123456
```

### Environment Variables

| Variable   | Default     | Description       |
|------------|-------------|-------------------|
| HOST       | 0.0.0.0     | Server host       |
| PORT       | 7862        | Server port       |
| USERNAME   | root        | Login username    |
| PASSWORD   | 123456      | Login password    |

### Docker

```bash
docker run -d -p 7862:7862 -e USERNAME=root -e PASSWORD=123456 shell-proxy-server
```

## API

### Login

```
POST /login
Content-Type: application/x-www-form-urlencoded

username=root&password=123456
```

### Execute Command

```
POST /api/exec
Content-Type: application/json

{"command": "ls -la"}
```

### Server Status

```
GET /api/status
```

## Web UI

Access `http://<host>:<port>/` in browser, login with configured username/password.
