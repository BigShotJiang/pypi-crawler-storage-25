#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author: qicongsheng
import argparse
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../'))

from shell_proxy_server import help
from shell_proxy_server.shell_server import run


def main():
    parser = argparse.ArgumentParser(f"{help.get_name()} {help.get_version()} ({help.get_source_url()})")
    parser.add_argument('--host', default=os.getenv("HOST", "0.0.0.0"), type=str,
                        help='server host (env: HOST)', required=False)
    parser.add_argument('--port', default=os.getenv("PORT", 7862), type=int,
                        help='server port (env: PORT)', required=False)
    parser.add_argument('--username', default=os.getenv("USERNAME", "root"), type=str,
                        help='login username (env: USERNAME)', required=False)
    parser.add_argument('--password', default=os.getenv("PASSWORD", "123456"), type=str,
                        help='login password (env: PASSWORD)', required=False)
    parser.add_argument('--debug', action='store_true', default=False, help='enable debug mode')
    args = parser.parse_args()
    run(host=args.host, port=args.port, username=args.username, password=args.password, debug=args.debug)


if __name__ == "__main__":
    main()
