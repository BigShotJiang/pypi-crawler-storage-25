import functools
import os
import platform
import subprocess
import time

from flask import Flask, request, session, redirect, url_for, render_template_string, jsonify

# --- Configuration ---
DEFAULT_USERNAME = "root"
DEFAULT_PASSWORD = "123456"
DEFAULT_HOST = "0.0.0.0"
DEFAULT_PORT = 7862

app = Flask(__name__)
app.secret_key = os.urandom(24)

_username = DEFAULT_USERNAME
_password = DEFAULT_PASSWORD
_start_time = time.time()


def configure(username=None, password=None):
    global _username, _password
    if username is not None:
        _username = username
    if password is not None:
        _password = password


# --- Auth ---
def check_auth(username, password):
    return username == _username and password == _password


def requires_auth(f):
    @functools.wraps(f)
    def decorated(*args, **kwargs):
        auth = request.authorization
        if auth and check_auth(auth.username, auth.password):
            return f(*args, **kwargs)
        if session.get("logged_in"):
            return f(*args, **kwargs)
        return jsonify({"error": "Unauthorized"}), 401, {"WWW-Authenticate": 'Basic realm="Login Required"'}

    return decorated


# --- Page Routes ---
@app.route("/")
def index():
    return redirect(url_for("login"))


LOGIN_TEMPLATE = """<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Shell Server - Login</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { background: #1a1a2e; color: #e0e0e0; font-family: 'Segoe UI', sans-serif; display: flex; justify-content: center; align-items: center; min-height: 100vh; }
.card { background: #16213e; border-radius: 12px; padding: 40px; width: 360px; box-shadow: 0 8px 32px rgba(0,0,0,0.3); }
h1 { text-align: center; margin-bottom: 24px; color: #00d4ff; font-size: 24px; }
label { display: block; margin-bottom: 6px; color: #a0a0b0; font-size: 14px; }
input { width: 100%; padding: 10px 14px; border: 1px solid #2a2a4a; border-radius: 8px; background: #0f0f23; color: #e0e0e0; font-size: 15px; margin-bottom: 18px; }
input:focus { outline: none; border-color: #00d4ff; }
button { width: 100%; padding: 12px; border: none; border-radius: 8px; background: #00d4ff; color: #0f0f23; font-size: 16px; font-weight: 600; cursor: pointer; }
button:hover { background: #00b8d9; }
.error { color: #ff6b6b; text-align: center; margin-bottom: 12px; font-size: 14px; }
</style>
</head>
<body>
<div class="card">
<h1>Shell Server</h1>
{% if error %}<p class="error">{{ error }}</p>{% endif %}
<form method="POST">
<label>Username</label>
<input type="text" name="username" autofocus required>
<label>Password</label>
<input type="password" name="password" required>
<button type="submit">Login</button>
</form>
</div>
</body>
</html>"""


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if check_auth(request.form.get("username", ""), request.form.get("password", "")):
            session["logged_in"] = True
            return redirect(url_for("dashboard"))
        return render_template_string(LOGIN_TEMPLATE, error="Invalid credentials"), 401
    return render_template_string(LOGIN_TEMPLATE)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/dashboard")
@requires_auth
def dashboard():
    return render_template_string(DASHBOARD_TEMPLATE)


# --- API Routes ---
@app.route("/api/status")
@requires_auth
def api_status():
    uptime = int(time.time() - _start_time)
    return jsonify({
        "hostname": platform.node(),
        "platform": platform.system(),
        "platform_release": platform.release(),
        "python_version": platform.python_version(),
        "uptime_seconds": uptime,
    })


@app.route("/api/exec", methods=["POST"])
@requires_auth
def api_exec():
    data = request.get_json(silent=True)
    if not data or "command" not in data:
        return jsonify({"error": "Missing 'command' in request body"}), 400
    try:
        result = subprocess.run(
            data["command"],
            shell=True,
            capture_output=True,
            text=True,
        )
        return jsonify({
            "stdout": result.stdout,
            "stderr": result.stderr,
            "returncode": result.returncode,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# --- Dashboard Template ---
DASHBOARD_TEMPLATE = """<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Shell Server - Dashboard</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { background: #1a1a2e; color: #e0e0e0; font-family: 'Segoe UI', sans-serif; min-height: 100vh; }
nav { background: #16213e; padding: 14px 24px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #2a2a4a; }
nav h1 { color: #00d4ff; font-size: 20px; }
nav a { color: #ff6b6b; text-decoration: none; font-size: 14px; }
.container { max-width: 900px; margin: 24px auto; padding: 0 16px; }
.card { background: #16213e; border-radius: 12px; padding: 24px; margin-bottom: 20px; box-shadow: 0 4px 16px rgba(0,0,0,0.2); }
.card h2 { color: #00d4ff; margin-bottom: 16px; font-size: 18px; }
table { width: 100%; border-collapse: collapse; }
th, td { padding: 10px 14px; text-align: left; border-bottom: 1px solid #2a2a4a; font-size: 14px; }
th { color: #a0a0b0; font-weight: 600; }
td code { background: #0f0f23; padding: 3px 8px; border-radius: 4px; color: #00d4ff; font-size: 13px; }
.method { display: inline-block; padding: 2px 10px; border-radius: 4px; font-size: 12px; font-weight: 600; }
.method-get { background: #1a4a2e; color: #4ade80; }
.method-post { background: #4a3a1a; color: #fbbf24; }
textarea { width: 100%; height: 120px; background: #0f0f23; color: #e0e0e0; border: 1px solid #2a2a4a; border-radius: 8px; padding: 14px; font-family: 'Consolas', 'Courier New', monospace; font-size: 14px; resize: vertical; }
textarea:focus { outline: none; border-color: #00d4ff; }
.btn { padding: 10px 24px; border: none; border-radius: 8px; font-size: 15px; font-weight: 600; cursor: pointer; margin-top: 12px; }
.btn-exec { background: #00d4ff; color: #0f0f23; }
.btn-exec:hover { background: #00b8d9; }
.btn-exec:disabled { opacity: 0.5; cursor: not-allowed; }
.output { margin-top: 16px; }
.output-header { color: #a0a0b0; font-size: 13px; margin-bottom: 6px; font-weight: 600; }
.output-box { background: #0f0f23; border-radius: 8px; padding: 14px; font-family: 'Consolas', 'Courier New', monospace; font-size: 13px; white-space: pre-wrap; word-break: break-all; max-height: 400px; overflow-y: auto; }
.stdout { color: #4ade80; }
.stderr { color: #ff6b6b; }
.exit-code { color: #a0a0b0; font-size: 13px; margin-top: 8px; }
.spinner { display: none; color: #00d4ff; margin-top: 8px; }
</style>
</head>
<body>
<nav>
<h1>Shell Server</h1>
<a href="/logout">Logout</a>
</nav>
<div class="container">

<div class="card">
<h2>API Endpoints</h2>
<table>
<thead><tr><th>Route</th><th>Method</th><th>Description</th></tr></thead>
<tbody>
<tr><td><code>/api/exec</code></td><td><span class="method method-post">POST</span></td><td>Execute shell command. Body: <code>{"command": "..."}</code></td></tr>
<tr><td><code>/api/status</code></td><td><span class="method method-get">GET</span></td><td>Server status (hostname, uptime, platform)</td></tr>
</tbody>
</table>
</div>

<div class="card">
<h2>Execute Command</h2>
<textarea id="cmd" placeholder="Enter shell command, e.g. ls -la"></textarea>
<button class="btn btn-exec" id="execBtn" onclick="execCmd()">Execute</button>
<span class="spinner" id="spinner">Running...</span>
<div class="output" id="output" style="display:none">
<div class="output-header">STDOUT</div>
<div class="output-box stdout" id="stdout"></div>
<div class="output-header" style="margin-top:12px">STDERR</div>
<div class="output-box stderr" id="stderr"></div>
<div class="exit-code" id="exitCode"></div>
</div>
</div>

</div>
<script>
function execCmd() {
  const cmd = document.getElementById('cmd').value.trim();
  if (!cmd) return;
  const btn = document.getElementById('execBtn');
  const spinner = document.getElementById('spinner');
  const output = document.getElementById('output');
  btn.disabled = true;
  spinner.style.display = 'inline';
  output.style.display = 'none';
  fetch('/api/exec', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({command: cmd})
  })
  .then(r => r.json())
  .then(data => {
    document.getElementById('stdout').textContent = data.stdout || '(empty)';
    document.getElementById('stderr').textContent = data.stderr || '(empty)';
    document.getElementById('exitCode').textContent = 'Exit code: ' + (data.returncode !== undefined ? data.returncode : 'N/A');
    if (data.error) document.getElementById('stderr').textContent = data.error;
    output.style.display = 'block';
  })
  .catch(err => {
    document.getElementById('stderr').textContent = 'Request failed: ' + err.message;
    output.style.display = 'block';
  })
  .finally(() => {
    btn.disabled = false;
    spinner.style.display = 'none';
  });
}
document.getElementById('cmd').addEventListener('keydown', function(e) {
  if (e.ctrlKey && e.key === 'Enter') execCmd();
});
</script>
</body>
</html>"""


def create_app(username=None, password=None):
    configure(username=username, password=password)
    return app


def run(host=DEFAULT_HOST, port=DEFAULT_PORT, username=None, password=None, debug=False):
    global _start_time
    _start_time = time.time()
    configure(username=username, password=password)
    app.run(host=host, port=port, debug=debug, threaded=True)


if __name__ == "__main__":
    run(debug=True)
