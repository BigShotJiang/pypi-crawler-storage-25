#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author: qicongsheng
from shell_proxy_server import help
from setuptools import setup, find_packages

setup(
    name=help.get_name(),
    version=help.get_version(),
    keywords=help.get_name(),
    description='Http Shell Proxy Server.',
    license='MIT License',
    url=help.get_source_url(),
    author='qicongsheng',
    author_email='qicongsheng@outlook.com',
    packages=find_packages(),
    include_package_data=True,
    platforms=['any'],
    install_requires=[
        'flask',
    ],
    entry_points={
        'console_scripts': [
            'shell-proxy-server = shell_proxy_server.__main__:main'
        ]
    }
)
