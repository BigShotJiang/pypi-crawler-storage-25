"""knktx CLI — bootstrap agents with rules, workflows, skills, MCP configs, and plugins from knktx."""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tomllib
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from types import MappingProxyType

import httpx

from knktx_mcp.enforcement import render_rules, render_workflows

MARKER_START = "<!-- knktx:start -->"
MARKER_END = "<!-- knktx:end -->"

VALID_MODES = ("full", "soft")

# Keep in sync with server/app/services/settings_sync_service.py SETTING_GROUPS
_ALL_SETTING_GROUPS = (
    "task_tracking",
    "branch_pr_linking",
    "board_per_feature",
    "pr_comments_to_cards",
    "plan_documents",
    "plan_before_code",
    "single_pr_workflow",
    "no_secrets",
    "branch_workflow",
    "atomic_commits",
    "handoff_sync",
    "project_description_sync",
    "dry_reuse",
    "fresh_board_ids",
    "note_tracking",
    "agent_attribution",
)


# ---------------------------------------------------------------------------
# Agent registry
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class AgentDef:
    """Immutable definition for a supported agent CLI."""

    key: str  # internal identifier, matches API agent param and --agent flag
    display_name: str
    binary: str  # CLI binary name for shutil.which()
    config_dir: str  # e.g. ".claude" — relative to ~ or cwd
    instructions_file: str  # e.g. "CLAUDE.md"
    skills_dir: str  # relative to config_dir
    project_skills_dir: str | None  # override for project scope (None = use config_dir/skills_dir)
    project_instructions_dir: str | None  # override for project instructions (None = use config_dir)
    install_hint: str  # e.g. "npm install -g @anthropic-ai/claude-code"


AGENT_REGISTRY: tuple[AgentDef, ...] = (
    AgentDef(
        key="claude",
        display_name="Claude Code",
        binary="claude",
        config_dir=".claude",
        instructions_file="CLAUDE.md",
        skills_dir="skills",
        project_skills_dir=None,
        project_instructions_dir=None,
        install_hint="npm install -g @anthropic-ai/claude-code",
    ),
    AgentDef(
        key="gemini",
        display_name="Gemini CLI",
        binary="gemini",
        config_dir=".gemini",
        instructions_file="GEMINI.md",
        skills_dir="skills",
        project_skills_dir=None,
        project_instructions_dir=None,
        install_hint="npm install -g @google/gemini-cli",
    ),
    AgentDef(
        key="codex",
        display_name="Codex CLI",
        binary="codex",
        config_dir=".codex",
        instructions_file="AGENTS.md",
        skills_dir="skills",
        project_skills_dir=".agents/skills",
        project_instructions_dir="",
        install_hint="npm install -g @openai/codex",
    ),
)

AGENT_BY_KEY: MappingProxyType[str, AgentDef] = MappingProxyType(
    {a.key: a for a in AGENT_REGISTRY}
)


def detect_agents() -> list[AgentDef]:
    """Return agents whose CLI binary is found on PATH."""
    return [a for a in AGENT_REGISTRY if shutil.which(a.binary)]


DEFAULT_API_URL = "https://app.knktx.dev/api/v1"

_SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9-]*$")
_MCP_NAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_-]*$")

_COLORS = {
    "red": "\x1b[31m",
    "green": "\x1b[32m",
    "yellow": "\x1b[33m",
    "cyan": "\x1b[36m",
    "bold": "\x1b[1m",
    "dim": "\x1b[2m",
    "reset": "\x1b[0m",
}

# Per-agent display colors
AGENT_COLORS: MappingProxyType[str, str] = MappingProxyType({
    "claude": "cyan",
    "gemini": "yellow",
    "codex": "green",
})


def _c(text: str, *styles: str) -> str:
    """Wrap text in ANSI color codes. Respects NO_COLOR env var."""
    if os.environ.get("NO_COLOR") or not sys.stdout.isatty():
        return text
    codes = "".join(_COLORS.get(s, "") for s in styles)
    return f"{codes}{text}{_COLORS['reset']}" if codes else text


def _agent_badge(agent_key: str) -> str:
    """Color-coded [agent] badge for display."""
    color = AGENT_COLORS.get(agent_key, "dim")
    return _c(f"[{agent_key}]", color)


def _agent_badges(agent_keys: list[str]) -> str:
    """Space-separated color-coded agent badges."""
    return " ".join(_agent_badge(k) for k in agent_keys)


def _merge_by_key(
    items_by_agent: dict[str, list[dict]], key_field: str = "id",
) -> list[tuple[dict, list[str]]]:
    """Merge items fetched per-agent into (item, [agent_keys]) tuples.

    Deduplicates by *key_field*, preserves order of first appearance.
    """
    seen: dict[str, tuple[dict, list[str]]] = {}
    for agent_key, items in items_by_agent.items():
        for item in items:
            item_key = str(item.get(key_field, ""))
            if not item_key:
                continue
            if item_key in seen:
                if agent_key not in seen[item_key][1]:
                    seen[item_key][1].append(agent_key)
            else:
                seen[item_key] = (item, [agent_key])
    return list(seen.values())


# ---------------------------------------------------------------------------
# Interactive prompts
# ---------------------------------------------------------------------------


def _prompt(message: str, default: str = "") -> str:
    """Prompt for input with optional default. Handles Ctrl-C/EOF."""
    suffix = f" [{default}]" if default else ""
    try:
        value = input(f"{message}{suffix}: ").strip()
        return value or default
    except (EOFError, KeyboardInterrupt):
        print("\nAborted.", file=sys.stderr)
        sys.exit(1)


def _pick(message: str, options: list[str], default: int = 0) -> int:
    """Interactive arrow-key picker. Returns the selected index.

    Falls back to numbered input if the terminal doesn't support raw mode.
    """
    try:
        import termios
        import tty
    except ImportError:
        return _pick_fallback(message, options, default)

    try:
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
    except (termios.error, AttributeError):
        return _pick_fallback(message, options, default)

    selected = default
    try:
        print(message)
        tty.setraw(fd)
        _pick_render(options, selected, first=True)

        while True:
            ch = sys.stdin.read(1)
            if ch == "\x1b":  # escape sequence
                seq = sys.stdin.read(2)
                if seq == "[A":  # up
                    selected = (selected - 1) % len(options)
                elif seq == "[B":  # down
                    selected = (selected + 1) % len(options)
                _pick_render(options, selected)
            elif ch in ("\r", "\n"):  # enter
                break
            elif ch == "\x03":  # Ctrl-C
                raise KeyboardInterrupt
    except (EOFError, KeyboardInterrupt):
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        print("\nAborted.", file=sys.stderr)
        sys.exit(1)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

    # Clear the menu and print the selection
    sys.stdout.write(f"\x1b[{len(options)}A\x1b[J")
    sys.stdout.write(f"{message} {options[selected]}\n")
    sys.stdout.flush()
    return selected


def _pick_render(options: list[str], selected: int, *, first: bool = False) -> None:
    """Render the picker options (raw mode — write directly)."""
    # Move cursor to start of options (skip on first render — lines don't exist yet)
    if not first:
        sys.stdout.write(f"\x1b[{len(options)}A")
    for i, opt in enumerate(options):
        marker = "›" if i == selected else " "
        highlight = f"\x1b[1;36m{opt}\x1b[0m" if i == selected else opt
        sys.stdout.write(f"\r\x1b[K  {marker} {highlight}\n")
    sys.stdout.flush()


def _pick_fallback(message: str, options: list[str], default: int) -> int:
    """Numbered fallback when terminal doesn't support raw mode."""
    print(message)
    for i, opt in enumerate(options):
        marker = "*" if i == default else " "
        print(f"  {marker} {i + 1}. {opt}")
    raw = _prompt("Select", str(default + 1))
    if raw.isdigit():
        idx = int(raw) - 1
        if 0 <= idx < len(options):
            return idx
    return default


def _confirm(message: str, default_yes: bool = True) -> bool:
    """Ask a yes/no question. Returns True for yes."""
    hint = "Y/n" if default_yes else "y/N"
    try:
        answer = input(f"{message} [{hint}]: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print("\nAborted.", file=sys.stderr)
        sys.exit(1)
    if not answer:
        return default_yes
    return answer in ("y", "yes")


def _read_existing_config(agent: AgentDef) -> dict | None:
    """Read existing knktx MCP config from the selected agent's config file.

    Returns the knktx MCP server entry (dict with env, command, etc.) or None.
    Only reads from the specified agent — never falls back to other agents.
    """
    return _read_agent_mcp_entry(agent)


def _read_agent_mcp_entry(agent: AgentDef) -> dict | None:
    """Read the knktx MCP entry from a single agent's config file."""
    home = Path.home()
    try:
        if agent.key == "claude":
            path = home / ".claude.json"
            if not path.exists():
                return None
            data = json.loads(path.read_text(encoding="utf-8"))
            return data.get("mcpServers", {}).get("knktx")

        if agent.key == "gemini":
            path = home / ".gemini" / "settings.json"
            if not path.exists():
                return None
            data = json.loads(path.read_text(encoding="utf-8"))
            return data.get("mcpServers", {}).get("knktx")

        if agent.key == "codex":
            path = home / ".codex" / "config.toml"
            if not path.exists():
                return None
            data = tomllib.loads(path.read_text(encoding="utf-8"))
            entry = data.get("mcp_servers", {}).get("knktx")
            if not entry:
                return None
            # Normalise TOML structure to match JSON format
            return dict(entry)

    except (json.JSONDecodeError, OSError, tomllib.TOMLDecodeError):
        return None
    return None


def _resolve_api_key(args: argparse.Namespace, agents: list[AgentDef]) -> tuple[str, str]:
    """Resolve API key from flag → env var → all agents' configs → prompt.

    Returns (key, source) where source is "flag", "env", "config", or "prompt".
    Checks all agents' config files when looking for an existing key.
    """
    if args.key:
        return args.key, "flag"
    from_env = os.environ.get("KNKTX_API_KEY", "")
    if from_env:
        return from_env, "env"
    for agent in agents:
        existing = _read_existing_config(agent)
        if existing:
            key = existing.get("env", {}).get("KNKTX_API_KEY", "")
            if key:
                return key, "config"
    key = _prompt("Enter your knktx API key")
    if not key:
        print(_c("Error: API key is required.", "red"), file=sys.stderr)
        sys.exit(1)
    return key, "prompt"


def _resolve_agent(args: argparse.Namespace) -> AgentDef:
    """Resolve agent from flag → detection → interactive picker. Returns AgentDef."""
    detected = set(a.key for a in detect_agents())

    if args.agent is not None:
        # Explicit --agent flag: validate against registry
        agent = AGENT_BY_KEY.get(args.agent)
        if agent is None:
            known = ", ".join(a.key for a in AGENT_REGISTRY)
            print(f"Error: Unknown agent '{args.agent}'. Supported: {known}", file=sys.stderr)
            sys.exit(1)
        return agent

    if args.yes:
        auto = [a for a in AGENT_REGISTRY if a.key in detected]
        if len(auto) == 1:
            return auto[0]
        print("Error: --agent is required with -y when multiple agents are available.", file=sys.stderr)
        sys.exit(1)

    # Show all registered agents; mark ones not found on PATH
    labels = []
    for a in AGENT_REGISTRY:
        label = a.display_name
        if a.key not in detected:
            label += " (not on PATH)"
        labels.append(label)

    idx = _pick("Agent?", labels)
    return AGENT_REGISTRY[idx]


def _resolve_agents(args: argparse.Namespace) -> list[AgentDef]:
    """Resolve target agents. --all returns all detected, --agent returns one, else picker.

    The interactive picker shows "All detected agents" as the first option when
    multiple agents are found on PATH.
    """
    detected = detect_agents()

    if args.all_agents:
        if not detected:
            print(_c("Error: No supported agents found on PATH.", "red"), file=sys.stderr)
            sys.exit(1)
        return detected

    if args.agent is not None or args.yes:
        return [_resolve_agent(args)]

    # Interactive picker — offer "All" when multiple agents are detected
    detected_keys = {a.key for a in detected}
    labels: list[str] = []
    show_all = len(detected) > 1

    if show_all:
        names = ", ".join(a.display_name for a in detected)
        labels.append(f"All detected agents ({names})")

    for a in AGENT_REGISTRY:
        label = a.display_name
        if a.key not in detected_keys:
            label += " (not on PATH)"
        labels.append(label)

    idx = _pick("Agent?", labels)

    if show_all and idx == 0:
        return detected
    agent_idx = idx - (1 if show_all else 0)
    return [AGENT_REGISTRY[agent_idx]]


def _resolve_mode(args: argparse.Namespace, api_mode: str | None) -> str:
    """Resolve mode from flag → API setting → interactive picker → default."""
    if args.mode:
        return args.mode
    if api_mode:
        return api_mode
    if args.yes:
        return "soft"
    idx = _pick("Injection mode?", list(VALID_MODES))
    return VALID_MODES[idx]


class _ScopeKind(StrEnum):
    GLOBAL = "global"
    PROJECT = "project"
    BOTH = "global+project"


class _Scope:
    """Resolved scope: global, project, or both."""

    GLOBAL = _ScopeKind.GLOBAL
    PROJECT = _ScopeKind.PROJECT
    BOTH = _ScopeKind.BOTH

    def __init__(self, kind: _ScopeKind, project_slug: str | None = None):
        self.kind = _ScopeKind(kind)
        self.project_slug = project_slug

    @property
    def is_global(self) -> bool:
        return self.kind in (self.GLOBAL, self.BOTH)

    @property
    def is_project(self) -> bool:
        return self.kind in (self.PROJECT, self.BOTH)

    @property
    def is_project_only(self) -> bool:
        return self.kind == self.PROJECT

    def __repr__(self) -> str:
        if self.project_slug:
            return f"Scope({self.kind}, project={self.project_slug})"
        return f"Scope({self.kind})"


def _fetch_projects(client: httpx.Client) -> list[dict]:
    """Fetch all active projects for the authenticated user."""
    return _api_get(client, "/projects")


def _fetch_projects_with_rules(client: httpx.Client) -> list[dict]:
    """Return projects that have at least one enabled rule.

    NOTE: This makes one API call per project (N+1). A dedicated server
    endpoint (e.g. GET /projects?has_rules=true) would be more efficient.
    Acceptable for now given typical project counts.
    """
    projects = _fetch_projects(client)
    result = []
    for proj in projects:
        slug = proj.get("slug", "")
        if not slug:
            continue
        if _fetch_rules(client, project_slug=slug):
            result.append(proj)
    return result


def _resolve_scope(args: argparse.Namespace, client: httpx.Client | None = None) -> _Scope:
    """Resolve scope: global, project, or both.

    Flag precedence:
    - --project-slug=X → project scope for that slug
    - --project → detect projects with rules, pick one
    - --yes → global only (non-interactive default)
    - otherwise → interactive picker with smart detection
    """
    # Explicit slug flag
    project_slug = getattr(args, "project_slug", None)
    if project_slug:
        return _Scope(_Scope.PROJECT, project_slug)

    # Legacy --project flag without slug
    if args.project:
        if client is None:
            print(_c("Error: --project requires API connection to detect projects.", "red"), file=sys.stderr)
            sys.exit(1)
        return _pick_project_scope(client)

    # Non-interactive mode
    if args.yes:
        return _Scope(_Scope.GLOBAL)

    # Interactive: check if any projects have rules
    if client is None:
        return _Scope(_Scope.GLOBAL)

    projects_with_rules = _fetch_projects_with_rules(client)
    if not projects_with_rules:
        print(_c("  No projects with rules found — using global scope.", "dim"))
        return _Scope(_Scope.GLOBAL)

    # Projects exist — offer scope picker
    options = ["Global only", "Project only", "Global + Project"]
    idx = _pick("Scope?", options)
    if idx == 0:
        return _Scope(_Scope.GLOBAL)
    elif idx == 1:
        slug = _pick_project(projects_with_rules)
        return _Scope(_Scope.PROJECT, slug)
    else:
        slug = _pick_project(projects_with_rules)
        return _Scope(_Scope.BOTH, slug)


def _pick_project(projects: list[dict]) -> str:
    """Pick a project from a list. Returns slug."""
    if len(projects) == 1:
        slug = projects[0].get("slug", "")
        if not slug:
            print(_c("Error: Selected project has no slug.", "red"), file=sys.stderr)
            sys.exit(1)
        name = projects[0].get("name", slug)
        print(f"  Using project: {_c(name, 'bold')} ({slug})")
        return slug

    names = [f"{p.get('name', '(unnamed)')} ({p.get('slug', '')})" for p in projects]
    idx = _pick("Which project?", names)
    slug = projects[idx].get("slug", "")
    if not slug:
        print(_c("Error: Selected project has no slug.", "red"), file=sys.stderr)
        sys.exit(1)
    return slug


def _pick_project_scope(client: httpx.Client) -> _Scope:
    """When --project flag is used without --project-slug, detect and pick."""
    projects_with_rules = _fetch_projects_with_rules(client)
    if not projects_with_rules:
        print(_c("  No projects with rules found. Use the web UI to add project-scoped rules.", "yellow"))
        print(_c("  Falling back to global scope.", "dim"))
        return _Scope(_Scope.GLOBAL)
    slug = _pick_project(projects_with_rules)
    return _Scope(_Scope.PROJECT, slug)


def _connect(api_url: str, api_key: str, key_source: str) -> tuple[httpx.Client, str, list[dict]]:
    """Create an authenticated API client and verify connectivity.

    On 401 with a config-sourced key, prompts for a new key and retries once.
    Returns (client, api_key, settings_rules) — the key may differ from input on retry.
    The settings_rules are fetched during the connectivity probe to avoid a redundant call.
    """
    for attempt in range(2):
        client = httpx.Client(
            base_url=api_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=30.0,
        )
        try:
            # Connectivity probe — also fetches settings rules to avoid a redundant call
            settings_rules = _fetch_settings_rules(client)
            return client, api_key, settings_rules
        except httpx.HTTPStatusError as e:
            client.close()
            if e.response.status_code == 401 and attempt == 0 and key_source == "config":
                print(_c("  Existing API key is invalid or revoked.", "yellow"))
                api_key = _prompt("Enter a new API key")
                if not api_key:
                    print(_c("Error: API key is required.", "red"), file=sys.stderr)
                    sys.exit(1)
                key_source = "prompt"
                continue
            if e.response.status_code == 401:
                print(_c("Error: Invalid API key.", "red"), file=sys.stderr)
            else:
                print(_c(f"Error: API returned {e.response.status_code}.", "red"), file=sys.stderr)
            sys.exit(1)
        except httpx.RequestError as e:
            client.close()
            print(_c(f"Error: Could not reach API at {api_url}: {e}", "red"), file=sys.stderr)
            sys.exit(1)
    # Unreachable, but satisfies type checker
    sys.exit(1)


def _resolve_api_url() -> str:
    """Resolve API URL from env var or default to production.

    Never reads from agent config files — those may contain stale localhost URLs.
    """
    from_env = os.environ.get("KNKTX_API_URL", "")
    if from_env:
        return from_env.rstrip("/")
    return DEFAULT_API_URL


# ---------------------------------------------------------------------------
# API helpers
# ---------------------------------------------------------------------------


def _api_get(client: httpx.Client, path: str, **params: object) -> list[dict]:
    """GET a JSON list from the API with proper error handling."""
    resp = client.get(path, params=params if params else None)
    resp.raise_for_status()
    data = resp.json()
    if not isinstance(data, list):
        raise ValueError(f"Expected list from {path}, got {type(data).__name__}")
    return data


def _fetch_rules(
    client: httpx.Client,
    agent: str | None = None,
    project_slug: str | None = None,
) -> list[dict]:
    params: dict[str, object] = {"enabled": True}
    if agent is not None:
        params["agent"] = agent
    if project_slug is not None:
        params["project_slug"] = project_slug
    return _api_get(client, "/rules", **params)


def _fetch_settings_rules(client: httpx.Client) -> list[dict]:
    """Fetch settings rules, triggering a server-side sync to clean up orphans and update descriptions.

    If no settings rules exist yet (new user), seeds all groups as enabled with soft injection mode.
    """
    rules = _api_get(client, "/rules", source="settings")

    # Derive enabled groups from existing rules and POST sync to refresh
    groups: dict[str, bool] = {}
    injection_mode: str | None = None
    for rule in rules:
        config = rule.get("config", {})
        group = config.get("setting_group", "")
        if group == "injection_mode":
            injection_mode = config.get("mode")
        elif group:
            groups[group] = True

    # New user — no settings rules exist yet. Seed all defaults.
    if not groups:
        groups = {g: True for g in _ALL_SETTING_GROUPS}
        injection_mode = "soft"

    try:
        body: dict[str, object] = {"groups": groups}
        if injection_mode:
            body["injection_mode"] = injection_mode
        resp = client.post("/rules/sync-settings", json=body)
        resp.raise_for_status()
        return resp.json()
    except httpx.HTTPStatusError:
        pass  # Fall back to the already-fetched rules

    return rules


def _read_injection_mode(settings_rules: list[dict]) -> str | None:
    """Read injection_mode from settings rules. Returns None if not configured or invalid."""
    for rule in settings_rules:
        config = rule.get("config", {})
        if config.get("setting_group") == "injection_mode":
            mode = config.get("mode")
            if mode in VALID_MODES:
                return mode
            print(f"Warning: ignoring unknown injection mode '{mode}' from API.", file=sys.stderr)
            return None
    return None


def _fetch_workflows(client: httpx.Client, agent: str | None = None) -> list[dict]:
    params: dict[str, object] = {}
    if agent is not None:
        params["agent"] = agent
    return _api_get(client, "/workflows", **params)


def _fetch_enabled(client: httpx.Client, path: str, agent: str | None = None) -> list[dict]:
    """Fetch items from the API and filter to enabled-only (client-side).

    The API does not support an ``enabled`` query param for skills, MCP configs,
    or plugins, so we filter after fetching.  Items without an ``enabled`` field
    default to True (backwards-compatible).
    """
    params: dict[str, object] = {}
    if agent is not None:
        params["agent"] = agent
    items = _api_get(client, path, **params)
    return [i for i in items if i.get("enabled", True)]


# ---------------------------------------------------------------------------
# Rendering and injection
# ---------------------------------------------------------------------------


def _sanitize_markers(text: str) -> str:
    """Strip knktx markers from rendered content to prevent marker injection."""
    return text.replace(MARKER_START, "").replace(MARKER_END, "")


def _render_section(rules: list[dict], workflows: list[dict], *, mode: str = "full", agent: str | None = None) -> str:
    """Render the full knktx rules/workflows section with markers."""
    parts: list[str] = [MARKER_START]

    rules_md = _sanitize_markers(render_rules(rules))

    if mode == "full":
        workflows_md = _sanitize_markers(render_workflows(workflows, agent=agent))

        if rules_md:
            parts.append(rules_md)
        if workflows_md:
            if rules_md:
                parts.append("")
            parts.append(workflows_md)

        if not rules_md and not workflows_md:
            parts.append("No rules or workflows configured.")
    else:
        # Soft mode: rules + workflow catalog inline, agent fetches full steps via MCP on demand
        if rules_md:
            parts.append(rules_md)

        if workflows:
            parts.append("")
            parts.append("# Workflows")
            parts.append("")
            parts.append(
                "Before starting any task, match it against the workflows below. "
                "Call `get_workflow(workflow_id)` from the knktx MCP server "
                "to retrieve the full steps for the matching workflow and follow it step-by-step."
            )
            parts.append("")
            for wf in workflows:
                name = _sanitize_markers(wf.get("name", "(unnamed)"))
                wf_id = wf.get("id", "")
                desc = _sanitize_markers(wf.get("description", ""))
                suffix = f" — {desc}" if desc else ""
                parts.append(f"- **{name}** (`{wf_id}`){suffix}")
        elif not rules_md:
            parts.append("No rules or workflows configured.")

    parts.append(MARKER_END)
    return "\n".join(parts)


def _inject_section(target: Path, section: str) -> None:
    """Inject or replace the knktx section in an agent's instructions file."""
    try:
        if target.exists():
            content = target.read_text(encoding="utf-8")
            start_idx = content.find(MARKER_START)
            end_idx = content.find(MARKER_END)

            if start_idx != -1 and end_idx != -1 and end_idx > start_idx:
                # Replace existing section
                end_idx += len(MARKER_END)
                new_content = content[:start_idx] + section + content[end_idx:]
            elif start_idx != -1 or end_idx != -1:
                # Orphaned marker — warn and replace entire file section
                print(f"Warning: Found orphaned knktx marker in {target.name}. Replacing.", file=sys.stderr)
                # Remove any orphaned markers before appending fresh section
                cleaned = content.replace(MARKER_START, "").replace(MARKER_END, "")
                new_content = cleaned.rstrip() + "\n\n" + section + "\n"
            else:
                # No markers — append to end
                new_content = content.rstrip() + "\n\n" + section + "\n"
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            new_content = section + "\n"

        target.write_text(new_content, encoding="utf-8")
    except PermissionError:
        print(f"Error: Permission denied writing to {target}.", file=sys.stderr)
        sys.exit(1)
    except OSError as e:
        print(f"Error: Could not write to {target}: {e}", file=sys.stderr)
        sys.exit(1)


# ---------------------------------------------------------------------------
# Skills installation
# ---------------------------------------------------------------------------


def _sanitize_yaml_value(value: str) -> str:
    """Strip newlines and escape double quotes for safe YAML interpolation."""
    return value.replace("\n", " ").replace("\r", "").replace('"', '\\"')


def _build_skill_md(skill: dict) -> str:
    """Build a SKILL.md file from a skill dict (frontmatter + body from files array)."""
    lines: list[str] = ["---"]

    name = _sanitize_yaml_value(skill.get("slug", skill.get("name", "unnamed")))
    lines.append(f'name: "{name}"')

    desc = skill.get("description")
    if desc:
        lines.append(f'description: "{_sanitize_yaml_value(desc)}"')

    if skill.get("user_invocable"):
        lines.append("user-invocable: true")

    allowed = skill.get("allowed_tools")
    if allowed is not None:
        if allowed:
            tools_str = ", ".join(_sanitize_yaml_value(str(t)) for t in allowed)
            lines.append(f"allowed-tools: [{tools_str}]")
        else:
            lines.append("allowed-tools: []")

    lines.append("---")
    lines.append("")

    files = skill.get("files") or []
    body = next((f.get("content", "") for f in files if f.get("path") == "SKILL.md"), "")
    if body:
        lines.append(body)

    return "\n".join(lines)


def _skills_base(agent: AgentDef, project: bool) -> Path:
    """Return the base directory for skill files."""
    if project and agent.project_skills_dir:
        return Path.cwd() / agent.project_skills_dir
    return _agent_dir(agent, project) / agent.skills_dir


def _is_safe_file_path(path: str) -> bool:
    """Check that a file path is safe to write to disk.

    Rejects empty, absolute, backslash, null-byte, traversal (..), and
    bare-dot (.) paths.  Delegates to ``_safe_file_path`` from client.py
    so validation stays in one place.
    """
    from knktx_mcp.client import _safe_file_path  # avoid circular at module level

    if not path or path.startswith("/"):
        return False
    # Strip leading "./" to match server normalisation behaviour
    normalized = path.lstrip("./") if path.startswith("./") else path
    if not normalized:
        return False
    try:
        _safe_file_path(normalized)
        return True
    except ValueError:
        return False


def _install_skills(agent: AgentDef, skills: list[dict], *, project: bool) -> int:
    """Write skill files to disk from the files array. Returns count of installed skills."""
    base = _skills_base(agent, project)

    count = 0
    skipped = 0
    for skill in skills:
        slug = skill.get("slug")
        if not slug:
            name = skill.get("name", "<unknown>")
            print(f"Warning: Skipping skill with no slug: {name}", file=sys.stderr)
            skipped += 1
            continue
        if not _SLUG_RE.match(slug):
            print(f"Warning: Skipping skill with invalid slug: {slug!r}", file=sys.stderr)
            skipped += 1
            continue
        skill_dir = base / slug
        try:
            skill_dir.mkdir(parents=True, exist_ok=True)
            # Write SKILL.md with generated frontmatter
            skill_file = skill_dir / "SKILL.md"
            skill_file.write_text(_build_skill_md(skill), encoding="utf-8")
            # Write remaining files from the files array
            resolved_root = skill_dir.resolve()
            for f in skill.get("files") or []:
                fpath = f.get("path", "")
                if fpath.upper() == "SKILL.MD":
                    continue
                if not _is_safe_file_path(fpath):
                    print(f"Warning: Skipping unsafe file path in skill '{slug}': {fpath!r}", file=sys.stderr)
                    continue
                dest = skill_dir / fpath
                # Belt-and-suspenders: verify resolved path stays inside skill_dir
                try:
                    dest.resolve().relative_to(resolved_root)
                except ValueError:
                    print(f"Warning: Skipping file escaping skill dir in '{slug}': {fpath!r}", file=sys.stderr)
                    continue
                try:
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    dest.write_text(f.get("content", ""), encoding="utf-8")
                except OSError as e:
                    print(f"Warning: Could not write file '{fpath}' in skill '{slug}': {e}", file=sys.stderr)
            count += 1
        except PermissionError:
            print(f"Error: Permission denied writing skill '{slug}' to {skill_dir}.", file=sys.stderr)
            skipped += 1
        except OSError as e:
            print(f"Error: Could not write skill '{slug}' to {skill_dir}: {e}", file=sys.stderr)
            skipped += 1

    return count


def _cleanup_stale_commands(agent: AgentDef, skills: list[dict], *, project: bool) -> int:
    """Remove command files that have matching user-invocable skills (skills supersede commands)."""
    cmd_dir = _agent_dir(agent, project) / "commands"
    if not cmd_dir.exists():
        return 0
    removed = 0
    for skill in skills:
        slug = skill.get("slug", "")
        if not slug or not skill.get("user_invocable"):
            continue
        if not _SLUG_RE.match(slug):
            print(f"Warning: Skipping stale command cleanup for invalid slug: {slug!r}", file=sys.stderr)
            continue
        cmd_file = cmd_dir / f"{slug}.md"
        if cmd_file.exists():
            try:
                cmd_file.unlink()
                removed += 1
            except OSError as e:
                print(f"Warning: Could not remove stale command '{slug}': {e}", file=sys.stderr)
    return removed


class _AgentNotFoundError(Exception):
    """Raised when the agent's CLI binary is not found."""


_ENV_KEY_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _build_mcp_cmd(agent: AgentDef, name: str, config: dict) -> list[str]:
    """Build the agent-specific CLI command to install an MCP server config.

    Supports both stdio (command + args) and remote (http/sse via url) transports.

    - Claude: ``claude mcp add-json <name> '<json>' --scope user``
      Claude receives the full JSON blob — no decomposition needed.
    - Gemini: ``gemini mcp add <name> <commandOrUrl> [args...] -s user [-t type] [-e K=V ...] [-H K:V ...]``
    - Codex: ``codex mcp add <name> -- <cmd> [args...]`` (stdio)
             ``codex mcp add <name> --url <url>`` (http)
    """
    if agent.key == "claude":
        # Claude uses add-json with the raw config blob — no decomposition needed
        return [agent.binary, "mcp", "add-json", name, json.dumps(config), "--scope", "user"]

    transport = config.get("type", "stdio")
    url = config.get("url") or ""
    command = config.get("command") or ""
    args = config.get("args") or []
    env = config.get("env") or {}
    headers = config.get("headers") or {}

    is_remote = transport in ("http", "sse")

    if is_remote and not url:
        raise ValueError(f"MCP config '{name}' has type '{transport}' but missing 'url' field")
    if not is_remote and not command:
        raise ValueError(f"MCP config '{name}' missing 'command' field")
    if not isinstance(args, list):
        raise ValueError(f"MCP config '{name}' has invalid 'args' (expected list)")
    if not isinstance(env, dict):
        raise ValueError(f"MCP config '{name}' has invalid 'env' (expected dict)")

    # Validate env keys to prevent malformed -e KEY=VALUE strings
    for k in env:
        if not _ENV_KEY_RE.match(str(k)):
            raise ValueError(f"MCP config '{name}' has invalid env key: {k!r}")

    if agent.key == "gemini":
        if is_remote:
            cmd = [agent.binary, "mcp", "add", name, url, "-t", transport, "-s", "user"]
            for k, v in headers.items():
                cmd.extend(["-H", f"{k}: {v}"])
        else:
            cmd = [agent.binary, "mcp", "add", name, command, *args, "-s", "user"]
        for k, v in env.items():
            cmd.extend(["-e", f"{k}={v}"])
        return cmd

    if agent.key == "codex":
        if is_remote:
            cmd = [agent.binary, "mcp", "add", name, "--url", url]
        else:
            cmd = [agent.binary, "mcp", "add", name]
            for k, v in env.items():
                cmd.extend(["--env", f"{k}={v}"])
            cmd.extend(["--", command, *args])
        return cmd

    raise ValueError(f"Unknown agent key: {agent.key}")


def _build_mcp_remove_cmd(agent: AgentDef, name: str) -> list[str]:
    """Build the agent-specific CLI command to remove an MCP server config."""
    if agent.key == "claude":
        return [agent.binary, "mcp", "remove", name, "-s", "user"]
    if agent.key == "gemini":
        return [agent.binary, "mcp", "remove", name, "-s", "user"]
    if agent.key == "codex":
        return [agent.binary, "mcp", "remove", name]
    return [agent.binary, "mcp", "remove", name]


def _remove_mcp_config(agent: AgentDef, name: str) -> None:
    """Remove an existing MCP config if present. No-op if it doesn't exist."""
    try:
        subprocess.run(
            _build_mcp_remove_cmd(agent, name),
            capture_output=True, text=True, timeout=30,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass


def _install_mcp_config(agent: AgentDef, name: str, config: dict) -> bool:
    """Install a single MCP server config via the agent's native CLI.

    Removes any existing config with the same name first to avoid "already exists"
    errors on re-init.

    Raises :class:`_AgentNotFoundError` when the agent binary is missing
    so callers can bail out of loops instead of repeating the same warning.
    """
    if not _MCP_NAME_RE.match(name):
        print(f"Warning: Refusing MCP config with invalid name: {name!r}", file=sys.stderr)
        return False

    try:
        cmd = _build_mcp_cmd(agent, name, config)
    except ValueError as e:
        print(f"Warning: {e}", file=sys.stderr)
        return False

    _remove_mcp_config(agent, name)

    try:
        subprocess.run(cmd, check=True, capture_output=True, text=True, timeout=60)
        return True
    except FileNotFoundError:
        raise _AgentNotFoundError(f"'{agent.binary}' CLI not found")
    except subprocess.CalledProcessError as e:
        detail = e.stderr.strip() or "(no output)"
        print(f"Warning: Failed to install MCP config '{name}' (exit code {e.returncode}): {detail}", file=sys.stderr)
        return False
    except subprocess.TimeoutExpired:
        print(f"Warning: MCP config '{name}' installation timed out after 60s.", file=sys.stderr)
        return False


def _install_mcp_configs(agent: AgentDef, configs: list[dict]) -> tuple[int, int]:
    """Install MCP server configs. Returns (success_count, total_attempted)."""
    count = 0
    attempted = 0
    for cfg in configs:
        name = cfg.get("name", "(unnamed)")
        if name == "knktx":
            print(f"  > Skipped: {name} (reserved, managed by CLI)", file=sys.stderr)
            continue
        config = cfg.get("config")
        if not config or not isinstance(config, dict):
            print(f"Warning: Skipping MCP config '{name}' — no valid config.", file=sys.stderr)
            continue
        if not _MCP_NAME_RE.match(name):
            print(f"Warning: Skipping MCP config with invalid name: {name!r}", file=sys.stderr)
            continue

        attempted += 1
        try:
            if _install_mcp_config(agent, name, config):
                count += 1
                print(f"  > Installed: {name}")
        except _AgentNotFoundError:
            print(f"Warning: '{agent.binary}' CLI not found — cannot install MCP configs.", file=sys.stderr)
            break

    return count, attempted


def _execute_plugin(name: str, content: str) -> bool:
    """Execute a plugin's content as a shell script.

    WARNING: *content* comes from the knktx API and runs with the user's shell
    privileges.  Callers must ensure user consent before invocation.

    On Windows, uses PowerShell instead of cmd.exe to support ``#`` comments in plugin scripts.
    """
    if sys.platform == "win32":
        cmd: str | list[str] = ["powershell", "-NoProfile", "-Command", content]
        use_shell = False
    else:
        cmd = content
        use_shell = True
    try:
        subprocess.run(
            cmd,
            shell=use_shell,
            check=True,
            capture_output=True,
            text=True,
            timeout=300,
        )
        return True
    except subprocess.CalledProcessError as e:
        detail = e.stderr.strip() if e.stderr else ""
        msg = f"Warning: Plugin '{name}' failed (exit code {e.returncode})."
        if detail:
            msg += f" {detail}"
        print(msg, file=sys.stderr)
        return False
    except subprocess.TimeoutExpired:
        print(f"Warning: Plugin '{name}' timed out after 300s.", file=sys.stderr)
        return False


def _execute_plugins(plugins: list[dict], *, auto: bool = False) -> tuple[int, int]:
    """Execute plugin scripts, optionally without per-plugin confirmation.

    When *auto* is False (default), each plugin's content is displayed and the
    user must confirm before execution.  When *auto* is True, all plugins run
    without individual prompts.

    Returns (success_count, attempted_count).
    """
    count = 0
    attempted = 0
    for plugin in plugins:
        name = plugin.get("name", "(unnamed)")
        content = plugin.get("content", "").strip()
        if not content:
            print(f"Warning: Skipping plugin '{name}' — no content.", file=sys.stderr)
            continue

        if auto:
            print(f"  Executing: {name}")
        else:
            print(f"\n  Plugin: {name}")
            print("  Commands:")
            for line in content.splitlines():
                print(f"    {line}")
            print()
            if not _confirm(f"  Execute plugin '{name}'?", default_yes=False):
                print(f"  > Skipped: {name}")
                continue

        attempted += 1
        if _execute_plugin(name, content):
            count += 1
            print(f"  > Executed: {name}")
        else:
            print(f"  > Failed: {name}")

    return count, attempted


def _patch_agent_mcp_config(agent: AgentDef, api_url: str, api_key: str) -> None:
    """Directly patch the knktx entry in an agent's config file if it has stale values.

    Belt-and-suspenders: the agent CLI command is the primary mechanism, but config
    files may have stale entries (e.g. ``claude mcp add-json`` writes to
    ~/.claude/settings.json while ~/.claude.json retains old values).

    Handles JSON configs (Claude, Gemini). TOML configs (Codex) are skipped — the
    CLI command is the only write path for those.
    """
    home = Path.home()
    if agent.key == "claude":
        _patch_json_mcp_config(home / ".claude.json", "mcpServers", api_url, api_key)
    elif agent.key == "gemini":
        _patch_json_mcp_config(home / ".gemini" / "settings.json", "mcpServers", api_url, api_key)
    # Codex uses TOML — skip direct patching, rely on CLI command


def _patch_json_mcp_config(config_path: Path, servers_key: str, api_url: str, api_key: str) -> None:
    """Patch knktx env vars in a JSON config file."""
    try:
        if not config_path.exists():
            return
        data = json.loads(config_path.read_text(encoding="utf-8"))
        servers = data.get(servers_key)
        if not isinstance(servers, dict):
            return
        knktx = servers.get("knktx")
        if not isinstance(knktx, dict):
            return
        env = knktx.get("env")
        if not isinstance(env, dict):
            return
        if env.get("KNKTX_API_KEY") == api_key and env.get("KNKTX_API_URL") == api_url:
            return  # Already correct
        env["KNKTX_API_KEY"] = api_key
        env["KNKTX_API_URL"] = api_url
        config_path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    except (json.JSONDecodeError, OSError, PermissionError):
        pass  # Best-effort


def _configure_mcp(agent: AgentDef, api_url: str, api_key: str) -> bool:
    """Configure the knktx MCP server via the agent's native CLI."""
    mcp_config = {
        "type": "stdio",
        "command": "uvx",
        "args": ["--from", "knktx", "knktx-mcp"],
        "env": {
            "KNKTX_API_URL": api_url,
            "KNKTX_API_KEY": api_key,
        },
    }
    try:
        ok = _install_mcp_config(agent, "knktx", mcp_config)
    except _AgentNotFoundError:
        print(f"Warning: '{agent.binary}' CLI not found — skipping MCP server configuration.", file=sys.stderr)
        if agent.install_hint:
            print(f"Install {agent.display_name}: {agent.install_hint}", file=sys.stderr)
        return False

    # Belt-and-suspenders: patch the agent's config file directly if it has stale values
    _patch_agent_mcp_config(agent, api_url, api_key)

    return ok


def _agent_dir(agent: AgentDef, project: bool) -> Path:
    """Return the agent's config directory for the given scope."""
    if project:
        return Path.cwd() / agent.config_dir
    return Path.home() / agent.config_dir


def _resolve_target(agent: AgentDef, project: bool) -> Path:
    """Determine which instructions file to write to (e.g. CLAUDE.md, GEMINI.md, AGENTS.md)."""
    if project and agent.project_instructions_dir is not None:
        return Path.cwd() / agent.project_instructions_dir / agent.instructions_file
    return _agent_dir(agent, project) / agent.instructions_file


def _banner() -> str:
    try:
        from importlib.metadata import version as _pkg_version
        ver = _pkg_version("knktx")
    except Exception:
        ver = "unknown"
    return f"""\
\x1b[36m
  ██╗  ██╗███╗   ██╗██╗  ██╗████████╗██╗  ██╗
  ██║ ██╔╝████╗  ██║██║ ██╔╝╚══██╔══╝╚██╗██╔╝
  █████╔╝ ██╔██╗ ██║█████╔╝    ██║    ╚███╔╝
  ██╔═██╗ ██║╚██╗██║██╔═██╗    ██║    ██╔██╗
  ██║  ██╗██║ ╚████║██║  ██╗   ██║   ██╔╝ ██╗
  ╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝
\x1b[0m\x1b[2m  One source of truth for all your agents
  v{ver}\x1b[0m
"""


def _section(title: str) -> str:
    return f"\n{_c('──', 'dim')} {_c(title, 'cyan', 'bold')} {_c('──', 'dim')}"


def _agent_color(key: str) -> str:
    """Canonical agent color with consistent fallback."""
    return AGENT_COLORS.get(key, "dim")


def _agent_name_list(agents: list[AgentDef]) -> str:
    """Formatted comma-separated agent display names with colors."""
    return ", ".join(_c(a.display_name, _agent_color(a.key)) for a in agents)


def _agent_success(agent: AgentDef, detail: str) -> str:
    """Formatted per-agent success message."""
    return _c(f"  ✓ {agent.display_name}", _agent_color(agent.key)) + f" — {detail}"


def _apply_rules_and_workflows(
    agents: list[AgentDef],
    rules_by_agent: dict[str, list[dict]],
    workflows_by_agent: dict[str, list[dict]],
    mode: str,
    project: bool,
    multi: bool,
    *,
    confirm: bool = False,
    scope_label: str | None = None,
) -> None:
    """Merge, display, and inject rules+workflows for all agents."""
    merged_rules = _merge_by_key(rules_by_agent, "id")
    merged_workflows = _merge_by_key(workflows_by_agent, "id")
    scope = scope_label or ("project" if project else "global")
    wf_suffix = "inline" if mode == "full" else "on-demand via MCP"

    print(_section("Rules & Workflows"))
    print(f"  Found {_c(str(len(merged_rules)), 'bold')} rules, {_c(str(len(merged_workflows)), 'bold')} workflows")
    print(f"  Mode: {_c(mode, 'bold')} ({wf_suffix}) · Scope: {_c(scope, 'bold')}")
    if multi and confirm:
        for rule, agent_keys in merged_rules:
            name = rule.get("name", "(unnamed)")
            print(f"    {name}  {_agent_badges(agent_keys)}")

    if confirm:
        if not _confirm("  Install?", default_yes=True):
            print(_c("  → Skipped", "yellow"))
            return

    for agent in agents:
        section = _render_section(
            rules_by_agent[agent.key], workflows_by_agent[agent.key],
            mode=mode, agent=agent.key,
        )
        target = _resolve_target(agent, project)
        _inject_section(target, section)
        n_rules = len(rules_by_agent[agent.key])
        n_wf = len(workflows_by_agent[agent.key])
        if multi:
            print(_agent_success(agent, f"{target} ({n_rules} rules, {n_wf} workflows)"))
        else:
            print(_c(f"  ✓ Injected into {target}", "green"))


def _apply_skills(
    agents: list[AgentDef],
    skills_by_agent: dict[str, list[dict]],
    project: bool,
    multi: bool,
    *,
    confirm: bool = False,
    show_descriptions: bool = False,
) -> tuple[int, int]:
    """Merge, display, and install skills for all agents. Returns (installed, cleaned)."""
    merged_skills = _merge_by_key(skills_by_agent, "slug")
    total_installed = 0
    total_cleaned = 0

    print(_section("Skills"))
    if merged_skills:
        print(f"  Found {_c(str(len(merged_skills)), 'bold')} skills:")
        for s, agent_keys in merged_skills:
            name = s.get("name", "(unnamed)")
            slug = s.get("slug", "")
            invocable = f" {_c(f'/{slug}', 'cyan')}" if s.get("user_invocable") and slug else ""
            badges = f"  {_agent_badges(agent_keys)}" if multi else ""
            line = f"    {name}{invocable}{badges}"
            if show_descriptions:
                desc = s.get("description", "")
                if desc:
                    line += f" {_c(f'— {desc}', 'dim')}"
            print(line)

        if confirm:
            should_install = _confirm("  Install skills?", default_yes=True)
            if not should_install:
                print(_c("  → Skipped", "yellow"))
                return total_installed, total_cleaned

        for agent in agents:
            agent_skills = skills_by_agent[agent.key]
            if not agent_skills:
                continue
            n = _install_skills(agent, agent_skills, project=project)
            total_installed += n
            cleaned = _cleanup_stale_commands(agent, agent_skills, project=project)
            total_cleaned += cleaned
            if multi:
                msg = _agent_success(agent, f"{n} skills")
                if cleaned:
                    msg += f" ({cleaned} stale commands removed)"
                print(msg)
            else:
                skill_base = _skills_base(agent, project)
                msg = _c(f"  ✓ Installed {n} skills to {skill_base}/", "green")
                if cleaned:
                    msg += f" {_c(f'({cleaned} stale commands removed)', 'dim')}"
                print(msg)
    else:
        print(_c("  No skills found.", "dim"))

    return total_installed, total_cleaned


def _apply_mcp(agents: list[AgentDef], api_url: str, api_key: str, multi: bool) -> int:
    """Configure knktx MCP server for all agents. Returns count of successful configs."""
    ok_count = 0
    for agent in agents:
        ok = _configure_mcp(agent, api_url, api_key)
        if ok:
            ok_count += 1
            if multi:
                print(_agent_success(agent, "configured"))
            else:
                print(_c("  ✓ MCP server configured (scope: user)", "green"))
        else:
            if multi:
                print(_c(f"  → {agent.display_name}", "yellow") + " — skipped")
            else:
                print(_c("  → Skipped (see warnings above)", "yellow"))
    return ok_count


def cmd_update(args: argparse.Namespace) -> None:
    """Update only the knktx MCP server config (no rules, workflows, or skills)."""
    print(_banner())

    agents = _resolve_agents(args)
    multi = len(agents) > 1

    api_key, key_source = _resolve_api_key(args, agents)
    api_url = _resolve_api_url()

    _client, api_key, _settings_rules = _connect(api_url, api_key, key_source)
    _client.close()
    print(_c("  Connected", "green"))

    if multi:
        print(f"  Agents: {_agent_name_list(agents)}")

    print(_section("knktx MCP Server"))
    ok_count = _apply_mcp(agents, api_url, api_key, multi)

    agent_suffix = f" across {_c(str(len(agents)), 'bold')} agents" if multi else ""
    print(f"\n{_c('✓', 'green')} {_c('Done!', 'green', 'bold')} MCP server {'reconfigured' if ok_count else 'unchanged'}{agent_suffix}.")


def cmd_init(args: argparse.Namespace) -> None:
    """Run the full init — rules, workflows, skills, MCP server, configs, plugins.

    Supports multi-agent mode (``--all``) where each section fetches per-agent,
    shows merged items with color-coded agent badges, prompts once, then installs
    for all applicable agents.
    """
    print(_banner())

    agents = _resolve_agents(args)
    multi = len(agents) > 1

    api_key, key_source = _resolve_api_key(args, agents)
    api_url = _resolve_api_url()

    client, api_key, settings_rules = _connect(api_url, api_key, key_source)
    try:
        print(_c("  Connected", "green"))

        api_mode = _read_injection_mode(settings_rules)
        mode = _resolve_mode(args, api_mode)
        scope = _resolve_scope(args, client)

        if multi:
            print(f"  Agents: {_agent_name_list(agents)}")

        # Fetch per agent — global rules (always needed for global or both)
        global_rules_by_agent: dict[str, list[dict]] = {}
        project_rules_by_agent: dict[str, list[dict]] = {}
        workflows_by_agent: dict[str, list[dict]] = {}
        skills_by_agent: dict[str, list[dict]] = {}
        mcp_configs_by_agent: dict[str, list[dict]] = {}
        for agent in agents:
            if scope.is_global:
                global_rules_by_agent[agent.key] = _fetch_rules(client, agent=agent.key)
            if scope.is_project:
                project_rules_by_agent[agent.key] = _fetch_rules(
                    client, agent=agent.key, project_slug=scope.project_slug,
                )
            if not scope.is_project_only:
                workflows_by_agent[agent.key] = _fetch_workflows(client, agent=agent.key)
                skills_by_agent[agent.key] = _fetch_enabled(client, "/skills", agent=agent.key)
                mcp_configs_by_agent[agent.key] = _fetch_enabled(client, "/mcp-configs", agent=agent.key)
        # Plugins are agent-agnostic — fetch once (skip for project-only scope)
        plugins: list[dict] = [] if scope.is_project_only else _fetch_enabled(client, "/plugins")
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            print(_c("Error: Invalid API key.", "red"), file=sys.stderr)
        else:
            print(_c(f"Error: API returned {e.response.status_code}.", "red"), file=sys.stderr)
        sys.exit(1)
    except httpx.RequestError as e:
        print(_c(f"Error: Could not reach API at {api_url}: {e}", "red"), file=sys.stderr)
        sys.exit(1)
    except (ValueError, json.JSONDecodeError) as e:
        print(_c(f"Error: API returned an invalid response: {e}", "red"), file=sys.stderr)
        sys.exit(1)
    finally:
        client.close()

    # ---- Rules & Workflows ----
    confirm_init = not args.yes

    # Workflows are injected only in the global pass to avoid duplicating them
    # across both config files when scope is BOTH.
    if scope.is_global:
        _apply_rules_and_workflows(
            agents, global_rules_by_agent, workflows_by_agent, mode,
            project=False, multi=multi, confirm=confirm_init,
            scope_label="global" if scope.kind == _Scope.BOTH else None,
        )
    if scope.is_project:
        empty_workflows: dict[str, list[dict]] = {k: [] for k in project_rules_by_agent}
        _apply_rules_and_workflows(
            agents, project_rules_by_agent, empty_workflows, mode,
            project=True, multi=multi, confirm=confirm_init,
            scope_label=f"project ({scope.project_slug})",
        )

    total_skills_installed = 0
    total_commands_cleaned = 0
    total_mcp_installed = 0
    total_mcp_attempted = 0
    plugins_executed = 0
    plugins_attempted = 0

    if not scope.is_project_only:
        # ---- Skills ----
        total_skills_installed, total_commands_cleaned = _apply_skills(
            agents, skills_by_agent, False, multi,
            confirm=confirm_init, show_descriptions=True,
        )

        # ---- knktx MCP Server ----
        print(_section("knktx MCP Server"))
        _apply_mcp(agents, api_url, api_key, multi)

        # ---- User MCP Configs ----
        merged_configs = _merge_by_key(mcp_configs_by_agent, "name")

        print(_section("MCP Configs"))
        if merged_configs:
            print(f"  Found {_c(str(len(merged_configs)), 'bold')} MCP configs:")
            for c, agent_keys in merged_configs:
                name = c.get("name", "(unnamed)")
                desc = c.get("description", "")
                badges = f"  {_agent_badges(agent_keys)}" if multi else ""
                line = f"    {name}{badges}"
                if desc:
                    line += f" {_c(f'— {desc}', 'dim')}"
                print(line)

            should_install_mcp = args.yes or _confirm("  Install MCP configs?", default_yes=True)
            if should_install_mcp:
                for agent in agents:
                    agent_configs = mcp_configs_by_agent[agent.key]
                    if not agent_configs:
                        continue
                    installed, attempted = _install_mcp_configs(agent, agent_configs)
                    total_mcp_installed += installed
                    total_mcp_attempted += attempted
                    failed = attempted - installed
                    if multi:
                        msg = _agent_success(agent, f"{installed} configs")
                        if failed:
                            msg += f" {_c(f'({failed} failed)', 'yellow')}"
                        print(msg)
                    else:
                        if failed:
                            print(_c(f"  ✓ Installed {installed}/{attempted} MCP configs ", "green") + _c(f"({failed} failed)", "yellow"))
                        else:
                            print(_c(f"  ✓ Installed {installed} MCP configs", "green"))
            else:
                print(_c("  → Skipped", "yellow"))
        else:
            print(_c("  No MCP configs found.", "dim"))

        # ---- Plugins (run once, not per-agent) ----
        print(_section("Plugins"))
        if plugins:
            print(f"  Found {_c(str(len(plugins)), 'bold')} plugins:")
            for p in plugins:
                name = p.get("name", "(unnamed)")
                desc = p.get("description", "")
                line = f"    {name}"
                if desc:
                    line += f" {_c(f'— {desc}', 'dim')}"
                print(line)

            auto_plugins = args.yes and args.plugins
            if auto_plugins:
                plugins_executed, plugins_attempted = _execute_plugins(plugins, auto=True)
            else:
                should_run = _confirm("  Review and run plugins?", default_yes=False)
                if should_run:
                    plugins_executed, plugins_attempted = _execute_plugins(plugins)
                else:
                    print(_c("  → Skipped", "yellow"))
        else:
            print(_c("  No plugins found.", "dim"))

    # ---- Summary ----
    all_rules_by_agent = {
        k: global_rules_by_agent.get(k, []) + project_rules_by_agent.get(k, [])
        for k in {*global_rules_by_agent, *project_rules_by_agent}
    }
    n_rules = len(_merge_by_key(all_rules_by_agent, "id"))
    n_workflows = len(_merge_by_key(workflows_by_agent, "id"))
    agent_suffix = f" across {_c(str(len(agents)), 'bold')} agents" if multi else ""
    parts = [f"{_c(str(n_rules), 'bold')} rules"]
    if n_workflows:
        parts.append(f"{_c(str(n_workflows), 'bold')} workflows")
    if total_skills_installed:
        parts.append(f"{_c(str(total_skills_installed), 'bold')} skills")
    if total_mcp_attempted:
        failed = total_mcp_attempted - total_mcp_installed
        if failed:
            parts.append(f"{_c(str(total_mcp_installed), 'bold')}/{total_mcp_attempted} MCP configs")
        else:
            parts.append(f"{_c(str(total_mcp_installed), 'bold')} MCP configs")
    if plugins_attempted:
        failed = plugins_attempted - plugins_executed
        if failed:
            parts.append(f"{_c(str(plugins_executed), 'bold')}/{plugins_attempted} plugins executed")
        else:
            parts.append(f"{_c(str(plugins_executed), 'bold')} plugins executed")
    if total_commands_cleaned:
        parts.append(f"{_c(str(total_commands_cleaned), 'bold')} stale commands cleaned")
    print(f"\n{_c('✓', 'green')} {_c('Done!', 'green', 'bold')} {', '.join(parts)} applied{agent_suffix}.")


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="knktx",
        description="Bootstrap agents with knktx rules, workflows, skills, MCP configs, and plugins.",
    )
    try:
        from importlib.metadata import version as _pkg_version
        _ver = _pkg_version("knktx")
    except Exception:
        _ver = "unknown"
    parser.add_argument("--version", action="version", version=f"%(prog)s {_ver}")
    sub = parser.add_subparsers(dest="command")

    # Shared arguments for init and update
    def _add_common_args(p: argparse.ArgumentParser) -> None:
        p.add_argument(
            "--key",
            help="API key (prefer KNKTX_API_KEY env var to avoid shell history exposure)",
        )
        p.add_argument("--project", action="store_true", help="Write to project-level config instead of global")
        p.add_argument("--project-slug", default=None, help="Project slug for project-scoped rules (overrides --project)")
        p.add_argument(
            "--mode",
            choices=list(VALID_MODES),
            default=None,
            help="full = all rules+workflows inline; soft = rules inline, workflows via MCP (default: from settings, or full)",
        )
        agent_group = p.add_mutually_exclusive_group()
        agent_group.add_argument(
            "--agent",
            default=None,
            type=str.lower,
            help="Install for a single agent (e.g. claude, gemini, codex)",
        )
        agent_group.add_argument(
            "--all",
            dest="all_agents",
            action="store_true",
            default=False,
            help="Install for all detected agents at once",
        )
        p.add_argument(
            "-y", "--yes",
            action="store_true",
            help="Auto-accept prompts for skills, MCP configs, scope, mode, and agent (plugins still require --plugins)",
        )
        p.add_argument(
            "--plugins",
            action="store_true",
            help="With -y, also auto-execute plugins (requires explicit opt-in due to shell execution)",
        )

    init_parser = sub.add_parser("init", help="Full setup — rules, workflows, skills, MCP server, configs, plugins")
    _add_common_args(init_parser)

    sync_parser = sub.add_parser("sync", help="Alias for init — sync everything from knktx")
    _add_common_args(sync_parser)

    update_parser = sub.add_parser("update", help="Update only the knktx MCP server config")
    _add_common_args(update_parser)

    args = parser.parse_args()

    if args.command in ("init", "sync"):
        cmd_init(args)
    elif args.command == "update":
        cmd_update(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
