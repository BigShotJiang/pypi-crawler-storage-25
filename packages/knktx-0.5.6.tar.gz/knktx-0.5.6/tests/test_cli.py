"""Tests for knktx CLI — agents, skills, MCP configs, plugins, and interactive resolvers."""

import json
import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from knktx_mcp.cli import (
    AGENT_BY_KEY,
    AGENT_COLORS,
    AGENT_REGISTRY,
    AgentDef,
    _AgentNotFoundError,
    _agent_badge,
    _agent_badges,
    _agent_dir,
    _build_mcp_cmd,
    _build_mcp_remove_cmd,
    _build_skill_md,
    _cleanup_stale_commands,
    _configure_mcp,
    _confirm,
    _execute_plugin,
    _execute_plugins,
    _fetch_enabled,
    _install_mcp_config,
    _install_mcp_configs,
    _is_safe_file_path,
    _remove_mcp_config,
    _install_skills,
    _merge_by_key,
    _prompt,
    _resolve_agent,
    _resolve_agents,
    _resolve_api_key,
    _resolve_mode,
    _resolve_scope,
    _Scope,
    _resolve_target,
    _sanitize_yaml_value,
    detect_agents,
)

CLAUDE = AGENT_BY_KEY["claude"]
GEMINI = AGENT_BY_KEY["gemini"]
CODEX = AGENT_BY_KEY["codex"]

_SIMPLE_SKILL = {"slug": "test-skill", "name": "Test", "files": [{"path": "SKILL.md", "content": "Test content."}]}


# ---------------------------------------------------------------------------
# _sanitize_yaml_value
# ---------------------------------------------------------------------------


def test_sanitize_yaml_value_escapes_quotes():
    assert _sanitize_yaml_value('A "great" skill') == 'A \\"great\\" skill'


def test_sanitize_yaml_value_strips_newlines():
    assert _sanitize_yaml_value("line1\nline2\r\nline3") == "line1 line2 line3"


# ---------------------------------------------------------------------------
# _build_skill_md
# ---------------------------------------------------------------------------


def test_build_skill_md_basic():
    skill = {
        "slug": "commit",
        "name": "Commit Helper",
        "files": [{"path": "SKILL.md", "content": "Help the user create a good commit message."}],
    }
    result = _build_skill_md(skill)
    assert result.startswith("---\n")
    assert 'name: "commit"' in result
    assert "Help the user create a good commit message." in result
    assert "user-invocable" not in result
    assert "allowed-tools" not in result
    assert "description" not in result


def test_build_skill_md_user_invocable():
    skill = {
        "slug": "review",
        "name": "Review PR",
        "description": "Review a pull request",
        "files": [{"path": "SKILL.md", "content": "Review the PR thoroughly."}],
        "user_invocable": True,
    }
    result = _build_skill_md(skill)
    assert "user-invocable: true" in result
    assert 'description: "Review a pull request"' in result


def test_build_skill_md_allowed_tools_list():
    skill = {
        "slug": "reader",
        "name": "Reader",
        "files": [{"path": "SKILL.md", "content": "Read files only."}],
        "allowed_tools": ["Read", "Glob", "Grep"],
    }
    result = _build_skill_md(skill)
    assert "allowed-tools: [Read, Glob, Grep]" in result


def test_build_skill_md_allowed_tools_empty():
    """Empty allowed_tools = no tools allowed, different from null (all tools)."""
    skill = {
        "slug": "noop",
        "name": "No Tools",
        "files": [{"path": "SKILL.md", "content": "Cannot use any tools."}],
        "allowed_tools": [],
    }
    result = _build_skill_md(skill)
    assert "allowed-tools: []" in result


def test_build_skill_md_allowed_tools_null():
    """Null allowed_tools = all tools allowed, no frontmatter entry."""
    skill = {
        "slug": "full",
        "name": "Full Access",
        "files": [{"path": "SKILL.md", "content": "Use any tools."}],
        "allowed_tools": None,
    }
    result = _build_skill_md(skill)
    assert "allowed-tools" not in result


def test_build_skill_md_empty_content():
    skill = {
        "slug": "empty",
        "name": "Empty",
        "files": [],
    }
    result = _build_skill_md(skill)
    assert result.endswith("---\n")


def test_build_skill_md_full_frontmatter():
    skill = {
        "slug": "full-skill",
        "name": "Full Skill",
        "description": "A complete skill",
        "files": [{"path": "SKILL.md", "content": "Do everything."}],
        "user_invocable": True,
        "allowed_tools": ["Read", "Write"],
    }
    result = _build_skill_md(skill)
    lines = result.split("\n")
    assert lines[0] == "---"
    assert 'name: "full-skill"' in result
    assert 'description: "A complete skill"' in result
    assert "user-invocable: true" in result
    assert "allowed-tools: [Read, Write]" in result
    assert "Do everything." in result


def test_build_skill_md_description_with_quotes():
    """Descriptions with double quotes are escaped to prevent YAML injection."""
    skill = {
        "slug": "quoted",
        "name": "Quoted",
        "description": 'A "great" skill',
        "files": [{"path": "SKILL.md", "content": "body"}],
    }
    result = _build_skill_md(skill)
    assert 'description: "A \\"great\\" skill"' in result


def test_build_skill_md_description_with_newlines():
    """Descriptions with newlines are sanitized to prevent frontmatter injection."""
    skill = {
        "slug": "newline",
        "name": "Newline",
        "description": "line1\nuser-invocable: true",
        "files": [{"path": "SKILL.md", "content": "body"}],
    }
    result = _build_skill_md(skill)
    assert "user-invocable" not in result.split("---")[1].split("description")[0]
    assert "line1 user-invocable: true" in result


# ---------------------------------------------------------------------------
# _install_skills
# ---------------------------------------------------------------------------


def test_install_skills_writes_files(tmp_path, monkeypatch):
    """Skills are written to correct paths with correct content."""
    monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path))
    skills = [
        {
            "slug": "commit",
            "name": "Commit",
            "files": [{"path": "SKILL.md", "content": "Create a commit."}],
            "user_invocable": True,
        },
        {
            "slug": "review",
            "name": "Review",
            "files": [{"path": "SKILL.md", "content": "Review code."}],
            "description": "Code reviewer",
        },
    ]
    count = _install_skills(CLAUDE, skills, project=False)

    assert count == 2

    commit_file = tmp_path / ".claude" / "skills" / "commit" / "SKILL.md"
    assert commit_file.exists()
    content = commit_file.read_text()
    assert 'name: "commit"' in content
    assert "user-invocable: true" in content
    assert "Create a commit." in content

    review_file = tmp_path / ".claude" / "skills" / "review" / "SKILL.md"
    assert review_file.exists()
    content = review_file.read_text()
    assert 'description: "Code reviewer"' in content
    assert "Review code." in content


def test_install_skills_gemini_global(tmp_path, monkeypatch):
    """Gemini global skills go to ~/.gemini/skills/."""
    monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path))
    count = _install_skills(GEMINI, [_SIMPLE_SKILL], project=False)
    assert count == 1
    assert (tmp_path / ".gemini" / "skills" / "test-skill" / "SKILL.md").exists()


def test_install_skills_codex_global(tmp_path, monkeypatch):
    """Codex global skills go to ~/.codex/skills/."""
    monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path))
    count = _install_skills(CODEX, [_SIMPLE_SKILL], project=False)
    assert count == 1
    assert (tmp_path / ".codex" / "skills" / "test-skill" / "SKILL.md").exists()


def test_install_skills_project_scope(tmp_path, monkeypatch):
    """Project-scoped skills go to .claude/skills/ in current directory."""
    monkeypatch.chdir(tmp_path)
    count = _install_skills(CLAUDE, [_SIMPLE_SKILL], project=True)
    assert count == 1
    assert (tmp_path / ".claude" / "skills" / "test-skill" / "SKILL.md").exists()


def test_install_skills_codex_project_scope(tmp_path, monkeypatch):
    """Codex project-scoped skills go to .agents/skills/ (not .codex/skills/)."""
    monkeypatch.chdir(tmp_path)
    count = _install_skills(CODEX, [_SIMPLE_SKILL], project=True)
    assert count == 1
    assert (tmp_path / ".agents" / "skills" / "test-skill" / "SKILL.md").exists()
    assert not (tmp_path / ".codex" / "skills" / "test-skill" / "SKILL.md").exists()


def test_install_skills_skips_no_slug(tmp_path, monkeypatch, capsys):
    """Skills without a slug are skipped with a warning."""
    monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path))
    skills = [{"name": "No Slug", "files": [{"path": "SKILL.md", "content": "test"}]}]
    count = _install_skills(CLAUDE, skills, project=False)
    assert count == 0
    captured = capsys.readouterr()
    assert "Skipping skill with no slug: No Slug" in captured.err


def test_install_skills_rejects_invalid_slug(tmp_path, monkeypatch, capsys):
    """Skills with path-traversal slugs are rejected."""
    monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path))
    skills = [{"slug": "../../etc/evil", "name": "Evil", "files": [{"path": "SKILL.md", "content": "bad"}]}]
    count = _install_skills(CLAUDE, skills, project=False)
    assert count == 0
    captured = capsys.readouterr()
    assert "invalid slug" in captured.err


def test_install_skills_writes_multi_file(tmp_path, monkeypatch):
    """Multi-file skills create nested directories and write all files."""
    monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path))
    skills = [
        {
            "slug": "pr-swarm",
            "name": "PR Swarm",
            "files": [
                {"path": "SKILL.md", "content": "Review PRs."},
                {"path": "agents/code.md", "content": "Code review agent."},
                {"path": "agents/security.md", "content": "Security agent."},
                {"path": "config.json", "content": '{"timeout": 30}'},
            ],
        },
    ]
    count = _install_skills(CLAUDE, skills, project=False)
    assert count == 1

    skill_dir = tmp_path / ".claude" / "skills" / "pr-swarm"
    # SKILL.md has generated frontmatter
    skill_md = skill_dir / "SKILL.md"
    assert skill_md.exists()
    content = skill_md.read_text()
    assert 'name: "pr-swarm"' in content
    assert "Review PRs." in content

    # Nested files written as-is
    assert (skill_dir / "agents" / "code.md").read_text() == "Code review agent."
    assert (skill_dir / "agents" / "security.md").read_text() == "Security agent."
    assert (skill_dir / "config.json").read_text() == '{"timeout": 30}'


def test_install_skills_skips_unsafe_file_paths(tmp_path, monkeypatch, capsys):
    """Files with unsafe paths are skipped with a warning."""
    monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path))
    skills = [
        {
            "slug": "safe-skill",
            "name": "Safe",
            "files": [
                {"path": "SKILL.md", "content": "Body."},
                {"path": "../escape.txt", "content": "should not exist"},
                {"path": "/etc/passwd", "content": "should not exist"},
                {"path": "legit.md", "content": "this is fine"},
            ],
        },
    ]
    count = _install_skills(CLAUDE, skills, project=False)
    assert count == 1

    skill_dir = tmp_path / ".claude" / "skills" / "safe-skill"
    assert (skill_dir / "SKILL.md").exists()
    assert (skill_dir / "legit.md").read_text() == "this is fine"
    # Unsafe paths not written
    assert not (tmp_path / "escape.txt").exists()
    # Warnings printed for unsafe paths
    captured = capsys.readouterr()
    assert "Skipping unsafe file path" in captured.err


def test_install_skills_empty_files_array(tmp_path, monkeypatch):
    """Skill with empty files array still writes SKILL.md (frontmatter only)."""
    monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path))
    skills = [{"slug": "empty-skill", "name": "Empty", "files": []}]
    count = _install_skills(CLAUDE, skills, project=False)
    assert count == 1
    skill_md = tmp_path / ".claude" / "skills" / "empty-skill" / "SKILL.md"
    assert skill_md.exists()
    content = skill_md.read_text()
    assert 'name: "empty-skill"' in content


# ---------------------------------------------------------------------------
# _is_safe_file_path
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("path", [
    "agents/code.md",
    "config.json",
    "a/b/c/d.txt",
    ".gitignore",
    ".config/settings.json",
    "./agents/code.md",  # leading ./ is normalised
])
def test_is_safe_file_path_valid(path):
    """Normal and dotfile paths are safe."""
    assert _is_safe_file_path(path) is True


@pytest.mark.parametrize("path,reason", [
    ("../escape.txt", "traversal"),
    ("a/../b.txt", "traversal"),
    ("..", "traversal"),
    ("/etc/passwd", "absolute"),
    ("agents\\code.md", "backslash"),
    ("file\x00.md", "null byte"),
    ("", "empty"),
    (".", "bare dot"),
    ("a/./b.txt", "bare dot segment"),
])
def test_is_safe_file_path_rejects(path, reason):
    """Unsafe paths are rejected: {reason}."""
    assert _is_safe_file_path(path) is False


def test_install_skills_none_files_key(tmp_path, monkeypatch):
    """Skill with files=None still writes SKILL.md (frontmatter only)."""
    monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path))
    skills = [{"slug": "none-files", "name": "None", "files": None}]
    count = _install_skills(CLAUDE, skills, project=False)
    assert count == 1
    skill_md = tmp_path / ".claude" / "skills" / "none-files" / "SKILL.md"
    assert skill_md.exists()


def test_install_skills_case_insensitive_skill_md(tmp_path, monkeypatch):
    """Files named skill.md (lowercase) don't overwrite generated SKILL.md."""
    monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path))
    skills = [
        {
            "slug": "cased",
            "name": "Cased",
            "files": [
                {"path": "SKILL.md", "content": "Body."},
                {"path": "skill.md", "content": "should not overwrite"},
            ],
        },
    ]
    count = _install_skills(CLAUDE, skills, project=False)
    assert count == 1
    content = (tmp_path / ".claude" / "skills" / "cased" / "SKILL.md").read_text()
    assert "Body." in content
    # The lowercase variant should not overwrite the generated frontmatter
    assert "should not overwrite" not in content


def test_install_skills_normalises_dot_slash_prefix(tmp_path, monkeypatch):
    """Files with ./ prefix are normalised and written correctly."""
    monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path))
    skills = [
        {
            "slug": "dotslash",
            "name": "DotSlash",
            "files": [
                {"path": "SKILL.md", "content": "Body."},
                {"path": "./config.json", "content": '{"ok": true}'},
            ],
        },
    ]
    count = _install_skills(CLAUDE, skills, project=False)
    assert count == 1
    # ./config.json should be written as config.json
    assert (tmp_path / ".claude" / "skills" / "dotslash" / "config.json").exists()


# ---------------------------------------------------------------------------
# _prompt
# ---------------------------------------------------------------------------


def test_prompt_returns_input():
    with patch("builtins.input", return_value="hello"):
        assert _prompt("msg") == "hello"


def test_prompt_returns_default_on_empty():
    with patch("builtins.input", return_value=""):
        assert _prompt("msg", "default") == "default"


def test_prompt_strips_whitespace():
    with patch("builtins.input", return_value="  spaced  "):
        assert _prompt("msg") == "spaced"


def test_prompt_exits_on_eof():
    with patch("builtins.input", side_effect=EOFError):
        with pytest.raises(SystemExit):
            _prompt("msg")


def test_prompt_exits_on_ctrl_c():
    with patch("builtins.input", side_effect=KeyboardInterrupt):
        with pytest.raises(SystemExit):
            _prompt("msg")


# ---------------------------------------------------------------------------
# _confirm
# ---------------------------------------------------------------------------


def test_confirm_yes():
    with patch("builtins.input", return_value="y"):
        assert _confirm("proceed?") is True


def test_confirm_yes_full():
    with patch("builtins.input", return_value="yes"):
        assert _confirm("proceed?") is True


def test_confirm_yes_uppercase():
    with patch("builtins.input", return_value="YES"):
        assert _confirm("proceed?") is True


def test_confirm_no():
    with patch("builtins.input", return_value="n"):
        assert _confirm("proceed?") is False


def test_confirm_default_yes():
    with patch("builtins.input", return_value=""):
        assert _confirm("proceed?", default_yes=True) is True


def test_confirm_default_no():
    with patch("builtins.input", return_value=""):
        assert _confirm("proceed?", default_yes=False) is False


# ---------------------------------------------------------------------------
# _resolve_mode
# ---------------------------------------------------------------------------


class _FakeArgs:
    """Minimal args namespace for resolver tests."""
    def __init__(self, **kwargs):
        self.mode = kwargs.get("mode")
        self.project = kwargs.get("project", False)
        self.project_slug = kwargs.get("project_slug")
        self.agent = kwargs.get("agent")
        self.yes = kwargs.get("yes", False)
        self.key = kwargs.get("key")
        self.all_agents = kwargs.get("all_agents", False)


def test_resolve_mode_from_flag():
    args = _FakeArgs(mode="soft")
    assert _resolve_mode(args, api_mode=None) == "soft"


def test_resolve_mode_from_api():
    args = _FakeArgs()
    assert _resolve_mode(args, api_mode="soft") == "soft"


def test_resolve_mode_flag_overrides_api():
    args = _FakeArgs(mode="full")
    assert _resolve_mode(args, api_mode="soft") == "full"


def test_resolve_mode_yes_defaults_soft():
    args = _FakeArgs(yes=True)
    assert _resolve_mode(args, api_mode=None) == "soft"


def test_resolve_mode_interactive_pick():
    args = _FakeArgs()
    with patch("knktx_mcp.cli._pick", return_value=1):  # "soft"
        result = _resolve_mode(args, api_mode=None)
    assert result == "soft"


# ---------------------------------------------------------------------------
# _resolve_scope
# ---------------------------------------------------------------------------


def test_resolve_scope_project_slug_flag():
    args = _FakeArgs(project_slug="my-project")
    scope = _resolve_scope(args)
    assert scope.kind == _Scope.PROJECT
    assert scope.project_slug == "my-project"


def test_resolve_scope_yes_defaults_global():
    args = _FakeArgs(yes=True)
    scope = _resolve_scope(args)
    assert scope.kind == _Scope.GLOBAL
    assert scope.project_slug is None


def test_resolve_scope_project_flag_without_client_exits(capsys):
    args = _FakeArgs(project=True)
    with pytest.raises(SystemExit):
        _resolve_scope(args, client=None)


def test_resolve_scope_project_flag_with_client():
    args = _FakeArgs(project=True)
    mock_client = MagicMock()
    with patch("knktx_mcp.cli._pick_project_scope", return_value=_Scope(_Scope.PROJECT, "picked")) as mock_pick:
        scope = _resolve_scope(args, client=mock_client)
    mock_pick.assert_called_once_with(mock_client)
    assert scope.kind == _Scope.PROJECT
    assert scope.project_slug == "picked"


def test_resolve_scope_interactive_global():
    args = _FakeArgs()
    mock_client = MagicMock()
    with patch("knktx_mcp.cli._fetch_projects_with_rules", return_value=[{"slug": "p1", "name": "P1"}]):
        with patch("knktx_mcp.cli._pick", return_value=0):  # "Global only"
            scope = _resolve_scope(args, client=mock_client)
    assert scope.kind == _Scope.GLOBAL


def test_resolve_scope_interactive_both():
    args = _FakeArgs()
    mock_client = MagicMock()
    with patch("knktx_mcp.cli._fetch_projects_with_rules", return_value=[{"slug": "p1", "name": "P1"}]):
        with patch("knktx_mcp.cli._pick", return_value=2):  # "Global + Project"
            with patch("knktx_mcp.cli._pick_project", return_value="p1"):
                scope = _resolve_scope(args, client=mock_client)
    assert scope.kind == _Scope.BOTH
    assert scope.project_slug == "p1"


def test_resolve_scope_no_projects_with_rules_defaults_global(capsys):
    args = _FakeArgs()
    mock_client = MagicMock()
    with patch("knktx_mcp.cli._fetch_projects_with_rules", return_value=[]):
        scope = _resolve_scope(args, client=mock_client)
    assert scope.kind == _Scope.GLOBAL


# ---------------------------------------------------------------------------
# _install_mcp_config
# ---------------------------------------------------------------------------


def test_install_mcp_config_success():
    config = {"type": "stdio", "command": "uvx", "args": ["test-mcp"]}
    with patch("subprocess.run") as mock_run:
        result = _install_mcp_config(CLAUDE, "test-server", config)
    assert result is True
    # Called twice: first remove, then add
    assert mock_run.call_count == 2
    expected = [CLAUDE.binary, "mcp", "add-json", "test-server", json.dumps(config), "--scope", "user"]
    call_args = mock_run.call_args[0][0]
    assert call_args == expected


def test_install_mcp_config_agent_not_found():
    config = {"type": "stdio", "command": "test"}
    with patch("subprocess.run", side_effect=FileNotFoundError):
        with pytest.raises(_AgentNotFoundError):
            _install_mcp_config(CLAUDE, "test", config)


def test_install_mcp_config_failure(capsys):
    config = {"type": "stdio", "command": "test"}
    # remove succeeds (returns None), then add fails
    with patch("knktx_mcp.cli._remove_mcp_config"), \
         patch("subprocess.run", side_effect=subprocess.CalledProcessError(1, "claude", stderr="err")):
        result = _install_mcp_config(CLAUDE, "test", config)
    assert result is False
    assert "Failed to install MCP config" in capsys.readouterr().err


def test_install_mcp_config_gemini_success():
    config = {"command": "uvx", "args": ["test-mcp"], "env": {"API_KEY": "secret"}}
    with patch("subprocess.run") as mock_run:
        result = _install_mcp_config(GEMINI, "test-server", config)
    assert result is True
    cmd = mock_run.call_args[0][0]
    assert cmd == ["gemini", "mcp", "add", "test-server", "uvx", "test-mcp", "-s", "user", "-e", "API_KEY=secret"]


def test_install_mcp_config_codex_success():
    config = {"command": "uvx", "args": ["test-mcp"], "env": {"API_KEY": "secret"}}
    with patch("subprocess.run") as mock_run:
        result = _install_mcp_config(CODEX, "test-server", config)
    assert result is True
    cmd = mock_run.call_args[0][0]
    assert cmd == ["codex", "mcp", "add", "test-server", "--env", "API_KEY=secret", "--", "uvx", "test-mcp"]


def test_install_mcp_config_missing_command(capsys):
    """Config without 'command' field fails gracefully."""
    config = {"type": "stdio"}
    result = _install_mcp_config(GEMINI, "bad", config)
    assert result is False
    assert "missing 'command'" in capsys.readouterr().err


# ---------------------------------------------------------------------------
# _build_mcp_remove_cmd
# ---------------------------------------------------------------------------


def test_build_mcp_remove_cmd_claude():
    cmd = _build_mcp_remove_cmd(CLAUDE, "knktx")
    assert cmd == ["claude", "mcp", "remove", "knktx", "-s", "user"]


def test_build_mcp_remove_cmd_gemini():
    cmd = _build_mcp_remove_cmd(GEMINI, "knktx")
    assert cmd == ["gemini", "mcp", "remove", "knktx", "-s", "user"]


def test_build_mcp_remove_cmd_codex():
    cmd = _build_mcp_remove_cmd(CODEX, "knktx")
    assert cmd == ["codex", "mcp", "remove", "knktx"]


def test_build_mcp_remove_cmd_unknown_agent():
    """Unknown agent falls through to generic remove command."""
    fake_agent = AgentDef(
        key="unknown", display_name="Unknown", binary="unknown-cli",
        config_dir=".unknown", instructions_file="UNKNOWN.md",
        skills_dir="skills", project_skills_dir=None,
        project_instructions_dir=None, install_hint="install unknown",
    )
    cmd = _build_mcp_remove_cmd(fake_agent, "knktx")
    assert cmd == ["unknown-cli", "mcp", "remove", "knktx"]


# ---------------------------------------------------------------------------
# _remove_mcp_config
# ---------------------------------------------------------------------------


def test_remove_mcp_config_success():
    """Remove runs the command and completes silently."""
    with patch("subprocess.run") as mock_run:
        _remove_mcp_config(CLAUDE, "knktx")
    mock_run.assert_called_once()
    cmd = mock_run.call_args[0][0]
    assert cmd == ["claude", "mcp", "remove", "knktx", "-s", "user"]


def test_remove_mcp_config_not_found():
    """Swallows FileNotFoundError when agent binary is missing."""
    with patch("subprocess.run", side_effect=FileNotFoundError):
        _remove_mcp_config(CLAUDE, "knktx")  # should not raise


def test_remove_mcp_config_timeout():
    """Swallows TimeoutExpired when command hangs."""
    with patch("subprocess.run", side_effect=subprocess.TimeoutExpired("claude", 30)):
        _remove_mcp_config(CLAUDE, "knktx")  # should not raise


# ---------------------------------------------------------------------------
# _build_mcp_cmd
# ---------------------------------------------------------------------------


def test_build_mcp_cmd_claude():
    config = {"command": "uvx", "args": ["test"], "env": {"K": "V"}}
    cmd = _build_mcp_cmd(CLAUDE, "srv", config)
    assert cmd == ["claude", "mcp", "add-json", "srv", json.dumps(config), "--scope", "user"]


def test_build_mcp_cmd_gemini_no_env():
    config = {"command": "npx", "args": ["-y", "test-mcp"]}
    cmd = _build_mcp_cmd(GEMINI, "srv", config)
    assert cmd == ["gemini", "mcp", "add", "srv", "npx", "-y", "test-mcp", "-s", "user"]


def test_build_mcp_cmd_gemini_with_env():
    config = {"command": "uvx", "args": ["mcp"], "env": {"A": "1", "B": "2"}}
    cmd = _build_mcp_cmd(GEMINI, "srv", config)
    assert cmd == [
        "gemini", "mcp", "add", "srv", "uvx", "mcp", "-s", "user",
        "-e", "A=1", "-e", "B=2",
    ]


def test_build_mcp_cmd_codex_no_env():
    config = {"command": "npx", "args": ["-y", "test-mcp"]}
    cmd = _build_mcp_cmd(CODEX, "srv", config)
    assert cmd == ["codex", "mcp", "add", "srv", "--", "npx", "-y", "test-mcp"]


def test_build_mcp_cmd_codex_with_env():
    config = {"command": "uvx", "args": ["mcp"], "env": {"KEY": "val"}}
    cmd = _build_mcp_cmd(CODEX, "srv", config)
    assert cmd == ["codex", "mcp", "add", "srv", "--env", "KEY=val", "--", "uvx", "mcp"]


def test_build_mcp_cmd_missing_command():
    with pytest.raises(ValueError, match="missing 'command'"):
        _build_mcp_cmd(GEMINI, "srv", {"type": "stdio"})


def test_build_mcp_cmd_no_args_codex():
    """Config with command but no args works for Codex."""
    config = {"command": "uvx"}
    cmd = _build_mcp_cmd(CODEX, "srv", config)
    assert cmd == ["codex", "mcp", "add", "srv", "--", "uvx"]


def test_build_mcp_cmd_no_args_gemini():
    """Config with command but no args works for Gemini."""
    config = {"command": "uvx"}
    cmd = _build_mcp_cmd(GEMINI, "srv", config)
    assert cmd == ["gemini", "mcp", "add", "srv", "uvx", "-s", "user"]


def test_build_mcp_cmd_unknown_agent():
    """Unknown agent key raises ValueError."""
    fake = AgentDef(
        key="unknown", display_name="Unknown", binary="unknown",
        config_dir=".unknown", instructions_file="UNKNOWN.md",
        skills_dir="skills", project_skills_dir=None,
        project_instructions_dir=None, install_hint="",
    )
    with pytest.raises(ValueError, match="Unknown agent key"):
        _build_mcp_cmd(fake, "srv", {"command": "test"})


def test_build_mcp_cmd_null_args_and_env():
    """Config with args: null and env: null doesn't crash."""
    config = {"command": "uvx", "args": None, "env": None}
    cmd = _build_mcp_cmd(GEMINI, "srv", config)
    assert cmd == ["gemini", "mcp", "add", "srv", "uvx", "-s", "user"]


def test_build_mcp_cmd_invalid_args_type():
    """Non-list args raises ValueError."""
    with pytest.raises(ValueError, match="invalid 'args'"):
        _build_mcp_cmd(GEMINI, "srv", {"command": "uvx", "args": "string"})


def test_build_mcp_cmd_invalid_env_type():
    """Non-dict env raises ValueError."""
    with pytest.raises(ValueError, match="invalid 'env'"):
        _build_mcp_cmd(GEMINI, "srv", {"command": "uvx", "env": ["bad"]})


def test_build_mcp_cmd_invalid_env_key():
    """Env key with invalid chars raises ValueError."""
    with pytest.raises(ValueError, match="invalid env key"):
        _build_mcp_cmd(GEMINI, "srv", {"command": "uvx", "env": {"bad key": "v"}})


# ---------------------------------------------------------------------------
# _configure_mcp
# ---------------------------------------------------------------------------


def test_configure_mcp_success():
    with patch("knktx_mcp.cli._install_mcp_config", return_value=True) as mock, \
         patch("knktx_mcp.cli._patch_agent_mcp_config"):
        result = _configure_mcp(CLAUDE, "http://localhost:8000/api/v1", "test-key")
    assert result is True
    mock.assert_called_once()
    config = mock.call_args[0][1]
    assert config == "knktx"


def test_configure_mcp_agent_not_found(capsys):
    with patch("knktx_mcp.cli._install_mcp_config", side_effect=_AgentNotFoundError("missing")), \
         patch("knktx_mcp.cli._patch_agent_mcp_config"):
        result = _configure_mcp(CLAUDE, "http://localhost:8000/api/v1", "test-key")
    assert result is False
    err = capsys.readouterr().err
    assert "CLI not found" in err
    assert CLAUDE.install_hint in err


def test_configure_mcp_gemini():
    """Gemini MCP config installation works end-to-end with env vars."""
    with patch("subprocess.run") as mock_run:
        result = _configure_mcp(GEMINI, "http://localhost:8000/api/v1", "test-key")
    assert result is True
    cmd = mock_run.call_args[0][0]
    assert cmd[0] == "gemini"
    cmd_str = " ".join(cmd)
    assert "KNKTX_API_URL=http://localhost:8000/api/v1" in cmd_str
    assert "KNKTX_API_KEY=test-key" in cmd_str


def test_configure_mcp_codex():
    """Codex MCP config installation works end-to-end with env vars."""
    with patch("subprocess.run") as mock_run:
        result = _configure_mcp(CODEX, "http://localhost:8000/api/v1", "test-key")
    assert result is True
    cmd = mock_run.call_args[0][0]
    assert cmd[0] == "codex"
    assert "--" in cmd
    cmd_str = " ".join(cmd)
    assert "KNKTX_API_URL=http://localhost:8000/api/v1" in cmd_str
    assert "KNKTX_API_KEY=test-key" in cmd_str


# ---------------------------------------------------------------------------
# _install_mcp_configs
# ---------------------------------------------------------------------------


def test_install_mcp_configs_installs_all():
    configs = [
        {"name": "server-a", "config": {"type": "stdio", "command": "a"}},
        {"name": "server-b", "config": {"type": "stdio", "command": "b"}},
    ]
    with patch("knktx_mcp.cli._install_mcp_config", return_value=True):
        success, attempted = _install_mcp_configs(CLAUDE, configs)
    assert success == 2
    assert attempted == 2


def test_install_mcp_configs_skips_no_config(capsys):
    configs = [{"name": "empty"}]
    success, attempted = _install_mcp_configs(CLAUDE, configs)
    assert success == 0
    assert attempted == 0
    assert "no valid config" in capsys.readouterr().err


def test_install_mcp_configs_bails_on_agent_not_found(capsys):
    """When agent CLI is missing, loop bails after first config instead of spamming."""
    configs = [
        {"name": "a", "config": {"type": "stdio", "command": "a"}},
        {"name": "b", "config": {"type": "stdio", "command": "b"}},
    ]
    with patch("knktx_mcp.cli._install_mcp_config", side_effect=_AgentNotFoundError("not found")):
        success, attempted = _install_mcp_configs(CLAUDE, configs)
    assert success == 0
    err = capsys.readouterr().err
    assert err.count("CLI not found") == 1  # only printed once, not N times


# ---------------------------------------------------------------------------
# _execute_plugin
# ---------------------------------------------------------------------------


def test_execute_plugin_success():
    with patch("subprocess.run") as mock_run:
        result = _execute_plugin("test-plugin", "echo hello")
    assert result is True
    mock_run.assert_called_once_with(
        "echo hello",
        shell=True,
        check=True,
        capture_output=True,
        text=True,
        timeout=300,
    )


def test_execute_plugin_failure(capsys):
    with patch("subprocess.run", side_effect=subprocess.CalledProcessError(1, "sh")):
        result = _execute_plugin("bad-plugin", "exit 1")
    assert result is False
    assert "failed" in capsys.readouterr().err


def test_execute_plugin_timeout(capsys):
    with patch("subprocess.run", side_effect=subprocess.TimeoutExpired("cmd", 300)):
        result = _execute_plugin("slow-plugin", "sleep 999")
    assert result is False
    assert "timed out" in capsys.readouterr().err


# ---------------------------------------------------------------------------
# _execute_plugins
# ---------------------------------------------------------------------------


def test_execute_plugins_with_confirm():
    plugins = [
        {"name": "plugin-a", "content": "echo a"},
        {"name": "plugin-b", "content": "echo b"},
    ]
    with patch("knktx_mcp.cli._confirm", return_value=True), \
         patch("knktx_mcp.cli._execute_plugin", return_value=True):
        success, attempted = _execute_plugins(plugins)
    assert success == 2
    assert attempted == 2


def test_execute_plugins_skip_on_decline():
    plugins = [{"name": "skipped", "content": "echo skip"}]
    with patch("knktx_mcp.cli._confirm", return_value=False):
        success, attempted = _execute_plugins(plugins)
    assert success == 0
    assert attempted == 0  # declined = not attempted


def test_execute_plugins_skips_empty_content(capsys):
    plugins = [{"name": "empty", "content": ""}]
    success, attempted = _execute_plugins(plugins)
    assert success == 0
    assert attempted == 0
    assert "no content" in capsys.readouterr().err


# ---------------------------------------------------------------------------
# _execute_plugins (auto=True)
# ---------------------------------------------------------------------------


def test_execute_plugins_auto_runs_all():
    plugins = [
        {"name": "auto-a", "content": "echo a"},
        {"name": "auto-b", "content": "echo b"},
    ]
    with patch("knktx_mcp.cli._execute_plugin", return_value=True):
        success, attempted = _execute_plugins(plugins, auto=True)
    assert success == 2
    assert attempted == 2


def test_execute_plugins_auto_skips_empty(capsys):
    plugins = [{"name": "empty", "content": "  "}]
    success, attempted = _execute_plugins(plugins, auto=True)
    assert success == 0
    assert attempted == 0
    assert "no content" in capsys.readouterr().err


# ---------------------------------------------------------------------------
# _fetch_enabled
# ---------------------------------------------------------------------------


def test_fetch_enabled_filters_disabled():
    """Items with enabled=False are excluded, enabled=True or missing are kept."""
    items = [
        {"name": "on", "enabled": True},
        {"name": "off", "enabled": False},
        {"name": "default"},
    ]
    client = MagicMock()
    with patch("knktx_mcp.cli._api_get", return_value=items):
        result = _fetch_enabled(client, "/skills")
    assert len(result) == 2
    names = [i["name"] for i in result]
    assert "on" in names
    assert "default" in names
    assert "off" not in names


def test_fetch_enabled_passes_agent():
    """Agent param is forwarded to the API call."""
    client = MagicMock()
    with patch("knktx_mcp.cli._api_get", return_value=[]) as mock_get:
        _fetch_enabled(client, "/skills", agent="claude")
    mock_get.assert_called_once_with(client, "/skills", agent="claude")


def test_fetch_enabled_no_agent():
    """Without agent, no extra params are passed."""
    client = MagicMock()
    with patch("knktx_mcp.cli._api_get", return_value=[]) as mock_get:
        _fetch_enabled(client, "/plugins")
    mock_get.assert_called_once_with(client, "/plugins")


# ---------------------------------------------------------------------------
# Additional coverage — partial failures and edge cases
# ---------------------------------------------------------------------------


def test_install_mcp_configs_partial_failure():
    """Mix of successes and failures returns accurate counts."""
    configs = [
        {"name": "ok-1", "config": {"type": "stdio", "command": "a"}},
        {"name": "fail", "config": {"type": "stdio", "command": "b"}},
        {"name": "ok-2", "config": {"type": "stdio", "command": "c"}},
    ]
    returns = [True, False, True]
    with patch("knktx_mcp.cli._install_mcp_config", side_effect=returns):
        success, attempted = _install_mcp_configs(CLAUDE, configs)
    assert success == 2
    assert attempted == 3


def test_install_mcp_configs_skips_invalid_name(capsys):
    """MCP configs with names that could inject CLI flags are rejected."""
    configs = [{"name": "--scope", "config": {"type": "stdio", "command": "x"}}]
    success, attempted = _install_mcp_configs(CLAUDE, configs)
    assert success == 0
    assert attempted == 0
    assert "invalid name" in capsys.readouterr().err


def test_execute_plugins_confirm_yes_failure():
    """When user confirms but plugin fails, count stays 0."""
    plugins = [{"name": "broken", "content": "exit 1"}]
    with patch("knktx_mcp.cli._confirm", return_value=True), \
         patch("knktx_mcp.cli._execute_plugin", return_value=False):
        success, attempted = _execute_plugins(plugins)
    assert success == 0
    assert attempted == 1


def test_execute_plugins_auto_partial_failure():
    """Auto mode with mix of pass/fail returns accurate counts."""
    plugins = [
        {"name": "ok", "content": "echo ok"},
        {"name": "fail", "content": "exit 1"},
    ]
    with patch("knktx_mcp.cli._execute_plugin", side_effect=[True, False]):
        success, attempted = _execute_plugins(plugins, auto=True)
    assert success == 1
    assert attempted == 2


# ---------------------------------------------------------------------------
# Agent registry
# ---------------------------------------------------------------------------


def test_agent_registry_has_three_agents():
    assert len(AGENT_REGISTRY) == 3
    keys = [a.key for a in AGENT_REGISTRY]
    assert keys == ["claude", "gemini", "codex"]


def test_agent_by_key_lookup():
    assert AGENT_BY_KEY["claude"].display_name == "Claude Code"
    assert AGENT_BY_KEY["gemini"].display_name == "Gemini CLI"
    assert AGENT_BY_KEY["codex"].display_name == "Codex CLI"


def test_agent_by_key_missing():
    assert AGENT_BY_KEY.get("unknown") is None


# ---------------------------------------------------------------------------
# detect_agents
# ---------------------------------------------------------------------------


def test_detect_agents_finds_installed():
    def mock_which(binary):
        return "/usr/bin/claude" if binary == "claude" else None

    with patch("knktx_mcp.cli.shutil.which", side_effect=mock_which):
        found = detect_agents()
    assert len(found) == 1
    assert found[0].key == "claude"


def test_detect_agents_finds_multiple():
    with patch("knktx_mcp.cli.shutil.which", return_value="/usr/bin/something"):
        found = detect_agents()
    assert len(found) == 3


def test_detect_agents_finds_none():
    with patch("knktx_mcp.cli.shutil.which", return_value=None):
        found = detect_agents()
    assert len(found) == 0


# ---------------------------------------------------------------------------
# _agent_dir / _resolve_target
# ---------------------------------------------------------------------------


def test_agent_dir_global(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path))
    assert _agent_dir(CLAUDE, project=False) == tmp_path / ".claude"
    assert _agent_dir(GEMINI, project=False) == tmp_path / ".gemini"
    assert _agent_dir(CODEX, project=False) == tmp_path / ".codex"


def test_agent_dir_project(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    assert _agent_dir(CLAUDE, project=True) == tmp_path / ".claude"
    assert _agent_dir(GEMINI, project=True) == tmp_path / ".gemini"
    assert _agent_dir(CODEX, project=True) == tmp_path / ".codex"


def test_resolve_target_global(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path))
    assert _resolve_target(CLAUDE, project=False) == tmp_path / ".claude" / "CLAUDE.md"
    assert _resolve_target(GEMINI, project=False) == tmp_path / ".gemini" / "GEMINI.md"
    assert _resolve_target(CODEX, project=False) == tmp_path / ".codex" / "AGENTS.md"


def test_resolve_target_project(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    assert _resolve_target(CLAUDE, project=True) == tmp_path / ".claude" / "CLAUDE.md"
    assert _resolve_target(GEMINI, project=True) == tmp_path / ".gemini" / "GEMINI.md"


def test_resolve_target_codex_project_is_repo_root(tmp_path, monkeypatch):
    """Codex project instructions go to <repo>/AGENTS.md, not .codex/AGENTS.md."""
    monkeypatch.chdir(tmp_path)
    assert _resolve_target(CODEX, project=True) == tmp_path / "AGENTS.md"


# ---------------------------------------------------------------------------
# _resolve_agent
# ---------------------------------------------------------------------------


def test_resolve_agent_explicit_flag():
    args = _FakeArgs(agent="claude")
    with patch("knktx_mcp.cli.detect_agents", return_value=[CLAUDE]):
        result = _resolve_agent(args)
    assert result == CLAUDE


def test_resolve_agent_explicit_unknown(capsys):
    args = _FakeArgs(agent="unknown")
    with patch("knktx_mcp.cli.detect_agents", return_value=[]):
        with pytest.raises(SystemExit):
            _resolve_agent(args)
    assert "Unknown agent" in capsys.readouterr().err


def test_resolve_agent_explicit_not_detected():
    """--agent flag works even if the binary isn't on PATH."""
    args = _FakeArgs(agent="codex")
    with patch("knktx_mcp.cli.detect_agents", return_value=[CLAUDE]):
        result = _resolve_agent(args)
    assert result == CODEX


def test_resolve_agent_no_agents_detected_still_shows_picker():
    """All registered agents shown even when none detected (all marked not on PATH)."""
    args = _FakeArgs()
    with patch("knktx_mcp.cli.detect_agents", return_value=[]), \
         patch("knktx_mcp.cli._pick", return_value=0) as pick:
        result = _resolve_agent(args)
    labels = pick.call_args[0][1]
    assert all("(not on PATH)" in l for l in labels)
    assert result == CLAUDE  # first in registry


def test_resolve_agent_marks_undetected():
    """Picker labels mark agents not found on PATH."""
    args = _FakeArgs()
    with patch("knktx_mcp.cli.detect_agents", return_value=[GEMINI]), \
         patch("knktx_mcp.cli._pick", return_value=1) as pick:
        result = _resolve_agent(args)
    labels = pick.call_args[0][1]
    assert "(not on PATH)" in labels[0]  # Claude not detected
    assert "(not on PATH)" not in labels[1]  # Gemini detected
    assert "(not on PATH)" in labels[2]  # Codex not detected
    assert result == GEMINI


def test_resolve_agent_yes_single():
    args = _FakeArgs(yes=True)
    with patch("knktx_mcp.cli.detect_agents", return_value=[CLAUDE]):
        result = _resolve_agent(args)
    assert result == CLAUDE


def test_resolve_agent_yes_multiple_requires_flag(capsys):
    args = _FakeArgs(yes=True)
    with patch("knktx_mcp.cli.detect_agents", return_value=[CLAUDE, GEMINI]):
        with pytest.raises(SystemExit):
            _resolve_agent(args)
    assert "--agent is required" in capsys.readouterr().err


def test_resolve_agent_interactive_picker():
    args = _FakeArgs()
    with patch("knktx_mcp.cli.detect_agents", return_value=[CLAUDE, GEMINI, CODEX]), \
         patch("knktx_mcp.cli._pick", return_value=1):
        result = _resolve_agent(args)
    assert result == GEMINI


# ---------------------------------------------------------------------------
# _agent_badge / _agent_badges
# ---------------------------------------------------------------------------


def test_agent_badge_known_agent(monkeypatch):
    """Known agents get their assigned color."""
    monkeypatch.setenv("NO_COLOR", "1")
    assert _agent_badge("claude") == "[claude]"
    assert _agent_badge("gemini") == "[gemini]"
    assert _agent_badge("codex") == "[codex]"


def test_agent_badge_unknown_agent(monkeypatch):
    """Unknown agents fall back to dim color."""
    monkeypatch.setenv("NO_COLOR", "1")
    assert _agent_badge("unknown") == "[unknown]"


def test_agent_badges_multiple(monkeypatch):
    """Multiple agents produce space-separated badges."""
    monkeypatch.setenv("NO_COLOR", "1")
    result = _agent_badges(["claude", "gemini"])
    assert result == "[claude] [gemini]"


def test_agent_badges_single(monkeypatch):
    monkeypatch.setenv("NO_COLOR", "1")
    assert _agent_badges(["codex"]) == "[codex]"


def test_agent_badges_empty():
    assert _agent_badges([]) == ""


def test_agent_colors_maps_all_registry_agents():
    """Every agent in the registry has a color entry."""
    for agent in AGENT_REGISTRY:
        assert agent.key in AGENT_COLORS


# ---------------------------------------------------------------------------
# _merge_by_key
# ---------------------------------------------------------------------------


def test_merge_by_key_deduplicates():
    """Same item from two agents appears once with both agent keys."""
    items_by_agent = {
        "claude": [{"id": "1", "name": "rule-a"}, {"id": "2", "name": "rule-b"}],
        "gemini": [{"id": "1", "name": "rule-a"}],
    }
    merged = _merge_by_key(items_by_agent)
    assert len(merged) == 2
    item_1, agents_1 = merged[0]
    assert item_1["id"] == "1"
    assert agents_1 == ["claude", "gemini"]
    item_2, agents_2 = merged[1]
    assert item_2["id"] == "2"
    assert agents_2 == ["claude"]


def test_merge_by_key_preserves_first_appearance_order():
    """Items are ordered by first appearance across agents."""
    items_by_agent = {
        "claude": [{"id": "3"}, {"id": "1"}],
        "gemini": [{"id": "2"}, {"id": "1"}],
    }
    merged = _merge_by_key(items_by_agent)
    ids = [item["id"] for item, _ in merged]
    assert ids == ["3", "1", "2"]


def test_merge_by_key_custom_key_field():
    """Custom key_field works for non-id fields."""
    items_by_agent = {
        "claude": [{"slug": "watch-pr", "name": "Watch PR"}],
        "gemini": [{"slug": "watch-pr", "name": "Watch PR"}],
    }
    merged = _merge_by_key(items_by_agent, key_field="slug")
    assert len(merged) == 1
    assert merged[0][1] == ["claude", "gemini"]


def test_merge_by_key_skips_empty_key():
    """Items with empty or missing key_field are skipped."""
    items_by_agent = {
        "claude": [{"id": "", "name": "bad"}, {"name": "no-id"}],
    }
    merged = _merge_by_key(items_by_agent)
    assert len(merged) == 0


def test_merge_by_key_empty_input():
    assert _merge_by_key({}) == []


def test_merge_by_key_no_duplicate_agent():
    """Same agent appearing twice for same item doesn't duplicate the agent key."""
    items_by_agent = {
        "claude": [{"id": "1"}, {"id": "1"}],
    }
    merged = _merge_by_key(items_by_agent)
    assert len(merged) == 1
    assert merged[0][1] == ["claude"]


# ---------------------------------------------------------------------------
# _cleanup_stale_commands
# ---------------------------------------------------------------------------


def test_cleanup_stale_commands_removes_matching(tmp_path, monkeypatch):
    """Removes command files for user-invocable skills."""
    monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path))
    cmd_dir = tmp_path / ".claude" / "commands"
    cmd_dir.mkdir(parents=True)
    (cmd_dir / "watch-pr.md").write_text("old command")
    (cmd_dir / "other.md").write_text("unrelated command")

    skills = [
        {"slug": "watch-pr", "user_invocable": True},
        {"slug": "review", "user_invocable": False},
    ]
    removed = _cleanup_stale_commands(CLAUDE, skills, project=False)
    assert removed == 1
    assert not (cmd_dir / "watch-pr.md").exists()
    assert (cmd_dir / "other.md").exists()


def test_cleanup_stale_commands_skips_non_invocable(tmp_path, monkeypatch):
    """Non-user-invocable skills don't trigger command removal."""
    monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path))
    cmd_dir = tmp_path / ".claude" / "commands"
    cmd_dir.mkdir(parents=True)
    (cmd_dir / "internal.md").write_text("command")

    skills = [{"slug": "internal", "user_invocable": False}]
    removed = _cleanup_stale_commands(CLAUDE, skills, project=False)
    assert removed == 0
    assert (cmd_dir / "internal.md").exists()


def test_cleanup_stale_commands_no_cmd_dir(tmp_path, monkeypatch):
    """Returns 0 when commands directory doesn't exist."""
    monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path))
    skills = [{"slug": "watch-pr", "user_invocable": True}]
    removed = _cleanup_stale_commands(CLAUDE, skills, project=False)
    assert removed == 0


def test_cleanup_stale_commands_no_matching_file(tmp_path, monkeypatch):
    """Returns 0 when no command files match skill slugs."""
    monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path))
    cmd_dir = tmp_path / ".claude" / "commands"
    cmd_dir.mkdir(parents=True)
    (cmd_dir / "unrelated.md").write_text("safe")

    skills = [{"slug": "watch-pr", "user_invocable": True}]
    removed = _cleanup_stale_commands(CLAUDE, skills, project=False)
    assert removed == 0
    assert (cmd_dir / "unrelated.md").exists()


def test_cleanup_stale_commands_project_scope(tmp_path, monkeypatch):
    """Project-scoped cleanup uses cwd instead of home."""
    monkeypatch.chdir(tmp_path)
    cmd_dir = tmp_path / ".claude" / "commands"
    cmd_dir.mkdir(parents=True)
    (cmd_dir / "watch-pr.md").write_text("old")

    skills = [{"slug": "watch-pr", "user_invocable": True}]
    removed = _cleanup_stale_commands(CLAUDE, skills, project=True)
    assert removed == 1
    assert not (cmd_dir / "watch-pr.md").exists()


def test_cleanup_stale_commands_skips_no_slug(tmp_path, monkeypatch):
    """Skills without slugs are skipped."""
    monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path))
    cmd_dir = tmp_path / ".claude" / "commands"
    cmd_dir.mkdir(parents=True)

    skills = [{"user_invocable": True}]
    removed = _cleanup_stale_commands(CLAUDE, skills, project=False)
    assert removed == 0


def test_cleanup_stale_commands_rejects_traversal_slug(tmp_path, monkeypatch, capsys):
    """Slugs with path traversal characters are rejected, no files deleted."""
    monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path))
    cmd_dir = tmp_path / ".claude" / "commands"
    cmd_dir.mkdir(parents=True)
    # Create a file that a traversal slug would target
    target = tmp_path / ".claude" / "CLAUDE.md"
    target.write_text("important")

    skills = [{"slug": "../../.claude/CLAUDE", "user_invocable": True}]
    removed = _cleanup_stale_commands(CLAUDE, skills, project=False)
    assert removed == 0
    assert target.exists()  # file must not be deleted
    assert "invalid slug" in capsys.readouterr().err


def test_cleanup_stale_commands_oserror_on_unlink(tmp_path, monkeypatch, capsys):
    """OSError on unlink is logged, not raised."""
    monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path))
    cmd_dir = tmp_path / ".claude" / "commands"
    cmd_dir.mkdir(parents=True)
    (cmd_dir / "watch-pr.md").write_text("old")

    skills = [{"slug": "watch-pr", "user_invocable": True}]
    with patch.object(Path, "unlink", side_effect=OSError("permission denied")):
        removed = _cleanup_stale_commands(CLAUDE, skills, project=False)
    assert removed == 0
    assert "Could not remove" in capsys.readouterr().err


# ---------------------------------------------------------------------------
# _resolve_agents
# ---------------------------------------------------------------------------


def test_resolve_agents_all_flag():
    """--all returns all detected agents."""
    args = _FakeArgs(all_agents=True)
    with patch("knktx_mcp.cli.detect_agents", return_value=[CLAUDE, GEMINI]):
        result = _resolve_agents(args)
    assert result == [CLAUDE, GEMINI]


def test_resolve_agents_all_flag_none_detected(capsys):
    """--all with no agents on PATH exits with error."""
    args = _FakeArgs(all_agents=True)
    with patch("knktx_mcp.cli.detect_agents", return_value=[]):
        with pytest.raises(SystemExit):
            _resolve_agents(args)
    assert "No supported agents found" in capsys.readouterr().err


def test_resolve_agents_single_fallback():
    """Without --all, --agent flag falls back to single-agent resolver."""
    args = _FakeArgs(agent="claude")
    with patch("knktx_mcp.cli.detect_agents", return_value=[CLAUDE]):
        result = _resolve_agents(args)
    assert result == [CLAUDE]


def test_resolve_agents_picker_shows_all_option():
    """Interactive picker shows 'All detected agents' when multiple are detected."""
    args = _FakeArgs()
    with patch("knktx_mcp.cli.detect_agents", return_value=[CLAUDE, GEMINI]), \
         patch("knktx_mcp.cli._pick", return_value=0) as mock_pick:
        result = _resolve_agents(args)
    # Picking index 0 = "All detected agents"
    assert result == [CLAUDE, GEMINI]
    labels = mock_pick.call_args[0][1]
    assert "All detected agents" in labels[0]


def test_resolve_agents_picker_select_single_with_all_shown():
    """Picking a specific agent when 'All' is shown returns just that agent."""
    args = _FakeArgs()
    with patch("knktx_mcp.cli.detect_agents", return_value=[CLAUDE, GEMINI]), \
         patch("knktx_mcp.cli._pick", return_value=1):
        result = _resolve_agents(args)
    # Index 1 = first agent in AGENT_REGISTRY (claude)
    assert result == [CLAUDE]


def test_resolve_agents_picker_no_all_with_single_detected():
    """Picker does not show 'All' when only one agent is detected."""
    args = _FakeArgs()
    with patch("knktx_mcp.cli.detect_agents", return_value=[CLAUDE]), \
         patch("knktx_mcp.cli._pick", return_value=0) as mock_pick:
        result = _resolve_agents(args)
    assert result == [CLAUDE]
    labels = mock_pick.call_args[0][1]
    assert not any("All detected" in l for l in labels)


# ---------------------------------------------------------------------------
# _resolve_api_key
# ---------------------------------------------------------------------------


def test_resolve_api_key_from_flag():
    args = _FakeArgs(key="test-key")
    key, source = _resolve_api_key(args, [CLAUDE, GEMINI])
    assert key == "test-key"
    assert source == "flag"


def test_resolve_api_key_from_env(monkeypatch):
    args = _FakeArgs()
    monkeypatch.setenv("KNKTX_API_KEY", "env-key")
    key, source = _resolve_api_key(args, [CLAUDE])
    assert key == "env-key"
    assert source == "env"


def test_resolve_api_key_from_second_agent_config(monkeypatch):
    """Key is found in second agent's config after first has none."""
    monkeypatch.delenv("KNKTX_API_KEY", raising=False)
    args = _FakeArgs()

    def fake_read_config(agent):
        if agent.key == "gemini":
            return {"env": {"KNKTX_API_KEY": "gemini-key"}}
        return None

    with patch("knktx_mcp.cli._read_existing_config", side_effect=fake_read_config):
        key, source = _resolve_api_key(args, [CLAUDE, GEMINI])
    assert key == "gemini-key"
    assert source == "config"


def test_resolve_api_key_prompts_when_no_config(monkeypatch):
    """Falls back to prompt when no agent has a stored key."""
    monkeypatch.delenv("KNKTX_API_KEY", raising=False)
    args = _FakeArgs()

    with patch("knktx_mcp.cli._read_existing_config", return_value=None), \
         patch("knktx_mcp.cli._prompt", return_value="prompted-key"):
        key, source = _resolve_api_key(args, [CLAUDE])
    assert key == "prompted-key"
    assert source == "prompt"


def test_resolve_api_key_exits_on_empty_prompt(monkeypatch):
    """Exits with code 1 when user enters empty key at prompt."""
    monkeypatch.delenv("KNKTX_API_KEY", raising=False)
    args = _FakeArgs()

    with patch("knktx_mcp.cli._read_existing_config", return_value=None), \
         patch("knktx_mcp.cli._prompt", return_value=""), \
         pytest.raises(SystemExit) as exc_info:
        _resolve_api_key(args, [CLAUDE])
    assert exc_info.value.code == 1
