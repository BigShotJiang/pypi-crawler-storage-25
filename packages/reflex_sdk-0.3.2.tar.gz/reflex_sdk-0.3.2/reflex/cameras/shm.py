"""Shared-memory camera source for the Reflex SDK.

Uses raw posix shm via `os.open("/dev/shm/<name>", O_RDONLY)` + `mmap` to
BYPASS Python's multiprocessing.shared_memory.resource_tracker, which would
otherwise unlink segments owned by another process when this reader exits.

Use in connect yaml:

    cameras:
      top:
        kind: shm
        name: "top"

Register in SDK by adding to reflex.cameras.__init__._BUILTIN:
    "shm": "reflex.cameras.shm:ShmCameraSource"
"""
from __future__ import annotations

import mmap
import os
import struct
import time
from typing import Optional

import numpy as np

from reflex.cameras.base import CameraSource


HEADER_SIZE = 64
MAGIC = 0xCAFEFACE


class ShmCameraSource(CameraSource):
    """Lock-free reader for a per-camera SHM segment published by broadcaster."""

    kind = "shm"

    def __init__(
        self,
        name: str,
        max_attach_retries: int = 20,
        attach_retry_delay_s: float = 0.5,
    ):
        self._name = name
        self._shm_path = f"/dev/shm/reflex_cam_{name}"
        self._max_retries = int(max_attach_retries)
        self._retry_delay = float(attach_retry_delay_s)
        self._fd: Optional[int] = None
        self._mmap: Optional[mmap.mmap] = None
        self._frame_view: Optional[np.ndarray] = None
        self._w = self._h = self._c = 0

    def start(self) -> None:
        for attempt in range(self._max_retries):
            if os.path.exists(self._shm_path):
                break
            if attempt == 0:
                print(
                    f"[shm-camera:{self._name}] waiting for broadcaster to "
                    f"publish {self._shm_path}..."
                )
            time.sleep(self._retry_delay)
        else:
            raise RuntimeError(
                f"[shm-camera:{self._name}] no SHM segment at {self._shm_path}. "
                f"Is camera_broadcaster running on this host?"
            )

        self._fd = os.open(self._shm_path, os.O_RDONLY)
        size = os.fstat(self._fd).st_size
        self._mmap = mmap.mmap(self._fd, size, prot=mmap.PROT_READ)
        magic, w, h, c = struct.unpack_from("<IIII", self._mmap, 0)
        if magic != MAGIC:
            raise RuntimeError(
                f"[shm-camera:{self._name}] bad magic 0x{magic:x} (expected 0x{MAGIC:x})"
            )
        self._w, self._h, self._c = w, h, c
        # Zero-copy ndarray view onto the mmap (read-only data, no allocation)
        self._frame_view = np.ndarray(
            (h, w, c), dtype=np.uint8, buffer=self._mmap, offset=HEADER_SIZE
        )
        print(
            f"[shm-camera:{self._name}] attached to {self._shm_path} "
            f"({w}x{h}x{c} uint8, raw mmap — no resource_tracker)"
        )

    def read(self) -> np.ndarray:
        """Return the LATEST frame as a copy (so caller can hold it safely)."""
        if self._mmap is None or self._frame_view is None:
            raise RuntimeError(f"[shm-camera:{self._name}] start() must be called first")
        # Seqlock read: try up to 10x to catch a non-torn frame.
        for _ in range(10):
            seq1 = struct.unpack_from("<Q", self._mmap, 16)[0]
            if seq1 % 2 == 0:
                continue  # writer in progress
            frame = self._frame_view.copy()
            seq2 = struct.unpack_from("<Q", self._mmap, 16)[0]
            if seq1 == seq2:
                return frame
        # Best-effort fallback (writer is hammering)
        return self._frame_view.copy()

    def stop(self) -> None:
        if self._mmap is not None:
            try:
                self._mmap.close()
            except Exception:
                pass
            self._mmap = None
        if self._fd is not None:
            try:
                os.close(self._fd)
            except Exception:
                pass
            self._fd = None
        self._frame_view = None


__all__ = ["ShmCameraSource"]
