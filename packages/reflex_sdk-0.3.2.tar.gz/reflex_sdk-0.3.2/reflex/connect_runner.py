"""YAML-driven runner for ``reflex connect``.

Reads a single YAML config, builds a :class:`RobotConnector`, a
:class:`Transport`, and zero or more :class:`CameraSource` objects from the
registries, and runs a session loop that:

    1. reads state from the connector,
    2. grabs the latest frame from each camera and merges them into the
       observation,
    3. asks the transport to infer an action chunk,
    4. applies that chunk back to the connector (when mode is apply_actions),
    5. on error, calls ``connector.safe_stop`` and either stops or continues.

The runner knows nothing about specific robots, cameras, or inference
servers — those are plug-in choices in YAML.
"""

from __future__ import annotations

import concurrent.futures
import logging
import signal
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Mapping

import yaml

log = logging.getLogger("reflex.connect_runner")


class _Interrupted(Exception):
    """Raised internally when SIGINT/SIGTERM lands inside the session loop."""

from reflex.cameras import build_camera
from reflex.cameras.base import CameraSource
from reflex.connectors import build_connector
from reflex.connectors.base import RobotConnector
from reflex.transports import build_transport
from reflex.transports.base import InferenceRequest, Transport


@dataclass
class RunnerResult:
    steps: int = 0
    applied_steps: int = 0
    safe_stops: int = 0
    errors: list[str] = field(default_factory=list)
    last_action_chunk: list[list[float]] | None = None


def load_config(path: str | Path) -> dict[str, Any]:
    """Load and validate a connect YAML config."""
    raw = yaml.safe_load(Path(path).read_text())
    if not isinstance(raw, dict):
        raise ValueError(f"Config at {path} must be a mapping at the top level")
    _validate_config(raw, source=str(path))
    return raw


def _validate_config(cfg: dict[str, Any], *, source: str) -> None:
    for key in ("target", "hardware"):
        if key not in cfg or not isinstance(cfg[key], dict):
            raise ValueError(f"{source}: missing or non-mapping '{key}' section")
    if not cfg["target"].get("kind"):
        raise ValueError(f"{source}: target.kind is required")
    if not cfg["hardware"].get("kind"):
        raise ValueError(f"{source}: hardware.kind is required")
    cameras = cfg.get("cameras")
    if cameras is not None and not isinstance(cameras, dict):
        raise ValueError(f"{source}: cameras section must be a mapping")
    mode = cfg.get("mode", "dry_run")
    if mode not in ("dry_run", "apply_actions"):
        raise ValueError(f"{source}: mode must be 'dry_run' or 'apply_actions', got {mode!r}")


def build_from_config(
    cfg: dict[str, Any],
) -> tuple[RobotConnector, Transport, dict[str, CameraSource]]:
    """Instantiate connector, transport, and cameras from a parsed config."""
    target = dict(cfg["target"])
    target_kind = target.pop("kind")
    # PROD.2: if REFLEX_API_KEY is set (or saved in ~/.config/reflex), authorize a
    # session with Convex first. The returned session token gets passed to the
    # WebRTC transport so it can authenticate with HMAC-validating workers.
    try:
        from .auth_runner import maybe_authorize
        grant = maybe_authorize(
            base_model=target.get("base_model"),
            robot_type=(cfg.get("hardware") or {}).get("config", {}).get("robot_type"),
        )
    except Exception as exc:
        import sys
        print(f"[reflex] WARNING: authorize failed ({exc}); continuing with unauthenticated connect", file=sys.stderr, flush=True)
        grant = None

    if grant is not None:
        # Override target url with the worker_url Convex assigned (load-balanced
        # across the primeNode pool) and attach the session token.
        target["url"] = grant.worker_url
        target["auth_token"] = grant.session_token
    transport = build_transport(target_kind, target)

    hardware = cfg["hardware"]
    hw_kind = hardware["kind"]
    hw_config = hardware.get("config", {})
    connector = build_connector(hw_kind, hw_config)

    cameras: dict[str, CameraSource] = {}
    for name, spec in (cfg.get("cameras") or {}).items():
        if not isinstance(spec, Mapping):
            raise ValueError(
                f"cameras.{name} must be a mapping with 'kind' and driver kwargs"
            )
        spec_dict = dict(spec)
        cam_kind = spec_dict.pop("kind", None)
        if not cam_kind:
            raise ValueError(f"cameras.{name}.kind is required")
        cameras[name] = build_camera(cam_kind, spec_dict)

    return connector, transport, cameras


def run_from_config(
    path: str | Path,
    *,
    on_heartbeat: Callable[[dict[str, Any]], None] | None = None,
) -> RunnerResult:
    """Top-level entry point used by ``reflex connect --config <path>``."""
    cfg = load_config(path)
    connector, transport, cameras = build_from_config(cfg)
    return run_session(
        connector=connector,
        transport=transport,
        cameras=cameras,
        mode=cfg.get("mode", "dry_run"),
        max_steps=int(cfg.get("max_steps", 0) or 0),
        control_period_s=float(cfg.get("control_period_s", 0.0) or 0.0),
        stop_on_error=bool(cfg.get("stop_on_error", True)),
        heartbeat_interval_s=float(cfg.get("heartbeat_interval_s", 10.0) or 10.0),
        pipeline_inference=bool(cfg.get("pipeline_inference", True)),
        on_heartbeat=on_heartbeat,
    )


def run_session(
    *,
    connector: RobotConnector,
    transport: Transport,
    cameras: dict[str, CameraSource] | None = None,
    mode: str = "dry_run",
    max_steps: int = 0,
    control_period_s: float = 0.0,
    stop_on_error: bool = True,
    heartbeat_interval_s: float = 10.0,
    pipeline_inference: bool = True,
    on_heartbeat: Callable[[dict[str, Any]], None] | None = None,
) -> RunnerResult:
    """Drive a single observe/infer/apply loop until ``max_steps`` or interruption.

    When ``pipeline_inference`` is True (default), the next inference runs in a
    background thread while the current action chunk is being applied. This
    keeps the GPU busy during hardware motion and roughly doubles the effective
    control rate when ``apply`` time ≈ ``infer`` time. Set False to force a
    strictly serial obs → infer → apply loop (useful for debugging).
    """
    if mode not in ("dry_run", "apply_actions"):
        raise ValueError(f"mode must be 'dry_run' or 'apply_actions', got {mode!r}")

    cameras = cameras or {}
    _ensure_logging()
    result = RunnerResult()
    transport_started = False
    connector_started = False
    started_cameras: list[str] = []
    last_heartbeat = 0.0
    interrupted = False
    executor: concurrent.futures.ThreadPoolExecutor | None = None

    def _on_signal(signum, _frame):  # noqa: ANN001 - signal callback signature
        nonlocal interrupted
        interrupted = True
        log.warning("received signal %s; ending session and homing arms", signum)

    prev_sigint = signal.signal(signal.SIGINT, _on_signal)
    prev_sigterm = signal.signal(signal.SIGTERM, _on_signal)

    log.info(
        "starting session: mode=%s max_steps=%s control_period_s=%s cameras=%s pipeline=%s",
        mode,
        max_steps if max_steps else "unbounded",
        control_period_s,
        list(cameras),
        pipeline_inference,
    )

    try:
        transport.start()
        transport_started = True
        connector.start()
        connector_started = True
        for name, cam in cameras.items():
            cam.start()
            started_cameras.append(name)
        log.info(
            "hardware ready: connector=%s transport=%s cameras=%s",
            type(connector).__name__,
            type(transport).__name__,
            list(cameras),
        )

        def _read_observation(control_step: int) -> InferenceRequest:
            obs = connector.get_observation()
            for cam_name, cam in cameras.items():
                frame = cam.read()
                if frame is not None:
                    obs.cameras[cam_name] = frame
            return InferenceRequest(observation=obs, control_step=control_step)

        def _log_step(step: int, request: InferenceRequest, chunk, infer_wait_ms: float) -> None:
            chunk_shape = (
                (len(chunk.actions), len(chunk.actions[0]) if chunk.actions else 0)
                if chunk.actions
                else (0, 0)
            )
            server_dt_ms = (
                chunk.metadata.get("raw", {}).get("dt_ms")
                if isinstance(chunk.metadata, dict)
                else None
            )
            # ANSI-colorized latency at-a-glance
            _RESET = "\033[0m"; _BOLD = "\033[1m"
            _GREEN = "\033[92m"; _YELLOW = "\033[93m"; _RED = "\033[91m"
            _MAGENTA = "\033[95m"; _CYAN = "\033[96m"; _DIM = "\033[2m"
            if infer_wait_ms < 200:
                _wc = _GREEN
            elif infer_wait_ms < 400:
                _wc = _YELLOW
            else:
                _wc = _RED
            _mode_c = _MAGENTA if mode == "apply_actions" else _CYAN
            _server_str = (
                f"{_BOLD}{server_dt_ms:.1f}ms{_RESET}"
                if isinstance(server_dt_ms, (int, float))
                else f"{_DIM}n/a{_RESET}"
            )
            log.info(
                f"step={_BOLD}%d{_RESET} state_dim=%d cameras=%s chunk=%s "
                f"infer_wait={_wc}{_BOLD}%.1fms{_RESET} server_dt=%s mode={_mode_c}{_BOLD}%s{_RESET}",
                step,
                len(request.observation.state),
                list(request.observation.cameras),
                chunk_shape,
                infer_wait_ms,
                _server_str,
                mode,
            )
            # Diagnostic: state vs first/last action of the chunk.
            # If state ≈ action[0] ≈ action[-1] for every chunk, the model is
            # not progressing — likely OOD or instruction mismatch.
            if chunk.actions:
                first = chunk.actions[0]
                last = chunk.actions[-1]
                state = request.observation.state

                def _fmt(v):
                    return "[" + " ".join(f"{x:+.3f}" for x in v) + "]"

                log.info(
                    "  state =%s",
                    _fmt(state),
                )
                log.info(
                    "  act[0]=%s  delta_from_state=%s",
                    _fmt(first),
                    _fmt([a - s for a, s in zip(first, state)]),
                )
                log.info(
                    "  act[%d]=%s  travel_within_chunk=%s",
                    len(chunk.actions) - 1,
                    _fmt(last),
                    _fmt([la - fa for la, fa in zip(last, first)]),
                )

        executor = (
            concurrent.futures.ThreadPoolExecutor(max_workers=1, thread_name_prefix="reflex-infer")
            if pipeline_inference
            else None
        )

        def _record_failure(exc: BaseException, step_id: int, where: str) -> None:
            message = f"{type(exc).__name__}: {exc}" or "unknown error"
            log.warning("step=%d %s failed: %s", step_id, where, message)
            result.errors.append(message)
            result.safe_stops += 1
            try:
                connector.safe_stop(reason=message)
            except Exception as stop_exc:  # noqa: BLE001 - never re-raise from stop
                result.errors.append(f"safe_stop_failed: {stop_exc}")

        step = 0
        current_chunk = None

        while max_steps == 0 or step < max_steps:
            if interrupted:
                log.info("interrupt observed; stopping loop after %d steps", step)
                break

            iter_started = time.monotonic()
            failures_at_iter_start = result.safe_stops

            # 1. Make sure we have a chunk to apply. Either inherited from a prior
            #    prefetch, or sync infer now (bootstrap / serial mode / recovery).
            if current_chunk is None:
                try:
                    req = _read_observation(step)
                    t0 = time.monotonic()
                    current_chunk = transport.infer(req)
                    _log_step(step, req, current_chunk, (time.monotonic() - t0) * 1000.0)
                except Exception as exc:  # noqa: BLE001 - fail closed
                    _record_failure(exc, step, "sync infer")
                    if stop_on_error:
                        break
                    result.steps += 1
                    step += 1
                    continue
            result.last_action_chunk = current_chunk.actions

            # 2. (Pipelined): prefetch next chunk in background.
            next_future: concurrent.futures.Future | None = None
            next_request: InferenceRequest | None = None
            if executor is not None and (max_steps == 0 or step + 1 < max_steps):
                try:
                    next_request = _read_observation(step + 1)
                    next_future = executor.submit(transport.infer, next_request)
                except Exception as exc:  # noqa: BLE001
                    _record_failure(exc, step + 1, "prefetch obs")
                    # Don't break here: still apply current chunk first so we don't
                    # strand it mid-flight, then break after.

            # 3. Apply the current chunk.
            apply_failed = False
            try:
                if mode == "apply_actions":
                    connector.apply_action(current_chunk)
                    result.applied_steps += 1
            except Exception as exc:  # noqa: BLE001
                _record_failure(exc, step, "apply")
                apply_failed = True

            result.steps += 1
            step += 1

            if apply_failed:
                if next_future is not None:
                    next_future.cancel()
                current_chunk = None
                if stop_on_error:
                    break
                continue

            # 4. Collect the prefetched chunk (waits if infer is still running).
            if next_future is not None:
                infer_t0 = time.monotonic()
                try:
                    current_chunk = next_future.result()
                    _log_step(step, next_request, current_chunk, (time.monotonic() - infer_t0) * 1000.0)
                except Exception as exc:  # noqa: BLE001
                    _record_failure(exc, step, "infer")
                    current_chunk = None
                    if stop_on_error:
                        break
            else:
                # No prefetch was kicked off (serial mode or end-of-window).
                # Force a sync infer next iter by clearing current_chunk.
                current_chunk = None

            # 5. If any failure happened earlier this iter (e.g. prefetch obs),
            #    honour stop_on_error now that the current apply has finished.
            if stop_on_error and result.safe_stops > failures_at_iter_start:
                break

            now = time.monotonic()
            if on_heartbeat is not None and now - last_heartbeat >= heartbeat_interval_s:
                on_heartbeat(
                    {
                        "step": step,
                        "applied_steps": result.applied_steps,
                        "safe_stops": result.safe_stops,
                    }
                )
                last_heartbeat = now

            if control_period_s > 0:
                elapsed = time.monotonic() - iter_started
                sleep_s = control_period_s - elapsed
                if sleep_s > 0:
                    time.sleep(sleep_s)

    finally:
        if executor is not None:
            executor.shutdown(wait=False, cancel_futures=True)
        for name in reversed(started_cameras):
            try:
                cameras[name].stop()
            except Exception:  # noqa: BLE001 - best-effort shutdown
                pass
        if connector_started:
            try:
                log.info("shutting down connector (homing arms)")
                connector.stop()
            except Exception:  # noqa: BLE001 - best-effort shutdown
                pass
        if transport_started:
            try:
                transport.stop()
            except Exception:  # noqa: BLE001 - best-effort shutdown
                pass
        signal.signal(signal.SIGINT, prev_sigint)
        signal.signal(signal.SIGTERM, prev_sigterm)

    return result


def _ensure_logging() -> None:
    """Idempotently install a stdout handler if the caller didn't configure logging."""
    root = logging.getLogger()
    if not root.handlers:
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        )


__all__ = [
    "RunnerResult",
    "build_from_config",
    "load_config",
    "run_from_config",
    "run_session",
]
