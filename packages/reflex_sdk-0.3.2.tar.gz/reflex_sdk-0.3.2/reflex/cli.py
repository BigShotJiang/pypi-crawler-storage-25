"""Command line interface for the Reflex hosted product API."""

from __future__ import annotations

import json
import os
import socket
import time
import webbrowser
from datetime import datetime, timezone
from pathlib import Path
from urllib import parse

import typer

from reflex.deployments import load_deployment_spec
from reflex.product import (
    AuthClient,
    JsonValue,
    ProductClient,
    ProductError,
    clear_credentials,
    config_path,
    expect_object,
    load_json_arg,
    resolve_api_key,
    resolve_convex_url,
    resolve_site_url,
    save_credentials,
)
from reflex.robot_runtime import RobotExecutionConfig, run_robot_execution_loop
from reflex.robots import _load_schema_payload

HELP_CONTEXT = {"help_option_names": ["-h", "--help"]}
DATASET_COMMANDS = typer.Typer(
    help="Register, validate, and list hosted datasets.",
    no_args_is_help=True,
    context_settings=HELP_CONTEXT,
)
TRAINING_COMMANDS = typer.Typer(
    help="Start, inspect, and stop hosted training runs.",
    no_args_is_help=True,
    context_settings=HELP_CONTEXT,
)
ARTIFACT_COMMANDS = typer.Typer(
    help="List and inspect trained model artifacts.",
    no_args_is_help=True,
    context_settings=HELP_CONTEXT,
)
INFERENCE_COMMANDS = typer.Typer(
    help="Authorize and close hosted inference sessions.",
    no_args_is_help=True,
    context_settings=HELP_CONTEXT,
)
SESSIONS_COMMANDS = typer.Typer(
    help="Start, inspect, and close hosted robot sessions.",
    no_args_is_help=True,
    context_settings=HELP_CONTEXT,
)
DEPLOYMENTS_COMMANDS = typer.Typer(
    help="Create and inspect model deployments.",
    no_args_is_help=True,
    context_settings=HELP_CONTEXT,
)
ROBOTS_COMMANDS = typer.Typer(
    help="Register robot schemas and robots.",
    no_args_is_help=True,
    context_settings=HELP_CONTEXT,
)
RECEIPTS_COMMANDS = typer.Typer(
    help="List deployment receipts.",
    no_args_is_help=True,
    context_settings=HELP_CONTEXT,
)
DEFAULT_DASHBOARD_URL = "https://app.tryreflex.ai"
ACTIVE_TRAINING_STATUSES = {"queued", "provisioning", "running", "sync_requested", "stopping"}
RECENT_FAILED_TRAINING_WINDOW_MS = 15 * 60 * 1000
_GLOBAL_JSON_OUTPUT = False
DEFAULT_ROBOT_TYPE = "so101"
DEFAULT_SO101_ACTION_ADAPTER = "so101_joint"
REAL_ROBOT_NEUTRAL_DWELL_SECONDS = 1.0
SUPPORTED_ACTION_ADAPTERS = {"aloha_joint", "pi_native", "so101_joint"}


def _normalize_action_adapter(value: str, *, robot_type: str = DEFAULT_ROBOT_TYPE) -> str:
    normalized = value.strip().lower().replace("-", "_")
    if not normalized:
        return DEFAULT_SO101_ACTION_ADAPTER if robot_type == "so101" else "aloha_joint"
    aliases = {
        "aloha": "aloha_joint",
        "aloha14": "aloha_joint",
        "pi": "pi_native",
        "pi05": "pi_native",
        "native": "pi_native",
        "so101": "so101_joint",
        "so_101": "so101_joint",
    }
    normalized = aliases.get(normalized, normalized)
    if normalized not in SUPPORTED_ACTION_ADAPTERS:
        expected = ", ".join(sorted(SUPPORTED_ACTION_ADAPTERS))
        raise ProductError(f"--action-adapter must be one of {expected}.")
    return normalized


def _emit_json(payload: dict[str, JsonValue]) -> None:
    typer.echo(json.dumps(payload, indent=2, sort_keys=True))


def _json_enabled(json_output: bool) -> bool:
    return json_output or _GLOBAL_JSON_OUTPUT


def _label(key: str) -> str:
    words: list[str] = []
    current = ""
    for char in key.replace("_", " ").replace("-", " "):
        if char == " ":
            if current:
                words.append(current)
                current = ""
        elif char.isupper() and current:
            words.append(current)
            current = char.lower()
        else:
            current += char
    if current:
        words.append(current)
    return " ".join(words).capitalize() or key


def _sensitive_key(key: str) -> bool:
    lower = key.lower()
    return any(marker in lower for marker in ("apikey", "api_key", "secret", "token", "password"))


def _display_scalar(key: str, value: JsonValue) -> str:
    if _sensitive_key(key):
        return "[hidden]"
    if _timestamp_key(key) and _datetime_from_millis(value) is not None:
        return _datetime_text(value)
    if value is None:
        return "not available"
    if isinstance(value, bool):
        return "yes" if value else "no"
    return str(value)


def _timestamp_key(key: str) -> bool:
    lower = key.lower()
    return lower.endswith("at") or lower.endswith("_at") or lower.endswith("-at")


def _render_object_lines(prefix: str, value: dict[str, JsonValue]) -> list[str]:
    lines: list[str] = []
    for key, item in value.items():
        if key == "ok":
            continue
        if isinstance(item, dict):
            lines.append(f"{prefix}{_label(key)}:")
            lines.extend(_render_object_lines(f"{prefix}  ", item))
        elif isinstance(item, list):
            if key == "next":
                lines.append(f"{prefix}Next:")
                for command in item:
                    lines.append(f"{prefix}  {command}")
            else:
                lines.append(f"{prefix}{_label(key)}: {len(item)} item(s)")
                for entry in item[:5]:
                    if isinstance(entry, dict):
                        summary = ", ".join(
                            f"{_label(k)}={_display_scalar(k, v)}"
                            for k, v in entry.items()
                            if not isinstance(v, (dict, list))
                        )
                        lines.append(f"{prefix}  - {summary or 'item'}")
                    else:
                        lines.append(f"{prefix}  - {_display_scalar(key, entry)}")
                if len(item) > 5:
                    lines.append(f"{prefix}  - ... {len(item) - 5} more")
        else:
            lines.append(f"{prefix}{_label(key)}: {_display_scalar(key, item)}")
    return lines


def _emit(
    payload: dict[str, JsonValue],
    *,
    json_output: bool,
    title: str = "Reflex command complete",
    lines: list[str] | None = None,
) -> None:
    if _json_enabled(json_output):
        _emit_json(payload)
        return
    if lines is None:
        lines = [title, "", *_render_object_lines("", payload)]
    typer.echo("\n".join(lines).rstrip())


def _action_shape_text(frame: dict[str, JsonValue] | None) -> str:
    if not frame:
        return "unknown"
    shape = frame.get("action_shape")
    if isinstance(shape, list) and len(shape) >= 2:
        return "x".join(str(item) for item in shape[:2])
    for key in ("actions_so101", "actions_aloha", "actions", "actions_pi"):
        value = frame.get(key)
        if not isinstance(value, list) or not value:
            continue
        first = value[0]
        if isinstance(first, list):
            return f"{len(value)}x{len(first)}"
        return f"{len(value)}"
    return "unknown"


def _numeric_ms(value: JsonValue) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    return None


def _frame_timing_ms(frame: dict[str, JsonValue] | None, *keys: str) -> float | None:
    if not frame:
        return None
    timing = frame.get("timing")
    if isinstance(timing, dict):
        for key in keys:
            value = _numeric_ms(timing.get(key))
            if value is not None:
                return value
    for key in keys:
        value = _numeric_ms(frame.get(key))
        if value is not None:
            return value
    return None


def _log_inference_tick(
    *,
    seq: int,
    steps: int,
    recv_ms: float,
    apply_ms: float | None,
    frame: dict[str, JsonValue] | None,
) -> None:
    pieces = [
        f"inference tick {seq + 1}/{steps}",
        f"recv_ms={recv_ms:.1f}",
    ]
    server_total_ms = _frame_timing_ms(frame, "server_total_ms", "total_ms")
    if server_total_ms is not None:
        pieces.append(f"network_ms={max(0.0, recv_ms - server_total_ms):.1f}")
        pieces.append(f"server_ms={server_total_ms:.1f}")
    if apply_ms is not None:
        pieces.append(f"apply_ms={apply_ms:.1f}")
    pieces.extend([
        f"action_shape={_action_shape_text(frame)}",
    ])
    typer.echo(" | ".join(pieces))


def _hold_final_robot_pose_before_neutral_reset(*, log_ticks: bool) -> None:
    if log_ticks:
        typer.echo(
            "holding final robot pose before neutral reset | "
            f"seconds={REAL_ROBOT_NEUTRAL_DWELL_SECONDS:g}"
        )
    time.sleep(REAL_ROBOT_NEUTRAL_DWELL_SECONDS)


def _inference_run_lines(payload: dict[str, JsonValue]) -> list[str]:
    session = payload.get("inferenceSession")
    stream = payload.get("stream")
    closed = payload.get("closedSession")
    session_obj = session if isinstance(session, dict) else {}
    stream_obj = stream if isinstance(stream, dict) else {}
    closed_obj = closed if isinstance(closed, dict) else {}
    last_action = stream_obj.get("lastActionChunk")
    robot = stream_obj.get("robot")

    lines = [
        "Inference run complete",
        "",
        f"Session: {_display_scalar('sessionId', session_obj.get('sessionId'))}",
        f"Closed: {_display_scalar('status', closed_obj.get('status'))}",
        f"Transport: {_display_scalar('transport', stream_obj.get('transport'))}",
        f"URL: {_display_scalar('url', stream_obj.get('url'))}",
        f"Observations sent: {_display_scalar('observationsSent', stream_obj.get('observationsSent'))}",
        f"Last action shape: {_action_shape_text(last_action if isinstance(last_action, dict) else None)}",
    ]
    if isinstance(last_action, dict):
        server_total_ms = _frame_timing_ms(last_action, "server_total_ms", "total_ms")
        if server_total_ms is not None:
            lines.append(f"Last server time: {server_total_ms:.1f} ms")
    if stream_obj.get("mock") is True:
        joints = stream_obj.get("finalMockJoints")
        if isinstance(joints, list):
            preview = ", ".join(str(round(float(value), 4)) for value in joints[:6] if isinstance(value, (int, float)))
            lines.append(f"Final mock joints: [{preview}]")
    elif isinstance(robot, dict):
        lines.extend([
            f"Robot: {_display_scalar('type', robot.get('type'))}",
            f"Robot port: {_display_scalar('port', robot.get('port'))}",
        ])
        neutral = robot.get("neutralReset")
        if isinstance(neutral, dict):
            lines.append(f"Neutral reset: {_display_scalar('settled', neutral.get('settled'))}")
            steps = neutral.get("steps")
            if isinstance(steps, (int, float)):
                lines.append(f"Neutral reset steps: {int(steps)}")
        applied = robot.get("actionsApplied")
        if isinstance(applied, list) and applied:
            last_applied = applied[-1]
            if isinstance(last_applied, dict):
                lines.append(f"Applied motor: {_display_scalar('appliedMotor', last_applied.get('appliedMotor'))}")
                targets = last_applied.get("targetsRaw")
                if isinstance(targets, list):
                    lines.append(f"Applied targets: {len(targets)}")
                torque = last_applied.get("torqueEnable")
                if isinstance(torque, dict):
                    enabled = [name for name, value in torque.items() if value]
                    lines.append(f"Torque enabled after run: {', '.join(enabled) if enabled else 'none'}")
    return lines


def _error(exc: Exception, *, json_output: bool = False) -> None:
    if _json_enabled(json_output):
        _emit_json({"ok": False, "error": str(exc)})
    else:
        typer.echo(f"Reflex command failed\n\nError: {exc}", err=True)
    raise typer.Exit(code=1) from exc


def root_callback(
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Emit structured JSON from subcommands. Default: human-readable text.",
    ),
) -> None:
    global _GLOBAL_JSON_OUTPUT
    _GLOBAL_JSON_OUTPUT = json_output


def _client(convex_url: str) -> ProductClient:
    return ProductClient(convex_url or None)


def _api_key(value: str) -> str:
    return resolve_api_key(value or None)


def _expect_public_ok(value: JsonValue, *, label: str, action: str) -> dict[str, JsonValue]:
    result = expect_object(value, label=label)
    if result.get("ok") is True:
        return result
    reason = result.get("reason")
    message = result.get("message")
    detail = reason if isinstance(reason, str) and reason else message
    if not isinstance(detail, str) or not detail:
        detail = "unknown"
    raise ProductError(f"{action}: {detail}.")


def _datetime_from_millis(value: JsonValue) -> datetime | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(value / 1000, tz=timezone.utc)
    if isinstance(value, str):
        try:
            return datetime.fromtimestamp(float(value) / 1000, tz=timezone.utc)
        except ValueError:
            return None
    return None


def _now_millis() -> int:
    return int(datetime.now(timezone.utc).timestamp() * 1000)


def _plural(count: int, unit: str) -> str:
    suffix = "" if count == 1 else "s"
    return f"{count} {unit}{suffix}"


def _relative_time(future: datetime) -> str:
    seconds = int(round((future - datetime.now(timezone.utc)).total_seconds()))
    if seconds <= 0:
        return "already expired"
    if seconds < 90:
        return f"in {_plural(seconds, 'second')}"
    minutes = round(seconds / 60)
    if minutes < 90:
        return f"in {_plural(minutes, 'minute')}"
    hours = round(minutes / 60)
    if hours < 48:
        return f"in {_plural(hours, 'hour')}"
    days = round(hours / 24)
    if days < 730:
        return f"in {_plural(days, 'day')}"
    years = round(days / 365)
    return f"in {_plural(years, 'year')}"


def _expiry_text(expires_at: JsonValue) -> str:
    expires = _datetime_from_millis(expires_at)
    if expires is None:
        return "unknown"
    return f"{_relative_time(expires)} ({_format_local_datetime(expires)})"


def _date_text(value: JsonValue) -> str:
    return _datetime_text(value)


def _local_datetime(value: datetime) -> datetime:
    return value.astimezone()


def _format_local_datetime(value: datetime) -> str:
    local = _local_datetime(value)
    zone = local.tzname() or local.strftime("%z")
    suffix = f" {zone}" if zone else ""
    return f"{local.strftime('%Y-%m-%d %H:%M:%S')}{suffix}"


def _datetime_text(value: JsonValue) -> str:
    date = _datetime_from_millis(value)
    if date is None:
        return "not available"
    return _format_local_datetime(date)


def _dashboard_url(value: str = "") -> str:
    if value.strip():
        return resolve_site_url(value)
    try:
        return resolve_site_url(None)
    except ProductError:
        return DEFAULT_DASHBOARD_URL


def _open_browser(url: str) -> bool:
    try:
        return bool(webbrowser.open(url))
    except Exception:
        return False


def _login_pending_lines(
    *,
    approval_url: str,
    expires_at: JsonValue,
    request_id: str,
    browser_opened: bool,
    waiting: bool,
) -> list[str]:
    lines = [
        "Reflex CLI login",
        "",
        "Open this link to authorize this terminal:",
        approval_url,
        "",
        f"Expires: {_expiry_text(expires_at)}",
        f"Request ID: {request_id}",
    ]
    if browser_opened:
        lines.append("Browser: opened automatically")
    else:
        lines.append("Browser: attempted to open automatically; use the link if no window appeared")
    lines.extend(
        [
            "",
            "After approval, Reflex will save a local API key for this machine.",
        ]
    )
    if waiting:
        lines.append("Waiting for approval...")
    else:
        lines.append("This command is not waiting. Approve the link, then run `reflex whoami`.")
    return lines


def _login_approved_lines(*, path: str, request_id: str) -> list[str]:
    return [
        "Reflex CLI login complete",
        "",
        f"Request ID: {request_id}",
        f"Credentials saved: {path}",
        "",
        "Next:",
        "  reflex whoami",
        "  reflex datasets list",
    ]


def _whoami_lines(account: dict[str, JsonValue], dashboard_url: str) -> list[str]:
    organization = account.get("organization")
    org_name = ""
    org_slug = ""
    org_id = account.get("orgId")
    if isinstance(organization, dict):
        name = organization.get("name")
        slug = organization.get("slug")
        ident = organization.get("id")
        org_name = name if isinstance(name, str) else ""
        org_slug = slug if isinstance(slug, str) else ""
        org_id = ident if isinstance(ident, str) else org_id
    key_name = account.get("keyName")
    lines = [
        "Logged in to Reflex",
        "",
        f"Organization: {org_name or org_id or 'not available'}",
    ]
    if org_slug:
        lines.append(f"Organization slug: {org_slug}")
    if org_id:
        lines.append(f"Organization ID: {org_id}")
    if isinstance(key_name, str) and key_name:
        lines.append(f"API key: {key_name}")
    lines.extend(
        [
            f"Dashboard: {dashboard_url}",
            "",
            "You can now use Reflex product commands from this terminal.",
            "Next:",
            "  reflex datasets list",
            "  reflex training list",
        ]
    )
    return lines


def _dataset_field(value: JsonValue, *, fallback: str = "not available") -> str:
    if value is None:
        return fallback
    text = str(value).strip()
    if not text:
        return fallback
    return text


def _dataset_status(dataset: dict[str, JsonValue]) -> str:
    if dataset.get("deleted") is True:
        return "deleted"
    if dataset.get("lastValidatedAt") is not None:
        return "validated"
    message = dataset.get("validationMessage")
    if isinstance(message, str) and message.strip():
        return _dataset_field(message)
    return "registered"


def _dataset_source(dataset: dict[str, JsonValue]) -> str:
    repo = _dataset_field(dataset.get("hfRepo"), fallback="")
    path = _dataset_field(dataset.get("hfPath"), fallback="")
    revision = _dataset_field(dataset.get("hfRevision"), fallback="")
    if not repo:
        return _dataset_field(dataset.get("hfSourceUri"))
    source = repo
    if path:
        source = f"{source}/{path}"
    if revision:
        source = f"{source}@{revision}"
    return source


def _huggingface_dataset_url(dataset: dict[str, JsonValue]) -> str:
    repo = _dataset_field(dataset.get("hfRepo"), fallback="")
    if not repo:
        source = _dataset_field(dataset.get("hfSourceUri"), fallback="")
        if source.startswith("https://huggingface.co/datasets/"):
            return source
        return "not available"
    url = f"https://huggingface.co/datasets/{parse.quote(repo, safe='/')}"
    revision = _dataset_field(dataset.get("hfRevision"), fallback="")
    path = _dataset_field(dataset.get("hfPath"), fallback="")
    if revision or path:
        ref = revision or "main"
        url = f"{url}/tree/{parse.quote(ref, safe='')}"
        if path:
            url = f"{url}/{parse.quote(path, safe='/')}"
    return url


def _datasets_list_lines(value: JsonValue) -> list[str]:
    result = expect_object(value, label="publicApi:listDatasets response")
    if result.get("ok") is not True:
        reason = result.get("reason")
        detail = reason if isinstance(reason, str) else "unknown"
        raise ProductError(f"Unable to list datasets: {detail}.")
    datasets = result.get("datasets")
    if not isinstance(datasets, list):
        raise ProductError("publicApi:listDatasets response did not include datasets.")
    if not datasets:
        return [
            "Datasets",
            "",
            "No datasets found.",
            "",
            "Run `reflex datasets register <hf-uri>` to add one.",
            "Use `reflex datasets list --json` for comprehensive dataset metadata.",
        ]

    lines = ["Datasets", ""]
    for index, item in enumerate(datasets, start=1):
        if not isinstance(item, dict):
            continue
        dataset = item
        dataset_id = _dataset_field(dataset.get("_id") or dataset.get("id"))
        name = _dataset_field(dataset.get("name"), fallback=dataset_id)
        updated = dataset.get("updatedAt") or dataset.get("createdAt")
        lines.extend(
            [
                f"{index}. {name}",
                f"   ID: {dataset_id}",
                f"   Source: {_dataset_source(dataset)}",
                f"   Status: {_dataset_status(dataset)}",
                f"   Updated: {_date_text(updated)}",
            ]
        )
        if index != len(datasets):
            lines.append("")
    lines.extend(
        [
            "",
            "Use `reflex datasets list --json` for comprehensive dataset metadata.",
        ]
    )
    return lines


def _percent_text(value: JsonValue) -> str:
    if isinstance(value, bool):
        return "not available"
    if not isinstance(value, (int, float)):
        return "not available"
    percent = float(value) * 100 if 0 <= float(value) <= 1 else float(value)
    if percent.is_integer():
        return f"{int(percent)}%"
    return f"{percent:.1f}%"


def _number_text(value: JsonValue) -> str:
    if isinstance(value, bool):
        return "not available"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return str(int(value)) if value.is_integer() else str(value)
    return _dataset_field(value)


def _count_pair_text(current: JsonValue, total: JsonValue, *, total_unit: str = "total") -> str:
    current_text = _number_text(current)
    total_text = _number_text(total)
    if current_text != "not available" and total_text != "not available":
        return f"{current_text}/{total_text}"
    if total_text != "not available":
        return f"{total_text} {total_unit}"
    if current_text != "not available":
        return current_text
    return ""


def _bytes_text(value: JsonValue) -> str:
    if isinstance(value, bool):
        return "not available"
    if not isinstance(value, (int, float)):
        return "not available"
    size = float(value)
    units = ["B", "KB", "MB", "GB", "TB"]
    unit = units[0]
    for unit in units:
        if abs(size) < 1024 or unit == units[-1]:
            break
        size /= 1024
    if unit == "B":
        return f"{int(size)} {unit}"
    return f"{size:.1f} {unit}"


def _pretty_enum(value: JsonValue, *, fallback: str = "not available") -> str:
    text = _dataset_field(value, fallback=fallback)
    return text.replace("_", " ")


def _parse_json_field(value: JsonValue) -> JsonValue:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError:
        return value
    if isinstance(parsed, (dict, list, str, int, float, bool)) or parsed is None:
        return parsed
    return value


def _nested_value_lines(prefix: str, value: JsonValue) -> list[str]:
    if isinstance(value, dict):
        lines: list[str] = []
        for key, item in value.items():
            if isinstance(item, (dict, list)):
                lines.append(f"{prefix}{_label(key)}:")
                lines.extend(_nested_value_lines(f"{prefix}  ", item))
            else:
                lines.append(f"{prefix}{_label(key)}: {_display_scalar(key, item)}")
        return lines
    if isinstance(value, list):
        lines = []
        for item in value:
            if isinstance(item, (dict, list)):
                lines.append(f"{prefix}-")
                lines.extend(_nested_value_lines(f"{prefix}  ", item))
            else:
                lines.append(f"{prefix}- {_display_scalar('value', item)}")
        return lines
    return [f"{prefix}{_display_scalar('value', value)}"]


def _training_title(run: dict[str, JsonValue]) -> str:
    name = _dataset_field(run.get("modelName"), fallback="")
    version = _dataset_field(run.get("modelVersion"), fallback="")
    if name and version:
        return f"{name} {version}"
    if name:
        return name
    return _dataset_field(run.get("_id") or run.get("id"))


def _training_status_text(run: dict[str, JsonValue]) -> str:
    status = _pretty_enum(run.get("status"))
    progress = _percent_text(run.get("progress"))
    if progress != "not available":
        return f"{status} ({progress})"
    return status


def _training_creator_text(run: dict[str, JsonValue]) -> str:
    created_by = run.get("createdBy")
    if isinstance(created_by, dict):
        name = _dataset_field(created_by.get("name"), fallback="")
        api_key_name = _dataset_field(created_by.get("apiKeyName"), fallback="")
        if name and api_key_name:
            return f'{name} via API key "{api_key_name}"'
        if name:
            return name
    return "not available"


def _training_dataset(run: dict[str, JsonValue]) -> dict[str, JsonValue]:
    dataset = run.get("dataset")
    if isinstance(dataset, dict):
        return dataset
    return {}


def _training_dataset_text(run: dict[str, JsonValue]) -> str:
    dataset = _training_dataset(run)
    dataset_id = _dataset_field(dataset.get("_id") or run.get("datasetId"))
    name = _dataset_field(dataset.get("name"), fallback="")
    if name:
        return f"{name} ({dataset_id})"
    return dataset_id


def _append_line(lines: list[str], label: str, value: JsonValue, *, indent: str = "   ") -> None:
    text = _dataset_field(value, fallback="")
    if text and text != "not available":
        lines.append(f"{indent}{label}: {text}")


def _append_training_json_section(lines: list[str], label: str, value: JsonValue) -> None:
    parsed = _parse_json_field(value)
    if parsed is None:
        return
    lines.append(f"   {label}:")
    lines.extend(_nested_value_lines("     ", parsed))


def _training_scope_note(*, include_all: bool, json_output: bool = False) -> str:
    default_scope = (
        "By default, `reflex training list` shows active training runs and failed training "
        "runs updated in the last 15 minutes."
    )
    if json_output:
        return "JSON output includes every training run."
    if include_all:
        return f"Showing all training runs because --all was specified. {default_scope}"
    return f"{default_scope} Add --all to include every training run."


def _training_failed_at_millis(run: dict[str, JsonValue]) -> int | None:
    date = _datetime_from_millis(run.get("finishedAt") or run.get("updatedAt") or run.get("createdAt"))
    if date is None:
        return None
    return int(date.timestamp() * 1000)


def _training_run_visible_by_default(run: dict[str, JsonValue], *, now_ms: int) -> bool:
    status = run.get("status")
    if isinstance(status, str) and status in ACTIVE_TRAINING_STATUSES:
        return True
    if status != "failed":
        return False
    failed_at = _training_failed_at_millis(run)
    return failed_at is not None and now_ms - failed_at <= RECENT_FAILED_TRAINING_WINDOW_MS


def _training_runs_scoped_value(
    value: JsonValue,
    *,
    include_all: bool,
    json_output: bool = False,
) -> dict[str, JsonValue]:
    result = expect_object(value, label="publicApi:listTrainingRuns response")
    if result.get("ok") is not True:
        reason = result.get("reason")
        detail = reason if isinstance(reason, str) else "unknown"
        raise ProductError(f"Unable to list training runs: {detail}.")
    training_runs = result.get("trainingRuns")
    if not isinstance(training_runs, list):
        return result
    if include_all:
        return {**result, "note": _training_scope_note(include_all=True, json_output=json_output)}
    now_ms = _now_millis()
    filtered = [
        item
        for item in training_runs
        if isinstance(item, dict) and _training_run_visible_by_default(item, now_ms=now_ms)
    ]
    return {**result, "trainingRuns": filtered, "note": _training_scope_note(include_all=False)}


def _training_runs_list_lines(value: JsonValue, *, include_all: bool) -> list[str]:
    result = expect_object(value, label="publicApi:listTrainingRuns response")
    if result.get("ok") is not True:
        reason = result.get("reason")
        detail = reason if isinstance(reason, str) else "unknown"
        raise ProductError(f"Unable to list training runs: {detail}.")
    training_runs = result.get("trainingRuns")
    if not isinstance(training_runs, list):
        raise ProductError("publicApi:listTrainingRuns response did not include trainingRuns.")
    if not training_runs:
        return [
            "Training runs",
            "",
            f"Note: {_training_scope_note(include_all=include_all)}",
            "",
            "No training runs found.",
            "",
            "Run `reflex training start --dataset <dataset-id>` to launch one.",
            "Use `reflex training list --json` for comprehensive training run metadata.",
        ]

    lines = ["Training runs", "", f"Note: {_training_scope_note(include_all=include_all)}", ""]
    for index, item in enumerate(training_runs, start=1):
        if not isinstance(item, dict):
            continue
        run = item
        run_id = _dataset_field(run.get("_id") or run.get("id"))
        dataset = _training_dataset(run)
        lines.extend(
            [
                f"{index}. {_training_title(run)}",
                f"   ID: {run_id}",
                f"   Status: {_training_status_text(run)}",
                f"   Created: {_datetime_text(run.get('createdAt'))}",
                f"   Updated: {_datetime_text(run.get('updatedAt'))}",
                f"   Created by: {_training_creator_text(run)}",
                f"   Dataset: {_training_dataset_text(run)}",
                f"   HF link: {_huggingface_dataset_url(dataset)}",
                f"   Base model: {_dataset_field(run.get('baseModel'))}",
                f"   Fine tuning: {_pretty_enum(run.get('fineTuningType'))}",
                f"   Operation: {_pretty_enum(run.get('operation'))}",
                f"   Model: {_training_title(run)}",
                f"   Dataset revision: {_dataset_field(run.get('hfRevision'))}",
            ]
        )
        _append_line(
            lines,
            "Epochs",
            _count_pair_text(run.get("currentEpoch"), run.get("totalEpochs") or run.get("epochs")),
        )
        _append_line(
            lines,
            "Steps",
            _count_pair_text(run.get("stepsCompleted"), run.get("estimatedTotalSteps")),
        )
        _append_line(lines, "Model artifact", run.get("modelId"))
        _append_line(lines, "Base artifact", run.get("baseModelId"))
        _append_line(lines, "Prime node", run.get("primeNodeId"))
        _append_line(lines, "Parent run", run.get("parentTrainingRunId"))
        _append_line(lines, "Request ID", run.get("requestId"))
        _append_line(lines, "Started", _datetime_text(run.get("startedAt")))
        _append_line(lines, "Finished", _datetime_text(run.get("finishedAt")))
        _append_line(lines, "Last heartbeat", _datetime_text(run.get("lastHeartbeatAt")))
        _append_line(lines, "Error", run.get("errorMessage"))
        _append_training_json_section(lines, "Parameters", run.get("parametersJson"))
        if run.get("latestCheckpointStorageId") is not None:
            lines.append("   Latest checkpoint:")
            _append_line(lines, "Storage ID", run.get("latestCheckpointStorageId"), indent="     ")
            _append_line(lines, "SHA-256", run.get("latestCheckpointSha256"), indent="     ")
            _append_line(lines, "Size", _bytes_text(run.get("latestCheckpointSizeBytes")), indent="     ")
            _append_line(lines, "Content type", run.get("latestCheckpointContentType"), indent="     ")
            _append_line(lines, "Saved", _datetime_text(run.get("latestCheckpointSavedAt")), indent="     ")
            _append_training_json_section(lines, "Checkpoint metrics", run.get("latestCheckpointMetricsJson"))
        if index != len(training_runs):
            lines.append("")
    lines.extend(
        [
            "",
            "Use `reflex training list --json` for comprehensive training run metadata.",
        ]
    )
    return lines


def signup(
    name: str = typer.Option("", help="Display name for the new Reflex account."),
    email: str = typer.Option("", help="Email address for the new Reflex account."),
    password: str = typer.Option(
        "",
        help="Password for the new Reflex account. Better Auth requires at least 8 characters by default.",
        hide_input=True,
        prompt=True,
        confirmation_prompt=True,
    ),
    site_url: str = typer.Option("", help="Reflex Platform URL. Defaults to REFLEX_PLATFORM_URL."),
    callback_url: str = typer.Option("", help="Optional Better Auth callback URL after signup."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    try:
        clean_name = name.strip()
        clean_email = email.strip().lower()
        if not clean_name:
            raise ProductError("--name is required.")
        if not clean_email:
            raise ProductError("--email is required.")
        if not password:
            raise ProductError("--password is required.")
        if len(password) < 8:
            raise ProductError("--password must be at least 8 characters.")
        resolved_site_url = resolve_site_url(site_url or None)
        AuthClient(resolved_site_url).sign_up_email(
            name=clean_name,
            email=clean_email,
            password=password,
            callback_url=callback_url.strip() or None,
        )
        payload: dict[str, JsonValue] = {
            "ok": True,
            "status": "created",
            "email": clean_email,
            "next": [
                "reflex login",
                "reflex whoami",
            ],
        }
        _emit(
            payload,
            json_output=json_output,
            title="Reflex account created",
            lines=[
                "Reflex account created",
                "",
                f"Email: {clean_email}",
                "",
                "Next:",
                "  reflex login",
                "  reflex whoami",
            ],
        )
    except ProductError as exc:
        _error(exc, json_output=json_output)


def _model_name(value: str) -> str:
    if value.strip():
        return value.strip()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    return f"reflex-cli-{stamp}"


def _model_version(value: str) -> str:
    if value.strip():
        return value.strip()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    return f"v{stamp}"


def login(
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL."),
    site_url: str = typer.Option("", help="Reflex Platform URL. Defaults to REFLEX_PLATFORM_URL."),
    timeout: float = typer.Option(600.0, help="Seconds to wait for browser approval. Use 0 to only create a request."),
    poll_interval: float = typer.Option(2.0, help="Seconds between approval polls."),
    hostname: str = typer.Option("", help="Hostname label shown in the approval screen."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    try:
        resolved_convex_url = resolve_convex_url(convex_url or None)
        resolved_site_url = resolve_site_url(site_url or None)
        client = ProductClient(resolved_convex_url)
        created = expect_object(
            client.mutation("cliAuth:createRequest", {"hostname": hostname or socket.gethostname()}),
            label="cliAuth:createRequest response",
        )
        request_id = created.get("requestId")
        if not isinstance(request_id, str):
            raise ProductError("cliAuth:createRequest did not return requestId.")
        approval_url = f"{resolved_site_url}/cli/authorize?requestId={parse.quote(request_id)}"
        pending_payload: dict[str, JsonValue] = {
            "ok": True,
            "status": "pending",
            "requestId": request_id,
            "approvalUrl": approval_url,
            "expiresAt": created.get("expiresAt"),
        }
        browser_opened = _open_browser(approval_url)
        pending_payload["browserOpened"] = browser_opened
        _emit(
            pending_payload,
            json_output=json_output,
            lines=_login_pending_lines(
                approval_url=approval_url,
                expires_at=created.get("expiresAt"),
                request_id=request_id,
                browser_opened=browser_opened,
                waiting=timeout > 0,
            ),
        )
        if timeout <= 0:
            return
        deadline = time.monotonic() + timeout
        while True:
            polled = expect_object(
                client.mutation("cliAuth:poll", {"id": request_id}),
                label="cliAuth:poll response",
            )
            status = polled.get("status")
            if status == "approved":
                api_key = polled.get("apiKey")
                if not isinstance(api_key, str) or not api_key:
                    raise ProductError("Approved login did not return an API key.")
                path = save_credentials(api_key=api_key, convex_url=resolved_convex_url, site_url=resolved_site_url)
                payload = {
                    "ok": True,
                    "status": "approved",
                    "requestId": request_id,
                    "configPath": str(path),
                    "next": ["reflex whoami", "reflex datasets list"],
                }
                _emit(
                    payload,
                    json_output=json_output,
                    lines=_login_approved_lines(path=str(path), request_id=request_id),
                )
                return
            if status in {"expired", "consumed", "unknown"}:
                payload = {"ok": False, "status": status, "requestId": request_id}
                _emit(
                    payload,
                    json_output=json_output,
                    lines=[
                        "Reflex CLI login was not completed",
                        "",
                        f"Status: {status}",
                        f"Request ID: {request_id}",
                        "Run `reflex login` to generate a fresh approval link.",
                    ],
                )
                raise typer.Exit(code=1)
            if time.monotonic() >= deadline:
                payload = {
                    "ok": False,
                    "status": "timeout",
                    "requestId": request_id,
                    "approvalUrl": approval_url,
                    "expiresAt": created.get("expiresAt"),
                }
                _emit(
                    payload,
                    json_output=json_output,
                    lines=[
                        "Still waiting for Reflex CLI approval",
                        "",
                        "Open this link to finish authorizing this terminal:",
                        approval_url,
                        "",
                        f"Expires: {_expiry_text(created.get('expiresAt'))}",
                        f"Request ID: {request_id}",
                    ],
                )
                raise typer.Exit(code=1)
            time.sleep(max(0.25, poll_interval))
    except ProductError as exc:
        _error(exc, json_output=json_output)


def logout(
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    deleted = clear_credentials()
    payload = {"ok": True, "deleted": deleted, "configPath": str(config_path())}
    _emit(
        payload,
        json_output=json_output,
        title="Logged out of Reflex",
        lines=[
            "Logged out of Reflex",
            "",
            f"Credentials removed: {'yes' if deleted else 'no saved credentials found'}",
            f"Config path: {config_path()}",
        ],
    )


def whoami(
    api_key: str = typer.Option("", help="API key. Defaults to REFLEX_API_KEY or saved login."),
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL or saved login."),
    site_url: str = typer.Option("", help="Reflex dashboard URL. Defaults to saved login or app.tryreflex.ai."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    try:
        value = _client(convex_url).query("publicApi:whoami", {"apiKey": _api_key(api_key)})
        account = expect_object(value, label="publicApi:whoami response")
        if account.get("ok") is not True:
            reason = account.get("reason")
            detail = reason if isinstance(reason, str) else "unknown"
            raise ProductError(f"Reflex API key is not valid: {detail}. Run `reflex login`.")
        payload: dict[str, JsonValue] = {"ok": True, "account": account}
        _emit(
            payload,
            json_output=json_output,
            lines=_whoami_lines(account, _dashboard_url(site_url)),
        )
    except ProductError as exc:
        _error(exc, json_output=json_output)


@DATASET_COMMANDS.command("register", context_settings=HELP_CONTEXT)
def register_dataset(
    hf_source_uri: str = typer.Argument(..., help="Public Hugging Face dataset URI, e.g. hf://datasets/owner/repo."),
    api_key: str = typer.Option("", help="API key. Defaults to REFLEX_API_KEY or saved login."),
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL or saved login."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    try:
        value = _client(convex_url).action(
            "publicApi:registerDataset",
            {"apiKey": _api_key(api_key), "hfSourceUri": hf_source_uri},
        )
        result = _expect_public_ok(
            value,
            label="publicApi:registerDataset response",
            action="Unable to register dataset",
        )
        _emit(
            {"ok": True, "dataset": result, "next": ["reflex datasets validate <dataset-id>"]},
            json_output=json_output,
            title="Dataset registered",
        )
    except ProductError as exc:
        _error(exc, json_output=json_output)


@DATASET_COMMANDS.command("validate", context_settings=HELP_CONTEXT)
def validate_dataset(
    dataset_id: str = typer.Argument(..., help="Dataset id returned by register/list."),
    api_key: str = typer.Option("", help="API key. Defaults to REFLEX_API_KEY or saved login."),
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL or saved login."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    try:
        value = _client(convex_url).action(
            "publicApi:validateDataset",
            {"apiKey": _api_key(api_key), "datasetId": dataset_id},
        )
        result = _expect_public_ok(
            value,
            label="publicApi:validateDataset response",
            action="Unable to validate dataset",
        )
        _emit(
            {"ok": True, "validation": result, "next": ["reflex training start --dataset <dataset-id>"]},
            json_output=json_output,
            title="Dataset validation complete",
        )
    except ProductError as exc:
        _error(exc, json_output=json_output)


@DATASET_COMMANDS.command("list", context_settings=HELP_CONTEXT)
def list_datasets(
    api_key: str = typer.Option("", help="API key. Defaults to REFLEX_API_KEY or saved login."),
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL or saved login."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    try:
        value = _client(convex_url).mutation("publicApi:listDatasets", {"apiKey": _api_key(api_key)})
        result = _expect_public_ok(
            value,
            label="publicApi:listDatasets response",
            action="Unable to list datasets",
        )
        _emit(
            {"ok": True, "datasets": result},
            json_output=json_output,
            title="Datasets",
            lines=_datasets_list_lines(result),
        )
    except ProductError as exc:
        _error(exc, json_output=json_output)


@TRAINING_COMMANDS.command("start", context_settings=HELP_CONTEXT)
def start_training(
    dataset_id: str = typer.Option(..., "--dataset", help="Dataset id returned by register/list."),
    base_model: str = typer.Option("pi0.5", help="Base model to train."),
    trainable: str = typer.Option("lora", help="Fine-tuning type: lora or full."),
    epochs: int = typer.Option(3, help="Number of training epochs."),
    model_name: str = typer.Option("", help="Model artifact name."),
    model_version: str = typer.Option("", help="Model artifact version."),
    parameters_json: str = typer.Option("", help="Optional JSON object or @path for training parameters."),
    request_id: str = typer.Option("", help="Optional idempotency key."),
    api_key: str = typer.Option("", help="API key. Defaults to REFLEX_API_KEY or saved login."),
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL or saved login."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    try:
        if base_model != "pi0.5":
            raise ProductError("Only base model pi0.5 is supported by the product API.")
        if trainable not in {"lora", "full"}:
            raise ProductError("--trainable must be lora or full.")
        params = ""
        if parameters_json:
            params_value = load_json_arg(parameters_json, label="parameters-json")
            params = json.dumps(params_value, sort_keys=True)
        args: dict[str, JsonValue] = {
            "apiKey": _api_key(api_key),
            "datasetId": dataset_id,
            "baseModel": "pi0.5",
            "fineTuningType": trainable,
            "epochs": epochs,
            "modelName": _model_name(model_name),
            "modelVersion": _model_version(model_version),
        }
        if params:
            args["parametersJson"] = params
        if request_id:
            args["requestId"] = request_id
        value = _client(convex_url).action("publicApi:createAndProvisionTrainingRun", args)
        result = _expect_public_ok(
            value,
            label="publicApi:createAndProvisionTrainingRun response",
            action="Unable to start training run",
        )
        _emit(
            {
                "ok": True,
                "trainingRun": result,
                "next": ["reflex training status <training-run-id> --watch"],
            },
            json_output=json_output,
            title="Training run started",
        )
    except ProductError as exc:
        _error(exc, json_output=json_output)


@TRAINING_COMMANDS.command("status", context_settings=HELP_CONTEXT)
def training_status(
    training_run_id: str = typer.Argument(..., help="Training run id returned by start/list."),
    watch: bool = typer.Option(False, "--watch", help="Poll until a terminal training status is reached."),
    poll_interval: float = typer.Option(10.0, help="Seconds between polls when --watch is set."),
    api_key: str = typer.Option("", help="API key. Defaults to REFLEX_API_KEY or saved login."),
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL or saved login."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    try:
        while True:
            value = expect_object(
                _client(convex_url).mutation(
                    "publicApi:getTrainingRun",
                    {"apiKey": _api_key(api_key), "trainingRunId": training_run_id},
                ),
                label="training run response",
            )
            _expect_public_ok(
                value,
                label="publicApi:getTrainingRun response",
                action="Unable to get training run",
            )
            _emit({"ok": True, "trainingRun": value}, json_output=json_output, title="Training run status")
            run = value.get("trainingRun")
            status = run.get("status") if isinstance(run, dict) else None
            if not watch or status in {"succeeded", "failed", "stopped"}:
                return
            time.sleep(max(1.0, poll_interval))
    except ProductError as exc:
        _error(exc, json_output=json_output)


@TRAINING_COMMANDS.command("list", context_settings=HELP_CONTEXT)
def list_training_runs(
    api_key: str = typer.Option("", help="API key. Defaults to REFLEX_API_KEY or saved login."),
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL or saved login."),
    all_runs: bool = typer.Option(
        False,
        "--all",
        help="Show every training run. By default, show active runs and failed runs updated in the last 15 minutes.",
    ),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    try:
        value = _client(convex_url).mutation("publicApi:listTrainingRuns", {"apiKey": _api_key(api_key)})
        json_mode = _json_enabled(json_output)
        scoped_value = _training_runs_scoped_value(
            value,
            include_all=all_runs or json_mode,
            json_output=json_mode,
        )
        _emit(
            scoped_value,
            json_output=json_output,
            title="Training runs",
            lines=None if json_mode else _training_runs_list_lines(scoped_value, include_all=all_runs),
        )
    except ProductError as exc:
        _error(exc, json_output=json_output)


@TRAINING_COMMANDS.command("stop", context_settings=HELP_CONTEXT)
def stop_training(
    training_run_id: str = typer.Argument(..., help="Training run id returned by start/list."),
    api_key: str = typer.Option("", help="API key. Defaults to REFLEX_API_KEY or saved login."),
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL or saved login."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    try:
        value = _client(convex_url).mutation(
            "publicApi:stopTrainingRun",
            {"apiKey": _api_key(api_key), "trainingRunId": training_run_id},
        )
        result = _expect_public_ok(
            value,
            label="publicApi:stopTrainingRun response",
            action="Unable to stop training run",
        )
        _emit({"ok": True, "trainingRun": result}, json_output=json_output, title="Training run stop requested")
    except ProductError as exc:
        _error(exc, json_output=json_output)


@ARTIFACT_COMMANDS.command("list", context_settings=HELP_CONTEXT)
def list_artifacts(
    api_key: str = typer.Option("", help="API key. Defaults to REFLEX_API_KEY or saved login."),
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL or saved login."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    try:
        value = _client(convex_url).query("models:listWithApiKey", {"apiKey": _api_key(api_key)})
        result = _expect_public_ok(
            value,
            label="models:listWithApiKey response",
            action="Unable to list artifacts",
        )
        _emit({"ok": True, "artifacts": result}, json_output=json_output, title="Artifacts")
    except ProductError as exc:
        _error(exc, json_output=json_output)


@ARTIFACT_COMMANDS.command("get", context_settings=HELP_CONTEXT)
def get_artifact(
    artifact_id: str = typer.Argument(..., help="Artifact/model id returned by list or training status."),
    api_key: str = typer.Option("", help="API key. Defaults to REFLEX_API_KEY or saved login."),
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL or saved login."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    try:
        value = _client(convex_url).query(
            "models:getWithApiKey",
            {"apiKey": _api_key(api_key), "modelId": artifact_id},
        )
        result = _expect_public_ok(
            value,
            label="models:getWithApiKey response",
            action="Unable to get artifact",
        )
        _emit(
            {
                "ok": True,
                "artifact": result,
                "next": ["reflex inference run --artifact <artifact-id> --prompt <task>"],
            },
            json_output=json_output,
            title="Artifact",
        )
    except ProductError as exc:
        _error(exc, json_output=json_output)


@INFERENCE_COMMANDS.command("authorize", context_settings=HELP_CONTEXT)
def authorize_inference(
    artifact_id: str = typer.Option("", "--artifact", help="Optional artifact/model id."),
    base_model: str = typer.Option("pi0.5", help="Base model to serve."),
    runtime: str = typer.Option("", help="Optional runtime selector."),
    robot_type: str = typer.Option(DEFAULT_ROBOT_TYPE, "--robot", help="Robot/embodiment requested for the session."),
    action_adapter: str = typer.Option(
        "",
        "--action-adapter",
        help="Requested action schema: so101_joint, aloha_joint, or pi_native.",
    ),
    mode: str = typer.Option("dry_run", help="Inference mode: dry_run or apply_actions."),
    client_session_id: str = typer.Option("", help="Optional client-provided session id."),
    api_key: str = typer.Option("", help="API key. Defaults to REFLEX_API_KEY or saved login."),
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL or saved login."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    try:
        value = _authorize(
            artifact_id=artifact_id,
            base_model=base_model,
            runtime=runtime,
            robot_type=robot_type,
            action_adapter=action_adapter,
            mode=mode,
            client_session_id=client_session_id,
            api_key=api_key,
            convex_url=convex_url,
        )
        _emit(
            {"ok": True, "inferenceSession": value},
            json_output=json_output,
            title="Inference session authorized",
        )
    except ProductError as exc:
        _error(exc, json_output=json_output)


@INFERENCE_COMMANDS.command("run", context_settings=HELP_CONTEXT)
def run_inference(
    artifact_id: str = typer.Option(
        "",
        "--artifact",
        help="Optional artifact/model id returned by artifacts list.",
    ),
    mock: bool = typer.Option(
        False,
        "--mock",
        help="Run with a simulated neutral robot and zero camera frames.",
    ),
    steps: int = typer.Option(
        1,
        "--steps",
        help="Number of control-loop observations to send.",
    ),
    prompt: str = typer.Option(
        ...,
        "--prompt",
        help="Required task instruction sent to inference.",
    ),
    camera: list[str] = typer.Option(
        ["cam_high"],
        "--camera",
        help="Camera channel sent to inference. Repeat for multiple.",
    ),
    mock_joints: int = typer.Option(
        6,
        help="Number of simulated robot joints to update from returned actions.",
    ),
    state_dim: int = typer.Option(14, help="State vector length sent to inference in --mock mode."),
    port: str = typer.Option(
        "",
        "--port",
        help="SO-101 serial port. Defaults to auto-detecting a Feetech bus.",
    ),
    robot_motor: str = typer.Option(
        "wrist_flex",
        "--robot-motor",
        help="SO-101 motor used by the safety-clamped action adapter.",
    ),
    robot_max_delta_raw: int = typer.Option(
        260,
        "--robot-max-delta-raw",
        help="Maximum raw encoder delta for --robot-backend raw.",
    ),
    robot_max_relative_target: float = typer.Option(
        10.0,
        "--robot-max-relative-target",
        help="Maximum calibrated target change per joint for LeRobot SO-101 execution.",
    ),
    robot_action_steps: int = typer.Option(
        25,
        "--robot-action-steps",
        help="Number of sampled action-chunk targets to apply in SO-101 mode.",
    ),
    robot_action_sleep: float = typer.Option(
        0.08,
        "--robot-action-sleep",
        help="Seconds to sleep after each sampled SO-101 action target.",
    ),
    robot_prefetch_frame: int = typer.Option(
        14,
        "--robot-prefetch-frame",
        help="Start requesting the next SO-101 action chunk after consuming this source frame index.",
    ),
    robot_backend: str = typer.Option(
        "lerobot",
        "--robot-backend",
        help="SO-101 backend: lerobot or raw.",
    ),
    robot_id: str = typer.Option(
        "",
        "--robot-id",
        help="LeRobot SO-101 calibration id. Defaults to REFLEX_SO101_ID or reflex_so101.",
    ),
    hz: float = typer.Option(25.0, help="Control-loop frequency metadata."),
    timeout: float = typer.Option(120.0, help="WebSocket connect/read timeout in seconds."),
    websocket_retry_seconds: float = typer.Option(
        90.0,
        "--websocket-retry-seconds",
        help="Seconds to retry transient WebSocket handshake failures before HTTP fallback.",
    ),
    mode: str = typer.Option("dry_run", help="Inference mode: dry_run or apply_actions."),
    base_model: str = typer.Option("pi0.5", help="Base model to serve."),
    runtime: str = typer.Option("", help="Optional runtime selector."),
    robot_type: str = typer.Option(DEFAULT_ROBOT_TYPE, "--robot", help="Robot/embodiment requested for the session."),
    action_adapter: str = typer.Option(
        "",
        "--action-adapter",
        help="Requested action schema: so101_joint, aloha_joint, or pi_native.",
    ),
    client_session_id: str = typer.Option("", help="Optional client-provided session id."),
    api_key: str = typer.Option("", help="API key. Defaults to REFLEX_API_KEY or saved login."),
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL or saved login."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    try:
        prompt = prompt.strip()
        if not prompt:
            raise ProductError("--prompt is required.")
        if steps < 1:
            raise ProductError("--steps must be at least 1.")
        if mock_joints < 1:
            raise ProductError("--mock-joints must be at least 1.")
        if state_dim < mock_joints:
            raise ProductError("--state-dim must be greater than or equal to --mock-joints.")
        if robot_max_delta_raw < 1:
            raise ProductError("--robot-max-delta-raw must be at least 1.")
        if robot_max_relative_target <= 0:
            raise ProductError("--robot-max-relative-target must be greater than 0.")
        if robot_action_steps < 1:
            raise ProductError("--robot-action-steps must be at least 1.")
        if robot_action_sleep < 0:
            raise ProductError("--robot-action-sleep must be at least 0.")
        if robot_prefetch_frame < 0:
            raise ProductError("--robot-prefetch-frame must be at least 0.")
        if websocket_retry_seconds < 0:
            raise ProductError("--websocket-retry-seconds must be at least 0.")
        robot_backend = robot_backend.strip().lower().replace("-", "_") or "lerobot"
        if robot_backend not in {"lerobot", "raw"}:
            raise ProductError("--robot-backend must be lerobot or raw.")
        robot_type = robot_type.strip().lower().replace("-", "_") or DEFAULT_ROBOT_TYPE
        action_adapter = _normalize_action_adapter(action_adapter, robot_type=robot_type)
        if not mock and robot_type != "so101":
            raise ProductError("Real robot inference currently supports --robot so101.")
        if not mock and action_adapter != DEFAULT_SO101_ACTION_ADAPTER:
            raise ProductError("SO-101 execution requires --action-adapter so101_joint.")

        value = _authorize(
            artifact_id=artifact_id,
            base_model=base_model,
            runtime=runtime,
            robot_type=robot_type,
            action_adapter=action_adapter,
            mode=mode,
            client_session_id=client_session_id,
            api_key=api_key,
            convex_url=convex_url,
        )
        close_result: dict[str, JsonValue] | None = None
        try:
            stream_result = _run_authorized_inference_stream(
                session=value,
                mock=mock,
                steps=steps,
                prompt=prompt,
                robot_type=robot_type,
                action_adapter=action_adapter,
                cameras=camera,
                mock_joints=mock_joints,
                state_dim=state_dim,
                port=port,
                robot_motor=robot_motor,
                robot_max_delta_raw=robot_max_delta_raw,
                robot_max_relative_target=robot_max_relative_target,
                robot_action_steps=robot_action_steps,
                robot_action_sleep=robot_action_sleep,
                robot_prefetch_frame=robot_prefetch_frame,
                robot_backend=robot_backend,
                robot_id=robot_id,
                hz=hz,
                timeout=timeout,
                websocket_retry_seconds=websocket_retry_seconds,
                log_ticks=not _json_enabled(json_output),
            )
        except KeyboardInterrupt as exc:
            close_result = _close_authorized_session(
                session=value,
                api_key=api_key,
                convex_url=convex_url,
                reason="cli_interrupted",
            )
            if _json_enabled(json_output):
                _emit_json({
                    "ok": False,
                    "error": "Interrupted by user.",
                    "closedSession": close_result,
                })
            else:
                typer.echo("\nInference run interrupted; session closed.", err=True)
                if close_result and close_result.get("ok") is False:
                    typer.echo(f"Session close failed: {close_result.get('error')}", err=True)
            raise typer.Exit(code=130) from exc
        except Exception as exc:
            close_result = _close_authorized_session(
                session=value,
                api_key=api_key,
                convex_url=convex_url,
                reason="cli_run_error",
            )
            close_note = (
                ""
                if not close_result or close_result.get("ok") is not False
                else f" Session close also failed: {close_result.get('error')}"
            )
            raise ProductError(f"Inference stream failed: {exc}.{close_note}") from exc
        close_result = _close_authorized_session(
            session=value,
            api_key=api_key,
            convex_url=convex_url,
            reason="cli_run_complete",
        )
        payload: dict[str, JsonValue] = {
            "ok": True,
            "inferenceSession": _public_session_summary(value),
            "stream": stream_result,
            "closedSession": close_result,
        }
        _emit(
            payload,
            json_output=json_output,
            title="Inference run complete",
            lines=_inference_run_lines(payload),
        )
    except ProductError as exc:
        _error(exc, json_output=json_output)


@INFERENCE_COMMANDS.command("close", context_settings=HELP_CONTEXT)
def close_inference(
    session_id: str = typer.Argument(..., help="Inference session id returned by authorize/run/list."),
    reason: str = typer.Option("cli_closed", help="Close reason recorded for the session."),
    api_key: str = typer.Option("", help="API key. Defaults to REFLEX_API_KEY or saved login."),
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL or saved login."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    try:
        value = _client(convex_url).mutation(
            "publicApi:closeSession",
            {"apiKey": _api_key(api_key), "sessionId": session_id, "reason": reason},
        )
        result = _expect_public_ok(
            value,
            label="publicApi:closeSession response",
            action="Unable to close inference session",
        )
        _emit(
            {"ok": True, "inferenceSession": result},
            json_output=json_output,
            title="Inference session closed",
        )
    except ProductError as exc:
        _error(exc, json_output=json_output)


@INFERENCE_COMMANDS.command("list", context_settings=HELP_CONTEXT)
def list_inference_sessions(
    api_key: str = typer.Option("", help="API key. Defaults to REFLEX_API_KEY or saved login."),
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL or saved login."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    try:
        value = _client(convex_url).mutation("publicApi:listInferenceSessions", {"apiKey": _api_key(api_key)})
        result = _expect_public_ok(
            value,
            label="publicApi:listInferenceSessions response",
            action="Unable to list inference sessions",
        )
        _emit({"ok": True, "inferenceSessions": result}, json_output=json_output, title="Inference sessions")
    except ProductError as exc:
        _error(exc, json_output=json_output)


SESSIONS_COMMANDS.command("close", context_settings=HELP_CONTEXT)(close_inference)
SESSIONS_COMMANDS.command("list", context_settings=HELP_CONTEXT)(list_inference_sessions)


@SESSIONS_COMMANDS.command("promote", context_settings=HELP_CONTEXT)
def promote_session_command(
    session_id: str = typer.Argument(..., help="Session id returned by sessions start/list."),
    mode: str = typer.Option("apply_actions", "--to", help="Target mode: dry_run or apply_actions."),
    api_key: str = typer.Option("", help="API key. Defaults to REFLEX_API_KEY or saved login."),
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL or saved login."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    try:
        if mode not in {"dry_run", "apply_actions"}:
            raise ProductError("--to must be dry_run or apply_actions.")
        value = _client(convex_url).mutation(
            "publicApi:promoteSession",
            {"apiKey": _api_key(api_key), "sessionId": session_id, "mode": mode},
        )
        result = _expect_public_ok(
            value,
            label="publicApi:promoteSession response",
            action="Unable to promote session",
        )
        _emit({"ok": True, "session": result}, json_output=json_output, title="Session promoted")
    except ProductError as exc:
        _error(exc, json_output=json_output)


def _deployment_args_from_spec(path: str) -> dict[str, JsonValue]:
    spec = load_deployment_spec(path)
    name = spec.get("name")
    model_id = spec.get("modelId") or spec.get("model_id") or spec.get("artifact")
    if not isinstance(name, str) or not name.strip():
        raise ProductError("Deployment spec requires string field: name.")
    if not isinstance(model_id, str) or not model_id.strip():
        raise ProductError("Deployment spec requires string field: modelId.")
    args: dict[str, JsonValue] = {
        "name": name,
        "modelId": model_id,
        "specJson": json.dumps(spec, sort_keys=True),
    }
    robot_schema_id = spec.get("robotSchemaId") or spec.get("robot_schema_id")
    runtime = spec.get("runtime")
    mode = spec.get("mode")
    if isinstance(robot_schema_id, str) and robot_schema_id.strip():
        args["robotSchemaId"] = robot_schema_id
    if isinstance(runtime, str) and runtime.strip():
        args["runtime"] = runtime
    if isinstance(mode, str) and mode.strip():
        args["mode"] = mode
    return args


def _create_deployment(
    *,
    spec_path: str,
    name: str,
    artifact_id: str,
    robot_schema_id: str,
    runtime: str,
    mode: str,
    api_key: str,
    convex_url: str,
) -> JsonValue:
    args = _deployment_args_from_spec(spec_path) if spec_path else {
        "name": name,
        "modelId": artifact_id,
        "mode": mode,
    }
    if not spec_path:
        if not name.strip():
            raise ProductError("--name is required when --file is not provided.")
        if not artifact_id.strip():
            raise ProductError("--artifact is required when --file is not provided.")
        if robot_schema_id:
            args["robotSchemaId"] = robot_schema_id
        if runtime:
            args["runtime"] = runtime
    args["apiKey"] = _api_key(api_key)
    return _expect_public_ok(
        _client(convex_url).mutation("publicApi:createDeployment", args),
        label="publicApi:createDeployment response",
        action="Unable to create deployment",
    )


@DEPLOYMENTS_COMMANDS.command("create", context_settings=HELP_CONTEXT)
def create_deployment_command(
    spec_path: str = typer.Option("", "--file", "-f", help="Deployment JSON spec path."),
    name: str = typer.Option("", help="Deployment name when --file is not used."),
    artifact_id: str = typer.Option("", "--artifact", help="Model artifact id when --file is not used."),
    robot_schema_id: str = typer.Option("", "--robot-schema", help="Optional robot schema id."),
    runtime: str = typer.Option("", help="Optional runtime selector."),
    mode: str = typer.Option("dry_run", help="Default session mode: dry_run or apply_actions."),
    api_key: str = typer.Option("", help="API key. Defaults to REFLEX_API_KEY or saved login."),
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL or saved login."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    try:
        result = _create_deployment(
            spec_path=spec_path,
            name=name,
            artifact_id=artifact_id,
            robot_schema_id=robot_schema_id,
            runtime=runtime,
            mode=mode,
            api_key=api_key,
            convex_url=convex_url,
        )
        _emit(
            {"ok": True, "deployment": result, "next": ["reflex doctor <deployment-id>"]},
            json_output=json_output,
            title="Deployment created",
        )
    except ProductError as exc:
        _error(exc, json_output=json_output)


def deploy(
    spec_path: str = typer.Option("", "--file", "-f", help="Deployment JSON spec path."),
    name: str = typer.Option("", help="Deployment name when --file is not used."),
    artifact_id: str = typer.Option("", "--artifact", help="Model artifact id when --file is not used."),
    robot_schema_id: str = typer.Option("", "--robot-schema", help="Optional robot schema id."),
    runtime: str = typer.Option("", help="Optional runtime selector."),
    mode: str = typer.Option("dry_run", help="Default session mode: dry_run or apply_actions."),
    api_key: str = typer.Option("", help="API key. Defaults to REFLEX_API_KEY or saved login."),
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL or saved login."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    create_deployment_command(
        spec_path=spec_path,
        name=name,
        artifact_id=artifact_id,
        robot_schema_id=robot_schema_id,
        runtime=runtime,
        mode=mode,
        api_key=api_key,
        convex_url=convex_url,
        json_output=json_output,
    )


@DEPLOYMENTS_COMMANDS.command("list", context_settings=HELP_CONTEXT)
def list_deployments_command(
    api_key: str = typer.Option("", help="API key. Defaults to REFLEX_API_KEY or saved login."),
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL or saved login."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    try:
        value = _client(convex_url).mutation("publicApi:listDeployments", {"apiKey": _api_key(api_key)})
        result = _expect_public_ok(
            value,
            label="publicApi:listDeployments response",
            action="Unable to list deployments",
        )
        _emit({"ok": True, "deployments": result}, json_output=json_output, title="Deployments")
    except ProductError as exc:
        _error(exc, json_output=json_output)


def doctor(
    deployment_id: str = typer.Argument(..., help="Deployment id returned by deploy/list."),
    api_key: str = typer.Option("", help="API key. Defaults to REFLEX_API_KEY or saved login."),
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL or saved login."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    try:
        value = _client(convex_url).mutation(
            "publicApi:runReadinessCheck",
            {"apiKey": _api_key(api_key), "deploymentId": deployment_id},
        )
        result = _expect_public_ok(
            value,
            label="publicApi:runReadinessCheck response",
            action="Unable to run readiness check",
        )
        _emit({"ok": True, "readiness": result}, json_output=json_output, title="Readiness check")
    except ProductError as exc:
        _error(exc, json_output=json_output)


@ROBOTS_COMMANDS.command("register-schema", context_settings=HELP_CONTEXT)
def register_robot_schema_command(
    name: str = typer.Argument(..., help="Robot schema name."),
    schema_path: Path = typer.Option(..., "--schema", help="Robot schema JSON path."),
    robot_kind: str = typer.Option("", help="Optional robot kind."),
    api_key: str = typer.Option("", help="API key. Defaults to REFLEX_API_KEY or saved login."),
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL or saved login."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    try:
        schema = _load_schema_payload(schema_path)
        action = schema.get("actions", {}).get("action", {}) if isinstance(schema.get("actions"), dict) else {}
        args: dict[str, JsonValue] = {
            "apiKey": _api_key(api_key),
            "name": name,
            "schemaVersion": str(schema.get("schema_version") or schema.get("schemaVersion") or "robot_schema.v1"),
            "schemaJson": json.dumps(schema, sort_keys=True),
            "hasExplicitSafeStop": isinstance(action, dict)
            and isinstance(action.get("safe_stop"), list)
            and len(action.get("safe_stop", [])) > 0,
        }
        if robot_kind:
            args["robotKind"] = robot_kind
        if isinstance(action, dict):
            shape = action.get("shape")
            if isinstance(shape, list) and shape and isinstance(shape[0], (int, float)):
                args["actionDim"] = int(shape[0])
            if isinstance(action.get("safe_stop_mode"), str):
                args["safeStopMode"] = action["safe_stop_mode"]
        value = _client(convex_url).mutation("publicApi:registerRobotSchema", args)
        result = _expect_public_ok(
            value,
            label="publicApi:registerRobotSchema response",
            action="Unable to register robot schema",
        )
        _emit({"ok": True, "robotSchema": result}, json_output=json_output, title="Robot schema registered")
    except ProductError as exc:
        _error(exc, json_output=json_output)


@ROBOTS_COMMANDS.command("register", context_settings=HELP_CONTEXT)
def register_robot_command(
    name: str = typer.Argument(..., help="Robot name."),
    robot_schema_id: str = typer.Option(..., "--schema-id", help="Robot schema id."),
    robot_kind: str = typer.Option("", help="Optional robot kind."),
    calibration_id: str = typer.Option("", help="Optional calibration id."),
    api_key: str = typer.Option("", help="API key. Defaults to REFLEX_API_KEY or saved login."),
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL or saved login."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    try:
        args: dict[str, JsonValue] = {
            "apiKey": _api_key(api_key),
            "name": name,
            "robotSchemaId": robot_schema_id,
        }
        if robot_kind:
            args["robotKind"] = robot_kind
        if calibration_id:
            args["calibrationId"] = calibration_id
        value = _client(convex_url).mutation("publicApi:registerRobot", args)
        result = _expect_public_ok(
            value,
            label="publicApi:registerRobot response",
            action="Unable to register robot",
        )
        _emit({"ok": True, "robot": result}, json_output=json_output, title="Robot registered")
    except ProductError as exc:
        _error(exc, json_output=json_output)


@ROBOTS_COMMANDS.command("pair", context_settings=HELP_CONTEXT)
def pair_robot_command(
    robot_id: str = typer.Argument(..., help="Registered robot id."),
    ttl_seconds: int = typer.Option(3600, help="Pairing token lifetime in seconds."),
    api_key: str = typer.Option("", help="API key. Defaults to REFLEX_API_KEY or saved login."),
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL or saved login."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    try:
        value = _client(convex_url).mutation(
            "publicApi:createRobotPairingToken",
            {"apiKey": _api_key(api_key), "robotId": robot_id, "ttlSeconds": ttl_seconds},
        )
        result = _expect_public_ok(
            value,
            label="publicApi:createRobotPairingToken response",
            action="Unable to create robot pairing token",
        )
        _emit({"ok": True, "pairing": result}, json_output=json_output, title="Robot pairing token")
    except ProductError as exc:
        _error(exc, json_output=json_output)


_VALID_SESSION_MODES = ("dry_run", "apply_actions")


def connect_robot_command(
    config: str = typer.Option("", "--config", help="Path to a YAML config that fully describes the session (transport, hardware, mode). When set, other flags are ignored."),
    deployment_id: str = typer.Option("", "--deployment", help="Deployment id to bind this robot session to. Required unless --config is set."),
    robot_id: str = typer.Option("", "--robot", help="Registered robot id. Required unless --config is set."),
    pairing_token: str = typer.Option("", "--pairing-token", help="Optional robot pairing token to claim before connecting."),
    mode: str = typer.Option("dry_run", help="Session mode: dry_run or apply_actions."),
    allow_unchecked: bool = typer.Option(False, "--allow-unchecked", help="Skip the readiness gate for apply_actions. Use only for known-safe development."),
    once: bool = typer.Option(False, "--once", help="Authorize one session and exit instead of staying attached."),
    start_drtc: bool = typer.Option(False, "--start-drtc", help="Start the local DRTC sidecar client when inference extras are installed."),
    sidecar_binary: str = typer.Option("", help="Optional DRTC sidecar binary path."),
    observe_command: str = typer.Option("", help="Command that emits one observation JSON object per control step."),
    action_command: str = typer.Option("", help="Command that receives action chunk JSON on stdin and applies it."),
    safe_stop_command: str = typer.Option("", help="Command that receives safe-stop JSON on stdin after connector errors."),
    command_timeout_s: float = typer.Option(2.0, help="Per-command wallclock timeout in seconds for observe/action subprocesses."),
    safe_stop_timeout_s: float = typer.Option(5.0, help="Wallclock timeout in seconds for the safe-stop subprocess."),
    task: str = typer.Option("", help="Optional task text sent with observations when observe-command omits task."),
    max_steps: int = typer.Option(0, help="Maximum execution loop steps. 0 means run until interrupted."),
    control_period_s: float = typer.Option(0.02, help="Control loop period in seconds."),
    heartbeat_interval: float = typer.Option(10.0, help="Seconds between local keepalive messages."),
    api_key: str = typer.Option("", help="API key. Defaults to REFLEX_API_KEY or saved login."),
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL or saved login."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    drtc_client = None
    try:
        if mode not in _VALID_SESSION_MODES:
            raise ProductError(
                f"mode must be one of {', '.join(_VALID_SESSION_MODES)}; got {mode!r}."
            )
        if config:
            from reflex.connect_runner import run_from_config

            result = run_from_config(config)
            _emit(
                {
                    "ok": True,
                    "config": config,
                    "steps": result.steps,
                    "appliedSteps": result.applied_steps,
                    "safeStops": result.safe_stops,
                    "errors": result.errors,
                },
                json_output=json_output,
                title="Connect session (config)",
                lines=[
                    f"Connect session finished: {result.steps} steps, "
                    f"{result.applied_steps} applied, {result.safe_stops} safe stops",
                ],
            )
            return
        if not deployment_id:
            raise ProductError("--deployment is required unless --config is provided.")
        if not robot_id:
            raise ProductError("--robot is required unless --config is provided.")
        if mode == "apply_actions" and not allow_unchecked:
            _require_readiness_passed(
                deployment_id=deployment_id, api_key=api_key, convex_url=convex_url
            )
        if pairing_token:
            _expect_public_ok(
                _client(convex_url).mutation(
                    "publicApi:claimRobotPairingToken",
                    {"apiKey": _api_key(api_key), "token": pairing_token},
                ),
                label="publicApi:claimRobotPairingToken response",
                action="Unable to claim robot pairing token",
            )
        value = _authorize(
            artifact_id="",
            deployment_id=deployment_id,
            robot_id=robot_id,
            base_model="pi0.5",
            runtime="",
            mode=mode,
            client_session_id="",
            api_key=api_key,
            convex_url=convex_url,
        )
        payload = {
            "ok": True,
            "session": value,
            "status": "authorized",
            "transport": "drtc" if start_drtc else "drtc_pending",
        }
        if start_drtc:
            if not isinstance(value, dict):
                raise ProductError("Session authorization did not return a session object.")
            drtc_client = _start_drtc_client_from_session(value, sidecar_binary=sidecar_binary)
            payload["drtcMetadata"] = getattr(drtc_client, "metadata", {})
        heartbeat_payload = {
            "apiKey": _api_key(api_key),
            "robotId": robot_id,
            "deploymentId": deployment_id,
            "transport": "drtc" if start_drtc else "drtc_pending",
            "message": "connector_authorized",
        }
        if isinstance(value, dict) and isinstance(value.get("sessionId"), str):
            heartbeat_payload["sessionId"] = value["sessionId"]
        _client(convex_url).mutation("publicApi:robotHeartbeat", heartbeat_payload)
        execution_result = None
        if observe_command:
            if drtc_client is None:
                raise ProductError("--observe-command requires --start-drtc so observations can reach the model.")
            if not isinstance(value, dict) or not isinstance(value.get("sessionId"), str):
                raise ProductError("Session authorization did not return a session id.")
            execution_result = run_robot_execution_loop(
                drtc_client=drtc_client,
                config=RobotExecutionConfig(
                    session_id=value["sessionId"],
                    deployment_id=deployment_id,
                    robot_id=robot_id,
                    mode=mode,
                    task=task,
                    max_steps=max_steps,
                    control_period_s=control_period_s,
                    observe_command=observe_command,
                    action_command=action_command,
                    safe_stop_command=safe_stop_command,
                    command_timeout_s=command_timeout_s,
                    safe_stop_timeout_s=safe_stop_timeout_s,
                    heartbeat=lambda event: _client(convex_url).mutation(
                        "publicApi:robotHeartbeat",
                        {
                            "apiKey": _api_key(api_key),
                            "robotId": robot_id,
                            "deploymentId": deployment_id,
                            "sessionId": event.get("session_id"),
                            "transport": event.get("transport"),
                            "message": event.get("message"),
                        },
                    ),
                    heartbeat_interval_s=heartbeat_interval,
                ),
            )
            payload["execution"] = {
                "steps": execution_result.steps,
                "appliedSteps": execution_result.applied_steps,
                "safeStops": execution_result.safe_stops,
                "errors": execution_result.errors,
            }
        _emit(
            payload,
            json_output=json_output,
            title="Robot connector authorized",
            lines=[
                "Robot connector authorized",
                "",
                f"Session ID: {_display_scalar('sessionId', value.get('sessionId') if isinstance(value, dict) else None)}",
                f"Mode: {mode}",
                f"Transport: {'DRTC sidecar active' if start_drtc else 'DRTC sidecar handoff pending'}",
            ],
        )
        if once or _json_enabled(json_output) or execution_result is not None:
            return
        while True:
            typer.echo(f"reflex connect: session active at {_format_local_datetime(datetime.now(timezone.utc))}")
            _client(convex_url).mutation("publicApi:robotHeartbeat", heartbeat_payload)
            time.sleep(max(1.0, heartbeat_interval))
    except KeyboardInterrupt:
        typer.echo("reflex connect: stopped")
    except ProductError as exc:
        _error(exc, json_output=json_output)
    finally:
        if drtc_client is not None:
            drtc_client.close()


def _require_readiness_passed(*, deployment_id: str, api_key: str, convex_url: str) -> None:
    result = _expect_public_ok(
        _client(convex_url).mutation(
            "publicApi:getDeployment",
            {"apiKey": _api_key(api_key), "deploymentId": deployment_id},
        ),
        label="publicApi:getDeployment response",
        action="Unable to load deployment readiness",
    )
    deployment = result.get("deployment") if isinstance(result, dict) else None
    status = deployment.get("status") if isinstance(deployment, dict) else None
    if status == "ready":
        return
    raise ProductError(
        "apply_actions blocked: deployment readiness has not passed "
        f"(deployment status={status!r}). Run `reflex doctor {deployment_id}` first, "
        "or pass --allow-unchecked to override (development only)."
    )


def _start_drtc_client_from_session(session: dict[str, JsonValue], *, sidecar_binary: str):
    prime_url = str(session.get("primeUrl") or "")
    parsed = parse.urlparse(prime_url)
    host = parsed.hostname or prime_url.removeprefix("https://").removeprefix("http://").split("/", 1)[0]
    if not host:
        raise ProductError("Session did not include a primeUrl host for DRTC.")
    DrtcSidecarClient, DrtcSidecarClientConfig = _load_drtc_sidecar()
    return DrtcSidecarClient(
        DrtcSidecarClientConfig(
            server_host=host,
            server_port=5555,
            binary_path=Path(sidecar_binary) if sidecar_binary else None,
        )
    )


def _load_drtc_sidecar():
    """Resolve the DRTC sidecar client from the installable extras or the monorepo checkout."""
    try:
        from reflex_inference.drtc_sidecar import (  # type: ignore[import-not-found]
            DrtcSidecarClient,
            DrtcSidecarClientConfig,
        )
        return DrtcSidecarClient, DrtcSidecarClientConfig
    except ImportError:
        pass
    import sys
    inference_root = Path(__file__).resolve().parents[3] / "inference"
    if not inference_root.exists():
        raise ProductError(
            "--start-drtc requires the DRTC sidecar. Install with "
            "`pip install 'reflex[inference]'`, or run from a monorepo checkout "
            "(expected sibling directory: inference/)."
        )
    if str(inference_root) not in sys.path:
        sys.path.insert(0, str(inference_root))
    try:
        from server.drtc_sidecar import (  # type: ignore[import-not-found]
            DrtcSidecarClient,
            DrtcSidecarClientConfig,
        )
    except ImportError as exc:
        raise ProductError(
            f"--start-drtc could not load the DRTC sidecar from the monorepo checkout: {exc}"
        ) from exc
    return DrtcSidecarClient, DrtcSidecarClientConfig


@RECEIPTS_COMMANDS.command("list", context_settings=HELP_CONTEXT)
def list_receipts_command(
    deployment_id: str = typer.Option("", "--deployment", help="Optional deployment id."),
    api_key: str = typer.Option("", help="API key. Defaults to REFLEX_API_KEY or saved login."),
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL or saved login."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    try:
        args: dict[str, JsonValue] = {"apiKey": _api_key(api_key)}
        if deployment_id:
            args["deploymentId"] = deployment_id
        value = _client(convex_url).mutation("publicApi:listDeploymentReceipts", args)
        result = _expect_public_ok(
            value,
            label="publicApi:listDeploymentReceipts response",
            action="Unable to list receipts",
        )
        _emit({"ok": True, "receipts": result}, json_output=json_output, title="Deployment receipts")
    except ProductError as exc:
        _error(exc, json_output=json_output)


def _authorize(
    *,
    artifact_id: str,
    deployment_id: str = "",
    robot_id: str = "",
    base_model: str,
    runtime: str,
    robot_type: str,
    action_adapter: str,
    mode: str,
    client_session_id: str,
    api_key: str,
    convex_url: str,
) -> JsonValue:
    if base_model != "pi0.5":
        raise ProductError("Only base model pi0.5 is supported by the product API.")
    if mode not in {"dry_run", "apply_actions"}:
        raise ProductError("--mode must be dry_run or apply_actions.")
    robot_type = robot_type.strip().lower().replace("-", "_") or DEFAULT_ROBOT_TYPE
    action_adapter = _normalize_action_adapter(action_adapter, robot_type=robot_type)
    args: dict[str, JsonValue] = {
        "apiKey": _api_key(api_key),
        "baseModel": "pi0.5",
        "robotType": robot_type,
        "actionAdapter": action_adapter,
    }
    if artifact_id:
        args["modelId"] = artifact_id
    if deployment_id:
        args["deploymentId"] = deployment_id
    if robot_id:
        args["robotId"] = robot_id
    if runtime:
        args["runtime"] = runtime
    args["mode"] = mode
    if client_session_id:
        args["clientSessionId"] = client_session_id
    return _expect_public_ok(
        _client(convex_url).mutation("publicApi:authorizeSession", args),
        label="publicApi:authorizeSession response",
        action="Unable to authorize inference session",
    )


@SESSIONS_COMMANDS.command("start", context_settings=HELP_CONTEXT)
def start_session(
    artifact_id: str = typer.Option("", "--artifact", help="Optional artifact/model id."),
    deployment_id: str = typer.Option("", "--deployment", help="Optional deployment id."),
    robot_id: str = typer.Option("", "--robot", help="Optional robot id."),
    base_model: str = typer.Option("pi0.5", help="Base model to serve."),
    runtime: str = typer.Option("", help="Optional runtime selector."),
    mode: str = typer.Option("dry_run", help="Session mode: dry_run or apply_actions."),
    client_session_id: str = typer.Option("", help="Optional client-provided session id."),
    api_key: str = typer.Option("", help="API key. Defaults to REFLEX_API_KEY or saved login."),
    convex_url: str = typer.Option("", help="Convex deployment URL. Defaults to REFLEX_CONVEX_URL or saved login."),
    json_output: bool = typer.Option(False, "--json", help="Emit structured JSON output."),
) -> None:
    try:
        value = _authorize(
            artifact_id=artifact_id,
            deployment_id=deployment_id,
            robot_id=robot_id,
            base_model=base_model,
            runtime=runtime,
            mode=mode,
            client_session_id=client_session_id,
            api_key=api_key,
            convex_url=convex_url,
        )
        _emit(
            {
                "ok": True,
                "session": value,
                "next": [
                    "Use the returned primeUrl/token with the robot daemon or SDK transport.",
                    "reflex sessions close <session-id>",
                ],
            },
            json_output=json_output,
            title="Robot session started",
        )
    except ProductError as exc:
        _error(exc, json_output=json_output)


def register_product_commands(app: typer.Typer) -> None:
    app.command("signup", context_settings=HELP_CONTEXT)(signup)
    app.command("login", context_settings=HELP_CONTEXT)(login)
    app.command("logout", context_settings=HELP_CONTEXT)(logout)
    app.command("whoami", context_settings=HELP_CONTEXT)(whoami)
    app.command("deploy", context_settings=HELP_CONTEXT)(deploy)
    app.command("doctor", context_settings=HELP_CONTEXT)(doctor)
    app.command("connect", context_settings=HELP_CONTEXT)(connect_robot_command)
    app.add_typer(DATASET_COMMANDS, name="datasets")
    app.add_typer(TRAINING_COMMANDS, name="training")
    app.add_typer(ARTIFACT_COMMANDS, name="artifacts")
    app.add_typer(INFERENCE_COMMANDS, name="inference")
    app.add_typer(SESSIONS_COMMANDS, name="sessions")
    app.add_typer(DEPLOYMENTS_COMMANDS, name="deployments")
    app.add_typer(ROBOTS_COMMANDS, name="robots")
    app.add_typer(RECEIPTS_COMMANDS, name="receipts")


def build_reflex_app() -> typer.Typer:
    app = typer.Typer(
        name="reflex",
        help="User-facing CLI for Reflex hosted robot workflows.",
        no_args_is_help=True,
        add_completion=False,
        context_settings=HELP_CONTEXT,
    )
    app.callback(invoke_without_command=True, context_settings=HELP_CONTEXT)(root_callback)
    register_product_commands(app)
    return app


def main_reflex() -> None:
    build_reflex_app()()