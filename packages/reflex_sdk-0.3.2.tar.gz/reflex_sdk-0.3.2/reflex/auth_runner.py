"""Authorize an inference session with Convex before a WebRTC connect.

PROD.2 (hq-qouv) — bolt-on to ``connect_runner.run_session`` that resolves
the rfx_* API key, calls ``publicApi:authorizeSession``, and returns a
:class:`SessionGrant` the transport can use to attach an
``Authorization: Bearer <token>`` header.

If REFLEX_API_KEY (or ~/.config/reflex/credentials.json) is NOT set, this
module is a no-op — the runner falls back to the yaml's target URL with
no auth header (dev/local mode, only works against workers with
``REFLEX_REQUIRE_SESSION_TOKEN=0``).

Once REFLEX_REQUIRE_SESSION_TOKEN=1 lands on prod workers, every connect
must go through this module first.
"""

from __future__ import annotations

import json
import os
import sys
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any


CONVEX_URL_DEFAULT = "https://api.tryreflex.ai"
USER_AGENT = "reflex-sdk-cli/0.2"


class AuthError(RuntimeError):
    """Authorize step failed; caller should bail."""


@dataclass(frozen=True)
class SessionGrant:
    session_token: str
    worker_url: str
    expires_at: int
    session_id: str
    base_model: str

    def auth_header(self) -> dict[str, str]:
        return {"authorization": f"Bearer {self.session_token}"}


def _resolve_api_key() -> str | None:
    """Resolve rfx_* api key from env or ~/.config/reflex/credentials.json."""
    val = (os.environ.get("REFLEX_API_KEY") or "").strip()
    if val:
        return val
    for path in (
        Path.home() / ".reflex" / "api_key",
        Path.home() / ".reflex" / "credentials",
        Path.home() / ".config" / "reflex" / "credentials.json",
    ):
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8").strip()
        if not text:
            continue
        if path.suffix == ".json" or text.startswith("{"):
            try:
                obj = json.loads(text)
                key = (obj.get("apiKey") or obj.get("api_key") or "").strip()
                if key:
                    return key
            except Exception:
                pass
        else:
            return text
    return None


def _convex_mutation(convex_url: str, path: str, args: dict, *, timeout: float = 30.0) -> dict:
    body = json.dumps({"path": path, "format": "json", "args": args}).encode("utf-8")
    req = urllib.request.Request(
        f"{convex_url.rstrip('/')}/api/mutation",
        data=body,
        method="POST",
        headers={"content-type": "application/json", "user-agent": USER_AGENT},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = json.loads(resp.read())
    except urllib.error.HTTPError as exc:
        raise AuthError(f"convex HTTP {exc.code}: {exc.read().decode()[:200]}") from exc
    if payload.get("status") != "success":
        raise AuthError(f"convex error: {json.dumps(payload)[:200]}")
    return payload["value"]


def maybe_authorize(
    *,
    base_model: str | None = None,
    robot_type: str | None = None,
    convex_url: str | None = None,
) -> SessionGrant | None:
    """Try to authorize a session; return None if no creds set (dev mode).

    Raises :class:`AuthError` if creds ARE set but the call fails — that's
    a real misconfiguration we should surface to the user.
    """
    api_key = _resolve_api_key()
    if not api_key:
        return None

    base_model = base_model or os.environ.get("REFLEX_BASE_MODEL") or "molmoact2-bimanualyam"
    robot_type = robot_type or os.environ.get("REFLEX_ROBOT_TYPE") or "yam_bimanual"
    convex_url = (
        convex_url
        or os.environ.get("REFLEX_CONVEX_URL")
        or CONVEX_URL_DEFAULT
    )

    t0 = time.perf_counter()
    result = _convex_mutation(
        convex_url,
        "publicApi:authorizeSession",
        {"apiKey": api_key, "baseModel": base_model, "robotType": robot_type},
    )
    dt_ms = (time.perf_counter() - t0) * 1000

    if not result.get("ok"):
        reason = result.get("reason", "unknown")
        hint = {
            "unknown_key": "API key not recognized — mint a new one at https://app.tryreflex.ai/keys",
            "balance_too_low": "org balance < $5 — top up at https://app.tryreflex.ai/billing",
            "no_inference_node_available": f"no worker live for baseModel={base_model!r}",
        }.get(reason, "")
        raise AuthError(f"authorize rejected: reason={reason} {hint}")

    print(
        f"[reflex] authorized session in {dt_ms:.0f} ms — base_model={base_model} expires_at={result['expiresAt']}",
        file=sys.stderr, flush=True,
    )
    return SessionGrant(
        session_token=result["token"],
        worker_url=result.get("primeUrl") or result.get("workerUrl") or "",
        expires_at=int(result["expiresAt"]),
        session_id=result["sessionId"],
        base_model=result.get("model") or base_model,
    )
