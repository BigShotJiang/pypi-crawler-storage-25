"""IR → output-format serializers."""
