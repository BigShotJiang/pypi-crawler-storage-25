import ctypes
import time
import numpy as np
import os

class macss:
    def __init__(self, monitor=None, exclude_self=True, exclude_window_name=""):
        current_dir = os.path.dirname(os.path.abspath(__file__))
        lib_path = os.path.join(current_dir, 'libScreenCapture.dylib')
        
        self.lib = ctypes.CDLL(lib_path)
        self.lib.init_capture.argtypes = [ctypes.POINTER(ctypes.c_int32), ctypes.POINTER(ctypes.c_int32)]
        
        self.lib.start_stream.argtypes = [
            ctypes.POINTER(ctypes.c_uint8), 
            ctypes.POINTER(ctypes.c_uint64), 
            ctypes.POINTER(ctypes.c_int32),
            ctypes.c_int32, ctypes.c_int32, ctypes.c_int32, ctypes.c_int32, 
            ctypes.c_int32,
            ctypes.c_char_p
        ]
        
        full_w = ctypes.c_int32()
        full_h = ctypes.c_int32()
        self.lib.init_capture(ctypes.byref(full_w), ctypes.byref(full_h))
        
        if monitor:
            self.crop_y = monitor.get("top", 0)
            self.crop_x = monitor.get("left", 0)
            self.w = monitor.get("width", full_w.value)
            self.h = monitor.get("height", full_h.value)
        else:
            self.crop_x, self.crop_y = 0, 0
            self.w, self.h = full_w.value, full_h.value
            
        self.exclude_pid = os.getpid() if exclude_self else 0
        self.exclude_window_name_c = exclude_window_name.encode('utf-8') if exclude_window_name else None
        
        max_size = self.w * self.h * 8 
        self.buffer = np.empty(max_size, dtype=np.uint8)
        self.ptr = self.buffer.ctypes.data_as(ctypes.POINTER(ctypes.c_uint8))
        
        self.frame_counter = ctypes.c_uint64(0)
        self.bpr = ctypes.c_int32(0)
        self.raw_image_view = None

    def __enter__(self):
        self.lib.start_stream(
            self.ptr, 
            ctypes.byref(self.frame_counter), 
            ctypes.byref(self.bpr),
            self.crop_x, self.crop_y, self.w, self.h,
            self.exclude_pid,
            self.exclude_window_name_c
        )
        
        while self.frame_counter.value == 0:
            time.sleep(0.01)
            
        frame_size = self.h * self.bpr.value
        self.raw_image_view = self.buffer[:frame_size].reshape((self.h, self.bpr.value // 4, 4))
        
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.lib.stop_stream()

    def grab(self):
        return self.raw_image_view[:, :self.w, :]