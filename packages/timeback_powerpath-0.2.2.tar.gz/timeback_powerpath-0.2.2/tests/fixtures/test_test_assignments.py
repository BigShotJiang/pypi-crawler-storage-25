"""Fixture-driven tests for PowerPath test assignments resource."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_resource_fixture_test
from timeback_powerpath.lib.testing import create_recording_transport
from timeback_powerpath.resources.test_assignments import (
    TestAssignmentsResource as PowerPathTestAssignmentsResource,
)

FIXTURES_DIR = fixtures_dir("powerpath", "test-assignments")


def _setup(
    fail_request: dict[str, object] | None, transport_config: dict[str, object] | None
) -> dict[str, object]:
    transport = create_recording_transport(fail_request, transport_config)
    resource = PowerPathTestAssignmentsResource(transport)
    setattr(resource, "import", resource.import_assignments)
    return {"resource": resource, "calls": transport.calls}


test_powerpath_test_assignments_fixtures = make_resource_fixture_test(
    name="powerpath > test-assignments",
    fixtures_dir=FIXTURES_DIR,
    setup=_setup,
)
