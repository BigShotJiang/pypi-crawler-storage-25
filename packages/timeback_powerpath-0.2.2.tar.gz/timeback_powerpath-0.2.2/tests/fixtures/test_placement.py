"""Fixture-driven tests for PowerPath placement resource."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_resource_fixture_test
from timeback_powerpath.lib.testing import create_recording_transport
from timeback_powerpath.resources.placement import PlacementResource

FIXTURES_DIR = fixtures_dir("powerpath", "placement")


def _setup(
    fail_request: dict[str, object] | None, transport_config: dict[str, object] | None
) -> dict[str, object]:
    transport = create_recording_transport(fail_request, transport_config)
    return {"resource": PlacementResource(transport), "calls": transport.calls}


test_powerpath_placement_fixtures = make_resource_fixture_test(
    name="powerpath > placement",
    fixtures_dir=FIXTURES_DIR,
    setup=_setup,
)
