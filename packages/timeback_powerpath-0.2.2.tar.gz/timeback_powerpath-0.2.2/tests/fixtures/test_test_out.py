"""Fixture-driven tests for PowerPath test out resource."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_resource_fixture_test
from timeback_powerpath.lib.testing import create_recording_transport
from timeback_powerpath.resources.test_out import TestOutResource as PowerPathTestOutResource

FIXTURES_DIR = fixtures_dir("powerpath", "test-out")


def _setup(
    fail_request: dict[str, object] | None, transport_config: dict[str, object] | None
) -> dict[str, object]:
    transport = create_recording_transport(fail_request, transport_config)
    return {"resource": PowerPathTestOutResource(transport), "calls": transport.calls}


test_powerpath_test_out_fixtures = make_resource_fixture_test(
    name="powerpath > test-out",
    fixtures_dir=FIXTURES_DIR,
    setup=_setup,
)
