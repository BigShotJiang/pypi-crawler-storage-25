"""Native validation tests for PowerPath resources."""

from __future__ import annotations

import pytest

from timeback_common import InputValidationError
from timeback_powerpath.resources.assessment import AssessmentResource
from timeback_powerpath.resources.lesson_plans import LessonPlansResource
from timeback_powerpath.resources.placement import PlacementResource
from timeback_powerpath.resources.syllabus import SyllabusResource
from timeback_powerpath.resources.test_assignments import (
    TestAssignmentsResource as PowerPathTestAssignmentsResource,
)


class _MockPaths:
    base = "/powerpath"


class _MockTransport:
    def __init__(self) -> None:
        self.request_count = 0
        self.paths = _MockPaths()
        self.base_url = "https://example.test"

    async def get(
        self, _path: str, *, params: dict[str, object] | None = None
    ) -> dict[str, object]:
        del params
        self.request_count += 1
        raise RuntimeError("request should not be called")

    async def post(self, _path: str, _data: object = None) -> dict[str, object]:
        self.request_count += 1
        raise RuntimeError("request should not be called")

    async def put(self, _path: str, _data: object = None) -> dict[str, object]:
        self.request_count += 1
        raise RuntimeError("request should not be called")

    async def delete(self, _path: str) -> None:
        self.request_count += 1
        raise RuntimeError("request should not be called")


@pytest.mark.asyncio
async def test_lesson_plan_create_validates_before_request() -> None:
    transport = _MockTransport()
    with pytest.raises(InputValidationError):
        await LessonPlansResource(transport).create({"courseId": "", "userId": "user-1"})  # type: ignore[arg-type]
    assert transport.request_count == 0


@pytest.mark.asyncio
async def test_assessment_progress_validates_before_request() -> None:
    transport = _MockTransport()
    with pytest.raises(InputValidationError):
        await AssessmentResource(transport).get_assessment_progress(  # type: ignore[arg-type]
            {"student": "", "lesson": "lesson-1"}
        )
    assert transport.request_count == 0


@pytest.mark.asyncio
async def test_placement_validates_before_request() -> None:
    transport = _MockTransport()
    with pytest.raises(InputValidationError):
        await PlacementResource(transport).get_next_placement_test(
            {"student": "", "subject": "Math"}
        )  # type: ignore[arg-type]
    assert transport.request_count == 0


@pytest.mark.asyncio
async def test_test_assignments_validates_before_request() -> None:
    transport = _MockTransport()
    with pytest.raises(InputValidationError):
        await PowerPathTestAssignmentsResource(transport).create(  # type: ignore[arg-type]
            {"student": "", "subject": "Math", "grade": 4}
        )
    assert transport.request_count == 0


@pytest.mark.asyncio
async def test_syllabus_validates_before_request() -> None:
    transport = _MockTransport()
    with pytest.raises(InputValidationError):
        await SyllabusResource(transport).get("course-1", {"status": "bad"})  # type: ignore[arg-type]
    assert transport.request_count == 0
