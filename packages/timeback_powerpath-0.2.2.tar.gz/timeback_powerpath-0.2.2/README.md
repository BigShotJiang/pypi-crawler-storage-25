# timeback-powerpath

Python client for the Timeback PowerPath adaptive learning API.

## Installation

```bash
pip install timeback-powerpath
```

## Quick Start

```python
from timeback_powerpath import PowerPathClient

async def main():
    client = PowerPathClient(
        env="staging",
        client_id="your-client-id",
        client_secret="your-client-secret",
    )

    # List test assignments
    result = await client.test_assignments.list({"student": "student-id"})

    # Get assessment progress
    progress = await client.assessments.get_assessment_progress({
        "student": "student-id",
        "lesson": "lesson-id",
    })

    await client.close()
```

## Resources

- `client.assessments` - Tests, attempts, and assessment responses
- `client.test_assignments` - Test assignment CRUD and bulk operations
- `client.placement` - Placement testing and progress
- `client.screening` - Screening sessions and results
- `client.lesson_plans` - Lesson plan management and course progress
- `client.syllabus` - Course syllabus retrieval
