"""
PowerPath Base Types

Common literal types and enums for PowerPath API responses.
"""

from __future__ import annotations

from typing import Literal

TestAssignmentStatus = Literal[
    "assigned",
    "in_progress",
    "completed",
    "failed",
    "expired",
    "cancelled",
]

PowerPathLessonType = Literal[
    "powerpath-100",
    "quiz",
    "test-out",
    "placement",
    "unit-test",
    "alpha-read-article",
]

QuizLikeLessonType = Literal["quiz", "test-out", "placement", "unit-test"]

ExternalTestCapableLessonType = Literal["test-out", "placement", "unit-test"]

ScoreStatus = Literal[
    "exempt",
    "fully graded",
    "not submitted",
    "partially graded",
    "submitted",
]

PowerPathQuestionDifficulty = Literal["easy", "medium", "hard"]

LessonPlanOperationType = Literal[
    "set-skipped",
    "add-custom-resource",
    "move-item-before",
    "move-item-after",
    "move-item-to-start",
    "move-item-to-end",
    "change-item-parent",
]

ToolProvider = Literal["edulastic", "mastery-track"]

ScreeningSubject = Literal["Math", "Reading", "Language", "Science"]

ResourceStatus = Literal["active", "tobedeleted"]

TimebackSubject = Literal[
    "Reading",
    "Language",
    "Vocabulary",
    "Social Studies",
    "Writing",
    "Science",
    "FastMath",
    "Math",
    "None",
    "Other",
]

TimebackGrade = Literal[-1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]


__all__ = [
    "ExternalTestCapableLessonType",
    "LessonPlanOperationType",
    "PowerPathLessonType",
    "PowerPathQuestionDifficulty",
    "QuizLikeLessonType",
    "ResourceStatus",
    "ScoreStatus",
    "ScreeningSubject",
    "TestAssignmentStatus",
    "TimebackGrade",
    "TimebackSubject",
    "ToolProvider",
]
