"""
Render Config Resource

PowerPath custom renderer configuration operations.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any
from urllib.parse import quote

from timeback_common import serialize_input, validate_non_empty_string, validate_with_schema

from ..types.inputs import RenderConfigUpsertInput
from ..types.responses import (
    RenderConfigDeleteResponse,
    RenderConfigGetResponse,
    RenderConfigUpsertResponse,
)

if TYPE_CHECKING:
    from ..lib.transport import Transport


class RenderConfigResource:
    """Render config resource for managing custom renderer configurations on courses."""

    def __init__(self, transport: Transport) -> None:
        self._transport = transport

    @property
    def _base_path(self) -> str:
        return self._transport.paths.base

    async def upsert(
        self, input: RenderConfigUpsertInput | dict[str, Any]
    ) -> RenderConfigUpsertResponse:
        """
        Upsert render config for one or more courses.

        Args:
            input: Render config data including course_ids, renderer_id, and renderer_url

        Returns:
            List of updated course IDs
        """
        validate_with_schema(RenderConfigUpsertInput, input, "render config upsert")
        body = await self._transport.put(
            f"{self._base_path}/render-config/",
            serialize_input(input, RenderConfigUpsertInput),
        )
        return RenderConfigUpsertResponse.model_validate(body)

    async def get(self, course_id: str) -> RenderConfigGetResponse:
        """
        Get render config for a course.

        Args:
            course_id: The course ID to look up

        Returns:
            The render config for the course
        """
        validate_non_empty_string(course_id, "course_id")
        body = await self._transport.get(
            f"{self._base_path}/render-config/{quote(course_id, safe='')}"
        )
        return RenderConfigGetResponse.model_validate(body)

    async def delete(self, course_id: str) -> RenderConfigDeleteResponse:
        """
        Delete render config for a course.

        Args:
            course_id: The course ID whose render config to delete

        Returns:
            Confirmation with the deleted course ID
        """
        validate_non_empty_string(course_id, "course_id")
        body = await self._transport.delete(
            f"{self._base_path}/render-config/{quote(course_id, safe='')}"
        )
        return RenderConfigDeleteResponse.model_validate(body)
