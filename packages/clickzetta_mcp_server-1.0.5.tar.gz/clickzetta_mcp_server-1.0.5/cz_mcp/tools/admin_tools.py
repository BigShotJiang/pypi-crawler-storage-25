from cz_mcp.core.tool_registry import Tool
from cz_mcp.handlers.object_management import handle_show_object_list


def get_admin_tools():
    return [
        Tool(
            name="LH-show_object_list",
            description=(
                "Lakehouse SDK low-level query tool that bypasses Studio to directly query the Lakehouse SQL engine.\n"
                "Lists Lakehouse database objects without needing to construct SQL, avoiding query failures due to SQL "
                "dialect issues. Supports intelligent filtering, statistical analysis, and filter suggestions. JOBS "
                "refers to Lakehouse SQL job concept, not to be confused with Studio tasks. If the user only needs to "
                "switch objects without actually querying, just return the recorded information without executing USE. "
                "You should use precise queries as much as possible to avoid too many objects.\n"
                "Main Features:\n"
                "• Smart Analysis: Analyzes all data and suggests useful filters\n"
                "• Accurate Statistics: Shows real counts in the database, not just displayed records\n"
                "• Filter Discovery: Informs about available fields and their possible values\n"
                "• Smart Suggestions: Recommends filters for hidden important objects\n"
                "• Two-Step Workflow: First call shows overview and suggestions, second call applies precise filtering\n"
                "Default Limits: FUNCTIONS(25), TABLES(50), SCHEMAS(20), maximum 100"
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "show_command": {
                        "type": "string",
                        "description": (
                            "Legacy parameter (backward compatible). You can use the following syntax to construct the SHOW command:\n"
                            "SHOW <object_type_plural>  [ IN <scope_object> ] [ LIKE '<pattern>' | WHERE <expr>] [LIMIT num];\n"
                            "Examples: SHOW tables LIKE 'user%'; SHOW tables WHERE is_view=true; SHOW tables IN public; SHOW volumes WHERE workspace_name='public'; SHOW jobs in VCLUSTER default;"
                        )
                    },
                    "object_type": {
                        "type": "string",
                        "enum": ["WORKSPACES", "TABLES", "VIEWS", "SCHEMAS", "CATALOGS", "FUNCTIONS",
                                 "EXTERNAL FUNCTIONS", "VOLUMES",
                                 "CONNECTIONS", "VCLUSTERS", "JOBS", "PIPES", "USERS",
                                 "ROLES", "GRANTS", "SHARES", "TABLE STREAMS", "DYNAMIC TABLES",
                                 "MATERIALIZED VIEWS", "EXTERNAL TABLES", "EXTERNAL SCHEMAS", "NETWORK POLICY"],
                        "description": "Type of objects to list (recommended over show_command)"
                    },
                    "in_schema": {
                        "type": "string",
                        "description": "Optional schema name to filter objects within. Note: VOLUMES does not support IN syntax currently, use WHERE workspace_name = 'schema' instead"
                    },
                    "like_pattern": {
                        "type": "string",
                        "description": "Optional LIKE pattern for filtering object names (e.g., 'user%')"
                    },
                    "where_condition": {
                        "type": "string",
                        "description": "Optional WHERE clause for advanced filtering (e.g., 'is_external = true')"
                    },
                    "table_type_filters": {
                        "type": "object",
                        "description": "Quick filters for table types (only for TABLES)",
                        "properties": {
                            "is_view": {"type": "boolean", "description": "Filter views"},
                            "is_external": {"type": "boolean", "description": "Filter external tables"},
                            "is_dynamic": {"type": "boolean", "description": "Filter dynamic tables"},
                            "is_stream": {"type": "boolean", "description": "Filter table streams"}
                        }
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of results to return (default varies by object type)",
                        "minimum": 1,
                        "maximum": 20
                    },
                    "smart_defaults": {
                        "type": "boolean",
                        "default": True,
                        "description": "Apply smart defaults (e.g., auto-limit for JOBS)"
                    }
                },
                "required": ["object_type"],  # 修复：object_type是必选参数
            },
            handler=handle_show_object_list,
            tags=["read"],
            samples=[
                {
                    "description": "List all workspaces",
                    "query": {
                        "object_type": "WORKSPACES"
                    }
                },
                {
                    "description": "List tables in public schema",
                    "query": {
                        "object_type": "TABLES",
                        "in_schema": "public"
                    }
                },
                {
                    "description": "Find tables with names starting with 'user'",
                    "query": {
                        "object_type": "TABLES",
                        "like_pattern": "user%"
                    }
                }
            ],
        ),
    ]

