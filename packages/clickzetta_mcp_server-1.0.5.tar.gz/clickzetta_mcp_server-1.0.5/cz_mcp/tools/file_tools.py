"""
Studio-specific tools for MCP Studio server
Handles Studio API interactions and project management
"""

import json
import logging
from datetime import datetime
from enum import IntEnum
from typing import List, Optional, Any, Coroutine

from mcp.types import TextContent, EmbeddedResource

from cz_mcp.handlers.ide_admin_server import create_task
from cz_mcp.handlers.ide_admin_server import get_task_detail
from cz_mcp.handlers.ide_admin_server import list_files
from cz_mcp.handlers.ide_admin_server import list_folders
from cz_mcp.handlers.ide_admin_server import save_configuration
from cz_mcp.handlers.ide_admin_server import save_content
from cz_mcp.handlers.ide_admin_server import submit_task
from cz_mcp.handlers.ide_admin_server import get_configuration_detail
from cz_mcp.handlers.ide_admin_server import generate_instance_time_list
from ..common.redirect_url_utils import _build_ide_studio_url
from ..common.file_type import FILE_TYPE_MAP, OFFLINE_FILE_TYPE_MAP, REALTIME_FILE_TYPE_MAP, FileType
from ..common.task_type import OFFLINE_TASK_TYPE_MAP, REALTIME_TASK_TYPE_MAP, TASK_FILE_TYPE_MAPPING, TaskType
from ..common.utilities import ResponseBuilder
from ..core import StudioConfig, MCPServerCore
from ..core.tool_registry import Tool
from ..handlers.login_server import get_current_user
from ..utils.config_utils import read_api
from cz_mcp.utils.datasource_utils import (
    get_datasource_by_name, check_table_exists, create_sink_table_from_source, integration_generator,
    create_schema_if_not_exists
)

from loguru import logger

from ..utils.cron_expression_adapter import convert_agent_cron

task_type_desc = "Available offline task types:\n"
task_type_desc += "\n".join([f"  - {int(ft)}: {name}" for ft, name in sorted(OFFLINE_TASK_TYPE_MAP.items())])
task_type_desc += "Available realtime task types:\n"
task_type_desc += "\n".join([f"  - {int(ft)}: {name}" for ft, name in sorted(REALTIME_TASK_TYPE_MAP.items())])


def _get_task_param_doc_url() -> str:
    """
    Get task parameter documentation URL from configuration
    Returns the configured documentation URL or a default if not found
    """
    try:
        doc_url = read_api("TASK_PARAM_DOC")
        return doc_url if doc_url else "https://yunqi.tech/documents/task_param"
    except Exception as e:
        logger.warning(f"Failed to read TASK_PARAM_DOC from config: {e}, using default URL")
        return "https://yunqi.tech/documents/task_param"


def _format_iso_start_of_day(value: Optional[str] = None) -> str:
    """
    Normalize date-like inputs to YYYY-MM-DDT00:00:00.000Z.

    Accepted inputs:
    - None: uses the current local date
    - YYYY-MM-DD
    - ISO datetime strings such as YYYY-MM-DDTHH:MM:SS(.sss)Z
    """
    if not value:
        return datetime.now().strftime("%Y-%m-%dT00:00:00.000Z")

    normalized = value.strip()
    if normalized.endswith("Z"):
        normalized = normalized[:-1] + "+00:00"

    for fmt in ("%Y-%m-%d",):
        try:
            parsed = datetime.strptime(value.strip(), fmt)
            return parsed.strftime("%Y-%m-%dT00:00:00.000Z")
        except ValueError:
            pass

    try:
        parsed = datetime.fromisoformat(normalized)
        return parsed.strftime("%Y-%m-%dT00:00:00.000Z")
    except ValueError:
        logger.warning(f"Unable to normalize date value '{value}', keeping original")
        return value


def _format_iso_end_of_day(value: Optional[str] = None) -> str:
    """
    Normalize date-like inputs to YYYY-MM-DDT23:59:59.000Z.

    Accepted inputs:
    - None: uses the current local date
    - YYYY-MM-DD
    - ISO datetime strings such as YYYY-MM-DDTHH:MM:SS(.sss)Z
    """
    if not value:
        return datetime.now().strftime("%Y-%m-%dT23:59:59.000Z")

    normalized = value.strip()
    if normalized.endswith("Z"):
        normalized = normalized[:-1] + "+00:00"

    for fmt in ("%Y-%m-%d",):
        try:
            parsed = datetime.strptime(value.strip(), fmt)
            return parsed.strftime("%Y-%m-%dT23:59:59.000Z")
        except ValueError:
            pass

    try:
        parsed = datetime.fromisoformat(normalized)
        return parsed.strftime("%Y-%m-%dT23:59:59.000Z")
    except ValueError:
        logger.warning(f"Unable to normalize end-of-day value '{value}', keeping original")
        return value


def _normalize_schedule_clock(value: Optional[str], default_value: str, field_name: str) -> str:
    """
    Normalize schedule clock value to HH:MM.
    """
    if not value:
        return default_value

    normalized = str(value).strip()
    for fmt in ("%H:%M", "%H:%M:%S"):
        try:
            parsed = datetime.strptime(normalized, fmt)
            return parsed.strftime("%H:%M")
        except ValueError:
            pass

    try:
        parsed = datetime.fromisoformat(normalized.replace("Z", "+00:00"))
        return parsed.strftime("%H:%M")
    except ValueError as exc:
        raise ValueError(
            f"Invalid {field_name}: '{value}'. Expected HH:MM format, for example '00:00'."
        ) from exc


def convert_task_detail_fields(api_data: dict) -> dict:
    """
    Convert API response fields for task detail to tool naming convention.

    Field mappings:
    - id -> task_id
    - tenantId -> tenant_id
    - userId -> user_id
    - projectId -> project_id
    - dataFolderId -> folder_id
    - fileCreateType -> file_create_type
    - dataFileName -> task_name
    - fileType -> task_type (converted from FileType to TaskType)
    - ownerCnName -> owner_cn_name
    - ownerEnName -> owner_en_name
    - lastEditTime -> last_edit_time
    - lastEditUser -> last_edit_user
    - fileFlowStatus -> file_flow_status
    - showFileStatusName -> show_file_status_name
    - fileStatus -> file_status
    - currentVersion -> current_version
    - fileContent -> task_content
    - fileDescription -> task_description
    - createdBy -> created_by
    - createdTime -> created_time
    - updatedBy -> updated_by
    - updatedTime -> updated_time
    - deployStatus -> deploy_status
    - workspaceId -> workspace_id
    - defaultSchemaName -> default_schema_name
    - defaultVcName -> default_vc_name
    - isLock -> is_lock
    - lockUserName -> lock_user_name
    - lockTime -> lock_time
    - paramValueList -> param_value_list
    - executeParam -> execute_param
    - hasConfig -> has_config
    - datasourceId -> datasource_id
    - dsType -> ds_type
    - sessionSchemaName -> session_schema_name
    - cdcTaskId -> cdc_task_id
    - groupId -> group_id
    - instanceName -> instance_name
    - multiDataSource -> multi_data_source
    - nodeId -> node_id
    - adhocConfigs -> adhoc_configs

    Args:
        api_data: Dictionary from API response

    Returns:
        Dictionary with converted field names
    """
    if api_data is None:
        return {}
    field_mapping = {
        # Core fields
        "id": "task_id",
        "tenantId": "tenant_id",
        "userId": "user_id",
        "projectId": "project_id",
        "location": "location",
        "dataFolderId": "folder_id",
        "dataFileName": "task_name",
        "ownerCnName": "owner_cn_name",
        "ownerEnName": "owner_en_name",

        # Time fields
        "lastEditTime": "last_edit_time",
        "lastEditUser": "last_edit_user",
        "createdBy": "created_by",
        "createdTime": "created_time",
        "updatedBy": "updated_by",
        "updatedTime": "updated_time",
        "lockTime": "lock_time",

        # Status fields
        "fileFlowStatus": "task_edit_state",
        "showFileStatusName": "show_file_status_name",

        "lockUserName": "lock_user_name",
        "hasConfig": "has_config",

        # Content and version fields
        "currentVersion": "current_version",
        "fileContent": "task_content",
        "fileDescription": "task_description",
        "paramValueList": "param_value_list",
        "executeParam": "execute_param",

        # Configuration fields
        "workspaceId": "workspace_id",
        "defaultSchemaName": "default_schema_name",
        "defaultVcName": "default_vc_name",
        "datasourceId": "datasource_id",
        "dsType": "ds_type",
        "sessionSchemaName": "session_schema_name",
        "cdcTaskId": "cdc_task_id",
        "groupId": "group_id",
        "instanceName": "instance_name",
        "multiDataSource": "multi_data_source",
        "nodeId": "node_id",
        "adhocConfigs": "adhoc_configs",
    }

    converted = {}
    for key, value in api_data.items():
        # Only include fields that are in the mapping, skip others
        if key in field_mapping:
            new_key = field_mapping[key]
            converted[new_key] = value
        elif key == "fileType":
            # Special handling: convert FileType to TaskType
            try:
                task_type = _convert_file_type_to_task_type(value)
                converted["task_type"] = task_type
            except ValueError:
                # If conversion fails, skip this field
                logger.warning(f"Failed to convert fileType {value} to taskType, skipping")

    return converted


def convert_configuration_detail_fields(api_data: dict) -> dict:
    """
    Convert configuration detail response to snake_case and prepare save_task_configuration payload.
    """
    if api_data is None:
        return {}

    converted = {}

    field_mapping = {
        "projectId": "project_id",
        "dataFileId": "data_file_id",
        "dataFileVersion": "data_file_version",
        "resourceGroupId": "resource_group_id",
        "executeParam": "execute_param",
        "scheduleConfigType": "schedule_config_type",
        "retryIntervalTime": "retry_interval_time",
        "retryIntervalTimeUnit": "retry_interval_time_unit",
        "retryCount": "retry_count",
        "scheduleRateType": "schedule_rate_type",
        "scheduleType": "schedule_type",
        "rerunProperty": "rerun_property",
        "selfDependsJob": "self_depends_job",
        "triggerType": "trigger_type",
        "taskPriority": "task_priority",
        "activeStartTime": "active_start_time",
        "activeEndTime": "active_end_time",
        "ownerCnName": "owner_cn_name",
        "ownerEnName": "owner_en_name",
        "fileOutputTableDTOS": "file_output_table_dtos",
        "paramValueList": "param_value_list",
        "dataFileDependencyDTOS": "data_file_dependency_dtos",
        "fileDescription": "file_description",
        "dataFileName": "data_file_name",
        "fileCreateType": "file_create_type",
        "scheduleCreatedType": "schedule_created_type",
        "fileType": "file_type",
        "cronExpress": "cron_express",
        "connectionParam": "connection_param",
        "schemaName": "schema_name",
        "adhocVcCode": "adhoc_vc_code",
        "adhocVcId": "adhoc_vc_id",
        "etlVcCode": "etl_vc_code",
        "etlVcId": "etl_vc_id",
        "executeTimeout": "execute_timeout",
        "executeTimeoutUnit": "execute_timeout_unit",
        "fileContent": "file_content",
        "dataConfiguration": "data_configuration",
        "configProperties": "config_properties",
        "submitTime": "submit_time",
        "datasourceId": "datasource_id",
        "dsType": "ds_type",
        "sessionSchemaName": "session_schema_name",
        "dependencyTimeout": "dependency_timeout",
        "dependencyTimeoutUnit": "dependency_timeout_unit",
        "instanceName": "instance_name",
        "multiDataSource": "multi_data_source",
        "nodeId": "node_id",
        "useFlowConfig": "use_flow_config",
    }

    # Apply field mapping
    for old_key, new_key in field_mapping.items():
        if old_key in api_data:
            value = api_data.get(old_key)
            # Special handling for activeStartTime and activeEndTime
            if old_key in ("activeStartTime", "activeEndTime") and value:
                # Parse yyyy-MM-dd format and convert to yyyy-MM-dd'T'HH:mm:ss.SSS'Z' format
                date_obj = datetime.strptime(value, "%Y-%m-%d")
                converted[new_key] = date_obj.strftime("%Y-%m-%dT%H:%M:%S.000Z")
            elif old_key == "fileType" and value is not None:
                try:
                    converted["task_type"] = _convert_file_type_to_task_type(value)
                except ValueError:
                    logger.warning(f"Failed to convert fileType {value} to task_type, keeping raw file_type")
                    converted[new_key] = value
            else:
                converted[new_key] = value

    # Parse configProperties if present
    config_props_raw = api_data.get("configProperties")
    parsed_config_props = None
    if config_props_raw:
        if isinstance(config_props_raw, str):
            try:
                parsed_config_props = json.loads(config_props_raw)
            except Exception:
                parsed_config_props = config_props_raw
        elif isinstance(config_props_raw, dict):
            parsed_config_props = config_props_raw
    converted["config_properties_parsed"] = parsed_config_props

    # Convert dependency DTOs to task_dependencies for save_task_configuration_tool
    dependencies = api_data.get("dataFileDependencyDTOS") or []
    task_dependencies = []
    if isinstance(dependencies, list):
        for dep in dependencies:
            if not isinstance(dep, dict):
                continue
            task_dependencies.append({
                "dependency_task_id": dep.get("dependencyFileId") or dep.get("dataFileId"),
                "dependency_task_name": dep.get("dependencyFileName") or dep.get("dataFileName"),
                "dep_strategy": dep.get("depStrategy", dep.get("dep_strategy", 0))
            })
    converted["task_dependencies"] = task_dependencies

    # Build a payload that matches save_task_configuration_tool inputs
    save_payload = {
        "task_id": api_data.get("data_file_id"),
        "cron_express": converted.get("cron_express"),
        "schedule_start_time": parsed_config_props.get("scheduleStartTime") if isinstance(parsed_config_props, dict) else None,
        "schedule_end_time": parsed_config_props.get("scheduleEndTime") if isinstance(parsed_config_props, dict) else None,
        "active_start_time": converted.get("active_start_time"),
        "active_end_time": converted.get("active_end_time"),
        "retry_count": converted.get("retry_count"),
        "retry_interval_time": converted.get("retry_interval_time"),
        "retry_interval_time_unit": converted.get("retry_interval_time_unit"),
        "rerun_property": converted.get("rerun_property"),
        "self_depends_job": converted.get("self_depends_job"),
        "schema_name": converted.get("schema_name"),
        "etl_vc_code": converted.get("etl_vc_code"),
        "etl_vc_id": converted.get("etl_vc_id"),
        "task_dependencies": task_dependencies,
        "exclude_time_ranges": parsed_config_props.get("excludeTimeRanges") if isinstance(parsed_config_props, dict) else None
    }
    # Remove None values for cleanliness
    converted["save_task_configuration_input"] = {
        k: v for k, v in save_payload.items() if v is not None
    }

    return converted

def _convert_task_type_to_file_type(task_type: int) -> int:
    """
    Convert TaskType (int) to FileType (int).

    Args:
        task_type: TaskType enum value as integer

    Returns:
        FileType enum value as integer

    Raises:
        ValueError: If task_type is invalid or has no corresponding FileType mapping
    """
    try:
        task_type_enum = TaskType(task_type)
        file_type_enum = TASK_FILE_TYPE_MAPPING.get(task_type_enum)
        if file_type_enum is None:
            raise ValueError(f"TaskType {task_type} has no corresponding FileType mapping")
        return int(file_type_enum)
    except ValueError as e:
        raise ValueError(f"Invalid task_type {task_type}: {str(e)}")


def _convert_file_type_to_task_type(file_type: int) -> int:
    """
    Convert FileType (int) back to TaskType (int).

    Args:
        file_type: FileType enum value as integer

    Returns:
        TaskType enum value as integer

    Raises:
        ValueError: If file_type is invalid or has no corresponding TaskType mapping
    """
    try:
        file_type_enum = FileType(file_type)
        # Create reverse mapping
        file_to_task_mapping = {v: k for k, v in TASK_FILE_TYPE_MAPPING.items()}
        task_type_enum = file_to_task_mapping.get(file_type_enum)
        if task_type_enum is None:
            raise ValueError(f"FileType {file_type} has no corresponding TaskType mapping")
        return int(task_type_enum)
    except ValueError as e:
        raise ValueError(f"Invalid file_type {file_type}: {str(e)}")


async def handle_create_task(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    Create tasl in Clickzetta Studio
    """
    if arguments is None:
        arguments = {}

    try:
        # Extract parameters
        task_type = arguments.get("task_type")

        # Convert TaskType (int) to FileType (int)
        try:
            file_type = _convert_task_type_to_file_type(task_type)
        except ValueError as e:
            error_response = {
                "success": False,
                "message": f"Invalid task_type {task_type}: {str(e)}",
                "error_type": "InvalidTaskType"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        created_by = arguments.get("created_by")
        task_name = arguments.get("task_name")
        task_description = arguments.get("task_description")
        data_folder_id = arguments.get("data_folder_id")
        # Get auth context from server core
        config = studio_config

        # Use config project ID if not provided
        project_id = config.project_id

        created_by = config.username
        if created_by is None:
            current_user = get_current_user(config.token, config.env)
            created_by = current_user["name"] if current_user else ""
        logger.info(f"Creating task for project_id: {project_id}, task_type: {task_type} -> file_type: {file_type}")

        # Call the API with converted file_type
        response = create_task(
            project_id=project_id,
            task_type=file_type,
            created_by=created_by,
            data_task_name=task_name,
            task_description=task_description,
            data_folder_id=data_folder_id,
            jwt_token=config.token,
            instance_name=config.instance,
            env=config.env,
            workspace_name=config.workspace
        )

        # Parse and format the response
        response_data = json.loads(response)

        if response_data.get("code") == "200":
            data = response_data.get("data", {})
            task_id = data

            # Build Studio URL
            studio_url = _build_ide_studio_url(config, task_id, config.env) if task_id else None

            # Format the response for better readability
            formatted_response = {
                "success": True,
                "message": "Successfully create task",
                "task_id": task_id,
            }

            if studio_url:
                formatted_response["studio_url"] = studio_url

            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[handle_create_task]API request failed: {response_data.get('message', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in create task: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


def create_task_tool() -> List[Tool]:
    """Get all Studio-specific tools"""
    return [
        Tool(
            name="create_task",
            description="Create a new data task in a Clickzetta Studio project workspace and return a direct link to open it. "
                        "Specify the task name, type, owner, description, and target folder. "
                        "Supports various task types including SQL, Shell, Python, data integration, and notebook tasks."
                        "\n\n"
                        "**For Flow tasks (组合任务, task_type=500):** After creation, use flow-specific tools to manage nodes:\n"
                        "- create_flow_node: add nodes/steps to the flow\n"
                        "- bind_flow_node: set dependencies between nodes\n"
                        "- get_flow_dag: view flow structure\n"
                        "- submit_flow: publish/deploy the flow\n"
                        "For saving node content/schedule, use save_non_integration_task_content and save_task_configuration with the node's ID.\n\n"
                        "The response includes a 'studio_url' field providing a direct link to open the task in Clickzetta Studio IDE.",
            input_schema={
                "type": "object",
                "properties": {
                    "task_type": {
                        "type": "integer",
                        "description": f"Task type ID\n.{task_type_desc} "
                    },
                    "task_name": {
                        "type": "string",
                        "description": "Name of the task to be created."
                    },
                    "task_description": {
                        "type": "string",
                        "description": "Optional description or notes for the task."
                    },
                    "data_folder_id": {
                        "type": "integer",
                        "description": "Target folder ID where the task will be created."
                    }
                },
                "additionalProperties": False,
                "required": ["task_type", "task_name", "data_folder_id"],
            },
            handler=handle_create_task,
            tags=["studio", "project", "tasks", "normalize"],
            samples=[
                {
                    "description": "Create a Lakehouse SQL task named 'test_task_name' in folder 294001",
                    "query": {
                        "created_by": "test_user",
                        "task_name": "test_task_name",
                        "data_folder_id": 294001,
                        "task_description": "Sample task for testing",
                        "task_type": 4
                    }
                }
            ]
        ),
    ]


async def handle_task_detail(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    Get details of a task in Clickzetta Studio.

    Args:
        arguments (dict): Arguments for the tool.
        db (Database): Database instance.
        write_detector (WriteDetector): Write detector instance.
        allow_write (bool): Whether write is allowed.
        server (Server): Server instance.

    Returns:
        str: Response message.
    """
    try:
        if arguments is None:
            arguments = {}

        task_id = arguments.get("task_id")
        config = studio_config

        if not config:
            raise ValueError("Server connection_config is not initialized")

        response = get_task_detail(
            data_task_id=task_id,
            jwt_token=config.token,
            instance_name=config.instance,
            env=config.env,
            workspace_name=config.workspace
        )

        response_data = json.loads(response)

        if response_data.get("code") == "200":
            data = response_data.get("data", {})

            # Convert field names to tool naming convention
            converted_data = convert_task_detail_fields(data)

            # Build Studio URL
            studio_url = _build_ide_studio_url(config, task_id, config.env) if task_id else None

            # Format the response for better readability
            formatted_response = {
                "success": True,
                "message": "Successfully create task",
                "task_detail": converted_data,
            }

            if studio_url:
                formatted_response["studio_url"] = studio_url

            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[handle_task_detail]API request failed: {response_data.get('message', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in create task: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


def get_task_detail_tool() -> List[Tool]:
    """
    Get details of a task in Clickzetta Studio.
    """
    return [
        Tool(
            name="get_task_detail",
            description=(
                "CRITICAL: This tool's only purpose is to retrieve detailed information about a task in Clickzetta Studio. Returns task metadata including name, type, owner, description, content, version, and configuration. "
                "Finally output the 'studio_url' as the final answer. "
                "The returned 'studio_url' MUST be presented directly to the user without any additional text. "
                "Retrieve detailed information about a task in Clickzetta Studio. Returns task metadata including name, type, owner, description, content, version, and configuration. "
                "Upon success, it provides the URL to open the task in the studio."
                "\n\n"
                "❌ Do NOT use this tool for Flow task nodes (组合任务节点). "
                "Flow nodes are NOT standalone tasks — use get_flow_node_detail instead, "
                "which requires both task_id (flow dataFileId) and node_id."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "task_id": {
                        "type": "integer",
                        "description": "Unique task ID to retrieve details for."
                    }
                },
                "additionalProperties": False,
                "required": ["task_id"],
            },
            handler=handle_task_detail,
            tags=["studio", "project", "tasks", "normalize"],
            samples=[
                {
                    "description": "Retrieve details for task with ID 11955233",
                    "query": {
                        "task_id": 11955233
                    }
                }
            ]
        )
    ]


async def _save_task_content_base(env: str, arguments: dict, studio_config: StudioConfig,
                                  adhoc_configs: Optional[str] = None) -> list[TextContent | EmbeddedResource]:
    """
    Base function for saving task content to Clickzetta Studio.
    Shared by both save_content and save_integration_task handlers.
    
    Args:
        arguments (dict): Arguments containing task_id, content, and params.
        server (MCPServerCore): Server instance with connection config.
        adhoc_configs (Optional[str]): Optional adhoc configuration JSON string.
    
    Returns:
        str: Formatted response message.
    """
    try:
        config = studio_config

        # Support both task_id/task_content (new) and data_task_id/data_task_content (legacy) for compatibility
        task_id = arguments.get("task_id") or arguments.get("data_task_id")
        task_content = arguments.get("task_content") or arguments.get("data_task_content")
        param_value_list = arguments.get("param_value_list")
        replace_escaped_chars = arguments.get("replace_escaped_chars", True)

        # Use config project ID and username
        project_id = config.project_id
        update_by = config.username
        if update_by is None:
            current_user = get_current_user(config.token, config.env)
            update_by = current_user["name"] if current_user else ""

        # Fill necessary fields for param_value_list
        if param_value_list:
            for param in param_value_list:
                param.setdefault("encrypt", False)
                param.setdefault("ignore", False)
                param.setdefault("ref", 0)
                param.setdefault("paramType", "manual")
                param.setdefault("id", "1761124251997")

                if "paramKey" not in param or "paramValue" not in param:
                    logger.warning(f"param_value_list missing key/value: {param}")

        logger.info(f"Saving content to task with ID: {task_id}")

        # Call the API with optional adhoc_configs
        response = save_content(
            project_id=project_id,
            data_task_id=task_id,
            content=task_content,
            param_value_list=param_value_list,
            update_by=update_by,
            jwt_token=config.token,
            instance_name=config.instance,
            env=config.env,
            adhoc_configs=adhoc_configs,
            workspace_name=config.workspace,
            replace_escaped_chars=replace_escaped_chars,
        )

        # Parse and format the response
        response_data = json.loads(response)

        if response_data.get("code") == "200":
            data = response_data.get("data", {})

            # Build Studio URL
            studio_url = _build_ide_studio_url(config, task_id, env) if task_id else None

            formatted_response = {
                "success": True,
                "message": "Successfully saved task content",
                "save_result": data,
            }

            if studio_url:
                formatted_response["studio_url"] = studio_url

            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[_save_task_content_base]API request failed: {response_data.get('message', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in saving task content: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


async def handle_save_content(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    Save SQL or other text content to a task in Clickzetta Studio.

    Args:
        arguments (dict): Arguments for the tool.
        db (Database): Database instance.
        write_detector (WriteDetector): Write detector instance.
        allow_write (bool): Whether write is allowed.
        server (Server): Server instance.

    Returns:
        str: Response message.
    """
    if arguments is None:
        arguments = {}

    config = studio_config
    return await _save_task_content_base(config.env, arguments, config)


def save_non_integration_task_content() -> List[Tool]:
    """Get all Studio-specific tools"""
    return [
        Tool(
            name="save_non_integration_task_content",
            description=(
                "CRITICAL: This tool's only purpose is to save content to a Clickzetta task and output the 'studio_url' as the final answer. "
                "The returned 'studio_url' MUST be presented directly to the user without any additional text. "
                "Save content to a non-data-integration task in Clickzetta Studio. Supports SQL scripts, Shell scripts, Python code, and other text-based task content. "
                "Use this for task types such as Lakehouse SQL, JDBC SQL, Shell, Python, and Notebook tasks. Includes support for parameterized content with dynamic variables. "
                "\n\n"
                "❌ Do NOT use this tool to create flow nodes — use create_flow_node instead. "
                "**IMPORTANT:** By default, escaped control sequences in task_content (\\\\n/\\\\r/\\\\t) are converted to real control "
                "characters before saving. Set `replace_escaped_chars=false` to keep literal escape sequences unchanged."
                "\n\n"
                "Upon success, it provides the URL to open the task in the studio."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "task_id": {
                        "type": "integer",
                        "description": "Unique task ID of the target task."
                    },
                    "task_content": {
                        "type": "string",
                        "description": (
                            "Task content to save. The format depends on the task type: "
                            "SQL statements for query tasks, Shell scripts for Shell tasks, "
                            "Python code for Python tasks, etc."
                        )
                    },
                    "replace_escaped_chars": {
                        "type": "boolean",
                        "default": True,
                        "description": (
                            "Whether to replace escaped control sequences (\\\\n/\\\\r/\\\\t) with actual "
                            "control characters before saving. Default true."
                        ),
                    },
                    "param_value_list": {
                        "type": "array",
                        "description": "List of parameter key-value pairs for dynamic variables within the task content. Each parameter must comply with the rules defined at: https://yunqi.tech/documents/task_param",
                        "items": {
                            "type": "object",
                            "properties": {
                                "paramKey": {
                                    "type": "string",
                                    "description": "Parameter name (e.g., 'today', 'yesterday')."
                                },
                                "paramValue": {
                                    "type": "string",
                                    "description": "Parameter value or expression (e.g., '$[yyyyMMdd]', '$[yyyyMMdd, -1d]')."
                                }
                            }
                        }
                    }
                },
                "required": ["task_id", "task_content", "param_value_list"]
            },
            handler=handle_save_content,
            tags=["studio", "project", "tasks", "save"],
            samples=[
                {
                    "task_content": "--LAKEHOUSE SQL\n--********************************************************************--\n-- author: 110000001376\n-- create time: 2025-10-22 15:28:01\n--********************************************************************--\nselect 1; ",
                    "task_id": 11955233,
                    "param_value_list": [
                        {
                            "paramKey": "today",
                            "paramValue": "$[yyyyMMdd]",
                        },
                        {
                            "paramKey": "yesterday",
                            "paramValue": "$[yyyyMMdd, -1d]",
                        },
                        {
                            "paramKey": "custom_param",
                            "paramValue": "test",
                        }
                    ]
                }
            ]
        )
    ]


async def handle_save_integration_task(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    Create a data integration task with flexible parameters.

    This tool handles the complete workflow:
    1. Validate input parameters
    2. Check if source and sink tables exist
    3. Create sink table if it doesn't exist
    4. Get metadata for both tables
    5. Build and save the integration configuration

    Args:
        arguments (dict): Arguments for the tool
        db (Database): Database instance
        write_detector (WriteDetector): Write detector instance
        allow_write (bool): Whether write is allowed
        server (Server): Server instance

    Returns:
        str: Response message
    """
    if arguments is None:
        arguments = {}

    config = studio_config

    # Validate studio_config
    if not config:
        error_response = {
            "success": False,
            "message": "Studio configuration is not available",
            "error_type": "ConfigurationError"
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    try:
        # Extract parameters with flexible naming and validation
        data_task_id = arguments.get("task_id")

        # Validate task_id
        if not data_task_id:
            error_response = {
                "success": False,
                "message": "task_id is required",
                "error_type": "MissingParameter"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        # Validate task_id is numeric
        try:
            data_task_id = int(data_task_id)
        except (ValueError, TypeError):
            error_response = {
                "success": False,
                "message": f"task_id must be a valid integer, got: {data_task_id}",
                "error_type": "InvalidParameter"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        param_value_list = arguments.get("param_value_list")
        adhoc_configs = arguments.get("adhoc_configs")
        env = studio_config.env
        update_by = config.username
        if update_by is None:
            current_user = get_current_user(config.token, config.env)
            update_by = current_user["name"] if current_user else ""

        # Extract and validate source parameters
        source_datasource_name = arguments.get("source_datasource_name")
        source_schema = arguments.get("source_schema")
        source_table = arguments.get("source_table")
        source_ds_type = arguments.get("source_ds_type")

        # Extract and validate sink parameters
        sink_datasource_name = arguments.get("sink_datasource_name")
        sink_schema = arguments.get("sink_schema", "public")  # Default to public
        sink_table = arguments.get("sink_table")
        sink_ds_type = arguments.get("sink_ds_type")

        # If sink_table is not specified, default to source_table name
        if not sink_table:
            sink_table = source_table
            logger.info(f"sink_table not specified, defaulting to source_table: {source_table}")

        # Validate required parameters with detailed error messages
        validation_errors = []

        if not source_datasource_name or not isinstance(source_datasource_name, str):
            validation_errors.append("source_datasource_name (must be a non-empty string)")
        if not source_schema or not isinstance(source_schema, str):
            validation_errors.append("source_schema (must be a non-empty string)")
        if not source_table or not isinstance(source_table, str):
            validation_errors.append("source_table (must be a non-empty string)")
        if source_ds_type is None:
            validation_errors.append("source_ds_type (must be provided)")
        elif not isinstance(source_ds_type, int):
            validation_errors.append("source_ds_type (must be an integer)")

        if not sink_datasource_name or not isinstance(sink_datasource_name, str):
            validation_errors.append("sink_datasource_name (must be a non-empty string)")
        if not sink_schema or not isinstance(sink_schema, str):
            validation_errors.append("sink_schema (must be a non-empty string)")
        if sink_ds_type is None:
            validation_errors.append("sink_ds_type (must be provided)")
        elif not isinstance(sink_ds_type, int):
            validation_errors.append("sink_ds_type (must be an integer)")

        if validation_errors:
            error_response = {
                "success": False,
                "message": f"Parameter validation failed: {'; '.join(validation_errors)}",
                "error_type": "ValidationError",
                "invalid_parameters": validation_errors
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        # Get datasource information with error handling
        logger.info(f"Looking up source datasource: {source_datasource_name} (type: {source_ds_type})")
        try:
            source_datasource = get_datasource_by_name(
                source_datasource_name,
                studio_config,
                ds_name=source_datasource_name,
                ds_type=source_ds_type
            )
        except Exception as e:
            logger.error(f"Error fetching source datasource: {e}")
            error_response = {
                "success": False,
                "message": f"Failed to fetch source datasource '{source_datasource_name}': {str(e)}",
                "error_type": "DatasourceQueryError"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        if not source_datasource:
            error_response = {
                "success": False,
                "message": f"Source datasource '{source_datasource_name}' not found. Please verify the datasource name and type (type={source_ds_type})",
                "error_type": "DatasourceNotFound",
                "hint": "Use list_datasources tool to see available datasources"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        logger.info(f"Looking up sink datasource: {sink_datasource_name} (type: {sink_ds_type})")
        try:
            sink_datasource = get_datasource_by_name(
                sink_datasource_name,
                studio_config,
                ds_name=sink_datasource_name,
                ds_type=sink_ds_type
            )
        except Exception as e:
            logger.error(f"Error fetching sink datasource: {e}")
            error_response = {
                "success": False,
                "message": f"Failed to fetch sink datasource '{sink_datasource_name}': {str(e)}",
                "error_type": "DatasourceQueryError"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        if not sink_datasource:
            error_response = {
                "success": False,
                "message": f"Sink datasource '{sink_datasource_name}' not found. Please verify the datasource name and type (type={sink_ds_type})",
                "error_type": "DatasourceNotFound",
                "hint": "Use list_datasources tool to see available datasources"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        # Extract datasource IDs with validation
        try:
            source_datasource_id = source_datasource["id"]
            if not source_datasource_id:
                raise ValueError("Source datasource ID is empty")
        except (KeyError, ValueError) as e:
            error_response = {
                "success": False,
                "message": f"Invalid source datasource object: {str(e)}",
                "error_type": "DatasourceDataError"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        try:
            sink_datasource_id = sink_datasource["id"]
            if not sink_datasource_id:
                raise ValueError("Sink datasource ID is empty")
        except (KeyError, ValueError) as e:
            error_response = {
                "success": False,
                "message": f"Invalid sink datasource object: {str(e)}",
                "error_type": "DatasourceDataError"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        # Use provided ds_type parameter, fallback to datasource object
        source_datasource_type = source_ds_type if source_ds_type is not None else (
            source_datasource.get("dsType") or source_datasource.get("type")
        )
        sink_datasource_type = sink_ds_type if sink_ds_type is not None else (
            sink_datasource.get("dsType") or sink_datasource.get("type")
        )

        # Validate datasource types are valid
        if source_datasource_type is None:
            error_response = {
                "success": False,
                "message": "Could not determine source datasource type",
                "error_type": "DatasourceTypeError"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        if sink_datasource_type is None:
            error_response = {
                "success": False,
                "message": "Could not determine sink datasource type",
                "error_type": "DatasourceTypeError"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        logger.info(f"Source: {source_datasource_name} (ID: {source_datasource_id}, Type: {source_datasource_type})")
        logger.info(f"Sink: {sink_datasource_name} (ID: {sink_datasource_id}, Type: {sink_datasource_type})")

        # Check if source table exists with error handling
        logger.info(f"Checking if source table exists: {source_schema}.{source_table}")
        try:
            source_table_exists = check_table_exists(
                source_datasource_id, source_schema, source_table, studio_config, source_datasource_type, env
            )
        except Exception as e:
            logger.error(f"Error checking source table existence: {e}")
            error_response = {
                "success": False,
                "message": f"Failed to check if source table exists: {str(e)}",
                "error_type": "TableCheckError",
                "table": f"{source_schema}.{source_table}"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        if not source_table_exists:
            error_response = {
                "success": False,
                "message": f"Source table '{source_schema}.{source_table}' does not exist in datasource '{source_datasource_name}'",
                "error_type": "SourceTableNotFound",
                "datasource": source_datasource_name,
                "table": f"{source_schema}.{source_table}",
                "hint": "Please verify the schema and table name are correct"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        logger.info(f"Source table {source_schema}.{source_table} exists")

        # Ensure sink schema exists before creating the sink table
        logger.info(f"Ensuring sink schema exists: {sink_schema}")
        try:
            sink_schema_ready = create_schema_if_not_exists(
                sink_datasource_id,
                sink_schema,
                studio_config,
                sink_datasource_type,
                env
            )
        except Exception as e:
            logger.error(f"Error ensuring sink schema exists: {e}")
            error_response = {
                "success": False,
                "message": f"Exception while ensuring sink schema '{sink_schema}' exists: {str(e)}",
                "error_type": "SchemaCreationException",
                "sink_schema": sink_schema
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        if not sink_schema_ready:
            error_response = {
                "success": False,
                "message": f"Failed to ensure sink schema '{sink_schema}' exists in datasource '{sink_datasource_name}'",
                "error_type": "SinkSchemaCreationFailed",
                "datasource": sink_datasource_name,
                "sink_schema": sink_schema,
                "hint": "Check if you have permission to create schemas/databases in the sink datasource"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        # Create sink table from source if it doesn't exist
        logger.info(f"Creating/verifying sink table: {sink_schema}.{sink_table}")
        try:
            sink_table_created = create_sink_table_from_source(
                source_datasource_id=source_datasource_id,
                source_datasource_type=source_datasource_type,
                source_schema=source_schema,
                source_table=source_table,
                sink_datasource_id=sink_datasource_id,
                sink_datasource_type=sink_datasource_type,
                sink_schema=sink_schema,
                sink_table=sink_table,
                server=config,
                env=env
            )
        except Exception as e:
            logger.error(f"Error creating sink table: {e}")
            error_response = {
                "success": False,
                "message": f"Exception while creating sink table '{sink_schema}.{sink_table}': {str(e)}",
                "error_type": "TableCreationException",
                "source_table": f"{source_schema}.{source_table}",
                "sink_table": f"{sink_schema}.{sink_table}"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        if not sink_table_created:
            error_response = {
                "success": False,
                "message": f"Failed to create sink table '{sink_schema}.{sink_table}' from source '{source_schema}.{source_table}'",
                "error_type": "SinkTableCreationFailed",
                "source_table": f"{source_schema}.{source_table}",
                "sink_table": f"{sink_schema}.{sink_table}",
                "hint": "Check if you have permission to create tables in the sink datasource"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        logger.info(f"Sink table {sink_schema}.{sink_table} is ready")

        # Generate integration configuration with error handling
        logger.info("Generating integration configuration")
        try:
            integration_json = integration_generator(
                source_datasource_id, source_datasource_name, source_schema, source_table,
                sink_datasource_id, sink_datasource_name, sink_schema, sink_table,
                source_datasource_type, sink_datasource_type,
                env, studio_config
            )
        except Exception as e:
            logger.error(f"Error generating integration config: {e}")
            error_response = {
                "success": False,
                "message": f"Failed to generate integration configuration: {str(e)}",
                "error_type": "ConfigGenerationError"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        # Validate integration_json is not empty
        if not integration_json or not isinstance(integration_json, dict):
            error_response = {
                "success": False,
                "message": "Generated integration configuration is invalid or empty",
                "error_type": "InvalidConfigError"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        # Save the integration configuration
        logger.info(f"Saving integration configuration for task_id: {data_task_id}")
        try:
            response_text = save_content(
                project_id=config.project_id,
                data_task_id=data_task_id,
                content=integration_json,
                param_value_list=param_value_list if param_value_list is not None else [],
                update_by=update_by,
                jwt_token=config.token,
                instance_name=config.instance,
                env=config.env,
                adhoc_configs=adhoc_configs,
                workspace_name=config.workspace
            )
        except Exception as e:
            logger.error(f"Error calling save_content API: {e}")
            error_response = {
                "success": False,
                "message": f"Failed to save integration configuration: {str(e)}",
                "error_type": "SaveContentAPIError"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        # Validate response is not empty
        if not response_text:
            error_response = {
                "success": False,
                "message": "Received empty response from save_content API",
                "error_type": "EmptyResponseError"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        # Parse the response (save_content returns a JSON string)
        try:
            response = json.loads(response_text)
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse response: {e}")
            logger.error(f"Response text: {response_text[:500]}")  # Log first 500 chars
            error_response = {
                "success": False,
                "message": f"Failed to parse API response: {str(e)}",
                "error_type": "JSONParseError",
                "raw_response": response_text[:1000]  # Limit to first 1000 chars
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        # Validate response structure
        if not isinstance(response, dict):
            error_response = {
                "success": False,
                "message": f"Invalid response format: expected dict, got {type(response).__name__}",
                "error_type": "InvalidResponseFormat"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        # Build the response
        response_code = response.get("code")
        if response_code == "200":
            logger.info(f"Successfully saved integration task {data_task_id}")

            # Build Studio URL with error handling
            try:
                from cz_mcp.common.redirect_url_utils import _build_ide_studio_url
                studio_url = _build_ide_studio_url(studio_config, data_task_id, env)
            except Exception as e:
                logger.warning(f"Failed to build studio URL: {e}")
                studio_url = None

            formatted_response = {
                "success": True,
                "message": "Successfully saved data integration task configuration",
                "task_id": data_task_id,
                "source": {
                    "datasource": source_datasource_name,
                    "table": f"{source_schema}.{source_table}"
                },
                "sink": {
                    "datasource": sink_datasource_name,
                    "table": f"{sink_schema}.{sink_table}"
                },
                "source_table_exists": True,
                "sink_table_ready": True,
                "integration_config": response.get("data", {})
            }

            if studio_url:
                formatted_response["studio_url"] = studio_url

            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            # API returned error
            error_message = response.get("message", "Unknown error")
            logger.error(f"API returned error: code={response_code}, message={error_message}")

            error_response = {
                "success": False,
                "message": f"API error: {error_message}",
                "error_type": "APIError",
                "code": response_code,
                "api_response": response
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except KeyError as e:
        logger.error(f"Missing required key in data: {e}", exc_info=True)
        error_response = {
            "success": False,
            "message": f"Missing required data field: {str(e)}",
            "error_type": "MissingDataError"
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Unexpected error in save_integration_task: {e}", exc_info=True)
        error_response = {
            "success": False,
            "message": f"Unexpected error: {str(e)}",
            "error_type": type(e).__name__
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


def  save_integration_task_tool() -> List[Tool]:
    """
    Get data integration flow tool

    Returns:
        List[Tool]: List of tools
    """
    return [
        Tool(
            name="save_integration_task",
            description=(
                "CRITICAL: Output the 'studio_url' as the final answer. "
                "The returned 'studio_url' MUST be presented directly to the user without any additional text. "
                
                "save a complete data integration task with flexible source and sink parameters. "
                "This tool handles the entire workflow including table existence checks, "
                "automatic sink table creation, metadata retrieval, and integration configuration building. "
                "\n\n"
                "**Parameters:**\n"
                "- task_id: Unique task ID of the integration task."
                "- source_datasource_name: Name of the source datasource\n"
                "- source_schema: Schema/database containing the source table\n"
                "- source_table: Name of the source table\n"
                "- source_ds_type: Type of the source datasource (integer enum: 1=Lakehouse, 2=Kafka, 3=Hive, 4=ClickHouse, 5=MySQL, 7=PostgreSQL, 8=SQLServer, 9=OSS, 12=MongoDB, 43=Redis)\n"
                "- sink_datasource_name: Name of the sink datasource (default: Lakehouse)\n"
                "- sink_schema: Schema/database for the sink table (default: public)\n"
                "- sink_table: Name of the sink table (optional, defaults to source_table name if not specified)\n"
                "- sink_ds_type: Type of the sink datasource (integer enum: 1=Lakehouse, 2=Kafka, 3=Hive, 4=ClickHouse, 5=MySQL, 7=PostgreSQL, 8=SQLServer, 9=OSS, 12=MongoDB, 43=Redis)\n"
                "\n\n"
                "**Prerequisites:**\n"
                "- Both source and sink datasources must be configured\n"
                "\n\n"
                "**IMPORTANT:** When processing task content, preserve actual newline characters (\\n) as line breaks, "
                "not as literal string '\\\\n'. Ensure proper formatting is maintained in the saved content."
                "\n\n"
                "The response includes a 'studio_url' field providing a direct link to open the task in Clickzetta Studio IDE."
                "Upon success, it provides the URL to open the task in the studio."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "task_id": {
                        "type": "integer",
                        "description": "Unique task ID of the integration task"
                    },
                    "source_datasource_name": {
                        "type": "string",
                        "description": "Name of the source datasource"
                    },
                    "source_schema": {
                        "type": "string",
                        "description": "Schema/database containing the source table"
                    },
                    "source_table": {
                        "type": "string",
                        "description": "Name of the source table"
                    },
                    "source_ds_type": {
                        "type": "integer",
                        "description": "Type of the source datasource (1=Lakehouse, 2=Kafka, 3=Hive, 4=ClickHouse, 5=MySQL, 7=PostgreSQL, 8=SQLServer, 9=OSS, 12=MongoDB, 43=Redis)",
                        "enum": [1, 2, 3, 4, 5, 7, 8, 9, 12, 43]
                    },
                    "sink_datasource_name": {
                        "type": "string",
                        "description": "Name of the sink datasource (default: Lakehouse)"
                    },
                    "sink_schema": {
                        "type": "string",
                        "description": "Schema/database for the sink table (default: public)",
                        "default": "public"
                    },
                    "sink_table": {
                        "type": "string",
                        "description": "Name of the sink table (if not specified, defaults to same name as source_table)"
                    },
                    "sink_ds_type": {
                        "type": "integer",
                        "description": "Type of the sink datasource (1=Lakehouse, 2=Kafka, 3=Hive, 4=ClickHouse, 5=MySQL, 7=PostgreSQL, 8=SQLServer, 9=OSS, 12=MongoDB, 43=Redis)",
                        "enum": [1, 2, 3, 4, 5, 7, 8, 9, 12, 43]
                    }
                },
                "required": [
                    "task_id",
                    "source_datasource_name", "source_schema", "source_table", "source_ds_type",
                    "sink_datasource_name", "sink_ds_type"
                ]
            },
            handler=handle_save_integration_task,
            tags=["studio", "project", "tasks", "integration", "save"],
            samples=[
                {
                    "task_id":"1234566",
                    "source_datasource_name": "MySQL_Prod",
                    "source_schema": "app",
                    "source_table": "users",
                    "source_ds_type": 5,
                    "sink_datasource_name": "LAKEHOUSE_dengqiang_ws",
                    "sink_schema": "public",
                    "sink_table": "users_from_mysql",
                    "sink_ds_type": 1
                }
            ]
        )
    ]


async def handle_save_task_cron_configuration(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    Save configuration to a task in Clickzetta Studio with automatic defaults.

    Args:
        arguments (dict): Arguments for the tool.
        db (Database): Database instance.
        write_detector (WriteDetector): Write detector instance.
        allow_write (bool): Whether write is allowed.
        server (Server): Server instance.

    Returns:
        str: Response message.
    """
    if arguments is None:
        arguments = {}
    try:
        from datetime import datetime

        config = studio_config
        jwt_token = config.token
        project_id = config.project_id
        user_id = config.user_id
        user_name = config.username
        if user_name is None:
            current_user = get_current_user(jwt_token, config.env)
            user_name = current_user["name"] if current_user else ""
        instance_name = arguments.get("instance_name") or config.instance

        # Required fields
        task_id = arguments.get("task_id")
        if not task_id:
            error_response = {
                "success": False,
                "message": "⚠️ Missing required field: task_id",
                "error_type": "MissingParameter"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        old_configuration_text = get_configuration_detail(
            project_id=project_id,
            workspace_id=config.workspace_id,
            data_file_id=task_id,
            jwt_token=jwt_token,
            instance_name=instance_name,
            tenant_id=config.tenant_id,
            user_id=user_id,
            instance_id=config.instance_id,
            env=config.env,
            workspace_name=config.workspace
        )
        old_configuration = json.loads(old_configuration_text)
        # Cron expression with default
        cron_express = arguments.get("cron_express")
        if not cron_express:
            cron_express = "0 00 00 * * ? *"  # Default: daily at midnight
            logger.info(f"Using default cron_express: {cron_express}")

        active_start_time = _format_iso_start_of_day(old_configuration.get("activeStartTime"))
        active_end_time = _format_iso_start_of_day(old_configuration.get("activeEndTime") or "2099-01-01")

        studio_cron_result = convert_agent_cron(cron_express)
        cron_express = studio_cron_result["output_cron"]
        schema_name = arguments.get("schema_name", arguments.get("schema_name",old_configuration.get("schemaName", "public")))
        if not schema_name:
            schema_name = config.schema
            logger.info(f"Using default schema_name: {schema_name}")

        etl_vc_code = arguments.get("etl_vc_code", arguments.get("schema_name", old_configuration.get("etlVcCode", "DEFAULT")))
        if not etl_vc_code:
            etl_vc_code = config.vcluster
            logger.info(f"Using default etl_vc_code: {etl_vc_code}")
        etl_vc_id = arguments.get("etl_vc_id", old_configuration.get("etlVcId", ""))

        # 如果传入了 excludeTimeRanges，则组装为 configProperties JSON 对象
        # Schedule timing with defaults
        config_properties = dict(old_configuration.get("configProperties", {})) if old_configuration else {}
        config_properties.pop("scheduleStartTime", None)
        config_properties.pop("scheduleEndTime", None)

        ui_param = studio_cron_result.get("ui_param") if isinstance(studio_cron_result, dict) else None
        if ui_param:
            schedule_start_time = getattr(ui_param, "schedule_start_time", None)
            schedule_end_time = getattr(ui_param, "schedule_end_time", None)
            if schedule_start_time:
                config_properties["scheduleStartTime"] = schedule_start_time
            if schedule_end_time:
                config_properties["scheduleEndTime"] = schedule_end_time

        config_properties_str = json.dumps(config_properties)

        response = save_configuration(
            project_id,
            task_id,
            cron_express,
            user_id,
            user_name,
            active_start_time,
            active_end_time,
            old_configuration.get("retryIntervalTime",1),
            old_configuration.get("retryIntervalTimeUnit", "m"),
            old_configuration.get("retryCount", 1),
            old_configuration.get("rerunProperty", 3),
            old_configuration.get("executeTimeout", 0),
            old_configuration.get("executeTimeoutUnit", "m"),
            old_configuration.get("selfDependsJob", 0),
            old_configuration.get("dataFileDependencyDTOS", []),
            config_properties_str,
            schema_name,
            etl_vc_code,
            etl_vc_id,
            jwt_token,
            instance_name,
            env=config.env,
            workspace_name=config.workspace
        )

        logger.info(f"保存配置成功: {response}")

        # Parse and format the response
        response_data = json.loads(response)

        if response_data.get("code") == "200":
            data = response_data.get("data", {})
            save_config_result = data

            # Build Studio URL
            studio_url = _build_ide_studio_url(config, task_id, config.env) if task_id else None

            # Format the response for better readability
            formatted_response = {
                "success": True,
                "message": "Successfully save configuration",
                "save_config_result": save_config_result,
            }

            if studio_url:
                formatted_response["studio_url"] = studio_url

            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[handle_save_configuration]API request failed: {response_data.get('message', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in save configuration: {e}")
        import traceback
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__,
            "traceback": traceback.format_exc()
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


async def handle_save_task_non_cron_configuration(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    Save configuration to a task in Clickzetta Studio with automatic defaults.

    Args:
        arguments (dict): Arguments for the tool.
        db (Database): Database instance.
        write_detector (WriteDetector): Write detector instance.
        allow_write (bool): Whether write is allowed.
        server (Server): Server instance.

    Returns:
        str: Response message.
    """
    if arguments is None:
        arguments = {}
    try:
        from datetime import datetime

        config = studio_config
        jwt_token = config.token
        project_id = config.project_id
        user_id = config.user_id
        user_name = config.username
        if user_name is None:
            current_user = get_current_user(jwt_token, config.env)
            user_name = current_user["name"] if current_user else ""
        instance_name = arguments.get("instance_name") or config.instance

        # Required fields
        task_id = arguments.get("task_id")
        if not task_id:
            error_response = {
                "success": False,
                "message": "⚠️ Missing required field: task_id",
                "error_type": "MissingParameter"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


        old_configuration_text = get_configuration_detail(
            project_id=project_id,
            workspace_id=config.workspace_id,
            data_file_id=task_id,
            jwt_token=jwt_token,
            instance_name=instance_name,
            tenant_id=config.tenant_id,
            user_id=user_id,
            instance_id=config.instance_id,
            env=config.env,
            workspace_name=config.workspace
        )
        old_configuration = json.loads(old_configuration_text)
        # Cron expression with default
        cron_express = old_configuration.get("cronExpress")
        if not cron_express:
            cron_express = "0 00 00 * * ? *"  # Default: daily at midnight
            logger.info(f"Using default cron_express: {cron_express}")

        active_start_time = _format_iso_start_of_day(old_configuration.get("activeStartTime"))
        active_end_time = _format_iso_start_of_day(old_configuration.get("activeEndTime") or "2099-01-01")
        # Retry policy with defaults


        retry_interval_time = arguments.get("retry_interval_time",old_configuration.get("retryIntervalTime", 1))
        retry_interval_time_units = arguments.get("retry_interval_time_unit",old_configuration.get("retryIntervalTimeUnit", "m"))
        retry_count = arguments.get("retry_count",old_configuration.get("retryCount", 1))
        # Rerun property with default (MUST be integer, not string)
        rerun_property = arguments.get("rerun_property",old_configuration.get("rerunProperty", 3))
        # Self dependency with default
        self_depends_job = arguments.get("self_depends_job",old_configuration.get("selfDependsJob", 0))
        # Execution environment with defaults


        schema_name = arguments.get("schema_name",old_configuration.get("schemaName", ""))
        etl_vc_code = arguments.get("etl_vc_code",old_configuration.get("etlVcCode", "DEFAULT"))
        etl_vc_id = arguments.get("etl_vc_id",old_configuration.get("etlVcId", ""))

        # Dependencies support explicit three-state updates:
        # - keep: preserve existing dependencies
        # - replace: replace with provided task_dependencies (empty list clears)
        # - clear: clear all dependencies
        task_dependencies_action = arguments.get("task_dependencies_action")
        if task_dependencies_action == "clear":
            task_dependencies = []
        elif task_dependencies_action == "replace":
            task_dependencies = arguments.get("task_dependencies", [])
        elif task_dependencies_action == "keep":
            task_dependencies = old_configuration.get("dataFileDependencyDTOS", [])
        elif "task_dependencies" in arguments:
            # Backward compatibility: if caller explicitly passes task_dependencies,
            # treat it as a replace operation even when action is omitted.
            task_dependencies = arguments["task_dependencies"] or []
        else:
            task_dependencies = old_configuration.get("dataFileDependencyDTOS", [])

        config_properties = old_configuration.get("configProperties", "{}")

        execute_timeout = arguments.get("execute_timeout", old_configuration.get("executeTimeout"))
        execute_timeout_unit = arguments.get("execute_timeout_unit", old_configuration.get("executeTimeoutUnit", "m"))
        response = save_configuration(
            project_id,
            task_id,
            cron_express,
            user_id,
            user_name,
            active_start_time,
            active_end_time,
            retry_interval_time,
            retry_interval_time_units,
            retry_count,
            rerun_property,
            execute_timeout,
            execute_timeout_unit,
            self_depends_job,
            task_dependencies,  # API expects data_file_input_list_reqs, but we use task_dependencies in tool
            config_properties,
            schema_name,
            etl_vc_code,
            etl_vc_id,
            jwt_token,
            instance_name,
            env=config.env,
            workspace_name=config.workspace
        )

        logger.info(f"保存配置成功: {response}")

        # Parse and format the response
        response_data = json.loads(response)

        if response_data.get("code") == "200":
            data = response_data.get("data", {})
            save_config_result = data

            # Build Studio URL
            studio_url = _build_ide_studio_url(config, task_id, config.env) if task_id else None

            # Format the response for better readability
            formatted_response = {
                "success": True,
                "message": "Successfully save configuration",
                "save_config_result": save_config_result,
            }

            if studio_url:
                formatted_response["studio_url"] = studio_url

            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[handle_save_configuration]API request failed: {response_data.get('message', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in save configuration: {e}")
        import traceback
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__,
            "traceback": traceback.format_exc()
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


async def handle_save_configuration(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    Save configuration to a task in Clickzetta Studio with automatic defaults.

    Args:
        arguments (dict): Arguments for the tool.
        db (Database): Database instance.
        write_detector (WriteDetector): Write detector instance.
        allow_write (bool): Whether write is allowed.
        server (Server): Server instance.

    Returns:
        str: Response message.
    """
    if arguments is None:
        arguments = {}
    try:
        from datetime import datetime

        config = studio_config
        jwt_token = config.token
        project_id = config.project_id
        user_id = config.user_id
        user_name = config.username
        if user_name is None:
            current_user = get_current_user(jwt_token, config.env)
            user_name = current_user["name"] if current_user else ""
        instance_name = arguments.get("instance_name") or config.instance

        # Required fields
        task_id = arguments.get("task_id")
        if not task_id:
            error_response = {
                "success": False,
                "message": "⚠️ Missing required field: task_id",
                "error_type": "MissingParameter"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        # Cron expression with default
        cron_express = arguments.get("cron_express")
        if not cron_express:
            cron_express = "0 00 00 * * ? *"  # Default: daily at midnight
            logger.info(f"Using default cron_express: {cron_express}")

        active_start_time = _format_iso_start_of_day(arguments.get("active_start_time"))
        active_end_time = _format_iso_start_of_day(arguments.get("active_end_time") or "2099-01-01")
        # Retry policy with defaults
        retry_interval_time = arguments.get("retry_interval_time")
        retry_interval_time_units = arguments.get("retry_interval_time_unit")
        retry_count = arguments.get("retry_count")
        # Rerun property with default (MUST be integer, not string)
        rerun_property = arguments.get("rerun_property")
        # Self dependency with default
        self_depends_job = arguments.get("self_depends_job")
        # Execution environment with defaults
        schema_name = arguments.get("schema_name")
        if not schema_name:
            schema_name = config.schema
            logger.info(f"Using default schema_name: {schema_name}")

        etl_vc_code = arguments.get("etl_vc_code")
        if not etl_vc_code:
            etl_vc_code = config.vcluster
            logger.info(f"Using default etl_vc_code: {etl_vc_code}")
        etl_vc_id = arguments.get("etl_vc_id")

        # Dependencies (optional)
        task_dependencies = arguments.get("task_dependencies", [])

        exclude_time_ranges = arguments.get("exclude_time_ranges", [])
        # 如果传入了 excludeTimeRanges，则组装为 configProperties JSON 对象
        # Schedule timing with defaults
        config_properties = {}
        schedule_start_time = _format_iso_start_of_day(arguments.get("schedule_start_time"))
        if schedule_start_time:
            config_properties["scheduleStartTime"] = schedule_start_time
        schedule_end_time = _format_iso_end_of_day(arguments.get("schedule_end_time"))
        if schedule_end_time:
            config_properties["scheduleEndTime"] = schedule_end_time
        if exclude_time_ranges:
            config_properties["excludeTimeRanges"] = exclude_time_ranges
            # config_properties = {
            #     "excludeTimeRanges": exclude_time_ranges,
            #     "scheduleStartTime": schedule_start_time,
            #     "scheduleEndTime": schedule_start_time
            # }
        config_properties = json.dumps(config_properties)

        execute_timeout = arguments.get("execute_timeout")
        execute_timeout_unit = arguments.get("execute_timeout_unit")
        response = save_configuration(
            project_id,
            task_id,
            cron_express,
            user_id,
            user_name,
            active_start_time,
            active_end_time,
            retry_interval_time,
            retry_interval_time_units,
            retry_count,
            rerun_property,
            execute_timeout,
            execute_timeout_unit,
            self_depends_job,
            task_dependencies,  # API expects data_file_input_list_reqs, but we use task_dependencies in tool
            config_properties,
            schema_name,
            etl_vc_code,
            etl_vc_id,
            jwt_token,
            instance_name,
            env=config.env,
            workspace_name=config.workspace
        )

        logger.info(f"保存配置成功: {response}")

        # Parse and format the response
        response_data = json.loads(response)

        if response_data.get("code") == "200":
            data = response_data.get("data", {})
            save_config_result = data

            # Build Studio URL
            studio_url = _build_ide_studio_url(config, task_id, config.env) if task_id else None

            # Format the response for better readability
            formatted_response = {
                "success": True,
                "message": "Successfully save configuration",
                "save_config_result": save_config_result,
            }

            if studio_url:
                formatted_response["studio_url"] = studio_url

            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[handle_save_configuration]API request failed: {response_data.get('message', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in save configuration: {e}")
        import traceback
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__,
            "traceback": traceback.format_exc()
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


async def handle_get_file_configuration_detail(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    Get file configuration detail and present data aligned with save_task_configuration_tool inputs.
    """
    if arguments is None:
        arguments = {}
    try:
        config = studio_config
        jwt_token = config.token
        project_id = arguments.get("project_id") or config.project_id
        workspace_id = arguments.get("workspace_id") or config.workspace_id
        instance_name = arguments.get("instance_name") or config.instance
        tenant_id = arguments.get("tenant_id") or config.tenant_id
        user_id = arguments.get("user_id") or config.user_id
        instance_id = arguments.get("instance_id") or config.instance_id

        data_file_id = arguments.get("task_id")
        if not data_file_id:
            error_response = {
                "success": False,
                "message": "⚠️ Missing required field: data_file_id (or task_id)",
                "error_type": "MissingParameter"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        response = get_configuration_detail(
            project_id=project_id,
            workspace_id=workspace_id,
            data_file_id=data_file_id,
            jwt_token=jwt_token,
            instance_name=instance_name,
            tenant_id=tenant_id,
            user_id=user_id,
            instance_id=instance_id,
            env=config.env,
            workspace_name=config.workspace
        )

        logger.info(f"获取配置详情成功: {response}")
        response_data = json.loads(response)

        if response_data.get("code") == "200":
            data = response_data.get("data", {})
            converted = convert_configuration_detail_fields(data)
            formatted_response = {
                "success": True,
                "message": "Successfully retrieved configuration detail",
                "configuration_detail": converted,
                "save_task_configuration_input": converted.get("save_task_configuration_input")
            }
            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[handle_get_file_configuration_detail]API request failed: {response_data.get('message', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in get configuration detail: {e}")
        import traceback
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__,
            "traceback": traceback.format_exc()
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


def save_task_configuration_tool() -> List[Tool]:
    """
    Save configuration to a task in Clickzetta Studio with smart defaults.
    """
    return [
        Tool(
            name="save_task_configuration",
            description=(
                """
                ### **[Execution Steps]**
                **Step 1: Identify Task Type (CRITICAL Prerequisite Check)**
                    1. You **MUST** first use the `taskId` to call the `get_task_detail` function to determine the task's type (`task_type`).
                    2. This is a **MANDATORY PREREQUISITE** for all subsequent steps. If the task type cannot be determined, stop immediately and report an error.

                **Step 2: Handle Integration Tasks (CRITICAL Conditional Logic)**
                    1. **IF** the `task_type` is **10 (离线同步), 28 (实时同步), 280 (全增量一体同步), or 281 (多表实时同步)**:
                        a. You **MUST** check for available Sync Virtual Clusters by calling `LH-show_object_list` with `object_type="VCLUSTERS"`.
                        b. Filter the results to find vclusters where `vcluster_type` contains "SYNC" or similar sync-related indicators.
                        c. **IF** no Sync Virtual Cluster is found:
                            i. **CRITICAL**: You **MUST** stop execution immediately.
                            ii. **MUST** return a clear error message to the user: "**Error: This integration task requires a 'Sync VCluster', but none was found. Please create a Sync VCluster in Clickzetta before retrying.**"
                            iii. You **MUST NOT** proceed to Step 3.
                        d. **ELSE** (a Sync Virtual Cluster was found):
                            i. When calling the `save_task_configuration` function, you **MUST** set the `etl_vc_code` parameter to the name of the found Sync Virtual Cluster.
                            ii. Also set the `etl_vc_id` parameter if available.
                            iii. Proceed to Step 3.
    
                    2. **ELSE** (the `task_type` is not an integration task):
                        a. No check for a Sync Virtual Cluster is needed.
                        b. Proceed to Step 3.

                **Step 3: Save Schedule Configuration and Output Result**
                    1. Call the `save_task_configuration` function, passing all necessary parameters (e.g., `task_id`, `cron_express`, etc.).
                        * **Smart Defaults**: If not provided, use: daily execution at midnight (`0 0 0 * * ? *`), retry_count=3, retry_interval_time=1, retry_interval_time_unit='m', active until 2099-12-31, rerun_property=1, and the `DEFAULT` virtual cluster (for non-integration tasks only).
                    2. Upon success, the function will return a `studio_url`.
                    3. **Final Output**: You **MUST** present the returned `studio_url` directly to the user.
                """),
            input_schema={
                "type": "object",
                "properties": {
                    "task_id": {
                        "type": "integer",
                        "description": "Unique task ID to configure."
                    },
                    "cron_express": {
                        "type": "string",
                        "description": "Cron expression defining the execution schedule. Examples: '0 0 2 * * ? *' (2 AM daily), '0 0 2 ? * MON *' (2 AM every Monday). "
                                       "REQUIRED. Cron expression defining the execution schedule. ALWAYS use explicit step syntax with '/' notation (e.g., '0 0 0-22/1 * * ? *' instead of '0 0 0-22 * * ? *'). "
                    },
                    "retry_count": {
                        "type": "integer",
                        "description": "Optional. Maximum number of retry attempts on failure.  Note: Retry interval cannot be less than 60 seconds."
                    },
                    "retry_interval_time": {
                        "type": "integer",
                        "description": "Optional. Retry interval duration. Minimum effective interval is 1 minute. When unit is 's', value must be ≥60. When unit is 'm', value must be ≥1. Default: 1. Only used when retry_count > 0."
                    },
                    "retry_interval_time_unit": {
                        "type": "string",
                        "description": "Optional. Unit for retry interval: 'm' (minutes) or 's' (seconds). Default: 'm'. Note: The resulting interval must be at least 1 minute."
                    },
                    "rerun_property": {
                        "type": "integer",
                        "description": "Optional. Rerun policy (must be INTEGER): "
                                       "1 = ANY_TIME (can rerun after success or failure), "
                                       "2 = FAILED_ONLY (can only rerun after failure), "
                                       "3 = NOT_RERUN (cannot rerun after completion)"
                    },
                    "self_depends_job": {
                        "type": "integer",
                        "description": "Optional. Whether the task depends on its previous instance: 0 = no , 1 = yes."
                    },
                    "schema_name": {
                        "type": "string",
                        "description": "Optional. Database schema name for task execution. Default is `public`"
                    },
                    "etl_vc_code": {
                        "type": "string",
                        "description": "CRITICAL: If it's an integration task that must specify a sync vcluster, you must find an available sync vcluster. If none is found, return an exception."
                                       "For other tasks, no need to specify. "
                    },
                    "etl_vc_id": {
                        "type": "string",
                        "description": "Optional, when get_task_configuration_detail returned etl_vc_id, must specify. "
                    },
                    "task_dependencies": {
                        "type": "array",
                        "description": "Optional. List of upstream dependency tasks that must complete before this task executes. Default: [] (no dependencies).",
                        "items": {
                            "type": "object",
                            "properties": {
                                "dependency_task_id": {
                                    "type": "integer",
                                    "description": "Task ID of the upstream dependency."
                                },
                                "dependency_task_name": {
                                    "type": "string",
                                    "description": "Name of the dependency task (for reference)."
                                },
                                "dep_strategy": {
                                    "type": "integer",
                                    "description": "Dependency resolution strategy: 0 = self-dependency (default), 1 = all instances, 2 = custom. Default 0"
                                }
                            }
                        }
                    }

                },
                "required": ["task_id", "cron_express"]
            },
            handler=handle_save_configuration,
            tags=["studio", "schedule", "project", "config"],
            samples=[
                {
                    "description": "Save a complete scheduling configuration with dependencies, retry policy, and timing rules",
                    "query": {
                        "task_id": 11994071,
                        "retry_interval_time": 1,
                        "retry_interval_time_unit": "m",
                        "retry_count": 3,
                        "rerun_property": "1",
                        "self_depends_job": 0,
                        "task_description": "",
                        "cron_express": "0 00 00 * * ? *",
                        "schema_name": "public",
                        "etl_vc_code": "DEFAULT",
                        "task_dependencies": [
                            {
                                "dependency_task_id": 12005123,
                                "dependency_task_name": "task_name",
                                "dep_strategy": 0
                            }
                        ]
                    }
                }
            ]
        )
    ]


def save_task_configuration_v2_tools() -> List[Tool]:
    """
    New split tools for saving schedule configuration:
    - save_task_cron_configuration: only save cron-related settings
    - save_task_non_cron_configuration: save non-cron settings
    Keep old save_task_configuration tool for compatibility.
    """
    return [
        Tool(
            name="save_task_cron_configuration",
            description=(
                "Save only cron/schedule-time related configuration for a task. "
                "This tool updates cron expression and schedule window related properties, "
                "while preserving existing non-cron configuration."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "task_id": {
                        "type": "integer",
                        "description": "Unique task ID to configure."
                    },
                    "cron_express": {
                        "type": "string",
                        "description": (
                            "Cron expression for task scheduling. "
                            "Studio canonical format is 7 fields: second minute hour day month week year. "
                            "Scheduling frequency is still minute/hour/day only; week/month/year fields are date constraints. "
                            "5/6-field input is accepted and auto-normalized to 7 fields."
                        )
                    },
                    "schema_name": {
                        "type": "string",
                        "description": "Execution schema name."
                    },
                    "etl_vc_code": {
                        "type": "string",
                        "description": "Execution virtual cluster code."
                    },
                    "etl_vc_id": {
                        "type": "string",
                        "description": "Execution virtual cluster ID."
                    }
                },
                "required": ["task_id", "cron_express"],
                "additionalProperties": False
            },
            handler=handle_save_task_cron_configuration,
            tags=["studio", "schedule", "project", "config", "cron"],
            samples=[
                {
                    "description": "Save cron expression for task schedule",
                    "query": {
                        "task_id": 11994071,
                        "cron_express": "0 00 00 * * ? *"
                    }
                }
            ]
        ),
        Tool(
            name="save_task_non_cron_configuration",
            description=(
                "Save non-cron task scheduling configuration. "
                "Use this tool to update retry policy, dependency, vc/schema and execution timeout settings "
                "without changing cron expression."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "task_id": {
                        "type": "integer",
                        "description": "Unique task ID to configure."
                    },
                    "retry_count": {
                        "type": "integer",
                        "description": "Maximum retry attempts."
                    },
                    "retry_interval_time": {
                        "type": "integer",
                        "description": "Retry interval value."
                    },
                    "retry_interval_time_unit": {
                        "type": "string",
                        "description": "Retry interval unit: 'm' or 's'."
                    },
                    "rerun_property": {
                        "type": "integer",
                        "description": "Rerun policy: 1=ANY_TIME, 2=FAILED_ONLY, 3=NOT_RERUN."
                    },
                    "self_depends_job": {
                        "type": "integer",
                        "description": "Self dependency: 0=no, 1=yes."
                    },
                    "task_dependencies": {
                        "type": "array",
                        "description": "Optional upstream dependency tasks. When task_dependencies_action is 'replace', this field becomes the full replacement value. Pass [] to clear dependencies.",
                        "items": {
                            "type": "object",
                            "properties": {
                                "dependency_task_id": {
                                    "type": "integer",
                                    "description": "Task ID of the upstream dependency."
                                },
                                "dependency_task_name": {
                                    "type": "string",
                                    "description": "Name of the dependency task."
                                },
                                "dep_strategy": {
                                    "type": "integer",
                                    "description": "Dependency strategy."
                                }
                            }
                        }
                    },
                    "task_dependencies_action": {
                        "type": "string",
                        "enum": ["keep", "replace", "clear"],
                        "description": "Optional dependency update mode. keep=preserve existing dependencies, replace=replace with task_dependencies, clear=remove all dependencies. If omitted, the tool keeps existing dependencies unless task_dependencies is explicitly provided, in which case it behaves as replace."
                    },
                    "execute_timeout": {
                        "type": "integer",
                        "description": "Task execution timeout value."
                    },
                    "execute_timeout_unit": {
                        "type": "string",
                        "description": "Timeout unit."
                    }
                },
                "required": ["task_id"],
                "additionalProperties": False
            },
            handler=handle_save_task_non_cron_configuration,
            tags=["studio", "schedule", "project", "config"],
            samples=[
                {
                    "description": "Update retry policy and execution vc for task",
                    "query": {
                        "task_id": 11994071,
                        "retry_count": 3,
                        "retry_interval_time": 1,
                        "retry_interval_time_unit": "m",
                        "rerun_property": 1,
                        "schema_name": "public",
                        "etl_vc_code": "DEFAULT"
                    }
                },
                {
                    "description": "Clear all upstream task dependencies",
                    "query": {
                        "task_id": 11994071,
                        "task_dependencies_action": "clear"
                    }
                },
                {
                    "description": "Replace upstream task dependencies",
                    "query": {
                        "task_id": 11994071,
                        "task_dependencies_action": "replace",
                        "task_dependencies": [
                            {
                                "dependency_task_id": 12005123,
                                "dependency_task_name": "task_name",
                                "dep_strategy": 0
                            }
                        ]
                    }
                }
            ]
        )
    ]


async def handle_preview_schedule_instance_times(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    Preview task schedule instance times by cron expression.
    """
    if arguments is None:
        arguments = {}
    try:
        config = studio_config

        cron_express = arguments.get("cron_express") or arguments.get("cron")
        if not cron_express:
            error_response = {
                "success": False,
                "message": "⚠️ Missing required field: cron_express",
                "error_type": "MissingParameter"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        schedule_start_time = _normalize_schedule_clock(
            arguments.get("schedule_start_time"), "00:00", "schedule_start_time"
        )
        schedule_end_time = _normalize_schedule_clock(
            arguments.get("schedule_end_time"), "23:59", "schedule_end_time"
        )

        studio_cron_result = convert_agent_cron(
            cron_express,
            schedule_start_time=schedule_start_time,
            schedule_end_time=schedule_end_time,
        )
        if not studio_cron_result.get("ok"):
            error_response = {
                "success": False,
                "message": f"Unsupported cron expression: {studio_cron_result.get('unsupported_reason')}",
                "input_cron_express": cron_express,
                "warnings": studio_cron_result.get("warnings", []),
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

        normalized_cron = studio_cron_result.get("output_cron") or cron_express
        schedule_env = arguments.get("schedule_env") or arguments.get("env") or "prod"
        instance_name = arguments.get("instance_name") or config.instance
        instance_id = arguments.get("instance_id") or config.instance_id
        workspace_name = arguments.get("workspace_name") or config.workspace

        response = generate_instance_time_list(
            cron=normalized_cron,
            schedule_start_time=schedule_start_time,
            schedule_end_time=schedule_end_time,
            jwt_token=config.token,
            instance_name=instance_name,
            instance_id=instance_id,
            schedule_env=schedule_env,
            env=config.env,
            workspace_name=workspace_name,
        )
        response_data = json.loads(response)

        if str(response_data.get("code")) == "200":
            preview_times = response_data.get("data") or []
            formatted_response = {
                "success": True,
                "message": "Successfully generated schedule preview times",
                "input_cron_express": cron_express,
                "normalized_cron_express": normalized_cron,
                "schedule_start_time": schedule_start_time,
                "schedule_end_time": schedule_end_time,
                "preview_times": preview_times,
                "preview_count": len(preview_times),
            }
            warnings = studio_cron_result.get("warnings")
            if warnings:
                formatted_response["cron_warnings"] = warnings

            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)

        error_response = {
            "success": False,
            "message": f"[handle_preview_schedule_instance_times]API request failed: {response_data.get('message', 'Unknown error')}",
            "code": response_data.get("code"),
            "raw_response": response_data,
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in preview schedule instance times: {e}")
        import traceback
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__,
            "traceback": traceback.format_exc(),
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


def preview_schedule_instance_times_tool() -> List[Tool]:
    """
    Preview schedule instance times for a cron expression.
    """
    return [
        Tool(
            name="preview_schedule_instance_times",
            description=(
                "Preview future schedule instance times by cron expression before saving task schedule configuration. "
                "This helps verify whether the cron plan is correct."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "cron_express": {
                        "type": "string",
                        "description": "Cron expression to preview. Example: '0 00 00 * * ? *'."
                    },
                    "schedule_start_time": {
                        "type": "string",
                        "description": "Optional schedule start clock in HH:MM format. Default: '00:00'."
                    },
                    "schedule_end_time": {
                        "type": "string",
                        "description": "Optional schedule end clock in HH:MM format. Default: '23:59'."
                    },
                    "schedule_env": {
                        "type": "string",
                        "description": "Optional value for request header 'env'. Default: 'prod'."
                    },
                    "env": {
                        "type": "string",
                        "description": "Alias of schedule_env. If provided, it is used when schedule_env is absent."
                    },
                    "instance_name": {
                        "type": "string",
                        "description": "Optional override for instance name. Defaults to current StudioConfig instance."
                    },
                    "instance_id": {
                        "type": "integer",
                        "description": "Optional override for instance ID. Defaults to current StudioConfig instance_id."
                    },
                    "workspace_name": {
                        "type": "string",
                        "description": "Optional override for workspace name. Defaults to current StudioConfig workspace."
                    },
                },
                "required": ["cron_express"],
                "additionalProperties": False
            },
            handler=handle_preview_schedule_instance_times,
            tags=["studio", "schedule", "cron", "preview"],
            samples=[
                {
                    "description": "Preview daily schedule at midnight",
                    "query": {
                        "cron_express": "0 00 00 * * ? *",
                        "schedule_start_time": "00:00",
                        "schedule_end_time": "23:59",
                        "schedule_env": "prod"
                    }
                }
            ]
        )
    ]


def get_task_configuration_detail_tool() -> List[Tool]:
    """
    Get configuration detail for a task, returning data aligned with save_task_configuration_tool inputs.
    """
    return [
        Tool(
            name="get_task_configuration_detail",
            description=(
                "Fetch configuration detail for a Clickzetta task and return both the full response and a "
                "`save_task_configuration_input` block that matches save_task_configuration_tool inputs. "
                "Uses project/workspace/tenant/user context from current StudioConfig unless overridden."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "task_id": {
                        "type": "integer",
                        "description": "Alias for data_file_id."
                    },
                    "project_id": {
                        "type": "integer",
                        "description": "Optional override. Defaults to current project."
                    }
                },
                "additionalProperties": False,
                "required": ["task_id"]
            },
            handler=handle_get_file_configuration_detail,
            tags=["studio", "schedule", "config", "read"],
            samples=[
                {
                    "description": "Get configuration detail for task 13001008",
                    "query": {
                        "task_id": 13001008
                    }
                }
            ]
        )
    ]


async def handle_publish_task(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    Submit a task to Clickzetta Studio for processing.

    Args:
        arguments (dict): Arguments for the tool.
        db (Database): Database instance.
        write_detector (WriteDetector): Write detector instance.
        allow_write (bool): Whether write is allowed.
        server (Server): Server instance.

    Returns:
        str: Response message.
    """
    if arguments is None:
        arguments = {}

    try:
        config = studio_config
        jwt_token = config.token
        task_id = arguments.get("task_id")
        task_version = arguments.get("task_version")

        # Use config project ID if not provided
        project_id = config.project_id

        username = config.username
        if username is None:
            current_user = get_current_user(config.token, config.env)
            username = current_user["name"] if current_user else ""

        instance_name = config.instance
        response = submit_task(
            project_id,
            task_id,
            task_version,
            username,
            jwt_token,
            instance_name,
            env=config.env,
            workspace_name=config.workspace
        )

        response_data = json.loads(response)

        if response_data.get("code") == "200":
            data = response_data.get("data", {})

            # Build Studio URL
            studio_url = _build_ide_studio_url(studio_config, task_id, config.env) if task_id else None

            # Format the response for better readability
            formatted_response = {
                "success": True,
                "message": "Successfully submit task",
                "submit_result": data,
            }

            if studio_url:
                formatted_response["studio_url"] = studio_url

            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[handle_submit_task]API request failed: {response_data.get('message', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in create task: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


def publish_task_tool() -> List[Tool]:
    """
    Publish a task to Clickzetta Studio for processing.

    Returns:
        List[Tool]: List of tools.
    """
    return [
        Tool(
            name="publish_task",
            description=(
                "Publish a task to Clickzetta Studio for execution. Publishes the task to the scheduler and triggers execution if the schedule is active. "
                "\n\n"
                "❌ Do NOT use this tool for Flow tasks (组合任务, task_type=500). Use submit_flow instead.\n\n"
                "**Prerequisites:** Task content and configuration must be saved before submission. "
                "\n\n"
                "**⚠️ IMPORTANT - User Confirmation Required:** This operation MUST obtain explicit user confirmation before execution. "
                "Always ask the user to confirm before submitting the task to ensure task content and configuration are correct. "
                "Do NOT proceed with submission without user approval. "
                "\n\n"
                "The response includes a 'studio_url' field providing a direct link to open the task in Clickzetta Studio IDE."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "task_id": {
                        "type": "integer",
                        "description": "Unique task ID to submit."
                    },
                    "task_version": {
                        "type": "integer",
                        "description": (
                            "Task version number to submit. "
                            "Retrieve the current version using the get_task_detail tool."
                        )
                    }
                },
                "required": ["task_id", "task_version"]
            },
            handler=handle_publish_task,
            tags=["studio", "project", "tasks", "submit"],
            samples=[
                {
                    "description": "Submit task 11955233 with version 0",
                    "query": {
                        "task_id": 11955233,
                        "task_version": 0
                    }
                }
            ]
        )
    ]


async def handle_list_folders(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[TextContent | EmbeddedResource]:
    """
    List folders in Clickzetta Studio project with filtering and pagination support.

    Args:
        arguments (dict): Arguments for the tool.
        db (Database): Database instance.
        write_detector (WriteDetector): Write detector instance.
        allow_write (bool): Whether write is allowed.
        server (Server): Server instance.

    Returns:
        str: Response message with folder list and pagination info.
    """
    if arguments is None:
        arguments = {}

    try:

        config = studio_config
        # Use config project ID if not provided
        project_id = config.project_id

        # Extract parameters
        parent_folder_id = arguments.get("parentFolderId", 0)
        folder_name = arguments.get("folderName")
        folder_type = arguments.get("folderType")
        page = arguments.get("page", 1)
        page_size = arguments.get("pageSize", 10)

        logger.info(f"Listing folders for project_id: {project_id}")

        # Call the API
        response = list_folders(
            project_id=project_id,
            parent_folder_id=parent_folder_id,
            folder_name=folder_name,
            folder_type=folder_type,
            page=page,
            page_size=page_size,
            jwt_token=config.token,
            instance_name=config.instance,
            env=config.env
        )

        # Parse and format the response
        response_data = json.loads(response)

        if response_data.get("code") == '200':
            data = response_data.get("data", {})
            folder_list = data.get("list", [])
            total = data.get("total", 0)
            total_pages = data.get("totalPages", 0)

            formatted_response = {
                "success": True,
                "message": f"Successfully retrieved {len(folder_list)} folders (page {page}/{total_pages})",
                "folders": folder_list,
                "pagination": {
                    "page": page,
                    "pageSize": page_size,
                    "total": total,
                    "totalPages": total_pages
                }
            }

            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[handle_list_folders]API request failed: {response_data}",
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in list folders: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


def list_folders_tool() -> List[Tool]:
    """
    Get list folders tool.

    Returns:
        List[Tool]: List of tools.
    """
    return [
        Tool(
            name="list_folders",
            description=(
                "List folders in a Clickzetta Studio project with support for filtering and pagination. "
                "Can list root folders, subfolders under a parent, search by name, or filter by folder type. "
                "Returns folder details including ID, name, type, location, and whether it has children.\n"
                "\n"
                "**Complete Task Discovery Workflow:**\n"
                "To retrieve ALL tasks (including draft/unsubmitted tasks), follow this process:\n"
                "  1. Call list_folders(parentFolderId=0) to get root-level folders\n"
                "  2. For each folder with hasChildren=true, recursively call list_folders(parentFolderId=<folder_id>)\n"
                "\n"
                "**Important Notes:**\n"
                "- Always check the 'hasChildren' field to determine if subfolders need to be queried\n"
                "- For complete task discovery, you must query ALL folders at ALL levels\n"
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "projectId": {
                        "type": "integer",
                        "description": "Optional. Project ID. If not provided, uses the configured project ID from connection settings."
                    },
                    "parentFolderId": {
                        "type": "integer",
                        "description": "Optional. Parent folder ID to list subfolders. Use 0 or omit to list root-level folders."
                    },
                    "folderName": {
                        "type": "string",
                        "description": "Optional. Folder name for fuzzy search filtering."
                    },
                    "folderType": {
                        "type": "integer",
                        "description": "Optional. Folder type filter (e.g., 1 for standard folder)."
                    },
                    "page": {
                        "type": "integer",
                        "description": "Optional. Page number for pagination. Default: 1.",
                        "default": 1
                    },
                    "pageSize": {
                        "type": "integer",
                        "description": "Optional. Number of items per page. Default: 10.",
                        "default": 10
                    }
                },
                "additionalProperties": False,
                "required": []
            },
            handler=handle_list_folders,
            tags=["studio", "project", "folders", "normalize"],
            samples=[
                {
                    "description": "List root-level folders",
                    "query": {
                        "parentFolderId": 0
                    }
                },
                {
                    "description": "List subfolders under parent folder 200",
                    "query": {
                        "parentFolderId": 200
                    }
                },
                {
                    "description": "Search folders by name with pagination",
                    "query": {
                        "folderName": "test",
                        "page": 1,
                        "pageSize": 20
                    }
                }
            ]
        )
    ]


async def handle_list_tasks(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    List tasks in a Clickzetta Studio folder with filtering and pagination support.

    This tool is typically the second step when users want to browse or query tasks.
    To list tasks, the user must first obtain the folder list using the list_folders tool (or equivalent directory-retrieval tool), and then choose a specific folder to query.

    If the user intends to retrieve *all tasks under the workspace*, they must perform
    a recursive directory traversal: first obtain all folders (including nested ones),
    then list tasks within each folder according to the directory hierarchy.
    Args:
        arguments (dict): Arguments for the tool.
        db (Database): Database instance.
        write_detector (WriteDetector): Write detector instance.
        allow_write (bool): Whether write is allowed.
        server (Server): Server instance.

    Returns:
        str: Response message with task list and pagination info.
    """
    if arguments is None:
        arguments = {}

    try:
        config = studio_config

        # Extract parameters
        project_id = config.project_id
        folder_id = arguments.get("folderId")
        task_name = arguments.get("taskName")
        task_type = arguments.get("taskType")
        file_type = None
        if task_type is not None:
            try:
                file_type = _convert_task_type_to_file_type(task_type)
            except ValueError:
                # If conversion fails, use task_type directly (might be FileType already)
                file_type = task_type
        page = arguments.get("page", 1)
        page_size = arguments.get("pageSize", 10)

        logger.info(f"Listing tasks for folder_id: {folder_id}")

        # Call the API
        response = list_files(
            project_id=project_id,
            folder_id=folder_id,
            file_name=task_name,
            file_type=file_type,
            page=page,
            page_size=page_size,
            jwt_token=config.token,
            instance_name=config.instance,
            env=config.env,
            workspace_name=config.workspace
        )

        # Parse and format the response
        response_data = json.loads(response)

        if response_data.get("code") == "200":
            data = response_data.get("data", {})
            task_list = data.get("list", [])
            total = data.get("total", 0)
            total_pages = data.get("totalPages", 0)

            # Convert field names to tool naming convention
            converted_tasks = [convert_task_detail_fields(task) for task in task_list]

            formatted_response = {
                "success": True,
                "message": f"Successfully retrieved {len(converted_tasks)} tasks (page {page}/{total_pages})",
                "tasks": converted_tasks,
                "pagination": {
                    "page": page,
                    "pageSize": page_size,
                    "total": total,
                    "totalPages": total_pages
                }
            }

            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[handle_list_tasks]API request failed: {response_data.get('message', 'Unknown error')}",
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in list tasks: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


def list_tasks_tool() -> List[Tool]:
    """
    Get list tasks tool.

    Returns:
        List[Tool]: List of tools.
    """

    return [
        Tool(
            name="list_clickzetta_tasks",
            description=(
                "List tasks in Clickzetta Studio. Returns tasks with optional filtering by folder, name, or type.\n"
                "\n"
                "**What This Tool Returns:**\n"
                "Returns tasks matching the specified filters, including:\n"
                "- ✅ Draft tasks (created but not yet submitted)\n"
                "- ✅ Submitted tasks (published to scheduler)\n"
                "- ✅ Tasks in any state or status\n"
                "- ✅ All task types (SQL, Shell, Python, Integration, Notebook, etc.)\n"
                "\n"
                "**Supported Task Types:**\n"
                f"{task_type_desc}\n"
                "\n"
                "**Common Usage Patterns:**\n"
                "- List all tasks: Don't specify folderId\n"
                "- List tasks in a specific folder: Provide folderId to filter by folder\n"
                "- Search by name: Use taskName parameter for fuzzy matching\n"
                "- Filter by type: Use taskType parameter (e.g., 4 for SQL tasks)\n"
                "- For quick name-based search across all folders, consider using search_task tool instead\n"
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "folderId": {
                        "type": "integer",
                        "description": "Optional. Folder ID to filter tasks by specific folder."
                    },
                    "taskName": {
                        "type": "string",
                        "description": "Optional. Task name for search filtering. Support fuzzy query by partial name."
                    },
                    "taskType": {
                        "type": "integer",
                        "description": f"Optional. Task type to filter by.{task_type_desc}\n"
                    },
                    "page": {
                        "type": "integer",
                        "description": "Optional. Page number for pagination. Default: 1."
                    },
                    "pageSize": {
                        "type": "integer",
                        "description": "Optional. Number of items per page. Default: 10."
                    }
                },
                "additionalProperties": False,
                "required": []
            },
            handler=handle_list_tasks,
            tags=["studio", "project", "tasks", "normalize"],
            samples=[
                {
                    "description": "List all tasks in folder 200",
                    "query": {
                        "page": 1,
                        "pageSize": 20
                    }
                },
                {
                    "description": "Search for tasks with 'test' in their name within folder 200",
                    "query": {
                        "folderId": 200,
                        "taskName": "test"
                    }
                },
                {
                    "description": "List data integration tasks (type 1) in folder 200 with pagination",
                    "query": {
                        "folderId": 200,
                        "taskType": 1,
                        "page": 2,
                        "pageSize": 20
                    }
                }
            ]
        )
    ]
