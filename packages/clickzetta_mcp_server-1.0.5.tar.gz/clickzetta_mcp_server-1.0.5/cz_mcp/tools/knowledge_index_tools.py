# coding=utf-8
"""
Create and query index for text type knowledges.
"""
import asyncio
import json
import os
from typing import List, Sequence

from aiohttp import ClientSession, ClientTimeout
from loguru import logger

from cz_mcp.common.utilities import ResponseBuilder
from cz_mcp.core.tool_registry import Tool
from ..studio_config_manager import StudioConfig
from ..utils.request_utils import RequestUtils

_RETRY_COUNT = 3
_RETRY_DELAY = 0.5  # seconds between retries


class RestProviderV2:
    def __init__(self, tenant_id: int, env: str):
        self.endpoint = "http://aliyun-sh-knowledge.clickzetta-inc.com"  # Hardcode to aliyun sh-prod
        self.tenant_id = tenant_id
        self.space = "mcp_" + env
        self.api_key = os.environ.get("KNOWLEDGE_API_KEY", "")  # Set via environment variable
        logger.info(f"Initializing rest db provider with endpoint: {self.endpoint}")

    # put a key into a space
    # meta is a string
    # k_id is the unique id in the space. If not provided, one will be generated and returned
    # tags is a list of tags associate with the key and tags can be used later as search filters
    # or deletion filters
    async def async_put(
            self,
            key: str,
            providers: Sequence,
            meta: str,
            tags: Sequence = (),
    ):
        # tags = ["column_name=xxxx","table_name=xxxx","indicator_id=xxx","dimension_id=xxx"]
        logger.info(
            f"put called with space: {self.space} key: {key} meta: {meta}, tags: {tags}"
        )
        url = f"{self.endpoint}/v2/put?tenant_id={self.tenant_id}&api_key={self.api_key}&space={self.space}&providers={','.join(providers)}"
        headers = {"content-type": "application/json"}
        payload = {
            "key": key,
            "meta": meta,
            "k_id": "",
            "tags": tags,
        }
        last_exc = None
        for attempt in range(1, _RETRY_COUNT + 1):
            try:
                async with ClientSession(timeout=ClientTimeout(total=300)) as session:
                    async with session.post(url, data=json.dumps(payload), headers=headers) as response:
                        if response.status != 200:
                            body = await response.text()
                            raise Exception(
                                f"async_put failed with HTTP {response.status}, body: {body}, url: {url}"
                            )
                        response_json = await response.json()
                        return response_json["result"]
            except Exception as e:
                last_exc = e
                if attempt < _RETRY_COUNT:
                    logger.warning(f"async_put attempt {attempt} failed: {e}, retrying in {_RETRY_DELAY}s...")
                    await asyncio.sleep(_RETRY_DELAY)
        raise last_exc

    async def async_search(
            self,
            key,
            limit,
            providers: Sequence,
            rerank: bool,
            max_distance: float = 1000.0,
            min_score: float = 0.0,
            tags: Sequence = (),
    ) -> list:
        logger.info(
            f"async_msearch called with space: {self.space}, key: {key}, limit: {limit}, max_instance: {max_distance}, min_score: {min_score}, providers: {providers}, tags: {tags}"
        )
        url = f"{self.endpoint}/v2/search?tenant_id={self.tenant_id}&api_key={self.api_key}&space={self.space}&providers={','.join(providers)}"
        headers = {"content-type": "application/json"}
        payload = {
            "key": key,
            "limit": limit,
            "rank_func": "Reranker" if rerank else "None",
            "max_distance": max_distance,
            "min_score": min_score,
            "tags": tags,
            "metric_aggressive": False,
        }
        last_exc = None
        for attempt in range(1, _RETRY_COUNT + 1):
            try:
                async with ClientSession(timeout=ClientTimeout(total=300)) as session:
                    async with session.post(url, data=json.dumps(payload), headers=headers) as response:
                        if response.status != 200:
                            body = await response.text()
                            raise Exception(
                                f"msearch failed with HTTP {response.status}, body: {body}, url: {url}"
                            )
                        response_json = await response.json()
                        return response_json["result"]
            except Exception as e:
                last_exc = e
                if attempt < _RETRY_COUNT:
                    logger.warning(f"async_search attempt {attempt} failed: {e}, retrying in {_RETRY_DELAY}s...")
                    await asyncio.sleep(_RETRY_DELAY)
        raise last_exc

    def create_space(self, providers: Sequence):
        logger.info(
            f"create_space called with space: {self.space}, providers: {providers}",
        )
        url = f"{self.endpoint}/v2/create_space?tenant_id={self.tenant_id}&api_key={self.api_key}&space={self.space}&providers={','.join(providers)}"
        response = RequestUtils().get(url=url)
        if response.status_code != 200:
            raise Exception(f"create_space failed with error {response.text}")
        return response.json()


async def handle_put_knowledge(arguments=None, studio_config: StudioConfig = None, **kwargs
):
    """
    This function puts a knowledge entry into the knowledge base with index created.
    """
    try:
        import httpx
        from cz_mcp.utils.config_utils import read_env_configuration, read_url, read_api

        config = studio_config
        if not config:
            return ResponseBuilder.create_error_response(
                error=ValueError(
                    "Server not initialized! db connection_config is None"
                ),
                context="create_dqc_rule",
            )

        env: str = config.env
        tenant_id: int = config.tenant_id

        key = arguments.get("key")
        meta = arguments.get("meta", "")
        tags = arguments.get("tags", [])
        index_list = arguments.get("index_list", ["vector"])

        if key is None or key.strip() == "":
            return ResponseBuilder.create_error_response(
                error=ValueError("key is required"),
                context="put_knowledge",
            )

        # input is vector or scalar or both
        # transfer to lh-vector and es
        index_providers = []
        for index in index_list:
            if index == "vector":
                index_providers.append("lh-vector")
            elif index == "scalar":
                index_providers.append("es")
        if len(index_providers) == 0:
            index_providers.append("lh-vector")

        kb_provider = RestProviderV2(tenant_id=tenant_id, env=env)
        try:
            kb_provider.create_space(providers=index_providers)
        except Exception as e:
            # swallow any exception and let put throw if failed
            pass

        await kb_provider.async_put(
            key=key,
            providers=index_providers,
            meta=meta,
            tags=tags,
        )

        formatted_response = {
            "success": True,
            "action": "created",
        }

        return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)

    except Exception as e:
        logger.exception(f"Error putting knowledge: {e}")
        return ResponseBuilder.create_error_response(error=e, context="put_knowledge")


async def handle_search_knowledge(arguments=None, studio_config: StudioConfig = None, **kwargs
):
    """
    This function searches knowledge entry from the knowledge base.
    """
    try:
        import httpx
        from cz_mcp.utils.config_utils import read_env_configuration, read_url, read_api

        config = studio_config
        if not config:
            return ResponseBuilder.create_error_response(
                error=ValueError(
                    "Server not initialized! db connection_config is None"
                ),
                context="handle_search_knowledge",
            )

        env: str = config.env
        tenant_id: int = config.tenant_id

        query = arguments.get("query")
        limit = arguments.get("limit", 8)
        rerank = arguments.get("rerank", False)
        max_distance = arguments.get("max_distance", 1000.0)
        min_score = arguments.get("min_score", 0.0)
        tags = arguments.get("tags", [])
        index_list = arguments.get("index_list", ["vector"])

        if query is None or query.strip() == "":
            return ResponseBuilder.create_error_response(
                error=ValueError("query is required"),
                context="search_knowledge",
            )

        # input is vector or scalar or both
        # transfer to lh-vector and es
        index_providers = []
        for index in index_list:
            if index == "vector":
                index_providers.append("lh-vector")
            elif index == "scalar":
                index_providers.append("es")

        if len(index_providers) == 0:
            index_providers.append("lh-vector")

        kb_provider = RestProviderV2(tenant_id=tenant_id, env=env)

        knowledges = await kb_provider.async_search(
            key=query,
            providers=index_providers,
            tags=tags,
            limit=limit,
            rerank=rerank,
            max_distance=max_distance,
            min_score=min_score,
        )

        formatted_response = {
            "success": True,
            "action": "created",
            "knowledges": knowledges,
        }

        return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)

    except Exception as e:
        logger.exception(f"Error putting knowledge: {e}")
        return ResponseBuilder.create_error_response(
            error=e, context="search_knowledge"
        )


async def handle_get_product_knowledge(arguments=None, studio_config: StudioConfig = None, **kwargs):
    try:
        query = arguments.get("query")
        limit = arguments.get("limit", 5)
        provider = RestProviderV2(
            tenant_id=107, env="prod"
        )  # tenant_id is not used in this context
        provider.space = "zetta_doc_qa"
        results = await provider.async_search(
            key=query,
            limit=limit,
            providers=["lh-vector"],
            rerank=False,
        )
        logger.debug(f"Search results for query: {results}")

        # Add progressive prompt for Corrective-RAG strategy
        corrective_rag_guidance = (
            "<CORRECTIVE-RAG EVALUATION REQUIRED>\n"
            "• Assess if these results are relevant to your query\n"
            "• If relevance is low, modify the query and call get_product_knowledge again\n"
            "• Try different keywords, remove high-weight terms (clickzetta, lakehouse, studio, 任务, 作业)\n"
            "• Maximum 3 attempts recommended for optimal results\n"
            "• Consider using more specific technical terms or Chinese keywords\n\n"
            "**IMPORTANT SQL ENGINE CONTEXT**:\n"
            "• This system uses Lakehouse SQL Engine (云器Lakehouse - 基于增量计算的云湖仓) with its own SQL dialect\n"
            "• Compatible with Spark basic syntax only\n"
            "• Stick to YunQi(云器) Lakehouse-specific SQL features and syntax to avoid confusion"
            "</CORRECTIVE-RAG EVALUATION REQUIRED>\n"
        )

        return ResponseBuilder.create_yaml_json_response(
            [{"results": results}],
            studio_config=studio_config,
            additional_user_preferences={"corrective_rag_guidance": corrective_rag_guidance}
        )
    except Exception as e:
        logger.exception(f"Error getting product knowledge: {e}")
        return ResponseBuilder.create_error_response(
            error=e, context="get_product_knowledge"
        )

def create_knowledge_tools() -> List[Tool]:
    """All knowledge-related tools"""

    tools = []

    # Create DQC Rule Tool
    tools.append(
        Tool(
            name="put_knowledge",
            description="Put a text knowledge entry into the knowledge base with index created.",
            input_schema={
                "type": "object",
                "properties": {
                    "key": {
                        "type": "string",
                        "description": "The text to index.",
                    },
                    "meta": {
                        "type": "string",
                        "description": "The meta information associated with the knowledge entry, will not be indexed but will be retrieved if a later search recalled this knowledge.",
                    },
                    "tags": {
                        "type": "array",
                        "description": "tags of this knowledge, can be used as search filters",
                        "items": {"type": "string"},
                        "default": [],
                    },
                    "index_list": {
                        "type": "array",
                        "description": "index_list of this knowledge, vector and/or scalar or both. default empty means vector index",
                        "items": {"type": "string"},
                        "default": [],
                    },
                },
                "required": ["key"],
            },
            handler=handle_put_knowledge,
            tags=["create", "execution", "normalize"],
            samples=[
                {
                    "key": "北京是中国的首都",
                    "meta": "This is a knowledge about Beijing.",
                    "tags": ["category=geography", "type=capital"],
                    "index_list": ["vector"],
                }
            ],
        )
    )

    tools.append(
        Tool(
            name="search_knowledge",
            description=(
                "Search manually entered and labeled knowledge base content, including successful cases and feedback.\n\n"
                "**SEARCH OPTIMIZATION RULES**:\n"
                "• Remove high-weight terms before querying: clickzetta, lakehouse, studio, 任务, 作业\n"
                "• Prioritize Chinese queries as embedding model is trained on Chinese\n"
                "• Retrieved results may be inaccurate, evaluate confidence and re-query if needed\n\n"
                "**NOTE**: This tool queries user-specific knowledge only. For product technical documentation, use get_product_knowledge tool."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "The text to search.",
                    },
                    "tags": {
                        "type": "array",
                        "description": "tags of will be used as search filters",
                        "items": {"type": "string"},
                        "default": [],
                    },
                    "index_list": {
                        "type": "array",
                        "description": "index_list to search from, vector and/or scalar or both. default empty means vector index",
                        "items": {"type": "string"},
                        "default": [],
                    },
                    "limit": {
                        "type": "integer",
                        "description": "maximum number of results to return",
                        "default": 8,
                    },
                    "rerank": {
                        "type": "boolean",
                        "description": "whether to rerank the results with reranking model",
                        "default": False,
                    },
                    "max_distance": {
                        "type": "number",
                        "description": "maximum distance for vector search",
                        "default": 1000.0,
                    },
                    "min_score": {
                        "type": "number",
                        "description": "minimum score for scalar search",
                        "default": 0.0,
                    },
                },
                "required": ["query"],
            },
            handler=handle_search_knowledge,
            tags=["execution", "normalize"],
            samples=[
                {
                    "query": "北京是中国的首都",
                },
                {
                    "query": "中国的首都是什么？",
                    "tags": ["category=geography"],
                    "limit": 3,
                },
                {
                    "query": "中国的首都是什么？",
                    "index_list": ["vector", "scalar"],
                    "limit": 5,
                    "rerank": True,
                },
                {
                    "query": "中国的首都是什么？",
                    "index_list": ["scalar"],
                    "limit": 5,
                    "min_score": 0.5,
                },
            ],
        ),
    )

    tools.append(
        Tool(
            name="get_product_knowledge",
            description=(
                "Search Clickzetta Lakehouse and Studio specification knowledge base for domain-specific "
                "technical documentation and product knowledge. To assist in answering questions about product features, usage, "
                "SQL dialects, APIs, java and python SDKs, configurations, and best practices.\n\n"
                "**SEARCH OPTIMIZATION RULES**:\n"
                "• Remove high-weight terms keyword before querying: clickzetta, lakehouse, studio, 任务, 作业\n"
                "• Prioritize Chinese queries as embedding model is trained on Chinese Tech Document\n"
                "• Retrieved results may be inaccurate, evaluate confidence and re-query if needed\n\n"
                "**IMPORTANT**: This tool searches PRODUCT DOCUMENTATION only. For user-specific "
                "knowledge (successful cases, feedback), use search_knowledge tool instead."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "The text to search.",
                    },
                    "limit": {
                        "type": "integer",
                        "description": "maximum number of results to return",
                        "default": 8,
                    },
                },
                "required": ["query"],
            },
            handler=handle_get_product_knowledge,
            tags=["execution", "normalize"],
            samples=[
                {
                    "query": "Java SDK 参考",
                },
                {
                    "query": "Java SDK 参考",
                    "limit": 3,
                },
            ],
        ),
    )

    return tools
