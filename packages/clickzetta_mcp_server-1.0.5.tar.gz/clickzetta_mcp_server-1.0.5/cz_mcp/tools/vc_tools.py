"""
Studio-specific tools for MCP Studio server
Handles vCluster listing and workspace environment queries
"""
import logging
import warnings
from typing import List, Any, Coroutine

from mcp.types import TextContent, EmbeddedResource

from cz_mcp.handlers.vc_server import vc_list as api_vc_list
from cz_mcp.handlers.vc_server import vc_create as api_vc_create
from ..common.utilities import ResponseBuilder
from ..core.tool_registry import Tool
from ..studio_config_manager import StudioConfig

from loguru import logger

def _normalize_api_response(response: Any) -> dict:
    """Normalize API response payload to dict."""
    if isinstance(response, dict):
        return response
    if isinstance(response, str):
        return json.loads(response)
    if hasattr(response, "json"):
        return response.json()
    raise TypeError(f"Unsupported response type: {type(response).__name__}")


async def handle_list_vcluster(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    List vClusters (virtual clusters) in Clickzetta Studio for a given workspace and instance.
    """
    if arguments is None:
        arguments = {}

    try:
        # Extract params
        workspace_id = arguments.get("workspace_id",studio_config.workspace_id)
        name = arguments.get("name","")
        config = studio_config

        token = config.token
        instance_name = config.instance
        env = config.env

        if not workspace_id:
            raise ValueError("Missing required fields: workspace_id")

        # Call the API
        response_raw = api_vc_list(
            workspace_id=workspace_id,
            jwt_token=token,
            instance_name=instance_name,
            user_id = config.user_id,
            instance_id = config.instance_id,
            account_id = config.tenant_id,
            env = env,
            name = name,
            workspace_name=config.workspace
        )
        response_data = _normalize_api_response(response_raw)

        if response_data.get("code") == "200":
            vclusters = response_data.get("data", [])
            formatted_response = {
                "success": True,
                "message": f"Successfully fetched {len(vclusters)} vClusters.",
                "count": len(vclusters),
                "vclusters": vclusters,
            }
            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"API request failed: {response_data.get('message', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


    except Exception as e:
        logger.error(f"Error in list_vcluster: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__,
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


async def handle_create_vcluster(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    Create a vCluster in Clickzetta Studio for the current workspace.
    """
    if arguments is None:
        arguments = {}

    try:
        config = studio_config
        workspace_id = arguments.get("workspace_id", config.workspace_id)
        vc_name = arguments.get("vc_name")
        vc_type = arguments.get("vc_type")

        min_size = arguments.get("min_size")
        max_size = arguments.get("max_size")
        ap_max_concurrency = arguments.get("ap_max_concurrency")
        ap_size = arguments.get("ap_size")

        if not workspace_id:
            raise ValueError("Missing required fields: workspace_id")
        if not vc_name:
            raise ValueError("Missing required fields: vc_name")
        if not vc_type:
            raise ValueError("Missing required fields: vc_type")

        vc_type = vc_type.upper()
        if vc_type == "GENERAL":
            if min_size is None:
                min_size = 1
            if max_size is None:
                max_size = 2
        elif vc_type == "INTEGRATION":
            if min_size is None:
                min_size = 0.25
            if max_size is None:
                max_size = 1
        elif vc_type == "ANALYTICS":
            if min_size is None:
                min_size = 1
            if max_size is None:
                max_size = 2
            if ap_max_concurrency is None:
                ap_max_concurrency = 16
            if ap_size is None:
                ap_size = 2
        else:
            raise ValueError("vc_type must be one of GENERAL, INTEGRATION, ANALYTICS")

        response_raw = api_vc_create(
            workspace_id=workspace_id,
            jwt_token=config.token,
            instance_name=config.instance,
            user_id=config.user_id,
            instance_id=config.instance_id,
            account_id=config.tenant_id,
            env=config.env,
            vc_name=vc_name,
            vc_type=vc_type,
            minSize=min_size,
            maxSize=max_size,
            apMaxConcurrency=ap_max_concurrency,
            apSize=ap_size,
        )
        response_data = _normalize_api_response(response_raw)

        if response_data.get("code") == "200":
            data = response_data.get("data", {})
            formatted_response = {
                "success": True,
                "message": f"Successfully created vCluster '{vc_name}'.",
                "vcluster": data,
            }
            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)

        error_response = {
            "success": False,
            "message": f"API request failed: {response_data.get('message', 'Unknown error')}",
            "code": response_data.get("code"),
            "raw_response": response_data
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)
    except Exception as e:
        logger.error(f"Error in create_vcluster: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__,
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


def list_vcluster_tool() -> List[Tool]:
    """Get the vCluster listing tool"""

    return [
        Tool(
            name="list_vcluster",
            description=(
                "List all available virtual clusters (vClusters) under a specific workspace and instance "
                "in Clickzetta Studio. This tool queries the Clickzetta LakeConsole API to retrieve environment "
                "cluster information associated with a given workspaceId and instanceId."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Optional fuzzy filter for vCluster name. Returns only clusters whose names contain this value."
                    }
                },
                "additionalProperties": False,
                "required": [],
            },
            handler=handle_list_vcluster,
            tags=["studio", "vcluster"],
            samples=[
                {
                    "description": "List all vClusters whose names contain 'sync'",
                    "query": {
                        "name": "sync"
                    }
                }
            ]
        )
    ]


def create_vcluster_tool() -> List[Tool]:
    """Get vCluster creation tool"""
    return [
        Tool(
            name="create_vcluster",
            description=(
                "Create a new virtual cluster (vCluster) in the current Clickzetta workspace. "
                "Supports vc types GENERAL, INTEGRATION, and ANALYTICS. "
                "min_size and max_size are optional. "
                "For GENERAL: min_size defaults to 1, max_size supports 1-4 and defaults to 2. "
                "For INTEGRATION: min_size defaults to 0.25, max_size supports 1-2 and defaults to 1, where 2 is the maximum. "
                "For ANALYTICS: min_size defaults to 1, max_size defaults to 2, ap_max_concurrency defaults to 16, and ap_size defaults to 2."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "vc_name": {
                        "type": "string",
                        "description": "Name of the vCluster to create. MUST in upper case"
                    },
                    "vc_type": {
                        "type": "string",
                        "description": "vCluster type, such as INTEGRATION, GENERAL, or ANALYTICS."
                    },
                    "min_size": {
                        "type": "number",
                        "description": "Optional minimum size/replicas. Supports decimals such as 0.25 for INTEGRATION. Defaults: GENERAL=1, INTEGRATION=0.25, ANALYTICS=1."
                    },
                    "max_size": {
                        "type": "number",
                        "description": "Optional maximum size/replicas. Defaults: GENERAL=2 with allowed range 1-4, INTEGRATION=1 with allowed range 1-2, ANALYTICS=2."
                    },
                    "ap_max_concurrency": {
                        "type": "integer",
                        "description": "Optional ANALYTICS-only setting: maximum concurrency. Default is 16."
                    },
                    "ap_size": {
                        "type": "integer",
                        "description": "Optional ANALYTICS-only setting: AP compute size. Default is 2."
                    }
                },
                "additionalProperties": False,
                "required": ["vc_name", "vc_type"],
            },
            handler=handle_create_vcluster,
            tags=["studio", "vcluster"],
            samples=[
                {
                    "description": "Create an integration vCluster for data sync workloads",
                    "query": {
                        "vc_name": "sync_vc_prod",
                        "vc_type": "INTEGRATION",
                        "min_size": 0.25,
                        "max_size": 1
                    }
                }
            ]
        )
    ]
