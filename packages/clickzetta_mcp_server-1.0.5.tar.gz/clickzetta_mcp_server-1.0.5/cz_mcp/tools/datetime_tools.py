"""
DateTime Tools for MCP Server
提供日期时间相关的工具，包括获取当前时间和日期格式转换
"""

import logging
from datetime import datetime
from typing import Any, Dict, Optional, Coroutine
from zoneinfo import ZoneInfo

from mcp.types import TextContent, EmbeddedResource

from cz_mcp.common.utilities import ResponseBuilder
from cz_mcp.core.tool_registry import Tool
from cz_mcp.studio_config_manager import StudioConfig

from loguru import logger


async def handle_get_current_datetime(arguments=None, studio_config: StudioConfig = None, **kwargs
) -> list[TextContent | EmbeddedResource]:
    """
    获取当前日期时间的处理器

    Args:
        arguments: 包含时区和格式参数
        db: 数据库连接
        writer_detector: 写操作检测器
        enable_init_retry: 是否启用重试
        server_core: 服务器核心实例

    Returns:
        包含当前日期时间信息的响应列表
    """
    try:
        timezone = arguments.get('timezone', 'Asia/Shanghai')
        format_type = arguments.get('format', 'all')

        # 获取指定时区的当前时间
        try:
            tz = ZoneInfo(timezone)
        except Exception as e:
            logger.warning(f"Invalid timezone: {timezone}, falling back to Asia/Shanghai. Error: {e}")
            tz = ZoneInfo('Asia/Shanghai')
            timezone = 'Asia/Shanghai'

        now = datetime.now(tz)

        # 准备返回数据
        result = {
            "timezone": timezone,
        }

        # 根据 format_type 返回不同格式
        if format_type in ['all', 'timestamp']:
            result['timestamp'] = int(now.timestamp())
            result['timestamp_ms'] = int(now.timestamp() * 1000)

        if format_type in ['all', 'mysql']:
            result['mysql_datetime'] = now.strftime('%Y-%m-%d %H:%M:%S')
            result['mysql_date'] = now.strftime('%Y-%m-%d')
            result['mysql_time'] = now.strftime('%H:%M:%S')

        if format_type in ['all', 'iso']:
            result['iso_format'] = now.isoformat()

        if format_type in ['all', 'components']:
            result['year'] = now.year
            result['month'] = now.month
            result['day'] = now.day
            result['hour'] = now.hour
            result['minute'] = now.minute
            result['second'] = now.second
            result['weekday'] = now.strftime('%A')

        logger.info(f"Generated current datetime for timezone {timezone}: {result}")

        return ResponseBuilder.create_yaml_json_response([{
            "status": "success",
            "data": result,
            "message": f"Current datetime in {timezone}"
        }])

    except Exception as e:
        logger.error(f"Failed to get current datetime: {e}")
        return ResponseBuilder.create_yaml_json_response([{
            "success": False,
            "message": f"Failed to get current datetime: {str(e)}"
        }])


async def handle_parse_datetime(arguments=None, studio_config: StudioConfig = None, **kwargs
) -> list[TextContent | EmbeddedResource]:
    """
    日期时间格式转换的处理器

    Args:
        arguments: 包含输入值和目标格式参数
        db: 数据库连接
        writer_detector: 写操作检测器
        enable_init_retry: 是否启用重试
        server_core: 服务器核心实例

    Returns:
        包含转换后日期时间的响应列表
    """
    try:
        input_value = arguments.get('input_value')
        input_type = arguments.get('input_type', 'auto')
        output_format = arguments.get('output_format', 'all')
        timezone = arguments.get('timezone', 'Asia/Shanghai')

        if not input_value:
            return ResponseBuilder.create_yaml_json_response([{
                "status": "error",
                "message": "input_value is required"
            }])

        # 获取时区
        try:
            tz = ZoneInfo(timezone)
        except Exception as e:
            logger.warning(f"Invalid timezone: {timezone}, falling back to Asia/Shanghai. Error: {e}")
            tz = ZoneInfo('Asia/Shanghai')
            timezone = 'Asia/Shanghai'

        # 解析输入
        dt: Optional[datetime] = None

        if input_type == 'auto':
            # 自动检测输入类型
            # 尝试解析为时间戳
            try:
                if isinstance(input_value, (int, float)) or (isinstance(input_value, str) and input_value.isdigit()):
                    timestamp = float(input_value)
                    # 判断是秒还是毫秒
                    if timestamp > 1e11:  # 毫秒级时间戳
                        timestamp = timestamp / 1000
                    dt = datetime.fromtimestamp(timestamp, tz=tz)
                    input_type = 'timestamp'
            except (ValueError, OSError):
                pass

            # 如果不是时间戳，尝试解析为日期字符串
            if dt is None:
                # 尝试多种常见格式
                formats_to_try = [
                    '%Y-%m-%d %H:%M:%S',
                    '%Y-%m-%d',
                    '%Y/%m/%d %H:%M:%S',
                    '%Y/%m/%d',
                    '%Y-%m-%dT%H:%M:%S',
                    '%Y-%m-%d %H:%M:%S.%f',
                ]

                for fmt in formats_to_try:
                    try:
                        dt = datetime.strptime(str(input_value), fmt)
                        dt = dt.replace(tzinfo=tz)
                        input_type = 'datetime_string'
                        break
                    except ValueError:
                        continue

        elif input_type == 'timestamp':
            timestamp = float(input_value)
            if timestamp > 1e11:  # 毫秒级时间戳
                timestamp = timestamp / 1000
            dt = datetime.fromtimestamp(timestamp, tz=tz)

        elif input_type == 'mysql_datetime':
            dt = datetime.strptime(str(input_value), '%Y-%m-%d %H:%M:%S')
            dt = dt.replace(tzinfo=tz)

        elif input_type == 'mysql_date':
            dt = datetime.strptime(str(input_value), '%Y-%m-%d')
            dt = dt.replace(tzinfo=tz)

        elif input_type == 'iso':
            dt = datetime.fromisoformat(str(input_value))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=tz)

        if dt is None:
            return ResponseBuilder.create_yaml_json_response([{
                "status": "error",
                "message": f"Failed to parse input_value: {input_value}. Please specify input_type or use a supported format."
            }])

        # 准备返回数据
        result = {
            "input_value": input_value,
            "detected_input_type": input_type,
            "timezone": timezone,
        }

        # 根据 output_format 返回不同格式
        if output_format in ['all', 'timestamp']:
            result['timestamp'] = int(dt.timestamp())
            result['timestamp_ms'] = int(dt.timestamp() * 1000)

        if output_format in ['all', 'mysql']:
            result['mysql_datetime'] = dt.strftime('%Y-%m-%d %H:%M:%S')
            result['mysql_date'] = dt.strftime('%Y-%m-%d')
            result['mysql_time'] = dt.strftime('%H:%M:%S')

        if output_format in ['all', 'iso']:
            result['iso_format'] = dt.isoformat()

        if output_format in ['all', 'components']:
            result['year'] = dt.year
            result['month'] = dt.month
            result['day'] = dt.day
            result['hour'] = dt.hour
            result['minute'] = dt.minute
            result['second'] = dt.second
            result['weekday'] = dt.strftime('%A')

        logger.info(f"Parsed datetime: {result}")

        return ResponseBuilder.create_yaml_json_response([{
            "status": "success",
            "data": result,
            "message": f"Successfully parsed datetime"
        }])

    except Exception as e:
        logger.error(f"Failed to parse datetime: {e}")
        return ResponseBuilder.create_yaml_json_response([{
            "success": False,
            "message": f"Failed to parse datetime: {str(e)}"
        }])


def get_current_datetime_tool():
    """创建获取当前日期时间的工具"""
    return [Tool(
        name="get_current_datetime",
        description=(
            "Get current date and time in various formats. "
            "Returns timestamp (Unix epoch in seconds and milliseconds), "
            "MySQL datetime format (YYYY-MM-DD HH:MM:SS), "
            "ISO format, and individual date/time components. "
            "Supports multiple timezones."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "timezone": {
                    "type": "string",
                    "description": (
                        "Timezone for the datetime (e.g., 'Asia/Shanghai', 'UTC', 'America/New_York'). "
                        "Defaults to 'Asia/Shanghai'."
                    ),
                    "default": "Asia/Shanghai"
                },
                "format": {
                    "type": "string",
                    "enum": ["all", "timestamp", "mysql", "iso", "components"],
                    "description": (
                        "Output format type:\n"
                        "- all: Return all available formats\n"
                        "- timestamp: Return Unix timestamp (seconds and milliseconds)\n"
                        "- mysql: Return MySQL datetime formats (datetime, date, time)\n"
                        "- iso: Return ISO 8601 format\n"
                        "- components: Return individual date/time components (year, month, day, etc.)"
                    ),
                    "default": "all"
                }
            },
            "required": []
        },
        handler=handle_get_current_datetime,
        tags=["datetime", "utility"]
    )]


def parse_datetime_tool():
    """创建日期时间解析工具"""
    return [Tool(
        name="parse_datetime",
        description=(
            "Parse and convert datetime between different formats. "
            "Supports automatic detection of input format or explicit specification. "
            "Can convert between Unix timestamp, MySQL datetime, ISO format, and extract components. "
            "Handles both seconds and milliseconds timestamps."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "input_value": {
                    "type": "string",
                    "description": (
                        "The datetime value to parse. Can be:\n"
                        "- Unix timestamp (seconds or milliseconds, e.g., 1609459200 or 1609459200000)\n"
                        "- MySQL datetime (e.g., '2021-01-01 00:00:00')\n"
                        "- MySQL date (e.g., '2021-01-01')\n"
                        "- ISO format (e.g., '2021-01-01T00:00:00')\n"
                        "- Other common datetime string formats"
                    )
                },
                "input_type": {
                    "type": "string",
                    "enum": ["auto", "timestamp", "mysql_datetime", "mysql_date", "iso"],
                    "description": (
                        "Type of the input value. Use 'auto' for automatic detection. "
                        "Explicit types: timestamp, mysql_datetime, mysql_date, iso"
                    ),
                    "default": "auto"
                },
                "output_format": {
                    "type": "string",
                    "enum": ["all", "timestamp", "mysql", "iso", "components"],
                    "description": (
                        "Output format type:\n"
                        "- all: Return all available formats\n"
                        "- timestamp: Return Unix timestamp (seconds and milliseconds)\n"
                        "- mysql: Return MySQL datetime formats (datetime, date, time)\n"
                        "- iso: Return ISO 8601 format\n"
                        "- components: Return individual date/time components"
                    ),
                    "default": "all"
                },
                "timezone": {
                    "type": "string",
                    "description": (
                        "Timezone for the datetime interpretation (e.g., 'Asia/Shanghai', 'UTC'). "
                        "Defaults to 'Asia/Shanghai'."
                    ),
                    "default": "Asia/Shanghai"
                }
            },
            "required": ["input_value"]
        },
        handler=handle_parse_datetime,
        tags=["datetime", "utility", "parser"]
    )]


def get_datetime_tools():
    """获取所有日期时间工具"""
    tools = []
    tools.extend(get_current_datetime_tool())
    tools.extend(parse_datetime_tool())
    return tools
