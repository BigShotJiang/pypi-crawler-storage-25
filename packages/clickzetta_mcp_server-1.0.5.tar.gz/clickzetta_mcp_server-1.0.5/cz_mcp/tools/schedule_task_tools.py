# coding=utf-8
"""
Studio-specific tools for MCP Studio server
Handles Studio API interactions for scheduled task management
"""
import json
import logging
from typing import List, Optional, Any, Coroutine

from mcp.types import TextContent, EmbeddedResource

from cz_mcp.common.utilities import ResponseBuilder
from cz_mcp.core.tool_registry import Tool
from cz_mcp.handlers.ide_admin_server import task_relation as api_task_relation
from cz_mcp.handlers.ide_admin_server import get_task_statistics as api_get_task_statistics
from cz_mcp.tools.file_tools import _convert_task_type_to_file_type, _convert_file_type_to_task_type
from ..common.task_type import REALTIME_TASK_TYPE_MAP, OFFLINE_TASK_TYPE_MAP

from ..studio_config_manager import StudioConfig
from loguru import logger

task_type_desc = "Available offline task types:\n"
task_type_desc += "\n".join([f"  - {int(ft)}: {name}" for ft, name in sorted(OFFLINE_TASK_TYPE_MAP.items())])
task_type_desc += "Available realtime task types:\n"
task_type_desc += "\n".join([f"  - {int(ft)}: {name}" for ft, name in sorted(REALTIME_TASK_TYPE_MAP.items())])


def convert_task_statistics_fields(api_data: dict) -> dict:
    """
    Convert API response fields for task statistics to tool naming convention.
    
    Field mappings:
    - fileType -> task_type (converted from FileType to TaskType)
    - fileFlowStatus -> task_edit_state
    - owner -> task_owner
    - cnt -> count
    
    Args:
        api_data: Dictionary from API response
        
    Returns:
        Dictionary with converted field names
    """
    if api_data is None:
        return {}
    
    field_mapping = {
        "fileFlowStatus": "task_edit_state",
        "owner": "task_owner",
        "cnt": "count",
    }
    
    converted = {}
    for key, value in api_data.items():
        # Only include fields that are in the mapping, skip others
        if key in field_mapping:
            new_key = field_mapping[key]
            converted[new_key] = value
        elif key == "fileType":
            # Special handling: convert FileType to TaskType
            try:
                task_type = _convert_file_type_to_task_type(value)
                converted["task_type"] = task_type
            except ValueError:
                # If conversion fails, skip this field
                logger.warning(f"Failed to convert fileType {value} to taskType, skipping")
        else:
            # Keep other fields as-is
            converted[key] = value
    
    return converted


def convert_published_task_relation_fields(api_data: dict) -> dict:
    """
    Convert API response fields for published task relation to tool naming convention.
    
    Field mappings:
    - tenantId -> tenant_id
    - projectId -> project_id
    - projectName -> project_name
    - scheduleTaskId -> task_id
    - scheduleTaskName -> task_name
    - taskStatus -> task_status
    - cycleTaskType -> task_type
    - scheduleRateType -> schedule_rate_type
    - taskOwnerUserName -> task_owner_user_name
    - taskOwnerUserId -> task_owner_user_id
    - createTime -> create_time
    - updateTime -> update_time
    - publishTime -> publish_time
    - nextLevelCount -> next_level_count
    - instanceCount -> instance_count
    - lastInstanceStatus -> last_instance_status
    - childScheduleTaskBeans -> child_tasks (recursively converted)
    - parentScheduleTaskBeans -> parent_tasks (recursively converted)
    
    Args:
        api_data: Dictionary from API response
        
    Returns:
        Dictionary with converted field names
    """
    if api_data is None:
        return {}
    
    field_mapping = {
        # Core fields
        "tenantId": "tenant_id",
        "projectId": "project_id",
        "projectName": "project_name",
        "scheduleTaskId": "task_id",
        "scheduleTaskName": "task_name",
        "taskStatus": "task_status",
        "cycleTaskType": "task_type",
        "scheduleRateType": "schedule_rate_type",
        
        # Owner fields
        "taskOwnerUserName": "task_owner_user_name",
        "taskOwnerUserId": "task_owner_user_id",
        
        # Time fields
        "createTime": "create_time",
        "updateTime": "update_time",
        "publishTime": "publish_time",
        
        # Count and status fields
        "nextLevelCount": "next_level_count",
        "instanceCount": "task_run_count",
        "lastInstanceStatus": "last_run_status",
    }
    
    converted = {}
    for key, value in api_data.items():
        # Only include fields that are in the mapping, skip others
        if key in field_mapping:
            new_key = field_mapping[key]
            converted[new_key] = value
        elif key == "childScheduleTaskBeans":
            # Recursively convert child tasks
            if isinstance(value, list):
                converted["child_tasks"] = [
                    convert_published_task_relation_fields(item) for item in value
                ]
            else:
                converted["child_tasks"] = value
        elif key == "parentScheduleTaskBeans":
            # Recursively convert parent tasks
            if isinstance(value, list):
                converted["parent_tasks"] = [
                    convert_published_task_relation_fields(item) for item in value
                ]
            elif value is None:
                converted["parent_tasks"] = None
            else:
                converted["parent_tasks"] = value
        else:
            # Skip fields not in mapping
            pass
    
    return converted


async def handle_get_published_task_relation(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    get published task relations in Clickzetta Studio
    """
    if arguments is None:
        arguments = {}

    try:
        # Extract parameters
        project_id = arguments.get("project_id")
        schedule_task_id = arguments.get("task_id")

        child_level = arguments.get("child_level", 1)
        parent_level = arguments.get("parent_level", 1)

        # Get auth context from server core
        config = studio_config
        if project_id is None:
            project_id = config.project_id
        # Use config project ID if not provided


        logger.info(f"Getting task relation for task {schedule_task_id} and project_id: {project_id}")

        # Call the API
        response = api_task_relation(
            projectId=project_id,
            scheduleTaskId=schedule_task_id,
            parentLevel=parent_level,
            childLevel=child_level,
            jwt_token=config.token,
            instance_name=config.instance,
            env=config.env,
            workspace_name=config.workspace
        )

        # Parse and format the response
        response_data = json.loads(response)

        if response_data.get("code") == "200":
            data = response_data.get("data", {})
            
            # Convert field names to tool naming convention
            converted_data = convert_published_task_relation_fields(data)

            # Format the response for better readability
            formatted_response = {
                "success": True,
                "message": "Successfully get published task relation",
                "graph": converted_data
            }

            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[handle_get_schedule_task_relation]API request failed: {response_data.get('msg', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in get task relation: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


async def handle_get_task_statistics(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    Get task statistics in Clickzetta Studio.
    
    Returns aggregated statistics for tasks matching the filter conditions.
    """
    if arguments is None:
        arguments = {}

    try:
        # Extract parameters
        project_id = arguments.get("project_id")
        task_name_like = arguments.get("task_name_like")
        task_owner = arguments.get("task_owner")
        task_type = arguments.get("task_type")
        task_edit_state = arguments.get("task_edit_state")

        # Get auth context from server core
        config = studio_config
        if project_id is None:
            project_id = config.project_id

        # Convert TaskType to FileType for API
        file_type = None
        if task_type is not None:
            try:
                file_type = _convert_task_type_to_file_type(task_type)
            except ValueError:
                # If conversion fails, use task_type directly (might be FileType already)
                file_type = task_type

        logger.info(f"Getting task statistics for project_id: {project_id}")

        # Call the API
        response = api_get_task_statistics(
            projectId=project_id,
            taskNameLike=task_name_like,
            taskOwner=task_owner,
            fileType=file_type,
            fileFlowStatus=task_edit_state,
            jwt_token=config.token,
            instance_name=config.instance,
            user_id=config.user_id,
            instance_id=config.instance_id,
            account_id=config.tenant_id,
            env=config.env,
            workspace_name=config.workspace
        )

        # Parse and format the response
        response_data = json.loads(response)

        if response_data.get("code") == "200":
            data = response_data.get("data", [])
            
            # Convert field names to tool naming convention
            if isinstance(data, list):
                converted_stats = [convert_task_statistics_fields(stat) for stat in data]
            else:
                # If data is not a list, wrap it
                converted_stats = [convert_task_statistics_fields(data)] if data else []

            # Format the response for better readability
            formatted_response = {
                "success": True,
                "message": "Successfully get task statistics",
                "statistics": converted_stats
            }

            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[handle_get_task_statistics]API request failed: {response_data.get('msg', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in get task statistics: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


def get_task_statistics_tools() -> List[Tool]:
    """Get task statistics tools"""
    return [
        Tool(
            name="get_task_statistics",
            description=(
                "Get task statistics aggregated by task in Clickzetta Studio. "
                "Supports filtering by project space, task name pattern (like), "
                "task owner, task type, and task edit state. "
                "\n\n"
                "**When to Use This Tool:**\n"
                "✅ **PRIORITIZE this tool** when users ask vague questions about tasks, such as:\n"
                "- 'What tasks do I have?'\n"
                "- 'What's my task status?'\n"
                "- 'Show me task statistics'\n"
                "- 'How many tasks are there?'\n"
                "- 'What's the task situation?'\n"
                "\n"
                "❌ **DO NOT use this tool** when users explicitly request:\n"
                "- 'List all my tasks' (use list_tasks instead)\n"
                "- 'Show me task details' (use get_task_detail instead)\n"
                "- 'Get specific task information' (use get_task_detail instead)\n"
                "\n"
                "**Aggregation Dimensions:**\n"
                "The returned statistics are aggregated by three dimensions:\n"
                f"- Task type (task_type)\n Available values:{task_type_desc}, USE TaskType.name instead of integer value to response"
                "- Task edit state (task_edit_state)\n Available values: 10= WAIT_FOR_SAVE, 20=WAIT_FOR_PUBLISH, 80=MODIFIED_AFTER_PUBLISH, 100=PUBLISHED"
                "- Task owner (task_owner)\n"
                "\n"
                "**Secondary Aggregation:**\n"
                "If the user needs higher-level aggregation (e.g., aggregated only by task owner, "
                "or only by task type), you need to perform secondary aggregation on the returned data. "
                "For example, to get statistics grouped only by task owner, sum up the 'count' field "
                "for all records with the same 'task_owner' value."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "project_id": {
                        "type": "integer",
                        "description": "Project space ID. Optional; defaults to current project if not provided."
                    },
                    "task_name_like": {
                        "type": "string",
                        "description": (
                            "Task name pattern filter (partial match). "
                            "Optional; returns all tasks if omitted."
                        )
                    },
                    "task_owner": {
                        "type": "string",
                        "description": (
                            "Task owner filter (English name). "
                            "Optional; returns all tasks if omitted."
                        )
                    },
                    "task_type": {
                        "type": "integer",
                        "description": (
                            "Task type filter "
                            "Optional; returns all task types if omitted. "
                            f"Supported Values: {task_type_desc}"
                        )
                    },
                    "task_edit_state": {
                        "type": "integer",
                        "description": (
                            "Task edit state filter (fileFlowStatus). "
                            "Optional; returns all states if omitted. "
                            "Common values: 100 = Draft, 200 = Submitted, etc."
                        )
                    }
                },
                "additionalProperties": False,
                "required": []
            },
            handler=handle_get_task_statistics,
            tags=["schedule", "task_statistics", "statistics", "aggregation"],
            samples=[
                {
                    "description": "Get statistics for all tasks in project 2001.",
                    "query": {
                        "project_id": 2001
                    }
                },
                {
                    "description": "Get statistics for SQL tasks with name containing 'etl'.",
                    "query": {
                        "task_name_like": "etl",
                        "task_type": 23
                    }
                },
                {
                    "description": "Get statistics for tasks owned by a specific user.",
                    "query": {
                        "task_owner": "user123"
                    }
                }
            ]
        ),
    ]


def get_published_task_dependencies_tools() -> List[Tool]:
    """Get all Studio-specific tools"""
    return [
        Tool(
            name="get_published_task_dependencies",
            description=(
                "Get upstream and downstream dependency tasks of a specific published task. "
                "Returns dependency information as a tree structure, with configurable "
                "parent (upstream) and child (downstream) depth levels."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "project_id": {
                        "type": "integer",
                        "description": "Project space ID of the task. Optional."
                    },
                    "task_id": {
                        "type": "integer",
                        "description": "Task ID for which to retrieve dependency relations. Required."
                    },
                    "parent_level": {
                        "type": "integer",
                        "description": (
                            "Number of upstream dependency levels to retrieve. "
                            "Default is 1."
                        ),
                        "default": 1
                    },
                    "child_level": {
                        "type": "integer",
                        "description": (
                            "Number of downstream dependency levels to retrieve. "
                            "Default is 1."
                        ),
                        "default": 1
                    }
                },
                "additionalProperties": False,
                "required": ["task_id"]
            },
            handler=handle_get_published_task_relation,
            tags=["task_relation", "dependency", "graph"],
            samples=[
                {
                    "description": "Get 1-level upstream and downstream dependencies for task 9001 under project 2001.",
                    "query": {
                        "project_id": 2001,
                        "schedule_task_id": 9001,
                        "parent_level": 1,
                        "child_level": 1
                    }
                },
                {
                    "description": "Get 3 levels of upstream and 2 levels of downstream dependencies for the given task.",
                    "query": {
                        "project_id": 2001,
                        "schedule_task_id": 9001,
                        "parent_level": 3,
                        "child_level": 2
                    }
                }
            ]
        ),
    ]
