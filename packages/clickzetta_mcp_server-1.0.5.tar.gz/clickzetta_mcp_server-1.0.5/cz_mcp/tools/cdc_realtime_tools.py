"""
Multi-Table Real-Time CDC Task Tools
"""

import json
import logging
from typing import List, Dict, Any, Optional

from mcp.types import TextContent, EmbeddedResource

from ..core.tool_registry import Tool
from ..common.utilities import ResponseBuilder
from ..handlers.ide_admin_server import save_cdc_task
from ..studio_config_manager import StudioConfig

from loguru import logger


async def handle_save_cdc_realtime_task(
    arguments=None, studio_config: StudioConfig = None, **kwargs
) -> list[TextContent | EmbeddedResource]:
    """
    Save multi-table real-time CDC task configuration
    """
    if arguments is None:
        arguments = {}

    try:
        # Extract parameters
        data_file_id = arguments.get("data_file_id")
        pipeline_type = arguments.get(
            "pipeline_type", 3
        )  # Default to 3 for whole database mirror
        save_mode = arguments.get("save_mode", 2)  # Default to 2 for append
        sync_mode = arguments.get("sync_mode", 1)  # Default to 1 for full+incremental
        source_datasource_list = arguments.get("source_datasource_list", [])
        sync_object_list = arguments.get("sync_object_list", [])
        target_datasource = arguments.get("target_datasource", {})

        # Validate required parameters
        if not data_file_id:
            return ResponseBuilder.create_yaml_json_response(
                [
                    {
                        "success": False,
                        "message": "Missing required parameter: data_file_id",
                    }
                ],
                studio_config=studio_config,
            )

        if not source_datasource_list:
            return ResponseBuilder.create_yaml_json_response(
                [
                    {
                        "success": False,
                        "message": "Missing required parameter: source_datasource_list (at least one source datasource required)",
                    }
                ],
                studio_config=studio_config,
            )

        if not sync_object_list:
            return ResponseBuilder.create_yaml_json_response(
                [
                    {
                        "success": False,
                        "message": "Missing required parameter: sync_object_list (at least one sync object required)",
                    }
                ],
                studio_config=studio_config,
            )

        if not target_datasource:
            return ResponseBuilder.create_yaml_json_response(
                [
                    {
                        "success": False,
                        "message": "Missing required parameter: target_datasource",
                    }
                ],
                studio_config=studio_config,
            )

        # Validate source datasource types (5\19\39=MySQL, 7\40\48=PostgreSQL, 8=SQL Server, 17=TiDB)
        valid_source_types = [5, 7, 8, 19, 39, 17, 40, 48]
        for source_ds in source_datasource_list:
            ds_type = source_ds.get("datasourceType")
            if ds_type not in valid_source_types:
                return ResponseBuilder.create_yaml_json_response(
                    [
                        {
                            "success": False,
                            "message": f"Invalid source datasource type: {ds_type}. Only MySQL (5\19\39), PostgreSQL (7\40\48), and SQL Server (8) are supported.",
                        }
                    ],
                    studio_config=studio_config,
                )

        # Validate target datasource type (1=Lakehouse, 2=Kafka)
        valid_target_types = [1, 2]
        target_type = target_datasource.get("datasourceType")
        if target_type not in valid_target_types:
            return ResponseBuilder.create_yaml_json_response(
                [
                    {
                        "success": False,
                        "message": f"Invalid target datasource type: {target_type}. Only Lakehouse (1) and Kafka (2) are supported.",
                    }
                ],
                studio_config=studio_config,
            )

        logger.info(f"Saving CDC real-time task for data_file_id: {data_file_id}")

        # Call the API
        response = save_cdc_task(
            project_id=studio_config.project_id,
            data_file_id=data_file_id,
            pipeline_type=pipeline_type,
            save_mode=save_mode,
            sync_mode=sync_mode,
            source_datasource_list=source_datasource_list,
            sync_object_list=sync_object_list,
            target_datasource=target_datasource,
            jwt_token=studio_config.token,
            instance_name=studio_config.instance,
            env=studio_config.env,
            workspace_name=studio_config.workspace,
        )

        # Parse and format the response
        response_data = json.loads(response)

        if response_data.get("code") == "200":
            data = response_data.get("data", {})

            formatted_response = {
                "success": True,
                "message": "Successfully saved multi-table real-time CDC task",
                "data": data,
                "task_id": data_file_id,
                "next_steps": [
                    "1. Review the saved CDC configuration",
                    "2. Use submit_task to deploy and start the CDC task (CDC tasks run continuously, no scheduling needed)",
                    "3. Monitor the task status through Studio UI or task monitoring tools",
                ],
                "important_note": (
                    "CDC real-time tasks are continuous streaming tasks. "
                    "DO NOT use save_task_configuration, execute_task, or list_task_run with CDC tasks. "
                    "These tools are only for batch/scheduled tasks."
                ),
            }

            return ResponseBuilder.create_yaml_json_response(
                [formatted_response], studio_config=studio_config
            )
        else:
            error_response = {
                "success": False,
                "message": f"API request failed: {response_data.get('message', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data,
            }
            return ResponseBuilder.create_yaml_json_response(
                [error_response], studio_config=studio_config
            )

    except Exception as e:
        logger.error(f"Error in save_cdc_realtime_task: {e}")
        import traceback

        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__,
            "traceback": traceback.format_exc(),
        }
        return ResponseBuilder.create_yaml_json_response(
            [error_response], studio_config=studio_config
        )


def cdc_realtime_tools() -> List[Tool]:
    """Get CDC real-time task tools"""
    return [
        Tool(
            name="save_cdc_realtime_task",
            description=(
                "Save multi-table real-time CDC (Change Data Capture) task configuration to Clickzetta Studio. "
                "This tool creates or updates a real-time data synchronization task that continuously captures changes "
                "from source databases and syncs them to target systems.\n"
                "\n"
                "**⚠️ IMPORTANT LIMITATIONS - CDC Real-Time Tasks:**\n"
                "CDC real-time tasks are CONTINUOUS STREAMING tasks that run 24/7, NOT batch/scheduled tasks.\n"
                "**DO NOT use these tools with CDC tasks:**\n"
                "- ❌ save_task_configuration (CDC tasks don't need scheduling - they run continuously)\n"
                "- ❌ execute_task (CDC tasks are submitted once and run continuously)\n"
                "- ❌ list_task_run (CDC tasks don't have discrete 'runs' - they stream continuously)\n"
                "\n"
                "**Use these tools instead:**\n"
                "- ✅ submit_task - Deploy and start the CDC task\n"
                "- ✅ Studio UI - Monitor real-time sync status and metrics\n"
                "\n"
                "**Supported Source Datasources:**\n"
                "- MySQL (type in [5,39,19])\n"
                "- PostgreSQL (type in [7,40,48])\n"
                "- SQL Server (type=8)\n"
                "- TiDB (type=17)\n"
                "\n"
                "**Supported Target Datasources:**\n"
                "- Lakehouse (type=1)\n"
                "- Kafka (type=2)\n"
                "\n"
                "**Key Features:**\n"
                "- Multi-table synchronization: Sync entire schemas or multiple tables at once\n"
                "- Real-time CDC: Captures INSERT, UPDATE, DELETE operations in real-time\n"
                "- No pre-existing target tables required: Tables are created automatically\n"
                "- Full + Incremental sync: Initial full data load followed by incremental changes\n"
                "- Continuous operation: Once started, runs 24/7 until manually stopped\n"
                "\n"
                "**Prerequisites:**\n"
                "1. Create a task first using create_task with task_type=281 (CDC_REALTIME)\n"
                "2. Source database must have CDC/binlog enabled\n"
                "3. Proper permissions on source and target datasources\n"
                "\n"
                "**Workflow:**\n"
                "Step 1: create_task(task_type=281, task_name='cdc_sync_task') → Get data_file_id\n"
                "Step 2: **Call this tool** with data_file_id and configuration\n"
                "Step 3: submit_task(data_file_id=xxx) to deploy and start the CDC task\n"
                "Step 4: Monitor through Studio UI (CDC tasks run continuously, no scheduling needed)\n"
                "\n"
                "⚠️ **Remember:** CDC tasks are streaming tasks. After submit_task, they run continuously. "
                "Don't try to schedule or execute them like batch tasks!\n"
                "\n"
                "**Sync Modes:**\n"
                "- sync_mode=1: Full + Incremental (recommended) - Initial full load then capture changes\n"
                "- sync_mode=2: Incremental only - Only capture changes from current point\n"
                "\n"
                "**Configuration Example:**\n"
                "```json\n"
                "{\n"
                '  "dataFileId": 12549001,\n'
                '  "pipelineType": 3,\n'
                '  "projectId": 60001,\n'
                '  "saveMode": 2,\n'
                '  "sourceDatasourceList": [\n'
                '    {"datasourceId": 12094, "datasourceType": 5}\n'
                "  ],\n"
                '  "syncMode": 1,\n'
                '  "syncObjectList": [\n'
                '    {"schemaName": "wx3"}\n'
                "  ],\n"
                '  "targetDatasource": {\n'
                '    "datasourceId": 263,\n'
                '    "datasourceType": 1\n'
                "  }\n"
                "}\n"
                "```\n"
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "data_file_id": {
                        "type": "integer",
                        "description": (
                            "REQUIRED. The task file ID obtained from create_task. "
                            "This task must be of type 281 (CDC_REALTIME)."
                        ),
                    },
                    "pipeline_type": {
                        "type": "integer",
                        "description": (
                            "Pipeline type for multi-table real-time sync:\n"
                            "- 1: Multi-table mirror sync (when user specifies specific tables)\n"
                            "- 2: Multi-table merge\n"
                            "- 3: Whole database mirror (when user specifies a database without specific tables)\n"
                            "Default is 3. System will auto-select based on sync_object_list configuration."
                        ),
                        "enum": [1, 2, 3],
                        "default": 3,
                    },
                    "save_mode": {
                        "type": "integer",
                        "description": (
                            "Save mode for current operation on saved data:\n"
                            "- 1: Overwrite - Replace existing configuration\n"
                            "- 2: Append - Add to existing configuration (recommended for new tasks)\n"
                            "- 3: Modify - Update existing configuration\n"
                            "Default is 2 (append)."
                        ),
                        "enum": [1, 2, 3],
                        "default": 2,
                    },
                    "sync_mode": {
                        "type": "integer",
                        "description": (
                            "Synchronization mode:\n"
                            "- 1: Full + Incremental (recommended) - Performs initial full data load, then captures incremental changes\n"
                            "- 2: Incremental only - Only captures changes from the current point forward"
                        ),
                        "enum": [1, 2],
                        "default": 1,
                    },
                    "source_datasource_list": {
                        "type": "array",
                        "description": (
                            "REQUIRED. List of source datasources to sync from. "
                            "Each datasource must have datasourceId and datasourceType. "
                            "Supported types: MySQL (5), PostgreSQL (7), SQL Server (8)."
                        ),
                        "items": {
                            "type": "object",
                            "properties": {
                                "datasourceId": {
                                    "type": "integer",
                                    "description": "Source datasource ID (get from list_data_sources)",
                                },
                                "datasourceType": {
                                    "type": "integer",
                                    "description": "Source datasource type: 5=MySQL, 7=PostgreSQL, 8=SQL Server",
                                },
                            },
                            "required": ["datasourceId", "datasourceType"],
                        },
                    },
                    "sync_object_list": {
                        "type": "array",
                        "description": (
                            "REQUIRED. List of objects (schemas/tables) to synchronize. "
                            "Can specify entire schemas or individual tables."
                        ),
                        "items": {
                            "type": "object",
                            "properties": {
                                "schemaName": {
                                    "type": "string",
                                    "description": (
                                        "Schema/database name to sync. If only schemaName is provided, "
                                        "all tables in the schema will be synced."
                                    ),
                                },
                                "tableName": {
                                    "type": "string",
                                    "description": "Optional. Specific table name to sync. If omitted, all tables in schema are synced.",
                                },
                            },
                            "required": ["schemaName"],
                        },
                    },
                    "target_datasource": {
                        "type": "object",
                        "description": (
                            "REQUIRED. Target datasource configuration. "
                            "Supported types: Lakehouse (1), Kafka (2)."
                        ),
                        "properties": {
                            "datasourceId": {
                                "type": "integer",
                                "description": "Target datasource ID (get from list_data_sources)",
                            },
                            "datasourceType": {
                                "type": "integer",
                                "description": "Target datasource type: 1=Lakehouse, 2=Kafka",
                            },
                        },
                        "required": ["datasourceId", "datasourceType"],
                    },
                },
                "required": [
                    "data_file_id",
                    "source_datasource_list",
                    "sync_object_list",
                    "target_datasource",
                ],
            },
            handler=handle_save_cdc_realtime_task,
            tags=["studio", "cdc", "realtime", "sync", "multi-table"],
            samples=[
                {
                    "description": "Save a MySQL to Lakehouse CDC task syncing entire schema",
                    "query": {
                        "data_file_id": 12549001,
                        "pipeline_type": 3,
                        "save_mode": 2,
                        "sync_mode": 1,
                        "source_datasource_list": [
                            {"datasourceId": 12094, "datasourceType": 5}
                        ],
                        "sync_object_list": [{"schemaName": "wx3"}],
                        "target_datasource": {"datasourceId": 263, "datasourceType": 1},
                    },
                },
                {
                    "description": "Save a PostgreSQL to Kafka CDC task with specific tables",
                    "query": {
                        "data_file_id": 12549002,
                        "sync_mode": 1,
                        "source_datasource_list": [
                            {"datasourceId": 15001, "datasourceType": 7}
                        ],
                        "sync_object_list": [
                            {"schemaName": "public", "tableName": "users"},
                            {"schemaName": "public", "tableName": "orders"},
                        ],
                        "target_datasource": {"datasourceId": 500, "datasourceType": 2},
                    },
                },
                {
                    "description": "Save a SQL Server to Lakehouse CDC task with incremental only mode",
                    "query": {
                        "data_file_id": 12549003,
                        "sync_mode": 2,
                        "source_datasource_list": [
                            {"datasourceId": 20001, "datasourceType": 8}
                        ],
                        "sync_object_list": [{"schemaName": "dbo"}],
                        "target_datasource": {"datasourceId": 300, "datasourceType": 1},
                    },
                },
            ],
        )
    ]
