"""
Flow Task Tools - MCP tools for Flow (组合任务) development operations
"""
import json
from typing import List

from loguru import logger
from mcp.types import TextContent, EmbeddedResource

from cz_mcp.handlers.flow_task_server import (
    get_flow_dag, create_flow_node, bind_flow_node,
    unbind_flow_node, remove_flow_node, submit_flow_and_wait,
    list_flow_node_instances, save_flow_node_configuration,
    get_flow_node_detail, save_flow_node_content,
)
from ..core.tool_registry import Tool
from ..common.utilities import ResponseBuilder
from ..studio_config_manager import StudioConfig

# AI-friendly node type mapping: string name -> FileType integer
NODE_TYPE_MAP = {
    "sql": 4,
    "shell": 5,
    "python": 7,
    "data_integration": 1,
    "jdbc": 15,
    "virtual": 0,
    "continuous_job": 17,
    "spark": 400,
}

NODE_TYPE_NAMES = ", ".join(f"{k}({v})" for k, v in NODE_TYPE_MAP.items())


def _resolve_node_type(file_type) -> int:
    """Resolve AI-friendly node type string or int to FileType integer"""
    if isinstance(file_type, int):
        return file_type
    if isinstance(file_type, str):
        lower = file_type.lower().strip()
        if lower in NODE_TYPE_MAP:
            return NODE_TYPE_MAP[lower]
        # Try parsing as int string
        try:
            return int(lower)
        except ValueError:
            pass
    raise ValueError(f"Unknown node type '{file_type}'. Supported: {NODE_TYPE_NAMES}")


def _resolve_node_name(data_file_id, node_name, studio_config):
    """Resolve a node name to its node ID by fetching the DAG. Returns (node_id, error_msg)."""
    response = get_flow_dag(
        data_file_id=data_file_id,
        jwt_token=studio_config.token, instance_name=studio_config.instance,
        tenant_id=studio_config.tenant_id, env=studio_config.env,
        workspace_name=studio_config.workspace,
    )
    data = json.loads(response)
    if str(data.get("code")) != "200":
        return None, f"Failed to fetch DAG: {data.get('message', 'Unknown error')}"
    dag = data.get("data", {})
    # API may return nodes as a list directly or as {"nodes": [...]}
    if isinstance(dag, list):
        nodes = dag
    else:
        nodes = dag.get("nodes", [])
    matched = [n for n in nodes if n.get("fileName") == node_name]
    if len(matched) == 1:
        return matched[0]["id"], None
    if len(matched) == 0:
        available = [n.get("fileName") for n in nodes]
        return None, f"Node '{node_name}' not found. Available nodes: {available}"
    return None, f"Multiple nodes named '{node_name}' found. Use node_id instead."


def _require_node_name(arguments, name_key, data_file_id, studio_config):
    """Resolve a required node name to its ID. Returns (node_id, error_msg)."""
    node_name = arguments.get(name_key)
    if not node_name:
        return None, f"{name_key} is required"
    return _resolve_node_name(data_file_id, node_name, studio_config)


def _parse_response(response_text, success_msg, studio_config):
    """Common response parsing"""
    response_data = json.loads(response_text)
    if str(response_data.get("code")) == "200":
        return ResponseBuilder.create_yaml_json_response([{
            "success": True,
            "message": success_msg,
            "data": response_data.get("data"),
        }], studio_config=studio_config)
    else:
        return ResponseBuilder.create_yaml_json_response([{
            "success": False,
            "message": f"API failed: {response_data.get('message', 'Unknown error')}",
            "code": response_data.get("code"),
        }], studio_config=studio_config)


async def handle_get_flow_dag(arguments=None, studio_config: StudioConfig = None, **kwargs
) -> list[TextContent | EmbeddedResource]:
    """Get flow DAG structure"""
    if arguments is None:
        arguments = {}
    try:
        config = studio_config
        data_file_id = arguments.get("task_id")
        if not data_file_id:
            return ResponseBuilder.create_yaml_json_response(
                [{"success": False, "message": "task_id is required"}], studio_config=config)

        response = get_flow_dag(
            data_file_id=data_file_id,
            jwt_token=config.token, instance_name=config.instance,
            tenant_id=config.tenant_id, env=config.env, workspace_name=config.workspace,
        )
        return _parse_response(response, "Flow DAG retrieved successfully", config)
    except Exception as e:
        logger.error(f"Error in get_flow_dag: {e}")
        return ResponseBuilder.create_yaml_json_response(
            [{"success": False, "message": f"Internal error: {str(e)}"}], studio_config=studio_config)


async def handle_create_flow_node(arguments=None, studio_config: StudioConfig = None, **kwargs
) -> list[TextContent | EmbeddedResource]:
    """Create a flow node"""
    if arguments is None:
        arguments = {}
    try:
        config = studio_config
        data_file_id = arguments.get("task_id")
        node_name = arguments.get("node_name")
        if not all([data_file_id, node_name]):
            return ResponseBuilder.create_yaml_json_response(
                [{"success": False, "message": "task_id and node_name are required"}],
                studio_config=config)

        # Resolve node type: accept string or int, default to SQL
        raw_type = arguments.get("node_type", "sql")
        try:
            file_type = _resolve_node_type(raw_type)
        except ValueError as e:
            return ResponseBuilder.create_yaml_json_response(
                [{"success": False, "message": str(e)}], studio_config=config)

        # Resolve dependency by name
        dep_node_id = None
        dep_node_name = arguments.get("dependency_node_name")
        if dep_node_name:
            dep_node_id, err = _resolve_node_name(data_file_id, dep_node_name, config)
            if err:
                return ResponseBuilder.create_yaml_json_response(
                    [{"success": False, "message": f"dependency: {err}"}], studio_config=config)

        response = create_flow_node(
            data_file_id=data_file_id,
            project_id=arguments.get("project_id") or config.project_id,
            node_name=node_name, file_type=file_type,
            jwt_token=config.token, instance_name=config.instance,
            tenant_id=config.tenant_id, user_id=config.user_id,
            env=config.env, workspace_name=config.workspace,
            node_description=arguments.get("node_description"),
            dependency_node_id=dep_node_id,
            position=arguments.get("position"),
            content=arguments.get("content"),
        )
        return _parse_response(response, "Flow node created successfully", config)
    except Exception as e:
        logger.error(f"Error in create_flow_node: {e}")
        return ResponseBuilder.create_yaml_json_response(
            [{"success": False, "message": f"Internal error: {str(e)}"}], studio_config=studio_config)


async def handle_remove_flow_node(arguments=None, studio_config: StudioConfig = None, **kwargs
) -> list[TextContent | EmbeddedResource]:
    """Remove a flow node"""
    if arguments is None:
        arguments = {}
    try:
        config = studio_config
        file_id = arguments.get("task_id")
        if not file_id:
            return ResponseBuilder.create_yaml_json_response(
                [{"success": False, "message": "task_id is required"}], studio_config=config)

        node_id, err = _require_node_name(arguments, "node_name", file_id, config)
        if err:
            return ResponseBuilder.create_yaml_json_response(
                [{"success": False, "message": err}], studio_config=config)

        response = remove_flow_node(
            file_id=file_id, node_id=node_id,
            jwt_token=config.token, instance_name=config.instance,
            tenant_id=config.tenant_id, user_id=config.user_id,
            env=config.env, workspace_name=config.workspace,
        )
        return _parse_response(response, "Flow node removed successfully", config)
    except Exception as e:
        logger.error(f"Error in remove_flow_node: {e}")
        return ResponseBuilder.create_yaml_json_response(
            [{"success": False, "message": f"Internal error: {str(e)}"}], studio_config=studio_config)


async def handle_bind_flow_node(arguments=None, studio_config: StudioConfig = None, **kwargs
) -> list[TextContent | EmbeddedResource]:
    """Bind dependency between flow nodes"""
    if arguments is None:
        arguments = {}
    try:
        config = studio_config
        data_file_id = arguments.get("task_id")
        if not data_file_id:
            return ResponseBuilder.create_yaml_json_response(
                [{"success": False, "message": "task_id is required"}], studio_config=config)

        # Resolve upstream by name
        upstream_node_id, err = _require_node_name(arguments, "upstream_node_name", data_file_id, config)
        if err:
            return ResponseBuilder.create_yaml_json_response(
                [{"success": False, "message": f"upstream: {err}"}], studio_config=config)

        # Resolve downstream by name
        downstream_node_id, err = _require_node_name(arguments, "downstream_node_name", data_file_id, config)
        if err:
            return ResponseBuilder.create_yaml_json_response(
                [{"success": False, "message": f"downstream: {err}"}], studio_config=config)

        response = bind_flow_node(
            current_file_id=arguments.get("downstream_file_id") or data_file_id,
            current_node_id=downstream_node_id,
            current_project_id=arguments.get("downstream_project_id") or config.project_id,
            dependency_file_id=arguments.get("upstream_file_id") or data_file_id,
            dependency_node_id=upstream_node_id,
            dependency_project_id=arguments.get("upstream_project_id") or config.project_id,
            jwt_token=config.token, instance_name=config.instance,
            tenant_id=config.tenant_id, user_id=config.user_id,
            env=config.env, workspace_name=config.workspace,
        )
        return _parse_response(response, "Flow nodes bound successfully", config)
    except Exception as e:
        logger.error(f"Error in bind_flow_node: {e}")
        return ResponseBuilder.create_yaml_json_response(
            [{"success": False, "message": f"Internal error: {str(e)}"}], studio_config=studio_config)


async def handle_unbind_flow_node(arguments=None, studio_config: StudioConfig = None, **kwargs
) -> list[TextContent | EmbeddedResource]:
    """Unbind dependency between flow nodes"""
    if arguments is None:
        arguments = {}
    try:
        config = studio_config
        dep_id = arguments.get("dependency_id")
        file_id = arguments.get("task_id")
        if not all([dep_id, file_id]):
            return ResponseBuilder.create_yaml_json_response(
                [{"success": False, "message": "task_id and dependency_id are required"}], studio_config=config)

        response = unbind_flow_node(
            dep_id=dep_id, file_id=file_id,
            jwt_token=config.token, instance_name=config.instance,
            tenant_id=config.tenant_id, user_id=config.user_id,
            env=config.env, workspace_name=config.workspace,
        )
        return _parse_response(response, "Flow node dependency unbound successfully", config)
    except Exception as e:
        logger.error(f"Error in unbind_flow_node: {e}")
        return ResponseBuilder.create_yaml_json_response(
            [{"success": False, "message": f"Internal error: {str(e)}"}], studio_config=studio_config)


async def handle_submit_flow(arguments=None, studio_config: StudioConfig = None, **kwargs
) -> list[TextContent | EmbeddedResource]:
    """Submit flow and wait for completion"""
    if arguments is None:
        arguments = {}
    try:
        config = studio_config
        file_id = arguments.get("task_id")
        if not file_id:
            return ResponseBuilder.create_yaml_json_response(
                [{"success": False, "message": "task_id is required"}], studio_config=config)

        response = submit_flow_and_wait(
            file_id=file_id,
            project_id=arguments.get("project_id") or config.project_id,
            jwt_token=config.token, instance_name=config.instance,
            tenant_id=config.tenant_id, user_id=config.user_id,
            env=config.env, workspace_name=config.workspace,
        )
        return _parse_response(response, "Flow submitted successfully", config)
    except Exception as e:
        logger.error(f"Error in submit_flow: {e}")
        return ResponseBuilder.create_yaml_json_response(
            [{"success": False, "message": f"Internal error: {str(e)}"}], studio_config=studio_config)


async def handle_get_flow_node_detail(arguments=None, studio_config: StudioConfig = None, **kwargs
) -> list[TextContent | EmbeddedResource]:
    """Get flow node detail."""
    if arguments is None:
        arguments = {}
    try:
        config = studio_config
        flow_task_id = arguments.get("task_id")
        node_id = arguments.get("node_id")
        if not all([flow_task_id, node_id]):
            return ResponseBuilder.create_yaml_json_response(
                [{"success": False, "message": "task_id and node_id are required"}], studio_config=config)

        response = get_flow_node_detail(
            data_file_id=flow_task_id, node_id=node_id,
            jwt_token=config.token, instance_name=config.instance,
            tenant_id=config.tenant_id, env=config.env,
            workspace_name=config.workspace,
        )
        return _parse_response(response, "Node detail retrieved successfully", config)
    except Exception as e:
        logger.error(f"Error in get_flow_node_detail: {e}")
        return ResponseBuilder.create_yaml_json_response(
            [{"success": False, "message": f"Internal error: {str(e)}"}], studio_config=studio_config)


async def handle_save_node_content(arguments=None, studio_config: StudioConfig = None, **kwargs
) -> list[TextContent | EmbeddedResource]:
    """Save content (SQL/code) for a flow node."""
    if arguments is None:
        arguments = {}
    try:
        config = studio_config
        flow_task_id = arguments.get("task_id")
        node_id = arguments.get("node_id")
        content = arguments.get("content")
        if not all([flow_task_id, node_id]):
            return ResponseBuilder.create_yaml_json_response(
                [{"success": False, "message": "task_id and node_id are required"}], studio_config=config)
        if content is None:
            return ResponseBuilder.create_yaml_json_response(
                [{"success": False, "message": "content is required"}], studio_config=config)

        response = save_flow_node_content(
            data_file_id=flow_task_id, node_id=node_id, content=content,
            project_id=arguments.get("project_id") or config.project_id,
            user_name=config.username,
            jwt_token=config.token, instance_name=config.instance,
            tenant_id=config.tenant_id, env=config.env,
            workspace_name=config.workspace,
            param_value_list=arguments.get("param_value_list"),
        )
        return _parse_response(response, "Node content saved successfully", config)
    except Exception as e:
        logger.error(f"Error in save_node_content: {e}")
        return ResponseBuilder.create_yaml_json_response(
            [{"success": False, "message": f"Internal error: {str(e)}"}], studio_config=studio_config)


async def handle_save_node_configuration(arguments=None, studio_config: StudioConfig = None, **kwargs
) -> list[TextContent | EmbeddedResource]:
    """Save schedule configuration for a flow node."""
    if arguments is None:
        arguments = {}
    try:
        config = studio_config
        flow_task_id = arguments.get("task_id")
        node_id = arguments.get("node_id")
        if not flow_task_id:
            return ResponseBuilder.create_yaml_json_response(
                [{"success": False, "message": "task_id (flow task ID) is required"}], studio_config=config)
        if not node_id:
            return ResponseBuilder.create_yaml_json_response(
                [{"success": False, "message": "node_id is required"}], studio_config=config)

        # Fetch node detail to get defaults (schemaName, vcCode, etc.)
        detail_resp = get_flow_node_detail(
            data_file_id=flow_task_id, node_id=node_id,
            jwt_token=config.token, instance_name=config.instance,
            tenant_id=config.tenant_id, env=config.env,
            workspace_name=config.workspace,
        )
        detail_data = json.loads(detail_resp)
        if str(detail_data.get("code")) != "200":
            return ResponseBuilder.create_yaml_json_response(
                [{"success": False, "message": f"Failed to get node detail: {detail_data.get('message', 'Unknown error')}"}],
                studio_config=config)

        node_detail = detail_data.get("data", {})
        # Use node detail defaults, allow user override
        schema_name = arguments.get("schema_name") or node_detail.get("defaultSchemaName") or "public"
        etl_vc_code = arguments.get("etl_vc_code") or node_detail.get("defaultVcName") or "DEFAULT"
        etl_vc_id = arguments.get("etl_vc_id")

        response = save_flow_node_configuration(
            data_file_id=flow_task_id,
            node_id=node_id,
            project_id=arguments.get("project_id") or config.project_id,
            user_id=config.user_id,
            user_name=config.username,
            jwt_token=config.token, instance_name=config.instance,
            tenant_id=config.tenant_id, env=config.env,
            workspace_name=config.workspace,
            schema_name=schema_name,
            etl_vc_code=etl_vc_code,
            etl_vc_id=etl_vc_id,
        )
        return _parse_response(response, f"Node configuration saved successfully", config)
    except Exception as e:
        logger.error(f"Error in save_node_configuration: {e}")
        return ResponseBuilder.create_yaml_json_response(
            [{"success": False, "message": f"Internal error: {str(e)}"}], studio_config=studio_config)


INSTANCE_STATUS_MAP = {
    -1: "disabled(已下线)",
    1: "success(运行成功)",
    2: "un_execute(未运行)",
    3: "fail(运行失败)",
    4: "executing(运行中)",
    5: "waiting_queue(等待队列资源中)",
    6: "waiting_dependency(等待上游节点运行完成)",
    7: "stop(已暂停)",
    8: "waiting_dependency_success(上游节点运行失败阻塞运行)",
}


async def handle_list_flow_node_instances(arguments=None, studio_config: StudioConfig = None, **kwargs
) -> list[TextContent | EmbeddedResource]:
    """List flow node instances with extra info"""
    if arguments is None:
        arguments = {}
    try:
        config = studio_config
        flow_id = arguments.get("flow_id")
        flow_instance_id = arguments.get("flow_instance_id")
        if not all([flow_id, flow_instance_id]):
            return ResponseBuilder.create_yaml_json_response(
                [{"success": False, "message": "flow_id and flow_instance_id are required"}], studio_config=config)

        response = list_flow_node_instances(
            tenant_id=config.tenant_id, flow_id=flow_id,
            flow_instance_id=flow_instance_id,
            jwt_token=config.token, instance_name=config.instance,
            env=config.env, workspace_name=config.workspace,
            flow_node_id=arguments.get("flow_node_id"),
            flow_node_instance_id=arguments.get("flow_node_instance_id"),
        )
        response_data = json.loads(response)
        if str(response_data.get("code")) == "200":
            instances = response_data.get("data", [])
            # Translate instanceStatus to readable name
            for inst in (instances or []):
                status = inst.get("instanceStatus")
                if status is not None:
                    inst["instanceStatusName"] = INSTANCE_STATUS_MAP.get(status, f"unknown({status})")
            return ResponseBuilder.create_yaml_json_response([{
                "success": True,
                "message": f"Found {len(instances or [])} node instance(s)",
                "data": instances,
            }], studio_config=config)
        else:
            return ResponseBuilder.create_yaml_json_response([{
                "success": False,
                "message": f"API failed: {response_data.get('message', 'Unknown error')}",
                "code": response_data.get("code"),
            }], studio_config=config)
    except Exception as e:
        logger.error(f"Error in list_flow_node_instances: {e}")
        return ResponseBuilder.create_yaml_json_response(
            [{"success": False, "message": f"Internal error: {str(e)}"}], studio_config=studio_config)


FLOW_TOOL_ROUTING_HINT = (
    "\n\n⚠️ This tool is ONLY for Flow tasks (组合任务, task_type=500). "
    "For creating/removing/binding flow nodes, use flow-specific tools. "
    "For saving node content, use save_non_integration_task_content with the node's data_file_id. "
    "For saving node schedule config, use save_task_configuration with the node's task_id."
)

FLOW_WORKFLOW_HINT = (
    "\n\n**Flow Workflow:** "
    "1) create_task(task_type=500) → get flow task_id; "
    "2) create_flow_node → add nodes (returns node data_file_id); "
    "3) bind_flow_node → set dependencies (or use dependency_node_name in step 2); "
    "4) save_node_content → write SQL/code to each node using node's node_id; "
    "5) save_node_configuration → configure vs and schema for each node; "
    "6) submit_flow → publish/deploy the flow."
)


def get_flow_task_tools() -> List[Tool]:
    """Get all flow task tools"""
    return [
        Tool(
            name="get_flow_dag",
            description=(
                "**When to Use:** User asks to view, check, or inspect the structure/nodes/dependencies "
                "of a Flow task (组合任务/工作流), e.g.:\n"
                "- '查看组合任务结构', '这个flow有哪些节点', 'show me the flow DAG'\n"
                "- '组合任务的依赖关系是什么', 'what nodes are in this flow'\n"
                "- Before bind_flow_node/remove_flow_node to look up node names\n\n"
                "Get the DAG (Directed Acyclic Graph) structure of a Flow task (组合任务). "
                "Returns all nodes (with nodeId, nodeName, fileType) and their dependency edges. "
                "A Flow task is created via create_task with task_type=500. "
                "The returned task_id is used as the task_id parameter for all flow node operations."
                + FLOW_TOOL_ROUTING_HINT
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "task_id": {
                        "type": "integer",
                        "description": "REQUIRED. The ID of the flow task (obtained from create_task response)."
                    },
                },
                "required": ["task_id"],
            },
            handler=handle_get_flow_dag,
            tags=["studio", "flow", "read"],
            samples=[
                {"description": "查看组合任务12345的DAG结构", "query": {"task_id": 12345}},
            ],
        ),
        Tool(
            name="create_flow_node",
            description=(
                "**When to Use:** User asks to add a node/step/subtask to a Flow task (组合任务/工作流), e.g.:\n"
                "- '给组合任务添加一个SQL节点', '在flow里新建一个Python步骤'\n"
                "- '添加flow子任务', 'add a node to the flow'\n"
                "- '创建组合任务节点', 'create a flow step'\n\n"
                "❌ Do NOT use task_management_operation/save_content to create flow nodes.\n\n"
                "Create a new node (子节点/子任务) in a Flow task (组合任务). "
                "A flow node represents a sub-task within the flow. "
                "Supported node types: sql (default), python, shell, data_integration, jdbc, virtual, continuous_job, spark. "
                "Use dependency_node_name to set execution order between nodes."
                + FLOW_WORKFLOW_HINT
                + FLOW_TOOL_ROUTING_HINT
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "task_id": {
                        "type": "integer",
                        "description": "REQUIRED. The flow task ID (obtained from create_task response with task_type=500)."
                    },
                    "node_name": {
                        "type": "string",
                        "description": "REQUIRED. Name of the new node."
                    },
                    "node_type": {
                        "type": "string",
                        "description": "Type of the node. Options: sql, python, shell, data_integration, jdbc, virtual, continuous_job, spark. Default: sql.",
                        "enum": ["sql", "python", "shell", "data_integration", "jdbc", "virtual", "continuous_job", "spark"],
                        "default": "sql",
                    },
                    "node_description": {
                        "type": "string",
                        "description": "Optional description for the node."
                    },
                    "dependency_node_name": {
                        "type": "string",
                        "description": "Optional. Name of an existing node that this new node should depend on (run after)."
                    },
                    "content": {
                        "type": "string",
                        "description": "Optional. Initial SQL/code content for the node."
                    },
                },
                "required": ["task_id", "node_name"],
            },
            handler=handle_create_flow_node,
            tags=["studio", "flow", "write"],
            samples=[
                {"description": "给flow添加一个SQL节点", "query": {"task_id": 12345, "node_name": "extract_data"}},
                {"description": "创建Python节点并依赖extract_data", "query": {"task_id": 12345, "node_name": "transform", "node_type": "python", "dependency_node_name": "extract_data"}},
            ],
        ),
        Tool(
            name="remove_flow_node",
            description=(
                "**When to Use:** User asks to delete/remove a node from a Flow task (组合任务), e.g.:\n"
                "- '删除组合任务里的某个节点', 'remove a node from the flow'\n"
                "- '把flow里的xxx节点去掉'\n\n"
                "Remove a node (子节点) from a Flow task (组合任务/工作流). "
                "This will also remove all dependencies associated with the node. "
                "Use get_flow_dag first to find the exact node name."
                + FLOW_TOOL_ROUTING_HINT
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "task_id": {
                        "type": "integer",
                        "description": "REQUIRED. The flow task ID."
                    },
                    "node_name": {
                        "type": "string",
                        "description": "REQUIRED. The name of the node to remove. Use get_flow_dag to find available node names."
                    },
                },
                "required": ["task_id", "node_name"],
            },
            handler=handle_remove_flow_node,
            tags=["studio", "flow", "write"],
        ),
        Tool(
            name="bind_flow_node",
            description=(
                "**When to Use:** User asks to add a dependency/edge between two nodes in a Flow task (组合任务), e.g.:\n"
                "- '给flow节点添加依赖', '设置节点执行顺序'\n"
                "- '让A节点在B节点之后执行', 'add dependency between flow nodes'\n"
                "- '连接两个flow节点', 'set execution order'\n\n"
                "Create a dependency edge: upstream_node runs first → then downstream_node. "
                "Both nodes must already exist in the same flow. "
                "Alternatively, use dependency_node_name in create_flow_node to set dependencies at creation time."
                + FLOW_TOOL_ROUTING_HINT
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "task_id": {
                        "type": "integer",
                        "description": "REQUIRED. The flow task ID."
                    },
                    "upstream_node_name": {
                        "type": "string",
                        "description": "REQUIRED. Name of the node that runs FIRST (上游节点)."
                    },
                    "downstream_node_name": {
                        "type": "string",
                        "description": "REQUIRED. Name of the node that runs AFTER upstream (下游节点)."
                    },
                },
                "required": ["task_id", "upstream_node_name", "downstream_node_name"],
            },
            handler=handle_bind_flow_node,
            tags=["studio", "flow", "write"],
            samples=[
                {"description": "设置依赖: extract_data → transform", "query": {"task_id": 12345, "upstream_node_name": "extract_data", "downstream_node_name": "transform"}},
            ],
        ),
        Tool(
            name="unbind_flow_node",
            description=(
                "**When to Use:** User asks to remove a dependency/edge between flow nodes (组合任务), e.g.:\n"
                "- '删除flow节点之间的依赖', '解除节点依赖关系'\n"
                "- 'remove dependency between flow nodes'\n\n"
                "Remove a dependency edge between two nodes in a Flow task (组合任务/工作流). "
                "Call get_flow_dag first — each dependency in the response has an 'id' field, pass that as dependency_id."
                + FLOW_TOOL_ROUTING_HINT
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "task_id": {
                        "type": "integer",
                        "description": "REQUIRED. The flow task ID."
                    },
                    "dependency_id": {
                        "type": "integer",
                        "description": "REQUIRED. The dependency ID to remove (the 'id' field from dependencies in get_flow_dag result)."
                    },
                },
                "required": ["task_id", "dependency_id"],
            },
            handler=handle_unbind_flow_node,
            tags=["studio", "flow", "write"],
        ),
        Tool(
            name="submit_flow",
            description=(
                "**When to Use:** User asks to submit/publish/deploy a Flow task (组合任务), e.g.:\n"
                "- '提交组合任务', '发布flow', 'deploy the flow', '上线组合任务'\n"
                "- 'submit the flow task', '发布工作流'\n\n"
                "❌ Do NOT use publish_task for Flow tasks — use this tool instead.\n\n"
                "Submit/publish a Flow task (组合任务/工作流) for deployment and scheduling. "
                "Automatically polls for completion status. "
                "All nodes should be properly configured before submitting."
                + FLOW_WORKFLOW_HINT
                + FLOW_TOOL_ROUTING_HINT
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "task_id": {
                        "type": "integer",
                        "description": "REQUIRED. The flow task ID to submit."
                    },
                },
                "required": ["task_id"],
            },
            handler=handle_submit_flow,
            tags=["studio", "flow", "write"],
        ),
        Tool(
            name="get_flow_node_detail",
            description=(
                "**When to Use:** User asks to view the detail/content of a flow node (查看组合任务节点详情), e.g.:\n"
                "- '查看flow节点内容', '获取组合任务节点详情'\n"
                "- 'get flow node detail', 'show node content'\n\n"
                "Get detail of a specific node within a Flow task (组合任务), including "
                "fileContent, defaultSchemaName, defaultVcName, ownerCnName, hasConfig, etc. "
                "Use get_flow_dag first to find the node_id."
                + FLOW_TOOL_ROUTING_HINT
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "task_id": {
                        "type": "integer",
                        "description": "REQUIRED. The flow task ID (the parent flow's dataFileId)."
                    },
                    "node_id": {
                        "type": "integer",
                        "description": "REQUIRED. The node ID (the 'id' field from get_flow_dag)."
                    },
                },
                "required": ["task_id", "node_id"],
            },
            handler=handle_get_flow_node_detail,
            tags=["studio", "flow", "read"],
            samples=[
                {"description": "查看flow节点详情", "query": {"task_id": 13262001, "node_id": 13265002}},
            ],
        ),
        Tool(
            name="save_node_content",
            description=(
                "**When to Use:** User asks to save SQL/code content to a flow node (保存组合任务节点内容), e.g.:\n"
                "- '给flow节点写SQL', '保存组合任务节点代码'\n"
                "- 'save content to flow node', 'write SQL to flow node'\n\n"
                "Save SQL/Shell/Python content to a specific node within a Flow task (组合任务). "
                "Use get_flow_dag first to find the node_id. "
                "Supports parameterized content via param_value_list.\n\n"
                "**IMPORTANT:** Preserve actual newline characters (\\n) as line breaks in content."
                + FLOW_TOOL_ROUTING_HINT
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "task_id": {
                        "type": "integer",
                        "description": "REQUIRED. The flow task ID (the parent flow's dataFileId)."
                    },
                    "node_id": {
                        "type": "integer",
                        "description": "REQUIRED. The node ID (the 'id' field from get_flow_dag)."
                    },
                    "content": {
                        "type": "string",
                        "description": "REQUIRED. SQL/Shell/Python content to save to the node."
                    },
                    "param_value_list": {
                        "type": "array",
                        "description": "Optional. Parameter key-value pairs for dynamic variables.",
                        "items": {
                            "type": "object",
                            "properties": {
                                "paramKey": {"type": "string", "description": "Parameter name."},
                                "paramValue": {"type": "string", "description": "Parameter value or expression."}
                            }
                        }
                    },
                },
                "required": ["task_id", "node_id", "content"],
            },
            handler=handle_save_node_content,
            tags=["studio", "flow", "write"],
            samples=[
                {"description": "给flow节点保存SQL", "query": {"task_id": 13262001, "node_id": 13265003, "content": "select 1;"}},
            ],
        ),
        Tool(
            name="save_node_configuration",
            description=(
                "**When to Use:** User asks to save/configure the schedule of a flow node (组合任务节点调度配置), e.g.:\n"
                "- '给flow节点配置调度', '保存组合任务节点配置'\n"
                "- 'configure flow node', 'save flow node config'\n\n"
                "Save schedule configuration for a specific node within a Flow task (组合任务). "
                "Automatically fetches node defaults (schema, vc) from getDetail API. "
                "Most scheduling parameters use sensible defaults (daily, retry=1, etc.). "
                "Use get_flow_dag first to find the node_id."
                + FLOW_TOOL_ROUTING_HINT
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "task_id": {
                        "type": "integer",
                        "description": "REQUIRED. The flow task ID (the parent flow's dataFileId)."
                    },
                    "node_id": {
                        "type": "integer",
                        "description": "REQUIRED. The node ID (the 'id' field from get_flow_dag)."
                    },
                    "schema_name": {
                        "type": "string",
                        "description": "Optional. Database schema. Auto-filled from node detail if not provided."
                    },
                    "etl_vc_code": {
                        "type": "string",
                        "description": "Optional. Virtual cluster name. Auto-filled from node detail if not provided."
                    },
                    "etl_vc_id": {
                        "type": "string",
                        "description": "Optional. Virtual cluster ID."
                    },
                },
                "required": ["task_id", "node_id"],
            },
            handler=handle_save_node_configuration,
            tags=["studio", "flow", "write"],
            samples=[
                {"description": "保存flow节点配置", "query": {"task_id": 13262001, "node_id": 13265003}},
            ],
        ),
        Tool(
            name="list_flow_node_instances",
            description=(
                "**When to Use:** User asks to check the run status of nodes within a flow instance (组合任务节点运行状态), e.g.:\n"
                "- '查看组合任务各节点的运行情况', '这次flow跑的怎么样'\n"
                "- 'show flow node instance status', 'which nodes failed in this flow run'\n"
                "- '组合任务节点执行详情', 'flow node execution details'\n\n"
                "List all node instances of a specific flow run (组合任务运行实例) with detailed execution info. "
                "Returns each node's status (waiting/running/success/failed/killed/timeout/skipped), "
                "start/end times, failure messages, retry count, etc. "
                "Requires flow_id (the flow task's flowId) and flow_instance_id (a specific run instance). "
                "Optionally filter by flow_node_id or flow_node_instance_id."
                + FLOW_TOOL_ROUTING_HINT
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "flow_id": {
                        "type": "integer",
                        "description": "REQUIRED. The flow ID (flowId from get_flow_dag node data)."
                    },
                    "flow_instance_id": {
                        "type": "integer",
                        "description": "REQUIRED. The flow instance ID (a specific run/execution of the flow)."
                    },
                    "flow_node_id": {
                        "type": "integer",
                        "description": "Optional. Filter by a specific flow node ID."
                    },
                    "flow_node_instance_id": {
                        "type": "integer",
                        "description": "Optional. Filter by a specific flow node instance ID."
                    },
                },
                "required": ["flow_id", "flow_instance_id"],
            },
            handler=handle_list_flow_node_instances,
            tags=["studio", "flow", "read"],
            samples=[
                {"description": "查看flow运行实例的各节点状态", "query": {"flow_id": 13262001, "flow_instance_id": 99001}},
            ],
        ),
    ]
