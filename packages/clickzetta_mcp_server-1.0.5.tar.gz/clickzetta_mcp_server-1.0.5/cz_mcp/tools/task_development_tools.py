"""
Task Development Tools - Generalized tools for non-integration task development
"""
import re
from typing import List
from cz_mcp.common.utilities import ResponseBuilder
from cz_mcp.core.tool_registry import Tool
from cz_mcp.studio_config_manager import StudioConfig
from cz_mcp.tools.agent.LH_execute_tools import handle_execute_sql
from cz_mcp.tools.file_tools import (
    handle_create_task,
    handle_save_content,
    handle_save_configuration,
    handle_get_file_configuration_detail
)


DESTRUCTIVE_SQL_PATTERNS = [
    r'\bDROP\s+(TABLE|DATABASE|SCHEMA|VIEW|INDEX)\b',
    r'\bDELETE\s+FROM\b',
    r'\bTRUNCATE\s+TABLE\b',
    r'\bALTER\s+TABLE\s+\w+\s+DROP\b',
]


def is_destructive_sql(sql: str) -> tuple[bool, str]:
    """Check if SQL contains destructive operations"""
    sql_upper = sql.upper()
    for pattern in DESTRUCTIVE_SQL_PATTERNS:
        if re.search(pattern, sql_upper, re.IGNORECASE):
            return True, f"Destructive SQL detected: {pattern}"
    return False, ""


async def handle_task_query_operation(arguments=None, studio_config: StudioConfig = None, **kwargs):
    """Handle task query operations"""
    if arguments is None:
        arguments = {}
    
    operation_type = arguments.get("operation_type")
    params = arguments.get("parameters", {})
    
    # Merge parameters into arguments
    merged_args = {**params, "operation_type": operation_type}
    
    if operation_type == "validate_sql":
        sql = merged_args.get("sql")
        if not sql:
            return ResponseBuilder.create_yaml_json_response([{
                "success": False,
                "message": "Missing required parameter: sql",
                "error_type": "MissingParameter"
            }], studio_config=studio_config)
        
        # Check for destructive SQL
        is_destructive, reason = is_destructive_sql(sql)
        if is_destructive:
            return ResponseBuilder.create_yaml_json_response([{
                "success": False,
                "message": f"Destructive SQL not allowed: {reason}",
                "error_type": "DestructiveSQL"
            }], studio_config=studio_config)
        
        # Execute SQL validation
        return await handle_execute_sql(merged_args, studio_config, **kwargs)
    
    return ResponseBuilder.create_yaml_json_response([{
        "success": False,
        "message": f"Unknown operation_type: {operation_type}",
        "error_type": "InvalidOperation"
    }], studio_config=studio_config)


async def handle_task_management_operation(arguments=None, studio_config: StudioConfig = None, **kwargs):
    """Handle task management operations"""
    if arguments is None:
        arguments = {}
    
    operation_type = arguments.get("operation_type")
    params = arguments.get("parameters", {})
    
    # Merge parameters into arguments
    merged_args = {**params, "operation_type": operation_type}
    
    if operation_type == "create_task":
        return await handle_create_task(merged_args, studio_config, **kwargs)
    
    elif operation_type == "save_content":
        return await handle_save_content(merged_args, studio_config, **kwargs)
    
    elif operation_type == "save_schedule":
        return await handle_save_configuration(merged_args, studio_config, **kwargs)
    
    elif operation_type == "get_schedule":
        return await handle_get_file_configuration_detail(merged_args, studio_config, **kwargs)
    
    return ResponseBuilder.create_yaml_json_response([{
        "success": False,
        "message": f"Unknown operation_type: {operation_type}",
        "error_type": "InvalidOperation"
    }], studio_config=studio_config)


def task_development_tools() -> List[Tool]:
    """Get task development tools"""
    return [
        Tool(
            name="task_query_operation",
            description=(
                "Execute query operations for task development. "
                "Supports SQL validation before saving tasks.\n\n"
                "Available operations:\n"
                "- validate_sql: Validate SQL syntax and check for destructive operations (DROP/DELETE/TRUNCATE)\n\n"
                "For detailed documentation, refer to skill references:\n"
                "- cz_mcp/skills/task-development/references/query-operations.md"
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "operation_type": {
                        "type": "string",
                        "description": "Operation type: validate_sql"
                    },
                    "parameters": {
                        "type": "object",
                        "description": "Operation parameters (see references for details)"
                    }
                },
                "required": ["operation_type", "parameters"]
            },
            handler=handle_task_query_operation,
            tags=["task-development", "query", "validation"]
        ),
        Tool(
            name="task_management_operation",
            description=(
                "Manage task lifecycle for non-integration tasks. "
                "Supports creating tasks, saving content, configuring schedules, and retrieving configurations.\n\n"
                "❌ Do NOT use this tool to create flow nodes (use create_flow_node instead). "
                "For saving flow node schedule config, use save_task_configuration directly.\n\n"
                "Available operations:\n"
                "- create_task: Create a new task (returns task_id)\n"
                "- save_content: Save task content (SQL/Shell/Python scripts)\n"
                "- save_schedule: Configure task schedule and dependencies\n"
                "- get_schedule: Retrieve task schedule configuration\n\n"
                "For detailed documentation, refer to skill references:\n"
                "- cz_mcp/skills/task-development/references/task-management-operations.md\n"
                "- cz_mcp/skills/task-development/references/task-types.md\n"
                "- cz_mcp/skills/task-development/references/schedule-configuration.md"
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "operation_type": {
                        "type": "string",
                        "description": "Operation type: create_task, save_content, save_schedule, get_schedule"
                    },
                    "parameters": {
                        "type": "object",
                        "description": "Operation parameters (see references for details)"
                    }
                },
                "required": ["operation_type", "parameters"]
            },
            handler=handle_task_management_operation,
            tags=["task-development", "management", "schedule"]
        )
    ]
