# coding=utf-8
"""
Studio-specific tools for MCP Studio server
Handles Studio API interactions for scheduled task management
"""
import json
import logging
from datetime import datetime, timezone
from typing import List

from mcp.types import TextContent, EmbeddedResource

from cz_mcp.common.utilities import ResponseBuilder
from cz_mcp.core.tool_registry import Tool
from cz_mcp.handlers.ide_admin_server import get_backfill_task_detail as api_get_backfill_task_detail
from cz_mcp.handlers.ide_admin_server import list_backfill_instances as api_list_backfill_instances
from cz_mcp.handlers.ide_admin_server import list_backfill_tasks as api_list_backfill_tasks
from cz_mcp.handlers.ide_admin_server import create_complement_job as api_create_complement_job
from cz_mcp.handlers.ide_admin_server import get_all_downstream as api_get_all_downstream
from cz_mcp.handlers.ide_admin_server import check_vcluster_create_permission as api_check_vcluster_create_permission
from ..common.redirect_url_utils import _build_ops_studio_url
from ..studio_config_manager import StudioConfig

from loguru import logger


async def handle_list_backfill_tasks(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    list backfill task in Clickzetta Studio
    """
    if arguments is None:
        arguments = {}

    try:
        # Extract parameters
        task_name_like = arguments.get("task_name_like", "")

        page_index = arguments.get("page_index", 1)
        page_size = arguments.get("page_size", 20)

        run_status = arguments.get("run_status")
        submitter = arguments.get("submitter")

        query_plan_time_left = arguments.get("query_plan_time_left")
        query_plan_time_right = arguments.get("query_plan_time_right")
        # Get auth context from server core


        project_id = arguments.get("project_id")
        # Use config project ID if not provided
        if project_id is None:
            project_id = studio_config.project_id

        logger.info(f"Listing backfill task for project_id: {project_id}")

        # Call the API
        response = api_list_backfill_tasks(
            projectId=project_id,
            taskNameLike=task_name_like,
            runStatus=run_status,
            submitter=submitter,
            queryPlanTimeLeft=query_plan_time_left,
            queryPlanTimeRight=query_plan_time_right,
            pageIndex=page_index,
            pageSize=page_size,
            jwt_token=studio_config.token,
            instance_name=studio_config.instance,
            user_id = studio_config.user_id,
            instance_id=studio_config.instance_id,
            account_id= studio_config.tenant_id,
            workspace_name= studio_config.workspace,
            env=studio_config.env
        )

        # Parse and format the response
        response_data = json.loads(response)

        if response_data.get("code") == "200":

            res_page_index = response_data.get("pageIndex", page_index)
            tasks = response_data.get("data", [])
            count = response_data.get("count")

            # Format the response for better readability
            formatted_response = {
                "success": True,
                "message": "Successfully list backfill tasks",
                "backfill_task_list": tasks,
                "total_count": count,
                "page_index": res_page_index,
                "page_size": page_size
            }

            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[handle_list_backfill_task]API request failed: {response_data.get('msg', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in list backfill tasks: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


def list_backfill_tasks_tools() -> List[Tool]:
    """Get all Studio-specific tools"""
    return [
        Tool(
            name="list_backfill_tasks",
            description=(
                "List backfill (complement) tasks in Clickzetta Studio. "
                "Note: 'complement' is used as a synonym for 'backfill' in this product. "
                "This tool returns one page of results per call. When the user requests the full list, "
                "the assistant MUST repeatedly call this tool (incrementing page_index each time) until "
                "an empty page or a page smaller than page_size is returned."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "project_id": {
                        "type": "integer",
                        "description": "Project ID."
                    },
                    "page_index": {
                        "type": "integer",
                        "description": "Page index (1-based).",
                        "default": 1
                    },
                    "page_size": {
                        "type": "integer",
                        "description": "Page size (default 50).",
                        "default": 50
                    },
                    "task_name_r_like": {
                        "type": "string",
                        "description": "Fuzzy search string for task name (optional)."
                    },
                    "run_status": {
                        "type": "integer",
                        "description": "Backfill run status. Optional values: 1 = running, 4 = finished. If omitted, returns all statuses.",
                        "enum": [1, 4]
                    },
                    "submitter": {
                        "type": "string",
                        "description": "Submitter of the backfill task (optional)."
                    },
                    "query_plan_time_left": {
                        "type": "integer",
                        "description": "Left bound (inclusive) of planned execution time, in milliseconds timestamp (optional)."
                    },
                    "query_plan_time_right": {
                        "type": "integer",
                        "description": "Right bound (inclusive) of planned execution time, in milliseconds timestamp. Should be paired with query_plan_time_left (optional)."
                    }
                },
                "additionalProperties": False,
                "required": ["project_id", "page_index", "page_size"]
            },
            handler=handle_list_backfill_tasks,
            tags=["backfill", "complement", "tasks", "pagination"],
            samples=[
                {
                    "description": "List first page of backfill tasks in project 2001 with default page size.",
                    "query": {
                        "project_id": 2001,
                        "page_index": 1,
                        "page_size": 50
                    }
                },
                {
                    "description": "Search backfill tasks in running status, with name like 'daily_etl', submitted by 'alice', within a plan time window.",
                    "query": {
                        "project_id": 2001,
                        "page_index": 1,
                        "page_size": 50,
                        "task_name_r_like": "daily_etl",
                        "submitter": "alice",
                        "query_plan_time_left": 1764691200000,
                        "query_plan_time_right": 1767110400000,
                        "run_status": 1
                    }
                }
            ]
        ),
    ]


async def handle_get_backfill_task_detail(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    get backfill task detail in Clickzetta Studio
    """
    if arguments is None:
        arguments = {}

    try:
        # Extract parameters

        backfill_task_id = arguments.get("backfill_task_id")
        # Get auth context from server core
        config = studio_config

        # Use config project ID if not provided

        logger.info(f"Getting backfill task detail for task {backfill_task_id}")

        # Call the API
        response = api_get_backfill_task_detail(
            backFillTaskId=backfill_task_id,
            jwt_token=config.token,
            instance_name=config.instance,
            user_id=config.user_id,
            instance_id=config.instance_id,
            account_id=config.tenant_id,
            env=config.env,
            workspace_name=config.workspace
        )

        # Parse and format the response
        response_data = json.loads(response)

        if response_data.get("code") == "200":
            data = response_data.get("data", {})

            # Format the response for better readability
            formatted_response = {
                "success": True,
                "message": "Successfully get backfill task detail",
                "data": data
            }
            studio_url = _build_ops_studio_url(studio_config, backfill_task_id, 'complement',
                                               config.env) if backfill_task_id else None
            if studio_url:
                formatted_response["redirect_url"] = studio_url

            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[handle_get_backfill_task_detail]API request failed: {response_data.get('msg', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in get backfill task detail: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


def get_backfill_task_detail_tools() -> List[Tool]:
    """Get all Studio-specific tools"""
    return [
        Tool(
            name="get_backfill_task_detail",
            description=(
                "Get details of a backfill (complement) task in Clickzetta Studio. "
                "This tool retrieves the full metadata and configuration for the specified backfill task."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "backfill_task_id": {
                        "type": "integer",
                        "description": "Unique ID of the backfill (complement) task."
                    }
                },
                "additionalProperties": False,
                "required": ["backfill_task_id"]
            },
            handler=handle_get_backfill_task_detail,
            tags=["backfill", "complement", "task_detail"],
            samples=[
                {
                    "description": "Get configuration detail of backfill task 90001.",
                    "query": {
                        "backfill_task_id": 90001
                    }
                }
            ]
        ),
    ]


async def handle_list_backfill_instances(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    list backfill instances
    """
    if arguments is None:
        arguments = {}

    try:
        # Extract parameters

        backfill_task_id = arguments.get("backfill_task_id")
        task_name_r_like = arguments.get("task_name_r_like")
        instance_status_list = arguments.get("instance_status_list")
        page_index = arguments.get("page_index")
        page_size = arguments.get("page_size")
        # Get auth context from server core
        config = studio_config

        # Use config project ID if not provided

        logger.info(f"Getting instance list of backfill task id  {backfill_task_id}")

        # Call the API
        response = api_list_backfill_instances(
            backFillTaskId=backfill_task_id,
            taskNameLike=task_name_r_like,
            instanceStatusList=instance_status_list,
            pageIndex=page_index,
            pageSize=page_size,
            jwt_token=config.token,
            instance_name=config.instance,
            user_id=config.user_id,
            instance_id=config.instance_id,
            account_id=config.tenant_id,
            env=config.env,
            workspace_name=config.workspace
        )

        # Parse and format the response
        response_data = json.loads(response)

        if response_data.get("code") == "200":
            res_page_index = response_data.get("pageIndex", page_index)
            tasks = response_data.get("data", [])
            count = response_data.get("count")

            # Format the response for better readability
            formatted_response = {
                "success": True,
                "message": "Successfully list backfill instances",
                "instance_list": tasks,
                "total_count": count,
                "page_index": res_page_index,
                "page_size": page_size
            }

            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[handle_list_backfill_instances]API request failed: {response_data.get('msg', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in list backfill instances: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


def list_backfill_instances_tools() -> List[Tool]:
    """Get all Studio-specific tools"""
    return [
        Tool(
            name="list_backfill_instances",
            description=(
                "List the instances associated with a specific backfill (complement) task in Clickzetta Studio. "
                "Supports pagination and optional fuzzy search on task names, instance status list within the backfill task. "
                "This tool returns one page of results per call. When the user requests the full list, "
                "the assistant MUST repeatedly call this tool (incrementing page_index each time) until "
                "an empty page or a page smaller than page_size is returned."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "backfill_task_id": {
                        "type": "integer",
                        "description": "ID of the backfill (complement) task."
                    },
                    "page_index": {
                        "type": "integer",
                        "description": "Pagination start index (1-based)."
                    },
                    "page_size": {
                        "type": "integer",
                        "description": "Page size, default is 50."
                    },
                    "task_name_r_like": {
                        "type": "string",
                        "description": (
                            "Optional fuzzy search string for task names under the backfill task. "
                            "If empty, all tasks are returned."
                        ),
                        "default": ""
                    },
                    "instance_status_list": {
                        "type": "array",
                        "items": {"type": "integer"},
                        "description": (
                            "List of instance status values (optional). Supported values: "
                            "1=Success, 2=Not started, 3=Failed, 4=Running, "
                            "5=Waiting for resources, 6=Waiting for upstream, "
                            "7=Paused, 8=Upstream failed blocking."
                        )
                    }
                },
                "additionalProperties": False,
                "required": ["backfill_task_id", "page_index", "page_size"]
            },
            handler=handle_list_backfill_instances,
            tags=["backfill", "complement", "instances", "pagination"],
            samples=[
                {
                    "description": "List instances of backfill task 90001, first page with default size.",
                    "query": {
                        "backfill_task_id": 90001,
                        "page_index": 1,
                        "page_size": 50
                    }
                },
                {
                    "description": "List backfill instances with fuzzy task name search 'ods_user'.",
                    "query": {
                        "backfill_task_id": 90001,
                        "page_index": 1,
                        "page_size": 50,
                        "task_name_r_like": "ods_user"
                    }
                }
            ]
        ),
    ]


async def handle_create_backfill_job(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    Create one backfill(complement) job for periodic schedule task.
    """
    if arguments is None:
        arguments = {}

    try:
        config = studio_config
        schedule_task_id = int(arguments.get("schedule_task_id"))
        biz_start_time = int(arguments.get("biz_start_time"))
        biz_end_time = int(arguments.get("biz_end_time"))
        sql_vc_code = arguments.get("sql_vc_code") or "DEFAULT"
        include_root = int(arguments.get("include_root", 1))
        is_concurrence = int(arguments.get("is_concurrence", 0))
        concurrence_number = int(arguments.get("concurrence_number", 1))
        self_dep = int(arguments.get("self_dep", 0))
        complement_type = int(arguments.get("complement_type", 1))
        next_type = int(arguments.get("next_type", 0))
        check_permission = bool(arguments.get("check_permission", True))
        check_downstream = bool(arguments.get("check_downstream", True))

        complement_job_name = arguments.get("complement_job_name")
        if not complement_job_name:
            suffix = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
            complement_job_name = f"S_{schedule_task_id}_{suffix}"

        downstream_tasks = []
        if check_downstream:
            downstream_resp = api_get_all_downstream(
                schedule_task_id=schedule_task_id,
                workspace=config.workspace,
                jwt_token=config.token,
                instance_name=config.instance,
                instance_id=config.instance_id,
                env=config.env,
            )
            downstream_data = json.loads(downstream_resp)
            if str(downstream_data.get("code")) != "200":
                return ResponseBuilder.create_yaml_json_response([{
                    "success": False,
                    "message": f"[handle_create_backfill_job]get_all_downstream failed: {downstream_data.get('message', 'Unknown error')}",
                    "code": downstream_data.get("code"),
                    "raw_response": downstream_data,
                }], studio_config=studio_config)
            raw_downstream = downstream_data.get("data")
            if isinstance(raw_downstream, list):
                downstream_tasks = raw_downstream

        if check_permission:
            permission_resp = api_check_vcluster_create_permission(
                workspace=config.workspace,
                jwt_token=config.token,
                instance_name=config.instance,
                instance_id=config.instance_id,
                env=config.env,
            )
            permission_data = json.loads(permission_resp)
            if str(permission_data.get("code")) not in {"200", "0"}:
                return ResponseBuilder.create_yaml_json_response([{
                    "success": False,
                    "message": f"[handle_create_backfill_job]check_permission failed: {permission_data.get('message', 'Unknown error')}",
                    "code": permission_data.get("code"),
                    "raw_response": permission_data,
                }], studio_config=studio_config)
            perm_value = permission_data.get("data")
            if isinstance(perm_value, bool) and not perm_value:
                return ResponseBuilder.create_yaml_json_response([{
                    "success": False,
                    "message": "Permission denied: no CREATE permission on VCLUSTER.",
                    "code": "PERMISSION_DENIED",
                    "raw_response": permission_data,
                }], studio_config=studio_config)

        payload = {
            "includeRoot": include_root,
            "sqlVcCode": sql_vc_code,
            "complementJobName": complement_job_name,
            "isConcurrence": is_concurrence,
            "complementType": complement_type,
            "concurrenceNumber": concurrence_number,
            "selfDep": self_dep,
            "dateList": [{"bizStartDate": biz_start_time, "bizEndDate": biz_end_time}],
            "nextType": next_type,
            "complementBizDateBeanList": [{"bizStartDate": biz_start_time, "bizEndDate": biz_end_time}],
            "scheduleTaskId": schedule_task_id,
            "userId": config.user_id,
            "createBy": config.username,
            "projectId": config.project_id,
            "workspace": config.workspace,
        }

        response = api_create_complement_job(
            payload=payload,
            jwt_token=config.token,
            instance_name=config.instance,
            instance_id=config.instance_id,
            env=config.env,
        )
        response_data = json.loads(response)

        if str(response_data.get("code")) == "200":
            return ResponseBuilder.create_yaml_json_response([{
                "success": True,
                "message": "Successfully create backfill task",
                "backfill_task_id": response_data.get("data"),
                "schedule_task_id": schedule_task_id,
                "complement_job_name": complement_job_name,
                "downstream_count": len(downstream_tasks),
            }], studio_config=studio_config)

        return ResponseBuilder.create_yaml_json_response([{
            "success": False,
            "message": f"[handle_create_backfill_job]API request failed: {response_data.get('message', 'Unknown error')}",
            "code": response_data.get("code"),
            "raw_response": response_data,
        }], studio_config=studio_config)
    except Exception as e:
        logger.error(f"Error in create backfill task: {e}")
        return ResponseBuilder.create_yaml_json_response([{
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__,
        }], studio_config=studio_config)


def create_backfill_job_tools() -> List[Tool]:
    return [
        Tool(
            name="create_backfill_job",
            description=(
                "Create one backfill(complement) job for a periodic schedule task. "
                "This tool optionally checks downstream relationship and VCLUSTER CREATE permission "
                "before submitting complement job."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "schedule_task_id": {
                        "type": "integer",
                        "description": "Schedule task ID for creating backfill job."
                    },
                    "biz_start_time": {
                        "type": "integer",
                        "description": "Business start time in milliseconds timestamp."
                    },
                    "biz_end_time": {
                        "type": "integer",
                        "description": "Business end time in milliseconds timestamp."
                    },
                    "sql_vc_code": {
                        "type": "string",
                        "description": "VC code for executing complement tasks.",
                        "default": "DEFAULT"
                    },
                    "complement_job_name": {
                        "type": "string",
                        "description": "Optional complement job name. Auto-generated when omitted."
                    },
                    "include_root": {
                        "type": "integer",
                        "description": "Whether include root task. 1=yes, 0=no.",
                        "default": 1
                    },
                    "is_concurrence": {
                        "type": "integer",
                        "description": "Whether run in parallel. 1=yes, 0=no.",
                        "default": 0
                    },
                    "concurrence_number": {
                        "type": "integer",
                        "description": "Parallel number when is_concurrence=1.",
                        "default": 1
                    },
                    "self_dep": {
                        "type": "integer",
                        "description": "Self dependency flag.",
                        "default": 0
                    },
                    "complement_type": {
                        "type": "integer",
                        "description": "Complement type. Default 1.",
                        "default": 1
                    },
                    "next_type": {
                        "type": "integer",
                        "description": "Next type. Default 0.",
                        "default": 0
                    },
                    "check_permission": {
                        "type": "boolean",
                        "description": "Whether to check VCLUSTER CREATE permission before submit.",
                        "default": True
                    },
                    "check_downstream": {
                        "type": "boolean",
                        "description": "Whether to query downstream relation before submit.",
                        "default": True
                    }
                },
                "additionalProperties": False,
                "required": ["schedule_task_id", "biz_start_time", "biz_end_time"]
            },
            handler=handle_create_backfill_job,
            tags=["backfill", "complement", "create", "task_run"],
            samples=[
                {
                    "description": "Create one complement task for schedule task 13284040.",
                    "query": {
                        "schedule_task_id": 13284040,
                        "biz_start_time": 1775145600000,
                        "biz_end_time": 1775231999000,
                        "sql_vc_code": "DEFAULT"
                    }
                }
            ]
        ),
    ]
