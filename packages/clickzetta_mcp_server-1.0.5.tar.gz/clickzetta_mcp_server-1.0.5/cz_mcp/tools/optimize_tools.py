from typing import List
import json
import os

from loguru import logger
from mcp.types import TextContent

from ..common import ResponseBuilder
from ..core.tool_registry import Tool
from ..handlers.job_performance_handler import analyze_job_performance
from ..studio_config_manager import StudioConfig
from ..utils.config_utils import read_url, read_api
from ..utils.request_utils import RequestUtils


def get_job_plan_url(workspace_name: str, job_id: str, instance_id: int, user_id: int,
                     extended: bool, env: str, jwt_token: str, instance_name: str) -> dict:
    """Get job profile URL from API"""
    url = read_url(env=env) + read_api("JOB_PROFILE_URL")

    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": str(jwt_token),
        "userId": str(user_id),
        "instanceId": str(instance_id),
        "accountId": str(user_id),
        "instanceName": str(instance_name),
    }

    params = {
        "workspaceName": workspace_name,
        "jobId": job_id,
        "extended": extended,
        "jsonFormat": True
    }

    response = RequestUtils().get(url=url, headers=headers, params=params)
    if response.status_code != 200:
        logger.error(f"Failed to get job profile URL. Status code: {response.status_code}, Response: {response.text}")
        raise ValueError(f"Failed to get job profile URL: {response.text}")

    return response.json()


def get_job_profile(workspace_name: str, job_id: str, instance_id: int, instance_name: str,
                    jwt_token: str, env: str) -> dict:
    """Get job profile from API"""
    url = read_url(env=env) + read_api("GET_JOB_PROFILE_URL")

    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": str(jwt_token),
        "instanceId": str(instance_id),
        "instanceName": str(instance_name),
    }

    params = {
        "jobId": job_id,
        "workspaceName": workspace_name,
        "instanceId": instance_id,
        "brief": False
    }

    response = RequestUtils().get(url=url, headers=headers, params=params)
    if response.status_code != 200:
        logger.error(f"Failed to get job profile. Status code: {response.status_code}, Response: {response.text}")
        raise ValueError(f"Failed to get job profile: {response.text}")

    return response.json()


def _build_ai_review_prompt(analysis_mode: str) -> str:
    """构建 AI 研判 prompt，根据分析模式返回不同的指令"""
    base_prompt = (
        "你是 Clickzetta 增量计算性能专家。以下是规则引擎的分析结果。\n\n"
        "请你做以下分析：\n\n"
        "1. **因果关联分析**：检查 findings 之间是否有因果关系。\n"
        "   常见因果链：\n"
        "   - DATA_SKEW → STAGE_SPILLING → RESOURCE_INEFFICIENCY\n"
        "   - SINGLE_DOP_AGG → BOTTLENECK_ANALYSIS(SINGLE_OP_DOMINANT)\n"
        "   - TABLESINK_DOP(DOP被调小) → RESOURCE_INEFFICIENCY\n"
        "   如果发现因果链，指出根因和影响链。\n\n"
        "2. **优先级建议**：如果有多个 recommendations，基于以下原则重新排序：\n"
        "   - 根因问题的参数优先于症状问题的参数\n"
        "   - 影响范围大的参数优先（影响多个 stage）\n"
        "   - confidence=high 的优先于 medium/low\n"
        "   给出'如果只能改一个参数，建议先改哪个'的建议。\n\n"
        "3. **补充洞察**：检查 analysis_scope 中是否有被 findings 遗漏的重要信息。\n"
        "   特别关注：\n"
        "   - confidence=medium/low 的 findings，是否有额外证据支持或否定\n"
        "   - 多个 stage 出现相似问题时，是否有共同根因\n"
        "   - insights 中 level=detail 的信息，是否有值得提升为 important 的\n\n"
        "4. **stage_summary 全局审视**：检查 stage_summary 中每个 stage 的关键指标，\n"
        "   发现规则引擎可能遗漏的问题。特别关注：\n"
        "   - effective_spill_bytes 较高但没有对应 STAGE_SPILLING finding 的 stage\n"
        "   - task_skew.skew_ratio 较高但没有 DATA_SKEW finding 的 stage\n"
        "   - top_operators 中 stage_pct 极高（>80%）的单一算子瓶颈\n"
        "   - 多个 stage 的 dop 远低于 vc_cores，可能存在全局资源竞争\n\n"
        "5. **风险提示**：对于 recommendations 中的参数建议，是否有潜在风险或副作用。\n"
    )

    if analysis_mode == 'expert':
        expert_prompt = (
            "\n\n--- 专家分析额外要求 ---\n\n"
            "6. **规则盲区检查**：基于你对 Clickzetta 增量计算的理解，是否有规则引擎未覆盖的问题？\n"
            "   检查 analysis_scope 和 stage_summary 中是否存在异常 pattern。\n\n"
            "7. **参数组合分析**：多个参数建议之间是否有依赖或冲突关系？\n"
            "   是否需要按特定顺序设置？\n\n"
            "8. **深度根因分析**：对于 confidence=low/medium 的 findings，\n"
            "   给出更确定的诊断。\n\n"
            "9. **优化方案设计**：综合所有发现，给出一个完整的优化方案，\n"
            "   包括参数设置顺序、预期效果、验证方法。\n"
        )
        return base_prompt + expert_prompt

    return base_prompt


async def handle_job_performance_analysis(arguments: dict, studio_config: StudioConfig = None, **kwargs) -> List[
    TextContent]:
    """Analyze job performance using job plan and profile data"""
    job_profile_response = None
    try:
        if arguments.get('workspace_name'):
            workspace_name = arguments.get('workspace_name')
        else:
            workspace_name = studio_config.workspace
        logger.info(f"[handle_job_performance_analysis] Workspace name: {workspace_name}")
        job_id = arguments.get('job_id')
        instance_id = studio_config.instance_id
        user_id = studio_config.user_id
        enable_state_table = arguments.get('enable_state_table', True)
        enable_incremental_algorithm = arguments.get('enable_incremental_algorithm', False)
        analysis_mode = arguments.get('analysis_mode', 'quick')
        job_plan_path = arguments.get('path')
        extended = True

        if not workspace_name or not job_id:
            return ResponseBuilder.create_error_response(
                ValueError("workspace_name and job_id are required")
            )

        # If job_plan_path is provided, load files from local path
        if job_plan_path:
            logger.info(f"Loading job plan and profile from local path: {job_plan_path}")

            # Load job_plan.json
            job_plan_file = os.path.join(job_plan_path, 'job_plan.json')
            plan_file = os.path.join(job_plan_path, 'plan.json')
            job_plan_data = None
            if os.path.exists(job_plan_file):
                try:
                    with open(job_plan_file, 'r', encoding='utf-8') as f:
                        job_plan_data = json.load(f)
                    logger.info(f"Successfully loaded job_plan.json from {job_plan_file}")
                except Exception as e:
                    logger.warning(f"Failed to load job_plan.json: {e}")
            elif os.path.exists(plan_file):
                try:
                    with open(plan_file, 'r', encoding='utf-8') as f:
                        job_plan_data = json.load(f)
                    logger.info(f"Successfully loaded job_plan.json from {plan_file}")
                except Exception as e:
                    logger.warning(f"Failed to load job_plan.json: {e}")
            else:
                logger.info(f"job_plan.json not found at {job_plan_file}, proceeding without plan data")

            # Load job_profile.json
            job_profile_file = os.path.join(job_plan_path, 'job_profile.json')
            if not os.path.exists(job_profile_file):
                return ResponseBuilder.create_error_response(
                    ValueError(f"job_profile.json not found at {job_profile_file}")
                )

            try:
                with open(job_profile_file, 'r', encoding='utf-8') as f:
                    job_profile_response = json.load(f)
                logger.info(f"Successfully loaded job_profile.json from {job_profile_file}")
            except Exception as e:
                logger.error(f"Failed to load job_profile.json: {e}")
                return ResponseBuilder.create_error_response(
                    error=e,
                    context=f"Failed to load job_profile.json from {job_profile_file}"
                )
        else:
            # Original download logic
            # Get job plan URL
            try:
                plan_url_response = get_job_plan_url(
                    workspace_name=workspace_name,
                    job_id=job_id,
                    instance_id=instance_id,
                    user_id=user_id,
                    extended=extended,
                    env=studio_config.env,
                    jwt_token=studio_config.token,
                    instance_name=studio_config.instance
                )
            except Exception as e:
                logger.error(f"Failed to get job plan json. {e}")
                return ResponseBuilder.create_error_response(
                    error=e,
                    context=f"Can not get job plan json by job_id:{job_id}"
                )

            # Check if job plan URL exists, if not, set job_plan_data to None
            job_plan_data = None
            if (plan_url_response.get('data') and
                plan_url_response['data'].get('locations') and
                plan_url_response['data']['locations'].get("JobPlanJson")):

                job_plan_url = plan_url_response['data']['locations']['JobPlanJson']

                # Download job plan
                job_plan_response = RequestUtils().get(url=job_plan_url)
                if job_plan_response.status_code != 200:
                    return ResponseBuilder.create_error_response(
                        ValueError(f"Failed to download job plan: {job_plan_response.text}")
                    )
                job_plan_data = job_plan_response.json()
            else:
                logger.info(f"Job plan URL not found, proceeding without plan data for job_id: {job_id}")

            # Get job profile
            try:
                job_profile_response = get_job_profile(
                    workspace_name=workspace_name,
                    job_id=job_id,
                    instance_id=instance_id,
                    instance_name=studio_config.instance,
                    jwt_token=studio_config.token,
                    env=studio_config.env
                )
            except Exception as e:
                logger.error(f"Failed to get job profile json. {e}")
                return ResponseBuilder.create_error_response(
                    error=e,
                    context=f"Can not get job profile json by job_id:{job_id}"
                )

            resp_status = job_profile_response.get('respStatus', {})
            if resp_status.get('errorCode'):
                error_msg = resp_status.get('errorMsg', 'Unknown error')
                error_code = resp_status.get('errorCode')
                logger.error(f"Job profile API can not get. errorCode: {error_code}, errorMsg: {error_msg}")
                return ResponseBuilder.create_error_response(
                    ValueError(f"[{error_code}] {error_msg}")
                )

        # Run analysis using handler
        analysis_result = analyze_job_performance(job_plan_data, job_profile_response, enable_incremental_algorithm,
                                                  enable_state_table, analysis_mode)

        optimization_principles = (
            "优化参数推荐必须遵守的原则：\n"
            "❌ 禁止行为：\n"
            "1. 不要给没有依据的参数\n"
            "2. 不要凭空给 flag，必须为data中明确提及的 flag，且询问用户是否需要执行\n"
            "3. 不要推荐已存在且正确的参数\n"
            "✅ 必须做到：\n"
            "1. 仅在发现实际问题时才建议参数\n"
            "2. 每个建议必须有明确的触发条件\n"
            "3. 每个建议必须引用实际数据作为证据\n"
            "4. 必须检查 settings 避免重复建议\n"
            "📋 其他可能有用的参数：对于那些可能有用但没有明确问题证据的参数，单独列出，不要给强烈建议，让用户自行决定是否重跑"
        )

        # detailed/expert 模式：附加 AI 研判指令
        additional_prefs = {"optimization_principles": optimization_principles}
        if analysis_mode in ('detailed', 'expert'):
            ai_review_prompt = _build_ai_review_prompt(analysis_mode)
            additional_prefs["ai_review_prompt"] = ai_review_prompt
        
        # expert 模式：附加 reference 上下文和确认提示
        if analysis_mode == 'expert' and isinstance(analysis_result, dict):
            reference_context = analysis_result.pop('reference_context', '')
            token_estimate = analysis_result.pop('token_estimate', 0)
            requires_confirmation = analysis_result.pop('requires_confirmation', False)
            
            if reference_context:
                additional_prefs["reference_context"] = reference_context
            
            if requires_confirmation:
                additional_prefs["expert_mode_notice"] = (
                    f"⚠️ 专家分析模式已启用。\n"
                    f"已加载相关参考文档，预计消耗约 {token_estimate} tokens。\n"
                    f"请基于规则引擎结果、analysis_scope 和 reference_context 进行专家级分析。"
                )

        return ResponseBuilder.create_yaml_json_response(
            analysis_result,
            data_id=f"job_analysis_{job_id}",
            studio_config=studio_config,
            additional_user_preferences=additional_prefs
        )

    except Exception as e:
        logger.error(f"Job performance analysis failed: {e}")
        return ResponseBuilder.create_error_response(e, "job_performance_analysis")


def job_performance_analysis_tool() -> List[Tool]:
    """Job performance analysis tool"""
    return [Tool(
        name="fetch_job_performance_data",
        description=(
            "⚠️ PREREQUISITE: Before calling this tool, you MUST call get_useful_skills with "
            "task_description='job performance analysis' and follow the returned skill instructions. "
            "Calling this tool without the skill guidance will produce incomplete and incorrect results.\n"
            "Fetches raw job plan and profile data for a given job ID. Returns structured data only — "
            "does NOT interpret results. You MUST load the job-performance-analyzer skill first to "
            "perform analysis and generate optimization recommendations.\n"
            "Note: This tool params job ID does not need to be checked for existence.\n"
            "## Example Usage\n"
            "- Analyze task 2026012808001805432z9g3fx1sok.\n"
            "- Please analyze job ID 2026012808001805432z9g3fx1sok and provide tuning suggestions.\n"),
        input_schema={
            "type": "object",
            "properties": {
                "workspace_name": {
                    "type": "string",
                    "description": "Workspace name"
                },
                "job_id": {
                    "type": "string",
                    "description": "Lakehouse engine sql job_id. Note: This job ID does not need to be checked for existence."
                },
                "enable_incremental_algorithm": {
                    "type": "boolean",
                    "description": "Enable incremental algorithm, default is False"
                },
                "enable_state_table": {
                    "type": "boolean",
                    "description": "Enable state table optimization, default is True"
                },
                "analysis_mode": {
                    "type": "string",
                    "enum": ["quick", "detailed", "expert"],
                    "default": "quick",
                    "description": "分析模式，默认 quick。必须严格按以下关键词匹配，不要自行升级：quick='分析'/'看看'/'帮我分析'（默认）；detailed='详细分析'/'仔细看看'/'再详细分析下'；expert=仅当用户原话包含'专家模式'/'深度分析'/'全面分析'时才用。'详细'='detailed'，不是'expert'。不确定时选 quick。"
                },
                "path": {
                    "type": "string",
                    "description": "Optional local folder path containing both job_plan.json and job_profile.json. If provided, the tool will load data from these local files instead of downloading from API."
                },
            },
            "additionalProperties": False,
            "required": ["job_id"]
        },
        handler=handle_job_performance_analysis,
        tags=["optimization", "job", "performance", "normalize"]
    )]


def get_optimize_tools() -> List[Tool]:
    """Get all optimization tools"""
    tools = []
    tools.extend(job_performance_analysis_tool())
    return tools
