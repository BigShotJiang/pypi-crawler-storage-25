"""
Workspace tools for MCP Studio server
Handles workspace listing and management
"""
from typing import List

from loguru import logger
from mcp.types import TextContent, EmbeddedResource

from cz_mcp.common.utilities import ResponseBuilder
from cz_mcp.core.tool_registry import Tool
from cz_mcp.query.sql_intelligence import sql_intelligence
from cz_mcp.studio_config_manager import StudioConfig
from cz_mcp.tools.agent.show_object import handle_show_object_list_v2
from cz_mcp.utils.datasource_utils import get_datasource_by_name, execute_query


async def handle_execute_sql(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:

    if arguments is None:
        arguments = {}

    try:
        # Get auth context from server core
        config = studio_config
        page_size = 20
        datasource_name = arguments.get("datasource_name")
        ds_type = None

        sql = arguments.get("sql")

        if datasource_name is None:
            logger.info(f"No datasource name provided, set default datasource name to {config.workspace}")
            datasource_name = f"LAKEHOUSE_{config.workspace}"
            ds_type = 1

        logger.info(f"list datasources by name: {datasource_name}")
        response = get_datasource_by_name(datasource_name=datasource_name, ds_name=datasource_name,ds_type=ds_type,server=studio_config)
        # Parse and format the response
        # Failback logic: if response is None, try with workspace_id format
        if response is None:
            failback_datasource_name = f"LAKEHOUSE_{studio_config.project_id}_{config.workspace}"
            logger.info(f"Failback: trying datasource name: {failback_datasource_name}")
            response = get_datasource_by_name(datasource_name=failback_datasource_name,
                                              ds_name=failback_datasource_name, ds_type=ds_type,
                                              server=studio_config)
            if response is None:
                failback_datasource_name = config.workspace
                logger.info(f"Failback: trying datasource name: {failback_datasource_name}")
                response = get_datasource_by_name(datasource_name=failback_datasource_name,
                                                  ds_name=failback_datasource_name, ds_type=ds_type,
                                                  server=studio_config)
                if response is None:
                    return ResponseBuilder.create_yaml_json_response([{
                        "success": False,
                        "result_set": f"Datasource '{datasource_name}' or '{failback_datasource_name}' not found.",
                    }], studio_config=studio_config)

        ds_id = response["id"]

        result_set, error, job_id = execute_query(datasource_id=ds_id, sql=sql, env=studio_config.env, server=studio_config)

        if error:
            analysis = sql_intelligence.analyze_sql_error(error, sql)
            err_response = {
                "success": False,
                "error_type": analysis.get("error_type", "sql_execution_failed"),
                "friendly_message": analysis.get("friendly_message") or error,
                "suggestions": analysis.get("suggestions", [])[:3]
            }
            if job_id:
                err_response["job_id"] = job_id
            return ResponseBuilder.create_yaml_json_response([err_response], studio_config=studio_config)

        return ResponseBuilder.create_yaml_json_response([{
            "success": True,
            "result_set": result_set,
        }], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Unexpected error in handle_execute_sql: {e}")
        import traceback
        return ResponseBuilder.create_yaml_json_response([{
            "success": False,
            "error_type": "unexpected_error",
            "original_error": traceback.format_exc(),
        }], studio_config=studio_config)


def agent_execute_query_tool() -> List[Tool]:
    """Get agent execute query tools"""
    return [
        Tool(
            name="LH_execute_query",
            description=(

                "Execute SQL query on a specified datasource to verify SQL correctness. "
                "This tool allows agents to execute SQL queries against a datasource. "
                "If datasource_name is not provided, it will default to the workspace's Lakehouse datasource. "
                "The tool returns query results in a structured format.It cannot access Studio's management data files,"
                "scheduled task instances, or operational monitoring - use other Tools for those.\n\n"
                "** Clickzetta Lakehouse SQL Compatibility **:"
                "• Compatible with most basic Spark SQL syntax"
                "• CRITICAL: Specific functions, advanced syntax, and complex data types have Clickzetta-specific dialects"
                "• NEVER fabricate or guess SQL functions/syntax "
                "• When uncertain about SQL syntax, function availability, or data types, call get_product_knowledge first"
                "⚠️ IMPORTANT WARNINGS:\n"
                "• **information_schema compatibility**: Lakehouse's information_schema structure and schema "
                "DO NOT match standard databases (e.g., MySQL, PostgreSQL). Before querying information_schema, "
                "you MUST verify the actual schema structure. Do NOT assume it follows MySQL or other standard formats.\n"
                "• **Object identifier format**: When referencing database objects in SQL, you MUST use at least "
                "two-part qualified names (schema.table format). Examples: `public.users`, `schema1.table1`. "
                "Using single-part names (e.g., just `table1`) may fail or cause ambiguity."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "sql": {
                        "type": "string",
                        "description": (
                            "SQL query statement to execute. "
                            "**MUST use two-part qualified names for objects**: Use `schema.table` format (e.g., `public.users`, `schema1.table1`). "
                            "Single-part names may cause errors or ambiguity. "
                            "**If querying information_schema**: Verify the schema structure first as it differs from standard databases (MySQL/PostgreSQL)."
                        )
                    },
                    "datasource_name": {
                        "type": "string",
                        "description": "Name of the datasource to execute the query on. If not provided, defaults to the workspace's Lakehouse datasource (LAKEHOUSE_{workspace})"
                    }
                },
                "required": ["sql"]
            },
            handler=handle_execute_sql,
            tags=["agent", "query", "execute"]
        ),
        Tool(
            name="LH_show_object_list_v2",
            description=(
                "Lakehouse SDK low-level query tool that bypasses Studio to directly query the Lakehouse SQL engine.\n"
                "Lists Lakehouse database objects without needing to construct SQL, avoiding query failures due to SQL "
                "dialect issues. Supports intelligent filtering, statistical analysis, and filter suggestions. JOBS "
                "refers to Lakehouse SQL job concept, not to be confused with Studio tasks. If the user only needs to "
                "switch objects without actually querying, just return the recorded information without executing USE. "
                "You should use precise queries as much as possible to avoid too many objects.\n\n"
                "Object Hierarchy and Scope (归属关系):\n"
                "Lakehouse uses a hierarchical structure: Instance → Workspace → Schema → Objects\n\n"
                "1. Instance-Level Objects (全局共享, Instance级):\n"
                "   • USERS - Platform-level users (全局账号用户) and instance-level users (服务实例用户)\n"
                "   • ROLES - Instance-level roles (instance_admin, instance_user, instance_sre, etc.)\n"
                "   • SHARES - Cross-instance data sharing (visible across all workspaces in the instance)\n"
                "   → Query these without workspace/schema scope\n\n"
                "2. Workspace-Level Objects (Workspace级):\n"
                "   • WORKSPACES - Logical isolation units (MANAGED/SHARED/EXTERNAL)\n"
                "   • USERS - Workspace members (added from instance user pool)\n"
                "   • ROLES - Workspace roles (workspace_admin, workspace_dev, workspace_analyst, etc.)\n"
                "   • SCHEMAS - Data organization units (MANAGED/EXTERNAL/SHARED schemas)\n"
                "   • VCLUSTERS - Virtual clusters (GENERAL/ANALYTICS/INTEGRATION)\n"
                "   • CONNECTIONS - Cloud connections (STORAGE_CONNECTION/API_CONNECTION/CATALOG_CONNECTION)\n"
                "   • NETWORK_POLICY - IP access control policies\n"
                "   • JOBS - Execution history and scheduled tasks\n"
                "   → Query these at workspace scope (current workspace context)\n\n"
                "3. Schema-Level Objects (Schema级):\n"
                "   • TABLES - Base data storage (includes INDEXES)\n"
                "   • VIEWS - Virtual tables\n"
                "   • DYNAMIC_TABLES - Auto-refresh tables\n"
                "   • MATERIALIZED_VIEWS - Pre-computed views\n"
                "   • EXTERNAL_TABLES - External data mappings\n"
                "   • TABLE STREAMS - CDC change streams\n"
                "   • FUNCTIONS - SQL functions (BUILTIN/UDF/EXTERNAL FUNCTION)\n"
                "   • VOLUMES - Storage volumes (INTERNAL/EXTERNAL)\n"
                "   • PIPES - Automated data ingestion\n"
                "   → IMPORTANT: These objects MUST specify schema using 'in_schema' parameter!\n"
                "   → Example: To list tables, you MUST provide 'in_schema' (e.g., 'SHOW TABLES IN public')\n\n"
                "Main Features:\n"
                "• Smart Analysis: Analyzes all data and suggests useful filters\n"
                "• Accurate Statistics: Shows real counts in the database, not just displayed records\n"
                "• Filter Discovery: Informs about available fields and their possible values\n"
                "• Smart Suggestions: Recommends filters for hidden important objects\n"
                "• Two-Step Workflow: First call shows overview and suggestions, second call applies precise filtering\n\n"
                "Default Limits: FUNCTIONS(25), TABLES(20), SCHEMAS(20), maximum 100"
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "show_command": {
                        "type": "string",
                        "description": (
                            "Legacy parameter (backward compatible). You can use the following syntax to construct the SHOW command:\n"
                            "SHOW <object_type_plural>  [ IN <scope_object> ] [ LIKE '<pattern>' | WHERE <expr>] [LIMIT num];\n"
                            "Examples: SHOW tables LIKE 'user%'; SHOW tables WHERE is_view=true; SHOW tables IN public; SHOW volumes WHERE workspace_name='public'; SHOW jobs in VCLUSTER default;"
                        )
                    },
                    "object_type": {
                        "type": "string",
                        "enum": ["WORKSPACES", "TABLES", "VIEWS", "SCHEMAS", "CATALOGS", "FUNCTIONS",
                                 "EXTERNAL FUNCTIONS", "VOLUMES",
                                 "CONNECTIONS", "VCLUSTERS", "JOBS", "PIPES", "USERS",
                                 "ROLES", "GRANTS", "SHARES", "TABLE STREAMS", "DYNAMIC TABLES",
                                 "MATERIALIZED VIEWS", "EXTERNAL TABLES", "EXTERNAL SCHEMAS", "NETWORK POLICY"],
                        "description": "Type of objects to list (recommended over show_command)"
                    },
                    "in_schema": {
                        "type": "string",
                        "description": (
                            "Schema name to filter objects within. **REQUIRED for Schema-level objects**: "
                            "TABLES, VIEWS, DYNAMIC_TABLES, MATERIALIZED_VIEWS, EXTERNAL_TABLES, TABLE STREAMS, "
                            "FUNCTIONS (UDF and EXTERNAL FUNCTION require schema), VOLUMES, PIPES. "
                            "Optional for Workspace-level and Instance-level objects. "
                            "Note: VOLUMES does not support IN syntax currently, use WHERE workspace_name = 'schema' instead."
                        )
                    },
                    "like_pattern": {
                        "type": "string",
                        "description": "Optional LIKE pattern for filtering object names (e.g., 'user%')"
                    },
                    "where_condition": {
                        "type": "string",
                        "description": "Optional WHERE clause for advanced filtering (e.g., 'is_external = true')"
                    },
                    "table_type_filters": {
                        "type": "object",
                        "description": "Quick filters for table types (only for TABLES)",
                        "properties": {
                            "is_view": {"type": "boolean", "description": "Filter views"},
                            "is_external": {"type": "boolean", "description": "Filter external tables"},
                            "is_dynamic": {"type": "boolean", "description": "Filter dynamic tables"},
                            "is_stream": {"type": "boolean", "description": "Filter table streams"}
                        }
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of results to return (default varies by object type)",
                        "minimum": 1,
                        "maximum": 100
                    },
                    "smart_defaults": {
                        "type": "boolean",
                        "default": True,
                        "description": "Apply smart defaults (e.g., auto-limit for JOBS)"
                    }
                },
                "required": ["object_type"],  # 修复：object_type是必选参数
            },
            handler=handle_show_object_list_v2,
            tags=["read"],
            samples=[
                {
                    "description": "List all workspaces (Workspace-level object)",
                    "query": {
                        "object_type": "WORKSPACES"
                    }
                },
                {
                    "description": "List instance-level users (Instance-level object)",
                    "query": {
                        "object_type": "USERS"
                    }
                },
                {
                    "description": "List instance-level roles (Instance-level object)",
                    "query": {
                        "object_type": "ROLES"
                    }
                },
                {
                    "description": "List schemas in current workspace (Workspace-level object)",
                    "query": {
                        "object_type": "SCHEMAS"
                    }
                },
                {
                    "description": "List tables in public schema (Schema-level object - REQUIRES in_schema)",
                    "query": {
                        "object_type": "TABLES",
                        "in_schema": "public"
                    }
                },
                {
                    "description": "Find tables with names starting with 'user' in a specific schema",
                    "query": {
                        "object_type": "TABLES",
                        "in_schema": "public",
                        "like_pattern": "user%"
                    }
                },
                {
                    "description": "List functions in a schema (UDF/EXTERNAL FUNCTION require schema)",
                    "query": {
                        "object_type": "FUNCTIONS",
                        "in_schema": "public"
                    }
                },
                {
                    "description": "List jobs in a vcluster (Workspace-level object)",
                    "query": {
                        "object_type": "JOBS",
                        "where_condition": "vcluster_name = 'default'"
                    }
                }
            ],
        )
    ]
