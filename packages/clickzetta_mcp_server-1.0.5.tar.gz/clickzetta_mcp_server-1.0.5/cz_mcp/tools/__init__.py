"""
MCP Studio Tools
Provides tools for interacting with Clickzetta Studio API
"""
from .admin_tools import get_admin_tools
from .file_tools import create_task_tool, save_non_integration_task_content, get_task_detail_tool, get_task_configuration_detail_tool, \
    save_task_configuration_tool, save_task_configuration_v2_tools, preview_schedule_instance_times_tool, \
    publish_task_tool, save_integration_task_tool, list_folders_tool, list_tasks_tool
from .task_development_tools import task_development_tools
from .folder_tools import create_folder_tool
from .dqc_tools import create_dqc_rule
from .schedule_task_tools import get_published_task_dependencies_tools, get_task_statistics_tools
from .schedule_instance_tools import get_task_run_dependencies_tools, list_task_run_tools, \
    list_attempts_tools, get_attempt_log_tool, get_task_run_stats_tools
from .backfill_task_tools import get_backfill_task_detail_tools, list_backfill_tasks_tools, \
    list_backfill_instances_tools, create_backfill_job_tools
from .datasource_tools import list_data_sources
from .execute_tools import execute_tool
from .integration_config_tools import integration_config_tools
from .datetime_tools import get_datetime_tools
from .system_prompt_tools import SYSTEM_TOOLS
from .vc_tools import list_vcluster_tool, create_vcluster_tool
from .workspace_tools import list_user_workspaces_tool
from .knowledge_index_tools import create_knowledge_tools
from .cdc_realtime_tools import cdc_realtime_tools
from cz_mcp.tools.agent.LH_execute_tools import agent_execute_query_tool
from .optimize_tools import get_optimize_tools
from .flow_task_tools import get_flow_task_tools
from .task_lifecycle_tools import get_task_lifecycle_tools

def get_all_tools():
    """Get all available tools"""
    tools = []

    tools.extend(agent_execute_query_tool())
    tools.extend(get_admin_tools())

    tools.extend(create_dqc_rule())
    tools.extend(create_task_tool())
    tools.extend(create_folder_tool())
    tools.extend(list_folders_tool())
    tools.extend(list_tasks_tool())

    tools.extend(save_non_integration_task_content())
    tools.extend(save_integration_task_tool())
    tools.extend(get_task_configuration_detail_tool())
    tools.extend(save_task_configuration_tool())
    tools.extend(save_task_configuration_v2_tools())
    tools.extend(preview_schedule_instance_times_tool())

    tools.extend(publish_task_tool())
    
    # Task development generalized tools
    # tools.extend(task_development_tools())

    tools.extend(get_task_detail_tool())
    tools.extend(get_backfill_task_detail_tools())
    tools.extend(get_published_task_dependencies_tools())
    tools.extend(get_task_statistics_tools())
    tools.extend(get_task_run_dependencies_tools())
    tools.extend(get_datetime_tools())

    tools.extend(list_task_run_tools())
    tools.extend(list_attempts_tools())
    tools.extend(get_task_run_stats_tools())
    tools.extend(list_data_sources())
    tools.extend(list_vcluster_tool())
    tools.extend(create_vcluster_tool())
    tools.extend(list_backfill_tasks_tools())
    tools.extend(list_backfill_instances_tools())
    tools.extend(create_backfill_job_tools())

    tools.extend(execute_tool())
    tools.extend(get_attempt_log_tool())

    # tools.extend(integration_config_tools())
    tools.extend(create_knowledge_tools())
    tools.extend(list_user_workspaces_tool())
    tools.extend(cdc_realtime_tools())

    # Optimization tools
    tools.extend(get_optimize_tools())

    # Flow task tools
    tools.extend(get_flow_task_tools())

    # Task lifecycle tools
    tools.extend(get_task_lifecycle_tools())

    return tools



def get_all_agent_tools():
    """Get all available tools"""
    tools = get_all_tools()
    tools.extend(save_task_configuration_v2_tools())
    tools.extend(agent_execute_query_tool())
    tools.extend(task_development_tools())

    return tools
