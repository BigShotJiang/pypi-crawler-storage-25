from mcp.types import TextContent, EmbeddedResource

from cz_mcp.common import ResponseBuilder
from cz_mcp.core.tool_registry import Tool, SYSTEM_PROMPT


def handle_get_system_prompt(arguments=None,
                             studio_config=None,
                             **kwargs
                             ) -> list[TextContent | EmbeddedResource]:
    return ResponseBuilder.create_yaml_json_response([SYSTEM_PROMPT], None, studio_config=studio_config)


SYSTEM_TOOLS = [
    Tool(
        name="get_system_prompt",
        title="Allways get system prompt",
        description=(
            "Retrieve the system prompt for a specified agent by its name. "
            "This tool is essential for understanding the agent's behavior and context."
        ),
        input_schema={
            "type": "object",
            "properties": {
            },
            "required": [],
        },
        handler=handle_get_system_prompt,
        tags=["studio"],
        samples=[]
    ),
]
