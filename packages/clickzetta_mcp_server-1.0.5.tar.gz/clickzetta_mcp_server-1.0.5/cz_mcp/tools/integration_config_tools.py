"""
Integration Configuration Generation Tools
"""

import json
import logging
from typing import List, Dict, Any, Optional

from mcp.types import TextContent, EmbeddedResource

from .integration_templates import IntegrationTemplateLibrary
from ..common.utilities import ResponseBuilder
from ..core.tool_registry import Tool
from ..handlers.datasource_server import get_meta_detail as api_get_meta_detail
from ..studio_config_manager import StudioConfig

from loguru import logger


class IntegrationConfigGenerator:
    """Integration configuration generator"""

    def __init__(self, config: StudioConfig):
        self.config = config
        self.template_lib = IntegrationTemplateLibrary()
    
    async def generate_config(
        self,
        source_datasource_id: int,
        sink_datasource_id: int,
        source_table: str,
        sink_table: str,
        source_datasource_type: int,
        sink_datasource_type: int,
        source_datasource_name: str,
        sink_datasource_name: str,
        source_namespace: Optional[str] = None,
        sink_namespace: Optional[str] = None,
        write_mode: str = "APPEND",
        parallelism: int = 2,
        custom_params: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Generate integration task configuration
        
        Args:
            source_datasource_id: Source datasource ID
            sink_datasource_id: Sink datasource ID
            source_table: Source table name
            sink_table: Sink table name
            source_datasource_type: Source datasource type code
            sink_datasource_type: Sink datasource type code
            source_datasource_name: Source datasource name
            sink_datasource_name: Sink datasource name
            source_namespace: Source namespace/database (optional)
            sink_namespace: Sink namespace/database (optional)
            write_mode: Write mode (APPEND or OVERWRITE)
            parallelism: Task parallelism
            custom_params: Custom parameters to override defaults
        
        Returns:
            Complete integration configuration dict
        """
        # Use provided datasource type information directly
        source_type = source_datasource_type
        sink_type = sink_datasource_type
        
        # 1. Get template
        template_key = self.template_lib.get_template_key(source_type, sink_type)
        template = self.template_lib.get_template(template_key)
        
        logger.info(f"Using template: {template_key} for {source_type} → {sink_type}")
        
        # 2. Get table metadata
        source_columns = await self._get_table_columns(
            source_datasource_id, 
            source_namespace or source_table,
            source_table,
            source_type
        )
        
        # 3. Build configuration
        config = {
            "templateKey": 1,
            "userParams": {},
            "sourceConnection": {
                "datasourceId": source_datasource_id,
                "datasourceName": source_datasource_name,
                "type": source_type
            },
            "sinkConnection": {
                "datasourceId": sink_datasource_id,
                "datasourceName": sink_datasource_name,
                "type": sink_type
            },
            "jobs": [
                self._build_job(
                    source_table=source_table,
                    sink_table=sink_table,
                    source_namespace=source_namespace,
                    sink_namespace=sink_namespace,
                    source_columns=source_columns,
                    source_type=source_type,
                    sink_type=sink_type,
                    template=template,
                    write_mode=write_mode,
                    parallelism=parallelism,
                    custom_params=custom_params
                )
            ]
        }
        
        return config
    
    async def _get_table_columns(
        self,
        datasource_id: int,
        namespace: str,
        table_name: str,
        ds_type: int
    ) -> List[Dict[str, Any]]:
        """Get table column metadata"""
        try:
            # For Kafka, use system columns
            if ds_type == 2:
                template = self.template_lib.get_template("kafka_to_lakehouse")
                return template.get("system_columns", [])
            
            # For OSS, try to get metadata, if fails use system columns as fallback
            if ds_type == 9:
                try:
                    response = api_get_meta_detail(
                        datasource_id=datasource_id,
                        namespace=namespace,
                        data_object_name=table_name,
                        jwt_token=self.config.token,
                        instance_name=self.config.instance,
                        instance_id= self.config.instance_id,
                        user_id = self.config.user_id,
                        account_id = self.config.tenant_id,
                        env=self.config.env,
                        workspace_name=self.config.workspace
                    )
                    
                    response_data = json.loads(response)
                    if response_data.get("code") == "200":
                        metadata = response_data.get("data", {})
                        columns = metadata.get("columns", [])
                        if columns:
                            return columns
                except Exception as e:
                    logger.warning(f"Failed to get OSS metadata, using system columns: {e}")
                
                # Fallback to system columns for OSS
                template = self.template_lib.get_template("oss_to_lakehouse")
                return template.get("system_columns", [])
            
            # For other types, get from metadata API
            response = api_get_meta_detail(
                datasource_id=datasource_id,
                namespace=namespace,
                data_object_name=table_name,
                jwt_token=self.config.token,
                instance_name=self.config.instance,
                instance_id=self.config.instance_id,
                user_id=self.config.user_id,
                account_id=self.config.tenant_id,
                env=self.config.env,
                workspace_name=self.config.workspace
            )
            
            response_data = json.loads(response)
            if response_data.get("code") == "200":
                metadata = response_data.get("data", {})
                columns = metadata.get("columns", [])
                
                if not columns:
                    logger.warning(f"No columns found for {table_name}, returning empty list")
                
                return columns
            else:
                logger.error(f"API error getting columns: {response_data.get('message')}")
                return []
        
        except Exception as e:
            logger.error(f"Error getting table columns: {e}")
            return []
    
    def _build_job(
        self,
        source_table: str,
        sink_table: str,
        source_namespace: Optional[str],
        sink_namespace: Optional[str],
        source_columns: List[Dict[str, Any]],
        source_type: int,
        sink_type: int,
        template: Dict[str, Any],
        write_mode: str,
        parallelism: int,
        custom_params: Optional[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Build job configuration"""
        
        # Build source params
        source_params = self._build_params(
            "source",
            source_type,
            source_table,
            source_namespace,
            template,
            custom_params
        )
        
        # Build sink params
        sink_params = self._build_params(
            "sink",
            sink_type,
            sink_table,
            sink_namespace,
            template,
            custom_params,
            write_mode=write_mode
        )
        
        # Map columns
        sink_columns = self._map_columns(source_columns, source_type, sink_type)
        
        # Build column mapping
        column_mapping = {col["name"]: col["name"] for col in source_columns}
        
        # Build job
        job = {
            "source": {
                "dataObject": source_table,
                "namespace": source_namespace or source_table,
                "params": source_params,
                "columns": source_columns
            },
            "sink": {
                "dataObject": sink_table,
                "namespace": sink_namespace or "public",
                "params": sink_params,
                "columns": sink_columns
            },
            "setting": {
                "parallelism": parallelism,
                "errorLimit": {
                    "maxCount": -1,
                    "collectDirtyData": True,
                    "record": -1
                }
            },
            "columnMapping": column_mapping
        }
        
        return job
    
    def _build_params(
        self,
        operator_type: str,
        ds_type: int,
        table: str,
        namespace: Optional[str],
        template: Dict[str, Any],
        custom_params: Optional[Dict[str, Any]],
        write_mode: str = "APPEND"
    ) -> Dict[str, Any]:
        """Build params dict"""
        
        defaults_key = operator_type
        
        # Start with defaults from template
        params = template.get("default_values", {}).get(defaults_key, {}).copy()
        
        # Add required params
        params["dsType"] = ds_type
        params["operatorType"] = operator_type
        
        # Add table/database if needed (not for Hive source or Redis sink)
        if not (ds_type == 3 and operator_type == "source"):  # Not Hive source
            if ds_type != 43 or operator_type != "sink":  # Not Redis sink
                params["table"] = table
                params["database"] = namespace or table
        
        # Add write mode for sinks
        if operator_type == "sink" and ds_type == 1:  # Lakehouse sink
            params["writeMode"] = write_mode
            params["outputMode"] = write_mode  # Must match writeMode
        
        # Apply custom params
        if custom_params:
            params.update(custom_params.get(operator_type, {}))
        
        return params
    
    def _map_columns(
        self,
        source_columns: List[Dict[str, Any]],
        source_type: int,
        sink_type: int
    ) -> List[Dict[str, Any]]:
        """Map source columns to sink columns"""
        
        sink_columns = []
        for col in source_columns:
            source_col_type = col.get("type", "STRING")
            sink_col_type = self.template_lib.map_column_type(
                source_col_type,
                source_type,
                sink_type
            )
            
            sink_col = col.copy()
            sink_col["type"] = sink_col_type
            
            # Add helper flag for Lakehouse sink
            if sink_type == 1:
                sink_col["helper"] = True
            
            sink_columns.append(sink_col)
        
        return sink_columns


async def handle_recommend_integration_config(arguments=None, studio_config: StudioConfig = None, **kwargs
) -> list[TextContent | EmbeddedResource]:
    """
    Recommend and generate integration task configuration
    """
    if arguments is None:
        arguments = {}
    
    try:
        # Extract parameters
        source_datasource_id = arguments.get("source_datasource_id")
        sink_datasource_id = arguments.get("sink_datasource_id")
        source_table = arguments.get("source_table")
        sink_table = arguments.get("sink_table")
        source_datasource_type = arguments.get("source_datasource_type")
        sink_datasource_type = arguments.get("sink_datasource_type")
        source_datasource_name = arguments.get("source_datasource_name")
        sink_datasource_name = arguments.get("sink_datasource_name")
        source_namespace = arguments.get("source_namespace")
        sink_namespace = arguments.get("sink_namespace")
        write_mode = arguments.get("write_mode", "APPEND")
        parallelism = arguments.get("parallelism", 2)
        custom_params = arguments.get("custom_params")
        
        # Validate required parameters
        required_params = [
            source_datasource_id, sink_datasource_id, 
            source_table, sink_table,
            source_datasource_type, sink_datasource_type,
            source_datasource_name, sink_datasource_name
        ]
        if not all(required_params):
            return ResponseBuilder.create_yaml_json_response([{
                "success": False,
                "message": "Missing required parameters: source_datasource_id, sink_datasource_id, source_table, sink_table, source_datasource_type, sink_datasource_type, source_datasource_name, sink_datasource_name"
            }], studio_config=studio_config)
        
        # Generate configuration
        generator = IntegrationConfigGenerator(studio_config)
        config = await generator.generate_config(
            source_datasource_id=source_datasource_id,
            sink_datasource_id=sink_datasource_id,
            source_table=source_table,
            sink_table=sink_table,
            source_datasource_type=source_datasource_type,
            sink_datasource_type=sink_datasource_type,
            source_datasource_name=source_datasource_name,
            sink_datasource_name=sink_datasource_name,
            source_namespace=source_namespace,
            sink_namespace=sink_namespace,
            write_mode=write_mode,
            parallelism=parallelism,
            custom_params=custom_params
        )
        
        # Format response
        formatted_response = {
            "success": True,
            "message": "Successfully generated integration configuration",
            "configuration": config,
            "data_file_content": json.dumps(config, ensure_ascii=False),
            "next_steps": [
                "1. Review the generated configuration",
                "2. Use save_integration_task to save this configuration to a file",
                "3. Use save_configuration to set up scheduling",
                "4. Use submit_file to deploy the task"
            ]
        }
        
        return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
    
    except Exception as e:
        logger.error(f"Error in recommend_integration_config: {e}")
        import traceback
        return ResponseBuilder.create_yaml_json_response([{
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__,
            "traceback": traceback.format_exc()
        }], studio_config=studio_config)


def integration_config_tools() -> List[Tool]:
    """Get integration configuration tools"""
    return [
        Tool(
            name="recommend_integration_config",
            description=(
                "Generate complete data integration configuration for 50+ datasource types (MySQL, Kafka, OSS, MongoDB, etc.). "
                "Handles column mappings, type conversions, and datasource-specific parameters automatically.\n"
                "\n"
                "**Prerequisites**: Source table exists (auto-fetched). Sink table MUST exist with compatible schema.\n"
                "\n"
                "**Workflow**: 1) Verify source via get_meta_detail 2) Create sink table with correct types 3) Call this tool 4) Save & submit\n"
                "\n"
                "**Finding Sink Datasource** (IMPORTANT for LakeHouse):\n"
                "• For LakeHouse sink: Use list_data_sources to find the datasource matching current project\n"
                "• Look for dsName pattern: 'LAKEHOUSE_<projectId>_<projectName>'\n"
                "• Example: Project 97001 with workspace 'zetta_studio_dw' → datasource name 'LAKEHOUSE_97001_zetta_studio_dw'\n"
                "• The projectId is available in X-Lakehouse-ProjectId header from MCP config\n"
                "• Each project has its own isolated LakeHouse datasource for data security\n"
                "• MUST match current project to ensure proper permissions and data isolation\n"
                "\n"
                "**Auto Type Mapping** (Source→Lakehouse):\n"
                "• Strings: VARCHAR/CHAR/TEXT→string\n"
                "• Integers: TINYINT→tinyint, SMALLINT→smallint, INT→int, BIGINT→bigint\n"
                "• Decimals: FLOAT→float, DOUBLE→double, DECIMAL→decimal\n"
                "• Time: DATE→date, TIMESTAMP/DATETIME→timestamp\n"
                "• MySQL UNSIGNED升级: INT UNSIGNED→bigint, BIGINT UNSIGNED→decimal (Lakehouse不支持UNSIGNED)\n"
                "• PostgreSQL特殊: UUID/JSONB/INET→string\n"
                "• MongoDB: OBJECTID/DOCUMENT→string\n"
                "• ClickHouse: Int128/UInt256→decimal\n"
                "• Kafka: 固定5列(__key__,__value__,__partition__,__offset__,__timestamp__)\n"
                "• OSS/S3: 所有类型→string\n"
                "\n"
                "Column names unchanged. Complex types→STRING. Large integers→DECIMAL."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "source_datasource_id": {
                        "type": "integer",
                        "description": "ID of the source datasource (use list_data_sources to find)"
                    },
                    "sink_datasource_id": {
                        "type": "integer",
                        "description": (
                            "ID of the sink datasource. Use list_data_sources to find. "
                            "**For LakeHouse sink (dsType=1)**: Each project has its own LakeHouse datasource. "
                            "Look for datasource with dsName pattern 'LAKEHOUSE_<projectId>_<projectName>' "
                            "that matches the current project (from X-Lakehouse-ProjectId header). "
                            "Example: For project 97001, find datasource named 'LAKEHOUSE_97001_zetta_studio_dw'. "
                            "Using wrong project's LakeHouse will cause permission errors."
                        )
                    },
                    "source_datasource_type": {
                        "type": "integer",
                        "description": "Type code of the source datasource (dsType from list_data_sources)"
                    },
                    "sink_datasource_type": {
                        "type": "integer",
                        "description": "Type code of the sink datasource (dsType from list_data_sources)"
                    },
                    "source_datasource_name": {
                        "type": "string",
                        "description": "Name of the source datasource (dsName from list_data_sources)"
                    },
                    "sink_datasource_name": {
                        "type": "string",
                        "description": (
                            "Name of the sink datasource (dsName from list_data_sources). "
                            "**For LakeHouse sink**: Use pattern 'LAKEHOUSE_<projectId>_<projectName>'. "
                            "Must match the current project to ensure proper data isolation and permissions. "
                            "Example: 'LAKEHOUSE_97001_zetta_studio_dw' for project 97001 with workspace 'zetta_studio_dw'."
                        )
                    },
                    "source_table": {
                        "type": "string",
                        "description": "Source table/object name (for Kafka: topic name; for OSS: file path)"
                    },
                    "sink_table": {
                        "type": "string",
                        "description": "Sink table name in the target datasource"
                    },
                    "source_namespace": {
                        "type": "string",
                        "description": "Source namespace/database/schema (optional, defaults to source_table)"
                    },
                    "sink_namespace": {
                        "type": "string",
                        "description": "Sink namespace/database/schema (optional, defaults to 'public')"
                    },
                    "write_mode": {
                        "type": "string",
                        "description": "Write mode for sink",
                        "enum": ["APPEND", "OVERWRITE"],
                        "default": "APPEND"
                    },
                    "parallelism": {
                        "type": "integer",
                        "description": "Task parallelism (default: 2)",
                        "default": 2,
                        "minimum": 1,
                        "maximum": 32
                    },
                    "custom_params": {
                        "type": "object",
                        "description": (
                            "Custom parameters to override defaults. Structure: "
                            "{\"source\": {\"param_name\": \"value\"}, \"sink\": {\"param_name\": \"value\"}}. "
                            "For example, for Kafka: {\"source\": {\"codec\": \"avro\", \"groupId\": \"my_group\"}}. "
                            "For Redis: {\"sink\": {\"redisOpType\": \"string\", \"keyColumns\": [\"id\", \"name\"]}}"
                        )
                    }
                },
                "required": [
                    "source_datasource_id", "sink_datasource_id", 
                    "source_table", "sink_table",
                    "source_datasource_type", "sink_datasource_type",
                    "source_datasource_name", "sink_datasource_name"
                ]
            },
            handler=handle_recommend_integration_config,
            tags=["studio", "integration", "config", "generate", "normalize"],
            samples=[
                {
                    "description": "Generate MySQL to Lakehouse integration config",
                    "query": {
                        "source_datasource_id": 797,
                        "sink_datasource_id": 794,
                        "source_datasource_type": 5,
                        "sink_datasource_type": 1,
                        "source_datasource_name": "StudioUatmysql",
                        "sink_datasource_name": "LAKEHOUSE_97001_zetta_studio_dw",
                        "source_table": "users",
                        "sink_table": "users_copy",
                        "source_namespace": "mydb",
                        "sink_namespace": "public",
                        "write_mode": "APPEND"
                    }
                },
                {
                    "description": "Generate Kafka to Lakehouse integration config with custom parameters",
                    "query": {
                        "source_datasource_id": 15963,
                        "sink_datasource_id": 1153,
                        "source_datasource_type": 2,
                        "sink_datasource_type": 1,
                        "source_datasource_name": "kafka_source",
                        "sink_datasource_name": "lakehouse_sink",
                        "source_table": "user_events",
                        "sink_table": "kafka_events",
                        "write_mode": "OVERWRITE",
                        "custom_params": {
                            "source": {
                                "codec": "avro",
                                "groupId": "analytics_group"
                            }
                        }
                    }
                }
            ]
        )
    ]
