# coding=utf-8
"""
Studio-specific tools for MCP Studio server
Handles Studio API interactions for scheduled task management
"""
import json
import logging
from datetime import timedelta, datetime
from typing import List, Optional, Any, Coroutine

from mcp.types import TextContent, EmbeddedResource

from cz_mcp.common.utilities import ResponseBuilder
from cz_mcp.core.tool_registry import Tool
from cz_mcp.handlers.ide_admin_server import get_attempt_log_content as api_get_attempt_log_content
from cz_mcp.handlers.ide_admin_server import instance_list as api_schedule_instance_list
from cz_mcp.handlers.ide_admin_server import instance_relation as api_schedule_instance_relation
from cz_mcp.handlers.ide_admin_server import list_attempt_records as api_list_attempt_records
from cz_mcp.handlers.ide_admin_server import get_instance_statistics as api_get_instance_statistics
from ..common.task_type import OFFLINE_TASK_TYPE_MAP, REALTIME_TASK_TYPE_MAP
from ..studio_config_manager import StudioConfig

from loguru import logger

task_type_desc = "Available offline task types:\n"
task_type_desc += "\n".join([f"  - {int(ft)}: {name}" for ft, name in sorted(OFFLINE_TASK_TYPE_MAP.items())])
task_type_desc += "Available realtime task types:\n"
task_type_desc += "\n".join([f"  - {int(ft)}: {name}" for ft, name in sorted(REALTIME_TASK_TYPE_MAP.items())])

def convert_task_run_fields(api_data: dict) -> dict:
    """
    Convert API response fields to tool naming convention.

    Field mappings:
    - taskInstanceId -> task_run_id
    - instanceType -> task_run_type
    - instanceStatus -> task_run_status
    - scheduleTaskId -> task_id
    - cycleTaskName -> task_name
    - cycleTaskType -> task_type
    - taskOwnerCn -> task_owner_cn
    - taskOwnerEn -> task_owner_en
    - executorUserName -> executor_user_name
    - executorUserId -> executor_user_id
    - taskGroupId -> task_group_id
    - taskGroupName -> task_group_name
    - planTriggerTime -> plan_trigger_time
    - planTriggerTimeStr -> plan_trigger_time_str
    - executeStartTime -> execute_start_time
    - executeStartTimeStr -> execute_start_time_str
    - executeEndTime -> execute_end_time
    - executeEndTimeStr -> execute_end_time_str
    - finishedTime -> finished_time
    - finishedTimeStr -> finished_time_str
    - retryCount -> retry_count
    - retryIntervalTime -> retry_interval_time
    - failType -> fail_type
    - failMsg -> fail_msg
    - createdBy -> created_by
    - createdTime -> created_time
    - updatedBy -> updated_by
    - updatedTime -> updated_time

    Args:
        api_data: Dictionary from API response

    Returns:
        Dictionary with converted field names
    """
    if api_data is None:
        return {}
    
    field_mapping = {
        # Core task run fields
        "taskInstanceId": "task_run_id",
        "instanceType": "task_run_type",
        "instanceStatus": "task_run_status",
        "scheduleTaskId": "task_id",
        "cycleTaskName": "task_name",
        "cycleTaskType": "task_type",

        # User and project fields
        "tenantId": "tenant_id",
        "userId": "user_id",
        "projectId": "project_id",
        "projectName": "project_name",
        "taskOwnerCn": "task_owner_cn",
        "taskOwnerEn": "task_owner_en",
        "executorUserName": "executor_user_name",
        "executorUserId": "executor_user_id",

        # Task group fields
        "taskGroupId": "task_group_id",
        "taskGroupName": "task_group_name",

        # Time fields
        "planTriggerTime": "plan_trigger_time",
        "triggerTime": "trigger_time",
        "executeStartTime": "execute_start_time",
        "executeEndTime": "execute_end_time",
        "startWaitTime": "start_wait_time",
        "endWaitTime": "end_wait_time",
        "waitSpanTime": "wait_span_time",

        # Status and result fields

        "failType": "fail_type",
        "failMsg": "fail_msg",

        "rerunStatus": "rerun_status",
        # Attempt reference (present when the run has at least one attempt)
        "executeLogId": "attempt_id",
        # Configuration fields
        "showTaskParam": "task_param",
        "taskPriority": "task_priority",
        "vcCode": "vc_code",
        "env": "env",
        "version": "version",
    }

    converted = {}
    for key, value in api_data.items():
        # Only include fields that are in the mapping, skip others
        if key in field_mapping:
            new_key = field_mapping[key]
            converted[new_key] = value

    return converted


def convert_task_run_dependency_fields(api_data: dict) -> dict:
    """
    Convert API response fields for task run dependencies to tool naming convention.

    Field mappings:
    - scheduleInstanceId -> task_run_id
    - taskInstanceStatus -> task_run_status
    - scheduleTaskId -> task_id
    - scheduleTaskName -> task_name
    - cycleTaskType -> task_type
    - planTriggerTime -> plan_trigger_time
    - executeStartTime -> execute_start_time
    - executeEndTime -> execute_end_time
    - executeStartTimeStr -> execute_start_time_str
    - executeEndTimeStr -> execute_end_time_str
    - taskOwnerDisplayName -> task_owner_display_name
    - taskOwnerUserId -> task_owner_user_id
    - cronExpression -> cron_expression
    - rerunEnabled -> rerun_enabled
    - rerunStatus -> rerun_status
    - vcCode -> vc_code
    - parentScheduleTaskInstanceBeans -> parent_task_runs (recursively converted)
    - childScheduleTaskInstanceBeans -> child_task_runs (recursively converted)

    Args:
        api_data: Dictionary from API response

    Returns:
        Dictionary with converted field names
    """
    if api_data is None:
        return {}
    
    field_mapping = {
        # Core fields
        "scheduleInstanceId": "task_run_id",
        "taskInstanceStatus": "task_run_status",
        "scheduleTaskId": "task_id",
        "scheduleTaskName": "task_name",
        "cycleTaskType": "task_type",

        # Project fields
        "projectId": "project_id",
        "projectName": "project_name",
        "tenantId": "tenant_id",

        # Time fields
        "planTriggerTime": "plan_trigger_time",
        "executeStartTime": "execute_start_time",
        "executeEndTime": "execute_end_time",

        # User fields
        "taskOwnerDisplayName": "task_owner_display_name",
        "taskOwnerUserId": "task_owner_user_id",

        # Configuration fields
        "cronExpression": "cron_expression",
        "rerunStatus": "rerun_status",
        "vcCode": "vc_code",
        "nextLevelCount": "next_level_count",
    }

    converted = {}
    for key, value in api_data.items():
        # Only include fields that are in the mapping, skip others
        if key in field_mapping:
            new_key = field_mapping[key]
            converted[new_key] = value
        elif key == "parentScheduleTaskInstanceBeans":
            # Recursively convert parent task runs
            if isinstance(value, list):
                converted["parent_task_runs"] = [
                    convert_task_run_dependency_fields(item) for item in value
                ]
            else:
                converted["parent_task_runs"] = value
        elif key == "childScheduleTaskInstanceBeans":
            # Recursively convert child task runs
            if isinstance(value, list):
                converted["child_task_runs"] = [
                    convert_task_run_dependency_fields(item) for item in value
                ]
            else:
                converted["child_task_runs"] = value
        elif key in ["parent", "children"]:
            # Recursively convert nested parent/children arrays
            if isinstance(value, list):
                converted[key] = [
                    convert_task_run_dependency_fields(item) for item in value
                ]
            else:
                converted[key] = value

    return converted


def convert_attempt_fields(api_data: dict) -> dict:
    """
    Convert API response fields for task-run attempts to tool naming convention.

    Field mappings:
    - scheduleTaskId -> task_id
    - scheduleInstanceId -> task_run_id
    - executeLogId -> attempt_id
    - createdBy -> created_by
    - createdTime -> created_time
    - startTime -> start_time
    - endTime -> end_time
    - finishResult -> finish_result

    Args:
        api_data: Dictionary from API response

    Returns:
        Dictionary with converted field names
    """
    if api_data is None:
        return {}
    
    field_mapping = {
        # Core fields
        "scheduleTaskId": "task_id",
        "scheduleInstanceId": "task_run_id",
        "executeLogId": "attempt_id",

        # Time fields
        "createdTime": "created_time",
        "startTime": "start_time",
        "endTime": "end_time",

        # Status fields
        "finishResult": "finish_result",

        # Metadata fields
        "createdBy": "created_by",
    }

    converted = {}
    for key, value in api_data.items():
        # Only include fields that are in the mapping, skip others
        if key in field_mapping:
            new_key = field_mapping[key]
            converted[new_key] = value

    return converted


def convert_run_stats_fields(api_data: dict) -> dict:
    """
    Args:
        api_data: Dictionary from API response

    Returns:
        Dictionary with converted field names
    """
    if api_data is None:
        return {}
    
    field_mapping = {
        # Core fields
        "instanceStatus": "task_run_status",
        "taskType": "task_type",
        "instanceType": "task_run_type",
        # Time fields
        "count": "count",

    }

    converted = {}
    for key, value in api_data.items():
        # Only include fields that are in the mapping, skip others
        if key in field_mapping:
            new_key = field_mapping[key]
            converted[new_key] = value

    return converted


async def handle_list_task_run(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    list schedule task run in Clickzetta Studio
    """
    if arguments is None:
        arguments = {}

    try:
        today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        yesterday = today - timedelta(days=1)
        yesterday_zero = yesterday.replace(hour=0, minute=0, second=0)
        tomorrow = today + timedelta(days=1)
        tomorrow_end = tomorrow.replace(hour=23, minute=59, second=59)

        # Extract parameters
        task_name_or_id = arguments.get("task_name_or_id", "")
        task_type = arguments.get("task_type")
        task_run_type = arguments.get("task_run_type", 1)
        schedule_task_id = arguments.get("task_id")
        page_index = arguments.get("page_index", 1)
        page_size = arguments.get("page_size", 10)
        if page_size > 20:
            return ResponseBuilder.create_yaml_json_response([{
                "success": False,
                "message": "page_size exceeds the maximum limit of 20."
            }], studio_config=studio_config)
        order_by = arguments.get("order_by", "desc").upper()
        order_by_field = arguments.get("order_by_field", "execute_start_time")
        query_start_time = arguments.get("query_plan_time_left", yesterday_zero.timestamp()*1000 )
        query_end_time = arguments.get("query_plan_time_right", tomorrow_end.timestamp()*1000)
        task_run_status_list = arguments.get("task_run_status_list")

        # If task_run_status_list contains 2 (Not started), also include 5 (Waiting for resources),
        # 6 (Waiting for upstream), and 8 (Upstream failed blocking)
        if task_run_status_list is not None and isinstance(task_run_status_list, list):
            if 2 in task_run_status_list:
                # Add 5, 6, 8 if not already present
                additional_statuses = [5, 6, 8]
                for status in additional_statuses:
                    if status not in task_run_status_list:
                        task_run_status_list.append(status)
                logger.info(f"Added statuses 5, 6, 8 to task_run_status_list because it contains 2. Final list: {task_run_status_list}")

        group_id = arguments.get("group_id")
        # Get auth context from server core
        config = studio_config

        # Use config project ID if not provided
        project_id = config.project_id

        logger.info(f"Listing schedule task runs for project_id: {project_id}")

        # Call the API
        response = api_schedule_instance_list(
            projectId=project_id,
            taskNameOrTaskId=task_name_or_id,
            taskType=task_type,
            instanceType=task_run_type,
            scheduleTaskId=schedule_task_id,
            pageIndex=page_index,
            pageSize=page_size,
            orderBy=order_by,
            orderByFields = order_by_field,
            queryStartPlanTime = query_start_time,
            queryEndPlanTime = query_end_time,
            instanceStatusList= task_run_status_list,
            groupId = group_id,
            jwt_token=config.token,
            instance_name=config.instance,
            instance_id = config.instance_id,
            user_id=config.user_id,
            account_id=config.tenant_id,
            env=config.env,
            workspace_name=config.workspace
        )

        # Parse and format the response
        response_data = json.loads(response)

        if response_data.get("code") == "200":

            res_page_index = response_data.get("pageIndex", page_index)
            tasks = response_data.get("data", [])  or []
            count = response_data.get("count")

            # Convert field names to tool naming convention
            converted_tasks = [convert_task_run_fields(task) for task in tasks]

            # Format the response for better readability
            formatted_response = {
                "success": True,
                "message": "Successfully list task runs",
                "task_run_list": converted_tasks,
                "total_count": count,
                "page_index":res_page_index,
                "page_size": page_size
            }

            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[handle_list_schedule_task_run]API request failed: {response_data.get('msg', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in list task runs: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


def list_task_run_tools() -> List[Tool]:
    """Get all Studio-specific tools"""
    return [
        Tool(
            name="list_task_run",
            description=(
                "List task runs that match filtering conditions with **pagination**. "
                "Supports filtering by project space, task type, schedule task ID, "
                "fuzzy task name or task run ID, task run type, planned time range, "
                "status combinations, task group, and sorting."
                
                "**Usage Guidelines:**"
                "1. Use this tool ONLY when the user explicitly requests a list of task runs (e.g., 'show me the execution list', 'list all task runs', 'get the task run details')."
                "2. By default, return ONLY the first page (page_index=1) and inform the user that the results are incomplete: 'The current results show only the first page. There are [total_count] task runs in total. If you need the complete list, I can fetch all pages.'"
                "3. Only iterate through all pages if the user explicitly requests the full/complete list (e.g., 'get all of them', 'I need the complete list', 'show me everything')."
                "4. **DO NOT use this tool** when the user asks about execution status, execution situation, or execution statistics in general terms. In such cases, use `get_task_run_stats` instead to get aggregated statistics."
                
                "**Time Parameters:**"
                "⚠️ The `query_plan_time_left` and `query_plan_time_right` parameters require timestamp values in milliseconds. "
                "If you are uncertain about the time values, first call `get_current_datetime` to get the current timestamp_ms, "
                "then calculate the desired time range based on it."
                
                "A *task run* represents a single execution record generated after a task runs. "
                "Each task run contains metadata such as execution time, run status, input parameters, "
                "output logs, and other runtime details."
                
                "This tool returns only one page of results per call. When iterating through pages, "
                "increment page_index each time until all pages are retrieved or no more data is returned."
                ""
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "project_id": {
                        "type": "integer",
                        "description": (
                            "Project space ID. Optional. If not provided, defaults to "
                            "all project spaces the user has access to."
                        )
                    },
                    "task_type": {
                        "type": "integer",
                        "description": f"Task type filter. Optional,{task_type_desc}; returns all if omitted."
                    },
                    "task_id": {
                        "type": "integer",
                        "description": "Specific task ID to filter task runs by."
                    },
                    "task_name_or_id": {
                        "type": "string",
                        "description": (
                            "Fuzzy search for task run name, or direct task run ID value."
                        )
                    },
                    "page_index": {
                        "type": "integer",
                        "description": "Page index (1-based, default 1).",
                        "default": 1
                    },
                    "page_size": {
                        "type": "integer",
                        "description": "Number of items per page (default 10). Maximum is 20.",
                        "default": 10
                    },
                    "order_by": {
                        "type": "string",
                        "enum": ["asc", "desc"],
                        "description": "Sort order (default 'desc').",
                        "default": "desc"
                    },
                    "order_by_field": {
                        "type": "string",
                        "description": "Sorting field (default 'execute_start_time').",
                        "default": "execute_start_time",
                        "enum": ["execute_start_time", "execute_end_time", "plan_trigger_time"]

                    },
                    "group_id": {
                        "type": "integer",
                        "description": "Task group ID filter."
                    },
                    "task_run_type": {
                        "type": "integer",
                        "description": (
                            "Task run type. Valid values: "
                            "1 = Schedule run, "
                            "3 = Temporary  run, "
                            "4 = backfill run."
                        ),
                        "enum": [1, 3, 4],
                        "default": 1
                    },
                    "query_plan_time_left": {
                        "type": "integer",
                        "description": (
                            "Left bound of planned time (timestamp in milliseconds). "
                            "The default value is the timestamp of yesterday at 00:00:00 based on the current time. "
                            "Example: 1762444800000. "
                            "⚠️ **IMPORTANT**: If you are uncertain about the time value, first call `get_current_datetime` to get the current timestamp_ms, "
                            "then calculate the desired time range based on it (e.g., subtract 24 hours for yesterday, or set to 00:00:00 of a specific date)."
                        )
                    },
                    "query_plan_time_right": {
                        "type": "integer",
                        "description": (
                            "Right bound of planned time (timestamp in milliseconds). "
                            "The default value is the timestamp of tomorrow at 23:59:59 based on the current time. "
                            "Example: 1762531199000. "
                            "⚠️ **IMPORTANT**: If you are uncertain about the time value, first call `get_current_datetime` to get the current timestamp_ms, "
                            "then calculate the desired time range based on it (e.g., add 24 hours for tomorrow, or set to 23:59:59 of a specific date)."
                        )
                    },
                    "task_run_status_list": {
                        "type": "array",
                        "items": {"type": "integer"},
                        "description": (
                            "List of task run status values. Supported values: "
                            "1=Success, 2=Not started, 3=Failed, 4=Running, "
                            "5=Waiting for resources, 6=Waiting for upstream, "
                            "7=Paused, 8=Upstream failed blocking."
                        )
                    }
                },
                "additionalProperties": False,
                "required": []
            },
            handler=handle_list_task_run,
            tags=["task_run", "normalize"],
            samples=[
                {
                    "description": "List task runs of task 9001 within a time window, filtered by status and sorted by updated_time.",
                    "query": {
                        "task_id": 9001,
                        "page_index": 1,
                        "page_size": 10,
                        "orderBy": "desc",
                        "order_by_field": "plan_trigger_time",
                        "query_plan_time_left": 1762444800000,
                        "query_plan_time_right": 1762531199000,
                        "task_run_status_list": [3, 4]
                    }
                },
                {
                    "description": "Fuzzy search task runs containing 'etl', filtered by project 2001 and task run type = schedule task run.",
                    "query": {
                        "project_id": 2001,
                        "task_name_or_id": "etl",
                        "task_run_type": 1,
                        "page_index": 1,
                        "page_size": 10,
                        "orderBy": "asc",
                        "order_by_field": "plan_trigger_time"
                    }
                }
            ]
        ),
    ]


async def handle_get_task_run_dependencies(arguments=None, studio_config: StudioConfig = None, **kwargs) -> \
list[TextContent | EmbeddedResource]:
    """
    get schedule task run dependencies in Clickzetta Studio
    """
    if arguments is None:
        arguments = {}

    try:
        # Extract parameters
        project_id = arguments.get("project_id")
        task_run_id = arguments.get("task_run_id")

        child_level = arguments.get("child_level", 1)
        parent_level = arguments.get("parent_level", 1)

        # Get auth context from server core
        config = studio_config
        if project_id is None:
            project_id = config.project_id
        # Use config project ID if not provided


        logger.info(f"Getting schedule task run relation for task run {task_run_id} and project_id: {project_id}")

        # Call the API
        response = api_schedule_instance_relation(
            projectId=project_id,
            taskInstanceId=task_run_id,
            parentLevel=parent_level,
            childLevel=child_level,
            jwt_token=config.token,
            instance_name=config.instance,
            env=config.env,
            workspace_name=config.workspace
        )

        # Parse and format the response
        response_data = json.loads(response)

        if response_data.get("code") == "200":
            data = response_data.get("data", {})

            # Convert field names to tool naming convention
            converted_data = convert_task_run_dependency_fields(data)

            # Format the response for better readability
            formatted_response = {
                "success": True,
                "message": "Successfully get task run dependencies",
                "graph": converted_data
            }

            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[handle_get_schedule_task_run_dependencies]API request failed: {response_data.get('msg', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in get task run dependencies: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)



def get_task_run_dependencies_tools() -> List[Tool]:
    """Get all Studio-specific tools"""
    return [
        Tool(
            name="get_task_run_dependencies",
            description=(
                "Get upstream and downstream dependency task runs of a specific task run. "
                "Returns dependency information as a tree structure, with configurable "
                "parent (upstream) and child (downstream) depth levels."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "project_id": {
                        "type": "integer",
                        "description": "Project space ID of the task. Required."
                    },
                    "task_run_id": {
                        "type": "integer",
                        "description": "Task Run ID for which to retrieve dependency relations. Required."
                    },
                    "parent_level": {
                        "type": "integer",
                        "description": (
                            "Number of upstream dependency levels to retrieve. "
                            "Default is 1."
                        ),
                        "default": 1
                    },
                    "child_level": {
                        "type": "integer",
                        "description": (
                            "Number of downstream dependency levels to retrieve. "
                            "Default is 1."
                        ),
                        "default": 1
                    }
                },
                "additionalProperties": False,
                "required": ["task_run_id"]
            },
            handler=handle_get_task_run_dependencies,
            tags=[ "task_run_relation", "dependency", "graph"],
            samples=[
                {
                    "description": "Get 1-level upstream and downstream dependencies for task run 9001 under project 2001.",
                    "query": {
                        "project_id": 2001,
                        "task_run_id": 9001,
                        "parent_level": 1,
                        "child_level": 1
                    }
                },
                {
                    "description": "Get 3 levels of upstream and 2 levels of downstream dependencies for the given task run.",
                    "query": {
                        "project_id": 2001,
                        "task_run_id": 9001,
                        "parent_level": 3,
                        "child_level": 2
                    }
                }
            ]
        ),
    ]

async def handle_get_attempt_log(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    get task attempt log content in Clickzetta Studio
    """
    if arguments is None:
        arguments = {}

    try:
        # Extract parameters

        task_run_id = arguments.get("task_run_id")

        attempt_id = arguments.get("attempt_id")
        offset = arguments.get("offset")
        query_action = arguments.get("query_action", 3)

        config = studio_config

        # Use config project ID if not provided


        logger.info(f"Getting attempt logs for task run {task_run_id} and attempt id: {attempt_id}")

        # Call the API
        response = api_get_attempt_log_content(
            taskInstanceId= task_run_id,
            executeLogId= attempt_id,
            queryLogActionCode= query_action,
            offset= offset,
            jwt_token=config.token,
            instance_name=config.instance,
            env=config.env,
            workspace_name=config.workspace
        )

        # Parse and format the response
        response_data = json.loads(response)

        if response_data.get("code") == "200":
            data = response_data.get("data", {})
            log_content = data.get("logContent", "")
            start_offset = data.get("startOffset", 0)
            end_offset = data.get("endOffset", 0)
            has_next = data.get("hasNext", False)
            # Format the response for better readability
            formatted_response = {
                "success": True,
                "message": "Successfully get attempt logs",
                "attempt_id": attempt_id,
                "log_content": log_content,
                "start_offset": start_offset,
                "end_offset": end_offset,
                "has_next": has_next
            }

            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[handle_get_attempt_log]API request failed: {response_data.get('msg', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in get attempt logs: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)




def get_attempt_log_tool() -> List[Tool]:
    """Get all Studio-specific tools"""
    return [
        Tool(
            name="get_attempt_log",
            description=(
                "Get attempt log content for a specific task-run attempt. "
                "Each task run may have multiple attempts. "
                "Supports querying logs from top, bottom, or by offset in forward/backward direction."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "attempt_id": {
                        "type": "integer",
                        "description": "Attempt ID."
                    },
                    "task_run_id": {
                        "type": "integer",
                        "description": "Task run ID."
                    },
                    "query_action": {
                        "type": "integer",
                        "description": (
                            "Log query action type. "
                            "1 = query downward, "
                            "2 = query upward, "
                            "3 = query from tail (default)."
                        ),
                        "enum": [1, 2, 3],
                        "default": 3
                    },
                    "offset": {
                        "type": "integer",
                        "description": (
                            "Log read offset. Not required when query_action = 3 "
                            "(query from tail)."
                        )
                    }
                },
                "additionalProperties": False,
                "required": ["attempt_id", "task_run_id"]
            },
            handler=handle_get_attempt_log,
            tags=["log", "task_run", "attempt"],
            samples=[
                {
                    "description": "Get log content from tail for the specified attempt.",
                    "query": {
                        "attempt_id": 10001,
                        "task_run_id": 50001,
                        "query_action": 3
                    }
                },
                {
                    "description": "Get log content from offset 2000 downward.",
                    "query": {
                        "attempt_id": 10001,
                        "task_run_id": 50001,
                        "query_action": 1,
                        "offset": 2000
                    }
                }
            ]
        ),
    ]


async def _handle_list_attempts(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    list attempts for a task run in Clickzetta Studio
    Each task run may have multiple attempts.
    """
    if arguments is None:
        arguments = {}

    try:
        # Extract parameters
        project_id = arguments.get("project_id")
        task_run_id = arguments.get("task_run_id")

        page_index = arguments.get("page_index", 1)
        page_size = arguments.get("page_size", 20)

        # Get auth context from server core
        config = studio_config
        if project_id is None:
            project_id = config.project_id
        # Use config project ID if not provided


        logger.info(f"Getting attempts for task run {task_run_id} and project_id: {project_id}")

        # Call the API
        response = api_list_attempt_records(
            projectId=project_id,
            taskInstanceId=task_run_id,
            pageIndex=page_index,
            pageSize=page_size,
            jwt_token=config.token,
            instance_name=config.instance,
            env=config.env,
            workspace_name=config.workspace
        )

        # Parse and format the response
        response_data = json.loads(response)

        if response_data.get("code") == "200":
            raw_data = response_data.get("data")
            if raw_data is None:
                data = []
            elif isinstance(raw_data, list):
                data = raw_data
            else:
                data = [raw_data]

            raw_count = response_data.get("count")
            count = raw_count if isinstance(raw_count, int) else len(data)

            # Convert field names to tool naming convention
            converted_attempts = [
                convert_attempt_fields(attempt)
                for attempt in data
                if isinstance(attempt, dict)
            ]

            # Format the response for better readability
            formatted_response = {
                "success": True,
                "message": "Successfully get attempts",
                "attempts": converted_attempts,
                "total_count": count,
                "page_index": page_index
            }

            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[handle_list_attempts]API request failed: {response_data.get('msg', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in get attempts: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


async def handle_list_attempts(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    Canonical handler for listing task-run attempts.
    """
    return await _handle_list_attempts(arguments=arguments, studio_config=studio_config, **kwargs)



def list_attempts_tools() -> List[Tool]:
    """Get canonical task-run attempt tools"""
    return [
        Tool(
            name="list_attempts",
            description=(
                "List attempts for a specific task run with **pagination**. "
                "The attempt concept follows Yarn semantics: each retry or re-run under the same task run is an attempt. "
                "Supports specifying project ID and paging parameters."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "task_run_id": {
                        "type": "integer",
                        "description": "Task run ID."
                    },
                    "project_id": {
                        "type": "integer",
                        "description": "Project ID."
                    },
                    "page_index": {
                        "type": "integer",
                        "description": "Page index (1-based).",
                        "default": 1
                    },
                    "page_size": {
                        "type": "integer",
                        "description": "Page size (default 20).",
                        "default": 20
                    }
                },
                "additionalProperties": False,
                "required": ["task_run_id"]
            },
            handler=handle_list_attempts,
            tags=["attempt", "task_run"],
            samples=[
                {
                    "description": "List attempts for task run 50001 under project 2001.",
                    "query": {
                        "task_run_id": 50001,
                        "project_id": 2001,
                        "page_index": 1,
                        "page_size": 20
                    }
                },
                {
                    "description": "List attempts on page 2 with page size 10.",
                    "query": {
                        "task_run_id": 50001,
                        "project_id": 2001,
                        "page_index": 2,
                        "page_size": 10
                    }
                }
            ]
        ),
    ]
async def handle_get_task_run_stats(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    get task run statistics in Clickzetta Studio
    """
    if arguments is None:
        arguments = {}

    try:
        today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        yesterday = today - timedelta(days=1)
        yesterday_zero = yesterday.replace(hour=0, minute=0, second=0)
        tomorrow = today + timedelta(days=1)
        tomorrow_end = tomorrow.replace(hour=23, minute=59, second=59)

        # Extract parameters
        task_name_or_id = arguments.get("task_name_rlike", "")
        task_type = arguments.get("task_type")
        task_run_type = arguments.get("task_run_type", 1)

        query_start_time = arguments.get("query_plan_time_left", yesterday_zero.timestamp()*1000 )
        query_end_time = arguments.get("query_plan_time_right", tomorrow_end.timestamp()*1000)
        task_run_status_list = arguments.get("task_run_status_list")

        task_owner_id = arguments.get("task_owner_id")
        executor_user_id = arguments.get("executor_user_id")
        group_id = arguments.get("group_id")
        vc_code = arguments.get("vc_code")
        # Get auth context from server core
        config = studio_config

        # Use config project ID if not provided
        project_id = config.project_id

        logger.info(f"get task run stats for project_id: {project_id}")

        # Call the API
        response = api_get_instance_statistics(
            projectId=project_id,
            scheduleTaskName=task_name_or_id,
            taskType=task_type,
            instanceType=task_run_type,
            queryStartPlanTime = query_start_time,
            queryEndPlanTime = query_end_time,
            instanceStatusList= task_run_status_list,
            groupId = group_id,
            taskOwnerId= task_owner_id,
            executorUserId= executor_user_id,
            vcCode=vc_code,
            jwt_token=config.token,
            instance_name=config.instance,
            instance_id = config.instance_id,
            user_id=config.user_id,
            account_id=config.tenant_id,
            env=config.env,
            workspace_name=config.workspace
        )

        # Parse and format the response
        response_data = json.loads(response)

        if response_data.get("code") == "200":
            stats = response_data.get("data", [])
            converted_stats = [convert_run_stats_fields(statistic) for statistic in stats]
            # Format the response for better readability
            formatted_response = {
                "success": True,
                "message": "Successfully get task run stats",
                "stats": converted_stats,
            }

            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[handle_get_task_run_stats]API request failed: {response_data.get('msg', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in get task run stats: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


def get_task_run_stats_tools() -> List[Tool]:
    """Get all Studio-specific tools"""
    return [
        Tool(
            name="get_task_run_stats",
            description=(
                "Get task run statistics aggregated by task. "
                "Supports filtering by project space, task type, task run type, "
                "task name pattern (regex-like), planned time range, task run status combinations, "
                "task owner, executor user, task group, and version control code. "
                "\n\n"
                "**When to Use This Tool:**\n"
                "✅ **PRIORITIZE this tool** when users ask vague questions about task execution, such as:\n"
                "- 'How are my task executions doing?'\n"
                "- 'What's my task execution status?'\n"
                "- 'Show me task execution statistics'\n"
                "- 'How many task runs succeeded/failed?'\n"
                "- 'What's the task execution situation?'\n"
                "\n"
                "❌ **DO NOT use this tool** when users explicitly request:\n"
                "- 'List all my task runs' (use list_task_run instead)\n"
                "- 'Show me attempt details' (use list_attempts instead)\n"
                "- 'Get specific attempt information' (use list_task_run or list_attempts instead)\n"
                "\n"
                "**Time Parameters:**\n"
                "⚠️ The `query_plan_time_left` and `query_plan_time_right` parameters require timestamp values in milliseconds. "
                "If you are uncertain about the time values, first call `get_current_datetime` to get the current timestamp_ms, "
                "then calculate the desired time range based on it.\n"
                "\n"
                "**Aggregation Dimensions:**\n"
                "The returned statistics are aggregated by three dimensions:\n"
                "- Task run status (task_run_status)\n"
                "- Task type (task_type)\n"
                "- Task run type (task_run_type)\n"
                "\n"
                "**Secondary Aggregation:**\n"
                "If the user needs higher-level aggregation (e.g., aggregated only by task run status, "
                "or only by task type), you need to perform secondary aggregation on the returned data. "
                "For example, to get statistics grouped only by task run status, sum up the 'count' field "
                "for all records with the same 'task_run_status' value."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "task_name_rlike": {
                        "type": "string",
                        "description": (
                            "Task name pattern filter (regex-like). "
                            "Optional; returns all tasks if omitted."
                        )
                    },
                    "task_type": {
                        "type": "integer",
                        "description": f"Task type filter. Optional. {task_type_desc} ; returns all if omitted."
                    },
                    "task_run_type": {
                        "type": "integer",
                        "description": (
                            "Task run type. Valid values: "
                            "1 = Schedule task run, "
                            "3 = Temporary task run, "
                            "4 = Refill task run."
                        ),
                        "enum": [1, 3, 4],
                        "default": 1
                    },
                    "query_plan_time_left": {
                        "type": "integer",
                        "description": (
                            "Left bound of planned time (timestamp in milliseconds). "
                            "The default value is the timestamp of yesterday at 00:00:00 based on the current time. "
                            "Example: 1762444800000. "
                            "⚠️ **IMPORTANT**: If you are uncertain about the time value, first call `get_current_datetime` to get the current timestamp_ms, "
                            "then calculate the desired time range based on it (e.g., subtract 24 hours for yesterday, or set to 00:00:00 of a specific date)."
                        )
                    },
                    "query_plan_time_right": {
                        "type": "integer",
                        "description": (
                            "Right bound of planned time (timestamp in milliseconds). "
                            "The default value is the timestamp of tomorrow at 23:59:59 based on the current time. "
                            "Example: 1762531199000. "
                            "⚠️ **IMPORTANT**: If you are uncertain about the time value, first call `get_current_datetime` to get the current timestamp_ms, "
                            "then calculate the desired time range based on it (e.g., add 24 hours for tomorrow, or set to 23:59:59 of a specific date)."
                        )
                    },
                    "task_run_status_list": {
                        "type": "array",
                        "items": {"type": "integer"},
                        "description": (
                            "List of task run status values. Supported values: "
                            "1=Success, 2=Not started, 3=Failed, 4=Running, "
                            "5=Waiting for resources, 6=Waiting for upstream, "
                            "7=Paused, 8=Upstream failed blocking."
                        )
                    },
                    "task_owner_id": {
                        "type": "integer",
                        "description": "Task owner user ID filter."
                    },
                    "executor_user_id": {
                        "type": "integer",
                        "description": "Executor user ID filter."
                    },
                    "group_id": {
                        "type": "integer",
                        "description": "Task group ID filter."
                    },
                    "vc_code": {
                        "type": "string",
                        "description": "Version control code filter."
                    }
                },
                "additionalProperties": False,
                "required": ["query_plan_time_left", "query_plan_time_right"]
            },
            handler=handle_get_task_run_stats,
            tags=["task_run_stats", "statistics", "aggregation"],
            samples=[
                {
                    "description": "Get task run statistics for tasks matching pattern 'etl' within a time window, filtered by status.",
                    "query": {
                        "task_name_rlike": "etl",
                        "task_run_type": 1,
                        "query_plan_time_left": 1762444800000,
                        "query_plan_time_right": 1762531199000,
                        "task_run_status_list": [1, 3]
                    }
                },
                {
                    "description": "Get statistics for all tasks in a specific task group within a time range.",
                    "query": {
                        "group_id": 1001,
                        "query_plan_time_left": 1762444800000,
                        "query_plan_time_right": 1762531199000,
                        "task_run_type": 1
                    }
                },
                {
                    "description": "Get statistics for tasks owned by a specific user.",
                    "query": {
                        "task_owner_id": 2001,
                        "query_plan_time_left": 1762444800000,
                        "query_plan_time_right": 1762531199000
                    }
                }
            ]
        ),
    ]
