"""
Studio Execute Tools for MCP Studio server
Handles async task execution with status polling
"""
import json
import logging
from typing import List, Optional, Any, Coroutine

from mcp.types import TextContent, EmbeddedResource

from cz_mcp.handlers.execute_server import (
    adhoc_execute,
    get_task_instance_detail,
    poll_task_status
)
from cz_mcp.handlers.ide_admin_server import get_task_detail
from cz_mcp.tools.schedule_instance_tools import convert_task_run_fields
from .file_tools import _convert_file_type_to_task_type
from ..common.redirect_url_utils import _build_ops_studio_url
from ..common.task_type import TaskType
from ..core.tool_registry import Tool
from ..common.utilities import ResponseBuilder
from ..handlers.login_server import get_current_user
from ..studio_config_manager import StudioConfig

from loguru import logger


async def handle_execute_task(arguments=None, studio_config: StudioConfig = None, **kwargs
) -> list[TextContent | EmbeddedResource]:
    """
    Execute data integration task asynchronously and poll for completion
    
    This tool:
    1. Submits the integration task for execution
    2. Polls the task status until completion or timeout
    3. Returns the final execution result
    """
    if arguments is None:
        arguments = {}
    
    try:
        config = studio_config
        
        # Extract required parameters
        data_task_id = arguments.get("data_task_id")
        data_task_content = arguments.get("data_task_content")
        
        if not data_task_id:
            return ResponseBuilder.create_yaml_json_response([{
                "success": False,
                "message": "data_task_id is required"
            }], studio_config=studio_config)
        
        if not data_task_content:
            return ResponseBuilder.create_yaml_json_response([{
                "success": False,
                "message": "data_task_content is required"
            }], studio_config=studio_config)
        
        # Extract optional parameters with defaults
        params = arguments.get("params", {})
        collect_type = arguments.get("collect_type", 1)
        max_row_size = arguments.get("max_row_size", 1000)
        offset_line = arguments.get("offset_line", 0)
        offset_col = arguments.get("offset_col", 0)
        multi_data_source = arguments.get("multi_data_source", [])
        
        # Check if the task is an integration task by querying task details
        task_type = None
        try:
            task_detail_response = get_task_detail(
                data_task_id=data_task_id,
                jwt_token=config.token,
                instance_name=config.instance,
                env=config.env,
                workspace_name=config.workspace
            )
            task_detail_data = json.loads(task_detail_response)
            if task_detail_data.get("code") == "200":
                task_data = task_detail_data.get("data", {})
                task_type = task_data.get("fileType")
                task_type = _convert_file_type_to_task_type(task_type)
                logger.info(f"Retrieved task type: {task_type} for task_id: {data_task_id}")
        except Exception as e:
            logger.warning(f"Failed to retrieve task type for task_id {data_task_id}: {e}")
        
        # Determine adhoc_vc_code based on task type
        # Integration task types: 10 (离线同步), 28 (实时同步), 280 (全增量一体同步), 281 (多表实时同步), 291 (多表离线同步)
        integration_task_types = [
            TaskType.DataIntegration,      # 10
            TaskType.RealTimeDI,            # 28
            TaskType.FullIncrementalSync,   # 280
            TaskType.MultipleRISync,        # 281
            TaskType.MultipleDISync         # 291
        ]
        
        if task_type in integration_task_types:
            # For integration tasks, force adhoc_vc_code to FLINK_ON_VC
            adhoc_vc_code = "FLINK_ON_VC"
            logger.info(f"Task {data_task_id} is an integration task (type={task_type}), setting adhoc_vc_code=FLINK_ON_VC")
        else:
            # For non-integration tasks, use the provided value or default
            adhoc_vc_code = arguments.get("adhoc_vc_code", config.vcluster)
            logger.info(f"Task {data_task_id} is not an integration task (type={task_type}), using adhoc_vc_code={adhoc_vc_code}")
        
        adhoc_schema_name = arguments.get("adhoc_schema_name", config.schema)
        adhoc_vc_id = arguments.get("adhoc_vc_id", "")
        
        # Polling parameters
        max_wait_seconds = arguments.get("max_wait_seconds", 300)
        poll_interval = arguments.get("poll_interval", 5)
        
        update_by = config.username
        if update_by is None:
            current_user = get_current_user(config.token, config.env)
            update_by = current_user["name"] if current_user else ""

        logger.info(f"Executing task for task_id: {data_task_id}")
        
        # Step 1: Submit task for execution
        response = adhoc_execute(
            data_task_id=data_task_id,
            data_task_content=data_task_content,
            params=params,
            update_by=update_by,
            collect_type=collect_type,
            max_row_size=max_row_size,
            offset_line=offset_line,
            offset_col=offset_col,
            multi_data_source=multi_data_source,
            adhoc_vc_code=adhoc_vc_code,
            adhoc_schema_name=adhoc_schema_name,
            adhoc_vc_id=adhoc_vc_id,
            jwt_token=config.token,
            instance_name=config.instance,
            user_id = config.user_id,
            instance_id=config.instance_id,
            account_id= config.tenant_id,
            env=config.env,
            workspace_name=config.workspace
        )
        
        response_data = json.loads(response)
        
        if response_data.get("code") != "200":
            error_response = {
                "success": False,
                "message": f"Failed to submit task: {response_data.get('message', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)
        
        # Extract task instance ID
        execute_result = response_data.get("data")
        
        if not execute_result:
            error_response = {
                "success": False,
                "message": "Task submitted but no task instance ID returned",
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)
        
        logger.info(f"Task submitted successfully, execute_result: {execute_result}")
        
        # Step 2: Poll for task completion
        logger.info(f"Starting to poll task status for execute_result: {execute_result}")

        task_instance_id = execute_result.get("scheduleInstanceId")
        
        poll_result = poll_task_status(
            task_instance_id=task_instance_id,
            jwt_token=config.token,
            instance_name=config.instance,
            instance_id=config.instance_id,
            user_id=config.user_id,
            account_id=config.tenant_id,
            env=config.env,
            max_wait_seconds=max_wait_seconds,
            poll_interval=poll_interval
        )
        
        formatted_response = {
            "success": poll_result.get("success", False),
            "message": f"Task execution {poll_result.get('status')}",
            "task_instance_id": task_instance_id,
            "execution_status": poll_result.get("status"),
            "status_code": poll_result.get("status_code"),
            "elapsed_seconds": poll_result.get("elapsed_seconds"),
            "poll_count": poll_result.get("poll_count"),
        }
        
        if not poll_result.get("success"):
            formatted_response["error_message"] = poll_result.get("error_message") or poll_result.get("message")
        
        # Include task details if available
        if "task_detail" in poll_result:
            formatted_response["task_detail"] = poll_result["task_detail"]
        
        return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
    
    except Exception as e:
        logger.error(f"Error in execute_integration_task: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


async def handle_get_task_instance_detail(arguments=None, studio_config: StudioConfig = None, **kwargs
) -> list[TextContent | EmbeddedResource]:
    """
    Get execution status of a task instance
    """
    if arguments is None:
        arguments = {}
    
    try:
        config = studio_config
        
        task_instance_id = arguments.get("task_instance_id")
        
        if not task_instance_id:
            return ResponseBuilder.create_yaml_json_response([{
                "success": False,
                "message": "task_instance_id is required"
            }], studio_config=studio_config)
        
        project_id = studio_config.project_id
        schedule_task_id = arguments.get("schedule_task_id")
        
        logger.info(f"Getting task status for task_instance_id: {task_instance_id}")
        
        response = get_task_instance_detail(
            task_instance_id=task_instance_id,
            jwt_token=config.token,
            instance_name=config.instance,
            instance_id=config.instance_id,
            user_id = config.user_id,
            account_id=config.tenant_id,
            env=config.env,
            project_id=int(project_id),
            schedule_task_id=schedule_task_id,
            workspace_name=config.workspace
        )
        
        response_data = json.loads(response)
        
        if response_data.get("code") == "200":
            task_data = response_data.get("data", {})
            converted = convert_task_run_fields(task_data)

            # Status mapping
            STATUS_NAMES = {
                1: "WAITING",
                2: "RUNNING",
                3: "SUCCESS",
                4: "FAILED",
                5: "KILLED",
                6: "TIMEOUT"
            }

            status_code = task_data.get("instanceStatus")
            status_name = STATUS_NAMES.get(status_code, f"UNKNOWN({status_code})")

            formatted_response = {
                "success": True,
                "message": "Task status retrieved successfully",
                "task_run_id": task_instance_id,
                "status": status_name,
                "status_code": status_code,
                "task_detail": converted
            }
            studio_url = _build_ops_studio_url(studio_config, task_instance_id, 'taskInst', config.env) if task_instance_id else None
            if studio_url:
                formatted_response["redirect_url"] = studio_url

            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"Failed to get task status: {response_data.get('message', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)
    
    except Exception as e:
        logger.error(f"Error in get_task_status: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


def execute_tool() -> List[Tool]:
    """Get execute tool"""
    return [
        Tool(
            name="execute_task",
            description=(
                "Execute a data task asynchronously in Clickzetta Studio.\n\n"
                "⚠️ Mandatory VC selection (STRICT, MUST DO FIRST — NO DEFAULT VC): "
                "Before ANY task retrieval or submission, the tool MUST call `LH-show_object_list`  with `object_type='VCLUSTERS'` to fetch the available Virtual Clusters (VCs) "
                "for the current workspace/project. "
                "**IF** the `task_type` is **10 (离线同步), 28 (实时同步), 280 (全增量一体同步), or 281 (多表实时同步)**:"
                    "a. You **MUST** check for available Sync Virtual Clusters by calling `LH-show_object_list` with `object_type='VCLUSTERS'`."
                    "b. Filter the results to find vclusters where `vcluster_type` contains 'SYNC' or similar sync-related indicators."
                    "c. **IF** no Sync Virtual Cluster is found:"
                       " i. **CRITICAL**: You **MUST** stop execution immediately."
                        "ii. **MUST** return a clear error message to the user: **Error: This integration task requires a 'Sync VCluster', but none was found. Please create a Sync VCluster in Clickzetta before retrying.**"
            
                    "d. **ELSE** (a Sync Virtual Cluster was found):"
                        "i. When calling the `save_task_configuration` function, you **MUST** set the `etl_vc_code` parameter to the name of the found Sync Virtual Cluster."
                "**ELSE** (the `task_type` is not an integration task):"
                    "a. No check for a Sync Virtual Cluster is needed."

                "Task content resolution: If `data_task_content` is not provided, the tool retrieves the task definition using `data_task_id`. "
                "After loading the task content, the tool scans for custom variables in the format `${varName}`. "
                "If variables are detected, the tool MUST pause execution and request the user to supply values before continuing.\n\n"

                "Supported task types include:\n"
                "- Data integration tasks (source-to-sink synchronization)\n"
                "- Lakehouse SQL tasks\n"
                "- Other custom task types defined in Clickzetta Studio\n\n"

                "Execution flow: After (1) calling `list_vcluster` and obtaining an explicit user-selected VC, (2) resolving the task definition, and (3) resolving all required variables, "
                "the tool submits the task, automatically polls its execution status, waits for completion, and returns the final result.\n\n"

                "Error handling: If `list_vcluster` fails, returns no VCs, the selected VC is invalid/unavailable, the task definition cannot be retrieved, "
                "the task fails, or the task times out, the tool returns an appropriate error message."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "data_task_id": {
                        "type": "integer",
                        "description": "The ID of the data task containing the task definition"
                    },
                    "data_task_content": {
                        "type": "string",
                        "description": (
                            "The task configuration as a JSON string or SQL text. "
                            "For integration tasks: JSON with templateKey, sourceConnection, sinkConnection, and jobs array. "
                            "For Lakehouse SQL tasks: SQL query text or JSON configuration. "
                            "The format depends on the task type defined in the data task."
                        )
                    },
                    "params": {
                        "type": "object",
                        "description": (
                            "Parameter key-value pairs for the task execution. "
                            "Example: {\"dt\": \"$[yyyy-MM-dd]\"}"
                        ),
                        "additionalProperties": {"type": "string"}
                    },
                    "adhoc_vc_code": {
                        "type": "string",
                        "description": "Virtual cluster code for execution. "
                                       "REQUIRED for integration tasks (task_type: 10, 28, 280, 281) - must be a Sync VCluster. "
                                       "REQUIRED for Lakehouse tasks. "
                                       "Optional for other task types (default: from config)."
                    },
                    "adhoc_schema_name": {
                        "type": "string",
                        "description": "Schema name for execution (default: from config)"
                    },
                    "adhoc_vc_id": {
                        "type": "string",
                        "description": "Virtual cluster ID for execution. "
                                       "REQUIRED for integration tasks (task_type: 10, 28, 280, 281) - must be a Sync VCluster ID. "
                                       "REQUIRED for Lakehouse tasks. "
                                       "Optional for other task types."
                    },
                    "collect_type": {
                        "type": "integer",
                        "description": "Collection type (default: 1)"
                    },
                    "max_row_size": {
                        "type": "integer",
                        "description": "Maximum rows to return (default: 1000)"
                    },
                    "offset_line": {
                        "type": "integer",
                        "description": "Line offset (default: 0)"
                    },
                    "offset_col": {
                        "type": "integer",
                        "description": "Column offset (default: 0)"
                    },
                    "multi_data_source": {
                        "type": "array",
                        "description": "Multi data source configuration (default: [])",
                        "items": {"type": "object"}
                    },
                    "max_wait_seconds": {
                        "type": "integer",
                        "description": "Maximum seconds to wait for task completion (default: 300)"
                    },
                    "poll_interval": {
                        "type": "integer",
                        "description": "Seconds between status polls (default: 5)"
                    }
                },
                "required": ["data_task_id", "data_task_content","adhoc_vc_code"],
                "additionalProperties": False
            },
            handler=handle_execute_task,
            tags=["studio", "execute", "integration", "sql", "async", "api"],
            samples=[
                {
                    "description": "Execute a data integration task",
                    "query": {
                        "data_task_id": 12005907,
                        "data_task_content": "{\"templateKey\":1,\"sourceConnection\":{...},\"sinkConnection\":{...},\"jobs\":[...]}",
                        "params": {"dt": "$[yyyy-MM-dd]"},
                        "adhoc_vc_code": "DEFAULT",
                        "adhoc_vc_id": "vc-id-123",
                    }
                },
                {
                    "description": "Execute a Lakehouse SQL task",
                    "query": {
                        "data_task_id": 12005908,
                        "data_task_content": "SELECT * FROM my_table WHERE dt = '${dt}'",
                        "params": {"dt": "2025-01-10"},
                        "adhoc_vc_code": "DEFAULT",
                        "adhoc_schema_name": "public"
                    }
                },
                {
                    "description": "Execute a SQL query with custom timeout",
                    "query": {
                        "data_task_id": 12005907,
                        "data_task_content": "SELECT COUNT(*) FROM orders",
                        "max_wait_seconds": 600,
                        "poll_interval": 10
                    }
                }
            ]
        ),
        Tool(
            name="get_task_instance_detail",
            description=(
                "Get the execution status and details of a task instance in Clickzetta Studio. "
                "This tool retrieves comprehensive information about a task's execution, including status, "
                "timing information, execution details, and error information if the task failed. "
                "Use this tool to check the status of a previously submitted task or to get detailed "
                "execution information for debugging purposes."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "task_instance_id": {
                        "type": "integer",
                        "description": "The unique identifier of the task instance to query"
                    },
                    "project_id": {
                        "type": "integer",
                        "description": "Optional project ID for the task (defaults to config project ID)"
                    },
                    "schedule_task_id": {
                        "type": "integer",
                        "description": "Optional schedule task ID (task ID) for the task"
                    }
                },
                "required": ["task_instance_id"],
                "additionalProperties": False
            },
            handler=handle_get_task_instance_detail,
            tags=["studio", "execute", "status", "monitoring", "api"],
            samples=[
                {
                    "description": "Get status of a task instance",
                    "query": {
                        "task_instance_id": 72085416
                    }
                },
                {
                    "description": "Get detailed task status with project and schedule info",
                    "query": {
                        "task_instance_id": 72085416,
                        "project_id": 97001,
                        "schedule_task_id": 12004918
                    }
                }
            ]
        )
    ]

