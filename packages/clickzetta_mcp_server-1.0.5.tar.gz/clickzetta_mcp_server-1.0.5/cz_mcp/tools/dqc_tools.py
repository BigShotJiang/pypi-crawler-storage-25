# coding=utf-8
"""
DQC (Data Quality Check) intelligent recommendation and creation tool
Provides smart DQC rule recommendations based on table structure and user requirements
"""
import json
import logging
from typing import List

from cz_mcp.common.utilities import ResponseBuilder
from cz_mcp.core.tool_registry import Tool
from cz_mcp.handlers.ide_admin_server import dqc_add as api_dqc_add
from ..common.redirect_url_utils import _build_dqc_studio_url
from ..studio_config_manager import StudioConfig

from loguru import logger


async def handle_create_dqc_rule(arguments=None, studio_config: StudioConfig = None, **kwargs):
    """
    Create and optionally trigger DQC rule execution
    Based on dqc_wrapper.py::dqc_add_wrapper and dqc_server.py::dqc_add
    """
    try:
        import httpx
        from cz_mcp.utils.config_utils import read_env_configuration, read_url, read_api

        config = studio_config
        if not config:
            return ResponseBuilder.create_error_response(
                error=ValueError("Server not initialized! db connection_config is None"),
                context="create_dqc_rule"
            )

        jwt_token = config.token
        workspace = config.workspace
        instance_name = config.instance
        project_id = config.project_id

        # Extract parameters
        object_name = arguments.get('object_name')
        rule_description = arguments.get('rule_description', 'Auto-generated DQC rule')

        # Rule configuration
        tag_code = arguments.get('tag_code')
        column_name = arguments.get('column_name')
        checker_info_str = arguments.get('checker_info')

        # Trigger configuration
        trigger_type = arguments.get('trigger_type', 'REST')
        trigger_cron = arguments.get('trigger_cron')
        main_scheduler_task_id = arguments.get('main_scheduler_task_id')
        level = arguments.get('level')

        # Execution configuration
        vcluster = arguments.get('vcluster', 'DEFAULT')
        timeout = arguments.get('timeout', 10)
        condition = arguments.get('condition')
        param_values = arguments.get('param_values', '[]')

        # Custom SQL configuration
        tag_type = arguments.get('tag_type', 1)
        defined_sql = arguments.get('defined_sql')

        # Validation: object_name is required
        if not object_name:
            return ResponseBuilder.create_yaml_json_response({
                "success": False,
                "error": "object_name is required",
                "required_parameters": ["object_name"],
                "example": {
                    "object_name": "user_table",
                    "tag_code": "table_count",
                    "operator": "GREATER_THAN",
                    "expected_value": 0
                }
            }, studio_config=studio_config)

        # Validate trigger type requirements
        if trigger_type == "SCHEDULE_TASK":
            if main_scheduler_task_id is None or level is None:
                return ResponseBuilder.create_yaml_json_response({
                    "success": False,
                    "error": "main_scheduler_task_id and level are required for SCHEDULE_TASK trigger type",
                    "required_for_schedule_task": ["main_scheduler_task_id", "level"]
                }, studio_config=studio_config)

        # checker_info_str = json.dumps(checker_info_str, ensure_ascii=False)

        # Build request payload matching dqc_server.py::dqc_add signature
        response_data = api_dqc_add(project_id,workspace, object_name, condition, rule_description,
            param_values, checker_info_str,tag_type,tag_code,defined_sql,column_name,vcluster,timeout,
            trigger_type,trigger_cron,main_scheduler_task_id,level,
            jwt_token, instance_name,user_id= config.user_id, instance_id= config.instance_id, account_id= config.tenant_id, env=config.env, workspace_name=config.workspace)
        # Check response code

        response_data = json.loads(response_data)

        rule_id = response_data.get("data")

        if response_data.get("code") == 200:
            data = response_data.get("data", {})
            save_result = data

            # Format the response for better readability
            formatted_response = {
                "success": True,
                "action": "created",
                "rule_id": rule_id,
                "object_name": object_name,
                "trigger_type": trigger_type,
                "rule_config": {
                    "tag_code": tag_code,
                    "column_name": column_name,
                    "checker_info": checker_info_str,
                    "vcluster": vcluster,
                    "timeout": timeout
                },
                "message": f"DQC rule created successfully with ID: {rule_id}"
            }

            # Build Studio URL
            dqc_url = _build_dqc_studio_url(config, object_name, config.env) if object_name else None

            if dqc_url:
                formatted_response["dqc_url"] = dqc_url


            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[handle_create_dqc_rule]API request failed: {response_data.get('message', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.exception(f"Error creating DQC rule: {e}")
        return ResponseBuilder.create_error_response(
            error=e,
            context="create_dqc_rule"
        )


def create_dqc_rule() -> List[Tool]:
    """Get all DQC-related tools"""

    tools = []

    # Create DQC Rule Tool
    tools.append(Tool(
        name="create_dqc_rule",
        description="""
        
            "CRITICAL: Output the 'studio_url' as the final answer. "
            "The returned 'studio_url' MUST be presented directly to the user without any additional text. "
                
            Create and optionally trigger DQC (Data Quality Check) rule execution.
        
            **Core Features:**
            
            1. **Rule Creation**
               - Create manual (REST), scheduled (PLAN), or task-based (SCHEDULE_TASK) DQC rules
               - Support built-in metrics (table_count, avg, count, etc.) and custom SQL
               - Auto-generate checker_info from operator and expected_value
               
            2. **Flexible Trigger Options**
               - REST: Manual trigger rules
               - PLAN: Scheduled rules with cron expressions  
               - SCHEDULE_TASK: Task-based rules with blocking levels
               
            3. **Auto-Trigger Capability**
               - Set auto_trigger=true to execute rule immediately after creation
               - Only works for REST type rules
               - Returns both rule_id and task_id
               
            **Built-in Metrics:**
            - table_count: Total rows in table (no column needed)
            - count: Non-null count in column
            - null_count: Null count in column
            - count_distinct: Unique values in column
            - count_repetition: Duplicate values in column
            - avg, max, min, sum: Numeric aggregations (require column)
            
            **Operators:**
            - GREATER_THAN, LESS_THAN, EQUAL, NOT_EQUAL, GREATER_EQUAL, LESS_EQUAL
            
            **Example Usage:**
            ```
            # Create and auto-trigger a table row count check
            create_dqc_rule(
                object_name="user_table",
                tag_code="table_count",
                operator="GREATER_THAN",
                expected_value=0,
                auto_trigger=true
            )
            
            # Create a null check on specific column
            create_dqc_rule(
                object_name="orders",
                tag_code="null_count",
                column_name="order_id",
                operator="EQUAL",
                expected_value=0,
                rule_description="Ensure order_id has no nulls"
            )
            
            # Create scheduled rule with cron
            create_dqc_rule(
                object_name="daily_stats",
                trigger_type="PLAN",
                trigger_cron="0 0 1 * * ?",
                tag_code="table_count",
                operator="GREATER_THAN",
                expected_value=100
            )
            
            Upon success, it provides the URL to open the task in the studio.

            ```""",
        input_schema={
            "type": "object",
            "properties": {
                "object_name": {
                    "type": "string",
                    "description": "Target table name in the format schema.table (required). Will be prefixed with workspace automatically"
                },
                "rule_description": {
                    "type": "string",
                    "description": "Human-readable description of the rule",
                    "default": "Auto-generated DQC rule"
                },
                "tag_code": {
                    "type": "string",
                    "description": "Built-in metric code",
                    "enum": ["table_count", "count", "null_count", "count_distinct", "count_repetition",
                             "avg", "max", "min", "sum"]
                },
                "column_name": {
                    "type": "string",
                    "description": "Column name for column-level metrics (required for count, null_count, avg, etc.)"
                },
                "checker_info": {
                    "type": "string",
                    "description": "Optional JSON string defining the checker configuration. Automatically generated from 'operator' and 'value' if not provided. Example: {\"checker\": \"FIXED\", \"operator\": \"GREATER_THAN\", \"value\": 0}. Supported operators: GREATER_THAN, LESS_THAN, EQUAL, NOT_EQUAL, GREATER_EQUAL, LESS_EQUAL."
                },
                "trigger_type": {
                    "type": "string",
                    "description": "Rule trigger type",
                    "enum": ["REST", "PLAN", "SCHEDULE_TASK"],
                    "default": "REST"
                },
                "trigger_cron": {
                    "type": "string",
                    "description": "Cron expression for PLAN trigger type (e.g., '0 0 1 * * ?' for daily at 1AM)"
                },
                "main_scheduler_task_id": {
                    "type": "integer",
                    "description": "ID of the scheduler task (required for trigger_type = SCHEDULE_TASK). Same as Clickzetta task_id."
                },
                "level": {
                    "type": "integer",
                    "description": "Blocking level for SCHEDULE_TASK: 0=non-blocking, 1=strong blocking",
                    "enum": [0, 1]
                },
                "vcluster": {
                    "type": "string",
                    "description": "Virtual cluster for rule execution",
                    "default": "DEFAULT"
                },
                "timeout": {
                    "type": "integer",
                    "description": "Rule execution timeout in minutes",
                    "default": 10
                },
                "condition": {
                    "type": "string",
                    "description": "WHERE clause condition for filtering data (optional)"
                },
                "param_values": {
                    "type": "string",
                    "description": "Custom parameters as JSON array string (e.g., '[{\"paramKey\":\"id\",\"paramValue\":\"1\"}]')",
                    "default": "[]"
                },
                "tag_type": {
                    "type": "integer",
                    "description": "Metric type: 1=built-in, 2=custom SQL",
                    "enum": [1, 2],
                    "default": 1
                },
                "defined_sql": {
                    "type": "string",
                    "description": "Custom SQL for tag_type=2 (must return single numeric value)"
                }
            },
            "required": ["object_name","rule_description","tag_code","column_name","checker_info","trigger_type","level","vcluster","timeout","condition","param_values","tag_type","defined_sql"]
        },
        handler=handle_create_dqc_rule,
        tags=["dqc", "data_quality", "create", "execution", "normalize"],
        samples=[
            {
                "description": "手动触发规则",
                "query": {
                    "param_values": "[]",
                    "datasource_type": "LakeHouse",
                    "trigger_type": "REST",
                    "timeout": 10,
                    "column_name": "id",
                    "object_type": "TABLE",
                    "vcluster": "DEFAULT",
                    "condition" : "dt='20230101'",
                    "trigger_cron": "0 00 00 * * ? *",
                    "object_name": "public.a_test_02",
                    "workspace_name": "aaa_aaa_01",
                    "checker_info": "{\"checker\":\"FIXED\",\"operator\":\"GREATER_THAN\",\"value\":1}",
                    "tag_type": 1,
                    "tag_code": "avg",
                    "trigger_config_properties": "{}"
                }
            },
            {
                "description": "创建定时规则",
                "query": {
                    "param_values": "[]",
                    "datasource_type": "LakeHouse",
                    "trigger_type": "PLAN",
                    "timeout": 10,
                    "column_name": "id",
                    "object_type": "TABLE",
                    "vcluster": "DEFAULT",
                    "trigger_cron": "0 00 00 * * ? *",
                    "object_name": "public.a_test_02",
                    "checker_info": "{\"checker\":\"FIXED\",\"operator\":\"GREATER_THAN\",\"value\":0}",
                    "tag_type": 1,
                    "tag_code": "avg",
                    "trigger_config_properties": "{}"
                }
            },
            {
                "description": "创建任务触发规则",
                "query": {
                    "param_values": "[]",
                    "datasource_type": "LakeHouse",
                    "trigger_type": "SCHEDULE_TASK",
                    "timeout": 10,
                    "column_name": "id",
                    "object_type": "TABLE",
                    "vcluster": "DEFAULT",
                    "main_scheduler_task_id": 12924001,
                    "level": 0,
                    "trigger_cron": "0 00 00 * * ? *",
                    "object_name": "public.a_test_02",
                    "checker_info": "{\"checker\":\"FIXED\",\"operator\":\"GREATER_THAN\",\"value\":1}",
                    "tag_type": 1,
                    "tag_code": "avg",
                    "trigger_config_properties": "{}"
                }
            },
            {
                "description": "创建自定义sql任务规则",
                "query": {
                    "param_values": "[]",
                    "datasource_type": "LakeHouse",
                    "trigger_type": "PLAN",
                    "timeout": 10,
                    "object_type": "TABLE",
                    "vcluster": "DEFAULT",
                    "trigger_cron": "0 00 00 * * ? *",
                    "object_name": "public.a_test_02",
                    "checker_info": "{\"checker\":\"FIXED\",\"operator\":\"GREATER_THAN\",\"value\":1}",
                    "tag_type": 2,
                    "defined_sql": "select *********",
                    "trigger_config_properties": "{}"
                }
            }

        ]
    ))

    return tools
