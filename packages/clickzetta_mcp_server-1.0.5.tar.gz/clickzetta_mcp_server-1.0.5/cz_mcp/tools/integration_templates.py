"""
Integration Task Template Library
Provides complete JSON templates based on real demos
"""

from typing import Dict, Any, Optional, List
from enum import IntEnum
import copy


class DataSourceType(IntEnum):
    """Data source type enumeration"""
    LAKEHOUSE = 1
    KAFKA = 2
    HIVE = 3
    CLICKHOUSE = 4
    MYSQL = 5
    POSTGRESQL = 7
    SQLSERVER = 8
    OSS = 9
    MONGODB = 12
    REDIS = 43


class IntegrationTemplateLibrary:
    """
    Integration template library with complete JSON structures from real demos.
    
    This library provides:
    1. Complete JSON templates for different datasource combinations
    2. Structured metadata for LLM understanding (_metadata field)
    3. Field-level annotations for human and machine reading
    4. Type mapping rules for automatic column conversion
    
    Usage for LLM:
    - Call get_template_metadata(template_key) to get structured information
    - Call get_template(template_key) to get the actual template with inline comments
    - Use metadata to understand required fields, optional fields, and constraints
    """
    
    # 数据源分类
    RELATIONAL_DB = [5, 7, 8, 17, 18, 19, 21, 22, 23, 24, 25, 26]  # MySQL, PostgreSQL, Oracle, etc.
    NOSQL_DB = [12, 43]  # MongoDB, Redis
    DATA_WAREHOUSE = [3, 4, 14, 15, 16, 20]  # Hive, ClickHouse, Doris, StarRocks, etc.
    STREAMING = [2, 45, 52]  # Kafka, AutoMQ, KafkaCdc
    FILE_STORAGE = [9, 27, 38]  # OSS, COS, S3
    
    # 完整的模板定义 - 直接来自真实 demo
    # 每个模板都包含完整的 JSON 结构和字段说明
    TEMPLATES = {
        # Kafka → Lakehouse
        "kafka_to_lakehouse": {
            "_meta": {
                "description": "Kafka消息队列到Lakehouse数据湖的集成模板",
                "source_type": 2,
                "source_name": "Kafka",
                "sink_type": 1,
                "sink_name": "Lakehouse",
                "use_case": "实时消息流到数据湖的集成,用于日志收集、事件流处理等场景",
                "required_fields": [
                    {"path": "sourceConnection.datasourceId", "type": "integer", "description": "源Kafka数据源ID", "how_to_get": "调用list_data_sources工具,筛选type=2"},
                    {"path": "sourceConnection.datasourceName", "type": "string", "description": "源Kafka数据源名称", "how_to_get": "从list_data_sources结果中获取"},
                    {"path": "sinkConnection.datasourceId", "type": "integer", "description": "目标Lakehouse数据源ID", "how_to_get": "调用list_data_sources工具,筛选type=1"},
                    {"path": "sinkConnection.datasourceName", "type": "string", "description": "目标Lakehouse数据源名称", "how_to_get": "从list_data_sources结果中获取"},
                    {"path": "source.dataObject", "type": "string", "description": "Kafka topic名称", "how_to_get": "用户指定或从get_meta_list获取"},
                    {"path": "source.params.table", "type": "string", "description": "Kafka topic名称", "how_to_get": "与source.dataObject相同"},
                    {"path": "sink.dataObject", "type": "string", "description": "目标Lakehouse表名", "how_to_get": "用户指定,表必须已存在"},
                    {"path": "sink.namespace", "type": "string", "description": "目标Lakehouse schema名称", "how_to_get": "用户指定或从get_namespace_list获取"},
                    {"path": "sink.params.table", "type": "string", "description": "目标表名", "how_to_get": "与sink.dataObject相同"},
                    {"path": "sink.params.database", "type": "string", "description": "目标schema名称", "how_to_get": "与sink.namespace相同"}
                ],
                "optional_fields": [
                    {"path": "source.params.codec", "type": "string", "default": "json", "options": ["json", "avro", "csv", "protobuf"], "description": "消息编码格式"},
                    {"path": "source.params.mode", "type": "string", "default": "earliest-offset", "options": ["earliest-offset", "latest-offset", "timestamp"], "description": "消费起始位置"},
                    {"path": "source.params.endMode", "type": "string", "default": "period", "options": ["period", "latest-offset"], "description": "消费结束模式"},
                    {"path": "source.params.groupId", "type": "string", "default": "0001", "description": "Kafka消费者组ID"},
                    {"path": "sink.params.vclusterName", "type": "string", "default": "DEFAULT", "description": "虚拟集群名称"},
                    {"path": "sink.params.writeMode", "type": "string", "default": "OVERWRITE", "options": ["APPEND", "OVERWRITE"], "description": "写入模式"},
                    {"path": "setting.parallelism", "type": "integer", "default": 1, "range": [1, 10], "description": "并行度"},
                    {"path": "setting.errorLimit.maxCount", "type": "integer", "default": 1, "description": "最大错误数,-1表示无限制"}
                ],
                "fixed_fields": [
                    {"path": "sourceConnection.type", "value": 2, "description": "Kafka类型标识"},
                    {"path": "sinkConnection.type", "value": 1, "description": "Lakehouse类型标识"},
                    {"path": "source.namespace", "value": "--", "description": "Kafka固定使用--作为namespace"},
                    {"path": "source.params.database", "value": "--", "description": "Kafka固定使用--作为database"},
                    {"path": "source.params.dsType", "value": 2, "description": "源数据源类型"},
                    {"path": "source.params.operatorType", "value": "source", "description": "源操作类型"},
                    {"path": "sink.params.dsType", "value": 1, "description": "目标数据源类型"},
                    {"path": "sink.params.operatorType", "value": "sink", "description": "目标操作类型"}
                ],
                "auto_generated_fields": [
                    {"path": "source.columns", "description": "Kafka固定的5个系统列", "generation_rule": "使用预定义的系统列: __key__, __value__, __partition__, __offset__, __timestamp__"},
                    {"path": "sink.columns", "description": "Lakehouse对应的列", "generation_rule": "从source.columns映射,类型转换: STRING→string, INTEGER→int, LONG→bigint"},
                    {"path": "columnMapping", "description": "列名映射关系", "generation_rule": "同名映射,所有5个系统列"}
                ],
                "special_notes": [
                    "Kafka的5个系统列是固定的,不需要从API获取",
                    "__value__列包含完整的消息内容(通常是JSON字符串)",
                    "如需解析__value__中的字段,需要在Lakehouse中使用JSON函数",
                    "source.namespace和source.params.database固定为'--'",
                    "目标表必须提前创建,且列结构需要包含这5个系统列"
                ],
                "type_mappings": {
                    "STRING": "string",
                    "INTEGER": "int",
                    "LONG": "bigint"
                },
                "fill_instructions": {
                    "sourceConnection.datasourceId": "源Kafka数据源ID,通过list_data_sources获取",
                    "sourceConnection.datasourceName": "源Kafka数据源名称",
                    "sinkConnection.datasourceId": "目标Lakehouse数据源ID",
                    "sinkConnection.datasourceName": "目标Lakehouse数据源名称",
                    "source.dataObject": "Kafka topic名称",
                    "source.params.table": "Kafka topic名称(与dataObject相同)",
                    "source.params.codec": "消息编码格式: json/avro/csv等",
                    "source.params.mode": "消费模式: earliest-offset(从最早)/latest-offset(从最新)/timestamp(指定时间)",
                    "source.params.endMode": "结束模式: period(持续消费)/latest-offset(消费到最新)",
                    "source.params.groupId": "Kafka消费者组ID",
                    "sink.dataObject": "目标Lakehouse表名",
                    "sink.namespace": "目标Lakehouse schema名称",
                    "sink.params.table": "目标表名(与dataObject相同)",
                    "sink.params.database": "目标schema名称(与namespace相同)",
                    "sink.params.vclusterName": "虚拟集群名称,默认DEFAULT",
                    "sink.params.writeMode": "写入模式: APPEND(追加)/OVERWRITE(覆盖)",
                    "setting.parallelism": "并行度,建议1-10",
                    "setting.errorLimit.maxCount": "最大错误数,-1表示无限制"
                },
                "human_notes": [
                    "Kafka使用5个固定系统列: __key__, __value__, __partition__, __offset__, __timestamp__",
                    "source.namespace固定为'--'",
                    "source.params.database固定为'--'",
                    "sink.columns的类型会自动转换: STRING→string, INTEGER→int, LONG→bigint"
                ]
            },
            "templateKey": 1,
            "userParams": {},
            "sourceConnection": {
                "datasourceId": None,  # 必填: Kafka数据源ID
                "datasourceName": None,  # 必填: Kafka数据源名称
                "type": 2  # 固定值: Kafka类型
            },
            "sinkConnection": {
                "datasourceId": None,  # 必填: Lakehouse数据源ID
                "datasourceName": None,  # 必填: Lakehouse数据源名称
                "type": 1  # 固定值: Lakehouse类型
            },
            "jobs": [{
                "source": {
                    "dataObject": None,  # 必填: Kafka topic名称
                    "namespace": "--",  # 固定值: Kafka使用"--"作为namespace
                    "params": {
                        "dsType": 2,  # 固定值: Kafka类型
                        "operatorType": "source",  # 固定值: 源操作类型
                        "codec": "json",  # 可选修改: 消息编码格式(json/avro/csv)
                        "mode": "earliest-offset",  # 可选修改: 消费起始位置(earliest-offset/latest-offset/timestamp)
                        "endMode": "period",  # 可选修改: 结束模式(period持续消费/latest-offset消费到最新)
                        "groupId": "0001",  # 可选修改: Kafka消费者组ID
                        "table": None,  # 必填: topic名称(与dataObject相同)
                        "database": "--"  # 固定值: Kafka使用"--"作为database
                    },
                    "columns": [  # 固定值: Kafka的5个系统列
                        {"name": "__key__", "type": "STRING", "comment": None, "nullable": False, "supportAsSplitKey": False, "properties": None, "primary": False, "sorted": False, "partitionColumn": False, "cluster": False},  # Kafka消息key
                        {"name": "__value__", "type": "STRING", "comment": None, "nullable": False, "supportAsSplitKey": False, "properties": None, "primary": False, "sorted": False, "partitionColumn": False, "cluster": False},  # Kafka消息value(JSON字符串)
                        {"name": "__partition__", "type": "INTEGER", "comment": None, "nullable": False, "supportAsSplitKey": False, "properties": None, "primary": False, "sorted": False, "partitionColumn": False, "cluster": False},  # Kafka分区号
                        {"name": "__offset__", "type": "LONG", "comment": None, "nullable": False, "supportAsSplitKey": False, "properties": None, "primary": False, "sorted": False, "partitionColumn": False, "cluster": False},  # Kafka消息offset
                        {"name": "__timestamp__", "type": "LONG", "comment": None, "nullable": False, "supportAsSplitKey": False, "properties": None, "primary": False, "sorted": False, "partitionColumn": False, "cluster": False}  # Kafka消息时间戳
                    ]
                },
                "sink": {
                    "dataObject": None,  # 必填: Lakehouse目标表名
                    "namespace": None,  # 必填: Lakehouse schema名称(如public)
                    "params": {
                        "dsType": 1,  # 固定值: Lakehouse类型
                        "vclusterName": "DEFAULT",  # 可选修改: 虚拟集群名称
                        "writeMode": "OVERWRITE",  # 可选修改: 写入模式(APPEND追加/OVERWRITE覆盖)
                        "operatorType": "sink",  # 固定值: 目标操作类型
                        "table": None,  # 必填: 表名(与dataObject相同)
                        "database": None  # 必填: schema名称(与namespace相同)
                    },
                    "columns": [  # 固定值: Lakehouse中对应的列(类型已转换)
                        {"name": "__key__", "type": "string", "comment": "__key__", "nullable": False, "supportAsSplitKey": False, "properties": None, "primary": False, "sorted": False, "partitionColumn": False, "cluster": False},  # STRING→string
                        {"name": "__value__", "type": "string", "comment": "__value__", "nullable": False, "supportAsSplitKey": False, "properties": None, "primary": False, "sorted": False, "partitionColumn": False, "cluster": False},  # STRING→string
                        {"name": "__partition__", "type": "int", "comment": "__partition__", "nullable": False, "supportAsSplitKey": False, "properties": None, "primary": False, "sorted": False, "partitionColumn": False, "cluster": False},  # INTEGER→int
                        {"name": "__offset__", "type": "bigint", "comment": "__offset__", "nullable": False, "supportAsSplitKey": False, "properties": None, "primary": False, "sorted": False, "partitionColumn": False, "cluster": False},  # LONG→bigint
                        {"name": "__timestamp__", "type": "bigint", "comment": "__timestamp__", "nullable": False, "supportAsSplitKey": False, "properties": None, "primary": False, "sorted": False, "partitionColumn": False, "cluster": False}  # LONG→bigint
                    ]
                },
                "setting": {
                    "errorLimit": {"maxCount": 1},  # 可选修改: 最大错误数,-1表示无限制
                    "parallelism": 1  # 可选修改: 并行度,建议1-10
                },
                "columnMapping": {  # 固定值: Kafka系统列的同名映射
                    "__key__": "__key__",
                    "__value__": "__value__",
                    "__partition__": "__partition__",
                    "__offset__": "__offset__",
                    "__timestamp__": "__timestamp__"
                }
            }]
        },
        
        # OSS → Lakehouse
        "oss_to_lakehouse": {
            "_meta": {
                "description": "OSS对象存储到Lakehouse数据湖的集成模板",
                "source_type": 9,
                "source_name": "OSS",
                "sink_type": 1,
                "sink_name": "Lakehouse",
                "use_case": "从OSS/S3等对象存储读取文件(CSV/JSON/Parquet等)并导入到Lakehouse,用于批量数据导入、日志文件分析等场景",
                "required_fields": [
                    {"path": "sourceConnection.datasourceId", "type": "integer", "description": "源OSS数据源ID", "how_to_get": "调用list_data_sources工具,筛选type=9"},
                    {"path": "sourceConnection.datasourceName", "type": "string", "description": "源OSS数据源名称", "how_to_get": "从list_data_sources结果中获取"},
                    {"path": "sinkConnection.datasourceId", "type": "integer", "description": "目标Lakehouse数据源ID", "how_to_get": "调用list_data_sources工具,筛选type=1"},
                    {"path": "sinkConnection.datasourceName", "type": "string", "description": "目标Lakehouse数据源名称", "how_to_get": "从list_data_sources结果中获取"},
                    {"path": "source.dataObject", "type": "string", "description": "OSS文件路径", "how_to_get": "用户指定,如: folder/file.csv"},
                    {"path": "source.namespace", "type": "string", "description": "OSS bucket名称", "how_to_get": "用户指定或从get_namespace_list获取"},
                    {"path": "source.params.table", "type": "string", "description": "文件路径", "how_to_get": "与source.dataObject相同"},
                    {"path": "source.params.database", "type": "string", "description": "bucket名称", "how_to_get": "与source.namespace相同"},
                    {"path": "sink.dataObject", "type": "string", "description": "目标Lakehouse表名", "how_to_get": "用户指定,表必须已存在"},
                    {"path": "sink.namespace", "type": "string", "description": "目标Lakehouse schema名称", "how_to_get": "用户指定"},
                    {"path": "sink.params.table", "type": "string", "description": "目标表名", "how_to_get": "与sink.dataObject相同"},
                    {"path": "sink.params.database", "type": "string", "description": "目标schema名称", "how_to_get": "与sink.namespace相同"}
                ],
                "optional_fields": [
                    {"path": "source.params.codec", "type": "string", "default": "csv", "options": ["csv", "json", "parquet", "orc", "avro"], "description": "文件格式"},
                    {"path": "source.params.isFirstLineHeader", "type": "boolean", "default": False, "description": "CSV文件首行是否为列名"},
                    {"path": "source.params.isRecursive", "type": "boolean", "default": False, "description": "是否递归读取子目录"},
                    {"path": "source.params.encoding", "type": "string", "default": "utf-8", "options": ["utf-8", "gbk", "gb2312"], "description": "文件编码"},
                    {"path": "source.params.fieldDelimiter", "type": "string", "default": ",", "description": "CSV字段分隔符"},
                    {"path": "sink.params.vclusterName", "type": "string", "default": "DEFAULT", "description": "虚拟集群名称"},
                    {"path": "sink.params.writeMode", "type": "string", "default": "OVERWRITE", "options": ["APPEND", "OVERWRITE"], "description": "写入模式"},
                    {"path": "setting.parallelism", "type": "integer", "default": 1, "range": [1, 10], "description": "并行度"}
                ],
                "fixed_fields": [
                    {"path": "sourceConnection.type", "value": 9, "description": "OSS类型标识"},
                    {"path": "sinkConnection.type", "value": 1, "description": "Lakehouse类型标识"},
                    {"path": "source.params.dsType", "value": 9, "description": "源数据源类型"},
                    {"path": "source.params.operatorType", "value": "source", "description": "源操作类型"},
                    {"path": "sink.params.dsType", "value": 1, "description": "目标数据源类型"},
                    {"path": "sink.params.operatorType", "value": "source", "description": "目标操作类型(OSS特殊情况)"}
                ],
                "auto_generated_fields": [
                    {
                        "path": "source.columns",
                        "description": "OSS文件列结构(根据文件格式不同而不同)",
                        "generation_rule": "根据文件格式:\n1. CSV/JSON等无schema文件: 使用自动列名(__c0__, __c1__, __c2__, ...) + 系统列(__path__, __last_modified__)\n2. Parquet/ORC等有schema文件: 调用get_meta_detail API获取实际列名和类型\n3. 列数量: 根据实际文件内容确定\n4. 系统列始终包含: __path__(文件路径), __last_modified__(最后修改时间)",
                        "example_csv": [
                            {"name": "__c0__", "type": "BIGINT"},
                            {"name": "__c1__", "type": "BIGINT"},
                            {"name": "__c2__", "type": "STRING"},
                            {"name": "__c3__", "type": "BIGINT"},
                            {"name": "__c4__", "type": "BIGINT"},
                            {"name": "__path__", "type": "STRING"},
                            {"name": "__last_modified__", "type": "STRING"}
                        ],
                        "how_to_determine": "1. 如果codec为csv/json: 根据文件实际列数生成__c0__, __c1__等\n2. 如果codec为parquet/orc: 调用get_meta_detail(datasource_id, namespace, dataObject)获取\n3. 始终在末尾添加__path__和__last_modified__系统列"
                    },
                    {
                        "path": "sink.columns",
                        "description": "Lakehouse对应的列",
                        "generation_rule": "从source.columns映射,所有类型统一转为string类型(OSS特殊规则)"
                    },
                    {
                        "path": "columnMapping",
                        "description": "列名映射关系",
                        "generation_rule": "同名映射,包括所有数据列和系统列"
                    }
                ],
                "special_notes": [
                    "OSS文件列结构取决于文件格式:",
                    "  - CSV/JSON: 自动列(__c0__, __c1__, ...) + 系统列(__path__, __last_modified__)",
                    "  - Parquet/ORC: 实际列名 + 系统列(__path__, __last_modified__)",
                    "自动列命名规则: __c0__(第1列), __c1__(第2列), __c2__(第3列), 以此类推",
                    "系统列说明: __path__存储文件完整路径, __last_modified__存储文件最后修改时间",
                    "sink.params.operatorType为'source'(特殊情况,按实际demo)",
                    "所有列类型在sink中统一映射为string(包括数字、日期等)",
                    "如需获取Parquet/ORC的实际schema,调用get_meta_detail(datasource_id, namespace, dataObject)",
                    "目标表必须提前创建,且列结构需匹配(包括系统列)"
                ],
                "type_mappings": {
                    "BIGINT": "string",
                    "STRING": "string",
                    "INTEGER": "string",
                    "DOUBLE": "string",
                    "BOOLEAN": "string"
                }
            },
            "templateKey": 1,
            "userParams": {},
            "sourceConnection": {
                "datasourceId": None,  # 必填: OSS数据源ID
                "datasourceName": None,  # 必填: OSS数据源名称
                "type": 9  # 固定值: OSS类型
            },
            "sinkConnection": {
                "datasourceId": None,  # 必填: Lakehouse数据源ID
                "datasourceName": None,  # 必填: Lakehouse数据源名称
                "type": 1  # 固定值: Lakehouse类型
            },
            "jobs": [{
                "source": {
                    "dataObject": None,  # 必填: OSS文件路径(如: folder/file.csv)
                    "namespace": None,  # 必填: OSS bucket名称
                    "params": {
                        "dsType": 9,  # 固定值: OSS类型
                        "operatorType": "source",  # 固定值: 源操作类型
                        "codec": "csv",  # 可选修改: 文件格式(csv/json/parquet/orc)
                        "isFirstLineHeader": False,  # 可选修改: CSV首行是否为列名
                        "isRecursive": False,  # 可选修改: 是否递归读取子目录
                        "encoding": "utf-8",  # 可选修改: 文件编码
                        "fieldDelimiter": ",",  # 可选修改: CSV字段分隔符
                        "table": None,  # 必填: 文件路径(与dataObject相同)
                        "database": None  # 必填: bucket名称(与namespace相同)
                    },
                    "columns": []  # 需要动态填充: CSV/JSON用__c0__,__c1__等自动列名; Parquet/ORC从API获取实际列名; 末尾始终添加__path__,__last_modified__系统列
                },
                "sink": {
                    "dataObject": None,  # 必填: Lakehouse目标表名
                    "namespace": None,  # 必填: Lakehouse schema名称
                    "params": {
                        "dsType": 1,  # 固定值: Lakehouse类型
                        "vclusterName": "DEFAULT",  # 可选修改: 虚拟集群名称
                        "writeMode": "OVERWRITE",  # 可选修改: 写入模式(APPEND/OVERWRITE)
                        "operatorType": "source",  # 固定值: OSS特殊情况,使用"source"
                        "table": None,  # 必填: 表名(与dataObject相同)
                        "database": None  # 必填: schema名称(与namespace相同)
                    },
                    "columns": []  # 需要动态填充: 对应source.columns的每一列,所有类型统一映射为string(包括数字、日期等)
                },
                "setting": {
                    "errorLimit": {"maxCount": 1, "collectDirtyData": True, "record": 1},  # 可选修改: 错误处理配置
                    "parallelism": 1  # 可选修改: 并行度
                },
                "columnMapping": {}  # 需要动态填充: 列名映射关系
            }]
        },
        
        # MongoDB → Lakehouse
        "mongodb_to_lakehouse": {
            "_meta": {
                "description": "MongoDB文档数据库到Lakehouse数据湖的集成模板",
                "source_type": 12,
                "source_name": "MongoDB",
                "sink_type": 1,
                "sink_name": "Lakehouse",
                "use_case": "从MongoDB文档数据库导出数据到Lakehouse,用于NoSQL数据分析、数据备份、数据仓库构建等场景",
                "required_fields": [
                    {"path": "sourceConnection.datasourceId", "type": "integer", "description": "源MongoDB数据源ID", "how_to_get": "调用list_data_sources工具,筛选type=12"},
                    {"path": "sourceConnection.datasourceName", "type": "string", "description": "源MongoDB数据源名称", "how_to_get": "从list_data_sources结果中获取"},
                    {"path": "sinkConnection.datasourceId", "type": "integer", "description": "目标Lakehouse数据源ID", "how_to_get": "调用list_data_sources工具,筛选type=1"},
                    {"path": "sinkConnection.datasourceName", "type": "string", "description": "目标Lakehouse数据源名称", "how_to_get": "从list_data_sources结果中获取"},
                    {"path": "source.dataObject", "type": "string", "description": "MongoDB collection名称", "how_to_get": "用户指定或从get_meta_list获取"},
                    {"path": "source.namespace", "type": "string", "description": "MongoDB database名称", "how_to_get": "用户指定或从get_namespace_list获取"},
                    {"path": "source.params.table", "type": "string", "description": "collection名称", "how_to_get": "与source.dataObject相同"},
                    {"path": "source.params.database", "type": "string", "description": "database名称", "how_to_get": "与source.namespace相同"},
                    {"path": "sink.dataObject", "type": "string", "description": "目标Lakehouse表名", "how_to_get": "用户指定,表必须已存在"},
                    {"path": "sink.namespace", "type": "string", "description": "目标Lakehouse schema名称", "how_to_get": "用户指定"},
                    {"path": "sink.params.table", "type": "string", "description": "目标表名", "how_to_get": "与sink.dataObject相同"},
                    {"path": "sink.params.database", "type": "string", "description": "目标schema名称", "how_to_get": "与sink.namespace相同"}
                ],
                "optional_fields": [
                    {"path": "source.params.filter", "type": "string", "default": "", "description": "MongoDB查询过滤器(JSON格式),如: {\"age\": {\"$gt\": 18}}"},
                    {"path": "sink.params.vclusterName", "type": "string", "default": "DEFAULT", "description": "虚拟集群名称"},
                    {"path": "sink.params.writeMode", "type": "string", "default": "OVERWRITE", "options": ["APPEND", "OVERWRITE"], "description": "写入模式"},
                    {"path": "setting.parallelism", "type": "integer", "default": 1, "range": [1, 10], "description": "并行度"}
                ],
                "fixed_fields": [
                    {"path": "sourceConnection.type", "value": 12, "description": "MongoDB类型标识"},
                    {"path": "sinkConnection.type", "value": 1, "description": "Lakehouse类型标识"},
                    {"path": "source.params.dsType", "value": 12, "description": "源数据源类型"},
                    {"path": "source.params.operatorType", "value": "source", "description": "源操作类型"},
                    {"path": "sink.params.dsType", "value": 1, "description": "目标数据源类型"},
                    {"path": "sink.params.operatorType", "value": "sink", "description": "目标操作类型"}
                ],
                "auto_generated_fields": [
                    {"path": "source.columns", "description": "MongoDB collection字段", "generation_rule": "调用get_meta_detail获取collection结构"},
                    {"path": "sink.columns", "description": "Lakehouse对应的列", "generation_rule": "从source.columns映射,应用类型转换,添加helper:true"},
                    {"path": "columnMapping", "description": "列名映射关系", "generation_rule": "同名映射"}
                ],
                "special_notes": [
                    "MongoDB类型映射: String→string, Integer→int, Long→bigint, Double→double, Boolean→boolean",
                    "_id是MongoDB的系统字段,类型为String,必须包含",
                    "sink.columns中每个字段需要添加helper:true",
                    "filter参数支持MongoDB查询语法,留空表示全量导出",
                    "目标表必须提前创建"
                ],
                "type_mappings": {
                    "String": "string",
                    "Integer": "int",
                    "Long": "bigint",
                    "Double": "double",
                    "Boolean": "boolean"
                }
            },
            "templateKey": 1,
            "userParams": {},
            "sourceConnection": {
                "datasourceId": None,  # 必填: MongoDB数据源ID
                "datasourceName": None,  # 必填: MongoDB数据源名称
                "type": 12  # 固定值: MongoDB类型
            },
            "sinkConnection": {
                "datasourceId": None,  # 必填: Lakehouse数据源ID
                "datasourceName": None,  # 必填: Lakehouse数据源名称
                "type": 1  # 固定值: Lakehouse类型
            },
            "jobs": [{
                "source": {
                    "dataObject": None,  # 必填: MongoDB collection名称
                    "namespace": None,  # 必填: MongoDB database名称
                    "params": {
                        "dsType": 12,  # 固定值: MongoDB类型
                        "operatorType": "source",  # 固定值: 源操作类型
                        "filter": "",  # 可选修改: MongoDB查询过滤器(JSON格式),如: {"age": {"$gt": 18}}
                        "table": None,  # 必填: collection名称(与dataObject相同)
                        "database": None  # 必填: database名称(与namespace相同)
                    },
                    "columns": []  # 需要从API获取: 通过get_meta_detail获取collection字段
                },
                "sink": {
                    "dataObject": None,  # 必填: Lakehouse目标表名
                    "namespace": None,  # 必填: Lakehouse schema名称
                    "params": {
                        "dsType": 1,  # 固定值: Lakehouse类型
                        "vclusterName": "DEFAULT",  # 可选修改: 虚拟集群名称
                        "writeMode": "OVERWRITE",  # 可选修改: 写入模式(APPEND/OVERWRITE)
                        "operatorType": "sink",  # 固定值: 目标操作类型
                        "table": None,  # 必填: 表名(与dataObject相同)
                        "database": None  # 必填: schema名称(与namespace相同)
                    },
                    "columns": []  # 需要动态填充: 类型映射 + helper:true
                },
                "setting": {
                    "errorLimit": {"maxCount": 1, "collectDirtyData": True, "record": 1},  # 可选修改: 错误处理配置
                    "parallelism": 1  # 可选修改: 并行度
                },
                "columnMapping": {}  # 需要动态填充: 列名映射关系
            }]
        },
        
        # Lakehouse → Redis
        "lakehouse_to_redis": {
            "_meta": {
                "description": "Lakehouse数据湖到Redis缓存的集成模板",
                "source_type": 1,
                "source_name": "Lakehouse",
                "sink_type": 43,
                "sink_name": "Redis",
                "use_case": "从Lakehouse导出数据到Redis缓存,用于热数据加速、实时查询优化、缓存预热等场景",
                "required_fields": [
                    {"path": "sourceConnection.datasourceId", "type": "integer", "description": "源Lakehouse数据源ID", "how_to_get": "调用list_data_sources工具,筛选type=1"},
                    {"path": "sourceConnection.datasourceName", "type": "string", "description": "源Lakehouse数据源名称", "how_to_get": "从list_data_sources结果中获取"},
                    {"path": "sinkConnection.datasourceId", "type": "integer", "description": "目标Redis数据源ID", "how_to_get": "调用list_data_sources工具,筛选type=43"},
                    {"path": "sinkConnection.datasourceName", "type": "string", "description": "目标Redis数据源名称", "how_to_get": "从list_data_sources结果中获取"},
                    {"path": "source.dataObject", "type": "string", "description": "Lakehouse源表名", "how_to_get": "用户指定或从get_meta_list获取"},
                    {"path": "source.namespace", "type": "string", "description": "Lakehouse schema名称", "how_to_get": "用户指定或从get_namespace_list获取"},
                    {"path": "source.params.table", "type": "string", "description": "源表名", "how_to_get": "与source.dataObject相同"},
                    {"path": "source.params.database", "type": "string", "description": "源schema名称", "how_to_get": "与source.namespace相同"},
                    {"path": "sink.params.keyColumns", "type": "array", "description": "用于构建Redis key的列名数组", "how_to_get": "用户指定,如: [\"user_id\", \"dt\"]"}
                ],
                "optional_fields": [
                    {"path": "source.params.partitions", "type": "string", "default": None, "description": "分区过滤条件,如: dt='2024-01-01'"},
                    {"path": "sink.params.dbNum", "type": "integer", "default": 0, "range": [0, 15], "description": "Redis数据库编号"},
                    {"path": "sink.params.redisOpType", "type": "string", "default": "hash", "options": ["hash", "string", "set", "zset", "list"], "description": "Redis操作类型"},
                    {"path": "sink.params.expireTime", "type": "integer", "default": -1, "description": "过期时间(秒),-1表示永不过期"},
                    {"path": "sink.params.keyDelimiter", "type": "string", "default": "_", "description": "Redis key分隔符"},
                    {"path": "sink.params.batchSize", "type": "integer", "default": 1000, "range": [100, 10000], "description": "批量写入大小"},
                    {"path": "sink.params.virtualColumns", "type": "array", "default": [{"key": "test", "value": "123"}], "description": "虚拟列,添加额外字段"},
                    {"path": "setting.parallelism", "type": "integer", "default": 1, "range": [1, 10], "description": "并行度"}
                ],
                "fixed_fields": [
                    {"path": "sourceConnection.type", "value": 1, "description": "Lakehouse类型标识"},
                    {"path": "sinkConnection.type", "value": 43, "description": "Redis类型标识"},
                    {"path": "source.params.dsType", "value": 1, "description": "源数据源类型"},
                    {"path": "source.params.operatorType", "value": "source", "description": "源操作类型"},
                    {"path": "sink.dataObject", "value": "", "description": "Redis不使用dataObject"},
                    {"path": "sink.namespace", "value": "", "description": "Redis不使用namespace"},
                    {"path": "sink.params.dsType", "value": 43, "description": "目标数据源类型"},
                    {"path": "sink.params.operatorType", "value": "sink", "description": "目标操作类型"},
                    {"path": "sink.params.table", "value": "", "description": "Redis不使用table"},
                    {"path": "sink.params.database", "value": "", "description": "Redis不使用database"},
                    {"path": "sink.params.is_partition", "value": False, "description": "Redis不支持分区"}
                ],
                "auto_generated_fields": [
                    {"path": "source.columns", "description": "Lakehouse表字段", "generation_rule": "调用get_meta_detail获取表结构"},
                    {"path": "sink.columns", "description": "Redis对应的列", "generation_rule": "从source.columns映射,应用类型转换,添加nullable:true, supportAsSplitKey:true, helper:true"},
                    {"path": "columnMapping", "description": "列名映射关系", "generation_rule": "同名映射"}
                ],
                "special_notes": [
                    "Redis不使用table/database概念,sink.dataObject和sink.namespace为空字符串",
                    "keyColumns非常重要,用于构建Redis key,格式: key1_key2_key3",
                    "类型映射: int→INT, string→STRING, bigint→LONG, double→DOUBLE, float→FLOAT",
                    "virtualColumns可以添加额外的元数据字段",
                    "sink.columns中每个字段需要: nullable:true, supportAsSplitKey:true, helper:true",
                    "keyColumns中的列必须在source.columns中存在"
                ],
                "type_mappings": {
                    "int": "INT",
                    "bigint": "LONG",
                    "string": "STRING",
                    "double": "DOUBLE",
                    "float": "FLOAT",
                    "boolean": "BOOLEAN",
                    "date": "STRING",
                    "timestamp_ltz": "STRING"
                }
            },
            "templateKey": 1,
            "userParams": {},
            "sourceConnection": {
                "datasourceId": None,  # 必填: Lakehouse数据源ID
                "datasourceName": None,  # 必填: Lakehouse数据源名称
                "type": 1  # 固定值: Lakehouse类型
            },
            "sinkConnection": {
                "datasourceId": None,  # 必填: Redis数据源ID
                "datasourceName": None,  # 必填: Redis数据源名称
                "type": 43  # 固定值: Redis类型
            },
            "jobs": [{
                "source": {
                    "dataObject": None,  # 必填: Lakehouse源表名
                    "namespace": None,  # 必填: Lakehouse schema名称
                    "params": {
                        "partitions": None,  # 可选修改: 分区过滤条件,如: dt='2024-01-01'
                        "dsType": 1,  # 固定值: Lakehouse类型
                        "operatorType": "source",  # 固定值: 源操作类型
                        "table": None,  # 必填: 表名(与dataObject相同)
                        "database": None  # 必填: schema名称(与namespace相同)
                    },
                    "columns": []  # 需要从API获取: 通过get_meta_detail获取表字段
                },
                "sink": {
                    "dataObject": "",  # 固定值: Redis不使用dataObject
                    "namespace": "",  # 固定值: Redis不使用namespace
                    "params": {
                        "dbNum": 0,  # 可选修改: Redis数据库编号(0-15)
                        "redisOpType": "hash",  # 可选修改: Redis操作类型(hash/string/set/zset/list)
                        "expireTime": -1,  # 可选修改: 过期时间(秒),-1表示永不过期
                        "keyDelimiter": "_",  # 可选修改: Redis key分隔符
                        "batchSize": 1000,  # 可选修改: 批量写入大小
                        "dsType": 43,  # 固定值: Redis类型
                        "operatorType": "sink",  # 固定值: 目标操作类型
                        "table": "",  # 固定值: Redis不使用table
                        "database": "",  # 固定值: Redis不使用database
                        "is_partition": False,  # 固定值: Redis不支持分区
                        "virtualColumns": [{"key": "test", "value": "123"}],  # 可选修改: 虚拟列,添加额外字段
                        "keyColumns": []  # 必填: 用于构建Redis key的列名数组,如: ["user_id", "dt"]
                    },
                    "columns": []  # 需要动态填充: 类型映射 + nullable:true + supportAsSplitKey:true + helper:true
                },
                "setting": {
                    "parallelism": 1,  # 可选修改: 并行度
                    "errorLimit": {"maxCount": -1, "collectDirtyData": True, "record": -1}  # 可选修改: 错误处理配置
                },
                "columnMapping": {}  # 需要动态填充: 列名映射关系
            }]
        },
        
        # Hive → Lakehouse
        "hive_to_lakehouse": {
            "_meta": {
                "description": "Hive数据仓库到Lakehouse数据湖的集成模板",
                "source_type": 3,
                "source_name": "Hive",
                "sink_type": 1,
                "sink_name": "Lakehouse",
                "use_case": "从Hive数据仓库迁移数据到Lakehouse,用于数据湖构建、仓库升级、跨平台数据同步等场景",
                "required_fields": [
                    {"path": "sourceConnection.datasourceId", "type": "integer", "description": "源Hive数据源ID", "how_to_get": "调用list_data_sources工具,筛选type=3"},
                    {"path": "sourceConnection.datasourceName", "type": "string", "description": "源Hive数据源名称", "how_to_get": "从list_data_sources结果中获取"},
                    {"path": "sinkConnection.datasourceId", "type": "integer", "description": "目标Lakehouse数据源ID", "how_to_get": "调用list_data_sources工具,筛选type=1"},
                    {"path": "sinkConnection.datasourceName", "type": "string", "description": "目标Lakehouse数据源名称", "how_to_get": "从list_data_sources结果中获取"},
                    {"path": "source.dataObject", "type": "string", "description": "Hive表名", "how_to_get": "用户指定或从get_meta_list获取"},
                    {"path": "source.namespace", "type": "string", "description": "Hive数据库名称", "how_to_get": "用户指定或从get_namespace_list获取"},
                    {"path": "sink.dataObject", "type": "string", "description": "目标Lakehouse表名", "how_to_get": "用户指定,表必须已存在"},
                    {"path": "sink.namespace", "type": "string", "description": "目标Lakehouse schema名称", "how_to_get": "用户指定"}
                ],
                "optional_fields": [
                    {"path": "source.params.partitions", "type": "string", "default": None, "description": "分区过滤条件,如: dt='2024-01-01'"},
                    {"path": "sink.params.vclusterName", "type": "string", "default": "default", "description": "虚拟集群名称(注意小写)"},
                    {"path": "sink.params.writeMode", "type": "string", "default": "OVERWRITE", "options": ["APPEND", "OVERWRITE"], "description": "写入模式"},
                    {"path": "setting.parallelism", "type": "integer", "default": 1, "range": [1, 10], "description": "并行度"}
                ],
                "fixed_fields": [
                    {"path": "sourceConnection.type", "value": 3, "description": "Hive类型标识"},
                    {"path": "sinkConnection.type", "value": 1, "description": "Lakehouse类型标识"},
                    {"path": "source.params.dsType", "value": 3, "description": "源数据源类型"},
                    {"path": "source.params.operatorType", "value": "source", "description": "源操作类型"},
                    {"path": "sink.params.dsType", "value": 1, "description": "目标数据源类型"},
                    {"path": "sink.params.operatorType", "value": "sink", "description": "目标操作类型"}
                ],
                "auto_generated_fields": [
                    {"path": "source.columns", "description": "Hive表字段", "generation_rule": "调用get_meta_detail获取表结构"},
                    {"path": "sink.columns", "description": "Lakehouse对应的列", "generation_rule": "从source.columns映射,类型通常一致,添加helper:true"},
                    {"path": "columnMapping", "description": "列名映射关系", "generation_rule": "同名映射"}
                ],
                "special_notes": [
                    "Hive的source.params中不包含table和database字段(与其他数据源不同)",
                    "表名和数据库名只在dataObject和namespace中指定",
                    "Hive和Lakehouse的类型系统基本一致,通常无需类型转换",
                    "sink.params中也不包含table和database字段",
                    "vclusterName默认为'default'(小写)",
                    "目标表必须提前创建"
                ],
                "type_mappings": {
                    "int": "int",
                    "bigint": "bigint",
                    "string": "string",
                    "double": "double",
                    "float": "float",
                    "boolean": "boolean",
                    "date": "date",
                    "timestamp": "timestamp_ltz"
                }
            },
            "templateKey": 1,
            "userParams": {},
            "sourceConnection": {
                "datasourceId": None,  # 必填: Hive数据源ID
                "datasourceName": None,  # 必填: Hive数据源名称
                "type": 3  # 固定值: Hive类型
            },
            "sinkConnection": {
                "datasourceId": None,  # 必填: Lakehouse数据源ID
                "datasourceName": None,  # 必填: Lakehouse数据源名称
                "type": 1  # 固定值: Lakehouse类型
            },
            "jobs": [{
                "source": {
                    "dataObject": None,  # 必填: Hive表名
                    "namespace": None,  # 必填: Hive数据库名称
                    "params": {
                        "dsType": 3,  # 固定值: Hive类型
                        "partitions": None,  # 可选修改: 分区过滤条件,如: dt='2024-01-01'
                        "operatorType": "source"  # 固定值: 源操作类型
                        # 注意: Hive的params中不包含table和database字段
                    },
                    "columns": []  # 需要从API获取: 通过get_meta_detail获取Hive表字段
                },
                "sink": {
                    "dataObject": None,  # 必填: Lakehouse目标表名
                    "namespace": None,  # 必填: Lakehouse schema名称
                    "params": {
                        "dsType": 1,  # 固定值: Lakehouse类型
                        "vclusterName": "default",  # 可选修改: 虚拟集群名称(注意小写)
                        "writeMode": "OVERWRITE",  # 可选修改: 写入模式(APPEND/OVERWRITE)
                        "operatorType": "sink"  # 固定值: 目标操作类型
                        # 注意: Hive sink的params中也不包含table和database字段
                    },
                    "columns": []  # 需要动态填充: Hive和Lakehouse类型通常一致 + helper:true
                },
                "setting": {
                    "errorLimit": {"maxCount": -1},  # 可选修改: 最大错误数,-1表示无限制
                    "parallelism": 1  # 可选修改: 并行度
                },
                "columnMapping": {}  # 需要动态填充: 列名映射关系
            }]
        },
        
        # MySQL → Lakehouse (关系型数据库通用)
        "relational_to_lakehouse": {
            "_meta": {
                "description": "关系型数据库(MySQL/PostgreSQL/Oracle等)到Lakehouse数据湖的集成模板",
                "source_type": None,  # 动态设置: 5=MySQL, 7=PostgreSQL, 8=SQLServer, 17=Oracle等
                "source_name": "Relational DB",
                "sink_type": 1,
                "sink_name": "Lakehouse",
                "use_case": "从关系型数据库导出数据到Lakehouse,用于数据湖构建、离线分析、数据备份等场景。支持MySQL, PostgreSQL, Oracle, SQL Server等所有关系型数据库",
                "required_fields": [
                    {"path": "sourceConnection.datasourceId", "type": "integer", "description": "源数据库数据源ID", "how_to_get": "调用list_data_sources工具,筛选相应type"},
                    {"path": "sourceConnection.datasourceName", "type": "string", "description": "源数据库数据源名称", "how_to_get": "从list_data_sources结果中获取"},
                    {"path": "sourceConnection.type", "type": "integer", "description": "数据源类型", "how_to_get": "5=MySQL, 7=PostgreSQL, 8=SQLServer, 17=Oracle等"},
                    {"path": "sinkConnection.datasourceId", "type": "integer", "description": "目标Lakehouse数据源ID", "how_to_get": "调用list_data_sources工具,筛选type=1"},
                    {"path": "sinkConnection.datasourceName", "type": "string", "description": "目标Lakehouse数据源名称", "how_to_get": "从list_data_sources结果中获取"},
                    {"path": "source.dataObject", "type": "string", "description": "源表名", "how_to_get": "用户指定或从get_meta_list获取"},
                    {"path": "source.namespace", "type": "string", "description": "源数据库schema/database名称", "how_to_get": "用户指定或从get_namespace_list获取"},
                    {"path": "source.params.dsType", "type": "integer", "description": "数据源类型", "how_to_get": "与sourceConnection.type相同"},
                    {"path": "source.params.table", "type": "string", "description": "表名", "how_to_get": "与source.dataObject相同"},
                    {"path": "source.params.database", "type": "string", "description": "schema名称", "how_to_get": "与source.namespace相同"},
                    {"path": "sink.dataObject", "type": "string", "description": "目标Lakehouse表名", "how_to_get": "用户指定,表必须已存在"},
                    {"path": "sink.namespace", "type": "string", "description": "目标Lakehouse schema名称", "how_to_get": "用户指定"},
                    {"path": "sink.params.table", "type": "string", "description": "目标表名", "how_to_get": "与sink.dataObject相同"},
                    {"path": "sink.params.database", "type": "string", "description": "目标schema名称", "how_to_get": "与sink.namespace相同"}
                ],
                "optional_fields": [
                    {"path": "sink.params.writeMode", "type": "string", "default": "OVERWRITE", "options": ["APPEND", "OVERWRITE"], "description": "写入模式"},
                    {"path": "sink.params.is_partition", "type": "boolean", "default": False, "description": "目标表是否分区表"},
                    {"path": "setting.parallelism", "type": "integer", "default": 1, "range": [1, 10], "description": "并行度"}
                ],
                "fixed_fields": [
                    {"path": "sinkConnection.type", "value": 1, "description": "Lakehouse类型标识"},
                    {"path": "source.params.operatorType", "value": "source", "description": "源操作类型"},
                    {"path": "sink.params.dsType", "value": 1, "description": "目标数据源类型"},
                    {"path": "sink.params.operatorType", "value": "sink", "description": "目标操作类型"}
                ],
                "auto_generated_fields": [
                    {"path": "source.columns", "description": "源表字段", "generation_rule": "调用get_meta_detail获取表结构,包含完整字段信息"},
                    {"path": "sink.columns", "description": "Lakehouse对应的列", "generation_rule": "从source.columns映射,应用类型转换(INT→int, VARCHAR→string, DATE→date等)"},
                    {"path": "columnMapping", "description": "列名映射关系", "generation_rule": "同名映射"}
                ],
                "special_notes": [
                    "适用于所有关系型数据库: MySQL(5), PostgreSQL(7), Oracle(17), SQL Server(8)等",
                    "类型映射: INT→int, BIGINT→bigint, VARCHAR→string, DATE→date, DATETIME→timestamp_ltz",
                    "source.columns包含完整字段: physicalType, supportAsSplitKey, properties, sorted, cluster等",
                    "sink.columns中supportAsSplitKey通常为false",
                    "主键信息会保留在primary字段中",
                    "目标表必须提前创建"
                ],
                "type_mappings": {
                    "INT": "int",
                    "INTEGER": "int",
                    "BIGINT": "bigint",
                    "SMALLINT": "smallint",
                    "TINYINT": "tinyint",
                    "VARCHAR": "string",
                    "CHAR": "string",
                    "TEXT": "string",
                    "DATE": "date",
                    "DATETIME": "timestamp_ltz",
                    "TIMESTAMP": "timestamp_ltz",
                    "DOUBLE": "double",
                    "FLOAT": "float",
                    "DECIMAL": "decimal",
                    "BOOLEAN": "boolean"
                }
            },
            "templateKey": 1,
            "userParams": {},
            "sourceConnection": {
                "datasourceId": None,  # 必填: 源数据库数据源ID
                "datasourceName": None,  # 必填: 源数据库数据源名称
                "type": None  # 必填: 数据源类型(5=MySQL, 7=PostgreSQL, 8=SQLServer, 17=Oracle等)
            },
            "sinkConnection": {
                "datasourceId": None,  # 必填: Lakehouse数据源ID
                "datasourceName": None,  # 必填: Lakehouse数据源名称
                "type": 1  # 固定值: Lakehouse类型
            },
            "jobs": [{
                "source": {
                    "dataObject": None,  # 必填: 源表名
                    "namespace": None,  # 必填: 源数据库schema/database名称
                    "params": {
                        "dsType": None,  # 必填: 数据源类型(与sourceConnection.type相同)
                        "operatorType": "source",  # 固定值: 源操作类型
                        "table": None,  # 必填: 表名(与dataObject相同)
                        "database": None  # 必填: schema名称(与namespace相同)
                    },
                    "columns": []  # 需要从API获取: 通过get_meta_detail获取表字段
                },
                "sink": {
                    "dataObject": None,  # 必填: Lakehouse目标表名
                    "namespace": None,  # 必填: Lakehouse schema名称
                    "params": {
                        "dsType": 1,  # 固定值: Lakehouse类型
                        "writeMode": "OVERWRITE",  # 可选修改: 写入模式(APPEND追加/OVERWRITE覆盖)
                        "operatorType": "sink",  # 固定值: 目标操作类型
                        "table": None,  # 必填: 表名(与dataObject相同)
                        "database": None,  # 必填: schema名称(与namespace相同)
                        "is_partition": False  # 可选修改: 目标表是否为分区表
                    },
                    "columns": []  # 需要动态填充: 类型映射(INT→int, VARCHAR→string等)
                },
                "setting": {
                    "parallelism": 1,  # 可选修改: 并行度,建议1-10
                    "errorLimit": {"maxCount": -1, "collectDirtyData": True, "record": -1}  # 可选修改: 错误处理配置
                },
                "columnMapping": {}  # 需要动态填充: 列名映射关系
            }]
        }
    }
    
    # 类型映射规则 (增强版 - 基于完整数据源映射文档)
    TYPE_MAPPINGS = {
        # 到 Lakehouse 的类型映射
        "to_lakehouse": {
            # ===== 字符串类型 → STRING =====
            "VARCHAR": "string", "CHAR": "string", "TEXT": "string", "STRING": "string",
            "NVARCHAR": "string", "NCHAR": "string", "NTEXT": "string",
            "CLOB": "string", "NCLOB": "string", "LONGTEXT": "string", 
            "MEDIUMTEXT": "string", "TINYTEXT": "string", "BPCHAR": "string",
            "VARCHAR2": "string", "CHARACTER VARYING": "string", "CHARACTER": "string",
            "NAME": "string", "LONGVARCHAR": "string",
            
            # ===== 整数类型 =====
            "TINYINT": "tinyint", "INT8": "tinyint", "BYTE": "tinyint",
            "SMALLINT": "smallint", "INT16": "smallint", "INT2": "smallint", "SHORT": "smallint",
            "SMALLSERIAL": "smallint",
            "INT": "int", "INTEGER": "int", "INT32": "int", "INT4": "int", 
            "SERIAL": "int", "MEDIUMINT": "int",
            "BIGINT": "bigint", "INT64": "bigint", "INT8": "bigint", "LONG": "bigint",
            "BIGSERIAL": "bigint", "OID": "bigint",
            
            # ===== MySQL UNSIGNED类型(升级一级) =====
            "TINYINT UNSIGNED": "smallint", "TINYINT UNSIGNED ZEROFILL": "smallint",
            "SMALLINT UNSIGNED": "int", "SMALLINT UNSIGNED ZEROFILL": "int",
            "MEDIUMINT UNSIGNED": "bigint", "MEDIUMINT UNSIGNED ZEROFILL": "bigint",
            "INT UNSIGNED": "bigint", "INT UNSIGNED ZEROFILL": "bigint",
            "INTEGER UNSIGNED": "bigint", "INTEGER UNSIGNED ZEROFILL": "bigint",
            "BIGINT UNSIGNED": "decimal", "BIGINT UNSIGNED ZEROFILL": "decimal",
            "SERIAL": "decimal",  # MySQL SERIAL = BIGINT UNSIGNED
            
            # ===== ClickHouse超大整数 → DECIMAL =====
            "Int128": "decimal", "Int256": "decimal", 
            "UInt64": "decimal", "UInt128": "decimal", "UInt256": "decimal",
            "UINT32": "bigint", "UINT64": "decimal", "UINT8": "smallint", "UINT16": "int",
            
            # ===== 小数类型 =====
            "FLOAT": "float", "FLOAT4": "float", "FLOAT32": "float", "REAL": "float",
            "FLOAT UNSIGNED": "float", "FLOAT UNSIGNED ZEROFILL": "float",
            "DOUBLE": "double", "DOUBLE PRECISION": "double", "FLOAT8": "double", "FLOAT64": "double",
            "DOUBLE UNSIGNED": "double", "DOUBLE UNSIGNED ZEROFILL": "double",
            "REAL UNSIGNED": "double", "REAL UNSIGNED ZEROFILL": "double",
            "DECIMAL": "decimal", "NUMERIC": "decimal", "DEC": "decimal", "NUMBER": "decimal",
            "MONEY": "decimal", "SMALLMONEY": "decimal", "DECFLOAT": "decimal",
            "DECIMAL32": "decimal", "DECIMAL64": "decimal", "DECIMAL128": "decimal",
            "DECIMALV2": "decimal", "DECIMAL UNSIGNED": "decimal",
            
            # ===== 布尔类型 =====
            "BOOLEAN": "boolean", "BOOL": "boolean", "BIT": "boolean",
            
            # ===== 时间类型 =====
            "DATE": "date",
            "TIME": "time", "TIMEZ": "time",
            "TIMESTAMP": "timestamp_ltz", "DATETIME": "timestamp_ltz", 
            "TIMESTAMPTZ": "timestamp_ltz", "TIMESTAMP WITH TIME ZONE": "timestamp_ltz",
            "DATETIME2": "timestamp_ltz", "SMALLDATETIME": "timestamp_ltz",
            
            # ===== 二进制类型 =====
            "BINARY": "binary", "VARBINARY": "binary", "BLOB": "binary", "BYTEA": "binary",
            "LONGBLOB": "binary", "MEDIUMBLOB": "binary", "TINYBLOB": "binary",
            "IMAGE": "binary", "GEOMETRY": "binary", "LONG RAW": "binary", "RAW": "binary",
            "BITMAP": "binary", "BINDATA": "binary", "BYTES": "binary",
            
            # ===== JSON类型(MySQL原生支持) =====
            "JSON": "json",
            
            # ===== PostgreSQL特殊类型 → STRING =====
            "UUID": "string", "INET": "string", "CIDR": "string",
            "MACADDR": "string", "MACADDR8": "string", "XML": "string",
            "JSONB": "string", "JSONPATH": "string",
            "INTERVAL": "string", "BIT VARYING": "string", "VARBIT": "string",
            "POINT": "string", "LINE": "string", "LSEG": "string", "BOX": "string",
            "PATH": "string", "POLYGON": "string", "CIRCLE": "string",
            "TSQUERY": "string", "TSVECTOR": "string",
            "TSRANGE": "string", "INT4RANGE": "string", "INT8RANGE": "string",
            "NUMRANGE": "string", "TSTZRANGE": "string", "DATERANGE": "string",
            
            # ===== MongoDB/NoSQL类型 =====
            "String": "string", "OBJECTID": "string", "DOCUMENT": "string",
            "Integer": "int", "Long": "bigint", "Double": "double", "Boolean": "boolean",
            
            # ===== ClickHouse特殊类型 =====
            "FIXEDSTRING": "string", "ENUM8": "string", "ENUM16": "string",
            "NESTED": "string", "STRUCT": "string", "COLLECTION": "string",
            "INTERVALYEAR": "int", "INTERVALQUARTER": "int", "INTERVALMONTH": "int",
            "INTERVALWEEK": "int", "INTERVALDAY": "int", "INTERVALHOUR": "int",
            "INTERVALMINUTE": "int", "INTERVALSECOND": "int",
            
            # ===== Doris/StarRocks特殊类型 =====
            "LARGEINT": "string", "HLL": "binary", "SET": "string", "ENUM": "string",
            "INT24": "int",
            
            # ===== Oracle特殊类型 =====
            "BINARY_FLOAT": "float", "BINARY_DOUBLE": "double",
            
            # ===== SQLServer特殊类型 =====
            "UNIQUEIDENTIFIER": "string", "INT IDENTITY": "int",
            
            # ===== Elasticsearch类型 =====
            "OBJECT": "string", "NESTED": "string",
            
            # ===== Kafka/消息队列 =====
            "UNIXTIME_MICROS": "bigint", "TIMESTAMP_LTZ": "timestamp_ltz",
            
            # ===== 通用降级规则(未明确列出的复杂类型) =====
            "ARRAY": "string", "MAP": "string", "ROW": "string"
        },
        
        # 从 Lakehouse 到其他系统
        "from_lakehouse": {
            # Lakehouse → Redis
            "int": "INT",
            "bigint": "LONG",
            "string": "STRING",
            "double": "DOUBLE",
            "float": "FLOAT",
            "boolean": "BOOLEAN",
            "date": "STRING",
            "timestamp_ltz": "STRING",
            "timestamp": "STRING",
            "tinyint": "INT",
            "smallint": "INT",
            "decimal": "STRING"
        }
    }
    
    @classmethod
    def get_template_key(cls, source_type: int, sink_type: int) -> str:
        """Get template key based on source and sink types"""
        # Kafka → Lakehouse
        if source_type == 2 and sink_type == 1:
            return "kafka_to_lakehouse"
        
        # OSS → Lakehouse
        if source_type == 9 and sink_type == 1:
            return "oss_to_lakehouse"
        
        # MongoDB → Lakehouse
        if source_type == 12 and sink_type == 1:
            return "mongodb_to_lakehouse"
        
        # Hive → Lakehouse
        if source_type == 3 and sink_type == 1:
            return "hive_to_lakehouse"
        
        # Lakehouse → Redis
        if source_type == 1 and sink_type == 43:
            return "lakehouse_to_redis"
        
        # Relational DB → Lakehouse
        if source_type in cls.RELATIONAL_DB and sink_type == 1:
            return "relational_to_lakehouse"
        
        # 默认使用关系型数据库模板
        return "relational_to_lakehouse"
    
    @classmethod
    def get_template(cls, template_key: str) -> Dict[str, Any]:
        """
        Get template by key, returns a deep copy.
        
        The returned template includes:
        - _meta: Metadata for LLM understanding (structured information)
        - templateKey, userParams, sourceConnection, sinkConnection, jobs: Actual template structure
        
        LLM should:
        1. Read _meta to understand the template
        2. Use _meta.required_fields to know what must be filled
        3. Use _meta.optional_fields to know what can be customized
        4. Use _meta.fixed_fields to know what should not be changed
        5. Fill the actual template fields (templateKey, sourceConnection, etc.)
        6. Remove _meta before passing to save_integration_task
        """
        if template_key not in cls.TEMPLATES:
            raise ValueError(f"Unknown template key: {template_key}")
        return copy.deepcopy(cls.TEMPLATES[template_key])
    
    @classmethod
    def get_template_metadata(cls, template_key: str) -> Dict[str, Any]:
        """
        Get only the metadata (_meta) of a template for LLM understanding.
        
        This is useful when LLM needs to understand the template structure
        without loading the entire template.
        
        Returns:
            Dictionary containing:
            - description: What this template is for
            - source_type, source_name: Source datasource info
            - sink_type, sink_name: Sink datasource info
            - use_case: When to use this template
            - required_fields: List of fields that must be filled
            - optional_fields: List of fields that can be customized
            - fixed_fields: List of fields that should not be changed
            - auto_generated_fields: List of fields that will be auto-generated
            - special_notes: Important notes for LLM
            - type_mappings: Column type conversion rules
            - fill_instructions: Human-readable instructions
        """
        if template_key not in cls.TEMPLATES:
            raise ValueError(f"Unknown template key: {template_key}")
        
        template = cls.TEMPLATES[template_key]
        
        # For templates with _meta
        if "_meta" in template:
            return copy.deepcopy(template["_meta"])
        
        # For templates with old structure (_description, _fill_instructions, _notes)
        # Convert to _meta format
        meta = {}
        if "_description" in template:
            meta["description"] = template["_description"]
        if "_fill_instructions" in template:
            meta["fill_instructions"] = template["_fill_instructions"]
        if "_notes" in template:
            meta["human_notes"] = template["_notes"]
        
        return meta
    
    @classmethod
    def get_template_structure(cls, template_key: str) -> Dict[str, Any]:
        """
        Get only the actual template structure (without _meta).
        
        This returns the clean template that should be filled and passed to save_integration_task.
        All metadata fields (_meta, _description, _fill_instructions, _notes) are removed.
        
        Returns:
            Clean template with only: templateKey, userParams, sourceConnection, sinkConnection, jobs
        """
        if template_key not in cls.TEMPLATES:
            raise ValueError(f"Unknown template key: {template_key}")
        
        template = copy.deepcopy(cls.TEMPLATES[template_key])
        
        # Remove all metadata fields
        template.pop("_meta", None)
        template.pop("_description", None)
        template.pop("_fill_instructions", None)
        template.pop("_notes", None)
        template.pop("_metadata", None)
        
        return template
    
    @classmethod
    def map_column_type(cls, source_type: str, source_ds_type: int, sink_ds_type: int) -> str:
        """
        Map column type from source to sink with enhanced type conversion.
        
        Args:
            source_type: Source column type (e.g., "VARCHAR", "INT UNSIGNED", "BIGINT")
            source_ds_type: Source datasource type ID
            sink_ds_type: Sink datasource type ID
            
        Returns:
            Mapped type for sink datasource
        """
        if not source_type:
            return "string"  # Default fallback
        
        # Lakehouse → Redis
        if source_ds_type == 1 and sink_ds_type == 43:
            return cls.TYPE_MAPPINGS["from_lakehouse"].get(source_type.lower(), source_type.upper())
        
        # Others → Lakehouse
        if sink_ds_type == 1:
            # Try exact match first (preserves case-sensitive types like MongoDB "String")
            mapped_type = cls.TYPE_MAPPINGS["to_lakehouse"].get(source_type)
            if mapped_type:
                return mapped_type
            
            # Try uppercase match (most SQL types are uppercase)
            mapped_type = cls.TYPE_MAPPINGS["to_lakehouse"].get(source_type.upper())
            if mapped_type:
                return mapped_type
            
            # Try lowercase match
            mapped_type = cls.TYPE_MAPPINGS["to_lakehouse"].get(source_type.lower())
            if mapped_type:
                return mapped_type
            
            # For unknown types, apply safe defaults based on common patterns
            source_upper = source_type.upper()
            if "CHAR" in source_upper or "TEXT" in source_upper or "STRING" in source_upper:
                return "string"
            elif "INT" in source_upper:
                if "TINY" in source_upper:
                    return "tinyint"
                elif "SMALL" in source_upper:
                    return "smallint"
                elif "BIG" in source_upper:
                    return "bigint"
                else:
                    return "int"
            elif "FLOAT" in source_upper or "REAL" in source_upper:
                return "float"
            elif "DOUBLE" in source_upper:
                return "double"
            elif "DECIMAL" in source_upper or "NUMERIC" in source_upper or "NUMBER" in source_upper:
                return "decimal"
            elif "BOOL" in source_upper:
                return "boolean"
            elif "DATE" in source_upper:
                if "TIME" in source_upper:
                    return "timestamp_ltz"
                else:
                    return "date"
            elif "TIME" in source_upper:
                if "STAMP" in source_upper:
                    return "timestamp_ltz"
                else:
                    return "time"
            elif "BINARY" in source_upper or "BLOB" in source_upper or "BYTE" in source_upper:
                return "binary"
            
            # Ultimate fallback: convert to lowercase (safe default for Lakehouse)
            return source_type.lower()
        
        # Default: keep as is for non-Lakehouse targets
        return source_type
