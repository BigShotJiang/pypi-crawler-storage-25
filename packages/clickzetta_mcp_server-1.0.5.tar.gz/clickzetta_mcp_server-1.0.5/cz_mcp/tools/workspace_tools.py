"""
Workspace tools for MCP Studio server
Handles workspace listing and management
"""
import json
import logging
import warnings
from typing import List, Any, Coroutine

from mcp.types import TextContent, EmbeddedResource

from cz_mcp.handlers.ide_admin_server import list_user_workspaces
from ..common.utilities import ResponseBuilder
from ..core.tool_registry import Tool
from ..studio_config_manager import StudioConfig

from loguru import logger


async def handle_list_user_workspaces(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    List all user workspaces in Clickzetta Studio (no pagination support)
    """
    if arguments is None:
        arguments = {}

    try:
        # Get auth context from server core
        config = studio_config

        logger.info(f"Listing all workspaces for user")

        # Call the API with fixed pageSize=99999 to get all workspaces
        # (user info retrieval is now handled inside list_user_workspaces)
        page_size = 20
        workspace_name = arguments.get("workspace_pattern")
        response = list_user_workspaces(
            page_index=1,
            page_size=page_size,
            jwt_token=config.token,
            instance_name=config.instance,
            instance_id=config.instance_id,
            user_id=config.user_id,
            tenant_id=config.tenant_id,
            env=config.env,
            workspace_name=workspace_name
        )

        # Parse and format the response
        response_data = json.loads(response)

        if response_data.get("code") == "200":
            # data is a list of workspaces; capture full count before limiting to 20
            max_results = page_size
            all_workspaces = response_data.get("data", [])
            total_count = len(all_workspaces)
            data = all_workspaces[:max_results]

            # Format workspace data for better readability
            formatted_workspaces = []
            for ws in data:
                formatted_ws = {
                    "workspace_name": ws.get("showName"),
                    "project_id": ws.get("projectId"),
                    "workspace_id": ws.get("workspaceId"),
                    "created_time": ws.get("createdTime"),
                    "updated_time": ws.get("updatedTime"),
                    "default_schema_name": ws.get("defaultSchemaName"),
                    "default_vc_name": ws.get("defaultVcName")
                }
                formatted_workspaces.append(formatted_ws)

            message = (
                f"{total_count} total matches found, showing {page_size}. Refine keywords if needed."
                if total_count > page_size
                else "Successfully retrieved all user workspaces"
            )

            formatted_response = {
                "success": True,
                "message": message,
                "total_count": total_count,
                "workspaces": formatted_workspaces
            }

            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"API request failed: {response_data.get('message', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in list_user_workspaces: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


def list_user_workspaces_tool() -> List[Tool]:
    """Get workspace listing tools"""
    return [
        Tool(
            name="list_user_workspaces",
            description=(
                "List workspaces accessible to the current user in Clickzetta Studio. "
                "Supports fuzzy matching search by workspace. "
                "Returns workspace information including workspace name, projectId, workspace id, and timestamps. "
                "CRITICAL: this tool return up to 20 most relevant results, when return size < total_count, must prompt users to adjust keywords "
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "workspace_pattern": {
                        "type": "string",
                        "description": (
                            "Optional. Supports fuzzy matching search by workspace "
                        )
                    }
                },
                "additionalProperties": False,
                "required": [],
            },
            handler=handle_list_user_workspaces,
            tags=["studio", "workspace", "normalize"],
            samples=[
                {
                    "description": "List all workspaces for the current user",
                    "query": {
                        "workspace_pattern": "myWorkspace"
                    }
                }
            ]
        ),
    ]
