"""
Studio-specific tools for MCP Studio server
Handles Studio API interactions and project management
"""
import json
import logging
from typing import List, Optional, Any, Coroutine

from mcp.types import TextContent, EmbeddedResource

from cz_mcp.handlers.ide_admin_server import create_folder
from ..core.tool_registry import Tool
from ..common.utilities import ResponseBuilder
from ..handlers.login_server import get_current_user
from ..studio_config_manager import StudioConfig

from loguru import logger

async def handle_create_folder(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    Create folder in Clickzetta Studio
    """
    if arguments is None:
        arguments = {}

    try:
        # Extract parameters
        parent_folder_id = arguments.get("parent_folder_id")
        data_folder_name = arguments.get("data_folder_name")
        config = studio_config

        if not config:
            raise ValueError("Server connection_config is not initialized")

        # Use config project ID if not provided
        project_id = config.project_id
        created_by = config.username
        if created_by is None:
            current_user = get_current_user(config.token, config.env)
            created_by = current_user["name"] if current_user else ""
        logger.info(f"create project dolder for project_id: {project_id}")

        # Call the API
        response = create_folder(
            project_id=project_id,
            created_by=created_by,
            parent_folder_id=parent_folder_id,
            data_folder_name=data_folder_name,
            jwt_token=config.token,
            instance_name=config.instance,
            env=config.env,
            workspace_name=config.workspace
        )

        # Parse and format the response
        response_data = json.loads(response)

        if response_data.get("code") == "200":
            data = response_data.get("data", {})
            folder_id = data

            # Format the response for better readability
            formatted_response = {
                "success": True,
                "message": "Successfully create folder",
                "folder_id": folder_id,
            }

            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[handle_create_folder]API request failed: {response_data.get('message', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in create folder: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


def create_folder_tool() -> List[Tool]:
    """Get all Studio-specific tools"""
    return [
        Tool(
            name="create_folder",
            description=(
                "Create a new data folder within a specified project workspace in Clickzetta Studio. "
                "Supports defining the folder name, parent folder, folder type, and metadata such as creator information. "
                "In this configuration, the folder will be created in the Clickzetta Studio workspace where projectId is specified."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "data_folder_name": {
                        "type": "string",
                        "description": "Name of the folder to be created. Must be unique within the same parent folder."
                    },
                    "parent_folder_id": {
                        "type": "integer",
                        "description": "ID of the parent folder under which the new folder will be created."
                    }
                },
                "additionalProperties": False,
                "required": ["data_folder_name", "parent_folder_id"],
            },
            handler=handle_create_folder,
            tags=["studio", "project", "normalize"],
            samples=[
                {
                    "description": "Create a new folder named cc in Click zetta Studio project (ID 97001), under parent folder with ID 528042.",
                    "query": {
                       "data_folder_name": "test_folder",
                        "parent_folder_id": 528042
                    }
                }
            ]
        ),
    ]

