"""
Studio-specific tools for MCP Studio server
Handles Studio API interactions for data source management
"""
import json
from typing import List, Optional

from loguru import logger
from mcp.types import TextContent, EmbeddedResource

from cz_mcp.handlers.datasource_server import (
    datasource_list as api_datasource_list,
    get_namespace_list as api_get_namespace_list,
    get_meta_list as api_get_meta_list,
    get_meta_detail as api_get_meta_detail
)
from ..common.utilities import ResponseBuilder
from ..core.tool_registry import Tool
from ..studio_config_manager import StudioConfig

# ==========================================
# 全量数据源类型映射表
# ==========================================
DATASOURCE_TYPE_MAP = {
    1: "LakeHouse",
    2: "Kafka",
    3: "Hive",
    4: "ClickHouse",
    5: "MySQL",
    7: "PostgreSQL",
    8: "SqlServer",
    9: "Oss",
    10: "Hbase",
    11: "Odps",
    12: "MongoDB",
    13: "ElasticSearch7",
    14: "Doris",
    15: "StarRocks",
    16: "SelectDB",
    17: "TiDB",
    18: "MariaDB",
    19: "PolarDB",
    20: "Hologres",
    21: "DB2",
    22: "Greenplum",
    23: "AdbMysql",
    24: "AdbPostgresql",
    25: "Oracle",
    26: "DM",
    27: "COS",
    28: "LogHub",
    30: "customJdbc",
    31: "sensorsApi",
    32: "mirrorJdbc",
    33: "PostgreSqlCdc",
    34: "MySqlCdc",
    35: "RestfulApi",
    36: "SqlserverCdc",
    37: "Amqp",
    38: "S3",
    39: "Aurora_For_Mysql",
    40: "Aurora_For_Postgresql",
    41: "Aurora_For_Mysql_CDC",
    42: "Aurora_For_Postgresql_CDC",
    43: "Redis",
    44: "Databricks",
    45: "AutoMQ",
    46: "Redshift",
    47: "Sap_Hana",
    48: "Polardb_For_Postgresql",
    49: "Polardb_For_Mysql_CDC",
    50: "Polardb_For_Postgresql_CDC",
    51: "DynamoDB",
    52: "KafkaCdc",
}

async def handle_list_data_sources(arguments=None, studio_config: Optional[StudioConfig] = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    Fetch data source list for a project in Clickzetta Studio
    """
    if arguments is None:
        arguments = {}

    try:
        if studio_config is None:
            error_response = {
                "success": False,
                "message": "Studio configuration is required"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)
        
        config = studio_config
        ds_name = arguments.get("ds_name")
        ds_type = arguments.get("ds_type")
        page_index = arguments.get("page_index", 1)
        page_size = arguments.get("page_size", 20)
        project_id = config.project_id
        token = config.token
        instance_name = config.instance
        env = config.env

        logger.info(f"Fetching data source list for project_id: {project_id}, page: {page_index}, size: {page_size}")


        # Call the API
        response = api_datasource_list(
            project_id=project_id,
            ds_name=ds_name,
            ds_type=ds_type,
            jwt_token=token,
            instance_name=instance_name,
            user_id= config.user_id,
            instance_id=config.instance_id,
            account_id= config.tenant_id,
            env=env,
            workspace_name=config.workspace,
            page_index=page_index,
            page_size=page_size
        )

        # Parse and format the response
        response_data = json.loads(response)

        if response_data.get("code") == "200":
            data = response_data.get("data", {})

            # Handle both list and dict response formats
            if isinstance(data, list):
                data_sources = data
                total_count = len(data)
            else:
                data_sources = data.get("list", [])
                total_count = data.get("total", len(data_sources))
            
            # Remove connectionParams to save tokens (contains encrypted passwords and long connection strings)
            for ds in data_sources:
                if "connectionParams" in ds:
                    del ds["connectionParams"]
            
            formatted_response = {
                "success": True,
                "message": f"Successfully fetched page {page_index} with {len(data_sources)} data sources.",
                "page_index": page_index,
                "page_size": page_size,
                "count": len(data_sources),
                "total_count": total_count,
                "has_more": page_index * page_size < total_count,
                "data_sources": data_sources,
            }
            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[handle_list_data_sources]API request failed: {response_data.get('message', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


    except Exception as e:
        logger.error(f"Error in list data sources: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


async def handle_list_namespaces(arguments=None, studio_config: Optional[StudioConfig] = None, **kwargs) -> list[TextContent | EmbeddedResource]:
    """
    List namespaces (schemas/databases) for a specific data source in Clickzetta Studio
    """
    if arguments is None:
        arguments = {}

    try:
        if studio_config is None:
            error_response = {
                "success": False,
                "message": "Studio configuration is required"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)
        
        config = studio_config
        datasource_id = arguments.get("datasource_id")
        namespace_filter = arguments.get("namespace_filter")  # Optional fuzzy match filter
        
        if not datasource_id:
            error_response = {
                "success": False,
                "message": "datasource_id is required"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)
        
        token = config.token
        instance_name = config.instance
        env = config.env

        logger.info(f"Fetching namespace list for datasource_id: {datasource_id}")

        # Call the API
        response = api_get_namespace_list(
            datasource_id=datasource_id,
            jwt_token=token,
            instance_name=instance_name,
            instance_id=config.instance_id,
            user_id=config.user_id,
            account_id=config.tenant_id,
            env=env,
            workspace_name=config.workspace
        )

        # Parse and format the response
        response_data = json.loads(response)

        if response_data.get("code") == "200":
            data = response_data.get("data", {})
            # Extract namespace list from the paginated response structure
            namespaces = data.get("list", [])
            total = data.get("total", len(namespaces))
            
            # Apply fuzzy matching filter if provided
            original_count = len(namespaces)
            if namespace_filter:
                filter_lower = namespace_filter.lower()
                filtered_namespaces = [
                    ns for ns in namespaces 
                    if filter_lower in str(ns).lower()
                ]
                logger.info(f"Filtered namespaces from {original_count} to {len(filtered_namespaces)} using filter: {namespace_filter}")
                namespaces = filtered_namespaces
            
            formatted_response = {
                "success": True,
                "message": f"Successfully fetched {len(namespaces)} namespaces." + (f" (filtered by '{namespace_filter}')" if namespace_filter else ""),
                "count": len(namespaces),
                "total_before_filter": original_count,
                "namespaces": namespaces,
                "filter_applied": namespace_filter if namespace_filter else None,
            }
            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[handle_list_namespaces]API request failed: {response_data.get('message', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in get namespace list: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


async def handle_list_metadata_objects(arguments=None, studio_config: Optional[StudioConfig] = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    List data objects (tables/views/collections) for a specific namespace in a data source
    """
    if arguments is None:
        arguments = {}

    try:
        if studio_config is None:
            error_response = {
                "success": False,
                "message": "Studio configuration is required"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)
        
        config = studio_config
        datasource_id = arguments.get("datasource_id")
        namespace = arguments.get("namespace")
        table_filter = arguments.get("table_filter")  # Optional fuzzy match filter
        
        if not datasource_id:
            error_response = {
                "success": False,
                "message": "datasource_id is required"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)
        
        if not namespace:
            error_response = {
                "success": False,
                "message": "namespace is required"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)
        
        token = config.token
        instance_name = config.instance
        env = config.env

        logger.info(f"Fetching data objects for datasource_id: {datasource_id}, namespace: {namespace}")

        # Call the API
        response = api_get_meta_list(
            datasource_id=datasource_id,
            namespace=namespace,
            jwt_token=token,
            instance_name=instance_name,
            instance_id=config.instance_id,
            user_id=config.user_id,
            account_id=config.tenant_id,
            env=env,
            workspace_name=config.workspace
        )

        # Parse and format the response
        response_data = json.loads(response)

        if response_data.get("code") == "200":
            data = response_data.get("data", {})
            # Extract data objects list from the paginated response structure
            data_objects = data.get("list", [])
            total = data.get("total", len(data_objects))
            
            # Apply fuzzy matching filter if provided
            original_count = len(data_objects)
            if table_filter:
                filter_lower = table_filter.lower()
                filtered_objects = []
                for obj in data_objects:
                    # Support both string and dict formats
                    if isinstance(obj, str):
                        if filter_lower in obj.lower():
                            filtered_objects.append(obj)
                    elif isinstance(obj, dict):
                        # Check common field names for table name
                        table_name = obj.get("name") or obj.get("table_name") or obj.get("tableName") or str(obj)
                        if filter_lower in table_name.lower():
                            filtered_objects.append(obj)
                    else:
                        if filter_lower in str(obj).lower():
                            filtered_objects.append(obj)
                
                logger.info(f"Filtered data objects from {original_count} to {len(filtered_objects)} using filter: {table_filter}")
                data_objects = filtered_objects
            
            formatted_response = {
                "success": True,
                "message": f"Successfully fetched {len(data_objects)} data objects." + (f" (filtered by '{table_filter}')" if table_filter else ""),
                "count": len(data_objects),
                "total_before_filter": original_count,
                "data_objects": data_objects,
                "filter_applied": table_filter if table_filter else None,
            }
            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[handle_list_metadata_objects]API request failed: {response_data.get('message', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in get meta list: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


async def handle_get_metadata_detail(arguments=None, studio_config: Optional[StudioConfig] = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    """
    Get detailed metadata for a specific data object
    """
    if arguments is None:
        arguments = {}

    try:
        if studio_config is None:
            error_response = {
                "success": False,
                "message": "Studio configuration is required"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)
        
        config = studio_config
        datasource_id = arguments.get("datasource_id")
        namespace = arguments.get("namespace")
        data_object_name = arguments.get("data_object_name")
        
        if not datasource_id:
            error_response = {
                "success": False,
                "message": "datasource_id is required"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)
        
        if not namespace:
            error_response = {
                "success": False,
                "message": "namespace is required"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)
        
        if not data_object_name:
            error_response = {
                "success": False,
                "message": "data_object_name is required"
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)
        
        token = config.token
        instance_name = config.instance
        env = config.env

        logger.info(f"Fetching metadata for datasource_id: {datasource_id}, namespace: {namespace}, object: {data_object_name}")

        # Call the API
        response = api_get_meta_detail(
            datasource_id=datasource_id,
            namespace=namespace,
            data_object_name=data_object_name,
            jwt_token=token,
            instance_name=instance_name,
            instance_id=config.instance_id,
            user_id=config.user_id,
            account_id=config.tenant_id,
            env=env,
            workspace_name=config.workspace
        )

        # Parse and format the response
        response_data = json.loads(response)

        if response_data.get("code") == "200":
            metadata = response_data.get("data", {})
            formatted_response = {
                "success": True,
                "message": "Successfully fetched metadata details.",
                "metadata": metadata,
            }
            return ResponseBuilder.create_yaml_json_response([formatted_response], studio_config=studio_config)
        else:
            error_response = {
                "success": False,
                "message": f"[handle_get_metadata_detail]API request failed: {response_data.get('message', 'Unknown error')}",
                "code": response_data.get("code"),
                "raw_response": response_data
            }
            return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)

    except Exception as e:
        logger.error(f"Error in get meta detail: {e}")
        error_response = {
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__
        }
        return ResponseBuilder.create_yaml_json_response([error_response], studio_config=studio_config)


def list_data_sources() -> List[Tool]:
    """Get all Studio-specific datasource tools"""
    return [
        Tool(
            name="list_data_sources",
            description=(
                "Retrieve all available data sources in the specified Clickzetta Studio project. "
                "This API lists all active data sources configured for the current workspace, "
                "including metadata such as source name, type, and connection information.\n\n"
                "**Self-Contained Tool**: This tool handles all data retrieval internally. "
                "No need to query table structures or use additional tools - it provides complete datasource information directly.\n\n"
                "**⚠️ STRONGLY RECOMMENDED - Use Filter Parameters**: When querying datasources, it is STRONGLY RECOMMENDED to use "
                "filter parameters (`ds_name` and/or `ds_type`). Without filters, the response may be extremely large and cause "
                "performance issues or output truncation. Always try to narrow down your search scope.\n\n"
                "**Performance Tip**: When searching for a specific datasource, it is HIGHLY RECOMMENDED to specify "
                "the `ds_type` parameter along with `ds_name`. This significantly improves query performance and accuracy "
                "by narrowing down the search scope. For example, if you know you're looking for a MySQL datasource, "
                "always include `ds_type: 5` in your query.\n\n"
                "**Common datasource types**:\n"
                "- 1: Lakehouse\n"
                "- 2: Kafka\n"
                "- 3: Hive\n"
                "- 4: ClickHouse\n"
                "- 5: MySQL\n"
                "- 7: PostgreSQL\n"
                "- 8: SQL Server\n"
                "- 9: OSS (Object Storage)\n"
                "- 12: MongoDB\n"
                "- 43: Redis\n\n"
                "**Pagination**: This tool returns only one page of results per call.\n\n"
                "When the user asks for 'all items', 'the full list', or any request that cannot be fulfilled by a single page, "
                "the assistant MUST repeatedly call this tool, incrementing page_index each time, "
                "until all pages are retrieved or no more data is returned.\n\n"
                "The assistant is responsible for performing the loop and merging all pages before responding to the user."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "ds_name": {
                        "type": "string",
                        "description": "Name of the data source to filter results by (supports fuzzy match). RECOMMENDED: Use together with ds_type for better performance."
                    },
                    "ds_type": {
                        "type": "integer",
                        "description": "Data source type code (RECOMMENDED when using ds_name filter for better performance). Full mapping:\n"
                                       + "\n".join([f"{k}: {v}" for k, v in DATASOURCE_TYPE_MAP.items()])
                    },
                    "page_index": {
                        "type": "integer",
                        "description": "Page index (1-based). Default is 1.",
                        "default": 1
                    },
                    "page_size": {
                        "type": "integer",
                        "description": "Number of items per page. Default is 20.",
                        "default": 20
                    }
                },
                "additionalProperties": False,
            },
            handler=handle_list_data_sources,
            tags=["studio", "datasource", "project", "api"],
            samples=[
                {
                    "description": "Fetch first page of all data sources.",
                    "query": {"page_index": 1, "page_size": 20}
                },
                {
                    "description": "Fetch all MySQL data sources (recommended: filter by type).",
                    "query": {"ds_type": 5, "page_index": 1, "page_size": 50}
                },
                {
                    "description": "Search for a specific MySQL datasource by name (BEST PRACTICE: include ds_type).",
                    "query": {"ds_name": "MySQL_Prod", "ds_type": 5, "page_index": 1, "page_size": 20}
                },
                {
                    "description": "Search for Lakehouse datasources containing 'test' in name.",
                    "query": {"ds_name": "test", "ds_type": 1, "page_index": 1, "page_size": 20}
                }
            ]
        ),
        Tool(
            name="list_namespaces",
            description=(
                "Retrieve the list of namespaces (schemas/databases) available in a specific data source. "
                "This API returns all namespaces that can be accessed within the given data source, "
                "which is useful for exploring the hierarchical structure of external data systems.\n\n"
                "**⚠️ STRONGLY RECOMMENDED - Use Filter Parameter**: It is STRONGLY RECOMMENDED to use the "
                "`namespace_filter` parameter when querying namespaces. Without filtering, the response may contain "
                "a large number of namespaces, leading to excessive output size and potential performance issues. "
                "Always try to narrow down your search by providing a filter string.\n\n"
                "**Fuzzy Matching**: Supports optional `namespace_filter` parameter for case-insensitive substring matching. "
                "When provided, only namespaces containing the filter string will be returned."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "datasource_id": {
                        "type": "integer",
                        "description": "The unique identifier of the data source to query namespaces from."
                    },
                    "namespace_filter": {
                        "type": "string",
                        "description": "Optional filter to perform case-insensitive fuzzy matching on namespace names. Only namespaces containing this substring will be returned."
                    }
                },
                "required": ["datasource_id"],
                "additionalProperties": False,
            },
            handler=handle_list_namespaces,
            tags=["studio", "datasource", "namespace", "schema", "api"],
            samples=[
                {
                    "description": "Get all namespaces for data source with ID 26412.",
                    "query": {"datasource_id": 26412}
                },
                {
                    "description": "Get namespaces containing 'demo' for data source with ID 26412.",
                    "query": {"datasource_id": 26412, "namespace_filter": "demo"}
                }
            ]
        ),
        Tool(
            name="list_metadata_objects",
            description=(
                "List all data objects (tables/views/collections) within a specific namespace "
                "of a data source. This API provides metadata about all accessible data objects in the "
                "specified namespace, enabling discovery of available datasets.\n\n"
                "**⚠️ STRONGLY RECOMMENDED - Use Filter Parameter**: It is STRONGLY RECOMMENDED to use the "
                "`table_filter` parameter when querying data objects. Without filtering, the response may contain "
                "a large number of tables/views, leading to excessive output size and potential performance issues. "
                "Always try to narrow down your search by providing a filter string.\n\n"
                "**Fuzzy Matching**: Supports optional `table_filter` parameter for case-insensitive substring matching. "
                "When provided, only tables/objects containing the filter string will be returned."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "datasource_id": {
                        "type": "integer",
                        "description": "The unique identifier of the data source."
                    },
                    "namespace": {
                        "type": "string",
                        "description": "The namespace (schema/database name) to query data objects from."
                    },
                    "table_filter": {
                        "type": "string",
                        "description": "Optional filter to perform case-insensitive fuzzy matching on table/object names. Only objects containing this substring will be returned."
                    }
                },
                "required": ["datasource_id", "namespace"],
                "additionalProperties": False,
            },
            handler=handle_list_metadata_objects,
            tags=["studio", "datasource", "metadata", "table", "api"],
            samples=[
                {
                    "description": "Get all data objects in namespace '00_wky_demo' for data source 26412.",
                    "query": {"datasource_id": 26412, "namespace": "00_wky_demo"}
                },
                {
                    "description": "Get data objects containing 'user' in namespace '00_wky_demo' for data source 26412.",
                    "query": {"datasource_id": 26412, "namespace": "00_wky_demo", "table_filter": "user"}
                }
            ]
        ),
        Tool(
            name="get_metadata_detail",
            description=(
                "Get detailed metadata information for a specific data object (table/view/collection). "
                "This API returns comprehensive schema information including column names, data types, "
                "constraints, and other metadata properties of the specified data object."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "datasource_id": {
                        "type": "integer",
                        "description": "The unique identifier of the data source."
                    },
                    "namespace": {
                        "type": "string",
                        "description": "The namespace (schema/database name) containing the data object."
                    },
                    "data_object_name": {
                        "type": "string",
                        "description": "The name of the data object (table/view/collection) to retrieve metadata for."
                    }
                },
                "required": ["datasource_id", "namespace", "data_object_name"],
                "additionalProperties": False,
            },
            handler=handle_get_metadata_detail,
            tags=["studio", "datasource", "metadata", "schema", "column", "api"],
            samples=[
                {
                    "description": "Get metadata details for table 'abbbbbc' in namespace '00_wky_demo'.",
                    "query": {
                        "datasource_id": 26412,
                        "namespace": "00_wky_demo",
                        "data_object_name": "abbbbbc"
                    }
                }
            ]
        ),
    ]
