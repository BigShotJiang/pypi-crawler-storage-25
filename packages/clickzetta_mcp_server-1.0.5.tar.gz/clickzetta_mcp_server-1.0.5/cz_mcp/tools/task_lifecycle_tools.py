"""
Task lifecycle tools for periodic schedule tasks.
"""

import json
from typing import List

from loguru import logger
from mcp.types import TextContent, EmbeddedResource

from cz_mcp.common.utilities import ResponseBuilder
from cz_mcp.core.tool_registry import Tool
from cz_mcp.handlers.ide_admin_server import (
    offline_task as api_offline_task,
    offline_task_with_downstream as api_offline_task_with_downstream,
    kill_task_instance as api_kill_task_instance,
)
from cz_mcp.studio_config_manager import StudioConfig


async def handle_offline_task(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    if arguments is None:
        arguments = {}

    try:
        config = studio_config
        schedule_task_id = arguments.get("schedule_task_id")
        update_by = arguments.get("update_by") or config.username

        response = api_offline_task(
            schedule_task_id=schedule_task_id,
            update_by=update_by,
            workspace=config.workspace,
            jwt_token=config.token,
            instance_name=config.instance,
            instance_id=config.instance_id,
            env=config.env,
        )
        response_data = json.loads(response)

        if str(response_data.get("code")) == "200":
            return ResponseBuilder.create_yaml_json_response([{
                "success": True,
                "message": "Task offline succeeded",
                "result": response_data.get("data", True),
                "schedule_task_id": schedule_task_id,
            }], studio_config=studio_config)

        return ResponseBuilder.create_yaml_json_response([{
            "success": False,
            "message": f"API request failed: {response_data.get('message', 'Unknown error')}",
            "code": response_data.get("code"),
            "raw_response": response_data,
        }], studio_config=studio_config)
    except Exception as e:
        logger.error(f"Error in offline_task: {e}")
        return ResponseBuilder.create_yaml_json_response([{
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__,
        }], studio_config=studio_config)


async def handle_offline_task_with_downstream(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    if arguments is None:
        arguments = {}

    try:
        config = studio_config
        schedule_task_id = arguments.get("schedule_task_id")
        tasks = arguments.get("tasks") or []
        update_by = arguments.get("update_by") or config.username

        response = api_offline_task_with_downstream(
            schedule_task_id=schedule_task_id,
            tasks=tasks,
            update_by=update_by,
            workspace=config.workspace,
            jwt_token=config.token,
            instance_name=config.instance,
            instance_id=config.instance_id,
            env=config.env,
        )
        response_data = json.loads(response)

        if str(response_data.get("code")) == "200":
            return ResponseBuilder.create_yaml_json_response([{
                "success": True,
                "message": "Task offline with downstream succeeded",
                "result": response_data.get("data", True),
                "schedule_task_id": schedule_task_id,
            }], studio_config=studio_config)

        return ResponseBuilder.create_yaml_json_response([{
            "success": False,
            "message": f"API request failed: {response_data.get('message', 'Unknown error')}",
            "code": response_data.get("code"),
            "raw_response": response_data,
        }], studio_config=studio_config)
    except Exception as e:
        logger.error(f"Error in offline_task_with_downstream: {e}")
        return ResponseBuilder.create_yaml_json_response([{
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__,
        }], studio_config=studio_config)


async def handle_kill_task_instance(arguments=None, studio_config: StudioConfig = None, **kwargs) -> list[
    TextContent | EmbeddedResource]:
    if arguments is None:
        arguments = {}

    try:
        config = studio_config
        task_instance_id = arguments.get("task_instance_id")
        project_id = arguments.get("project_id") or config.project_id
        update_by = arguments.get("update_by") or config.username

        response = api_kill_task_instance(
            project_id=project_id,
            task_instance_id=task_instance_id,
            update_by=update_by,
            workspace=config.workspace,
            jwt_token=config.token,
            instance_name=config.instance,
            instance_id=config.instance_id,
            env=config.env,
        )
        response_data = json.loads(response)

        if str(response_data.get("code")) == "200":
            return ResponseBuilder.create_yaml_json_response([{
                "success": True,
                "message": "Task instance stop succeeded",
                "result": response_data.get("data", True),
                "task_instance_id": task_instance_id,
                "project_id": project_id,
            }], studio_config=studio_config)

        return ResponseBuilder.create_yaml_json_response([{
            "success": False,
            "message": f"API request failed: {response_data.get('message', 'Unknown error')}",
            "code": response_data.get("code"),
            "raw_response": response_data,
        }], studio_config=studio_config)
    except Exception as e:
        logger.error(f"Error in kill_task_instance: {e}")
        return ResponseBuilder.create_yaml_json_response([{
            "success": False,
            "message": f"Internal error: {str(e)}",
            "error_type": type(e).__name__,
        }], studio_config=studio_config)


def get_task_lifecycle_tools() -> List[Tool]:
    return [
        Tool(
            name="offline_task",
            description=(
                "Offline a periodic schedule task without downstream tasks. "
                "Use this only when the task has no downstream dependencies."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "schedule_task_id": {
                        "type": "integer",
                        "description": "Schedule task ID to offline.",
                    },
                    "update_by": {
                        "type": "string",
                        "description": "Optional operator username. Defaults to current login user.",
                    },
                },
                "required": ["schedule_task_id"],
                "additionalProperties": False,
            },
            handler=handle_offline_task,
            tags=["task", "lifecycle", "offline"],
            samples=[
                {
                    "description": "Offline one periodic task",
                    "query": {
                        "schedule_task_id": 10330178,
                    },
                }
            ],
        ),
        Tool(
            name="offline_task_with_downstream",
            description=(
                "Offline a periodic schedule task together with downstream tasks. "
                "Use this when downstream dependencies exist and should be offline as well."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "schedule_task_id": {
                        "type": "integer",
                        "description": "Root schedule task ID to offline.",
                    },
                    "tasks": {
                        "type": "array",
                        "description": "Optional downstream task descriptor array. Defaults to empty list.",
                        "items": {"type": "object"},
                        "default": [],
                    },
                    "update_by": {
                        "type": "string",
                        "description": "Optional operator username. Defaults to current login user.",
                    },
                },
                "required": ["schedule_task_id"],
                "additionalProperties": False,
            },
            handler=handle_offline_task_with_downstream,
            tags=["task", "lifecycle", "offline", "downstream"],
            samples=[
                {
                    "description": "Offline root task with downstream",
                    "query": {
                        "schedule_task_id": 10331106,
                        "tasks": [],
                    },
                }
            ],
        ),
        Tool(
            name="kill_task_instance",
            description="Stop a running task instance by task instance ID.",
            input_schema={
                "type": "object",
                "properties": {
                    "task_instance_id": {
                        "type": "integer",
                        "description": "Task instance ID to stop.",
                    },
                    "project_id": {
                        "type": "integer",
                        "description": "Optional project ID. Defaults to current workspace project.",
                    },
                    "update_by": {
                        "type": "string",
                        "description": "Optional operator username. Defaults to current login user.",
                    },
                },
                "required": ["task_instance_id"],
                "additionalProperties": False,
            },
            handler=handle_kill_task_instance,
            tags=["task_run", "lifecycle", "stop"],
            samples=[
                {
                    "description": "Stop a running task instance",
                    "query": {
                        "task_instance_id": 24618006,
                        "project_id": 139187,
                    },
                }
            ],
        ),
    ]
