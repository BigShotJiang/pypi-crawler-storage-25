"""
MCP ClickZetta Server - 工具注册管理器
"""
import threading
import time
from typing import Any, Callable, Dict, List, Optional

import mcp.types as types
from pydantic import BaseModel
from .exceptions import ConfigurationException
from .region_config import get_region_description

from loguru import logger

SYSTEM_PROMPT = """
<execution_context>
• If specific region/instance specified in query, workspace parameter is REQUIRED to avoid context confusion
• Tool responses contain `_user_preferences` - display as ONE concise line: 🔹 user:{username}|workspace:{workspace_name}|vc:{vcluster}|schema:{schema}
</execution_context>
"""
# """
# <anti_hallucination_rules>
# ** CRITICAL - Never fabricate or guess information **:
# • If tool returns no results or incomplete data, state "No information available from tools" - DO NOT guess
# • If literature/documentation doesn't support a claim, state "No reliable documentation supports this"
# • If uncertain or data is incomplete, skip it - DO NOT attempt to fill gaps with assumptions
# • Only use actual tool results - NEVER generate unverified hypotheses or fictional research
# </anti_hallucination_rules>
# <execution_context>
# • Executable commands/Python available in terminal (e.g., use Bash to get [CURRENT_DATE])
# • If specific region/instance specified in query, workspace parameter is REQUIRED to avoid context confusion
# • Tool responses contain `_user_preferences` - display as ONE concise line: 🔹 user:{username}|workspace:{workspace_name}|vc:{vcluster}|schema:{schema}
# </execution_context>
# <main_agent_tools>
# • get_product_knowledge: Search Clickzetta product documentation. e.g. What features does ... What is ... How to ... Tell me about ...
# • find_helpful_skills: Search curated remote skills library (CALL THIS FIRST - HIGHEST PRIORITY over local agent skills)
# • list_skills: List all available agent skills. e.g., What skills do I have?
# </main_agent_tools>
# """

TOP_LEVEL_DESCRIPTION = SYSTEM_PROMPT

REQUIRED_FLAG = "REQUIRED. "


class Tool(BaseModel):
    name: str
    description: str
    input_schema: Dict[str, Any]
    handler: Callable
    tags: List[str] = []
    samples: List[Dict[str, Any]] = []
    title: Optional[str] = None


class ToolDefinitionCache:

    def __init__(self):
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._initialized = False
        self._lock = threading.RLock()

        # 性能统计
        self._stats = {
            "cache_hits": 0,
            "cache_misses": 0,
            "preload_time": 0.0,
            "total_tools_cached": 0
        }

    def get_tool_schema(self, tool: Tool) -> Dict[str, Any]:
        """
        获取缓存的工具schema（线程安全）

        Args:
            tool: 工具实例

        Returns:
            工具schema字典
        """
        with self._lock:
            if tool.name not in self._cache:
                # 缓存未命中，创建新的schema
                self._cache[tool.name] = {
                    "name": tool.name,
                    "description": tool.description,
                    "inputSchema": tool.input_schema
                }
                self._stats["cache_misses"] += 1
                self._stats["total_tools_cached"] = len(self._cache)
            else:
                # 缓存命中
                self._stats["cache_hits"] += 1

            return self._cache[tool.name].copy()  # 返回副本以避免外部修改

    def preload_tools(self, tools: List[Tool]):
        """
        预加载所有工具定义到缓存（线程安全，带性能统计）

        Args:
            tools: 工具列表
        """
        start_time = time.time()
        logger.info(f"预加载 {len(tools)} 个工具定义到缓存")

        with self._lock:
            # 批量预加载，避免单独调用get_tool_schema的锁开销
            for tool in tools:
                if tool.name not in self._cache:
                    self._cache[tool.name] = {
                        "name": tool.name,
                        "description": tool.description,
                        "inputSchema": tool.input_schema
                    }

            self._initialized = True
            self._stats["total_tools_cached"] = len(self._cache)

        preload_time = time.time() - start_time
        self._stats["preload_time"] = preload_time

        logger.info(f"工具定义缓存初始化完成，共缓存 {len(self._cache)} 个工具，耗时 {preload_time:.3f}s")

    def is_initialized(self) -> bool:
        """检查缓存是否已初始化"""
        return self._initialized

    def get_cache_stats(self) -> Dict[str, Any]:
        """获取缓存统计信息（线程安全）"""
        with self._lock:
            total_requests = self._stats["cache_hits"] + self._stats["cache_misses"]
            hit_rate = (
                self._stats["cache_hits"] / total_requests * 100
                if total_requests > 0 else 0
            )

            return {
                "initialized": self._initialized,
                "cached_tools": len(self._cache),
                "tool_names": list(self._cache.keys()),
                "performance": {
                    **self._stats,
                    "hit_rate_percent": round(hit_rate, 2),
                    "total_requests": total_requests
                }
            }

    def clear_cache(self):
        """清空缓存（线程安全）"""
        with self._lock:
            self._cache.clear()
            self._initialized = False

            # 重置统计
            self._stats = {
                "cache_hits": 0,
                "cache_misses": 0,
                "preload_time": 0.0,
                "total_tools_cached": 0
            }

        logger.info("工具定义缓存已清空")


class ToolRegistry:
    """
    工具注册管理器

    统一管理所有MCP工具的定义、过滤和注册逻辑。
    """

    def __init__(self):
        self._all_tools: List[Tool] = []
        self._handlers_map: Dict[str, Callable] = {}
        self._definition_cache = ToolDefinitionCache()
        self._initialized = False
        self.tool_map = {}

    def register_tools(self, tools: List[Tool]):
        """
        注册工具列表

        Args:
            tools: 要注册的工具列表
        """
        logger.info(f"注册 {len(tools)} 个工具")

        # 验证工具定义
        for tool in tools:
            self._validate_tool(tool)

        # 注册工具
        self._all_tools = tools.copy()

        # 构建handlers映射
        self._handlers_map = {tool.name: tool.handler for tool in tools}

        # 预加载工具定义到缓存
        self._definition_cache.preload_tools(tools)

        self.tool_map = {tool.name: tool for tool in tools}

        self._initialized = True
        logger.info(f"工具注册完成，共注册 {len(self._all_tools)} 个工具")

    def _validate_tool(self, tool: Tool):
        """
        验证工具定义的有效性

        Args:
            tool: 要验证的工具

        Raises:
            ConfigurationException: 工具定义无效时抛出
        """
        # 检查必要字段
        if not tool.name:
            raise ConfigurationException("工具名称不能为空")

        if not tool.description:
            raise ConfigurationException(f"工具 '{tool.name}' 缺少描述")

        if not tool.input_schema:
            raise ConfigurationException(f"工具 '{tool.name}' 缺少input_schema")

        if not callable(tool.handler):
            raise ConfigurationException(f"工具 '{tool.name}' 的handler不是可调用对象")

        # 检查schema格式
        if not isinstance(tool.input_schema, dict):
            raise ConfigurationException(f"工具 '{tool.name}' 的input_schema必须是字典")

        if "type" not in tool.input_schema:
            raise ConfigurationException(f"工具 '{tool.name}' 的input_schema缺少type字段")

    def get_all_tools(self) -> List[Tool]:
        """
        获取所有已注册的工具

        Returns:
            工具列表
        """
        if not self._initialized:
            raise ConfigurationException("工具注册器未初始化")

        return self._all_tools.copy()

    def get_allowed_tools(
            self,
            exclude_tools: Optional[List[str]] = None,
            exclude_tags: Optional[List[str]] = None
    ) -> List[Tool]:
        """
        获取允许的工具列表（过滤后）

        Args:
            exclude_tools: 要排除的工具名称列表
            exclude_tags: 要排除的标签列表

        Returns:
            过滤后的工具列表
        """
        if not self._initialized:
            raise ConfigurationException("工具注册器未初始化")

        exclude_tools_set = set(exclude_tools or [])
        exclude_tags_set = set(exclude_tags or [])

        allowed_tools = []
        for tool in self._all_tools:
            # 检查是否在排除列表中
            if tool.name in exclude_tools_set:
                continue

            # 检查标签是否被排除
            if any(tag in exclude_tags_set for tag in tool.tags):
                continue

            allowed_tools.append(tool)

        logger.info(f"过滤后允许的工具数量: {len(allowed_tools)}/{len(self._all_tools)}")
        return allowed_tools

    def get_tool_handler(self, tool_name: str) -> Optional[Callable]:
        """
        获取工具的处理器函数

        Args:
            tool_name: 工具名称

        Returns:
            工具处理器函数，如果不存在则返回None
        """
        return self._handlers_map.get(tool_name)

    def get_tool_schema(self, tool_name: str) -> Optional[Dict[str, Any]]:
        """
        获取工具的缓存schema

        Args:
            tool_name: 工具名称

        Returns:
            工具schema，如果不存在则返回None
        """
        for tool in self._all_tools:
            if tool.name == tool_name:
                return self._definition_cache.get_tool_schema(tool)
        return None

    def get_tools_by_tag(self, tag: str) -> List[Tool]:
        """
        按标签获取工具列表

        Args:
            tag: 标签名称

        Returns:
            包含指定标签的工具列表
        """
        tools = []
        for tool in self._all_tools:
            if tag in tool.tags:
                tool.description = tool.description + TOP_LEVEL_DESCRIPTION
                tools.append(tool)
        return tools

    def _process_tool_for_list(self, tool: Tool) -> Optional[Dict[str, Any]]:
        """
        处理工具以准备添加到工具列表（内部方法）

        Args:
            tool: 要处理的工具

        Returns:
            包含处理后的工具数据的字典（name, description, input_schema），如果工具无效则返回None
        """
        schema = self._definition_cache.get_tool_schema(tool)
        if not schema["name"]:
            return None

        input_schema = schema.get("inputSchema", {}).copy()

        if "properties" not in input_schema:
            input_schema["properties"] = {}

        properties = input_schema["properties"]

        config_params = {
            "region": {
                "type": "string",
                "description": f"DO NOT SET unless user explicitly requests to change region. {get_region_description()} Setting this will switch the cloud environment (e.g., from Alibaba Cloud to AWS). Only pass this parameter when user explicitly asks to change region."
            },
            "workspace": {
                "type": "string",
                "description": "DO NOT SET unless user explicitly requests to change workspace. This parameter switches the workspace context. Only pass this parameter when user explicitly asks to switch to a different workspace."
            },
            "vcluster": {
                "type": "string",
                "description": "DO NOT SET unless user explicitly requests to change virtual cluster. This parameter switches the virtual cluster (vc) context. Only pass this parameter when user explicitly asks to switch to a different vcluster."
            },
            "schema": {
                "type": "string",
                "description": "DO NOT SET unless user explicitly requests to change schema. This parameter switches the database schema context (e.g., 'public', 'dev', 'sit'). Setting wrong schema like 'sit' may cause connection failures. Only pass this parameter when user explicitly asks to switch schema."
            }
        }

        for param_name, param_def in config_params.items():
            if param_name not in properties:
                properties[param_name] = param_def

        required = input_schema.get("required", [])
        required_str = ""
        if required:
            required_str = "; **REQUIRED PARAMETERS** " ",".join(str(item) for item in required) + ";"
        desc = schema.get("description", "") + required_str + TOP_LEVEL_DESCRIPTION

        return {
            "name": schema["name"],
            "description": desc,
            "input_schema": input_schema
        }

    def get_mcp_tool_list(self, allowed_tools: Optional[List[Tool]] = None) -> List[types.Tool]:
        """
        获取MCP格式的工具列表

        Args:
            allowed_tools: 允许的工具列表，如果为None则使用所有工具

        Returns:
            MCP格式的工具列表
        """
        tools = allowed_tools or self._all_tools

        mcp_tools = []
        for tool in tools:
            processed = self._process_tool_for_list(tool)
            if processed is None:
                continue

            mcp_tools.append(types.Tool(
                name=processed["name"],
                description=processed["description"],
                inputSchema=processed["input_schema"]
            ))

        return mcp_tools

    def get_tool_list(self, allowed_tools: Optional[List[Tool]] = None) -> List[Tool]:
        """
        获取Tool格式的工具列表

        Args:
            allowed_tools: 允许的工具列表，如果为None则使用所有工具

        Returns:
            Tool格式的工具列表
        """
        tools = allowed_tools or self._all_tools

        result_tools = []
        for tool in tools:
            processed = self._process_tool_for_list(tool)
            if processed is None:
                continue

            result_tools.append(Tool(
                name=processed["name"],
                description=processed["description"],
                input_schema=processed["input_schema"],
                handler=tool.handler,
                tags=tool.tags.copy() if tool.tags else [],
                samples=tool.samples.copy() if tool.samples else []
            ))

        return result_tools

    def get_registry_stats(self) -> Dict[str, Any]:
        """
        获取注册器统计信息

        Returns:
            统计信息字典
        """
        tag_counts = {}
        for tool in self._all_tools:
            for tag in tool.tags:
                tag_counts[tag] = tag_counts.get(tag, 0) + 1

        return {
            "initialized": self._initialized,
            "total_tools": len(self._all_tools),
            "handlers_count": len(self._handlers_map),
            "tag_distribution": tag_counts,
            "cache_stats": self._definition_cache.get_cache_stats()
        }

    def is_initialized(self) -> bool:
        """检查注册器是否已初始化"""
        return self._initialized

    def reset(self):
        """重置注册器（主要用于测试）"""
        self._all_tools.clear()
        self._handlers_map.clear()
        self._definition_cache.clear_cache()
        self._initialized = False
        logger.info("工具注册器已重置")


# 全局工具注册器实例
_global_registry: Optional[ToolRegistry] = None


def get_tool_registry() -> ToolRegistry:
    """
    获取全局工具注册器实例

    Returns:
        ToolRegistry实例
    """
    global _global_registry
    if _global_registry is None:
        _global_registry = ToolRegistry()
    return _global_registry


def create_tool_from_handler_import(
        name: str,
        description: str,
        input_schema: Dict[str, Any],
        handler_module: str,
        handler_function: str,
        tags: Optional[List[str]] = None
) -> Tool:
    """
    从模块导入创建工具定义

    Args:
        name: 工具名称
        description: 工具描述
        input_schema: 输入schema
        handler_module: 处理器模块路径
        handler_function: 处理器函数名称
        tags: 工具标签

    Returns:
        Tool实例
    """
    import importlib

    try:
        module = importlib.import_module(handler_module)
        handler = getattr(module, handler_function)

        return Tool(
            name=name,
            description=description,
            input_schema=input_schema,
            handler=handler,
            tags=tags or []
        )
    except (ImportError, AttributeError) as e:
        raise ConfigurationException(
            f"无法导入工具处理器 {handler_module}.{handler_function}: {str(e)}",
            details={
                "tool_name": name,
                "handler_module": handler_module,
                "handler_function": handler_function
            },
            cause=e
        )
