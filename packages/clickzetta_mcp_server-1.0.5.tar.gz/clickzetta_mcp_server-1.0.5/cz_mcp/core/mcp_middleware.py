import logging

from mcp.server.auth.provider import TokenVerifier, AccessToken

from .hornhub_client import HornhubClient


class ClickzettaTokenVerifier(TokenVerifier):
    """Token verifier for Clickzetta using HornhubClient"""

    def __init__(self, logger: logging.Logger, hornhub_client: HornhubClient):
        super().__init__()
        self.logger = logger
        self.hornhub_client = hornhub_client

    async def verify_token(self, token: str) -> AccessToken | None:
        """
        Verify a bearer token and return access info if valid.

        Args:
            token: The JWT token string to validate

        Returns:
            AccessToken object if valid, None if invalid or expired
        """
        try:
            user = await self.hornhub_client.check_access_token(token=token)
            return AccessToken(token=token, client_id=str(user.id), scopes=[])
        except Exception as e:
            self.logger.error(f"Failed to verify token: {e}")
            return None


def create_token_verifier(logger: logging.Logger, hornhub_client: HornhubClient) -> TokenVerifier:
    """Create token verifier for FastMCP"""
    return ClickzettaTokenVerifier(logger=logger, hornhub_client=hornhub_client)
