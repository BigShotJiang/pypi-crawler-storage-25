"""
MCP ClickZetta Server - 核心服务器逻辑

包含ClickzettaDB类和核心服务器功能，从原server.py重构而来。
"""

import logging
import time
import uuid
from functools import wraps
from typing import Any, Callable, Dict, List, Optional, Tuple

import mcp.types as types

from cz_mcp.core.enhanced_lakehouse import create_lakehouse_client_from_token, EnhancedLakehouseClient
from cz_mcp.core.exceptions import (
    ConnectionException,
    QueryExecutionException,
    ConfigurationException,
    MCPBaseException,
    map_exception
)
from ..studio_config_manager import StudioConfig

from loguru import logger


class EnhancedLakehouseDB:
    """
    Enhanced Lakehouse数据库连接和查询管理类
    
    使用EnhancedLakehouseClient替代原有的ClickzettaDB实现。
    """

    AUTH_EXPIRATION_TIME = 1800  # 30分钟会话超时

    def __init__(
            self,
            connection_config: Optional[StudioConfig] = None,
            enable_query_cache: bool = False
    ):
        """
        初始化数据库连接,lazy load
        
        Args:
            connection_config: StudioConfig实例，包含token、instance、service、workspace等
            enable_query_cache: 是否启用查询缓存（默认False，优先保证状态准确性）
        """
        # Store structured config or create empty one
        if isinstance(connection_config, dict):
            # Backward compatibility: convert dict to StudioConfig
            connection_config = StudioConfig.from_dict(connection_config)

        self.connection_config: Optional[StudioConfig] = connection_config
        self.lakehouse_client: Optional[EnhancedLakehouseClient] = None
        self.insights: List[str] = []
        self.managed_workspace: List[str] = []
        self.auth_time = 0

        # 性能优化组件
        self.enable_query_cache = enable_query_cache
        self._prefetch_cache = None  # 缓存组件

        # 设置默认hints（如果未提供）
        self._ensure_default_hints()

    @staticmethod
    def create_from_connection_config(connection_config: StudioConfig) -> 'EnhancedLakehouseDB':
        """
        从 StudioConfig 创建 EnhancedLakehouseDB 实例

        Args:
            connection_config: StudioConfig 实例

        Returns:
            配置好的 EnhancedLakehouseDB 实例
        """
        if not connection_config.token:
            raise ConfigurationException("Missing token in connection_config")

        logger.info(f"Creating EnhancedLakehouseDB with config: {connection_config}")

        return EnhancedLakehouseDB(connection_config)

    def _ensure_default_hints(self):
        """确保连接配置包含默认的hints"""
        if self.connection_config and not self.connection_config.hints:
            self.connection_config.hints = {
                "sdk.job.timeout": 300,
                "query_tag": "Query from MCP Server",
                "cz.storage.parquet.vector.index.read.memory.cache": "true",
                "cz.storage.parquet.vector.index.read.local.cache": "false",
                "cz.sql.table.scan.push.down.filter": "true",
                "cz.sql.table.scan.enable.ensure.filter": "true",
                "cz.storage.always.prefetch.internal": "true",
                "cz.optimizer.generate.columns.always.valid": "true",
                "cz.sql.index.prewhere.enabled": "true",
                "cz.storage.parquet.enable.io.prefetch": "false"
            }

    def _init_lakehouse_connection(self):
        """
        初始化Enhanced Lakehouse连接

        Raises:
            ConnectionException: 连接失败时抛出
            ConfigurationException: 配置错误时抛出
        """
        try:
            # Validate connection_config
            if not self.connection_config:
                raise ConfigurationException(
                    f"Invalid connection configuration",
                    details={"config_type": str(type(self.connection_config))}
                )

            logger.info(f"Initializing Enhanced Lakehouse connection: {self.connection_config}")

            # Validate required parameters
            token = self.connection_config.token
            instance = self.connection_config.instance
            service = self.connection_config.service
            workspace = self.connection_config.workspace
            vcluster = self.connection_config.vcluster
            schema = self.connection_config.schema

            if not all([token, instance, service, workspace]):
                logger.error(f"Missing required connection fields")
                raise ConfigurationException(
                    f"Connection configuration missing required parameters",
                    details={
                        "has_token": bool(token),
                        "has_instance": bool(instance),
                        "has_service": bool(service),
                        "has_workspace": bool(workspace)
                    }
                )

            logger.info(f"连接到Enhanced Lakehouse服务: {service} (instance: {instance}, workspace: {workspace})")

            # 使用create_lakehouse_client_from_token创建客户端
            self.lakehouse_client = create_lakehouse_client_from_token(
                magic_token=token,
                instance=instance,
                service=service,
                workspace=workspace,
                vcluster=vcluster,
                schema=schema
            )

            # 建立连接
            self.lakehouse_client.connect()

            self.auth_time = time.time()

            # 获取管理的workspace信息（可选，失败不影响连接）
            self._fetch_managed_workspaces()

            logger.info("ClickZetta连接初始化成功")

        except ConfigurationException:
            raise
        except Exception as e:
            logger.error(f"Connection initialization failed: {e}")
            # Safely get connection info for error reporting
            safe_connection_info = {}
            if self.connection_config:
                safe_connection_info = {
                    "service": self.connection_config.service,
                    "workspace": self.connection_config.workspace,
                    "instance": self.connection_config.instance
                }
            else:
                safe_connection_info = {
                    "error": f"Invalid connection configuration type: {type(self.connection_config)}"
                }

            raise ConnectionException(
                f"Failed to connect to ClickZetta Lakehouse: {str(e)}",
                connection_info=safe_connection_info,
                cause=e
            )

    def _fetch_managed_workspaces(self):
        """获取管理的workspace信息（可选操作）"""
        try:
            # 使用Enhanced Lakehouse客户端执行查询
            result_json = self.lakehouse_client.run_sql("SHOW CATALOGS WHERE category='MANAGED'", None)
            import json
            result_data = json.loads(result_json)

            if isinstance(result_data, list) and len(result_data) > 0:
                self.managed_workspace = [row.get('workspace_name', '') for row in result_data if
                                          'workspace_name' in row]
            else:
                self.managed_workspace = []

            logger.debug(f"获取到管理的workspace: {self.managed_workspace}")
        except Exception as workspace_error:
            logger.warning(f"获取管理workspace失败，使用空列表: {workspace_error}")
            self.managed_workspace = []

    def execute_query(
            self,
            query: str,
            use_cache: bool = False,
            cache_ttl: int = 300
    ) -> Tuple[List[Dict[str, Any]], str]:
        """
        执行SQL查询并返回结果（支持缓存）

        Args:
            query: SQL查询语句
            use_cache: 是否使用缓存（默认False，优先保证查询实时性）
            cache_ttl: 缓存TTL(秒)

        Returns:
            Tuple[查询结果列表, 数据ID]

        Raises:
            QueryExecutionException: 查询执行失败时抛出
        """
        try:
            # 尝试从缓存获取结果
            if use_cache and self.enable_query_cache and self._prefetch_cache:
                cached_result = self._prefetch_cache.get_cached_query_result(query)
                if cached_result is not None:
                    data_id = str(uuid.uuid4())
                    logger.debug(f"查询缓存命中，返回{len(cached_result)}行结果")
                    return cached_result, data_id

            # 检查连接状态并重新连接（如需要）
            if not self.lakehouse_client or time.time() - self.auth_time > self.AUTH_EXPIRATION_TIME:
                logger.debug("会话已过期，重新初始化连接")
                self._init_lakehouse_connection()

            logger.debug(f"执行查询: {query[:100]}..." if len(query) > 100 else f"执行查询: {query}")

            # 使用Enhanced Lakehouse客户端执行查询
            result_json = self.lakehouse_client.run_sql(query, None)

            # 解析JSON结果
            import json
            if result_json and result_json != "{}":
                result_rows = json.loads(result_json)
                if not isinstance(result_rows, list):
                    result_rows = []
            else:
                result_rows = []

            data_id = str(uuid.uuid4())

            # 缓存查询结果
            if use_cache and self.enable_query_cache and self._prefetch_cache:
                # 对于某些查询类型启用缓存
                if self._should_cache_query(query):
                    self._prefetch_cache.cache_query_result(query, result_rows, cache_ttl)

            logger.debug(f"查询成功，返回{len(result_rows)}行结果")
            return result_rows, data_id

        except (ConnectionException, ConfigurationException) as e:
            logger.error(f"Connection error during query: {query[:50]}, e:{e}")
            raise  # 重新抛出连接和配置异常
        except Exception as e1:
            logger.warning(f'查询执行失败 "{query[:100]}...": {e1}')
            raise QueryExecutionException(
                f"查询执行失败: {str(e1)}",
                query=query,
                cause=e1
            )

    def _should_cache_query(self, query: str) -> bool:
        """
        判断查询是否应该被缓存
        
        Args:
            query: SQL查询语句
            
        Returns:
            是否应该缓存
        """
        query_lower = query.lower().strip()

        # 缓存以下类型的查询：
        cache_patterns = [
            "select",  # 查询操作
            "show tables",  # 元数据查询
            "show catalogs",  # 目录查询
            "show schemas",  # 模式查询
            "describe",  # 描述操作
            "information_schema"  # 信息模式查询
        ]

        # 不缓存以下类型的查询：
        no_cache_patterns = [
            "insert", "update", "delete",  # 写操作
            "create", "drop", "alter",  # DDL操作
            "grant", "revoke",  # 权限操作
            "use ", "set ",  # 会话操作
        ]

        # 检查是否为不应缓存的查询
        for pattern in no_cache_patterns:
            if pattern in query_lower:
                return False

        # 检查是否为应该缓存的查询
        for pattern in cache_patterns:
            if pattern in query_lower:
                return True

        # 默认不缓存未知类型的查询
        return False

    def add_insight(self, insight: str) -> None:
        """
        添加数据洞察
        
        Args:
            insight: 洞察内容
        """
        if insight and insight.strip():
            self.insights.append(insight.strip())
            logger.debug(f"添加洞察: {insight[:50]}...")

    def get_memo(self) -> str:
        """
        生成数据洞察备忘录
        
        Returns:
            格式化的洞察备忘录
        """
        if not self.insights:
            return "暂无数据洞察。"

        memo = "📊 数据洞察备忘录 📊\n\n"
        memo += "关键发现:\n\n"
        memo += "\n".join(f"- {insight}" for insight in self.insights)

        if len(self.insights) > 1:
            memo += f"\n\n总结:\n分析发现了 {len(self.insights)} 个关键数据洞察，"
            memo += "为战略优化和增长提供了机会。"

        return memo

    def get_connection_info(self) -> Dict[str, Any]:
        """
        获取连接信息（用于调试和监控）
        
        Returns:
            连接信息字典
        """
        if not self.connection_config:
            return {
                "error": f"Invalid connection configuration type: {type(self.connection_config)}",
                "config_value": str(self.connection_config)
            }

        info = {
            "service": self.connection_config.service,
            "workspace": self.connection_config.workspace,
            "schema": self.connection_config.schema,
            "vcluster": self.connection_config.vcluster,
            "instance": self.connection_config.instance,
            "connected": self.lakehouse_client is not None,
            "auth_time": self.auth_time,
            "time_since_auth": time.time() - self.auth_time if self.auth_time else 0,
            "managed_workspaces": self.managed_workspace,
            "performance_features": {
                "query_cache_enabled": self.enable_query_cache
            }
        }

        # Add cache statistics
        if self.enable_query_cache and self._prefetch_cache:
            info["performance_features"]["prefetch_cache_stats"] = self._prefetch_cache.get_stats()

        return info

    def close(self):
        """关闭连接"""
        if self.lakehouse_client:
            try:
                self.lakehouse_client.close()
                logger.debug("Enhanced Lakehouse连接已关闭")
            except Exception as e:
                logger.warning(f"关闭连接时发生错误: {e}")
            finally:
                self.lakehouse_client = None
                self.auth_time = 0


def handle_tool_errors(operation_name: Optional[str] = None):
    """
    工具错误处理装饰器

    将异常转换为MCP兼容的响应格式。

    Args:
        operation_name: 操作名称，用于上下文信息
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs) -> List[types.TextContent]:
            try:
                return func(*args, **kwargs)
            except MCPBaseException as mcp_exc:
                # MCP异常直接处理
                error_info = mcp_exc.to_dict()
                logger.error(f"MCP异常在 {operation_name or func.__name__}: {error_info}")
                return [types.TextContent(
                    type="text",
                    text=f"错误 [{mcp_exc.error_code}]: {mcp_exc.message}"
                )]
            except Exception as e:
                # 普通异常映射为MCP异常
                mcp_exc = map_exception(e, context=operation_name or func.__name__)
                error_info = mcp_exc.to_dict()
                logger.error(f"未处理异常在 {operation_name or func.__name__}: {error_info}")
                return [types.TextContent(
                    type="text",
                    text=f"错误 [{mcp_exc.error_code}]: {mcp_exc.message}"
                )]

        return wrapper

    return decorator


class MCPServerCore:
    """
    MCP服务器核心类
    
    管理服务器的核心功能，包括连接池、工具注册、缓存等。
    """

    def __init__(self, enable_connection_pool: bool = True):
        self.db: Optional[EnhancedLakehouseDB] = None
        self.connection_config: Optional[StudioConfig] = None
        self.tool_registry = None
        self._initialized = False

        # 移除连接池 - 简化为单一连接模式
        self.enable_connection_pool = False  # 强制禁用连接池
        logger.info("连接池已禁用，使用简化的单一连接模式")

    def initialize(
            self,
            connection_config: Optional[StudioConfig] = None
    ):
        """
        初始化服务器核心

        Args:
            connection_config: StudioConfig 实例
        """
        try:
            logger.info("Initializing MCP Server Core")

            self.connection_config: Optional[StudioConfig] = connection_config
            self.db = EnhancedLakehouseDB.create_from_connection_config(connection_config)
            self._initialized = True

            logger.info("MCP Server Core initialization completed")

        except Exception as e:
            logger.error(f"Server core initialization failed: {e}")
            raise ConfigurationException(
                f"MCP Server Core initialization failed: {str(e)}",
                cause=e
            )

    def update_connection_config(
            self,
            connection_config: StudioConfig
    ):
        """
        更新服务器连接配置并重新创建数据库连接

        用于HTTP模式下每个请求动态更新连接配置

        Args:
            connection_config: StudioConfig 实例，包含新的连接配置
        """
        try:
            # Check if config actually changed to avoid unnecessary reconnection
            config_changed = (
                    not self.connection_config or
                    self.connection_config.service != connection_config.service or
                    self.connection_config.workspace != connection_config.workspace or
                    self.connection_config.vcluster != connection_config.vcluster or
                    self.connection_config.instance != connection_config.instance or
                    self.connection_config.schema != connection_config.schema or
                    self.connection_config.token != connection_config.token
            )

            if config_changed:
                logger.info(f"Connection config changed, updating database connection: service={connection_config.service}, "
                            f"workspace={connection_config.workspace}, vcluster={connection_config.vcluster}, "
                            f"instance={connection_config.instance}, schema={connection_config.schema}")

                # Update stored config
                self.connection_config = connection_config

                # Create new database instance with updated config
                new_db = EnhancedLakehouseDB.create_from_connection_config(connection_config)

                # Replace old database instance
                self.set_db_instance(new_db)

                logger.info("Database connection updated successfully")
            else:
                logger.debug("Connection config unchanged, skipping database reconnection")

        except Exception as e:
            logger.error(f"Failed to update connection config: {e}")
            raise ConfigurationException(
                f"Failed to update connection config: {str(e)}",
                cause=e
            )

    def is_initialized(self) -> bool:
        """检查服务器是否已初始化"""
        return self._initialized

    def get_db(self) -> EnhancedLakehouseDB:
        """
        获取数据库实例（简化版本 - 单一连接模式）
        
        Returns:
            EnhancedLakehouseDB实例
            
        Raises:
            ConfigurationException: 如果数据库未初始化
        """
        # 简化为单一连接模式
        if not self.db:
            raise ConfigurationException("数据库连接未初始化")
        return self.db

    def set_db_instance(self, new_db: EnhancedLakehouseDB):
        """
        设置新的数据库实例（原子性操作）
        
        Args:
            new_db: 新的EnhancedLakehouseDB实例
        """
        old_db = self.db

        # 原子性设置新连接
        self.db = new_db

        # 关闭旧连接
        if old_db and old_db != new_db:
            try:
                old_db.close()
            except Exception as e:
                logger.warning(f"关闭旧数据库连接时出现警告: {e}")

    def get_db_connection(self, connection_config: StudioConfig) -> EnhancedLakehouseDB:
        """
        获取数据库连接（简化版本 - 直接创建）
        
        Args:
            connection_config: StudioConfig实例或字典(向后兼容)
            
        Returns:
            EnhancedLakehouseDB实例
        """
        # Support backward compatibility with dict
        if isinstance(connection_config, dict):
            connection_config = StudioConfig.from_dict(connection_config)

        # Create new connection
        return EnhancedLakehouseDB(connection_config)

    def return_db_connection(self, db_connection: EnhancedLakehouseDB):
        """
        处理数据库连接（单连接模式 - 无需处理）
        
        Args:
            db_connection: 要处理的连接
            
        Note:
            单连接模式下，连接由server_core统一管理，无需归还或关闭
        """
        # 单连接模式：连接由server_core统一管理，不需要额外处理
        pass

    def clear_old_connections(self, current_config: StudioConfig):
        """
        简化版本 - 无需清理连接池
        
        Args:
            current_config: 当前活跃的连接配置（保持接口兼容）
        """
        logger.debug("单一连接模式，无需清理连接池")

    def shutdown(self):
        """关闭服务器核心"""
        logger.info("关闭MCP服务器核心")

        # 关闭数据库连接
        if self.db:
            self.db.close()

        # 单一连接模式，无需关闭连接池

        self._initialized = False
        logger.info("MCP服务器核心已关闭")

    def get_server_stats(self) -> Dict[str, Any]:
        """
        获取服务器统计信息
        
        Returns:
            统计信息字典
        """
        stats = {
            "initialized": self._initialized,
            "connection_pool_enabled": self.enable_connection_pool
        }

        # 单一连接模式，无连接池统计信息

        # 添加数据库连接信息
        if self.db:
            stats["database_info"] = self.db.get_connection_info()

        return stats


# 用于向后兼容的函数
def prefetch_tables(db: EnhancedLakehouseDB, credentials: Dict) -> Dict:
    """
    预取表和列信息（优化版，支持缓存）

    Args:
        db: 数据库实例
        credentials: 连接凭证

    Returns:
        预取的表信息
    """
    try:
        workspace = credentials.get('workspace')
        schema = credentials.get('schema', '').upper()

        if not workspace or not schema:
            raise ConfigurationException(
                "预取表信息需要workspace和schema配置",
                details={"workspace": workspace, "schema": schema}
            )

        # 尝试从缓存获取表信息
        if db.enable_query_cache and db._prefetch_cache:
            cached_info = db._prefetch_cache.get_table_info(workspace, schema)
            if cached_info:
                logger.info(f"从缓存获取了 {len(cached_info)} 个表的信息")
                return cached_info

        logger.info("预取表描述信息")

        # 查询表信息
        table_query = f"""
            SELECT table_name, comment
            FROM {workspace}.information_schema.tables
            WHERE table_schema = '{schema}'
        """
        table_results, _ = db.execute_query(table_query, use_cache=True, cache_ttl=1800)

        # 查询列信息
        column_query = f"""
            SELECT table_name, column_name, data_type, comment
            FROM {workspace}.information_schema.columns
            WHERE table_schema = '{schema}'
        """
        column_results, _ = db.execute_query(column_query, use_cache=True, cache_ttl=1800)

        # 组织结果
        tables_info = {}
        for table in table_results:
            table_name = table['table_name']
            tables_info[table_name] = {
                'comment': table.get('comment', ''),
                'columns': []
            }

        for column in column_results:
            table_name = column['table_name']
            if table_name in tables_info:
                tables_info[table_name]['columns'].append({
                    'name': column['column_name'],
                    'type': column['data_type'],
                    'comment': column.get('comment', '')
                })

        # 缓存表信息
        if db.enable_query_cache and db._prefetch_cache:
            db._prefetch_cache.cache_table_info(workspace, schema, tables_info)

        logger.info(f"成功预取了 {len(tables_info)} 个表的信息")
        return tables_info

    except Exception as e:
        logger.warning(f"预取表信息失败: {e}")
        raise QueryExecutionException(
            f"预取表信息失败: {str(e)}",
            cause=e
        )
