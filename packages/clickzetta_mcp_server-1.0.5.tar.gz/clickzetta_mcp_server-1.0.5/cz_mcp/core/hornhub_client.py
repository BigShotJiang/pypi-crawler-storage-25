import hashlib
import typing

import httpx
from pydantic import BaseModel


class CheckAccessTokenRequest(BaseModel):
    accountId: int | None = None
    tokenHash: str


class HornhubResponse(BaseModel):
    code: int
    message: str | None
    msg: str | None
    data: typing.Any | None
    exDefinition: typing.Any | None
    timestamp: int
    shortCode: int


class BaseUser(BaseModel):
    id: int
    email: str | None
    phone: str | None
    name: str
    realName: str | None
    displayName: str | None
    accountId: int
    status: int
    type: int
    password: str | None
    createTime: str | None


class ServiceInstance(BaseModel):
    id: int
    orderId: int | None
    cspId: int | None
    regionId: int | None
    serviceId: int | None
    serviceVersionId: int | None
    creatorUserId: int | None
    menderUserId: int | None
    status: int
    accountId: int
    name: str
    code: str | None
    createTime: str | None


class HornhubError(Exception):
    """Exception related to operation with Hornhub."""


class HornhubClient:
    _TIMEOUT = httpx.Timeout(10.0, connect=20.0)

    _HEADERS = {
        "Content-Type": "application/json",
        "Accept": "application/json",
    }

    CHECK_ACCESS_TOKEN_PATH = "/clickzetta-hornhub/hornhub/user/checkUserByAccessToken"
    GET_INSTANCE_PATH = "/clickzetta-hornhub/hornhub/service/getInstanceOnlyByName"

    def __init__(self, server_address: str):
        if "://" not in server_address:
            server_address = "http://" + server_address
        self.client = httpx.AsyncClient(
            headers=self._HEADERS,
            timeout=self._TIMEOUT,
            base_url=server_address,
        )

    async def close(self):
        if self.client is not None:
            await self.client.aclose()

    async def check_access_token(self, token: str) -> BaseUser:
        token_hash = self.generate_token_hash(token)
        request = CheckAccessTokenRequest(tokenHash=token_hash)
        request_json = request.model_dump(by_alias=True, mode="json", exclude_none=True)
        response = await self.client.post(self.CHECK_ACCESS_TOKEN_PATH, json=request_json)
        data = self._extract_response_data(response)
        return BaseUser.model_validate(data)

    async def get_instance(self, instance_name: str) -> ServiceInstance:
        params = {"instanceName": instance_name}
        response = await self.client.get(self.GET_INSTANCE_PATH, params=params)
        data = self._extract_response_data(response)
        return ServiceInstance.model_validate(data)

    @staticmethod
    def generate_token_hash(token: str) -> str:
        return hashlib.sha256(token.encode()).hexdigest()

    @staticmethod
    def _extract_response_data(response: httpx.Response) -> typing.Any:
        response.raise_for_status()
        message = HornhubResponse.model_validate(response.json())
        if message.code != 0:
            raise HornhubError(f"Request failed: {message}")
        return message.data
