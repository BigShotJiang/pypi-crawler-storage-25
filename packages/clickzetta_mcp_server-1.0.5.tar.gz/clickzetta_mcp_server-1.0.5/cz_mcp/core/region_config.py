"""
Region Configuration and Mapping
使用官方 region_id 作为标准区域标识符
"""
import configparser
import os
from enum import Enum
from typing import Dict, Optional
from urllib.parse import urlparse


class Region(str, Enum):
    """ClickZetta 支持的区域枚举（使用官方 region_id）"""

    # 测试环境
    DEV = "dev"
    SIT = "sit"
    UAT = "uat"

    # 阿里云
    CN_SHANGHAI_ALICLOUD = "cn-shanghai-alicloud"
    AP_SOURCE_1_ALICLOUD = "ap-southeast-1-alicloud"

    # 腾讯云
    AP_SHANGHAI_TENCENTCLOUD = "ap-shanghai-tencentcloud"
    AP_BEIJING_TENCENTCLOUD = "ap-beijing-tencentcloud"
    AP_GUANGZHOU_TENCENTCLOUD = "ap-guangzhou-tencentcloud"

    # AWS
    AP_SOURCE_1_AWS = "ap-southeast-1-aws"

    # 快手
    KUAISHOU = "kuaishou"
    KUAISHOU_SGP = "kuaishou-sgp"

    # 高途
    GAOTU = "gaotu-ap-beijing-tencentcloud"


# Region 别名映射（用于用户友好的输入）
REGION_ALIASES: Dict[str, str] = {
    # 测试环境
    "dev": Region.DEV.value,
    "sit": Region.SIT.value,
    "uat": Region.UAT.value,
    "开发": Region.DEV.value,
    "开发环境": Region.DEV.value,
    "验收": Region.UAT.value,
    "验收环境": Region.UAT.value,

    # 阿里云
    "aliyun": Region.CN_SHANGHAI_ALICLOUD.value,  # 默认上海
    "阿里云": Region.CN_SHANGHAI_ALICLOUD.value,
    "阿里云环境": Region.CN_SHANGHAI_ALICLOUD.value,
    "阿里云上海": Region.CN_SHANGHAI_ALICLOUD.value,
    "华东2": Region.CN_SHANGHAI_ALICLOUD.value,
    "华东2（上海）": Region.CN_SHANGHAI_ALICLOUD.value,
    Region.CN_SHANGHAI_ALICLOUD.value: Region.CN_SHANGHAI_ALICLOUD.value,
    # 腾讯云
    "tencent": Region.AP_SHANGHAI_TENCENTCLOUD.value,  # 默认上海
    "腾讯云": Region.AP_SHANGHAI_TENCENTCLOUD.value,
    "腾讯云环境": Region.AP_SHANGHAI_TENCENTCLOUD.value,
    "腾讯云上海": Region.AP_SHANGHAI_TENCENTCLOUD.value,
    "华东地区（上海）": Region.AP_SHANGHAI_TENCENTCLOUD.value,
    "腾讯云北京": Region.AP_BEIJING_TENCENTCLOUD.value,
    "华北地区（北京）": Region.AP_BEIJING_TENCENTCLOUD.value,
    "腾讯云广州": Region.AP_GUANGZHOU_TENCENTCLOUD.value,
    "华南地区（广州）": Region.AP_GUANGZHOU_TENCENTCLOUD.value,
    Region.AP_SHANGHAI_TENCENTCLOUD.value: Region.AP_SHANGHAI_TENCENTCLOUD.value,
    Region.AP_BEIJING_TENCENTCLOUD.value: Region.AP_BEIJING_TENCENTCLOUD.value,
    Region.AP_GUANGZHOU_TENCENTCLOUD.value: Region.AP_GUANGZHOU_TENCENTCLOUD.value,
    # AWS
    "aws新加坡": Region.AP_SOURCE_1_AWS.value,
    Region.AP_SOURCE_1_AWS.value: Region.AP_SOURCE_1_AWS.value,
    Region.AP_SOURCE_1_ALICLOUD.value: Region.AP_SOURCE_1_ALICLOUD.value,
    "阿里云新加坡": Region.AP_SOURCE_1_ALICLOUD.value,
    "亚马逊云": Region.AP_SOURCE_1_AWS.value,

    # 快手
    "kuaishou": Region.KUAISHOU.value,
    "快手": Region.KUAISHOU.value,
    Region.KUAISHOU.value: Region.KUAISHOU.value,
    "kuaishou-sgp": Region.KUAISHOU_SGP.value,
    "快手新加坡": Region.KUAISHOU_SGP.value,
    Region.KUAISHOU_SGP.value: Region.KUAISHOU_SGP.value,

    # 高途
    "gaotu": Region.GAOTU.value,
    "gaotu-ap-beijing-tencentcloud": Region.GAOTU.value,
    "高途": Region.GAOTU.value,
    "高途环境": Region.GAOTU.value,
    Region.GAOTU.value: Region.GAOTU.value,

}


def get_region_by_alias(alias: str, default: Optional[str] = None) -> Optional[str]:
    if not alias:
        return default
    region = REGION_ALIASES.get(alias.lower())
    if not region:
        return default
    return region


def _normalize_service_host(service_url: str) -> str:
    if not service_url:
        return ""
    value = service_url.strip().lower()
    if "://" not in value:
        value = f"https://{value}"
    parsed = urlparse(value)
    host = parsed.netloc or parsed.path
    if "/" in host:
        host = host.split("/", 1)[0]
    return host.strip().rstrip("/")


def get_region_by_service_url(service_url: str, default: Optional[str] = None) -> Optional[str]:
    """Get region key by matching service URL/host against config.ini [URL] values."""
    target_host = _normalize_service_host(service_url)
    if not target_host:
        return default

    config = configparser.ConfigParser()
    config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config", "config.ini")
    config.read(config_path, encoding="utf-8")

    if "URL" not in config:
        return default

    for region_key, configured_url in config["URL"].items():
        configured_host = _normalize_service_host(configured_url)
        if configured_host and configured_host == target_host:
            return region_key

    return default


def get_region_code_by_cregionid(cregionid: str) -> Optional[str]:
    if not cregionid:
        return None
    if cregionid in ("dev", "sit", "uat"):
        return "alicloud"
    else:
        parts = cregionid.split("-")
        return parts[-1].upper() if len(parts) > 0 else None


def get_available_regions() -> Dict[str, Dict[str, str]]:
    """
    获取所有可用区域及其详细信息

    Returns:
        包含所有区域信息的字典
    """
    regions = {}
    for region_enum in Region:
        regions[region_enum.value] = {
            "name": region_enum.value,
        }
    return regions


def get_region_description() -> str:
    """
    获取所有区域的描述信息，用于工具参数描述

    Returns:
        区域描述字符串
    """
    descriptions = [
        "The region id parameter only needs to be passed when the user explicitly requests to use or switch environments in their query."
        " - E.g.: Could you check the failed scheduling tasks of the studio in Alibaba Cloud's Shanghai region?",
        "Region/Environment configuration. Available options(region_id: description):",
        "",
        "Test Environments:",
        "  - dev: Development environment (开发环境)",
        "  - sit: System Integration Test environment (稳定SIT测试环境)",
        "  - uat: User Acceptance Test environment (验收环境)",
        "",
        "Alibaba Cloud (阿里云):",
        "  - cn-shanghai-alicloud: 华东2（上海）Aliases: aliyun, 阿里云上海, 阿里云环境, 华东2",
        "",
        "Alibaba Cloud (阿里云新加坡):",
        "  - ap-southeast-1-alicloud: 新加坡 Aliases: 阿里云新加坡, aliyun singapore",
        "",
        "Tencent Cloud (腾讯云):",
        "  - ap-shanghai-tencentcloud: 华东地区（上海）Aliases: tencent, 腾讯云, 腾讯云环境",
        "  - ap-beijing-tencentcloud: 华北地区（北京）Aliases: 腾讯云北京, 华北地区（北京）",
        "  - ap-guangzhou-tencentcloud: 华南地区（广州）Aliases: 腾讯云广州, 华南地区（广州）",
        "",
        "AWS (亚马逊云):",
        "  - ap-southeast-1-aws: 新加坡 Aliases: aws新加坡, 亚马逊云, aws singapore",
        "",
        "Kuaishou (快手):",
        "  - kuaishou: 快手环境 Aliases: 快手, kuaishou",
        "  - kuaishou-sgp: 快手新加坡 Aliases: 快手新加坡, kuaishou-sgp",
        "",
        "Gaotu (高途):",
        "  - gaotu-ap-beijing-tencentcloud: 高途环境 Aliases: 高途, 高途环境, gaotu",
        "",
        "Usage:",
        "  You can use either the official region_id.",
        "  Examples: 'cn-shanghai-alicloud' refer to Alibaba Cloud Shanghai.",
        "",
        "Priority: If specified, this takes highest priority over header values."
    ]
    return "\n".join(descriptions)
