"""
Enhanced Lakehouse Client with Clickzetta Connect API Integration
Supports both native gRPC client and clickzetta connect API
"""
import json
import logging
from dataclasses import dataclass
from typing import Any

from clickzetta import connect

from ..common.utilities import json_serializer

from loguru import logger

@dataclass
class Column:
    column_name: str
    column_type: dict[str, Any]
    comment: str

@dataclass
class Table:
    instance: str
    workspace: str
    schema: str
    table_name: str
    table_type: str
    columns: list[Column]
    partition_key: list[str]
    cluster_key: list[str]
    sort_key: list[str]
    primary_key: list[str]
    comment: str
    record_count: int
    size_in_bytes: int
    total_data_files: int

@dataclass 
class ClickzettaConnectionParams:
    """Connection parameters for clickzetta connect API"""
    magic_token: str
    instance: str
    service: str
    workspace: str
    vcluster: str = "DEFAULT"
    schema: str = "public"


class EnhancedLakehouseClient:
    """
    Enhanced Lakehouse Client that supports both native gRPC and clickzetta connect API
    """
    
    def __init__(
        self,
        coordinator_address: str = None,
        meta_address: str = None,
        connection_params: ClickzettaConnectionParams = None
    ):
        """
        Initialize client with either gRPC addresses or connection parameters
        
        Args:
            coordinator_address: gRPC coordinator address (for native mode)
            meta_address: gRPC metadata address (for native mode) 
            connection_params: Clickzetta connection parameters (for connect API mode)
        """
        self.coordinator_address = coordinator_address
        self.meta_address = meta_address
        self.connection_params = connection_params
        
        # Native gRPC client (when using coordinator/meta addresses)
        self._native_client = None
        
        # Clickzetta connect API connection (when using connection params)
        self._connect_conn = None
        self._connect_cursor = None
        
        # Determine which mode to use
        self.use_connect_api = connection_params is not None
        
    def connect(self):
        """Establish connection based on mode"""
        if self.use_connect_api:
            self._connect_via_api()
        else:
            self._connect_via_grpc()
    
    def _connect_via_grpc(self):
        """Connect using native gRPC client"""
        if not self.coordinator_address or not self.meta_address:
            raise ValueError("coordinator_address and meta_address are required for gRPC mode")
        from mcp_clickzetta.lakehouse import (
            LakehouseClient as BaseLakehouseClient
        )

        self._native_client = BaseLakehouseClient(
            self.coordinator_address,
            self.meta_address
        )
        self._native_client.connect()
        logger.info("Connected via native gRPC client")
    
    def _connect_via_api(self):
        """Connect using clickzetta connect API"""
        try:
            if self.connection_params.schema:
                self._connect_conn = connect(
                    magic_token=self.connection_params.magic_token,
                    instance=self.connection_params.instance,
                    service=self.connection_params.service,
                    workspace=self.connection_params.workspace,
                    vcluster=self.connection_params.vcluster,
                    schema=self.connection_params.schema
                )
            else:
                self._connect_conn = connect(
                    magic_token=self.connection_params.magic_token,
                    instance=self.connection_params.instance,
                    service=self.connection_params.service,
                    workspace=self.connection_params.workspace,
                    vcluster=self.connection_params.vcluster,
                )
            self._connect_cursor = self._connect_conn.cursor()

            logger.info(
                f"Connected via clickzetta connect API: instance={self.connection_params.instance}, "
                f"service={self.connection_params.service}, workspace={self.connection_params.workspace}, "
                f"vcluster={self.connection_params.vcluster}, schema={self.connection_params.schema}")

        except ImportError:
            raise Exception("clickzetta package not available for connect API")
        except Exception as e:
            raise Exception(f"Failed to connect via clickzetta API: {e}")
    
    def close(self):
        """Close connections"""
        if self._native_client:
            self._native_client.close()

        if self._connect_cursor:
            self._connect_cursor.close()

        if self._connect_conn:
            self._connect_conn.close()
    
    def run_sql(self, sql: str, context) -> str:
        """Execute SQL query"""
        if self.use_connect_api:
            return self._run_sql_via_api(sql)
        else:
            return self._native_client.run_sql(sql, context)
    
    def _run_sql_via_api(self, sql: str) -> str:
        """Execute SQL using clickzetta connect API"""
        try:
            # Add hints for proper result formatting
            params = {'hints': {}}

            # Execute query
            self._connect_cursor.execute(sql, params)
            result = self._connect_cursor.fetchall()

            # Convert result to JSON format for consistency
            if result:
                # Convert rows to list of dictionaries
                columns = [desc[0] for desc in self._connect_cursor.description]
                rows = []
                for row in result:
                    row_dict = dict(zip(columns, row))
                    rows.append(row_dict)

                return json.dumps(rows, default=json_serializer)
            else:
                return "{}"

        except Exception as e:
            logger.error(f"SQL execution failed via connect API: {e}")
            raise Exception(f"SQL execution failed: {e}")


def create_lakehouse_client_from_token(
    magic_token: str,
    instance: str,
    service: str,
    workspace: str,
    vcluster: str = "DEFAULT",
    schema: str = "public"
) -> EnhancedLakehouseClient:
    """
    Create lakehouse client using magic token (for HTTP transport)
    
    Args:
        magic_token: JWT token for authentication
        instance: Clickzetta instance ID
        service: Service endpoint
        workspace: Workspace name
        vcluster: Virtual cluster name
        schema: Default schema name
        
    Returns:
        Configured EnhancedLakehouseClient
    """
    connection_params = ClickzettaConnectionParams(
        magic_token=magic_token,
        instance=instance,
        service=service,
        workspace=workspace,
        vcluster=vcluster,
        schema=schema
    )
    
    return EnhancedLakehouseClient(connection_params=connection_params)


def create_lakehouse_client_from_grpc(
    coordinator_address: str,
    meta_address: str
) -> EnhancedLakehouseClient:
    """
    Create lakehouse client using gRPC addresses (for STDIO transport)
    
    Args:
        coordinator_address: gRPC coordinator address
        meta_address: gRPC metadata address
        
    Returns:
        Configured EnhancedLakehouseClient
    """
    return EnhancedLakehouseClient(
        coordinator_address=coordinator_address,
        meta_address=meta_address
    )
