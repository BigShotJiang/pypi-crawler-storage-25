# -*- coding: utf-8 -*-
import os
import sys
from typing import Dict, Any
from pathlib import Path
import logging
from loguru import logger

APP_NAME = "clickzetta-mcp-server"
_VALID_LOG_LEVELS = {"TRACE", "DEBUG", "INFO", "SUCCESS", "WARNING", "ERROR", "CRITICAL"}

DEVELOP_MODE = os.environ.get("DEVELOP_MODE", "DEV")
TRANSPORT_MODE = os.environ.get("CZ_MCP_TRANSPORT", "http").lower()
_log_to_file_env = os.environ.get("CZ_MCP_LOG_TO_FILE")
if _log_to_file_env is not None:
    LOG_TO_FILE = _log_to_file_env.lower() in {"1", "true", "yes", "on"}
else:
    # Default behavior: stdio mode outputs only to stdout.
    LOG_TO_FILE = TRANSPORT_MODE != "stdio"
APP_LOG_PATH_OVERRIDE = os.environ.get("APP_LOG_PATH")
_raw_log_level = os.environ.get("CZ_MCP_LOG_LEVEL", "INFO").strip().upper()
if _raw_log_level not in _VALID_LOG_LEVELS:
    LOG_LEVEL = "INFO"
else:
    LOG_LEVEL = _raw_log_level

PID = os.getpid()

resolved_log_path = None
if APP_LOG_PATH_OVERRIDE:
    resolved_log_path = Path(APP_LOG_PATH_OVERRIDE)
elif DEVELOP_MODE == "PROD":
    resolved_log_path = Path(f"/cz/cz-mcp-server/{APP_NAME}")
elif _log_to_file_env is not None and _log_to_file_env:
    resolved_log_path = Path(f"./logs/{APP_NAME}")

LOG_FORMAT = (
        "{time:YYYY-MM-dd HH:mm:ss} |<lvl>{level:1}</>|"
        + f"[{PID}] "
        + "{name}:{line:1}: <lvl>{message}</>"
)

logger.remove()

logger.add(
    sys.stdout,
    format=LOG_FORMAT,
    level=LOG_LEVEL,
    backtrace=True,
    colorize=False,
    diagnose=True,
    catch=True
)

if LOG_TO_FILE:
    try:
        resolved_log_path.mkdir(parents=True, exist_ok=True)

        logger.add(
            resolved_log_path / f"info.{APP_NAME}.log.{PID}-{{time:YYYY-MM-DD}}.log",
            format=LOG_FORMAT,
            level=LOG_LEVEL,
            rotation="500 MB",
            retention="7 days",
            encoding="utf-8",
            colorize=False,
            diagnose=True,
            catch=True
        )

        logger.add(
            resolved_log_path / f"error.{APP_NAME}.log.{{time:YYYY-MM-DD}}.log",
            format=LOG_FORMAT,
            level="ERROR",
            rotation="500 MB",
            retention="7 days",
            encoding="utf-8",
            filter=lambda record: record["level"].name == "ERROR",
            colorize=True,
            diagnose=True,
            catch=True
        )

        logger.add(
            resolved_log_path / f"warn.{APP_NAME}.log.{{time:YYYY-MM-DD}}.log",
            format=LOG_FORMAT,
            level="WARNING",
            rotation="500 MB",
            retention="7 days",
            encoding="utf-8",
            filter=lambda record: record["level"].name == "WARNING",
            colorize=True,
            diagnose=True,
            catch=True
        )
    except Exception as e:
        print(f"file logging disabled due to APP_LOG_PATH error: {e}")
else:
    print("file logging disabled (CZ_MCP_LOG_TO_FILE=0)")

SANIC_LOGGING_CONFIG_DEFAULTS: Dict[str, Any] = dict(  # no cov
    version=1,
    disable_existing_loggers=False,
    datefmt='%Y-%M-%D %H:%M:%S',
    loggers={
        "sanic.root": {"level": LOG_LEVEL, "handlers": ["console"], "propagate": False},
        "sanic.error": {
            "level": LOG_LEVEL,
            "handlers": ["error_console"],
            "propagate": False,
            "qualname": "sanic.error",
        },
        "sanic.access": {
            "level": LOG_LEVEL,
            "handlers": ["access_console"],
            "propagate": False,
            "qualname": "sanic.access",
        },
        "sanic.server": {
            "level": LOG_LEVEL,
            "handlers": ["console"],
            "propagate": False,
            "qualname": "sanic.server",
        },
    },
    handlers={
        "console": {
            "class": "logger.InterceptHandler",
        },
        "error_console": {
            "class": "logger.InterceptHandler",
        },
        "access_console": {
            "class": "logger.InterceptHandler",
        },
    }
)


class InterceptHandler(logging.Handler):
    def emit(self, record: logging.LogRecord):
        try:
            level = logger.level(record.levelname).name
        except ValueError:
            level = record.levelno
        # Find caller from where originated the logged message
        frame, depth = logging.currentframe(), 2
        while frame.f_code.co_filename == logging.__file__:
            frame = frame.f_back
            depth += 1

        logger.opt(depth=depth, exception=record.exc_info).log(level, record.getMessage())


def setup_log():
    py_level = getattr(logging, LOG_LEVEL, logging.INFO)
    logging.root.handlers = [InterceptHandler()]
    logging.root.setLevel(py_level)
    for name in logging.root.manager.loggerDict.keys():
        logging.getLogger(name).handlers = []
        logging.getLogger(name).propagate = True
