import sqlparse
from sqlparse.sql import Token, TokenList
from sqlparse.tokens import Keyword, DML, DDL, Punctuation
from typing import Dict, List, Set, Tuple


class SQLWriteDetector:
    def __init__(self):
        # Define sets of keywords that indicate write operations
        # Note: UPSERT is not standard SQL and not supported by ClickZetta
        # MERGE INTO is fully supported with WHEN MATCHED/NOT MATCHED clauses
        self.dml_write_keywords = {"INSERT", "UPDATE", "DELETE", "MERGE", "TRUNCATE","COPY","PUT","REMOVE","REFRESH","RESTORE"}

        self.ddl_keywords = {"CREATE", "ALTER", "DROP", "UNDROP", "RENAME","REPLACE","CLONE"}

        self.dcl_keywords = {"GRANT", "REVOKE"}

        # Combine all write keywords
        self.write_keywords = self.dml_write_keywords | self.ddl_keywords | self.dcl_keywords

    def analyze_query(self, sql_query: str) -> Dict:
        """
        Analyze a SQL query to determine if it contains write operations.

        Args:
            sql_query: The SQL query string to analyze

        Returns:
            Dictionary containing analysis results
        """
        # Parse the SQL query
        parsed = sqlparse.parse(sql_query)
        if not parsed:
            return {"contains_write": False, "write_operations": set(), "has_cte_write": False}

        # Initialize result tracking
        found_operations = set()
        has_cte_write = False

        # Analyze each statement in the query
        for statement in parsed:
            # Check for write operations in CTEs (WITH clauses)
            if self._has_cte(statement):
                cte_write = self._analyze_cte(statement)
                if cte_write:
                    has_cte_write = True
                    found_operations.add("CTE_WRITE")

            # Analyze the main query
            operations = self._find_write_operations(statement)
            found_operations.update(operations)

        # 确定主要操作类型
        operation_type = self._determine_operation_type(found_operations)

        return {
            "contains_write": bool(found_operations) or has_cte_write,
            "write_operations": found_operations,
            "has_cte_write": has_cte_write,
            "cte_operations": set(),  # 向后兼容
            "operation_type": operation_type
        }

    def _has_cte(self, statement: TokenList) -> bool:
        """Check if the statement has a WITH clause."""
        return any(token.is_keyword and token.normalized == "WITH" for token in statement.tokens)

    def _analyze_cte(self, statement: TokenList) -> bool:
        """
        Analyze CTEs (WITH clauses) for write operations.
        Returns True if any CTE contains a write operation.
        """
        in_cte = False
        paren_depth = 0

        tokens = list(statement.flatten())

        for i, token in enumerate(tokens):
            if token.is_keyword and token.normalized == "WITH":
                in_cte = True
                continue

            if not in_cte:
                continue

            # 跟踪括号深度
            if token.match(Punctuation, '('):
                paren_depth += 1
            elif token.match(Punctuation, ')'):
                paren_depth -= 1

            # 当退出所有CTE括号时，检查是否到主查询
            if in_cte and paren_depth == 0:
                if i + 1 < len(tokens):
                    next_token = tokens[i + 1]
                    if (next_token.is_keyword and
                        next_token.normalized in ("SELECT", "FROM", "WHERE")):
                        in_cte = False
                        continue

            # 在CTE内部时，检查写操作
            if in_cte and paren_depth > 0 and token.is_keyword:
                normalized = token.normalized.upper()
                if normalized in self.write_keywords:
                    return True

        return False

    def _find_write_operations(self, statement: TokenList) -> Set[str]:
        """
        Find all write operations in a statement.
        Returns a set of found write operation keywords.
        """
        operations = set()

        # 首先检查是否是只读的SHOW命令（如SHOW CREATE TABLE）
        if self._is_read_only_show_command(statement):
            return operations  # 返回空集合，表示没有写操作

        # 检查CREATE OR REPLACE模式
        operations.update(self._detect_create_or_replace(statement))

        # 获取所有token用于上下文检查
        all_tokens = list(statement.flatten())

        for i, token in enumerate(all_tokens):
            # Skip comments and whitespace
            if token.is_whitespace or token.ttype in (sqlparse.tokens.Comment,):
                continue

            # Check if token is a keyword (enhanced detection)
            if token.ttype in (Keyword, DML, DDL) or token.is_keyword:
                normalized = token.normalized.upper()
                if normalized in self.write_keywords:
                    # 检查是否是函数调用
                    remaining_tokens = all_tokens[i+1:i+3]  # 检查后面几个token
                    if not self._is_function_call(normalized, remaining_tokens):
                        operations.add(normalized)

            # Additional string-based detection for edge cases
            # This helps catch keywords that sqlparse might not properly categorize
            if hasattr(token, 'normalized'):
                token_str = token.normalized.upper()
                for write_keyword in self.write_keywords:
                    if token_str == write_keyword:
                        # 检查是否是函数调用
                        remaining_tokens = all_tokens[i+1:i+3]
                        if not self._is_function_call(write_keyword, remaining_tokens):
                            operations.add(write_keyword)
                    elif token_str.startswith(write_keyword + ' '):
                        operations.add(write_keyword)

        return operations

    def _is_function_call(self, token_str: str, next_tokens: list) -> bool:
        """
        检测是否是函数调用（如 TRUNCATE(number, decimals)）
        而不是DDL语句（如 TRUNCATE TABLE）
        """
        # 检查后面是否紧跟着左括号，这通常表示函数调用
        if len(next_tokens) > 0:
            next_token = next_tokens[0]
            if hasattr(next_token, 'ttype') and next_token.match(sqlparse.tokens.Punctuation, '('):
                return True
            # 或者检查token本身是否以 ( 结尾
            if token_str.endswith('('):
                return True
        return False

    def _is_read_only_show_command(self, statement: TokenList) -> bool:
        """
        检测是否是只读的SHOW命令，这些命令虽然包含写操作关键字但实际是读操作
        例如：SHOW CREATE TABLE, SHOW CREATE VIEW等
        """
        sql_text = str(statement).upper().strip()

        # 简化：只要是SHOW CREATE开头的命令都视为只读
        return sql_text.startswith("SHOW CREATE")

    def _detect_create_or_replace(self, statement: TokenList) -> Set[str]:
        """
        专门检测CREATE OR REPLACE模式
        """
        operations = set()

        # 字符串匹配检测CREATE OR REPLACE
        sql_text = str(statement).upper()
        if "CREATE OR REPLACE" in sql_text:
            operations.add("CREATE")
            operations.add("REPLACE")

        return operations

    def _determine_operation_type(self, operations: Set[str]) -> str:
        """
        根据检测到的操作确定主要操作类型

        Args:
            operations: 检测到的操作集合

        Returns:
            主要操作类型字符串
        """
        if not operations:
            return "UNKNOWN"

        # 按优先级确定操作类型
        # DDL操作（数据定义语言）
        if "CREATE" in operations:
            return "CREATE"
        elif "ALTER" in operations:
            return "ALTER"
        elif "DROP" in operations:
            return "DROP"
        elif "RENAME" in operations:
            return "RENAME"
        elif "REPLACE" in operations:
            return "REPLACE"
        elif "CLONE" in operations:
            return "CLONE"
        elif "UNDROP" in operations:
            return "UNDROP"

        # DML操作（数据操作语言）
        elif "INSERT" in operations:
            return "INSERT"
        elif "UPDATE" in operations:
            return "UPDATE"
        elif "DELETE" in operations:
            return "DELETE"
        elif "MERGE" in operations:
            return "MERGE"
        # UPSERT operation removed - not supported by ClickZetta
        elif "TRUNCATE" in operations:
            return "TRUNCATE"

        # 数据移动操作
        elif "COPY" in operations:
            return "COPY"
        elif "PUT" in operations:
            return "PUT"
        elif "REMOVE" in operations:
            return "REMOVE"

        # 维护操作
        elif "REFRESH" in operations:
            return "REFRESH"
        elif "RESTORE" in operations:
            return "RESTORE"

        # DCL操作（数据控制语言）
        elif "GRANT" in operations:
            return "GRANT"
        elif "REVOKE" in operations:
            return "REVOKE"

        # CTE写操作
        elif "CTE_WRITE" in operations:
            return "CTE_WRITE"

        # 如果有多个操作，返回第一个检测到的
        else:
            return list(operations)[0]
