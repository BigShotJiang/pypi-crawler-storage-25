"""
MCP ClickZetta Server - 统一异常体系

提供结构化的异常处理，改善错误信息和调试体验。
"""

from datetime import datetime
from typing import Dict, Optional, Any


class MCPBaseException(Exception):
    """MCP服务器基础异常类"""

    def __init__(
        self,
        message: str,
        error_code: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        cause: Optional[Exception] = None
    ):
        """
        初始化MCP异常

        Args:
            message: 错误消息
            error_code: 错误代码，默认为类名
            details: 错误详细信息
            cause: 原始异常
        """
        self.message = message
        self.error_code = error_code or self.__class__.__name__
        self.details = details or {}
        self.cause = cause
        self.timestamp = datetime.utcnow().isoformat()

        super().__init__(message)

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式，便于序列化"""
        return {
            "success": False,
            "error_code": self.error_code,
            "message": self.message,
            "details": self.details,
            "timestamp": self.timestamp,
            "cause": str(self.cause) if self.cause else None
        }


class ConnectionException(MCPBaseException):
    """连接相关异常"""

    def __init__(self, message: str, connection_info: Optional[Dict] = None, **kwargs):
        details = kwargs.get('details', {})
        if connection_info:
            details['connection_info'] = connection_info
        kwargs['details'] = details
        super().__init__(message, **kwargs)


class ToolExecutionException(MCPBaseException):
    """工具执行异常"""

    def __init__(self, message: str, tool_name: Optional[str] = None, **kwargs):
        details = kwargs.get('details', {})
        if tool_name:
            details['tool_name'] = tool_name
        kwargs['details'] = details
        super().__init__(message, **kwargs)


class ValidationException(MCPBaseException):
    """参数验证异常"""

    def __init__(self, message: str, validation_errors: Optional[Dict] = None, **kwargs):
        details = kwargs.get('details', {})
        if validation_errors:
            details['validation_errors'] = validation_errors
        kwargs['details'] = details
        super().__init__(message, **kwargs)


class PermissionException(MCPBaseException):
    """权限相关异常"""

    def __init__(self, message: str, required_permission: Optional[str] = None, **kwargs):
        details = kwargs.get('details', {})
        if required_permission:
            details['required_permission'] = required_permission
        kwargs['details'] = details
        super().__init__(message, **kwargs)


class ConfigurationException(MCPBaseException):
    """配置相关异常"""

    def __init__(self, message: str, config_key: Optional[str] = None, **kwargs):
        details = kwargs.get('details', {})
        if config_key:
            details['config_key'] = config_key
        kwargs['details'] = details
        super().__init__(message, **kwargs)


class TransportException(MCPBaseException):
    """传输层异常"""

    def __init__(self, message: str, transport_type: Optional[str] = None, **kwargs):
        details = kwargs.get('details', {})
        if transport_type:
            details['transport_type'] = transport_type
        kwargs['details'] = details
        super().__init__(message, **kwargs)


class QueryExecutionException(MCPBaseException):
    """查询执行异常"""

    def __init__(self, message: str, query: Optional[str] = None, **kwargs):
        details = kwargs.get('details', {})
        if query:
            # 截断查询以避免日志过长，但保留完整信息用于调试
            details['query'] = query[:500] + "..." if len(query) > 500 else query
            details['query_length'] = len(query)
        kwargs['details'] = details
        super().__init__(message, **kwargs)


# 异常映射：将常见的Python异常映射到MCP异常
EXCEPTION_MAPPING = {
    ConnectionError: ConnectionException,
    TimeoutError: ConnectionException,
    ValueError: ValidationException,
    KeyError: ValidationException,
    AttributeError: ConfigurationException,
    ImportError: ConfigurationException,
    FileNotFoundError: ConfigurationException,
}


def map_exception(exc: Exception, context: Optional[str] = None) -> MCPBaseException:
    """
    将标准Python异常映射为MCP异常

    Args:
        exc: 原始异常
        context: 异常上下文信息

    Returns:
        映射后的MCP异常
    """
    exc_type = type(exc)
    mcp_exc_type = EXCEPTION_MAPPING.get(exc_type, MCPBaseException)

    # 构建详细信息
    details = {}
    if context:
        details['context'] = context
    details['original_exception_type'] = exc_type.__name__

    return mcp_exc_type(
        message=str(exc),
        error_code=f"MAPPED_{exc_type.__name__.upper()}",
        details=details,
        cause=exc
    )