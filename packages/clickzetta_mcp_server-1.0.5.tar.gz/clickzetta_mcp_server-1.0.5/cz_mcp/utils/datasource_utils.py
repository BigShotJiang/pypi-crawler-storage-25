"""Utility functions for working with datasources"""

import json
import logging
import re
from typing import Dict, Any, Optional

from ..handlers import datasource_server
from ..studio_config_manager import StudioConfig
from ..utils.request_utils import RequestUtils
from ..utils.config_utils import read_api, read_url

from loguru import logger

# Create request instance
request = RequestUtils()

def get_datasource_by_name(
    datasource_name: str, 
    server: StudioConfig = None, 
    ds_name: Optional[str] = None,
    ds_type: Optional[int] = None,
    page_index: int = 1,
    page_size: int = 20
) -> Optional[Dict[str, Any]]:
    """
    Get datasource information by name

    Args:
        datasource_name: Name of datasource
        server: Server instance with connection config
        ds_name: Optional datasource name filter for list query
        ds_type: Optional datasource type filter for list query
        page_index: Page index for pagination (default: 1)
        page_size: Page size for pagination (default: 20)

    Returns:
        Datasource information or None if not found
    """
    config = server
    project_id = config.project_id
    token = config.token
    instance_name = config.instance
    env = config.env

    response = datasource_server.datasource_list(
        project_id=project_id,
        ds_name=ds_name,
        ds_type=ds_type,
        jwt_token=token,
        instance_name=instance_name,
        user_id=config.user_id,
        instance_id=config.instance_id,
        account_id=config.tenant_id,
        env=env,
        page_index=page_index,
        page_size=page_size
    )
    try:
        response_data = json.loads(response)

        if response_data.get("code") == "200":
            data = response_data.get("data", {})
            datasources = data.get("list", [])
            for datasource in datasources:
                if datasource.get("dsName") == datasource_name:
                    return datasource

            logger.error(f"Datasource '{datasource_name}' not found")
        return None
        
    except Exception as e:
        logger.error(f"Error getting datasource by name: {e}")
        return None


def check_table_exists(datasource_id: int, schema: str, table: str, server: StudioConfig = None,
                       datasource_type: Optional[int] = None, env=None) -> bool:
    """
    Check if a table exists in the specified datasource

    Args:
        datasource_id: ID of the datasource
        schema: Schema or database name
        table: Table name
        server: Server instance with connection config
        datasource_type: Type of the datasource (5=MySQL, 7=PostgreSQL, 12=MongoDB, etc.)

    Returns:
        True if table exists, False otherwise
    """
    try:
        config = server
        url = read_url(env=env) + read_api("EXECUTE_SQL_URL")
        token = config.token
        instance_id = config.instance
        env = config.env

        # Get datasource type if not provided
        if datasource_type is None:
            datasource_type = _get_datasource_type(datasource_id)

        # Generate SQL based on datasource type
        check_sql = _generate_check_table_sql(datasource_type, schema, table)
        
        if check_sql is None:
            logger.error(f"Unsupported datasource type: {datasource_type}")
            return False

        # API expects only 'id' and 'sql' fields
        request_data = {
            "id": datasource_id,
            "sql": check_sql
        }

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "cz-lang": "zh_CN",
            "env": "prod",
            "instanceid": str(instance_id),
            "instancename": config.instance,
            "x-clickzetta-token": token
        }

        logger.info(f"Checking table existence with SQL: {check_sql}")
        logger.debug(f"Request data: {request_data}")

        # Make the request
        response = request.post(
            url=f"{url}?instanceId={instance_id}",
            data=json.dumps(request_data),
            headers=headers
        )

        if response.status_code != 200:
            logger.error(f"Failed to check table existence: {response.status_code}")
            return False

        response_data = response.json()
        if response_data.get("code") == "200":
            data = response_data.get("data", {})
            # Safely extract data from response
            if isinstance(data, dict):
                rows = data.get('rows', [])
                if rows and len(rows) > 0:
                    data = rows[0]
                    # Recursively extract value if data is still a list/array
                    # e.g., ['0'] -> '0', [['0']] -> '0', etc.
                    while isinstance(data, (list, tuple)) and len(data) > 0:
                        data = data[0]
                else:
                    logger.warning(f"No rows found in response data: {data}")
                    return False
            elif isinstance(data, (list, tuple)):
                # If data is directly a list/tuple, extract recursively
                if len(data) > 0:
                    data = data[0]
                    while isinstance(data, (list, tuple)) and len(data) > 0:
                        data = data[0]
                else:
                    logger.warning(f"Empty list/tuple in response data: {data}")
                    return False
            elif isinstance(data, (str, int, float, bool)):
                # Direct value (for boolean or count results)
                pass
            else:
                logger.warning(f"Unexpected data format: {type(data)}, value: {data}")
                return False
            # Handle different result formats based on datasource type
            if datasource_type in [5, 21, 22, 23, 24]:  # MySQL family
                # MySQL SHOW TABLES returns rows if table exists
                if isinstance(data, str):
                    return len(data) > 0 and data.strip() != ""
                elif isinstance(data, (int, float)):
                    return data > 0
                elif isinstance(data, bool):
                    return data
                else:
                    return bool(data)
                
            elif datasource_type in [7, 18, 19, 25, 26]:  # PostgreSQL family
                # PostgreSQL EXISTS returns boolean
                # Result format might be: "true" or contain "t" or "true"
                data_lower = str(data).lower().strip()
                return "true" in data_lower or "t" == data_lower
                
            elif datasource_type == 12:  # MongoDB
                # MongoDB returns the result of the JavaScript expression
                return "true" in str(data).lower() or "-1" not in str(data)
                
            elif datasource_type in [17, 8, 1]:  # Oracle, SQL Server, Lakehouse
                # These return COUNT, > 0 means table exists
                try:
                    if isinstance(data, (int, float)):
                        return data > 0
                    elif isinstance(data, bool):
                        return data
                    elif isinstance(data, str):
                        # Try to parse as number from string
                        import re
                        numbers = re.findall(r'\d+', data)
                        if numbers:
                            return int(numbers[0]) > 0
                        return len(data) > 0 and data.strip() != ""
                    else:
                        return bool(data)
                except Exception as e:
                    logger.warning(f"Error parsing data for datasource type {datasource_type}: {e}, data: {data}")
                    return bool(data)
                    
            elif datasource_type in [3, 4, 27]:  # Hive, Spark, ClickHouse
                # SHOW TABLES or EXISTS returns rows/boolean
                if isinstance(data, str):
                    return len(data) > 0 and data.strip() != ""
                elif isinstance(data, (int, float)):
                    return data > 0
                elif isinstance(data, bool):
                    return data
                else:
                    return bool(data)
                
            else:
                # Default behavior: any non-empty result means table exists
                if isinstance(data, str):
                    return len(data) > 0 and data.strip() != ""
                elif isinstance(data, (int, float)):
                    return data > 0
                elif isinstance(data, bool):
                    return data
                else:
                    return bool(data)

        return False

    except Exception as e:
        logger.error(f"Error checking table existence: {e}")
        return False


def check_schema_exists(datasource_id: int, schema: str, server: StudioConfig = None,
                        datasource_type: Optional[int] = None, env=None) -> bool:
    """
    Check if a schema/database exists in the specified datasource.
    """
    try:
        config = server
        url = read_url(env=env) + read_api("EXECUTE_SQL_URL")
        token = config.token
        instance_id = config.instance

        if datasource_type is None:
            datasource_type = _get_datasource_type(datasource_id)

        check_sql = _generate_check_schema_sql(datasource_type, schema)
        if check_sql is None:
            logger.warning(f"Unsupported datasource type for schema existence check: {datasource_type}")
            return True

        request_data = {
            "id": datasource_id,
            "sql": check_sql
        }

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "cz-lang": "zh_CN",
            "env": "prod",
            "instanceid": str(instance_id),
            "instancename": config.instance,
            "x-clickzetta-token": token
        }

        logger.info(f"Checking schema existence with SQL: {check_sql}")
        response = request.post(
            url=f"{url}?instanceId={instance_id}",
            data=json.dumps(request_data),
            headers=headers
        )

        if response.status_code != 200:
            logger.error(f"Failed to check schema existence: {response.status_code}")
            return False

        response_data = response.json()
        if response_data.get("code") != "200":
            logger.error(f"Schema existence check failed: {response_data.get('message')}")
            return False

        data = response_data.get("data", {})
        if isinstance(data, dict):
            rows = data.get("rows", [])
            if not rows:
                return False
            data = rows[0]
            while isinstance(data, (list, tuple)) and len(data) > 0:
                data = data[0]
        elif isinstance(data, (list, tuple)):
            if not data:
                return False
            while isinstance(data, (list, tuple)) and len(data) > 0:
                data = data[0]

        if datasource_type in [5, 21, 22, 23, 24, 3, 4]:
            if isinstance(data, str):
                return len(data.strip()) > 0
            if isinstance(data, (int, float)):
                return data > 0
            return bool(data)
        if datasource_type in [7, 18, 19, 25, 26]:
            data_lower = str(data).lower().strip()
            return "true" in data_lower or data_lower == "t"
        if datasource_type in [17, 8, 1, 27]:
            if isinstance(data, (int, float)):
                return data > 0
            if isinstance(data, str):
                numbers = re.findall(r'\d+', data)
                if numbers:
                    return int(numbers[0]) > 0
                return len(data.strip()) > 0
            return bool(data)

        return bool(data)
    except Exception as e:
        logger.error(f"Error checking schema existence: {e}")
        return False


def create_schema_if_not_exists(datasource_id: int, schema: str, server: StudioConfig = None,
                                datasource_type: Optional[int] = None, env=None) -> bool:
    """
    Create a schema/database if it does not already exist.
    """
    if datasource_type is None:
        datasource_type = _get_datasource_type(datasource_id)

    if check_schema_exists(datasource_id, schema, server, datasource_type, env):
        logger.info(f"Schema {schema} already exists in datasource {datasource_id}")
        return True

    create_sql = _generate_create_schema_sql(datasource_type, schema)
    if create_sql is None:
        logger.warning(f"Unsupported datasource type for schema creation: {datasource_type}")
        return False

    logger.info(f"Creating schema {schema} in datasource {datasource_id}")
    return execute_sql(datasource_id, create_sql, env, server)


def create_sink_table_from_source(
    source_datasource_id: int,
    source_datasource_type: int,
    source_schema: str,
    source_table: str,
    sink_datasource_id: int,
    sink_datasource_type: int,
    sink_schema: str,
    sink_table: str,
    server: StudioConfig,
    env
) -> bool:
    """
    Create a sink table based on the structure of a source table.
    This function gets DDL from source table and creates the table in sink datasource.

    Args:
        source_datasource_id: ID of the source datasource
        source_datasource_type: Type of the source datasource (5=MySQL, 7=PostgreSQL, etc.)
        source_schema: Schema/database name in source
        source_table: Table name in source
        sink_datasource_id: ID of the sink datasource
        sink_datasource_type: Type of the sink datasource
        sink_schema: Schema/database name in sink
        sink_table: Table name in sink (can be different from source)
        server: Server instance with connection config

    Returns:
        True if table was created or already exists, False if creation failed
    """
    try:
        # Check if sink table already exists
        if check_table_exists(sink_datasource_id, sink_schema, sink_table, server, sink_datasource_type,env):
            logger.info(f"Table {sink_schema}.{sink_table} already exists in sink datasource")
            return True

        # Table doesn't exist, need to get DDL from source and create it
        logger.info(f"Creating table {sink_schema}.{sink_table} in sink datasource based on {source_schema}.{source_table}")

        config = server
        url = read_url(env=env) + read_api("DATA_SOURCES_GET_DDL")
        token = config.token
        instance_id = config.instance

        # Request to get DDL - based on the curl example
        request_data = {
            "options": {
                "dsType": source_datasource_type,
                "sinkNameSpace": sink_schema,
                "sinkDsType": sink_datasource_type,
                "operatorType": "source"
            },
            "__id__": [source_datasource_type, source_datasource_id],
            "id": source_datasource_id,
            "nameSpace": source_schema,
            "dataObjectName": source_table,
            "workspace": ""
        }

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "cz-lang": "zh_CN",
            "env": "prod",
            "instanceid": str(instance_id),
            "instancename": config.instance,
            "x-clickzetta-token": token
        }

        logger.info(f"Getting DDL from source table: {source_schema}.{source_table}")
        logger.debug(f"Request data: {request_data}")

        # Make the request to get DDL
        response = request.post(
            url=f"{url}?instanceId={instance_id}",
            data=json.dumps(request_data),
            headers=headers
        )

        if response.status_code != 200:
            logger.error(f"Failed to get DDL: {response.status_code}")
            logger.error(f"Response body: {response.text}")
            return False

        response_data = response.json()
        if response_data.get("code") == "200":
            ddl = response_data.get("data", "")
            if not ddl:
                logger.error(f"Received empty DDL for table {source_schema}.{source_table}")
                return False

            # Replace table name in DDL
            # The DDL returned by API may use a different schema name than the source,
            # so we need to replace any schema.table pattern in CREATE TABLE statement
            import re
            
            logger.info(f"Starting DDL replacement:")
            logger.info(f"  Source: {source_schema}.{source_table}")
            logger.info(f"  Sink: {sink_schema}.{sink_table}")
            logger.info(f"  Original DDL length: {len(ddl)} chars")
            logger.info(f"  Original DDL (first 500 chars): {ddl[:500]}")
            logger.debug(f"  Full Original DDL: {ddl}")
            
            modified_ddl = ddl
            replacements_made = 0
            
            # First, find what table identifier is actually used in CREATE TABLE
            create_table_match = re.search(
                r'CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?([^\s(]+)', 
                ddl, 
                re.IGNORECASE
            )
            
            if create_table_match:
                actual_table_identifier = create_table_match.group(1)
                logger.info(f"  Found CREATE TABLE with identifier: '{actual_table_identifier}'")
                
                # Build the replacement identifier
                # Determine quote style from actual identifier
                if '`' in actual_table_identifier:
                    # Use backticks
                    replacement_identifier = f'`{sink_schema}`.`{sink_table}`'
                elif '"' in actual_table_identifier:
                    # Use double quotes
                    replacement_identifier = f'"{sink_schema}"."{sink_table}"'
                else:
                    # No quotes
                    replacement_identifier = f'{sink_schema}.{sink_table}'
                
                logger.info(f"  Will replace '{actual_table_identifier}' with '{replacement_identifier}'")
                
                # Replace the table identifier in CREATE TABLE statement
                # Use re.escape to handle special characters in the identifier
                pattern = r'(CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+))' + re.escape(actual_table_identifier)
                modified_ddl = re.sub(
                    pattern,
                    r'\1' + replacement_identifier,
                    modified_ddl,
                    count=1,
                    flags=re.IGNORECASE
                )
                
                # Check if replacement was successful
                if modified_ddl != ddl:
                    replacements_made = 1
                    logger.info(f"  Successfully replaced table identifier in CREATE TABLE statement")
                else:
                    logger.warning(f"  Failed to replace table identifier - pattern might not match")
                    logger.debug(f"  Pattern used: {pattern}")
            else:
                logger.warning(f"No CREATE TABLE statement found in DDL")

            logger.info(f"Total replacements made: {replacements_made}")
            if replacements_made == 0:
                logger.error(f"Failed to modify DDL - no replacements were made")
            logger.debug(f"Modified DDL: {modified_ddl}")

            # Execute the modified DDL to create the table in sink datasource
            return execute_sql(sink_datasource_id, modified_ddl, env, server)
        else:
            logger.error(f"Failed to get DDL: {response_data.get('message')}")
            return False

    except Exception as e:
        logger.error(f"Error creating sink table from source: {e}")
        raise Exception(f"Error creating sink table from source: {e}")


def execute_sql(datasource_id: int, sql: str, env: str, server: StudioConfig = None) -> bool:
    """
    Execute SQL in the specified datasource

    Args:
        datasource_id: ID of the datasource
        sql: SQL statement to execute
        server: Server instance with connection config

    Returns:
        True if execution was successful, False otherwise
    """
    try:
        config = server
        url = read_url(env=env) + read_api("EXECUTE_SQL_URL")
        token = config.token
        instance_id = config.instance
        env = config.env
        options = {}
        if config.schema:
            options["schema"] = config.schema
        if config.vcluster:
            options["vclusterName"] = config.vcluster
        # API expects only 'id' and 'sql' fields
        request_data = {
            "id": datasource_id,
            "sql": sql,
            "options":options
        }

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "cz-lang": "zh_CN",
            "env": "prod",
            "instanceid": str(instance_id),
            "instancename": config.instance,
            "x-clickzetta-token": token
        }

        logger.info(f"Executing SQL: {sql[:100]}...")
        logger.debug(f"Request data: {request_data}")

        # Make the request to execute SQL
        response = request.post(
            url=f"{url}?instanceId={instance_id}",
            data=json.dumps(request_data),
            headers=headers
        )

        if response.status_code != 200:
            logger.error(f"Failed to execute SQL: {response.status_code},Response body: {response.text}")
            raise Exception(f"Failed to execute SQL: {response.status_code},Response body: {response.text}")

        response_data = response.json()
        if response_data.get("code") == "200":
            logger.info(f"SQL executed successfully: {response_data.get('data')}")
            return True
        else:
            logger.error(f"SQL execution failed: {response_data.get('message')}")
            raise Exception(f"SQL execution failed: {response_data.get('message')}")

    except Exception as e:
        logger.error(f"Error executing SQL: {e}")
        raise e



def execute_query(datasource_id: int, sql: str, env: str, server: StudioConfig = None):
    """
    Execute SQL in the specified datasource

    Args:
        datasource_id: ID of the datasource
        sql: SQL statement to execute
        server: Server instance with connection config

    Returns:
        True if execution was successful, False otherwise
    """
    try:
        config = server
        url = read_url(env=env) + read_api("EXECUTE_SQL_URL")
        token = config.token
        instance_id = config.instance
        env = config.env
        options = {}
        # if config.schema:
        #     options["schema"] = config.schema
        options["schema"] = "" # non Schema模式
        if config.vcluster:
            options["vclusterName"] = config.vcluster
        # API expects only 'id' and 'sql' fields
        request_data = {
            "id": datasource_id,
            "sql": sql,
            "options":options
        }

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "cz-lang": "zh_CN",
            "env": "prod",
            "instanceid": str(instance_id),
            "instancename": config.instance,
            "x-clickzetta-token": token
        }

        logger.info(f"Executing SQL: {sql[:100]}...")
        logger.debug(f"Request data: {request_data}")

        # Make the request to execute SQL
        response = request.post(
            url=f"{url}?instanceId={instance_id}",
            data=json.dumps(request_data),
            headers=headers
        )

        if response.status_code != 200:
            msg = f"HTTP {response.status_code}: {response.text}"
            logger.error(f"Execute SQL failed: {msg}")
            return None, msg

        response_data = response.json()
        if response_data.get("code") == "200":
            return response_data.get("data"), None, None
        else:
            msg = response_data.get("message", "unknown error")
            clean = msg.replace("数据源探测失败:SQLException:", "", 1).replace(
                "COMMON_DATASOURCE_EXPLORE_EXCEPTION_WITH_REASON", "sql_execution_failed", 1).strip()
            job_id = None
            try:
                m = re.search(r"Job\s+([a-f0-9\-]{36})", msg)
                if m:
                    job_id = m.group(1)
            except Exception:
                pass
            logger.error(f"Execute SQL failed: {msg}")
            return None, clean or msg, job_id

    except Exception as e:
        logger.error(f"Execute SQL unexpected error: {e}")
        return None, str(e), None

def get_table_metadata(datasource_id: int, schema: str, table: str,env: str, server: StudioConfig = None) -> Optional[Dict[str, Any]]:
    """
    Get table metadata using the getColumnMapMeta API

    Args:
        datasource_id: ID of the datasource
        schema: Schema or database name
        table: Table name
        server: Server instance with connection config

    Returns:
        Table metadata or None if not found
    """
    try:
        config = server
        url =read_url(env=env) + read_api("DATA_SOURCES_GET_COLUMN_MAP_META")
        token = config.token
        instance_id = config.instance

        # Request to get column metadata
        request_data = {
            "sourceReq": {
                "options": {
                    "dsType": _get_datasource_type(datasource_id),
                    "operatorType": "source",
                    "table": table,
                    "database": schema
                },
                "id": datasource_id,
                "dataObjectName": table,
                "nameSpace": schema
            },
            "sinkReq": {
                "options": {
                    "dsType": 1,  # Lakehouse
                    "operatorType": "sink",
                    "table": table,  # Will be overridden by caller
                    "database": "public",  # Will be overridden by caller
                    "is_partition": False
                },
                "id": 1,  # Will be overridden by caller
                "dataObjectName": table,  # Will be overridden by caller
                "nameSpace": "public"  # Will be overridden by caller
            }
        }

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "cz-lang": "zh_CN",
            "env": "prod",
            "instanceid": str(instance_id),
            "instancename": config.instance,
            "x-clickzetta-token": token
        }

        # Make the request
        response = request.post(
            url=f"{url}?instanceId={instance_id}",
            data=json.dumps(request_data),
            headers=headers
        )

        if response.status_code != 200:
            logger.error(f"Failed to get table metadata: {response.status_code}")
            return None

        response_data = response.json()
        if response_data.get("code") == "200":
            return response_data.get("data", {})

        return None

    except Exception as e:
        logger.error(f"Error getting table metadata: {e}")
        return None


def integration_generator(source_datasource_id: int,
                          source_datasource_name: str,
                          source_schema: str,
                          source_table: str,
                          sink_datasource_id: int,
                          sink_datasource_name: str,
                          sink_schema: str, sink_table: str,
                          source_ds_type: int,
                          sink_ds_type: int,
                          env: str,
                          server: StudioConfig = None) -> Dict[str, Any]:
    """
    Generate integration configuration by fetching source and sink metadata in one API call

    Args:
        source_datasource_id: ID of the source datasource
        source_datasource_name: Name of the source datasource
        source_schema: Schema of the source table
        source_table: Name of the source table
        sink_datasource_id: ID of the sink datasource
        sink_datasource_name: Name of the sink datasource
        sink_schema: Schema of the sink table
        sink_table: Name of the sink table
        source_ds_type: Type of the source datasource
        sink_ds_type: Type of the sink datasource
        env: Environment (dev/prod)
        server: Server instance with connection config

    Returns:
        Integration JSON configuration
    """

    # Get metadata for both source and sink in one API call
    try:
        config = server
        url = read_url(env=env) + read_api("DATA_SOURCES_GET_COLUMN_MAP_META")
        token = config.token
        instance_id = config.instance

        # Build request payload
        request_data = {
            "sourceReq": {
                "options": {
                    "dsType": source_ds_type,
                    "operatorType": "source",
                    "table": source_table,
                    "database": source_schema
                },
                "id": source_datasource_id,
                "dataObjectName": source_table,
                "nameSpace": source_schema
            },
            "sinkReq": {
                "options": {
                    "dsType": sink_ds_type,
                    "operatorType": "sink",
                    "table": sink_table
                },
                "id": sink_datasource_id,
                "dataObjectName": sink_table,
                "nameSpace": sink_schema,
                "__id__": [sink_ds_type, sink_datasource_id],
                "__partitions__": {"open": False}
            }
        }

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "cz-lang": "zh_CN",
            "env": env,
            "instanceid": str(instance_id),
            "instancename": config.instance,
            "x-clickzetta-token": token
        }

        logger.info(f"Getting column metadata for {source_schema}.{source_table} -> {sink_schema}.{sink_table}")
        logger.debug(f"Request data: {request_data}")

        # Make the request
        response = request.post(
            url=f"{url}?instanceId={instance_id}",
            data=json.dumps(request_data),
            headers=headers
        )

        if response.status_code != 200:
            logger.error(f"Failed to get column metadata: {response.status_code}")
            logger.error(f"Response body: {response.text}")
            return {"code": "500", "message": f"Failed to get metadata: HTTP {response.status_code}"}

        response_data = response.json()
        
        if response_data.get("code") != "200":
            logger.error(f"API returned error: {response_data.get('message')}")
            return {"code": "500", "message": response_data.get("message", "Failed to get metadata")}

        # Extract metadata from response
        data = response_data.get("data", {})
        source_meta = data.get("sourceMeta", {})
        sink_meta = data.get("sinkMeta", {})

        if not source_meta or not sink_meta:
            logger.error("Missing sourceMeta or sinkMeta in response")
            return {"code": "500", "message": "Missing metadata in response"}

        # Build the column mapping
        source_columns = source_meta.get("columns", [])
        sink_columns = sink_meta.get("columns", [])
        
    except Exception as e:
        logger.error(f"Error getting column metadata: {e}")
        return {"code": "500", "message": f"Error: {str(e)}"}

    # Create column mapping by position (order)
    column_mapping = {}
    min_length = min(len(source_columns), len(sink_columns))
    for i in range(min_length):
        source_col_name = source_columns[i].get("name")
        sink_col_name = sink_columns[i].get("name")
        column_mapping[sink_col_name] = source_col_name

    # Build the integration configuration
    integration_json = {
        "templateKey": 1,
        "userParams": {},
        "sourceConnection": {
            "datasourceId": source_datasource_id,
            "datasourceName": source_datasource_name,
            "type": source_ds_type
        },
        "sinkConnection": {
            "datasourceId": sink_datasource_id,
            "datasourceName": sink_datasource_name,
            "type": sink_ds_type
        },
        "jobs": [{
            "source": {
                "dataObject": source_table,
                "namespace": source_schema,
                "params": {
                    "dsType": source_ds_type,
                    "operatorType": "source",
                    "table": source_table,
                    "database": source_schema
                },
                "columns": source_columns
            },
            "sink": {
                "dataObject": sink_table,
                "namespace": sink_schema,
                "params": {
                    "dsType": sink_ds_type,
                    "operatorType": "sink",
                    "table": sink_table,
                    "database": sink_schema,
                    "is_partition": False,
                    "writeMode": "OVERWRITE",  # Default to OVERWRITE
                    "outputMode": "OVERWRITE"  # Must match writeMode
                },
                "columns": sink_columns
            },
            "setting": {
                "parallelism": 1,
                "errorLimit": {
                    "maxCount": -1,
                    "collectDirtyData": True,
                    "record": -1
                }
            },
            "columnMapping": column_mapping
        }]
    }

    return integration_json

def _generate_check_table_sql(datasource_type: int, schema: str, table: str) -> Optional[str]:
    """
    Generate SQL to check if a table exists based on datasource type

    Args:
        datasource_type: Type of the datasource
        schema: Schema or database name
        table: Table name

    Returns:
        SQL string to check table existence, or None if unsupported
    """
    # MySQL family (5=MySQL, 21=MariaDB, 22=TiDB, etc.)
    if datasource_type in [5, 21, 22, 23, 24]:
        # MySQL: SHOW TABLES FROM schema LIKE 'table'
        return f"SHOW TABLES FROM `{schema}` LIKE '{table}'"
    
    # PostgreSQL family (7=PostgreSQL, 18=Greenplum, 19=Hologres, etc.)
    elif datasource_type in [7, 18, 19, 25, 26]:
        # PostgreSQL: Use information_schema
        return f"""SELECT EXISTS (
            SELECT FROM information_schema.tables 
            WHERE table_schema = '{schema}' 
            AND table_name = '{table}'
        )"""
    
    # MongoDB (12)
    elif datasource_type == 12:
        # MongoDB: Use listCollections command
        # Note: This returns a list of collections, not a boolean
        return f"db.getCollectionNames().indexOf('{table}') !== -1"
    
    # Oracle (17)
    elif datasource_type == 17:
        return f"""SELECT COUNT(*) FROM all_tables 
            WHERE owner = UPPER('{schema}') 
            AND table_name = UPPER('{table}')"""
    
    # SQL Server (8)
    elif datasource_type == 8:
        return f"""SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES 
            WHERE TABLE_SCHEMA = '{schema}' 
            AND TABLE_NAME = '{table}'"""
    
    # ClickHouse (27)
    elif datasource_type == 27:
        return f"EXISTS TABLE `{schema}`.`{table}`"
    
    # Hive (3) / Spark (4)
    elif datasource_type in [3, 4, 1]:
        return f"SHOW TABLES IN `{schema}` LIKE '{table}'"
    
    else:
        # Unsupported datasource type
        logger.warning(f"Unsupported datasource type for table existence check: {datasource_type}")
        return None


def _generate_check_schema_sql(datasource_type: int, schema: str) -> Optional[str]:
    """
    Generate SQL to check if a schema/database exists based on datasource type.
    """
    if datasource_type in [5, 21, 22, 23, 24]:
        return f"SHOW DATABASES LIKE '{schema}'"
    elif datasource_type in [7, 18, 19, 25, 26]:
        return f"""SELECT EXISTS (
            SELECT FROM information_schema.schemata
            WHERE schema_name = '{schema}'
        )"""
    elif datasource_type == 17:
        return f"""SELECT COUNT(*) FROM all_users
            WHERE username = UPPER('{schema}')"""
    elif datasource_type == 8:
        return f"""SELECT COUNT(*) FROM INFORMATION_SCHEMA.SCHEMATA
            WHERE SCHEMA_NAME = '{schema}'"""
    elif datasource_type == 27:
        return f"EXISTS DATABASE `{schema}`"
    elif datasource_type in [3, 4]:
        return f"SHOW DATABASES LIKE '{schema}'"
    elif datasource_type == 1:
        return f"SHOW SCHEMAS LIKE '{schema}'"
    else:
        logger.warning(f"Unsupported datasource type for schema existence check: {datasource_type}")
        return None


def _generate_create_schema_sql(datasource_type: int, schema: str) -> Optional[str]:
    """
    Generate SQL to create a schema/database based on datasource type.
    """
    if datasource_type in [5, 21, 22, 23, 24, 3, 4]:
        return f"CREATE DATABASE IF NOT EXISTS `{schema}`"
    elif datasource_type in [7, 18, 19, 25, 26]:
        return f'CREATE SCHEMA IF NOT EXISTS "{schema}"'
    elif datasource_type == 8:
        return f"IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = '{schema}') EXEC('CREATE SCHEMA [{schema}]')"
    elif datasource_type == 27:
        return f"CREATE DATABASE IF NOT EXISTS `{schema}`"
    elif datasource_type == 1:
        return f"CREATE SCHEMA IF NOT EXISTS {schema}"
    else:
        logger.warning(f"Unsupported datasource type for schema creation: {datasource_type}")
        return None


def _get_datasource_type(datasource_id: int) -> int:
    """
    Get the type of a datasource based on known patterns

    Args:
        datasource_id: ID of the datasource

    Returns:
        Integer representing the datasource type
    """
    # This would ideally come from an API call, but we'll use common patterns
    # In a real implementation, you'd get this from the datasource list
    # For now, we'll return a default based on common patterns

    # Common datasource types (from your examples)
    # 5 = MySQL, 1 = Lakehouse, etc.

    # Since we don't have the actual API call result, we'll use a heuristic
    # In a real implementation, you'd call the list datasources API
    if datasource_id == 14040:  # From your example for Lakehouse
        return 1
    elif datasource_id == 12094:  # From your example for MySQL
        return 5
    elif datasource_id == 1376:  # From your example for Lakehouse
        return 1

    # Default to relational database
    return 5
