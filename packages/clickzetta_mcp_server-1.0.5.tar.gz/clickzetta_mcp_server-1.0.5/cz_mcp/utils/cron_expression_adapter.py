from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal


SUPPORTED_SPECIAL_TOKENS = ("L", "W", "#", "C")
ALLOWED_MINUTE_GAPS = {1, 2, 3, 5, 10, 15, 20, 30}
ALLOWED_HOUR_GAP_MIN = 1
ALLOWED_HOUR_GAP_MAX = 12


@dataclass
class CronFields:
    second: str
    minute: str
    hour: str
    day: str
    month: str
    week: str
    year: str = "*"


@dataclass
class UiScheduleParam:
    schedule: list[list[str]] = field(default_factory=lambda: [["everyday"]])
    frequency: Literal["1", "2"] = "1"
    schedule_start_time: str = "00:00"
    schedule_end_time: str | None = None
    time_gap: str | int | None = None


@dataclass
class DecodeResult:
    param: UiScheduleParam
    warnings: list[str] = field(default_factory=list)
    unsupported_reason: str | None = None
    lossless: bool = True


def normalize_cron(expr: str) -> str:
    return " ".join(expr.strip().split())


def parse_cron(expr: str) -> CronFields:
    normalized = normalize_cron(expr)
    parts = normalized.split(" ")
    if len(parts) == 5:
        minute, hour, day, month, week = parts
        if week == "*":
            week = "?"
        parts = ["0", minute, hour, day, month, week, "*"]
    if len(parts) == 6:
        parts.append("*")
    if len(parts) != 7:
        raise ValueError(f"Unsupported cron parts count: {len(parts)}")

    return CronFields(
        second=parts[0],
        minute=parts[1],
        hour=parts[2],
        day=parts[3],
        month=parts[4],
        week=parts[5],
        year=parts[6],
    )


def _contains_unsupported_token(token: str) -> bool:
    return any(s in token for s in SUPPORTED_SPECIAL_TOKENS)


def _pad_2(v: int) -> str:
    return f"{v:02d}"


def _parse_hour_range(token: str) -> tuple[str, str, str | None]:
    step = None
    base = token
    if "/" in token:
        base, step = token.split("/", 1)
    if "-" in base:
        start, end = base.split("-", 1)
        return start, end, step
    return base, base, step


def _parse_minute_step(token: str) -> tuple[int | None, int]:
    """
    Parse minute step expressions:
    - "*/3" -> (None, 3)
    - "2/3" -> (2, 3)
    """
    base, step = token.split("/", 1)
    start_minute = None if base == "*" else int(base)
    return start_minute, int(step)


def decode_to_ui(fields: CronFields) -> DecodeResult:
    warnings: list[str] = []
    unsupported = None
    lossless = True

    for token in (
        fields.second,
        fields.minute,
        fields.hour,
        fields.day,
        fields.month,
        fields.week,
        fields.year,
    ):
        if _contains_unsupported_token(token):
            unsupported = f"Unsupported Quartz token in field: {token}"
            break
    if unsupported:
        return DecodeResult(param=UiScheduleParam(), warnings=warnings, unsupported_reason=unsupported, lossless=False)

    if fields.day not in ("*", "?") and fields.week not in ("*", "?"):
        return DecodeResult(
            param=UiScheduleParam(),
            warnings=warnings,
            unsupported_reason="Both day-of-month and day-of-week are specific.",
            lossless=False,
        )

    param = UiScheduleParam()

    if fields.day not in ("*", "?"):
        param.schedule = [[ "daily", d ] for d in fields.day.split(",")]
    elif fields.week not in ("*", "?"):
        param.schedule = [[ "weekly", d ] for d in fields.week.split(",")]

    minute = fields.minute
    hour = fields.hour

    # minute step
    if "/" in minute or minute == "*":
        param.frequency = "2"
        if minute == "*":
            param.time_gap = "1m"
            start_minute = 0
        else:
            start_minute, step = _parse_minute_step(minute)
            param.time_gap = f"{step}m"
            if start_minute is None:
                start_minute = 0

        h_start, h_end, _ = _parse_hour_range(hour)
        if hour == "*":
            param.schedule_start_time = f"00:{_pad_2(start_minute)}"
            param.schedule_end_time = "23:59"
        else:
            param.schedule_start_time = f"{_pad_2(int(h_start))}:{_pad_2(start_minute)}"
            param.schedule_end_time = f"{_pad_2(int(h_end))}:59"
            if minute.startswith("*/"):
                warnings.append(
                    "Cron minute step '*/N' does not contain explicit start-minute anchor; inferred as :00."
                )
                lossless = False
        return DecodeResult(param=param, warnings=warnings, unsupported_reason=None, lossless=lossless)

    # hour step
    h_start, h_end, h_step = _parse_hour_range(hour)
    if h_step is not None:
        param.frequency = "2"
        param.time_gap = int(h_step)
        param.schedule_start_time = f"{_pad_2(int(h_start))}:{_pad_2(int(minute))}"
        param.schedule_end_time = f"{_pad_2(int(h_end))}:59"
        return DecodeResult(param=param, warnings=warnings, unsupported_reason=None, lossless=lossless)

    # once daily/weekly/etc
    param.frequency = "1"
    param.schedule_start_time = f"{_pad_2(int(hour))}:{_pad_2(int(minute))}"
    param.schedule_end_time = None
    param.time_gap = None
    return DecodeResult(param=param, warnings=warnings, unsupported_reason=None, lossless=lossless)


def _minute_anchor_values(start_minute: int, gap: int) -> list[int]:
    values: list[int] = []
    seen = set()
    current = start_minute
    for _ in range(60):
        current_mod = current % 60
        if current_mod in seen:
            break
        seen.add(current_mod)
        values.append(current_mod)
        current += gap
    return sorted(values)


def encode_from_ui(param: UiScheduleParam, mode: Literal["business", "classic"] = "classic") -> str:
    crontab = ["0", "0", "*", "*", "*", "?", "*"]
    start_h, start_m = [int(x) for x in param.schedule_start_time.split(":")]
    schedule = param.schedule or [["everyday"]]
    schedule_type = schedule[0][0]
    schedule_values = [item[1] for item in schedule if len(item) > 1]

    if schedule_type in ("daily", "monthly"):
        crontab[3] = ",".join(schedule_values)
    elif schedule_type == "weekly":
        crontab[3] = "?"
        crontab[5] = ",".join(schedule_values)

    if param.frequency == "2" and param.time_gap is not None:
        end_h = 23
        if param.schedule_end_time:
            end_h = int(param.schedule_end_time.split(":")[0])

        gap_text = str(param.time_gap)
        if gap_text.endswith("m"):
            gap = int(gap_text.replace("m", ""))
            if gap not in ALLOWED_MINUTE_GAPS:
                raise ValueError(
                    f"Unsupported minute gap: {gap}. Allowed values: {sorted(ALLOWED_MINUTE_GAPS)}"
                )
            if mode == "business":
                anchored = _minute_anchor_values(start_m, gap)
                crontab[1] = ",".join(str(v) for v in anchored)
            elif start_m == 0 and gap == 1:
                crontab[1] = "*"
            else:
                crontab[1] = f"*/{gap}"

            if start_h == 0 and end_h == 23:
                crontab[2] = "*"
            else:
                crontab[2] = f"{start_h:02d}-{end_h:02d}"
        else:
            hour_gap = int(gap_text)
            if not (ALLOWED_HOUR_GAP_MIN <= hour_gap <= ALLOWED_HOUR_GAP_MAX):
                raise ValueError(
                    f"Unsupported hour gap: {hour_gap}. Allowed range: {ALLOWED_HOUR_GAP_MIN}-{ALLOWED_HOUR_GAP_MAX}"
                )
            crontab[1] = f"{start_m:02d}"
            if start_h == 0 and end_h == 23 and hour_gap == 1:
                crontab[2] = "*"
            else:
                crontab[2] = f"{start_h:02d}-{end_h:02d}/{hour_gap}"
    else:
        crontab[1] = f"{start_m:02d}"
        crontab[2] = f"{start_h:02d}"

    return " ".join(crontab)


def roundtrip(expr: str, mode: Literal["business", "classic"] = "classic") -> dict:
    fields = parse_cron(expr)
    decoded = decode_to_ui(fields)
    if decoded.unsupported_reason:
        return {
            "ui_param": decoded.param,
            "rebuilt_cron": None,
            "warnings": decoded.warnings,
            "unsupported_reason": decoded.unsupported_reason,
            "lossless": False,
        }

    rebuilt = encode_from_ui(decoded.param, mode=mode)
    return {
        "ui_param": decoded.param,
        "rebuilt_cron": rebuilt,
        "warnings": decoded.warnings,
        "unsupported_reason": None,
        "lossless": decoded.lossless,
    }


def convert_agent_cron(
    expr: str,
    schedule_start_time: str | None = None,
    schedule_end_time: str | None = None,
    mode: Literal["business", "classic"] = "classic",
) -> dict:
    """
    Agent cron adapter entrypoint.

    Flow:
    1) Parse traditional cron.
    2) Decode into UI params.
    3) Apply optional start/end time overrides.
    4) Re-encode into system cron with constraints.
    """
    fields = parse_cron(expr)
    decoded = decode_to_ui(fields)
    if decoded.unsupported_reason:
        return {
            "ok": False,
            "input_cron": normalize_cron(expr),
            "output_cron": None,
            "ui_param": decoded.param,
            "warnings": decoded.warnings,
            "unsupported_reason": decoded.unsupported_reason,
            "lossless": False,
        }

    param = decoded.param
    if schedule_start_time is not None:
        param.schedule_start_time = schedule_start_time
        decoded.warnings.append("schedule_start_time overridden by caller.")
        decoded.lossless = False
    if schedule_end_time is not None:
        param.schedule_end_time = schedule_end_time
        decoded.warnings.append("schedule_end_time overridden by caller.")
        decoded.lossless = False

    try:
        output_cron = encode_from_ui(param, mode=mode)
    except ValueError as e:
        return {
            "ok": False,
            "input_cron": normalize_cron(expr),
            "output_cron": None,
            "ui_param": param,
            "warnings": decoded.warnings,
            "unsupported_reason": str(e),
            "lossless": False,
        }

    return {
        "ok": True,
        "input_cron": normalize_cron(expr),
        "output_cron": output_cron,
        "ui_param": param,
        "warnings": decoded.warnings,
        "unsupported_reason": None,
        "lossless": decoded.lossless,
    }
