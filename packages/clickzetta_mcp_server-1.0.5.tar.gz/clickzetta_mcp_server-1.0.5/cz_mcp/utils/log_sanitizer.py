"""
Utilities for masking sensitive values before writing logs.
"""
from typing import Any, Mapping

SENSITIVE_KEYWORDS = (
    "token",
    "password",
    "authorization",
    "secret",
    "api-key",
    "apikey",
    "cookie",
    "session",
)


def is_sensitive_key(key: str) -> bool:
    """Return True if key likely contains sensitive data."""
    lowered = str(key).lower()
    return any(keyword in lowered for keyword in SENSITIVE_KEYWORDS)


def mask_secret_value(value: Any, visible_prefix: int = 4, visible_suffix: int = 2) -> Any:
    """Mask sensitive value while keeping a tiny prefix/suffix for troubleshooting."""
    if value is None:
        return None
    value_str = str(value)
    if not value_str:
        return value_str
    if len(value_str) <= visible_prefix + visible_suffix:
        return "***"
    return f"{value_str[:visible_prefix]}...{value_str[-visible_suffix:]}"


def sanitize_data(data: Any) -> Any:
    """Recursively sanitize dict/list/tuple data for safe logging."""
    if isinstance(data, Mapping):
        sanitized = {}
        for key, value in data.items():
            if is_sensitive_key(str(key)):
                sanitized[key] = mask_secret_value(value)
            else:
                sanitized[key] = sanitize_data(value)
        return sanitized
    if isinstance(data, list):
        return [sanitize_data(item) for item in data]
    if isinstance(data, tuple):
        return tuple(sanitize_data(item) for item in data)
    return data

