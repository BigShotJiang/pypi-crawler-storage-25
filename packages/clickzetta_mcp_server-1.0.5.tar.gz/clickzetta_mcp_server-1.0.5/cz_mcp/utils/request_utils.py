# -*- encoding=utf8 -*-
import json
import logging
import time

from jsonpath_ng import parse
import requests
from requests import Response
from requests import exceptions as requests_exceptions
from urllib3.exceptions import InsecureRequestWarning


logger = logging.getLogger(__name__)


class RequestUtils:
    # Internal retry policy (not exposed to callers).
    _DEFAULT_RETRY_TIMES = 2
    _DEFAULT_RETRY_INTERVAL_SECONDS = 0.5
    _RETRY_MESSAGE_KEYWORDS = ("internal server error",)
    _RETRY_EXCEPTIONS = (
        requests_exceptions.Timeout,
        requests_exceptions.ConnectionError,
    )

    def _should_retry_response(
        self,
        response: Response,
    ):
        normalized_messages = []

        try:
            payload = response.json()
        except ValueError:
            payload = None

        if isinstance(payload, dict):
            payload_message = payload.get("message")
            if payload_message is not None:
                normalized_messages.append(str(payload_message).strip().lower())

        response_text = getattr(response, "text", None)
        if response_text is not None:
            normalized_messages.append(str(response_text).strip().lower())

        for message in normalized_messages:
            if any(keyword in message for keyword in self._RETRY_MESSAGE_KEYWORDS):
                return True, "internal_server_error"

        return False, ""

    def _request_with_retry(
        self,
        method,
        url,
        params=None,
        **kwargs,
    ):
        requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
        kwargs.setdefault("verify", False)

        last_exception = None
        attempts = self._DEFAULT_RETRY_TIMES + 1

        for attempt in range(1, attempts + 1):
            try:
                response = method(url=url, params=params, **kwargs)
                should_retry, reason = self._should_retry_response(
                    response=response,
                )
                if should_retry and attempt < attempts:
                    sleep_seconds = self._DEFAULT_RETRY_INTERVAL_SECONDS * (2 ** (attempt - 1))
                    logger.warning(
                        f"HTTP request retry {attempt}/{attempts - 1} for {url}, "
                        f"reason={reason}, sleep={sleep_seconds}s"
                    )
                    time.sleep(sleep_seconds)
                    continue
                return response
            except requests_exceptions.RequestException as exc:
                last_exception = exc
                should_retry_exception = isinstance(exc, self._RETRY_EXCEPTIONS)
                if not should_retry_exception or attempt >= attempts:
                    raise
                sleep_seconds = self._DEFAULT_RETRY_INTERVAL_SECONDS * (2 ** (attempt - 1))
                logger.warning(
                    f"HTTP request retry {attempt}/{attempts - 1} for {url}, "
                    f"reason=exception:{type(exc).__name__}, sleep={sleep_seconds}s"
                )
                time.sleep(sleep_seconds)

        if last_exception is not None:
            raise last_exception

        # Should not reach here, keep fallback for safety.
        return method(url=url, params=params, **kwargs)

    def get(
        self,
        url,
        params=None,
        **kwargs,
    ):
        return self._request_with_retry(
            method=requests.get,
            url=url,
            params=params,
            **kwargs,
        )

    # post请求的封装：data也可能存在无值得情况，存放默认None
    def post(
        self,
        url,
        data=None,
        json=None,
        params=None,
        **kwargs,
    ):
        return self._request_with_retry(
            method=requests.post,
            url=url,
            params=params,
            data=data,
            json=json,
            **kwargs,
        )

    # Extract data using jsonpath expressions
    def get_data(self, response, key):
        # Parse JSON response
        dict_data = json.loads(response)

        # Convert JSONPath expression to jsonpath-ng format
        if key.startswith('$.'):
            key = key[2:]  # Remove '$.' prefix

        # Parse and find data
        jsonpath_expr = parse(key)
        matches = [match.value for match in jsonpath_expr.find(dict_data)]

        if matches:
            return matches[0]
        else:
            return None
