import configparser
import os

from .context_utils import context

from loguru import logger

conf = configparser.ConfigParser()
path = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), 'config/')

def read_ini(file_path, section, key):
    """读取ini文件"""
    conf.read(path + file_path, encoding="utf-8")
    try:
        return conf.get(section, key)
    except (configparser.NoSectionError, configparser.NoOptionError) as e:
        logger.error(f"Error reading INI file: {e}")
        return None


def read_url(section="URL", env=None):
    """读取请求头"""
    conf.read(path + "config.ini", encoding="utf-8")
    try:
        # 如果没有传入env参数，尝试从context获取，否则使用默认值
        if env is None:
            env = context.get('env', 'dev')
        return conf.get(section, env)
    except Exception as e:
        logger.error(f"Error: {e}")
        return ''

def read_web_url(section="WEB", env=None):
    """读取请求头"""
    conf.read(path + "config.ini", encoding="utf-8")
    try:
        # 如果没有传入env参数，尝试从context获取，否则使用默认值
        if env is None:
            env = context.get('env', 'dev')
        return conf.get(section, env)
    except Exception as e:
        logger.error(f"Error: {e}")
        return ''


def read_api(key, section='API'):
    """读取接口路径"""
    try:
        return read_ini("api_properties.ini", section, key)
    except Exception as e:
        logger.error(f"Error: {e}")
        return ''


# 主函数：读取环境配置文件中的配置项
def read_env_configuration(key, section="variable"):
    try:
        file_path = f"{context['env']}_properties.ini"
        return read_ini(file_path, section, key)
    except Exception as e:
        logger.error(f"Error: {e}")
        return ''


def read_data_source_config(section, key):
    """读取数据源配置文件"""
    try:
        return read_ini(f"{context['env']}_dataSource_config.ini", section, key)
    except Exception as e:
        logger.error(f"Error: {e}")
        return ''


def read_sections_ini(key):
    try:
        conf.read(path + key, encoding="utf-8")
        return conf.options(conf.sections()[0])
    except Exception as e:
        logger.error(f"Error: {e}")
        return ''

def read_config_ini(section,key):
    conf.read(path + "config.ini", encoding="utf-8")
    try:
        return conf.get(section, key)
    except Exception as e:
        logger.error(f"Error: {e}")
        return ''