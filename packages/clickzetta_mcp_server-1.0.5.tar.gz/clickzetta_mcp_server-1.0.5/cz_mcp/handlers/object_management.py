"""
Admin Object Management - 对象管理处理器
合并 object_list_handlers.py 和 object_desc_handlers.py 的功能
统一对象查看、描述和列表管理
"""

from cz_mcp.common import ResponseBuilder
from cz_mcp.common.data_utils import convert_df_to_dict
from cz_mcp.handlers.parameter_handler import ParameterHandler, ParamType, Validators, HandlerFactory
from cz_mcp.handlers.transformer import Transformers
from cz_mcp.studio_config_manager import StudioConfig

from loguru import logger


# =================== 对象列表处理 ===================

async def handle_show_object_list(arguments=None, studio_config: StudioConfig = None, **kwargs):
    """
    增强版SHOW对象列表处理器 - 支持结构化参数和智能SQL构建
    """
    try:
        # 使用参数处理器
        params = show_object_list().process_arguments(arguments)

        object_type = params["object_type"]

        # 标准化对象类型名称，处理空格和下划线的差异
        # object_type现在是必选参数，不会为None
        object_type_normalized = object_type.upper().replace(" ", "_")
        schema_name = params.get("in_schema")
        pattern = params.get("like_pattern")
        limit = params.get("limit")
        table_type_filters = params.get("table_type_filters", [])
        db = kwargs.get("db")

        # 默认限制
        DEFAULT_LIMITS = {
            'FUNCTIONS': 25, 'TABLES': 20, 'VIEWS': 25, 'SCHEMAS': 20,
            'CONNECTIONS': 20, 'VOLUMES': 15, 'PIPES': 20, 'STREAMS': 20,
            'CATALOGS': 10, 'WORKSPACES': 10, 'VCLUSTERS': 15, 'USERS': 30,
            'ROLES': 20, 'SHARES': 15, 'DYNAMIC_TABLES': 25, 'INDEXES': 40,
            'MATERIALIZED_VIEWS': 20
        }

        # 应用默认限制
        if limit is None:
            limit = DEFAULT_LIMITS.get(object_type, 20)

        # 构建基础SQL
        query_parts = []

        if object_type_normalized in ['FUNCTIONS', 'EXTERNAL_FUNCTIONS']:
            # 函数特殊处理
            return await _handle_functions_special_internal(params, db)
        elif object_type_normalized == 'TABLES' and table_type_filters:
            # 表类型过滤特殊处理
            return await handle_tables_with_type_filter(params, db)
        elif object_type_normalized in ['TABLES', 'VIEWS', 'DYNAMIC_TABLES', 'MATERIALIZED_VIEWS', 'EXTERNAL_TABLES']:
            # 特殊对象类型：需要使用SHOW TABLES + WHERE过滤
            return await _handle_special_table_types(object_type_normalized, params, db)
        else:
            # 标准SHOW语句 - 使用标准化的对象类型
            query_parts = ["SHOW", object_type_normalized]

            # 添加IN SCHEMA子句
            # "WORKSPACES", "TABLES", "VIEWS", "SCHEMAS", "CATALOGS", "FUNCTIONS",
            # "EXTERNAL FUNCTIONS", "VOLUMES",
            # "CONNECTIONS", "VCLUSTERS", "JOBS", "PIPES", "USERS",
            # "ROLES", "GRANTS", "SHARES", "TABLE STREAMS", "DYNAMIC TABLES",
            # "MATERIALIZED VIEWS", "EXTERNAL TABLES", "EXTERNAL SCHEMAS", "NETWORK POLICY"
            if schema_name and not object_type_normalized in ['WORKSPACES', "FUNCTIONS", "EXTERNAL FUNCTIONS",
                                                              "VOLUMES", 'CATALOGS', 'CONNECTIONS', 'USERS',
                                                              'ROLES', 'SHARES', 'NETWORK_POLICY', 'VCLUSTERS',
                                                              'JOBS']:
                query_parts.extend(["IN", "SCHEMA", schema_name])

            # 添加LIKE模式匹配
            if pattern and object_type_normalized in ['USERS', 'GRANTS', 'EXTERNAL SCHEMAS']:
                query_parts.extend(["LIKE", f"'{pattern}'"])

            # 添加LIMIT
            if limit:
                query_parts.extend(["LIMIT", str(limit)])

        query = " ".join(query_parts)

        try:
            # 执行查询
            data, data_id = db.execute_query(query + ";")
            result_data = convert_df_to_dict(data)

            response = {
                "sql_query_executed": query,
                "result": result_data[:limit] if limit else result_data,
                "result_count": len(result_data),
                "object_type": object_type
            }

            # 添加截断提示
            if limit and len(result_data) >= limit:
                response["truncated"] = True
                response["hint"] = f"结果已限制为前 {limit} 个对象"

            return ResponseBuilder.create_yaml_json_response([response], data_id, studio_config=studio_config)

        except Exception as e:
            error_msg = str(e)
            suggestions = []

            if "permission" in error_msg.lower():
                suggestions.append("没有查看此对象类型的权限")
                suggestions.append("请检查用户权限设置")
            elif "not exist" in error_msg.lower() or "invalid" in error_msg.lower():
                if schema_name:
                    suggestions.append(f"Schema '{schema_name}' 不存在或无访问权限")
                    suggestions.append("使用 show_object_list(object_type='SCHEMAS') 查看可用Schema")
                else:
                    suggestions.append(f"对象类型 '{object_type}' 不受支持")

            return ResponseBuilder.create_yaml_json_response({
                "success": False,
                "error": error_msg,
                "object_type": object_type,
                "sql_query_attempted": query,
                "suggestions": suggestions
            }, None, studio_config=studio_config)

    except Exception as e:
        return ResponseBuilder.create_yaml_json_response({
            "success": False,
            "error": str(e),
            "operation": "SHOW OBJECT LIST",
            "suggestion": "请检查参数是否正确"
        }, None, studio_config=studio_config)

def show_object_list() -> ParameterHandler:
    """显示对象列表参数处理器 - 增强版本，支持结构化输入"""
    return (ParameterHandler("show_object_list")
            # 基本模式：直接传入SHOW命令
            .define_param("show_command", ParamType.OPTIONAL,
                          validator=Validators.non_empty_string,
                          transformer=lambda x: x.strip().upper(),
                          description="完整的SHOW命令（向后兼容）")

            # 结构化模式：分解参数
            .define_param("object_type", ParamType.REQUIRED,  # 修复：改回REQUIRED
                          validator=Validators.in_choices([
                              "WORKSPACES", "TABLES", "VIEWS", "SCHEMAS", "CATALOGS", "FUNCTIONS",
                              "EXTERNAL FUNCTIONS", "VOLUMES",
                              "CONNECTIONS", "VCLUSTERS", "JOBS", "PIPES", "USERS",
                              "ROLES", "GRANTS", "SHARES", "TABLE STREAMS", "DYNAMIC TABLES",
                              "MATERIALIZED VIEWS", "EXTERNAL TABLES", "EXTERNAL SCHEMAS", "NETWORK POLICY"
                          ]),
                          transformer=Transformers.normalize_object_type,
                          description="对象类型（默认为TABLES）")

            # 通用过滤参数
            .define_param("in_schema", ParamType.OPTIONAL,
                          validator=Validators.non_empty_string,
                          transformer=Transformers.strip_string,
                          description="在指定Schema中查找（支持TABLES/VOLUMES/PIPES等）")

            .define_param("like_pattern", ParamType.OPTIONAL,
                          validator=Validators.non_empty_string,
                          transformer=Transformers.strip_string,
                          description="LIKE模式匹配（支持%和_通配符）")

            .define_param("where_condition", ParamType.OPTIONAL,
                          validator=Validators.non_empty_string,
                          transformer=Transformers.strip_string,
                          description="WHERE条件（仅TABLES支持）")

            .define_param("limit", ParamType.OPTIONAL,
                          transformer=Transformers.to_int,
                          validator=Validators.positive_integer,
                          description="限制返回数量")

            # 特定对象类型参数
            .define_param("in_vcluster", ParamType.OPTIONAL,
                          validator=Validators.non_empty_string,
                          transformer=Transformers.strip_string,
                          description="在指定VCluster中查找（仅JOBS支持）")

            .define_param("to_user", ParamType.OPTIONAL,
                          validator=Validators.non_empty_string,
                          transformer=Transformers.strip_string,
                          description="查看特定用户的权限（仅GRANTS支持）")

            # TABLES特定过滤器
            .define_param("table_type_filters", ParamType.OPTIONAL,
                          validator=Validators.is_dict_or_none,
                          description="表类型过滤器：{is_view, is_materialized_view, is_external, is_dynamic}")

            # 智能默认值
            .define_param("smart_defaults", ParamType.OPTIONAL,
                          default_value=True,
                          transformer=Transformers.to_bool,
                          description="是否应用智能默认值（如JOBS自动加LIMIT 10，TABLES自动加LIMIT 50等）")

            # 响应优化控制
            .define_param("include_suggestions", ParamType.OPTIONAL,
                          default_value=False,
                          transformer=Transformers.to_bool,
                          description="是否包含过滤建议和提示信息")

            .define_param("include_field_analysis", ParamType.OPTIONAL,
                          default_value=False,
                          # 上方已定义增强参数块
                          description="是否包含字段级别的详细分析")

            # FUNCTIONS特定参数
            .define_param("show_builtin_functions", ParamType.OPTIONAL,
                          default_value=False,
                          transformer=Transformers.to_bool,
                          description="是否显示内置函数详情（默认只显示外部函数）")

            .define_param("function_type", ParamType.OPTIONAL,
                          validator=Validators.in_choices(["ALL", "BUILTIN", "EXTERNAL", "UDF"]),
                          transformer=Transformers.to_upper,
                          description="函数类型过滤：ALL(所有)/BUILTIN(内置)/EXTERNAL(远程外部函数)/UDF(用户SQL函数)")

            # 响应优化参数
            .define_param("detailed_analysis", ParamType.OPTIONAL,
                          default_value=False,
                          transformer=Transformers.to_bool,
                          description="是否返回详细的数据分析（默认为简洁模式）"))

async def _handle_special_table_types(object_type, params, db):
    """处理特殊表类型对象 - TABLES(普通表), VIEWS, DYNAMIC_TABLES, MATERIALIZED_VIEWS, EXTERNAL_TABLES"""
    schema_name = params.get("in_schema")
    pattern = params.get("like_pattern")
    limit = params.get("limit", 25)

    # 根据对象类型构建WHERE条件
    if object_type == "TABLES":
        # 普通表：排除所有特殊类型（视图、动态表、物化视图、外部表）
        where_condition = "is_view=false AND is_dynamic=false AND is_materialized_view=false AND is_external=false"
    elif object_type == "VIEWS":
        where_condition = "is_view=true"
    elif object_type == "DYNAMIC_TABLES":
        where_condition = "is_dynamic=true"
    elif object_type == "MATERIALIZED_VIEWS":
        where_condition = "is_materialized_view=true"
    elif object_type == "EXTERNAL_TABLES":
        where_condition = "is_external=true"
    else:
        # 不应该到达这里，但提供默认值
        where_condition = "1=1"

    # 构建查询
    query_parts = ["SHOW TABLES"]

    # 添加IN SCHEMA子句
    if schema_name:
        query_parts.extend(["IN", schema_name])

    # 添加WHERE条件
    where_conditions = [where_condition]

    # 添加LIKE模式匹配到WHERE条件中
    if pattern:
        where_conditions.append(f"table_name LIKE '{pattern}'")

    query_parts.extend(["WHERE", " AND ".join(where_conditions)])

    # 添加LIMIT
    if limit:
        query_parts.extend(["LIMIT", str(limit)])

    query = " ".join(query_parts)

    try:
        # 执行查询
        data, data_id = db.execute_query(query + ";")
        result_data = convert_df_to_dict(data)

        response = {
            "sql_query_executed": query,
            "result": result_data,
            "result_count": len(result_data),
            "object_type": object_type,
            "note": f"使用SHOW TABLES WHERE {where_condition}查询{object_type}"
        }

        # 添加截断提示
        if limit and len(result_data) >= limit:
            response["truncated"] = True
            response["hint"] = f"结果已限制为前 {limit} 个对象"

        return ResponseBuilder.create_yaml_json_response([response], data_id)

    except Exception as e:
        error_msg = str(e)
        suggestions = []

        if "permission" in error_msg.lower():
            suggestions.append(f"没有查看{object_type}的权限")
            suggestions.append("请检查用户权限设置")
        elif "not exist" in error_msg.lower():
            if schema_name:
                suggestions.append(f"Schema '{schema_name}' 不存在或无访问权限")
                suggestions.append("使用 show_object_list(object_type='SCHEMAS') 查看可用Schema")

        return ResponseBuilder.create_yaml_json_response({
            "success": False,
            "error": error_msg,
            "object_type": object_type,
            "sql_query_attempted": query,
            "suggestions": suggestions
        }, None)


async def _handle_functions_special_internal(params, db):
    """函数特殊处理 - 支持内置和外部函数（内部实现）"""
    object_type = params["object_type"]
    limit = params.get("limit", 25)
    schema_name = params.get("in_schema")
    pattern = params.get("like_pattern")

    # 确保limit是有效的数字
    if limit is None or not isinstance(limit, (int, str)) or str(limit).strip() == '':
        limit = 25

    # 构建查询
    query_parts = []
    if object_type == "FUNCTIONS":
        query_parts = ["SHOW FUNCTIONS"]
    else:  # EXTERNAL_FUNCTIONS
        query_parts = ["SHOW EXTERNAL FUNCTIONS"]

    # 添加 LIKE 模式匹配（SHOW FUNCTIONS 支持 LIKE 'pattern'）
    if pattern:
        query_parts.extend(["LIKE", f"'{pattern}'"])

    # 添加 LIMIT
    query_parts.extend(["LIMIT", str(limit)])
    query = " ".join(query_parts)

    try:
        data, data_id = db.execute_query(query + ";")
        result_data = convert_df_to_dict(data)

        response = {
            "sql_query_executed": query,
            "result": result_data,
            "result_count": len(result_data),
            "object_type": object_type,
            "note": "函数列表已按类型筛选"
        }

        if len(result_data) >= limit:
            response["truncated"] = True
            response["hint"] = f"结果已限制为前 {limit} 个函数"

        return ResponseBuilder.create_yaml_json_response([response], data_id)

    except Exception as e:
        return ResponseBuilder.create_yaml_json_response({
            "success": False,
            "error": str(e),
            "object_type": object_type,
            "sql_query_attempted": query,
            "suggestion": "请检查是否有查看函数的权限"
        }, None)


async def handle_tables_with_type_filter(params, db):
    """表类型过滤处理"""
    table_type_filters = params["table_type_filters"]
    limit = params.get("limit", 50)
    schema_name = params.get("in_schema")

    # 构建带过滤的查询 - ClickZetta统一使用SHOW TABLES + WHERE条件
    if table_type_filters == ["VIEWS"]:
        query = "SHOW TABLES WHERE is_view=true"
    elif table_type_filters == ["DYNAMIC_TABLES"]:
        query = "SHOW TABLES WHERE is_dynamic=true"
    elif table_type_filters == ["MATERIALIZED_VIEWS"]:
        query = "SHOW TABLES WHERE is_materialized_view=true"
    elif table_type_filters == ["EXTERNAL_TABLES"]:
        query = "SHOW TABLES WHERE is_external=true"
    elif table_type_filters == ["REGULAR_TABLES"]:
        # 普通表：排除所有特殊类型
        query = "SHOW TABLES WHERE is_view=false AND is_dynamic=false AND is_materialized_view=false AND is_external=false"
    elif len(table_type_filters) > 1:
        # 多类型组合过滤
        conditions = []
        if "VIEWS" in table_type_filters:
            conditions.append("is_view=true")
        if "DYNAMIC_TABLES" in table_type_filters:
            conditions.append("is_dynamic=true")
        if "MATERIALIZED_VIEWS" in table_type_filters:
            conditions.append("is_materialized_view=true")
        if "EXTERNAL_TABLES" in table_type_filters:
            conditions.append("is_external=true")

        if conditions:
            query = f"SHOW TABLES WHERE {' OR '.join(conditions)}"
        else:
            query = "SHOW TABLES"
    else:
        # 无过滤或未知过滤，使用默认查询
        query = "SHOW TABLES"

    # 添加schema限制
    if schema_name:
        if "WHERE" in query:
            query += f" AND schema_name = '{schema_name}'"
        else:
            query += f" IN SCHEMA {schema_name}"

    # 添加LIMIT子句
    query += f" LIMIT {limit}"

    try:
        data, data_id = db.execute_query(query + ";")
        result_data = convert_df_to_dict(data)

        response = {
            "sql_query_executed": query,
            "result": result_data,
            "result_count": len(result_data),
            "table_type_filters": table_type_filters,
            "filtered_by": "SQL指令直接过滤"
        }

        return ResponseBuilder.create_yaml_json_response([response], data_id)

    except Exception as e:
        return ResponseBuilder.create_yaml_json_response({
            "success": False,
            "error": str(e),
            "table_type_filters": table_type_filters,
            "sql_query_attempted": query,
            "suggestion": "请检查表类型过滤参数和权限"
        }, None)


# =================== 对象描述处理 ===================

async def handle_desc_object(arguments, db, write_detector, allow_write, server, *_):
    """
    描述对象处理器 - 支持所有ClickZetta对象类型的详细描述
    """
    try:
        # 使用参数处理器
        params = HandlerFactory.desc_object().process_arguments(arguments)

        object_type = params["object_type"]
        object_name = params["object_name"]
        extended = params.get("extended", False)

        # 标准化对象类型名称，处理空格和下划线的差异
        object_type_normalized = object_type.upper().replace(" ", "_")

        # 构建DESC语句
        query_parts = ["DESC"]

        # 特殊对象类型处理
        if object_type_normalized in ["EXTERNAL_FUNCTION", "FUNCTION"] and extended:
            # 函数类型支持EXTENDED
            query_parts.extend(["FUNCTION", "EXTENDED", object_name])
        elif object_type_normalized in ["EXTERNAL_FUNCTION", "FUNCTION"]:
            # 外部函数和普通函数都使用DESC FUNCTION语法
            query_parts.extend(["FUNCTION", object_name])
        elif object_type_normalized in ["TABLE", "EXTERNAL_TABLE", "DYNAMIC_TABLE", "MATERIALIZED_VIEW"] and extended:
            # 对于所有表类型对象，当extended=true时使用EXTENDED
            query_parts.extend(["TABLE", "EXTENDED", object_name])
        elif object_type_normalized in ["TABLE", "EXTERNAL_TABLE", "VIEW", "DYNAMIC_TABLE", "MATERIALIZED_VIEW"]:
            # 对于所有表类型对象（表、外部表、视图、动态表、物化视图），统一使用TABLE关键字
            # 根据ClickZetta文档，所有这些类型都使用DESC [TABLE] [EXTENDED] table_name语法
            query_parts.extend(["TABLE", object_name])
        else:
            # 其他对象类型（SCHEMA, CONNECTION, VCLUSTER等）
            query_parts.extend([object_type_normalized, object_name])

        query = " ".join(query_parts)

        try:
            # 执行描述查询
            data, data_id = db.execute_query(query + ";")
            result_data = convert_df_to_dict(data)

            response = {
                "query_type": "DESCRIBE",
                "object_type": object_type,
                "object_name": object_name,
                "sql_query_executed": query,
                "result": result_data
            }

            # 添加扩展信息标识
            if extended:
                response["extended_info"] = True
                response["note"] = "包含扩展属性信息"

            return ResponseBuilder.create_yaml_json_response([response], data_id)

        except Exception as e:
            error_msg = str(e)
            suggestions = []

            if "does not exist" in error_msg.lower() or "not found" in error_msg.lower():
                suggestions.append(f"对象 '{object_name}' 不存在")
                suggestions.append(f"使用 show_object_list(object_type='{object_type}S') 查看可用对象")
            elif "permission" in error_msg.lower():
                suggestions.append("没有访问此对象的权限")
                suggestions.append("请检查用户权限设置")
            elif "invalid" in error_msg.lower():
                suggestions.append(f"对象类型 '{object_type}' 可能不支持DESC操作")
                suggestions.append("请确认对象类型是否正确")

            return ResponseBuilder.create_yaml_json_response({
                "error": error_msg,
                "object_type": object_type,
                "object_name": object_name,
                "sql_query_attempted": query,
                "suggestions": suggestions
            }, None)

    except Exception as e:
        return ResponseBuilder.create_yaml_json_response({
            "success": False,
            "error": str(e),
            "operation": "DESCRIBE OBJECT",
            "suggestion": "请检查对象名称和类型参数"
        }, None)


async def handle_desc_history(arguments, db, write_detector, allow_write, server, *_):
    """
    描述历史对象处理器 - 查看对象的历史版本信息
    """
    try:
        # 使用参数处理器
        params = HandlerFactory.desc_object_history().process_arguments(arguments)

        object_name = params["object_name"]
        object_type = params["object_type"]
        limit = params.get("limit", 10)

        # 构建DESC HISTORY语句，包含对象类型以提高准确性
        query = f"DESC HISTORY {object_type} {object_name}"

        # 如果需要限制结果数量，添加LIMIT子句
        if limit and limit > 0:
            query += f" LIMIT {limit}"

        try:
            # 执行历史查询
            data, data_id = db.execute_query(query + ";")
            result_data = convert_df_to_dict(data)

            response = {
                "query_type": "DESCRIBE HISTORY",
                "object_name": object_name,
                "object_type": object_type,
                "limit_applied": limit,
                "sql_query_executed": query,
                "history_count": len(result_data),
                "result": result_data
            }

            # 添加历史信息说明
            if len(result_data) == 0:
                response["note"] = "此对象没有历史版本记录"
            else:
                response["note"] = f"找到 {len(result_data)} 个历史版本"

            return ResponseBuilder.create_yaml_json_response([response], data_id)

        except Exception as e:
            error_msg = str(e)
            suggestions = []

            if "does not exist" in error_msg.lower():
                suggestions.append(f"对象 '{object_name}' 不存在")
                suggestions.append("请检查对象名称是否正确")
            elif "not supported" in error_msg.lower():
                suggestions.append("此对象类型不支持历史查询")
                suggestions.append("只有TABLE、VIEW等支持历史记录")
            elif "permission" in error_msg.lower():
                suggestions.append("没有查看对象历史的权限")

            return ResponseBuilder.create_yaml_json_response({
                "error": error_msg,
                "object_name": object_name,
                "object_type": object_type,
                "limit_requested": limit,
                "sql_query_attempted": query,
                "suggestions": suggestions
            }, None)

    except Exception as e:
        return ResponseBuilder.create_yaml_json_response({
            "success": False,
            "error": str(e),
            "operation": "DESCRIBE HISTORY",
            "suggestion": "请检查对象名称参数"
        }, None)


# =================== 统一导出函数 ===================

async def handle_functions_special(arguments, db, write_detector, allow_write, server, *_):
    """兼容性函数 - 函数特殊处理的直接调用接口"""
    # 解析参数并调用内部函数
    try:
        params = HandlerFactory.show_object_list().process_arguments(arguments)
        return await _handle_functions_special_internal(params, db)
    except Exception as e:
        return ResponseBuilder.create_yaml_json_response({
            "success": False,
            "error": str(e),
            "operation": "FUNCTIONS SPECIAL",
            "suggestion": "请检查函数查询参数"
        }, None)