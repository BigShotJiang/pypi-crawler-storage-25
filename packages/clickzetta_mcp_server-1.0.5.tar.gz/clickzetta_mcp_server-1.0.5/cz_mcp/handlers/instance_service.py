from loguru import logger

from cz_mcp.utils.config_utils import read_url, read_api
from cz_mcp.utils.request_utils import RequestUtils


def service_csp_list(jwt, env, workspace_name=None):
    url = read_url(env=env) + read_api("SERVICE_CSP_LIST")

    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": str(jwt),
        "cz-lang": "zh_CN",
    }
    if workspace_name:
        headers["workspaceName"] = workspace_name

    response = RequestUtils().get(url=url, headers=headers)
    if response.status_code != 200:
        logger.error(f"Failed to fetch csp. Status code: {response.status_code}, Response: {response.text}")
        raise ValueError(f"Failed to fetch service csp list: {response.text}")

    data = response.json()

    return data.get("data", [])


def service_instance_list(account_id, jwt, env, workspace_name=None):
    url = read_url(env=env) + read_api("SERVICE_INSTANCE_LIST")

    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": str(jwt),
        "cz-lang": "zh_CN",
    }
    if workspace_name:
        headers["workspaceName"] = workspace_name

    json_data = {
        "accountId": account_id,
    }

    response = RequestUtils().get(url=url, params=json_data, headers=headers)
    if response.status_code != 200:
        logger.error(f"Failed to fetch workspace. Status code: {response.status_code}, Response: {response.text}")
        raise ValueError(f"Failed to fetch service instance list: {response.text}")

    data = response.json()

    return data.get("data", [])


def service_region_list(jwt, env, csp_id):
    url = read_url(env=env) + read_api("SERVICE_REGION_LIST")
    
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": str(jwt),
        "cz-lang": "zh_CN",
    }
    
    params = {"cspId": csp_id}
    
    response = RequestUtils().get(url=url, params=params, headers=headers)
    if response.status_code != 200:
        logger.error(f"Failed to fetch region list. Status code: {response.status_code}, Response: {response.text}")
        raise ValueError(f"Failed to fetch service region list: {response.text}")
    
    data = response.json()
    return data.get("data", [])


def get_instance_by_csp_id(account_id, jwt, env, csp_id):
    # Get region list filtered by csp_id
    regions = service_region_list(jwt, env, csp_id)
    if not regions:
        logger.error(f"No regions found for csp_id={csp_id}")
        return None
    
    # Filter regions by cregionId matching env
    matching_region = None
    for region in regions:
        if region.get("cregionId") == env:
            matching_region = region
            break
    
    if not matching_region:
        logger.error(f"No region found with cregionId={env} for csp_id={csp_id}")
        return None
    
    # Get region_id from the matching region
    region_id = matching_region.get("id")
    if not region_id:
        logger.error(f"Region missing 'id' field: {matching_region}")
        return None
    
    # Get instances and filter by region_id
    instances = service_instance_list(account_id, jwt, env)
    if instances:
        for instance in instances:
            if instance.get("regionId") == region_id:
                return instance
    
    logger.error(f"No instance found for region_id={region_id}")
    return None


def get_instance_by_region_id(account_id, jwt, env, region_id):
    instances = service_instance_list(account_id, jwt, env)
    if instances:
        for instance in instances:
            if instance.get("regionId") == region_id:
                return instance
    return None
