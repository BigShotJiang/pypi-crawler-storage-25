import os
import re
from dataclasses import dataclass
from enum import Enum
from typing import Any, Optional, Callable, List, Dict
import json

from cz_mcp.handlers.transformer import Transformers

# Notice: Current function is deprecated. Should not edit.


def _normalize_db_type(db_type: str) -> str:
    """
    标准化数据库类型名称，支持常见别名和大小写不敏感
    将用户输入转换为 DataValidator.validate_connection_type 期望的格式
    """
    if not db_type:
        return db_type

    # 转换为小写进行比较
    db_type_lower = db_type.lower()

    # 数据库类型映射表 - 从用户输入到标准格式
    db_type_mapping = {
        # MySQL variants
        "mysql": "mysql",
        "mariadb": "mysql",  # MariaDB 使用 MySQL 连接器

        # PostgreSQL variants
        "postgresql": "postgresql",
        "postgres": "postgresql",
        "pgsql": "postgresql",

        # SQL Server variants
        "sqlserver": "sqlserver",
        "mssql": "sqlserver",
        "sql server": "sqlserver",
        "microsoft sql server": "sqlserver",

        # Oracle variants
        "oracle": "oracle",
        "oracle database": "oracle",

        # ClickHouse variants
        "clickhouse": "clickhouse",
        "click house": "clickhouse",

        # Others
        "hive": "hive",
        "spark": "spark",
        "sqlite": "sqlite",
        "sqlite3": "sqlite"
    }

    return db_type_mapping.get(db_type_lower, db_type_lower)


class ParamType(Enum):
    """参数类型枚举"""
    REQUIRED = "required"
    OPTIONAL = "optional"

@dataclass
class ParamDefinition:
    """参数定义"""
    name: str
    param_type: ParamType
    default_value: Any = None
    env_var: Optional[str] = None
    validator: Optional[Callable[[Any], bool]] = None
    transformer: Optional[Callable[[Any], Any]] = None
    error_message: Optional[str] = None


class Validators:
    """常用验证器"""

    @staticmethod
    def is_list_or_none(value: Any) -> bool:
        """允许列表或None值"""
        return value is None or isinstance(value, list)

    @staticmethod
    def positive_number(value: Any) -> bool:
        """验证正数（int或float）"""
        return isinstance(value, (int, float)) and value > 0

    @staticmethod
    def range_validator(min_val: float, max_val: float) -> Callable[[Any], bool]:
        """范围验证器"""

        def validator(value: Any) -> bool:
            if not isinstance(value, (int, float)):
                return False
            return min_val <= value <= max_val

        return validator

    @staticmethod
    def non_empty_string(value: Any) -> bool:
        return isinstance(value, str) and value.strip() != ""

    @staticmethod
    def positive_integer(value: Any) -> bool:
        return isinstance(value, int) and value > 0

    @staticmethod
    def non_negative_integer(value: Any) -> bool:
        return isinstance(value, int) and value >= 0

    @staticmethod
    def is_bool_or_none(value: Any) -> bool:
        return value is None or isinstance(value, bool)

    @staticmethod
    def handler_format_validator(value: Any) -> bool:
        """
        🚀 Handler格式验证器 - 验证ClickZetta Handler格式
        允许：'module.class', 'package.module.class' 等格式
        不允许：'class', '.invalid.', '' 等格式
        """
        if not isinstance(value, str) or not value.strip():
            return False

        # 检查基本格式要求
        value = value.strip()

        # 如果没有点，在转换器中会自动修正，这里认为是有效的
        if '.' not in value:
            return True  # 会被转换器自动修正

        # 验证包含点的格式
        parts = value.split('.')
        if len(parts) < 2:
            return False

        # 检查每个部分都不为空
        return all(part.strip() for part in parts)

    @staticmethod
    def is_dict(value: Any) -> bool:
        return isinstance(value, dict)

    @staticmethod
    def is_dict_or_none(value: Any) -> bool:
        """允许字典或None值"""
        return value is None or isinstance(value, dict)

    @staticmethod
    def in_choices(choices: List[str]) -> Callable[[Any], bool]:
        def validator(value: Any) -> bool:
            return value in choices

        validator._choices = choices  # 存储选择列表用于错误信息
        return validator

    @staticmethod
    def in_choices_case_insensitive(choices: List[str]) -> Callable[[Any], bool]:
        """大小写不敏感的选择验证器"""
        lower_choices = [choice.lower() for choice in choices]

        def validator(value: Any) -> bool:
            if isinstance(value, str):
                return value.lower() in lower_choices
            return value in choices

        validator._choices = choices  # 存储选择列表用于错误信息
        return validator

    @staticmethod
    def regex(pattern: str, flags: int = 0) -> Callable[[Any], bool]:
        """正则表达式验证器"""
        try:
            compiled_pattern = re.compile(pattern, flags)

            def validator(value: Any) -> bool:
                if not isinstance(value, str):
                    return False
                return bool(compiled_pattern.match(value))

            return validator
        except re.error as e:
            # 如果正则表达式编译失败，返回一个总是失败的验证器
            def failed_validator(value: Any) -> bool:
                return False

            return failed_validator

    @staticmethod
    def connection_name(value: Any) -> bool:
        """验证连接名称格式"""
        if not isinstance(value, str):
            return False
        # 连接名称只能包含字母、数字、下划线
        pattern = r'^[a-zA-Z0-9_]+$'
        return bool(re.match(pattern, value))

    @staticmethod
    def non_empty_string_or_none(value: Any) -> bool:
        """允许非空字符串或None值"""
        if value is None:
            return True
        return isinstance(value, str) and value.strip() != ""

    @staticmethod
    def is_boolean_or_none(value: Any) -> bool:
        """允许布尔值或None值"""
        return value is None or isinstance(value, bool) or (
                    isinstance(value, str) and value.lower() in ['true', 'false'])

    @staticmethod
    def resource_uris_list(value: Any) -> bool:
        """验证resource_uris格式：支持JSON字符串或数组格式"""
        if isinstance(value, list):
            return len(value) > 0
        if isinstance(value, str):
            try:
                import json
                parsed = json.loads(value)
                return isinstance(parsed, list) and len(parsed) > 0
            except (json.JSONDecodeError, ValueError):
                return False
        return False


class ResponseControlMixin:
    """响应控制参数混入 - 用于批量添加verbose和include_sql参数"""

    @staticmethod
    def add_response_control_params(handler: 'ParameterHandler') -> 'ParameterHandler':
        """
        为handler添加标准的响应控制参数

        Args:
            handler: 参数处理器实例

        Returns:
            添加了响应控制参数的handler
        """
        return (handler
                .define_param("verbose", ParamType.OPTIONAL,
                              default_value=None,
                              transformer=Transformers.to_bool,
                              description="是否返回详细信息（包括SQL、日志等）")
                .define_param("include_sql", ParamType.OPTIONAL,
                              default_value=None,
                              transformer=Transformers.to_bool,
                              description="是否在响应中包含执行的SQL语句"))


class ParameterHandler:
    """统一的参数处理器"""

    def __init__(self, tool_name: str):
        self.tool_name = tool_name
        self.param_definitions: List[ParamDefinition] = []

    def define_param(self,
                     name: str,
                     param_type: ParamType,
                     default_value: Any = None,
                     env_var: Optional[str] = None,
                     validator: Optional[Callable[[Any], bool]] = None,
                     transformer: Optional[Callable[[Any], Any]] = None,
                     error_message: Optional[str] = None,
                     description: Optional[str] = None) -> 'ParameterHandler':
        """定义参数"""
        self.param_definitions.append(ParamDefinition(
            name=name,
            param_type=param_type,
            default_value=default_value,
            env_var=env_var,
            validator=validator,
            transformer=transformer,
            error_message=error_message
        ))
        return self

    def process_arguments(self, arguments: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """处理参数并返回标准化的参数字典 - 修复None值处理"""
        if not arguments:
            arguments = {}

        result = {}
        missing_required = []

        for param_def in self.param_definitions:
            value = None

            try:
                # 1. 获取参数值
                if param_def.param_type == ParamType.REQUIRED:
                    if param_def.name not in arguments:
                        missing_required.append(param_def.name)
                        continue
                    value = arguments[param_def.name]

                elif param_def.param_type == ParamType.OPTIONAL:
                    value = arguments.get(param_def.name, param_def.default_value)

                elif param_def.param_type == ParamType.ENV_FALLBACK:
                    if param_def.name in arguments:
                        value = arguments[param_def.name]
                    elif param_def.env_var:
                        value = os.getenv(param_def.env_var, param_def.default_value)
                    else:
                        value = param_def.default_value

                # 2. 类型转换 - 修复: 对None值的特殊处理
                if value is not None and param_def.transformer:
                    try:
                        value = param_def.transformer(value)
                    except Exception as e:
                        raise ValueError(f"参数 '{param_def.name}' 转换失败: {e}")

                # 3. 验证 - 修复: 允许验证器处理None值
                if param_def.validator and value is not None:
                    try:
                        if not param_def.validator(value):
                            # 改进错误信息，特别是选择列表验证器
                            if hasattr(param_def.validator, '_choices'):
                                choices = param_def.validator._choices
                                error_msg = param_def.error_message or f"参数 '{param_def.name}' 值 '{value}' 无效，支持的值: {', '.join(choices)}"
                            else:
                                error_msg = param_def.error_message or f"参数 '{param_def.name}' 验证失败"
                            raise ValueError(error_msg)
                    except Exception as e:
                        if "NoneType" in str(e):
                            # None值验证失败时，使用默认值
                            if param_def.default_value is not None:
                                value = param_def.default_value
                            else:
                                raise ValueError(f"参数 '{param_def.name}' 不能为空")
                        else:
                            raise e

                result[param_def.name] = value

            except Exception as e:
                # 捕获所有异常，避免导致整个server崩溃
                raise ValueError(f"处理参数 '{param_def.name}' 时发生错误: {e}")

        # 检查必需参数
        if missing_required:
            raise ValueError(f"{self.tool_name} 缺少必需参数: {', '.join(missing_required)}")

        return result


# 预定义的参数处理器工厂
class HandlerFactory:
    """Handler参数处理器工厂"""
    @staticmethod
    def get_product_knowledge():
        """获取产品知识搜索参数处理器"""
        return ParameterHandler("get_product_knowledge") \
            .define_param("question", ParamType.REQUIRED,
                    validator=Validators.non_empty_string,
                    description="用户问题或搜索关键词") \
            .define_param("vector_search_limit_n", ParamType.OPTIONAL,
                    default_value=3,
                    transformer=Transformers.to_int,
                    validator=Validators.range_validator(1, 20),
                    description="返回结果数量限制") \
            .define_param("table_name", ParamType.OPTIONAL,
                    default_value="knowledge_base",
                    validator=Validators.non_empty_string,
                    description="知识库表名") \
            .define_param("embedding_column_name", ParamType.OPTIONAL,
                    default_value="embeddings",
                    validator=Validators.non_empty_string,
                    description="向量列名") \
            .define_param("content_column_name", ParamType.OPTIONAL,
                    default_value="text",
                    validator=Validators.non_empty_string,
                    description="内容列名") \
            .define_param("other_columns", ParamType.OPTIONAL,
                    default_value="",
                    description="其他要返回的列名") \
            .define_param("partition_scope", ParamType.OPTIONAL,
                    default_value="",
                    description="分区范围过滤条件")
    @staticmethod
    def create_external_catalog() -> ParameterHandler:
        """创建外部目录参数处理器 - 修复：移除不支持的comment参数"""
        return (ParameterHandler("create_external_catalog")
                .define_param("catalog_name", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="外部目录名称")
                .define_param("connection", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="目录连接名称")
                .define_param("options", ParamType.OPTIONAL,
                            default_value={},
                            validator=Validators.is_dict_or_none,
                            description="其他选项"))
                # 修复：移除comment参数，因为CREATE EXTERNAL CATALOG语法不支持COMMENT子句

    @staticmethod
    def create_external_schema() -> ParameterHandler:
        """创建外部Schema参数处理器"""
        return (ParameterHandler("create_external_schema")
                .define_param("schema_name", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="外部Schema名称")
                .define_param("connection", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="连接名称")
                .define_param("database", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="外部数据库名称")
                .define_param("options", ParamType.OPTIONAL,
                            default_value={},
                            validator=Validators.is_dict_or_none,
                            description="其他选项"))

    @staticmethod
    def create_function() -> ParameterHandler:
        """创建SQL函数参数处理器 - 支持标量函数和表函数"""
        return (ParameterHandler("create_function")
                .define_param("function_name", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="函数名称，可使用schema限定（如my_schema.function_name）")
                .define_param("parameters", ParamType.OPTIONAL,
                            default_value=[],
                            transformer=Transformers.parse_function_parameters,
                            validator=Validators.is_list_or_none,
                            description="函数参数列表，支持字符串格式：'x INT, y INT' 或列表格式：[{'name': 'x', 'type': 'INT'}, ...]")
                .define_param("returns_type", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.to_upper,
                            description="标量函数返回类型（如DOUBLE、STRING、INT）")
                .define_param("return_type", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.to_upper,
                            description="标量函数返回类型的别名（与returns_type相同）")
                .define_param("returns_table", ParamType.OPTIONAL,
                            validator=Validators.is_list_or_none,
                            description="表函数返回结构，格式：[{'name': 'col1', 'type': 'STRING'}, ...]")
                .define_param("function_body", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            description="函数体，可以是表达式或查询")
                .define_param("or_replace", ParamType.OPTIONAL,
                            default_value=False,
                            transformer=Transformers.to_bool,
                            description="是否替换已存在的函数")
                .define_param("if_not_exists", ParamType.OPTIONAL,
                            default_value=False,
                            transformer=Transformers.to_bool,
                            description="仅在函数不存在时创建")
                .define_param("comment", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            description="函数注释")
                # 注意：接受language参数以便提供更好的错误提示
                .define_param("language", ParamType.OPTIONAL,
                            transformer=Transformers.to_upper,
                            description="已废弃：CREATE FUNCTION只支持SQL，请使用create_external_function创建Python/Java函数"))

    @staticmethod
    def run_happy_paths() -> ParameterHandler:
        """运行Happy Path演示参数处理器"""
        return (ParameterHandler("run_happy_paths")
                .define_param("language", ParamType.OPTIONAL,
                            default_value="中文",
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="演示语言"))

    @staticmethod
    def add_data_insight() -> ParameterHandler:
        """添加数据洞察参数处理器"""
        return (ParameterHandler("add_data_insight")
                .define_param("insight", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            description="数据洞察内容"))

    @staticmethod
    def read_query() -> ParameterHandler:
        """读取查询参数处理器 - 增强版，支持响应控制"""
        return (ParameterHandler("read_query")
                .define_param("query", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="SELECT查询语句")

                # 响应控制参数
                .define_param("verbose", ParamType.OPTIONAL,
                            default_value=None,  # None表示使用环境配置
                            transformer=Transformers.to_bool,
                            description="是否返回详细信息（包括SQL、警告等）")

                .define_param("include_sql", ParamType.OPTIONAL,
                            default_value=None,
                            transformer=Transformers.to_bool,
                            description="是否在响应中包含执行的SQL")

                .define_param("response_format", ParamType.OPTIONAL,
                            validator=Validators.in_choices(["minimal", "standard", "detailed"]),
                            transformer=Transformers.to_lower,
                            description="响应格式级别"))

    @staticmethod
    def write_query() -> ParameterHandler:
        """写入查询参数处理器 - 增强版，支持响应控制"""
        return (ParameterHandler("write_query")
                .define_param("query", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="INSERT/UPDATE/DELETE查询语句")

                # 响应控制参数
                .define_param("verbose", ParamType.OPTIONAL,
                            default_value=None,
                            transformer=Transformers.to_bool,
                            description="是否返回详细信息")

                .define_param("include_sql", ParamType.OPTIONAL,
                            default_value=None,
                            transformer=Transformers.to_bool,
                            description="是否返回执行的SQL语句"))
    @staticmethod
    def switch_context() -> ParameterHandler:
        """切换上下文参数处理器 - 映射到统一的上下文切换处理器"""
        return HandlerFactory.switch_context_unified()

    @staticmethod
    def switch_vcluster_schema() -> ParameterHandler:
        """切换VCluster和Schema参数处理器"""
        return (ParameterHandler("switch_vcluster_schema")
                .define_param("schema_name", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            description="要切换到的schema名称")
                .define_param("vcluster_name", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            description="要切换到的vcluster名称"))

    @staticmethod
    def switch_workspace() -> ParameterHandler:
        """切换workspace参数处理器"""
        return (ParameterHandler("switch_workspace")
                .define_param("workspace_name", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="目标workspace名称")
                .define_param("list_workspaces", ParamType.OPTIONAL,
                            default_value=False,
                            transformer=Transformers.to_bool,
                            description="是否列出所有可用workspace")
                .define_param("update_config", ParamType.OPTIONAL,
                            default_value=False,
                            transformer=Transformers.to_bool,
                            description="是否永久更新配置文件"))

    @staticmethod
    def switch_context_unified() -> ParameterHandler:
        """统一的上下文切换参数处理器"""
        return (ParameterHandler("switch_context_unified")
                .define_param("connection", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            description="目标连接名称")
                .define_param("workspace", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            description="目标workspace名称")
                .define_param("schema", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            description="目标schema名称")
                .define_param("vcluster", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            description="目标vcluster名称")
                .define_param("show_current", ParamType.OPTIONAL,
                            default_value=False,
                            transformer=Transformers.to_bool,
                            description="显示当前上下文信息")
                .define_param("update_config", ParamType.OPTIONAL,
                            default_value=False,
                            transformer=Transformers.to_bool,
                            description="是否永久更新配置文件"))

    @staticmethod
    def create_vcluster() -> ParameterHandler:
        """创建计算集群参数处理器 - 基于ClickZetta文档"""
        return (ParameterHandler("create_vcluster")
                .define_param("cluster_name", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            description="计算集群名称，3-28字符，仅支持字母、下划线、数字")
                .define_param("if_not_exists", ParamType.OPTIONAL,
                            default_value=False,
                            transformer=Transformers.to_bool,
                            description="如果集群已存在是否跳过创建")
                .define_param("vcluster_type", ParamType.OPTIONAL,
                            default_value="GENERAL",
                            validator=Validators.in_choices(["GENERAL", "ANALYTICS", "INTEGRATION"]),
                            transformer=Transformers.to_upper,
                            description="计算集群类型")
                .define_param("vcluster_size", ParamType.OPTIONAL,
                            transformer=Transformers.to_int,
                            validator=Validators.positive_integer,
                            description="计算集群规格(1-256 CRU)")
                .define_param("min_vcluster_size", ParamType.OPTIONAL,
                            transformer=Transformers.to_int,
                            validator=Validators.positive_integer,
                            description="最小集群规格(GENERAL类型)")
                .define_param("max_vcluster_size", ParamType.OPTIONAL,
                            transformer=Transformers.to_int,
                            validator=Validators.positive_integer,
                            description="最大集群规格(GENERAL类型)")
                .define_param("min_replicas", ParamType.OPTIONAL,
                            transformer=Transformers.to_int,
                            validator=Validators.positive_integer,
                            description="最小实例数(ANALYTICS类型)")
                .define_param("max_replicas", ParamType.OPTIONAL,
                            transformer=Transformers.to_int,
                            validator=Validators.positive_integer,
                            description="最大实例数(ANALYTICS类型)")
                .define_param("auto_suspend_in_second", ParamType.OPTIONAL,
                            transformer=Transformers.to_int,
                            description="自动暂停时间(秒)")
                .define_param("auto_resume", ParamType.OPTIONAL,
                            default_value=True,
                            transformer=Transformers.to_bool,
                            description="是否自动恢复")
                .define_param("max_concurrency", ParamType.OPTIONAL,
                            transformer=Transformers.to_int,
                            validator=Validators.positive_integer,
                            description="最大并发数(ANALYTICS类型)")
                .define_param("query_runtime_limit_in_second", ParamType.OPTIONAL,
                            transformer=Transformers.to_int,
                            validator=Validators.positive_integer,
                            description="查询运行时间限制(秒)")
                .define_param("preload_tables", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            description="预加载表(ANALYTICS类型)")
                .define_param("query_resource_limit_ratio", ParamType.OPTIONAL,
                            # 修复：移除 to_float 转换，因为 JSON schema 中已经是 number 类型
                            description="单作业资源占比阈值(0.0-1.0)")
                .define_param("comment", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            description="集群注释"))

    @staticmethod
    def alter_vcluster() -> ParameterHandler:
        """修改计算集群参数处理器 - 基于ClickZetta文档"""
        return (ParameterHandler("alter_vcluster")
                .define_param("cluster_name", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            description="计算集群名称")
                .define_param("operation", ParamType.REQUIRED,
                            validator=Validators.in_choices([
                                "RESUME", "SUSPEND", "CANCEL_ALL_JOBS", "SET", "SET_COMMENT"
                            ]),
                            transformer=Transformers.to_upper,
                            description="操作类型")
                .define_param("if_exists", ParamType.OPTIONAL,
                            default_value=False,
                            transformer=Transformers.to_bool,
                            description="如果集群不存在是否跳过操作")
                .define_param("force", ParamType.OPTIONAL,
                            default_value=False,
                            transformer=Transformers.to_bool,
                            description="是否强制操作(SUSPEND时使用)")
                # SET操作的属性参数
                .define_param("vcluster_size", ParamType.OPTIONAL,
                            transformer=Transformers.to_int,
                            validator=Validators.positive_integer,
                            description="计算集群规格(1-256 CRU)")
                .define_param("min_vcluster_size", ParamType.OPTIONAL,
                            transformer=Transformers.to_int,
                            validator=Validators.positive_integer,
                            description="最小集群规格(GENERAL类型)")
                .define_param("max_vcluster_size", ParamType.OPTIONAL,
                            transformer=Transformers.to_int,
                            validator=Validators.positive_integer,
                            description="最大集群规格(GENERAL类型)")
                .define_param("min_replicas", ParamType.OPTIONAL,
                            transformer=Transformers.to_int,
                            validator=Validators.positive_integer,
                            description="最小实例数(ANALYTICS类型)")
                .define_param("max_replicas", ParamType.OPTIONAL,
                            transformer=Transformers.to_int,
                            validator=Validators.positive_integer,
                            description="最大实例数(ANALYTICS类型)")
                .define_param("auto_suspend_in_second", ParamType.OPTIONAL,
                            transformer=Transformers.to_int,
                            description="自动暂停时间(秒)")
                .define_param("auto_resume", ParamType.OPTIONAL,
                            transformer=Transformers.to_bool,
                            description="是否自动恢复")
                .define_param("max_concurrency", ParamType.OPTIONAL,
                            transformer=Transformers.to_int,
                            validator=Validators.positive_integer,
                            description="最大并发数(ANALYTICS类型)")
                .define_param("query_runtime_limit_in_second", ParamType.OPTIONAL,
                            transformer=Transformers.to_int,
                            validator=Validators.positive_integer,
                            description="查询运行时间限制(秒)")
                .define_param("preload_tables", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            description="预加载表(ANALYTICS类型)")
                .define_param("query_resource_limit_ratio", ParamType.OPTIONAL,
                            # 修复：移除 to_float 转换
                            description="单作业资源占比阈值(0.0-1.0)")
                .define_param("vcluster_type", ParamType.OPTIONAL,
                            validator=Validators.in_choices(["GENERAL", "ANALYTICS", "INTEGRATION"]),
                            transformer=Transformers.to_upper,
                            description="计算集群类型")
                .define_param("comment", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            description="集群注释"))
    @staticmethod
    def add_knowledge_entry() -> ParameterHandler:
        """添加知识条目参数处理器"""
        return (ParameterHandler("add_knowledge_entry")
                .define_param("knowledge_table_name", ParamType.REQUIRED,
                             validator=Validators.non_empty_string,
                             transformer=Transformers.strip_string,
                             description="知识表名称")
                .define_param("knowledge", ParamType.REQUIRED,
                             validator=Validators.non_empty_string,
                             description="知识内容"))
    @staticmethod
    def vector_search() -> ParameterHandler:
        """向量搜索参数处理器 - 修复版本，支持智能列名推断"""
        return (ParameterHandler("vector_search")
                .define_param("question", ParamType.REQUIRED,
                             validator=Validators.non_empty_string,
                             error_message="question 参数不能为空")
                .define_param("table_name", ParamType.OPTIONAL,  # 修改：改为可选参数，从配置获取
                             default_value="",
                             description="表名称，如不指定会使用配置文件中的similar_search.table_name")
                .define_param("embedding_column_name", ParamType.OPTIONAL,  # 修改：改为可选
                             default_value="",
                             description="向量列名，如不指定会智能推断")
                .define_param("content_column_name", ParamType.OPTIONAL,  # 修改：改为可选
                             default_value="",
                             description="内容列名，如不指定会智能推断")
                .define_param("partition_scope", ParamType.OPTIONAL,  # 修改：改为可选
                             default_value="",
                             description="分区范围条件")
                .define_param("other_columns", ParamType.OPTIONAL,  # 修改：改为可选
                             default_value="",
                             description="其他要查询的列")
                .define_param("vector_search_limit_n", ParamType.OPTIONAL,
                             default_value=1,
                             transformer=Transformers.to_int,
                             validator=Validators.positive_integer,
                             description="返回结果数量限制")
                .define_param("distance_threshold", ParamType.OPTIONAL,
                             default_value=0.8,
                             transformer=Transformers.to_float,
                             validator=Validators.range_validator(0.0, 2.0),
                             description="向量距离阈值，越小越严格。归一化向量：0-1，未归一化向量：0-2"))

    @staticmethod
    def match_all() -> ParameterHandler:
        """全文搜索参数处理器"""
        return (ParameterHandler("match_all")
                .define_param("question", ParamType.REQUIRED,
                             validator=Validators.non_empty_string)
                .define_param("table_name", ParamType.OPTIONAL,
                             default_value="knowledge_base",
                             description="要搜索的表名")
                .define_param("content_column_name", ParamType.OPTIONAL,
                             default_value="",
                             description="内容列名，留空则自动检测")
                .define_param("other_columns", ParamType.OPTIONAL,
                             default_value="",
                             description="其他要选择的列，格式: column1, column2, column3")
                .define_param("match_limit_n", ParamType.OPTIONAL,
                             default_value=10,
                             validator=Validators.positive_integer,
                             description="匹配结果的限制数量")
                .define_param("partition_scope", ParamType.OPTIONAL,
                             default_value="",
                             description="分区范围条件")
                .define_param("verbose", ParamType.OPTIONAL,
                             default_value=False,
                             transformer=Transformers.to_bool,
                             description="是否返回详细信息"))


    @staticmethod
    def describe_table() -> ParameterHandler:
        """描述表参数处理器"""
        return (ParameterHandler("describe_table")
                .define_param("table_name", ParamType.REQUIRED,
                             validator=Validators.non_empty_string,
                             transformer=Transformers.strip_string))

    @staticmethod
    def show_object_list() -> ParameterHandler:
        """显示对象列表参数处理器 - 增强版本，支持结构化输入"""
        return (ParameterHandler("show_object_list")
                # 基本模式：直接传入SHOW命令
                .define_param("show_command", ParamType.OPTIONAL,
                             validator=Validators.non_empty_string,
                             transformer=lambda x: x.strip().upper(),
                             description="完整的SHOW命令（向后兼容）")

                # 结构化模式：分解参数
                .define_param("object_type", ParamType.REQUIRED,  # 修复：改回REQUIRED
                             validator=Validators.in_choices([
                                 "WORKSPACES", "TABLES", "VIEWS", "SCHEMAS", "CATALOGS", "FUNCTIONS", "EXTERNAL FUNCTIONS", "VOLUMES",
                                 "CONNECTIONS", "VCLUSTERS", "JOBS", "PIPES", "USERS",
                                 "ROLES", "GRANTS", "SHARES", "TABLE STREAMS", "DYNAMIC TABLES",
                                 "MATERIALIZED VIEWS", "EXTERNAL TABLES", "EXTERNAL SCHEMAS", "NETWORK POLICY"
                             ]),
                             transformer=Transformers.normalize_object_type,
                             description="对象类型（默认为TABLES）")

                # 通用过滤参数
                .define_param("in_schema", ParamType.OPTIONAL,
                             validator=Validators.non_empty_string,
                             transformer=Transformers.strip_string,
                             description="在指定Schema中查找（支持TABLES/VOLUMES/PIPES等）")

                .define_param("like_pattern", ParamType.OPTIONAL,
                             validator=Validators.non_empty_string,
                             transformer=Transformers.strip_string,
                             description="LIKE模式匹配（支持%和_通配符）")

                .define_param("where_condition", ParamType.OPTIONAL,
                             validator=Validators.non_empty_string,
                             transformer=Transformers.strip_string,
                             description="WHERE条件（仅TABLES支持）")

                .define_param("limit", ParamType.OPTIONAL,
                             transformer=Transformers.to_int,
                             validator=Validators.positive_integer,
                             description="限制返回数量")

                # 特定对象类型参数
                .define_param("in_vcluster", ParamType.OPTIONAL,
                             validator=Validators.non_empty_string,
                             transformer=Transformers.strip_string,
                             description="在指定VCluster中查找（仅JOBS支持）")

                .define_param("to_user", ParamType.OPTIONAL,
                             validator=Validators.non_empty_string,
                             transformer=Transformers.strip_string,
                             description="查看特定用户的权限（仅GRANTS支持）")

                # TABLES特定过滤器
                .define_param("table_type_filters", ParamType.OPTIONAL,
                             validator=Validators.is_dict_or_none,
                             description="表类型过滤器：{is_view, is_materialized_view, is_external, is_dynamic}")

                # 智能默认值
                .define_param("smart_defaults", ParamType.OPTIONAL,
                             default_value=True,
                             transformer=Transformers.to_bool,
                             description="是否应用智能默认值（如JOBS自动加LIMIT 10，TABLES自动加LIMIT 50等）")

                # 响应优化控制
                .define_param("include_suggestions", ParamType.OPTIONAL,
                             default_value=False,
                             transformer=Transformers.to_bool,
                             description="是否包含过滤建议和提示信息")

                .define_param("include_field_analysis", ParamType.OPTIONAL,
                             default_value=False,
    # 上方已定义增强参数块
                             description="是否包含字段级别的详细分析")

                # FUNCTIONS特定参数
                .define_param("show_builtin_functions", ParamType.OPTIONAL,
                             default_value=False,
                             transformer=Transformers.to_bool,
                             description="是否显示内置函数详情（默认只显示外部函数）")

                .define_param("function_type", ParamType.OPTIONAL,
                             validator=Validators.in_choices(["ALL", "BUILTIN", "EXTERNAL", "UDF"]),
                             transformer=Transformers.to_upper,
                             description="函数类型过滤：ALL(所有)/BUILTIN(内置)/EXTERNAL(远程外部函数)/UDF(用户SQL函数)")

                # 响应优化参数
                .define_param("detailed_analysis", ParamType.OPTIONAL,
                             default_value=False,
                             transformer=Transformers.to_bool,
                             description="是否返回详细的数据分析（默认为简洁模式）"))

    @staticmethod
    def desc_object() -> ParameterHandler:
        """描述对象参数处理器"""
        return (ParameterHandler("desc_object")
                # 对象类型 - 必需 (DESC 语义：必须使用单数关键词)
                .define_param("object_type", ParamType.REQUIRED,
                             validator=Validators.in_choices([
                                 "WORKSPACE", "TABLE", "VCLUSTER", "VOLUME", "EXTERNAL VOLUME", "CONNECTION", "STORAGE CONNECTION", "API CONNECTION", "CATALOG CONNECTION",
                                 "SCHEMA", "EXTERNAL SCHEMA", "FUNCTION", "EXTERNAL FUNCTION", "VIEW", "MATERIALIZED VIEW",
                                 "DYNAMIC TABLE", "EXTERNAL TABLE", "PIPE", "INDEX", "BLOOMFILTER", "INVERTED", "VECTOR",
                                 "USER", "ROLE", "GRANT", "SHARE", "TABLE STREAM", "NETWORK POLICY", "SYNONYM"
                             ]),
                             transformer=Transformers.normalize_object_type_no_plural,
                             description="对象类型(单数，禁止自动复数)")

                # 对象名称 - 必需
                .define_param("object_name", ParamType.REQUIRED,
                             validator=Validators.non_empty_string,
                             transformer=Transformers.strip_string,
                             description="对象名称，可包含schema限定（如schema.table）")

                # 详细模式
                .define_param("extended", ParamType.OPTIONAL,
                             default_value=True,
                             transformer=Transformers.to_bool,
                             description="是否显示详细信息（EXTENDED模式）")

                # 特定对象类型的选项
                .define_param("show_history", ParamType.OPTIONAL,
                             default_value=False,
                             transformer=Transformers.to_bool,
                             description="是否显示历史信息（仅TABLE/DYNAMIC TABLE支持）")

                .define_param("show_indexes", ParamType.OPTIONAL,
                             default_value=False,
                             transformer=Transformers.to_bool,
                             description="是否显示索引信息（仅TABLE支持）")

                .define_param("show_grants", ParamType.OPTIONAL,
                             default_value=False,
                             transformer=Transformers.to_bool,
                             description="是否显示权限信息")

                # 修复Issue #3：添加show_sensitive参数用于控制敏感数据显示
                .define_param("show_sensitive", ParamType.OPTIONAL,
                             default_value=False,
                             transformer=Transformers.to_bool,
                             description="是否显示敏感数据（如CONNECTION的密码等）"))

    @staticmethod
    def import_data_src() -> ParameterHandler:
        """导入数据源处理器 - 增强版本，支持写入模式和响应控制"""
        handler = (ParameterHandler("import_data_src")
                .define_param("from_url", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="数据源URL，支持HTTP(S) URL或本地文件路径")
                .define_param("dest_table", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="目标表名称")
                .define_param("write_mode", ParamType.OPTIONAL,
                            default_value="overwrite",
                            validator=Validators.in_choices(["create", "overwrite", "append"]),
                            transformer=Transformers.to_lower,
                            description="写入模式：create(新建)/overwrite(覆盖)/append(追加)"))
        return ResponseControlMixin.add_response_control_params(handler)

    @staticmethod
    def import_data_from_db() -> ParameterHandler:
        """外部数据库导入数据处理器"""
        handler = (ParameterHandler("import_data_from_db")
                .define_param("db_type", ParamType.REQUIRED,
                             validator=Validators.in_choices([
                                 "mysql", "postgresql", "oracle", "sqlserver", "mssql",
                                 "clickhouse", "hive", "spark", "sqlite"
                             ]),
                             transformer=lambda x: _normalize_db_type(x) if x else x,
                             description="数据库类型 (支持: MySQL, PostgreSQL, Oracle, SQL Server, ClickHouse, Hive, Spark, SQLite)")
                .define_param("host", ParamType.OPTIONAL,
                             description="数据库主机地址（SQLite不需要）")
                .define_param("port", ParamType.OPTIONAL,
                             transformer=Transformers.to_int,
                             description="数据库端口（SQLite不需要）")
                .define_param("database", ParamType.REQUIRED,
                             validator=Validators.non_empty_string,
                             description="数据库名称或SQLite文件路径")
                .define_param("username", ParamType.OPTIONAL,
                             description="用户名（SQLite不需要）")
                .define_param("password", ParamType.OPTIONAL,
                             description="密码（SQLite不需要）")
                .define_param("source_table", ParamType.REQUIRED,
                             validator=Validators.non_empty_string,
                             description="源表名称")
                .define_param("dest_table", ParamType.REQUIRED,
                             validator=Validators.non_empty_string,
                             description="目标表名称")
                .define_param("write_mode", ParamType.OPTIONAL,
                             default_value="overwrite",
                             validator=Validators.in_choices(["create", "overwrite", "append"]),
                             transformer=Transformers.to_lower,
                             description="数据写入模式"))
        return ResponseControlMixin.add_response_control_params(handler)

    @staticmethod
    def preview_volume_data() -> ParameterHandler:
        """预览Volume数据参数处理器 - 与工具名匹配"""
        handler = (ParameterHandler("preview_volume_data")
                .define_param("source_volume", ParamType.REQUIRED,
                             validator=Validators.non_empty_string,
                             transformer=Transformers.strip_string)
                .define_param("format", ParamType.REQUIRED,
                             validator=Validators.in_choices(["csv", "parquet", "orc", "bson", "json"]),
                             transformer=Transformers.to_lower)
                .define_param("files", ParamType.REQUIRED,
                             validator=Validators.non_empty_string)
                .define_param("mode", ParamType.OPTIONAL, default_value="preview")
                .define_param("target_table", ParamType.OPTIONAL)
                .define_param("columns", ParamType.OPTIONAL,
                             default_value="*",  # 修复: 改为合理的默认值
                             transformer=Transformers.strip_string)
                .define_param("limit", ParamType.OPTIONAL,
                             default_value=3,
                             transformer=Transformers.to_int)
                .define_param("where", ParamType.OPTIONAL)
                .define_param("options", ParamType.OPTIONAL,
                             default_value={},
                             validator=Validators.is_dict_or_none))  # 修复: 使用正确的验证器
        return ResponseControlMixin.add_response_control_params(handler)

    @staticmethod
    def create_external_table() -> ParameterHandler:
        """创建外部表参数处理器 - 仅支持DELTA格式（官方文档限制）"""
        return (ParameterHandler("create_external_table")
                .define_param("table_name", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="外部表名称")
                .define_param("table_format", ParamType.OPTIONAL,
                            default_value="DELTA",
                            validator=Validators.in_choices(["DELTA", "HUDI"]),
                            transformer=Transformers.to_upper,
                            description="外部表格式类型，支持DELTA和HUDI（预览版）")
                .define_param("columns", ParamType.OPTIONAL,
                            transformer=Transformers.parse_table_columns,
                            description="列定义，支持字符串或数组格式")
                .define_param("connection", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="连接名称（STORAGE CONNECTION或KAFKA CONNECTION）")
                .define_param("location", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="数据文件路径（DELTA/HUDI必需，KAFKA不需要）")
                .define_param("kafka_options", ParamType.OPTIONAL,
                            validator=Validators.is_dict_or_none,
                            description="Kafka特定选项（仅KAFKA格式需要）")
                .define_param("if_not_exists", ParamType.OPTIONAL,
                            default_value=False,
                            transformer=Transformers.to_bool,
                            description="如果表已存在则跳过创建")
                .define_param("partitioned_by", ParamType.OPTIONAL,
                            description="分区列定义（可选）")
                .define_param("comment", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="表注释说明"))

    @staticmethod
    def create_api_connection() -> ParameterHandler:
        """创建API连接处理器 - 支持新旧两种架构"""
        return (ParameterHandler("create_api_connection")
                .define_param("connection_name", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="API CONNECTION名称")
                .define_param("architecture", ParamType.OPTIONAL,
                            default_value="CLOUD_FUNCTION",
                            validator=Validators.in_choices(["CLOUD_FUNCTION", "LEGACY_API"]),
                            transformer=Transformers.to_upper,
                            description="API连接架构类型")
                # 新架构参数（CLOUD_FUNCTION类型必需参数）
                .define_param("provider", ParamType.REQUIRED,
                            validator=Validators.in_choices(["aliyun", "tencent", "aws"]),
                            transformer=Transformers.to_lower,
                            description="云函数提供商（aliyun/tencent/aws）")
                .define_param("region", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="云服务区域（如 cn-hangzhou）")
                .define_param("role_arn", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="角色ARN授权信息")
                .define_param("namespace", ParamType.REQUIRED,
                            default_value="default",
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="命名空间（腾讯云必填，其他可填default）")
                .define_param("code_bucket", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="代码存储桶名称（必需）")
                # 旧架构参数
                .define_param("type", ParamType.OPTIONAL,
                            default_value="REST",
                            validator=Validators.in_choices(["REST", "HTTP", "OPENAPI"]),
                            transformer=Transformers.to_upper,
                            description="API类型")
                .define_param("endpoint", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="API端点地址")
                .define_param("api_key", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="API密钥")
                .define_param("secret_key", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="API密钥")
                .define_param("format", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="数据格式")
                .define_param("headers", ParamType.OPTIONAL,
                            description="HTTP头部信息")
                .define_param("comment", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="连接注释"))

    @staticmethod
    def create_storage_connection() -> ParameterHandler:
        """创建存储连接处理器 - 修复版本，明确OSS和S3/COS的参数差异"""
        return (ParameterHandler("create_storage_connection")
                .define_param("connection_name", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="存储连接名称")
                .define_param("connection_type", ParamType.REQUIRED,
                            validator=Validators.in_choices(["HDFS", "OSS", "COS", "S3", "KAFKA"]),
                            transformer=Transformers.to_upper,
                            description="存储连接类型")

                # OSS 特有参数 - 修复：OSS使用access_id + access_key
                .define_param("access_id", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="OSS访问ID（OSS必需）")
                .define_param("access_key", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="访问密钥（OSS和S3/COS都需要，但含义不同）")

                # S3/COS 特有参数 - S3/COS使用access_key + secret_key
                .define_param("secret_key", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="密钥（仅S3/COS使用）")

                # 通用对象存储参数
                .define_param("endpoint", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=lambda x: x.strip().replace('https://', '').replace('http://', '') if x else x,
                            description=(
                                "服务端点，自动移除https://前缀：\n"
                                "• OSS: oss-cn-hangzhou.aliyuncs.com\n"
                                "• S3: s3.cn-north-1.amazonaws.com.cn\n"
                                "• COS: cos.ap-guangzhou.myqcloud.com"
                            ))
                .define_param("region", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="服务区域")

                # 角色授权参数
                .define_param("role_arn", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description=(
                                "角色ARN（角色授权方式）：\n"
                                "• OSS: acs:ram::账号ID:role/角色名\n"
                                "• S3: arn:aws-cn:iam::账号ID:role/角色名\n"
                                "• COS: qcs::cam::uin/账号ID:roleName/角色名"
                            ))

                # COS特有参数
                .define_param("app_id", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="腾讯云APP_ID（COS可选）")

                # HDFS 参数
                .define_param("name_node", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="HDFS NameNode地址（HDFS必需），如 hdfs://namenode:9000")
                .define_param("name_node_rpc_addresses", ParamType.OPTIONAL,
                            description="HDFS NameNode RPC地址列表（HDFS可选），如 namenode1:8020,namenode2:8020")

                # KAFKA 参数
                .define_param("bootstrap_servers", ParamType.OPTIONAL,
                            description="Kafka服务器列表（KAFKA必需），如 localhost:9092 或 server1:9092,server2:9092")
                .define_param("security_protocol", ParamType.OPTIONAL,
                            validator=Validators.in_choices(["PLAINTEXT", "SSL", "SASL_PLAINTEXT", "SASL_SSL"]),
                            transformer=Transformers.to_upper,
                            default_value="PLAINTEXT",
                            description="Kafka安全协议")

                # 通用可选参数
                .define_param("use_ssl", ParamType.OPTIONAL,
                            transformer=Transformers.to_bool,
                            description="是否启用SSL（可选）")
                .define_param("path_style_access", ParamType.OPTIONAL,
                            transformer=Transformers.to_bool,
                            description="是否使用路径样式访问（S3可选）")
                .define_param("session_token", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="临时会话令牌（S3可选）"))
    @staticmethod
    def smart_crawl_to_volume() -> ParameterHandler:
        """智能抓取到Volume参数处理器

        注意：与 smart_crawl_url 参数保持对齐，便于共享内部高级抓取逻辑。
        """
        return (
            ParameterHandler("smart_crawl_to_volume")
            .define_param(
                "url", ParamType.REQUIRED,
                validator=Validators.non_empty_string,
                transformer=Transformers.strip_string,
                description="起始抓取URL"
            )
            .define_param(
                "volume", ParamType.REQUIRED,
                validator=Validators.non_empty_string,
                transformer=Transformers.strip_string,
                description="目标Volume根路径，如 VOLUME_A"
            )
            .define_param(
                "volume_dir", ParamType.OPTIONAL,
                default_value="/",
                transformer=Transformers.strip_string,
                description="写入的子目录，默认根目录 /"
            )
            .define_param(
                "max_depth", ParamType.OPTIONAL,
                default_value=3,
                transformer=Transformers.to_int,
                description="多页面递归抓取最大深度 (adaptive 已启用)"
            )
            .define_param(
                "max_concurrent", ParamType.OPTIONAL,
                default_value=10,
                transformer=Transformers.to_int,
                description="最大并发请求数 (adaptive 已启用，硬上限32)"
            )
            .define_param(
                "max_pages", ParamType.OPTIONAL,
                default_value=20,
                transformer=Transformers.to_int,
                description="最多抓取页面数量 (adaptive 已启用)"
            )
            .define_param(
                "crawler", ParamType.OPTIONAL,
                default_value="default_crawler",
                transformer=Transformers.strip_string,
                description="爬虫策略占位"
            )
            # === 新增与 smart_crawl_url 对齐的高级提取参数 ===
            .define_param(
                "css_selector", ParamType.OPTIONAL,
                validator=Validators.non_empty_string_or_none,
                transformer=Transformers.strip_string,
                description="限制提取范围的CSS选择器，可选"
            )
            .define_param(
                "word_count_threshold", ParamType.OPTIONAL,
                validator=Validators.positive_integer,
                transformer=Transformers.to_int_or_none,
                default_value="10",
                description="分块最小词数阈值"
            )
            .define_param(
                "extraction_strategy", ParamType.OPTIONAL,
                validator=Validators.non_empty_string_or_none,
                transformer=Transformers.strip_string,
                default_value="LLMExtractionStrategy",
                description="提取策略 (占位名)"
            )
            .define_param(
                "chunking_strategy", ParamType.OPTIONAL,
                validator=Validators.non_empty_string_or_none,
                transformer=Transformers.strip_string,
                default_value="RegexChunking",
                description="分块策略 (占位名)"
            )
            .define_param(
                "bypass_cache", ParamType.OPTIONAL,
                validator=Validators.is_boolean_or_none,
                transformer=Transformers.to_bool_or_none,
                default_value="false",
                description="是否忽略内部缓存"
            )
            .define_param(
                "include_raw_html", ParamType.OPTIONAL,
                validator=Validators.is_boolean_or_none,
                transformer=Transformers.to_bool_or_none,
                default_value="false",
                description="是否同时保存原始HTML (后续可扩展)"
            )
            .define_param(
                "include_patterns", ParamType.OPTIONAL,
                validator=Validators.is_list_or_none,
                transformer=Transformers.to_list,
                description="URL包含过滤：仅抓取包含任一子串的URL (逗号分隔或数组)"
            )
            .define_param(
                "exclude_patterns", ParamType.OPTIONAL,
                validator=Validators.is_list_or_none,
                transformer=Transformers.to_list,
                description="URL排除过滤：忽略包含任一子串的URL (逗号分隔或数组)"
            )
        )
    @staticmethod
    def smart_crawl_url() -> ParameterHandler:
        """智能URL抓取参数处理器（缺失补充）"""
        return (ParameterHandler("smart_crawl_url")
                .define_param("url", ParamType.REQUIRED,
                              validator=Validators.non_empty_string,
                              transformer=Transformers.strip_string,
                              description="要抓取的网页URL")
                .define_param("css_selector", ParamType.OPTIONAL,
                              validator=Validators.non_empty_string_or_none,
                              transformer=Transformers.strip_string,
                              description="CSS选择器，用于提取特定内容")
                .define_param("word_count_threshold", ParamType.OPTIONAL,
                              validator=Validators.positive_integer,
                              transformer=Transformers.to_int_or_none,
                              default_value="10",
                              description="内容块的最小词数阈值")
                .define_param("extraction_strategy", ParamType.OPTIONAL,
                              validator=Validators.non_empty_string_or_none,
                              transformer=Transformers.strip_string,
                              default_value="LLMExtractionStrategy",
                              description="提取策略名称（预留占位）")
                .define_param("chunking_strategy", ParamType.OPTIONAL,
                              validator=Validators.non_empty_string_or_none,
                              transformer=Transformers.strip_string,
                              default_value="RegexChunking",
                              description="分块策略名称（预留占位）")
                .define_param("bypass_cache", ParamType.OPTIONAL,
                              validator=Validators.is_boolean_or_none,
                              transformer=Transformers.to_bool_or_none,
                              default_value="false",
                              description="是否跳过缓存")
                .define_param("max_depth", ParamType.OPTIONAL,
                              transformer=Transformers.to_int_or_none,
                              default_value="1",
                              description="递归抓取最大深度 (adaptive)")
                .define_param("max_concurrent", ParamType.OPTIONAL,
                              transformer=Transformers.to_int_or_none,
                              default_value="5",
                              description="最大并发 (adaptive, 上限32)")
                .define_param("max_pages", ParamType.OPTIONAL,
                              transformer=Transformers.to_int_or_none,
                              default_value="20",
                              description="最多抓取页面数 (adaptive)")
                .define_param("include_raw_html", ParamType.OPTIONAL,
                              validator=Validators.is_boolean_or_none,
                              transformer=Transformers.to_bool_or_none,
                              default_value="false",
                              description="是否包含原始HTML")
                .define_param("include_patterns", ParamType.OPTIONAL,
                              validator=Validators.is_list_or_none,
                              transformer=Transformers.to_list,
                              description="URL包含过滤：仅抓取包含任一子串的URL")
                .define_param("exclude_patterns", ParamType.OPTIONAL,
                              validator=Validators.is_list_or_none,
                              transformer=Transformers.to_list,
                              description="URL排除过滤：忽略包含任一子串的URL"))
    @staticmethod
    def smart_crawl_url_direct() -> ParameterHandler:
        """向后兼容：smart_crawl_url_direct 别名，复用 smart_crawl_url 定义"""
        return HandlerFactory.smart_crawl_url()
    @staticmethod
    def create_catalog_connection() -> ParameterHandler:
        """创建目录连接参数处理器"""
        return (ParameterHandler("create_catalog_connection")
                .define_param("connection_name", ParamType.REQUIRED, validator=Validators.non_empty_string)
                .define_param("catalog_type", ParamType.REQUIRED, validator=Validators.in_choices(["HIVE", "OSS_CATALOG", "DATABRICKS"]), transformer=Transformers.to_upper)
                .define_param("endpoint", ParamType.REQUIRED, validator=Validators.non_empty_string)
                .define_param("access_key", ParamType.REQUIRED, validator=Validators.non_empty_string)
                .define_param("secret_key", ParamType.REQUIRED, validator=Validators.non_empty_string)
                .define_param("region", ParamType.OPTIONAL)
                .define_param("database", ParamType.OPTIONAL)
                .define_param("client_id", ParamType.OPTIONAL)
                .define_param("client_secret", ParamType.OPTIONAL)
                .define_param("host", ParamType.OPTIONAL)
                .define_param("metastore_uris", ParamType.OPTIONAL))

    @staticmethod
    def create_schema() -> ParameterHandler:
        """创建Schema参数处理器"""
        return (ParameterHandler("create_schema")
                .define_param("schema_name", ParamType.REQUIRED,
                             validator=Validators.non_empty_string)
                .define_param("if_not_exists", ParamType.OPTIONAL, default_value=False)
                .define_param("comment", ParamType.OPTIONAL, default_value=""))

    @staticmethod
    def switch_lakehouse_instance() -> ParameterHandler:
        """切换Lakehouse实例参数处理器 - 支持多云环境和服务实例切换"""
        return (ParameterHandler("switch_lakehouse_instance")
                .define_param("instance_name", ParamType.OPTIONAL,
                             validator=Validators.non_empty_string,
                             description="要切换到的实例名称（如：aliyun_prod, tencent_dev等）")
                .define_param("connection_name", ParamType.OPTIONAL,
                             validator=Validators.non_empty_string,
                             description="要切换到的连接名称")
                .define_param("set_as_default", ParamType.OPTIONAL,
                             default_value=False,
                             transformer=Transformers.to_bool,
                             description="是否将此连接设置为默认连接")
                .define_param("force", ParamType.OPTIONAL,
                             default_value=False,
                             transformer=Transformers.to_bool,
                             description="是否在检测到配置/实际连接漂移时强制重建底层物理连接")
                .define_param("list_instances", ParamType.OPTIONAL,
                             default_value=False,
                             transformer=Transformers.to_bool,
                             description="是否列出所有可用实例")
                .define_param("reload", ParamType.OPTIONAL,
                             default_value=False,
                             transformer=Transformers.to_bool,
                             description="是否重新加载配置文件"))

    @staticmethod
    def create_lakehouse_instance() -> ParameterHandler:
        """创建Lakehouse实例参数处理器 - 智能引导用户创建新实例"""
        return (ParameterHandler("create_lakehouse_instance")
                # 必需参数
                .define_param("instance_name", ParamType.OPTIONAL,
                            validator=lambda x: x is None or (isinstance(x, str) and len(x.strip()) > 0),
                            transformer=Transformers.strip_string,
                            description="实例名称（留空自动生成）")
                .define_param("instance_id", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="实例标识：可以是控制台URL（推荐）或实例ID")
                .define_param("username", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            description="用户名")
                .define_param("password", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            description="密码")
                # 可选参数（使用智能默认值）
                .define_param("workspace", ParamType.OPTIONAL,
                            default_value="quick_start",
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="工作空间")
                .define_param("schema", ParamType.OPTIONAL,
                            default_value="public",
                            validator=Validators.non_empty_string,
                            description="Schema")
                .define_param("vcluster", ParamType.OPTIONAL,
                            default_value="default_ap",
                            validator=Validators.non_empty_string,
                            description="虚拟集群")
                # 环境和用途参数
                .define_param("environment", ParamType.OPTIONAL,
                            validator=Validators.in_choices(["dev", "test", "uat", "prod"]),
                            transformer=Transformers.to_lower,
                            description="环境类型")
                .define_param("purpose", ParamType.OPTIONAL,
                            default_value="general",
                            validator=Validators.in_choices(["general", "etl", "analytics", "streaming"]),
                            transformer=Transformers.to_lower,
                            description="实例用途")
                # 行为控制参数
                .define_param("activate", ParamType.OPTIONAL,
                            default_value=False,
                            transformer=Transformers.to_bool,
                            description="是否立即激活")
                .define_param("set_as_default", ParamType.OPTIONAL,
                            default_value=False,
                            transformer=Transformers.to_bool,
                            description="设为默认实例")
                .define_param("validate_before_save", ParamType.OPTIONAL,
                            default_value=True,
                            transformer=Transformers.to_bool,
                            description="保存前验证实例")
                .define_param("description", ParamType.OPTIONAL,
                            transformer=Transformers.strip_string,
                            description="实例描述")
                # 手动指定平台和地域（当自动识别失败时）
                .define_param("platform", ParamType.OPTIONAL,
                            validator=Validators.in_choices(["yunqi", "singdata"]),
                            transformer=Transformers.to_lower,
                            description="平台类型")
                .define_param("region_key", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            description="地域键值"))

    @staticmethod
    def get_operation_guide() -> ParameterHandler:
        """获取操作指引参数处理器 - 修复缺失方法"""
        return (ParameterHandler("get_operation_guide")
                .define_param("to_do_something", ParamType.REQUIRED,
                             validator=Validators.non_empty_string,
                             description="要执行的操作"))

    @staticmethod
    def desc_object_history() -> ParameterHandler:
        """描述对象历史参数处理器"""
        return (ParameterHandler("desc_object_history")
                .define_param("object_name", ParamType.REQUIRED, validator=Validators.non_empty_string)
                .define_param("object_type", ParamType.REQUIRED, validator=Validators.non_empty_string)
                .define_param("limit", ParamType.OPTIONAL, default_value=10,
                             transformer=Transformers.to_int, validator=Validators.positive_integer))

    @staticmethod
    def undrop_object() -> ParameterHandler:
        """恢复被删除对象参数处理器"""
        return (ParameterHandler("undrop_object")
                .define_param("object_name", ParamType.REQUIRED, validator=Validators.non_empty_string)
                .define_param("object_type", ParamType.REQUIRED, validator=Validators.non_empty_string))

    @staticmethod
    def drop_object() -> ParameterHandler:
        """删除对象参数处理器 - 安全删除各种对象类型"""
        return (ParameterHandler("drop_object")
                .define_param("object_name", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="要删除的对象名称")
                .define_param("object_type", ParamType.REQUIRED,
                            validator=Validators.in_choices([
                                # 数据库对象
                                "SCHEMA", "EXTERNAL SCHEMA",
                                # 表相关对象
                                "TABLE", "VIEW", "DYNAMIC TABLE", "MATERIALIZED VIEW",
                                "EXTERNAL TABLE", "TABLE STREAM",
                                # 索引对象
                                "INDEX", "BLOOMFILTER", "INVERTED", "VECTOR",
                                # 连接对象
                                "CONNECTION", "STORAGE CONNECTION", "API CONNECTION",
                                "CATALOG CONNECTION",
                                # 存储对象
                                "VOLUME", "EXTERNAL VOLUME",
                                # 计算集群对象
                                "VCLUSTER",
                                # 安全对象
                                "USER", "ROLE", "SHARE", "NETWORK POLICY",
                                # 流处理对象
                                "PIPE",
                                # 函数对象
                                "FUNCTION", "EXTERNAL FUNCTION",
                                # 同义词对象
                                "SYNONYM"
                            ]),
                            transformer=lambda x: x.strip().upper() if x else x,
                            description="对象类型（如TABLE、VIEW等）")
                .define_param("if_exists", ParamType.OPTIONAL,
                            default_value=True,
                            transformer=Transformers.to_bool,
                            description="是否使用IF EXISTS（默认True）")
                .define_param("cascade", ParamType.OPTIONAL,
                            default_value=False,
                            transformer=Transformers.to_bool,
                            description="是否级联删除依赖对象（仅部分对象支持）")
                .define_param("restrict", ParamType.OPTIONAL,
                            default_value=False,
                            transformer=Transformers.to_bool,
                            description="是否限制删除（有依赖时失败，仅部分对象支持）")
                .define_param("force", ParamType.OPTIONAL,
                            default_value=False,
                            transformer=Transformers.to_bool,
                            description="是否强制删除（跳过某些检查）")
                .define_param("confirm_delete", ParamType.OPTIONAL,
                            default_value=False,
                            transformer=Transformers.to_bool,
                            description="确认删除操作（必须设为True才执行删除）"))

    @staticmethod
    def restore_object() -> ParameterHandler:
        """恢复对象到历史时间点参数处理器 - 增强时间戳格式指导"""
        return (ParameterHandler("restore_object")
                .define_param("object_name", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="要恢复的对象名称")
                .define_param("object_type", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.to_upper,
                            description="对象类型（如TABLE、VIEW等）")
                .define_param("timestamp", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="""恢复到的时间点，必需参数
                                        🕒 时间戳格式支持：
                                        • ✅ 推荐格式：
                                        - CAST('2025-08-15 14:54:42' AS TIMESTAMP)
                                        - CURRENT_TIMESTAMP() - INTERVAL '1' HOUR
                                        - CURRENT_TIMESTAMP() - INTERVAL '12' HOURS  
                                        - '2025-08-15 14:54:42.123' (完整时间戳)
                                        • ❌ 不支持格式：
                                        - '2025-08-15' (简单日期)
                                        - '2025-08-15 14:54:42' (简单字符串)
                                        • 💡 建议先用 desc_object_history 查看可用快照"""))

    @staticmethod
    def create_external_function() -> ParameterHandler:
        """创建外部函数参数处理器"""
        handler = ParameterHandler("create_external_function")

        # 必需参数
        handler.define_param("function_name", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="外部函数名称")
        handler.define_param("class_name", ParamType.REQUIRED,
                            validator=Validators.handler_format_validator,
                            transformer=Transformers.validate_and_fix_handler_format,
                            description="🎯 函数Handler，支持module.class格式，会自动修正格式")
        handler.define_param("resource_uris", ParamType.REQUIRED,
                            validator=Validators.resource_uris_list,
                            transformer=Transformers.parse_resource_uris,
                            description="""资源文件列表（仅支持 .zip 压缩包）。支持JSON字符串或数组格式。
                                示例:
                                JSON字符串: '[{"type": "ARCHIVE", "uri": "volume://my_volume/my_func.zip"}]'
                                数组格式: [{"type": "ARCHIVE", "uri": "volume://my_volume/my_func.zip"}]"""
                            )
        handler.define_param("connection_name", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="🔗 API连接名称，推荐使用'ai_function_connection'，必须是已创建的API_CONNECTION")

        # 可选参数
        handler.define_param("schema_name", ParamType.OPTIONAL,
                            default_value=None,  # 修复：不应该默认为public，应该使用当前schema
                            validator=Validators.non_empty_string_or_none,
                            transformer=Transformers.strip_string,
                            description="Schema名称（不指定时使用当前schema）")
        handler.define_param("if_not_exists", ParamType.OPTIONAL,
                            default_value=False,
                            transformer=Transformers.to_bool,
                            description="如果函数已存在是否跳过创建")
        handler.define_param("language", ParamType.OPTIONAL,
                            default_value="python",
                            validator=Validators.in_choices_case_insensitive(["python", "java"]),
                            transformer=Transformers.to_lower,
                            description="编程语言类型：python或java")
        handler.define_param("comment", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string_or_none,
                            transformer=Transformers.strip_string,
                            description="函数注释说明")

        # 增强控制参数
        handler.define_param("validate_code", ParamType.OPTIONAL,
                    default_value=True,
                    transformer=Transformers.to_bool,
                    description="是否执行代码/归档文件基础校验（结构/入口类/命名）")
        # 已收敛为仅ZIP，以下参数废弃占位（保持兼容避免调用端报错）
        handler.define_param("enforce_zip", ParamType.OPTIONAL,
                default_value=True,
                transformer=Transformers.to_bool,
                description="[已废弃] 始终强制ZIP；参数保留兼容，无实际作用")
        handler.define_param("auto_package", ParamType.OPTIONAL,
                default_value=False,
                transformer=Transformers.to_bool,
                description="[已废弃] 不再支持自动打包单.py；请手动提供 .zip")
        handler.define_param("auto_test", ParamType.OPTIONAL,
                default_value=False,
                transformer=Transformers.to_bool,
                description="创建后是否自动执行一次测试调用（需提供 test_sql 或系统生成默认SQL）")
        handler.define_param("test_sql", ParamType.OPTIONAL,
                validator=Validators.non_empty_string_or_none,
                transformer=Transformers.strip_string,
                description="用于auto_test的测试SQL（未提供则生成示例：SELECT function_name('test')）")
        handler.define_param("suggest_volume", ParamType.OPTIONAL,
                default_value=True,
                transformer=Transformers.to_bool,
                description="当检测到资源文件位于非推荐卷/路径时给出优化建议")
        handler.define_param("include_precheck", ParamType.OPTIONAL,
                default_value=True,
                transformer=Transformers.to_bool,
                description="是否在响应中包含预检查(precheck)诊断信息")
        handler.define_param("include_usage_examples", ParamType.OPTIONAL,
                default_value=True,
                transformer=Transformers.to_bool,
                description="是否在响应中包含使用示例/测试示例")
        handler.define_param("include_sql", ParamType.OPTIONAL,
                default_value=True,
                transformer=Transformers.to_bool,
                description="是否返回生成的CREATE EXTERNAL FUNCTION SQL语句")
        handler.define_param("zip_structure", ParamType.OPTIONAL,
                validator=Validators.non_empty_string_or_none,
                transformer=Transformers.strip_string,
                description="可选：声明ZIP内主模块文件名(不含.py)，用于创建前一致性校验；例如 'my_func'。若提供将与class_name模块段比对")
        handler.define_param("include_structure_scan", ParamType.OPTIONAL,
                default_value=True,
                transformer=Transformers.to_bool,
                description="是否对ZIP做轻量结构扫描并返回结果；volume远端无法读取文件内容时仅做命名推断")
        handler.define_param("strict_naming", ParamType.OPTIONAL,
            default_value=True,
            transformer=Transformers.to_bool,
            description="是否对 zip_structure 与 class_name 模块名不一致进行硬阻断；默认 True 直接阻断")
        handler.define_param("auto_correct_handler_path", ParamType.OPTIONAL,
            default_value=True,
            transformer=Transformers.to_bool,
            description="当检测到唯一可推断模块+类且用户传入不匹配时自动校正 handler 路径 并记录 actions")

        return handler

    @staticmethod
    def create_table() -> ParameterHandler:
        """创建表参数处理器 - 支持完整的ClickZetta CREATE TABLE语法"""
        return (ParameterHandler("create_table")
                # 基本参数
                .define_param("table_name", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="表名称")
                .define_param("if_not_exists", ParamType.OPTIONAL,
                            default_value=False,
                            transformer=Transformers.to_bool,
                            description="是否使用IF NOT EXISTS")
                .define_param("creation_method", ParamType.OPTIONAL,
                            default_value="standard",
                            validator=Validators.in_choices(["standard", "like", "ctas", "raw_sql"]),
                            transformer=Transformers.to_lower,
                            description="表创建方式")

                # 列定义参数 - 支持字符串或字典列表
                .define_param("columns", ParamType.OPTIONAL,
                            validator=lambda x: x is None or isinstance(x, (str, list)),
                            description="列定义（字符串格式或字典数组格式）")

                # 索引定义参数
                .define_param("indexes", ParamType.OPTIONAL,
                            validator=Validators.is_list_or_none,
                            description="索引定义数组")

                # 分区配置参数
                .define_param("partition", ParamType.OPTIONAL,
                            validator=Validators.is_dict_or_none,
                            description="分区配置")

                # 分桶配置参数
                .define_param("clustering", ParamType.OPTIONAL,
                            validator=Validators.is_dict_or_none,
                            description="分桶配置")

                # 表级排序参数
                .define_param("table_sorted_by", ParamType.OPTIONAL,
                            validator=Validators.is_list_or_none,
                            description="表级排序配置")

                # 表属性参数
                .define_param("properties", ParamType.OPTIONAL,
                            validator=Validators.is_dict_or_none,
                            description="表属性配置")

                # LIKE语法参数
                .define_param("source_table", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="LIKE语法的源表名")

                # CTAS语法参数
                .define_param("select_statement", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="CREATE TABLE AS SELECT的查询语句")

                # 原始SQL参数（向后兼容）
                .define_param("raw_sql", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="完整的CREATE TABLE SQL语句")

                # 表注释
                .define_param("comment", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="表注释")

                # 响应控制参数
                .define_param("verbose", ParamType.OPTIONAL,
                            default_value=None,
                            transformer=Transformers.to_bool,
                            description="是否返回详细信息（包括SQL等）")

                .define_param("include_sql", ParamType.OPTIONAL,
                            default_value=None,
                            transformer=Transformers.to_bool,
                            description="是否返回生成的CREATE TABLE SQL"))

    @staticmethod
    def create_dynamic_table() -> ParameterHandler:
        """创建动态表参数处理器 - 支持query别名"""
        handler = ParameterHandler("create_dynamic_table")

        handler.define_param("table_name", ParamType.REQUIRED,
                           validator=Validators.non_empty_string,
                           transformer=Transformers.strip_string,
                           description="动态表名称")
        handler.define_param("select_sql", ParamType.REQUIRED,
                           validator=Validators.non_empty_string,
                           transformer=Transformers.strip_string,
                           description="SELECT查询语句")
        handler.define_param("replace", ParamType.OPTIONAL,
                           default_value=False,
                           transformer=Transformers.to_bool,
                           description="是否替换已存在的表")
        handler.define_param("if_not_exists", ParamType.OPTIONAL,
                           default_value=False,
                           transformer=Transformers.to_bool,
                           description="如果表已存在则跳过创建")
        handler.define_param("partition_by", ParamType.OPTIONAL,
                           validator=Validators.non_empty_string_or_none,
                           transformer=Transformers.strip_string,
                           description="分区列")
        handler.define_param("refresh_interval", ParamType.OPTIONAL,
                           validator=Validators.non_empty_string_or_none,
                           transformer=Transformers.strip_string,
                           description="刷新间隔")
        handler.define_param("comment", ParamType.OPTIONAL,
                           validator=Validators.non_empty_string_or_none,
                           transformer=Transformers.strip_string,
                           description="表注释")
        handler.define_param("refresh_option", ParamType.OPTIONAL,
                           validator=Validators.non_empty_string_or_none,
                           transformer=Transformers.strip_string,
                           description="刷新选项")

        # 添加自定义处理逻辑支持query别名
        original_process = handler.process_arguments

        def process_arguments_with_query_alias(arguments):
            # 如果有query参数但没有select_sql，使用query作为select_sql
            if "query" in arguments and "select_sql" not in arguments:
                arguments = arguments.copy()  # 避免修改原始参数
                arguments["select_sql"] = arguments["query"]
            return original_process(arguments)

        handler.process_arguments = process_arguments_with_query_alias
        return handler

    @staticmethod
    def refresh_dynamic_table() -> ParameterHandler:
        """刷新动态表参数处理器"""
        return (ParameterHandler("refresh_dynamic_table")
                .define_param("table_name", ParamType.REQUIRED, validator=Validators.non_empty_string))

    @staticmethod
    def alter_dynamic_table() -> ParameterHandler:
        """修改动态表参数处理器 - 修复操作类型枚举"""
        return (ParameterHandler("alter_dynamic_table")
                .define_param("table_name", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="动态表名称")
                .define_param("operation", ParamType.REQUIRED,
                            validator=Validators.in_choices([
                                "suspend", "resume", "set_comment", "rename_column", "set_column_comment",
                                "add_column", "drop_column", "alter_column", "set_refresh_interval", "set_select"
                            ]),
                            transformer=Transformers.to_lower,
                            description="操作类型")
                # 列操作参数
                .define_param("column_name", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="列名")
                .define_param("new_column_name", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="新列名")
                .define_param("comment", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="注释内容"))

    @staticmethod
    def modify_dynamic_table_data() -> ParameterHandler:
        """动态表数据变更参数处理器 - 增强数据类型兼容性指导"""
        return (ParameterHandler("modify_dynamic_table_data")
                .define_param("sql", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            description="""要执行的SQL语句，支持INSERT/UPDATE/DELETE/MERGE操作
                            
⚠️  数据类型兼容性要点：
• 使用显式类型转换避免类型不匹配错误
• 常见示例：
  ✅ CAST(1 AS BIGINT) 替代直接使用 1
  ✅ DATE('2025-09-01') 替代 '2025-09-01'
  ✅ TIMESTAMP('2025-09-01 10:30:00') 替代字符串
• 建议先用 desc_object 查看表结构确认字段类型""")
                .define_param("table_name", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            description="目标表名（可选），如不提供将从SQL中自动提取")
                .define_param("auto_cast", ParamType.OPTIONAL,
                            validator=Validators.is_bool_or_none,
                            default_value=True,
                            description="是否自动将明显的日期/时间字面量包装为 DATE()/TIMESTAMP()，默认开启"))

    @staticmethod
    def create_pipe() -> ParameterHandler:
        """创建PIPE参数处理器 - 完全基于ClickZetta产品文档 + 智能优化"""
        return (ParameterHandler("create_pipe")
                .define_param("pipe_name", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="PIPE名称")
                # 智能模式：支持自动生成COPY语句
                .define_param("target_table", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string_or_none,
                            transformer=Transformers.strip_string,
                            description="目标表名（智能模式：用于自动生成COPY语句）")
                .define_param("source_volume", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string_or_none,
                            transformer=Transformers.strip_string,
                            description="源VOLUME名称（智能模式：用于自动生成COPY语句）")
                .define_param("file_format", ParamType.OPTIONAL,
                            default_value="CSV",
                            validator=Validators.in_choices(["CSV", "JSON", "PARQUET", "ORC", "AVRO"]),
                            transformer=Transformers.to_upper,
                            description="文件格式（智能模式）")
                .define_param("source_path", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string_or_none,
                            transformer=Transformers.strip_string,
                            description="源文件路径或目录（智能模式）")
                # 诊断与回退相关参数
                .define_param("debug", ParamType.OPTIONAL,
                            validator=Validators.is_bool_or_none,
                            transformer=Transformers.to_bool,
                            description="调试模式：输出 debug_trace 诊断信息")
                .define_param("step_by_step", ParamType.OPTIONAL,
                            validator=Validators.is_bool_or_none,
                            transformer=Transformers.to_bool,
                            default_value=False,
                            description="分步骤模式：先执行预检查(卷/表/格式)再创建PIPE，失败则中断并给出修复建议")
                .define_param("smart_fallback", ParamType.OPTIONAL,
                            default_value="abort",
                            validator=Validators.in_choices(["abort", "skeleton"]),
                            transformer=Transformers.to_lower,
                            description="智能生成失败时的回退策略：abort(默认) 或 skeleton")
                .define_param("schema_name", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string_or_none,
                            transformer=Transformers.strip_string,
                            description="显式指定schema，用于 target_table 自动补全")
                # 必需参数（可以智能推断）
                .define_param("virtual_cluster", ParamType.OPTIONAL,
                            default_value="default",
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="虚拟集群名称")
                .define_param("ingest_mode", ParamType.OPTIONAL,
                            default_value="LIST_PURGE",
                            validator=Validators.in_choices(["LIST_PURGE", "EVENT_NOTIFICATION"]),
                            transformer=Transformers.to_upper,
                            description="摄取模式（默认LIST_PURGE）")
                # 手动模式：直接提供COPY语句
                .define_param("copy_statement", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string_or_none,
                            transformer=Transformers.strip_string,
                            description="完整COPY INTO语句（手动模式）")
                .define_param("if_not_exists", ParamType.OPTIONAL,
                            default_value=False,
                            transformer=Transformers.to_bool,
                            description="如果PIPE已存在则跳过创建")
                # 对象存储专用参数
                .define_param("copy_job_hint", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string_or_none,
                            transformer=Transformers.strip_string,
                            description="COPY作业提示（对象存储模式）")
                .define_param("auto_purge", ParamType.OPTIONAL,
                            validator=Validators.is_bool_or_none,
                            transformer=Transformers.to_bool,
                            description="自动清理源文件（智能推断：LIST_PURGE模式默认true）")
                # Kafka专用参数
                .define_param("batch_interval_in_seconds", ParamType.OPTIONAL,
                            validator=Validators.positive_integer,
                            transformer=Transformers.to_int,
                            description="批处理间隔时间（秒）- Kafka模式")
                .define_param("batch_size_per_kafka_partition", ParamType.OPTIONAL,
                            validator=Validators.positive_integer,
                            transformer=Transformers.to_int,
                            description="每个Kafka分区的批处理大小 - Kafka模式")
                .define_param("max_skip_batch_count_on_error", ParamType.OPTIONAL,
                            validator=Validators.positive_integer,
                            transformer=Transformers.to_int,
                            description="错误时最大跳过批次数 - Kafka模式")
                .define_param("reset_kafka_group_offsets", ParamType.OPTIONAL,
                            validator=Validators.in_choices(["latest", "earliest", "none", "valid"]),
                            transformer=Transformers.to_lower,
                            description="Kafka初始点位设置 - Kafka模式")
                .define_param("initial_delay_in_seconds", ParamType.OPTIONAL,
                            validator=Validators.non_negative_integer,
                            transformer=Transformers.to_int,
                            description="首个作业调度延迟（秒）")
                .define_param("current_schema", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string_or_none,
                            transformer=Transformers.strip_string,
                            description="当前Schema名称"))

    @staticmethod
    def create_table_stream() -> ParameterHandler:
        """创建表流处理器 - 强化TABLE_STREAM_MODE验证"""
        return (ParameterHandler("create_table_stream")
                .define_param("stream_name", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="表流名称")
                .define_param("table_name", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="源表名称")
                .define_param("table_stream_mode", ParamType.OPTIONAL,
                            default_value="STANDARD",
                            validator=Validators.in_choices(["APPEND_ONLY", "STANDARD"]),
                            transformer=Transformers.to_upper,
                            description="表流模式")
                .define_param("with_options", ParamType.OPTIONAL,
                            default_value={},
                            description="WITH子句其他选项")
                .define_param("start_from", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="捕获起点")
                .define_param("comment", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="表流注释"))

    @staticmethod
    def list_files_on_volume() -> ParameterHandler:
        """列举Volume文件参数处理器 - 增强版，支持响应控制"""
        handler = (ParameterHandler("list_files_on_volume")
                .define_param("target_volume", ParamType.REQUIRED, validator=Validators.non_empty_string)
                .define_param("regexp", ParamType.OPTIONAL)
                .define_param("target_subdirectory", ParamType.OPTIONAL)
                .define_param("target_schema", ParamType.OPTIONAL,
                             validator=Validators.non_empty_string_or_none,
                             transformer=Transformers.strip_string,
                             description="目标Schema名称（跨Schema访问时使用）"))
        return ResponseControlMixin.add_response_control_params(handler)

    @staticmethod
    def put_file_to_volume() -> ParameterHandler:
        """上传文件到VOLUME处理器 - 增强版本，支持content参数和Python外部函数"""
        handler = (ParameterHandler("put_file_to_volume")
                .define_param("source_path", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="源文件路径或URL")
                .define_param("content", ParamType.OPTIONAL,
                            description="直接上传的内容（支持空字符串创建空文件）")
                .define_param("target_volume", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="目标VOLUME")
                .define_param("target_filename", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="目标文件名（使用content参数时必需）")
                .define_param("target_subdirectory", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="目标子目录")
                .define_param("validate_format", ParamType.OPTIONAL,
                            default_value=False,
                            transformer=Transformers.to_bool,
                            description="是否验证文件格式")
                .define_param("overwrite", ParamType.OPTIONAL,
                            default_value=True,
                            transformer=Transformers.to_bool,
                            description="是否覆盖已存在文件")
                .define_param("python_version", ParamType.OPTIONAL,
                            default_value="python3.10",
                            validator=lambda v: v in ["python3.10", "python3.9", "python3.8", "python3.11"],
                            description="Python版本（用于依赖打包建议）")
                .define_param("options", ParamType.OPTIONAL,
                            default_value={},
                            description="PUT命令选项")
                .define_param("target_schema", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="目标Schema名称（跨Schema访问时使用）")
                .define_param("current_schema", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="当前Schema名称"))
        return ResponseControlMixin.add_response_control_params(handler)

    @staticmethod
    def get_file_from_volume() -> ParameterHandler:
        """从Volume获取文件参数处理器 - 支持默认下载目录"""
        handler = (ParameterHandler("get_file_from_volume")
                .define_param("source_file", ParamType.REQUIRED, validator=Validators.non_empty_string)
                .define_param("source_volume", ParamType.REQUIRED, validator=Validators.non_empty_string)
                .define_param("target_local_path", ParamType.OPTIONAL,
                             validator=Validators.non_empty_string_or_none,
                             description="目标本地路径（可选，未指定时使用默认下载目录）")
                .define_param("source_schema", ParamType.OPTIONAL,
                             validator=Validators.non_empty_string_or_none,
                             transformer=Transformers.strip_string,
                             description="源Volume所在的Schema名称（跨Schema访问时使用）")
                .define_param("overwrite", ParamType.OPTIONAL, default_value=False, transformer=Transformers.to_bool,
                               description="是否覆盖已存在文件 (目录模式下针对单个目标文件)")
                .define_param("target_is_directory", ParamType.OPTIONAL, default_value=None,
                               description="显式指定 target_local_path 作为目录 (True/False)，为空则自动推断")
                .define_param("options", ParamType.OPTIONAL, default_value={}, description="GET命令选项"))
        return ResponseControlMixin.add_response_control_params(handler)

    @staticmethod
    def remove_file_from_volume() -> ParameterHandler:
        """从Volume删除文件或目录参数处理器"""
        return (ParameterHandler("remove_file_from_volume")
                .define_param("target_volume", ParamType.REQUIRED,
                             validator=Validators.non_empty_string,
                             transformer=Transformers.strip_string,
                             description="目标Volume")
                .define_param("target_file", ParamType.OPTIONAL,
                             validator=Validators.non_empty_string,
                             transformer=Transformers.strip_string,
                             description="要删除的文件名（与target_subdirectory二选一）")
                .define_param("target_subdirectory", ParamType.OPTIONAL,
                             validator=Validators.non_empty_string,
                             transformer=Transformers.strip_string,
                             description="要删除的子目录名（与target_file二选一）")
                .define_param("target_schema", ParamType.OPTIONAL,
                             validator=Validators.non_empty_string,
                             transformer=Transformers.strip_string,
                             description="目标Schema（用于跨Schema访问）"))

    @staticmethod
    def create_volume() -> ParameterHandler:
        """创建Volume参数处理器 - 修复volume_type参数不一致问题"""
        handler = (ParameterHandler("create_volume")
                .define_param("volume_name", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="VOLUME名称")
                .define_param("volume_type", ParamType.OPTIONAL,
                            default_value="external",
                            validator=Validators.in_choices(["oss", "cos", "s3", "external", "internal"]),
                            transformer=Transformers.to_lower,
                            description="Volume类型：external/internal，或对象存储类型oss/cos/s3")
                .define_param("bucket", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="对象存储桶名称（外部Volume必需）")
                .define_param("path", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="桶内路径（外部Volume必需）")
                .define_param("connection", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="STORAGE CONNECTION名称（外部Volume必需）")
                .define_param("directory_options", ParamType.OPTIONAL,
                            default_value={},
                            validator=Validators.is_dict_or_none,
                            description="DIRECTORY选项")
                .define_param("recursive", ParamType.OPTIONAL,
                            default_value=True,
                            transformer=Transformers.to_bool,
                            description="是否递归")
                .define_param("validate_after_creation", ParamType.OPTIONAL,
                            default_value=True,
                            transformer=Transformers.to_bool,
                            description="创建后是否验证VOLUME可用性"))

        # 重写process_arguments来处理存储类型的自动推导
        original_process = handler.process_arguments

        def process_arguments_with_storage_type_inference(arguments):
            # 先进行标准处理
            params = original_process(arguments)

            # 推导存储类型和Volume类型
            volume_type = params.get("volume_type", "external")
            if volume_type in ["oss", "cos", "s3"]:
                # 如果用户传递的是存储类型，保存原始值并转换volume_type
                params["storage_type"] = volume_type
                params["volume_type"] = "external"
            elif volume_type == "external":
                # 如果是external但没有storage_type，尝试从其他参数推导
                params["storage_type"] = params.get("storage_type", "oss")  # 默认OSS

            return params

        handler.process_arguments = process_arguments_with_storage_type_inference
        return handler

    @staticmethod
    def create_knowledge_base() -> ParameterHandler:
        """创建知识库参数处理器"""
        return (ParameterHandler("create_knowledge_base")
                .define_param("knowledge_name", ParamType.REQUIRED, validator=Validators.non_empty_string)
                .define_param("documents_source_type", ParamType.REQUIRED, validator=Validators.non_empty_string)
                .define_param("documents_source_path", ParamType.REQUIRED, validator=Validators.non_empty_string)
                .define_param("volume_name", ParamType.OPTIONAL)
                .define_param("processing_options", ParamType.OPTIONAL, default_value={}))

    @staticmethod
    def create_external_volume() -> ParameterHandler:
        """创建外部Volume参数处理器"""
        return (ParameterHandler("create_external_volume")
                .define_param("volume_name", ParamType.REQUIRED, validator=Validators.non_empty_string)
                .define_param("bucket", ParamType.REQUIRED, validator=Validators.non_empty_string)
                .define_param("connection", ParamType.REQUIRED, validator=Validators.non_empty_string)
                .define_param("path", ParamType.REQUIRED, validator=Validators.non_empty_string)
                .define_param("volume_type", ParamType.REQUIRED, validator=Validators.non_empty_string)
                .define_param("recursive", ParamType.OPTIONAL, default_value=True))


    @staticmethod
    def modify_dynamic_table() -> ParameterHandler:
        """修复动态表数据修改参数处理器"""
        return (ParameterHandler("modify_dynamic_table")
                .define_param("table_name", ParamType.REQUIRED, validator=Validators.non_empty_string)
                .define_param("operation", ParamType.REQUIRED, validator=Validators.in_choices(["INSERT", "UPDATE", "DELETE", "MERGE"]))
                .define_param("sql", ParamType.REQUIRED, validator=Validators.non_empty_string))

    @staticmethod
    def package_external_function() -> ParameterHandler:
        """打包外部函数参数处理器"""
        return (ParameterHandler("package_external_function")
                .define_param("source_file", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            description="Python源文件路径")
                .define_param("source_content", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            description="Python源代码内容（与source_file二选一）")
                .define_param("module_name", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            description="当使用source_content时强制指定主模块文件名(不含.py)；若未提供则尝试从output_path推断")
                .define_param("dependencies", ParamType.OPTIONAL,
                            default_value=[],
                            validator=Validators.is_list_or_none,
                            description="依赖包列表，如['requests', 'numpy==1.21.0']")
                .define_param("output_path", ParamType.OPTIONAL,
                            default_value="function.zip",
                            validator=Validators.non_empty_string,
                            description="输出ZIP文件路径")
                .define_param("packaging_mode", ParamType.OPTIONAL,
                            default_value="development",
                            validator=lambda v: v in ["production", "development", "docker"] if v else True,
                            description="打包模式：production/development/docker")
                .define_param("use_docker", ParamType.OPTIONAL,
                            default_value=False,
                            transformer=Transformers.to_bool,
                            description="是否使用Docker确保兼容性（已弃用，请使用packaging_mode='docker'）")
                .define_param("force_python_version", ParamType.OPTIONAL,
                            validator=lambda v: v in ["3.8", "3.9", "3.10", "3.11"] if v else True,
                            description="强制使用特定Python版本")
                .define_param("auto_annotate", ParamType.OPTIONAL,
                            default_value=True,
                            transformer=Transformers.to_bool,
                            description="若缺少@annotate('*->string')自动注入")
                .define_param("structure_scan", ParamType.OPTIONAL,
                            default_value=True,
                            transformer=Transformers.to_bool,
                            description="是否返回轻量结构扫描结果(class/evaluate/__call__/annotate/建议)")
                .define_param("force_json_return", ParamType.OPTIONAL,
                            default_value=False,
                            transformer=Transformers.to_bool,
                            description="为evaluate添加返回json.dumps的提示注释")
               )

    @staticmethod
    def build_knowledge_base() -> ParameterHandler:
        """构建知识库参数处理器"""
        return (ParameterHandler("build_knowledge_base")
                .define_param("knowledge_name", ParamType.REQUIRED, validator=Validators.non_empty_string)
                .define_param("documents_source_type", ParamType.REQUIRED, validator=Validators.non_empty_string)
                .define_param("documents_source_path", ParamType.REQUIRED, validator=Validators.non_empty_string)
                .define_param("if_exists", ParamType.REQUIRED, validator=Validators.non_empty_string)
                .define_param("documents_original_source", ParamType.OPTIONAL)
                .define_param("volume_name", ParamType.OPTIONAL)
                .define_param("volume_regexp", ParamType.OPTIONAL))

    @staticmethod
    def alter_pipe() -> ParameterHandler:
        """ALTER PIPE 参数处理器 - 修复操作类型枚举"""
        return (ParameterHandler("alter_pipe")
                .define_param("pipe_name", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="PIPE名称")
                .define_param("operation", ParamType.REQUIRED,
                            validator=Validators.in_choices([
                                "suspend", "resume", "set_virtual_cluster", "set_batch_interval",
                                "set_batch_size", "set_max_skip_batch_count", "set_copy_job_hint"
                            ]),
                            transformer=Transformers.to_lower,
                            description="操作类型")
                .define_param("virtual_cluster", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="虚拟集群名称")
                .define_param("batch_interval_in_seconds", ParamType.OPTIONAL,
                            validator=Validators.positive_integer,
                            transformer=Transformers.to_int,
                            description="批处理间隔时间（秒）")
                .define_param("batch_size_per_kafka_partition", ParamType.OPTIONAL,
                            validator=Validators.positive_integer,
                            transformer=Transformers.to_int,
                            description="每个Kafka分区的批处理大小")
                .define_param("max_skip_batch_count_on_error", ParamType.OPTIONAL,
                            validator=Validators.positive_integer,
                            transformer=Transformers.to_int,
                            description="错误时跳过的批次最大重试次数")
                .define_param("copy_job_hint", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="COPY作业提示参数")
                .define_param("paused", ParamType.OPTIONAL,
                            transformer=Transformers.to_bool,
                            description="是否暂停PIPE执行")
                .define_param("error_handling", ParamType.OPTIONAL,
                            validator=Validators.in_choices(["CONTINUE", "ABORT_STATEMENT", "SKIP_FILE"]),
                            transformer=Transformers.to_upper,
                            description="错误处理策略"))

    @staticmethod
    def create_index() -> ParameterHandler:
        """创建索引参数处理器 - 支持VECTOR/INVERTED/BLOOMFILTER三种索引类型"""
        return (ParameterHandler("create_index")
                # 基本模式参数
                .define_param("index_type", ParamType.OPTIONAL,
                            validator=Validators.in_choices(["VECTOR", "INVERTED", "BLOOMFILTER"]),
                            transformer=Transformers.to_upper,
                            description="索引类型")
                .define_param("index_name", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="索引名称")
                .define_param("table_name", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="表名称（可包含schema）")
                .define_param("column_name", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="列名称")

                # 批量模式参数
                .define_param("indexes", ParamType.OPTIONAL,
                            validator=Validators.is_list_or_none,
                            description="批量创建索引数组")

                # 智能推荐模式参数
                .define_param("auto_recommend", ParamType.OPTIONAL,
                            default_value=False,
                            transformer=Transformers.to_bool,
                            description="是否自动推荐索引")
                .define_param("query_patterns", ParamType.OPTIONAL,
                            validator=Validators.is_list_or_none,
                            description="查询模式列表，用于智能推荐")

                # 通用选项
                .define_param("if_not_exists", ParamType.OPTIONAL,
                            default_value=False,
                            transformer=Transformers.to_bool,
                            description="仅在索引不存在时创建")
                .define_param("build_immediately", ParamType.OPTIONAL,
                            default_value=False,
                            transformer=Transformers.to_bool,
                            description="创建后立即构建索引（仅VECTOR/INVERTED）")
                .define_param("comment", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="索引注释")

                # VECTOR索引特有参数
                .define_param("distance_function", ParamType.OPTIONAL,
                            default_value="COSINE",
                            validator=Validators.in_choices(["COSINE", "L2", "JACCARD", "HAMMING"]),
                            transformer=Transformers.to_upper,
                            description="向量距离函数")
                .define_param("dimension", ParamType.OPTIONAL,
                            transformer=Transformers.to_int,
                            validator=Validators.positive_integer,
                            description="向量维度")
                .define_param("index_type_param", ParamType.OPTIONAL,
                            default_value="HNSW",
                            validator=Validators.in_choices(["HNSW", "IVF", "FLAT"]),
                            transformer=Transformers.to_upper,
                            description="VECTOR索引类型参数")
                .define_param("scalar_type", ParamType.OPTIONAL,
                            default_value="f32",
                            validator=Validators.in_choices(["f32", "f16", "i8", "b1"]),
                            transformer=Transformers.to_lower,
                            description="向量标量类型")
                .define_param("ef_construction", ParamType.OPTIONAL,
                            default_value=200,
                            transformer=Transformers.to_int,
                            validator=Validators.positive_integer,
                            description="VECTOR索引构建参数")
                .define_param("M", ParamType.OPTIONAL,
                            default_value=16,
                            transformer=Transformers.to_int,
                            validator=Validators.positive_integer,
                            description="VECTOR索引M参数")

                # INVERTED索引特有参数
                .define_param("analyzer", ParamType.OPTIONAL,
                            default_value="chinese",
                            validator=Validators.in_choices(["chinese", "english", "keyword", "unicode"]),
                            transformer=Transformers.to_lower,
                            description="文本分析器（INVERTED索引必需）")

                # 高级属性
                .define_param("properties", ParamType.OPTIONAL,
                            validator=Validators.is_dict_or_none,
                            description="其他索引属性"))

    @staticmethod
    def show_job_history() -> ParameterHandler:
        """show_job_history 参数处理器，系统作业历史查询"""
        return (ParameterHandler("show_job_history")
                .define_param("limit", ParamType.OPTIONAL, validator=Validators.positive_integer, transformer=Transformers.to_int, default_value=10)
                .define_param("virtual_cluster", ParamType.OPTIONAL, validator=Validators.non_empty_string)
                .define_param("start_time", ParamType.OPTIONAL, validator=Validators.non_empty_string)
                .define_param("end_time", ParamType.OPTIONAL, validator=Validators.non_empty_string)
                .define_param("status", ParamType.OPTIONAL, validator=Validators.non_empty_string))

    @staticmethod
    def show_table_load_history() -> ParameterHandler:
        """show_table_load_history 参数处理器，table_name 必填"""
        return (ParameterHandler("show_table_load_history")
                .define_param("table_name", ParamType.REQUIRED, validator=Validators.non_empty_string))

    @staticmethod
    def audit_table_schema_history() -> ParameterHandler:
        """表/Schema历史审计参数处理器"""
        return (ParameterHandler("audit_table_schema_history")
                .define_param(
                    "target_type",
                    ParamType.REQUIRED,
                    transformer=Transformers.to_upper,
                    validator=Validators.in_choices(["TABLE", "SCHEMA", "DYNAMIC_TABLE"]),
                    description="审计范围：TABLE 或 SCHEMA"
                )
                .define_param(
                    "table_name",
                    ParamType.OPTIONAL,
                    validator=Validators.non_empty_string,
                    description="要审计的对象名称（包含schema，如 analytics.orders）。当 target_type为TABLE或DYNAMIC_TABLE 时必填"
                )
                .define_param(
                    "schema_name",
                    ParamType.OPTIONAL,
                    validator=Validators.non_empty_string,
                    description="要审计的schema名称。当 target_type=SCHEMA 时必填"
                )
                .define_param(
                    "like_pattern",
                    ParamType.OPTIONAL,
                    validator=Validators.non_empty_string,
                    description="可选的LIKE模式，用于Schema审计时过滤表名（例如 'sales_%'）"
                )
                .define_param(
                    "limit",
                    ParamType.OPTIONAL,
                    default_value=20,
                    transformer=Transformers.to_int,
                    validator=Validators.positive_integer,
                    description="返回的历史记录数量上限（默认20）"
                )
                .define_param(
                    "audit_type",
                    ParamType.OPTIONAL,
                    default_value="table_overview",
                    transformer=Transformers.to_lower,
                    validator=Validators.in_choices([
                        "table_overview",
                        "table_lifecycle",
                        "table_changes",
                        "table_loads",
                        "dynamic_refresh",
                        "deleted_objects",
                        "schema_overview"
                    ]),
                    description="审计模式：table_overview（默认）/table_lifecycle/table_changes/table_loads/dynamic_refresh/schema_overview/deleted_objects"
                ))

    @staticmethod
    def get_current_context() -> ParameterHandler:
        """get_current_context 参数处理器，无需参数"""
        return ParameterHandler("get_current_context")

    @staticmethod
    def analyze_function_package() -> ParameterHandler:
        """分析函数包的参数处理器"""
        return (ParameterHandler("analyze_function_package")
                .define_param("resource_uri", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="函数包的URI，如volume://path/to/package.zip")
                .define_param("language", ParamType.OPTIONAL,
                            default_value="auto",
                            validator=Validators.in_choices(["python", "java", "auto"]),
                            transformer=Transformers.to_lower,
                            description="编程语言类型，auto表示自动检测"))

    @staticmethod
    def manage_share() -> ParameterHandler:
        """管理SHARE对象的参数处理器"""
        return (ParameterHandler("manage_share")
                .define_param("operation", ParamType.REQUIRED,
                            validator=Validators.in_choices([
                                # OUTBOUND操作（基于产品文档）
                                "create", "drop", "add_instance", "remove_instance",
                                "grant_table", "grant_view", "grant_schema_tables", "grant_schema_views",
                                "revoke_table", "revoke_view",
                                # 通用操作
                                "describe", "list"
                            ]),
                            transformer=Transformers.strip_string,
                            description="操作类型")
                .define_param("share_name", ParamType.OPTIONAL,  # 根据操作类型决定是否必需
                            validator=Validators.non_empty_string_or_none,
                            transformer=Transformers.strip_string,
                            description="SHARE名称")
                # 对象相关参数
                .define_param("table_name", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string_or_none,
                            transformer=Transformers.strip_string,
                            description="表名")
                .define_param("view_name", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string_or_none,
                            transformer=Transformers.strip_string,
                            description="视图名")
                .define_param("schema_name", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string_or_none,
                            transformer=Transformers.strip_string,
                            description="Schema名")
                # 实例相关参数
                .define_param("instance_name", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string_or_none,
                            transformer=Transformers.strip_string,
                            description="目标实例名")
                .define_param("provider_instance", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string_or_none,
                            transformer=Transformers.strip_string,
                            description="提供者实例名")
                # 筛选参数
                .define_param("filter_kind", ParamType.OPTIONAL,
                            validator=lambda v: v is None or v.upper() in ["INBOUND", "OUTBOUND"],
                            transformer=lambda v: v.upper() if v else None,
                            description="SHARE类型筛选")
                .define_param("limit", ParamType.OPTIONAL,
                            validator=lambda v: v is None or (isinstance(v, int) and v > 0),
                            transformer=Transformers.to_int_or_none,
                            description="限制返回数量")
                # INBOUND操作参数
                .define_param("new_schema_name", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string_or_none,
                            transformer=Transformers.strip_string,
                            description="本地Schema名称")
                .define_param("source_schema", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string_or_none,
                            transformer=Transformers.strip_string,
                            description="要从SHARE中提取的源schema名称"))

    @staticmethod
    def crawl_single_page_direct() -> ParameterHandler:
        """单页面网页抓取工具参数处理器"""
        return (ParameterHandler("crawl_single_page_direct")
                .define_param("url", ParamType.REQUIRED,
                            validator=Validators.non_empty_string,
                            transformer=Transformers.strip_string,
                            description="要抓取的网页URL")
                .define_param("css_selector", ParamType.OPTIONAL,
                            validator=Validators.non_empty_string_or_none,
                            transformer=Transformers.strip_string,
                            description="CSS选择器，用于提取特定内容")
                .define_param("word_count_threshold", ParamType.OPTIONAL,
                            validator=Validators.positive_integer,
                            transformer=Transformers.to_int_or_none,
                            default_value="10",
                            description="内容块的最小词数阈值")
                .define_param("bypass_cache", ParamType.OPTIONAL,
                            validator=Validators.is_boolean_or_none,
                            transformer=Transformers.to_bool_or_none,
                            default_value="false",
                            description="是否跳过缓存")
                .define_param("include_raw_html", ParamType.OPTIONAL,
                            validator=Validators.is_boolean_or_none,
                            transformer=Transformers.to_bool_or_none,
                            default_value="false",
                            description="是否包含原始HTML"))

    @staticmethod
    def get_external_function_guide():
        """获取Python外部函数开发指南参数处理器"""
        return ParameterHandler("get_external_function_guide") \
            .define_param("topic", ParamType.OPTIONAL,
                        default_value="overview",
                        validator=lambda v: v in [
                            "knowledge_hub", "overview", "python_spec", "packaging",
                            "debugging", "best_practices", "common_errors", "null_handling"
                        ],
                        description="指南主题") \
            .define_param("format", ParamType.OPTIONAL,
                        default_value="markdown",
                        validator=lambda v: v in ["markdown", "structured"],
                        description="返回格式")

    @staticmethod
    def get_external_function_template():
        """获取Python外部函数模板参数处理器"""
        return ParameterHandler("get_external_function_template") \
            .define_param("example_type", ParamType.OPTIONAL,
                        default_value="basic",
                        validator=lambda v: v in [
                            "basic", "with_dependencies", "api_integration",
                            "data_processing", "ml_inference"
                        ],
                        description="示例类型") \
            .define_param("python_version", ParamType.OPTIONAL,
                        default_value="python3.10",
                        validator=lambda v: v in [
                            "python3.10", "python3.9", "python3.8", "python3.11"
                        ],
                        description="Python版本") \
            .define_param("include_tests", ParamType.OPTIONAL,
                        default_value=True,
                        transformer=Transformers.to_bool,
                        description="是否包含测试用例")

    # 外部函数开发工具参数处理器
    @staticmethod
    def generate_external_function_template():
        """生成外部函数模板参数处理器"""
        return ParameterHandler("generate_external_function_template") \
            .define_param("function_name", ParamType.REQUIRED,
                        validator=Validators.non_empty_string,
                        transformer=Transformers.strip_string,
                        description="函数名称") \
            .define_param("template_type", ParamType.OPTIONAL,
                        default_value="simple_function",
                        validator=lambda v: v in ["ai_text_processing", "data_processing", "simple_function"],
                        description="模板类型") \
            .define_param("system_prompt", ParamType.OPTIONAL,
                        validator=Validators.non_empty_string,
                        description="AI系统提示词（仅ai_text_processing类型使用）") \
            .define_param("output_dir", ParamType.OPTIONAL,
                        default_value=".",
                        validator=Validators.non_empty_string,
                        description="输出目录") \
            .define_param("custom_parameters", ParamType.OPTIONAL,
                        default_value={},
                        description="自定义参数")

    @staticmethod
    def package_external_function():
        """打包外部函数参数处理器"""
        return ParameterHandler("package_external_function") \
            .define_param("source_file", ParamType.REQUIRED,
                        validator=Validators.non_empty_string,
                        transformer=Transformers.strip_string,
                        description="源文件路径") \
            .define_param("output_name", ParamType.OPTIONAL,
                        validator=Validators.non_empty_string,
                        description="输出ZIP文件名") \
            .define_param("include_dependencies", ParamType.OPTIONAL,
                        default_value=True,
                        transformer=Transformers.to_bool,
                        description="是否包含依赖包") \
            .define_param("requirements_file", ParamType.OPTIONAL,
                        default_value="requirements.txt",
                        validator=Validators.non_empty_string,
                        description="依赖文件名") \
            .define_param("optimization_level", ParamType.OPTIONAL,
                        default_value="production",
                        validator=lambda v: v in ["dev", "test", "production"],
                        description="优化级别") \
            .define_param("output_dir", ParamType.OPTIONAL,
                        default_value=".",
                        validator=Validators.non_empty_string,
                        description="输出目录")

    @staticmethod
    def test_external_function_locally():
        """本地测试外部函数参数处理器"""
        return ParameterHandler("test_external_function_locally") \
            .define_param("python_file", ParamType.REQUIRED,
                        validator=Validators.non_empty_string,
                        transformer=Transformers.strip_string,
                        description="Python文件路径") \
            .define_param("function_name", ParamType.OPTIONAL,
                        validator=Validators.non_empty_string,
                        description="函数名称（自动推断）") \
            .define_param("test_cases", ParamType.OPTIONAL,
                        default_value=[],
                        description="测试用例列表")


# 使用示例：重构后的handler
async def handle_vector_search_refactored(arguments, db, *_):
    """重构后的向量搜索handler - 展示如何使用参数处理器"""
    # 参数处理 - 一行代码搞定所有参数处理
    params = HandlerFactory.vector_search().process_arguments(arguments)

    # 现在可以直接使用处理过的参数，无需再做验证和转换
    question = params["question"]
    table_name = params["table_name"]
    embedding_column_name = params["embedding_column_name"]
    content_column_name = params["content_column_name"]
    partition_scope = params["partition_scope"]
    other_columns = params["other_columns"]
    vector_search_limit_n = params["vector_search_limit_n"]

    # 原有的业务逻辑保持不变...
    # 这里省略具体的向量搜索实现

    return {"success": True, "params": params}


# 装饰器版本（更简洁的使用方式）
def with_parameter_handler(handler_factory_method):
    """参数处理装饰器"""
    def decorator(func):
        async def wrapper(arguments, *args, **kwargs):
            handler = handler_factory_method()
            params = handler.process_arguments(arguments)
            return await func(params, *args, **kwargs)
        return wrapper
    return decorator


# 装饰器使用示例
@with_parameter_handler(HandlerFactory.vector_search)
async def handle_vector_search_decorated(params, db, *_):
    """使用装饰器的向量搜索handler"""
    question = params["question"]
    table_name = params["table_name"]

    # 直接使用处理好的参数，无需任何验证逻辑
    # 业务逻辑...

    return {"success": True, "question": question}
