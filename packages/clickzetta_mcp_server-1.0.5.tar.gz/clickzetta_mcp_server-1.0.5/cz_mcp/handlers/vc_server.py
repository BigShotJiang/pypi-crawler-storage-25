import datetime
import json

from cz_mcp.utils.config_utils import read_url, read_api, read_env_configuration
from cz_mcp.utils.request_utils import RequestUtils
from loguru import logger

def vc_list(workspace_id, jwt_token, instance_name, user_id, instance_id, account_id, env, name = None, workspace_name=None):

    url = read_url(env=env) + read_api("VC_LIST")


    # url_get_current = read_url(env=env) + read_api("USER_GET_CURRENT")
    #
    # data = get_user_id(url_get_current, jwt_token,instance_name,env)
    #
    # user_id = data.get("id")
    # account_id=data.get("accountId")
    # instance_id = data.get("instanceId")

    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": str(jwt_token),
        "userId": str(user_id),
        "instanceId": str(instance_id),
        "accountId": str(account_id),
        "instanceName": str(instance_name),
        "tenantId": str(account_id)
    }
    if workspace_name:
        headers["workspaceName"] = workspace_name

    json_data = {
        "instanceId": instance_id,
        "workspaceId": str(workspace_id),
    }
    if name:
        json_data["name"] = name
    logger.info(f"Fetching vCluster list for instance_id={instance_id}, workspace_id={workspace_id}")

    response = RequestUtils().post(url=url, headers=headers, json=json_data)
    return response



def vc_create(workspace_id, jwt_token, instance_name, user_id, instance_id, account_id, env,
              vc_name, vc_type,minSize, maxSize,apMaxConcurrency,apSize):

    url = read_url(env=env) + read_api("VC_CREATE")


    # url_get_current = read_url(env=env) + read_api("USER_GET_CURRENT")
    #
    # data = get_user_id(url_get_current, jwt_token,instance_name,env)
    #
    # user_id = data.get("id")
    # account_id=data.get("accountId")
    # instance_id = data.get("instanceId")

    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": str(jwt_token),
        "userId": str(user_id),
        "instanceId": str(instance_id),
        "accountId": str(account_id),
        "instanceName": str(instance_name),
        "tenantId": str(account_id)
    }

    json_data = {
        "instanceId": instance_id,
        "workspaceId": str(workspace_id),
        "name":vc_name,
        "type": vc_type.upper(),
        "autoStartEnabled": True,
        "autoStopSeconds": 60,
        "provisionMode": "SERVERLESS"
    }
    if vc_type == "INTEGRATION" or vc_type == "GENERAL":
        json_data["minSize"] = minSize
        json_data["maxSize"] = maxSize
    else:
        json_data["minReplicas"] = minSize
        json_data["maxReplicas"] = maxSize
        json_data["maxConcurrency"] = apMaxConcurrency
        json_data["size"] = apSize

    logger.info(f"Create Vc for instance_id={instance_id}, workspace_id={workspace_id}, name = {vc_name}")

    response = RequestUtils().post(url=url, headers=headers, json=json_data)
    return response
