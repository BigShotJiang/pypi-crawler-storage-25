"""
Job Performance Analysis Handler
"""
import json
import os
import tempfile
from typing import Dict, List, Set

from loguru import logger

from cz_skills.job_performance_analyzer import analyze_job

# Expert 模式：Finding 类型到 reference 文件的映射
FINDING_REFERENCE_MAP: Dict[str, List[str]] = {
    'DATA_SKEW': ['stage-operator-optimization.md'],
    'STAGE_SPILLING': ['stage-operator-optimization.md'],
    'OPERATOR_SPILLING': ['stage-operator-optimization.md'],
    'RESOURCE_INEFFICIENCY': ['stage-operator-optimization.md'],
    'SINGLE_DOP_AGG': ['stage-operator-optimization.md'],
    'MISSING_BF_COLLECTION': ['stage-operator-optimization.md'],
    'BROADCAST_JOIN': ['stage-operator-optimization.md'],
    'TABLESINK_DOP': ['stage-operator-optimization.md'],
    'MAX_DOP_USER_SET': ['stage-operator-optimization.md'],
    'BOTTLENECK_ANALYSIS': ['stage-operator-optimization.md'],
    'FULL_REFRESH': ['incremental-optimization.md'],
    'NON_INCREMENTAL_REFRESH': ['state-table-optimization.md', 'incremental-optimization.md'],
    'HEAVY_CALC': ['state-table-optimization.md'],
    'POTENTIAL_OPTIMIZATION': ['state-table-optimization.md'],
    'SNAPSHOT_SUBPLAN_CANDIDATE': ['state-table-optimization.md'],
    'INCREMENTAL_STATE_TABLE_CANDIDATE': ['state-table-optimization.md'],
    'AGG_NOT_REUSING': ['state-table-optimization.md'],
    'MISSING_APPEND_ONLY_PROPERTY': ['state-table-optimization.md'],
}


def _load_reference_files(finding_types: Set[str]) -> str:
    """根据 findings 类型按需加载对应的 reference 文件内容
    
    Args:
        finding_types: 规则引擎产出的 finding 类型集合
        
    Returns:
        拼接后的 reference 文档内容
    """
    # 收集需要加载的 reference 文件（去重）
    needed_files: Set[str] = set()
    for finding_type in finding_types:
        refs = FINDING_REFERENCE_MAP.get(finding_type, [])
        needed_files.update(refs)
    
    # expert 模式下始终加载优化原则文档
    needed_files.add('optimization-principles.md')
    
    if not needed_files:
        return ""
    
    # 定位 references 目录
    references_dir = os.path.join(
        os.path.dirname(__file__), '..', 'skills', 'job-performance-analyzer', 'references'
    )
    references_dir = os.path.normpath(references_dir)
    
    contents = []
    total_size = 0
    for filename in sorted(needed_files):
        filepath = os.path.join(references_dir, filename)
        if os.path.exists(filepath):
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
                total_size += len(content)
                contents.append(f"## Reference: {filename}\n\n{content}")
                logger.info(f"[expert mode] Loaded reference: {filename} ({len(content)} chars)")
            except Exception as e:
                logger.warning(f"[expert mode] Failed to load reference {filename}: {e}")
        else:
            logger.warning(f"[expert mode] Reference file not found: {filepath}")
    
    logger.info(f"[expert mode] Loaded {len(contents)} reference files, total {total_size} chars")
    return "\n\n---\n\n".join(contents)


def _estimate_expert_mode_tokens(json_report: dict, reference_content: str) -> int:
    """估算 expert 模式的 token 消耗
    
    粗略估算：1 token ≈ 4 chars (中英文混合场景偏保守)
    """
    report_size = len(json.dumps(json_report, ensure_ascii=False))
    reference_size = len(reference_content)
    prompt_size = 2000  # AI prompt 模板约 2KB
    
    input_tokens = (report_size + reference_size + prompt_size) // 4
    output_tokens = 3000  # 预估 AI 输出
    return input_tokens + output_tokens


def analyze_job_performance(job_plan_data: dict, job_profile_data: dict, enable_incremental_algorithm_analysis: bool,
                            enable_state_table_analysis: bool, analysis_mode: str = 'quick') -> dict:
    """
    Analyze job performance using job plan and profile data
    
    Args:
        job_plan_data: Job plan JSON data
        job_profile_data: Job profile JSON data
        enable_incremental_algorithm_analysis: Enable incremental algorithm analysis
        enable_state_table_analysis: Enable state table analysis
        analysis_mode: Analysis mode ('quick', 'detailed', 'expert')
        
    Returns:
        Analysis result dictionary containing:
            - output: All captured output (print and log messages)
            - json_report: JSON format analysis report with structured data
    """
    try:
        with tempfile.TemporaryDirectory() as temp_dir:
            # Save job plan only if data exists
            job_plan_file = None
            if job_plan_data is not None:
                job_plan_file = os.path.join(temp_dir, "job_plan.json")
                with open(job_plan_file, 'w', encoding='utf-8') as f:
                    json.dump(job_plan_data, f, ensure_ascii=False, indent=2)
            
            # Save job profile
            job_profile_file = os.path.join(temp_dir, "job_profile.json")
            with open(job_profile_file, 'w', encoding='utf-8') as f:
                json.dump(job_profile_data, f, ensure_ascii=False, indent=2)
            
            # Call analyze_job function with output capture enabled
            logger.info(f"Running job performance analysis with output capture")

            result = analyze_job(
                plan_file=job_plan_file,
                profile_file=job_profile_file,
                output_dir=temp_dir,
                enable_state_table_analysis=enable_state_table_analysis,
                enable_incremental_algorithm_analysis=enable_incremental_algorithm_analysis,
                capture_output=True,
                analysis_mode=analysis_mode
            )
            
            # Expert 模式：按需加载 reference 文档，附加 token 估算和确认标记
            if analysis_mode == 'expert' and isinstance(result, dict):
                finding_types: Set[str] = set()
                structured_report = result.get('structured_json_report', {})
                
                if not structured_report:
                    # fallback: 从文件读取
                    analysis_json_path = os.path.join(temp_dir, "analysis_results.json")
                    if os.path.exists(analysis_json_path):
                        with open(analysis_json_path, 'r', encoding='utf-8') as f:
                            structured_report = json.load(f)
                        result['structured_json_report'] = structured_report
                
                if structured_report:
                    for finding in structured_report.get('findings', []):
                        finding_types.add(finding.get('type', ''))
                    
                    # 加载对应的 reference 文档
                    reference_content = _load_reference_files(finding_types)
                    
                    if reference_content:
                        result['reference_context'] = reference_content
                    
                    # Token 估算
                    result['token_estimate'] = _estimate_expert_mode_tokens(
                        structured_report, reference_content or ''
                    )
                    result['requires_confirmation'] = True
            
            return result
                
    except Exception as e:
        logger.error(f"Job performance analysis failed: {e}")
        raise
