"""
Studio Datasource Server API functions
"""

from cz_mcp.handlers.login_server import get_user_id
from cz_mcp.utils.config_utils import read_url, read_api
from cz_mcp.utils.request_utils import RequestUtils

def datasource_list(project_id, ds_name, ds_type, jwt_token, instance_name, user_id, instance_id, account_id, env, page_index=1, page_size=20, workspace_name=None):

    url = read_url(env=env) + read_api("DATA_SOURCES_LIST")


    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": str(jwt_token),
        "userId": str(user_id),
        "instanceId": str(instance_id),
        "accountId": str(account_id),
        "instanceName": str(instance_name),
        "tenantId": str(account_id)
    }
    if workspace_name:
        headers["workspaceName"] = workspace_name

    json_data = {
        "current": page_index,
        "pageSize": page_size,
        "status": 1,
        "pageIndex": page_index,
        # "projectId": project_id,
        "dsName": ds_name,
        "dsType": ds_type
    }


    response = RequestUtils().post(url=url, headers=headers, json=json_data).text
    return response


def get_namespace_list(datasource_id, jwt_token, instance_name, instance_id, user_id, account_id, env, workspace_name=None):
    """获取数据源的命名空间列表"""
    url = read_url(env=env) + read_api("DATA_SOURCES_LIST_NAMESPACES")
    # url_get_current = read_url(env=env) + read_api("USER_GET_CURRENT")
    #
    # data = get_user_id(url_get_current, jwt_token, instance_name, env)
    #
    # user_id = data.get("id")
    # account_id = data.get("accountId")
    # instance_id = data.get("instanceId")
    
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": str(jwt_token),
        "userId": str(user_id),
        "instanceId": str(instance_id),
        "accountId": str(account_id),
        "instanceName": str(instance_name),
        "tenantId": str(account_id)
    }
    if workspace_name:
        headers["workspaceName"] = workspace_name
    
    json_data = {
        "id": datasource_id
    }
    
    response = RequestUtils().post(url=url, headers=headers, json=json_data).text
    return response


def get_meta_list(datasource_id, namespace, jwt_token, instance_name, instance_id, user_id,account_id, env, workspace_name=None):
    """获取指定命名空间下的数据对象列表"""
    url = read_url(env=env) + read_api("DATA_SOURCES_LIST_DATA_OBJECTS")
    # url_get_current = read_url(env=env) + read_api("USER_GET_CURRENT")
    #
    # data = get_user_id(url_get_current, jwt_token, instance_name, env)
    #
    # user_id = data.get("id")
    # account_id = data.get("accountId")
    # instance_id = data.get("instanceId")
    
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": str(jwt_token),
        "userId": str(user_id),
        "instanceId": str(instance_id),
        "accountId": str(account_id),
        "instanceName": str(instance_name),
        "tenantId": str(account_id)
    }
    if workspace_name:
        headers["workspaceName"] = workspace_name
    
    json_data = {
        "id": datasource_id,
        "nameSpace": namespace
    }
    
    response = RequestUtils().post(url=url, headers=headers, json=json_data).text
    return response


def get_meta_detail(datasource_id, namespace, data_object_name, jwt_token, instance_name, instance_id, user_id, account_id, env, workspace_name=None):
    """获取指定数据对象的元数据详情"""
    url = read_url(env=env) + read_api("DATA_SOURCES_GET_DATA_OBJECT_META")
    # url_get_current = read_url(env=env) + read_api("USER_GET_CURRENT")
    #
    # data = get_user_id(url_get_current, jwt_token, instance_name, env)
    #
    # user_id = data.get("id")
    # account_id = data.get("accountId")
    # instance_id = data.get("instanceId")
    
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": str(jwt_token),
        "userId": str(user_id),
        "instanceId": str(instance_id),
        "accountId": str(account_id),
        "instanceName": str(instance_name),
        "tenantId": str(account_id)
    }
    if workspace_name:
        headers["workspaceName"] = workspace_name
    
    json_data = {
        "id": datasource_id,
        "nameSpace": namespace,
        "dataObjectName": data_object_name
    }
    
    response = RequestUtils().post(url=url, headers=headers, json=json_data).text
    return response
