class Transformers:
    """参数转换器类"""

    @staticmethod
    def to_int(value):
        """转换为整数"""
        if value is None:
            return None
        if isinstance(value, int):
            return value
        if isinstance(value, str):
            return int(value)
        if isinstance(value, float):
            return int(value)
        raise ValueError(f"Cannot convert {value} to int")

    @staticmethod
    def to_float(value):
        """转换为浮点数"""
        if value is None:
            return None
        if isinstance(value, (int, float)):
            return float(value)
        if isinstance(value, str):
            return float(value)
        raise ValueError(f"Cannot convert {value} to float")

    @staticmethod
    def to_bool(value):
        """转换为布尔值"""
        if value is None:
            return None
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return value.lower() in ('true', '1', 'yes', 'on')
        if isinstance(value, (int, float)):
            return bool(value)
        raise ValueError(f"Cannot convert {value} to bool")

    @staticmethod
    def to_bool_or_none(value):
        """转换为布尔值或None"""
        if value is None:
            return None
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            if value.lower() in ('true', '1', 'yes', 'on'):
                return True
            elif value.lower() in ('false', '0', 'no', 'off'):
                return False
            else:
                return None
        if isinstance(value, (int, float)):
            return bool(value)
        return None

    @staticmethod
    def to_upper(value):
        """转换为大写字符串"""
        if value is None:
            return None
        return str(value).upper()

    @staticmethod
    def to_lower(value):
        """转换为小写字符串"""
        if value is None:
            return None
        return str(value).lower()

    @staticmethod
    def to_string(value):
        """转换为字符串"""
        if value is None:
            return None
        return str(value)

    @staticmethod
    def strip_string(value):
        """去除字符串首尾空白"""
        if value is None:
            return None
        return str(value).strip()

    @staticmethod
    def to_int_or_none(value):
        """转换为整数或保持None"""
        if value is None:
            return None
        return Transformers.to_int(value)

    @staticmethod
    def validate_and_fix_handler_format(value):
        """
        🚀 智能Handler格式验证和修正
        ClickZetta要求使用 module.class 格式
        """
        if value is None:
            return None

        value = str(value).strip()
        if not value:
            return value

        # 如果没有点，说明只给了类名，需要推断module.class格式
        if '.' not in value:
            suggested_format = f"{value}.{value}"
            # 这里使用logger会在后续Handler中输出警告
            return suggested_format

        # 验证格式正确性
        parts = value.split('.')
        if len(parts) >= 2 and all(part.strip() for part in parts):
            return value

        # 格式不正确，抛出错误
        raise ValueError(
            f"Handler格式错误: '{value}'\n"
            f"正确格式应为: 'module.class'，如 'my_function.MyFunction'\n"
            f"如果只有类名，请使用: '{value}.{value}'"
        )

    @staticmethod
    def normalize_object_type(value):
        """
        标准化对象类型名称，支持多种命名风格

        支持的格式：
        - 下划线分隔：EXTERNAL_FUNCTIONS -> EXTERNAL FUNCTIONS
        - 空格分隔：EXTERNAL FUNCTIONS（保持不变）
        - 驼峰命名：ExternalFunctions -> EXTERNAL FUNCTIONS
        - 小写：external_functions, external functions -> EXTERNAL FUNCTIONS

        Args:
            value: 输入的对象类型名称

        Returns:
            标准化后的对象类型名称（空格分隔的大写格式）
        """
        if value is None:
            return None

        # 转换为字符串并去除首尾空白
        value = str(value).strip()

        if not value:
            return value

        # 处理驼峰命名：在大写字母前插入空格
        import re
        # 在连续的大写字母前不插入空格（如API, VIEWS等）
        # 但在大写字母后跟小写字母的情况下插入空格
        camel_spaced = re.sub(r'(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])', ' ', value)

        # 将下划线替换为空格
        normalized = camel_spaced.replace('_', ' ')

        # 转换为大写
        normalized = normalized.upper()

        # 规范化多个空格为单个空格
        normalized = re.sub(r'\s+', ' ', normalized)

        # 去除首尾空白
        normalized = normalized.strip()

        # 处理单数到复数的转换（for show_object_list compatibility）
        singular_to_plural_mapping = {
            'TABLE': 'TABLES',
            'VIEW': 'VIEWS',
            'SCHEMA': 'SCHEMAS',
            'FUNCTION': 'FUNCTIONS',
            'VOLUME': 'VOLUMES',
            'CONNECTION': 'CONNECTIONS',
            'VCLUSTER': 'VCLUSTERS',
            'JOB': 'JOBS',
            'PIPE': 'PIPES',
            'INDEX': 'INDEXES',  # 补充：支持 show_object_list 传入 index
            'USER': 'USERS',
            'ROLE': 'ROLES',
            'GRANT': 'GRANTS',
            'SHARE': 'SHARES',
            'CATALOG': 'CATALOGS',
            'WORKSPACE': 'WORKSPACES',
            # 复合词保持原样
            'TABLE STREAM': 'TABLE STREAMS',
            'DYNAMIC TABLE': 'DYNAMIC TABLES',
            'MATERIALIZED VIEW': 'MATERIALIZED VIEWS',
            'EXTERNAL TABLE': 'EXTERNAL TABLES',
            'EXTERNAL SCHEMA': 'EXTERNAL SCHEMAS',
            'EXTERNAL FUNCTION': 'EXTERNAL FUNCTIONS'
        }

        # 如果是单数形式，转换为复数
        if normalized in singular_to_plural_mapping:
            normalized = singular_to_plural_mapping[normalized]

        return normalized

    @staticmethod
    def to_list(value):
        """将逗号分隔字符串或列表转换为列表；忽略空白项。"""
        if value is None:
            return None
        if isinstance(value, list):
            return [str(v).strip() for v in value if str(v).strip()]
        if isinstance(value, str):
            parts = [p.strip() for p in value.split(',') if p.strip()]
            return parts if parts else None
        # 其它类型直接转字符串再切分（不推荐，作为兜底）
        return [str(value).strip()] if str(value).strip() else None

    @staticmethod
    def normalize_object_type_no_plural(value):
        """标准化对象类型（不进行单数->复数转换，供 desc_object 使用）"""
        if value is None:
            return None
        # 复用 normalize_object_type 逻辑，但去掉末尾的单复数映射
        import re
        value = str(value).strip()
        if not value:
            return value
        camel_spaced = re.sub(r'(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])', ' ', value)
        normalized = camel_spaced.replace('_', ' ').upper()
        normalized = re.sub(r'\s+', ' ', normalized).strip()
        return normalized

    @staticmethod
    def parse_function_parameters(value):
        """
        解析函数参数 - 支持字符串和列表格式
        输入格式：
        - 字符串: "x INT, y INT, name STRING"
        - 列表: [{"name": "x", "type": "INT"}, {"name": "y", "type": "INT"}]
        输出格式: [{"name": "x", "type": "INT"}, ...]
        """
        if value is None:
            return []

        # 如果已经是列表格式，直接返回
        if isinstance(value, list):
            return value

        # 如果是字符串格式，解析为列表
        if isinstance(value, str):
            import re
            import html

            value = value.strip()
            if not value:
                return []

            # 解码HTML实体，处理&lt;, &gt;等编码问题
            value = html.unescape(value)

            parameters = []
            # 分割参数：按逗号分割，但注意处理嵌套的括号和角括号
            # 括号如DECIMAL(10,2)，角括号如MAP<STRING, INT>
            param_parts = []
            current_part = ""
            paren_depth = 0
            angle_depth = 0

            for char in value:
                if char == '(':
                    paren_depth += 1
                    current_part += char
                elif char == ')':
                    paren_depth -= 1
                    current_part += char
                elif char == '<':
                    angle_depth += 1
                    current_part += char
                elif char == '>':
                    angle_depth -= 1
                    current_part += char
                elif char == ',' and paren_depth == 0 and angle_depth == 0:
                    param_parts.append(current_part.strip())
                    current_part = ""
                else:
                    current_part += char

            # 添加最后一部分
            if current_part.strip():
                param_parts.append(current_part.strip())

            for param_str in param_parts:
                param_str = param_str.strip()
                if not param_str:
                    continue

                # 使用正则表达式解析 "name TYPE" 格式
                # 支持复杂类型如 DECIMAL(10,2), VARCHAR(100), ARRAY<STRING> 等
                match = re.match(r'^([a-zA-Z_][a-zA-Z0-9_]*)\s+(.+)$', param_str)
                if match:
                    param_name = match.group(1)
                    param_type = match.group(2).strip().upper()
                    parameters.append({
                        "name": param_name,
                        "type": param_type
                    })
                else:
                    raise ValueError(f"无效的参数格式: '{param_str}'. 期望格式: 'name TYPE'")

            return parameters

        raise ValueError(f"参数格式不支持: {type(value)}. 支持字符串或列表格式")

    @staticmethod
    def parse_table_columns(value):
        """
        解析表列定义 - 专门为CREATE TABLE/EXTERNAL TABLE设计
        输入格式：
        - 字符串: "id INT, name STRING, created_at TIMESTAMP"
        - 列表: [{"name": "id", "type": "INT"}, ...]
        输出格式: [{"name": "id", "type": "INT"}, ...]
        """
        if value is None:
            return []

        # 如果已经是列表格式，直接返回
        if isinstance(value, list):
            return value

        # 如果是字符串格式，解析为列表
        if isinstance(value, str):
            import re
            import html

            value = value.strip()
            if not value:
                return []

            # 解码HTML实体，处理&lt;, &gt;等编码问题
            # 这修复了MAP<STRING, STRING>被编码为MAP&lt;STRING, STRING&gt;的问题
            value = html.unescape(value)

            columns = []
            # 分割列定义：按逗号分割，但注意处理嵌套的括号和角括号
            # 括号如DECIMAL(10,2)，角括号如MAP<STRING, INT>
            column_parts = []
            current_part = ""
            paren_depth = 0
            angle_depth = 0

            for char in value:
                if char == '(':
                    paren_depth += 1
                    current_part += char
                elif char == ')':
                    paren_depth -= 1
                    current_part += char
                elif char == '<':
                    angle_depth += 1
                    current_part += char
                elif char == '>':
                    angle_depth -= 1
                    current_part += char
                elif char == ',' and paren_depth == 0 and angle_depth == 0:
                    column_parts.append(current_part.strip())
                    current_part = ""
                else:
                    current_part += char

            # 添加最后一部分
            if current_part.strip():
                column_parts.append(current_part.strip())

            for col_str in column_parts:
                col_str = col_str.strip()
                if not col_str:
                    continue

                # 解析列定义："column_name DATA_TYPE [constraints]"
                # 支持复杂类型如 DECIMAL(10,2), VARCHAR(100), ARRAY<STRING> 等
                match = re.match(r'^([a-zA-Z_][a-zA-Z0-9_]*)\s+(.+)$', col_str)
                if match:
                    column_name = match.group(1)
                    column_type = match.group(2).strip().upper()
                    columns.append({
                        "name": column_name,
                        "type": column_type
                    })
                else:
                    raise ValueError(f"无效的列定义格式: '{col_str}'. 期望格式: 'column_name DATA_TYPE'")

            return columns

        raise ValueError(f"列定义格式不支持: {type(value)}. 支持字符串或列表格式")

    @staticmethod
    def parse_resource_uris(value):
        """
        解析resource_uris - 支持JSON字符串、数组格式和简单字符串格式
        根据ClickZetta产品文档支持volume://、oss://、s3://等路径
        """
        if value is None:
            return []

        # 如果已经是列表格式，直接返回
        if isinstance(value, list):
            return value

        # 如果是字符串格式，支持多种解析方式
        if isinstance(value, str):
            import json

            # 处理空字符串
            if not value.strip():
                return []

            # 🚀 新增：支持简单的URI字符串格式
            # 如果不是JSON格式，尝试作为单个URI处理
            if not value.strip().startswith('[') and not value.strip().startswith('{'):
                # 单个URI字符串，自动包装为数组格式
                uri = value.strip()
                resource_type = 'FILE'  # 默认类型

                # 根据文件扩展名推断类型
                if uri.endswith('.zip'):
                    resource_type = 'ARCHIVE'
                elif uri.endswith('.jar'):
                    resource_type = 'JAR'
                elif uri.endswith('.py'):
                    resource_type = 'FILE'

                return [{"type": resource_type, "uri": uri}]

            try:
                parsed = json.loads(value)
                if isinstance(parsed, list):
                    # 验证每个资源项的格式
                    for item in parsed:
                        if not isinstance(item, dict) or 'uri' not in item:
                            raise ValueError(f"资源项必须包含'uri'字段: {item}")
                        # 自动推断type如果未提供
                        if 'type' not in item:
                            uri = item['uri']
                            if uri.endswith('.zip'):
                                item['type'] = 'ARCHIVE'
                            elif uri.endswith('.jar'):
                                item['type'] = 'JAR'
                            else:
                                item['type'] = 'FILE'
                    return parsed
                elif isinstance(parsed, dict):
                    # 单个对象，包装为数组
                    if 'uri' not in parsed:
                        raise ValueError("资源项必须包含'uri'字段")
                    if 'type' not in parsed:
                        uri = parsed['uri']
                        if uri.endswith('.zip'):
                            parsed['type'] = 'ARCHIVE'
                        elif uri.endswith('.jar'):
                            parsed['type'] = 'JAR'
                        else:
                            parsed['type'] = 'FILE'
                    return [parsed]
                else:
                    raise ValueError("JSON必须解析为数组或对象格式")
            except (json.JSONDecodeError, ValueError) as e:
                # JSON解析失败，可能是无效格式
                if "Expecting value" in str(e):
                    raise ValueError(
                        f"resource_uris格式错误。支持格式：\n• JSON数组: '[{{\"type\": \"ARCHIVE\", \"uri\": \"volume://path/file.zip\"}}]'\n• 简单URI: 'volume://path/file.zip'\n• JSON对象: '{{\"type\": \"ARCHIVE\", \"uri\": \"volume://path/file.zip\"}}'\n当前值: {repr(value)}")
                else:
                    raise ValueError(f"无法解析resource_uris JSON: {e}")

        raise ValueError(f"resource_uris格式不支持: {type(value)}. 支持JSON字符串、数组格式或简单URI字符串")
