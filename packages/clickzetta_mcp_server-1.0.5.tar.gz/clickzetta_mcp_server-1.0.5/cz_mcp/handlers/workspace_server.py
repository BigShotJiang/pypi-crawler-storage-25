from cz_mcp.handlers.ide_admin_server import print_curl_request
from cz_mcp.utils.config_utils import read_url, read_api
from cz_mcp.utils.request_utils import RequestUtils

from loguru import logger


def workspace_list_user_workspaces(tenant_id, user_id, instance_name, instance_id, jwt, env, workspace_name=None):

    url = read_url(env=env) + read_api("WORKSPACE_LIST_USER_WORKSPACES")

    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": str(jwt),
        "instanceId": str(instance_id),
        "userId": str(user_id),
        "accountId": str(tenant_id),
        "instanceName": str(instance_name),
        "env": "prod"
    }
    if workspace_name:
        headers["workspaceName"] = workspace_name

    json_data = {
        "forWrite": "true",
        "listType": 4,
        "pageIndex": 1,
        "pageSize": 99999,
        "tenantId": tenant_id,
        "userId": user_id,
    }
    print_curl_request(url, headers, json_data=json_data, method="POST")

    request = RequestUtils()
    response = request.post(
        url,
        headers=headers,
        json=json_data,
    )
    if response.status_code != 200:
        logger.error(
            f"Failed to fetch workspace. Status code: {response.status_code}, Response: {response.text}"
        )
        raise ValueError(f"Failed to fetch workspace: {response.text}")

    data = response.json()

    return data.get("data", [])


def get_workspace_by_name(user_id, account_id, instance_name, workspace_name, instance_id, jwt, env):
    workspace_list = workspace_list_user_workspaces(
        account_id,
        user_id,
        instance_name,
        instance_id,
        jwt,
        env,
    )
    for data in workspace_list:
        if data.get("projectName") == workspace_name:
            return data
    return {}
