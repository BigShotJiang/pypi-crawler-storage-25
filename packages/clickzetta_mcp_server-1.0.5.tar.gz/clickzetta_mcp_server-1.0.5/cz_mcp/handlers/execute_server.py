"""
Studio Execute Server API functions
Handles async task execution and status polling
"""
import json
import time
import logging
from typing import Dict, Any, Optional

from cz_mcp.handlers.login_server import get_user_id
from cz_mcp.utils.config_utils import read_url, read_api
from cz_mcp.utils.request_utils import RequestUtils

from loguru import logger


def adhoc_execute(
    data_task_id: int,
    data_task_content: str,
    params: Dict[str, str],
    update_by: str,
    collect_type: int,
    max_row_size: int,
    offset_line: int,
    offset_col: int,
    multi_data_source: list,
    adhoc_vc_code: str,
    adhoc_schema_name: str,
    adhoc_vc_id: str,
    jwt_token: str,
    instance_name: str,
    user_id:int,
    instance_id:int,
    account_id:int,
    env: str,
    workspace_name: Optional[str] = None
) -> str:
    """
    Execute adhoc task asynchronously
    
    Args:
        data_task_id: Data file ID
        data_task_content: File content (JSON string for integration tasks)
        params: Parameter key-value pairs
        update_by: User who triggers the execution
        collect_type: Collection type (1 for normal)
        max_row_size: Maximum rows to return
        offset_line: Line offset
        offset_col: Column offset
        multi_data_source: Multi data source configuration
        adhoc_vc_code: Virtual cluster code
        adhoc_schema_name: Schema name
        adhoc_vc_id: Virtual cluster ID
        jwt_token: JWT authentication token
        instance_name: Instance name
        env: Environment
        workspace_name: Workspace name
        
    Returns:
        Response text containing task instance ID
    """
    url = read_url(env=env) + read_api("ADHOC_EXECUTE")
    
    # url_get_current = read_url(env=env) + read_api("USER_GET_CURRENT")
    # data = get_user_id(url_get_current, jwt_token, instance_name, env)
    #
    # user_id = data.get("id")
    # account_id = data.get("accountId")
    # instance_id = data.get("instanceId")
    
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": str(jwt_token),
        "userId": str(user_id),
        "instanceId": str(instance_id),
        "accountId": str(account_id),
        "instanceName": str(instance_name),
        "tenantId": str(account_id),
        "env": "prod"
    }
    if workspace_name:
        headers["workspaceName"] = workspace_name
    
    json_data = {
        "updateBy": update_by,
        "dataFileId": data_task_id,
        "collectType": collect_type,
        "maxRowSize": max_row_size,
        "offsetLine": offset_line,
        "offsetCol": offset_col,
        "instanceName": instance_name,
        "multiDataSource": multi_data_source,
        "adhocVcCode": adhoc_vc_code,
        "adhocSchemaName": adhoc_schema_name,
        "adhocVcId": adhoc_vc_id,
        "dataFileContent": data_task_content,
        "params": params
    }
    
    logger.info(f"Executing adhoc task for file_id: {data_task_id}")
    response = RequestUtils().post(url=url, headers=headers, json=json_data).text
    return response


def get_task_instance_detail(
    task_instance_id: int,
    jwt_token: str,
    instance_name: str,
    user_id: int,
    instance_id:int,
    account_id: int,
    env: str,
    project_id: Optional[int] = None,
    schedule_task_id: Optional[int] = None,
    workspace_name: Optional[str] = None
) -> str:
    """
    Get task instance execution detail
    
    Args:
        task_instance_id: Task instance ID
        jwt_token: JWT authentication token
        instance_name: Instance name
        env: Environment
        project_id: Optional project ID
        schedule_task_id: Optional schedule task ID
        workspace_name: Workspace name
        
    Returns:
        Response text containing task execution status and details
    """
    url = read_url(env=env) + read_api("TASK_INST_GET_DETAIL")
    
    # url_get_current = read_url(env=env) + read_api("USER_GET_CURRENT")
    # data = get_user_id(url_get_current, jwt_token, instance_name, env)
    #
    # user_id = data.get("id")
    # account_id = data.get("accountId")
    # instance_id = data.get("instanceId")
    
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": str(jwt_token),
        "userId": str(user_id),
        "instanceId": str(instance_id),
        "accountId": str(account_id),
        "instanceName": str(instance_name),
        "tenantId": str(account_id)
    }
    if workspace_name:
        headers["workspaceName"] = workspace_name
    
    json_data = {
        "taskInstanceId": task_instance_id,
        "projectId": project_id,
        "scheduleTaskId": schedule_task_id
    }
    
    response = RequestUtils().post(url=url, headers=headers, json=json_data).text
    return response


def poll_task_status(
    task_instance_id: int,
    jwt_token: str,
    instance_name: str,
    instance_id:int,
    user_id: int,
    account_id: int,
    env: str,
    max_wait_seconds: int = 300,
    poll_interval: int = 5
) -> Dict[str, Any]:
    """
    Poll task execution status until completion or timeout
    
    Args:
        task_instance_id: Task instance ID to poll
        jwt_token: JWT authentication token
        instance_name: Instance name
        env: Environment
        max_wait_seconds: Maximum seconds to wait (default: 300)
        poll_interval: Seconds between polls (default: 5)
        
    Returns:
        Dict containing final status and details
    """
    start_time = time.time()
    poll_count = 0
    
    # Status mapping
    # 1=Success, 2=Not started, 3=Failed, 4=Running, 
    # 5=Waiting for resources, 6=Waiting for upstream, 
    # 7=Paused, 8=Upstream failed blocking
    TERMINAL_STATUSES = {1, 3, 8}  # SUCCESS, FAILED, UPSTREAM_FAILED_BLOCKING
    STATUS_NAMES = {
        1: "SUCCESS",
        2: "NOT_STARTED",
        3: "FAILED",
        4: "RUNNING",
        5: "WAITING_FOR_RESOURCES",
        6: "WAITING_FOR_UPSTREAM",
        7: "PAUSED",
        8: "UPSTREAM_FAILED_BLOCKING"
    }
    
    logger.info(f"Starting to poll task {task_instance_id}, max_wait={max_wait_seconds}s, interval={poll_interval}s")
    
    while True:
        elapsed = time.time() - start_time
        poll_count += 1
        
        # Check timeout
        if elapsed > max_wait_seconds:
            logger.warning(f"Polling timeout after {elapsed:.1f}s and {poll_count} attempts")
            return {
                "success": False,
                "status": "POLLING_TIMEOUT",
                "message": f"Task polling timeout after {max_wait_seconds} seconds",
                "task_instance_id": task_instance_id,
                "elapsed_seconds": elapsed,
                "poll_count": poll_count
            }
        
        # Get task status
        try:
            response_text = get_task_instance_detail(
                task_instance_id=task_instance_id,
                jwt_token=jwt_token,
                instance_name=instance_name,
                instance_id= instance_id,
                user_id= user_id,
                account_id=account_id,
                env=env
            )
            
            response_data = json.loads(response_text)
            
            if response_data.get("code") != "200":
                logger.error(f"Failed to get task status: {response_data.get('message')}")
                return {
                    "success": False,
                    "status": "API_ERROR",
                    "message": response_data.get("message", "Unknown error"),
                    "task_instance_id": task_instance_id,
                    "elapsed_seconds": elapsed,
                    "poll_count": poll_count
                }
            
            task_data = response_data.get("data", {})
            status_code = task_data.get("instanceStatus")
            status_name = STATUS_NAMES.get(status_code, f"UNKNOWN({status_code})")

            logger.info(f"Poll #{poll_count} (elapsed {elapsed:.1f}s): Task {task_instance_id} status = {status_name}")

            # Check if task reached terminal status
            if status_code in TERMINAL_STATUSES:
                is_success = (status_code == 1)  # SUCCESS
                from cz_mcp.tools.schedule_instance_tools import convert_task_run_fields
                converted = convert_task_run_fields(task_data)

                result = {
                    "success": is_success,
                    "status": status_name,
                    "status_code": status_code,
                    "task_instance_id": task_instance_id,
                    "elapsed_seconds": elapsed,
                    "poll_count": poll_count,
                    "task_detail": converted
                }

                if is_success:
                    logger.info(f"Task {task_instance_id} completed successfully after {elapsed:.1f}s")
                else:
                    logger.warning(f"Task {task_instance_id} failed with status {status_name} after {elapsed:.1f}s")
                    result["error_message"] = task_data.get("failMsg", "No error message")

                return result
            
            # Task still running, wait before next poll
            time.sleep(poll_interval)
            
        except Exception as e:
            logger.error(f"Error during polling: {e}")
            return {
                "success": False,
                "status": "POLLING_ERROR",
                "message": str(e),
                "task_instance_id": task_instance_id,
                "elapsed_seconds": elapsed,
                "poll_count": poll_count
            }

