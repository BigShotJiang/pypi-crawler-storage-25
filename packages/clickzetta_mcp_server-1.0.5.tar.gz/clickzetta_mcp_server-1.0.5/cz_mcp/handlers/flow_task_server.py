"""
Flow Task Handler - API calls for Flow (组合任务) development operations
"""
import json
import time

from loguru import logger

from cz_mcp.utils.config_utils import read_url, read_api
from cz_mcp.utils.request_utils import RequestUtils


def _build_flow_headers(jwt_token, instance_name, tenant_id, user_id, env, workspace_name=None, ip=None):
    """Build common headers for flow API calls"""
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "x-clickzetta-token": str(jwt_token),
        "tenantId": str(tenant_id),
        "userId": str(user_id),
        "instanceName": str(instance_name),
        "env": "prod",
        "openApi": "false",
    }
    if workspace_name:
        headers["workspaceName"] = workspace_name
    if ip:
        headers["X-real-ip"] = ip
    return headers


def get_flow_dag(data_file_id, jwt_token, instance_name, tenant_id, env, workspace_name=None):
    """Get flow DAG structure"""
    url = read_url(env=env) + read_api("FLOW_GET_DAG")
    headers = _build_flow_headers(jwt_token, instance_name, tenant_id, 0, env, workspace_name)
    response = RequestUtils().post(url=url, headers=headers, params={"dataFileId": data_file_id}).text
    return response


def create_flow_node(data_file_id, project_id, node_name, file_type, jwt_token, instance_name,
                     tenant_id, user_id, env, workspace_name=None,
                     node_description=None, dependency_node_id=None, position=None, content=None):
    """Create a flow node"""
    url = read_url(env=env) + read_api("FLOW_NODE_CREATE")
    headers = _build_flow_headers(jwt_token, instance_name, tenant_id, user_id, env, workspace_name)

    json_data = {
        "tenantId": tenant_id,
        "userId": user_id,
        "dataFileId": data_file_id,
        "projectId": project_id,
        "nodeName": node_name,
        "fileType": file_type,
        "env": env,
    }
    if node_description:
        json_data["nodeDescription"] = node_description
    if dependency_node_id:
        json_data["dependencyNodeId"] = dependency_node_id
    if position:
        json_data["position"] = position
    if content:
        json_data["content"] = content

    response = RequestUtils().post(url=url, headers=headers, json=json_data).text
    return response


def bind_flow_node(current_file_id, current_node_id, current_project_id,
                   dependency_file_id, dependency_node_id, dependency_project_id,
                   jwt_token, instance_name, tenant_id, user_id, env, workspace_name=None):
    """Bind dependency between flow nodes"""
    url = read_url(env=env) + read_api("FLOW_NODE_BIND")
    headers = _build_flow_headers(jwt_token, instance_name, tenant_id, user_id, env, workspace_name)

    json_data = {
        "tenantId": tenant_id,
        "userId": user_id,
        "currentFileId": current_file_id,
        "currentNodeId": current_node_id,
        "currentProjectId": current_project_id,
        "dependencyFileId": dependency_file_id,
        "dependencyNodeId": dependency_node_id,
        "dependencyProjectId": dependency_project_id,
    }

    response = RequestUtils().post(url=url, headers=headers, json=json_data).text
    return response


def unbind_flow_node(dep_id, file_id, jwt_token, instance_name, tenant_id, user_id, env, workspace_name=None):
    """Unbind dependency between flow nodes"""
    url = read_url(env=env) + read_api("FLOW_NODE_UNBIND")
    headers = _build_flow_headers(jwt_token, instance_name, tenant_id, user_id, env, workspace_name)

    json_data = {
        "tenantId": tenant_id,
        "userId": user_id,
        "depId": dep_id,
        "fileId": file_id,
    }

    response = RequestUtils().post(url=url, headers=headers, json=json_data).text
    return response


def remove_flow_node(file_id, node_id, jwt_token, instance_name, tenant_id, user_id, env, workspace_name=None):
    """Remove a flow node"""
    url = read_url(env=env) + read_api("FLOW_NODE_REMOVE")
    headers = _build_flow_headers(jwt_token, instance_name, tenant_id, user_id, env, workspace_name)

    json_data = {
        "tenantId": tenant_id,
        "userId": user_id,
        "fileId": file_id,
        "nodeId": node_id,
    }

    response = RequestUtils().post(url=url, headers=headers, json=json_data).text
    return response


def submit_flow(file_id, project_id, jwt_token, instance_name, tenant_id, user_id, env, workspace_name=None):
    """Submit a flow task"""
    url = read_url(env=env) + read_api("FLOW_SUBMIT")
    headers = _build_flow_headers(jwt_token, instance_name, tenant_id, user_id, env, workspace_name)

    json_data = {
        "fileId": file_id,
        "projectId": project_id,
        "env": env,
    }

    response = RequestUtils().post(url=url, headers=headers, json=json_data).text
    return response


def check_submit_status(submit_trace_id, jwt_token, instance_name, tenant_id, env, workspace_name=None):
    """Check flow submit status"""
    url = read_url(env=env) + read_api("FLOW_CHECK_SUBMIT_STATUS")
    headers = _build_flow_headers(jwt_token, instance_name, tenant_id, 0, env, workspace_name)

    response = RequestUtils().post(url=url, headers=headers, params={"submitTraceId": submit_trace_id}).text
    return response


def list_flow_node_instances(tenant_id, flow_id, flow_instance_id, jwt_token, instance_name, env,
                             workspace_name=None, flow_node_id=None, flow_node_instance_id=None):
    """List flow node instances with extra info"""
    url = read_url(env=env) + read_api("FLOW_INST_LIST_WITH_EXTRA")
    headers = _build_flow_headers(jwt_token, instance_name, tenant_id, 0, env, workspace_name)

    json_data = {
        "tenantId": tenant_id,
        "flowId": flow_id,
        "flowInstanceId": flow_instance_id,
    }
    if flow_node_id:
        json_data["flowNodeId"] = flow_node_id
    if flow_node_instance_id:
        json_data["flowNodeInstanceId"] = flow_node_instance_id

    response = RequestUtils().post(url=url, headers=headers, json=json_data).text
    return response


def save_flow_node_content(data_file_id, node_id, content, project_id, user_name,
                           jwt_token, instance_name, tenant_id, env, workspace_name=None,
                           param_value_list=None):
    """Save content for a flow node."""
    url = read_url(env=env) + read_api("SAVE_DATAFILE_CONFIGURATION")
    headers = _build_flow_headers(jwt_token, instance_name, tenant_id, 0, env, workspace_name)

    json_data = {
        "dataFileId": data_file_id,
        "nodeId": node_id,
        "dataFileContent": content,
        "projectId": project_id,
        "collectType": 2,
        "onlySaveContent": 1,
        "updateBy": user_name or "",
        "paramValueList": param_value_list or [],
        "inputParamValueList": None,
        "outputParamValueList": None,
        "instanceName": instance_name,
        "adhocConfigs": json.dumps({
            "multiDataSource": [],
            "schema": "public",
            "adhocVcCode": "DEFAULT",
        }),
        "extendConfigs": None,
    }

    response = RequestUtils().post(url=url, headers=headers, json=json_data).text
    return response


def get_flow_node_detail(data_file_id, node_id, jwt_token, instance_name, tenant_id, env, workspace_name=None):
    """Get flow node detail via getDetail API."""
    url = read_url(env=env) + read_api("GET_DETAIL")
    headers = _build_flow_headers(jwt_token, instance_name, tenant_id, 0, env, workspace_name)
    json_data = {"id": data_file_id, "nodeId": node_id, "collectType": 2}
    response = RequestUtils().post(url=url, headers=headers, json=json_data).text
    return response


def save_flow_node_configuration(data_file_id, node_id, project_id, user_id, user_name,
                                 jwt_token, instance_name, tenant_id, env, workspace_name=None,
                                 schema_name="public", etl_vc_code="DEFAULT", etl_vc_id=None):
    """Save schedule configuration for a flow node with sensible defaults."""
    url = read_url(env=env) + read_api("SAVE_DATAFILE_CONFIGURATION")
    headers = _build_flow_headers(jwt_token, instance_name, tenant_id, user_id, env, workspace_name)

    json_data = {
        "projectId": project_id,
        "dataFileId": data_file_id,
        "nodeId": node_id,
        "useFlowConfig": True,
        "scheduleConfigType": "1",
        "scheduleRateType": 1,
        "scheduleType": 1,
        "triggerType": 1,
        "taskPriority": "1",
        "fileCreateType": 1,
        "scheduleCreatedType": "2",
        "collectType": 2,
        "onlySaveContent": 0,
        "isScheduleRateTypeOff": False,
        "useActiveEndTime": False,
        "enableAutoMv": False,
        "retryIntervalTime": 2,
        "retryIntervalTimeUnit": "s",
        "retryCount": 1,
        "rerunProperty": "1",
        "selfDependsJob": 0,
        "executeTimeout": 0,
        "executeTimeoutUnit": "m",
        "activeStartTime": "1989-12-31T00:00:00.000Z",
        "activeEndTime": "2099-01-01T00:00:00.000Z",
        "ownerEnName": str(user_id),
        "ownerCnName": user_name or str(user_id),
        "schemaName": schema_name,
        "etlVcCode": etl_vc_code,
        "instanceName": instance_name,
        "schedule": [["everyday"]],
        "frequency": "1",
        "configProperties": json.dumps({"extConfig": {}, "enableAutoMv": False}),
        "dataFileInputListReqs": [],
        "dataFileOutputListReqs": [],
    }
    if etl_vc_id:
        json_data["etlVcId"] = etl_vc_id

    response = RequestUtils().post(url=url, headers=headers, json=json_data).text
    return response


def submit_flow_and_wait(file_id, project_id, jwt_token, instance_name, tenant_id, user_id, env,
                         workspace_name=None, max_wait=60, poll_interval=3):
    """Submit flow and poll until completion"""
    submit_resp = submit_flow(file_id, project_id, jwt_token, instance_name, tenant_id, user_id, env, workspace_name)
    submit_data = json.loads(submit_resp)

    if str(submit_data.get("code")) != "200":
        return submit_resp

    trace_id = submit_data.get("data")
    if not trace_id:
        return submit_resp

    # Poll for completion
    # FlowSubmitStatusEnum: 0=INIT, 1=SUBMITTING, 2=SUCCESS, 3=FAILED
    start = time.time()
    while time.time() - start < max_wait:
        status_resp = check_submit_status(trace_id, jwt_token, instance_name, tenant_id, env, workspace_name)
        status_data = json.loads(status_resp)
        if str(status_data.get("code")) == "200":
            status = status_data.get("data")
            if status == 2:
                return json.dumps({"code": "200", "message": "Flow submitted successfully", "submitTraceId": trace_id})
            elif status == 3:
                return json.dumps({"code": "500", "message": "Flow submit failed", "submitTraceId": trace_id})
            # 0=INIT, 1=SUBMITTING → keep polling
        time.sleep(poll_interval)

    return json.dumps({"code": "500", "message": f"Submit timeout after {max_wait}s", "submitTraceId": trace_id})
