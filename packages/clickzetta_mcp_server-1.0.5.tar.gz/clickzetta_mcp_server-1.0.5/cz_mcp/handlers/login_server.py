from urllib.parse import urljoin

from jsonpath_ng import parse
from requests import exceptions as requests_exceptions

from cz_mcp.utils.config_utils import read_url, read_api
from cz_mcp.utils.request_utils import RequestUtils

from loguru import logger

def login_with_password(instance: str, username: str, password: str, url: str = None):
    """
    Login with username and password
    :param instance: instance name
    :param username: username for authentication
    :param password: password for authentication
    :param url: base URL for login
    :return: dict with login response data including token, instanceId, userId, expireTime
    """
    from cz_mcp.core import PermissionException, ToolExecutionException

    headers = {
        'content-type': "application/json", "Accept": "application/json, text/plain, */*",
    }
    json_data = {
        "username": username,
        "password": password,
        "accountDisplayName": instance
    }

    # Enhanced logging
    logger.info(f"Attempting password login to: {url}")
    logger.info(f"Login parameters: instanceName={instance}, username={username}")
    logger.debug(f"Request headers: {headers}")

    try:
        response = RequestUtils().post(url=url, headers=headers, json=json_data).text
        logger.debug(f"Login response received: {response[:200]}...")

        response_code = RequestUtils().get_data(response, '$.code')

        if response_code != 0:
            logger.error(f"Login failed with response: {response}")
            raise ToolExecutionException(f"User login failed: {response}")
        else:
            token = RequestUtils().get_data(response, '$.data.token')

            if token:
                return token
            else:
                logger.error(f"Token not found in response: {response}")
                raise PermissionException(f"Token not found in login response: {response}")
    except Exception as e:
        logger.error(f"Login request exception: {type(e).__name__}: {str(e)}")
        raise PermissionException(f"Login request failed: {str(e)}") from e


def login_wrapper(instance, pat=None, username: str = None, password: str = None, url: str = None):
    """
    Login interface
    :param instance: instance name
    :param pat: PAT token for authentication
    :param username: username for password authentication
    :param password: password for password authentication
    :param url: base URL for login
    :return: dict with login response data including token, instanceId, userId, expireTime
    """
    from cz_mcp.core import PermissionException, ToolExecutionException

    headers = {
        'content-type': "application/json", "Accept": "application/json, text/plain, */*",
    }
    if username and password:
        json_data = {
            "username": username,
            "password": password,
            "instanceName": instance
        }
        auth_mode = "password"
    elif pat:
        json_data = {
            "accessToken": pat,
            "instanceName": instance
        }
        auth_mode = "pat"
    else:
        raise PermissionException("Either pat or username/password must be provided for login")

    url = url or read_url()
    path = read_api("USER_LOGIN_SINGLE")
    full_url = url + path

    # Enhanced logging
    logger.info(f"Attempting login to: {full_url}")
    if auth_mode == "password":
        logger.info(f"Login parameters: instanceName={instance}, username={username}")
    else:
        logger.info(
            f"Login parameters: instanceName={instance}, accessToken={'***' + pat[-8:] if pat and len(pat) > 8 else 'None'}")
    logger.debug(f"Request headers: {headers}")

    try:
        response = RequestUtils().post(url=full_url, headers=headers, json=json_data).text

        response_code = RequestUtils().get_data(response, '$.code')

        if response_code != 0:
            logger.error(f"Login failed with response: {response}")
            raise ToolExecutionException(f"User login failed: {response}")
        else:
            # Extract all login data
            login_data = {
                'token': RequestUtils().get_data(response, '$.data.token'),
                'instance_id': RequestUtils().get_data(response, '$.data.instanceId'),
                'user_id': RequestUtils().get_data(response, '$.data.userId'),
                'expire_time': RequestUtils().get_data(response, '$.data.expireTime')
            }

            if login_data['token']:
                logger.info(f"Successfully obtained JWT token and login data: "
                            f"instanceId={login_data['instance_id']}, userId={login_data['user_id']}")
                return login_data
            else:
                logger.error(f"Token not found in response: {response}")
                raise PermissionException(f"Token not found in login response: {response}")
    except Exception as e:
        logger.error(f"Login request exception: {type(e).__name__}: {str(e)}")
        raise PermissionException(f"Login request failed: {str(e)}") from e


# https://uat-api.clickzetta.com/clickzetta-portal/service/getInstanceByName?instanceName=jnsxwfyr

def get_instance_id(token: str = None, instance_name: str = None, env: str = None) -> int:
    """
    调用 clickzetta 获取实例 ID

    :param token: x-clickzetta-token
    :return: 实例 ID（int），如果失败则返回 None
    """
    headers = {
        "accept": "application/json, text/plain, */*",
        "accept-language": "zh-CN,zh;q=0.9",
        "cz-lang": "zh_CN",
        "user-agent": (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36"
        ),
        "x-clickzetta-token": token
    }

    full_url = urljoin(read_url(env=env), f"{read_api('SERVICE_GET_INSTANCE_BY_NAME')}?instanceName={instance_name}")

    return RequestUtils().get_data(RequestUtils().get(url=full_url, headers=headers).text, '$.data.id')


def get_data(data, jsonpath_expr: str):
    """安全地通过 JSONPath 获取数据"""
    try:
        expr = parse(jsonpath_expr)
        matches = [match.value for match in expr.find(data)]
        return matches[0] if matches else None
    except Exception:
        return None


def get_user_id(url: str = None, token: str = None, instance_name: str = None, env: str = None):
    """
    调用 clickzetta 接口获取当前用户信息，并返回用户 ID

    :param token: x-clickzetta-token
    :return: 用户 ID（int），如果失败则返回 None
    """
    headers = {
        "accept": "application/json, text/plain, */*",
        "accept-language": "zh-CN,zh;q=0.9",
        "cz-lang": "zh_CN",
        "user-agent": (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36"
        ),
        "x-clickzetta-token": token
    }

    if url is None or not url.endswith('getCurrentUser'):
        url = read_url(env=env) + "/clickzetta-portal/user/getCurrentUser"

    try:
        resp = RequestUtils().post(url=url, headers=headers, timeout=10)
        resp.raise_for_status()  # 网络或 4xx/5xx 错误会抛异常

        data = resp.json()

        data_value = get_data(data, '$.data')

        if instance_name:
            # ===== 获取 instance_id =====
            instance_id = get_instance_id(token, instance_name, env)
            if isinstance(data_value, dict):
                data_value["instanceId"] = instance_id

        return data_value

    except requests_exceptions.RequestException as e:
        logger.error("get_user_id failed:", e)
        return None

def get_current_user( token: str = None,  env: str = None):
    """
    调用 clickzetta 接口获取当前用户信息，并返回用户 ID

    :param token: x-clickzetta-token
    :return: 用户 ID（int），如果失败则返回 None
    """
    headers = {
        "accept": "application/json, text/plain, */*",
        "accept-language": "zh-CN,zh;q=0.9",
        "cz-lang": "zh_CN",
        "user-agent": (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36"
        ),
        "x-clickzetta-token": token
    }
    url = read_url(env=env) + read_api("USER_GET_CURRENT")


    try:
        resp = RequestUtils().post(url=url, headers=headers, timeout=10)
        resp.raise_for_status()  # 网络或 4xx/5xx 错误会抛异常
        data = resp.json()
        data_value = get_data(data, '$.data')
        return data_value

    except requests_exceptions.RequestException as e:
        logger.error("get_user_id failed:", e)
        return None

def get_user_config(jwt, user_id: int, account_id: int, env: str = None):
    """
    调用 clickzetta 接口获取当前用户信息，并返回用户 ID

    :param token: x-clickzetta-token
    :return: 用户 ID（int），如果失败则返回 None
    """
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": str(jwt),
        "userId": str(user_id),
        "accountId": str(account_id),
        "X-real-ip": "192.168.1.100"
    }

    url = read_url(env=env) + read_api("GET_USER_CONFIG")

    try:
        request = RequestUtils()
        resp = request.post(url, headers=headers, json={"type": "mcp"}, timeout=10)
        resp.raise_for_status()

        data = resp.json()

        data_value = get_data(data, '$.data')
        if data_value:
            return data_value["content"]

        return data_value

    except requests_exceptions.RequestException as e:
        logger.error("get_user_config failed:", e)
        return None
