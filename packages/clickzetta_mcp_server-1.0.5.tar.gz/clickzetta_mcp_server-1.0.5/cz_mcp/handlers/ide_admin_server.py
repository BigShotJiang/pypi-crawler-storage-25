"""
Studio IDE Admin Server API functions
"""
import datetime
import json

from loguru import logger

from cz_mcp.utils.config_utils import read_url, read_api, read_env_configuration
from cz_mcp.utils.log_sanitizer import sanitize_data
from cz_mcp.utils.request_utils import RequestUtils


def generate_curl_command(url, headers, json_data=None, method="POST", mask_sensitive=True):
    """
    Generate a curl command from request parameters for debugging
    
    Args:
        url: Request URL
        headers: Request headers dict
        json_data: Request JSON data dict
        method: HTTP method (default: POST)
        mask_sensitive: Whether to mask sensitive fields (default: True)
    
    Returns:
        curl command string
    """
    curl_parts = [f"curl -X {method}"]
    
    headers_to_log = sanitize_data(headers) if mask_sensitive else headers

    # Add headers
    for key, value in headers_to_log.items():
        curl_parts.append(f"-H '{key}: {value}'")
    
    # Add JSON data
    if json_data:
        body_to_log = sanitize_data(json_data) if mask_sensitive else json_data
        json_str = json.dumps(body_to_log, ensure_ascii=False)
        # Escape single quotes in JSON for shell
        json_str = json_str.replace("'", "'\\''")
        curl_parts.append(f"-d '{json_str}'")
    
    # Add URL
    curl_parts.append(f"'{url}'")
    
    return " \\\n  ".join(curl_parts)


def create_task(project_id, task_type, created_by, data_task_name, task_description, data_folder_id, jwt_token,
                instance_name, env, workspace_name=None):
    """
    Query data file list by project workspace
    """
    url = read_url(env=env) + read_api("DATA_FILE_ADD")
    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "x-clickzetta-token": jwt_token,
        "instanceName": instance_name,
    }
    if workspace_name:
        header["workspaceName"] = workspace_name

    json_data = {
        "fileType": task_type,
        "createdBy": created_by,
        "projectId": project_id,
        "dataFileName": data_task_name,
        "fileDescription": task_description,
        "dataFolderId": data_folder_id
    }

    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def create_folder(project_id, created_by, parent_folder_id, data_folder_name, jwt_token, instance_name, env, workspace_name=None):
    """
    create folder in
    """
    url = read_url(env=env) + read_api("DATA_FOLDER_ADD")
    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "x-clickzetta-token": jwt_token,
        "instanceName": instance_name,
    }
    if workspace_name:
        header["workspaceName"] = workspace_name

    json_data = {
        "createdBy": created_by,
        "projectId": project_id,
        "dataFolderName": data_folder_name,
        "parentFolderId": parent_folder_id,
        "dataFolderType": 1
    }

    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def list_folders(project_id, parent_folder_id, folder_name, folder_type, page, page_size, instance_name, jwt_token,
                 env, workspace_name=None):
    """
    List folders in project with filtering and pagination
    """
    url = read_url(env=env) + read_api("MCP_LIST_FOLDERS")
    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "x-clickzetta-token": jwt_token,
        "instanceName": instance_name,
    }
    if workspace_name:
        header["workspaceName"] = workspace_name

    json_data = {
        "projectId": project_id,
        "page": page,
        "pageSize": page_size
    }

    # Add optional filters
    if parent_folder_id is not None:
        json_data["parentFolderId"] = parent_folder_id
    if folder_name:
        json_data["folderName"] = folder_name
    if folder_type is not None:
        json_data["folderType"] = folder_type

    # Print curl command for debugging
    curl_headers = ' '.join([f"-H '{k}: {v}'" for k, v in header.items()])
    curl_data = json.dumps(json_data, ensure_ascii=False)
    curl_command = f"curl -X POST '{url}' {curl_headers} -d '{curl_data}'"
    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def list_files(project_id, folder_id, file_name, file_type, page, page_size, jwt_token, instance_name, env, workspace_name=None):
    """
    List files in folder with filtering and pagination
    """
    url = read_url(env=env) + read_api("MCP_LIST_FILES")
    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "x-clickzetta-token": jwt_token,
        "instanceName": instance_name,
    }
    if workspace_name:
        header["workspaceName"] = workspace_name

    json_data = {
        "projectId": project_id,
        "page": page,
        "pageSize": page_size
    }

    # Add optional filters
    if folder_id is not None:
        json_data["folderId"] = folder_id
    if file_name:
        json_data["fileName"] = file_name
    if file_type is not None:
        json_data["fileType"] = file_type

    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def save_content(project_id, data_task_id, content, param_value_list, update_by, jwt_token, instance_name, env,
                 adhoc_configs=None, workspace_name=None, replace_escaped_chars=True):
    """
    save file content
    """
    url = read_url(env=env) + read_api("SAVE_DATAFILE_CONFIGURATION")
    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "x-clickzetta-token": jwt_token,
        "instanceName": instance_name,
    }
    if workspace_name:
        header["workspaceName"] = workspace_name
    
    # CRITICAL FIX: dataFileContent must be a JSON string, not an object
    # The API expects a stringified JSON, not a nested object
    if isinstance(content, dict):
        content_str = json.dumps(content, ensure_ascii=False)
    else:
        content_str = content

    # Handle escaped control sequences when enabled (default behavior).
    # Set replace_escaped_chars=False to preserve literal escape sequences like "\\n".
    if isinstance(content_str, str) and replace_escaped_chars:
        # Replace common escape sequences with their actual characters
        # This handles content from models that may include escaped characters like \n, \r, \t
        # We use a simple replacement approach to avoid encoding issues
        content_str = content_str.replace('\\n', '\n')
        content_str = content_str.replace('\\r', '\r')
        content_str = content_str.replace('\\t', '\t')

    # Ensure paramValueList is an array, not null
    if param_value_list is None:
        param_value_list = []
    
    json_data = {
        "dataFileId": data_task_id,
        "dataFileContent": content_str,  # Must be string
        "onlySaveContent": 1,
        "projectId": project_id,
        "updateBy": update_by,
        "paramValueList": param_value_list,
        "instanceName": instance_name
    }

    # Add adhocConfigs if provided (also as string)
    if adhoc_configs is not None:
        if isinstance(adhoc_configs, dict):
            json_data["adhocConfigs"] = json.dumps(adhoc_configs, ensure_ascii=False)
        else:
            json_data["adhocConfigs"] = adhoc_configs

    # Generate and log curl command for debugging (masked sensitive fields)
    masked_header = sanitize_data(header)
    masked_json_data = sanitize_data(json_data)
    curl_command = generate_curl_command(url, header, json_data, method="POST", mask_sensitive=True)
    logger.info("=" * 100)
    logger.info("SAVE_CONTENT REQUEST - Masked curl command:")
    logger.info(curl_command)
    logger.info("=" * 100)
    logger.info(f"Request URL: {url}")
    logger.info(f"Request Headers (masked): {json.dumps(masked_header, indent=2, ensure_ascii=False)}")
    logger.info(f"Request Body (masked): {json.dumps(masked_json_data, indent=2, ensure_ascii=False)}")
    logger.info("=" * 100)

    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    
    logger.info(f"Response: {response}")
    logger.info("=" * 100)
    
    return response


def get_task_detail(data_task_id, jwt_token, instance_name, env, workspace_name=None):
    """
    Get file detail information
    :param dataFileId: Data file ID
    :return: Response text
    """
    url = read_url(env=env) + read_api("GET_DETAIL")
    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "x-clickzetta-token": jwt_token,
        "instanceName": instance_name,
    }
    if workspace_name:
        header["workspaceName"] = workspace_name
    json_data = {
        "id": data_task_id
    }

    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def save_configuration(project_id, data_file_id, cron_express, user_id, user_name,
                       active_start_time, active_end_time, retry_interval_time, retry_interval_time_units,
                       retry_count, rerun_property, execute_timeout, execute_timeout_unit, self_depends_job, data_file_input_list_reqs, config_properties,
                       schema_name, etl_vc_code, etl_vc_id,
                       jwt_token, instance_name,
                       env, workspace_name=None):
    """
    save file configuration
    """
    url = read_url(env=env) + read_api("SAVE_DATAFILE_CONFIGURATION")
    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "x-clickzetta-token": jwt_token,
        # "instanceid": read_env_configuration(key="instanceId"),
        "instanceName": instance_name,
    }
    if workspace_name:
        header["workspaceName"] = workspace_name
    # "2025-10-22T16:00:00.000Z"

    # data_file_input_list_reqs is a array just like
    # "data_file_input_list_reqs": [
    #                             {
    #                                 "dependency_file_id": 12005123,
    #                                 "dep_strategy": 0
    #                             }
    #                         ]
    # I need add properties in every item in data_file_input_list_reqs
    # 1. add "parseType": "1",
    # 2. add "dependencyProjectId": project_id,
    # 3. add
    # 确保参数存在且为列表
    if data_file_input_list_reqs is None:
        data_file_input_list_reqs = []

    # 创建一个新的数组来承接处理后的变量
    processed_dependencies = []

    # 如果数组不为空，为每个元素添加字段

    if data_file_input_list_reqs:
        for item in data_file_input_list_reqs:
            # 创建新的依赖项字典
            if "dependencyFileId" in item:
                processed_dependencies.append(item)
            else:
                dependency_item = {
                    "parseType": "1",
                    "dependencyProjectId": project_id,
                    "depStrategy": 0,
                    "dependencyFileId": item.get("dependency_task_id"),
                    "dependencyFileName": item.get("dependency_task_name")
                }
                processed_dependencies.append(dependency_item)

    json_data = {
        "projectId": project_id,
        "dataFileId": data_file_id,
        "retryCount": retry_count,
        "retryIntervalTime": retry_interval_time,
        "retryIntervalTimeUnit": retry_interval_time_units,
        "rerunProperty": rerun_property,
        "selfDependsJob": self_depends_job,
        "activeStartTime": active_start_time,
        "activeEndTime": active_end_time,
        "ownerEnName": user_id,
        "ownerCnName": user_name,
        "cronExpress": cron_express,
        "schemaName": schema_name,
        "etlVcCode": etl_vc_code,
        "etlVcId": etl_vc_id,
        "executeTimeout": execute_timeout,
        "executeTimeoutUnit": execute_timeout_unit,
        "instanceName": instance_name,
        "dataFileInputListReqs": processed_dependencies,
        "dataFileOutputListReqs": [],
        "onlySaveContent": 0,
        "configProperties": config_properties,
        "taskPriority": "1",
        "scheduleRateType": 2,
        "scheduleType": 1,
        "fileCreateType": 1,
        "scheduleCreatedType": "2",
        "scheduleConfigType": "1"
    }

    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def get_configuration_detail(project_id, workspace_id, data_file_id, jwt_token, instance_name, tenant_id, user_id,
                             instance_id, env, workspace_name=None):
    """
    Get file configuration detail
    """
    url = read_url(env=env) + read_api("GET_CONFIGURATION_DETAIL")
    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "x-clickzetta-token": jwt_token,
        "instanceName": instance_name,
        "tenantId": tenant_id,
        "userId": user_id,
        "instanceId": instance_id,
    }
    if workspace_name:
        header["workspaceName"] = workspace_name
    # Ensure header values are strings to avoid serialization issues
    header = {k: str(v) if v is not None else "" for k, v in header.items()}

    json_data = {
        "projectId": project_id,
        "workspaceId": workspace_id,
        "dataFileId": data_file_id
    }

    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def generate_instance_time_list(cron, schedule_start_time, schedule_end_time, jwt_token, instance_name, instance_id,
                                schedule_env, env, workspace_name=None):
    """
    Preview schedule instance times based on cron expression and schedule window.
    """
    url = read_url(env=env) + read_api("GENERATE_INSTANCE_TIME_LIST")
    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "x-clickzetta-token": jwt_token,
        "env": schedule_env,
        "instanceid": instance_id,
        "instancename": instance_name,
    }
    if workspace_name:
        header["workspacename"] = workspace_name
    header = {k: str(v) if v is not None else "" for k, v in header.items()}

    json_data = {
        "cron": cron,
        "scheduleStartTime": schedule_start_time,
        "scheduleEndTime": schedule_end_time,
    }

    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def submit_task(project_id, data_file_id, data_file_version, username, jwt_token, instance_name, env, workspace_name=None):
    """
    Submit file
    """
    url = read_url(env=env) + read_api("SUBMIT")
    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "x-clickzetta-token": jwt_token,
        # "instanceid": read_env_configuration(key="instanceId"),
        "instanceName": instance_name,
    }
    if workspace_name:
        header["workspaceName"] = workspace_name
    commit_message = "【UAT_TEST】提交于：" + datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    json_data = {
        "commitMsg": commit_message,
        "dataFileId": data_file_id,
        "dataFileVersion": data_file_version,
        "projectId": project_id,
        "updatedBy": username
    }
    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def print_curl_request(url: str, headers: dict = None, data=None, json_data=None, method: str = "POST",
                       mask_sensitive: bool = True):
    """
    打印对应 HTTP 请求的 curl 命令字符串。

    :param url: 请求地址
    :param headers: 请求头（dict）
    :param data: form 表单数据（dict 或 str）
    :param json_data: JSON 请求体（dict）
    :param method: HTTP 方法（GET/POST/PUT/DELETE 等）
    :param mask_sensitive: 是否对敏感字段进行脱敏
    """
    headers = headers or {}
    headers_to_log = sanitize_data(headers) if mask_sensitive else headers

    curl_cmd = [f"curl '{url}'", f"-X {method.upper()}"]
    for key, value in headers_to_log.items():
        curl_cmd.append(f"-H '{key}: {value}'")

    if json_data is not None:
        body_to_log = sanitize_data(json_data) if mask_sensitive else json_data
        json_str = json.dumps(body_to_log, ensure_ascii=False)
        json_str = json_str.replace("'", "'\\''")
        curl_cmd.append(f"-d '{json_str}'")
    elif data is not None:
        if isinstance(data, dict):
            data_to_log = sanitize_data(data) if mask_sensitive else data
            data_str = "&".join(f"{key}={value}" for key, value in data_to_log.items())
        else:
            data_str = str(data)
        data_str = data_str.replace("'", "'\\''")
        curl_cmd.append(f"-d '{data_str}'")

    curl_str = " ".join(curl_cmd)
    logger.debug("curl cmd: {}", curl_str)
    return curl_str


def dqc_add(project_id, workspace, object_name, condition, desc,
            param_values, checker_info_str, tag_type, tag_code, defined_sql, column_name, vcluster, timeout,
            trigger_type, trigger_cron, main_scheduler_task_id, level,
            jwt_token, instance_name, user_id, instance_id, account_id, env, workspace_name=None):
    """
    Add DQC rule
    """
    url = read_url(env=env) + read_api("DQC_ADD")

    # url = "https://uat-api.clickzetta.com/clickzetta-portal/user/getCurrentUser"

    # url_get_current = read_url(env=env) + read_api("USER_GET_CURRENT")
    #
    # data = get_user_id(url_get_current, jwt_token, instance_name, env)
    #
    # user_id = data.get("id")
    # account_id = data.get("accountId")
    # instance_id = data.get("instanceId")

    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": jwt_token,
        "userId": user_id,
        "instanceId": instance_id,
        "accountId": account_id,
        "instanceName": instance_name,
        "tenantId": account_id
    }
    if workspace_name:
        header["workspaceName"] = workspace_name

    header = {k: str(v) for k, v in header.items()}

    json_data = {
        "datasourceType": "LakeHouse",
        "name": "rule",
        "workspaceName": workspace,
        "workspaceId": project_id,
        "objectName": object_name,
        "condition": condition,
        "owner": user_id,
        "desc": desc,
        "paramValues": param_values,
        "checkerInfo": checker_info_str,
        "objectType": "TABLE",
        "tagType": tag_type,
        "tagCode": tag_code,
        "definedSql": defined_sql,
        "properties": column_name,
        "vcluster": vcluster,
        "timeout": timeout,
        "triggerType": trigger_type,
        "triggerCron": trigger_cron,
        "mainSchedulerTaskId": main_scheduler_task_id,
        "level": level,
        "triggerConfigProperties": "{}"
    }

    print_curl_request(url, headers=header, json_data=json_data)

    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def schedule_task_list(projectId, taskNameOrTaskId, taskType, pageIndex, pageSize, orderBy, orderByFields,
                       groupId, jwt_token, instance_name, instance_id, user_id, account_id, env, workspace_name=None):
    """
    list scheduled tasks
    """
    url = read_url(env=env) + read_api("SCHEDULE_TASK_LIST")

    # url_get_current = read_url(env=env) + read_api("USER_GET_CURRENT")
    #
    # data = get_user_id(url_get_current, jwt_token, instance_name, env)
    #
    # user_id = data.get("id")
    # account_id = data.get("accountId")
    # instance_id = data.get("instanceId")

    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": jwt_token,
        "userId": user_id,
        "instanceId": instance_id,
        "accountId": account_id,
        "instanceName": instance_name,
        "tenantId": account_id
    }
    if workspace_name:
        header["workspaceName"] = workspace_name

    header = {k: str(v) for k, v in header.items()}

    json_data = {
        "taskType": taskType,
        "taskNameLike": taskNameOrTaskId,
        "projectId": projectId,
        "pageIndex": pageIndex,
        "pageSize": pageSize,
        "scheduleType": 1,
        "orderBy": orderBy,
        "orderByFields": orderByFields,
        "groupId": groupId
    }

    print_curl_request(url, headers=header, json_data=json_data)

    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def instance_list(projectId, taskNameOrTaskId, taskType, instanceType, scheduleTaskId, pageIndex, pageSize, orderBy,
                  orderByFields,
                  queryStartPlanTime, queryEndPlanTime, instanceStatusList, groupId, jwt_token, instance_name,
                  instance_id, user_id, account_id, env, workspace_name=None):
    """
    list tasks instances
    """
    url = read_url(env=env) + read_api("TASK_INST_LIST")

    # url_get_current = read_url(env=env) + read_api("USER_GET_CURRENT")
    #
    # data = get_user_id(url_get_current, jwt_token, instance_name, env)
    #
    # user_id = data.get("id")
    # account_id = data.get("accountId")
    # instance_id = data.get("instanceId")

    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": jwt_token,
        "userId": user_id,
        "instanceId": instance_id,
        "accountId": account_id,
        "instanceName": instance_name,
        "tenantId": account_id,
        "env": 'prod'
    }
    if workspace_name:
        header["workspaceName"] = workspace_name

    header = {k: str(v) for k, v in header.items()}

    json_data = {
        "cycleTaskType": taskType,
        "taskNameLike": taskNameOrTaskId,
        "scheduleTaskId": scheduleTaskId,
        "projectId": projectId,
        "pageIndex": pageIndex,
        "pageSize": pageSize,
        "instanceType": instanceType,
        "orderByFields": orderByFields,
        "orderBy": orderBy,
        "queryStartPlanTime": queryStartPlanTime,
        "queryEndPlanTime": queryEndPlanTime,
        "instanceStatusList": instanceStatusList,
        "groupId": groupId
    }

    print_curl_request(url, headers=header, json_data=json_data)

    response = RequestUtils().post(
        url=url,
        headers=header,
        json=json_data,
    ).text
    return response


def task_relation(projectId, scheduleTaskId, parentLevel, childLevel, jwt_token, instance_name, env, workspace_name=None):
    """
    list tasks relations
    """
    url = read_url(env=env) + read_api("SCHEDULE_TASK_RELATION")

    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": jwt_token,
        "instanceName": instance_name
    }
    if workspace_name:
        header["workspaceName"] = workspace_name

    header = {k: str(v) for k, v in header.items()}

    json_data = {

        "scheduleTaskId": scheduleTaskId,
        "projectId": projectId,
        "parentLevel": parentLevel,
        "childLevel": childLevel
    }

    print_curl_request(url, headers=header, json_data=json_data)

    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def instance_relation(projectId, taskInstanceId, parentLevel, childLevel, jwt_token, instance_name, env, workspace_name=None):
    """
    list tasks instances relations
    """
    url = read_url(env=env) + read_api("SCHEDULE_INSTANCE_RELATION")

    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": jwt_token,
        "instanceName": instance_name
    }
    if workspace_name:
        header["workspaceName"] = workspace_name

    header = {k: str(v) for k, v in header.items()}

    json_data = {
        "taskInstanceId": taskInstanceId,
        "projectId": projectId,
        "parentLevel": parentLevel,
        "childLevel": childLevel
    }

    print_curl_request(url, headers=header, json_data=json_data)

    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def list_attempt_records(projectId, taskInstanceId, pageIndex, pageSize, jwt_token, instance_name, env, workspace_name=None):
    """
    list the attempt records for specified task run instance
    """
    url = read_url(env=env) + read_api("EXECUTE_LOGS")

    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": jwt_token,
        "instanceName": instance_name
    }
    if workspace_name:
        header["workspaceName"] = workspace_name

    header = {k: str(v) for k, v in header.items()}

    json_data = {
        "taskInstanceId": taskInstanceId,
        "projectId": projectId,
        "pageIndex": pageIndex,
        "pageSize": pageSize
    }

    print_curl_request(url, headers=header, json_data=json_data)

    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def get_attempt_log_content(taskInstanceId, executeLogId, queryLogActionCode, offset, jwt_token, instance_name, env, workspace_name=None):
    """
    get attempt log content for a specific task run attempt
    """
    url = read_url(env=env) + read_api("QUERY_TEMP_LOG_RESULTS")

    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": jwt_token,
        "instanceName": instance_name
    }
    if workspace_name:
        header["workspaceName"] = workspace_name

    header = {k: str(v) for k, v in header.items()}

    json_data = {
        "queryLogActionCode": queryLogActionCode,
        "tempInstanceId": taskInstanceId,
        "executeLogId": executeLogId,
        "offset": offset
    }

    print_curl_request(url, headers=header, json_data=json_data)

    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def list_backfill_tasks(projectId, taskNameLike, runStatus, submitter, queryPlanTimeLeft, queryPlanTimeRight, pageIndex,
                        pageSize,
                        jwt_token, instance_name, user_id, instance_id, account_id, workspace_name, env):
    """
    list backfill tasks
    """
    url = read_url(env=env) + read_api("COMPLEMENT_LIST")

    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": jwt_token,
        "userId": user_id,
        "instanceId": instance_id,
        "accountId": account_id,
        "instanceName": instance_name,
        "workspaceName": workspace_name,
        "tenantId": account_id,
        "env": 'prod'
    }

    header = {k: str(v) for k, v in header.items()}

    json_data = {
        "taskNameLike": taskNameLike,
        "projectId": projectId,
        "pageIndex": pageIndex,
        "pageSize": pageSize
    }
    if runStatus is not None:
        json_data['runStatus'] = runStatus

    if submitter is not None:
        json_data['complementUserName'] = submitter

    if queryPlanTimeLeft is not None and queryPlanTimeRight is not None:
        json_data['bizStartDate'] = queryPlanTimeLeft
        json_data['bizEndDate'] = queryPlanTimeRight

    print_curl_request(url, headers=header, json_data=json_data)

    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def get_backfill_task_detail(backFillTaskId, jwt_token, instance_name, user_id, instance_id, account_id, env, workspace_name=None):
    """
    get backfill task detail
    """
    url = read_url(env=env) + read_api("COMPLEMENT_GET_DETAIL")

    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": jwt_token,
        "userId": user_id,
        "instanceId": instance_id,
        "accountId": account_id,
        "instanceName": instance_name,
        "tenantId": account_id,
        "env": 'prod'
    }
    if workspace_name:
        header["workspaceName"] = workspace_name

    header = {k: str(v) for k, v in header.items()}

    json_data = {
        "complementTaskId": backFillTaskId
    }

    print_curl_request(url, headers=header, json_data=json_data)

    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def list_backfill_instances(backFillTaskId, taskNameLike, instanceStatusList, pageIndex, pageSize, jwt_token,
                            instance_name, user_id, instance_id, account_id, env, workspace_name=None):
    """
    list backfill task instances
    """
    url = read_url(env=env) + read_api("COMPLEMENT_PAGELIST")

    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": jwt_token,
        "userId": user_id,
        "instanceId": instance_id,
        "accountId": account_id,
        "instanceName": instance_name,
        "tenantId": account_id,
        "env": 'prod'
    }
    if workspace_name:
        header["workspaceName"] = workspace_name

    header = {k: str(v) for k, v in header.items()}

    json_data = {
        "pageSize": pageSize,
        "pageIndex": pageIndex,
        "complementTaskId": backFillTaskId,
        "orderByFields": "plan_trigger_time",
        "orderBy": "desc"
    }
    if instanceStatusList is not None:
        json_data['instanceStatusList'] = instanceStatusList
    if taskNameLike is not None:
        json_data['taskName'] = taskNameLike
    print_curl_request(url, headers=header, json_data=json_data)

    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def list_user_workspaces(page_index, page_size, jwt_token, instance_name, instance_id, user_id, tenant_id, env, workspace_name):
    """
    List user workspaces in Clickzetta Studio
    """
    # Get current user info to obtain tenant_id, user_id and instance_id
    # url_get_current = read_url(env=env) + read_api("USER_GET_CURRENT")
    # user_data = get_user_id(url_get_current, jwt_token, instance_name, env)

    # if not user_data:
    #     return json.dumps({
    #         "code": "500",
    #         "message": "Failed to get current user information"
    #     })

    # tenant_id = user_data.get("accountId")
    # user_id = user_data.get("id")
    # instance_id = user_data.get("instanceId")
    url = read_url(env=env) + read_api("LIST_WORK_SPACES_BY_USER")


    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "x-clickzetta-token": jwt_token,
        "instanceName": instance_name,
        "instanceId": str(instance_id),
        "tenantId": str(tenant_id),
        "userId": str(user_id),
        "env": "prod"
    }
    if workspace_name:
        header["workspaceName"] = workspace_name

    json_data = {
        "forWrite": True,
        "pageIndex": page_index,
        "pageSize": page_size,
        "tenantId": tenant_id,
        "userId": user_id,
        "workspaceName": workspace_name
    }

    # Print curl command for debugging
    curl_headers = ' '.join([f"-H '{k}: {v}'" for k, v in header.items()])
    curl_data = json.dumps(json_data, ensure_ascii=False)
    curl_command = f"curl -X POST '{url}' {curl_headers} -d '{curl_data}'"

    print_curl_request(url, headers=header, json_data=json_data)

    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def list_project_files(projectId, fileTypes, ownerEnNames, status, pageIndex, pageSize, name, orderType,
                       orderBy, fileIdForRelation, folderIds, groupId, hasAlert, token):
    """
    根据项目空间查询数据文件列表
    """
    url = read_url() + read_api("LIST_PROJECT_FILES")
    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "x-clickzetta-token": token,
        "workspacename": read_env_configuration(key="workSpaceName"),
        "instanceid": read_env_configuration(key="instanceId"),
        "instanceName": read_env_configuration(key="instanceName"),
        "userId": read_env_configuration(key="userId"),
        "tenantId": read_env_configuration(key="tenantId"),
    }
    json = {
        "fileTypes": fileTypes,
        "ownerEnNames": ownerEnNames,
        "projectId": projectId,
        "status": status,
        "pageIndex": pageIndex,
        "pageSize": pageSize,
        "name": name,
        "orderType": orderType,
        "orderBy": orderBy,
        "fileIdForRelation": fileIdForRelation,
        "folderIds": folderIds,
        "groupId": groupId,
        "hasAlert": hasAlert
    }

    response = RequestUtils().post(url=url, headers=header, json=json).text
    return response


def get_task_statistics(projectId, taskNameLike, taskOwner, fileType,fileFlowStatus,
                        jwt_token, instance_name, user_id,  instance_id, account_id, env, workspace_name=None):
    """
    list backfill tasks
    """
    url = read_url(env=env) + read_api("MCP_TASK_STATISTICS")

    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": jwt_token,
        "userId": user_id,
        "instanceId": instance_id,
        "accountId": account_id,
        "instanceName": instance_name,
        "tenantId": account_id,
        "env": 'prod'
    }
    if workspace_name:
        header["workspaceName"] = workspace_name

    header = {k: str(v) for k, v in header.items()}


    json_data = {
        "projectId": projectId,
        "env" : "prod"
    }
    if taskNameLike is not None:
        json_data['cycleTaskName'] = taskNameLike

    if taskOwner is not None:
        json_data['taskOwnerEn'] = taskOwner

    if fileType is not None:
        json_data['fileType'] = fileType

    if fileFlowStatus is not None:
        json_data['fileFlowStatus'] = fileFlowStatus

    print_curl_request(url, headers=header, json_data=json_data)

    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def get_instance_statistics(projectId, scheduleTaskName, taskType, instanceType,queryStartPlanTime, queryEndPlanTime,
                  instanceStatusList, groupId, taskOwnerId, executorUserId, vcCode,
                  jwt_token, instance_name,instance_id, user_id, account_id, env, workspace_name=None):
    """
    list tasks instances
    """
    url = read_url(env=env) + read_api("MCP_INSTANCE_STATISTICS")

    # url_get_current = read_url(env=env) + read_api("USER_GET_CURRENT")
    #
    # data = get_user_id(url_get_current, jwt_token, instance_name, env)
    #
    # user_id = data.get("id")
    # account_id = data.get("accountId")
    # instance_id = data.get("instanceId")

    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": jwt_token,
        "userId": user_id,
        "instanceId": instance_id,
        "accountId": account_id,
        "instanceName": instance_name,
        "tenantId": account_id,
        "env": 'prod'
    }
    if workspace_name:
        header["workspaceName"] = workspace_name

    header = {k: str(v) for k, v in header.items()}


    json_data = {
        "cycleTaskType": taskType,
        "scheduleTaskName": scheduleTaskName,
        "projectId": projectId,
        "instanceType": instanceType,
        "cycleTaskType": taskType,
        "queryStartPlanTime": queryStartPlanTime,
        "queryEndPlanTime": queryEndPlanTime,
        "instanceStatusList": instanceStatusList,
        "groupId": groupId
    }
    if taskOwnerId is not None:
        json_data['taskOwnerId'] = taskOwnerId

    if executorUserId is not None:
        json_data['executorUserId'] = executorUserId

    if vcCode is not None:
        json_data['vcCodes'] = [vcCode]

    print_curl_request(url, headers=header, json_data=json_data)

    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def save_cdc_task(project_id, data_file_id, pipeline_type, save_mode, sync_mode, 
                  source_datasource_list, sync_object_list, target_datasource,
                  jwt_token, instance_name, env, workspace_name=None):
    """
    Save multi-table real-time CDC task configuration
    
    Args:
        project_id: Project ID
        data_file_id: Task file ID
        pipeline_type: Pipeline type for multi-table real-time sync
            - 1: Multi-table mirror sync (when user specifies specific tables)
            - 2: Multi-table merge
            - 3: Whole database mirror (when user specifies database without tables)
        save_mode: Save mode for current operation on saved data
            - 1: Overwrite - Replace existing configuration
            - 2: Append - Add to existing configuration
            - 3: Modify - Update existing configuration
        sync_mode: Sync mode (1 for full+incremental, 2 for incremental only)
        source_datasource_list: List of source datasources with id and type
        sync_object_list: List of sync objects (schemas/tables)
        target_datasource: Target datasource with id and type
        jwt_token: JWT token
        instance_name: Instance name
        env: Environment
        workspace_name: Workspace name
    
    Returns:
        Response text
    """
    url = read_url(env=env) + read_api("MCP_SAVE_CDC_TASK")
    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "x-clickzetta-token": jwt_token,
        "instanceName": instance_name,
    }
    if workspace_name:
        header["workspaceName"] = workspace_name
    
    json_data = {
        "dataFileId": data_file_id,
        "pipelineType": pipeline_type,
        "projectId": project_id,
        "saveMode": save_mode,
        "sourceDatasourceList": source_datasource_list,
        "syncMode": sync_mode,
        "syncObjectList": sync_object_list,
        "targetDatasource": target_datasource
    }
    
    print_curl_request(url, headers=header, json_data=json_data)
    
    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def offline_task(schedule_task_id, update_by, workspace, jwt_token, instance_name, instance_id, env):
    """Offline a periodic schedule task (without downstream)."""
    url = read_url(env=env) + read_api("DELETE_TASK")

    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": jwt_token,
        "instanceName": instance_name,
        "instanceId": instance_id,
    }
    header = {k: str(v) for k, v in header.items()}

    json_data = {
        "scheduleTaskId": schedule_task_id,
        "updateBy": update_by,
        "workspace": workspace,
    }

    print_curl_request(url, headers=header, json_data=json_data)
    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def offline_task_with_downstream(schedule_task_id, tasks, update_by, workspace, jwt_token, instance_name, instance_id, env):
    """Offline a periodic schedule task including downstream tasks."""
    url = read_url(env=env) + read_api("OFFLINE_TASK_WITH_DOWNSTREAM")

    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": jwt_token,
        "instanceName": instance_name,
        "instanceId": instance_id,
    }
    header = {k: str(v) for k, v in header.items()}

    json_data = {
        "scheduleTaskId": schedule_task_id,
        "tasks": tasks or [],
        "updateBy": update_by,
        "workspace": workspace,
    }

    print_curl_request(url, headers=header, json_data=json_data)
    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def kill_task_instance(project_id, task_instance_id, update_by, workspace, jwt_token, instance_name, instance_id, env):
    """Kill a running task instance."""
    url = read_url(env=env) + read_api("KILL_TASK_INSTANCE")

    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": jwt_token,
        "instanceName": instance_name,
        "instanceId": instance_id,
    }
    header = {k: str(v) for k, v in header.items()}

    json_data = {
        "projectId": project_id,
        "taskInstanceId": task_instance_id,
        "updateBy": update_by,
        "workspace": workspace,
    }

    print_curl_request(url, headers=header, json_data=json_data)
    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def get_all_downstream(schedule_task_id, workspace, jwt_token, instance_name, instance_id, env):
    """Get all downstream task metadata for one schedule task."""
    url = read_url(env=env) + read_api("FLAT_ALL_DOWNSTREAM")

    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": jwt_token,
        "instanceName": instance_name,
        "instanceId": instance_id,
    }
    header = {k: str(v) for k, v in header.items()}

    json_data = {
        "scheduleTaskId": schedule_task_id,
        "workspace": workspace,
    }

    print_curl_request(url, headers=header, json_data=json_data)
    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def check_vcluster_create_permission(workspace, jwt_token, instance_name, instance_id, env):
    """Check CREATE permission on VCLUSTER in current workspace."""
    url = read_url(env=env) + read_api("CHECK_PERMISSION") + "?env=PROD"

    header = {
        "Content-Type": "application/json",
        "env": "prod",
        "instanceName": instance_name,
        "instanceId": instance_id,
        "X-Clickzetta-Token": jwt_token,
    }
    header = {k: str(v) for k, v in header.items()}

    json_data = {
        "entitySubType": "VCLUSTER",
        "workspace": workspace,
        "actions": [{"actions": ["CREATE"], "operate": "OR"}],
    }

    print_curl_request(url, headers=header, json_data=json_data)
    response = RequestUtils().post(url=url, headers=header, json=json_data).text
    return response


def create_complement_job(payload, jwt_token, instance_name, instance_id, env):
    """Create complement(backfill) job for periodic task."""
    url = read_url(env=env) + read_api("COMPLEMENT_ADD")

    header = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "X-Clickzetta-Token": jwt_token,
        "instanceName": instance_name,
        "instanceId": instance_id,
    }
    header = {k: str(v) for k, v in header.items()}

    print_curl_request(url, headers=header, json_data=payload)
    response = RequestUtils().post(url=url, headers=header, json=payload).text
    return response
