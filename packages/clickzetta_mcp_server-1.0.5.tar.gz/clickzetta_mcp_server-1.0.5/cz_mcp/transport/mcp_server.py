"""
Unified MCP Server for Clickzetta Studio

Supports both HTTP and STDIO transport modes:
- HTTP mode: Remote deployment with Bearer token authentication from headers using low-level MCP server
- STDIO mode: Local development with configuration-based authentication
"""
import json
import logging
import time
from typing import Optional

from loguru import logger
from mcp.server import Server, InitializationOptions, NotificationOptions
from mcp.server.fastmcp import FastMCP

from cz_mcp.common.utilities import ResponseBuilder
from cz_mcp.core import MCPServerCore, ToolRegistry, SQLWriteDetector, PermissionException
from cz_mcp.core import StudioConfig
from cz_mcp.core.logger import setup_log
from cz_mcp.core.region_config import (
    get_region_by_alias,
    get_region_by_service_url,
    Region,
    get_region_code_by_cregionid,
)
from cz_mcp.handlers.instance_service import get_instance_by_csp_id, service_csp_list
from cz_mcp.handlers.login_server import get_user_id, get_user_config
from cz_mcp.handlers.workspace_server import get_workspace_by_name
from cz_mcp.studio_config_manager import StudioConfigManager
from cz_mcp.tools import get_all_tools
from cz_mcp.transport.argument_normalizer import create_normalizer_for_tool, ArgumentNormalizationError
from cz_mcp.transport.mcp_registrar import MCPComponentRegistrar
from cz_mcp.utils.log_sanitizer import sanitize_data
from cz_mcp.version import __version__

access_logger = logging.getLogger('access')

setup_log()


class ClickzettaMCPServer:
    """Unified MCP Server supporting both HTTP and STDIO transport modes"""

    def __init__(self, host: str = "0.0.0.0", port: int = 8000, transport_type: str = "http", env: str = None):
        self.host = host
        self.port = port
        self.transport_type = transport_type
        self.env = env
        self.writer_detector = SQLWriteDetector()

        # Core components
        self.server_core: Optional[MCPServerCore] = None
        self.tool_registry: Optional[ToolRegistry] = None
        self.registrar: Optional[MCPComponentRegistrar] = None

        # Configuration based on transport type
        if transport_type == "stdio":
            if not env:
                raise ValueError("Environment must be specified for STDIO transport")
            self.config_manager = StudioConfigManager(env=env, transport_type=transport_type)
        else:
            # HTTP mode: env is optional, defaults to 'dev' if not specified
            self.config_manager = StudioConfigManager(env=env, transport_type=transport_type)

        # Transport-specific components
        if transport_type == "http":
            # HTTP mode: Only low-level MCP server, no FastAPI needed
            logger.info("Initializing low-level MCP for HTTP transport...")
            self.low_level_server = Server("MCP Clickzetta Server")

            self.mcp = FastMCP("MCP Clickzetta Server", host=self.host, port=self.port)
            self.mcp._mcp_server = self.low_level_server

        elif transport_type == "stdio":
            logger.info("Initializing low-level MCP server for STDIO transport")
            # STDIO mode: Pure MCP server without HTTP middleware
            self.low_level_server = Server("MCP Clickzetta Server")

        else:
            raise ValueError(f"Unsupported transport type: {transport_type}")

    async def _update_server_connection(self, auth_input: dict, tool_config_params: dict = None,
                                        connection_info: dict = None, center_region: str = "dev"):
        """Update server connection with authentication and configuration

        Args:
            auth_input: Authentication input (PAT or username/password)
            tool_config_params: Configuration parameters from tool arguments (highest priority)
            connection_info: Connection info from HTTP headers (medium priority)
            center_region: Temporary region for initial authentication (lowest priority)
        """
        try:
            # Initialize and resolve region
            tool_config, connection_info = self._initialize_config_params(
                tool_config_params, connection_info)

            # Get service URL
            service_url, service = self._get_service_url(center_region)

            # Authenticate
            auth_result = await self._authenticate_user(
                auth_input, tool_config.region, service_url, center_region)

            # Load user configuration
            user_config_dict, only_use_user_config = await self._load_user_config(
                auth_result, tool_config, center_region)

            if only_use_user_config and not user_config_dict.get("cregionId"):
                raise PermissionException(
                    f"No user config found from center-region {center_region}! Please set up your user config first!")

            # Resolve instance info
            instance_info = await self._resolve_instance_info(
                auth_result, tool_config, user_config_dict, only_use_user_config, center_region)

            # Resolve workspace, vcluster, schema
            workspace_id, project_id = await self._resolve_workspace_config(
                tool_config, connection_info, user_config_dict,
                only_use_user_config, auth_result, instance_info)

            logger.info(f"Final configuration: region={tool_config.region}, workspace={tool_config.workspace}, "
                        f"vcluster={tool_config.vcluster}, schema={tool_config.schema}")

            # Create and apply configuration
            connection_config = StudioConfig(
                token=auth_result['jwt'],
                instance=instance_info['instance_name'],
                instance_id=instance_info['instance_id'],
                service=service,
                workspace=tool_config.workspace,
                workspace_id=workspace_id,
                vcluster=tool_config.vcluster,
                schema=tool_config.schema,
                env=tool_config.region,
                project_id=project_id,
                tenant_id=auth_result['tenant_id'],
                user_id=auth_result['user_id'],
                username=auth_result['user_name'],
                base_url=service_url,
                region_code=instance_info['region_code'],
                region_id=instance_info['region_id'],
                expire_time=auth_result['expire_time']
            )

            # Initialize or update server core
            if not self.server_core.is_initialized():
                logger.info("Initializing server core with new connection config")
                self.server_core.initialize(connection_config)
            else:
                logger.info("Updating existing server core connection config")
                self.server_core.update_connection_config(connection_config)

        except Exception as e:
            logger.opt(exception=True).error("Failed to update server connection: {}", e)
            raise

    def _initialize_config_params(self, tool_config_params: dict = None,
                                  connection_info: dict = None) -> tuple['ToolConfig', dict]:
        """Initialize and resolve configuration parameters

        Args:
            tool_config_params: Configuration from tool arguments (highest priority)
            connection_info: Configuration from HTTP headers (medium priority)

        Returns:
            tuple: (tool_config, connection_info)
        """
        tool_config_params = tool_config_params or {}
        tool_config: ToolConfig = ToolConfig.from_dict(tool_config_params)
        connection_info = connection_info or {}

        if tool_config.has_any():
            logger.info(f"Tool config params: {sanitize_data(tool_config_params)}")
        if connection_info:
            logger.info(f"Connection info from headers: {sanitize_data(connection_info)}")

        # Resolve region with priority: tool params > connection headers
        if not tool_config.has_region():
            region = get_region_by_alias(connection_info.get('region'))
            tool_config.region = region
            logger.info(f"Resolved region from connection info: {region}")

        return tool_config, connection_info

    def _get_service_url(self, temp_region: str) -> tuple[str, str]:
        """Get service URL for the region

        Args:
            temp_region: Temporary region identifier

        Returns:
            tuple: (service_url, service)
        """
        from cz_mcp.utils.config_utils import read_url
        service_url = read_url(env=temp_region)
        service = service_url.removeprefix('https://').removeprefix('http://')
        logger.info(f"[_get_service_url] Get Service URL: {service_url}, service: {service}, center region: {temp_region}")
        return service_url, service

    async def _authenticate_user(self, auth_input: dict, region: str, service_url: str, temp_region: str) -> dict:
        """Authenticate user and get user information

        Args:
            auth_input: Authentication input (PAT or username/password)
            region: Region identifier
            service_url: Service URL
            temp_region: temp region

        Returns:
            dict: Authentication result containing jwt, user_id, user_name, tenant_id, expire_time
        """
        # UAT region requires specific instance
        if not region:
            region = temp_region
        if region == "uat":
            temp_instance_name = "jnsxwfyr"
        elif region == "dev":
            temp_instance_name = "tmwmzxzs"
        else:
            temp_instance_name = None
        if temp_instance_name:
            logger.info(f"Using instance for testing: {temp_instance_name}")

        auth_type = (auth_input or {}).get("type")
        if auth_type == "password":
            username = auth_input.get("username")
            password = auth_input.get("password")
            instance_name = auth_input.get("instance_name")
            if not (username and password and instance_name):
                raise ValueError("username/password authentication requires username, password and instance_name")
            logger.info(f"Authenticating with username '{username}' for region={region}, instance={instance_name}")
            login_data = await self.config_manager.login(
                instance_name=instance_name,
                base_url=service_url,
                username=username,
                password=password,
            )
            auth_preview = f"user={username}"
        elif auth_type == "pat":
            pat = auth_input.get("pat")
            logger.info(f"Authenticating with PAT {pat[:4] if pat else None}**** for region={region}...")
            login_data = await self.config_manager.login(
                pat=pat,
                instance_name=temp_instance_name,
                base_url=service_url,
            )
            auth_preview = f"pat={pat[:4] if pat else None}****"
        else:
            raise ValueError("Unsupported authentication input")

        jwt = login_data['token']
        user_id = login_data.get('user_id', 0)
        expire_time = login_data.get('expire_time', 0)
        logger.info(f"Authentication successful: user_id={user_id}, token_expiry={expire_time}")

        # Get user details (using temp_region as env parameter)
        user_json = get_user_id(service_url, jwt, env=region)
        if not user_json or not user_json.get('name') or not user_json.get('accountId'):
            raise RuntimeError(
                f"Failed to authenticate with user_id={user_id}, region={region}, auth={auth_preview}")

        user_name = user_json.get('name')
        tenant_id = int(user_json.get('accountId'))
        logger.info(f"User info retrieved: username={user_name}, tenant_id={tenant_id}")

        return {
            'jwt': jwt,
            'user_id': user_id,
            'user_name': user_name,
            'tenant_id': tenant_id,
            'expire_time': expire_time
        }

    @staticmethod
    async def _load_user_config(auth_result: dict, tool_config: 'ToolConfig',
                                temp_region: str) -> tuple[dict, bool]:
        """Load user configuration from server

        Args:
            auth_result: Authentication result
            tool_config: Tool configuration
            temp_region: Temporary region identifier

        Returns:
            tuple: (user_config_dict, only_use_user_config)
        """
        user_config_dict = {}
        only_use_user_config = False

        if not tool_config.has_required():
            user_config = get_user_config(
                auth_result['jwt'], auth_result['user_id'],
                auth_result['tenant_id'], temp_region) or {}
            if user_config:
                user_config_dict = json.loads(user_config)
                logger.info(f"User config loaded: {sanitize_data(user_config_dict)}")
                # Use region from user config only if not specified elsewhere
                if not tool_config.has_region():
                    # tool config does not have all params and headers do not specify region
                    only_use_user_config = True
                    region = user_config_dict.get('cregionId')
                    tool_config.region = region
                    logger.info(f"Using region from user config: {region}")
            else:
                logger.warning(f"No user config found from center-region {temp_region}! Please set up your user config first!")

        return user_config_dict, only_use_user_config

    async def _resolve_instance_info(self, auth_result: dict, tool_config: 'ToolConfig',
                                     user_config_dict: dict, only_use_user_config: bool, center_region: str) -> dict:
        """Resolve instance information

        Args:
            auth_result: Authentication result
            tool_config: Tool configuration
            user_config_dict: User configuration dictionary
            only_use_user_config: Whether to use only user config
            center_region: Temporary region identifier

        Returns:
            dict: Instance info containing instance_id, instance_name, region_id, region_code
        """
        if only_use_user_config:
            instance_id = user_config_dict.get('instanceId')
            instance_name = user_config_dict.get('instanceName')
            region_id = user_config_dict.get('regionId')
            region_code = user_config_dict.get('regionCode').upper()
            logger.info(f"Using instance from user config: {tool_config.region} {instance_name} (id={instance_id})")
        else:
            # Get region ID from CSP list
            logger.info(f"Fetching CSP list for center region abort {tool_config.region}: {center_region}")
            csp_list = service_csp_list(auth_result['jwt'], env=center_region)
            region_code = "ALICLOUD" if tool_config.region in ("uat", "dev") else get_region_code_by_cregionid(
                tool_config.region)
            logger.info(f"Region code determined: {region_code}")

            region_id = None
            if csp_list:
                logger.debug(f"CSP list contents: {csp_list}")
                csp_info = next((csp for csp in csp_list if csp.get('code').upper() == region_code), None)

                if csp_info:
                    csp_id = csp_info.get('id')
                    if not csp_id:
                        logger.error(f"CSP info found but missing 'id' field. CSP info: {csp_info}")
                        raise ValueError(f"CSP info for region_code={region_code} is missing 'id' field")
                    logger.info(f"CSP ID resolved from matching CSP: {csp_id} for region_code: {region_code}")
                else:
                    logger.error(f"CSP list is empty for region={tool_config.region}")
                    raise ValueError(f"CSP list is empty for region={tool_config.region}")
            else:
                logger.error(f"No CSP info found for region_code={region_code}, region={tool_config.region}")
                raise ValueError(f"No CSP info available for region={tool_config.region}")

            logger.info(f"Fetching instance info for csp_id={csp_id}, tenant_id={auth_result['tenant_id']}")
            instance_info = get_instance_by_csp_id(
                auth_result['tenant_id'], auth_result['jwt'],
                env=tool_config.region, csp_id=csp_id)

            if not instance_info:
                logger.error(f"No instance info returned for csp_id={csp_id}")
                raise ValueError(f"No instance info found for csp_id={csp_id}")

            logger.debug(f"Instance info retrieved: {instance_info}")
            instance_id = instance_info.get('id')
            instance_name = instance_info.get('name')
            region_id = instance_info.get('regionId')  # Get region_id from instance_info

            if not instance_id or not instance_name:
                logger.error(f"Instance info missing required fields. Info: {instance_info}")
                raise ValueError(f"Instance info is incomplete: id={instance_id}, name={instance_name}")

            logger.info(f"Retrieved instance info: {instance_name} (id={instance_id}, region_id={region_id})")

        return {
            'instance_id': instance_id,
            'instance_name': instance_name,
            'region_id': region_id,
            'region_code': region_code
        }

    async def _resolve_workspace_config(self, tool_config: 'ToolConfig', connection_info: dict,
                                        user_config_dict: dict, only_use_user_config: bool,
                                        auth_result: dict, instance_info: dict) -> tuple[int, str]:
        """Resolve workspace configuration

        Args:
            tool_config: Tool configuration
            connection_info: Connection info from headers
            user_config_dict: User configuration dictionary
            only_use_user_config: Whether to use only user config
            auth_result: Authentication result
            instance_info: Instance information

        Returns:
            tuple: (workspace_id, project_id)
        """
        if only_use_user_config:
            return self._resolve_config_from_user_config(user_config_dict, tool_config)
        else:
            return await self._resolve_config_with_priority(
                tool_config, connection_info, user_config_dict,
                auth_result['user_id'], auth_result['tenant_id'],
                instance_info['instance_name'], instance_info['instance_id'],
                auth_result['jwt'])

    def _resolve_config_from_user_config(self, user_config_dict: dict, tool_config: 'ToolConfig') -> tuple[int, str]:
        """Resolve workspace configuration from user config

        Args:
            user_config_dict: User configuration dictionary
            tool_config: Tool configuration object to update

        Returns:
            tuple: (workspace_id, project_id)
        """
        workspace = user_config_dict.get('workspaceName')
        vcluster = user_config_dict.get('vcName', 'DEFAULT')
        schema = user_config_dict.get('schemaName', 'public')
        workspace_id = user_config_dict.get('workspaceId')
        project_id = user_config_dict.get('projectId')

        if not tool_config.has_workspace():
            tool_config.workspace = workspace
            logger.info(f"Using workspace from user config: {workspace}")
        if not tool_config.has_vcluster():
            tool_config.vcluster = vcluster
            logger.info(f"Using vcluster from user config: {vcluster}")
        if not tool_config.has_schema():
            tool_config.schema = schema
            logger.info(f"Using schema from user config: {schema}")

        return workspace_id, project_id

    async def _resolve_config_with_priority(self, tool_config: 'ToolConfig', connection_info: dict,
                                            user_config_dict: dict, user_id: int, tenant_id: int,
                                            instance_name: str, instance_id: int, jwt: str) -> tuple[int, str]:
        """Resolve configuration with priority: tool params > connection headers > user config > defaults

        Args:
            tool_config: Tool configuration object to update
            connection_info: Connection info from HTTP headers
            user_config_dict: User configuration dictionary
            user_id: User ID
            tenant_id: Tenant ID
            instance_name: Instance name
            instance_id: Instance ID
            jwt: JWT token

        Returns:
            tuple: (workspace_id, project_id)
        """
        is_user_config_same_region = tool_config.region == user_config_dict.get('cregionId')
        is_connection_config_same_region = tool_config.region == connection_info.get('region')

        # Resolve workspace
        if not tool_config.has_workspace():
            workspace = self._get_config_value(
                'workspace', 'workspaceName',
                connection_info, user_config_dict,
                is_connection_config_same_region, is_user_config_same_region,
                None
            )
            tool_config.workspace = workspace

        # Resolve vcluster
        if not tool_config.has_vcluster():
            is_user_config_same_ws = (is_user_config_same_region and
                                      tool_config.workspace == user_config_dict.get('workspaceName'))
            is_connection_config_same_ws = (is_connection_config_same_region and
                                            tool_config.workspace == connection_info.get('workspace'))

            vcluster = self._get_config_value(
                'vcluster', 'vcName',
                connection_info, user_config_dict,
                is_connection_config_same_region and is_connection_config_same_ws,
                is_user_config_same_region and is_user_config_same_ws,
                'DEFAULT'
            )
            tool_config.vcluster = vcluster

        # Resolve schema
        if not tool_config.has_schema():
            is_user_config_same_ws = (is_user_config_same_region and
                                      tool_config.workspace == user_config_dict.get('workspaceName'))
            is_connection_config_same_ws = (is_connection_config_same_region and
                                            tool_config.workspace == connection_info.get('workspace'))
            is_user_config_same_vc = (is_user_config_same_ws and
                                      tool_config.vcluster == user_config_dict.get('vcName'))
            is_connection_config_same_vc = (is_connection_config_same_ws and
                                            tool_config.vcluster == connection_info.get('vcluster'))

            schema = self._get_config_value(
                'schema', 'schemaName',
                connection_info, user_config_dict,
                is_connection_config_same_region and is_connection_config_same_ws and is_connection_config_same_vc,
                is_user_config_same_region and is_user_config_same_ws and is_user_config_same_vc,
                'public'
            )
            tool_config.schema = schema

        # Get workspace details
        workspace_info = get_workspace_by_name(user_id, tenant_id, instance_name, tool_config.workspace,
                                               instance_id, jwt, tool_config.region)
        workspace_id = int(workspace_info["workspaceId"])
        project_id = workspace_info["projectId"]
        logger.info(f"[resolve_config_with_priority] Workspace info retrieved: workspace_id={workspace_id}, project_id={project_id}")

        return workspace_id, project_id

    def _get_config_value(self, connection_key: str, user_config_key: str,
                          connection_info: dict, user_config_dict: dict,
                          use_header: bool, use_user_config: bool,
                          default_value: Optional[str]) -> Optional[str]:
        """Get configuration value with priority: connection > user_config > default

        Args:
            connection_key: Key in connection_info dict
            user_config_key: Key in user_config_dict
            connection_info: Connection info dictionary
            user_config_dict: User config dictionary
            use_header: Whether to use connection info (must match region/workspace/vcluster)
            use_user_config: Whether to use user config (must match region/workspace/vcluster)
            default_value: Default value if nothing found

        Returns:
            str: The resolved configuration value
        """
        if use_header and connection_info.get(connection_key):
            value = connection_info.get(connection_key)
            logger.info(f"Using {connection_key} from connection Header config: {value}")
            return value
        elif use_user_config and user_config_dict.get(user_config_key):
            value = user_config_dict.get(user_config_key)
            logger.info(f"Using {connection_key} from user config: {value}")
            return value
        else:
            logger.info(f"Using {connection_key} from default config: {default_value}")
            return default_value

    async def initialize(self):
        """Initialize server components based on transport type"""
        try:
            logger.info(f"Initializing MCP Server (transport: {self.transport_type}, env: {self.env})...")

            # Initialize server core
            self.server_core = MCPServerCore()

            # Initialize tool registry
            self.tool_registry = ToolRegistry()

            # Create MCP component registrar
            self.registrar = MCPComponentRegistrar(self.server_core, self.tool_registry)

            # Use lazy connection initialization for both HTTP and STDIO.
            logger.info(f"{self.transport_type.upper()} mode: Server core will be initialized and updated per request")

            # Register all available tools
            all_tools = get_all_tools()
            self.tool_registry.register_tools(all_tools)

            # Register MCP components based on transport type
            await self._register_mcp_components()

            logger.info("MCP Server initialization completed")

        except Exception as e:
            logger.opt(exception=True).error("Failed to initialize MCP Server: {}", e)
            raise

    async def _register_mcp_components(self):
        """Register MCP components based on transport type"""
        try:
            logger.info("Registering MCP components...")

            if self.transport_type in ("http", "stdio"):
                # Unified registration with lazy loading for HTTP/STDIO
                await self._register_http_handlers()

            logger.info("✅ MCP components registration completed")

        except Exception as e:
            logger.opt(exception=True).error("Failed to register MCP components: {}", e)
            raise

    async def _register_http_handlers(self):
        """Register HTTP handlers with lazy loading support"""
        try:
            logger.info("Registering HTTP handlers with lazy loading...")

            # Get allowed tools
            allowed_tools = self.tool_registry.get_allowed_tools()
            tool_handlers = {tool.name: tool.handler for tool in allowed_tools}

            # Create normalizers for tools that need them
            tool_normalizers = {}
            for tool in allowed_tools:
                normalizer = create_normalizer_for_tool(tool)
                if normalizer:
                    tool_normalizers[tool.name] = normalizer
                    logger.debug(f"Created normalizer for tool: {tool.name}")

            @self.low_level_server.list_tools()
            async def handle_list_tools():
                return self.tool_registry.get_mcp_tool_list(allowed_tools)

            @self.low_level_server.call_tool()
            async def handle_call_tool(name: str, arguments: dict = None):
                """Handle tool execution with authentication and normalization"""

                def normalize_arguments(tool_name: str, args: dict) -> dict:
                    """Normalize tool arguments if normalizer exists"""
                    if tool_name not in tool_normalizers:
                        return args
                    try:
                        logger.debug(f"Normalizing arguments for tool: {tool_name}")
                        normalized = tool_normalizers[tool_name].normalize(args)
                        logger.debug(f"Arguments normalized successfully")
                        return normalized
                    except ArgumentNormalizationError as e:
                        logger.warning(f"Argument normalization failed for {tool_name}: {e.message}")
                        raise

                def infer_region_from_host(host: str, studio_region: str = None) -> str:
                    """Infer region from host header"""
                    # Fallback to studio region if no central region specified
                    if studio_region:
                        logger.info(f"Using studio region as fallback: {studio_region}")
                        return studio_region

                    if host.startswith("uat-"):
                        env = "uat"
                    elif host.startswith('0.0.0.0') or host.startswith('localhost') or host.startswith('dev-'):
                        env = "dev"
                    elif host.endswith('singdata.com'):
                        env = Region.AP_SOURCE_1_ALICLOUD.value
                    elif host.endswith('clickzetta.com'):
                        env = Region.CN_SHANGHAI_ALICLOUD.value
                    else:
                        env = "dev"
                    logger.info(f"Infer region from host: {host} -> {env}")
                    return env

                def extract_auth(headers: dict, query_params: dict) -> dict:
                    """Extract authentication input from headers or query params."""
                    # First try to get token from headers
                    if 'x-lakehouse-token' in headers:
                        auth_header = headers['x-lakehouse-token']
                        if auth_header.startswith('Bearer '):
                            return {"type": "pat", "pat": auth_header.split(' ')[1]}
                        if auth_header.strip():
                            return {"type": "pat", "pat": auth_header.strip()}

                    # Try to get token from query params
                    token = query_params.get('key')
                    if token:
                        return {"type": "pat", "pat": token}

                    # If no token, try username/password login parameters
                    username = headers.get('x-lakehouse-username')
                    password = headers.get('x-lakehouse-password')

                    if username and password:
                        # Get instance name from headers
                        instance_name = headers.get('x-lakehouse-instance')
                        if not instance_name:
                            raise ValueError("x-lakehouse-instance header is required when using username/password authentication")

                        return {
                            "type": "password",
                            "username": username,
                            "password": password,
                            "instance_name": instance_name,
                        }

                    raise ValueError(f"Login failed! token not found in headers or query params, and username/password login failed or not attempted")

                start_time = time.time()
                client_ip = "unknown"
                user_agent = "unknown"

                try:
                    logger.info(f"Tool call received: {name}")
                    arguments = arguments or {}

                    # Log access information
                    ctx = self.low_level_server.request_context
                    if ctx and ctx.request:
                        client_ip = ctx.request.client.host if ctx.request.client else "unknown"
                        user_agent = ctx.request.headers.get("user-agent", "unknown")

                    # Check if utility tool (no auth required)
                    tool_metadata = self.tool_registry.tool_map.get(name)
                    is_utility_tool = tool_metadata and "utility" in tool_metadata.tags

                    if is_utility_tool:
                        logger.info(f"Executing utility tool '{name}' without authentication")
                        arguments = normalize_arguments(name, arguments)
                        handler = tool_handlers.get(name)
                        if not handler:
                            logger.error(f"Unknown utility tool requested: {name}")
                            return ResponseBuilder.create_text_response(f"Unknown utility tool: {name}")
                        result = await handler(arguments, None)

                        # Log access
                        elapsed = time.time() - start_time
                        access_logger.info(f"{client_ip} - \"{name}\" utility - 200 {elapsed:.3f}s \"{user_agent}\"")
                        return result

                    # Non-utility tools require authentication
                    auth_input = None
                    connection_info = {}
                    center_region = None

                    ctx = self.low_level_server.request_context
                    is_http_request = bool(ctx and ctx.request)
                    if is_http_request:
                        headers = ctx.request.headers
                        logger.debug(f"Request headers: {sanitize_data(dict(headers))}")

                        # Extract and validate authentication
                        auth_input = extract_auth(headers, ctx.request.query_params)
                        if not auth_input:
                            logger.error(f"Request auth not found: {name}")
                            return ResponseBuilder.create_text_response(
                                "No authentication found! "
                                "Please provide either:\n"
                                "1. x-lakehouse-token header (Bearer token) or key query parameter, OR\n"
                                "2. x-lakehouse-username, x-lakehouse-password, and x-lakehouse-instance headers")

                        # Extract connection info from headers
                        user_config_region = headers.get("x-lakehouse-region")
                        service_header = headers.get("x-lakehouse-service")
                        center_region = headers.get("x-lakehouse-central-region")

                        if user_config_region:
                            user_config_region = get_region_by_alias(user_config_region)
                        elif service_header:
                            user_config_region = get_region_by_service_url(service_header)
                            if user_config_region:
                                logger.info(f"Resolved region from x-lakehouse-service '{service_header}': {user_config_region}")

                        if user_config_region:
                            connection_info["region"] = user_config_region

                        if center_region:
                            center_region = get_region_by_alias(center_region)
                        elif user_config_region:
                            center_region = user_config_region
                        elif service_header:
                            center_region = get_region_by_service_url(service_header)

                        if not center_region:
                            center_region = infer_region_from_host(headers.get('host', ''), user_config_region)
                        logger.info(f"Using central region: {center_region}")

                        if headers.get("x-lakehouse-workspace"):
                            connection_info["workspace"] = headers.get("x-lakehouse-workspace")
                        if headers.get("x-lakehouse-vcluster"):
                            connection_info["vcluster"] = headers.get("x-lakehouse-vcluster")
                        if headers.get("x-lakehouse-schema"):
                            connection_info["schema"] = headers.get("x-lakehouse-schema")
                        logger.info(f"Connection info from headers: workspace={connection_info.get('workspace')}, "
                                    f"region={user_config_region}, service={service_header}")
                    else:
                        config = self.config_manager.config
                        auth_defaults = getattr(self.config_manager, "_auth_defaults", {}) or {}
                        auth_mode = auth_defaults.get("auth_mode")
                        pat = auth_defaults.get("pat_token")
                        username = auth_defaults.get("username")
                        password = auth_defaults.get("password")
                        instance_name = config.instance if config else None

                        if auth_mode == "password" and username and password and instance_name:
                            auth_input = {
                                "type": "password",
                                "username": username,
                                "password": password,
                                "instance_name": instance_name,
                            }
                        elif auth_mode == "pat" and pat:
                            auth_input = {"type": "pat", "pat": pat}
                        elif pat:
                            auth_input = {"type": "pat", "pat": pat}
                        elif username and password and instance_name:
                            auth_input = {
                                "type": "password",
                                "username": username,
                                "password": password,
                                "instance_name": instance_name,
                            }

                        if not auth_input:
                            raise ValueError("No authentication found for stdio mode. "
                                             "Please provide x-Lakehouse-Token or username/password.")

                        region = None
                        if config and config.env:
                            region = get_region_by_alias(config.env, default=config.env)
                        if region:
                            connection_info["region"] = region
                        if config and config.workspace:
                            connection_info["workspace"] = config.workspace
                        if config and config.vcluster:
                            connection_info["vcluster"] = config.vcluster
                        if config and config.schema:
                            connection_info["schema"] = config.schema

                        center_region = region
                        if not center_region and config and config.base_url:
                            center_region = get_region_by_service_url(config.base_url)
                        if not center_region:
                            center_region = self.env or "dev"
                        logger.info(f"Using stdio connection info: workspace={connection_info.get('workspace')}, "
                                    f"region={connection_info.get('region')}, center_region={center_region}")

                    # Extract config params from tool arguments (highest priority)
                    tool_config_params = {}
                    for param in ["region", "workspace", "vcluster", "schema"]:
                        if param in arguments and arguments[param]:
                            value = arguments.get(param)
                            tool_config_params[param] = get_region_by_alias(value) if param == "region" else value

                    if tool_config_params:
                        logger.info(f"Config params from tool arguments: {tool_config_params}")

                    # Update server connection
                    try:
                        await self._update_server_connection(auth_input, tool_config_params, connection_info, center_region)
                    except Exception as e:
                        logger.opt(exception=True).error("Failed to update server connection: {}", e)
                        return ResponseBuilder.create_error_response(e,
                                                                     "Authentication failed or invalid configuration!")

                    # Normalize and execute tool
                    arguments = normalize_arguments(name, arguments)
                    handler = tool_handlers.get(name)
                    if not handler:
                        logger.error(f"Unknown tool requested: {name}")
                        return ResponseBuilder.create_yaml_json_response([{
                            "error": f"Unknown tool: {name}"
                        }])

                    logger.info(f"Executing tool '{name}'")
                    try:
                        result = await handler(arguments, self.server_core.connection_config, db=self.server_core.db,
                                               writer_detector=self.writer_detector)
                    except Exception as e:
                        logger.opt(exception=True).error("Error during tool execution: {}", e)
                        return ResponseBuilder.create_error_response(e,
                                                                     f"Error executing tool {name}: {str(e)}")

                    # Log successful access with connection config info
                    elapsed = time.time() - start_time
                    config = self.server_core.connection_config
                    username = config.username if config and config.username else 'unknown'
                    user_id = config.user_id if config and config.user_id else 0
                    tenant_id = config.tenant_id if config and config.tenant_id else 0
                    workspace = config.workspace if config and config.workspace else 'unknown'
                    instance = config.instance if config and config.instance else 'unknown'
                    access_logger.info(
                        f"{client_ip} - user_id:{user_id}|tenant_id:{tenant_id}|user:{username}|ws:{workspace}|"
                        f"instance:{instance} - \"{name}\" - 200 {elapsed:.3f}s \"{user_agent}\"")
                    return result

                except ArgumentNormalizationError as e:
                    # Log argument error with user info if available
                    elapsed = time.time() - start_time
                    config = self.server_core.connection_config if self.server_core else None
                    if config and config.username:
                        user_info = f"user_id:{config.user_id}|tenant_id:{config.tenant_id}|user:{config.username}"
                    else:
                        user_info = "user_id:unknown|tenant_id:unknown|user:unknown"
                    access_logger.info(
                        f"{client_ip} - {user_info} - \"{name}\" - 400 {elapsed:.3f}s \"ArgumentError: {e.message}\"")
                    logger.warning(f"Argument error for {name}: {e.message}")
                    return ResponseBuilder.create_error_response(e, f"Tool {name} argument normalization error!")
                except Exception as e:
                    # Log execution error with user info if available
                    elapsed = time.time() - start_time
                    config = self.server_core.connection_config if self.server_core else None
                    if config and config.username:
                        user_info = f"user_id:{config.user_id}|tenant_id:{config.tenant_id}|user:{config.username}"
                    else:
                        user_info = "user_id:unknown|tenant_id:unknown|user:unknown"

                    # Enhanced error logging with more context
                    error_type = type(e).__name__
                    error_msg = str(e)

                    # Log detailed error information
                    logger.opt(exception=True).error(
                        "Tool execution failed for '{}': {}: {}\n  Arguments: {}\n  User info: {}\n  Client IP: {}",
                        name, error_type, error_msg, arguments, user_info, client_ip
                    )

                    # Log to access logger
                    access_logger.info(
                        f"{client_ip} - {user_info} - \"{name}\" - 500 {elapsed:.3f}s \"{error_type}: {error_msg}\"")
                    return ResponseBuilder.create_error_response(e, f"Tool execution: {name}")


            # Register resources if enabled
            if self.config_manager.config.enable_resources:
                # Get resources list synchronously during setup
                try:
                    @self.low_level_server.list_resources()
                    async def handle_list_resources():
                        return await self.registrar._get_resources_list_for_server()

                    @self.low_level_server.read_resource()
                    async def handle_read_resource(uri):
                        return await self.registrar._read_resource_for_server(uri)

                    logger.info("✅ Resource handlers registered")
                except Exception as e:
                    logger.opt(exception=True).warning("Failed to setup resources: {}", e)

            # Register prompts if enabled  
            if self.config_manager.config.enable_prompts:
                # Get prompts list synchronously during setup
                try:
                    @self.low_level_server.list_prompts()
                    async def handle_list_prompts():
                        return await self.registrar._get_prompts_list_for_server()

                    @self.low_level_server.get_prompt()
                    async def handle_get_prompt(name: str, arguments: dict = None):
                        return await self.registrar._get_prompt_for_server(name, arguments or {})
                except Exception as e:
                    logger.opt(exception=True).warning("Failed to setup prompts: {}", e)

            logger.info("HTTP handlers registration completed")

        except Exception as e:
            logger.opt(exception=True).error("Failed to register HTTP handlers: {}", e)
            raise

    async def run(self):
        """Run the MCP server based on transport type"""
        try:
            # Initialize server
            await self.initialize()

            if self.transport_type == "http":
                logger.info(f"🚀 Starting HTTP MCP Server on {self.host}:{self.port}")
                logger.info(f"   MCP endpoint: http://{self.host}:{self.port}")
                logger.info(f"   Server version: {__version__}")
                logger.info("   Server ready for MCP client connections via HTTP")

                # Try the most likely method first
                try:
                    await self.mcp.run_streamable_http_async()
                except AttributeError:
                    try:
                        await self.mcp.run_sse_async()
                    except AttributeError as e:
                        logger.opt(exception=True).error("Failed to start FastMCP: {}", e)
                        raise

            elif self.transport_type == "stdio":
                logger.info("🚀 Starting STDIO MCP Server")
                logger.info(f"   Environment: {self.env}")
                logger.info(f"   Server version: {__version__}")
                logger.info("   Server ready for MCP client connections via STDIO")

                # Import STDIO server
                from mcp.server.stdio import stdio_server

                # Run the STDIO server
                async with stdio_server() as (read_stream, write_stream):
                    await self.low_level_server.run(
                        read_stream=read_stream,
                        write_stream=write_stream,
                        initialization_options=InitializationOptions(
                            server_name="clickzetta_stdio_server",
                            server_version="0.1.0",
                            capabilities=self.low_level_server.get_capabilities(
                                notification_options=NotificationOptions(),
                                experimental_capabilities={},
                            ),
                        ),
                    )

        except Exception as e:
            logger.opt(exception=True).error("MCP server failed: {}", e)
            raise


class ToolConfig:
    """Tool configuration parameters extracted from tool arguments"""

    def __init__(self, region: Optional[str] = None, workspace: Optional[str] = None,
                 vcluster: Optional[str] = None, schema: Optional[str] = None):
        self._region = region
        self._workspace = workspace
        self._vcluster = vcluster
        self._schema = schema

    @property
    def region(self) -> Optional[str]:
        """The regin is studio cregionId"""
        return self._region

    @region.setter
    def region(self, region: str | None):
        self._region = region

    @property
    def workspace(self) -> Optional[str]:
        return self._workspace

    @workspace.setter
    def workspace(self, workspace: str):
        self._workspace = workspace

    @property
    def vcluster(self) -> Optional[str]:
        return self._vcluster

    @vcluster.setter
    def vcluster(self, vcluster: str):
        self._vcluster = vcluster

    @property
    def schema(self) -> Optional[str]:
        return self._schema

    @schema.setter
    def schema(self, schema: str):
        self._schema = schema

    def has_workspace(self) -> bool:
        return self._workspace is not None

    def has_region(self) -> bool:
        return self._region is not None

    def has_vcluster(self) -> bool:
        return self._vcluster is not None

    def has_schema(self) -> bool:
        return self._schema is not None

    def has_required(self) -> bool:
        return self.has_region() and self.has_workspace()

    def has_any(self) -> bool:
        return self.has_region() or self.has_workspace() or self.has_vcluster() or self.has_schema()

    @classmethod
    def from_dict(cls, data: dict) -> 'ToolConfig':
        """Create ToolConfig from dictionary"""
        return ToolConfig(
            region=data.get('region'),
            workspace=data.get('workspace'),
            vcluster=data.get('vcluster'),
            schema=data.get('schema'),
        )
