"""
Argument Normalizer for MCP Tools

This module provides intelligent argument normalization and validation for MCP tools.
It performs the following operations:
1. Default value completion based on inputSchema
2. Type conversion between handler signature and provided arguments
3. Nested type handling for complex structures (list, dict)
4. Detailed error messages with prompt-like guidance
"""

import inspect
import json
import logging
from typing import Any, Dict, List, Optional

from loguru import logger


class ArgumentNormalizationError(Exception):
    """Exception raised when argument normalization fails"""
    
    def __init__(self, message: str, details: Dict[str, Any] = None):
        self.message = message
        self.details = details or {}
        super().__init__(message)
    
    def to_response_dict(self) -> Dict[str, Any]:
        """Convert to user-friendly response format"""
        return {
            "error": self.message,
            "error_type": "ArgumentNormalizationError",
            "details": self.details
        }


class ArgumentNormalizer:
    """
    Intelligent argument normalizer for MCP tools
    
    Handles:
    - Default value completion from inputSchema
    - Type conversion based on handler signature
    - Complex nested type handling (list, dict)
    - Detailed error messages with examples
    """
    
    def __init__(self, tool_name: str, handler: callable, input_schema: Dict[str, Any], samples: List[Dict] = None):
        """
        Initialize normalizer with tool information
        
        Args:
            tool_name: Name of the tool
            handler: Tool handler function
            input_schema: JSON schema for tool input
            samples: Example usage samples from tool definition
        """
        self.tool_name = tool_name
        self.handler = handler
        self.input_schema = input_schema
        self.samples = samples or []
        
        # Extract handler signature
        try:
            self.handler_sig = inspect.signature(handler)
            self.handler_params = self.handler_sig.parameters
        except Exception as e:
            logger.warning(f"Could not extract signature for {tool_name}: {e}")
            self.handler_sig = None
            self.handler_params = {}
    
    def normalize(self, arguments: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Normalize arguments according to inputSchema and handler signature
        
        Args:
            arguments: Raw arguments from client
            
        Returns:
            Normalized arguments dictionary
            
        Raises:
            ArgumentNormalizationError: If normalization fails
        """
        if arguments is None:
            arguments = {}
        
        # Step 1: Apply defaults from inputSchema
        normalized = self._apply_defaults(arguments.copy())
        
        # Step 2: Validate required fields
        self._validate_required_fields(normalized)
        
        # Step 3: Type conversion based on handler signature
        normalized = self._convert_types(normalized)
        
        # Step 4: Validate against inputSchema constraints
        self._validate_constraints(normalized)
        
        return normalized
    
    def _apply_defaults(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Apply default values from inputSchema for missing parameters"""
        properties = self.input_schema.get('properties', {})
        
        for param_name, param_schema in properties.items():
            if param_name not in arguments and 'default' in param_schema:
                default_value = param_schema['default']
                arguments[param_name] = default_value
                logger.debug(f"Applied default value for {param_name}: {default_value}")
        
        return arguments
    
    def _validate_required_fields(self, arguments: Dict[str, Any]) -> None:
        """Validate that all required fields are present"""
        required_fields = self.input_schema.get('required', [])
        missing_fields = [field for field in required_fields if field not in arguments]
        
        if missing_fields:
            error_msg = self._build_missing_fields_error(missing_fields)
            raise ArgumentNormalizationError(error_msg, {
                "missing_fields": missing_fields,
                "provided_fields": list(arguments.keys())
            })
    
    def _convert_types(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Convert argument types based on handler signature and inputSchema"""
        if not self.handler_params:
            return arguments
        
        converted = arguments.copy()
        properties = self.input_schema.get('properties', {})
        
        for param_name, param_value in arguments.items():
            # Skip special parameters that aren't in schema
            if param_name not in properties:
                continue
            
            param_schema = properties[param_name]
            expected_type = param_schema.get('type')
            
            # Get handler parameter info
            handler_param = self.handler_params.get(param_name)
            
            try:
                # Always convert complex types (array, object) to handle nested conversions
                # For simple types, skip if already matching
                if expected_type in ('array', 'object'):
                    # Force conversion to handle nested items
                    converted[param_name] = ArgumentNormalizer.convert_value(
                        param_name, 
                        param_value, 
                        expected_type, 
                        param_schema,
                        handler_param
                    )
                else:
                    # For simple types, only convert if needed
                    if not ArgumentNormalizer._types_match(param_value, expected_type):
                        converted[param_name] = ArgumentNormalizer.convert_value(
                            param_name, 
                            param_value, 
                            expected_type, 
                            param_schema,
                            handler_param
                        )
            except Exception as e:
                error_msg = self._build_type_conversion_error(
                    param_name, param_value, expected_type, param_schema, e
                )
                raise ArgumentNormalizationError(error_msg, {
                    "parameter": param_name,
                    "provided_value": str(param_value),
                    "provided_type": type(param_value).__name__,
                    "expected_type": expected_type,
                    "conversion_error": str(e)
                })
        
        return converted

    @staticmethod
    def convert_value(
        param_name: str,
        value: Any, 
        expected_type: str, 
        schema: Dict[str, Any],
        handler_param: Optional[inspect.Parameter]
    ) -> Any:
        """
        Convert a single value to expected type
        
        Args:
            param_name: Parameter name
            value: Value to convert
            expected_type: Expected type from inputSchema
            schema: Full parameter schema
            handler_param: Handler parameter info from signature
            
        Returns:
            Converted value
        """
        # If value is None and type allows null, return None
        if value is None:
            return None
        
        # Get actual type from value
        actual_type = type(value).__name__
        
        # For complex types (array, object), always process to handle nested conversions
        # even if outer type matches
        if expected_type not in ('array', 'object'):
            # Check if types already match for simple types
            if ArgumentNormalizer._types_match(value, expected_type):
                return value
        
        # Perform type conversion
        if expected_type == 'integer':
            return ArgumentNormalizer._to_int(param_name, value)
        elif expected_type == 'number':
            return ArgumentNormalizer._to_number(param_name, value)
        elif expected_type == 'string':
            return ArgumentNormalizer._to_string(param_name, value)
        elif expected_type == 'boolean':
            return ArgumentNormalizer._to_boolean(param_name, value)
        elif expected_type == 'array':
            return ArgumentNormalizer._to_array(param_name, value, schema)
        elif expected_type == 'object':
            return ArgumentNormalizer._to_object(param_name, value, schema)
        else:
            # Unknown type, return as is
            logger.warning(f"Unknown type '{expected_type}' for parameter '{param_name}'")
            return value

    @staticmethod
    def _types_match(value: Any, expected_type: str) -> bool:
        """Check if value type matches expected type"""
        actual_type = type(value).__name__

        type_mapping = {
            'integer': ['int'],
            'number': ['int', 'float'],
            'string': ['str'],
            'boolean': ['bool'],
            'array': ['list', 'tuple'],
            'object': ['dict']
        }

        return actual_type in type_mapping.get(expected_type, [])

    @staticmethod
    def _to_int(param_name: str, value: Any) -> int:
        """Convert value to integer"""
        if isinstance(value, int):
            return value
        if isinstance(value, float):
            return int(value)
        if isinstance(value, str):
            try:
                return int(value)
            except ValueError:
                try:
                    return int(float(value))
                except ValueError:
                    raise ValueError(f"Cannot convert '{value}' to integer")
        raise ValueError(f"Cannot convert {type(value).__name__} to integer")

    @staticmethod
    def _to_number(param_name: str, value: Any) -> float:
        """Convert value to number (float)"""
        if isinstance(value, (int, float)):
            return float(value)
        if isinstance(value, str):
            try:
                return float(value)
            except ValueError:
                raise ValueError(f"Cannot convert '{value}' to number")
        raise ValueError(f"Cannot convert {type(value).__name__} to number")

    @staticmethod
    def _to_string(param_name: str, value: Any) -> str:
        """Convert value to string"""
        if isinstance(value, str):
            return value
        # Convert other types to string representation
        return str(value)

    @staticmethod
    def _to_boolean(param_name: str, value: Any) -> bool:
        """Convert value to boolean"""
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            value_lower = value.lower()
            if value_lower in ('true', 'yes', '1', 'on'):
                return True
            if value_lower in ('false', 'no', '0', 'off'):
                return False
            raise ValueError(f"Cannot convert string '{value}' to boolean")
        if isinstance(value, (int, float)):
            return bool(value)
        raise ValueError(f"Cannot convert {type(value).__name__} to boolean")

    @staticmethod
    def _to_array(param_name: str, value: Any, schema: Dict[str, Any]) -> List[Any]:
        """Convert value to array (list)"""
        if isinstance(value, (list, tuple)):
            # Already a list/tuple, convert items if needed
            array_value = list(value) if isinstance(value, tuple) else value
            return ArgumentNormalizer._convert_array_items(array_value, schema)
        
        if isinstance(value, str):
            # Try to parse as JSON array
            try:
                parsed = json.loads(value)
                if isinstance(parsed, list):
                    return ArgumentNormalizer._convert_array_items(parsed, schema)
                else:
                    raise ValueError(f"Parsed JSON is not an array: {type(parsed).__name__}")
            except json.JSONDecodeError as e:
                raise ValueError(f"Cannot parse string as JSON array: {e}")
        
        raise ValueError(f"Cannot convert {type(value).__name__} to array")

    @staticmethod
    def _convert_array_items(array: List[Any], schema: Dict[str, Any]) -> List[Any]:
        """Recursively convert array items based on items schema"""
        items_schema = schema.get('items', {})
        item_type = items_schema.get('type')
        
        if not item_type:
            # No item type specified, return as is
            return array
        
        converted_items = []
        for i, item in enumerate(array):
            # Check if item needs conversion
            if not ArgumentNormalizer._types_match(item, item_type):
                try:
                    converted_item = ArgumentNormalizer.convert_value(
                        f"item[{i}]", item, item_type, items_schema, None
                    )
                    converted_items.append(converted_item)
                except Exception as e:
                    logger.warning(f"Failed to convert array item {i} from {type(item).__name__} to {item_type}: {e}")
                    converted_items.append(item)
            else:
                converted_items.append(item)
        
        return converted_items

    @staticmethod
    def _to_object(param_name: str, value: Any, schema: Dict[str, Any]) -> Dict[str, Any]:
        """Convert value to object (dict)"""
        if isinstance(value, dict):
            # Already a dict, check if properties need conversion
            return ArgumentNormalizer._convert_object_properties(value, schema)
        
        if isinstance(value, str):
            # Try to parse as JSON object
            try:
                parsed = json.loads(value)
                if isinstance(parsed, dict):
                    return ArgumentNormalizer._convert_object_properties(parsed, schema)
                else:
                    raise ValueError(f"Parsed JSON is not an object: {type(parsed).__name__}")
            except json.JSONDecodeError as e:
                raise ValueError(f"Cannot parse string as JSON object: {e}")
        
        raise ValueError(f"Cannot convert {type(value).__name__} to object")

    @staticmethod
    def _convert_object_properties(obj: Dict[str, Any], schema: Dict[str, Any]) -> Dict[str, Any]:
        """Recursively convert object properties based on properties schema"""
        properties_schema = schema.get('properties', {})
        
        if not properties_schema:
            # No properties schema, return as is
            return obj
        
        converted_obj = obj.copy()
        
        for prop_name, prop_value in obj.items():
            if prop_name in properties_schema:
                prop_schema = properties_schema[prop_name]
                prop_type = prop_schema.get('type')
                
                try:
                    converted_obj[prop_name] = ArgumentNormalizer.convert_value(
                        f"{prop_name}", prop_value, prop_type, prop_schema, None
                    )
                except Exception as e:
                    logger.warning(f"Failed to convert object property {prop_name}: {e}")
        
        return converted_obj
    
    def _validate_constraints(self, arguments: Dict[str, Any]) -> None:
        """Validate arguments against inputSchema constraints (enum, min, max, etc.)"""
        properties = self.input_schema.get('properties', {})
        
        for param_name, param_value in arguments.items():
            if param_name not in properties:
                continue
            
            param_schema = properties[param_name]
            
            # Validate enum
            if 'enum' in param_schema:
                enum_values = param_schema['enum']
                if param_value not in enum_values:
                    error_msg = self._build_enum_error(param_name, param_value, enum_values, param_schema)
                    raise ArgumentNormalizationError(error_msg, {
                        "parameter": param_name,
                        "provided_value": param_value,
                        "allowed_values": enum_values
                    })
            
            # Validate numeric constraints
            if param_schema.get('type') in ('integer', 'number'):
                if 'minimum' in param_schema and param_value < param_schema['minimum']:
                    raise ArgumentNormalizationError(
                        f"Parameter '{param_name}' value {param_value} is below minimum {param_schema['minimum']}",
                        {"parameter": param_name, "value": param_value, "minimum": param_schema['minimum']}
                    )
                
                if 'maximum' in param_schema and param_value > param_schema['maximum']:
                    raise ArgumentNormalizationError(
                        f"Parameter '{param_name}' value {param_value} exceeds maximum {param_schema['maximum']}",
                        {"parameter": param_name, "value": param_value, "maximum": param_schema['maximum']}
                    )
    
    def _build_missing_fields_error(self, missing_fields: List[str]) -> str:
        """Build detailed error message for missing required fields"""
        properties = self.input_schema.get('properties', {})
        
        error_parts = [
            f"❌ Missing required parameters for tool '{self.tool_name}':",
            ""
        ]
        
        for field in missing_fields:
            field_schema = properties.get(field, {})
            field_desc = field_schema.get('description', 'No description available')
            field_type = field_schema.get('type', 'unknown')
            
            error_parts.append(f"  • {field} ({field_type}): {field_desc}")
        
        # Add example if available
        if self.samples:
            error_parts.append("")
            error_parts.append("💡 Example usage:")
            sample = self.samples[0]
            if 'query' in sample:
                error_parts.append(f"   {json.dumps(sample['query'], indent=2)}")
        
        return "\n".join(error_parts)
    
    def _build_type_conversion_error(
        self, 
        param_name: str, 
        value: Any, 
        expected_type: str, 
        schema: Dict[str, Any],
        original_error: Exception
    ) -> str:
        """Build detailed error message for type conversion failure"""
        error_parts = [
            f"❌ Type conversion failed for parameter '{param_name}' in tool '{self.tool_name}':",
            "",
            f"  Provided value: {value}",
            f"  Provided type: {type(value).__name__}",
            f"  Expected type: {expected_type}",
            ""
        ]
        
        # Add description
        if 'description' in schema:
            error_parts.append(f"  Description: {schema['description']}")
            error_parts.append("")
        
        # Add enum values if applicable
        if 'enum' in schema:
            error_parts.append(f"  Allowed values: {', '.join(map(str, schema['enum']))}")
            error_parts.append("")
        
        # Add conversion hint
        error_parts.append(f"  Conversion error: {str(original_error)}")
        
        # Add example if available
        if self.samples:
            error_parts.append("")
            error_parts.append("💡 Example:")
            sample = self.samples[0]
            if 'query' in sample and param_name in sample['query']:
                example_value = sample['query'][param_name]
                error_parts.append(f"   {param_name}: {json.dumps(example_value)}")
        
        return "\n".join(error_parts)
    
    def _build_enum_error(
        self, 
        param_name: str, 
        value: Any, 
        enum_values: List[Any],
        schema: Dict[str, Any]
    ) -> str:
        """Build detailed error message for enum validation failure"""
        error_parts = [
            f"❌ Invalid value for parameter '{param_name}' in tool '{self.tool_name}':",
            "",
            f"  Provided: {value}",
            f"  Allowed values: {', '.join(map(str, enum_values))}",
            ""
        ]
        
        # Add description
        if 'description' in schema:
            error_parts.append(f"  Description: {schema['description']}")
            error_parts.append("")
        
        # Add example if available
        if self.samples:
            error_parts.append("💡 Example:")
            sample = self.samples[0]
            if 'query' in sample and param_name in sample['query']:
                example_value = sample['query'][param_name]
                error_parts.append(f"   {param_name}: {json.dumps(example_value)}")
        
        return "\n".join(error_parts)


def create_normalizer_for_tool(tool) -> Optional[ArgumentNormalizer]:
    """
    Create an ArgumentNormalizer for a tool if it has 'normalize' tag
    
    Args:
        tool: Tool object with name, handler, input_schema, tags, and samples
        
    Returns:
        ArgumentNormalizer instance or None if tool doesn't need normalization
    """
    # Check if tool has 'normalize' tag
    if 'normalize' not in tool.tags:
        return None
    
    samples = getattr(tool, 'samples', [])
    
    return ArgumentNormalizer(
        tool_name=tool.name,
        handler=tool.handler,
        input_schema=tool.input_schema,
        samples=samples
    )

