"""
MCP ClickZetta Server - 统一MCP组件注册器

提供统一的工具、资源、提示词注册逻辑，消除HTTP/SSE/STDIO之间的重复代码。
基于官方MCP SDK最佳实践设计。
"""

import asyncio
import inspect
import logging
import os
from typing import Any, Dict, List

import mcp.types as types
# MCP相关导入
from mcp.server import Server
from mcp.server.fastmcp import FastMCP

from ..core.region_config import get_available_regions
# 本地导入
from ..core.server_core import MCPServerCore
from ..core.tool_registry import ToolRegistry
from ..core.write_detector import SQLWriteDetector

from loguru import logger


class MCPComponentRegistrar:
    """
    统一的MCP组件注册器
    
    为HTTP/SSE/STDIO三种传输协议提供统一的工具、资源、提示词注册逻辑，
    消除重复代码，符合官方MCP SDK最佳实践。
    """
    
    def __init__(self, server_core: MCPServerCore, tool_registry: ToolRegistry):
        """
        初始化MCP组件注册器
        
        Args:
            server_core: 服务器核心实例
            tool_registry: 工具注册器
        """
        self.server_core = server_core
        self.tool_registry = tool_registry
        
        # 性能优化：资源和提示词缓存
        self._resources_cache = None
        self._prompts_cache = None
        self._markdown_files_cache = None
        self._cache_timestamp = 0
        self._cache_ttl = 300  # 5分钟缓存
        
        # 超时配置
        self.default_timeout = 30.0  # 30秒默认超时
        self.resource_timeout = 15.0  # 15秒资源操作超时
        self.prompt_timeout = 10.0   # 10秒提示词操作超时

    # ==================== FastMCP注册方法 (HTTP/SSE使用) ====================
    
    def register_tools_to_fastmcp(self, fastmcp_instance: FastMCP, enable_init_retry: bool = True) -> None:
        """
        将所有工具注册到FastMCP实例
        
        Args:
            fastmcp_instance: FastMCP实例(HTTP/SSE)
            enable_init_retry: 是否启用初始化重试机制
        """
        try:
            all_tools = self.tool_registry.get_all_tools()
            logger.info(f"开始注册 {len(all_tools)} 个工具到FastMCP")
            
            for tool in all_tools:
                handler = self.tool_registry.get_tool_handler(tool.name)
                if not handler:
                    logger.warning(f"工具 {tool.name} 没有对应的处理器，跳过")
                    continue
                
                self._create_fastmcp_tool_handler(fastmcp_instance, tool, handler, enable_init_retry)
            
            logger.info(f"✅ 成功注册 {len(all_tools)} 个工具到FastMCP")
            
        except Exception as e:
            logger.error(f"注册工具到FastMCP失败: {e}")
            raise
    
    def register_resources_to_fastmcp(self, fastmcp_instance: FastMCP) -> None:
        """
        将所有资源注册到FastMCP实例（优化版，带超时保护）

        Args:
            fastmcp_instance: FastMCP实例(HTTP/SSE)
        """
        try:
            logger.info("开始注册resources到FastMCP（优化版）")

            # 1. 注册memo资源（带超时保护）
            @fastmcp_instance.resource(
                "memo://insights",
                name="Data Insights Memo",
                description="A living document of discovered data insights",
                mime_type="text/plain"
            )
            async def get_memo() -> str:
                try:
                    return await asyncio.wait_for(
                        self._get_memo_with_timeout(),
                        timeout=self.resource_timeout
                    )
                except asyncio.TimeoutError:
                    logger.warning(f"获取备忘录超时({self.resource_timeout}秒)")
                    return "⏰ 备忘录获取超时，请稍后重试"
                except Exception as e:
                    logger.error(f"获取备忘录失败: {e}")
                    return f"❌ 获取备忘录失败: {str(e)}"


            @fastmcp_instance.resource(
                "schema://get_available_regions",
                name="Clickzetta region list",
                description="Available region list in Clickzetta Studio with their region_id and url",
                mime_type="application/json"
            )
            async def get_region_list() -> dict[str, Any]:
                try:
                    return get_available_regions()
                except Exception as e:
                    logger.error(f"获取region_list信息失败: {e}")
                    return {"error": f"获取region_list信息失败: {str(e)}"}

            # 3. 注册markdown文档资源（优化版）
            self._register_markdown_resources_to_fastmcp_optimized(fastmcp_instance)

            # 4. 注册表资源（优化版）
            self._register_table_resources_to_fastmcp_optimized(fastmcp_instance)

            logger.info("✅ Resources注册到FastMCP完成（优化版）")

        except Exception as e:
            logger.error(f"注册resources失败: {e}")
            raise

    def register_prompts_to_fastmcp(self, fastmcp_instance: FastMCP) -> None:
        """
        将所有提示词注册到FastMCP实例（优化版，带超时保护）
        
        Args:
            fastmcp_instance: FastMCP实例(HTTP/SSE)
        """
        try:
            from cz_mcp.prompts import PROMPTS
            
            logger.info(f"开始注册 {len(PROMPTS)} 个prompts到FastMCP（优化版）")
            
            for prompt_name, prompt_data in PROMPTS.items():
                def create_prompt_handler(name: str, data: dict):
                    @fastmcp_instance.prompt(
                        name=data["name"],
                        description=data["description"]
                    )
                    async def get_prompt(
                        table_name: str = "", 
                        columns: str = "", 
                        db_type: str = "", 
                        host: str = "", 
                        port: str = "", 
                        database: str = "", 
                        username: str = "", 
                        password: str = "", 
                        source_table: str = "", 
                        dest_table: str = ""
                    ) -> str:
                        try:
                            return await asyncio.wait_for(
                                self._process_prompt_request_async(name, data, {
                                    'table_name': table_name, 'columns': columns, 'db_type': db_type,
                                    'host': host, 'port': port, 'database': database, 'username': username,
                                    'password': password, 'source_table': source_table, 'dest_table': dest_table
                                }),
                                timeout=self.prompt_timeout
                            )
                        except asyncio.TimeoutError:
                            logger.warning(f"提示词处理超时: {name}")
                            return f"⏰ 提示词处理超时: {name}"
                        except Exception as e:
                            logger.error(f"提示词处理失败 {name}: {e}")
                            return f"❌ 提示词处理失败: {str(e)}"
                    
                    return get_prompt
                
                create_prompt_handler(prompt_name, prompt_data)
            
            logger.info(f"✅ 成功注册 {len(PROMPTS)} 个prompts到FastMCP（优化版）")
            
        except Exception as e:
            logger.error(f"注册prompts失败: {e}")
            raise
    
    # ==================== MCP Server注册方法 (STDIO使用) ====================

    def register_tools_to_server(self, server: Server) -> None:
        """
        将所有工具注册到MCP Server实例

        Args:
            server: MCP Server实例(STDIO)
        """
        try:
            all_tools = self.tool_registry.get_all_tools()
            logger.info(f"注册 {len(all_tools)} 个工具到MCP Server")

            @server.list_tools()
            async def handle_list_tools():
                """处理工具列表请求"""
                mcp_tools = self.tool_registry.get_mcp_tool_list(all_tools)
                logger.debug(f"返回{len(mcp_tools)}个工具")
                return mcp_tools

            @server.call_tool()
            async def handle_call_tool(name: str, arguments: dict = None):
                """处理工具调用请求"""
                # Access lifespan context
                ctx = server.request_context
                return await self._execute_tool_for_server(name, arguments or {})

            logger.info(f"✅ 成功注册工具处理器到MCP Server")

        except Exception as e:
            logger.error(f"注册工具到MCP Server失败: {e}")
            raise

    def register_resources_to_server(self, server: Server) -> None:
        """
        将所有资源注册到MCP Server实例

        Args:
            server: MCP Server实例(STDIO)
        """
        try:
            @server.list_resources()
            async def handle_list_resources():
                """处理资源列表请求"""
                return await self._get_resources_list_for_server()

            @server.read_resource()
            async def handle_read_resource(uri: Any) -> str:
                """处理资源读取请求"""
                return await self._read_resource_for_server(uri)

            logger.info("✅ 成功注册资源处理器到MCP Server")

        except Exception as e:
            logger.error(f"注册资源到MCP Server失败: {e}")
            raise

    def register_prompts_to_server(self, server: Server) -> None:
        """
        将所有提示词注册到MCP Server实例

        Args:
            server: MCP Server实例(STDIO)
        """
        try:
            @server.list_prompts()
            async def handle_list_prompts():
                """处理提示词列表请求"""
                return await self._get_prompts_list_for_server()

            @server.get_prompt()
            async def handle_get_prompt(name: str, arguments: dict = None):
                """处理获取提示词请求"""
                return await self._get_prompt_for_server(name, arguments or {})

            logger.info("✅ 成功注册提示词处理器到MCP Server")

        except Exception as e:
            logger.error(f"注册提示词到MCP Server失败: {e}")
            raise

    # ==================== 性能优化辅助方法 ====================

    async def _get_memo_with_timeout(self) -> str:
        """获取备忘录内容（带超时保护）"""
        try:
            db = self.server_core.get_db()
            try:
                return db.get_memo()
            finally:
                self.server_core.return_db_connection(db)
        except Exception as e:
            raise Exception(f"获取备忘录失败: {str(e)}")

    
    def _get_cached_markdown_files(self) -> List[Dict[str, str]]:
        """获取缓存的markdown文件信息"""
        import time
        current_time = time.time()
        
        # 检查缓存是否有效
        if (self._markdown_files_cache is not None and 
            current_time - self._cache_timestamp < self._cache_ttl):
            return self._markdown_files_cache
        
        # 重建缓存
        try:
            markdown_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "resource", "markdown"))
            chinese_filenames = [
                "Lakehouse架构实体关系详细描述",
                "Lakehouse UI 组件样式规范（中文）",
                "Lakehouse UI 数据流程图规范（中文）",
                "Lakehouse样式指南（中文）",
                "快速体验Lakehouse"
            ]

            files_info = []

            if os.path.exists(markdown_dir) and os.path.isdir(markdown_dir):
                md_files = [f for f in os.listdir(markdown_dir) if f.endswith(".md")]
                logger.info(f"发现 {len(md_files)} 个markdown文件")

                for idx, filename in enumerate(sorted(md_files)):
                    file_path = os.path.join(markdown_dir, filename)
                    chinese_name = chinese_filenames[idx] if idx < len(chinese_filenames) else filename

                    files_info.append({
                        "filename": filename,
                        "file_path": file_path,
                        "chinese_name": chinese_name,
                        "description": f"Markdown 文档: {chinese_name}"
                    })
            else:
                logger.warning(f"Markdown目录不存在: {markdown_dir}")
            
            # 更新缓存
            self._markdown_files_cache = files_info
            self._cache_timestamp = current_time
            
            return files_info
            
        except Exception as e:
            logger.error(f"获取markdown文件信息失败: {e}")
            return []
    
    def _register_markdown_resources_to_fastmcp_optimized(self, fastmcp_instance: FastMCP):
        """优化版：注册markdown资源到FastMCP"""
        try:
            files_info = self._get_cached_markdown_files()
            
            for file_info in files_info:
                file_path = file_info["file_path"]
                chinese_name = file_info["chinese_name"]
                description = file_info["description"]
                
                def create_markdown_handler(path: str, name: str, desc: str):
                    @fastmcp_instance.resource(
                        f"file://{path}",
                        name=name,
                        description=desc,
                        mime_type="text/markdown"
                    )
                    async def get_markdown() -> str:
                        try:
                            return await asyncio.wait_for(
                                self._read_file_async(path),
                                timeout=self.resource_timeout
                            )
                        except asyncio.TimeoutError:
                            logger.warning(f"读取文件超时: {path}")
                            return f"⏰ 文件读取超时: {name}"
                        except Exception as e:
                            logger.error(f"读取文件失败 {path}: {e}")
                            return f"❌ 读取文件失败: {str(e)}"
                    return get_markdown
                
                create_markdown_handler(file_path, chinese_name, description)
                
        except Exception as e:
            logger.error(f"注册markdown资源失败: {e}")
    
    def _register_table_resources_to_fastmcp_optimized(self, fastmcp_instance: FastMCP):
        """优化版：注册表资源到FastMCP"""
        try:
            tables_info = getattr(self.server_core, '_cached_tables_info', {})
            if tables_info:
                logger.info(f"注册 {len(tables_info)} 个表资源")
                for table_name in list(tables_info.keys())[:10]:  # 限制前10个表，避免过多资源
                    def create_table_resource_handler(name: str):
                        @fastmcp_instance.resource(
                            f"context://table/{name}",
                            name=f"{name} table",
                            description=f"Description of the {name} table",
                            mime_type="text/plain"
                        )
                        async def get_table_info() -> str:
                            try:
                                return await asyncio.wait_for(
                                    self._get_table_info_async(name),
                                    timeout=self.resource_timeout
                                )
                            except asyncio.TimeoutError:
                                logger.warning(f"获取表信息超时: {name}")
                                return f"⏰ 表信息获取超时: {name}"
                            except Exception as e:
                                logger.error(f"获取表信息失败 {name}: {e}")
                                return f"❌ 获取表信息失败: {str(e)}"
                        return get_table_info
                    
                    create_table_resource_handler(table_name)
            else:
                logger.info("没有缓存的表信息，跳过表资源注册")
                
        except Exception as e:
            logger.error(f"注册表资源失败: {e}")
    
    async def _read_file_async(self, file_path: str) -> str:
        """异步读取文件"""
        try:
            # 使用线程池执行文件I/O以避免阻塞
            import concurrent.futures
            
            def read_file_sync():
                with open(file_path, "r", encoding="utf-8") as f:
                    return f.read()
            
            loop = asyncio.get_event_loop()
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
                return await loop.run_in_executor(executor, read_file_sync)
                
        except Exception as e:
            raise Exception(f"读取文件失败 {file_path}: {str(e)}")
    
    async def _get_table_info_async(self, table_name: str) -> str:
        """异步获取表信息"""
        try:
            from ..common.utilities import data_to_yaml
            
            def get_table_info_sync():
                tables_info = getattr(self.server_core, '_cached_tables_info', {})
                if table_name in tables_info:
                    return data_to_yaml(tables_info[table_name])
                else:
                    raise ValueError(f"表 {table_name} 信息不可用")
            
            loop = asyncio.get_event_loop()
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
                return await loop.run_in_executor(executor, get_table_info_sync)
                
        except Exception as e:
            raise Exception(f"获取表信息失败 {table_name}: {str(e)}")
    
    async def _process_prompt_request_async(self, name: str, data: dict, arguments: dict) -> str:
        """异步处理提示词请求"""
        try:
            import concurrent.futures
            
            def process_prompt_sync():
                return self._process_prompt_request(name, data, arguments)
            
            loop = asyncio.get_event_loop()
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
                return await loop.run_in_executor(executor, process_prompt_sync)
                
        except Exception as e:
            raise Exception(f"处理提示词失败 {name}: {str(e)}")

    # ==================== 私有辅助方法 ====================
    
    def _create_fastmcp_tool_handler(self, fastmcp_instance: FastMCP, tool, handler, enable_init_retry: bool):
        """为工具创建FastMCP处理器"""
        
        # 获取工具参数schema
        properties = tool.input_schema.get("properties", {})
        required = tool.input_schema.get("required", [])
        
        # 创建动态函数签名
        params = []
        
        # 添加必需参数
        for param_name in required:
            if param_name in properties:
                params.append(inspect.Parameter(
                    param_name,
                    inspect.Parameter.POSITIONAL_OR_KEYWORD,
                    default=inspect.Parameter.empty,
                    annotation=str
                ))
        
        # 添加可选参数
        for param_name, param_info in properties.items():
            if param_name not in required:
                params.append(inspect.Parameter(
                    param_name,
                    inspect.Parameter.POSITIONAL_OR_KEYWORD,
                    default="",
                    annotation=str
                ))
        
        # 创建动态wrapper函数
        async def tool_wrapper(**kwargs) -> str:
            arguments = {k: v for k, v in kwargs.items() if v is not None and str(v).strip()}
            
            if enable_init_retry:
                return await self._execute_tool_with_init_retry(tool.name, arguments, handler)
            else:
                return await self._execute_tool_direct(tool.name, arguments, handler)
        
        # 设置函数签名和元信息
        tool_wrapper.__signature__ = inspect.Signature(params)
        tool_wrapper.__name__ = f"tool_{tool.name}"
        
        # 注册到FastMCP
        fastmcp_instance.add_tool(
            tool_wrapper,
            name=tool.name,
            description=tool.description
        )
    
    async def _execute_tool_with_init_retry(self, tool_name: str, arguments: dict, handler) -> str:
        """执行工具（带初始化重试机制）"""
        max_retries = 3
        
        for retry in range(max_retries):
            try:
                return await self._execute_tool_direct(tool_name, arguments, handler)
            except RuntimeError as e:
                error_str = str(e).lower()
                if ("initialization" in error_str and retry < max_retries - 1):
                    delay = 1.0 + (retry * 0.5)
                    logger.warning(f"工具 {tool_name} 初始化竞争，等待 {delay:.1f}s 重试 ({retry + 1}/{max_retries})")
                    await asyncio.sleep(delay)
                    continue
                else:
                    raise
        
        return f"❌ 工具 {tool_name} 初始化重试失败"
    
    async def _execute_tool_direct(self, tool_name: str, arguments: dict, handler) -> str:
        """直接执行工具"""
        db = None
        try:
            logger.debug(f"执行工具: {tool_name}，参数: {arguments}")
            
            # 获取数据库连接
            db = self.server_core.get_db()
            
            # 创建必要的辅助对象
            write_detector = SQLWriteDetector()

            # 执行工具，带超时保护
            tool_timeout = 120.0 if tool_name == "create_external_function" else 45.0
            result = await asyncio.wait_for(
                handler(arguments, db, write_detector, True, self.server_core),
                timeout=tool_timeout
            )
            await asyncio.sleep(0)
            
            return self._format_result_safe(result)
            
        except asyncio.TimeoutError:
            timeout = 120 if tool_name == "create_external_function" else 45
            logger.error(f"工具 {tool_name} 执行超时({timeout}秒)")
            return f"⏰ 工具执行超时: {tool_name} 超过{timeout}秒"
        except Exception as e:
            logger.error(f"工具 {tool_name} 执行失败: {e}")
            return self._format_error_safe(tool_name, e)
        finally:
            # 归还数据库连接
            if db is not None:
                try:
                    self.server_core.return_db_connection(db)
                except Exception as cleanup_error:
                    logger.warning(f"归还数据库连接失败: {cleanup_error}")
    
    async def _execute_tool_for_server(self, tool_name: str, arguments: dict):
        """为MCP Server执行工具"""
        try:
            handler = self.tool_registry.get_tool_handler(tool_name)
            if not handler:
                error_msg = f"工具 '{tool_name}' 未找到"
                logger.error(error_msg)
                return [types.TextContent(type="text", text=f"❌ {error_msg}")]

            # Check if this is a utility tool that doesn't require database connection
            all_tools = self.tool_registry.get_all_tools()
            tool_metadata = next((t for t in all_tools if t.name == tool_name), None)
            is_utility_tool = tool_metadata and "utility" in tool_metadata.tags

            if is_utility_tool:
                logger.info(f"Executing utility tool '{tool_name}' without database connection (STDIO mode)")
                # Execute utility tool directly without db, writer_detector, or server_core
                result_text = await handler(arguments, None, None, False, None)
            else:
                # Execute regular tool with full dependencies
                result_text = await self._execute_tool_direct(tool_name, arguments, handler)

            # 确保返回MCP类型
            if not isinstance(result_text, list):
                return [types.TextContent(type="text", text=str(result_text))]
            return result_text

        except Exception as e:
            error_msg = f"工具调用失败 {tool_name}: {str(e)}"
            logger.error(error_msg)
            return [types.TextContent(type="text", text=f"❌ {error_msg}")]
    
    def _register_markdown_resources_to_fastmcp(self, fastmcp_instance: FastMCP):
        """注册markdown资源到FastMCP"""
        markdown_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "resource", "markdown"))
        chinese_filenames = [
            "Lakehouse架构实体关系详细描述",
            "Lakehouse UI 组件样式规范（中文）",
            "Lakehouse UI 数据流程图规范（中文）",
            "Lakehouse样式指南（中文）",
            "快速体验Lakehouse"
        ]

        if os.path.exists(markdown_dir) and os.path.isdir(markdown_dir):
            md_files = [f for f in os.listdir(markdown_dir) if f.endswith(".md")]
            logger.info(f"发现 {len(md_files)} 个markdown文件")

            for idx, filename in enumerate(sorted(md_files)):
                file_path = os.path.join(markdown_dir, filename)
                chinese_name = chinese_filenames[idx] if idx < len(chinese_filenames) else filename

                def create_markdown_handler(path: str, name: str, description: str):
                    @fastmcp_instance.resource(
                        f"file://{path}",
                        name=name,
                        description=description,
                        mime_type="text/markdown"
                    )
                    async def get_markdown() -> str:
                        try:
                            with open(path, "r", encoding="utf-8") as f:
                                return f.read()
                        except Exception as e:
                            return f"读取文件失败: {str(e)}"
                    return get_markdown

                create_markdown_handler(file_path, chinese_name, f"Markdown 文档: {chinese_name}")
        else:
            logger.warning(f"Markdown目录不存在: {markdown_dir}")
    
    def _register_table_resources_to_fastmcp(self, fastmcp_instance: FastMCP):
        """注册表资源到FastMCP"""
        tables_info = getattr(self.server_core, '_cached_tables_info', {})
        if tables_info:
            logger.info(f"注册 {len(tables_info)} 个表资源")
            for table_name in tables_info.keys():
                def create_table_resource_handler(name: str):
                    @fastmcp_instance.resource(
                        f"context://table/{name}",
                        name=f"{name} table",
                        description=f"Description of the {name} table",
                        mime_type="text/plain"
                    )
                    async def get_table_info() -> str:
                        try:
                            from ..common.utilities import data_to_yaml
                            tables_info = getattr(self.server_core, '_cached_tables_info', {})
                            if name in tables_info:
                                return data_to_yaml(tables_info[name])
                            else:
                                return f"表 {name} 信息不可用"
                        except Exception as e:
                            return f"获取表信息失败: {str(e)}"
                    return get_table_info
                
                create_table_resource_handler(table_name)
        else:
            logger.info("没有缓存的表信息，跳过表资源注册")
    
    def _process_prompt_request(self, name: str, data: dict, arguments: dict) -> str:
        """处理提示词请求的统一逻辑"""
        try:
            if name == "create_table_prompt":
                table_name = arguments.get("table_name", "")
                columns = arguments.get("columns", "")
                if table_name and columns:
                    return f"Create a table named '{table_name}' with the following columns:\\n\\n{columns}"
                else:
                    return data["description"] + "\\n\\nPlease provide table_name and columns parameters."
            
            elif name == "create_database_connection_and_query_table_prompt":
                connection_info = []
                for key in ['db_type', 'host', 'port', 'database', 'username', 'source_table', 'dest_table']:
                    value = arguments.get(key, "")
                    if value:
                        connection_info.append(f"{key.replace('_', ' ').title()}: {value}")
                
                if connection_info:
                    return data["description"] + "\\n\\nConnection parameters:\\n" + "\\n".join(connection_info)
                else:
                    return data["description"] + "\\n\\nPlease provide the required connection parameters."
            
            else:
                return data["description"]
                
        except Exception as e:
            logger.error(f"处理prompt {name} 失败: {e}")
            return data["description"]
    
    async def _get_resources_list_for_server(self) -> List[types.Resource]:
        """获取资源列表(用于STDIO)"""
        try:
            from pydantic import AnyUrl

            resources = [
                types.Resource(
                    name="Data Insights Memo",
                    uri=AnyUrl("memo://insights"),
                    description="A living document of discovered data insights",
                    mimeType="text/plain",
                ),
                types.Resource(
                    uri=AnyUrl("schema://get_available_regions"),
                    name="Clickzetta region list",
                    description="Available region list in Clickzetta Studio with their region_id and url",
                    mimeType="application/json"
                )
            ]
            
            # 添加markdown文件资源
            markdown_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "resource", "markdown"))
            chinese_filenames = [
                "Lakehouse架构实体关系详细描述",
                "Lakehouse UI 组件样式规范（中文）",
                "Lakehouse UI 数据流程图规范（中文）",
                "Lakehouse样式指南（中文）",
                "快速体验Lakehouse"
            ]

            if os.path.exists(markdown_dir) and os.path.isdir(markdown_dir):
                try:
                    md_files = [f for f in os.listdir(markdown_dir) if f.endswith(".md")]
                    logger.info(f"发现 {len(md_files)} 个markdown文件")
                except Exception as e:
                    logger.warning(f"读取markdown目录失败: {e}")
                    md_files = []
            else:
                logger.warning(f"Markdown目录不存在: {markdown_dir}")
                md_files = []
                
            for idx, filename in enumerate(sorted(md_files)):
                file_path = os.path.join(markdown_dir, filename)
                uri = AnyUrl(f"file://{file_path}")
                chinese_name = chinese_filenames[idx] if idx < len(chinese_filenames) else filename
                resources.append(
                    types.Resource(
                        name=chinese_name,
                        uri=uri,
                        description=f"Markdown 文档: {chinese_name}",
                        mimeType="text/markdown",
                    )
                )
            
            # 添加表资源
            tables_info = getattr(self.server_core, '_cached_tables_info', {})
            for table_name in tables_info.keys():
                resources.append(
                    types.Resource(
                        name=f"{table_name} table",
                        uri=AnyUrl(f"context://table/{table_name}"),
                        description=f"Description of the {table_name} table",
                        mimeType="text/plain",
                    )
                )
            
            logger.info(f"返回 {len(resources)} 个资源")
            return resources
            
        except Exception as e:
            logger.error(f"获取资源列表失败: {e}")
            return []
    
    async def _read_resource_for_server(self, uri: Any) -> str:
        """读取资源(用于STDIO)"""
        try:
            from ..common.utilities import data_to_yaml

            uri_str = str(uri)

            if uri_str == "memo://insights":
                db = self.server_core.get_db()
                try:
                    return db.get_memo()
                finally:
                    self.server_core.return_db_connection(db)


            elif uri_str == "schema://get_available_regions":
                regions = get_available_regions()
                import json
                return json.dumps(regions, ensure_ascii=False, indent=2)

            elif uri_str.startswith("context://table"):
                table_name = uri_str.split("/")[-1]
                tables_info = getattr(self.server_core, '_cached_tables_info', {})
                if table_name in tables_info:
                    return data_to_yaml(tables_info[table_name])
                else:
                    raise ValueError(f"Unknown table: {table_name}")

            elif uri_str.startswith("file://"):
                file_path = uri_str[7:]  # 去掉 file://
                if os.path.exists(file_path):
                    with open(file_path, "r", encoding="utf-8") as f:
                        return f.read()
                else:
                    raise ValueError(f"File not found: {file_path}")

            else:
                raise ValueError(f"Unknown resource: {uri}")

        except Exception as e:
            logger.error(f"读取资源失败 {uri}: {e}")
            raise ValueError(f"读取资源失败: {str(e)}")
    
    async def _get_prompts_list_for_server(self) -> List[types.Prompt]:
        """获取提示词列表(用于STDIO)"""
        try:
            from cz_mcp.prompts import PROMPTS
            logger.info(f"导入PROMPTS成功，包含 {len(PROMPTS)} 个提示词")
            
            prompt_list = []
            
            for prompt_name, prompt_data in PROMPTS.items():
                try:
                    # 转换为MCP Prompt对象
                    arguments = []
                    for arg in prompt_data.get("arguments", []):
                        arguments.append(types.PromptArgument(
                            name=arg["name"],
                            description=arg["description"],
                            required=arg.get("required", False)
                        ))
                    
                    prompt_list.append(types.Prompt(
                        name=prompt_data["name"],
                        description=prompt_data["description"],
                        arguments=arguments
                    ))
                    logger.debug(f"成功处理提示词: {prompt_name}")
                except Exception as prompt_err:
                    logger.error(f"处理提示词 {prompt_name} 失败: {prompt_err}")
                    continue
            
            logger.info(f"返回 {len(prompt_list)} 个提示词")
            return prompt_list
        except Exception as e:
            logger.error(f"获取提示词列表失败: {e}")
            return []
    
    async def _get_prompt_for_server(self, name: str, arguments: dict) -> types.GetPromptResult:
        """获取提示词(用于STDIO)"""
        try:
            from cz_mcp.prompts import PROMPTS
            
            if name not in PROMPTS:
                raise ValueError(f"Prompt not found: {name}")
            
            # 处理特殊提示词
            if name == "create_table_interactive":
                table_name = arguments.get("table_name", "")
                columns = arguments.get("columns", "")
                return types.GetPromptResult(
                    messages=[
                        types.PromptMessage(
                            role="user",
                            content=types.TextContent(
                                type="text",
                                text=f"Create a table named '{table_name}' with the following columns:\\n\\n{columns}"
                            )
                        )
                    ]
                )
            
            # 返回默认提示词
            prompt_obj = PROMPTS[name]
            return types.GetPromptResult(
                messages=[
                    types.PromptMessage(
                        role="user", 
                        content=types.TextContent(
                            type="text",
                            text=prompt_obj["description"]
                        )
                    )
                ]
            )
            
        except Exception as e:
            logger.error(f"获取提示词失败 {name}: {e}")
            raise ValueError(f"获取提示词失败: {str(e)}")
    
    def _format_result_safe(self, result) -> str:
        """安全格式化结果为字符串"""
        try:
            if result is None:
                return "✅ 操作完成"
            
            if isinstance(result, list):
                texts = []
                for item in result:
                    try:
                        if hasattr(item, 'text'):
                            texts.append(str(item.text))
                        elif hasattr(item, 'content'):
                            texts.append(str(item.content))
                        else:
                            texts.append(str(item))
                    except Exception:
                        texts.append(str(item))
                return "\\n".join(texts) if texts else "✅ 操作完成"
            else:
                return str(result)
        except Exception as e:
            logger.error(f"格式化结果失败: {e}")
            return f"⚠️ 结果格式化失败: {str(e)}"
    
    def _format_error_safe(self, tool_name: str, error: Exception) -> str:
        """安全格式化错误结果"""
        try:
            error_str = str(error).lower()
            
            if "connection" in error_str or "database" in error_str:
                return f"❌ 数据库连接错误 [{tool_name}]: {str(error)}"
            elif "timeout" in error_str:
                return f"⏰ 操作超时 [{tool_name}]: {str(error)}"
            elif "permission" in error_str or "access" in error_str:
                return f"🔒 权限错误 [{tool_name}]: {str(error)}"
            elif "not found" in error_str or "404" in error_str:
                return f"📭 未找到资源 [{tool_name}]: {str(error)}"
            elif "invalid" in error_str or "bad" in error_str:
                return f"⚠️ 参数错误 [{tool_name}]: {str(error)}"
            else:
                return f"❌ 工具执行失败 [{tool_name}]: {str(error)}"
                
        except Exception:
            return f"❌ 工具执行失败 [{tool_name}]: 发生未知错误"