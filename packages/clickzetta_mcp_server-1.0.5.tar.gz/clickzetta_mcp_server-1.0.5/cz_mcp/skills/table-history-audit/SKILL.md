---
name: table-history-audit
description: |
  对 ClickZetta 表和 Schema 执行完整的历史审计与恢复工作流。
  当用户需要"审计表变更"、"追踪数据修改"、"恢复误删表"、"回滚到历史版本"、"查看 Schema 变动"时触发。
  组合 audit_table_schema_history、desc_object_history、restore_object、undrop_object 等工具，
  覆盖审计、诊断、恢复的完整链路。
---

# 表历史审计与恢复工作流

## 指令

### 步骤 1：确定审计范围

根据用户需求选择审计目标：
- 单表审计：需要 `table_name`（建议 schema.table 格式）
- Schema 级审计：需要 `schema_name`
- 动态表审计：需要 `table_name` + `target_type=dynamic_table`

### 步骤 2：执行审计查询

使用 `audit_table_schema_history` 工具，根据场景选择 audit_type：

| 场景 | target_type | audit_type | 说明 |
|------|------------|------------|------|
| 表综合审计 | table | table_overview | 整合生命周期 + 加载历史 |
| 表生命周期 | table | table_lifecycle | 基于 DESC HISTORY 的完整版本历史 |
| 数据变更追踪 | table | table_changes | 仅 INSERT/UPDATE/DELETE/MERGE 等变更事件 |
| 文件加载记录 | table | table_loads | 基于 load_history()，仅保留 7 天 |
| 动态表刷新 | dynamic_table | dynamic_refresh | SHOW DYNAMIC TABLE REFRESH HISTORY |
| Schema 概览 | schema | schema_overview | SHOW TABLES HISTORY 汇总 |
| 已删除对象 | schema | deleted_objects | 追踪回收站中的对象 |

### 步骤 3：分析审计结果

关注以下关键信息：
- `operations_breakdown`：操作类型分布
- `latest_operation` 和 `latest_timestamp`：最近的变更
- `unique_actors`：参与变更的用户列表
- `load_history.status_breakdown`：加载成功/失败统计

### 步骤 4：深入调查（按需）
使用 `desc_object_history`、`desc_object`(extended=true)、`show_job_history` 深入。

### 步骤 5：执行恢复（按需）

1. 回滚到历史版本：
   ```
   restore_object(object_type="TABLE", object_name="schema.table_name",
     timestamp="CURRENT_TIMESTAMP() - INTERVAL '2' HOURS")
   ```

2. 恢复已删除对象：
   ```
   undrop_object(object_type="TABLE", object_name="schema.table_name")
   ```
   支持 UNDROP 的对象：TABLE、DYNAMIC TABLE、MATERIALIZED VIEW

## 示例

### 示例 1：表综合审计
```
1. audit_table_schema_history(target_type="table", table_name="analytics.orders", audit_type="table_overview", limit=20)
2. 分析返回的 lifecycle 和 load_history 摘要
3. 如发现异常 DELETE 操作，进一步：
   audit_table_schema_history(target_type="table", table_name="analytics.orders", audit_type="table_changes", limit=50)
```

### 示例 2：误删表恢复
```
1. audit_table_schema_history(target_type="schema", schema_name="production", audit_type="deleted_objects")
2. undrop_object(object_type="TABLE", object_name="production.user_profiles")
3. desc_object(object_type="TABLE", object_name="production.user_profiles")
```

## 故障排除

错误：`load_history 查询失败`
原因：load_history() 仅保留最近 7 天的数据
解决方案：使用 table_lifecycle 审计模式查看更长时间范围的历史

错误：`UNDROP 失败，对象不存在`
原因：对象已超过恢复期限，或对象类型不支持 UNDROP
解决方案：仅 TABLE、DYNAMIC TABLE、MATERIALIZED VIEW 支持 UNDROP

错误：`RESTORE 时间戳格式错误`
原因：ClickZetta 不支持简单日期字符串如 '2025-08-15'
解决方案：使用 CAST('2025-08-15 14:00:00' AS TIMESTAMP) 或相对时间
