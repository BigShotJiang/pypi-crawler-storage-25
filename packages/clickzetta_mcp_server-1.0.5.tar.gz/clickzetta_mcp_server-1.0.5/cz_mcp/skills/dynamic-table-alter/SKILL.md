---
name: dynamic-table-alter
description: |
  修改 ClickZetta 动态表（Dynamic Table）的结构和属性，支持 10 种操作：suspend、resume、
  rename_column、set_comment、set_column_comment（直接 ALTER）以及 add_column、drop_column、
  alter_column、set_refresh_interval、set_select（需 CREATE OR REPLACE 重建）。当用户说
  "修改动态表"、"动态表加列"、"改刷新间隔"、"暂停动态表"时触发。包含 ClickZetta 动态表
  特有的 ALTER 语法限制和 CREATE OR REPLACE 重建机制。
---

# 动态表修改工作流

## 指令

### 步骤 1：确认动态表存在并获取当前定义
使用 `desc_object`(object_name='table_name', object_type='DYNAMIC_TABLE') 获取动态表当前结构。
如果不确定是否为动态表，先用 `show_object_list`(object_type='DYNAMIC_TABLES') 查看列表。

### 步骤 2：判断操作类型并选择执行方式

ClickZetta 动态表的 ALTER 操作分为两类：

**A. 直接 ALTER 操作**（5种，可直接执行）：

1. suspend - 暂停刷新：
```sql
ALTER DYNAMIC TABLE schema_name.table_name SUSPEND;
```

2. resume - 恢复刷新：
```sql
ALTER DYNAMIC TABLE schema_name.table_name RESUME;
```

3. set_comment - 设置表注释：
```sql
ALTER DYNAMIC TABLE schema_name.table_name SET COMMENT = '注释内容';
```

4. rename_column - 重命名列：
```sql
ALTER DYNAMIC TABLE schema_name.table_name RENAME COLUMN old_name TO new_name;
```

5. set_column_comment - 设置列注释（注意用 CHANGE COLUMN 而非 ALTER COLUMN）：
```sql
ALTER DYNAMIC TABLE schema_name.table_name CHANGE COLUMN col_name COMMENT '列注释';
```

**B. CREATE OR REPLACE 操作**（5种，需要重建动态表）：

这些操作无法通过 ALTER 直接完成，必须用 CREATE OR REPLACE DYNAMIC TABLE 重建：

6. add_column - 添加列
7. drop_column - 删除列
8. alter_column - 修改列类型
9. set_refresh_interval - 修改刷新间隔
10. set_select - 修改查询定义

### 步骤 3：执行 CREATE OR REPLACE 重建（仅 B 类操作）

对于 B 类操作，需要先获取当前动态表的完整定义，修改后重建：

1. 用 `read_query` 执行 `SHOW CREATE TABLE schema_name.table_name` 获取原始 DDL
2. 解析出：列定义、REFRESH_INTERVAL、AS SELECT 子句、COMMENT 等
3. 根据操作修改对应部分
4. 用 `write_query` 执行重建 SQL：

```sql
CREATE OR REPLACE DYNAMIC TABLE schema_name.table_name (
  col1 INT COMMENT '列注释',
  col2 STRING,
  new_col DOUBLE  -- add_column: 新增列
)
REFRESH_INTERVAL = '30 MINUTES'  -- set_refresh_interval: 修改间隔
COMMENT = '表注释'
AS
SELECT col1, col2, new_col FROM source_table;  -- set_select: 修改查询
```

### 步骤 4：验证修改结果
使用 `desc_object`(object_type='DYNAMIC_TABLE') 确认修改生效。
对于 suspend/resume，用 `read_query` 查询动态表状态确认。

## 平台特有知识

- CHANGE COLUMN 语法：设置列注释用 `CHANGE COLUMN col COMMENT 'xxx'`，不是 `ALTER COLUMN`
- RENAME COLUMN 语法：`RENAME COLUMN old TO new`，不是 `RENAME old TO new`
- DML 限制：动态表默认不支持 UPDATE/DELETE/MERGE（因隐藏列 MV__KEY），如需 DML 须先执行 `SET cz.sql.dt.allow.dml = true;`
- REFRESH_INTERVAL 格式：字符串格式如 `'30 MINUTES'`、`'1 HOUR'`、`'6 HOURS'`
- CREATE OR REPLACE 风险：重建会导致动态表数据重新计算，大表可能耗时较长
- schema 前缀：所有 ALTER/CREATE 语句中表名应包含 schema 前缀

## 示例

### 示例 1：暂停并修改刷新间隔
```
1. desc_object(object_name='my_dt', object_type='DYNAMIC_TABLE')
2. write_query(query="ALTER DYNAMIC TABLE my_schema.my_dt SUSPEND")
3. read_query(query="SHOW CREATE TABLE my_schema.my_dt")  → 获取原始 DDL
4. write_query(query="CREATE OR REPLACE DYNAMIC TABLE my_schema.my_dt (...) REFRESH_INTERVAL='1 HOUR' AS SELECT ...")
5. write_query(query="ALTER DYNAMIC TABLE my_schema.my_dt RESUME")
```

### 示例 2：给动态表添加列并设置注释
```
1. read_query(query="SHOW CREATE TABLE my_schema.my_dt")  → 获取原始 DDL
2. write_query(query="CREATE OR REPLACE DYNAMIC TABLE my_schema.my_dt (id INT, name STRING, new_col DOUBLE COMMENT '新列') REFRESH_INTERVAL='30 MINUTES' AS SELECT id, name, new_col FROM source")
3. write_query(query="ALTER DYNAMIC TABLE my_schema.my_dt CHANGE COLUMN new_col COMMENT '新增的度量列'")
```

## 故障排除

错误：ALTER DYNAMIC TABLE 报 "unsupported operation"
原因：尝试对动态表执行 ADD COLUMN/DROP COLUMN 等 B 类操作的 ALTER 语法
解决方案：B 类操作必须使用 CREATE OR REPLACE DYNAMIC TABLE 重建

错误：UPDATE/DELETE 报 "MV__KEY" 相关错误
原因：动态表有隐藏列 MV__KEY，默认禁止 DML
解决方案：先执行 `SET cz.sql.dt.allow.dml = true;` 再执行 DML

错误：CREATE OR REPLACE 后数据为空
原因：AS SELECT 子句引用的源表或列不正确
解决方案：先用 `read_query` 验证 SELECT 子句能正确返回数据
