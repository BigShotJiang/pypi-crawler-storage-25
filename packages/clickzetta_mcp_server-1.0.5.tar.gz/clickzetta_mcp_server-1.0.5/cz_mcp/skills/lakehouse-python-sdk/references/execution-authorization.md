# Temporary Execution Authorization

## Rule

Never run temporary execution automatically. Ask user for explicit permission first.

## Authorization Prompt Template

Use a direct confirmation prompt:

`本地验证已完成。是否允许我在 Studio 做一次临时执行验证 ？`

## Minimum Details to Include Before Asking

1. What will be executed (task/mode).
2. Scope (sample size, target table/partition).
3. Expected side effects.
4. Rollback/cleanup strategy if needed.

## If User Denies

1. Do not execute temporary run.
2. Provide static validation result and known residual risk.
3. Ask whether to proceed directly to plan save with noted risk.
