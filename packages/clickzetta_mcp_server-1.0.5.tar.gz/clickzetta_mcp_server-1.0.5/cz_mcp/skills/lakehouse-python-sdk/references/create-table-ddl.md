# CREATE TABLE DDL 参考

## 功能

本语句用于创建一个新的表。在Lakehouse中，表是存储数据的基本单位。通过创建表，您可以将数据按照指定的结构进行组织和管理。

## 语法

### 基本建表语句

```SQL
CREATE TABLE [ IF NOT EXISTS ] table_name
(
    column_definition  [column_definition ,...]
    index_definition_list
)
[ PARTITIONED BY (column_name column_type | column_name | transform_function) ]
[ CLUSTERED BY (column_name,...) 
    [SORTED BY (column_name [ ASC | DESC ])] 
    [INTO num_buckets BUCKETS] 
]
[ COMMENT 'table_comment' ]
[PROPERTIES('data_lifecycle'='day_num')];
```

### column_definition 说明

#### 基本语法

```
column_name column_type 
{ NOT NULL |
  PRIMARY KEY|
  IDENTITY[(seed)]|
  GENERATED ALWAYS AS ( expr ) |
  DEFAULT default_expression |
  COMMENT column_comment |   
}
```

#### 列类型 column_type

支持以下类型：

| 类型 | 说明 |
|------|------|
| `TINYINT` | 1字节整数，范围 -128 到 127 |
| `SMALLINT` | 2字节整数，范围 -32,768 到 32,767 |
| `INT` | 4字节整数，范围 -2,147,483,648 到 2,147,483,647 |
| `BIGINT` | 8字节整数，范围 -9,223,372,036,854,775,808 到 9,223,372,036,854,775,807 |
| `FLOAT` | 4字节浮点数 |
| `DOUBLE` | 8字节浮点数 |
| `DECIMAL` | 可变长度精确数值类型，支持指定精度和小数位数 |
| `VARCHAR` | 变长字符串，最大长度 65,533 字符 |
| `CHAR` | 定长字符串，长度 1~255 字符 |
| `DATE` | 日期，格式 `YYYY-MM-DD` |
| `TIMESTAMP` | 日期时间（本地时间），格式 `YYYY-MM-DD HH:MM:SS` |
| `TIMESTAMP_NTZ` | 不含时区的日期时间，格式 `YYYY-MM-DD HH:MM:SS` |
| `BINARY` | 固定长度二进制字符串 |
| `BOOLEAN` | 布尔值，真或假 |
| `ARRAY<T>` | 元素类型相同的有序集合，如 `ARRAY<INT>` |
| `MAP<K,V>` | 键值对集合，如 `MAP<STRING,INT>` |
| `STRUCT<...>` | 字段类型不同的记录类型，如 `STRUCT<company_name:STRING, employee_count:INT>` |
| `JSON` | 轻量级数据交换格式 |
| `VECTOR` | 数值向量类型，用于存储一系列数值 |

#### NOT NULL

表示该列不允许为 NULL。只支持建表时指定，不支持 ALTER 语法添加。
取消 NOT NULL 约束请使用：

```sql
ALTER TABLE table_name CHANGE COLUMN column_name data_type
-- 示例：去除 int 类型 not null 约束
CREATE TABLE aa_not_null (id INT NOT NULL);
ALTER TABLE aa_not_null CHANGE COLUMN id TYPE INT;
```

#### 主键（PRIMARY KEY）

主键用于确保表中每条记录的唯一性。定义主键的表在进行实时数据写入时，系统将自动根据主键值进行数据去重，适合 CDC 场景。**只支持建表时指定。**

```sql
-- 内联主键
CREATE TABLE pk_table (id INT PRIMARY KEY, col STRING);

-- 表级主键
CREATE TABLE pk_table (id INT, col STRING, PRIMARY KEY (id));

-- 分桶表定义主键
CREATE TABLE pk_table (
    id INT,
    col STRING,
    cluster_key STRING,
    PRIMARY KEY (id)
) CLUSTERED BY (id, cluster_key) SORTED BY (id) INTO 16 BUCKETS;

-- 分区表定义主键
CREATE TABLE pk_table (
    id INT,
    col STRING,
    pt STRING,
    PRIMARY KEY (id, pt)
) PARTITIONED BY (pt);
```

#### 自增列（IDENTITY[(seed)]）

支持指定自增列，无法保证序列值连续（无间隙）或按特定顺序分配。

```sql
CREATE TABLE identity_test (id BIGINT IDENTITY(1), col STRING);
```

#### 生成列（GENERATED ALWAYS AS）

通过表达式自动生成列的值。表达式可包含常量和内置标量确定性函数，**不支持**非确定性函数（如 `current_date`、`random`、`current_timestamp`）、聚合函数、窗口函数或表函数。支持分区列使用生成列。

```sql
CREATE TABLE t_genet (
    col1 TIMESTAMP,
    pt STRING GENERATED ALWAYS AS (date_format(col1, 'yyyy-MM-dd'))
) PARTITIONED BY (pt);
```

#### 默认值（DEFAULT）

为列定义默认值。INSERT/UPDATE/MERGE 未指定该列时自动使用。已存在的数据行填充为 NULL。支持非确定性函数（如 `current_timestamp()`）和常量值。

```sql
CREATE TABLE t_default (id INT, col1 STRING DEFAULT current_timestamp());
```

### 索引定义（index_definition_list）

#### 基本语法

```
INDEX index_name (col_name) index_type [COMMENT 'xxxxxx'] [PROPERTIES('key'='value')]
```

- `index_type`：目前支持 `BLOOMFILTER`、`INVERTED`、`VECTOR`
- `PROPERTIES`：不同索引支持不同参数，参考对应索引文档

### 分区（PARTITIONED BY）

分区通过在写入时将相似的行分组在一起加快查询速度，实现数据裁剪、避免全表扫描。

> **注意**：单个任务写入分区数默认限制 2048，超出报错 `The count of dynamic partitions exceeds the maximum number 2048`。
> 可通过 `SET cz.sql.table.sink.max.partition.per.thread=10000` 修改此限制。
> 建议单分区数据量在百MB到GB级别（如 parquet 格式压缩后 128MB）。

**写法一**：分区字段和类型在列定义中声明，`PARTITIONED BY` 只写字段名：

```sql
CREATE TABLE prod.db.sample (
    id BIGINT,
    category STRING,
    data STRING
) PARTITIONED BY (category);
```

**写法二**：分区字段和类型全部写在 `PARTITIONED BY` 语句中：

```sql
CREATE TABLE prod.db.sample (
    id BIGINT,
    data STRING
) PARTITIONED BY (category STRING);
```

### 分桶表（CLUSTERED BY）

`CLUSTERED BY` 指定 Hash Key，对指定列进行 Hash 运算将数据分散到各数据桶。

- 建议选择取值范围大、重复键值少的列作为 Hash Key
- 一般每个 bucket 大小在 128MB~1GB 之间
- 未指定分桶数默认为 256 buckets
- 建议 `SORTED BY` 和 `CLUSTERED BY` 保持一致以获得最佳性能

```sql
-- 指定分桶和排序
CREATE TABLE sales_data (
    sale_id INT,
    product_id INT,
    quantity_sold INT,
    sale_date DATE
) CLUSTERED BY (product_id)
  SORTED BY (sale_date DESC)
  INTO 50 BUCKETS;

-- 仅指定分桶数
CREATE TABLE sales_data (
    sale_id INT,
    product_id INT,
    quantity_sold INT,
    sale_date DATE
) CLUSTERED BY (product_id)
  INTO 50 BUCKETS;
```

### SORTED BY

`SORTED BY` 可单独使用（表示文件内排序），也可与 `CLUSTERED BY` 配合使用。可加速数据检索，但会增加写入耗时。

```sql
CREATE TABLE sales_data (
    sale_id INT,
    product_id INT,
    quantity_sold INT,
    sale_date DATE
) SORTED BY (sale_date DESC);
```

### PROPERTIES

常用属性：

| 属性 | 说明 |
|------|------|
| `data_lifecycle` | 数据生命周期（天），系统自动清理过期数据 |
| `data_retention_days` | Time Travel 数据保留周期（天），影响 table stream / restore / dynamic table 等功能，默认保留 1 天 |
| `change_tracking` | 是否开启 Table Stream；**建表时指定无效**，需用 ALTER 开启 |
| `partition.cache.policy.latest.count` | 缓存最近 N 个分区到计算集群本地 SSD |

```sql
-- 建表时设置生命周期和数据保留周期
CREATE TABLE historical_prices (
    ticker_symbol STRING,
    trading_date DATE,
    closing_price DECIMAL(10, 2)
) PROPERTIES (
    'data_lifecycle' = '365',
    'data_retention_days' = '7'
);

-- 修改已有表的生命周期
ALTER TABLE historical_prices SET PROPERTIES ('data_lifecycle' = '1');

-- 开启 Table Stream（必须用 ALTER）
ALTER TABLE test_table SET PROPERTIES ('change_tracking' = 'true');

-- 设置分区缓存策略
ALTER TABLE test_table SET PROPERTIES ('partition.cache.policy.latest.count' = '10');
```

### 使用 LIKE 语句建表

复制源表结构，不复制数据。

```sql
CREATE TABLE [ IF NOT EXISTS ] table_name
LIKE source_table
[ COMMENT 'table_comment' ];
```

### 使用 AS 语句建表（CTAS）

基于查询结果创建新表并插入数据。注意：**不会复制分区信息**。

```sql
CREATE TABLE [ IF NOT EXISTS ] table_name
[ AS select_statement ];
```

## 示例

### 1. 分区表

```sql
-- 写法一
CREATE TABLE table_part (id INT, name STRING)
PARTITIONED BY (age INT);

-- 写法二
CREATE TABLE table_fpart (id INT, name STRING, dt STRING)
PARTITIONED BY (dt) COMMENT '分区表';
```

### 2. 自增列商品表

```sql
CREATE TABLE IF NOT EXISTS products (
    product_id BIGINT IDENTITY(1) COMMENT '商品ID',
    name VARCHAR(255) NOT NULL COMMENT '商品名称',
    price DECIMAL(10, 2) NOT NULL COMMENT '价格'
) COMMENT '商品列表';
```

### 3. 生成列（时间戳转日期分区）

```sql
CREATE TABLE IF NOT EXISTS timestamps (
    event_time TIMESTAMP COMMENT '事件发生时间',
    formatted_date STRING GENERATED ALWAYS AS (date_format(event_time, 'yyyy-MM-dd')) COMMENT '格式化后的日期'
) PARTITIONED BY (formatted_date);
```

### 4. 默认值为当前时间戳

```sql
CREATE TABLE IF NOT EXISTS activities (
    activity_id BIGINT NOT NULL COMMENT '活动ID',
    description VARCHAR(255) COMMENT '描述',
    event_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '记录时间'
) COMMENT '活动记录';
```

### 5. Bloom Filter 索引

```sql
CREATE TABLE IF NOT EXISTS search_optimized (
    id BIGINT COMMENT 'ID',
    description VARCHAR(255) COMMENT '关键词',
    INDEX bloom_index (id) BLOOMFILTER COMMENT '布隆过滤器索引'
) COMMENT '用于快速查找的表';
```

### 6. 倒排索引（中文全文检索）

```sql
CREATE TABLE IF NOT EXISTS text_analysis (
    doc_id BIGINT COMMENT '文档ID',
    content TEXT COMMENT '内容',
    INDEX inverted_content (content) INVERTED PROPERTIES ('analyzer' = 'chinese') COMMENT '倒排索引'
) COMMENT '用于文本分析的表';
```

### 7. 分桶 + 排序的销售数据表

```sql
CREATE TABLE IF NOT EXISTS sales_data (
    sale_id BIGINT COMMENT '销售ID',
    product_id BIGINT COMMENT '产品ID',
    quantity_sold INT COMMENT '售出数量',
    sale_date DATE COMMENT '销售日期'
) CLUSTERED BY (product_id)
  SORTED BY (sale_date DESC)
  INTO 50 BUCKETS COMMENT '销售数据表';
```

### 8. 生命周期 + Time Travel 保留

```sql
CREATE TABLE IF NOT EXISTS historical_prices (
    ticker_symbol VARCHAR(10) COMMENT '股票代码',
    trading_date DATE COMMENT '交易日期',
    closing_price DECIMAL(10, 2) COMMENT '收盘价'
) PROPERTIES (
    'data_lifecycle' = '365',
    'data_retention_days' = '1'
) COMMENT '历史股价表';
```

### 9. LIKE 复制表结构

```sql
CREATE TABLE IF NOT EXISTS new_users LIKE users COMMENT '新用户表';
```

### 10. CTAS（查询结果建表）

```sql
CREATE TABLE IF NOT EXISTS recent_sales AS
SELECT * FROM sales WHERE sale_date >= DATE_SUB(CURRENT_DATE, 3);
```

### 11. 复杂类型（ARRAY + STRUCT）

```sql
CREATE TABLE IF NOT EXISTS order_details (
    order_id BIGINT COMMENT '订单ID',
    items ARRAY<STRUCT<item_id:BIGINT, quantity:INT, price:DECIMAL(10, 2)>> COMMENT '商品列表'
) COMMENT '订单详情';
```

### 12. JSON 类型

```sql
CREATE TABLE IF NOT EXISTS customer_feedback (
    feedback_id BIGINT COMMENT '反馈ID',
    feedback JSON COMMENT '反馈内容'
) COMMENT '客户反馈表';
```

## 使用说明

### 分区和分桶最佳实践

- **分区键选择**：选能有效缩小扫描范围的列，时间戳列适合用作日期范围查询分区键
- **分桶数量**：每个 bucket 建议 256MB~1GB；过多或过少均影响性能，建议测试后调整
- **排序字段**：选择频繁出现在过滤条件中的列；排序加速点查和范围查询，但增加写入成本

### 索引

- 可在建表时同时创建多列索引，也可建表后添加
- 建表后添加索引若表中已有数据，需重写所有数据，创建时间取决于数据量

### 表属性最佳实践

- **`data_lifecycle`**：自动清理历史数据，适合日志、交易记录等有明确保留期限的场景
- **`change_tracking`**：开启后支持 Table Stream 获取数据变化，需通过 ALTER 开启（建表时指定无效）
- **`data_retention_days`**：决定被删除数据保留时长，影响 table stream / restore / dynamic table 功能；延长保留周期会增加存储成本
