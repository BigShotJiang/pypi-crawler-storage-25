# IGS Realtime Guide

## Scope

Use this reference for realtime ingestion with Python SDK (`get_realtime_stream`).

## Realtime Behavior Summary

- Data is queryable quickly after write.
- Table stream/materialized view/dynamic table see data after commit window (about one minute per upstream doc).
- Best for short-interval, frequent small writes.

## Mode Selection

- Normal table: `RealtimeOperation.APPEND_ONLY` + `RowOperator.INSERT`
- PK table: `RealtimeOperation.CDC` + (`RowOperator.UPSERT`, `RowOperator.DELETE_IGNORE`)

Do not use APPEND_ONLY for PK table.

## Stream Creation Template

```python
from clickzetta.connector.v0.connection import connect
from clickzetta.connector.v0.enums import RealtimeOperation
from clickzetta_ingestion.realtime.realtime_options import (
    RealtimeOptionsBuilder,
    FlushMode,
)

with connect(...) as conn:
    stream = conn.get_realtime_stream(
        schema="your_schema",
        table="your_table",
        operate=RealtimeOperation.APPEND_ONLY,
        options=RealtimeOptionsBuilder()
            .with_flush_mode(FlushMode.AUTO_FLUSH_BACKGROUND)
            .build(),
    )
    stream.close()
```

## Write Pattern

```python
from clickzetta_ingestion.realtime.arrow_stream import RowOperator

row = stream.create_row(RowOperator.INSERT)
row.set_value("id", 1)
row.set_value("name", "alice")
stream.apply(row)
```

For low-latency checkpoints, call `stream.flush()` intentionally (avoid over-frequent flush).

## Options Tuning

- `with_flush_mode`:
  - `AUTO_FLUSH_BACKGROUND`: high throughput.
  - `AUTO_FLUSH_SYNC`: ordered/sync semantics; required by PK table path.
  - `MANUAL_FLUSH`: controlled by explicit flush.
- `with_mutation_buffer_lines_num`: row trigger threshold.
- `with_mutation_buffer_space`: memory trigger threshold.
- `with_flush_interval`: max delay.
- Retry options:
  - `with_request_failed_retry_enable`
  - `with_request_failed_retry_times`
  - `with_request_failed_retry_internal_ms`
  - `with_request_failed_retry_status`

## Troubleshooting Checklist

1. PK table failure:
- Verify mode is CDC.
- Verify row op is UPSERT/DELETE_IGNORE only.

2. Memory pressure:
- Reduce buffer lines and buffer space.
- Flush by batch boundaries.

3. Too many tiny files:
- Avoid aggressive manual flush per row.
- Increase batch size or interval.
