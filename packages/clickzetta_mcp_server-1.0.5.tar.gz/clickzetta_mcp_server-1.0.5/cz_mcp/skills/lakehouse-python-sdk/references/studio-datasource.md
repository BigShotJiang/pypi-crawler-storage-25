# Python/Shell 任务中使用数据源

Studio 平台支持在 Python/Shell 任务中复用`管理->数据源`中预配置的连接，通过内置的 `clickzetta-dbutils` 包访问，无需在代码中硬编码连接信息。

当前支持：**Lakehouse**、**MySQL**、**PostgreSQL** 数据源。

> 注：当前工作空间的默认 Lakehouse 数据源无需在任务中添加即可直接访问。

## 前置条件

1. 在`管理->数据源`中新建数据源并测试连通。
2. 在 Python/Shell 任务配置面板中选择要使用的数据源。

## 核心 API

### `get_active_engine(ds_name, ...)`

通用函数，支持 MySQL、PostgreSQL、Lakehouse 三类数据源。

```python
from clickzetta_dbutils import get_active_engine

engine = get_active_engine(
    ds_name,           # 必填：数据源名称，与管理->数据源中的名称一致
    vcluster=None,     # Lakehouse 必填：虚拟集群名称
    workspace=None,    # 工作空间，默认当前工作空间
    schema=None,       # schema，默认 'public'
    options=None,      # 额外连接选项（dict）
    query=None,        # SQLAlchemy URL 额外查询参数（dict）
)  # 返回 SQLAlchemy Engine
```

### `get_active_lakehouse_engine(...)`

专用于 Lakehouse 数据源（使用内置默认 Lakehouse 数据源时推荐）。

```python
from clickzetta_dbutils import get_active_lakehouse_engine

engine = get_active_lakehouse_engine(
    vcluster,          # 必填：虚拟集群名称
    workspace=None,    # 工作空间
    schema=None,       # schema，默认 'public'
)

with engine.connect() as conn:  # this connection is SQLAlchemy Connection object, not ClickZetta Connection object
    ...
```

### `DatabaseConnectionManager` (Builder 模式)

```python
from clickzetta_dbutils import DatabaseConnectionManager

engine = DatabaseConnectionManager("ds_name") \
    .use_vcluster("default") \
    .use_workspace("my-workspace") \
    .use_schema("public") \
    .use_options({"charset": "utf8"}) \
    .build()
```

## 代码示例

### PostgreSQL

```python
from sqlalchemy import text
from clickzetta_dbutils import get_active_engine

# 默认 schema
engine = get_active_engine("my_pg_source")
with engine.connect() as conn:
    result = conn.execute(text("SELECT * FROM my_table LIMIT 10;"))
    for row in result:
        print(row)

# 指定 database 和 schema
engine = get_active_engine("my_pg_source",
                           schema="my_database",
                           options={"search_path": "my_schema"})
```

### MySQL

```python
from sqlalchemy import text
from clickzetta_dbutils import DatabaseConnectionManager

engine = DatabaseConnectionManager("my_mysql_source") \
    .use_schema("my_db") \
    .build()

with engine.connect() as conn:
    result = conn.execute(text("SELECT * FROM my_table LIMIT 10;"))
    for row in result:
        print(row)
```

### Lakehouse

```python
from sqlalchemy import text
from clickzetta_dbutils import get_active_engine, get_active_lakehouse_engine

# 方式一：通过数据源名称
engine = get_active_engine("my_lakehouse_source",
                           vcluster="default",
                           workspace="my-workspace",
                           schema="public")

# 方式二：使用默认内置 Lakehouse 数据源
engine = get_active_lakehouse_engine(vcluster="default", schema="public")

with engine.connect() as conn:
    result = conn.execute(text("SELECT * FROM my_table LIMIT 10;"))
    for row in result:
        print(row)
```

使用 get_lakehouse_connection 获取原生连接对象执行特定操作：
```python
engine = get_active_lakehouse_engine(vcluster="default", schema="public")

with engine.connect() as conn:
    lh_conn = get_lakehouse_connection(connection)
    cursor = lh_conn.cursor()
    cursor.execute("create table if not exists zhanglin_test_schema.test_vector_1634020000000 (a int, b int)")
    for row in result:
        print(row)
```

### Shell 任务

```bash
cat >> /tmp/run_query.py << EOF
from sqlalchemy import text
from clickzetta_dbutils import get_active_engine

engine = get_active_engine("my_pg_source")
with engine.connect() as conn:
    result = conn.execute(text("SELECT count(*) FROM my_table;"))
    for row in result:
        print(row)
EOF

python /tmp/run_query.py
```

## 注意事项

- 使用 Lakehouse 数据源时 `vcluster` 必填。
- 使用不存在的数据源名称会报错，确保任务配置面板中已选择对应数据源。
- PostgreSQL 的 `schema` 参数填写 database 名称，实际 schema 通过 `options={"search_path": "..."}` 指定。
- 同一任务中可同时使用多个不同类型的数据源。
