# BulkLoad All Data Type Patterns

## Source Scope

Primary pattern source:
- `tests.ingestion.bulkload.test_bulkload_v2_e2e_advanced.AllDataTypeRowConsumer`

Although this is from v2 advanced e2e tests, it is a strong reference for modeling `row.set_value(...)` payload shapes across complex data types.

Before applying this file, read:
- `references/data-type-support-policy.md`

## Practical Row Value Shapes

1. Primitive:
- `boolean` -> `bool`
- `tinyint/smallint/int/bigint` -> `int`
- `float/double` -> `float`
- `decimal` -> `Decimal`
- `string` -> `str`
- `binary` -> `bytes`
- `timestamp/timestamp_ltz/timestamp_ntz` -> `datetime`
- `date` -> `date`
- `vector` -> numeric sequence (for example `list[float]`, must match target dimension)

2. Array:
- `array<int>` -> `list[int]`
- `array<string>` -> `list[str]`
- nested arrays allow nested list and optional `None` element
- `array<decimal>` -> `list[Decimal]`
- `array<timestamp>` -> `list[datetime]`
- `array<date>` -> `list[date]`

3. Map:
- scalar map keys/values use `dict`
- nested map/array values use nested `dict/list`
- for non-hashable logical keys (for example array/map as key), tests use tuple-like Python representation.

4. Struct:
- `struct<...>` -> `dict` with field names
- nested struct -> nested `dict`

5. Bitmap:
- preferred object: `pyroaring.BitMap64(...)` when available
- fallback forms seen in tests: comma-separated string or bytes/list in specific scenarios

6. Special column names:
- Columns with special characters are set by exact literal column name in `set_value`.

## Explicit Compatibility Constraints

1. SQL `DATETIME` is not supported in this skill guidance.
2. Use `TIMESTAMP`, `TIMESTAMP_LTZ`, `TIMESTAMP_NTZ` for time fields.
3. For `VECTOR`, verify numeric element type and exact dimension before write.

## Minimal Example

```python
from datetime import date, datetime, timedelta
from decimal import Decimal

row.set_value("v_bool", True)
row.set_value("v_int", 123)
row.set_value("v_decimal", Decimal("123.456")) # Must be Decimal, not float, to preserve precision
row.set_value("v_timestamp", datetime.utcnow())
row.set_value("v_date", date.today())
row.set_value("v_vector", [0.1, 0.2, 0.3])  # Example only; dimension must match table definition
row.set_value("v_array_string", ["a", "b"])
row.set_value("v_map_s_i", {"k": 1})
row.set_value("v_struct", {"b_sub1": 1, "b_sub2": 2, "b_sub3": "x"})
row.set_value("v_binary", b"abc")
```

## Cautions

1. This reference is pattern guidance, not a blanket compatibility guarantee for every version.
2. Prefer validating representative rows against actual target table schema.
3. For complex key types (array/map as key), keep serializer behavior verified in local tests before production run.
