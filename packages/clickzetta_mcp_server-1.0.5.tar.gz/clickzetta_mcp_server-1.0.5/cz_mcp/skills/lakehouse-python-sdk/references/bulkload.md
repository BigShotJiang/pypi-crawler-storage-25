# BulkLoad stream Guide

## Scope

Use this reference for high-throughput batch upload with `create_bulkload_stream`.

For verified behavior details and type patterns (lakehouse engine`s sql datatype), also read:
- `references/bulkload-behaviors.md`
- `references/bulkload-all-data-type-patterns.md`

## Core Workflow

1. Create connection.
2. Create bulkload stream (`schema`, `table`, optional `operation`, `partition_spec`).
3. Open writer(s) with unique shard id.
4. Build row by row and `writer.write(row)`.
5. Close all writers.
6. Commit stream once after all writers finish.

## Base Example

```python
from clickzetta import connect

conn = connect(...)
stream = conn.create_bulkload_stream(schema="public", table="bulkload_test")
writer = stream.open_writer(0)

for i in range(100000):
    row = writer.create_row()
    row.set_value("i", i)
    row.set_value("s", "hello")
    writer.write(row)

writer.close()
# Note that after `commit()`, the stream and writer are finalized; to write more data, you must create a new stream and writer instance.
stream.commit()
```

## Operation Mode

- `APPEND` (default): append data.
- `OVERWRITE`: replace target partition/table data.

For partition tables:
- Static partition: set `partition_spec="pt=2026-04-03"` style.
- Dynamic partition: do not pass `partition_spec`.

## Performance Playbook (Production Notes)

Apply these before deep tuning:

1. Enable debug logging in task runtime:

```python
import logging

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    force=True,
)
log = logging.getLogger(__name__)
```

3. Create stream inside each thread worker to reduce commit serialization bottleneck.

   **Stream lifecycle must be self-contained per worker.**
   Each worker owns the full lifecycle: `create_bulkload_stream → open_writer → write → writer.close → stream.commit`.
   Do NOT share one stream across multiple workers or commit from the outer scope.

   ❌ Wrong pattern (shared stream, external commit):
   ```python
   # stream created outside workers — commit is serialized and blocks all workers
   stream = conn.create_bulkload_stream(...)
   with ThreadPoolExecutor() as pool:
       for sid in range(n):
           pool.submit(write_shard, stream, sid, ...)  # stream shared across workers
   stream.commit()   # commit outside — all writers must finish before this runs
   ```

   ✅ Correct pattern (stream per worker, fully parallel):
   ```python
   def write_shard(conn, shard_id, data):
       stream = conn.create_bulkload_stream(...)  # each worker owns its stream
       writer = stream.open_writer(shard_id)
       for row_dict in data:
           row = writer.create_row()
           for col, val in row_dict.items():
               if val is not None:
                   row.set_value(col, val)
           writer.write(row)
       writer.close()
       stream.commit()   # commit inside worker — parallel across all workers
   ```

4. Set `prefer_internal_endpoint=True` in `create_bulkload_stream(...)`.
5. Use unique shard id per worker; never share one shard id across concurrent writers.

## Optimized Parallel Pattern

```python
import time

def write_shard(conn, shard_id, your_data):
    t0 = time.time()
    stream = conn.create_bulkload_stream(
        schema="your_schema",
        table="your_table",
        prefer_internal_endpoint=True,
    )
    writer = stream.open_writer(shard_id)
    count = 0

    row_dict_list = [row for row in your_data]
    for row_dict in row_dict_list:
        row = writer.create_row()
        for col, val in row_dict.items():
            if val is not None:
                row.set_value(col, val)
        writer.write(row)
        count += 1

    writer.close()
    stream.commit()
    return count, time.time() - t0

from concurrent.futures import ThreadPoolExecutor, as_completed

def run_parallel_write(conn, gen_fn, dt_str, total_rows, workers=8):
    shard_size = (total_rows + workers - 1) // workers
    futures = []
    results = []

    with ThreadPoolExecutor(max_workers=workers) as pool:
        for shard_id in range(workers):
            shard_offset = shard_id * shard_size
            shard_n = min(shard_size, total_rows - shard_offset)
            if shard_n <= 0:
                break
            shard_data = gen_fn(dt_str, shard_n, shard_offset)
            futures.append(pool.submit(write_shard, conn, shard_id, shard_data))

        for future in as_completed(futures):
            written, elapsed = future.result()
            results.append((written, elapsed))

    total_written = sum(w for w, _ in results)
    max_elapsed = max((e for _, e in results), default=0.0)
    return total_written, max_elapsed, results

# usage
# total_written, max_elapsed, shard_results = run_parallel_write(
#     conn=conn,
#     gen_fn=gen_fn,
#     dt_str="2026-04-04",
#     total_rows=5_000_000,
#     workers=8,
# )
```

## Anti-Patterns

- Committing repeatedly in a tight loop.
- Reusing shard id across concurrent workers.
- Forgetting `writer.close()` before `commit()`.
- Creating too many tiny shards causing small-file amplification.
- Sharing one stream across multiple concurrent workers and committing from the outer scope — this serializes the commit, eliminates parallelism, and can cause write contention. Always create stream inside each worker.
