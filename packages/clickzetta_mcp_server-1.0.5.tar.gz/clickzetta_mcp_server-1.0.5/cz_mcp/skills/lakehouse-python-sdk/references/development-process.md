# Development Process (Production)

## Goal

Deliver production-ready Lakehouse Python task changes with explicit gates.

## Gate Sequence

1. Requirement clarification
2. Technical design and code implementation
3. Local verification
4. User authorization for temporary execution
5. Temporary execution and result verification
6. Plan/task save and final confirmation

Do not jump directly to task save without gates 1-5.

## Deliverables Per Gate

1. Clarification notes:
- Business objective
- Input/output table and schema
- Schedule, retry, dependency requirements
- Acceptance criteria

2. Implementation output:
- Python code (mode-specific: connector/bulkload/igs)
- Parameter strategy
- Resource and dependency notes

3. Local verification evidence:
- Mandatory syntax pass (`python3 -m py_compile ...`)
- Mandatory logic-execution pass (sample/mock run with assertions)
- Dry-run/mock result
- Edge-case check summary

4. Authorization evidence:
- Explicit user confirmation for temporary execution

5. Temporary run evidence:
- Runtime logs
- Row count or key result
- Failure reason and fix (if any)

6. Plan-save evidence:
- Saved task id/name/folder
- Schedule and params snapshot
- Final user confirmation
