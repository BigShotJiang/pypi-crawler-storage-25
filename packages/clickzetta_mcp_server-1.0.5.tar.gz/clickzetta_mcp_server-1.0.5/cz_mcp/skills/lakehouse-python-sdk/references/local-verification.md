# Local Verification

## Rule

Complete local verification before any temporary execution in Studio.
Syntax verification is mandatory after development and before any temporary execution/plan save.
Execution-logic verification is also mandatory; syntax-only checks are insufficient.

## Pre-check: Must Follow Skill Templates

Before running any verification, confirm generated code stays within skill templates:

1. Connection entry is template-compliant:
- `from clickzetta import connect` (connector mode), or
- `from clickzetta_dbutils import ...` (datasource mode).

2. BulkLoad call chain is template-compliant:
- `conn.create_bulkload_stream -> open_writer -> create_row/set_value/write -> writer.close -> stream.commit`.

3. No out-of-skill APIs:
- Do not introduce third-party APIs/modules not covered by skill references.

If any pre-check item fails, stop verification and return to Gate 2 to regenerate code against references.

## Minimum Checks

1. Mandatory syntax check:
- `python3 -m py_compile <script.py>`
- If this step fails, stop and fix code first. Do not continue to execution or plan save.

2. Mandatory execution-logic test:
- Run executable logic path with sample data or mock/stub dependencies.
- Must include at least one deterministic assertion on expected behavior/result.
- AST parse or compile-only output does not satisfy this check.

3. Basic functional dry-run:
- Run with a tiny sample input or mocked generator for end-to-end control flow.
- For bulkload/igs code, validate row construction and control flow locally.

4. Guard checks:
- Null handling and type conversion path.
- Resource closing path (`close`/`finally`).
- Retry/timeout related control path.

## Mode-Specific Quick Checks

### Connector
- SQL parameter binding uses placeholders, not string concat.
- Cursor lifecycle is explicit.

### Bulkload
- Writer id/shard id uniqueness in concurrent path.
- `writer.close()` before `stream.commit()`.

### IGS
- PK table uses CDC mode.
- RowOperator matches mode constraints.

## Verification Evidence Format

Provide compact evidence:
- Command run
- Pass/fail
- Key output line(s)
- Assertion evidence (what was asserted and pass result)

## Blocking Condition

If syntax check or logic-execution check has no pass evidence, verification is incomplete and the task cannot move to execution authorization.
