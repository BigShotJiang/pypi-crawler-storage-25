# BulkLoad Verified Behaviors

## Source Scope

This note is extracted from integration test patterns in:
- `tests/ingestion/bulkload/test_bulkload_writer_v1.py`

Use these behaviors as practical constraints when generating or reviewing bulkload code.

For type-level policy, read:
- `references/data-type-support-policy.md`

## Verified Semantics

1. Stream lifecycle:
- Write path is `create_bulkload_stream -> open_writer -> create_row/set_value/write -> writer.close -> stream.commit`.
- `get_bulkload_stream(..., stream_id=...)` can attach to the same stream id and continue writing with a different writer id.

2. Multi-writer/distributed path:
- Multiple writers with unique writer ids can write into one stream.
- distributed flow uses commit options including workspace/vcluster.

3. Timestamp null handling:
- `None` (and NaT-like null input) on timestamp column is persisted as SQL `NULL`.
- Do not coerce missing timestamp to string literals.

4. Static partition override:
- When stream is created with static `partition_specs`, row-level partition values are overridden by static partition spec.
- Do not expect row partition field to take effect in static partition mode.

5. Identity column in APPEND:
- For identity/autoincrement column, omit identity field in `row.set_value(...)`.
- Backend generates identity values.

6. UPSERT with non-PK identity:
- In UPSERT mode, provide `record_keys` for primary key columns.
- `partial_update_columns` can update selected data fields.
- Non-PK identity column remains auto-generated and should not be set by user.

## Code Review Checklist

1. Unique writer id per concurrent worker.
2. Explicit `writer.close()` before `stream.commit()`.
3. Partition mode is explicit (static vs dynamic) and expectations match.
4. Identity column is not manually set when auto-generated.
5. UPSERT includes `record_keys`; `partial_update_columns` only includes intended mutable columns.
6. SQL `DATETIME` is disallowed; use `TIMESTAMP` / `TIMESTAMP_LTZ` / `TIMESTAMP_NTZ`.
7. For `VECTOR` fields, verify vector dimension and numeric element type before writing.
8. Stream lifecycle is self-contained per worker: `create_bulkload_stream`, `open_writer`,
   `writer.close()`, and `stream.commit()` must all reside in the same worker function.
   Never share a stream instance across concurrent workers or commit from the outer scope —
   this serializes the commit phase and eliminates write parallelism.
