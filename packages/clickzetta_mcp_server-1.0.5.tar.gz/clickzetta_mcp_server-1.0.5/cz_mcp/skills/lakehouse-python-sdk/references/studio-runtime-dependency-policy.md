# Studio Runtime Dependency Policy

## Goal

Avoid unnecessary runtime dependency installation in Studio Python tasks.

## Default Behavior

Do not install dependencies at runtime by default.

## Install Trigger Rules

Run runtime install only when any condition is true:

1. User explicitly asks to install or upgrade package.
2. Current script actually fails with missing package error (`ModuleNotFoundError`).
3. User explicitly requires a pinned package version not guaranteed in runtime.

If none of the above is true, keep code without install block.

## Safe Install Template (Only When Triggered)

```python
import subprocess
import sys

TARGET_DIR = "/home/system_normal"
subprocess.check_call([
    sys.executable, "-m", "pip", "install",
    "config",
    "--target", TARGET_DIR,
])
sys.path.insert(0, TARGET_DIR)
```

## Rewrite Rules for the Agent

When rewriting user code:

1. Preserve existing imports first.
2. Add runtime install block only if trigger rules are satisfied.
3. If adding install block, add one short comment explaining why it is required.
4. Do not auto-add install block for every new Studio Python task.
