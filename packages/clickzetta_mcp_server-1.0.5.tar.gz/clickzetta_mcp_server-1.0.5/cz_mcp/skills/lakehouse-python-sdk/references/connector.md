# Connector Guide

## Profile Setup

Connection info is the prerequisite for connector, BulkLoad, and IGS — always resolve it first.

**Step 1: List all profiles with secrets to get connection fields**

```bash
cz-cli profile list --show-secret
```

This outputs all saved profiles with plaintext credentials. Extract `username`, `password`, `service`, `instance`, `workspace`, `schema`, `vcluster` from the output and fill them directly into the connection template. Do not ask the user to fill in connection fields manually.

**Step 2: If no profile exists, check a specific profile by name**

```bash
cz-cli profile show NAME
```

**Step 3: If still no profile, guide the user to create one**

The JDBC URL can be copied from:
**Studio 数据平台 → 管理 → 工作空间 → 对应工作空间 → 连接配置**

```bash
cz-cli profile create --jdbc "jdbc:clickzetta://<instanceName>.api.clickzetta.com/<workspaceName>?username=<user>&password=<password>&schema=public&virtualCluster=default"
```

> **Sandbox note**: If running in an agent sandbox (e.g. Claude Code, Codex), `cz-cli` requires outbound network access to reach the Lakehouse API. Ensure the sandbox has external network access enabled, or run with elevated/privileged mode. Otherwise, run `cz-cli profile show` outside the sandbox and paste the output.

## Scope

Use this reference for Python task code based on `clickzetta-connector`:
- Build connection and run SQL
- Rewrite existing SQL task code to connector style
- Optimize execution path (binding params, async query, error handling)

## Runtime Dependency Install Policy (Studio develop)

Default rule: do not execute runtime `pip install` unless user explicitly requires it.

Use runtime install only when:
- User explicitly asks to install/upgrade package.
- Runtime throws missing package error (`ModuleNotFoundError`).
- User explicitly asks for a specific pinned version.

If install is required, use this template:

```python
import subprocess
import sys

TARGET_DIR = "/home/system_normal"
subprocess.check_call([
    sys.executable, "-m", "pip", "install",
    "your-package-name",
    "--target", TARGET_DIR,
    # "-i", "https://pypi.tuna.tsinghua.edu.cn/simple",  # optional mirror
])
sys.path.insert(0, TARGET_DIR)
```

For the full decision workflow, see:
`references/studio-runtime-dependency-policy.md`

## Connection Template
1. Enable SDK INFO logging in task runtime:

```python
import logging

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    force=True,
)
log = logging.getLogger(__name__)
```

```python
from clickzetta import connect

conn = connect(
    username="your_username",
    password="your_password",
    service="region_id.api.clickzetta.com",
    instance="your_instance",
    workspace="your_workspace",
    schema="public",
    vcluster="default",
)
```
> You should obtain the user configuration and fill it in to reduce the user's configuration work.

Required fields:
- `username`, `password`
- `service`, `instance`, `workspace`
- `schema`, `vcluster`

## Query Patterns

### Basic execute/fetch

```python
cursor = conn.cursor()
cursor.execute("SELECT * FROM your_table LIMIT 10")
rows = cursor.fetchall()
```

### Parameter binding

- `qmark`: `?` placeholder + `binding_params=[...]`
- `pyformat`: `%(name)s` placeholder

Prefer `qmark` when rewriting legacy string-concat SQL to reduce injection risk.

### Batch insert

```python
data = [(1, "a"), (2, "b")]
cursor.executemany("INSERT INTO t (id, name) VALUES (?, ?)", data)
```

### Async execution

```python
import time

cursor.execute_async("SELECT * FROM large_table")
while not cursor.is_job_finished():
    time.sleep(1)
rows = cursor.fetchall()
```

## Rewrite Checklist

1. Replace hardcoded SQL concatenation with parameter binding.
2. Keep connection and cursor lifecycle explicit (`close` in `finally` or context).
3. Keep hints/timeout in `parameters` when needed.
4. Preserve result schema handling when rewriting loops.
5. Remember connector does not provide `commit`/`rollback` transaction semantics.
