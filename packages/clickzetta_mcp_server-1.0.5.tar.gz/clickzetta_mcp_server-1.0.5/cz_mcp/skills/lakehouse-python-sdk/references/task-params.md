# Studio 任务参数

Studio 平台支持在 SQL/Python/Shell 任务中使用动态参数，运行时自动替换。

## 参数语法

代码中用 `${参数名}` 引用，参数名只能包含字母、数字、下划线。

```python
# Python 任务示例
yesterday = '${yesterday}'   # 字符串类型加引号
start_ts = ${start_ts}       # 数值类型不加引号
task_name = '${task_name}'
```

## 系统内置参数

直接用于参数赋值（不能在代码中直接引用，需通过自定义参数中转）：

| 参数名 | 格式 | 说明 | 示例（基准 2023-09-22 18:00:00） |
|--------|------|------|-------------------------------|
| bizdate | yyyyMMdd | 业务日期（计划时间-1天） | 20230921 |
| sys_biz_day | yyyy-MM-dd | 业务日期 | 2023-09-21 |
| sys_biz_datetime | yyyy-MM-dd HH:mm:ss | 业务时间 | 2023-09-21 18:00:00 |
| sys_plan_day | yyyy-MM-dd | 计划日期 | 2023-09-22 |
| sys_plan_datetime | yyyy-MM-dd HH:mm:ss | 计划时间 | 2023-09-22 18:00:00 |
| sys_plan_timestamp | 13位毫秒时间戳 | 计划时间戳 | 1695463200000 |
| sys_task_id | 整数 | 任务ID（仅调度运行） | 1002 |
| sys_task_name | 字符串 | 任务名称（仅调度运行） | demo_task |
| sys_task_owner | 字符串 | 任务负责人（仅调度运行） | UAT_TEST |

## 时间表达式

```
$[时间格式]                    # 基本格式化
$[时间格式, 偏移量]             # 带偏移量
$[时间格式, 偏移1, 偏移2, ...]  # 多个偏移量（依次计算）
```

时间格式遵循 ISO-8601，**严格区分大小写**：

| 元素 | 含义 | 正确 | 错误 |
|------|------|------|------|
| yyyy | 四位年 | yyyy | YYYY |
| MM | 月（01-12） | MM | mm（mm是分钟） |
| dd | 日（01-31） | dd | DD |
| HH | 24小时制 | HH | hh（hh是12小时制） |
| mm | 分钟 | mm | - |
| ss | 秒 | ss | - |

偏移量单位：`ms`(毫秒) `s`(秒) `m`(分钟) `h`(小时) `d`(天) `w`(周) `mon`(月) `y`(年)

常用示例（基准 2023-09-22）：

```
$[yyyy-MM-dd]              → 2023-09-22
$[yyyy-MM-dd, -1d]         → 2023-09-21（昨天）
$[yyyy-MM-dd, -1mon]       → 2023-08-22（上月同一天）
$[yyyy-MM-dd, -1y, -1d]    → 2022-09-21（去年昨天）
$[yyyyMMdd]                → 20230922
$[yyyy-MM-dd HH:mm:ss]     → 2023-09-22 18:00:00
```

## 内置时间函数

| 函数 | 功能 | 示例 |
|------|------|------|
| `first_day_of_month()` | 当月第一天 | `first_day_of_month('yyyy-MM-dd', '-1mon')` → 上月第一天 |
| `last_day_of_month()` | 当月最后一天 | `last_day_of_month()` |
| `first_day_of_week()` | 当周周一 | `first_day_of_week('yyyy-MM-dd', '-1w')` → 上周一 |
| `last_day_of_week()` | 当周周日 | `last_day_of_week()` |
| `get_day_of_week(fmt, n)` | 本周第n天 | `get_day_of_week('yyyy-MM-dd', 2)` → 本周二 |
| `day_of_week()` | 今天是周几（1-7） | `day_of_week()` |
| `timestamp()` | 毫秒时间戳 | `timestamp(-1d)` → 昨天此刻时间戳 |
| `biz_timestamp()` | 业务时间戳（基于00:00:00） | `biz_timestamp()` |
| `unix_timestamp()` | 秒时间戳 | `unix_timestamp()` |

## Python 任务使用示例

```python
# 参数配置：yesterday = $[yyyy-MM-dd, -1d]
#           start_ts  = biz_timestamp()
#           task_name = sys_task_name

yesterday = '${yesterday}'
start_ts = ${start_ts}
task_name = '${task_name}'

print(f"处理日期: {yesterday}, 任务: {task_name}")

sql = f"""
    SELECT * FROM orders
    WHERE dt = '{yesterday}'
      AND create_time >= {start_ts}
"""
```

## 常用速查

| 需求 | 参数赋值 |
|------|---------|
| 昨天 | `$[yyyy-MM-dd, -1d]` 或 `sys_biz_day` |
| 本月第一天 | `first_day_of_month()` |
| 上月第一天 | `first_day_of_month('yyyy-MM-dd', '-1mon')` |
| 上月最后一天 | `last_day_of_month('yyyy-MM-dd', '-1mon')` |
| 上周一 | `first_day_of_week('yyyy-MM-dd', '-1w')` |
| 上周日 | `last_day_of_week('yyyy-MM-dd', '-1w')` |
| 毫秒时间戳 | `timestamp()` 或 `sys_plan_timestamp` |
