# Requirement Clarification

## Rule

Ask interactively before coding when any key field is missing.

## Mandatory Clarification Fields

1. Business goal and expected output.
2. Data source and target (table/schema/workspace).
3. Task type and mode (`connector`, `bulkload`, `igs`).
4. Schedule strategy:
- ad-hoc/manual or scheduled
- cron/time window
5. Retry and timeout requirements.
6. Upstream dependency requirements.
7. Acceptance criteria:
- correctness metric
- performance metric

## Suggested Question Set

1. "这次任务的目标结果是什么，最终要产出到哪张表？"
2. "你希望用 connector、bulkload 还是 igs？如果不确定我可以按数据量和时效帮你选。"
3. "任务需要调度吗？如果需要，请给 cron、开始时间、结束时间。"
4. "失败重试次数和间隔是否有要求？"
5. "验收标准是什么（例如行数、时延、完成时间）？"

## Completion Criteria

Enter implementation only after mandatory fields are clear or explicitly assumed with user confirmation.
