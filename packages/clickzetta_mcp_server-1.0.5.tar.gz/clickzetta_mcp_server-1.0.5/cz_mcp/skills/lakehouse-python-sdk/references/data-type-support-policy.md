# Data Type Support Policy

## Goal

Make type compatibility explicit when generating or reviewing Lakehouse Python ingest code.

## SQL Type Policy (Important)

1. Do not use SQL `DATETIME` type.
2. Use only timestamp family:
- `TIMESTAMP`
- `TIMESTAMP_LTZ`
- `TIMESTAMP_NTZ`
3. `VECTOR` is supported and should be handled explicitly.

## Python Value Mapping (Guideline)

- `TIMESTAMP` / `TIMESTAMP_LTZ` / `TIMESTAMP_NTZ` -> Python `datetime`
- `DATE` -> Python `date`
- `DECIMAL` -> Python `Decimal`
- `VECTOR` -> numeric sequence (for example `list[float]`) with dimension matching table definition

## Validation Rules

1. Reject or rewrite any design that introduces SQL `DATETIME`.
2. Verify timestamp column names and semantics are aligned with target table definition.
3. Verify vector payload shape:
- element type is numeric
- dimension matches target vector column definition

## Review Prompt

When reviewing generated code, always answer:
- "是否出现了 DATETIME 字段？如果有，改为 TIMESTAMP 系列。"
- "VECTOR 字段是否按目标维度写入，并且元素是数值类型？"
