# Plan Save Python Task

## Goal

Save validated Python implementation into planned/scheduled task configuration.

## Save Sequence

1. Confirm final code version to save.
2. Confirm task metadata:
- task name
- folder/project
- owner

3. Confirm scheduling:
- cron
- start/end time
- timezone (if applicable)

4. Confirm runtime policy:
- retry count and interval
- timeout
- dependency policy (default no runtime install unless triggered)

5. Confirm parameters and dependencies:
- task params (for example `${sys_biz_day}` derived values)
- upstream task dependency list

6. Save task content and schedule config.
7. Read back saved config and send final summary to user.

## Final Confirmation Template

`计划任务已保存。请确认以下最终配置是否正确：任务名、调度周期、重试策略、参数映射、上游依赖。`
