---
name: lakehouse-python-sdk
description: "Lakehouse Python/Shell task engineering: develop, rewrite, optimize, troubleshoot; Covers connector (SQL access; prerequisite connection for BulkLoad and IGS), BulkLoad batch upload, IGS realtime ingest, Studio params, datasource, and CREATE TABLE DDL; MUST trigger on: develop/write/create/modify/rewrite/optimize Python or Shell task; BulkLoad batch upload; IGS realtime ingest; connector query/write; Python task error/diagnosis; CREATE TABLE/partition/bucket/index DDL. DO NOT trigger on: pure SQL queries; Zettapark API; non-clickzetta SDKs."
---

# Lakehouse Python SDK

Implement and optimize Lakehouse Python tasks with a production process and explicit quality gates.

## Mandatory Process Gates

Follow this sequence. Do not skip gates.

1. Clarify requirements interactively with user first.
- Use `references/requirement-clarification.md`.
- Confirm business goal, source/target table, schedule, retries, dependencies, and acceptance criteria.
- If key information is missing, ask before coding.

2. Select technical mode and implement code.
- `connector`: `references/connector.md`
- `bulkload`: `references/bulkload.md`
- `igs`: `references/igs.md`
- `task-params`: `references/task-params.md`
- `studio-datasource`: `references/studio-datasource.md`

3. Complete local development verification before any remote/studio execution.
- Use `references/local-verification.md`.
- MUST run syntax check after development.
- If syntax check fails, stop and fix before any temporary execution or plan save.
- Keep evidence of checks.

4. Ask explicit permission before temporary execution.
- Use `references/execution-authorization.md`.
- Ask user whether temporary execution is allowed.
- Do not run temporary task/job until approved.

5. After verification and approval, run temporary execution and verify result.
- Record runtime logs, row counts, and key output.
- If execution fails, diagnose and iterate before plan-save.

6. Save finalized Python task into plan/schedule.
- Use `references/plan-save-python-task.md`.
- Save task code, schedule, params, retries, dependencies, and verification summary.

## Runtime Dependency Rule

Default behavior is **do not install dependency at runtime**.
Only install when explicit trigger conditions are satisfied.

Use:
`references/studio-runtime-dependency-policy.md`

## Safety Rules

- Do not print or hardcode credentials in generated code.
- For PK tables with realtime ingest, use CDC mode only.
- Avoid high-frequency commit/flush unless latency requirement explicitly demands it.
- Stream lifecycle must be self-contained per worker: `create_bulkload_stream`, `open_writer`, write loop, `writer.close()`, and `stream.commit()` must all reside in the same worker function scope. Never share a stream across concurrent workers or delay commit to the outer scope — this serializes the commit phase and eliminates write parallelism.
- Do not bypass user confirmation gate for temporary execution.

## References

- `references/development-process.md`: End-to-end production development process and quality gates.
- `references/requirement-clarification.md`: Interactive requirement clarification checklist and question template.
- `references/local-verification.md`: Local dev verification checklist and evidence standard.
- `references/execution-authorization.md`: Permission gate before temporary execution.
- `references/plan-save-python-task.md`: Save Python task into plan/schedule with final confirmation.
- `references/connector.md`: Connector connect/query, parameter binding, async notes.
- `references/bulkload.md`: BulkLoad batch upload workflow, shard pattern, performance optimization playbook.
- `references/bulkload-behaviors.md`: Verified BulkLoad batch upload semantics from integration tests (partition override, NaT/NULL, identity, upsert).
- `references/bulkload-all-data-type-patterns.md`: Practical all-data-type row writing patterns.
- `references/data-type-support-policy.md`: Explicit type support policy (no DATETIME; use timestamp family; vector constraints).
- `references/igs.md`: Realtime stream modes, options tuning, PK constraints.
- `references/studio-runtime-dependency-policy.md`: Runtime dependency install policy (default no install).
- `references/task-params.md`: Studio task parameters — system built-in params, time expressions, time functions.
- `references/studio-datasource.md`: Use MySQL/PostgreSQL/Lakehouse datasources in Python/Shell tasks via `clickzetta_dbutils`.
- `references/create-table-ddl.md`: CREATE TABLE DDL full reference — syntax, column types, PRIMARY KEY, IDENTITY, GENERATED AS, DEFAULT, indexes (BLOOMFILTER/INVERTED/VECTOR), PARTITIONED BY, CLUSTERED BY, SORTED BY, PROPERTIES (data_lifecycle / data_retention_days / change_tracking), LIKE, CTAS, and best practices.
