---
name: timetravel-restore
description: |
  ClickZetta Lakehouse 数据恢复助手，通过 Time Travel 功能恢复误操作的表数据。
  当用户说"误操作了表"、"数据被误删"、"数据被误覆盖"、"需要恢复数据"、"数据恢复"、"回滚数据"、
  "time travel 恢复"、"INSERT OVERWRITE 写错了"、"DELETE 删错了"、"UPDATE 改错了"、
  "表数据恢复到某个时间点"时，必须使用此 skill。
  引导用户完成：查看历史版本 → 选择恢复时间点 → 验证数据可用 → 选择恢复方式（原表覆盖 or 新表对比）→ 执行恢复。
---

# ClickZetta Time Travel 数据恢复助手

帮助用户通过 Time Travel 功能恢复误操作的表数据。严格按照以下步骤执行，不要跳过任何确认环节。

## Time Travel 背景知识

ClickZetta 的 Time Travel 功能允许查询和恢复表的历史版本数据。

**核心语法：**
```sql
-- 查看表的历史版本（版本号、时间、行数、操作类型）
DESC HISTORY <table_name> [LIMIT n]

-- 时间旅行查询（验证某个历史版本的数据）
-- 注意：timestamp 必须精确匹配 DESC HISTORY 中显示的时间（含毫秒，格式 YYYY-MM-DD HH:MM:SS.mmm）
SELECT COUNT(*) as row_count FROM <table_name> TIMESTAMP AS OF '<exact_timestamp>'

-- 恢复到原表（直接覆盖）
RESTORE TABLE <table_name> TO TIMESTAMP AS OF '<exact_timestamp>'

-- 恢复到新表（CREATE TABLE AS SELECT）
CREATE TABLE <new_table_name> AS SELECT * FROM <source_table> TIMESTAMP AS OF '<exact_timestamp>'
```

**重要限制：**
- Time Travel 保留期通常为 7 天，超出保留期的版本无法恢复
- `TIMESTAMP AS OF` 的时间戳必须精确匹配 DESC HISTORY 中的时间（含毫秒），否则报 "version not found"
- `RESTORE TABLE` 需要用户具备 `RESTORE TABLE` 权限
- 恢复操作不可逆，务必在执行前做好确认

---

## 恢复流程

### 步骤 1：确认目标表

询问用户需要恢复哪张表，请提供完整表名（如 `schema_name.table_name`）。

如果用户已经提供了表名，直接进入步骤 2。

---

### 步骤 2：查看历史版本

使用 `desc_object_history` 工具（或 `read_query` 执行 `DESC HISTORY <table_name> LIMIT 20`）查看历史版本。

展示结果时，重点标注：
- 可疑的误操作版本（通常是 `INSERT_OVERWRITE`、`DELETE`、`UPDATE`、`MERGE` 等操作）
- 操作用户和时间
- 该版本的行数（与当前版本对比，帮助用户判断）

示例展示格式：
```
版本  时间                          行数          操作              用户
826   2026-03-18 02:19:47.559      1,494,028,916  COMPACTION        系统
825   2026-03-18 02:19:40.275      1,494,028,916  COMPACTION        系统
824   2026-03-18 01:02:20.590      1,494,028,916  INSERT_OVERWRITE  kingdong  ← 可能是误操作
823   2026-03-17 01:14:12.976      1,403,939,983  COMPACTION        系统
```

---

### 步骤 3：询问恢复时间点

根据历史版本列表，询问用户：

> "请选择要恢复到哪个时间点（即误操作**之前**的版本）？
> 您可以：
> 1. 直接说版本号（如：版本 823）
> 2. 或说时间（如：2026-03-17 01:14:12）"

**将用户选择映射到精确时间戳：**
- 用户选版本号 → 从 DESC HISTORY 结果中取对应的精确时间（含毫秒）
- 用户说时间 → 找 DESC HISTORY 中最接近且早于该时间的版本，取其精确时间戳
- 精确时间戳格式示例：`2026-03-17 01:14:12.976`

---

### 步骤 4：验证目标版本数据可用

使用 `read_query` 执行验证查询：
```sql
SELECT COUNT(*) as row_count FROM <table_name> TIMESTAMP AS OF '<exact_timestamp>'
```

- **成功**：告知用户该版本有多少行数据可恢复，继续步骤 5
- **失败（version not found）**：说明该版本已超出 Time Travel 保留期（通常 7 天），无法恢复。请用户选择其他版本，或告知无法恢复

---

### 步骤 5：询问恢复方式

验证成功后，向用户展示选项：

> "✅ 验证成功！版本 `<timestamp>` 有 **N 行**数据可恢复。
>
> 请选择恢复方式：
>
> **选项 A：直接恢复到原表**
> - 将原表数据覆盖为历史版本
> - ⚠️ 不可逆操作，当前数据将被覆盖
>
> **选项 B：先恢复到新表（推荐）**
> - 将历史数据写入一张新建的临时表
> - 自动对比新旧表的数据差异
> - 确认无误后再决定是否覆盖原表"

---

### 步骤 6A：恢复到原表

用户选择选项 A 时：

1. **二次确认**：
   > "⚠️ 您确定要将 `<table_name>` 恢复到 `<timestamp>` 的版本吗？
   > 当前表数据将被覆盖，此操作不可逆。
   > 请输入 **YES** 确认执行。"

2. 用户输入 YES 后，使用 `restore_object` 工具执行：
   - `object_type`: TABLE
   - `object_name`: `<table_name>`
   - `timestamp`: `<exact_timestamp>`

   等价 SQL：`RESTORE TABLE <table_name> TO TIMESTAMP AS OF '<exact_timestamp>'`

3. 恢复完成后，查询当前行数确认：
   ```sql
   SELECT COUNT(*) as current_rows FROM <table_name>
   ```
   告知用户恢复结果。

**权限不足时的处理：**
如果报 `NoPermission: has no RESTORE TABLE permission`，告知用户：
> "当前用户没有 RESTORE TABLE 权限。请联系工作空间管理员（workspace_admin）执行以下 SQL 授权：
> ```sql
> GRANT RESTORE TABLE ON TABLE <table_name> TO USER <username>;
> ```
> 或者改用选项 B（恢复到新表），再手动执行 INSERT OVERWRITE。"

---

### 步骤 6B：恢复到新表并对比

用户选择选项 B 时：

**1. 确认新表名**

建议新表名：`<原表名>_restore_<YYYYMMDD>`（如 `orders_restore_20260317`）

询问用户是否接受，或自定义表名。

**2. 创建恢复表**

使用 `write_query` 执行：
```sql
CREATE TABLE <new_table_name> AS
SELECT * FROM <source_table> TIMESTAMP AS OF '<exact_timestamp>'
```

**3. 自动数据差异对比**

新表创建成功后，立即执行以下对比：

**行数对比：**
```sql
SELECT '原表（当前）' as 表名, COUNT(*) as 行数 FROM <original_table>
UNION ALL
SELECT '恢复目标' as 表名, COUNT(*) as 行数 FROM <new_table>
```

**差异分析（如果表有主键）：**

先用 `desc_object` 查看表结构，找到主键列（PRIMARY KEY）。如果有主键，执行：
```sql
-- 原表有、恢复表没有的行（误操作新增的行）
SELECT COUNT(*) as 误操作新增行数 FROM <original_table> t1
WHERE NOT EXISTS (SELECT 1 FROM <new_table> t2 WHERE t1.<pk> = t2.<pk>)
UNION ALL
-- 恢复表有、原表没有的行（误操作删除的行）
SELECT COUNT(*) as 误操作删除行数 FROM <new_table> t2
WHERE NOT EXISTS (SELECT 1 FROM <original_table> t1 WHERE t1.<pk> = t2.<pk>)
```

如果表没有明确主键，仅做行数对比，并说明无法精确统计行级差异。

**4. 给出对比结论**

以清晰的格式展示：
```
📊 数据差异对比结果：
┌─────────────┬──────────────┐
│ 原表（当前） │  X 行        │
│ 恢复目标     │  Y 行        │
│ 差异         │  Z 行        │
└─────────────┴──────────────┘

分析：
- 原表比恢复版本 多/少 Z 行
- [如有主键] 误操作新增了 A 行，删除了 B 行

建议：[根据差异给出建议，如"差异较大，建议仔细确认后再覆盖原表"]
```

**5. 询问是否覆盖原表**

> "恢复表 `<new_table_name>` 已创建完成，数据对比如上。
>
> 是否要将原表 `<original_table>` 也恢复到该版本？
> - 是 → 执行步骤 6A 的恢复操作
> - 否 → 恢复表 `<new_table_name>` 将保留，您可以手动处理"

---

## 注意事项

- 时间戳必须使用 DESC HISTORY 中显示的精确时间（含毫秒），不能自行推算
- 如果用户指定的时间不在历史版本列表中，找最近的早于该时间的版本
- COMPACTION 操作是系统自动执行的，不是用户误操作，通常不需要恢复到这些版本
- 恢复前务必完成步骤 4 的验证，确保目标版本数据可用
- 对于大表，CREATE TABLE AS SELECT 可能需要较长时间，提前告知用户
