---
name: image-analysis-pipeline
description: |
  端到端构建 ClickZetta 图像解析管道，覆盖从建表（含 VECTOR 字段）、图像上传到 Volume、
  调用 AI 外部函数进行图像识别和向量化、向量相似度搜索到动态表自动化处理的完整工作流。
  当用户说"图像识别"、"图片分析"、"图像向量化"、"图片相似度搜索"、"多模态分析"时触发。
  包含 VECTOR 类型、USER VOLUME PUT、fc_image_to_text、fc_gen_emmbeding、
  cosine_distance、DYNAMIC TABLE 等 ClickZetta 平台特有功能。
---

# 图像解析管道工作流

## 适用场景

- 构建图像识别系统（如菜品识别、商品识别）
- 图像内容提取与结构化存储
- 基于向量的图像相似度搜索
- 图像数据的自动化 ETL 管道
- 关键词：图像识别、图片分析、向量搜索、多模态、VECTOR、image_to_text

## 背景知识

### ClickZetta 平台特有概念

- **VECTOR 类型**：原生支持向量字段，语法 `VECTOR(FLOAT, 1024)`，用于存储图像/文本嵌入向量
- **USER VOLUME**：用户级文件存储空间，通过 `PUT` 命令上传文件，通过 `LIST USER VOLUME` 查看
- **外部函数（EXTERNAL FUNCTION）**：
  - `public.fc_image_to_text(task, url)`：图像识别函数，task 如 `'dish_recognition'`
  - `public.fc_gen_emmbeding(model, text, image_url)`：多模态向量生成函数，model 如 `'multimodal'`
- **cosine_distance(v1, v2)**：向量余弦距离函数，值越小越相似
- **DYNAMIC TABLE**：支持定时刷新的物化视图，用 `REFRESH_INTERVAL` 设定刷新频率

## 工作流

### 步骤 1：创建含 VECTOR 字段的数据表

使用 `write_query` 或 `create_table` 创建包含向量字段的表：

```sql
CREATE TABLE IF NOT EXISTS <table_name> (
    id BIGINT NOT NULL PRIMARY KEY IDENTITY (1),
    url STRING NOT NULL COMMENT '图片的原始URL地址',
    file_name STRING NOT NULL COMMENT '图片文件名',
    image_content STRING COMMENT '使用fc_image_to_text提取的图像描述',
    image_vector VECTOR(FLOAT, 1024) COMMENT '使用fc_gen_emmbeding生成的图片向量',
    created_at TIMESTAMP DEFAULT current_timestamp() COMMENT '创建时间'
) COMMENT '<表描述>';
```

注意：VECTOR 维度必须与 embedding 模型输出维度一致，当前默认 1024。

### 步骤 2：上传图像到 USER VOLUME

通过 JDBC 客户端执行 PUT 命令（不能在 SQL 编辑器中直接运行）：

```sql
PUT
    '/local/path/image1.jpg',
    '/local/path/image2.jpg'
TO USER VOLUME SUBDIRECTORY '<subdirectory>';

-- 验证上传结果
LIST USER VOLUME SUBDIRECTORY '<subdirectory>';
```

也可使用 MCP 工具 `put_file_to_volume` 上传。

### 步骤 3：调用 AI 函数进行图像识别和向量化

使用 `write_query` 插入数据，同时调用外部函数：

```sql
INSERT INTO <table_name> (url, file_name, image_content, image_vector)
VALUES (
    '<image_url>',
    '<file_name>',
    public.fc_image_to_text('<task>', '<image_url>'),
    CAST(public.fc_gen_emmbeding('multimodal', '', '<image_url>') AS VECTOR(FLOAT, 1024))
);
```

批量插入时使用多 VALUES 子句，每条记录独立调用 AI 函数。

### 步骤 4：向量相似度搜索

基于目标图像查找最相似的记录：

```sql
WITH target_vector AS (
    SELECT CAST(
        public.fc_gen_emmbeding('multimodal', '', '<target_image_url>')
        AS VECTOR(FLOAT, 1024)
    ) AS vec
)
SELECT
    d.file_name,
    d.url,
    d.image_content,
    cosine_distance(d.image_vector, t.vec) AS similarity_score
FROM <table_name> d, target_vector t
ORDER BY similarity_score ASC
LIMIT 5;
```

基于已有图像查找相似图像：

```sql
SELECT
    d1.file_name AS source_image,
    d2.file_name AS similar_image,
    d2.image_content,
    cosine_distance(d1.image_vector, d2.image_vector) AS similarity_score
FROM <table_name> d1, <table_name> d2
WHERE d1.file_name = '<source_file>'
  AND d1.id != d2.id
ORDER BY similarity_score ASC
LIMIT 5;
```

### 步骤 5：高级分析（可选）

结合结构化查询和向量搜索：

```sql
-- 按关键词过滤图像内容
SELECT id, file_name, image_content
FROM <table_name>
WHERE image_content LIKE '%<keyword>%'
ORDER BY id;

-- 按类别统计
SELECT
    CASE
        WHEN image_content LIKE '%<category_a>%' THEN '<label_a>'
        WHEN image_content LIKE '%<category_b>%' THEN '<label_b>'
        ELSE '其他'
    END AS category,
    COUNT(*) AS count
FROM <table_name>
GROUP BY 1;
```

### 步骤 6：创建自动化处理管道（可选）

使用动态表实现增量数据的自动处理：

```sql
CREATE OR REPLACE DYNAMIC TABLE <summary_table>
REFRESH_INTERVAL = '1 HOUR'
AS
SELECT
    file_name,
    url,
    image_content,
    created_at
FROM <table_name>
WHERE image_content IS NOT NULL;
```

## 示例

### 示例 1：美食图像识别系统
```
1. write_query: CREATE TABLE dish_images (id BIGINT PRIMARY KEY IDENTITY(1), url STRING, file_name STRING, image_content STRING, image_vector VECTOR(FLOAT, 1024), created_at TIMESTAMP DEFAULT current_timestamp())
2. PUT 本地图片 TO USER VOLUME SUBDIRECTORY 'dish_images'  (通过 JDBC)
3. write_query: INSERT INTO dish_images (url, file_name, image_content, image_vector) VALUES ('<url>', 'food1.jpg', public.fc_image_to_text('dish_recognition', '<url>'), CAST(public.fc_gen_emmbeding('multimodal', '', '<url>') AS VECTOR(FLOAT, 1024)))
4. read_query: SELECT file_name, image_content, cosine_distance(image_vector, (SELECT CAST(public.fc_gen_emmbeding('multimodal', '', '<target_url>') AS VECTOR(FLOAT, 1024)))) AS score FROM dish_images ORDER BY score ASC LIMIT 5
```

### 示例 2：商品图像检索
```
1. write_query: CREATE TABLE product_images (...)  -- 同上结构
2. put_file_to_volume: 上传商品图片
3. write_query: 批量 INSERT + AI 函数调用
4. read_query: 向量相似度搜索找到最相似商品
5. write_query: CREATE DYNAMIC TABLE product_summary REFRESH_INTERVAL = '30 MINUTES' AS SELECT ...
```

## 故障排除

| 场景 | 处理方式 |
|------|---------|
| VECTOR 维度不匹配 | 确认 CAST 目标维度与建表时一致（默认 1024） |
| fc_image_to_text 返回空 | 检查图片 URL 是否可公网访问，task 名称是否正确 |
| fc_gen_emmbeding 报错 | 确认 model 参数正确（如 'multimodal'），图片 URL 可达 |
| PUT 命令失败 | PUT 只能通过 JDBC 客户端执行，不支持 SQL 编辑器 |
| cosine_distance 结果异常 | 确认两个向量维度一致，且非 NULL |
| 动态表不刷新 | 检查 REFRESH_INTERVAL 设置，确认源表有新数据 |

## 注意事项

- VECTOR 字段维度必须在建表时指定，后续不可更改
- AI 外部函数调用有网络延迟，批量插入时注意超时设置
- PUT 命令仅支持 JDBC 客户端，不能在 Web SQL 编辑器中执行
- cosine_distance 返回值越小表示越相似（0 = 完全相同）
- 动态表的 REFRESH_INTERVAL 根据数据更新频率合理设置
