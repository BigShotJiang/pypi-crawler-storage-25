---
name: lakehouse-governance-audit
description: |
  对 ClickZetta 湖仓进行治理审计分析，覆盖权限管控（权限全景、安全风险、治理成熟度）、
  成本管理（对象成本分配、成本分解、成本趋势）、用户分析（生命周期、画像、留存）9 个
  分析维度。通过查询 sys.information_schema 系统表生成治理报告。当用户说"治理审计"、
  "权限分析"、"安全风险"、"成本分析"、"用户分析"、"合规检查"时触发。需要 instance_admin 权限。
---

# 湖仓治理审计工作流

## 指令

### 步骤 1：确认权限和分析范围
使用 `read_query` 验证当前用户有 instance_admin 权限：
```sql
SELECT CURRENT_USER(), CURRENT_ROLE();
```
与用户确认需要哪些分析维度（可选全部或部分）。

### 步骤 2：选择分析类型并执行对应 SQL

9 种分析类型分为 3 大类，每种对应 `references/` 目录下的 SQL 模板：

**A. 权限管控类**：
1. `access_permission_overview` - 权限分配全景
2. `security_risk_monitoring` - 安全风险监控
3. `governance_maturity_assessment` - 治理成熟度评估

**B. 成本管理类**：
4. `cost_allocation_by_object_type` - 按对象类型的成本分配
5. `cost_breakdown_analysis` - 成本构成分解
6. `cost_trend_prediction` - 成本趋势预测

**C. 用户分析类**：
7. `user_lifecycle_analysis` - 用户生命周期
8. `user_persona_profiling` - 用户画像
9. `user_retention_analysis` - 用户留存分析

### 步骤 3：执行分析查询
参考 `references/` 目录下对应的 SQL 模板，使用 `read_query` 逐个执行。

关键系统表（均在 `sys.information_schema` 下）：
- `object_privileges` - 权限授予记录（用 `granted_to` 区分用户/角色权限）
- `users` - 用户信息（按 `workspace_name` 分组）
- `roles` - 角色信息
- `role_grants` - 角色授予关系
- `instance_usage` - 实例使用量（按 `sku_name` 分类成本）
- `storage_metering` - 存储计量（托管存储/多版本存储分开统计）
- `job_history` - 作业历史（用 `pt_date` 分区键过滤提升性能）
- `tables` - 表元数据（`bytes`、`row_count`、`table_type` 字段）
- `schemas` - Schema 元数据（`type` 字段区分 MANAGED/EXTERNAL/SHARED）

**重要**：
- 所有系统表查询必须加 `WHERE delete_time IS NULL` 过滤已删除记录
- `job_history` 查询必须用 `pt_date` 分区键过滤，避免全表扫描
- `instance_usage` 和 `storage_metering` 的存储 SKU 有重叠，需避免重复计算

### 步骤 4：汇总分析结果
将各维度查询结果整理为结构化报告，包含：
- 各维度的关键指标和数值
- 风险项和告警（如有）
- 优化建议

## 平台特有知识

- 系统表路径：`sys.information_schema.table_name`，不是 `information_schema.table_name`
- 必须过滤 `delete_time IS NULL`，否则会包含已删除的历史记录
- `instance_usage` 的 `sku_name` 字段包含中文名称（如 'AP类型计算集群'、'Lakehouse存储容量'）
- `storage_metering` 中 '托管存储容量' 和 '多版本未删除存储' 与 `instance_usage` 有重叠，需去重
- `job_history` 的 `pt_date` 是分区键，必须用于时间过滤以提升性能
- `object_privileges` 的 `privilege_type` 使用 AT_ 前缀（如 `AT_ALL`、`AT_SELECT_ALL`）
- 需要 `instance_admin` 角色才能查询完整的系统表数据
- 用户生命周期分析中需过滤系统自动化查询（`job_type NOT IN ('SYSTEM_MAINTENANCE', 'AUTO_REFRESH', 'HEARTBEAT')`）

## 示例

### 示例：执行权限全景分析
```
1. read_query(query="SELECT CURRENT_USER(), CURRENT_ROLE()")  → 确认权限
2. read_query(query=<参考 references/access_permission_overview.sql>)
   → 获取角色-用户映射、权限分布、权限模型类型
3. 整理结果为报告格式，标注高风险项
```

### 示例：成本分配分析
```
1. read_query(query=<参考 references/cost_allocation_by_object_type.sql>)
   → 获取按 SKU 类型的成本汇总、对象分布、单位成本效率
2. 重点关注 undeleted_versions_percentage（多版本存储占比）
3. 如果 > 30%，建议清理多版本存储
```

## 故障排除

错误："Access denied" 或 "Insufficient privileges"
原因：当前角色不是 instance_admin
解决方案：请用户切换到 instance_admin 角色：`USE ROLE instance_admin;`

错误：系统表查询返回空结果
原因：可能未过滤 delete_time，或当前 workspace 无数据
解决方案：确认 `WHERE delete_time IS NULL` 已添加，并检查 workspace 范围

查询超时
原因：job_history 等表数据量大，全量扫描耗时
解决方案：添加 `pt_date` 分区键过滤，如 `WHERE pt_date >= CURRENT_DATE() - INTERVAL '7' DAY`

成本数据重复
原因：instance_usage 和 storage_metering 中存储 SKU 重叠
解决方案：从 instance_usage 排除 '托管存储容量' 和 '多版本未删除存储'，这两项从 storage_metering 获取
