---
name: knowledge-base-construction
description: |
  端到端构建 ClickZetta 知识库，覆盖从文档采集（网页爬取或本地文件）、Volume 存储准备、
  文档上传、非结构化ETL管道执行到知识库验证的完整工作流。当用户说"创建知识库"、
  "构建知识库"、"文档向量化"、"RAG 数据准备"、"爬取网页建知识库"时触发。
  包含 Volume 自动创建、文档格式检测、ETL管道配置、向量化存储等 ClickZetta 特有逻辑。
---

# 知识库构建工作流

## 指令

### 步骤 1：准备文档源
根据文档来源选择采集方式：

方式A - 网页爬取：使用 `smart_crawl_to_volume` 将网页内容爬取并存储到 Volume
- 提供目标 URL 和 Volume 名称
- 工具自动完成：URL爬取 → 内容提取 → Markdown转换 → 上传到Volume
- 支持深度控制和内容过滤

方式B - 本地文件：使用 `put_file_to_volume` 上传本地文档
- 支持多种文档格式（PDF、DOCX、TXT、Markdown等）
- 记录上传后的 Volume 路径

### 步骤 2：确认 Volume 就绪
使用 `list_files_on_volume` 确认文档已存储到 Volume：
- 检查文件列表和文件大小
- 确认文档格式正确
- 如果 Volume 不存在，先用 `create_volume` 创建：
  - 需要先有 STORAGE CONNECTION（用 `create_storage_connection` 创建）
  - 指定 volume_type、bucket、path、connection

### 步骤 3：确认 Schema 上下文
知识库创建在当前 Schema 下，确认上下文正确：
- 使用 `get_current_context` 查看当前 Schema
- 如需切换，使用 `switch_context` 或 `switch_vcluster_schema`
- Volume 必须在当前 Schema 下可访问

### 步骤 4：创建知识库
使用 `create_knowledge_base` 执行非结构化ETL管道：
- knowledge_name：知识库名称（如 product_docs_kb）
- documents_source_type：文档源类型（volume/s3/local）
- documents_source_path：文档路径
- volume_name：Volume名称（volume类型必需）
- processing_options：可选的处理配置
- 工具内部执行：文档解析 → 分块 → 向量化 → 存储到向量表

### 步骤 5：验证知识库
使用 `get_product_knowledge` 或 `read_query` 验证知识库可用：
- 执行语义搜索测试，确认能检索到相关内容
- 检查向量表记录数和数据质量

## 示例

### 示例 1：从网页文档构建产品知识库
```
1. smart_crawl_to_volume(url='https://docs.example.com', target_volume='docs_vol')
2. list_files_on_volume(target_volume='docs_vol')
3. get_current_context()  -- 确认当前schema
4. create_knowledge_base(
     knowledge_name='product_kb',
     documents_source_type='volume',
     documents_source_path='/',
     volume_name='docs_vol'
   )
5. get_product_knowledge(question='如何创建表')  -- 验证检索
```

### 示例 2：从本地PDF构建知识库
```
1. create_storage_connection(connection_name='oss_conn', connection_type='OSS', ...)
2. create_volume(volume_name='pdf_vol', volume_type='EXTERNAL', bucket='my-bucket', path='/docs', connection='oss_conn')
3. put_file_to_volume(source_path='guide.pdf', target_volume='pdf_vol')
4. create_knowledge_base(
     knowledge_name='guide_kb',
     documents_source_type='volume',
     documents_source_path='/',
     volume_name='pdf_vol'
   )
5. get_product_knowledge(question='使用指南')
```

## 故障排除

错误：Volume 不在当前 Schema 下
原因：create_knowledge_base 要求 Volume 在当前 Schema 可访问
解决方案：使用 switch_context 切换到 Volume 所在的 Schema

错误：文档解析失败
原因：不支持的文档格式或文件损坏
解决方案：确认文档格式受支持（PDF/DOCX/TXT/MD），检查文件完整性

错误：知识库创建成功但检索无结果
原因：向量化过程可能未完成或文档内容为空
解决方案：等待ETL管道完成，用 read_query 检查向量表记录数
