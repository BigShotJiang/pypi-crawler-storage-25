---
name: table-relationship-discovery
description: |
  智能发现 ClickZetta 表之间的关系（外键、关联），通过获取表元数据、列名语义匹配、
  数据类型兼容性检查、样本值重叠度分析来推断表间关系，输出带置信度评分的关系列表和
  JOIN SQL。当用户说"发现表关系"、"表之间的关联"、"ER 图"、"语义模型"、"JOIN 关系"
  时触发。支持 schema 级批量分析和单表对分析两种模式。
---

# 表关系发现工作流

## 指令

### 步骤 1：确定分析范围
两种模式：
- **Schema 模式**：分析整个 schema 下所有表的关系
- **指定表模式**：分析用户指定的若干张表之间的关系

### 步骤 2：获取表元数据
对每张表使用 `desc_object` 获取列名、数据类型、是否主键等信息。

### 步骤 3：采样数据
对每张表使用 `read_query` 获取样本数据用于值重叠度分析。

### 步骤 4：推断关系
基于以下维度进行关系推断：
- 列名语义匹配（权重最高）
- 数据类型兼容性
- 样本值重叠度
- 基数比例分析

### 步骤 5：计算置信度评分
综合以上维度计算 0-1 的置信度分数。

### 步骤 6：可选 SQL 验证
对高置信度关系执行 JOIN 验证。

### 步骤 7：格式化输出
根据 output_format 生成 YAML/JSON/Detailed 格式结果。

## 平台特有知识

- SHARED workspace 需要先 `SHOW SCHEMAS IN workspace` 获取表列表
- 动态表和物化视图也可以参与关系发现
- 外部表的列类型可能与托管表不同，需注意类型兼容性
- 复合键识别：多列组合构成的联合外键

## 示例

### 示例 1：Schema 级关系发现
```
1. show_object_list(object_type='TABLES', in_schema='sales')
2. desc_object 获取每张表的列信息
3. read_query 采样数据
4. 推断关系并计算置信度
```

## 故障排除

推断出过多无效关系
解决方案：提高 confidence_threshold 到 0.7 或 0.8

采样数据量不足导致误判
解决方案：增大 sample_size 或对小表使用全量数据

复合键关系未被发现
解决方案：确保 include_composite_keys=true
