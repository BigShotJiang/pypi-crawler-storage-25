---
name: external-function-deployment
description: |
  端到端部署 ClickZetta 外部函数（Python/Java UDF），覆盖从模板生成、本地测试、打包、上传到 Volume、
  创建函数、创建后验证的完整工作流。当用户说"创建外部函数"、"部署 UDF"、"Python 函数上云"、
  "创建远程函数"时触发。包含 handler 格式自动修正、ZIP 结构扫描、代码规范检查、Volume 文件验证等
  ClickZetta 特有的验证链路。
---

# 外部函数部署工作流

## 指令

### 步骤 1：创建 API CONNECTION（前置条件）
确认目标环境已有可用的 API CONNECTION。如果没有，使用 `create_api_connection` 创建：
- 必需参数：connection_name, provider(aliyun/tencent/aws), region, role_arn, namespace, code_bucket
- provider 对应云函数服务：阿里云FC、腾讯云函数、AWS Lambda
- namespace 在腾讯云必填，阿里云/AWS 可用 "default"

### 步骤 2：生成函数模板
使用 `generate_external_function_template` 生成标准化代码：
- template_type 可选：simple_function（默认）、ai_text_processing、data_processing
- 生成物包含：Python 文件、requirements.txt、部署说明
- 代码必须遵循规范：类名与文件名一致，包含 `@annotate("*->string")` 装饰器和 `evaluate` 方法

### 步骤 3：本地测试
使用 `test_external_function_locally` 验证函数逻辑：
- 自动推断函数名（从文件名）
- 动态导入并实例化函数类，调用 evaluate 方法
- 验证返回结果（JSON 格式、必需字段、内容检查）
- 确认所有测试用例通过后再继续

### 步骤 4：打包函数
使用 `package_external_function` 将代码打包为 ZIP：
- ClickZetta 仅支持 .zip 格式资源（不支持单独 .py 或 .jar）
- production 模式会清理 __pycache__、.pyc 等无用文件
- 含依赖时自动安装到 ZIP 包内（pip install --target）
- 注意：云函数环境固定为 Python 3.10.5 (Linux AMD64)

### 步骤 5：上传到 Volume
使用 `put_file_to_volume` 将 ZIP 包上传：
- 记录上传后的 Volume 路径，格式为 `volume://volume_name/filename.zip`
- 确认上传成功后再继续

### 步骤 6：创建外部函数
使用 `create_external_function` 创建函数，注意以下关键规则：
- class_name 必须是 `module.class` 格式（如 `my_func.my_func`），工具会自动修正 `MyClass` → `MyClass.MyClass`
- resource_uris 格式：`[{"type": "ARCHIVE", "uri": "volume://vol/file.zip"}]`
- 不支持 OR REPLACE，只支持 IF NOT EXISTS
- 调用时必须使用完整 Schema 路径：`schema_name.function_name(args)`
- 工具内部会执行：handler 格式修正 → ZIP 结构扫描 → 代码规范检查 → Volume 文件验证 → 创建后验证

### 步骤 7：验证和测试
创建成功后验证函数可用：
- 使用 `read_query` 执行 `SELECT schema_name.function_name('test_input')`
- 确认返回 JSON 格式结果
- 如果失败，检查 handler 路径、ZIP 结构、连接配置

## 示例

### 示例 1：部署 AI 文本处理函数
```
1. create_api_connection(connection_name='ai_conn', provider='aliyun', region='cn-hangzhou', ...)
2. generate_external_function_template(function_name='sentiment_analyzer', template_type='ai_text_processing')
3. test_external_function_locally(python_file='sentiment_analyzer.py', test_cases=[...])
4. package_external_function(source_file='sentiment_analyzer.py', include_dependencies=True)
5. put_file_to_volume(source_path='sentiment_analyzer.zip', target_volume='my_vol')
6. create_external_function(
     function_name='sentiment_analyzer',
     class_name='sentiment_analyzer.sentiment_analyzer',
     resource_uris=[{"type":"ARCHIVE","uri":"volume://my_vol/sentiment_analyzer.zip"}],
     connection_name='ai_conn', language='python'
   )
7. read_query(query="SELECT my_schema.sentiment_analyzer('这个产品很好用')")
```

## 故障排除

错误：handler 路径不匹配（如 `MyClass` 而非 `MyClass.MyClass`）
原因：ClickZetta 要求 class_name 为 `module.class` 格式
解决方案：工具会自动修正，如仍失败则手动指定为 `filename_without_ext.ClassName`

错误：ZIP 结构扫描失败（fatal: module/class not found）
原因：ZIP 包内缺少对应的 Python 模块或类
解决方案：确认 ZIP 根目录包含 `module_name.py`，且文件内有同名类和 evaluate 方法

错误：Volume 文件不存在
原因：resource_uris 中的 Volume 路径指向不存在的文件
解决方案：先用 `list_files_on_volume` 确认文件已上传成功

错误：函数创建成功但调用失败
原因：可能是 Schema 路径缺失或连接配置问题
解决方案：调用时使用完整路径 `schema.function_name()`，检查 API CONNECTION 状态
