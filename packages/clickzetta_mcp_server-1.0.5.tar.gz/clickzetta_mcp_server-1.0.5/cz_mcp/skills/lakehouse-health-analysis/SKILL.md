---
name: lakehouse-health-analysis
description: |
  对 ClickZetta 湖仓进行健康度和性能分析，覆盖数据资产管理（综合健康评分、资产概览、
  ROI 分析、增长预测、热点分析、基础设施状态、对象生命周期）、性能优化（KPI 仪表板、
  优化机会、查询性能）、业务价值映射、作业运行分析（SQL 模式、异常告警）共 13 个分析
  维度。当用户说"健康度评估"、"性能分析"、"数据资产"、"查询优化"、"作业分析"时触发。
  需要 instance_admin 权限。
---

# 湖仓健康度与性能分析工作流

## 指令

### 步骤 1：确认权限和分析范围
使用 `read_query` 验证 instance_admin 权限和数据可用性：
```sql
SELECT
    (SELECT COUNT(*) FROM sys.information_schema.workspaces WHERE delete_time IS NULL) as workspaces,
    (SELECT COUNT(*) FROM sys.information_schema.tables WHERE delete_time IS NULL) as tables,
    (SELECT COUNT(*) FROM sys.information_schema.job_history WHERE pt_date >= CURRENT_DATE() - INTERVAL '7' DAY) as recent_jobs;
```

### 步骤 2：选择分析类型并执行

13 种分析类型分为 4 大类：

**A. 数据资产管理类**（7种）：
1. `comprehensive_health_score` - 综合健康评分
2. `data_asset_overview` - 数据资产概览
3. `data_asset_roi_analysis` - 数据资产 ROI
4. `data_growth_trend_prediction` - 数据增长预测
5. `data_hotspot_analysis` - 数据热点分析
6. `lake_infrastructure_status` - 基础设施状态
7. `object_lifecycle_comprehensive` - 对象生命周期

**B. 性能优化类**（3种）：
8. `kpi_comprehensive_dashboard` - KPI 综合仪表板
9. `optimization_opportunities_analysis` - 优化机会识别
10. `query_performance_analysis` - 查询性能分析

**C. 业务价值类**（1种）：
11. `business_scenario_mapping` - 业务场景映射

**D. 作业运行类**（2种）：
12. `sql_pattern_report` - SQL 模式报告
13. `job_execution_alerts` - 作业异常告警

### 步骤 3：执行分析查询
参考 `references/` 目录下对应的 SQL 模板，使用 `read_query` 执行。

关键系统表和字段：
- `tables` - `table_type`（MANAGED_TABLE/EXTERNAL_TABLE/VIRTUAL_VIEW/MATERIALIZED_VIEW/DYNAMIC_TABLE）、`bytes`、`row_count`、`is_partitioned`、`is_clustered`
- `job_history` - `pt_date`（分区键）、`execution_time`、`cru`、`input_bytes`、`cache_hit`、`input_tables`（JSON 格式）
- `instance_usage` - `sku_name`、`total_after_discount`、`measurements_consumption`
- `storage_metering` - 存储计量详情
- `materialized_view_refresh_history` - 物化视图刷新记录
- `automv_refresh_history` - 自动物化视图刷新记录
- `sortkey_candidates` - 排序键优化建议（用 `p_date` 分区键过滤）
- `connections` - `connection_kind`、`provider`（多云架构分析）
- `volumes` - `volume_type`（MANAGED/EXTERNAL）

### 步骤 4：生成健康度报告
将分析结果整理为结构化报告：
- 综合健康评分和各维度得分
- 性能瓶颈和优化建议
- 数据资产增长趋势
- 告警项和风险提示

## 平台特有知识

- 综合健康评分权重：稳定性25% + 性能20% + 现代化20% + 多云15% + 治理10% + 活跃度10%
- `job_history.input_tables` 是 JSON 格式，包含 `"type":"MANAGED_TABLE"` 等类型信息
- `cache_hit` 字段是字节数（不是百分比），缓存命中率 = SUM(cache_hit) / SUM(input_bytes) * 100
- `sortkey_candidates` 表用 `p_date` 分区键（不是 `pt_date`）
- 架构现代化评分：物化视图 + 动态表 + 分区表的使用比例
- 多云多样性：统计 connections 表中 provider 字段的不同云厂商数量（aliyun/tencent/aws/gcp）
- 性能分级标准：快速(<1s)、中等(1-10s)、慢(>10s)
- 表类型有 5 种：MANAGED_TABLE、EXTERNAL_TABLE、VIRTUAL_VIEW、MATERIALIZED_VIEW、DYNAMIC_TABLE

## 示例

### 示例 1：快速健康度评估
```
1. read_query(query=<参考 references/comprehensive_health_score.sql>)
   → 获取 0-100 分综合健康评分和各维度得分
2. 如果 ultimate_health_score < 70，重点分析得分最低的维度
3. 根据得分建议优化方向
```

### 示例 2：查询性能分析
```
1. read_query(query=<参考 references/query_performance_analysis.sql>)
   → 获取按对象类型的性能指标
2. 关注 slow_query_rate > 10% 的对象类型
3. 检查 cache_hit_rate < 50% 的场景，建议添加物化视图
```

## 故障排除

查询超时
原因：job_history 全表扫描
解决方案：确保使用 `pt_date` 分区键过滤，缩短时间窗口（30天→7天）

综合健康评分异常低
原因：某个维度数据缺失导致评分偏低
解决方案：检查各维度数据是否完整，特别是 job_history 和 instance_usage 是否有近期数据

sortkey_candidates 查询报错
原因：使用了错误的分区键名
解决方案：该表的分区键是 `p_date`（不是 `pt_date`），用 `WHERE p_date >= CURRENT_DATE() - INTERVAL '7' DAY`

缓存命中率显示异常高（>100%）
原因：cache_hit 和 input_bytes 的计算方式错误
解决方案：缓存命中率 = SUM(cache_hit) * 100.0 / SUM(input_bytes)，注意都是字节数
