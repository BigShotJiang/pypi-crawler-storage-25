---
name: lakehouse-access-control
description: |
  ClickZetta Lakehouse 访问控制与权限管理助手。当用户说"帮我授权"、"给某用户赋权"、"我需要对xx数据给xx授予权限"、
  "配置访问控制"、"创建角色并授权"、"权限管理"、"RBAC配置"、"回收权限"时使用。
  能分析授权需求的完整性（主体、客体、权限级别），推荐预置角色或生成 GRANT/REVOKE SQL，
  并提供等效的 Web 页面操作指引。
---

# ClickZetta Lakehouse 授权操作助手

帮助用户完成 Lakehouse 平台的数据授权操作。从分析授权需求开始，检查授权要素是否完整，
推荐最优授权方案（预置角色或自定义授权），生成可执行的 SQL 脚本，并提供 Web 页面操作指引。

## 适用场景

- 用户需要对某个范围的数据给某个用户/角色授予只读/读写/全部权限
- 用户需要创建自定义角色并配置权限
- 用户需要查询现有权限配置
- 用户需要回收已授予的权限
- 关键词：授权、赋权、GRANT、权限、角色、RBAC、访问控制

## 背景知识

### ClickZetta 权限体系概览

云器 Lakehouse 采用 ACL + RBAC 并存的访问控制机制：

- ACL（访问控制列表）：将权限直接分配给用户，适合小型/简单场景
- RBAC（基于角色的访问控制）：先为角色分配权限，再将角色授予用户（推荐方式）
- 两种模式并存：用户的最终权限 = 直接授予的权限 ∪ 所有角色的权限（取并集）
- 鉴权时系统自动遍历用户所有权限，用户无需声明当前以何种角色行事
- 不支持 DAC（自主访问控制）：对象所有者不能进行二次授权
- 无超级用户/超级角色：所有访问操作都必须明确获得授权，无法绕过权限检查
- 权限变更即时生效（GRANT/REVOKE 执行后立即生效）

权限层级（从高到低）：
- 服务实例级（Instance）→ 全局管控
  - 工作空间级（Workspace）→ 特定工作空间范围
    - Schema 级
      - 对象级：表(Table) / 视图(View) / 动态表(Dynamic Table) / 函数(Function)
    - 计算集群级（Virtual Cluster）

对象所有权规则：
- 创建者自动拥有对象的所有权（ownership）和全部操作权限
- 当前不支持对象所有权的转移
- 未被显式授权的访问默认拒绝
- 推荐通过 instance_admin 和 workspace_admin 角色统一管理授权

角色层次：
- 实例角色（Instance Role）：用于实例级资源和操作的全局管控，以及跨多个工作空间的权限授予
- 工作空间角色（Workspace Role）：作用于特定工作空间范围内的对象，以工作空间为边界互不影响
- 实例角色与工作空间角色互不影响，实例角色不具备也无法获取工作空间级对象的权限
- 用户可同时拥有多个角色，权限为所有角色权限的并集

### 权限级别划分

权限定义了对对象所能执行操作的最小访问单元。

| 权限级别 | 说明 | 典型权限点 |
|---------|------|-----------|
| 元数据查看 | 仅查看对象元数据 | READ METADATA |
| 只读 | 查看元数据+查询数据 | SELECT, READ METADATA |
| 读写 | 查看+修改数据 | SELECT, INSERT, UPDATE, DELETE, READ METADATA |
| 全部 | 所有操作权限 | ALL PRIVILEGES |

元数据对象的三种表达方式：
1. 具体对象：`TABLE mytable`、`VCLUSTER myvcluster`
2. ALL + 对象类别：`ALL TABLES IN SCHEMA my_schema`（当前和未来所有该类型对象）
3. ALL OBJECTS：`ALL OBJECTS IN WORKSPACE my_workspace`（所有类型的所有对象，谨慎使用）

权限点的两种表达方式：
1. 具体权限点：`SELECT`、`READ METADATA`、`INSERT` 等
2. ALL PRIVILEGES：该对象的所有权限点

WITH GRANT OPTION：在 GRANT 语句末尾加上此选项，允许被授予者将该权限再授予其他角色或用户。

ALL PRIVILEGES 特殊规则：ALL 是独立权限点，与其他权限点非指代关系。授予 ALL 不覆盖已有的单独权限点，REVOKE ALL 也不会解除单独授予的权限点。

### 权限点速查表

#### 通用权限点
`READ METADATA` | `SHOW PRIVILEGE` | `ALL PRIVILEGES`

说明：
- `SHOW PRIVILEGE`：查看对象权限信息的权限点，所有对象类型通用
- `READ METADATA`：查看对象元数据的权限点，所有对象类型通用

#### Table 权限点
`READ METADATA` | `SELECT` | `INSERT TABLE` | `UPDATE TABLE` | `DELETE TABLE` | `ALTER TABLE` | `DROP TABLE` | `RESTORE TABLE` | `TRUNCATE TABLE` | `ALL PRIVILEGES`

权限点名称语法糖：部分权限点支持简写和全称两种写法，在 GRANT/REVOKE 语句中均可使用：
- `SELECT` 等价于 `SELECT TABLE`（GRANT 时可用 SELECT，SHOW GRANTS 结果中显示为 SELECT TABLE）
- `INSERT` 等价于 `INSERT TABLE`
- 类似地，`UPDATE`/`DELETE` 等价于 `UPDATE TABLE`/`DELETE TABLE`

复合操作所需权限：
- MERGE INTO：需要 INSERT + UPDATE + DELETE
- INSERT OVERWRITE：需要 INSERT + DELETE
- COPY INTO：需要 INSERT

#### View 权限点
`READ METADATA` | `SELECT` | `ALTER VIEW` | `DROP VIEW` | `ALL PRIVILEGES`

#### Dynamic Table 权限点
`READ METADATA` | `SELECT` | `ALTER DYNAMIC TABLE` | `DROP DYNAMIC TABLE` | `RESTORE DYNAMIC TABLE` | `ALL PRIVILEGES`

#### Schema 权限点
`READ METADATA` | `ALTER SCHEMA` | `DROP SCHEMA` | `CREATE TABLE` | `CREATE VIEW` | `CREATE MATERIALIZED VIEW` | `CREATE DYNAMIC TABLE` | `CREATE INDEX` | `CREATE FUNCTION` | `CREATE TABLE STREAM` | `CREATE VOLUME` | `ALL PRIVILEGES`

#### Virtual Cluster 权限点
`READ METADATA` | `USE VCLUSTER` | `ALTER VCLUSTER` | `DROP VCLUSTER` | `ALL PRIVILEGES`

#### Workspace 权限点
`ALTER WORKSPACE`(仅 workspace_admin) | `CREATE CONNECTION` | `CREATE VCLUSTER` | `CREATE SCHEMA` | `CREATE USER`(仅 workspace_admin) | `CREATE ROLE`(仅 workspace_admin)

#### Instance 权限点
`CREATE WORKSPACE`(仅 instance_admin) | `CREATE NETWORK POLICY`(仅 instance_admin) | `DROP WORKSPACE`(仅 instance_admin)

#### 其他对象权限点
- Volume：`READ METADATA` | `READ VOLUME` | `WRITE VOLUME` | `ALTER VOLUME` | `ALL PRIVILEGES`
- Function：`READ METADATA` | `USE FUNCTION` | `ALTER FUNCTION` | `DROP FUNCTION` | `ALL PRIVILEGES`
- Table Stream：`READ METADATA` | `SELECT` | `ALTER TABLE STREAM` | `DROP TABLE STREAM` | `ALL PRIVILEGES`
- Materialized View：`READ METADATA` | `SELECT` | `ALTER/DELETE/DROP/UPDATE/TRUNCATE MATERIALIZED VIEW` | `ALL PRIVILEGES`
- Connection：`READ METADATA` | `ALTER CONNECTION` | `DROP CONNECTION` | `ALL PRIVILEGES`
- Index：`READ METADATA` | `DROP INDEX` | `ALL PRIVILEGES`
- Job：`READ METADATA` | `TERMINATE JOB` | `ALL PRIVILEGES`（均不可用于授权，由 workspace_admin 和 job 执行者默认拥有）

### 预置角色清单

预置角色是平台在服务实例创建时自动配置的角色，不可删除，可直接授予用户。
workspace_admin 和 instance_admin 的权限不允许修改；其他预置角色可以修改权限。
完整权限详见官方文档「系统内置角色权限列表」。

| 角色名 | 级别 | 权限范围 | 适用场景 |
|-------|------|---------|---------|
| instance_admin | 实例级 | 实例层面全部管理权限（创建工作空间、管理实例级角色等） | 实例管理员，创建实例的用户默认拥有 |
| instance_sre | 实例级 | 所有工作空间的调度任务运维管理权限（= 所有 workspace_sre 的并集） | 全实例统一运维管理 |
| workspace_admin | 工作空间级 | 工作空间内所有权限（角色管理、成员管理、数据对象、计算集群），WITH GRANT OPTION | 空间管理员，创建工作空间的用户默认拥有 |
| workspace_dev | 工作空间级 | 所有数据对象 ALL 权限(TABLE/SCHEMA/VCLUSTER/JOB/FUNCTION) + SHOW PRIVILEGE + CREATE SCHEMA + READ METADATA（不可二次授权） | 数据开发，可使用 Web"开发"功能和 JDBC |
| workspace_analyst | 工作空间级 | 所有计算集群 USE VCLUSTER + READ METADATA 权限 + 所有数据对象 READ METADATA + SHOW PRIVILEGE + CREATE TABLE + CREATE VIEW（无 SELECT，需额外授予） | 数据分析师，需单独授予 SELECT 权限 |
| workspace_sre | 工作空间级 | 工作空间内所有调度任务运维管理权限 + SHOW PRIVILEGE + READ METADATA（无计算资源使用和数据查询权限） | 空间运维，管理任务运维和监控报警 |

#### 已下线的历史预置角色

以下角色仅在部分早期创建的工作空间中存在，新建工作空间不再自动创建：

| 角色名 | 级别 | 权限范围 | 说明 |
|-------|------|---------|------|
| system_admin | 工作空间级 | 工作空间内 ALL on ALL 权限，WITH GRANT OPTION。权限不允许修改。 | 已不再是新建 workspace 的预置角色。拥有此角色的用户可将其授予其他工作空间用户。实际操作中已被 workspace_admin 替代。 |
| workspace_user | 工作空间级 | 所有数据对象 READ METADATA + 所有 ROLE/USER 的 READ METADATA + SHOW PRIVILEGE | 已下线。需要只读权限时，推荐对 workspace_analyst 角色授予 SELECT + READ METADATA 来实现。不建议在此角色上再设计权限。 |

### 自定义角色

创建语法：
```sql
-- 创建工作空间级自定义角色（需要 workspace_admin）
CREATE ROLE <role_name>;
CREATE ROLE <role_name> COMMENT '<描述>';

-- 创建实例级自定义角色（需要 instance_admin）
CREATE INSTANCE ROLE <role_name>;

-- 可选修饰符
CREATE OR REPLACE ROLE <role_name>;          -- 替换已存在的同名角色
CREATE ROLE IF NOT EXISTS <role_name>;       -- 角色已存在时不报错
```

规则：
- 工作空间级角色：需要 workspace_admin 角色执行，仅支持 SQL 创建（暂不支持 Web 端）
- 实例级角色：需要 instance_admin 角色执行，用于跨工作空间的统一权限管控
- 角色名称不能与系统预置角色名称相同
- 权限可随时通过 GRANT/REVOKE 修改或删除
- 创建流程：CREATE ROLE → GRANT 权限给角色 → GRANT ROLE 给用户

### 角色关键规则

- 预置角色不可删除；workspace_admin、instance_admin 和 system_admin（历史角色）不允许修改权限，其他预置角色可修改
- 实例级角色仅支持通过 Web 端授予，仅 instance_admin 可操作
- 工作空间级角色可通过 Web 端或 SQL 授予，仅 workspace_admin 可操作
- workspace_dev 的读写权限不支持二次授权，需 workspace_admin 操作
- 工作空间级角色不能授予给其他角色，只能直接授予给用户
- Instance Role 可授予跨工作空间的全局权限，授权对象包括用户或其他角色
- 一个用户可被授予多个角色，最终权限为各角色权限的并集
- 实例角色不具备也无法获取工作空间级对象的权限（两者互不影响）

### 元数据对象层级

元数据对象是可被授予权限的实体。对象及其父级关系：

| 元数据对象 | 父级对象 |
|-----------|---------|
| workspace | instance |
| share | instance |
| network policy | instance |
| schema | workspace |
| virtual cluster | workspace |
| connection | workspace |
| table | schema |
| view | schema |
| materialized view | schema |
| dynamic table | schema |
| table stream | schema |
| volume | schema |
| index | schema |
| function | schema |
| job | schema |

对象访问规则：
- 未被显式授权 → 默认拒绝访问
- 元数据对象均可通过 SQL 授权；工作空间内对象也可在 Web 端「管理→安全→权限」中操作
- 业务对象（脚本、任务、数据质量规则）不可通过 SQL 授权，通过预置角色控制

### 用户身份体系

用户层级：
- 全局用户：平台级独立身份，具备唯一用户名和密码，自动同步至各服务实例
- 服务实例用户：全局用户同步到实例后的身份，默认被授予 instance_user 角色（无任何数据和功能权限）

用户类型：
- 普通用户：代表实际人员，可 Web 登录和 JDBC 连接
- 服务用户：用于自动化流程，不允许 Web 登录，仅支持 JDBC 连接或调度任务
  - 系统服务用户：平台默认创建（如 sysservice_clickzetta、sysservice_auto_mv），默认禁用，按需启用
  - 自定义服务用户：用户自助创建，用于业务应用

### 动态脱敏（列级安全）

动态脱敏通过脱敏策略函数在数据读取时动态修改敏感数据的显示方式，系统仅存储原始数据。

核心流程：
1. 创建脱敏策略函数（CREATE FUNCTION），返回类型必须与原始列相同
2. 绑定策略到列：建表时 MASKING POLICY 指定，或 ALTER TABLE 修改已有表
3. 解除策略：ALTER TABLE ... ALTER COLUMN ... UNSET MASKING POLICY

安全上下文函数：
- `current_user()` — 获取当前用户名
- `current_roles()` — 获取用户角色数组

权限要求：
- 修改脱敏策略需要 ALTER TABLE 权限
- 创建脱敏函数需要 CREATE FUNCTION 权限

限制：单个列只能绑定一个脱敏策略，多种规则需在一个函数中用条件判断实现

## 工作流

### 步骤 1：分析授权需求完整性（必须）

收到用户的授权请求后，检查以下授权要素是否完整：

| 要素 | 说明 | 示例 | 缺失时的处理 |
|------|------|------|------------|
| 主体（WHO） | 被授权的用户或角色 | 用户 alice、角色 data_analyst | 询问"您要授权给哪个用户或角色？" |
| 客体（WHAT） | 被授权访问的数据范围 | workspace1.schema1.table1 | 询问"您要授权访问哪些数据？请指定工作空间/Schema/表" |
| 权限级别（HOW） | 授予什么级别的权限 | 只读/读写/全部 | 询问"您需要授予什么级别的权限？只读(SELECT)、读写(SELECT+INSERT+UPDATE+DELETE)、还是全部(ALL)？" |
| 授权方式 | 直接授权还是通过角色 | 直接给用户 / 先创建角色再授予 | 推荐使用角色方式（RBAC），除非是临时的简单授权 |

如果有要素缺失，按以下方式处理：
1. 明确指出缺失的要素
2. 根据上下文猜测并推荐可能的补充内容
3. 等用户确认后再继续

### 步骤 2：检查是否有预置角色可满足需求

根据用户的授权需求，对照预置角色清单检查是否能满足：

| 用户需求 | 推荐预置角色 | 说明 |
|---------|------------|------|
| 工作空间内全部数据读写+开发 | workspace_dev | 默认具备所有数据对象读写+计算集群使用权限 |
| 工作空间内数据查询分析 | workspace_analyst + 额外 GRANT SELECT | analyst 默认无 SELECT，需补充授权 |
| 工作空间管理（角色/成员/权限） | workspace_admin | 空间内最高权限 |
| 调度任务运维管理 | workspace_sre（单空间）或 instance_sre（全实例） | 仅运维权限，无数据查询权限 |
| 实例级管理 | instance_admin | 创建工作空间、管理实例级角色 |
| 特定表/Schema 的精细权限 | 自定义角色 | 预置角色粒度不够，需创建自定义角色 |

匹配逻辑：
- 如果预置角色完全匹配 → 直接推荐，跳到步骤 4
- 如果预置角色部分匹配 → 告知用户差异，建议使用预置角色 + 补充授权
- 如果没有匹配 → 进入步骤 3 创建自定义角色

### 步骤 3：生成授权方案

根据需求生成两种方案：

#### 方案 A：SQL 脚本方式

GRANT 语法（授予权限）：
```sql
-- 授予用户权限
GRANT <privileges> ON <object_type> <object_name> TO USER <username>;

-- 授予角色权限
GRANT <privileges> ON <object_type> <object_name> TO ROLE <role_name>;

-- 授予权限并允许被授予者再授权
GRANT <privileges> ON <object_type> <object_name> TO USER <username> WITH GRANT OPTION;

-- 将角色授予用户
GRANT ROLE <role_name> TO USER <username>;
```

REVOKE 语法（回收权限）：
```sql
-- 回收用户权限
REVOKE <privileges> ON <object_type> <object_name> FROM USER <username>;

-- 回收角色权限
REVOKE <privileges> ON <object_type> <object_name> FROM ROLE <role_name>;
```

权限类型参数说明：
- workspacePrivileges：工作空间下创建对象的权限（CREATE SCHEMA, CREATE VCLUSTER 等）
- workspaceObjectPrivileges：工作空间下对象的修改和查询权限（ALTER, DROP, READ METADATA 等）
- schemaPrivileges：Schema 下创建对象的权限（CREATE TABLE, CREATE VIEW 等）
- schemaObjectPrivileges：Schema 下对象的操作权限（SELECT, INSERT, UPDATE, DELETE, ALTER, DROP 等）

常用授权模板：
```sql
-- 1. 创建自定义角色
CREATE ROLE <role_name>;

-- 2. 授予计算集群使用权限（必须，否则无法执行查询）
GRANT USE VCLUSTER ON VCLUSTER <vc_name> TO ROLE <role_name>;

-- 3a. 授予特定表的只读权限
GRANT SELECT, READ METADATA ON TABLE <schema>.<table> TO ROLE <role_name>;

-- 3b. 授予 Schema 下所有表的只读权限
GRANT SELECT, READ METADATA ON ALL TABLES IN SCHEMA <schema> TO ROLE <role_name>;

-- 3c. 授予 Schema 下所有表的读写权限
GRANT SELECT, INSERT TABLE, UPDATE TABLE, DELETE TABLE, READ METADATA ON ALL TABLES IN SCHEMA <schema> TO ROLE <role_name>;

-- 3d. 授予 Schema 下所有对象的全部权限
GRANT ALL PRIVILEGES ON ALL OBJECTS IN SCHEMA <schema> TO ROLE <role_name>;

-- 4. 将角色授予用户
GRANT ROLE <role_name> TO USER <username>;
```

回收权限模板：
```sql
-- 回收用户在工作空间下的所有权限
REVOKE ALL PRIVILEGES ON WORKSPACE <workspace_name> FROM USER <username>;

-- 回收用户对特定表的查询权限
REVOKE SELECT ON TABLE <schema>.<table> FROM USER <username>;

-- 回收角色在 Schema 下创建视图的权限
REVOKE CREATE VIEW ON SCHEMA <schema> FROM ROLE <role_name>;
```

角色级 GRANT 四层授权结构：
```sql
-- 1. Workspace 级别权限（如创建 Schema、创建计算集群）
GRANT <workspacePrivileges> ON WORKSPACE <workspace_name> TO ROLE <role_name>;

-- 2. Workspace 对象权限（如 ALTER、DROP、READ METADATA）
GRANT <workspaceObjectPrivileges> ON <object_type> <object_name> TO ROLE <role_name>;

-- 3. Schema 级别权限（如 CREATE TABLE、CREATE VIEW）
GRANT <schemaPrivileges> ON SCHEMA <schema_name> TO ROLE <role_name>;

-- 4. Schema 对象权限（如 SELECT、INSERT、ALTER、DROP）
GRANT <schemaObjectPrivileges> ON <object_type> <object_name> TO ROLE <role_name>;

-- Instance Role 授权（跨工作空间全局权限）
GRANT <privileges> ON <object_type> <object_name> TO INSTANCE ROLE <role_name>;
```

角色级 REVOKE 四层回收结构：
```sql
-- 1. 回收 Workspace 级别权限
REVOKE <workspacePrivileges> ON WORKSPACE <workspace_name> FROM ROLE <role_name>;

-- 2. 回收 Workspace 对象权限
REVOKE <workspaceObjectPrivileges> ON <object_type> <object_name> FROM ROLE <role_name>;

-- 3. 回收 Schema 级别权限
REVOKE <schemaPrivileges> ON SCHEMA <schema_name> FROM ROLE <role_name>;

-- 4. 回收 Schema 对象权限
REVOKE <schemaObjectPrivileges> ON <object_type> <object_name> FROM ROLE <role_name>;

-- Instance Role 权限回收
REVOKE <privileges> ON <object_type> <object_name> FROM INSTANCE ROLE <role_name>;
```

#### 方案 B：Web 页面操作方式

##### 添加工作空间成员
1. 登录 Lakehouse Studio → 管理 → 工作空间 → 点击目标工作空间名称
2. 在工作空间详情页点击「+ 添加用户」
3. 勾选用户（仅显示实例中已存在且未加入此空间的用户）
4. 点击「添加用户」或「添加用户并授予角色」

##### 授予实例级角色（仅 instance_admin 可操作）
1. 管理 → 安全 → 切换到「角色」页面
2. 点击目标实例级角色名称 → 进入角色详情
3. 点击「+ 用户授予」→ 勾选用户 → 点击「授权」

##### 授予工作空间级角色（仅 workspace_admin 可操作）
1. 管理 → 安全 → 角色页面（或 管理 → 工作空间 → 进入空间详情 → 角色页签）
2. 点击目标工作空间角色名称 → 进入角色详情
3. 点击「+ 用户授予」→ 勾选用户 → 点击「授权」

##### 移除用户角色
- 在角色详情页，点击用户名右侧「...」→ 选择「移除用户」

##### 移除工作空间成员
- 在工作空间详情 → 用户列表 → 点击用户右侧「...」→ 选择「移除用户」
- 注意：被移除的用户立即失去空间角色和计算集群使用权限，但仍保留被直接授予的数据权限（可在其他空间行使）

##### 工作空间用户管理（SQL 方式）
```sql
-- 添加用户到工作空间（将已存在于实例中的用户加入当前工作空间，非创建新用户）
CREATE USER <user_name>;

-- 查看工作空间内用户
SHOW USERS;

-- 从工作空间移除用户（仅移除空间内身份，不影响其他工作空间和实例级身份）
DROP USER <user_name>;
```

##### 权限审计查询
```sql
-- 查看某个对象（如表）的权限被授予给了哪些身份
SHOW GRANTS ON TABLE <schema>.<table>;
SHOW GRANTS ON SCHEMA <schema>;

-- 查看某个用户当前拥有的所有权限
SHOW GRANTS TO USER <username>;

-- 查看某个角色当前拥有的所有权限
SHOW GRANTS TO ROLE <role_name>;

-- 查看当前用户身份
SELECT CURRENT_USER();
```

### 步骤 4：验证授权结果

SHOW GRANTS 有两种查询方向，注意区分：
- `SHOW GRANTS TO ...`：查询某个身份（用户/角色）当前拥有的所有权限
- `SHOW GRANTS ON ...`：查询某个对象/身份的权限被授予给了哪些身份

```sql
-- ===== 查询身份拥有的权限（TO） =====

-- 查看指定用户拥有的所有权限（包括角色授予和直接权限）
SHOW GRANTS TO USER <username>;

-- 查看工作空间级角色拥有的所有权限
SHOW GRANTS TO ROLE <role_name>;

-- 查看实例级角色拥有的所有权限
SHOW GRANTS TO INSTANCE ROLE <role_name>;

-- ===== 查询对象/身份的权限被授予给了谁（ON） =====

-- 查看某个角色的权限被授予给了哪些用户/角色
SHOW GRANTS ON ROLE <role_name>;

-- 查看某个用户被授予了哪些权限（从授予方视角）
SHOW GRANTS ON USER <username>;

-- 查看某张表的权限被授予给了哪些身份
SHOW GRANTS ON TABLE <schema>.<table>;

-- 查看某个 Schema 的权限被授予给了哪些身份
SHOW GRANTS ON SCHEMA <schema>;

-- ===== 角色列表查询 =====

-- 查看当前工作空间下所有角色
SHOW ROLES;

-- 按名称模糊过滤角色（不区分大小写，支持 % 和 _ 通配符）
SHOW ROLES LIKE '%admin%';

-- 查看当前实例下所有实例级角色
SHOW INSTANCE ROLES;
```

SHOW GRANTS 结果字段说明：
- `grantee_name`：接收授权的身份（用户名或角色名）
- `grantor_name`：执行授权操作的身份
- `grant_option`：该授权是否允许被授予者二次授予其他身份
- `granted_type`：`PRIVILEGE`（直接授权）或 `OBJECT_HIERARCHY`（层级继承授权）

注意：执行 SHOW GRANTS 查询其他用户/角色权限时，执行者需要具备相应的查询权限。角色必须存在于当前数据库空间中。

## 示例

### 示例 1：给用户授予某个 Schema 下所有表的只读权限

用户说："我需要给用户 alice 授予 workspace1 下 schema1 中所有表的只读权限"

分析：
- 主体：用户 alice ✅
- 客体：workspace1.schema1 下所有表 ✅
- 权限级别：只读 ✅
- 所有要素完整，直接生成方案

SQL 方案：
```sql
-- 方案1：直接授权给用户
GRANT SELECT ON ALL TABLES IN SCHEMA schema1 TO USER alice;

-- 方案2：通过角色授权（推荐）
CREATE ROLE schema1_reader;
GRANT SELECT ON ALL TABLES IN SCHEMA schema1 TO ROLE schema1_reader;
GRANT ROLE schema1_reader TO USER alice;
```

### 示例 2：授权需求不完整

用户说："帮我给小明授权"

分析：
- 主体：小明 ✅（但需确认是用户名还是显示名）
- 客体：❌ 缺失 - 不知道要授权访问什么数据
- 权限级别：❌ 缺失 - 不知道要什么级别的权限

回复：
"您的授权需求还缺少以下信息：
1. **数据范围**：您要给小明授权访问哪些数据？比如某个工作空间、Schema、还是具体的表？
2. **权限级别**：您需要授予什么级别的权限？
   - 只读（仅查询）
   - 读写（查询+增删改）
   - 全部（包括DDL操作如建表、删表等）

请补充这些信息，我来帮您生成授权方案。"

## 错误处理

| 场景 | 处理方式 |
|------|---------|
| 用户指定的对象不存在 | 建议先用 SHOW SCHEMAS / `SHOW TABLES IN <schema>` 确认对象名称 |
| 权限不足无法执行 GRANT | 提示需要 instance_admin（实例级角色）或 workspace_admin（工作空间级角色）才能授权 |
| 授权范围过大（如 ALL PRIVILEGES ON WORKSPACE） | 警告安全风险，建议缩小范围或使用最小权限原则 |
| 用户混淆实例级和工作空间级角色 | 解释两者区别，帮助选择正确的授权级别 |
| GRANT 语法错误 | 检查对象类型、权限点名称是否正确 |
| 查看视图列表 | 使用 `SHOW TABLES WHERE is_view = true'`（不支持 SHOW VIEWS） |
| 查看动态表列表 | 使用 `SHOW TABLES WHERE is_dynamic = true`（不支持 SHOW DYNAMIC TABLES） |
| 查看指定 Schema 下的表 | 使用 `SHOW TABLES IN <schema_name>`（注意：不支持 `IN SCHEMA <name>` 语法） |

## 注意事项

- 始终推荐 RBAC 模式（通过角色授权），而非直接给用户授权
- 遵循最小权限原则，不要授予超出需求的权限
- 授权前建议先用 SHOW GRANTS TO USER/ROLE 查看现有权限，避免重复授权（注意：用 TO 查拥有的权限，用 ON 查被授予给谁）
- 工作空间级权限和实例级权限是不同的层级，注意区分
- 实例级角色仅支持 Web 端授予，不支持 SQL 操作
- 工作空间级角色不能授予给其他角色；Instance Role 可授权给用户或其他角色
- 用户加入工作空间是使用计算集群和执行 SQL 的前提条件
- 从工作空间移除用户后，其直接授予的数据权限仍然保留，推荐通过角色管理权限
- 当前不支持在 Web 端创建自定义角色，必须使用 SQL（CREATE ROLE）
- 服务实例用户默认仅有 instance_user 角色，无任何数据和功能权限，需额外授权
- 服务用户（自动化/系统级）不允许 Web 登录，仅支持 JDBC 和调度任务
- ALL PRIVILEGES 是独立权限点，REVOKE ALL 不会解除单独授予的权限点
- 谨慎使用 ALL OBJECTS 授权，确认范围符合预期后再执行
- 动态脱敏是列级安全功能，与授权配合使用可实现更细粒度的数据保护（需 ALTER TABLE + CREATE FUNCTION 权限）
- 单个列只能绑定一个脱敏策略，多种规则需在一个函数中用条件判断实现

最佳实践：
- 角色命名规范：建议采用 `[业务域]_[功能]_role` 格式（如 `sales_readonly_role`）
- 服务用户命名：自动化流程的服务用户建议以 `svc_` 前缀命名
- 用户创建前检查：使用 SHOW USERS 确认用户是否已存在于工作空间中
- 定期审计：定期审查用户权限和角色分配，确保符合安全要求
- 权限变更后验证：使用相关用户身份测试验证权限是否正确生效
- CREATE USER 在工作空间中执行时是将已有实例用户添加到空间，非创建新用户
- DROP USER 只从当前工作空间移除用户，不影响其他工作空间和实例级身份
- SHOW GRANTS 结果中 `SELECT ALL` 表示 SELECT ON ALL objects（即对所有具有 SELECT 权限点的对象拥有查询权限），是层级继承授权的显示方式
- 查看视图列表使用 `SHOW TABLES WHERE table_type = 'VIEW'`，查看动态表使用 `SHOW TABLES WHERE is_dynamic = true`（SHOW VIEWS 和 SHOW DYNAMIC TABLES 语法不被支持）
- 查看指定 Schema 下的表使用 `SHOW TABLES IN <schema_name>`（注意不支持 `SHOW TABLES IN SCHEMA <name>` 语法）
- 遇到 system_admin 或 workspace_user 角色时，这些是早期工作空间的历史预置角色，新建工作空间不再创建，参见「已下线的历史预置角色」
