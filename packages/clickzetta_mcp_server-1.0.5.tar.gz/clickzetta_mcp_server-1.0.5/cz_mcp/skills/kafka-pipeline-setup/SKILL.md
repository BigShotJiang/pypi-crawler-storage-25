---
name: kafka-pipeline-setup
description: |
  搭建 ClickZetta Kafka 实时数据管道，覆盖从 Kafka 存储连接创建、PIPE 管道配置到管道监控分析的
  端到端工作流。当用户说"创建 Kafka 管道"、"实时数据接入"、"Kafka 数据导入"、"流式数据管道"时触发。
  包含智能数据源推断、COPY 语句自动生成、ingest_mode 自动切换、管道健康分析等 ClickZetta 特有逻辑。
---

# Kafka 数据管道搭建工作流

## 指令

### 步骤 1：创建 Kafka 存储连接
使用 `create_storage_connection` 创建 Kafka 类型连接：
- connection_type 设为 "KAFKA"
- 必需属性：kafka.bootstrap.servers（broker 地址列表）
- 可选属性：安全认证配置（SASL/SSL）
- 注意云提供商兼容性：确认当前环境支持 Kafka 连接

### 步骤 2：确认目标表存在
使用 `desc_object` 或 `read_query` 确认目标表已创建：
- 目标表的列定义需与 Kafka 消息结构匹配
- 如果表不存在，先用 `create_table` 创建
- 表名建议带 schema 前缀（如 `my_schema.kafka_events`）

### 步骤 3：创建 PIPE 管道
使用 `create_pipe` 创建 Kafka 数据管道，关键参数：
- pipe_name：管道名称
- target_table：目标表（建议带 schema 前缀，工具会自动补全）
- source_type：设为 "kafka"（或留空让工具智能推断）
- kafka_brokers：Kafka broker 地址
- kafka_topic：要消费的 topic
- kafka_consumer_group：消费者组名
- 工具内部智能逻辑：
  - 自动检测 Kafka 参数 → ingest_mode 切换为 KAFKA
  - 自动生成 COPY 语句（含 read_kafka 函数调用）
  - schema 自动补全（target_table 无 schema 时补全当前 schema）
  - 表存在性轻量校验
- PIPE 限制：不支持 FILES()、SUBDIRECTORY、REGEXP 语法

### 步骤 4：配置管道参数（可选）
使用 `alter_pipe` 调整运行参数：
- batch_interval_in_seconds：批处理间隔
- batch_size_per_kafka_partition：每分区批大小
- max_skip_batch_count_on_error：错误跳过批次数
- virtual_cluster：指定运行的计算集群

### 步骤 5：监控和分析管道
使用 `analyze_kafka_data_pipeline` 分析管道健康状态：
- 查看运行中的 Kafka pipes 详细信息
- 检查贴源层表的基础信息和结构
- 分析动态表的状态和配置
- 多维度 Schema 相似度计算
- E2E Pipeline 血缘关系追踪

## 示例

### 示例 1：搭建用户行为事件管道
```
1. create_storage_connection(
     connection_name='kafka_conn',
     connection_type='KAFKA',
     endpoint='broker1:9092,broker2:9092'
   )
2. create_table(
     table_name='user_events',
     columns=[
       {"name":"event_id","type":"STRING"},
       {"name":"user_id","type":"BIGINT"},
       {"name":"event_type","type":"STRING"},
       {"name":"event_time","type":"TIMESTAMP"},
       {"name":"payload","type":"STRING"}
     ]
   )
3. create_pipe(
     pipe_name='user_events_pipe',
     target_table='my_schema.user_events',
     kafka_brokers='broker1:9092,broker2:9092',
     kafka_topic='user-events',
     kafka_consumer_group='cz_user_events_cg'
   )
4. analyze_kafka_data_pipeline(data_scope='all')
```

## 故障排除

错误：file format not specified
原因：PIPE 无法推断 Kafka 消息格式
解决方案：显式指定 file_format 参数（如 'JSON'），或先用 preview_volume_data 确认数据格式

错误：目标表不存在
原因：create_pipe 的表存在性校验发现目标表未创建
解决方案：先创建目标表，确保表名包含正确的 schema 前缀

错误：ingest_mode 不匹配
原因：Kafka 数据源需要 KAFKA 模式，但指定了其他模式
解决方案：工具会自动切换，如仍失败则显式设置 source_type='kafka'

错误：PIPE 创建成功但无数据流入
原因：可能是 Kafka 连接配置、topic 名称或消费者组问题
解决方案：检查 Kafka broker 可达性、topic 是否存在、消费者组权限
