#!/usr/bin/env python3
"""
HTTP MCP Server Runner for Clickzetta Studio
Entry point for running the HTTP MCP server with argument parsing
"""

import os
os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"

import argparse
import asyncio
import logging
import socket
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path
from cz_mcp.transport.mcp_server import ClickzettaMCPServer


def setup_logging(log_dir: str = None):
    """
    Setup rotating file logger for application and access logs

    Args:
        log_dir: Directory to store log files. Defaults to script directory/logs
    """
    # Determine log directory
    if log_dir is None:
        script_dir = Path(__file__).parent.parent
        log_dir = script_dir / "logs"
    else:
        log_dir = Path(log_dir)

    # Create logs directory if it doesn't exist
    log_dir.mkdir(parents=True, exist_ok=True)

    # Application log file
    app_log_file = log_dir / "server.log"
    # Access log file
    access_log_file = log_dir / "access.log"

    # Create formatters
    app_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    access_formatter = logging.Formatter(
        '%(asctime)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    # Setup rotating file handler for application logs
    # Max 10MB per file, keep 5 backup files
    app_handler = RotatingFileHandler(
        app_log_file,
        maxBytes=10 * 1024 * 1024,  # 10MB
        backupCount=5,
        encoding='utf-8'
    )
    app_handler.setFormatter(app_formatter)
    app_handler.setLevel(logging.INFO)

    # Setup rotating file handler for access logs
    # Max 10MB per file, keep 10 backup files (access logs tend to be larger)
    access_handler = RotatingFileHandler(
        access_log_file,
        maxBytes=10 * 1024 * 1024,  # 10MB
        backupCount=10,
        encoding='utf-8'
    )
    access_handler.setFormatter(access_formatter)
    access_handler.setLevel(logging.INFO)

    # Setup console handler for stdout
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(app_formatter)
    console_handler.setLevel(logging.INFO)

    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    root_logger.handlers.clear()  # Clear any existing handlers
    root_logger.addHandler(app_handler)
    root_logger.addHandler(console_handler)

    # Configure access logger (separate from application logger)
    access_logger = logging.getLogger('access')
    access_logger.setLevel(logging.INFO)
    access_logger.handlers.clear()
    access_logger.addHandler(access_handler)
    access_logger.propagate = False  # Don't propagate to root logger

    # Log startup information
    logging.info(f"Logging configured:")
    logging.info(f"  Application log: {app_log_file}")
    logging.info(f"  Access log: {access_log_file}")
    logging.info(f"  Log rotation: 10MB per file")

    return str(log_dir)


def create_parser():
    """Create argument parser for HTTP server"""
    parser = argparse.ArgumentParser(
        description="Clickzetta HTTP MCP Server",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s                          # Start with defaults (0.0.0.0:8000, dev env)
  %(prog)s --host localhost --port 8080
  %(prog)s --port random  # Use random port
        """
    )
    
    parser.add_argument(
        '--host', 
        default='0.0.0.0',
        help='Host to bind to (default: 0.0.0.0)'
    )
    
    parser.add_argument(
        '--port', 
        default='8000',
        help='Port to bind to, or "random" for random port (default: 8000)'
    )
    
    return parser


def parse_port(port_arg: str) -> int:
    """Parse port argument, handling 'random' case"""
    if port_arg.lower() == 'random':
        # Find a random available port
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(('', 0))
            return s.getsockname()[1]
    else:
        return int(port_arg)


async def main():
    """Main entry point for HTTP server"""
    # Setup logging first
    log_dir = setup_logging()

    parser = create_parser()
    args = parser.parse_args()

    # Parse port
    try:
        port = parse_port(args.port)
    except ValueError:
        logging.error(f"Invalid port '{args.port}'. Use a number or 'random'.")
        sys.exit(1)

    logging.info("=" * 60)
    logging.info("   Starting Clickzetta HTTP MCP Server")
    logging.info(f"   Host: {args.host}")
    logging.info(f"   Port: {port}")
    logging.info(f"   Transport type: HTTP (centralized deployment)")
    logging.info(f"   Authentication: Bearer token from headers")
    logging.info(f"   Log directory: {log_dir}")
    logging.info("")
    logging.info("Example client requests:")
    logging.info("  With Authorization header:")
    logging.info(f"    curl 'http://{args.host}:{port}' \\")
    logging.info("      -H 'Authorization: Bearer YOUR_TOKEN' \\")
    logging.info("=" * 60)

    try:
        server = ClickzettaMCPServer(args.host, port, transport_type="http")
        await server.run()
    except KeyboardInterrupt:
        logging.info("\nServer stopped by user")
    except Exception as e:
        logging.exception(f"Server failed to start: {e}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())