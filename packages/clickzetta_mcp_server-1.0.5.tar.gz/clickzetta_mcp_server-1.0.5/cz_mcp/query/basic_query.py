"""
Query Basic Operations - 基础查询处理器
包含read_query, write_query, match_all等基础查询功能
"""

from cz_mcp.handlers.parameter_handler import HandlerFactory
from cz_mcp.common.utilities import (
    convert_df_to_dict,
    ResponseBuilder
)
from .sql_intelligence import sql_intelligence
from ..studio_config_manager import StudioConfig

from loguru import logger


async def handle_read_query(arguments=None, studio_config: StudioConfig = None, **kwargs):
    """处理只读查询请求"""
    # 使用参数处理器 (Notice: 该方式不推荐使用，建议修改为使用normalize自动处理)
    params = HandlerFactory.read_query().process_arguments(arguments)
    query_upper = params["query"].upper().strip()
    write_detector = kwargs.get("writer_detector")
    db = kwargs.get("db")

    # 检查写操作（如果write_detector可用）
    if write_detector is not None:
        analysis = write_detector.analyze_query(params["query"])
        if analysis["contains_write"]:
            error_response = {
                "success": False,
                "error_type": "write_operation_not_allowed",
                "friendly_message": "LH-execute_read_query 工具不支持写操作",
                "operation_type": analysis.get("operation_type", "WRITE"),
                "suggestions": [
                    f"请使用 LH-execute_write_query 工具执行 {analysis.get('operation_type', 'WRITE')} 操作",
                    "LH-execute_write_query 专门用于处理 INSERT/UPDATE/DELETE/CREATE/DROP/ALTER 等写操作"
                ]
            }
            return ResponseBuilder.create_yaml_json_response([error_response], None, studio_config=studio_config)
    else:
        # 如果write_detector不可用，进行简单的写操作检查
        write_keywords = ['INSERT', 'UPDATE', 'DELETE', 'CREATE', 'DROP', 'ALTER', 'TRUNCATE']
        detected_keyword = None
        for keyword in write_keywords:
            if keyword in query_upper:
                detected_keyword = keyword
                break

        if detected_keyword:
            error_response = {
                "success": False,
                "error_type": "write_operation_not_allowed",
                "friendly_message": "LH-execute_read_query 工具不支持写操作",
                "operation_type": detected_keyword,
                "suggestions": [
                    f"请使用 LH-execute_write_query 工具执行 {detected_keyword} 操作",
                    "LH-execute_write_query 专门用于处理 INSERT/UPDATE/DELETE/CREATE/DROP/ALTER 等写操作"
                ]
            }
            return ResponseBuilder.create_yaml_json_response([error_response], None, studio_config=studio_config)

    query = params["query"]
    if query_upper.startswith("DESCRIBE "):
        query = "DESC " + query_upper[len("DESCRIBE "):]
    limit = params.get("limit", 50)
    verbose = params.get("verbose", False)
    
    # 检查是否需要语法转换或LIMIT，但不自动执行
    suggested_query = _convert_unsupported_show_commands(query)
    needs_conversion = query != suggested_query

    # 检查是否需要添加LIMIT
    needs_limit = False
    limit_suggestion = query
    if limit and "limit" not in query.lower():
        query_upper = query.upper().strip()
        if (query_upper.startswith("SELECT") or
            (query_upper.startswith("WITH") and "SELECT" in query_upper)):
            needs_limit = True
            limit_suggestion = f"{query.rstrip(';')} LIMIT {limit}"

    # 如果需要转换或添加LIMIT，返回建议而不是自动执行
    if needs_conversion or needs_limit:
        suggestions = []
        if needs_conversion:
            suggestions.append(f"语法转换建议: {suggested_query}")
        if needs_limit:
            suggestions.append(f"LIMIT建议: {limit_suggestion}")

        suggestion_response = {
            "success": False,
            "query_needs_modification": True,
            "suggestions": suggestions,
            "reason": "为了兼容ClickZetta语法或提高查询性能，建议修改查询语句",
            "action": "请复制建议的SQL语句重新执行"
        }

        return ResponseBuilder.create_yaml_json_response([suggestion_response], None, studio_config=studio_config)
    
    try:
        data, data_id = db.execute_query(query + ";")
        
        # 转换数据为字典格式
        if data is not None:
            result_dict = convert_df_to_dict(data)
        else:
            result_dict = []
            
    except Exception as e:
        # 返回详细的错误信息，包含执行的SQL和原始错误

        error_msg = str(e)
        logger.error(f"读查询执行失败: {error_msg}")

        analysis = sql_intelligence.analyze_sql_error(error_msg, query)

        # 构建详细的错误响应
        error_response = {
            "error_type": "query_execution_failed",
            "friendly_message": analysis["friendly_message"] or "查询执行失败",
            "original_error": error_msg,
            "suggestions": analysis["suggestions"][:3],  # 提供更多建议
            "analysis": {
                "no_auto_conversion": True,  # 标识不再自动转换
                "limit_applied": limit if limit and "LIMIT" in query else None
            }
        }

        # 返回错误响应而不是抛出异常
        return ResponseBuilder.create_yaml_json_response([error_response], None, studio_config=studio_config)
    
    # 构建响应
    response_data = {
        "data": result_dict,
        "count": len(result_dict),
        "truncated": limit is not None and len(result_dict) >= limit,
        "hint": f"Limited to {limit} rows" if limit and len(result_dict) >= limit else None
    }
    
    if verbose:
        response_data["sql_query_executed"] = query
        response_data["parameter_details"] = {
            "limit_applied": limit,
            "verbose_mode": True
        }
    
    return ResponseBuilder.create_yaml_json_response([response_data], data_id, studio_config=studio_config)


async def handle_write_query(arguments=None, studio_config: StudioConfig = None, **kwargs):
    """处理写入查询请求"""
    write_detector = kwargs.get("writer_detector")
    db = kwargs.get("db")
    # 使用参数处理器
    params = HandlerFactory.write_query().process_arguments(arguments)
    
    query = params["query"]
    verbose = params.get("verbose", False)

    # 检查是否需要语法转换，但不自动执行
    suggested_query = _convert_unsupported_show_commands(query)
    needs_conversion = query != suggested_query

    # 如果需要转换，返回建议而不是自动执行
    if needs_conversion:
        suggestion_response = {
            "query_needs_modification": True,
            "suggested_query": suggested_query,
            "reason": "为了兼容ClickZetta语法，建议修改查询语句",
            "action": "请复制建议的SQL语句重新执行"
        }

        return ResponseBuilder.create_yaml_json_response([suggestion_response], None, studio_config=studio_config)

    # 分析查询是否包含写操作
    analysis = write_detector.analyze_query(query)
    if not analysis["contains_write"]:
        logger.warning(f"查询可能不包含写操作: {query[:100]}...")
    
    try:
        data, data_id = db.execute_query(query + ";")
        
        # 写操作通常不返回数据，但可能有执行结果
        if data is not None:
            result_dict = convert_df_to_dict(data)
        else:
            result_dict = []
        
        response_data = {
            "message": "Write query executed successfully",
            "affected_rows": len(result_dict) if result_dict else 0,
            "operation_type": analysis.get("operation_type", "UNKNOWN"),
            "result": result_dict if result_dict else None
        }
        
        if verbose:
            response_data["sql_query_executed"] = query
            response_data["write_analysis"] = analysis
        
        return ResponseBuilder.create_yaml_json_response([response_data], data_id, studio_config=studio_config)
        
    except Exception as e:
        # 返回详细的错误信息，包含执行的SQL和原始错误
        error_msg = str(e)
        logger.error(f"写查询执行失败: {error_msg}")

        # 使用智能分析器提供友好的错误信息

        analysis_result = sql_intelligence.analyze_sql_error(error_msg, query)

        # 构建详细的错误响应
        error_response = {
            "success": False,
            "error_type": "write_query_execution_failed",
            "friendly_message": analysis_result["friendly_message"] or "写操作失败",
            "original_error": error_msg,
            "suggestions": analysis_result["suggestions"][:3],  # 提供更多建议
            "write_analysis": analysis,
            "operation_type": analysis.get("operation_type", "UNKNOWN")
        }

        return ResponseBuilder.create_yaml_json_response([error_response], None, studio_config=studio_config)


def _convert_unsupported_show_commands(query: str) -> str:
    """
    自动转换ClickZetta不支持的SHOW命令和其他SQL语法差异

    转换规则：
    1. SHOW命令转换（与标准SQL的差异）
    2. DATABASE/SCHEMA概念差异
    3. 索引查看命令差异
    4. EXPLAIN命令支持范围
    """
    query_stripped = query.strip().rstrip(';')
    query_upper = query_stripped.upper()

    # === SHOW TABLE类型命令转换 ===

    # SHOW DYNAMIC TABLES → SHOW TABLES WHERE is_dynamic = true
    if query_upper == "SHOW DYNAMIC TABLES":
        logger.info("转换 SHOW DYNAMIC TABLES → SHOW TABLES WHERE is_dynamic = true")
        return "SHOW TABLES WHERE is_dynamic = true"

    # SHOW VIEWS → SHOW TABLES WHERE table_type = 'VIEW'
    elif query_upper == "SHOW VIEWS":
        logger.info("转换 SHOW VIEWS → SHOW TABLES WHERE table_type = 'VIEW'")
        return "SHOW TABLES WHERE table_type = 'VIEW'"

    # SHOW MATERIALIZED VIEWS → SHOW TABLES WHERE table_type = 'MATERIALIZED_VIEW'
    elif query_upper == "SHOW MATERIALIZED VIEWS":
        logger.info("转换 SHOW MATERIALIZED VIEWS → SHOW TABLES WHERE table_type = 'MATERIALIZED_VIEW'")
        return "SHOW TABLES WHERE table_type = 'MATERIALIZED_VIEW'"

    # === DATABASE/WORKSPACE概念转换 ===

    # SHOW DATABASES → SHOW CATALOGS (ClickZetta使用workspace概念)
    elif query_upper == "SHOW DATABASES":
        logger.info("转换 SHOW DATABASES → SHOW CATALOGS (显示workspaces)")
        return "SHOW CATALOGS"

    # === 索引命令转换 ===

    # SHOW INDEXES ON table → SHOW INDEX FROM table
    elif query_upper.startswith("SHOW INDEXES ON "):
        table_name = query_stripped[len("SHOW INDEXES ON "):].strip()
        logger.info(f"转换 SHOW INDEXES ON {table_name} → SHOW INDEX FROM {table_name}")
        return f"SHOW INDEX FROM {table_name}"

    # SHOW INDEXES IN table → SHOW INDEX FROM table
    elif query_upper.startswith("SHOW INDEXES IN "):
        table_name = query_stripped[len("SHOW INDEXES IN "):].strip()
        logger.info(f"转换 SHOW INDEXES IN {table_name} → SHOW INDEX FROM {table_name}")
        return f"SHOW INDEX FROM {table_name}"

    # SHOW INDEXES FROM table (标准化为FROM语法)
    elif query_upper.startswith("SHOW INDEXES FROM "):
        table_name = query_stripped[len("SHOW INDEXES FROM "):].strip()
        logger.info(f"转换 SHOW INDEXES FROM {table_name} → SHOW INDEX FROM {table_name}")
        return f"SHOW INDEX FROM {table_name}"

    # === USE语句转换 ===

    # USE DATABASE name → USE SCHEMA name (ClickZetta不使用DATABASE概念)
    elif query_upper.startswith("USE DATABASE "):
        schema_name = query_stripped[len("USE DATABASE "):].strip()
        logger.info(f"转换 USE DATABASE {schema_name} → USE SCHEMA {schema_name}")
        return f"USE SCHEMA {schema_name}"

    # === EXPLAIN命令检查 ===

    # EXPLAIN ANALYZE → 不支持，给出提示
    elif query_upper.startswith("EXPLAIN ANALYZE"):
        logger.warning("EXPLAIN ANALYZE不被支持，ClickZetta只支持基本的EXPLAIN查询")
        # 移除ANALYZE，保留基本的EXPLAIN
        remaining_query = query_stripped[len("EXPLAIN ANALYZE"):].strip()
        return f"EXPLAIN {remaining_query}"


    # === 常见的不支持命令提示 ===

    # SHOW TRIGGERS → 不支持
    elif query_upper.startswith("SHOW TRIGGERS"):
        raise ValueError(
            "ClickZetta不支持SHOW TRIGGERS命令。请使用其他方式查看表信息，或使用 get_product_knowledge 工具获取ClickZetta语法文档。")

    # SHOW PROCEDURES → 不支持
    elif query_upper.startswith("SHOW PROCEDURES"):
        raise ValueError(
            "ClickZetta不支持SHOW PROCEDURES命令。请使用SHOW FUNCTIONS查看函数信息，或使用 get_product_knowledge 工具获取详细语法。")

    # SHOW ENGINES → 不支持
    elif query_upper.startswith("SHOW ENGINES"):
        raise ValueError(
            "ClickZetta不支持SHOW ENGINES命令。这是云原生数据湖仓，无需存储引擎选择。如需了解更多，请使用 get_product_knowledge 工具。")

    # 返回原始查询(无需转换)
    return query