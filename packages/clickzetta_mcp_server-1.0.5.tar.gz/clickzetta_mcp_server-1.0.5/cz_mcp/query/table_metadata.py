"""
Table Metadata Query - 表元数据查询处理器
获取指定schema下所有表的完整元数据信息
"""
import json
from typing import Any, Dict

from cz_mcp.common.utilities import convert_df_to_dict, ResponseBuilder
from .sql_intelligence import sql_intelligence
from ..studio_config_manager import StudioConfig
from loguru import logger

async def get_all_tables_metadata(arguments, studio_config: StudioConfig = None, **kwargs):
    """
    获取指定schema下所有表的完整元数据（包括列信息）

    输入:
      - schema_name: str  Schema名称，例如"sv_lxj"或"tpch_ai"
      - include_columns: bool  是否包含列详情（默认True）
      - verbose: bool  是否返回执行的SQL等额外信息

    输出:
      - 使用ResponseBuilder返回标准的YAML+JSON响应
      - data为表元数据列表，每个表包含：
        - table_name: 表名
        - schema_name: Schema名
        - workspace: 工作空间名
        - table_type: 表类型
        - columns: 列信息列表（如果include_columns=True）
    """
    schema_name: str = studio_config.schema
    schema_name = arguments.get("schema_name", schema_name)
    db = kwargs.get("db", None)
    include_columns: bool = arguments.get("include_columns", True)
    verbose: bool = arguments.get("verbose", False)

    if not schema_name:
        raise ValueError("❌ schema_name 参数不能为空。请提供要查询的 schema 名称。")

    logger.info(f"Get all tables metadata for schema: {schema_name}, include_columns={include_columns}")

    executed_sqls: list[str] = []

    # 1) 获取schema下的所有表
    show_tables_sql = f"SHOW TABLES IN {schema_name}"
    executed_sqls.append(show_tables_sql)

    try:
        tables_df, data_id = db.execute_query(show_tables_sql + ";")
        tables = convert_df_to_dict(tables_df) if tables_df is not None else []
        logger.info(f"Found {len(tables)} tables in schema {schema_name}")
    except Exception as e:
        error_msg = str(e)
        logger.error(f"SHOW TABLES failed: {error_msg}")
        analysis = sql_intelligence.analyze_sql_error(error_msg, show_tables_sql)
        detailed_error = (
            f"❌ {analysis['friendly_message'] or f'获取 {schema_name} 下的表列表失败'}\n\n"
            f"📝 SQL executed: {show_tables_sql}\n"
            f"🔍 Original Error: {error_msg}\n\n"
            f"💡 Suggestions: {'; '.join(analysis['suggestions'][:2])}"
        )
        raise ValueError(detailed_error)

    if not tables:
        response_data = {
            "success": False,
            "schema_name": schema_name,
            "tables": [],
            "table_count": 0,
            "message": f"Schema '{schema_name}' 中没有找到任何表"
        }
        if verbose:
            response_data["sql_query_executed"] = executed_sqls
        return ResponseBuilder.create_yaml_json_response([response_data], data_id)

    # 2) 如果需要列信息，为每个表执行 DESC TABLE EXTENDED
    tables_metadata = []

    for table in tables:
        table_name = table.get("table_name") or table.get("name") or ""
        if not table_name:
            continue

        # 构建表的基础元数据
        table_meta = {
            "workspace": table.get("workspace") or table.get("catalog") or "",
            "table_type": table.get("table_type") or "TABLE",
            "schema_name": table.get("schema_name") or table.get("schema") or schema_name,
            "table_name": table_name,
            "is_view": table.get("is_view", False),
            "is_materialized_view": table.get("is_materialized_view", False),
            "is_external": table.get("is_external", False),
            "is_dynamic": table.get("is_dynamic", False),
        }

        # 如果需要列信息，执行 DESC TABLE EXTENDED
        if include_columns:
            # 构建完整表名
            workspace = table_meta["workspace"]
            schema = table_meta["schema_name"]
            full_table_name = f"{workspace}.{schema}.{table_name}" if workspace else f"{schema}.{table_name}"

            # 使用 EXTENDED 获取完整信息（包括主键、外键等）
            desc_sql = f"DESC TABLE EXTENDED {full_table_name}"

            logger.info(f"执行的SQL语句是{desc_sql};")

            executed_sqls.append(desc_sql)

            try:
                cols_df, _ = db.execute_query(desc_sql + ";")
                cols = convert_df_to_dict(cols_df) if cols_df is not None else []

                # 解析 DESC EXTENDED 的返回结果
                # DESC EXTENDED 返回格式：列信息 + 元数据行（如 primary_key, foreign_key等）
                columns_info = []
                primary_keys = []
                foreign_keys = []

                for col in cols:
                    col_name_field = col.get("col_name") or col.get("column_name") or col.get("name") or ""

                    # 检查是否是元数据行（primary_key, foreign_key 等）
                    if col_name_field.lower() == "primary_key":
                        # 主键信息通常在 data_type 字段中（JSON 或文本格式）
                        pk_value = col.get("data_type") or col.get("type") or col.get("col_type") or ""
                        if pk_value:
                            # 尝试解析主键列表
                            try:
                                import json
                                pk_data = json.loads(pk_value) if isinstance(pk_value, str) and pk_value.startswith(
                                    '[') else pk_value
                                if isinstance(pk_data, list):
                                    primary_keys = pk_data
                                elif isinstance(pk_data, str):
                                    # 可能是逗号分隔的字符串
                                    primary_keys = [pk.strip() for pk in pk_data.split(',') if pk.strip()]
                            except:
                                # 解析失败，尝试简单分割
                                if isinstance(pk_value, str):
                                    primary_keys = [pk.strip() for pk in
                                                    pk_value.replace('[', '').replace(']', '').split(',') if pk.strip()]
                        continue

                    elif col_name_field.lower() == "foreign_key" or col_name_field.lower() == "foreign_keys":
                        # 外键信息
                        fk_value = col.get("data_type") or col.get("type") or col.get("col_type") or ""
                        if fk_value and fk_value not in ["", "null", "NULL", "None"]:
                            try:
                                import json
                                fk_data = json.loads(fk_value) if isinstance(fk_value, str) and (
                                            fk_value.startswith('[') or fk_value.startswith('{')) else fk_value
                                if isinstance(fk_data, list):
                                    foreign_keys = fk_data
                                elif isinstance(fk_data, dict):
                                    foreign_keys = [fk_data]
                                elif isinstance(fk_data, str) and fk_data.strip():
                                    # 可能是描述性文本，保存原始值
                                    foreign_keys = [{"raw": fk_data}]
                            except:
                                # 解析失败，保存原始值
                                if isinstance(fk_value, str) and fk_value.strip():
                                    foreign_keys = [{"raw": fk_value}]
                        continue

                    # 普通列信息
                    if col_name_field:
                        col_info = {
                            "name": col_name_field,
                            "type": col.get("type") or col.get("data_type") or col.get("col_type") or "",
                            "nullable": col.get("nullable", True),
                            "comment": col.get("comment") or col.get("col_comment") or "",
                        }

                        # 可选字段
                        if "default_value" in col and col["default_value"]:
                            col_info["default_value"] = col["default_value"]

                        # 检查是否是主键列（从 SHOW TABLES 返回或列属性中）
                        if "primary_key" in col:
                            col_info["is_primary_key"] = col["primary_key"]

                        columns_info.append(col_info)

                # 添加列信息
                table_meta["columns"] = columns_info
                table_meta["column_count"] = len(columns_info)

                # 添加主键信息（如果有）
                if primary_keys:
                    table_meta["primary_key"] = primary_keys
                    table_meta["primary_key_columns"] = primary_keys  # 兼容字段
                    logger.debug(f"Table {table_name} has primary key: {primary_keys}")

                # 添加外键信息（如果有）
                if foreign_keys:
                    table_meta["foreign_keys"] = foreign_keys
                    logger.debug(f"Table {table_name} has foreign keys: {foreign_keys}")

                    # 解析外键提示（用于后续生成关系）
                    foreign_key_hints = []
                    for fk in foreign_keys:
                        if isinstance(fk, dict) and "raw" not in fk:
                            # 结构化的外键信息
                            hint = {
                                "column": fk.get("column") or fk.get("columns", [None])[0] if isinstance(
                                    fk.get("columns"), list) else None,
                                "references_table": fk.get("references_table") or fk.get("ref_table"),
                                "references_column": fk.get("references_column") or fk.get("ref_column") or
                                                     fk.get("ref_columns", [None])[0] if isinstance(
                                    fk.get("ref_columns"), list) else None
                            }
                            if hint["column"] and hint["references_table"]:
                                foreign_key_hints.append(hint)

                    if foreign_key_hints:
                        table_meta["foreign_key_hints"] = foreign_key_hints

            except Exception as e:
                # 列信息获取失败时，记录错误但不中断整体流程
                logger.warning(f"DESC TABLE EXTENDED failed for {full_table_name}: {e}")
                table_meta["columns"] = []
                table_meta["column_count"] = 0
                table_meta["metadata_error"] = str(e)

        tables_metadata.append(table_meta)

    # 3) 构建响应
    response_data = {
        "schema_name": schema_name,
        "tables": tables_metadata,
        "table_count": len(tables_metadata),
    }

    if verbose:
        response_data["sql_query_executed"] = executed_sqls
        response_data["parameter_details"] = {
            "include_columns": include_columns,
            "verbose_mode": True
        }

    return ResponseBuilder.create_yaml_json_response([response_data], data_id)


async def get_view_dimensions(arguments, studio_config: StudioConfig = None, **kwargs):
    schema_name = studio_config.schema
    schema_name = arguments.get("schema_name", schema_name)
    db = kwargs.get("db", None)
    semantic_view = arguments.get("semantic_view", "")

    # 1. 获取当前定义
    full_view_name = f"{schema_name}.{semantic_view}"


    # 这里是通过视图名拼接成SQL
    query = f"set cz.sql.desc.format=json; DESC extended {full_view_name};"
    data_frame, data_id = db.execute_query(query)


    def_data = None
    for item in data_frame:
        if item.get('column_name') == 'def' and item.get('data_type'):
            def_data = item['data_type']
            break
    dimensions_info = []
    if def_data:
        # 2. 解析 JSON 数据
        semantic_view_data = json.loads(def_data)

        # 3. 提取所有 dimensions（核心步骤）
        dimensions = semantic_view_data.get('dimensions', [])

        # 5. 提取关键信息到列表（便于后续使用）

        for dim in dimensions:
            dimensions_info.append({
                'dimensions_name': dim['name']['name'],
                'logical_table': dim['name']['namespace'],
                'expression': dim['expressionExpandedText'],
                'comment': dim['comment'],
                'synonyms': dim['synonyms']
            })
    else:
        print("未找到'def'字段或字段数据为空")


    # 构建响应
    response_data = {
        "schema_name": schema_name,
        "dimensions_info": dimensions_info,
    }

    return ResponseBuilder.create_yaml_json_response([response_data], data_id)



async def get_tables_column_names(arguments: Dict[str, Any], db, *_):
    """
    获取指定schema下所有表的列名，对列名为空的表（视图）解析其逻辑表，替换物理表名为逻辑表名

    输入:
      - schema_name: str  Schema名称

    输出:
      - 逻辑表信息列表，包含logical_table_name、column_names等
    """
    schema_name: str = arguments.get("schema_name", "").strip()
    if not schema_name:
        raise ValueError("❌ schema_name 参数不能为空")

    logger.info(f"获取Schema {schema_name}下的表/视图信息")

    # 1. 获取schema下所有表（含视图）
    show_tables_sql = f"SHOW TABLES IN {schema_name}"
    try:
        tables_df, data_id = db.execute_query(show_tables_sql + ";")
        tables = convert_df_to_dict(tables_df) if tables_df is not None else []
        logger.info(f"找到{len(tables)}张表/视图")
    except Exception as e:
        error_msg = str(e)
        logger.error(f"获取表列表失败: {error_msg}")
        raise ValueError(f"获取表列表失败: {error_msg}")

    if not tables:
        response_data = {
            "schema_name": schema_name,
            "logical_tables": [],
            "message": f"Schema '{schema_name}' 无表/视图"
        }
        return ResponseBuilder.create_yaml_json_response([response_data], data_id)

    # 2. 先获取所有表的列名，得到原始tables列表（含视图）
    original_tables = []
    for table in tables:
        table_name = table.get("table_name") or table.get("name") or ""
        if not table_name:
            continue

        # 构建完整表名
        schema = table.get("schema_name") or schema_name
        workspace = table.get("workspace") or ""
        full_table_name = f"{workspace}.{schema}.{table_name}" if workspace else f"{schema}.{table_name}"

        # 查询列名
        desc_sql = f"DESC TABLE {full_table_name}"
        column_names = []
        try:
            cols_df, _ = db.execute_query(desc_sql + ";")
            cols = convert_df_to_dict(cols_df) if cols_df is not None else []
            for col in cols:
                col_name = col.get("col_name") or col.get("column_name") or ""
                if col_name and col_name.lower() not in ["primary_key", "foreign_key"]:
                    column_names.append(col_name)
        except Exception as e:
            logger.warning(f"查询{full_table_name}列名失败: {e}")

        original_tables.append({
            "table_name": table_name,
            "column_names": column_names,
            "column_count": len(column_names)
        })

    print(original_tables)

    # 3. 筛选出列名为空的表（即视图），解析其逻辑表与物理表的映射
    logical_physical_map = {}
    for table in original_tables:
        if table["column_names"] != []:
            continue  # 不是视图，跳过

        # 对列名为空的表执行DESC EXTENDED
        table_name = table["table_name"]
        schema = schema_name
        workspace = ""
        full_table_name = f"{workspace}.{schema}.{table_name}" if workspace else f"{schema}.{table_name}"
        desc_extended_sql = f"DESC EXTENDED {full_table_name}"

        print(desc_extended_sql)

        try:
            data, _ = db.execute_query(desc_extended_sql + ";")
            result_dict = convert_df_to_dict(data) if data is not None else []
            logical_physical_map = parse_logical_physical_mapping(result_dict)  # 逻辑表名: 物理表名
        except Exception as e:
            logger.warning(f"解析视图{full_table_name}失败: {e}")

    # 4. 替换原始tables中的物理表名为逻辑表名
    final_logical_tables = []
    for table in original_tables:
        if table["column_names"] == []:
            continue  # 跳过视图本身

        # 替换物理表名为逻辑表名
        physical_table_name = table["table_name"]
        logical_table_name = logical_physical_map.get(physical_table_name, physical_table_name)

        final_logical_tables.append({
            "logical_table_name": logical_table_name,
            "column_names": table["column_names"],
            "column_count": table["column_count"]
        })

    # 构建响应
    response_data = {
        "schema_name": schema_name,
        "logical_tables": final_logical_tables,
        "table_count": len(final_logical_tables),
        "message": f"成功获取{len(final_logical_tables)}个逻辑表的列信息"
    }

    print(final_logical_tables)
    return ResponseBuilder.create_yaml_json_response([response_data], data_id)



def parse_logical_physical_mapping(result_dict):
    """
    从新格式的 result_dict 中解析逻辑表别名与物理表名的映射关系

    Args:
        result_dict: DESC EXTENDED 返回的结果列表（含#logical tables段落）

    Returns:
        dict: {物理表名: 逻辑表别名}
    """

    # print(result_dict)

    logical_physical_map = {}
    in_logical_tables_section = False  # 标记是否进入#logical tables段落

    for row in result_dict:
        column_name = row.get("column_name", "").strip()
        data_type = row.get("data_type", "").strip()

        # 1. 进入#logical tables段落
        if column_name == "#logical tables":
            in_logical_tables_section = True
            continue

        # 2. 离开#logical tables段落（遇到下一个#开头的段落）
        if in_logical_tables_section and column_name.startswith("#"):
            break

        # 3. 解析逻辑表行（column_name为逻辑表名，data_type为物理表路径）
        if in_logical_tables_section and column_name and "." in data_type:
            # 提取物理表名（从完整路径datagpt_ws.sv_oa.ordsers中取最后一段）
            physical_table_name = data_type.split(".")[-1]
            # column_name即为逻辑表别名
            logical_table_alias = column_name
            # 构建映射
            logical_physical_map[physical_table_name] = logical_table_alias

    print(logical_physical_map)

    return logical_physical_map


async def get_tables_metadata(arguments, db, *_):
    """
    获取指定schema下所有**包含主键或外键**的表的完整元数据（包括列信息）

    输入:
      - schema_name: str  Schema名称，例如"sv_lxj"或"tpch_ai"
      - include_columns: bool  是否包含列详情（默认True）
      - verbose: bool  是否返回执行的SQL等额外信息

    输出:
      - 使用ResponseBuilder返回标准的YAML+JSON响应
      - data为表元数据列表，每个表包含：
        - table_name: 表名
        - schema_name: Schema名
        - workspace: 工作空间名
        - table_type: 表类型
        - columns: 列信息列表（如果include_columns=True）
        - primary_key: 主键列列表（如有）
        - foreign_keys: 外键信息列表（如有）
    说明:
      - 仅返回包含主键（primary_key）或外键（foreign_keys）的表
      - 无主键且无外键的表会被过滤，不纳入返回结果
    """
    schema_name: str = arguments.get("schema_name", "").strip()
    include_columns: bool = arguments.get("include_columns", True)
    verbose: bool = arguments.get("verbose", False)

    if not schema_name:
        raise ValueError("❌ schema_name 参数不能为空。请提供要查询的 schema 名称。")

    logger.info(f"Get tables metadata (with PK/FK) for schema: {schema_name}, include_columns={include_columns}")

    executed_sqls: list[str] = []

    # 1) 获取schema下的所有表
    show_tables_sql = f"SHOW TABLES IN {schema_name}"
    executed_sqls.append(show_tables_sql)

    try:
        tables_df, data_id = db.execute_query(show_tables_sql + ";")
        tables = convert_df_to_dict(tables_df) if tables_df is not None else []
        logger.info(f"Found {len(tables)} tables in schema {schema_name} (will filter by PK/FK)")
    except Exception as e:
        error_msg = str(e)
        logger.error(f"SHOW TABLES failed: {error_msg}")
        analysis = sql_intelligence.analyze_sql_error(error_msg, show_tables_sql)
        detailed_error = (
            f"❌ {analysis['friendly_message'] or f'获取 {schema_name} 下的表列表失败'}\n\n"
            f"📝 SQL executed: {show_tables_sql}\n"
            f"🔍 Original Error: {error_msg}\n\n"
            f"💡 Suggestions: {'; '.join(analysis['suggestions'][:2])}"
        )
        raise ValueError(detailed_error)

    if not tables:
        response_data = {
            "schema_name": schema_name,
            "tables": [],
            "table_count": 0,
            "filtered_tables_count": 0,
            "message": f"Schema '{schema_name}' 中没有找到任何表"
        }
        if verbose:
            response_data["sql_query_executed"] = executed_sqls
        return ResponseBuilder.create_yaml_json_response([response_data], data_id)

    # 2) 遍历表，仅保留含主键/外键的表
    tables_metadata = []
    filtered_table_count = 0  # 记录被过滤的表数量（无PK/FK）

    for table in tables:
        table_name = table.get("table_name") or table.get("name") or ""
        if not table_name:
            filtered_table_count += 1
            continue

        # 构建表的基础元数据
        table_meta = {
            "workspace": table.get("workspace") or table.get("catalog") or "",
            "table_type": table.get("table_type") or "TABLE",
            "schema_name": table.get("schema_name") or table.get("schema") or schema_name,
            "table_name": table_name,
            "is_view": table.get("is_view", False),
            "is_materialized_view": table.get("is_materialized_view", False),
            "is_external": table.get("is_external", False),
            "is_dynamic": table.get("is_dynamic", False),
        }

        # 初始化主键/外键标识
        has_primary_key = False
        has_foreign_key = False
        columns_info = []
        primary_keys = []
        foreign_keys = []

        # 如果需要列信息，执行 DESC TABLE EXTENDED 解析PK/FK
        if include_columns:
            # 构建完整表名
            workspace = table_meta["workspace"]
            schema = table_meta["schema_name"]
            full_table_name = f"{workspace}.{schema}.{table_name}" if workspace else f"{schema}.{table_name}"

            # 使用 EXTENDED 获取完整信息（包括主键、外键等）
            desc_sql = f"DESC TABLE EXTENDED {full_table_name}"
            executed_sqls.append(desc_sql)
            logger.info(f"执行的SQL语句是{desc_sql};")

            try:
                cols_df, _ = db.execute_query(desc_sql + ";")
                cols = convert_df_to_dict(cols_df) if cols_df is not None else []

                # 解析 DESC EXTENDED 的返回结果
                for col in cols:
                    col_name_field = col.get("col_name") or col.get("column_name") or col.get("name") or ""

                    # 解析主键信息
                    if col_name_field.lower() == "primary_key":
                        pk_value = col.get("data_type") or col.get("type") or col.get("col_type") or ""
                        if pk_value:
                            try:
                                pk_data = json.loads(pk_value) if isinstance(pk_value, str) and pk_value.startswith(
                                    '[') else pk_value
                                if isinstance(pk_data, list):
                                    primary_keys = pk_data
                                elif isinstance(pk_data, str):
                                    primary_keys = [pk.strip() for pk in pk_data.split(',') if pk.strip()]
                            except:
                                primary_keys = [pk.strip() for pk in
                                                pk_value.replace('[', '').replace(']', '').split(',') if pk.strip()]
                        has_primary_key = len(primary_keys) > 0
                        continue

                    # 解析外键信息
                    elif col_name_field.lower() in ["foreign_key", "foreign_keys"]:
                        fk_value = col.get("data_type") or col.get("type") or col.get("col_type") or ""
                        if fk_value and fk_value not in ["", "null", "NULL", "None"]:
                            try:
                                fk_data = json.loads(fk_value) if isinstance(fk_value, str) and (
                                            fk_value.startswith('[') or fk_value.startswith('{')) else fk_value
                                if isinstance(fk_data, list):
                                    foreign_keys = fk_data
                                elif isinstance(fk_data, dict):
                                    foreign_keys = [fk_data]
                                elif isinstance(fk_data, str) and fk_data.strip():
                                    foreign_keys = [{"raw": fk_data}]
                            except:
                                if isinstance(fk_value, str) and fk_value.strip():
                                    foreign_keys = [{"raw": fk_value}]
                        has_foreign_key = len(foreign_keys) > 0
                        continue

                    # 解析普通列信息
                    if col_name_field:
                        col_info = {
                            "name": col_name_field,
                            "type": col.get("type") or col.get("data_type") or col.get("col_type") or "",
                            "nullable": col.get("nullable", True),
                            "comment": col.get("comment") or col.get("col_comment") or "",
                        }
                        # 标记列是否为主键
                        if "primary_key" in col:
                            col_info["is_primary_key"] = col["primary_key"]
                            has_primary_key = True  # 列级别主键标识
                        if "default_value" in col and col["default_value"]:
                            col_info["default_value"] = col["default_value"]
                        columns_info.append(col_info)

            except Exception as e:
                logger.warning(f"DESC TABLE EXTENDED failed for {full_table_name}: {e}")
                table_meta["metadata_error"] = str(e)
        else:
            # 不获取列信息时，尝试从 SHOW TABLES 结果中提取PK/FK（部分数据库支持）
            has_primary_key = bool(table.get("primary_key"))
            has_foreign_key = bool(table.get("foreign_keys"))
            primary_keys = table.get("primary_key", [])
            foreign_keys = table.get("foreign_keys", [])

        # 核心过滤逻辑：仅保留有主键 或 有外键的表
        if has_primary_key or has_foreign_key:
            # 补充表元数据
            table_meta["columns"] = columns_info
            table_meta["column_count"] = len(columns_info)

            if primary_keys:
                table_meta["primary_key"] = primary_keys
                table_meta["primary_key_columns"] = primary_keys
                logger.debug(f"Table {table_name} has primary key: {primary_keys}")

            if foreign_keys:
                table_meta["foreign_keys"] = foreign_keys
                logger.debug(f"Table {table_name} has foreign keys: {foreign_keys}")
                # 解析外键提示
                foreign_key_hints = []
                for fk in foreign_keys:
                    if isinstance(fk, dict) and "raw" not in fk:
                        hint = {
                            "column": fk.get("column") or (
                                fk.get("columns", [None])[0] if isinstance(fk.get("columns"), list) else None),
                            "references_table": fk.get("references_table") or fk.get("ref_table"),
                            "references_column": fk.get("references_column") or (
                                fk.get("ref_columns", [None])[0] if isinstance(fk.get("ref_columns"), list) else None)
                        }
                        if hint["column"] and hint["references_table"]:
                            foreign_key_hints.append(hint)
                if foreign_key_hints:
                    table_meta["foreign_key_hints"] = foreign_key_hints

            tables_metadata.append(table_meta)
            logger.info(f"Table {table_name} retained (PK: {has_primary_key}, FK: {has_foreign_key})")
        else:
            # 无主键且无外键，过滤该表
            filtered_table_count += 1
            logger.info(f"Table {table_name} filtered out (no PK/FK)")

    # 3) 构建响应
    response_data = {
        "schema_name": schema_name,
        "tables": tables_metadata,
        "table_count": len(tables_metadata),  # 最终保留的表数量
        "filtered_tables_count": filtered_table_count,  # 被过滤的表数量（无PK/FK）
        "total_tables_scanned": len(tables),  # 扫描的总表数
    }

    # 补充提示信息
    if len(tables_metadata) == 0:
        response_data["message"] = f"Schema '{schema_name}' 中没有找到包含主键或外键的表"
    else:
        response_data[
            "message"] = f"Schema '{schema_name}' 中筛选出 {len(tables_metadata)} 个包含主键/外键的表（共扫描 {len(tables)} 个表，过滤 {filtered_table_count} 个无PK/FK的表）"

    if verbose:
        response_data["sql_query_executed"] = executed_sqls
        response_data["parameter_details"] = {
            "include_columns": include_columns,
            "verbose_mode": True,
            "filter_rule": "仅保留包含主键（PK）或外键（FK）的表"
        }

    return ResponseBuilder.create_yaml_json_response([response_data], data_id)