"""
Query Handlers 模块 - 查询处理器
"""

# 从各子模块导入所有查询处理函数
from .basic_query import (
    handle_read_query,
    handle_write_query,
)

# 导出所有函数供外部使用
__all__ = [
    # 基础查询
    'handle_read_query',
    'handle_write_query', 

]