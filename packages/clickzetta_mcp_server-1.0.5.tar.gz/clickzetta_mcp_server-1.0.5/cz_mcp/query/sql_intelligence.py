"""
SQL智能提示和错误美化模块
提供ClickZetta特定的语法检查、拼写纠错和友好的错误提示
"""

import re
import logging
from typing import Dict, List, Optional, Tuple, Any

from loguru import logger

class SQLIntelligence:
    """SQL智能分析和错误美化器"""
    
    @classmethod
    def analyze_sql_error(cls, error_msg: str, sql: str = "") -> Dict[str, Any]:
        """
        分析SQL错误并提供智能建议
        """
        result = {
            "original_error": error_msg,
            "friendly_message": "",
            "suggestions": [],
            "error_type": "sql_execution_failed"
        }

        # 0. 语义分析错误优先处理：隐式类型转换失败
        if cls._is_implicit_cast_semantic_error(error_msg):
            result["friendly_message"] = "SQL语义分析错误：字段类型不兼容，无法隐式转换"
            result["error_type"] = "sql_semantic_analysis_error"
            result["suggestions"] = cls._build_implicit_cast_suggestions(error_msg)
            return result

        # 2. 检查ClickZetta特定语法
        syntax_fixes = cls._check_clickzetta_syntax(error_msg, sql)
        if syntax_fixes:
            result["suggestions"].extend(syntax_fixes)
            
        result["suggestions"].append("如果当前错误是语法问题，使用 get_product_knowledge 工具获取Lakehouse 语法方言用于改写SQL")
        
        return result

    @classmethod
    def _is_implicit_cast_semantic_error(cls, error_msg: str) -> bool:
        error_lower = (error_msg or "").lower()
        return (
            "semantic analysis exception" in error_lower
            and "implicit cast not allowed" in error_lower
        )

    @classmethod
    def _build_implicit_cast_suggestions(cls, error_msg: str) -> List[str]:
        suggestions = [
            "请检查SQL字段类型，避免依赖隐式类型转换。",
            "请对不兼容字段使用显式 CAST(...) 转换后再写入目标表。",
        ]

        match = re.search(
            r"implicit cast not allowed for '([^']+)':\s*([^:]+?)\s+to\s+([a-zA-Z0-9_]+)",
            error_msg or "",
            flags=re.IGNORECASE,
        )
        if match:
            column_name = match.group(1).strip()
            source_type = match.group(2).strip()
            target_type = match.group(3).strip()
            suggestions.insert(
                2,
                f"示例修复：将 `{column_name}` 从 `{source_type}` 显式转换为 `{target_type}`，如 `CAST({column_name} AS {target_type})`。"
            )

        return suggestions

    @classmethod
    def _check_clickzetta_syntax(cls, error_msg: str, sql: str) -> List[str]:
        """检查ClickZetta特定语法问题"""
        suggestions = []
        
        # 检查ClickZetta特定问题（专注于最有价值的提示）
        if "identity column type int" in error_msg.lower():
            suggestions.append("IDENTITY列必须使用BIGINT类型")
            
        # 权限问题
        if "permission denied" in error_msg.lower():
            suggestions.append("检查访问权限或联系管理员")
        
        return suggestions
    
    @classmethod
    def _beautify_error_message(cls, raw_error: str) -> str:
        """美化错误信息（针对大模型用户优化）"""
            
        error_lower = raw_error.lower()
        
        # ClickZetta特定错误优先处理
        if "identity column type int" in error_lower:
            return "IDENTITY列类型错误：必须使用BIGINT而不是INT"
            
        # 语法错误（简化版）
        elif "syntax error" in error_lower:
            return "SQL语法错误"
        
        # 解析错误
        elif "parse error" in error_lower:
            return "SQL解析错误"
            
        # 表不存在
        elif any(keyword in error_lower for keyword in ["table", "not found", "not exist", "does not exist"]):
            if "table" in error_lower:
                return "表不存在"
            
        # 列不存在  
        elif any(keyword in error_lower for keyword in ["column", "not found"]):
            if "column" in error_lower:
                return "列不存在"
            
        # 权限错误
        elif "permission denied" in error_lower or "access denied" in error_lower:
            return "权限不足"
            
        # 数据类型错误
        elif "type" in error_lower and "cannot" in error_lower:
            return "数据类型错误"
            
        # 连接错误
        elif "connection" in error_lower or "timeout" in error_lower:
            return "连接超时"
        
        # 默认处理（保持原始错误的关键信息）
        return f"执行失败: {raw_error[:500]}{'...' if len(raw_error) > 500 else ''}"
    
    @classmethod
    def get_helpful_hints(cls, sql: str, context: Dict[str, Any] = None) -> List[str]:
        """根据SQL内容提供有用的提示"""
        hints = []
        sql_upper = sql.upper()
        
        # CREATE TABLE相关提示
        if "CREATE TABLE" in sql_upper:
            hints.append("💡 建议：为大表考虑添加适当的分区策略")
            if "IDENTITY" not in sql_upper:
                hints.append("💡 建议：考虑添加IDENTITY主键列")
                
        # INSERT相关提示  
        elif "INSERT INTO" in sql_upper:
            if "VALUES" in sql_upper and sql.count("VALUES") == 1:
                hints.append("💡 建议：批量插入使用多个VALUES子句可提升性能")
                
        # SELECT相关提示
        elif "SELECT" in sql_upper:
            if "*" in sql and "LIMIT" not in sql_upper:
                hints.append("💡 建议：大表查询建议添加LIMIT子句限制结果数量")
                
        # 性能提示
        if "ORDER BY" in sql_upper and "LIMIT" not in sql_upper:
            hints.append("💡 性能提示：ORDER BY配合LIMIT使用效果更佳")
            
        if context and context.get("is_large_table"):
            hints.append("💡 性能提示：大表查询建议使用WHERE条件过滤数据")
        
        return hints

# 全局实例
sql_intelligence = SQLIntelligence()
