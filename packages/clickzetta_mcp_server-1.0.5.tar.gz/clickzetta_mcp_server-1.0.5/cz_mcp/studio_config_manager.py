"""
Studio MCP Configuration Manager
Handles configuration loading and login token management
"""
import configparser
import logging
import os
from dataclasses import dataclass, field
from typing import Optional, Dict, Any

from .common import ResponseBuilder
from .core.enhanced_lakehouse import ClickzettaConnectionParams
from .handlers.login_server import login_wrapper
from .utils.context_utils import context

from loguru import logger


@dataclass
class StudioConfig:
    token: str  # JWT token
    instance: str  # instance name
    instance_id: int  # Instance ID from login response
    workspace: str  # workspace name
    workspace_id: int = 0  # workspace ID
    vcluster: str = "DEFAULT"
    schema: str = "public"
    service: str = ""

    # Environment and URLs
    env: str = "dev"  # region/environment
    region_id: int = 1
    region_code: str = ""  # region code
    base_url: str = ""  # API base URL
    login_url: str = ""  # Login/accounts URL

    # Optional metadata
    project_id: str = ""
    user_id: int = 0  # User ID from login response
    tenant_id: int = 0  # Tenant ID from login response
    username: str = ""
    expire_time: int = 0  # Token expiration time (timestamp in milliseconds)

    # Server configuration
    # TODO : transport_type should be set
    transport_type: str = "stdio"
    enable_resources: bool = True
    enable_prompts: bool = True
    resource_request_timeout: float = 30.0
    prompt_request_timeout: float = 20.0

    # Query and execution hints
    hints: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """Initialize default hints if not provided"""
        if not self.hints:
            self.hints = self._get_default_hints()

    @staticmethod
    def _get_default_hints() -> Dict[str, Any]:
        """Get default query hints"""
        return {
            "sdk.job.timeout": 300,
            "query_tag": "Query from MCP Server",
            "cz.storage.parquet.vector.index.read.memory.cache": "true",
            "cz.storage.parquet.vector.index.read.local.cache": "false",
            "spark.sql.ansi.enabled": "true",
            "spark.sql.storeAssignmentPolicy": "ANSI",
            "cz.sql.allowComplexTypeInSelect": "true",
            "cz.sql.allowCollectionInDataFrame": "true",
        }

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary format for backward compatibility"""
        return {
            'token': self.token,
            'instance': self.instance,
            'instance_id': self.instance_id,
            'workspace': self.workspace,
            'workspace_id': self.workspace_id,
            'vcluster': self.vcluster,
            'schema': self.schema,
            'service': self.service,
            'env': self.env,
            'region_id': self.region_id,
            'region_code': self.region_code,
            'base_url': self.base_url,
            'login_url': self.login_url,
            'project_id': self.project_id,
            'user_id': self.user_id,
            'tenant_id': self.tenant_id,
            'username': self.username,
            'expire_time': self.expire_time,
            'transport_type': self.transport_type,
            'enable_resources': self.enable_resources,
            'enable_prompts': self.enable_prompts,
            'resource_request_timeout': self.resource_request_timeout,
            'prompt_request_timeout': self.prompt_request_timeout,
            'hints': self.hints,
        }

    def __repr__(self):
        """Custom string representation excluding sensitive token"""
        token_preview = f"{self.token[:10]}..." if self.token and len(self.token) > 10 else "****"
        return (
            f"StudioConfig("
            f"token='{token_preview}', "
            f"instance='{self.instance}', "
            f"instance_id={self.instance_id}, "
            f"workspace='{self.workspace}', "
            f"workspace_id={self.workspace_id}, "
            f"vcluster='{self.vcluster}', "
            f"schema='{self.schema}', "
            f"service='{self.service}', "
            f"env='{self.env}', "
            f"region_id={self.region_id}, "
            f"region_code={self.region_code}, "
            f"user_id={self.user_id}, "
            f"tenant_id={self.tenant_id}, "
            f"username='{self.username}', "
            f"transport_type='{self.transport_type}'"
            f")"
        )

    def __str__(self):
        """Custom string conversion excluding sensitive token"""
        return self.__repr__()

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> 'StudioConfig':
        """Create StudioConfig from dictionary"""
        return cls(
            token=config_dict.get('token', ''),
            instance=config_dict.get('instance', ''),
            instance_id=config_dict.get('instance_id', 0),
            workspace=config_dict.get('workspace', ''),
            workspace_id=config_dict.get('workspace_id', 0),
            vcluster=config_dict.get('vcluster', 'DEFAULT'),
            schema=config_dict.get('schema', 'public'),
            service=config_dict.get('service', ''),
            env=config_dict.get('env', 'dev'),
            region_id=config_dict.get('region_id', 1),
            region_code=config_dict.get('region_code', ''),
            base_url=config_dict.get('base_url', ''),
            login_url=config_dict.get('login_url', ''),
            project_id=config_dict.get('project_id', ''),
            user_id=config_dict.get('user_id', 0),
            tenant_id=config_dict.get('tenant_id', 0),
            username=config_dict.get('username', ''),
            expire_time=config_dict.get('expire_time', 0),
            transport_type=config_dict.get('transport_type', 'stdio'),
            enable_resources=config_dict.get('enable_resources', True),
            enable_prompts=config_dict.get('enable_prompts', True),
            resource_request_timeout=config_dict.get('resource_request_timeout', 30.0),
            prompt_request_timeout=config_dict.get('prompt_request_timeout', 20.0),
            hints=config_dict.get('hints', {}),
        )

    def to_clickzetta_params(self) -> 'ClickzettaConnectionParams':
        """Convert to ClickzettaConnectionParams for EnhancedLakehouseClient"""
        return ClickzettaConnectionParams(
            magic_token=self.token,
            instance=self.instance,
            service=self.service,
            workspace=self.workspace,
            vcluster=self.vcluster,
            schema=self.schema
        )


class StudioConfigManager:
    """Manages Studio configuration and authentication"""

    def __init__(self, env: str = None, transport_type: str = "stdio"):
        """
        Initialize configuration manager
        
        Args:
            env: Environment name (dev, uat, etc.) - only used for STDIO mode
            transport_type: Transport type ("stdio" or "http")
        """
        self.env = env
        self.transport_type = transport_type
        self.config: Optional[StudioConfig] = None
        self.token: Optional[str] = None
        self._auth_defaults: Dict[str, str] = {}
        self._config_path = os.path.join(
            os.path.dirname(__file__), 'config'
        )

        # Auto-load configuration
        self.load_config()

    def load_config(self) -> StudioConfig:
        """Load configuration from ini files"""
        config_parser = configparser.ConfigParser()

        # Load main config
        config_ini_path = os.path.join(self._config_path, 'config.ini')
        config_parser.read(config_ini_path, encoding='utf-8')

        # Determine base URL and login URL based on transport type and environment
        if self.transport_type == "stdio" and self.env:
            base_url = config_parser.get('URL', self.env)
        else:
            # HTTP mode: use specified env or default to dev
            env_key = self.env or 'dev'
            base_url = config_parser.get('URL', env_key)

        if self.transport_type == "stdio":
            # STDIO mode: Load environment-specific config
            if not self.env:
                raise ValueError("Environment must be specified for STDIO transport")

            # Load environment-specific properties
            env_config_path = os.path.join(
                self._config_path, f'{self.env}_properties.ini'
            )
            env_parser = configparser.ConfigParser()
            env_parser.read(env_config_path, encoding='utf-8')
            self._auth_defaults = {
                "username": env_parser.get('USER', 'username', fallback=''),
                "password": env_parser.get('USER', 'password', fallback=''),
                "pat_token": env_parser.get('USER', 'pat_token', fallback=''),
            }

            # Extract configuration values for STDIO
            self.config = StudioConfig(
                token="",  # Will be set after login
                instance_id=0,  # Will be set after login
                instance=env_parser.get('variable', 'instancename'),
                workspace_id=0,  # Will be set after login
                workspace=env_parser.get('variable', 'workSpaceName'),
                vcluster=env_parser.get('variable', 'adhocVcCode', fallback='DEFAULT'),
                schema=env_parser.get('variable', 'adhocSchemaName', fallback='public'),
                env=self.env,
                region_id=0,  # Will be set after login
                base_url=base_url,
                login_url=base_url,
                project_id=env_parser.get('variable', 'projectId'),
                user_id=0 ,  # Will be set after login
                username=env_parser.get('USER', 'username'),
                transport_type=self.transport_type,
            )

        else:
            # HTTP mode: Use centralized config with specified environment
            # HTTP mode uses minimal configuration - authentication comes from headers
            self.config = StudioConfig(
                token="",  # Comes from headers
                instance_id=0,  # Will be set after login
                instance="",  # Comes from headers
                workspace="",  # Comes from headers
                workspace_id=0,  # Will be set after login
                vcluster="DEFAULT",  # Default, can be overridden
                schema="public",  # Default, can be overridden
                env=self.env or "dev",
                region_id=0,  # Will be set after login
                base_url=base_url,
                login_url=base_url,
                project_id="",  # Comes from headers
                username="",  # Comes from headers
                transport_type=self.transport_type,
            )
            self._auth_defaults = {}

        # Set context for backward compatibility
        context['env'] = self.env or "http"

        logger.info(f"Loaded configuration for transport: {self.transport_type}, env: {self.env or 'dev'}")
        return self.config

    async def login(self, pat=None, instance_name=None, base_url=None, username: str = None,
                    password: str = None) -> dict:
        """
        Login and get authentication data

        Returns:
            dict with keys: token, instance_id, user_id, expire_time
        """
        if not instance_name and self.config:
            instance_name = self.config.instance
        if not base_url and self.config:
            base_url = self.config.base_url
        if not pat and not (username and password):
            auth_mode = self._auth_defaults.get("auth_mode")
            default_pat = self._auth_defaults.get("pat_token") or None
            default_username = self._auth_defaults.get("username") or None
            default_password = self._auth_defaults.get("password") or None

            if auth_mode == "password" and default_username and default_password:
                username = default_username
                password = default_password
            elif auth_mode == "pat" and default_pat:
                pat = default_pat
            elif default_pat:
                pat = default_pat
            elif default_username and default_password:
                username = default_username
                password = default_password

        logger.info(f"Calling login_wrapper with instance_name='{instance_name}'")

        try:
            logger.info(f"login using base_url: {base_url}")
            login_data = login_wrapper(
                instance_name,
                pat=pat,
                username=username,
                password=password,
                url=base_url
            )

            # Update self.token and self.config with login data
            self.token = login_data['token']

            # Update config if it exists
            if self.config:
                self.config.token = login_data['token']
                self.config.instance_id = login_data.get('instance_id', 0)
                self.config.user_id = login_data.get('user_id', 0)
                self.config.expire_time = login_data.get('expire_time', 0)

            # Set token in context for backward compatibility
            context['token'] = self.token

            logger.info(f"Successfully logged in: instanceId={login_data.get('instance_id')}, "
                       f"userId={login_data.get('user_id')}")
            return login_data

        except Exception as e:
            raise e

    def get_token(self) -> Optional[str]:
        """Get current authentication token"""
        return self.token
