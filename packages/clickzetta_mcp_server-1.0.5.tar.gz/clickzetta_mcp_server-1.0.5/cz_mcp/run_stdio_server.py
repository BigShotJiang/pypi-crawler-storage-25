#!/usr/bin/env python3
"""
STDIO MCP Server Runner for Clickzetta Studio
Entry point for running the STDIO MCP server with argument parsing
"""
import argparse
import asyncio
import os
import sys

from cz_mcp.core.region_config import get_region_by_alias, get_region_by_service_url

from loguru import logger


HEADER_ARG_MAP = {
    "x-lakehouse-username": "x_lakehouse_username",
    "x-lakehouse-password": "x_lakehouse_password",
    "x-lakehouse-token": "x_lakehouse_token",
    "x-lakehouse-service": "x_lakehouse_service",
    "x-lakehouse-instance": "x_lakehouse_instance",
    "x-lakehouse-workspace": "x_lakehouse_workspace",
    "x-lakehouse-schema": "x_lakehouse_schema",
    "x-lakehouse-vcluster": "x_lakehouse_vcluster",
    "x-lakehouse-region": "x_lakehouse_region",
}


def create_parser():
    """Create argument parser for STDIO server"""
    parser = argparse.ArgumentParser(
        description="Clickzetta STDIO MCP Server",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s                    # Start with dev environment (default)
  %(prog)s --env uat          # Start with uat environment
  %(prog)s --x-lakehouse-username UAT_TEST --x-lakehouse-password xxx --x-lakehouse-instance public
  %(prog)s x-Lakehouse-Username=UAT_TEST x-Lakehouse-Password=xxx x-Lakehouse-Instance=public
        """
    )
    parser.add_argument(
        '--env',
        default='dev',
        help='Environment name, maps to config/{env}_properties.ini (default: dev)'
    )
    parser.add_argument('--x-lakehouse-username', dest='x_lakehouse_username')
    parser.add_argument('--x-lakehouse-password', dest='x_lakehouse_password')
    parser.add_argument('--x-lakehouse-token', dest='x_lakehouse_token')
    parser.add_argument('--x-lakehouse-service', dest='x_lakehouse_service')
    parser.add_argument('--x-lakehouse-instance', dest='x_lakehouse_instance')
    parser.add_argument('--x-lakehouse-workspace', dest='x_lakehouse_workspace')
    parser.add_argument('--x-lakehouse-schema', dest='x_lakehouse_schema')
    parser.add_argument('--x-lakehouse-vcluster', dest='x_lakehouse_vcluster')
    parser.add_argument('--x-lakehouse-region', dest='x_lakehouse_region')
    parser.add_argument(
        '--enable-local-log',
        action='store_true',
        help='Enable local file logging for stdio mode (default disabled)'
    )
    parser.add_argument(
        '--app-log-path',
        dest='app_log_path',
        help='Local log directory when --enable-local-log is set'
    )
    return parser


def apply_header_style_overrides(args: argparse.Namespace, unknown_args: list[str]) -> argparse.Namespace:
    """Allow key=value style arguments using header-like names."""
    for item in unknown_args:
        if "=" not in item:
            continue
        key, value = item.split("=", 1)
        normalized_key = key.strip().lower()
        if normalized_key in HEADER_ARG_MAP:
            setattr(args, HEADER_ARG_MAP[normalized_key], value.strip())
    return args


def normalize_service_url(service_value: str) -> str:
    if not service_value:
        return ""
    service_value = service_value.strip()
    if service_value.startswith("http://") or service_value.startswith("https://"):
        return service_value
    return f"https://{service_value}"


def apply_cli_config_overrides(server, args: argparse.Namespace) -> None:
    """Apply CLI auth/config overrides to stdio configuration."""
    config = server.config_manager.config
    if not config:
        return

    if args.x_lakehouse_service:
        base_url = normalize_service_url(args.x_lakehouse_service)
        config.base_url = base_url
        config.login_url = base_url

    if args.x_lakehouse_region:
        config.env = get_region_by_alias(args.x_lakehouse_region, default=args.x_lakehouse_region)
    elif args.x_lakehouse_service:
        inferred_region = get_region_by_service_url(args.x_lakehouse_service)
        if inferred_region:
            config.env = inferred_region

    if args.x_lakehouse_instance:
        config.instance = args.x_lakehouse_instance
    if args.x_lakehouse_workspace:
        config.workspace = args.x_lakehouse_workspace
    if args.x_lakehouse_vcluster:
        config.vcluster = args.x_lakehouse_vcluster
    if args.x_lakehouse_schema:
        config.schema = args.x_lakehouse_schema
    if args.x_lakehouse_username:
        config.username = args.x_lakehouse_username

    auth_defaults = server.config_manager._auth_defaults
    if args.x_lakehouse_token:
        auth_defaults["pat_token"] = args.x_lakehouse_token
        auth_defaults["auth_mode"] = "pat"
        # PAT mode should not be shadowed by previous username/password defaults
        auth_defaults["username"] = auth_defaults.get("username", "")
        auth_defaults["password"] = auth_defaults.get("password", "")
    if args.x_lakehouse_username:
        auth_defaults["username"] = args.x_lakehouse_username
    if args.x_lakehouse_password:
        auth_defaults["password"] = args.x_lakehouse_password
    # If CLI username/password are provided (and PAT is not provided), force password auth.
    if (args.x_lakehouse_username and args.x_lakehouse_password) and not args.x_lakehouse_token:
        auth_defaults["auth_mode"] = "password"
        auth_defaults["pat_token"] = ""


async def main():
    """Main entry point for STDIO server"""
    parser = create_parser()
    args, unknown_args = parser.parse_known_args()
    args = apply_header_style_overrides(args, unknown_args)

    # STDIO default: output-only logging, no local file logs.
    os.environ["CZ_MCP_TRANSPORT"] = "stdio"
    if args.enable_local_log:
        os.environ["CZ_MCP_LOG_TO_FILE"] = "1"
        if args.app_log_path:
            os.environ["APP_LOG_PATH"] = args.app_log_path
    else:
        os.environ.setdefault("CZ_MCP_LOG_TO_FILE", "0")

    # Import after logging env is prepared so logger module picks the right mode.
    from cz_mcp.transport.mcp_server import ClickzettaMCPServer

    logger.info(f"🚀 Starting Clickzetta STDIO MCP Server")
    logger.info(f"   Environment: {args.env}")
    logger.info(f"   Transport type: STDIO (local development)")
    logger.info(f"   Authentication: Configuration-based with token caching")
    logger.info(f"   Local file logging: {'enabled' if os.environ.get('CZ_MCP_LOG_TO_FILE') == '1' else 'disabled'}")
    if os.environ.get("APP_LOG_PATH"):
        logger.info(f"   APP_LOG_PATH: {os.environ.get('APP_LOG_PATH')}")
    logger.info(f"   Config file: config/{args.env}_properties.ini")

    try:
        server = ClickzettaMCPServer(transport_type="stdio", env=args.env)
        apply_cli_config_overrides(server, args)
        await server.run()
    except KeyboardInterrupt:
        logger.info("\n🛑 Server stopped by user")
    except Exception as e:
        logger.error(f"Failed to start STDIO MCP Server: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
