from pathlib import Path

from cz_mcp.tools.task_development_tools import task_development_tools


def test_task_development_tool_descriptions_use_canonical_skill_paths():
    tools = {tool.name: tool for tool in task_development_tools()}

    query_desc = tools["task_query_operation"].description
    management_desc = tools["task_management_operation"].description

    assert "cz_mcp/skills/task-development/" in query_desc
    assert "cz_mcp/skills/task-development/" in management_desc
    assert "custom_skills/" not in query_desc
    assert "custom_skills/" not in management_desc


def test_task_development_skill_reference_files_exist():
    skills_root = Path(__file__).resolve().parents[1] / "skills" / "task-development"
    references = skills_root / "references"

    expected_files = [
        skills_root / "SKILL.md",
        references / "query-operations.md",
        references / "task-management-operations.md",
        references / "task-types.md",
        references / "schedule-configuration.md",
    ]

    missing = [str(path) for path in expected_files if not path.exists()]
    assert not missing, f"Missing task-development skill files: {missing}"
