"""
Unit tests for Flow Task Tools
"""
import json
import pytest
from unittest.mock import Mock, patch

import sys
import types as _types
from unittest.mock import MagicMock

# Stub out heavy transitive imports to allow isolated unit testing
for mod_name in ["sentence_transformers", "torch", "langchain_openai",
                 "langchain_openai.chat_models", "langchain_openai.embeddings"]:
    sys.modules.setdefault(mod_name, MagicMock())

from cz_mcp.tools.flow_task_tools import (
    handle_get_flow_dag,
    handle_create_flow_node,
    handle_remove_flow_node,
    handle_bind_flow_node,
    handle_unbind_flow_node,
    handle_submit_flow,
    handle_get_flow_node_detail,
    handle_save_node_content,
    handle_save_node_configuration,
    handle_list_flow_node_instances,
    get_flow_task_tools,
    _resolve_node_type,
    _resolve_node_name,
    NODE_TYPE_MAP,
)
from cz_mcp.studio_config_manager import StudioConfig


@pytest.fixture
def mock_config():
    return StudioConfig(
        token="test_token",
        instance="test_instance",
        instance_id=1,
        workspace="test_workspace",
        project_id="60001",
        user_id=100,
        tenant_id=200,
        env="dev",
    )


def _api_success(data=None):
    return json.dumps({"code": "200", "message": "Success", "data": data})


def _api_error(msg="fail"):
    return json.dumps({"code": "500", "message": msg})


# ==================== _resolve_node_type ====================

class TestResolveNodeType:
    def test_string_types(self):
        assert _resolve_node_type("sql") == 4
        assert _resolve_node_type("SQL") == 4
        assert _resolve_node_type("python") == 7
        assert _resolve_node_type("shell") == 5
        assert _resolve_node_type("data_integration") == 1
        assert _resolve_node_type("jdbc") == 15
        assert _resolve_node_type("virtual") == 0
        assert _resolve_node_type("spark") == 400

    def test_int_passthrough(self):
        assert _resolve_node_type(4) == 4
        assert _resolve_node_type(0) == 0

    def test_int_string(self):
        assert _resolve_node_type("4") == 4

    def test_unknown_raises(self):
        with pytest.raises(ValueError, match="Unknown node type"):
            _resolve_node_type("unknown_type")


# ==================== get_flow_task_tools ====================

class TestToolDefinitions:
    def test_tool_count(self):
        tools = get_flow_task_tools()
        assert len(tools) == 10

    def test_tool_names(self):
        tools = get_flow_task_tools()
        names = {t.name for t in tools}
        assert names == {"get_flow_dag", "create_flow_node", "remove_flow_node",
                         "bind_flow_node", "unbind_flow_node", "submit_flow",
                         "get_flow_node_detail", "save_node_content",
                         "save_node_configuration", "list_flow_node_instances"}

    def test_all_tools_have_handlers(self):
        for tool in get_flow_task_tools():
            assert callable(tool.handler)

    def test_all_tools_have_required_fields(self):
        for tool in get_flow_task_tools():
            assert tool.name
            assert tool.description
            assert tool.input_schema.get("type") == "object"
            assert "required" in tool.input_schema

    def test_create_node_has_enum(self):
        """node_type should have string enum for AI friendliness"""
        tools = {t.name: t for t in get_flow_task_tools()}
        props = tools["create_flow_node"].input_schema["properties"]
        assert "enum" in props["node_type"]
        assert "sql" in props["node_type"]["enum"]

    def test_create_node_default_type(self):
        """node_type should default to sql"""
        tools = {t.name: t for t in get_flow_task_tools()}
        props = tools["create_flow_node"].input_schema["properties"]
        assert props["node_type"].get("default") == "sql"

    def test_bind_uses_upstream_downstream(self):
        """bind_flow_node should use upstream/downstream naming with node names"""
        tools = {t.name: t for t in get_flow_task_tools()}
        props = tools["bind_flow_node"].input_schema["properties"]
        assert "upstream_node_name" in props
        assert "downstream_node_name" in props
        # Should NOT have ID-based or confusing params
        assert "upstream_node_id" not in props
        assert "downstream_node_id" not in props
        assert "current_file_id" not in props
        assert "dependency_file_id" not in props

    def test_consistent_data_file_id(self):
        """All tools should use task_id as the flow identifier (except check/instance tools)"""
        skip_tools = {"check_flow_submit_status", "list_flow_node_instances",
                      "save_node_configuration", "save_node_content", "get_flow_node_detail"}
        for tool in get_flow_task_tools():
            if tool.name in skip_tools:
                continue
            required = tool.input_schema.get("required", [])
            assert "task_id" in required, f"{tool.name} missing task_id in required"

    def test_submit_minimal_params(self):
        """submit_flow should only require task_id"""
        tools = {t.name: t for t in get_flow_task_tools()}
        assert tools["submit_flow"].input_schema["required"] == ["task_id"]


# ==================== handle_get_flow_dag ====================

class TestGetFlowDag:
    @pytest.mark.asyncio
    async def test_success(self, mock_config):
        dag_data = [{"id": 1, "fileName": "node1"}]
        with patch("cz_mcp.tools.flow_task_tools.get_flow_dag", return_value=_api_success(dag_data)):
            result = await handle_get_flow_dag({"task_id": 12345}, mock_config)
        assert result is not None
        content = result[0].text
        assert "success" in content

    @pytest.mark.asyncio
    async def test_missing_param(self, mock_config):
        result = await handle_get_flow_dag({}, mock_config)
        content = result[0].text
        assert "task_id is required" in content

    @pytest.mark.asyncio
    async def test_api_error(self, mock_config):
        with patch("cz_mcp.tools.flow_task_tools.get_flow_dag", return_value=_api_error("not found")):
            result = await handle_get_flow_dag({"task_id": 99999}, mock_config)
        content = result[0].text
        assert "not found" in content


# ==================== handle_create_flow_node ====================

class TestCreateFlowNode:
    @pytest.mark.asyncio
    async def test_success_default_type(self, mock_config):
        """Should default to SQL when node_type not specified"""
        with patch("cz_mcp.tools.flow_task_tools.create_flow_node", return_value=_api_success({"id": 10})) as mock_call:
            result = await handle_create_flow_node(
                {"task_id": 123, "node_name": "my_node"}, mock_config)
        content = result[0].text
        assert "success" in content
        # Verify file_type=4 (SQL) was passed
        mock_call.assert_called_once()
        assert mock_call.call_args.kwargs["file_type"] == 4

    @pytest.mark.asyncio
    async def test_string_node_type(self, mock_config):
        """Should accept string node type like 'python'"""
        with patch("cz_mcp.tools.flow_task_tools.create_flow_node", return_value=_api_success({"id": 10})) as mock_call:
            result = await handle_create_flow_node(
                {"task_id": 123, "node_name": "etl", "node_type": "python"}, mock_config)
        assert mock_call.call_args.kwargs["file_type"] == 7

    @pytest.mark.asyncio
    async def test_invalid_node_type(self, mock_config):
        result = await handle_create_flow_node(
            {"task_id": 123, "node_name": "x", "node_type": "invalid"}, mock_config)
        content = result[0].text
        assert "Unknown node type" in content

    @pytest.mark.asyncio
    async def test_missing_name(self, mock_config):
        result = await handle_create_flow_node({"task_id": 123}, mock_config)
        content = result[0].text
        assert "required" in content

    @pytest.mark.asyncio
    async def test_missing_file_id(self, mock_config):
        result = await handle_create_flow_node({"node_name": "x"}, mock_config)
        content = result[0].text
        assert "required" in content


# ==================== handle_remove_flow_node ====================

class TestRemoveFlowNode:
    @pytest.mark.asyncio
    async def test_success(self, mock_config):
        dag = _api_success([{"id": 10, "fileName": "old_step", "fileType": 4, "flowId": 100}])
        with patch("cz_mcp.tools.flow_task_tools.get_flow_dag", return_value=dag), \
             patch("cz_mcp.tools.flow_task_tools.remove_flow_node", return_value=_api_success([])):
            result = await handle_remove_flow_node(
                {"task_id": 123, "node_name": "old_step"}, mock_config)
        content = result[0].text
        assert "success" in content

    @pytest.mark.asyncio
    async def test_missing_node_name(self, mock_config):
        result = await handle_remove_flow_node({"task_id": 123}, mock_config)
        content = result[0].text
        assert "required" in content


# ==================== _resolve_node_name ====================

class TestResolveNodeName:
    """Test _resolve_node_name with real API response format"""

    REAL_API_NODES = [
        {"deployStatus": 0, "fileName": "node_1", "fileType": 4, "flowId": 13262001, "id": 13265003},
        {"deployStatus": 0, "fileName": "node_2", "fileType": 4, "flowId": 13262001, "id": 13265002},
        {"deployStatus": 0, "fileName": "bbb_01", "fileType": 4, "flowId": 13262001, "id": 13265001},
    ]

    def test_match_found(self, mock_config):
        dag_resp = _api_success(self.REAL_API_NODES)
        with patch("cz_mcp.tools.flow_task_tools.get_flow_dag", return_value=dag_resp):
            node_id, err = _resolve_node_name(123, "node_1", mock_config)
        assert node_id == 13265003
        assert err is None

    def test_match_not_found(self, mock_config):
        dag_resp = _api_success(self.REAL_API_NODES)
        with patch("cz_mcp.tools.flow_task_tools.get_flow_dag", return_value=dag_resp):
            node_id, err = _resolve_node_name(123, "nonexistent", mock_config)
        assert node_id is None
        assert "not found" in err.lower()
        assert "node_1" in err  # should list available nodes

    def test_api_error(self, mock_config):
        with patch("cz_mcp.tools.flow_task_tools.get_flow_dag", return_value=_api_error("server error")):
            node_id, err = _resolve_node_name(123, "node_1", mock_config)
        assert node_id is None
        assert "server error" in err

    def test_dict_format_with_nodes_key(self, mock_config):
        """Also handle {"nodes": [...]} format if API ever returns it"""
        dag_resp = _api_success({"nodes": [
            {"fileName": "step_a", "id": 10},
            {"fileName": "step_b", "id": 20},
        ]})
        with patch("cz_mcp.tools.flow_task_tools.get_flow_dag", return_value=dag_resp):
            node_id, err = _resolve_node_name(123, "step_b", mock_config)
        assert node_id == 20
        assert err is None


# ==================== handle_bind_flow_node ====================

class TestBindFlowNode:
    MOCK_NODES = [
        {"fileName": "step_a", "fileType": 4, "flowId": 100, "id": 10},
        {"fileName": "step_b", "fileType": 4, "flowId": 100, "id": 20},
    ]

    def _dag_with_nodes(self):
        """Return a mock DAG response with two nodes (real API format)"""
        return _api_success(self.MOCK_NODES)

    @pytest.mark.asyncio
    async def test_success(self, mock_config):
        with patch("cz_mcp.tools.flow_task_tools.get_flow_dag", return_value=self._dag_with_nodes()), \
             patch("cz_mcp.tools.flow_task_tools.bind_flow_node", return_value=_api_success({"id": 1})) as mock_call:
            result = await handle_bind_flow_node(
                {"task_id": 123, "upstream_node_name": "step_a", "downstream_node_name": "step_b"}, mock_config)
        content = result[0].text
        assert "success" in content
        assert mock_call.call_args.kwargs["current_node_id"] == 20
        assert mock_call.call_args.kwargs["dependency_node_id"] == 10

    @pytest.mark.asyncio
    async def test_missing_upstream(self, mock_config):
        result = await handle_bind_flow_node(
            {"task_id": 123, "downstream_node_name": "step_b"}, mock_config)
        content = result[0].text
        assert "required" in content

    @pytest.mark.asyncio
    async def test_node_not_found(self, mock_config):
        with patch("cz_mcp.tools.flow_task_tools.get_flow_dag", return_value=self._dag_with_nodes()):
            result = await handle_bind_flow_node(
                {"task_id": 123, "upstream_node_name": "nonexistent", "downstream_node_name": "step_b"}, mock_config)
        content = result[0].text
        assert "not found" in content.lower()

    @pytest.mark.asyncio
    async def test_project_id_fallback(self, mock_config):
        """Should use config.project_id when not explicitly provided"""
        with patch("cz_mcp.tools.flow_task_tools.get_flow_dag", return_value=self._dag_with_nodes()), \
             patch("cz_mcp.tools.flow_task_tools.bind_flow_node", return_value=_api_success({})) as mock_call:
            await handle_bind_flow_node(
                {"task_id": 123, "upstream_node_name": "step_a", "downstream_node_name": "step_b"}, mock_config)
        assert mock_call.call_args.kwargs["current_project_id"] == "60001"
        assert mock_call.call_args.kwargs["dependency_project_id"] == "60001"


# ==================== handle_unbind_flow_node ====================

class TestUnbindFlowNode:
    @pytest.mark.asyncio
    async def test_success(self, mock_config):
        with patch("cz_mcp.tools.flow_task_tools.unbind_flow_node", return_value=_api_success({})):
            result = await handle_unbind_flow_node(
                {"task_id": 123, "dependency_id": 50}, mock_config)
        content = result[0].text
        assert "success" in content

    @pytest.mark.asyncio
    async def test_missing_dependency_id(self, mock_config):
        result = await handle_unbind_flow_node({"task_id": 123}, mock_config)
        content = result[0].text
        assert "required" in content


# ==================== handle_submit_flow ====================

class TestSubmitFlow:
    @pytest.mark.asyncio
    async def test_success(self, mock_config):
        resp = json.dumps({"code": "200", "message": "Flow submitted successfully", "submitTraceId": "abc"})
        with patch("cz_mcp.tools.flow_task_tools.submit_flow_and_wait", return_value=resp):
            result = await handle_submit_flow({"task_id": 123}, mock_config)
        content = result[0].text
        assert "success" in content

    @pytest.mark.asyncio
    async def test_missing_file_id(self, mock_config):
        result = await handle_submit_flow({}, mock_config)
        content = result[0].text
        assert "task_id is required" in content

    @pytest.mark.asyncio
    async def test_api_failure(self, mock_config):
        with patch("cz_mcp.tools.flow_task_tools.submit_flow_and_wait", return_value=_api_error("submit failed")):
            result = await handle_submit_flow({"task_id": 123}, mock_config)
        content = result[0].text
        assert "submit failed" in content


# ==================== handle_list_flow_node_instances ====================

class TestListFlowNodeInstances:
    MOCK_INSTANCES = [
        {"id": 1, "nodeName": "step_a", "instanceStatus": 2, "flowNodeId": 10},
        {"id": 2, "nodeName": "step_b", "instanceStatus": 3, "failMsg": "OOM", "flowNodeId": 20},
    ]

    @pytest.mark.asyncio
    async def test_success(self, mock_config):
        with patch("cz_mcp.tools.flow_task_tools.list_flow_node_instances",
                    return_value=_api_success(self.MOCK_INSTANCES)):
            result = await handle_list_flow_node_instances(
                {"flow_id": 100, "flow_instance_id": 200}, mock_config)
        content = result[0].text
        assert "success" in content
        assert "2 node instance" in content

    @pytest.mark.asyncio
    async def test_missing_params(self, mock_config):
        result = await handle_list_flow_node_instances({"flow_id": 100}, mock_config)
        content = result[0].text
        assert "required" in content

    @pytest.mark.asyncio
    async def test_api_error(self, mock_config):
        with patch("cz_mcp.tools.flow_task_tools.list_flow_node_instances",
                    return_value=_api_error("not found")):
            result = await handle_list_flow_node_instances(
                {"flow_id": 100, "flow_instance_id": 200}, mock_config)
        content = result[0].text
        assert "not found" in content


# ==================== submit_flow_and_wait (handler-level) ====================

class TestSubmitFlowAndWait:
    """Test the polling logic inside submit_flow_and_wait directly"""

    @patch("cz_mcp.handlers.flow_task_server.time.sleep", return_value=None)
    @patch("cz_mcp.handlers.flow_task_server.check_submit_status")
    @patch("cz_mcp.handlers.flow_task_server.submit_flow")
    def test_success_on_status_2(self, mock_submit, mock_check, mock_sleep):
        """Status 2 = SUCCESS per FlowSubmitStatusEnum"""
        from cz_mcp.handlers.flow_task_server import submit_flow_and_wait
        mock_submit.return_value = json.dumps({"code": "200", "data": "trace-1"})
        mock_check.return_value = json.dumps({"code": "200", "data": 2})

        result = json.loads(submit_flow_and_wait("f1", "p1", "t", "i", 1, 1, "dev"))
        assert result["code"] == "200"
        assert "success" in result["message"].lower()

    @patch("cz_mcp.handlers.flow_task_server.time.sleep", return_value=None)
    @patch("cz_mcp.handlers.flow_task_server.check_submit_status")
    @patch("cz_mcp.handlers.flow_task_server.submit_flow")
    def test_fail_on_status_3(self, mock_submit, mock_check, mock_sleep):
        """Status 3 = FAILED per FlowSubmitStatusEnum"""
        from cz_mcp.handlers.flow_task_server import submit_flow_and_wait
        mock_submit.return_value = json.dumps({"code": "200", "data": "trace-2"})
        mock_check.return_value = json.dumps({"code": "200", "data": 3})

        result = json.loads(submit_flow_and_wait("f1", "p1", "t", "i", 1, 1, "dev"))
        assert result["code"] == "500"
        assert "failed" in result["message"].lower()

    @patch("cz_mcp.handlers.flow_task_server.time.sleep", return_value=None)
    @patch("cz_mcp.handlers.flow_task_server.time.time")
    @patch("cz_mcp.handlers.flow_task_server.check_submit_status")
    @patch("cz_mcp.handlers.flow_task_server.submit_flow")
    def test_keeps_polling_on_status_1(self, mock_submit, mock_check, mock_time, mock_sleep):
        """Status 1 = SUBMITTING, should keep polling until success or timeout"""
        from cz_mcp.handlers.flow_task_server import submit_flow_and_wait
        mock_submit.return_value = json.dumps({"code": "200", "data": "trace-3"})
        # First call returns SUBMITTING(1), second returns SUCCESS(2)
        mock_check.side_effect = [
            json.dumps({"code": "200", "data": 1}),
            json.dumps({"code": "200", "data": 2}),
        ]
        # Simulate time: 0, 1, 2 (within max_wait)
        mock_time.side_effect = [0, 1, 2]

        result = json.loads(submit_flow_and_wait("f1", "p1", "t", "i", 1, 1, "dev", max_wait=10))
        assert result["code"] == "200"
        assert mock_check.call_count == 2


# ==================== handle_save_node_configuration ====================

class TestSaveNodeConfiguration:
    MOCK_DETAIL = {
        "defaultSchemaName": "public",
        "defaultVcName": "DEFAULT",
        "ownerCnName": "test_user",
        "ownerEnName": "100",
        "nodeId": 13265003,
    }

    @pytest.mark.asyncio
    async def test_success(self, mock_config):
        with patch("cz_mcp.tools.flow_task_tools.get_flow_node_detail",
                   return_value=_api_success(self.MOCK_DETAIL)), \
             patch("cz_mcp.tools.flow_task_tools.save_flow_node_configuration",
                   return_value=_api_success({})) as mock_save:
            result = await handle_save_node_configuration(
                {"task_id": 13262001, "node_id": 13265003, "schema_name": "dev"}, mock_config)
        content = result[0].text
        assert "success" in content
        assert mock_save.call_args.kwargs["node_id"] == 13265003
        assert mock_save.call_args.kwargs["schema_name"] == "dev"

    @pytest.mark.asyncio
    async def test_defaults_from_detail(self, mock_config):
        """Should use defaultSchemaName/defaultVcName from node detail when not provided"""
        with patch("cz_mcp.tools.flow_task_tools.get_flow_node_detail",
                   return_value=_api_success(self.MOCK_DETAIL)), \
             patch("cz_mcp.tools.flow_task_tools.save_flow_node_configuration",
                   return_value=_api_success({})) as mock_save:
            await handle_save_node_configuration(
                {"task_id": 13262001, "node_id": 13265003}, mock_config)
        assert mock_save.call_args.kwargs["schema_name"] == "public"
        assert mock_save.call_args.kwargs["etl_vc_code"] == "DEFAULT"

    @pytest.mark.asyncio
    async def test_missing_node_id(self, mock_config):
        result = await handle_save_node_configuration({"task_id": 100}, mock_config)
        content = result[0].text
        assert "node_id is required" in content

    @pytest.mark.asyncio
    async def test_missing_task_id(self, mock_config):
        result = await handle_save_node_configuration({"node_id": 123}, mock_config)
        content = result[0].text
        assert "task_id" in content and "required" in content

    @pytest.mark.asyncio
    async def test_detail_api_error(self, mock_config):
        with patch("cz_mcp.tools.flow_task_tools.get_flow_node_detail",
                   return_value=_api_error("node not found")):
            result = await handle_save_node_configuration(
                {"task_id": 100, "node_id": 999}, mock_config)
        content = result[0].text
        assert "node not found" in content


# ==================== handle_save_node_content ====================

class TestSaveNodeContent:
    @pytest.mark.asyncio
    async def test_success(self, mock_config):
        with patch("cz_mcp.tools.flow_task_tools.save_flow_node_content",
                   return_value=_api_success({})) as mock_save:
            result = await handle_save_node_content(
                {"task_id": 13262001, "node_id": 13265003, "content": "select 1;"}, mock_config)
        content = result[0].text
        assert "success" in content
        assert mock_save.call_args.kwargs["data_file_id"] == 13262001
        assert mock_save.call_args.kwargs["node_id"] == 13265003
        assert mock_save.call_args.kwargs["content"] == "select 1;"

    @pytest.mark.asyncio
    async def test_with_params(self, mock_config):
        params = [{"paramKey": "dt", "paramValue": "$[yyyyMMdd]"}]
        with patch("cz_mcp.tools.flow_task_tools.save_flow_node_content",
                   return_value=_api_success({})) as mock_save:
            await handle_save_node_content(
                {"task_id": 100, "node_id": 200, "content": "select ${dt}", "param_value_list": params}, mock_config)
        assert mock_save.call_args.kwargs["param_value_list"] == params

    @pytest.mark.asyncio
    async def test_missing_content(self, mock_config):
        result = await handle_save_node_content({"task_id": 100, "node_id": 200}, mock_config)
        assert "content is required" in result[0].text

    @pytest.mark.asyncio
    async def test_missing_node_id(self, mock_config):
        result = await handle_save_node_content({"task_id": 100, "content": "x"}, mock_config)
        assert "required" in result[0].text


# ==================== handle_get_flow_node_detail ====================

class TestGetFlowNodeDetail:
    @pytest.mark.asyncio
    async def test_success(self, mock_config):
        detail = {"fileContent": "select 1;", "defaultSchemaName": "public", "nodeId": 13265002}
        with patch("cz_mcp.tools.flow_task_tools.get_flow_node_detail",
                   return_value=_api_success(detail)):
            result = await handle_get_flow_node_detail(
                {"task_id": 13262001, "node_id": 13265002}, mock_config)
        content = result[0].text
        assert "success" in content

    @pytest.mark.asyncio
    async def test_missing_params(self, mock_config):
        result = await handle_get_flow_node_detail({"task_id": 100}, mock_config)
        assert "required" in result[0].text

    @pytest.mark.asyncio
    async def test_api_error(self, mock_config):
        with patch("cz_mcp.tools.flow_task_tools.get_flow_node_detail",
                   return_value=_api_error("not found")):
            result = await handle_get_flow_node_detail(
                {"task_id": 100, "node_id": 999}, mock_config)
        assert "not found" in result[0].text
