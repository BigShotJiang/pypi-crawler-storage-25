#!/usr/bin/env python3
"""
Unit tests for configuration priority logic in MCP server

Tests the priority resolution for configuration parameters:
Priority: tool_config_params > connection_info (headers) > user_config > defaults

Covers:
- _get_config_value: Generic configuration value resolution with priority
- _resolve_config_from_user_config: Configuration from user config only
- _initialize_config_params: Initial parameter setup and region resolution
"""

import pytest
from unittest.mock import Mock, MagicMock, patch
from cz_mcp.transport.mcp_server import ClickzettaMCPServer, ToolConfig


# ==================== Fixtures ====================

@pytest.fixture
def mock_server():
    """Create a mock MCP server instance for testing"""
    with patch('cz_mcp.transport.mcp_server.StudioConfigManager'):
        server = ClickzettaMCPServer(transport_type="http")
        # Mock logger to avoid logging during tests
        server.server_core = Mock()
        return server


@pytest.fixture
def sample_tool_config():
    """Sample tool configuration"""
    return ToolConfig(
        region="cn-shanghai-alicloud",
        workspace="test_workspace",
        vcluster="test_vcluster",
        schema="test_schema"
    )


@pytest.fixture
def sample_connection_info():
    """Sample connection info from HTTP headers"""
    return {
        "region": "cn-shanghai-alicloud",
        "workspace": "header_workspace",
        "vcluster": "header_vcluster",
        "schema": "header_schema"
    }


@pytest.fixture
def sample_user_config():
    """Sample user configuration dictionary"""
    return {
        "cspId": 1,
        "regionId": 1,
        "cregionId": "cn-shanghai-alicloud",
        "workspaceName": "user_workspace",
        "vcId": 1,
        "vcName": "user_vcluster",
        "schemaName": "user_schema",
        "workspaceId": 12345,
        "projectId": "proj_123",
        "instanceId": 100,
        "instanceName": "test_instance",
        "regionCode": "alicloud"
    }


# ==================== ToolConfig Tests ====================

@pytest.mark.unit
class TestToolConfig:
    """Tests for ToolConfig class"""

    def test_from_dict_all_params(self):
        """Test creating ToolConfig from dict with all parameters"""
        data = {
            "region": "cn-shanghai-alicloud",
            "workspace": "test_ws",
            "vcluster": "test_vc",
            "schema": "test_schema"
        }
        config = ToolConfig.from_dict(data)

        assert config.region == "cn-shanghai-alicloud"
        assert config.workspace == "test_ws"
        assert config.vcluster == "test_vc"
        assert config.schema == "test_schema"
        assert config.has_required() is True

    def test_from_dict_partial_params(self):
        """Test creating ToolConfig with partial parameters"""
        data = {
            "region": "cn-shanghai-alicloud",
            "workspace": "test_ws"
        }
        config = ToolConfig.from_dict(data)

        assert config.region == "cn-shanghai-alicloud"
        assert config.workspace == "test_ws"
        assert config.vcluster is None
        assert config.schema is None
        assert config.has_required() is True
        assert config.has_any() is True

    def test_from_dict_empty(self):
        """Test creating ToolConfig with empty dict"""
        config = ToolConfig.from_dict({})

        assert config.region is None
        assert config.workspace is None
        assert config.vcluster is None
        assert config.schema is None
        assert config.has_required() is False
        assert config.has_any() is False

    def test_has_methods(self):
        """Test has_* methods"""
        config = ToolConfig(region="dev", workspace="ws1")

        assert config.has_region() is True
        assert config.has_workspace() is True
        assert config.has_vcluster() is False
        assert config.has_schema() is False
        assert config.has_required() is True
        assert config.has_any() is True


# ==================== Configuration Priority Tests ====================

@pytest.mark.unit
class TestGetConfigValue:
    """Tests for _get_config_value method - core priority resolution logic"""

    def test_priority_connection_header_over_user_config(self, mock_server):
        """Test that connection header value takes priority over user config"""
        connection_info = {"workspace": "header_workspace"}
        user_config = {"workspaceName": "user_workspace"}

        result = mock_server._get_config_value(
            connection_key="workspace",
            user_config_key="workspaceName",
            connection_info=connection_info,
            user_config_dict=user_config,
            use_header=True,
            use_user_config=True,
            default_value="default_workspace"
        )

        assert result == "header_workspace"

    def test_priority_user_config_when_no_header(self, mock_server):
        """Test that user config is used when header is not available"""
        connection_info = {}
        user_config = {"workspaceName": "user_workspace"}

        result = mock_server._get_config_value(
            connection_key="workspace",
            user_config_key="workspaceName",
            connection_info=connection_info,
            user_config_dict=user_config,
            use_header=False,
            use_user_config=True,
            default_value="default_workspace"
        )

        assert result == "user_workspace"

    def test_priority_default_when_no_config(self, mock_server):
        """Test that default value is used when no config available"""
        connection_info = {}
        user_config = {}

        result = mock_server._get_config_value(
            connection_key="workspace",
            user_config_key="workspaceName",
            connection_info=connection_info,
            user_config_dict=user_config,
            use_header=False,
            use_user_config=False,
            default_value="default_workspace"
        )

        assert result == "default_workspace"

    def test_priority_none_default(self, mock_server):
        """Test that None can be used as default value"""
        connection_info = {}
        user_config = {}

        result = mock_server._get_config_value(
            connection_key="workspace",
            user_config_key="workspaceName",
            connection_info=connection_info,
            user_config_dict=user_config,
            use_header=False,
            use_user_config=False,
            default_value=None
        )

        assert result is None

    def test_respect_use_header_flag(self, mock_server):
        """Test that use_header flag is respected even when header exists"""
        connection_info = {"workspace": "header_workspace"}
        user_config = {"workspaceName": "user_workspace"}

        result = mock_server._get_config_value(
            connection_key="workspace",
            user_config_key="workspaceName",
            connection_info=connection_info,
            user_config_dict=user_config,
            use_header=False,  # Explicitly disabled
            use_user_config=True,
            default_value="default_workspace"
        )

        assert result == "user_workspace"

    def test_respect_use_user_config_flag(self, mock_server):
        """Test that use_user_config flag is respected"""
        connection_info = {}
        user_config = {"workspaceName": "user_workspace"}

        result = mock_server._get_config_value(
            connection_key="workspace",
            user_config_key="workspaceName",
            connection_info=connection_info,
            user_config_dict=user_config,
            use_header=False,
            use_user_config=False,  # Explicitly disabled
            default_value="default_workspace"
        )

        assert result == "default_workspace"


@pytest.mark.unit
class TestResolveConfigFromUserConfig:
    """Tests for _resolve_config_from_user_config method"""

    def test_resolve_all_from_user_config(self, mock_server, sample_user_config):
        """Test resolving all config from user config"""
        tool_config = ToolConfig()  # Empty config

        workspace_id, project_id = mock_server._resolve_config_from_user_config(
            sample_user_config, tool_config
        )

        assert tool_config.workspace == "user_workspace"
        assert tool_config.vcluster == "user_vcluster"
        assert tool_config.schema == "user_schema"
        assert workspace_id == 12345
        assert project_id == "proj_123"

    def test_resolve_defaults_when_missing(self, mock_server):
        """Test that defaults are applied when user config values are missing"""
        user_config = {
            "workspaceName": "user_workspace",
            "workspaceId": 12345,
            "projectId": "proj_123"
            # vcName and schema are missing
        }
        tool_config = ToolConfig()

        workspace_id, project_id = mock_server._resolve_config_from_user_config(
            user_config, tool_config
        )

        assert tool_config.workspace == "user_workspace"
        assert tool_config.vcluster == "DEFAULT"  # Default value
        assert tool_config.schema == "public"  # Default value
        assert workspace_id == 12345
        assert project_id == "proj_123"

    def test_preserve_existing_tool_config(self, mock_server, sample_user_config):
        """Test that existing tool config values are preserved"""
        tool_config = ToolConfig(
            workspace="tool_workspace",
            vcluster="tool_vcluster",
            schema="tool_schema"
        )

        workspace_id, project_id = mock_server._resolve_config_from_user_config(
            sample_user_config, tool_config
        )

        # Tool config values should be preserved
        assert tool_config.workspace == "tool_workspace"
        assert tool_config.vcluster == "tool_vcluster"
        assert tool_config.schema == "tool_schema"
        # But workspace_id and project_id come from user_config
        assert workspace_id == 12345
        assert project_id == "proj_123"


@pytest.mark.unit
class TestInitializeConfigParams:
    """Tests for _initialize_config_params method"""

    @patch('cz_mcp.transport.mcp_server.get_region_by_alias')
    def test_initialize_with_tool_config_region(self, mock_get_region, mock_server):
        """Test initialization when region is in tool config params"""
        tool_config_params = {"region": "dev"}
        connection_info = {"region": "uat"}

        tool_config, conn_info = mock_server._initialize_config_params(
            tool_config_params, connection_info
        )

        # Tool config region should be used, not connection info
        assert tool_config.region == "dev"
        # get_region_by_alias should not be called
        mock_get_region.assert_not_called()

    @patch('cz_mcp.transport.mcp_server.get_region_by_alias')
    def test_initialize_with_connection_region(self, mock_get_region, mock_server):
        """Test initialization when region is only in connection info"""
        mock_get_region.return_value = "cn-shanghai-alicloud"
        tool_config_params = {}
        connection_info = {"region": "shanghai"}

        tool_config, conn_info = mock_server._initialize_config_params(
            tool_config_params, connection_info
        )

        # Should resolve region from connection info
        mock_get_region.assert_called_once_with("shanghai")
        assert tool_config.region == "cn-shanghai-alicloud"

    @patch('cz_mcp.transport.mcp_server.get_region_by_alias')
    def test_initialize_with_no_region(self, mock_get_region, mock_server):
        """Test initialization when no region is provided"""
        mock_get_region.return_value = None
        tool_config_params = {}
        connection_info = {}

        tool_config, conn_info = mock_server._initialize_config_params(
            tool_config_params, connection_info
        )

        # Should call get_region_by_alias with None
        mock_get_region.assert_called_once_with(None)
        assert tool_config.region is None

    def test_initialize_with_all_params(self, mock_server):
        """Test initialization with all tool config parameters"""
        tool_config_params = {
            "region": "dev",
            "workspace": "test_ws",
            "vcluster": "test_vc",
            "schema": "test_schema"
        }

        tool_config, conn_info = mock_server._initialize_config_params(
            tool_config_params, None
        )

        assert tool_config.region == "dev"
        assert tool_config.workspace == "test_ws"
        assert tool_config.vcluster == "test_vc"
        assert tool_config.schema == "test_schema"
        assert tool_config.has_required() is True

    def test_initialize_preserves_connection_info(self, mock_server):
        """Test that connection info is preserved during initialization"""
        connection_info = {
            "region": "dev",
            "workspace": "header_ws",
            "vcluster": "header_vc"
        }

        tool_config, conn_info = mock_server._initialize_config_params(
            None, connection_info
        )

        # Connection info should be preserved
        assert conn_info == connection_info


# ==================== Integration Tests for Priority Resolution ====================

@pytest.mark.unit
class TestConfigPriorityIntegration:
    """Integration tests for the complete priority resolution flow"""

    def test_tool_params_override_all(self, mock_server, sample_connection_info, sample_user_config):
        """Test that tool params have highest priority"""
        tool_config = ToolConfig(
            region="tool_region",
            workspace="tool_workspace",
            vcluster="tool_vcluster",
            schema="tool_schema"
        )

        # Even with connection and user config available, tool config should win
        result = mock_server._get_config_value(
            "workspace", "workspaceName",
            sample_connection_info, sample_user_config,
            True, True, "default"
        )

        # In this test, we're testing the priority logic directly
        # Tool config would be checked before calling _get_config_value
        # So here we test that header beats user config
        assert result == "header_workspace"

    def test_vcluster_resolution_with_matching_workspace(self, mock_server):
        """Test vcluster resolution when workspace matches"""
        tool_config = ToolConfig(region="dev", workspace="test_ws")
        connection_info = {
            "region": "dev",
            "workspace": "test_ws",
            "vcluster": "header_vc"
        }
        user_config = {
            "cregionId": "dev",
            "workspaceName": "test_ws",
            "vcName": "user_vc"
        }

        # When region and workspace match, vcluster from header should be used
        is_region_match = tool_config.region == connection_info.get('region')
        is_workspace_match = tool_config.workspace == connection_info.get('workspace')

        result = mock_server._get_config_value(
            "vcluster", "vcName",
            connection_info, user_config,
            is_region_match and is_workspace_match,
            is_region_match and is_workspace_match,
            "DEFAULT"
        )

        assert result == "header_vc"

    def test_vcluster_resolution_with_mismatched_workspace(self, mock_server):
        """Test vcluster resolution when workspace doesn't match"""
        tool_config = ToolConfig(region="dev", workspace="different_ws")
        connection_info = {
            "region": "dev",
            "workspace": "test_ws",
            "vcluster": "header_vc"
        }
        user_config = {
            "cregionId": "dev",
            "workspaceName": "test_ws",
            "vcName": "user_vc"
        }

        # When workspace doesn't match, should use default
        is_region_match = tool_config.region == connection_info.get('region')
        is_workspace_match = tool_config.workspace == connection_info.get('workspace')

        result = mock_server._get_config_value(
            "vcluster", "vcName",
            connection_info, user_config,
            is_region_match and is_workspace_match,
            False,  # Workspace doesn't match
            "DEFAULT"
        )

        assert result == "DEFAULT"

    def test_schema_default_is_public(self, mock_server):
        """Test that default schema is 'public' not 'DEFAULT'"""
        result = mock_server._get_config_value(
            "schema", "schemaName",
            {}, {},
            False, False,
            "public"
        )

        assert result == "public"

    def test_vcluster_default_is_uppercase_default(self, mock_server):
        """Test that default vcluster is 'DEFAULT'"""
        result = mock_server._get_config_value(
            "vcluster", "vcName",
            {}, {},
            False, False,
            "DEFAULT"
        )

        assert result == "DEFAULT"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
