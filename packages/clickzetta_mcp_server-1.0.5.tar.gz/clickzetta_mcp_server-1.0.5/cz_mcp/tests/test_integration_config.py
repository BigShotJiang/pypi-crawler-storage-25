"""
Tests for integration configuration generation tools
"""

import pytest
from cz_mcp.tools.integration_templates import IntegrationTemplateLibrary


class TestIntegrationTemplateLibrary:
    """Test integration template library"""
    
    def test_get_template_key_mysql_to_lakehouse(self):
        """Test MySQL to Lakehouse template selection"""
        template_key = IntegrationTemplateLibrary.get_template_key(5, 1)
        assert template_key == "relational_to_lakehouse"
    
    def test_get_template_key_kafka_to_lakehouse(self):
        """Test Kafka to Lakehouse template selection"""
        template_key = IntegrationTemplateLibrary.get_template_key(2, 1)
        assert template_key == "kafka_to_lakehouse"
    
    def test_get_template_key_oss_to_lakehouse(self):
        """Test OSS to Lakehouse template selection"""
        template_key = IntegrationTemplateLibrary.get_template_key(9, 1)
        assert template_key == "oss_to_lakehouse"
    
    def test_get_template_key_mongodb_to_lakehouse(self):
        """Test MongoDB to Lakehouse template selection"""
        template_key = IntegrationTemplateLibrary.get_template_key(12, 1)
        assert template_key == "mongodb_to_lakehouse"
    
    def test_get_template_key_lakehouse_to_redis(self):
        """Test Lakehouse to Redis template selection"""
        template_key = IntegrationTemplateLibrary.get_template_key(1, 43)
        assert template_key == "lakehouse_to_redis"
    
    def test_get_template_key_hive_to_lakehouse(self):
        """Test Hive to Lakehouse template selection"""
        template_key = IntegrationTemplateLibrary.get_template_key(3, 1)
        assert template_key == "hive_to_lakehouse"
    
    def test_get_template_key_postgresql_to_lakehouse(self):
        """Test PostgreSQL (relational DB) to Lakehouse template selection"""
        template_key = IntegrationTemplateLibrary.get_template_key(7, 1)
        assert template_key == "relational_to_lakehouse"
    
    def test_get_template_structure(self):
        """Test template structure"""
        template = IntegrationTemplateLibrary.get_template("relational_to_lakehouse")
        
        assert "source_params" in template
        assert "sink_params" in template
        assert "default_values" in template
        
        assert "required" in template["source_params"]
        assert "optional" in template["source_params"]
    
    def test_kafka_template_has_system_columns(self):
        """Test Kafka template includes system columns"""
        template = IntegrationTemplateLibrary.get_template("kafka_to_lakehouse")
        
        assert "system_columns" in template
        system_columns = template["system_columns"]
        
        column_names = [col["name"] for col in system_columns]
        assert "__key__" in column_names
        assert "__value__" in column_names
        assert "__partition__" in column_names
        assert "__offset__" in column_names
        assert "__timestamp__" in column_names
    
    def test_map_column_type_mysql_to_lakehouse(self):
        """Test column type mapping from MySQL to Lakehouse"""
        result = IntegrationTemplateLibrary.map_column_type("BIGINT", 5, 1)
        assert result == "bigint"
        
        result = IntegrationTemplateLibrary.map_column_type("VARCHAR", 5, 1)
        assert result == "string"
        
        result = IntegrationTemplateLibrary.map_column_type("DATETIME", 5, 1)
        assert result == "timestamp_ltz"
    
    def test_map_column_type_mongodb_to_lakehouse(self):
        """Test column type mapping from MongoDB to Lakehouse"""
        result = IntegrationTemplateLibrary.map_column_type("String", 12, 1)
        assert result == "string"
        
        result = IntegrationTemplateLibrary.map_column_type("Integer", 12, 1)
        assert result == "int"
        
        result = IntegrationTemplateLibrary.map_column_type("Long", 12, 1)
        assert result == "bigint"
    
    def test_map_column_type_lakehouse_to_redis(self):
        """Test column type mapping from Lakehouse to Redis"""
        result = IntegrationTemplateLibrary.map_column_type("int", 1, 43)
        assert result == "INT"
        
        result = IntegrationTemplateLibrary.map_column_type("string", 1, 43)
        assert result == "STRING"
        
        result = IntegrationTemplateLibrary.map_column_type("bigint", 1, 43)
        assert result == "LONG"
    
    def test_map_column_type_unknown_defaults_to_string(self):
        """Test unknown column type defaults to string for Lakehouse"""
        result = IntegrationTemplateLibrary.map_column_type("UNKNOWN_TYPE", 5, 1)
        assert result == "string"
    
    def test_redis_template_special_params(self):
        """Test Redis sink template has special parameters"""
        template = IntegrationTemplateLibrary.get_template("lakehouse_to_redis")
        
        sink_defaults = template["default_values"]["sink"]
        
        assert "dbNum" in sink_defaults
        assert "redisOpType" in sink_defaults
        assert "expireTime" in sink_defaults
        assert "keyDelimiter" in sink_defaults
        assert "batchSize" in sink_defaults
        assert sink_defaults["table"] == ""  # Redis doesn't use table
        assert sink_defaults["database"] == ""  # Redis doesn't use database
    
    def test_hive_template_no_table_in_params(self):
        """Test Hive template notes about table/database"""
        template = IntegrationTemplateLibrary.get_template("hive_to_lakehouse")
        
        assert "special_notes" in template
        assert "dataObject/namespace" in template["special_notes"]
    
    def test_mysql_unsigned_type_mapping(self):
        """Test MySQL UNSIGNED types are upgraded correctly"""
        # INT UNSIGNED → bigint (upgrade from int)
        result = IntegrationTemplateLibrary.map_column_type("INT UNSIGNED", 5, 1)
        assert result == "bigint", "INT UNSIGNED should upgrade to bigint"
        
        # BIGINT UNSIGNED → decimal (upgrade from bigint)
        result = IntegrationTemplateLibrary.map_column_type("BIGINT UNSIGNED", 5, 1)
        assert result == "decimal", "BIGINT UNSIGNED should upgrade to decimal"
        
        # TINYINT UNSIGNED → smallint (upgrade from tinyint)
        result = IntegrationTemplateLibrary.map_column_type("TINYINT UNSIGNED", 5, 1)
        assert result == "smallint", "TINYINT UNSIGNED should upgrade to smallint"
        
        # SMALLINT UNSIGNED → int (upgrade from smallint)
        result = IntegrationTemplateLibrary.map_column_type("SMALLINT UNSIGNED", 5, 1)
        assert result == "int", "SMALLINT UNSIGNED should upgrade to int"
    
    def test_postgresql_special_type_mapping(self):
        """Test PostgreSQL special types convert to string"""
        # UUID → string
        result = IntegrationTemplateLibrary.map_column_type("UUID", 7, 1)
        assert result == "string", "UUID should convert to string"
        
        # JSONB → string
        result = IntegrationTemplateLibrary.map_column_type("JSONB", 7, 1)
        assert result == "string", "JSONB should convert to string"
        
        # INET → string
        result = IntegrationTemplateLibrary.map_column_type("INET", 7, 1)
        assert result == "string", "INET should convert to string"
    
    def test_clickhouse_large_integer_mapping(self):
        """Test ClickHouse large integers convert to decimal"""
        # Int128 → decimal
        result = IntegrationTemplateLibrary.map_column_type("Int128", 4, 1)
        assert result == "decimal", "Int128 should convert to decimal"
        
        # UInt256 → decimal
        result = IntegrationTemplateLibrary.map_column_type("UInt256", 4, 1)
        assert result == "decimal", "UInt256 should convert to decimal"
    
    def test_mongodb_special_type_mapping(self):
        """Test MongoDB special types"""
        # OBJECTID → string
        result = IntegrationTemplateLibrary.map_column_type("OBJECTID", 12, 1)
        assert result == "string", "OBJECTID should convert to string"
        
        # DOCUMENT → string
        result = IntegrationTemplateLibrary.map_column_type("DOCUMENT", 12, 1)
        assert result == "string", "DOCUMENT should convert to string"
    
    def test_case_insensitive_type_mapping(self):
        """Test type mapping handles different cases"""
        # Uppercase
        result = IntegrationTemplateLibrary.map_column_type("VARCHAR", 5, 1)
        assert result == "string"
        
        # Lowercase
        result = IntegrationTemplateLibrary.map_column_type("varchar", 5, 1)
        assert result == "string"
        
        # Mixed case
        result = IntegrationTemplateLibrary.map_column_type("VarChar", 5, 1)
        assert result == "string"
    
    def test_standard_type_mappings(self):
        """Test standard SQL type mappings"""
        mappings = [
            ("TINYINT", "tinyint"),
            ("SMALLINT", "smallint"),
            ("INT", "int"),
            ("BIGINT", "bigint"),
            ("FLOAT", "float"),
            ("DOUBLE", "double"),
            ("DECIMAL", "decimal"),
            ("DATE", "date"),
            ("TIME", "time"),
            ("TIMESTAMP", "timestamp_ltz"),
            ("BOOLEAN", "boolean"),
            ("BINARY", "binary"),
        ]
        
        for source_type, expected_lakehouse_type in mappings:
            result = IntegrationTemplateLibrary.map_column_type(source_type, 5, 1)
            assert result == expected_lakehouse_type, f"{source_type} should map to {expected_lakehouse_type}"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

