#!/usr/bin/env python3
"""
Pytest test suite for LH-show_object_list tool with argument normalizer

Tests various object types and parameter combinations to verify:
1. Basic object listing (TABLES, SCHEMAS, FUNCTIONS, etc.)
2. Pattern matching with LIKE
3. IN SCHEMA filtering
4. Limit parameter
5. Table type filters (is_view, is_external, is_dynamic, is_stream)
6. Error handling and friendly error messages

Uses StudioMCPTester base class from conftest.py for connection management.
"""

import pytest


@pytest.mark.asyncio
async def test_show_tables(mcp_client):
    """Test: SHOW TABLES"""
    result = await mcp_client.call_tool(
        "LH-show_object_list",
        {
            "object_type": "TABLES",
            "limit": 10
        }
    )

    assert result is not None
    assert hasattr(result, 'content')
    print(f"✅ SHOW TABLES returned {len(result.content)} content items")


@pytest.mark.asyncio
async def test_show_schemas(mcp_client):
    """Test: SHOW SCHEMAS"""
    result = await mcp_client.call_tool(
        "LH-show_object_list",
        {
            "object_type": "SCHEMAS",
            "limit": 20
        }
    )

    assert result is not None
    assert hasattr(result, 'content')
    print(f"✅ SHOW SCHEMAS returned {len(result.content)} content items")


@pytest.mark.asyncio
async def test_show_functions(mcp_client):
    """Test: SHOW FUNCTIONS (special handling)"""
    result = await mcp_client.call_tool(
        "LH-show_object_list",
        {
            "object_type": "FUNCTIONS",
            "limit": 25
        }
    )

    assert result is not None
    assert hasattr(result, 'content')
    print(f"✅ SHOW FUNCTIONS returned {len(result.content)} content items")


@pytest.mark.asyncio
async def test_show_tables_with_pattern(mcp_client):
    """Test: SHOW TABLES with LIKE pattern"""
    result = await mcp_client.call_tool(
        "LH-show_object_list",
        {
            "object_type": "TABLES",
            "like_pattern": "test%",
            "limit": 10
        }
    )

    assert result is not None
    assert hasattr(result, 'content')
    print(f"✅ SHOW TABLES with pattern returned {len(result.content)} content items")


@pytest.mark.asyncio
async def test_show_tables_in_schema(mcp_client):
    """Test: SHOW TABLES IN SCHEMA"""
    result = await mcp_client.call_tool(
        "LH-show_object_list",
        {
            "object_type": "TABLES",
            "in_schema": "public",
            "limit": 10
        }
    )

    assert result is not None
    assert hasattr(result, 'content')
    print(f"✅ SHOW TABLES IN SCHEMA returned {len(result.content)} content items")


@pytest.mark.asyncio
async def test_show_views(mcp_client):
    """Test: SHOW VIEWS (using table_type_filters)"""
    result = await mcp_client.call_tool(
        "LH-show_object_list",
        {
            "object_type": "TABLES",
            "table_type_filters": {"is_view": True},
            "limit": 10
        }
    )

    assert result is not None
    assert hasattr(result, 'content')
    print(f"✅ SHOW VIEWS returned {len(result.content)} content items")


@pytest.mark.asyncio
async def test_show_external_tables(mcp_client):
    """Test: SHOW EXTERNAL TABLES"""
    result = await mcp_client.call_tool(
        "LH-show_object_list",
        {
            "object_type": "TABLES",
            "table_type_filters": {"is_external": True},
            "limit": 10
        }
    )

    assert result is not None
    assert hasattr(result, 'content')
    print(f"✅ SHOW EXTERNAL TABLES returned {len(result.content)} content items")


@pytest.mark.asyncio
async def test_type_conversion(mcp_client):
    """Test: Type conversion (string limit → integer)"""
    result = await mcp_client.call_tool(
        "LH-show_object_list",
        {
            "object_type": "TABLES",
            "limit": "15"  # String should be converted to integer
        }
    )

    assert result is not None
    assert hasattr(result, 'content')
    print(f"✅ Type conversion test passed - string limit converted to integer")


@pytest.mark.asyncio
async def test_invalid_object_type(mcp_client):
    """Test: Invalid object type (should give friendly error)"""
    with pytest.raises(Exception) as exc_info:
        await mcp_client.call_tool(
            "LH-show_object_list",
            {
                "object_type": "INVALID_TYPE",
                "limit": 10
            }
        )

    print(f"✅ Invalid object type correctly raised exception: {exc_info.value}")


@pytest.mark.asyncio
async def test_smart_defaults(mcp_client):
    """Test: Smart defaults (different limits for different object types)"""
    result = await mcp_client.call_tool(
        "LH-show_object_list",
        {
            "object_type": "FUNCTIONS"
            # No limit - should use default 25 for FUNCTIONS
        }
    )

    assert result is not None
    assert hasattr(result, 'content')
    print(f"✅ Smart defaults test passed - FUNCTIONS used default limit")
