"""
Tests for integration configuration generation tools
"""

import pytest
import json
from cz_mcp.tools.integration_templates import IntegrationTemplateLibrary


class TestIntegrationTemplateLibrary:
    """Test integration template library"""
    
    def test_get_template_key_mysql_to_lakehouse(self):
        """Test MySQL to Lakehouse template key"""
        template_key = IntegrationTemplateLibrary.get_template_key(5, 1)
        assert template_key == "relational_to_lakehouse"
    
    def test_get_template_key_kafka_to_lakehouse(self):
        """Test Kafka to Lakehouse template key"""
        template_key = IntegrationTemplateLibrary.get_template_key(2, 1)
        assert template_key == "kafka_to_lakehouse"
    
    def test_get_template_key_oss_to_lakehouse(self):
        """Test OSS to Lakehouse template key"""
        template_key = IntegrationTemplateLibrary.get_template_key(9, 1)
        assert template_key == "oss_to_lakehouse"
    
    def test_get_template_key_mongodb_to_lakehouse(self):
        """Test MongoDB to Lakehouse template key"""
        template_key = IntegrationTemplateLibrary.get_template_key(12, 1)
        assert template_key == "mongodb_to_lakehouse"
    
    def test_get_template_key_lakehouse_to_redis(self):
        """Test Lakehouse to Redis template key"""
        template_key = IntegrationTemplateLibrary.get_template_key(1, 43)
        assert template_key == "lakehouse_to_redis"
    
    def test_get_template_key_hive_to_lakehouse(self):
        """Test Hive to Lakehouse template key"""
        template_key = IntegrationTemplateLibrary.get_template_key(3, 1)
        assert template_key == "hive_to_lakehouse"
    
    def test_get_template_mysql(self):
        """Test get MySQL template"""
        template = IntegrationTemplateLibrary.get_template("relational_to_lakehouse")
        assert template is not None
        assert "source_params" in template
        assert "sink_params" in template
        assert "default_values" in template
    
    def test_get_template_kafka(self):
        """Test get Kafka template"""
        template = IntegrationTemplateLibrary.get_template("kafka_to_lakehouse")
        assert template is not None
        assert "system_columns" in template
        assert len(template["system_columns"]) == 5  # Kafka has 5 system columns
    
    def test_map_column_type_to_lakehouse(self):
        """Test column type mapping to Lakehouse"""
        # MySQL types
        assert IntegrationTemplateLibrary.map_column_type("BIGINT", 5, 1) == "bigint"
        assert IntegrationTemplateLibrary.map_column_type("VARCHAR", 5, 1) == "string"
        assert IntegrationTemplateLibrary.map_column_type("INT", 5, 1) == "int"
        
        # MongoDB types
        assert IntegrationTemplateLibrary.map_column_type("String", 12, 1) == "string"
        assert IntegrationTemplateLibrary.map_column_type("Integer", 12, 1) == "int"
        assert IntegrationTemplateLibrary.map_column_type("Long", 12, 1) == "bigint"
    
    def test_map_column_type_lakehouse_to_redis(self):
        """Test column type mapping from Lakehouse to Redis"""
        assert IntegrationTemplateLibrary.map_column_type("int", 1, 43) == "INT"
        assert IntegrationTemplateLibrary.map_column_type("bigint", 1, 43) == "LONG"
        assert IntegrationTemplateLibrary.map_column_type("string", 1, 43) == "STRING"
    
    def test_template_structure_kafka(self):
        """Test Kafka template structure"""
        template = IntegrationTemplateLibrary.get_template("kafka_to_lakehouse")
        
        # Check source params
        assert "codec" in template["default_values"]["source"]
        assert template["default_values"]["source"]["codec"] == "json"
        assert "mode" in template["default_values"]["source"]
        assert "groupId" in template["default_values"]["source"]
        
        # Check sink params
        assert "vclusterName" in template["default_values"]["sink"]
        assert "writeMode" in template["default_values"]["sink"]
    
    def test_template_structure_redis(self):
        """Test Redis template structure"""
        template = IntegrationTemplateLibrary.get_template("lakehouse_to_redis")
        
        # Check Redis-specific params
        sink_defaults = template["default_values"]["sink"]
        assert "redisOpType" in sink_defaults
        assert "dbNum" in sink_defaults
        assert "expireTime" in sink_defaults
        assert "keyDelimiter" in sink_defaults
        assert "batchSize" in sink_defaults
        
        # Redis doesn't use table/database
        assert sink_defaults["table"] == ""
        assert sink_defaults["database"] == ""
    
    def test_datasource_classification(self):
        """Test datasource classification"""
        # Relational databases
        assert 5 in IntegrationTemplateLibrary.RELATIONAL_DB  # MySQL
        assert 7 in IntegrationTemplateLibrary.RELATIONAL_DB  # PostgreSQL
        assert 25 in IntegrationTemplateLibrary.RELATIONAL_DB  # Oracle
        
        # NoSQL
        assert 12 in IntegrationTemplateLibrary.NOSQL_DB  # MongoDB
        assert 43 in IntegrationTemplateLibrary.NOSQL_DB  # Redis
        
        # Streaming
        assert 2 in IntegrationTemplateLibrary.STREAMING  # Kafka
        
        # File storage
        assert 9 in IntegrationTemplateLibrary.FILE_STORAGE  # OSS
        assert 38 in IntegrationTemplateLibrary.FILE_STORAGE  # S3
        assert 27 in IntegrationTemplateLibrary.FILE_STORAGE  # COS


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

