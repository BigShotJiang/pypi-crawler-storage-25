from cz_mcp.utils.cron_expression_adapter import parse_cron


def test_parse_cron_accepts_5_field_and_normalizes_to_7():
    fields = parse_cron("0 2 * * *")
    assert fields.second == "0"
    assert fields.minute == "0"
    assert fields.hour == "2"
    assert fields.day == "*"
    assert fields.month == "*"
    assert fields.week == "?"
    assert fields.year == "*"


def test_parse_cron_accepts_6_field_and_appends_year():
    fields = parse_cron("0 0 2 * * ?")
    assert fields.second == "0"
    assert fields.minute == "0"
    assert fields.hour == "2"
    assert fields.day == "*"
    assert fields.month == "*"
    assert fields.week == "?"
    assert fields.year == "*"


def test_parse_cron_accepts_7_field():
    fields = parse_cron("0 0 2 * * ? 2026")
    assert fields.year == "2026"
