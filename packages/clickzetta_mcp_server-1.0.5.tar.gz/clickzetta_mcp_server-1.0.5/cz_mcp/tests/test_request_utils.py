"""
Unit tests for request retry behavior.
"""

import inspect
from unittest.mock import Mock, patch

import pytest
import requests

from cz_mcp.utils.request_utils import RequestUtils


def _mock_response(status_code=200, payload=None, text=""):
    response = Mock()
    response.status_code = status_code
    response.text = text
    if payload is None:
        response.json.side_effect = ValueError("no json")
    else:
        response.json.return_value = payload
    return response


def test_public_request_methods_do_not_expose_retry_params():
    get_params = inspect.signature(RequestUtils.get).parameters
    post_params = inspect.signature(RequestUtils.post).parameters

    assert "retry" not in get_params
    assert "retry_times" not in get_params
    assert "retry" not in post_params
    assert "retry_times" not in post_params


def test_post_without_retry_condition_calls_once():
    request = RequestUtils()
    with patch("cz_mcp.utils.request_utils.requests.post", return_value=_mock_response()) as mock_post:
        response = request.post(url="https://example.com/api", json={"k": "v"})

    assert response.status_code == 200
    assert mock_post.call_count == 1


def test_post_retry_on_internal_server_error_message_then_success():
    request = RequestUtils()
    fail_response = _mock_response(status_code=200, payload={"code": "10001", "message": "Internal Server Error"})
    success_response = _mock_response(status_code=200, payload={"code": "200"})

    with patch(
        "cz_mcp.utils.request_utils.requests.post",
        side_effect=[fail_response, success_response],
    ) as mock_post, patch("cz_mcp.utils.request_utils.time.sleep"):
        response = request.post(url="https://example.com/api", json={"k": "v"})

    assert response is success_response
    assert mock_post.call_count == 2


def test_post_retry_on_internal_server_error_text_then_success():
    request = RequestUtils()
    fail_response = _mock_response(status_code=500, payload=None, text="Internal Server Error")
    success_response = _mock_response(status_code=200, payload={"code": "200"})

    with patch(
        "cz_mcp.utils.request_utils.requests.post",
        side_effect=[fail_response, success_response],
    ) as mock_post, patch("cz_mcp.utils.request_utils.time.sleep"):
        response = request.post(url="https://example.com/api", json={"k": "v"})

    assert response is success_response
    assert mock_post.call_count == 2


def test_post_no_retry_on_http_500_without_internal_message():
    request = RequestUtils()
    fail_response = _mock_response(status_code=500, payload={"code": "500", "message": "not transient"}, text="not transient")

    with patch("cz_mcp.utils.request_utils.requests.post", return_value=fail_response) as mock_post:
        response = request.post(url="https://example.com/api", json={"k": "v"})

    assert response is fail_response
    assert mock_post.call_count == 1


def test_post_retry_on_timeout_then_success():
    request = RequestUtils()
    success_response = _mock_response(status_code=200, payload={"code": "200"})

    with patch(
        "cz_mcp.utils.request_utils.requests.post",
        side_effect=[requests.exceptions.Timeout("timeout"), success_response],
    ) as mock_post, patch("cz_mcp.utils.request_utils.time.sleep"):
        response = request.post(url="https://example.com/api", json={"k": "v"})

    assert response is success_response
    assert mock_post.call_count == 2


def test_post_non_retryable_exception_raises_immediately():
    request = RequestUtils()

    with patch(
        "cz_mcp.utils.request_utils.requests.post",
        side_effect=requests.exceptions.HTTPError("http"),
    ) as mock_post:
        with pytest.raises(requests.exceptions.HTTPError):
            request.post(url="https://example.com/api", json={"k": "v"})

    assert mock_post.call_count == 1


def test_post_retry_exhausted_returns_last_response():
    request = RequestUtils()
    fail_response_1 = _mock_response(status_code=500, payload={"message": "Internal Server Error"})
    fail_response_2 = _mock_response(status_code=500, payload={"message": "Internal Server Error"})
    fail_response_3 = _mock_response(status_code=500, payload={"message": "Internal Server Error"})

    with patch(
        "cz_mcp.utils.request_utils.requests.post",
        side_effect=[fail_response_1, fail_response_2, fail_response_3],
    ) as mock_post, patch("cz_mcp.utils.request_utils.time.sleep"):
        response = request.post(url="https://example.com/api", json={"k": "v"})

    assert response is fail_response_3
    assert mock_post.call_count == 3

