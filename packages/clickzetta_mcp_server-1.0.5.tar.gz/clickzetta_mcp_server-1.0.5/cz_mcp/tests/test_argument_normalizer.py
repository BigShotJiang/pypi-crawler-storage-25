#!/usr/bin/env python3
"""
Pytest tests for ArgumentNormalizer with list_project_files tool schema.

Covers:
- Normalizer creation when tool has 'normalize' tag
- Default application from schema
- Type conversions (string -> int, arrays from JSON string, nested array items)
- Enum and numeric constraint validation errors
- Real-world example end-to-end
"""

import pytest


from cz_mcp.transport.argument_normalizer import (
    ArgumentNormalizer,
    create_normalizer_for_tool,
    ArgumentNormalizationError,
)
from cz_mcp.core.tool_registry import Tool


# --------------------
# Fixtures
# --------------------
@pytest.fixture()
def list_files_tool():
    # Create a mock tool with the same schema as list_project_files
    async def handle_mock(**kwargs):
        return None

    return Tool(
        name="list_project_files",
        description="Query data file list by project workspace",
        input_schema={
            "type": "object",
            "properties": {
                "project_id": {
                    "type": "integer",
                    "description": "Project ID",
                },
                "file_types": {
                    "type": "array",
                    "items": {"type": "integer"},
                    "description": "List of file type IDs",
                },
                "owner_names": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of owner names",
                },
                "status": {
                    "type": "integer",
                    "description": "File status",
                },
                "page_index": {
                    "type": "integer",
                    "description": "Page index",
                    "default": 1,
                },
                "page_size": {
                    "type": "integer",
                    "description": "Page size",
                    "default": 10,
                    "maximum": 20,
                },
                "name": {
                    "type": "string",
                    "description": "File name filter"
                },
                "order_type": {
                    "type": "string",
                    "description": "Sort order",
                    "enum": ["asc", "desc"],
                    "default": "desc",
                },
                "order_by": {
                    "type": "string",
                    "description": "Field to sort by",
                },
            },
            "required": ["page_size"],
        },
        handler=handle_mock,
        tags=["studio", "project", "files", "normalize"],
        samples=[
            {
                "description": "Example query",
                "query": {
                    "project_id": 123,
                    "file_types": [4, 7],
                    "owner_names": ["alice"],
                    "page_size": 10,
                    "order_type": "desc",
                },
            }
        ],
    )


@pytest.fixture()
def normalizer(list_files_tool: Tool) -> ArgumentNormalizer:
    norm = create_normalizer_for_tool(list_files_tool)
    assert norm is not None, "Normalizer should be created when 'normalize' tag is present"
    return norm


# --------------------
# Tests
# --------------------

def test_defaults_applied(normalizer: ArgumentNormalizer):
    # Minimal input with defaults
    input_args = {"page_size": 10}
    result = normalizer.normalize(input_args)

    assert result.get("page_size") == 10
    assert result.get("order_type") == "desc"  # Default from schema
    assert result.get("page_index") == 1  # Default from schema
    # assert result.get("name") == "dqc"  # Default from schema


def test_string_to_integer_conversion(normalizer: ArgumentNormalizer):
    input_args = {
        "project_id": "12345",
        "page_size": "15",
        "page_index": "2",
    }
    result = normalizer.normalize(input_args)

    assert isinstance(result["project_id"], int)
    assert result["project_id"] == 12345
    assert isinstance(result["page_size"], int)
    assert result["page_size"] == 15
    assert isinstance(result["page_index"], int)
    assert result["page_index"] == 2


def test_array_conversion_from_json_string(normalizer: ArgumentNormalizer):
    input_args = {
        "page_size": 10,
        "file_types": "[4, 7, 8]",
        "owner_names": '["alice", "bob"]',
    }
    result = normalizer.normalize(input_args)

    assert isinstance(result["file_types"], list)
    assert result["file_types"] == [4, 7, 8]
    assert isinstance(result["owner_names"], list)
    assert result["owner_names"] == ["alice", "bob"]


def test_nested_array_item_conversion(normalizer: ArgumentNormalizer):
    input_args = {
        "page_size": 10,
        "file_types": ["4", "7", "8"],
    }
    result = normalizer.normalize(input_args)

    assert result["file_types"] == [4, 7, 8]
    assert all(isinstance(x, int) for x in result["file_types"]) is True


def test_enum_validation_error(normalizer: ArgumentNormalizer):
    input_args = {
        "page_size": 10,
        "order_type": "invalid_order",
    }
    with pytest.raises(ArgumentNormalizationError) as exc:
        _ = normalizer.normalize(input_args)

    # Optional: basic checks on error details
    err = exc.value
    assert "order_type" in err.message
    assert "Allowed values" in err.message


def test_maximum_constraint_error(normalizer: ArgumentNormalizer):
    input_args = {"page_size": 50}  # Exceeds maximum of 20
    with pytest.raises(ArgumentNormalizationError) as exc:
        _ = normalizer.normalize(input_args)

    assert "exceeds maximum" in exc.value.message


def test_real_world_example(normalizer: ArgumentNormalizer):
    input_args = {
        "project_id": "109021",
        "file_types": ["4", "7"],
        "owner_names": ["studi_test_1"],
        "page_index": "1",
        "page_size": "10",
        "order_type": "desc",
        "order_by": "last_edit_time",
    }
    result = normalizer.normalize(input_args)

    assert isinstance(result["project_id"], int)
    assert result["project_id"] == 109021
    assert isinstance(result["file_types"], list)
    assert all(isinstance(x, int) for x in result["file_types"]) is True
    assert result["file_types"] == [4, 7]
    assert isinstance(result["page_index"], int)
    assert isinstance(result["page_size"], int)

def test_missing_required_argument(normalizer:  ArgumentNormalizer):
    input_args = {
        "project_id": "12345",
        # "page_size" is missing, which is required
    }
    result = normalizer.normalize(input_args)

    assert result["page_size"] == 10  # Default applied
