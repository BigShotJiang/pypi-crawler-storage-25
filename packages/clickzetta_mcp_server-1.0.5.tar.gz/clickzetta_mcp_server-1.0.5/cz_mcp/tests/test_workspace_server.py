from unittest.mock import Mock, patch

import pytest

from cz_mcp.handlers.workspace_server import workspace_list_user_workspaces


def _mock_response(status_code=200, payload=None, text=""):
    response = Mock()
    response.status_code = status_code
    response.text = text
    if payload is None:
        response.json.side_effect = ValueError("no json")
    else:
        response.json.return_value = payload
    return response


@patch("cz_mcp.handlers.workspace_server.print_curl_request")
@patch("cz_mcp.handlers.workspace_server.read_api", return_value="/workspace/list")
@patch("cz_mcp.handlers.workspace_server.read_url", return_value="https://example.com")
@patch("cz_mcp.handlers.workspace_server.RequestUtils")
def test_workspace_list_user_workspaces_uses_request_utils(
    mock_request_cls,
    _mock_read_url,
    _mock_read_api,
    _mock_print_curl,
):
    request_instance = Mock()
    request_instance.post.return_value = _mock_response(
        status_code=200,
        payload={"data": [{"projectName": "demo"}]},
    )
    mock_request_cls.return_value = request_instance

    data = workspace_list_user_workspaces(
        tenant_id="1",
        user_id="2",
        instance_name="inst",
        instance_id="3",
        jwt="token",
        env="dev",
    )

    assert data == [{"projectName": "demo"}]

    _, kwargs = request_instance.post.call_args
    assert kwargs["headers"]["X-Clickzetta-Token"] == "token"
    assert kwargs["json"]["tenantId"] == "1"
    assert "retry" not in kwargs
    assert "retry_times" not in kwargs


def test_workspace_list_user_workspaces_raise_on_non_200():
    request_instance = Mock()
    request_instance.post.return_value = _mock_response(
        status_code=500,
        payload={"code": "500", "message": "Internal Server Error"},
        text='{"code":"500","message":"Internal Server Error"}',
    )

    with patch("cz_mcp.handlers.workspace_server.print_curl_request"), patch(
        "cz_mcp.handlers.workspace_server.read_api", return_value="/workspace/list"
    ), patch("cz_mcp.handlers.workspace_server.read_url", return_value="https://example.com"), patch(
        "cz_mcp.handlers.workspace_server.RequestUtils", return_value=request_instance
    ):
        with pytest.raises(ValueError) as exc:
            workspace_list_user_workspaces(
                tenant_id="1",
                user_id="2",
                instance_name="inst",
                instance_id="3",
                jwt="token",
                env="dev",
            )
        assert "Failed to fetch workspace" in str(exc.value)
