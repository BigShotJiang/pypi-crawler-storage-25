#!/usr/bin/env python3
"""
Pytest configuration and shared fixtures for cz-mcp-server tests

Provides:
- StudioMCPTester: Base test client class
- mcp_client: Pytest fixture for MCP client session
"""
import asyncio
import logging
from typing import Optional

import pytest
from mcp import ClientSession, types
from mcp.client.streamable_http import streamablehttp_client

# Configure logging
from loguru import logger


class StudioMCPTester:
    """
    Base test client class for Studio MCP Server testing
    
    Provides connection management and common test utilities for MCP server testing.
    Can be used directly or via pytest fixtures.
    """

    def __init__(
        self, 
        base_url: str = "http://localhost:8000", 
        token: str = None,
        instance: str = "tmwmzxzs",
        username: str = "studi_test_1",
        workspace: str = "dev_automated_testing",
        vcluster: str = "DEFAULT",
        region: str = "dev",
        project_id: str = "113001"
    ):
        """
        Initialize MCP test client
        
        Args:
            base_url: MCP server base URL
            token: Authentication token
            instance: Lakehouse instance name
            username: Lakehouse username
            workspace: Lakehouse workspace
            vcluster: Virtual cluster name
            region: Region identifier
            project_id: Project ID
        """
        self.base_url = base_url
        self.mcp_url = f"{base_url}/mcp"
        self.token = token
        self.instance = instance
        self.username = username
        self.workspace = workspace
        self.vcluster = vcluster
        self.region = region
        self.project_id = project_id
        self.session: Optional[ClientSession] = None
        self._closed = False

    async def __aenter__(self):
        """Async context manager entry"""
        try:
            # Create streamable HTTP client connection
            self.client_context = streamablehttp_client(
                self.mcp_url,
                headers={
                    "x-lakehouse-token": f"Bearer {self.token}" if self.token else "",
                    "X-Lakehouse-Workspace": self.workspace,
                    "X-Lakehouse-VCluster": self.vcluster,
                    "x-lakehouse-region": self.region,
                }
            )

            # Enter the client context
            self.streams = await self.client_context.__aenter__()
            read_stream, write_stream, _ = self.streams

            # Create MCP session
            self.session_context = ClientSession(read_stream, write_stream)
            self.session = await self.session_context.__aenter__()

            # Initialize the connection
            await self.session.initialize()

            logger.info(f"✅ Connected to MCP server at {self.mcp_url}")
            return self

        except Exception as e:
            logger.error(f"❌ Failed to connect to MCP server: {e}")
            await self._cleanup()
            raise

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit with proper cleanup"""
        await self._cleanup()

    async def _cleanup(self):
        """Clean up resources"""
        if self._closed:
            return

        self._closed = True

        try:
            if hasattr(self, 'session_context') and self.session_context:
                await self.session_context.__aexit__(None, None, None)

            if hasattr(self, 'client_context') and self.client_context:
                await self.client_context.__aexit__(None, None, None)

        except Exception as e:
            logger.warning(f"⚠️ Error during cleanup: {e}")

    async def call_tool(self, tool_name: str, arguments: dict = None):
        """
        Call an MCP tool
        
        Args:
            tool_name: Name of the tool to call
            arguments: Tool arguments
            
        Returns:
            Tool execution result
        """
        if not self.session:
            raise RuntimeError("Client session not initialized. Use 'async with' context manager.")
        
        return await self.session.call_tool(tool_name, arguments or {})

    async def list_tools(self):
        """List available tools"""
        if not self.session:
            raise RuntimeError("Client session not initialized.")
        return await self.session.list_tools()

    async def list_resources(self):
        """List available resources"""
        if not self.session:
            raise RuntimeError("Client session not initialized.")
        return await self.session.list_resources()

    async def list_prompts(self):
        """List available prompts"""
        if not self.session:
            raise RuntimeError("Client session not initialized.")
        return await self.session.list_prompts()


# ==================== Pytest Fixtures ====================

@pytest.fixture(scope="session")
def default_test_token():
    """Default test token for MCP server authentication"""
    return "czt_87cae6fd49f5080d54a4c60c06bdf83e15375a27"


@pytest.fixture(scope="session")
def default_test_config():
    """Default test configuration"""
    return {
        "base_url": "http://localhost:8000",
        "instance": "tmwmzxzs",
        "username": "studi_test_1",
        "workspace": "dev_automated_testing",
        "vcluster": "DEFAULT",
        "region": "dev",
        "project_id": "113001"
    }


@pytest.fixture(scope="function")
async def mcp_client(default_test_token, default_test_config):
    """
    Pytest fixture providing an initialized MCP client session
    
    Usage:
        @pytest.mark.asyncio
        async def test_something(mcp_client):
            result = await mcp_client.call_tool("tool_name", {...})
            assert result is not None
    """
    async with StudioMCPTester(
        token=default_test_token,
        **default_test_config
    ) as client:
        yield client


@pytest.fixture
async def mcp_session(mcp_client):
    """
    Pytest fixture providing direct access to MCP session
    
    Usage:
        @pytest.mark.asyncio
        async def test_something(mcp_session):
            result = await mcp_session.call_tool("tool_name", {...})
    """
    return mcp_client.session


# ==================== Pytest Hooks ====================

def pytest_configure(config):
    """Register custom markers"""
    config.addinivalue_line(
        "markers", "slow: marks tests as slow (deselect with '-m \"not slow\"')"
    )
    config.addinivalue_line(
        "markers", "integration: marks tests as integration tests"
    )
    config.addinivalue_line(
        "markers", "unit: marks tests as unit tests"
    )

