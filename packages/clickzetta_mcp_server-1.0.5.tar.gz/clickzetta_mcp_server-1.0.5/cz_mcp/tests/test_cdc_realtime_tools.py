"""
Tests for CDC Real-Time Multi-Table Task Tools
"""

import pytest
import json
from unittest.mock import Mock, patch, AsyncMock

from cz_mcp.tools.cdc_realtime_tools import (
    handle_save_cdc_realtime_task,
    cdc_realtime_tools
)
from cz_mcp.core.server_core import MCPServerCore


@pytest.fixture
def mock_server():
    """Create mock server with connection config"""
    server = Mock(spec=MCPServerCore)
    server.connection_config = Mock()
    server.connection_config.project_id = 60001
    server.connection_config.token = "test_token"
    server.connection_config.instance = "test_instance"
    server.connection_config.env = "uat"
    return server


@pytest.mark.asyncio
async def test_save_cdc_realtime_task_success(mock_server):
    """Test successful CDC real-time task save"""
    
    # Mock API response
    mock_response = json.dumps({
        "code": "200",
        "message": "Success",
        "data": {
            "taskId": 12549001,
            "version": 1
        }
    })
    
    with patch('cz_mcp.tools.cdc_realtime_tools.save_cdc_task', return_value=mock_response):
        arguments = {
            "data_file_id": 12549001,
            "pipeline_type": 3,
            "save_mode": 2,
            "sync_mode": 1,
            "source_datasource_list": [
                {
                    "datasourceId": 12094,
                    "datasourceType": 5  # MySQL
                }
            ],
            "sync_object_list": [
                {
                    "schemaName": "wx3"
                }
            ],
            "target_datasource": {
                "datasourceId": 263,
                "datasourceType": 1  # Lakehouse
            }
        }
        
        result = await handle_save_cdc_realtime_task(
            arguments=arguments,
            server=mock_server
        )
        
        # Verify result
        assert "success" in result
        assert "Successfully saved multi-table real-time CDC task" in result


@pytest.mark.asyncio
async def test_save_cdc_realtime_task_missing_data_file_id(mock_server):
    """Test error when data_file_id is missing"""
    
    arguments = {
        "source_datasource_list": [{"datasourceId": 12094, "datasourceType": 5}],
        "sync_object_list": [{"schemaName": "wx3"}],
        "target_datasource": {"datasourceId": 263, "datasourceType": 1}
    }
    
    result = await handle_save_cdc_realtime_task(
        arguments=arguments,
        server=mock_server
    )
    
    assert "success" in result
    assert "Missing required parameter: data_file_id" in result


@pytest.mark.asyncio
async def test_save_cdc_realtime_task_invalid_source_type(mock_server):
    """Test error when source datasource type is invalid"""
    
    arguments = {
        "data_file_id": 12549001,
        "source_datasource_list": [
            {
                "datasourceId": 12094,
                "datasourceType": 99  # Invalid type
            }
        ],
        "sync_object_list": [{"schemaName": "wx3"}],
        "target_datasource": {"datasourceId": 263, "datasourceType": 1}
    }
    
    result = await handle_save_cdc_realtime_task(
        arguments=arguments,
        server=mock_server
    )
    
    assert "success" in result
    assert "Invalid source datasource type" in result


@pytest.mark.asyncio
async def test_save_cdc_realtime_task_invalid_target_type(mock_server):
    """Test error when target datasource type is invalid"""
    
    arguments = {
        "data_file_id": 12549001,
        "source_datasource_list": [{"datasourceId": 12094, "datasourceType": 5}],
        "sync_object_list": [{"schemaName": "wx3"}],
        "target_datasource": {
            "datasourceId": 263,
            "datasourceType": 99  # Invalid type
        }
    }
    
    result = await handle_save_cdc_realtime_task(
        arguments=arguments,
        server=mock_server
    )
    
    assert "success" in result
    assert "Invalid target datasource type" in result


@pytest.mark.asyncio
async def test_save_cdc_realtime_task_multiple_schemas(mock_server):
    """Test CDC task with multiple schemas"""
    
    mock_response = json.dumps({
        "code": "200",
        "message": "Success",
        "data": {"taskId": 12549001}
    })
    
    with patch('cz_mcp.tools.cdc_realtime_tools.save_cdc_task', return_value=mock_response):
        arguments = {
            "data_file_id": 12549001,
            "sync_mode": 1,
            "source_datasource_list": [
                {"datasourceId": 12094, "datasourceType": 5}
            ],
            "sync_object_list": [
                {"schemaName": "schema1"},
                {"schemaName": "schema2"},
                {"schemaName": "schema3", "tableName": "specific_table"}
            ],
            "target_datasource": {"datasourceId": 263, "datasourceType": 1}
        }
        
        result = await handle_save_cdc_realtime_task(
            arguments=arguments,
            server=mock_server
        )
        
        assert "success" in result
        assert "Successfully saved" in result


@pytest.mark.asyncio
async def test_save_cdc_realtime_task_postgresql_to_kafka(mock_server):
    """Test PostgreSQL to Kafka CDC task"""
    
    mock_response = json.dumps({
        "code": "200",
        "message": "Success",
        "data": {"taskId": 12549002}
    })
    
    with patch('cz_mcp.tools.cdc_realtime_tools.save_cdc_task', return_value=mock_response):
        arguments = {
            "data_file_id": 12549002,
            "sync_mode": 2,  # Incremental only
            "source_datasource_list": [
                {"datasourceId": 15001, "datasourceType": 7}  # PostgreSQL
            ],
            "sync_object_list": [
                {"schemaName": "public", "tableName": "users"}
            ],
            "target_datasource": {
                "datasourceId": 500,
                "datasourceType": 2  # Kafka
            }
        }
        
        result = await handle_save_cdc_realtime_task(
            arguments=arguments,
            server=mock_server
        )
        
        assert "success" in result


@pytest.mark.asyncio
async def test_save_cdc_realtime_task_sqlserver(mock_server):
    """Test SQL Server to Lakehouse CDC task"""
    
    mock_response = json.dumps({
        "code": "200",
        "message": "Success",
        "data": {"taskId": 12549003}
    })
    
    with patch('cz_mcp.tools.cdc_realtime_tools.save_cdc_task', return_value=mock_response):
        arguments = {
            "data_file_id": 12549003,
            "sync_mode": 1,
            "source_datasource_list": [
                {"datasourceId": 20001, "datasourceType": 8}  # SQL Server
            ],
            "sync_object_list": [
                {"schemaName": "dbo"}
            ],
            "target_datasource": {"datasourceId": 300, "datasourceType": 1}
        }
        
        result = await handle_save_cdc_realtime_task(
            arguments=arguments,
            server=mock_server
        )
        
        assert "success" in result


def test_cdc_realtime_tools_registration():
    """Test that CDC realtime tools are properly registered"""
    
    tools = cdc_realtime_tools()
    
    assert len(tools) == 1
    assert tools[0].name == "save_cdc_realtime_task"
    assert "CDC" in tools[0].description or "cdc" in tools[0].description
    
    # Check required parameters
    schema = tools[0].input_schema
    required_params = schema.get("required", [])
    assert "data_file_id" in required_params
    assert "source_datasource_list" in required_params
    assert "sync_object_list" in required_params
    assert "target_datasource" in required_params


def test_cdc_realtime_tools_samples():
    """Test that CDC realtime tools have valid samples"""
    
    tools = cdc_realtime_tools()
    tool = tools[0]
    
    assert hasattr(tool, "samples")
    assert len(tool.samples) >= 1
    
    # Validate first sample structure
    sample = tool.samples[0]
    assert "description" in sample
    assert "query" in sample
    
    query = sample["query"]
    assert "data_file_id" in query
    assert "source_datasource_list" in query
    assert "sync_object_list" in query
    assert "target_datasource" in query


@pytest.mark.asyncio
async def test_save_cdc_realtime_task_api_error(mock_server):
    """Test handling of API error response"""
    
    mock_response = json.dumps({
        "code": "500",
        "message": "Internal server error"
    })
    
    with patch('cz_mcp.tools.cdc_realtime_tools.save_cdc_task', return_value=mock_response):
        arguments = {
            "data_file_id": 12549001,
            "source_datasource_list": [{"datasourceId": 12094, "datasourceType": 5}],
            "sync_object_list": [{"schemaName": "wx3"}],
            "target_datasource": {"datasourceId": 263, "datasourceType": 1}
        }
        
        result = await handle_save_cdc_realtime_task(
            arguments=arguments,
            server=mock_server
        )
        
        assert "success" in result
        assert "API request failed" in result or "Internal server error" in result

