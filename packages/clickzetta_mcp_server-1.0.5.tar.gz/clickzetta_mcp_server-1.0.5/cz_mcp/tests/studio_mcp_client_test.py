#!/usr/bin/env python3
"""
Studio MCP Server Client Test

Comprehensive test script for Studio MCP server using StudioMCPTester base class.
Tests basic functionality and list_project_files tool.
"""
import asyncio
import json
import logging
import os
import signal
import sys

from mcp import types

# Import base test class from conftest
from conftest import StudioMCPTester

# Configure logging
logging.basicConfig(level=logging.INFO)
from loguru import logger

class StudioMCPTestSuite:
    """Test suite for Studio MCP Server using StudioMCPTester base class"""

    def __init__(self, tester: StudioMCPTester):
        self.tester = tester
        self.session = tester.session

    async def test_basic_functionality(self):
        """Test basic MCP functionality"""
        logger.info("🧪 Testing basic MCP functionality...")

        try:
            # Test 1: List available tools
            logger.info("1. Testing list_tools...")
            tools_result = await self.tester.list_tools()

            if tools_result and tools_result.tools:
                logger.info(f"   ✅ Found {len(tools_result.tools)} tools:")
                for tool in tools_result.tools:
                    logger.info(f"      - {tool.name}: {tool.description}")
            else:
                logger.warning("   ⚠️ No tools found")

            # Test 2: List available resources
            logger.info("2. Testing list_resources...")
            try:
                resources_result = await self.tester.list_resources()
                if resources_result and resources_result.resources:
                    logger.info(f"   ✅ Found {len(resources_result.resources)} resources:")
                    for resource in resources_result.resources:
                        logger.info(f"      - {resource.name}: {resource.description}")
                else:
                    logger.info("   ✅ No resources found (expected for Studio)")
            except Exception as e:
                logger.info(f"   ✅ Resources not supported: {e}")

            # Test 3: List available prompts
            logger.info("3. Testing list_prompts...")
            try:
                prompts_result = await self.tester.list_prompts()
                if prompts_result and prompts_result.prompts:
                    logger.info(f"   ✅ Found {len(prompts_result.prompts)} prompts:")
                    for prompt in prompts_result.prompts:
                        logger.info(f"      - {prompt.name}: {prompt.description}")
                else:
                    logger.info("   ✅ No prompts found")
            except Exception as e:
                logger.info(f"   ✅ Prompts not supported: {e}")

            return True

        except Exception as e:
            logger.error(f"❌ Basic functionality test failed: {e}")
            return False

    async def test_list_project_files(self):
        """Test list_project_files tool"""
        logger.info("🧪 Testing list_project_files tool...")

        try:
            # Test 4: Simple file listing
            logger.info("4. Testing basic file listing...")
            result = await self.tester.call_tool(
                "list_project_files",
                {
                    "page_index": 1,
                    "page_size": 5,
                    "name": "",
                    "order_type": "desc"
                }
            )

            if result.isError:
                logger.error("   ❌ Tool call failed!")
                for content in result.content:
                    if isinstance(content, types.TextContent):
                        logger.error(f"      Error: {content.text}")
                return False
            else:
                logger.info("   ✅ Basic file listing successful")
                self._log_tool_result(result)

            # Test 5: Filtered file listing
            logger.info("5. Testing list_project_files with filters...")
            result = await self.tester.call_tool(
                "list_project_files",
                {
                    "file_types": [4, 7],  # SQL and Python files
                    "page_index": 1,
                    "page_size": 10,
                    "order_type": "desc"
                }
            )

            if result.isError:
                logger.error("   ❌ Filtered query failed!")
                for content in result.content:
                    if isinstance(content, types.TextContent):
                        logger.error(f"      Error: {content.text}")
                return False
            else:
                logger.info("   ✅ Filtered file listing successful")
                self._log_tool_result(result)

            return True

        except Exception as e:
            logger.error(f"❌ list_project_files test failed: {e}")
            return False

    def _log_tool_result(self, result):
        """Log tool execution result"""
        logger.info(f"      Tool execution result:")

        for i, content in enumerate(result.content):
            if isinstance(content, types.TextContent):
                # Try to parse as JSON for better formatting
                try:
                    data = json.loads(content.text)
                    logger.info(f"      Content {i + 1} (JSON):")
                    logger.info(f"         {json.dumps(data, indent=2)[:500]}...")
                except json.JSONDecodeError:
                    logger.info(f"      Content {i + 1} (Text): {content.text[:200]}...")

            elif isinstance(content, types.EmbeddedResource):
                resource = content.resource
                if isinstance(resource, types.TextResourceContents):
                    logger.info(f"      Resource {i + 1}: {resource.uri}")
                    logger.info(f"         {resource.text[:200]}...")

            elif isinstance(content, types.ImageContent):
                logger.info(f"      Image {i + 1}: {content.mimeType}, {len(content.data)} bytes")

            else:
                logger.info(f"      Content {i + 1}: {type(content).__name__}")

    async def test_custom_project(self, project_id: str = "109021"):
        """Test with a specific project ID"""
        logger.info(f"🧪 Testing with custom project ID: {project_id}")

        try:
            result = await self.tester.call_tool(
                "list_project_files",
                {
                    "project_id": int(project_id),
                    "page_index": 1,
                    "page_size": 5,
                    "name": "",
                    "order_type": "desc"
                }
            )

            if result.isError:
                logger.error(f"   ❌ Custom project test failed!")
                for content in result.content:
                    if isinstance(content, types.TextContent):
                        logger.error(f"      Error: {content.text}")
                return False
            else:
                logger.info(f"   ✅ Custom project {project_id} test successful")
                self._log_tool_result(result)
                return True

        except Exception as e:
            logger.error(f"❌ Custom project test failed: {e}")
            return False


def _load_test_token() -> str:
    """Load test token from test_config.json (not committed to git)."""
    config_path = os.path.join(os.path.dirname(__file__), "test_config.json")
    try:
        with open(config_path) as f:
            return json.load(f).get("test_token", "")
    except FileNotFoundError:
        logger.warning(f"test_config.json not found at {config_path}, falling back to TEST_TOKEN env var")
        return os.environ.get("TEST_TOKEN", "")


async def run_comprehensive_test():
    """Run comprehensive test suite"""
    logger.info("🚀 Starting Studio MCP comprehensive test suite...")

    test_token = _load_test_token()

    try:
        async with StudioMCPTester(token=test_token) as tester:
            # Create test suite instance
            test_suite = StudioMCPTestSuite(tester)
            results = []

            # Run all tests
            results.append(await test_suite.test_basic_functionality())
            results.append(await test_suite.test_list_project_files())
            results.append(await test_suite.test_custom_project())

            # Summary
            passed = sum(results)
            total = len(results)

            logger.info(f"📊 Test Summary: {passed}/{total} tests passed")

            if passed == total:
                logger.info("🎉 All tests passed!")
                return True
            else:
                logger.warning(f"⚠️ {total - passed} tests failed")
                return False

    except Exception as e:
        logger.error(f"❌ Test suite failed: {e}")
        return False


def setup_signal_handlers():
    """Setup signal handlers for graceful shutdown"""

    def signal_handler(signum, frame):
        logger.info("🛑 Received interrupt signal, shutting down...")
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)


def main():
    """Main entry point"""
    setup_signal_handlers()
    success = asyncio.run(run_comprehensive_test())
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
