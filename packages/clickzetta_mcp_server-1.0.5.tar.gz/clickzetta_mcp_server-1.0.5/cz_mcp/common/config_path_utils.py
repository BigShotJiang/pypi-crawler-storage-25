"""
配置文件路径工具类 - Docker友好的配置文件查找
统一处理MCP服务器和相关工具的配置文件路径解析
"""
import os
from typing import Optional, List
import logging

from loguru import logger


def find_config_file(filename: str = "connections.json", additional_paths: Optional[List[str]] = None) -> Optional[str]:
    """
    Docker友好的配置文件查找
    
    Args:
        filename: 配置文件名，默认为 connections.json
        additional_paths: 额外的搜索路径列表
        
    Returns:
        找到的配置文件路径，如果未找到返回None
    """
    # 标准优先级路径
    standard_paths = [
        f"/app/.clickzetta/lakehouse_connection/{filename}",  # Docker统一路径（最高优先级）
        f"/app/config/lakehouse_connection/{filename}",      # Docker挂载路径
        os.path.expanduser(f"~/.clickzetta/{filename}"),     # 用户主目录（仅非Docker）
        f"config/lakehouse_connection/{filename}"            # 项目默认模板
    ]
    
    # 合并路径列表
    all_paths = standard_paths
    if additional_paths:
        all_paths = additional_paths + standard_paths
    
    logger.debug(f"查找配置文件 {filename}，搜索路径: {all_paths}")
    
    # 按优先级查找
    for path in all_paths:
        if os.path.exists(path):
            logger.debug(f"找到配置文件: {path}")
            return path
        else:
            logger.debug(f"配置文件不存在: {path}")
    
    logger.warning(f"未找到配置文件: {filename}")
    return None


def get_config_file_path(filename: str = "connections.json", additional_paths: Optional[List[str]] = None) -> str:
    """
    获取配置文件路径，如果找不到则返回默认用户主目录路径
    
    Args:
        filename: 配置文件名，默认为 connections.json
        additional_paths: 额外的搜索路径列表
        
    Returns:
        配置文件路径（存在或默认）
    """
    config_path = find_config_file(filename, additional_paths)
    
    if config_path:
        return config_path
    else:
        # 返回默认路径（即使不存在）
        default_path = os.path.expanduser(f"~/.clickzetta/{filename}")
        logger.info(f"使用默认配置文件路径: {default_path}")
        return default_path


def is_docker_environment() -> bool:
    """
    检测是否在Docker环境中运行
    
    Returns:
        True如果在Docker环境中，False否则
    """
    # 方法1: 检查/.dockerenv文件
    if os.path.exists('/.dockerenv'):
        return True
        
    # 方法2: 检查环境变量
    if os.environ.get('DOCKER_CONTAINER'):
        return True
        
    # 方法3: 检查/proc/1/cgroup
    try:
        with open('/proc/1/cgroup', 'r') as f:
            return 'docker' in f.read()
    except:
        pass
        
    return False


def get_backup_directory() -> str:
    """
    获取Docker友好的备份目录路径
    
    Returns:
        备份目录路径
    """
    if os.path.exists("/app/.clickzetta"):
        return "/app/.clickzetta/backups"
    else:
        return os.path.expanduser("~/.clickzetta/backups")


def ensure_config_directory(path: str) -> bool:
    """
    确保配置文件目录存在
    
    Args:
        path: 配置文件或目录路径
        
    Returns:
        True如果目录创建成功或已存在，False如果失败
    """
    try:
        if os.path.isfile(path):
            # 如果是文件路径，获取其目录
            directory = os.path.dirname(path)
        else:
            # 如果是目录路径
            directory = path
            
        os.makedirs(directory, exist_ok=True)
        return True
    except Exception as e:
        logger.error(f"无法创建配置目录 {path}: {e}")
        return False


# 向后兼容的便捷函数
def get_connections_json_path() -> str:
    """获取connections.json文件路径（向后兼容）"""
    return get_config_file_path("connections.json")