"""
通配符和正则表达式工具
用于处理documents_source_path中的通配符模式
"""
import logging
from typing import Optional
from urllib.parse import urlencode

from ..core import StudioConfig
from ..utils.config_utils import read_web_url

from loguru import logger


def _build_ide_studio_url(config: StudioConfig, data_task_id: int, env: str) -> Optional[str]:
    """
    Build Clickzetta Studio URL for a task

    Args:
        config: instance connection config
        data_task_id: Task ID (fileId)

    Returns:
        Studio URL string or None if config is incomplete
    """
    try:

        if not config:
            return None

        # Get base_url and workspace_name from config
        base_url = read_web_url(env=env)
        workspace_name = config.workspace
        instance = config.instance

        if not base_url or not workspace_name or not instance:
            logger.warning(f"Cannot build Studio URL: missing base_url, workspace_name or instance")
            return None

        # Remove protocol prefix from base_url if present
        base_url = base_url.replace('https://', '').replace('http://', '').rstrip('/')

        # Build Studio URL: https://instance.base_url/ide?workspace_name=xxx&fileId=xxx
        # Use urlencode to properly encode query parameters
        query_params = urlencode({
            "workspace_name": workspace_name,
            "fileId": str(data_task_id)
        })
        studio_url = f"https://{instance}.{base_url}/ide?{query_params}"
        return studio_url

    except Exception as e:
        logger.warning(f"Error building Studio URL: {e}")
        return None


def _build_ops_studio_url(config:StudioConfig , id: int, sub_page_name:str, env: str) -> Optional[str]:
    """
    Build Clickzetta Studio OPS URL for a task or instance

    Args:
        config: instance connection config
        id: Task ID (fileId) or instance ID or complement task ID
        sub_page_name: task/complement/taskInst
    Returns:
        Studio URL string or None if config is incomplete
    """
    try:

        if not config:
            return None

        # Get base_url and workspace_name from config
        base_url = read_web_url(env=env)
        workspace_name = config.workspace
        instance = config.instance

        if not base_url or not workspace_name or not instance:
            logger.warning(f"Cannot build Studio URL: missing base_url, workspace_name or instance")
            return None

        # Remove protocol prefix from base_url if present
        base_url = base_url.replace('https://', '').replace('http://', '').rstrip('/')

        # Build Studio URL: https://instance.base_url/ops/sub_page_name/id


        studio_url = f"https://{instance}.{base_url}/ops/{sub_page_name}/{id}"
        return studio_url

    except Exception as e:
        logger.warning(f"Error building Studio URL: {e}")
        return None

# https://tmwmzxzs.dev-app.clickzetta.com/dqc?listType=qualityRule&objectName=public.daily_volume&workspaceId=60001&projectId=60001&env=prod
def _build_dqc_studio_url(config:StudioConfig , object_name: str, env: str) -> Optional[str]:
    """
    Build Clickzetta Studio DQC URL for a task or instance

    Args:
        config: instance connection config
        object_name: object name
    Returns:
        Studio URL string or None if config is incomplete
    """
    try:
        base_url = read_web_url(env=env)
        project_id = config.project_id
        instance = config.instance
        if not base_url or not project_id or not instance:
            logger.warning(f"Cannot build Studio URL: missing base_url, workspace_id or project_id or instance")
            return None
        base_url = read_web_url(env=env)
        base_url = base_url.replace('https://', '').replace('http://', '').rstrip('/')
        studio_url = f"https://{instance}.{base_url}/dqc?listType=qualityRule&objectName={object_name}&workspaceId={project_id}&projectId={project_id}&env=prod"
        return studio_url
    except Exception as e:
        logger.warning(f"Error building Studio URL: {e}")
        return None
