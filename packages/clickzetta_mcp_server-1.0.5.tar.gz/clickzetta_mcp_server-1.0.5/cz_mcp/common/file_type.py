from enum import IntEnum


class FileType(IntEnum):
    """Task type enumeration matching Clickzetta Studio schema types"""
    Virtual = 0  # 虚拟任务
    DataIntegration = 1  # 离线同步
    LakeHouse = 4  # SQL
    Shell = 5  # Shell
    Python3 = 7  # Python
    RealTimeDI = 14  # 实时同步
    JDBC = 15  # JDBC
    DynamicTable = 16  # 动态表
    ContinuousJob = 17  # 流式SQL
    FullIncrementalSync = 280  # 全增量一体同步
    MultipleRISync = 281  # 多表实时同步
    MultipleDISync = 291  # 多表离线同步
    DatabrickSql = 300  # Databricks SQL
    DatabrickNotebook = 301  # Databricks Notebook
    Spark = 400  # Spark
    Flow = 500  # 组合任务


# File type mapping: ID -> Display Name
OFFLINE_FILE_TYPE_MAP = {
    FileType.LakeHouse: 'SQL',
    FileType.Python3: 'Python',
    FileType.Shell: 'Shell',
    FileType.DataIntegration: '离线同步',
    FileType.JDBC: 'JDBC',
    FileType.ContinuousJob: '流式SQL',
    FileType.DynamicTable: '动态表',
    FileType.Virtual: '虚拟任务',
    FileType.DatabrickSql: 'Databricks SQL',
    FileType.DatabrickNotebook: 'Databricks Notebook',
    FileType.Spark: 'Spark',
    FileType.Flow: '组合任务',
    FileType.MultipleDISync: '多表离线同步',
}

REALTIME_FILE_TYPE_MAP = {
    FileType.MultipleRISync: '多表实时同步',
    FileType.FullIncrementalSync: '全增量一体同步',
    FileType.RealTimeDI: '实时同步',
}
FILE_TYPE_MAP = {
    **OFFLINE_FILE_TYPE_MAP,
    **REALTIME_FILE_TYPE_MAP,
}
