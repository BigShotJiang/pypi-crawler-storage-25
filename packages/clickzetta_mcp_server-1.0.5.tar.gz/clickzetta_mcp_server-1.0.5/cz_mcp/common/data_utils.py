"""
数据处理工具模块 - 从util.py完整迁移

包含所有数据处理相关功能：
- 嵌入向量获取
- 文件和URL数据读取
- 数据库连接和数据读取  
- DataFrame schema生成
- ClickZetta数据插入

完整迁移日期：2025-08-23
原文件：util.py (515行) → data_utils.py
"""

import pandas as pd
# 设置日志记录器
from loguru import logger
from sqlalchemy import create_engine

# 导入embedding_provider模块
from .embedding_provider import get_embedding_provider

# 嵌入相关配置
embedding_provider = "dashscope"  # 默认使用通义千问
embedding_model_name = "text-embedding-v4"  # 通义千问默认模型
embedding_dim = 1024  # text-embedding-v4 向量维度
embedding_max_tokens = 2048


def get_embedding_hf(query):
    """
    获取文本嵌入向量（保持向后兼容的函数名）
    
    Args:
        query: 单个文本字符串或文本列表
        
    Returns:
        numpy数组或numpy数组列表
    """
    provider = get_embedding_provider()
    return provider.get_embedding(query)


# 向后兼容的别名
get_embedding = get_embedding_hf


def read_data_from_url_or_file_into_dataframe(source: str, **kwargs) -> pd.DataFrame:
    """
    从URL或文件路径读取数据到DataFrame - 增强版本
    支持所有pandas格式，压缩文件，智能参数检测
    
    支持格式：
    - 结构化：CSV, TSV, Excel(xlsx/xls), JSON, XML, HTML
    - 大数据：Parquet, ORC, Feather, Pickle
    - 科学计算：HDF5, SAS, SPSS, Stata
    - 压缩格式：ZIP, GZ, BZ2, XZ, ZSTD
    - 智能检测：TXT(自动分隔符), 多编码支持
    
    Args:
        source: URL或文件路径
        **kwargs: 传递给pandas读取函数的参数
        
    Returns:
        pd.DataFrame: 读取的数据
        
    Raises:
        RuntimeError: 当读取失败或缺少依赖时
        
    Examples:
        >>> # 基本用法
        >>> df = read_data_from_url_or_file_into_dataframe('data.csv')
        >>> 
        >>> # 高级参数
        >>> df = read_data_from_url_or_file_into_dataframe(
        ...     'https://example.com/data.xlsx',
        ...     sheet_name='Sheet2',
        ...     encoding='gbk',
        ...     nrows=1000
        ... )
        >>>
        >>> # 压缩文件
        >>> df = read_data_from_url_or_file_into_dataframe('data.csv.gz')
    """
    
    try:
        # 规范化输入
        source = source.strip()
        is_url = source.startswith(('http://', 'https://'))
        
        logger.info(f"开始读取数据源: {source[:100]}...")
        
        # 自动检测文件格式
        source_lower = source.lower()
        
        # 处理压缩文件
        compression = None
        if source_lower.endswith(('.gz', '.gzip')):
            compression = 'gzip'
            # 移除压缩后缀以检测原格式
            source_for_format = source_lower.rsplit('.gz', 1)[0].rsplit('.gzip', 1)[0]
        elif source_lower.endswith('.bz2'):
            compression = 'bz2'
            source_for_format = source_lower.rsplit('.bz2', 1)[0]
        elif source_lower.endswith('.xz'):
            compression = 'xz'
            source_for_format = source_lower.rsplit('.xz', 1)[0]
        elif source_lower.endswith('.zip'):
            compression = 'zip'
            source_for_format = source_lower.rsplit('.zip', 1)[0]
        else:
            source_for_format = source_lower
            
        # 智能格式检测和参数优化
        read_func = None
        read_kwargs = kwargs.copy()
        
        if any(source_for_format.endswith(ext) for ext in ['.csv', '.tsv', '.txt']):
            read_func = pd.read_csv
            # CSV智能参数
            if '.tsv' in source_for_format or 'tab' in source_for_format:
                read_kwargs.setdefault('sep', '\t')
            if 'encoding' not in read_kwargs:
                # 智能编码检测
                read_kwargs['encoding'] = 'utf-8'
                
        elif any(source_for_format.endswith(ext) for ext in ['.xlsx', '.xls']):
            read_func = pd.read_excel
            read_kwargs.setdefault('engine', 'openpyxl' if '.xlsx' in source_for_format else 'xlrd')
            
        elif source_for_format.endswith('.json'):
            read_func = pd.read_json
            read_kwargs.setdefault('lines', True)  # 默认处理JSONLines格式
            
        elif source_for_format.endswith('.parquet'):
            read_func = pd.read_parquet
            read_kwargs.setdefault('engine', 'pyarrow')
            
        elif source_for_format.endswith('.orc'):
            read_func = pd.read_orc
            
        elif source_for_format.endswith('.feather'):
            read_func = pd.read_feather
            
        elif source_for_format.endswith('.pickle'):
            read_func = pd.read_pickle
            
        elif any(source_for_format.endswith(ext) for ext in ['.h5', '.hdf5', '.hdf']):
            read_func = pd.read_hdf
            read_kwargs.setdefault('key', 'data')  # 默认key
            
        elif source_for_format.endswith('.sas7bdat'):
            read_func = pd.read_sas
            
        elif source_for_format.endswith('.sav'):
            read_func = pd.read_spss
            
        elif any(source_for_format.endswith(ext) for ext in ['.dta', '.stata']):
            read_func = pd.read_stata
            
        elif any(source_for_format.endswith(ext) for ext in ['.xml']):
            read_func = pd.read_xml
            
        elif any(source_for_format.endswith(ext) for ext in ['.html', '.htm']):
            read_func = pd.read_html
            # HTML返回list，取第一个表格
            def html_wrapper(*args, **kwargs):
                tables = pd.read_html(*args, **kwargs)
                return tables[0] if tables else pd.DataFrame()
            read_func = html_wrapper
            
        else:
            # 默认尝试CSV，使用智能分隔符检测
            read_func = pd.read_csv
            read_kwargs.setdefault('sep', None)  # 让pandas自动检测
            read_kwargs.setdefault('engine', 'python')  # 支持更复杂的分隔符检测
            
        # 添加压缩参数
        if compression and 'compression' not in read_kwargs:
            read_kwargs['compression'] = compression
            
        # 执行读取
        logger.debug(f"使用函数: {read_func.__name__}, 参数: {read_kwargs}")
        
        df = read_func(source, **read_kwargs)
        
        # 验证结果
        if df is None or df.empty:
            logger.warning(f"读取到空数据: {source}")
            return pd.DataFrame()
            
        logger.info(f"成功读取数据: {df.shape[0]} 行 x {df.shape[1]} 列")
        return df
        
    except ImportError as e:
        # 提供具体的安装建议
        missing_lib = str(e).split("'")[1] if "'" in str(e) else "unknown"
        suggestions = {
            'openpyxl': 'pip install openpyxl',
            'xlrd': 'pip install xlrd',
            'pyarrow': 'pip install pyarrow',
            'lxml': 'pip install lxml',
            'html5lib': 'pip install html5lib',
            'beautifulsoup4': 'pip install beautifulsoup4',
            'tables': 'pip install tables',
            'fastparquet': 'pip install fastparquet'
        }
        suggestion = suggestions.get(missing_lib, f'pip install {missing_lib}')
                
        raise RuntimeError(f"缺少依赖包: {e}. {suggestion}")
    except Exception as e:
        raise RuntimeError(f"读取文件失败 {source}: {e}")



def generate_df_schema_sql(df: pd.DataFrame) -> str:
    """
    Generate a SQL schema definition string for a DataFrame for CREATE TABLE statement.
    
    Args:
        df (pd.DataFrame): The DataFrame for which to generate the schema.
    
    Returns:
        str: The schema definition string for CREATE TABLE (e.g., "col1 VARCHAR(255), col2 INT")
    """
    type_mapping = {
        "int64": "BIGINT",
        "int32": "INT", 
        "float64": "DOUBLE",
        "float32": "FLOAT",
        "object": "VARCHAR(255)",  # Default string length
        "bool": "BOOLEAN",
        "datetime64[ns]": "TIMESTAMP",
    }
    
    schema_parts = []
    for column_name, dtype in df.dtypes.items():
        # 清理列名，确保符合SQL标识符规范
        clean_column_name = str(column_name).replace(' ', '_').replace('-', '_')
        sql_type = type_mapping.get(str(dtype), "VARCHAR(255)")  # Default to VARCHAR if type is unknown
        schema_parts.append(f"{clean_column_name} {sql_type}")
    
    return ", ".join(schema_parts)


def connect_to_database_and_read_data_from_table_into_dataframe(
    db_type: str,
    host: str = None,
    port: int = None,
    database: str = None,
    username: str = None,
    password: str = None,
    table_name: str = None,
    driver: str = None
) -> pd.DataFrame:
    """
    Establish a connection to a database and read data from a specified table into a Pandas DataFrame.

    Args:
        db_type (str): The type of the database (e.g., 'mysql', 'postgresql', 'sqlite', 'mssql', 'oracle').
        host (str): The hostname or IP address of the database server. Not required for SQLite.
        port (int): The port number of the database server. Not required for SQLite.
        database (str): The name of the database to connect to. For SQLite, this is the file path to the database file.
        username (str): The username for authentication. Not required for SQLite.
        password (str): The password for authentication. Not required for SQLite.
        table_name (str): The name of the table to read data from.
        driver (str): Optional. The driver to use for the connection (e.g., 'pymysql', 'psycopg2').

    Returns:
        pd.DataFrame: A DataFrame containing the data from the specified table.

    Raises:
        ValueError: If required parameters are missing or the database type is unsupported.
        ConnectionError: If the connection to the database fails.
        RuntimeError: If reading data from the table fails.
    """
    # Supported database types
    supported_db_types = ["mysql", "postgresql", "sqlite", "mssql", "oracle"]

    if db_type not in supported_db_types:
        raise ValueError(f"Unsupported database type '{db_type}'. Supported types are: {', '.join(supported_db_types)}")

    if not table_name:
        raise ValueError("A valid table name must be provided.")

    # Construct the connection URL
    if db_type == "sqlite":
        # SQLite uses a file path instead of host/port
        connection_url = f"sqlite:///{database}"
    elif db_type == "mysql":
        driver = driver or "pymysql"  # Default to pymysql for MySQL
        connection_url = f"mysql+{driver}://{username}:{password}@{host}:{port}/{database}"
    elif db_type == "postgresql":
        driver = driver or "psycopg2"  # Default to psycopg2 for PostgreSQL
        connection_url = f"postgresql+{driver}://{username}:{password}@{host}:{port}/{database}"
    elif db_type == "mssql":
        driver = driver or "pyodbc"  # Default to pyodbc for MSSQL
        connection_url = f"mssql+{driver}://{username}:{password}@{host}:{port}/{database}"
    elif db_type == "oracle":
        driver = driver or "cx_oracle"  # Default to cx_oracle for Oracle
        connection_url = f"oracle+{driver}://{username}:{password}@{host}:{port}/?service_name={database}"
    else:
        raise ValueError(f"Unsupported database type '{db_type}'.")

    # Create the SQLAlchemy engine
    try:
        engine = create_engine(connection_url)
        logger.info(f"Connecting to the {db_type} database '{database}' at {host}:{port}...")
    except Exception as e:
        raise ConnectionError(f"Failed to connect to the {db_type} database. Error: {e}")

    # Execute the query and return results as a DataFrame
    try:
        query = f"SELECT * FROM {table_name}"
        df = pd.read_sql(query, engine)
        
        # 关键修复：正确处理NaN值，防止在后续处理中变成字符串'nan'
        # 1. 将所有NaN替换为None（Python的NULL值）
        df = df.where(pd.notnull(df), None)
        
        # 2. 特殊处理布尔列中的NA值，防止"boolean value of NA is ambiguous"错误
        for col in df.columns:
            col_dtype = str(df[col].dtype)
            
            # 处理布尔列
            if df[col].dtype == 'bool' or 'bool' in col_dtype.lower():
                if df[col].isna().any():
                    na_count = df[col].isna().sum()
                    logger.info(f"布尔列 {col} 有 {na_count} 个NA值，转换处理中")
                    # 转换为nullable boolean类型，然后替换为None
                    df[col] = df[col].astype('boolean')
                    df[col] = df[col].where(pd.notnull(df[col]), None)
            
            # 处理字符串列中的NaN
            elif df[col].dtype == 'object':
                # 将字符串形式的'nan', 'NaN', 'NULL'替换为None
                df[col] = df[col].replace(['nan', 'NaN', 'NAN', 'null', 'NULL'], None)
        
        # 3. 关键修复：清理和验证列名，防止'nan'列名问题
        new_columns = []
        for i, col in enumerate(df.columns):
            col_str = str(col)
            
            # 检查列名是否为各种形式的无效值
            if col_str.lower() in ['nan', 'none', 'null', '', 'unnamed']:
                # 无效列名，使用默认名称
                new_col_name = f"COLUMN_{i+1}"
                logger.warning(f"列名 '{col_str}' 无效，替换为 '{new_col_name}'")
            else:
                # 清理有效列名，确保符合SQL标准
                new_col_name = col_str.replace(' ', '_').replace('-', '_').replace('.', '_').upper()
                
                # 确保列名不以数字开头
                if new_col_name and new_col_name[0].isdigit():
                    new_col_name = f"COL_{new_col_name}"
            
            new_columns.append(new_col_name)
        
        # 处理重复列名
        seen_columns = {}
        final_columns = []
        for col in new_columns:
            if col in seen_columns:
                seen_columns[col] += 1
                final_col = f"{col}_{seen_columns[col]}"
            else:
                seen_columns[col] = 0
                final_col = col
            final_columns.append(final_col)
        
        df.columns = final_columns
        logger.info(f"列名处理完成，最终列名: {list(df.columns)}")
        
        logger.info(f"Successfully read {len(df)} rows from table '{table_name}' with proper NULL handling.")
        return df
    except Exception as e:
        raise RuntimeError(f"Failed to read data from table '{table_name}'. Error: {e}")


def insert_dataframe_to_clickzetta(df: pd.DataFrame, table_name: str, db_connection, 
                                  if_exists: str = "append", method: str = "multi") -> bool:
    """
    Insert a DataFrame into a ClickZetta table.
    
    Args:
        df: The DataFrame to insert
        table_name: Target table name
        db_connection: Database connection object
        if_exists: What to do if table exists ('fail', 'replace', 'append')
        method: Insert method ('multi' for batch insert)
        
    Returns:
        bool: True if successful
        
    Raises:
        RuntimeError: If insert fails
    """
    try:
        # Convert DataFrame to the format expected by ClickZetta
        # This is a simplified implementation - actual implementation would depend on ClickZetta's requirements
        
        logger.info(f"开始插入数据到表 {table_name}: {df.shape[0]} 行 x {df.shape[1]} 列")
        
        # Use pandas to_sql method for now - would need ClickZetta-specific optimization
        rows_affected = df.to_sql(
            table_name, 
            con=db_connection, 
            if_exists=if_exists,
            index=False,
            method=method
        )
        
        logger.info(f"成功插入 {len(df)} 行数据到表 {table_name}")
        return True
        
    except Exception as e:
        logger.error(f"插入数据失败: {e}")
        raise RuntimeError(f"Failed to insert data into table '{table_name}': {e}")


# 向后兼容的函数别名
def convert_df_to_dict(df: pd.DataFrame):
    """向后兼容：转换DataFrame到字典格式"""
    # 导入utilities中的实现
    from .utilities import convert_df_to_dict as _convert_df_to_dict
    return _convert_df_to_dict(df)


# 导出所有公共函数
__all__ = [
    'get_embedding_hf',
    'get_embedding', 
    'read_data_from_url_or_file_into_dataframe',
    'connect_to_database_and_read_data_from_table_into_dataframe',
    'insert_dataframe_to_clickzetta',
    'convert_df_to_dict',
    'embedding_provider',
    'embedding_model_name', 
    'embedding_dim',
    'embedding_max_tokens'
]