#!/usr/bin/env python3
"""
文件路径工具模块 - 支持默认上传和下载目录
"""

import os
from typing import Optional, List
from pathlib import Path

class FilePathManager:
    """文件路径管理器 - 处理默认上传下载目录"""

    # 默认上传目录优先级顺序
    DEFAULT_UPLOAD_DIRS = [
        "/app/.clickzetta/data/uploads",
        "~/.clickzetta/data/uploads"
    ]

    # 默认下载目录优先级顺序
    DEFAULT_DOWNLOAD_DIRS = [
        "/app/.clickzetta/data/downloads",
        "~/.clickzetta/data/downloads"
    ]

    @classmethod
    def get_upload_directories(cls) -> List[str]:
        """获取上传目录列表（展开~路径）"""
        return [os.path.expanduser(path) for path in cls.DEFAULT_UPLOAD_DIRS]

    @classmethod
    def get_download_directories(cls) -> List[str]:
        """获取下载目录列表（展开~路径）"""
        return [os.path.expanduser(path) for path in cls.DEFAULT_DOWNLOAD_DIRS]

    @classmethod
    def find_upload_file(cls, filename: str) -> Optional[str]:
        """
        在默认上传目录中查找文件

        Args:
            filename: 文件名（可以是相对路径）

        Returns:
            找到的完整文件路径，如果未找到返回None
        """
        # 如果已经是绝对路径或当前目录下存在，直接返回
        if os.path.isabs(filename) or os.path.exists(filename):
            return filename if os.path.exists(filename) else None

        # 在默认上传目录中查找
        for upload_dir in cls.get_upload_directories():
            if os.path.exists(upload_dir):
                candidate_path = os.path.join(upload_dir, filename)
                if os.path.exists(candidate_path):
                    return candidate_path

        # 未找到返回原始路径（让调用者处理错误）
        return filename

    @classmethod
    def get_default_download_path(cls, filename: str) -> str:
        """
        获取默认下载路径

        Args:
            filename: 目标文件名

        Returns:
            完整的下载路径
        """
        # 尝试第一个可用的下载目录
        for download_dir in cls.get_download_directories():
            expanded_dir = os.path.expanduser(download_dir)

            # 尝试创建目录
            try:
                os.makedirs(expanded_dir, exist_ok=True)
                if os.path.exists(expanded_dir) and os.access(expanded_dir, os.W_OK):
                    return os.path.join(expanded_dir, filename)
            except (OSError, PermissionError):
                continue

        # 如果都失败，使用当前目录
        return filename

    @classmethod
    def ensure_upload_directories(cls) -> List[str]:
        """
        确保上传目录存在，返回成功创建或已存在的目录列表
        """
        created_dirs = []

        for upload_dir in cls.get_upload_directories():
            try:
                os.makedirs(upload_dir, exist_ok=True)
                if os.path.exists(upload_dir):
                    created_dirs.append(upload_dir)
            except (OSError, PermissionError):
                pass  # 忽略权限错误，继续尝试下一个

        return created_dirs

    @classmethod
    def ensure_download_directories(cls) -> List[str]:
        """
        确保下载目录存在，返回成功创建或已存在的目录列表
        """
        created_dirs = []

        for download_dir in cls.get_download_directories():
            try:
                os.makedirs(download_dir, exist_ok=True)
                if os.path.exists(download_dir):
                    created_dirs.append(download_dir)
            except (OSError, PermissionError):
                pass  # 忽略权限错误，继续尝试下一个

        return created_dirs

    @classmethod
    def get_search_summary(cls, filename: str, found_path: Optional[str]) -> dict:
        """
        获取文件搜索总结信息

        Args:
            filename: 搜索的文件名
            found_path: 找到的路径（如果有）

        Returns:
            搜索总结字典
        """
        upload_dirs = cls.get_upload_directories()

        summary = {
            "requested_file": filename,
            "search_directories": upload_dirs,
            "found_path": found_path,
            "search_successful": found_path is not None and os.path.exists(found_path)
        }

        # 检查各个目录的状态
        directory_status = []
        for dir_path in upload_dirs:
            status = {
                "path": dir_path,
                "exists": os.path.exists(dir_path),
                "readable": os.path.exists(dir_path) and os.access(dir_path, os.R_OK),
                "contains_file": False
            }

            if status["exists"] and status["readable"]:
                candidate_file = os.path.join(dir_path, filename)
                status["contains_file"] = os.path.exists(candidate_file)

            directory_status.append(status)

        summary["directory_status"] = directory_status
        return summary


def get_enhanced_file_path(source_path: str) -> tuple[str, dict]:
    """
    增强的文件路径获取 - 支持默认目录搜索

    Args:
        source_path: 用户提供的源文件路径

    Returns:
        (实际文件路径, 搜索信息字典)
    """
    if not source_path:
        return source_path, {"error": "源路径为空"}

    # 如果是URL，直接返回
    if source_path.startswith(('http://', 'https://', 'ftp://', 'ftps://')):
        return source_path, {"type": "url", "original_path": source_path}

    # 尝试在上传目录中查找文件
    found_path = FilePathManager.find_upload_file(source_path)
    search_summary = FilePathManager.get_search_summary(source_path, found_path)

    return found_path or source_path, {
        "type": "local_file",
        "original_path": source_path,
        "search_summary": search_summary
    }


def get_enhanced_download_path(target_path: Optional[str], default_filename: str) -> tuple[str, dict]:
    """
    增强的下载路径获取 - 支持默认下载目录

    Args:
        target_path: 用户指定的目标路径（可选）
        default_filename: 默认文件名

    Returns:
        (实际下载路径, 路径信息字典)
    """
    if target_path:
        # 用户指定了路径，直接使用
        return target_path, {
            "type": "user_specified",
            "path": target_path
        }

    # 使用默认下载路径
    default_path = FilePathManager.get_default_download_path(default_filename)

    download_dirs = FilePathManager.get_download_directories()
    available_dirs = FilePathManager.ensure_download_directories()

    return default_path, {
        "type": "default_download",
        "path": default_path,
        "default_directories": download_dirs,
        "available_directories": available_dirs,
        "filename": default_filename
    }