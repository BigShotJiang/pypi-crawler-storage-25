"""
嵌入向量提供者模块
支持多种嵌入服务：通义千问、OpenAI等
"""
import os
import logging
import hashlib
from typing import List, Union, Dict, Any, Optional
import numpy as np
from functools import lru_cache

from loguru import logger

class EmbeddingProvider:
    """统一的嵌入向量提供者接口"""
    
    def __init__(self, config: Dict[str, Any]):
        """
        初始化嵌入提供者
        
        Args:
            config: 配置字典，包含：
                - provider: 提供者类型 (dashscope/openai)
                - dashscope_config: 通义千问配置
                - openai_config: OpenAI配置
                - cache_config: 缓存配置
        """
        self.config = config
        self.provider = config.get("provider", "dashscope")
        self._provider_instance = None
        self._cache = {}  # 简单内存缓存
        self.cache_enabled = config.get("cache", {}).get("enabled", True)
        self.cache_max_size = config.get("cache", {}).get("max_size", 10000)
        
    def get_provider(self):
        """延迟初始化具体的提供者"""
        if self._provider_instance is None:
            if self.provider == "dashscope":
                self._provider_instance = DashScopeEmbeddingProvider(
                    self.config.get("dashscope", {})
                )
            elif self.provider == "openai":
                self._provider_instance = OpenAIEmbeddingProvider(
                    self.config.get("openai", {})
                )
            else:
                raise ValueError(f"Unsupported provider: {self.provider}. Supported providers: dashscope, openai")
        return self._provider_instance
    
    def get_embedding(self, text: Union[str, List[str]]) -> Union[np.ndarray, List[np.ndarray]]:
        """获取文本嵌入向量（带缓存）"""
        if isinstance(text, str):
            # 单文本处理
            if self.cache_enabled:
                cache_key = self._get_cache_key(text)
                if cache_key in self._cache:
                    logger.debug(f"缓存命中: {text[:50]}...")
                    return self._cache[cache_key].copy()
            
            embedding = self.get_provider().get_embedding(text)
            
            if self.cache_enabled and len(self._cache) < self.cache_max_size:
                self._cache[cache_key] = embedding.copy()
                
            return embedding
        else:
            # 批量处理
            return self._get_batch_embeddings_with_cache(text)
    
    def _get_cache_key(self, text: str) -> str:
        """生成缓存键"""
        return f"{self.provider}:{hashlib.md5(text.encode()).hexdigest()}"
    
    def _get_batch_embeddings_with_cache(self, texts: List[str]) -> List[np.ndarray]:
        """批量获取嵌入（带缓存）"""
        results = []
        uncached_texts = []
        uncached_indices = []
        
        # 检查缓存
        for i, text in enumerate(texts):
            if self.cache_enabled:
                cache_key = self._get_cache_key(text)
                if cache_key in self._cache:
                    results.append((i, self._cache[cache_key].copy()))
                    continue
            
            uncached_texts.append(text)
            uncached_indices.append(i)
        
        # 获取未缓存的嵌入
        if uncached_texts:
            new_embeddings = self.get_provider().get_embedding(uncached_texts)
            for idx, text, emb in zip(uncached_indices, uncached_texts, new_embeddings):
                if self.cache_enabled and len(self._cache) < self.cache_max_size:
                    cache_key = self._get_cache_key(text)
                    self._cache[cache_key] = emb.copy()
                results.append((idx, emb))
        
        # 按原始顺序返回
        results.sort(key=lambda x: x[0])
        return [emb for _, emb in results]

class DashScopeEmbeddingProvider:
    """通义千问嵌入提供者"""
    
    def __init__(self, config: Dict[str, Any]):
        self.api_key = config.get("api_key") or os.getenv("DASHSCOPE_API_KEY")
        self.model = config.get("model", "text-embedding-v4")
        self.max_text_length = config.get("max_text_length", 2048)
        
        if not self.api_key:
            raise ValueError("通义千问API密钥未配置，请在配置文件或环境变量DASHSCOPE_API_KEY中设置")
        
        # 初始化通义千问SDK
        try:
            import dashscope
            dashscope.api_key = self.api_key
        except ImportError:
            raise ImportError("请安装dashscope包: pip install dashscope")
        
    def get_embedding(self, text: Union[str, List[str]]) -> Union[np.ndarray, List[np.ndarray]]:
        """获取嵌入向量"""
        try:
            from dashscope import TextEmbedding
        except ImportError:
            raise ImportError("请安装dashscope包: pip install dashscope")
        
        is_batch = isinstance(text, list)
        texts = text if is_batch else [text]
        
        # 预处理文本
        processed_texts = []
        for t in texts:
            if not t or len(t.strip()) == 0:
                processed_texts.append("empty")
            elif len(t) > self.max_text_length:
                logger.warning(f"文本太长（{len(t)}字符），截断到{self.max_text_length}字符")
                processed_texts.append(t[:self.max_text_length])
            else:
                processed_texts.append(t)
        
        try:
            response = TextEmbedding.call(
                model=self.model,
                input=processed_texts
            )
            
            if response.status_code == 200:
                embeddings = [np.array(emb['embedding']) for emb in response.output['embeddings']]
                return embeddings if is_batch else embeddings[0]
            else:
                raise Exception(f"通义千问API调用失败: {response}")
                
        except Exception as e:
            logger.error(f"获取嵌入失败: {e}")
            raise

class OpenAIEmbeddingProvider:
    """OpenAI兼容的嵌入提供者（支持通义千问兼容模式）"""
    
    def __init__(self, config: Dict[str, Any]):
        self.api_key = config.get("api_key") or os.getenv("OPENAI_API_KEY")
        self.model = config.get("model", "text-embedding-ada-002")
        self.api_base = config.get("api_base", "https://api.openai.com/v1")
        self.max_text_length = config.get("max_text_length", 8191)
        
        if not self.api_key:
            raise ValueError("OpenAI API密钥未配置")
        
    def get_embedding(self, text: Union[str, List[str]]) -> Union[np.ndarray, List[np.ndarray]]:
        """获取嵌入向量"""
        try:
            import openai
        except ImportError:
            raise ImportError("请安装openai包: pip install openai")
        
        openai.api_key = self.api_key
        openai.api_base = self.api_base
        
        is_batch = isinstance(text, list)
        texts = text if is_batch else [text]
        
        # 预处理文本
        processed_texts = []
        for t in texts:
            if not t or len(t.strip()) == 0:
                processed_texts.append("empty")
            elif len(t) > self.max_text_length:
                logger.warning(f"文本太长，截断到{self.max_text_length}字符")
                processed_texts.append(t[:self.max_text_length])
            else:
                processed_texts.append(t)
        
        try:
            response = openai.Embedding.create(
                model=self.model,
                input=processed_texts
            )
            
            embeddings = [np.array(item['embedding']) for item in response['data']]
            return embeddings if is_batch else embeddings[0]
            
        except Exception as e:
            logger.error(f"OpenAI API调用失败: {e}")
            raise

# 全局嵌入提供者实例
_embedding_provider = None

def init_embedding_provider(config: Dict[str, Any]):
    """初始化全局嵌入提供者"""
    global _embedding_provider
    _embedding_provider = EmbeddingProvider(config)
    logger.info(f"初始化嵌入提供者: {config.get('provider', 'dashscope')}")

def get_embedding_provider() -> EmbeddingProvider:
    """获取全局嵌入提供者实例"""
    global _embedding_provider
    if _embedding_provider is None:
        # 如果未初始化，尝试使用通义千问
        if os.getenv("DASHSCOPE_API_KEY"):
            logger.info("检测到通义千问API密钥，使用通义千问作为默认嵌入提供者")
            _embedding_provider = EmbeddingProvider({
                "provider": "dashscope",
                "dashscope": {
                    "api_key": os.getenv("DASHSCOPE_API_KEY"),
                    "model": "text-embedding-v4"
                }
            })
        elif os.getenv("OPENAI_API_KEY"):
            logger.info("检测到OpenAI API密钥，使用OpenAI作为默认嵌入提供者")
            _embedding_provider = EmbeddingProvider({
                "provider": "openai",
                "openai": {
                    "api_key": os.getenv("OPENAI_API_KEY"),
                    "model": "text-embedding-ada-002"
                }
            })
        else:
            raise ValueError(
                "未配置嵌入提供者。请在配置文件中设置embedding配置，"
                "或设置环境变量DASHSCOPE_API_KEY（通义千问）或OPENAI_API_KEY（OpenAI）"
            )
    return _embedding_provider

# Unstructured集成支持
def get_unstructured_embedder_config(system_config: Dict[str, Any]):
    """
    为Unstructured生成嵌入配置
    支持通过OpenAI兼容接口使用通义千问
    """
    from unstructured_ingest.processes.embedder import EmbedderConfig
    
    embedding_config = system_config.get("embedding", {})
    provider = embedding_config.get("provider", "dashscope")
    
    if provider == "dashscope":
        # 使用DashScope嵌入器
        dashscope_config = embedding_config.get("dashscope", {})
        api_key = dashscope_config.get("api_key") or os.getenv("DASHSCOPE_API_KEY")
        
        if not api_key:
            raise ValueError("通义千问API密钥未配置，请设置DASHSCOPE_API_KEY环境变量或在配置文件中设置")
        
        return EmbedderConfig(
            embedding_provider="dashscope",
            embedding_api_key=api_key,
            embedding_model_name=dashscope_config.get("model", "text-embedding-v4"),
            embedding_api_base=dashscope_config.get("api_base", "https://dashscope.aliyuncs.com/compatible-mode/v1")
        )
    
    elif provider == "openai":
        openai_config = embedding_config.get("openai", {})
        api_key = openai_config.get("api_key") or os.getenv("OPENAI_API_KEY")
        
        if not api_key:
            raise ValueError("OpenAI API密钥未配置，请设置OPENAI_API_KEY环境变量或在配置文件中设置")
        
        return EmbedderConfig(
            embedding_provider="openai",
            embedding_api_key=api_key,
            embedding_model_name=openai_config.get("model", "text-embedding-ada-002"),
            embedding_api_base=openai_config.get("api_base", "https://api.openai.com/v1")
        )
    
    else:
        raise ValueError(f"不支持的嵌入提供者: {provider}。支持的提供者: dashscope, openai")