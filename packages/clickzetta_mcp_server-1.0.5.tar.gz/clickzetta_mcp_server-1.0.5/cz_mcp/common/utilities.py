"""
共享工具函数模块
"""

import decimal
import json
import uuid
from datetime import datetime, date, time
from typing import Any, Dict
from uuid import UUID

import mcp.types as types
import numpy as np
import pandas as pd
import yaml

# 导入响应配置
try:
    from ..config.response_config import get_config, should_include_sql, get_warning
except ImportError:
    # 向后兼容：如果配置模块不存在，使用默认行为
    def get_config():
        return None
    def should_include_sql():
        import os
        return os.getenv('MCP_VERBOSE', 'false').lower() == 'true'
    def get_warning(warning_type, **context):
        return None


def json_serializer(obj: Any) -> Any:
    # Decimal 类型
    if isinstance(obj, decimal.Decimal):
        return float(obj)

    # 日期时间类型
    elif isinstance(obj, pd.Timestamp):
        return obj.isoformat()
    elif isinstance(obj, datetime):
        return obj.isoformat()
    elif isinstance(obj, date):
        return obj.isoformat()
    elif isinstance(obj, time):
        return obj.isoformat()

    # UUID 类型
    elif isinstance(obj, UUID):
        return str(obj)

    # 二进制类型
    elif isinstance(obj, (bytes, bytearray)):
        try:
            return obj.decode('utf-8')
        except UnicodeDecodeError:
            import base64
            return base64.b64encode(obj).decode('utf-8')

    # 集合类型
    elif isinstance(obj, (set, frozenset)):
        return list(obj)

    # numpy 类型
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    elif isinstance(obj, np.generic):
        return obj.item()

    # 不支持的类型
    else:
        return str(obj)


def convert_df_to_dict(data: pd.DataFrame) -> list[dict[str, Any]]:
    """
    将DataFrame转换为字典列表，处理特殊数据类型以确保JSON序列化兼容性
    
    Args:
        data: 要转换的DataFrame
        
    Returns:
        字典列表，所有值都转换为可JSON序列化的类型
    """
    # Convert Timestamp, date, Decimal, and ndarray objects to strings or lists for JSON serialization compatibility
    df = pd.DataFrame(data)

    def convert_value(value):
        # 修复：使用正确的类型检查
        if isinstance(value, (pd.Timestamp, datetime, date)):
            return value.isoformat()
        elif isinstance(value, (decimal.Decimal, float)):
            return str(value)
        elif isinstance(value, np.ndarray):
            return value.tolist()
        elif pd.isna(value):
            return None
        # 修复Bug 5: 保持布尔值类型
        elif isinstance(value, bool):
            return value
        # 修复布尔值解析问题：处理字符串形式的布尔值
        elif isinstance(value, str):
            if value == 'True':
                return True
            elif value == 'False':
                return False
            else:
                return value
        # 保持数值类型
        elif isinstance(value, (int, float)):
            return value
        else:
            return str(value)

    # 使用map代替已弃用的applymap
    try:
        df = df.map(convert_value)  # pandas 2.1.0+
    except AttributeError:
        df = df.applymap(convert_value)  # 向后兼容
    
    data = df.to_dict(orient="records")
    return data


def to_builtin_type(obj):
    """
    递归将所有 numpy 类型转为 Python 内置类型，确保可 JSON 序列化
    
    Args:
        obj: 要转换的对象
        
    Returns:
        转换后的Python内置类型对象
    """
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    elif isinstance(obj, (np.generic,)):
        return obj.item()
    elif isinstance(obj, dict):
        return {k: to_builtin_type(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [to_builtin_type(v) for v in obj]
    else:
        return obj


def data_to_yaml(data: Any) -> str:
    """
    将数据转换为YAML格式字符串
    
    Args:
        data: 要转换的数据
        
    Returns:
        YAML格式字符串
    """
    try:
        return yaml.dump(data, indent=2, sort_keys=False, allow_unicode=True, default_flow_style=False)
    except:
        return str(data)


def types_compatible(existing_type: str, new_type: str) -> bool:
    """
    检查两种数据类型是否兼容
    
    Args:
        existing_type: 现有表的列类型
        new_type: 新数据的列类型
        
    Returns:
        bool: 是否兼容
    """
    # 类型标准化
    existing_type = existing_type.lower().strip()
    new_type = new_type.lower().strip()
    
    # 相同类型直接兼容
    if existing_type == new_type:
        return True
    
    # 定义类型兼容性映射
    compatible_types = {
        # 数值类型兼容性
        'int': ['bigint', 'integer', 'smallint', 'tinyint', 'int64', 'int32', 'int16', 'int8'],
        'bigint': ['int', 'integer', 'smallint', 'tinyint', 'int64', 'int32', 'int16', 'int8'],
        'integer': ['int', 'bigint', 'smallint', 'tinyint', 'int64', 'int32', 'int16', 'int8'],
        'float': ['double', 'decimal', 'numeric', 'real', 'float64', 'float32'],
        'double': ['float', 'decimal', 'numeric', 'real', 'float64', 'float32'],
        'decimal': ['float', 'double', 'numeric', 'real', 'float64', 'float32'],
        
        # 字符串类型兼容性
        'string': ['varchar', 'char', 'text', 'clob'],
        'varchar': ['string', 'char', 'text', 'clob'],
        'char': ['string', 'varchar', 'text', 'clob'],
        'text': ['string', 'varchar', 'char', 'clob'],
        
        # 日期时间类型兼容性
        'timestamp': ['datetime', 'timestamptz'],
        'datetime': ['timestamp', 'timestamptz'],
        'date': ['timestamp', 'datetime'],
        
        # 布尔类型
        'boolean': ['bool', 'bit'],
        'bool': ['boolean', 'bit'],
    }
    
    # 检查类型兼容性
    if existing_type in compatible_types:
        return new_type in compatible_types[existing_type]
    
    if new_type in compatible_types:
        return existing_type in compatible_types[new_type]
    
    # 默认不兼容
    return False


class ResponseOptimizationConfig:
    """响应优化配置"""
    # 默认配置
    COMPRESSION_LEVEL = "smart"  # none | smart | aggressive
    PRESERVE_ALL_DATA = True  # 是否保留所有业务数据
    MAX_ITEMS_DISPLAY = -1  # -1表示不限制，正数表示最大显示条数
    
    @classmethod
    def get_config(cls):
        """获取当前配置"""
        import os
        level = os.getenv("MCP_RESPONSE_COMPRESSION", "smart").lower()
        return {
            "level": level,
            "preserve_data": level != "aggressive",
            "max_items": -1 if level != "aggressive" else 50
        }


class ResponseBuilder:
    """
    统一的响应构造器，用于减少重复的返回值构造代码
    提供标准化的响应格式，确保所有handler的输出一致性
    """
    
    # 定义始终要移除的冗余字段
    ALWAYS_REMOVE_FIELDS = {
        "execution_time", "server_version", "request_id",
        "session_id", "query_id", "timestamp", "response_time",
        "trace_id", "span_id", "correlation_id", "api_version",
        "sdk_version", "client_version", "host", "port",
        "process_id", "thread_id", "memory_usage", "cpu_usage"
    }
    
    # 重要字段，即使为空也要保留
    IMPORTANT_FIELDS = {
        "sql_conversion", "sql_conversion_note", "sql_query_executed"
    }
    
    @staticmethod
    def _optimize_data(data: Any) -> Any:
        """
        优化数据结构，移除冗余信息
        """
        if isinstance(data, dict):
            # 创建新字典，只包含需要的字段
            optimized = {}
            
            for key, value in data.items():
                # 跳过始终移除的字段
                if key in ResponseBuilder.ALWAYS_REMOVE_FIELDS:
                    continue
                
                # 递归优化嵌套结构
                if isinstance(value, (dict, list)):
                    optimized_value = ResponseBuilder._optimize_data(value)
                    if optimized_value or key in ResponseBuilder.IMPORTANT_FIELDS:  # 重要字段即使为空也保留
                        optimized[key] = optimized_value
                else:
                    optimized[key] = value
            
            # 特殊处理：如果只有data字段，直接返回data内容
            if len(optimized) == 1 and "data" in optimized:
                return optimized["data"]
            
            return optimized
            
        elif isinstance(data, list):
            # 递归优化列表中的每个元素
            optimized = [ResponseBuilder._optimize_data(item) for item in data]
            # 过滤掉空元素
            return [item for item in optimized if item]
        
        return data
    
    @staticmethod
    def create_data_intensive_response(data: Any, tool_name: str = None) -> list[types.TextContent | types.EmbeddedResource]:
        """
        为数据密集型工具创建优化的响应格式
        """
        if not isinstance(data, (dict, list)):
            return ResponseBuilder.create_yaml_json_response(data)
        
        # 特殊处理 read_query 的响应
        if tool_name == "read_query" and isinstance(data, list) and len(data) > 0:
            query_result = data[0] if isinstance(data[0], dict) else data
            
            # 提取结果数据
            result_data = query_result.get("result", [])
            
            # 构建精简响应
            core_data = {
                "data": result_data,
                "count": query_result.get("count", len(result_data))
            }
            
            # 只在截断时添加提示
            if query_result.get("truncated"):
                core_data["truncated"] = True
                core_data["limit"] = query_result.get("limit", 50)
                # 使用配置系统获取警告
                warning = get_warning("result_truncated", limit=core_data["limit"], max_limit=100) if get_warning else None
                if warning:
                    core_data["hint"] = warning
                elif query_result.get("hint"):
                    core_data["hint"] = query_result["hint"]
            
            # 只在详细模式包含SQL
            if should_include_sql and should_include_sql():
                if query_result.get("sql_executed"):
                    core_data["sql"] = query_result["sql_executed"]
            
            return ResponseBuilder.create_yaml_json_response(core_data)
        
        # 特殊处理 show_object_list 的响应
        if tool_name == "show_object_list" and isinstance(data, list) and len(data) > 0:
            result_info = data[0] if isinstance(data[0], dict) else data
            
            # FUNCTIONS 特殊处理 - 修复JIRA Bug
            if result_info.get("type") == "FUNCTIONS" or result_info.get("object_type") == "FUNCTIONS":
                # 对于函数，直接返回优化后的结构
                return ResponseBuilder.create_yaml_json_response(result_info)
            
            # 提取核心信息 - 保留完整数据
            core_data = {
                "type": result_info.get("object_type", "UNKNOWN"),
                "count": result_info.get("result_count", len(result_info.get("result", []))),
                "data": result_info.get("result", [])  # 保留所有数据
            }
            
            # 优化数据结构但不截断
            if isinstance(core_data["data"], list) and len(core_data["data"]) > 0:
                # 检测数据中的冗余字段
                first_item = core_data["data"][0]
                if isinstance(first_item, dict):
                    # 识别总是为空或相同的字段
                    fields_to_check = list(first_item.keys())
                    redundant_fields = []
                    
                    for field in fields_to_check:
                        # 检查这个字段是否在所有记录中都相同或为空
                        values = [item.get(field) for item in core_data["data"][:100]]  # 采样前100条
                        unique_values = set(str(v) for v in values if v is not None)
                        
                        # 如果所有值都相同或都为空，考虑移除
                        if len(unique_values) <= 1:
                            # 但保留某些重要字段
                            if field not in ["name", "type", "owner", "schema_name", "table_name", "column_name"]:
                                redundant_fields.append(field)
                    
                    # 创建精简的数据结构
                    if redundant_fields:
                        simplified_data = []
                        for item in core_data["data"]:
                            simplified_item = {k: v for k, v in item.items() if k not in redundant_fields}
                            simplified_data.append(simplified_item)
                        core_data["data"] = simplified_data
                        core_data["optimized_fields"] = f"Removed {len(redundant_fields)} redundant fields"
            
            # 添加关键统计信息（精简格式）
            if "table_statistics" in result_info:
                stats = result_info["table_statistics"]
                
                # Story CZ-2025-001-003: 支持新的语义化统计格式
                if "meta" in stats and "table_types" in stats["meta"]:
                    # 新格式：使用meta.table_types
                    table_types = stats["meta"]["table_types"]
                    non_zero_stats = {}
                    if table_types.get("regular", 0) > 0:
                        non_zero_stats["regular"] = table_types["regular"]
                    if table_types.get("view", 0) > 0:
                        non_zero_stats["views"] = table_types["view"]
                    if table_types.get("external", 0) > 0:
                        non_zero_stats["external"] = table_types["external"]
                    if table_types.get("dynamic", 0) > 0:
                        non_zero_stats["dynamic"] = table_types["dynamic"]
                    if table_types.get("materialized_view", 0) > 0:
                        non_zero_stats["materialized_views"] = table_types["materialized_view"]
                    
                    if non_zero_stats:
                        core_data["types"] = non_zero_stats
                        core_data["total"] = stats["meta"].get("total_count", 0)
                else:
                    # 旧格式兼容
                    non_zero_stats = {}
                    if stats.get("regular_tables", 0) > 0:
                        non_zero_stats["tables"] = stats["regular_tables"]
                    if stats.get("views", 0) > 0:
                        non_zero_stats["views"] = stats["views"]
                    if stats.get("external_tables", 0) > 0:
                        non_zero_stats["external"] = stats["external_tables"]
                    if non_zero_stats:
                        core_data["stats"] = non_zero_stats
                    
            elif "function_statistics" in result_info:
                # 支持旧格式的function_statistics
                stats = result_info["function_statistics"]
                non_zero_stats = {}
                if stats.get("external_functions", 0) > 0:
                    non_zero_stats["external"] = stats["external_functions"]
                if stats.get("builtin_functions", 0) > 0:
                    non_zero_stats["builtin"] = stats["builtin_functions"]
                if non_zero_stats:
                    core_data["stats"] = non_zero_stats
            
            elif "meta" in result_info:
                # Story CZ-2025-001-003: 支持新的语义化统计格式
                meta = result_info["meta"]
                
                # 处理table_types或function_types
                if "table_types" in meta:
                    types = meta["table_types"]
                    non_zero_stats = {}
                    for key, value in types.items():
                        if value > 0:
                            non_zero_stats[key] = value
                    if non_zero_stats:
                        core_data["types"] = non_zero_stats
                        core_data["total"] = meta.get("total_count", 0)
                
                elif "function_types" in meta:
                    types = meta["function_types"]
                    non_zero_stats = {}
                    for key, value in types.items():
                        if value > 0:
                            non_zero_stats[key] = value
                    if non_zero_stats:
                        core_data["types"] = non_zero_stats
                        core_data["total"] = meta.get("total_count", 0)
            
            # 如果原始响应标记了截断，保留提示
            if result_info.get("truncated"):
                core_data["note"] = "Data was truncated by the query, use limit parameter for more"
            
            return ResponseBuilder.create_yaml_json_response(core_data)
        
        # 特殊处理 desc_object 的响应
        if tool_name == "desc_object" and isinstance(data, list) and len(data) > 0:
            desc_info = data[0] if isinstance(data[0], dict) else data
            
            # 提取核心信息
            core_data = {
                "object": desc_info.get("object_name", "UNKNOWN"),
                "type": desc_info.get("object_type", "UNKNOWN"),
                "columns": desc_info.get("result", [])
            }
            
            # 优化列信息结构，但保留所有重要字段
            if isinstance(core_data["columns"], list):
                optimized_columns = []
                for col in core_data["columns"]:
                    if isinstance(col, dict):
                        # 提取列名和类型（必需）
                        col_name = col.get("name") or col.get("column_name") or col.get("col_name")
                        col_type = col.get("type") or col.get("data_type") or col.get("col_type")
                        
                        if not col_name:
                            continue  # 跳过没有列名的
                            
                        optimized_col = {
                            "name": col_name,
                            "type": col_type
                        }
                        
                        # 保留所有非默认值的重要属性
                        # 注释
                        comment = col.get("comment") or col.get("col_comment")
                        if comment and comment.strip() and comment.strip().lower() != "null":
                            optimized_col["comment"] = comment.strip()
                        
                        # 主键
                        if col.get("primary_key") == "true" or col.get("is_primary_key"):
                            optimized_col["primary_key"] = True
                            
                        # 分区键
                        if col.get("partition_key") == "true" or col.get("is_partition_key"):
                            optimized_col["partition_key"] = True
                            
                        # 聚簇键
                        if col.get("cluster_key") == "true" or col.get("is_cluster_key"):
                            optimized_col["cluster_key"] = True
                            
                        # 唯一键
                        if col.get("unique_key") == "true" or col.get("is_unique"):
                            optimized_col["unique"] = True
                            
                        # 非空约束
                        if col.get("nullable") == "false" or col.get("not_null"):
                            optimized_col["not_null"] = True
                            
                        # 默认值
                        default_val = col.get("default_value") or col.get("default")
                        if default_val and str(default_val).strip() and str(default_val).lower() not in ["null", "none"]:
                            optimized_col["default"] = default_val
                        
                        optimized_columns.append(optimized_col)
                        
                core_data["columns"] = optimized_columns
                
                # 添加列统计摘要
                if optimized_columns:
                    column_summary = {
                        "total": len(optimized_columns),
                        "primary_keys": sum(1 for c in optimized_columns if c.get("primary_key")),
                        "partition_keys": sum(1 for c in optimized_columns if c.get("partition_key")),
                        "with_comments": sum(1 for c in optimized_columns if c.get("comment"))
                    }
                    # 只添加非零的统计
                    non_zero_summary = {k: v for k, v in column_summary.items() if v > 0}
                    if len(non_zero_summary) > 1:  # 如果除了total还有其他信息
                        core_data["column_summary"] = non_zero_summary
            
            return ResponseBuilder.create_yaml_json_response(core_data)
        
        # 默认处理
        return ResponseBuilder.create_yaml_json_response(data)
    
    @staticmethod
    def create_compact_response(data: Any) -> list[types.TextContent]:
        """
        创建极简响应格式（仅用于简单操作成功）
        """
        if isinstance(data, dict) and len(data) <= 3:
            # 对于极简数据，直接返回纯文本
            lines = []
            for key, value in data.items():
                lines.append(f"{key}: {value}")
            return ResponseBuilder.create_text_response("\n".join(lines))
        else:
            # 复杂数据仍使用标准格式
            return ResponseBuilder.create_yaml_json_response(data)
    
    @staticmethod
    def create_unoptimized_response(data: Any, data_id: str = None) -> list[types.TextContent | types.EmbeddedResource]:
        """
        创建不经过优化的完整响应，用于需要保持原始数据结构的场景
        如外部函数模板、完整配置信息等
        """
        if data_id is None:
            data_id = str(uuid.uuid4())
            
        output = {
            "success": True,
            "type": "data", 
            "data_id": data_id,
            "data": data,  # 不经过_optimize_data处理
        }
        yaml_output = data_to_yaml(output)
        json_output = json.dumps(output, ensure_ascii=False, default=json_serializer)

        return [
            types.TextContent(type="text", text=yaml_output),
            types.EmbeddedResource(
                type="resource",
                resource=types.TextResourceContents(
                    uri=f"data://{data_id}", 
                    text=json_output, 
                    mimeType="application/json"
                ),
            )
        ]



    @staticmethod
    def create_text_response(content: str) -> list[types.TextContent]:
        """
        创建纯文本响应
        
        Args:
            content: 文本内容
            
        Returns:
            包含TextContent的列表
        """
        return [types.TextContent(type="text", text=content)]
    
    @staticmethod
    def create_sql_result_response(sql: str, result_data: Any, data_id: str = None, 
                                   error: Exception = None) -> list[types.TextContent | types.EmbeddedResource]:
        """
        创建SQL执行结果的标准响应格式，支持错误处理优化
        
        Args:
            sql: 执行的SQL语句
            result_data: SQL执行结果数据
            data_id: 数据ID，如果为None则自动生成
            error: 异常对象（如果有）
            
        Returns:
            包含SQL执行结果的标准响应格式
        """
        if data_id is None:
            data_id = str(uuid.uuid4())
        
        # 错误处理优化
        if error is not None:
            user_friendly_error = ResponseBuilder._format_user_friendly_error(error, sql)
            data = [{"SQL": sql, "Error": user_friendly_error, "Success": False}]
            return ResponseBuilder.create_yaml_json_response(data, data_id)
            
        # 转换DataFrame为dict并处理特殊类型
        if hasattr(result_data, 'to_dict'):
            processed_data = convert_df_to_dict(result_data)
        else:
            processed_data = result_data
            
        data = [{"SQL": sql, "SQL Result": processed_data, "Success": True}]
        return ResponseBuilder.create_yaml_json_response(data, data_id)
    
    @staticmethod
    def _format_user_friendly_error(error: Exception, sql: str = None) -> Dict[str, Any]:
        """
        将技术错误转换为用户友好的错误信息
        
        Args:
            error: 原始异常对象
            sql: 相关的SQL语句
            
        Returns:
            包含用户友好错误信息的字典
        """
        error_msg = str(error)
        error_type = type(error).__name__
        
        # 定义错误映射规则 - 基于真实回归测试结果优化
        error_patterns = {
            # API连接相关错误 - BUG-001修复
            "malformed credential config": {
                "message": "API连接配置错误：凭据格式不正确",
                "suggestion": "请检查provider、region、role_arn等参数。阿里云API连接需要正确的角色ARN格式"
            },
            "json.exception.parse_error": {
                "message": "配置解析失败：参数格式错误",
                "suggestion": "请检查所有参数是否为有效的字符串或数值"
            },
            "Compiler internal error": {
                "message": "系统处理失败：请检查参数配置后重试",
                "suggestion": "这通常是由于参数格式不正确导致的，请确认所有必需参数都正确提供"
            },
            "compiler failed to process": {
                "message": "参数处理失败：请检查输入参数的格式和有效性",
                "suggestion": "请确认所有参数符合ClickZetta要求，特别注意凭据和连接配置"
            },
            # 存储连接相关错误
            "endpoint not reachable": {
                "message": "存储连接失败：无法访问指定的存储端点",
                "suggestion": "请检查endpoint地址、网络连接和访问权限"
            },
            "access denied": {
                "message": "访问被拒绝：请检查访问凭据和权限配置",
                "suggestion": "请确认access_key、secret_key等凭据是否正确"
            },
            # 表创建相关错误
            "table already exists": {
                "message": "表已存在",
                "suggestion": "请使用不同的表名或添加IF NOT EXISTS子句"
            },
            "already exists": {
                "message": "对象已存在",
                "suggestion": "请使用不同的名称或添加IF NOT EXISTS子句"
            },
            "unknown table provider": {
                "message": "不支持的外部表连接器类型",
                "suggestion": "ClickZetta外部表仅支持：DELTA格式（OSS/S3上的Delta Lake文件）、HUDI格式（Hudi文件）、KAFKA格式（实时数据流）。不支持MySQL、PostgreSQL等数据库连接器"
            },
            # PIPE和文件相关错误 - BUG-003修复
            "File not found": {
                "message": "Volume中找不到指定文件",
                "suggestion": "请确认文件路径正确，避免使用复杂通配符。建议先用list_files_on_volume工具查看可用文件"
            },
            "No matched file in volume": {
                "message": "Volume中没有匹配的文件",
                "suggestion": "请检查文件路径和格式，确保Volume中存在对应格式的文件用于schema推断"
            },
            "invalid column type": {
                "message": "无效的列类型",
                "suggestion": "请检查列定义中的数据类型是否符合ClickZetta规范"
            },
            # 权限相关错误
            "permission denied": {
                "message": "权限不足：无法执行该操作",
                "suggestion": "请联系管理员获取必要的权限"
            },
            # 语法错误类别
            "syntax error": {
                "message": "SQL语法错误",
                "suggestion": "请检查SQL语句的语法是否正确，或使用 get_product_knowledge 工具获取ClickZetta语法文档"
            },
            "parse error": {
                "message": "SQL解析错误",
                "suggestion": "请检查SQL语句格式，或使用 get_product_knowledge 工具查询正确语法"
            },
            "invalid syntax": {
                "message": "无效的SQL语法",
                "suggestion": "请参考ClickZetta语法文档，或使用 get_product_knowledge 工具获取帮助"
            },
            "unexpected token": {
                "message": "SQL语句中包含意外的关键字或符号",
                "suggestion": "请检查SQL语法，或使用 get_product_knowledge 工具查询ClickZetta支持的语法"
            },
            "unsupported": {
                "message": "使用了不支持的SQL功能或语法",
                "suggestion": "请使用 get_product_knowledge 工具查询ClickZetta支持的功能和替代方案"
            }
        }
        
        # 查找匹配的错误模式
        user_message = "操作失败，请检查输入参数或稍后重试"
        suggestion = "如需帮助，请联系技术支持"
        pattern_matched = False
        
        for pattern, info in error_patterns.items():
            if pattern.lower() in error_msg.lower():
                user_message = info["message"]
                suggestion = info["suggestion"]
                pattern_matched = True
                break
        
        # 如果没有匹配到特定模式，清理后台技术错误信息
        if not pattern_matched:
            cleaned_message = ResponseBuilder._clean_backend_error(error_msg)
            if cleaned_message != error_msg:
                user_message = cleaned_message
                suggestion = "请检查输入参数是否正确，或稍后重试"
        
        # 构造友好的错误响应
        friendly_error = {
            "user_message": user_message,
            "suggestion": suggestion,
            "error_type": error_type,
            "timestamp": datetime.now().isoformat()
        }
        
        return friendly_error
    
    @staticmethod
    def _clean_backend_error(error_msg: str) -> str | None:
        """
        清理后台技术错误信息，移除堆栈跟踪、内存地址等技术细节
        
        Args:
            error_msg: 原始错误信息
            
        Returns:
            清理后的用户友好错误信息
        """
        if not error_msg:
            return None
        
        # 定义需要清理的后台技术信息模式 - 基于真实回归测试结果增强
        cleanup_patterns = [
            # ClickZetta特定backtrace信息 - 来自真实测试
            r'backtrace:\s*\n.*?(?=\n\n|\Z)',  # 完整的backtrace块
            r'\d+\s+0x[0-9a-fA-F]+\s+/cz/coordinator_service/bin/.*?\n',  # backtrace行
            r'/home/jenkins/agent/workspace/.*?\n',  # Jenkins构建路径
            r'\[0x[0-9a-fA-F]+\]\s+/home/jenkins.*?\n',  # 带内存地址的Jenkins路径
            r'_ZN.*?\+0x[0-9a-fA-F]+\)',  # C++ mangled function names
            
            # CZLH错误代码清理 - 保留错误类型和位置信息，只移除重复的FAILED部分
            r'CZLH-\d+\s*FAILED\s*(?=CZLH-\d+)',  # 只移除重复的FAILED关键字
            
            # JSON解析错误详细信息
            r'\[json\.exception\.parse_error\.\d+\].*?while parsing value.*?last read:.*?\'.*?\'',
            
            # 通用技术栈信息
            r'Traceback \(most recent call last\):.*$',
            r'File ".*", line \d+.*$',
            r'    at .*\(.*:\d+:\d+\).*$',
            r'    at .*\..*\(.*\).*$',
            
            # 内存地址和技术ID
            r'0x[0-9a-fA-F]+',  # 十六进制内存地址
            r'\[0x[0-9a-fA-F,\s]+\]',  # 内存地址数组
            r'Object id: [0-9a-fA-F-]+',
            r'Thread-\d+',
            r'Process-\d+',
            
            # Java/C++风格的异常堆栈
            r'Exception in thread ".*?".*$',
            r'Caused by:.*$',
            r'\s+at [a-zA-Z0-9._$]+\(.*?\).*$',
            
            # JSON解析技术细节
            r'json\.exception\.parse_error\.\d+.*?(?=;|$)',
            r'parse error at line \d+, column \d+:.*?(?=;|$)',
            r'last read: \'.*?\'',
            r'syntax error while parsing value.*?(?=;|$)',
            r'expected digit after.*?(?=;|$)',
            
            # 网络和连接技术细节
            r'Connection pool exhausted.*$',
            r'Socket timeout after \d+ ms.*$',
            r'SSL handshake failed.*$',
            
            # 文件系统路径和代码位置
            r'/[a-zA-Z0-9_/.-]+\.jar',
            r'/[a-zA-Z0-9_/.-]+\.class',
            r'C:\\[a-zA-Z0-9_\\.-]+',
            r'at [a-zA-Z0-9._$]+\.java:\d+',
            r'\.java:\d+',
            r'\.py:\d+',
            
            # 其他技术细节
            r'Version: \d+\.\d+\.\d+.*$',
            r'Build: \d+.*$',
            r'Debug info:.*$',
        ]
        
        import re
        cleaned_msg = error_msg
        
        # 逐个应用清理模式
        for pattern in cleanup_patterns:
            cleaned_msg = re.sub(pattern, '', cleaned_msg, flags=re.MULTILINE | re.DOTALL)
        
        # 清理多余的空白和标点
        cleaned_msg = re.sub(r'\s+', ' ', cleaned_msg)  # 多个空格合并为一个
        cleaned_msg = re.sub(r'[\s]*[;,:\s]*$', '', cleaned_msg)  # 移除结尾的标点和空格
        cleaned_msg = re.sub(r'^[\s,;:]+', '', cleaned_msg)  # 移除开头的标点和空格
        cleaned_msg = cleaned_msg.strip()
        
        # 如果清理后为空或过短，返回通用错误信息
        if not cleaned_msg or len(cleaned_msg) < 10:
            return "操作执行失败"
        
        # 限制长度，避免过长的错误信息
        if len(cleaned_msg) > 500:
            cleaned_msg = cleaned_msg[:500] + "..."
        
        # 确保句子结构完整
        if not cleaned_msg.endswith(('.', '!', '?', '。', '！', '？')):
            cleaned_msg += "。"
        
        return cleaned_msg
    
    @staticmethod
    def _clean_error_data(data: Any) -> Any:
        """
        递归清理数据中的错误信息，移除C++堆栈跟踪等技术细节
        
        Args:
            data: 原始数据
            
        Returns:
            清理后的数据
        """
        if isinstance(data, dict):
            cleaned = {}
            for key, value in data.items():
                # 检测错误相关的键
                if key.lower() in ['error', 'error_message', 'detail', 'details', 'reason', 'cause']:
                    if isinstance(value, str):
                        # 清理错误信息
                        cleaned[key] = ResponseBuilder._clean_backend_error(value)
                    else:
                        cleaned[key] = ResponseBuilder._clean_error_data(value)
                elif key.lower() == 'message' and isinstance(value, str):
                    # Bug 2修复: 对于message字段，只有当它看起来像错误消息时才清理
                    if any(error_indicator in value.lower() for error_indicator in ['error', 'failed', 'exception', 'traceback', 'backtrace']):
                        cleaned[key] = ResponseBuilder._clean_backend_error(value)
                    else:
                        # 正常消息不需要清理
                        cleaned[key] = value
                else:
                    cleaned[key] = ResponseBuilder._clean_error_data(value)
            return cleaned
            
        elif isinstance(data, list):
            return [ResponseBuilder._clean_error_data(item) for item in data]
            
        elif isinstance(data, str):
            # 检查是否包含堆栈跟踪特征
            if any(pattern in data for pattern in ['backtrace:', 'stack trace:', '0x', '/home/jenkins/', '_ZN']):
                return ResponseBuilder._clean_backend_error(data)
            return data
            
        else:
            return data
    
    @staticmethod
    def create_error_response(error: Exception, context: str = None, data_id: str = None) -> list[types.TextContent | types.EmbeddedResource]:
        """
        创建纯错误响应，用于操作完全失败的情况

        Args:
            error: 异常对象
            context: 错误上下文（如操作类型）
            data_id: 数据ID，如果为None则自动生成

        Returns:
            包含错误信息的标准响应格式
        """
        if data_id is None:
            data_id = str(uuid.uuid4())

        user_friendly_error = ResponseBuilder._format_user_friendly_error(error, context)
        data = [{"operation": context or "unknown", "error": user_friendly_error, "success": False}]
        return ResponseBuilder.create_yaml_json_response(data, data_id)

    @staticmethod
    def wrap_text_contents_with_config(
        contents: list[types.TextContent | types.EmbeddedResource],
        studio_config=None,
        data_id: str = None,
        additional_user_preferences: dict = None
    ) -> list[types.TextContent | types.EmbeddedResource]:
        """
        将已有的 TextContent/EmbeddedResource 列表与 studio_config 信息结合

        这个方法用于包装从外部库（如 claude-skills-mcp-backend）返回的响应，
        添加 Clickzetta 的用户偏好信息。

        Args:
            contents: 已有的 TextContent 或 EmbeddedResource 列表
            studio_config: StudioConfig对象，用于附加用户偏好信息
            data_id: 可选的数据ID，如果为None则自动生成
            additional_user_preferences: 额外的用户偏好信息字典

        Returns:
            包含原有内容和配置信息的列表
        """
        if not contents:
            return contents

        # 如果没有 studio_config，直接返回原内容
        if studio_config is None:
            return contents

        # 生成 data_id
        if data_id is None:
            data_id = str(uuid.uuid4())

        # 构建用户偏好信息
        user_preferences = {
            "use_region": getattr(studio_config, 'env', '') if studio_config else '',
            "instance_name": getattr(studio_config, 'instance', '') if studio_config else '',
            "instance_id": getattr(studio_config, 'instance_id', 0) if studio_config else 0,
            "workspace_name": getattr(studio_config, 'workspace', '') if studio_config else '',
            "workspace_id": getattr(studio_config, 'workspace_id', 0) if studio_config else 0,
            "vcluster": getattr(studio_config, 'vcluster', '') if studio_config else '',
            "schema": getattr(studio_config, 'schema', '') if studio_config else '',
            "project_id": getattr(studio_config, 'project_id', '') if studio_config else '',
            "user_id": getattr(studio_config, 'user_id', 0) if studio_config else 0,
            "tenant_id": getattr(studio_config, 'tenant_id', 0) if studio_config else 0,
            "username": getattr(studio_config, 'username', '') if studio_config else '',
        }
        
        # 添加额外的用户偏好信息
        if additional_user_preferences:
            user_preferences.update(additional_user_preferences)

        # 创建配置信息的 EmbeddedResource
        config_data = {
            "type": "user_preferences",
            "data_id": data_id,
            "_basic_user_preferences": user_preferences
        }

        config_json = json.dumps(config_data, ensure_ascii=False, default=json_serializer)

        config_resource = types.EmbeddedResource(
            type="resource",
            resource=types.TextResourceContents(
                uri=f"config://{data_id}",
                text=config_json,
                mimeType="application/json"
            ),
        )

        # 返回原内容 + 配置信息
        return list(contents) + [config_resource]

    @staticmethod
    def create_yaml_json_response(data: Any, data_id: str = None, studio_config=None, additional_user_preferences: dict = None) -> list[
        types.TextContent | types.EmbeddedResource]:
        """
        创建标准的YAML+JSON响应格式（优化版）

        Args:
            data: 要输出的数据
            data_id: 数据ID，如果为None则自动生成
            studio_config: StudioConfig对象，用于返回用户偏好信息，为None时不添加
            additional_user_preferences: 额外的用户偏好信息字典

        Returns:
            包含TextContent和EmbeddedResource的列表
        """
        optimized_data = ResponseBuilder._optimize_data(data)

        if isinstance(optimized_data, (str, int, float, bool)):
            return ResponseBuilder.create_text_response(str(optimized_data))

        output = {
            "type": "data",
            "data_id": data_id,
            "data": optimized_data,
        }

        yaml_output = data_to_yaml(output)

        return ResponseBuilder.wrap_text_contents_with_config(contents = [types.TextContent(type="text", text=yaml_output)], studio_config = studio_config, data_id=data_id, additional_user_preferences=additional_user_preferences)

def safe_get_config_attr(config, attr_name, default=None):
    """安全地获取StudioConfig对象的属性"""
    if config is None:
        return default
    return getattr(config, attr_name, default)
