"""
Docker兼容性工具 - 特别针对Windows Docker环境的兼容性处理
"""
import os
import platform
import logging
from pathlib import Path
from typing import List, Optional, Dict, Any

from loguru import logger


def is_windows_docker() -> bool:
    """
    检测是否在Windows Docker环境中运行
    
    Returns:
        True如果在Windows Docker环境中
    """
    # 检查是否在Docker中
    is_docker = (
        os.path.exists('/.dockerenv') or 
        os.environ.get('DOCKER_CONTAINER') or
        os.path.exists('/proc/1/cgroup') and 'docker' in open('/proc/1/cgroup').read()
    )
    
    if not is_docker:
        return False
    
    # 在Docker中，检查是否为Windows主机
    # Windows Docker有一些特殊的环境标识
    windows_indicators = [
        os.environ.get('DOCKER_HOST', '').find('npipe') != -1,  # Windows命名管道
        os.environ.get('DOCKER_BUILDKIT_PROGRESS') == 'plain',  # Windows常见设置
        os.path.exists('/mnt/wsl'),  # WSL2环境
    ]
    
    return any(windows_indicators)


def normalize_path(path: str) -> str:
    """
    标准化路径格式，确保在Windows Docker中正常工作
    
    Args:
        path: 原始路径
        
    Returns:
        标准化后的路径
    """
    if not path:
        return path
        
    # 使用正斜杠作为路径分隔符
    normalized = path.replace('\\', '/')
    
    # 在Windows Docker中，确保绝对路径以正斜杠开始
    if is_windows_docker() and len(normalized) > 1 and normalized[1] == ':':
        # 处理Windows风格的绝对路径 (C:\path -> /c/path)
        drive = normalized[0].lower()
        rest = normalized[2:]
        normalized = f"/{drive}{rest}"
    
    return normalized


def get_docker_friendly_config_paths(filename: str = "connections.json") -> List[str]:
    """
    获取Docker友好的配置文件路径列表，包含Windows Docker特殊处理
    
    Args:
        filename: 配置文件名
        
    Returns:
        按优先级排序的路径列表
    """
    standard_paths = [
        f"/app/.clickzetta/lakehouse_connection/{filename}",  # Docker统一路径
        f"/app/config/lakehouse_connection/{filename}",      # Docker挂载路径
        os.path.expanduser(f"~/.clickzetta/{filename}"),     # 用户主目录
        f"config/lakehouse_connection/{filename}"            # 项目模板
    ]
    
    # Windows Docker特殊路径
    if is_windows_docker():
        windows_paths = [
            f"/mnt/c/Users/{os.getenv('USERNAME', 'user')}/.clickzetta/{filename}",  # WSL2挂载
            f"/app/.clickzetta/{filename}",  # 简化路径
            f"/config/{filename}",  # 简化配置路径
        ]
        standard_paths = windows_paths + standard_paths
    
    # 标准化所有路径
    return [normalize_path(path) for path in standard_paths]


def safe_file_access(filepath: str) -> bool:
    """
    安全的文件访问检查，处理Windows Docker的权限问题
    
    Args:
        filepath: 文件路径
        
    Returns:
        True如果文件可以安全访问
    """
    try:
        normalized_path = normalize_path(filepath)
        
        # 检查文件是否存在
        if not os.path.exists(normalized_path):
            return False
            
        # 检查是否为文件
        if not os.path.isfile(normalized_path):
            return False
        
        # 尝试读取权限检查
        return os.access(normalized_path, os.R_OK)
        
    except Exception as e:
        logger.debug(f"文件访问检查失败 {filepath}: {e}")
        return False


def safe_directory_create(dirpath: str) -> bool:
    """
    安全的目录创建，处理Windows Docker的权限问题
    
    Args:
        dirpath: 目录路径
        
    Returns:
        True如果目录创建成功或已存在
    """
    try:
        normalized_path = normalize_path(dirpath)
        
        # 使用pathlib创建目录，更好的跨平台兼容性
        Path(normalized_path).mkdir(parents=True, exist_ok=True)
        
        return True
        
    except Exception as e:
        logger.warning(f"目录创建失败 {dirpath}: {e}")
        return False


def get_windows_docker_debug_info() -> Dict[str, Any]:
    """
    获取Windows Docker环境的调试信息
    
    Returns:
        调试信息字典
    """
    return {
        "platform": platform.system(),
        "is_docker": os.path.exists('/.dockerenv'),
        "is_windows_docker": is_windows_docker(),
        "docker_host": os.environ.get('DOCKER_HOST', ''),
        "user": os.environ.get('USER', os.environ.get('USERNAME', '')),
        "home": os.path.expanduser('~'),
        "cwd": os.getcwd(),
        "path_exists_checks": {
            "/.dockerenv": os.path.exists('/.dockerenv'),
            "/mnt/wsl": os.path.exists('/mnt/wsl'),
            "/app": os.path.exists('/app'),
            "/app/.clickzetta": os.path.exists('/app/.clickzetta'),
        },
        "env_vars": {
            k: v for k, v in os.environ.items() 
            if 'DOCKER' in k or 'WSL' in k or 'PATH' in k
        }
    }


def create_safe_connection_manager():
    """
    创建一个安全的连接管理器，处理Windows Docker环境的特殊情况
    
    Returns:
        ConnectionManager实例或None（如果创建失败）
    """
    try:
        from ..connection_manager import ConnectionManager
        
        # 在Windows Docker环境中，尝试使用更健壮的初始化
        if is_windows_docker():
            logger.info("检测到Windows Docker环境，使用增强初始化")
            
            # 获取调试信息
            debug_info = get_windows_docker_debug_info()
            logger.debug(f"Windows Docker环境信息: {debug_info}")
            
            # 尝试找到可用的配置文件
            config_paths = get_docker_friendly_config_paths()
            config_file = None
            
            for path in config_paths:
                if safe_file_access(path):
                    config_file = path
                    logger.info(f"在Windows Docker环境中找到配置文件: {path}")
                    break
                else:
                    logger.debug(f"配置文件不可访问: {path}")
            
            # 使用找到的配置文件创建连接管理器
            return ConnectionManager(config_file)
        else:
            # 标准初始化
            return ConnectionManager()
            
    except Exception as e:
        logger.error(f"创建连接管理器失败: {e}")
        logger.error("这可能是由于以下原因之一:")
        logger.error("1. 配置文件路径问题")
        logger.error("2. 文件权限问题")
        logger.error("3. Windows Docker环境特殊性")
        
        if is_windows_docker():
            debug_info = get_windows_docker_debug_info()
            logger.error(f"Windows Docker调试信息: {debug_info}")
        
        return None


def log_docker_environment_info():
    """记录Docker环境信息用于调试"""
    logger.info(f"Docker环境检测:")
    logger.info(f"  - 是否在Docker中: {os.path.exists('/.dockerenv')}")
    logger.info(f"  - 是否Windows Docker: {is_windows_docker()}")
    logger.info(f"  - 平台: {platform.system()}")
    logger.info(f"  - 工作目录: {os.getcwd()}")
    logger.info(f"  - 用户主目录: {os.path.expanduser('~')}")
    
    if is_windows_docker():
        debug_info = get_windows_docker_debug_info()
        logger.info(f"  - Windows Docker详细信息: {debug_info}")