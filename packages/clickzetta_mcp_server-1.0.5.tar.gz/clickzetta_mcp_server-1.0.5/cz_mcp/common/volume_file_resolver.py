"""
Volume文件解析器
用于处理create_knowledge_base中的documents_source_path通配符和模式匹配
"""

import logging
from typing import List, Dict, Any, Optional, Tuple
from .wildcard_utils import (
    contains_wildcard, 
    contains_regex_pattern, 
    get_volume_list_sql,
    convert_wildcard_to_regex
)

from loguru import logger


class VolumeFileResolver:
    """Volume文件解析器 - 处理通配符模式和文件路径解析"""
    
    def __init__(self, db_connection):
        """
        初始化文件解析器
        
        Args:
            db_connection: 数据库连接对象
        """
        self.db = db_connection
    
    def resolve_file_paths(self, volume_name: str, documents_source_path: str) -> Tuple[List[str], Dict[str, Any]]:
        """
        解析文件路径，支持通配符和正则表达式
        
        Args:
            volume_name: Volume名称
            documents_source_path: 文档源路径（可能包含通配符）
            
        Returns:
            Tuple[List[str], Dict[str, Any]]: (文件路径列表, 解析详情)
        """
        logger.info(f"开始解析Volume文件路径: {volume_name}/{documents_source_path}")
        
        # 检查是否包含通配符或正则表达式
        has_wildcard = contains_wildcard(documents_source_path)
        has_regex = contains_regex_pattern(documents_source_path)
        
        resolve_details = {
            "volume_name": volume_name,
            "original_path": documents_source_path,
            "has_wildcard": has_wildcard,
            "has_regex": has_regex,
            "resolution_method": "unknown"
        }
        
        if has_wildcard or has_regex:
            # 使用模式匹配方法
            return self._resolve_with_pattern_matching(volume_name, documents_source_path, resolve_details)
        else:
            # 使用直接路径方法
            return self._resolve_with_direct_path(volume_name, documents_source_path, resolve_details)
    
    def _resolve_with_pattern_matching(self, volume_name: str, pattern: str, resolve_details: Dict[str, Any]) -> Tuple[List[str], Dict[str, Any]]:
        """
        使用模式匹配解析文件路径
        
        Args:
            volume_name: Volume名称
            pattern: 模式字符串
            resolve_details: 解析详情
            
        Returns:
            Tuple[List[str], Dict[str, Any]]: (文件路径列表, 解析详情)
        """
        resolve_details["resolution_method"] = "pattern_matching"
        
        try:
            # 生成LIST VOLUME REGEXP查询
            sql = get_volume_list_sql(volume_name, pattern)
            resolve_details["sql_executed"] = sql
            
            logger.info(f"执行模式匹配查询: {sql}")
            
            # 执行查询
            data, data_id = self.db.execute_query(sql)
            resolve_details["query_data_id"] = data_id
            
            # 解析查询结果
            file_paths = self._extract_file_paths_from_result(data, resolve_details)
            
            resolve_details["files_found"] = len(file_paths)
            resolve_details["pattern_used"] = convert_wildcard_to_regex(pattern) if contains_wildcard(pattern) else pattern
            
            logger.info(f"模式匹配找到 {len(file_paths)} 个文件")
            
            if not file_paths:
                logger.warning(f"模式 '{pattern}' 在Volume '{volume_name}' 中未找到匹配文件")
                resolve_details["warning"] = f"模式 '{pattern}' 未找到匹配文件"
            
            return file_paths, resolve_details
            
        except Exception as e:
            logger.error(f"模式匹配查询失败: {e}")
            resolve_details["error"] = str(e)
            resolve_details["error_type"] = "pattern_matching_failed"
            return [], resolve_details
    
    def _resolve_with_direct_path(self, volume_name: str, path: str, resolve_details: Dict[str, Any]) -> Tuple[List[str], Dict[str, Any]]:
        """
        使用直接路径解析（无通配符）
        
        Args:
            volume_name: Volume名称
            path: 直接文件路径
            resolve_details: 解析详情
            
        Returns:
            Tuple[List[str], Dict[str, Any]]: (文件路径列表, 解析详情)
        """
        resolve_details["resolution_method"] = "direct_path"
        
        try:
            # 🔧 修复：使用修复后的get_volume_list_sql函数生成正确的SQL
            from .wildcard_utils import get_volume_list_sql
            
            sql = get_volume_list_sql(volume_name, path)
            
            # 推断目标类型以用于后续处理
            if path == "." or path == "":
                resolve_details["target_type"] = "list_all"
            elif path.endswith('/') or ('.' not in path.split('/')[-1]):
                resolve_details["target_type"] = "directory"
            else:
                resolve_details["target_type"] = "file"
            
            resolve_details["sql_executed"] = sql
            logger.info(f"执行直接路径查询: {sql}")
            
            # 执行查询
            data, data_id = self.db.execute_query(sql)
            resolve_details["query_data_id"] = data_id
            
            # 解析查询结果
            file_paths = self._extract_file_paths_from_result(data, resolve_details)
            resolve_details["files_found"] = len(file_paths)
            
            if resolve_details["target_type"] == "file":
                # 🔧 修复：具体文件名现在使用REGEXP查询，直接返回查询到的文件
                if file_paths:
                    logger.info(f"文件存在验证成功: 找到 {len(file_paths)} 个匹配文件")
                    return file_paths, resolve_details
                else:
                    logger.warning(f"文件 '{path}' 在Volume '{volume_name}' 中不存在")
                    resolve_details["warning"] = f"文件 '{path}' 不存在"
                    return [], resolve_details
            elif resolve_details["target_type"] == "list_all":
                # 🔧 修复：列出所有文件（"." 或 空字符串）
                logger.info(f"列出Volume中所有文件: 找到 {len(file_paths)} 个文件")
                return file_paths, resolve_details
            elif resolve_details["target_type"] == "directory":
                # 目录，返回找到的所有文件
                logger.info(f"目录 '{path}' 中找到 {len(file_paths)} 个文件")
                return file_paths, resolve_details
            else:
                # 其他情况
                if file_paths:
                    return file_paths, resolve_details
                else:
                    logger.warning(f"路径 '{path}' 在Volume '{volume_name}' 中未找到匹配内容")
                    resolve_details["warning"] = f"路径 '{path}' 未找到匹配内容"
                    return [], resolve_details
                
        except Exception as e:
            logger.error(f"直接路径查询失败: {e}")
            resolve_details["error"] = str(e)
            resolve_details["error_type"] = "direct_path_failed"
            return [], resolve_details
    
    def _extract_file_paths_from_result(self, query_result: Any, resolve_details: Dict[str, Any]) -> List[str]:
        """
        从查询结果中提取文件路径
        
        Args:
            query_result: 查询结果
            resolve_details: 解析详情（用于记录调试信息）
            
        Returns:
            List[str]: 文件路径列表
        """
        file_paths = []
        
        try:
            if query_result is None:
                resolve_details["result_analysis"] = "query_result_is_none"
                return file_paths
            
            # 处理不同类型的查询结果
            if hasattr(query_result, 'empty') and not query_result.empty:
                # pandas DataFrame
                resolve_details["result_type"] = "pandas_dataframe"
                resolve_details["result_shape"] = query_result.shape
                
                # 尝试不同的列名
                path_columns = ['relative_path', 'path', 'file_path', 'name', 'filename']
                for col in path_columns:
                    if col in query_result.columns:
                        file_paths = query_result[col].tolist()
                        resolve_details["path_column_used"] = col
                        break
                
                if not file_paths and len(query_result.columns) > 0:
                    # 使用第一列作为路径
                    first_col = query_result.columns[0]
                    file_paths = query_result[first_col].tolist()
                    resolve_details["path_column_used"] = first_col
                    resolve_details["fallback_to_first_column"] = True
                
            elif isinstance(query_result, list) and len(query_result) > 0:
                # List类型
                resolve_details["result_type"] = "list"
                resolve_details["result_length"] = len(query_result)
                
                for item in query_result:
                    if isinstance(item, dict):
                        # 字典项：尝试不同的键名
                        for key in ['relative_path', 'path', 'file_path', 'name', 'filename']:
                            if key in item:
                                file_paths.append(item[key])
                                break
                        else:
                            # 如果没有找到标准键，使用第一个字符串值
                            for value in item.values():
                                if isinstance(value, str) and value.strip():
                                    file_paths.append(value)
                                    break
                    elif isinstance(item, str):
                        # 字符串项：直接使用
                        file_paths.append(item)
            
            else:
                resolve_details["result_analysis"] = f"unsupported_result_type: {type(query_result)}"
            
            # 清理文件路径（移除空值和重复项）
            file_paths = [path.strip() for path in file_paths if path and str(path).strip()]
            file_paths = list(dict.fromkeys(file_paths))  # 去重但保持顺序
            
            resolve_details["extracted_files_count"] = len(file_paths)
            
            # 记录前几个文件路径作为样例
            if file_paths:
                resolve_details["sample_files"] = file_paths[:5]
            
        except Exception as e:
            logger.error(f"提取文件路径时出错: {e}")
            resolve_details["extraction_error"] = str(e)
        
        return file_paths