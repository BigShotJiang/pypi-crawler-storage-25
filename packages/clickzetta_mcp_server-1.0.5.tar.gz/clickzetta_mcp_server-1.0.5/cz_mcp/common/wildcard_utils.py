"""
通配符和正则表达式工具
用于处理documents_source_path中的通配符模式
"""

import os
import re
import fnmatch
from typing import List, Tuple


def contains_wildcard(path: str) -> bool:
    """
    检测路径是否包含通配符
    
    Args:
        path: 文件路径
        
    Returns:
        bool: 是否包含通配符
    """
    wildcard_patterns = ['*', '?', '[', ']', '{', '}', '**']
    return any(pattern in path for pattern in wildcard_patterns)


def contains_regex_pattern(path: str) -> bool:
    """
    检测路径是否包含正则表达式模式（而非普通文件名中的特殊字符）
    只检测明显的正则表达式模式，避免误判普通文件名
    
    Args:
        path: 文件路径模式
        
    Returns:
        bool: 是否包含正则表达式模式
    """
    # 只检测明显的正则表达式模式组合，不检测单个字符
    regex_patterns = ['.+', '.*', '\\d', '\\w', '\\s']
    return any(pattern in path for pattern in regex_patterns)


def convert_wildcard_to_regex(wildcard_pattern: str) -> str:
    """
    将通配符模式转换为正则表达式
    
    支持的通配符模式:
    - *.md -> .*\\.md$
    - **/*.md -> .*\\.md$
    - docs/*.md -> docs/.*\\.md$
    - *.{md,txt} -> .*\\.(md|txt)$
    
    Args:
        wildcard_pattern: 通配符模式
        
    Returns:
        str: 正则表达式字符串
    """
    pattern = wildcard_pattern
    
    # 处理双星号 **/ 
    pattern = pattern.replace('**/', '')  # **/ 表示递归，在Volume中等同于不限制目录层级
    
    # 处理 {ext1,ext2} 模式（在转义之前处理）
    brace_pattern = r'\{([^}]+)\}'
    def replace_braces(match):
        options = match.group(1).split(',')
        return '(' + '|'.join(opt.strip() for opt in options) + ')'
    
    pattern = re.sub(brace_pattern, replace_braces, pattern)
    
    # 转义正则表达式特殊字符（但保留我们要处理的通配符）
    # 先替换通配符为临时标记，然后转义，再恢复
    pattern = pattern.replace('*', '___STAR___')
    pattern = pattern.replace('?', '___QUESTION___')
    
    # 转义其他正则表达式特殊字符
    pattern = re.escape(pattern)
    
    # 恢复通配符为正则表达式
    pattern = pattern.replace('___STAR___', '.*')  # * -> .*
    pattern = pattern.replace('___QUESTION___', '.')   # ? -> .
    
    # 处理已经处理过的括号组（不需要转义）
    pattern = pattern.replace('\\(', '(').replace('\\)', ')')
    pattern = pattern.replace('\\|', '|')
    
    # 确保是完整匹配（添加锚点）
    if not pattern.endswith('$'):
        pattern = pattern + '$'
    
    return pattern


def convert_glob_to_regex(glob_pattern: str) -> str:
    """
    使用fnmatch将glob模式转换为正则表达式
    这是一个更标准的转换方法
    
    Args:
        glob_pattern: glob模式
        
    Returns:
        str: 正则表达式字符串
    """
    return fnmatch.translate(glob_pattern)


def escape_filename_for_regexp(filename: str) -> str:
    """
    为文件名创建精确的正则表达式转义
    专门处理Volume文件名中的特殊字符，避免过度转义
    
    Args:
        filename: 原始文件名
        
    Returns:
        str: 转义后的正则表达式模式
    """
    # 需要转义的正则表达式特殊字符
    # 注意：不包括单引号，因为它不是正则表达式特殊字符
    special_chars = {
        '.': r'\.',
        '^': r'\^', 
        '$': r'\$',
        '*': r'\*',
        '+': r'\+',
        '?': r'\?',
        '(': r'\(',
        ')': r'\)',
        '[': r'\[',
        ']': r'\]',
        '{': r'\{',
        '}': r'\}',
        '|': r'\|',
        '\\': r'\\'
    }
    
    # 手动转义，避免re.escape的过度转义
    escaped = ''
    for char in filename:
        if char in special_chars:
            escaped += special_chars[char]
        else:
            escaped += char
    
    return escaped


def get_volume_list_sql(volume_name: str, pattern: str) -> str:
    """
    根据模式生成LIST VOLUME SQL查询
    
    Args:
        volume_name: Volume名称
        pattern: 文件模式（通配符、正则表达式、目录路径或具体文件名）
        
    Returns:
        str: SQL查询语句
    """
    if contains_wildcard(pattern) or contains_regex_pattern(pattern):
        # 转换为正则表达式模式
        if contains_regex_pattern(pattern):
            # 已经是正则表达式，直接使用
            regex_pattern = pattern
        else:
            # 转换通配符为正则表达式
            regex_pattern = convert_wildcard_to_regex(pattern)
        
        return f"LIST VOLUME {volume_name} REGEXP = '{regex_pattern}'"
    else:
        # 没有通配符的情况：需要区分目录和文件名
        # 🔧 修复：正确处理不同类型的路径
        
        if pattern == "." or pattern == "":
            # 特殊情况：列出根目录所有文件
            return f"LIST VOLUME {volume_name}"
        elif pattern == "/":
            # 特殊情况：根目录斜杠，等同于列出所有文件
            return f"LIST VOLUME {volume_name}"
        elif pattern.endswith('/') or (not os.path.basename(pattern).count('.')):
            # 目录路径：以/结尾 或 最后一部分没有扩展名（启发式判断）
            dir_path = pattern.rstrip('/')  # 移除尾随斜杠
            if dir_path == "":  # 如果移除斜杠后为空，说明是根目录
                return f"LIST VOLUME {volume_name}"
            return f"LIST VOLUME {volume_name} SUBDIRECTORY '{dir_path}'"
        else:
            # 🔧 关键修复：具体文件名不能使用SUBDIRECTORY语法
            # 对于具体文件名，使用REGEXP进行精确匹配
            # 使用增强的转义逻辑处理特殊字符
            escaped_pattern = escape_filename_for_regexp(pattern) + '$'
            return f"LIST VOLUME {volume_name} REGEXP = '{escaped_pattern}'"


def test_pattern_conversion():
    """测试通配符转换逻辑"""
    import logging
    from loguru import logger
    
    test_cases = [
        ("*.md", ".*\\.md$"),
        ("**/*.md", ".*\\.md$"),
        ("docs/*.md", "docs/.*\\.md$"),
        ("*.{md,txt}", ".*\\.(md|txt)$"),
        ("data/**/*.{json,yaml}", "data/.*\\.(json|yaml)$"),
        ("test_*.py", "test_.*\\.py$"),
        ("file?.txt", "file.\\.txt$")
    ]
    
    logger.info("🧪 通配符转换测试:")
    for wildcard, expected in test_cases:
        actual = convert_wildcard_to_regex(wildcard)
        status = "✅" if expected in actual or actual == expected else "❌"
        logger.info(f"   {status} {wildcard} -> {actual}")
    
    logger.info("\n🧪 特殊字符文件名转义测试:")
    special_files = [
        "file with spaces.txt",
        "file'with'quotes.md", 
        "file(with)parentheses.json",
        "file[with]brackets.yaml",
        "file{with}braces.xml",
        "file$with$dollar.log",
        "file^with^caret.txt",
        "file+with+plus.py",
        "file|with|pipe.sh",
        "file\\with\\backslash.conf"
    ]
    
    for filename in special_files:
        escaped = escape_filename_for_regexp(filename)
        logger.info(f"   '{filename}' -> '{escaped}'")
    
    logger.info("\n🧪 SQL生成测试:")
    volume = "test_volume"
    patterns = ["*.md", "docs/*.txt", "regular_file.json", "file with spaces.txt", "file'quote.md"]
    
    for pattern in patterns:
        sql = get_volume_list_sql(volume, pattern)
        logger.info(f"   '{pattern}' -> {sql}")


if __name__ == "__main__":
    test_pattern_conversion()