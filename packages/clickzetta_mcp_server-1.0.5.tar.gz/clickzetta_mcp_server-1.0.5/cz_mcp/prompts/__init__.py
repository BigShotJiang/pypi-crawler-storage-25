"""
MCP Prompts Package

All prompts are organized into separate files for easier maintenance.
This file aggregates all prompts and provides a unified access interface.
"""
from .system_prompt import CZ_SYSTEM_PROMPT

# Unified PROMPTS registry
PROMPTS = {
    "cz_system_prompt": CZ_SYSTEM_PROMPT,
}

__all__ = ['PROMPTS']
