 # MCP ClickZetta Server Service Manager
 
 ## Usage:

$   ./service.sh start [--host HOST] [--port PORT] 

$   ./service.sh stop

$   ./service.sh restart [--host HOST] [--port PORT]

$   ./service.sh status

$   ./service.sh reinstall

$    ./service.sh logs [--tail N]

## Examples:
```bash


./service.sh start                    # Start with defaults
./service.sh start --port 8080        # Start on port 8080
./service.sh stop                     # Stop the service
./service.sh restart                  # Restart the service
./service.sh status                   # Check service status
./service.sh logs --tail 50           # Show last 50 log lines
./service.sh logs -f                  # use follow mode
```

## stdio mcp

Configure stdio MCP for your local agent by adding the following to your agent configuration:
```json
  {
    "mcpServers": {
      "clickzetta-studio-mcp-local-stdio": {
        "type": "stdio",
        "command": "/Users/zhanglin/PycharmProjects/claude-skills-mcp/cz-mcp-server/.venv/bin/python",
        "args": [
          "-m",
          "cz_mcp.run_stdio_server",
           "CZ_MCP_TRANSPORT=stdio",
          "CZ_MCP_LOG_TO_FILE=0",
          "x-Lakehouse-Username=xxx",
          "x-Lakehouse-Password=xxx",
          "x-Lakehouse-Service=uat-api.clickzetta.com",
          "x-Lakehouse-Instance=xxx",
          "x-Lakehouse-Workspace=xxx",
          "x-Lakehouse-Schema=public",
          "x-Lakehouse-VCluster=DEFAULT"
        ]
      }
    }
  }
···