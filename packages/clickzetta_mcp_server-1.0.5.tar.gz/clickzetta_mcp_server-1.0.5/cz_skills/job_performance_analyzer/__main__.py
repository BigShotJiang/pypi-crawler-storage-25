#!/usr/bin/env python3
"""
Clickzetta Job 性能分析工具 - 命令行入口

使用方法:
    cz-analyze-job <plan.json> <job_profile.json> [options]
    cz-analyze-job --job-dir /path/to/job_directory [options]
    cz-analyze-job --compare /path/to/job_a /path/to/job_b

示例:
    # 使用 job 目录（自动发现所有文件）
    cz-analyze-job --job-dir /path/to/202603302022081304091991

    # 对比两个 job
    cz-analyze-job --compare /path/to/job_a /path/to/job_b

    # 基本分析
    cz-analyze-job plan.json job_profile.json

    # 指定输出目录
    cz-analyze-job plan.json job_profile.json -o ./output
"""
import sys
import os
import argparse
import logging

logger = logging.getLogger(__name__)

def main():
    """命令行入口函数"""
    from .analyze_job import analyze_job, print_header, resolve_job_dir

    parser = argparse.ArgumentParser(
        description='Clickzetta Job 性能分析工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 使用 job 目录
  cz-analyze-job --job-dir /path/to/202603302022081304091991

  # 对比两个 job（目录或 job_profile.json）
  cz-analyze-job --compare /path/to/job_a /path/to/job_b

  # 基本分析
  cz-analyze-job plan.json job_profile.json

  # 启用状态表优化分析
  cz-analyze-job plan.json job_profile.json --enable-state-table
        """
    )

    parser.add_argument('plan_file', nargs='?', help='plan.json 文件路径（可选）')
    parser.add_argument('profile_file', nargs='?', help='job_profile.json 文件路径（可选，也可通过 --profile 指定）')
    parser.add_argument('--compare', nargs=2, metavar=('JOB_A', 'JOB_B'),
                       help='对比两个 job，参数为两个 job 目录或 job_profile.json 路径')
    parser.add_argument('--job-dir', '-d', dest='job_dir',
                       help='Job 目录路径，自动发现文件')
    parser.add_argument('--profile', '-p', dest='profile_file_opt',
                       help='job_profile.json 文件路径（可选，替代位置参数）')
    parser.add_argument('-o', '--output', dest='output_dir', default='.',
                       help='输出目录（默认: 当前目录）')
    parser.add_argument('--enable-state-table', action='store_true',
                       help='启用状态表优化分析（默认禁用）')

    args = parser.parse_args()

    # === 对比模式 ===
    if args.compare:
        from .compare_jobs import compare_jobs

        def _resolve_job(path):
            """返回 (profile_file, stats_file)"""
            if os.path.isdir(path):
                resolved = resolve_job_dir(path)
                if not resolved['profile_file']:
                    sys.stderr.write(f"错误: 目录中未找到 job_profile.json - {path}\n")
                    sys.exit(1)
                # 查找 stats_summary.json
                stats = ''
                for base in ['stats_summary.json.gz', 'stats_summary.json']:
                    for root, _, files in os.walk(path):
                        if base in files:
                            stats = os.path.join(root, base)
                            break
                    if stats:
                        break
                return resolved['profile_file'], stats
            return path, ''

        pa, sa = _resolve_job(args.compare[0])
        pb, sb = _resolve_job(args.compare[1])
        logger.info(compare_jobs(pa, pb, sa, sb))
        return

    # === 正常分析模式 ===
    extra_files = {}

    if args.job_dir:
        resolved = resolve_job_dir(args.job_dir)
        plan_file = resolved['plan_file']
        profile_file = resolved['profile_file']
        extra_files = resolved['extra_files']
    else:
        plan_file = args.plan_file or ''
        if args.profile_file_opt:
            profile_file = args.profile_file_opt
        else:
            profile_file = args.profile_file or ''

    if not plan_file and not profile_file:
        sys.stderr.write("错误: 至少需要提供 plan.json 或 job_profile.json 之一（或使用 --job-dir）\n")
        sys.stderr.write("使用 --help 查看帮助信息\n")
        sys.exit(1)

    if plan_file and not os.path.exists(plan_file):
        sys.stderr.write(f"错误: 文件不存在 - {plan_file}\n")
        sys.exit(1)
    if profile_file and not os.path.exists(profile_file):
        sys.stderr.write(f"错误: 文件不存在 - {profile_file}\n")
        sys.exit(1)

    print_header()
    analyze_job(plan_file, profile_file, args.output_dir, args.enable_state_table,
                extra_files=extra_files)

if __name__ == '__main__':
    main()
