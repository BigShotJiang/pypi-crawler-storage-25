#!/usr/bin/env python3
"""Job 对比分析 — 定位两次相同 SQL 执行的耗时差异"""
import json
import os
from typing import Dict, List, Tuple


def _load_profile(profile_file: str) -> Dict:
    """加载 job_profile.json 并返回 jobSummary"""
    with open(profile_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    raw = data.get('data', data)
    return raw


def _get_job_id(raw_profile: Dict) -> str:
    """从 profile 中提取 jobId"""
    for key in ('jobStatus', 'jobDesc'):
        jid = raw_profile.get(key, {}).get('jobId', {})
        if isinstance(jid, dict) and jid.get('id'):
            return jid['id']
        if isinstance(jid, str) and jid:
            return jid
    return 'unknown'


def _load_stats(stats_file: str) -> Dict:
    """加载 stats_summary.json"""
    if not stats_file or not os.path.exists(stats_file):
        return {}
    with open(stats_file, 'r', encoding='utf-8') as f:
        return json.load(f)


def _stage_elapsed(stage: Dict) -> int:
    s, e = int(stage.get('startTime', 0)), int(stage.get('endTime', 0))
    return max(0, e - s)


def _parse_sum(value_str: str) -> float:
    """从 'min/max/avg/sum' 或 '[min/max/avg/sum]' 格式中提取 sum"""
    parts = value_str.strip('[] ').split('/')
    if len(parts) >= 4:
        try:
            return float(parts[3])
        except ValueError:
            pass
    return 0.0


def _parse_max(value_str: str) -> float:
    """提取 max（第2个字段）"""
    parts = value_str.strip('[] ').split('/')
    if len(parts) >= 2:
        try:
            return float(parts[1])
        except ValueError:
            pass
    return 0.0


def _parse_avg(value_str: str) -> float:
    """提取 avg（第3个字段）"""
    parts = value_str.strip('[] ').split('/')
    if len(parts) >= 3:
        try:
            return float(parts[2])
        except ValueError:
            pass
    return 0.0


def _normalize_stage_key(stage_key: str) -> str:
    """'stg0 plan dop(1396)' -> 'stg0'"""
    return stage_key.split()[0] if ' ' in stage_key else stage_key


def compare_jobs(profile_a: str, profile_b: str,
                 stats_a: str = '', stats_b: str = '') -> str:
    """
    对比两个 job，输出耗时差异最大的 stage / operator / pipeline。

    Args:
        profile_a, profile_b: job_profile.json 路径
        stats_a, stats_b: stats_summary.json 路径（可选）
    """
    ja = _load_profile(profile_a)
    jb = _load_profile(profile_b)
    id_a = _get_job_id(ja)
    id_b = _get_job_id(jb)
    sa = ja.get('jobSummary', ja).get('stageSummary', {})
    sb = jb.get('jobSummary', jb).get('stageSummary', {})

    # 确保 A 是运行时间短的，B 是运行时间长的
    def _total_elapsed(stages):
        starts = [int(s['startTime']) for s in stages.values() if s.get('startTime')]
        ends = [int(s['endTime']) for s in stages.values() if s.get('endTime')]
        return (max(ends) - min(starts)) if starts and ends else 0

    if _total_elapsed(sa) > _total_elapsed(sb):
        sa, sb = sb, sa
        id_a, id_b = id_b, id_a
        stats_a, stats_b = stats_b, stats_a

    # 加载 stats_summary，按 stage_id 索引
    def _index_stats(raw: Dict) -> Dict:
        out = {}
        for key, val in raw.items():
            out[_normalize_stage_key(key)] = val
        return out

    stats_a_data = _index_stats(_load_stats(stats_a))
    stats_b_data = _index_stats(_load_stats(stats_b))

    lines = []

    # === 1. Job 总耗时 ===
    def _job_elapsed(stages: Dict) -> int:
        starts = [int(s['startTime']) for s in stages.values() if s.get('startTime')]
        ends = [int(s['endTime']) for s in stages.values() if s.get('endTime')]
        if not starts or not ends:
            return 0
        return max(ends) - min(starts)

    total_a = _job_elapsed(sa)
    total_b = _job_elapsed(sb)
    diff_total = total_b - total_a
    lines.append(f"Job A: {id_a}")
    lines.append(f"Job B: {id_b}")
    lines.append(f"Job 总耗时: A={total_a/1000:.1f}s  B={total_b/1000:.1f}s  差异={diff_total/1000:+.1f}s")
    lines.append("")

    # === 执行计划差异检测 ===
    warnings = []
    stages_a_only = set(sa.keys()) - set(sb.keys())
    stages_b_only = set(sb.keys()) - set(sa.keys())
    if stages_a_only or stages_b_only:
        warnings.append(f"Stage 数量不一致: A={len(sa)} 个, B={len(sb)} 个"
                        f"（A 独有: {sorted(stages_a_only) if stages_a_only else '无'}, "
                        f"B 独有: {sorted(stages_b_only) if stages_b_only else '无'}）")

    common_stages = set(sa.keys()) & set(sb.keys())
    dop_diffs = []
    row_diffs = []
    for sid in sorted(common_stages):
        tc_a = sa[sid].get('taskCount', len(sa[sid].get('taskSummary', {})))
        tc_b = sb[sid].get('taskCount', len(sb[sid].get('taskSummary', {})))
        if tc_a != tc_b:
            dop_diffs.append(f"{sid}({tc_a}→{tc_b})")

        rows_a = int(sa[sid].get('inputOutputStats', {}).get('inputRowCount', 0))
        rows_b = int(sb[sid].get('inputOutputStats', {}).get('inputRowCount', 0))
        if rows_a > 0 and rows_b > 0:
            ratio = max(rows_a, rows_b) / min(rows_a, rows_b)
            if ratio > 2:
                row_diffs.append(f"{sid}({rows_a:,}→{rows_b:,}, {ratio:.1f}x)")

    if dop_diffs:
        warnings.append(f"并发度不一致: {', '.join(dop_diffs[:10])}"
                        f"{'...' if len(dop_diffs) > 10 else ''}")
    if row_diffs:
        warnings.append(f"数据量差异较大(>2x): {', '.join(row_diffs[:10])}"
                        f"{'...' if len(row_diffs) > 10 else ''}")

    if warnings:
        lines.append("⚠️  执行计划差异警告（对比结果可能不具参考性）:")
        for w in warnings:
            lines.append(f"  • {w}")
        lines.append("")

    # === 2. Stage 对比 ===
    all_stages = sorted(set(list(sa.keys()) + list(sb.keys())),
                        key=lambda s: int(s.replace('stg', '')) if s.replace('stg', '').isdigit() else 0)

    stage_diffs: List[Tuple[str, int, int, int]] = []
    for sid in all_stages:
        ea = _stage_elapsed(sa[sid]) if sid in sa else 0
        eb = _stage_elapsed(sb[sid]) if sid in sb else 0
        stage_diffs.append((sid, ea, eb, eb - ea))

    stage_diffs.sort(key=lambda x: abs(x[3]), reverse=True)
    job_diff_abs = max(abs(diff_total), 1)

    lines.append("=" * 80)
    lines.append("Stage 耗时对比（按差异排序）")
    lines.append("=" * 80)
    lines.append(f"{'Stage':<10}{'A(s)':>10}{'B(s)':>10}{'差异(s)':>10}{'变化':>10}")
    lines.append("-" * 50)
    for sid, ea, eb, diff in stage_diffs:
        if abs(diff) < job_diff_abs * 0.05:
            break
        pct = f"{diff/ea*100:+.0f}%" if ea > 0 else "N/A"
        lines.append(f"{sid:<10}{ea/1000:>10.1f}{eb/1000:>10.1f}{diff/1000:>+10.1f}{pct:>10}")

    # === 3. Operator + Pipeline 下钻 ===
    top_diff_stages = [(s, e1, e2, d) for s, e1, e2, d in stage_diffs
                       if abs(d) >= job_diff_abs * 0.05][:5]

    for sid, ea, eb, diff in top_diff_stages:
        if sid not in sa or sid not in sb:
            continue

        # --- Operator 对比 (from job_profile) ---
        ops_a = sa[sid].get('operatorSummary', {})
        ops_b = sb[sid].get('operatorSummary', {})
        if ops_a or ops_b:
            all_ops = sorted(set(list(ops_a.keys()) + list(ops_b.keys())))
            op_diffs = []
            for op_name in all_ops:
                oa = ops_a.get(op_name, {})
                ob = ops_b.get(op_name, {})
                wt_a = oa.get('wallTimeNs', {})
                wt_b = ob.get('wallTimeNs', {})
                max_a = int(wt_a.get('max', 0))
                max_b = int(wt_b.get('max', 0))
                avg_a = int(wt_a.get('avg', 0))
                avg_b = int(wt_b.get('avg', 0))
                rows_a = int(oa.get('inputOutputStats', {}).get('inputRowCount', 0))
                rows_b = int(ob.get('inputOutputStats', {}).get('inputRowCount', 0))
                max_diff = max_b - max_a
                op_diffs.append((op_name, max_a, max_b, max_diff, avg_a, avg_b, rows_a, rows_b))

            op_diffs.sort(key=lambda x: abs(x[3]), reverse=True)
            max_val = max((max(abs(ma), abs(mb)) for _, ma, mb, _, _, _, _, _ in op_diffs), default=1)
            threshold = max(max_val * 0.05, 10_000_000)  # 至少 10ms
            top_ops = [o for o in op_diffs if abs(o[3]) >= threshold][:10]
            if top_ops:
                lines.append("")
                lines.append("=" * 80)
                lines.append(f"Stage {sid} Operator 对比 — Stage 差异: {diff/1000:+.1f}s")
                lines.append("=" * 80)
                lines.append(f"{'Operator':<22}{'MaxA(s)':>9}{'MaxB(s)':>9}{'Max差异':>9}{'AvgA(s)':>9}{'AvgB(s)':>9}{'Rows A':>13}{'Rows B':>13}")
                lines.append("-" * 93)
                for name, ma, mb, md, aa, ab, ra, rb in top_ops:
                    lines.append(
                        f"{name:<22}{ma/1e9:>9.2f}{mb/1e9:>9.2f}{md/1e9:>+9.2f}"
                        f"{aa/1e9:>9.2f}{ab/1e9:>9.2f}"
                        f"{ra:>13,}{rb:>13,}"
                    )

        # --- Pipeline 对比 (from stats_summary) ---
        ps_a = stats_a_data.get(sid, {}).get('pipeline_stats', {})
        ps_b = stats_b_data.get(sid, {}).get('pipeline_stats', {})
        if ps_a or ps_b:
            all_pids = sorted(set(list(ps_a.keys()) + list(ps_b.keys())),
                              key=lambda p: int(p) if p.isdigit() else 0)
            pipe_diffs = []
            for pid in all_pids:
                pa = ps_a.get(pid, {})
                pb = ps_b.get(pid, {})
                blk_max_a = _parse_max(pa.get('block_timing[min/max/avg/sum](ms)', ''))
                blk_max_b = _parse_max(pb.get('block_timing[min/max/avg/sum](ms)', ''))
                blk_avg_a = _parse_avg(pa.get('block_timing[min/max/avg/sum](ms)', ''))
                blk_avg_b = _parse_avg(pb.get('block_timing[min/max/avg/sum](ms)', ''))
                que_max_a = _parse_max(pa.get('queue_timing[min/max/avg/sum](ms)', ''))
                que_max_b = _parse_max(pb.get('queue_timing[min/max/avg/sum](ms)', ''))
                que_avg_a = _parse_avg(pa.get('queue_timing[min/max/avg/sum](ms)', ''))
                que_avg_b = _parse_avg(pb.get('queue_timing[min/max/avg/sum](ms)', ''))
                max_diff = (blk_max_b + que_max_b) - (blk_max_a + que_max_a)
                pipe_diffs.append((pid, blk_max_a, blk_max_b, blk_avg_a, blk_avg_b,
                                   que_max_a, que_max_b, que_avg_a, que_avg_b, max_diff))

            pipe_diffs.sort(key=lambda x: abs(x[9]), reverse=True)
            # 差异需要达到 stage 差异的 20% 或至少 500ms
            pipe_threshold = max(abs(diff) * 0.2, 500)
            top_pipes = [p for p in pipe_diffs if abs(p[9]) >= pipe_threshold][:10]
            if top_pipes:
                lines.append("")
                lines.append(f"Stage {sid} Pipeline 对比（block=I/O, queue=调度, 单位: 秒）")
                lines.append("-" * 100)
                lines.append(
                    f"{'Pipeline':<10}"
                    f"{'BlkMax_A':>9}{'BlkMax_B':>9}{'BlkAvg_A':>9}{'BlkAvg_B':>9}"
                    f"{'QueMax_A':>9}{'QueMax_B':>9}{'QueAvg_A':>9}{'QueAvg_B':>9}"
                )
                lines.append("-" * 100)
                for pid, bma, bmb, baa, bab, qma, qmb, qaa, qab, _ in top_pipes:
                    lines.append(
                        f"{'pipe'+pid:<10}"
                        f"{bma/1000:>9.2f}{bmb/1000:>9.2f}{baa/1000:>9.2f}{bab/1000:>9.2f}"
                        f"{qma/1000:>9.2f}{qmb/1000:>9.2f}{qaa/1000:>9.2f}{qab/1000:>9.2f}"
                    )

    return '\n'.join(lines)
