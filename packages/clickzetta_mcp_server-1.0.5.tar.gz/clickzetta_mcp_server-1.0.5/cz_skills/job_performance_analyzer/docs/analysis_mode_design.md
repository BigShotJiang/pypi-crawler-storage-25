# Job Performance Analyzer — 分析深度（Analysis Depth）设计文档

## 1. 概述

### 1.1 背景

当前 Job Performance Analyzer 是纯规则引擎模式：规则跑完 → 输出结果 → AI 解读。
这种模式在以下场景存在局限：

- 增量任务分析复杂，纯规则脚本难以覆盖所有场景
- 规则之间的关联关系（因果链）无法自动推理
- 部分 case 规则引擎"发现了异常但无法给出明确建议"

引入三层分析深度模式，在保持规则引擎核心优势（快速、确定性、零 token）的基础上，
用 AI 做精准补刀，覆盖规则引擎的盲区。

### 1.2 三种模式定义

| 模式 | 说明 | AI 介入 | Token 消耗 |
|------|------|---------|-----------|
| `quick` | 规则引擎跑完，直接出结果（现有行为） | 无 | 零 |
| `detailed` | 规则引擎 + AI 对结构化结果做二次研判 | 轻量 | 低（几KB json_report） |
| `expert` | 规则引擎 + AI 自主读 references md + 原始数据深度分析 | 重度 | 高（需用户确认） |

### 1.3 默认模式

默认为 `quick`，与现有行为完全一致，用户无感。

---

## 2. 规则引擎改造

### 2.1 BaseRule 新增字段

在 `base_rule.py` 中扩展输出结构：

#### 2.1.1 Finding 新增 `confidence` 字段

```python
def create_finding(self, finding_type, stage_id, severity, description="",
                   details=None, confidence='high') -> Dict:
    """
    confidence 取值：
    - 'high'   — 规则引擎很确定（如明确检测到 spilling > 阈值）
    - 'medium' — 有迹象但不完全确定（如倾斜比接近阈值）
    - 'low'    — 只是一个线索，需要 AI 进一步分析
    """
```

#### 2.1.2 Insight 新增 `level` 扩展

现有 `level` 取值为 `important` / `detail`，保持不变。
新增含义约定：

- `important` — quick/detailed/expert 都输出
- `detail` — detailed/expert 输出，quick 不输出（现有行为：仅 DEBUG 输出）

#### 2.1.3 新增 `add_analysis_detail()` 方法

规则在分析过程中，可以把关键中间计算数据存入 `analysis_scope`，
供 standard/expert 模式下 AI 消费。quick 模式下忽略。

```python
def add_analysis_detail(self, key: str, value: Any, stage_id: str = None):
    """存储分析中间数据，供 AI 二次研判使用"""
```

---

### 2.2 每条规则的改造方案

以下逐条说明每条规则在三种模式下的输出差异和 confidence 设计。

---

#### 2.2.1 RefreshTypeDetection（刷新类型检测）

**现有输出：**
- findings: `FULL_REFRESH`（severity=WARNING）
- insights: 增量/全量刷新提示

**模式差异：**
| 输出项 | quick | detailed | expert |
|--------|-------|----------|------|
| findings(FULL_REFRESH) | ✅ | ✅ | ✅ |
| insights(刷新类型) | important 级别 | important 级别 | important 级别 |

**confidence：** 始终 `high`（刷新类型判断是确定性的）

**analysis_scope：** 无需额外数据

**改造量：** 无改造。此规则输出已经足够，三种模式行为一致。

---

#### 2.2.2 SingleDopAggregate（单 DOP 聚合优化）

**现有输出：**
- findings: `SINGLE_DOP_AGG`（HIGH）、`MISSING_BF_COLLECTION`（HIGH）
- recommendations: 三阶段聚合参数、one-pass 参数、BF bits 阈值、BF 收集参数
- insights: 聚合阶段分析、BF 缺失提示

**模式差异：**
| 输出项 | quick | detailed | expert |
|--------|-------|----------|------|
| findings(SINGLE_DOP_AGG) | ✅ | ✅ | ✅ |
| findings(MISSING_BF_COLLECTION) | ✅ | ✅ | ✅ |
| recommendations(三阶段/BF) | ✅ | ✅ + AI 解释为什么这个参数最重要 | ✅ |
| insights(聚合阶段) | 仅 important | 全部 | 全部 |
| analysis_scope | ❌ | ✅ 聚合函数列表、bits 值、阶段信息 | ✅ |

**confidence：**
- `SINGLE_DOP_AGG` → `high`（DOP=1 是确定性事实）
- `MISSING_BF_COLLECTION` → `high`（有/无 BF 是确定性的）

**analysis_scope 新增：**
```python
{
    'aggregate_functions': ['MULTI_RANGE_COLLECT', ...],
    'bf_bits': 536870912,
    'aggregate_phase': 'FINAL',  # 或 'Complete'
    'has_upstream_p2': False,
    'three_phase_enabled': False
}
```

**改造量：** 小。在 analyze() 中添加 `add_analysis_detail()` 调用。

---

#### 2.2.3 HashJoinOptimization（Broadcast Hash Join 优化）

**现有输出：**
- findings: `BROADCAST_JOIN`（MEDIUM）
- recommendations: 禁用 broadcast hash join

**模式差异：**
| 输出项 | quick | detailed | expert |
|--------|-------|----------|------|
| findings(BROADCAST_JOIN) | ✅ | ✅ | ✅ |
| recommendations | ✅ | ✅ + AI 评估禁用后的影响 | ✅ |
| analysis_scope | ❌ | ✅ join 耗时占比、输入数据量 | ✅ |

**confidence：** `high`（join 耗时占比是确定性数据）

**analysis_scope 新增：**
```python
{
    'join_time_ms': 5000,
    'join_pct': 45.0,
    'input_gb': 2.5,
    'stage_elapsed_ms': 11000
}
```

**改造量：** 小。

---

#### 2.2.4 TableSinkDop（TableSink DOP 自动调整检测）

**现有输出：**
- findings: `TABLESINK_DOP`（MEDIUM）
- recommendations: 禁用自适应 split size
- insights: DOP 对比信息

**模式差异：**
| 输出项 | quick | detailed | expert |
|--------|-------|----------|------|
| findings(TABLESINK_DOP) | ✅ | ✅ | ✅ |
| recommendations | ✅ | ✅ | ✅ |
| insights(DOP 对比) | 仅 important | 全部（含"无需调整"的） | 全部 |
| analysis_scope | ❌ | ✅ 上下游 DOP 对比详情 | ✅ |

**confidence：** `high`（DOP 数值是确定性的）

**analysis_scope 新增：**
```python
{
    'current_dop': 10,
    'plan_dop': 50,
    'upstream_dops': [50, 30],
    'max_upstream_dop': 50,
    'dop_ratio': 0.2
}
```

**改造量：** 小。现有 finding 的 details 已包含这些数据，只需在 detailed 模式下透传。

---

#### 2.2.5 MaxDopCheck（最大 DOP 限制提示）

**现有输出：**
- findings: `MAX_DOP_USER_SET`（INFO）
- insights: DOP 达到限制提示

**模式差异：**
| 输出项 | quick | detailed | expert |
|--------|-------|----------|------|
| findings | ✅ | ✅ | ✅ |
| insights | 仅 important | 全部 | 全部 |

**confidence：** `high`

**改造量：** 无改造。此规则输出简单，三种模式差异仅在 insights 过滤层面。

---

#### 2.2.6 SpillingAnalysis（内存溢出分析）

**现有输出：**
- findings: `STAGE_SPILLING`（HIGH/MEDIUM）、`OPERATOR_SPILLING`（HIGH/MEDIUM）
- insights: spilling 详情

**模式差异：**
| 输出项 | quick | detailed | expert |
|--------|-------|----------|------|
| findings(STAGE_SPILLING) | 仅 HIGH | HIGH + MEDIUM | 全部 |
| findings(OPERATOR_SPILLING) | 仅 HIGH | HIGH + MEDIUM | 全部 |
| insights | 仅 important | 全部 | 全部 |
| analysis_scope | ❌ | ✅ 各 operator 的 spill 分布 | ✅ |

**confidence：**
- spill > 3GB → `high`
- 1GB < spill < 3GB → `high`
- 0.5GB < spill < 1GB → `medium`

**analysis_scope 新增：**
```python
{
    'operator_spills': [
        {'operator_id': 'HashAggregate#1', 'spill_gb': 2.5, 'is_ignorable': False},
        {'operator_id': 'ShuffleWrite#0', 'spill_gb': 1.0, 'is_ignorable': True},
    ],
    'effective_stage_spill_gb': 2.5,
    'ignorable_spill_gb': 1.0
}
```

**改造量：** 小。operator_spills 数据已在内部计算，只需暴露出来。

---

#### 2.2.7 SkewDetection（数据倾斜检测）

**现有输出：**
- findings: `DATA_SKEW`（HIGH/MEDIUM）
- recommendations: split size 调整
- insights: 倾斜详情、scan/shuffle 提示

**模式差异：**
| 输出项 | quick | detailed | expert |
|--------|-------|----------|------|
| findings(DATA_SKEW) | ✅ | ✅ | ✅ |
| recommendations(split size) | ✅ | ✅ + AI 分析倾斜根因 | ✅ |
| insights | 仅 important | 全部 | 全部 |
| analysis_scope | ❌ | ✅ task 分布详情 | ✅ |

**confidence：**
- active_task_ratio < 2% → `high`（极端倾斜）
- active_task_ratio < 30% → `medium`（一般倾斜）

**analysis_scope 新增：**
```python
{
    'active_tasks': 5,
    'total_tasks': 200,
    'active_task_ratio': 0.025,
    'has_scan': True,
    'has_shuffle_read': False,
    'current_split_size': 268435456,
    'recommended_split_size': 67108864
}
```

**detailed 模式 AI 研判重点：**
- 倾斜是源表文件分布问题，还是 shuffle key 选择问题？
- 如果 has_scan=True 且 split size 已经很小，AI 应建议检查源表 compaction
- 如果 has_shuffle_read=True，AI 应建议检查上游数据分布

**改造量：** 小。核心数据已在 _analyze_skew() 中计算。

---

#### 2.2.8 ResourceEfficiencyAnalysis（资源效率分析）

**现有输出：**
- findings: `RESOURCE_INEFFICIENCY`（HIGH/MEDIUM）
- insights: 资源抢占/调度问题提示

**模式差异：**
| 输出项 | quick | detailed | expert |
|--------|-------|----------|------|
| findings | ✅ | ✅ | ✅ |
| insights | 仅 important | 全部 | 全部 |
| analysis_scope | ❌ | ✅ 并发分析详情 | ✅ |

**confidence：**
- efficiency_ratio >= 3.0 → `high`
- efficiency_ratio >= 2.0 → `medium`

**analysis_scope 新增：**
```python
{
    'elapsed_ms': 60000,
    'estimated_ms': 20000,
    'efficiency_ratio': 3.0,
    'vc_cores': 64,
    'available_cores': 20,
    'concurrent_stages': ['stage_1', 'stage_3'],
    'concurrent_dop': 44,
    'task_concurrency': {'max': 20, 'min': 5, 'avg': 12.3}
}
```

**detailed 模式 AI 研判重点：**
- 效率低是因为资源竞争（concurrent_stages 多）还是调度问题（task 并发低）？
- 如果 available_cores 远大于 avg_concurrency，说明是调度问题而非资源不足

**改造量：** 小。数据已在 finding 的 details 中。

---

#### 2.2.9 ActiveProblemFinding（主动瓶颈分析）

**现有输出：**
- findings: `BOTTLENECK_ANALYSIS`（HIGH/MEDIUM）
- insights: 瓶颈算子信息、问题列表

**模式差异：**
| 输出项 | quick | detailed | expert |
|--------|-------|----------|------|
| findings | ✅ | ✅ | ✅ |
| insights(瓶颈算子) | 仅 important | 全部 | 全部 |
| insights(问题列表) | 仅 important | 全部 | 全部 |
| analysis_scope | ❌ | ✅ 完整问题列表 + 瓶颈算子详情 | ✅ |

**confidence：**
- 有明确问题（DATA_SKEW/HIGH_SPILLING）→ `high`
- 仅 GENERAL_SLOW → `low`（需要 AI 深入分析）

**analysis_scope 新增：**
```python
{
    'problems': [
        {'type': 'DATA_SKEW', 'severity': 'HIGH', 'description': '...'},
        {'type': 'LOW_DOP', 'severity': 'MEDIUM', 'description': '...'}
    ],
    'bottleneck_operator': {
        'operator_id': 'HashAggregate#1',
        'max_time_ms': 45000,
        'stage_pct': 85.0,
        'skew_ratio': 8.5
    }
}
```

**detailed 模式 AI 研判重点：**
- 对于 `GENERAL_SLOW`（confidence=low）的 case，AI 应结合其他规则的 findings 做归因
- 多个问题并存时，AI 判断因果关系（如：倾斜 → spilling → 效率低）

**改造量：** 小。problems 列表已在内部生成。

---

#### 2.2.10 ErrorMessageCollector（错误信息收集）

**现有输出：**
- insights: 错误信息统计
- 副作用: 将 error_messages 写入 context

**模式差异：**
| 输出项 | quick | detailed | expert |
|--------|-------|----------|------|
| insights | ✅ | ✅ | ✅ |
| analysis_scope | ❌ | ✅ 完整错误信息列表 | ✅ |

**改造量：** 无改造。此规则是基础设施，三种模式行为一致。

---

#### 2.2.11 JobConflictDetection（Job 提交冲突检测）

**现有输出：**
- findings: `job_conflict_error`（high）
- recommendations: `rerun_job` 类型
- insights: 冲突统计

**模式差异：**
| 输出项 | quick | detailed | expert |
|--------|-------|----------|------|
| findings | ✅ | ✅ | ✅ |
| recommendations(rerun) | ✅ | ✅ | ✅ |
| insights | ✅ | ✅ | ✅ |

**confidence：** `high`（冲突错误是确定性的）

**改造量：** 无改造。错误类规则三种模式行为一致。

---

#### 2.2.12 OptimizerErrorDetection（优化器错误检测）

**现有输出：**
- findings: `optimizer_internal_error`（high）
- recommendations: `rerun_job` 或 `contact_support`
- insights: 错误统计

**模式差异：** 同 JobConflictDetection，三种模式行为一致。

**confidence：** `high`

**改造量：** 无改造。

---

#### 2.2.13 NonIncrementalDiagnosis（全量刷新原因诊断）

**现有输出：**
- findings: `NON_INCREMENTAL_REFRESH`（HIGH）
- recommendations: 诊断参数设置
- insights: 全量原因提示

**模式差异：**
| 输出项 | quick | detailed | expert |
|--------|-------|----------|------|
| findings | ✅ | ✅ | ✅ |
| recommendations | ✅ | ✅ + AI 解释全量刷新的影响 | ✅ |
| insights | important 级别 | important 级别 | important 级别 |

**confidence：** `high`（全量刷新是确定性事实）

**改造量：** 无改造。

---

#### 2.2.14 StateTableEnable（状态表启用建议）

**现有输出：**
- recommendations: 状态表相关参数
- insights: 状态表分析详情、snapshot subplan 信息

**模式差异：**
| 输出项 | quick | detailed | expert |
|--------|-------|----------|------|
| recommendations | ✅ | ✅ | ✅ |
| insights | 仅 important | 全部（含 subplan 详情） | 全部 |
| analysis_scope | ❌ | ✅ snapshot subplan 结构 | ✅ |

**confidence：** `medium`（状态表建议需要结合业务场景判断）

**detailed 模式 AI 研判重点：**
- 状态表启用后的预期收益（基于 snapshot subplan 的耗时占比）
- 是否有不适合启用状态表的场景（如数据量太小）

**改造量：** 中。需要将 snapshot subplan 分析结果结构化输出。

---

#### 2.2.15 RowNumberCheck（ROW_NUMBER=1 pattern 检查）

**现有输出：**
- findings: ROW_NUMBER pattern 检测
- recommendations: 增量算法相关参数
- insights: pattern 分析

**模式差异：**
| 输出项 | quick | detailed | expert |
|--------|-------|----------|------|
| findings | ✅ | ✅ | ✅ |
| recommendations | ✅ | ✅ | ✅ |
| insights | 仅 important | 全部 | 全部 |

**confidence：** `high`（pattern 匹配是确定性的）

**改造量：** 无改造。

---

#### 2.2.16 AppendOnlyScan（Append-Only 表识别）

**现有输出：**
- findings: `POTENTIAL_OPTIMIZATION`（INFO）
- insights: append-only 表信息

**模式差异：**
| 输出项 | quick | detailed | expert |
|--------|-------|----------|------|
| findings | ✅ | ✅ | ✅ |
| insights | 仅 important | 全部 | 全部 |
| analysis_scope | ❌ | ✅ 表属性详情 | ✅ |

**confidence：** `medium`（append-only 是事实，但优化建议需要结合场景）

**改造量：** 小。

---

#### 2.2.17 AggregateReuse（聚合结果复用检查）

**现有输出：**
- findings: 聚合复用检测
- recommendations: 增量聚合参数
- insights: 聚合分析详情

**模式差异：**
| 输出项 | quick | detailed | expert |
|--------|-------|----------|------|
| findings | ✅ | ✅ | ✅ |
| recommendations | ✅ | ✅ | ✅ |
| insights | 仅 important | 全部 | 全部 |
| analysis_scope | ❌ | ✅ 聚合函数列表、增量能力分析 | ✅ |

**confidence：** `medium`（聚合复用可行性需要结合数据特征）

**改造量：** 小。

---

#### 2.2.18 HeavyCalcState（高耗时 Calc 状态优化）

**现有输出：**
- findings: `HEAVY_CALC`（HIGH/MEDIUM）
- recommendations: 状态表参数
- insights: Calc 耗时详情

**模式差异：**
| 输出项 | quick | detailed | expert |
|--------|-------|----------|------|
| findings | ✅ | ✅ | ✅ |
| recommendations | ✅ | ✅ + AI 评估 UDF 影响 | ✅ |
| insights | 仅 important | 全部 | 全部 |
| analysis_scope | ❌ | ✅ Calc 算子详情、UDF 信息 | ✅ |

**confidence：**
- has_udf=True → `high`
- has_udf=False → `medium`

**改造量：** 小。

---

#### 2.2.19 IncrementalAlgorithmVisualization（增量算法策略可视化）

**现有输出：**
- insights: 增量算法策略详情
- 副作用: 将 incremental_algorithms 写入 context

**模式差异：**
| 输出项 | quick | detailed | expert |
|--------|-------|----------|------|
| insights | 仅 important | 全部 | 全部 |
| analysis_scope | ❌ | ✅ 完整算法策略数据 | ✅ |

**改造量：** 无改造。此规则由独立参数控制启用。

---

## 3. Reporter 层改造

### 3.1 新增 `analysis_mode` 参数

Reporter 的输出方法接受 `analysis_mode` 参数，控制输出内容的详细程度。

```python
class Reporter:
    def generate_console_report(self, context, sections=None,
                                analysis_mode='quick') -> str:
        ...

    def generate_json_report(self, context=None,
                             analysis_mode='quick') -> Dict:
        ...
```

### 3.2 输出过滤规则

#### 3.2.1 Findings 过滤

| severity | quick | detailed | expert |
|----------|-------|----------|------|
| HIGH | ✅ | ✅ | ✅ |
| MEDIUM | ✅ | ✅ | ✅ |
| WARNING | ✅ | ✅ | ✅ |
| INFO | ❌ | ✅ | ✅ |
| LOW | ❌ | ✅ | ✅ |

注意：quick 模式下 INFO/LOW 级别的 findings 不输出到 console_report，
但 json_report 中始终包含完整数据（标记 `filtered: true`），
以便 standard/expert 模式的 AI 可以访问。

#### 3.2.2 Recommendations 过滤

所有模式都输出全部 recommendations（参数建议是核心价值）。
区别在于 standard/expert 模式下，json_report 中额外包含 `ai_review_hints` 字段：

```json
{
    "setting": "cz.optimizer.incremental.df.three.phase.agg.enable",
    "value": "true",
    "priority": 1,
    "ai_review_hints": {
        "related_findings": ["SINGLE_DOP_AGG"],
        "confidence": "high",
        "suggested_ai_action": "explain_impact"
    }
}
```

#### 3.2.3 Insights 过滤

| level | quick | detailed | expert |
|-------|-------|----------|------|
| important | ✅ | ✅ | ✅ |
| detail | ❌ | ✅ | ✅ |

这与现有行为一致（quick = 非 DEBUG 模式，detailed/expert = DEBUG 模式的 insights 输出）。

#### 3.2.4 Analysis Details 过滤

| 模式 | analysis_scope |
|------|-----------------|
| quick | ❌ 不包含在 json_report 中 |
| detailed | ✅ 包含在 json_report 中 |
| expert | ✅ 包含在 json_report 中 |

### 3.3 JSON Report 结构变化

```json
{
    "generated_at": "...",
    "metadata": {
        "analysis_depth": "detailed",
        "sql_type": "REFRESH",
        "refresh_type": "INCREMENTAL",
        ...
    },
    "findings": [...],
    "recommendations": [...],
    "insights": [...],
    "analysis_scope": {
        "skew_detection": {
            "stage_2": {
                "active_tasks": 5,
                "total_tasks": 200,
                "has_scan": true,
                ...
            }
        },
        "resource_efficiency": {
            "stage_3": {
                "efficiency_ratio": 3.0,
                "concurrent_stages": ["stage_1"],
                ...
            }
        },
        ...
    },
    "stage_summary": [
        {
            "stage_id": "stage_2",
            "elapsed_s": 45.12,
            "pct": 35.2,
            "dop": 50,
            "input_bytes": 1073741824,
            "output_bytes": 536870912,
            "spill_bytes": 2684354560,
            "task_skew": {
                "active": 5,
                "total": 50,
                "skew_ratio": 8.5
            },
            "top_operators": [
                {
                    "id": "HashAggregate#1",
                    "max_s": 40.5,
                    "stage_pct": 89.8,
                    "skew": 8.5,
                    "max_rows": 50000000,
                    "row_skew": 12.3
                }
            ]
        }
    ]
}
```

---

## 4. Detailed 模式 — AI 研判层设计

### 4.1 触发方式

detailed 模式在 MCP tool 调用时通过 `analysis_mode` 参数触发：

```json
{
    "name": "fetch_job_performance_data",
    "arguments": {
        "job_id": "xxx",
        "analysis_mode": "detailed"
    }
}
```

或通过自然语言触发（在 SKILL.md 中定义关键词映射）：
- "帮我详细分析" → detailed
- "帮我分析" / "快速看看" → quick

### 4.2 AI 研判 Prompt 模板

detailed 模式下，MCP handler 在返回结果时，附加一段结构化的 AI 研判指令：

```
你是 Clickzetta 增量计算性能专家。以下是规则引擎的分析结果（JSON 格式）。

请你做以下分析：

1. **因果关联分析**：检查 findings 之间是否有因果关系。
   常见因果链：
   - DATA_SKEW → STAGE_SPILLING → RESOURCE_INEFFICIENCY
   - SINGLE_DOP_AGG → BOTTLENECK_ANALYSIS(SINGLE_OP_DOMINANT)
   - TABLESINK_DOP(DOP被调小) → RESOURCE_INEFFICIENCY
   如果发现因果链，指出根因和影响链。

2. **优先级建议**：如果有多个 recommendations，基于以下原则重新排序：
   - 根因问题的参数优先于症状问题的参数
   - 影响范围大的参数优先（影响多个 stage）
   - confidence=high 的优先于 medium/low
   给出"如果只能改一个参数，建议先改哪个"的建议。

3. **补充洞察**：检查 analysis_scope 中是否有被 findings 遗漏的重要信息。
   特别关注：
   - confidence=medium/low 的 findings，是否有额外证据支持或否定
   - 多个 stage 出现相似问题时，是否有共同根因
   - insights 中 level=detail 的信息，是否有值得提升为 important 的

4. **风险提示**：对于 recommendations 中的参数建议，是否有潜在风险或副作用。
```

### 4.3 AI 输出格式

AI 的研判结果作为 `ai_analysis` 字段附加在返回结果中：

```json
{
    "output": "...(规则引擎原始输出)...",
    "json_report": "...(规则引擎 JSON 报告)...",
    "ai_analysis": {
        "causal_chains": [
            {
                "root_cause": "DATA_SKEW (Stage 2)",
                "effects": ["STAGE_SPILLING (Stage 2)", "RESOURCE_INEFFICIENCY (Stage 2)"],
                "explanation": "Stage 2 的数据倾斜导致少数 task 处理大量数据，内存不足触发 spilling..."
            }
        ],
        "priority_recommendation": {
            "top_recommendation": "cz.mapper.file.split.size = 67108864",
            "reason": "解决根因（数据倾斜）后，spilling 和资源效率问题可能同时改善"
        },
        "additional_insights": [
            "Stage 3 的 task 并发度（avg=12.3）远低于可用资源（available_cores=20），..."
        ],
        "risk_warnings": [
            "禁用 broadcast hash join 后，shuffle 数据量可能增加..."
        ]
    }
}
```

### 4.4 Token 消耗估算

detailed 模式的 AI 输入：
- json_report：通常 2-8 KB（取决于 stage 数量和问题数量）
- prompt 模板：约 1 KB
- 总输入：约 3-9 KB ≈ 1000-3000 tokens

AI 输出：约 500-1500 tokens

总消耗：约 1500-4500 tokens/次，成本可控。

---

## 5. Expert 模式 — AI 自主分析设计

### 5.1 触发方式与用户确认

expert 模式必须经过用户确认：

```
专家分析将读取以下参考文档和原始数据：
- references/stage-operator-optimization.md（约 XX KB）
- references/state-table-optimization.md（约 XX KB）
- 原始 stage 数据片段（约 XX KB）
预计消耗约 XXXX tokens。是否继续？
```

实现方式：MCP handler 在检测到 `analysis_mode=expert` 时，
先返回一个确认提示，等用户确认后再执行专家分析。

### 5.2 References MD 的使用策略

采用"按需加载"策略（路径 B），不是全部喂给 AI：

1. 规则引擎先跑完，产出 findings
2. 根据 findings 的类型，映射到对应的 reference 章节：

| Finding 类型 | 对应 Reference |
|-------------|---------------|
| DATA_SKEW, STAGE_SPILLING, RESOURCE_INEFFICIENCY | stage-operator-optimization.md |
| SINGLE_DOP_AGG, BROADCAST_JOIN | stage-operator-optimization.md |
| NON_INCREMENTAL_REFRESH, HEAVY_CALC | state-table-optimization.md |
| POTENTIAL_OPTIMIZATION (append-only) | state-table-optimization.md |
| optimizer_internal_error, job_conflict_error | 无需 reference |

3. AI 只读取相关的 reference 文档，结合 json_report + analysis_scope 做专家分析

### 5.3 Expert 模式 AI Prompt 模板

```
你是 Clickzetta 增量计算性能专家。

## 规则引擎分析结果
{json_report}

## 参考文档
{relevant_reference_content}

## 分析要求

在 detailed 模式分析的基础上，请额外做以下专家分析：

1. **规则盲区检查**：参考文档中描述的优化场景，是否有规则引擎未覆盖的问题？
   检查原始数据中是否存在参考文档提到但规则未检测的 pattern。

2. **参数组合分析**：多个参数建议之间是否有依赖或冲突关系？
   是否需要按特定顺序设置？

3. **深度根因分析**：对于 confidence=low/medium 的 findings，
   结合参考文档的知识，给出更确定的诊断。

4. **优化方案设计**：综合所有发现，给出一个完整的优化方案，
   包括参数设置顺序、预期效果、验证方法。
```

### 5.4 Token 消耗估算

expert 模式的 AI 输入：
- json_report + analysis_scope：约 5-15 KB
- reference 文档（按需加载）：约 10-30 KB
- prompt 模板：约 2 KB
- 总输入：约 17-47 KB ≈ 5000-15000 tokens

AI 输出：约 2000-5000 tokens

总消耗：约 7000-20000 tokens/次。

---

## 6. Debug 日志处理

### 6.1 设计原则

debug 日志不直接给任何模式的用户输出。原因：
- debug 日志是给开发者排查规则引擎本身问题的
- 量大且噪音多，AI 拿到也不好处理

### 6.2 替代方案：结构化 analysis_scope

规则引擎中现有的 debug 日志信息，有价值的部分通过 `analysis_scope` 结构化输出：

| 现有 debug 日志 | 转化为 analysis_scope |
|----------------|----------------------|
| `[tablesink_dop] Stage X: DOP=10, max_upstream=50, ratio=0.2` | `tablesink_dop.stage_X.dop_ratio` |
| `[resource_efficiency] Stage X: 实际耗时=60s, 预期=20s, 效率比=3.0x` | `resource_efficiency.stage_X.efficiency_ratio` |
| `[skew_detection] active_tasks=5/200` | `skew_detection.stage_X.active_task_ratio` |

### 6.3 debug 日志保留

现有的 `logger.debug()` 调用保持不变，仍然通过 `--log-level DEBUG` 控制。
这是给开发者用的，与 analysis_mode 是正交的两个维度：

- `--log-level` 控制开发者调试信息
- `analysis_mode` 控制用户可见的分析深度

---

## 7. MCP Tool 接口变更

### 7.1 新增参数

`fetch_job_performance_data` tool 新增 `analysis_mode` 参数：

```json
{
    "type": "object",
    "properties": {
        "job_id": {"type": "string"},
        "workspace_name": {"type": "string"},
        "analysis_mode": {
            "type": "string",
            "enum": ["quick", "detailed", "expert"],
            "default": "quick",
            "description": "分析模式：quick（默认，纯规则引擎）、detailed（规则+AI研判）、expert（专家分析，需确认）"
        },
        ...
    }
}
```

### 7.2 返回值变化

```python
# quick 模式（与现有一致）
{
    'output': '...(规则引擎输出)...',
    'json_report': '...(console report)...'
}

# detailed 模式
{
    'output': '...(规则引擎输出)...',
    'json_report': {  # 完整 JSON 报告（含 analysis_scope）
        'metadata': {..., 'analysis_mode': 'detailed'},
        'findings': [...],
        'recommendations': [...],
        'insights': [...],
        'analysis_scope': {...}
    },
    'ai_review_prompt': '...(结构化 AI 研判指令)...'
}

# expert 模式
{
    'output': '...(规则引擎输出)...',
    'json_report': {  # 完整 JSON 报告
        'metadata': {..., 'analysis_mode': 'expert'},
        ...
    },
    'ai_review_prompt': '...(专家分析 AI 指令)...',
    'reference_context': '...(按需加载的 reference 内容)...',
    'token_estimate': 12000,
    'requires_confirmation': True
}
```

---

## 8. SKILL.md 更新

### 8.1 使用说明新增

```markdown
### 分析深度

支持三种分析深度模式：

#### quick（默认）
纯规则引擎分析，零 AI 消耗，适合日常巡检。
- "帮我分析 job xxx"
- "快速看看 job xxx 有没有问题"

#### detailed
规则引擎 + AI 二次研判，适合排查具体问题。
- "帮我详细分析 job xxx"
- "分析 job xxx，需要 AI 研判"

#### expert
规则引擎 + AI 专家分析（读取参考文档），适合深度优化。
需要用户确认，消耗较多 token。
- "专家模式分析 job xxx"
- "帮我全面优化 job xxx"
```

---

## 9. 实现优先级

### Phase 1（基础设施）— ✅ 已完成
1. `base_rule.py` — 新增 `confidence` 字段和 `add_analysis_detail()` 方法
2. `reporter.py` — 新增 `analysis_mode` 参数，实现输出过滤逻辑
3. `analyze_job.py` — 传递 `analysis_mode` 参数

### Phase 2（规则改造）— ✅ 已完成
4. 逐条规则添加 `confidence` 字段（大部分规则改动 1-3 行）
5. 关键规则添加 `analysis_scope` 输出：
   - SkewDetection
   - ResourceEfficiencyAnalysis
   - SpillingAnalysis
   - ActiveProblemFinding
   - SingleDopAggregate
   - StateTableEnable
   - AggregateReuse

### Phase 3（MCP 集成）— ✅ 已完成
6. `optimize_tools.py` — 新增 `analysis_mode` 参数
7. `job_performance_handler.py` — 根据 depth 控制返回内容
8. detailed 模式 AI prompt 模板

### Phase 4（Expert 模式）— ✅ 已完成
9. reference 文档按需加载逻辑（handler 中 `_load_reference_files` + `FINDING_REFERENCE_MAP`）
10. expert 模式 AI prompt 模板（`_build_ai_review_prompt('expert')`）
11. 用户确认流程（`requires_confirmation` + `token_estimate` 字段）
12. SKILL.md 更新

---

## 10. 改造量评估

| 模块 | 改动文件数 | 改动量 | 说明 |
|------|-----------|--------|------|
| base_rule.py | 1 | 小 | 新增 confidence + add_analysis_detail |
| reporter.py | 1 | 中 | 新增过滤逻辑 |
| analyze_job.py | 1 | 小 | 传递参数 |
| 19 条规则 | 19 | 小（每条 1-5 行） | 添加 confidence，关键规则添加 analysis_scope |
| optimize_tools.py | 1 | 小 | 新增参数 |
| job_performance_handler.py | 1 | 中 | 返回值处理 |
| SKILL.md | 2 | 小 | 文档更新 |
| AI prompt 模板 | 新增 1 | 中 | detailed/expert prompt |
| **总计** | **~25 文件** | **中等** | 核心改动集中在 reporter 和 handler |
