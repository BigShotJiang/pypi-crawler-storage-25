# 核心模块详解

## 1. PlanProfileParser (`core/parser.py`)

### 职责
解析 `plan.json` 和 `job_profile.json`，提取结构化数据供后续模块使用。

### 输入容错
- plan_file 和 profile_file 均为可选，至少提供一个
- 文件不存在、JSON 格式错误、内容为空均有 graceful 处理
- `has_plan` / `has_profile` 标志位标识数据有效性

### 输出结构 (`parsed_data`)

```python
{
    'sql_info': {
        'text': str,           # SQL 文本
        'is_refresh': bool,    # 是否为 REFRESH SQL
        'is_compaction': bool, # 是否为 COMPACTION
        'sql_subtype': str,    # 具体子类型：SELECT/INSERT/MERGE INTO/...
    },
    'version_info': {
        'git_branch': str,     # 如 "release-v1.3"
    },
    'vc_mode': {
        'is_ap': bool,
        'mode': 'AP' | 'GP',
        'vc_cores': int,       # AP: executor count; GP: capability/100
    },
    'settings': dict,          # plan 中的所有参数配置
    'plan_stages': dict,       # stage_id -> plan stage data
    'profile_stages': dict,    # stage_id -> profile stage data
    'has_profile': bool,
    'has_plan': bool,
    'raw_profile': dict,       # 原始 profile 数据（含 jobStatus 等）
}
```

### SQL 类型检测 (`_detect_sql_subtype`)
移除注释后，按关键字优先级匹配：MERGE INTO > COPY INTO > INSERT > UPDATE > DELETE > SELECT/WITH > CREATE > DROP > ALTER > TRUNCATE > REFRESH > COMPACTION。

### Job Profiling 分析 (`get_job_profiling_analysis`)
解析 `jobProfiling.profiling` 数组（event_id → timestamp 映射），计算 Job 生命周期各阶段耗时：

| 阶段 | Event ID 范围 | 说明 |
|------|--------------|------|
| Setup | 100 → 108 | SQL 初始化（编译优化） |
| Resuming Cluster | 110 → 112 | 启动 VC |
| Queued | 112 → 120 | 等待资源 |
| Running | 120 → 130 | SQL 处理数据 |
| Finish | 130 → 150 | SQL 结束（commit 等） |

---

## 2. StageAligner (`core/aligner.py`)

### 职责
对齐 plan 和 profile 的 Stage 数据，计算性能指标，构建 Stage DAG。

### 核心流程

```
_calculate_stage_metrics()   # 计算每个 Stage 的指标
        │
_parse_stage_dependencies()  # 解析 Stage DAG（4 种方法）
        │
_align_stages()              # 合并 plan + profile + metrics
        │
_analyze_operators()         # 分析 Operator 性能 + 计算 per-operator spill
```

### Stage 指标 (`_stage_metrics[stage_id]`)

```python
{
    'elapsed_ms': int,           # Stage 耗时
    'dop': int,                  # 实际 DOP（= actual_dop）
    'actual_dop': int,           # 实际运行的 task count
    'plan_dop': int,             # plan 中估算的 DOP
    'input_bytes': int,
    'output_bytes': int,
    'spill_bytes': int,          # 原始 spill（含 Shuffle）
    'effective_spill_bytes': int, # 有效 spill（排除 Shuffle）
    'effective_spill_gb': float,
    'operator_spills': list,     # per-operator spill 详情
    # 倾斜相关（时间维度）
    'active_task_count': int,
    'total_task_count': int,
    'active_task_ratio': float,
    'task_time_skew_ratio': float,
    'active_max_ms': int,
    'active_avg_ms': float,
    # 倾斜相关（数据量维度）
    'data_skew_max_median_ratio': float,    # active task inputRowCount 的 max/median
    'data_skew_concentration_ratio': float, # 承担 80% 数据量的 task 占比（Top-K 集中度）
    'data_skew_top_k_tasks': int,           # 承担 80% 数据量所需的 task 数
    'data_skew_max_rows': int,              # active task 中最大 inputRowCount
    'data_skew_median_rows': int,           # active task 中 inputRowCount 中位数
}
```

### Stage 依赖解析（4 种方法）
按优先级尝试：
1. `inputStages` 字段
2. `inputs` 字段（含 stageId）
3. operators 中的 `exchange` 字段
4. operators 的 `inputIds` 推断上游 stage（最通用）

### Operator 分析
遍历每个 stage 的 `operatorSummary`，计算：
- 耗时（max/min/avg）、stage 占比、total 占比
- 时间倾斜比（当 active_task_ratio < 50% 时使用 stage 级别倾斜比）
- 行数统计（max/min/avg/sum）、行数倾斜比
- per-operator spill（区分 Shuffle 正常落盘 vs 计算溢出）

Shuffle 算子的 spill 被标记为 `is_shuffle=True`，不计入 `effective_spill_bytes`。
可忽略的 Shuffle 模式：`ShuffleWrite`、`ShuffleExchange`、`Exchange`。

### 输出结构 (`aligned_data`)

```python
{
    'aligned_stages': {stage_id: {
        'stage_id': str,
        'plan': dict,
        'profile': dict,
        'metrics': dict,
        'upstream_stages': list,
        'plan_operators': list,
    }},
    'stage_metrics': dict,
    'operator_analysis': list,  # 按 max_time_ms 降序
    'total_job_time': int,      # 最晚结束 - 最早开始
    'stage_dependencies': dict,
}
```

---

## 3. Reporter (`core/reporter.py`)

### 职责
收集分析结果，生成 console 报告和 JSON 报告。

### 数据收集
- `add_finding(finding)` — 问题发现
- `add_recommendation(rec)` — 参数建议
- `add_insight(insight)` — 洞察信息
- `set_metadata(key, value)` — 元数据
- `merge_analysis_result(result)` — 批量合并

### Console 报告 (`generate_console_report`)

输出布局采用"倒金字塔"设计，用户终端最后停留在底部，最先看到参数建议：

```
[概况]           ← 基本信息
[补充洞察]       ← detail 级别（仅 detailed/expert 模式）
[关键洞察]       ← important 级别
[参数建议]       ← 最终结论（最先看到）
```

### JSON 报告 (`generate_json_report`)

根据 `analysis_mode` 过滤输出：

| 内容 | quick | detailed | expert |
|------|-------|----------|--------|
| findings (HIGH/MEDIUM/WARNING) | ✅ | ✅ | ✅ |
| findings (INFO/LOW) | ❌ | ✅ | ✅ |
| insights (important) | ✅ | ✅ | ✅ |
| insights (detail) | ❌ | ✅ | ✅ |
| recommendations | ✅ | ✅ | ✅ |
| analysis_scope | ❌ | ✅ | ✅ |
| stage_summary | ❌ | ✅ | ✅ |

### 参数建议去重 (`_deduplicate_recommendations`)
- 参数建议按 `setting` 去重，保留 priority 更高的
- `rerun_job` 和 `contact_support` 类型不去重

### Stage Summary (`_build_stage_summary`)
为 detailed/expert 模式构建压缩的 per-stage 关键指标摘要，包含：
- 耗时、占比、DOP、IO、effective spill
- task 倾斜信息（active/total/skew_ratio）
- top 3 operators（耗时、stage 占比、倾斜比、行数）
