# Job Performance Analyzer — 技术文档

本目录包含 `job_performance_analyzer` 模块的完整技术文档，面向开发者和维护者。

## 文档索引

| 文档 | 说明 | 适合谁看 |
|------|------|---------|
| [architecture.md](./architecture.md) | 整体架构、数据流、模块职责 | 新人入门、架构理解 |
| [core-modules.md](./core-modules.md) | 核心模块详解（Parser / Aligner / Reporter） | 需要修改核心逻辑的开发者 |
| [rule-system.md](./rule-system.md) | 规则体系、基类设计、规则清单、新增规则指南 | 需要新增/修改规则的开发者 |
| [analysis-modes.md](./analysis-modes.md) | 三种分析模式（quick/detailed/expert）的设计与实现 | 需要理解分析深度控制的开发者 |
| [mcp-integration.md](./mcp-integration.md) | MCP Tool 集成层（Handler / Tools / AI Prompt） | 需要修改 MCP 接口的开发者 |
| [data-flow-reference.md](./data-flow-reference.md) | Context 字段参考、JSON 报告结构、关键数据路径 | 调试和排查问题时查阅 |
| [analysis_mode_design.md](./analysis_mode_design.md) | 分析模式设计方案（已有文档） | 了解设计决策 |

## 快速导航

- 想了解整体架构？→ [architecture.md](./architecture.md)
- 想新增一条规则？→ [rule-system.md](./rule-system.md) § 新增规则指南
- 想修改报告输出？→ [core-modules.md](./core-modules.md) § Reporter
- 想理解 MCP 调用链路？→ [mcp-integration.md](./mcp-integration.md)
- 想查某个 context 字段的含义？→ [data-flow-reference.md](./data-flow-reference.md)
