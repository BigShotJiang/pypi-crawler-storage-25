# 规则体系

## 1. 规则基类

所有规则继承自 `rules/base_rule.py`。

### BaseRule — Stage 级别规则

```python
class BaseRule(ABC):
    name: str          # 规则唯一标识
    category: str      # 分类路径（如 "incremental/stage_optimization"）
    description: str   # 规则描述
    rule_scope: str    # "stage" 或 "global"

    def check(self, stage_data, context) -> bool:
        """判断是否触发该规则"""

    def analyze(self, stage_data, context) -> Dict:
        """执行分析，返回 {findings, recommendations, insights}"""
```

### GlobalRule — 全局规则

```python
class GlobalRule(BaseRule):
    rule_scope = "global"

    def analyze_global(self, context) -> Dict:
        """全局分析，不针对单个 Stage"""
```

### 辅助方法

| 方法 | 说明 |
|------|------|
| `create_finding(type, stage_id, severity, description, details, confidence)` | 创建问题发现 |
| `create_recommendation(setting, value, priority, reason, impact, ...)` | 创建参数建议 |
| `create_insight(message, stage_id, level)` | 创建洞察（level: important/detail） |
| `add_analysis_detail(context, key, value, stage_id)` | 存储中间数据供 AI 消费 |
| `get_setting(setting, context)` | 获取参数值 |
| `has_setting(setting, context)` | 检查参数是否已配置 |
| `has_profile_data(context)` | 检查是否有有效 profile |
| `get_refresh_table_properties(context)` | 获取目标表的 dynamic table properties |
| `build_recommendation_with_table_check(...)` | 创建参数建议并检查表级属性冲突 |

### confidence 字段

Finding 的 `confidence` 表示规则引擎对诊断的置信度：
- `high` — 确定性事实（如 spilling > 阈值、DOP=1）
- `medium` — 有迹象但不完全确定（如倾斜比接近阈值）
- `low` — 只是线索，需要 AI 进一步分析

---

## 2. 规则清单

### 2.1 Stage/Operator 优化规则（9 条，始终启用）

| 规则 | 类名 | 触发条件概要 | 输出 |
|------|------|-------------|------|
| refresh_type_detection | RefreshTypeDetection | 所有 stage | 判断增量/全量刷新，写入 context['refresh_type'] |
| single_dop_aggregate | SingleDopAggregate | DOP=1 + HashAggregate P1 + 高成本聚合 + 耗时>阈值 | 三阶段聚合参数、BF 收集参数 |
| hash_join_optimization | HashJoinOptimization | 包含 BroadcastHashJoin + 耗时占比高 | 禁用 broadcast hash join |
| tablesink_dop | TableSinkDop | TableSink 实际 DOP < plan DOP | 禁用自适应 split size |
| max_dop_check | MaxDopCheck | DOP 达到用户设置的上限 | DOP 限制提示 |
| spilling_analysis | SpillingAnalysis | effective_spill_bytes > 0 | Stage/Operator 级别 spilling 发现 |
| skew_detection | SkewDetection | max/median>=5 或 Top-K集中度<=阈值 + 耗时>5s + 数据量>100MB + 占比>15% | split size 调整建议 |
| resource_efficiency_analysis | ResourceEfficiencyAnalysis | 实际耗时 / 理论耗时 >= 2.0 | 资源效率问题发现 |
| active_problem_finding | ActiveProblemFinding | 耗时占比高的 stage | 主动瓶颈分析，汇总已有 findings |

### 2.2 状态表优化规则（7 条，需 `--enable-state-table` 启用）

| 规则 | 类名 | 作用域 | 说明 |
|------|------|--------|------|
| non_incremental_diagnosis | NonIncrementalDiagnosis | Global | 全量刷新原因诊断 |
| state_table_enable | StateTableEnable | Global | 状态表启用建议（分析 snapshot subplan） |
| incremental_algorithm_visualization | IncrementalAlgorithmVisualization | Global | 增量算法策略可视化（独立参数控制） |
| row_number_check | RowNumberCheck | Stage | ROW_NUMBER=1 pattern 检查 |
| append_only_scan | AppendOnlyScan | Stage | Append-Only 表识别（当前已关闭） |
| aggregate_reuse | AggregateReuse | Stage | 聚合结果复用检查 |
| heavy_calc_state | HeavyCalcState | Stage | 高耗时 Calc 状态优化 |

### 2.3 通用规则（3 条，始终启用）

| 规则 | 类名 | 说明 |
|------|------|------|
| error_message_collector | ErrorMessageCollector | 收集所有错误信息，写入 context['error_messages'] |
| job_conflict_detection | JobConflictDetection | 基于收集的错误信息检测提交冲突 |
| optimizer_error_detection | OptimizerErrorDetection | 检测优化器内部错误 |

### 2.4 Job Profiling 分析

| 规则 | 类名 | 说明 |
|------|------|------|
| job_profiling_analysis | JobProfilingAnalysis | Job 生命周期阶段耗时分析 |

---

## 3. 规则执行顺序

`IncrementalAnalyzer.analyze()` 按以下顺序执行：

```
阶段1: Stage/Operator 级别优化
  ├─ 遍历所有 aligned_stages
  └─ 对每个 stage 执行 9 条 stage_rules
       └─ RefreshTypeDetection 的结果写入 context['refresh_type']

阶段2: 全局规则
  ├─ ErrorMessageCollector（所有 SQL 类型）
  ├─ JobConflictDetection（所有 SQL 类型）
  ├─ OptimizerErrorDetection（所有 SQL 类型）
  ├─ IncrementalAlgorithmVisualization（仅 REFRESH + 非全量刷新）
  ├─ NonIncrementalDiagnosis（仅 REFRESH）
  └─ StateTableEnable（仅 REFRESH + 非全量刷新）

阶段3: 状态表优化（需启用 + 仅 REFRESH + 非全量刷新）
  ├─ 遍历所有 aligned_stages
  └─ 对每个 stage 执行 state_table_rules
```

全量刷新（`refresh_type == 'FULL'`）时，状态表和增量算法规则自动跳过。

---

## 4. 新增规则指南

### 步骤

1. 在对应目录创建新文件，继承 `BaseRule` 或 `GlobalRule`
2. 实现 `check()` 和 `analyze()`（或 `analyze_global()`）
3. 在 `incremental_analyzer.py` 中导入并注册到对应的规则列表
4. 在对应的 `__init__.py` 中导出
5. 添加测试用例到 `tests/`

### 模板

```python
# rules/incremental/stage_optimization/new_rule.py
from ...base_rule import BaseRule

class NewRule(BaseRule):
    name = "new_rule"
    category = "incremental/stage_optimization"
    description = "新规则描述"

    def check(self, stage_data, context):
        # 前置条件检查
        if not self.has_profile_data(context):
            return False
        metrics = stage_data.get('metrics', {})
        # ... 触发条件
        return some_condition

    def analyze(self, stage_data, context):
        stage_id = stage_data.get('stage_id', 'unknown')
        findings, recommendations, insights = [], [], []

        # 分析逻辑...

        # 存储中间数据供 AI 消费（可选）
        self.add_analysis_detail(context, 'key', value, stage_id=stage_id)

        return {
            'findings': findings,
            'recommendations': recommendations,
            'insights': insights,
        }
```

### 注册

```python
# incremental_analyzer.py
from ..rules.incremental.stage_optimization import NewRule

class IncrementalAnalyzer(BaseAnalyzer):
    def __init__(self, ...):
        self.stage_rules = [
            ...,
            NewRule(),  # 添加到列表末尾
        ]
```

### 规范

- 规则内部日志用 `logger`，整体流程步骤可以用 `print`
- 每个参数建议必须有明确的触发条件和数据证据
- 必须检查 `settings` 避免重复建议已存在的参数
- 使用 `build_recommendation_with_table_check()` 自动检查表级属性冲突
- Finding 的 `confidence` 要准确反映确定性程度
