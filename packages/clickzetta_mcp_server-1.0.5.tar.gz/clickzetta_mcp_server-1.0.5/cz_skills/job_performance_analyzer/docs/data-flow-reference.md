# 数据流参考

## 1. Context 字段参考

分析器通过 `context` dict 在规则间共享数据。以下是所有字段的来源和用途。

### 1.1 由 analyze_job.py 写入

| 字段 | 类型 | 来源 | 说明 |
|------|------|------|------|
| `sql_info` | dict | parser | SQL 文本、类型、子类型 |
| `settings` | dict | parser | plan 中的所有参数配置 |
| `vc_mode` | str | parser | "AP" 或 "GP" |
| `vc_mode_info` | dict | parser | 完整 vc_mode 信息（含 vc_cores） |
| `version_info` | dict | parser | git_branch 等 |
| `has_profile` | bool | parser | 是否有有效的 profile 数据 |
| `raw_profile` | dict | parser | 原始 profile 数据（含 jobStatus） |
| `parser` | PlanProfileParser | - | Parser 实例（用于 Job Profiling） |
| `enable_incremental_algorithm_analysis` | bool | CLI/API | 是否启用增量算法分析 |

### 1.2 由 IncrementalAnalyzer 写入

| 字段 | 类型 | 来源 | 说明 |
|------|------|------|------|
| `total_job_time` | int | aligner | Job 总耗时（ms） |
| `all_stage_metrics` | dict | aligner | 所有 stage 的指标 |
| `operator_analysis` | list | aligner | 所有 operator 分析结果 |
| `aligned_stages` | dict | aligner | 对齐后的 stage 数据 |
| `stage_dependencies` | dict | aligner | Stage DAG 依赖关系 |
| `reporter` | Reporter | analyzer | Reporter 实例 |
| `all_results` | dict | analyzer | 累积的 findings/recommendations/insights |

### 1.3 由规则写入

| 字段 | 写入规则 | 说明 |
|------|---------|------|
| `refresh_type` | RefreshTypeDetection | "INCREMENTAL" 或 "FULL" |
| `error_messages` | ErrorMessageCollector | 收集的所有错误信息列表 |
| `incremental_algorithms` | IncrementalAlgorithmVisualization | 增量算法数据 |
| `analysis_scope` | 各规则通过 `add_analysis_detail()` | 中间计算数据（按规则名分组） |

---

## 2. JSON 报告结构

### 2.1 Finding

```json
{
  "rule": "skew_detection",
  "type": "DATA_SKEW",
  "stage_id": "stage_2",
  "severity": "HIGH",
  "description": "检测到数据倾斜：仅 2.5% 的 task 有数据 (5/200)...",
  "details": {
    "active_tasks": 5,
    "total_tasks": 200,
    "active_task_ratio": 0.025,
    "stage_elapsed_ms": 45120,
    "stage_total_pct": 35.2
  },
  "confidence": "high"
}
```

severity 取值：`HIGH` > `MEDIUM` > `WARNING` > `INFO` > `LOW`

### 2.2 Recommendation

#### 参数建议

```json
{
  "rule": "skew_detection",
  "type": "parameter",
  "setting": "cz.mapper.file.split.size",
  "value": "67108864",
  "priority": 2,
  "reason": "Stage stage_2: 检测到数据倾斜...",
  "impact": "MEDIUM",
  "current_value": "268435456",
  "warning": "同时注意：dynamic table xxx 上已设置该参数..."
}
```

#### 操作建议

```json
{
  "type": "rerun_job",
  "priority": "high",
  "title": "重新运行 Job（与 Compaction 冲突）",
  "description": "...",
  "action": "重新提交并运行此 Job"
}
```

### 2.3 Insight

```json
{
  "rule": "skew_detection",
  "message": "Stage stage_2: 检测到数据倾斜且包含 Scan 算子...",
  "stage_id": "stage_2",
  "level": "important"
}
```

level 取值：
- `important` — 所有模式都输出
- `detail` — 仅 detailed/expert 模式输出

---

## 3. 工具函数参考

### 3.1 PlanNavigator (`utils/plan_navigator.py`)

为单个 stage 的 plan 数据提供结构化查询：

```python
from cz_skills.job_performance_analyzer.utils.plan_navigator import create_stage_navigator

nav = create_stage_navigator(stage_data)
nav.has_operator('HashAggregate')
nav.has_hash_aggregate_phase('P1')
nav.has_aggregate_function(['MULTI_RANGE_COLLECT'])
nav.extract_aggregate_bits()
nav.get_table_sink_info()
nav.is_delta_table_sink()
nav.has_non_append_only_scan()
nav.has_append_only_scan()
nav.has_row_number_pattern()
nav.get_incremental_table_scans()
nav.get_input_stages()
```

### 3.2 StateTableChecker (`utils/state_table_checker.py`)

检查 Job 中是否包含中间状态表（表名含 `__incr__`）：

```python
from cz_skills.job_performance_analyzer.utils.state_table_checker import StateTableChecker

# 全局检查（遍历所有 stage）
has_state_table = StateTableChecker.check_plan_has_state_table(context)

# 单个 plan 检查
has_state_table = StateTableChecker.check_plan_has_state_table(plan_data)
```

带缓存，同一个 context 只检查一次。

### 3.3 AppendOnlyDetector (`utils/append_only_detector.py`)

判断 TableScan 的 delta 数据是否为 append-only：

```python
from cz_skills.job_performance_analyzer.utils.append_only_detector import AppendOnlyDetector

# 是否为 delta 扫描
AppendOnlyDetector.is_delta_scan(operator)

# 是否为 append-only（检查是否输出 __incremental_deleted 列）
AppendOnlyDetector.is_append_only_scan(operator)

# 组合判断
AppendOnlyDetector.is_append_only_delta_scan(operator)
```

### 3.4 IncrementalAlgorithmAnalyzer (`utils/incremental_algorithm_analyzer.py`)

识别增量算法和 delta/snapshot 传播：

```python
from cz_skills.job_performance_analyzer.utils.incremental_algorithm_analyzer import IncrementalAlgorithmAnalyzer

analyzer = IncrementalAlgorithmAnalyzer(plan_data)
result = analyzer.analyze()
# result['incremental_algorithms'] — 增量算法列表
# result['algorithm_dependencies'] — 算法依赖关系
# result['dependency_graph'] — 文本可视化
```

### 3.5 version_utils (`utils/version_utils.py`)

版本号解析与比较：

```python
from cz_skills.job_performance_analyzer.utils import parse_version, is_version_ge

version = parse_version("release-v1.3")  # (1, 3)
is_version_ge(version, 1, 4)             # False
```

---

## 4. 测试

```bash
# 运行所有测试
python -m pytest cz_skills/job_performance_analyzer/tests/ -v

# 运行单个测试
python -m pytest cz_skills/job_performance_analyzer/tests/test_skew_detection.py -v
```

测试文件命名规范：`test_<功能名>.py`，共 26 个测试文件覆盖各规则和工具函数。
