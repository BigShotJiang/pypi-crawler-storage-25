# MCP 集成层

## 1. 调用链路

```
用户自然语言
    │
    ▼
MCP Tool: fetch_job_performance_data (optimize_tools.py)
    │  解析参数、获取 plan + profile 数据
    ▼
Handler: analyze_job_performance (job_performance_handler.py)
    │  写入临时文件、调用 analyze_job()
    ▼
Core: analyze_job() (analyze_job.py)
    │  capture_output=True 模式
    ▼
Handler: 后处理
    │  expert 模式：加载 reference、估算 token
    ▼
MCP Tool: 构建响应
    │  附加 optimization_principles + ai_review_prompt
    ▼
返回给 AI
```

## 2. MCP Tool 定义

文件：`cz_mcp/tools/optimize_tools.py`

```python
Tool(
    name="fetch_job_performance_data",
    input_schema={
        "properties": {
            "workspace_name": {"type": "string"},
            "job_id": {"type": "string"},                    # 必需
            "enable_state_table": {"type": "boolean"},       # 默认 True
            "enable_incremental_algorithm": {"type": "boolean"}, # 默认 False
            "analysis_mode": {"type": "string", "enum": ["quick", "detailed", "expert"]},
            "path": {"type": "string"},                      # 可选，本地文件路径
        },
        "required": ["job_id"]
    }
)
```

### 数据获取方式

1. 远程获取（默认）：通过 API 下载 plan + profile
   - `get_job_plan_url()` → 下载 plan JSON
   - `get_job_profile()` → 获取 profile JSON
2. 本地加载（`path` 参数）：从指定目录读取 `job_plan.json` / `plan.json` + `job_profile.json`

## 3. Handler 处理逻辑

文件：`cz_mcp/handlers/job_performance_handler.py`

### analyze_job_performance()

1. 将 plan/profile 数据写入临时文件
2. 调用 `analyze_job(capture_output=True, analysis_mode=...)`
3. expert 模式后处理：
   - 从 findings 中提取类型集合
   - 通过 `FINDING_REFERENCE_MAP` 映射到 reference 文件
   - `_load_reference_files()` 按需加载
   - `_estimate_expert_mode_tokens()` 估算 token 消耗
   - 设置 `requires_confirmation=True`

### FINDING_REFERENCE_MAP

定义 finding 类型到 reference 文件的映射：

```python
FINDING_REFERENCE_MAP = {
    'DATA_SKEW': ['stage-operator-optimization.md'],
    'STAGE_SPILLING': ['stage-operator-optimization.md'],
    'NON_INCREMENTAL_REFRESH': ['state-table-optimization.md', 'incremental-optimization.md'],
    'HEAVY_CALC': ['state-table-optimization.md'],
    # ... 完整映射见源码
}
```

## 4. 响应结构

### quick 模式

```python
{
    'output': '...(规则引擎 print/log 输出)...',
    'json_report': '...(console report 文本)...',
}
```

### detailed 模式

```python
{
    'output': '...',
    'json_report': '...(console report)...',
    'structured_json_report': {  # 完整 JSON 报告
        'metadata': {..., 'analysis_mode': 'detailed'},
        'findings': [...],       # 含 INFO/LOW 级别
        'recommendations': [...],
        'insights': [...],       # 含 detail 级别
        'analysis_scope': {...}, # 规则中间数据
        'stage_summary': [...],  # per-stage 指标摘要
    },
}
```

MCP 层额外附加：
- `optimization_principles` — 参数推荐原则
- `ai_review_prompt` — AI 研判指令

### expert 模式

在 detailed 基础上额外包含：
- `reference_context` — 按需加载的 reference 文档内容
- `token_estimate` — 预估 token 消耗
- `requires_confirmation` — True
- `expert_mode_notice` — 专家分析提示信息

## 5. OutputCapture 机制

`analyze_job.py` 中的 `OutputCapture` 类用于 MCP 场景：
- 通过 `TeeOutput` 同时写入 buffer 和原始 stdout
- `capture_output=True` 时，console_report 绕过 Tee 直接写原始 stdout，避免被重复捕获
- 返回 `{'output': captured_text, 'json_report': console_report}`
