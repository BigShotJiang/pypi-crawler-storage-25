# 分析模式

## 1. 三种模式概览

| 模式 | 说明 | AI 介入 | Token 消耗 | 适用场景 |
|------|------|---------|-----------|---------|
| `quick` | 纯规则引擎（默认） | 无 | 零 | 日常巡检、批量扫描 |
| `detailed` | 规则引擎 + AI 研判数据 | 轻量 | 低 | 排查具体问题 |
| `expert` | 规则引擎 + AI 深度分析 | 重度 | 高 | 深度优化 |

## 2. 模式差异

### 2.1 输出内容差异

| 内容 | quick | detailed | expert |
|------|-------|----------|--------|
| console_report 中的 findings | 不显示 | 不显示 | 不显示 |
| console_report 中的 detail insights | 不显示 | 显示 | 显示 |
| json_report 中的 INFO/LOW findings | 过滤掉 | 包含 | 包含 |
| json_report 中的 detail insights | 过滤掉 | 包含 | 包含 |
| json_report 中的 analysis_scope | 不包含 | 包含 | 包含 |
| json_report 中的 stage_summary | 不包含 | 包含 | 包含 |
| MCP 返回的 ai_review_prompt | 无 | 有 | 有（含深度分析指令） |
| MCP 返回的 reference_context | 无 | 无 | 有（按需加载） |
| MCP 返回的 token_estimate | 无 | 无 | 有 |

### 2.2 analysis_scope

规则在分析过程中通过 `add_analysis_detail()` 存储的中间计算数据。quick 模式下不输出，detailed/expert 模式下包含在 json_report 中。

结构示例：
```json
{
  "analysis_scope": {
    "skew_detection": {
      "stage_2": {
        "skew_info": {
          "active_tasks": 5,
          "total_tasks": 200,
          "active_task_ratio": 0.025,
          "has_scan": true,
          "has_shuffle_read": false,
          "current_split_size": 268435456
        }
      }
    },
    "spilling_analysis": {
      "stage_3": {
        "operator_spills": [...],
        "effective_stage_spill_gb": 2.5
      }
    }
  }
}
```

### 2.3 stage_summary

Reporter 为 detailed/expert 模式构建的压缩 per-stage 指标摘要，让 AI 能看到规则引擎之外的"全貌"。

```json
{
  "stage_summary": [
    {
      "stage_id": "stage_2",
      "elapsed_s": 45.12,
      "pct": 35.2,
      "dop": 50,
      "input_bytes": 1073741824,
      "output_bytes": 536870912,
      "effective_spill_bytes": 2684354560,
      "task_skew": {"active": 5, "total": 50, "skew_ratio": 8.5},
      "top_operators": [
        {"id": "HashAggregate#1", "max_s": 40.5, "stage_pct": 89.8, "skew": 8.5, "max_rows": 50000000}
      ]
    }
  ]
}
```

## 3. MCP 层的模式处理

### 3.1 AI 研判 Prompt

detailed 和 expert 模式下，MCP handler 附加结构化的 AI 研判指令（`_build_ai_review_prompt`）：

1. 因果关联分析 — 检查 findings 之间的因果链
2. 优先级建议 — 基于根因/影响范围/confidence 重新排序
3. 补充洞察 — 检查 analysis_scope 中被遗漏的信息
4. stage_summary 全局审视 — 发现规则引擎盲区
5. 风险提示 — 参数建议的潜在副作用

expert 模式额外增加：
6. 规则盲区检查
7. 参数组合分析
8. 深度根因分析
9. 优化方案设计

### 3.2 Expert 模式的 Reference 加载

根据 findings 类型按需加载对应的 reference 文档：

| Finding 类型 | 加载的 Reference |
|-------------|-----------------|
| DATA_SKEW, STAGE_SPILLING, BROADCAST_JOIN, ... | stage-operator-optimization.md |
| NON_INCREMENTAL_REFRESH, HEAVY_CALC, ... | state-table-optimization.md |
| FULL_REFRESH | incremental-optimization.md |

映射关系定义在 `job_performance_handler.py` 的 `FINDING_REFERENCE_MAP` 中。

### 3.3 用户意图映射

| 用户说法 | 映射模式 |
|---------|---------|
| "帮我分析"、"看看"、"给出建议" | quick |
| "详细分析"、"仔细看看" | detailed |
| "专家模式"、"深度分析"、"全面分析" | expert |

注意："详细分析" = detailed，不是 expert。

## 4. 实现位置

| 组件 | 文件 | 关键参数/方法 |
|------|------|-------------|
| CLI 入口 | `analyze_job.py` | `--analysis-mode` 参数 |
| API 入口 | `analyze_job()` | `analysis_mode` 参数 |
| 规则基类 | `base_rule.py` | `add_analysis_detail()` |
| 报告过滤 | `reporter.py` | `generate_console_report(analysis_mode=)` / `generate_json_report(analysis_mode=)` |
| MCP Handler | `job_performance_handler.py` | `analyze_job_performance(analysis_mode=)` |
| MCP Tool | `optimize_tools.py` | `analysis_mode` schema 定义 |
| AI Prompt | `optimize_tools.py` | `_build_ai_review_prompt()` |
