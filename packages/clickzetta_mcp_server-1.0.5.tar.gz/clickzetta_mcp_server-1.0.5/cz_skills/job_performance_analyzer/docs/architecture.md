# 整体架构

## 1. 定位

`job_performance_analyzer` 是 Clickzetta Job 性能自动诊断的核心引擎。它接收执行计划（`plan.json`）和运行时统计（`job_profile.json`）作为输入，通过规则引擎自动识别性能瓶颈，输出参数优化建议。

支持的 SQL 场景：
- REFRESH（增量计算）— 主要场景
- Regular SQL（INSERT / SELECT / MERGE INTO 等）
- AP / GP 模式

## 2. 数据流总览

```
                        ┌─────────────────────────────────────────────┐
                        │              外部调用入口                     │
                        │  CLI: python -m job_performance_analyzer     │
                        │  API: analyze_job()                          │
                        │  MCP: fetch_job_performance_data             │
                        └──────────────────┬──────────────────────────┘
                                           │
                                           ▼
                        ┌──────────────────────────────────────────────┐
                        │         PlanProfileParser (core/parser.py)    │
                        │  · 解析 plan.json + job_profile.json          │
                        │  · 提取 SQL 类型、版本、VC 模式、settings      │
                        │  · plan 和 profile 均为可选（至少提供一个）     │
                        └──────────────────┬───────────────────────────┘
                                           │ parsed_data
                                           ▼
                        ┌──────────────────────────────────────────────┐
                        │         StageAligner (core/aligner.py)        │
                        │  · 对齐 plan stages 和 profile stages         │
                        │  · 计算 Stage 指标（耗时、DOP、IO、spill）     │
                        │  · 解析 Stage DAG 依赖关系                    │
                        │  · 分析 Operator 性能（耗时、倾斜比、spill）   │
                        └──────────────────┬───────────────────────────┘
                                           │ aligned_data
                                           ▼
                        ┌──────────────────────────────────────────────┐
                        │     IncrementalAnalyzer (analyzers/)          │
                        │  · 根据 SQL 类型选择分析器                     │
                        │  · 按顺序执行三组规则：                        │
                        │    1. stage_rules (9条) — Stage/Operator 优化  │
                        │    2. global_rules (3+条) — 错误分析 + 全局    │
                        │    3. state_table_rules (4条) — 状态表优化     │
                        │  · 收集 findings / recommendations / insights  │
                        └──────────────────┬───────────────────────────┘
                                           │ all_results
                                           ▼
                        ┌──────────────────────────────────────────────┐
                        │          Reporter (core/reporter.py)          │
                        │  · 去重参数建议                               │
                        │  · 按 Stage 耗时排序 insights                 │
                        │  · 根据 analysis_mode 过滤输出                │
                        │  · 输出 console 报告 + JSON 报告              │
                        └──────────────────────────────────────────────┘
```

## 3. 目录结构

```
job_performance_analyzer/
├── analyze_job.py              # 主入口（CLI + API），OutputCapture
├── __init__.py                 # 包定义，导出 analyze_job
├── __main__.py                 # python -m 入口
├── SKILL.md                    # 面向开发者的模块说明
│
├── core/                       # 核心管道
│   ├── parser.py               # JSON 解析与数据提取
│   ├── aligner.py              # Stage/Operator 对齐与指标计算
│   └── reporter.py             # 报告生成（console + JSON）
│
├── analyzers/                  # 分析器（编排规则执行）
│   ├── base_analyzer.py        # 基类：管理规则列表、context、reporter
│   └── incremental_analyzer.py # 增量计算分析器（REFRESH + Regular SQL）
│
├── rules/                      # 规则库
│   ├── base_rule.py            # 规则基类（BaseRule / GlobalRule）
│   ├── incremental/
│   │   ├── stage_optimization/ # 9 条 Stage/Operator 级别规则
│   │   └── state_table/        # 7 条状态表优化规则（含增量算法可视化）
│   ├── common/                 # 4 条通用规则（错误分析、Job Profiling）
│   └── ap_mode/                # AP 模式规则（TODO）
│
├── utils/                      # 工具函数
│   ├── plan_navigator.py       # 执行计划树遍历与查询
│   ├── state_table_checker.py  # 状态表存在性检查（带缓存）
│   ├── append_only_detector.py # Append-Only 表检测
│   ├── incremental_algorithm_analyzer.py  # 增量算法识别与可视化
│   └── version_utils.py        # 版本号解析与比较
│
├── docs/                       # 技术文档（本目录）
├── tests/                      # 测试用例（26 个测试文件）
└── references/                 # → symlink 到 cz_mcp/skills/.../references/
```

## 4. 调用方式

### 4.1 CLI

```bash
# 基本分析
python -m cz_skills.job_performance_analyzer plan.json job_profile.json

# 启用状态表分析
python -m cz_skills.job_performance_analyzer plan.json job_profile.json --enable-state-table

# 启用增量算法分析
python -m cz_skills.job_performance_analyzer plan.json job_profile.json --enable-incremental-algorithm

# DEBUG 模式
python -m cz_skills.job_performance_analyzer plan.json job_profile.json --log-level DEBUG

# 指定分析模式
python -m cz_skills.job_performance_analyzer plan.json job_profile.json --analysis-mode detailed
```

### 4.2 Python API

```python
from cz_skills.job_performance_analyzer import analyze_job

# 基本调用
result = analyze_job("plan.json", "profile.json")

# 带输出捕获（MCP 场景）
result = analyze_job(
    "plan.json", "profile.json",
    enable_state_table_analysis=True,
    capture_output=True,
    analysis_mode='detailed'
)
# result = {'output': '...', 'json_report': '...', 'structured_json_report': {...}}
```

### 4.3 MCP Tool

通过 `fetch_job_performance_data` MCP tool 调用，详见 [mcp-integration.md](./mcp-integration.md)。

## 5. 关键设计决策

### 5.1 plan 和 profile 均为可选

Parser 容忍缺失输入：
- 只有 plan → 可做状态表分析（不需要运行时数据）
- 只有 profile → 可做错误分析（不需要执行计划）
- 两者都有 → 完整分析

### 5.2 规则引擎 + AI 分层

规则引擎负责确定性分析（零 token），AI 负责二次研判（按需消耗 token）。
三种模式（quick / detailed / expert）控制 AI 介入程度，详见 [analysis-modes.md](./analysis-modes.md)。

### 5.3 Spill 统一在 Aligner 计算

Aligner 在遍历 operatorSummary 时统一计算 per-operator spill，区分 Shuffle 正常落盘和计算内存不足溢出（effective_spill）。规则直接从 metrics 读取，避免重复遍历。

### 5.4 倾斜检测基于数据量分布

Aligner 在 `_compute_task_time_skew` 中统一计算两组倾斜指标：

**时间维度**：`task_time_skew_ratio`（active task 的 max/avg 耗时比）、`active_task_ratio`（排除 idle task）。
idle task 判定标准：耗时 < 500ms 且输入行数 = 0 且输入字节 ≤ 64KB。

**数据量维度**（`_compute_data_skew`）：
- `data_skew_max_median_ratio`：active task 中 inputRowCount 的 max / median
- `data_skew_concentration_ratio`：承担 80% 数据量所需的最少 task 数 / active task 总数（Top-K 集中度）

skew_detection 规则使用两个条件 OR 触发：
- 条件 A：`max_median_ratio >= 5`（1 个 task 数据量远大于中位数）
- 条件 B：`concentration_ratio <= min(0.3, 2/active_count)`（少数 task 承担大部分数据）
