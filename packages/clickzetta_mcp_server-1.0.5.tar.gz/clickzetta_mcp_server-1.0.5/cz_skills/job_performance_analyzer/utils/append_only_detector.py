#!/usr/bin/env python3
"""
Append-Only 检测工具

统一的 append-only 检测逻辑，避免代码重复。
所有需要判断 delta 是否为 append-only 的地方都应该使用这个工具类。
"""
from typing import Dict, List, Optional


class AppendOnlyDetector:
    """
    Append-Only 检测器
    
    用于判断 TableScan 算子的 delta 数据是否为 append-only（纯增，无删除）。
    
    核心规则（来自 prompt 4.2.1.5）：
    1. 检查算子的实际输出列（operator.schema.structTypeInfo.fields）
    2. 如果输出 __incremental_deleted 列，则 delta 不是纯增（有删除）
    3. 如果没有输出该列，则 delta 是纯增（append-only）
    
    注意：
    - 列名是 __incremental_deleted（过去式），不是 __incremental_delete
    - 检查的是算子实际输出的列，不是表定义的完整 schema
    - 即使表本身支持删除，如果某次扫描不输出删除标记列，那次扫描就是 append-only 的
    """
    
    # 删除标记列名（注意是过去式）
    INCREMENTAL_DELETE_COL = '__incremental_deleted'
    
    @classmethod
    def is_append_only_scan(cls, operator: Dict) -> Optional[bool]:
        """
        判断 TableScan 算子是否为 append-only
        
        Args:
            operator: 算子字典，必须包含 tableScan 或 TableScan
            
        Returns:
            True: 是 append-only（纯增，无删除）
            False: 不是 append-only（有删除）
            None: 无法判断（不是 TableScan 或缺少必要信息）
        """
        # 检查是否为 TableScan
        table_scan = operator.get('tableScan') or operator.get('TableScan')
        if not table_scan:
            return None
        
        # 获取算子实际输出的列
        output_fields = cls.get_operator_output_fields(operator)
        if output_fields is None:
            return None
        
        # 检查是否输出删除标记列
        has_delete_col = cls.INCREMENTAL_DELETE_COL in output_fields
        
        # 如果输出删除标记列，则不是 append-only
        return not has_delete_col
    
    @classmethod
    def get_operator_output_fields(cls, operator: Dict) -> Optional[List[str]]:
        """
        获取算子实际输出的列名列表
        
        Args:
            operator: 算子字典
            
        Returns:
            列名列表，如果无法获取则返回 None
        """
        # 从 operator.schema.structTypeInfo.fields 获取实际输出的列
        operator_schema = operator.get('schema', {})
        struct_info = operator_schema.get('structTypeInfo', {})
        fields = struct_info.get('fields', [])
        
        if not fields:
            return None
        
        # 提取列名
        field_names = [f.get('name', '') for f in fields]
        return [name for name in field_names if name]  # 过滤空字符串
    
    @classmethod
    def has_incremental_delete_column(cls, operator: Dict) -> bool:
        """
        检查算子是否输出删除标记列
        
        Args:
            operator: 算子字典
            
        Returns:
            True: 输出了删除标记列
            False: 没有输出删除标记列或无法判断
        """
        output_fields = cls.get_operator_output_fields(operator)
        if output_fields is None:
            return False
        
        return cls.INCREMENTAL_DELETE_COL in output_fields
    
    @classmethod
    def is_delta_scan(cls, operator: Dict) -> bool:
        """
        判断 TableScan 是否为 delta 扫描
        
        Args:
            operator: 算子字典
            
        Returns:
            True: 是 delta 扫描
            False: 不是 delta 扫描
        """
        table_scan = operator.get('tableScan') or operator.get('TableScan')
        if not table_scan:
            return False
        
        # 检查 incrementalTableProperty
        incr_prop = table_scan.get('incrementalTableProperty')
        if not incr_prop:
            return False
        
        # 检查 from 版本，如果是 -9223372036854775808 则是 snapshot，不是 delta
        from_version = str(incr_prop.get('from', ''))
        if from_version == '-9223372036854775808':
            return False
        
        return True
    
    @classmethod
    def is_append_only_delta_scan(cls, operator: Dict) -> Optional[bool]:
        """
        判断是否为 append-only 的 delta 扫描
        
        这是一个组合判断：
        1. 必须是 delta 扫描
        2. 必须是 append-only
        
        Args:
            operator: 算子字典
            
        Returns:
            True: 是 append-only 的 delta 扫描
            False: 不是（可能不是 delta，或者不是 append-only）
            None: 无法判断
        """
        # 首先检查是否为 delta 扫描
        if not cls.is_delta_scan(operator):
            return False
        
        # 然后检查是否为 append-only
        return cls.is_append_only_scan(operator)
    
    @classmethod
    def get_table_name(cls, operator: Dict) -> Optional[str]:
        """
        从 TableScan 算子中提取表名
        
        Args:
            operator: 算子字典
            
        Returns:
            表名（格式：workspace.namespace.table），如果无法提取则返回 None
        """
        table_scan = operator.get('tableScan') or operator.get('TableScan')
        if not table_scan:
            return None
        
        table_info = table_scan.get('table', {})
        path = table_info.get('path', [])
        
        # 构建完整表名
        if len(path) >= 3:
            # 格式: [workspace, namespace, table_name] 或 [workspace, namespace, table_name, __delta__]
            return f"{path[0]}.{path[1]}.{path[2]}"
        elif len(path) >= 1:
            # 降级到最后一个元素
            return path[-1]
        else:
            # 尝试从 name 字段获取
            return table_info.get('name')
