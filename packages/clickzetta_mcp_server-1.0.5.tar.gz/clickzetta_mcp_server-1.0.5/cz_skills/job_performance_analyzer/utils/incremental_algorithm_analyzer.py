#!/usr/bin/env python3
"""增量算法分析器 - 识别增量算法和 delta/snapshot 传播"""
import json
import re
import logging
from typing import Dict, List, Set, Tuple, Optional
from enum import Enum

# 创建 logger
logger = logging.getLogger(__name__)


class DataType(Enum):
    """数据类型：Delta 或 Snapshot"""
    DELTA = "delta"
    SNAPSHOT = "snapshot"
    UNKNOWN = "unknown"


class AppendOnlyType(Enum):
    """Delta 数据的 append-only 类型"""
    APPEND_ONLY = "append_only"  # 纯增 delta（没有删除）
    WITH_DELETE = "with_delete"  # 有删除的 delta
    NOT_APPLICABLE = "not_applicable"  # 不适用（非 delta 数据）
    UNKNOWN = "unknown"


class IncrementalAlgorithmAnalyzer:
    """
    增量算法分析器

    根据 prompt 4.2.1 的要求实现增量算法识别：

    4.2.1.1 识别所有 operator 是 delta 还是 snapshot
      - 识别 TableScan 的数据类型（delta/snapshot）
      - 传播数据类型（一元算子、Join、Union 规则）

    4.2.1.2 识别不同算子的增量算法
      - 解析 Rule hints（如 Rule:IncrementalJoinWithoutCondenseRule_xxx#ID）
      - 识别增量算法类型（aggregate/join/window）
      - 区分真正的 join/aggregate/window 增量算子和算法的一部分

    4.2.1.3 算子增量算法对应的 subplan
      - 找到一个增量算法对应的所有算子（不仅仅是有 Rule hint 的算子）
      - 包括整个执行路径上的所有算子
      - 识别算子对应的 root 阶段
      - 使用 plan.json 的 "id" 字段（实际 ID，不是数组索引）

    4.2.1.4 展示增量算法以及状态图
      - 生成增量算法依赖关系图
      - 画出算子的依赖关系
    """

    def __init__(self, plan: Dict):
        self.plan = plan
        self.operators = plan.get('operators', [])
        logger.debug(f"初始化增量算法分析器，算子数量: {len(self.operators)}")

        # 算子 ID 映射：operator_index -> actual_operator_id (from plan.json)
        self.operator_ids: Dict[int, str] = {}
        # 反向映射：actual_operator_id -> operator_index
        self.id_to_index: Dict[str, int] = {}
        self._extract_operator_ids()

        # 算子数据类型映射：operator_index -> DataType
        self.operator_data_types: Dict[int, DataType] = {}

        # 算子 append-only 类型映射：operator_index -> AppendOnlyType
        # 根据 prompt 4.2.1.5 的要求，判断 delta 是否为 append-only（纯增）
        self.operator_append_only_types: Dict[int, AppendOnlyType] = {}

        # Rule hint 映射：rule_id -> [operator_indices]
        self.rule_groups: Dict[str, List[int]] = {}
        
        # **新增**：算子到 rule 名称的映射：operator_index -> rule_name
        # 用于记录所有算子的 hint（包括没有 #ID 的）
        # 例如：{329: "IncrementalAggregateSetDeltaRuleV2", 291: "IncrementalAggregateSetDeltaRuleV2"}
        self.operator_rule_names: Dict[int, str] = {}
        
        # 算法 ID 到完整 rule 名称的映射：algorithm_id -> full_rule_name
        # 用于从算法 ID 推断算法类型
        self.algorithm_id_to_rule_name: Dict[str, str] = {}
        
        # 记录相同 ID 有多个不同 rule 名称的情况（用于警告）
        self.algorithm_id_rule_conflicts: Dict[str, Set[str]] = {}

        # 算子依赖关系：operator_index -> [input_operator_indices]
        self.operator_dependencies: Dict[int, List[int]] = {}
        # 反向依赖：operator_index -> [output_operator_indices]（谁依赖我）
        self.operator_dependents: Dict[int, List[int]] = {}
        
        # **性能优化**：缓存算子的字符串表示和 deleteplan 检查结果
        self._operator_str_cache: Dict[int, str] = {}
        self._is_deleteplan_cache: Dict[int, bool] = {}

    def _extract_operator_ids(self):
        """
        从算子对象中提取实际的 operator ID

        根据用户补充：
        - "在 plan.json 里找到所有 operator 对应的 Id"
        - "这里的 ID 不是代码中那些 index 下标"

        需要从 plan.json 的算子对象中找到实际的 id 字段
        """
        for idx, op in enumerate(self.operators):
            # 尝试从算子对象中提取实际的 ID
            op_id = self._extract_id_from_operator(op)

            if op_id:
                self.operator_ids[idx] = op_id
                self.id_to_index[op_id] = idx
            else:
                # 如果没有找到 ID，生成一个唯一标识
                # 但这不应该是常态，plan.json 中的算子应该都有 id
                self.operator_ids[idx] = f"unknown_op_{idx}"
                self.id_to_index[f"unknown_op_{idx}"] = idx

    def _extract_id_from_operator(self, op: Dict) -> Optional[str]:
        """
        从算子对象中提取实际的 ID

        plan.json 中算子的 id 字段可能在不同位置：
        1. 直接在算子对象的顶层：{"id": "12345", "tableScan": {...}}
        2. 在算子类型的子对象中：{"tableScan": {"id": "12345", ...}}
        """
        # 方法1: 直接从顶层获取
        if 'id' in op:
            return str(op['id'])

        # 方法2: 从算子类型的子对象中获取
        # 常见的算子类型：tableScan, join, hashAgg, calc, filter, project, union, etc.
        for key, value in op.items():
            if isinstance(value, dict) and 'id' in value:
                return str(value['id'])

        # 方法3: 递归查找（最多两层）
        for key, value in op.items():
            if isinstance(value, dict):
                for sub_key, sub_value in value.items():
                    if sub_key == 'id':
                        return str(sub_value)

        return None

    def analyze(self) -> Dict:
        """
        执行完整的增量算法分析

        实现 prompt 4.2.1.1-4.2.1.4 的完整流程

        Returns:
            {
                'operator_data_types': {op_id: 'delta'/'snapshot'/'unknown'},  # 使用实际 ID
                'rule_groups': {rule_id: [op_ids]},                             # 使用实际 ID
                'incremental_algorithms': [
                    {
                        'type': 'aggregate'/'join'/'window',
                        'rule_id': 'xxx',
                        'operators': [op_ids],           # 完整 subplan 的所有算子 ID
                        'rule_operators': [op_ids],      # 仅有 Rule hint 的算子 ID
                        'is_original_sql': True/False,
                        'root_operator_id': 'xxx'
                    }
                ],
                'algorithm_dependencies': {rule_id: [dependent_rule_ids]},
                'dependency_graph': 'text visualization',
                'validation_warnings': [...]  # 验证警告信息
            }
        """
        logger.debug("========== 开始增量算法分析 ==========")
        logger.debug(f"算子总数: {len(self.operators)}")
        
        # 4.2.1.1 步骤 1: 识别 TableScan 的数据类型（delta/snapshot）
        self._identify_scan_data_types()

        # 4.2.1.2 步骤 2: 解析 Rule hints，识别增量算法
        self._parse_rule_hints()
        
        logger.debug(f"解析完成，找到 {len(self.rule_groups)} 个增量算法")
        for rule_id in self.rule_groups.keys():
            logger.debug(f"  算法 {rule_id}: {len(self.rule_groups[rule_id])} 个算子")

        # 4.2.1.3 步骤 3: 构建算子依赖关系
        self._build_operator_dependencies()

        # 4.2.1.1 步骤 4: 传播数据类型
        self._propagate_data_types()

        # 4.2.1.5 步骤 5: 识别 delta 是否为 append-only（纯增）
        self._identify_append_only_types()

        # 4.2.1.2 & 4.2.1.3 步骤 6: 识别增量算法及其完整 subplan
        algorithms = self._identify_incremental_algorithms_with_subplan()

        # 4.2.1.3 步骤 6: 构建算法依赖关系
        algo_deps = self._build_algorithm_dependencies(algorithms)

        # 4.2.1.4 步骤 7: 生成依赖关系图
        dep_graph = self._generate_dependency_graph(algorithms, algo_deps)

        # 新增步骤 8: 验证增量算法的正确性（根据 prompt 4.2.1.3 第 59 行的要求）
        validation_warnings = self._validate_algorithms(algorithms)
        
        # 新增步骤 9: 检测 rule 名称冲突
        rule_name_conflicts = self._detect_rule_name_conflicts()

        # 输出详细的增量算法信息到日志（在分析完成之前）
        self._log_algorithm_details(algorithms)

        # 调试模式：输出 delta/snapshot 传播树
        if logger.isEnabledFor(logging.DEBUG):
            self._log_data_type_tree()

        logger.debug("========== 增量算法分析完成 ==========")

        return {
            'operator_data_types': {
                self.operator_ids[idx]: dt.value
                for idx, dt in self.operator_data_types.items()
            },
            'operator_append_only_types': {
                self.operator_ids[idx]: ao.value
                for idx, ao in self.operator_append_only_types.items()
            },
            'rule_groups': {
                rule_id: [self.operator_ids[idx] for idx in indices]
                for rule_id, indices in self.rule_groups.items()
            },
            'incremental_algorithms': algorithms,
            'algorithm_dependencies': algo_deps,
            'dependency_graph': dep_graph,
            'validation_warnings': validation_warnings,
            'rule_name_conflicts': rule_name_conflicts
        }

    def _identify_scan_data_types(self):
        """
        识别 TableScan 的数据类型（delta 或 snapshot）

        根据 original_prompt.md 第 49 行的修改：
        - **Delta 数据**：只有当 from 和 to 都是非 MIN_LONG 值时（如 from=28800, to=57600）
        - **Snapshot 数据**：from=-9223372036854775808（MIN_LONG）是明显特征

        示例：
        1. Delta: {"from": "28800", "to": "57600"} → delta
        2. Snapshot (上个状态): {"from": "-9223372036854775808", "to": "28800"} → snapshot
        3. Snapshot (当前状态): {"from": "-9223372036854775808", "to": "57600"} → snapshot
        """
        # MIN_LONG 常量（Java Long.MIN_VALUE）
        MIN_LONG = -9223372036854775808

        for idx, op in enumerate(self.operators):
            if 'tableScan' not in op:
                continue

            table_scan = op['tableScan']
            incr_property = table_scan.get('incrementalTableProperty', {})

            from_version = incr_property.get('from')
            to_version = incr_property.get('to')

            # 如果没有增量属性，可能是普通表
            if from_version is None and to_version is None:
                self.operator_data_types[idx] = DataType.UNKNOWN
                continue

            # 转换为整数进行比较（可能是字符串格式）
            try:
                from_val = int(from_version) if from_version is not None else None
                to_val = int(to_version) if to_version is not None else None
            except (ValueError, TypeError):
                # 无法转换，标记为 UNKNOWN
                self.operator_data_types[idx] = DataType.UNKNOWN
                continue

            # 判断逻辑：
            # 1. 如果 from 是 MIN_LONG，则是 snapshot（无论 to 是什么）
            # 2. 如果 from 和 to 都不是 MIN_LONG，则是 delta
            # 3. 其他情况标记为 UNKNOWN

            if from_val is not None and from_val == MIN_LONG:
                # from 是 MIN_LONG，表示 snapshot
                self.operator_data_types[idx] = DataType.SNAPSHOT
            elif from_val is not None and to_val is not None and from_val != MIN_LONG and to_val != MIN_LONG:
                # from 和 to 都不是 MIN_LONG，表示 delta
                self.operator_data_types[idx] = DataType.DELTA
            else:
                # 其他情况（如只有 to，或 from/to 值异常）
                self.operator_data_types[idx] = DataType.UNKNOWN

    def _parse_rule_hints(self):
        """
        解析 Rule hints

        格式示例：
        - Rule:IncrementalLinearFunctionAggregateRule
        - Rule:IncrementalJoinWithoutCondenseRule_cz::optimizer::LogicalJoin#31766417_Delta:L_Snapshot:R
        - HINT=delta,DeltaState:[1,1896] - [1,6393]_IncrementalWindowSetDeltaRule#cz::optimizer::Window#293342
        - DeltaState:[1,6925] - [1,8514]_IncrementalJoinWithoutCondenseRule#cz::optimizer::LogicalJoin#5398716
        - HINT=Rule:IncrementalAggregateSetDeltaRuleV2_Delta:R_Snapshot:L （没有 #ID）

        注意：
        1. 同一个算子（如 #31766417）可能有多个变体，都应该归为一个算法
        2. 根据 prompt original_prompt.md 第 58 行，如果是 deleteplan 相关 hint，则忽略不属于增量算法
        3. **关键修复**（根据用户反馈）：
           - 有 #ID 的 hint：这是增量算法的"目标算子"，使用 #ID 作为算法标识
           - 没有 #ID 的 hint（如 HINT=Rule:IncrementalAggregateSetDeltaRuleV2_Delta:R_Snapshot:L）：
             这是增量算法的"辅助算子"，它会在 subplan 查找时被自然包含
             但需要记录它的 hint，以便在边界检测时使用
        4. **新增逻辑**（根据 prompt 4.2.1.3 第 69 行）：
           - 对于没有 ID 的 rule hint，应该往下游查找第一个带有 ID 且同类的增量算法
           - 这些算子联通起来的算子一定属于该算法的 subplan 一部分
           - 实现方式：通过 operator_rule_names 记录所有算子的 hint（包括没有 #ID 的）
           - 在边界检测时，使用 _has_downstream_with_algorithm_id() 向下游查找匹配的算法
        """
        for idx, op in enumerate(self.operators):
            op_str = json.dumps(op)

            # 查找 Rule: 模式（扩展正则以支持 - 和 () 符号）
            rule_pattern = r'Rule:([A-Za-z0-9_:#,\-()]+)'
            matches = re.findall(rule_pattern, op_str)

            for rule_name in matches:
                # 过滤 DeletePlan
                if 'deleteplan' in rule_name.lower() or 'delete_plan' in rule_name.lower():
                    continue

                # 提取算法 ID
                algorithm_id = self._extract_base_rule_id(rule_name)
                
                # 只处理有 ID 的 hint（创建独立的算法）
                if algorithm_id is None:
                    continue
                
                # 提取完整的 rule 名称
                full_rule_name = self._extract_full_rule_name(rule_name)
                
                # 更新算法 ID 到 rule 名称的映射
                self._update_algorithm_rule_name(algorithm_id, full_rule_name)

                if algorithm_id not in self.rule_groups:
                    self.rule_groups[algorithm_id] = []
                self.rule_groups[algorithm_id].append(idx)

            # 查找 HINT=Rule: 模式（可能没有 #ID）
            # 格式1：HINT=Rule:IncrementalAggregateSetDeltaRuleV2_Delta:R_Snapshot:L
            # 格式2：在 hint.comments 字段中：Rule:IncrementalAggregateSetDeltaRuleV2_Delta:R_Snapshot:L
            hint_rule_pattern = r'HINT=Rule:(Incremental[A-Za-z0-9]+Rule(?:V\d+)?)'
            hint_rule_matches = re.findall(hint_rule_pattern, op_str)

            # **新增**：查找 hint.comments 中的 Rule: 模式（没有 HINT= 前缀）
            # 这种格式出现在 hashJoin.join.hint.comments 等字段中
            comments_rule_pattern = r'"comments":\s*"Rule:(Incremental[A-Za-z0-9]+Rule(?:V\d+)?)[^"]*"'
            comments_rule_matches = re.findall(comments_rule_pattern, op_str)

            # 合并两种匹配结果
            all_hint_rule_matches = hint_rule_matches + comments_rule_matches

            for rule_name in all_hint_rule_matches:
                # 过滤 DeletePlan
                if 'deleteplan' in rule_name.lower() or 'delete_plan' in rule_name.lower():
                    continue

                # 提取完整的 rule 名称
                full_rule_name = self._extract_full_rule_name(rule_name)

                # **关键修改**：记录这个算子的 rule 名称（用于后续的边界检测）
                self.operator_rule_names[idx] = full_rule_name

                # 检查是否有 #ID
                algorithm_id = self._extract_base_rule_id(rule_name)

                if algorithm_id is not None:
                    # 有 #ID，创建独立的算法
                    self._update_algorithm_rule_name(algorithm_id, full_rule_name)

                    if algorithm_id not in self.rule_groups:
                        self.rule_groups[algorithm_id] = []
                    self.rule_groups[algorithm_id].append(idx)
                # 如果没有 #ID，只记录 rule 名称，不创建算法

            # 查找 HINT= 模式（有 #ID）
            hint_pattern = r'HINT=.*?_(Incremental[^#]+Rule(?:V\d+)?(?:\s+[^#]+)?)#[^#]*#(\d+)'
            hint_matches = re.findall(hint_pattern, op_str)

            for rule_name, target_op_id in hint_matches:
                rule_name = rule_name.strip()
                full_rule_id = f"{rule_name}#{target_op_id}"

                if 'deleteplan' in full_rule_id.lower() or 'delete_plan' in full_rule_id.lower():
                    continue

                algorithm_id = self._extract_base_rule_id(full_rule_id)
                
                if algorithm_id is None:
                    continue
                
                full_rule_name = self._extract_full_rule_name(rule_name)
                self._update_algorithm_rule_name(algorithm_id, full_rule_name)

                if algorithm_id not in self.rule_groups:
                    self.rule_groups[algorithm_id] = []
                self.rule_groups[algorithm_id].append(idx)

            # 查找 DeltaState 模式（有 #ID）
            deltastate_pattern = r'DeltaState[+-]?:\[.*?\].*?_(Incremental[^#]+Rule(?:V\d+)?(?:\s+[^#]+)?)#[^#]*#(\d+)'
            deltastate_matches = re.findall(deltastate_pattern, op_str)

            for rule_name, target_op_id in deltastate_matches:
                rule_name = rule_name.strip()
                full_rule_id = f"{rule_name}#{target_op_id}"

                if 'deleteplan' in full_rule_id.lower() or 'delete_plan' in full_rule_id.lower():
                    continue

                algorithm_id = self._extract_base_rule_id(full_rule_id)
                
                if algorithm_id is None:
                    continue
                
                full_rule_name = self._extract_full_rule_name(rule_name)
                self._update_algorithm_rule_name(algorithm_id, full_rule_name)

                if algorithm_id not in self.rule_groups:
                    self.rule_groups[algorithm_id] = []
                self.rule_groups[algorithm_id].append(idx)

            for rule_name, target_op_id in hint_matches:
                # 清理 rule 名称（去除尾部空格）
                rule_name = rule_name.strip()
                
                # 构建完整的 rule ID（包含目标算子 ID）
                full_rule_id = f"{rule_name}#{target_op_id}"

                # 过滤 DeletePlan 相关的 hint
                if 'deleteplan' in full_rule_id.lower() or 'delete_plan' in full_rule_id.lower():
                    continue

                # 提取算法 ID（用于分组统一）
                algorithm_id = self._extract_base_rule_id(full_rule_id)
                
                # 如果没有 ID，跳过（这些不是独立的增量算法）
                if algorithm_id is None:
                    continue
                
                # 提取完整的 rule 名称（保留版本号）
                full_rule_name = self._extract_full_rule_name(rule_name)
                
                # 更新算法 ID 到 rule 名称的映射（处理冲突）
                self._update_algorithm_rule_name(algorithm_id, full_rule_name)

                if algorithm_id not in self.rule_groups:
                    self.rule_groups[algorithm_id] = []
                self.rule_groups[algorithm_id].append(idx)

            # 新增：查找 DeltaState 模式（根据实际数据格式）
            # 格式：DeltaState:[1,6925] - [1,8514]_IncrementalJoinWithoutCondenseRule#cz::optimizer::LogicalJoin#5398716
            # 注意：rule 名称可能包含空格和特殊字符，如 "IncrementalAggregateSetDeltaRuleV2 Linear+"
            # 这种格式通常在 hint.comments 字段中
            deltastate_pattern = r'DeltaState[+-]?:\[.*?\].*?_(Incremental[^#]+Rule(?:V\d+)?(?:\s+[^#]+)?)#[^#]*#(\d+)'
            deltastate_matches = re.findall(deltastate_pattern, op_str)

            for rule_name, target_op_id in deltastate_matches:
                # 清理 rule 名称（去除尾部空格）
                rule_name = rule_name.strip()
                
                # 构建完整的 rule ID（包含目标算子 ID）
                full_rule_id = f"{rule_name}#{target_op_id}"

                # 过滤 DeletePlan 相关的 hint
                if 'deleteplan' in full_rule_id.lower() or 'delete_plan' in full_rule_id.lower():
                    continue

                # 提取算法 ID（用于分组统一）
                algorithm_id = self._extract_base_rule_id(full_rule_id)
                
                # 如果没有 ID，跳过（这些不是独立的增量算法）
                if algorithm_id is None:
                    continue
                
                # 提取完整的 rule 名称（保留版本号）
                full_rule_name = self._extract_full_rule_name(rule_name)
                
                # 更新算法 ID 到 rule 名称的映射（处理冲突）
                self._update_algorithm_rule_name(algorithm_id, full_rule_name)

                if algorithm_id not in self.rule_groups:
                    self.rule_groups[algorithm_id] = []
                self.rule_groups[algorithm_id].append(idx)

        # **新增**：处理没有ID的hint，将它们归属到对应的算法
        # 根据 prompt 4.2.1.3 第 69 行的要求
        self._assign_hints_without_id_to_algorithms()

        # 打印调试信息，打印所有base_rule_id和对应的所有operator信息
        # for base_rule_id in self.rule_groups.keys():
        #     print(f'base_rule_id: {base_rule_id}')
        #     print(f'operators: {self.rule_groups[base_rule_id]}')

    def _extract_base_rule_id(self, rule_name: str) -> Optional[str]:
        """
        从 rule 名称中提取基础的算法 ID

        例如：
        - IncrementalJoinWithoutCondenseRule#5398716 -> 5398716
        - IncrementalAggregateSetDeltaRuleV2#5399145 -> 5399145
        """
        match = re.search(r'#(\d+)', rule_name)
        if match:
            return match.group(1)
        return None

    def _assign_hints_without_id_to_algorithms(self):
        """
        将没有ID的hint归属到对应的算法

        根据 prompt 4.2.1.3 第 69 行的要求：
        "对于一些没有找到id的rule hint应该往自己下游继续查找，
        找到第一个带有id且同类（是指是相同算子，如，都是agg/window/join等）的增量算法"

        关键修复：
        1. 不仅要检查算子类型相同，还要检查rule名称是否匹配！
        2. **重要**：算法类型应该从hint的rule名称中提取，而不是从算子类型中提取
           例如：HashJoin291有hint "IncrementalAggregateSetDeltaRuleV2"，
           说明这个join算子是aggregate算法的一部分，应该匹配aggregate算法，而不是join算法
        """
        for idx, rule_name in self.operator_rule_names.items():
            # **关键修复**：从hint的rule名称中提取算法类型，而不是从算子类型中提取
            # 例如：IncrementalAggregateSetDeltaRuleV2 -> "aggregate"
            algo_type = self._identify_algorithm_type_from_rule_name(rule_name)

            # 向下游查找匹配的算法
            matched_algorithm_id = self._find_matching_algorithm_downstream_by_name(
                idx, rule_name, algo_type
            )

            if matched_algorithm_id:
                # 将该算子加入对应的算法
                if matched_algorithm_id not in self.rule_groups:
                    self.rule_groups[matched_algorithm_id] = []
                if idx not in self.rule_groups[matched_algorithm_id]:
                    self.rule_groups[matched_algorithm_id].append(idx)

    def _identify_algorithm_type_from_rule_name(self, rule_name: str) -> str:
        """
        从 rule 名称推断算法类型

        这是一个简化版本，直接从 rule 名称中提取类型，不需要查找映射

        Args:
            rule_name: rule 名称（如 "IncrementalAggregateSetDeltaRuleV2"）

        Returns:
            算法类型：'aggregate', 'join', 'window', 或 'unknown'
        """
        # 从 rule 名称中推断类型
        if 'Aggregate' in rule_name or 'Agg' in rule_name:
            return 'aggregate'
        elif 'Join' in rule_name:
            return 'join'
        elif 'Window' in rule_name:
            return 'window'
        else:
            return 'unknown'

    def _find_matching_algorithm_downstream_by_name(self, start_idx: int,
                                                     rule_name: str,
                                                     op_type: str,
                                                     max_depth: int = 10) -> Optional[str]:
        """
        查找匹配的算法（同时检查算子类型和rule名称）

        **关键修复**（根据用户反馈）：
        需要向下游搜索，找到第一个带有ID且同类的增量算法
        不能直接在所有算法中查找，因为可能有多个相同类型的算法，
        应该找到下游最近的那个

        匹配条件：
        1. 算子类型相同（join/aggregate/window）
        2. rule名称相似（去除版本号后的基础名称相同）
        3. 算法在当前算子的下游（通过图遍历可达）

        Args:
            start_idx: 起始算子索引
            rule_name: 无ID的rule名称（如 "IncrementalAggregateSetDeltaRuleV2"）
            op_type: 算子类型
            max_depth: 最大搜索深度

        Returns:
            匹配的算法ID，如果没找到返回None
        """
        # 提取基础rule名称（去除版本号和后缀）
        base_rule_name = self._extract_base_rule_name(rule_name)

        # **关键修复**：使用BFS向下游搜索，找到第一个匹配的算法
        # 下游 = 依赖当前算子的算子（dependents）
        visited = set()
        queue = [(start_idx, 0)]  # (算子索引, 深度)
        visited.add(start_idx)

        while queue:
            current_idx, depth = queue.pop(0)

            # 检查深度限制
            if depth > max_depth:
                continue

            # 检查当前算子是否属于某个算法
            for algorithm_id, algo_indices in self.rule_groups.items():
                if current_idx in algo_indices:
                    # 当前算子属于这个算法，检查是否匹配
                    algo_rule_name = self.algorithm_id_to_rule_name.get(algorithm_id, "")
                    algo_base_name = self._extract_base_rule_name(algo_rule_name)
                    algo_type = self._identify_algorithm_type(algorithm_id)

                    # **关键检查**：算子类型和rule名称是否都匹配
                    type_match = (algo_type == op_type)
                    name_match = (algo_base_name == base_rule_name)
                    
                    if type_match and name_match:
                        return algorithm_id

            # 继续向下游搜索（dependents = 依赖当前算子的算子）
            for dependent_idx in self.operator_dependents.get(current_idx, []):
                if dependent_idx not in visited:
                    visited.add(dependent_idx)
                    queue.append((dependent_idx, depth + 1))

        return None

    def _extract_base_rule_name(self, rule_name: str) -> str:
        """
        提取基础rule名称（去除版本号和后缀）

        例如：
        - IncrementalAggregateSetDeltaRuleV2 -> IncrementalAggregateSetDeltaRule
        - IncrementalJoinWithoutCondenseRule -> IncrementalJoinWithoutCondenseRule
        - IncrementalLinearTopKWindowRuleV2 -> IncrementalLinearTopKWindowRule
        """
        # 去除版本号（V1, V2等）
        base_name = re.sub(r'V\d+$', '', rule_name)
        # 去除可能的后缀（如 _Delta:R_Snapshot:L）
        base_name = re.sub(r'_.*$', '', base_name)
        return base_name.strip()

    def _extract_base_rule_id_old(self, rule_name: str) -> Optional[str]:
        """
        提取基础 rule ID，仅返回算法 ID（用于分组统一）

        关键修复（根据用户反馈）：
        - 不同的 hint 格式可能表示同一个算法（通过 # 后的 ID 识别）
        - 返回格式：仅返回 ID（如 "5399145"），用于分组
        - 完整的 rule 名称（带版本号）存储在 algorithm_id_to_rule_name 映射中
        - **重要**：没有 ID 的 rule 返回 None，因为它们可能只是某个增量算法的一部分

        提取逻辑：
        1. 提取最后一个 #数字 作为算法 ID
        2. 如果没有 ID，返回 None（这些 rule 不是独立的算法）
        3. 返回纯 ID（如 "5399145"），用于统一不同版本的同一算法

        例如：
        - IncrementalJoinWithoutCondenseRule_cz::optimizer::LogicalJoin#31766417
          -> "31766417"
        - IncrementalAggregateSetDeltaRuleV2_cz::optimizer::AggregatePhase#5399145
          -> "5399145"
        - IncrementalAggregateSetDeltaRule#5399145
          -> "5399145" (与上面统一)
        - IncrementalLinearFunctionAggregateRule (没有 ID)
          -> None (不是独立的算法)
        """
        # 查找所有 #数字 模式
        id_matches = re.findall(r'#(\d+)', rule_name)
        
        # 如果没有 ID，返回 None（这些不是独立的增量算法）
        if not id_matches:
            return None
        
        # 使用最后一个 #数字 作为算法 ID（仅返回 ID，用于分组）
        algorithm_id = id_matches[-1]
        
        return algorithm_id
    
    def _extract_full_rule_name(self, rule_name: str) -> str:
        """
        提取完整的 rule 名称（保留版本号）

        用于显示和存储在 algorithm_id_to_rule_name 映射中。
        当同一个 ID 有多个 rule 名称时，选择最完整的（带版本号的）。

        例如：
        - IncrementalAggregateSetDeltaRuleV2_cz::optimizer::AggregatePhase#5399145
          -> "IncrementalAggregateSetDeltaRuleV2"
        - IncrementalAggregateSetDeltaRule#5399145
          -> "IncrementalAggregateSetDeltaRule"
        - IncrementalAggregateSetDeltaRuleV2 Linear+#5402883
          -> "IncrementalAggregateSetDeltaRuleV2"
        """
        # 提取 Incremental 开头的完整 rule 名称（保留版本号）
        # 匹配模式：Incremental...Rule（可能带版本号如 V2）
        # 注意：不包括后面的修饰符（如 Linear+）
        
        # 方法1：尝试匹配标准格式（IncrementalXxxRule，可能带 V2 等版本号）
        rule_pattern = r'(Incremental[A-Za-z0-9]+Rule(?:V\d+)?)'
        rule_match = re.search(rule_pattern, rule_name)
        
        if rule_match:
            # 提取 rule 名称（保留版本号）
            return rule_match.group(1)
        else:
            # 方法2：如果没有匹配到标准格式，尝试提取第一个单词
            # 去除 _Delta:/_Snapshot: 等后缀
            match = re.match(r'([A-Za-z0-9]+)(?:_Delta:|_Snapshot:|_cz::|#|\s|$)', rule_name)
            if match:
                return match.group(1)
            else:
                # 方法3：直接使用第一个下划线或 # 之前的部分
                return rule_name.split('_')[0].split('#')[0].split()[0].strip()
    
    def _update_algorithm_rule_name(self, algorithm_id: str, new_rule_name: str):
        """
        更新算法 ID 对应的 rule 名称
        
        当同一个 ID 有多个不同的 rule 名称时，选择最合适的：
        1. 优先选择带版本号的（如 V2）
        2. 如果都有或都没有版本号，选择更长的（更完整的）
        3. 记录冲突情况用于警告
        
        Args:
            algorithm_id: 算法 ID（如 "5399145"）
            new_rule_name: 新的 rule 名称（如 "IncrementalAggregateSetDeltaRuleV2"）
        """
        if algorithm_id not in self.algorithm_id_to_rule_name:
            # 第一次遇到这个 ID，直接保存
            self.algorithm_id_to_rule_name[algorithm_id] = new_rule_name
            self.algorithm_id_rule_conflicts[algorithm_id] = {new_rule_name}
        else:
            existing_name = self.algorithm_id_to_rule_name[algorithm_id]
            
            # 记录所有遇到的 rule 名称
            if algorithm_id not in self.algorithm_id_rule_conflicts:
                self.algorithm_id_rule_conflicts[algorithm_id] = {existing_name}
            self.algorithm_id_rule_conflicts[algorithm_id].add(new_rule_name)
            
            # 如果 rule 名称不同，需要统一
            if existing_name != new_rule_name:
                # 选择策略：
                # 1. 优先选择带版本号的（如 V2）
                # 2. 如果都有或都没有版本号，选择更长的（更完整的）
                has_version_new = bool(re.search(r'V\d+', new_rule_name))
                has_version_existing = bool(re.search(r'V\d+', existing_name))
                
                should_update = False
                if has_version_new and not has_version_existing:
                    # 新的有版本号，旧的没有 -> 使用新的
                    should_update = True
                elif not has_version_new and has_version_existing:
                    # 旧的有版本号，新的没有 -> 保持旧的
                    should_update = False
                elif len(new_rule_name) > len(existing_name):
                    # 都有或都没有版本号，选择更长的
                    should_update = True
                
                if should_update:
                    self.algorithm_id_to_rule_name[algorithm_id] = new_rule_name
    
    def _detect_rule_name_conflicts(self) -> List[Dict]:
        """
        检测相同 ID 有多个不同 rule 名称的情况
        
        Returns:
            冲突列表，每个冲突包含：
            - algorithm_id: 算法 ID
            - rule_names: 所有遇到的 rule 名称列表
            - selected_name: 最终选择的 rule 名称
        """
        conflicts = []
        
        for algorithm_id, rule_names in self.algorithm_id_rule_conflicts.items():
            if len(rule_names) > 1:
                # 有多个不同的 rule 名称
                selected_name = self.algorithm_id_to_rule_name.get(algorithm_id, "Unknown")
                conflicts.append({
                    'algorithm_id': algorithm_id,
                    'rule_names': sorted(list(rule_names)),
                    'selected_name': selected_name,
                    'message': f'算法 ID #{algorithm_id} 有 {len(rule_names)} 个不同的 rule 名称: {", ".join(sorted(rule_names))}。已选择: {selected_name}'
                })
        
        return conflicts

    def _build_operator_dependencies(self):
        """
        构建算子依赖关系

        根据 prompt 4.2.1.3：需要识别算子之间的依赖关系
        """
        for idx in range(len(self.operators)):
            self.operator_dependencies[idx] = []
            self.operator_dependents[idx] = []

        # 尝试从算子中提取输入依赖
        for idx, op in enumerate(self.operators):
            inputs = self._extract_operator_inputs(op, idx)
            self.operator_dependencies[idx] = inputs

            # 构建反向依赖
            for input_idx in inputs:
                if 0 <= input_idx < len(self.operators):
                    self.operator_dependents[input_idx].append(idx)

    def _extract_operator_inputs(self, op: Dict, current_idx: int) -> List[int]:
        """
        提取算子的输入依赖

        从 plan.json 的 inputIds 字段提取真实的依赖关系。
        这支持跨 stage 的依赖追踪（例如通过 ShuffleRead/ShuffleWrite 连接）。

        实现逻辑：
        1. 优先使用 inputIds 字段（真实的依赖关系）
        2. inputIds 中的算子 ID 需要映射到索引
        3. 如果没有 inputIds，回退到启发式方法（向后兼容测试）
        """
        inputs = []

        # 方法1：使用 inputIds 字段（推荐，支持跨 stage）
        if 'inputIds' in op:
            input_ids = op['inputIds']
            if isinstance(input_ids, list):
                for input_id in input_ids:
                    if isinstance(input_id, str) and input_id in self.id_to_index:
                        inputs.append(self.id_to_index[input_id])
                return inputs

        # 方法2：回退到启发式方法（用于测试和简单场景）
        # 假设算子按拓扑顺序排列
        op_str = json.dumps(op).lower()
        if 'join' in op_str and current_idx >= 2:
            # Join 依赖前面两个算子
            inputs = [current_idx - 2, current_idx - 1]
        elif current_idx > 0:
            # 其他算子依赖前一个算子
            inputs = [current_idx - 1]

        return inputs

    def _propagate_data_types(self):
        """
        根据算子类型传播数据类型

        根据 prompt 4.2.1.1 的规则：
        - 一元算子：输入 delta → 输出 delta；输入 snapshot → 输出 snapshot
        - Join：只有 left 和 right 都是 snapshot，结果才是 snapshot
        - Union：所有输入都是 snapshot → 输出 snapshot；所有输入都是 delta → 输出 delta

        **重要补充规则**：
        - 如果算子有增量算法 hint（如 IncrementalJoinRule, IncrementalAggregateRule 等），
          那么该算子应该被标记为 delta，因为增量算法是用来处理增量数据的
        """
        max_iterations = 10
        for iteration in range(max_iterations):
            changed = False

            for idx, op in enumerate(self.operators):
                if idx in self.operator_data_types:
                    continue

                # **关键修复**：如果算子有增量算法 hint，直接标记为 delta
                if self._has_incremental_hint(op):
                    self.operator_data_types[idx] = DataType.DELTA
                    changed = True
                    continue

                input_indices = self.operator_dependencies.get(idx, [])
                input_types = []
                for input_idx in input_indices:
                    if input_idx in self.operator_data_types:
                        input_types.append(self.operator_data_types[input_idx])

                if not input_types or len(input_types) < len(input_indices):
                    continue

                op_type = self._get_operator_type(op)
                output_type = self._infer_output_type(op_type, input_types, op)

                if output_type != DataType.UNKNOWN:
                    self.operator_data_types[idx] = output_type
                    changed = True

            if not changed:
                break

    def _identify_append_only_types(self):
        """
        识别 delta 是否为 append-only（纯增）

        根据 prompt 4.2.1.5 的要求：
        - scan 如果是 delta，检查是否输出 __incremental_deleted 列（注意是过去式）
          - 检查位置：算子的实际输出列（operator.schema.structTypeInfo.fields）
          - 如果输出，则 delta 不是纯增（有删除）
          - 如果没有输出，则 delta 是纯增
        - join 算子：
          - 如果只有一路是 delta，且 join type 是 inner/anti/left semi，则继承该输入的 delta 是否纯增
          - 如果所有输入都是 delta，且 join type 是 inner，则所有 delta 都是纯增时 join 的 delta 才是纯增
        - aggregate/window 算子：
          - 如果有增量算法标记（4.2.1.2），则这些 aggregate/window 算子都是非纯增
          - 否则继承输入的 delta 是否纯增
        - 其他算子：
          - 把所有输入的 delta 一起看，只要有一路不是纯增，则该算子 delta 都不是纯增
        """
        from cz_skills.job_performance_analyzer.utils.append_only_detector import AppendOnlyDetector

        # 第一步：识别 TableScan 的 append-only 类型
        for idx, op in enumerate(self.operators):
            data_type = self.operator_data_types.get(idx, DataType.UNKNOWN)

            # 只处理 delta 数据
            if data_type != DataType.DELTA:
                self.operator_append_only_types[idx] = AppendOnlyType.NOT_APPLICABLE
                continue

            if 'tableScan' not in op:
                continue

            # 使用统一的 AppendOnlyDetector 检查是否为 append-only
            is_append_only = AppendOnlyDetector.is_append_only_scan(op)

            if is_append_only is None:
                # 无法判断，标记为未知
                self.operator_append_only_types[idx] = AppendOnlyType.NOT_APPLICABLE
            elif is_append_only:
                # 是 append-only（纯增）
                self.operator_append_only_types[idx] = AppendOnlyType.APPEND_ONLY
            else:
                # 不是 append-only（有删除）
                self.operator_append_only_types[idx] = AppendOnlyType.WITH_DELETE

        # 第二步：传播 append-only 类型
        max_iterations = 10
        for iteration in range(max_iterations):
            changed = False

            for idx, op in enumerate(self.operators):
                # 跳过已经确定的算子
                if idx in self.operator_append_only_types:
                    continue

                data_type = self.operator_data_types.get(idx, DataType.UNKNOWN)

                # 只处理 delta 数据
                if data_type != DataType.DELTA:
                    self.operator_append_only_types[idx] = AppendOnlyType.NOT_APPLICABLE
                    changed = True
                    continue

                # 获取输入算子的 append-only 类型
                input_indices = self.operator_dependencies.get(idx, [])
                input_append_only_types = []
                for input_idx in input_indices:
                    if input_idx in self.operator_append_only_types:
                        input_append_only_types.append(self.operator_append_only_types[input_idx])

                # 如果输入还没有全部确定，跳过
                if not input_append_only_types or len(input_append_only_types) < len(input_indices):
                    continue

                # 根据算子类型推导 append-only 类型
                op_type = self._get_operator_type(op)
                append_only_type = self._infer_append_only_type(
                    idx, op, op_type, input_indices, input_append_only_types
                )

                if append_only_type != AppendOnlyType.UNKNOWN:
                    self.operator_append_only_types[idx] = append_only_type
                    changed = True

            if not changed:
                break

    def _infer_append_only_type(self, idx: int, op: Dict, op_type: str,
                                input_indices: List[int],
                                input_append_only_types: List[AppendOnlyType]) -> AppendOnlyType:
        """
        根据算子类型和输入的 append-only 类型推导输出的 append-only 类型

        Args:
            idx: 算子索引
            op: 算子对象
            op_type: 算子类型
            input_indices: 输入算子索引列表
            input_append_only_types: 输入算子的 append-only 类型列表

        Returns:
            推导出的 append-only 类型
        """
        # 过滤掉 NOT_APPLICABLE 的输入（非 delta 数据）
        delta_inputs = [
            (input_idx, ao_type)
            for input_idx, ao_type in zip(input_indices, input_append_only_types)
            if ao_type != AppendOnlyType.NOT_APPLICABLE
        ]

        # 如果没有 delta 输入，则当前算子也不适用
        if not delta_inputs:
            return AppendOnlyType.NOT_APPLICABLE

        # Join 算子的特殊处理
        if op_type == 'join':
            return self._infer_join_append_only_type(op, delta_inputs)

        # Aggregate/Window 算子的特殊处理
        if op_type in ['aggregate', 'window']:
            return self._infer_agg_window_append_only_type(idx, op, op_type, delta_inputs)

        # 其他算子：只要有一路不是纯增，则该算子 delta 都不是纯增
        for _, ao_type in delta_inputs:
            if ao_type == AppendOnlyType.WITH_DELETE:
                return AppendOnlyType.WITH_DELETE
            elif ao_type == AppendOnlyType.UNKNOWN:
                return AppendOnlyType.UNKNOWN

        # 所有输入都是纯增，则输出也是纯增
        return AppendOnlyType.APPEND_ONLY

    def _infer_join_append_only_type(self, op: Dict,
                                     delta_inputs: List[Tuple[int, AppendOnlyType]]) -> AppendOnlyType:
        """
        推导 Join 算子的 append-only 类型

        根据 prompt 4.2.1.5 的最新要求：
        1. 首先检查 DeltaState 模式（新增规则）：
           - DeltaState- 表示有删除（非纯增）
           - DeltaState+ 表示纯增
        2. 如果没有 DeltaState 模式，则按原有逻辑：
           - 如果只有一路是 delta，且 join type 是 inner/anti/left_semi，则继承该输入的 delta 是否纯增
           - 如果所有输入都是 delta，所有 delta 都是纯增，且 join 上有类似 HINT=Rule: 这种 pattern，
             且 join type 是 inner/left_semi/anti 时，则 join 的 delta 也是纯增，否则认为是非纯增
        
        注意：delta_inputs 已经是过滤后的 delta 输入列表（不包含 NOT_APPLICABLE）
        """
        # 新增：检查 DeltaState 模式
        deltastate_type = self._check_deltastate_pattern(op)
        if deltastate_type != AppendOnlyType.UNKNOWN:
            return deltastate_type
        
        # 提取 join type（已经是小写格式，如 'inner', 'left_semi', 'anti'）
        join_type = self._get_join_type(op)

        # delta_inputs 的长度就是 delta 输入的数量
        delta_count = len(delta_inputs)

        # 情况1：只有一路是 delta，且 join type 是 inner/anti/left_semi
        if delta_count == 1 and join_type in ['inner', 'anti', 'left_semi']:
            # 继承该 delta 输入的 append-only 类型
            _, ao_type = delta_inputs[0]
            return ao_type

        # 情况2：所有输入都是 delta，所有 delta 都是纯增，且 join 上有 Rule hint，
        #        且 join type 是 inner/left_semi/anti
        if delta_count >= 2 and join_type in ['inner', 'left_semi', 'anti']:
            # 检查所有 delta 是否都是纯增
            all_append_only = all(ao_type == AppendOnlyType.APPEND_ONLY for _, ao_type in delta_inputs)
            
            if all_append_only:
                # 检查 join 上是否有 Rule hint
                if self._has_rule_hint(op):
                    return AppendOnlyType.APPEND_ONLY

        # 其他情况：默认为 WITH_DELETE
        return AppendOnlyType.WITH_DELETE

    def _has_rule_hint(self, op: Dict) -> bool:
        """
        检查算子是否有 Rule hint
        
        查找类似 HINT=Rule: 这种 pattern
        """
        op_str = json.dumps(op)
        
        # 检查是否包含 Rule: pattern
        # 可能的格式：
        # - "Rule:IncrementalJoinWithoutCondenseRule"
        # - "HINT=Rule:xxx"
        # - "hint": {"comments": "Rule:xxx"}
        
        # 方法1：直接搜索 Rule: pattern
        if 'Rule:' in op_str:
            return True
            
        # 方法2：检查 hint 字段
        for key in op.keys():
            if 'join' in key.lower():  # hashJoin, nestedLoopJoin 等
                join_obj = op[key]
                if isinstance(join_obj, dict):
                    # 检查 hint 字段
                    if 'hint' in join_obj:
                        hint_obj = join_obj['hint']
                        if isinstance(hint_obj, dict):
                            # 检查 comments 字段
                            if 'comments' in hint_obj:
                                comments = str(hint_obj['comments'])
                                if 'Rule:' in comments:
                                    return True
                            # 检查其他可能的字段
                            for hint_key, hint_value in hint_obj.items():
                                if isinstance(hint_value, str) and 'Rule:' in hint_value:
                                    return True
        
        return False

    def _infer_agg_window_append_only_type(self, idx: int, op: Dict, op_type: str,
                                           delta_inputs: List[Tuple[int, AppendOnlyType]]) -> AppendOnlyType:
        """
        推导 Aggregate/Window 算子的 append-only 类型

        根据 prompt 4.2.1.5 的要求：
        1. 首先检查 DeltaState 模式（新增规则）：
           - DeltaState- 表示有删除（非纯增）
           - DeltaState+ 表示纯增
        2. 如果没有 DeltaState 模式，则继承输入的 delta 是否纯增
        """
        # 新增：检查 DeltaState 模式
        deltastate_type = self._check_deltastate_pattern(op)
        if deltastate_type != AppendOnlyType.UNKNOWN:
            return deltastate_type
        
        # 继承输入的 delta 是否纯增
        # 只要有一路不是纯增，则该算子 delta 都不是纯增
        for _, ao_type in delta_inputs:
            if ao_type == AppendOnlyType.WITH_DELETE:
                return AppendOnlyType.WITH_DELETE
            elif ao_type == AppendOnlyType.UNKNOWN:
                return AppendOnlyType.UNKNOWN

        return AppendOnlyType.APPEND_ONLY

    def _check_deltastate_pattern(self, op: Dict) -> AppendOnlyType:
        """
        检查算子是否有 DeltaState 模式
        
        根据新增规则：
        - DeltaState- 表示有删除（非纯增）
        - DeltaState+ 表示纯增
        
        示例：HINT=delta,DeltaState-:[1,1896] - [1,6393]_IncrementalWindowSetDeltaRule#cz::optimizer::Window#44
        """
        op_str = json.dumps(op)
        
        # 检查 DeltaState- 模式（有删除）
        if 'DeltaState-' in op_str:
            return AppendOnlyType.WITH_DELETE
        
        # 检查 DeltaState+ 模式（纯增）
        if 'DeltaState+' in op_str:
            return AppendOnlyType.APPEND_ONLY
        
        # 没有找到 DeltaState 模式
        return AppendOnlyType.UNKNOWN

    def _get_join_type(self, op: Dict) -> str:
        """
        提取 Join 算子的 join type

        根据实际 plan.json 格式，join type 在以下路径：
        - hashJoin.join.type (如 "LEFT_SEMI", "INNER", "LEFT", "RIGHT", "FULL", "ANTI")
        - nestedLoopJoin.join.type
        - broadcastHashJoin.join.type

        Returns:
            join type 字符串，如 'inner', 'left', 'right', 'full', 'anti', 'left_semi' 等
        """
        # 尝试从不同的 join 算子类型中提取 join type
        join_keys = ['hashJoin', 'nestedLoopJoin', 'broadcastHashJoin', 'join']
        
        for key in op.keys():
            key_lower = key.lower()
            # 检查是否是 join 相关的键
            if any(jk.lower() in key_lower for jk in join_keys):
                join_obj = op[key]
                if isinstance(join_obj, dict):
                    # 方法1: 检查 join.type 路径（最常见）
                    if 'join' in join_obj and isinstance(join_obj['join'], dict):
                        if 'type' in join_obj['join']:
                            join_type = str(join_obj['join']['type'])
                            # 转换为小写并处理下划线
                            # LEFT_SEMI -> left_semi, INNER -> inner
                            return join_type.lower()
                    
                    # 方法2: 直接在顶层查找 type（兼容旧格式）
                    if 'type' in join_obj:
                        join_type = str(join_obj['type'])
                        return join_type.lower()
                    
                    # 方法3: 查找 joinType 字段（兼容其他格式）
                    if 'joinType' in join_obj:
                        join_type = str(join_obj['joinType'])
                        return join_type.lower()

        # 默认返回 unknown
        return 'unknown'

    def _infer_output_type(self, op_type: str, input_types: List[DataType], op: Dict = None) -> DataType:
        """
        根据算子类型和输入类型推导输出类型
        
        Args:
            op_type: 算子类型
            input_types: 输入数据类型列表
            op: 算子对象（可选，用于特殊判断）
        
        Returns:
            推导出的输出数据类型
        """
        if not input_types:
            return DataType.UNKNOWN

        if op_type == 'join':
            # 特殊处理：df_and join 应该被当作 filter 对待
            # df_and 仅用于数据裁剪，其 delta/snapshot 属性完全依赖于左边输入
            if op is not None and self._is_df_and_join(op):
                # df_and join: 只依赖左边输入（第一个输入）
                return input_types[0] if input_types else DataType.UNKNOWN
            
            # 普通 join: 只有所有输入都是 snapshot 时才是 snapshot
            if all(dt == DataType.SNAPSHOT for dt in input_types):
                return DataType.SNAPSHOT
            else:
                return DataType.DELTA
        elif op_type == 'union':
            if all(dt == DataType.SNAPSHOT for dt in input_types):
                return DataType.SNAPSHOT
            elif all(dt == DataType.DELTA for dt in input_types):
                return DataType.DELTA
            else:
                return DataType.SNAPSHOT
        else:
            return input_types[0] if input_types else DataType.UNKNOWN

    def _is_df_and_join(self, op: Dict) -> bool:
        """判断 join 是否是 df_and 类型，委托给公共工具函数"""
        from .plan_navigator import is_df_and_join
        return is_df_and_join(op)

    def _get_aggregate_mode(self, op: Dict) -> Optional[str]:
        """
        提取 Aggregate 算子的模式（P1/P2/Final/Complete等）

        Returns:
            模式字符串，如 'Final', 'P1', 'P2', 'Complete' 等
            如果不是 Aggregate 或无法提取模式，返回 None
        """
        # 检查 hashAgg 字段
        if 'hashAgg' in op and isinstance(op['hashAgg'], dict):
            hash_agg = op['hashAgg']

            # 方法1: 检查 hashAgg.stage 字段（顶层 stage）
            stage = hash_agg.get('stage')
            if stage:
                return str(stage)

            # 方法2: 检查 hashAgg.aggregate.aggregateCalls[].stage 字段
            # 这是实际存储 stage 信息的地方
            if 'aggregate' in hash_agg and isinstance(hash_agg['aggregate'], dict):
                aggregate = hash_agg['aggregate']
                if 'aggregateCalls' in aggregate and isinstance(aggregate['aggregateCalls'], list):
                    calls = aggregate['aggregateCalls']
                    if calls and len(calls) > 0:
                        # 取第一个 aggregateCall 的 stage
                        first_call = calls[0]
                        if isinstance(first_call, dict) and 'stage' in first_call:
                            return str(first_call['stage'])

            # 方法3: 回退到 mode 字段（兼容旧格式）
            mode = hash_agg.get('mode')
            if mode:
                return str(mode)

        # 检查 hashAggregate 字段（可能的别名）
        if 'hashAggregate' in op and isinstance(op['hashAggregate'], dict):
            hash_aggregate = op['hashAggregate']

            # 同样的逻辑
            stage = hash_aggregate.get('stage')
            if stage:
                return str(stage)

            if 'aggregate' in hash_aggregate and isinstance(hash_aggregate['aggregate'], dict):
                aggregate = hash_aggregate['aggregate']
                if 'aggregateCalls' in aggregate and isinstance(aggregate['aggregateCalls'], list):
                    calls = aggregate['aggregateCalls']
                    if calls and len(calls) > 0:
                        first_call = calls[0]
                        if isinstance(first_call, dict) and 'stage' in first_call:
                            return str(first_call['stage'])

            mode = hash_aggregate.get('mode')
            if mode:
                return str(mode)

        return None

    def _get_aggregate_functions(self, op: Dict) -> List[str]:
        """
        提取 Aggregate 算子的聚集函数名称列表

        Args:
            op: 算子对象

        Returns:
            聚集函数名称列表，如 ['SUM', 'COUNT', 'MULTI_RANGE_COLLECT']
        """
        functions = []

        # 检查 hashAgg 字段
        if 'hashAgg' in op and isinstance(op['hashAgg'], dict):
            hash_agg = op['hashAgg']
            if 'aggregate' in hash_agg and isinstance(hash_agg['aggregate'], dict):
                aggregate = hash_agg['aggregate']
                if 'aggregateCalls' in aggregate and isinstance(aggregate['aggregateCalls'], list):
                    for call in aggregate['aggregateCalls']:
                        if isinstance(call, dict) and 'function' in call:
                            func_obj = call['function']
                            # 可能的结构：function.function.name 或 function.name
                            if isinstance(func_obj, dict):
                                if 'function' in func_obj and isinstance(func_obj['function'], dict):
                                    func_name = func_obj['function'].get('name')
                                    if func_name:
                                        functions.append(str(func_name))
                                elif 'name' in func_obj:
                                    func_name = func_obj.get('name')
                                    if func_name:
                                        functions.append(str(func_name))

        # 检查 hashAggregate 字段（可能的别名）
        if 'hashAggregate' in op and isinstance(op['hashAggregate'], dict):
            hash_aggregate = op['hashAggregate']
            if 'aggregate' in hash_aggregate and isinstance(hash_aggregate['aggregate'], dict):
                aggregate = hash_aggregate['aggregate']
                if 'aggregateCalls' in aggregate and isinstance(aggregate['aggregateCalls'], list):
                    for call in aggregate['aggregateCalls']:
                        if isinstance(call, dict) and 'function' in call:
                            func_obj = call['function']
                            if isinstance(func_obj, dict):
                                if 'function' in func_obj and isinstance(func_obj['function'], dict):
                                    func_name = func_obj['function'].get('name')
                                    if func_name:
                                        functions.append(str(func_name))
                                elif 'name' in func_obj:
                                    func_name = func_obj.get('name')
                                    if func_name:
                                        functions.append(str(func_name))

        return functions

    def _has_incremental_hint(self, op: Dict) -> bool:
        """
        检查算子是否有增量相关的 hint

        根据 prompt 4.2.1.2 和用户反馈：
        在 plan 整体是增量逻辑时，如果一个算子上标注了是某个算子的增量算法，
        其实可以认为就是 delta。

        Args:
            op: 算子对象

        Returns:
            是否有增量相关的 hint
        """
        try:
            # **性能优化**: 先检查常见的字段，避免不必要的序列化
            # 检查 operator 的 id 字段
            op_id = op.get('id', '')
            if 'Incremental' in str(op_id) or 'DeltaState' in str(op_id):
                return True

            # 检查 hints 字段（如果存在）
            if 'hints' in op:
                hints = op.get('hints', [])
                if hints:
                    hints_str = str(hints)
                    if 'Incremental' in hints_str or 'DeltaState' in hints_str:
                        return True

            # 如果快速检查没有结果，才进行序列化检查
            op_str = json.dumps(op)

            # 检查是否包含增量相关的 hint pattern
            # 注意：这里不检查 'delta' 关键字，因为太宽泛，可能误判
            if 'Incremental' in op_str or 'DeltaState' in op_str:
                return True

            return False
        except Exception:
            return False

    def _get_operator_type(self, op: Dict) -> str:
        """
        获取算子类型

        根据 plan.json 中算子对象的键名来判断类型，而不是通过 json.dumps 查找关键字。
        plan.json 中的算子结构通常是：{"算子类型": {...算子详情...}}

        常见的算子类型键名：
        - tableScan, TableScan: 表扫描
        - join, hashJoin, nestedLoopJoin, broadcastHashJoin: Join 算子
        - hashAgg, hashAggregate: Aggregate 算子
        - calc, Calc: Calc 算子
        - filter, Filter: Filter 算子
        - project, Project: Project 算子
        - union, Union, unionAll: Union 算子
        - window, Window: Window 算子
        - exchange, Exchange: Exchange 算子
        - sort, Sort: Sort 算子
        """
        # 遍历算子对象的顶层键，查找算子类型
        for key in op.keys():
            key_lower = key.lower()

            # Join 类型（包括各种 join 变体）
            if 'join' in key_lower:
                return 'join'

            # Aggregate 类型
            elif 'agg' in key_lower or 'aggregate' in key_lower:
                return 'aggregate'

            # Calc 类型
            elif key_lower == 'calc':
                return 'calc'

            # Filter 类型
            elif key_lower == 'filter':
                return 'filter'

            # Project 类型
            elif key_lower == 'project':
                return 'project'

            # Union 类型
            elif 'union' in key_lower:
                return 'union'

            # Window 类型
            elif key_lower == 'window':
                return 'window'

            # TableScan 类型
            elif 'tablescan' in key_lower:
                return 'tablescan'

            # TableSink 类型
            elif 'tablesink' in key_lower or 'sink' in key_lower:
                return 'tablesink'

            # Exchange 类型
            elif 'exchange' in key_lower:
                return 'exchange'

            # Sort 类型
            elif key_lower == 'sort':
                return 'sort'

        # 如果没有匹配到，返回 unknown
        return 'unknown'

    def _identify_incremental_algorithms_with_subplan(self) -> List[Dict]:
        """
        识别增量算法及其完整 subplan

        根据 prompt 4.2.1.2 和 4.2.1.3 的要求：
        - 4.2.1.2 已经通过 _parse_rule_hints() 找到了相同增量算法的算子
        - 4.2.1.3 需要找到完整的 subplan（包括没有hint的算子）

        Returns:
            增量算法列表，每个算法包含完整的 subplan
        """
        algorithms = []

        # 预先构建所有算子的 hint 归属映射
        operator_hint_map = {}
        for rule_id, indices in self.rule_groups.items():
            for idx in indices:
                operator_hint_map[idx] = rule_id

        # 按照拓扑顺序处理算法（从上游到下游）
        sorted_rule_groups = self._sort_rule_groups_by_topology()

        # 记录已经被分配给某个算法的算子
        assigned_operators = {}

        # ========== 第一个循环：为所有算法构建确定集合 ==========
        # 根据用户反馈："应该先全部遍历一遍增量算法，得到所有的确定性的相关subplan后，再继续后续操作"
        all_confirmed_sets = {}

        for rule_id, rule_op_indices in sorted_rule_groups:
            # 识别算法类型
            algo_type = self._identify_algorithm_type(rule_id)

            # 连通所有hint算子，找到它们之间路径上的所有算子
            # 根据 prompt："这些算子联通(遍历)起来的算子一定属于该算法的subplan一部分"
            confirmed_set = self._connect_hint_operators_for_algorithm(
                set(rule_op_indices), algo_type, rule_id, operator_hint_map
            )

            all_confirmed_sets[rule_id] = {
                'confirmed_set': confirmed_set,
                'algo_type': algo_type,
                'rule_op_indices': rule_op_indices
            }

        # ========== 第二个循环：从确定集合扩展到完整subplan ==========
        for rule_id, rule_op_indices in sorted_rule_groups:
            algo_info = all_confirmed_sets[rule_id]
            confirmed_set = algo_info['confirmed_set']
            algo_type = algo_info['algo_type']

            # 找到目标算子
            target_op_idx = self._find_target_operator(rule_id, rule_op_indices)

            # 从确定集合扩展到完整subplan（使用边界规则）
            subplan_indices = self._find_algorithm_subplan_from_confirmed_set(
                confirmed_set,
                algorithm_type=algo_type,
                current_rule_id=rule_id,
                operator_hint_map=operator_hint_map,
                assigned_operators=assigned_operators
            )

            # 标记这些算子已被分配
            for idx in subplan_indices:
                if idx not in assigned_operators:
                    assigned_operators[idx] = rule_id

            # 判断是否是原始 SQL 的算子
            is_original_sql = self._is_original_sql_operator(algo_type, rule_op_indices)

            # 找到 root 算子
            root_op_idx = self._find_root_operator_index(subplan_indices)

            # 收集算子详细信息
            operator_details = []
            for idx in subplan_indices:
                op = self.operators[idx]
                op_id = self.operator_ids[idx]
                data_type = self.operator_data_types.get(idx, DataType.UNKNOWN)

                operator_details.append({
                    'operator_id': op_id,
                    'operator_type': self._get_operator_type(op),
                    'data_type': data_type.value,
                    'has_hint': (idx in rule_op_indices)
                })

            # 构建完整的 rule_id（RuleName#ID）
            full_rule_name = self.algorithm_id_to_rule_name.get(rule_id, "UnknownRule")
            full_rule_id = f"{full_rule_name}#{rule_id}"

            # 新增：收集所有 TableScan 算子的 append-only 信息
            # 根据 prompt 4.2.1.3.1 新增要求：
            # "每个增量算法得到了自己所有算子后，把所有tablescan算子找出来，
            #  如果全部是appendonly的tablescan，则显示出来，并标注；
            #  如果不全部是，也请显示每个tablescan是不是appendonly；
            #  appendonly信息在4.2.1.5里已经得到，从这里拿"
            tablescan_info = self._collect_tablescan_append_only_info(subplan_indices)

            algorithms.append({
                'type': algo_type,
                'rule_id': full_rule_id,
                'is_original_sql': is_original_sql,
                'operators': [self.operator_ids[idx] for idx in subplan_indices],
                'rule_operators': [self.operator_ids[idx] for idx in rule_op_indices],
                'target_operator_id': self.operator_ids[target_op_idx] if target_op_idx is not None else None,
                'root_operator_id': self.operator_ids[root_op_idx] if root_op_idx is not None else None,
                'operator_details': operator_details,
                'total_operators': len(subplan_indices),
                'tablescan_append_only_info': tablescan_info  # 新增字段
            })

        return algorithms

    def _connect_hint_operators_for_algorithm(self, hint_operators: Set[int],
                                              algorithm_type: str,
                                              current_rule_id: str,
                                              operator_hint_map: Dict) -> Set[int]:
        """
        连通所有hint算子，找到它们之间路径上的所有算子

        **关键修复**（根据用户反馈）：
        - 只连通**有 ID 的 hint 算子**（即已经在 rule_groups 中的算子）
        - 没有 ID 的 hint 算子不应该在这个阶段参与连通性检查
        - 它们会在 _assign_hints_without_id_to_algorithms 中被处理

        根据 prompt 4.2.1.3 第 69 行：
        "这些算子联通(遍历)起来的算子一定属于该算法的subplan一部分
        （即，类似有N个点组成的一个图，点中间的所有算子肯定属于该增量算法）"

        Args:
            hint_operators: hint算子集合（应该只包含有ID的hint算子）
            algorithm_type: 算法类型
            current_rule_id: 当前算法ID
            operator_hint_map: 算子到hint的映射

        Returns:
            扩展后的确定集合（包含所有连通路径上的算子）
        """
        confirmed_set = set(hint_operators)
        hint_list = list(hint_operators)

        # **关键修复**：只连通有 ID 的 hint 算子
        # 过滤掉没有 ID 的 hint 算子（它们在 operator_rule_names 中但不在 rule_groups 中）
        hint_list_with_id = [idx for idx in hint_list if idx in operator_hint_map and operator_hint_map[idx] == current_rule_id]

        logger.debug(f"算法 {current_rule_id} 连通性分析:")
        logger.debug(f"  hint_operators (原始): {len(hint_operators)} 个")
        logger.debug(f"  hint_list_with_id (过滤后): {len(hint_list_with_id)} 个")

        # 找到所有hint算子之间的连通路径
        for i in range(len(hint_list_with_id)):
            for j in range(i + 1, len(hint_list_with_id)):
                idx1, idx2 = hint_list_with_id[i], hint_list_with_id[j]

                # 检查是否有连通路径（使用边界逻辑）
                if self._has_path_between(idx1, idx2, max_depth=20, 
                                         algorithm_type=algorithm_type,
                                         current_rule_id=current_rule_id,
                                         operator_hint_map=operator_hint_map):
                    # 找到路径上的所有算子（使用边界逻辑）
                    path_operators = self._find_all_paths_between(idx1, idx2, max_depth=20,
                                                                  algorithm_type=algorithm_type,
                                                                  current_rule_id=current_rule_id,
                                                                  operator_hint_map=operator_hint_map)
                    
                    logger.debug(f"  找到连通路径: {self.operator_ids.get(idx1)} <-> {self.operator_ids.get(idx2)}, 包含 {len(path_operators)} 个算子")
                    confirmed_set.update(path_operators)

        logger.debug(f"  最终确定集合: {len(confirmed_set)} 个算子")
        return confirmed_set

    def _sort_rule_groups_by_topology(self) -> List[tuple]:
        """
        按照拓扑顺序对 rule groups 排序

        返回排序后的 (rule_id, indices) 列表
        上游算法排在前面，下游算法排在后面
        """
        rule_order = []
        for rule_id, indices in self.rule_groups.items():
            # 使用算法中最小的算子索引作为排序依据
            min_idx = min(indices) if indices else float('inf')
            rule_order.append((min_idx, rule_id, indices))

        # 按照最小索引排序
        rule_order.sort(key=lambda x: x[0])

        return [(rule_id, indices) for _, rule_id, indices in rule_order]

    def _identify_algorithm_type(self, rule_id: str) -> str:
        """
        从 rule 名称推断算法类型
        
        Args:
            rule_id: 算法 ID（如 #5398716）或完整 rule 名称
            
        Returns:
            算法类型：'aggregate', 'join', 'window', 或 'unknown'
        """
        # 如果 rule_id 是算法 ID（如 #5398716），从映射中获取完整 rule 名称
        rule_name = self.algorithm_id_to_rule_name.get(rule_id, rule_id)
        
        # 从 rule 名称中推断类型
        if 'Aggregate' in rule_name or 'Agg' in rule_name:
            return 'aggregate'
        elif 'Join' in rule_name:
            return 'join'
        elif 'Window' in rule_name:
            return 'window'
        else:
            return 'unknown'

    def _find_target_operator(self, rule_id: str, rule_op_indices: List[int]) -> Optional[int]:
        """找到目标算子（被优化的原始算子）"""
        # 从 Rule ID 中提取目标算子 ID
        target_op_id = self._extract_target_operator_id(rule_id)
        if target_op_id and target_op_id in self.id_to_index:
            return self.id_to_index[target_op_id]
        return None

    def _extract_target_operator_id(self, rule_id: str) -> Optional[str]:
        """
        从 Rule ID 中提取目标算子 ID

        关键修复（根据用户反馈）：
        - rule_id 现在是 "RuleName#ID" 格式（如 IncrementalJoinWithoutCondenseRule#5398716）
        - 提取 # 后面的数字部分

        例如：
        - IncrementalJoinWithoutCondenseRule#31766669 -> 31766669
        - IncrementalAggregateSetDeltaRule#5399145 -> 5399145
        - IncrementalLinearFunctionAggregateRule (没有 ID) -> None

        Returns:
            目标算子的 ID，如果没有则返回 None
        """
        # 查找 # 后面的数字
        match = re.search(r'#(\d+)', rule_id)
        if match:
            return match.group(1)
        return None

    def _find_algorithm_subplan_from_confirmed_set(self, confirmed_set: Set[int],
                                                    algorithm_type: str = None,
                                                    current_rule_id: str = None,
                                                    operator_hint_map: Dict = None,
                                                    assigned_operators: Dict = None) -> List[int]:
        """
        阶段2：从确定集合扩展到完整subplan

        这个方法接收阶段1构建好的确定集合，使用边界规则向上下游扩展

        Args:
            confirmed_set: 确定集合（阶段1构建的hint算子联通图）
            algorithm_type: 算法类型
            current_rule_id: 当前算法的 rule ID
            operator_hint_map: 算子到 hint 的映射
            assigned_operators: 已分配的算子映射

        Returns:
            完整 subplan 的所有算子索引列表
        """
        if operator_hint_map is None:
            operator_hint_map = {}
        if assigned_operators is None:
            assigned_operators = {}

        # 从确定集合开始，这些算子已经确定属于该算法
        subplan = set(confirmed_set)
        current_algo_hint_indices = confirmed_set

        def should_stop_at_operator(idx: int, direction: str = 'any') -> bool:
            """
            判断是否应该在此算子停止遍历

            停止条件（按优先级排序）：
            1. ⚠️ 算子包含 DeletePlan hint（最高优先级 - DeletePlan 不属于任何增量算法）
            2. 算子有不同的 hint（属于其他增量算法）
            3. 算子已被其他算法占用（除了 TableScan）
            4. 对于 aggregate 算法，遇到非起始点的 Final/Complete Aggregate
            5. ⚠️ Snapshot 边界：向上游遍历时，如果当前是 snapshot 且上游也是 snapshot，必须终止
            6. ⚠️ 邻居边界：如果当前算子的所有邻居（在遍历方向上）都属于其他算法，则当前算子是边界

            Args:
                idx: 算子索引
                direction: 遍历方向 ('down'=向上游, 'up'=向下游, 'any'=任意方向)
            """
            if idx < 0 or idx >= len(self.operators):
                return True

            # 条件 1: ⚠️ 检查是否包含 DeletePlan hint（最高优先级）
            # 根据 prompt original_prompt.md 第 60 行：
            # "如果是deleteplan相关算子应该不能继续查找，因为它不属于任何增量算法，
            #  由于plan是执行路径肯定不能跳过，所以不能继续找"
            #
            # 语义理解：
            # - DeletePlan 算子在执行路径中表示删除操作
            # - 如果遇到 DeletePlan，说明这条路径包含删除逻辑
            # - 必须终止遍历，不能跳过后继续查找（否则 subplan 不完整）
            #
            # ⚠️ 重要：这个检查必须在所有其他检查之前，因为 DeletePlan hint 在 _parse_rule_hints() 中被过滤了
            #         所以 DeletePlan 算子不在 operator_hint_map 中，条件 2 不会触发
            op = self.operators[idx]
            op_str = json.dumps(op)
            if 'deleteplan' in op_str.lower() or 'delete_plan' in op_str.lower():
                # 检查是否真的包含 DeletePlan Rule hint
                rule_pattern = r'Rule:([A-Za-z0-9_:#,\-()]+)'
                matches = re.findall(rule_pattern, op_str)
                for rule_name in matches:
                    if 'deleteplan' in rule_name.lower() or 'delete_plan' in rule_name.lower():
                        # 遇到 DeletePlan 算子，必须终止遍历
                        return True

            # 条件 2: 检查是否有不同的 hint
            if idx in operator_hint_map:
                hint_rule_id = operator_hint_map[idx]
                # 打印其他算法的 hint
                # print(f'xxxxxxxx operator {idx} hint: {hint_rule_id}')
                if hint_rule_id != current_rule_id:
                    return True

            # 条件 3: 检查是否已被其他算法占用
            if idx in assigned_operators:
                assigned_rule_id = assigned_operators[idx]
                if assigned_rule_id != current_rule_id:
                    # TableScan 可以被多个算法共享
                    op_id = self.operator_ids.get(idx, '')
                    is_table_scan = 'TableScan' in op_id or 'tablescan' in op_id.lower()
                    if not is_table_scan:
                        return True

            # debug： 如果rule id是Rule:IncrementalJoinWithoutCondenseRule_cz::optimizer::LogicalJoin#31766934，则打印信息
            # if current_rule_id == 'IncrementalJoinWithoutCondenseRule_cz::optimizer::LogicalJoin#31766934':
            #     print(f'{algorithm_type} xxxxxxxx operator {idx} rule id: {self.operators[idx]}, {self._get_operator_type(op), self._get_aggregate_mode(op)}')

            # 条件 4: 对于 aggregate 算法，检查 Final/Complete
            # **关键修改**（根据用户反馈和 prompt 4.2.1.3 第 69 行）：
            # - 没有 #ID 的 hint 应该向下游找匹配的 hint
            # - 没有 #ID 的 hint 向上游找一般就是边界
            # - 多个相同的 hint（属于同一增量算法）需要能联通
            # - 上下游要一个一个找，A 到 B 中间可能有 N 多个算子
            #
            # 实现逻辑：
            # 1. 如果当前算子是 Final/Complete aggregate 且不在起始点中
            # 2. 检查当前算子是否有相同类型的 rule hint（没有 #ID 的 hint）
            # 3. 如果有相同的 rule hint，不作为边界（这些算子应该联通）
            # 4. 如果没有相同的 rule hint，递归检查下游是否有相同算法的 hint（带 #ID 的）
            # 5. 如果下游有相同算法的 hint（带 #ID），说明它们是连通的，不应该作为边界
            # 6. 如果下游没有相同算法的 hint，作为边界
            if algorithm_type == 'aggregate' and idx not in current_algo_hint_indices:
                op = self.operators[idx]
                op_type = self._get_operator_type(op)
                if op_type == 'aggregate':
                    agg_mode = self._get_aggregate_mode(op)
                    if agg_mode in ['Final', 'Complete', 'FINAL', 'COMPLETE']:
                        # 检查当前算子是否有相同类型的 rule hint（没有 #ID 的 hint）
                        current_rule_name = self.operator_rule_names.get(idx)
                        algo_rule_name = self.algorithm_id_to_rule_name.get(current_rule_id)
                        
                        if current_rule_name and algo_rule_name and current_rule_name == algo_rule_name:
                            # 当前算子有相同的 rule hint（没有 #ID），不作为边界
                            # 这种情况下，算子应该属于当前算法
                            return False
                        
                        # 当前算子没有 hint，或者 hint 不匹配
                        # 递归检查下游是否有相同类型的 hint（带 #ID 的）
                        # 如果有，说明它们是连通的，不应该作为边界
                        # 注意：只检查下游，不检查上游（根据用户反馈）
                        if algo_rule_name:
                            # BFS 向下游查找相同的 rule hint（带 #ID 的）
                            if self._has_downstream_with_algorithm_id(idx, current_rule_id, max_depth=10):
                                # 下游有相同算法的 hint（带 #ID），不作为边界
                                return False
                        
                        # 没有相同的 rule hint，作为边界
                        return True

            # 条件 5: ⚠️ Snapshot 边界检查（仅在向上游遍历时）
            # 根据 prompt original_prompt.md 第 70 行：
            # "对于snapshot的算子，向上游遍历时如果遇到上游也是snapshot，必须终止，
            #  因为snapshot表示完整状态，其上游的snapshot不应该再属于增量算法一部分"
            #
            # 语义理解：
            # - 如果当前算子是 snapshot，向上游遍历时遇到上游也是 snapshot，应该终止
            # - 因为 snapshot 表示完整状态，其上游的 snapshot 不应该属于增量算法
            # - 这是边界条件，不能跳过继续查找（否则 subplan 不完整）
            #
            # 实现逻辑：
            # - 检查当前算子的上游（输入）是否是 snapshot
            # - 如果当前是 snapshot 且上游也是 snapshot，则当前算子作为边界，不继续向上游遍历
            if direction == 'down':  # 向上游遍历
                current_data_type = self.operator_data_types.get(idx, DataType.UNKNOWN)
                if current_data_type == DataType.SNAPSHOT:
                    # 检查上游是否也是 snapshot
                    for input_idx in self.operator_dependencies.get(idx, []):
                        input_data_type = self.operator_data_types.get(input_idx, DataType.UNKNOWN)
                        if input_data_type == DataType.SNAPSHOT:
                            # 上游是 snapshot，当前算子作为边界，终止遍历
                            return True

            # 条件 6: ⚠️ Calc 算子的 DeltaState 和 Incremental hint 边界检查
            # 根据 prompt original_prompt.md 第 71 行：
            # "如果是calc有hint，且hint包含了DeltaState和Incremental这些也需要终止，避免跨越算法边界；
            #  如，类似HINT=delta,DeltaState:[1,14] - [1,43]_IncrementalJoinWithoutCondenseRule#cz::optimizer::LogicalJoin#973"
            #
            # 语义理解：
            # - Calc 算子如果包含 DeltaState 和 Incremental 相关的 hint，说明它是某个增量算法的边界
            # - 这种 hint 通常表示状态计算的边界，不应该跨越到其他算法
            # - 需要检查 hint 中是否同时包含 "DeltaState" 和 "Incremental" 关键字
            #
            # 实现逻辑：
            # - 检查算子是否是 calc 类型
            # - 检查算子的 hint 中是否同时包含 "DeltaState" 和 "Incremental"
            # - 如果满足条件，则作为边界，但在 bottom-up 遍历时应该包含该算子
            # - 返回特殊标记 'calc_boundary' 而不是 True/False
            #
            # 注意：Calc 边界检查需要特殊处理，已单独提取到 is_calc_boundary 函数中
            # 在 dfs 遍历函数中会调用该函数进行检查

            # 所有边界条件检查完毕，当前算子不是边界
            return False

        def is_calc_boundary(idx: int) -> bool:
            """
            检查是否是 Calc 边界算子（包含 DeltaState 和 Incremental hint）

            这种算子应该被包含在 subplan 中，但不继续向上游或下游遍历
            
            **重要修正**：只有当 Calc 算子包含 DeltaState hint 且该 hint 指向**其他算法**时，
            才应该作为边界。如果 DeltaState hint 指向当前算法，则不应该作为边界。
            """
            if idx < 0 or idx >= len(self.operators):
                return False

            op = self.operators[idx]
            op_type = self._get_operator_type(op)

            if op_type == 'calc':
                op_str = json.dumps(op)
                # 检查是否同时包含 DeltaState 和 Incremental 关键字
                if 'DeltaState' in op_str and 'Incremental' in op_str:
                    # 检查是否匹配特定的 hint 模式
                    # 示例格式：DeltaState:[1,14] - [1,43]_IncrementalJoinWithoutCondenseRule#...
                    hint_pattern = r'DeltaState:.*?Incremental'
                    if re.search(hint_pattern, op_str, re.IGNORECASE | re.DOTALL):
                        # **关键修正**：检查 DeltaState hint 是否指向当前算法
                        # 如果 hint 中包含当前算法的 ID，则不应该作为边界
                        # 提取当前算法的 ID（从 current_rule_id 中提取）
                        current_algo_id = current_rule_id  # current_rule_id 已经是纯 ID 格式
                        
                        # 检查 op_str 中是否包含当前算法的 ID
                        # 格式可能是：DeltaState:...IncrementalXxxRule#...#5402883
                        if f'#{current_algo_id}' in op_str:
                            # DeltaState hint 指向当前算法，不应该作为边界
                            return False
                        else:
                            # DeltaState hint 指向其他算法，应该作为边界
                            return True

            return False

        def is_df_aggregate(idx: int) -> bool:
            """
            检查是否是 DF (Dynamic Filter) Aggregate 算子

            根据 prompt original_prompt.md 第 80 行：
            "增量算法查找算子时,如果碰到aggregate,且aggregate的聚集函数包括MULTI_RANGE_COLLECT或者_DF_BF_COLLECT,
             则终止,不需要添加到subplan里,因为这个是一个df的aggregate,仅仅是优化的一个plan,不需要添加"

            这是一个排除边界：不添加到 subplan，直接返回

            Args:
                idx: 算子索引

            Returns:
                是否是 DF aggregate 算子
            """
            if idx < 0 or idx >= len(self.operators):
                return False

            op = self.operators[idx]
            op_type = self._get_operator_type(op)

            # 必须是 aggregate 类型
            if op_type != 'aggregate':
                return False

            # 检查聚集函数
            # 从 hashAgg 或 hashAggregate 中提取聚集函数
            agg_functions = self._get_aggregate_functions(op)

            # 检查是否包含 DF 相关的聚集函数
            df_functions = {'MULTI_RANGE_COLLECT', '_DF_BF_COLLECT', 'DF_BF_COLLECT', 'BF_COLLECT'}

            for func_name in agg_functions:
                if func_name.upper() in df_functions:
                    return True

            return False

        def dfs_down(idx: int, visited: set):
            """向下搜索：找所有输入算子（向上游遍历）"""
            if idx in visited:
                return

            # ⚠️ 步骤1: 先检查"排除边界"（DeletePlan 和 DF Aggregate）- 不添加到subplan
            # 根据 prompt 第 76 行：deleteplan 不需要添加到 subplan 里
            # 根据 prompt 第 80 行：DF aggregate 不需要添加到 subplan 里
            if self._is_deleteplan_operator(idx):
                # DeletePlan 算子不添加到 subplan，直接返回
                return

            if is_df_aggregate(idx):
                # DF Aggregate 算子不添加到 subplan，直接返回
                return

            # ⚠️ 步骤2: 添加到 subplan（在检查其他边界之前）
            visited.add(idx)
            
            # 记录扩展的算子（仅在 debug 级别）
            if idx not in confirmed_set:
                op_id = self.operator_ids.get(idx)
                logger.debug(f"    dfs_down 扩展: {op_id}")
            
            subplan.add(idx)

            # ⚠️ 步骤3: 检查"包含边界"（需要添加但不继续遍历）
            # 根据 prompt 第 73-78 行：
            # - 不同hint：添加到subplan，但终止遍历
            # - final/complete：添加到subplan，但终止遍历
            # - snapshot：添加到subplan，但终止遍历
            # - calc边界：添加到subplan，但终止遍历

            # 检查是否是 Calc 边界算子
            if is_calc_boundary(idx):
                # Calc 边界：包含它但不继续向上游遍历
                return

            # 检查其他包含边界条件
            if should_stop_at_operator(idx, direction='down'):
                # 包含边界：已添加到 subplan，但不继续遍历
                return

            # ⚠️ 步骤4: 继续向上游遍历
            # 递归访问所有输入算子
            for input_idx in self.operator_dependencies.get(idx, []):
                # 先检查输入算子是否是排除边界（DeletePlan 或 DF Aggregate）
                if self._is_deleteplan_operator(input_idx) or is_df_aggregate(input_idx):
                    # 排除边界：不添加到 subplan，也不继续遍历
                    continue

                # 检查输入算子是否有不同的 hint
                # **关键修复**：同时检查 operator_hint_map（有ID的hint）和 operator_rule_names（所有hint）
                if input_idx in operator_hint_map:
                    input_hint = operator_hint_map[input_idx]
                    if input_hint != current_rule_id:
                        # 输入算子属于其他算法，不要继续遍历
                        continue
                
                # **新增检查**：如果算子有 hint（在 operator_rule_names 中）但没有 ID，
                # 说明它应该属于其他算法，不应该被当前算法包含
                if input_idx in self.operator_rule_names:
                    # 这个算子有 hint 但没有 ID，它应该向下游查找匹配的算法
                    # 不应该被当前算法包含（除非它已经被分配给当前算法）
                    if input_idx not in operator_hint_map or operator_hint_map.get(input_idx) != current_rule_id:
                        continue

                # 继续遍历
                dfs_down(input_idx, visited)

        def dfs_up(idx: int, visited: set, stop_at_final_agg: bool = False):
            """向上搜索：找所有输出算子（向下游遍历）"""
            if idx in visited:
                return

            # ⚠️ 步骤1: 先检查"排除边界"（DeletePlan 和 DF Aggregate）- 不添加到subplan
            # 根据 prompt 第 76 行：deleteplan 不需要添加到 subplan 里
            # 根据 prompt 第 80 行：DF aggregate 不需要添加到 subplan 里
            if self._is_deleteplan_operator(idx):
                # DeletePlan 算子不添加到 subplan，直接返回
                return

            if is_df_aggregate(idx):
                # DF Aggregate 算子不添加到 subplan，直接返回
                return

            # ⚠️ 步骤2: 添加到 subplan（在检查其他边界之前）
            visited.add(idx)
            
            # 记录扩展的算子（仅在 debug 级别）
            if idx not in confirmed_set:
                op_id = self.operator_ids.get(idx)
                logger.debug(f"    dfs_up 扩展: {op_id}")
            
            subplan.add(idx)

            # ⚠️ 步骤3: 检查"包含边界"（需要添加但不继续遍历）
            # 根据 prompt 第 73-78 行：
            # - 不同hint：添加到subplan，但终止遍历
            # - final/complete：添加到subplan，但终止遍历
            # - snapshot：添加到subplan，但终止遍历
            # - calc边界：添加到subplan，但终止遍历

            # 检查是否是 Calc 边界算子
            if is_calc_boundary(idx):
                # Calc 边界：包含它但不继续向下游遍历
                return

            # 检查其他包含边界条件
            if should_stop_at_operator(idx, direction='up'):
                # 包含边界：已添加到 subplan，但不继续遍历
                return

            # 检查是否是 Final/Complete Aggregate
            is_final_agg = False
            if stop_at_final_agg and algorithm_type == 'aggregate':
                op = self.operators[idx]
                op_type = self._get_operator_type(op)
                if op_type == 'aggregate':
                    agg_mode = self._get_aggregate_mode(op)
                    if agg_mode in ['Final', 'Complete', 'FINAL', 'COMPLETE']:
                        is_final_agg = True

            # ⚠️ 步骤4: 继续向下游遍历
            # 递归访问所有依赖当前算子的算子
            for output_idx in self.operator_dependents.get(idx, []):
                # 先检查输出算子是否是排除边界（DeletePlan 或 DF Aggregate）
                if self._is_deleteplan_operator(output_idx) or is_df_aggregate(output_idx):
                    # 排除边界：不添加到 subplan，也不继续遍历
                    continue

                # 检查输出算子是否有不同的 hint
                # **关键修复**：同时检查 operator_hint_map（有ID的hint）和 operator_rule_names（所有hint）
                if output_idx in operator_hint_map:
                    output_hint = operator_hint_map[output_idx]
                    if output_hint != current_rule_id:
                        # 输出算子属于其他算法，不要继续遍历
                        continue
                
                # **新增检查**：如果算子有 hint（在 operator_rule_names 中）但没有 ID，
                # 说明它应该属于其他算法，不应该被当前算法包含
                if output_idx in self.operator_rule_names:
                    # 这个算子有 hint 但没有 ID，它应该向下游查找匹配的算法
                    # 不应该被当前算法包含（除非它已经被分配给当前算法）
                    if output_idx not in operator_hint_map or operator_hint_map.get(output_idx) != current_rule_id:
                        output_op_id = self.operator_ids.get(output_idx)
                        output_rule_name = self.operator_rule_names.get(output_idx)
                        logger.debug(f"    dfs_up 边界: {output_op_id} 有无ID的hint ({output_rule_name})，停止遍历")
                        continue

                # 继续遍历
                if is_final_agg:
                    next_op = self.operators[output_idx]
                    next_op_type = self._get_operator_type(next_op)
                    if next_op_type != 'aggregate':
                        dfs_up(output_idx, visited, stop_at_final_agg)
                else:
                    dfs_up(output_idx, visited, stop_at_final_agg)

        # 从确定集合的所有算子开始双向搜索（阶段2的扩展）
        visited_down = set()
        visited_up = set()

        need_final_agg = (algorithm_type == 'aggregate')

        # 注意：从确定集合出发，而不是仅从start_indices
        for idx in confirmed_set:
            dfs_down(idx, visited_down)
            dfs_up(idx, visited_up, stop_at_final_agg=need_final_agg)

        return sorted(list(subplan))

    def _find_downstream_with_id_and_same_type(self, start_idx: int, target_rule_id: str,
                                                algorithm_type: str, operator_hint_map: Dict,
                                                max_depth: int = 10) -> Optional[int]:
        """
        向下游查找第一个带ID且同类的增量算法算子

        Args:
            start_idx: 起始算子索引
            target_rule_id: 目标算法ID
            algorithm_type: 算法类型（aggregate/join/window）
            operator_hint_map: 算子到hint的映射
            max_depth: 最大搜索深度

        Returns:
            找到的算子索引，如果没找到返回None
        """
        visited = set()
        queue = [(start_idx, 0)]

        while queue:
            current_idx, depth = queue.pop(0)

            if current_idx in visited:
                continue
            visited.add(current_idx)

            if depth > max_depth:
                continue

            # 跳过起始节点
            if current_idx != start_idx:
                # 检查是否是带ID的同类算子
                if current_idx in operator_hint_map and operator_hint_map[current_idx] == target_rule_id:
                    op_type = self._get_operator_type(self.operators[current_idx])
                    if op_type == algorithm_type:
                        return current_idx

            # 继续向下游查找
            for dependent_idx in self.operator_dependents.get(current_idx, []):
                if dependent_idx not in visited:
                    queue.append((dependent_idx, depth + 1))

        return None

    def _find_all_paths_between(self, from_idx: int, to_idx: int, max_depth: int = 20,
                                algorithm_type: str = None, current_rule_id: str = None,
                                operator_hint_map: Dict = None) -> Set[int]:
        """
        找到两个算子之间所有路径上的算子

        **关键修复**：使用与 dfs_down/dfs_up 相同的边界处理逻辑

        Args:
            from_idx: 起始算子索引
            to_idx: 目标算子索引
            max_depth: 最大搜索深度
            algorithm_type: 算法类型（用于边界检查）
            current_rule_id: 当前算法ID（用于边界检查）
            operator_hint_map: 算子到hint的映射（用于边界检查）

        Returns:
            路径上的所有算子索引集合
        """
        if operator_hint_map is None:
            operator_hint_map = {}

        path_operators = set()
        
        # 使用BFS找到所有路径
        queue = [(from_idx, 0, [from_idx])]  # (current_idx, depth, path)
        all_paths = []

        while queue:
            current_idx, depth, path = queue.pop(0)

            if depth > max_depth:
                continue

            if current_idx == to_idx:
                # 找到目标，记录这条路径
                all_paths.append(path)
                continue

            # 检查是否应该停止（使用与 dfs 相同的边界逻辑）
            if self._should_stop_at_boundary(current_idx, algorithm_type, current_rule_id, operator_hint_map):
                continue

            # 双向查找：向上游和向下游
            neighbors = []
            neighbors.extend(self.operator_dependencies.get(current_idx, []))
            neighbors.extend(self.operator_dependents.get(current_idx, []))

            for neighbor_idx in neighbors:
                if neighbor_idx not in path:  # 避免循环
                    # 检查邻居是否是排除边界
                    if self._is_deleteplan_operator(neighbor_idx):
                        continue
                    
                    # 检查邻居是否有不同的 hint
                    if neighbor_idx in operator_hint_map:
                        neighbor_hint = operator_hint_map[neighbor_idx]
                        if current_rule_id and neighbor_hint != current_rule_id:
                            continue
                    
                    new_path = path + [neighbor_idx]
                    queue.append((neighbor_idx, depth + 1, new_path))

        # 合并所有路径上的算子
        for path in all_paths:
            path_operators.update(path)

        return path_operators

    def _has_path_between(self, from_idx: int, to_idx: int, max_depth: int = 20,
                         algorithm_type: str = None, current_rule_id: str = None,
                         operator_hint_map: Dict = None) -> bool:
        """
        检查两个算子之间是否存在路径

        **关键修复**：使用与 dfs_down/dfs_up 相同的边界处理逻辑

        Args:
            from_idx: 起始算子索引
            to_idx: 目标算子索引
            max_depth: 最大搜索深度
            algorithm_type: 算法类型（用于边界检查）
            current_rule_id: 当前算法ID（用于边界检查）
            operator_hint_map: 算子到hint的映射（用于边界检查）

        Returns:
            如果存在路径返回True，否则返回False
        """
        if operator_hint_map is None:
            operator_hint_map = {}

        visited = set()
        queue = [(from_idx, 0)]

        while queue:
            current_idx, depth = queue.pop(0)

            if current_idx == to_idx:
                return True

            if depth > max_depth:
                continue

            if current_idx in visited:
                continue
            visited.add(current_idx)

            # 检查是否应该停止（使用与 dfs 相同的边界逻辑）
            if self._should_stop_at_boundary(current_idx, algorithm_type, current_rule_id, operator_hint_map):
                continue

            # 双向查找：向上游和向下游
            neighbors = []
            neighbors.extend(self.operator_dependencies.get(current_idx, []))
            neighbors.extend(self.operator_dependents.get(current_idx, []))

            for neighbor_idx in neighbors:
                if neighbor_idx not in visited:
                    # 检查邻居是否是排除边界
                    if self._is_deleteplan_operator(neighbor_idx):
                        continue
                    
                    # 检查邻居是否有不同的 hint
                    if neighbor_idx in operator_hint_map:
                        neighbor_hint = operator_hint_map[neighbor_idx]
                        if current_rule_id and neighbor_hint != current_rule_id:
                            continue
                    
                    queue.append((neighbor_idx, depth + 1))

        return False

    def _should_stop_at_boundary(self, idx: int, algorithm_type: str = None,
                                 current_rule_id: str = None, operator_hint_map: Dict = None) -> bool:
        """
        统一的边界检查逻辑（与 dfs_down/dfs_up 中的 should_stop_at_operator 一致）

        Args:
            idx: 算子索引
            algorithm_type: 算法类型
            current_rule_id: 当前算法ID
            operator_hint_map: 算子到hint的映射

        Returns:
            如果应该停止返回True，否则返回False
        """
        if operator_hint_map is None:
            operator_hint_map = {}

        if idx < 0 or idx >= len(self.operators):
            return True

        # 条件 1: 检查是否包含 DeletePlan hint
        if self._is_deleteplan_operator(idx):
            return True

        # 条件 2: 检查是否有不同的 hint
        if idx in operator_hint_map:
            hint_rule_id = operator_hint_map[idx]
            if current_rule_id and hint_rule_id != current_rule_id:
                return True

        # 条件 3: 对于 aggregate 算法，检查 Final/Complete
        if algorithm_type == 'aggregate':
            op = self.operators[idx]
            op_type = self._get_operator_type(op)
            if op_type == 'aggregate':
                agg_mode = self._get_aggregate_mode(op)
                if agg_mode in ['Final', 'Complete', 'FINAL', 'COMPLETE']:
                    # 检查是否有相同的 rule hint
                    current_rule_name = self.operator_rule_names.get(idx)
                    algo_rule_name = self.algorithm_id_to_rule_name.get(current_rule_id) if current_rule_id else None
                    
                    if current_rule_name and algo_rule_name and current_rule_name == algo_rule_name:
                        return False
                    
                    # 检查下游是否有相同算法
                    if algo_rule_name and current_rule_id:
                        if self._has_downstream_with_algorithm_id(idx, current_rule_id, max_depth=10):
                            return False
                    
                    return True

        return False

    def _has_downstream_same_rule(self, start_idx: int, target_rule_name: str, max_depth: int = 10) -> bool:
        """
        BFS 向下游查找是否有相同的 rule hint（没有 #ID 的）
        
        Args:
            start_idx: 起始算子索引
            target_rule_name: 目标 rule 名称
            max_depth: 最大搜索深度
        
        Returns:
            如果下游有相同的 rule hint，返回 True；否则返回 False
        """
        visited = set()
        queue = [(start_idx, 0)]  # (operator_index, depth)
        
        while queue:
            current_idx, depth = queue.pop(0)
            
            if current_idx in visited:
                continue
            visited.add(current_idx)
            
            # 检查深度限制
            if depth > max_depth:
                continue
            
            # 检查当前算子是否有相同的 rule hint
            current_rule_name = self.operator_rule_names.get(current_idx)
            if current_rule_name == target_rule_name:
                return True
            
            # 继续向下游查找
            for dependent_idx in self.operator_dependents.get(current_idx, []):
                if dependent_idx not in visited:
                    queue.append((dependent_idx, depth + 1))
        
        return False

    def _has_downstream_with_algorithm_id(self, start_idx: int, target_algorithm_id: str, max_depth: int = 10) -> bool:
        """
        BFS 向下游查找是否有相同算法 ID 的 hint（带 #ID 的）

        这个函数用于检查一个没有 #ID 的 hint 算子，其下游是否有带 #ID 的相同算法 hint。
        如果有，说明这个算子应该属于该算法。

        **实现 prompt 4.2.1.3 第 69 行的新增逻辑**：
        "对于一些没有找到 id 的 rule hint 应该往自己下游继续查找，找到第一个带有 id 且同类
        （是指是相同算子，如，都是 agg/window/join 等）的增量算法，这些算子联通(遍历)起来的
        算子一定属于该算法的 subplan 一部分"

        使用场景：
        - 在边界检测时，如果遇到 Final/Complete aggregate 但没有 #ID
        - 检查其下游是否有相同算法的 hint（带 #ID）
        - 如果有，说明它们是连通的，不应该作为边界

        Args:
            start_idx: 起始算子索引
            target_algorithm_id: 目标算法 ID（如 "5402883"）
            max_depth: 最大搜索深度

        Returns:
            如果下游有相同算法 ID 的 hint，返回 True；否则返回 False
        """
        visited = set()
        queue = [(start_idx, 0)]  # (operator_index, depth)
        
        while queue:
            current_idx, depth = queue.pop(0)
            
            if current_idx in visited:
                continue
            visited.add(current_idx)
            
            # 检查深度限制
            if depth > max_depth:
                continue
            
            # 检查当前算子是否属于目标算法（在 rule_groups 中）
            for rule_id, indices in self.rule_groups.items():
                if rule_id == target_algorithm_id and current_idx in indices:
                    # 找到了属于目标算法的算子
                    return True
            
            # 继续向下游查找
            for dependent_idx in self.operator_dependents.get(current_idx, []):
                if dependent_idx not in visited:
                    queue.append((dependent_idx, depth + 1))
        
        return False

    def _find_root_operator_index(self, subplan_indices: List[int]) -> Optional[int]:
        """
        找到 subplan 中的 root 算子（最上层算子）

        根据 prompt 4.2.1.3：找到算子对应的 root 阶段

        逻辑：
        - Root 算子是 subplan 中没有后继的算子（在 subplan 内部）
        - 或者是索引最大的算子（最后执行的算子）
        """
        if not subplan_indices:
            return None

        subplan_set = set(subplan_indices)

        # 找到没有后继节点的算子（在 subplan 内部）
        for idx in reversed(subplan_indices):
            dependents = self.operator_dependents.get(idx, [])
            # 检查是否有后继节点在 subplan 内
            has_dependent_in_subplan = any(dep in subplan_set for dep in dependents)
            if not has_dependent_in_subplan:
                return idx

        # 如果都有后继，返回索引最大的
        return max(subplan_indices)

    def _is_original_sql_operator(self, algo_type: str, op_indices: List[int]) -> bool:
        """
        判断是否是原始 SQL 的算子（4.2.1.2）

        如果 rule 出现在对应类型的算子上，则是原始 SQL
        """
        for idx in op_indices:
            if idx >= len(self.operators):
                continue

            op = self.operators[idx]
            op_type = self._get_operator_type(op)

            if op_type == algo_type:
                return True

        return False

    def _collect_tablescan_append_only_info(self, subplan_indices: List[int]) -> Dict:
        """
        收集增量算法中所有 TableScan 算子的 append-only 信息
        
        根据 prompt 4.2.1.3.1 新增要求：
        "每个增量算法得到了自己所有算子后，把所有tablescan算子找出来，
         如果全部是appendonly的tablescan，则显示出来，并标注；
         如果不全部是，也请显示每个tablescan是不是appendonly；
         appendonly信息在4.2.1.5里已经得到，从这里拿"
        
        Args:
            subplan_indices: 增量算法的所有算子索引列表
            
        Returns:
            {
                'has_tablescans': bool,  # 是否包含 TableScan
                'all_append_only': bool,  # 是否所有 TableScan 都是 append-only
                'tablescans': [
                    {
                        'operator_id': str,
                        'operator_index': int,
                        'table_name': str,  # 表名
                        'data_type': str,  # 'delta' or 'snapshot'
                        'append_only_type': str,  # 'append_only', 'with_delete', 'not_applicable'
                        'is_append_only': bool
                    }
                ]
            }
        """
        tablescans = []
        
        # 遍历 subplan 中的所有算子，找出 TableScan
        for idx in subplan_indices:
            if idx >= len(self.operators):
                continue
                
            op = self.operators[idx]
            
            # 检查是否是 TableScan 算子
            if 'tableScan' not in op:
                continue
            
            # 获取算子的数据类型和 append-only 类型
            data_type = self.operator_data_types.get(idx, DataType.UNKNOWN)
            append_only_type = self.operator_append_only_types.get(idx, AppendOnlyType.UNKNOWN)
            op_id = self.operator_ids.get(idx, f"op_{idx}")
            
            # 提取表名
            table_name = 'unknown'
            try:
                table_scan = op.get('tableScan', {})
                table_info = table_scan.get('table', {})
                table_path = table_info.get('path', [])
                if table_path:
                    # 表名格式：workspace.database.table 或 database.table
                    table_name = '.'.join(table_path)
            except Exception:
                pass
            
            # 判断是否为 append-only
            # 只有 delta 数据才有 append-only 的概念
            is_append_only = (
                data_type == DataType.DELTA and 
                append_only_type == AppendOnlyType.APPEND_ONLY
            )
            
            tablescans.append({
                'operator_id': op_id,
                'operator_index': idx,
                'table_name': table_name,
                'data_type': data_type.value,
                'append_only_type': append_only_type.value,
                'is_append_only': is_append_only
            })
        
        # 判断是否所有 TableScan 都是 append-only
        # 注意：只考虑 delta 类型的 TableScan
        delta_tablescans = [
            ts for ts in tablescans 
            if ts['data_type'] == DataType.DELTA.value
        ]
        
        all_append_only = (
            len(delta_tablescans) > 0 and
            all(ts['is_append_only'] for ts in delta_tablescans)
        )
        
        return {
            'has_tablescans': len(tablescans) > 0,
            'all_append_only': all_append_only,
            'total_tablescans': len(tablescans),
            'delta_tablescans': len(delta_tablescans),
            'tablescans': tablescans
        }

    def get_operator_summary(self, op_index: int) -> Dict:
        """获取算子的摘要信息"""
        if op_index >= len(self.operators):
            return {}

        op = self.operators[op_index]
        op_type = self._get_operator_type(op)
        data_type = self.operator_data_types.get(op_index, DataType.UNKNOWN)
        op_id = self.operator_ids.get(op_index, f"op_{op_index}")

        rule_ids = [
            rule_id for rule_id, indices in self.rule_groups.items()
            if op_index in indices
        ]

        return {
            'index': op_index,
            'id': op_id,
            'type': op_type,
            'data_type': data_type.value,
            'rule_ids': rule_ids
        }

    def _build_algorithm_dependencies(self, algorithms: List[Dict]) -> Dict[str, List[str]]:
        """
        构建增量算法之间的依赖关系

        基于算子的执行顺序，如果算法 A 的算子在算法 B 之前执行，
        则 B 依赖于 A
        """
        dependencies = {}

        for algo in algorithms:
            rule_id = algo['rule_id']
            dependencies[rule_id] = []

            # 使用 rule_operators 而不是 operators，因为我们关心的是算法的核心部分
            algo_indices = [
                self.id_to_index[op_id]
                for op_id in algo['rule_operators']
                if op_id in self.id_to_index
            ]

            if not algo_indices:
                continue

            min_idx = min(algo_indices)

            for other_algo in algorithms:
                if other_algo['rule_id'] == rule_id:
                    continue

                other_indices = [
                    self.id_to_index[op_id]
                    for op_id in other_algo['rule_operators']
                    if op_id in self.id_to_index
                ]

                if not other_indices:
                    continue

                other_max_idx = max(other_indices)

                if other_max_idx < min_idx:
                    dependencies[rule_id].append(other_algo['rule_id'])

        return dependencies

    def _generate_dependency_graph(self, algorithms: List[Dict],
                                   dependencies: Dict[str, List[str]]) -> str:
        """
        生成增量算法依赖关系的文本可视化

        格式：
        增量算法依赖关系图：

        [Aggregate#12345] (原始SQL)
          算子: op_10, op_15, op_20
          类型: aggregate
          ↓ 依赖于
          [Join#67890]
        """
        if not algorithms:
            return "未检测到增量算法"

        lines = ["", "=" * 60, "增量算法依赖关系图", "=" * 60, ""]

        # 按照算子索引排序（执行顺序）
        sorted_algos = sorted(
            algorithms,
            key=lambda a: min([
                self.id_to_index[op_id]
                for op_id in a['rule_operators']
                if op_id in self.id_to_index
            ]) if a['rule_operators'] else 0
        )

        for algo in sorted_algos:
            rule_id = algo['rule_id']
            algo_type = algo['type']
            is_original = algo['is_original_sql']
            operators = algo['operators']
            rule_operators = algo['rule_operators']

            tag = "(原始SQL)" if is_original else "(算法辅助)"
            lines.append(f"[{algo_type.upper()}] {tag}")

            if '#' in rule_id:
                short_id = rule_id.split('#')[-1]
                lines.append(f"  ID: #{short_id}")
            else:
                lines.append(f"  Rule: {rule_id[:50]}...")

            # 显示目标算子（从 Rule ID 中提取的）
            target_op_id = algo.get('target_operator_id')
            if target_op_id:
                lines.append(f"  目标算子: {target_op_id}")

            # 显示 Rule hint 算子
            if rule_operators:
                op_list = ', '.join(rule_operators[:5])
                if len(rule_operators) > 5:
                    op_list += f", ... (共{len(rule_operators)}个 hint 算子)"
                lines.append(f"  Rule 算子: {op_list}")

            # 显示完整 subplan 大小
            lines.append(f"  完整 subplan: {len(operators)} 个算子")

            # Root 算子
            if algo['root_operator_id']:
                lines.append(f"  Root 算子: {algo['root_operator_id']}")

            deps = dependencies.get(rule_id, [])
            if deps:
                lines.append(f"  ↓ 依赖于 {len(deps)} 个算法:")
                for dep_id in deps[:3]:
                    dep_algo = next((a for a in algorithms if a['rule_id'] == dep_id), None)
                    if dep_algo:
                        dep_type = dep_algo['type'].upper()
                        lines.append(f"    - {dep_type}")
            else:
                lines.append("  ↓ 无依赖（最底层）")

            lines.append("")

        lines.append("=" * 60)
        lines.append("执行顺序（从上到下）：")
        for i, algo in enumerate(sorted_algos, 1):
            tag = "原始SQL" if algo['is_original_sql'] else "辅助"
            subplan_size = len(algo['operators'])
            lines.append(f"  {i}. {algo['type'].upper()} ({tag}) - {subplan_size} 个算子")

        lines.append("=" * 60)

        return '\n'.join(lines)

    def _validate_algorithms(self, algorithms: List[Dict]) -> List[str]:
        """
        验证增量算法的正确性

        根据 prompt 4.2.1.3 第 59 行和 original_prompt.md 第 76 行的要求：
        1. 同一个 operator 不应该属于两个不同的增量算法（除非是 root 节点或 TableScan）
        2. 如果某个 operator 属于了上游的增量算法，就不应该属于下游的增量算法
        3. 对于 snapshot 的算子，增量算法遍历时应该停止
        4. 从 root 节点开始 top-down 遍历，在碰到边界算子前不应该有其他增量算法的算子

        注意：这些是验证规则，如果不满足说明脚本有问题，需要修改

        Returns:
            验证警告信息列表
        """
        warnings = []

        # 构建算子到算法的映射：operator_id -> [algorithm_rule_ids]
        op_to_algos = {}
        for algo in algorithms:
            rule_id = algo['rule_id']
            root_op_id = algo.get('root_operator_id')

            for op_id in algo['operators']:
                if op_id not in op_to_algos:
                    op_to_algos[op_id] = []
                op_to_algos[op_id].append({
                    'rule_id': rule_id,
                    'is_root': (op_id == root_op_id)
                })

        # 验证规则 1: 同一个 operator 不应该属于两个不同的增量算法
        # 例外：root 节点或 TableScan 可以横跨多个增量算法
        for op_id, algo_list in op_to_algos.items():
            if len(algo_list) > 1:
                # 检查是否是 TableScan
                is_table_scan = 'TableScan' in op_id or 'tablescan' in op_id.lower()

                # 检查是否所有归属都是作为 root 节点
                non_root_algos = [a for a in algo_list if not a['is_root']]

                # 如果不是 TableScan，且有多个非 root 归属，则报告警告
                if not is_table_scan and len(non_root_algos) > 1:
                    algo_names = [a['rule_id'] for a in non_root_algos]
                    warnings.append(
                        f"[算子唯一性] 算子 {op_id} 属于 {len(non_root_algos)} 个不同的增量算法（非 root 节点且非 TableScan）: "
                        f"{', '.join(algo_names[:3])}{'...' if len(algo_names) > 3 else ''}"
                    )

        # 验证规则 2: 如果某个 operator 属于了上游的增量算法，就不应该属于下游的增量算法
        # 构建算法的拓扑顺序（基于算子索引）
        algo_order = {}
        for algo in algorithms:
            rule_id = algo['rule_id']
            # 使用算法中最小的算子索引作为算法的顺序
            min_idx = float('inf')
            for op_id in algo['operators']:
                if op_id in self.id_to_index:
                    min_idx = min(min_idx, self.id_to_index[op_id])
            algo_order[rule_id] = min_idx if min_idx != float('inf') else 0

        # 检查算子是否同时属于上游和下游算法
        for op_id, algo_list in op_to_algos.items():
            if len(algo_list) > 1:
                # 检查是否是 TableScan（TableScan 可以横跨多个算法）
                is_table_scan = 'TableScan' in op_id or 'tablescan' in op_id.lower()

                # 按算法顺序排序
                sorted_algos = sorted(algo_list, key=lambda a: algo_order.get(a['rule_id'], 0))

                # 检查是否有非 root 且非 TableScan 的算子同时属于上游和下游算法
                for i in range(len(sorted_algos) - 1):
                    upstream_algo = sorted_algos[i]
                    downstream_algo = sorted_algos[i + 1]

                    if not upstream_algo['is_root'] and not downstream_algo['is_root'] and not is_table_scan:
                        warnings.append(
                            f"[上下游冲突] 算子 {op_id} 同时属于上游算法 {upstream_algo['rule_id']} "
                            f"和下游算法 {downstream_algo['rule_id']}"
                        )

        # 验证规则 3: 对于 snapshot 的算子，增量算法不应该继续向上游遍历
        for algo in algorithms:
            rule_id = algo['rule_id']

            for op_id in algo['operators']:
                if op_id not in self.id_to_index:
                    continue

                idx = self.id_to_index[op_id]
                data_type = self.operator_data_types.get(idx, DataType.UNKNOWN)

                # 如果这个算子是 snapshot 类型
                if data_type == DataType.SNAPSHOT:
                    # 检查其上游算子是否也在这个算法中
                    upstream_indices = self.operator_dependencies.get(idx, [])
                    for upstream_idx in upstream_indices:
                        upstream_id = self.operator_ids.get(upstream_idx)
                        if upstream_id and upstream_id in algo['operators']:
                            upstream_data_type = self.operator_data_types.get(upstream_idx, DataType.UNKNOWN)
                            if upstream_data_type == DataType.SNAPSHOT:
                                warnings.append(
                                    f"[Snapshot 边界] 算法 {rule_id} 包含 snapshot 算子 {op_id}，"
                                    f"但继续向上游遍历到 snapshot 算子 {upstream_id}"
                                )

        # 验证规则 4: 从 root 节点开始 top-down 遍历，检查是否有其他算法的算子混入
        # 根据 original_prompt.md 第 76 行：
        # "从找到的root节点开始top-down遍历所有算子，在碰到了非边界算子前是不是有其他增量算法的算子，如果有，说明脚本有问题"
        warnings.extend(self._validate_topdown_traversal(algorithms, op_to_algos))

        return warnings

    def _validate_topdown_traversal(self, algorithms: List[Dict], op_to_algos: Dict) -> List[str]:
        """
        验证规则 5: 从 root 节点开始 top-down 遍历，检查是否有其他算法的算子混入

        根据 original_prompt.md 第 76 行：
        "从找到的root节点开始top-down遍历所有算子，在碰到了非边界算子前是不是有其他增量算法的算子，如果有，说明脚本有问题"

        实现逻辑：
        1. 从每个算法的 root 节点开始
        2. 沿着依赖关系（inputIds）向下游（输入方向）遍历
        3. 在遇到边界条件前，检查路径上的算子是否属于其他算法
        4. 如果有，说明 _find_algorithm_subplan_strict 的边界检测有问题

        ⚠️ 重要：这是验证 subplan 识别是否正确的规则
        - 如果从 root 遍历时遇到了其他算法的算子，说明当前算法的 subplan 包含了不该包含的算子
        - 或者说明边界检测没有正确终止遍历

        边界条件（与 _find_algorithm_subplan_strict 中的 should_stop_at_operator 一致）：
        - 算子包含 DeletePlan hint
        - 算子有不同的 Rule hint
        - 算子已被其他算法占用（除了 TableScan）
        - 对于 aggregate 算法，遇到 Final/Complete
        - Snapshot 边界

        Args:
            algorithms: 增量算法列表
            op_to_algos: 算子到算法的映射

        Returns:
            验证警告信息列表
        """
        warnings = []

        # 构建算子到 hint 的映射
        operator_hint_map = {}
        for rule_id, indices in self.rule_groups.items():
            for idx in indices:
                operator_hint_map[idx] = rule_id

        for algo in algorithms:
            rule_id = algo['rule_id']
            root_op_id = algo.get('root_operator_id')

            if not root_op_id or root_op_id not in self.id_to_index:
                continue

            root_idx = self.id_to_index[root_op_id]
            algo_type = algo['type']

            # 构建当前算法的 subplan 算子集合（用于检查算子是否在 subplan 中）
            algo_op_ids = set(algo['operators'])
            algo_op_indices = set()
            for op_id in algo_op_ids:
                if op_id in self.id_to_index:
                    algo_op_indices.add(self.id_to_index[op_id])

            # 从 root 节点开始 top-down 遍历（沿着依赖关系遍历，不限制只遍历 subplan）
            visited = set()
            path_warnings = self._topdown_traverse_and_check(
                root_idx, rule_id, algo_type, operator_hint_map, op_to_algos, algo_op_indices, visited
            )

            warnings.extend(path_warnings)

        return warnings

    def _topdown_traverse_and_check(self, current_idx: int, current_rule_id: str,
                                     algo_type: str, operator_hint_map: Dict,
                                     op_to_algos: Dict, algo_op_indices: Set[int],
                                     visited: Set[int]) -> List[str]:
        """
        从当前节点开始双向遍历并检查是否有其他算法的算子

        ⚠️ 重要：需要双向遍历（向上游和向下游）
        - 向上游（输入方向）：沿着 operator_dependencies 遍历
        - 向下游（输出方向）：沿着 operator_dependents 遍历
        - 这样才能遍历到 subplan 的所有算子

        Args:
            current_idx: 当前算子索引
            current_rule_id: 当前算法的 rule ID
            algo_type: 算法类型
            operator_hint_map: 算子到 hint 的映射
            op_to_algos: 算子到算法的映射
            algo_op_indices: 当前算法的 subplan 算子索引集合（用于检查）
            visited: 已访问的算子集合

        Returns:
            警告信息列表
        """
        warnings = []

        if current_idx in visited:
            return warnings

        visited.add(current_idx)

        # 检查是否到达边界
        if self._is_boundary_operator(current_idx, current_rule_id, algo_type, operator_hint_map):
            # 到达边界，停止遍历
            return warnings

        # 检查当前算子是否在当前算法的 subplan 中
        current_op_id = self.operator_ids.get(current_idx)
        in_current_subplan = current_idx in algo_op_indices

        # 如果当前算子在 subplan 中，检查它是否属于其他算法
        if in_current_subplan and current_op_id and current_op_id in op_to_algos:
            algo_list = op_to_algos[current_op_id]

            # 过滤掉当前算法和 TableScan
            is_table_scan = 'TableScan' in current_op_id or 'tablescan' in current_op_id.lower()

            if not is_table_scan:
                other_algos = [a for a in algo_list if a['rule_id'] != current_rule_id]

                if other_algos:
                    # 发现当前算子在 subplan 中，但属于其他算法
                    # 这说明 _find_algorithm_subplan_strict 的边界检测有问题
                    other_rule_ids = [a['rule_id'] for a in other_algos]
                    warnings.append(
                        f"[Top-Down 遍历] 算法 {current_rule_id} 的 subplan 包含了算子 {current_op_id}，"
                        f"但该算子属于其他算法: {', '.join(other_rule_ids[:3])}{'...' if len(other_rule_ids) > 3 else ''}"
                        f"（说明 subplan 边界检测有问题）"
                    )

        # 双向遍历：向上游（输入方向）
        input_indices = self.operator_dependencies.get(current_idx, [])
        for input_idx in input_indices:
            sub_warnings = self._topdown_traverse_and_check(
                input_idx, current_rule_id, algo_type, operator_hint_map, op_to_algos, algo_op_indices, visited
            )
            warnings.extend(sub_warnings)

        # 双向遍历：向下游（输出方向）
        output_indices = self.operator_dependents.get(current_idx, [])
        for output_idx in output_indices:
            sub_warnings = self._topdown_traverse_and_check(
                output_idx, current_rule_id, algo_type, operator_hint_map, op_to_algos, algo_op_indices, visited
            )
            warnings.extend(sub_warnings)

        return warnings

    def _log_algorithm_details(self, algorithms: List[Dict]):
        """
        输出详细的增量算法信息到日志

        Args:
            algorithms: 增量算法列表
        """
        if not algorithms:
            return

        logger.debug("")
        logger.debug("=" * 80)
        logger.debug(f"增量算法详细信息 - 共 {len(algorithms)} 个")
        logger.debug("=" * 80)

        for i, algo in enumerate(algorithms, 1):
            rule_id = algo.get('rule_id', 'Unknown')
            algo_type = algo.get('type', 'Unknown')
            is_original = algo.get('is_original_sql', False)
            operators = algo.get('operators', [])  # 这是 operator ID 列表（字符串）
            operator_details = algo.get('operator_details', [])  # 这是详细信息列表（字典）

            # 从 rule_id 中提取算法名称和ID
            if '#' in rule_id:
                rule_name, algo_id = rule_id.split('#', 1)
            else:
                rule_name = rule_id
                algo_id = 'N/A'

            logger.debug(f"")
            logger.debug(f"算法 {i}: {rule_name}")
            logger.debug(f"  算法ID: {algo_id} | 类型: {algo_type} | 原始SQL: {'✓' if is_original else '✗'}")
            logger.debug(f"  涉及算子: {len(operators)} 个")

            # 统计并显示主要算子类型（直接从 operator ID 中提取）
            # operator ID 格式：TableScan68, HashJoin111, Calc115 等
            op_types = {}
            for op_id in operators:
                # 从 ID 中提取算子类型（去掉数字）
                import re
                op_type = re.sub(r'\d+$', '', op_id)
                op_types[op_type] = op_types.get(op_type, 0) + 1

            if op_types:
                top_ops = sorted(op_types.items(), key=lambda x: -x[1])[:5]
                op_summary = ', '.join([f"{op}({cnt})" for op, cnt in top_ops])
                logger.debug(f"  主要算子类型: {op_summary}")

        logger.debug("")
        logger.debug("=" * 80)

    def _get_operator_str(self, idx: int) -> str:
        """
        获取算子的字符串表示（带缓存）
        
        Args:
            idx: 算子索引
            
        Returns:
            算子的 JSON 字符串表示
        """
        if idx not in self._operator_str_cache:
            if idx < 0 or idx >= len(self.operators):
                self._operator_str_cache[idx] = ""
            else:
                self._operator_str_cache[idx] = json.dumps(self.operators[idx])
        return self._operator_str_cache[idx]

    def _is_deleteplan_operator(self, idx: int) -> bool:
        """
        检查算子是否包含 DeletePlan hint（带缓存）

        根据 prompt original_prompt.md 第 76 行：
        "deleteplan 不需要添加到 subplan 里"

        Args:
            idx: 算子索引

        Returns:
            是否是 DeletePlan 算子
        """
        # 使用缓存
        if idx in self._is_deleteplan_cache:
            return self._is_deleteplan_cache[idx]
        
        if idx < 0 or idx >= len(self.operators):
            self._is_deleteplan_cache[idx] = False
            return False

        # 使用缓存的字符串表示
        op_str = self._get_operator_str(idx)
        
        result = False
        if 'deleteplan' in op_str.lower() or 'delete_plan' in op_str.lower():
            rule_pattern = r'Rule:([A-Za-z0-9_:#,\-()]+)'
            matches = re.findall(rule_pattern, op_str)
            for rule_name in matches:
                if 'deleteplan' in rule_name.lower() or 'delete_plan' in rule_name.lower():
                    result = True
                    break
        
        # 缓存结果
        self._is_deleteplan_cache[idx] = result
        return result

    def _is_boundary_operator(self, idx: int, current_rule_id: str, algo_type: str,
                              operator_hint_map: Dict) -> bool:
        """
        判断是否是边界算子（与 _find_algorithm_subplan_strict 中的 should_stop_at_operator 逻辑一致）

        边界条件：
        1. 算子包含 DeletePlan hint
        2. 算子有不同的 Rule hint
        3. 对于 aggregate 算法，遇到 Final/Complete
        4. Snapshot 边界

        Args:
            idx: 算子索引
            current_rule_id: 当前算法的 rule ID
            algo_type: 算法类型
            operator_hint_map: 算子到 hint 的映射

        Returns:
            是否是边界算子
        """
        if idx < 0 or idx >= len(self.operators):
            return True

        # 条件 1: 检查是否包含 DeletePlan hint
        if self._is_deleteplan_operator(idx):
            return True

        # 条件 2: 检查是否有不同的 hint
        op = self.operators[idx]
        if idx in operator_hint_map:
            hint_rule_id = operator_hint_map[idx]
            if hint_rule_id != current_rule_id:
                return True

        # 条件 3: 对于 aggregate 算法，检查 Final/Complete
        if algo_type == 'aggregate':
            op_type = self._get_operator_type(op)
            if op_type == 'aggregate':
                agg_mode = self._get_aggregate_mode(op)
                if agg_mode in ['Final', 'Complete', 'FINAL', 'COMPLETE']:
                    return True

        # 条件 4: Snapshot 边界
        current_data_type = self.operator_data_types.get(idx, DataType.UNKNOWN)
        if current_data_type == DataType.SNAPSHOT:
            for input_idx in self.operator_dependencies.get(idx, []):
                input_data_type = self.operator_data_types.get(input_idx, DataType.UNKNOWN)
                if input_data_type == DataType.SNAPSHOT:
                    return True

        return False

    def _log_data_type_tree(self):
        """
        调试模式：输出 delta/snapshot 传播树

        在 DEBUG 日志级别下，输出所有算子的 delta/snapshot 类型，
        以树形结构展示，方便调试传播逻辑
        
        同时将树输出到临时文件，方便查看
        """
        import tempfile
        import os
        
        # 创建临时文件用于保存树输出
        tree_file_path = os.path.join(os.getcwd(), 'incremental_data_type_tree.txt')
        
        logger.debug("=" * 100)
        logger.debug("Delta/Snapshot 传播树")
        logger.debug(f"树输出将同时保存到: {tree_file_path}")
        logger.debug("=" * 100)
        
        # 打开文件用于写入
        tree_file = open(tree_file_path, 'w', encoding='utf-8')
        
        def log_both(msg):
            """同时输出到logger和文件"""
            logger.debug(msg)
            tree_file.write(msg + '\n')
        
        # 统计
        delta_count = sum(1 for dt in self.operator_data_types.values() if dt == DataType.DELTA)
        snapshot_count = sum(1 for dt in self.operator_data_types.values() if dt == DataType.SNAPSHOT)
        unknown_count = sum(1 for dt in self.operator_data_types.values() if dt == DataType.UNKNOWN)

        log_both("=" * 100)
        log_both("Delta/Snapshot 传播树")
        log_both("=" * 100)
        log_both(f"统计: Delta={delta_count}, Snapshot={snapshot_count}, Unknown={unknown_count}")
        log_both("")

        # 找到所有叶子节点（没有输入的算子，通常是 TableScan）
        leaf_indices = [idx for idx in range(len(self.operators))
                       if not self.operator_dependencies.get(idx, [])]

        # 找到所有 sink 节点（没有下游的算子，通常是 TableSink）
        sink_indices = [idx for idx in range(len(self.operators))
                       if not self.operator_dependents.get(idx, [])]
        
        # 按照 sink 名字尾部的数字排序
        def extract_sink_number(sink_idx):
            """从 sink ID 中提取尾部数字，用于排序"""
            op_id = self.operator_ids.get(sink_idx, f"idx_{sink_idx}")
            # 提取尾部的数字，例如 TableSink283 -> 283
            import re
            match = re.search(r'(\d+)$', op_id)
            if match:
                return int(match.group(1))
            return 0  # 如果没有数字，返回0
        
        sink_indices = sorted(sink_indices, key=extract_sink_number)

        log_both(f"找到 {len(leaf_indices)} 个叶子节点（TableScan 等）")
        log_both(f"找到 {len(sink_indices)} 个 sink 节点（TableSink 等）")

        # Debug: 检查依赖关系是否正确构建
        log_both(f"依赖关系统计: operator_dependencies 有 {len([d for d in self.operator_dependencies.values() if d])} 个非空项")
        log_both(f"依赖关系统计: operator_dependents 有 {len([d for d in self.operator_dependents.values() if d])} 个非空项")

        # Debug: 输出前几个 sink 节点的类型
        log_both("前 10 个 sink 节点:")
        for sink_idx in sink_indices[:10]:
            op = self.operators[sink_idx]
            op_id = self.operator_ids.get(sink_idx, f"idx_{sink_idx}")
            op_type = self._get_operator_type(op)
            log_both(f"  {op_id} ({op_type})")
        log_both("")

        # 从 sink 节点开始输出树（这样可以看到完整的传播链）
        log_both("从 Sink 节点开始的传播树:")
        
        # 先收集所有会被打印的算子
        all_printed_indices = set()
        max_depth = 1000  # 设置足够大的深度限制，实际上不会达到
        for sink_idx in sink_indices:  # 遍历所有 sink，不限制数量
            visited_in_this_sink = set()
            self._collect_subtree_indices(sink_idx, visited_in_this_sink, depth=0, max_depth=max_depth)
            all_printed_indices.update(visited_in_this_sink)
        
        # 输出统计信息
        log_both(f"将要打印 {len(all_printed_indices)} 个算子（共 {len(self.operators)} 个）")
        
        # 找出没有被打印的算子
        not_printed_indices = set(range(len(self.operators))) - all_printed_indices
        if not_printed_indices:
            log_both(f"未打印的算子 ({len(not_printed_indices)} 个):")
            for idx in sorted(not_printed_indices):
                op_id = self.operator_ids.get(idx, f"idx_{idx}")
                op_type = self._get_operator_type(self.operators[idx])
                data_type = self.operator_data_types.get(idx, DataType.UNKNOWN)
                # 检查这个算子的依赖和被依赖关系
                deps = self.operator_dependencies.get(idx, [])
                dependents = self.operator_dependents.get(idx, [])
                log_both(f"  {op_id} ({op_type}) [{data_type.value.upper()}] - 输入:{len(deps)}个, 输出:{len(dependents)}个")
        
        # 输出树 - 遍历所有 sink，使用足够大的深度
        # 将log_both传递给_log_operator_subtree
        self._tree_output_func = log_both
        for sink_idx in sink_indices:
            op_id = self.operator_ids.get(sink_idx, f"idx_{sink_idx}")
            log_both(f"\n--- Sink: {op_id} ---")
            # 使用100层深度，足以覆盖最深的依赖链
            self._log_operator_subtree(sink_idx, visited=set(), depth=0, max_depth=100)

        log_both("")
        log_both("=" * 100)
        
        # 关闭文件
        tree_file.close()
        self._tree_output_func = None
        
        logger.debug(f"树输出已保存到: {tree_file_path}")

    def _collect_subtree_indices(self, idx: int, visited: Set[int], depth: int, max_depth: int):
        """
        收集子树中的所有算子索引（用于调试）
        
        Args:
            idx: 算子索引
            visited: 已访问的算子集合
            depth: 当前深度
            max_depth: 最大深度
        """
        if depth > max_depth or idx in visited or idx >= len(self.operators):
            return
        
        visited.add(idx)
        
        # 递归收集输入算子
        input_indices = self.operator_dependencies.get(idx, [])
        for input_idx in input_indices:
            self._collect_subtree_indices(input_idx, visited, depth + 1, max_depth)

    def _log_operator_subtree(self, idx: int, visited: Set[int], depth: int, max_depth: int, prefix: str = "", is_last: bool = True):
        """
        递归输出算子子树

        Args:
            idx: 算子索引
            visited: 已访问的算子集合
            depth: 当前深度
            max_depth: 最大深度
            prefix: 当前行的前缀（用于缩进）
            is_last: 是否是最后一个子节点
        """
        if depth > max_depth or idx in visited or idx >= len(self.operators):
            return

        visited.add(idx)

        # 获取算子信息
        op = self.operators[idx]
        op_id = self.operator_ids.get(idx, f"idx_{idx}")
        op_type = self._get_operator_type(op)
        data_type = self.operator_data_types.get(idx, DataType.UNKNOWN)

        # 检查是否有增量 hint
        has_hint = self._has_incremental_hint(op)
        hint_marker = " 🔄" if has_hint else ""

        # 检查是否是 df_and join
        is_df_and = False
        if 'join' in op_type.lower():
            is_df_and = self._is_df_and_join(op)
        df_and_marker = " [df_and]" if is_df_and else ""

        # 特殊处理 TableScan
        extra_info = ""
        if op_type == 'tablescan' or 'tableScan' in op:
            table_scan = op.get('tableScan', {})
            incr_prop = table_scan.get('incrementalTableProperty', {})
            from_val = incr_prop.get('from', 'N/A')
            to_val = incr_prop.get('to', 'N/A')
            extra_info = f" (from={from_val}, to={to_val})"

        # 构建连接符
        connector = "└── " if is_last else "├── "

        # 输出当前算子 - 使用_tree_output_func如果存在，否则使用logger
        output_line = f"{prefix}{connector}{op_id} ({op_type}) [{data_type.value.upper()}]{hint_marker}{df_and_marker}{extra_info}"
        if hasattr(self, '_tree_output_func') and self._tree_output_func:
            self._tree_output_func(output_line)
        else:
            logger.debug(output_line)

        # 递归输出输入算子
        input_indices = self.operator_dependencies.get(idx, [])
        for i, input_idx in enumerate(input_indices):
            is_last_child = (i == len(input_indices) - 1)
            new_prefix = prefix + ("    " if is_last else "│   ")
            self._log_operator_subtree(input_idx, visited, depth + 1, max_depth, new_prefix, is_last_child)


def create_incremental_analyzer(stage_data: Dict) -> IncrementalAlgorithmAnalyzer:
    """为 stage_data 创建 IncrementalAlgorithmAnalyzer"""
    plan = stage_data.get('plan', {})
    return IncrementalAlgorithmAnalyzer(plan)
