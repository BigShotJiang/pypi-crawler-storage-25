#!/usr/bin/env python3
"""版本解析工具"""
import re
from typing import Optional, Tuple


def parse_version(git_branch: str) -> Optional[Tuple[int, int]]:
    """
    从 git_branch 解析版本号

    Args:
        git_branch: Git 分支名，如 "release-v1.3", "release-v1.4.2"

    Returns:
        版本号元组 (major, minor)，如 (1, 3)，解析失败返回 None

    Examples:
        >>> parse_version("release-v1.3")
        (1, 3)
        >>> parse_version("release-v1.4.2")
        (1, 4)
        >>> parse_version("Unknown")
        None
    """
    if not git_branch or git_branch == 'Unknown':
        return None

    # 匹配 v1.3, v1.4.2 等格式
    match = re.search(r'v?(\d+)\.(\d+)', git_branch)
    if match:
        major = int(match.group(1))
        minor = int(match.group(2))
        return (major, minor)

    return None


def compare_version(version: Optional[Tuple[int, int]], target_major: int, target_minor: int) -> Optional[int]:
    """
    比较版本号

    Args:
        version: 当前版本号元组 (major, minor)
        target_major: 目标主版本号
        target_minor: 目标次版本号

    Returns:
        -1: version < target
         0: version == target
         1: version > target
         None: version 为 None（无法比较）

    Examples:
        >>> compare_version((1, 3), 1, 4)
        -1
        >>> compare_version((1, 4), 1, 3)
        1
        >>> compare_version((1, 3), 1, 3)
        0
    """
    if version is None:
        return None

    major, minor = version
    target = (target_major, target_minor)
    current = (major, minor)

    if current < target:
        return -1
    elif current > target:
        return 1
    else:
        return 0


def is_version_le(version: Optional[Tuple[int, int]], target_major: int, target_minor: int) -> bool:
    """
    判断版本是否 <= 目标版本

    Args:
        version: 当前版本号元组
        target_major: 目标主版本号
        target_minor: 目标次版本号

    Returns:
        True 如果 version <= target，否则 False
        如果 version 为 None，返回 False（保守策略）
    """
    cmp = compare_version(version, target_major, target_minor)
    return cmp is not None and cmp <= 0


def is_version_ge(version: Optional[Tuple[int, int]], target_major: int, target_minor: int) -> bool:
    """
    判断版本是否 >= 目标版本

    Args:
        version: 当前版本号元组
        target_major: 目标主版本号
        target_minor: 目标次版本号

    Returns:
        True 如果 version >= target，否则 False
        如果 version 为 None，返回 False（保守策略）
    """
    cmp = compare_version(version, target_major, target_minor)
    return cmp is not None and cmp >= 0
