#!/usr/bin/env python3
"""状态表检查工具类

提供统一的状态表检查方法，供所有规则使用。
"""
import json
from typing import Dict, Union


class StateTableChecker:
    """状态表检查工具类"""
    
    # 状态表标识符
    STATE_TABLE_PATTERN = '__incr__'
    
    # 缓存：避免重复检查同一个 context
    _cache = {}
    
    @classmethod
    def check_plan_has_state_table(cls, context_or_plan: Union[Dict, Dict]) -> bool:
        """
        检查是否包含中间状态表
        
        这是一个全局检查方法：
        - 如果传入的是 context（包含 aligned_stages），则检查整个 job 的所有 stage
        - 如果传入的是单个 plan，则只检查该 plan
        
        只要 job 中任何一个 stage 包含状态表（表名包含 __incr__），就返回 True。
        
        Args:
            context_or_plan: 分析上下文（包含 aligned_stages）或单个 stage 的 plan 数据
            
        Returns:
            bool: 是否已包含状态表
        """
        # 判断是 context 还是 plan
        if 'aligned_stages' in context_or_plan:
            # 这是一个 context，检查所有 stage
            # **性能优化**: 使用缓存，避免重复检查
            context_id = id(context_or_plan)
            if context_id in cls._cache:
                return cls._cache[context_id]
            
            aligned_stages = context_or_plan.get('aligned_stages', {})
            
            # 遍历所有 stage，只要找到一个有状态表就返回
            for stage_id, stage_data in aligned_stages.items():
                plan = stage_data.get('plan', {})
                if not plan:
                    continue
                
                # 只序列化 plan，不序列化其他数据
                try:
                    plan_str = json.dumps(plan)
                    if cls.STATE_TABLE_PATTERN in plan_str:
                        cls._cache[context_id] = True
                        return True
                except (TypeError, ValueError):
                    # 如果序列化失败，跳过
                    continue
            
            cls._cache[context_id] = False
            return False
        else:
            # 这是一个单独的 plan
            try:
                plan_str = json.dumps(context_or_plan)
                return cls.STATE_TABLE_PATTERN in plan_str
            except (TypeError, ValueError):
                return False
    
    @classmethod
    def clear_cache(cls):
        """清除缓存"""
        cls._cache.clear()
    
    @classmethod
    def get_state_table_status_message(cls, has_state_table: bool, 
                                      base_message: str,
                                      with_state_table_suffix: str = None) -> str:
        """
        根据是否有状态表生成相应的提示信息
        
        Args:
            has_state_table: 是否已有状态表
            base_message: 基础消息
            with_state_table_suffix: 当已有状态表时的额外提示（可选）
            
        Returns:
            str: 完整的提示信息
        """
        if not has_state_table:
            return base_message
        
        if with_state_table_suffix:
            return f"{base_message}。注意：Job 已包含中间状态表，{with_state_table_suffix}"
        else:
            return f"{base_message}。注意：Job 已包含中间状态表，但该问题仍存在，建议检查状态表位置和配置"
