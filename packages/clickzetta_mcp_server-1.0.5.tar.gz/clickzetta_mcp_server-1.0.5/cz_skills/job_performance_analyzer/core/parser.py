#!/usr/bin/env python3
"""核心解析器 - 解析 plan.json 和 job_profile.json"""
import gzip
import json
from typing import Dict, Any

try:
    from loguru import logger
except ImportError:
    import logging
    logger = logging.getLogger(__name__)


class PlanProfileParser:
    def __init__(self, plan_file: str, profile_file: str):
        # plan.json 可能为空或不提供
        self.plan = {}
        self.has_plan = False
        if plan_file:  # 如果提供了 plan_file
            try:
                if plan_file.endswith('.gz'):
                    with gzip.open(plan_file, 'rt', encoding='utf-8') as f:
                        content = f.read().strip()
                else:
                    with open(plan_file, 'r', encoding='utf-8') as f:
                        content = f.read().strip()
                if content:  # 检查文件是否为空
                    self.plan = json.loads(content)
                    has_stages = 'dml' in self.plan and 'stages' in self.plan.get('dml', {})
                    has_settings = 'settings' in self.plan and self.plan.get('settings')
                    
                    if has_stages or has_settings:
                        self.has_plan = True
                        if has_stages:
                            stage_count = len(self.plan['dml']['stages'])
                            logger.debug(f"成功加载 plan.json（包含 {stage_count} 个 stages）")
                        else:
                            logger.warning("成功加载 plan.json（包含 settings，但无 stage 信息）")
                    else:
                        logger.warning("plan.json 缺少有效数据（无 dml.stages 或 settings），将跳过依赖 plan 数据的分析")
                else:
                    logger.warning("plan.json 为空文件，将跳过依赖 plan 数据的分析")
            except FileNotFoundError:
                logger.warning(f"Plan 文件不存在: {plan_file}，将跳过依赖 plan 数据的分析")
            except json.JSONDecodeError as e:
                logger.warning(f"Plan 文件 JSON 格式错误: {plan_file}, 错误: {str(e)}，将跳过依赖 plan 数据的分析")
            except Exception as e:
                logger.warning(f"读取 Plan 文件失败: {plan_file}, 错误: {str(e)}，将跳过依赖 plan 数据的分析")
        else:
            logger.warning("未提供 plan.json，将跳过依赖 plan 数据的分析")

        # job_profile.json 是可选的
        self.profile = {}
        self.raw_profile = {}  # 保存原始的 profile 数据（包含 jobStatus 等）
        self.has_profile = False
        if profile_file:  # 如果提供了 profile_file
            try:
                if profile_file.endswith('.gz'):
                    with gzip.open(profile_file, 'rt', encoding='utf-8') as f:
                        profile_data = json.load(f)
                else:
                    with open(profile_file, 'r', encoding='utf-8') as f:
                        profile_data = json.load(f)
                # 检查是否为空文件或空对象
                if profile_data:
                    if 'data' in profile_data:
                        self.raw_profile = profile_data.get('data', {})
                        self.profile = self.raw_profile.get('jobSummary', {})
                    else:
                        self.profile = profile_data.get('jobSummary', profile_data)
                        self.raw_profile = profile_data

                    has_stage_data = self.profile and 'stageSummary' in self.profile and self.profile.get('stageSummary')
                    has_error_data = self.raw_profile and 'jobStatus' in self.raw_profile and self.raw_profile.get('jobStatus', {}).get('message')
                    has_profiling_data = (
                        (self.profile and 'jobProfiling' in self.profile and self.profile.get('jobProfiling', {}).get('profiling')) or
                        (self.raw_profile and 'jobStatus' in self.raw_profile and 
                         self.raw_profile.get('jobStatus', {}).get('jobProfiling', {}).get('profiling'))
                    )
                    
                    if has_stage_data or has_error_data or has_profiling_data:
                        self.has_profile = True
                        if has_error_data and not has_stage_data:
                            logger.warning("成功加载 job_profile.json (包含错误信息)")
                        elif has_profiling_data and not has_stage_data:
                            logger.debug("成功加载 job_profile.json (包含 profiling 数据)")
                        else:
                            logger.debug("成功加载 job_profile.json")
                    else:
                        logger.warning("job_profile.json 为空或无有效数据，将跳过依赖运行时数据的分析")
                else:
                    logger.warning("job_profile.json 为空，将跳过依赖运行时数据的分析")
            except FileNotFoundError:
                logger.warning(f"Profile 文件不存在: {profile_file}，将跳过依赖运行时数据的分析")
            except json.JSONDecodeError as e:
                logger.warning(f"Profile 文件 JSON 格式错误: {profile_file}, 错误: {str(e)}，将跳过依赖运行时数据的分析")
            except Exception as e:
                logger.warning(f"读取 Profile 文件失败: {profile_file}, 错误: {str(e)}，将跳过依赖运行时数据的分析")
        else:
            logger.warning("未提供 job_profile.json，将跳过依赖运行时数据的分析")

        self._parsed_data = None
    
    def parse(self) -> Dict[str, Any]:
        if self._parsed_data:
            return self._parsed_data

        try:
            settings = {}
            sql_text = ''
            git_branch = 'Unknown'
            
            # 优先从 plan 中获取数据
            if self.has_plan:
                settings = dict(self.plan.get('settings', {}))
                sql_text = settings.get('cz.sql.text', '')
                
                # 解析版本信息
                # build_info 可能在两个位置：
                # 1. plan['build_info'] (旧格式)
                # 2. plan['settings']['build_info'] (新格式，字符串格式)

                # 先尝试从 settings 中获取（新格式）
                build_info_str = settings.get('build_info', '')
                if build_info_str and isinstance(build_info_str, str):
                    # 格式: "BuildInfo:GitBranch:release-v1.2,GitVersion:xxx,..."
                    for part in build_info_str.split(','):
                        if 'GitBranch:' in part:
                            git_branch = part.split('GitBranch:')[1].strip()
                            break

                # 如果没找到，尝试从 plan['build_info'] 获取（旧格式）
                if git_branch == 'Unknown':
                    build_info_dict = self.plan.get('build_info', {})
                    if isinstance(build_info_dict, dict):
                        git_branch = build_info_dict.get('GitBranch', 'Unknown')
            
            # 如果 plan 中没有 SQL 文本，或者没有 plan 数据，尝试从 profile 中提取
            if not sql_text and self.raw_profile:
                logger.debug("从 profile 中提取 SQL 文本")
                job_desc = self.raw_profile.get('jobDesc', {})
                sql_job = job_desc.get('sqlJob', {})
                
                # 提取 SQL 文本
                query_list = sql_job.get('query', [])
                if query_list:
                    sql_text = ' '.join(query_list)
                    logger.debug(f"从 profile 中提取到 SQL 文本（长度: {len(sql_text)}）")
                
                # 如果 settings 为空，也尝试从 profile 中提取
                if not settings:
                    sql_config = sql_job.get('sqlConfig', {})
                    hint = sql_config.get('hint', {})
                    if hint:
                        settings = dict(hint)
                        logger.debug(f"从 profile 中提取到 {len(settings)} 个参数设置")

            self._parsed_data = {
                'sql_info': {
                    'text': sql_text,
                    'is_refresh': 'REFRESH' in sql_text.upper() if sql_text else False,
                    'is_compaction': ('COMPACTION' in sql_text.upper() or 'OPTIMIZE' in sql_text.upper()) if sql_text else False,
                    'sql_subtype': self._detect_sql_subtype(sql_text),  # 检测具体的 SQL 子类型
                },
                'version_info': {
                    'git_branch': git_branch,
                },
                'vc_mode': {
                    'is_ap': settings.get('cz.inner.is.ap.vc', '0') == '1',
                    'mode': 'AP' if settings.get('cz.inner.is.ap.vc', '0') == '1' else 'GP',
                    'vc_cores': self._get_vc_cores(settings),
                },
                'settings': settings,
                'plan_stages': self._parse_plan_stages(),
                'profile_stages': self._parse_profile_stages(),
                'has_profile': self.has_profile,  # 添加标志位
                'has_plan': self.has_plan,  # 添加 plan 标志位
                'raw_profile': self.raw_profile,  # 添加原始 profile 数据
            }
            return self._parsed_data
        except Exception as e:
            logger.error(f"解析数据失败: {str(e)}")
            raise RuntimeError(f"解析数据失败: {str(e)}")
    
    def _parse_plan_stages(self) -> Dict[str, Dict]:
        stages = {}
        if 'dml' in self.plan and 'stages' in self.plan['dml']:
            for stage in self.plan['dml']['stages']:
                stage_id = stage.get('id', stage.get('stageId'))
                if stage_id:
                    stages[stage_id] = stage
        return stages
    
    def _detect_sql_subtype(self, sql_text: str) -> str:
        """
        检测 SQL 的具体子类型
        返回值：SELECT, INSERT, UPDATE, DELETE, MERGE INTO, COPY INTO, CREATE, DROP, ALTER, TRUNCATE 等
        """
        if not sql_text:
            return 'UNKNOWN'
        
        # 移除注释和多余空格，获取第一个有效的 SQL 关键字
        sql_upper = sql_text.upper()
        
        # 移除单行注释
        lines = []
        for line in sql_upper.split('\n'):
            # 移除 -- 注释
            if '--' in line:
                line = line[:line.index('--')]
            lines.append(line.strip())
        sql_clean = ' '.join(lines)
        
        # 移除多行注释 /* */
        while '/*' in sql_clean and '*/' in sql_clean:
            start = sql_clean.index('/*')
            end = sql_clean.index('*/')
            sql_clean = sql_clean[:start] + ' ' + sql_clean[end+2:]
        
        # 去除多余空格
        sql_clean = ' '.join(sql_clean.split())
        
        # 检测 SQL 类型（按优先级，多词关键字优先）
        if sql_clean.startswith('MERGE INTO') or sql_clean.startswith('MERGE\nINTO'):
            return 'MERGE INTO'
        elif sql_clean.startswith('COPY INTO') or sql_clean.startswith('COPY\nINTO'):
            return 'COPY INTO'
        elif sql_clean.startswith('INSERT'):
            return 'INSERT'
        elif sql_clean.startswith('UPDATE'):
            return 'UPDATE'
        elif sql_clean.startswith('DELETE'):
            return 'DELETE'
        elif sql_clean.startswith('SELECT') or sql_clean.startswith('WITH'):
            return 'SELECT'
        elif sql_clean.startswith('CREATE'):
            return 'CREATE'
        elif sql_clean.startswith('DROP'):
            return 'DROP'
        elif sql_clean.startswith('ALTER'):
            return 'ALTER'
        elif sql_clean.startswith('TRUNCATE'):
            return 'TRUNCATE'
        elif sql_clean.startswith('REFRESH'):
            return 'REFRESH'
        elif 'COMPACTION' in sql_clean or 'OPTIMIZE' in sql_clean:
            return 'COMPACTION'
        else:
            return 'UNKNOWN'
    
    def _parse_profile_stages(self) -> Dict[str, Dict]:
        stages = {}
        if 'stageSummary' in self.profile:
            for stage_id, stage_data in self.profile['stageSummary'].items():
                stages[stage_id] = stage_data
        return stages
    
    def _parse_job_profiling(self) -> Dict[str, Any]:
        """解析 Job Profiling 数据，分析各阶段耗时"""
        if not self.has_profile:
            return {}
        
        try:
            # profiling 数据可能在两个位置：
            # 1. jobSummary.jobProfiling (旧格式)
            # 2. jobStatus.jobProfiling (新格式)
            profiling_data = []
            
            # 先尝试从 jobSummary 获取
            if 'jobProfiling' in self.profile:
                profiling_data = self.profile['jobProfiling'].get('profiling', [])
            
            # 如果没有，尝试从 jobStatus 获取
            if not profiling_data and 'jobStatus' in self.raw_profile:
                job_status = self.raw_profile.get('jobStatus', {})
                if 'jobProfiling' in job_status:
                    profiling_data = job_status['jobProfiling'].get('profiling', [])
            
            if not profiling_data:
                return {}
            
            # 构建时间映射
            profiling_map = {}
            for entry in profiling_data:
                event_id = int(entry['e'])
                timestamp_ms = int(entry['t'])
                profiling_map[event_id] = timestamp_ms
            
            # 计算各阶段耗时（按照官方定义）
            durations = {}
            
            # 1. Setup: SQL初始化阶段 (100 -> 108)
            #    包含编译优化等操作
            if 100 in profiling_map and 108 in profiling_map:
                durations['setup'] = profiling_map[108] - profiling_map[100]
            
            # 2. Resuming Cluster: 启动VC (110 -> 112)
            #    如果长时间未拉起请联系技术支持
            if 110 in profiling_map and 112 in profiling_map:
                durations['resuming_cluster'] = profiling_map[112] - profiling_map[110]
            
            # 3. Queued: 等待资源 (112 -> 120)
            #    作业排队等待资源，如果耗时较长建议查看vc资源是否占满
            if 112 in profiling_map and 120 in profiling_map:
                durations['queued'] = profiling_map[120] - profiling_map[112]
            
            # 4. Running: SQL处理数据 (120 -> 130)
            #    可以点到诊断查看每个算子耗时
            if 120 in profiling_map and 130 in profiling_map:
                durations['running'] = profiling_map[130] - profiling_map[120]
            
            # 5. Finish: SQL结束 (130 -> 150)
            #    包含commit数据、auto merge等
            if 130 in profiling_map and 150 in profiling_map:
                durations['finish'] = profiling_map[150] - profiling_map[130]
            
            # 6. 总耗时 (100 -> 150)
            if 100 in profiling_map and 150 in profiling_map:
                durations['total'] = profiling_map[150] - profiling_map[100]
            
            # 7. 持久化 (160 -> 165)
            if 160 in profiling_map and 165 in profiling_map:
                durations['persistence'] = profiling_map[165] - profiling_map[160]
            
            # 8. 总耗时 (100 -> 155 或 170)
            if 100 in profiling_map:
                end_id = 170 if 170 in profiling_map else 155
                if end_id in profiling_map:
                    durations['total'] = profiling_map[end_id] - profiling_map[100]
            
            # 分析各阶段占比和瓶颈
            total_time = durations.get('total', 0)
            phases = []
            
            phase_info = [
                ('Setup', 'setup', 100, 108, 'SQL初始化（编译优化）'),
                ('Resuming Cluster', 'resuming_cluster', 110, 112, '启动VC'),
                ('Queued', 'queued', 112, 120, '等待资源'),
                ('Running', 'running', 120, 130, 'SQL处理数据'),
                ('Finish', 'finish', 130, 150, 'SQL结束（commit等）'),
            ]
            
            for name, key, start_id, end_id, description in phase_info:
                if key in durations:
                    duration_ms = durations[key]
                    percentage = (duration_ms / total_time * 100) if total_time > 0 else 0
                    
                    phases.append({
                        'name': name,
                        'description': description,
                        'duration_ms': duration_ms,
                        'duration_sec': duration_ms / 1000,
                        'percentage': percentage,
                        'start_event': start_id,
                        'end_event': end_id
                    })
            
            # 找出瓶颈阶段（占比 > 5% 且非 Running）
            bottleneck = None
            sorted_phases = sorted(phases, key=lambda x: x['duration_ms'], reverse=True)
            
            for phase in sorted_phases:
                if phase['name'] != 'Running' and phase['percentage'] > 5:
                    bottleneck = phase
                    break
            
            return {
                'profiling_map': profiling_map,
                'durations': durations,
                'phases': phases,
                'bottleneck': bottleneck,
                'total_time_ms': total_time,
                'total_time_sec': total_time / 1000 if total_time > 0 else 0
            }
            
        except Exception as e:
            logger.warning(f"解析 Job Profiling 数据失败: {str(e)}")
            return {}
    
    def get_job_profiling_analysis(self) -> Dict[str, Any]:
        """获取 Job Profiling 分析结果"""
        if not self._parsed_data:
            self.parse()
        
        if 'job_profiling' not in self._parsed_data:
            self._parsed_data['job_profiling'] = self._parse_job_profiling()
        
        return self._parsed_data['job_profiling']
    
    def is_refresh_sql(self) -> bool:
        return 'REFRESH' in self.plan.get('settings', {}).get('cz.sql.text', '').upper()
    
    def is_ap_mode(self) -> bool:
        return self.plan.get('settings', {}).get('cz.inner.is.ap.vc', '0') == '1'

    @staticmethod
    def _get_vc_cores(settings: dict) -> int:
        """获取 VC core 数。AP 模式用 cz.analyze.instance.executor.count；GP 模式用 cz.sql.gp.vc.capability / 100"""
        is_ap = settings.get('cz.inner.is.ap.vc', '0') == '1'
        if is_ap:
            try:
                return int(settings.get('cz.analyze.instance.executor.count', '0'))
            except (ValueError, TypeError):
                return 0
        else:
            try:
                return int(settings.get('cz.sql.gp.vc.capability', '0')) // 100
            except (ValueError, TypeError):
                return 0
