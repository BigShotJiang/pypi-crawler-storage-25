#!/usr/bin/env python3
"""Stage 对齐器 - 对齐 Plan 和 Profile 的 Stage 数据"""
from typing import Dict, List, Any

try:
    from loguru import logger
except ImportError:
    import logging
    logger = logging.getLogger(__name__)


class StageAligner:
    # idle task 判定阈值（与 skew_detection 保持一致）
    IDLE_TASK_MAX_TIME_MS = 500
    IDLE_TASK_MAX_INPUT_BYTES = 65536
    # Shuffle 算子的 spill 是正常落盘行为，不代表内存不足
    IGNORABLE_SPILL_PATTERNS = ['ShuffleWrite', 'ShuffleExchange', 'Exchange']

    def __init__(self, parsed_data: Dict[str, Any]):
        self.plan_stages = parsed_data.get('plan_stages', {})
        self.profile_stages = parsed_data.get('profile_stages', {})
        self.has_profile = parsed_data.get('has_profile', False)  # 是否有有效的 profile 数据
        self._aligned_stages = {}
        self._stage_metrics = {}
        self._operator_analysis = []
        self._total_job_time = 0
        self._stage_dependencies = {}  # stage_id -> [upstream_stage_ids]
        self._global_task_timeline = []  # [(timestamp, concurrency), ...]
        self._per_stage_task_timeline = {}  # stage_id -> [(timestamp, concurrency), ...]

    def align(self) -> Dict[str, Any]:
        self._calculate_stage_metrics()
        self._parse_stage_dependencies()
        self._align_stages()
        self._analyze_operators()
        self._build_global_task_timeline()
        return {
            'aligned_stages': self._aligned_stages,
            'stage_metrics': self._stage_metrics,
            'operator_analysis': self._operator_analysis,
            'total_job_time': self._total_job_time,
            'stage_dependencies': self._stage_dependencies,
            'global_task_timeline': self._global_task_timeline,
            'per_stage_task_timeline': self._per_stage_task_timeline,
        }

    def _calculate_stage_metrics(self):
        """计算 Stage 指标"""
        # 如果没有 profile 数据，跳过指标计算
        if not self.has_profile:
            logger.debug("没有 profile 数据，跳过 Stage 指标计算")
            return

        min_start_time = float('inf')
        max_end_time = 0

        for stage_id, stage_data in self.profile_stages.items():
            try:
                # 计算实际 DOP（从 job_profile.json 的 taskCount）
                task_count_detail = stage_data.get('taskCountDetail', {})
                if task_count_detail:
                    actual_dop = sum(int(float(c)) for c in task_count_detail.values() if c)
                else:
                    # 如果没有 taskCountDetail，尝试从其他字段获取
                    actual_dop = int(stage_data.get('taskCount', 0))

                # 防止 DOP 为 0
                if actual_dop == 0:
                    logger.warning(f"Stage {stage_id} actual DOP 为 0，设置为 1")
                    actual_dop = 1

                # 获取 plan 中的估算 DOP
                plan_dop = 1
                if stage_id in self.plan_stages:
                    plan_dop = int(self.plan_stages[stage_id].get('dop', 1))

                start_time = int(stage_data.get('startTime', 0))
                end_time = int(stage_data.get('endTime', 0))
                elapsed_ms = end_time - start_time
                io_stats = stage_data.get('inputOutputStats', {})

                self._stage_metrics[stage_id] = {
                    'elapsed_ms': elapsed_ms,
                    'dop': actual_dop,  # 默认使用实际 DOP（向后兼容）
                    'actual_dop': actual_dop,  # 实际运行的 task count
                    'plan_dop': plan_dop,  # plan 中估算的 DOP
                    'input_bytes': int(io_stats.get('inputBytes', 0)),
                    'output_bytes': int(io_stats.get('outputBytes', 0)),
                    'spill_bytes': int(io_stats.get('spillingBytes', 0)),
                }
                
                # 计算基于有效 task 的时间倾斜比（排除 idle task）
                task_skew = self._compute_task_time_skew(stage_data.get('taskSummary', {}))
                self._stage_metrics[stage_id].update(task_skew)
                
                # 记录最早开始时间和最晚结束时间
                if start_time > 0:
                    min_start_time = min(min_start_time, start_time)
                if end_time > 0:
                    max_end_time = max(max_end_time, end_time)
                    
            except Exception as e:
                logger.error(f"计算 Stage {stage_id} 指标失败: {str(e)}")
                # 设置默认值
                self._stage_metrics[stage_id] = {
                    'elapsed_ms': 0, 'dop': 1, 'actual_dop': 1, 'plan_dop': 1,
                    'input_bytes': 0, 'output_bytes': 0, 'spill_bytes': 0,
                    'effective_spill_bytes': 0, 'effective_spill_gb': 0,
                    'operator_spills': [],
                }
        
        # 计算总耗时：使用最晚结束时间 - 最早开始时间（考虑并行执行）
        if min_start_time != float('inf') and max_end_time > 0:
            self._total_job_time = max_end_time - min_start_time
            logger.debug(f"计算 Job 总耗时: {self._total_job_time}ms (基于 Stage 时间范围)")
        else:
            logger.warning("无法计算 Job 总耗时，所有 Stage 时间戳无效")

    def _is_idle_task(self, task_data: Dict) -> bool:
        """判断 task 是否为空跑（与 skew_detection 保持一致）"""
        io_stats = task_data.get('inputOutputStats', {})
        input_row_count = int(io_stats.get('inputRowCount', 0))
        input_bytes = int(io_stats.get('inputBytes', 0))
        start_time = int(task_data.get('startTime', 0))
        end_time = int(task_data.get('endTime', 0))
        elapsed_ms = end_time - start_time if end_time > 0 and start_time > 0 else 0
        return (elapsed_ms < self.IDLE_TASK_MAX_TIME_MS
                and input_row_count == 0
                and input_bytes <= self.IDLE_TASK_MAX_INPUT_BYTES)

    def _compute_task_time_skew(self, task_summary: Dict) -> Dict:
        """基于有效 task（排除 idle task）计算时间倾斜比和数据量倾斜指标
        
        Returns:
            dict with:
              时间维度: active_task_count, total_task_count, active_task_ratio,
                       task_time_skew_ratio, task_time_max_median_ratio,
                       active_max_ms, active_avg_ms, active_median_ms
              数据量维度: data_skew_max_median_ratio, data_skew_concentration_ratio,
                         data_skew_top_k_tasks, data_skew_max_rows, data_skew_median_rows
        """
        empty = {
            'active_task_count': 0, 'total_task_count': 0,
            'active_task_ratio': 0, 'task_time_skew_ratio': 1.0,
            'task_time_max_median_ratio': 1.0,
            'active_max_ms': 0, 'active_avg_ms': 0, 'active_median_ms': 0,
            'data_skew_max_median_ratio': 1.0,
            'data_skew_concentration_ratio': 1.0,
            'data_skew_top_k_tasks': 0,
            'data_skew_max_rows': 0, 'data_skew_median_rows': 0,
        }
        if not task_summary:
            return empty

        total = len(task_summary)
        active_elapsed = []
        active_input_rows = []
        for task_data in task_summary.values():
            if not self._is_idle_task(task_data):
                start = int(task_data.get('startTime', 0))
                end = int(task_data.get('endTime', 0))
                elapsed = end - start if end > 0 and start > 0 else 0
                active_elapsed.append(elapsed)
                io_stats = task_data.get('inputOutputStats', {})
                active_input_rows.append(int(io_stats.get('inputRowCount', 0)))

        active_count = len(active_elapsed)
        if active_count == 0:
            empty['total_task_count'] = total
            return empty

        # --- 时间维度 ---
        active_max = max(active_elapsed)
        active_avg = sum(active_elapsed) / active_count
        time_skew_ratio = active_max / active_avg if active_avg > 0 else 1.0

        # time max/median — 比 max/avg 更稳定，不受极值拉高分母的影响
        sorted_elapsed = sorted(active_elapsed)
        if active_count % 2 == 1:
            active_median = sorted_elapsed[active_count // 2]
        else:
            active_median = (sorted_elapsed[active_count // 2 - 1] + sorted_elapsed[active_count // 2]) // 2
        time_max_median_ratio = active_max / active_median if active_median > 0 else float('inf')

        # --- 数据量维度 ---
        data_skew = self._compute_data_skew(active_input_rows)

        result = {
            'active_task_count': active_count,
            'total_task_count': total,
            'active_task_ratio': active_count / total,
            'task_time_skew_ratio': time_skew_ratio,
            'task_time_max_median_ratio': time_max_median_ratio,
            'active_max_ms': active_max,
            'active_avg_ms': active_avg,
            'active_median_ms': active_median,
        }
        result.update(data_skew)
        return result

    @staticmethod
    def _compute_data_skew(input_rows: List[int]) -> Dict:
        """计算 active task 的数据量倾斜指标
        
        两个互补指标：
        1. max/median ratio — 简单快速，抓住"1 个 task 特别大"
        2. Top-K 集中度 — 精确，抓住"少数 task 承担大部分数据"
        
        Top-K 集中度定义：承担 80% 数据量所需的最少 task 数 / active task 总数。
        值越小说明数据越集中（越 skew）。
        
        Returns:
            data_skew_max_median_ratio: max / median（active task 的 inputRowCount）
            data_skew_concentration_ratio: top-k task 数 / active task 总数
            data_skew_top_k_tasks: 承担 80% 数据量所需的 task 数
            data_skew_max_rows: active task 中最大的 inputRowCount
            data_skew_median_rows: active task 中 inputRowCount 的中位数
        """
        n = len(input_rows)
        if n == 0:
            return {
                'data_skew_max_median_ratio': 1.0,
                'data_skew_concentration_ratio': 1.0,
                'data_skew_top_k_tasks': 0,
                'data_skew_max_rows': 0, 'data_skew_median_rows': 0,
            }

        sorted_rows = sorted(input_rows, reverse=True)
        max_rows = sorted_rows[0]

        # median
        if n % 2 == 1:
            median_rows = sorted_rows[n // 2]
        else:
            median_rows = (sorted_rows[n // 2 - 1] + sorted_rows[n // 2]) // 2

        max_median_ratio = max_rows / median_rows if median_rows > 0 else float('inf')

        # Top-K 集中度：承担 80% 数据量所需的最少 task 数
        total_rows = sum(sorted_rows)
        if total_rows == 0:
            return {
                'data_skew_max_median_ratio': 1.0,
                'data_skew_concentration_ratio': 1.0,
                'data_skew_top_k_tasks': n,
                'data_skew_max_rows': 0, 'data_skew_median_rows': 0,
            }

        threshold = total_rows * 0.8
        cumsum = 0
        top_k = 0
        for rows in sorted_rows:
            cumsum += rows
            top_k += 1
            if cumsum >= threshold:
                break

        concentration_ratio = top_k / n

        return {
            'data_skew_max_median_ratio': max_median_ratio,
            'data_skew_concentration_ratio': concentration_ratio,
            'data_skew_top_k_tasks': top_k,
            'data_skew_max_rows': max_rows,
            'data_skew_median_rows': median_rows,
        }

    def _parse_stage_dependencies(self):
        """解析 Stage 依赖关系"""
        # 首先构建一个 operator -> stage 的映射
        operator_to_stage = {}
        for stage_id, plan in self.plan_stages.items():
            operators = plan.get('operators', [])
            for op in operators:
                op_id = op.get('id')
                if op_id:
                    operator_to_stage[op_id] = stage_id
        
        logger.debug(f"Built operator_to_stage mapping with {len(operator_to_stage)} operators")
        
        for stage_id, plan in self.plan_stages.items():
            upstream_stages = []

            # 方法1: 从 inputStages 字段提取
            if 'inputStages' in plan:
                input_stages = plan.get('inputStages', [])
                if isinstance(input_stages, list):
                    upstream_stages.extend(input_stages)
                    logger.debug(f"Stage {stage_id}: found {len(input_stages)} upstream stages from inputStages")

            # 方法2: 从 inputs 字段提取
            if 'inputs' in plan:
                inputs = plan.get('inputs', [])
                for inp in inputs:
                    if isinstance(inp, dict) and 'stageId' in inp:
                        upstream_stages.append(inp['stageId'])
                    elif isinstance(inp, str):
                        upstream_stages.append(inp)
                if inputs:
                    logger.debug(f"Stage {stage_id}: found upstream stages from inputs field")

            # 方法3: 从 operators 中的 exchange 提取
            operators = plan.get('operators', [])
            for op in operators:
                if 'exchange' in op:
                    exchange = op.get('exchange', {})
                    if 'inputStageId' in exchange:
                        upstream_stages.append(exchange['inputStageId'])
                    elif 'input' in exchange and isinstance(exchange['input'], dict):
                        if 'stageId' in exchange['input']:
                            upstream_stages.append(exchange['input']['stageId'])
                
                # 方法4: 从 operators 的 inputIds 推断上游 stage
                # 这是最通用的方法，适用于大多数情况
                input_ids = op.get('inputIds', [])
                for input_id in input_ids:
                    if input_id in operator_to_stage:
                        upstream_stage_id = operator_to_stage[input_id]
                        # 排除自己（避免循环依赖）
                        if upstream_stage_id != stage_id:
                            upstream_stages.append(upstream_stage_id)

            # 去重
            unique_upstream = list(set(upstream_stages))
            self._stage_dependencies[stage_id] = unique_upstream
            
            if unique_upstream:
                logger.debug(f"Stage {stage_id}: resolved {len(unique_upstream)} upstream stages: {unique_upstream}")
            else:
                logger.debug(f"Stage {stage_id}: no upstream stages found")

    def _align_stages(self):
        """对齐 Plan 和 Profile 数据"""
        for stage_id in self.plan_stages:
            plan_data = self.plan_stages[stage_id]
            # 提取 operators 列表
            plan_operators = plan_data.get('operators', [])

            # 如果有 profile 数据，进行对齐；否则只使用 plan 数据
            if self.has_profile and stage_id in self.profile_stages:
                self._aligned_stages[stage_id] = {
                    'stage_id': stage_id,
                    'plan': plan_data,
                    'profile': self.profile_stages[stage_id],
                    'metrics': self._stage_metrics.get(stage_id, {}),
                    'upstream_stages': self._stage_dependencies.get(stage_id, []),
                    'plan_operators': plan_operators,  # 添加 operators 列表
                }
            else:
                # 没有 profile 数据，只使用 plan 数据
                self._aligned_stages[stage_id] = {
                    'stage_id': stage_id,
                    'plan': plan_data,
                    'profile': {},  # 空 profile
                    'metrics': {},  # 空 metrics
                    'upstream_stages': self._stage_dependencies.get(stage_id, []),
                    'plan_operators': plan_operators,
                }

    def _analyze_operators(self):
        """分析 Operator 性能，同时计算 per-operator spill 和 stage 有效 spill
        
        Spill 说明：
        - stage 级别的 inputOutputStats.spillingBytes 包含 Shuffle 算子的正常落盘，不代表内存不足
        - 真正有意义的是非 Shuffle 算子的 spill（effective_spill），表示计算内存不足溢出到磁盘
        - 此方法在遍历 operatorSummary 时顺便计算 per-operator spill，避免规则重复遍历
        """
        # 如果没有 profile 数据，跳过 Operator 分析
        if not self.has_profile:
            logger.debug("没有 profile 数据，跳过 Operator 性能分析")
            return

        for stage_id, stage_data in self._aligned_stages.items():
            profile = stage_data.get('profile', {})
            metrics = stage_data.get('metrics', {})
            if 'operatorSummary' not in profile:
                continue

            # 收集该 stage 的 operator spill 信息
            operator_spills = []
            effective_spill_bytes = 0

            for op_id, op_data in profile['operatorSummary'].items():
                try:
                    wall_time = op_data.get('wallTimeNs', {})
                    max_ms = int(wall_time.get('max', 0)) / 1_000_000
                    min_ms = int(wall_time.get('min', 0)) / 1_000_000
                    avg_ms = int(wall_time.get('avg', 0)) / 1_000_000
                    stage_elapsed = metrics.get('elapsed_ms', 1)  # 防止除零

                    # skew_ratio：优先使用 stage 级别基于有效 task 计算的倾斜比
                    # operator 级别的 max/avg 在 idle task 多时会严重失真
                    stage_task_skew = metrics.get('task_time_skew_ratio', 1.0)
                    # 如果 active_task_ratio 低（大量 idle task），operator 的 max/avg 不可信
                    active_ratio = metrics.get('active_task_ratio', 1.0)
                    if active_ratio < 0.5:
                        op_skew_ratio = stage_task_skew
                    else:
                        op_skew_ratio = max_ms / avg_ms if avg_ms > 0 else 1.0

                    # 提取 operator 级别的数据量 skew 信息
                    row_count_stats = op_data.get('rowCount', {})
                    row_count_max = int(row_count_stats.get('max', 0))
                    row_count_min = int(row_count_stats.get('min', 0))
                    row_count_avg = int(row_count_stats.get('avg', 0))
                    row_count_sum = int(row_count_stats.get('sum', 0))
                    row_skew_ratio = row_count_max / row_count_avg if row_count_avg > 0 else 1.0

                    # 计算 operator 级别的 spill（统一在 aligner 中计算，规则直接读取）
                    spill_bytes = self._extract_operator_spill_bytes(op_data)
                    is_shuffle = any(pattern in op_id for pattern in self.IGNORABLE_SPILL_PATTERNS)

                    if spill_bytes > 0:
                        operator_spills.append({
                            'operator_id': op_id,
                            'spill_bytes': spill_bytes,
                            'spill_gb': spill_bytes / (1024**3),
                            'is_shuffle': is_shuffle,
                        })
                        if not is_shuffle:
                            effective_spill_bytes += spill_bytes

                    self._operator_analysis.append({
                        'stage_id': stage_id,
                        'operator_id': op_id,
                        'max_time_ms': max_ms,
                        'min_time_ms': min_ms if min_ms > 0 else None,
                        'avg_time_ms': avg_ms,
                        'stage_pct': (max_ms / stage_elapsed * 100) if stage_elapsed else 0,
                        'total_pct': (max_ms / self._total_job_time * 100) if self._total_job_time else 0,
                        'skew_ratio': op_skew_ratio,
                        'row_count_max': row_count_max,
                        'row_count_min': row_count_min if row_count_min > 0 else None,
                        'row_count_avg': row_count_avg,
                        'row_count_sum': row_count_sum,
                        'row_skew_ratio': row_skew_ratio,
                        'spill_bytes': spill_bytes,
                        'is_shuffle': is_shuffle,
                        'operator_data': op_data,
                    })
                except Exception as e:
                    logger.error(f"分析 Operator {op_id} 失败: {str(e)}")

            # 将 operator spill 汇总信息写入 stage metrics
            if stage_id in self._stage_metrics:
                self._stage_metrics[stage_id]['effective_spill_bytes'] = effective_spill_bytes
                self._stage_metrics[stage_id]['effective_spill_gb'] = effective_spill_bytes / (1024**3)
                self._stage_metrics[stage_id]['operator_spills'] = sorted(
                    operator_spills, key=lambda x: x['spill_bytes'], reverse=True
                )

        self._operator_analysis.sort(key=lambda x: x['max_time_ms'], reverse=True)

    @staticmethod
    def _extract_operator_spill_bytes(op_data: Dict) -> int:
        """从 operator 数据中提取 spill 字节数（取 spillStats 和 inputOutputStats 的较大值）"""
        spill_bytes = 0
        if 'spillStats' in op_data:
            spill_stats = op_data['spillStats']
            if isinstance(spill_stats, dict):
                spill_bytes = int(spill_stats.get('spillingBytes', 0))
            elif isinstance(spill_stats, (int, float)):
                spill_bytes = int(spill_stats)
        if 'inputOutputStats' in op_data:
            io_spill = int(op_data['inputOutputStats'].get('spillingBytes', 0))
            spill_bytes = max(spill_bytes, io_spill)
        return spill_bytes

    def _build_global_task_timeline(self):
        """一次性构建全局 task 并发 timeline 和每个 stage 的 task timeline。

        全局 timeline：所有 stage 的所有 task 的 (start, +1) / (end, -1) 事件，
        扫描线得到分段常数函数 [(t0, count0), (t1, count1), ...]。

        每个 stage 的 timeline：只包含该 stage 自己的 task 事件。

        resource_efficiency_analysis 可以用全局 timeline 减去自己的 timeline，
        得到"其他 stage 在该时间段内的并发 task 数"。
        """
        if not self.has_profile:
            return

        global_events = []  # (timestamp, +1/-1)

        for stage_id, stage_data in self.profile_stages.items():
            task_summary = stage_data.get('taskSummary', {})
            stage_events = []
            for task_data in task_summary.values():
                t_start = int(task_data.get('startTime', 0))
                t_end = int(task_data.get('endTime', 0))
                if t_end > t_start:
                    global_events.append((t_start, 1))
                    global_events.append((t_end, -1))
                    stage_events.append((t_start, 1))
                    stage_events.append((t_end, -1))

            # 构建 per-stage timeline
            self._per_stage_task_timeline[stage_id] = self._events_to_timeline(stage_events)

        # 构建全局 timeline
        self._global_task_timeline = self._events_to_timeline(global_events)

    @staticmethod
    def _events_to_timeline(events: List) -> List:
        """将 (timestamp, +1/-1) 事件列表转换为分段常数 timeline [(t, count), ...]"""
        if not events:
            return []
        events.sort(key=lambda e: (e[0], e[1]))
        timeline = []
        current = 0
        i = 0
        while i < len(events):
            ts = events[i][0]
            # 处理同一时刻的所有事件
            while i < len(events) and events[i][0] == ts:
                current += events[i][1]
                i += 1
            timeline.append((ts, current))
        return timeline

    def get_top_stages(self, n: int = 10) -> List[tuple]:
        """获取 Top N 耗时 Stage"""
        return sorted(self._stage_metrics.items(), key=lambda x: x[1]['elapsed_ms'], reverse=True)[:n]

    def get_top_operators(self, n: int = 10) -> List[Dict]:
        """获取 Top N 耗时 Operator"""
        return self._operator_analysis[:n]

    def get_upstream_stages(self, stage_id: str) -> List[str]:
        """获取指定 Stage 的上游 Stage ID 列表"""
        return self._stage_dependencies.get(stage_id, [])

    def get_upstream_dops(self, stage_id: str) -> List[int]:
        """获取上游 Stage 的 DOP 列表"""
        upstream_ids = self.get_upstream_stages(stage_id)
        dops = []
        for upstream_id in upstream_ids:
            if upstream_id in self._stage_metrics:
                dops.append(self._stage_metrics[upstream_id].get('dop', 0))
        return [d for d in dops if d > 0]  # 过滤掉 0

