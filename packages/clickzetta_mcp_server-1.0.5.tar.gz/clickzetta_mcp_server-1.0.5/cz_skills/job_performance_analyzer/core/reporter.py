#!/usr/bin/env python3
"""报告生成器"""
import json
from typing import Dict, List, Any
from datetime import datetime

class Reporter:
    def __init__(self):
        self.findings = []
        self.recommendations = []
        self.insights = []
        self.warnings = []
        self.metadata = {}
        self.incremental_algorithms = None  # 增量算法数据
    
    def add_finding(self, finding: Dict):
        self.findings.append(finding)
    
    def add_recommendation(self, recommendation: Dict):
        self.recommendations.append(recommendation)
    
    def add_insight(self, insight: Dict):
        self.insights.append(insight)
    
    def set_metadata(self, key: str, value: Any):
        self.metadata[key] = value

    def set_incremental_algorithms(self, data: Dict):
        """设置增量算法数据"""
        self.incremental_algorithms = data
    
    def merge_analysis_result(self, result: Dict):
        self.findings.extend(result.get('findings', []))
        self.recommendations.extend(result.get('recommendations', []))
        self.insights.extend(result.get('insights', []))
    
    def generate_console_report(self, context: Dict, sections: List[str] = None,
                               show_detail_insights: bool = False,
                               analysis_mode: str = 'quick') -> str:
        if sections is None:
            sections = ['summary', 'recommendations']
        
        # analysis_mode 覆盖 show_detail_insights
        if analysis_mode in ('detailed', 'expert'):
            show_detail_insights = True
        lines = ["=" * 80, "Job 性能分析报告", "=" * 80]
        if 'summary' in sections:
            lines.append(f"\n[概况]")
            lines.append(f"  SQL 类型: {self.metadata.get('sql_type', 'Unknown')}")
            lines.append(f"  VC 模式: {self.metadata.get('vc_mode', 'Unknown')}")
            
            # 显示两个时间：Job 生命周期总耗时和 Stage 执行时间
            job_total_time = self.metadata.get('job_total_time_seconds', 0)
            stage_total_time = self.metadata.get('stage_total_time_seconds', 0)
            
            if job_total_time > 0 and stage_total_time > 0:
                # 两个时间都有，显示详细信息
                lines.append(f"  Job 总耗时: {job_total_time:.2f}s (生命周期)")
                lines.append(f"  Stage 执行时间: {stage_total_time:.2f}s (Running 阶段)")
                non_execution_time = job_total_time - stage_total_time
                if non_execution_time > 0.1:
                    lines.append(f"  非执行时间: {non_execution_time:.2f}s (Setup/Queued/Finish)")
            elif job_total_time > 0:
                # 只有 Job 总耗时
                lines.append(f"  总耗时: {job_total_time:.2f}s")
            elif stage_total_time > 0:
                # 只有 Stage 执行时间
                lines.append(f"  总耗时: {stage_total_time:.2f}s (Stage 执行)")
            else:
                # 兼容旧版本
                lines.append(f"  总耗时: {self.metadata.get('total_time_seconds', 0):.2f}s")
            
            lines.append(f"  Stage 数: {self.metadata.get('stage_count', 0)}")
            if self.metadata.get('refresh_type'):
                lines.append(f"  刷新类型: {self.metadata.get('refresh_type')}")
        
        if 'findings' in sections and self.findings:
            lines.append(f"\n[发现问题] ({len(self.findings)})")
            for f in self.findings:
                lines.append(f"  [{f.get('severity')}] {f.get('type')} - Stage {f.get('stage_id')}")
                if f.get('description'):
                    lines.append(f"         {f.get('description')}")
        
        # 倒金字塔布局：补充洞察 → 关键洞察 → 参数建议
        # 用户终端最后停留在底部，最先看到参数建议（最终结论），往上翻看更多细节
        
        if 'insights' in sections and self.insights:
            sorted_insights = self._sort_insights_by_stage_time(context)
            important_insights = [i for i in sorted_insights if i.get('level') == 'important']
            detail_insights = [i for i in sorted_insights if i.get('level') != 'important']
            
            # [补充洞察] — detail 级别，仅 detailed/expert 模式展示
            if show_detail_insights and detail_insights:
                lines.append(f"\n[补充洞察] ({len(detail_insights)} 条，供深入分析参考)")
                for insight in detail_insights[:50]:
                    lines.append(f"  ℹ️  {insight.get('message', '')}")
            
            # [关键洞察] — important 级别，所有模式都展示
            if important_insights:
                lines.append(f"\n[关键洞察] ({len(important_insights)} 条)")
                for insight in important_insights[:20]:
                    lines.append(f"  💡 {insight.get('message', '')}")
        
        if 'recommendations' in sections:
            if self.recommendations:
                unique_recs = self._deduplicate_recommendations()
                lines.append(f"\n[参数建议] ({len(unique_recs)})")
                lines.append("=" * 80)
                for i, rec in enumerate(unique_recs, 1):
                    rec_type = rec.get('type', 'parameter')
                    
                    if rec_type == 'rerun_job':
                        lines.append(f"\n{i}. [优先级: {rec.get('priority')}] {rec.get('title')}")
                        lines.append(f"   {rec.get('description')}")
                        if rec.get('action'):
                            lines.append(f"   操作: {rec.get('action')}")
                    elif rec_type == 'contact_support':
                        lines.append(f"\n{i}. [优先级: {rec.get('priority')}] {rec.get('title')}")
                        lines.append(f"   {rec.get('description')}")
                        if rec.get('reason'):
                            lines.append(f"   原因: {rec.get('reason')}")
                        if rec.get('action'):
                            lines.append(f"   操作: {rec.get('action')}")
                    else:
                        lines.append(f"\n{i}. [P{rec.get('priority')}] [Impact: {rec.get('impact')}]")
                        lines.append(f"   set {rec.get('setting')} = {rec.get('value')};")
                        if rec.get('current_value'):
                            lines.append(f"   当前值: {rec.get('current_value')}")
                        lines.append(f"   理由: {rec.get('reason')}")
                        if rec.get('warning'):
                            lines.append(f"   ⚠️  {rec.get('warning')}")
                lines.append("=" * 80)
            else:
                lines.append("\n[参数建议]\n  ✓ 未发现需要调整的参数")
        
        return "\n".join(lines)
    
    def generate_json_report(self, context: Dict = None, analysis_mode: str = 'quick') -> Dict:
        # Findings 过滤：quick 模式不输出 INFO/LOW 级别
        if analysis_mode == 'quick':
            filtered_findings = [f for f in self.findings
                                 if f.get('severity', '').upper() not in ('INFO', 'LOW')]
        else:
            filtered_findings = self.findings
        
        # Insights 过滤：quick 只输出 important，detailed/expert 输出全部
        if analysis_mode == 'quick':
            filtered_insights = [i for i in self.insights if i.get('level') == 'important']
        else:
            filtered_insights = self.insights
        
        # 排序
        sorted_insights = self._sort_insights_by_stage_time(context, filtered_insights) if context else filtered_insights
        
        report = {
            'generated_at': datetime.now().isoformat(),
            'metadata': {**self.metadata, 'analysis_mode': analysis_mode},
            'findings': filtered_findings,
            'warnings': self.warnings,
            'recommendations': self._deduplicate_recommendations(),
            'insights': sorted_insights,
        }

        # detailed/expert 模式：包含 analysis_scope
        if analysis_mode in ('detailed', 'expert') and context:
            analysis_scope = context.get('analysis_scope', {})
            if analysis_scope:
                report['analysis_scope'] = analysis_scope
            
            # 构建 stage_summary：压缩的 per-stage 关键指标，供 AI 全局审视
            stage_summary = self._build_stage_summary(context)
            if stage_summary:
                report['stage_summary'] = stage_summary

        # 如果有增量算法数据，添加到报告中
        if self.incremental_algorithms:
            report['incremental_algorithms'] = self.incremental_algorithms

        return report
    
    def _deduplicate_recommendations(self) -> List[Dict]:
        unique = {}
        for rec in self.recommendations:
            rec_type = rec.get('type', 'parameter')
            
            if rec_type in ('rerun_job', 'contact_support'):
                # 重跑建议和技术支持建议不去重，直接添加
                key = f"{rec_type}_{len(unique)}"
                unique[key] = rec
            else:
                # 参数建议按 setting 去重
                setting = rec.get('setting', '')
                if setting not in unique or rec.get('priority', 9) < unique[setting].get('priority', 9):
                    unique[setting] = rec
        return sorted(unique.values(), key=lambda x: (x.get('type') not in ('rerun_job', 'contact_support'), x.get('priority', 9)))
    
    def _build_stage_summary(self, context: Dict) -> List[Dict]:
        """构建压缩的 per-stage 关键指标摘要，供 AI 在 detailed/expert 模式下全局审视。
        
        包含 aligner 已计算的 top stages、top operators、task 并发等数据，
        让 AI 能看到规则引擎之外的"全貌"，发现规则盲区。
        """
        all_stage_metrics = context.get('all_stage_metrics', {})
        total_job_time = context.get('total_job_time', 0)
        operator_analysis = context.get('operator_analysis', [])
        
        if not all_stage_metrics:
            return []
        
        # 按耗时降序排列 stage
        sorted_stages = sorted(
            all_stage_metrics.items(),
            key=lambda x: x[1].get('elapsed_ms', 0),
            reverse=True
        )
        
        # 构建 operator 按 stage 分组的索引
        ops_by_stage = {}
        for op in operator_analysis:
            sid = op.get('stage_id')
            if sid not in ops_by_stage:
                ops_by_stage[sid] = []
            ops_by_stage[sid].append(op)
        
        summary = []
        for stage_id, metrics in sorted_stages:
            elapsed_ms = metrics.get('elapsed_ms', 0)
            if elapsed_ms <= 0:
                continue
            
            pct = (elapsed_ms / total_job_time * 100) if total_job_time > 0 else 0
            
            entry = {
                'stage_id': stage_id,
                'elapsed_s': round(elapsed_ms / 1000, 2),
                'pct': round(pct, 1),
                'dop': metrics.get('dop', 0),
                'input_bytes': metrics.get('input_bytes', 0),
                'output_bytes': metrics.get('output_bytes', 0),
                'effective_spill_bytes': metrics.get('effective_spill_bytes', 0),
            }
            
            # task 倾斜信息
            active_count = metrics.get('active_task_count', 0)
            total_count = metrics.get('total_task_count', 0)
            if total_count > 0:
                entry['task_skew'] = {
                    'active': active_count,
                    'total': total_count,
                    'skew_ratio': round(metrics.get('task_time_skew_ratio', 1.0), 2),
                }
            
            # top operators（取该 stage 的前 3 个耗时最高的 operator）
            stage_ops = ops_by_stage.get(stage_id, [])
            if stage_ops:
                top_ops = []
                for op in stage_ops[:3]:
                    op_entry = {
                        'id': op.get('operator_id', ''),
                        'max_s': round(op.get('max_time_ms', 0) / 1000, 2),
                        'stage_pct': round(op.get('stage_pct', 0), 1),
                        'skew': round(op.get('skew_ratio', 1.0), 1),
                    }
                    row_max = op.get('row_count_max', 0)
                    if row_max > 0:
                        op_entry['max_rows'] = row_max
                        row_skew = op.get('row_skew_ratio', 1.0)
                        if row_skew > 1.5:
                            op_entry['row_skew'] = round(row_skew, 1)
                    top_ops.append(op_entry)
                entry['top_operators'] = top_ops
            
            summary.append(entry)
        
        return summary

    def _sort_insights_by_stage_time(self, context: Dict, insights: List[Dict] = None) -> List[Dict]:
        """按 stage 耗时排序 insights
        
        排序规则：
        1. 有 stage_id 的 insights 按照 stage 耗时降序排列
        2. 没有 stage_id 的 insights 放在最后
        """
        if insights is None:
            insights = self.insights
        
        # 获取 stage 耗时信息
        stage_metrics = context.get('all_stage_metrics', {}) if context else {}
        
        # 为每个 insight 计算排序权重
        def get_sort_key(insight: Dict):
            stage_id = insight.get('stage_id')
            if not stage_id:
                # 没有 stage_id 的放在最后
                return (1, 0)
            
            # 获取 stage 耗时
            stage_metric = stage_metrics.get(stage_id, {})
            elapsed_ms = stage_metric.get('elapsed_ms', 0)
            
            # 按耗时降序（耗时越长，优先级越高）
            return (0, -elapsed_ms)
        
        return sorted(insights, key=get_sort_key)
    
    def save_json_report(self, output_path: str, context: Dict = None, analysis_mode: str = 'quick'):
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(self.generate_json_report(context, analysis_mode), f, indent=2, ensure_ascii=False)
        return output_path
