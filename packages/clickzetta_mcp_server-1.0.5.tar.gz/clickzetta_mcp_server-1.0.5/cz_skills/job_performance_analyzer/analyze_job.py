#!/usr/bin/env python3
"""
Clickzetta Job 性能分析工具
使用方法: python analyze_job.py <plan.json> <job_profile.json> [output_dir]
"""
import sys
import os
import io
import gzip
import json
import glob as glob_mod

# 支持直接运行脚本（python analyze_job.py）和模块运行（python -m）
if __name__ == '__main__' and __package__ is None:
    # 直接运行脚本时，添加父目录到 sys.path
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))
    # 设置包名，使相对导入可以工作
    __package__ = 'cz_skills.job_performance_analyzer'

from .core.parser import PlanProfileParser
from .core.aligner import StageAligner
from .analyzers import get_analyzer


def _read_json_file(path: str):
    """读取 JSON 文件，支持 .gz 压缩格式"""
    if path.endswith('.gz'):
        with gzip.open(path, 'rt', encoding='utf-8') as f:
            return json.load(f)
    else:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)


def _find_file_recursive(job_dir: str, filenames: list) -> str:
    """递归查找目录中第一个匹配的文件，按 filenames 优先级顺序返回"""
    for name in filenames:
        for root, _dirs, files in os.walk(job_dir):
            if name in files:
                return os.path.join(root, name)
    return ''


def resolve_job_dir(job_dir: str) -> dict:
    """
    从 job 目录中递归发现文件。
    
    返回 dict:
        plan_file, profile_file: 主文件路径（可能为空字符串）
        extra_files: dict，key 为文件类型（如 'dag_summary', 'stats_summary'），value 为解析后的 JSON 数据
    """
    result = {'plan_file': '', 'profile_file': '', 'extra_files': {}}
    
    if not os.path.isdir(job_dir):
        raise ValueError(f"目录不存在: {job_dir}")
    
    # 一次遍历：建索引 + 计数
    file_index = {}
    file_count = 0
    for root, _dirs, files in os.walk(job_dir):
        file_count += len(files)
        if file_count > 1024:
            raise ValueError(f"目录中文件数过多（>{1024}），疑似目录指定错误: {job_dir}")
        for f in files:
            if f not in file_index:
                file_index[f] = os.path.join(root, f)
    
    # 从索引中查找文件（按优先级）
    def _find(names):
        for n in names:
            if n in file_index:
                return file_index[n]
        return ''
    
    result['plan_file'] = _find(['plan.json.gz', 'plan.json'])
    result['profile_file'] = _find(['job_profile.json'])
    
    # 递归发现额外文件
    for base_name in ['dag_summary', 'stats_summary']:
        path = _find([base_name + '.json.gz', base_name + '.json'])
        if path:
            try:
                result['extra_files'][base_name] = _read_json_file(path)
            except Exception as e:
                print(f"[WARNING] 读取 {path} 失败: {e}")
    
    return result


class OutputCapture:
    """捕获 stdout 和 stderr 的输出，同时保持终端显示"""
    def __init__(self):
        self.buffer = io.StringIO()
        self.original_stdout = sys.stdout
        self.original_stderr = sys.stderr
        
    def __enter__(self):
        # 创建 Tee 类，同时写入到 buffer 和原始输出
        class TeeOutput:
            def __init__(self, original, buffer):
                self.original = original
                self.buffer = buffer
            
            def write(self, data):
                self.original.write(data)
                self.buffer.write(data)
            
            def flush(self):
                self.original.flush()
                self.buffer.flush()
        
        sys.stdout = TeeOutput(self.original_stdout, self.buffer)
        sys.stderr = TeeOutput(self.original_stderr, self.buffer)
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        sys.stdout = self.original_stdout
        sys.stderr = self.original_stderr
    
    def get_output(self):
        return self.buffer.getvalue()

def print_header():
    print("=" * 80)
    print("Clickzetta Job 性能分析工具 v2.0")
    print("=" * 80)
    print("\n已实现规则:")
    print("  ✅ 错误分析 (3条):")
    print("     错误信息收集、Job提交冲突检测、优化器错误检测")
    print("  ✅ Stage/Operator 级别优化 (7条):")
    print("     增量/全量判断、单DOP聚合、Hash Join、TableSink DOP、最大DOP、Spilling、主动问题发现")
    print("  ✅ 状态表优化 (6条):")
    print("     非增量诊断、Row Number检查、Append-Only Scan、状态表启用、Aggregate复用、Calc状态优化")

def analyze_job(plan_file: str, profile_file: str, output_dir: str = ".", 
               enable_state_table_analysis: bool = False,
               enable_incremental_algorithm_analysis: bool = False,
               log_level: str = "INFO",
               capture_output: bool = False,
               analysis_mode: str = 'quick',
               extra_files: dict = None):
    """
    分析 Job 性能

    Args:
        plan_file: plan.json 文件路径，非必填
        profile_file: job_profile.json 文件路径
        output_dir: 输出目录
        enable_state_table_analysis: 是否启用状态表优化分析（默认 False）
        enable_incremental_algorithm_analysis: 是否启用增量算法策略分析（默认 False）
        log_level: 日志级别 (DEBUG, INFO, WARNING, ERROR)，默认 INFO
        capture_output: 是否捕获所有输出（print 和 log），默认 False
        analysis_mode: 分析模式 ('quick', 'detailed', 'expert')，默认 'quick'
        extra_files: 额外文件数据 dict（如 dag_summary, stats_summary），默认 None
    
    Returns:
        如果 capture_output=True，返回 dict，包含：
            - output: 所有捕获的输出文本
            - json_report: JSON 格式的分析报告
        如果 capture_output=False，返回 JSON 格式的分析报告
    """
    # 如果需要捕获输出，使用 OutputCapture
    output_capture = OutputCapture() if capture_output else None
    
    if output_capture:
        output_capture.__enter__()
    
    try:
        return _analyze_job_impl(
            plan_file, profile_file, output_dir,
            enable_state_table_analysis,
            enable_incremental_algorithm_analysis,
            log_level,
            capture_output,
            output_capture,
            analysis_mode,
            extra_files or {}
        )
    finally:
        if output_capture:
            output_capture.__exit__(None, None, None)


def _analyze_job_impl(plan_file: str, profile_file: str, output_dir: str,
                     enable_state_table_analysis: bool,
                     enable_incremental_algorithm_analysis: bool,
                     log_level: str,
                     capture_output: bool,
                     output_capture,
                     analysis_mode: str = 'quick',
                     extra_files: dict = None):
    """内部实现函数"""
    # 配置日志
    import logging
    numeric_level = getattr(logging, log_level.upper(), logging.INFO)
    # 根据日志级别选择 format：DEBUG 带文件函数名，INFO 及以上简洁输出
    if numeric_level <= logging.DEBUG:
        log_format = '[%(levelname)s] %(name)s:%(funcName)s:%(lineno)d - %(message)s'
    else:
        log_format = '[%(levelname)s] %(message)s'
    
    logging.basicConfig(
        level=numeric_level,
        format=log_format,
        force=True  # 强制重新配置
    )
    
    # 配置 loguru（如果可用）
    try:
        from loguru import logger
        logger.remove()  # 移除默认 handler
        if numeric_level <= logging.DEBUG:
            loguru_format = "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>"
        else:
            loguru_format = "<level>[{level}]</level> <level>{message}</level>"
        logger.add(
            lambda msg: print(msg, end=''),  # 输出到 stdout
            level=log_level.upper(),
            format=loguru_format
        )
    except ImportError:
        pass  # loguru 不可用，使用标准 logging
    
    print("\n" + "=" * 80)
    print("步骤1: 解析输入文件")
    print("=" * 80)

    parser = PlanProfileParser(plan_file, profile_file)
    parsed_data = parser.parse()
    sql_info = parsed_data['sql_info']
    vc_mode = parsed_data['vc_mode']
    settings = parsed_data['settings']
    version_info = parsed_data['version_info']
    has_profile = parsed_data.get('has_profile', False)
    has_plan = parsed_data.get('has_plan', False)

    # 构建 SQL 类型显示字符串
    if sql_info['is_refresh']:
        sql_type_display = 'REFRESH SQL'
    elif sql_info['text']:
        sql_subtype = sql_info.get('sql_subtype', 'UNKNOWN')
        sql_type_display = f'Regular SQL ({sql_subtype})'
    else:
        sql_type_display = 'Unknown (无 plan 数据)'
    
    print(f"\n[SQL 类型] {sql_type_display}")
    print(f"[VC 模式] {vc_mode['mode']} Mode (Max VC Cores: {vc_mode.get('vc_cores', 'N/A')})")
    print(f"[版本信息] {version_info['git_branch']}")
    print(f"[已有参数] Total: {len(settings)}")
    print(f"[Plan 数据] {'有效' if has_plan else '无效或为空（仅能进行错误分析）'}")
    print(f"[Profile 数据] {'有效' if has_profile else '无效或为空（部分分析将基于 plan.json）'}")
    print(f"[状态表分析] {'启用' if enable_state_table_analysis else '禁用（使用 --enable-state-table 启用）'}")
    print(f"[增量算法策略] {'启用' if enable_incremental_algorithm_analysis else '禁用（使用 --enable-incremental-algorithm 启用）'}")
    
    # 显示 Job 生命周期阶段耗时
    if has_profile:
        profiling = parser.get_job_profiling_analysis()
        if profiling and profiling.get('phases'):
            print(f"\n[Job 生命周期] 总耗时: {profiling['total_time_sec']:.2f}s")
            
            # 获取详细的子阶段信息
            profiling_map = profiling.get('profiling_map', {})
            
            # 定义所有阶段（包括主阶段和子阶段）
            all_phases = []
            
            # 1. Setup 阶段及其子阶段
            if 100 in profiling_map and 108 in profiling_map:
                setup_total = profiling_map[108] - profiling_map[100]
                all_phases.append({
                    'name': 'Setup（SQL初始化）',
                    'duration_ms': setup_total,
                    'level': 0,
                    'description': '包含编译优化等操作'
                })
                
                # Setup 子阶段
                if 101 in profiling_map and 102 in profiling_map:
                    all_phases.append({
                        'name': '  ├─ 预检查',
                        'duration_ms': profiling_map[102] - profiling_map[101],
                        'level': 1
                    })
                if 102 in profiling_map and 103 in profiling_map:
                    all_phases.append({
                        'name': '  ├─ 元数据创建',
                        'duration_ms': profiling_map[103] - profiling_map[102],
                        'level': 1
                    })
                if 106 in profiling_map and 108 in profiling_map:
                    all_phases.append({
                        'name': '  └─ 执行计划生成',
                        'duration_ms': profiling_map[108] - profiling_map[106],
                        'level': 1
                    })
            
            # 2. Resuming Cluster 阶段
            if 110 in profiling_map and 112 in profiling_map:
                all_phases.append({
                    'name': 'Resuming Cluster（启动VC）',
                    'duration_ms': profiling_map[112] - profiling_map[110],
                    'level': 0,
                    'description': '等待启动VC'
                })
            
            # 3. Queued 阶段
            if 112 in profiling_map and 120 in profiling_map:
                all_phases.append({
                    'name': 'Queued（等待资源）',
                    'duration_ms': profiling_map[120] - profiling_map[112],
                    'level': 0,
                    'description': '作业排队等待资源'
                })
            
            # 4. Running 阶段
            if 120 in profiling_map and 130 in profiling_map:
                all_phases.append({
                    'name': 'Running（SQL处理数据）',
                    'duration_ms': profiling_map[130] - profiling_map[120],
                    'level': 0,
                    'description': '核心计算阶段'
                })
            
            # 5. Finish 阶段及其子阶段
            if 130 in profiling_map and 150 in profiling_map:
                finish_total = profiling_map[150] - profiling_map[130]
                all_phases.append({
                    'name': 'Finish（SQL结束）',
                    'duration_ms': finish_total,
                    'level': 0,
                    'description': '包含commit、auto merge等'
                })
                
                # Finish 子阶段
                if 131 in profiling_map:
                    if 140 in profiling_map:
                        all_phases.append({
                            'name': '  ├─ 数据提交',
                            'duration_ms': profiling_map[140] - profiling_map[131],
                            'level': 1
                        })
                    if 140 in profiling_map and 150 in profiling_map:
                        all_phases.append({
                            'name': '  └─ 查询完成',
                            'duration_ms': profiling_map[150] - profiling_map[140],
                            'level': 1
                        })
            
            # 计算总时间用于百分比
            total_time = profiling['total_time_ms']
            
            # 显示所有阶段
            for phase in all_phases:
                name = phase['name']
                duration_ms = phase['duration_ms']
                level = phase['level']
                percentage = (duration_ms / total_time * 100) if total_time > 0 else 0
                
                # 格式化时间显示
                if duration_ms < 1000:
                    time_str = f"{duration_ms:>7.0f}ms"
                else:
                    time_str = f"{duration_ms/1000:>7.2f}s "
                
                # 主阶段显示进度条，子阶段不显示
                if level == 0:
                    bar_length = int(percentage / 2)
                    bar = '█' * bar_length if bar_length > 0 else ''
                    print(f"  {name:28s}  {time_str}  ({percentage:5.1f}%)  {bar}")
                    # 显示描述（如果有）
                    desc = phase.get('description', '')
                    if desc:
                        print(f"      └─ {desc}")
                else:
                    print(f"  {name:28s}  {time_str}  ({percentage:5.1f}%)")
    
    print("\n" + "=" * 80)
    print("步骤2: Stage 对齐与统计")
    print("=" * 80)
    
    aligner = StageAligner(parsed_data)
    aligned_data = aligner.align()
    total_time = aligned_data['total_job_time']

    print(f"\n[统计] Aligned Stages: {len(aligned_data['aligned_stages'])}, 总耗时: {total_time/1000:.2f}s")

    # 只有在有 profile 数据且有 plan 数据时才显示性能统计
    if has_profile and has_plan:
        top_stages = aligner.get_top_stages(10)
        print(f"\n[Top 10 Stage]")
        print(f"{'#':<4}{'Stage':<12}{'Time(s)':>10}{'%':>8}{'DOP':>8}")
        print("-" * 45)
        for i, (sid, m) in enumerate(top_stages, 1):
            pct = m['elapsed_ms'] / total_time * 100 if total_time else 0
            print(f"{i:<4}{sid:<12}{m['elapsed_ms']/1000:>10.2f}{pct:>8.1f}{m['dop']:>8}")

        top_ops = aligner.get_top_operators(10)
        print(f"\n[Top 10 Operator]")
        print(f"{'#':<4}{'Stage':<12}{'Operator':<25}{'Max(s)':>8}{'Min(s)':>8}{'Stage%':>7}{'TSkew':>7}{'MaxRows':>11}{'MinRows':>11}{'RSkew':>7}")
        print("-" * 103)
        for i, op in enumerate(top_ops, 1):
            # 时间 min：过滤无效 0
            min_ms = op.get('min_time_ms')
            min_time_str = f"{min_ms/1000:.2f}" if min_ms is not None else "-"
            # 行数 max/min
            max_rows = op.get('row_count_max', 0)
            min_rows = op.get('row_count_min')
            max_rows_str = f"{max_rows:,}" if max_rows > 0 else "-"
            min_rows_str = f"{min_rows:,}" if min_rows is not None else "-"
            # row skew
            row_skew = op.get('row_skew_ratio', 1.0)
            row_skew_str = f"{row_skew:.1f}" if max_rows > 0 else "-"
            print(f"{i:<4}{op['stage_id']:<12}{op['operator_id']:<25}"
                  f"{op['max_time_ms']/1000:>8.2f}{min_time_str:>8}{op['stage_pct']:>7.1f}{op['skew_ratio']:>7.1f}"
                  f"{max_rows_str:>11}{min_rows_str:>11}{row_skew_str:>7}")
    elif has_profile and not has_plan:
        print("\n[提示] 没有 plan 数据，跳过性能统计展示（仅能进行错误分析）")
    else:
        print("\n[提示] 没有 profile 数据，跳过性能统计展示")
    
    sql_type = 'REFRESH' if sql_info['is_refresh'] else 'REGULAR'
    analyzer = get_analyzer(sql_type=sql_type, vc_mode=vc_mode['mode'],
                           enable_state_table_rules=enable_state_table_analysis,
                           enable_incremental_algorithm_rules=enable_incremental_algorithm_analysis)
    analyzer.context['sql_info'] = sql_info  # 传递 SQL 信息用于规则判断
    analyzer.context['settings'] = settings
    analyzer.context['vc_mode'] = vc_mode['mode']
    analyzer.context['vc_mode_info'] = vc_mode  # 传递完整 vc_mode 信息（含 vc_cores）
    analyzer.context['version_info'] = version_info
    analyzer.context['has_profile'] = has_profile  # 传递 profile 数据标志
    analyzer.context['raw_profile'] = parsed_data.get('raw_profile', {})  # 传递原始 profile 数据
    analyzer.context['parser'] = parser  # 传递 parser 用于 Job Profiling 分析
    analyzer.context['enable_incremental_algorithm_analysis'] = enable_incremental_algorithm_analysis  # 传递增量算法策略控制参数
    if extra_files:
        analyzer.context['extra_files'] = extra_files
    
    print("\n" + "=" * 80)
    print("步骤3: 执行规则分析")
    print("=" * 80)
    
    analyzer.analyze(aligned_data)
    reporter = analyzer.get_report()
    reporter.set_metadata('vc_mode', vc_mode['mode'])

    # 如果 context 中有增量算法数据，传递给 reporter
    if 'incremental_algorithms' in analyzer.context:
        reporter.set_incremental_algorithms(analyzer.context['incremental_algorithms'])

    is_debug = log_level.upper() == 'DEBUG'
    console_report = reporter.generate_console_report(analyzer.context,
        sections=['summary', 'findings', 'recommendations', 'insights'] if is_debug
        else ['summary', 'recommendations', 'insights'],
        show_detail_insights=is_debug,
        analysis_mode=analysis_mode
    )
    # 捕获模式下，绕过 Tee 直接写原始 stdout，避免 console_report 被重复捕获到 output 中
    if capture_output and output_capture:
        output_capture.original_stdout.write("\n" + console_report + "\n")
        output_capture.original_stdout.flush()
    else:
        print("\n" + console_report)
    
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, "analysis_results.json")
    reporter.save_json_report(output_path, analyzer.context, analysis_mode)
    print(f"\n结果已保存: {output_path}")
    
    # 生成 JSON 报告
    json_report = reporter.generate_json_report(analyzer.context, analysis_mode)
    
    # 如果捕获输出，返回输出文本和 JSON 报告
    if capture_output and output_capture:
        print(f"\n分析过程以及结果已返回")
        captured_text = output_capture.get_output()
        result = {
            'output': captured_text,
            'json_report': console_report
        }
        # detailed/expert 模式：附加结构化 JSON 报告（含 analysis_scope）
        if analysis_mode in ('detailed', 'expert'):
            result['structured_json_report'] = json_report
        return result
    else:
        print(f"\n结果已返回")
        return console_report

def main():
    import argparse

    parser = argparse.ArgumentParser(
        description='Clickzetta Job 性能分析工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 使用 job 目录（自动发现所有文件）
  python analyze_job.py --job-dir /path/to/202603302022081304091991

  # 基本分析（两个文件都提供）
  python analyze_job.py plan.json job_profile.json

  # 只有 plan.json（可进行状态表优化分析）
  python analyze_job.py plan.json --enable-state-table

  # 只有 job_profile.json（可进行错误分析）
  python analyze_job.py --profile job_profile.json

  # 启用状态表优化分析
  python analyze_job.py plan.json job_profile.json --enable-state-table

  # 启用增量算法策略分析
  python analyze_job.py plan.json job_profile.json --enable-incremental-algorithm

  # 启用输出捕获（用于程序化调用）
  python analyze_job.py plan.json job_profile.json --capture-output

  # 指定输出目录
  python analyze_job.py plan.json job_profile.json -o ./output
        """
    )

    parser.add_argument('plan_file', nargs='?', help='plan.json 文件路径（可选）')
    parser.add_argument('profile_file', nargs='?', help='job_profile.json 文件路径（可选，也可通过 --profile 指定）')
    parser.add_argument('--compare', nargs=2, metavar=('JOB_A', 'JOB_B'),
                       help='对比两个 job，参数为两个 job 目录或 job_profile.json 路径')
    parser.add_argument('--job-dir', '-d', dest='job_dir',
                       help='Job 目录路径，自动发现 plan.json(.gz)、job_profile.json、dag_summary.json、stats_summary.json 等文件')
    parser.add_argument('--profile', '-p', dest='profile_file_opt',
                       help='job_profile.json 文件路径（可选，替代位置参数）')
    parser.add_argument('-o', '--output', dest='output_dir', default='.',
                       help='输出目录（默认: 当前目录）')
    parser.add_argument('--enable-state-table', action='store_true',
                       help='启用状态表优化分析（默认禁用）')
    parser.add_argument('--enable-incremental-algorithm', action='store_true',
                       help='启用增量算法策略分析（默认禁用，避免浪费分析时间）')
    parser.add_argument('--capture-output', action='store_true',
                       help='捕获所有输出并返回（用于程序化调用，默认禁用）')
    parser.add_argument('--log-level', type=str, default='INFO',
                       choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
                       help='日志级别 (默认: INFO)')
    parser.add_argument('--analysis-mode', type=str, default='quick',
                       choices=['quick', 'detailed', 'expert'],
                       help='分析模式: quick（默认，纯规则引擎）、detailed（规则+AI研判数据）、expert（深度分析数据）')

    args = parser.parse_args()

    # === 对比模式 ===
    if args.compare:
        from .compare_jobs import compare_jobs

        def _resolve_job(path):
            if os.path.isdir(path):
                resolved = resolve_job_dir(path)
                if not resolved['profile_file']:
                    sys.stderr.write(f"错误: 目录中未找到 job_profile.json - {path}\n")
                    sys.exit(1)
                stats = ''
                for base in ['stats_summary.json.gz', 'stats_summary.json']:
                    for root, _, files in os.walk(path):
                        if base in files:
                            stats = os.path.join(root, base)
                            break
                    if stats:
                        break
                return resolved['profile_file'], stats
            return path, ''

        pa, sa = _resolve_job(args.compare[0])
        pb, sb = _resolve_job(args.compare[1])
        print(compare_jobs(pa, pb, sa, sb))
        return

    extra_files = {}

    # 如果指定了 --job-dir，从目录中自动发现文件
    if args.job_dir:
        resolved = resolve_job_dir(args.job_dir)
        plan_file = resolved['plan_file']
        profile_file = resolved['profile_file']
        extra_files = resolved['extra_files']
    else:
        plan_file = args.plan_file or ''
        # 处理 profile_file：优先使用 --profile，否则使用位置参数
        if args.profile_file_opt:
            profile_file = args.profile_file_opt
        else:
            profile_file = args.profile_file or ''
    
    # 检查至少提供一个文件
    if not plan_file and not profile_file:
        sys.stderr.write("错误: 至少需要提供 plan.json 或 job_profile.json 之一（或使用 --job-dir）\n")
        sys.stderr.write("使用 --help 查看帮助信息\n")
        sys.exit(1)

    # 检查文件是否存在
    if plan_file and not os.path.exists(plan_file):
        sys.stderr.write(f"错误: 文件不存在 - {plan_file}\n")
        sys.exit(1)
    if profile_file and not os.path.exists(profile_file):
        sys.stderr.write(f"错误: 文件不存在 - {profile_file}\n")
        sys.exit(1)

    print_header()
    result = analyze_job(
        plan_file,
        profile_file,
        args.output_dir, 
        args.enable_state_table, 
        args.enable_incremental_algorithm,
        args.log_level,
        args.capture_output,
        args.analysis_mode,
        extra_files
    )
    
    # 如果启用了输出捕获，打印返回值信息
    if args.capture_output:
        print("\n" + "=" * 80)
        print("输出捕获模式")
        print("=" * 80)
        if isinstance(result, dict) and 'output' in result:
            print(f"✅ 已捕获 {len(result['output'])} 字符的输出")
            print(f"✅ JSON 报告包含 {len(result['json_report'])} 个键")
        else:
            print("⚠️  返回值格式异常")

if __name__ == '__main__':
    main()
