#!/usr/bin/env python3
"""增量计算分析器"""
import traceback


import logging
logger = logging.getLogger(__name__)

from typing import Dict
from .base_analyzer import BaseAnalyzer
from ..rules.incremental.stage_optimization import (
    RefreshTypeDetection, SingleDopAggregate, HashJoinOptimization,
    TableSinkDop, MaxDopCheck, SpillingAnalysis, SkewDetection,
    ResourceEfficiencyAnalysis, ActiveProblemFinding,
)
from ..rules.incremental.state_table import (
    NonIncrementalDiagnosis, RowNumberCheck, AppendOnlyScan,
    StateTableEnable, AggregateReuse, HeavyCalcState,
    IncrementalAlgorithmVisualization,
)
from ..rules.common import (
    ErrorMessageCollector, JobConflictDetection, OptimizerErrorDetection,
    CpuEfficiencyAnalysis, ResourceWaitAnalysis,
)


class IncrementalAnalyzer(BaseAnalyzer):
    name = "incremental_analyzer"
    description = "分析 REFRESH SQL 的性能问题"

    def __init__(self, enable_state_table_rules: bool = True, enable_incremental_algorithm_rules: bool = False):
        super().__init__()
        # Stage 级别规则
        self.stage_rules = [
            RefreshTypeDetection(), SingleDopAggregate(), HashJoinOptimization(),
            TableSinkDop(), MaxDopCheck(), SpillingAnalysis(), SkewDetection(),
            ResourceEfficiencyAnalysis(), ActiveProblemFinding(),
        ]

        # 全局规则和 Stage 级别状态表规则
        self.global_rules = []
        self.state_table_rules = []

        # 错误分析规则（始终启用，且必须按顺序执行）
        # 1. 先收集所有错误信息
        self.global_rules.append(ErrorMessageCollector())
        # 2. 再基于收集的错误信息进行具体分析
        self.global_rules.append(JobConflictDetection())
        self.global_rules.append(OptimizerErrorDetection())

        # extra_files 分析规则（有数据时自动生效）
        self.global_rules.append(CpuEfficiencyAnalysis())
        self.global_rules.append(ResourceWaitAnalysis())

        # **关键修复**：增量算法分析由独立的参数控制
        if enable_incremental_algorithm_rules:
            self.global_rules.append(IncrementalAlgorithmVisualization())

        if enable_state_table_rules:
            # 全局规则
            self.global_rules.append(NonIncrementalDiagnosis())
            self.global_rules.append(StateTableEnable())  # StateTableEnable 是全局规则
            # Stage 级别状态表规则
            self.state_table_rules = [
                RowNumberCheck(), AppendOnlyScan(),
                AggregateReuse(), HeavyCalcState(),
            ]

        self.refresh_type = None

    def analyze(self, aligned_data: Dict) -> Dict:
        aligned_stages = aligned_data.get('aligned_stages', {})
        self.context['total_job_time'] = aligned_data.get('total_job_time', 0)
        self.context['all_stage_metrics'] = aligned_data.get('stage_metrics', {})
        self.context['operator_analysis'] = aligned_data.get('operator_analysis', [])
        self.context['aligned_stages'] = aligned_stages
        self.context['stage_dependencies'] = aligned_data.get('stage_dependencies', {})
        self.context['global_task_timeline'] = aligned_data.get('global_task_timeline', [])
        self.context['per_stage_task_timeline'] = aligned_data.get('per_stage_task_timeline', {})
        self.context['reporter'] = self.reporter  # 传递 reporter 给规则

        all_results = {'findings': [], 'recommendations': [], 'insights': []}
        # 将 all_results 存入 context，供后续规则（如 active_problem_finding）读取已有 findings
        self.context['all_results'] = all_results

        print("阶段1: Stage/Operator 级别优化分析")

        # 执行 Stage 级别规则
        for stage_id, stage_data in aligned_stages.items():
            stage_data['stage_id'] = stage_id
            for rule in self.stage_rules:
                try:
                    if rule.check(stage_data, self.context):
                        result = rule.analyze(stage_data, self.context)
                        self._merge_results(all_results, result)
                        if rule.name == 'refresh_type_detection' and result.get('refresh_type'):
                            self.refresh_type = result['refresh_type']
                            self.context['refresh_type'] = self.refresh_type
                            logger.debug(f"  [{rule.name}] 刷新类型: {self.refresh_type}")
                        elif result.get('findings'):
                            logger.debug(f"  [{rule.name}] Stage {stage_id}: 发现 {len(result['findings'])} 个问题")
                except Exception as e:
                    logger.error(f"  [{rule.name}] Stage {stage_id}: 异常 - {str(e)}")

        # 执行全局规则（只执行一次）
        # 注意：错误分析规则（ErrorMessageCollector, JobConflictDetection, OptimizerErrorDetection）
        # 对所有 SQL 类型都适用，但增量相关的全局规则（NonIncrementalDiagnosis, StateTableEnable, 
        # IncrementalAlgorithmVisualization）只对 REFRESH SQL 生效
        if self.global_rules:
            print("阶段2: 全局规则分析")
            
            # 获取 SQL 类型
            sql_info = self.context.get('sql_info', {})
            is_refresh_sql = sql_info.get('is_refresh', False)
            
            # 错误分析规则（对所有 SQL 类型生效）
            error_analysis_rules = ['error_message_collector', 'job_conflict_detection', 'optimizer_error_detection']
            # 增量相关的全局规则（只对 REFRESH SQL 生效）
            incremental_global_rules = ['non_incremental_diagnosis', 'state_table_enable', 'incremental_algorithm_visualization']
            
            for rule in self.global_rules:
                try:
                    # 如果是增量相关的规则，检查 SQL 类型
                    if rule.name in incremental_global_rules and not is_refresh_sql:
                        logger.debug(f"  [{rule.name}] 跳过（仅适用于 REFRESH SQL）")
                        continue
                    
                    # 全量刷新时，state_table 相关的全局规则（除 non_incremental_diagnosis 外）跳过
                    if rule.name in ('state_table_enable', 'incremental_algorithm_visualization') and self.refresh_type == 'FULL':
                        logger.debug(f"  [{rule.name}] 跳过（全量刷新时不需要状态表/增量算法分析）")
                        continue
                    
                    result = rule.analyze_global(self.context)
                    self._merge_results(all_results, result)
                    if result.get('findings'):
                        logger.debug(f"  [{rule.name}] 发现 {len(result['findings'])} 个全局问题")
                    if result.get('insights'):
                        logger.debug(f"  [{rule.name}] 生成 {len(result['insights'])} 条洞察")
                except Exception as e:
                    logger.error(f"  [{rule.name}] 异常 - {str(e)}")
                    logger.debug(traceback.format_exc())

        # 执行 Stage 级别状态表规则（只对 REFRESH SQL 生效）
        if self.state_table_rules:
            # 获取 SQL 类型
            sql_info = self.context.get('sql_info', {})
            is_refresh_sql = sql_info.get('is_refresh', False)
            
            if not is_refresh_sql:
                print("阶段3: 状态表优化分析 - 跳过（仅适用于 REFRESH SQL）")
            elif self.refresh_type == 'FULL':
                print("阶段3: 状态表优化分析 - 跳过（全量刷新时不需要）")
            else:
                print("阶段3: 状态表优化分析")
                for stage_id, stage_data in aligned_stages.items():
                    stage_data['stage_id'] = stage_id
                    for rule in self.state_table_rules:
                        try:
                            if rule.check(stage_data, self.context):
                                result = rule.analyze(stage_data, self.context)
                                self._merge_results(all_results, result)
                                if result.get('findings'):
                                    logger.debug(f"  [{rule.name}] Stage {stage_id}: 发现 {len(result['findings'])} 个问题")
                        except Exception as e:
                            logger.error(f"  [{rule.name}] Stage {stage_id}: 异常 - {str(e)}")

        for f in all_results['findings']:
            self.reporter.add_finding(f)
        for r in all_results['recommendations']:
            self.reporter.add_recommendation(r)
        for i in all_results['insights']:
            self.reporter.add_insight(i)

        # 从 context 中获取实际的 SQL 类型
        sql_info = self.context.get('sql_info', {})
        is_refresh = sql_info.get('is_refresh', False)
        sql_subtype = sql_info.get('sql_subtype', 'UNKNOWN')
        
        if is_refresh:
            actual_sql_type = 'REFRESH'
        else:
            # 对于 Regular SQL，显示子类型
            actual_sql_type = f'REGULAR ({sql_subtype})'
        
        self.reporter.set_metadata('sql_type', actual_sql_type)
        self.reporter.set_metadata('refresh_type', self.refresh_type)
        
        # 设置两个时间：Job 生命周期总耗时和 Stage 执行时间
        stage_total_time_sec = aligned_data.get('total_job_time', 0) / 1000
        self.reporter.set_metadata('stage_total_time_seconds', stage_total_time_sec)
        
        # 尝试获取 Job Profiling 的总耗时
        parser = self.context.get('parser')
        if parser:
            profiling = parser.get_job_profiling_analysis()
            if profiling and profiling.get('total_time_sec'):
                self.reporter.set_metadata('job_total_time_seconds', profiling['total_time_sec'])
        
        # 兼容旧版本：如果没有 Job Profiling 数据，total_time_seconds 使用 Stage 时间
        if not self.reporter.metadata.get('job_total_time_seconds'):
            self.reporter.set_metadata('total_time_seconds', stage_total_time_sec)
        
        self.reporter.set_metadata('stage_count', len(aligned_stages))

        return all_results

    def _merge_results(self, target: Dict, source: Dict):
        target['findings'].extend(source.get('findings', []))
        target['recommendations'].extend(source.get('recommendations', []))
        target['insights'].extend(source.get('insights', []))

