#!/usr/bin/env python3
"""分析器模块"""
from .base_analyzer import BaseAnalyzer
from .incremental_analyzer import IncrementalAnalyzer

def get_analyzer(sql_type: str, vc_mode: str = 'GP', **kwargs):
    if sql_type == 'REFRESH':
        return IncrementalAnalyzer(**kwargs)
    # For non-REFRESH SQL, set default enable_state_table_rules=False if not provided
    if 'enable_state_table_rules' not in kwargs:
        kwargs['enable_state_table_rules'] = False
    return IncrementalAnalyzer(**kwargs)

__all__ = ['BaseAnalyzer', 'IncrementalAnalyzer', 'get_analyzer']
