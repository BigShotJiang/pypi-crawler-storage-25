#!/usr/bin/env python3
"""测试 df_and join 的 delta/snapshot 传播逻辑"""
import sys
import os

# 添加项目根目录到 Python 路径
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))

from cz_skills.job_performance_analyzer.utils.incremental_algorithm_analyzer import (
    IncrementalAlgorithmAnalyzer,
    DataType
)


def test_df_and_join_follows_left_input():
    """
    测试 df_and join 应该完全依赖左边输入的 delta/snapshot 属性
    
    场景：
    - HashJoin50 是 df_and join
    - 左边输入是 delta
    - 右边输入是 delta（用于裁剪）
    - 结果应该是 delta（跟随左边）
    
    - HashJoin42 依赖 HashJoin50
    - 应该被识别为依赖 delta 输入
    """
    plan = {
        'operators': [
            # Operator 0: TableScan (delta) - 左边输入
            {
                'id': '100',
                'tableScan': {
                    'incrementalTableProperty': {
                        'from': '28800',
                        'to': '57600'
                    }
                },
                'inputIds': []
            },
            # Operator 1: TableScan (delta) - 右边输入（用于裁剪）
            {
                'id': '101',
                'tableScan': {
                    'incrementalTableProperty': {
                        'from': '28800',
                        'to': '57600'
                    }
                },
                'inputIds': []
            },
            # Operator 2: HashJoin50 (df_and join)
            # 应该跟随左边输入 -> delta
            {
                'id': '50',
                'hashJoin': {
                    'join': {
                        'type': 'INNER',
                        'hint': {
                            'comments': 'df_and'
                        }
                    }
                },
                'inputIds': ['100', '101']
            },
            # Operator 3: TableScan (snapshot)
            {
                'id': '102',
                'tableScan': {
                    'incrementalTableProperty': {
                        'from': '-9223372036854775808',
                        'to': '57600'
                    }
                },
                'inputIds': []
            },
            # Operator 4: HashJoin42 (普通 join)
            # 左边是 delta (HashJoin50)，右边是 snapshot
            # 应该是 delta
            {
                'id': '42',
                'hashJoin': {
                    'join': {
                        'type': 'INNER'
                    }
                },
                'inputIds': ['50', '102']
            }
        ]
    }

    analyzer = IncrementalAlgorithmAnalyzer(plan)
    result = analyzer.analyze()

    # 验证 TableScan 的数据类型
    assert result['operator_data_types']['100'] == 'delta', f"Expected delta, got {result['operator_data_types']['100']}"
    assert result['operator_data_types']['101'] == 'delta', f"Expected delta, got {result['operator_data_types']['101']}"
    assert result['operator_data_types']['102'] == 'snapshot', f"Expected snapshot, got {result['operator_data_types']['102']}"

    # 验证 df_and join (HashJoin50) 跟随左边输入 -> delta
    assert result['operator_data_types']['50'] == 'delta', f"Expected delta for df_and join, got {result['operator_data_types']['50']}"

    # 验证 HashJoin42 识别为 delta（因为左边是 delta）
    assert result['operator_data_types']['42'] == 'delta', f"Expected delta, got {result['operator_data_types']['42']}"
    
    print("✓ test_df_and_join_follows_left_input passed")


def test_df_and_join_with_snapshot_left():
    """
    测试 df_and join 当左边是 snapshot 时的行为
    
    场景：
    - df_and join 左边是 snapshot
    - 右边是 delta（用于裁剪）
    - 结果应该是 snapshot（跟随左边）
    """
    plan = {
        'operators': [
            # Operator 0: TableScan (snapshot) - 左边输入
            {
                'id': '100',
                'tableScan': {
                    'incrementalTableProperty': {
                        'from': '-9223372036854775808',
                        'to': '57600'
                    }
                },
                'inputIds': []
            },
            # Operator 1: TableScan (delta) - 右边输入（用于裁剪）
            {
                'id': '101',
                'tableScan': {
                    'incrementalTableProperty': {
                        'from': '28800',
                        'to': '57600'
                    }
                },
                'inputIds': []
            },
            # Operator 2: df_and join
            # 应该跟随左边输入 -> snapshot
            {
                'id': '50',
                'hashJoin': {
                    'join': {
                        'type': 'INNER',
                        'hint': {
                            'comments': 'df_and'
                        }
                    }
                },
                'inputIds': ['100', '101']
            }
        ]
    }

    analyzer = IncrementalAlgorithmAnalyzer(plan)
    result = analyzer.analyze()

    # 验证 df_and join 跟随左边输入 -> snapshot
    assert result['operator_data_types']['50'] == 'snapshot', f"Expected snapshot for df_and join, got {result['operator_data_types']['50']}"
    
    print("✓ test_df_and_join_with_snapshot_left passed")


def test_normal_join_vs_df_and_join():
    """
    对比普通 join 和 df_and join 的行为差异
    
    场景：
    - 普通 join: delta + delta -> delta
    - df_and join: delta + delta -> delta (跟随左边)
    - 普通 join: snapshot + delta -> delta
    - df_and join: snapshot + delta -> snapshot (跟随左边)
    """
    plan = {
        'operators': [
            # Operator 0: TableScan (delta)
            {
                'id': '100',
                'tableScan': {
                    'incrementalTableProperty': {
                        'from': '28800',
                        'to': '57600'
                    }
                },
                'inputIds': []
            },
            # Operator 1: TableScan (delta)
            {
                'id': '101',
                'tableScan': {
                    'incrementalTableProperty': {
                        'from': '28800',
                        'to': '57600'
                    }
                },
                'inputIds': []
            },
            # Operator 2: 普通 join (delta + delta -> delta)
            {
                'id': '200',
                'hashJoin': {
                    'join': {
                        'type': 'INNER'
                    }
                },
                'inputIds': ['100', '101']
            },
            # Operator 3: df_and join (delta + delta -> delta)
            {
                'id': '201',
                'hashJoin': {
                    'join': {
                        'type': 'INNER',
                        'hint': {
                            'comments': 'df_and'
                        }
                    }
                },
                'inputIds': ['100', '101']
            },
            # Operator 4: TableScan (snapshot)
            {
                'id': '102',
                'tableScan': {
                    'incrementalTableProperty': {
                        'from': '-9223372036854775808',
                        'to': '57600'
                    }
                },
                'inputIds': []
            },
            # Operator 5: 普通 join (snapshot + delta -> delta)
            {
                'id': '202',
                'hashJoin': {
                    'join': {
                        'type': 'INNER'
                    }
                },
                'inputIds': ['102', '101']
            },
            # Operator 6: df_and join (snapshot + delta -> snapshot)
            {
                'id': '203',
                'hashJoin': {
                    'join': {
                        'type': 'INNER',
                        'hint': {
                            'comments': 'df_and'
                        }
                    }
                },
                'inputIds': ['102', '101']
            }
        ]
    }

    analyzer = IncrementalAlgorithmAnalyzer(plan)
    result = analyzer.analyze()

    # 普通 join: delta + delta -> delta
    assert result['operator_data_types']['200'] == 'delta', f"Expected delta, got {result['operator_data_types']['200']}"
    
    # df_and join: delta + delta -> delta (跟随左边)
    assert result['operator_data_types']['201'] == 'delta', f"Expected delta, got {result['operator_data_types']['201']}"
    
    # 普通 join: snapshot + delta -> delta
    assert result['operator_data_types']['202'] == 'delta', f"Expected delta, got {result['operator_data_types']['202']}"
    
    # df_and join: snapshot + delta -> snapshot (跟随左边)
    assert result['operator_data_types']['203'] == 'snapshot', f"Expected snapshot for df_and join, got {result['operator_data_types']['203']}"
    
    print("✓ test_normal_join_vs_df_and_join passed")


if __name__ == '__main__':
    print("Running df_and join tests...")
    print()
    
    try:
        test_df_and_join_follows_left_input()
        test_df_and_join_with_snapshot_left()
        test_normal_join_vs_df_and_join()
        
        print()
        print("=" * 60)
        print("All tests passed! ✓")
        print("=" * 60)
    except AssertionError as e:
        print()
        print("=" * 60)
        print(f"Test failed: {e}")
        print("=" * 60)
        sys.exit(1)
    except Exception as e:
        print()
        print("=" * 60)
        print(f"Error: {e}")
        print("=" * 60)
        import traceback
        traceback.print_exc()
        sys.exit(1)

