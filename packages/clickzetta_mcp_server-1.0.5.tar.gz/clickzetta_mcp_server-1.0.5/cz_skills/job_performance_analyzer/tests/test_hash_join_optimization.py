#!/usr/bin/env python3
"""测试 Hash Join 优化规则

Case 覆盖：
  Case 1: Broadcast Hash Join build heavy → HIGH finding + recommendation
  Case 2: Shuffle Hash Join build heavy → MEDIUM finding, no recommendation
  Case 3: build/probe 比值低于阈值 → 不触发
  Case 4: df_and join → 降级为 detail
  Case 5: join 算子耗时低 → 降级为 detail
  Case 6: 前提过滤 — stage 耗时太短 / 无 hashJoin
  Case 7: Broadcast join 耗时占比高 → BROADCAST_JOIN_SLOW（含 build 侧数据量信息）
  Case 8: 递归叶子节点查找
"""
import unittest
from cz_skills.job_performance_analyzer.rules.incremental.stage_optimization.hash_join_optimization import HashJoinOptimization


class TestHashJoinOptimization(unittest.TestCase):
    def setUp(self):
        self.rule = HashJoinOptimization()
        self.base_context = {
            'has_profile': True,
            'settings': {},
            'total_job_time': 1000000,
            'aligned_stages': {},
        }

    def _make_stage_data(self, stage_id='stg1', elapsed_ms=200000,
                         operators=None, op_summary=None):
        return {
            'stage_id': stage_id,
            'plan': {'operators': operators or []},
            'plan_operators': operators or [],
            'profile': {'operatorSummary': op_summary or {}},
            'metrics': {'elapsed_ms': elapsed_ms},
        }

    def _make_hash_join_op(self, op_id='HashJoin1', probe_id='Calc1', build_id='ShuffleRead1',
                           broadcast=True, is_df=False):
        comments = 'Rule:df_and_test' if is_df else 'Rule:IncrementalJoin'
        return {
            'id': op_id,
            'inputIds': [probe_id, build_id],
            'hashJoin': {
                'join': {'hint': {'comments': comments}},
                'probeOperatorId': probe_id,
                'broadcast': broadcast,
            },
        }

    def _make_leaf_op(self, op_id='ShuffleRead1'):
        return {'id': op_id, 'inputIds': []}

    def _make_calc_op(self, op_id='Calc1', input_ids=None):
        return {'id': op_id, 'inputIds': input_ids or [], 'calc': {}}

    def _make_op_summary(self, op_id, wall_max_ns=0, row_sum=0, input_bytes=0):
        result = {
            'wallTimeNs': {'max': str(wall_max_ns)},
            'rowCount': {'sum': str(row_sum)},
        }
        if input_bytes > 0:
            result['inputOutputStats'] = {'inputBytes': str(input_bytes)}
        return {op_id: result}

    # ---- Case 1: Broadcast build heavy ----

    def test_broadcast_build_heavy(self):
        """Broadcast Hash Join, build >> probe → HIGH + recommendation"""
        build_op = self._make_leaf_op('ShuffleRead1')
        probe_op = self._make_leaf_op('ShuffleRead2')
        hj_op = self._make_hash_join_op('HashJoin1', 'ShuffleRead2', 'ShuffleRead1', broadcast=True)
        operators = [hj_op, build_op, probe_op]

        op_summary = {}
        op_summary.update(self._make_op_summary('ShuffleRead1', input_bytes=1000*1024**3, row_sum=80_000_000_000))
        op_summary.update(self._make_op_summary('ShuffleRead2', input_bytes=50*1024**3, row_sum=400_000_000))
        op_summary.update(self._make_op_summary('HashJoin1', wall_max_ns=77_000_000_000))

        stage_data = self._make_stage_data(operators=operators, op_summary=op_summary)
        self.assertTrue(self.rule.check(stage_data, self.base_context))

        result = self.rule.analyze(stage_data, self.base_context)
        self.assertEqual(len(result['findings']), 1)
        self.assertEqual(result['findings'][0]['type'], 'HASH_JOIN_BUILD_HEAVY')
        self.assertEqual(result['findings'][0]['severity'], 'HIGH')
        self.assertTrue(len(result['recommendations']) > 0)
        self.assertIn('broadcast', result['recommendations'][0]['setting'])

    # ---- Case 2: Shuffle build heavy ----

    def test_shuffle_build_heavy(self):
        """Shuffle Hash Join, build >> probe → MEDIUM, no recommendation"""
        build_op = self._make_leaf_op('ShuffleRead1')
        probe_op = self._make_leaf_op('ShuffleRead2')
        hj_op = self._make_hash_join_op('HashJoin1', 'ShuffleRead2', 'ShuffleRead1', broadcast=False)
        operators = [hj_op, build_op, probe_op]

        op_summary = {}
        op_summary.update(self._make_op_summary('ShuffleRead1', input_bytes=500*1024**3))
        op_summary.update(self._make_op_summary('ShuffleRead2', input_bytes=10*1024**3))
        op_summary.update(self._make_op_summary('HashJoin1', wall_max_ns=30_000_000_000))

        stage_data = self._make_stage_data(operators=operators, op_summary=op_summary)
        result = self.rule.analyze(stage_data, self.base_context)
        self.assertEqual(result['findings'][0]['severity'], 'MEDIUM')
        self.assertEqual(len(result['recommendations']), 0)

    # ---- Case 3: ratio below threshold ----

    def test_ratio_below_threshold(self):
        """build/probe ratio < 10x → no finding"""
        build_op = self._make_leaf_op('ShuffleRead1')
        probe_op = self._make_leaf_op('ShuffleRead2')
        hj_op = self._make_hash_join_op('HashJoin1', 'ShuffleRead2', 'ShuffleRead1', broadcast=True)
        operators = [hj_op, build_op, probe_op]

        op_summary = {}
        op_summary.update(self._make_op_summary('ShuffleRead1', input_bytes=50*1024**3))
        op_summary.update(self._make_op_summary('ShuffleRead2', input_bytes=10*1024**3))  # 5x < 10x
        op_summary.update(self._make_op_summary('HashJoin1', wall_max_ns=10_000_000_000))

        stage_data = self._make_stage_data(operators=operators, op_summary=op_summary)
        result = self.rule.analyze(stage_data, self.base_context)
        build_heavy = [f for f in result['findings'] if f['type'] == 'HASH_JOIN_BUILD_HEAVY']
        self.assertEqual(len(build_heavy), 0)

    # ---- Case 4: df_and join → detail ----

    def test_df_and_join_downgraded(self):
        """df_and join → insight level=detail, no recommendation"""
        build_op = self._make_leaf_op('ShuffleRead1')
        probe_op = self._make_leaf_op('ShuffleRead2')
        hj_op = self._make_hash_join_op('HashJoin1', 'ShuffleRead2', 'ShuffleRead1',
                                         broadcast=True, is_df=True)
        operators = [hj_op, build_op, probe_op]

        op_summary = {}
        op_summary.update(self._make_op_summary('ShuffleRead1', input_bytes=1000*1024**3))
        op_summary.update(self._make_op_summary('ShuffleRead2', input_bytes=10*1024**3))
        op_summary.update(self._make_op_summary('HashJoin1', wall_max_ns=50_000_000_000))

        stage_data = self._make_stage_data(operators=operators, op_summary=op_summary)
        result = self.rule.analyze(stage_data, self.base_context)
        # finding 仍然产出但 severity 降低
        self.assertTrue(len(result['findings']) > 0)
        # 不应该有 recommendation（df join 降级）
        self.assertEqual(len(result['recommendations']), 0)
        # insight 应该是 detail 级别
        detail_insights = [i for i in result['insights'] if i.get('level') == 'detail']
        self.assertTrue(len(detail_insights) > 0)

    # ---- Case 5: low join time → detail ----

    def test_low_join_time_downgraded(self):
        """join 算子耗时 < 5s → detail, no recommendation"""
        build_op = self._make_leaf_op('ShuffleRead1')
        probe_op = self._make_leaf_op('ShuffleRead2')
        hj_op = self._make_hash_join_op('HashJoin1', 'ShuffleRead2', 'ShuffleRead1', broadcast=True)
        operators = [hj_op, build_op, probe_op]

        op_summary = {}
        op_summary.update(self._make_op_summary('ShuffleRead1', input_bytes=500*1024**3))
        op_summary.update(self._make_op_summary('ShuffleRead2', input_bytes=5*1024**3))
        op_summary.update(self._make_op_summary('HashJoin1', wall_max_ns=2_000_000_000))  # 2s < 5s

        stage_data = self._make_stage_data(operators=operators, op_summary=op_summary)
        result = self.rule.analyze(stage_data, self.base_context)
        self.assertEqual(len(result['recommendations']), 0)

    # ---- Case 6: check filter ----

    def test_check_no_hash_join(self):
        """no hashJoin operator → check returns False"""
        operators = [{'id': 'Calc1', 'calc': {}}]
        stage_data = self._make_stage_data(operators=operators)
        self.assertFalse(self.rule.check(stage_data, self.base_context))

    def test_check_short_stage(self):
        """stage too short → check returns False"""
        hj_op = self._make_hash_join_op()
        stage_data = self._make_stage_data(elapsed_ms=5000, operators=[hj_op])
        ctx = {**self.base_context, 'total_job_time': 1000000}
        self.assertFalse(self.rule.check(stage_data, ctx))

    # ---- Case 7: Broadcast join slow (high join_pct) ----

    def test_broadcast_join_slow_with_build_info(self):
        """Broadcast join 耗时占比高 + build 侧数据量信息 → BROADCAST_JOIN_SLOW + recommendation"""
        build_op = self._make_leaf_op('ShuffleRead1')
        probe_op = self._make_leaf_op('ShuffleRead2')
        # ratio < 10x so no HASH_JOIN_BUILD_HEAVY, but join_pct > 30%
        hj_op = self._make_hash_join_op('HashJoin1', 'ShuffleRead2', 'ShuffleRead1', broadcast=True)
        operators = [hj_op, build_op, probe_op]

        op_summary = {}
        op_summary.update(self._make_op_summary('ShuffleRead1', input_bytes=30*1024**3))   # 30GB build
        op_summary.update(self._make_op_summary('ShuffleRead2', input_bytes=10*1024**3))   # 10GB probe → 3x < 10x
        op_summary.update(self._make_op_summary('HashJoin1', wall_max_ns=150_000_000_000))  # 150s

        stage_data = self._make_stage_data(elapsed_ms=200000, operators=operators, op_summary=op_summary)
        result = self.rule.analyze(stage_data, self.base_context)

        slow_findings = [f for f in result['findings'] if f['type'] == 'BROADCAST_JOIN_SLOW']
        self.assertEqual(len(slow_findings), 1, "Should produce BROADCAST_JOIN_SLOW finding")

        finding = slow_findings[0]
        self.assertEqual(finding['severity'], 'MEDIUM')
        # Verify build_bytes is in details
        self.assertIn('build_bytes', finding['details'])
        self.assertEqual(finding['details']['build_bytes'], 30*1024**3)
        self.assertIn('build_rows', finding['details'])
        # Verify build info appears in description
        self.assertIn('build 侧数据量', finding['description'])

        # Should have recommendation to disable broadcast
        self.assertTrue(len(result['recommendations']) > 0)
        rec = result['recommendations'][0]
        self.assertIn('broadcast', rec['setting'])
        self.assertIn('build 侧数据量', rec['reason'])
        self.assertIn('Broadcast 需要将 build 侧数据广播到所有 task', rec['reason'])

    def test_broadcast_join_slow_with_row_fallback(self):
        """Broadcast join slow, no bytes but has rows → build_info uses row count"""
        build_op = self._make_leaf_op('ShuffleRead1')
        probe_op = self._make_leaf_op('ShuffleRead2')
        hj_op = self._make_hash_join_op('HashJoin1', 'ShuffleRead2', 'ShuffleRead1', broadcast=True)
        operators = [hj_op, build_op, probe_op]

        op_summary = {}
        # No input_bytes, only row_sum
        op_summary.update(self._make_op_summary('ShuffleRead1', row_sum=500_000_000))
        op_summary.update(self._make_op_summary('ShuffleRead2', row_sum=100_000_000))  # 5x < 10x
        op_summary.update(self._make_op_summary('HashJoin1', wall_max_ns=150_000_000_000))

        stage_data = self._make_stage_data(elapsed_ms=200000, operators=operators, op_summary=op_summary)
        result = self.rule.analyze(stage_data, self.base_context)

        slow_findings = [f for f in result['findings'] if f['type'] == 'BROADCAST_JOIN_SLOW']
        self.assertEqual(len(slow_findings), 1)
        # build_info should use row count fallback
        self.assertIn('build 侧数据量', slow_findings[0]['description'])

    def test_broadcast_join_slow_no_build_data(self):
        """Broadcast join slow, no bytes and no rows → no build_info in description"""
        build_op = self._make_leaf_op('ShuffleRead1')
        probe_op = self._make_leaf_op('ShuffleRead2')
        hj_op = self._make_hash_join_op('HashJoin1', 'ShuffleRead2', 'ShuffleRead1', broadcast=True)
        operators = [hj_op, build_op, probe_op]

        op_summary = {}
        op_summary.update(self._make_op_summary('ShuffleRead1'))  # no bytes, no rows
        op_summary.update(self._make_op_summary('ShuffleRead2'))
        op_summary.update(self._make_op_summary('HashJoin1', wall_max_ns=150_000_000_000))

        stage_data = self._make_stage_data(elapsed_ms=200000, operators=operators, op_summary=op_summary)
        result = self.rule.analyze(stage_data, self.base_context)

        slow_findings = [f for f in result['findings'] if f['type'] == 'BROADCAST_JOIN_SLOW']
        self.assertEqual(len(slow_findings), 1)
        # No build info when no data available
        self.assertNotIn('build 侧数据量', slow_findings[0]['description'])

    # ---- Case 7b: df_and join should NOT produce BROADCAST_JOIN_SLOW ----

    def test_broadcast_join_slow_skipped_for_df_and(self):
        """df_and broadcast join 耗时占比高 → 不产出 BROADCAST_JOIN_SLOW finding 和 recommendation

        回归测试：修复前 df_and join 仍会触发 BROADCAST_JOIN_SLOW，
        修复后在检测 2 中也过滤 df_and join。
        """
        build_op = self._make_leaf_op('ShuffleRead1')
        probe_op = self._make_leaf_op('ShuffleRead2')
        # ratio < 10x (3x) so no HASH_JOIN_BUILD_HEAVY, but join_pct > 30%
        # is_df=True → df_and join
        hj_op = self._make_hash_join_op('HashJoin1', 'ShuffleRead2', 'ShuffleRead1',
                                         broadcast=True, is_df=True)
        operators = [hj_op, build_op, probe_op]

        op_summary = {}
        op_summary.update(self._make_op_summary('ShuffleRead1', input_bytes=30*1024**3))   # 30GB build
        op_summary.update(self._make_op_summary('ShuffleRead2', input_bytes=10*1024**3))   # 10GB probe → 3x < 10x
        op_summary.update(self._make_op_summary('HashJoin1', wall_max_ns=150_000_000_000))  # 150s → 75% > 30%

        stage_data = self._make_stage_data(elapsed_ms=200000, operators=operators, op_summary=op_summary)
        result = self.rule.analyze(stage_data, self.base_context)

        # df_and join 不应该产出 BROADCAST_JOIN_SLOW finding
        slow_findings = [f for f in result['findings'] if f['type'] == 'BROADCAST_JOIN_SLOW']
        self.assertEqual(len(slow_findings), 0,
                         "df_and join should NOT produce BROADCAST_JOIN_SLOW finding")

        # df_and join 不应该有 recommendation（broadcast 参数建议）
        broadcast_recs = [r for r in result['recommendations']
                          if 'broadcast' in r.get('setting', '')]
        self.assertEqual(len(broadcast_recs), 0,
                         "df_and join should NOT produce broadcast recommendation")

    # ---- Case 8: recursive leaf finding ----

    def test_recursive_leaf_finding(self):
        """probe 侧经过 Calc → 递归找到叶子节点的 bytes"""
        leaf = self._make_leaf_op('ShuffleRead2')
        calc = self._make_calc_op('Calc1', input_ids=['ShuffleRead2'])
        build = self._make_leaf_op('ShuffleRead1')
        hj_op = self._make_hash_join_op('HashJoin1', 'Calc1', 'ShuffleRead1', broadcast=True)
        operators = [hj_op, calc, build, leaf]

        op_summary = {}
        op_summary.update(self._make_op_summary('ShuffleRead1', input_bytes=500*1024**3))
        op_summary.update(self._make_op_summary('ShuffleRead2', input_bytes=10*1024**3))
        op_summary.update(self._make_op_summary('Calc1'))  # Calc has no bytes
        op_summary.update(self._make_op_summary('HashJoin1', wall_max_ns=30_000_000_000))

        stage_data = self._make_stage_data(operators=operators, op_summary=op_summary)
        result = self.rule.analyze(stage_data, self.base_context)
        # Should find build heavy via recursive leaf finding
        self.assertEqual(len(result['findings']), 1)
        self.assertEqual(result['findings'][0]['details']['ratio_based_on'], 'bytes')


if __name__ == '__main__':
    unittest.main()
