#!/usr/bin/env python3
"""命令行集成测试"""
import unittest
import sys
import os
import json
import tempfile
import subprocess

# 添加项目路径
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))

from analyze_job import analyze_job


class TestCommandLineIntegration(unittest.TestCase):
    """测试命令行参数集成"""

    def setUp(self):
        """测试前准备"""
        self.plan_file = None
        self.profile_file = None
        self._create_test_files()

    def tearDown(self):
        """测试后清理"""
        if self.plan_file and os.path.exists(self.plan_file):
            os.unlink(self.plan_file)
        if self.profile_file and os.path.exists(self.profile_file):
            os.unlink(self.profile_file)

    def _create_test_files(self):
        """创建测试文件"""
        # 创建最小的 plan.json
        plan_data = {
            "dml": {
                "stages": [
                    {
                        "id": "stg1",
                        "operators": [
                            {
                                "id": "op1",
                                "tableScan": {
                                    "table": {"path": ["test_db", "test_table"]}
                                }
                            },
                            {
                                "id": "op2", 
                                "hashAggregate": {
                                    "aggregate": {
                                        "aggregateCalls": [
                                            {"function": {"function": {"name": "COUNT"}}}
                                        ]
                                    },
                                    "hint": "IncrementalAggregateRule"
                                }
                            }
                        ]
                    }
                ]
            },
            "sql": "SELECT COUNT(*) FROM test_table",
            "settings": {}
        }
        
        # 创建最小的 job_profile.json
        profile_data = {
            "jobSummary": {
                "stageSummary": {
                    "stg1": {
                        "startTime": "1000",
                        "endTime": "6000",
                        "taskCountDetail": {"1": "4"},
                        "inputOutputStats": {
                            "inputBytes": "1000000",
                            "outputBytes": "100000"
                        },
                        "operatorSummary": {
                            "op1": {
                                "wallTimeNs": {"max": "3000000000", "avg": "3000000000"}
                            },
                            "op2": {
                                "wallTimeNs": {"max": "2000000000", "avg": "2000000000"}
                            }
                        }
                    }
                }
            }
        }
        
        # 创建临时文件
        with tempfile.NamedTemporaryFile(mode='w', suffix='_plan.json', delete=False) as f:
            json.dump(plan_data, f, indent=2)
            self.plan_file = f.name
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='_profile.json', delete=False) as f:
            json.dump(profile_data, f, indent=2)
            self.profile_file = f.name

    def test_analyze_job_function_parameters(self):
        """测试 analyze_job 函数参数"""
        # 测试默认参数（增量算法策略禁用）
        result1 = analyze_job(
            self.plan_file, self.profile_file, ".",
            enable_state_table_analysis=True,
            enable_incremental_algorithm_analysis=False
        )
        self.assertIsNotNone(result1, "默认参数分析应该成功")
        
        # 测试启用增量算法策略
        result2 = analyze_job(
            self.plan_file, self.profile_file, ".",
            enable_state_table_analysis=True,
            enable_incremental_algorithm_analysis=True
        )
        self.assertIsNotNone(result2, "启用增量算法策略分析应该成功")

    def test_command_line_help(self):
        """测试命令行帮助信息"""
        script_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "analyze_job.py")
        
        cmd = [sys.executable, script_path, "--help"]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        
        self.assertEqual(result.returncode, 0, "帮助命令应该成功执行")
        self.assertIn("--enable-incremental-algorithm", result.stdout, 
                     "帮助信息应该包含 --enable-incremental-algorithm 参数")
        self.assertIn("--enable-state-table", result.stdout,
                     "帮助信息应该包含 --enable-state-table 参数")

    def test_command_line_execution(self):
        """测试命令行执行"""
        script_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "analyze_job.py")
        
        # 测试基本执行
        cmd_basic = [
            sys.executable, script_path,
            self.plan_file, self.profile_file,
            "--enable-state-table"
        ]
        
        result_basic = subprocess.run(cmd_basic, capture_output=True, text=True, timeout=30)
        self.assertEqual(result_basic.returncode, 0, f"基本命令执行失败: {result_basic.stderr}")
        self.assertIn("状态表分析] 启用", result_basic.stdout, "应该显示状态表分析启用")
        
        # 测试启用增量算法策略
        cmd_full = [
            sys.executable, script_path,
            self.plan_file, self.profile_file,
            "--enable-state-table",
            "--enable-incremental-algorithm"
        ]
        
        result_full = subprocess.run(cmd_full, capture_output=True, text=True, timeout=30)
        self.assertEqual(result_full.returncode, 0, f"完整命令执行失败: {result_full.stderr}")
        self.assertIn("增量算法策略] 启用", result_full.stdout, "应该显示增量算法策略启用")

    def test_parameter_validation(self):
        """测试参数验证"""
        script_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "analyze_job.py")
        
        # 测试缺少文件参数
        cmd_missing = [sys.executable, script_path]
        result_missing = subprocess.run(cmd_missing, capture_output=True, text=True, timeout=10)
        self.assertNotEqual(result_missing.returncode, 0, "缺少参数应该失败")
        
        # 测试不存在的文件
        cmd_nonexistent = [
            sys.executable, script_path,
            "nonexistent_plan.json", "nonexistent_profile.json"
        ]
        result_nonexistent = subprocess.run(cmd_nonexistent, capture_output=True, text=True, timeout=10)
        self.assertNotEqual(result_nonexistent.returncode, 0, "不存在的文件应该失败")


if __name__ == '__main__':
    unittest.main()