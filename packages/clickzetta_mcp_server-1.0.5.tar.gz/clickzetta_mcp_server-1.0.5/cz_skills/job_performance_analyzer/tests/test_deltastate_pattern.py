#!/usr/bin/env python3
"""测试 DeltaState 模式的 append-only 判断"""

import json
import unittest
from unittest.mock import Mock

from cz_skills.job_performance_analyzer.utils.incremental_algorithm_analyzer import IncrementalAlgorithmAnalyzer, AppendOnlyType


class TestDeltaStatePattern(unittest.TestCase):
    """测试 DeltaState 模式的 append-only 判断"""

    def setUp(self):
        """设置测试环境"""
        # 创建一个简单的 plan 用于测试
        self.plan = {
            'operators': []
        }
        self.analyzer = IncrementalAlgorithmAnalyzer(self.plan)

    def test_deltastate_minus_pattern(self):
        """测试 DeltaState- 模式（有删除）"""
        # 模拟包含 DeltaState- 的算子
        op = {
            'window': {
                'hint': {
                    'comments': 'HINT=delta,DeltaState-:[1,1896] - [1,6393]_IncrementalWindowSetDeltaRule#cz::optimizer::Window#44'
                }
            }
        }
        
        result = self.analyzer._check_deltastate_pattern(op)
        self.assertEqual(result, AppendOnlyType.WITH_DELETE)

    def test_deltastate_plus_pattern(self):
        """测试 DeltaState+ 模式（纯增）"""
        # 模拟包含 DeltaState+ 的算子
        op = {
            'hashAggregate': {
                'hint': {
                    'comments': 'HINT=delta,DeltaState+:[1,1896] - [1,6393]_IncrementalAggregateRule#cz::optimizer::Aggregate#123'
                }
            }
        }
        
        result = self.analyzer._check_deltastate_pattern(op)
        self.assertEqual(result, AppendOnlyType.APPEND_ONLY)

    def test_no_deltastate_pattern(self):
        """测试没有 DeltaState 模式的情况"""
        # 模拟没有 DeltaState 模式的算子
        op = {
            'hashJoin': {
                'join': {
                    'type': 'INNER'
                },
                'hint': {
                    'comments': 'Rule:IncrementalJoinWithoutCondenseRule'
                }
            }
        }
        
        result = self.analyzer._check_deltastate_pattern(op)
        self.assertEqual(result, AppendOnlyType.UNKNOWN)

    def test_deltastate_in_json_string(self):
        """测试 DeltaState 模式在 JSON 字符串中的检测"""
        # 模拟复杂的算子结构，DeltaState 在深层嵌套中
        op = {
            'calc': {
                'expressions': [
                    {
                        'function': {
                            'name': 'SOME_FUNC',
                            'properties': {
                                'hint': 'HINT=delta,DeltaState-:[1,100] - [1,200]_IncrementalCalcRule'
                            }
                        }
                    }
                ]
            }
        }
        
        result = self.analyzer._check_deltastate_pattern(op)
        self.assertEqual(result, AppendOnlyType.WITH_DELETE)

    def test_aggregate_with_deltastate_priority(self):
        """测试 Aggregate 算子优先使用 DeltaState 模式"""
        # 模拟有 DeltaState+ 的 aggregate 算子
        op = {
            'hashAggregate': {
                'hint': {
                    'comments': 'HINT=delta,DeltaState+:[1,1896] - [1,6393]_IncrementalAggregateRule#123'
                }
            }
        }
        
        # 模拟有 WITH_DELETE 输入（应该被 DeltaState+ 覆盖）
        delta_inputs = [(0, AppendOnlyType.WITH_DELETE)]
        
        result = self.analyzer._infer_agg_window_append_only_type(0, op, 'aggregate', delta_inputs)
        self.assertEqual(result, AppendOnlyType.APPEND_ONLY)

    def test_join_with_deltastate_priority(self):
        """测试 Join 算子优先使用 DeltaState 模式"""
        # 模拟有 DeltaState- 的 join 算子
        op = {
            'hashJoin': {
                'join': {
                    'type': 'INNER'
                },
                'hint': {
                    'comments': 'HINT=delta,DeltaState-:[1,100] - [1,200]_IncrementalJoinRule#456'
                }
            }
        }
        
        # 模拟有 APPEND_ONLY 输入（应该被 DeltaState- 覆盖）
        delta_inputs = [(0, AppendOnlyType.APPEND_ONLY), (1, AppendOnlyType.APPEND_ONLY)]
        
        result = self.analyzer._infer_join_append_only_type(op, delta_inputs)
        self.assertEqual(result, AppendOnlyType.WITH_DELETE)

    def test_fallback_to_original_logic(self):
        """测试没有 DeltaState 模式时回退到原有逻辑"""
        # 模拟没有 DeltaState 模式的 aggregate 算子
        op = {
            'hashAggregate': {
                'aggregate': {
                    'aggregateCalls': [
                        {
                            'function': {
                                'function': {
                                    'name': 'SUM'
                                }
                            }
                        }
                    ]
                }
            }
        }
        
        # 模拟有 WITH_DELETE 输入
        delta_inputs = [(0, AppendOnlyType.WITH_DELETE)]
        
        result = self.analyzer._infer_agg_window_append_only_type(0, op, 'aggregate', delta_inputs)
        self.assertEqual(result, AppendOnlyType.WITH_DELETE)

        # 模拟有 APPEND_ONLY 输入
        delta_inputs = [(0, AppendOnlyType.APPEND_ONLY)]
        
        result = self.analyzer._infer_agg_window_append_only_type(0, op, 'aggregate', delta_inputs)
        self.assertEqual(result, AppendOnlyType.APPEND_ONLY)


if __name__ == '__main__':
    unittest.main()