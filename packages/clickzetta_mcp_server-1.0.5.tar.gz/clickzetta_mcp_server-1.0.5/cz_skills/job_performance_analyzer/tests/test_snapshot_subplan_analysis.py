#!/usr/bin/env python3
"""Snapshot Subplan 分析测试集"""
import unittest
import sys
import os

# 添加项目路径
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))

from cz_skills.job_performance_analyzer.rules.incremental.state_table.state_table_enable import StateTableEnable


class TestSnapshotSubplanAnalysis(unittest.TestCase):
    """测试 Snapshot Subplan 分析功能"""

    def setUp(self):
        """测试前准备"""
        self.rule = StateTableEnable()

    def test_basic_snapshot_subplan_detection(self):
        """测试基本的 snapshot subplan 检测"""
        # 创建测试数据
        test_data = {
            'operator_data_types': {
                'TableScan_op_100': 'snapshot',
                'HashAggregate_op_101': 'snapshot',
                'HashJoin_op_102': 'snapshot',
                'Calc_op_103': 'snapshot',
                'TableScan_op_104': 'delta',
                'HashAggregate_op_105': 'delta',
            },
            'operator_analysis': [
                {'operator_id': 'TableScan_op_100', 'stage_id': 'stg1', 'elapsed_ms': 2000},
                {'operator_id': 'HashAggregate_op_101', 'stage_id': 'stg1', 'elapsed_ms': 1500},
                {'operator_id': 'HashJoin_op_102', 'stage_id': 'stg2', 'elapsed_ms': 1000},
                {'operator_id': 'Calc_op_103', 'stage_id': 'stg2', 'elapsed_ms': 500},
                {'operator_id': 'TableScan_op_104', 'stage_id': 'stg3', 'elapsed_ms': 300},
                {'operator_id': 'HashAggregate_op_105', 'stage_id': 'stg3', 'elapsed_ms': 200},
            ],
            'operator_dependencies': {
                'HashAggregate_op_101': ['TableScan_op_100'],
                'HashJoin_op_102': ['HashAggregate_op_101'],
                'Calc_op_103': ['HashJoin_op_102'],
                'HashAggregate_op_105': ['TableScan_op_104'],
            },
            'aligned_stages': {
                'stg1': {
                    'plan': {
                        'operators': [
                            {
                                'id': 'op_100',
                                'tableScan': {'table': {'path': ['ws1', 'test_db', 'large_table']}}
                            },
                            {
                                'id': 'op_101',
                                'hashAggregate': {
                                    'aggregate': {
                                        'aggregateCalls': [
                                            {'function': {'function': {'name': 'SUM'}}},
                                            {'function': {'function': {'name': 'COUNT'}}}
                                        ]
                                    }
                                }
                            }
                        ]
                    }
                },
                'stg2': {
                    'plan': {
                        'operators': [
                            {
                                'id': 'op_102',
                                'hashJoin': {'join': {'type': 'INNER'}}
                            }
                        ]
                    }
                }
            },
            'total_job_time': 10000,
            'settings': {}
        }

        stage_data = {'stage_id': 'stg1', 'plan': {'operators': []}, 'metrics': {}}
        
        # 执行分析
        result = self.rule.analyze(stage_data, test_data)
        
        # 验证结果
        self.assertGreater(len(result['findings']), 0, "应该发现 snapshot subplan 问题")
        self.assertGreater(len(result['recommendations']), 0, "应该有状态表建议")
        self.assertGreater(len(result['insights']), 0, "应该有分析洞察")
        
        # 验证具体内容
        findings = result['findings']
        snapshot_findings = [f for f in findings if 'Snapshot subplan' in f.get('description', '')]
        self.assertGreater(len(snapshot_findings), 0, "应该有 snapshot subplan 相关发现")
        
        recommendations = result['recommendations']
        state_table_recs = [r for r in recommendations if 'incremental.enable.state.table' in r.get('setting', '')]
        self.assertGreater(len(state_table_recs), 0, "应该有状态表启用建议")

    def test_threshold_boundary_conditions(self):
        """测试阈值边界条件"""
        # 测试刚好15%的情况
        test_data = {
            'operator_data_types': {'TableScan_op1': 'snapshot'},
            'operator_analysis': [
                {'operator_id': 'TableScan_op1', 'stage_id': 'stg1', 'elapsed_ms': 1500}  # 15%
            ],
            'total_job_time': 10000,
            'aligned_stages': {
                'stg1': {
                    'plan': {
                        'operators': [
                            {'id': 'op1', 'tableScan': {'table': {'path': ['test_table']}}}
                        ]
                    }
                }
            },
            'operator_dependencies': {},
            'settings': {}
        }
        
        stage_data = {'stage_id': 'stg1', 'plan': {'operators': []}, 'metrics': {}}
        result = self.rule.analyze(stage_data, test_data)
        
        # 15% 应该触发建议
        recommendations = result['recommendations']
        state_table_recs = [r for r in recommendations if 'incremental.enable.state.table' in r.get('setting', '')]
        self.assertGreater(len(state_table_recs), 0, "15% 阈值应该触发状态表建议")

    def test_all_delta_operators(self):
        """测试所有算子都是 delta 的情况"""
        test_data = {
            'operator_data_types': {'TableScan_op1': 'delta', 'HashAggregate_op2': 'delta'},
            'operator_analysis': [
                {'operator_id': 'TableScan_op1', 'stage_id': 'stg1', 'elapsed_ms': 1000},
                {'operator_id': 'HashAggregate_op2', 'stage_id': 'stg1', 'elapsed_ms': 2000}
            ],
            'total_job_time': 5000,
            'aligned_stages': {},
            'operator_dependencies': {'HashAggregate_op2': ['TableScan_op1']},
            'settings': {}
        }
        
        stage_data = {'stage_id': 'stg1', 'plan': {'operators': []}, 'metrics': {}}
        result = self.rule.analyze(stage_data, test_data)
        
        # 全是 delta 算子，不应该有 snapshot subplan 建议
        findings = result['findings']
        snapshot_findings = [f for f in findings if 'Snapshot subplan' in f.get('description', '')]
        self.assertEqual(len(snapshot_findings), 0, "全 delta 算子不应该有 snapshot subplan 发现")

    def test_empty_data_handling(self):
        """测试空数据处理"""
        empty_context = {
            'operator_data_types': {},
            'operator_analysis': [],
            'total_job_time': 0,
            'aligned_stages': {},
            'settings': {}
        }
        
        stage_data = {'stage_id': 'stg1', 'plan': {'operators': []}, 'metrics': {}}
        result = self.rule.analyze(stage_data, empty_context)
        
        # 空数据应该有相应的洞察
        insights = result['insights']
        self.assertGreater(len(insights), 0, "空数据应该有相应洞察")
        
        empty_insights = [i for i in insights if '缺少operator依赖关系或统计数据' in i.get('message', '')]
        self.assertGreater(len(empty_insights), 0, "应该有缺少数据的洞察")

    def test_incremental_algorithm_strategy_control(self):
        """测试增量算法策略控制"""
        test_data = {
            'operator_data_types': {
                'TableScan_op_100': 'snapshot',
                'HashAggregate_op_101': 'snapshot',
            },
            'operator_analysis': [
                {'operator_id': 'TableScan_op_100', 'stage_id': 'stg1', 'elapsed_ms': 1000},
                {'operator_id': 'HashAggregate_op_101', 'stage_id': 'stg1', 'elapsed_ms': 2000}
            ],
            'total_job_time': 10000,
            'aligned_stages': {
                'stg1': {
                    'plan': {
                        'operators': [
                            {
                                'id': 'op_101',
                                'hashAggregate': {
                                    'aggregate': {
                                        'aggregateCalls': [
                                            {'function': {'function': {'name': 'SUM'}}}
                                        ]
                                    },
                                    'hint': 'IncrementalAggregateRule'
                                }
                            }
                        ]
                    }
                }
            },
            'operator_dependencies': {'HashAggregate_op_101': ['TableScan_op_100']},
            'settings': {}
        }
        
        stage_data = {'stage_id': 'stg1', 'plan': test_data['aligned_stages']['stg1']['plan'], 'metrics': {}}
        
        # 测试默认禁用增量算法策略
        test_data['enable_incremental_algorithm_analysis'] = False
        result1 = self.rule.analyze(stage_data, test_data)
        
        # 测试启用增量算法策略
        test_data['enable_incremental_algorithm_analysis'] = True
        result2 = self.rule.analyze(stage_data, test_data)
        
        # 启用时应该有更多的发现和建议
        self.assertGreaterEqual(len(result2['findings']), len(result1['findings']), 
                               "启用增量算法策略应该有更多或相等的发现")
        self.assertGreaterEqual(len(result2['recommendations']), len(result1['recommendations']), 
                               "启用增量算法策略应该有更多或相等的建议")

    def test_complex_dependency_tracing(self):
        """测试复杂依赖关系追踪"""
        test_data = {
            'operator_data_types': {
                'scan_large_fact_table': 'snapshot',
                'filter_recent_data': 'snapshot',
                'complex_aggregation': 'snapshot',
                'post_agg_calc': 'snapshot',
                'scan_customer_dim': 'snapshot',
                'customer_join': 'snapshot',
                'scan_delta_updates': 'delta',
                'delta_aggregation': 'delta',
                'final_join': 'snapshot',
                'output_sink': 'snapshot',
            },
            'operator_analysis': [
                {'operator_id': 'scan_large_fact_table', 'stage_id': 'stg_extract', 'elapsed_ms': 10000},
                {'operator_id': 'filter_recent_data', 'stage_id': 'stg_extract', 'elapsed_ms': 2000},
                {'operator_id': 'complex_aggregation', 'stage_id': 'stg_aggregate', 'elapsed_ms': 6000},
                {'operator_id': 'post_agg_calc', 'stage_id': 'stg_aggregate', 'elapsed_ms': 2000},
                {'operator_id': 'scan_customer_dim', 'stage_id': 'stg_dimension_join', 'elapsed_ms': 1000},
                {'operator_id': 'customer_join', 'stage_id': 'stg_dimension_join', 'elapsed_ms': 2000},
                {'operator_id': 'scan_delta_updates', 'stage_id': 'stg_incremental_delta', 'elapsed_ms': 200},
                {'operator_id': 'delta_aggregation', 'stage_id': 'stg_incremental_delta', 'elapsed_ms': 300},
                {'operator_id': 'final_join', 'stage_id': 'stg_final_output', 'elapsed_ms': 500},
                {'operator_id': 'output_sink', 'stage_id': 'stg_final_output', 'elapsed_ms': 500},
            ],
            'operator_dependencies': {
                'filter_recent_data': ['scan_large_fact_table'],
                'complex_aggregation': ['filter_recent_data'],
                'post_agg_calc': ['complex_aggregation'],
                'customer_join': ['post_agg_calc', 'scan_customer_dim'],
                'delta_aggregation': ['scan_delta_updates'],
                'final_join': ['customer_join', 'delta_aggregation'],
                'output_sink': ['final_join'],
            },
            'aligned_stages': {
                'stg_extract': {
                    'plan': {
                        'operators': [
                            {
                                'id': 'scan_large_fact_table',
                                'tableScan': {'table': {'path': ['warehouse', 'fact', 'sales_transactions']}}
                            }
                        ]
                    }
                },
                'stg_aggregate': {
                    'plan': {
                        'operators': [
                            {
                                'id': 'complex_aggregation',
                                'hashAggregate': {
                                    'aggregate': {
                                        'aggregateCalls': [
                                            {'function': {'function': {'name': 'SUM'}}},
                                            {'function': {'function': {'name': 'COUNT'}}},
                                            {'function': {'function': {'name': 'AVG'}}},
                                            {'function': {'function': {'name': 'MAX'}}},
                                            {'function': {'function': {'name': 'MIN'}}}
                                        ]
                                    }
                                }
                            }
                        ]
                    }
                }
            },
            'total_job_time': 25000,  # 25秒
            'settings': {}
        }
        
        stage_data = {'stage_id': 'global', 'plan': {'operators': []}, 'metrics': {}}
        result = self.rule.analyze(stage_data, test_data)
        
        # 应该检测到大的 snapshot subplan
        findings = result['findings']
        snapshot_findings = [f for f in findings if 'Snapshot subplan' in f.get('description', '')]
        self.assertGreater(len(snapshot_findings), 0, "应该检测到大的 snapshot subplan")
        
        # 检查占比是否合理（应该远超15%）
        for finding in snapshot_findings:
            description = finding.get('description', '')
            if '占比' in description:
                # 提取占比数字
                import re
                match = re.search(r'占比 (\d+\.?\d*)%', description)
                if match:
                    percentage = float(match.group(1))
                    self.assertGreater(percentage, 15.0, f"Snapshot subplan 占比 {percentage}% 应该超过15%")

    def test_skeleton_generation(self):
        """测试骨架信息生成"""
        test_data = {
            'operator_data_types': {
                'TableScan_op1': 'snapshot',
                'HashAggregate_op2': 'snapshot',
                'HashJoin_op3': 'snapshot',
            },
            'operator_analysis': [
                {'operator_id': 'TableScan_op1', 'stage_id': 'stg1', 'elapsed_ms': 2000},
                {'operator_id': 'HashAggregate_op2', 'stage_id': 'stg1', 'elapsed_ms': 3000},
                {'operator_id': 'HashJoin_op3', 'stage_id': 'stg2', 'elapsed_ms': 2000},
            ],
            'operator_dependencies': {
                'HashAggregate_op2': ['TableScan_op1'],
                'HashJoin_op3': ['HashAggregate_op2'],
            },
            'aligned_stages': {
                'stg1': {
                    'plan': {
                        'operators': [
                            {
                                'id': 'op1',
                                'tableScan': {'table': {'path': ['warehouse', 'fact', 'test_table']}}
                            },
                            {
                                'id': 'op2',
                                'hashAggregate': {
                                    'aggregate': {
                                        'aggregateCalls': [
                                            {'function': {'function': {'name': 'SUM'}}},
                                            {'function': {'function': {'name': 'COUNT'}}}
                                        ]
                                    }
                                }
                            }
                        ]
                    }
                },
                'stg2': {
                    'plan': {
                        'operators': [
                            {
                                'id': 'op3',
                                'hashJoin': {'join': {'type': 'LEFT'}}
                            }
                        ]
                    }
                }
            },
            'total_job_time': 10000,
            'settings': {}
        }
        
        stage_data = {'stage_id': 'stg1', 'plan': {'operators': []}, 'metrics': {}}
        result = self.rule.analyze(stage_data, test_data)
        
        # 检查洞察中是否包含有意义的骨架信息
        insights = result['insights']
        skeleton_insights = [i for i in insights if 'subplan' in i.get('message', '') and 'Snapshot策略' in i.get('message', '')]
        
        if skeleton_insights:
            # 验证骨架信息包含有意义的内容
            skeleton_message = skeleton_insights[0].get('message', '')
            self.assertTrue(any(keyword in skeleton_message for keyword in ['Aggregate', 'Join', 'TableScan']), 
                           f"骨架信息应该包含算子类型: {skeleton_message}")


class TestSnapshotSubplanStageAggregation(unittest.TestCase):
    """测试 snapshot subplan 耗时按 stage 聚合计算（回归测试）

    修复前：同一 stage 内多个 operator 的耗时直接相加，导致 subplan 占比虚高。
    修复后：同一 stage 内取 max（流水线执行），跨 stage 相加。
    """

    def setUp(self):
        self.rule = StateTableEnable()

    def test_same_stage_operators_use_max_not_sum(self):
        """同一 stage 内的 snapshot operator 应取 max 耗时，而非 sum

        场景：stg1 有两个 snapshot operator（3000ms 和 2000ms），
              stg2 有一个 snapshot operator（4000ms）。
        修复前：total = 3000 + 2000 + 4000 = 9000ms → 90%
        修复后：total = max(3000,2000) + max(4000) = 3000 + 4000 = 7000ms → 70%
        """
        test_data = {
            'operator_data_types': {
                'TableScan_op1': 'snapshot',
                'HashAggregate_op2': 'snapshot',
                'HashJoin_op3': 'snapshot',
            },
            'operator_analysis': [
                {'operator_id': 'TableScan_op1', 'stage_id': 'stg1', 'max_time_ms': 3000, 'elapsed_ms': 3000},
                {'operator_id': 'HashAggregate_op2', 'stage_id': 'stg1', 'max_time_ms': 2000, 'elapsed_ms': 2000},
                {'operator_id': 'HashJoin_op3', 'stage_id': 'stg2', 'max_time_ms': 4000, 'elapsed_ms': 4000},
            ],
            'operator_dependencies': {
                'HashAggregate_op2': ['TableScan_op1'],
                'HashJoin_op3': ['HashAggregate_op2'],
            },
            'aligned_stages': {
                'stg1': {'plan': {'operators': [
                    {'id': 'op1', 'tableScan': {'table': {'path': ['db', 'tbl']}}},
                    {'id': 'op2', 'hashAggregate': {'aggregate': {'aggregateCalls': [
                        {'function': {'function': {'name': 'SUM'}}}
                    ]}}}
                ]}},
                'stg2': {'plan': {'operators': [
                    {'id': 'op3', 'hashJoin': {'join': {'type': 'INNER'}}}
                ]}},
            },
            'total_job_time': 10000,
            'settings': {},
        }

        stage_data = {'stage_id': 'global', 'plan': {'operators': []}, 'metrics': {}}
        result = self.rule.analyze(stage_data, test_data)

        # 找到 snapshot subplan finding
        snapshot_findings = [f for f in result['findings']
                            if 'Snapshot subplan' in f.get('description', '')]
        self.assertGreater(len(snapshot_findings), 0, "应该检测到 snapshot subplan")

        # 验证占比：应该是 70%（7000/10000），而不是 90%（9000/10000）
        import re
        for f in snapshot_findings:
            match = re.search(r'占比 (\d+\.?\d*)%', f.get('description', ''))
            if match:
                pct = float(match.group(1))
                self.assertAlmostEqual(pct, 70.0, delta=1.0,
                    msg=f"占比应约为 70%（stage 聚合后），实际 {pct}%")

    def test_single_operator_per_stage_unchanged(self):
        """每个 stage 只有一个 operator 时，行为与修复前一致"""
        test_data = {
            'operator_data_types': {
                'TableScan_op1': 'snapshot',
                'HashJoin_op2': 'snapshot',
            },
            'operator_analysis': [
                {'operator_id': 'TableScan_op1', 'stage_id': 'stg1', 'max_time_ms': 5000, 'elapsed_ms': 5000},
                {'operator_id': 'HashJoin_op2', 'stage_id': 'stg2', 'max_time_ms': 3000, 'elapsed_ms': 3000},
            ],
            'operator_dependencies': {
                'HashJoin_op2': ['TableScan_op1'],
            },
            'aligned_stages': {
                'stg1': {'plan': {'operators': [
                    {'id': 'op1', 'tableScan': {'table': {'path': ['db', 'tbl']}}}
                ]}},
                'stg2': {'plan': {'operators': [
                    {'id': 'op2', 'hashJoin': {'join': {'type': 'INNER'}}}
                ]}},
            },
            'total_job_time': 10000,
            'settings': {},
        }

        stage_data = {'stage_id': 'global', 'plan': {'operators': []}, 'metrics': {}}
        result = self.rule.analyze(stage_data, test_data)

        snapshot_findings = [f for f in result['findings']
                            if 'Snapshot subplan' in f.get('description', '')]
        self.assertGreater(len(snapshot_findings), 0, "应该检测到 snapshot subplan")

        import re
        for f in snapshot_findings:
            match = re.search(r'占比 (\d+\.?\d*)%', f.get('description', ''))
            if match:
                pct = float(match.group(1))
                # 5000 + 3000 = 8000 → 80%
                self.assertAlmostEqual(pct, 80.0, delta=1.0,
                    msg=f"单 operator/stage 时占比应约为 80%，实际 {pct}%")

    def test_many_operators_same_stage_takes_max(self):
        """同一 stage 有多个 operator 时只取最大值

        stg1: 4 个 snapshot operator（1000, 2000, 5000, 3000ms）→ max = 5000
        total_job_time = 10000 → 占比 50%
        """
        test_data = {
            'operator_data_types': {
                'op_a': 'snapshot',
                'op_b': 'snapshot',
                'op_c': 'snapshot',
                'op_d': 'snapshot',
            },
            'operator_analysis': [
                {'operator_id': 'op_a', 'stage_id': 'stg1', 'max_time_ms': 1000, 'elapsed_ms': 1000},
                {'operator_id': 'op_b', 'stage_id': 'stg1', 'max_time_ms': 2000, 'elapsed_ms': 2000},
                {'operator_id': 'op_c', 'stage_id': 'stg1', 'max_time_ms': 5000, 'elapsed_ms': 5000},
                {'operator_id': 'op_d', 'stage_id': 'stg1', 'max_time_ms': 3000, 'elapsed_ms': 3000},
            ],
            'operator_dependencies': {
                'op_b': ['op_a'],
                'op_c': ['op_b'],
                'op_d': ['op_c'],
            },
            'aligned_stages': {
                'stg1': {'plan': {'operators': [
                    {'id': 'a', 'tableScan': {'table': {'path': ['db', 'tbl']}}},
                ]}},
            },
            'total_job_time': 10000,
            'settings': {},
        }

        stage_data = {'stage_id': 'global', 'plan': {'operators': []}, 'metrics': {}}
        result = self.rule.analyze(stage_data, test_data)

        snapshot_findings = [f for f in result['findings']
                            if 'Snapshot subplan' in f.get('description', '')]
        self.assertGreater(len(snapshot_findings), 0, "应该检测到 snapshot subplan")

        import re
        for f in snapshot_findings:
            match = re.search(r'占比 (\d+\.?\d*)%', f.get('description', ''))
            if match:
                pct = float(match.group(1))
                # max(1000,2000,5000,3000) = 5000 → 50%
                self.assertAlmostEqual(pct, 50.0, delta=1.0,
                    msg=f"同 stage 多 operator 应取 max，占比应约 50%，实际 {pct}%")


class TestStateTableEnableRule(unittest.TestCase):
    """测试 StateTableEnable 规则的基本功能"""

    def setUp(self):
        """测试前准备"""
        self.rule = StateTableEnable()

    def test_rule_check_always_true(self):
        """测试规则检查总是返回 True"""
        stage_data = {'stage_id': 'test', 'plan': {}, 'metrics': {}}
        
        # 测试不同的 refresh_type
        context1 = {'refresh_type': 'INCREMENTAL'}
        context2 = {'refresh_type': 'FULL'}
        context3 = {}
        
        self.assertTrue(self.rule.check(stage_data, context1), "INCREMENTAL refresh_type 应该返回 True")
        self.assertTrue(self.rule.check(stage_data, context2), "FULL refresh_type 应该返回 True")
        self.assertTrue(self.rule.check(stage_data, context3), "无 refresh_type 应该返回 True")

    def test_job_has_state_table_detection(self):
        """测试检测 job 是否已有状态表"""
        # 测试包含状态表的情况
        context_with_state_table = {
            'aligned_stages': {
                'stg1': {
                    'plan': {
                        'operators': [
                            {
                                'id': 'op1',
                                'tableScan': {
                                    'table': {'path': ['test_db', 'table_123__incr__456']}
                                }
                            }
                        ]
                    }
                }
            }
        }
        
        has_state_table = self.rule._check_job_has_state_table(context_with_state_table)
        self.assertTrue(has_state_table, "应该检测到状态表")
        
        # 测试不包含状态表的情况
        context_without_state_table = {
            'aligned_stages': {
                'stg1': {
                    'plan': {
                        'operators': [
                            {
                                'id': 'op1',
                                'tableScan': {
                                    'table': {'path': ['test_db', 'normal_table']}
                                }
                            }
                        ]
                    }
                }
            }
        }
        
        has_state_table = self.rule._check_job_has_state_table(context_without_state_table)
        self.assertFalse(has_state_table, "不应该检测到状态表")


if __name__ == '__main__':
    unittest.main()