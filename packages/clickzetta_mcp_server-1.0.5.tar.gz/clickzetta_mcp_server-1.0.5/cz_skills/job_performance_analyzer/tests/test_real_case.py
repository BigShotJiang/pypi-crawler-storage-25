#!/usr/bin/env python3
"""使用真实案例测试 Spilling 计算修复"""
import sys
from pathlib import Path

# 添加项目根目录到 Python 路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))

from cz_skills.job_performance_analyzer.rules.incremental.stage_optimization.spilling_analysis import SpillingAnalysis


def test_real_case():
    """
    真实案例：
    - Stage stg0 总 spilling: 9.38 GB
    - ShuffleWrite131 spilling: 5.23 GB (可忽略)
    - ShuffleWrite124 spilling: 4.15 GB (可忽略)
    - 实际需要关注的 spilling: 9.38 - 5.23 - 4.15 = 0 GB
    
    修复前：会错误地报告 "Stage stg0: Spilling 较大 (9.38 GB)"
    修复后：不应该报告 Stage 级别的告警，因为扣除后为 0 GB
    """
    
    rule = SpillingAnalysis()
    
    stage_data = {
        'stage_id': 'stg0',
        'metrics': {
            'spill_bytes': int(9.38 * 1024**3)  # 9.38 GB
        },
        'profile': {
            'operatorSummary': {
                'ShuffleWrite131': {
                    'spillStats': {
                        'spillingBytes': int(5.23 * 1024**3)  # 5.23 GB
                    }
                },
                'ShuffleWrite124': {
                    'spillStats': {
                        'spillingBytes': int(4.15 * 1024**3)  # 4.15 GB
                    }
                }
            }
        }
    }
    
    context = {'has_profile': True}
    
    # 执行分析
    result = rule.analyze(stage_data, context)
    
    print("=== 真实案例测试 ===")
    print("场景描述：")
    print("  - Stage stg0 总 spilling: 9.38 GB")
    print("  - ShuffleWrite131 spilling: 5.23 GB (Shuffle Write，可忽略)")
    print("  - ShuffleWrite124 spilling: 4.15 GB (Shuffle Write，可忽略)")
    print("  - 实际需要关注的 spilling: 9.38 - 5.23 - 4.15 = 0 GB")
    print()
    
    findings = result.get('findings', [])
    insights = result.get('insights', [])
    
    print("分析结果：")
    print(f"  Findings: {len(findings)} 个")
    for finding in findings:
        print(f"    - [{finding.get('severity')}] {finding.get('description')}")
    
    print(f"  Insights: {len(insights)} 个")
    for insight in insights:
        print(f"    - {insight.get('message')}")
    
    print()
    
    # 验证结果
    stage_spilling_findings = [f for f in findings if f.get('type') == 'STAGE_SPILLING']
    stage_spilling_insights = [i for i in insights if 'Spilling 较大' in i.get('message', '')]
    ignorable_insights = [i for i in insights if '可忽略' in i.get('message', '')]
    
    print("验证：")
    
    # 1. 不应该有 Stage 级别的 Spilling finding
    if len(stage_spilling_findings) == 0:
        print("  ✅ 没有产生错误的 Stage 级别 Spilling 告警")
    else:
        print(f"  ❌ 错误：产生了 {len(stage_spilling_findings)} 个 Stage 级别告警")
        return False
    
    # 2. 不应该有 "Spilling 较大" 的 insight
    if len(stage_spilling_insights) == 0:
        print("  ✅ 没有产生错误的关键洞察")
    else:
        print(f"  ❌ 错误：产生了错误的关键洞察: {stage_spilling_insights[0].get('message')}")
        return False
    
    # 3. 不应该有任何可忽略的 insight（已被过滤）
    if len(ignorable_insights) == 0:
        print("  ✅ 可忽略的 spilling 已从洞察中过滤")
    else:
        print(f"  ❌ 错误：不应该有可忽略的 insight，实际有 {len(ignorable_insights)} 个")
        return False
    
    # 4. 总的 insights 数量应该为 0
    if len(insights) == 0:
        print("  ✅ 没有产生任何洞察（符合预期）")
    else:
        print(f"  ❌ 错误：应该没有任何 insight，实际有 {len(insights)} 个")
        return False
    
    print()
    print("结论：修复成功！现在能够正确扣除可忽略的 Shuffle Write spilling")
    return True


if __name__ == '__main__':
    success = test_real_case()
    sys.exit(0 if success else 1)
