#!/usr/bin/env python3
"""测试 Spilling 计算逻辑，确保可忽略的 spilling 被正确扣除"""
import sys
from pathlib import Path

# 添加项目根目录到 Python 路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))

from cz_skills.job_performance_analyzer.rules.incremental.stage_optimization.spilling_analysis import SpillingAnalysis


def test_spilling_with_ignorable_operators():
    """测试当存在可忽略的 operator spilling 时，Stage 级别的判断是否正确"""
    
    rule = SpillingAnalysis()
    
    # 模拟场景：
    # - Stage 总 spilling: 9.38 GB
    # - ShuffleWrite131 spilling: 5.23 GB (可忽略)
    # - ShuffleWrite124 spilling: 4.15 GB (可忽略)
    # - 实际需要关注的 spilling: 9.38 - 5.23 - 4.15 = 0 GB
    
    stage_data = {
        'stage_id': 'stg0',
        'metrics': {
            'spill_bytes': int(9.38 * 1024**3)  # 9.38 GB
        },
        'profile': {
            'operatorSummary': {
                'ShuffleWrite131': {
                    'spillStats': {
                        'spillingBytes': int(5.23 * 1024**3)  # 5.23 GB
                    }
                },
                'ShuffleWrite124': {
                    'spillStats': {
                        'spillingBytes': int(4.15 * 1024**3)  # 4.15 GB
                    }
                }
            }
        }
    }
    
    context = {'has_profile': True}
    
    # 执行分析
    result = rule.analyze(stage_data, context)
    
    print("=== 测试：可忽略的 Spilling 应该被正确扣除 ===")
    print(f"Stage 总 spilling: 9.38 GB")
    print(f"可忽略的 spilling: 5.23 + 4.15 = 9.38 GB")
    print(f"实际需要关注的 spilling: 0 GB")
    print()
    
    # 验证结果
    findings = result.get('findings', [])
    insights = result.get('insights', [])
    
    print(f"Findings 数量: {len(findings)}")
    for finding in findings:
        print(f"  - {finding}")
    
    print(f"\nInsights 数量: {len(insights)}")
    for insight in insights:
        print(f"  - {insight}")
    
    # 断言：不应该有 STAGE_SPILLING 的 finding（因为扣除后为 0）
    stage_spilling_findings = [f for f in findings if f.get('type') == 'STAGE_SPILLING']
    
    if len(stage_spilling_findings) == 0:
        print("\n✅ 测试通过：没有产生 Stage 级别的 Spilling 告警")
    else:
        print("\n❌ 测试失败：不应该产生 Stage 级别的 Spilling 告警")
        print(f"   错误的 finding: {stage_spilling_findings}")
        return False
    
    # 不应该有任何 insight（可忽略的 spilling 不再显示）
    if len(insights) == 0:
        print("✅ 测试通过：没有产生任何洞察（可忽略的 spilling 已被过滤）")
    else:
        print(f"❌ 测试失败：不应该有任何 insight，实际有 {len(insights)} 个")
        return False
    
    return True


def test_spilling_with_mixed_operators():
    """测试混合场景：既有可忽略的 spilling，也有需要关注的 spilling"""
    
    rule = SpillingAnalysis()
    
    # 模拟场景：
    # - Stage 总 spilling: 10 GB
    # - ShuffleWrite spilling: 5 GB (可忽略)
    # - HashAggregate spilling: 5 GB (需要关注)
    # - 实际需要关注的 spilling: 10 - 5 = 5 GB
    
    stage_data = {
        'stage_id': 'stg1',
        'metrics': {
            'spill_bytes': int(10 * 1024**3)  # 10 GB
        },
        'profile': {
            'operatorSummary': {
                'ShuffleWrite100': {
                    'spillStats': {
                        'spillingBytes': int(5 * 1024**3)  # 5 GB
                    }
                },
                'HashAggregate200': {
                    'spillStats': {
                        'spillingBytes': int(5 * 1024**3)  # 5 GB
                    }
                }
            }
        }
    }
    
    context = {'has_profile': True}
    
    # 执行分析
    result = rule.analyze(stage_data, context)
    
    print("\n=== 测试：混合场景（可忽略 + 需要关注）===")
    print(f"Stage 总 spilling: 10 GB")
    print(f"可忽略的 spilling: 5 GB (ShuffleWrite)")
    print(f"需要关注的 spilling: 5 GB (HashAggregate)")
    print(f"实际需要关注的 Stage spilling: 5 GB")
    print()
    
    findings = result.get('findings', [])
    insights = result.get('insights', [])
    
    print(f"Findings 数量: {len(findings)}")
    for finding in findings:
        print(f"  - Type: {finding.get('type')}, Description: {finding.get('description')}")
    
    print(f"\nInsights 数量: {len(insights)}")
    for insight in insights:
        print(f"  - {insight.get('message')}")
    
    # 验证：应该有 STAGE_SPILLING finding（5GB 超过阈值）
    stage_spilling_findings = [f for f in findings if f.get('type') == 'STAGE_SPILLING']
    
    if len(stage_spilling_findings) > 0:
        finding = stage_spilling_findings[0]
        # 检查 finding 中是否包含正确的数值
        description = finding.get('description', '')
        if '5.00 GB' in description and '10.00 GB' in description and '可忽略' in description:
            print("\n✅ 测试通过：正确产生了 Stage 级别的 Spilling 告警，并显示了扣除信息")
        else:
            print(f"\n❌ 测试失败：Finding 描述不正确: {description}")
            return False
    else:
        print("\n❌ 测试失败：应该产生 Stage 级别的 Spilling 告警")
        return False
    
    # 验证：应该有 OPERATOR_SPILLING finding（HashAggregate）
    operator_spilling_findings = [f for f in findings if f.get('type') == 'OPERATOR_SPILLING']
    
    if len(operator_spilling_findings) > 0:
        print("✅ 测试通过：正确识别了需要关注的 operator spilling")
    else:
        print("❌ 测试失败：应该识别出 HashAggregate 的 spilling")
        return False
    
    # 验证：insights 中不应该有可忽略的 spilling（已被过滤）
    ignorable_insights = [i for i in insights if '可忽略' in i.get('message', '')]
    
    if len(ignorable_insights) == 0:
        print("✅ 测试通过：可忽略的 spilling 已从洞察中过滤")
    else:
        print(f"❌ 测试失败：不应该有可忽略的 insight，实际有 {len(ignorable_insights)} 个")
        return False
    
    return True


if __name__ == '__main__':
    print("开始测试 Spilling 计算逻辑...\n")
    
    test1_passed = test_spilling_with_ignorable_operators()
    test2_passed = test_spilling_with_mixed_operators()
    
    print("\n" + "="*60)
    if test1_passed and test2_passed:
        print("✅ 所有测试通过！")
        sys.exit(0)
    else:
        print("❌ 部分测试失败")
        sys.exit(1)
