#!/usr/bin/env python3
"""测试状态表检查工具类"""
import sys
import os

# 添加项目根目录到 Python 路径
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))

from cz_skills.job_performance_analyzer.utils.state_table_checker import StateTableChecker


def test_check_plan_has_state_table_with_plan():
    """测试检查单个 plan 是否包含状态表"""
    print("=" * 80)
    print("测试: check_plan_has_state_table (传入 plan)")
    print("=" * 80)
    
    # 测试用例 1: 包含状态表
    plan_with_state_table = {
        'operators': [{
            'tableScan': {
                'table': {
                    'path': ['gic_prod', 'kscdm', '2502726411993855340__incr__1266109515']
                }
            }
        }]
    }
    
    result1 = StateTableChecker.check_plan_has_state_table(plan_with_state_table)
    print(f"\n测试 1: 包含状态表的 plan")
    print(f"  结果: {result1}")
    print(f"  预期: True")
    print(f"  {'✓ 通过' if result1 else '✗ 失败'}")
    
    # 测试用例 2: 不包含状态表
    plan_without_state_table = {
        'operators': [{
            'tableScan': {
                'table': {
                    'path': ['gic_prod', 'kscdm', 'normal_table']
                }
            }
        }]
    }
    
    result2 = StateTableChecker.check_plan_has_state_table(plan_without_state_table)
    print(f"\n测试 2: 不包含状态表的 plan")
    print(f"  结果: {result2}")
    print(f"  预期: False")
    print(f"  {'✓ 通过' if not result2 else '✗ 失败'}")
    
    return result1 and not result2


def test_check_plan_has_state_table_with_context():
    """测试检查整个 job 是否包含状态表（传入 context）"""
    print("\n" + "=" * 80)
    print("测试: check_plan_has_state_table (传入 context - 全局检查)")
    print("=" * 80)
    
    # 测试用例 1: 某个 stage 包含状态表
    context_with_state_table = {
        'aligned_stages': {
            'stg1': {
                'plan': {
                    'operators': [{
                        'tableScan': {
                            'table': {'path': ['db', 'normal_table']}
                        }
                    }]
                }
            },
            'stg2': {
                'plan': {
                    'operators': [{
                        'tableScan': {
                            'table': {'path': ['db', 'table__incr__123']}
                        }
                    }]
                }
            }
        }
    }
    
    result1 = StateTableChecker.check_plan_has_state_table(context_with_state_table)
    print(f"\n测试 1: stg2 包含状态表")
    print(f"  结果: {result1}")
    print(f"  预期: True (全局检查，只要有一个 stage 包含就返回 True)")
    print(f"  {'✓ 通过' if result1 else '✗ 失败'}")
    
    # 测试用例 2: 所有 stage 都不包含状态表
    context_without_state_table = {
        'aligned_stages': {
            'stg1': {
                'plan': {
                    'operators': [{
                        'tableScan': {
                            'table': {'path': ['db', 'normal_table1']}
                        }
                    }]
                }
            },
            'stg2': {
                'plan': {
                    'operators': [{
                        'tableScan': {
                            'table': {'path': ['db', 'normal_table2']}
                        }
                    }]
                }
            }
        }
    }
    
    result2 = StateTableChecker.check_plan_has_state_table(context_without_state_table)
    print(f"\n测试 2: 所有 stage 都不包含状态表")
    print(f"  结果: {result2}")
    print(f"  预期: False")
    print(f"  {'✓ 通过' if not result2 else '✗ 失败'}")
    
    # 测试用例 3: 空 context
    context_empty = {'aligned_stages': {}}
    result3 = StateTableChecker.check_plan_has_state_table(context_empty)
    print(f"\n测试 3: 空 context")
    print(f"  结果: {result3}")
    print(f"  预期: False")
    print(f"  {'✓ 通过' if not result3 else '✗ 失败'}")
    
    return result1 and not result2 and not result3


def test_get_state_table_status_message():
    """测试生成状态表状态消息"""
    print("\n" + "=" * 80)
    print("测试: get_state_table_status_message")
    print("=" * 80)
    
    base_msg = "建议启用状态表"
    
    # 测试用例 1: 没有状态表
    msg1 = StateTableChecker.get_state_table_status_message(False, base_msg)
    print(f"\n测试 1: 没有状态表")
    print(f"  消息: {msg1}")
    print(f"  预期: 只返回基础消息")
    print(f"  {'✓ 通过' if msg1 == base_msg else '✗ 失败'}")
    
    # 测试用例 2: 有状态表，使用默认后缀
    msg2 = StateTableChecker.get_state_table_status_message(True, base_msg)
    print(f"\n测试 2: 有状态表，使用默认后缀")
    print(f"  消息: {msg2}")
    print(f"  预期: 包含 'Job 已包含中间状态表' 的提示")
    print(f"  {'✓ 通过' if 'Job 已包含中间状态表' in msg2 else '✗ 失败'}")
    
    # 测试用例 3: 有状态表，使用自定义后缀
    custom_suffix = "但该聚合未能利用"
    msg3 = StateTableChecker.get_state_table_status_message(True, base_msg, custom_suffix)
    print(f"\n测试 3: 有状态表，使用自定义后缀")
    print(f"  消息: {msg3}")
    print(f"  预期: 包含自定义后缀")
    print(f"  {'✓ 通过' if custom_suffix in msg3 else '✗ 失败'}")
    
    return (msg1 == base_msg and 
            'Job 已包含中间状态表' in msg2 and 
            custom_suffix in msg3)


if __name__ == '__main__':
    print("\n" + "=" * 80)
    print("状态表检查工具类测试")
    print("=" * 80)
    
    test1_passed = test_check_plan_has_state_table_with_plan()
    test2_passed = test_check_plan_has_state_table_with_context()
    test3_passed = test_get_state_table_status_message()
    
    print("\n" + "=" * 80)
    print("测试总结")
    print("=" * 80)
    print(f"check_plan_has_state_table (传入 plan): {'✓ 通过' if test1_passed else '✗ 失败'}")
    print(f"check_plan_has_state_table (传入 context): {'✓ 通过' if test2_passed else '✗ 失败'}")
    print(f"get_state_table_status_message: {'✓ 通过' if test3_passed else '✗ 失败'}")
    
    if test1_passed and test2_passed and test3_passed:
        print("\n✓ 所有测试通过！")
        sys.exit(0)
    else:
        print("\n✗ 部分测试失败")
        sys.exit(1)
