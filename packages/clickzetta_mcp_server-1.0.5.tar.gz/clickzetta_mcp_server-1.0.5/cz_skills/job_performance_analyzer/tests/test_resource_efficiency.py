#!/usr/bin/env python3
"""测试资源效率分析规则

Case 覆盖：
  Case 1: stg35 场景 — DOP < vc_cores，理论一轮跑完，实际 12.7x → 触发
  Case 2: 资源充足 — 实际耗时接近理论最优 → 不触发
  Case 3: DOP > vc_cores — 需要多轮，但实际耗时合理 → 不触发
  Case 4: 前提过滤 — stage 耗时太短 → 不触发
  Case 5: task 并发计算正确性
"""
import unittest
from cz_skills.job_performance_analyzer.rules.incremental.stage_optimization.resource_efficiency_analysis import ResourceEfficiencyAnalysis


class TestResourceEfficiency(unittest.TestCase):
    def setUp(self):
        self.rule = ResourceEfficiencyAnalysis()
        self.base_context = {
            'has_profile': True,
            'settings': {},
            'total_job_time': 1000000,
            'vc_mode_info': {'vc_cores': 5600},
            'aligned_stages': {},
        }

    def _make_task_summary(self, task_specs):
        """构造 taskSummary
        task_specs: list of (start_ms, end_ms)
        """
        summary = {}
        for i, (start, end) in enumerate(task_specs):
            summary[str(i)] = {
                'startTime': str(start),
                'endTime': str(end),
                'inputOutputStats': {},
            }
        return summary

    # ---- Case 1: stg35 场景 ----

    def test_case1_stg35_resource_starvation(self):
        """DOP=232, vc_cores=5600, 理论一轮跑完(47.8s)，实际 608.9s → 触发"""
        # 模拟 232 个 task，分批跑（平均并发约 6-7）
        tasks = []
        base = 1000000
        batch_size = 7
        for batch in range(34):  # ~232/7 = 33 batches
            batch_start = base + batch * 48000
            for j in range(min(batch_size, 232 - batch * batch_size)):
                t_start = batch_start + j * 100  # 略微错开
                t_end = t_start + 40000 + (j * 1000)  # 40-47s
                tasks.append((t_start, t_end))

        task_summary = self._make_task_summary(tasks[:232])
        stage_start = min(t[0] for t in tasks[:232])
        stage_end = max(t[1] for t in tasks[:232])

        stage_data = {
            'stage_id': 'stg35',
            'profile': {
                'startTime': str(stage_start),
                'endTime': str(stage_end),
                'taskSummary': task_summary,
            },
            'metrics': {
                'elapsed_ms': stage_end - stage_start,
                'dop': 232,
            },
        }

        self.assertTrue(self.rule.check(stage_data, self.base_context))
        result = self.rule.analyze(stage_data, self.base_context)
        self.assertEqual(len(result['findings']), 1)
        self.assertEqual(result['findings'][0]['type'], 'RESOURCE_INEFFICIENCY')
        # efficiency_ratio 应该 >= 2.0
        ratio = result['findings'][0]['details']['efficiency_ratio']
        self.assertGreaterEqual(ratio, 2.0)

    # ---- Case 2: 资源充足 ----

    def test_case2_resources_sufficient(self):
        """DOP=100, vc_cores=5600, 所有 task 同时跑，耗时接近 max_task → 不触发"""
        base = 1000000
        # 100 个 task 同时跑，各 10s
        tasks = [(base, base + 10000 + i * 10) for i in range(100)]
        task_summary = self._make_task_summary(tasks)
        max_task_end = max(t[1] for t in tasks)

        stage_data = {
            'stage_id': 'stg1',
            'profile': {
                'startTime': str(base),
                'endTime': str(max_task_end),
                'taskSummary': task_summary,
            },
            'metrics': {
                'elapsed_ms': max_task_end - base,  # ~11s，但需要 > 60s 过 check
                'dop': 100,
            },
        }

        # elapsed < 60s，check 不通过，所以不触发（这是正确的 — 短 stage 不分析）
        self.assertFalse(self.rule.check(stage_data, self.base_context))

    # ---- Case 3: DOP > vc_cores ----

    def test_case3_dop_exceeds_vc_cores(self):
        """DOP=10000, vc_cores=5600, 需要 2 轮，实际耗时合理 → 不触发"""
        base = 1000000
        # 模拟 2 轮：5600 个 task 第一轮，4400 个第二轮
        tasks = []
        for i in range(5600):
            tasks.append((base, base + 10000))
        for i in range(4400):
            tasks.append((base + 10000, base + 20000))
        task_summary = self._make_task_summary(tasks)

        stage_data = {
            'stage_id': 'stg2',
            'profile': {
                'startTime': str(base),
                'endTime': str(base + 20000),
                'taskSummary': task_summary,
            },
            'metrics': {
                'elapsed_ms': 20000,  # 20s < 60s → check 不通过
                'dop': 10000,
            },
        }

        # elapsed < 60s，check 不通过
        self.assertFalse(self.rule.check(stage_data, self.base_context))

    def test_case3_dop_exceeds_vc_cores_long_stage(self):
        """DOP=10000, vc_cores=5600, 需要 2 轮，实际耗时 = 理论 2 轮 → 不触发"""
        base = 1000000
        task_time = 50000  # 50s per task
        tasks = []
        for i in range(5600):
            tasks.append((base, base + task_time))
        for i in range(4400):
            tasks.append((base + task_time, base + task_time * 2))
        task_summary = self._make_task_summary(tasks)

        stage_data = {
            'stage_id': 'stg2b',
            'profile': {
                'startTime': str(base),
                'endTime': str(base + task_time * 2),
                'taskSummary': task_summary,
            },
            'metrics': {
                'elapsed_ms': task_time * 2,  # 100s = 理论最优
                'dop': 10000,
            },
        }

        self.assertTrue(self.rule.check(stage_data, self.base_context))
        result = self.rule.analyze(stage_data, self.base_context)
        # 理论 50s * 2轮 = 100s，实际 100s，ratio = 1.0x → 不触发
        self.assertEqual(len(result['findings']), 0)

    # ---- Case 4: 前提过滤 ----

    def test_case4_filter_short_stage(self):
        """stage 耗时 < 60s → 不触发"""
        base = 1000000
        tasks = [(base, base + 5000) for _ in range(10)]
        task_summary = self._make_task_summary(tasks)

        stage_data = {
            'stage_id': 'stg3',
            'profile': {
                'startTime': str(base),
                'endTime': str(base + 50000),
                'taskSummary': task_summary,
            },
            'metrics': {
                'elapsed_ms': 50000,  # < 60000
                'dop': 10,
            },
        }

        self.assertFalse(self.rule.check(stage_data, self.base_context))

    def test_case4_filter_no_vc_cores(self):
        """vc_cores = 0 → 不触发"""
        context = {**self.base_context, 'vc_mode_info': {'vc_cores': 0}}
        base = 1000000
        tasks = [(base, base + 100000) for _ in range(10)]
        task_summary = self._make_task_summary(tasks)

        stage_data = {
            'stage_id': 'stg4',
            'profile': {
                'startTime': str(base),
                'endTime': str(base + 100000),
                'taskSummary': task_summary,
            },
            'metrics': {
                'elapsed_ms': 100000,
                'dop': 10,
            },
        }

        self.assertFalse(self.rule.check(stage_data, context))

    # ---- Case 5: task 并发计算 ----

    def test_case5_task_concurrency(self):
        """验证 _calc_task_concurrency 的正确性"""
        # 3 个 task 同时跑
        task_summary = {
            '0': {'startTime': '1000', 'endTime': '2000'},
            '1': {'startTime': '1000', 'endTime': '2000'},
            '2': {'startTime': '1000', 'endTime': '2000'},
        }
        result = self.rule._calc_task_concurrency(task_summary)
        self.assertEqual(result['max_concurrency'], 3)
        self.assertEqual(result['min_concurrency'], 3)

    def test_case5_task_concurrency_sequential(self):
        """验证顺序执行的并发计算"""
        # 3 个 task 顺序跑
        task_summary = {
            '0': {'startTime': '1000', 'endTime': '2000'},
            '1': {'startTime': '2000', 'endTime': '3000'},
            '2': {'startTime': '3000', 'endTime': '4000'},
        }
        result = self.rule._calc_task_concurrency(task_summary)
        self.assertEqual(result['max_concurrency'], 1)


if __name__ == '__main__':
    unittest.main()
