#!/usr/bin/env python3
"""测试数据倾斜检测规则

Case 覆盖：
  Case 1: 行宽差异假倾斜 — rows 倾斜但 time 不倾斜 → 不触发
  Case 2: 真正的数据倾斜 — time 倾斜 + rows 倾斜 → 触发 DATA_SKEW
  Case 3: 计算复杂度差异 — time 倾斜但 rows 不倾斜 → 触发 TIME_SKEW（无 split size 建议）
  Case 4: 少量 active task + 大量 idle — idle 过滤后 time 倾斜准确
  Case 5: 前提过滤 — stage 耗时太短/数据量太小/占比太低 → 不触发
  Case 6: 包含 Scan 算子 → 给 split size 建议
  Case 7: 包含 Shuffle Read → 提示关注上游
"""
import unittest
from cz_skills.job_performance_analyzer.rules.incremental.stage_optimization.skew_detection import SkewDetection


class TestSkewDetection(unittest.TestCase):
    def setUp(self):
        self.rule = SkewDetection()
        self.base_context = {
            'has_profile': True,
            'settings': {},
            'total_job_time': 100000,  # 100s
        }

    def _make_metrics(self, elapsed_ms=20000, input_bytes=200*1024*1024,
                      output_bytes=100*1024*1024,
                      time_max_median=1.0, active_tasks=100, total_tasks=100,
                      active_max_ms=10000, active_median_ms=10000,
                      rows_max_median=1.0, concentration_ratio=1.0,
                      top_k_tasks=50, max_rows=1000, median_rows=1000):
        return {
            'elapsed_ms': elapsed_ms,
            'input_bytes': input_bytes,
            'output_bytes': output_bytes,
            'task_time_max_median_ratio': time_max_median,
            'active_task_count': active_tasks,
            'total_task_count': total_tasks,
            'active_task_ratio': active_tasks / total_tasks if total_tasks > 0 else 1.0,
            'active_max_ms': active_max_ms,
            'active_avg_ms': active_max_ms,  # simplified
            'active_median_ms': active_median_ms,
            'task_time_skew_ratio': time_max_median,
            'data_skew_max_median_ratio': rows_max_median,
            'data_skew_concentration_ratio': concentration_ratio,
            'data_skew_top_k_tasks': top_k_tasks,
            'data_skew_max_rows': max_rows,
            'data_skew_median_rows': median_rows,
        }

    # ---- Case 1: 行宽差异假倾斜 ----

    def test_case1_row_width_difference_no_trigger(self):
        """Case 1: 行宽差异假倾斜 — 模拟 stg35 场景
        rows max/median=16.3x 但 time max/median=3.1x → 不触发
        """
        metrics = self._make_metrics(
            elapsed_ms=608882, input_bytes=50*1024**3,
            time_max_median=3.1,  # 时间不倾斜
            active_tasks=232, total_tasks=232,
            active_max_ms=47840, active_median_ms=15198,
            rows_max_median=16.3, max_rows=14232832, median_rows=875326,
        )
        stage_data = {'stage_id': 'stg35', 'plan': {'operators': []}, 'metrics': metrics}
        self.assertFalse(self.rule.check(stage_data, self.base_context))

    # ---- Case 2: 真正的数据倾斜 ----

    def test_case2_real_data_skew_triggers(self):
        """Case 2: 真正的数据倾斜 — time 倾斜 + rows 倾斜 → DATA_SKEW"""
        metrics = self._make_metrics(
            elapsed_ms=30000, input_bytes=10*1024**3,
            time_max_median=15.0,  # 时间倾斜
            active_tasks=100, total_tasks=100,
            active_max_ms=30000, active_median_ms=2000,
            rows_max_median=20.0, max_rows=10000000, median_rows=500000,
        )
        stage_data = {
            'stage_id': 'stg1', 'metrics': metrics,
            'plan': {'operators': [{'tableScan': {}}]},
        }
        self.assertTrue(self.rule.check(stage_data, self.base_context))

        result = self.rule.analyze(stage_data, self.base_context)
        self.assertEqual(len(result['findings']), 1)
        self.assertEqual(result['findings'][0]['type'], 'DATA_SKEW')
        # 有 scan 算子，应该有 split size 建议
        self.assertTrue(len(result['recommendations']) > 0)

    # ---- Case 3: 计算复杂度差异 ----

    def test_case3_time_skew_without_data_skew(self):
        """Case 3: time 倾斜但 rows 不倾斜 → TIME_SKEW（无 split size 建议）"""
        metrics = self._make_metrics(
            elapsed_ms=20000, input_bytes=5*1024**3,
            time_max_median=12.0,  # 时间倾斜
            active_tasks=50, total_tasks=50,
            active_max_ms=20000, active_median_ms=1667,
            rows_max_median=1.5, max_rows=1000000, median_rows=666666,  # 数据量均匀
        )
        stage_data = {
            'stage_id': 'stg2', 'metrics': metrics,
            'plan': {'operators': [{'tableScan': {}}]},
        }
        self.assertTrue(self.rule.check(stage_data, self.base_context))

        result = self.rule.analyze(stage_data, self.base_context)
        self.assertEqual(len(result['findings']), 1)
        self.assertEqual(result['findings'][0]['type'], 'TIME_SKEW')
        # 数据量不倾斜，不应该有 split size 建议
        self.assertEqual(len(result['recommendations']), 0)

    # ---- Case 4: 少量 active + 大量 idle ----

    def test_case4_few_active_many_idle(self):
        """Case 4: DOP=100, 5 active tasks, 95 idle
        1 个 active task 耗时 500s, 其他 4 个各 10s
        idle 过滤后 time max/median = 500/10 = 50x → 触发
        """
        metrics = self._make_metrics(
            elapsed_ms=500000, input_bytes=10*1024**3,
            time_max_median=50.0,  # idle 过滤后的时间倾斜
            active_tasks=5, total_tasks=100,
            active_max_ms=500000, active_median_ms=10000,
            rows_max_median=100.0, max_rows=50000000, median_rows=500000,
        )
        stage_data = {
            'stage_id': 'stg3', 'metrics': metrics,
            'plan': {'operators': [{'tableScan': {}}]},
        }
        self.assertTrue(self.rule.check(stage_data, self.base_context))

        result = self.rule.analyze(stage_data, self.base_context)
        self.assertEqual(result['findings'][0]['type'], 'DATA_SKEW')
        self.assertEqual(result['findings'][0]['severity'], 'HIGH')

    # ---- Case 5: 前提过滤 ----

    def test_case5_filter_short_stage(self):
        """前提过滤：stage 耗时太短"""
        metrics = self._make_metrics(
            elapsed_ms=3000,  # < 5000ms
            time_max_median=20.0,
        )
        stage_data = {'stage_id': 'stg4', 'plan': {'operators': []}, 'metrics': metrics}
        self.assertFalse(self.rule.check(stage_data, self.base_context))

    def test_case5_filter_small_data(self):
        """前提过滤：数据量太小"""
        metrics = self._make_metrics(
            elapsed_ms=20000,
            input_bytes=50*1024*1024,  # 50MB < 100MB
            output_bytes=30*1024*1024,
            time_max_median=20.0,
        )
        stage_data = {'stage_id': 'stg5', 'plan': {'operators': []}, 'metrics': metrics}
        self.assertFalse(self.rule.check(stage_data, self.base_context))

    def test_case5_filter_low_time_ratio(self):
        """前提过滤：stage 耗时占比太低"""
        context = {**self.base_context, 'total_job_time': 1000000}  # 1000s
        metrics = self._make_metrics(
            elapsed_ms=10000,  # 10s / 1000s = 1% < 15%
            time_max_median=20.0,
        )
        stage_data = {'stage_id': 'stg6', 'plan': {'operators': []}, 'metrics': metrics}
        self.assertFalse(self.rule.check(stage_data, context))

    # ---- Case 6: Scan 算子 split size 建议 ----

    def test_case6_scan_split_size_recommendation(self):
        """包含 Scan 算子 + 数据倾斜 → split size 建议"""
        metrics = self._make_metrics(
            elapsed_ms=30000, input_bytes=10*1024**3,
            time_max_median=15.0,
            active_tasks=200, total_tasks=200,
            active_max_ms=30000, active_median_ms=2000,
            rows_max_median=10.0, max_rows=5000000, median_rows=500000,
        )
        stage_data = {
            'stage_id': 'stg7', 'metrics': metrics,
            'plan': {'operators': [{'tableScan': {}}]},
        }
        result = self.rule.analyze(stage_data, self.base_context)
        self.assertTrue(len(result['recommendations']) > 0)
        self.assertIn('split.size', result['recommendations'][0]['setting'])

    # ---- Case 7: Shuffle Read ----

    def test_case7_shuffle_read_insight(self):
        """包含 Shuffle Read + 数据倾斜 → 提示关注上游"""
        metrics = self._make_metrics(
            elapsed_ms=25000, input_bytes=8*1024**3,
            time_max_median=12.0,
            active_tasks=100, total_tasks=100,
            active_max_ms=25000, active_median_ms=2083,
            rows_max_median=8.0, max_rows=4000000, median_rows=500000,
        )
        stage_data = {
            'stage_id': 'stg8', 'metrics': metrics,
            'plan': {'operators': [{'shuffleRead': {}}]},
        }
        result = self.rule.analyze(stage_data, self.base_context)
        self.assertEqual(result['findings'][0]['type'], 'DATA_SKEW')
        # 没有 scan，不应该有 split size 建议
        self.assertEqual(len(result['recommendations']), 0)
        # 应该有 shuffle read 相关 insight
        shuffle_insights = [i for i in result['insights'] if 'Shuffle Read' in i['message']]
        self.assertTrue(len(shuffle_insights) > 0)

    # ---- Case: 无 profile 数据 ----

    def test_no_profile_data(self):
        """无 profile 数据 → 不触发"""
        context = {**self.base_context, 'has_profile': False}
        metrics = self._make_metrics(time_max_median=20.0)
        stage_data = {'stage_id': 'stg9', 'plan': {'operators': []}, 'metrics': metrics}
        self.assertFalse(self.rule.check(stage_data, context))

    # ---- Case: 阈值边界 ----

    def test_time_skew_at_threshold(self):
        """时间倾斜刚好等于阈值 10x → 触发"""
        metrics = self._make_metrics(
            elapsed_ms=20000, input_bytes=5*1024**3,
            time_max_median=10.0,
            rows_max_median=10.0, max_rows=5000000, median_rows=500000,
        )
        stage_data = {'stage_id': 'stg10', 'plan': {'operators': []}, 'metrics': metrics}
        self.assertTrue(self.rule.check(stage_data, self.base_context))

    def test_time_skew_below_threshold(self):
        """时间倾斜 9.9x < 10x → 不触发"""
        metrics = self._make_metrics(
            elapsed_ms=20000, input_bytes=5*1024**3,
            time_max_median=9.9,
            rows_max_median=50.0,  # 即使 rows 倾斜很高也不触发
        )
        stage_data = {'stage_id': 'stg11', 'plan': {'operators': []}, 'metrics': metrics}
        self.assertFalse(self.rule.check(stage_data, self.base_context))


if __name__ == '__main__':
    unittest.main()


class TestSkewDetectionHudiExternalTable(unittest.TestCase):
    """测试 Hudi 外表场景下的倾斜检测行为

    修改背景：当 Stage 包含 Hudi 外表的 TableScan 时，split size 调整无效（Hudi 按文件切分），
    应给出 Hudi 专属提示而非 split size 建议。
    """

    def setUp(self):
        self.rule = SkewDetection()
        self.base_context = {
            'has_profile': True,
            'settings': {},
            'total_job_time': 100000,
        }

    def _make_skew_metrics(self, **overrides):
        """构造满足 DATA_SKEW 触发条件的 metrics"""
        defaults = {
            'elapsed_ms': 30000,
            'input_bytes': 10 * 1024 ** 3,
            'output_bytes': 1 * 1024 ** 3,
            'task_time_max_median_ratio': 15.0,
            'active_task_count': 100,
            'total_task_count': 100,
            'active_task_ratio': 1.0,
            'active_max_ms': 30000,
            'active_avg_ms': 2000,
            'active_median_ms': 2000,
            'task_time_skew_ratio': 15.0,
            'data_skew_max_median_ratio': 10.0,
            'data_skew_concentration_ratio': 0.1,
            'data_skew_top_k_tasks': 5,
            'data_skew_max_rows': 5000000,
            'data_skew_median_rows': 500000,
        }
        defaults.update(overrides)
        return defaults

    def _make_hudi_external_table_plan(self, hudi_type='MERGE_ON_READ', table_path=None):
        """构造包含 Hudi 外表 TableScan 的 plan

        实际 plan.json 中外表的判断依据：
        - tableMeta.tableType == 'EXTERNAL_TABLE'
        - 或 properties 中 external == 'TRUE'
        Hudi 表的判断依据：properties 中包含 hoodie.table.type
        """
        if table_path is None:
            table_path = ['ws1', 'ext_db', 'hudi_events']
        return {
            'operators': [{
                'tableScan': {
                    'table': {
                        'path': table_path,
                        'tableMeta': {'tableType': 'EXTERNAL_TABLE'},
                        'properties': [
                            {'key': 'hoodie.table.type', 'value': hudi_type},
                        ],
                    }
                }
            }]
        }

    # ---- _get_external_hudi_info 单元测试 ----

    def test_hudi_info_detected_with_list_properties(self):
        """properties 为 list 格式 + tableMeta 外表标记 → 正确识别 Hudi 外表"""
        plan = self._make_hudi_external_table_plan('COPY_ON_WRITE')
        info = SkewDetection._get_external_hudi_info(plan)
        self.assertEqual(info['table_name'], 'ws1.ext_db.hudi_events')
        self.assertEqual(info['hudi_type'], 'COPY_ON_WRITE')

    def test_hudi_info_detected_with_dict_properties(self):
        """properties 为 dict 格式时正确识别 Hudi 外表"""
        plan = {
            'operators': [{
                'tableScan': {
                    'table': {
                        'path': ['ws1', 'db', 'tbl'],
                        'tableMeta': {'tableType': 'EXTERNAL_TABLE'},
                        'properties': {'hoodie.table.type': 'MERGE_ON_READ'},
                    }
                }
            }]
        }
        info = SkewDetection._get_external_hudi_info(plan)
        self.assertEqual(info['hudi_type'], 'MERGE_ON_READ')

    def test_hudi_info_detected_via_properties_external_flag(self):
        """通过 properties 中的 external=TRUE 识别外表（无 tableMeta）"""
        plan = {
            'operators': [{
                'tableScan': {
                    'table': {
                        'path': ['ws1', 'db', 'tbl'],
                        'properties': [
                            {'key': 'external', 'value': 'TRUE'},
                            {'key': 'hoodie.table.type', 'value': 'MERGE_ON_READ'},
                        ],
                    }
                }
            }]
        }
        info = SkewDetection._get_external_hudi_info(plan)
        self.assertEqual(info['hudi_type'], 'MERGE_ON_READ')

    def test_hudi_info_empty_for_internal_table(self):
        """内部表（非外表）不应识别为 Hudi 外表"""
        plan = {
            'operators': [{
                'tableScan': {
                    'table': {
                        'path': ['ws1', 'db', 'tbl'],
                        'tableMeta': {'tableType': 'MANAGED_TABLE'},
                        'properties': [
                            {'key': 'hoodie.table.type', 'value': 'MERGE_ON_READ'},
                        ],
                    }
                }
            }]
        }
        info = SkewDetection._get_external_hudi_info(plan)
        self.assertEqual(info, {})

    def test_hudi_info_empty_for_external_non_hudi(self):
        """外表但不是 Hudi 表 → 返回空"""
        plan = {
            'operators': [{
                'tableScan': {
                    'table': {
                        'path': ['ws1', 'db', 'tbl'],
                        'tableMeta': {'tableType': 'EXTERNAL_TABLE'},
                        'properties': [
                            {'key': 'some.other.property', 'value': 'val'},
                        ],
                    }
                }
            }]
        }
        info = SkewDetection._get_external_hudi_info(plan)
        self.assertEqual(info, {})

    def test_hudi_info_empty_for_empty_plan(self):
        """空 plan → 返回空"""
        self.assertEqual(SkewDetection._get_external_hudi_info({}), {})
        self.assertEqual(SkewDetection._get_external_hudi_info(None), {})

    def test_hudi_info_empty_for_no_operators(self):
        """plan 无 operators → 返回空"""
        self.assertEqual(SkewDetection._get_external_hudi_info({'operators': []}), {})

    def test_hudi_info_external_property_case_insensitive(self):
        """properties 中 external 字段值大小写不敏感"""
        plan = {
            'operators': [{
                'tableScan': {
                    'table': {
                        'path': ['ws1', 'db', 'tbl'],
                        'properties': [
                            {'key': 'external', 'value': 'true'},
                            {'key': 'hoodie.table.type', 'value': 'MERGE_ON_READ'},
                        ],
                    }
                }
            }]
        }
        info = SkewDetection._get_external_hudi_info(plan)
        self.assertEqual(info['hudi_type'], 'MERGE_ON_READ')

    # ---- analyze() 集成测试：Hudi 外表路径 ----

    def test_hudi_external_table_no_split_size_recommendation(self):
        """Hudi 外表 + 数据倾斜 → 有 DATA_SKEW finding，无 split size 建议，有 Hudi 提示"""
        plan = self._make_hudi_external_table_plan('MERGE_ON_READ')
        metrics = self._make_skew_metrics()
        stage_data = {'stage_id': 'stg_hudi', 'metrics': metrics, 'plan': plan}

        result = self.rule.analyze(stage_data, self.base_context)

        # 应该有 DATA_SKEW finding
        self.assertEqual(len(result['findings']), 1)
        self.assertEqual(result['findings'][0]['type'], 'DATA_SKEW')

        # 不应该有 split size 建议
        split_recs = [r for r in result['recommendations']
                      if 'split.size' in r.get('setting', '')]
        self.assertEqual(len(split_recs), 0, "Hudi 外表不应有 split size 建议")

        # 应该有 Hudi 相关 insight
        hudi_insights = [i for i in result['insights'] if 'Hudi' in i['message']]
        self.assertTrue(len(hudi_insights) > 0, "应该有 Hudi 外表相关提示")
        self.assertIn('hudi_events', hudi_insights[0]['message'])
        self.assertIn('MERGE_ON_READ', hudi_insights[0]['message'])
        self.assertIn('compaction', hudi_insights[0]['message'])

    def test_non_hudi_scan_still_gets_split_size(self):
        """普通内部表 + 数据倾斜 → 仍然给 split size 建议（回归验证）"""
        plan = {
            'operators': [{
                'tableScan': {
                    'table': {
                        'path': ['ws1', 'db', 'normal_table'],
                        'tableMeta': {'tableType': 'MANAGED_TABLE'},
                        'properties': [],
                    }
                }
            }]
        }
        metrics = self._make_skew_metrics()
        stage_data = {'stage_id': 'stg_normal', 'metrics': metrics, 'plan': plan}

        result = self.rule.analyze(stage_data, self.base_context)

        # 应该有 DATA_SKEW finding
        self.assertEqual(result['findings'][0]['type'], 'DATA_SKEW')

        # 应该有 split size 建议
        split_recs = [r for r in result['recommendations']
                      if 'split.size' in r.get('setting', '')]
        self.assertTrue(len(split_recs) > 0, "普通表应该有 split size 建议")

        # 不应该有 Hudi 相关 insight
        hudi_insights = [i for i in result['insights'] if 'Hudi' in i['message']]
        self.assertEqual(len(hudi_insights), 0, "普通表不应有 Hudi 提示")

    def test_hudi_cow_external_table(self):
        """Hudi COW 外表也应走 Hudi 路径"""
        plan = self._make_hudi_external_table_plan('COPY_ON_WRITE')
        metrics = self._make_skew_metrics()
        stage_data = {'stage_id': 'stg_cow', 'metrics': metrics, 'plan': plan}

        result = self.rule.analyze(stage_data, self.base_context)

        split_recs = [r for r in result['recommendations']
                      if 'split.size' in r.get('setting', '')]
        self.assertEqual(len(split_recs), 0, "Hudi COW 外表不应有 split size 建议")

        hudi_insights = [i for i in result['insights'] if 'Hudi' in i['message']]
        self.assertTrue(len(hudi_insights) > 0)
        self.assertIn('COPY_ON_WRITE', hudi_insights[0]['message'])

    def test_mixed_scan_hudi_and_normal(self):
        """Stage 同时有 Hudi 外表和普通表 → 走 Hudi 路径（Hudi 优先）"""
        plan = {
            'operators': [
                {
                    'tableScan': {
                        'table': {
                            'path': ['ws1', 'ext_db', 'hudi_tbl'],
                            'tableMeta': {'tableType': 'EXTERNAL_TABLE'},
                            'properties': [
                                {'key': 'hoodie.table.type', 'value': 'MERGE_ON_READ'},
                            ],
                        }
                    }
                },
                {
                    'tableScan': {
                        'table': {
                            'path': ['ws1', 'db', 'normal_tbl'],
                            'tableMeta': {'tableType': 'MANAGED_TABLE'},
                            'properties': [],
                        }
                    }
                },
            ]
        }
        metrics = self._make_skew_metrics()
        stage_data = {'stage_id': 'stg_mixed', 'metrics': metrics, 'plan': plan}

        result = self.rule.analyze(stage_data, self.base_context)

        # Hudi 外表被检测到 → 走 Hudi 路径，无 split size 建议
        split_recs = [r for r in result['recommendations']
                      if 'split.size' in r.get('setting', '')]
        self.assertEqual(len(split_recs), 0, "有 Hudi 外表时不应有 split size 建议")


if __name__ == '__main__':
    unittest.main()
