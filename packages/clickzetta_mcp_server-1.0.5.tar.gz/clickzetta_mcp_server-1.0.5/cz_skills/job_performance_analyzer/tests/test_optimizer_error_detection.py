#!/usr/bin/env python3
"""
测试优化器错误检测规则
"""
import unittest
import sys
import os

script_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))

from cz_skills.job_performance_analyzer.rules.common import ErrorMessageCollector, OptimizerErrorDetection


class TestOptimizerErrorDetection(unittest.TestCase):
    """测试优化器错误检测规则"""
    
    def setUp(self):
        """初始化测试"""
        self.collector = ErrorMessageCollector()
        self.rule = OptimizerErrorDetection()
    
    def test_detect_optimizer_error_without_playback(self):
        """测试检测优化器错误（未设置 playback）"""
        # 先收集错误
        context = {
            'has_profile': True,
            'raw_profile': {
                'jobStatus': {
                    'message': 'Error: Optimizer internal error occurred during query planning'
                }
            },
            'aligned_stages': {},
            'settings': {}  # 没有设置 playback
        }
        
        # 收集错误信息
        collector_result = self.collector.analyze_global(context)
        context['error_messages'] = collector_result.get('error_messages', [])
        
        # 检测优化器错误
        result = self.rule.analyze_global(context)
        
        self.assertEqual(len(result['findings']), 1)
        self.assertEqual(result['findings'][0]['type'], 'optimizer_internal_error')
        # 应该只有一个重跑建议
        self.assertEqual(len(result['recommendations']), 1)
        self.assertEqual(result['recommendations'][0]['type'], 'rerun_job')
        # 检查action中包含设置参数的步骤
        self.assertIn('cz.sql.playback.scratch=true', result['recommendations'][0]['action'])
    
    def test_detect_optimizer_error_with_playback(self):
        """测试检测优化器错误（已设置 playback）"""
        context = {
            'has_profile': True,
            'raw_profile': {
                'jobStatus': {
                    'message': 'Optimizer internal error'
                }
            },
            'aligned_stages': {},
            'settings': {
                'cz.sql.playback.scratch': 'true'  # 已经设置了 playback
            }
        }
        
        # 收集错误信息
        collector_result = self.collector.analyze_global(context)
        context['error_messages'] = collector_result.get('error_messages', [])
        
        # 检测优化器错误
        result = self.rule.analyze_global(context)
        
        self.assertEqual(len(result['findings']), 1)
        self.assertEqual(result['findings'][0]['type'], 'optimizer_internal_error')
        # 已经设置了 playback，应该推荐联系技术支持
        self.assertEqual(len(result['recommendations']), 1)
        self.assertEqual(result['recommendations'][0]['type'], 'contact_support')
        # 应该有 insight 提示已启用
        self.assertGreater(len(result['insights']), 0)
        self.assertIn('已启用', result['insights'][0]['message'])
    
    def test_no_optimizer_error(self):
        """测试没有优化器错误的情况"""
        context = {
            'has_profile': True,
            'error_messages': [
                {
                    'location': 'job_status',
                    'message': 'Some other error',
                    'refined_message': 'Some other error'
                }
            ],
            'settings': {}
        }
        
        result = self.rule.analyze_global(context)
        
        self.assertEqual(len(result['findings']), 0)
        self.assertEqual(len(result['recommendations']), 0)
    
    def test_case_insensitive_detection(self):
        """测试大小写不敏感的检测"""
        context = {
            'has_profile': True,
            'raw_profile': {
                'jobStatus': {
                    'message': 'OPTIMIZER INTERNAL ERROR'
                }
            },
            'aligned_stages': {},
            'settings': {}
        }
        
        # 收集错误信息
        collector_result = self.collector.analyze_global(context)
        context['error_messages'] = collector_result.get('error_messages', [])
        
        # 检测优化器错误
        result = self.rule.analyze_global(context)
        
        self.assertEqual(len(result['findings']), 1)
    
    def test_multiple_optimizer_errors(self):
        """测试多个优化器错误"""
        context = {
            'has_profile': True,
            'raw_profile': {
                'jobStatus': {
                    'message': 'Optimizer internal error in stage 1'
                }
            },
            'aligned_stages': {
                'stage_1': {
                    'profile': {
                        'message': 'Optimizer internal error in stage execution'
                    }
                }
            },
            'settings': {}
        }
        
        # 收集错误信息
        collector_result = self.collector.analyze_global(context)
        context['error_messages'] = collector_result.get('error_messages', [])
        
        # 检测优化器错误
        result = self.rule.analyze_global(context)
        
        self.assertEqual(len(result['findings']), 1)
        self.assertEqual(result['findings'][0]['evidence']['error_count'], 2)


if __name__ == '__main__':
    unittest.main()
