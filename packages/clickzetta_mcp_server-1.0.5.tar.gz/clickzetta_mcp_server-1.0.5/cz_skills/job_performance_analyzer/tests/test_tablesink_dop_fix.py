#!/usr/bin/env python3
"""测试 TableSink DOP 规则修复"""
import sys
import os

# 添加脚本目录到路径
script_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(script_dir)
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))


def test_stage_dependency_parsing():
    """测试 Stage 依赖关系解析（通过 inputIds）"""
    print("测试 1: Stage 依赖关系解析")
    
    from cz_skills.job_performance_analyzer.core.aligner import StageAligner
    
    # 构造测试数据：stg56 依赖 stg55
    parsed_data = {
        'plan_stages': {
            'stg55': {
                'id': 'stg55',
                'dop': '2048',
                'operators': [
                    {'id': 'ShuffleRead8', 'inputIds': []},
                    {'id': 'HashJoin7', 'inputIds': ['ShuffleRead8']},
                    {'id': 'TableSink532', 'inputIds': ['HashJoin7']},
                ]
            },
            'stg56': {
                'id': 'stg56',
                'dop': '73',
                'operators': [
                    {'id': 'ShuffleRead3', 'inputIds': ['TableSink532']},  # 依赖 stg55 的 TableSink532
                    {'id': 'LocalSort0', 'inputIds': ['ShuffleRead3']},
                    {'id': 'TableSink1', 'inputIds': ['LocalSort0']},
                ]
            }
        },
        'profile_stages': {},
        'has_profile': False,
    }
    
    aligner = StageAligner(parsed_data)
    aligner._parse_stage_dependencies()
    
    # 验证 stg56 的上游 stage 包含 stg55
    upstream_stages = aligner._stage_dependencies.get('stg56', [])
    
    if 'stg55' in upstream_stages:
        print(f"  ✓ 成功解析上游依赖: stg56 -> {upstream_stages}")
        return True
    else:
        print(f"  ✗ 解析失败: stg56 的上游 stage 为 {upstream_stages}，应该包含 stg55")
        return False


def test_tablesink_dop_uses_plan_dop():
    """测试 TableSink DOP 规则使用 plan 中的 DOP"""
    print("\n测试 2: TableSink DOP 规则使用 plan DOP")
    
    from cz_skills.job_performance_analyzer.rules.incremental.stage_optimization.tablesink_dop import TableSinkDop
    
    # 构造测试数据
    stage_data = {
        'stage_id': 'stg56',
        'plan': {
            'id': 'stg56',
            'dop': '73',  # plan 中的 DOP
            'operators': [
                {'id': 'TableSink1', 'inputIds': []}
            ]
        },
        'metrics': {
            'elapsed_ms': 35000,
            'dop': 51,  # profile 中的实际 task count（不应该使用这个）
        },
        'upstream_stages': ['stg55'],
    }
    
    context = {
        'has_profile': True,
        'settings': {},
        'aligned_stages': {
            'stg55': {
                'plan': {
                    'id': 'stg55',
                    'dop': '2048',  # 上游的 plan DOP
                },
                'metrics': {
                    'dop': 51,  # 上游的实际 task count
                }
            },
            'stg56': stage_data,
        }
    }
    
    rule = TableSinkDop()
    
    # 检查规则是否触发
    if not rule.check(stage_data, context):
        print("  ✗ 规则未触发（应该触发）")
        return False
    
    # 执行分析
    result = rule.analyze(stage_data, context)
    
    # 验证结果
    findings = result.get('findings', [])
    recommendations = result.get('recommendations', [])
    
    if not findings:
        print("  ✗ 没有发现问题（应该发现 DOP 被调小）")
        return False
    
    # 检查是否使用了正确的 DOP 值
    finding = findings[0]
    details = finding.get('details', {})
    current_dop = details.get('current_dop')
    max_upstream_dop = details.get('max_upstream_dop')
    dop_ratio = details.get('dop_ratio')
    
    if current_dop != 73:
        print(f"  ✗ current_dop 错误: {current_dop}，应该是 73（plan DOP）")
        return False
    
    if max_upstream_dop != 2048:
        print(f"  ✗ max_upstream_dop 错误: {max_upstream_dop}，应该是 2048（plan DOP）")
        return False
    
    expected_ratio = 73 / 2048
    if abs(dop_ratio - expected_ratio) > 0.001:
        print(f"  ✗ dop_ratio 错误: {dop_ratio:.4f}，应该是 {expected_ratio:.4f}")
        return False
    
    if not recommendations:
        print("  ✗ 没有参数建议（应该建议禁用 auto adaptive split size）")
        return False
    
    print(f"  ✓ 规则正确触发: current_dop={current_dop}, max_upstream={max_upstream_dop}, ratio={dop_ratio:.4f}")
    print(f"  ✓ 生成了 {len(recommendations)} 条参数建议")
    return True


def test_tablesink_dop_no_trigger_when_close():
    """测试当 DOP 差异不大时不触发"""
    print("\n测试 3: DOP 差异不大时不触发")
    
    from cz_skills.job_performance_analyzer.rules.incremental.stage_optimization.tablesink_dop import TableSinkDop
    
    # 构造测试数据：DOP 差异不大
    stage_data = {
        'stage_id': 'stg56',
        'plan': {
            'id': 'stg56',
            'dop': '150',  # 与上游接近
            'operators': [
                {'id': 'TableSink1', 'inputIds': []}
            ]
        },
        'metrics': {
            'elapsed_ms': 35000,
            'dop': 150,
        },
        'upstream_stages': ['stg55'],
    }
    
    context = {
        'has_profile': True,
        'settings': {},
        'aligned_stages': {
            'stg55': {
                'plan': {
                    'id': 'stg55',
                    'dop': '200',  # 上游 DOP
                },
            },
            'stg56': stage_data,
        }
    }
    
    rule = TableSinkDop()
    
    if not rule.check(stage_data, context):
        print("  ✗ 规则未触发检查")
        return False
    
    result = rule.analyze(stage_data, context)
    findings = result.get('findings', [])
    recommendations = result.get('recommendations', [])
    
    # DOP ratio = 150/200 = 0.75 > 0.5，不应该触发
    if findings or recommendations:
        print(f"  ✗ 不应该触发: ratio=0.75 > 0.5，但生成了 {len(findings)} 个 findings")
        return False
    
    print("  ✓ DOP 差异不大时正确不触发")
    return True


def test_stage_dependency_self_exclusion():
    """测试 Stage 依赖关系解析排除自己"""
    print("\n测试 4: Stage 依赖关系解析排除自己")
    
    from cz_skills.job_performance_analyzer.core.aligner import StageAligner
    
    # 构造测试数据：stage 内部有循环引用
    parsed_data = {
        'plan_stages': {
            'stg55': {
                'id': 'stg55',
                'dop': '2048',
                'operators': [
                    {'id': 'ShuffleRead8', 'inputIds': []},
                    {'id': 'HashJoin7', 'inputIds': ['ShuffleRead8', 'HashJoin7']},  # 自己引用自己
                    {'id': 'TableSink532', 'inputIds': ['HashJoin7']},
                ]
            }
        },
        'profile_stages': {},
        'has_profile': False,
    }
    
    aligner = StageAligner(parsed_data)
    aligner._parse_stage_dependencies()
    
    # 验证 stg55 的上游 stage 不包含自己
    upstream_stages = aligner._stage_dependencies.get('stg55', [])
    
    if 'stg55' in upstream_stages:
        print(f"  ✗ 上游 stage 包含自己: {upstream_stages}")
        return False
    
    print(f"  ✓ 正确排除自己: stg55 的上游 stage 为 {upstream_stages}")
    return True


def run_all_tests():
    """运行所有测试"""
    print("=" * 80)
    print("TableSink DOP 规则修复测试")
    print("=" * 80)
    
    tests = [
        test_stage_dependency_parsing,
        test_tablesink_dop_uses_plan_dop,
        test_tablesink_dop_no_trigger_when_close,
        test_stage_dependency_self_exclusion,
    ]
    
    results = []
    for test in tests:
        try:
            result = test()
            results.append(result)
        except Exception as e:
            print(f"  ✗ 测试异常: {str(e)}")
            import traceback
            traceback.print_exc()
            results.append(False)
    
    print("\n" + "=" * 80)
    print(f"测试结果: {sum(results)}/{len(results)} 通过")
    print("=" * 80)
    
    return all(results)


if __name__ == '__main__':
    success = run_all_tests()
    sys.exit(0 if success else 1)
