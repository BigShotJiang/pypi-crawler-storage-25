#!/usr/bin/env python3
"""测试 subplan 树形打印功能"""
import sys
import os

# 添加项目根目录到 Python 路径
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))

from cz_skills.job_performance_analyzer.rules.incremental.state_table.state_table_enable import StateTableEnable


def test_subplan_tree_print():
    """测试树形打印功能"""
    
    # 创建测试数据
    plan = {
        'operators': [
            {
                'id': '1',
                'tableScan': {
                    'table': {'name': 'table_a'}
                },
                'inputIds': []
            },
            {
                'id': '2',
                'tableScan': {
                    'table': {'name': 'table_b'}
                },
                'inputIds': []
            },
            {
                'id': '3',
                'hashJoin': {
                    'join': {'type': 'INNER'}
                },
                'inputIds': ['1', '2']
            },
            {
                'id': '4',
                'hashAgg': {
                    'aggregate': {
                        'aggregateCalls': [
                            {
                                'function': {
                                    'function': {'name': 'SUM'}
                                }
                            },
                            {
                                'function': {
                                    'function': {'name': 'COUNT'}
                                }
                            }
                        ]
                    }
                },
                'inputIds': ['3']
            },
            {
                'id': '5',
                'shuffleRead': {},
                'inputIds': ['4']
            }
        ]
    }
    
    operator_analysis = {
        'TableScan1': {'elapsed_ms': 100.5},
        'TableScan2': {'elapsed_ms': 150.3},
        'HashJoin3': {'elapsed_ms': 200.7},
        'HashAgg4': {'elapsed_ms': 300.2},
        'ShuffleRead5': {'elapsed_ms': 50.1}
    }
    
    subplan = {
        'root_operator': 'ShuffleRead5',
        'root_stage': 'stg1',
        'operators': ['ShuffleRead5', 'HashAgg4', 'HashJoin3', 'TableScan1', 'TableScan2'],
        'percentage': 20.5,
        'total_time_ms': 801.8
    }
    
    context = {
        'aligned_stages': {
            'stg1': {
                'plan': plan,
                'operator_analysis': operator_analysis
            }
        },
        'total_job_time': 3910
    }
    
    # 创建规则实例
    rule = StateTableEnable()
    
    # 生成树形结构
    tree_str = rule._format_subplan_tree(subplan, context)
    
    print(tree_str)
    print()
    print("✓ 树形打印测试完成")


if __name__ == '__main__':
    print("测试 subplan 树形打印...")
    print()
    
    try:
        test_subplan_tree_print()
        print()
        print("=" * 60)
        print("测试通过! ✓")
        print("=" * 60)
    except Exception as e:
        print()
        print("=" * 60)
        print(f"测试失败: {e}")
        print("=" * 60)
        import traceback
        traceback.print_exc()
        sys.exit(1)
