#!/usr/bin/env python3
"""测试版本工具函数"""
import sys
from pathlib import Path

# 添加父目录到 Python 路径
parent = Path(__file__).resolve().parent.parent
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))

from cz_skills.job_performance_analyzer.utils.version_utils import parse_version, compare_version, is_version_le, is_version_ge


def test_parse_version():
    """测试版本解析"""
    print("\n[测试] parse_version")

    test_cases = [
        ("release-v1.3", (1, 3)),
        ("release-v1.4", (1, 4)),
        ("release-v1.4.2", (1, 4)),
        ("v1.2", (1, 2)),
        ("1.5", (1, 5)),
        ("Unknown", None),
        ("", None),
        (None, None),
    ]

    passed = 0
    failed = 0

    for input_val, expected in test_cases:
        result = parse_version(input_val)
        if result == expected:
            print(f"  ✓ parse_version('{input_val}') = {result}")
            passed += 1
        else:
            print(f"  ✗ parse_version('{input_val}') = {result}, 期望 {expected}")
            failed += 1

    print(f"\n  通过: {passed}, 失败: {failed}")
    return failed == 0


def test_compare_version():
    """测试版本比较"""
    print("\n[测试] compare_version")

    test_cases = [
        ((1, 3), 1, 4, -1),  # 1.3 < 1.4
        ((1, 4), 1, 3, 1),   # 1.4 > 1.3
        ((1, 3), 1, 3, 0),   # 1.3 == 1.3
        ((2, 0), 1, 5, 1),   # 2.0 > 1.5
        (None, 1, 3, None),  # None 无法比较
    ]

    passed = 0
    failed = 0

    for version, target_major, target_minor, expected in test_cases:
        result = compare_version(version, target_major, target_minor)
        if result == expected:
            print(f"  ✓ compare_version({version}, {target_major}, {target_minor}) = {result}")
            passed += 1
        else:
            print(f"  ✗ compare_version({version}, {target_major}, {target_minor}) = {result}, 期望 {expected}")
            failed += 1

    print(f"\n  通过: {passed}, 失败: {failed}")
    return failed == 0


def test_is_version_le():
    """测试版本 <= 判断"""
    print("\n[测试] is_version_le")

    test_cases = [
        ((1, 3), 1, 3, True),   # 1.3 <= 1.3
        ((1, 2), 1, 3, True),   # 1.2 <= 1.3
        ((1, 4), 1, 3, False),  # 1.4 > 1.3
        ((2, 0), 1, 5, False),  # 2.0 > 1.5
        (None, 1, 3, False),    # None 保守策略返回 False
    ]

    passed = 0
    failed = 0

    for version, target_major, target_minor, expected in test_cases:
        result = is_version_le(version, target_major, target_minor)
        if result == expected:
            print(f"  ✓ is_version_le({version}, {target_major}, {target_minor}) = {result}")
            passed += 1
        else:
            print(f"  ✗ is_version_le({version}, {target_major}, {target_minor}) = {result}, 期望 {expected}")
            failed += 1

    print(f"\n  通过: {passed}, 失败: {failed}")
    return failed == 0


def test_is_version_ge():
    """测试版本 >= 判断"""
    print("\n[测试] is_version_ge")

    test_cases = [
        ((1, 3), 1, 3, True),   # 1.3 >= 1.3
        ((1, 4), 1, 3, True),   # 1.4 >= 1.3
        ((1, 2), 1, 3, False),  # 1.2 < 1.3
        ((2, 0), 1, 5, True),   # 2.0 >= 1.5
        (None, 1, 3, False),    # None 保守策略返回 False
    ]

    passed = 0
    failed = 0

    for version, target_major, target_minor, expected in test_cases:
        result = is_version_ge(version, target_major, target_minor)
        if result == expected:
            print(f"  ✓ is_version_ge({version}, {target_major}, {target_minor}) = {result}")
            passed += 1
        else:
            print(f"  ✗ is_version_ge({version}, {target_major}, {target_minor}) = {result}, 期望 {expected}")
            failed += 1

    print(f"\n  通过: {passed}, 失败: {failed}")
    return failed == 0


def main():
    """运行所有测试"""
    print("=" * 60)
    print("版本工具函数测试")
    print("=" * 60)

    all_passed = True
    all_passed &= test_parse_version()
    all_passed &= test_compare_version()
    all_passed &= test_is_version_le()
    all_passed &= test_is_version_ge()

    print("\n" + "=" * 60)
    if all_passed:
        print("✓ 所有测试通过")
    else:
        print("✗ 部分测试失败")
    print("=" * 60)

    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())
