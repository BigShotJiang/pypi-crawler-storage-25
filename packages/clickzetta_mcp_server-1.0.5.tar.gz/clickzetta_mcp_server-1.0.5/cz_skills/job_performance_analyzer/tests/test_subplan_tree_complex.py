#!/usr/bin/env python3
"""测试复杂场景下的 subplan 树形打印"""
import sys
import os

# 添加项目根目录到 Python 路径
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))

from cz_skills.job_performance_analyzer.rules.incremental.state_table.state_table_enable import StateTableEnable


def test_complex_subplan_tree():
    """测试复杂的依赖关系"""
    
    # 创建一个更复杂的测试数据，包含多个 join 和分支
    plan = {
        'operators': [
            # 左分支
            {'id': '1', 'tableScan': {'table': {'name': 'table_a'}}, 'inputIds': []},
            {'id': '2', 'tableScan': {'table': {'name': 'table_b'}}, 'inputIds': []},
            {'id': '3', 'hashJoin': {'join': {'type': 'INNER'}}, 'inputIds': ['1', '2']},
            
            # 右分支
            {'id': '4', 'tableScan': {'table': {'name': 'table_c'}}, 'inputIds': []},
            {'id': '5', 'calc': {}, 'inputIds': ['4']},
            
            # 合并
            {'id': '6', 'hashJoin': {'join': {'type': 'LEFT'}}, 'inputIds': ['3', '5']},
            {'id': '7', 'hashAgg': {
                'aggregate': {
                    'aggregateCalls': [
                        {'function': {'function': {'name': 'SUM'}}},
                        {'function': {'function': {'name': 'COUNT'}}}
                    ]
                }
            }, 'inputIds': ['6']},
            {'id': '8', 'shuffleRead': {}, 'inputIds': ['7']}
        ]
    }
    
    operator_analysis = {
        'TableScan1': {'elapsed_ms': 100.0},
        'TableScan2': {'elapsed_ms': 150.0},
        'HashJoin3': {'elapsed_ms': 200.0},
        'TableScan4': {'elapsed_ms': 80.0},
        'Calc5': {'elapsed_ms': 50.0},
        'HashJoin6': {'elapsed_ms': 300.0},
        'HashAgg7': {'elapsed_ms': 250.0},
        'ShuffleRead8': {'elapsed_ms': 70.0}
    }
    
    # subplan 包含所有算子（使用 ID）
    subplan = {
        'root_operator': '8',  # 使用 ID
        'root_stage': 'stg1',
        'operators': ['8', '7', '6', '3', '5', '1', '2', '4'],  # 使用 ID
        'percentage': 25.5,
        'total_time_ms': 1200.0
    }
    
    context = {
        'aligned_stages': {
            'stg1': {
                'plan': plan,
                'operator_analysis': operator_analysis
            }
        },
        'total_job_time': 4700
    }
    
    # 创建规则实例
    rule = StateTableEnable()
    
    # 生成树形结构
    tree_str = rule._format_subplan_tree(subplan, context)
    
    print(tree_str)
    print()
    
    # 验证树形结构包含所有算子
    assert 'ShuffleRead8' in tree_str
    assert 'HashAgg7' in tree_str
    assert 'HashJoin6' in tree_str
    assert 'HashJoin3' in tree_str
    assert 'Calc5' in tree_str
    assert 'TableScan1' in tree_str
    assert 'TableScan2' in tree_str
    assert 'TableScan4' in tree_str
    
    print("✓ 复杂树形打印测试完成")


def test_missing_operators():
    """测试当某些算子在 subplan 中但不在 plan 中时的处理"""
    
    plan = {
        'operators': [
            {'id': '1', 'tableScan': {'table': {'name': 'table_a'}}, 'inputIds': []},
            {'id': '2', 'hashJoin': {'join': {'type': 'INNER'}}, 'inputIds': ['1']},
        ]
    }
    
    operator_analysis = {
        'TableScan1': {'elapsed_ms': 100.0},
        'HashJoin2': {'elapsed_ms': 200.0},
    }
    
    # subplan 包含一个不存在的算子 ID
    subplan = {
        'root_operator': '2',
        'root_stage': 'stg1',
        'operators': ['2', '1', '999'],  # '999' 不存在
        'percentage': 15.0,
        'total_time_ms': 300.0
    }
    
    context = {
        'aligned_stages': {
            'stg1': {
                'plan': plan,
                'operator_analysis': operator_analysis
            }
        },
        'total_job_time': 2000
    }
    
    rule = StateTableEnable()
    tree_str = rule._format_subplan_tree(subplan, context)
    
    print(tree_str)
    print()
    
    # 应该能正常处理，只显示存在的算子
    assert 'HashJoin2' in tree_str
    assert 'TableScan1' in tree_str
    
    print("✓ 缺失算子处理测试完成")


if __name__ == '__main__':
    print("测试复杂场景下的 subplan 树形打印...")
    print()
    
    try:
        test_complex_subplan_tree()
        print()
        test_missing_operators()
        
        print()
        print("=" * 60)
        print("所有测试通过! ✓")
        print("=" * 60)
    except AssertionError as e:
        print()
        print("=" * 60)
        print(f"测试失败: {e}")
        print("=" * 60)
        import traceback
        traceback.print_exc()
        sys.exit(1)
    except Exception as e:
        print()
        print("=" * 60)
        print(f"错误: {e}")
        print("=" * 60)
        import traceback
        traceback.print_exc()
        sys.exit(1)
