#!/usr/bin/env python3
"""测试 Job Profiling 分析功能"""
import json
import tempfile
import os
from cz_skills.job_performance_analyzer.core.parser import PlanProfileParser


def test_job_profiling_parsing():
    """测试 Job Profiling 数据解析"""
    
    # 创建测试数据
    profile_data = {
        "data": {
            "jobSummary": {
                "jobProfiling": {
                    "profiling": [
                        {"e": 100, "t": "1769626801341"},  # RECEIVE_SUBMIT
                        {"e": 101, "t": "1769626801341"},  # PRECHECK_START
                        {"e": 102, "t": "1769626801343"},  # PRECHECK_END (2ms)
                        {"e": 103, "t": "1769626801375"},  # JOB_META_CREATED (32ms)
                        {"e": 105, "t": "1769626801375"},  # COORDINATOR_PRE_RUN
                        {"e": 106, "t": "1769626801375"},  # COORDINATOR_RUN
                        {"e": 108, "t": "1769626802297"},  # PLAN_CREATED (922ms)
                        {"e": 110, "t": "1769626802307"},  # SUBMIT_TO_RM
                        {"e": 111, "t": "1769626802310"},  # VC_RUNNING
                        {"e": 112, "t": "1769626802328"},  # RM_APP_CREATED
                        {"e": 120, "t": "1769626802374"},  # GOT_FIRST_RESOURCE (67ms)
                        {"e": 130, "t": "1769627493236"},  # DAG_COMPLETE (690,862ms)
                        {"e": 131, "t": "1769627493485"},  # DATA_COMMIT_START
                        {"e": 150, "t": "1769627499326"},  # RUN_FINISH (5,841ms)
                        {"e": 160, "t": "1769627499326"},  # START_PERSIST
                        {"e": 165, "t": "1769627499931"},  # SUMMARY_UPLOADED (605ms)
                        {"e": 155, "t": "1769627499931"},  # KEY_PATH_END
                    ]
                },
                "stageSummary": {}
            }
        }
    }
    
    # 创建临时文件
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(profile_data, f)
        profile_file = f.name
    
    try:
        # 解析数据
        parser = PlanProfileParser(None, profile_file)
        profiling = parser.get_job_profiling_analysis()
        
        # 验证解析结果
        assert profiling is not None, "Profiling 数据应该被解析"
        assert 'phases' in profiling, "应该包含 phases"
        assert 'durations' in profiling, "应该包含 durations"
        assert 'total_time_sec' in profiling, "应该包含 total_time_sec"
        
        # 验证各阶段耗时
        durations = profiling['durations']
        assert durations['precheck'] == 2, f"预检查耗时应为 2ms，实际为 {durations['precheck']}ms"
        assert durations['meta_creation'] == 32, f"元数据创建耗时应为 32ms，实际为 {durations['meta_creation']}ms"
        assert durations['plan_generation'] == 922, f"执行计划生成耗时应为 922ms，实际为 {durations['plan_generation']}ms"
        assert durations['resource_allocation'] == 67, f"资源申请耗时应为 67ms，实际为 {durations['resource_allocation']}ms"
        assert durations['dag_execution'] == 690862, f"DAG 执行耗时应为 690862ms，实际为 {durations['dag_execution']}ms"
        assert durations['data_commit'] == 5841, f"数据提交耗时应为 5841ms，实际为 {durations['data_commit']}ms"
        assert durations['persistence'] == 605, f"持久化耗时应为 605ms，实际为 {durations['persistence']}ms"
        
        # 验证总耗时
        total_time = profiling['total_time_ms']
        expected_total = 1769627499931 - 1769626801341  # 698590ms
        assert total_time == expected_total, f"总耗时应为 {expected_total}ms，实际为 {total_time}ms"
        
        # 验证阶段信息
        phases = profiling['phases']
        assert len(phases) == 7, f"应该有 7 个阶段，实际有 {len(phases)} 个"
        
        # 验证 DAG 执行阶段占比
        dag_phase = next((p for p in phases if p['name'] == 'DAG执行'), None)
        assert dag_phase is not None, "应该包含 DAG 执行阶段"
        assert dag_phase['percentage'] > 98, f"DAG 执行应占 98% 以上，实际为 {dag_phase['percentage']:.1f}%"
        
        print("✅ Job Profiling 解析测试通过")
        print(f"\n总耗时: {profiling['total_time_sec']:.1f}s")
        print("\n各阶段耗时:")
        for phase in sorted(phases, key=lambda x: x['duration_ms'], reverse=True):
            print(f"  - {phase['name']}: {phase['duration_sec']:.2f}s ({phase['percentage']:.1f}%)")
        
        # 验证瓶颈检测
        bottleneck = profiling.get('bottleneck')
        if bottleneck:
            print(f"\n⚠️ 瓶颈阶段: {bottleneck['name']} ({bottleneck['duration_sec']:.1f}s, {bottleneck['percentage']:.1f}%)")
        
        return True
        
    finally:
        # 清理临时文件
        if os.path.exists(profile_file):
            os.unlink(profile_file)


def test_job_profiling_with_slow_plan_generation():
    """测试执行计划生成较慢的场景"""
    
    profile_data = {
        "data": {
            "jobSummary": {
                "jobProfiling": {
                    "profiling": [
                        {"e": 100, "t": "1000000"},  # RECEIVE_SUBMIT
                        {"e": 106, "t": "1000000"},  # COORDINATOR_RUN
                        {"e": 108, "t": "1005000"},  # PLAN_CREATED (5s - 较慢)
                        {"e": 110, "t": "1005100"},  # SUBMIT_TO_RM
                        {"e": 120, "t": "1005200"},  # GOT_FIRST_RESOURCE
                        {"e": 130, "t": "1015200"},  # DAG_COMPLETE (10s)
                        {"e": 131, "t": "1015300"},  # DATA_COMMIT_START
                        {"e": 150, "t": "1015400"},  # RUN_FINISH
                        {"e": 155, "t": "1015400"},  # KEY_PATH_END
                    ]
                },
                "stageSummary": {}
            }
        }
    }
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(profile_data, f)
        profile_file = f.name
    
    try:
        parser = PlanProfileParser(None, profile_file)
        profiling = parser.get_job_profiling_analysis()
        
        # 验证执行计划生成耗时
        durations = profiling['durations']
        assert durations['plan_generation'] == 5000, "执行计划生成应耗时 5000ms"
        
        # 验证瓶颈检测
        bottleneck = profiling.get('bottleneck')
        assert bottleneck is not None, "应该检测到瓶颈"
        assert bottleneck['name'] == '执行计划生成', f"瓶颈应该是执行计划生成，实际为 {bottleneck['name']}"
        
        print("✅ 执行计划生成慢场景测试通过")
        print(f"   瓶颈: {bottleneck['name']} ({bottleneck['duration_sec']:.1f}s, {bottleneck['percentage']:.1f}%)")
        
        return True
        
    finally:
        if os.path.exists(profile_file):
            os.unlink(profile_file)


def test_job_profiling_with_slow_resource_allocation():
    """测试资源申请较慢的场景"""
    
    profile_data = {
        "data": {
            "jobSummary": {
                "jobProfiling": {
                    "profiling": [
                        {"e": 100, "t": "1000000"},  # RECEIVE_SUBMIT
                        {"e": 106, "t": "1000000"},  # COORDINATOR_RUN
                        {"e": 108, "t": "1000500"},  # PLAN_CREATED (0.5s)
                        {"e": 110, "t": "1000600"},  # SUBMIT_TO_RM
                        {"e": 120, "t": "1010600"},  # GOT_FIRST_RESOURCE (10s - 较慢)
                        {"e": 130, "t": "1020600"},  # DAG_COMPLETE (10s)
                        {"e": 131, "t": "1020700"},  # DATA_COMMIT_START
                        {"e": 150, "t": "1020800"},  # RUN_FINISH
                        {"e": 155, "t": "1020800"},  # KEY_PATH_END
                    ]
                },
                "stageSummary": {}
            }
        }
    }
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(profile_data, f)
        profile_file = f.name
    
    try:
        parser = PlanProfileParser(None, profile_file)
        profiling = parser.get_job_profiling_analysis()
        
        # 验证资源申请耗时
        durations = profiling['durations']
        assert durations['resource_allocation'] == 10000, "资源申请应耗时 10000ms"
        
        # 验证瓶颈检测
        bottleneck = profiling.get('bottleneck')
        assert bottleneck is not None, "应该检测到瓶颈"
        assert bottleneck['name'] == '资源申请', f"瓶颈应该是资源申请，实际为 {bottleneck['name']}"
        
        print("✅ 资源申请慢场景测试通过")
        print(f"   瓶颈: {bottleneck['name']} ({bottleneck['duration_sec']:.1f}s, {bottleneck['percentage']:.1f}%)")
        
        return True
        
    finally:
        if os.path.exists(profile_file):
            os.unlink(profile_file)


if __name__ == '__main__':
    print("=" * 80)
    print("测试 Job Profiling 分析功能")
    print("=" * 80)
    
    test_job_profiling_parsing()
    print()
    test_job_profiling_with_slow_plan_generation()
    print()
    test_job_profiling_with_slow_resource_allocation()
    
    print("\n" + "=" * 80)
    print("所有测试通过 ✅")
    print("=" * 80)
