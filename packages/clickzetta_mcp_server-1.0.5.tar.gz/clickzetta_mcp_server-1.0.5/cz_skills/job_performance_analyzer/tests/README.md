# Job Performance Analyzer 测试集

本目录包含 Job Performance Analyzer 的完整测试集，确保所有功能正常工作。

## 测试结构

### 核心功能测试

1. **test_snapshot_subplan_analysis.py** - Snapshot Subplan 分析测试
   - 基本 snapshot subplan 检测
   - 阈值边界条件测试
   - 复杂依赖关系追踪
   - 骨架信息生成
   - 增量算法策略控制
   - 空数据处理

2. **test_command_line_integration.py** - 命令行集成测试
   - 命令行参数验证
   - `--enable-incremental-algorithm` 参数测试
   - `--enable-state-table` 参数测试
   - 帮助信息验证

3. **test_incremental_algorithm_analyzer.py** - 增量算法分析器测试
   - Delta/Snapshot 类型推断
   - 增量算法识别
   - 依赖关系分析

4. **test_target_operator.py** - 目标算子测试
   - 算子类型识别
   - 性能分析

5. **test_job_conflict_detection.py** - Job 冲突检测测试
   - Stage 级别冲突检测
   - Task 级别冲突检测
   - 多个冲突检测
   - 大小写不敏感检测
   - 空数据处理
   - 错误收集器集成测试

6. **test_optimizer_error_detection.py** - 优化器错误检测测试
   - 未设置 playback 的优化器错误检测
   - 已设置 playback 的优化器错误检测
   - 大小写不敏感检测
   - 多个优化器错误检测
   - 无优化器错误的情况

### 专项功能测试

7. **test_deltastate_pattern.py** - DeltaState 模式测试
8. **test_bidirectional_dfs.py** - 双向 DFS 算法测试
9. **test_path_based_logic.py** - 路径逻辑测试
10. **test_version_utils.py** - 版本工具测试
11. **test_improvements.py** - 改进功能测试
12. **test_incremental_logic.py** - 增量逻辑测试

## 运行测试

### 使用测试运行脚本

```bash
# 运行核心功能测试（推荐）
python run_tests.py --core

# 运行所有测试
python run_tests.py --all

# 只运行 Snapshot Subplan 测试
python run_tests.py --snapshot

# 只运行命令行集成测试
python run_tests.py --cli

# 使用 DEBUG 日志级别运行测试（查看详细分析过程）
python run_tests.py --core --log-level DEBUG
```

### 使用 unittest 直接运行

```bash
# 运行单个测试文件
python -m unittest tests.test_snapshot_subplan_analysis -v

# 运行特定测试类
python -m unittest tests.test_snapshot_subplan_analysis.TestSnapshotSubplanAnalysis -v

# 运行特定测试方法
python -m unittest tests.test_snapshot_subplan_analysis.TestSnapshotSubplanAnalysis.test_basic_snapshot_subplan_detection -v

# 发现并运行所有测试
python -m unittest discover tests -v
```

### 日志级别控制

测试支持日志级别控制，方便调试：

```bash
# 使用 DEBUG 级别查看详细的分析过程
LOG_LEVEL=DEBUG python -m unittest tests.test_snapshot_subplan_analysis -v

# 使用 WARNING 级别只看警告和错误
LOG_LEVEL=WARNING python -m unittest discover tests -v
```

**注意**: 测试默认使用 WARNING 级别以减少输出噪音。如需查看详细的分析过程，请设置 `LOG_LEVEL=DEBUG`。

## 测试覆盖范围

### 错误分析功能

- ✅ **错误收集**: 统一收集 Job/Stage/Task 级别的错误信息
- ✅ **错误去重**: 去除重复的错误信息
- ✅ **错误分类**: 将错误分为冲突、超时、内存等类型
- ✅ **冲突检测**: 识别 Job 提交冲突错误
- ✅ **优化器错误**: 识别优化器内部错误并建议启用 playback
- ✅ **大小写不敏感**: 不区分大小写的错误信息匹配
- ✅ **空数据处理**: 优雅处理缺失 profile 数据的情况
- ✅ **参数检查**: 检查是否已设置相关参数，避免重复推荐

### Snapshot Subplan 分析功能

- ✅ **基本检测**: 识别超过15%阈值的 snapshot subplan
- ✅ **依赖追踪**: 正确追踪算子依赖关系，构建完整 subplan
- ✅ **骨架生成**: 生成有意义的 subplan 骨架信息
- ✅ **阈值测试**: 边界条件测试（15%阈值）
- ✅ **策略控制**: 增量算法策略的启用/禁用控制
- ✅ **空数据处理**: 优雅处理缺失数据的情况

### 命令行集成

- ✅ **参数解析**: `--enable-incremental-algorithm` 和 `--enable-state-table` 参数
- ✅ **帮助信息**: 完整的命令行帮助
- ✅ **错误处理**: 文件不存在、参数缺失等错误情况
- ✅ **功能验证**: 参数正确传递到分析逻辑

### 核心算法

- ✅ **增量算法识别**: 正确识别各种增量算法模式
- ✅ **数据类型推断**: Delta/Snapshot 类型传播
- ✅ **性能分析**: 算子性能统计和瓶颈识别

## 测试数据

测试使用模拟的真实场景数据：

- **复杂客户分析作业**: 包含大表扫描、复杂聚合、维度Join、窗口函数等
- **增量数据处理**: 模拟 delta 和 snapshot 数据混合场景
- **性能数据**: 真实的耗时分布和资源使用情况

## 预期结果验证

每个测试都验证以下关键指标：

1. **功能正确性**: 算法逻辑是否正确
2. **性能阈值**: 是否正确识别超过15%的 subplan
3. **建议生成**: 是否生成正确的优化建议
4. **错误处理**: 异常情况的优雅处理

## 持续集成

这些测试应该在以下情况下运行：

- 代码提交前
- 功能开发完成后
- 发布前验证
- 定期回归测试

## 故障排除

如果测试失败，请检查：

1. **依赖项**: 确保所有必要的 Python 模块已安装
2. **路径问题**: 确保在正确的目录下运行测试
3. **数据格式**: 测试数据是否符合预期格式
4. **版本兼容性**: Python 版本是否兼容
5. **日志输出**: 使用 `LOG_LEVEL=DEBUG` 查看详细的分析过程，帮助定位问题

### 调试技巧

```bash
# 查看特定算法的分析过程
LOG_LEVEL=DEBUG python -m unittest tests.test_incremental_algorithm_analyzer -v 2>&1 | grep "算法"

# 查看边界检查过程
LOG_LEVEL=DEBUG python -m unittest tests.test_incremental_algorithm_analyzer -v 2>&1 | grep "边界"

# 保存完整日志到文件
LOG_LEVEL=DEBUG python -m unittest discover tests -v > test.log 2>&1
```

## 添加新测试

添加新测试时，请遵循以下规范：

1. **命名规范**: 测试文件以 `test_` 开头
2. **文档说明**: 每个测试方法包含清晰的文档字符串
3. **断言验证**: 使用适当的断言验证预期结果
4. **数据清理**: 测试后清理临时文件和数据
5. **独立性**: 测试之间应该相互独立，不依赖执行顺序


## TableSink DOP 规则测试（新增）

### test_tablesink_dop_fix.py

单元测试，验证 TableSink DOP 规则的核心修复：

1. **Stage 依赖关系解析** - 验证通过 `inputIds` 正确解析上游 stage
2. **使用 Plan DOP** - 验证规则使用 plan 中的 DOP 而不是 profile 中的 task count
3. **DOP 差异阈值** - 验证当 DOP 差异不大时不触发规则
4. **自引用排除** - 验证依赖关系解析时正确排除自己

运行方式：
```bash
python3 tests/test_tablesink_dop_fix.py
```

### test_tablesink_dop_integration.py

集成测试，使用真实数据结构验证完整流程：

1. **真实数据结构测试** - 使用完整的 plan.json 和 job_profile.json 结构
2. **无误报测试** - 验证 DOP 正常时不会误报

运行方式：
```bash
python3 tests/test_tablesink_dop_integration.py
```

### 测试覆盖的修复

#### 1. Stage 依赖关系解析修复
- **问题**：`StageAligner._parse_stage_dependencies()` 无法通过 `inputIds` 解析上游 stage
- **修复**：添加了通过 `operators.inputIds` 推断上游 stage 的逻辑
- **测试**：`test_stage_dependency_parsing()`

#### 2. TableSink DOP 规则修复
- **问题**：规则使用 profile 中的实际 task count 而不是 plan 中的 DOP
- **修复**：改为使用 plan 中的 DOP 进行比较
- **测试**：`test_tablesink_dop_uses_plan_dop()`

#### 3. 日志支持
- **添加**：完整的 DEBUG/INFO/WARNING 日志支持
- **测试**：通过 `--log-level` 参数验证

### 调试 TableSink DOP 规则

使用 DEBUG 日志级别查看详细信息：

```bash
python3 -m analyze_job plan.json job_profile.json --log-level DEBUG 2>&1 | grep tablesink_dop
```

这将显示：
- 上游 stage 列表
- 当前和上游的 DOP 值
- DOP ratio 计算
- 是否触发规则的判断逻辑
