#!/usr/bin/env python3
"""
测试 Job 冲突检测规则
"""
import unittest
import sys
import os

script_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))

from cz_skills.job_performance_analyzer.rules.common import ErrorMessageCollector, JobConflictDetection


class TestErrorMessageCollector(unittest.TestCase):
    """测试错误信息收集器"""
    
    def setUp(self):
        """初始化测试"""
        self.rule = ErrorMessageCollector()
    
    def test_collect_job_status_error(self):
        """测试收集 Job Status 级别的错误"""
        context = {
            'has_profile': True,
            'raw_profile': {
                'jobStatus': {
                    'message': 'Error: this job has conflicts with another concurrent job'
                }
            },
            'aligned_stages': {}
        }
        
        result = self.rule.analyze_global(context)
        
        self.assertIn('error_messages', result)
        self.assertEqual(len(result['error_messages']), 1)
        self.assertEqual(result['error_messages'][0]['location'], 'job_status')
    
    def test_collect_stage_error(self):
        """测试收集 Stage 级别的错误"""
        context = {
            'has_profile': True,
            'raw_profile': {},
            'aligned_stages': {
                'stage_1': {
                    'profile': {
                        'message': 'Error: stage failed'
                    }
                }
            }
        }
        
        result = self.rule.analyze_global(context)
        
        self.assertEqual(len(result['error_messages']), 1)
        self.assertEqual(result['error_messages'][0]['location'], 'stage')
        self.assertEqual(result['error_messages'][0]['stage_id'], 'stage_1')
    
    def test_collect_task_error(self):
        """测试收集 Task 级别的错误"""
        context = {
            'has_profile': True,
            'raw_profile': {},
            'aligned_stages': {
                'stage_1': {
                    'profile': {
                        'taskSummary': {
                            'task_001': {
                                'message': 'Error: task failed'
                            }
                        }
                    }
                }
            }
        }
        
        result = self.rule.analyze_global(context)
        
        self.assertEqual(len(result['error_messages']), 1)
        self.assertEqual(result['error_messages'][0]['location'], 'task')
        self.assertEqual(result['error_messages'][0]['task_id'], 'task_001')
    
    def test_deduplicate_errors(self):
        """测试错误去重"""
        context = {
            'has_profile': True,
            'raw_profile': {},
            'aligned_stages': {
                'stage_1': {
                    'profile': {
                        'message': 'Error: duplicate error'
                    }
                },
                'stage_2': {
                    'profile': {
                        'message': 'Error: duplicate error'  # 相同的错误
                    }
                }
            }
        }
        
        result = self.rule.analyze_global(context)
        
        # 应该去重，只保留一个
        self.assertEqual(len(result['error_messages']), 1)
    
    def test_filter_non_error_messages(self):
        """测试过滤非错误信息"""
        context = {
            'has_profile': True,
            'raw_profile': {},
            'aligned_stages': {
                'stage_1': {
                    'profile': {
                        'message': 'Success'  # 不是错误信息
                    }
                }
            }
        }
        
        result = self.rule.analyze_global(context)
        
        self.assertEqual(len(result['error_messages']), 0)


class TestJobConflictDetection(unittest.TestCase):
    """测试 Job 冲突检测规则"""
    
    def setUp(self):
        """初始化测试"""
        self.collector = ErrorMessageCollector()
        self.rule = JobConflictDetection()
    
    def test_detect_conflict_from_collected_errors(self):
        """测试从收集的错误中检测冲突"""
        # 先收集错误
        context = {
            'has_profile': True,
            'raw_profile': {
                'jobStatus': {
                    'message': 'Conflict: this job has conflicts with another concurrent job which updates table xyz'
                }
            },
            'aligned_stages': {}
        }
        
        # 收集错误信息
        collector_result = self.collector.analyze_global(context)
        context['error_messages'] = collector_result.get('error_messages', [])
        
        # 检测冲突
        result = self.rule.analyze_global(context)
        
        self.assertEqual(len(result['findings']), 1)
        self.assertEqual(result['findings'][0]['type'], 'job_conflict_error')
        self.assertEqual(len(result['recommendations']), 1)
        self.assertEqual(result['recommendations'][0]['type'], 'rerun_job')
    
    def test_no_conflict_when_no_errors(self):
        """测试没有错误时不检测到冲突"""
        context = {
            'has_profile': True,
            'error_messages': []
        }
        
        result = self.rule.analyze_global(context)
        
        self.assertEqual(len(result['findings']), 0)
        self.assertEqual(len(result['recommendations']), 0)
    
    def test_no_conflict_when_other_errors(self):
        """测试其他错误不触发冲突检测"""
        context = {
            'has_profile': True,
            'error_messages': [
                {
                    'location': 'job_status',
                    'message': 'Error: timeout occurred',
                    'refined_message': 'Error: timeout occurred'
                }
            ]
        }
        
        result = self.rule.analyze_global(context)
        
        self.assertEqual(len(result['findings']), 0)


if __name__ == '__main__':
    unittest.main()
