#!/usr/bin/env python3
"""
测试空 plan.json 文件处理

测试当优化器错误导致 plan.json 为空或不存在时，
系统能够正确处理并从 profile 中提取必要信息。
"""
import unittest
import json
import tempfile
import os
from cz_skills.job_performance_analyzer.core.parser import PlanProfileParser


class TestEmptyPlanHandling(unittest.TestCase):
    """测试空 plan.json 文件处理"""
    
    def setUp(self):
        """设置测试环境"""
        self.temp_dir = tempfile.mkdtemp()
    
    def tearDown(self):
        """清理测试环境"""
        import shutil
        shutil.rmtree(self.temp_dir)
    
    def test_empty_plan_file(self):
        """测试空的 plan.json 文件"""
        # 创建空的 plan.json
        plan_file = os.path.join(self.temp_dir, 'plan.json')
        with open(plan_file, 'w') as f:
            f.write('')
        
        # 创建包含错误信息的 profile
        profile_file = os.path.join(self.temp_dir, 'job_profile.json')
        profile_data = {
            'data': {
                'jobDesc': {
                    'sqlJob': {
                        'query': ['REFRESH dynamic table test_table;'],
                        'sqlConfig': {
                            'hint': {
                                'cz.sql.playback.scratch': 'true',
                                'schedule_task_id': '10001004'
                            }
                        }
                    }
                },
                'jobStatus': {
                    'state': 'FAILED',
                    'message': '{"errors":[{"category":"Optimizer internal error","col":1,"errorCode":"CZLH-66000","line":13,"message":"optimizer failed to process"}],"warnings":[]}'
                },
                'jobSummary': {
                    'stageSummary': {}
                }
            }
        }
        with open(profile_file, 'w') as f:
            json.dump(profile_data, f)
        
        # 解析文件
        parser = PlanProfileParser(plan_file, profile_file)
        self.assertFalse(parser.has_plan, "空 plan 文件应该标记为无效")
        self.assertTrue(parser.has_profile, "包含错误信息的 profile 应该标记为有效")
        
        # 解析数据
        context = parser.parse()
        
        # 验证从 profile 中提取了设置
        self.assertIn('settings', context)
        self.assertEqual(context['settings'].get('cz.sql.playback.scratch'), 'true')
        self.assertEqual(len(context['settings']), 2)
        
        # 验证 SQL 信息
        self.assertTrue(context['sql_info']['is_refresh'])
        self.assertIn('REFRESH', context['sql_info']['text'])
        
        # 验证标志位
        self.assertFalse(context['has_plan'])
        self.assertTrue(context['has_profile'])
        
        # 验证原始 profile 数据
        self.assertIn('raw_profile', context)
        self.assertIn('jobStatus', context['raw_profile'])
    
    def test_missing_plan_file(self):
        """测试不存在的 plan.json 文件"""
        plan_file = os.path.join(self.temp_dir, 'nonexistent_plan.json')
        
        # 创建包含错误信息的 profile
        profile_file = os.path.join(self.temp_dir, 'job_profile.json')
        profile_data = {
            'data': {
                'jobDesc': {
                    'sqlJob': {
                        'query': ['SELECT * FROM test;'],
                        'sqlConfig': {
                            'hint': {
                                'cz.sql.adhoc.result.type': 'embedded'
                            }
                        }
                    }
                },
                'jobStatus': {
                    'state': 'FAILED',
                    'message': 'Optimizer internal error: test error'
                },
                'jobSummary': {
                    'stageSummary': {}
                }
            }
        }
        with open(profile_file, 'w') as f:
            json.dump(profile_data, f)
        
        # 解析文件
        parser = PlanProfileParser(plan_file, profile_file)
        self.assertFalse(parser.has_plan)
        self.assertTrue(parser.has_profile)
        
        # 解析数据应该成功
        context = parser.parse()
        self.assertIsNotNone(context)
        self.assertFalse(context['has_plan'])
        self.assertTrue(context['has_profile'])
    
    def test_profile_with_json_error_message(self):
        """测试 JSON 格式的错误消息"""
        plan_file = os.path.join(self.temp_dir, 'plan.json')
        with open(plan_file, 'w') as f:
            f.write('')
        
        profile_file = os.path.join(self.temp_dir, 'job_profile.json')
        profile_data = {
            'data': {
                'jobDesc': {
                    'sqlJob': {
                        'query': ['REFRESH dynamic table test;'],
                        'sqlConfig': {
                            'hint': {}
                        }
                    }
                },
                'jobStatus': {
                    'state': 'FAILED',
                    'message': '{"errors":[{"category":"Optimizer internal error","col":1,"errorCode":"CZLH-66000","line":13,"message":"row count got nan"}],"warnings":[]}'
                },
                'jobSummary': {
                    'stageSummary': {}
                }
            }
        }
        with open(profile_file, 'w') as f:
            json.dump(profile_data, f)
        
        parser = PlanProfileParser(plan_file, profile_file)
        self.assertTrue(parser.has_profile, "包含 JSON 错误消息的 profile 应该有效")
        
        context = parser.parse()
        self.assertIn('raw_profile', context)
        
        # 验证错误消息可以被访问
        job_status = context['raw_profile'].get('jobStatus', {})
        self.assertIn('message', job_status)
        self.assertIn('errors', job_status['message'])
    
    def test_profile_without_stage_summary(self):
        """测试没有 stageSummary 但有错误信息的 profile"""
        plan_file = os.path.join(self.temp_dir, 'plan.json')
        with open(plan_file, 'w') as f:
            json.dump({'settings': {}}, f)
        
        profile_file = os.path.join(self.temp_dir, 'job_profile.json')
        profile_data = {
            'data': {
                'jobDesc': {
                    'sqlJob': {
                        'query': ['SELECT 1;'],
                        'sqlConfig': {
                            'hint': {
                                'test_param': 'test_value'
                            }
                        }
                    }
                },
                'jobStatus': {
                    'state': 'FAILED',
                    'message': 'Some error occurred'
                },
                'jobSummary': {}  # 没有 stageSummary
            }
        }
        with open(profile_file, 'w') as f:
            json.dump(profile_data, f)
        
        parser = PlanProfileParser(plan_file, profile_file)
        self.assertTrue(parser.has_profile, "有错误信息的 profile 应该有效，即使没有 stageSummary")
    
    def test_settings_extraction_priority(self):
        """测试设置提取的优先级：plan > profile"""
        # 创建有设置的 plan
        plan_file = os.path.join(self.temp_dir, 'plan.json')
        plan_data = {
            'settings': {
                'cz.sql.text': 'SELECT * FROM plan_table;',
                'param_from_plan': 'plan_value'
            }
        }
        with open(plan_file, 'w') as f:
            json.dump(plan_data, f)
        
        # 创建有不同设置的 profile
        profile_file = os.path.join(self.temp_dir, 'job_profile.json')
        profile_data = {
            'data': {
                'jobDesc': {
                    'sqlJob': {
                        'query': ['SELECT * FROM profile_table;'],
                        'sqlConfig': {
                            'hint': {
                                'param_from_profile': 'profile_value'
                            }
                        }
                    }
                },
                'jobSummary': {
                    'stageSummary': {
                        'stage1': {}
                    }
                }
            }
        }
        with open(profile_file, 'w') as f:
            json.dump(profile_data, f)
        
        parser = PlanProfileParser(plan_file, profile_file)
        context = parser.parse()
        
        # 应该使用 plan 中的设置
        self.assertIn('param_from_plan', context['settings'])
        self.assertNotIn('param_from_profile', context['settings'])
        self.assertIn('plan_table', context['sql_info']['text'])


if __name__ == '__main__':
    unittest.main()
