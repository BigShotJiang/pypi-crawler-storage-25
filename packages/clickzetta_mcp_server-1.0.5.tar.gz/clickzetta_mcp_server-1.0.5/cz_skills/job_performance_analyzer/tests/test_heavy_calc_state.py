#!/usr/bin/env python3
"""测试 Calc 状态优化规则"""
import unittest
from cz_skills.job_performance_analyzer.rules.incremental.state_table.heavy_calc_state import HeavyCalcState


class TestHeavyCalcState(unittest.TestCase):
    def setUp(self):
        self.rule = HeavyCalcState()
        self.context = {
            'has_profile': True,
            'settings': {},
            'total_job_time': 100000,  # 100秒
            'operator_analysis': [],
            'operator_data_types': {}
        }

    def test_calc_snapshot_high_percentage(self):
        """测试：Calc 是 SNAPSHOT 状态，占比高，应该给出建议"""
        # 构造数据
        stage_data = {
            'stage_id': 'stg1',
            'plan': {'operators': []},
            'metrics': {
                'elapsed_ms': 20000,  # 20秒，占总耗时 20%
            }
        }
        
        # Calc 耗时 8秒，占 stage 40%
        self.context['operator_analysis'] = [
            {
                'stage_id': 'stg1',
                'operator_id': 'Calc100',
                'elapsed_ms': 8000,
                'stage_pct': 40.0
            }
        ]
        
        # Calc 是 SNAPSHOT 状态
        self.context['operator_data_types'] = {
            'Calc100': 'SNAPSHOT'  # 支持大写
        }
        
        result = self.rule.analyze(stage_data, self.context)
        
        # 应该有 finding
        self.assertGreater(len(result['findings']), 0)
        finding = result['findings'][0]
        self.assertEqual(finding['type'], 'HEAVY_CALC')
        self.assertIn('8.0s', finding['description'])
        self.assertIn('40.0%', finding['description'])
        self.assertIn('20.0%', finding['description'])
        
        # 应该有 recommendation
        self.assertGreater(len(result['recommendations']), 0)
        rec = result['recommendations'][0]
        self.assertEqual(rec['setting'], 'cz.optimizer.incremental.create.rule.based.table.on.heavy.calc')
        self.assertEqual(rec['value'], 'true')
        
        # 应该有 insight
        self.assertGreater(len(result['insights']), 0)
        insight = result['insights'][0]
        self.assertIn('Calc100', insight['message'])
        self.assertIn('8.0s', insight['message'])
        self.assertIn('40.0%', insight['message'])

    def test_calc_delta_should_skip(self):
        """测试：Calc 是 DELTA 状态，应该跳过"""
        stage_data = {
            'stage_id': 'stg1',
            'plan': {'operators': []},
            'metrics': {
                'elapsed_ms': 20000,
            }
        }
        
        self.context['operator_analysis'] = [
            {
                'stage_id': 'stg1',
                'operator_id': 'Calc100',
                'elapsed_ms': 8000,
                'stage_pct': 40.0
            }
        ]
        
        # Calc 是 DELTA 状态，应该跳过
        self.context['operator_data_types'] = {
            'Calc100': 'DELTA'
        }
        
        result = self.rule.analyze(stage_data, self.context)
        
        # 不应该有任何输出
        self.assertEqual(len(result['findings']), 0)
        self.assertEqual(len(result['recommendations']), 0)
        self.assertEqual(len(result['insights']), 0)

    def test_calc_unknown_should_skip(self):
        """测试：Calc 是 UNKNOWN 状态，应该跳过"""
        stage_data = {
            'stage_id': 'stg1',
            'plan': {'operators': []},
            'metrics': {
                'elapsed_ms': 20000,
            }
        }
        
        self.context['operator_analysis'] = [
            {
                'stage_id': 'stg1',
                'operator_id': 'Calc100',
                'elapsed_ms': 8000,
                'stage_pct': 40.0
            }
        ]
        
        # Calc 是 UNKNOWN 状态，应该跳过
        self.context['operator_data_types'] = {
            'Calc100': 'UNKNOWN'
        }
        
        result = self.rule.analyze(stage_data, self.context)
        
        # 不应该有任何输出
        self.assertEqual(len(result['findings']), 0)
        self.assertEqual(len(result['recommendations']), 0)
        self.assertEqual(len(result['insights']), 0)

    def test_calc_low_percentage_should_skip(self):
        """测试：Calc 占比低（< 30%），应该跳过"""
        stage_data = {
            'stage_id': 'stg1',
            'plan': {'operators': []},
            'metrics': {
                'elapsed_ms': 20000,
            }
        }
        
        self.context['operator_analysis'] = [
            {
                'stage_id': 'stg1',
                'operator_id': 'Calc100',
                'elapsed_ms': 4000,
                'stage_pct': 20.0  # < 30%
            }
        ]
        
        self.context['operator_data_types'] = {
            'Calc100': 'SNAPSHOT'
        }
        
        result = self.rule.analyze(stage_data, self.context)
        
        # 不应该有任何输出
        self.assertEqual(len(result['findings']), 0)
        self.assertEqual(len(result['recommendations']), 0)
        self.assertEqual(len(result['insights']), 0)

    def test_stage_low_percentage_should_skip(self):
        """测试：Stage 占整体比例低（< 10%），应该跳过"""
        stage_data = {
            'stage_id': 'stg1',
            'plan': {'operators': []},
            'metrics': {
                'elapsed_ms': 5000,  # 5秒，占总耗时 5% < 10%
            }
        }
        
        self.context['operator_analysis'] = [
            {
                'stage_id': 'stg1',
                'operator_id': 'Calc100',
                'elapsed_ms': 2000,
                'stage_pct': 40.0  # 占 stage 40%，但 stage 占整体只有 5%
            }
        ]
        
        self.context['operator_data_types'] = {
            'Calc100': 'SNAPSHOT'
        }
        
        result = self.rule.analyze(stage_data, self.context)
        
        # 不应该有任何输出
        self.assertEqual(len(result['findings']), 0)
        self.assertEqual(len(result['recommendations']), 0)
        self.assertEqual(len(result['insights']), 0)

    def test_with_udf_should_have_high_priority(self):
        """测试：包含 UDF 的 Calc 应该有更高优先级"""
        stage_data = {
            'stage_id': 'stg1',
            'plan': {
                'operators': [
                    {
                        'id': 'Calc100',
                        'calc': {
                            'expressions': [
                                {'function': {'name': 'my_udf'}}
                            ]
                        }
                    }
                ]
            },
            'metrics': {
                'elapsed_ms': 20000,
            }
        }
        
        self.context['operator_analysis'] = [
            {
                'stage_id': 'stg1',
                'operator_id': 'Calc100',
                'elapsed_ms': 8000,
                'stage_pct': 40.0
            }
        ]
        
        self.context['operator_data_types'] = {
            'Calc100': 'SNAPSHOT'
        }
        
        result = self.rule.analyze(stage_data, self.context)
        
        # 应该有 HIGH 优先级
        self.assertGreater(len(result['findings']), 0)
        finding = result['findings'][0]
        self.assertEqual(finding['severity'], 'HIGH')
        
        self.assertGreater(len(result['recommendations']), 0)
        rec = result['recommendations'][0]
        self.assertEqual(rec['priority'], 2)  # UDF 优先级更高
        self.assertEqual(rec['impact'], 'HIGH')

    def test_lowercase_snapshot_should_work(self):
        """测试：小写的 snapshot 也应该被识别"""
        stage_data = {
            'stage_id': 'stg1',
            'plan': {'operators': []},
            'metrics': {
                'elapsed_ms': 20000,
            }
        }
        
        self.context['operator_analysis'] = [
            {
                'stage_id': 'stg1',
                'operator_id': 'Calc100',
                'elapsed_ms': 8000,
                'stage_pct': 40.0
            }
        ]
        
        # 小写的 snapshot
        self.context['operator_data_types'] = {
            'Calc100': 'snapshot'
        }
        
        result = self.rule.analyze(stage_data, self.context)
        
        # 应该有输出
        self.assertGreater(len(result['findings']), 0)
        self.assertGreater(len(result['recommendations']), 0)
        self.assertGreater(len(result['insights']), 0)


if __name__ == '__main__':
    unittest.main()
