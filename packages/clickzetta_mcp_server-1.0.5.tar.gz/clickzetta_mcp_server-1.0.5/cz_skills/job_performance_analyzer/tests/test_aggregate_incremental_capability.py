#!/usr/bin/env python3
"""测试聚合增量能力判断逻辑"""
import sys
import os

# 添加项目根目录到 Python 路径
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))

from cz_skills.job_performance_analyzer.rules.incremental.state_table.aggregate_reuse import AggregateReuse


def test_aggregate_incremental_capability():
    """测试聚合增量能力判断"""
    print("=" * 80)
    print("测试: 聚合增量能力判断")
    print("=" * 80)
    
    rule = AggregateReuse()
    
    # 测试用例 1: 只有 SUM/COUNT，可以无条件做增量
    print("\n测试 1: 只有 SUM/COUNT")
    agg_funcs = ['SUM', 'COUNT']
    can_always, can_append_only, blocking = rule._check_aggregate_incremental_capability(
        agg_funcs, is_append_only=False
    )
    print(f"  函数: {agg_funcs}")
    print(f"  append-only: False")
    print(f"  结果: can_always={can_always}, can_append_only={can_append_only}, blocking={blocking}")
    print(f"  预期: can_always=True, can_append_only=False, blocking=[]")
    test1_pass = can_always and not can_append_only and not blocking
    print(f"  {'✓ 通过' if test1_pass else '✗ 失败'}")
    
    # 测试用例 2: 只有 MIN/MAX，非 append-only，不能做增量
    print("\n测试 2: 只有 MIN/MAX，非 append-only")
    agg_funcs = ['MIN', 'MAX']
    can_always, can_append_only, blocking = rule._check_aggregate_incremental_capability(
        agg_funcs, is_append_only=False
    )
    print(f"  函数: {agg_funcs}")
    print(f"  append-only: False")
    print(f"  结果: can_always={can_always}, can_append_only={can_append_only}, blocking={blocking}")
    print(f"  预期: can_always=False, can_append_only=False, blocking=['MIN', 'MAX']")
    test2_pass = not can_always and not can_append_only and set(blocking) == {'MIN', 'MAX'}
    print(f"  {'✓ 通过' if test2_pass else '✗ 失败'}")
    
    # 测试用例 3: 只有 MIN/MAX，append-only，可以做增量
    print("\n测试 3: 只有 MIN/MAX，append-only")
    agg_funcs = ['MIN', 'MAX']
    can_always, can_append_only, blocking = rule._check_aggregate_incremental_capability(
        agg_funcs, is_append_only=True
    )
    print(f"  函数: {agg_funcs}")
    print(f"  append-only: True")
    print(f"  结果: can_always={can_always}, can_append_only={can_append_only}, blocking={blocking}")
    print(f"  预期: can_always=False, can_append_only=True, blocking=[]")
    test3_pass = not can_always and can_append_only and not blocking
    print(f"  {'✓ 通过' if test3_pass else '✗ 失败'}")
    
    # 测试用例 4: SUM + MIN，非 append-only，不能做增量（被 MIN 拖累）
    print("\n测试 4: SUM + MIN，非 append-only（关键测试）")
    agg_funcs = ['SUM', 'MIN']
    can_always, can_append_only, blocking = rule._check_aggregate_incremental_capability(
        agg_funcs, is_append_only=False
    )
    print(f"  函数: {agg_funcs}")
    print(f"  append-only: False")
    print(f"  结果: can_always={can_always}, can_append_only={can_append_only}, blocking={blocking}")
    print(f"  预期: can_always=False, can_append_only=False, blocking=['MIN']")
    print(f"  说明: 即使 SUM 能做增量，但 MIN 不能，整个聚合就不能做增量")
    test4_pass = not can_always and not can_append_only and 'MIN' in blocking
    print(f"  {'✓ 通过' if test4_pass else '✗ 失败'}")
    
    # 测试用例 5: SUM + MIN，append-only，可以做增量
    print("\n测试 5: SUM + MIN，append-only")
    agg_funcs = ['SUM', 'MIN']
    can_always, can_append_only, blocking = rule._check_aggregate_incremental_capability(
        agg_funcs, is_append_only=True
    )
    print(f"  函数: {agg_funcs}")
    print(f"  append-only: True")
    print(f"  结果: can_always={can_always}, can_append_only={can_append_only}, blocking={blocking}")
    print(f"  预期: can_always=True, can_append_only=False, blocking=[]")
    print(f"  说明: append-only 场景下，MIN 也能做增量，所以整个聚合可以做增量")
    test5_pass = can_always and not can_append_only and not blocking
    print(f"  {'✓ 通过' if test5_pass else '✗ 失败'}")
    
    # 测试用例 6: SUM + AVG（不支持的函数），不能做增量
    print("\n测试 6: SUM + AVG（不支持的函数）")
    agg_funcs = ['SUM', 'AVG']
    can_always, can_append_only, blocking = rule._check_aggregate_incremental_capability(
        agg_funcs, is_append_only=True
    )
    print(f"  函数: {agg_funcs}")
    print(f"  append-only: True")
    print(f"  结果: can_always={can_always}, can_append_only={can_append_only}, blocking={blocking}")
    print(f"  预期: can_always=False, can_append_only=False, blocking=['AVG']")
    print(f"  说明: 即使 SUM 能做增量，但 AVG 不支持，整个聚合就不能做增量")
    test6_pass = not can_always and not can_append_only and 'AVG' in blocking
    print(f"  {'✓ 通过' if test6_pass else '✗ 失败'}")
    
    # 测试用例 7: COUNT + MAX + MIN，非 append-only，不能做增量
    print("\n测试 7: COUNT + MAX + MIN，非 append-only")
    agg_funcs = ['COUNT', 'MAX', 'MIN']
    can_always, can_append_only, blocking = rule._check_aggregate_incremental_capability(
        agg_funcs, is_append_only=False
    )
    print(f"  函数: {agg_funcs}")
    print(f"  append-only: False")
    print(f"  结果: can_always={can_always}, can_append_only={can_append_only}, blocking={blocking}")
    print(f"  预期: can_always=False, can_append_only=False, blocking=['MAX', 'MIN']")
    print(f"  说明: 即使 COUNT 能做增量，但 MAX/MIN 不能，整个聚合就不能做增量")
    test7_pass = not can_always and not can_append_only and set(blocking) == {'MAX', 'MIN'}
    print(f"  {'✓ 通过' if test7_pass else '✗ 失败'}")
    
    print("\n" + "=" * 80)
    print("测试总结")
    print("=" * 80)
    all_pass = all([test1_pass, test2_pass, test3_pass, test4_pass, test5_pass, test6_pass, test7_pass])
    
    if all_pass:
        print("✓ 所有测试通过！")
        print("\n关键验证:")
        print("  ✓ 聚合的增量能力取决于最弱的函数")
        print("  ✓ SUM + MIN（非 append-only）不能做增量")
        print("  ✓ SUM + MIN（append-only）可以做增量")
        return 0
    else:
        print("✗ 部分测试失败")
        return 1


if __name__ == '__main__':
    sys.exit(test_aggregate_incremental_capability())
