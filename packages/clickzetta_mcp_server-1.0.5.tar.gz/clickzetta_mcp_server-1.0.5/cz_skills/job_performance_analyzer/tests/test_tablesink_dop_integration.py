#!/usr/bin/env python3
"""TableSink DOP 规则集成测试 - 使用真实数据"""
import sys
import os
import json
import tempfile

# 添加脚本目录到路径
script_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(script_dir)
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))


def create_test_plan_data():
    """创建测试用的 plan 数据"""
    return {
        "settings": {
            "cz.sql.enable.dag.auto.adaptive.split.size": "true"
        },
        "statements": [],
        "dml": {
            "stages": [
                {
                    "id": "stg55",
                    "dop": "2048",
                    "operators": [
                        {"id": "ShuffleRead8", "inputIds": []},
                        {"id": "HashJoin7", "inputIds": ["ShuffleRead8"]},
                        {"id": "TableSink532", "inputIds": ["HashJoin7"]}
                    ]
                },
                {
                    "id": "stg56",
                    "dop": "73",
                    "operators": [
                        {"id": "ShuffleRead3", "inputIds": ["TableSink532"]},
                        {"id": "LocalSort0", "inputIds": ["ShuffleRead3"]},
                        {"id": "TableSink1", "inputIds": ["LocalSort0"]}
                    ]
                }
            ]
        },
        "userId": "test_user"
    }


def create_test_profile_data():
    """创建测试用的 profile 数据"""
    return {
        "code": 0,
        "success": True,
        "message": "success",
        "data": {
            "jobSummary": {
                "stageSummary": {
                    "stg55": {
                        "stageId": "stg55",
                        "startTime": "1000000",
                        "endTime": "1062000",
                        "taskCount": 51,
                        "taskCountDetail": {"SUCCEED": 51.0},
                        "inputOutputStats": {},
                        "operatorSummary": {}
                    },
                    "stg56": {
                        "stageId": "stg56",
                        "startTime": "1062000",
                        "endTime": "1200000",  # 增加耗时以满足 10% 阈值 (138秒 / 200秒 = 69%)
                        "taskCount": 73,
                        "taskCountDetail": {"SUCCEED": 73.0},
                        "inputOutputStats": {},
                        "operatorSummary": {
                            "TableSink1": {
                                "wallTimeNs": {
                                    "max": 7570000000,
                                    "avg": 1000000000
                                }
                            }
                        }
                    }
                }
            }
        }
    }


def test_integration_with_real_data_structure():
    """集成测试：使用真实数据结构"""
    print("集成测试: 使用真实数据结构")
    
    from analyze_job import analyze_job
    
    # 创建临时文件
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as plan_file:
        json.dump(create_test_plan_data(), plan_file)
        plan_path = plan_file.name
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as profile_file:
        json.dump(create_test_profile_data(), profile_file)
        profile_path = profile_file.name
    
    try:
        # 运行分析
        result = analyze_job(
            plan_file=plan_path,
            profile_file=profile_path,
            output_dir=tempfile.gettempdir(),
            log_level='WARNING'  # 减少日志输出
        )
        
        # 验证结果
        findings = result.get('findings', [])
        recommendations = result.get('recommendations', [])
        
        # 查找 TABLESINK_DOP 类型的 finding
        tablesink_findings = [f for f in findings if f.get('type') == 'TABLESINK_DOP']
        
        if not tablesink_findings:
            print("  ✗ 没有发现 TABLESINK_DOP 问题")
            return False
        
        finding = tablesink_findings[0]
        details = finding.get('details', {})
        
        # 验证关键信息
        if details.get('current_dop') != 73:
            print(f"  ✗ current_dop 错误: {details.get('current_dop')}")
            return False
        
        if details.get('max_upstream_dop') != 2048:
            print(f"  ✗ max_upstream_dop 错误: {details.get('max_upstream_dop')}")
            return False
        
        # 验证参数建议
        adaptive_split_recommendations = [
            r for r in recommendations 
            if r.get('setting') == 'cz.sql.enable.dag.auto.adaptive.split.size'  # 使用 'setting'
        ]
        
        if not adaptive_split_recommendations:
            print(f"  ✗ 没有生成参数建议 (recommendations: {recommendations})")
            return False
        
        rec = adaptive_split_recommendations[0]
        if rec.get('value') != 'false':
            print(f"  ✗ 推荐值错误: {rec.get('value')}")
            return False
        
        print("  ✓ 集成测试通过")
        print(f"    - 发现 {len(tablesink_findings)} 个 TABLESINK_DOP 问题")
        print(f"    - 生成 {len(adaptive_split_recommendations)} 条参数建议")
        print(f"    - DOP: {details.get('current_dop')} -> {details.get('max_upstream_dop')} (ratio={details.get('dop_ratio'):.4f})")
        return True
        
    finally:
        # 清理临时文件
        os.unlink(plan_path)
        os.unlink(profile_path)


def test_integration_no_false_positive():
    """集成测试：确保不会误报"""
    print("\n集成测试: 确保不会误报（DOP 正常的情况）")
    
    from analyze_job import analyze_job
    
    # 创建 DOP 正常的测试数据
    plan_data = create_test_plan_data()
    plan_data['dml']['stages'][1]['dop'] = '2048'  # 修改 stg56 的 DOP 为 2048
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as plan_file:
        json.dump(plan_data, plan_file)
        plan_path = plan_file.name
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as profile_file:
        json.dump(create_test_profile_data(), profile_file)
        profile_path = profile_file.name
    
    try:
        result = analyze_job(
            plan_file=plan_path,
            profile_file=profile_path,
            output_dir=tempfile.gettempdir(),
            log_level='WARNING'
        )
        
        findings = result.get('findings', [])
        tablesink_findings = [f for f in findings if f.get('type') == 'TABLESINK_DOP']
        
        if tablesink_findings:
            print(f"  ✗ 误报: DOP 正常但仍然触发了规则")
            return False
        
        print("  ✓ 没有误报")
        return True
        
    finally:
        os.unlink(plan_path)
        os.unlink(profile_path)


def run_all_tests():
    """运行所有集成测试"""
    print("=" * 80)
    print("TableSink DOP 规则集成测试")
    print("=" * 80)
    
    tests = [
        test_integration_with_real_data_structure,
        test_integration_no_false_positive,
    ]
    
    results = []
    for test in tests:
        try:
            result = test()
            results.append(result)
        except Exception as e:
            print(f"  ✗ 测试异常: {str(e)}")
            import traceback
            traceback.print_exc()
            results.append(False)
    
    print("\n" + "=" * 80)
    print(f"测试结果: {sum(results)}/{len(results)} 通过")
    print("=" * 80)
    
    return all(results)


if __name__ == '__main__':
    success = run_all_tests()
    sys.exit(0 if success else 1)
