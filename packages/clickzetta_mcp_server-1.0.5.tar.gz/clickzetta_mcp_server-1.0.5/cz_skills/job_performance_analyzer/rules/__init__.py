#!/usr/bin/env python3
"""规则模块"""
from .base_rule import BaseRule
__all__ = ['BaseRule']
