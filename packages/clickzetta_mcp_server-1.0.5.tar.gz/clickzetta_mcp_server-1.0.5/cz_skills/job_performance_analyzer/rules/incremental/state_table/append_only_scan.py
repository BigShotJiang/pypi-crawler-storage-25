#!/usr/bin/env python3
"""Append-Only Scan 检查规则"""
import json
from typing import Dict, List
from ...base_rule import BaseRule
from ....utils.append_only_detector import AppendOnlyDetector
from ....utils.state_table_checker import StateTableChecker


class AppendOnlyScan(BaseRule):
    name = "append_only_scan"
    category = "incremental/state_table"
    description = "检查 append-only 表扫描是否可以通过增量算法优化"
    
    def check(self, stage_data: Dict, context: Dict) -> bool:
        ## TODO(yun.chen) 当前实现逻辑混乱，暂时关闭
        # plan_str = json.dumps(stage_data.get('plan', {}))
        # return 'tableScan' in plan_str or 'TableScan' in plan_str
        return False
    
    def analyze(self, stage_data: Dict, context: Dict) -> Dict:
        stage_id = stage_data.get('stage_id', 'unknown')
        plan = stage_data.get('plan', {})
        settings = context.get('settings', {})
        findings, recommendations, insights = [], [], []
        
        table_analysis = self._analyze_tables(plan)
        for info in table_analysis:
            if info['is_append_only']:
                # "表 xxx 是 append-only" 是纯事实，降级为 analysis_scope 供 AI 消费
                self.add_analysis_detail(context, 'append_only_tables', {
                    'table_name': info['name'],
                    'has_join': info['has_join'],
                    'has_agg': info['has_agg'],
                }, stage_id=stage_id)
                
                # 根据 prompt 4.2.4 的核心思想：
                # 如果还有 append-only 的 scan，说明可能没有充分利用 append-only 特性进行优化
                # 应该考虑：为什么还在扫描 append-only 数据，而不是使用增量算法？
                
                optimization_suggestions = []
                
                # **改进**: 检查整个 job 是否已有状态表（全局检查）
                has_state_table_in_job = StateTableChecker.check_plan_has_state_table(context)
                
                # 1. 检查是否可以使用状态表避免重复扫描
                state_table_enabled = settings.get('cz.optimizer.incremental.enable.state.table', 'false') == 'true'
                if not state_table_enabled and (info['has_join'] or info['has_agg']):
                    if has_state_table_in_job:
                        optimization_suggestions.append("考虑启用状态表以避免重复扫描 append-only 数据（注意：Job 已有状态表但参数未启用）")
                    else:
                        optimization_suggestions.append("考虑启用状态表以避免重复扫描 append-only 数据")
                
                # 2. 检查是否已使用增量算法
                plan_str = json.dumps(plan)
                has_incremental_hints = any(pattern in plan_str for pattern in [
                    'IncrementalLinearTopKWindowRule',
                    'IncrementalAggregateRule', 
                    'IncrementalJoinRule',
                    'Rule:Incremental',
                    'DeltaState'
                ])
                
                if not has_incremental_hints and (info['has_join'] or info['has_agg']):
                    optimization_suggestions.append("未检测到增量算法 hint，可能可以使用增量计算替代全量扫描")
                
                # 3. 对于 append-only 数据，理论上应该能够避免全量扫描
                if not has_incremental_hints and not state_table_enabled:
                    if has_state_table_in_job:
                        optimization_suggestions.append("append-only 数据特性未被充分利用。注意：Job 已有状态表，建议检查状态表位置和增量处理配置")
                    else:
                        optimization_suggestions.append("append-only 数据特性未被充分利用，建议使用增量处理")
                
                if optimization_suggestions:
                    findings.append(self.create_finding('POTENTIAL_OPTIMIZATION', stage_id, 'INFO',
                        f"append-only 表 {info['name']} 仍在进行扫描，{'; '.join(optimization_suggestions)}",
                        confidence='medium'))
                # "已被充分利用" 是纯正面事实，不需要作为 insight 输出
        
        return {'findings': findings, 'recommendations': recommendations, 'insights': insights}
    
    def _analyze_tables(self, plan: Dict) -> List[Dict]:
        """分析 plan 中的所有 TableScan，识别 append-only 的 delta 扫描"""
        results = []
        try:
            for op in plan.get('operators', []):
                # 使用统一的 AppendOnlyDetector 进行检测
                if not AppendOnlyDetector.is_delta_scan(op):
                    continue  # 跳过非 delta 扫描
                
                # 获取表名
                table_name = AppendOnlyDetector.get_table_name(op)
                if not table_name:
                    continue
                
                # 排除中间状态表
                if any(pattern in table_name for pattern in ['__incr__', '__state__', '__temp__']):
                    continue
                
                # 排除 delta 元数据扫描
                output_fields = AppendOnlyDetector.get_operator_output_fields(op)
                if output_fields:
                    delta_metadata_fields = ['file_path', 'pos', 'commit_ts', 'operation', 'field_id', 'value']
                    if any(field in output_fields for field in delta_metadata_fields):
                        continue
                
                # 判断是否为 append-only
                is_append_only = AppendOnlyDetector.is_append_only_scan(op)
                if is_append_only is None:
                    continue  # 无法判断，跳过
                
                # 检查是否有 join/aggregate
                plan_str = json.dumps(plan)
                
                # 获取增量属性
                table_scan = op.get('tableScan') or op.get('TableScan')
                incr_prop = table_scan.get('incrementalTableProperty', {})
                
                results.append({
                    'name': table_name,
                    'is_append_only': is_append_only,
                    'has_join': 'Join' in plan_str or 'HashJoin' in plan_str,
                    'has_agg': 'HashAggregate' in plan_str or 'Aggregate' in plan_str,
                    'from_version': incr_prop.get('from', ''),
                    'to_version': incr_prop.get('to', ''),
                })
        except Exception:
            pass
        return results
