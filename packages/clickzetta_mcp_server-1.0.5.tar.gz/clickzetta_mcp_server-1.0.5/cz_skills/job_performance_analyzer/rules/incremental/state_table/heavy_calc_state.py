#!/usr/bin/env python3
"""Calc 状态优化规则"""
import json
import logging
from typing import Dict
from ...base_rule import BaseRule

logger = logging.getLogger(__name__)

class HeavyCalcState(BaseRule):
    name = "heavy_calc_state"
    category = "incremental/state_table"
    description = "检测高耗时 Calc 算子，建议存储状态以避免重复计算"
    CALC_STAGE_PERCENT = 30.0
    STAGE_TOTAL_PERCENT = 15.0
    UDF_PATTERNS = ['udf', 'UDF', 'user_defined', 'custom_func', 'ScalarFunction']
    
    def check(self, stage_data: Dict, context: Dict) -> bool:
        operator_analysis = context.get('operator_analysis', [])
        stage_id = stage_data.get('stage_id')
        calc_ops = [op for op in operator_analysis if op['stage_id'] == stage_id and 'Calc' in op.get('operator_id', '')]
        return len(calc_ops) > 0
    
    def analyze(self, stage_data: Dict, context: Dict) -> Dict:
        stage_id = stage_data.get('stage_id', 'unknown')
        plan = stage_data.get('plan', {})
        metrics = stage_data.get('metrics', {})
        settings = context.get('settings', {})
        operator_analysis = context.get('operator_analysis', [])
        total_time = context.get('total_job_time', 0)
        operator_data_types = context.get('operator_data_types', {})  # 来自 4.2.1.1 分析
        
        elapsed_ms = metrics.get('elapsed_ms', 0)
        stage_pct = (elapsed_ms / total_time * 100) if total_time else 0
        findings, recommendations, insights = [], [], []
        
        stage_ops = [op for op in operator_analysis if op['stage_id'] == stage_id]
        calc_ops = [op for op in stage_ops if 'Calc' in op.get('operator_id', '')]
        
        for calc_op in calc_ops:
            calc_stage_pct = calc_op.get('stage_pct', 0)
            calc_elapsed_ms = calc_op.get('elapsed_ms', 0)
            operator_id = calc_op.get('operator_id', 'unknown')
            
            # 过滤条件 1：calc 占 stage 比例 < 30%
            if calc_stage_pct < self.CALC_STAGE_PERCENT:
                continue
            
            # 过滤条件 2：stage 占整体比例 < 10%
            if stage_pct < self.STAGE_TOTAL_PERCENT:
                continue
            
            # 过滤条件 3：calc 必须是 snapshot 状态（不是 delta）
            # 根据 4.2.1.1 规则获取 operator 的数据类型
            op_data_type = operator_data_types.get(operator_id, 'UNKNOWN')
            
            # 兼容大小写
            if op_data_type.upper() != 'SNAPSHOT':
                logger.debug(f"[heavy_calc_state] 跳过 Calc {operator_id}：不是 SNAPSHOT 状态（当前：{op_data_type}）")
                continue
            
            # 检查是否有 UDF
            has_udf = any(p in json.dumps(plan) for p in self.UDF_PATTERNS)
            
            # 计算 Calc 的实际耗时：如果 operator_analysis 中没有 elapsed_ms，则根据占比计算
            if calc_elapsed_ms == 0 and calc_stage_pct > 0:
                calc_elapsed_ms = elapsed_ms * calc_stage_pct / 100
            
            # 创建 finding，包含详细信息
            # 格式：Calc xxx 占 Stage yyy%，Stage zzz 占整体 www%
            findings.append(self.create_finding(
                'HEAVY_CALC', 
                stage_id, 
                'HIGH' if has_udf else 'MEDIUM',
                f"Calc {operator_id} 占 Stage {calc_stage_pct:.1f}%，"
                f"Stage {stage_id} 占整体 {stage_pct:.1f}%",
                {
                    'operator_id': operator_id,
                    'has_udf': has_udf,
                    'calc_elapsed_ms': calc_elapsed_ms,
                    'calc_stage_pct': calc_stage_pct,
                    'stage_elapsed_ms': elapsed_ms,
                    'stage_total_pct': stage_pct,
                    'data_type': op_data_type
                },
                confidence='high' if has_udf else 'medium'
            ))

            param = 'cz.optimizer.incremental.create.rule.based.table.on.heavy.calc'
            # 根据规则 4.2.7：参数不存在 OR 值 = 'false' 时才推荐
            if param not in settings or settings.get(param) == 'false':
                # 格式：Stage xxx: Calc yyy 耗时 zzz (占 Stage aaa%，Stage bbb 占整体 ccc%)
                reason = (f"Stage {stage_id}: Calc {operator_id} 耗时 {calc_elapsed_ms/1000:.1f}s "
                         f"(占 Stage {calc_stage_pct:.1f}%，Stage {stage_id} 占整体 {stage_pct:.1f}%)"
                         f"{'，包含 UDF' if has_udf else ''}")
                
                recommendations.append(self.build_recommendation_with_table_check(
                    param, 'true', 2 if has_udf else 3,
                    reason, 'HIGH' if has_udf else 'MEDIUM',
                    context))
            
            # 创建 insight，包含详细信息
            insights.append(self.create_insight(
                f"Stage {stage_id}: Calc {operator_id} 耗时 {calc_elapsed_ms/1000:.1f}s "
                f"(占 Stage {calc_stage_pct:.1f}%，Stage {stage_id} 耗时 {elapsed_ms/1000:.1f}s 占整体 {stage_pct:.1f}%)"
                f"{'，包含 UDF' if has_udf else ''}，考虑开启状态优化", 
                stage_id
            ))
        
        return {'findings': findings, 'recommendations': recommendations, 'insights': insights}
