#!/usr/bin/env python3
"""非增量原因诊断规则"""
from typing import Dict
from ...base_rule import GlobalRule
from ....utils.version_utils import parse_version, is_version_le, is_version_ge


class NonIncrementalDiagnosis(GlobalRule):
    name = "non_incremental_diagnosis"
    category = "incremental/state_table"
    description = "诊断为什么任务退化为全量刷新"
    rule_scope = "global"

    # 版本 <= 1.3 使用的诊断标志
    DIAGNOSIS_FLAGS_V13 = [
        ('cz.optimizer.print.non.incremental.reason', 'true'),
        ('cz.optimizer.print.non.incremental.reason.msg.max.length', '100000'),
        ('cz.optimizer.incremental.force.incremental', 'true'),
    ]

    # 版本 >= 1.4 使用的诊断标志
    DIAGNOSIS_FLAGS_V14 = [
        ('cz.optimizer.incremental.try.incremental.refresh.enabled', 'true'),
    ]

    def analyze_global(self, context: Dict) -> Dict:
        """全局分析：只在检测到全量刷新时执行一次"""
        refresh_type = context.get('refresh_type')
        settings = context.get('settings', {})
        version_info = context.get('version_info', {})
        git_branch = version_info.get('git_branch', 'Unknown')

        findings, recommendations, insights = [], [], []

        # 只在全量刷新时触发
        if refresh_type != 'FULL':
            return {'findings': findings, 'recommendations': recommendations, 'insights': insights}

        # 如果 is.incremental.plan=1，说明这是增量计划的第一次刷新，
        # 虽然表现为 full refresh，但属于正常的初始化行为，不需要诊断
        is_incremental_plan = settings.get('cz.sql.incremental.is.incremental.plan', '0')
        if str(is_incremental_plan) == '1':
            return {'findings': findings, 'recommendations': recommendations, 'insights': insights}

        # 如果设置了强制全量刷新，则全量是符合预期的，不需要诊断
        force_full = settings.get('cz.optimizer.incremental.force.full.refresh', '').lower()
        if force_full == 'true':
            insights.append(self.create_insight(
                "任务为全量刷新，因设置了 cz.optimizer.incremental.force.full.refresh=true，属于强制全量，符合预期",
                'global', level='important'))
            return {'findings': findings, 'recommendations': recommendations, 'insights': insights}

        findings.append(self.create_finding('NON_INCREMENTAL_REFRESH', 'global', 'HIGH',
            '任务退化为全量刷新，需要诊断原因（注意：如果是该表或分区的第一次刷新，则全量是正常行为，可忽略）',
            confidence='high'))

        # 解析版本号
        version = parse_version(git_branch)

        # 根据版本选择合适的诊断标志
        if version is None:
            # 版本未知，保守策略：同时提供两种版本的建议
            insights.append(self.create_insight(
                f"无法解析版本信息（当前: {git_branch}），请根据实际版本选择合适的诊断参数", 'global'))
            diagnosis_flags = self.DIAGNOSIS_FLAGS_V13
            version_hint = "版本 ≤ 1.3"
        elif is_version_le(version, 1, 3):
            # 版本 <= 1.3
            diagnosis_flags = self.DIAGNOSIS_FLAGS_V13
            version_hint = f"版本 {version[0]}.{version[1]} (≤ 1.3)"
        elif is_version_ge(version, 1, 4):
            # 版本 >= 1.4
            diagnosis_flags = self.DIAGNOSIS_FLAGS_V14
            version_hint = f"版本 {version[0]}.{version[1]} (≥ 1.4)"
        else:
            # 理论上不应该到这里，但作为保险
            diagnosis_flags = self.DIAGNOSIS_FLAGS_V13
            version_hint = f"版本 {version[0]}.{version[1]}"

        # 构建参数展示文本
        params_display = ', '.join(f'{p}={v}' for p, v in diagnosis_flags)

        # 检查缺失的标志
        missing_flags = [(p, v) for p, v in diagnosis_flags if p not in settings]
        for param, value in missing_flags:
            recommendations.append(self.build_recommendation_with_table_check(
                param, value, 1,
                f'任务为全量刷新，需设置该参数诊断全量原因。',
                'HIGH', context))

        # 生成洞察信息
        if missing_flags:
            missing_params_display = ', '.join(f'{p}={v}' for p, v in missing_flags)
            insights.append(self.create_insight(
                f"任务为全量刷新，请设置 {missing_params_display} 后查看全量原因。"
                f"注意：如果是该表或分区的第一次刷新，则全量刷新是正常行为，可忽略",
                'global', level='important'))
        else:
            insights.append(self.create_insight(
                f"任务退化为全量刷新，参数 {params_display} 已设置。"
                f"注意：如果是该表或分区的第一次刷新，则全量是正常行为，可忽略",
                'global', level='important'))

        return {'findings': findings, 'recommendations': recommendations, 'insights': insights}

