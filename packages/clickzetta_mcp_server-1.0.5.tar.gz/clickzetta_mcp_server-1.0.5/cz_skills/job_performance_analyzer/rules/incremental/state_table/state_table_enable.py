#!/usr/bin/env python3
"""状态表启用建议规则"""
import json
import logging
from typing import Dict, List, Set
from ...base_rule import GlobalRule
from ....utils.state_table_checker import StateTableChecker

# 创建 logger
logger = logging.getLogger(__name__)


class StateTableEnable(GlobalRule):
    name = "state_table_enable"
    category = "incremental/state_table"
    description = "判断是否应该开启状态表以优化增量计算"
    rule_scope = "global"  # 全局规则，只执行一次
    STATE_TABLE_PATTERN = '__incr__'
    STATEFUL_OPS = ['HashAggregate', 'Window', 'Join']
    STATE_SIZE_RATIO_THRESHOLD = 10  # 状态表大小阈值（相对于输入）

    def analyze_global(self, context: Dict) -> Dict:
        """
        全局分析：分析整个job的snapshot subplan
        
        根据用户要求：
        1. 全局分析一次，避免按stage重复分析
        2. 对于全snapshot的subplan，公共节点也属于subplan
        3. 输出具体的物化节点名字和所在stage
        """
        findings, recommendations, insights = [], [], []
        
        logger.debug(f"[StateTableEnable] 开始全局分析")
        
        # 检查整个 job 是否已经有中间状态表
        has_state_table = StateTableChecker.check_plan_has_state_table(context)
        logger.debug(f"[StateTableEnable] Job 是否已有状态表: {has_state_table}")

        # if has_state_table:
        #     logger.info(f"[StateTableEnable] Job 已包含中间状态表，跳过分析")
        #     insights.append(self.create_insight(
        #         f"Job 已包含中间状态表（表名包含 {self.STATE_TABLE_PATTERN}）", 'global'))
        #     return {'findings': findings, 'recommendations': recommendations, 'insights': insights}

        # 策略1：基于增量算法的状态表优化（程序控制是否启用）
        enable_incremental_strategy = context.get('enable_incremental_algorithm_analysis', False)
        logger.debug(f"[StateTableEnable] 增量算法策略启用状态: {enable_incremental_strategy}")
        
        if enable_incremental_strategy:
            logger.debug(f"[StateTableEnable] 执行增量算法策略分析...")
            incremental_result = self._analyze_incremental_algorithm_strategy_global(context)
            findings.extend(incremental_result.get('findings', []))
            recommendations.extend(incremental_result.get('recommendations', []))
            insights.extend(incremental_result.get('insights', []))
        
        # 策略2：基于Snapshot subplan占比的状态表优化（最重要，总是执行）
        logger.debug(f"[StateTableEnable] 执行 Snapshot subplan 策略分析...")
        snapshot_result = self._analyze_snapshot_subplan_strategy(context)
        findings.extend(snapshot_result.get('findings', []))
        recommendations.extend(snapshot_result.get('recommendations', []))
        insights.extend(snapshot_result.get('insights', []))

        logger.debug(f"[StateTableEnable] 全局分析完成: 总共 {len(findings)} findings, {len(recommendations)} recommendations")
        return {'findings': findings, 'recommendations': recommendations, 'insights': insights}

    def _analyze_incremental_algorithm_strategy_global(self, context: Dict) -> Dict:
        """
        全局分析基于增量算法的状态表优化策略
        
        这个方法在全局层面分析增量算法，避免按stage重复分析
        """
        findings, recommendations, insights = [], [], []
        
        logger.debug(f"[StateTableEnable] 增量算法策略 - 开始全局分析")
        
        aligned_stages = context.get('aligned_stages', {})
        
        # 遍历所有stage，收集增量状态算子
        all_incremental_stateful_ops = []
        
        for stage_id, stage_data in aligned_stages.items():
            plan = stage_data.get('plan', {})
            incremental_stateful_ops = self._get_incremental_stateful_ops(plan)
            
            if incremental_stateful_ops:
                all_incremental_stateful_ops.extend([
                    {'stage_id': stage_id, 'ops': incremental_stateful_ops, 
                     'plan': plan, 'metrics': stage_data.get('metrics', {})}
                ])
        
        logger.debug(f"[StateTableEnable] 增量算法策略 - 找到 {len(all_incremental_stateful_ops)} 个包含增量状态算子的stage")
        
        if not all_incremental_stateful_ops:
            logger.debug(f"[StateTableEnable] 增量算法策略 - 未找到增量状态算子")
            return {'findings': findings, 'recommendations': recommendations, 'insights': insights}
        
        # 全局判断是否应该启用状态表
        for item in all_incremental_stateful_ops:
            stage_id = item['stage_id']
            ops = item['ops']
            plan = item['plan']
            metrics = item['metrics']
            
            should_enable, reason = self._should_enable_state_table_for_incremental(
                stage_id, plan, metrics, ops
            )
            
            logger.debug(f"[StateTableEnable] 增量算法策略 - Stage {stage_id}: should_enable={should_enable}, reason={reason}")
            
            if should_enable:
                findings.append(self.create_finding(
                    'INCREMENTAL_STATE_TABLE_CANDIDATE', stage_id, 'INFO',
                    f"基于增量算法：{reason}",
                    confidence='medium'
                ))
                
                # 存储 analysis_scope
                self.add_analysis_detail(context, 'incremental_strategy', {
                    'stateful_ops': ops,
                    'should_enable': should_enable,
                    'reason': reason,
                    'output_input_ratio': metrics.get('output_bytes', 0) / max(metrics.get('input_bytes', 1), 1),
                }, stage_id=stage_id)
                
                param = 'cz.optimizer.incremental.enable.state.table'
                settings = context.get('settings', {})
                if param not in settings or settings.get(param) == 'false':
                    logger.info(f"[StateTableEnable] 增量算法策略 - 推荐设置参数: {param}=true")
                    recommendations.append(self.build_recommendation_with_table_check(
                        param, 'true', 3,
                        f"Stage {stage_id}: {reason}",
                        'MEDIUM', context))
                else:
                    logger.debug(f"[StateTableEnable] 增量算法策略 - 参数 {param} 已设置，跳过推荐")
                    insights.append(self.create_insight(
                        f"Stage {stage_id}: [增量算法策略] 参数 {param} 已开启，但 {reason}，"
                        f"建议深入分析中间表创建策略是否需要进一步优化",
                        stage_id, level='important'))
                
                insights.append(self.create_insight(
                    f"Stage {stage_id}: [增量算法策略] {reason}", stage_id))
        
        return {'findings': findings, 'recommendations': recommendations, 'insights': insights}

    def _analyze_incremental_algorithm_strategy(self, stage_data: Dict, context: Dict) -> Dict:
        """分析基于增量算法的状态表优化策略"""
        stage_id = stage_data.get('stage_id', 'unknown')
        plan = stage_data.get('plan', {})
        findings, recommendations, insights = [], [], []
        
        logger.debug(f"[StateTableEnable] 增量算法策略 - 开始分析 stage {stage_id}")
        
        # 检查是否包含需要状态的算子（必须是增量算法产生的）
        incremental_stateful_ops = self._get_incremental_stateful_ops(plan)
        logger.debug(f"[StateTableEnable] 增量算法策略 - 找到增量状态算子: {incremental_stateful_ops}")
        
        if incremental_stateful_ops:
            # 判断是否值得存储中间状态
            should_enable, reason = self._should_enable_state_table_for_incremental(
                stage_id, plan, stage_data.get('metrics', {}), incremental_stateful_ops
            )
            
            logger.debug(f"[StateTableEnable] 增量算法策略 - Stage {stage_id}: should_enable={should_enable}, reason={reason}")
            
            if should_enable:
                findings.append(self.create_finding(
                    'INCREMENTAL_STATE_TABLE_CANDIDATE', stage_id, 'INFO',
                    f"基于增量算法：{reason}"
                ))
                
                param = 'cz.optimizer.incremental.enable.state.table'
                settings = context.get('settings', {})
                if param not in settings or settings.get(param) == 'false':
                    logger.info(f"[StateTableEnable] 增量算法策略 - 推荐设置参数: {param}=true")
                    recommendations.append(self.build_recommendation_with_table_check(
                        param, 'true', 3,
                        f"Stage {stage_id}: {reason}",
                        'MEDIUM', context))
                else:
                    logger.debug(f"[StateTableEnable] 增量算法策略 - 参数 {param} 已设置，跳过推荐")
                    insights.append(self.create_insight(
                        f"Stage {stage_id}: [增量算法策略] 参数 {param} 已开启，但 {reason}，"
                        f"建议深入分析中间表创建策略是否需要进一步优化",
                        stage_id, level='important'))
                
                insights.append(self.create_insight(
                    f"Stage {stage_id}: [增量算法策略] {reason}", stage_id))
        else:
            logger.debug(f"[StateTableEnable] 增量算法策略 - Stage {stage_id}: 未找到增量状态算子")
        
        return {'findings': findings, 'recommendations': recommendations, 'insights': insights}

    def _analyze_snapshot_subplan_strategy(self, context: Dict) -> Dict:
        """
        分析基于Snapshot subplan占比的状态表优化策略
        
        根据 prompt 要求：
        1. 结合3.6的operator统计和4.2.1的delta/snapshot分析
        2. 找到某个subplan（root节点是snapshot）的统计耗时占比
        3. 基于operator级别的链路关系，不是stage级别
        """
        findings, recommendations, insights = [], [], []

        logger.debug(f"[StateTableEnable] Snapshot策略 - 开始分析")

        # 获取必要的数据
        operator_data_types = context.get('operator_data_types', {})  # 来自4.2.1分析
        operator_analysis = context.get('operator_analysis', [])      # 来自3.6统计
        total_job_time = context.get('total_job_time', 0)
        
        logger.debug(f"[StateTableEnable] Snapshot策略 - operator_data_types: {len(operator_data_types)} 个")
        logger.debug(f"[StateTableEnable] Snapshot策略 - operator_analysis: {len(operator_analysis)} 个")
        logger.debug(f"[StateTableEnable] Snapshot策略 - total_job_time: {total_job_time}ms")
        
        # **关键修复**：如果 operator_data_types 为空，尝试运行增量算法分析器来获取数据
        if not operator_data_types:
            logger.debug(f"[StateTableEnable] Snapshot策略 - operator_data_types 为空，尝试运行增量算法分析器")
            operator_data_types = self._run_incremental_analyzer_for_data_types(context)
            if operator_data_types:
                # 保存到 context 供后续使用
                context['operator_data_types'] = operator_data_types
                logger.debug(f"[StateTableEnable] Snapshot策略 - 成功获取 {len(operator_data_types)} 个 operator 的数据类型")
            else:
                logger.warning(f"[StateTableEnable] Snapshot策略 - 无法获取 operator 数据类型")
        
        if not operator_data_types or not operator_analysis or total_job_time == 0:
            logger.warning(f"[StateTableEnable] Snapshot策略 - 缺少必要数据，无法分析")
            insights.append(self.create_insight(
                "缺少operator依赖关系或统计数据，无法分析snapshot subplan", 'global'))
            return {'findings': findings, 'recommendations': recommendations, 'insights': insights}
        
        # **新增**: 检查整个 job 是否已经有中间状态表
        has_state_table = StateTableChecker.check_plan_has_state_table(context)
        logger.debug(f"[StateTableEnable] Snapshot策略 - Job 是否已有状态表: {has_state_table}")
        
        # 分析snapshot subplan
        snapshot_subplans = self._find_snapshot_subplans(operator_data_types, operator_analysis, context)
        logger.debug(f"[StateTableEnable] Snapshot策略 - 找到 {len(snapshot_subplans)} 个 snapshot subplan")
        
        for i, subplan in enumerate(snapshot_subplans):
            percentage = subplan['percentage']
            root_op = subplan['root_operator']
            root_stage = subplan.get('root_stage', 'unknown')
            total_time_ms = subplan['total_time_ms']
            num_operators = len(subplan['operators'])
            
            # **改进**: 为每个subplan打印详细信息
            logger.debug(f"[StateTableEnable] Snapshot策略 - Subplan {i+1}/{len(snapshot_subplans)}: "
                       f"Root={root_op} (Stage {root_stage}), "
                       f"占比={percentage:.1f}% ({total_time_ms}ms / {context.get('total_job_time', 0)}ms), "
                       f"包含{num_operators}个算子")
            
            # **新增**: 打印树形结构（DEBUG 级别）
            tree_str = self._format_subplan_tree(subplan, context)
            logger.debug(tree_str)
            
            if percentage >= 15.0:
                # **关键修复**: 输出具体的物化节点名字和所在stage
                materialization_info = f"建议在 Stage {root_stage} 的算子 {root_op} 处物化为中间状态表"
                logger.debug(f"[StateTableEnable] Snapshot策略 - ✓ Subplan {i+1} 占比 {percentage:.1f}% >= 15%，{materialization_info}")
                
                # **新增**: 根据是否已有状态表调整建议内容
                if has_state_table:
                    # 已有状态表，提示需要进一步优化
                    finding_msg = f"Snapshot subplan 耗时 {total_time_ms/1000:.1f}s（占比 {percentage:.1f}%），{materialization_info}。注意：Job 已包含中间状态表，但该 subplan 仍占比较高，可能需要进一步优化状态表策略或检查是否在正确位置物化。"
                    recommendation_reason = f"Snapshot subplan 耗时 {total_time_ms/1000:.1f}s（占比 {percentage:.1f}%），{materialization_info}。Job 已有状态表但如果想更进一步优化，建议检查状态表位置是否合理，或考虑在此处额外物化"
                    insight_msg = f"[Snapshot策略] 发现高占比subplan（耗时 {total_time_ms/1000:.1f}s，占比 {percentage:.1f}%）：{materialization_info}。骨架：{{skeleton_info}}。注意：Job 已有状态表，建议检查优化策略"
                else:
                    # 没有状态表，正常建议
                    finding_msg = f"Snapshot subplan 耗时 {total_time_ms/1000:.1f}s（占比 {percentage:.1f}%），{materialization_info}"
                    recommendation_reason = f"Snapshot subplan 耗时 {total_time_ms/1000:.1f}s（占比 {percentage:.1f}%），{materialization_info}"
                    insight_msg = f"[Snapshot策略] 发现高占比subplan（耗时 {total_time_ms/1000:.1f}s，占比 {percentage:.1f}%）：{materialization_info}。骨架：{{skeleton_info}}"
                
                findings.append(self.create_finding(
                    'SNAPSHOT_SUBPLAN_CANDIDATE', 'global', 'INFO',
                    finding_msg,
                    confidence='medium'
                ))
                
                # 存储 snapshot subplan 的 analysis_scope
                self.add_analysis_detail(context, f'snapshot_subplan_{i}', {
                    'root_operator': root_op,
                    'root_stage': root_stage,
                    'percentage': round(percentage, 1),
                    'total_time_ms': total_time_ms,
                    'num_operators': num_operators,
                    'has_state_table': has_state_table,
                    'skeleton': [{'operator_id': s['operator_id'], 'type': s['type'], 'elapsed_ms': s['elapsed_ms']}
                                 for s in subplan.get('skeleton', [])],
                })
                
                param = 'cz.optimizer.incremental.enable.state.table'
                settings = context.get('settings', {})
                if param not in settings or settings.get(param) == 'false':
                    logger.info(f"[StateTableEnable] Snapshot策略 - 推荐设置参数: {param}=true")
                    recommendations.append(self.build_recommendation_with_table_check(
                        param, 'true', 2,  # 更高优先级
                        recommendation_reason,
                        'HIGH', context))
                else:
                    logger.debug(f"[StateTableEnable] Snapshot策略 - 参数 {param} 已设置，跳过推荐")
                    # 参数已开启但 subplan 仍占比高，建议深入优化
                    settings = context.get('settings', {})
                    materialize_param = 'cz.optimizer.incremental.materialize.all.stateful.op'
                    rebuild_param = 'cz.optimizer.incremental.rebuild.rule.based.state.table'
                    extra_params = []
                    if settings.get(materialize_param) != 'true':
                        extra_params.append(f"set {materialize_param}=true")
                    if settings.get(rebuild_param) != 'true':
                        extra_params.append(f"set {rebuild_param}=true")

                    if extra_params:
                        sep = ";\n"
                        param_hint = (
                            f"建议临时加以下参数跑一次 refresh 重建中间表：{sep.join(extra_params)};\n"
                            f"其中 {rebuild_param} 仅需临时使用（重建后去掉），"
                            f"{materialize_param} 如果观察到效果则需要保留")
                    else:
                        param_hint = "相关优化参数均已设置，建议观察后续 refresh 是否有改善"

                    insights.append(self.create_insight(
                        f"[Snapshot策略] 参数 {param} 已开启，但 snapshot subplan 仍占比 {percentage:.1f}%"
                        f"（耗时 {total_time_ms/1000:.1f}s），{materialization_info}。"
                        f"{param_hint}",
                        'global', level='important'))
                skeleton_info = self._format_subplan_skeleton(subplan)
                logger.debug(f"[StateTableEnable] Snapshot策略 - Subplan {i+1} 骨架: {skeleton_info}")
                insights.append(self.create_insight(
                    insight_msg.format(skeleton_info=skeleton_info), 'global'))
            else:
                logger.debug(f"[StateTableEnable] Snapshot策略 - ✗ Subplan {i+1} 占比 {percentage:.1f}% < 15%，不建议创建状态表")
                # 不达标的 subplan 不需要作为 insight 输出，debug 日志已记录
        
        logger.debug(f"[StateTableEnable] Snapshot策略 - 分析完成")
        return {'findings': findings, 'recommendations': recommendations, 'insights': insights}

    def _should_enable_state_table(self, stage_id: str, plan: Dict, metrics: Dict,
                                   stateful_ops: list) -> tuple:
        """
        判断是否值得存储中间状态

        根据 prompt 4.2.5 的要求：
        1. 是否需要状态（参考流计算的带状态计算定义）
        2. 状态表是否过大（根据 stats 信息和输入表的增量数据大小判断）

        Returns:
            (should_enable: bool, reason: str)
        """
        # 1. 检查是否需要状态
        # 带状态计算的定义：需要维护历史信息的计算
        # - Aggregate: 需要维护聚合状态
        # - Window: 需要维护窗口状态
        # - Join: 需要维护 join 状态
        needs_state = len(stateful_ops) > 0

        if not needs_state:
            return False, "不包含需要状态的算子"

        # 2. 检查状态表是否过大
        # 根据输出和输入的比例判断
        output_bytes = metrics.get('output_bytes', 0)
        input_bytes = metrics.get('input_bytes', 0)

        if input_bytes == 0:
            # 无法判断，保守建议开启
            return True, f"包含 {', '.join(stateful_ops)}，建议开启状态表以避免重复计算"

        size_ratio = output_bytes / input_bytes

        if size_ratio > self.STATE_SIZE_RATIO_THRESHOLD:
            # 状态表可能过大
            return False, (
                f"状态表可能过大（输出/输入比例={size_ratio:.1f}x，阈值={self.STATE_SIZE_RATIO_THRESHOLD}x），"
                f"不建议开启状态表"
            )

        # 状态表大小合理，建议开启
        return True, (
            f"包含 {', '.join(stateful_ops)}，状态表大小预估合理"
            f"（输出/输入比例={size_ratio:.1f}x），建议开启状态表以避免重复计算"
        )

    def _check_job_has_state_table(self, context: Dict) -> bool:
        """
        检查整个 job 是否已经包含中间状态表
        
        Args:
            context: 分析上下文，包含所有 stage 数据
            
        Returns:
            bool: 是否已包含状态表
        """
        aligned_stages = context.get('aligned_stages', {})
        
        # 检查所有 stage 的 plan
        for stage_id, stage_data in aligned_stages.items():
            plan = stage_data.get('plan', {})
            if self._check_plan_has_state_table(plan):
                return True
                
        return False
    
    def _check_plan_has_state_table(self, plan: Dict) -> bool:
        """
        检查单个 plan 是否包含状态表
        
        已废弃：请使用 StateTableChecker.check_plan_has_state_table(context)
        
        Args:
            plan: stage 的 plan 数据
            
        Returns:
            bool: 是否包含状态表
        """
        return StateTableChecker.check_plan_has_state_table(plan)

    def _has_incremental_hint(self, op: Dict) -> bool:
        """
        检查算子是否有增量相关的 hint
        
        根据 prompt 4.2.1.2 和 4.2.0 的要求：
        "同时关于状态表这些优化必须是对应算子的对应增量算法，如aggregate则必须是增量算法产生的，join/window等都类似；可以根据4.2.1.2来判断；"
        
        只有有增量 hint 的算子才是增量算法的一部分，才需要进行状态表优化分析。
        
        Args:
            op: 算子对象
            
        Returns:
            是否有增量相关的 hint
        """
        try:
            # **性能优化**: 先检查常见的字段，避免不必要的序列化
            # 检查 operator 的 id 字段
            op_id = op.get('id', '')
            if 'Incremental' in op_id or 'DeltaState' in op_id or 'delta' in op_id:
                return True
            
            # 检查 hints 字段（如果存在）
            if 'hints' in op:
                hints = op.get('hints', [])
                if hints:
                    hints_str = str(hints)
                    if 'Incremental' in hints_str or 'delta' in hints_str:
                        return True
            
            # 如果快速检查没有结果，才进行序列化检查
            op_str = json.dumps(op)
            
            # 检查是否包含增量相关的 hint pattern
            if 'Incremental' in op_str or 'DeltaState' in op_str or 'delta' in op_str:
                return True
                    
            return False
        except Exception:
            return False

    def _get_incremental_stateful_ops(self, plan: Dict) -> List[str]:
        """
        获取增量算法产生的状态算子列表
        
        根据 prompt 要求，只有增量算法产生的算子才需要状态表优化。
        新增要求：需要区分增量算法是不是对应的增量算法，如join算子对应的rule是join，aggregate类似。
        
        Args:
            plan: stage 的 plan 数据
            
        Returns:
            增量算法产生的状态算子类型列表
        """
        incremental_stateful_ops = []
        
        try:
            # 遍历所有算子，检查是否是增量算法产生的状态算子
            operators = plan.get('operators', [])
            for op in operators:
                # 检查是否有增量 hint
                if not self._has_incremental_hint(op):
                    continue
                
                # 先尝试从 operator 结构中直接获取类型信息
                op_type = None
                op_id = op.get('id', '')
                
                # 从 id 或 operator 键中判断类型
                if 'join' in op or 'hashJoin' in op:
                    op_type = 'Join'
                elif 'hashAgg' in op or 'hashAggregate' in op:
                    op_type = 'HashAggregate'
                elif 'window' in op or 'hashWindow' in op:
                    op_type = 'Window'
                elif 'Join' in op_id or 'HashJoin' in op_id:
                    op_type = 'Join'
                elif 'Aggregate' in op_id or 'HashAgg' in op_id:
                    op_type = 'HashAggregate'
                elif 'Window' in op_id:
                    op_type = 'Window'
                
                if not op_type:
                    continue
                
                # 避免重复添加
                if op_type in incremental_stateful_ops:
                    continue
                
                # 只在需要时序列化单个 operator
                op_str = json.dumps(op)
                
                # Join 算子：检查是否有对应的 Join 增量算法
                if op_type == 'Join':
                    if 'IncrementalJoinRule' in op_str or 'Incremental' in op_str and 'Join' in op_str:
                        incremental_stateful_ops.append('Join')
                
                # Aggregate 算子：检查是否有对应的 Aggregate 增量算法
                elif op_type == 'HashAggregate':
                    if 'IncrementalAggregateRule' in op_str or 'Incremental' in op_str and 'Agg' in op_str:
                        incremental_stateful_ops.append('HashAggregate')
                
                # Window 算子：检查是否有对应的 Window 增量算法
                elif op_type == 'Window':
                    if 'IncrementalWindow' in op_str or 'Incremental' in op_str and 'Window' in op_str:
                        incremental_stateful_ops.append('Window')
                        
        except Exception:
            pass
            
        return incremental_stateful_ops

    def _should_enable_state_table_for_incremental(self, stage_id: str, plan: Dict, metrics: Dict,
                                                   stateful_ops: list) -> tuple:
        """
        判断是否值得为增量算法存储中间状态
        
        Returns:
            (should_enable: bool, reason: str)
        """
        # 检查状态表是否过大
        output_bytes = metrics.get('output_bytes', 0)
        input_bytes = metrics.get('input_bytes', 0)

        if input_bytes == 0:
            return True, f"包含 {', '.join(stateful_ops)}，建议开启状态表以避免重复计算"

        size_ratio = output_bytes / input_bytes

        if size_ratio > self.STATE_SIZE_RATIO_THRESHOLD:
            return False, (
                f"状态表可能过大（输出/输入比例={size_ratio:.1f}x，阈值={self.STATE_SIZE_RATIO_THRESHOLD}x），"
                f"不建议开启状态表"
            )

        return True, (
            f"包含 {', '.join(stateful_ops)}，状态表大小预估合理"
            f"（输出/输入比例={size_ratio:.1f}x），建议开启状态表以避免重复计算"
        )

    def _find_snapshot_subplans(self, operator_data_types: Dict, operator_analysis: List[Dict], 
                                context: Dict) -> List[Dict]:
        """
        找到root节点是snapshot的subplan
        
        根据prompt要求：
        1. 结合3.6的operator统计和4.2.1的delta/snapshot分析
        2. 基于operator级别的链路关系，不是stage级别
        3. 找到某个subplan（root节点是snapshot）的统计耗时占比
        
        Args:
            operator_data_types: 来自4.2.1分析的operator类型 {op_id: 'delta'/'snapshot'}
                                 注意：键是纯 ID（如 "39"）
            operator_analysis: 来自3.6统计的operator耗时信息
                              注意：operator_id 是带类型的名称（如 "ShuffleRead39"）
            context: 分析上下文，包含operator依赖关系
            
        Returns:
            [
                {
                    'root_operator': str,  # 带类型的名称（如 "ShuffleRead39"）
                    'operators': [str],    # subplan包含的所有operator（带类型的名称）
                    'total_time_ms': int,
                    'percentage': float,
                    'skeleton': [...]  # 重要算子骨架
                }
            ]
        """
        logger.debug(f"[StateTableEnable] _find_snapshot_subplans - 开始查找 snapshot subplan")
        
        subplans = []
        total_job_time = context.get('total_job_time', 0)
        
        if total_job_time == 0:
            logger.warning(f"[StateTableEnable] _find_snapshot_subplans - total_job_time=0，无法计算占比")
            return subplans
        
        # 构建operator耗时映射（键是带类型的名称）
        op_time_map = {}
        for op_analysis in operator_analysis:
            op_id = op_analysis.get('operator_id', '')
            # 修复：使用 max_time_ms 而不是 elapsed_ms，如果没有则回退到 elapsed_ms
            elapsed_ms = op_analysis.get('max_time_ms', op_analysis.get('elapsed_ms', 0))
            op_time_map[op_id] = {
                'elapsed_ms': elapsed_ms,
                'stage_id': op_analysis.get('stage_id', ''),
                'analysis': op_analysis
            }
        
        logger.debug(f"[StateTableEnable] _find_snapshot_subplans - 构建了 {len(op_time_map)} 个 operator 的耗时映射")
        logger.debug(f"[StateTableEnable] _find_snapshot_subplans - op_time_map keys 示例: {list(op_time_map.keys())[:5]}")
        logger.debug(f"[StateTableEnable] _find_snapshot_subplans - operator_data_types keys 示例: {list(operator_data_types.keys())[:5]}")
        
        # 找到所有snapshot类型的operator作为潜在的root节点
        snapshot_operators = [op_id for op_id, data_type in operator_data_types.items() 
                             if data_type == 'snapshot']
        
        logger.debug(f"[StateTableEnable] _find_snapshot_subplans - 找到 {len(snapshot_operators)} 个 snapshot operator")
        logger.debug(f"[StateTableEnable] _find_snapshot_subplans - snapshot_operators 示例: {snapshot_operators[:5]}")
        
        # 获取operator依赖关系（来自增量算法分析器或其他地方）
        operator_dependencies = self._get_operator_dependencies(context)
        
        logger.debug(f"[StateTableEnable] _find_snapshot_subplans - 获取了 {len(operator_dependencies)} 个 operator 的依赖关系")
        logger.debug(f"[StateTableEnable] _find_snapshot_subplans - operator_dependencies keys 示例: {list(operator_dependencies.keys())[:5]}")
        
        # **关键修复**：找到真正的root节点
        # root节点的定义：不被任何其他snapshot算子依赖的snapshot算子
        # 这样可以避免subplan overlap问题
        snapshot_dependencies = set()
        for op_name in snapshot_operators:
            # 只收集snapshot算子的依赖
            deps = operator_dependencies.get(op_name, [])
            for dep in deps:
                # 只有当依赖也是snapshot时，才算作snapshot依赖
                if dep in snapshot_operators:
                    snapshot_dependencies.add(dep)
        
        # 真正的root节点是那些不被其他snapshot算子依赖的snapshot算子
        root_candidates = [op_name for op_name in snapshot_operators if op_name not in snapshot_dependencies]
        
        # 如果没有找到root候选，说明可能有循环依赖或者所有算子都是叶子节点
        if not root_candidates:
            logger.debug(f"[StateTableEnable] _find_snapshot_subplans - 未找到 root 候选，使用所有 snapshot operator")
            root_candidates = snapshot_operators
        else:
            logger.debug(f"[StateTableEnable] _find_snapshot_subplans - 找到 {len(root_candidates)} 个 root 候选")
            logger.debug(f"[StateTableEnable] _find_snapshot_subplans - root_candidates 示例: {root_candidates[:5]}")
        
        processed_operators = set()
        
        for i, root_op in enumerate(root_candidates):
            if root_op in processed_operators:
                logger.debug(f"[StateTableEnable] _find_snapshot_subplans - Root {root_op} 已处理，跳过")
                continue
            
            logger.debug(f"[StateTableEnable] _find_snapshot_subplans - 处理 root {i+1}/{len(root_candidates)}: {root_op}")
                
            # 从root节点开始，找到整个snapshot subplan
            subplan_ops = self._trace_snapshot_subplan(
                root_op, operator_data_types, operator_dependencies, processed_operators
            )
            
            if not subplan_ops:
                logger.debug(f"[StateTableEnable] _find_snapshot_subplans - Root {root_op} 的 subplan 为空，跳过")
                continue
            
            logger.debug(f"[StateTableEnable] _find_snapshot_subplans - Root {root_op} 的 subplan 包含 {len(subplan_ops)} 个 operator")
            logger.debug(f"[StateTableEnable] _find_snapshot_subplans - Subplan operators: {subplan_ops[:10]}")  # 只显示前10个
            
            # 计算subplan的总耗时
            # 按 stage 聚合：同一 stage 内的 operator 是流水线执行的，
            # 取每个 stage 中 subplan operator 的最大耗时，然后跨 stage 相加
            stage_max_times = {}  # stage_id -> max operator elapsed_ms in this stage
            valid_ops = []
            missing_ops = []
            for op_name in subplan_ops:
                if op_name in op_time_map:
                    op_info = op_time_map[op_name]
                    stage_id = op_info.get('stage_id', '')
                    elapsed_ms = op_info['elapsed_ms']
                    valid_ops.append(op_name)
                    if stage_id:
                        stage_max_times[stage_id] = max(stage_max_times.get(stage_id, 0), elapsed_ms)
                else:
                    missing_ops.append(op_name)
            
            # 跨 stage 相加（每个 stage 贡献其中 subplan operator 的最大耗时）
            total_time_ms = sum(stage_max_times.values())
            
            if missing_ops:
                logger.warning(f"[StateTableEnable] _find_snapshot_subplans - Root {root_op}: {len(missing_ops)} 个 operator 在 op_time_map 中未找到")
                logger.debug(f"[StateTableEnable] _find_snapshot_subplans - 缺失的 operators: {missing_ops[:5]}")
            
            if total_time_ms == 0:
                logger.warning(f"[StateTableEnable] _find_snapshot_subplans - Root {root_op} 的 subplan 总耗时为0，跳过（可能是 operator ID 不匹配）")
                # 即使耗时为0，也要标记这些 operator 为已处理，避免重复分析
                processed_operators.update(subplan_ops)
                continue
            
            percentage = (total_time_ms / total_job_time * 100)
            logger.debug(f"[StateTableEnable] _find_snapshot_subplans - Root {root_op} 的 subplan: {total_time_ms}ms, 占比 {percentage:.1f}%")
            
            # 构建subplan骨架
            skeleton = self._build_subplan_skeleton(valid_ops, op_time_map, context)
            logger.debug(f"[StateTableEnable] _find_snapshot_subplans - Root {root_op} 的骨架包含 {len(skeleton)} 个重要算子")
            
            # **关键修复**: 找到root operator所在的stage
            root_stage = self._find_operator_stage(root_op, context)
            logger.debug(f"[StateTableEnable] _find_snapshot_subplans - Root {root_op} 所在 stage: {root_stage}")
            
            subplans.append({
                'root_operator': root_op,  # 现在是带类型的名称
                'root_stage': root_stage,
                'operators': valid_ops,  # 现在是带类型的名称列表
                'total_time_ms': total_time_ms,
                'percentage': percentage,
                'skeleton': skeleton
            })
            
            # 标记已处理的operator
            processed_operators.update(valid_ops)
        
        # 按占比排序
        subplans.sort(key=lambda x: x['percentage'], reverse=True)
        logger.debug(f"[StateTableEnable] _find_snapshot_subplans - 找到 {len(subplans)} 个 snapshot subplan")
        
        return subplans

    def _run_incremental_analyzer_for_data_types(self, context: Dict) -> Dict:
        """
        运行增量算法分析器以获取 operator 数据类型
        
        这个方法独立于 enable_incremental_algorithm_analysis 标志，
        因为 snapshot subplan 分析总是需要 operator 数据类型信息
        
        Returns:
            {op_id: 'delta'/'snapshot'/'unknown'}
        """
        try:
            aligned_stages = context.get('aligned_stages', {})
            if not aligned_stages:
                return {}
            
            # 将所有 stage 的 operators 合并成一个全局 plan
            all_operators = []
            for stage_id, stage_data in aligned_stages.items():
                operators = stage_data.get('plan_operators', [])
                all_operators.extend(operators)
            
            if not all_operators:
                return {}
            
            # 创建全局 plan 并分析
            global_plan = {'operators': all_operators}
            
            from ....utils.incremental_algorithm_analyzer import IncrementalAlgorithmAnalyzer
            analyzer = IncrementalAlgorithmAnalyzer(global_plan)
            result = analyzer.analyze()
            
            operator_data_types = result.get('operator_data_types', {})
            
            # 同时保存 operator_dependencies 到 context（如果还没有）
            if 'operator_dependencies' not in context:
                # 从 aligned_stages 构建依赖关系
                dependencies = {}
                for stage_id, stage_data in aligned_stages.items():
                    operators = stage_data.get('plan_operators', [])
                    for op in operators:
                        op_id = op.get('id')
                        if op_id:
                            input_ids = op.get('inputIds', [])
                            dependencies[str(op_id)] = [str(iid) for iid in input_ids]
                
                logger.debug(f"[StateTableEnable] _run_incremental_analyzer - 构建了 {len(dependencies)} 个依赖关系")
                logger.debug(f"[StateTableEnable] _run_incremental_analyzer - dependencies keys 示例: {list(dependencies.keys())[:5]}")
                context['operator_dependencies'] = dependencies
            
            return operator_data_types
            
        except Exception as e:
            logger.error(f"[StateTableEnable] 运行增量算法分析器失败: {str(e)}")
            import traceback
            logger.debug(traceback.format_exc())
            return {}

    def _find_operator_stage(self, operator_id: str, context: Dict) -> str:
        """
        查找operator所在的stage
        
        Args:
            operator_id: operator ID (可能包含前缀，如 'TableScan_op_100')
            context: 分析上下文
            
        Returns:
            stage_id 或 'unknown'
        """
        aligned_stages = context.get('aligned_stages', {})
        
        # 尝试直接匹配
        for stage_id, stage_data in aligned_stages.items():
            operators = stage_data.get('plan_operators', [])
            for op in operators:
                op_id = op.get('id')
                if op_id == operator_id:
                    return stage_id
        
        # 如果直接匹配失败，尝试部分匹配（去掉前缀）
        # 例如：'TableScan_op_100' 匹配 'op_100'
        if '_op_' in operator_id:
            short_id = 'op_' + operator_id.split('_op_')[-1]
            for stage_id, stage_data in aligned_stages.items():
                operators = stage_data.get('plan_operators', [])
                for op in operators:
                    op_id = op.get('id')
                    if op_id == short_id:
                        return stage_id
        
        # 如果还是找不到，尝试从 operator_analysis 中获取
        operator_analysis = context.get('operator_analysis', [])
        for op_analysis in operator_analysis:
            if op_analysis.get('operator_id') == operator_id:
                return op_analysis.get('stage_id', 'unknown')
        
        logger.warning(f"[StateTableEnable] _find_operator_stage - 未找到 operator {operator_id} 所在的 stage")
        return 'unknown'

    def _get_operator_dependencies(self, context: Dict) -> Dict:
        """
        获取operator依赖关系
        
        Returns:
            {op_id: [input_op_ids]}
        """
        # 尝试从context中获取已构建的依赖关系
        dependencies = context.get('operator_dependencies', {})
        if dependencies:
            logger.debug(f"[StateTableEnable] _get_operator_dependencies - 从 context 获取了 {len(dependencies)} 个依赖关系")
            return dependencies
        
        # 如果没有，尝试从aligned_stages构建
        aligned_stages = context.get('aligned_stages', {})
        dependencies = {}
        
        for stage_id, stage_data in aligned_stages.items():
            operators = stage_data.get('plan_operators', [])
            for op in operators:
                op_id = op.get('id')
                if op_id:
                    input_ids = op.get('inputIds', [])
                    dependencies[op_id] = input_ids
        
        logger.debug(f"[StateTableEnable] _get_operator_dependencies - 从 aligned_stages 构建了 {len(dependencies)} 个依赖关系")
        if dependencies:
            logger.debug(f"[StateTableEnable] _get_operator_dependencies - 依赖关系 keys 示例: {list(dependencies.keys())[:5]}")
        
        return dependencies

    def _trace_snapshot_subplan(self, root_op: str, operator_data_types: Dict, 
                               operator_dependencies: Dict, processed_operators: set) -> List[str]:
        """
        从root节点开始追踪整个snapshot subplan
        
        **关键修复**（根据用户反馈）：
        对于全snapshot的subplan，公共节点（被多个snapshot算子访问）也属于这个subplan，
        不应该因为processed_operators而被跳过。
        
        Args:
            root_op: root operator 名称（如 "ShuffleRead39"）
            operator_data_types: operator类型映射（键是算子名称）
            operator_dependencies: operator依赖关系（键是算子名称）
            processed_operators: 已处理的operator集合（仅用于避免重复分析不同的root）
            
        Returns:
            subplan包含的所有operator名称列表
        """
        if root_op in processed_operators:
            return []
        
        subplan_ops = []
        visited = set()
        
        def dfs_trace(op_name):
            # **关键修复**: 只检查visited，不检查processed_operators
            # 因为公共节点也应该属于这个subplan
            if op_name in visited:
                return
            
            visited.add(op_name)
            
            # 检查operator类型
            op_type = operator_data_types.get(op_name)
            
            if op_type == 'snapshot':
                subplan_ops.append(op_name)
                
                # 继续追踪上游依赖
                input_ops = operator_dependencies.get(op_name, [])
                for input_op in input_ops:
                    dfs_trace(input_op)
            elif op_type == 'delta':
                # 遇到delta算子，停止追踪（边界条件）
                return
            else:
                # 未知类型，保守处理，停止追踪
                return
        
        dfs_trace(root_op)
        
        return subplan_ops

    def _build_subplan_skeleton(self, operator_ids: List[str], op_time_map: Dict, 
                               context: Dict) -> List[Dict]:
        """
        构建subplan的骨架信息
        
        Args:
            operator_ids: subplan包含的operator ID列表
            op_time_map: operator耗时映射
            context: 分析上下文
            
        Returns:
            骨架信息列表
        """
        skeleton = []
        aligned_stages = context.get('aligned_stages', {})
        
        # 按重要性和耗时排序
        important_ops = []
        
        for op_id in operator_ids:
            if op_id not in op_time_map:
                continue
                
            op_info = op_time_map[op_id]
            stage_id = op_info['stage_id']
            elapsed_ms = op_info['elapsed_ms']
            
            # 获取operator类型
            op_type = self._get_operator_type_from_analysis(op_info['analysis'])
            
            if op_type in ['aggregate', 'join', 'window', 'tablescan']:
                important_ops.append({
                    'operator_id': op_id,
                    'stage_id': stage_id,
                    'type': op_type,
                    'elapsed_ms': elapsed_ms
                })
        
        # 按重要性和耗时排序
        importance_order = {'aggregate': 1, 'join': 2, 'window': 3, 'tablescan': 4}
        important_ops.sort(key=lambda x: (importance_order.get(x['type'], 5), -x['elapsed_ms']))
        
        for op in important_ops[:10]:  # 只取前10个重要算子
            stage_id = op['stage_id']
            op_type = op['type']
            
            skeleton_item = {
                'stage_id': stage_id,
                'operator_id': op['operator_id'],
                'type': op_type,
                'elapsed_ms': op['elapsed_ms'],
                'details': ''
            }
            
            # 获取详细信息
            if stage_id in aligned_stages:
                stage_data = aligned_stages[stage_id]
                plan = stage_data.get('plan', {})
                
                if op_type == 'aggregate':
                    skeleton_item['details'] = self._extract_aggregate_functions(plan)
                elif op_type == 'window':
                    skeleton_item['details'] = self._extract_window_functions(plan)
                elif op_type == 'join':
                    skeleton_item['details'] = self._extract_join_info(plan)
                elif op_type == 'tablescan':
                    skeleton_item['details'] = self._extract_table_info(plan)
            
            skeleton.append(skeleton_item)
        
        return skeleton

    def _get_operator_type_from_analysis(self, op_analysis: Dict) -> str:
        """从算子分析中提取算子类型"""
        operator_id = op_analysis.get('operator_id', '')
        
        # 简单的类型识别
        if 'Aggregate' in operator_id or 'HashAgg' in operator_id:
            return 'aggregate'
        elif 'Join' in operator_id or 'HashJoin' in operator_id:
            return 'join'
        elif 'Window' in operator_id:
            return 'window'
        elif 'TableScan' in operator_id or 'Scan' in operator_id:
            return 'tablescan'
        else:
            return 'other'

    def _format_subplan_skeleton(self, subplan: Dict) -> str:
        """格式化subplan骨架信息为可读字符串"""
        skeleton = subplan.get('skeleton', [])
        if not skeleton:
            return f"Root: {subplan['root_operator']} (无详细骨架)"
        
        formatted_items = []
        for item in skeleton:
            op_type = item['type']
            details = item['details']
            elapsed_ms = item['elapsed_ms']
            
            if op_type == 'aggregate':
                formatted_items.append(f"Aggregate({details}, {elapsed_ms}ms)")
            elif op_type == 'join':
                formatted_items.append(f"Join({details}, {elapsed_ms}ms)")
            elif op_type == 'window':
                formatted_items.append(f"Window({details}, {elapsed_ms}ms)")
            elif op_type == 'tablescan':
                formatted_items.append(f"TableScan({details}, {elapsed_ms}ms)")
        
        return ' -> '.join(formatted_items)

    def _format_subplan_tree(self, subplan: Dict, context: Dict) -> str:
        """
        格式化 subplan 为树形结构
        
        Args:
            subplan: subplan 信息，包含 operators 列表（带类型的算子名称列表）
            context: 分析上下文，包含 plan 和 metrics
            
        Returns:
            树形结构的字符串表示
        """
        operator_names = subplan.get('operators', [])
        if not operator_names:
            return f"Root: {subplan['root_operator']} (无算子信息)"
        
        logger.debug(f"[_format_subplan_tree] subplan 包含 {len(operator_names)} 个算子: {operator_names[:10]}...")
        
        # 获取 aligned_stages
        aligned_stages = context.get('aligned_stages', {})
        
        # 使用全局的 operator_analysis（列表格式）
        operator_analysis_list = context.get('operator_analysis', [])
        
        # 将 operator_analysis 列表转换为字典（键是 operator_id）
        operator_analysis = {}
        for op_info in operator_analysis_list:
            op_id = op_info.get('operator_id')
            if op_id:
                operator_analysis[op_id] = op_info
        
        logger.debug(f"[_format_subplan_tree] operator_analysis 包含 {len(operator_analysis)} 个算子")
        
        # **关键修复**: 需要从所有 stage 收集算子依赖关系，而不仅仅是 root_stage
        # 因为 subplan 可能跨越多个 stage
        all_operator_deps_by_id = {}
        all_id_to_name = {}
        
        for stage_id, stage_data in aligned_stages.items():
            plan = stage_data.get('plan', {})
            if not plan:
                continue
            
            # 构建该 stage 的算子依赖关系
            stage_deps = self._build_operator_dependencies_by_id(plan)
            all_operator_deps_by_id.update(stage_deps)
            
            # 构建该 stage 的 ID 到名称映射
            for op in plan.get('operators', []):
                op_id = self._get_operator_id(op)
                op_name = self._get_operator_name(op)
                if op_id:
                    all_id_to_name[op_id] = op_name
        
        logger.debug(f"[_format_subplan_tree] 从所有 stage 收集到 {len(all_operator_deps_by_id)} 个算子依赖关系")
        logger.debug(f"[_format_subplan_tree] 从所有 stage 收集到 {len(all_id_to_name)} 个 ID 映射")
        
        # 将依赖关系从 ID 转换为名称
        operator_deps = {}
        for op_id, input_ids in all_operator_deps_by_id.items():
            op_name = all_id_to_name.get(op_id, op_id)
            input_names = [all_id_to_name.get(inp_id, inp_id) for inp_id in input_ids]
            operator_deps[op_name] = input_names
        
        logger.debug(f"[_format_subplan_tree] operator_deps 包含 {len(operator_deps)} 个算子")
        if operator_deps:
            # 打印前几个依赖关系作为示例
            sample_items = list(operator_deps.items())[:3]
            for op_name, inputs in sample_items:
                logger.debug(f"[_format_subplan_tree]   {op_name} -> {inputs}")
        
        # 找到 root 算子名称（已经是带类型的名称了）
        root_op_name = subplan['root_operator']
        logger.debug(f"[_format_subplan_tree] root_op_name = {root_op_name}")
        
        # 生成树形结构
        tree_lines = []
        tree_lines.append(f"\n算子依赖树 (Root: {root_op_name}, 共{len(operator_names)}个算子):")
        tree_lines.append("=" * 80)
        
        # 使用 DFS 遍历生成树形结构
        visited = set()
        self._print_operator_tree(
            root_op_name, None, operator_analysis, operator_deps, 
            operator_names, "", True, visited, tree_lines
        )
        
        tree_lines.append("=" * 80)
        return '\n'.join(tree_lines)
    
    def _build_operator_dependencies_by_id(self, plan: Dict) -> Dict[str, List[str]]:
        """
        构建算子依赖关系映射（使用 ID）
        
        Returns:
            Dict[operator_id, List[input_operator_ids]]
        """
        operators = plan.get('operators', [])
        operator_deps = {}
        
        # 构建依赖关系
        for op in operators:
            op_id = self._get_operator_id(op)
            if not op_id:
                continue
            
            input_ids = op.get('inputIds', [])
            operator_deps[op_id] = input_ids
        
        return operator_deps
    
    
    def _get_operator_id(self, op: Dict) -> str:
        """获取算子的 ID"""
        if 'id' in op:
            return str(op['id'])
        
        # 尝试从算子类型的子对象中获取
        for key, value in op.items():
            if isinstance(value, dict) and 'id' in value:
                return str(value['id'])
        
        return None
    
    def _get_operator_name(self, op: Dict) -> str:
        """
        获取算子的名称（类型+ID）
        
        例如：HashJoin3, TableScan1, ShuffleRead5
        """
        op_id = self._get_operator_id(op)
        
        if not op_id:
            return 'UnknownOp'
        
        # **关键修复**: 如果 op_id 已经包含类型名称（如 "TableScan265"），直接返回
        # 检查 op_id 是否以字母开头（说明已经包含类型名）
        if op_id and op_id[0].isalpha():
            return op_id
        
        # 否则，从算子的键名推断类型名称并拼接
        for key in op.keys():
            key_lower = key.lower()
            
            # 优先匹配具体的算子类型
            if key_lower == 'shuffleread':
                return f"ShuffleRead{op_id}"
            elif key_lower == 'shufflewrite':
                return f"ShuffleWrite{op_id}"
            elif 'hashjoin' in key_lower:
                return f"HashJoin{op_id}"
            elif 'hashagg' in key_lower:
                return f"HashAgg{op_id}"
            elif 'tablescan' in key_lower:
                return f"TableScan{op_id}"
            elif key_lower == 'window':
                return f"Window{op_id}"
            elif key_lower == 'calc':
                return f"Calc{op_id}"
            elif key_lower == 'filter':
                return f"Filter{op_id}"
            elif 'exchange' in key_lower:
                return f"Exchange{op_id}"
            elif 'tablesink' in key_lower:
                return f"TableSink{op_id}"
        
        # 如果没有匹配到，使用通用名称
        return f"Op{op_id}"
    
    def _print_operator_tree(self, op_name: str, plan: Dict, operator_analysis: Dict,
                            operator_deps: Dict[str, List[str]], subplan_operators: List[str],
                            prefix: str, is_last: bool, visited: Set[str], 
                            tree_lines: List[str]):
        """
        递归打印算子树
        
        Args:
            op_name: 当前算子名称
            plan: plan 对象 (已废弃，传 None 即可)
            operator_analysis: 算子分析结果
            operator_deps: 算子依赖关系
            subplan_operators: subplan 包含的算子列表
            prefix: 当前行的前缀（用于缩进）
            is_last: 是否是最后一个子节点
            visited: 已访问的算子集合（避免循环）
            tree_lines: 输出行列表
        """
        # 检查是否在 subplan 中
        if op_name not in subplan_operators:
            return
        
        # 检查是否已访问（避免循环）
        if op_name in visited:
            tree_lines.append(f"{prefix}{'└── ' if is_last else '├── '}{op_name} (已访问)")
            return
        
        visited.add(op_name)
        
        # 获取算子信息
        op_info = self._get_operator_info_simple(op_name, operator_analysis)
        
        # 打印当前算子
        connector = "└── " if is_last else "├── "
        tree_lines.append(f"{prefix}{connector}{op_info}")
        
        # 获取输入算子
        inputs = operator_deps.get(op_name, [])
        
        # 过滤出在 subplan 中的输入
        inputs_in_subplan = [inp for inp in inputs if inp in subplan_operators]
        
        # 递归打印子节点
        for i, input_op in enumerate(inputs_in_subplan):
            is_last_child = (i == len(inputs_in_subplan) - 1)
            new_prefix = prefix + ("    " if is_last else "│   ")
            self._print_operator_tree(
                input_op, plan, operator_analysis, operator_deps,
                subplan_operators, new_prefix, is_last_child, visited, tree_lines
            )
    
    def _get_operator_info_simple(self, op_name: str, operator_analysis: Dict) -> str:
        """
        获取算子的详细信息用于显示（简化版，不需要 plan）
        
        Returns:
            格式化的算子信息字符串
        """
        # 从 operator_analysis 获取时间信息
        op_metrics = operator_analysis.get(op_name, {})
        # 尝试多个可能的时间字段
        elapsed_ms = op_metrics.get('elapsed_ms') or op_metrics.get('max_time_ms') or op_metrics.get('avg_time_ms') or 0
        
        # 从算子名称推断类型
        op_type = 'unknown'
        if 'Join' in op_name:
            op_type = 'join'
        elif 'Agg' in op_name or 'Aggregate' in op_name:
            op_type = 'aggregate'
        elif 'Scan' in op_name:
            op_type = 'tablescan'
        elif 'Window' in op_name:
            op_type = 'window'
        elif 'Calc' in op_name:
            op_type = 'calc'
        elif 'Filter' in op_name:
            op_type = 'filter'
        elif 'Shuffle' in op_name or 'Exchange' in op_name:
            op_type = 'exchange'
        
        return f"{op_name} [{op_type}] - {elapsed_ms:.1f}ms"
    
    def _get_operator_info(self, op_name: str, plan: Dict, operator_analysis: Dict) -> str:
        """
        获取算子的详细信息用于显示
        
        Returns:
            格式化的算子信息字符串
        """
        # 从 operator_analysis 获取时间信息
        op_metrics = operator_analysis.get(op_name, {})
        elapsed_ms = op_metrics.get('elapsed_ms', 0)
        
        # 从 plan 获取算子类型和详细信息
        operators = plan.get('operators', [])
        op_obj = None
        for op in operators:
            if self._get_operator_name(op) == op_name:
                op_obj = op
                break
        
        if not op_obj:
            return f"{op_name} ({elapsed_ms:.1f}ms)"
        
        # 获取算子类型
        op_type = self._get_operator_type_from_obj(op_obj)
        
        # 根据类型添加详细信息
        details = []
        
        if op_type == 'aggregate':
            # 获取聚合函数
            agg_funcs = self._extract_aggregate_functions_from_op(op_obj)
            if agg_funcs:
                details.append(f"funcs={','.join(agg_funcs[:3])}")  # 最多显示3个
        elif op_type == 'join':
            # 获取 join 类型
            join_type = self._get_join_type_from_op(op_obj)
            if join_type:
                details.append(f"type={join_type}")
        elif op_type == 'tablescan':
            # 获取表名
            table_name = self._get_table_name_from_op(op_obj)
            if table_name:
                details.append(f"table={table_name}")
        
        details_str = ', '.join(details) if details else ''
        if details_str:
            return f"{op_name} [{op_type}] ({details_str}) - {elapsed_ms:.1f}ms"
        else:
            return f"{op_name} [{op_type}] - {elapsed_ms:.1f}ms"
    
    def _get_operator_type_from_obj(self, op: Dict) -> str:
        """从算子对象获取类型"""
        for key in op.keys():
            key_lower = key.lower()
            if 'join' in key_lower:
                return 'join'
            elif 'agg' in key_lower or 'aggregate' in key_lower:
                return 'aggregate'
            elif 'scan' in key_lower:
                return 'tablescan'
            elif 'window' in key_lower:
                return 'window'
            elif 'calc' in key_lower:
                return 'calc'
            elif 'filter' in key_lower:
                return 'filter'
            elif 'exchange' in key_lower or 'shuffle' in key_lower:
                return 'exchange'
        return 'unknown'
    
    def _extract_aggregate_functions_from_op(self, op: Dict) -> List[str]:
        """从算子对象提取聚合函数"""
        functions = []
        
        if 'hashAgg' in op:
            hash_agg = op['hashAgg']
            if 'aggregate' in hash_agg and isinstance(hash_agg['aggregate'], dict):
                aggregate = hash_agg['aggregate']
                if 'aggregateCalls' in aggregate:
                    for call in aggregate['aggregateCalls']:
                        if isinstance(call, dict) and 'function' in call:
                            func_obj = call['function']
                            if isinstance(func_obj, dict):
                                if 'function' in func_obj and isinstance(func_obj['function'], dict):
                                    func_name = func_obj['function'].get('name')
                                    if func_name:
                                        functions.append(str(func_name))
                                elif 'name' in func_obj:
                                    func_name = func_obj.get('name')
                                    if func_name:
                                        functions.append(str(func_name))
        
        return functions
    
    def _get_join_type_from_op(self, op: Dict) -> str:
        """从算子对象获取 join 类型"""
        for key in op.keys():
            if 'join' in key.lower():
                join_obj = op[key]
                if isinstance(join_obj, dict):
                    if 'join' in join_obj and isinstance(join_obj['join'], dict):
                        join_type = join_obj['join'].get('type')
                        if join_type:
                            return str(join_type).lower()
                    if 'type' in join_obj:
                        join_type = join_obj.get('type')
                        if join_type:
                            return str(join_type).lower()
        return 'unknown'
    
    def _get_table_name_from_op(self, op: Dict) -> str:
        """从算子对象获取表名"""
        if 'tableScan' in op:
            table_scan = op['tableScan']
            if isinstance(table_scan, dict):
                # 尝试多种可能的字段
                for field in ['tableName', 'table', 'name']:
                    if field in table_scan:
                        return str(table_scan[field])
                
                # 尝试从 table 对象中获取
                if 'table' in table_scan and isinstance(table_scan['table'], dict):
                    table_obj = table_scan['table']
                    for field in ['name', 'tableName']:
                        if field in table_obj:
                            return str(table_obj[field])
        
        return 'unknown'

    def _extract_aggregate_functions(self, plan: Dict) -> str:
        """提取聚集函数信息"""
        try:
            operators = plan.get('operators', [])
            agg_functions = []
            
            for op in operators:
                if 'hashAgg' in op or 'hashAggregate' in op:
                    hash_agg = op.get('hashAgg') or op.get('hashAggregate')
                    if hash_agg and 'aggregate' in hash_agg:
                        agg_calls = hash_agg['aggregate'].get('aggregateCalls', [])
                        for call in agg_calls:
                            func_name = call.get('function', {}).get('function', {}).get('name', '')
                            if not func_name:
                                func_name = call.get('function', {}).get('name', '')
                            if func_name and func_name not in agg_functions:
                                agg_functions.append(func_name)
            
            return ', '.join(agg_functions) if agg_functions else 'unknown'
        except Exception:
            return 'unknown'
    
    def _extract_window_functions(self, plan: Dict) -> str:
        """提取窗口函数信息"""
        try:
            operators = plan.get('operators', [])
            window_functions = []
            
            for op in operators:
                if 'window' in op:
                    # 简化处理，提取窗口函数名称
                    op_str = json.dumps(op)
                    if 'ROW_NUMBER' in op_str:
                        window_functions.append('ROW_NUMBER')
                    if 'RANK' in op_str:
                        window_functions.append('RANK')
                    if 'DENSE_RANK' in op_str:
                        window_functions.append('DENSE_RANK')
            
            return ', '.join(window_functions) if window_functions else 'window'
        except Exception:
            return 'window'
    
    def _extract_join_info(self, plan: Dict) -> str:
        """提取 join 信息"""
        try:
            operators = plan.get('operators', [])
            join_types = []
            
            for op in operators:
                if 'hashJoin' in op:
                    join_type = op.get('hashJoin', {}).get('join', {}).get('type', 'INNER')
                    if join_type not in join_types:
                        join_types.append(join_type)
            
            return ', '.join(join_types) if join_types else 'JOIN'
        except Exception:
            return 'JOIN'
    
    def _extract_table_info(self, plan: Dict) -> str:
        """提取表信息"""
        try:
            operators = plan.get('operators', [])
            tables = []
            
            for op in operators:
                if 'tableScan' in op:
                    table_scan = op['tableScan']
                    table_path = table_scan.get('table', {}).get('path', [])
                    if table_path:
                        table_name = '.'.join(table_path)
                        if table_name not in tables:
                            tables.append(table_name)
            
            return ', '.join(tables) if tables else 'table'
        except Exception:
            return 'table'
