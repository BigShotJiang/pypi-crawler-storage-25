#!/usr/bin/env python3
"""Row Number=1 Pattern 检查规则"""
import json
from typing import Dict, List
from ...base_rule import BaseRule
from ....utils.append_only_detector import AppendOnlyDetector


class RowNumberCheck(BaseRule):
    name = "row_number_check"
    category = "incremental/state_table"
    description = "检查 window 算子在 append-only delta 输入时的优化"
    ROW_NUMBER_PATTERNS = ['ROW_NUMBER', 'row_number', 'rn=1', 'rn = 1']

    def _has_incremental_hint(self, op: Dict) -> bool:
        """
        检查算子是否有增量相关的 hint
        
        根据 prompt 4.2.1.2 和 4.2.0 的要求：
        "同时关于状态表这些优化必须是对应算子的对应增量算法，如aggregate则必须是增量算法产生的，join/window等都类似；可以根据4.2.1.2来判断；"
        
        只有有增量 hint 的算子才是增量算法的一部分，才需要进行状态表优化分析。
        
        Args:
            op: 算子对象
            
        Returns:
            是否有增量相关的 hint
        """
        try:
            op_str = json.dumps(op)
            
            # 检查是否包含增量相关的 hint pattern
            incremental_patterns = [
                'IncrementalLinearTopKWindowRule',
                'IncrementalLinearTopKWindowRuleV2',
                'IncrementalWindowSetDeltaRule',
                'IncrementalAggregateRule',
                'IncrementalJoinRule',
                'Rule:Incremental',
                'DeltaState',
                'HINT=delta'
            ]
            
            for pattern in incremental_patterns:
                if pattern in op_str:
                    return True
                    
            return False
            
        except Exception:
            return False

    def _check_linear_topk_rule(self, window_op: Dict) -> bool:
        """
        检查 window 算子是否使用 IncrementalLinearTopKWindowRule 增量算法

        根据 prompt 4.2.3 更新：检查 window 算子是否包含 IncrementalLinearTopKWindowRule hint
        
        注意：支持 V1 和 V2 版本的规则：
        - IncrementalLinearTopKWindowRule (V1)
        - IncrementalLinearTopKWindowRuleV2 (V2)

        Args:
            window_op: Window 算子对象

        Returns:
            是否使用 IncrementalLinearTopKWindowRule (V1 或 V2)
        """
        try:
            window_str = json.dumps(window_op)
            # 检查是否包含 IncrementalLinearTopKWindowRule (支持 V1 和 V2)
            return ('IncrementalLinearTopKWindowRule' in window_str or 
                    'IncrementalLinearTopKWindowRuleV2' in window_str)
        except Exception:
            return False

    def _check_rn_equals_one_pattern(self, calc_op: Dict) -> bool:
        """
        检查 calc 算子是否包含 row number=1 的 pattern

        根据 prompt 4.2.3 的更新（original_prompt.md 第 102-103 行）：
        rn=1 pattern 可以通过 JSON 结构识别：
        - function.name = "EQ" (表示等于 =)
        - arguments[1].constant.bigint = "1" (表示常量 1)
        - 这表示 xx=1 的 pattern

        示例 JSON 结构：
        {
            "function": {
                "name": "EQ",
                "arguments": [
                    {"reference": {...}},
                    {"constant": {"bigint": "1"}}
                ]
            }
        }

        Args:
            calc_op: Calc 算子对象

        Returns:
            是否包含 rn=1 pattern
        """
        try:
            # 方法1: 检查简单的字符串 pattern（向后兼容）
            calc_str = json.dumps(calc_op)
            if any(p in calc_str for p in self.ROW_NUMBER_PATTERNS):
                return True

            # 方法2: 检查 JSON 结构中的 EQ(xx, 1) pattern
            # 递归查找所有 function 对象
            def find_eq_one_pattern(obj):
                if isinstance(obj, dict):
                    # 检查是否是 EQ function
                    if 'function' in obj:
                        func = obj['function']
                        if isinstance(func, dict):
                            # 检查 function.name 是否是 EQ
                            if func.get('name') == 'EQ':
                                # 检查 arguments 是否包含 constant.bigint = "1"
                                args = func.get('arguments', [])
                                if isinstance(args, list) and len(args) >= 2:
                                    for arg in args:
                                        if isinstance(arg, dict) and 'constant' in arg:
                                            constant = arg['constant']
                                            if isinstance(constant, dict):
                                                # 检查 bigint 或 int 字段是否为 "1" 或 1
                                                bigint_val = constant.get('bigint')
                                                int_val = constant.get('int')
                                                if bigint_val == '1' or bigint_val == 1 or int_val == '1' or int_val == 1:
                                                    return True

                    # 递归检查所有子对象
                    for value in obj.values():
                        if find_eq_one_pattern(value):
                            return True

                elif isinstance(obj, list):
                    # 递归检查列表中的所有元素
                    for item in obj:
                        if find_eq_one_pattern(item):
                            return True

                return False

            return find_eq_one_pattern(calc_op)

        except Exception:
            # 如果解析失败，回退到简单的字符串匹配
            return False

    def check(self, stage_data: Dict, context: Dict) -> bool:
        plan = stage_data.get('plan', {})
        plan_str = json.dumps(plan)
        # 检查是否包含 window 算子
        has_window = 'window' in plan_str.lower() or 'Window' in plan_str
        return has_window

    def analyze(self, stage_data: Dict, context: Dict) -> Dict:
        stage_id = stage_data.get('stage_id', 'unknown')
        plan = stage_data.get('plan', {})
        settings = context.get('settings', {})
        findings, recommendations, insights = [], [], []

        # 根据 prompt 4.2.3 的要求（更新后）：
        # 1. 检查 window 算子的父节点是否是 calc，且存在 row number=1 的 pattern
        # 2. 检查 window 的输入是否是 append-only 的 delta
        # 3. 如果是 append-only 且 rn=1 的 pattern，但 window 没有使用 IncrementalLinearTopKWindowRule 增量算法，
        #    则设置 cz.optimizer.incremental.window.sd.to.sd.rule.enable=false
        # 4. 检查 tablescan 的 table 属性是否有 incr.append.only.table=true

        window_info = self._analyze_window_operators(plan, context)

        for window_idx, info in window_info.items():
            has_rn_pattern = info['has_rn_pattern']
            is_append_only_input = info['is_append_only_input']
            append_only_tables = info['append_only_tables']
            uses_linear_topk_rule = info['uses_linear_topk_rule']

            if is_append_only_input:
                # "输入是 append-only delta" 是纯事实，降级为 analysis_scope
                self.add_analysis_detail(context, f'window_{window_idx}_append_only', {
                    'is_append_only_input': True,
                    'has_rn_pattern': has_rn_pattern,
                    'uses_linear_topk_rule': uses_linear_topk_rule,
                }, stage_id=stage_id)

                # 根据 prompt 4.2.3 更新：如果是 append-only 且 rn=1 的 pattern，
                # 检查 window 是否使用 IncrementalLinearTopKWindowRule 增量算法
                if has_rn_pattern:
                    if uses_linear_topk_rule:
                        # 已经使用了 IncrementalLinearTopKWindowRule，这是期望的行为
                        # 纯正面事实，不作为 insight 输出
                        pass
                    else:
                        # 没有使用 IncrementalLinearTopKWindowRule，需要优化
                        param = 'cz.optimizer.incremental.window.sd.to.sd.rule.enable'
                        # 根据规则 4.2.3：参数不存在 OR 值 = 'true' 时才推荐
                        if param not in settings or settings.get(param) == 'true':
                            recommendations.append(self.build_recommendation_with_table_check(
                                param, 'false', 2,
                                f"Stage {stage_id}: Window 算子输入是 append-only delta 且有 rn=1 pattern，"
                                f"但未使用 IncrementalLinearTopKWindowRule 增量算法",
                                'MEDIUM', context, settings.get(param)))

                # 检查 tablescan 的 table 属性
                for table_name, has_property in append_only_tables.items():
                    if not has_property:
                        # 检查是否在 flag 中设置了
                        append_only_setting = settings.get('cz.optimizer.incremental.append.only.tables', '')
                        if table_name not in append_only_setting:
                            findings.append(self.create_finding(
                                'MISSING_APPEND_ONLY_PROPERTY', stage_id, 'WARNING',
                                f"表 {table_name} 是 append-only 但缺少 incr.append.only.table=true 属性"
                            ))
                            insights.append(self.create_insight(
                                f"Stage {stage_id}: 建议为表 {table_name} 添加 incr.append.only.table=true 属性 "
                                f"或设置 cz.optimizer.incremental.append.only.tables='{table_name}'",
                                stage_id
                            ))

        return {
            'findings': findings,
            'recommendations': recommendations,
            'insights': insights,
            'window_info': window_info
        }

    def _analyze_window_operators(self, plan: Dict, context: Dict) -> Dict:
        """
        分析 window 算子及其输入

        Returns:
            {
                window_idx: {
                    'has_rn_pattern': bool,  # 父节点 calc 是否有 row number=1 pattern
                    'is_append_only_input': bool,  # 输入是否是 append-only delta
                    'append_only_tables': {table_name: has_property},  # append-only 表及其属性
                    'uses_linear_topk_rule': bool  # 是否使用 IncrementalLinearTopKWindowRule
                }
            }
        """
        window_info = {}
        operators = plan.get('operators', [])

        # 构建算子依赖关系
        op_dependencies = {}
        for idx, op in enumerate(operators):
            if 'inputIds' in op:
                op_dependencies[idx] = op['inputIds']
            elif idx > 0:
                op_dependencies[idx] = [idx - 1]
            else:
                op_dependencies[idx] = []

        # 查找所有 window 算子
        for idx, op in enumerate(operators):
            if 'window' not in json.dumps(op).lower():
                continue

            # 根据 prompt 4.2.0 和相关要求：
            # "同时关于状态表这些优化必须是对应算子的对应增量算法，如aggregate则必须是增量算法产生的，join/window等都类似；可以根据4.2.1.2来判断；"
            # 
            # 首先检查 window 是否是增量算法的一部分（有增量 hint）
            # 只有增量算法的 window 才需要进行状态表优化分析
            
            # 检查是否有增量相关的 hint
            has_incremental_hint = self._has_incremental_hint(op)
            if not has_incremental_hint:
                # 没有增量 hint 的 window 不是增量算法的一部分，跳过
                continue

            # 检查父节点是否是 calc 且有 row number=1 pattern
            # 根据 prompt 4.2.3 的更新，使用新的 JSON 结构检查方法
            has_rn_pattern = False
            for parent_idx in range(idx + 1, len(operators)):
                parent_op = operators[parent_idx]
                if 'calc' in json.dumps(parent_op).lower():
                    # 使用新的 _check_rn_equals_one_pattern 方法
                    if self._check_rn_equals_one_pattern(parent_op):
                        has_rn_pattern = True
                        break

            # 检查是否使用 IncrementalLinearTopKWindowRule 增量算法
            # 根据 prompt 4.2.3 更新：检查 window 算子是否包含该 rule hint
            uses_linear_topk_rule = self._check_linear_topk_rule(op)

            # 检查输入是否是 append-only delta
            is_append_only_input, append_only_tables = self._check_append_only_input(
                idx, operators, op_dependencies, context
            )

            window_info[idx] = {
                'has_rn_pattern': has_rn_pattern,
                'is_append_only_input': is_append_only_input,
                'append_only_tables': append_only_tables,
                'uses_linear_topk_rule': uses_linear_topk_rule
            }

        return window_info

    def _check_append_only_input(self, window_idx: int, operators: List[Dict],
                                  op_dependencies: Dict, context: Dict) -> tuple:
        """
        检查 window 算子的输入是否是 append-only delta

        根据 prompt 4.2.1.5 的要求，使用增量算法分析器的结果来判断

        Returns:
            (is_append_only, {table_name: has_property})
        """
        # 优先使用 context 中的 operator_append_only_types（来自 IncrementalAlgorithmAnalyzer）
        operator_append_only_types = context.get('operator_append_only_types', {})

        if operator_append_only_types:
            # 获取 window 算子的 ID
            window_op = operators[window_idx]
            window_id = window_op.get('id')

            if window_id and window_id in operator_append_only_types:
                append_only_type = operator_append_only_types[window_id]

                # 如果是 APPEND_ONLY，则返回 True
                if append_only_type == 'append_only':
                    return True, {}
                else:
                    return False, {}

        # 如果 context 中没有信息，回退到原来的方法（搜索 TableScan）
        # 从 window 算子向上游遍历，找到所有 tablescan
        visited = set()
        append_only_tables = {}

        def dfs(idx):
            if idx in visited or idx < 0 or idx >= len(operators):
                return
            visited.add(idx)

            op = operators[idx]

            # 如果是 tablescan，检查是否是 append-only
            if 'tableScan' in op:
                table_scan = op['tableScan']
                table_name = table_scan.get('table', {}).get('name', 'unknown')

                # 使用统一的 AppendOnlyDetector 检查是否为 append-only
                is_append_only = AppendOnlyDetector.is_append_only_scan(op)

                if is_append_only:
                    # 是 append-only，检查是否有 incr.append.only.table=true 属性
                    table_properties = table_scan.get('table', {}).get('properties', {})
                    has_property = table_properties.get('incr.append.only.table') == 'true'
                    append_only_tables[table_name] = has_property

            # 继续向上游遍历
            for input_idx in op_dependencies.get(idx, []):
                if isinstance(input_idx, int):
                    dfs(input_idx)

        dfs(window_idx)

        is_append_only = len(append_only_tables) > 0
        return is_append_only, append_only_tables
