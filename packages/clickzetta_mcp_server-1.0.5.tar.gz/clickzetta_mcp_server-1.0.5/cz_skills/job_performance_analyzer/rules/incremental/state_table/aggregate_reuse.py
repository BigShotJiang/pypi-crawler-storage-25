#!/usr/bin/env python3
"""Aggregate 复用检查规则"""
import json
from typing import Dict, List
from ...base_rule import BaseRule
from ....utils.append_only_detector import AppendOnlyDetector
from ....utils.state_table_checker import StateTableChecker


class AggregateReuse(BaseRule):
    name = "aggregate_reuse"
    category = "incremental/state_table"
    description = "检查聚合计算是否利用了之前的结果"
    ALWAYS_INCREMENTAL = ['SUM', 'COUNT', 'sum', 'count']
    APPEND_ONLY_INCREMENTAL = ['MIN', 'MAX', 'min', 'max']

    def check(self, stage_data: Dict, context: Dict) -> bool:
        plan_str = json.dumps(stage_data.get('plan', {}))
        return 'HashAggregate' in plan_str or 'Aggregate' in plan_str

    def analyze(self, stage_data: Dict, context: Dict) -> Dict:
        stage_id = stage_data.get('stage_id', 'unknown')
        plan = stage_data.get('plan', {})
        settings = context.get('settings', {})
        findings, recommendations, insights = [], [], []

        # 根据 prompt 4.2.6 的要求：
        # 1. aggregate 必须设置上了 hint 包含类似 4.2.1.2 的一些状态 hint
        #    如果不包含，说明该 aggregate 算子不是原始 sql 中的 aggregate，而是其他优化器 rule 等自己生成的
        # 2. 检查当前任务中 aggregate 的计算是否利用上了之前的计算结果
        #    - 对于 SUM，COUNT 希望无论如何都尽量使用之前的结果
        #    - 对于 MIN，MAX 希望在 append-only 的情况下尽量使用之前的结果
        # 3. 如果发现没用上，根据 4.2.5 的方法看看是否存在状态
        # 4. 如果状态存在，根据 4.2.1.5 的方法看看是否有 append-only 的输入
        # 5. 如果是 append-only 但是缺少系统 hint 的，请补充上 hint

        # 获取所有 aggregate，并过滤掉增量算法的辅助 aggregate
        agg_info_list = self._analyze_aggregates_with_hints(plan)

        # 检查是否利用了之前的计算结果（全局检查一次即可）
        has_incremental_marker = self._check_incremental_markers(plan)
        
        # **改进**: 检查整个 job 是否有状态表（全局检查）
        has_state_table = StateTableChecker.check_plan_has_state_table(context)

        for agg_info in agg_info_list:
            op_idx = agg_info['op_idx']
            agg_funcs = agg_info['agg_funcs']
            has_incremental_hint = agg_info['has_incremental_hint']

            # 如果没有增量 hint，跳过（不是原始 SQL 的 aggregate）
            if not has_incremental_hint:
                continue

            # 检查输入是否是 append-only
            is_append_only = self._check_append_only_inputs(plan, op_idx)

            # **关键改进**: 判断整个聚合算子能否做增量优化
            # 规则：取决于最弱的函数
            can_always_incremental, can_append_only_incremental, blocking_funcs = \
                self._check_aggregate_incremental_capability(agg_funcs, is_append_only)
            
            # 如果已经有增量标记，说明已经优化了，跳过
            if has_incremental_marker:
                continue
            
            # **情况1**: 包含 SUM/COUNT，理论上应该能做增量优化
            if can_always_incremental:
                if not has_incremental_marker:
                    # 列出所有函数
                    func_list = ', '.join(agg_funcs)
                    findings.append(self.create_finding(
                        'AGG_NOT_REUSING', stage_id, 'WARNING',
                        f"聚合 ({func_list}) 未复用之前的计算结果",
                        confidence='medium'
                    ))
                    
                    # 存储 analysis_scope
                    self.add_analysis_detail(context, 'aggregate_info', {
                        'agg_funcs': agg_funcs,
                        'is_append_only': is_append_only,
                        'has_state_table': has_state_table,
                        'has_incremental_marker': has_incremental_marker,
                        'can_always_incremental': can_always_incremental,
                        'blocking_funcs': blocking_funcs,
                    }, stage_id=stage_id)

                    # **改进**: 根据是否已有状态表给出不同的建议
                    if not has_state_table:
                        insights.append(self.create_insight(
                            f"Stage {stage_id}: 聚合 ({func_list}) 未复用之前的结果，可能缺少状态表，"
                            f"建议设置 cz.optimizer.incremental.enable.state.table=true",
                            stage_id
                        ))
                    else:
                        insights.append(self.create_insight(
                            f"Stage {stage_id}: 聚合 ({func_list}) 未复用之前的结果。注意：Job 已包含状态表，"
                            f"但该聚合未能利用，建议检查状态表位置是否合理或聚合算子配置",
                            stage_id
                        ))

                    # 如果是 append-only 但缺少 hint
                    if is_append_only and not settings.get('cz.optimizer.incremental.append.only.tables'):
                        insights.append(self.create_insight(
                            f"Stage {stage_id}: 聚合的输入是 append-only，建议添加 append-only hint",
                            stage_id
                        ))
            
            # **情况2**: 只在 append-only 场景下能做增量优化（如只有 MIN/MAX）
            elif can_append_only_incremental and is_append_only:
                if not has_incremental_marker:
                    func_list = ', '.join(agg_funcs)
                    findings.append(self.create_finding(
                        'AGG_NOT_REUSING', stage_id, 'INFO',
                        f"聚合 ({func_list}) 在 append-only 场景下未复用之前的计算结果",
                        confidence='medium'
                    ))
                    
                    # 存储 analysis_scope
                    self.add_analysis_detail(context, 'aggregate_append_only_info', {
                        'agg_funcs': agg_funcs,
                        'is_append_only': is_append_only,
                        'has_state_table': has_state_table,
                    }, stage_id=stage_id)

                    # **改进**: 根据是否已有状态表给出不同的建议
                    if not has_state_table:
                        insights.append(self.create_insight(
                            f"Stage {stage_id}: 聚合 ({func_list}) 在 append-only 场景下未复用之前的结果，"
                            f"可能缺少状态表，建议设置 cz.optimizer.incremental.enable.state.table=true",
                            stage_id
                        ))
                    else:
                        insights.append(self.create_insight(
                            f"Stage {stage_id}: 聚合 ({func_list}) 在 append-only 场景下未复用之前的结果。"
                            f"注意：Job 已包含状态表，但该聚合未能利用，建议检查状态表位置或 append-only 配置",
                            stage_id
                        ))

                    # 如果缺少 append-only hint
                    if not settings.get('cz.optimizer.incremental.append.only.tables'):
                        insights.append(self.create_insight(
                            f"Stage {stage_id}: 聚合的输入是 append-only，建议添加 append-only hint",
                            stage_id
                        ))
            
            # **情况3**: 不能做增量优化（有阻塞函数）
            elif blocking_funcs:
                func_list = ', '.join(agg_funcs)
                blocking_list = ', '.join(blocking_funcs)
                insights.append(self.create_insight(
                    f"Stage {stage_id}: 聚合 ({func_list}) 包含不支持增量的函数 ({blocking_list})，"
                    f"无法做增量优化",
                    stage_id
                ))

        if has_incremental_marker:
            # "已利用增量特性" 是纯正面事实，降级为 analysis_scope 供 AI 消费
            self.add_analysis_detail(context, 'incremental_status', {
                'has_incremental_marker': True,
            }, stage_id=stage_id)

        return {'findings': findings, 'recommendations': recommendations, 'insights': insights}
    
    def _check_aggregate_incremental_capability(self, agg_funcs: List[str], 
                                                is_append_only: bool) -> tuple:
        """
        检查聚合算子整体能否做增量优化
        
        关键逻辑：整个聚合的优化能力取决于最弱的函数
        - 如果有 SUM/COUNT，但也有 MIN/MAX（非 append-only），则不能做增量
        - 如果只有 SUM/COUNT，则可以做增量
        - 如果只有 MIN/MAX，则只在 append-only 时可以做增量
        
        Args:
            agg_funcs: 聚合函数列表
            is_append_only: 输入是否是 append-only
            
        Returns:
            (can_always_incremental, can_append_only_incremental, blocking_funcs)
            - can_always_incremental: 是否可以无条件做增量（只有 SUM/COUNT）
            - can_append_only_incremental: 是否只在 append-only 时可以做增量（有 MIN/MAX）
            - blocking_funcs: 阻塞增量优化的函数列表
        """
        has_always_incremental = False  # 是否有 SUM/COUNT
        has_append_only_incremental = False  # 是否有 MIN/MAX
        blocking_funcs = []  # 不支持增量的函数
        
        for func_name in agg_funcs:
            upper_name = func_name.upper()
            
            # SUM, COUNT 可以无条件做增量
            if any(f in upper_name for f in self.ALWAYS_INCREMENTAL):
                has_always_incremental = True
            # MIN, MAX 只在 append-only 时可以做增量
            elif any(f in upper_name for f in self.APPEND_ONLY_INCREMENTAL):
                has_append_only_incremental = True
            # 其他函数不支持增量
            else:
                blocking_funcs.append(func_name)
        
        # 如果有不支持增量的函数，整个聚合都不能做增量
        if blocking_funcs:
            return False, False, blocking_funcs
        
        # 如果有 MIN/MAX（非 append-only），则整个聚合不能做增量
        # 即使有 SUM/COUNT，也会被 MIN/MAX 拖累
        if has_append_only_incremental and not is_append_only:
            # MIN/MAX 在非 append-only 场景下成为阻塞函数
            blocking_funcs = [f for f in agg_funcs 
                            if any(af in f.upper() for af in self.APPEND_ONLY_INCREMENTAL)]
            return False, False, blocking_funcs
        
        # 如果只有 SUM/COUNT，可以无条件做增量
        if has_always_incremental and not has_append_only_incremental:
            return True, False, []
        
        # 如果有 SUM/COUNT 和 MIN/MAX，且是 append-only，可以做增量
        if has_always_incremental and has_append_only_incremental and is_append_only:
            return True, False, []
        
        # 如果只有 MIN/MAX，且是 append-only，可以做增量
        if has_append_only_incremental and is_append_only:
            return False, True, []
        
        # 其他情况不能做增量
        return False, False, []

    def _analyze_aggregates_with_hints(self, plan: Dict) -> List[Dict]:
        """
        分析 plan 中的 aggregate 函数，并检查是否有增量 hint

        Returns:
            [
                {
                    'op_idx': int,
                    'agg_funcs': [func_name],
                    'has_incremental_hint': bool
                }
            ]
        """
        agg_info_list = []
        operators = plan.get('operators', [])

        for idx, op in enumerate(operators):
            if 'hashAgg' not in op and 'hashAggregate' not in op:
                continue

            # 检查是否是辅助 aggregate
            if self._is_incremental_helper_aggregate(op):
                continue

            # 提取 aggregate 函数
            agg_funcs = []
            for call in self._get_aggregate_calls(op):
                name = call.get('function', {}).get('function', {}).get('name', '')
                if not name:
                    name = call.get('function', {}).get('name', '')
                if name:
                    agg_funcs.append(name)

            if not agg_funcs:
                continue

            # 检查是否有增量 hint
            # 根据 prompt 4.2.6：必须设置上了 hint 包含类似 4.2.1.2 的一些状态 hint
            # 例如：Rule:IncrementalLinearFunctionAggregateRule
            has_incremental_hint = self._has_incremental_hint(op)

            agg_info_list.append({
                'op_idx': idx,
                'agg_funcs': agg_funcs,
                'has_incremental_hint': has_incremental_hint
            })

        return agg_info_list

    def _has_incremental_hint(self, op: Dict) -> bool:
        """
        检查算子是否有增量 hint

        根据 prompt 4.2.1.2 的格式（更新后）：
        - Rule:IncrementalLinearFunctionAggregateRule
        - Rule:IncrementalAggPositiveDeltaDedupRule_cz::optimizer::LogicalAggregate#xxx
        - HINT=delta,DeltaState:[...]_IncrementalAggregateRule#cz::optimizer::LogicalAggregate#xxx
        """
        op_str = json.dumps(op)

        # 检查是否包含增量相关的 Rule hint
        incremental_patterns = [
            'IncrementalLinearFunctionAggregateRule',
            'IncrementalAggPositiveDeltaDedupRule',
            'IncrementalAggregate',
            'Rule:Incremental.*Aggregate',
            'Rule:Incremental.*Agg'
        ]

        for pattern in incremental_patterns:
            if pattern in op_str:
                return True

        # 检查新的 HINT= 格式（根据 prompt 4.2.1.2 更新）
        # 格式：HINT=delta,DeltaState:[...]_IncrementalAggregateRule#...
        if 'DeltaState' in op_str and 'Incremental' in op_str and ('Aggregate' in op_str or 'Agg' in op_str):
            return True

        return False

    def _get_aggregate_calls(self, op: Dict) -> List[Dict]:
        """提取 aggregate calls"""
        calls = []

        # 检查 hashAgg 字段
        if 'hashAgg' in op and isinstance(op['hashAgg'], dict):
            hash_agg = op['hashAgg']
            if 'aggregate' in hash_agg and isinstance(hash_agg['aggregate'], dict):
                aggregate = hash_agg['aggregate']
                if 'aggregateCalls' in aggregate and isinstance(aggregate['aggregateCalls'], list):
                    calls.extend(aggregate['aggregateCalls'])

        # 检查 hashAggregate 字段
        if 'hashAggregate' in op and isinstance(op['hashAggregate'], dict):
            hash_aggregate = op['hashAggregate']
            if 'aggregate' in hash_aggregate and isinstance(hash_aggregate['aggregate'], dict):
                aggregate = hash_aggregate['aggregate']
                if 'aggregateCalls' in aggregate and isinstance(aggregate['aggregateCalls'], list):
                    calls.extend(aggregate['aggregateCalls'])

        return calls

    def _is_incremental_helper_aggregate(self, op: Dict) -> bool:
        """
        判断是否是增量算法的辅助 aggregate（而非原始 SQL 的 aggregate）

        判断依据：
        1. 3阶段 aggregate 的 P1/P2 阶段（PARTIAL1, PARTIAL2）
        2. 包含增量相关的特殊函数（如 MULTI_RANGE_COLLECT, _DF_BF_COLLECT）
        """
        if 'hashAgg' not in op and 'hashAggregate' not in op:
            return False

        # 获取 aggregate 对象
        hash_agg = op.get('hashAgg') or op.get('hashAggregate')
        if not hash_agg:
            return False

        # 检查 mode
        mode = hash_agg.get('aggregate', {}).get('mode', '')
        if mode in ['PARTIAL1', 'P1', 'PARTIAL2', 'P2', 'Partial1', 'Partial2']:
            return True

        # 检查聚集函数
        agg_calls = hash_agg.get('aggregate', {}).get('aggregateCalls', [])
        for call in agg_calls:
            func_name = call.get('function', {}).get('function', {}).get('name', '')
            if not func_name:
                func_name = call.get('function', {}).get('name', '')

            # 增量算法的特殊函数
            if any(special in func_name for special in [
                'MULTI_RANGE_COLLECT', '_DF_BF_COLLECT', 'BF_COLLECT',
                'DF_BF_COLLECT', '_INCR_', 'INCREMENTAL_'
            ]):
                return True

        return False

    def _check_append_only_inputs(self, plan: Dict, agg_idx: int) -> bool:
        """
        检查 aggregate 的输入是否是 append-only

        根据 prompt 4.2.1.5 的方法
        """
        operators = plan.get('operators', [])

        # 从 aggregate 向上游遍历，找到所有 tablescan
        visited = set()

        def dfs(idx):
            if idx in visited or idx < 0 or idx >= len(operators):
                return True  # 默认为 append-only

            visited.add(idx)
            op = operators[idx]

            # 如果是 tablescan，使用统一的 AppendOnlyDetector 检查是否为 append-only
            if 'tableScan' in op:
                is_append_only = AppendOnlyDetector.is_append_only_scan(op)
                return is_append_only if is_append_only is not None else True

            # 继续向上游遍历
            # 简化处理：假设算子按拓扑顺序排列
            if idx > 0:
                return dfs(idx - 1)

            return True

        return dfs(agg_idx)

    def _check_state_table_exists(self, plan: Dict) -> bool:
        """
        检查是否存在状态表

        已废弃：请使用 StateTableChecker.check_plan_has_state_table(context)
        进行全局检查，或传入 plan 进行单个 plan 检查
        """
        return StateTableChecker.check_plan_has_state_table(plan)

    def _check_incremental_markers(self, plan: Dict) -> bool:
        """检查是否有增量标记"""
        plan_str = json.dumps(plan).lower()
        return any(m in plan_str for m in ['incremental', 'delta', 'state', 'partial_result'])
