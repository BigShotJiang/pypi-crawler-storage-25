#!/usr/bin/env python3
"""数据倾斜检测规则

核心思路：时间倾斜为主判断，数据量倾斜为辅助归因。

主判断 — 时间倾斜：
  active task（排除 idle task 后）的 time max/median >= 10x
  只有 task 耗时真正倾斜时才认为存在性能问题。
  这避免了行宽差异、多数据源等场景下 inputRowCount 倾斜的误判。

辅助归因 — 数据量倾斜：
  时间倾斜确认后，检查 inputRowCount 的 max/median ratio 和 Top-K 集中度。
  如果数据量也倾斜 → 报 DATA_SKEW，给 split size 建议。
  如果数据量不倾斜 → 只报时间倾斜，不给 split size 建议（可能是计算复杂度差异）。

前提过滤：stage 耗时 > 5s + 数据量 > 100MB + 占比 > 15%
"""
from typing import Dict
from ...base_rule import BaseRule


class SkewDetection(BaseRule):
    name = "skew_detection"
    category = "incremental/stage_optimization"
    description = "检测数据倾斜问题，分析 task 时间和数据量分布并提供优化建议"

    # --- 前提过滤阈值 ---
    STAGE_TIME_RATIO_THRESHOLD = 0.15   # Stage 耗时占总体 >= 15%
    MIN_STAGE_TIME_MS = 5000            # Stage 耗时 >= 5s
    MIN_DATA_BYTES = 100 * 1024 * 1024  # 输入或输出 >= 100MB

    # --- 主判断：时间倾斜阈值 ---
    TIME_MAX_MEDIAN_RATIO_THRESHOLD = 10.0

    # --- 辅助归因：数据量倾斜阈值 ---
    DATA_MAX_MEDIAN_RATIO_THRESHOLD = 5.0
    CONCENTRATION_RATIO_THRESHOLD = 0.3

    # --- split size 建议 ---
    DEFAULT_SPLIT_SIZE = 268435456  # 256MB
    MIN_SPLIT_SIZE = 16777216       # 16MB
    MAX_SPLIT_SIZE = 268435456      # 256MB

    def check(self, stage_data: Dict, context: Dict) -> bool:
        if not self.has_profile_data(context):
            return False

        metrics = stage_data.get('metrics', {})

        # 前提过滤 1：Stage 耗时太短
        elapsed_ms = metrics.get('elapsed_ms', 0)
        if elapsed_ms < self.MIN_STAGE_TIME_MS:
            return False

        # 前提过滤 2：数据量太小
        input_bytes = metrics.get('input_bytes', 0)
        output_bytes = metrics.get('output_bytes', 0)
        if input_bytes < self.MIN_DATA_BYTES and output_bytes < self.MIN_DATA_BYTES:
            return False

        # 前提过滤 3：Stage 耗时占比太小
        total_job_time = context.get('total_job_time', 0)
        if total_job_time > 0:
            if elapsed_ms / total_job_time < self.STAGE_TIME_RATIO_THRESHOLD:
                return False

        # 主判断：时间倾斜 (active task 的 time max/median >= 10x)
        time_max_median = metrics.get('task_time_max_median_ratio', 1.0)
        return time_max_median >= self.TIME_MAX_MEDIAN_RATIO_THRESHOLD

    def analyze(self, stage_data: Dict, context: Dict) -> Dict:
        stage_id = stage_data.get('stage_id', 'unknown')
        plan_stage = stage_data.get('plan_stage') or stage_data.get('plan', {})
        metrics = stage_data.get('metrics', {})

        findings, recommendations, insights = [], [], []

        elapsed_ms = metrics.get('elapsed_ms', 0)
        total_job_time = context.get('total_job_time', 0)
        stage_pct = (elapsed_ms / total_job_time * 100) if total_job_time > 0 else 0

        # 时间倾斜指标
        active_tasks = metrics.get('active_task_count', 0)
        total_tasks = metrics.get('total_task_count', 0)
        active_task_ratio = metrics.get('active_task_ratio', 1.0)
        time_max_median = metrics.get('task_time_max_median_ratio', 1.0)
        active_max_ms = metrics.get('active_max_ms', 0)
        active_median_ms = metrics.get('active_median_ms', 0)

        # 数据量倾斜指标
        max_median_ratio = metrics.get('data_skew_max_median_ratio', 1.0)
        concentration_ratio = metrics.get('data_skew_concentration_ratio', 1.0)
        top_k_tasks = metrics.get('data_skew_top_k_tasks', 0)
        max_rows = metrics.get('data_skew_max_rows', 0)
        median_rows = metrics.get('data_skew_median_rows', 0)

        # 辅助归因：判断数据量是否也倾斜
        has_data_skew = max_median_ratio >= self.DATA_MAX_MEDIAN_RATIO_THRESHOLD
        threshold_b = min(self.CONCENTRATION_RATIO_THRESHOLD, 2 / active_tasks) if active_tasks > 0 else 1.0
        has_concentration_skew = concentration_ratio <= threshold_b if active_tasks > 0 else False
        is_data_skew = has_data_skew or has_concentration_skew

        # 构建描述
        time_desc = (f"时间倾斜 max/median={time_max_median:.1f}x "
                     f"(最慢 task {active_max_ms/1000:.1f}s, 中位数 {active_median_ms/1000:.1f}s)")

        data_desc_parts = []
        if has_data_skew:
            data_desc_parts.append(
                f"数据量 max/median={max_median_ratio:.1f}x "
                f"(最大 task {self._format_rows(max_rows)}, 中位数 {self._format_rows(median_rows)})")
        if has_concentration_skew:
            data_desc_parts.append(
                f"{top_k_tasks} 个 task（占 {concentration_ratio*100:.0f}%）承担了 80% 的数据量")

        # 严重程度
        if time_max_median >= 20:
            severity, confidence = 'HIGH', 'high'
        else:
            severity, confidence = 'MEDIUM', 'high'

        if is_data_skew:
            # 时间倾斜 + 数据量倾斜 → DATA_SKEW
            skew_desc = f"{time_desc}，{'；'.join(data_desc_parts)}"
            findings.append(self.create_finding(
                'DATA_SKEW', stage_id, severity,
                f"检测到数据倾斜：{skew_desc}，"
                f"active task {active_tasks}/{total_tasks}，"
                f"Stage 耗时 {elapsed_ms/1000:.1f}s，占整体 {stage_pct:.1f}%",
                {
                    'active_tasks': active_tasks,
                    'total_tasks': total_tasks,
                    'active_task_ratio': active_task_ratio,
                    'task_time_max_median_ratio': time_max_median,
                    'active_max_ms': active_max_ms,
                    'active_median_ms': active_median_ms,
                    'data_skew_max_median_ratio': max_median_ratio,
                    'data_skew_concentration_ratio': concentration_ratio,
                    'data_skew_top_k_tasks': top_k_tasks,
                    'data_skew_max_rows': max_rows,
                    'data_skew_median_rows': median_rows,
                    'stage_elapsed_ms': elapsed_ms,
                    'stage_total_pct': stage_pct,
                },
                confidence=confidence
            ))

            # 根据算子类型给建议
            has_scan = self._has_scan_operator(plan_stage)
            has_shuffle_read = self._has_shuffle_read_operator(plan_stage)

            if has_scan:
                ext_hudi_info = self._get_external_hudi_info(plan_stage)
                if ext_hudi_info:
                    # Hudi 外表（尤其 MOR）必须按文件切分，split size 调整无效，
                    # 且外表由用户管理，内部无法干预，只给提示
                    table_name = ext_hudi_info.get('table_name', '外表')
                    hudi_type = ext_hudi_info.get('hudi_type', 'UNKNOWN')
                    insights.append(self.create_insight(
                        f"Stage {stage_id}: {skew_desc}，"
                        f"Stage 耗时 {elapsed_ms/1000:.1f}s (占整体 {stage_pct:.1f}%)，"
                        f"该 Stage 读取 Hudi 外表 {table_name}（{hudi_type}），"
                        f"Hudi 表按文件切分，无法通过调整 split size 缓解倾斜，"
                        f"建议联系数据源方对该表做 compaction 或优化文件布局",
                        stage_id, level='important'))
                else:
                    self._generate_scan_skew_recommendations(
                        stage_id, skew_desc, elapsed_ms, stage_pct,
                        time_max_median, context, recommendations, insights)
            if has_shuffle_read:
                insights.append(self.create_insight(
                    f"Stage {stage_id}: {skew_desc}，"
                    f"Stage 耗时 {elapsed_ms/1000:.1f}s (占整体 {stage_pct:.1f}%)，"
                    f"包含 Shuffle Read，请关注上游是否存在倾斜数据",
                    stage_id, level='important'))
            if not has_scan and not has_shuffle_read:
                insights.append(self.create_insight(
                    f"Stage {stage_id}: {skew_desc}，"
                    f"Stage 耗时 {elapsed_ms/1000:.1f}s (占整体 {stage_pct:.1f}%)，"
                    f"建议检查数据分布和分区策略",
                    stage_id, level='important'))
        else:
            # 时间倾斜但数据量不倾斜 → 可能是计算复杂度差异，不给 split size 建议
            findings.append(self.create_finding(
                'TIME_SKEW', stage_id, severity,
                f"检测到时间倾斜：{time_desc}，但数据量分布均匀，"
                f"active task {active_tasks}/{total_tasks}，"
                f"Stage 耗时 {elapsed_ms/1000:.1f}s，占整体 {stage_pct:.1f}%",
                {
                    'active_tasks': active_tasks,
                    'total_tasks': total_tasks,
                    'task_time_max_median_ratio': time_max_median,
                    'active_max_ms': active_max_ms,
                    'active_median_ms': active_median_ms,
                    'data_skew_max_median_ratio': max_median_ratio,
                    'stage_elapsed_ms': elapsed_ms,
                    'stage_total_pct': stage_pct,
                },
                confidence='medium'
            ))
            insights.append(self.create_insight(
                f"Stage {stage_id}: {time_desc}，数据量分布均匀，"
                f"Stage 耗时 {elapsed_ms/1000:.1f}s (占整体 {stage_pct:.1f}%)，"
                f"可能是计算复杂度差异或资源争抢导致",
                stage_id, level='important'))

        # 存储 analysis_scope
        self.add_analysis_detail(context, 'skew_info', {
            'task_time_max_median_ratio': time_max_median,
            'active_max_ms': active_max_ms,
            'active_median_ms': active_median_ms,
            'is_data_skew': is_data_skew,
            'data_skew_max_median_ratio': max_median_ratio,
            'has_scan': self._has_scan_operator(plan_stage),
            'has_shuffle_read': self._has_shuffle_read_operator(plan_stage),
            'current_split_size': self._get_current_split_size(context),
        }, stage_id=stage_id)

        return {'findings': findings, 'recommendations': recommendations, 'insights': insights}

    # ---- 内部方法 ----

    @staticmethod
    def _get_external_hudi_info(plan_stage: Dict) -> Dict:
        """检查 stage 中的 TableScan 是否读取 Hudi 外表。

        判断条件：
        1. tableMeta.tableType == 'EXTERNAL_TABLE' 或 properties 中 external == 'TRUE'
        2. properties 中包含 hoodie.table.type（Hudi 表）

        Returns:
            包含 table_name 和 hudi_type 的 dict，如果不是 Hudi 外表则返回空 dict
        """
        if not plan_stage:
            return {}
        for op in plan_stage.get('operators', []):
            if 'tableScan' not in op:
                continue
            ts = op['tableScan']
            table = ts.get('table', {})

            # 解析 properties（可能是 list[{key, value}] 或 dict）
            raw_props = table.get('properties', [])
            if isinstance(raw_props, list):
                props = {p.get('key', ''): p.get('value', '') for p in raw_props if 'key' in p}
            elif isinstance(raw_props, dict):
                props = raw_props
            else:
                props = {}

            # 检查是否是外表
            table_meta = table.get('tableMeta', {})
            is_external = (
                table_meta.get('tableType') == 'EXTERNAL_TABLE'
                or str(props.get('external', '')).upper() == 'TRUE'
            )
            if not is_external:
                continue

            # 检查是否是 Hudi 表
            hudi_type = props.get('hoodie.table.type')
            if hudi_type:
                path = table.get('path', [])
                table_name = '.'.join(path[:3]) if len(path) >= 3 else str(path)
                return {'table_name': table_name, 'hudi_type': hudi_type}
        return {}

    def _generate_scan_skew_recommendations(self, stage_id, skew_desc,
                                             elapsed_ms, stage_pct,
                                             time_max_median,
                                             context, recommendations, insights):
        """为包含 Scan 算子的 stage 生成 split size 调整建议"""
        current_split_size = self._get_current_split_size(context)
        is_user_set = current_split_size is not None
        if current_split_size is None:
            current_split_size = self.DEFAULT_SPLIT_SIZE

        recommended_split_size = current_split_size // 4
        recommended_split_size = max(self.MIN_SPLIT_SIZE, min(recommended_split_size, self.MAX_SPLIT_SIZE))

        if recommended_split_size >= current_split_size or current_split_size <= self.MIN_SPLIT_SIZE:
            if current_split_size <= self.MIN_SPLIT_SIZE:
                insights.append(self.create_insight(
                    f"Stage {stage_id}: {skew_desc}，"
                    f"split size 已设置为 {current_split_size / (1024**2):.0f}M（最小值），"
                    f"仍存在倾斜，建议检查源表文件大小分布或做 compaction",
                    stage_id, level='important'))
            else:
                insights.append(self.create_insight(
                    f"Stage {stage_id}: {skew_desc}，"
                    f"split size 当前为 {current_split_size / (1024**2):.0f}M，"
                    f"建议检查源表文件大小分布或做 compaction",
                    stage_id, level='important'))
        else:
            reason = (f"Stage {stage_id}: {skew_desc}，"
                     f"Stage 耗时 {elapsed_ms/1000:.1f}s (占整体 {stage_pct:.1f}%)，"
                     f"建议调整 split size 从 {current_split_size / (1024**2):.0f}M "
                     f"到 {recommended_split_size / (1024**2):.0f}M")
            if is_user_set:
                reason += f"（当前已设置为 {current_split_size / (1024**2):.0f}M，建议进一步调小）"

            recommendations.append(self.build_recommendation_with_table_check(
                'cz.mapper.file.split.size',
                str(recommended_split_size), 2,
                reason, 'MEDIUM', context,
                str(current_split_size) if is_user_set else None,
                stage_id=stage_id))

            insights.append(self.create_insight(
                f"Stage {stage_id}: {skew_desc}，"
                f"Stage 耗时 {elapsed_ms/1000:.1f}s (占整体 {stage_pct:.1f}%)，"
                f"建议将 split size 从 {current_split_size / (1024**2):.0f}M "
                f"调整为 {recommended_split_size / (1024**2):.0f}M",
                stage_id, level='important'))

        # 严重倾斜额外提示
        if time_max_median > 100:
            insights.append(self.create_insight(
                f"Stage {stage_id}: 时间倾斜极为严重（max/median={time_max_median:.0f}x），"
                f"仅调整 split size 可能不够，建议对源表做 compaction 并调整 compaction 参数",
                stage_id, level='important'))

    @staticmethod
    def _format_rows(r: int) -> str:
        if r >= 1_0000_0000:
            return f"{r / 1_0000_0000:.1f}亿行"
        if r >= 1_0000:
            return f"{r / 1_0000:.0f}万行"
        return f"{r}行"

    def _has_scan_operator(self, plan_stage: Dict) -> bool:
        if not plan_stage:
            return False
        for op in plan_stage.get('operators', []):
            if 'tableScan' in op:
                return True
            op_type = op.get('type', '').lower()
            if 'scan' in op_type or 'tablescan' in op_type:
                return True
        return False

    def _has_shuffle_read_operator(self, plan_stage: Dict) -> bool:
        if not plan_stage:
            return False
        for op in plan_stage.get('operators', []):
            if 'shuffleRead' in op or 'exchange' in op:
                return True
            op_type = op.get('type', '').lower()
            if 'shuffle' in op_type and 'read' in op_type:
                return True
        return False

    def _get_current_split_size(self, context: Dict):
        settings = context.get('settings', {})
        split_size_str = settings.get('cz.mapper.file.split.size')
        if split_size_str:
            try:
                return int(split_size_str)
            except (ValueError, TypeError):
                pass
        return None
