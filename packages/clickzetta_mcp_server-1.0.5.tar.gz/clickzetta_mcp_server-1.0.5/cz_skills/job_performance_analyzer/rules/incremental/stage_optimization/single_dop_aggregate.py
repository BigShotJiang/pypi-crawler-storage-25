#!/usr/bin/env python3
"""单 DOP 聚合优化规则"""
from typing import Dict, Optional
from ...base_rule import BaseRule
from ....utils.plan_navigator import create_stage_navigator


class SingleDopAggregate(BaseRule):
    name = "single_dop_aggregate"
    category = "incremental/stage_optimization"
    description = "检测单并行度聚合Stage，优化三阶段聚合配置"
    EXPENSIVE_FUNCTIONS = ['MULTI_RANGE_COLLECT', '_DF_BF_COLLECT', 'BF_COLLECT', 'DF_BF_COLLECT']
    MULTI_RANGE_FUNCTIONS = ['MULTI_RANGE_COLLECT']
    BF_COLLECT_FUNCTIONS = ['_DF_BF_COLLECT', '_DF_SET_BF_COLLECT', 'DF_BF_COLLECT', 'DF_SET_BF_COLLECT']
    TIME_THRESHOLD_MS = 20000  # 20秒
    TIME_THRESHOLD_ABSOLUTE_MS = 30000  # 30秒（绝对阈值）
    PERCENT_THRESHOLD = 10.0  # 10%
    INPUT_DATA_THRESHOLD_BYTES = 20 * 1024 * 1024  # 20MB（输入数据阈值）
    BITS_LOW_THRESHOLD = 536870912  # 512M
    BITS_HIGH_THRESHOLD_V13 = 1073741824  # 1G (v1.3及以下版本默认值)
    BITS_HIGH_THRESHOLD_V14_PLUS = 536870912  # 512M (v1.3以上版本默认值)

    def _get_version_threshold(self, context: Dict) -> int:
        """根据版本获取对应的 bits 阈值"""
        version_info = context.get('version_info', {})
        git_branch = version_info.get('git_branch', '')

        # 从 git_branch 中提取版本号，如 "release-v1.3" -> "1.3"
        # 如果无法解析版本，默认使用 v1.3 的阈值（更保守）
        try:
            if 'release-v' in git_branch:
                version_str = git_branch.split('release-v')[1].split('-')[0]
                # 解析主版本号和次版本号
                parts = version_str.split('.')
                major = int(parts[0]) if len(parts) > 0 else 1
                minor = int(parts[1]) if len(parts) > 1 else 3

                # v1.3 及以下使用 1G，v1.4+ 使用 512M
                if major < 1 or (major == 1 and minor <= 3):
                    return self.BITS_HIGH_THRESHOLD_V13
                else:
                    return self.BITS_HIGH_THRESHOLD_V14_PLUS
        except (ValueError, IndexError):
            pass

        # 默认使用 v1.3 的阈值（1G）
        return self.BITS_HIGH_THRESHOLD_V13

    def check(self, stage_data: Dict, context: Dict) -> bool:
        # 使用 PlanNavigator 检查是否有 HashAggregate
        navigator = create_stage_navigator(stage_data)
        if not navigator.has_operator('HashAggregate'):
            return False

        # 优先检查 Bloom Filter 收集问题（高优先级，不需要 profile 数据）
        has_multi_range = navigator.has_aggregate_function(self.MULTI_RANGE_FUNCTIONS)
        has_bf_collect = navigator.has_aggregate_function(self.BF_COLLECT_FUNCTIONS)
        
        # 如果有 MULTI_RANGE_COLLECT 但缺少 BF 收集，立即触发规则
        if has_multi_range and not has_bf_collect:
            return True

        # 以下是原有的单 DOP 聚合检查逻辑
        # 如果没有 profile 数据，跳过此规则（需要运行时性能数据）
        if not self.has_profile_data(context):
            return False

        metrics = stage_data.get('metrics', {})
        total_time = context.get('total_job_time', 0)

        # 检查 DOP 是否为 1
        if metrics.get('dop') != 1:
            return False

        # 检查耗时是否超过阈值
        # 条件：(耗时超过20s以上且占总体10%以上) 或者 耗时超过30s
        elapsed_ms = metrics.get('elapsed_ms', 0)
        time_pct = (elapsed_ms / total_time * 100) if total_time else 0
        
        condition1 = elapsed_ms >= self.TIME_THRESHOLD_MS and time_pct >= self.PERCENT_THRESHOLD
        condition2 = elapsed_ms >= self.TIME_THRESHOLD_ABSOLUTE_MS
        
        if not (condition1 or condition2):
            return False

        # 检查 stage 输入数据量（一般是 shuffle read 算子）是否超过 20MB
        input_bytes = metrics.get('input_bytes', 0)
        
        if input_bytes < self.INPUT_DATA_THRESHOLD_BYTES:
            return False

        # 检查是否有昂贵的聚合函数
        if not navigator.has_aggregate_function(self.EXPENSIVE_FUNCTIONS):
            return False

        # 检查是否是 Final 或 Complete 状态（表示最后一个聚合阶段）
        # 如果是 Final/Complete，说明可能需要 3 阶段优化
        has_final_or_complete = (navigator.has_hash_aggregate_phase('FINAL') or
                                 navigator.has_hash_aggregate_phase('Complete'))

        # 如果有 Final/Complete，检查上游是否有 P2（判断是否已经是 3 阶段）
        if has_final_or_complete:
            # 检查上游是否有 P2
            upstream_stages = stage_data.get('upstream_stages', [])
            all_aligned_stages = context.get('aligned_stages', {})
            has_upstream_p2 = False

            for upstream_id in upstream_stages:
                if upstream_id in all_aligned_stages:
                    upstream_nav = create_stage_navigator(all_aligned_stages[upstream_id])
                    if upstream_nav.has_hash_aggregate_phase('P2') or upstream_nav.has_hash_aggregate_phase('PARTIAL2'):
                        has_upstream_p2 = True
                        break

            # 如果上游没有 P2，说明没有开启 3 阶段，需要优化
            if not has_upstream_p2:
                return True

        # 如果没有明确的 Final/Complete 标记，但有昂贵函数，也可能需要优化
        # （兼容 mode 为 None 的情况）
        return True

    def analyze(self, stage_data: Dict, context: Dict) -> Dict:
        stage_id = stage_data.get('stage_id', 'unknown')
        metrics = stage_data.get('metrics', {})
        settings = context.get('settings', {})
        total_time = context.get('total_job_time', 0)
        elapsed_ms = metrics.get('elapsed_ms', 0)
        time_pct = (elapsed_ms / total_time * 100) if total_time else 0

        navigator = create_stage_navigator(stage_data)

        findings = [self.create_finding('SINGLE_DOP_AGG', stage_id, 'HIGH',
            f"DOP=1, 耗时={elapsed_ms/1000:.1f}s ({time_pct:.1f}%)",
            {'dop': 1, 'elapsed_ms': elapsed_ms, 'time_pct': time_pct})]
        recommendations, insights = [], []

        # 检查聚合阶段
        has_final = navigator.has_hash_aggregate_phase('FINAL')
        has_complete = navigator.has_hash_aggregate_phase('Complete')

        # 检查上游是否有 P2
        upstream_stages = stage_data.get('upstream_stages', [])
        all_aligned_stages = context.get('aligned_stages', {})
        has_upstream_p2 = False

        for upstream_id in upstream_stages:
            if upstream_id in all_aligned_stages:
                upstream_nav = create_stage_navigator(all_aligned_stages[upstream_id])
                if upstream_nav.has_hash_aggregate_phase('P2') or upstream_nav.has_hash_aggregate_phase('PARTIAL2'):
                    has_upstream_p2 = True
                    break

        # 判断是否需要开启三阶段
        if has_final or has_complete:
            if not has_upstream_p2:
                insights.append(self.create_insight(
                    f"Stage {stage_id}: 聚合处于 {'FINAL' if has_final else 'Complete'} 阶段，"
                    f"但上游缺少 P2，当前只有 2 阶段聚合", stage_id))
            else:
                insights.append(self.create_insight(
                    f"Stage {stage_id}: 已开启 3 阶段聚合（上游有 P2）", stage_id))

        # 检查三阶段聚合参数
        # 注意：cz.optimizer.incremental.df.three.phase.agg.enable 和
        # cz.optimizer.df.enable.three.phase.agg 是等价的，任一开启即可
        p1 = 'cz.optimizer.incremental.df.three.phase.agg.enable'
        p2 = 'cz.optimizer.df.enable.three.phase.agg'
        three_phase_enabled = settings.get(p1) == 'true' or settings.get(p2) == 'true'

        if not three_phase_enabled:
            recommendations.append(self.build_recommendation_with_table_check(
                p1, 'true', 1,
                f"Stage {stage_id} 耗时 {elapsed_ms/1000:.1f}s (占总耗时 {time_pct:.1f}%)，开启三阶段聚合可提升并行度",
                'HIGH', context))
        elif has_complete:
            # 如果已经开启三阶段但还是 Complete，可能是 one-pass 导致退化
            param = 'cz.optimizer.enable.one.pass.agg'
            if param not in settings or settings.get(param) != 'false':
                recommendations.append(self.build_recommendation_with_table_check(
                    param, 'false', 2,
                    f"Stage {stage_id} 耗时 {elapsed_ms/1000:.1f}s (占总耗时 {time_pct:.1f}%)，禁用 one-pass 防止三阶段退化",
                    'MEDIUM', context))
            insights.append(self.create_insight(
                f"Stage {stage_id}: 聚合退化为单阶段 (Complete)，可能是 one-pass 导致", stage_id))

        # 检查 BF bits 阈值（根据版本使用不同的默认阈值）
        bits = navigator.extract_aggregate_bits()
        version_threshold = self._get_version_threshold(context)

        if bits and self.BITS_LOW_THRESHOLD <= bits < version_threshold:
            param = 'cz.optimizer.df.three.phase.agg.bf.width.threshold'
            current = settings.get(param)
            if not current or int(current) > bits:
                version_info = context.get('version_info', {})
                git_branch = version_info.get('git_branch', 'Unknown')
                threshold_desc = f"{version_threshold} (版本 {git_branch} 的默认值)"

                recommendations.append(self.build_recommendation_with_table_check(
                    param, str(bits), 3,
                    f"Stage {stage_id} 耗时 {elapsed_ms/1000:.1f}s (占总耗时 {time_pct:.1f}%)，BF bits={bits}，需调整阈值使三阶段生效",
                    'MEDIUM', context, current,
                    warning=f"bits={bits} < 默认阈值 {threshold_desc}"))
                insights.append(self.create_insight(
                    f"Stage {stage_id}: BF bits={bits} < 默认阈值 {threshold_desc}，"
                    f"可能导致三阶段未生效", stage_id))

        # 检查 Bloom Filter 收集（高优先级）
        # 如果有 MULTI_RANGE_COLLECT 但缺少 BF 收集函数，说明 BF 未收集，会导致裁剪效果不佳
        has_multi_range = navigator.has_aggregate_function(self.MULTI_RANGE_FUNCTIONS)
        has_bf_collect = navigator.has_aggregate_function(self.BF_COLLECT_FUNCTIONS)
        
        if has_multi_range and not has_bf_collect:
            # 添加高优先级 finding
            findings.append(self.create_finding('MISSING_BF_COLLECTION', stage_id, 'HIGH',
                f"Stage {stage_id} 有 MULTI_RANGE_COLLECT 但缺少 Bloom Filter 收集",
                {'stage_id': stage_id, 'has_multi_range': True, 'has_bf_collect': False}))
            
            insights.append(self.create_insight(
                f"Stage {stage_id}: 检测到 MULTI_RANGE_COLLECT 但未收集 Bloom Filter，"
                f"这会导致数据裁剪效果不佳，影响增量计算性能", stage_id))
            
            # 判断版本并给出相应的优化建议
            version_info = context.get('version_info', {})
            git_branch = version_info.get('git_branch', '')
            is_v13 = False
            
            try:
                if 'release-v' in git_branch:
                    version_str = git_branch.split('release-v')[1].split('-')[0]
                    parts = version_str.split('.')
                    major = int(parts[0]) if len(parts) > 0 else 1
                    minor = int(parts[1]) if len(parts) > 1 else 3
                    is_v13 = (major == 1 and minor == 3)
            except (ValueError, IndexError):
                pass
            
            # 如果是 v1.3 版本，添加完整的 BF 配置
            if is_v13:
                bf_params = [
                    ('cz.optimizer.incremental.df.three.phase.agg.enable', 'true'),
                    ('cz.optimizer.df.three.phase.agg.bf.width.threshold', '536870912'),
                    ('cz.optimizer.df.bf.width.max', '2147483648'),
                    ('cz.optimizer.df.bf.width.min', '1073741824'),
                    ('cz.optimizer.incremental.enforce.creating.bf', 'true')
                ]
                
                priority = 10  # 使用较高的优先级，确保在其他建议之前
                for param, value in bf_params:
                    current_value = settings.get(param)
                    if current_value != value:
                        recommendations.append(self.build_recommendation_with_table_check(
                            param, value, priority,
                            f"Stage {stage_id} 缺少 Bloom Filter 收集，设置此参数以强制创建 BF（v1.3版本）",
                            'HIGH', context, current_value))
                        priority += 1
            else:
                # 非 v1.3 版本，至少添加强制创建 BF 的参数
                param = 'cz.optimizer.incremental.enforce.creating.bf'
                current_value = settings.get(param)
                if current_value != 'true':
                    recommendations.append(self.build_recommendation_with_table_check(
                        param, 'true', 10,
                        f"Stage {stage_id} 缺少 Bloom Filter 收集，强制创建 BF 以改善数据裁剪",
                        'HIGH', context, current_value))

        # 存储 analysis_scope 供 standard/deep 模式使用
        bits = navigator.extract_aggregate_bits()
        self.add_analysis_detail(context, 'aggregate_info', {
            'aggregate_phase': 'FINAL' if has_final else ('Complete' if has_complete else 'unknown'),
            'has_upstream_p2': has_upstream_p2,
            'three_phase_enabled': three_phase_enabled,
            'bf_bits': bits,
            'has_multi_range': has_multi_range,
            'has_bf_collect': has_bf_collect,
        }, stage_id=stage_id)

        return {'findings': findings, 'recommendations': recommendations, 'insights': insights}


