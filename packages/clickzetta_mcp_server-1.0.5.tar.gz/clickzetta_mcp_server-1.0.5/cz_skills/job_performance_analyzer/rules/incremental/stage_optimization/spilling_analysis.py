#!/usr/bin/env python3
"""Spilling 分析规则 — 读取 aligner 已计算的 per-operator spill 数据"""
from typing import Dict, List
from ...base_rule import BaseRule


class SpillingAnalysis(BaseRule):
    name = "spilling_analysis"
    category = "incremental/stage_optimization"
    description = "检测内存溢出到磁盘的情况，区分 Stage 级别和 Operator 级别"
    STAGE_SPILL_THRESHOLD_GB = 1.0
    OPERATOR_SPILL_THRESHOLD_GB = 0.5

    def check(self, stage_data: Dict, context: Dict) -> bool:
        if not self.has_profile_data(context):
            return False
        # 使用 aligner 计算的 effective_spill_bytes（排除 Shuffle 算子）
        metrics = stage_data.get('metrics', {})
        return metrics.get('effective_spill_bytes', 0) > 0

    def analyze(self, stage_data: Dict, context: Dict) -> Dict:
        stage_id = stage_data.get('stage_id', 'unknown')
        metrics = stage_data.get('metrics', {})

        findings, recommendations, insights = [], [], []

        # 直接从 aligner metrics 读取（aligner._analyze_operators 已统一计算）
        effective_spill_gb = metrics.get('effective_spill_gb', 0)
        operator_spills = metrics.get('operator_spills', [])
        effective_spills = [op for op in operator_spills if not op.get('is_shuffle', False)]

        # Stage 级别 Spilling finding
        if effective_spill_gb >= self.STAGE_SPILL_THRESHOLD_GB:
            severity = 'HIGH' if effective_spill_gb >= self.STAGE_SPILL_THRESHOLD_GB * 3 else 'MEDIUM'
            findings.append(self.create_finding('STAGE_SPILLING', stage_id, severity,
                f"计算算子 Spilling 合计: {effective_spill_gb:.2f} GB",
                {'spill_gb': effective_spill_gb, 'level': 'stage'},
                confidence='high'))

        # Operator 级别 Spilling finding
        for op_spill in effective_spills:
            spill_gb = op_spill['spill_gb']
            if spill_gb >= self.OPERATOR_SPILL_THRESHOLD_GB:
                severity = 'HIGH' if spill_gb >= self.OPERATOR_SPILL_THRESHOLD_GB * 2 else 'MEDIUM'
                findings.append(self.create_finding('OPERATOR_SPILLING', stage_id, severity,
                    f"Operator {op_spill['operator_id']} Spilling: {spill_gb:.2f} GB",
                    {'operator_id': op_spill['operator_id'], 'spill_gb': spill_gb, 'level': 'operator'},
                    confidence='high'))

        # 存储 analysis_scope
        if effective_spills:
            self.add_analysis_detail(context, 'operator_spills', [
                {'operator_id': op['operator_id'], 'spill_gb': op['spill_gb']}
                for op in effective_spills
            ], stage_id=stage_id)
            self.add_analysis_detail(context, 'effective_stage_spill_gb', effective_spill_gb, stage_id=stage_id)

        return {'findings': findings, 'recommendations': recommendations, 'insights': insights}
