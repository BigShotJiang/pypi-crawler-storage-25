#!/usr/bin/env python3
"""资源效率分析规则 - 对比实际运行时间与理论资源充足时的预期时间（考虑并发 stage 资源竞争）"""
from typing import Dict, List, Tuple

try:
    from loguru import logger
except ImportError:
    import logging
    logger = logging.getLogger(__name__)

from ...base_rule import BaseRule


class ResourceEfficiencyAnalysis(BaseRule):
    """分析每个 stage 的资源利用效率：对比实际耗时与给足资源情况下的预期耗时，考虑并发 stage 的资源竞争"""

    name = "resource_efficiency_analysis"
    category = "incremental/stage_optimization"
    description = "分析 Stage 资源效率，检测资源不足导致的性能问题"

    # 实际耗时 / 预期耗时 的倍数阈值，超过则告警
    EFFICIENCY_RATIO_THRESHOLD = 2.0
    # Stage 最小耗时（ms），低于此值不分析
    MIN_STAGE_TIME_MS = 60000

    def check(self, stage_data: Dict, context: Dict) -> bool:
        if not self.has_profile_data(context):
            return False

        profile = stage_data.get('profile', {})
        if 'taskSummary' not in profile:
            return False

        # vc_cores 必须有效
        vc_cores = context.get('vc_mode_info', {}).get('vc_cores', 0)
        if vc_cores <= 0:
            return False

        metrics = stage_data.get('metrics', {})
        elapsed_ms = metrics.get('elapsed_ms', 0)
        if elapsed_ms < self.MIN_STAGE_TIME_MS:
            return False

        return True

    def _get_concurrent_dop(self, stage_id: str, start_time: int, end_time: int,
                            context: Dict) -> Tuple[int, List[str]]:
        """计算 stage 运行期间其他 stage 的平均并发 task 数。

        使用 aligner 预计算的全局 timeline 和 per-stage timeline：
        全局并发 - 自己的并发 = 其他 stage 的并发。
        """
        global_tl = context.get('global_task_timeline', [])
        my_tl = context.get('per_stage_task_timeline', {}).get(stage_id, [])

        if not global_tl:
            return 0, []

        global_avg = self._avg_concurrency_in_range(global_tl, start_time, end_time)
        my_avg = self._avg_concurrency_in_range(my_tl, start_time, end_time)
        other_avg = max(0, global_avg - my_avg)

        # 找并发 stage 列表（仍用 stage 级别时间重叠判断，仅用于描述）
        concurrent_stages = []
        aligned_stages = context.get('aligned_stages', {})
        for other_id, other_data in aligned_stages.items():
            if other_id == stage_id:
                continue
            other_profile = other_data.get('profile', {})
            other_start = int(other_profile.get('startTime', 0))
            other_end = int(other_profile.get('endTime', 0))
            if other_start <= 0 or other_end <= 0:
                continue
            if other_start < end_time and other_end > start_time:
                concurrent_stages.append(other_id)

        return int(round(other_avg)), concurrent_stages

    @staticmethod
    def _avg_concurrency_in_range(timeline: List[Tuple[int, int]],
                                   start: int, end: int) -> float:
        """在 timeline 上计算 [start, end) 区间内的加权平均并发数。

        timeline 是 [(timestamp, concurrency), ...] 的分段常数函数。
        """
        if not timeline or start >= end:
            return 0.0

        import bisect
        timestamps = [t[0] for t in timeline]

        # 找到 start 所在的段
        idx = bisect.bisect_right(timestamps, start) - 1
        if idx < 0:
            idx = 0

        weighted_sum = 0.0
        prev_ts = start

        while idx < len(timeline) and prev_ts < end:
            current_count = timeline[idx][1]
            # 下一个时间点
            next_ts = timeline[idx + 1][0] if idx + 1 < len(timeline) else end
            # 裁剪到 [start, end)
            seg_start = max(prev_ts, start)
            seg_end = min(next_ts, end)
            if seg_end > seg_start:
                weighted_sum += current_count * (seg_end - seg_start)
            prev_ts = seg_end
            idx += 1

        duration = end - start
        return weighted_sum / duration if duration > 0 else 0.0

    @staticmethod
    def _calc_task_concurrency(task_summary: Dict) -> Dict:
        """用扫描线算法计算 stage 内 task 的实际并发情况（最大/最小/加权平均同时运行数）"""
        events = []  # (timestamp, +1/-1)
        for task_id, task_data in task_summary.items():
            t_start = int(task_data.get('startTime', 0))
            t_end = int(task_data.get('endTime', 0))
            if t_end > t_start:
                events.append((t_start, 1))
                events.append((t_end, -1))

        if not events:
            return {'max_concurrency': 0, 'min_concurrency': 0, 'avg_concurrency': 0.0}

        # 按时间排序，同一时刻先处理 -1（结束）再处理 +1（启动），
        # 这样同一时刻结束再启动不会虚高
        events.sort(key=lambda e: (e[0], e[1]))

        current = 0
        max_conc = 0
        min_conc = float('inf')
        weighted_sum = 0  # 并发数 × 持续时长 的累加
        prev_ts = events[0][0]

        i = 0
        while i < len(events):
            ts = events[i][0]
            # 累加上一段的加权值
            if current > 0:
                weighted_sum += current * (ts - prev_ts)
            prev_ts = ts
            # 处理同一时刻的所有事件
            while i < len(events) and events[i][0] == ts:
                current += events[i][1]
                i += 1
            if current > max_conc:
                max_conc = current
            if current > 0 and current < min_conc:
                min_conc = current

        if min_conc == float('inf'):
            min_conc = 0

        # 总时长 = 最后一个事件时间 - 第一个事件时间
        total_duration = events[-1][0] - events[0][0]
        avg_conc = weighted_sum / total_duration if total_duration > 0 else 0.0

        return {'max_concurrency': max_conc, 'min_concurrency': min_conc, 'avg_concurrency': round(avg_conc, 1)}

    def analyze(self, stage_data: Dict, context: Dict) -> Dict:
        stage_id = stage_data.get('stage_id', 'unknown')
        profile = stage_data.get('profile', {})
        metrics = stage_data.get('metrics', {})

        findings, recommendations, insights = [], [], []

        task_summary = profile.get('taskSummary', {})
        if not task_summary:
            return {'findings': findings, 'recommendations': recommendations, 'insights': insights}

        vc_cores = context.get('vc_mode_info', {}).get('vc_cores', 0)
        dop = metrics.get('dop', 0)
        elapsed_ms = metrics.get('elapsed_ms', 0)
        total_job_time = context.get('total_job_time', 0)
        stage_pct = (elapsed_ms / total_job_time * 100) if total_job_time > 0 else 0

        # 获取当前 stage 的时间范围
        stage_start = int(profile.get('startTime', 0))
        stage_end = int(profile.get('endTime', 0))

        # 并发 stage 信息（仅用于归因描述，不参与 estimated_ms 计算）
        concurrent_dop, concurrent_stages = self._get_concurrent_dop(
            stage_id, stage_start, stage_end, context
        )

        # 从 taskSummary 计算每个 task 的运行时间
        task_times_ms = []
        for task_id, task_data in task_summary.items():
            t_start = int(task_data.get('startTime', 0))
            t_end = int(task_data.get('endTime', 0))
            if t_end > t_start:
                task_times_ms.append(t_end - t_start)

        if not task_times_ms:
            return {'findings': findings, 'recommendations': recommendations, 'insights': insights}

        max_task_time_ms = max(task_times_ms)
        total_tasks = len(task_times_ms)

        # 计算 task 实际并发情况（最大/最小/平均同时运行数）
        task_conc = self._calc_task_concurrency(task_summary)
        max_concurrency = task_conc['max_concurrency']
        min_concurrency = task_conc['min_concurrency']
        avg_concurrency = task_conc['avg_concurrency']

        # 计算理论最优耗时：假设 vc 资源全部可用，DOP 个 task 分 ceil(DOP/vc_cores) 轮跑完
        import math
        rounds = math.ceil(total_tasks / vc_cores) if vc_cores > 0 else total_tasks
        estimated_ms = max_task_time_ms * rounds

        if estimated_ms <= 0:
            return {'findings': findings, 'recommendations': recommendations, 'insights': insights}

        efficiency_ratio = elapsed_ms / estimated_ms

        logger.debug(
            f"Stage {stage_id}: 实际耗时={elapsed_ms/1000:.1f}s, "
            f"预期耗时={estimated_ms/1000:.1f}s (max_task={max_task_time_ms/1000:.1f}s, "
            f"tasks={total_tasks}, vc_cores={vc_cores}, rounds={rounds}), "
            f"效率比={efficiency_ratio:.2f}x, "
            f"task并发: max={max_concurrency}, min={min_concurrency}, avg={avg_concurrency}"
        )

        if efficiency_ratio >= self.EFFICIENCY_RATIO_THRESHOLD:
            severity = 'HIGH' if efficiency_ratio >= 3.0 else 'MEDIUM'
            confidence = 'high' if efficiency_ratio >= 3.0 else 'medium'

            concurrent_info = ""
            if concurrent_stages:
                concurrent_info = (
                    f"，并发 stage: {', '.join(concurrent_stages[:5])}"
                    f"{'等' if len(concurrent_stages) > 5 else ''}"
                    f" 占用 {concurrent_dop} cores，VC 总资源 {vc_cores} cores"
                )

            findings.append(self.create_finding(
                'RESOURCE_INEFFICIENCY',
                stage_id,
                severity,
                f"Stage 实际耗时 {elapsed_ms/1000:.1f}s 是预期耗时 {estimated_ms/1000:.1f}s 的 "
                f"{efficiency_ratio:.1f} 倍 (占整体 {stage_pct:.1f}%)"
                f"，task 实际并发: 最大 {max_concurrency}，最小 {min_concurrency}，平均 {avg_concurrency}"
                f"{concurrent_info}",
                {
                    'elapsed_ms': elapsed_ms,
                    'estimated_ms': estimated_ms,
                    'efficiency_ratio': efficiency_ratio,
                    'max_task_time_ms': max_task_time_ms,
                    'total_tasks': total_tasks,
                    'vc_cores': vc_cores,
                    'concurrent_dop': concurrent_dop,
                    'concurrent_stages': concurrent_stages,
                    'rounds': rounds,
                    'dop': dop,
                    'max_concurrency': max_concurrency,
                    'min_concurrency': min_concurrency,
                    'avg_concurrency': avg_concurrency,
                },
                confidence=confidence
            ))

            ## 注：这里“资源抢占或调度问题导致并发偏低" 不要被修改了 for LLM
            insights.append(self.create_insight(
                f"Stage {stage_id}: 资源抢占或调度问题导致并发偏低，实际耗时 {elapsed_ms/1000:.1f}s，"
                f"预期 {estimated_ms/1000:.1f}s "
                f"(最大task {max_task_time_ms/1000:.1f}s × {rounds}轮，"
                f"VC 总资源 {vc_cores} cores)，"
                f"实际/预期={efficiency_ratio:.1f}x，"
                f"task 实际并发: 最大 {max_concurrency} 最小 {min_concurrency} 平均 {avg_concurrency}"
                f"{concurrent_info}",
                stage_id,
                level='important'
            ))

            # 存储 analysis_scope 供 standard/deep 模式使用
            self.add_analysis_detail(context, 'efficiency', {
                'elapsed_ms': elapsed_ms,
                'estimated_ms': estimated_ms,
                'efficiency_ratio': efficiency_ratio,
                'vc_cores': vc_cores,
                'concurrent_stages': concurrent_stages,
                'concurrent_dop': concurrent_dop,
                'task_concurrency': {
                    'max': max_concurrency,
                    'min': min_concurrency,
                    'avg': avg_concurrency
                }
            }, stage_id=stage_id)

        return {'findings': findings, 'recommendations': recommendations, 'insights': insights}
