#!/usr/bin/env python3
"""Hash Join 优化规则

检测两类问题：
1. Build/Probe 数据量不对称：build 侧数据量远大于 probe 侧，说明 build side 选择可能不合理
   - 递归沿 inputIds 找到叶子节点（TableScan/ShuffleRead/Values），汇总 bytes 和 rowCount
   - 对于 ShuffleRead 叶子节点，追溯上游 ShuffleWrite 获取真实数据量（避免 broadcast 放大）
   - 优先用 bytes 判断，fallback 到 rowCount
   - Broadcast + build heavy → HIGH，建议关闭 broadcast
   - Shuffle + build heavy → MEDIUM，expert 级别 insight
2. Broadcast Join 耗时占比高且 build 侧真实数据量大：
   - 需同时满足耗时占比高 + build 侧真实数据量超过阈值
   - df_and join 降级为 detail，不产生 recommendation
"""
import json
import logging
from typing import Dict, List, Optional, Tuple
from ...base_rule import BaseRule

logger = logging.getLogger(__name__)

# 叶子节点类型前缀：递归查找 inputIds 时遇到这些就停止
LEAF_PREFIXES = ('TableScan', 'ShuffleRead', 'Values', 'Buffer')


class HashJoinOptimization(BaseRule):
    name = "hash_join_optimization"
    category = "incremental/stage_optimization"
    description = "检测 Hash Join build/probe 数据量不对称和 Broadcast Join 性能问题"

    # --- 前置过滤 ---
    STAGE_TIME_THRESHOLD_MS = 10000
    STAGE_PERCENT_THRESHOLD = 8.0

    # --- build/probe 不对称阈值 ---
    BUILD_PROBE_RATIO_THRESHOLD = 10.0

    # --- join 算子耗时门槛：低于此值的 build heavy 降级为 detail（仅 expert 模式输出） ---
    JOIN_TIME_IMPORTANT_MS = 5000

    # --- broadcast join 耗时占比阈值 ---
    JOIN_PERCENT_THRESHOLD = 30.0

    # --- broadcast build 侧真实数据量阈值：超过此值才认为广播开销大 ---
    BROADCAST_BUILD_SIZE_THRESHOLD = 2 * 1024 ** 3  # 2 GB

    def check(self, stage_data: Dict, context: Dict) -> bool:
        if not self.has_profile_data(context):
            return False

        metrics = stage_data.get('metrics', {})
        total_time = context.get('total_job_time', 0)
        elapsed_ms = metrics.get('elapsed_ms', 0)
        time_pct = (elapsed_ms / total_time * 100) if total_time else 0

        if elapsed_ms < self.STAGE_TIME_THRESHOLD_MS and time_pct < self.STAGE_PERCENT_THRESHOLD:
            return False

        # 遍历 plan operators，检查是否存在 hashJoin 算子
        plan_operators = stage_data.get('plan_operators', [])
        for op in plan_operators:
            if 'hashJoin' in op:
                return True
        return False

    def analyze(self, stage_data: Dict, context: Dict) -> Dict:
        stage_id = stage_data.get('stage_id', 'unknown')
        metrics = stage_data.get('metrics', {})
        profile = stage_data.get('profile', {})
        plan_operators = stage_data.get('plan_operators', [])
        settings = context.get('settings', {})
        total_time = context.get('total_job_time', 0)

        elapsed_ms = metrics.get('elapsed_ms', 0)
        stage_pct = (elapsed_ms / total_time * 100) if total_time > 0 else 0

        findings, recommendations, insights = [], [], []

        # 构建 operator id -> operator 映射（用于递归查找叶子节点）
        op_map = {op['id']: op for op in plan_operators if 'id' in op}
        op_summary = profile.get('operatorSummary', {})

        # 构建跨 stage 的 ShuffleWrite profile 映射（用于获取真实广播数据量）
        shuffle_write_summary = self._build_shuffle_write_summary(context)

        for op in plan_operators:
            if 'hashJoin' not in op:
                continue

            op_id = op['id']
            hj = op['hashJoin']
            is_broadcast = hj.get('broadcast', False)
            probe_op_id = hj.get('probeOperatorId', '')
            input_ids = op.get('inputIds', [])

            # 确定 build 侧：inputIds 中不是 probe 的那个
            build_op_id = None
            for iid in input_ids:
                if iid != probe_op_id:
                    build_op_id = iid
                    break
            if not build_op_id:
                continue

            is_df = self._is_df_join(op)

            # --- 检测 1: build/probe 数据量不对称 ---
            build_bytes, build_rows = self._get_subtree_data(
                build_op_id, op_map, op_summary, shuffle_write_summary)
            probe_bytes, probe_rows = self._get_subtree_data(
                probe_op_id, op_map, op_summary, shuffle_write_summary)

            # 优先用 bytes 判断，fallback 到 rowCount
            if build_bytes > 0 and probe_bytes > 0:
                ratio = build_bytes / probe_bytes
                ratio_desc = (f"build 侧 {self._fmt_bytes(build_bytes)} vs "
                              f"probe 侧 {self._fmt_bytes(probe_bytes)}，"
                              f"比值 {ratio:.1f}x")
                use_bytes = True
            elif build_rows > 0 and probe_rows > 0:
                ratio = build_rows / probe_rows
                ratio_desc = (f"build 侧 {self._fmt_rows(build_rows)} vs "
                              f"probe 侧 {self._fmt_rows(probe_rows)}，"
                              f"比值 {ratio:.1f}x")
                use_bytes = False
            else:
                ratio = 0
                ratio_desc = ''
                use_bytes = False

            if ratio >= self.BUILD_PROBE_RATIO_THRESHOLD:
                join_type = 'Broadcast' if is_broadcast else 'Shuffle'
                # HashJoin 算子自身的耗时
                hj_profile = op_summary.get(op_id, {})
                hj_max_ms = int(hj_profile.get('wallTimeNs', {}).get('max', 0)) / 1_000_000

                # 耗时低的降级为 detail（仅 expert 模式输出）
                is_important = hj_max_ms >= self.JOIN_TIME_IMPORTANT_MS

                # df_and join 是增量框架自动生成的，build/probe 由框架决定，降级为 detail
                if is_df:
                    is_important = False

                insight_level = 'important' if is_important else 'detail'

                time_desc = (f"算子耗时 {hj_max_ms/1000:.1f}s，"
                             f"Stage 耗时 {elapsed_ms/1000:.1f}s (占整体 {stage_pct:.1f}%)")

                finding_details = {
                    'operator_id': op_id,
                    'join_type': join_type,
                    'is_df_join': is_df,
                    'build_operator': build_op_id,
                    'probe_operator': probe_op_id,
                    'build_bytes': build_bytes,
                    'probe_bytes': probe_bytes,
                    'build_rows': build_rows,
                    'probe_rows': probe_rows,
                    'ratio': ratio,
                    'ratio_based_on': 'bytes' if use_bytes else 'rows',
                    'join_time_ms': hj_max_ms,
                    'stage_elapsed_ms': elapsed_ms,
                    'stage_total_pct': stage_pct,
                }

                if is_broadcast:
                    severity = 'HIGH' if is_important else 'LOW'
                    findings.append(self.create_finding(
                        'HASH_JOIN_BUILD_HEAVY', stage_id, severity,
                        f"{op_id}（{join_type} Hash Join）build 侧数据量远大于 probe 侧：{ratio_desc}，{time_desc}",
                        finding_details, confidence='high'
                    ))
                    # 只有耗时够高且非 df_and 才给 recommendation
                    if is_important:
                        param = 'cz.optimizer.enable.broadcast.hash.join'
                        if settings.get(param) != 'false':
                            recommendations.append(self.build_recommendation_with_table_check(
                                param, 'false', 2,
                                f"Stage {stage_id}: {op_id} (Broadcast Hash Join) build 侧数据量远大于 probe 侧"
                                f"（{ratio_desc}），{time_desc}，"
                                f"广播大表会导致严重性能问题，建议关闭 Broadcast Hash Join",
                                'HIGH', context, settings.get(param),
                                warning="禁用后将使用 Shuffle Hash Join，需观察整体性能变化",
                                stage_id=stage_id))
                    insights.append(self.create_insight(
                        f"Stage {stage_id}: {op_id} 是 Broadcast Hash Join，build 侧数据量远大于 probe 侧"
                        f"（{ratio_desc}），{time_desc}，"
                        f"广播大表导致每个 task 都要构建巨大的 hash table，建议关闭 broadcast hash join",
                        stage_id, level=insight_level
                    ))
                else:
                    severity = 'MEDIUM' if is_important else 'LOW'
                    findings.append(self.create_finding(
                        'HASH_JOIN_BUILD_HEAVY', stage_id, severity,
                        f"{op_id}（{join_type} Hash Join）build 侧数据量远大于 probe 侧：{ratio_desc}，{time_desc}",
                        finding_details, confidence='high'
                    ))
                    insights.append(self.create_insight(
                        f"Stage {stage_id}: {op_id} 是 Shuffle Hash Join，build 侧数据量远大于 probe 侧"
                        f"（{ratio_desc}），{time_desc}，"
                        f"build side 选择可能不合理，大表作为 build 侧会导致 hash table 过大，增加内存压力和 spilling 风险",
                        stage_id, level=insight_level
                    ))

            # --- 检测 2: Broadcast Join 耗时占比高 + build 侧数据量大 ---
            if is_broadcast:
                hj_profile = op_summary.get(op_id, {})
                hj_max_ms = int(hj_profile.get('wallTimeNs', {}).get('max', 0)) / 1_000_000
                if elapsed_ms > 0 and hj_max_ms > 0:
                    join_pct = hj_max_ms / elapsed_ms * 100
                    if join_pct > self.JOIN_PERCENT_THRESHOLD:
                        # 避免和 build heavy 重复报 finding
                        if ratio < self.BUILD_PROBE_RATIO_THRESHOLD:
                            # 获取 build 侧真实数据量（追溯 ShuffleWrite）
                            real_build_bytes = self._get_real_broadcast_build_bytes(
                                build_op_id, op_map, shuffle_write_summary, op_summary)

                            build_info = ""
                            probe_info = ""
                            if real_build_bytes > 0:
                                build_info = f"，build 侧真实数据量 {self._fmt_bytes(real_build_bytes)}"
                            elif build_bytes > 0:
                                build_info = f"，build 侧数据量 {self._fmt_bytes(build_bytes)}"
                            elif build_rows > 0:
                                build_info = f"，build 侧数据量 {self._fmt_rows(build_rows)}"
                            if probe_bytes > 0:
                                probe_info = f"，probe 侧数据量 {self._fmt_bytes(probe_bytes)}"
                            elif probe_rows > 0:
                                probe_info = f"，probe 侧数据量 {self._fmt_rows(probe_rows)}"

                            actual_build = real_build_bytes if real_build_bytes > 0 else build_bytes
                            build_is_large = actual_build >= self.BROADCAST_BUILD_SIZE_THRESHOLD

                            # df_and join 降级为 detail，不产生 recommendation
                            if is_df:
                                insights.append(self.create_insight(
                                    f"Stage {stage_id}: {op_id} 是 df_and Broadcast Join，"
                                    f"耗时 {hj_max_ms/1000:.1f}s ({join_pct:.0f}%){build_info}{probe_info}，"
                                    f"Stage 耗时 {elapsed_ms/1000:.1f}s (占整体 {stage_pct:.1f}%)，"
                                    f"df_and join 由增量框架自动生成，build/probe 选择不可调",
                                    stage_id, level='detail'
                                ))
                            elif build_is_large:
                                # build 侧数据量大 → 产生 finding + recommendation
                                findings.append(self.create_finding(
                                    'BROADCAST_JOIN_SLOW', stage_id, 'MEDIUM',
                                    f"{op_id}: Broadcast Join 耗时 {hj_max_ms/1000:.1f}s "
                                    f"({join_pct:.0f}%){build_info}{probe_info}，"
                                    f"Stage 耗时 {elapsed_ms/1000:.1f}s (占整体 {stage_pct:.1f}%)",
                                    {
                                        'operator_id': op_id,
                                        'join_time_ms': hj_max_ms,
                                        'join_pct': join_pct,
                                        'build_bytes': actual_build,
                                        'probe_bytes': probe_bytes,
                                        'build_rows': build_rows,
                                        'probe_rows': probe_rows,
                                        'stage_elapsed_ms': elapsed_ms,
                                        'stage_total_pct': stage_pct,
                                    },
                                    confidence='high'
                                ))
                                param = 'cz.optimizer.enable.broadcast.hash.join'
                                if settings.get(param) != 'false':
                                    recommendations.append(self.build_recommendation_with_table_check(
                                        param, 'false', 2,
                                        f"Stage {stage_id}: {op_id} (Broadcast Join) 耗时 {hj_max_ms/1000:.1f}s "
                                        f"(占 Stage {join_pct:.0f}%){build_info}{probe_info}，"
                                        f"Broadcast 需要将 build 侧数据广播到所有 task，数据量大时开销显著，"
                                        f"Stage 耗时 {elapsed_ms/1000:.1f}s (占整体 {stage_pct:.1f}%)，"
                                        f"建议关闭 Broadcast Hash Join 改用 Shuffle Hash Join",
                                        'MEDIUM', context, settings.get(param),
                                        warning="禁用后将使用 Shuffle Hash Join，需观察整体性能变化",
                                        stage_id=stage_id))
                            else:
                                # build 侧数据量不大，慢的原因可能是别的，仅产生 insight
                                insights.append(self.create_insight(
                                    f"Stage {stage_id}: {op_id} 是 Broadcast Join，"
                                    f"耗时 {hj_max_ms/1000:.1f}s ({join_pct:.0f}%){build_info}{probe_info}，"
                                    f"Stage 耗时 {elapsed_ms/1000:.1f}s (占整体 {stage_pct:.1f}%)，"
                                    f"build 侧数据量未超过阈值，慢的原因可能是数据倾斜或计算复杂度",
                                    stage_id, level='important'
                                ))

        # 存储分析详情
        self.add_analysis_detail(context, 'hash_join_analysis', {
            'stage_elapsed_ms': elapsed_ms,
            'stage_total_pct': stage_pct,
            'findings_count': len(findings),
        }, stage_id=stage_id)

        return {'findings': findings, 'recommendations': recommendations, 'insights': insights}

    # ---- 内部方法 ----

    @staticmethod
    def _is_df_join(op: Dict) -> bool:
        """判断 hashJoin 是否是 df_and 类型，委托给公共工具函数"""
        from ....utils.plan_navigator import is_df_and_join
        return is_df_and_join(op)

    @staticmethod
    def _build_shuffle_write_summary(context: Dict) -> Dict:
        """从所有 stage 的 profile 中构建 ShuffleWrite op_id -> outputBytes 的映射。

        用于在 broadcast 场景下获取 build 侧的真实数据量（而非 ShuffleRead 的放大值）。
        """
        result = {}
        aligned_stages = context.get('aligned_stages', {})
        for stage_id, stage_data in aligned_stages.items():
            profile = stage_data.get('profile', {})
            op_summary = profile.get('operatorSummary', {})
            for op_id, op_data in op_summary.items():
                if op_id.startswith('ShuffleWrite'):
                    io_stats = op_data.get('inputOutputStats', {})
                    output_bytes = int(io_stats.get('outputBytes', 0))
                    result[op_id] = output_bytes
        return result

    def _get_real_broadcast_build_bytes(self, build_op_id: str, op_map: Dict,
                                         shuffle_write_summary: Dict,
                                         op_summary: Dict) -> int:
        """获取 broadcast build 侧的真实数据量。

        从 build_op_id 递归找到 ShuffleRead 叶子节点，再通过其 inputIds 找到
        上游 ShuffleWrite，取 ShuffleWrite 的 outputBytes 作为真实广播数据量。

        如果 build 侧是 TableScan（没有 ShuffleRead），返回 0 表示无需修正。
        """
        # 递归找到 build 侧的所有 ShuffleRead 叶子
        shuffle_reads = self._find_shuffle_reads(build_op_id, op_map, set())
        if not shuffle_reads:
            return 0

        total_bytes = 0
        for sr_op_id in shuffle_reads:
            sr_op = op_map.get(sr_op_id)
            if not sr_op:
                continue
            # ShuffleRead 的 inputIds 指向上游 ShuffleWrite
            for sw_id in sr_op.get('inputIds', []):
                if sw_id.startswith('ShuffleWrite') and sw_id in shuffle_write_summary:
                    total_bytes += shuffle_write_summary[sw_id]
        return total_bytes

    def _find_shuffle_reads(self, op_id: str, op_map: Dict, visited: set) -> List[str]:
        """递归找到子树中所有 ShuffleRead 叶子节点的 op_id"""
        if op_id in visited:
            return []
        visited.add(op_id)

        if op_id.startswith('ShuffleRead'):
            return [op_id]

        # 其他叶子类型，不含 ShuffleRead
        if any(op_id.startswith(p) for p in ('TableScan', 'Values', 'Buffer')):
            return []

        op = op_map.get(op_id)
        if not op:
            return []

        result = []
        for iid in op.get('inputIds', []):
            result.extend(self._find_shuffle_reads(iid, op_map, visited))
        return result

    def _get_subtree_data(self, op_id: str, op_map: Dict,
                          op_summary: Dict,
                          shuffle_write_summary: Dict = None) -> Tuple[int, int]:
        """递归沿 inputIds 找到叶子节点，汇总 bytes 和 rowCount。

        叶子节点：TableScan / ShuffleRead / Values / Buffer，或 op_map 中找不到的算子。
        对于 ShuffleRead 叶子节点，如果提供了 shuffle_write_summary，
        则追溯上游 ShuffleWrite 获取真实数据量（避免 broadcast 放大）。
        其他叶子节点从 profile operatorSummary 取 inputOutputStats.inputBytes 和 rowCount.sum。

        Returns:
            (total_bytes, total_rows)
        """
        return self._collect_leaf_data(op_id, op_map, op_summary,
                                       shuffle_write_summary or {}, set())

    def _collect_leaf_data(self, op_id: str, op_map: Dict,
                           op_summary: Dict,
                           shuffle_write_summary: Dict,
                           visited: set) -> Tuple[int, int]:
        """递归收集叶子节点数据，带环检测"""
        if op_id in visited:
            return 0, 0
        visited.add(op_id)

        # 判断是否是叶子节点
        is_leaf = any(op_id.startswith(prefix) for prefix in LEAF_PREFIXES)
        if is_leaf or op_id not in op_map:
            # ShuffleRead: 尝试追溯上游 ShuffleWrite 获取真实数据量
            if op_id.startswith('ShuffleRead') and shuffle_write_summary:
                real_bytes, real_rows = self._get_shuffle_write_data(
                    op_id, op_map, shuffle_write_summary, op_summary)
                if real_bytes > 0 or real_rows > 0:
                    return real_bytes, real_rows
            return self._extract_op_data(op_id, op_summary)

        # 非叶子：递归 inputIds
        op = op_map[op_id]
        input_ids = op.get('inputIds', [])
        if not input_ids:
            # 没有 input 的非叶子节点，当作叶子处理
            return self._extract_op_data(op_id, op_summary)

        total_bytes, total_rows = 0, 0
        for iid in input_ids:
            b, r = self._collect_leaf_data(iid, op_map, op_summary,
                                           shuffle_write_summary, visited)
            total_bytes += b
            total_rows += r
        return total_bytes, total_rows

    @staticmethod
    def _get_shuffle_write_data(sr_op_id: str, op_map: Dict,
                                 shuffle_write_summary: Dict,
                                 op_summary: Dict) -> Tuple[int, int]:
        """从 ShuffleRead 追溯上游 ShuffleWrite，获取真实数据量。

        Returns:
            (bytes, rows) 来自上游 ShuffleWrite；如果找不到返回 (0, 0)
        """
        sr_op = op_map.get(sr_op_id)
        if not sr_op:
            return 0, 0

        total_bytes, total_rows = 0, 0
        found = False
        for sw_id in sr_op.get('inputIds', []):
            if sw_id.startswith('ShuffleWrite') and sw_id in shuffle_write_summary:
                total_bytes += shuffle_write_summary[sw_id]
                # ShuffleWrite 的 rowCount 从 op_summary 获取
                sw_data = op_summary.get(sw_id, {})
                total_rows += int(sw_data.get('rowCount', {}).get('sum', 0))
                found = True

        # 如果 ShuffleWrite 不在当前 stage 的 op_summary 中，
        # 尝试从 shuffle_write_summary 的全局映射获取（已在 _build_shuffle_write_summary 中收集）
        if not found:
            # fallback: 从 ShuffleRead 的 exchangeSourceSummary.compressedShuffleBytes.max 获取
            # 这是单个 task 读取的最大值，对于 broadcast 就是真实数据量
            sr_data = op_summary.get(sr_op_id, {})
            exchange_src = sr_data.get('exchangeSourceSummary', {})
            compressed = exchange_src.get('compressedShuffleBytes', {})
            max_bytes = int(compressed.get('max', 0))
            if max_bytes > 0:
                total_bytes = max_bytes
                total_rows = int(sr_data.get('rowCount', {}).get('max', 0))
                found = True

        return (total_bytes, total_rows) if found else (0, 0)

    @staticmethod
    def _extract_op_data(op_id: str, op_summary: Dict) -> Tuple[int, int]:
        """从 profile operatorSummary 提取单个算子的 bytes 和 rowCount"""
        op_data = op_summary.get(op_id, {})
        io_stats = op_data.get('inputOutputStats', {})
        bytes_val = int(io_stats.get('inputBytes', 0))
        rows_val = int(op_data.get('rowCount', {}).get('sum', 0))
        return bytes_val, rows_val

    @staticmethod
    def _fmt_bytes(b: int) -> str:
        if b >= 1024 ** 3:
            return f"{b / (1024**3):.1f} GB"
        if b >= 1024 ** 2:
            return f"{b / (1024**2):.0f} MB"
        return f"{b / 1024:.0f} KB"

    @staticmethod
    def _fmt_rows(r: int) -> str:
        if r >= 1_0000_0000:
            return f"{r / 1_0000_0000:.1f}亿行"
        if r >= 1_0000:
            return f"{r / 1_0000:.0f}万行"
        return f"{r}行"
