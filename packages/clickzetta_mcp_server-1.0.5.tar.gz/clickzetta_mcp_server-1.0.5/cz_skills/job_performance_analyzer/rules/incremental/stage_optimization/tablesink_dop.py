#!/usr/bin/env python3
"""TableSink DOP 优化规则"""
import logging
from typing import Dict, List
from ...base_rule import BaseRule
from ....utils.plan_navigator import create_stage_navigator

# 创建 logger
logger = logging.getLogger(__name__)


class TableSinkDop(BaseRule):
    name = "tablesink_dop"
    category = "incremental/stage_optimization"
    description = "检测 TableSink Stage 的 DOP 是否被自动调小"
    STAGE_PCT_THRESHOLD = 0.10  # Stage 耗时占总体 10%
    DOP_RATIO_THRESHOLD = 0.5

    def check(self, stage_data: Dict, context: Dict) -> bool:
        stage_id = stage_data.get('stage_id', 'unknown')
        
        # 如果没有 profile 数据，跳过此规则（需要运行时性能数据）
        if not self.has_profile_data(context):
            logger.debug(f"[tablesink_dop] Stage {stage_id}: no profile data, skipping")
            return False

        metrics = stage_data.get('metrics', {})
        navigator = create_stage_navigator(stage_data)

        # 检查是否包含 TableSink 算子（且不是 partial sink）
        if not navigator.has_operator('TableSink'):
            logger.debug(f"[tablesink_dop] Stage {stage_id}: no TableSink operator, skipping")
            return False
        
        # 检查是否为 partial sink 或 DELTA sink
        plan = stage_data.get('plan', {})
        operators = plan.get('operators', [])
        
        has_valid_sink = False
        for op in operators:
            if 'tableSink' in op:
                table_sink = op.get('tableSink', {})
                flags = table_sink.get('flags', 0)
                
                # 跳过 partial sink (flags & 0x20 != 0)
                if (flags & 0x20) != 0:
                    logger.debug(f"[tablesink_dop] Stage {stage_id}: partial sink (flags={flags}), skipping")
                    continue
                
                # 跳过 DELTA sink (path 最后一个元素是 __delta__)
                table = table_sink.get('table', {})
                path = table.get('path', [])
                if len(path) == 4 and path[-1] == '__delta__':
                    logger.debug(f"[tablesink_dop] Stage {stage_id}: DELTA sink (path={path}), skipping")
                    continue
                
                # 找到有效的 TableSink
                has_valid_sink = True
                break
        
        if not has_valid_sink:
            logger.debug(f"[tablesink_dop] Stage {stage_id}: no valid TableSink (all are partial or DELTA), skipping")
            return False
        
        # 检查 Stage 耗时占总体是否 > 10%
        total_elapsed_ms = context.get('total_job_time', 0)
        if total_elapsed_ms == 0:
            logger.debug(f"[tablesink_dop] Stage {stage_id}: total_job_time is 0, skipping")
            return False
        
        stage_elapsed_ms = metrics.get('elapsed_ms', 0)
        stage_pct = stage_elapsed_ms / total_elapsed_ms if total_elapsed_ms > 0 else 0
        
        logger.debug(f"[tablesink_dop] Stage {stage_id}: elapsed={stage_elapsed_ms}ms, total={total_elapsed_ms}ms, pct={stage_pct:.1%}, threshold={self.STAGE_PCT_THRESHOLD:.1%}")
        
        return stage_pct >= self.STAGE_PCT_THRESHOLD

    def analyze(self, stage_data: Dict, context: Dict) -> Dict:
        stage_id = stage_data.get('stage_id', 'unknown')
        metrics = stage_data.get('metrics', {})
        settings = context.get('settings', {})
        
        # 使用实际运行的 DOP（从 job_profile.json 的 taskCount）
        current_dop = metrics.get('actual_dop', metrics.get('dop', 0))
        # 同时记录 plan 中的估算 DOP，用于对比
        plan_dop = metrics.get('plan_dop', 0)

        findings, recommendations, insights = [], [], []

        # 获取真正的上游 stage DOP
        upstream_stages = stage_data.get('upstream_stages', [])
        aligned_stages = context.get('aligned_stages', {})

        logger.debug(f"[tablesink_dop] Stage {stage_id}: upstream_stages={upstream_stages}, current_dop={current_dop}, plan_dop={plan_dop}")

        upstream_dops = []
        for upstream_id in upstream_stages:
            # 从 metrics 中获取上游 stage 的实际 DOP
            if upstream_id in aligned_stages:
                upstream_metrics = aligned_stages[upstream_id].get('metrics', {})
                upstream_dop = upstream_metrics.get('actual_dop', upstream_metrics.get('dop', 0))
                if upstream_dop > 0:
                    upstream_dops.append(upstream_dop)
                    logger.debug(f"[tablesink_dop] Stage {stage_id}: found upstream {upstream_id} with actual_dop={upstream_dop}")

        if not upstream_dops:
            logger.debug(f"[tablesink_dop] Stage {stage_id}: no valid upstream stages found, skipping DOP check")
            insights.append(self.create_insight(
                f"Stage {stage_id}: 无法找到上游 Stage，跳过 DOP 检查", stage_id))
            return {'findings': findings, 'recommendations': recommendations, 'insights': insights}

        max_upstream = max(upstream_dops)

        # 检查 DOP 是否被调小
        if current_dop >= max_upstream:
            # 下游 DOP 大于等于上游，不需要调整
            logger.debug(f"[tablesink_dop] Stage {stage_id}: DOP={current_dop} >= max_upstream={max_upstream}, no adjustment needed")
            insights.append(self.create_insight(
                f"Stage {stage_id}: DOP={current_dop} >= 上游最大 DOP={max_upstream}，无需调整", stage_id))
        else:
            dop_ratio = current_dop / max_upstream
            logger.debug(f"[tablesink_dop] Stage {stage_id}: DOP={current_dop}, max_upstream={max_upstream}, ratio={dop_ratio:.4f}, threshold={self.DOP_RATIO_THRESHOLD}")
            
            if dop_ratio >= self.DOP_RATIO_THRESHOLD:
                # DOP 差异不大
                logger.debug(f"[tablesink_dop] Stage {stage_id}: DOP ratio {dop_ratio:.4f} >= threshold {self.DOP_RATIO_THRESHOLD}, no adjustment needed")
                insights.append(self.create_insight(
                    f"Stage {stage_id}: DOP={current_dop} 与上游接近 (max={max_upstream})，无需调整", stage_id))
            else:
                # DOP 被显著调小
                logger.debug(f"[tablesink_dop] Stage {stage_id}: DOP significantly reduced - current={current_dop}, max_upstream={max_upstream}, ratio={dop_ratio:.4f}")
                findings.append(self.create_finding('TABLESINK_DOP', stage_id, 'MEDIUM',
                    f"TableSink actual_dop={current_dop} 远小于上游 (max={max_upstream}, ratio={dop_ratio:.2f})",
                    {'current_dop': current_dop, 'plan_dop': plan_dop, 'max_upstream_dop': max_upstream,
                     'upstream_dops': upstream_dops, 'dop_ratio': dop_ratio},
                    confidence='high'))

                param = 'cz.sql.enable.dag.auto.adaptive.split.size'

                # 只有当参数已经设置为 true 时才推荐设置为 false
                if settings.get(param) == 'true':
                    logger.info(f"[tablesink_dop] Stage {stage_id}: recommending to disable {param}")
                    recommendations.append(self.build_recommendation_with_table_check(
                        param, 'false', 2,
                        f"Stage {stage_id}: TableSink actual_dop={current_dop} (plan_dop={plan_dop}) 可能被自动调小 (上游max={max_upstream})",
                        'MEDIUM', context, settings.get(param),
                        warning="该参数影响TableSink stage的DOP，目的是不根据table的目标文件大小来自动调整DOP"))
                else:
                    logger.debug(f"[tablesink_dop] Stage {stage_id}: {param} not set to true, no recommendation needed")
                    insights.append(self.create_insight(
                        f"Stage {stage_id}: DOP被调小但参数 {param} 未设置为true，无需调整", stage_id))

        return {'findings': findings, 'recommendations': recommendations, 'insights': insights}

