#!/usr/bin/env python3
"""主动问题发现规则 — 关联分析已有 findings，做瓶颈归因"""
from typing import Dict, List
from ...base_rule import BaseRule


class ActiveProblemFinding(BaseRule):
    name = "active_problem_finding"
    category = "incremental/stage_optimization"
    description = "主动分析 Top 耗时 Stage 的瓶颈原因，关联其他规则的 findings 做因果链推理"
    MIN_STAGE_TIME_MS = 5000
    SINGLE_OP_THRESHOLD = 80.0

    # DATA_SKEW 噪音过滤门槛
    MIN_BOTTLENECK_TIME_MS = 5000     # 瓶颈算子耗时 < 5s 不报倾斜
    MIN_SHUFFLE_BYTES = 500 * 1024 * 1024  # Shuffle 总量 < 500MB 不报倾斜

    # 算子类型 → 更具体的建议
    OP_TYPE_SUGGESTIONS = {
        'Calc': '可能是 UDF 或复杂表达式导致，检查 Calc 算子内的计算逻辑',
        'HashAggregate': '聚合数据量大或 group by 基数高，检查是否可以预聚合或减少分组数',
        'HashAgg': '聚合数据量大或 group by 基数高，检查是否可以预聚合或减少分组数',
        'ShuffleWrite': '检查上游数据分布或考虑减少 shuffle 数据量',
        'ShuffleRead': 'Shuffle 读取耗时高，可能是数据倾斜或网络瓶颈',
        'TableScan': '表扫描耗时高，检查是否可以减少扫描范围或优化文件布局',
        'TableSink': '数据写入耗时高，检查目标表的文件数量和 compaction 状态',
        'HashJoin': 'Join 耗时高，检查 join key 分布是否均匀',
        'Window': '窗口函数耗时高，检查窗口大小和分区策略',
    }

    def check(self, stage_data: Dict, context: Dict) -> bool:
        if not self.has_profile_data(context):
            return False
        return True

    def analyze(self, stage_data: Dict, context: Dict) -> Dict:
        stage_id = stage_data.get('stage_id', 'unknown')
        metrics = stage_data.get('metrics', {})
        profile = stage_data.get('profile', {})
        total_time = context.get('total_job_time', 0)
        operator_analysis = context.get('operator_analysis', [])

        elapsed_ms = metrics.get('elapsed_ms', 0)
        time_pct = (elapsed_ms / total_time * 100) if total_time else 0
        dop = metrics.get('dop', 0)

        # 直接从 aligner metrics 读取有效 spill（排除 Shuffle 算子）
        effective_spill_gb = metrics.get('effective_spill_gb', 0)

        findings, recommendations, insights = [], [], []

        if elapsed_ms < self.MIN_STAGE_TIME_MS:
            return {'findings': findings, 'recommendations': recommendations, 'insights': insights}

        # 找瓶颈 Operator
        stage_ops = sorted([op for op in operator_analysis if op['stage_id'] == stage_id],
                          key=lambda x: x['max_time_ms'], reverse=True)
        bottleneck = stage_ops[0] if stage_ops else None

        # 关联分析：从 context 中读取其他规则已产出的 findings
        existing_findings = self._get_existing_findings_for_stage(stage_id, context)

        # 分析问题
        problems = self._analyze_problems(stage_id, elapsed_ms, dop, effective_spill_gb,
                                          bottleneck, existing_findings, context)

        if problems:
            severity = 'HIGH' if time_pct > 30 else 'MEDIUM'
            confidence = 'high'
            findings.append(self.create_finding('BOTTLENECK_ANALYSIS', stage_id, severity,
                f"Stage 耗时 {elapsed_ms/1000:.1f}s ({time_pct:.1f}%)",
                {'elapsed_ms': elapsed_ms, 'time_pct': time_pct, 'problems': problems},
                confidence=confidence))
            for p in problems:
                insights.append(self.create_insight(
                    f"Stage {stage_id}: {p['description']}. 建议: {p['suggestion']}", stage_id))

        # 瓶颈算子信息存入 analysis_scope（不再作为 insight 输出）
        if bottleneck:
            self.add_analysis_detail(context, 'bottleneck', {
                'problems': problems if problems else [],
                'bottleneck_operator': {
                    'operator_id': bottleneck['operator_id'],
                    'max_time_ms': bottleneck['max_time_ms'],
                    'stage_pct': bottleneck['stage_pct'],
                    'skew_ratio': bottleneck.get('skew_ratio', 1.0)
                },
                'existing_findings': [f['type'] for f in existing_findings],
            }, stage_id=stage_id)

        return {'findings': findings, 'recommendations': recommendations, 'insights': insights}

    def _get_existing_findings_for_stage(self, stage_id: str, context: Dict) -> List[Dict]:
        """从 context 中读取其他规则已产出的、属于该 stage 的 findings"""
        all_results = context.get('all_results', {})
        all_findings = all_results.get('findings', [])
        return [f for f in all_findings if f.get('stage_id') == stage_id and f.get('rule') != self.name]

    def _get_op_type_suggestion(self, operator_id: str) -> str:
        """根据算子名称推断类型并给出更具体的建议"""
        for op_type, suggestion in self.OP_TYPE_SUGGESTIONS.items():
            if op_type in operator_id:
                return suggestion
        return '检查算子逻辑和数据分布'

    def _format_data_volume(self, bottleneck: Dict) -> str:
        """从瓶颈算子的 operator_data 中提取数据量，返回格式化字符串

        Shuffle 算子：使用 compressedShuffleBytes 的 sum/max/avg
        其他算子：使用 rowCount 的 sum/max/avg
        返回空字符串表示无可用数据。
        """
        op_data = bottleneck.get('operator_data', {})
        op_id = bottleneck.get('operator_id', '')

        # Shuffle 算子：展示 shuffle bytes 分布
        is_shuffle = any(p in op_id for p in ('ShuffleWrite', 'ShuffleExchange', 'Exchange'))
        if is_shuffle:
            ess = op_data.get('exchangeSinkSummary', {})
            shuffle_bytes = ess.get('compressedShuffleBytes', {})
            total = int(shuffle_bytes.get('sum', 0))
            max_val = int(shuffle_bytes.get('max', 0))
            avg_val = int(shuffle_bytes.get('avg', 0))
            if total > 0:
                return (f"，Shuffle 总量 {self._format_bytes(total)}"
                        f"（max {self._format_bytes(max_val)} / avg {self._format_bytes(avg_val)}）")

        # 非 Shuffle 算子或 Shuffle 无 exchangeSinkSummary：用 rowCount
        row_stats = op_data.get('rowCount', {})
        total_rows = int(row_stats.get('sum', 0))
        max_rows = int(row_stats.get('max', 0))
        avg_rows = int(row_stats.get('avg', 0))
        if total_rows > 0:
            return (f"，数据量 {self._format_rows(total_rows)}"
                    f"（max {self._format_rows(max_rows)} / avg {self._format_rows(avg_rows)}）")

        return ''

    @staticmethod
    def _get_shuffle_total_bytes(bottleneck: Dict) -> int:
        """获取 Shuffle 算子的压缩后总字节数"""
        op_data = bottleneck.get('operator_data', {})
        ess = op_data.get('exchangeSinkSummary', {})
        shuffle_bytes = ess.get('compressedShuffleBytes', {})
        return int(shuffle_bytes.get('sum', 0))

    @staticmethod
    def _format_bytes(b: int) -> str:
        if b >= 1024 ** 3:
            return f"{b / (1024**3):.1f} GB"
        if b >= 1024 ** 2:
            return f"{b / (1024**2):.0f} MB"
        return f"{b / 1024:.0f} KB"

    @staticmethod
    def _format_rows(r: int) -> str:
        if r >= 1_0000_0000:  # 亿
            return f"{r / 1_0000_0000:.1f}亿行"
        if r >= 1_0000:  # 万
            return f"{r / 1_0000:.0f}万行"
        return f"{r}行"


    def _analyze_problems(self, stage_id, elapsed_ms, dop, spill_gb,
                          bottleneck, existing_findings, context) -> List[Dict]:
        problems = []
        existing_types = {f.get('type') for f in existing_findings}

        # 1. 数据倾斜 — 只在其他规则没有报告 DATA_SKEW 时才报告（避免重复）
        # 额外门槛：瓶颈算子耗时 >= 5s，Shuffle 算子还要求 shuffle 总量 >= 500MB
        if bottleneck and bottleneck.get('skew_ratio', 1) > 5.0 and 'DATA_SKEW' not in existing_types:
            # 门槛 1：瓶颈算子绝对耗时太短的不报
            if bottleneck['max_time_ms'] >= self.MIN_BOTTLENECK_TIME_MS:
                # 门槛 2：Shuffle 算子还要看数据量
                op_id = bottleneck.get('operator_id', '')
                is_shuffle = any(p in op_id for p in ('ShuffleWrite', 'ShuffleExchange', 'Exchange'))
                skip = False
                if is_shuffle:
                    shuffle_bytes = self._get_shuffle_total_bytes(bottleneck)
                    if shuffle_bytes < self.MIN_SHUFFLE_BYTES:
                        skip = True

                if not skip:
                    volume_desc = self._format_data_volume(bottleneck)
                    problems.append({
                        'type': 'DATA_SKEW',
                        'description': f"数据倾斜 {bottleneck['skew_ratio']:.1f}x，"
                                       f"瓶颈算子 {bottleneck['operator_id']} "
                                       f"耗时 {bottleneck['max_time_ms']/1000:.1f}s"
                                       f"（Stage 总耗时 {elapsed_ms/1000:.1f}s）"
                                       f"{volume_desc}",
                        'suggestion': self._get_op_type_suggestion(bottleneck['operator_id']),
                        'severity': 'HIGH'
                    })

        # 2. 单算子主导 — 给出更具体的建议
        if bottleneck and bottleneck.get('stage_pct', 0) > self.SINGLE_OP_THRESHOLD:
            suggestion = self._get_op_type_suggestion(bottleneck['operator_id'])
            volume_desc = self._format_data_volume(bottleneck)
            problems.append({
                'type': 'SINGLE_OP_DOMINANT',
                'description': f"算子 {bottleneck['operator_id']} 占 Stage 耗时 {bottleneck['stage_pct']:.1f}%，"
                               f"耗时 {bottleneck['max_time_ms']/1000:.1f}s（Stage 总耗时 {elapsed_ms/1000:.1f}s）"
                               f"{volume_desc}",
                'suggestion': suggestion,
                'severity': 'MEDIUM'
            })

        # 3. LOW_DOP — DOP=1 通常是 singleton shuffle（全局聚合/排序），属于正常行为
        # 只有 DOP>1 且仍然很低时才可能是真正的问题
        # 即使如此，DOP 主要由数据分区数和 shuffle 策略决定，不一定是资源不足
        if dop > 1 and dop <= 4:
            vc_info = context.get('vc_mode_info', {})
            vc_cores = vc_info.get('vc_cores', 0)
            if vc_cores > 0:
                problems.append({
                    'type': 'LOW_DOP',
                    'description': f"DOP={dop}（VC 可用核数 {vc_cores}），Stage 耗时 {elapsed_ms/1000:.1f}s",
                    'suggestion': '检查数据分区数是否过少，或上游 shuffle 分区策略是否合理',
                    'severity': 'LOW'
                })

        # 4. Spilling — 读取 spilling_analysis 的 findings 做归因，不重复报告事实
        # spilling_analysis 负责事实发现（findings），这里负责归因（insight）
        has_spill_finding = any(t in existing_types for t in ('STAGE_SPILLING', 'OPERATOR_SPILLING'))
        # 如果 spilling_analysis 没报但自己算出来有 spill，也纳入归因（1GB 阈值与 spilling_analysis 一致）
        has_spill = has_spill_finding or spill_gb > 1.0

        # 5. 因果链检测 — 归因分析，产出有因果关系的结论
        has_skew = 'DATA_SKEW' in existing_types or any(p['type'] == 'DATA_SKEW' for p in problems)
        has_inefficiency = 'RESOURCE_INEFFICIENCY' in existing_types

        if has_skew and has_spill:
            # 倾斜 → spill 因果链
            spill_desc = f"（Spilling {spill_gb:.2f} GB）" if spill_gb > 0 else ""
            problems.append({
                'type': 'CAUSAL_CHAIN',
                'description': f"数据倾斜导致 Spilling{spill_desc}：少数 task 处理大量数据，内存不足溢出到磁盘",
                'suggestion': '优先解决数据倾斜（根因），Spilling 会随之改善',
                'severity': 'HIGH'
            })
        elif has_spill and not has_skew:
            # 有 spill 但没有倾斜，可能是整体内存不足
            problems.append({
                'type': 'HIGH_SPILLING',
                'description': f"计算算子 Spilling {spill_gb:.2f} GB（无数据倾斜），"
                               f"Stage 耗时 {elapsed_ms/1000:.1f}s",
                'suggestion': '非倾斜导致，可能是整体数据量大或内存配置不足',
                'severity': 'MEDIUM'
            })

        if has_skew and has_inefficiency:
            problems.append({
                'type': 'CAUSAL_CHAIN',
                'description': '数据倾斜导致资源效率低：少数 task 拖慢整个 Stage，大量资源空等',
                'suggestion': '优先解决数据倾斜（根因），资源利用率会随之改善',
                'severity': 'HIGH'
            })

        # 6. GENERAL_SLOW 不再产出 — "没有明显瓶颈"不是洞察，避免给 AI 制造噪音
        # Stage 的基本信息已在 analysis_scope 中，deep 模式 AI 可自行查看

        return problems
