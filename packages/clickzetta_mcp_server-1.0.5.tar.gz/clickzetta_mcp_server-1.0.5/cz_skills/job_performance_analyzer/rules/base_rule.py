#!/usr/bin/env python3
"""
规则基类 - 所有优化规则的抽象基类
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional


class BaseRule(ABC):
    """规则基类"""

    name: str = "base_rule"
    category: str = "unknown"
    description: str = ""
    rule_scope: str = "stage"  # 'stage' 或 'global'

    def __init__(self):
        self.context = {}

    @abstractmethod
    def check(self, stage_data: Dict, context: Dict) -> bool:
        """检查是否触发该规则"""
        pass

    @abstractmethod
    def analyze(self, stage_data: Dict, context: Dict) -> Dict:
        """分析问题并返回结果"""
        pass

    def get_setting(self, setting: str, context: Dict) -> Optional[str]:
        """获取参数值"""
        return context.get('settings', {}).get(setting)

    def has_setting(self, setting: str, context: Dict) -> bool:
        """检查参数是否已配置"""
        return setting in context.get('settings', {})

    def has_profile_data(self, context: Dict) -> bool:
        """检查是否有有效的 profile 数据"""
        return context.get('has_profile', False)

    def create_recommendation(self, setting: str, value: str, priority: int,
                            reason: str, impact: str = 'MEDIUM',
                            current_value: str = None, warning: str = None) -> Dict:
        """创建参数建议"""
        return {
            'rule': self.name, 'setting': setting, 'value': value,
            'priority': priority, 'reason': reason, 'impact': impact,
            'current_value': current_value, 'warning': warning,
        }

    def create_finding(self, finding_type: str, stage_id: str, severity: str,
                      description: str = "", details: Dict = None,
                      confidence: str = 'high') -> Dict:
        """创建问题发现
        
        Args:
            confidence: 规则引擎对此诊断的置信度
                - 'high'   — 确定性事实（如明确检测到 spilling > 阈值）
                - 'medium' — 有迹象但不完全确定（如倾斜比接近阈值）
                - 'low'    — 只是线索，需要 AI 进一步分析
        """
        return {
            'rule': self.name, 'type': finding_type, 'stage_id': stage_id,
            'severity': severity, 'description': description, 'details': details or {},
            'confidence': confidence,
        }

    def create_insight(self, message: str, stage_id: str = None, level: str = 'detail') -> Dict:
        """创建洞察
        
        Args:
            level: 'important' 始终输出, 'detail' 仅 DEBUG 时输出
        """
        return {'rule': self.name, 'message': message, 'stage_id': stage_id, 'level': level}

    def add_analysis_detail(self, context: Dict, key: str, value: Any, stage_id: str = None):
        """存储分析中间数据，供 detailed/expert 模式下 AI 二次研判使用。
        
        数据存储在 context['analysis_scope'][rule_name] 中。
        quick 模式下这些数据不会包含在输出中。
        
        Args:
            context: 分析上下文
            key: 数据键名
            value: 数据值
            stage_id: 关联的 stage ID（可选，用于按 stage 组织数据）
        """
        if 'analysis_scope' not in context:
            context['analysis_scope'] = {}
        if self.name not in context['analysis_scope']:
            context['analysis_scope'][self.name] = {}
        
        if stage_id:
            if stage_id not in context['analysis_scope'][self.name]:
                context['analysis_scope'][self.name][stage_id] = {}
            context['analysis_scope'][self.name][stage_id][key] = value
        else:
            context['analysis_scope'][self.name][key] = value

    def get_refresh_table_properties(self, context: Dict) -> Dict:
        """从 context 的 aligned_stages 中获取 refresh 目标表（非 partial、非 delta 的 TableSink）的 dynamic table properties。
        
        注意：plan 中 table.properties 是 list[{key, value}] 格式，此方法会转换为 dict。
        
        Returns:
            dict: 目标表的 properties，如 {'cz.sql.enable.dag.auto.adaptive.split.size': 'true', ...}
        """
        aligned_stages = context.get('aligned_stages', {})
        for stage_id, stage_data in aligned_stages.items():
            plan = stage_data.get('plan', {})
            for op in plan.get('operators', []):
                if 'tableSink' in op:
                    table_sink = op['tableSink']
                    flags = table_sink.get('flags', 0)
                    if (flags & 0x20) != 0:
                        continue
                    table = table_sink.get('table', {})
                    path = table.get('path', [])
                    if len(path) == 4 and path[-1] == '__delta__':
                        continue
                    raw_props = table.get('properties', {})
                    # properties 可能是 list[{key, value}] 或 dict
                    if isinstance(raw_props, list):
                        return {item['key']: item.get('value', '') for item in raw_props if 'key' in item}
                    return raw_props if isinstance(raw_props, dict) else {}
        return {}

    def _get_refresh_table_name(self, context: Dict) -> Optional[str]:
        """获取 refresh 目标表的表名（从 tableSink 的 path 中提取）"""
        aligned_stages = context.get('aligned_stages', {})
        for stage_id, stage_data in aligned_stages.items():
            plan = stage_data.get('plan', {})
            for op in plan.get('operators', []):
                if 'tableSink' in op:
                    table_sink = op['tableSink']
                    flags = table_sink.get('flags', 0)
                    if (flags & 0x20) != 0:
                        continue
                    table = table_sink.get('table', {})
                    path = table.get('path', [])
                    if len(path) == 4 and path[-1] == '__delta__':
                        continue
                    if len(path) >= 3:
                        return '.'.join(path[:3])
        return None

    def build_recommendation_with_table_check(self, param: str, value: str, priority: int,
                                               reason: str, impact: str, context: Dict,
                                               current_value: str = None, warning: str = None,
                                               stage_id: str = None) -> Dict:
        """创建参数建议，同时检查目标表 properties 是否有冲突。
        
        如果目标 dynamic table 上也设置了该参数，会在 warning 中追加提示去掉表级属性。
        
        Returns:
            recommendation dict
        """
        table_props = self.get_refresh_table_properties(context)
        if param in table_props:
            table_name = self._get_refresh_table_name(context) or '目标表'
            table_warning = (f"同时注意：dynamic table {table_name} 上已设置该参数为 '{table_props[param]}'，"
                           f"需先通过 ALTER TABLE {table_name} UNSET TBLPROPERTIES ('{param}') 去掉")
            if warning:
                warning = f"{warning}；{table_warning}"
            else:
                warning = table_warning
        
        return self.create_recommendation(param, value, priority, reason, impact, current_value, warning)


class GlobalRule(BaseRule):
    """全局规则基类 - 不针对单个 Stage，而是针对整个 Job"""

    rule_scope: str = "global"

    def check(self, stage_data: Dict, context: Dict) -> bool:
        """全局规则不需要 stage_data，直接返回 True"""
        return True

    @abstractmethod
    def analyze_global(self, context: Dict) -> Dict:
        """全局分析方法"""
        pass

    def analyze(self, stage_data: Dict, context: Dict) -> Dict:
        """兼容接口，调用 analyze_global"""
        return self.analyze_global(context)

