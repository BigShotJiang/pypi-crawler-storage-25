#!/usr/bin/env python3
"""基于 extra_files（dag_summary, stats_summary）的深度分析规则"""
import re
from typing import Dict, List

from ..base_rule import GlobalRule


class CpuEfficiencyAnalysis(GlobalRule):
    """从 stats_summary 分析各 operator 的 CPU 效率（cpu_time / wall_time）"""

    name = "cpu_efficiency_analysis"
    category = "common"
    description = "分析 Operator CPU 效率，识别 I/O 瓶颈"

    # cpu_time / wall_time 低于此值视为 CPU 效率低
    CPU_RATIO_THRESHOLD = 0.3
    # 只分析 wall_time_sum 超过此值的 operator（ms）
    MIN_WALL_TIME_SUM_MS = 1000

    def analyze_global(self, context: Dict) -> Dict:
        stats_summary = context.get('extra_files', {}).get('stats_summary')
        if not stats_summary:
            return {'findings': [], 'recommendations': [], 'insights': []}

        findings = []
        insights = []
        low_efficiency_ops = []

        for stage_key, operators in stats_summary.items():
            stage_id = stage_key.split()[0] if ' ' in stage_key else stage_key

            # --- Operator 级别: CPU 效率 ---
            for op_name, stats in operators.items():
                if op_name == 'pipeline_stats':
                    continue
                wall_str = stats.get('wall_time[min/max/avg/sum](ms)', '')
                cpu_str = stats.get('cpu_time[min/max/avg/sum](ms)', '')
                if not wall_str or not cpu_str:
                    continue

                wall_sum = self._parse_sum(wall_str)
                cpu_sum = self._parse_sum(cpu_str)
                if wall_sum < self.MIN_WALL_TIME_SUM_MS:
                    continue

                ratio = cpu_sum / wall_sum if wall_sum > 0 else 1.0
                if ratio < self.CPU_RATIO_THRESHOLD:
                    low_efficiency_ops.append({
                        'stage_id': stage_id,
                        'operator': op_name,
                        'cpu_ratio': ratio,
                        'wall_sum_ms': wall_sum,
                        'cpu_sum_ms': cpu_sum,
                        'block_timing': stats.get('block_timing[min/max/avg/sum](ms)', ''),
                    })

        if not low_efficiency_ops:
            return {'findings': findings, 'recommendations': [], 'insights': insights}

        # 按 wall_time 降序，取 top
        low_efficiency_ops.sort(key=lambda x: x['wall_sum_ms'], reverse=True)
        top_ops = low_efficiency_ops[:10]

        lines = ["CPU 效率分析（cpu_time/wall_time 低于 {:.0f}%）:".format(self.CPU_RATIO_THRESHOLD * 100)]
        for op in top_ops:
            wait_ms = op['wall_sum_ms'] - op['cpu_sum_ms']
            lines.append(
                f"  {op['stage_id']}/{op['operator']}: "
                f"CPU 占比 {op['cpu_ratio']:.0%}, "
                f"wall_sum={op['wall_sum_ms']/1000:.1f}s, "
                f"等待时间≈{wait_ms/1000:.1f}s"
                f"{' (有 block_timing)' if op['block_timing'] else ''}"
            )

        insights.append(self.create_insight('\n'.join(lines), level='important'))

        # 对最严重的生成 finding
        worst = top_ops[0]
        findings.append(self.create_finding(
            'LOW_CPU_EFFICIENCY',
            worst['stage_id'],
            'MEDIUM',
            f"{worst['stage_id']}/{worst['operator']} CPU 效率仅 {worst['cpu_ratio']:.0%}，"
            f"wall_time 总计 {worst['wall_sum_ms']/1000:.1f}s 中约 "
            f"{(worst['wall_sum_ms'] - worst['cpu_sum_ms'])/1000:.1f}s 在等待 I/O 或调度",
            details={'low_efficiency_operators': top_ops},
        ))

        return {'findings': findings, 'recommendations': [], 'insights': insights}

    @staticmethod
    def _parse_sum(value_str: str) -> float:
        """从 'min/max/avg/sum' 或 '[min/max/avg/sum]' 格式字符串中提取 sum 值"""
        s = value_str.strip('[] ')
        parts = s.split('/')
        if len(parts) >= 4:
            try:
                return float(parts[3])
            except ValueError:
                pass
        return 0.0


class ResourceWaitAnalysis(GlobalRule):
    """从 dag_summary 分析 task 级别的资源等待时间"""

    name = "resource_wait_analysis"
    category = "common"
    description = "分析 Task 资源等待时间，识别调度瓶颈"

    # 资源等待时间超过此值才报告（ms）
    MIN_WAIT_TIME_MS = 1000

    def analyze_global(self, context: Dict) -> Dict:
        dag_summary = context.get('extra_files', {}).get('dag_summary')
        if not dag_summary:
            return {'findings': [], 'recommendations': [], 'insights': []}

        stage_progress = dag_summary.get('stageProgress', {})
        if not stage_progress:
            return {'findings': [], 'recommendations': [], 'insights': []}

        findings = []
        insights = []
        stage_wait_stats = []

        for stage_id, stage_info in stage_progress.items():
            task_progress = stage_info.get('taskProgress', {})
            if not task_progress:
                continue

            wait_times = []
            exec_times = []
            for _tid, tinfo in task_progress.items():
                for att in tinfo.get('attempts', []):
                    wr = att.get('timeOnWaitResource', {})
                    ws, we = wr.get('startTime'), wr.get('endTime')
                    if ws and we:
                        wait_times.append(int(we) - int(ws))

                    te = att.get('timeOnExecutor', {})
                    es, ee = te.get('startTime'), te.get('endTime')
                    if es and ee:
                        exec_times.append(int(ee) - int(es))

            if not wait_times:
                continue

            max_wait = max(wait_times)
            avg_wait = sum(wait_times) / len(wait_times)
            max_exec = max(exec_times) if exec_times else 0
            avg_exec = sum(exec_times) / len(exec_times) if exec_times else 0

            if max_wait >= self.MIN_WAIT_TIME_MS:
                stage_wait_stats.append({
                    'stage_id': stage_id,
                    'task_count': len(task_progress),
                    'wait_max_ms': max_wait,
                    'wait_avg_ms': avg_wait,
                    'exec_max_ms': max_exec,
                    'exec_avg_ms': avg_exec,
                    'wait_ratio': avg_wait / (avg_wait + avg_exec) if (avg_wait + avg_exec) > 0 else 0,
                })

        if not stage_wait_stats:
            return {'findings': [], 'recommendations': [], 'insights': []}

        stage_wait_stats.sort(key=lambda x: x['wait_max_ms'], reverse=True)

        lines = ["Task 资源等待时间分析:"]
        for s in stage_wait_stats:
            lines.append(
                f"  {s['stage_id']} ({s['task_count']} tasks): "
                f"等待 max={s['wait_max_ms']/1000:.1f}s avg={s['wait_avg_ms']/1000:.1f}s, "
                f"执行 max={s['exec_max_ms']/1000:.1f}s avg={s['exec_avg_ms']/1000:.1f}s, "
                f"等待占比={s['wait_ratio']:.0%}"
            )
        insights.append(self.create_insight('\n'.join(lines), level='important'))

        worst = stage_wait_stats[0]
        if worst['wait_ratio'] > 0.3:
            severity = 'HIGH' if worst['wait_ratio'] > 0.5 else 'MEDIUM'
            findings.append(self.create_finding(
                'HIGH_RESOURCE_WAIT',
                worst['stage_id'],
                severity,
                f"{worst['stage_id']} 资源等待占比 {worst['wait_ratio']:.0%}，"
                f"最大等待 {worst['wait_max_ms']/1000:.1f}s，"
                f"可能存在资源不足或调度延迟",
                details={'stage_wait_stats': stage_wait_stats},
            ))

        return {'findings': findings, 'recommendations': [], 'insights': insights}
