#!/usr/bin/env python3
"""
优化器错误检测规则

基于 ErrorMessageCollector 收集的错误信息，检测优化器错误并给出诊断建议。
"""
from typing import Dict, Any
from ..base_rule import BaseRule


class OptimizerErrorDetection(BaseRule):
    """检测优化器错误"""
    
    name = "optimizer_error_detection"
    description = "检测优化器内部错误"
    category = "error_analysis"
    
    def check(self, stage_data: Dict, context: Dict) -> bool:
        """
        检查是否需要执行此规则
        
        此规则是全局规则，在 stage 级别总是返回 False
        """
        return False
    
    def analyze_global(self, context: Dict) -> Dict:
        """
        全局分析：基于收集的错误信息检测优化器错误
        
        Args:
            context: 包含 error_messages 的上下文
            
        Returns:
            分析结果字典
        """
        findings = []
        recommendations = []
        insights = []
        
        # 检查是否有 profile 数据
        has_profile = context.get('has_profile', False)
        if not has_profile:
            return {
                'findings': findings,
                'recommendations': recommendations,
                'insights': insights
            }
        
        # 从 context 中获取收集的错误信息
        error_messages = context.get('error_messages', [])
        
        if not error_messages:
            return {
                'findings': findings,
                'recommendations': recommendations,
                'insights': insights
            }
        
        # 查找优化器错误
        optimizer_errors = []
        for error in error_messages:
            message = error.get('message', '')
            if 'optimizer internal error' in message.lower():
                optimizer_errors.append(error)
        
        if optimizer_errors:
            # 构建详细的错误信息
            error_details = []
            for error in optimizer_errors:
                location = error.get('location', 'unknown')
                if location == 'job_status':
                    error_details.append(f"Job Status: {error.get('refined_message', error.get('message'))}")
                elif location == 'stage':
                    error_details.append(
                        f"Stage {error.get('stage_id')}: {error.get('refined_message', error.get('message'))}"
                    )
                elif location == 'task':
                    error_details.append(
                        f"Stage {error.get('stage_id')}, Task {error.get('task_id')}: "
                        f"{error.get('refined_message', error.get('message'))}"
                    )
            
            findings.append({
                'type': 'optimizer_internal_error',
                'severity': 'high',
                'title': '优化器内部错误',
                'description': (
                    f'检测到优化器内部错误。这通常是优化器在处理查询时遇到了异常情况。\n'
                    f'错误详情:\n' + '\n'.join(f'  - {detail}' for detail in error_details)
                ),
                'evidence': {
                    'error_count': len(optimizer_errors),
                    'error_details': optimizer_errors
                }
            })
            
            # 检查是否已经设置了 playback flag
            settings = context.get('settings', {})
            playback_enabled = settings.get('cz.sql.playback.scratch', '').lower() == 'true'
            
            if not playback_enabled:
                # 如果没有设置 playback，建议设置参数并重跑 Job
                recommendations.append({
                    'type': 'rerun_job',
                    'priority': 'high',
                    'title': '设置参数后重新运行 Job',
                    'description': (
                        '优化器内部错误导致 Job 失败。'
                        '需要设置 set cz.sql.playback.scratch=true 后重新运行此 Job，'
                        '以生成 playback 信息用于问题诊断。'
                    ),
                    'reason': (
                        '优化器内部错误需要 playback 信息来定位问题根因。'
                        '设置参数后重跑 Job 可以生成诊断数据。'
                    ),
                    'action': '1. 设置 set cz.sql.playback.scratch=true\n   2. 重新提交并运行此 Job\n   3. 收集生成的 playback 信息'
                })
                
                insights.append({
                    'category': 'error_analysis',
                    'message': (
                        f'检测到 {len(optimizer_errors)} 处优化器内部错误。'
                        '建议启用 playback 功能并重新运行 Job 以收集诊断信息。'
                    )
                })
            else:
                # 已经设置了 playback，提示联系技术支持
                recommendations.append({
                    'type': 'contact_support',
                    'priority': 'high',
                    'title': '联系技术支持',
                    'description': (
                        '检测到优化器内部错误。playback 功能已启用，'
                        '已有足够的诊断信息，建议联系技术支持进行问题定位。'
                    ),
                    'reason': (
                        '优化器内部错误通常需要技术团队介入分析。'
                        'playback 参数已正确配置，系统已生成诊断信息。'
                    ),
                    'action': '收集 playback 信息并联系技术支持团队进行问题诊断'
                })
                
                insights.append({
                    'category': 'error_analysis',
                    'message': (
                        f'检测到 {len(optimizer_errors)} 处优化器内部错误。'
                        'playback 功能已启用，请收集 playback 信息并联系技术支持。'
                    )
                })
        
        return {
            'findings': findings,
            'recommendations': recommendations,
            'insights': insights
        }
    
    def analyze(self, stage_data: Dict, context: Dict) -> Dict:
        """
        Stage 级别分析（此规则不在 stage 级别执行）
        """
        return {
            'findings': [],
            'recommendations': [],
            'insights': []
        }
