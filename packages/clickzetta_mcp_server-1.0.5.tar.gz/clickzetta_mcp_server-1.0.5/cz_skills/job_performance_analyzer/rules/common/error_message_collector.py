#!/usr/bin/env python3
"""
错误信息收集器

统一从 job_profile.json 的所有 message 字段收集错误信息，
去重并精炼，为后续错误分析提供基础。
"""
from typing import Dict, Any, List, Set
from ..base_rule import BaseRule


class ErrorMessageCollector(BaseRule):
    """收集并精炼 Job 中的所有错误信息"""
    
    name = "error_message_collector"
    description = "收集 job_profile.json 中的所有错误信息"
    category = "error_analysis"
    
    def check(self, stage_data: Dict, context: Dict) -> bool:
        """
        检查是否需要执行此规则
        
        此规则是全局规则，在 stage 级别总是返回 False
        """
        return False
    
    def analyze_global(self, context: Dict) -> Dict:
        """
        全局分析：收集所有错误信息
        
        Args:
            context: 包含 job_profile 数据的上下文
            
        Returns:
            分析结果字典
        """
        findings = []
        recommendations = []
        insights = []
        
        # 检查是否有 profile 数据
        has_profile = context.get('has_profile', False)
        if not has_profile:
            return {
                'findings': findings,
                'recommendations': recommendations,
                'insights': insights,
                'error_messages': []  # 空的错误信息列表
            }
        
        # 收集所有错误信息
        error_messages = []
        error_locations = []
        
        # 1. 检查 Job 级别的错误信息
        raw_profile = context.get('raw_profile', {})
        if raw_profile:
            job_status = raw_profile.get('jobStatus', {})
            job_message = job_status.get('message', '')
            if job_message and self._is_error_message(job_message):
                # 尝试解析 JSON 格式的错误消息
                parsed_errors = self._parse_json_errors(job_message)
                if parsed_errors:
                    # JSON 格式的错误
                    for err in parsed_errors:
                        error_messages.append({
                            'location': 'job_status',
                            'message': err,
                            'raw_message': job_message
                        })
                        error_locations.append('Job Status')
                else:
                    # 普通字符串错误
                    error_messages.append({
                        'location': 'job_status',
                        'message': job_message,
                        'raw_message': job_message
                    })
                    error_locations.append('Job Status')
        
        # 2. 检查 Stage 级别的错误信息
        aligned_stages = context.get('aligned_stages', {})
        for stage_id, stage_data in aligned_stages.items():
            profile_data = stage_data.get('profile', {})
            
            # Stage 级别的 message
            stage_message = profile_data.get('message', '')
            if stage_message and self._is_error_message(stage_message):
                error_messages.append({
                    'location': 'stage',
                    'stage_id': stage_id,
                    'message': stage_message,
                    'raw_message': stage_message
                })
                error_locations.append(f'Stage {stage_id}')
            
            # 3. 检查 Task 级别的错误信息
            task_summary = profile_data.get('taskSummary', {})
            for task_id, task_data in task_summary.items():
                task_message = task_data.get('message', '')
                if task_message and self._is_error_message(task_message):
                    error_messages.append({
                        'location': 'task',
                        'stage_id': stage_id,
                        'task_id': task_id,
                        'message': task_message,
                        'raw_message': task_message
                    })
                    error_locations.append(f'Stage {stage_id}, Task {task_id}')
        
        # 去重和精炼错误信息
        refined_errors = self._refine_error_messages(error_messages)
        
        # 将精炼后的错误信息存储到 context 中，供其他规则使用
        context['error_messages'] = refined_errors
        context['raw_error_messages'] = error_messages
        
        # 如果有错误信息，生成洞察
        if refined_errors:
            unique_error_types = self._categorize_errors(refined_errors)
            
            insights.append({
                'category': 'error_analysis',
                'message': (
                    f'收集到 {len(error_messages)} 条错误信息（去重后 {len(refined_errors)} 条），'
                    f'涉及 {len(set(error_locations))} 个位置。'
                    f'错误类型: {", ".join(unique_error_types)}'
                )
            })
        
        return {
            'findings': findings,
            'recommendations': recommendations,
            'insights': insights,
            'error_messages': refined_errors  # 传递给其他规则
        }
    
    def _is_error_message(self, message: str) -> bool:
        """
        判断是否是错误信息
        
        Args:
            message: 消息内容
            
        Returns:
            是否是错误信息
        """
        if not message:
            return False
        
        # 尝试解析 JSON 格式的 message
        try:
            import json
            msg_obj = json.loads(message)
            # 如果是 JSON 对象且包含 errors 字段
            if isinstance(msg_obj, dict) and 'errors' in msg_obj:
                return len(msg_obj.get('errors', [])) > 0
        except (json.JSONDecodeError, ValueError):
            # 不是 JSON，继续按字符串处理
            pass
        
        # 常见的错误关键字
        error_keywords = [
            'error', 'exception', 'failed', 'failure', 'conflict',
            'timeout', 'abort', 'cancel', 'invalid', 'illegal',
            'denied', 'forbidden', 'unauthorized', 'not found',
            'out of memory', 'oom', 'overflow', 'underflow'
        ]
        
        message_lower = message.lower()
        return any(keyword in message_lower for keyword in error_keywords)
    
    def _parse_json_errors(self, message: str) -> List[str]:
        """
        解析 JSON 格式的错误消息
        
        Args:
            message: 可能是 JSON 格式的消息
            
        Returns:
            错误消息列表，如果不是 JSON 格式返回空列表
        """
        try:
            import json
            msg_obj = json.loads(message)
            if isinstance(msg_obj, dict) and 'errors' in msg_obj:
                errors = msg_obj.get('errors', [])
                result = []
                for err in errors:
                    if isinstance(err, dict):
                        # 构建错误消息
                        category = err.get('category', '')
                        error_code = err.get('errorCode', '')
                        error_msg = err.get('message', '')
                        line = err.get('line', '')
                        col = err.get('col', '')
                        
                        parts = []
                        if category:
                            parts.append(f"[{category}]")
                        if error_code:
                            parts.append(f"({error_code})")
                        if line and col:
                            parts.append(f"Line {line}, Col {col}:")
                        if error_msg:
                            parts.append(error_msg)
                        
                        result.append(' '.join(parts))
                return result
        except (json.JSONDecodeError, ValueError, TypeError):
            pass
        
        return []
    
    def _refine_error_messages(self, error_messages: List[Dict]) -> List[Dict]:
        """
        去重和精炼错误信息
        
        Args:
            error_messages: 原始错误信息列表
            
        Returns:
            精炼后的错误信息列表
        """
        if not error_messages:
            return []
        
        # 使用 message 内容作为去重的 key
        seen_messages: Set[str] = set()
        refined = []
        
        for error in error_messages:
            message = error['message']
            
            # 简单去重：如果消息内容完全相同，只保留第一个
            if message in seen_messages:
                continue
            
            seen_messages.add(message)
            
            # 精炼消息：截断过长的消息
            refined_message = self._truncate_message(message)
            
            refined.append({
                **error,
                'refined_message': refined_message
            })
        
        return refined
    
    def _truncate_message(self, message: str, max_length: int = 500) -> str:
        """
        截断过长的错误消息
        
        Args:
            message: 原始消息
            max_length: 最大长度
            
        Returns:
            截断后的消息
        """
        if len(message) <= max_length:
            return message
        
        return message[:max_length] + '. . .'
    
    def _categorize_errors(self, error_messages: List[Dict]) -> List[str]:
        """
        对错误信息进行分类
        
        Args:
            error_messages: 错误信息列表
            
        Returns:
            错误类型列表
        """
        error_types = set()
        
        for error in error_messages:
            message = error['message'].lower()
            
            if 'conflict' in message:
                error_types.add('冲突错误')
            elif 'timeout' in message:
                error_types.add('超时错误')
            elif 'out of memory' in message or 'oom' in message:
                error_types.add('内存错误')
            elif 'not found' in message:
                error_types.add('资源未找到')
            elif 'denied' in message or 'forbidden' in message or 'unauthorized' in message:
                error_types.add('权限错误')
            elif 'invalid' in message or 'illegal' in message:
                error_types.add('参数错误')
            else:
                error_types.add('其他错误')
        
        return sorted(list(error_types))
    
    def analyze(self, stage_data: Dict, context: Dict) -> Dict:
        """
        Stage 级别分析（此规则不在 stage 级别执行）
        """
        return {
            'findings': [],
            'recommendations': [],
            'insights': []
        }
