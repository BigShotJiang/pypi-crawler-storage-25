#!/usr/bin/env python3
"""
Job 冲突报错检测规则

基于 ErrorMessageCollector 收集的错误信息，检测提交冲突错误并给出重跑建议。
"""
from typing import Dict, Any
from ..base_rule import BaseRule


class JobConflictDetection(BaseRule):
    """检测 Job 提交冲突错误"""
    
    name = "job_conflict_detection"
    description = "检测 Job 提交冲突报错"
    category = "error_analysis"
    
    def check(self, stage_data: Dict, context: Dict) -> bool:
        """
        检查是否需要执行此规则
        
        此规则是全局规则，在 stage 级别总是返回 False
        """
        return False
    
    def analyze_global(self, context: Dict) -> Dict:
        """
        全局分析：基于收集的错误信息检测冲突错误
        
        Args:
            context: 包含 error_messages 的上下文
            
        Returns:
            分析结果字典
        """
        findings = []
        recommendations = []
        insights = []
        
        # 检查是否有 profile 数据
        has_profile = context.get('has_profile', False)
        if not has_profile:
            return {
                'findings': findings,
                'recommendations': recommendations,
                'insights': insights
            }
        
        # 从 context 中获取收集的错误信息
        error_messages = context.get('error_messages', [])
        
        if not error_messages:
            return {
                'findings': findings,
                'recommendations': recommendations,
                'insights': insights
            }
        
        # 查找冲突错误
        conflict_errors = []
        conflict_job_ids = set()  # 收集冲突的 Job ID
        
        for error in error_messages:
            message = error.get('message', '')
            if 'conflicts with another concurrent job which updates' in message.lower():
                conflict_errors.append(error)
                
                # 尝试从错误信息中提取冲突的 Job ID
                # 错误信息格式可能是：
                # "this job has conflicts with another concurrent job '20260209143826642_b_411f96fc' which updates..."
                import re
                # 匹配 Job ID 模式：日期时间戳_b_哈希 或 普通的 Job ID
                # 匹配单引号或双引号包围的 Job ID，或者 "job" 关键字后的 Job ID
                job_id_pattern = r"(?:job\s+['\"]|concurrent\s+job\s+['\"])([0-9]{17,20}_[a-z]_[a-f0-9]+|[0-9]{17,30}[a-z0-9]+)['\"]"
                matches = re.findall(job_id_pattern, message, re.IGNORECASE)
                for match in matches:
                    conflict_job_ids.add(match)
        
        if conflict_errors:
            # 分析冲突 Job 类型
            compaction_jobs = []
            regular_jobs = []
            
            for job_id in conflict_job_ids:
                # 检查是否是 compaction job（格式：日期时间戳_b_哈希）
                if '_b_' in job_id:
                    compaction_jobs.append(job_id)
                else:
                    regular_jobs.append(job_id)
            
            # 构建详细的错误信息
            error_details = []
            for error in conflict_errors:
                location = error.get('location', 'unknown')
                if location == 'job_status':
                    error_details.append(f"Job Status: {error.get('refined_message', error.get('message'))}")
                elif location == 'stage':
                    error_details.append(
                        f"Stage {error.get('stage_id')}: {error.get('refined_message', error.get('message'))}"
                    )
                elif location == 'task':
                    error_details.append(
                        f"Stage {error.get('stage_id')}, Task {error.get('task_id')}: "
                        f"{error.get('refined_message', error.get('message'))}"
                    )
            
            # 构建冲突 Job 信息
            conflict_info = []
            if compaction_jobs:
                conflict_info.append(f"检测到与 Compaction Job 冲突: {', '.join(compaction_jobs)}")
            if regular_jobs:
                conflict_info.append(f"检测到与普通 Job 冲突: {', '.join(regular_jobs)}")
            if not conflict_job_ids:
                conflict_info.append("未能从错误信息中提取冲突 Job ID")
            
            findings.append({
                'type': 'job_conflict_error',
                'severity': 'high',
                'title': 'Job 提交冲突错误',
                'description': (
                    f'检测到 Job 提交冲突错误。此 Job 与另一个并发 Job 发生了更新冲突。\n'
                    f'冲突详情:\n' + '\n'.join(f'  - {detail}' for detail in error_details) +
                    '\n\n冲突 Job 信息:\n' + '\n'.join(f'  - {info}' for info in conflict_info)
                ),
                'evidence': {
                    'conflict_count': len(conflict_errors),
                    'conflict_details': conflict_errors,
                    'conflict_job_ids': list(conflict_job_ids),
                    'compaction_jobs': compaction_jobs,
                    'regular_jobs': regular_jobs
                }
            })
            
            # 根据冲突类型给出不同的建议
            if compaction_jobs and regular_jobs:
                # 混合冲突：既有 Compaction 又有普通 Job
                recommendations.append({
                    'type': 'rerun_job',
                    'priority': 'high',
                    'title': '重新运行 Job（混合冲突）',
                    'description': (
                        f'检测到与多个 Job 冲突:\n'
                        f'  - Compaction Job: {", ".join(compaction_jobs)}\n'
                        f'  - 普通 Job: {", ".join(regular_jobs)}\n\n'
                        '建议操作：\n'
                        '1. 重新运行此 Job\n'
                        '2. 针对 Compaction 冲突：\n'
                        '   - 检查 Compaction 策略配置，考虑调整触发时机\n'
                        '   - 调整 Compaction 的调度时间，避开业务高峰期\n'
                        '3. 针对普通 Job 冲突：\n'
                        '   - 检查调度配置，确保配置了正确的依赖关系\n'
                        '   - 如果多个 Job 更新同一张表，需要配置自依赖关系\n'
                        '   - 避免多个 Job 并发写入同一张表'
                    ),
                    'action': '重新提交并运行此 Job，同时检查 Compaction 策略和调度依赖配置'
                })
            elif compaction_jobs:
                # 仅 Compaction 冲突
                recommendations.append({
                    'type': 'rerun_job',
                    'priority': 'high',
                    'title': '重新运行 Job（与 Compaction 冲突）',
                    'description': (
                        f'检测到与 Compaction Job 冲突: {", ".join(compaction_jobs)}\n\n'
                        '建议操作：\n'
                        '1. 重新运行此 Job（Compaction 已完成，重跑可以解决冲突）\n'
                        '2. 检查 Compaction 策略配置，考虑调整 Compaction 触发时机\n'
                        '3. 如果频繁与 Compaction 冲突，可以考虑：\n'
                        '   - 调整 Compaction 的调度时间，避开业务高峰期\n'
                        '   - 增加 Compaction 的触发阈值，减少 Compaction 频率\n'
                        '   - 使用表级别的 Compaction 策略，避免全局冲突'
                    ),
                    'action': '重新提交并运行此 Job，同时检查 Compaction 策略配置'
                })
            elif regular_jobs:
                # 仅普通 Job 冲突
                recommendations.append({
                    'type': 'rerun_job',
                    'priority': 'high',
                    'title': '重新运行 Job（与普通 Job 冲突）',
                    'description': (
                        f'检测到与普通 Job 冲突: {", ".join(regular_jobs)}\n\n'
                        '建议操作：\n'
                        '1. 重新运行此 Job\n'
                        '2. 检查调度配置，确认是否配置了正确的依赖关系：\n'
                        '   - 如果多个 Job 更新同一张表，需要配置自依赖关系\n'
                        '   - 确保上游 Job 完成后才触发下游 Job\n'
                        '   - 避免多个 Job 并发写入同一张表\n'
                        '3. 如果是手动触发的 Job，确认没有其他 Job 正在运行'
                    ),
                    'action': '重新提交并运行此 Job，同时检查调度依赖配置'
                })
            else:
                # 无法提取 Job ID
                recommendations.append({
                    'type': 'rerun_job',
                    'priority': 'high',
                    'title': '重新运行整个 Job',
                    'description': (
                        '由于检测到提交冲突错误，建议重新运行整个 Job。\n\n'
                        '提交冲突通常是由于多个 Job 同时更新同一张表导致的，重跑可以解决此问题。\n\n'
                        '如果频繁出现冲突，建议：\n'
                        '1. 检查调度配置，确保配置了正确的依赖关系\n'
                        '2. 避免多个 Job 并发写入同一张表\n'
                        '3. 如果是与 Compaction 冲突，考虑调整 Compaction 策略'
                    ),
                    'action': '重新提交并运行此 Job'
                })
            
            # 构建 insights
            insight_msg = f'检测到 {len(conflict_errors)} 处提交冲突错误。'
            if compaction_jobs:
                insight_msg += f' 与 Compaction Job 冲突（{len(compaction_jobs)} 个）。'
            if regular_jobs:
                insight_msg += f' 与普通 Job 冲突（{len(regular_jobs)} 个）。'
            insight_msg += ' 这通常发生在多个 Job 并发更新同一张表时。'
            
            insights.append({
                'category': 'error_analysis',
                'message': insight_msg
            })
        
        return {
            'findings': findings,
            'recommendations': recommendations,
            'insights': insights
        }
    
    def analyze(self, stage_data: Dict, context: Dict) -> Dict:
        """
        Stage 级别分析（此规则不在 stage 级别执行）
        """
        return {
            'findings': [],
            'recommendations': [],
            'insights': []
        }
