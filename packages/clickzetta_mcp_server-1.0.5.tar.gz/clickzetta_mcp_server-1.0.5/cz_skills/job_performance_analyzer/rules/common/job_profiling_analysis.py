#!/usr/bin/env python3
"""Job Profiling 分析 - 分析 Job 各阶段耗时和瓶颈"""

try:
    from loguru import logger
except ImportError:
    import logging
    logger = logging.getLogger(__name__)

from ..base_rule import GlobalRule


class JobProfilingAnalysis(GlobalRule):
    """分析 Job 生命周期各阶段的耗时，识别非计算阶段的瓶颈"""
    
    name = "job_profiling_analysis"
    category = "性能分析"
    description = "Job 生命周期分析"
    
    def analyze_global(self, context: dict) -> dict:
        """分析 Job Profiling 数据"""
        parser = context.get('parser')
        if not parser:
            return {'triggered': False, 'findings': [], 'recommendations': [], 'insights': []}
        
        # 获取 profiling 分析结果
        profiling = parser.get_job_profiling_analysis()
        if not profiling or not profiling.get('phases'):
            return {'triggered': False, 'findings': [], 'recommendations': [], 'insights': []}
        
        findings = []
        recommendations = []
        insights = []
        
        total_time_sec = profiling.get('total_time_sec', 0)
        phases = profiling.get('phases', [])
        bottleneck = profiling.get('bottleneck')
        
        # 生成阶段耗时洞察（作为 insights）
        insights.append(f"Job 生命周期总耗时: {total_time_sec:.1f}s")
        
        # 按耗时排序显示各阶段
        sorted_phases = sorted(phases, key=lambda x: x['duration_ms'], reverse=True)
        for phase in sorted_phases:
            name = phase['name']
            duration_sec = phase['duration_sec']
            percentage = phase['percentage']
            
            if duration_sec < 1:
                time_str = f"{phase['duration_ms']:.0f}ms"
            else:
                time_str = f"{duration_sec:.2f}s"
            
            insights.append(f"  {name}: {time_str} ({percentage:.1f}%)")
        
        # 分析瓶颈阶段
        if bottleneck:
            bottleneck_analysis = self._analyze_bottleneck(bottleneck, total_time_sec)
            insights.append(bottleneck_analysis['insight'])
            if bottleneck_analysis.get('recommendation'):
                recommendations.append(bottleneck_analysis['recommendation'])
        
        # 检查各阶段是否异常
        phase_checks = self._check_phase_anomalies(phases, total_time_sec)
        insights.extend(phase_checks['insights'])
        recommendations.extend(phase_checks['recommendations'])
        
        return {
            'triggered': len(insights) > 0,
            'findings': findings,
            'recommendations': recommendations,
            'insights': insights,
            'metadata': {
                'total_time_sec': total_time_sec,
                'phases': phases,
                'bottleneck': bottleneck
            }
        }
    
    def _generate_phase_report(self, phases: list, total_time_sec: float) -> str:
        """生成阶段耗时报告（已废弃，改用 insights）"""
        report_lines = [f"### Job 生命周期分析 (总耗时: {total_time_sec:.1f}s)"]
        report_lines.append("")
        
        # 按耗时排序
        sorted_phases = sorted(phases, key=lambda x: x['duration_ms'], reverse=True)
        
        for phase in sorted_phases:
            name = phase['name']
            duration_sec = phase['duration_sec']
            percentage = phase['percentage']
            
            # 格式化输出
            if duration_sec < 1:
                time_str = f"{phase['duration_ms']:.0f}ms"
            else:
                time_str = f"{duration_sec:.2f}s"
            
            report_lines.append(f"- **{name}**: {time_str} ({percentage:.1f}%)")
        
        return "\n".join(report_lines)
    
    def _analyze_bottleneck(self, bottleneck: dict, total_time_sec: float) -> dict:
        """分析瓶颈阶段"""
        name = bottleneck['name']
        duration_sec = bottleneck['duration_sec']
        percentage = bottleneck['percentage']
        
        insight = f"⚠️ 瓶颈阶段: {name} 耗时 {duration_sec:.1f}s，占总时间 {percentage:.1f}%"
        
        recommendation = None
        
        # 根据不同阶段生成建议
        if name == '执行计划生成':
            if duration_sec > 1:
                recommendation = {
                    'type': 'optimization',
                    'priority': 2,
                    'title': '优化 SQL 复杂度',
                    'description': f'执行计划生成耗时 {duration_sec:.1f}s，SQL 可能过于复杂',
                    'action': '考虑简化查询逻辑、减少 JOIN 层数或拆分为多个步骤'
                }
        
        elif name == '资源申请':
            if duration_sec > 5:
                recommendation = {
                    'type': 'resource',
                    'priority': 1,
                    'title': '检查 VC 资源配置',
                    'description': f'资源申请耗时 {duration_sec:.1f}s，可能存在资源不足或队列拥堵',
                    'action': '检查 VC 配额、并发任务数，或考虑使用更高优先级的队列'
                }
        
        elif name == '数据提交':
            if duration_sec > 10:
                recommendation = {
                    'type': 'optimization',
                    'priority': 2,
                    'title': '优化数据提交',
                    'description': f'数据提交耗时 {duration_sec:.1f}s，可能存在小文件过多',
                    'action': '考虑启用自动合并或调整文件大小配置'
                }
        
        elif name == '持久化':
            if duration_sec > 5:
                recommendation = {
                    'type': 'optimization',
                    'priority': 2,
                    'title': '优化元数据持久化',
                    'description': f'持久化耗时 {duration_sec:.1f}s，元数据操作可能较慢',
                    'action': '检查元数据服务性能或减少分区数量'
                }
        
        return {
            'insight': insight,
            'recommendation': recommendation
        }
    
    def _check_phase_anomalies(self, phases: list, total_time_sec: float) -> dict:
        """检查各阶段是否存在异常"""
        insights = []
        recommendations = []
        
        phase_dict = {p['name']: p for p in phases}
        
        # 检查预检查阶段
        if '预检查' in phase_dict:
            precheck = phase_dict['预检查']
            if precheck['duration_ms'] > 500:
                insights.append(
                    f"⚠️ 预检查阶段耗时 {precheck['duration_ms']:.0f}ms，可能存在权限检查或元数据查询较慢"
                )
        
        # 检查元数据创建
        if '元数据创建' in phase_dict:
            meta = phase_dict['元数据创建']
            if meta['duration_ms'] > 1000:
                insights.append(
                    f"⚠️ 元数据创建耗时 {meta['duration_sec']:.1f}s，可能存在大量分区或复杂表结构"
                )
        
        # 检查 DAG 执行占比
        if 'DAG执行' in phase_dict:
            dag = phase_dict['DAG执行']
            if dag['percentage'] < 80 and total_time_sec > 60:
                # DAG 执行占比过低，说明其他阶段耗时过多
                insights.append(
                    f"💡 DAG 执行仅占 {dag['percentage']:.1f}%，其他阶段耗时较多，建议关注非计算阶段的优化"
                )
        
        return {
            'insights': insights,
            'recommendations': recommendations
        }
