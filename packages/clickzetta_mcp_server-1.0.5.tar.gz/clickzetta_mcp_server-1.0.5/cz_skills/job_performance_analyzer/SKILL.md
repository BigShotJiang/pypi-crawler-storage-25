# Job Performance Analyzer — 代码模块说明

## 概述

`cz_skills/job_performance_analyzer` 是 Clickzetta Job 性能自动诊断工具的核心实现。它接收 `plan.json`（执行计划）和 `job_profile.json`（运行时统计）作为输入，自动识别性能瓶颈并给出参数优化建议。

支持的 SQL 场景：REFRESH（增量计算）、Regular SQL（INSERT/SELECT/MERGE INTO 等）、AP/GP 模式。

> 本文档面向代码开发和维护。MCP skill 的使用说明见 `cz_mcp/skills/job-performance-analyzer/SKILL.md`。

## 数据流

```
plan.json + job_profile.json
        │
        ▼
   PlanProfileParser (core/parser.py)
   - 解析 JSON，提取 SQL 类型、版本、VC 模式、settings
   - plan 和 profile 均为可选，至少提供一个
        │
        ▼
   StageAligner (core/aligner.py)
   - 对齐 plan stages 和 profile stages
   - 计算 Stage 指标（耗时、DOP、IO、spill）
   - 解析 Stage 依赖关系（DAG）
   - 分析 Operator 性能（耗时、倾斜比）
        │
        ▼
   Analyzer (analyzers/)
   - 根据 SQL 类型选择分析器（目前主要是 IncrementalAnalyzer）
   - 遍历 aligned stages，依次执行规则
   - 收集 findings / recommendations / insights
        │
        ▼
   Reporter (core/reporter.py)
   - 去重参数建议
   - 按 Stage 耗时排序 insights
   - 输出 console 报告和 JSON 报告
```

## 模块结构

```
job_performance_analyzer/
├── SKILL.md                    # 本文件
├── analyze_job.py              # 主入口（CLI + API）
├── compare_jobs.py             # Job 对比分析（--compare）
├── references/                 # → symlink 到 cz_mcp/skills/job-performance-analyzer/references/
│
├── core/                       # 核心模块
│   ├── parser.py               # JSON 解析与数据提取
│   ├── aligner.py              # Stage/Operator 对齐与指标计算
│   └── reporter.py             # 报告生成（console + JSON）
│
├── analyzers/                  # 分析器
│   ├── base_analyzer.py        # 基类：管理规则列表、context、reporter
│   └── incremental_analyzer.py # 增量计算分析器（REFRESH + Regular SQL）
│
├── rules/                      # 规则库（每个规则一个文件）
│   ├── base_rule.py            # 规则基类（BaseRule / GlobalRule）
│   ├── incremental/
│   │   ├── stage_optimization/ # Stage/Operator 级别优化（9 条）
│   │   └── state_table/        # 状态表优化（6 条 + 增量算法可视化）
│   ├── common/                 # 通用规则（错误分析等）
│   └── ap_mode/                # AP 模式规则（TODO）
│
├── utils/                      # 工具函数
│   ├── plan_navigator.py       # 执行计划树遍历
│   ├── state_table_checker.py  # 统一的状态表检查
│   ├── append_only_detector.py # Append-Only 表检测
│   ├── incremental_algorithm_analyzer.py # 增量算法分析
│   └── version_utils.py        # 版本比较工具
│
├── docs/                       # 设计文档（架构决策、改造方案）
│   └── analysis_mode_design.md   # 分析模式（quick/standard/deep）设计方案
│
└── tests/                      # 测试用例
```


## 规则体系

### 规则基类

所有规则继承自 `rules/base_rule.py`：

- `BaseRule` — Stage 级别规则，对每个 stage 执行
  - `check(stage_data, context) -> bool` — 判断是否触发
  - `analyze(stage_data, context) -> Dict` — 执行分析，返回 findings/recommendations/insights
- `GlobalRule(BaseRule)` — 全局规则，对整个 Job 执行一次
  - `analyze_global(context) -> Dict` — 全局分析

辅助方法：`create_recommendation()`, `create_finding()`, `create_insight()`, `get_setting()`, `has_setting()`

### Stage/Operator 优化规则（9 条）

| 规则文件 | 类名 | 说明 |
|---------|------|------|
| `refresh_type_detection.py` | RefreshTypeDetection | 判断增量/全量刷新类型 |
| `single_dop_aggregate.py` | SingleDopAggregate | 单并行度聚合优化（三阶段聚合、Bloom Filter） |
| `hash_join_optimization.py` | HashJoinOptimization | Broadcast Hash Join 优化 |
| `tablesink_dop.py` | TableSinkDop | TableSink DOP 自动调整检测 |
| `max_dop_check.py` | MaxDopCheck | 最大 DOP 限制提示 |
| `spilling_analysis.py` | SpillingAnalysis | 内存溢出（Spilling）分析 |
| `skew_detection.py` | SkewDetection | 数据倾斜检测 |
| `resource_efficiency_analysis.py` | ResourceEfficiencyAnalysis | 资源效率分析（实际耗时 vs 理论耗时） |
| `active_problem_finding.py` | ActiveProblemFinding | 主动瓶颈分析 |

### 状态表优化规则（7 条，默认禁用）

| 规则文件 | 类名 | 作用域 | 说明 |
|---------|------|--------|------|
| `non_incremental_diagnosis.py` | NonIncrementalDiagnosis | Global | 全量刷新原因诊断 |
| `state_table_enable.py` | StateTableEnable | Global | 状态表启用建议 |
| `incremental_algorithm_visualization.py` | IncrementalAlgorithmVisualization | Global | 增量算法策略可视化（独立参数控制） |
| `row_number_check.py` | RowNumberCheck | Stage | ROW_NUMBER=1 pattern 检查 |
| `append_only_scan.py` | AppendOnlyScan | Stage | Append-Only 表识别 |
| `aggregate_reuse.py` | AggregateReuse | Stage | 聚合结果复用检查 |
| `heavy_calc_state.py` | HeavyCalcState | Stage | 高耗时 Calc 状态优化 |

### 通用规则（5 条，始终启用）

| 规则文件 | 类名 | 说明 |
|---------|------|------|
| `error_message_collector.py` | ErrorMessageCollector | 收集所有错误信息 |
| `job_conflict_detection.py` | JobConflictDetection | Job 提交冲突检测 |
| `optimizer_error_detection.py` | OptimizerErrorDetection | 优化器错误检测 |
| `extra_file_analysis.py` | CpuEfficiencyAnalysis | Operator CPU 效率分析（需 stats_summary.json） |
| `extra_file_analysis.py` | ResourceWaitAnalysis | Task 资源等待时间分析（需 dag_summary.json） |

## 分析器执行流程

`IncrementalAnalyzer.analyze()` 按以下顺序执行：

1. **Stage/Operator 优化**：遍历所有 aligned stages，对每个 stage 执行 9 条 stage_rules
2. **全局规则**：执行错误分析（所有 SQL 类型）+ 增量全局规则（仅 REFRESH SQL）
3. **状态表优化**（需 `enable_state_table_rules=True`）：遍历 stages 执行 state_table_rules

全量刷新（`refresh_type == 'FULL'`）时，状态表和增量算法规则自动跳过。

## 关键 Context 字段

分析器通过 `context` dict 在规则间共享数据：

| 字段 | 来源 | 说明 |
|------|------|------|
| `sql_info` | parser | SQL 文本、类型（is_refresh）、子类型 |
| `settings` | parser | plan 中的所有参数配置 |
| `vc_mode` / `vc_mode_info` | parser | AP/GP 模式、VC cores |
| `has_profile` | parser | 是否有有效的 profile 数据 |
| `aligned_stages` | aligner | 对齐后的 stage 数据 |
| `total_job_time` | aligner | Job 总耗时（ms） |
| `all_stage_metrics` | aligner | 所有 stage 的指标 |
| `stage_dependencies` | aligner | Stage DAG 依赖关系 |
| `refresh_type` | RefreshTypeDetection | 增量/全量刷新类型 |
| `extra_files` | resolve_job_dir | 额外文件数据（dag_summary, stats_summary） |
| `reporter` | analyzer | Reporter 实例 |

## 如何新增规则

1. 在对应目录创建新文件，继承 `BaseRule` 或 `GlobalRule`
2. 实现 `check()` 和 `analyze()`（或 `analyze_global()`）
3. 在 `incremental_analyzer.py` 中导入并注册到对应的规则列表
4. 添加测试用例到 `tests/`

示例：
```python
# rules/incremental/stage_optimization/new_rule.py
from ...base_rule import BaseRule

class NewRule(BaseRule):
    name = "new_rule"
    category = "incremental/stage_optimization"
    description = "新规则描述"

    def check(self, stage_data, context):
        # 触发条件
        return some_condition

    def analyze(self, stage_data, context):
        findings, recommendations, insights = [], [], []
        # 分析逻辑...
        return {'findings': findings, 'recommendations': recommendations, 'insights': insights}
```

## 运行方式

```bash
# CLI 运行（指定文件）
python -m cz_skills.job_performance_analyzer plan.json job_profile.json

# 支持 .gz 格式的 plan 文件
python -m cz_skills.job_performance_analyzer plan.json.gz job_profile.json

# 启用状态表分析
python -m cz_skills.job_performance_analyzer plan.json job_profile.json --enable-state-table

# 启用增量算法分析
python -m cz_skills.job_performance_analyzer plan.json job_profile.json --enable-incremental-algorithm

# DEBUG 模式
python -m cz_skills.job_performance_analyzer plan.json job_profile.json --log-level DEBUG

# 使用 job 目录（自动发现 plan.json、job_profile.json等)
python -m cz_skills.job_performance_analyzer --job-dir /path/to/job_directory

# 对比两个 job
python -m cz_skills.job_performance_analyzer --compare /path/to/job_a /path/to/job_b


# API 调用
from cz_skills.job_performance_analyzer.analyze_job import analyze_job
result = analyze_job("plan.json", "profile.json", enable_state_table_analysis=True)

# API: Job 对比
from cz_skills.job_performance_analyzer.compare_jobs import compare_jobs
report = compare_jobs("a/job_profile.json", "b/job_profile.json",
                      "a/stats_summary.json", "b/stats_summary.json")
```

## Job 目录结构

使用 `--job-dir` 时，工具会递归扫描目录（上限 1024 个文件），自动发现以下文件：

| 文件 | 用途 | 格式 |
|------|------|------|
| `plan.json` / `plan.json.gz` | 执行计划 | 必选其一 |
| `job_profile.json` | 运行时统计 | 可选 |
| `dag_summary.json` | Task 级别调度数据 | 可选，用于资源等待分析 |
| `stats_summary.json` | Operator/Pipeline 统计 | 可选，用于 CPU 效率分析和 Job 对比 |

## Job 对比功能

`--compare` 对比两个 job 的性能差异，输出三个层级：

1. **Stage** — 按耗时差异排序，过滤差异 < 总差异 5% 的
2. **Operator** — max/avg wall_time 对比，过滤微小差异
3. **Pipeline** — block_timing（I/O）和 queue_timing（调度）的 max/avg 对比

当检测到执行计划不同（stage 数量/并发度/数据量差异大）时，会在报告开头给出警告。

## 运行测试

```bash
python -m pytest cz_skills/job_performance_analyzer/tests/ -v
```

## 参考文档

详细的规范文档在 `references/` 目录（symlink 到 `cz_mcp/skills/job-performance-analyzer/references/`）：

- `core-specification.md` — 核心数据提取规范（输入格式、初始化步骤、参数推荐逻辑）
- `optimization-principles.md` — 参数推荐原则（必须遵守）
- `incremental-optimization.md` — 增量计算优化入口文档
- `stage-operator-optimization.md` — Stage/Operator 级别优化详细规范
- `state-table-optimization.md` — 状态表优化详细规范
- `incremental-algorithm-analysis.md` — 增量算法分析规范
- `data-extraction-paths.md` — JSON 路径参考
- `skill_architecture.md` — 架构设计文档
- `recreate-skill-rule.md` — 重新创建规则的指南
