#!/usr/bin/env python3
"""运行所有测试"""
import unittest
import sys
import os

# 添加项目路径
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

def run_all_tests():
    """运行所有测试"""
    # 发现并运行所有测试
    loader = unittest.TestLoader()
    start_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tests')
    suite = loader.discover(start_dir, pattern='test_*.py')
    
    # 运行测试
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # 返回测试结果
    return result.wasSuccessful()

def run_specific_tests():
    """运行特定的重要测试"""
    print("=" * 80)
    print("运行核心功能测试")
    print("=" * 80)
    
    # 重要测试模块列表
    important_tests = [
        'tests.test_job_conflict_detection',
        'tests.test_optimizer_error_detection',
        'tests.test_empty_plan_handling',
        'tests.test_snapshot_subplan_analysis',
        'tests.test_command_line_integration',
        'tests.test_incremental_algorithm_analyzer',
        'tests.test_target_operator',
    ]
    
    suite = unittest.TestSuite()
    
    for test_module in important_tests:
        try:
            # 导入测试模块
            module = __import__(test_module, fromlist=[''])
            # 添加模块中的所有测试
            module_suite = unittest.defaultTestLoader.loadTestsFromModule(module)
            suite.addTest(module_suite)
            print(f"✅ 已加载测试模块: {test_module}")
        except ImportError as e:
            print(f"❌ 无法加载测试模块 {test_module}: {e}")
    
    # 运行测试
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    return result.wasSuccessful()

if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='运行 Job Performance Analyzer 测试')
    parser.add_argument('--all', action='store_true', help='运行所有测试')
    parser.add_argument('--core', action='store_true', help='运行核心功能测试')
    parser.add_argument('--snapshot', action='store_true', help='只运行 Snapshot Subplan 测试')
    parser.add_argument('--cli', action='store_true', help='只运行命令行集成测试')
    
    args = parser.parse_args()
    
    success = True
    
    if args.snapshot:
        print("=" * 80)
        print("运行 Snapshot Subplan 分析测试")
        print("=" * 80)
        
        from tests.test_snapshot_subplan_analysis import TestSnapshotSubplanAnalysis, TestStateTableEnableRule
        
        suite = unittest.TestSuite()
        suite.addTest(unittest.defaultTestLoader.loadTestsFromTestCase(TestSnapshotSubplanAnalysis))
        suite.addTest(unittest.defaultTestLoader.loadTestsFromTestCase(TestStateTableEnableRule))
        
        runner = unittest.TextTestRunner(verbosity=2)
        result = runner.run(suite)
        success = result.wasSuccessful()
        
    elif args.cli:
        print("=" * 80)
        print("运行命令行集成测试")
        print("=" * 80)
        
        from tests.test_command_line_integration import TestCommandLineIntegration
        
        suite = unittest.TestSuite()
        suite.addTest(unittest.defaultTestLoader.loadTestsFromTestCase(TestCommandLineIntegration))
        
        runner = unittest.TextTestRunner(verbosity=2)
        result = runner.run(suite)
        success = result.wasSuccessful()
        
    elif args.core:
        success = run_specific_tests()
        
    elif args.all:
        success = run_all_tests()
        
    else:
        # 默认运行核心测试
        success = run_specific_tests()
    
    if success:
        print("\n🎉 所有测试通过！")
        sys.exit(0)
    else:
        print("\n❌ 部分测试失败")
        sys.exit(1)