import unittest
import os
import shutil
import subprocess
import sys
from pathlib import Path

class TestMakiniOnMakini(unittest.TestCase):
    def setUp(self):
        self.test_dir = Path("bootstrap_test")
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)
            
    def tearDown(self):
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)

    def test_self_bootstrap(self):
        # 1. Use Headless CLI to Initialize
        print("\n[Makini on Makini] Step 1: Initializing self...")
        cmd_init = [sys.executable, "-m", "makini.cli_runner.makini_cli", "init", "--dir", str(self.test_dir)]
        result = subprocess.run(cmd_init, capture_output=True, text=True)
        if result.returncode != 0:
            print(f"STDOUT: {result.stdout}")
            print(f"STDERR: {result.stderr}")
        self.assertEqual(result.returncode, 0)
        self.assertTrue((self.test_dir / ".makini" / "makini.yaml").exists())

        # 2. Simulate LDS creation (Self-Discovery would happen here)
        print("[Makini on Makini] Step 2: Injecting self-model...")
        lds_content = """
ENTITY: Makini_Project
ATTRIBUTES:
  - id (UUID, PK)
  - name (String)
  - path (String)

ENTITY: Makini_Package
ATTRIBUTES:
  - id (UUID, PK)
  - name (String)
  - description (String)

RELATIONSHIP: Makini_Project (1) [MUST] --- [MAY] (MANY) Makini_Package
"""
        with open(self.test_dir / "schema.lds", "w") as f:
            f.write(lds_content)

        # 3. Use Headless CLI to Build
        print("[Makini on Makini] Step 3: Building models...")
        cmd_build = [sys.executable, "-m", "makini.cli_runner.makini_cli", "build", "--dir", str(self.test_dir)]
        result = subprocess.run(cmd_build, capture_output=True, text=True)
        if result.returncode != 0:
            print(f"STDOUT: {result.stdout}")
            print(f"STDERR: {result.stderr}")
        self.assertEqual(result.returncode, 0)
        self.assertIn("CREATE TABLE IF NOT EXISTS makini_projects", result.stdout)
        self.assertIn("CREATE TABLE IF NOT EXISTS makini_packages", result.stdout)

if __name__ == "__main__":
    unittest.main()
