import os
import shutil
from pathlib import Path
from typing import List, Dict, Any
from ..sensing.partner_sensor import PartnerCSVSensor, PartnerJSONSensor
from ..lds_compiler.discoverer import DomainDiscoverer
from ..broker import MakiniBroker

class PartnerMesh:
    """
    Macro-orchestrator for Phase 3: Macro Deployment.
    Automates the ingestion, discovery, and alignment of multiple partner datasets.
    """
    def __init__(self, target_dir: str):
        self.target_dir = Path(target_dir).expanduser().resolve()
        self.broker = MakiniBroker(str(self.target_dir))
        self.csv_sensor = PartnerCSVSensor(str(self.target_dir))
        self.json_sensor = PartnerJSONSensor(str(self.target_dir))

    def mesh_directory(self, partner_data_dir: str, auto_align_threshold: float = 0.8) -> Dict[str, Any]:
        """
        Scans a directory for CSV/JSON files, ingests them as domains, 
        discovers LDS, and attempts auto-alignment.
        """
        data_path = Path(partner_data_dir).expanduser().resolve()
        if not data_path.exists() or not data_path.is_dir():
            return {"success": False, "error": f"Directory not found: {partner_data_dir}"}

        results = {
            "ingested_domains": [],
            "discovered_lds": [],
            "alignments_count": 0,
            "errors": []
        }

        # 1. Ingest all files
        for file in data_path.iterdir():
            if file.name.startswith("."): continue
            
            domain_name = file.stem.replace(" ", "_")
            table_name = domain_name.lower() 
            
            success = False
            if file.suffix == ".csv":
                success = self.csv_sensor.ingest_csv(str(file), domain_name, table_name)
            elif file.suffix == ".json":
                success = self.json_sensor.ingest_json(str(file), domain_name, table_name)
            
            if success:
                results["ingested_domains"].append(domain_name)
                self.broker.add_package(domain_name)
            else:
                results["errors"].append(f"Failed to ingest {file.name}")

        # 2. Discover LDS for each domain
        lds_files = {} # domain_name -> path
        for domain in results["ingested_domains"]:
            db_path = self.target_dir / ".makini" / "states" / f"{domain}.db"
            if db_path.exists():
                discoverer = DomainDiscoverer(str(db_path))
                lds_content = discoverer.discover_lds()
                
                # Save LDS file
                lds_dir = self.target_dir / ".makini" / "packages" / domain
                lds_dir.mkdir(parents=True, exist_ok=True)
                lds_path = lds_dir / "schema.lds"
                lds_path.write_text(lds_content)
                
                results["discovered_lds"].append(domain)
                lds_files[domain] = str(lds_path)

        # 3. Auto-Align all pairs
        domains = list(lds_files.keys())
        for i in range(len(domains)):
            for j in range(i + 1, len(domains)):
                d1, d2 = domains[i], domains[j]
                proposals = self.broker.negotiate_alignments(lds_files[d1], lds_files[d2], threshold=auto_align_threshold)
                
                for p in proposals:
                    self.broker.authorize_alignment(
                        d1, d2, 
                        p['source_concept'], p['target_concept'], 
                        p['confidence'], f"PartnerMesh Auto-Alignment: {p['rationale']}",
                        _defer_sync=True
                    )
                    results["alignments_count"] += 1

        if results["alignments_count"] > 0:
            self.broker.sync_all_ontologies()

        return results
