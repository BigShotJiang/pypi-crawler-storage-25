import os
import shlex
import subprocess
import platform
import tempfile
import stat
from pathlib import Path


def _escape_applescript(s: str) -> str:
    """Escapes a string for safe embedding inside an AppleScript double-quoted string."""
    return s.replace('\\', '\\\\').replace('"', '\\"')


def execute_headless_agy(prompt: str, target_dir: str = "."):
    print("[MAKINI] Igniting headless Antigravity engine...")
    target_path = Path(target_dir).absolute()
    try:
        # We pass the prompt via 'input', NOT as a command-line argument.
        # This breaks the TTY and forces a one-shot execution.
        result = subprocess.run(
            ["agy", "run", "--dangerously-skip-permissions"],
            input=prompt,
            capture_output=True,
            text=True,
            check=True,
            cwd=str(target_path)
        )
        return result.stdout.strip()
    except subprocess.CalledProcessError as e:
        print(f"[MAKINI FATAL] Engine failure: {e.stderr}")
        import sys
        sys.exit(1)


def launch_agent(target_dir: str, engine: str, yolo: bool = False, initial_prompt: str = "", headless: bool = False):
    """
    Attempts to launch the selected CLI agent in the target directory.
    On macOS, it opens a new Terminal window and brings it to the front.
    """
    target_path = Path(target_dir).absolute()

    # Construct base command
    if engine == "Antigravity":
        engine_cmd = "agy run"
    elif engine == "Claude Code":
        engine_cmd = "claude"
    elif engine == "Ollama":
        engine_cmd = "ollama run llama3"
    elif engine == "Codex":
        engine_cmd = "codex"
    else:
        engine_cmd = "agy run"

    flags = []
    if yolo:
        if engine == "Antigravity":
            flags.append("--dangerously-skip-permissions")
        elif engine == "Claude Code":
            flags.append("--dangerously-skip-permissions")
        elif engine == "Codex":
            flags.extend(["--approval-policy", "never"])

    if headless and (engine == "Antigravity" or engine == "agy"):
        output = execute_headless_agy(initial_prompt, target_dir=str(target_path))
        print(output)
        return True, "Headless execution completed successfully."

    system = platform.system()
    try:
        if system == "Darwin":  # macOS
            if initial_prompt and (engine == "Antigravity" or engine == "agy"):
                # Use UNIX expect to bypass AppleScript Accessibility prompts
                # This spawns agy in a true PTY, waits for the REPL, injects the prompt, and hands over control.
                engine_cmd_str = f"{engine_cmd} {' '.join(flags)}"
                
                # Escape quotes in the prompt for the expect script
                escaped_prompt = initial_prompt.replace('"', '\\"')
                
                expect_script_content = f"""#!/usr/bin/expect -f
# Set timeout to wait for the agy REPL to boot
set timeout 10

# Change to the target directory
cd "{str(target_path)}"

# Spawn the interactive Antigravity CLI
spawn {engine_cmd_str}

# Wait for the absolute LAST string the UI renders to guarantee the screen is drawn
expect "? for shortcuts"

# Give the TUI event loop 0.5 seconds to fully bind to stdin before we inject
sleep 0.5

# Send the initial priority task
send "{escaped_prompt}\\r"

# Hand control over to the user's terminal
interact
"""
                fd, script_path = tempfile.mkstemp(prefix="makini_agy_", suffix=".exp", text=True)
                with os.fdopen(fd, "w") as f:
                    f.write(expect_script_content)
                
                os.chmod(script_path, stat.S_IRWXU)
                
                # Tell macOS to open this script in a new Terminal window
                subprocess.run(["open", "-a", "Terminal", script_path], check=True)
                return True, "Launched Antigravity via expect PTY."
            else:
                # Standard AppleScript launch for other engines or empty prompts
                prompt_arg = f" {shlex.quote(initial_prompt)}" if initial_prompt else ""
                cmd = f"cd {shlex.quote(str(target_path))} && {engine_cmd} {' '.join(flags)}{prompt_arg}"
                escaped_cmd = _escape_applescript(cmd)
                applescript = f'''
                    tell application "Terminal"
                        activate
                        do script "{escaped_cmd}"
                    end tell
                '''
                subprocess.run(["osascript", "-e", applescript])
                return True, "Launched and focused Terminal."
        else:
            prompt_arg = f" {shlex.quote(initial_prompt)}" if initial_prompt else ""
            cmd = f"cd {shlex.quote(str(target_path))} && {engine_cmd} {' '.join(flags)}{prompt_arg}"
            return False, f"Auto-launch not supported on {system}. Please run '{cmd}' manually."
    except Exception as e:
        return False, str(e)

