from orc_sdk import workflow, task
from orc_sdk.workflow_builder.base import compile_wf_config


@task()
def hello() -> str:
    return "hi"


def test_compile_wf_config_smoke():
    @workflow(workflow_path="//tmp/orc_test_wf", triggers=[])
    def the_wf(wfro):
        wfro.register_first_step(hello())

    cfg = compile_wf_config(the_wf())

    assert cfg["triggers"] == []
    assert isinstance(cfg["steps"], list) and len(cfg["steps"]) == 1
    assert cfg["steps"][0]["task_type"] == "docker"
    assert "concurrency_policy" not in cfg


def test_compile_wf_config_serializes_concurrency_policy():
    @workflow(
        workflow_path="//tmp/orc_test_wf",
        triggers=[],
        max_active_runs=1,
        concurrency_strategy="ENQUEUE",
        queue_limit=2,
    )
    def the_wf(wfro):
        wfro.register_first_step(hello())

    cfg = compile_wf_config(the_wf())

    assert cfg["concurrency_policy"] == {
        "max_active_runs": 1,
        "concurrency_strategy": "ENQUEUE",
        "queue_limit": 2,
    }
