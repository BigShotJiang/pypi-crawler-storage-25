from __future__ import annotations

from rich.text import Text
from textual.containers import ScrollableContainer
from textual.widgets import Static


class RoleHeader(Static):
    def __init__(self, name: str, *, role: str):
        self.label = str(name or role)
        self.role = str(role or "assistant")
        super().__init__(self.renderable(), classes=f"role-header {self.role}")

    def renderable(self):
        label = f" {self.label} "
        return Text(label, style="#88b38a" if self.role == "user" else "#789fbe")


class StepMarker(Static):
    def __init__(self, *, role="assistant"):
        self.role = str(role or "assistant")
        super().__init__(Text("▪", style="#88b38a" if self.role == "user" else "#6f98bd"), classes=f"step-marker {self.role}")


class MessageBubble(Static):
    """One chat item in the scrollback.

    The widget owns its own content so live updates do not mutate or relayout a
    monolithic transcript buffer. Rendering intentionally mimics the previous
    transcript look: sparse role rules, discreet tool lines, and no chat bubbles.
    """

    def __init__(self, kind: str, content="", *, title: str = "", classes: str = ""):
        self.kind = str(kind or "info")
        self.title = str(title or "")
        self._body = content
        super().__init__(self.renderable(), classes=f"message {self.kind} {classes}".strip())

    def renderable(self):
        if self.kind in {"user", "assistant"}:
            body_style = "#aeb0aa" if self.kind != "user" else "#d6e4c9"
            return self.as_text(self._body, style=body_style)
        if self.kind == "tool":
            return self.tool_line(self.title, self._body)
        if self.kind == "slash-command":
            return self.slash_command_line(self.title, self._body)
        if self.kind == "info":
            return Text("info > ", style="bold #7d8590") + self.as_text(self._body, style="#8b949e")
        if self.kind == "error":
            return Text("error > ", style="bold #ff7b72") + self.as_text(self._body, style="#ff7b72")
        if self.kind == "step-end":
            return Text("▪", style="#6f98bd")
        return self.as_text(self._body)

    def set_body(self, content):
        self._body = content
        self.update(self.renderable())

    @classmethod
    def tool_line(cls, title, detail):
        name = str(title or "tool").removeprefix("↳ ")
        status, call_id = cls._split_status_detail(detail)
        icon, style = cls._status_badge(status)
        text = Text("  ", style="#4b5563")
        text += Text(f"{icon} ", style=style)
        text += Text(name or "tool", style="bold white")
        short_id = cls._short_call_id(call_id)
        if short_id:
            text += Text(f"  #{short_id}", style="#6e7681")
        return text

    @classmethod
    def slash_command_line(cls, title, detail):
        command = str(title or "/").removeprefix("/")
        args = str(detail or "").strip()
        text = Text("  ", style="#4b5563")
        text += Text("→ ", style="bold #58a6ff")
        text += Text(f"/{command}" if command else "/", style="bold white")
        if args:
            text += Text(f" {args}", style="#8b949e")
        return text

    @staticmethod
    def _split_status_detail(detail):
        parts = [part.strip() for part in str(detail or "").split("·", 1)]
        status = parts[0] if parts else ""
        call_id = parts[1] if len(parts) > 1 else ("" if status in {"running", "done", "failed"} else status)
        return status, call_id

    @staticmethod
    def _status_badge(status):
        status = str(status or "running")
        if status in {"done", "completed", "success"}:
            return "✓", "bold #3fb950"
        if status in {"failed", "failure", "error"}:
            return "✕", "bold #ff7b72"
        return "→", "bold #58a6ff"

    @staticmethod
    def _short_call_id(call_id, *, max_length=16):
        if not call_id:
            return ""
        call_id = str(call_id)
        if len(call_id) <= max_length:
            return call_id
        keep = max(4, max_length - 2)
        head = max(4, keep // 2)
        tail = max(4, keep - head)
        return f"{call_id[:head]}…{call_id[-tail:]}"

    @staticmethod
    def as_text(content, *, style=None):
        if isinstance(content, Text):
            return content
        return Text(str(content or ""), style=style)


class ConversationTimeline(ScrollableContainer):
    """Scrollable chat surface made of independent message widgets."""

    def __init__(self, *args, visible_limit: int = 260, **kwargs):
        super().__init__(*args, **kwargs)
        self.visible_limit = visible_limit
        self.active_assistant: MessageBubble | None = None
        self._active_assistant_text = ""
        self.last_role: str | None = None

    def clear_messages(self):
        self.remove_children()
        self.active_assistant = None
        self._active_assistant_text = ""
        self.last_role = None

    def add_user(self, text, *, title="You"):
        should_stick = self.should_stick_to_bottom()
        self.ensure_role("user", title, stick_to_bottom=should_stick)
        return self.add_message("user", str(text or ""), title="", stick_to_bottom=should_stick)

    def add_assistant_message(self, text, *, title="Pandora"):
        should_stick = self.should_stick_to_bottom()
        self.ensure_role("assistant", title, stick_to_bottom=should_stick)
        if self.active_assistant is not None:
            widget = self.active_assistant
            widget.title = title
            widget.set_body(str(text or ""))
            widget.remove_class("live")
            self.active_assistant = None
            self._active_assistant_text = ""
            self.maybe_scroll_end(should_stick)
            return widget
        return self.add_message("assistant", str(text or ""), title="", stick_to_bottom=should_stick)

    def ensure_role(self, role, title, *, stick_to_bottom=None):
        role = str(role or "assistant")
        if self.last_role == role:
            return None
        self.last_role = role
        return self.add_header(title or role, role=role, stick_to_bottom=stick_to_bottom)

    def add_header(self, title, *, role, stick_to_bottom=None):
        should_stick = self.should_stick_to_bottom() if stick_to_bottom is None else stick_to_bottom
        widget = RoleHeader(title, role=role)
        self.mount(widget)
        self._trim_old_widgets()
        self.maybe_scroll_end(should_stick)
        return widget

    def ensure_active_assistant(self, *, title="Pandora", stick_to_bottom=None):
        self.ensure_role("assistant", title, stick_to_bottom=stick_to_bottom)
        if self.active_assistant is None:
            self.active_assistant = self.add_message("assistant", "", title="", classes="live", stick_to_bottom=stick_to_bottom)
            self._active_assistant_text = ""
        return self.active_assistant

    def append_assistant_delta(self, delta, *, title="Pandora"):
        should_stick = self.should_stick_to_bottom()
        self._active_assistant_text += str(delta or "")
        widget = self.ensure_active_assistant(title=title, stick_to_bottom=should_stick)
        widget.set_body(self._active_assistant_text)
        self.maybe_scroll_end(should_stick)
        return widget

    def commit_active_assistant_preview(self):
        if self.active_assistant is None:
            return False
        self.active_assistant.remove_class("live")
        self.active_assistant = None
        self._active_assistant_text = ""
        return True

    def clear_active_assistant(self):
        if self.active_assistant is not None:
            self.active_assistant.remove()
        self.active_assistant = None
        self._active_assistant_text = ""

    def add_tool(self, name, call_id=None, status=None):
        label = f"↳ {name or 'tool'}"
        detail = str(status or "")
        if call_id:
            detail = f"{detail} · {call_id}" if detail else str(call_id)
        return self.add_message("tool", detail, title=label)

    def add_slash_command(self, name, args="", status=None):
        label = f"/{name or 'command'}"
        detail = " ".join(part for part in [str(args or ""), str(status or "")] if part)
        return self.add_message("slash-command", detail, title=label)

    def add_info(self, text):
        return self.add_message("info", str(text or ""))

    def add_error(self, text):
        return self.add_message("error", str(text or ""))

    def add_step_separator(self):
        should_stick = self.should_stick_to_bottom()
        widget = StepMarker(role="assistant")
        self.mount(widget)
        self._trim_old_widgets()
        self.maybe_scroll_end(should_stick)
        return widget

    def add_message(self, kind, content="", *, title="", classes="", stick_to_bottom=None):
        should_stick = self.should_stick_to_bottom() if stick_to_bottom is None else stick_to_bottom
        widget = MessageBubble(kind, content, title=title, classes=classes)
        self.mount(widget)
        self._trim_old_widgets()
        self.maybe_scroll_end(should_stick)
        return widget

    def should_stick_to_bottom(self, *, tolerance=1):
        return self.scroll_y >= max(0, self.max_scroll_y - tolerance)

    def maybe_scroll_end(self, should_stick):
        if should_stick:
            self.scroll_end(animate=False)

    def _trim_old_widgets(self):
        if self.visible_limit <= 0:
            return
        children = list(self.children)
        overflow = len(children) - self.visible_limit
        if overflow <= 0:
            return
        for child in children[:overflow]:
            if child is self.active_assistant:
                continue
            child.remove()
