from .tiny_flags import TinyFlags as TinyFlags
