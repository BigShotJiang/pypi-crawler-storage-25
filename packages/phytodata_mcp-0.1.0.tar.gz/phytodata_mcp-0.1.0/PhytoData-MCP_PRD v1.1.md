# PhytoData-MCP — Product Requirements Document
> Standalone MCP Server for Plant Genomics · PRD v1.1

---

## 1. Vision & Problem Statement

Plant biotechnology researchers spend a disproportionate amount of time manually navigating siloed databases (Phytozome, KEGG, Ensembl Plants, UniProt) to build a complete picture of a single gene's function, pathway membership, cross-species conservation, and protein behavior. There is no unified conversational interface that chains these queries automatically.

**PhytoData-MCP** solves this by exposing the four most important plant genomics databases as MCP tools that an LLM host (Claude Sonnet) can chain together autonomously. The LLM owns all reasoning and interpretation; the MCP server owns only I/O and API calls.

> **Note on future compatibility:** PhytoData-MCP is designed as a standalone, self-contained MCP server. The architecture is intentionally modular so it can later be integrated into a broader BioMCP suite without refactoring.

---

## 2. Positioning

**Package name:** `phytodata-mcp`
**GitHub repo:** `github.com/zaeyasa/phytodata-mcp`
**PyPI package:** `phytodata-mcp`

**Target users:** Plant biotechnologists, computational biologists, graduate students in plant sciences.

**Primary use case example:**
> *"Fetch the gene info for AT3G24650 in Arabidopsis, identify its KEGG pathway, and find its orthologs in wheat and tomato."*
> The LLM chains: PhytoMine → KEGG → Ensembl Plants — all in one turn.

---

## 3. Architecture Principles

1. **MCP server = I/O only.** No summarization, no ranking, no interpretation logic inside the server. Return clean structured data; let the LLM reason.
2. **Tool chaining is first-class.** Every tool response MUST include a `next_tool_hint` field (see §5) that explicitly tells the LLM which tool to call next and with which output field.
3. **Graceful, actionable failures.** On any API error, return a structured error object — never a naked exception. The error message must guide the LLM's next action (e.g., suggest alternate ID format).
4. **Phase-gated scope.** Build Phase 1 only. Do not implement Phase 2 tools until Phase 1 is stable and tested.

---

## 4. Tech Stack

```
Runtime:         Python 3.10+
MCP framework:   FastMCP  (mcp library)
HTTP client:     requests
Phytozome:       requests → PhytoMine REST  ⚠️ NOT the intermine Python library
KEGG:            requests → rest.kegg.jp
Ensembl Plants:  requests → rest.ensembl.org (Plants division)
UniProt:         requests → rest.uniprot.org
Config:          python-dotenv (.env for any API keys)
```

> ⚠️ **PhytoMine:** The `intermine` Python library introduces version incompatibilities with newer PhytoMine instances. Always use direct `requests` calls with URL-encoded InterMine query XML.

---

## 5. Tool Specifications

### `next_tool_hint` Convention (ALL tools)

Every successful response dict must include this field:

```json
"next_tool_hint": {
  "suggested_tool": "<tool_name or null>",
  "use_field": "<output field name to pass>",
  "reason": "<one sentence why>"
}
```

If no natural next step exists, set `suggested_tool` to `null`.

---

### Tool 1 — `phytomine_gene_info` ✅ Phase 1

**API:** PhytoMine REST at `https://phytozome-next.jgi.doe.gov/phytomine`

**Input:**
```python
gene_id: str    # e.g. "AT1G01010" (Arabidopsis) or "Potri.001G000100" (Populus trichocarpa)
organism: str   # e.g. "Arabidopsis thaliana", "Populus trichocarpa"
```

**Logic:**
1. Build an InterMine query XML to fetch Gene object by `primaryIdentifier`.
2. `POST /phytomine/service/query/results` with URL-encoded XML.
3. Extract GO terms (biological process, molecular function, cellular component), Pfam domain IDs, and KO ID.
4. KO ID is the critical output — it is the entry point for `kegg_pathway_lookup`.

**Output schema:**
```json
{
  "gene_id": "AT1G01010",
  "organism": "Arabidopsis thaliana",
  "go_terms": {
    "biological_process": ["GO:0006355 - regulation of transcription"],
    "molecular_function": ["GO:0003677 - DNA binding"],
    "cellular_component": ["GO:0005634 - nucleus"]
  },
  "pfam_domains": ["PF00847"],
  "ko_id": "K14431",
  "next_tool_hint": {
    "suggested_tool": "kegg_pathway_lookup",
    "use_field": "ko_id",
    "reason": "Pass the KO ID to retrieve the biochemical pathways this gene participates in."
  }
}
```

**Error object:**
```json
{
  "error": true,
  "code": "PHYTOMINE_NOT_FOUND",
  "message": "Gene 'AT9G99999' not found in PhytoMine for organism 'Arabidopsis thaliana'.",
  "suggested_action": "Verify gene ID format. Arabidopsis: ATxGxxxxx · Populus: Potri.xxxGxxxxxx"
}
```

---

### Tool 2 — `kegg_pathway_lookup` ✅ Phase 1

**API:** `http://rest.kegg.jp` (free, no auth required for academic use — do not embed in commercial products without a KEGG license)

**Input:**
```python
ko_id: str        # KEGG Orthology ID, e.g. "K14431" — typically piped from phytomine_gene_info
ec_number: str    # Alternative: EC number e.g. "1.1.1.1"
```

**Logic:**
1. If input matches EC pattern (`\d+\.\d+\.\d+\.\d+`), resolve to KO first via `GET /find/ko/{ec_number}`.
2. `GET /link/pathway/{ko_id}` → list of pathway IDs.
3. For each pathway ID, `GET /get/{pathway_id}` → pathway name + key enzyme list.
4. Return top 5 pathways max.

**Output schema:**
```json
{
  "ko_id": "K14431",
  "pathways": [
    {
      "pathway_id": "map04075",
      "pathway_name": "Plant hormone signal transduction",
      "key_enzymes": ["K14431", "K12126", "K09422"]
    }
  ],
  "pathway_count": 2,
  "next_tool_hint": {
    "suggested_tool": "ensembl_plants_orthologs",
    "use_field": "ko_id",
    "reason": "Find orthologs of this gene across crop species."
  }
}
```

**Error object:**
```json
{
  "error": true,
  "code": "KEGG_NOT_FOUND",
  "message": "KO ID 'K99999' not found. Format should be K followed by 5 digits.",
  "suggested_action": "Try resolving from an EC number using the ec_number parameter instead."
}
```

---

### Tool 3 — `ensembl_plants_orthologs` ✅ Phase 1

**API:** `https://rest.ensembl.org` (Plants division, no auth required)

**Input:**
```python
gene_id: str          # Ensembl stable gene ID, e.g. "AT3G24650" (Arabidopsis) or "Potri.001G000100" (Populus)
target_species: str   # e.g. "solanum_lycopersicum", "triticum_aestivum", "populus_trichocarpa"
                      # Pass "all_crops" to query 5 major crop species at once
```

**`all_crops` species list:** `arabidopsis_thaliana`, `populus_trichocarpa`, `solanum_lycopersicum`, `triticum_aestivum`, `zea_mays`, `oryza_sativa`, `hordeum_vulgare`

**Logic:**
1. `GET /homology/id/{gene_id}?target_species={species}&type=orthologues&content-type=application/json`
2. If `target_species == "all_crops"`, loop over the 5-species list above.
3. Return ortholog gene IDs, species, percent identity, alignment coverage.
4. Cap at 20 orthologs max.

**Output schema:**
```json
{
  "query_gene": "AT3G24650",
  "query_species": "arabidopsis_thaliana",
  "orthologs": [
    {
      "species": "solanum_lycopersicum",
      "ortholog_gene_id": "Solyc01g005000",
      "percent_identity": 78.4,
      "alignment_coverage": 0.91,
      "type": "ortholog_one2one"
    }
  ],
  "ortholog_count": 4,
  "next_tool_hint": {
    "suggested_tool": "uniprot_plant_protein",
    "use_field": "orthologs[*].ortholog_gene_id",
    "reason": "Retrieve subcellular localization and functional domains for these ortholog proteins."
  }
}
```

---

### Tool 4 — `uniprot_plant_protein` 🟡 Phase 2

**API:** `https://rest.uniprot.org` (no auth required)

**Input:**
```python
identifier: str      # UniProt accession (e.g. "P0DTX7") OR gene name (e.g. "RuBisCO")
organism_taxid: str  # NCBI taxonomy ID, e.g. "3702" (Arabidopsis), "4081" (tomato). Optional.
```

**Logic:**
1. If input matches UniProt accession pattern (`[A-Z][0-9][A-Z0-9]{3}[0-9]`), fetch directly: `GET /uniprotkb/{id}.json`.
2. Otherwise: `GET /uniprotkb/search?query=gene:{identifier}+organism_id:{taxid}&format=json`.
3. Extract: subcellular localization, functional domains, active sites, reviewed status (Swiss-Prot vs TrEMBL).

**`next_tool_hint`:** `null` — terminal tool in the chain.

---

## 6. Full Chain Flow

```
User query
    │
    ▼
phytomine_gene_info          →  GO terms, Pfam domains, KO ID
    │  ko_id
    ▼
kegg_pathway_lookup          →  pathway names, key enzymes
    │  ko_id / gene_id
    ▼
ensembl_plants_orthologs     →  orthologs across crop species
    │  ortholog_gene_id
    ▼
uniprot_plant_protein        →  subcellular localization, domains  [Phase 2]
```

---

## 7. Phased Roadmap

### Phase 1 — Full Working Chain (Scope-Locked)
**Goal:** PhytoMine → KEGG → Ensembl Plants, end-to-end in one LLM turn.

- [ ] Scaffold FastMCP server (`server.py`)
- [ ] Implement `phytomine_gene_info` (Arabidopsis + Populus trichocarpa tested)
- [ ] Implement `kegg_pathway_lookup` with EC→KO resolution
- [ ] Implement `ensembl_plants_orthologs` with `all_crops` support
- [ ] Add `next_tool_hint` to all three tools
- [ ] Shared HTTP client in `utils/http_client.py` (3 retries, exponential backoff)
- [ ] Integration tests: `test_phytomine.py`, `test_kegg.py`, `test_ensembl.py`
- [ ] `README.md` with install instructions + example chain prompt

**Done definition:** Claude Sonnet can take an Arabidopsis or Populus gene ID, retrieve its KO ID, resolve its KEGG pathway, and list orthologs in tomato and wheat — all in one prompt, zero manual steps.

### Phase 2 — Full Suite
- [ ] Implement `uniprot_plant_protein`
- [ ] End-to-end chain test: PhytoMine → KEGG → Ensembl → UniProt
- [ ] Expand organism support in PhytoMine tool beyond Arabidopsis/Populus

---

## 8. GitHub & PyPI

### Repository

**Recommended repo topics:** `mcp`, `plant-biology`, `bioinformatics`, `kegg`, `ensembl`, `phytozome`, `llm-tools`, `fastmcp`, `genomics`

**README badges:**
```markdown
![PyPI version](https://img.shields.io/pypi/v/phytodata-mcp)
![Python](https://img.shields.io/pypi/pyversions/phytodata-mcp)
![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)
```

### PyPI Package

`pyproject.toml` key fields:
```toml
[project]
name = "phytodata-mcp"
version = "0.1.0"
description = "MCP server providing LLMs with conversational access to plant genomics databases (PhytoMine, KEGG, Ensembl Plants, UniProt)"
requires-python = ">=3.10"
keywords = ["mcp", "plant-biology", "bioinformatics", "kegg", "ensembl", "phytozome"]
dependencies = [
    "mcp",
    "requests",
    "python-dotenv"
]

[project.scripts]
phytodata-mcp = "phytodata_mcp.server:main"
```

**Install:**
```bash
pip install phytodata-mcp
```

**Claude Desktop `claude_desktop_config.json`:**
```json
{
  "mcpServers": {
    "phytodata": {
      "command": "phytodata-mcp"
    }
  }
}
```

---

## 9. Project Structure

```
phytodata-mcp/
├── pyproject.toml
├── README.md
├── .env.example
├── phytodata_mcp/
│   ├── __init__.py
│   ├── server.py              # FastMCP entry point, tool registration
│   ├── tools/
│   │   ├── __init__.py
│   │   ├── phytomine.py       # phytomine_gene_info        [Phase 1]
│   │   ├── kegg.py            # kegg_pathway_lookup        [Phase 1]
│   │   ├── ensembl_plants.py  # ensembl_plants_orthologs   [Phase 1]
│   │   └── uniprot.py         # uniprot_plant_protein      [Phase 2]
│   └── utils/
│       ├── http_client.py     # Shared session, retry + backoff logic
│       └── validators.py      # ID format validators (KO, EC, Ensembl, gene IDs)
└── tests/
    ├── test_phytomine.py
    ├── test_kegg.py
    └── test_ensembl.py
```

---

*PhytoData-MCP PRD v1.1*
