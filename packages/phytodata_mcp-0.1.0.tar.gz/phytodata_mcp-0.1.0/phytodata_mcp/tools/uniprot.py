from typing import Dict, Any, Optional
import re
from phytodata_mcp.utils.http_client import get_http_client

def uniprot_plant_protein(identifier: str, organism_taxid: Optional[str] = None) -> Dict[str, Any]:
    """
    Retrieves subcellular localization and domains for a given UniProt accession or gene name.
    """
    client = get_http_client()
    
    # Check if identifier is a Uniprot Accession (e.g. P0DTX7)
    is_accession = bool(re.match(r"^[A-NR-Z][0-9]([A-Z][A-Z0-9]{2}[0-9]){1,2}$", identifier.upper()))
    
    try:
        if is_accession:
            url = f"https://rest.uniprot.org/uniprotkb/{identifier.upper()}.json"
            response = client.get(url)
            response.raise_for_status()
            data = response.json()
        else:
            # Query by gene name
            query_str = f"gene:{identifier}"
            if organism_taxid:
                query_str += f" AND organism_id:{organism_taxid}"
                
            url = f"https://rest.uniprot.org/uniprotkb/search?query={query_str}&format=json&size=1"
            response = client.get(url)
            response.raise_for_status()
            search_data = response.json()
            
            if "results" not in search_data or len(search_data["results"]) == 0:
                return {
                    "error": True,
                    "code": "UNIPROT_NOT_FOUND",
                    "message": f"No UniProt record found for '{identifier}'.",
                    "suggested_action": "Verify gene name or provide a known UniProt accession ID."
                }
            data = search_data["results"][0]

        accession = data.get("primaryAccession")
        reviewed = data.get("entryType") == "UniProtKB reviewed (Swiss-Prot)"
        
        # Extract Subcellular Location
        subcellular_locations = []
        for comment in data.get("comments", []):
            if comment.get("commentType") == "SUBCELLULAR LOCATION":
                for subloc in comment.get("subcellularLocations", []):
                    subcellular_locations.append(subloc.get("location", {}).get("value"))
                    
        # Extract Domains & Active Sites
        domains = []
        active_sites = []
        for feature in data.get("features", []):
            ft_type = feature.get("type", "")
            if ft_type == "Domain":
                domains.append(feature.get("description", "Unknown Domain"))
            elif ft_type == "Active site":
                active_sites.append(feature.get("description", "Active Site"))
                
        return {
            "query_identifier": identifier,
            "uniprot_accession": accession,
            "reviewed": reviewed,
            "subcellular_locations": list(set(subcellular_locations)),
            "functional_domains": list(set(domains)),
            "active_sites": list(set(active_sites)),
            "next_tool_hint": None
        }

    except Exception as e:
        return {
            "error": True,
            "code": "UNIPROT_API_ERROR",
            "message": f"Failed to connect to UniProt: {str(e)}",
            "suggested_action": "Try again later."
        }
