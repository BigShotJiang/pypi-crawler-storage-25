from typing import Dict, Any, Optional
from phytodata_mcp.utils.http_client import get_http_client
import re

def resolve_ec_to_ko(ec_number: str) -> Optional[str]:
    client = get_http_client()
    try:
        response = client.get(f"http://rest.kegg.jp/find/ko/{ec_number}")
        if response.status_code == 200 and response.text.strip():
            # Returns lines like: "ko:K14431\txyz enzyme"
            match = re.search(r"ko:(K\d{5})", response.text)
            if match:
                return match.group(1)
    except:
        pass
    return None

def kegg_pathway_lookup(ko_id: Optional[str] = None, ec_number: Optional[str] = None) -> Dict[str, Any]:
    if not ko_id and not ec_number:
        return {
            "error": True,
            "code": "KEGG_MISSING_INPUT",
            "message": "Must provide either ko_id or ec_number.",
            "suggested_action": "Provide a valid KO ID or EC number."
        }

    resolved_ko = ko_id
    if ec_number and not ko_id:
        resolved_ko = resolve_ec_to_ko(ec_number)
        if not resolved_ko:
            return {
                "error": True,
                "code": "KEGG_NOT_FOUND",
                "message": f"Could not resolve EC number '{ec_number}' to a KO ID.",
                "suggested_action": "Check EC number or provide a KO ID instead."
            }

    if not resolved_ko or not resolved_ko.startswith("K") or len(resolved_ko) != 6:
        return {
            "error": True,
            "code": "KEGG_INVALID_KO",
            "message": f"KO ID '{resolved_ko}' is invalid.",
            "suggested_action": "Check the KO format. It should be 'K' followed by 5 digits."
        }

    client = get_http_client()
    pathways = []
    
    try:
        # Link ko to pathway
        link_res = client.get(f"http://rest.kegg.jp/link/pathway/{resolved_ko}")
        if link_res.status_code != 200 or not link_res.text.strip():
            return {
                "error": True,
                "code": "KEGG_NO_PATHWAYS",
                "message": f"No pathways found for KO ID '{resolved_ko}'.",
                "suggested_action": "This ortholog might not be mapped to any known KEGG pathway."
            }

        pathway_ids = []
        for line in link_res.text.strip().split("\n"):
            parts = line.split("\t")
            if len(parts) == 2:
                # Returns path:map04075 or path:ko04075
                pid = parts[1].replace("path:ko", "map").replace("path:", "")
                if pid not in pathway_ids and pid.startswith("map"):
                    pathway_ids.append(pid)

        # Cap at top 5
        pathway_ids = pathway_ids[:5]

        for pid in pathway_ids:
            get_res = client.get(f"http://rest.kegg.jp/get/{pid}")
            if get_res.status_code == 200:
                name_match = re.search(r"NAME\s+(.+)", get_res.text)
                name = name_match.group(1).strip() if name_match else pid
                
                # Extract up to 5 key enzymes from orthology section
                enzymes = []
                ortho_section = False
                for line in get_res.text.split("\n"):
                    if line.startswith("ORTHOLOGY"):
                        ortho_section = True
                    elif ortho_section and not line.startswith(" "):
                        ortho_section = False
                    
                    if ortho_section:
                        ko_match = re.search(r"(K\d{5})", line)
                        if ko_match and ko_match.group(1) not in enzymes:
                            enzymes.append(ko_match.group(1))

                pathways.append({
                    "pathway_id": pid,
                    "pathway_name": name,
                    "key_enzymes": enzymes[:5]
                })

        return {
            "ko_id": resolved_ko,
            "pathways": pathways,
            "pathway_count": len(pathways),
            "next_tool_hint": {
                "suggested_tool": "ensembl_plants_orthologs",
                "use_field": "ko_id",
                "reason": "Find orthologs of this gene across crop species."
            }
        }

    except Exception as e:
        return {
            "error": True,
            "code": "KEGG_API_ERROR",
            "message": f"Failed to connect to KEGG: {str(e)}",
            "suggested_action": "Try again later."
        }
