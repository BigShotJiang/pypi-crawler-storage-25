from typing import Dict, Any, Optional
from phytodata_mcp.utils.http_client import get_http_client
from xml.sax.saxutils import escape

PHYTOMINE_URL = "https://phytozome-next.jgi.doe.gov/phytomine/service/query/results"

def build_phytomine_xml(gene_id: str, organism: str) -> str:
    """
    Builds the InterMine XML query for the given gene_id and organism.
    """
    safe_gene_id = escape(gene_id)
    safe_org = escape(organism)
    # This query retrieves gene, GO annotations, Pfam domains, and KO ID (via pathways if mapped that way, but often it's in a specific KEGG pathway or cross reference)
    # Phytozome often stores KO annotations. Let's get pathways and cross references.
    return f"""<query name="" model="genomic" view="Gene.primaryIdentifier Gene.goAnnotation.ontologyTerm.identifier Gene.goAnnotation.ontologyTerm.name Gene.goAnnotation.ontologyTerm.namespace Gene.proteinDomains.identifier Gene.pathways.identifier" longDescription="" sortOrder="Gene.primaryIdentifier asc">
  <constraint path="Gene.primaryIdentifier" op="=" value="{safe_gene_id}"/>
  <constraint path="Gene.organism.name" op="=" value="{safe_org}"/>
</query>"""

def _extract_ko_id(results: list) -> Optional[str]:
    # Extract KO ID which starts with K followed by 5 digits
    for row in results:
        for val in row:
            if isinstance(val, str) and val.startswith("K") and len(val) == 6 and val[1:].isdigit():
                return val
            if isinstance(val, str) and "ko:" in val:
                parts = val.split("ko:")
                if len(parts) > 1 and parts[1].startswith("K") and len(parts[1]) >= 6:
                    return parts[1][:6]
    return None

def phytomine_gene_info(gene_id: str, organism: str) -> Dict[str, Any]:
    """
    Fetches gene information including GO terms, Pfam domains, and KO ID from PhytoMine.
    """
    client = get_http_client()
    xml_query = build_phytomine_xml(gene_id, organism)
    
    data = {
        "query": xml_query,
        "format": "json"
    }
    
    try:
        response = client.post(PHYTOMINE_URL, data=data, timeout=15)
        response.raise_for_status()
        result_json = response.json()
        
        results = result_json.get("results", [])
        if not results:
            return {
                "error": True,
                "code": "PHYTOMINE_NOT_FOUND",
                "message": f"Gene '{gene_id}' not found in PhytoMine for organism '{organism}'.",
                "suggested_action": "Verify gene ID format or that the specific organism genome is correct."
            }
            
        go_terms = {
            "biological_process": set(),
            "molecular_function": set(),
            "cellular_component": set()
        }
        pfam_domains = set()
        
        # Row layout based on our view:
        # 0: Gene.primaryIdentifier
        # 1: GO term ID
        # 2: GO term Name
        # 3: GO term Namespace
        # 4: Pfam identifier
        # 5: Pathway identifier
        
        for row in results:
            # Handle GO terms
            if row[1] and row[2] and row[3]:
                namespace = row[3].replace("_", " ") # biological_process, etc.
                go_str = f"{row[1]} - {row[2]}"
                if row[3] in go_terms:
                    go_terms[row[3]].add(go_str)
            
            # Handle Pfam
            if row[4] and row[4].startswith("PF"):
                pfam_domains.add(row[4])

        ko_id = _extract_ko_id(results)
        if not ko_id:
            ko_id = "Not Found"

        return {
            "gene_id": gene_id,
            "organism": organism,
            "go_terms": {k: list(v) for k, v in go_terms.items()},
            "pfam_domains": list(pfam_domains),
            "ko_id": ko_id,
            "next_tool_hint": {
                "suggested_tool": "kegg_pathway_lookup",
                "use_field": "ko_id",
                "reason": "Pass the KO ID to retrieve the biochemical pathways this gene participates in."
            }
        }

    except Exception as e:
        return {
            "error": True,
            "code": "PHYTOMINE_API_ERROR",
            "message": f"Failed to connect to PhytoMine: {str(e)}",
            "suggested_action": "Try again later or check network connection."
        }
