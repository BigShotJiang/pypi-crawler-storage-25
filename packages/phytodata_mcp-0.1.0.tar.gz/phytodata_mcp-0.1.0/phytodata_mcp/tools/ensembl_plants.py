from typing import Dict, Any, List
from phytodata_mcp.utils.http_client import get_http_client

ALL_CROPS = [
    "arabidopsis_thaliana",
    "populus_trichocarpa",
    "solanum_lycopersicum",
    "triticum_aestivum",
    "zea_mays",
    "oryza_sativa",
    "hordeum_vulgare"
]

def ensembl_plants_orthologs(gene_id: str, target_species: str) -> Dict[str, Any]:
    """
    Finds orthologous genes across crop species using Ensembl Plants.
    """
    client = get_http_client()
    
    species_list = ALL_CROPS if target_species == "all_crops" else [target_species]
    orthologs_list = []
    query_species = None

    try:
        for species in species_list:
            url = f"https://rest.ensembl.org/homology/id/{gene_id}?target_species={species}&type=orthologues&content-type=application/json"
            response = client.get(url)
            
            # Ensembl returns 400 for bad requests (like bad species or gene_id)
            if response.status_code == 400:
                continue
                
            response.raise_for_status()
            data = response.json()
            
            if "data" in data and len(data["data"]) > 0:
                q_data = data["data"][0]
                if not query_species:
                    query_species = q_data.get("species")
                
                homologies = q_data.get("homologies", [])
                for hom in homologies:
                    target = hom.get("target", {})
                    orthologs_list.append({
                        "species": target.get("species"),
                        "ortholog_gene_id": target.get("id"),
                        "percent_identity": target.get("perc_id"),
                        "alignment_coverage": target.get("perc_cov"),
                        "type": hom.get("type")
                    })
                    
                    if len(orthologs_list) >= 20:
                        break
                        
            if len(orthologs_list) >= 20:
                break

        if not orthologs_list:
             return {
                "error": True,
                "code": "ENSEMBL_NOT_FOUND",
                "message": f"No orthologs found for gene '{gene_id}' in target species '{target_species}'.",
                "suggested_action": "Check the gene_id or try a different target_species."
            }

        return {
            "query_gene": gene_id,
            "query_species": query_species or "unknown",
            "orthologs": orthologs_list[:20],
            "ortholog_count": len(orthologs_list[:20]),
            "next_tool_hint": {
                "suggested_tool": "uniprot_plant_protein",
                "use_field": "orthologs[*].ortholog_gene_id",
                "reason": "Retrieve subcellular localization and functional domains for these ortholog proteins."
            }
        }

    except Exception as e:
        return {
            "error": True,
            "code": "ENSEMBL_API_ERROR",
            "message": f"Failed to connect to Ensembl Plants: {str(e)}",
            "suggested_action": "Network issue or service unavailable. Try again later."
        }
