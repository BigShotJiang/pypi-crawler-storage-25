import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

def get_http_client() -> requests.Session:
    """
    Returns a configured requests.Session with retry logic and exponential backoff.
    
    Configuration:
    - Retries: 3
    - Backoff factor: 1.0 (1s, 2s, 4s delay between retries)
    - Status forcelist: 429, 500, 502, 503, 504
    - Allowed methods: GET, POST
    """
    session = requests.Session()
    
    retry_strategy = Retry(
        total=3,
        backoff_factor=1.0,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET", "POST"]
    )
    
    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    
    # Generic User-Agent good practice for academic APIs
    session.headers.update({
        "User-Agent": "phytodata-mcp/0.1.0 (Academic LLM Tool; https://github.com/zaeyasa/phytodata-mcp)"
    })
    
    return session
