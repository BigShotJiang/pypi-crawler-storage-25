import re

def is_valid_ko_id(ko_id: str) -> bool:
    """
    Validates if a given string is a valid KEGG Orthology (KO) ID.
    Format: 'K' followed by 5 digits (e.g., K14431)
    """
    return bool(re.match(r"^K\d{5}$", ko_id))

def is_valid_ec_number(ec_number: str) -> bool:
    """
    Validates if a given string is a valid EC number.
    Format: d.d.d.d, where each d can be a number or a dash (e.g., 1.1.1.1)
    """
    return bool(re.match(r"^\d+\.\d+\.\d+\.\d+$", ec_number))

def is_valid_arabidopsis_gene(gene_id: str) -> bool:
    """
    Validates Arabidopsis gene ID format.
    Format: ATxGxxxxx where x is digit (e.g., AT1G01010)
    """
    return bool(re.match(r"^AT[1-5M]G\d{5}$", gene_id.upper()))

def is_valid_populus_gene(gene_id: str) -> bool:
    """
    Validates Populus trichocarpa gene ID format.
    Format: Potri.xxxGxxxxxx (e.g., Potri.001G000100)
    """
    return bool(re.match(r"^Potri\.\d{3}G\d{6}$", gene_id, re.IGNORECASE))
