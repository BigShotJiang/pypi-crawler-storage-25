import base64
from typing import Optional
from dotenv import load_dotenv

from mcp.server.fastmcp import FastMCP

from phytodata_mcp.tools.phytomine import phytomine_gene_info
from phytodata_mcp.tools.kegg import kegg_pathway_lookup
from phytodata_mcp.tools.ensembl_plants import ensembl_plants_orthologs
from phytodata_mcp.tools.uniprot import uniprot_plant_protein

load_dotenv()

mcp = FastMCP("PhytoData-MCP", dependencies=["requests", "python-dotenv"])

@mcp.tool()
def get_phytomine_gene_info(gene_id: str, organism: str) -> dict:
    """
    Fetches the gene info (GO terms, Pfam domains, KO ID) for a given plant gene and organism.
    
    Args:
        gene_id: The primary gene identifier.
        organism: The organism name (e.g., 'Arabidopsis thaliana', 'Phaseolus vulgaris').
    """
    return phytomine_gene_info(gene_id, organism)

@mcp.tool()
def get_kegg_pathway_lookup(ko_id: str = "", ec_number: str = "") -> dict:
    """
    Retrieves up to 5 highest-level KEGG pathways associated with a given KO ID or EC number.
    
    Args:
        ko_id: Optional KEGG Orthology ID (e.g., 'K14431').
        ec_number: Optional EC number (e.g., '1.1.1.1').
    """
    # FastMCP maps kwargs slightly differently so defaults are handled cleanly
    return kegg_pathway_lookup(ko_id if ko_id else None, ec_number if ec_number else None)

@mcp.tool()
def get_ensembl_plants_orthologs(gene_id: str, target_species: str) -> dict:
    """
    Finds orthologs for a given query plant gene in a specific crop or all major crops.
    
    Args:
        gene_id: Core gene identifier.
        target_species: Species to find homologues in (e.g. 'solanum_lycopersicum' or 'all_crops').
    """
    return ensembl_plants_orthologs(gene_id, target_species)

@mcp.tool()
def get_uniprot_plant_protein(identifier: str, organism_taxid: str = "") -> dict:
    """
    Retrieves subcellular localization and domains for a given UniProt protein. (Phase 2)
    
    Args:
        identifier: UniProt accession or gene name.
        organism_taxid: Optional NCBI taxid.
    """
    return uniprot_plant_protein(identifier, organism_taxid if organism_taxid else None)

def main():
    mcp.run()

if __name__ == "__main__":
    main()
