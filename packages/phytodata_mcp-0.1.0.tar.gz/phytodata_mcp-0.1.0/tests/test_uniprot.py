import pytest
from unittest.mock import patch, MagicMock
from phytodata_mcp.tools.uniprot import uniprot_plant_protein

@patch("phytodata_mcp.tools.uniprot.get_http_client")
def test_uniprot_plant_protein_happy_path_accession(mock_get_client):
    mock_client = MagicMock()
    mock_get = MagicMock()
    mock_get.status_code = 200
    mock_get.json.return_value = {
        "primaryAccession": "P0DTX7",
        "entryType": "UniProtKB reviewed (Swiss-Prot)",
        "comments": [{
            "commentType": "SUBCELLULAR LOCATION",
            "subcellularLocations": [{"location": {"value": "Nucleus"}}]
        }],
        "features": [{"type": "Domain", "description": "bHLH"}]
    }
    mock_client.get.return_value = mock_get
    mock_get_client.return_value = mock_client

    res = uniprot_plant_protein("P0DTX7")
    assert "error" not in res
    assert res["query_identifier"] == "P0DTX7"
    assert res["uniprot_accession"] == "P0DTX7"
    assert res["reviewed"] is True
    assert "Nucleus" in res["subcellular_locations"]
    assert "bHLH" in res["functional_domains"]
    assert res["next_tool_hint"] is None

@patch("phytodata_mcp.tools.uniprot.get_http_client")
def test_uniprot_plant_protein_unhappy_path(mock_get_client):
    mock_client = MagicMock()
    mock_get = MagicMock()
    mock_get.status_code = 400
    # Simulate API error
    mock_client.get.side_effect = Exception("Not found dummy")
    mock_get_client.return_value = mock_client
    
    res = uniprot_plant_protein("INVALID_123")
    assert res.get("error") is True
    assert res.get("code") == "UNIPROT_API_ERROR"
