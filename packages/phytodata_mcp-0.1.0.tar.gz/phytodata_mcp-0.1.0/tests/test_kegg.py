import pytest
from unittest.mock import patch, MagicMock
from phytodata_mcp.tools.kegg import kegg_pathway_lookup, resolve_ec_to_ko

@patch("phytodata_mcp.tools.kegg.get_http_client")
def test_resolve_ec_to_ko(mock_get_client):
    mock_client = MagicMock()
    mock_get = MagicMock()
    mock_get.text = "ko:K14431\tEnzyme Name"
    mock_get.status_code = 200
    mock_client.get.return_value = mock_get
    mock_get_client.return_value = mock_client
    
    ko = resolve_ec_to_ko("1.1.1.1")
    assert ko == "K14431"

@patch("phytodata_mcp.tools.kegg.get_http_client")
def test_kegg_pathway_lookup_happy_path_ko(mock_get_client):
    mock_client = MagicMock()
    mock_link = MagicMock()
    mock_link.text = "ko:K14431\tpath:map04075\n"
    mock_link.status_code = 200
    
    mock_get_res = MagicMock()
    mock_get_res.text = "NAME        Plant hormone signal transduction\nORTHOLOGY   K14431  Enzyme X\n"
    mock_get_res.status_code = 200
    
    # Map the mock client's get route
    def side_effect(url):
        if "link" in url:
            return mock_link
        elif "get" in url:
            return mock_get_res
        return MagicMock(status_code=404)
        
    mock_client.get.side_effect = side_effect
    mock_get_client.return_value = mock_client

    res = kegg_pathway_lookup(ko_id="K14431")
    assert "error" not in res
    assert res["ko_id"] == "K14431"
    assert "pathways" in res
    assert isinstance(res["pathways"], list)
    assert res["pathway_count"] == 1
    assert res["pathways"][0]["pathway_id"] == "map04075"
    assert "next_tool_hint" in res
    assert res["next_tool_hint"]["suggested_tool"] == "ensembl_plants_orthologs"

@patch("phytodata_mcp.tools.kegg.get_http_client")
def test_kegg_pathway_lookup_unhappy_path_missing_inputs(mock_get_client):
    res = kegg_pathway_lookup()
    assert res.get("error") is True
    assert res.get("code") == "KEGG_MISSING_INPUT"

@patch("phytodata_mcp.tools.kegg.get_http_client")
def test_kegg_pathway_lookup_unhappy_path_invalid_ko(mock_get_client):
    res = kegg_pathway_lookup(ko_id="K123")
    assert res.get("error") is True
    assert res.get("code") == "KEGG_INVALID_KO"

@patch("phytodata_mcp.tools.kegg.get_http_client")
def test_kegg_pathway_lookup_unhappy_path_no_pathway(mock_get_client):
    mock_client = MagicMock()
    mock_link = MagicMock()
    mock_link.text = "" # No pathways mapped
    mock_link.status_code = 200
    mock_client.get.return_value = mock_link
    mock_get_client.return_value = mock_client

    res = kegg_pathway_lookup(ko_id="K00000")
    if "error" in res:
        assert res.get("code") in ["KEGG_NO_PATHWAYS", "KEGG_API_ERROR"]
