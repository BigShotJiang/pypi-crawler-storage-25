import pytest
from unittest.mock import patch, MagicMock
from phytodata_mcp.tools.phytomine import phytomine_gene_info, build_phytomine_xml

def test_build_phytomine_xml():
    xml = build_phytomine_xml("AT1G01010", "Arabidopsis thaliana")
    assert "AT1G01010" in xml
    assert "Arabidopsis thaliana" in xml
    assert "Gene.primaryIdentifier" in xml

@patch("phytodata_mcp.tools.phytomine.get_http_client")
def test_phytomine_gene_info_happy_path(mock_get_client):
    mock_client = MagicMock()
    mock_post = MagicMock()
    
    mock_post.json.return_value = {
        "results": [
            ["AT1G01010", "GO:123", "Some Process", "biological_process", "PF001", "K14431"]
        ]
    }
    mock_post.status_code = 200
    mock_client.post.return_value = mock_post
    mock_get_client.return_value = mock_client

    res = phytomine_gene_info("AT1G01010", "Arabidopsis thaliana")
    assert "error" not in res
    assert res["gene_id"] == "AT1G01010"
    assert res["organism"] == "Arabidopsis thaliana"
    assert res["ko_id"] == "K14431"
    assert "go_terms" in res
    assert "pfam_domains" in res
    assert "next_tool_hint" in res
    assert res["next_tool_hint"]["suggested_tool"] == "kegg_pathway_lookup"

@patch("phytodata_mcp.tools.phytomine.get_http_client")
def test_phytomine_gene_info_unhappy_path(mock_get_client):
    mock_client = MagicMock()
    mock_post = MagicMock()
    mock_post.json.return_value = {"results": []}
    mock_post.status_code = 200
    mock_client.post.return_value = mock_post
    mock_get_client.return_value = mock_client

    res = phytomine_gene_info("INVALID_GENE_123", "Arabidopsis thaliana")
    # Verify error struct
    assert res.get("error") is True
    assert res.get("code") == "PHYTOMINE_NOT_FOUND"
    assert "Verify gene ID format" in res.get("suggested_action")
