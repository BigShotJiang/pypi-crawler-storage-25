import pytest
from unittest.mock import patch, MagicMock
from phytodata_mcp.tools.ensembl_plants import ensembl_plants_orthologs

@patch("phytodata_mcp.tools.ensembl_plants.get_http_client")
def test_ensembl_plants_orthologs_happy_path_single(mock_get_client):
    mock_client = MagicMock()
    mock_get = MagicMock()
    mock_get.status_code = 200
    mock_get.json.return_value = {
        "data": [{
            "species": "arabidopsis_thaliana",
            "homologies": [{
                "target": {
                    "species": "solanum_lycopersicum",
                    "id": "Solyc01g005000",
                    "perc_id": 78.4,
                    "perc_cov": 0.91
                },
                "type": "ortholog_one2one"
            }]
        }]
    }
    mock_client.get.return_value = mock_get
    mock_get_client.return_value = mock_client

    res = ensembl_plants_orthologs("AT3G24650", "solanum_lycopersicum")
    assert "error" not in res
    assert res["query_gene"] == "AT3G24650"
    assert res["query_species"] == "arabidopsis_thaliana"
    assert "orthologs" in res
    assert len(res["orthologs"]) == 1
    assert res["orthologs"][0]["species"] == "solanum_lycopersicum"
    assert res["orthologs"][0]["ortholog_gene_id"] == "Solyc01g005000"
    assert "next_tool_hint" in res
    assert res["next_tool_hint"]["suggested_tool"] == "uniprot_plant_protein"

@patch("phytodata_mcp.tools.ensembl_plants.get_http_client")
def test_ensembl_plants_orthologs_happy_path_all_crops(mock_get_client):
    mock_client = MagicMock()
    mock_get = MagicMock()
    mock_get.status_code = 200
    # Will be called 7 times for all crops, return a mock homologue each time
    mock_get.json.return_value = {
        "data": [{
            "species": "arabidopsis_thaliana",
            "homologies": [{
                "target": {"species": "some_crop", "id": "GeneX", "perc_id": 50, "perc_cov": 0.5},
                "type": "ortholog_one2one"
            }]
        }]
    }
    mock_client.get.return_value = mock_get
    mock_get_client.return_value = mock_client

    res = ensembl_plants_orthologs("AT3G24650", "all_crops")
    assert "error" not in res
    # called multiple times mapping to `orthologs` list
    assert len(res["orthologs"]) == 7

@patch("phytodata_mcp.tools.ensembl_plants.get_http_client")
def test_ensembl_plants_orthologs_unhappy_path_invalid_gene(mock_get_client):
    mock_client = MagicMock()
    mock_get = MagicMock()
    # Ensembl often returns 400 for bad ids
    mock_get.status_code = 400
    mock_client.get.return_value = mock_get
    mock_get_client.return_value = mock_client

    res = ensembl_plants_orthologs("INVALID_GENE", "solanum_lycopersicum")
    assert res.get("error") is True
    assert res.get("code") == "ENSEMBL_NOT_FOUND"

@patch("phytodata_mcp.tools.ensembl_plants.get_http_client")
def test_ensembl_plants_orthologs_unhappy_path_invalid_species(mock_get_client):
    mock_client = MagicMock()
    mock_get = MagicMock()
    mock_get.status_code = 400
    mock_client.get.return_value = mock_get
    mock_get_client.return_value = mock_client
    
    res = ensembl_plants_orthologs("AT3G24650", "invalid_species")
    assert res.get("error") is True
    assert res.get("code") == "ENSEMBL_NOT_FOUND" 
