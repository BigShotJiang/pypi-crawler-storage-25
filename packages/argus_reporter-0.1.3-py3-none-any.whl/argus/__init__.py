"""Fire-and-forget client for Argus.

Public API (v0.1.0):

    Reporter, JobContext              -- new context-manager front door
    emit, new_batch_id, set_batch_id, sub_env, get_batch_id
                                       -- module-level escape hatches
    ExperimentReporter                 -- v0.1.x low-level class (still works)
    SCHEMA_VERSION                     -- event-contract version

Quickstart::

    from argus import Reporter

    with Reporter("my-run", experiment_type="forecast",
                  source_project="deepts", n_total=2) as r:
        with r.job("j1", model="patchtst", dataset="etth1") as j:
            for ep in range(50):
                j.epoch(ep, train_loss=..., val_loss=...)
                if j.stopped:
                    break
            j.metrics({"MSE": 0.21})
            j.upload("outputs/.../visualizations")
"""
from __future__ import annotations

from .context import (
    JobContext,
    Reporter,
    emit,
    get_batch_id,
    new_batch_id,
    set_batch_id,
    sub_env,
)
from .reporter import ExperimentReporter
from .schema import SCHEMA_VERSION

__all__ = [
    # high-level API
    "Reporter",
    "JobContext",
    "emit",
    "new_batch_id",
    "set_batch_id",
    "get_batch_id",
    "sub_env",
    # low-level compatibility
    "ExperimentReporter",
    "SCHEMA_VERSION",
]
__version__ = "0.1.3"
