"""Deprecated alias for the :mod:`argus` package.

This shim is kept for one minor release cycle (v0.1.x) to ease migration
for users who installed ``experiment-reporter`` and import via
``from experiment_reporter import Reporter``. It will be removed in v0.2.

Update your code::

    -from experiment_reporter import Reporter
    +from argus import Reporter

Importing this module re-exports the entire :mod:`argus` public API and
emits a single :class:`DeprecationWarning` so the rebrand is visible at
runtime without breaking working scripts.
"""
from __future__ import annotations

import warnings

warnings.warn(
    "experiment_reporter is renamed to argus. Update imports to "
    "'from argus import Reporter'. This alias will be removed in v0.2.",
    DeprecationWarning,
    stacklevel=2,
)

from argus import *  # noqa: F401,F403,E402
from argus import (  # noqa: F401,E402
    ExperimentReporter,
    JobContext,
    Reporter,
    SCHEMA_VERSION,
    __version__,
    emit,
    get_batch_id,
    new_batch_id,
    set_batch_id,
    sub_env,
)
