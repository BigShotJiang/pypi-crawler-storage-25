"""Test to verify that operator configurations are properly propagated to metric dependencies."""

from unittest.mock import Mock

from agentops.arg_configs import TestConfig, AuthConfig
from agentops.langfuse_evaluation_package import EvaluationRunner, load_metrics
from agentops.metrics.text_match import TextMatchMetric
from agentops.metrics.keyword_match_metric import KeywordMatchMetric
from agentops.metrics.semantic_match_metric import SemanticMatchMetric
from agentops.prompt import (
    GPT_KEYWORD_MATCHING_PROMPT_PATH,
    GPT_SEMANTIC_MATCHING_PROMPT_V1_PATH,
)


def test_config_propagation_to_dependencies():
    """Test that operator_configs are properly applied to metric dependencies."""
    
    # Create a mock LLM client
    mock_llm_client = Mock()
    
    # Use v1 semantic template as "custom" (different from default v2)
    custom_semantic_path = str(GPT_SEMANTIC_MATCHING_PROMPT_V1_PATH)
    custom_keyword_path = str(GPT_KEYWORD_MATCHING_PROMPT_PATH)
    
    # Create a TestConfig with operator_configs
    config = TestConfig(
        test_paths=["dummy"],
        output_dir="dummy",
        auth_config=AuthConfig(),
        wxo_lite_version="test",
        operator_configs={
            "TextMatchMetric": {
                "semantic_template_path": custom_semantic_path,
                "keyword_template_path": custom_keyword_path,
            }
        }
    )
    
    # Load metrics with configuration
    metrics = load_metrics(
        config=config,
        metrics=["TextMatchMetric"],
        llm_client=mock_llm_client
    )
    
    # Verify we got one metric
    assert len(metrics) == 1
    text_match_metric = metrics[0]
    assert isinstance(text_match_metric, TextMatchMetric)
    
    # Verify the metric has dependencies
    assert len(text_match_metric.dependencies) == 3
    
    # Find the KeywordMatchMetric and SemanticMatchMetric dependencies
    keyword_metric = None
    semantic_metric = None
    
    for dep in text_match_metric.dependencies:
        if isinstance(dep, KeywordMatchMetric):
            keyword_metric = dep
        elif isinstance(dep, SemanticMatchMetric):
            semantic_metric = dep
    
    assert keyword_metric is not None, "KeywordMatchMetric dependency not found"
    assert semantic_metric is not None, "SemanticMatchMetric dependency not found"
    
    # Verify the dependencies were instantiated with the custom template paths
    # KeywordMatchMetric stores the template in keyword_template
    assert hasattr(keyword_metric, 'keyword_template')
    # The template renderer should have been created with the custom path
    # We can't directly check the path, but we can verify it was configured
    
    # SemanticMatchMetric stores the path in prompt_path
    assert hasattr(semantic_metric, 'prompt_path')
    assert semantic_metric.prompt_path == custom_semantic_path
    
    print("✓ Configuration was properly propagated to TextMatchMetric dependencies")


def test_config_propagation_through_scheduler():
    """Test that _scheduler correctly processes dependencies that are already configured.

    Dependencies are configured once at initialization (by their parent metrics),
    and _scheduler simply collects and orders them without re-instantiation.
    """

    # Create a mock LLM client
    mock_llm_client = Mock()

    # Use v1 semantic template as "custom" (different from default v2)
    custom_semantic_path = str(GPT_SEMANTIC_MATCHING_PROMPT_V1_PATH)
    custom_keyword_path = str(GPT_KEYWORD_MATCHING_PROMPT_PATH)

    # Create a TextMatchMetric with custom paths (configured at initialization)
    text_match_metric = TextMatchMetric(
        llm_client=mock_llm_client,
        semantic_template_path=custom_semantic_path,
        keyword_template_path=custom_keyword_path
    )

    # Use _gather to collect dependencies
    # Dependencies should be used as-is since they're already correctly configured
    op_mapping = EvaluationRunner._gather(
        user_metrics=[text_match_metric]
    )
    
    # Find the dependencies in the mapping
    keyword_metric = None
    semantic_metric = None
    
    for op in op_mapping.values():
        if isinstance(op, KeywordMatchMetric):
            keyword_metric = op
        elif isinstance(op, SemanticMatchMetric):
            semantic_metric = op
    
    assert keyword_metric is not None, "KeywordMatchMetric not found in op_mapping"
    assert semantic_metric is not None, "SemanticMatchMetric not found in op_mapping"
    
    # Verify dependencies were collected with their original configuration
    assert semantic_metric.prompt_path == custom_semantic_path, \
        f"Expected {custom_semantic_path}, got {semantic_metric.prompt_path}"
    assert hasattr(keyword_metric, 'keyword_template')
    
    print("✓ _scheduler correctly processes pre-configured dependencies")


def test_llm_client_propagation():
    """Test that llm_client is properly passed through load_metrics to dependencies."""

    # Create a mock LLM client
    mock_llm_client = Mock()
    mock_llm_client.name = "test_client"

    # Use v1 semantic template
    custom_semantic_path = str(GPT_SEMANTIC_MATCHING_PROMPT_V1_PATH)

    # Create a TestConfig with operator_configs
    config = TestConfig(
        test_paths=["dummy"],
        output_dir="dummy",
        auth_config=AuthConfig(),
        wxo_lite_version="test",
        operator_configs={
            "TextMatchMetric": {
                "semantic_template_path": custom_semantic_path,
            }
        }
    )

    # Load metrics with configuration - this is where dependencies get configured
    metrics = load_metrics(
        config=config,
        metrics=["TextMatchMetric"],
        llm_client=mock_llm_client
    )

    text_match_metric = metrics[0]

    # Use _gather to collect dependencies
    op_mapping = EvaluationRunner._gather(
        user_metrics=[text_match_metric]
    )
    
    # Find the SemanticMatchMetric in the mapping
    semantic_metric = None
    for op in op_mapping.values():
        if isinstance(op, SemanticMatchMetric):
            semantic_metric = op
            break
    
    assert semantic_metric is not None
    assert semantic_metric.llm_client is not None
    assert semantic_metric.llm_client.name == "test_client"
    
    print("✓ llm_client was properly propagated to re-instantiated dependencies")


def test_journey_success_metric_with_scheduler():
    """Test the real-world scenario through the full scheduler flow.
    
    This tests that when we configure TextMatchMetric in operator_configs and use the
    full _scheduler method (as done in EvaluationRunner), the configurations are properly
    applied to the entire dependency chain: JourneySuccessMetric -> TextMatchMetric ->
    SemanticMatchMetric/KeywordMatchMetric.
    """
    from agentops.metrics.journey_success import JourneySuccessMetric
    
    # Create a mock LLM client
    mock_llm_client = Mock()
    
    # Use v1 semantic template as "custom" (different from default v2)
    custom_semantic_path = str(GPT_SEMANTIC_MATCHING_PROMPT_V1_PATH)
    custom_keyword_path = str(GPT_KEYWORD_MATCHING_PROMPT_PATH)
    
    # Create a TestConfig with operator_configs for TextMatchMetric
    # This simulates the configuration done in main.py:190
    config = TestConfig(
        test_paths=["dummy"],
        output_dir="dummy",
        auth_config=AuthConfig(),
        wxo_lite_version="test",
        operator_configs={
            "TextMatchMetric": {
                "semantic_template_path": custom_semantic_path,
                "keyword_template_path": custom_keyword_path,
            }
        }
    )
    
    # Load JourneySuccessMetric (which has TextMatchMetric as a dependency)
    metrics = load_metrics(
        config=config,
        metrics=["JourneySuccessMetric"],
        llm_client=mock_llm_client
    )
    
    assert len(metrics) == 1
    journey_metric = metrics[0]
    assert isinstance(journey_metric, JourneySuccessMetric)
    
    # Use the full _scheduler method (as done in EvaluationRunner.__init__)
    # This is the actual code path used in production
    schedule = EvaluationRunner._scheduler(
        metrics=metrics,
        output_dir=None
    )
    
    # The schedule is an ordered dict of operators
    # Find TextMatchMetric and its nested dependencies in the schedule
    text_match_metric = None
    semantic_match_metric = None
    keyword_match_metric = None
    
    for op in schedule.values():
        if isinstance(op, TextMatchMetric):
            text_match_metric = op
        elif isinstance(op, SemanticMatchMetric):
            semantic_match_metric = op
        elif isinstance(op, KeywordMatchMetric):
            keyword_match_metric = op
    
    assert text_match_metric is not None, "TextMatchMetric not found in schedule"
    assert semantic_match_metric is not None, "SemanticMatchMetric not found in schedule"
    assert keyword_match_metric is not None, "KeywordMatchMetric not found in schedule"
    
    # Verify that the nested dependencies were configured with the custom paths
    # This is the key test: configurations should flow through multiple levels via _scheduler
    assert semantic_match_metric.prompt_path == custom_semantic_path, \
        f"Expected {custom_semantic_path}, got {semantic_match_metric.prompt_path}"
    
    # KeywordMatchMetric should have been re-instantiated with the template
    assert hasattr(keyword_match_metric, 'keyword_template')
    
    print("✓ Configuration properly propagated through _scheduler: JourneySuccessMetric -> TextMatchMetric -> nested dependencies")
