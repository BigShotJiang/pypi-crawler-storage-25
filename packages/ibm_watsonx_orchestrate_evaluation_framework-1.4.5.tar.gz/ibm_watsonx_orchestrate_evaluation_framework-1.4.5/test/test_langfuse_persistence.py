"""
Unit tests for LangfusePersistence.
Run with: pytest test/persistence/test_langfuse_persistence.py -v
"""
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import MagicMock, patch

import pytest

from agentops.metrics.metrics import EvaluatorData
from agentops.persistence.langfuse_persistence import LangfusePersistence
from agentops.stats import Result
 

class TestLangfusePersistenceIntegration:
    """Integration test with EvaluationRunner."""

    def _make_evaluator_data(self, eval_name, value):
        return EvaluatorData(
            eval_name=eval_name,
            display_name=eval_name,
            value=value,
            display_value=value,
            metadata={},
        )

    def _make_runner(self, test_cases, messages):
        """Create a minimal EvaluationRunner without triggering __init__ side effects."""
        from agentops.langfuse_evaluation_package import EvaluationRunner

        runner = object.__new__(EvaluationRunner)
        runner.evaluation_name = "test_eval"
        runner.experiment_id = "test-id"
        runner.executor = ThreadPoolExecutor(max_workers=2)
        runner.test_cases = test_cases
        runner.messages = messages
        runner.is_referenceless = False
        runner.session_ids = [f"sid_{i}" for i in range(len(test_cases))]
        runner.experiment_results = None
        return runner

    @patch('agentops.persistence.langfuse_persistence.get_langfuse_client')
    def test_langfuse_persistence_integration(self, mock_get_langfuse_client):
        """Verify that LangfusePersistence is called correctly in full evaluation flow."""
        # Mock the Langfuse client
        mock_client = MagicMock()
        mock_get_langfuse_client.return_value = mock_client

        tc1 = MagicMock()
        tc1.dataset_name = "tc1"
        tc2 = MagicMock()
        tc2.dataset_name = "tc2"

        runner = self._make_runner(
            test_cases=[tc1, tc2],
            messages=[["msg1"], ["msg2"]],
        )
        langfuse_exporter = LangfusePersistence()
        runner.exporters = [langfuse_exporter]

        mock_collection = MagicMock()
        mock_collection.dataset_id.return_value = "123"
        runner.collection = mock_collection

        def mock_evaluate(test_case_name, ground_truth, messages):
            return {test_case_name: [self._make_evaluator_data("accuracy", 0.9)]}

        runner._evaluate = mock_evaluate
        result = runner.evaluate()

        # Verify the mock client's create_score was called
        assert mock_client.create_score.called
        
        # Verify it was called for both per_dataset and overall metrics
        calls = mock_client.create_score.call_args_list
        assert len(calls) > 0
        
        # Check that metrics were persisted with correct structure
        for call in calls:
            assert 'name' in call[1]
            assert 'value' in call[1]
            assert 'data_type' in call[1]
            assert 'metadata' in call[1]

        # Verify aggregated metrics were persisted
        agg_metric_args = calls[-1][1]
        assert agg_metric_args["name"] == "Average accuracy"
        assert agg_metric_args["value"] == 0.9 