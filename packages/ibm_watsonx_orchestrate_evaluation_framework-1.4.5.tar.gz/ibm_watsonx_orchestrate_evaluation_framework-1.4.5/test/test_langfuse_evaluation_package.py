from dataclasses import asdict
from types import SimpleNamespace
from unittest.mock import MagicMock, Mock, patch

import pytest
import tempfile

from agentops.arg_configs import AuthConfig, TestConfig
import os
from agentops.extractors import Extractor
from agentops.langfuse_evaluation_package import (
    EvaluationRunner,
    load_metrics,
)
from agentops.metrics.dummy_metric import DummyMetric
from agentops.metrics.evaluations import Evaluation
from agentops.metrics.metrics import EvaluatorData
from agentops.utils.telemetry_platform import TelemetryPlatform
from agentops.collection import LangfuseCollection
from agentops.type import TestCase


class ConfigurableDummyMetric(Evaluation):
    def __init__(self, param=None, llm_client=None):
        super().__init__(llm_client)
        self.param = param

    def do_evaluate(self, messages, ground_truth=None, metadata=None, **kwargs):
        return EvaluatorData(eval_name="configurable_dummy", value=True, metadata=metadata)

@pytest.fixture(autouse=True)
def temp_output_dir():
    with tempfile.TemporaryDirectory(prefix="test_langfuse_evaluation_package_") as tmpdir:
        yield tmpdir

class TestMetricLoading:
    def setup_method(self):
        # Patch metric_pkg
        self.metric_pkg_patcher = patch(
            "agentops.langfuse_evaluation_package.metric_pkg",
            new=SimpleNamespace())
        
        self.mock_metric_pkg = self.metric_pkg_patcher.start()
        self.mock_metric_pkg.ValidMetric = ConfigurableDummyMetric

    def test_load_metric(self):
        config = TestConfig(
            test_paths=[],
            output_dir="path",
            auth_config=AuthConfig(),
            wxo_lite_version="1",
            operator_configs={"ValidMetric": {"param": "value"}},
        )
        evaluators = load_metrics(config, ["ValidMetric"], llm_client=None)

        assert len(evaluators) == 1
        assert isinstance(evaluators[0], ConfigurableDummyMetric)
        assert evaluators[0].param == "value"
