import json
from unittest.mock import MagicMock, patch

import pytest

from agentops.record.data_annotator import DataAnnotator
from agentops.type import ContentType, Message, TestCase


class TestDataAnnotator:
    """Test suite for DataAnnotator class"""

    @pytest.fixture
    def mock_provider(self):
        """Create a mock provider"""
        provider = MagicMock()
        provider.generate.return_value = "mocked response"
        return provider

    @pytest.fixture
    def basic_messages(self):
        """Create basic test messages"""
        return [
            Message(
                role="user",
                content="Hello, I need help with my account",
                type=ContentType.text,
            ),
            Message(
                role="assistant",
                content="I'll help you with that",
                type=ContentType.text,
            ),
        ]

    @pytest.fixture
    def messages_with_tool_calls(self):
        """Create messages with tool calls"""
        return [
            Message(
                role="user",
                content="Get user info for user123",
                type=ContentType.text,
            ),
            Message(
                role="assistant",
                content=json.dumps({
                    "tool_call_id": "call_1",
                    "id": "call_1",
                    "name": "get_user_info",
                    "args": {"user_id": "user123"},
                }),
                type=ContentType.tool_call,
            ),
            Message(
                role="tool",
                content=json.dumps({
                    "tool_call_id": "call_1",
                    "content": json.dumps({"name": "John Doe", "email": "john@example.com"}),
                }),
                type=ContentType.tool_response,
            ),
            Message(
                role="assistant",
                content="The user's name is John Doe and email is john@example.com",
                type=ContentType.text,
            ),
        ]

    def test_get_starting_sentence_from_first_message_string(self, basic_messages):
        """Test that starting_sentence is extracted from first message when content is string"""
        annotator = DataAnnotator(messages=basic_messages)
        starting_sentence = annotator._get_starting_sentence()
        
        assert starting_sentence == "Hello, I need help with my account"

    def test_get_starting_sentence_from_first_message_dict(self):
        """Test that starting_sentence is extracted from first message when content is dict"""
        messages = [
            Message(
                role="user",
                content={"text": "Hello world", "metadata": "test"},
                type=ContentType.text,
            ),
        ]
        annotator = DataAnnotator(messages=messages)
        starting_sentence = annotator._get_starting_sentence()
        
        # Should convert dict to string
        assert "Hello world" in starting_sentence or "text" in starting_sentence

    def test_get_starting_sentence_fallback_to_initial_data(self):
        """Test that starting_sentence falls back to initial_data when no messages"""
        from agentops.type import GoalDetailOrchestrate
        
        initial_data = TestCase(
            story="Test story",
            starting_sentence="Initial starting sentence",
            goals={"summarize": []},
            goal_details=[
                GoalDetailOrchestrate(
                    name="summarize",
                    type=ContentType.text,
                    response="test response",
                )
            ],
        )
        annotator = DataAnnotator(messages=[], initial_data=initial_data)
        starting_sentence = annotator._get_starting_sentence()
        
        assert starting_sentence == "Initial starting sentence"

    def test_get_starting_sentence_empty_messages(self):
        """Test that starting_sentence returns empty string when no messages and no initial_data"""
        annotator = DataAnnotator(messages=[])
        starting_sentence = annotator._get_starting_sentence()
        
        assert starting_sentence == ""

    def test_get_starting_sentence_prefers_message_over_initial_data(self, basic_messages):
        """Test that starting_sentence prefers first message over initial_data"""
        from agentops.type import GoalDetailOrchestrate
        
        initial_data = TestCase(
            story="Test story",
            starting_sentence="Initial starting sentence",
            goals={"summarize": []},
            goal_details=[
                GoalDetailOrchestrate(
                    name="summarize",
                    type=ContentType.text,
                    response="test response",
                )
            ],
        )
        annotator = DataAnnotator(messages=basic_messages, initial_data=initial_data)
        starting_sentence = annotator._get_starting_sentence()
        
        # Should use message content, not initial_data
        assert starting_sentence == "Hello, I need help with my account"
        assert starting_sentence != "Initial starting sentence"

    @patch("agentops.record.data_annotator.get_provider")
    def test_generate_includes_starting_sentence_from_message(
        self, mock_get_provider, basic_messages, mock_provider
    ):
        """Test that generate() includes starting_sentence from first message"""
        mock_get_provider.return_value = mock_provider
        
        # Mock the generators to avoid actual LLM calls
        annotator = DataAnnotator(messages=basic_messages)
        annotator._kw_generator = MagicMock()
        annotator._kw_generator.generate.return_value = ["keyword1", "keyword2"]
        annotator._summary_generator = MagicMock()
        annotator._summary_generator.generate.return_value = "Test summary"
        annotator._arg_matching_generator = MagicMock()
        annotator._arg_matching_generator.generate_arg_matching.return_value = []
        
        result = annotator.generate()
        
        assert "starting_sentence" in result
        assert result["starting_sentence"] == "Hello, I need help with my account"

    @patch("agentops.record.data_annotator.get_provider")
    def test_generate_with_tool_calls(
        self, mock_get_provider, messages_with_tool_calls, mock_provider
    ):
        """Test generate() with tool calls"""
        mock_get_provider.return_value = mock_provider
        
        annotator = DataAnnotator(messages=messages_with_tool_calls)
        annotator._kw_generator = MagicMock()
        annotator._kw_generator.generate.return_value = ["keyword1"]
        annotator._summary_generator = MagicMock()
        annotator._summary_generator.generate.return_value = "Summary"
        annotator._arg_matching_generator = MagicMock()
        annotator._arg_matching_generator.generate_arg_matching.return_value = [{}]
        
        result = annotator.generate()
        
        assert "starting_sentence" in result
        assert result["starting_sentence"] == "Get user info for user123"
        assert "goals" in result
        assert "goal_details" in result
        assert len(result["goal_details"]) > 0

    def test_is_error_in_message(self):
        """Test error detection in messages"""
        assert DataAnnotator._is_error_in_message("Error: something went wrong")
        assert DataAnnotator._is_error_in_message("Failed to process")
        assert DataAnnotator._is_error_in_message("Exception occurred")
        assert not DataAnnotator._is_error_in_message("Success")
        assert not DataAnnotator._is_error_in_message("Completed successfully")

    def test_get_failed_tool_responses(self):
        """Test identification of failed tool responses"""
        messages = [
            Message(
                role="tool",
                content=json.dumps({
                    "tool_call_id": "call_1",
                    "content": json.dumps({
                        "is_success": False,
                        "error_details": "Tool execution failed",
                    }),
                }),
                type=ContentType.tool_response,
            ),
            Message(
                role="tool",
                content=json.dumps({
                    "tool_call_id": "call_2",
                    "content": json.dumps({"is_success": True, "data": "success"}),
                }),
                type=ContentType.tool_response,
            ),
        ]
        
        annotator = DataAnnotator(messages=messages)
        failed_ids = annotator._get_failed_tool_responses()
        
        assert "call_1" in failed_ids
        assert "call_2" not in failed_ids

    @patch("agentops.record.data_annotator.get_provider")
    def test_lazy_initialization_of_generators(self, mock_get_provider, basic_messages, mock_provider):
        """Test that generators are lazily initialized"""
        mock_get_provider.return_value = mock_provider
        
        annotator = DataAnnotator(messages=basic_messages)
        
        # Generators should be None initially
        assert annotator._kw_generator is None
        assert annotator._summary_generator is None
        assert annotator._arg_matching_generator is None
        
        # Access properties to trigger lazy initialization
        _ = annotator.kw_generator
        assert annotator._kw_generator is not None
        
        _ = annotator.summary_generator
        assert annotator._summary_generator is not None
        
        _ = annotator.arg_matching_generator
        assert annotator._arg_matching_generator is not None

    def test_generate_with_empty_messages_and_initial_data(self):
        """Test generate with empty messages but with initial_data"""
        from agentops.type import GoalDetailOrchestrate
        
        initial_data = TestCase(
            agent="test_agent",
            story="Test story",
            starting_sentence="From initial data",
            goals={"summarize": []},
            goal_details=[
                GoalDetailOrchestrate(
                    name="summarize",
                    type=ContentType.text,
                    response="test response",
                )
            ],
        )
        
        annotator = DataAnnotator(messages=[], initial_data=initial_data)
        annotator._kw_generator = MagicMock()
        annotator._kw_generator.generate.return_value = []
        annotator._summary_generator = MagicMock()
        annotator._summary_generator.generate.return_value = None
        annotator._arg_matching_generator = MagicMock()
        annotator._arg_matching_generator.generate_arg_matching.return_value = []
        
        result = annotator.generate()
        
        assert result["starting_sentence"] == "From initial data"
        assert result["agent"] == "test_agent"
        assert result["story"] == "Test story"

    def test_process_tool_call_order_skips_failed_calls(self):
        """Test that failed tool calls are skipped in processing"""
        messages = [
            Message(
                role="assistant",
                content=json.dumps({
                    "tool_call_id": "call_1",
                    "id": "call_1",
                    "name": "tool1",
                    "args": {"param": "value1"},
                }),
                type=ContentType.tool_call,
            ),
            Message(
                role="tool",
                content=json.dumps({
                    "tool_call_id": "call_1",
                    "content": json.dumps({"is_success": False}),
                }),
                type=ContentType.tool_response,
            ),
            Message(
                role="assistant",
                content=json.dumps({
                    "tool_call_id": "call_2",
                    "id": "call_2",
                    "name": "tool2",
                    "args": {"param": "value2"},
                }),
                type=ContentType.tool_call,
            ),
            Message(
                role="tool",
                content=json.dumps({
                    "tool_call_id": "call_2",
                    "content": json.dumps({"is_success": True}),
                }),
                type=ContentType.tool_response,
            ),
        ]
        
        annotator = DataAnnotator(messages=messages)
        wrong_ids = annotator._get_failed_tool_responses()
        order = annotator._process_tool_call_order(wrong_ids)
        
        # Only call_2 should be in the order (call_1 failed)
        assert len(order) == 1
        assert "tool2" in order[0]
        assert "tool1" not in order[0]

# Made with Bob

import json
from unittest.mock import MagicMock, patch

import pytest

from agentops.record.data_annotator import DataAnnotator
from agentops.type import ContentType, Message, TestCase


class TestExtractObjectKeyFromUrl:
    """Test cases for _extract_object_key_from_url method"""
    
    def test_extract_object_key_standard_s3_url(self):
        """Test extraction from standard S3/MinIO URL with query parameters"""
        annotator = DataAnnotator(messages=[])
        url = "http://host.docker.internal:9000/wxo-server-storage-bucket/uploaded_files/e67e04b3-3222-420c-9ea0-269a70ed1f43/sample-id.txt?AWSAccessKeyId=minioadmin&Signature=itwMUecnbZC7%2Fg9Ydk%2BmzMnQ6vg%3D&Expires=1772838092"
        
        result = annotator._extract_object_key_from_url(url)
        
        assert result == "uploaded_files/e67e04b3-3222-420c-9ea0-269a70ed1f43/sample-id.txt"
    
    def test_extract_object_key_without_query_params(self):
        """Test extraction from URL without query parameters"""
        annotator = DataAnnotator(messages=[])
        url = "http://host.docker.internal:9000/wxo-server-storage-bucket/uploaded_files/abc123/employee-id.txt"
        
        result = annotator._extract_object_key_from_url(url)
        
        assert result == "uploaded_files/abc123/employee-id.txt"
    
    def test_extract_object_key_nested_path(self):
        """Test extraction from URL with deeply nested path"""
        annotator = DataAnnotator(messages=[])
        url = "https://s3.amazonaws.com/my-bucket/folder1/folder2/folder3/document.pdf?token=xyz"
        
        result = annotator._extract_object_key_from_url(url)
        
        assert result == "folder1/folder2/folder3/document.pdf"
    
    def test_extract_object_key_simple_path(self):
        """Test extraction from URL with simple path"""
        annotator = DataAnnotator(messages=[])
        url = "http://localhost:9000/bucket/file.txt"
        
        result = annotator._extract_object_key_from_url(url)
        
        assert result == "file.txt"
    
    def test_extract_object_key_empty_url(self):
        """Test extraction from empty URL"""
        annotator = DataAnnotator(messages=[])
        
        result = annotator._extract_object_key_from_url("")
        
        assert result == ""
    
    def test_extract_object_key_only_bucket(self):
        """Test extraction from URL with only bucket name"""
        annotator = DataAnnotator(messages=[])
        url = "http://localhost:9000/bucket/"
        
        result = annotator._extract_object_key_from_url(url)
        
        assert result == ""
    
    def test_extract_object_key_malformed_url(self):
        """Test extraction from malformed URL"""
        annotator = DataAnnotator(messages=[])
        url = "not-a-valid-url"
        
        result = annotator._extract_object_key_from_url(url)
        
        # Should handle gracefully and return empty string
        assert result == ""

