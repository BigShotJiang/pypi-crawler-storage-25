"""Unit tests for quick_eval.py."""

import json 
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch
 
from agentops.quick_eval import process_test_case 

class TestQuickEvalTestCaseLoading:
    """Test that ReferencelessTestCase can load test cases with empty goals and goal_details."""
    test_case_data = {
        "agent": "hr_agent",
        "goals": {},
        "goal_details": [],
        "story": "I want to get my user ID.",
        "starting_sentence": "I want to know my user ID.",
    }

    @patch("agentops.quick_eval.QuickEvalController")
    def test_loading_test_case(self, mock_controller):
 

        with tempfile.TemporaryDirectory() as temp_dir: 
             
            file_path = temp_dir + "/test.json" 
            with open(file_path, "w") as f:
                json.dump(self.test_case_data, f) 
 
            mock_config = MagicMock()
            mock_config.output_dir = tempfile.gettempdir()  
            mock_summary = MagicMock()
            mock_summary.model_dump.return_value = {}
 
            mock_controller.return_value.run.return_value = []
            mock_controller.return_value.generate_summary.return_value = (
                mock_summary, []
            )

            process_test_case(
                0, file_path, mock_config, MagicMock(), MagicMock(), []
            ) 