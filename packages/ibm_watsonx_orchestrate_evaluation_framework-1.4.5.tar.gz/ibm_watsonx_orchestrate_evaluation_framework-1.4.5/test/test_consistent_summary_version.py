import pytest

from agentops.type import (
    ContentType,
    DatasetSummaryStepVersion,
    GoalDetail,
    TestCase,
)

# @pytest.fixture(autouse=True)
def make_testcase(goals, goal_details) -> TestCase:
    """Create a TestCase where each goal_detail has the given summary value."""

    return TestCase(
        story="test",
        goals=goals,
        goal_details=goal_details,
    )


class TestConsistentSummaryVersion:
    def test_all_v1_returns_v1(self):
        datasets = [
            make_testcase(goals={"summarize": []}, goal_details=[GoalDetail(name="summarize", type=ContentType.text, summary=None, response="dummy response 1")]),
            make_testcase(goals={"summarize": []}, goal_details=[GoalDetail(name="summarize", type=ContentType.text, summary=None, response="dummy response 2")]),
            make_testcase(goals={"summarize": []}, goal_details=[GoalDetail(name="summarize", type=ContentType.text, summary=None, response="dummy response 3")]),
        ]
        result = TestCase.consistent_summary_version(datasets)
        assert result == DatasetSummaryStepVersion.v1

    def test_all_v2_returns_v2(self):
        datasets = [
            make_testcase(goals={"summarize": []}, goal_details=[GoalDetail(name="summarize", type=ContentType.text, summary="summary 1", response=None)]),
            make_testcase(goals={"summarize": []}, goal_details=[GoalDetail(name="summarize", type=ContentType.text, summary="summary 2", response=None)]),
            make_testcase(goals={"summarize": []}, goal_details=[GoalDetail(name="summarize", type=ContentType.text, summary="summary 3", response=None)]),
        ]
        result = TestCase.consistent_summary_version(datasets)
        assert result == DatasetSummaryStepVersion.v2

    def test_v2_and_no_summary_returns_v2(self):
        datasets = [
            make_testcase(goals={"summarize": []}, goal_details=[GoalDetail(name="summarize", type=ContentType.text, summary="summary", response=None)]),
            make_testcase(goals={"tool_call_1": []}, goal_details=[GoalDetail(name="tool_call_1", type=ContentType.tool_call)]),
        ]
        result = TestCase.consistent_summary_version(datasets)
        assert result == DatasetSummaryStepVersion.v2

    def test_all_no_summary_returns_v1(self):
        datasets = [
            make_testcase(goals={"tool_call1": []}, goal_details=[GoalDetail(name="tool_call1", type=ContentType.tool_call)]),
            make_testcase(goals={"tool_call2": []}, goal_details=[GoalDetail(name="tool_call2", type=ContentType.tool_call)]),
        ]
        result = TestCase.consistent_summary_version(datasets)
        assert result == DatasetSummaryStepVersion.v1

    def test_v1_and_v2_raises_value_error(self):
        datasets = [
            make_testcase(goals={"summarize": []}, goal_details=[GoalDetail(name="summarize", type=ContentType.text, summary="dummy summary", response=None)]),
            make_testcase(goals={"summarize": []}, goal_details=[GoalDetail(name="summarize", type=ContentType.text, response="dummy response")]),
        ]
        with pytest.raises(ValueError, match="Mixed dataset summary versions"):
            TestCase.consistent_summary_version(datasets)