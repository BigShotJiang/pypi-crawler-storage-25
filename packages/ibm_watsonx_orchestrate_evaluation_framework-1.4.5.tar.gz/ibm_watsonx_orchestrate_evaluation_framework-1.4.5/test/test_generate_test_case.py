"""
Unit tests for generate_test_case_from_messages function.
"""
import pytest
from unittest.mock import MagicMock, patch, PropertyMock
from agentops.record.generate_test_case import generate_test_case_from_messages
from agentops.type import Message, ContentType
from agentops.arg_configs import ProviderConfig
from agentops.record.data_annotator import DataAnnotator

@pytest.fixture
def provider_config():
    """Fixture providing a ProviderConfig for testing"""
    return ProviderConfig(
        model_id="smart",
        provider="fake"
    )


@pytest.fixture
def sample_messages():
    """Fixture providing sample messages as Message objects"""
    return [
        Message(
            role="user",
            content="Book a flight from New York to London",
            type=ContentType.text,
        ),
        Message(
            role="assistant",
            content='{"name": "search_flights", "args": {"origin": "NYC", "destination": "LON"}, "tool_call_id": "call_1"}',
            type=ContentType.tool_call,
        ),
        Message(
            role="tool",
            content='{"tool_call_id": "call_1", "content": "Found 5 flights"}',
            type=ContentType.tool_response,
        ),
        Message(
            role="assistant",
            content="I found 5 flights from New York to London.",
            type=ContentType.text,
        ),
    ]




@patch("agentops.record.generate_test_case.generate_story")
@patch("agentops.record.generate_test_case.DataAnnotator")
def test_generate_test_case_basic(mock_annotator_class, mock_story_gen, provider_config, sample_messages):
    """Test basic functionality with Message objects"""
    # Setup mocks
    mock_annotator_instance = MagicMock()
    mock_annotator_instance.generate.return_value = {
        "goals": {"search_flights": []},
        "goal_details": [
            {
                "name": "search_flights",
                "type": "tool_call",
                "tool_name": "search_flights",
                "args": {"origin": "NYC", "destination": "LON"},
            }
        ],
        "starting_sentence": "Book a flight from New York to London",
    }
    mock_annotator_instance._extract_file_upload_info.return_value = None
    mock_annotator_class.return_value = mock_annotator_instance
    mock_story_gen.return_value = "User wants to book a flight"
    
    result = generate_test_case_from_messages(
        messages=sample_messages,
        agent_name="travel_agent",
        provider_config=provider_config,
    )
    
    # Verify result is a TestCase instance
    from agentops.type import TestCase
    assert isinstance(result, TestCase)
    
    # Verify values using Pydantic model attributes
    assert result.agent == "travel_agent"
    assert result.story == "User wants to book a flight"
    assert result.starting_sentence == "Book a flight from New York to London"
    assert "search_flights" in result.goals
    assert len(result.goal_details) == 1


@patch("agentops.record.generate_test_case.generate_story")
@patch("agentops.record.generate_test_case.DataAnnotator")
def test_generate_test_case_preserves_goal_structure(mock_annotator_class, mock_story_gen, provider_config):
    """Test that goal structure from DataAnnotator is preserved"""
    # Setup mocks
    mock_annotator_instance = MagicMock()
    mock_annotator_instance.generate.return_value = {
        "goals": {
            "goal1": ["goal2"],
            "goal2": ["goal3"],
            "goal3": [],
        },
        "goal_details": [
            {"name": "goal1", "type": "tool_call"},
            {"name": "goal2", "type": "tool_call"},
            {"name": "goal3", "type": "tool_call"},
        ],
        "starting_sentence": "Start",
    }
    mock_annotator_instance._extract_file_upload_info.return_value = None
    mock_annotator_class.return_value = mock_annotator_instance
    mock_story_gen.return_value = "Story"
    
    result = generate_test_case_from_messages(
        messages=[Message(role="user", content="test", type=ContentType.text)],
        agent_name="test_agent",
        provider_config=provider_config,
    )
    
    # Verify goal structure is preserved using Pydantic model attributes
    assert result.goals == {
        "goal1": ["goal2"],
        "goal2": ["goal3"],
        "goal3": [],
    }
    assert len(result.goal_details) == 3

@patch("agentops.record.generate_test_case.generate_story")
@patch("agentops.record.data_annotator.KeywordsGenerationLLM")
def test_generate_test_case_goals_and_goal_details_integration(
    mock_keywords_llm, mock_story_gen, provider_config
):
    """Integration test that goals and goal_details are properly generated from actual DataAnnotator"""
    
    # Mock only the provider-dependent parts (keyword generation and story generation)
    mock_keywords_instance = MagicMock()
    mock_keywords_instance.generate.return_value = ["flight", "booking", "travel"]
    mock_keywords_llm.return_value = mock_keywords_instance
    
    mock_story_gen.return_value = "User wants to book a flight from NYC to London"
    
    # Create messages with tool calls that should generate goals
    messages = [
        Message(role="user", content="Book a flight from NYC to London", type=ContentType.text),
        Message(
            role="assistant",
            content='{"name": "search_flights", "args": {"origin": "NYC", "destination": "LON"}, "tool_call_id": "call_1"}',
            type=ContentType.tool_call,
        ),
        Message(
            role="tool",
            content='{"tool_call_id": "call_1", "content": "Found flights"}',
            type=ContentType.tool_response,
        ),
        Message(
            role="assistant",
            content='{"name": "book_flight", "args": {"flight_id": "FL123"}, "tool_call_id": "call_2"}',
            type=ContentType.tool_call,
        ),
        Message(
            role="tool",
            content='{"tool_call_id": "call_2", "content": "Booked successfully"}',
            type=ContentType.tool_response,
        ),
        Message(
            role="assistant",
            content="Your flight has been booked successfully!",
            type=ContentType.text,
        ),
    ]
    
    # Call the actual function - DataAnnotator.generate() will run for real
    result = generate_test_case_from_messages(
        messages=messages,
        agent_name="travel_agent",
        provider_config=provider_config,
    )
    
    # Verify result is a TestCase instance
    from agentops.type import TestCase
    assert isinstance(result, TestCase)
    
    # Verify goals structure exists and is a dict using Pydantic model attributes
    assert isinstance(result.goals, dict)
    
    # Verify goal_details structure exists and is a list
    assert isinstance(result.goal_details, list)
    assert len(result.goal_details) >= 2, "Should have at least 2 tool calls"
    
    # Verify each goal detail has required fields
    for goal_detail in result.goal_details:
        assert goal_detail.name is not None
        assert goal_detail.type is not None
        # Tool calls should have tool_name and args
        if goal_detail.type == "tool_call":
            assert goal_detail.tool_name is not None
            assert goal_detail.args is not None
            assert isinstance(goal_detail.args, dict)
    
    # Verify we captured the tool calls from messages
    tool_names = [gd.tool_name for gd in result.goal_details if gd.type == "tool_call"]
    assert "search_flights" in tool_names
    assert "book_flight" in tool_names

@patch("agentops.record.generate_test_case.generate_story")
@patch("agentops.record.data_annotator.KeywordsGenerationLLM")
def test_generate_test_case_file_upload_integration(mock_keywords_llm, mock_story_gen, provider_config):
    """Integration test for file upload extraction with real DataAnnotator"""
    # Mock only the provider-dependent parts
    mock_keywords_instance = MagicMock()
    mock_keywords_instance.generate.return_value = ["file", "upload", "employee"]
    mock_keywords_llm.return_value = mock_keywords_instance
    
    mock_story_gen.return_value = "User uploads employee ID to check time off"
    
    # Create messages with file upload content (similar to the example provided)
    messages = [
        Message(role="user", content="i want to know my time off schedule", type=ContentType.text),
        Message(
            role="assistant",
            content={
                "response_type": "file_upload",
                "id": "1",
                "text": "Please upload your employee ID",
                "uploadSettings": {
                    "maxFilesPerUpload": 10,
                    "allowedFileMimeTypes": {"txt": ["text/plain"]},
                },
            },
            type=ContentType.text,
        ),
        Message(
            role="user",
            content='{"response_type": "file_download", "files": [{"fileName": "employee-id.txt", "url": "http://host.docker.internal:9000/wxo-server-storage-bucket/uploaded_files/abc123/employee-id.txt", "uploadStatus": "complete"}]}',
            type=ContentType.text,
        ),
        Message(
            role="assistant",
            content='{"name": "verify_employee", "args": {"file": "employee-id.txt"}, "tool_call_id": "call_1"}',
            type=ContentType.tool_call,
        ),
        Message(
            role="tool",
            content='{"tool_call_id": "call_1", "content": "Verified"}',
            type=ContentType.tool_response,
        ),
        Message(role="assistant", content="Employee verified successfully", type=ContentType.text),
    ]
    
    # Call the actual function
    result = generate_test_case_from_messages(
        messages=messages,
        agent_name="hr_agent",
        provider_config=provider_config,
    )
    
    # Verify result is a TestCase instance
    from agentops.type import TestCase
    assert isinstance(result, TestCase)
    
    # Verify file_upload field was extracted
    assert result.file_upload is not None
    assert "file_name" in result.file_upload
    assert "url" in result.file_upload
    assert "object_key" in result.file_upload
    
    # Verify the content
    assert result.file_upload["file_name"] == "employee-id.txt"
    assert "uploaded_files/abc123/employee-id.txt" in result.file_upload["object_key"]


@patch("agentops.record.generate_test_case.generate_story")
@patch("agentops.record.data_annotator.KeywordsGenerationLLM")
def test_generate_test_case_chat_with_collaborator_ignored(
    mock_keywords_llm, mock_story_gen, provider_config
):
    """Test that chat_with_collaborator_ tools have all args set to ignore."""
    from agentops.type import MatchingStrategy
    from agentops.generators import ArgMatchingGenerationLLM
    
    # Mock the keywords generator
    mock_keywords_instance = MagicMock()
    mock_keywords_instance.generate.return_value = ["chat", "collaborator", "help"]
    mock_keywords_llm.return_value = mock_keywords_instance
    
    # Create a real ArgMatchingGenerationLLM with a mock provider
    mock_provider = MagicMock()
    mock_response = MagicMock()
    mock_response.choices = [MagicMock()]
    # Return strict for regular tools (simulating LLM response)
    mock_response.choices[0].message.content = '[{"idx": 2, "title": "strict", "assignee": "strict"}]'
    mock_provider.chat.return_value = mock_response
    
    # Create real generator with mock provider
    from agentops.prompt.template_render import ArgMatchingGenerationTemplateRenderer
    from agentops.arg_configs import ArgMatchingGenerationConfig
    real_generator = ArgMatchingGenerationLLM(
        provider=mock_provider,
        template=ArgMatchingGenerationTemplateRenderer(ArgMatchingGenerationConfig().prompt_config),
        batch_size=10,
        max_workers=4
    )
    
    mock_story_gen.return_value = "User chats with collaborators and creates a task"
    
    # Create messages with chat_with_collaborator_ tools and regular tools
    messages = [
        Message(role="user", content="Can you help me with this task?", type=ContentType.text),
        Message(
            role="assistant",
            content='{"name": "chat_with_collaborator_alice", "args": {"message": "Can you review this?", "priority": "high"}, "tool_call_id": "call_1"}',
            type=ContentType.tool_call,
        ),
        Message(
            role="tool",
            content='{"tool_call_id": "call_1", "content": "Sure, I will review it"}',
            type=ContentType.tool_response,
        ),
        Message(
            role="assistant",
            content='{"name": "chat_with_collaborator_bob", "args": {"text": "Please help", "context": {"project": "X"}}, "tool_call_id": "call_2"}',
            type=ContentType.tool_call,
        ),
        Message(
            role="tool",
            content='{"tool_call_id": "call_2", "content": "I can help"}',
            type=ContentType.tool_response,
        ),
        Message(
            role="assistant",
            content='{"name": "create_task", "args": {"title": "Review code", "assignee": "alice"}, "tool_call_id": "call_3"}',
            type=ContentType.tool_call,
        ),
        Message(
            role="tool",
            content='{"tool_call_id": "call_3", "content": "Task created"}',
            type=ContentType.tool_response,
        ),
        Message(
            role="assistant",
            content="I've coordinated with the team and created the task.",
            type=ContentType.text,
        ),
    ]
    
    # Patch the DataAnnotator to use our real generator with mock provider
    with patch.object(
        DataAnnotator,
        'arg_matching_generator',
        new_callable=PropertyMock,
        return_value=real_generator
    ):
        # Call the actual function
        result = generate_test_case_from_messages(
            messages=messages,
            agent_name="team_coordinator",
            provider_config=provider_config,
        )
        
        # Verify result is a TestCase instance
        from agentops.type import TestCase, MatchingStrategy
        assert isinstance(result, TestCase)
        
        # Verify we have 4 goal_details (3 tool calls + 1 summarize)
        assert len(result.goal_details) == 4
        
        # Find the chat_with_collaborator tools and regular tool
        chat_alice = None
        chat_bob = None
        create_task = None
        
        for goal_detail in result.goal_details:
            if goal_detail.tool_name == "chat_with_collaborator_alice":
                chat_alice = goal_detail
            elif goal_detail.tool_name == "chat_with_collaborator_bob":
                chat_bob = goal_detail
            elif goal_detail.tool_name == "create_task":
                create_task = goal_detail
        
        # Verify all three tools were found
        assert chat_alice is not None, "chat_with_collaborator_alice not found"
        assert chat_bob is not None, "chat_with_collaborator_bob not found"
        assert create_task is not None, "create_task not found"
        
        # Verify chat_with_collaborator_ tools have all args set to ignore
        # These should ALWAYS have arg_matching populated with ignore values
        assert chat_alice.arg_matching is not None, "chat_alice should have arg_matching"
        assert len(chat_alice.arg_matching) > 0, "chat_alice arg_matching should not be empty"
        assert chat_alice.arg_matching == {
            "message": MatchingStrategy.ignore,
            "priority": MatchingStrategy.ignore
        }, f"Expected all args to be ignore for chat_alice, got {chat_alice.arg_matching}"

        assert chat_bob.arg_matching is not None, "chat_bob should have arg_matching"
        assert len(chat_bob.arg_matching) > 0, "chat_bob arg_matching should not be empty"
        assert chat_bob.arg_matching == {
            "text": MatchingStrategy.ignore,
            "context": MatchingStrategy.ignore
        }, f"Expected all args to be ignore for chat_bob, got {chat_bob.arg_matching}"
        
        # For the regular tool, verify it has arg_matching and it's NOT all ignore
        assert create_task.arg_matching is not None, "create_task should have arg_matching"
        assert len(create_task.arg_matching) > 0, "create_task arg_matching should not be empty"
        arg_values = set(create_task.arg_matching.values())
        # The regular tool should have strict (fallback) or other strategies, but NOT all ignore
        assert arg_values != {MatchingStrategy.ignore}, \
            f"Regular tool should not have all args as ignore, got {create_task.arg_matching}"


