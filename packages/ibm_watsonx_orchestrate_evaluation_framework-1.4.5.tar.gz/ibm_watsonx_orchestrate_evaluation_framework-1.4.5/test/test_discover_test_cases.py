import os
from pathlib import Path

import pytest

from src.agentops.scheduler import discover_tests


class TestDiscoverTests:
    def _create_test_directory_structure(self, tmp_path):
        """
        Create a temporary directory structure for testing with the following layout:
        
        tmp_path/
        ├── test1.json
        ├── test2.json
        ├── agent.json (should be ignored)
        ├── not_json.txt (should be ignored)
        ├── subdir1/
        │   ├── test3.json
        │   └── test4.json
        └── subdir2/
            └── nested/
                └── test5.json
        """
        # Create files at the top level
        (tmp_path / "test1.json").write_text('{"test": "1"}')
        (tmp_path / "test2.json").write_text('{"test": "2"}')
        (tmp_path / "agent.json").write_text('{"agent": "config"}')
        (tmp_path / "not_json.txt").write_text("not a json file")
        
        # Create subdirectory 1 with files
        subdir1 = tmp_path / "subdir1"
        subdir1.mkdir()
        (subdir1 / "test3.json").write_text('{"test": "3"}')
        (subdir1 / "test4.json").write_text('{"test": "4"}')
        
        # Create nested subdirectory with a file
        nested_dir = tmp_path / "subdir2" / "nested"
        nested_dir.mkdir(parents=True)
        (nested_dir / "test5.json").write_text('{"test": "5"}')
        
        return tmp_path
    
    def test_non_recursive_search(self, tmp_path, monkeypatch):
        """Test that non-recursive search only finds files at the top level."""
        # Disable rich_print to avoid output during tests
        monkeypatch.setattr("rich.print", lambda *args, **kwargs: None)
        
        # Create test directory structure
        test_dir = self._create_test_directory_structure(tmp_path)
        
        # Run discover_tests with recursive_search=False
        test_cases = discover_tests([str(test_dir)], recursive_search=False)
        
        # Should only find the 2 JSON files at the top level (excluding agent.json)
        assert len(test_cases) == 2
        
        # Check that only top-level files are found
        test_files = [os.path.basename(tc) for tc in test_cases]
        assert "test1.json" in test_files
        assert "test2.json" in test_files
        assert "test3.json" not in test_files  # Should not find files in subdirectories
        assert "test5.json" not in test_files  # Should not find files in nested subdirectories
    
    def test_recursive_search(self, tmp_path, monkeypatch):
        """Test that recursive search finds files in subdirectories."""
        # Disable rich_print to avoid output during tests
        monkeypatch.setattr("rich.print", lambda *args, **kwargs: None)
        
        # Create test directory structure
        test_dir = self._create_test_directory_structure(tmp_path)
        
        # Run discover_tests with recursive_search=True
        test_cases = discover_tests([str(test_dir)], recursive_search=True)
        
        # Should find all 5 JSON files (excluding agent.json)
        assert len(test_cases) == 5
        
        # Check that files from all levels are found
        test_files = [os.path.basename(tc) for tc in test_cases]
        assert "test1.json" in test_files  # Top level
        assert "test2.json" in test_files  # Top level
        assert "test3.json" in test_files  # In subdir1
        assert "test4.json" in test_files  # In subdir1
        assert "test5.json" in test_files  # In nested subdirectory
        
        # Verify that agent.json is not included
        assert "agent.json" not in test_files
    
    def test_non_existent_directory(self, monkeypatch):
        """Test handling of non-existent directories."""
        # Disable rich_print to avoid output during tests
        monkeypatch.setattr("rich.print", lambda *args, **kwargs: None)
        
        # Create a path that definitely doesn't exist
        non_existent_path = "/path/that/definitely/does/not/exist"
        
        # Run discover_tests with a non-existent path
        test_cases = discover_tests([non_existent_path], recursive_search=True)
        
        # Should return an empty list without errors
        assert test_cases == []
    
    def test_mixed_paths(self, tmp_path, monkeypatch):
        """Test with a mix of file patterns and directories."""
        # Disable rich_print to avoid output during tests
        monkeypatch.setattr("rich.print", lambda *args, **kwargs: None)
        
        # Create test directory structure
        test_dir = self._create_test_directory_structure(tmp_path)
        
        # Create a specific file pattern
        file_pattern = str(test_dir / "test1.json")
        
        # Run discover_tests with both a directory and a file pattern
        test_cases = discover_tests([str(test_dir), file_pattern], recursive_search=False)
        
        # Should find 2 files: test1.json and test2.json (test1.json is deduplicated)
        assert len(test_cases) == 2
        
        # Count occurrences of each file
        test_files = [os.path.basename(tc) for tc in test_cases]
        assert test_files.count("test1.json") == 1  # From file path
        assert test_files.count("test2.json") == 1  # From dir path


    def test_unique_test_cases(self, tmp_path, monkeypatch):
        """Test that only unique test case names are returned, with first occurrence kept."""
        # Disable rich_print to avoid output during tests
        monkeypatch.setattr("rich.print", lambda *args, **kwargs: None)
        
        # Create subdirectories in the temporary directory
        dir1 = tmp_path / "subdir_a"
        dir2 = tmp_path / "subdir_b"
        dir1.mkdir()
        dir2.mkdir()
        
        # Create test files with the same name in different directories
        (dir1 / "duplicate.json").write_text('{"test": "first occurrence"}')
        (dir2 / "duplicate.json").write_text('{"test": "second occurrence"}')
        
        # Create unique test files
        (dir1 / "unique1.json").write_text('{"test": "unique1"}')
        (dir2 / "unique2.json").write_text('{"test": "unique2"}')
        
        # Run discover_tests with recursive search to find all files
        test_cases = discover_tests([str(tmp_path)], recursive_search=True)
        
        # Should find 3 unique test cases (duplicate.json should only be counted once)
        assert len(test_cases) == 3
        
        # Check that duplicate.json appears only once
        test_files = [os.path.basename(tc) for tc in test_cases]
        assert test_files.count("duplicate.json") == 1
        assert "unique1.json" in test_files
        assert "unique2.json" in test_files
        
        # Verify that the first occurrence of duplicate.json is kept
        duplicate_path = next(tc for tc in test_cases if os.path.basename(tc) == "duplicate.json")
        assert str(dir1) in duplicate_path, "First occurrence of duplicate.json should be kept"
