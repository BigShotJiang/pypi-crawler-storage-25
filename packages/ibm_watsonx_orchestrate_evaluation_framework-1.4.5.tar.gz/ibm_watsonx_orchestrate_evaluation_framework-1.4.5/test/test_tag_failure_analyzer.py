"""
Test cases for tag_failure_analyzer module.

This module tests the tag-based failure analysis functionality including:
- Building tag failure indices
- Loading benchmark data
"""

import json
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, Mock, patch

import pandas as pd
import pytest
import yaml

from agentops.tag_failure_analyzer import (
    build_benchmark_tag_failure_index,
    tag_test_failure_mapping,
)


@pytest.fixture
def sample_test_files(tmp_path):
    """Create sample test JSON files with tags."""
    test_dir = tmp_path / "tests"
    test_dir.mkdir()

    # Test 1: Login test with "login" and "critical" tags
    test1 = test_dir / "test_login.json"
    test1.write_text(
        json.dumps(
            {
                "name": "test_login",
                "tags": ["login", "critical"],
                "description": "Test login functionality",
            }
        )
    )

    # Test 2: Checkout test with "checkout" tag
    test2 = test_dir / "test_checkout.json"
    test2.write_text(
        json.dumps(
            {
                "name": "test_checkout",
                "tags": ["checkout"],
                "description": "Test checkout process",
            }
        )
    )

    # Test 3: Search test with "search" and "critical" tags
    test3 = test_dir / "test_search.json"
    test3.write_text(
        json.dumps(
            {
                "name": "test_search",
                "tags": ["search", "critical"],
                "description": "Test search functionality",
            }
        )
    )

    # Test 4: Test without tags (should be grouped as "untagged")
    test4 = test_dir / "test_untagged.json"
    test4.write_text(
        json.dumps(
            {
                "name": "test_untagged",
                "description": "Test without tags",
            }
        )
    )

    return [str(test1), str(test2), str(test3), str(test4)]


@pytest.fixture
def sample_failure_dict():
    """Create a sample failure dictionary."""
    return {
        "reason_tool_map": {
            "timeout": [
                {"tool_name": "login_tool", "test_name": "test_login"},
                {"tool_name": "search_tool", "test_name": "test_search"},
            ],
            "auth_error": [
                {"tool_name": "login_tool", "test_name": "test_login"}
            ],
            "invalid_parameter": [
                {"tool_name": "checkout_tool", "test_name": "test_checkout"}
            ],
        },
        "tool_reason_map": {
            "login_tool": [
                {
                    "error": "timeout",
                    "reason": {"reason": "Connection timeout"},
                    "tool_type": "tool_response",
                    "test_name": "test_login",
                },
                {
                    "error": "auth_error",
                    "reason": {"reason": "Invalid credentials"},
                    "tool_type": "tool_call",
                    "test_name": "test_login",
                },
            ],
            "search_tool": [
                {
                    "error": "timeout",
                    "reason": {"reason": "Search timeout"},
                    "tool_type": "tool_response",
                    "test_name": "test_search",
                }
            ],
            "checkout_tool": [
                {
                    "error": "invalid_parameter",
                    "reason": {"reason": "Missing payment info"},
                    "tool_type": "tool_call",
                    "test_name": "test_checkout",
                }
            ],
        },
    }


@pytest.fixture
def sample_summary_df():
    """Create a sample summary DataFrame."""
    return pd.DataFrame(
        {
            "dataset_name": [
                "test_login",
                "test_checkout",
                "test_search",
                "test_untagged",
            ],
            "is_success": [False, False, False, True],
            "total_tests": [1, 1, 1, 1],
        }
    )


@pytest.fixture
def benchmark_directory(tmp_path, sample_failure_dict, sample_summary_df):
    """Create a complete benchmark directory structure."""
    benchmark_dir = tmp_path / "benchmark_results"
    benchmark_dir.mkdir()

    # Create failure_dict.json
    failure_dict_path = benchmark_dir / "failure_dict.json"
    failure_dict_path.write_text(json.dumps(sample_failure_dict))

    # Create summary_metrics.csv
    summary_csv_path = benchmark_dir / "summary_metrics.csv"
    sample_summary_df.to_csv(summary_csv_path, index=False)

    # Create test files
    test_dir = benchmark_dir / "tests"
    test_dir.mkdir()

    test_files = []
    for test_name in ["test_login", "test_checkout", "test_search", "test_untagged"]:
        test_file = test_dir / f"{test_name}.json"
        tags = []
        if test_name == "test_login":
            tags = ["login", "critical"]
        elif test_name == "test_checkout":
            tags = ["checkout"]
        elif test_name == "test_search":
            tags = ["search", "critical"]

        test_file.write_text(
            json.dumps({"name": test_name, "tags": tags, "description": f"Test {test_name}"})
        )
        test_files.append(str(test_file))

    # Create config.yml
    config_path = benchmark_dir / "config.yml"
    config_data = {"test_paths": test_files}
    config_path.write_text(yaml.dump(config_data))

    return benchmark_dir


class TestBuildTagFailureIndex:
    """Test cases for tag_test_failure_mapping function."""

    def test_basic_tag_failure_index(self, sample_test_files, sample_failure_dict):
        """Test building a basic tag failure index."""
        result = tag_test_failure_mapping(
            test_paths=sample_test_files,
            failure_dict=sample_failure_dict,
            summary_df=None,
            prefix_dir=None,
        )

        # Check that all expected tags are present
        assert "login" in result
        assert "critical" in result
        assert "checkout" in result
        assert "search" in result
        assert "untagged" in result

        # Check login tag data
        login_data = result["login"]
        assert "test_login" in login_data["tests"]
        assert "test_login" in login_data["failed_tests"]
        assert login_data["total_tests"] == 1
        assert login_data["failed_tests_count"] == 1
        assert login_data["total_tool_failures"] == 2  # timeout + auth_error


    def test_tools_used_tracking(self, sample_test_files, sample_failure_dict):
        """Test that tools used are properly tracked."""
        result = tag_test_failure_mapping(
            test_paths=sample_test_files,
            failure_dict=sample_failure_dict,
            summary_df=None,
            prefix_dir=None,
        )

        login_data = result["login"]
        assert "login_tool" in login_data["tools_used"]

        tool_data = login_data["tools_used"]["login_tool"]
        assert tool_data["failures"] == 2
        assert "timeout" in tool_data["reasons"]
        assert "auth_error" in tool_data["reasons"]

    def test_failure_reasons_aggregation(self, sample_test_files, sample_failure_dict):
        """Test that failure reasons are properly aggregated."""
        result = tag_test_failure_mapping(
            test_paths=sample_test_files,
            failure_dict=sample_failure_dict,
            summary_df=None,
            prefix_dir=None,
        )

        login_data = result["login"]
        assert "timeout" in login_data["tool_failure_reasons"]
        assert "auth_error" in login_data["tool_failure_reasons"]
        assert login_data["tool_failure_reasons"]["timeout"] == 1
        assert login_data["tool_failure_reasons"]["auth_error"] == 1

    def test_critical_tag_multiple_tests(self, sample_test_files, sample_failure_dict):
        """Test tag that appears in multiple tests."""
        result = tag_test_failure_mapping(
            test_paths=sample_test_files,
            failure_dict=sample_failure_dict,
            summary_df=None,
            prefix_dir=None,
        )

        critical_data = result["critical"]
        assert critical_data["total_tests"] == 2  # test_login and test_search
        assert "test_login" in critical_data["tests"]
        assert "test_search" in critical_data["tests"]

    def test_empty_failure_dict(self, sample_test_files):
        """Test with empty failure dictionary."""
        empty_failure_dict = {"reason_tool_map": {}, "tool_reason_map": {}}

        result = tag_test_failure_mapping(
            test_paths=sample_test_files,
            failure_dict=empty_failure_dict,
            summary_df=None,
            prefix_dir=None,
        )

        # All tests should have no failures
        for tag_data in result.values():
            assert tag_data["total_tool_failures"] == 0
            assert len(tag_data["failed_tests"]) == 0

    def test_prefix_dir_resolution(self, tmp_path, sample_failure_dict):
        """Test that prefix_dir properly resolves relative paths."""
        test_dir = tmp_path / "tests"
        test_dir.mkdir()

        test_file = test_dir / "test_example.json"
        test_file.write_text(
            json.dumps({"name": "test_example", "tags": ["example"]})
        )

        # Use relative path
        relative_paths = ["tests/test_example.json"]

        result = tag_test_failure_mapping(
            test_paths=relative_paths,
            failure_dict=sample_failure_dict,
            summary_df=None,
            prefix_dir=tmp_path,
        )

        assert "example" in result

    def test_passed_tests_count(
        self, sample_test_files, sample_failure_dict, sample_summary_df
    ):
        """Test that passed tests are correctly counted."""
        result = tag_test_failure_mapping(
            test_paths=sample_test_files,
            failure_dict=sample_failure_dict,
            summary_df=sample_summary_df,
            prefix_dir=None,
        )

        untagged_data = result["untagged"]
        assert untagged_data["passed_tests"] == 1
        assert untagged_data["failed_tests_count"] == 0


class TestBuildBenchmarkTagFailureIndex:
    """Test cases for build_benchmark_tag_failure_index function."""

    def test_build_benchmark_tag_failure_index_basic(self, benchmark_directory):
        """Test building single tag index."""
        result = build_benchmark_tag_failure_index(
            benchmark_dir=str(benchmark_directory)
        )

        assert isinstance(result, dict)
        assert len(result) > 0
        assert "login" in result or "checkout" in result or "search" in result


    def test_tag_index_structure(self, benchmark_directory):
        """Test that returned tag index has correct structure."""
        result = build_benchmark_tag_failure_index(
            benchmark_dir=str(benchmark_directory)
        )

        # Check structure of at least one tag
        for tag, data in result.items():
            assert "tests" in data
            assert "failed_tests" in data
            assert "tools_used" in data
            assert "tool_failure_reasons" in data
            assert "total_tests" in data
            assert "passed_tests" in data
            assert "failed_tests_count" in data
            assert "total_tool_failures" in data
            break  # Just check one tag

    def test_success_rate_calculation(self, benchmark_directory):
        """Test that success rates are calculated correctly."""
        result = build_benchmark_tag_failure_index(
            benchmark_dir=str(benchmark_directory)
        )

        # At least one tag should have success_rate
        has_success_rate = any("success_rate" in data for data in result.values())
        assert has_success_rate
