"""
Generation classes for data annotation tasks.

This module provides a base abstraction for LLM-based generators and concrete
implementations for keywords, summaries, and stories.
"""

import ast
import concurrent.futures
import json
import os
import re
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional

from agentops.prompt.template_render import (
    ArgMatchingGenerationTemplateRenderer,
    LlamaKeywordsGenerationTemplateRenderer,
    LlamaSummaryGenerationTemplateRenderer,
    StoryGenerationTemplateRenderer,
)
from agentops.service_provider.watsonx_provider import Provider
from agentops.type import GPTOSS_ROUTING_AGENT_NAME_PREFIX, MatchingStrategy


class BaseGenerator(ABC):
    """
    Abstract base class for LLM-based generators.

    All generators follow a common pattern:
    1. Accept a provider and template renderer
    2. Render a prompt from input data
    3. Call the provider to generate output
    4. Process and return the result
    """

    def __init__(self, provider: Provider, template: Any):
        """
        Initialize the generator.

        Args:
            provider: The LLM provider to use for generation
            template: The template renderer for creating prompts
        """
        self.provider = provider
        self.prompt_template = template

    @abstractmethod
    def generate(self, *args, **kwargs) -> Any:
        """
        Generate output based on input data.

        This method must be implemented by subclasses.
        """
        pass


class KeywordsGenerationLLM(BaseGenerator):
    """Generator for extracting keywords from text responses."""

    def __init__(
        self,
        provider: Provider,
        template: LlamaKeywordsGenerationTemplateRenderer,
    ):
        super().__init__(provider, template)

    def generate(self, response: str) -> list | None:
        """
        Generate keywords from a given response.

        Args:
            response: The text response to extract keywords from

        Returns:
            A list of keywords, or None if generation fails
        """
        prompt = self.prompt_template.render(response=response)
        llm_response = self.provider.chat(prompt)
        keywords = ast.literal_eval(
            llm_response.choices[0].message.content.strip()
        )
        return keywords


class SummaryGenerationLLM(BaseGenerator):
    """Generator for creating text summaries from responses."""

    def __init__(
        self,
        provider: Provider,
        template: LlamaSummaryGenerationTemplateRenderer,
    ):
        super().__init__(provider, template)

    def generate(self, response: str) -> str | None:
        """
        Generate a textual summary from the given response.

        Args:
            response: The text response to summarize

        Returns:
            A summary string, or None if generation fails
        """
        try:
            prompt = self.prompt_template.render(response=response)
            llm_response = self.provider.chat(prompt)
            return llm_response.choices[0].message.content.strip()
        except Exception:
            return None


class StoryGenerationLLM(BaseGenerator):
    """Generator for creating narrative stories from structured data."""

    def __init__(
        self,
        provider: Provider,
        template: StoryGenerationTemplateRenderer,
    ):
        super().__init__(provider, template)

    def generate(self, input_data: dict) -> str | None:
        """
        Generate a narrative story from structured input data.

        Args:
            input_data: Dictionary containing the data to generate a story from

        Returns:
            A story string, or None if generation fails
        """
        prompt = self.prompt_template.render(input_data=input_data)
        llm_response = self.provider.chat(prompt)
        return llm_response.choices[0].message.content.strip()


class ArgMatchingGenerationLLM(BaseGenerator):
    """LLM wrapper for generating arg_matching labels for tool call arguments."""

    DEFAULT_BATCH_SIZE = 1  # Process one at a time, parallelized
    MAX_WORKERS = 10  # Max concurrent LLM calls

    def __init__(
        self,
        provider: Provider,
        template: ArgMatchingGenerationTemplateRenderer,
        batch_size: int = DEFAULT_BATCH_SIZE,
        max_workers: int = MAX_WORKERS,
    ):
        super().__init__(provider, template)
        self.batch_size = batch_size
        self.max_workers = max_workers
        self.executor = concurrent.futures.ThreadPoolExecutor(
            max_workers=max_workers
        )

    def shutdown(self):
        """Shut down the executor and release resources."""
        self.executor.shutdown(wait=True)

    def generate(
        self, tool_calls: List[Dict]
    ) -> List[Dict[str, MatchingStrategy]]:
        """Generate arg_matching labels for multiple tool calls.

        This is the main generate method required by BaseGenerator.
        Delegates to generate_arg_matching for backward compatibility.

        Args:
            tool_calls: List of dicts with 'tool_name' and 'args' keys

        Returns:
            List of arg_matching dicts in the same order as input
        """
        return self.generate_arg_matching(tool_calls)

    def generate_arg_matching(
        self, tool_calls: List[Dict]
    ) -> List[Dict[str, MatchingStrategy]]:
        """Generate arg_matching labels for multiple tool calls.

        Uses parallel execution for speed when batch_size=1.
        Can be disabled via AUTOLABEL_ENABLED=false env var.

        Args:
            tool_calls: List of dicts with 'tool_name' and 'args' keys

        Returns:
            List of arg_matching dicts in the same order as input
        """
        if not tool_calls:
            return []

        # Kill switch: disable autolabeling via environment variable
        # When disabled, all parameters are explicitly set to strict matching
        if os.getenv("AUTOLABEL_ENABLED", "true").lower() not in ("true", "1"):
            results = []
            for tc in tool_calls:
                args = tc.get("args", {})
                if args and args != {"IGNORE": None}:
                    results.append(
                        {k: MatchingStrategy.strict for k in args.keys()}
                    )
                else:
                    results.append({})
            return results

        # Validate and filter tool calls
        valid_calls = []
        ignored_collaborator_calls = {}
        for i, tc in enumerate(tool_calls):
            args = tc.get("args", {})
            tool_name = tc.get("tool_name", "")

            # Fail loudly on malformed tool calls with empty names
            if args == {"": {}}:
                raise ValueError(
                    f"Tool call at index {i} has empty name (args={{'': {{}}}}). "
                    "This indicates malformed data that should be fixed at the source."
                )

            # Check if tool name starts with "chat_with_collaborator_"
            if tool_name.startswith(GPTOSS_ROUTING_AGENT_NAME_PREFIX):
                # Set all args to ignore for collaborator tools
                if args and args != {"IGNORE": None}:
                    ignored_collaborator_calls[i] = {
                        k: "ignore" for k in args.keys()
                    }
                continue

            # Skip empty/ignored args
            if args and args != {"IGNORE": None}:
                valid_calls.append(
                    {
                        "idx": i,
                        "tool": tool_name,
                        "args": args,
                    }
                )

        if not valid_calls:
            # Build results with ignored collaborator calls
            results = [{} for _ in tool_calls]
            for idx, arg_matching in ignored_collaborator_calls.items():
                if 0 <= idx < len(results):
                    results[idx] = self._convert_arg_matching(arg_matching)
            return results

        # Process in parallel when batch_size is 1
        all_raw_results = {}
        if self.batch_size == 1:
            all_raw_results = self._process_parallel(valid_calls)
        else:
            # Parallelize chunked batch processing
            chunks = [
                valid_calls[i : i + self.batch_size]
                for i in range(0, len(valid_calls), self.batch_size)
            ]
            future_to_chunk = {
                self.executor.submit(
                    self._process_batch_with_retry, chunk
                ): chunk
                for chunk in chunks
            }
            for future in concurrent.futures.as_completed(future_to_chunk):
                chunk = future_to_chunk[future]
                try:
                    chunk_results = future.result()
                    # For any calls in chunk not in chunk_results, add strict fallback
                    for call in chunk:
                        if call["idx"] not in chunk_results:
                            chunk_results[call["idx"]] = (
                                self._get_strict_fallback(call)
                            )
                    all_raw_results.update(chunk_results)
                except Exception:
                    # LLM failed for entire chunk - fall back to strict
                    for call in chunk:
                        all_raw_results[call["idx"]] = (
                            self._get_strict_fallback(call)
                        )

        # Build result list using idx for safety
        results = [{} for _ in tool_calls]

        # First, add ignored collaborator calls
        for idx, arg_matching in ignored_collaborator_calls.items():
            if 0 <= idx < len(results):
                results[idx] = self._convert_arg_matching(arg_matching)

        # Then, add LLM-generated results
        for idx, raw_matching in all_raw_results.items():
            if 0 <= idx < len(results):
                results[idx] = self._convert_arg_matching(raw_matching)

        return results

    def _convert_arg_matching(
        self,
        arg_matching: Dict[str, str],
    ) -> Dict[str, MatchingStrategy]:
        """Convert arg_matching string values to MatchingStrategy enum."""
        return {
            key: MatchingStrategy(value)
            for key, value in arg_matching.items()
            if value in ("strict", "optional", "ignore", "fuzzy")
        }

    def _get_strict_fallback(self, call: Dict) -> Dict[str, str]:
        """Return strict labels for all args when LLM fails.

        This ensures the UI always receives explicit matching strategies
        rather than empty dicts that would need to infer defaults.
        """
        args = call.get("args", {})
        if not args or args == {"IGNORE": None}:
            return {}
        return {k: "strict" for k in args.keys()}

    def _process_parallel(self, valid_calls: List[Dict]) -> Dict[int, Dict]:
        """Process all tool calls in parallel using self.executor."""
        all_results = {}

        # Submit all calls
        future_to_call = {
            self.executor.submit(self._process_single, call): call
            for call in valid_calls
        }

        # Collect results as they complete
        for future in concurrent.futures.as_completed(future_to_call):
            call = future_to_call[future]
            try:
                result = future.result()
                if result:
                    all_results[call["idx"]] = result
                else:
                    # LLM returned None - fall back to strict
                    all_results[call["idx"]] = self._get_strict_fallback(call)
            except Exception:
                # LLM failed - fall back to strict
                all_results[call["idx"]] = self._get_strict_fallback(call)

        return all_results

    def _process_single(self, call: Dict) -> Optional[Dict]:
        """Process a single tool call and return its arg_matching."""
        try:
            tool_calls_json = json.dumps([call], indent=2)
            prompt = self.prompt_template.render(
                tool_calls_json=tool_calls_json
            )
            response = self.provider.chat(prompt)

            content = response.choices[0].message.content
            if not content or content.strip() == "":
                return None

            content = content.strip()

            # Handle potential markdown code blocks
            if content.startswith("```"):
                content = re.sub(r"```(?:json)?\s*", "", content)
                content = content.rstrip("`")

            raw_results = json.loads(content)

            if isinstance(raw_results, list) and len(raw_results) > 0:
                item = raw_results[0]
                if isinstance(item, dict):
                    item.pop("idx", None)  # Remove idx if present
                    return item

            return None

        except Exception:
            return None

    def _process_batch_with_retry(self, batch: List[Dict]) -> Dict[int, Dict]:
        """Process batch with auto-retry on context limit.

        If finish_reason='length' (context exceeded), splits batch
        in half and retries recursively.
        """
        if not batch:
            return {}

        # Try processing the batch
        result, hit_limit = self._process_batch(batch)

        if hit_limit and len(batch) > 1:
            # Split batch in half and retry
            mid = len(batch) // 2
            left_results = self._process_batch_with_retry(batch[:mid])
            right_results = self._process_batch_with_retry(batch[mid:])
            left_results.update(right_results)
            return left_results

        return result

    def _process_batch(self, batch: List[Dict]) -> tuple[Dict[int, Dict], bool]:
        """Process a single batch of tool calls.

        Args:
            batch: List of tool calls with 'idx', 'tool', 'args' keys

        Returns:
            Tuple of (results dict, hit_context_limit bool)
        """
        try:
            tool_calls_json = json.dumps(batch, indent=2)
            prompt = self.prompt_template.render(
                tool_calls_json=tool_calls_json
            )
            response = self.provider.chat(prompt)

            # Check if we hit context limit
            finish_reason = getattr(response.choices[0], "finish_reason", None)
            content = response.choices[0].message.content
            if finish_reason == "length" and (
                not content or content.strip() == ""
            ):
                return {}, True  # Signal to retry with smaller batch

            content = content.strip()

            # Handle potential markdown code blocks
            if content.startswith("```"):
                content = re.sub(r"```(?:json)?\s*", "", content)
                content = content.rstrip("`")

            raw_results = json.loads(content)

            if not isinstance(raw_results, list):
                raise ValueError("Expected JSON array response")

            # Parse using idx field for safety, fall back to positional
            results = {}
            for i, item in enumerate(raw_results):
                if isinstance(item, dict):
                    if "idx" in item:
                        idx = item.pop("idx")
                        results[idx] = item
                    else:
                        # Fallback: use position to match with batch order
                        if i < len(batch):
                            results[batch[i]["idx"]] = item
            return results, False

        except (json.JSONDecodeError, KeyError, IndexError, ValueError):
            return {}, False
        except Exception:
            return {}, False
