from agentops.singleton import ThreadSafeSingleton


class ResourceRegistryMeta(ThreadSafeSingleton):
    @staticmethod
    def get_key(cls, *args, **kwargs):
        return cls


class ResourceRegistry(metaclass=ResourceRegistryMeta):
    """Subclass this class to add any shared resource to a global registry.
    The resource is then available to components that want to access that resource.

    There are several objects that are instantiated once,
    and then required by various components of the evaluation loop.
    ex.
    For example, when evaluating Orchestrate agents, we need to instantiate a `ResourceMap`.
    The `ResourceMap` does not change during the evaluation loop, and it is required by
    various metrics. Therefore, the `ResourceMap` class subclasses this class and it is
    then available to the components that require it.
    """

    @classmethod
    def get(cls, resource_name):
        resource = cls.get_instance(resource_name)
        if resource is None:
            raise ValueError(
                f"Resource {resource_name} not found. Make sure the resource is initialized."
            )
        return resource
