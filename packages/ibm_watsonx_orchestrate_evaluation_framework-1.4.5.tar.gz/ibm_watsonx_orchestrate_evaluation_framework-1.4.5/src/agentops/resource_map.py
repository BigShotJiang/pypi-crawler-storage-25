from collections import defaultdict
from typing import Optional

from pydantic import BaseModel

from agentops.resource_registry import ResourceRegistry
from agentops.utils.rich_utils import RichLogger
from agentops.utils.utils import is_saas_url
from agentops.wxo_client import WXOClient

logger = RichLogger(__name__)


class AgentData(BaseModel):
    agent_name: str
    id: str
    tools: list[str]
    collaborators: list[str]
    is_manager: bool = False


class ResourceMap(ResourceRegistry):
    def __init__(
        self,
        agent2tools: dict[str, set[str]],
        tools2agents: dict[str, set[str]],
        agent_data: Optional[dict[str, AgentData]] = None,
        all_agent_objs: Optional[list[dict]] = None,
    ):
        self.agent2tools = agent2tools
        self.tools2agents = tools2agents
        self.all_agents = list(self.agent2tools.keys())

        # TODO: these objects need to be validated
        self.agent_data = agent_data
        self.all_agent_objs = all_agent_objs

        logger.info(f":heavy_check_mark: ResourceMap initialized successfully")

    @classmethod
    def from_agent_and_tool_data(cls, agent_data, tool_data):
        agent2tools = defaultdict(set)
        tools2agents = defaultdict(set)
        agents_data: dict[str, AgentData] = {}

        # ensure the ids are all str, not `UUID`
        tool_id2name = {str(tool["id"]): tool["name"] for tool in tool_data}
        agent_id2name = {
            str(agent["id"]): agent["name"] for agent in agent_data
        }

        for agent in agent_data:
            agent_name = agent["name"]
            agent_tool_ids = [str(tool_id) for tool_id in agent["tools"]]
            agent_tools = [tool_id2name[id] for id in agent_tool_ids]
            # only get collaborator names that are retrievable
            collaborators = [
                agent_id2name.get(id)
                for id in agent["collaborators"]
                if agent_id2name.get(id) is not None
            ]

            for tool in agent_tools:
                agent2tools[agent_name].add(tool)
                tools2agents[tool].add(agent_name)

            # TODO: is this used anywhere?
            agents_data[agent_name] = AgentData(
                agent_name=agent_name,
                id=str(agent.get("id", "")),
                tools=agent_tools,
                collaborators=collaborators,
                is_manager=(len(agent_tools) == 0),
            )

        return cls(agent2tools, tools2agents, agents_data, agent_data)

    @classmethod
    def from_wxo_client(cls, wxo_client: WXOClient):
        if is_saas_url(wxo_client.service_url):
            # TO-DO: this is not validated after the v1 prefix change
            # need additional validation
            tools_path = "v1/orchestrate/tools"
            agents_path = "v1/orchestrate/agents"
        else:
            tools_path = "v1/tools/"
            agents_path = "v1/orchestrate/agents/"

        resp = wxo_client.get(tools_path)
        if resp.status_code == 200:
            tools = resp.json()
        else:
            resp.raise_for_status()

        resp = wxo_client.get(agents_path)

        if resp.status_code == 200:
            agents: list[dict] = resp.json()
        else:
            resp.raise_for_status()

        return cls.from_agent_and_tool_data(agents, tools)
