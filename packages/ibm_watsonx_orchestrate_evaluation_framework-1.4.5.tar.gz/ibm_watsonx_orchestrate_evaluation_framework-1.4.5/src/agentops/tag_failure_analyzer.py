"""
Tag-based Failure Analysis Module

This module provides functionality for analyzing test failures at the tag level,
enabling insights into how different categories of tests (e.g., "Login", "Checkout")
perform across a benchmark run.

Key Features:
- Build tag-failure index mapping tags to failures, tools, and reasons
- Display rich visualizations of tag performance
"""

from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd
from rich.console import Console

from agentops.scheduler import build_tag_mapping
from agentops.utils.rich_utils import RichLogger
from agentops.utils.utils import (
    load_config_file_from_benchmark_run,
    load_failure_dict,
    load_summary_csv,
)

logger = RichLogger(__name__)
console = Console()


def _build_tag_to_tests_mapping(
    test_paths: List[str],
    prefix_dir: Optional[Path] = None,
) -> Dict[str, List[str]]:
    """
    Build mapping of tags to test names, including untagged tests.

    Args:
        test_paths: List of test file paths
        prefix_dir: Optional directory to prepend to relative paths

    Returns:
        Dictionary mapping tag names to lists of test names
    """
    # Build tag to test name mapping
    tag_to_tests = build_tag_mapping(
        test_paths=test_paths,
        filter_tags=None,  # Discover all tags
        return_stems=True,  # Return test names for matching
        prefix_dir=prefix_dir,
    )

    # Identify tests without any tags and add them to "untagged"
    all_test_names = {Path(test_path).stem for test_path in test_paths}
    tagged_test_names = set()
    for test_list in tag_to_tests.values():
        tagged_test_names.update(test_list)

    untagged_tests = list(all_test_names - tagged_test_names)
    if untagged_tests:
        tag_to_tests["untagged"] = untagged_tests

    return tag_to_tests


def _build_test_to_failures_mapping(
    tool_reason_map: Dict[str, List[Dict[str, Any]]]
) -> Dict[str, List[Dict[str, Any]]]:
    """
    Build reverse mapping from test names to their failures.

    Args:
        tool_reason_map: Mapping of tool names to their failure records

    Returns:
        Dictionary mapping test names to lists of failure records
    """
    test_to_failures: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for tool_name, failures in tool_reason_map.items():
        for failure in failures:
            test_name = failure.get("test_name")
            if test_name:
                test_to_failures[test_name].append(
                    {
                        "tool": tool_name,
                        "reason": failure["error"],
                    }
                )
    return test_to_failures


def _initialize_tag_data(test_names: List[str]) -> Dict[str, Any]:
    """
    Initialize the data structure for a single tag.

    Args:
        test_names: List of test names associated with this tag

    Returns:
        Initialized tag data dictionary
    """
    return {
        "tests": test_names,
        "failed_tests": [],
        "tools_used": {},
        "tool_failure_reasons": defaultdict(int),
        "total_tests": len(test_names),
        "passed_tests": 0,
        "failed_tests_count": 0,
        "total_tool_failures": 0,
    }


def _process_test_failures(
    tag_data: Dict[str, Any],
    test_names: List[str],
    test_to_failures: Dict[str, List[Dict[str, Any]]],
) -> None:
    """
    Process failures for all tests in a tag and update tag data.

    Args:
        tag_data: Tag data dictionary to update (modified in place)
        test_names: List of test names for this tag
        test_to_failures: Mapping of test names to their failures
    """
    for test_name in test_names:
        if test_name in test_to_failures:
            tag_data["failed_tests"].append(test_name)
            tag_data["failed_tests_count"] += 1

            # Process each failure for this test
            for failure in test_to_failures[test_name]:
                tool_name = failure["tool"]
                reason = failure["reason"]

                # Update tools_used
                if tool_name not in tag_data["tools_used"]:
                    tag_data["tools_used"][tool_name] = {
                        "total_calls": 0,
                        "failures": 0,
                        "reasons": set(),
                    }

                tag_data["tools_used"][tool_name]["failures"] += 1
                tag_data["tools_used"][tool_name]["reasons"].add(reason)

                # Increment total tool failures
                tag_data["total_tool_failures"] += 1

                # Update failure_reasons
                tag_data["tool_failure_reasons"][reason] += 1
        else:
            tag_data["passed_tests"] += 1


def _finalize_tag_data(tag_data: Dict[str, Any]) -> None:
    """
    Finalize tag data by converting sets to lists and defaultdicts to dicts.

    Args:
        tag_data: Tag data dictionary to finalize (modified in place)
    """
    # Convert sets to lists for JSON serialization
    for tool_name in tag_data["tools_used"]:
        tag_data["tools_used"][tool_name]["reasons"] = list(
            tag_data["tools_used"][tool_name]["reasons"]
        )

    # Convert defaultdict to regular dict
    tag_data["tool_failure_reasons"] = dict(tag_data["tool_failure_reasons"])


def _calculate_success_rate(
    tag_data: Dict[str, Any],
    test_names: List[str],
    summary_df: pd.DataFrame,
) -> None:
    """
    Calculate and update success rate from summary DataFrame.

    Args:
        tag_data: Tag data dictionary to update (modified in place)
        test_names: List of test names for this tag
        summary_df: DataFrame with test results
    """
    if "dataset_name" not in summary_df.columns:
        return

    tag_tests_in_df = summary_df[summary_df["dataset_name"].isin(test_names)]
    if not tag_tests_in_df.empty and "is_success" in tag_tests_in_df.columns:
        success_count = tag_tests_in_df["is_success"].sum()
        total_count = len(tag_tests_in_df)
        tag_data["success_rate"] = (
            success_count / total_count if total_count > 0 else 0.0
        )
        tag_data["passed_tests"] = int(success_count)
        tag_data["failed_tests_count"] = total_count - int(success_count)


def tag_test_failure_mapping(
    test_paths: List[str],
    failure_dict: Dict[str, Any],
    summary_df: Optional[pd.DataFrame] = None,
    prefix_dir: Optional[Path] = None,
) -> Dict[str, Dict[str, Any]]:
    """
    Build a comprehensive index mapping tags to all associated test failures,
    tools, and reasons.

    This creates a single source of truth with all data available, which is
    advantageous for comparisons (as seen with the rest of the failure analysis code).

    Tests without any tags are automatically grouped under the "untagged" tag.

    Args:
        test_paths: List of test file paths
        failure_dict: Dictionary containing 'reason_tool_map' and 'tool_reason_map'
        summary_df: Optional DataFrame with test results (for success rate calculation)
        prefix_dir: Optional directory to prepend to relative paths

    Returns:
        Dictionary mapping tag names to their failure analysis data
    """
    # Build tag to test name mapping (including untagged tests)
    tag_to_tests = _build_tag_to_tests_mapping(test_paths, prefix_dir)

    # Build reverse mapping: test_name -> failed tools and reasons
    tool_reason_map = failure_dict.get("tool_reason_map", {})
    test_to_failures = _build_test_to_failures_mapping(tool_reason_map)

    # Initialize the tag failure index
    tag_failure_index: Dict[str, Dict[str, Any]] = {}

    # Process each tag
    for tag, test_names in tag_to_tests.items():
        # Initialize tag data structure
        tag_data = _initialize_tag_data(test_names)

        # Process all failures for tests in this tag
        _process_test_failures(tag_data, test_names, test_to_failures)

        # Finalize tag data (convert sets to lists, etc.)
        _finalize_tag_data(tag_data)

        # Calculate success rate if summary_df is provided
        if summary_df is not None:
            _calculate_success_rate(tag_data, test_names, summary_df)

        tag_failure_index[tag] = tag_data

    logger.info(f"Built tag failure index for {len(tag_failure_index)} tags")
    return tag_failure_index


def build_benchmark_tag_failure_index(
    benchmark_dir: str,
) -> Dict[str, Dict[str, Any]]:
    """
    Build tag failure index for a single benchmark.

    Args:
        benchmark_dir: Benchmark directory path

    Returns:
        Tag failure index dictionary
    """
    benchmark_path = Path(benchmark_dir)

    # Validate directory
    if not benchmark_path.exists():
        raise FileNotFoundError(
            f"Benchmark directory not found: {benchmark_dir}"
        )

    logger.info(f"Building tag failure index for: {benchmark_dir}")

    # Load benchmark data using utility functions
    failure_dict = load_failure_dict(benchmark_path)
    summary_df = load_summary_csv(str(benchmark_path))
    config = load_config_file_from_benchmark_run(benchmark_path)

    test_paths = config.get("test_paths", [])
    if not test_paths:
        raise ValueError(f"No test_paths found in config.yml")

    # Build tag failure index
    tag_index = tag_test_failure_mapping(
        test_paths=test_paths,
        failure_dict=failure_dict,
        summary_df=summary_df,
        prefix_dir=benchmark_path,
    )

    logger.info(f"Built tag failure index with {len(tag_index)} tags")
    return tag_index
