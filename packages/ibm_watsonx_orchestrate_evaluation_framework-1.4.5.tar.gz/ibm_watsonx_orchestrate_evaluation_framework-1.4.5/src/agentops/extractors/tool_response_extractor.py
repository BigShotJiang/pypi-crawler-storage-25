from agentops.error_constants import ERROR_KEYWORDS
from agentops.extractors.extractor_base import Extractor
from agentops.metrics.metrics import ExtractorData
from agentops.type import ContentType


class ToolResponseErrorExtractor(Extractor):
    def __init__(self, llm_client=None, error_keywords=ERROR_KEYWORDS):
        self.error_keywords = error_keywords
        super().__init__(llm_client)

    def do_extract(self, messages, ground_truth, **kwargs):
        tool_response_error_idx = []
        for idx, message in enumerate(messages):
            if message.type == ContentType.tool_response:
                found = False
                if self.error_keywords:
                    for keyword in self.error_keywords:
                        if keyword in message.content.lower():
                            tool_response_error_idx.append(idx)
                            found = True
                            break
                if found:
                    tool_response_error_idx.append(idx)

        return ExtractorData(
            field_name="tool_response_error_idx", value=tool_response_error_idx
        )
