import json

from agentops.extractors.extractor_base import Extractor
from agentops.extractors.utils import argument_matching
from agentops.metrics.metrics import ExtractorData
from agentops.type import ContentType
from agentops.utils.rich_utils import RichLogger

logger = RichLogger(__name__)


class ExpectedToolExtractor(Extractor):
    def matched_goal_details(self, messages, tool_dictionary):
        """Returns the index of relevant tool calls and irrelevant tool calls made by the agent"""
        relevant_tool_call_idx = []
        irrelevant_tool_call_idx = []

        for idx, message in enumerate(messages):
            if message.type != ContentType.tool_call:
                continue
            try:
                msg_tool_call = message.tool_calls[0].function
            except Exception:
                # ignore malformed tool_call content
                continue

            matching_goal_details = [
                gd
                for gd in tool_dictionary.values()
                if gd.tool_name.strip() == msg_tool_call.name.strip()
            ]
            if matching_goal_details:
                relevant_tool_call_idx.append(idx)
            else:
                irrelevant_tool_call_idx.append(idx)

        return relevant_tool_call_idx, irrelevant_tool_call_idx

    def do_extract(self, messages, ground_truth, **kwargs):
        tool_dictionary = (
            {
                goal_detail.name: goal_detail
                for goal_detail in ground_truth.goal_details
                if goal_detail.type == ContentType.tool_call
            }
            if ground_truth.goal_details
            else {}
        )
        relevant_tool_call_idx, irrelevant_tool_call_idx = (
            self.matched_goal_details(messages, tool_dictionary)
        )
        correct_tool_calls = {}
        incorrect_param_tool_idx = []

        if not relevant_tool_call_idx:
            logger.info("No relevant tool calls found")

        for message_idx in relevant_tool_call_idx:
            msg_tool_call = messages[message_idx]
            msg_tool_call = msg_tool_call.tool_calls[0].function

            found = False
            for goal_detail in tool_dictionary.values():
                if goal_detail.tool_name == msg_tool_call.name:
                    args_match = argument_matching(
                        expected=goal_detail.args,
                        actual=(
                            {}
                            if len(msg_tool_call.arguments) == 0
                            else json.loads(msg_tool_call.arguments)
                        ),
                        matching_strategy=goal_detail.arg_matching,
                        llm_client=self.llm_client,
                    )

                    if args_match:
                        found = True
                        correct_tool_calls[goal_detail.name] = None
                        break

            if not found:
                incorrect_param_tool_idx.append(message_idx)

        correct_tool_calls = ExtractorData(
            field_name="correct_tool_calls",
            value=list(correct_tool_calls.keys()),
        )
        incorrect_param_tool_idx = ExtractorData(
            field_name="incorrect_param_tool_idx",
            value=incorrect_param_tool_idx,
        )
        relevant_tool_call_idx = ExtractorData(
            field_name="relevant_tool_call_idx", value=relevant_tool_call_idx
        )
        irrelevant_tool_call_idx = ExtractorData(
            field_name="irrelevant_tool_call_idx",
            value=irrelevant_tool_call_idx,
        )

        extractor_data = [
            correct_tool_calls,
            incorrect_param_tool_idx,
            relevant_tool_call_idx,
            irrelevant_tool_call_idx,
        ]

        return extractor_data
