import json
import math
import os
from typing import Optional

import rich
from dateutil import parser
from fuzzywuzzy import fuzz

from agentops.service_provider.provider import Provider
from agentops.type import MatchingStrategy
from agentops.utils.rich_utils import RichLogger
from agentops.utils.utils import safe_divide

RESERVED_KEYWORD_FOR_GROUND_TRUTH_ARGS = os.getenv(
    "RESERVED_KEYWORD_FOR_GROUND_TRUTH_ARGS", "<IGNORE>"
)

logger = RichLogger(__name__)


def simplified_argument_matching(expected, actual):
    if actual is None:
        return False
    for field in actual:
        if field not in expected:
            return False

    return True


def normalize_args(data):
    if str(data) == RESERVED_KEYWORD_FOR_GROUND_TRUTH_ARGS:
        return str(data)
    return str(data).lower()


def compare_as_date_or_number(normalized_actual, normalized_expected):
    """
    Attempts to compare two normalized values as dates or numbers.

    Args:
        normalized_actual: The actual value from tool call
        normalized_expected: The expected value from ground truth

    Returns:
        tuple: (conversion_succeeded, values_match)
            - conversion_succeeded: True if values could be converted to numbers or dates
            - values_match: True if converted values match
    """
    # Try to convert to numbers
    try:
        num_actual = float(normalized_actual)
        num_expected = float(normalized_expected)
        # Conversion succeeded, check if values match
        return (
            True,
            abs(num_actual - num_expected) <= 0.001,
        )  # Small epsilon for float comparison
    except (ValueError, TypeError):
        pass

    # Try to convert to dates
    try:
        date_actual = parser.parse(normalized_actual)
        date_expected = parser.parse(normalized_expected)
        # Conversion succeeded, check if values match
        return True, date_actual == date_expected
    except (ValueError, TypeError):
        pass

    # If we get here, neither number nor date conversion worked
    return False, False


def cosine_similarity_semantic_match(
    llm_client: Provider,
    prediction: str,
    ground_truth: str,
    similarity_threshold=0.8,
) -> bool:
    """
    Determines if two strings are semantically similar using cosine similarity

    Args:
        llm_client: LLM provider
        prediction: The actual string
        ground_truth: The expected string
        similarity_threshold: Minimum score for a match. Defaults to 0.8.

    Returns:
        True if cosine similarity >= threshold, False otherwise
    """
    embeddings = llm_client.encode([prediction, ground_truth])
    emb1, emb2 = embeddings
    dot_product = sum(a * b for a, b in zip(emb1, emb2))
    magnitude1 = math.sqrt(sum(a * a for a in emb1))
    magnitude2 = math.sqrt(sum(b * b for b in emb2))

    cosine_similarity = safe_divide(dot_product, (magnitude1 * magnitude2))

    return cosine_similarity >= similarity_threshold


def fuzzywuzzy_semantic_match(
    prediction: str, ground_truth: str, similarity_threshold: float = 0.8
) -> bool:

    similarity_score = fuzz.WRatio(prediction, ground_truth)
    return similarity_score > similarity_threshold


def argument_matching(
    expected: dict[str, str],
    actual: dict[str, str],
    matching_strategy: dict[str, MatchingStrategy],
    llm_client: Optional[Provider] = None,
) -> bool:
    """Handles argument matching for expected and actual arguments and values.

    Args:
        expected: Expected ground truth arguments.
        actual: Actual arguments in tool call
        matching_strategy: Matching mode for each argument. Defaults to strict if not specified.

    Returns:
        True if all arguments match according to their matching strategy.
    """
    # ignore arg matching
    if expected == {"IGNORE": None}:
        return True

    # Note: Extra fields in actual that aren't in expected are allowed.
    # This handles cases where the agent provides default/optional params
    # that weren't captured in the recording.

    for field in expected:
        # defaults to strict
        strategy = matching_strategy.get(field, MatchingStrategy.strict.value)

        norm_actual_val = normalize_args(actual.get(field))
        norm_expected_val = normalize_args(expected.get(field))

        # ignore matching - skip this field entirely
        if strategy == MatchingStrategy.ignore.value:
            continue
        # continue to next if it's an ignored keyword (backwards compatibility)
        if norm_expected_val == RESERVED_KEYWORD_FOR_GROUND_TRUTH_ARGS:
            continue

        # Check field existence (skip for optional)
        if strategy == MatchingStrategy.optional.value:
            if field not in actual:
                continue
            if actual[field] != expected[field]:
                return False

        # Strict and fuzzy both require exact match when field exists
        if field not in actual:
            return False

        if strategy == MatchingStrategy.fuzzy.value:
            # check date/number conversion
            conversion_succeeded, values_match = (
                compare_as_date_or_number(  # pylint: disable=protected-access
                    norm_actual_val, norm_expected_val
                )
            )
            # If conversion succeeded and values match, continue to next parameter
            if conversion_succeeded and values_match:
                continue
            # If conversion succeeded but values don't match, return False
            if conversion_succeeded and not values_match:
                return False

            # try cosine matching
            res = False
            if llm_client:
                res = cosine_similarity_semantic_match(
                    llm_client, norm_actual_val, norm_expected_val
                )
            else:
                # fall back to fuzzywuzzy
                res = fuzzywuzzy_semantic_match(
                    norm_actual_val, norm_expected_val
                )

            return res

        elif strategy == MatchingStrategy.strict.value:
            # must match
            if norm_actual_val != norm_expected_val:
                return False

        else:
            logger.info(
                f"Warning: undefined matching strategy found: {strategy}"
            )

    return True
