import json
import os
import pathlib
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Tuple
from uuid import uuid4

import yaml
from jsonargparse import CLI
from rich.console import Console

from agentops.arg_configs import TestConfig
from agentops.clients import Clients, bootstrap_clients
from agentops.langfuse_evaluation_package import EvaluationRunner, load_metrics
from agentops.metrics.metrics import (
    CustomEvalMetrics,
    KnowledgeBaseMetricSummary,
    ToolCallAndRoutingMetrics,
    extract_error_cases,
    extract_metrics,
    format_metrics_for_display,
)
from agentops.persistence.langfuse_persistence import LangfusePersistence
from agentops.prompt import (
    GPT_KEYWORD_MATCHING_PROMPT_PATH,
    GPT_SEMANTIC_MATCHING_PROMPT_V1_PATH,
    GPT_SEMANTIC_MATCHING_PROMPT_V2_PATH,
)
from agentops.runner import RichLogger, process_test_case
from agentops.scheduler import (
    discover_tests,
    enumerate_jobs,
    filter_tests,
    run_jobs,
)
from agentops.type import DatasetSummaryStepVersion, ErrorLog, Message, TestCase
from agentops.utils.experiment_results import ExperimentResult
from agentops.utils.utils import SummaryPanel, create_table, csv_dump

os.environ["TELEMETRY_PLATFORM"] = "langfuse"

logger = RichLogger(__name__)

################## Common functions ##################


def _setup_output_directory(config: TestConfig) -> None:
    """Setup output directory with timestamp if not skipping available results."""
    if not getattr(config, "skip_available_results", False):
        ts = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        config.output_dir = os.path.join(config.output_dir, ts)


def _discover_and_run_tests(config: TestConfig, clients) -> tuple[list, list]:
    """Discover, filter, schedule and execute test cases.

    Returns:
        tuple: (filtered_test_cases, results) - filtered test cases and execution results
    """
    test_cases = discover_tests(
        config.test_paths, config.enable_recursive_search
    )
    filtered_test_cases = filter_tests(test_cases, config.tags)

    jobs = enumerate_jobs(
        filtered_test_cases,
        config.n_runs,
        config.skip_available_results,
        config.output_dir,
    )

    results = run_jobs(
        jobs, config, clients, process_test_case, config.num_workers
    )
    return filtered_test_cases, results


def _save_config(config: TestConfig, output_dir: str) -> None:
    """Save configuration to YAML file."""
    config_path = pathlib.Path(output_dir) / "config.yml"
    with open(config_path, "w", encoding="utf-8") as f:
        yaml.safe_dump(asdict(config), f)


################## Langfuse functions ##################


def _expand_test_cases(test_cases: List[str], n_runs):
    if n_runs > 1:
        return [test_case for test_case in test_cases for _ in range(n_runs)]
    else:
        return test_cases


def _get_session_ids(test_cases: List[str], n_runs, output_dir: str):
    is_multi_run = n_runs > 1
    session_ids = []

    for test_case in test_cases:
        name = os.path.basename(test_case).replace(".json", "")
        paths = []
        if is_multi_run:
            for run_idx in range(1, n_runs + 1):
                metadata_path = os.path.join(
                    output_dir, f"{name}.run{run_idx}.metadata.json"
                )
                paths.append(metadata_path)
        else:
            metadata_path = os.path.join(output_dir, f"{name}.metadata.json")
            paths.append(metadata_path)

        for path in paths:
            with open(path, "r") as f:
                metadata = json.load(f)
            session_id = metadata["thread_id"]
            session_ids.append(session_id)

    return session_ids


def _configure_metrics(
    config: TestConfig, dataset_summary_version: DatasetSummaryStepVersion
) -> TestConfig:
    """This method is to configure the semantic and keyword template paths.

    If an explicit semantic/keyword template path is provided, that will be used instead of the default.
    Otherwise, the default prompt for semantic/keyword matching depends on the dataset version.
    """
    if dataset_summary_version == DatasetSummaryStepVersion.v2:
        default_text_match_kwargs = {
            "semantic_template_path": str(GPT_SEMANTIC_MATCHING_PROMPT_V2_PATH),
            "keyword_template_path": str(GPT_KEYWORD_MATCHING_PROMPT_PATH),
        }
    else:
        default_text_match_kwargs = {
            "semantic_template_path": str(GPT_SEMANTIC_MATCHING_PROMPT_V1_PATH),
            "keyword_template_path": str(GPT_KEYWORD_MATCHING_PROMPT_PATH),
        }

    if config.operator_configs is None:
        config.operator_configs = {}

    for operator_name in [
        "JourneySuccessMetric",
        "TextMatchMetric",
        "JourneyCompletion",
        "AttackSuccessMetric",
    ]:
        operator_config = config.operator_configs.get(operator_name, {})
        if operator_config:
            if "semantic_template_path" not in operator_config:
                operator_config["semantic_template_path"] = (
                    default_text_match_kwargs["semantic_template_path"]
                )
            if "keyword_template_path" not in operator_config:
                operator_config["keyword_template_path"] = (
                    default_text_match_kwargs["keyword_template_path"]
                )
        config.operator_configs[operator_name] = operator_config

    return config


def _run_new_evaluation(
    test_cases: list,
    config: TestConfig,
    clients: Clients,
    messages: list = None,
    disable_session_ids: bool = False,
) -> tuple[str, list[str], ExperimentResult]:
    """Process results using Langfuse evaluation.

    Args:
        test_cases: List of test case file paths
        config: Test configuration
        clients: Bootstrap clients
        messages: Optional list of message lists from in-memory execution.
                  If None, falls back to polling Langfuse.
    """

    test_cases_expanded = _expand_test_cases(test_cases, config.n_runs)
    if disable_session_ids:
        session_ids = None
    else:
        session_ids = _get_session_ids(
            test_cases, config.n_runs, config.output_dir
        )

    dataset_summary_version = TestCase.consistent_summary_version(
        [TestCase.from_path(test_case) for test_case in test_cases_expanded]
    )
    logger.info(f"Dataset summary version: {dataset_summary_version}")

    config = _configure_metrics(config, dataset_summary_version)

    # Upload to collection and run evaluation
    collection_name = config.collection_name
    if config.langfuse_enabled:
        from agentops.collection import LangfuseCollection

        collection = LangfuseCollection(
            name=collection_name,
            description="",
        )
        collection.delete_all_items()
        # we only upload the test cases once, the data is duplicated in the EvaluationRunner
        # this avoids having n copies of the data in Langfuse/Arize.
        collection.upload(paths=test_cases)
        exporters = [LangfusePersistence()]
        test_cases_expanded = None
    else:
        test_cases_expanded = [
            TestCase.from_path(test_case) for test_case in test_cases_expanded
        ]
        collection = None
        exporters = []

    evaluators = load_metrics(
        config,
        config.metrics,
        llm_client=clients.llmaaj_provider,
    )

    run = EvaluationRunner(
        evaluation_name=str(uuid4()) + "-evaluation",
        output_dir=config.output_dir,
        session_ids=session_ids,
        collection=collection,
        test_cases=test_cases_expanded,
        metrics=evaluators,
        exporters=exporters,
        messages=messages,  # Pass in-memory messages, falls back to Langfuse if None,
        n_runs=config.n_runs,
    )

    evaluation_results = run.evaluate()

    return collection_name, session_ids, evaluation_results


def _print_new_results(
    output_dir: str,
    collection_name: str,
    session_ids: list[str],
    eval_results: ExperimentResult,
    langfuse_enabled: bool,
) -> None:
    console = Console()
    console.print(f"Config and metadata saved to {output_dir}")
    console.print(f"Evaluation run completed for collection {collection_name}:")

    eval_results.print_metrics()

    if langfuse_enabled:
        for session_id in session_ids:
            console.print(
                f" - http://localhost:3010/project/orchestrate-lite/sessions/{session_id}"
            )


################## Legacy functions ##################


def _setup_legacy_paths(config: TestConfig) -> dict[str, Path]:
    """Create and return paths needed for legacy evaluation mode."""
    base_dir = Path(config.output_dir)
    kb_folder = base_dir / "knowledge_base_metrics"
    kb_folder.mkdir(exist_ok=True, parents=True)

    messages_dir = base_dir / "messages"
    messages_dir.mkdir(exist_ok=True, parents=True)

    return {
        "kb_detailed": kb_folder / "knowledge_base_detailed_metrics.json",
        "kb_summary": base_dir / "knowledge_base_summary_metrics.json",
        "debug": base_dir / "debug.json",
        "summary_metrics": base_dir / "summary_metrics.csv",
    }


def _get_legacy_evaluation_results(
    results: list,
    config: TestConfig,
    paths: dict[str, Path],
    logger: RichLogger,
) -> None:
    """Process results using legacy evaluation metrics."""
    filtered_results, error_cases = extract_error_cases(results)
    logger.info(f"{len(filtered_results)} test case(s) completed successfully")

    if error_cases:
        _handle_error_cases(error_cases, paths["debug"], logger)

    tool_metrics, kb_summary, custom_metrics = extract_metrics(filtered_results)
    _save_legacy_metrics(tool_metrics, kb_summary, paths)
    _display_legacy_results(tool_metrics, kb_summary, custom_metrics)


def _handle_error_cases(
    error_cases: list, debug_path: Path, logger: RichLogger
) -> None:
    """Log and save error cases to debug file."""
    logger.warn(
        f"{len(error_cases)} test case(s) failed during execution. "
        f"See debug.json for failure reasons\n"
        + "\n".join(f" - {error.test_case_path}" for error in error_cases)
    )
    with open(debug_path, "w") as f:
        json.dump([error.model_dump() for error in error_cases], f, indent=4)


def _save_legacy_metrics(
    tool_metrics: list, kb_summary, paths: dict[str, Path]
) -> None:
    """Save legacy evaluation metrics to files."""
    csv_dump(
        paths["summary_metrics"],
        rows=[metric.model_dump() for metric in tool_metrics],
    )

    for file_path, key in [
        (paths["kb_detailed"], "detailed"),
        (paths["kb_summary"], "summary"),
    ]:
        with open(file_path, "w+", encoding="utf-8") as f:
            json.dump(kb_summary.model_dump(by_alias=True)[key], f, indent=4)


def _display_legacy_results(
    tool_metrics: list, kb_summary, custom_metrics: list
) -> None:
    """Display legacy evaluation results in console."""
    SummaryPanel(kb_summary).print()

    tool_table = create_table(
        format_metrics_for_display(tool_metrics), title="Agent Metrics"
    )
    if tool_table:
        tool_table.print()

    if any(cm.custom_metrics for cm in custom_metrics):
        rows = []
        for cm in custom_metrics:
            row = {"dataset_name": cm.dataset_name}
            for m in cm.custom_metrics:
                row[m.eval_name] = str(m.value)
            rows.append(row)
        custom_metrics_table = create_table(rows, title="Custom Metrics")
        if custom_metrics_table:
            custom_metrics_table.print()


def main(config: TestConfig):
    """Main entry point for agent evaluation."""
    logger = RichLogger(__name__)

    # Setup
    clients = bootstrap_clients(config)
    _setup_output_directory(config)

    # Discover and execute tests
    test_cases, results = _discover_and_run_tests(config, clients)

    # Update config with actual test paths that were executed (if tags were passed)
    config.test_paths = test_cases

    results: List[
        Tuple[
            ToolCallAndRoutingMetrics,
            KnowledgeBaseMetricSummary,
            CustomEvalMetrics,
            List[Message],
            Optional[ErrorLog],
        ]
    ]
    # Process results based on evaluation mode
    if config.skip_legacy_evaluation:
        # Extract messages from results (4th element of each tuple)
        messages_list = [r[3] for r in results if r[3] is not None]
        collection_name, session_ids, eval_results = _run_new_evaluation(
            test_cases, config, clients, messages_list
        )
        _print_new_results(
            config.output_dir,
            collection_name,
            session_ids,
            eval_results,
            config.langfuse_enabled,
        )
    else:
        # Setup paths and run legacy evaluation
        paths = _setup_legacy_paths(config)
        _get_legacy_evaluation_results(results, config, paths, logger)
        print(f"Results saved to {config.output_dir}")

    # Persist configuration
    _save_config(config, config.output_dir)


if __name__ == "__main__":
    main(CLI(TestConfig, as_positional=False))
