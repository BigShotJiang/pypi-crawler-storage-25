import json

from agentops.type import ContentType, Function, Message, ToolCall


def parse_observations(observation_tree, dfs_observations) -> list[Message]:
    """
    This has been tested work with gpt-oss-120b and llama-3-2-90b models.

    Observation node types:
    -----------
    1. SPAN: Root (name='LangGraph')
       - Contains the complete conversation in output['messages']
    2. SPAN: Other nodes (Skip for parsing)
       - Contain partial/duplicate data from specific execution steps
       - input['messages']: Messages leading up to this step
       - output['update']['messages']: Only new messages from this step
    3. GENERATION Nodes
        - Already included in parent SPAN output. Skip for parsing

    Args:
        observation_tree: observation nodes as a tree
        dfs_observations: observation nodes as a flat list

    Returns:
        a list of parsed messages based on the observation nodes
    """
    messages = []
    for node in dfs_observations:
        messages.extend(_get_output_message(node.obs.output))
    return messages


def _parse_tools(msg: dict) -> list[Message]:
    """Parses tool call data"""

    content = msg.get("content", "")
    try:
        json_content = json.loads(content)
    except json.JSONDecodeError:
        json_content = None

    if not isinstance(json_content, dict):
        json_content = None

    messages = []

    # content can't be parsed with json loader/doesnt have message
    if not json_content or "message" not in json_content:
        tool_call_id = msg.get("tool_call_id")
        if not tool_call_id:
            return messages

        messages.append(
            Message(
                role="tool",
                content=content,
                tool_call_id=tool_call_id,
                type=ContentType.tool_response,
            )
        )
        return messages

    content_msg = json_content.get("message", {})
    if not isinstance(content_msg, dict):
        return []
    for step in content_msg.get("step_history", []):

        role = step["role"]
        step_details = step.get("step_details", {})
        for step_detail in step_details:
            if step_detail["type"] == "tool_calls":
                content_type = ContentType.tool_call
                tool_calls = step_detail["tool_calls"]
                step_content = json.dumps(step_detail)
                for tc in tool_calls:
                    tool_call = ToolCall(
                        id=tc["id"],
                        function=Function(
                            name=tc["name"],
                            arguments=json.dumps(tc["args"]),
                        ),
                    )
                    messages.append(
                        Message(
                            role=role,
                            content=step_content,
                            type=content_type,
                            tool_calls=[tool_call],
                        )
                    )
            elif step_detail["type"] == "tool_response":

                messages.append(
                    Message(
                        role="tool",
                        content=step_detail["content"],
                        tool_call_id=step_detail["tool_call_id"],
                        type=ContentType.tool_response,
                    )
                )

    return messages


def _get_output_message(data) -> list[Message]:
    """Parses messages"""
    messages = []
    # Observations from LangGraph routing nodes (e.g. `_route_start`) emit
    # the next-node name as a plain string output rather than a dict, so an
    # unconditional `data.get(...)` here would crash. Skip anything that
    # isn't a dict — there are no parseable messages in those nodes.
    if not isinstance(data, dict):
        return []

    for msg in data.get("messages", []):
        if msg["type"] == "human":
            messages.append(
                Message(
                    role="user",
                    content=msg.get("content"),
                    type=ContentType.text,
                )
            )
        elif msg["type"] == "ai":

            msg_tool_calls = msg.get("tool_calls", [])
            tool_calls = []
            for tc in msg_tool_calls:
                tool_calls.append(
                    ToolCall(
                        id=tc["id"],
                        function=Function(
                            name=tc.get("name", ""),
                            arguments=json.dumps(tc.get("args")),
                        ),
                    )
                )
            # skip if both are blank
            if tool_calls or msg.get("content", ""):
                messages.append(
                    Message(
                        role="assistant",
                        content=msg.get("content", ""),
                        tool_calls=None if not tool_calls else tool_calls,
                        type=(
                            ContentType.tool_call
                            if tool_calls
                            else ContentType.text
                        ),
                    )
                )

        elif msg["type"] == "tool":
            # contains tool calls and responses
            msgs = _parse_tools(msg)
            messages.extend(msgs)

    return messages
