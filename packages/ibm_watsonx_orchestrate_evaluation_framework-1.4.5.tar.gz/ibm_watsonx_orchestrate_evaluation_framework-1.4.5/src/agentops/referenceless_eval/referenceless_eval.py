import json
from typing import Any, List, Mapping, Optional

import rich

from agentops.referenceless_eval.function_calling.consts import (
    METRIC_FUNCTION_SELECTION_APPROPRIATENESS,
    METRIC_GENERAL_HALLUCINATION_CHECK,
    TOOL_SPEC_FREE_METRICS,
)
from agentops.referenceless_eval.function_calling.pipeline.pipeline import (
    ReflectionPipeline,
)
from agentops.referenceless_eval.function_calling.pipeline.types import (
    ToolCall,
    ToolSpec,
)
from agentops.resource_map import ResourceMap
from agentops.runtime_adapter.wxo_runtime_adapter import WXORuntimeAdapter
from agentops.service_provider import get_provider
from agentops.type import Message

DEFAULT_GENERATION_PARAMS = {
    "min_new_tokens": 0,
    "decoding_method": "greedy",
    "max_new_tokens": 4096,
}


def _extract_resource_map_from_backend(
    inference_backend: Optional[WXORuntimeAdapter],
) -> Optional[ResourceMap]:
    """Extract or create ResourceMap from WXORuntimeAdapter if available.

    This helper provides backward compatibility by checking if the inference_backend
    is a WXORuntimeAdapter and safely creating a ResourceMap from its wxo_client.

    Args:
        inference_backend: Optional runtime adapter, expected to be WXORuntimeAdapter for WXO cases

    Returns:
        ResourceMap if backend is WXORuntimeAdapter, None otherwise
    """
    if inference_backend is None:
        return None

    # Check if this is a WXO runtime adapter with wxo_client
    if isinstance(inference_backend, WXORuntimeAdapter):
        wxo_client = getattr(inference_backend, "wxo_client", None)
        if wxo_client:
            try:
                return ResourceMap.from_wxo_client(wxo_client)
            except Exception as e:
                rich.print(
                    f"[yellow]Warning: Could not create ResourceMap: {e}[/yellow]"
                )
                return None

    return None


class ReferencelessEvaluation:
    """
    Note: static.final_decison, if `True` -> then all static metrics were valid. If false, atleast one of the static metrics failed. Look at explanation for reasoning
    Note: if static.final_decision == True, check semantic metrics. Semantic metrics **not** run if static.final_decision is False.
    ---
    Note: For semantic metrics, check agentic constraints. If agent-constraints == False, no point in checking others. If true, check others.
    Note: METRIC_FUNCTION_SELECTION_APPROPRIATENESS == False, implies that the LLM should have called some other function/tool before *OR* it is a redundant call.
    Note: When parsing the semantic metrics, check for `is_correct` field.  if `false` there is some mistake that the LLMaJ found in that tool call.
    """

    def __init__(
        self,
        api_spec: Optional[List[Mapping[str, Any]]],
        model_id: str,
        task_n: str,
        dataset_name: str,
        runtime_pipeline: bool = True,
        generation_params=DEFAULT_GENERATION_PARAMS,
        inference_backend: Optional[WXORuntimeAdapter] = None,
        resource_map: Optional[ResourceMap] = None,
    ):

        self.metrics_client = get_provider(
            model_id=model_id, params=generation_params, referenceless_eval=True
        )

        # Auto-detect spec-free mode when no API specs provided
        has_specs = api_spec is not None and len(api_spec) > 0
        if has_specs:
            # Full mode: use standard metrics with tool specs
            self.pipeline = ReflectionPipeline(
                metrics_client=self.metrics_client,
                general_metrics=[METRIC_GENERAL_HALLUCINATION_CHECK],
                function_metrics=[METRIC_FUNCTION_SELECTION_APPROPRIATENESS],
                parameter_metrics=None,
                runtime_pipeline=runtime_pipeline,
            )
        else:
            # Spec-free mode: use only spec-free metrics
            rich.print(
                f"[yellow][b][Task-{task_n}] Running in spec-free mode with conversation-grounded metrics only"
            )
            self.pipeline = ReflectionPipeline(
                metrics_client=self.metrics_client,
                general_metrics=list(TOOL_SPEC_FREE_METRICS),
                function_metrics=None,
                parameter_metrics=None,
                runtime_pipeline=runtime_pipeline,
            )

        self.task_n = task_n
        self.dataset_name = dataset_name

        self.apis_specs = (
            [ToolSpec.model_validate(spec) for spec in api_spec]
            if api_spec
            else []
        )

        # Extract ResourceMap from inference_backend if not provided
        # This enables automatic filtering of sub-agent calls in WXO environments
        self.resource_map = resource_map or _extract_resource_map_from_backend(
            inference_backend
        )

    @staticmethod
    def fmt_tool_call(tool_id, tool_call_name, arguments, context):
        call = {
            "call": {
                "id": tool_id,
                "type": "function",
                "function": {
                    "name": tool_call_name,
                    "arguments": arguments,
                },
            },
            "context": context,
        }

        return call

    @staticmethod
    def fmt_msgs_referenceless(
        messages: List[Message],
        resource_map: Optional[ResourceMap] = None,
    ) -> List[Mapping[str, Any]]:
        """Assume that the last item in the `messages` array is the tool call, and preceding items
        in the messages array is the context.

        Args:
            messages: List of conversation messages
            resource_map: Optional ResourceMap to filter out sub-agent collaboration calls

        Returns:
            List of formatted tool call examples, excluding transfer_to_* and sub-agent calls
        """
        examples = []
        processed_data = [
            {
                k: msg.model_dump().get(k)
                for k in ["role", "content", "type"]
                if k in msg.model_dump()
            }
            for msg in messages
        ]

        for idx, message in enumerate(processed_data):
            role = message["role"]
            content = message["content"]
            context = processed_data[:idx]

            if role == "assistant" and message["type"] == "tool_call":
                tool_call_msg = json.loads(content)
                tool_name = tool_call_msg["name"]

                # Skip transfer_to_* pattern
                if tool_name.startswith("transfer_to"):
                    continue

                # Skip sub-agent collaboration calls
                # Check if tool name matches any agent name in ResourceMap
                if resource_map and tool_name in resource_map.all_agents:
                    continue

                call = ReferencelessEvaluation.fmt_tool_call(
                    tool_id=tool_call_msg.get("id", "1"),
                    tool_call_name=tool_name,
                    arguments=json.dumps(tool_call_msg["args"]),
                    context=context,
                )
                examples.append(call)

        return examples

    def _run_pipeline(self, examples: List[Mapping[str, Any]]):
        results = []
        for example in examples:
            result = self.pipeline.run_sync(
                conversation=example["context"],
                inventory=self.apis_specs,
                call=example["call"],
                continue_on_static=False,
                retries=2,
            )
            result_dict = result.model_dump()
            results.append(result_dict)

        return results

    def run(self, examples: List[Mapping[str, str]], verbose=False):
        """`examples` should be an array where each element is formatted:

        call = {
            "call": {
                "id": tool_call_msg.get("id", "1"),
                "type": "function",
                "function": {
                    "name": tool_call_msg["name"],
                    "arguments": json.dumps(tool_call_msg["args"]),
                },
            },
            "context": context,
        }

        Note: Sub-agent collaboration calls are filtered out in fmt_msgs_referenceless
        when resource_map is available, so they won't appear in examples.
        """

        examples = [
            {
                "call": ToolCall.model_validate(ex["call"]),
                "context": ex["context"],
            }
            for ex in examples
        ]

        if verbose:
            rich.print(
                f"[yellow][b][Task-{self.task_n}] There are {len(examples)} examples to analyze"
            )
        results = self._run_pipeline(examples)

        return results
