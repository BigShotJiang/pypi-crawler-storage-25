"""LiteLLM Provider for unified access to multiple LLM providers.

LiteLLM supports 100+ LLMs including OpenAI, Azure, Anthropic, Cohere,
Replicate, HuggingFace, and more with a unified interface.
"""

from __future__ import annotations

import json
import logging
import time
import uuid
from typing import Any, Dict, List, Optional, Sequence

try:
    import litellm
    from litellm import completion, embedding
    from litellm.exceptions import (
        APIConnectionError,
        AuthenticationError,
        BadRequestError,
        RateLimitError,
        ServiceUnavailableError,
        Timeout,
    )

    LITELLM_AVAILABLE = True
except ImportError:
    litellm = None
    LITELLM_AVAILABLE = False

    # Define placeholder exceptions for type hints when litellm is not installed
    class APIConnectionError(Exception):
        pass

    class APIError(Exception):
        pass

    class AuthenticationError(Exception):
        pass

    class BadRequestError(Exception):
        pass

    class RateLimitError(Exception):
        pass

    class ServiceUnavailableError(Exception):
        pass

    class Timeout(Exception):
        pass


from agentops.service_provider.provider import Provider
from agentops.type import ChatCompletions, Choice, Message

logger = logging.getLogger(__name__)


def _truncate(value: Any, max_len: int = 1000) -> str:
    """Truncate a value to a maximum length for logging."""
    if value is None:
        return ""
    s = str(value)
    return (
        s
        if len(s) <= max_len
        else s[:max_len] + f"... [truncated {len(s) - max_len} chars]"
    )


class LiteLLMProvider(Provider):
    """Provider that uses LiteLLM for unified access to multiple LLM providers.

    LiteLLM supports 100+ LLMs including OpenAI, Azure, Anthropic, Cohere,
    Replicate, HuggingFace, and more with a unified interface.

    Attributes:
        model: The model identifier for chat completions.
        embedding_model: Optional separate model for embeddings.
        api_key: API key for the provider.
        api_base: Custom API base URL.
        api_version: API version (for Azure).
        timeout: Request timeout in seconds.
        num_retries: Number of retries for failed requests.
        system_prompt: Optional system prompt to prepend to conversations.
        fallbacks: Optional list of fallback models.
    """

    def __init__(
        self,
        model: str,
        api_key: Optional[str] = None,
        api_base: Optional[str] = None,
        api_version: Optional[str] = None,
        timeout: int = 60,
        num_retries: int = 2,
        system_prompt: Optional[str] = None,
        embedding_model: Optional[str] = None,
        fallbacks: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        """Initialize LiteLLM provider.

        Args:
            model: Model identifier (e.g., "gpt-4", "claude-3-opus", "command-nightly").
                   Use provider prefixes for clarity: "openai/gpt-4", "anthropic/claude-3".
            api_key: API key for the provider (optional, can use env vars).
            api_base: Custom API base URL (optional).
            api_version: API version (optional, for Azure).
            timeout: Request timeout in seconds (default: 60).
            num_retries: Number of retries for failed requests (default: 2).
            system_prompt: Optional system prompt to prepend to conversations.
            embedding_model: Separate model for embeddings (e.g., "text-embedding-ada-002").
                            If not specified, uses the main model.
            fallbacks: List of fallback models if primary fails
                      (e.g., ["gpt-3.5-turbo", "claude-instant-1"]).
            metadata: Additional metadata for logging and tracking.
            **kwargs: Additional parameters to pass to litellm.completion().
        """
        super().__init__()

        if not LITELLM_AVAILABLE:
            raise ImportError(
                "litellm is not installed. Install it with: pip install litellm"
            )

        self.model = model
        self.embedding_model = embedding_model
        self.api_key = api_key
        self.api_base = api_base
        self.api_version = api_version
        self.timeout = timeout
        self.num_retries = num_retries
        self.system_prompt = system_prompt
        self.fallbacks = fallbacks
        self.metadata = metadata or {}
        self.extra_kwargs = kwargs

        logger.info(
            "[LiteLLMProvider] Initialized with model=%s, embedding_model=%s, timeout=%s, num_retries=%s",
            self.model,
            self.embedding_model,
            self.timeout,
            self.num_retries,
        )

    def _build_common_kwargs(
        self, params: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Build common kwargs for LiteLLM API calls.

        Args:
            params: Optional parameters to merge.

        Returns:
            Dictionary of kwargs for LiteLLM.
        """
        kwargs: Dict[str, Any] = {
            "timeout": self.timeout,
            "num_retries": self.num_retries,
        }

        # Add optional parameters if set
        if self.api_key:
            kwargs["api_key"] = self.api_key
        if self.api_base:
            kwargs["api_base"] = self.api_base
        if self.api_version:
            kwargs["api_version"] = self.api_version
        if self.fallbacks:
            kwargs["fallbacks"] = [{"model": m} for m in self.fallbacks]
        if self.metadata:
            kwargs["metadata"] = self.metadata

        # Merge extra kwargs from constructor
        kwargs.update(self.extra_kwargs)

        # Merge params from method call (takes precedence)
        if params:
            kwargs.update(params)

        return kwargs

    def chat(
        self,
        messages: Sequence[Dict[str, str]],
        params: Optional[Dict[str, Any]] = None,
    ) -> ChatCompletions:
        """Send chat completion request via LiteLLM.

        Args:
            messages: List of message dictionaries with 'role' and 'content'.
            params: Optional parameters to override defaults (temperature, max_tokens, etc.).

        Returns:
            ChatCompletions object with response.

        Raises:
            AuthenticationError: If API key is invalid.
            RateLimitError: If rate limit is exceeded.
            BadRequestError: If request is malformed.
            APIConnectionError: If connection to API fails.
            Timeout: If request times out.
            APIError: For other API errors.
        """
        request_id = str(uuid.uuid4())
        t0 = time.time()

        # Build kwargs
        kwargs = self._build_common_kwargs(params)
        kwargs["model"] = self.model
        kwargs["messages"] = list(messages)

        # Get last user message for logging
        last_user = next(
            (
                m.get("content", "")
                for m in reversed(list(messages))
                if m.get("role") == "user"
            ),
            "",
        )

        logger.debug(
            "[LiteLLMProvider] Sending chat request | request_id=%s model=%s params=%s input_preview=%s",
            request_id,
            self.model,
            json.dumps(
                {
                    k: v
                    for k, v in kwargs.items()
                    if k not in ("messages", "api_key")
                },
                sort_keys=True,
                ensure_ascii=False,
                default=str,
            ),
            _truncate(last_user, 200),
        )

        response = None
        try:
            response = completion(**kwargs)  # type: ignore[possibly-undefined]
            duration_ms = int((time.time() - t0) * 1000)

            # Extract response details for logging
            content = (
                response.choices[0].message.content if response.choices else ""
            )
            finish_reason = (
                response.choices[0].finish_reason if response.choices else None
            )
            usage = getattr(response, "usage", None)
            usage_dict = (
                {
                    "prompt_tokens": getattr(usage, "prompt_tokens", None),
                    "completion_tokens": getattr(
                        usage, "completion_tokens", None
                    ),
                    "total_tokens": getattr(usage, "total_tokens", None),
                }
                if usage
                else {}
            )

            logger.debug(
                "[LiteLLMProvider] Chat response received | request_id=%s duration_ms=%s finish_reason=%s usage=%s output_preview=%s",
                request_id,
                duration_ms,
                finish_reason,
                json.dumps(usage_dict, sort_keys=True),
                _truncate(content, 200),
            )

            # Convert to our ChatCompletions format
            return ChatCompletions(
                choices=[
                    Choice(
                        message=Message(
                            role=choice.message.role or "assistant",
                            content=choice.message.content or "",
                        ),
                        finish_reason=choice.finish_reason,
                    )
                    for choice in response.choices
                ],
                id=response.id,
                model=response.model,
            )

        except (
            AuthenticationError,
            RateLimitError,
            BadRequestError,
            APIConnectionError,
            Timeout,
            ServiceUnavailableError,
        ) as e:
            duration_ms = int((time.time() - t0) * 1000)
            logger.exception(
                "[LiteLLMProvider] Chat request failed | request_id=%s error_type=%s duration_ms=%s error=%s",
                request_id,
                type(e).__name__,
                duration_ms,
                str(e),
            )
            raise
        except Exception as e:
            duration_ms = int((time.time() - t0) * 1000)
            logger.exception(
                "[LiteLLMProvider] Chat request failed unexpectedly | request_id=%s error_type=%s duration_ms=%s error=%s",
                request_id,
                type(e).__name__,
                duration_ms,
                str(e),
            )
            raise

    def encode(self, sentences: List[str]) -> List[List[float]]:
        """Encode sentences to embeddings using LiteLLM.

        Args:
            sentences: List of text strings to encode.

        Returns:
            List of embedding vectors.

        Raises:
            ValueError: If no embedding model is configured.
        """
        if not LITELLM_AVAILABLE:
            raise ImportError(
                "litellm is not installed. Install it with: pip install litellm"
            )

        # Use embedding_model if specified, otherwise fall back to model
        embed_model = self.embedding_model or self.model

        request_id = str(uuid.uuid4())
        t0 = time.time()

        # Build kwargs for embedding
        kwargs: Dict[str, Any] = {
            "model": embed_model,
            "input": sentences,
            "timeout": self.timeout,
        }

        if self.api_key:
            kwargs["api_key"] = self.api_key
        if self.api_base:
            kwargs["api_base"] = self.api_base

        logger.debug(
            "[LiteLLMProvider] Sending embedding request | request_id=%s model=%s num_inputs=%s",
            request_id,
            embed_model,
            len(sentences),
        )

        try:
            response = embedding(**kwargs)  # type: ignore[possibly-undefined]
            duration_ms = int((time.time() - t0) * 1000)

            # Extract embeddings from response
            vectors = [item["embedding"] for item in response.data]

            logger.debug(
                "[LiteLLMProvider] Embedding response received | request_id=%s duration_ms=%s num_vectors=%s",
                request_id,
                duration_ms,
                len(vectors),
            )

            return vectors

        except Exception as e:
            duration_ms = int((time.time() - t0) * 1000)
            logger.exception(
                "[LiteLLMProvider] Embedding request failed | request_id=%s error_type=%s duration_ms=%s",
                request_id,
                type(e).__name__,
                duration_ms,
            )
            raise

    def get_supported_models(self) -> List[str]:
        """Get list of models supported by LiteLLM.

        Returns:
            List of supported model names.
        """
        if not LITELLM_AVAILABLE or litellm is None:
            return []

        try:
            return (
                list(litellm.model_list)
                if hasattr(litellm, "model_list")
                else []
            )
        except Exception:
            return []

    def get_model_cost(
        self, model: Optional[str] = None
    ) -> Optional[Dict[str, float]]:
        """Get cost information for a model.

        Args:
            model: Model name (defaults to self.model).

        Returns:
            Dictionary with input_cost_per_token and output_cost_per_token,
            or None if not available.
        """
        if not LITELLM_AVAILABLE or litellm is None:
            return None

        model_name = model or self.model
        try:
            cost_info = litellm.get_model_cost_map(url="")
            if model_name in cost_info:
                return cost_info[model_name]
        except Exception:
            pass
        return None


if __name__ == "__main__":
    import os

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )

    print("=" * 60)
    print("LiteLLM Provider Examples")
    print("=" * 60)

    # Example 1: OpenAI via LiteLLM
    if os.environ.get("OPENAI_API_KEY"):
        print("\n1. OpenAI Chat Completion:")
        provider = LiteLLMProvider(
            model="openai/gpt-4o-mini",
            api_key=os.environ.get("OPENAI_API_KEY"),
            system_prompt="You are a helpful assistant.",
            num_retries=3,
        )
        response = provider.query("What is the capital of France?")
        print(f"   Response: {response.choices[0].message.content}")
        print("-" * 40)

        # Example: Embeddings
        print("\n2. Embeddings:")
        embed_provider = LiteLLMProvider(
            model="openai/gpt-4o-mini",
            embedding_model="openai/text-embedding-3-small",
            api_key=os.environ.get("OPENAI_API_KEY"),
        )
        embeddings = embed_provider.encode(["Hello world", "How are you?"])
        print(f"   Generated {len(embeddings)} embeddings")
        print(f"   Embedding dimension: {len(embeddings[0])}")
        print("-" * 40)

        # Example 3: With fallbacks
        print("\n3. With Fallback Models:")
        provider = LiteLLMProvider(
            model="openai/gpt-4o-mini",
            api_key=os.environ.get("OPENAI_API_KEY"),
            fallbacks=["openai/gpt-3.5-turbo"],
        )
        response = provider.query("What is 2+2?")
        print(f"   Response: {response.choices[0].message.content}")
        print("-" * 40)

    print("\n" + "=" * 60)
    print("Examples completed!")
    print("=" * 60)
