from typing import Any, Dict, List, Optional, Sequence

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)

from agentops.service_provider.provider import Provider
from agentops.type import ChatCompletions, Choice, Message
from agentops.utils.rich_utils import RichLogger

logger = RichLogger(__name__)

DEFAULT_MODEL = "gpt-4"


class LangChainProvider(Provider):
    """Provider that uses LangChain's BaseChatModel.

    This provider accepts any LangChain chat model that inherits from
    BaseChatModel and provides a unified interface for chat completions.

    Supports any LangChain chat model including:
    - ChatOpenAI
    - ChatAnthropic
    - ChatGoogleGenerativeAI
    - ChatOllama
    - And any other BaseChatModel implementation
    """

    def __init__(
        self,
        model: Optional[BaseChatModel] = None,
        model_name: Optional[str] = None,
        system_prompt: Optional[str] = None,
        **kwargs,
    ):
        """Initialize LangChainProvider.

        Args:
            model: A LangChain BaseChatModel instance. If None, creates a default ChatOpenAI model.
            model_name: Model name override or name to use for default model.
                       If model is provided and model_name is None, extracts from model attributes.
                       If neither provided, uses DEFAULT_MODEL.
            system_prompt: Optional system prompt to prepend to conversations
        """
        super().__init__()
        if kwargs:
            logger.debug(
                f"LangChainProvider ignoring extra kwargs: {list(kwargs.keys())}"
            )

        self.system_prompt = system_prompt

        # Initialize model if not provided
        if model is None:
            model_name = model_name or DEFAULT_MODEL
            try:
                from langchain_openai import ChatOpenAI

                self.model = ChatOpenAI(model=model_name, temperature=0)
            except ImportError as e:
                raise TypeError(
                    "No model was passed and langchain_openai is not installed. "
                    "For default model, install langchain with uv sync --extra demo"
                ) from e
        else:
            self.model = model

        # Determine model_name
        if model_name is not None:
            self.model_name = model_name
        else:
            self.model_name = (
                getattr(self.model, "model_name", None)
                or getattr(self.model, "model_id", None)
                or "<unknown-model>"
            )

        logger.info(
            f"LangChainProvider initialized with model: {self.model_name}",
        )

    def _convert_to_langchain_messages(
        self, messages: Sequence[Dict[str, str]]
    ) -> List[BaseMessage]:
        """Convert agentops message format to LangChain message format.

        Args:
            messages: List of messages in agentops format

        Returns:
            List of LangChain BaseMessage objects
        """
        lc_messages = []

        for msg in messages:
            role = msg.get("role", "")
            content = msg.get("content", "")

            if role == "system":
                lc_messages.append(SystemMessage(content=content))
            elif role == "user":
                lc_messages.append(HumanMessage(content=content))
            elif role == "assistant":
                lc_messages.append(AIMessage(content=content))
            elif role == "tool":
                # Tool messages need a tool_call_id
                tool_call_id = msg.get("tool_call_id", "")
                lc_messages.append(
                    ToolMessage(content=content, tool_call_id=tool_call_id)
                )
            else:
                # Default to human message for unknown roles
                logger.warning(
                    f"Unknown role '{role}', treating as user message"
                )
                lc_messages.append(HumanMessage(content=content))

        return lc_messages

    def chat(
        self,
        messages: Sequence[Dict[str, str]],
        params: Optional[Dict[str, Any]] = None,
    ) -> ChatCompletions:
        """Send a chat request using the LangChain BaseChatModel.

        Args:
            messages: List of messages in the conversation
            params: Optional parameters to override defaults

        Returns:
            ChatCompletions object with the model response
        """
        # Convert messages to LangChain format
        lc_messages = self._convert_to_langchain_messages(messages)

        params = params or {}

        # Call the model
        try:
            # Use invoke() method which is the standard LangChain interface
            response = self.model.invoke(lc_messages, **params)

            # Extract content from response
            if isinstance(response, AIMessage):
                content = response.content
            elif hasattr(response, "content"):
                content = response.content
            else:
                content = str(response)

            # Ensure content is a string
            if isinstance(content, list):
                # If content is a list, join it or take first element
                content = str(content[0]) if content else ""
            elif not isinstance(content, str):
                content = str(content)

            # Convert response to agentops format
            choices = [
                Choice(
                    message=Message(
                        role="assistant",
                        content=content,
                    ),
                    finish_reason="stop",
                )
            ]

            return ChatCompletions(
                choices=choices,
                id="",  # LangChain doesn't provide request IDs by default
                model=self.model_name,
            )

        except Exception as e:
            logger.error("Error calling LangChain model: %s", e)
            raise

    def encode(self, sentences: List[str]) -> List[list]:
        """Encode sentences to embeddings.

        Note: This provider is for chat models, not embedding models.
        Use a LangChain Embeddings model directly if you need embeddings.

        Args:
            sentences: List of sentences to encode

        Raises:
            NotImplementedError: This method is not implemented
        """
        raise NotImplementedError(
            "LangChainProvider does not implement encode(). "
            "Use a LangChain Embeddings model for embeddings."
        )
