import glob
import json
import os
import re
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from enum import unique
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

from rich import print as rich_print
from rich.progress import Progress

from agentops.arg_configs import TestConfig
from agentops.clients import Clients
from agentops.service_provider import LOGGING_ENABLED
from agentops.utils.rich_utils import pretty_print, warn


def discover_tests(
    test_paths: List[str], recursive_search: bool = False
) -> List[str]:
    """
    Discover test cases from the given test paths.

    This function searches for JSON test case files in the provided paths.
    When recursive_search is enabled, it will search through all subdirectories
    recursively. Otherwise, it will only search the top level of each directory.

    Args:
        test_paths: List of paths to search for test cases
        recursive_search: Whether to search recursively in subdirectories

    Returns:
        List of unique test case names
    """
    test_cases = []
    for test_path in test_paths:
        # Check if the path exists
        if not glob.glob(test_path):
            rich_print(
                f"[bold yellow]Warning: Path '{test_path}' does not exist. Skipping.[/bold yellow]"
            )
            continue

        if os.path.isdir(test_path):
            if recursive_search:
                # Use ** pattern for recursive search
                pattern = os.path.join(test_path, "**", "*.json")
                found_files = sorted(glob.glob(pattern, recursive=True))
                rich_print(
                    f"Found {len(found_files)} files in '{test_path}' (recursive search)"
                )
                test_cases.extend(found_files)
            else:
                # Original behavior for non-recursive search
                pattern = os.path.join(test_path, "*.json")
                found_files = sorted(glob.glob(pattern))
                rich_print(
                    f"Found {len(found_files)} files in '{test_path}' (non-recursive)"
                )
                test_cases.extend(found_files)
        else:
            # If it's a file pattern, just use it directly
            found_files = sorted(glob.glob(test_path))
            test_cases.extend(found_files)

    # Filter out non-JSON files and agent.json files
    filtered_cases = [
        tc
        for tc in test_cases
        if tc.endswith(".json") and not tc.endswith("agent.json")
    ]

    # create mapping of test case name to file path
    unique_files_map: dict[str, str] = {}

    for f in filtered_cases:
        name = Path(f).stem
        if name not in unique_files_map:
            unique_files_map[name] = f
        else:
            rich_print(
                f"[bold red]Duplicate test case name detected:[/bold red] "
                f"'{name}' (skipping file '{f}')"
            )

    unique_files = list(unique_files_map.values())
    rich_print(
        f"[bold green]Discovered {len(unique_files)} test cases in total[/bold green]"
    )
    return unique_files


def get_test_tags(test_case_path: str) -> List[str]:
    """
    Extract tags from a single test case JSON file.

    Args:
        test_case_path: Path to the test case JSON file

    Returns:
        List of tags found in the test case, or empty list if file can't be read
    """
    try:
        with open(test_case_path, "r") as f:
            test_data = json.load(f)
        return test_data.get("tags", [])
    except (json.JSONDecodeError, FileNotFoundError):
        pretty_print(
            warn(
                message=f"Skipping the following test case because of a parsing issue: {test_case_path}"
            )
        )
        return []


def build_tag_mapping(
    test_paths: List[str],
    filter_tags: Optional[List[str]] = None,
    return_stems: bool = False,
    prefix_dir: Optional[Path] = None,
) -> Dict[str, List[str]]:
    """
    Build a mapping of tags to test files.

    Args:
        test_paths: List of test file paths
        filter_tags: Optional list of tags to filter by. If None, discovers all tags.
        return_stems: If True, returns test names (stems). If False, returns full paths.
        prefix_dir: Optional directory to prepend to relative paths for resolution.

    Returns:
        Dict mapping tag names to lists of test paths or names

    Examples:
        # Discover all tags, return paths
        >>> build_tag_mapping(test_paths)
        {'tag1': ['path/to/test1.json', 'path/to/test2.json'], 'tag2': [...]}

        # Filter specific tags, return paths
        >>> build_tag_mapping(test_paths, filter_tags=['hard', 'easy'])
        {'hard': ['path/to/test1.json'], 'easy': ['path/to/test2.json']}

        # Discover all tags, return test names
        >>> build_tag_mapping(test_paths, return_stems=True)
        {'tag1': ['test1', 'test2'], 'tag2': ['test3']}

        # Resolve relative paths with prefix_dir
        >>> build_tag_mapping(['test1.json'], prefix_dir=Path('/base'))
        {'tag1': ['/base/test1.json']}
    """
    # Resolve paths if prefix_dir provided
    if prefix_dir:
        resolved_paths = []
        for test_path in test_paths:
            if Path(test_path).is_absolute():
                resolved_paths.append(test_path)
            else:
                abs_path = prefix_dir / test_path
                resolved_paths.append(
                    str(abs_path) if abs_path.exists() else test_path
                )
        test_paths = resolved_paths

    if filter_tags:
        # Filtered mode: only include specified tags
        filter_tags_set = set(filter_tags)
        tag_to_tests: Dict[str, List[str]] = {tag: [] for tag in filter_tags}

        for test_path in test_paths:
            tags = get_test_tags(test_path)
            matching_tags = set(tags) & filter_tags_set

            for tag in matching_tags:
                value = Path(test_path).stem if return_stems else test_path
                tag_to_tests[tag].append(value)
    else:
        # Discovery mode: find all tags
        tag_to_tests = {}

        for test_path in test_paths:
            tags = get_test_tags(test_path)
            value = Path(test_path).stem if return_stems else test_path

            for tag in tags:
                if tag not in tag_to_tests:
                    tag_to_tests[tag] = []
                tag_to_tests[tag].append(value)

    return tag_to_tests


def filter_tests(test_cases: List[str], config_tags: List[str]) -> List[str]:
    """
    Given a set of test cases and a user-passed tag, filter only on test cases that have said tag.

    Args:
        test_cases: List of paths to search for test cases
        config_tags: List of tags to filter by

    Returns:
        List of test case paths that match any of the tags
    """
    if not config_tags:
        return test_cases

    pretty_print(
        f"Filtering test cases by tags: {', '.join(config_tags)}",
        style="bold blue",
    )

    # Use build_tag_mapping to get tag-to-tests mapping
    tag_to_tests = build_tag_mapping(test_cases, filter_tags=config_tags)

    # Flatten to get unique test cases that match any of the tags
    filtered_test_cases = []
    seen = set()
    for test_paths in tag_to_tests.values():
        for test_path in test_paths:
            if test_path not in seen:
                seen.add(test_path)
                filtered_test_cases.append(test_path)

    return filtered_test_cases


def _removesuffix(s: str, suf: str) -> str:
    """Remove suffix from string (for Python < 3.9 compatibility)"""
    return s[: -len(suf)] if s.endswith(suf) else s


def get_available_runs(output_dir: str) -> Dict[str, Set[int]]:
    """
    Get available runs from the output directory.

    Args:
        output_dir: Output directory path

    Returns:
        Dictionary mapping test case stems to sets of run numbers
    """
    available_runs = defaultdict(set)
    for f in glob.glob(os.path.join(output_dir, "messages", "*.messages.json")):
        # strip the fixed tail
        name = _removesuffix(os.path.basename(f), ".messages.json")
        # match either "<stem>" (single run) OR "<stem>.runN" (multi-run)
        m = re.match(r"^(?P<stem>.+?)(?:\.run(?P<run>\d+))?$", name)
        if not m:
            continue
        stem = m.group("stem")
        run_num = int(m.group("run") or 1)  # no suffix ⇒ run 1
        available_runs[stem].add(run_num)

    return available_runs


def enumerate_jobs(
    test_cases: List[str],
    n_runs: int,
    skip_available_results: bool,
    output_dir: str,
) -> List[Tuple[int, str, int]]:
    """
    Enumerate jobs to be run.

    Args:
        test_cases: List of test case file paths
        n_runs: Number of runs per test case
        skip_available_results: Whether to skip available results
        output_dir: Output directory path

    Returns:
        List of tuples (task_n, test_case, run_idx)
    """
    jobs = []
    task_n = 0

    available_runs = (
        get_available_runs(output_dir) if skip_available_results else {}
    )

    for test_case in test_cases:
        stem = Path(test_case).stem

        for run_idx in range(n_runs):
            run_number = run_idx + 1

            # Skip precisely this (test, run) if results exist
            if skip_available_results and (
                run_number in available_runs.get(stem, set())
            ):
                print(
                    f"Skipping {stem} run {run_number} as results already exist."
                )
                continue

            jobs.append((task_n, test_case, run_idx))
            task_n += 1

    return jobs


def run_jobs(
    jobs: List[Tuple[int, str, int]],
    config: TestConfig,
    clients: Clients,
    process_func: Callable,
    num_workers: int,
) -> List[Any]:
    """
    Run jobs using ThreadPoolExecutor.

    Args:
        jobs: List of jobs to run
        config: Test configuration
        clients: Tuple of clients (wxo_client, llmaaj_provider, resource_map, inference_backend, llm_user)
        process_func: Function to process each job
        num_workers: Number of worker threads

    Returns:
        List of results from all jobs
    """

    if config.num_workers > 1 and config.enable_manual_user_input:
        rich_print(
            "[bold yellow]Warning ⚠️: Manual user input is disabled for parallel execution.[/bold yellow]"
        )
        config.enable_manual_user_input = (
            False  # disable manual user input for parallel execution
        )

    executor = ThreadPoolExecutor(max_workers=num_workers)
    futures = []

    for task_n, test_case, run_idx in jobs:
        future = executor.submit(
            process_func,
            task_n,
            test_case,
            config,
            clients.inference_backend,
            clients.resource_map,
            clients.llm_user,
            clients.llmaaj_provider,
            run_idx,
        )
        futures.append(((test_case, run_idx), future))

    results = []

    if futures:
        if LOGGING_ENABLED:
            # No progress bar when logging - just process tasks
            for (test_case, run_idx), future in futures:
                try:
                    results.extend(future.result())
                except Exception as e:
                    import traceback

                    rich_print(f"test case {test_case} fails with {e}")

                    traceback.print_exc()
        else:
            with Progress() as progress:
                task1 = progress.add_task(
                    f"[purple]Evaluating {len(futures)} tasks...",
                    total=len(futures),
                )
                for (test_case, run_idx), future in futures:
                    try:
                        results.extend(future.result())
                    except Exception as e:
                        import traceback

                        rich_print(f"test case {test_case} fails with {e}")

                        traceback.print_exc()
                    finally:
                        progress.update(task1, advance=1)

    return results
