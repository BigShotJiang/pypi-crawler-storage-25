"""
Multi-Directory Tool Failure Analyzer

This module analyzes tool failures across multiple results directories and displays
comparison reports showing failure counts per directory. It automatically discovers
nested benchmark structures (e.g., benchmark_results/date/model_name/) and creates
abbreviated column names with dates for better readability.

Features:
    - Recursive directory discovery for nested benchmark structures
    - Automatic date extraction from directory paths
    - Abbreviated provider/model names (e.g., groq_gpt4, wx_gpt35)
    - Rich console output with formatted tables
    - Optional detailed test case tracking

Usage:
    # Specify individual directories (comma-separated)
    python -m agentops.broken_test_analysis --results_dirs "./results1,./results2,./results3"
    
    # Analyze all subdirectories in a parent directory (recommended for benchmarks)
    python -m agentops.broken_test_analysis --parent_dir ./benchmark_results
    
    # With detailed test case tracking
    python -m agentops.broken_test_analysis --parent_dir ./benchmark_results --include_test_cases true
    
    # With verbose output (show timeline tables)
    python -m agentops.broken_test_analysis --parent_dir ./benchmark_results --verbose true
"""

import json
import re
import sys
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Union

import pandas as pd
from jsonargparse import CLI
from rich.console import Console
from rich.table import Table

from agentops.type import ContentType
from agentops.utils import TestCaseResources


@dataclass
class MultiDirAnalyzeConfig:
    """Configuration for multi-directory tool failure analysis"""

    results_dirs: Union[str, list[str]] = field(
        default="",
        metadata={
            "help": "Comma-separated list of results directories to analyze"
        },
    )
    parent_dir: str = field(
        default="",
        metadata={
            "help": "Parent directory containing multiple result subdirectories (alternative to results_dirs)"
        },
    )
    output: str = field(
        default="tool_failures_comparison",
        metadata={
            "help": "Output file base name (deprecated, kept for compatibility)"
        },
    )
    include_test_cases: bool = field(
        default=False,
        metadata={"help": "Include test case names in the detailed report"},
    )
    verbose: bool = field(
        default=False,
        metadata={
            "help": "Generate verbose timeline tables (tool failures and test success by directory)"
        },
    )
    metrics: Union[str, list[str]] = field(
        default="is_success",
        metadata={
            "help": "Comma-separated list of metrics to analyze from summary (e.g., 'is_success')"
        },
    )

    def __post_init__(self):
        """Parse comma-separated results_dirs and metrics into lists"""
        if isinstance(self.results_dirs, str) and self.results_dirs:
            self.results_dirs = [
                d.strip() for d in self.results_dirs.split(",") if d.strip()
            ]
        elif not self.results_dirs:
            self.results_dirs = []

        if isinstance(self.metrics, str) and self.metrics:
            self.metrics = [
                m.strip() for m in self.metrics.split(",") if m.strip()
            ]
        elif not self.metrics:
            self.metrics = ["is_success"]


class MultiDirectoryToolFailureAnalyzer:
    """Analyzes tool failures across multiple results directories"""

    def __init__(self, config: MultiDirAnalyzeConfig):
        self.config = config
        self.tool_failures = defaultdict(lambda: defaultdict(int))
        self.tool_test_failures = defaultdict(
            lambda: defaultdict(list)
        )  # tool -> dir -> [test_names]
        self.tool_calls = defaultdict(
            lambda: defaultdict(int)
        )  # tool -> dir -> total_calls
        self.tool_failure_reasons = defaultdict(
            lambda: defaultdict(int)
        )  # tool -> reason -> count
        self.tool_tests = defaultdict(
            set
        )  # tool -> set of test names that use this tool
        # Generic metric tracking: metric_name -> test_name -> dir -> value
        self.test_metrics = defaultdict(
            lambda: defaultdict(lambda: defaultdict(float))
        )
        # Track tests with perfect tool metrics but incomplete journey
        self.perfect_tools_incomplete_journey = defaultdict(
            lambda: defaultdict(dict)
        )  # test_name -> dir -> metrics
        self.console = Console()
        self.dir_metadata = {}  # Maps column names to full directory info

    def _extract_date_and_model(self, dir_path: str) -> tuple[str, str, str]:
        """
        Extract date and model information from directory path.

        Expected format: benchmark_results/date/model_name/

        Returns:
            Tuple of (date, abbreviated_model, full_column_name)
        """
        path = Path(dir_path)
        parts = path.parts

        # Try to find date pattern (YYYY-MM-DD or similar)
        date = "unknown"
        for part in parts:
            # Match date patterns like 2024-01-15, 20240115, etc.
            if re.match(r"\d{4}[-_]?\d{2}[-_]?\d{2}", part):
                date = part
                break

        # Get model name (last directory in path)
        model_full = path.name

        # Create abbreviation for model name
        model_abbrev = self._abbreviate_model_name(model_full)

        # Create unique column name: date_model
        column_name = f"{date}_{model_abbrev}"

        return date, model_abbrev, column_name

    def _abbreviate_model_name(self, model_name: str) -> str:
        """
        Create abbreviated version of model name.

        Examples:
            groq_openai_gpt-4 -> gq_gpt4
            virtual_model_gpt-4o -> vm_gpt4o
            watsonx_openai_gpt-3.5 -> wx_gpt35
            bedrock_openai_gpt-4 -> br_gpt4
        """
        # Common provider abbreviations
        provider_abbrevs = {
            "groq": "gq",
            "openai": "oai",
            "virtual_model": "vm",
            "watsonx": "wx",
            "bedrock": "br",
            "anthropic": "ant",
            "google": "ggl",
            "azure": "az",
            "cohere": "coh",
        }

        parts = model_name.lower().replace("-", "").replace("_", " ").split()

        # Try to identify provider and model
        provider = None
        model = None

        for part in parts:
            if part in provider_abbrevs:
                provider = provider_abbrevs[part]
            elif any(
                m in part
                for m in ["gpt", "claude", "llama", "gemini", "command"]
            ):
                # Extract model name and version
                model = part
                # Simplify version numbers: gpt4o, claude3, etc.
                model = re.sub(r"[.\-_]", "", model)

        if provider and model:
            return f"{provider}_{model}"
        elif model:
            return model
        else:
            # Fallback: use first 10 chars
            return model_name[:10].replace("-", "").replace("_", "")

    def analyze_directory(
        self, dir_path: str, column_name: str | None = None
    ) -> dict[str, int]:
        """
        Analyze a single results directory and return tool failure counts.

        Args:
            dir_path: Path to the results directory
            column_name: Optional column name to use for tracking (defaults to dir name)

        Returns:
            Dictionary mapping tool names to failure counts
        """
        tool_counts = defaultdict(int)
        dir_name = column_name if column_name else Path(dir_path).name

        try:
            # Reuse TestCaseResources from analyze_run
            resources = TestCaseResources(dir_path)
            summary = resources.get_summary
        except Exception as e:
            self.console.print(
                f"[red]Error loading directory {dir_path}: {e}[/red]"
            )
            return tool_counts

        # Process each test case
        for test_entry in summary:
            test_name = test_entry["dataset_name"]

            # Skip summary rows
            if test_name.lower().strip() == "summary (average)":
                continue

            try:
                # Track test metrics (is_success, text_match, etc.)
                for metric in self.config.metrics:
                    metric_value = test_entry.get(metric, 0)
                    # Convert to float, handling various types
                    try:
                        if isinstance(metric_value, bool):
                            metric_value = float(metric_value)
                        elif isinstance(metric_value, str):
                            if metric_value in ("True", "False"):
                                metric_value = float(metric_value == "True")
                            else:
                                # Try to convert string to float, skip if not numeric
                                metric_value = float(metric_value)
                        else:
                            metric_value = float(metric_value)
                        self.test_metrics[metric][test_name][
                            dir_name
                        ] = metric_value
                    except (ValueError, TypeError):
                        # Skip non-numeric values
                        self.console.print(
                            f"[yellow]Warning: Skipping non-numeric value '{metric_value}' for metric '{metric}' in test '{test_name}'[/yellow]"
                        )
                        continue

                # Track cases where journey completion < 100% but tool recall and precision are 100%
                journey_completion = test_entry.get(
                    "Journey Completion %", "0%"
                )
                tool_recall = test_entry.get("Tool Call Recall", 0)
                tool_precision = test_entry.get("Tool Call Precision", 0)

                # Parse journey completion percentage
                if isinstance(journey_completion, str):
                    journey_completion = (
                        float(journey_completion.rstrip("%")) / 100
                    )
                else:
                    journey_completion = float(journey_completion)

                # Check if this is a perfect tools but incomplete journey case
                if (
                    journey_completion < 1.0
                    and tool_recall == 1.0
                    and tool_precision == 1.0
                ):
                    self.perfect_tools_incomplete_journey[test_name][
                        dir_name
                    ] = {
                        "journey_completion": journey_completion,
                        "tool_recall": tool_recall,
                        "tool_precision": tool_precision,
                        "text_match": test_entry.get("Text Match", "N/A"),
                        "is_success": test_entry.get("Journey Success", False),
                    }

                # Get analyze messages (reusing existing method)
                messages, meta = resources.get_analyze_messages(
                    test_case_name=test_name
                )

                # Extract all tool calls and track failures
                for msg in messages:
                    # Check if this is a tool call
                    if (
                        msg.message.role == "assistant"
                        and msg.message.type == ContentType.tool_call
                    ):
                        # Extract tool name
                        content = msg.message.content
                        if isinstance(content, str):
                            content = json.loads(content)
                        tool_name = content.get("name", "unknown")

                        # Track which tests use this tool
                        self.tool_tests[tool_name].add(test_name)

                        # Track total calls
                        if tool_name not in self.tool_calls:
                            self.tool_calls[tool_name] = defaultdict(int)
                        self.tool_calls[tool_name][dir_name] += 1

                        # Check if this is a failed tool call
                        if msg.reason:
                            # Handle reason being dict or list
                            if isinstance(msg.reason, dict):
                                reason = msg.reason.get("reason")
                            else:
                                # Skip if reason is not a dict
                                continue

                            if reason and reason != "irrelevant tool call":
                                # Increment failure count
                                tool_counts[tool_name] += 1

                                # Track failure reason
                                if tool_name not in self.tool_failure_reasons:
                                    self.tool_failure_reasons[tool_name] = (
                                        defaultdict(int)
                                    )
                                self.tool_failure_reasons[tool_name][
                                    reason
                                ] += 1

                                # Track test case if requested
                                if self.config.include_test_cases:
                                    self.tool_test_failures[tool_name][
                                        dir_name
                                    ].append(test_name)

            except Exception as e:
                self.console.print(
                    f"[yellow]Warning: Error processing {test_name} in {dir_path}: {e}[/yellow]"
                )
                continue

        return tool_counts

    def analyze_all(self) -> pd.DataFrame:
        """
        Analyze all directories and create comparison DataFrame.

        Returns:
            DataFrame with tool names as index and directory names as columns
        """
        self.console.print(
            f"[bold blue]Analyzing {len(self.config.results_dirs)} directories...[/bold blue]"
        )

        # Collect failures from each directory
        for dir_path in self.config.results_dirs:
            # Extract date and model info for better column naming
            date, model_abbrev, column_name = self._extract_date_and_model(
                dir_path
            )

            # Store metadata
            self.dir_metadata[column_name] = {
                "full_path": dir_path,
                "date": date,
                "model": model_abbrev,
                "original_name": Path(dir_path).name,
            }

            self.console.print(
                f"Processing: {Path(dir_path).name} -> {column_name}"
            )

            tool_counts = self.analyze_directory(dir_path, column_name)

            for tool_name, count in tool_counts.items():
                self.tool_failures[tool_name][column_name] = count

        if not self.tool_failures:
            self.console.print(
                "[yellow]No tool failures found in any directory.[/yellow]"
            )
            return pd.DataFrame()

        # Convert to DataFrame
        df = pd.DataFrame.from_dict(self.tool_failures, orient="index")
        df = df.fillna(0).astype(int)
        df.index.name = "tool_name"

        # Sort columns by date and model name
        sorted_cols = sorted(
            df.columns,
            key=lambda x: (
                self.dir_metadata.get(x, {}).get("date", "zzz"),
                self.dir_metadata.get(x, {}).get("model", "zzz"),
            ),
        )
        df = df[sorted_cols]

        # Sort by total failures
        df["total"] = df.sum(axis=1)
        df = df.sort_values("total", ascending=False)

        return df

    def display_summary(self, df: pd.DataFrame):
        """Display a rich table summary of the results"""
        if df.empty:
            return

        table = Table(title="Tool Failure Summary", show_lines=True)
        table.add_column("Tool Name", style="cyan", no_wrap=True)

        # Add columns for each directory
        for col in df.columns:
            if col != "total":
                table.add_column(col, justify="right", style="yellow")

        table.add_column("Total", justify="right", style="bold red")

        # Add rows (limit to top 20 for display)
        for tool_name, row in df.head(20).iterrows():
            row_data = [str(tool_name)]
            for col in df.columns:
                if col != "total":
                    row_data.append(str(int(row[col])))
            row_data.append(str(int(row["total"])))
            table.add_row(*row_data)

        self.console.print(table)

        if len(df) > 20:
            self.console.print(
                f"\n[dim]Showing top 20 of {len(df)} tools with failures[/dim]"
            )

    def save_report(self) -> pd.DataFrame:
        """
        Generate and display the failure report.

        Returns:
            DataFrame with the analysis results
        """
        df = self.analyze_all()

        if df.empty:
            self.console.print(
                "[yellow]No data to save. Skipping report generation.[/yellow]"
            )
            return df

        # Generate summary statistics
        summary_df = self._generate_summary_statistics()

        # Generate metric summaries for each metric
        metric_stats_dfs = {}
        metric_timeline_dfs = {}
        for metric in self.config.metrics:
            metric_timeline_dfs[metric] = self._generate_metric_timeline(metric)
            metric_stats_dfs[metric] = self._generate_metric_statistics(metric)

        # Generate perfect tools incomplete journey analysis
        perfect_tools_df = (
            self._generate_perfect_tools_incomplete_journey_report()
        )

        # Display summaries
        if self.config.verbose:
            self.display_summary(df)
        self.display_summary_statistics(summary_df)

        # Display metric summaries
        for metric in self.config.metrics:
            if self.config.verbose:
                metric_timeline_df = self._generate_metric_timeline(metric)
                if not metric_timeline_df.empty:
                    self.display_metric_timeline(metric_timeline_df, metric)

            metric_stats_df = self._generate_metric_statistics(metric)
            if not metric_stats_df.empty:
                self.display_metric_statistics(metric_stats_df, metric)

        # Display perfect tools incomplete journey analysis
        perfect_tools_df = (
            self._generate_perfect_tools_incomplete_journey_report()
        )
        if not perfect_tools_df.empty:
            self.display_perfect_tools_incomplete_journey(perfect_tools_df)

        # Display detailed test case failures if requested
        if self.config.include_test_cases:
            self.display_detailed_test_failures()

        return df

    def _generate_summary_statistics(self) -> pd.DataFrame:
        """
        Generate summary statistics table with:
        - tool_name
        - count of failures across n runs
        - number of times called
        - % of calls with failures
        - failure reasons breakdown
        - number of tests that expect this tool
        - tests that expect this tool
        """
        summary_data = []

        # Get all unique tool names from both failures and calls
        all_tools = set(self.tool_failures.keys()) | set(self.tool_calls.keys())

        for tool_name in all_tools:
            # Calculate total failures across all directories
            total_failures = sum(self.tool_failures.get(tool_name, {}).values())

            # Calculate total calls across all directories
            total_calls = sum(self.tool_calls.get(tool_name, {}).values())

            # Calculate failure percentage
            failure_percentage = (
                (total_failures / total_calls * 100) if total_calls > 0 else 0.0
            )

            # Format failure reasons breakdown
            reasons_breakdown = ""
            if tool_name in self.tool_failure_reasons:
                reason_parts = []
                for reason, count in sorted(
                    self.tool_failure_reasons[tool_name].items(),
                    key=lambda x: x[1],
                    reverse=True,
                ):
                    reason_parts.append(f"{reason} ({count})")
                reasons_breakdown = "; ".join(reason_parts)

            # Get tests that use this tool
            tests_using_tool = sorted(self.tool_tests.get(tool_name, set()))
            num_tests = len(tests_using_tool)
            tests_str = (
                ", ".join(tests_using_tool) if tests_using_tool else "N/A"
            )

            summary_data.append(
                {
                    "tool_name": tool_name,
                    "count_of_failures_across_n_runs": total_failures,
                    "number_of_times_called": total_calls,
                    "percent_of_calls_with_failures": round(
                        failure_percentage, 2
                    ),
                    "failure_reasons": reasons_breakdown,
                    "num_tests_expecting_tool": num_tests,
                    "tests_expecting_tool": tests_str,
                }
            )

        # Create DataFrame
        summary_df = pd.DataFrame(summary_data)
        if not summary_df.empty:
            # Filter to only include tools with failures
            summary_df = summary_df[
                summary_df["count_of_failures_across_n_runs"] > 0
            ]
            # First, sort by failure count to get top 20
            summary_df = summary_df.sort_values(
                "count_of_failures_across_n_runs", ascending=False
            )
            # Take top 20 by failure count
            summary_df = summary_df.head(20)
            # Then sort those 20 by failure percentage (descending)
            summary_df = summary_df.sort_values(
                "percent_of_calls_with_failures", ascending=False
            )

        return summary_df

    def display_summary_statistics(self, summary_df: pd.DataFrame):
        """Display a rich table of summary statistics (top 20 by failure count, sorted by failure %)"""
        if summary_df.empty:
            return

        table = Table(
            title="Tool Failure Summary Statistics (Top 20 by Failure Count, Sorted by Failure %)",
            show_lines=True,
        )
        table.add_column("Tool Name", style="cyan", no_wrap=True)
        table.add_column("Failures", justify="right", style="red")
        table.add_column("Total Calls", justify="right", style="blue")
        table.add_column("Failure %", justify="right", style="yellow")
        table.add_column("Failure Reasons", style="magenta")
        table.add_column("# Tests", justify="right", style="bright_blue")
        table.add_column("Tests Expecting Tool", style="green")

        # Display all rows (already limited to top 20 in _generate_summary_statistics)
        for _, row in summary_df.iterrows():
            # Truncate tests list if too long
            tests_str = str(row["tests_expecting_tool"])
            if len(tests_str) > 60:
                tests_str = tests_str[:57] + "..."

            table.add_row(
                str(row["tool_name"]),
                str(int(row["count_of_failures_across_n_runs"])),
                str(int(row["number_of_times_called"])),
                f"{row['percent_of_calls_with_failures']:.2f}%",
                str(row["failure_reasons"]),
                str(int(row["num_tests_expecting_tool"])),
                tests_str,
            )

        self.console.print("\n")
        self.console.print(table)

        self.console.print(
            f"\n[dim]Showing top 20 tools by failure count, sorted by failure %[/dim]"
        )

    def _generate_metric_timeline(self, metric: str) -> pd.DataFrame:
        """
        Generate test-level metric timeline table with:
        - test_name as rows
        - directory columns showing metric values
        - total column showing sum across all directories
        """
        if metric not in self.test_metrics or not self.test_metrics[metric]:
            return pd.DataFrame()

        # Convert to DataFrame
        df = pd.DataFrame.from_dict(self.test_metrics[metric], orient="index")
        df = df.fillna(0.0)
        df.index.name = "test_name"

        # Sort columns by date and model name (same as tool failures table)
        sorted_cols = sorted(
            df.columns,
            key=lambda x: (
                self.dir_metadata.get(x, {}).get("date", "zzz"),
                self.dir_metadata.get(x, {}).get("model", "zzz"),
            ),
        )
        df = df[sorted_cols]

        # Add total column
        df["total"] = df.sum(axis=1)

        # Sort by total (descending)
        df = df.sort_values("total", ascending=False)

        return df

    def display_metric_timeline(self, df: pd.DataFrame, metric: str):
        """Display a rich table summary of metric timeline results"""
        if df.empty:
            return

        table = Table(
            title=f"{metric.replace('_', ' ').title()} Timeline",
            show_lines=True,
        )
        table.add_column("Test Name", style="cyan", no_wrap=True)

        # Add columns for each directory
        for col in df.columns:
            if col != "total":
                table.add_column(col, justify="right", style="yellow")

        table.add_column("Total", justify="right", style="bold green")

        # Add rows (limit to top 20 for display)
        for test_name, row in df.head(20).iterrows():
            row_data = [str(test_name)]
            for col in df.columns:
                if col != "total":
                    # Display as float with 1 decimal place
                    row_data.append(f"{row[col]:.1f}")
            row_data.append(f"{row['total']:.1f}")
            table.add_row(*row_data)

        self.console.print("\n")
        self.console.print(table)

        if len(df) > 20:
            self.console.print(
                f"\n[dim]Showing top 20 of {len(df)} tests[/dim]"
            )

    def _generate_metric_statistics(self, metric: str) -> pd.DataFrame:
        """
        Generate metric summary statistics with:
        - test_name
        - number of occurrences across n runs
        - average metric value (as percentage if 0-1 range, otherwise raw average)
        """
        if metric not in self.test_metrics or not self.test_metrics[metric]:
            return pd.DataFrame()

        stats_data = []

        # Determine if this metric is in 0-1 range (should be shown as percentage)
        all_values = []
        for dir_results in self.test_metrics[metric].values():
            all_values.extend(dir_results.values())

        # Check if all values are between 0 and 1 (with some tolerance)
        is_percentage_metric = all_values and all(
            0 <= v <= 1.0001 for v in all_values
        )

        for test_name, dir_results in self.test_metrics[metric].items():
            # Count number of occurrences (directories where this test appeared)
            num_occurrences = len(dir_results)

            # Calculate average metric value
            metric_values = list(dir_results.values())
            avg_value = (
                sum(metric_values) / len(metric_values)
                if metric_values
                else 0.0
            )

            # Convert to percentage if metric is in 0-1 range
            if is_percentage_metric:
                display_value = avg_value * 100
                column_name = f"{metric}_percent"
            else:
                display_value = avg_value
                column_name = f"{metric}_avg"

            stats_data.append(
                {
                    "test_name": test_name,
                    "num_occurrences_across_n_runs": num_occurrences,
                    column_name: round(display_value, 2),
                }
            )

        # Create DataFrame
        stats_df = pd.DataFrame(stats_data)
        if not stats_df.empty:
            # Sort by metric value
            # Percentage metrics (0-1): ascending (show worst performing first)
            # Average metrics (other): descending (show highest first)
            sort_column = (
                f"{metric}_percent" if is_percentage_metric else f"{metric}_avg"
            )
            stats_df = stats_df.sort_values(
                sort_column, ascending=is_percentage_metric
            )

        return stats_df

    def display_metric_statistics(self, stats_df: pd.DataFrame, metric: str):
        """Display a rich table of metric statistics"""
        if stats_df.empty:
            return

        # Determine if this is a percentage metric or average metric
        metric_col = (
            f"{metric}_percent"
            if f"{metric}_percent" in stats_df.columns
            else f"{metric}_avg"
        )
        is_percentage = metric_col.endswith("_percent")

        table = Table(
            title=f"{metric.replace('_', ' ').title()} Statistics (Sorted by {metric.replace('_', ' ').title()})",
            show_lines=True,
        )
        table.add_column("Test Name", style="cyan", no_wrap=True)
        table.add_column("Occurrences", justify="right", style="blue")
        table.add_column(
            f"{metric.replace('_', ' ').title()}",
            justify="right",
            style="yellow",
        )

        # Display top 20 rows
        for _, row in stats_df.head(20).iterrows():
            metric_value = row[metric_col]

            # Color code based on value (only for percentage metrics)
            if is_percentage:
                if metric_value >= 80:
                    rate_style = "green"
                elif metric_value >= 50:
                    rate_style = "yellow"
                else:
                    rate_style = "red"
                value_str = f"[{rate_style}]{metric_value:.2f}%[/{rate_style}]"
            else:
                # For non-percentage metrics, just display the value
                value_str = f"{metric_value:.2f}"

            table.add_row(
                str(row["test_name"]),
                str(int(row["num_occurrences_across_n_runs"])),
                value_str,
            )

        self.console.print("\n")
        self.console.print(table)

        if len(stats_df) > 20:
            self.console.print(
                f"\n[dim]Showing top 20 of {len(stats_df)} tests (sorted by {metric}, lowest first)[/dim]"
            )

    def _generate_perfect_tools_incomplete_journey_report(self) -> pd.DataFrame:
        """
        Generate report for tests where:
        - Journey completion < 100%
        - Tool recall = 100%
        - Tool precision = 100%

        This identifies cases where the agent made all correct tool calls but failed on:
        - Text-based goals
        - Ordering/dependency issues
        - Other non-tool-related failures
        """
        if not self.perfect_tools_incomplete_journey:
            return pd.DataFrame()

        report_data = []

        for (
            test_name,
            dir_results,
        ) in self.perfect_tools_incomplete_journey.items():
            # Count occurrences across directories
            num_occurrences = len(dir_results)

            # Calculate average journey completion
            journey_completions = [
                r["journey_completion"] for r in dir_results.values()
            ]
            avg_journey_completion = (
                sum(journey_completions) / len(journey_completions)
                if journey_completions
                else 0.0
            )

            # Get text match status (most common)
            text_matches = [r["text_match"] for r in dir_results.values()]
            # Count occurrences of each text match status
            text_match_counts = {}
            for tm in text_matches:
                text_match_counts[tm] = text_match_counts.get(tm, 0) + 1
            most_common_text_match = (
                max(text_match_counts.items(), key=lambda x: x[1])[0]
                if text_match_counts
                else "N/A"
            )

            # Get directories where this occurs
            affected_dirs = ", ".join(sorted(dir_results.keys()))

            report_data.append(
                {
                    "test_name": test_name,
                    "num_occurrences": num_occurrences,
                    "avg_journey_completion_percent": round(
                        avg_journey_completion * 100, 2
                    ),
                    "tool_recall": 100.0,
                    "tool_precision": 100.0,
                    "most_common_text_match": most_common_text_match,
                    "affected_directories": affected_dirs,
                }
            )

        # Create DataFrame
        report_df = pd.DataFrame(report_data)
        if not report_df.empty:
            # Sort by journey completion (ascending - worst first)
            report_df = report_df.sort_values(
                "avg_journey_completion_percent", ascending=True
            )

        return report_df

    def display_perfect_tools_incomplete_journey(self, df: pd.DataFrame):
        """Display analysis of tests with perfect tool metrics but incomplete journey"""
        if df.empty:
            return

        table = Table(
            title="Perfect Tool Calls but Incomplete Journey (100% Recall & Precision, <100% Completion)",
            show_lines=True,
        )
        table.add_column("Test Name", style="cyan", no_wrap=True)
        table.add_column("Occurrences", justify="right", style="blue")
        table.add_column("Avg Journey %", justify="right", style="yellow")
        table.add_column("Tool Recall", justify="right", style="green")
        table.add_column("Tool Precision", justify="right", style="green")
        table.add_column("Text Match", style="magenta")
        table.add_column("Affected Dirs", style="dim")

        # Display all rows (or top 20 if too many)
        display_df = df.head(20) if len(df) > 20 else df

        for _, row in display_df.iterrows():
            # Color code journey completion
            journey_pct = row["avg_journey_completion_percent"]
            if journey_pct >= 80:
                journey_style = "yellow"
            elif journey_pct >= 50:
                journey_style = "orange1"
            else:
                journey_style = "red"

            table.add_row(
                str(row["test_name"]),
                str(int(row["num_occurrences"])),
                f"[{journey_style}]{journey_pct:.1f}%[/{journey_style}]",
                f"{row['tool_recall']:.0f}%",
                f"{row['tool_precision']:.0f}%",
                str(row["most_common_text_match"]),
                (
                    str(row["affected_directories"])[:50] + "..."
                    if len(str(row["affected_directories"])) > 50
                    else str(row["affected_directories"])
                ),
            )

        self.console.print("\n")
        self.console.print(table)

        if len(df) > 20:
            self.console.print(
                f"\n[dim]Showing top 20 of {len(df)} tests with perfect tools but incomplete journey[/dim]"
            )

        # Add interpretation note
        self.console.print("\n[bold cyan]Interpretation:[/bold cyan]")
        self.console.print("These tests show cases where the agent:")
        self.console.print(
            "  • Made all expected tool calls correctly (100% recall)"
        )
        self.console.print("  • Made no incorrect tool calls (100% precision)")
        self.console.print(
            "  • But still failed to complete the journey (< 100% completion)"
        )
        self.console.print("\n[yellow]Likely causes:[/yellow]")
        self.console.print(
            "  • Failed text-based goals (check Text Match column)"
        )
        self.console.print(
            "  • Incorrect ordering of tool calls (dependency violations)"
        )
        self.console.print(
            "  • Missing or incorrect text responses between tool calls"
        )

    def display_detailed_test_failures(self):
        """Display detailed breakdown of which tests failed for each tool in each directory"""
        if not self.tool_test_failures:
            self.console.print(
                "\n[yellow]No detailed test failure data available.[/yellow]"
            )
            return

        self.console.print("\n")
        table = Table(
            title="Detailed Test Case Failures by Tool and Directory",
            show_lines=True,
        )
        table.add_column("Tool Name", style="cyan", no_wrap=True)
        table.add_column("Directory", style="blue")
        table.add_column("Failed Tests", style="red")
        table.add_column("Count", justify="right", style="yellow")

        # Sort tools by total failure count
        tool_failure_counts = {}
        for tool_name, dir_failures in self.tool_test_failures.items():
            total_failures = sum(len(tests) for tests in dir_failures.values())
            tool_failure_counts[tool_name] = total_failures

        sorted_tools = sorted(
            tool_failure_counts.items(), key=lambda x: x[1], reverse=True
        )

        # Display top 20 tools
        for tool_name, _ in sorted_tools[:20]:
            dir_failures = self.tool_test_failures[tool_name]

            # Sort directories by failure count
            sorted_dirs = sorted(
                dir_failures.items(), key=lambda x: len(x[1]), reverse=True
            )

            for dir_name, test_cases in sorted_dirs:
                # Get unique test cases (in case of duplicates)
                unique_tests = sorted(set(test_cases))
                test_count = len(unique_tests)

                # Format test names (truncate if too long)
                tests_str = ", ".join(unique_tests)
                if len(tests_str) > 80:
                    tests_str = tests_str[:77] + "..."

                table.add_row(
                    str(tool_name), str(dir_name), tests_str, str(test_count)
                )

        self.console.print(table)

        if len(sorted_tools) > 20:
            self.console.print(
                f"\n[dim]Showing top 20 of {len(sorted_tools)} tools with test failures[/dim]"
            )


def run(config: MultiDirAnalyzeConfig):
    """Main entry point for the multi-directory tool failure analyzer"""

    def find_analyzable_dirs(
        path: Path, current_depth: int = 0, max_depth: int = 2
    ):
        """
        Recursively find directories that contain eval data.
        Searches up to max_depth levels deep, stopping at the first level
        where summary_metrics.csv is found.

        Args:
            path: Directory to search
            current_depth: Current recursion depth (0 = starting directory)
            max_depth: Maximum depth to search (default: 2 levels)

        Returns:
            List of paths to analyzable directories
        """
        found_dirs = []

        if not path.is_dir():
            return found_dirs

        # Check if current directory is analyzable
        is_analyzable = (path / "summary_metrics.csv").exists() or (
            path / "messages"
        ).exists()

        if is_analyzable:
            found_dirs.append(str(path))
            # Don't recurse into analyzable directories
            return found_dirs

        # Stop if we've reached max depth
        if current_depth >= max_depth:
            return found_dirs

        # Recurse into subdirectories
        try:
            for item in path.iterdir():
                if item.is_dir():
                    found_dirs.extend(
                        find_analyzable_dirs(item, current_depth + 1, max_depth)
                    )
        except PermissionError:
            # Skip directories we can't access
            pass

        return found_dirs

    # Handle parent_dir option - find all subdirectories recursively
    if config.parent_dir:
        parent_path = Path(config.parent_dir)
        if not parent_path.exists():
            print(
                f"Error: Parent directory does not exist: {config.parent_dir}"
            )
            sys.exit(1)

        subdirs = find_analyzable_dirs(parent_path)

        if not subdirs:
            print(
                f"Error: No valid results directories found in {config.parent_dir}"
            )
            sys.exit(1)

        config.results_dirs = sorted(subdirs)
        print(
            f"Found {len(config.results_dirs)} results directories in {config.parent_dir}"
        )
        for dir_path in config.results_dirs:
            print(f"  - {dir_path}")

    # Handle results_dirs - expand each directory to find analyzable subdirectories
    elif config.results_dirs:
        expanded_dirs = []
        for dir_path in config.results_dirs:
            path = Path(dir_path)
            if not path.exists():
                print(f"Warning: Directory does not exist: {dir_path}")
                continue

            # Check if this directory itself is analyzable
            if (path / "summary_metrics.csv").exists() or (
                path / "messages"
            ).exists():
                expanded_dirs.append(str(path))
            else:
                # Search for analyzable subdirectories (up to 2 levels deep)
                found = find_analyzable_dirs(path)
                if found:
                    expanded_dirs.extend(found)
                else:
                    print(
                        f"Warning: No analyzable directories found in {dir_path}"
                    )

        if not expanded_dirs:
            print("Error: No valid results directories found")
            sys.exit(1)

        config.results_dirs = sorted(expanded_dirs)
        print(f"Found {len(config.results_dirs)} results directories")
        for dir_path in config.results_dirs:
            print(f"  - {dir_path}")

    if not config.results_dirs:
        print("Error: No results directories provided")
        print(
            "Usage: python -m agentops.broken_test_analysis --results_dirs ./results1 --results_dirs ./results2"
        )
        print(
            "   or: python -m agentops.broken_test_analysis --parent_dir ./benchmark_results"
        )
        sys.exit(1)

    # Validate directories exist
    for dir_path in config.results_dirs:
        if not Path(dir_path).exists():
            print(f"Error: Directory does not exist: {dir_path}")
            sys.exit(1)

    analyzer = MultiDirectoryToolFailureAnalyzer(config)
    analyzer.save_report()


if __name__ == "__main__":
    config = CLI(MultiDirAnalyzeConfig, as_positional=False)
    run(config)

# Made with Bob
