"""
Dictionary Diff Utility

Provides utilities for comparing dictionaries and highlighting differences,
particularly useful for analyzing tool call parameter mismatches.
"""

from typing import Any, Dict, List, Set, Tuple


def diff_dicts(
    actual: Dict[str, Any], expected: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Compare two dictionaries and return a structured diff.

    Args:
        actual: The actual dictionary (what was provided)
        expected: The expected dictionary (what should have been provided)

    Returns:
        A dictionary containing:
        - missing_keys: Keys in expected but not in actual
        - extra_keys: Keys in actual but not in expected
        - different_values: Keys with different values
        - matching_keys: Keys with matching values
    """
    actual_keys = set(actual.keys())
    expected_keys = set(expected.keys())

    missing_keys = expected_keys - actual_keys
    extra_keys = actual_keys - expected_keys
    common_keys = actual_keys & expected_keys

    different_values = {}
    matching_keys = set()

    for key in common_keys:
        actual_val = actual[key]
        expected_val = expected[key]

        if actual_val != expected_val:
            different_values[key] = {
                "actual": actual_val,
                "expected": expected_val,
            }
        else:
            matching_keys.add(key)

    return {
        "missing_keys": sorted(list(missing_keys)),
        "extra_keys": sorted(list(extra_keys)),
        "different_values": different_values,
        "matching_keys": sorted(list(matching_keys)),
    }


def find_best_match(
    actual: Dict[str, Any], expected_list: List[Dict[str, Any]]
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Find the best matching expected dictionary from a list of possibilities.

    Args:
        actual: The actual dictionary
        expected_list: List of possible expected dictionaries

    Returns:
        Tuple of (best_match_dict, diff_result)
    """
    if not expected_list:
        return {}, diff_dicts(actual, {})

    best_match = None
    best_diff = None
    best_score = -1

    for expected in expected_list:
        diff = diff_dicts(actual, expected)

        # Calculate match score (higher is better)
        # Matching keys are good, missing/extra/different are bad
        score = (
            len(diff["matching_keys"]) * 2  # Matching keys are worth 2 points
            - len(diff["missing_keys"])
            - len(diff["extra_keys"])
            - len(diff["different_values"])
        )

        if score > best_score:
            best_score = score
            best_match = expected
            best_diff = diff

    return best_match, best_diff


def format_diff_summary(diff: Dict[str, Any]) -> str:
    """
    Format a diff result into a human-readable summary string.

    Args:
        diff: Result from diff_dicts()

    Returns:
        Formatted string summarizing the differences
    """
    lines = []

    if diff["missing_keys"]:
        lines.append(f"❌ Missing keys: {', '.join(diff['missing_keys'])}")

    if diff["extra_keys"]:
        lines.append(f"➕ Extra keys: {', '.join(diff['extra_keys'])}")

    if diff["different_values"]:
        lines.append("🔄 Different values:")
        for key, values in diff["different_values"].items():
            lines.append(f"  • {key}:")
            lines.append(f"    - Expected: {values['expected']}")
            lines.append(f"    - Actual:   {values['actual']}")

    if diff["matching_keys"]:
        lines.append(f"✅ Matching keys: {', '.join(diff['matching_keys'])}")

    if not lines:
        lines.append("✅ Dictionaries are identical")

    return "\n".join(lines)


def format_diff_compact(diff: Dict[str, Any]) -> str:
    """
    Format a diff result into a compact one-line summary.

    Args:
        diff: Result from diff_dicts()

    Returns:
        Compact string summarizing the differences
    """
    parts = []

    if diff["missing_keys"]:
        parts.append(f"Missing: {', '.join(diff['missing_keys'])}")

    if diff["extra_keys"]:
        parts.append(f"Extra: {', '.join(diff['extra_keys'])}")

    if diff["different_values"]:
        changed = ", ".join(diff["different_values"].keys())
        parts.append(f"Changed: {changed}")

    if not parts:
        return "No differences"

    return " | ".join(parts)


# Made with Bob
