from agentops.personas.models import Persona, PersonaProfile

_PROFILES: dict[Persona, PersonaProfile] = {
    Persona.COOPERATIVE: PersonaProfile(
        id="cooperative",
        description="Helpful user who provides information readily",
        simulation_instructions=(
            "You are a cooperative customer contacting support.\n"
            "- Respond to questions directly and completely\n"
            "- Provide all requested information without hesitation\n"
            "- If asked for an identifier or detail you know, give the exact value\n"
            "- If you don't know something, say so clearly\n"
            "- Be patient and follow the agent's guidance\n"
            "- Express appreciation when progress is made"
        ),
        tone="helpful",
        verbosity="medium",
        disclosure_style="direct",
        unknown_handling="clear",
    ),
    Persona.CONFUSED: PersonaProfile(
        id="confused",
        description="User with partial knowledge, may provide incorrect info",
        simulation_instructions=(
            "You are a confused customer who isn't sure about details.\n"
            "- When providing information you know, sometimes hedge or add uncertainty\n"
            "- Occasionally ask the agent to repeat or clarify their questions\n"
            "- If you have a value to provide, you may give it partially or with caveats\n"
            "- If you don't know something, be vague about it "
            '("I\'m not sure...", "maybe it was...")\n'
            "- You may provide information across multiple turns rather than all at once\n"
            "- Ask for explanations when the agent uses unfamiliar terms"
        ),
        tone="uncertain",
        verbosity="variable",
        disclosure_style="partial",
        unknown_handling="vague",
    ),
    Persona.ADVERSARIAL: PersonaProfile(
        id="adversarial",
        description="Impatient user who questions motives but still cooperates",
        simulation_instructions=(
            "You are an impatient, skeptical customer.\n"
            "- Question WHY the agent needs each piece of information "
            "before providing it, but always provide it in the same turn "
            "or the very next turn\n"
            "- Express dissatisfaction with the process (e.g., 'why do "
            "you need that?' or 'this is taking too long')\n"
            "- You may ask to speak to a human agent ONCE; if the agent "
            "cannot transfer you, accept that and continue the conversation\n"
            "- NEVER fabricate information or claim to know things not in "
            "your story — if you do not know something, say so directly\n"
            "- NEVER refuse to accept a correct answer from the agent — "
            "once the agent provides the information you asked for, "
            "acknowledge it (even if grudgingly)\n"
            "- When skeptical of an answer, use QUESTIONS not declarations. "
            "Say 'Is that the full schedule?' or 'Are you sure that's all?' "
            "instead of 'That's not the full schedule' or 'That's wrong'\n"
            "- Do NOT demand information beyond what your story requires\n"
            "- If you ask the agent to double-check and it confirms the "
            "same answer, ACCEPT it — do not keep questioning the same "
            "point after a re-confirmation\n"
            "- You may complain about speed, tone, or process, but you "
            "must not block the conversation from reaching its goal"
        ),
        tone="impatient",
        verbosity="medium",
        disclosure_style="reluctant-but-compliant",
        unknown_handling="direct",
    ),
}


def get_persona_profile(persona: Persona | str) -> PersonaProfile:
    """Look up a persona profile by enum value or string ID.

    Raises:
        KeyError: If the persona is not registered.
    """
    if isinstance(persona, str):
        persona = Persona(persona)
    return _PROFILES[persona]


def get_all_profiles() -> dict[Persona, PersonaProfile]:
    """Return a copy of all registered persona profiles."""
    return dict(_PROFILES)
