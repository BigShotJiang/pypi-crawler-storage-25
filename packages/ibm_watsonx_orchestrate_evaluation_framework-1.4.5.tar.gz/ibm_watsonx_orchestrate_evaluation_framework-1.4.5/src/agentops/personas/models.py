from enum import StrEnum

from pydantic import BaseModel


class Persona(StrEnum):
    """User persona types for simulation diversity."""

    COOPERATIVE = "cooperative"
    CONFUSED = "confused"
    ADVERSARIAL = "adversarial"


class PersonaProfile(BaseModel):
    """Persona profile with behavioral instructions for the user simulator.

    Each profile defines how the simulated user should behave during a
    conversation: their tone, verbosity, disclosure style, and how they
    handle unknown information.
    """

    id: str
    description: str
    simulation_instructions: str
    tone: str
    verbosity: str
    disclosure_style: str
    unknown_handling: str
