from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field


class GoalStatus(StrEnum):
    """Conversation termination signal from the user simulator."""

    IN_PROGRESS = "in_progress"
    SATISFIED = "satisfied"
    FAILED = "failed"


class SimulatedUserTurn(BaseModel):
    """Structured output of a single simulated user turn.

    Produced by the user simulator and validated by the guardrail pipeline
    before being sent to the orchestration loop.
    """

    content: str = Field(
        ...,
        description="Natural language message to send to the agent",
    )
    entities: dict[str, Any] = Field(
        default_factory=dict,
        description=(
            "Entity names and values communicated in this turn. "
            "Values must originate from the user story or agent messages."
        ),
    )
    goal_status: GoalStatus = Field(
        default=GoalStatus.IN_PROGRESS,
        description="Termination signal for the conversation loop",
    )
    guardrail_notes: list[str] = Field(
        default_factory=list,
        description="Notes from guardrail pipeline (corrections, retries, patches)",
    )
