"""
Tool Parameter Diff Analyzer

Analyzes parameter mismatches for a specific tool across multiple test runs,
showing clear diffs between actual and expected parameters.

Usage:
    python -m agentops.tool_parameter_diff_analyzer --parent_dir ./benchmark_results --tool_name update_address
"""

import json
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List

from jsonargparse import CLI
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from agentops.arg_configs import ToolParameterDiffConfig
from agentops.type import ContentType
from agentops.utils import TestCaseResources


def diff_dicts(
    actual: Dict[str, Any], expected: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Compare two dictionaries and return a structured diff.

    Args:
        actual: The actual dictionary (what was provided)
        expected: The expected dictionary (what should have been provided)

    Returns:
        A dictionary containing differences
    """
    actual_keys = set(actual.keys())
    expected_keys = set(expected.keys())

    missing_keys = expected_keys - actual_keys
    extra_keys = actual_keys - expected_keys
    common_keys = actual_keys & expected_keys

    different_values = {}
    matching_keys = set()

    for key in common_keys:
        actual_val = actual[key]
        expected_val = expected[key]

        if actual_val != expected_val:
            different_values[key] = {
                "actual": actual_val,
                "expected": expected_val,
            }
        else:
            matching_keys.add(key)

    return {
        "missing_keys": sorted(list(missing_keys)),
        "extra_keys": sorted(list(extra_keys)),
        "different_values": different_values,
        "matching_keys": sorted(list(matching_keys)),
    }


def find_best_match(
    actual: Dict[str, Any], expected_list: List[Dict[str, Any]]
) -> tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Find the best matching expected dictionary from a list of possibilities.

    Args:
        actual: The actual dictionary
        expected_list: List of possible expected dictionaries

    Returns:
        Tuple of (best_match_dict, diff_result)
    """
    if not expected_list:
        return {}, diff_dicts(actual, {})

    best_match = expected_list[0]
    best_diff = diff_dicts(actual, expected_list[0])
    best_score = -1

    for expected in expected_list:
        diff = diff_dicts(actual, expected)

        # Calculate match score (higher is better)
        score = (
            len(diff["matching_keys"]) * 2
            - len(diff["missing_keys"])
            - len(diff["extra_keys"])
            - len(diff["different_values"])
        )

        if score > best_score:
            best_score = score
            best_match = expected
            best_diff = diff

    return best_match, best_diff


class ToolParameterDiffAnalyzer:
    """Analyzes parameter mismatches for a specific tool across test runs"""

    def __init__(self, config: ToolParameterDiffConfig):
        self.config = config
        self.console = Console()
        self.failures = []  # List of failure records

    def find_result_directories(self) -> List[str]:
        """Find all result directories in the parent directory"""
        parent_path = Path(self.config.parent_dir)
        if not parent_path.exists():
            self.console.print(
                f"[red]Error: Directory does not exist: {self.config.parent_dir}[/red]"
            )
            return []

        subdirs = []

        def find_analyzable_dirs(path: Path):
            """Recursively find directories that contain eval data"""
            if not path.is_dir():
                return

            # Check if current directory is analyzable
            is_analyzable = (path / "summary_metrics.csv").exists() or (
                path / "messages"
            ).exists()

            if is_analyzable:
                subdirs.append(str(path))
                return

            # Recurse into subdirectories
            try:
                for item in path.iterdir():
                    if item.is_dir():
                        find_analyzable_dirs(item)
            except PermissionError:
                pass

        find_analyzable_dirs(parent_path)
        return sorted(subdirs)

    def analyze_directory(self, dir_path: str):
        """Analyze a single results directory for tool parameter failures"""
        # Get relative path from parent_dir for better context
        parent_path = Path(self.config.parent_dir)
        dir_path_obj = Path(dir_path)
        try:
            dir_name = str(dir_path_obj.relative_to(parent_path))
        except ValueError:
            # If not relative to parent, just use the name
            dir_name = dir_path_obj.name

        try:
            resources = TestCaseResources(dir_path)
            summary = resources.get_summary
        except Exception as e:
            self.console.print(
                f"[yellow]Warning: Error loading directory {dir_path}: {e}[/yellow]"
            )
            return

        # Process each test case
        for test_entry in summary:
            test_name = test_entry["dataset_name"]

            # Skip summary rows
            if test_name.lower().strip() == "summary (average)":
                continue

            try:
                # Get analyze messages
                messages, meta = resources.get_analyze_messages(
                    test_case_name=test_name
                )

                # Look for tool call failures for our specific tool
                for msg in messages:
                    if (
                        msg.message.role == "assistant"
                        and msg.message.type == ContentType.tool_call
                        and msg.reason
                    ):
                        # Extract tool name and check if it matches
                        content = msg.message.content
                        if isinstance(content, str):
                            content = json.loads(content)
                        tool_name = content.get("name", "unknown")

                        if tool_name != self.config.tool_name:
                            continue

                        # Check if this is an incorrect parameter failure
                        if isinstance(msg.reason, dict):
                            reason = msg.reason.get("reason")
                            if reason == "incorrect parameter":
                                actual = msg.reason.get("actual", {})
                                expected_list = msg.reason.get("expected", [])

                                # Find best match and compute diff
                                best_match, diff = find_best_match(
                                    actual, expected_list
                                )

                                self.failures.append(
                                    {
                                        "directory": dir_name,
                                        "test_name": test_name,
                                        "actual": actual,
                                        "expected_list": expected_list,
                                        "best_match": best_match,
                                        "diff": diff,
                                    }
                                )

            except Exception as e:
                self.console.print(
                    f"[yellow]Warning: Error processing {test_name} in {dir_path}: {e}[/yellow]"
                )
                continue

    def analyze_all(self):
        """Analyze all directories and collect failures"""
        directories = self.find_result_directories()

        if not directories:
            self.console.print(
                f"[red]No result directories found in {self.config.parent_dir}[/red]"
            )
            return

        self.console.print(
            f"[bold blue]Analyzing {len(directories)} directories for tool '{self.config.tool_name}'...[/bold blue]"
        )

        for dir_path in directories:
            self.console.print(f"Processing: {Path(dir_path).name}")
            self.analyze_directory(dir_path)

        if not self.failures:
            self.console.print(
                f"[yellow]No parameter failures found for tool '{self.config.tool_name}'[/yellow]"
            )
        else:
            self.console.print(
                f"[bold green]Found {len(self.failures)} parameter failures for '{self.config.tool_name}'[/bold green]"
            )

    def display_results(self):
        """Display the analysis results in a rich format"""
        if not self.failures:
            return

        self.console.print(
            f"\n[bold cyan]Parameter Diff Analysis for Tool: {self.config.tool_name}[/bold cyan]\n"
        )

        # Track statistics for summary
        missing_key_counts = defaultdict(int)
        extra_key_counts = defaultdict(int)
        different_key_counts = defaultdict(int)

        for idx, failure in enumerate(self.failures, 1):
            # Create a panel for each failure
            diff = failure["diff"]

            # Update statistics
            for key in diff["missing_keys"]:
                missing_key_counts[key] += 1
            for key in diff["extra_keys"]:
                extra_key_counts[key] += 1
            for key in diff["different_values"].keys():
                different_key_counts[key] += 1

            # Build the content
            content_lines = []
            content_lines.append(
                f"[bold]Directory:[/bold] {failure['directory']}"
            )
            content_lines.append(f"[bold]Test:[/bold] {failure['test_name']}")
            content_lines.append("")

            # Show diff summary
            if diff["missing_keys"]:
                content_lines.append(
                    f"[red]❌ Missing keys:[/red] {', '.join(diff['missing_keys'])}"
                )

            if diff["extra_keys"]:
                content_lines.append(
                    f"[yellow]➕ Extra keys:[/yellow] {', '.join(diff['extra_keys'])}"
                )

            if diff["different_values"]:
                content_lines.append("[magenta]🔄 Different values:[/magenta]")
                for key, values in diff["different_values"].items():
                    content_lines.append(f"  [cyan]• {key}:[/cyan]")
                    content_lines.append(
                        f"    [red]Expected:[/red] {values['expected']}"
                    )
                    content_lines.append(
                        f"    [yellow]Actual:[/yellow]   {values['actual']}"
                    )

            if diff["matching_keys"]:
                content_lines.append(
                    f"[green]✅ Matching keys:[/green] {', '.join(diff['matching_keys'])}"
                )

            # Show full actual and expected for reference (sorted keys)
            content_lines.append("")
            content_lines.append("[dim]Full Actual Parameters:[/dim]")
            content_lines.append(
                f"[dim]{json.dumps(failure['actual'], indent=2, sort_keys=True)}[/dim]"
            )
            content_lines.append("")
            content_lines.append("[dim]Best Match Expected Parameters:[/dim]")
            content_lines.append(
                f"[dim]{json.dumps(failure['best_match'], indent=2, sort_keys=True)}[/dim]"
            )

            # If there are multiple expected options, show count
            if len(failure["expected_list"]) > 1:
                content_lines.append("")
                content_lines.append(
                    f"[dim]Note: {len(failure['expected_list'])} possible expected parameter sets (showing best match)[/dim]"
                )

            panel = Panel(
                "\n".join(content_lines),
                title=f"[bold]Failure #{idx}[/bold]",
                border_style="blue",
            )
            self.console.print(panel)
            self.console.print()

        # Display summary statistics
        self._display_summary_statistics(
            missing_key_counts, extra_key_counts, different_key_counts
        )

    def _display_summary_statistics(
        self, missing_key_counts, extra_key_counts, different_key_counts
    ):
        """Display summary statistics of parameter issues"""
        self.console.print(
            "\n[bold cyan]═══ Summary Statistics ═══[/bold cyan]\n"
        )

        # Missing keys table
        if missing_key_counts:
            table = Table(
                title="Missing Keys (Expected but Not Provided)",
                show_header=True,
                header_style="bold red",
            )
            table.add_column("Key Name", style="cyan")
            table.add_column("Occurrences", justify="right", style="red")

            for key, count in sorted(
                missing_key_counts.items(), key=lambda x: x[1], reverse=True
            ):
                table.add_row(key, str(count))

            self.console.print(table)
            self.console.print()

        # Extra keys table
        if extra_key_counts:
            table = Table(
                title="Extra Keys (Provided but Not Expected)",
                show_header=True,
                header_style="bold yellow",
            )
            table.add_column("Key Name", style="cyan")
            table.add_column("Occurrences", justify="right", style="yellow")

            for key, count in sorted(
                extra_key_counts.items(), key=lambda x: x[1], reverse=True
            ):
                table.add_row(key, str(count))

            self.console.print(table)
            self.console.print()

        # Different values table
        if different_key_counts:
            table = Table(
                title="Keys with Wrong Values (Provided but Incorrect)",
                show_header=True,
                header_style="bold magenta",
            )
            table.add_column("Key Name", style="cyan")
            table.add_column("Occurrences", justify="right", style="magenta")

            for key, count in sorted(
                different_key_counts.items(), key=lambda x: x[1], reverse=True
            ):
                table.add_row(key, str(count))

            self.console.print(table)
            self.console.print()

        # Overall summary
        total_failures = len(self.failures)
        total_missing = sum(missing_key_counts.values())
        total_extra = sum(extra_key_counts.values())
        total_different = sum(different_key_counts.values())

        summary_table = Table(
            title="Overall Summary", show_header=True, header_style="bold green"
        )
        summary_table.add_column("Metric", style="cyan")
        summary_table.add_column("Count", justify="right", style="green")

        summary_table.add_row("Total Failures", str(total_failures))
        summary_table.add_row("Total Missing Key Instances", str(total_missing))
        summary_table.add_row("Total Extra Key Instances", str(total_extra))
        summary_table.add_row(
            "Total Wrong Value Instances", str(total_different)
        )
        summary_table.add_row(
            "Unique Missing Keys", str(len(missing_key_counts))
        )
        summary_table.add_row("Unique Extra Keys", str(len(extra_key_counts)))
        summary_table.add_row(
            "Unique Keys with Wrong Values", str(len(different_key_counts))
        )

        self.console.print(summary_table)


def run(config: ToolParameterDiffConfig):
    """Main entry point for the tool parameter diff analyzer"""
    analyzer = ToolParameterDiffAnalyzer(config)
    analyzer.analyze_all()
    analyzer.display_results()


if __name__ == "__main__":
    config = CLI(ToolParameterDiffConfig, as_positional=False)
    run(config)

# Made with Bob
