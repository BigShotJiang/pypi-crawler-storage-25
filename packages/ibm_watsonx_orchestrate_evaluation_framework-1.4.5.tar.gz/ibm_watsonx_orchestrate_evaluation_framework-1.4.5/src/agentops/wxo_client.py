import os
import time
from threading import Lock
from typing import Any, Dict, Optional

import jwt
import requests
import urllib3
from urllib3.exceptions import InsecureRequestWarning

REFRESH_BUFFER_SECONDS = 15 * 60  # Refresh 15 minutes before expiry


class WXOClient:
    def __init__(
        self,
        service_url,
        api_key,
        env: Optional[Dict[str, Any]] = None,
        tenant_name: Optional[str] = None,
    ):
        self.service_url = service_url
        self.api_key = api_key
        self.tenant_name = tenant_name
        self._refresh_lock = Lock()
        self._expiration_time: Optional[float] = self._extract_expiration(
            api_key
        )
        ov = os.getenv("WO_SSL_VERIFY")
        if ov and ov.strip().lower() in ("true", "false"):
            self._verify_ssl = ov.strip().lower() == "true"
        else:
            v, bs = (env.get("verify") if env else None), (
                env.get("bypass_ssl") if env else None
            )
            self._verify_ssl = (
                False
                if (
                    (bs is True)
                    or (isinstance(bs, str) and bs.strip().lower() == "true")
                    or (v is None)
                    or (
                        isinstance(v, str)
                        and v.strip().lower() in {"none", "null"}
                    )
                )
                else (v if isinstance(v, bool) else True)
            )

        if not self._verify_ssl:
            urllib3.disable_warnings(InsecureRequestWarning)

    def _extract_expiration(self, token: Optional[str]) -> Optional[float]:
        if not token:
            return None
        try:
            decoded = jwt.decode(token, options={"verify_signature": False})
            return decoded.get("exp")
        except jwt.DecodeError:
            return None

    def _ensure_valid_token(self):
        if self._expiration_time is None:
            return
        if time.time() + REFRESH_BUFFER_SECONDS >= self._expiration_time:
            with self._refresh_lock:
                if (
                    time.time() + REFRESH_BUFFER_SECONDS
                    >= self._expiration_time
                ):
                    self._refresh_token()

    def _refresh_token(self):
        from agentops.service_instance import (
            ServiceInstance,
            update_cached_token,
        )

        self.api_key = ServiceInstance(
            self.service_url, self.tenant_name
        ).get_user_token()
        self._expiration_time = self._extract_expiration(self.api_key)

        if self.tenant_name:
            try:
                update_cached_token(self.tenant_name, self.api_key)
            except Exception:
                pass

    def _get_headers(self) -> dict:
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def post(self, payload: dict, path: str, stream=False):
        self._ensure_valid_token()
        url = f"{self.service_url}/{path}"
        response = requests.post(
            url=url,
            headers=self._get_headers(),
            json=payload,
            stream=stream,
            verify=self._verify_ssl,
        )
        return response

    def post_files(
        self, path: str, files: dict, data: Optional[dict] = None, stream=False
    ):
        self._ensure_valid_token()
        url = f"{self.service_url}/{path}"
        response = requests.post(
            url=url,
            headers=self._get_headers(),
            files=files,
            data=data,
            stream=stream,
            verify=self._verify_ssl,
        )
        return response

    def get(self, path: str, params: Optional[dict] = None):
        self._ensure_valid_token()
        url = f"{self.service_url}/{path}"
        response = requests.get(
            url,
            params=params,
            headers=self._get_headers(),
            verify=self._verify_ssl,
        )
        return response


def get_wxo_client(
    service_url: Optional[str], tenant_name: str, token: Optional[str] = None
) -> WXOClient:

    from agentops.service_instance import tenant_setup

    token, resolved_url, env = tenant_setup(service_url, tenant_name)
    service_url = service_url or resolved_url

    if not (service_url and str(service_url).strip()):
        raise ValueError(
            f"service_url not provided and not found in config for tenant '{tenant_name}'"
        )

    wxo_client = WXOClient(
        service_url=service_url, api_key=token, env=env, tenant_name=tenant_name
    )
    return wxo_client
