class EventHandlerOrchestrator:
    def __init__(self, wxo_client, enable_saas_mode) -> None:
        self.handlers = [
            RunsEventHandler(wxo_client, enable_saas_mode),
            FlowEventsHandler(wxo_client, enable_saas_mode),
        ]

    def handle(self, context):
        for handler in self.handlers:
            if handler.can_handle(context):
                response = handler.handle(context)
