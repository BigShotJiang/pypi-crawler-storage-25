import collections
import json
from typing import Any, Dict, List, Optional

from agentops.arg_configs import (
    ArgMatchingGenerationConfig,
    KeywordsGenerationConfig,
    ProviderConfig,
    SummaryGenerationConfig,
)
from agentops.error_constants import ERROR_KEYWORDS
from agentops.generators import (
    ArgMatchingGenerationLLM,
    KeywordsGenerationLLM,
    SummaryGenerationLLM,
)
from agentops.prompt.template_render import (
    ArgMatchingGenerationTemplateRenderer,
    LlamaKeywordsGenerationTemplateRenderer,
    LlamaSummaryGenerationTemplateRenderer,
)
from agentops.service_provider import get_provider
from agentops.service_provider.provider import Provider
from agentops.type import Message, TestCase


class DataAnnotator:
    def __init__(
        self,
        messages: List[Message],
        keywords_generation_config: Optional[KeywordsGenerationConfig] = None,
        summary_generation_config: Optional[SummaryGenerationConfig] = None,
        arg_matching_generation_config: Optional[
            ArgMatchingGenerationConfig
        ] = None,
        provider_config: Optional[ProviderConfig] = None,
        initial_data: Optional[TestCase] = None,
    ):
        self.messages = messages
        self.keywords_generation_config = (
            keywords_generation_config or KeywordsGenerationConfig()
        )
        self.arg_matching_generation_config = (
            arg_matching_generation_config or ArgMatchingGenerationConfig()
        )
        self.summary_generation_config = (
            summary_generation_config or SummaryGenerationConfig()
        )
        self.provider_config = provider_config or ProviderConfig()

        self.initial_data = initial_data

        self._kw_generator = None
        self._summary_generator = None
        self._arg_matching_generator = None

    def _create_provider(
        self, model_id: str, max_new_tokens: int = 256
    ) -> Provider:
        """Create a provider with the given model_id and parameters."""
        return get_provider(
            config=self.provider_config,
            model_id=model_id,
            params={
                "min_new_tokens": 0,
                "decoding_method": "greedy",
                "max_new_tokens": max_new_tokens,
            },
            **self.provider_config.provider_params,
        )

    @property
    def kw_generator(self) -> KeywordsGenerationLLM:
        """Lazy initialization of keyword generator."""
        if self._kw_generator is None:
            provider = self._create_provider(
                self.keywords_generation_config.model_id,
                max_new_tokens=256,
            )

            self._kw_generator = KeywordsGenerationLLM(
                provider=provider,
                template=LlamaKeywordsGenerationTemplateRenderer(
                    self.keywords_generation_config.prompt_config
                ),
            )
        return self._kw_generator

    @property
    def summary_generator(self) -> SummaryGenerationLLM:
        """Lazy initialization of summary generator."""
        if self._summary_generator is None:
            provider = self._create_provider(
                self.summary_generation_config.model_id,
                max_new_tokens=1024,
            )

            self._summary_generator = SummaryGenerationLLM(
                provider=provider,
                template=LlamaSummaryGenerationTemplateRenderer(
                    self.summary_generation_config.prompt_config
                ),
            )
        return self._summary_generator

    @property
    def arg_matching_generator(self) -> ArgMatchingGenerationLLM:
        """Lazy initialization of arg matching generator."""
        if self._arg_matching_generator is None:
            provider = self._create_provider(
                self.arg_matching_generation_config.model_id,
                max_new_tokens=4096,
            )

            self._arg_matching_generator = ArgMatchingGenerationLLM(
                provider=provider,
                template=ArgMatchingGenerationTemplateRenderer(
                    self.arg_matching_generation_config.prompt_config
                ),
                batch_size=self.arg_matching_generation_config.batch_size,
                max_workers=self.arg_matching_generation_config.max_workers,
            )
        return self._arg_matching_generator

    @staticmethod
    def _is_error_in_message(message: str) -> bool:
        """Heuristic to catch tool calls that fail"""
        message = message.lower()
        return any(keyword in message for keyword in ERROR_KEYWORDS)

    def _get_failed_tool_responses(self) -> list[str]:
        """Get list of IDs for failed tool calls"""
        wrong_tool_response_id = []
        for message in self.messages:
            if message.type == "tool_response":
                try:
                    parsed_content = json.loads(message.content)
                    tool_call_id = parsed_content["tool_call_id"]

                    # Check if the tool response indicates failure
                    # Look for is_success field in the nested content
                    if "content" in parsed_content:
                        inner_content = json.loads(parsed_content["content"])
                        # Check for explicit success/failure indicators
                        if isinstance(inner_content, dict):
                            is_success = inner_content.get("is_success", True)
                            error_details = inner_content.get("error_details")

                            if is_success is False or error_details is not None:
                                wrong_tool_response_id.append(tool_call_id)

                except (json.JSONDecodeError, KeyError, TypeError):
                    pass

        return wrong_tool_response_id

    def _process_tool_call_order(
        self, wrong_tool_response_id: list[str]
    ) -> list[str]:
        """Process and order tool calls, skipping failed ones"""
        # gather all call ids that actually got a response
        valid_call_ids = set()
        for m in self.messages:
            if m.type == "tool_response":
                try:
                    content = json.loads(m.content)
                    if "tool_call_id" in content:
                        valid_call_ids.add(content["tool_call_id"])
                except json.JSONDecodeError:
                    continue

        order = []
        for idx, message in enumerate(self.messages):
            if message.type != "tool_call":
                continue

            try:
                content = json.loads(message.content)
            except json.JSONDecodeError:
                continue

            call_id = content.get("tool_call_id") or content.get("id")

            # skip any calls that errored
            if call_id in wrong_tool_response_id:
                continue

            # skip calls that never produced a tool_response
            if call_id not in valid_call_ids:
                continue

            # skip the "reflection" copy that the LLM emits right after a response
            prev = self.messages[idx - 1] if idx > 0 else None
            if prev is not None and prev.type == "tool_response":
                try:
                    prev_content = json.loads(prev.content)
                    if prev_content.get("tool_call_id") == call_id:
                        continue
                except json.JSONDecodeError:
                    pass

            # normalize ids so json dumps only reflects name-args
            content.pop("tool_call_id", None)
            content.pop("id", None)

            signature = json.dumps(content, sort_keys=True)
            # if we've seen that exact (name-args) before, drop the old one
            if signature in order:
                order.remove(signature)
            order.append(signature)

        return order

    def _process_tool_calls(self) -> tuple[Dict, List, str]:
        """Process tool calls and generate goals structure with arg_matching."""
        # Get failed tool response IDs and process tool calls
        wrong_tool_response_id = self._get_failed_tool_responses()
        order = self._process_tool_call_order(wrong_tool_response_id)

        goals = {}
        goal_details = []
        function_count = collections.defaultdict(int)
        previous = None

        # First pass: parse all tool calls and collect for batching
        parsed_calls = []
        for tool_call in order:
            call = json.loads(tool_call)
            funct_name = call["name"]
            function_count[funct_name] += 1
            goal_name = funct_name + f"-{function_count[funct_name]}"
            args = call.get("args", {})
            parsed_calls.append(
                {
                    "tool_name": funct_name,
                    "goal_name": goal_name,
                    "args": args,
                }
            )

        # Generate arg_matching for all tool calls in one batch request
        tool_calls_for_batch = [
            {"tool_name": pc["tool_name"], "args": pc["args"]}
            for pc in parsed_calls
        ]
        try:
            all_arg_matchings = (
                self.arg_matching_generator.generate_arg_matching(
                    tool_calls_for_batch
                )
            )
        except Exception:
            all_arg_matchings = [{} for _ in parsed_calls]
        finally:
            if self._arg_matching_generator is not None:
                self._arg_matching_generator.shutdown()

        # Second pass: build goal_details with the batch results
        for i, pc in enumerate(parsed_calls):
            goal_name = pc["goal_name"]
            args = pc["args"]
            arg_matching = (
                all_arg_matchings[i] if i < len(all_arg_matchings) else {}
            )

            if previous:
                goals[previous] = [goal_name]

            goal_detail = {
                "type": "tool_call",
                "name": goal_name,
                "tool_name": pc["tool_name"],
                "args": args,
            }

            # Only add arg_matching if there are non-strict values
            if arg_matching:
                goal_detail["arg_matching"] = arg_matching

            goal_details.append(goal_detail)
            previous = goal_name

        return goals, goal_details, previous

    def _process_summarization(
        self,
        previous: str,
        goals: Dict,
        goal_details: List,
    ) -> None:
        """Process summarization step"""
        summarize_step = None
        # we assume single summary step at the end

        for message in self.messages[::-1]:
            if message.role == "assistant":
                # Use the keyword generator property (lazy initialization)
                if self.keywords_generation_config.enabled:
                    try:
                        keywords = self.kw_generator.generate(message.content)
                    except Exception:
                        keywords = []
                else:
                    keywords = []

                # Use the summary generator property (lazy initialization)
                try:
                    summary = self.summary_generator.generate(message.content)
                except Exception:
                    summary = None

                summarize_step = {
                    "name": "summarize",
                    "type": "text",
                    "response": message.content,
                    "keywords": keywords,
                    "summary": summary,
                }
                goal_details.append(summarize_step)
                break

        if previous is None:
            goals["summarize"] = []
        elif summarize_step is None:
            goals[previous] = []
        else:
            goals[previous] = ["summarize"]

    def _get_starting_sentence(self) -> str:
        """Get starting_sentence from first message content if available,
        otherwise fall back to initial_data.starting_sentence."""
        starting_sentence = ""

        # Try to get from first message content
        if self.messages and len(self.messages) > 0:
            first_message = self.messages[0]
            if isinstance(first_message.content, str):
                starting_sentence = first_message.content
            elif isinstance(first_message.content, dict):
                # Handle dict content by converting to string
                starting_sentence = str(first_message.content)

        # Fall back to initial_data if no message content found
        if not starting_sentence and self.initial_data:
            starting_sentence = self.initial_data.starting_sentence or ""

        return starting_sentence

    def _extract_file_upload_info(self) -> Optional[Dict[str, Any]]:
        """Extract file upload information from messages. Only uses the first file found.

        Returns a dictionary with file upload details:
        {
            "file_name": "sample-id.txt",
            "url": "http://host.docker.internal:9000/...",
            "object_key": "uploaded_files/e67e04b3-3222-420c-9ea0-269a70ed1f43/sample-id.txt"
        }

        Returns None if no file upload information is found.
        """
        # Look for file_download messages which indicate a file was uploaded
        for message in self.messages:
            # Message content is a JSON string in the actual runtime format
            if isinstance(message.content, str):
                try:
                    content_data = json.loads(message.content)
                    if isinstance(content_data, dict):
                        response_type = content_data.get("response_type")

                        if response_type == "file_download":
                            files = content_data.get("files", [])
                            if files and len(files) > 0:
                                file_info = files[0]  # Use first file
                                if isinstance(file_info, dict):
                                    file_name = file_info.get("fileName")
                                    url = file_info.get("url")

                                    # Extract object_key from URL
                                    object_key = (
                                        self._extract_object_key_from_url(url)
                                    )

                                    if file_name and url:
                                        return {
                                            "file_name": file_name,
                                            "url": url,
                                            "object_key": object_key,
                                        }
                except (json.JSONDecodeError, TypeError):
                    pass

        return None

    def _extract_object_key_from_url(self, url: str) -> str:
        """Extract object_key from a file URL using urllib.parse.

        Example:
            Input: "http://host.docker.internal:9000/wxo-server-storage-bucket/uploaded_files/e67e04b3-3222-420c-9ea0-269a70ed1f43/sample-id.txt?..."
            Output: "uploaded_files/e67e04b3-3222-420c-9ea0-269a70ed1f43/sample-id.txt"
        """
        if not url:
            return ""

        from urllib.parse import urlparse

        try:
            parsed = urlparse(url)
            # Path format: /bucket-name/object_key
            # Split path and remove empty strings and bucket name
            path_parts = [p for p in parsed.path.split("/") if p]

            if len(path_parts) > 1:
                # Remove bucket name (first part) and join the rest
                object_key = "/".join(path_parts[1:])
                return object_key

            return ""
        except Exception:
            return ""

    def generate(self) -> Dict:
        """Generate the final dataset with arg_matching labels."""
        goals, goal_details, previous = self._process_tool_calls()

        self._process_summarization(previous, goals, goal_details)

        return {
            "agent": self.initial_data.agent if self.initial_data else "",
            "goals": goals,
            "goal_details": goal_details,
            "story": self.initial_data.story if self.initial_data else "N/A",
            "starting_sentence": self._get_starting_sentence(),
            "response_summary_version": "v2",
        }
