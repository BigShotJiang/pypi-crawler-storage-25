"""
Generate test cases from message threads using a generic provider.

This module provides functionality to convert a thread of messages into a v2 test case
structure, using a configurable provider for any LLM-based generation steps.
"""

import logging
from typing import List, Optional

from agentops.arg_configs import (
    KeywordsGenerationConfig,
    ProviderConfig,
    StoryGenerationConfig,
    SummaryGenerationConfig,
)
from agentops.record.data_annotator import DataAnnotator
from agentops.record.record_chat import generate_story
from agentops.type import Message, TestCase

logger = logging.getLogger(__name__)


def generate_test_case_from_messages(
    messages: List[Message],
    agent_name: str,
    keywords_generation_config: Optional[KeywordsGenerationConfig] = None,
    summary_generation_config: Optional[SummaryGenerationConfig] = None,
    story_generation_config: Optional[StoryGenerationConfig] = None,
    provider_config: Optional[ProviderConfig] = None,
) -> TestCase:
    """
    Generate a test case from a thread of messages.

    This function takes a list of messages from an agent conversation and converts
    them into a structured test case format that can be used for evaluation.

    File upload information is automatically extracted from messages with
    response_type "file_download" and included in the test case with file_name,
    url, and object_key fields. Only uses the first file found.

    Args:
        messages: List of Message objects from the thread.
        agent_name: Agent name for the test case. Required.
        keywords_generation_config: Optional KeywordsGenerationConfig for keyword extraction.
        summary_generation_config: Optional SummaryGenerationConfig for summary generation.
        story_generation_config: Optional StoryGenerationConfig for story generation.
        provider_config: Optional ProviderConfig for LLM provider configuration.

    Returns:
        TestCase instance containing the test case structure with:
            - agent: Agent name
            - story: Generated story/description
            - starting_sentence: Initial user message
            - goals: Goal dependency graph (dict mapping goal names to list of next goals)
            - goal_details: List of detailed goal specifications
            - file_upload: Optional file upload information (automatically extracted)

    Example:
        >>> from agentops.arg_configs import ProviderConfig, KeywordsGenerationConfig
        >>> from agentops.generate_test_case import generate_test_case_from_messages
        >>> from agentops.type import Message, ContentType
        >>>
        >>> messages = [
        ...     Message(role="user", content="Book a flight", type=ContentType.text),
        ...     Message(role="assistant", content='{"name": "search_flights", "args": {...}}', type=ContentType.tool_call),
        ...     Message(role="tool", content="...", type=ContentType.tool_response),
        ...     Message(role="assistant", content="I found some flights...", type=ContentType.text)
        ... ]
        >>>
        >>> # Use individual config parameters
        >>> provider_config = ProviderConfig(model_id="bedrock/openai.gpt-oss-120b-1:0")
        >>> keywords_config = KeywordsGenerationConfig()
        >>> test_case = generate_test_case_from_messages(
        ...     messages=messages,
        ...     agent_name="travel_agent",
        ...     provider_config=provider_config,
        ...     keywords_generation_config=keywords_config
        ... )
    """

    # Validate that all messages are Message objects
    normalized_messages = []
    for msg in messages:
        if not isinstance(msg, Message):
            raise TypeError(
                f"All messages must be Message objects, got {type(msg)}"
            )
        normalized_messages.append(msg)

    # Use DataAnnotator to generate the test case structure
    annotator = DataAnnotator(
        messages=normalized_messages,
        summary_generation_config=summary_generation_config,
        keywords_generation_config=keywords_generation_config,
        provider_config=provider_config,
    )

    # Generate the annotated data
    annotated_data = annotator.generate()

    # Set agent name
    annotated_data["agent"] = agent_name

    # Generate story
    try:
        annotated_data["story"] = generate_story(
            annotated_data,
            story_generation_config,
            provider_config=provider_config,
        )
    except Exception as e:
        logger.warning(f"Failed to generate story: {e}")
        annotated_data["story"] = "<None>"

    # Extract file upload information if present
    file_upload_info = annotator._extract_file_upload_info()
    if file_upload_info:
        annotated_data["file_upload"] = file_upload_info

    # Convert to TestCase for type safety
    return TestCase.model_validate(annotated_data)


# Made with Bob
