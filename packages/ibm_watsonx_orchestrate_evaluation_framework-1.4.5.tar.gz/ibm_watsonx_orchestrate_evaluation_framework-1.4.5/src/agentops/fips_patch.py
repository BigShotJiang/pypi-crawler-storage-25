"""
FIPS compliance patch for hashlib.

This module patches hashlib.md5 and hashlib.sha1 to default to
usedforsecurity=False, ensuring compatibility with FIPS-enabled systems.

Import this module before any other imports that use hashlib.
"""

import hashlib

_original_md5 = hashlib.md5
_original_sha1 = hashlib.sha1


def _fips_safe_md5(data=b"", *, usedforsecurity=False):
    return _original_md5(data, usedforsecurity=usedforsecurity)


def _fips_safe_sha1(data=b"", *, usedforsecurity=False):
    return _original_sha1(data, usedforsecurity=usedforsecurity)


hashlib.md5 = _fips_safe_md5
hashlib.sha1 = _fips_safe_sha1
