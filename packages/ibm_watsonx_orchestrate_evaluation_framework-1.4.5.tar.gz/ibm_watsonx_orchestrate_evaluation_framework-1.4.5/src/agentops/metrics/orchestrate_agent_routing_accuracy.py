from agentops.metrics.evaluations import Evaluation
from agentops.metrics.metrics import EvaluatorData
from agentops.resource_registry import ResourceRegistry
from agentops.type import GPTOSS_ROUTING_AGENT_NAME_PREFIX, ContentType


class OrchestrateAgentRoutingAccuracy(Evaluation):
    def do_evaluate(
        self,
        messages,
        ground_truth=None,
        metadata=None,
        **kwargs,
    ):
        """Extract routing call metrics.

        Args:
            messages: List of conversation messages
            ground_truth: Ground truth data with goal_details
            **kwargs: Additional arguments (resource_map containing agent2tools mapping)
        """
        # Deferred import to break circular dependency
        from agentops.resource_map import ResourceMap

        # Access agent2tools from resource_map
        resource_map = ResourceRegistry.get(ResourceMap)
        agent_data = resource_map.agent_data if resource_map else {}
        tool2agents = resource_map.tools2agents if resource_map else {}

        tool_dictionary = (
            {
                goal_detail.tool_name: goal_detail
                for goal_detail in ground_truth.goal_details
                if goal_detail.type == ContentType.tool_call
            }
            if ground_truth.goal_details
            else {}
        )

        # Get List of Agents from the Tool Dictionary
        # `possible_agents` is the super set of all agents that have a ground truth tool registered to them
        # `explicitly_labeled_agents` is the set of all agents that are explicitly labeled in the ground truth
        possible_agents = set()
        explicitly_labeled_agents = set()
        for tool_name in tool_dictionary.keys():
            if agents := tool2agents.get(tool_name, []):
                possible_agents.update(agents)

            # in this case, the "tool_name" is an agent name that is explicitly labeled in the ground truth
            if tool_name in agent_data:
                explicitly_labeled_agents.add(tool_name)

        actual_agents = set()
        total_routing_calls = 0
        for message in messages:
            if message.type == ContentType.tool_call:
                # Extract tool call from message
                msg_tool_call = message.tool_calls[0].function
                tool_name = msg_tool_call.name
                tool_name = tool_name.removeprefix(
                    GPTOSS_ROUTING_AGENT_NAME_PREFIX
                )

                # Check if this is a routing call
                if tool_name in agent_data:
                    total_routing_calls += 1
                    actual_agents.add(tool_name)

        # Calculate routing f1
        super_set = explicitly_labeled_agents.union(possible_agents)
        tp = len(actual_agents.intersection(super_set))
        fp = len(actual_agents.difference(super_set))
        # we get fn by look at the explicitly labeled agents
        fn = len(explicitly_labeled_agents.difference(actual_agents))

        routing_f1 = (
            round(2 * tp / (2 * tp + fn + fp), 2)
            if total_routing_calls > 0
            else 1
        )

        return EvaluatorData(
            eval_name="orchestrate_agent_routing_accuracy",
            display_name="Orchestrate Agent Routing F1",
            comment="",
            value=routing_f1,
            metadata=metadata,
        )
