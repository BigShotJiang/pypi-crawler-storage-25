from collections import defaultdict


def find_terminal_nodes(graph: dict[str, list[str]]) -> set[str]:
    """Finds terminal nodes (nodes with no outgoing edges).

    Args:
        graph: the input graph

    Returns:
        a set of the terminal nodes
    """
    seen_nodes = set()  # track seen nodes
    non_terminal_nodes = set()  # track nodes with children

    for node in graph:
        seen_nodes.add(node)
        if graph[node]:
            non_terminal_nodes.add(node)
            for n in graph[node]:
                seen_nodes.add(n)
    return seen_nodes - non_terminal_nodes


def is_topological_sort(
    graph: dict[str, list[str]],
    ordering: list[str],
    is_strict: bool = True,
) -> bool:
    """Graph traversal to check if every node in `graph` is visited in `ordering` only after all its dependencies are visited.

    Args:
        graph: the graph representing the ground truth, where keys represent nodes and values represent its dependent nodes
        ordering: the nodes visited, in order
        is_strict: if True, only consider most recent tool call; if False, consider all tool calls

    Returns:
        Boolean representing if `ordering` visits all nodes in a valid order based on the dependencies in graph.
    """
    # No keyword match or goal details were achieved
    if not ordering:
        return False

    if is_strict:
        # strict matching: only consider most recent tool call
        position = {node: [i] for i, node in enumerate(ordering)}
    else:
        # lenient matching: consider all tool calls (account for all indexes of the node)
        position = defaultdict(list)
        for i, node in enumerate(ordering):
            position[node].append(i)

    terminal_nodes = find_terminal_nodes(graph)
    # adds a dummy node for each terminal node
    DUMMY_GRAPH_NODE_NAME = "dummy-goal"
    next_idx = (
        max(val for values in position.values() for val in values) + 1
        if position
        else 0
    )

    for n in terminal_nodes:
        graph[n] = [DUMMY_GRAPH_NODE_NAME]
        graph[DUMMY_GRAPH_NODE_NAME] = []
        position[DUMMY_GRAPH_NODE_NAME] = [next_idx]
        next_idx += 1

    for node in graph:
        for child_nodes in graph[node]:
            # Current node/children doesn't show up in made calls
            if node not in position or child_nodes not in position:
                return False
            # Current node doesn't show up before any of its child
            # all index in current nodes are larger than every child nodes' index
            if all(
                curr >= max(position[child_nodes]) for curr in position[node]
            ):
                return False
    return True
