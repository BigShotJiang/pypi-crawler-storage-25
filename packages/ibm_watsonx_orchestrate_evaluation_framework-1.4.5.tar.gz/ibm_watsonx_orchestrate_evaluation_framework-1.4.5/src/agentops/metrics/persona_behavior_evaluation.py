"""LLM-as-a-Judge evaluation for simulated user behavior quality.

Judges whether the simulated user's persona behavior is realistic and
does not unrealistically prevent goal completion.  This evaluates the
*user simulator*, not the agent.
"""

import json
import os
from typing import Any, Dict, List, Mapping, Optional, Union

from agentops.metrics.evaluations import Evaluation
from agentops.metrics.metrics import EvaluatorData
from agentops.prompt.template_render import JinjaTemplateRenderer
from agentops.service_provider.provider import Provider
from agentops.type import ContentType, Message, TestCase

root_dir: str = os.path.dirname(os.path.dirname(__file__))
PERSONA_BEHAVIOR_PROMPT_PATH = os.path.join(
    root_dir, "prompt", "persona_behavior_prompt.jinja2"
)


class PersonaBehaviorEvaluation(Evaluation):
    """Evaluate whether a persona's simulated behavior is realistic.

    Criteria judged (each scored 0-1):
    - goal_interference: Did the persona prevent the conversation from
      reaching a goal that should have been achievable?
    - behavioral_realism: Is the persona's behavior realistic for someone
      with that profile?
    - entity_integrity: Did the persona fabricate information not present
      in the story or agent messages?

    Usage::

        metric = PersonaBehaviorEvaluation(
            llm_client=provider,
            config={"persona_id": "confused"},
        )
        result = metric.evaluate(messages, ground_truth=dataset)
    """

    def __init__(
        self,
        llm_client: Optional[Provider] = None,
        prompt_path: Optional[str] = PERSONA_BEHAVIOR_PROMPT_PATH,
        config: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(llm_client)
        self.renderer = JinjaTemplateRenderer(prompt_path)
        self.config = config or {}

    def _extract_conversation_transcript(self, messages: List[Message]) -> str:
        parts = []
        for msg in messages:
            if msg.type == ContentType.text:
                content = (
                    msg.content
                    if isinstance(msg.content, str)
                    else str(msg.content)
                )
                parts.append(f"{msg.role}: {content}")
            elif msg.type == ContentType.tool_call:
                parts.append(f"{msg.role}: [tool_call] {msg.content}")
            elif msg.type == ContentType.tool_response:
                parts.append(f"tool: {msg.content}")
        return "\n".join(parts) if parts else "No conversation"

    def _get_user_story(self, ground_truth: Optional[TestCase]) -> str:
        if ground_truth and ground_truth.story:
            return ground_truth.story
        return ""

    def _get_expected_goals(self, ground_truth: Optional[TestCase]) -> str:
        if not ground_truth or not ground_truth.goal_details:
            return ""
        parts = []
        for gd in ground_truth.goal_details:
            parts.append(f"- {gd.name} ({gd.type})")
        return "\n".join(parts)

    def _parse_llm_response(self, response_text: str) -> Dict[str, Any]:
        text = response_text.strip()
        if text.startswith("```json"):
            text = text[7:]
        if text.startswith("```"):
            text = text[3:]
        if text.endswith("```"):
            text = text[:-3]
        try:
            return json.loads(text.strip())
        except (json.JSONDecodeError, ValueError):
            return {}

    def do_evaluate(
        self,
        messages: List[Message],
        ground_truth: Optional[TestCase] = None,
        metadata: Mapping[str, Any] = None,
        **kwargs,
    ) -> Union[EvaluatorData, List[EvaluatorData]]:
        transcript = self._extract_conversation_transcript(messages)
        user_story = self._get_user_story(ground_truth)
        expected_goals = self._get_expected_goals(ground_truth)
        persona_id = self.config.get("persona_id", "unknown")
        termination_reason = self.config.get("termination_reason", "unknown")

        if not transcript or transcript == "No conversation":
            return EvaluatorData(
                eval_name="goal_interference",
                value=None,
                comment="No conversation to evaluate",
                metadata=metadata,
            )

        prompt_messages = self.renderer.render(
            conversation_transcript=transcript,
            user_story=user_story,
            expected_goals=expected_goals,
            persona_id=persona_id,
            termination_reason=termination_reason,
        )

        response = self.llm_client.chat(prompt_messages)
        response_text = response.choices[0].message.content
        data = self._parse_llm_response(response_text)

        metrics = []
        for criterion in (
            "goal_interference",
            "behavioral_realism",
            "entity_integrity",
        ):
            criterion_data = data.get(criterion, {})
            score = criterion_data.get("score", 0.0)
            reasoning = criterion_data.get("reasoning", "")
            metrics.append(
                EvaluatorData(
                    eval_name=criterion,
                    value=float(score),
                    comment=reasoning,
                    metadata={**(metadata or {}), "persona_id": persona_id},
                )
            )

        return metrics
