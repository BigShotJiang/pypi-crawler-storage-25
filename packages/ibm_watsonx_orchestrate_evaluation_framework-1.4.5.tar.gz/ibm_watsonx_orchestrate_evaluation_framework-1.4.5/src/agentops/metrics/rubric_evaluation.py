import json
import os
from typing import Any, Dict, List, Mapping, Optional, Union

from pydantic import BaseModel

from agentops.metrics.evaluations import Evaluation
from agentops.metrics.metrics import EvaluatorData
from agentops.prompt import RUBRIC_EVALUATION_PROMPT_PATH
from agentops.prompt.template_render import JinjaTemplateRenderer
from agentops.service_provider.provider import Provider
from agentops.type import ContentType, Message, TestCase


class CriterionResult(BaseModel):
    """Result for a single evaluation criterion."""

    score: float
    reasoning: str


class RubricEvaluationResult(BaseModel):
    """Full result from the rubric-based evaluation."""

    correctness: CriterionResult
    policy_adherence: CriterionResult
    custom_criteria: Optional[Dict[str, CriterionResult]] = None
    overall_score: float
    summary: str


class RubricEvaluation(Evaluation):
    """
    LLM-as-a-Judge rubric-based evaluation.

    Evaluates an agent's response against defined rubrics (scoring criteria).
    Supports two types of ground truth:
    1. Gold answer - exact expected response in goal_details[].response
    2. Answer description - high-level criteria describing what the answer should contain

    Default rubrics:
    - Correctness: Does the answer match the expected answer/description?
    - Policy adherence: Did the agent follow proper procedures?

    Custom rubrics can be provided via config for additional evaluation dimensions.
    Each rubric is evaluated separately and returns its own score.

    Example:
        # Basic usage
        metric = RubricEvaluation(llm_client=provider)
        result = metric.evaluate(messages, ground_truth=dataset)

        # With custom rubrics (each gets a separate score)
        metric = RubricEvaluation(
            llm_client=provider,
            config={
                "custom_criteria": {
                    "source_citations": "Response must include references to official policy documents",
                    "date_format": "All dates must be in ISO format (YYYY-MM-DD)",
                    "completeness": "Must cover PTO accrual, eligibility, and procedures"
                }
            }
        )
    """

    def __init__(
        self,
        llm_client: Optional[Provider] = None,
        prompt_path: Optional[str] = RUBRIC_EVALUATION_PROMPT_PATH,
    ):
        """
        Initialize the RubricEvaluation.

        Args:
            llm_client: LLM provider for evaluation
            config: Optional configuration dict with:
                - custom_criteria: Dict[str, str] - Named evaluation rubrics
                  e.g. {"source_citations": "Must include references to docs"}
                - include_tool_calls: bool - Include tool call sequence (default: True)
        """
        super().__init__(llm_client)
        self.renderer = JinjaTemplateRenderer(RUBRIC_EVALUATION_PROMPT_PATH)

    def _extract_conversation_context(
        self, messages: List[Message]
    ) -> tuple[str, str, str]:
        """
        Extract conversation context, user request, and agent answer from messages.

        Returns:
            Tuple of (full_conversation, first_user_request, final_agent_answer)
        """
        # Build FULL conversation transcript including tool calls
        conversation_parts = []
        for msg in messages:
            if msg.type == ContentType.text:
                content = (
                    msg.content
                    if isinstance(msg.content, str)
                    else str(msg.content)
                )
                conversation_parts.append(f"{msg.role}: {content}")
            elif msg.type == ContentType.tool_call:
                conversation_parts.append(
                    f"{msg.role}: [tool_call] {msg.content}"
                )
            elif msg.type == ContentType.tool_response:
                conversation_parts.append(f"tool: {msg.content}")

        # Get first user request
        user_request = ""
        for msg in messages:
            if msg.role == "user" and msg.type == ContentType.text:
                user_request = (
                    msg.content
                    if isinstance(msg.content, str)
                    else str(msg.content)
                )
                break

        # Get final agent answer
        agent_answer = ""
        for msg in reversed(messages):
            if msg.role == "assistant" and msg.type == ContentType.text:
                agent_answer = (
                    msg.content
                    if isinstance(msg.content, str)
                    else str(msg.content)
                )
                break

        full_conversation = (
            "\n".join(conversation_parts)
            if conversation_parts
            else "No conversation"
        )
        return full_conversation, user_request, agent_answer

    def _extract_tool_call_sequence(self, messages: List[Message]) -> str:
        """Extract tool call sequence from messages."""
        tool_calls = []
        for msg in messages:
            if msg.type == ContentType.tool_call:
                try:
                    content = (
                        json.loads(msg.content)
                        if isinstance(msg.content, str)
                        else msg.content
                    )
                    name = content.get("name", "unknown")
                    args = content.get("arguments", content.get("args", {}))
                    tool_calls.append(f"- {name}({json.dumps(args)})")
                except (json.JSONDecodeError, AttributeError):
                    tool_calls.append(f"- {msg.content}")

        return "\n".join(tool_calls) if tool_calls else ""

    def _get_expected_answer(self, ground_truth: Optional[TestCase]) -> str:
        """
        Get the expected answer from ground truth.

        Looks for text-type goal_details with a response field.
        """
        if not ground_truth or not ground_truth.goal_details:
            return ""

        expected_parts = []
        for goal_detail in ground_truth.goal_details:
            if goal_detail.type == ContentType.text and goal_detail.response:
                expected_parts.append(
                    f"**{goal_detail.name}**: {goal_detail.response}"
                )

        return "\n".join(expected_parts) if expected_parts else ""

    def _parse_llm_response(
        self, response_text: str, custom_criteria_keys: List[str]
    ) -> RubricEvaluationResult:
        """Parse the LLM response into structured result."""
        try:
            response_text = response_text.strip()
            if response_text.startswith("```json"):
                response_text = response_text[7:]
            if response_text.startswith("```"):
                response_text = response_text[3:]
            if response_text.endswith("```"):
                response_text = response_text[:-3]

            data = json.loads(response_text.strip())

            # Parse custom criteria results
            custom_results = None
            if custom_criteria_keys and data.get("custom_criteria"):
                custom_results = {}
                for key in custom_criteria_keys:
                    if key in data["custom_criteria"]:
                        custom_results[key] = CriterionResult(
                            **data["custom_criteria"][key]
                        )

            return RubricEvaluationResult(
                correctness=CriterionResult(
                    **data.get("correctness", {"score": 0, "reasoning": ""})
                ),
                policy_adherence=CriterionResult(
                    **data.get(
                        "policy_adherence", {"score": 0, "reasoning": ""}
                    )
                ),
                custom_criteria=custom_results,
                overall_score=data.get("overall_score", 0),
                summary=data.get("summary", ""),
            )
        except (json.JSONDecodeError, KeyError, TypeError) as e:
            return RubricEvaluationResult(
                correctness=CriterionResult(
                    score=0, reasoning=f"Failed to parse LLM response: {e}"
                ),
                policy_adherence=CriterionResult(score=0, reasoning=""),
                overall_score=0,
                summary=f"Evaluation failed: {e}",
            )

    def do_evaluate(
        self,
        messages: List[Message],
        ground_truth: Optional[TestCase] = None,
        metadata: Mapping[str, Any] = None,
    ) -> Union[EvaluatorData, List[EvaluatorData]]:
        """
        Evaluate the agent's answer for correctness.

        Args:
            messages: Conversation messages
            ground_truth: Ground truth data containing expected answers
            metadata: Additional metadata

        Returns:
            List of EvaluatorData with scores for each criterion
        """
        conversation_context, user_request, agent_answer = (
            self._extract_conversation_context(messages)
        )

        expected_answer = self._get_expected_answer(ground_truth)

        if not expected_answer:
            return EvaluatorData(
                eval_name="correctness",
                value=None,
                comment="No expected answer found in ground truth",
                metadata=metadata,
            )

        if not agent_answer:
            return EvaluatorData(
                eval_name="correctness",
                value=0.0,
                comment="No agent answer found in messages",
                metadata=metadata,
            )

        tool_call_sequence = ""
        if self.config.get("include_tool_calls", True):
            tool_call_sequence = self._extract_tool_call_sequence(messages)

        custom_criteria = self.config.get("custom_criteria", {})
        custom_criteria_keys = (
            list(custom_criteria.keys()) if custom_criteria else []
        )

        prompt_messages = self.renderer.render(
            conversation_context=conversation_context,
            user_request=user_request,
            agent_answer=agent_answer,
            expected_answer=expected_answer,
            tool_call_sequence=tool_call_sequence,
            custom_criteria=custom_criteria if custom_criteria else None,
        )

        response = self.llm_client.chat(prompt_messages)
        response_text = response.choices[0].message.content

        result = self._parse_llm_response(response_text, custom_criteria_keys)

        # Build metrics list
        metrics = [
            EvaluatorData(
                eval_name="correctness",
                value=result.correctness.score,
                comment=result.correctness.reasoning,
                metadata={**(metadata or {}), "criterion": "correctness"},
            ),
            EvaluatorData(
                eval_name="policy_adherence",
                value=result.policy_adherence.score,
                comment=result.policy_adherence.reasoning,
                metadata={**(metadata or {}), "criterion": "policy_adherence"},
            ),
        ]

        # Add individual custom criteria metrics - configurable
        if result.custom_criteria:
            for name, criterion_result in result.custom_criteria.items():
                metrics.append(
                    EvaluatorData(
                        eval_name=f"custom_{name}",
                        value=criterion_result.score,
                        comment=criterion_result.reasoning,
                        metadata={**(metadata or {}), "criterion": name},
                    )
                )

        return metrics


if __name__ == "__main__":
    from agentops.service_provider import get_provider

    llm_client = get_provider(model_id="openai/gpt-oss-120b")
    metric = RubricEvaluation(llm_client)
    messages = [
        Message(
            role="user",
            content="What is Labcorp's annual leave policy?",
            type=ContentType.text,
        ),
        Message(
            role="assistant",
            content="I'm not sure about the specific policy. You should check with HR.",
            type=ContentType.text,
        ),
    ]

    from agentops.type import GoalDetailOrchestrate

    gt = TestCase(
        story="User wants to know about annual leave policy",
        starting_sentence="What is Labcorp's annual leave policy?",
        goals={"explain_policy": []},
        goal_details=[
            GoalDetailOrchestrate(
                name="explain_policy",
                type=ContentType.text,
                response="""PTO accrual is 15 days for 0-2 years, 20 days for 3-5 years, and 25 days for 6+ years.
    Full-time employees are eligible after 90 days. Requests must be submitted 2 weeks in advance through the HR portal.""",
            )
        ],
    )
    output = metric.evaluate(messages=messages, ground_truth=gt)

    for metric in output["metric"]["RubricEvaluation"]:
        print(metric)
