from agentops.extractors.agent_resp_extractor import AgentResponseExtractor
from agentops.metrics.evaluations import Evaluation
from agentops.metrics.metrics import EvaluatorData
from agentops.operator.operator_base import OperatorBase
from agentops.type import Message


class AgentResponseTime(Evaluation):
    def __init__(self, llm_client=None):
        super().__init__(llm_client)

    def do_evaluate(self, messages: list[Message], **kwargs) -> EvaluatorData:
        response_time = [
            message.response_time
            for message in messages
            if message.response_time is not None
        ]
        if response_time:
            average_response_time = round(
                sum(response_time) / len(response_time), 3
            )
            return EvaluatorData(
                eval_name="average_agent_response_time",
                display_name="Average Agent Response Time (s)",
                value=average_response_time,
            )
        else:
            return EvaluatorData(
                eval_name="average_agent_response_time",
                display_name="Average Agent Response Time (s)",
                value=0.0,
            )
