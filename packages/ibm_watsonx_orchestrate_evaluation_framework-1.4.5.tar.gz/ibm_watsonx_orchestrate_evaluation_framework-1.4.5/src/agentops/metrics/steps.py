from agentops.metrics.evaluations import Evaluation
from agentops.metrics.metrics import EvaluatorData
from agentops.type import ContentType


class StepMetrics(Evaluation):
    def do_evaluate(self, messages, ground_truth=None, metadata=None, **kwargs):
        total_steps = len(messages)
        llm_steps = len(
            [
                message
                for message in messages
                if message.role == "assistant"
                and message.type
                in [
                    ContentType.text,
                    ContentType.tool_call,
                    ContentType.conversational_search,
                ]
            ]
        )

        metrics = [
            EvaluatorData(
                eval_name="total_steps",
                display_name="Total Steps",
                value=total_steps,
                metadata=metadata,
            ),
            EvaluatorData(
                eval_name="llm_steps",
                display_name="LLM Steps",
                value=llm_steps,
                metadata=metadata,
            ),
        ]
        return metrics
