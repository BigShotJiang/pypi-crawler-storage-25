from typing import Any, List, Mapping

from fuzzywuzzy import fuzz

from agentops.extractors.agent_resp_extractor import AgentResponseExtractor
from agentops.metrics.evaluations import Evaluation
from agentops.metrics.metrics import EvaluatorData
from agentops.operator.operator_base import OperatorBase
from agentops.prompt import GPT_SEMANTIC_MATCHING_PROMPT_V2_PATH
from agentops.prompt.template_render import SemanticMatchingTemplateRenderer
from agentops.type import ChatCompletions, Message


class SemanticMatchMetric(Evaluation):
    def __init__(
        self,
        llm_client=None,
        prompt_path=GPT_SEMANTIC_MATCHING_PROMPT_V2_PATH,
        enable_fuzzy_matching: bool = False,
        similarity_threshold: float = 0.8,
    ):
        super().__init__(llm_client)
        self.prompt_path = prompt_path
        self.semantic_template = SemanticMatchingTemplateRenderer(
            self.prompt_path
        )
        self.enable_fuzzy_matching = enable_fuzzy_matching
        self.similarity_threshold = similarity_threshold
        self.dependencies = [AgentResponseExtractor()]

    def _llm_semantic_match(
        self, context: str, expected: str, actual: str
    ) -> bool:
        """Use LLM to determine if texts match semantically.

        Args:
            context: Context/starting sentence
            expected: The reference text
            actual: The actual text to be evaluated

        Returns:
            True if texts match semantically
        """
        prompt = self.semantic_template.render(
            context=context,
            expected_text=expected,
            actual_text=actual,
        )
        output: ChatCompletions = self.llm_client.chat(prompt)
        output_str: str = output.choices[0].message.content
        semantic_match = output_str.strip().lower().startswith("true")
        return semantic_match

    def _semantic_match(self, context: str, expected: str, actual: str) -> bool:
        """Perform semantic matching between expected and actual text,
        along with given context. Uses LLM-based semantic matching and falls back to fuzzy matching (when enabled) if it fails.

        Args:
            context: Context/starting sentence
            expected: The reference text
            actual: The actual text to be evaluated

        Returns:
            bool: True if texts match semantically
        """
        try:
            return self._llm_semantic_match(context, expected, actual)
        except Exception:
            pass

        if self.enable_fuzzy_matching:
            similarity_score = fuzz.WRatio(actual, expected)
            similarity_threshold = self.similarity_threshold
            return similarity_score > similarity_threshold

        return False

    def do_evaluate(
        self,
        messages: List[Message],
        ground_truth,
        metadata: Mapping[str, Any] = None,
        **kwargs,
    ) -> Any:
        extracted_context = kwargs.get("extracted_context", {})

        # Get extracted text data
        extractor_context = extracted_context.get("extractor", {})
        agent_response_extractor = extractor_context.get(
            OperatorBase.key(self.dependencies[0])
        )
        text_goals = agent_response_extractor.get("text_goals").value
        text_responses = agent_response_extractor.get("text_responses").value

        # keep track of keyword matches
        semantic_matches: list[bool] = []

        starting_sentence: str = messages[0].content if messages else ""
        for message in text_responses:
            for goal_detail in text_goals:
                semantic_match = self._semantic_match(
                    context=starting_sentence,
                    expected=goal_detail.response,
                    actual=message.content,
                )

                semantic_matches.append(semantic_match)

        metadata = metadata or {}
        metadata.update({"semantic_matches": semantic_matches})
        return EvaluatorData(
            eval_name="semantic_match",
            display_name="Semantic Match",
            value=all(semantic_matches),
            metadata=metadata,
        )
