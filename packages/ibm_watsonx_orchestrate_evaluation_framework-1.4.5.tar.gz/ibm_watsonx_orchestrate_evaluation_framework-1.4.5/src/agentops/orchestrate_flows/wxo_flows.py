import json
import time
from enum import StrEnum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel

from agentops.clients import WXOClient
from agentops.runtime_adapter.events.orchestrate_events import (
    FlowEvents,
    FlowTaskDataModel,
)
from agentops.runtime_adapter.wxo_runtime_adapter import WXORuntimeAdapter
from agentops.type import ContentType, Function, Message, ToolCall
from agentops.utils.rich_utils import RichLogger
from agentops.wxo_client import get_wxo_flows_client

logger = RichLogger(__name__)

FLOW_END = "__flow_end__"


class FlowStatus(StrEnum):
    # Taken from https://github.ibm.com/WatsonOrchestrate/wxo-server/blob/ed4b7de6c896353885263f1cc7e8c93233ac3ed4/wo_archer/api/routers/flows.py#L1044-L1053C24
    in_progress = "in_progress"
    completed = "completed"
    interrupted = "interrupted"
    failed = "failed"


class FlowResults(BaseModel):
    instance_id: str
    state: FlowStatus
    output: Dict[str, Any]
    messages: List[Message]


class FlowMetadata(BaseModel):
    flow_name: str
    flow_id: str
    id: str
    servers: List[str]
    display_name: Optional[str] = None
    description: Optional[str] = None
    is_async: bool = False
    http_method: Optional[str] = None
    http_path: Optional[str] = None
    version: Optional[str] = None

    @classmethod
    def from_api_response(
        cls, flow_name: str, flow_data: Dict[str, Any]
    ) -> "FlowMetadata":
        """
        Parse flow metadata from the nested API response structure.

        Expected structure:
        {
            'binding': {'flow': {'flow_id': '...', 'servers': [...], 'http_method': '...', 'http_path': '...'}},
            'id': '...',
            'name': '...',
            'display_name': '...',
            'description': '...',
            'is_async': True/False,
            ...
        }
        """
        binding_flow = flow_data.get("binding", {}).get("flow", {})

        return cls(
            flow_name=flow_name,
            flow_id=binding_flow.get("flow_id", flow_data.get("id", "")),
            id=flow_data.get("id", ""),
            servers=binding_flow.get("servers", []),
            display_name=flow_data.get("display_name"),
            description=flow_data.get("description"),
            is_async=flow_data.get("is_async", False),
            http_method=binding_flow.get("http_method"),
            http_path=binding_flow.get("http_path"),
            version=binding_flow.get("version"),
        )


class WXOFlowsExecutor:
    def __init__(
        self,
        flow_name: str,
        wxo_agent: WXORuntimeAdapter,
        wxo_flow_client: WXOClient,
    ):
        self.tool_mapping = wxo_agent.get_tool_name2tool()
        self.wxo_flow_client = wxo_flow_client
        self.flow_metadata = self._valid_flow(flow_name)
        self.flow_name = flow_name

    def _valid_flow(self, flow_name: str) -> FlowMetadata:
        # flows are listed as tools
        if flow_name not in self.tool_mapping:
            raise ValueError(
                f"Flow with name {flow_name} not found. Make sure the flow is imported into your tenant."
            )

        flow_data = self.tool_mapping[flow_name]
        flow_metadata = FlowMetadata.from_api_response(flow_name, flow_data)
        return flow_metadata

    def execute_flow(
        self, input_data: dict, timeout_seconds: int = 60
    ) -> FlowResults:
        """Execute the flow with the given input data."""
        if not self.flow_metadata.servers:
            raise ValueError(f"No servers configured for flow {self.flow_name}")

        # TODO: Flows can be run either async or sync. Leaving the async url for future reference.
        response = self.wxo_flow_client.post(
            payload=input_data,
            path=f"v1/flows/{self.flow_metadata.flow_id}/versions/{self.flow_metadata.version}{self.flow_metadata.http_path}",
        )
        # response = self.wxo_flow_client.post(payload=input_data, path=f"v1/flows/{self.flow_metadata.flow_id}/versions/{self.flow_metadata.version}/run?request_timeout={timeout_seconds * 1000}")
        resp_json = response.json()
        instance_id = resp_json.get("instance_id")

        messages = []

        elapsed_time = 0
        while elapsed_time < timeout_seconds:
            response = self.wxo_flow_client.get(
                path=f"v1/flows/", params={"instance_id": instance_id}
            )
            resp_json = response.json()[0]
            state = resp_json.get("state")
            if state == FlowStatus.failed:
                logger.warn(
                    f"Flow {self.flow_name} failed with output {resp_json.get('output')}"
                )
                return FlowResults(
                    instance_id=instance_id,
                    state=state,
                    output=resp_json.get("output"),
                )

            if state == FlowStatus.completed:
                tasks = resp_json.get("tasks", [])
                for task in tasks:
                    input = task.get("input", {})
                    output = task.get("output", {})

                    if task.get("name") == FLOW_END:
                        message = Message(
                            role="assistant",
                            content=json.dumps(input),
                            type=ContentType.text,
                        )
                        messages.append(message)
                    else:
                        tool_call = ToolCall(
                            id=task.get("task_instance_id"),
                            function=Function(
                                name=task.get("name"),
                                arguments=json.dumps(input),
                            ),
                        )
                        tool_call = Message(
                            role="assistant",
                            content=json.dumps(input),
                            type=ContentType.tool_call,
                            tool_calls=[tool_call],
                        )

                        tool_response = Message(
                            role="assistant",
                            content=json.dumps(output),
                            type=ContentType.tool_response,
                        )

                        messages.append(tool_call)
                        messages.append(tool_response)

                return FlowResults(
                    instance_id=instance_id,
                    state=state,
                    output=resp_json.get("output"),
                    messages=messages,
                )

            elapsed_time += 1
            time.sleep(1)

        raise Exception(
            f"Flow {self.flow_name} timed out after {timeout_seconds} seconds"
        )


if __name__ == "__main__":
    import re

    from agentops.runtime_adapter.wxo_runtime_adapter import WXORuntimeAdapter
    from agentops.type import CallTracker
    from agentops.wxo_client import get_wxo_client

    def extract_instance_id(text: str) -> str | None:
        print("this is the text: ", text)
        UUID_RE = re.compile(
            r"flow instance ID\s+([0-9a-fA-F]{8}-"
            r"[0-9a-fA-F]{4}-"
            r"[0-9a-fA-F]{4}-"
            r"[0-9a-fA-F]{4}-"
            r"[0-9a-fA-F]{12})"
        )
        match = UUID_RE.search(text)
        return match.group(1) if match else None

    def stream_flow_events(instance_id: str, base_url: str):
        import requests

        url = f"{base_url}/flows/{instance_id}/events"
        params = {"start_from_id": "0", "stream_timeout": 60000}

        t = requests.get(url, params=params, stream=True)
        print("this is the response: ", t.text)

        # with requests.get(url, params=params, stream=True) as response:
        #     for line in response.iter_lines():
        #         print("line: ", line)
        #         if line:
        #             event = json.loads(line.decode('utf-8'))
        #             print(event)
        #             yield event

        #             if event['data']['kind'] in ['on_flow_end', 'on_flow_error']:
        #                 break

    wxo_client = get_wxo_client(
        "http://localhost:4321",
        "local",
    )

    wxo_runtime_adapter = WXORuntimeAdapter(wxo_client)
    response = wxo_runtime_adapter.run(
        # user_input=Message(
        #     role="user", content="book me a flight from amsterdam to boston departing on 12/01/25 and returning 12/03/25", type=ContentType.text
        # ),
        user_input=Message(
            role="user",
            content="invoke flow my name is john smith",
            type=ContentType.text,
        ),
        context={
            "agent_name": "hello_message_datamap_agent",
            "call_tracker": CallTracker(),
        },
        # context={"agent_name": "Book_a_flight_agent", "call_tracker": CallTracker()}
    )

    extracted_instanced_id = extract_instance_id(response.messages[-2].content)

    print()
    print()
    import rich

    response2 = wxo_client.get(
        path=f"/v1/flows/{extracted_instanced_id}/events",
        stream=True,
        params={"start_from_id": "0", "stream_timeout": "5000"},
    )
    events = []
    for chunk in wxo_runtime_adapter._parse_events(response2):
        if (chunk := json.loads(chunk.strip())) and chunk["data"][
            "kind"
        ] != "stream_timeout":
            # chunk = json.loads(chunk.strip())
            events.append(FlowEvents.from_api_response(chunk))

    rich.print("---Below is from /events stream")
    rich.print(events)
    rich.print()
    rich.print("----Below is from /tasks endpoint-------")
    # in the actual code we will do this once flow processing completes
    response3 = wxo_client.get(path=f"/v1/flows/{extracted_instanced_id}/tasks")
    tasks = []
    for task in response3.json():
        # print(task.strip())
        try:
            tasks.append(FlowTaskDataModel.model_validate(task))
        except Exception as e:
            print(task)
            raise e

    rich.print(tasks)
    # # response2 = stream_flow_events(instance_id=extracted_instanced_id, base_url="http://localhost:4321/v1")

    # print(response2)

    # print("-----")

    # response2 = wxo_client.get(path="/v1/flows/")
    # import rich
    # rich.print(response2.json())

    # wxo_flows_client = get_wxo_flows_client(
    #     "http://localhost:4321",
    #     "local",
    # )

    # wxo_agent = WXORuntimeAdapter(wxo_client)
    # flows_executor = WXOFlowsExecutor(
    #     "hello_message_flow_datamap", wxo_agent, wxo_flows_client
    # )
    # response = flows_executor.execute_flow(
    #     input_data={"first_name": "John", "last_name": "Doe"}
    # )
    # from rich import print

    # print(response.model_dump())
