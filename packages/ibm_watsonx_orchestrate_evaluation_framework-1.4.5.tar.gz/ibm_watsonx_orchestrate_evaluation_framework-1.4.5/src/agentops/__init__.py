import agentops.fips_patch  # noqa: F401 - FIPS compliance, must be first
