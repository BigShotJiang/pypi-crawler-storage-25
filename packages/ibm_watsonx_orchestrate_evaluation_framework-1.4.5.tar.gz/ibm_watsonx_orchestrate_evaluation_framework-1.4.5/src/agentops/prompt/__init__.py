import importlib.resources as resources

prompt_dir = resources.files("agentops.prompt")

KEYWORD_MATCHING_PROMPT_PATH = prompt_dir / "keyword_matching_prompt.jinja2"
SEMANTIC_MATCHING_PROMPT_V1_PATH = (
    prompt_dir / "semantic_matching_prompt_v1.jinja2"
)
SEMANTIC_MATCHING_PROMPT_V2_PATH = (
    prompt_dir / "semantic_matching_prompt_v2.jinja2"
)
FAITHFULNESS_PROMPT_PATH = prompt_dir / "faithfulness_prompt.jinja2"
ANSWER_RELEVANCY_PROMPT_PATH = prompt_dir / "answer_relevancy_prompt.jinja2"
DERAILMENT_PROMPT_PATH = prompt_dir / "derailment_prompt.jinja2"
UNSAFE_TOPIC_PROMPT_PATH = prompt_dir / "unsafe_topic_prompt.jinja2"
UNSAFE_TOPIC_GRANITE_GUARDIAN_PATH = (
    prompt_dir / "unsafe_topic_granite_guardian_prompt.jinja2"
)
RUBRIC_EVALUATION_PROMPT_PATH = prompt_dir / "rubric_evaluation_prompt.jinja2"
LLAMA_USER_PROMPT_PATH = prompt_dir / "llama_user_prompt.jinja2"

QUALITY_EVAL_TEMPLATE_PATH = "src/agentops/prompt/eval_data_quality.jinja2"
COMPLEXITY_EVAL_TEMPLATE_PATH = (
    "src/agentops/prompt/eval_data_complexity.jinja2"
)


##### GPT prompts #####
GPT_SEMANTIC_MATCHING_PROMPT_V1_PATH = (
    prompt_dir / "gpt" / "semantic_matching_prompt.jinja2"
)
GPT_SEMANTIC_MATCHING_PROMPT_V2_PATH = (
    prompt_dir / "gpt" / "semantic_matching_prompt_v2.jinja2"
)
GPT_KEYWORD_MATCHING_PROMPT_PATH = (
    prompt_dir / "gpt" / "keyword_matching_prompt.jinja2"
)

GPT_DERAILMENT_PROMPT_PATH = prompt_dir / "gpt" / "derailment_prompt.jinja2"
GPT_UNSAFE_TOPIC_PROMPT_PATH = prompt_dir / "gpt" / "unsafe_topic_prompt.jinja2"

GPT_FAITHFULNESS_PROMPT_PATH = prompt_dir / "gpt" / "faithfulness_prompt.jinja2"
GPT_ANSWER_RELEVANCY_PROMPT_PATH = (
    prompt_dir / "gpt" / "answer_relevancy_prompt.jinja2"
)
GPT_QUALITY_EVAL_TEMPLATE_PATH = prompt_dir / "gpt" / "eval_data_quality.jinja2"
GPT_COMPLEXITY_EVAL_TEMPLATE_PATH = (
    prompt_dir / "gpt" / "eval_data_complexity.jinja2"
)
