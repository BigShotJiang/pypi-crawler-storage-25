from typing import Any, List, Optional

from agentops.metrics.metrics import EvaluatorData
from agentops.persistence.persistence_base import PersistenceBase
from agentops.stats import Result
from agentops.type import Message, TestCase
from agentops.utils.optional_imports import get_langfuse_client
from agentops.utils.rich_utils import RichLogger

CLIENT = None

logger = RichLogger(__name__)


class LangfusePersistence(PersistenceBase):
    def __init__(self):
        if CLIENT is None:
            self.client = get_langfuse_client()
        else:
            self.client = CLIENT

    def _sync_metrics(
        self,
        name: str,
        value: float,
        data_type: str,
        metadata: dict,
        session_id: str = None,
        dataset_run_id: str = None,
    ):

        try:
            if session_id:
                self.client.create_score(
                    name=name,
                    session_id=session_id,
                    value=value,
                    data_type=data_type,
                    metadata=metadata,
                )
            elif dataset_run_id:
                self.client.create_score(
                    name=name,
                    dataset_run_id=dataset_run_id,
                    value=value,
                    data_type=data_type,
                    metadata=metadata,
                )
            else:
                raise Exception(
                    "`dataset_run_id` or `session_id` must be passed"
                )

        except Exception as e:
            logger.error(
                f"Uploading {name} with value {value} failed with exception {e}"
            )

    def persist(
        self,
        test_cases: List[TestCase],
        messages: List[List[Message]],
        evaluation_results: List[List[EvaluatorData]],
        experiment_results: Optional[
            Any
        ] = None,  # TODO: Remove this arg once the changes are in place
        session_ids: Optional[List[str]] = None,
        experiment_id: str = None,
        **kwargs,
    ):

        # TODO: Remove if condition once the optimization changes are stabilised
        if session_ids is None:
            session_ids = [
                entry.output for entry in experiment_results.item_results
            ]

        for idx, test_case in enumerate(test_cases):
            test_case_name = test_case.dataset_name
            test_case_evaluation_results = evaluation_results[idx].get(
                test_case_name
            )
            for result in test_case_evaluation_results:
                name = result.display_name
                value = result.value
                data_type = result.data_type
                metadata = result.metadata
                session_id = session_ids[idx]

                self._sync_metrics(name, value, data_type, metadata, session_id)

    def persist_aggregated_metrics(
        self,
        evaluation_results: List[List[EvaluatorData]],
        aggregated_metrics: Result,
        **kwargs,
    ):
        dataset_id = kwargs.get("dataset_id", "")
        for metric_name, metric_value in aggregated_metrics.overall.items():
            self._sync_metrics(
                name=f"Average {metric_name}",
                value=metric_value,
                data_type="NUMERIC",
                metadata={},
                dataset_run_id=dataset_id,
            )
