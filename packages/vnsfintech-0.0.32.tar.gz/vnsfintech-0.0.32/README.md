# VNSFintech

`VNSFintech` là thư viện Python cung cấp dữ liệu và công cụ hỗ trợ tài chính cho các nhà đầu tư và phân tích thị trường chứng khoán.

## Cài đặt

Cài đặt thư viện mới:

```bash
pip install VNSFintech
```

Cập nhật phiên bản mới:

```bash
pip install --upgrade VNSFintech
```

## Sử dụng

```python
from VNSFintech import *
```

---

# Hướng dẫn sử dụng
Thư viện `VNSFintech` được chia làm các mảng chính:

_ stock: dữ liệu về cổ phiếu được niêm yết trên các sàn giao dịch chứng khoán Việt Nam.

_ exchange: dữ liệu về các sàn giao dịch chứng khoán Việt Nam.

_ indice: dữ liệu về các chỉ số chứng khoán.

_ fund: dữ liệu về chứng chỉ quỹ trên các sàn giao dịch chứng khoán Việt Nam.

_ macro_economic: dữ liệu về các chỉ số kinh tế vĩ mô của Việt Nam.

_ other: dữ liệu về các chỉ số khác vd: vàng, dầu thô,...


---
# **stock** : Cổ phiếu Việt Nam
Dữ liệu về cổ phiếu được chia ra làm 4 thuộc tính: thị trường, tài chính, cổ đông, tin tức - sự kiện.
---

## **market** : Dữ liệu thị trường
---

### 1. Thông tin mã cổ phiếu:

Cung cấp thông tin về cổ phiếu thuộc sàn giao dịch nào, tên và ngành của cổ phiếu đó.

`stock_info(symbol)`

Cách gọi hàm sử dụng:
```python
cp=stock(symbol='ACB')
df = cp.market.stock_info()
```
hoặc gọi nhanh: 

```python
df = stock.get_stock_info(symbol='ACB')
```

---

### 2. Lịch sử ohlcv:

Cung cấp dữ liệu lịch sử theo ngày hoặc theo phút của giá đóng cửa, giá mở của, giá cao nhất, giá thấp nhất và khối lượng giao dịch của cổ phiếu đó.

`history(symbol, start, end, time='days')`
`time`:
- `'minutes'`
- `'hours'`
- `'days'`
- `'months'`

Cách gọi hàm sử dụng:
```python
cp=stock(symbol='ACB')
df = cp.market.history(start='2020-01-01',end='2023-01-01',time='days')
```
hoặc gọi nhanh: 

```python
df = stock.get_history(symbol='ACB',start='2020-01-01',end='2023-01-01',time='days')
```

---

### 3. Lịch sử khớp lệnh:
#### Danh sách lịch sử khớp lệnh:

Cung cấp danh sách lịch sử các lệnh giao dịch đã khớp tính theo từng lệnh của cổ phiếu.

`intraday(symbol)`

Cách gọi hàm sử dụng:

```python
cp=stock(symbol='ACB')
df = cp.market.intraday()
```
hoặc gọi nhanh: 

```python
df = stock.get_intraday(symbol='ACB')
```

#### Phân loại khớp lệnh theo nhà đầu tư:

Cung cấp danh sách lịch sử khớp lệnh tính theo nhà đầu tư và phân loại khớp lệnh thành 3 loại: Cá mập, Sói già, và Cừu non.

`intraday_order(symbol)`

Cách gọi hàm sử dụng:

```python
cp=stock('ACB')
df = cp.market.intraday_order()
```

hoặc gọi nhanh:

```python
df = stock.get_intraday_order('ACB')
```

---

### 4. Thông tin giá cổ phiếu:
#### Danh sách giá cổ phiếu:

Cung cấp lịch sử dữ liệu chi tiết về giá và khối lượng giao dịch của cổ phiếu theo ngày, tháng, quý, năm.

`price_history(symbol, time, start, end)`

`time`:
- `'days'` : start = 2023-01-01 ; end = 2026-12-31
- `'months'` : start = 2023-01 ; end = 2026-12
- `'quarters'` : start = 2023 ; end = 2026
- `'years'` : start = 2023 ; end = 2026

Cách gọi hàm sử dụng:

```python
cp=stock('ACB')
df = cp.market.price_history(time='days', start='2020-01-01', end='2023-01-01')
```

hoặc gọi nhanh:

```python
df = stock.get_price_history(symbol='ACB',time='days', start='2020-01-01', end='2023-01-01')
```

#### Tổng hợp giá cổ phiếu: 

Cung cấp dữ liệu tổng đến hiện tại và trung bình theo ngày, tháng, quý, năm.

`price_history_summary(symbol,time)`

`time`:
- `'days'` : start = 2023-01-01 ; end = 2026-12-31
- `'months'` : start = 2023-01 ; end = 2026-12
- `'quarters'` : start = 2023 ; end = 2026
- `'years'` : start = 2023 ; end = 2026

Cách gọi hàm sử dụng:

```python
cp = stock('ACB')
df = cp.market.price_history_summary(time='days')
```

hoặc gọi nhanh:

```python
df = stock.get_price_history_summary(symbol='ACB',time='days', start='2020-01-01', end='2023-01-01')
```

---

### 5. Nước ngoài:
#### Lịch sử giao dịch nước ngoài:

Cung cấp dữ liệu giao dịch với nước ngoài của cổ phiếu.

`foreign_history(symbol, time, start, end)` 

`time`:
- `'days'` : start = 2023-01-01 ; end = 2026-12-31
- `'months'` : start = 2023-01 ; end = 2026-12
- `'quarters'` : start = 2023 ; end = 2026
- `'years'` : start = 2023 ; end = 2026

Cách gọi hàm sử dụng:

```python
cp = stock('ACB')
df = cp.market.foreign_history(time='days', start='2020-01-01', end='2023-01-01')
```

hoặc gọi nhanh:

```python
df = stock.get_foreign_history(symbol='ACB',time='days', start='2020-01-01', end='2023-01-01')
```

#### Tổng hợp giao dịch nước ngoài: 

Cung cấp dữ liệu tổng đến hiện tại và trung bình theo ngày, tháng, quý, năm.

`foreign_history_summary(symbol,time)`

`time`:
- `'days'` : start = 2023-01-01 ; end = 2026-12-31
- `'months'` : start = 2023-01 ; end = 2026-12
- `'quarters'` : start = 2023 ; end = 2026
- `'years'` : start = 2023 ; end = 2026

Cách gọi hàm sử dụng:

```python
cp = stock('ACB')
df = cp.market.foreign_history_summary(time='days')
```

hoặc gọi nhanh:

```python
df = stock.get_foreign_history_summary(symbol='ACB',time='days')
```

---

### 6. Tự doanh
#### Lịch sử giao dịch tự doanh:

Cung cấp dữ liệu giao dịch tự doanh của cổ phiếu.

`proprietary_history(symbol, time, start, end)`

`time`:
- `'days'` : start = 2023-01-01 ; end = 2026-12-31
- `'months'` : start = 2023-01 ; end = 2026-12
- `'quarters'` : start = 2023 ; end = 2026
- `'years'` : start = 2023 ; end = 2026

Cách gọi hàm sử dụng:

```python
cp = stock('ACB')
df = cp.market.proprietary_history(time='days', start='2020-01-01', end='2023-01-01')
```

hoặc gọi nhanh:

```python
df = stock.get_foreign_history(symbol='ACB',time='days', start='2020-01-01', end='2023-01-01')
```

#### Tổng hợp giao dịch tự doanh: 

Cung cấp dữ liệu tổng đến hiện tại và trung bình theo ngày, tháng, quý, năm.

`proprietary_history_summary(symbol, time)`

`time`:
- `'days'` : start = 2023-01-01 ; end = 2026-12-31
- `'months'` : start = 2023-01 ; end = 2026-12
- `'quarters'` : start = 2023 ; end = 2026
- `'years'` : start = 2023 ; end = 2026

Cách gọi hàm sử dụng:

```python
cp = stock('ACB')
df = cp.market.proprietary_history_summary('days')
```

hoặc gọi nhanh:

```python
df = stock.get_proprietary_history_summary(symbol='ACB',time='days')
```

---

### 7. Cung cầu

Cung cấp dữ liệu đặt mua, đặt bán, các giao dịch mua bán chưa khớp.

`demand_history(symbol, time, start, end)`

`time`:
- `'days'` : start = 2023-01-01 ; end = 2026-12-31
- `'months'` : start = 2023-01 ; end = 2026-12
- `'quarters'` : start = 2023 ; end = 2026
- `'years'` : start = 2023 ; end = 2026

Cách gọi hàm sử dụng:

```python
cp = stock('ACB')
df = cp.market.demand_history(time='days', start='2020-01-01', end='2023-01-01')
```

hoặc gọi nhanh:

```python
df = stock.get_demand_history(symbol='ACB',time='days', start='2020-01-01', end='2023-01-01')
```

---

## **financial** : Dữ liệu tài chính
---
### 1. Chỉ số tài chính:
`finance_ratio(symbol, time)`

`time`:
- `'quarters'`
- `'years'`

Cách gọi hàm sử dụng:

```python
cp = stock('ACB')
df = cp.financial.finance_ratio(time='years')
```

hoặc gọi nhanh:

```python
df = stock.get_finance_ratio(symbol='ACB', time='years')
```
---

### 2. Bảng cân đối kế toán:
`balance_sheet(symbol, time)`
 
`time`:
- `'quarters'`
- `'years'`

Cách gọi hàm sử dụng:

```python
cp = stock('ACB')
df = cp.financial.balance_sheet(time='years')
```

hoặc gọi nhanh:

```python
df = stock.get_balance_sheet(symbol='ACB', time='years')
```
---

### 3. Kết quả kinh doanh:
`income_statement(symbol, time)`

`time`:
- `'quarters'`
- `'years'`

Cách gọi hàm sử dụng:

```python
cp = stock('ACB')
df = cp.financial.income_statement(time='years')
```

hoặc gọi nhanh:

```python
df = stock.get_income_statement('ACB', time='years')
```
---

### 4. Báo cáo lưu chuyển tiền tệ:
`cash_flow(symbol, time)`

`time`:
- `'quarters'`
- `'years'`

Cách gọi hàm sử dụng:

```python
cp = stock('ACB')
df = cp.financial.cash_flow(time='years')
```

hoặc gọi nhanh:

```python
df = stock.get_cash_flow('ACB', time='years')
```
---

## **shareholder** : Dữ liệu cổ đông
---
### 1. Thông tin cổ đông:

Cung cấp danh sách các cổ đông, chức vụ, số lượng cổ phiếu sở hữu,...

`shareholders_info(symbol)`

Cách gọi hàm sử dụng:

```python
cp = stock('ACB')
df = cp.shareholder.shareholders_info()
```

hoặc gọi nhanh:

```python
df = stock.get_shareholders_info('ACB')
```
---

### 2. Cấu trúc cổ đông:

Cung cấp dữ liệu số lượng cổ phiếu phát hành và số lượng cổ phiếu các bên nắm giữ.

`shareholders_structure(symbol)`

Cách gọi hàm sử dụng:

```python
cp = stock('ACB')
df = cp.shareholder.shareholders_structure()
```

hoặc gọi nhanh:

```python
df = stock.get_shareholders_structure('ACB')
```
---

### 3. Các công ty liên quan:

Cung cấp dữ liệu về các công ty con và công ty liên kết cũng như tỷ lệ nắm giữ của cổ phiếu đó.

`shareholders_relationship(symbol)`

Cách gọi hàm sử dụng:

```python
cp = stock('ACB')
df = cp.shareholder.shareholders_relationship()
```

hoặc gọi nhanh:

```python
df = stock.get_shareholders_relationship('ACB')
```
---

### 4. Giao dịch nội bộ:

Cung cấp dữ liệu về các giao dịch cổ phiếu có liên quan đến nội bộ công ty.

`insider_trans(symbol)`

Cách gọi hàm sử dụng:

```python
cp = stock('ACB')
df = cp.shareholder.insider_trans()
```

hoặc gọi nhanh:

```python
df = stock.get_insider_trans('ACB')
```

---

## **event** : Dữ liệu tin tức & sự kiện
---

### 1. Tin tức:

Cung cấp dữ liệu tin tức liên quan đến cổ phiếu.

`news(symbol)`

Cách gọi hàm sử dụng:

```python
cp = stock('ACB')
df = cp.event.news()
```

hoặc gọi nhanh:

```python
df = stock.get_news('ACB')
```
---

### 2. Cổ tức:

Cung cấp dữ liệu về cổ tức, lịch trả cổ tức, ... của cổ phiếu.

`dividend(symbol)` 

Cách gọi hàm sử dụng:

```python
cp = stock('ACB')
df = cp.event.dividend()
```

hoặc gọi nhanh:

```python
df = stock.get_dividend('ACB')
```
---

### 3. Họp HDQT:

Cung cấp thông tin về lịch tổ chức ĐHĐCĐ thường niên.

`general_meeting(symbol)` 

Cách gọi hàm sử dụng:

```python
cp = stock('ACB')
df = cp.event.general_meeting()
```

hoặc gọi nhanh:

```python
df = stock.get_general_meeting('ACB')
```
---

### 4. Sự kiện khác:

Cung cấp thông tin niêm yết và các sự kiện khác của cổ phiếu.

`other_event(symbol)`

Cách gọi hàm sử dụng:

```python
cp = stock('ACB')
df = cp.event.other_event()
```

hoặc gọi nhanh:

```python
df = stock.get_other_event('ACB')
```
---

# **exchange** : Sàn chứng khoán Việt Nam
---

### Danh sách top cổ phiếu tăng/giảm:

`get_top_stock(exchange, up_down)`

`exchange`:
- `'HOSE'`
- `'HNX'`
- `'UPCOM'`

`up_down`:
- `'up'`
- `'down'`

Cách gọi hàm sử dụng:

```python
ex=exchange(exchange="HOSE")
df = ex.top_stock(up_down='up')
```

hoặc gọi nhanh:
```python
df = exchange.get_top_stock('HOSE', 'up')
```
---

# **indice** : chỉ số chứng khoán Việt Nam
---
### Dữ liệu chỉ số chứng khoán Việt Nam:

`overview_market(indice, start, end)`

`indice`:
- `'VNINDEX'`
- `'VN30'`
- `'HNXINDEX'`
- `'UPINDEX'`

Cách gọi hàm sử dụng:

```python
ind=indice(indice="VNINDEX")
df = ind.overview_market(start='2024-01-01',end= '2025-01-01')
```

hoặc gọi nhanh:

```python
df = indice.get_overview_market(indice='VNINDEX',start='2024-01-01',end= '2025-01-01')
```

---

# **fund** : chứng chỉ quỹ
---

### 1. Danh sách các chứng chỉ quỹ:

`fund_listing()`

Cách gọi hàm sử dụng:
```python
df = fund.fund_listing()
```
---

### 2. Tăng trưởng tài sản ròng (NAV) của quỹ:

`nav_history(fund, start, end)`

`fund`:
- `'BMFF'`
- `'87'`

Xem ở fund_listing()

Cách gọi hàm sử dụng:

```python
f=fund(fund='BMFF')
df = f.nav_history(start='2020-01-01', end='2023-01-01')
```

hoặc gọi nhanh:

```python
df = fund.get_nav_history(fund='BMFF',start='2020-01-01', end='2023-01-01')
```

---

### 3. Danh mục đầu tư lớn:
`top_holding(fund)`

`fund`:
- `'BMFF'`
- `'87'`

Xem ở fund_listing()

Cách gọi hàm sử dụng:

```python
f=fund(fund='BMFF')
df = f.top_holding()
```

hoặc gọi nhanh:

```python
df = fund.get_top_holding(fund='BMFF')
```
---

### 4. Phân bổ quỹ theo tài sản nắm giữ:
`asset_holding(fund)`

`fund`:
- `'BMFF'`
- `'87'`

Xem ở fund_listing()

Cách gọi hàm sử dụng:

```python
f=fund(fund='BMFF')
df = f.asset_holding()
```

hoặc gọi nhanh:

```python
df = fund.get_asset_holding(fund='BMFF')
```
---

### 5. Phân bổ quỹ theo ngành:
`industries_holding(fund)`

`fund`:
- `'BMFF'`
- `'87'`

Xem ở fund_listing()

Cách gọi hàm sử dụng:

```python
f=fund(fund='BMFF')
df = f.industries_holding()
```

hoặc gọi nhanh:
```python
df = fund.get_industries_holding(fund='BMFF')
```

---

# **macro_economic**: Chỉ số kinh tế vĩ mô Việt Nam
---

`general(indicator, time, start, end)`

`time`:
- `'days'` : start = 2023-01-01 ; end = 2026-12-31
- `'months'` : start = 2023-01 ; end = 2026-12
- `'quarters'` : start = 2023 ; end = 2026
- `'years'` : start = 2023 ; end = 2026

`indicator`:
- `'GDP'`, `'CPI'`, ...
- hoặc ID: `43`, `52`, ...

### Danh sách chỉ số vĩ mô

| ID | Indicator                | Symbol  | Time                     |
|----|--------------------------|---------|--------------------------|
| 43 | GDP                      | GDP     | quarters , years         |
| 52 | CPI                      | CPI     | months , years           |
| 46 | Sản xuất công nghiệp     | IIP     | months , years           |
| 47 | Bán lẻ                   | RET     | months , quarters , years|
| 48 | Xuất nhập khẩu           | TRADE   | months , years           |
| 50 | FDI                      | FDI     | months , years           |
| 51 | Tín dụng                 | CREDIT  | months , years           |
| 53 | Tỷ giá                   | FX      | days , years             |
| 55 | Dân số và lao động       | LABOR   | years                    |


Cách gọi hàm sử dụng:

```python
m=macro_economic(indicator=43) hoặc m=macro_economic(indicator='GDP')
df = m.general(time='years', start='2021', end='2024')

```

Dùng symbol

```python
m=macro_economic(indicator=46) hoặc m=macro_economic(indicator='Sản xuất công nghiệp') hoặc m=macro_economic(indicator='IIP')
df = m.general(time='years', start='2021', end='2024')

```

hoặc gọi nhanh:

```python
df = macro_economic.get_general('GDP', 'years', '2021', '2024')
df = macro_economic.get_general(43, 'quarters', '2020', '2023')
df = macro_economic.get_general('CREDIT', 'quarters', '2020', '2023')
```
---

# **other** : các chỉ số khác
---
### Dữ liệu các chỉ số khác:

`exchange_other()`

Cách gọi hàm sử dụng:

```python
df = other.exchange_other()
```

---


## Giấy phép

Thư viện này được phát hành theo giấy phép MIT. Vui lòng xem tệp LICENSE để biết thêm chi tiết.