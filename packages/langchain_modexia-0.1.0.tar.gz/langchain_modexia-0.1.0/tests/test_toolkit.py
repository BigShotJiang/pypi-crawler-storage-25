import os
from langchain_modexia import ModexiaToolkit

def test_toolkit_initialization():
    """Ensure the toolkit initializes properly and injects all required tools."""
    toolkit = ModexiaToolkit.from_api_key(api_key="mx_test_00000000000000000000000000000000")
    tools = toolkit.get_tools()
    
    # We should have 8 core tools
    assert len(tools) == 8
    
    # Check that a specific tool is accessible
    tool_names = [t.name for t in tools]
    assert "modexia_get_balance" in tool_names
    assert "modexia_transfer" in tool_names
    assert "modexia_cross_chain_transfer" in tool_names

def test_toolkit_async_initialization():
    """Ensure the toolkit initializes with an async client if requested."""
    toolkit = ModexiaToolkit.from_api_key(api_key="mx_test_00000000000000000000000000000000", async_mode=True)
    tools = toolkit.get_tools()
    
    # The first tool should have its async_client populated, and not the sync client
    balance_tool = tools[0]
    assert balance_tool.async_client is not None
    assert balance_tool.client is None
