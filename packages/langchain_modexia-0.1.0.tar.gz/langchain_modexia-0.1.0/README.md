<div align="center">
  <h1>🔗 LangChain x Modexia AgentPay</h1>
  <p><b>The official, enterprise-grade LangChain integration for Modexia's autonomous crypto infrastructure.</b></p>

  [![PyPI version](https://badge.fury.io/py/langchain-modexia.svg)](https://badge.fury.io/py/langchain-modexia)
  [![Python versions](https://img.shields.io/pypi/pyversions/langchain-modexia.svg)](https://pypi.org/project/langchain-modexia/)
  [![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
</div>

<br />

Welcome to **`langchain-modexia`**, the premium provider package for AI Developers building intelligent, financially autonomous agents in Python.

This package provides native LangChain tools allowing your agents to instantly hold USDC, execute cross-chain transfers, open zero-gas micro-payment channels, and automatically negotiate HTTP paywalls without needing to handle private keys directly in the LLM context.

---

## ⚡ Installation

Install the package directly via pip. This will also automatically install the core cryptographic engine (`modexiaagentpay`) under the hood.

```bash
pip install langchain-modexia
```

## 🛠️ Quick Start (LangGraph / Agents)

For the absolute smoothest developer experience, we provide the `ModexiaToolkit`. This automatically injects the entire suite of 8+ crypto capabilities seamlessly into standard LangGraph or `AgentExecutor` workflows.

### 1. Synchronous Agents (Standard)

```python
import os
from langchain_modexia import ModexiaToolkit
from langchain_anthropic import ChatAnthropic
from langgraph.prebuilt import create_react_agent

# Use the API key generated from https://modexia.software
os.environ["MODEXIA_API_KEY"] = "mx_test_your_key_here_..."

# Initialize the toolkit securely
toolkit = ModexiaToolkit.from_api_key(os.environ["MODEXIA_API_KEY"])
tools = toolkit.get_tools()

# Attach tools to your favorite LLM
llm = ChatAnthropic(model="claude-3-5-sonnet-20240620")
agent_executor = create_react_agent(llm, tools)

# The Agent is ready to execute Modexia payments!
response = agent_executor.invoke({
    "messages": [("user", "Check my wallet balance and send 5 USDC to 0x123abc...")]
})
print(response["messages"][-1].content)
```

### 2. High-Concurrency Asynchronous Swarms (Async)

If you are running multi-agent swarms (e.g. `ainvoke`), Modexia flawlessly supports fully non-blocking I/O. Just pass `async_mode=True` when creating the toolkit!

```python
import asyncio

async def main():
    # Setting async_mode=True automatically provisions the AsyncModexiaClient
    # and routes LangChain 'ainvoke' to non-blocking HTTPx calls.
    toolkit = ModexiaToolkit.from_api_key(os.environ["MODEXIA_API_KEY"], async_mode=True)
    tools = toolkit.get_tools()
    
    agent_executor = create_react_agent(llm, tools)
    
    res = await agent_executor.ainvoke({
       "messages": [("user", "Transfer 1.5 USDC to Alice on Arbitrum using CCTP")]
    })

asyncio.run(main())
```

---

## 🧰 Native Tools Injected

The `ModexiaToolkit` automatically handles schema validation for the LLM using strict `Pydantic` models. The following tools are injected:

*   **`modexia_get_balance`**: Checks the Agent's current usable USDC balance.
*   **`modexia_transfer`**: Sends a standard on-chain Modexia transaction to any EVM compatible address.
*   **`modexia_cross_chain_transfer`**: Routes and burns USDC natively across any blockchain using Squid Router CCTP abstraction.
*   **`modexia_get_history`**: Retrieves recent financial history for LLM context injection.
*   **`modexia_smart_fetch`**: Allows the agent to hit an external URL and automatically pay HTTP `402 Payment Required` L402 invoices to acquire premium data!
*   **`modexia_open_channel`**: Opens an ongoing high-frequency payment vault.
*   **`modexia_consume_channel`**: Executes an instant, gas-free cryptographically signed micro-payment inside an open channel (perfect for sub-cent API usage).
*   **`modexia_settle_channel`**: Closes the vault and distributes funds.

---

## 🌐 JavaScript & Non-Python Environments

**Are you building your LangChain App in TypeScript/Node.js, or using Claude Desktop?**

Because Python agents get a dedicated native package (`langchain-modexia`), we recommend non-Python systems use our **[Model Context Protocol (MCP)](https://modelcontextprotocol.io/)** server instead!

Simply install `modexia-mcp` and connect to it using `@langchain/mcp-adapters` to unlock identical functionality in JavaScript with zero custom code!

---

## 🤝 Contributing
Found a bug or want to add a feature? Open a Pull Request! This package acts as a thin LangChain abstraction over the core [Modexia AgentPay Python SDK](https://github.com/Modaniel/SDKs/tree/develop/packages/SDKs/pythonSdk).
