from typing import Optional, List, Type, Dict, Any
from pydantic import BaseModel, Field
from langchain_core.tools import BaseTool
from modexia import ModexiaClient, AsyncModexiaClient

class RetrieveBalanceInput(BaseModel):
    pass

class RetrieveBalanceTool(BaseTool):
    name: str = "modexia_get_balance"
    description: str = "Retrieves the current available USDC balance of the agent's Modexia wallet."
    args_schema: Type[BaseModel] = RetrieveBalanceInput
    client: Optional[ModexiaClient] = Field(exclude=True, default=None)
    async_client: Optional[AsyncModexiaClient] = Field(exclude=True, default=None)

    def _run(self) -> str:
        if not self.client: raise ValueError("Sync client not initialized")
        return self.client.get_balance()
        
    async def _arun(self) -> str:
        if not self.async_client: raise ValueError("Async client not initialized")
        return await self.async_client.get_balance()

class TransferInput(BaseModel):
    recipient: str = Field(description="The blockchain address to receive funds. Must start with 0x. Example: '0x123...abc'")
    amount: float = Field(description="The amount of USDC to send. Example: 5.50")

class TransferTool(BaseTool):
    name: str = "modexia_transfer"
    description: str = "Sends USDC funds to a specified EVM-compatible address. Returns a receipt with the transaction ID."
    args_schema: Type[BaseModel] = TransferInput
    client: Optional[ModexiaClient] = Field(exclude=True, default=None)
    async_client: Optional[AsyncModexiaClient] = Field(exclude=True, default=None)

    def _run(self, recipient: str, amount: float) -> str:
        if not self.client: raise ValueError("Sync client not initialized")
        receipt = self.client.transfer(recipient=recipient, amount=amount, wait=True)
        if receipt.success:
            return f"Success! Transferred {amount} USDC to {recipient}. TxID: {receipt.txId}"
        return f"Transfer failed. Please check the logs."
        
    async def _arun(self, recipient: str, amount: float) -> str:
        if not self.async_client: raise ValueError("Async client not initialized")
        receipt = await self.async_client.transfer(recipient=recipient, amount=amount, wait=True)
        if receipt.success:
            return f"Success! Transferred {amount} USDC to {recipient}. TxID: {receipt.txId}"
        return f"Transfer failed. Please check the logs."

class CrossChainTransferInput(BaseModel):
    to_chain: str = Field(description="Destination chain ID. Examples: '1' for Ethereum, '42161' for Arbitrum, 'akashnet-2' for Akash.")
    to_token: str = Field(description="The address of the destination token (e.g., USDC) on the target chain.")
    recipient: str = Field(description="Destination wallet address starting with 0x on the target chain.")
    amount: float = Field(description="Amount of USDC to transfer across chains. Example: 10.0")

class CrossChainTransferTool(BaseTool):
    name: str = "modexia_cross_chain_transfer"
    description: str = "Sends USDC natively to another blockchain using CCTP. Modexia handles burning and routing abstraction automatically."
    args_schema: Type[BaseModel] = CrossChainTransferInput
    client: Optional[ModexiaClient] = Field(exclude=True, default=None)
    async_client: Optional[AsyncModexiaClient] = Field(exclude=True, default=None)

    def _run(self, to_chain: str, to_token: str, recipient: str, amount: float) -> str:
        if not self.client: raise ValueError("Sync client not initialized")
        receipt = self.client.cross_chain_transfer(to_chain, to_token, recipient, amount)
        if receipt.success:
            return f"Initiated Cross Chain Transfer. TxID: {receipt.txId} Status: {receipt.status}"
        return f"Transfer failed: {receipt.errorReason}"
        
    async def _arun(self, to_chain: str, to_token: str, recipient: str, amount: float) -> str:
        if not self.async_client: raise ValueError("Async client not initialized")
        receipt = await self.async_client.cross_chain_transfer(to_chain, to_token, recipient, amount)
        if receipt.success:
            return f"Initiated Cross Chain Transfer. TxID: {receipt.txId} Status: {receipt.status}"
        return f"Transfer failed: {receipt.errorReason}"

class GetHistoryInput(BaseModel):
    limit: int = Field(default=5, description="Number of historical transactions to retrieve. Example: 5")

class GetHistoryTool(BaseTool):
    name: str = "modexia_get_history"
    description: str = "Retrieves the agent's recent transaction history. Call this to check previous payments or memory context."
    args_schema: Type[BaseModel] = GetHistoryInput
    client: Optional[ModexiaClient] = Field(exclude=True, default=None)
    async_client: Optional[AsyncModexiaClient] = Field(exclude=True, default=None)

    def _run(self, limit: int = 5) -> str:
        if not self.client: raise ValueError("Sync client not initialized")
        history = self.client.get_history(limit=limit)
        return f"History: {[item.__dict__ for item in history.transactions]}"
        
    async def _arun(self, limit: int = 5) -> str:
        if not self.async_client: raise ValueError("Async client not initialized")
        history = await self.async_client.get_history(limit=limit)
        return f"History: {[item.__dict__ for item in history.transactions]}"

# VAULT CHANNELS

class OpenChannelInput(BaseModel):
    provider: str = Field(description="The blockchain address serving as the channel payee/provider. Example: '0x123...'")
    deposit: float = Field(description="Total USDC to lock into the channel for future micro-payments. Example: 10.0")
    duration_hours: float = Field(default=24.0, description="Lifetime of the channel in hours. Example: 24.0")

class OpenChannelTool(BaseTool):
    name: str = "modexia_open_channel"
    description: str = "Opens a high-frequency payment vault with a provider. Returns a channelId used for instant zero-fee micro-payments."
    args_schema: Type[BaseModel] = OpenChannelInput
    client: Optional[ModexiaClient] = Field(exclude=True, default=None)
    async_client: Optional[AsyncModexiaClient] = Field(exclude=True, default=None)

    def _run(self, provider: str, deposit: float, duration_hours: float = 24.0) -> str:
        if not self.client: raise ValueError("Sync client not initialized")
        res = self.client.open_channel(provider, deposit, duration_hours)
        return f"Opened Channel: {res.get('channelId')} locked {deposit} USDC."
        
    async def _arun(self, provider: str, deposit: float, duration_hours: float = 24.0) -> str:
        if not self.async_client: raise ValueError("Async client not initialized")
        res = await self.async_client.open_channel(provider, deposit, duration_hours)
        return f"Opened Channel: {res.get('channelId')} locked {deposit} USDC."

class ConsumeChannelInput(BaseModel):
    channel_id: str = Field(description="The active channel ID returned from modexia_open_channel.")
    amount: float = Field(description="The micro-payment amount to consume right now. Example: 0.05")

class ConsumeChannelTool(BaseTool):
    name: str = "modexia_consume_channel"
    description: str = "Executes an instant, gas-free cryptographically signed micro-payment inside an open vault channel."
    args_schema: Type[BaseModel] = ConsumeChannelInput
    client: Optional[ModexiaClient] = Field(exclude=True, default=None)
    async_client: Optional[AsyncModexiaClient] = Field(exclude=True, default=None)

    def _run(self, channel_id: str, amount: float) -> str:
        if not self.client: raise ValueError("Sync client not initialized")
        res = self.client.consume_channel(channel_id, amount)
        if res.success:
            return f"Micro-payment executed. Remaining channel balance: {res.remaining}"
        return "Micro-payment failed."
        
    async def _arun(self, channel_id: str, amount: float) -> str:
        if not self.async_client: raise ValueError("Async client not initialized")
        res = await self.async_client.consume_channel(channel_id, amount)
        if res.success:
            return f"Micro-payment executed. Remaining channel balance: {res.remaining}"
        return "Micro-payment failed."

class SettleChannelInput(BaseModel):
    channel_id: str = Field(description="The active channel ID to securely close and settle.")

class SettleChannelTool(BaseTool):
    name: str = "modexia_settle_channel"
    description: str = "Closes a vault channel, pays the provider their cut, and withdraws/refunds the remaining unused deposit back to the agent."
    args_schema: Type[BaseModel] = SettleChannelInput
    client: Optional[ModexiaClient] = Field(exclude=True, default=None)
    async_client: Optional[AsyncModexiaClient] = Field(exclude=True, default=None)

    def _run(self, channel_id: str) -> str:
        if not self.client: raise ValueError("Sync client not initialized")
        res = self.client.settle_channel(channel_id)
        return f"Channel settled. TxId: {res.get('settleTxId')}"
        
    async def _arun(self, channel_id: str) -> str:
        if not self.async_client: raise ValueError("Async client not initialized")
        res = await self.async_client.settle_channel(channel_id)
        return f"Channel settled. TxId: {res.get('settleTxId')}"

# SMART FETCH
class SmartFetchInput(BaseModel):
    method: str = Field(default="GET", description="HTTP Method (GET, POST). Example: 'GET'")
    url: str = Field(description="The full URL destination endpoint to fetch/crawl. Example: 'https://api.example.com/data'")

class SmartFetchTool(BaseTool):
    name: str = "modexia_smart_fetch"
    description: str = "Fetches an external web endpoint and automatically negotiates and pays Modexia HTTP 402 Paywalls if premium data is requested."
    args_schema: Type[BaseModel] = SmartFetchInput
    client: Optional[ModexiaClient] = Field(exclude=True, default=None)
    async_client: Optional[AsyncModexiaClient] = Field(exclude=True, default=None)

    def _run(self, method: str, url: str) -> str:
        if not self.client: raise ValueError("Sync client not initialized")
        res = self.client.smart_fetch(method, url)
        return f"Status: {res.status_code}\nResponse: {res.text[:1000]}"
        
    async def _arun(self, method: str, url: str) -> str:
        if not self.async_client: raise ValueError("Async client not initialized")
        res = await self.async_client.smart_fetch(method, url)
        return f"Status: {res.status_code}\nResponse: {res.text[:1000]}"
