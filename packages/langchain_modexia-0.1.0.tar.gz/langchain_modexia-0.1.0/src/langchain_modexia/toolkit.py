from typing import List, Optional
from pydantic import Field
from langchain_core.tools import BaseTool
from langchain_core.tools.base import BaseToolkit
from modexia import ModexiaClient, AsyncModexiaClient

from .tools import (
    RetrieveBalanceTool, 
    TransferTool, 
    GetHistoryTool,
    CrossChainTransferTool,
    OpenChannelTool,
    ConsumeChannelTool,
    SettleChannelTool,
    SmartFetchTool
)

class ModexiaToolkit(BaseToolkit):
    """Toolkit for interacting with the Modexia AgentPay API.
    
    This toolkit provides native LangChain tools allowing agents to securely 
    interact with digital payments without handling complex cryptography.
    """

    client: Optional[ModexiaClient] = Field(default=None, description="The sync Modexia client.")
    async_client: Optional[AsyncModexiaClient] = Field(default=None, description="The async Modexia client.")

    class Config:
        arbitrary_types_allowed = True

    def get_tools(self) -> List[BaseTool]:
        """Get the tools in the toolkit."""
        return [
            RetrieveBalanceTool(client=self.client, async_client=self.async_client),
            TransferTool(client=self.client, async_client=self.async_client),
            GetHistoryTool(client=self.client, async_client=self.async_client),
            CrossChainTransferTool(client=self.client, async_client=self.async_client),
            OpenChannelTool(client=self.client, async_client=self.async_client),
            ConsumeChannelTool(client=self.client, async_client=self.async_client),
            SettleChannelTool(client=self.client, async_client=self.async_client),
            SmartFetchTool(client=self.client, async_client=self.async_client),
        ]

    @classmethod
    def from_api_key(cls, api_key: str, async_mode: bool = False, **kwargs) -> "ModexiaToolkit":
        """Create a Modexia toolkit securely from an API key.
        
        Args:
            api_key: The Modexia AgentPay API key.
            async_mode: If True, initializes an AsyncModexiaClient for `_arun` support.
            **kwargs: Extra arguments passed to the client (like base_url or timeout).
        """
        if async_mode:
            client = AsyncModexiaClient(api_key=api_key, **kwargs)
            return cls(async_client=client)
        else:
            client = ModexiaClient(api_key=api_key, **kwargs)
            return cls(client=client)
