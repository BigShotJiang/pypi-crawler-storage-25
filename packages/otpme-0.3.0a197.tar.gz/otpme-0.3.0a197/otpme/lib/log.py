# -*- coding: utf-8 -*-
# Copyright (C) 2014 the2nd <the2nd@otpme.org>
import os
import sys
import logging
# We need this import to get access to logging.handlers.
import logging.config
import threading
from functools import wraps

try:
    if os.environ['OTPME_DEBUG_MODULE_LOADING'] == "True":
        msg = _("Loading module: {}")
        msg = msg.format(__name__)
        print(msg)
except Exception:
    pass

from otpme.lib.syslog import get_log_handler

fd = None
LOCK_TYPE = "log"
log_banner = None

# Per-process lock used to serialize concurrent log writes from multiple
# threads in the same process. Cross-process coordination on a shared log
# file is handled by the OS (O_APPEND gives atomic writes up to PIPE_BUF),
# which is good enough for line-based log output and much cheaper than the
# flock-based AtomicFileLock the previous implementation used.
_log_lock = threading.Lock()

# Prevent "Broken Pipe" messages when piping daemon output e.g. to tee(1)
logging.raiseExceptions = False

# List with valid loglevels
valid_log_levels = [ "CRITICAL", "ERROR", "WARNING", "INFO", "DEBUG" ]

def atfork():
    """ Blank any FD from parent process. """
    global fd
    fd = None

# We need this to add variables to logging format.
class ContextFilter(logging.Filter):
    """ Add log banner and filter log messages. """
    def filter(self, record):
        from otpme.lib import config
        global log_banner
        valid_log = True
        record.log_banner = log_banner
        if config.log_filter:
            valid_log = False
            for x in config.log_filter:
                x_check = f"{config.my_name.lower()}-{x}"
                if log_banner and log_banner.startswith(x_check):
                    valid_log = True
                    break
        return valid_log

def ensure_logfile(logfile):
    """ Make sure we have a logfile we can write to. """
    from otpme.lib import config
    from otpme.lib import filetools
    # Check if path to logfile exists and is writable
    logfile_parent_dir = os.path.dirname(logfile)
    if not os.path.exists(logfile):
        if not os.path.exists(logfile_parent_dir):
            msg = _("No such file or directory: {logfile_parent_dir}")
            msg = msg.format(logfile_parent_dir=logfile_parent_dir)
            raise Exception(msg)
        if not os.access(logfile_parent_dir, os.W_OK):
            msg = _("Permission denied: {logfile_parent_dir}")
            msg = msg.format(logfile_parent_dir=logfile_parent_dir)
            raise Exception(msg)
        # Make sure logfile exists
        filetools.create_file(path=logfile,
                                content="",
                                user=config.user,
                                group=config.group,
                                mode=0o660)
    if not os.access(logfile, os.W_OK):
        msg = _("Permission denied: {logfile}")
        msg = msg.format(logfile=logfile)
        raise Exception(msg)

def get_logger(log_name, level, syslog=False, syslog_address="/dev/log",
    syslog_ssl=False, syslog_ca_cert=None, syslog_cert=None, syslog_key=None,
    syslog_relp=False, logger=None, pid=None, banner=None, logfile=None,
    facility="LOCAL7", systemd=False, timestamps=None, color_logs=False,
    stderr_log=False):
    """ Get new logger instance or re-configure a given one """
    global log_banner
    unknown_loglevel = None

    # Make log name lowercase.
    log_name = log_name.lower()

    # Handle colored logs.
    log_formatter = logging.Formatter
    if color_logs:
        from colorlog import ColoredFormatter
        log_formatter = ColoredFormatter

    # Catch unknown loglevels
    if level not in valid_log_levels:
        unknown_loglevel = level
        level = "INFO"

    # Get PID if needed.
    if pid is True:
        pid = os.getpid()

    # Use given banner or set one.
    if banner is True:
        log_banner = log_name
    elif isinstance(banner, str):
        log_banner = banner
    elif logger:
        log_banner = logger.banner
    else:
        log_banner = None

    if log_banner:
        # Add PID to banner if given.
        if pid and not syslog:
            log_banner = f"{log_banner}[{pid}]"

        # Add colon to banner.
        log_banner = f"{log_banner}:"

        # Logformat without date.
        LOG_FORMAT = '%(log_banner)s %(levelname)s: %(message)s'
        # Logformat with date.
        LOG_FORMAT_DATE = '%(asctime)s %(log_banner)s %(levelname)s: %(message)s'
    else:
        # Logformat without date.
        LOG_FORMAT = '%(levelname)s: %(message)s'
        # Logformat with date.
        LOG_FORMAT_DATE = '%(asctime)s %(levelname)s: %(message)s'

    # Add colors to log.
    if color_logs:
        LOG_FORMAT = '%(log_color)s' + LOG_FORMAT + '%(reset)s'
        LOG_FORMAT_DATE = '%(log_color)s' + LOG_FORMAT_DATE + '%(reset)s'

    # Add log formatters.
    log_format_date = log_formatter(LOG_FORMAT_DATE, datefmt='%Y-%m-%d %H:%M:%S')
    log_format_without_date = log_formatter(LOG_FORMAT)

    if timestamps is True:
        log_format = log_format_date
    elif timestamps is False:
        log_format = log_format_without_date
    else:
        log_format = None

    # Create new logger if there where no logger instance given to us.
    if not logger:
        logger = logging.getLogger(log_name)
    elif isinstance(logger, OTPmeLogger):
        logger = logger.logger

    if logger.hasHandlers():
        logger.handlers.clear()

    # Add filter to add log_banner to format string of logging.
    logger.addFilter(ContextFilter())

    # Set loglevel.
    logger.setLevel(level)

    # Check if we should log to syslog.
    if syslog:
        # Default log format should be with date.
        if not log_format:
            log_format = log_format_date
        # Create syslog handler:
        syslog_handler = get_log_handler(address=syslog_address,
                                        use_ssl=syslog_ssl,
                                        ca_cert_file=syslog_ca_cert,
                                        client_cert_file=syslog_cert,
                                        client_key_file=syslog_key,
                                        facility=facility,
                                        relp=syslog_relp)
        # Set log format for handler
        syslog_handler.setFormatter(log_format)
        # If file logging is not enabled print to stdout.
        logger.addHandler(syslog_handler)
    # Check if we should log to file.
    elif logfile:
        # Make sure logfile exists and has proper permissions.
        ensure_logfile(logfile)
        # Default log format should be with date.
        if not log_format:
            log_format = log_format_date
        # Create handler for logfile.
        file_handler = logging.handlers.WatchedFileHandler(logfile,)
        # Set log format for handler.
        file_handler.setFormatter(log_format)
        # Enable logging to logfile.
        logger.addHandler(file_handler)

    elif systemd:
        from systemd import journal
        # Get journald handler.
        journald_handler = journal.JournaldLogHandler()

        # Set log journald format for handler:
        log_format = log_formatter('%(levelname)s: %(message)s')
        journald_handler.setFormatter(log_format)

        # Add journald handler.
        logger.addHandler(journald_handler)
    else:
        # Default log format should be without date.
        if not log_format:
            log_format = log_format_without_date
        # Create handler for stdout.
        if stderr_log:
            stdout_handler = logging.StreamHandler(stream=sys.stderr)
        else:
            stdout_handler = logging.StreamHandler(stream=sys.stdout)
        # Set log format for handler.
        stdout_handler.setFormatter(log_format)
        # If file logging is not enabled print to stdout.
        logger.addHandler(stdout_handler)

    if unknown_loglevel:
        msg = _("Changed unknown loglevel '{}' to loglevel 'INFO'.")
        msg = msg.format(unknown_loglevel)
        logger.error(msg)

    otpme_logger = OTPmeLogger(logger, logfile=logfile, banner=log_banner)

    return otpme_logger

def setup_logger(*args, **kwargs):
    """ Configure logger based on site settings. """
    from otpme.lib import config
    relp = False
    use_ssl = False
    ca_cert_file = None
    client_cert_file = None
    client_key_file = None
    address = None
    timestamps = True
    logger_syslog = False
    if not config.debug_enabled and not config.realm_init:
        if config.syslog_enabled and config.syslog_server:
            logger_syslog = True
            timestamps = False
            address = config.syslog_server
            relp = False
            if config.syslog_protocol == "relp":
                relp = True
            use_ssl = config.syslog_use_tls
            if use_ssl:
                ca_cert_file = config.syslog_ca_cert
                if not ca_cert_file:
                    logger_syslog = False
                    msg = _("Cannot start syslog. Site misses CA cert.")
                    config.logger.warning(msg)
                if config.syslog_use_client_cert:
                    client_cert_file = config.syslog_cert
                    client_key_file = config.syslog_key
                    if not client_cert_file:
                        logger_syslog = False
                        msg = _("Cannot start syslog. Node misses client cert.")
                        config.logger.warning(msg)
                    if not client_key_file:
                        logger_syslog = False
                        msg = _("Cannot start syslog. Node misses client key.")
                        config.logger.warning(msg)
    # Setup logger.
    logger = config.setup_logger(*args,
                                logger_syslog=logger_syslog,
                                syslog_address=address,
                                syslog_ssl=use_ssl,
                                syslog_ca_cert=ca_cert_file,
                                syslog_cert=client_cert_file,
                                syslog_key=client_key_file,
                                syslog_relp=relp,
                                timestamps=timestamps,
                                **kwargs)
    return logger

def _maybe_add_exc_info(kwargs):
    """ When config.log_exc_info is enabled, attach the active exception
    (if any) to the log record. Only kicks in inside an except: block —
    outside of one sys.exc_info() is (None, None, None) and exc_info=True
    would be a no-op. A caller that passes exc_info explicitly (True or
    False) always wins.
    """
    if 'exc_info' in kwargs:
        return
    from otpme.lib import config
    if not config.log_exc_info:
        return
    if sys.exc_info()[0] is None:
        return
    kwargs['exc_info'] = True

def log_lock():
    """ Decorator to serialize logger calls across threads in this process.

    Python's logging handlers are already thread-safe on their own; this
    decorator keeps a single additional in-process lock so the historic
    contract (only one OTPmeLogger call at a time) is preserved without
    paying the flock+create+unlink cost per log statement that the previous
    AtomicFileLock-based implementation did.
    """
    def wrapper(f):
        @wraps(f)
        def wrapped(self, *f_args, **f_kwargs):
            from otpme.lib import config
            if config.proc_mode == "threading":
                with _log_lock:
                    return f(self, *f_args, **f_kwargs)
            else:
                return f(self, *f_args, **f_kwargs)
        return wrapped
    return wrapper

class OTPmeLogger(object):
    """ Wrapper class to handle logfile locking. """
    def __init__(self, logger, logfile=None, banner=None):
        self.logger = logger
        self.logfile = logfile
        self.banner = banner

    def __getattr__(self, name):
        """ Map to original logger attributes. """
        return getattr(self.logger, name)

    def atfork(self):
        for h in self.handlers:
             self.removeHandler(h)

    @log_lock()
    def debug(self, *args, **kwargs):
        return self.logger.debug(*args, **kwargs)

    @log_lock()
    def info(self, *args, **kwargs):
        return self.logger.info(*args, **kwargs)

    @log_lock()
    def warning(self, *args, **kwargs):
        _maybe_add_exc_info(kwargs)
        return self.logger.warning(*args, **kwargs)

    @log_lock()
    def error(self, *args, **kwargs):
        _maybe_add_exc_info(kwargs)
        return self.logger.error(*args, **kwargs)

    @log_lock()
    def critical(self, *args, **kwargs):
        _maybe_add_exc_info(kwargs)
        return self.logger.critical(*args, **kwargs)

    @log_lock()
    def warn(self, *args, **kwargs):
        _maybe_add_exc_info(kwargs)
        return self.logger.warn(*args, **kwargs)

    @log_lock()
    def fatal(self, *args, **kwargs):
        _maybe_add_exc_info(kwargs)
        return self.logger.fatal(*args, **kwargs)
