# -*- coding: utf-8 -*-
# Copyright (C) 2014 the2nd <the2nd@otpme.org>
import os
import json
from getpass import getpass
from fido2.ctap2 import Ctap2
from fido2.ctap2 import ClientPin
from fido2.hid import CtapHidDevice
from fido2.client import Fido2Client
from fido2.client import UserInteraction
from fido2.webauthn import AttestedCredentialData
from fido2.client import DefaultClientDataCollector
from fido2.ctap2.extensions import HmacSecretExtension

try:
    from fido2.pcsc import CtapPcscDevice
except ImportError:
    CtapPcscDevice = None

try:
    if os.environ['OTPME_DEBUG_MODULE_LOADING'] == "True":
        msg = _("Loading module: {module_name}")
        msg = msg.format(module_name=__name__)
        print(msg)
except Exception:
    pass

from otpme.lib import cli
from otpme.lib import stuff
from otpme.lib import config
from otpme.lib.help import command_map
#from otpme.lib.encoding.base import encode
from otpme.lib.encoding.base import decode

from otpme.lib. exceptions import *

logger = config.logger

REGISTER_BEFORE = []
REGISTER_AFTER = []

def register():
    config.register_smartcard_type("fido2", Fido2ClientHandler, Fido2ServerHandler)

class CliInteraction(UserInteraction):
    def __init__(self, pin=None):
        self._pin = pin

    def prompt_up(self):
        print("Touch your authenticator device now...")

    def request_pin(self, permissions, rd_id):
        if not self._pin:
            self._pin = getpass("Enter smartcard password: ")
        return self._pin

    def request_uv(self, permissions, rd_id):
        print("User Verification required.")
        return True

class Fido2ClientHandler(object):
    def __init__(self, sc_type, token_rel_path, token_options=None,
        message_method=print, error_message_method=print):
        # The token type used on server side.
        self.token_type = "fido2"
        self.smartcard_type = sc_type
        self.token_rel_path = token_rel_path
        self.token_options = token_options
        self.uv = "discouraged"
        self.fido2_token = None
        self.enc_challenge = None
        self._hmac_output = None
        self.message_method = message_method
        self.error_message_method = error_message_method
        # FIXME: pam message methods from pam.py does not work with sddm
        #       and adds some strange delay.
        self.message_method = print
        self.error_message_method = print
        self.logger = config.logger

    def parse_syntax(self, command_handler):
        # Get command syntax.
        try:
            command_syntax = command_map['token']['fido2']['deploy']['cmd']
        except Exception:
            msg = _("Unknown token type: {type}")
            msg = msg.format(type=self.smartcard_type)
            raise OTPmeException(msg) from None

        # Parse command line.
        try:
            object_cmd, \
            object_required, \
            self.object_identifier, \
            self.local_command_args = cli.get_opts(command_syntax=command_syntax,
                                            command_line=command_handler.command_line)
        except Exception as e:
            if str(e) == "help":
                exception = command_handler.get_help()
                raise ShowHelp(exception) from e
            elif str(e) != "":
                msg = str(e)
                exception = command_handler.get_help(message=msg)
                raise ShowHelp(exception) from e

    def get_pre_deploy_args(self, command_handler, **kwargs):
        self.parse_syntax(command_handler)
        try:
            self.uv = self.local_command_args['uv']
        except KeyError:
            self.uv = None
        if self.uv is not None and self.uv not in ['discouraged', 'preferred', 'required']:
            msg = _("Invalid uv: {uv}")
            msg = msg.format(uv=self.uv)
            raise OTPmeException(msg)
        self.detect_fido2_sc()
        if self.uv is None:
            self.uv = self.fido2_token.uv
        pre_deploy_args = {
                            'uv'                : self.uv,
                            'hmac_supported'    : self.fido2_token.hmac_secret_supported,
                        }
        return pre_deploy_args

    def detect_fido2_sc(self):
        if self.fido2_token:
            return
        log_msg = _("Trying to detect connected fido2 token...", log=True)[1]
        self.logger.debug(log_msg)
        try:
            self.fido2_token = Fido2(uv=self.uv)
        except Exception as e:
            msg = str(e)
            raise OTPmeException(msg) from e

    def handle_deploy(self, command_handler, no_token_write=False, pre_deploy_result=None):
        # Get command syntax.
        try:
            command_syntax = command_map['token']['fido2']['deploy']['cmd']
        except Exception:
            msg = _("Unknown token type: {type}")
            msg = msg.format(type=self.smartcard_type)
            raise OTPmeException(msg) from None

        # Parse command line.
        local_command_args = {}
        try:
            object_cmd, \
            object_required, \
            object_identifier, \
            local_command_args = cli.get_opts(command_syntax=command_syntax,
                                            command_line=command_handler.command_line,
                                            command_args=local_command_args)
        except Exception as e:
            if str(e) == "help":
                exception = command_handler.get_help()
                raise ShowHelp(exception) from e
            elif str(e) != "":
                msg = str(e)
                exception = command_handler.get_help(message=msg)
                raise ShowHelp(exception) from e

        # Try to find a locally connected U2F token.
        self.detect_fido2_sc()
        # Set pin if supported.
        if self.fido2_token.pin is False:
            self.fido2_token.setup_pin()

        create_options_json = pre_deploy_result['create_options']
        create_options = json.loads(create_options_json)
        try:
            registration_data = self.fido2_token.register(create_options)
        except Exception as e:
            msg = _("Failed to register fido2 token: {error}")
            msg = msg.format(error=e)
            raise OTPmeException(msg) from e

        # Send registration data to server.
        deploy_args = {}
        deploy_args['registration_data'] = registration_data
        return deploy_args

    def handle_preauth(self, smartcard, password=None, **kwargs):
        rp = self.token_options['rp']
        request_options = self.token_options['request_options']
        is_2f_token = self.token_options['is_2f_token']
        pass_required = self.token_options['pass_required']
        self.enc_challenge = stuff.gen_secret(len=16)
        try:
            auth_response = smartcard.authenticate(rp=rp,
                                            pin=password,
                                            hmac_salt=self.enc_challenge,
                                            request_options=request_options)
        except Exception as e:
            msg = _("Failed to authenticate with fido2 token: {error}")
            msg = msg.format(error=e)
            raise AuthFailed(msg) from e
        self._hmac_output = smartcard._hmac_output
        auth_response_json = json.dumps(dict(auth_response))
        smartcard_data = {
                            'token_rel_path'    : self.token_rel_path,
                            'smartcard_type'    : self.smartcard_type,
                            'auth_response'     : auth_response_json,
                            'pass_required'     : pass_required,
                            'is_2f_token'       : is_2f_token,
                        }
        return smartcard_data

    def handle_authentication(self, smartcard, smartcard_data, password=None, **kwargs):
        rp = smartcard_data['rp']
        request_options = smartcard_data['request_options']
        try:
            auth_response = smartcard.authenticate(rp=rp,
                                            pin=password,
                                            request_options=request_options)
        except Exception as e:
            msg = _("Failed to authenticate with fido2 token: {error}")
            msg = msg.format(error=e)
            raise AuthFailed(msg) from e
        auth_response_json = json.dumps(dict(auth_response))
        return auth_response_json

    def handle_offline_token_challenge(self, **kwargs):
        return self._hmac_output

    def handle_offline_challenge(self, **kwargs):
        return self._hmac_output

    def get_smartcard_data(self, smartcard, token, password, enc_challenge, **kwargs):
        credential_data = decode(token.credential_data, "hex")
        credentials = [AttestedCredentialData(credential_data)]
        fido2_server = token.get_fido2_server()
        request_options, \
        auth_state = fido2_server.authenticate_begin(credentials,
                                                    user_verification=token.uv)
        request_options = json.dumps(dict(request_options))
        try:
            auth_response = smartcard.authenticate(rp=token.rp,
                                                pin=password,
                                                hmac_salt=enc_challenge,
                                                request_options=request_options)
        except Exception as e:
            msg = _("Failed to authenticate with fido2 token: {error}")
            msg = msg.format(error=e)
            raise AuthFailed(msg) from e
        self._hmac_output = smartcard._hmac_output
        auth_response_json = json.dumps(dict(auth_response))
        smartcard_data = {
                            'auth_state'    : auth_state,
                            'auth_response' : auth_response_json,
                        }
        return smartcard_data


class Fido2ServerHandler(object):
    def __init__(self):
        self.auth_state = None
        self.token_type = None

    def handle_preauth(self, token, **kwargs):
        credential_data = decode(token.credential_data, "hex")
        credentials = [AttestedCredentialData(credential_data)]
        fido2_server = token.get_fido2_server()
        request_options, \
        self.auth_state = fido2_server.authenticate_begin(credentials,
                                                    user_verification=token.uv)
        request_options = json.dumps(dict(request_options))
        self.token_type = token.token_type
        pass_required = False
        if token.uv == "required":
            pass_required = True
        token_options = {
                    'rp'                : token.rp,
                    'token_type'        : self.token_type,
                    'pass_required'     : pass_required,
                    'request_options'   : request_options,
                    }
        return token_options

    def prepare_authentication(self, smartcard_data):
        smartcard_data['auth_state'] = self.auth_state
        return smartcard_data

class Fido2(object):
    """ Class for fido2 tokens. """
    def __init__(self, autodetect=True, uv=None, debug=False):
        # Set supported auth types
        self.otpme_auth_types = [ "fido2" ]
        # Set smartcard type
        self.type = "fido2"
        # Will be set by OTPmeClient() when doing preauth_check
        self.options = {}
        self.ctap = None
        self.dev = None
        self.pin = None
        self._pin = None
        self.uv = uv
        self.hmac_secret_supported = False
        self._hmac_output = None
        if autodetect:
            self.detect()

    def detect(self, debug=False, print_devices=False):
        """ Try to find fido2 token """
        dev = None
        for x_dev in CtapHidDevice.list_devices():
            if dev is None:
                dev = x_dev
            if not print_devices:
                break
            msg = _("Detected fido2 smartcard: {device}")
            msg = msg.format(device=x_dev)
            print(msg)

        if dev is None and CtapPcscDevice:
            for dev in CtapPcscDevice.list_devices():
                if dev is None:
                    dev = x_dev
                if not print_devices:
                    break
                msg = _("Detected fido2 smartcard: {device}")
                msg = msg.format(device=x_dev)
                print(msg)

        if dev is None:
            raise ValueError("No suitable fido2 smartcard found!")

        self.dev = dev
        self.ctap = Ctap2(self.dev)
        info = self.ctap.info

        pin_supported = info.options.get("clientPin")
        if pin_supported is None:
            # Authenticator does not support PIN.
            if self.uv == "required":
                msg = _("Authenticator does not support PIN.")
                raise OTPmeException(msg)
            self.pin = None
        elif pin_supported:
            # Authenticator has a PIN set.
            self.pin = True
        else:
            # Authenticator supports PIN but none is set.
            # Set PIN now.
            self.pin = False

        # Require UV if PIN is supported.
        if self.uv is None:
            if pin_supported is not None:
                self.uv = "required"
            elif info.options.get("uv") or info.options.get("bioEnroll"):
                self.uv = "preferred"
            else:
                self.uv = "discouraged"

        # Check hmac-secret support.
        if "hmac-secret" in info.extensions:
            self.hmac_secret_supported = True

    def setup_pin(self):
        """ Set PIN on authenticator. """
        client_pin = ClientPin(self.ctap)
        while True:
            pin = getpass("Enter new smartcard password: ")
            pin_confirm = getpass("Confirm new smartcard password: ")
            if pin != pin_confirm:
                print("Passwords do not match. Please try again.")
                continue
            if len(pin) < 4:
                print("Password must be at least 4 characters.")
                continue
            break
        client_pin.set_pin(pin)
        self._pin = pin
        self.pin = True
        print("Password set successfully.")
        return True

    def get_fido2_client(self, rp, pin=None):
        rp = f"https://{rp}"
        client_data_collector = DefaultClientDataCollector(rp)
        extensions = [HmacSecretExtension(allow_hmac_secret=True)]
        client = Fido2Client(self.dev,
                            client_data_collector=client_data_collector,
                            user_interaction=CliInteraction(pin=pin),
                            extensions=extensions)
        return client

    def register(self, create_options):
        pin = None
        if self.pin:
            if self._pin:
                pin = self._pin
                self._pin = None
            else:
                pin = getpass("Enter smartcard password: ")
        rp = create_options['publicKey']['rp']['id']
        # Enable hmac-secret extension for this credential.
        if self.hmac_secret_supported:
            extensions = create_options["publicKey"].get("extensions", {})
            extensions["hmacCreateSecret"] = True
            create_options["publicKey"]["extensions"] = extensions
        client = self.get_fido2_client(rp, pin=pin)
        result = client.make_credential(create_options["publicKey"])
        result = json.dumps(dict(result))
        return result

    def authenticate(self, rp, request_options, pin=None, hmac_salt=None):
        client = self.get_fido2_client(rp, pin=pin)
        request_options = json.loads(request_options)
        # Add hmac-secret salt to request.
        if hmac_salt and self.hmac_secret_supported:
            if isinstance(hmac_salt, str):
                hmac_salt = hmac_salt.encode()
            # Pad or hash salt to 32 bytes.
            if len(hmac_salt) != 32:
                import hashlib
                hmac_salt = hashlib.sha256(hmac_salt).digest()
            extensions = request_options["publicKey"].get("extensions", {})
            extensions["hmacGetSecret"] = {"salt1": hmac_salt}
            request_options["publicKey"]["extensions"] = extensions
        results = client.get_assertion(request_options["publicKey"])
        auth_response = results.get_response(0)
        # Extract hmac-secret output.
        self._hmac_output = None
        if hmac_salt and auth_response.client_extension_results:
            hmac_result = auth_response.client_extension_results.get("hmacGetSecret")
            if hmac_result:
                self._hmac_output = hmac_result['output1']
        return auth_response
