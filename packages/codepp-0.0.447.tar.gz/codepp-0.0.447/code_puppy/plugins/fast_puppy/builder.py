"""Multi-crate Rust builder for Fast Puppy plugin.

This module provides generic auto-build functionality for all Rust crates
in the code_puppy workspace: code_puppy_core, turbo_ops, turbo_parse.
"""

from __future__ import annotations

import importlib
import importlib.util
import logging
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

from code_puppy.config_package import get_puppy_config
from code_puppy.messaging import emit_info

logger = logging.getLogger(__name__)

# Registry of all Rust crates to auto-build
CRATES = [
    {
        "name": "code_puppy_core",
        "dir": "code_puppy_core",
        "probe": "_code_puppy_core",
        "bridges": ["code_puppy._core_bridge"],
        "patch_targets": [
            {
                "module": "code_puppy.agents.base_agent",
                "flags": {"RUST_AVAILABLE": "available"},
                "rebind_from": "code_puppy._core_bridge",
                "rebind_names": [],  # base_agent uses module-attribute lookup
            },
        ],
    },
    {
        "name": "turbo_ops",
        "dir": "turbo_ops",
        "probe": "turbo_ops",
        "bridges": [],
        "patch_targets": [
            {
                "module": "code_puppy.plugins.turbo_executor.orchestrator",
                "flags": {"TURBO_OPS_AVAILABLE": "available"},
                "rebind_from": "turbo_ops",
                "rebind_names": ["list_files", "grep", "read_file"],
                "rebind_as": {
                    "list_files": "turbo_list_files",
                    "grep": "turbo_grep",
                    "read_file": "turbo_read_file",
                },
            },
        ],
    },
    {
        "name": "turbo_parse",
        "dir": "turbo_parse",
        "probe": "turbo_parse",
        "bridges": ["code_puppy.turbo_parse_bridge"],
        "patch_targets": [
            {
                "module": "code_puppy.code_context.explorer",
                "flags": {"TURBO_PARSE_AVAILABLE": "available"},
                "rebind_from": "code_puppy.turbo_parse_bridge",
                "rebind_names": [
                    "is_language_supported",
                    "extract_symbols_from_file",
                ],
            },
            {
                "module": "code_puppy.plugins.turbo_parse.register_callbacks",
                "flags": {"TURBO_PARSE_AVAILABLE": "available"},
                "rebind_from": "code_puppy.turbo_parse_bridge",
                "rebind_names": [
                    "parse_source",
                    "parse_file",
                    "parse_files_batch",
                    "extract_symbols",
                    "extract_syntax_diagnostics",
                    "get_folds",
                    "get_highlights",
                    "is_language_supported",
                    "supported_languages",
                    "health_check",
                    "stats",
                ],
                "rebind_as": {
                    "parse_source": "_parse_source",
                    "parse_file": "_parse_file",
                    "parse_files_batch": "_parse_files_batch",
                    "extract_symbols": "_extract_symbols",
                    "extract_syntax_diagnostics": "_extract_diagnostics",
                    "get_folds": "_get_folds",
                    "get_highlights": "_get_highlights",
                },
            },
        ],
    },
]


def _find_repo_root() -> Path | None:
    """Find the repo root containing Cargo.toml workspace file."""
    # Start from this file's location and traverse up
    current = Path(__file__).resolve().parent
    for _ in range(5):  # Don't search too far
        if (current / "Cargo.toml").exists():
            # Verify it's a workspace by reading it
            try:
                content = (current / "Cargo.toml").read_text()
                if "[workspace]" in content:
                    return current
            except Exception:
                pass
        parent = current.parent
        if parent == current:
            break
        current = parent
    return None


def _find_crate_dir(crate_name: str) -> Path | None:
    """Find a specific crate directory relative to repo root."""
    repo_root = _find_repo_root()
    if repo_root is None:
        return None
    crate_dir = repo_root / crate_name
    if (crate_dir / "Cargo.toml").exists():
        return crate_dir
    return None


def _is_crate_installed(probe_module: str) -> bool:
    """Check if a crate's Python module is importable using importlib.util.find_spec."""
    try:
        spec = importlib.util.find_spec(probe_module)
        return spec is not None
    except Exception:
        return False


def _is_crate_fresh(crate_dir: Path, probe_module: str) -> bool:
    """Check if installed crate is fresh (binary mtime newer than all source files).

    Returns True if installed .so/.dylib mtime is newer than every source file.
    Checks Rust sources (.rs), tree-sitter queries (.scm), and config files.
    If not installed at all, returns False.
    """
    # Find the installed extension module
    try:
        spec = importlib.util.find_spec(probe_module)
        if spec is None or spec.origin is None:
            return False
        binary_path = Path(spec.origin)
        if not binary_path.exists():
            return False
        binary_mtime = binary_path.stat().st_mtime
    except Exception:
        return False

    # Collect all source files to check
    source_files: list[Path] = []

    # Rust sources in src/
    src_dir = crate_dir / "src"
    if src_dir.exists():
        source_files.extend(src_dir.rglob("*.rs"))

    # Tree-sitter queries (for turbo_parse)
    queries_dir = crate_dir / "queries"
    if queries_dir.exists():
        source_files.extend(queries_dir.rglob("*.scm"))

    # Build config files
    for name in ("Cargo.toml", "Cargo.lock", "pyproject.toml", "build.rs"):
        config_file = crate_dir / name
        if config_file.exists():
            source_files.append(config_file)

    # Check all collected sources
    try:
        for src_file in source_files:
            if src_file.stat().st_mtime > binary_mtime:
                return False  # Source is newer than binary
        return True
    except Exception:
        return False


def _has_rust_toolchain() -> bool:
    """Check if Rust compiler is available."""
    return shutil.which("rustc") is not None


def _has_maturin() -> bool:
    """Check if maturin is available (in PATH, as uv module, or as Python module)."""
    if shutil.which("maturin"):
        return True
    if shutil.which("uv"):
        # Check if uv can run maturin
        try:
            result = subprocess.run(
                ["uv", "run", "maturin", "--version"],
                capture_output=True,
                timeout=10,
            )
            return result.returncode == 0
        except Exception:
            pass
    # Try as Python module
    try:
        result = subprocess.run(
            [sys.executable, "-m", "maturin", "--version"],
            capture_output=True,
            timeout=10,
        )
        return result.returncode == 0
    except Exception:
        return False


def _install_maturin() -> bool:
    """Try to install maturin using pip."""
    try:
        install_result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "maturin"],
            capture_output=True,
            text=True,
            timeout=60,
        )
        return install_result.returncode == 0
    except Exception as exc:
        logger.debug("Could not install maturin: %s", exc)
        return False


def _try_pip_install_crate(crate_name: str) -> bool:
    """Try to install a Rust crate from PyPI.

    This will succeed if:
    - A pre-built wheel exists for this platform, OR
    - User has Rust toolchain and maturin (builds from sdist)

    Returns True on success.
    """
    # Map crate names to PyPI package names
    pypi_names = {
        "code_puppy_core": "codepuppy-rs-core",
        "turbo_ops": "codepuppy-rs-turbo-ops",
        "turbo_parse": "codepuppy-rs-turbo-parse",
    }
    package_name = pypi_names.get(crate_name, crate_name.replace("_", "-"))

    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--quiet", package_name],
            capture_output=True,
            text=True,
            timeout=300,  # 5 min timeout for potential compilation
        )
        return result.returncode == 0
    except Exception as e:
        logger.debug("pip install %s failed: %s", package_name, e)
        return False


def _get_maturin_command() -> list[str]:
    """Get the appropriate maturin command as a list."""
    if shutil.which("maturin"):
        return ["maturin"]
    if shutil.which("uv"):
        return ["uv", "run", "maturin"]
    return [sys.executable, "-m", "maturin"]


def _emit_build_heartbeat(
    proc: subprocess.Popen, crate_name: str, stop_event: threading.Event
) -> None:
    """Emit heartbeat messages during long builds.

    Runs in a daemon thread, emits message every 20 seconds.
    """
    start_time = time.time()
    next_heartbeat = 20.0

    while not stop_event.is_set() and proc.poll() is None:
        elapsed = time.time() - start_time
        if elapsed >= next_heartbeat:
            emit_info(
                f"🐕⚡ Fast Puppy: Still building {crate_name}… ({int(elapsed)}s elapsed)"
            )
            next_heartbeat += 20.0
        time.sleep(1.0)


def _build_crate(crate_dir: Path, crate_name: str) -> tuple[bool, str]:
    """Build and install a Rust crate into the current environment.

    Returns (success, error_msg).
    Uses 600 second timeout (turbo_parse is slow).
    """
    cmd_base = _get_maturin_command()
    cmd = cmd_base + [
        "develop",
        "--release",
        "--manifest-path",
        str(crate_dir / "Cargo.toml"),
    ]

    try:
        # Use Popen for heartbeat support on long builds
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            cwd=str(crate_dir),
        )

        # Start heartbeat thread for builds >30s
        stop_event = threading.Event()
        heartbeat_thread = threading.Thread(
            target=_emit_build_heartbeat,
            args=(proc, crate_name, stop_event),
            daemon=True,
        )
        heartbeat_thread.start()

        try:
            stdout, stderr = proc.communicate(timeout=600)  # 10 min max
        finally:
            stop_event.set()
            heartbeat_thread.join(timeout=2.0)

        if proc.returncode == 0:
            return True, ""
        else:
            error_msg = (
                stderr.strip()
                if stderr
                else stdout.strip()
                if stdout
                else "Unknown error"
            )
            return False, error_msg

    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait()
        return False, "Build timed out after 600 seconds"
    except Exception as e:
        return False, str(e)


def _prewarm_workspace(repo_root: Path) -> None:
    """Pre-warm cargo workspace by building shared dependencies once.

    Runs `cargo build --release --workspace` as a non-fatal optimization.
    Individual maturin builds will handle any issues if this fails.
    """
    try:
        result = subprocess.run(
            ["cargo", "build", "--release", "--workspace"],
            capture_output=True,
            text=True,
            timeout=300,  # 5 min for prewarm
            cwd=str(repo_root),
        )
        if result.returncode == 0:
            logger.debug("Workspace prewarm completed successfully")
    except Exception as e:
        logger.debug("Workspace prewarm failed (non-fatal): %s", e)


def _reload_and_patch_crate(crate_spec: dict) -> bool:
    """Reload bridge modules and patch consumer flags/function references.

    Args:
        crate_spec: The crate specification dict from CRATES.

    Returns:
        True if the probe module is now importable after reload.
    """
    import importlib
    import importlib.util
    import sys

    # 1. Reload all bridge modules
    for bridge_name in crate_spec.get("bridges", []):
        if bridge_name in sys.modules:
            try:
                importlib.reload(sys.modules[bridge_name])
                logger.debug("Reloaded bridge module %s", bridge_name)
            except Exception as e:
                logger.warning("Failed to reload bridge %s: %s", bridge_name, e)
        else:
            try:
                importlib.import_module(bridge_name)
            except Exception as e:
                logger.warning("Failed to import bridge %s: %s", bridge_name, e)

    # 2. Verify the probe module is now importable
    probe_name = crate_spec["probe"]
    try:
        # Use find_spec first (doesn't execute code, just finds the module)
        spec = importlib.util.find_spec(probe_name)
        if spec is None:
            is_available = False
        else:
            # Module exists, try to import/reload it
            if probe_name in sys.modules:
                try:
                    importlib.reload(sys.modules[probe_name])
                except Exception:
                    pass  # reload failed but spec exists, still available
            else:
                try:
                    importlib.import_module(probe_name)
                except Exception:
                    pass  # import failed but spec exists, still available
            is_available = True
    except Exception:
        is_available = False

    # 3. Patch each consumer module
    for target in crate_spec.get("patch_targets", []):
        module_name = target["module"]
        if module_name not in sys.modules:
            continue  # consumer not yet imported, nothing to patch
        consumer = sys.modules[module_name]

        # 3a. Patch flags
        for flag_name, value_source in target.get("flags", {}).items():
            if value_source == "available":
                value = is_available
            else:
                value = value_source
            try:
                setattr(consumer, flag_name, value)
                logger.debug("Patched %s.%s = %r", module_name, flag_name, value)
            except Exception as e:
                logger.warning("Failed to patch %s.%s: %s", module_name, flag_name, e)

        # 3b. Rebind function references from the fresh module
        rebind_from = target.get("rebind_from")
        rebind_names = target.get("rebind_names", [])
        rebind_as = target.get("rebind_as", {})

        if rebind_from and rebind_names and is_available:
            try:
                fresh_module = importlib.import_module(rebind_from)
            except ImportError as e:
                logger.warning("Cannot import %s for rebinding: %s", rebind_from, e)
                continue

            for fresh_name in rebind_names:
                local_name = rebind_as.get(fresh_name, fresh_name)
                try:
                    fresh_value = getattr(fresh_module, fresh_name)
                    setattr(consumer, local_name, fresh_value)
                    logger.debug(
                        "Rebound %s.%s = %s.%s",
                        module_name,
                        local_name,
                        rebind_from,
                        fresh_name,
                    )
                except AttributeError as e:
                    logger.warning(
                        "Cannot rebind %s.%s from %s: %s",
                        module_name,
                        local_name,
                        rebind_from,
                        e,
                    )

    return is_available


def _check_disable_autobuild() -> bool:
    """Check if rust autobuild is disabled in config."""
    try:
        cfg = get_puppy_config()
        return cfg.rust_autobuild_disabled
    except Exception:
        return False


def _is_development_mode() -> bool:
    """Check if we're running in development mode (editable install)."""
    try:
        import importlib.util
        spec = importlib.util.find_spec("code_puppy")
        if spec and spec.origin:
            # If the module is in a site-packages dir, it's a regular install
            origin = Path(spec.origin)
            if "site-packages" in str(origin):
                return False
            # If we're near a Cargo.toml, it's a dev checkout
            for parent in origin.parents:
                if (parent / "Cargo.toml").exists():
                    return True
        return False
    except Exception:
        return False


def _try_auto_build_all() -> dict[str, bool]:
    """Auto-install/build all Rust crates.

    Strategy (in order):
    1. Already installed? → Done
    2. Try pip install from PyPI (uses pre-built wheel if available)
    3. In dev mode with Rust? → Build from source
    4. Nothing worked → Pure Python fallback

    Returns dict of {crate_name: success_bool}.
    """
    results: dict[str, bool] = {}

    # Check config flag
    if _check_disable_autobuild():
        logger.debug("Rust autobuild disabled via config")
        return results

    in_dev_mode = _is_development_mode()
    has_rust = _has_rust_toolchain()

    # Process each crate
    for crate_spec in CRATES:
        crate_name = crate_spec["name"]
        probe = crate_spec["probe"]

        # Step 1: Already installed?
        if _is_crate_installed(probe):
            # In dev mode, check freshness
            if in_dev_mode:
                crate_dir = _find_crate_dir(crate_spec["dir"])
                if crate_dir and not _is_crate_fresh(crate_dir, probe):
                    # Stale - will rebuild below
                    pass
                else:
                    emit_info(f"🐕⚡ Fast Puppy: ✅ {crate_name}: ready")
                    results[crate_name] = True
                    continue
            else:
                emit_info(f"🐕⚡ Fast Puppy: ✅ {crate_name}: ready")
                results[crate_name] = True
                continue

        # Step 2: Try pip install from PyPI
        emit_info(f"🐕⚡ Fast Puppy: 📦 Installing {crate_name} from PyPI...")
        if _try_pip_install_crate(crate_name):
            # Verify it actually works now
            if _is_crate_installed(probe):
                _reload_and_patch_crate(crate_spec)
                emit_info(f"🐕⚡ Fast Puppy: ✅ {crate_name}: installed from PyPI")
                results[crate_name] = True
                continue

        # Step 3: In dev mode with Rust? Build from source
        if in_dev_mode and has_rust:
            crate_dir = _find_crate_dir(crate_spec["dir"])
            if crate_dir:
                # Ensure maturin is available
                if not _has_maturin():
                    emit_info("🐕⚡ Fast Puppy: Installing maturin…")
                    if not _install_maturin():
                        emit_info(f"🐕 Fast Puppy: ❌ {crate_name}: maturin install failed")
                        results[crate_name] = False
                        continue

                emit_info(f"🐕⚡ Fast Puppy: 🔨 Building {crate_name} from source...")
                success, error_msg = _build_crate(crate_dir, crate_name)

                if success:
                    is_available = _reload_and_patch_crate(crate_spec)
                    if is_available:
                        emit_info(f"🐕⚡ Fast Puppy: ✅ {crate_name}: built from source")
                        results[crate_name] = True
                        continue
                    else:
                        emit_info(f"🐕 Fast Puppy: ⚠️ {crate_name}: built but not loadable")
                else:
                    emit_info(f"🐕 Fast Puppy: ❌ {crate_name}: build failed — {error_msg[:80]}")

        # Step 4: Nothing worked
        results[crate_name] = False

    # Summary
    success_count = sum(1 for v in results.values() if v)
    total_count = len(CRATES)

    if success_count == 0:
        if not has_rust:
            emit_info("🐕 Fast Puppy: Pure Python mode (install Rust for acceleration)")
        else:
            emit_info("🐕 Fast Puppy: Pure Python mode (Rust crates unavailable)")
    elif success_count < total_count:
        missing = [k for k, v in results.items() if not v]
        emit_info(f"🐕⚡ Fast Puppy: Partial acceleration ({success_count}/{total_count}) — missing: {', '.join(missing)}")

    return results


def _try_auto_build() -> bool:
    """Legacy function for backward compatibility - builds only code_puppy_core.

    Returns True if code_puppy_core is available (either already installed or built).
    """
    results = _try_auto_build_all()
    return results.get("code_puppy_core", False)


def get_all_crate_status() -> list[dict]:
    """Return status dict for each crate in CRATES registry.

    Each dict has: name, installed, fresh, active, crate_dir_found.
    """
    statuses = []
    for crate_spec in CRATES:
        crate_name = crate_spec["name"]
        probe = crate_spec["probe"]
        crate_dir = _find_crate_dir(crate_spec["dir"])

        installed = _is_crate_installed(probe)
        fresh = False
        if installed and crate_dir is not None:
            fresh = _is_crate_fresh(crate_dir, probe)

        # Check if active (importable now)
        active = False
        try:
            importlib.import_module(probe)
            active = True
        except ImportError:
            pass

        statuses.append(
            {
                "name": crate_name,
                "installed": installed,
                "fresh": fresh,
                "active": active,
                "crate_dir_found": crate_dir is not None,
            }
        )

    return statuses


def build_single_crate(crate_name: str) -> bool:
    """Build one specific crate by name from the CRATES registry.

    Returns True on success, False otherwise.
    """
    # Find the crate spec
    crate_spec = None
    for spec in CRATES:
        if spec["name"] == crate_name:
            crate_spec = spec
            break

    if crate_spec is None:
        logger.debug("Unknown crate name: %s", crate_name)
        return False

    # Check prerequisites
    if not _has_rust_toolchain():
        logger.debug("Rust toolchain not available for building %s", crate_name)
        return False

    if not _has_maturin():
        if not _install_maturin():
            logger.debug("Could not install maturin for building %s", crate_name)
            return False

    crate_dir = _find_crate_dir(crate_spec["dir"])
    if crate_dir is None:
        logger.debug("Crate directory not found for %s", crate_name)
        return False

    # Build it
    success, error_msg = _build_crate(crate_dir, crate_name)

    if success:
        # Reload and patch
        is_available = _reload_and_patch_crate(crate_spec)
        if is_available:
            logger.debug("Crate %s built and is now available", crate_name)
            return True
        else:
            logger.debug("Crate %s build succeeded but module not loadable", crate_name)
            return False
    else:
        logger.debug("Build error for %s: %s", crate_name, error_msg)
        return False
