"""Meeting Helper — AI meeting assistant for macOS."""

__version__ = "2.8.6"
