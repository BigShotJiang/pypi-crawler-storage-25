"""HTTP routes: health, config, transcribe, summarize."""

from __future__ import annotations

import asyncio
import json
import logging
import re
import time

from aiohttp import web

from meeting_helper.state import state
from meeting_helper.server.websocket import ws_handler, slim_card_for_broadcast

logger = logging.getLogger(__name__)


def _hot_moment_window_sec(request) -> float:
    """Resolve the configured Hot Moment window in seconds.

    Reads hot_moment_window_minutes from the request app config.
    Returns 0 if no config is reachable (arm_hot_moment becomes a no-op).
    """
    try:
        cfg = request.app.get("config")
        if cfg is not None:
            return cfg.hot_moment_window_minutes * 60.0
    except Exception:
        pass
    return 0.0



try:
    from anthropic import AsyncAnthropic
except ImportError:
    AsyncAnthropic = None  # tests patch this


def _parse_brief_script_to_sentences(script: str) -> list[str]:
    """Extract first-person bullet sentences from the brief markdown script.

    Each bullet line (lines starting with '-' or '*') is treated as one
    sentence. Section headers (**Today**, etc.) are skipped.
    """
    sentences: list[str] = []
    for raw in script.splitlines():
        line = raw.strip()
        if not line:
            continue
        # Skip section headers
        if line.startswith("**") and line.endswith("**"):
            continue
        # Bullets
        if line.startswith("- ") or line.startswith("* "):
            text = line[2:].strip()
            if text:
                sentences.append(text)
    return sentences


def _ticket_ids_in(text: str) -> list[str]:
    """Extract unique ticket IDs (e.g. PROJ-123) preserving first-occurrence order."""
    seen: list[str] = []
    for m in re.finditer(r"[A-Z]{2,}-\d+", text):
        tid = m.group(0)
        if tid not in seen:
            seen.append(tid)
    return seen


def _seed_warm_cache_from_brief(script: str, brief_cards: list[dict]) -> dict:
    """After /brief succeeds, seed state.self_buffer + state.current_topic +
    state.current_topic_cards so subsequent queries have grounded context.

    Returns the seeded `current_topic` dict (also assigned to state).
    """
    sentences = _parse_brief_script_to_sentences(script)
    if state.self_buffer is not None:
        for s in sentences:
            state.self_buffer.append_final(s)

    # Pick the first "Today" bullet as the primary topic statement.
    # The script's structure is:
    #   **Today**
    #   - I'm working on PROJ-123 ...
    #   **Yesterday**
    #   - I finished PROJ-111 ...
    today_bullet = ""
    section = None
    for raw in script.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("**") and line.endswith("**"):
            header = line.strip("*").strip().lower()
            section = header
            continue
        if section == "today" and (line.startswith("- ") or line.startswith("* ")):
            today_bullet = line[2:].strip()
            break  # take the FIRST today bullet

    last_user_statement = today_bullet or (sentences[0] if sentences else "")
    # The brief script no longer prints raw ticket ids (they sound bad read
    # aloud), so harvest them from the source card titles instead.
    ticket_ids: list[str] = []
    for c in (brief_cards or []):
        for tid in _ticket_ids_in(str(c.get("title", ""))):
            if tid not in ticket_ids:
                ticket_ids.append(tid)
    # Fallback: still scan the script in case the model slipped one in.
    for tid in _ticket_ids_in(script):
        if tid not in ticket_ids:
            ticket_ids.append(tid)
    # Topic = a short noun phrase from the today bullet, falling back to the bullet itself
    topic = ""
    if today_bullet:
        # Strip leading first-person "I'm working on " etc.
        cleaned = re.sub(
            r"^(I['’]m\s+(working on|continuing|focused on|on)|I am\s+(working on|continuing|focused on|on))\s+",
            "",
            today_bullet,
            flags=re.IGNORECASE,
        )
        # Take up to the first em-dash or "—" or first 80 chars
        for sep in [" — ", " - ", ": ", ". "]:
            if sep in cleaned:
                topic = cleaned.split(sep, 1)[0].strip()
                break
        if not topic:
            topic = cleaned[:80].strip()

    # Search query — best-effort keywords from the topic
    search_query = topic.lower() if topic else " ".join(ticket_ids[:2])

    current_topic = {
        "topic": topic,
        "ticket_ids": ticket_ids,
        "search_query": search_query,
        "last_user_statement": last_user_statement,
    }
    state.current_topic = current_topic
    state.current_topic_cards = list(brief_cards or [])
    return current_topic


async def health_handler(request: web.Request) -> web.Response:
    meeting_name = ""
    if state.meeting_info:
        meeting_name = getattr(state.meeting_info, "meeting_name", "") or ""
    now = time.time()

    def _age(ts: float):
        return round(now - ts, 1) if ts else None

    aq = state.active_query
    active_query = bool(aq is not None and not aq.done())

    return web.Response(
        text=json.dumps({
            "status": "ok",
            "meeting": meeting_name,
            "session_active": state.session_active,
            "summarizing": state.summarizing,
            "uptime": round(now - state.started_at) if state.started_at else 0,
            "stats": {
                "ai_calls": state.ai_call_count,
                "ai_calls_by_kind": dict(state.ai_calls_by_kind),
                "local_todo_calls": state.local_todo_call_count,
                "local_todo_calls_by_kind": dict(state.local_todo_calls_by_kind),
                "last_local_todo_action": state.last_local_todo_action,
                "last_local_todo_at": state.last_local_todo_at,
            },
            "health": {
                "last_ai_call_at": state.last_ai_call_at or None,
                "last_ai_call_kind": state.last_ai_call_kind,
                "last_ai_call_age_sec": _age(state.last_ai_call_at),
                "active_query": active_query,
                "active_query_age_sec": (
                    _age(state.active_query_started_at) if active_query else None
                ),
                "event_loop_lag_ms": round(state.event_loop_lag_ms, 1),
                "cpu_percent": round(state.proc_cpu_percent, 1),
                "host_cpu_percent": round(state.host_cpu_percent, 1),
                "rss_mb": round(state.proc_rss_mb, 1),
            },
        }),
        content_type="application/json",
    )


async def workspace_handler(request: web.Request) -> web.Response:
    """Return the active workspace name and the daemon's bound port."""
    from meeting_helper.config import get_config, load_state
    state_data = load_state()
    cfg = get_config()
    return web.Response(
        text=json.dumps({
            "name": state_data["active_workspace"],
            "port": cfg.port,
        }),
        content_type="application/json",
    )


async def shutdown_handler(request: web.Request) -> web.Response:
    """Trigger graceful daemon shutdown via SIGTERM (handled in run_daemon)."""
    import os
    import signal
    asyncio.get_event_loop().call_later(
        0.1, lambda: os.kill(os.getpid(), signal.SIGTERM)
    )
    return web.Response(
        text=json.dumps({"ok": True}),
        content_type="application/json",
    )


async def config_get_handler(request: web.Request) -> web.Response:
    """Return live tunables the daemon exposes for runtime reconfig.

    The repos/knowledge fields lived here for the legacy Context Selector;
    that whole layer was removed in Phase 2 of "Learn From Conversations".
    """
    config = request.app["config"]
    return web.Response(
        text=json.dumps({
            "hot_moment_window_minutes": getattr(
                config, "hot_moment_window_minutes", 10.0,
            ),
            "local_todo_mcp": dict(getattr(config, "local_todo_mcp", {}) or {}),
        }),
        content_type="application/json",
    )


async def config_post_handler(request: web.Request) -> web.Response:
    """Update live-tunable workspace config mid-session.

    Accepts `hot_moment_window_minutes`, `local_todo_mcp`, and the transcriber
    settings (`preferred_transcriber`, `whisper_host`, `deepgram_api_key`,
    `transcription_language`). The daemon caches its `AppConfig` at startup, so
    without this the GUI's saved transcriber changes were silently ignored
    until a full daemon restart — here we mutate the in-memory config and, if a
    session is running, hot-swap the transcribers (same path as `/provider`).
    Everything else lives only in the per-workspace JSON written by the GUI.
    """
    try:
        body = await request.json()
    except Exception:
        return web.Response(status=400, text='{"error": "invalid JSON"}',
                            content_type="application/json")

    config = request.app["config"]

    if "hot_moment_window_minutes" in body:
        # Live tunable. Mirror it onto `state` so every Hot Moment armer
        # (TopicWorker on self-speech, query, brief) picks up the change on
        # the next event — `state` is what they read, not this snapshot.
        minutes = float(body["hot_moment_window_minutes"])
        config.hot_moment_window_minutes = minutes
        state.hot_moment_window_sec = minutes * 60.0
    if "local_todo_mcp" in body:
        # MCP config changed — close existing client and rebuild against new endpoint.
        new_mcp = dict(body["local_todo_mcp"] or {})
        config.local_todo_mcp = new_mcp
        if state.local_todo is not None:
            try:
                await state.local_todo.close()
            except Exception as exc:
                logger.warning("local-todo close error during reconfig: %s", exc)
            state.local_todo = None
        kind = (new_mcp.get("type") or "stdio").strip().lower()
        configured = bool(new_mcp.get("url")) if kind == "http" else bool(new_mcp.get("command"))
        if configured:
            try:
                from meeting_helper.local_todo import LocalTodoClient
                state.local_todo = LocalTodoClient(mcp_config=new_mcp)
                logger.info(
                    "local-todo MCP rewired (%s %s)",
                    kind,
                    new_mcp.get("url") if kind == "http" else new_mcp.get("command"),
                )
            except Exception as exc:
                logger.warning("local-todo rewire failed: %s", exc)
                state.local_todo = None
        else:
            logger.info("local-todo MCP cleared via /config")
        # Push fresh info so Brief-button visibility flips without polling delay.
        from meeting_helper.server.websocket import broadcast_info
        asyncio.ensure_future(broadcast_info())

    # Transcriber settings — the daemon's AppConfig snapshot would otherwise
    # only pick these up on a full restart. Mutate it in place and, if a
    # session is live, hot-swap the transcribers (reuses session.swap_transcriber,
    # the same machinery the /provider toolbar dropdown uses). Only act on
    # values that actually changed so an unrelated settings-save doesn't tear
    # down and rebuild the transcribers mid-meeting.
    _trans_changed = False
    if "preferred_transcriber" in body:
        v = (body["preferred_transcriber"] or "").strip()
        if v != config.preferred_transcriber:
            config.preferred_transcriber = v
            _trans_changed = True
    if "whisper_host" in body:
        v = (body["whisper_host"] or "").strip()
        if v != config.whisper_host:
            config.whisper_host = v
            _trans_changed = True
    if "deepgram_api_key" in body:
        v = (body["deepgram_api_key"] or "").strip()
        if v != config.deepgram_api_key:
            config.deepgram_api_key = v
            _trans_changed = True
    if "transcription_language" in body:
        v = (body["transcription_language"] or "auto").strip()
        if v != config.transcription_language:
            config.transcription_language = v
            _trans_changed = True
    if _trans_changed:
        if state.session_active and state.meeting_session is not None:
            try:
                t_name = await asyncio.to_thread(
                    state.meeting_session.swap_transcriber,
                    config.preferred_transcriber, config,
                )
                state.transcriber_name = t_name
                logger.info("Transcriber reconfigured live via /config -> %s", t_name)
            except Exception as exc:
                logger.warning("live transcriber swap failed: %s", exc)
        else:
            logger.info("Transcriber config updated via /config (no active session)")
        from meeting_helper.server.websocket import broadcast_info as _bi
        await _bi()

    # AI provider / model — same story: cached at daemon startup, so a Settings
    # change to these used to need a daemon restart. Queries read `config` fresh,
    # so mutating the in-memory snapshot is enough (no transcriber-style swap).
    _ai_changed = False
    if "preferred_provider" in body:
        v = (body["preferred_provider"] or "").strip()
        if v != config.preferred_provider:
            config.preferred_provider = v
            _ai_changed = True
    if "claude_model" in body:
        from meeting_helper.config import CLAUDE_MODELS
        alias = (body["claude_model"] or "").strip()
        if alias and alias != config.claude_model_alias:
            config.claude_model_alias = alias
            config.claude_model = CLAUDE_MODELS.get(alias, alias)
            _ai_changed = True
    if "gemini_model" in body:
        from meeting_helper.config import GEMINI_MODELS
        alias = (body["gemini_model"] or "").strip()
        if alias and alias != config.gemini_model_alias:
            config.gemini_model_alias = alias
            config.gemini_model = GEMINI_MODELS.get(alias, alias)
            _ai_changed = True
    if "local_model" in body:
        v = (body["local_model"] or "").strip()
        if v != config.local_model:
            config.local_model = v
            _ai_changed = True
    if _ai_changed:
        state.ai_provider = config.preferred_provider or "claude"
        state.ai_model = _resolve_ai_model(config)
        logger.info("AI provider/model reconfigured live via /config -> %s / %s",
                    state.ai_provider, state.ai_model)
        from meeting_helper.server.websocket import broadcast_info as _bi2
        await _bi2()

    return web.Response(
        text=json.dumps({"ok": True}),
        content_type="application/json",
    )


async def transcript_handler_get(request: web.Request) -> web.Response:
    """GET /transcript — return the last N sentences from the buffer."""
    n = int(request.query.get("n", "10"))
    sentences = []
    if state.sentence_buffer is not None:
        sentences = state.sentence_buffer.get_last_n(n)
    interim = None
    if state.sentence_buffer is not None:
        interim = state.sentence_buffer.get_interim()
    return web.Response(
        text=json.dumps({"sentences": sentences, "interim": interim}),
        content_type="application/json",
    )


async def transcript_clear_handler(request: web.Request) -> web.Response:
    """POST /transcript/clear — clear the accumulated transcript buffer."""
    if state.sentence_buffer is not None:
        state.sentence_buffer.clear()
    return web.Response(
        text=json.dumps({"ok": True}),
        content_type="application/json",
    )


async def last_response_handler(request: web.Request) -> web.Response:
    """GET /last_response — return the last AI response text."""
    return web.Response(
        text=json.dumps({"text": state.last_response or ""}),
        content_type="application/json",
    )


async def last_cards_handler(request: web.Request) -> web.Response:
    """GET /last_cards — returns the last query's local-todo source cards."""
    return web.Response(
        text=json.dumps({"items": state.last_cards or []}),
        content_type="application/json",
    )


async def current_topic_handler(request: web.Request) -> web.Response:
    """GET /current_topic — current topic + warm-cache info from TopicWorker."""
    return web.Response(
        text=json.dumps({
            "topic": state.current_topic or {
                "topic": "", "ticket_ids": [], "search_query": "", "last_user_statement": "",
            },
            "cards_count": len(state.current_topic_cards or []),
            "cards": state.current_topic_cards or [],
        }),
        content_type="application/json",
    )


async def topics_handler(request: web.Request) -> web.Response:
    """GET /topics — list every top-level task in active sprints across boards.

    Powers the Topics tab in the Copilot side panel: the user picks one to
    set as the current conversation topic, overriding TopicWorker's
    automatic detection for a brief window.

    Slim payload — no subtasks/comments/history (the TopicsPanel only needs
    enough to render a card and call /topic/set on click).
    """
    if state.local_todo is None:
        return web.json_response(
            {"topics": [], "columns": [], "error": "local-todo MCP not configured"},
            status=503,
        )
    # Server timeout intentionally tighter than the GUI's 8s poll cadence
    # AND tighter than the GUI's 3s urlopen timeout. With a 15s server
    # timeout, a single slow MCP would have the GUI bail at 3s, the next
    # poll fire at 8s while the server still chews for 7 more seconds —
    # producing concurrent my_active_tasks() calls hitting the same MCP
    # subprocess. 5s caps the overlap window at zero.
    try:
        tasks = await asyncio.wait_for(
            state.local_todo.my_active_tasks(), timeout=5.0,
        )
    except asyncio.TimeoutError:
        logger.warning("topics: my_active_tasks timed out (5s)")
        return web.json_response(
            {"topics": [], "columns": [], "error": "timeout"}, status=504,
        )
    except Exception as exc:
        logger.warning("topics: my_active_tasks failed: %s", exc)
        return web.json_response(
            {"topics": [], "columns": [], "error": str(exc)}, status=502,
        )

    # Slim each task to the fields TopicsPanel renders.
    slimmed = [
        {
            "id": str(t.get("id") or ""),
            "title": t.get("title") or "",
            "status": (t.get("status") or "todo").lower(),
            "priority": (t.get("priority") or "").lower(),
            "board_id": t.get("board_id"),
            "board_name": t.get("board_name") or "",
            "sprint_name": t.get("sprint_name") or "",
            "url": t.get("url") or "",
        }
        for t in tasks
        if (t.get("title") or "").strip()
    ]

    # Fetch column metadata per distinct board in parallel so the GUI can
    # render status sections in the user's configured order with their
    # configured names + colors. Without this we hardcode (todo,
    # in_progress, in_review, done) and miss anything the user added on
    # their board (e.g. "blocked"). MCP `list_board_columns` returns
    # `key, name, kind, color, position` per column.
    board_ids: list[int] = sorted({
        t.get("board_id") for t in slimmed
        if isinstance(t.get("board_id"), int)
    })
    columns: list[dict] = []
    if board_ids:
        col_calls = [
            state.local_todo.list_board_columns(bid) for bid in board_ids
        ]
        try:
            results = await asyncio.wait_for(
                asyncio.gather(*col_calls, return_exceptions=True),
                timeout=3.0,
            )
        except asyncio.TimeoutError:
            logger.warning("topics: column fetch timed out (3s)")
            results = []

        # Merge: dedupe by (board_id, key) so multiple boards don't
        # collide on shared status keys; preserve each board's position.
        seen: set[tuple[int, str]] = set()
        for board_id, res in zip(board_ids, results):
            if isinstance(res, Exception):
                logger.warning(
                    "topics: list_board_columns(%d) failed: %s", board_id, res,
                )
                continue
            for c in res or []:
                key = (c.get("key") or "").lower()
                if not key:
                    continue
                marker = (board_id, key)
                if marker in seen:
                    continue
                seen.add(marker)
                columns.append({
                    "board_id": board_id,
                    "key": key,
                    "name": c.get("name") or key.replace("_", " ").title(),
                    "kind": (c.get("kind") or "").lower(),
                    "color": c.get("color") or "",
                    "position": c.get("position", 0),
                })

    return web.json_response({"topics": slimmed, "columns": columns})


async def topic_set_handler(request: web.Request) -> web.Response:
    """POST /topic/set — manually pin the current topic.

    Body: {ticket_id: str, title: str, board_id?: int}

    Side effects:
    - state.current_topic is updated.
    - state.topic_manual_mode is set to True so TopicWorker won't
      overwrite it until the user explicitly toggles back to AUTO.
    - WS broadcast fires so the TopicStrip on top + the active-topic
      highlight in TopicsPanel update immediately.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    ticket_id = str(body.get("ticket_id") or "").strip()
    title = (body.get("title") or "").strip()
    board_id = body.get("board_id")
    if not title:
        return web.json_response({"error": "title required"}, status=400)

    # MANUAL mode is sticky — stays on until the user explicitly toggles
    # back to AUTO via POST /topic/auto (or by clicking the indicator pill
    # in the GUI). No countdown.
    state.current_topic = {
        "topic": title,
        "ticket_ids": [ticket_id] if ticket_id else [],
        "search_query": title,
        "last_user_statement": "",
        "manual": True,
    }
    state.topic_manual_mode = True

    # Hydrate the picked card so the AI's `_format_cards_markdown` has the
    # real ticket body + comments to ground its answers in. Without this,
    # the user pins a topic and the AI knows the title only — every
    # follow-up question lands without context. One get_task call (~100-
    # 300 ms via local-todo MCP) is the entire cost; no LLM round-trip.
    # Cached in state.current_topic_cards for the 90 s pin window so
    # subsequent /query calls reuse it for free.
    hydrated_cards: list[dict] = []
    if state.local_todo is not None and ticket_id and board_id is not None:
        try:
            hydrated = await asyncio.wait_for(
                state.local_todo.get("task", ticket_id, int(board_id)),
                timeout=10.0,
            )
            if hydrated:
                hydrated_cards = [hydrated]
                logger.info(
                    "topic/set: hydrated card %s (board=%s, body=%d chars, "
                    "%d comments, %d subtasks)",
                    ticket_id, board_id,
                    len(hydrated.get("body_md") or ""),
                    len(hydrated.get("comments") or []),
                    len(hydrated.get("subtasks") or []),
                )
        except asyncio.TimeoutError:
            logger.warning(
                "topic/set: hydrate get_task(%s, board=%s) timed out — "
                "falling back to thin card", ticket_id, board_id,
            )
        except Exception as exc:
            logger.warning(
                "topic/set: hydrate get_task(%s, board=%s) failed: %s — "
                "falling back to thin card", ticket_id, board_id, exc,
            )

    if not hydrated_cards:
        # Fall back to a thin card so the AI at least sees the ticket id +
        # title. Cards markdown handles thin cards gracefully (title only).
        thin_card: dict = {"id": ticket_id, "title": title}
        if board_id is not None:
            thin_card["board_id"] = board_id
        hydrated_cards = [thin_card]

    state.current_topic_cards = hydrated_cards

    # Broadcast so all connected GUIs reflect the change immediately.
    # MANUAL mode is binary now — no countdown payload. The GUI flips its
    # AUTO/MANUAL pill until the user toggles it back.
    try:
        from meeting_helper.server.websocket import broadcast
        await broadcast({
            "type": "topic",
            "topic": title,
            "ticket_ids": [ticket_id] if ticket_id else [],
            "last_user_statement": "",
            "cards": [],
            "manual": True,
            "hot_moment": {
                "active": state.is_hot_moment(),
                "until_wallclock": state.hot_moment_until_wallclock(),
            },
        })
    except Exception as exc:
        logger.warning("topic/set broadcast failed: %s", exc)

    logger.info(
        "topic/set: pinned ticket_id=%s title=%r indefinite",
        ticket_id, title[:80],
    )
    return web.json_response({
        "ok": True,
        "ticket_id": ticket_id,
        "title": title,
        "manual": True,
    })


async def topic_auto_handler(request: web.Request) -> web.Response:
    """POST /topic/auto — clear the manual topic pin and let TopicWorker
    resume auto-picking. Idempotent.
    """
    state.topic_manual_mode = False
    # Clear the pinned topic so TopicWorker's next pick takes over cleanly.
    state.current_topic = {}
    state.current_topic_cards = []
    state.last_cards = []
    # Broadcast so the GUI updates immediately.
    try:
        from meeting_helper.server.websocket import broadcast
        await broadcast({"type": "topic", "manual": False, "current_topic": {}})
    except Exception as exc:
        logger.warning("topic/auto broadcast failed: %s", exc)
    logger.info("topic/auto: cleared manual pin")
    return web.json_response({"ok": True})


async def topic_manual_handler(request: web.Request) -> web.Response:
    """POST /topic/manual — flip into MANUAL mode without changing the
    current topic. TopicWorker stops auto-picking; the displayed topic
    stays as-is. Idempotent.
    """
    state.topic_manual_mode = True
    from meeting_helper.server.websocket import broadcast
    try:
        await broadcast({"type": "topic", "manual": True})
    except Exception as exc:
        logger.warning("topic/manual broadcast failed: %s", exc)
    logger.info("topic/manual: switched to MANUAL")
    return web.json_response({"ok": True})


async def hot_moment_cancel_handler(request: web.Request) -> web.Response:
    """POST /hot_moment/cancel — disarm the current hot moment immediately.

    Sets hot_moment_until to 0 so state.is_hot_moment() returns False
    on the next tick. Idempotent.
    """
    state.hot_moment_until = 0.0
    from meeting_helper.server.websocket import broadcast
    try:
        await broadcast({"type": "hot_moment", "active": False, "until_wallclock": 0})
    except Exception as exc:
        logger.warning("hot_moment/cancel broadcast failed: %s", exc)
    logger.info("hot_moment/cancel: disarmed")
    return web.json_response({"ok": True})


async def query_handler(request: web.Request) -> web.Response:
    """POST /query — send a manual text query to Claude."""
    state.arm_hot_moment(window_sec=_hot_moment_window_sec(request))
    try:
        body = await request.json()
    except Exception:
        return web.Response(status=400, text='{"error": "invalid JSON"}',
                            content_type="application/json")

    text = body.get("text", "").strip()
    if not text:
        return web.Response(status=400, text='{"error": "text required"}',
                            content_type="application/json")

    from meeting_helper.ai.client import handle_manual_query
    config = request.app["config"]

    try:
        await handle_manual_query(state, config, text)
        return web.Response(
            text=json.dumps({"ok": True}),
            content_type="application/json",
        )
    except Exception as exc:
        return web.Response(
            status=500,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )


async def trigger_query_handler(request: web.Request) -> web.Response:
    """POST /query/trigger — context-only query, equivalent to the 2xCmd hotkey.

    Calls handle_query(state, config) without any user-typed text — the AI
    responds based on current transcript + topic context.
    """
    state.arm_hot_moment(window_sec=_hot_moment_window_sec(request))
    from meeting_helper.ai.client import handle_query
    config = request.app["config"]
    try:
        await handle_query(state, config)
        return web.Response(
            text=json.dumps({"ok": True}),
            content_type="application/json",
        )
    except Exception as exc:
        return web.Response(
            status=500,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )


async def transcribe_handler(request: web.Request) -> web.Response:
    """POST /transcribe — transcribe an MP3 file with Whisper."""
    try:
        body = await request.json()
    except Exception:
        return web.Response(status=400, text='{"error": "invalid JSON"}',
                            content_type="application/json")

    mp3_path = body.get("mp3_path", "")
    if not mp3_path:
        return web.Response(status=400, text='{"error": "mp3_path required"}',
                            content_type="application/json")

    from meeting_helper.ai.client import transcribe_audio_file
    config = request.app["config"]

    try:
        transcript = await asyncio.to_thread(transcribe_audio_file, mp3_path, config)
        return web.Response(
            text=json.dumps({"ok": True, "transcript": transcript}),
            content_type="application/json",
        )
    except Exception as exc:
        return web.Response(
            status=500,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )


async def summarize_handler(request: web.Request) -> web.Response:
    """POST /summarize — summarize a transcript with Claude."""
    try:
        body = await request.json()
    except Exception:
        return web.Response(status=400, text='{"error": "invalid JSON"}',
                            content_type="application/json")

    transcript_path = body.get("transcript_path", "")
    if not transcript_path:
        return web.Response(status=400, text='{"error": "transcript_path required"}',
                            content_type="application/json")

    from meeting_helper.ai.client import summarize_transcript
    config = request.app["config"]

    try:
        summary = await summarize_transcript(transcript_path, config)
        return web.Response(
            text=json.dumps({"ok": True, "summary": summary}),
            content_type="application/json",
        )
    except Exception as exc:
        return web.Response(
            status=500,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )


async def extract_task_handler(request: web.Request) -> web.Response:
    """POST /extract-task — extract new action items from the in-memory transcript."""
    from meeting_helper.ai.client import extract_tasks
    from meeting_helper.server.websocket import broadcast

    config = request.app["config"]
    try:
        added = await extract_tasks(state, config)
    except Exception as exc:
        return web.Response(
            status=500,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )

    await broadcast({"type": "tasks_extracted", "added": len(added)})
    await broadcast({"type": "tasks", "tasks": list(state.session_tasks)})

    return web.Response(
        text=json.dumps({"added": len(added), "total": len(state.session_tasks)}),
        content_type="application/json",
    )


async def tasks_get_handler(request: web.Request) -> web.Response:
    """GET /tasks — return the current session's extracted tasks."""
    return web.Response(
        text=json.dumps({"tasks": list(state.session_tasks)}),
        content_type="application/json",
    )


async def brief_handler(request: web.Request) -> web.Response:
    """POST /brief — generate a first-person standup script + source cards from local-todo."""
    state.arm_hot_moment(window_sec=_hot_moment_window_sec(request))
    from meeting_helper.ai.prompts import BRIEF_SYSTEM_PROMPT
    import httpx

    config = request.app.get("config")
    logger.info("brief: start")
    if state.local_todo is None:
        logger.warning("brief: local_todo not configured — early-exit 503")
        return web.json_response(
            {"error": "local-todo MCP not configured"}, status=503,
        )
    if not getattr(config, "anthropic_api_key", ""):
        logger.warning("brief: anthropic key missing — early-exit 503")
        return web.json_response(
            {"error": "Anthropic API key not configured"}, status=503,
        )

    # Generous timeouts — first MCP call cold-starts the subprocess + does
    # list_boards + N parallel list_sprints + N parallel search_tasks + N
    # parallel get_task(include_subtasks=true). On a heavily loaded machine
    # 15s is too tight; 90s leaves headroom but still caps a wedged MCP call.
    # The enriched fetch adds one round-trip per active task; for ~10 active
    # tasks that's typically <2s on top of the base call.
    try:
        logger.info("brief: fetching my_active_tasks_enriched…")
        active_tasks = await asyncio.wait_for(
            state.local_todo.my_active_tasks_enriched(), timeout=90.0,
        )
        logger.info(
            "brief: got %d active topics (with subtasks/comments/history)",
            len(active_tasks),
        )
    except asyncio.TimeoutError:
        logger.warning("brief: my_active_tasks_enriched timed out after 90s")
        return web.json_response({"error": "local-todo timed out (90s)"}, status=504)
    except Exception as exc:
        logger.warning("brief: my_active_tasks_enriched failed: %s", exc)
        return web.json_response({"error": f"local-todo error: {exc}"}, status=502)

    if not active_tasks:
        logger.warning("brief: no active tasks — skipping LLM call")
        return web.json_response(
            {"error": "No active tasks in any sprint — nothing to summarize"},
            status=502,
        )

    user_msg = (
        "## My active topics (top-level tasks in active sprints, with their "
        "subtasks, recent comments, and recent history nested inline):\n"
        + json.dumps(active_tasks, indent=2)
        + "\n\nGenerate the standup script as JSON."
    )

    # Explicit timeout — without this, the Anthropic call could hang
    # indefinitely on a slow/wedged network (the GUI eventually gives up
    # at 30s but the daemon would still be holding the request open).
    client = AsyncAnthropic(
        api_key=config.anthropic_api_key,
        http_client=httpx.AsyncClient(verify=False, timeout=httpx.Timeout(30.0)),
    )
    state.record_ai_call("brief")
    try:
        logger.info("brief: calling Claude (haiku) with %d tasks…", len(active_tasks))
        msg = await asyncio.wait_for(
            client.messages.create(
                model="claude-haiku-4-5-20251001",
                max_tokens=getattr(config, "max_tokens", 800),
                system=BRIEF_SYSTEM_PROMPT,
                messages=[{"role": "user", "content": user_msg}],
            ),
            timeout=30.0,
        )
        logger.info("brief: Claude responded")
    except asyncio.TimeoutError:
        logger.warning("brief: Claude call timed out after 30s")
        return web.json_response({"error": "Claude API timed out (30s)"}, status=504)
    except Exception as exc:
        logger.warning("brief: Claude call failed: %s", exc)
        return web.json_response({"error": f"Claude call failed: {exc}"}, status=502)

    raw = msg.content[0].text.strip()
    match = re.search(r"\{.*\}", raw, re.DOTALL)
    if not match:
        logger.warning("brief: AI returned non-JSON (%d chars)", len(raw))
        return web.json_response({"error": "AI returned non-JSON", "raw": raw[:500]}, status=502)
    try:
        parsed = json.loads(match.group())
    except json.JSONDecodeError as exc:
        logger.warning("brief: JSON parse failed: %s", exc)
        return web.json_response({"error": f"JSON parse: {exc}", "raw": raw[:500]}, status=502)

    script = parsed.get("script", "").strip()
    card_ids = parsed.get("card_ids", []) or []
    logger.info("brief: parsed (script=%d chars, %d card_ids)", len(script), len(card_ids))
    if not script and not card_ids:
        logger.warning("brief: AI returned empty script and no card_ids — likely no active tasks")
        return web.json_response(
            {"error": "Brief came back empty — no active tasks to summarize"},
            status=502,
        )

    # Build id → board_id lookup from active_tasks (since task ids are scoped per board)
    id_to_board: dict[str, int] = {}
    for t in active_tasks:
        tid = str(t.get("id", ""))
        bid = t.get("board_id")
        if tid and bid is not None:
            id_to_board[tid] = bid

    cards: list[dict] = []
    for cid in card_ids:
        cid = str(cid)
        bid = id_to_board.get(cid)
        if bid is None:
            # Card id not in our active set — skip or try first available board
            logger.warning("brief: card_id %s not in active task set; skipping backfill", cid)
            continue
        record = None
        try:
            record = await asyncio.wait_for(
                state.local_todo.get("task", cid, board_id=bid), timeout=15.0,
            )
            if record:
                record.setdefault("kind", "task")
                record.setdefault("board_id", bid)
        except asyncio.TimeoutError:
            logger.warning("brief: backfill task %s timed out", cid)
            record = None
        except Exception:
            record = None
        if not record:
            try:
                record = await asyncio.wait_for(
                    state.local_todo.get("doc", cid, board_id=bid), timeout=15.0,
                )
                if record:
                    record.setdefault("kind", "doc")
                    record.setdefault("board_id", bid)
            except asyncio.TimeoutError:
                logger.warning("brief: backfill doc %s timed out", cid)
                continue
            except Exception as exc:
                logger.warning("brief: failed to backfill %s: %s", cid, exc)
                continue
        if record:
            cards.append(record)
    logger.info("brief: backfill done (%d/%d cards resolved)", len(cards), len(card_ids))

    # Slim cards before broadcasting (full records can blow the WS frame).
    # Full `cards` list is still passed to _seed_warm_cache_from_brief below
    # so AI queries keep their grounding context.
    slim_cards = [slim_card_for_broadcast(c) for c in cards]
    payload = {"script": script, "cards": slim_cards}

    # Seed warm cache so subsequent /query calls have grounded context
    # even before the user speaks aloud.
    try:
        seeded_topic = _seed_warm_cache_from_brief(script, cards)
        try:
            from meeting_helper.server.websocket import broadcast
            # NOTE: don't include `cards` here. The full card payload (with
            # comment threads etc.) can be large enough to disconnect WS
            # clients on the topic broadcast, *before* the brief broadcast
            # below ever lands. The brief broadcast carries cards for the
            # GUI, and the overlay only used `cards` here to compute a
            # count — pass the count instead.
            await broadcast({
                "type": "topic",
                "topic": seeded_topic.get("topic", ""),
                "ticket_ids": seeded_topic.get("ticket_ids", []),
                "last_user_statement": seeded_topic.get("last_user_statement", ""),
                "warm_cards_count": len(cards),
            })
            logger.info("brief: topic broadcast sent")
        except Exception as exc:
            logger.warning("brief: topic broadcast failed: %s", exc)
    except Exception as exc:
        logger.warning("brief: warm-cache seeding failed: %s", exc)

    try:
        from meeting_helper.server.websocket import broadcast
        n_clients = len(state.ws_clients)
        await broadcast({"type": "brief", **payload})
        logger.info("brief: brief broadcast sent to %d ws clients", n_clients)
    except Exception as exc:
        logger.warning("brief: brief broadcast failed: %s", exc)

    logger.info("brief: done")
    return web.json_response(payload)


async def debug_say_handler(request: web.Request) -> web.Response:
    """POST /debug/say — inject a sentence into self_buffer or other_buffer
    for testing without a mic. Body: {"text": "...", "role": "self"|"other"}.
    """
    try:
        body = await request.json()
    except Exception:
        return web.json_response({"error": "invalid JSON"}, status=400)

    text = (body.get("text") or "").strip()
    if not text:
        return web.json_response({"error": "text required"}, status=400)
    role = (body.get("role") or "self").strip().lower()
    if role not in ("self", "other"):
        return web.json_response({"error": "role must be 'self' or 'other'"}, status=400)

    buf = state.self_buffer if role == "self" else state.other_buffer
    if buf is None:
        return web.json_response(
            {"error": f"{role}_buffer not initialized — start a session first"},
            status=409,
        )

    buf.append_final(text)
    logger.info("debug/say: injected '%s' into %s_buffer", text[:80], role)
    return web.json_response({"ok": True, "role": role, "text": text})


async def conversations_handler(request: web.Request) -> web.Response:
    """GET /conversations?repo=<path> — list past Claude Code conversations for a repo."""
    repo = request.query.get("repo", "").strip()
    if not repo:
        return web.Response(
            status=400,
            text=json.dumps({"error": "repo query param required"}),
            content_type="application/json",
        )
    from meeting_helper.claude_history import list_conversations
    convs = await asyncio.to_thread(list_conversations, repo)
    return web.Response(
        text=json.dumps({"conversations": convs}),
        content_type="application/json",
    )


async def conversation_attach_handler(request: web.Request) -> web.Response:
    """POST /conversation/attach — attach a past Claude Code conversation as primary context.

    Body: {"repo": "<absolute path>", "session_id": "<uuid>"}
    """
    try:
        body = await request.json()
    except Exception:
        return web.Response(
            status=400,
            text='{"error": "invalid JSON"}',
            content_type="application/json",
        )

    repo = (body.get("repo") or "").strip()
    session_id = (body.get("session_id") or "").strip()
    if not repo or not session_id:
        return web.Response(
            status=400,
            text='{"error": "repo and session_id required"}',
            content_type="application/json",
        )

    from meeting_helper.claude_history import reconstruct_conversation
    from meeting_helper.ai.prompts import build_system_prompt, build_conversation_context_block
    from pathlib import Path

    try:
        conv = await asyncio.to_thread(reconstruct_conversation, repo, session_id)
    except FileNotFoundError as exc:
        return web.Response(
            status=404,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )
    except Exception as exc:
        return web.Response(
            status=500,
            text=json.dumps({"error": str(exc)}),
            content_type="application/json",
        )

    repo_name = Path(repo).expanduser().resolve().name
    context_block = build_conversation_context_block(
        title=conv["title"],
        repo_name=repo_name,
        body=conv["body"],
        truncated=conv["truncated"],
    )
    state.system_prompt = build_system_prompt(context_block)
    # Clear any prior Q&A turns so answers grounded in the OLD context don't
    # leak into answers for the NEW conversation. Safe whether this is the
    # first attach or a switch from another conversation.
    state.conversation_history = []
    state.attached_conversation = {
        "session_id": conv["session_id"],
        "title": conv["title"],
        "repo": conv["repo"],
        "attached_at": time.time(),
        "chars": conv["chars"],
        "truncated": conv["truncated"],
        "turn_count": conv["turn_count"],
    }

    from meeting_helper.server.websocket import broadcast
    await broadcast({
        "type": "conversation_attached",
        "session_id": conv["session_id"],
        "title": conv["title"],
        "repo": conv["repo"],
        "chars": conv["chars"],
        "truncated": conv["truncated"],
        "turn_count": conv["turn_count"],
    })

    return web.Response(
        text=json.dumps({
            "ok": True,
            "title": conv["title"],
            "chars": conv["chars"],
            "truncated": conv["truncated"],
            "turn_count": conv["turn_count"],
        }),
        content_type="application/json",
    )


async def conversation_detach_handler(request: web.Request) -> web.Response:
    """POST /conversation/detach — clear an attached Claude Code conversation.

    Drops to a bare system prompt — the repos/knowledge auto-context layer
    has been removed (see Phase 2 of "Learn From Conversations").
    """
    if state.attached_conversation is None:
        return web.Response(
            text=json.dumps({"ok": True, "was_attached": False}),
            content_type="application/json",
        )

    state.attached_conversation = None
    # Clear Q&A turns grounded in the conversation we're detaching from.
    state.conversation_history = []

    from meeting_helper.ai.prompts import build_system_prompt
    state.system_prompt = build_system_prompt("")

    from meeting_helper.server.websocket import broadcast
    await broadcast({"type": "conversation_detached"})

    return web.Response(
        text=json.dumps({"ok": True, "was_attached": True}),
        content_type="application/json",
    )


async def session_start_handler(request: web.Request) -> web.Response:
    """POST /session/start — manually start a full recording session."""
    if state.session_active:
        return web.Response(
            text=json.dumps({"ok": True, "already_active": True}),
            content_type="application/json",
        )
    session = state.meeting_session
    if session is None:
        return web.Response(status=400, text='{"error": "no session manager"}',
                            content_type="application/json")
    session.manual_start()
    return web.Response(
        text=json.dumps({"ok": True}),
        content_type="application/json",
    )


async def session_stop_handler(request: web.Request) -> web.Response:
    """POST /session/stop — manually stop the current recording session."""
    if not state.session_active:
        return web.Response(
            text=json.dumps({"ok": True, "was_active": False}),
            content_type="application/json",
        )
    session = state.meeting_session
    if session is None:
        return web.Response(status=400, text='{"error": "no session manager"}',
                            content_type="application/json")
    session.manual_stop()
    return web.Response(
        text=json.dumps({"ok": True}),
        content_type="application/json",
    )


async def proactive_handler(request: web.Request) -> web.Response:
    """POST /proactive — enable or disable proactive answers for current session."""
    try:
        body = await request.json()
    except Exception:
        return web.Response(status=400, text='{"error": "invalid JSON"}', content_type="application/json")

    enabled = bool(body.get("enabled", True))
    monitor = state.proactive_monitor
    if monitor is not None:
        monitor.set_enabled(enabled)

    return web.Response(
        text=json.dumps({"ok": True, "enabled": enabled, "monitor_active": monitor is not None}),
        content_type="application/json",
    )


async def proactive_status_handler(request: web.Request) -> web.Response:
    """GET /proactive — return current proactive enabled state."""
    monitor = state.proactive_monitor
    enabled = monitor.is_enabled() if monitor is not None else False
    return web.Response(
        text=json.dumps({"enabled": enabled, "monitor_active": monitor is not None}),
        content_type="application/json",
    )


def _resolve_ai_model(config) -> str:
    """Return the display model string for the current provider config."""
    if config.preferred_provider == "local":
        return config.local_model
    if config.preferred_provider == "gemini":
        return config.gemini_model
    return config.claude_model


async def provider_get_handler(request: web.Request) -> web.Response:
    """GET /provider — return current provider/model/transcriber state.

    Also reports whether the workspace has the prerequisites the GUI needs to
    decide which controls to surface (`local_todo_configured`,
    `provider_configured`). Without these the GUI would have to read the
    daemon's config another way.
    """
    config = request.app["config"]
    return web.Response(
        text=json.dumps({
            "provider": config.preferred_provider or "claude",
            "claude_model": config.claude_model_alias,
            "gemini_model": config.gemini_model_alias,
            "local_model": config.local_model,
            "transcriber": config.preferred_transcriber or "whisper",
            # Runtime transcriber display name — e.g. "Whisper (remote: …)" /
            # "Whisper (local)" / "Deepgram" — so the toolbar chip shows what's
            # actually running, not just the configured mode. Empty until a
            # session has started.
            "transcriber_name": state.transcriber_name,
            "ai_model": state.ai_model,
            "local_todo_configured": config.local_todo_configured,
            "provider_configured": config.provider_configured,
        }),
        content_type="application/json",
    )


async def provider_post_handler(request: web.Request) -> web.Response:
    """POST /provider — switch AI provider, model, or transcriber at runtime."""
    try:
        body = await request.json()
    except Exception:
        return web.Response(status=400, text='{"error": "invalid JSON"}',
                            content_type="application/json")

    config = request.app["config"]
    changed = False

    # AI provider switch
    if "provider" in body:
        config.preferred_provider = body["provider"]
        changed = True
    if "claude_model" in body:
        from meeting_helper.config import CLAUDE_MODELS
        alias = body["claude_model"]
        config.claude_model_alias = alias
        config.claude_model = CLAUDE_MODELS.get(alias, alias)
        changed = True
    if "gemini_model" in body:
        from meeting_helper.config import GEMINI_MODELS
        alias = body["gemini_model"]
        config.gemini_model_alias = alias
        config.gemini_model = GEMINI_MODELS.get(alias, alias)
        changed = True
    if "local_model" in body:
        config.local_model = body["local_model"]
        changed = True

    # Transcriber switch
    transcriber_changed = False
    if "transcriber" in body:
        config.preferred_transcriber = body["transcriber"]
        transcriber_changed = True
        changed = True

    if transcriber_changed and state.session_active:
        session = state.meeting_session
        if session is not None:
            t_name = await asyncio.to_thread(
                session.swap_transcriber, body["transcriber"], config
            )
            state.transcriber_name = t_name

    # Update displayed AI provider + model
    if changed:
        state.ai_provider = config.preferred_provider or "claude"
        state.ai_model = _resolve_ai_model(config)

        # Broadcast info update to overlay/dashboard
        from meeting_helper.server.websocket import broadcast_info
        await broadcast_info()

        # Persist to disk config
        from meeting_helper.config import get_config
        disk = get_config()
        disk.preferred_provider = config.preferred_provider
        disk.claude_model = config.claude_model_alias
        disk.gemini_model = config.gemini_model_alias
        disk.local_model = config.local_model
        disk.preferred_transcriber = config.preferred_transcriber
        disk.save()

    return web.Response(
        text=json.dumps({"ok": True}),
        content_type="application/json",
    )


def setup_routes(app: web.Application) -> None:
    app.router.add_get("/health", health_handler)
    app.router.add_get("/config", config_get_handler)
    app.router.add_post("/config", config_post_handler)
    app.router.add_get("/transcript", transcript_handler_get)
    app.router.add_post("/transcript/clear", transcript_clear_handler)
    app.router.add_get("/last_response", last_response_handler)
    app.router.add_get("/last_cards", last_cards_handler)
    app.router.add_get("/current_topic", current_topic_handler)
    app.router.add_get("/topics", topics_handler)
    app.router.add_post("/topic/set", topic_set_handler)
    app.router.add_post("/topic/auto", topic_auto_handler)
    app.router.add_post("/topic/manual", topic_manual_handler)
    app.router.add_post("/hot_moment/cancel", hot_moment_cancel_handler)
    app.router.add_post("/query", query_handler)
    app.router.add_post("/query/trigger", trigger_query_handler)
    app.router.add_post("/transcribe", transcribe_handler)
    app.router.add_post("/summarize", summarize_handler)
    app.router.add_post("/extract-task", extract_task_handler)
    app.router.add_get("/tasks", tasks_get_handler)
    app.router.add_post("/brief", brief_handler)
    app.router.add_post("/debug/say", debug_say_handler)
    app.router.add_get("/conversations", conversations_handler)
    app.router.add_post("/conversation/attach", conversation_attach_handler)
    app.router.add_post("/conversation/detach", conversation_detach_handler)
    app.router.add_post("/proactive", proactive_handler)
    app.router.add_get("/proactive", proactive_status_handler)
    app.router.add_post("/session/start", session_start_handler)
    app.router.add_post("/session/stop", session_stop_handler)
    app.router.add_get("/provider", provider_get_handler)
    app.router.add_post("/provider", provider_post_handler)
    app.router.add_get("/workspace", workspace_handler)
    app.router.add_post("/shutdown", shutdown_handler)
    app.router.add_get("/ws", ws_handler)
