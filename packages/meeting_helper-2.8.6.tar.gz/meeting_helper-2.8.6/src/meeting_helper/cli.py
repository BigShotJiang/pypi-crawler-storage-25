"""CLI entry point for meeting-helper."""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

import click

from meeting_helper.config import (
    CLAUDE_MODELS,
    CONFIG_FILE,
    LOG_FILE,
    Config,
    bootstrap_test_config_dir,
    get_config,
)
from meeting_helper.daemon import is_process_running, kill_existing, read_meta, read_pid


@click.group(invoke_without_command=True)
@click.pass_context
def cli(ctx):
    """Meeting Helper — AI meeting assistant for macOS."""
    bootstrap_test_config_dir()
    if ctx.invoked_subcommand is None:
        ctx.invoke(start)


@cli.command()
@click.option("--foreground", "-f", is_flag=True, help="Run daemon in foreground (no fork)")
@click.option("--workspace", "-w", default=None, help="Workspace name to activate before starting.")
def start(foreground, workspace: str | None):
    """Start the daemon (auto-detects meetings, records, transcribes)."""
    if workspace:
        from meeting_helper.config import set_active_workspace
        try:
            set_active_workspace(workspace)
        except ValueError as e:
            raise click.ClickException(str(e))
    config = get_config()


    # Kill existing daemon if running
    existing_pid = read_pid()
    if existing_pid and is_process_running(existing_pid):
        click.echo(f"Daemon already running (pid={existing_pid}). Stopping it first...")
        kill_existing()
        time.sleep(0.5)

    app_config = config.to_app_config()
    click.echo(f"Starting daemon on port {app_config.port}...")

    if foreground:
        _run_foreground(app_config)
    else:
        from meeting_helper.daemon import run_daemon
        run_daemon(app_config)


def _run_foreground(config):
    """Run daemon without forking (for debugging)."""
    import asyncio
    import logging
    import signal

    from meeting_helper.buffer import SentenceBuffer
    from meeting_helper.daemon import write_meta, write_pid_file, remove_pid_file, remove_meta
    from meeting_helper.hotkeys import start_hotkey_listener
    from meeting_helper.server.app import create_app
    from meeting_helper.session import MeetingSession
    from meeting_helper.state import state

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    logger = logging.getLogger("meeting_helper")

    write_pid_file()

    state.started_at = time.time()
    state.self_buffer = SentenceBuffer(max_sentences=50, role="self")
    state.other_buffer = SentenceBuffer(max_sentences=50, role="other")
    state.system_prompt = config.system_prompt

    def on_meeting_start(info):
        state.status = "listening"
        state.meeting_info = info
        state.session_active = True
        logger.info("Meeting started: %s (%s)", info.app_name, info.meeting_name or "unnamed")

    def on_meeting_end(saved_path):
        state.status = "idle"
        state.meeting_info = None
        state.session_active = False
        state.conversation_history.clear()
        logger.info("Meeting ended. Recording: %s", saved_path)

    session = MeetingSession(
        config=config,
        self_buffer=state.self_buffer,
        other_buffer=state.other_buffer,
        on_meeting_start=on_meeting_start,
        on_meeting_end=on_meeting_end,
    )
    session.start()
    write_meta(config, transcriber_name="pending")
    start_hotkey_listener(config)

    async def _main():
        import aiohttp.web as web

        loop = asyncio.get_running_loop()
        state.asyncio_loop = loop
        state.shutdown_event = asyncio.Event()

        app = create_app(config)
        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, "0.0.0.0", config.port)
        await site.start()
        logger.info("Server on 0.0.0.0:%d", config.port)

        try:
            await state.shutdown_event.wait()
        except asyncio.CancelledError:
            pass
        finally:
            await runner.cleanup()

    try:
        asyncio.run(_main())
    except KeyboardInterrupt:
        click.echo("\nShutting down...")
    finally:
        session.stop()
        remove_pid_file()
        remove_meta()


@cli.command()
def stop():
    """Stop the running daemon."""
    if kill_existing():
        click.echo("Daemon stopped.")
    else:
        click.echo("No daemon running.")


@cli.command()
def status():
    """Show daemon status."""
    pid = read_pid()
    if pid and is_process_running(pid):
        meta = read_meta()
        click.echo(f"Daemon running (pid={pid})")
        if meta:
            port = meta.get("port", "?")
            provider = meta.get("ai_provider", "claude")
            if provider == "local":
                model = meta.get("local_model", "?")
            else:
                model = meta.get("claude_model", "?")
            transcriber = meta.get("transcriber", "?")
            click.echo(f"  Port: {port}")
            click.echo(f"  Provider: {provider}")
            click.echo(f"  Model: {model}")
            click.echo(f"  Transcriber: {transcriber}")
            started = meta.get("started_at", 0)
            if started:
                uptime = int(time.time() - started)
                m, s = divmod(uptime, 60)
                h, m = divmod(m, 60)
                click.echo(f"  Uptime: {h}h {m}m {s}s")

        # Try health endpoint
        try:
            import urllib.request
            port = (meta or {}).get("port", 7891)
            req = urllib.request.Request(f"http://127.0.0.1:{port}/health")
            with urllib.request.urlopen(req, timeout=2) as resp:
                data = json.loads(resp.read().decode())
            meeting = data.get("meeting", "")
            if meeting:
                click.echo(f"  Meeting: {meeting}")
            click.echo(f"  Session: {'active' if data.get('session_active') else 'idle'}")
        except Exception:
            pass

        # Probe ScreenCaptureKit so the user knows whether system audio
        # capture is actually going to work — single most useful diagnostic
        # for the recurring "managed-laptop" silent-system-audio symptom.
        from meeting_helper import permissions as _perm
        if _perm.is_macos():
            probe = _perm.probe_sck(timeout=2.0)
            if probe == "ok":
                click.echo("  Screen capture: ok")
            elif probe == "unavailable":
                click.echo("  Screen capture: unavailable (PyObjC/SCK missing)")
            else:
                click.echo(f"  Screen capture: BROKEN ({probe})")
                click.echo(
                    "    System audio will be silent. "
                    "Run `meeting-helper fix-recording` to attempt recovery."
                )
    else:
        click.echo("Daemon not running.")
        click.echo("  Start with: meeting-helper start")


@cli.command("diagnose-recording")
def diagnose_recording():
    """Dump everything we can about why screen recording isn't working.

    Run this when `fix-recording` doesn't help. Paste the output back so
    we can target the actual root cause — currently we know SCK hangs
    but not WHY.
    """
    from meeting_helper import permissions as _perm
    if not _perm.is_macos():
        click.echo("This command is macOS-only. Nothing to do.")
        return

    click.echo("Screen Recording diagnostics")
    click.echo("─" * 60)
    diag = _perm.collect_diagnostics()

    click.echo("[python]")
    for k, v in diag["python"].items():
        click.echo(f"  {k}: {v}")

    click.echo("\n[bundle identity — what macOS attributes our SCK request to]")
    if diag["bundle"]:
        for k, v in diag["bundle"].items():
            click.echo(f"  {k}: {v}")
    else:
        click.echo("  (no bundle info available)")

    click.echo("\n[permission]")
    for k, v in diag["permission"].items():
        click.echo(f"  {k}: {v}")

    click.echo("\n[daemon processes]")
    for d, s in diag["daemon_processes"].items():
        click.echo(f"  {d}: {s}")

    click.echo("\n[macOS unified log — last 30s, SCK + replayd + TCC]")
    log_text = diag.get("sck_log", "")
    if log_text:
        for line in log_text.splitlines():
            click.echo(f"  {line}")
    else:
        click.echo("  (no log entries)")

    click.echo("\n" + "─" * 60)
    click.echo("Paste this output back to share the root cause.")


@cli.command("fix-recording")
@click.option(
    "--no-sudo", is_flag=True,
    help="Skip the sudo nudge that restarts tccd / coreaudiod / replayd.",
)
@click.option(
    "--open-settings", is_flag=True,
    help="Also open System Settings → Privacy → Screen Recording at the end.",
)
@click.option(
    "--userspace-reboot", is_flag=True,
    help="Skip the daemon kills and go straight to `launchctl reboot userspace`.",
)
def fix_recording(no_sudo, open_settings, userspace_reboot):
    """Recover Screen Recording / system audio capture without rebooting.

    Runs the cheapest fixes first: restart the daemon (clears stale SCK
    sessions inside our process). If --no-sudo is not passed, also offers
    to restart `tccd` and `coreaudiod` — the macOS daemons that own
    permission state and audio routing — which often un-wedges the OS-side
    cause without needing a reboot.
    """
    from meeting_helper import permissions as _perm

    if not _perm.is_macos():
        click.echo("This command is macOS-only. Nothing to do.")
        return

    click.echo("Screen Recording recovery")
    click.echo("─" * 40)

    # Fast path: --userspace-reboot skips the rest and goes straight to
    # the strongest non-reboot lever.
    if userspace_reboot:
        click.echo(
            "About to run `sudo launchctl reboot userspace` — this will "
            "restart your user session (all GUI apps close + relaunch) in "
            "~10 seconds. Save your work first."
        )
        if not click.confirm("  Proceed?", default=False):
            click.echo("  Cancelled.")
            return
        ok, msg = _perm.userspace_reboot_interactive()
        click.echo(f"  → {msg}")
        return

    # Step 0: probe — definitive signal whether SCK actually works
    click.echo("Probing ScreenCaptureKit...")
    probe = _perm.probe_sck(timeout=3.0)
    if probe == "ok":
        click.echo("  → SCK works. System audio capture should be fine.")
        click.echo("  If you're still seeing silence, the issue is elsewhere "
                   "(e.g. mic-only meeting, headphones routing).")
        return
    if probe == "unavailable":
        click.echo("  → SCK not available on this system. Skipping recovery.")
        return
    click.echo(f"  → SCK probe failed: {probe}")
    if probe == "timeout":
        click.echo(
            "    (getShareableContent hung — classic 'managed-laptop wedge' signature.)"
        )

    # Step 1: status check (Quartz heuristic — coarse)
    status_str = _perm.screen_recording_status()
    click.echo(f"Quartz permission heuristic: {status_str}")
    if status_str == "denied":
        click.echo(
            "  Permission appears NOT granted. Open System Settings → "
            "Privacy & Security → Screen Recording and enable Terminal/iTerm/your shell host."
        )

    # Step 2: restart daemon (cheapest, no sudo)
    if read_pid() and is_process_running(read_pid()):
        click.echo("Stopping existing daemon...")
        kill_existing()
        time.sleep(0.6)
    click.echo("Starting daemon fresh...")
    config = get_config()
    app_config = config.to_app_config()
    # Spawn daemon in the background — same as `start` non-foreground.
    import subprocess as _sp
    _sp.Popen(
        [sys.executable, "-m", "meeting_helper", "start"],
        stdout=_sp.DEVNULL,
        stderr=_sp.DEVNULL,
        stdin=_sp.DEVNULL,
        start_new_session=True,
    )
    click.echo("  Daemon respawned.")

    # Step 3: optional sudo nudge
    if not no_sudo:
        click.echo("")
        click.echo(
            "If the issue persists, the OS-side cache may be stuck. "
            "I can restart `tccd`, `coreaudiod`, and `replayd` "
            "(needs sudo password). `replayd` is the SCK capture service — "
            "usually the actual culprit when system audio is silent."
        )
        if click.confirm(
            "  Restart tccd + coreaudiod + replayd now?", default=False,
        ):
            result = _perm.restart_tcc_and_coreaudio_interactive()
            click.echo(f"  → {result.get('message', '?')}")
            if result.get("tccd") and result.get("coreaudiod"):
                click.echo(
                    "  Wait ~5 seconds, then start a fresh meeting and check"
                    "\n  the daemon log for 'SCK.start' lines — they now"
                    "\n  identify exactly which step failed if it still breaks."
                )
        else:
            click.echo("  Skipped sudo nudge.")

    # Step 4: re-probe to see if anything we did actually unwedged SCK
    click.echo("")
    click.echo("Re-probing ScreenCaptureKit...")
    probe2 = _perm.probe_sck(timeout=3.0)
    if probe2 == "ok":
        click.echo("  → SCK is now working. Start a meeting to verify system audio.")
        return
    click.echo(f"  → still {probe2}.")

    # Step 5: open settings if requested or if status is denied
    if open_settings or status_str == "denied":
        if _perm.open_screen_recording_settings():
            click.echo("Opened System Settings → Privacy → Screen Recording.")
        else:
            click.echo(
                "Could not open Settings automatically. Open manually:"
                "\n  System Settings → Privacy & Security → Screen Recording"
            )

    # Step 6: offer the strongest non-reboot lever
    click.echo("")
    click.echo("All targeted daemon kills failed. Two remaining options:")
    click.echo("  1. Toggle Screen Recording OFF→ON in System Settings (manual).")
    click.echo("  2. `sudo launchctl reboot userspace` — restarts your user")
    click.echo("     session (~10s, GUI apps close + relaunch, kernel stays up).")
    click.echo("     Faster than a full reboot and often unwedges SCK.")
    if click.confirm(
        "  Run `launchctl reboot userspace` now? "
        "(SAVE YOUR WORK FIRST — apps will close)",
        default=False,
    ):
        ok, msg = _perm.userspace_reboot_interactive()
        click.echo(f"  → {msg}")
        if not ok:
            click.echo(
                "  Userspace reboot didn't run. Last resort: full reboot."
            )
    else:
        click.echo("  Skipped. Try option 1 (manual toggle) or full reboot.")


@cli.command()
def setup():
    """Interactive setup wizard."""
    config = get_config()

    click.echo("\n  Meeting Helper Setup\n")

    # Anthropic key
    current_key = config.anthropic_api_key
    masked = f"...{current_key[-8:]}" if len(current_key) > 8 else "(not set)"
    click.echo(f"  Current Anthropic key: {masked}")
    key = click.prompt("  Anthropic API key (Enter to keep)", default="", show_default=False)
    if key.strip():
        config.anthropic_api_key = key.strip()

    # Deepgram key (optional)
    current_dg = config.deepgram_api_key
    masked_dg = f"...{current_dg[-8:]}" if len(current_dg) > 8 else "(not set)"
    click.echo(f"\n  Current Deepgram key: {masked_dg}")
    dg_key = click.prompt("  Deepgram API key (Enter to skip)", default="", show_default=False)
    if dg_key.strip():
        config.deepgram_api_key = dg_key.strip()

    # Claude model
    click.echo(f"\n  Current model: {config._data.get('claude_model', 'sonnet')}")
    models = list(CLAUDE_MODELS.keys())
    for i, m in enumerate(models):
        click.echo(f"    {i + 1}. {m} ({CLAUDE_MODELS[m]})")
    choice = click.prompt("  Select model (1-3, Enter to keep)", default="", show_default=False)
    if choice.strip() and choice.strip().isdigit():
        idx = int(choice.strip()) - 1
        if 0 <= idx < len(models):
            config.claude_model = models[idx]

    # Recordings dir
    click.echo(f"\n  Recordings dir: {config.recordings_dir}")
    rec_dir = click.prompt("  Recordings directory (Enter to keep)", default="", show_default=False)
    if rec_dir.strip():
        config.recordings_dir = rec_dir.strip()

    # local-todo MCP — structured config (stdio or http)
    current = config.local_todo_mcp
    click.echo(f"\n  Current local-todo MCP:")
    click.echo(f"    type:    {current.get('type', 'stdio')}")
    if current.get("type") == "http":
        click.echo(f"    url:     {current.get('url') or '(unset)'}")
        hdrs = ", ".join(f"{k}={v}" for k, v in (current.get('headers') or {}).items())
        click.echo(f"    headers: {hdrs or '(none)'}")
    else:
        click.echo(f"    command: {current.get('command') or '(unset)'}")
        click.echo(f"    args:    {' '.join(current.get('args') or []) or '(none)'}")
        env_lines = ", ".join(f"{k}={v}" for k, v in (current.get('env') or {}).items())
        click.echo(f"    env:     {env_lines or '(none)'}")

    new_type = click.prompt("  MCP transport (stdio/http, Enter to keep)",
                            default="", show_default=False).strip().lower()
    if new_type and new_type not in ("stdio", "http"):
        click.echo(f"  Unknown type {new_type!r}, keeping current.")
        new_type = ""

    new_cfg = dict(current)
    if new_type:
        new_cfg["type"] = new_type

    effective_type = new_cfg.get("type", "stdio")

    if effective_type == "http":
        url = click.prompt("  MCP URL (Enter to keep)", default="", show_default=False).strip()
        if url:
            new_cfg["url"] = url
        hdr_str = click.prompt(
            "  MCP headers, KEY=value pairs comma-separated (Enter to keep, '-' to clear)",
            default="", show_default=False,
        ).strip()
        if hdr_str == "-":
            new_cfg["headers"] = {}
        elif hdr_str:
            hdr_dict = {}
            for pair in hdr_str.split(","):
                pair = pair.strip()
                if "=" in pair:
                    k, v = pair.split("=", 1)
                    hdr_dict[k.strip()] = v.strip()
            new_cfg["headers"] = hdr_dict
    else:
        cmd = click.prompt("  MCP command (Enter to keep)", default="", show_default=False).strip()
        args_str = click.prompt(
            "  MCP args, space-separated (Enter to keep)", default="", show_default=False,
        ).strip()
        env_str = click.prompt(
            "  MCP env, KEY=value pairs comma-separated (Enter to keep, '-' to clear)",
            default="", show_default=False,
        ).strip()
        if cmd:
            new_cfg["command"] = cmd
        if args_str:
            new_cfg["args"] = args_str.split()
        if env_str == "-":
            new_cfg["env"] = {}
        elif env_str:
            env_dict = {}
            for pair in env_str.split(","):
                pair = pair.strip()
                if "=" in pair:
                    k, v = pair.split("=", 1)
                    env_dict[k.strip()] = v.strip()
            new_cfg["env"] = env_dict

    if new_type or any(k in current for k in ("url", "headers", "command", "args", "env")):
        config.local_todo_mcp = new_cfg

    config.setup_complete = True
    config.save()

    # Pre-download Whisper model so first meeting doesn't stall
    click.echo("\n  Downloading Whisper transcription model (runs locally, one-time download)...")
    try:
        import certifi, os
        os.environ.setdefault("SSL_CERT_FILE", certifi.where())
        os.environ.setdefault("REQUESTS_CA_BUNDLE", certifi.where())
        from faster_whisper import WhisperModel
        WhisperModel("base", device="cpu", compute_type="int8")
        click.echo("  Whisper model ready.")
    except Exception as exc:
        click.echo(f"  Warning: could not download Whisper model: {exc}")
        click.echo("  Run manually: python3 -c \"from faster_whisper import WhisperModel; WhisperModel('base', device='cpu', compute_type='int8')\"")

    click.echo("\n  Setup complete! Run 'meeting-helper start' to begin.\n")


def _ensure_menubar():
    """Start the menu bar icon if enabled and not already running."""
    config = get_config()
    if not config.show_menubar_icon:
        return

    from meeting_helper.config import MENUBAR_PID_FILE
    if MENUBAR_PID_FILE.exists():
        try:
            pid = int(MENUBAR_PID_FILE.read_text().strip())
            if is_process_running(pid):
                return
        except Exception:
            pass
        MENUBAR_PID_FILE.unlink(missing_ok=True)

    import subprocess
    subprocess.Popen(
        [sys.executable, "-m", "meeting_helper.menubar"],
        start_new_session=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        stdin=subprocess.DEVNULL,
    )


@cli.command()
def gui():
    """Open the desktop GUI (Material Design 3, launches in background)."""
    import subprocess

    _ensure_menubar()

    log_path = Path.home() / ".meeting-helper-gui.log"
    with open(log_path, "a") as log_fh:
        subprocess.Popen(
            [sys.executable, "-m", "meeting_helper.flet_gui"],
            stdout=log_fh,
            stderr=log_fh,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )
    click.echo("GUI launched.")


@cli.command()
def version():
    """Show current version and check/install latest from PyPI."""
    from meeting_helper import __version__
    from meeting_helper.auto_updater import (
        _is_outdated,
        fetch_latest_version,
        is_editable_install,
        upgrade_to_latest,
    )

    click.echo(f"  meeting-helper v{__version__}")

    editable, src_path = is_editable_install()
    if editable:
        click.echo(f"  Editable install (source: {src_path})")
        click.echo("  Skipping auto-update — `pipx upgrade` is a no-op for editable installs.")
        click.echo("  To switch to the released version: pipx install --force meeting-helper")
        return

    click.echo("  Checking for updates…")
    latest = fetch_latest_version()
    if latest is None:
        click.echo("  Could not reach PyPI (see logs).", err=True)
        return

    if not _is_outdated(__version__, latest):
        click.echo(f"  Already on latest version (v{__version__})")
        return

    click.echo(f"  Update available: v{__version__} → v{latest} — installing (retries through PyPI lag)…")
    new_version = upgrade_to_latest(latest, __version__)
    if new_version:
        click.echo(f"  Updated: v{__version__} → v{new_version}")
        click.echo("  Restart Meeting Helper to load the new version.")
    else:
        click.echo(
            "  Update did not take — PyPI may not have propagated the new "
            "wheel yet. Try again in a minute: pipx upgrade meeting-helper",
            err=True,
        )


@cli.command()
def autostart():
    """Install or remove meeting-helper as a login item (auto-start on login)."""
    import subprocess
    plist_dir = Path.home() / "Library" / "LaunchAgents"
    plist_path = plist_dir / "com.meeting-helper.daemon.plist"

    exe = subprocess.run(["which", "meeting-helper"], capture_output=True, text=True).stdout.strip()
    if not exe:
        click.echo("  meeting-helper not found in PATH. Install it first.")
        return

    if plist_path.exists():
        # Already installed — ask to remove
        click.echo(f"  Auto-start is currently ENABLED ({plist_path})")
        if click.confirm("  Disable auto-start?"):
            subprocess.run(["launchctl", "unload", str(plist_path)], capture_output=True)
            plist_path.unlink()
            click.echo("  Auto-start disabled.")
        return

    plist_dir.mkdir(parents=True, exist_ok=True)
    plist_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.meeting-helper.daemon</string>
    <key>ProgramArguments</key>
    <array>
        <string>{exe}</string>
        <string>start</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <false/>
    <key>StandardOutPath</key>
    <string>{LOG_FILE}</string>
    <key>StandardErrorPath</key>
    <string>{LOG_FILE}</string>
</dict>
</plist>"""
    plist_path.write_text(plist_content)
    result = subprocess.run(["launchctl", "load", str(plist_path)], capture_output=True, text=True)
    if result.returncode == 0:
        click.echo(f"  Auto-start enabled. meeting-helper will start automatically on login.")
        click.echo(f"  Run 'meeting-helper autostart' again to disable.")
    else:
        click.echo(f"  Failed to register: {result.stderr.strip()}")


@cli.command()
def logs():
    """Tail the daemon log file."""
    if not LOG_FILE.exists():
        click.echo("No log file found.")
        return

    click.echo(f"Tailing {LOG_FILE}...\n")
    try:
        import subprocess
        subprocess.run(["tail", "-f", "-n", "50", str(LOG_FILE)])
    except KeyboardInterrupt:
        pass


@cli.command()
def menubar():
    """Start the menu bar icon (top bar)."""
    from meeting_helper.menubar import run_menubar
    run_menubar()


@cli.command()
@click.option("--duration", type=int, default=3600, show_default=True,
              help="Seconds to capture the WS event tap + time-series.")
@click.option("--out", "out_dir", type=click.Path(), default=None,
              help="Where to write the bundle (.tar.gz). Default: ~/Desktop.")
@click.option("--quick", is_flag=True,
              help="Snapshot-only mode — skip the timed capture window.")
@click.option("--scrub-text", is_flag=True,
              help="Redact transcript text from WS events + daemon log (timing kept).")
def diag(duration: int, out_dir: str | None, quick: bool, scrub_text: bool):
    """Collect a diagnostic bundle (~/Desktop/mh-diag-<host>-<ts>.tar.gz).

    Start a meeting first, then run `meeting-helper diag` from a second
    terminal — it'll capture system state, daemon state (/health, /provider,
    meta), a CPU/RSS time-series, every WebSocket event the daemon emits
    (with per-role inter-arrival + interim→final stats), a log tail, and
    network probes to Deepgram and your whisper host before+after the run.

    Bundle is meant to be sent to whoever's debugging the issue with you —
    API keys are redacted; use --scrub-text to also drop transcript content.
    """
    from meeting_helper.diag import main as run_diag
    sys.exit(run_diag(duration=duration, out=out_dir,
                      quick=quick, scrub_text=scrub_text))
