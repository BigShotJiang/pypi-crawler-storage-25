"""Retrieve KB cards (📚 meeting summaries + notes) for the current query.

Called from the query handler. Pure local file I/O, no network. Failure
isolated: any exception returns an empty list so the local-todo cards
path is unaffected.
"""

from __future__ import annotations

import asyncio
import logging
import re
from dataclasses import dataclass
from datetime import date as _date
from datetime import datetime as _datetime
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from meeting_helper.config import Config

logger = logging.getLogger(__name__)

# A small, English stopword list. Generic words add no signal and pollute
# the overlap score. Kept private so it can be extended without bumping
# the module's public surface.
_STOPWORDS: frozenset[str] = frozenset({
    "the", "a", "an", "and", "or", "but", "if", "then", "else", "of",
    "to", "in", "on", "at", "by", "for", "with", "without", "from",
    "is", "are", "was", "were", "be", "been", "being", "do", "does",
    "did", "have", "has", "had", "will", "would", "could", "should",
    "can", "may", "might", "this", "that", "these", "those", "it",
    "its", "i", "you", "he", "she", "we", "they", "me", "him", "her",
    "us", "them", "my", "your", "his", "our", "their", "as", "so",
    "not", "no", "yes", "ok", "okay", "just", "than", "about", "into",
    "out", "up", "down", "over", "under", "again", "more", "most",
    "some", "any", "all", "each", "every", "very", "now", "also",
})

_TOKEN_RE = re.compile(r"[A-Za-z0-9]+")


def tokenize(text: str) -> set[str]:
    """Lowercase tokens of length >= 3, with stopwords removed."""
    if not text:
        return set()
    return {
        tok for tok in (m.group().lower() for m in _TOKEN_RE.finditer(text))
        if len(tok) >= 3 and tok not in _STOPWORDS
    }


def score_artifact(*, blob_tokens: set[str], body: str, age_days: float) -> float:
    """Score an artifact body against the query blob's tokens.

    Primary signal: count of distinct token overlaps.
    Secondary signal: a small recency boost — at most `recency_weight` × overlap.
    Zero overlap → zero score (the recency boost cannot rescue an irrelevant doc).
    """
    body_tokens = tokenize(body)
    overlap = len(blob_tokens & body_tokens)
    if overlap == 0:
        return 0.0
    # Recency: linear from 1.0 at age=0 to 0.0 at age>=30 days. Capped to a
    # 20% bonus over the overlap so it never overrides a clearly better
    # content match.
    recency = max(0.0, 1.0 - max(0.0, age_days) / 30.0)
    recency_weight = 0.2 * overlap
    return float(overlap) + recency * recency_weight


@dataclass(frozen=True)
class KbCard:
    """A retrieved KB artifact ready for prompt rendering."""
    id: str          # filename, e.g. "2026-05-03.summary.txt"
    kind: str        # "meeting" | "note"
    title: str
    date: str        # YYYY-MM-DD or "" when unknown
    body: str        # raw text content of the artifact
    score: float


_TIMESTAMP_RE = re.compile(r"^(\d{4}-\d{2}-\d{2})_\d{6}(?:_(.+))?$")


def _parse_meeting_stem(stem: str) -> tuple[str, str]:
    """Return (date, title) parsed from a meeting filename stem.

    Stems look like '2026-05-08_193029' or '2026-05-08_193029_Daily_Standup'.
    Falls back to ('', stem) when the format doesn't match.
    """
    m = _TIMESTAMP_RE.match(stem)
    if not m:
        return "", stem
    date = m.group(1)
    if m.group(2):
        title = m.group(2).replace("_", " ")
    else:
        title = stem  # no human label; show the whole stem so it's still identifiable
    return date, title


def _meeting_stem_from_summary(filename: str) -> str:
    if filename.endswith(".summary.txt"):
        return filename[: -len(".summary.txt")]
    return Path(filename).stem


def _note_title(filename: str) -> str:
    if filename.endswith(".note.md"):
        return filename[: -len(".note.md")].replace("-", " ")
    return Path(filename).stem


def load_artifacts(*, recordings_dir: Path, kb_filenames: list[str]) -> list[KbCard]:
    """Load every KB-flagged artifact from disk into KbCards (without scoring).

    Missing files are silently skipped. Returns an empty list when the
    recordings directory itself is missing.
    """
    if not recordings_dir.is_dir():
        return []
    out: list[KbCard] = []
    for fname in kb_filenames:
        fpath = recordings_dir / fname
        if not fpath.is_file():
            continue
        try:
            body = fpath.read_text(errors="ignore")
        except OSError:
            continue
        if fname.endswith(".summary.txt"):
            stem = _meeting_stem_from_summary(fname)
            date, title = _parse_meeting_stem(stem)
            out.append(KbCard(
                id=fname,
                kind="meeting",
                title=title,
                date=date,
                body=body,
                score=0.0,
            ))
        elif fname.endswith(".note.md"):
            out.append(KbCard(
                id=fname,
                kind="note",
                title=_note_title(fname),
                date="",
                body=body,
                score=0.0,
            ))
        # Anything else → silently skipped
    return out


def _age_days(date_str: str) -> float:
    """Return age in days for a YYYY-MM-DD string. Returns a large value for unparseable input."""
    if not date_str:
        return 365.0  # unknown → treat as a year old (no recency boost)
    try:
        d = _date.fromisoformat(date_str)
    except ValueError:
        return 365.0
    delta = (_date.today() - d).days
    return float(max(0, delta))


def _retrieve_sync(
    *,
    query_text: str,
    self_buffer_text: str,
    other_buffer_text: str,
    recordings_dir: Path,
    kb_filenames: list[str],
    max_results: int,
) -> list[KbCard]:
    """Synchronous core of retrieve_kb_cards. Designed to run in a thread."""
    blob = " ".join(t for t in (query_text, self_buffer_text, other_buffer_text) if t)
    blob_tokens = tokenize(blob)
    if not blob_tokens or not kb_filenames:
        return []

    artifacts = load_artifacts(recordings_dir=recordings_dir, kb_filenames=kb_filenames)
    scored: list[KbCard] = []
    for art in artifacts:
        s = score_artifact(
            blob_tokens=blob_tokens,
            body=art.body,
            age_days=_age_days(art.date),
        )
        if s > 0:
            scored.append(KbCard(
                id=art.id,
                kind=art.kind,
                title=art.title,
                date=art.date,
                body=art.body,
                score=s,
            ))
    scored.sort(key=lambda c: c.score, reverse=True)
    return scored[:max_results]


async def retrieve_kb_cards(
    *,
    query_text: str,
    self_buffer_text: str,
    other_buffer_text: str,
    config: "Config",
) -> list[KbCard]:
    """Top-N KB cards for the current query. Failure-isolated: returns [] on error."""
    try:
        recordings_dir = Path(config.recordings_dir)
        kb_filenames = list(config.kb_artifacts)
        max_results = int(config.kb_max_results)
        return await asyncio.to_thread(
            _retrieve_sync,
            query_text=query_text,
            self_buffer_text=self_buffer_text,
            other_buffer_text=other_buffer_text,
            recordings_dir=recordings_dir,
            kb_filenames=kb_filenames,
            max_results=max_results,
        )
    except Exception as exc:
        logger.warning("retrieve_kb_cards failed: %s", exc, exc_info=True)
        return []


@dataclass(frozen=True)
class LibraryItem:
    """A row in the Library list — either a meeting (with adjacent files) or a note."""
    id: str               # for meetings: the stem (e.g. "2026-05-08_193029"); for notes: the filename
    kind: str             # "meeting" | "note"
    title: str            # human-friendly display name
    date: str             # YYYY-MM-DD or ""
    sort_key: str         # used for newest-first ordering
    has_mp3: bool         # meeting only
    has_live: bool        # meeting only
    has_transcript: bool  # meeting only
    has_summary: bool     # meeting only
    summary_filename: str # meeting only — "" when no summary exists
    note_filename: str    # note only — "" for meetings


def list_artifacts(*, recordings_dir: Path) -> list[LibraryItem]:
    """Scan recordings_dir and return a unified, newest-first list of meetings + notes."""
    if not recordings_dir.is_dir():
        return []

    items: list[LibraryItem] = []

    # --- Meetings (one row per .mp3) ---
    mp3_paths = sorted(recordings_dir.glob("*.mp3"))
    for mp3 in mp3_paths:
        stem = mp3.stem
        date, title = _parse_meeting_stem(stem)
        live_path = mp3.with_suffix(".live.txt")
        transcript_path = mp3.with_suffix(".transcript.txt")
        summary_path = mp3.with_suffix(".summary.txt")
        # sort_key must capture the full timestamp, not just the date —
        # keying on `date` alone collapsed every same-day recording into one
        # bucket, so they fell back to filesystem (oldest-first) order. The
        # stem is `YYYY-MM-DD_HHMMSS[_title]` and sorts correctly lexically;
        # for non-timestamped stems fall back to the mp3's mtime in the same
        # format so it stays comparable.
        if date:
            sort_key = stem
        else:
            try:
                _mtime = mp3.stat().st_mtime
            except OSError:
                _mtime = 0.0
            sort_key = _datetime.fromtimestamp(_mtime).strftime("%Y-%m-%d_%H%M%S")
        items.append(LibraryItem(
            id=stem,
            kind="meeting",
            title=title,
            date=date,
            sort_key=sort_key,
            has_mp3=True,
            has_live=live_path.is_file(),
            has_transcript=transcript_path.is_file(),
            has_summary=summary_path.is_file(),
            summary_filename=summary_path.name if summary_path.is_file() else "",
            note_filename="",
        ))

    # --- Notes (one row per .note.md) ---
    note_paths = sorted(recordings_dir.glob("*.note.md"))
    for note in note_paths:
        try:
            mtime = note.stat().st_mtime
        except OSError:
            mtime = 0.0
        # Use ISO-formatted mtime so the unified sort_key field is comparable
        sort_key = _datetime.fromtimestamp(mtime).strftime("%Y-%m-%d_%H%M%S")
        items.append(LibraryItem(
            id=note.name,
            kind="note",
            title=_note_title(note.name),
            date="",
            sort_key=sort_key,
            has_mp3=False,
            has_live=False,
            has_transcript=False,
            has_summary=False,
            summary_filename="",
            note_filename=note.name,
        ))

    # newest-first
    items.sort(key=lambda i: i.sort_key, reverse=True)
    return items
