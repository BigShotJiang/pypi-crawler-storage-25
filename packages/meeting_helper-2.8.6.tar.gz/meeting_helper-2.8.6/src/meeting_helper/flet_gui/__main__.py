"""Entry point for: python -m meeting_helper.flet_gui"""

import atexit
import os
import sys

from meeting_helper.config import GUI_PID_FILE, get_config
from meeting_helper.flet_gui.app import run_flet_gui

# Fix SSL certificate verification for Flet client download.
# Homebrew Python on macOS does not ship CA certs and certifi's bundle
# is not picked up by Python 3.14's ssl module. Since the only HTTPS
# call at this stage is downloading the public Flet client from GitHub
# Releases, skip verification entirely.
import ssl
import urllib.request

_ctx = ssl._create_unverified_context()
urllib.request.install_opener(
    urllib.request.build_opener(urllib.request.HTTPSHandler(context=_ctx))
)


def _is_running(pid: int) -> bool:
    """True iff the given pid is alive. Mirrors menubar._is_running."""
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, PermissionError):
        return False
    except OSError:
        return False


def _enforce_single_instance() -> None:
    """Refuse to start a second GUI when one is already running.

    Writes our own PID to GUI_PID_FILE on success; cleans up on exit.
    Without this guard, clicking 'Open Dashboard' from the menubar (or
    `meeting-helper gui` from the shell) while a GUI is already up
    spawns a duplicate window instead of focusing the existing one.
    """
    if GUI_PID_FILE.exists():
        try:
            existing_pid = int(GUI_PID_FILE.read_text().strip())
        except (ValueError, OSError):
            existing_pid = -1
        if existing_pid > 0 and existing_pid != os.getpid() and _is_running(existing_pid):
            try:
                from AppKit import NSWorkspace  # type: ignore

                for app in NSWorkspace.sharedWorkspace().runningApplications():
                    name = (app.localizedName() or "")
                    bid = (app.bundleIdentifier() or "")
                    if "Flet" in name or "Meeting Helper" in name or "flet" in bid:
                        app.activateWithOptions_(1 << 1)
                        break
            except Exception:
                pass
            print(
                f"Meeting Helper GUI is already running (pid={existing_pid}); focusing it.",
                file=sys.stderr,
            )
            sys.exit(0)

    try:
        GUI_PID_FILE.write_text(str(os.getpid()))
    except OSError:
        pass

    def _cleanup() -> None:
        try:
            if GUI_PID_FILE.exists():
                pid = int(GUI_PID_FILE.read_text().strip() or "0")
                if pid == os.getpid():
                    GUI_PID_FILE.unlink()
        except Exception:
            pass

    atexit.register(_cleanup)


_enforce_single_instance()
run_flet_gui(get_config())
