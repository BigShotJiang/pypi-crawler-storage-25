"""Copilot screen — during-meeting surface (toolbar, topic, conversation, tasks)."""

from __future__ import annotations

import asyncio
import json
import logging
import threading
import time
import urllib.error
import urllib.request
from typing import TYPE_CHECKING, Optional

import websockets

import flet as ft

logger = logging.getLogger(__name__)

from meeting_helper.flet_gui.components.conversation import (
    ConversationThread,
    ConversationView,
)
from meeting_helper.flet_gui.components.pill import Pill, PillOption
from meeting_helper.flet_gui.components.tasks_panel import TasksPanel
from meeting_helper.flet_gui.components.topics_panel import TopicsPanel
from meeting_helper.flet_gui.components.topic_strip import TopicStrip

if TYPE_CHECKING:
    from meeting_helper.config import Config

TEAL = "#4ec9b0"
ERROR_RED = "#f14c4c"

_PROVIDER_OPTIONS = [
    PillOption(key="claude", label="Claude"),
    PillOption(key="gemini", label="Gemini"),
    PillOption(key="local", label="Ollama (Free)"),
]

_TRANSCRIBER_OPTIONS = [
    PillOption(key="whisper", label="Whisper (Free)"),
    PillOption(key="deepgram", label="Deepgram"),
]

# Labels lead with a velocity hint (Fastest / Fast / Balanced / Slow) and
# carry the model version, so the toolbar pill shows what you're actually on.
_MODEL_OPTIONS_BY_PROVIDER: dict[str, list[PillOption]] = {
    "claude": [
        PillOption(key="sonnet", label="Balanced · Sonnet 4.6"),
        PillOption(key="opus", label="Slow · Opus 4.6"),
        PillOption(key="haiku", label="Fast · Haiku 4.5"),
    ],
    "gemini": [
        PillOption(key="flash", label="Fast · Flash 2.5"),
        PillOption(key="flash-lite", label="Fastest · Flash Lite 2.5"),
        PillOption(key="flash-3", label="Fast · Flash 3"),
        PillOption(key="pro", label="Slow · Pro 2.5"),
    ],
    "local": [],
}

_PROVIDER_TO_MODEL_KEY = {
    "claude": "claude_model",
    "gemini": "gemini_model",
    "local": "local_model",
}


class CopilotScreen(ft.Column):
    def __init__(self, page: ft.Page, config: "Config") -> None:
        super().__init__(expand=True, spacing=0)
        self._page = page
        self._config = config
        self._port = config.port
        self._daemon_running = False
        self._session_active = False
        self._syncing_provider = False

        # Lifecycle:
        # - _stop_event: hard kill — set on dispose() (workspace change, app
        #   exit). All background loops exit and threads are joinable.
        # - _is_active: soft "is this screen the one shown right now". When
        #   false, polling loops still tick (so on_activate finds fresh data
        #   immediately) but widget mutations are skipped — no page.update()
        #   on a screen the user can't see, no thread-safety drama.
        self._stop_event = threading.Event()
        self._is_active = True
        # Track the canonical current provider/transcriber so model-pill
        # selections don't have to guess from display labels (they used to
        # infer the provider from `self._provider_pill.label`, which lagged
        # the actual state and produced invalid combos like Claude+Flash).
        self._current_provider: str = "claude"
        self._current_transcriber: str = "whisper"
        # Suppress provider polling for this many seconds after a user click,
        # so the periodic /provider GET doesn't overwrite the user's just-made
        # selection while the daemon is still processing the POST.
        self._provider_poll_suppressed_until: float = 0.0
        self._PROVIDER_POLL_SUPPRESS_SEC = 5.0
        # Workspace readiness flags (filled by /provider polling). Optimistic
        # defaults match how the daemon used to behave before these flags
        # existed — controls show until we hear otherwise.
        self._local_todo_configured: bool = True
        self._provider_configured: bool = True

        # ---------------- toolbar ----------------
        # A small colour-coded dot is the only persistent status indicator in
        # the toolbar — the Start/Stop button already conveys most of the state,
        # so the old "Recording: …" text label was removed. `_status_text` is
        # kept as a hidden bookkeeping widget (lots of code still writes to it);
        # its value is mirrored into the dot's tooltip so it's available on hover.
        self._status_icon = ft.Icon(
            ft.Icons.CIRCLE, color=ft.Colors.OUTLINE, size=12, tooltip="Stopped",
        )
        self._status_text = ft.Text("Stopped", size=12, color=ft.Colors.ON_SURFACE_VARIANT)

        # Engagement (Hot Moment) indicator — sits next to the recording status pill.
        self._engagement_dot = ft.Icon(
            ft.Icons.RADIO_BUTTON_UNCHECKED,
            color=ft.Colors.OUTLINE,
            size=10,
        )
        self._engagement_text = ft.Text(
            "Idle",
            size=12,
            color=ft.Colors.ON_SURFACE_VARIANT,
        )
        self._engagement_pill = ft.Container(
            content=ft.Row(
                [self._engagement_dot, self._engagement_text],
                spacing=4,
                tight=True,
            ),
            tooltip="Idle — listening to mic only. Speak or send a query to engage.",
            padding=ft.Padding.symmetric(horizontal=8, vertical=2),
            border=ft.Border.all(1, ft.Colors.OUTLINE_VARIANT),
            border_radius=10,
            visible=False,
            ink=True,
            on_click=lambda _e: self._on_engagement_pill_click(),
        )
        # Hot Moment countdown state. Updated by `_set_engagement` and a
        # per-second ticker thread launched in `_ensure_countdown_ticker`.
        self._engagement_until_wallclock: float = 0.0
        self._engagement_ticker_running: bool = False

        self._session_btn = ft.IconButton(
            icon=ft.Icons.FIBER_MANUAL_RECORD,
            icon_color="#238636",
            tooltip="Start recording",
            on_click=self._on_session_toggle,
        )

        # Read-only display chips — the active transcriber / AI provider / model.
        # These are changed only in Settings now (the daemon applies the change
        # live); the toolbar just reflects what the daemon reports, refreshed by
        # `_poll_provider` every ~3 s — same cadence as the resource chip.
        self._transcriber_pill = Pill(label="Whisper", read_only=True)
        self._provider_pill = Pill(label="Claude", read_only=True)
        self._model_pill = Pill(label="Balanced · Sonnet 4.6", read_only=True)

        self._brief_btn_label = ft.Text("Brief", color="white", weight=ft.FontWeight.W_500)
        self._brief_btn = ft.ElevatedButton(
            content=self._brief_btn_label,
            icon=ft.Icons.DESCRIPTION,
            bgcolor="#1f6feb",
            color="white",
            tooltip="Generate Brief",
            on_click=self._on_brief_clicked,
        )
        self._clear_btn = ft.IconButton(
            icon=ft.Icons.DELETE_OUTLINE,
            tooltip="Clear conversation",
            on_click=self._on_clear_clicked,
        )
        self._autoscroll_btn = ft.IconButton(
            icon=ft.Icons.VERTICAL_ALIGN_BOTTOM,
            icon_color=TEAL,
            tooltip="Auto-scroll on (following bottom)",
            on_click=self._on_autoscroll_clicked,
        )

        # Live counters — totals only, displayed as a compact pill that sits
        # in the *left* group (after the model pill) so the right-side action
        # buttons don't shift. Tooltip shows per-kind breakdown for debugging.
        self._ai_count_text = ft.Text(
            "0", size=11, color=ft.Colors.ON_SURFACE_VARIANT, no_wrap=True,
        )
        self._todo_count_text = ft.Text(
            "0", size=11, color=ft.Colors.ON_SURFACE_VARIANT, no_wrap=True,
        )
        self._stats_pill = ft.Container(
            content=ft.Row(
                [
                    ft.Icon(ft.Icons.AUTO_AWESOME, size=12, color=ft.Colors.ON_SURFACE_VARIANT),
                    self._ai_count_text,
                    ft.Container(width=4),
                    ft.Icon(ft.Icons.CHECKLIST, size=12, color=ft.Colors.ON_SURFACE_VARIANT),
                    self._todo_count_text,
                ],
                spacing=4,
                tight=True,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            tooltip="AI calls · local-todo calls (this meeting)",
            padding=ft.Padding.symmetric(horizontal=10, vertical=4),
            border=ft.Border.all(1, ft.Colors.OUTLINE_VARIANT),
            border_radius=999,
            visible=False,
        )

        # Daemon health pill — compact: <speed icon> <age> · <cpu>% · <rss> MB
        # plus a loop-status dot (green = OK, amber = lagging). The verbose
        # breakdown (kind of last call, host CPU, exact lag, restart hint when
        # degraded) lives in the pill's tooltip. Styled to match _stats_pill so
        # the toolbar reads as a row of consistent chips, not bare debug text.
        # Hidden outside an active meeting (same visibility as _stats_pill).
        self._health_icon = ft.Icon(
            ft.Icons.SPEED, size=12, color=ft.Colors.ON_SURFACE_VARIANT,
        )
        self._health_text = ft.Text(
            "—", size=11, color=ft.Colors.ON_SURFACE_VARIANT, no_wrap=True,
        )
        self._health_dot = ft.Icon(ft.Icons.CIRCLE, size=8, color="#3fb950")
        self._health_pill = ft.Container(
            content=ft.Row(
                [self._health_icon, self._health_text, self._health_dot],
                spacing=6,
                tight=True,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            tooltip="Daemon health",
            padding=ft.Padding.symmetric(horizontal=10, vertical=4),
            border=ft.Border.all(1, ft.Colors.OUTLINE_VARIANT),
            border_radius=999,
            visible=False,
        )

        # Phase 4d's overflow menu (PopupMenuButton with stats/clear/autoscroll
        # tucked inside) was reverted — the user preferred seeing the buttons
        # directly. Original toolbar layout restored. Kept _overflow_btn as
        # an invisible placeholder so the rest of the code (update_status
        # references it) stays untouched.
        self._overflow_btn = ft.Container(visible=False)

        toolbar = ft.Container(
            content=ft.Row(
                [
                    self._status_icon,
                    self._session_btn,
                    self._engagement_pill,
                    ft.Container(width=4),
                    self._transcriber_pill,
                    self._provider_pill,
                    self._model_pill,
                    self._stats_pill,
                    self._health_pill,
                    ft.Container(expand=True),
                    self._brief_btn,
                    self._autoscroll_btn,
                    self._clear_btn,
                ],
                spacing=8,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.symmetric(horizontal=16, vertical=8),
            bgcolor=ft.Colors.SURFACE_CONTAINER_HIGH,
        )

        # ---------------- topic strip ----------------
        self._topic_strip = TopicStrip(on_explain=self._on_explain_topic)
        self._topic_strip_container = ft.Container(
            content=self._topic_strip,
            padding=ft.Padding.symmetric(horizontal=16, vertical=8),
            border=ft.Border.only(bottom=ft.BorderSide(1, ft.Colors.OUTLINE_VARIANT)),
            visible=False,  # only shown during an active meeting
        )

        # ---------------- conversation + tasks panel ----------------
        self._thread = ConversationThread()
        self._view = ConversationView(
            self._thread,
            on_following_changed=self._on_view_following_changed,
        )

        self._tasks_panel = TasksPanel(title="Tasks")
        self._extract_btn_label = ft.Text("Extract Task", color="white", weight=ft.FontWeight.W_500)
        self._extract_btn = ft.ElevatedButton(
            content=self._extract_btn_label,
            icon=ft.Icons.ADD_TASK,
            bgcolor="#1f6feb",
            color="white",
            on_click=self._on_extract_task,
        )

        # Topics panel: clickable list of active-sprint topics. Click pins
        # the topic for the conversation (POST /topic/set on the daemon).
        self._topics_panel = TopicsPanel(
            title="Topics",
            on_pick=self._on_topic_pick,
            on_indicator_click=self._on_topic_indicator_toggle,
        )

        # Right-pane tabs: Topics | Tasks. Flet 0.80+ ft.Tabs split into
        # TabBar + TabBarView, which is overkill for two tabs. Roll a
        # tiny manual tab strip: two text buttons + a content container
        # that swaps on click. Same UX, no API drama.
        self._tab_topics_content = ft.Container(
            content=self._topics_panel,
            padding=ft.Padding.symmetric(horizontal=8, vertical=4),
            expand=True,
            visible=True,
        )
        self._tab_tasks_content = ft.Container(
            content=ft.Column(
                [self._extract_btn, self._tasks_panel],
                spacing=10,
                expand=True,
            ),
            padding=ft.Padding.symmetric(horizontal=8, vertical=4),
            expand=True,
            visible=False,
        )

        def _tab_button(label: str, key: str) -> ft.Container:
            txt = ft.Text(label, size=13, weight=ft.FontWeight.W_600)
            container = ft.Container(
                content=txt,
                padding=ft.Padding.symmetric(horizontal=14, vertical=8),
                ink=True,
                on_click=lambda _e, k=key: self._on_right_tab_click(k),
                data=key,
            )
            return container

        self._tab_btn_topics = _tab_button("Topics", "topics")
        self._tab_btn_tasks = _tab_button("Tasks", "tasks")

        self._right_tab_strip = ft.Container(
            content=ft.Row(
                [self._tab_btn_topics, self._tab_btn_tasks],
                spacing=0,
                tight=True,
            ),
            border=ft.Border.only(bottom=ft.BorderSide(1, ft.Colors.OUTLINE_VARIANT)),
        )
        self._active_right_tab: str = "topics"
        # Apply initial styling.
        self._sync_right_tab_styling()

        self._tasks_pane = ft.Container(
            content=ft.Column(
                [
                    self._right_tab_strip,
                    ft.Stack(
                        [self._tab_topics_content, self._tab_tasks_content],
                        expand=True,
                    ),
                ],
                spacing=0,
                expand=True,
            ),
            width=300,
            padding=ft.Padding.symmetric(horizontal=0, vertical=0),
            border=ft.Border.only(left=ft.BorderSide(1, ft.Colors.OUTLINE_VARIANT)),
        )

        # ---------------- live caption bar (interim transcripts) ----------------
        # The footer where you SEE the meeting in real time. Deepgram fires
        # growing-prefix interims ~50 ms apart; without this bar users wait
        # 1-3 s for is_final and miss the cadence of conversation.
        #
        # Round-2 UX revision (this file's history was: dynamic-visible bottom
        # bar → sticky-top conversation column → fixed-height footer with
        # italic gray text → THIS): role-tinted text in solid weight so the
        # bar is the visual anchor of a live meeting. Italic gray was the
        # lowest-priority Material treatment for what should be the
        # highest-priority signal during a call.
        from meeting_helper.flet_gui.components.conversation import (
            SELF_BORDER, OTHER_BORDER,
        )
        # Role-tinted interim text. The role label sits in a fixed-width
        # Container next to it so "You"/"Other" both pin-align regardless
        # of the proportional font's character widths. Earlier draft used
        # multiple literal spaces ("You    {text}") which Flutter does
        # render but doesn't actually align across rows because "You" and
        # "Other" are different pixel widths.
        self._self_interim_text = ft.Text(
            "", size=14, color=SELF_BORDER, weight=ft.FontWeight.W_500,
            no_wrap=True, max_lines=1, overflow=ft.TextOverflow.ELLIPSIS,
            expand=True,
        )
        self._other_interim_text = ft.Text(
            "", size=14, color=OTHER_BORDER, weight=ft.FontWeight.W_500,
            no_wrap=True, max_lines=1, overflow=ft.TextOverflow.ELLIPSIS,
            expand=True,
        )
        self._self_interim_label = ft.Container(
            content=ft.Text(
                "You", size=11, weight=ft.FontWeight.W_700,
                color=SELF_BORDER,
            ),
            width=48,
        )
        self._other_interim_label = ft.Container(
            content=ft.Text(
                "Other", size=11, weight=ft.FontWeight.W_700,
                color=OTHER_BORDER,
            ),
            width=48,
        )
        self._self_interim_row = ft.Row(
            [self._self_interim_label, self._self_interim_text],
            spacing=8,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            tight=True,
        )
        self._other_interim_row = ft.Row(
            [self._other_interim_label, self._other_interim_text],
            spacing=8,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            tight=True,
        )
        # Fixed-height so the conversation above never reflows when interims
        # appear/disappear. Hidden outside meetings (no captions to show
        # then anyway).
        self._live_caption_bar = ft.Container(
            content=ft.Column(
                [self._self_interim_row, self._other_interim_row],
                spacing=2,
                tight=True,
            ),
            padding=ft.Padding.symmetric(horizontal=16, vertical=6),
            bgcolor=ft.Colors.SURFACE_CONTAINER,
            border=ft.Border.only(top=ft.BorderSide(1, ft.Colors.OUTLINE_VARIANT)),
            height=52,
            visible=False,  # gated on session_active in update_status
        )

        body_row = ft.Row(
            [
                ft.Container(
                    content=self._view,
                    expand=True,
                    padding=ft.Padding.symmetric(horizontal=16, vertical=10),
                ),
                self._tasks_pane,
            ],
            expand=True,
            spacing=0,
        )

        # ---------------- ask AI input ----------------
        self._query_input = ft.TextField(
            hint_text="Ask AI…  (Enter to send)",
            dense=True,
            border_radius=8,
            text_size=13,
            on_submit=self._on_send,
            expand=True,
        )
        self._send_btn = ft.ElevatedButton(
            "➤ Send",
            on_click=self._on_send,
        )
        # Renamed from icon-only sparkle button: users were hitting Send when
        # they meant Trigger or vice-versa because they were equal weight.
        # Text label "From context" disambiguates intent; secondary visual
        # weight (TextButton not Elevated) puts Send as the obvious primary.
        self._trigger_btn = ft.TextButton(
            content=ft.Row(
                [
                    ft.Icon(ft.Icons.AUTO_AWESOME, color=TEAL, size=16),
                    ft.Text("From context", color=TEAL, size=13),
                ],
                spacing=4,
                tight=True,
            ),
            tooltip="Ask AI from current meeting context (same as 2×Cmd)",
            on_click=self._on_trigger_query,
        )
        self._ask_claude_row = ft.Container(
            content=ft.Row(
                [self._query_input, self._trigger_btn, self._send_btn],
                spacing=8,
            ),
            padding=ft.Padding.symmetric(horizontal=16, vertical=10),
            bgcolor=ft.Colors.SURFACE_CONTAINER_HIGH,
        )

        # ---------------- empty state (daemon down) ----------------
        # `_start_pending_until` keeps the button in a "Starting…" state
        # for a few seconds after click so the 3 s health poll doesn't
        # flicker the label back to "Start" before the daemon binds.
        self._start_pending_until: float = 0.0

        self._start_button = ft.FilledButton(
            "Start",
            icon=ft.Icons.PLAY_ARROW,
            on_click=self._on_start_click,
        )

        self._empty_state = ft.Container(
            content=ft.Column(
                [
                    ft.Icon(ft.Icons.AUTO_AWESOME, size=48, color=ft.Colors.OUTLINE),
                    ft.Text("Daemon not running", size=18, weight=ft.FontWeight.W_600),
                    self._start_button,
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=14,
            ),
            alignment=ft.Alignment(0, 0),
            expand=True,
        )

        self._live_body = ft.Column(
            # Caption bar is a fixed-height footer between body and input.
            # Always rendered so the conversation never reflows around it.
            [self._topic_strip_container, body_row, self._live_caption_bar, self._ask_claude_row],
            spacing=0,
            expand=True,
        )

        self._content_stack = ft.Container(content=self._live_body, expand=True)
        self._toolbar_container = toolbar
        self.controls = [toolbar, self._content_stack]

        self._start_provider_polling()
        self._page.run_thread(self._seed_topic)
        self._start_ws_subscription()
        self._start_tasks_polling()
        self._start_stats_polling()
        self._start_topics_polling()

    # ------------------------------------------------ public lifecycle

    def update_status(self, daemon_running: bool, session_active: bool, meeting_name: str) -> None:
        was_session_active = self._session_active
        self._daemon_running = daemon_running
        self._session_active = session_active
        if session_active:
            self._status_icon.color = ERROR_RED
            self._status_text.value = f"Recording: {meeting_name}" if meeting_name else "Recording"
            self._status_text.color = ERROR_RED
            self._session_btn.icon = ft.Icons.STOP
            self._session_btn.icon_color = ERROR_RED
            self._session_btn.tooltip = "Stop recording"
            self._session_btn.visible = True
        elif daemon_running:
            self._status_icon.color = TEAL
            self._status_text.value = "Ready"
            self._status_text.color = TEAL
            self._session_btn.icon = ft.Icons.FIBER_MANUAL_RECORD
            self._session_btn.icon_color = "#238636"
            self._session_btn.tooltip = "Start recording"
            self._session_btn.visible = True
        else:
            self._status_icon.color = ft.Colors.OUTLINE
            self._status_text.value = "Stopped"
            self._status_text.color = ft.Colors.ON_SURFACE_VARIANT
            self._session_btn.visible = False
        # The status text label was removed from the toolbar; surface it on the
        # dot's tooltip instead so the info is still one hover away.
        self._status_icon.tooltip = self._status_text.value

        # In-meeting actions are hidden entirely when no meeting is active.
        # Brief, Auto-scroll, Clear and Extract Task have no meaning outside
        # a live session — no transcript, no conversation, no warm cards.
        in_meeting = session_active
        # Extract and Trigger also need an AI provider — readiness gates them
        # below, but compose both conditions here so a stale earlier paint
        # doesn't briefly show them when AI is unconfigured.
        self._extract_btn.visible = in_meeting and self._provider_configured
        self._autoscroll_btn.visible = in_meeting
        self._clear_btn.visible = in_meeting
        self._trigger_btn.visible = in_meeting and self._provider_configured
        self._stats_pill.visible = in_meeting
        self._health_pill.visible = in_meeting
        self._topic_strip_container.visible = in_meeting
        # Caption bar gated on meeting activity — outside a meeting it's
        # just dead chrome.
        self._live_caption_bar.visible = in_meeting

        # If a meeting just ended, wipe per-meeting state so the GUI doesn't
        # dangle (topic banner, tasks list, engagement countdown, conversation,
        # AND the Topics tab list — sprint cards from the just-finished
        # session aren't relevant once you've stopped, and the active-card
        # highlight should clear with the topic banner).
        if was_session_active and not session_active:
            self._reset_for_new_meeting()
            try:
                self._topics_panel.set_topics([])
                self._topics_panel.set_active_ticket("")
            except Exception as exc:
                logger.debug("topics clear-on-stop: %s", exc)

        # Toggle empty state: when daemon is down, replace the whole body.
        if daemon_running:
            if self._content_stack.content is self._empty_state:
                self._content_stack.content = self._live_body
            self._start_pending_until = 0.0
        else:
            self._content_stack.content = self._empty_state
            if time.monotonic() < self._start_pending_until:
                self._start_button.disabled = True
                self._start_button.content = "Starting…"
            else:
                self._start_button.disabled = False
                self._start_button.content = "Start"

        # Engagement pill follows the same daemon-down hide rule as the session button.
        self._engagement_pill.visible = daemon_running
        # Re-apply readiness gates last so AI/MCP visibility wins over any
        # earlier ungated assignment in this method (e.g. _engagement_pill).
        self._apply_readiness_visibility()

        # Skip the global page repaint when the user isn't on this tab —
        # update_status fires on a 3 s polling tick from the app shell, so
        # repainting Recordings/Settings every 3 s purely to refresh the
        # invisible Copilot toolbar wastes Flet IPC bandwidth and competes
        # with whatever the user IS looking at. Widget state still updates
        # in-memory so on_activate() finds it ready.
        if not self._is_active:
            return

        try:
            self._page.update()
        except Exception as exc:
            logger.debug("update_status: page.update() failed: %s", exc)

    # ---------------- daemon Start button ----------------

    def _cli_path(self) -> str:
        import shutil
        import sys
        from pathlib import Path
        p = Path(sys.executable).parent / "meeting-helper"
        if p.exists():
            return str(p)
        return shutil.which("meeting-helper") or "meeting-helper"

    def _on_start_click(self, _e) -> None:
        import subprocess
        self._start_pending_until = time.monotonic() + 8.0
        self._start_button.disabled = True
        self._start_button.content = "Starting…"
        try:
            self._page.update()
        except Exception:
            pass
        try:
            subprocess.Popen(
                [self._cli_path(), "start"],
                start_new_session=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
            )
        except Exception as exc:
            logger.warning("Manual daemon start failed: %s", exc)
            self._start_pending_until = 0.0
            self._start_button.disabled = False
            self._start_button.content = "Start"
            try:
                sb = ft.SnackBar(content=ft.Text(f"Start failed: {exc}"))
                self._page.overlay.append(sb)
                sb.open = True
                self._page.update()
            except Exception:
                pass

    def _reset_for_new_meeting(self) -> None:
        """Wipe per-meeting state — topic banner, tasks panel, engagement
        countdown, conversation thread. Called when a meeting ends so the GUI
        doesn't dangle stale content from the previous meeting.
        """
        # Conversation
        self._thread.clear()
        self._view.notify_cleared()
        self._view.force_follow()
        # Topic banner — full clear (current + history)
        self._topic_strip.clear()
        # Tasks panel
        self._tasks_panel.set_tasks([])
        # Engagement pill — also reset the ticker flag so the next meeting
        # can start the countdown again. Without this, a tab switch during
        # an active engagement countdown left _engagement_ticker_running=True
        # forever (the ticker thread saw a torn-down widget, raised silently,
        # never reset the flag), and the next session's ticker never started.
        self._set_engagement(False, 0.0)
        self._engagement_ticker_running = False
        self._engagement_until_wallclock = 0.0
        # Live caption bar — wipe stale interim too. Same reasoning as the
        # WS reconnect reset: an interrupted utterance leaves the last
        # interim sticking forever.
        self._reset_live_captions()

    def _set_engagement(self, active: bool, until_wallclock: float = 0.0) -> None:
        """Update the Engagement pill icon, label, color, and tooltip.

        When ``active`` is True and ``until_wallclock > 0``, also kick off a
        per-second countdown ticker that updates the label like
        ``Active · 9:54`` and locally flips to Idle when the timer expires
        (so the UI reflects the transition without waiting for the next
        daemon ticker tick).
        """
        # Cancel any in-flight countdown ticker — we'll restart if still active.
        self._engagement_until_wallclock = until_wallclock if active else 0.0

        if active:
            self._engagement_dot.name = ft.Icons.CIRCLE
            self._engagement_dot.color = TEAL
            self._engagement_text.color = TEAL
            self._engagement_pill.tooltip = (
                "Engaged — TopicWorker is listening to both you and others."
            )
            self._refresh_engagement_label()
            self._ensure_countdown_ticker()
        else:
            self._engagement_dot.name = ft.Icons.RADIO_BUTTON_UNCHECKED
            self._engagement_dot.color = ft.Colors.OUTLINE
            self._engagement_text.value = "Idle"
            self._engagement_text.color = ft.Colors.ON_SURFACE_VARIANT
            self._engagement_pill.tooltip = (
                "Idle — listening to mic only. Speak or send a query to engage."
            )

    def _refresh_engagement_label(self) -> None:
        """Recompute the `Active · M:SS` label from the current `until_wallclock`."""
        import time as _time
        if self._engagement_until_wallclock <= 0:
            self._engagement_text.value = "Active"
            return
        secs = int(round(self._engagement_until_wallclock - _time.time()))
        if secs <= 0:
            # Expired locally — flip to Idle visually. The daemon's ticker
            # will confirm with an engagement_status event shortly.
            self._engagement_until_wallclock = 0.0
            self._engagement_dot.name = ft.Icons.RADIO_BUTTON_UNCHECKED
            self._engagement_dot.color = ft.Colors.OUTLINE
            self._engagement_text.value = "Idle"
            self._engagement_text.color = ft.Colors.ON_SURFACE_VARIANT
            self._engagement_pill.tooltip = (
                "Idle — listening to mic only. Speak or send a query to engage."
            )
            return
        m, s = divmod(secs, 60)
        self._engagement_text.value = f"Active · {m}:{s:02d}"

    def _ensure_countdown_ticker(self) -> None:
        """Start the per-second ticker if not already running."""
        if self._engagement_ticker_running:
            return
        self._engagement_ticker_running = True

        def _tick() -> None:
            import threading as _threading
            while self._engagement_until_wallclock > 0:
                _threading.Event().wait(1.0)
                self._refresh_engagement_label()
                try:
                    self._engagement_text.update()
                except Exception:
                    pass
            self._engagement_ticker_running = False

        self._page.run_thread(_tick)

    def _on_topic_indicator_toggle(self) -> None:
        """Click on AUTO/MANUAL pill → flip mode in either direction.

        AUTO → MANUAL: POST /topic/manual (stops auto-picking, current topic stays)
        MANUAL → AUTO: POST /topic/auto (clears the pin and resumes auto-picking)
        """
        target_path = "/topic/auto" if self._topics_panel.is_manual() else "/topic/manual"

        def _do() -> None:
            try:
                req = urllib.request.Request(
                    f"http://127.0.0.1:{self._port}{target_path}",
                    data=b"{}",
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                urllib.request.urlopen(req, timeout=5)
            except Exception:
                logger.debug("indicator toggle POST %s failed", target_path, exc_info=True)
        self._page.run_thread(_do)

        # Optimistic UI flip — daemon WS broadcast is canonical, but flipping
        # the pill now feels snappier.
        try:
            self._topics_panel.set_indicator(manual=(target_path == "/topic/manual"))
        except Exception:
            pass

    def _on_engagement_pill_click(self) -> None:
        """Click engagement pill → disarm the current hot moment.

        No-op when not currently in a hot moment (the pill shows "Idle"
        and clicking it shouldn't accidentally fire a network call).
        """
        # Only act when active; check the visible label.
        label = (self._engagement_text.value or "").strip()
        if label.lower().startswith("idle"):
            return

        def _do() -> None:
            try:
                req = urllib.request.Request(
                    f"http://127.0.0.1:{self._port}/hot_moment/cancel",
                    data=b"{}",
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                urllib.request.urlopen(req, timeout=5)
            except Exception:
                logger.debug("hot_moment/cancel POST failed", exc_info=True)
        self._page.run_thread(_do)

        # Optimistic UI: flip to Idle immediately. WS broadcast will confirm.
        try:
            self._set_engagement(False, 0.0)
        except Exception:
            pass

    def on_activate(self) -> None:
        # Force a provider sync the moment the user opens the screen.
        self._is_active = True
        self._page.run_thread(self._poll_provider)
        # Clear any stale interim text from before the user came back —
        # otherwise the bar shows the LAST interim from before the tab
        # switch, which can be 30+ seconds old.
        self._reset_live_captions()
        logger.debug("CopilotScreen activated")

    def on_deactivate(self) -> None:
        # Soft-suspend: polling loops keep ticking (to find fresh data on
        # next activate) but widget mutations are gated on _is_active so
        # we don't hammer page.update() on a tab the user can't see.
        self._is_active = False
        logger.debug("CopilotScreen deactivated")

    def dispose(self) -> None:
        # Hard kill — stop all background loops permanently. Called by
        # app.py on workspace change and at app teardown. Without this,
        # background polls survived workspace switches and wrote into
        # stale widgets, eventually firing "page is not on the page" errors
        # buried under bare-except handlers.
        logger.info("CopilotScreen.dispose — stopping background loops")
        self._stop_event.set()
        self._is_active = False

    def on_workspace_changed(self) -> None:
        from meeting_helper.config import get_config
        self.config = get_config()
        # Rebind websocket loop to the new daemon port (next reconnect picks it up)
        self._port = self.config.port
        # Clear conversation, brief, topic, sources panels so we don't show
        # state from the previous workspace.
        reset = getattr(self, "_reset_for_new_meeting", None)
        if callable(reset):
            reset()
        try:
            self.update()
        except Exception:
            pass

    # ------------------------------------------------ provider syncing

    def _start_provider_polling(self) -> None:
        def _poll() -> None:
            # Loop checks _stop_event each tick so dispose() exits within ~3s.
            # _stop_event.wait(3) is interruptible — stop() returns immediately.
            while not self._stop_event.is_set():
                try:
                    self._poll_provider()
                except Exception as exc:
                    logger.warning("provider poll iteration failed: %s", exc)
                if self._stop_event.wait(3):
                    return

        self._page.run_thread(_poll)

    # ------------------------------------------------ stats polling
    #
    # Polls /health every 3s for AI + local-todo call counters and renders
    # a compact summary in the toolbar. Hidden outside an active meeting
    # (counters reset on session start).

    def _start_stats_polling(self) -> None:
        def _poll() -> None:
            while not self._stop_event.is_set():
                try:
                    self._poll_stats()
                except Exception as exc:
                    logger.warning("stats poll iteration failed: %s", exc)
                if self._stop_event.wait(3):
                    return

        self._page.run_thread(_poll)

    @staticmethod
    def _format_health_line(h: dict) -> tuple[str, bool]:
        """Build the compact health-pill text + a "degraded" flag from a
        ``/health`` "health" block.

        Returns ``(text, degraded)`` — e.g. ``("8s · 31% · 412 MB", False)``.
        ``text`` is ``"—"`` when no metrics are available yet. ``degraded`` is
        True when a query has been in flight >15 s or the event loop is lagging
        (≥500 ms); the caller turns the status dot / pill border / icon amber.
        Loop status itself is shown as the trailing dot (and spelled out in the
        pill tooltip), so it is intentionally not part of this text. Pure
        function, no side effects.
        """
        age = h.get("last_ai_call_age_sec")
        cpu = h.get("cpu_percent")
        rss = h.get("rss_mb")
        lag = h.get("event_loop_lag_ms") or 0.0
        aq = bool(h.get("active_query"))
        aq_age = h.get("active_query_age_sec") or 0.0

        parts: list[str] = []
        if isinstance(age, (int, float)):
            parts.append(f"{int(age)}s")
        if isinstance(cpu, (int, float)):
            parts.append(f"{cpu:.0f}%")
        if isinstance(rss, (int, float)):
            parts.append(f"{rss:.0f} MB")
        text = " · ".join(parts) if parts else "—"
        degraded = (aq and aq_age > 15) or (lag >= 500)
        return text, degraded

    def _poll_stats(self) -> None:
        if not self._session_active:
            return
        try:
            req = urllib.request.Request(f"http://127.0.0.1:{self._port}/health")
            with urllib.request.urlopen(req, timeout=1) as resp:
                data = json.loads(resp.read().decode())
        except Exception as exc:
            logger.debug("stats poll fetch failed: %s", exc)
            return

        stats = data.get("stats") or {}
        ai = int(stats.get("ai_calls", 0))
        td = int(stats.get("local_todo_calls", 0))

        # Per-kind breakdown lives in the tooltip — visible on hover, doesn't
        # affect the pill width so the toolbar layout stays stable.
        ai_kinds = stats.get("ai_calls_by_kind") or {}
        td_kinds = stats.get("local_todo_calls_by_kind") or {}
        last_action = stats.get("last_local_todo_action") or ""
        ai_breakdown = ", ".join(f"{k}={v}" for k, v in sorted(ai_kinds.items())) or "(none)"
        td_breakdown = ", ".join(f"{k}={v}" for k, v in sorted(td_kinds.items())) or "(none)"
        tooltip = (
            f"AI calls: {ai} ({ai_breakdown})\n"
            f"Local-todo calls: {td} ({td_breakdown})"
        )
        if last_action:
            tooltip += f"\nLast todo action: {last_action}"

        # Daemon health — its own compact pill (text + loop dot), separate from
        # the call-counter pill above. Verbose breakdown goes in the health
        # pill's own tooltip, not the counter pill's.
        h = data.get("health") or {}
        health_str, degraded = self._format_health_line(h)
        lag = h.get("event_loop_lag_ms") or 0.0
        loop_ok = lag < 500
        health_dot_color = "#3fb950" if loop_ok else ft.Colors.AMBER
        health_accent = ft.Colors.AMBER if degraded else ft.Colors.ON_SURFACE_VARIANT
        health_border = ft.Colors.AMBER if degraded else ft.Colors.OUTLINE_VARIANT

        cpu = h.get("cpu_percent")
        rss = h.get("rss_mb")
        host_cpu = h.get("host_cpu_percent")
        last_kind = h.get("last_ai_call_kind") or ""
        age_v = h.get("last_ai_call_age_sec")
        age_phrase = f"{int(age_v)}s ago" if isinstance(age_v, (int, float)) else "never"
        ht_lines = ["Last AI call: " + age_phrase + (f" ({last_kind})" if last_kind else "")]
        if isinstance(cpu, (int, float)):
            cpu_line = f"CPU: {cpu:.0f}% process"
            if isinstance(host_cpu, (int, float)):
                cpu_line += f" · {host_cpu:.0f}% host"
            ht_lines.append(cpu_line)
        if isinstance(rss, (int, float)):
            ht_lines.append(f"Memory: {rss:.0f} MB")
        ht_lines.append("Event loop: " + ("OK" if loop_ok else f"SLOW ({int(lag)} ms)"))
        if degraded:
            ht_lines.append("⚠ daemon looks degraded — consider restarting it from Settings.")
        health_tooltip = "\n".join(ht_lines)

        # Widget mutations belong on the page's asyncio loop, NOT on the
        # background polling thread. Calling .update() from page.run_thread
        # is a Flet thread-safety violation that can cause assertion errors
        # or double-paint races, especially while the user is typing.
        async def _apply() -> None:
            if not self._is_active:
                return  # tab hidden — skip the IPC paint cycle
            self._ai_count_text.value = str(ai)
            self._todo_count_text.value = str(td)
            self._stats_pill.tooltip = tooltip
            try:
                self._stats_pill.update()
            except Exception as exc:
                logger.debug("stats pill update: %s", exc)
            self._health_text.value = health_str
            self._health_text.color = health_accent
            self._health_icon.color = health_accent
            self._health_dot.color = health_dot_color
            self._health_pill.tooltip = health_tooltip
            self._health_pill.border = ft.Border.all(1, health_border)
            try:
                self._health_pill.update()
            except Exception as exc:
                logger.debug("health pill update: %s", exc)

        try:
            self._page.run_task(_apply)
        except Exception as exc:
            logger.debug("stats run_task dispatch: %s", exc)

    def _poll_provider(self) -> None:
        # Skip polling for a few seconds after a user click. Without this, the
        # 3 s background poll fetches the OLD provider state from the daemon
        # (the POST may still be in flight or transcriber-swap is blocking
        # the daemon's handler) and overwrites the user's just-made selection.
        if time.monotonic() < self._provider_poll_suppressed_until:
            return
        try:
            req = urllib.request.Request(f"http://127.0.0.1:{self._port}/provider")
            with urllib.request.urlopen(req, timeout=1) as resp:
                data = json.loads(resp.read().decode())
        except Exception:
            return

        self._syncing_provider = True
        try:
            provider = data.get("provider", "claude")
            self._current_provider = provider
            self._provider_pill.set_label(_label_for(_PROVIDER_OPTIONS, provider, "Claude"))

            model_key = _PROVIDER_TO_MODEL_KEY.get(provider, "claude_model")
            model_val = data.get(model_key, "")
            opts = _MODEL_OPTIONS_BY_PROVIDER.get(provider, [])
            if provider == "local" and model_val:
                opts = [PillOption(key=model_val, label=model_val)]
            self._model_pill.set_options(opts)
            if model_val:
                self._model_pill.set_label(_label_for(opts, model_val, model_val))

            transcriber = data.get("transcriber", "whisper")
            self._current_transcriber = transcriber
            # Prefer the daemon's runtime transcriber name — e.g. "Whisper
            # (remote: http://…)" / "Whisper (local)" / "Deepgram" — so the
            # chip shows what's actually running, not just the configured mode.
            t_name = (data.get("transcriber_name") or "").strip()
            self._transcriber_pill.set_label(
                t_name or _label_for(_TRANSCRIBER_OPTIONS, transcriber, "Whisper")
            )

            # Readiness flags drive control visibility (Brief, provider/model
            # pills). Default to True if the daemon predates these fields so
            # we don't hide everything against an old daemon.
            self._local_todo_configured = bool(
                data.get("local_todo_configured", True)
            )
            self._provider_configured = bool(
                data.get("provider_configured", True)
            )
            self._apply_readiness_visibility()

            try:
                self._page.update()
            except Exception:
                pass
        finally:
            self._syncing_provider = False

    def _apply_readiness_visibility(self) -> None:
        """Toggle controls based on workspace setup.

        Goal: in 'simple mode' (no AI provider, no local-todo MCP) the
        Copilot screen reduces to recording controls + the live
        conversation feed, with no AI or task-tracker UI cluttering it.
        """
        in_meeting = self._session_active
        ai = self._provider_configured
        mcp = self._local_todo_configured

        # MCP-driven
        self._brief_btn.visible = in_meeting and mcp
        self._tab_btn_topics.visible = mcp

        # AI-driven
        self._provider_pill.visible = ai
        self._model_pill.visible = ai
        self._engagement_pill.visible = ai  # Hot moment is AI-only
        self._query_input.visible = ai
        self._send_btn.visible = ai
        self._trigger_btn.visible = ai and in_meeting
        self._ask_claude_row.visible = ai  # Hide the whole ask-claude row container
        self._extract_btn.visible = ai and in_meeting
        self._tab_btn_tasks.visible = ai

        # Right-side pane: pointless if neither AI nor MCP is configured.
        self._tasks_pane.visible = ai or mcp
        # If only one of the two is configured, snap the active tab to it.
        if not mcp and ai and self._active_right_tab == "topics":
            self._active_right_tab = "tasks"
            self._tab_topics_content.visible = False
            self._tab_tasks_content.visible = True
            self._sync_right_tab_styling()
        elif not ai and mcp and self._active_right_tab == "tasks":
            self._active_right_tab = "topics"
            self._tab_topics_content.visible = True
            self._tab_tasks_content.visible = False
            self._sync_right_tab_styling()
        # If neither tab is meaningful, hide the strip entirely.
        self._right_tab_strip.visible = ai and mcp  # only show when both tabs exist

    # NOTE: the transcriber / provider / model toolbar chips are read-only —
    # those are changed in Settings (the daemon applies them live via /config).
    # The old _on_*_select / _post_provider / _suppress_provider_poll handlers
    # were removed; the chips stay in sync via `_poll_provider` and the `info`
    # websocket event.

    # ------------------------------------------------ topic + query handlers

    def _seed_topic(self) -> None:
        try:
            req = urllib.request.Request(f"http://127.0.0.1:{self._port}/current_topic")
            with urllib.request.urlopen(req, timeout=2) as resp:
                data = json.loads(resp.read().decode())
            topic_info = data.get("topic", {}) or {}
            topic = (topic_info.get("topic") or "").strip()
            tickets = topic_info.get("ticket_ids") or []
            if topic:
                self._topic_strip.set_topic(topic, tickets)
        except Exception:
            pass

    def _on_explain_topic(self, topic: str) -> None:
        text = f"Explain more about {topic}"
        self._thread.append("you", text)
        self._view.notify_appended(self._thread.turns[-1])
        self._view.force_follow()
        self._page.update()
        self._page.run_task(self._view.scroll_to_bottom)
        self._post_query(text)

    def _post_query(self, text: str) -> None:
        def _do() -> None:
            try:
                body = json.dumps({"text": text}).encode()
                req = urllib.request.Request(
                    f"http://127.0.0.1:{self._port}/query",
                    data=body,
                    headers={"Content-Type": "application/json"},
                )
                urllib.request.urlopen(req, timeout=120)
            except Exception:
                pass
        self._page.run_thread(_do)

    # ------------------------------------------------ websocket subscription

    def _start_ws_subscription(self) -> None:
        # Run on the page's actual asyncio loop (not a worker thread). With
        # run_thread + new_event_loop, every `.update()` from the WS handler
        # crosses both a thread and a loop boundary, which serializes UI
        # updates and makes streaming feel sluggish. run_task keeps everything
        # on the page's loop so widget mutations + page.update() are direct.
        self._page.run_task(self._ws_loop)

    async def _ws_loop(self) -> None:
        # Outer loop checks _stop_event so dispose() can break us out cleanly.
        # The asyncio.sleep(2) reconnect backoff is also gated on _stop_event.
        while not self._stop_event.is_set():
            url = f"ws://127.0.0.1:{self._port}/ws"
            try:
                async with websockets.connect(url) as ws:
                    logger.debug("WS connected to %s", url)
                    # Clear any stale interim caption left over from before
                    # the previous disconnect — otherwise a reconnect mid-
                    # utterance shows last interim forever until a fresh
                    # final lands.
                    self._reset_live_captions()
                    async for raw in ws:
                        if self._stop_event.is_set():
                            return
                        try:
                            msg = json.loads(raw)
                        except Exception as exc:
                            logger.warning(
                                "WS json decode failed (raw=%r): %s",
                                raw[:200] if isinstance(raw, (str, bytes)) else raw, exc,
                            )
                            continue
                        await self._dispatch_ws_event(msg)
                        # One batched flush per WS message — much cheaper than
                        # per-widget update() calls and produces a single,
                        # consistent paint per event.
                        try:
                            self._page.update()
                        except Exception as exc:
                            logger.debug("page.update() failed: %s", exc)
            except Exception as exc:
                # Reconnect after a short backoff. Log so the user can see why
                # the GUI is reconnecting forever (port mismatch, daemon down,
                # etc.) instead of getting an opaque silent retry loop.
                logger.warning("WS connection lost (will retry in 2s): %s", exc)
                # Wait 2s OR until dispose() is called, whichever first.
                # asyncio.wait_for + an event-loop-bound asyncio.Event would
                # be cleaner, but a thread-safe poll is good enough since
                # the loop iterates often.
                for _ in range(20):
                    if self._stop_event.is_set():
                        return
                    await asyncio.sleep(0.1)

    def _reset_live_captions(self) -> None:
        """Clear any stale interim text in the caption bar. Called on every
        successful WS connect so a reconnect mid-utterance doesn't leave the
        last interim sticking around forever waiting for a final that will
        never arrive on the new connection."""
        try:
            self._self_interim_text.value = ""
            self._other_interim_text.value = ""
            # Bar stays visible — it's fixed-height now, just blank when no
            # interim is active.
        except Exception as exc:
            logger.debug("reset_live_captions: %s", exc)

    def _schedule_render_streaming_turn(self) -> None:
        """Re-render the in-flight streaming `ai` turn after a chunk / answer
        event. Mirrors the original `chunk`-branch rendering: append the row
        if it isn't on screen yet, else update it in place, then schedule an
        autoscroll on the page loop (never awaited inline — that would
        serialize every subsequent WS event behind a Flet IPC round-trip)."""
        turn = self._thread.streaming_turn
        if turn is None:
            return
        if not self._view.is_rendered(turn):
            self._view.notify_appended(turn)
        else:
            self._view.notify_updated(turn)
        if self._view.is_following():
            self._page.run_task(self._view.scroll_to_bottom)

    def _render_streaming_turn_final(self, turn) -> None:
        """Render a streaming turn after it's been closed (`all_done` / legacy
        `done`)."""
        self._view.notify_updated(turn)
        if self._view.is_following():
            self._page.run_task(self._view.scroll_to_bottom)

    async def _dispatch_ws_event(self, msg: dict) -> None:
        kind = msg.get("type")
        if kind == "transcript":
            # SELF / OTHER sentences flow into the conversation thread so the
            # chat reads like a real meeting log. Consecutive sentences from
            # the same speaker (within SPEAKER_BURST_WINDOW_SEC) merge into
            # the same turn instead of spawning a new bubble per sentence.
            #
            # Interim transcripts go into a separate live caption bar — they
            # don't belong in the chat (Deepgram fires many growing-prefix
            # interims per utterance), but rendering them is what makes the
            # GUI feel fast. The bar clears as each role's final lands.
            role = msg.get("role")
            text = (msg.get("text") or "").strip()
            if role not in ("self", "other"):
                return

            if msg.get("interim"):
                # Role label is rendered in a fixed-width sibling Container
                # (see _self_interim_label / _other_interim_label) so we
                # only set the body text here.
                if role == "self":
                    self._self_interim_text.value = text
                else:
                    self._other_interim_text.value = text
                return

            if not text:
                return

            # Final: clear this role's interim, then commit to chat.
            if role == "self":
                self._self_interim_text.value = ""
            else:
                self._other_interim_text.value = ""

            turn, extended = self._thread.append_or_extend_transcript(role, text)
            if extended:
                self._view.notify_updated(turn)
            else:
                self._view.notify_appended(turn)
            # Don't await scroll — it's a Flet IPC round-trip and serializes
            # every other transcript behind it. Schedule on the page loop and
            # let dispatch return immediately. The outer _ws_loop's
            # page.update() handles the paint for this event.
            if self._view.is_following():
                self._page.run_task(self._view.scroll_to_bottom)
            return
        elif kind == "topic":
            topic = msg.get("topic") or ""
            tickets = msg.get("ticket_ids") or []
            self._topic_strip.set_topic(topic, tickets)
            # Mirror the active-topic highlight in the Topics tab so the
            # user can see which card the system thinks is current.
            active_id = tickets[0] if tickets else ""
            try:
                self._topics_panel.set_active_ticket(str(active_id))
            except Exception as exc:
                logger.debug("topics_panel.set_active_ticket: %s", exc)
            # AUTO/MANUAL pill — binary state, no countdown. Manual pin
            # payloads include `manual: True`; auto-picker payloads don't.
            try:
                self._topics_panel.set_indicator(manual=bool(msg.get("manual")))
            except Exception as exc:
                logger.debug("topics_panel.set_indicator: %s", exc)
            hm = msg.get("hot_moment") or {}
            self._set_engagement(
                bool(hm.get("active")),
                float(hm.get("until_wallclock") or 0.0),
            )
        elif kind == "start":
            # AI is starting to stream a response. Open an empty `ai` turn now;
            # subsequent `chunk` events will fill it in.
            turn = self._thread.begin_streaming("ai")
            self._view.notify_appended(turn)
            self._page.update()
            if self._view.is_following():
                await self._view.scroll_to_bottom()
            return
        elif kind == "meeting_status":
            active = bool(msg.get("active"))
            meeting_name = msg.get("meeting_name") or msg.get("app") or ""
            # Flip the toolbar status the moment the daemon reports the new
            # state — much faster than the global 3 s /health poll.
            self.update_status(True, active, meeting_name)
            if active:
                # Only clear conversation on a NEW meeting, not every replay.
                # The websocket.py on-connect handler re-sends `meeting_status
                # active=True` to late-joining clients, and historically that
                # call wiped the conversation on every WS reconnect (and on
                # the in-meeting state-confirmation tick the daemon could
                # send). Track the last meeting we cleared for and dedupe —
                # same meeting name → no clear, different name → clear.
                last = getattr(self, "_last_cleared_meeting_name", None)
                if last != meeting_name:
                    self._thread.clear()
                    self._view.notify_cleared()
                    self._last_cleared_meeting_name = meeting_name
        elif kind == "meeting_ended":
            # update_status already calls _reset_for_new_meeting on the
            # active→inactive transition. The explicit cleanup call here is
            # idempotent and covers the case where update_status was already
            # called by the polling loop just before this WS event.
            self.update_status(True, False, "")
            self._reset_for_new_meeting()
            # Reset clear-dedupe so the NEXT meeting (with the same or
            # different name) gets a fresh wipe.
            self._last_cleared_meeting_name = None
        elif kind == "summarizing":
            # Post-meeting summary in progress — the daemon holds its restart
            # until .summary.txt is written. Surface it so Stop / mic-release
            # doesn't look like a frozen no-op.
            if bool(msg.get("active")):
                self._set_status("Summarizing meeting…", ft.Colors.TERTIARY)
        elif kind == "engagement_status":
            self._set_engagement(
                bool(msg.get("active")),
                float(msg.get("until_wallclock") or 0.0),
            )
        elif kind == "answer_open":
            # A provider in the cascade just produced its first token — register
            # the answer on the in-flight `ai` turn so the carousel shows it.
            aid = msg.get("answer_id") or "A"
            self._thread.open_answer(
                aid,
                provider=msg.get("provider", ""),
                model=msg.get("model", ""),
            )
            ms = msg.get("first_token_ms")
            if isinstance(ms, (int, float)):
                self._thread.set_answer_latency(aid, int(ms))
            self._schedule_render_streaming_turn()
            return
        elif kind == "chunk":
            text = msg.get("text") or ""
            aid = msg.get("answer_id")
            if text:
                if aid:
                    turn = self._thread.append_chunk_to_answer(aid, text)
                else:
                    turn = self._thread.append_chunk(text)  # legacy / proactive
                if turn is not None:
                    self._schedule_render_streaming_turn()
                return
        elif kind == "ai_latency":
            # Legacy time-to-first-token for the in-flight AI turn (the cascade
            # now sends `first_token_ms` inside answer_open/done; this branch is
            # kept for older daemons / any path still emitting it).
            ms = msg.get("first_token_ms")
            if isinstance(ms, (int, float)):
                turn = self._thread.set_streaming_latency(int(ms))
                if turn is not None:
                    if not self._view.is_rendered(turn):
                        self._view.notify_appended(turn)
                    self._view.notify_meta_updated(turn)
                return
        elif kind == "answer_error":
            # The orchestrator doesn't currently emit this, but handle it: mark
            # the answer as failed (the carousel auto-flips to the first OK one).
            aid = msg.get("answer_id") or "A"
            self._thread.set_answer_error(aid, msg.get("message", "error"))
            self._schedule_render_streaming_turn()
            return
        elif kind == "all_done":
            # The cascade finished — close the streaming turn.
            turn = self._thread.end_streaming()
            if turn is not None:
                self._render_streaming_turn_final(turn)
            return
        elif kind == "done":
            aid = msg.get("answer_id")
            if aid:
                # Per-answer done from the cascade — stamp final latency.
                ms = msg.get("first_token_ms")
                if isinstance(ms, (int, float)):
                    self._thread.set_answer_latency(aid, int(ms))
                self._schedule_render_streaming_turn()
                return
            # Legacy single-stream done (the proactive path may still emit it).
            cards = msg.get("cards") or msg.get("items") or None
            turn = self._thread.end_streaming(cards=cards)
            if turn is not None:
                self._render_streaming_turn_final(turn)
                return
        elif kind == "brief":
            # Brief comes as a full payload (script + cards); append as one turn.
            script = msg.get("script") or ""
            cards = msg.get("cards") or []
            turn = self._thread.append("brief", script, cards=cards)
            self._view.notify_appended(turn)
            if self._view.is_following():
                self._page.run_task(self._view.scroll_to_bottom)
            return
        elif kind == "transcriber_dead":
            # Surfaced by DeepgramTranscriber._broadcast_dead after reconnect
            # exhaustion (10 attempts × exponential back-off ≈ 210 s). Without
            # this listener the pill stayed green while transcription was
            # dead — we'd add the broadcast in 9c03d13 but never wired the
            # consumer side, so the user would never know why captions stopped.
            role = (msg.get("role") or "?").lower()
            reason = msg.get("reason") or "unknown"
            logger.warning(
                "Transcriber DEAD (role=%s, reason=%s) — surfacing to UI",
                role, reason,
            )
            # Mark the transcriber pill so the user sees something is broken.
            # Health-monitor (Phase 4c) will try to respawn; if it succeeds,
            # the next info broadcast resets the label.
            current = self._transcriber_pill.label or "Deepgram"
            if "⚠" not in current:
                self._transcriber_pill.set_label(f"{current} ⚠ {role}")
            return
        elif kind == "cards":
            cards = msg.get("items") or msg.get("cards") or []
            # Attach to the last ai turn if there is one.
            for turn in reversed(self._thread.turns):
                if turn.role == "ai":
                    turn.cards = list(cards)
                    self._view.notify_updated(turn)
                    break
        elif kind == "app_updated":
            new_version = msg.get("version", "?")
            logger.info("auto-update: received app_updated event v%s", new_version)
            # Notify the user briefly, then close the window so they
            # restart cleanly into the new version.
            try:
                sb = ft.SnackBar(
                    content=ft.Text(
                        f"Updated to v{new_version}. Closing — please reopen Meeting Helper."
                    ),
                    duration=5000,
                )
                self._page.overlay.append(sb)
                sb.open = True
                self._page.update()
            except Exception:
                pass
            # Close the window after a short delay so the user sees the
            # snackbar first. Window.close()/destroy() are coroutines in
            # Flet 0.84 — calling them from a bare thread is a silent no-op
            # ("coroutine was never awaited"), which left the old GUI alive
            # so the post-update relaunch just focused it instead of opening
            # a fresh window. Run it as a page task so it's actually awaited.
            async def _close_after_delay() -> None:
                import asyncio as _asyncio
                await _asyncio.sleep(2.5)
                try:
                    await self._page.window.destroy()
                except Exception:
                    try:
                        await self._page.window.close()
                    except Exception:
                        # Last resort: hard-exit this GUI process so the
                        # relaunched one isn't blocked by an "already
                        # running" check.
                        import os
                        os._exit(0)

            try:
                self._page.run_task(_close_after_delay)
            except Exception:
                logger.warning("auto-update: could not schedule GUI window close")

    # ------------------------------------------------ ask AI input handler

    def _on_send(self, _e: ft.ControlEvent) -> None:
        text = (self._query_input.value or "").strip()
        if not text:
            return
        self._query_input.value = ""
        try:
            self._query_input.update()
        except Exception:
            pass
        turn = self._thread.append("you", text)
        self._view.notify_appended(turn)
        self._view.force_follow()
        self._page.update()
        self._page.run_task(self._view.scroll_to_bottom)
        self._post_query(text)

    # ------------------------------------------------ trigger-query handler
    #
    # Mirrors the 2xCmd hotkey: posts to /query/trigger so the daemon runs
    # handle_query() with no typed text — the AI reply uses the current
    # transcript + topic context.

    def _on_trigger_query(self, _e: ft.ControlEvent) -> None:
        if not self._session_active:
            return
        self._trigger_btn.disabled = True
        try:
            self._trigger_btn.update()
        except Exception:
            pass

        def _do() -> None:
            try:
                req = urllib.request.Request(
                    f"http://127.0.0.1:{self._port}/query/trigger",
                    data=b"{}",
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                urllib.request.urlopen(req, timeout=60).read()
            except Exception as exc:
                turn = self._thread.append("ai", f"**(error)** {exc}")
                self._view.notify_appended(turn)
            finally:
                self._trigger_btn.disabled = False
                try:
                    self._trigger_btn.update()
                except Exception:
                    pass

        self._page.run_thread(_do)

    # ------------------------------------------------ brief button handler

    def _on_brief_clicked(self, _e: ft.ControlEvent) -> None:
        self._brief_btn.disabled = True
        self._brief_btn_label.value = "Generating…"
        try:
            self._brief_btn.update()
        except Exception:
            pass

        def _do() -> None:
            try:
                req = urllib.request.Request(
                    f"http://127.0.0.1:{self._port}/brief",
                    data=b"{}",
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                urllib.request.urlopen(req, timeout=120).read()
            except urllib.error.HTTPError as exc:
                try:
                    body_str = exc.read().decode()
                    err = json.loads(body_str).get("error", str(exc))
                except Exception:
                    err = str(exc)
                turn = self._thread.append("brief", f"**(error)** {err}")
                self._view.notify_appended(turn)
            except Exception as exc:
                turn = self._thread.append("brief", f"**(error)** {exc}")
                self._view.notify_appended(turn)
            finally:
                self._brief_btn.disabled = False
                self._brief_btn_label.value = "Brief"
                try:
                    self._brief_btn.update()
                except Exception:
                    pass

        self._page.run_thread(_do)

    def _on_clear_clicked(self, _e: ft.ControlEvent) -> None:
        self._thread.clear()
        self._view.notify_cleared()
        self._view.force_follow()

    # ------------------------------------------------ autoscroll indicator

    def _on_view_following_changed(self, following: bool) -> None:
        """Update the toolbar autoscroll button to reflect follow state."""
        if following:
            self._autoscroll_btn.icon = ft.Icons.VERTICAL_ALIGN_BOTTOM
            self._autoscroll_btn.icon_color = TEAL
            self._autoscroll_btn.tooltip = "Auto-scroll on (following bottom)"
        else:
            self._autoscroll_btn.icon = ft.Icons.PAUSE_CIRCLE_OUTLINE
            self._autoscroll_btn.icon_color = ft.Colors.TERTIARY
            self._autoscroll_btn.tooltip = "Paused — click to resume auto-scroll"
        try:
            self._autoscroll_btn.update()
        except Exception:
            pass

    def _on_autoscroll_clicked(self, _e: ft.ControlEvent) -> None:
        """User clicked the indicator: jump to bottom and re-arm following."""
        self._view.force_follow()
        self._page.run_task(self._view.scroll_to_bottom)

    def _on_show_stats(self, _e: ft.ControlEvent) -> None:
        """Surface the AI / local-todo call counters via a snackbar.

        Vestigial — the overflow-menu redesign that introduced this was
        reverted. Stats pill is back on the toolbar. Kept callable so the
        existing tests pass; harmless if invoked.
        """
        ai = self._ai_count_text.value or "0"
        td = self._todo_count_text.value or "0"
        msg = (
            f"AI calls: {ai}   ·   Local-todo calls: {td}\n"
            f"(Hover the toolbar pill for per-kind breakdown.)"
        )
        try:
            sb = ft.SnackBar(content=ft.Text(msg))
            self._page.overlay.append(sb)
            sb.open = True
            self._page.update()
        except Exception as exc:
            logger.warning("show_stats snackbar failed: %s", exc)

    # ------------------------------------------------ session toggle

    def _on_session_toggle(self, _e: ft.ControlEvent) -> None:
        was_active = self._session_active
        endpoint = "/session/stop" if was_active else "/session/start"

        # Optimistic visual feedback so the user gets immediate response.
        # The daemon broadcasts `meeting_status` over WS the moment the
        # session is actually live (or stopped) — the WS handler picks it up
        # and calls update_status with the real state. Don't poll /health
        # here: the daemon sets session_active a few seconds after returning
        # 200 from /session/start (audio capture + transcribers spin up
        # asynchronously), and an early poll would clobber the optimistic
        # label with stale "Ready".
        self._session_btn.disabled = True
        self._status_text.value = "Stopping…" if was_active else "Starting…"
        self._status_text.color = ft.Colors.TERTIARY
        self._status_icon.color = ft.Colors.TERTIARY
        try:
            self._page.update()
        except Exception:
            pass

        def _do() -> None:
            if was_active:
                # Graceful stop: ask the daemon to end the session. It stops
                # capture, writes the meeting summary, then restarts itself for
                # a clean PortAudio state. We poll /health through that whole
                # cycle (surfacing "Summarizing meeting…") and only fall back
                # to force_stop if the daemon won't even acknowledge the stop
                # — i.e. it's genuinely wedged on a slow MCP / dead WS / stuck
                # SCK callback.
                acked = False
                try:
                    req = urllib.request.Request(
                        f"http://127.0.0.1:{self._port}/session/stop",
                        data=b"{}",
                        headers={"Content-Type": "application/json"},
                    )
                    with urllib.request.urlopen(req, timeout=10) as resp:
                        acked = 200 <= resp.status < 300
                except Exception as exc:
                    logger.warning("session/stop POST failed: %s", exc)
                if acked:
                    self._wait_for_stop_complete(deadline_sec=200.0)
                else:
                    from meeting_helper.force_stop import force_stop_session
                    self._set_status("Forcing stop…", ft.Colors.TERTIARY)
                    try:
                        force_stop_session(self._port)
                    except Exception as exc:
                        logger.warning("force_stop_session failed: %s", exc)
                    self._wait_for_daemon_ready(deadline_sec=10.0)
            else:
                # Start path: simple POST.
                try:
                    req = urllib.request.Request(
                        f"http://127.0.0.1:{self._port}{endpoint}",
                        data=b"{}",
                        headers={"Content-Type": "application/json"},
                    )
                    urllib.request.urlopen(req, timeout=5)
                except Exception as exc:
                    logger.warning("session/start POST failed: %s", exc)
            # Re-enable the button now — for stop we've confirmed the daemon
            # cycled; for start we already finished the POST.
            self._session_btn.disabled = False
            try:
                self._page.update()
            except Exception:
                pass

        self._page.run_thread(_do)

    def _set_status(self, text: str, color=None) -> None:
        """Update the toolbar status label from any thread (best-effort)."""
        self._status_text.value = text
        if color is not None:
            self._status_text.color = color
            self._status_icon.color = color
        try:
            self._page.update()
        except Exception:
            pass

    def _wait_for_stop_complete(self, *, deadline_sec: float = 200.0) -> None:
        """After a graceful POST /session/stop, poll /health until the stop
        cycle is fully done. The daemon stops capture → writes the meeting
        summary → restarts itself (clean PortAudio state), so we expect:
        a "summarizing" window, then a brief connection gap (the restart),
        then a fresh daemon reporting session_active=False. Surfaces the
        summarizing state in the toolbar so the user isn't left blind.
        """
        start = time.monotonic()
        showed_summarizing = False
        saw_restart = False
        while time.monotonic() - start < deadline_sec:
            up = False
            data: dict = {}
            try:
                req = urllib.request.Request(f"http://127.0.0.1:{self._port}/health")
                with urllib.request.urlopen(req, timeout=1) as resp:
                    if 200 <= resp.status < 300:
                        up = True
                        try:
                            data = json.loads(resp.read().decode() or "{}") or {}
                        except Exception:
                            data = {}
            except Exception:
                pass

            if up:
                if data.get("summarizing"):
                    # Re-assert each tick — the app-shell's 3 s /health poll
                    # may otherwise clobber the label back to a stale state.
                    showed_summarizing = True
                    self._set_status("Summarizing meeting…", ft.Colors.TERTIARY)
                if not data.get("session_active"):
                    if saw_restart:
                        return  # fresh daemon up after the restart — done
                    if (time.monotonic() - start) > 8.0:
                        return  # daemon idle and not restarting — treat as done
            else:
                # Daemon went away → it's restarting (os._exit + respawn).
                if not saw_restart:
                    saw_restart = True
                    if not showed_summarizing:
                        self._set_status("Restarting…", ft.Colors.TERTIARY)
            time.sleep(0.5)
        logger.warning("stop did not fully complete within %.0fs", deadline_sec)

    def _wait_for_daemon_ready(self, *, deadline_sec: float = 10.0) -> bool:
        """Poll /health on a tight cadence until the daemon answers or we
        time out. Used after force_stop_session respawns the daemon, so
        the next Start click hits a daemon that's actually listening
        instead of timing out into a silent failure.
        """
        start = time.monotonic()
        while time.monotonic() - start < deadline_sec:
            try:
                req = urllib.request.Request(
                    f"http://127.0.0.1:{self._port}/health",
                )
                with urllib.request.urlopen(req, timeout=1) as resp:
                    if 200 <= resp.status < 300:
                        logger.info(
                            "fresh daemon ready after %.1fs",
                            time.monotonic() - start,
                        )
                        return True
            except Exception:
                pass
            time.sleep(0.3)
        logger.warning(
            "fresh daemon not ready within %.1fs — Start button may "
            "land on an unresponsive daemon", deadline_sec,
        )
        return False

    # ------------------------------------------------ extract task handler

    def _on_extract_task(self, _e: ft.ControlEvent) -> None:
        self._extract_btn.disabled = True
        self._extract_btn_label.value = "Extracting…"
        try:
            self._extract_btn.update()
        except Exception:
            pass

        def _do() -> None:
            try:
                req = urllib.request.Request(
                    f"http://127.0.0.1:{self._port}/extract-task",
                    data=b"{}",
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                urllib.request.urlopen(req, timeout=60).read()
            except Exception:
                pass
            finally:
                self._extract_btn.disabled = False
                self._extract_btn_label.value = "Extract Task"
                try:
                    self._extract_btn.update()
                except Exception:
                    pass

        self._page.run_thread(_do)

    # ------------------------------------------------ tasks polling

    def _start_tasks_polling(self) -> None:
        def _poll() -> None:
            while not self._stop_event.is_set():
                try:
                    self._poll_tasks()
                except Exception as exc:
                    logger.warning("tasks poll iteration failed: %s", exc)
                if self._stop_event.wait(2):
                    return

        self._page.run_thread(_poll)

    def _poll_tasks(self) -> None:
        try:
            req = urllib.request.Request(f"http://127.0.0.1:{self._port}/tasks")
            with urllib.request.urlopen(req, timeout=2) as resp:
                data = json.loads(resp.read())
            tasks = data.get("tasks", [])
        except Exception as exc:
            logger.debug("tasks poll fetch failed: %s", exc)
            return

        current_ids = [t.get("id") for t in self._tasks_panel._tasks]
        new_ids = [t.get("id") for t in tasks]
        if current_ids == new_ids:
            return

        # set_tasks calls page.update() — must run on the asyncio loop,
        # not the polling thread. Skip when the tab isn't active so we
        # don't repaint a hidden screen.
        async def _apply() -> None:
            if not self._is_active:
                return
            try:
                self._tasks_panel.set_tasks(tasks)
            except Exception as exc:
                logger.debug("tasks panel set_tasks: %s", exc)

        try:
            self._page.run_task(_apply)
        except Exception as exc:
            logger.debug("tasks run_task dispatch: %s", exc)

    # ------------------------------------------------ topics polling

    def _start_topics_polling(self) -> None:
        """Poll /topics every 8s. Sprint contents change rarely, so we
        don't need a tight cadence — once-per-bubble-of-conversation is
        fine. Cancellable via _stop_event for clean dispose."""
        def _poll() -> None:
            while not self._stop_event.is_set():
                try:
                    self._poll_topics()
                except Exception as exc:
                    logger.warning("topics poll iteration failed: %s", exc)
                if self._stop_event.wait(8):
                    return

        self._page.run_thread(_poll)

    def _poll_topics(self) -> None:
        # Skip when there's no active session — outside a meeting the
        # Topics tab is empty by design (cleared in update_status), so
        # polling generates pure waste: an MCP fan-out across boards
        # every 8 s for data nobody will see. Mirrors the _poll_tasks
        # gating pattern.
        if not self._session_active:
            return
        try:
            req = urllib.request.Request(f"http://127.0.0.1:{self._port}/topics")
            with urllib.request.urlopen(req, timeout=3) as resp:
                data = json.loads(resp.read())
            topics = data.get("topics", [])
            columns = data.get("columns", [])
        except Exception as exc:
            logger.debug("topics poll fetch failed: %s", exc)
            return

        # Set on the page's asyncio loop — set_topics calls page.update().
        async def _apply() -> None:
            if not self._is_active:
                return
            try:
                self._topics_panel.set_topics(topics, columns=columns)
            except Exception as exc:
                logger.debug("topics panel set_topics: %s", exc)

        try:
            self._page.run_task(_apply)
        except Exception as exc:
            logger.debug("topics run_task dispatch: %s", exc)

    def _on_right_tab_click(self, key: str) -> None:
        """Switch the right-pane tab content.

        Pure UI: flips visibility on the two stacked content containers
        and re-styles the tab buttons. No backend call required.
        """
        if key not in ("topics", "tasks"):
            return
        if key == self._active_right_tab:
            return
        self._active_right_tab = key
        self._tab_topics_content.visible = (key == "topics")
        self._tab_tasks_content.visible = (key == "tasks")
        self._sync_right_tab_styling()
        try:
            self._page.update()
        except Exception as exc:
            logger.debug("right tab click page.update: %s", exc)

    def _sync_right_tab_styling(self) -> None:
        """Make the active tab button visually distinct (filled bg + bottom
        accent, like a Material tab indicator)."""
        active_bg = ft.Colors.SURFACE_CONTAINER_HIGH
        active_color = TEAL
        inactive_color = ft.Colors.ON_SURFACE_VARIANT
        for btn, key in (
            (self._tab_btn_topics, "topics"),
            (self._tab_btn_tasks, "tasks"),
        ):
            is_active = (key == self._active_right_tab)
            btn.bgcolor = active_bg if is_active else None
            btn.border = (
                ft.Border.only(bottom=ft.BorderSide(2, active_color))
                if is_active else None
            )
            # The Text inside: tweak color to telegraph active state.
            try:
                inner = btn.content  # ft.Text
                inner.color = active_color if is_active else inactive_color
            except Exception:
                pass

    def _on_topic_pick(self, topic: dict) -> None:
        """Called when the user clicks a topic in the Topics tab.

        Fires POST /topic/set so the daemon pins the topic for ~90 s
        (TopicWorker auto-pick is suppressed during that window). The
        daemon broadcasts a `topic` WS event back which the dispatch
        handler picks up to update the top topic strip + the highlighted
        card. We don't optimistically update the strip here — the WS
        event is the canonical signal so a failed POST doesn't leave a
        misleading top banner.
        """
        ticket_id = str(topic.get("id") or "")
        title = topic.get("title") or ""
        board_id = topic.get("board_id")
        body = json.dumps({
            "ticket_id": ticket_id, "title": title, "board_id": board_id,
        }).encode()

        def _do() -> None:
            try:
                req = urllib.request.Request(
                    f"http://127.0.0.1:{self._port}/topic/set",
                    data=body,
                    headers={"Content-Type": "application/json"},
                )
                urllib.request.urlopen(req, timeout=5)
                logger.info("topic/set posted for ticket %s (%s)", ticket_id, title[:60])
            except Exception as exc:
                logger.warning(
                    "topic/set POST failed (ticket=%s): %s", ticket_id, exc,
                )

        try:
            self._page.run_thread(_do)
        except Exception as exc:
            logger.debug("topic pick run_thread dispatch: %s", exc)


def _label_for(options: list[PillOption], key: str, default: str) -> str:
    for o in options:
        if o.key == key:
            return o.label
    return default


def _key_for(options: list[PillOption], label: str, default: str) -> str:
    for o in options:
        if o.label == label:
            return o.key
    return default
