"""Workspace screen — placeholder.

Originally this screen managed repos workspace folders and knowledge folders for
Claude context. That layer was removed in Phase 2 of "Learn From Conversations"
(see docs/superpowers/plans/2026-05-08-learn-from-conversations.md): the agent
now learns from past meeting summaries and user-authored Notes via the Library
screen + KB toggle, and the per-meeting Context Selector is gone.

The module is kept so `from meeting_helper.flet_gui.screens import WorkspaceScreen`
keeps working for any back-compat import path. The class renders an empty column.
It is NOT mounted in `app.py` — see the comment there for re-enablement.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import flet as ft

if TYPE_CHECKING:
    from meeting_helper.config import Config


class WorkspaceScreen(ft.Column):
    """Empty placeholder. Kept for import back-compat."""

    def __init__(self, page: ft.Page, config: "Config"):
        super().__init__(
            expand=True,
            spacing=0,
            horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
        )
        self._page = page
        self._config = config
        self.controls = []

    def on_activate(self):  # parity with other screens
        pass
