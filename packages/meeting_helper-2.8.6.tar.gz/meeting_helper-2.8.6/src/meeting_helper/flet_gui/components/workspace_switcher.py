"""Top-bar workspace dropdown — lists workspaces, dispatches switch.

The actual switch flow runs in `workspace_switch.switch_workspace`. This
component only handles UI state and rebuild on the active workspace changing.
"""

from __future__ import annotations

from typing import Callable

import flet as ft

from meeting_helper.config import list_workspaces, load_state


class WorkspaceSwitcher(ft.Container):
    """Pill-shaped popup menu showing the active workspace name."""

    def __init__(
        self,
        on_pick: Callable[[str], None],
        on_manage: Callable[[], None],
    ):
        super().__init__()
        self._on_pick = on_pick
        self._on_manage = on_manage

        self._label = ft.Text(
            self._active_name(), size=13, weight=ft.FontWeight.W_500
        )
        self._popup = ft.PopupMenuButton(
            content=ft.Container(
                content=ft.Row(
                    [
                        ft.Icon(ft.Icons.FOLDER_OPEN_OUTLINED, size=16),
                        self._label,
                        ft.Icon(ft.Icons.ARROW_DROP_DOWN, size=18),
                    ],
                    spacing=4,
                    tight=True,
                ),
                padding=ft.Padding.symmetric(horizontal=12, vertical=6),
                border_radius=20,
                bgcolor=ft.Colors.with_opacity(0.06, ft.Colors.ON_SURFACE),
            ),
            items=self._build_items(),
        )
        self.content = self._popup
        self.padding = ft.Padding.only(left=12, top=6, bottom=6)

    def _active_name(self) -> str:
        return load_state()["active_workspace"]

    def _build_items(self) -> list[ft.PopupMenuItem]:
        active = self._active_name()
        items: list[ft.PopupMenuItem] = []
        for name in list_workspaces():
            items.append(
                ft.PopupMenuItem(
                    content=ft.Row(
                        [
                            ft.Icon(
                                ft.Icons.CHECK if name == active else None,
                                size=16,
                            ),
                            ft.Text(name),
                        ],
                        spacing=8,
                    ),
                    on_click=lambda e, n=name: self._handle_pick(n),
                )
            )
        items.append(ft.PopupMenuItem())  # divider
        items.append(
            ft.PopupMenuItem(
                content=ft.Row(
                    [
                        ft.Icon(ft.Icons.SETTINGS_OUTLINED, size=16),
                        ft.Text("Manage workspaces…"),
                    ],
                    spacing=8,
                ),
                on_click=lambda e: self._on_manage(),
            )
        )
        return items

    def _handle_pick(self, name: str) -> None:
        if name == self._active_name():
            return
        self._on_pick(name)

    def refresh(self) -> None:
        """Re-read state.json and rebuild the menu items + label."""
        self._label.value = self._active_name()
        self._popup.items = self._build_items()
        try:
            self.update()
        except Exception:
            pass
