"""Conversation thread — data model + Flet rendering for the Copilot screen.

The data model (`ConversationThread`) is a pure-Python class with no Flet
dependency, so it can be unit-tested without a Page. The Flet view
(`ConversationView`) wraps the model and adds rendering, autoscroll,
and source-card display. Added in a later task.
"""

from __future__ import annotations

import re
import time
from collections import deque
from collections.abc import Callable
from dataclasses import dataclass, field

# Pattern for the source-ticket header lines the AI prefixes its replies with.
# Format: "> [TICKET-ID] Title". Treated as theme-aware chips, NOT as
# markdown blockquote (which renders almost-invisibly on dark themes).
_SOURCE_HEADER_RE = re.compile(r"^\s*>\s*\[([^\]]+)\]\s*(.+?)\s*$")


def _split_source_headers(text: str) -> tuple[list[tuple[str, str]], str]:
    """Pull leading `> [TICKET-ID] Title` lines off the front of `text`.

    Returns ``(headers, body)`` where ``headers`` is ``[(ticket_id, title), ...]``
    in source order. Stops at the first non-header, non-blank line. Blank lines
    inside the header block are tolerated and skipped. If no headers are found,
    returns ``([], text)`` unchanged.
    """
    if not text:
        return [], text
    lines = text.split("\n")
    headers: list[tuple[str, str]] = []
    consumed = 0
    for i, line in enumerate(lines):
        stripped = line.strip()
        if not stripped:
            # Blank line — keep going only if it's still inside the leading block
            consumed = i + 1
            continue
        m = _SOURCE_HEADER_RE.match(stripped)
        if m is None:
            break
        headers.append((m.group(1).strip(), m.group(2).strip()))
        consumed = i + 1
    if not headers:
        return [], text
    body = "\n".join(lines[consumed:]).lstrip("\n")
    return headers, body

# Roles a turn can have. UI styling differs per role.
TurnRole = str  # "self" | "other" | "you" | "ai" | "brief"


@dataclass
class Answer:
    answer_id: str
    provider: str = ""
    model: str = ""
    text: str = ""
    first_token_ms: int | None = None
    error: str | None = None


@dataclass
class Turn:
    role: TurnRole
    text: str
    cards: list[dict] = field(default_factory=list)
    ts: float = field(default_factory=time.time)
    # Time-to-first-token for `ai` turns, in milliseconds. Set once the
    # `ai_latency` websocket event arrives; None until then (or for non-ai turns).
    first_token_ms: int | None = None
    # Multi-answer carousel (only ever populated on `ai` turns produced by the
    # cascade). Empty list => single-stream turn, use `.text`.
    answers: list[Answer] = field(default_factory=list)
    visible_answer_index: int = 0

    @property
    def visible_answer(self) -> "Answer | None":
        if not self.answers:
            return None
        idx = max(0, min(self.visible_answer_index, len(self.answers) - 1))
        return self.answers[idx]

    @property
    def visible_text(self) -> str:
        a = self.visible_answer
        return a.text if a is not None else self.text


class ConversationThread:
    """In-memory conversation. UI-free; testable as plain Python."""

    MAX_TURNS = 500

    def __init__(self) -> None:
        self._turns: deque[Turn] = deque(maxlen=self.MAX_TURNS)
        self._streaming: Turn | None = None

    @property
    def turns(self) -> list[Turn]:
        return list(self._turns)

    @property
    def streaming_turn(self) -> "Turn | None":
        """The in-flight streaming turn, or None if nothing is streaming."""
        return self._streaming

    def append(
        self,
        role: TurnRole,
        text: str,
        cards: list[dict] | None = None,
    ) -> Turn:
        turn = Turn(role=role, text=text, cards=list(cards) if cards else [])
        self._turns.append(turn)
        return turn

    # Speaker-burst window: if the previous turn is the same `self`/`other`
    # speaker and was added within this many seconds, extend it instead of
    # creating a new turn. Avoids the "many tiny messages" pain.
    SPEAKER_BURST_WINDOW_SEC = 30.0
    # Cap merged-turn length so a long monologue (90+ s of one speaker)
    # doesn't become a wall-of-text bubble that pushes scroll forever.
    # Once the merged text exceeds this many chars, start a fresh bubble
    # for the same speaker — same role, just a new message group.
    MAX_MERGED_TURN_CHARS = 400

    def append_or_extend_transcript(self, role: TurnRole, text: str) -> tuple[Turn, bool]:
        """Append a transcribed sentence; merge with the previous turn if the
        same speaker is still in their burst window AND the merged text would
        stay under MAX_MERGED_TURN_CHARS.

        Returns ``(turn, extended)`` — ``extended=True`` means the previous
        turn was mutated (caller should re-render it), ``False`` means a new
        turn was appended (caller should render the new row).
        """
        text = text.strip()
        if not text:
            # No-op: return a sentinel so callers can branch cleanly.
            empty = Turn(role=role, text="")
            return (empty, False)

        last = self._turns[-1] if self._turns else None
        if (
            last is not None
            and last.role == role
            and (time.time() - last.ts) <= self.SPEAKER_BURST_WINDOW_SEC
            and len(last.text) < self.MAX_MERGED_TURN_CHARS
        ):
            sep = " " if last.text and not last.text.endswith((" ", "\n")) else ""
            last.text = f"{last.text}{sep}{text}"
            return (last, True)

        return (self.append(role, text), False)

    def begin_streaming(self, role: TurnRole) -> Turn:
        """Open a new streaming turn. Subsequent append_chunk() calls extend it."""
        turn = Turn(role=role, text="")
        self._turns.append(turn)
        self._streaming = turn
        return turn

    def append_chunk(self, text: str) -> Turn:
        """Append text to the in-flight streaming turn.

        If no streaming turn is open (e.g. a chunk arrived without a prior
        begin_streaming() call due to a race), opens a new `ai` turn
        conservatively.
        """
        if self._streaming is None:
            self.begin_streaming("ai")
        assert self._streaming is not None  # for type-checkers
        self._streaming.text += text
        return self._streaming

    def set_streaming_latency(self, first_token_ms: int) -> Turn | None:
        """Stamp time-to-first-token onto the in-flight streaming turn.

        Returns the turn so the caller can re-render it, or None if no turn
        is currently streaming (event arrived too late / out of order).
        """
        turn = self._streaming
        if turn is not None:
            turn.first_token_ms = first_token_ms
        return turn

    def end_streaming(self, cards: list[dict] | None = None) -> Turn | None:
        turn = self._streaming
        if turn is not None and cards:
            turn.cards = list(cards)
        self._streaming = None
        return turn

    def open_answer(self, answer_id: str, *, provider: str = "", model: str = "") -> Answer:
        """Register a new answer stream on the in-flight `ai` turn (opens one if needed)."""
        if self._streaming is None:
            self.begin_streaming("ai")
        assert self._streaming is not None
        for a in self._streaming.answers:
            if a.answer_id == answer_id:
                a.provider, a.model = provider or a.provider, model or a.model
                return a
        a = Answer(answer_id=answer_id, provider=provider, model=model)
        self._streaming.answers.append(a)
        return a

    def _find_answer(self, turn: Turn, answer_id: str) -> "Answer | None":
        for a in turn.answers:
            if a.answer_id == answer_id:
                return a
        return None

    def append_chunk_to_answer(self, answer_id: str, text: str) -> "Turn | None":
        if self._streaming is None:
            return None
        a = self._find_answer(self._streaming, answer_id) or self.open_answer(answer_id)
        a.text += text
        # Mirror the primary answer into `.text` so legacy consumers / history
        # extraction that read `turn.text` still see something sensible.
        if a is (self._streaming.answers[0] if self._streaming.answers else None):
            self._streaming.text = a.text
        return self._streaming

    def set_answer_latency(self, answer_id: str, first_token_ms: int) -> "Turn | None":
        if self._streaming is None:
            return None
        a = self._find_answer(self._streaming, answer_id)
        if a is not None:
            a.first_token_ms = first_token_ms
        return self._streaming

    def set_answer_error(self, answer_id: str, error: str) -> "Turn | None":
        if self._streaming is None:
            return None
        a = self._find_answer(self._streaming, answer_id) or self.open_answer(answer_id)
        a.error = error
        self._auto_switch_off_error(self._streaming)
        return self._streaming

    @staticmethod
    def _auto_switch_off_error(turn: Turn) -> None:
        """If the currently visible answer has an error and another answer has
        text, move the visible index to the first answer that has text."""
        vis = turn.visible_answer
        if vis is None or (vis.error is None):
            return
        for i, a in enumerate(turn.answers):
            if a.error is None and a.text:
                turn.visible_answer_index = i
                return

    def switch_answer(self, turn: Turn, delta: int) -> int:
        if not turn.answers:
            return 0
        turn.visible_answer_index = max(
            0, min(turn.visible_answer_index + delta, len(turn.answers) - 1)
        )
        return turn.visible_answer_index

    def clear(self) -> None:
        self._turns.clear()
        self._streaming = None


# ---------------------------------------------------------------------------
# Flet rendering
# ---------------------------------------------------------------------------

import webbrowser  # noqa: E402

import flet as ft  # noqa: E402

# Role styling constants
# Brand accents — kept as explicit hex; they read well on both themes.
TEAL = "#4ec9b0"
GREEN = "#3fb950"
BLUE = "#1f6feb"
SELF_BORDER = GREEN
OTHER_BORDER = BLUE
# Bubble backgrounds use Material 3 surface tokens so they adapt to theme.
# All three are in the SURFACE_CONTAINER family to keep `on_surface` text
# readable on either theme (avoiding ON_TERTIARY_CONTAINER mismatch risk
# with `ft.Markdown` which paints with `on_surface` by default).
YOU_BG = ft.Colors.SURFACE_CONTAINER_LOW
AI_BG = ft.Colors.SURFACE_CONTAINER
BRIEF_BG = ft.Colors.SURFACE_CONTAINER_HIGH

ROLE_ICON = {
    "self": "🎤",
    "other": "🔊",
    "you": "👤",
    "ai": "🤖",
    "brief": "📋",
}

ROLE_LABEL = {
    "self": "You said",
    "other": "Other said",
    "you": "You",
    "ai": "AI",
    "brief": "Brief",
}


def _format_ts(ts: float) -> str:
    return time.strftime("%H:%M", time.localtime(ts))


def _format_latency(ms: int) -> str:
    """Render a time-to-first-token reading: '⚡ 420 ms' or '⚡ 1.8s'."""
    if ms < 1000:
        return f"⚡ {ms} ms"
    return f"⚡ {ms / 1000:.1f}s"


def _provider_label(provider: str) -> str:
    """Human-friendly provider name for a carousel answer."""
    p = (provider or "").lower()
    if p == "claude":
        return "Claude"
    if p == "gemini":
        return "Gemini"
    return provider.title() if provider else "AI"


class ConversationView(ft.Container):
    """Flet rendering of a ConversationThread.

    Wraps an internal ``ft.ListView`` (``auto_scroll=False`` so ``scroll_to``
    works). The view tracks whether the user is currently pinned to the
    bottom — when they scroll up to read older content, ``is_following()``
    flips to ``False`` and the screen stops yanking them down on new turns.
    Scrolling back to the bottom re-arms the follow.

    Streaming updates are cheap: each turn keeps a reference to its body
    widget (``ft.Markdown`` for ai/brief, ``ft.Text`` for you). On
    ``notify_updated`` the body's value is mutated in place — no Container
    rebuild — so each chunk of streamed AI text shows up immediately.
    """

    # How close to the bottom (in pixels) still counts as "following". A small
    # buffer avoids toggling off on a tiny rubber-band overscroll.
    NEAR_BOTTOM_THRESHOLD_PX = 60.0

    def __init__(
        self,
        thread: ConversationThread,
        on_following_changed: "Callable[[bool], None] | None" = None,
    ) -> None:
        self._thread = thread
        # id(turn) -> (row Container, body widget, cards-container Column)
        self._row_for_turn: dict[int, tuple[ft.Control, ft.Control, ft.Column]] = {}
        # id(turn) -> headers Column (only present for ai/brief turns that
        # surfaced source-ticket lead-in chips). Kept in a separate dict so
        # we don't break the established 3-tuple contract above.
        self._headers_for_turn: dict[int, ft.Column] = {}
        # id(turn) -> the "⚡ 420 ms" Text in the header row (ai turns only).
        # Updated in place when the `ai_latency` event arrives.
        self._latency_for_turn: dict[int, ft.Text] = {}
        self._following = True
        self._on_following_changed = on_following_changed
        # Coalesce concurrent scroll_to_bottom calls into a single IPC
        # round-trip per paint frame.
        self._scroll_pending = False
        self._list = ft.ListView(
            spacing=8,
            auto_scroll=False,
            expand=True,
            on_scroll=self._handle_scroll,
            scroll_interval=120,
        )
        super().__init__(content=self._list, expand=True)

    # ----------------------------- following / scroll API

    def is_following(self) -> bool:
        return self._following

    def force_follow(self) -> None:
        """Re-arm autoscroll (used when the user takes a deliberate action,
        e.g. clicking Send or the resume-autoscroll button)."""
        self._set_following(True)

    async def scroll_to_bottom(self) -> None:
        # Debounce: if a scroll-to-bottom is already in flight, drop this
        # call. During AI streaming + concurrent transcripts the previous
        # impl queued 10-20 IPC round-trips per second; coalescing keeps
        # exactly one outstanding scroll per paint frame.
        if self._scroll_pending:
            return
        self._scroll_pending = True
        try:
            await self._list.scroll_to(offset=-1, duration=0)
        except Exception:
            pass
        finally:
            self._scroll_pending = False

    def _set_following(self, value: bool) -> None:
        if self._following == value:
            return
        self._following = value
        if self._on_following_changed is not None:
            try:
                self._on_following_changed(value)
            except Exception:
                pass

    def _handle_scroll(self, e: "ft.OnScrollEvent") -> None:
        # Disarm follow ONLY on user-initiated scroll-up. Content growth
        # (a new bubble or a streaming chunk extending the list) also
        # fires scroll events, and the old logic disarmed follow whenever
        # the bottom drifted past 60 px — which during a streaming AI
        # response could fire mid-chunk between the autoscroll's
        # scroll_to dispatch and its landing. Result: ping-pong follow
        # state, scroll stranded mid-chat, "scroll doesn't work very well".
        try:
            distance_from_bottom = e.max_scroll_extent - e.pixels
            delta = getattr(e, "scroll_delta", 0) or 0
        except Exception:
            return
        if self._following:
            # Only disarm on real user scroll-up (negative delta).
            if delta < 0 and distance_from_bottom > self.NEAR_BOTTOM_THRESHOLD_PX:
                self._set_following(False)
        else:
            # Re-arm when the user scrolls back near bottom.
            if distance_from_bottom <= self.NEAR_BOTTOM_THRESHOLD_PX:
                self._set_following(True)

    def is_rendered(self, turn: Turn) -> bool:
        return id(turn) in self._row_for_turn

    # ------------------------------------------------------------ public API

    def render_all(self) -> None:
        """Initial full render — call once after mounting."""
        self._list.controls = []
        self._row_for_turn.clear()
        for turn in self._thread.turns:
            self._append_turn(turn)
        self._safe_update()

    def notify_appended(self, turn: Turn) -> None:
        """Caller invokes this after a fresh ``thread.append(...)`` or ``begin_streaming(...)``.

        This method only mutates state. The owning screen is expected to call
        ``page.update()`` once per WS message to flush.
        """
        self._append_turn(turn)

    def notify_updated(self, turn: Turn) -> None:
        """Update an existing turn's body in place (cheap; no Container rebuild).

        Multi-answer `ai` turns are the exception — their header (answer count,
        per-answer latency, the visible answer's text) can't be patched in
        place, so they get a full row rebuild via ``rebuild_turn``."""
        entry = self._row_for_turn.get(id(turn))
        if entry is None:
            # turn isn't on screen yet (raced with append)
            self.notify_appended(turn)
            return
        if turn.role == "ai" and turn.answers:
            self.rebuild_turn(turn)
            return
        _row, body, _cards_col = entry
        # For ai/brief turns the AI may stream a "> [TICKET-ID] Title" header
        # block at the top — strip those lines into themed chips, leaving the
        # body markdown clean. The chip column is updated in place too.
        text = turn.text or ""
        if turn.role in ("ai", "brief"):
            headers, body_text = _split_source_headers(text)
            headers_col = self._headers_for_turn.get(id(turn))
            if headers_col is not None:
                headers_col.controls = [self._render_source_header(h) for h in headers]
                headers_col.visible = bool(headers)
        else:
            body_text = text
        if isinstance(body, ft.Markdown):
            body.value = body_text
        elif isinstance(body, ft.Text):
            body.value = body_text

    def notify_meta_updated(self, turn: Turn) -> None:
        """Update a turn's header metadata (the latency badge) in place.

        No-op if the turn isn't an ai turn or isn't rendered yet.
        """
        latency_text = self._latency_for_turn.get(id(turn))
        if latency_text is None:
            return
        latency_text.value = (
            _format_latency(turn.first_token_ms) if turn.first_token_ms is not None else ""
        )

    def notify_cleared(self) -> None:
        self._list.controls = []
        self._row_for_turn.clear()
        self._headers_for_turn.clear()
        self._latency_for_turn.clear()

    # ------------------------------------------------------------ rendering

    def _append_turn(self, turn: Turn) -> None:
        row, body, cards_col = self._build_turn(turn)
        self._list.controls.append(row)
        self._row_for_turn[id(turn)] = (row, body, cards_col)

    def _build_turn(self, turn: Turn) -> tuple[ft.Control, ft.Control, ft.Column]:
        """Build a row Container for a turn, returning (container, body widget, cards column).

        Body widget is held by reference so streaming chunks update it in place.
        cards column is empty initially; cards from `done` get appended into it.
        """
        icon = ROLE_ICON.get(turn.role, "•")
        label = ROLE_LABEL.get(turn.role, turn.role)
        ts = _format_ts(turn.ts)
        header_controls: list[ft.Control] = [
            ft.Text(f"{icon} {label}", size=11, weight=ft.FontWeight.W_600,
                    color=ft.Colors.ON_SURFACE_VARIANT),
            ft.Text(ts, size=11, color=ft.Colors.OUTLINE),
        ]
        if turn.role == "ai":
            # Time-to-first-token badge — empty until the `ai_latency` event
            # lands, then updated in place via notify_meta_updated().
            latency_text = ft.Text(
                _format_latency(turn.first_token_ms) if turn.first_token_ms is not None else "",
                size=11, color=TEAL,
            )
            header_controls.append(latency_text)
            self._latency_for_turn[id(turn)] = latency_text
        header = ft.Row(header_controls, spacing=8)

        # Multi-answer carousel (only on `ai` turns produced by the provider
        # cascade). When present, the body shows the *visible* answer's text
        # and a compact header above it lets the user flip between answers.
        answer_header: ft.Control | None = None
        visible_error: tuple[str, str] | None = None
        if turn.role == "ai" and turn.answers:
            answer_header = self._build_answer_header(turn)
            va = turn.visible_answer
            if va is not None and va.error is not None:
                visible_error = (_provider_label(va.provider), va.error)

        # Pull "> [TICKET-ID] Title" lead-in lines off the front of ai/brief
        # text so we can paint them as theme-aware chips instead of letting
        # them render as washed-out markdown blockquote.
        headers: list[tuple[str, str]] = []
        if turn.role == "ai" and turn.answers:
            body_text = turn.visible_text or ""
        else:
            body_text = turn.text or ""
        if turn.role in ("ai", "brief"):
            headers, body_text = _split_source_headers(body_text)

        body: ft.Control
        if visible_error is not None:
            plabel, err = visible_error
            body = ft.Text(f"⚠ {plabel}: {err}", size=12,
                           color=ft.Colors.ERROR, selectable=True)
        elif turn.role in ("ai", "brief"):
            body = ft.Markdown(
                body_text,
                selectable=True,
                extension_set=ft.MarkdownExtensionSet.GITHUB_WEB,
            )
        else:
            body = ft.Text(body_text, size=13, selectable=True)

        headers_col = ft.Column(
            controls=[self._render_source_header(h) for h in headers],
            spacing=4,
            visible=bool(headers),
        )
        if turn.role in ("ai", "brief"):
            self._headers_for_turn[id(turn)] = headers_col

        # The brief is meant to be read aloud — source-card boxes underneath
        # are visual clutter that distract from the spoken script, so we no
        # longer render them. Card data still rides on the turn for any
        # downstream consumer that wants it.
        cards_col = ft.Column([], spacing=4)

        bg = {
            "you": YOU_BG,
            "ai": AI_BG,
            "brief": BRIEF_BG,
        }.get(turn.role)
        border = None
        padding = ft.Padding.symmetric(horizontal=10, vertical=6)
        if turn.role == "self":
            # SELF speakers (the user) get a tinted background and a RIGHT
            # stripe — universal "this is me" treatment from every chat app
            # since 2010. Right-aligned via the wrapper Row below.
            bg = ft.Colors.SURFACE_CONTAINER_LOW
            border = ft.Border.only(right=ft.BorderSide(3, SELF_BORDER))
            padding = ft.Padding.only(left=10, top=4, bottom=4, right=10)
        elif turn.role == "other":
            # OTHER speakers — left-aligned, faint background, left stripe.
            bg = ft.Colors.SURFACE_CONTAINER_LOWEST
            border = ft.Border.only(left=ft.BorderSide(3, OTHER_BORDER))
            padding = ft.Padding.only(left=10, top=4, bottom=4, right=10)

        column_controls: list[ft.Control] = [header]
        if answer_header is not None:
            column_controls.append(answer_header)
        column_controls.extend([headers_col, body, cards_col])
        bubble = ft.Container(
            content=ft.Column(column_controls, spacing=4),
            bgcolor=bg,
            border=border,
            border_radius=6 if bg else 0,
            padding=padding,
        )

        # Right-align SELF with a width cap so long messages WRAP instead
        # of overflowing the right edge of the conversation column.
        # Earlier draft used `expand=False` on the bubble — the bubble then
        # grew to fit its content with no upper bound, so a long sentence
        # ran off the visible area (ticket: cropped "string typ...").
        # Flex-ratio Row: spacer takes 1, bubble takes 4 → bubble caps at
        # ~80% of the row width and the inner Text wraps to that width.
        if turn.role == "self":
            bubble.expand = 4
            wrapped = ft.Row(
                [
                    ft.Container(expand=1),  # left spacer
                    bubble,
                ],
                spacing=0,
            )
            return (wrapped, body, cards_col)

        return (bubble, body, cards_col)

    def _build_answer_header(self, turn: Turn) -> ft.Control:
        """Compact header for a multi-answer (or single-answer) `ai` turn.

        Single answer  →  right-aligned caption "Claude · model · 420 ms".
        Two or more     →  "‹  Claude · model · 1 / 2 · 420 ms  ›" with the
        chevrons flipping the visible answer.
        """
        n = len(turn.answers)
        idx = max(0, min(turn.visible_answer_index, n - 1))
        va = turn.answers[idx]
        plabel = _provider_label(va.provider)
        mlabel = va.model or ""
        ms = va.first_token_ms
        cap_color = ft.Colors.ON_SURFACE_VARIANT

        if n == 1:
            txt = f"{plabel}"
            if mlabel:
                txt += f" · {mlabel}"
            if ms:
                txt += f" · {ms} ms"
            return ft.Row(
                [ft.Text(txt, size=11, color=cap_color)],
                alignment=ft.MainAxisAlignment.END,
            )

        txt = f"{plabel}"
        if mlabel:
            txt += f" · {mlabel}"
        txt += f" · {idx + 1} / {n}"
        if ms:
            txt += f" · {ms} ms"

        def _go(delta: int):
            def _handler(_e: ft.ControlEvent) -> None:
                self._thread.switch_answer(turn, delta)
                self.rebuild_turn(turn)
                try:
                    self.update()
                except Exception:
                    pass
            return _handler

        return ft.Row(
            [
                ft.IconButton(
                    icon=ft.Icons.CHEVRON_LEFT,
                    icon_size=16,
                    tooltip="Previous answer",
                    disabled=idx == 0,
                    on_click=_go(-1),
                ),
                ft.Text(txt, size=11, color=cap_color),
                ft.IconButton(
                    icon=ft.Icons.CHEVRON_RIGHT,
                    icon_size=16,
                    tooltip="Next answer",
                    disabled=idx == n - 1,
                    on_click=_go(+1),
                ),
            ],
            spacing=4,
            tight=True,
        )

    def rebuild_turn(self, turn: Turn) -> None:
        """Rebuild a turn's row widget from scratch and swap it into the list.

        Used when an in-place body mutation isn't enough — e.g. a carousel
        turn whose header / visible answer changed (new answer opened, the
        user flipped the ‹ › arrows, an answer errored, latency stamped)."""
        entry = self._row_for_turn.get(id(turn))
        if entry is None:
            self.notify_appended(turn)
            return
        old_row, _body, _cards = entry
        new_row, new_body, new_cards = self._build_turn(turn)
        try:
            i = self._list.controls.index(old_row)
            self._list.controls[i] = new_row
        except (ValueError, AttributeError):
            # Old row not found — re-append rather than lose the turn.
            self._list.controls.append(new_row)
        self._row_for_turn[id(turn)] = (new_row, new_body, new_cards)

    def _render_source_header(self, header: tuple[str, str]) -> ft.Control:
        """Render one `[TICKET-ID] Title` chip.

        Uses Material 3 surface tokens so the chip stays legible on both
        light and dark themes — `SECONDARY_CONTAINER` for the bg pairs
        with `ON_SECONDARY_CONTAINER` text guaranteed by the theme.
        """
        ticket_id, title = header
        return ft.Container(
            content=ft.Row(
                [
                    ft.Text(
                        f"[{ticket_id}]",
                        size=11,
                        weight=ft.FontWeight.W_700,
                        color=ft.Colors.ON_SECONDARY_CONTAINER,
                        no_wrap=True,
                    ),
                    ft.Text(
                        title,
                        size=11,
                        color=ft.Colors.ON_SECONDARY_CONTAINER,
                        weight=ft.FontWeight.W_500,
                        expand=True,
                    ),
                ],
                spacing=6,
                tight=True,
            ),
            bgcolor=ft.Colors.SECONDARY_CONTAINER,
            border_radius=6,
            padding=ft.Padding.symmetric(horizontal=8, vertical=4),
        )

    def _render_one_card(self, c: dict) -> ft.Control:
        meta_parts: list[str] = []
        if c.get("status"):
            meta_parts.append(c["status"])
        if c.get("sprint"):
            meta_parts.append(f"Sprint {c['sprint']}")
        if c.get("due"):
            meta_parts.append(f"Due {c['due']}")
        meta = "  ·  ".join(meta_parts)
        head = f"[{c.get('id', '?')}] {c.get('title', '')}"
        url = c.get("url")

        def _open(_e: ft.ControlEvent) -> None:
            if url:
                webbrowser.open(url)

        return ft.Container(
            content=ft.Column([
                ft.Text(head, weight=ft.FontWeight.W_600, size=12),
                ft.Text(meta, size=10, color=ft.Colors.ON_SURFACE_VARIANT)
                    if meta else ft.Container(),
            ], spacing=2),
            padding=8,
            border=ft.Border.all(1, ft.Colors.OUTLINE_VARIANT),
            border_radius=6,
            on_click=_open if url else None,
            tooltip=url or None,
        )

    def _safe_update(self) -> None:
        try:
            self.update()
        except Exception:
            pass
