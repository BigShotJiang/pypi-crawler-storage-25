"""Pill — compact label + chevron button that opens a menu of options.

Also supports a `read_only` mode: a plain bordered chip showing the current
value with no popup menu — used in the Copilot toolbar to *display* the active
transcriber / AI provider / model (those are changed only in Settings now).
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

import flet as ft


@dataclass
class PillOption:
    key: str
    label: str


class Pill(ft.Container):
    """Compact pill: shows current label, opens a PopupMenu of options on click.

    The Flet rendering uses `ft.PopupMenuButton` whose `content` is the styled
    pill itself, so the button's tap target covers the whole visible pill. (An
    earlier layout put the styling on an *outer* Container wrapping the button,
    which left a dead click-band around the button's edges — users had to click
    twice to open the menu.)

    When `read_only=True`, the popup machinery is dropped entirely: the pill is
    just a bordered `Container` + `Text` (no chevron, no tap target). `set_label`
    still works so callers can keep it in sync with daemon state; `set_options`
    and `select` become no-ops.

    Most logic (selection routing, option mutation) lives in plain Python so it
    can be unit-tested without a Page.
    """

    def __init__(
        self,
        label: str,
        options: list[PillOption] | None = None,
        on_select: Callable[[str], None] | None = None,
        *,
        read_only: bool = False,
    ) -> None:
        super().__init__()
        self._label = label
        self._options = list(options or [])
        self._on_select = on_select
        self._read_only = read_only or on_select is None
        self._menu: ft.PopupMenuButton | None = None
        self._build()

    @property
    def label(self) -> str:
        return self._label

    @property
    def options(self) -> list[PillOption]:
        return list(self._options)

    @property
    def read_only(self) -> bool:
        return self._read_only

    def set_label(self, label: str) -> None:
        if label == self._label:
            return
        self._label = label
        if self._label_text is not None:
            self._label_text.value = label
            try:
                self._label_text.update()
            except Exception:
                pass

    def set_options(self, options: list[PillOption]) -> None:
        new_options = list(options)
        if [(o.key, o.label) for o in new_options] == [
            (o.key, o.label) for o in self._options
        ]:
            return  # unchanged — don't rebuild the menu (would disrupt it if open)
        self._options = new_options
        if self._menu is not None:
            self._menu.items = [
                ft.PopupMenuItem(content=ft.Text(o.label), on_click=self._make_handler(o.key))
                for o in self._options
            ]
            try:
                self._menu.update()
            except Exception:
                pass

    def select(self, key: str) -> None:
        """Programmatically trigger a selection (used by tests + chip click)."""
        if self._on_select is None:
            return
        if any(o.key == key for o in self._options):
            self._on_select(key)

    # ------------------------------------------------------------------ Flet UI

    def _make_handler(self, key: str) -> Callable[[ft.ControlEvent], None]:
        def handler(_e: ft.ControlEvent) -> None:
            if self._on_select is not None:
                self._on_select(key)
        return handler

    def _build(self) -> None:
        self._label_text = ft.Text(
            self._label,
            size=12,
            weight=ft.FontWeight.W_500,
        )
        if self._read_only:
            # Display-only chip — same styling as the interactive pill but no
            # chevron and no PopupMenuButton (so it doesn't look clickable).
            self.content = ft.Container(
                content=ft.Row([self._label_text], spacing=2, tight=True),
                padding=ft.Padding(left=10, right=10, top=4, bottom=4),
                border=ft.Border(
                    left=ft.BorderSide(1, ft.Colors.OUTLINE_VARIANT),
                    right=ft.BorderSide(1, ft.Colors.OUTLINE_VARIANT),
                    top=ft.BorderSide(1, ft.Colors.OUTLINE_VARIANT),
                    bottom=ft.BorderSide(1, ft.Colors.OUTLINE_VARIANT),
                ),
                border_radius=14,
                bgcolor=ft.Colors.SURFACE_CONTAINER_HIGH,
            )
            return
        # The styled, bordered pill body is the *child* of the PopupMenuButton,
        # so the button's InkWell/tap target covers the entire visible pill.
        pill_body = ft.Container(
            content=ft.Row(
                [
                    self._label_text,
                    ft.Icon(ft.Icons.ARROW_DROP_DOWN, size=16),
                ],
                spacing=2,
                tight=True,
            ),
            padding=ft.Padding(left=10, right=10, top=4, bottom=4),
            border=ft.Border(
                left=ft.BorderSide(1, ft.Colors.OUTLINE_VARIANT),
                right=ft.BorderSide(1, ft.Colors.OUTLINE_VARIANT),
                top=ft.BorderSide(1, ft.Colors.OUTLINE_VARIANT),
                bottom=ft.BorderSide(1, ft.Colors.OUTLINE_VARIANT),
            ),
            border_radius=14,
            bgcolor=ft.Colors.SURFACE_CONTAINER_HIGH,
        )
        self._menu = ft.PopupMenuButton(
            items=[
                ft.PopupMenuItem(content=ft.Text(o.label), on_click=self._make_handler(o.key))
                for o in self._options
            ],
            content=pill_body,
            padding=0,
        )
        self.content = self._menu
