"""TopicsPanel — clickable list of active-sprint topics, grouped by status.

Sits in the right-pane Tabs alongside TasksPanel. Lets the user pin a
topic for the conversation manually (via POST /topic/set), overriding
TopicWorker's automatic detection for a short window.

The currently-active topic is highlighted (matches the topic on the
top bar). Status grouping mirrors the user's local-todo board layout —
columns + order come from MCP, not hardcoded, so custom statuses
(e.g. "Blocked") render correctly.

Like TasksPanel, the host screen is responsible for polling /topics
periodically and pushing the data via `set_topics(topics, columns)`.
Click handling is plumbed via the `on_pick` callback so the screen can
POST and optimistically update active state.
"""

from __future__ import annotations

from typing import Callable, Optional

import flet as ft


# Fallback color per column "kind" — only used when MCP didn't supply
# a color or supplied an unknown one. Real per-column colors come from
# MCP and are mapped via _RESOLVE_COLOR below.
_KIND_COLOR_FALLBACK = {
    "in_progress": "#f0b429",  # amber
    "todo":        "#6b7280",  # gray
    "done":        "#3fb950",  # green
}

# MCP color names → Flet hex. The MCP list_board_columns API returns
# tailwind-style names (slate, blue, purple, rose, emerald, amber, ...).
_COLOR_NAME_TO_HEX = {
    "slate":   "#94a3b8",
    "gray":    "#9ca3af",
    "stone":   "#a8a29e",
    "red":     "#ef4444",
    "rose":    "#f43f5e",
    "amber":   "#f0b429",
    "yellow":  "#eab308",
    "lime":    "#84cc16",
    "green":   "#22c55e",
    "emerald": "#3fb950",
    "teal":    "#14b8a6",
    "cyan":    "#06b6d4",
    "sky":     "#0ea5e9",
    "blue":    "#3b82f6",
    "indigo":  "#6366f1",
    "violet":  "#8b5cf6",
    "purple":  "#9f7aea",
    "fuchsia": "#d946ef",
    "pink":    "#ec4899",
}

# Active-topic highlight color (matches the SELF chat bubble + caption color).
_ACTIVE_COLOR = "#3fb950"


def _resolve_column_color(column: dict) -> str:
    """Pick a hex color for a column. MCP gives a tailwind-ish name; map
    it. Fall back to the column's `kind` color, then a neutral gray."""
    name = (column.get("color") or "").lower().strip()
    if name in _COLOR_NAME_TO_HEX:
        return _COLOR_NAME_TO_HEX[name]
    kind = (column.get("kind") or "").lower()
    return _KIND_COLOR_FALLBACK.get(kind, "#6b7280")


class TopicsPanel(ft.Column):
    """Status-grouped, clickable topic list. Highlights the active topic."""

    def __init__(
        self,
        on_pick: Callable[[dict], None],
        title: str = "Topics",
        expand: bool = True,
        on_indicator_click: Optional[Callable[[], None]] = None,
    ) -> None:
        super().__init__(spacing=8, expand=expand)
        self._title = title
        self._on_pick = on_pick
        self._on_indicator_click = on_indicator_click
        self._topics: list[dict] = []
        self._columns: list[dict] = []  # MCP-supplied per-board columns
        self._active_ticket_id: str = ""

        self._header = ft.Row(
            [ft.Text(title, size=14, weight=ft.FontWeight.W_600)],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        )
        # AUTO/MANUAL mode pill. Binary: AUTO (TopicWorker auto-picks) or
        # MANUAL (user-pinned, sticky). Click to toggle. No countdown.
        self._indicator_label = ft.Text(
            "AUTO",
            size=10,
            weight=ft.FontWeight.W_700,
            color=ft.Colors.ON_SURFACE_VARIANT,
        )
        self._indicator_bar = ft.Container(
            content=self._indicator_label,
            padding=ft.Padding.symmetric(horizontal=10, vertical=4),
            bgcolor=ft.Colors.SURFACE_CONTAINER_LOW,
            border_radius=4,
            ink=True,
            tooltip="Click to toggle AUTO / MANUAL",
            on_click=lambda _e: (
                self._on_indicator_click() if self._on_indicator_click else None
            ),
        )
        self._empty_state = ft.Text(
            "No active-sprint topics yet — start a session.",
            size=12, italic=True, color=ft.Colors.OUTLINE,
        )
        # ListView (not Column) so `scroll_to(key=...)` works for
        # bringing the active card into view when it's far down.
        self._list_view = ft.ListView(
            spacing=10,
            expand=expand,
            auto_scroll=False,
        )
        self.controls = [self._header, self._indicator_bar, self._empty_state, self._list_view]

    def set_topics(
        self,
        topics: list[dict],
        columns: Optional[list[dict]] = None,
    ) -> None:
        """Replace the displayed list. ``columns`` is the per-board
        status metadata from MCP (key, name, kind, color, position) —
        when present, sections render in MCP-configured order with the
        user's column names + colors. Falls back to discovered statuses
        in their first-seen order when columns is None/empty."""
        self._topics = list(topics)
        if columns is not None:
            self._columns = list(columns)
        self._empty_state.visible = not self._topics
        self._render()

    def set_indicator(self, manual: bool) -> None:
        """Update the AUTO/MANUAL pill. No countdown — just the binary state."""
        if manual:
            self._indicator_label.value = "MANUAL"
            self._indicator_label.color = _ACTIVE_COLOR
            self._indicator_bar.bgcolor = ft.Colors.with_opacity(0.10, _ACTIVE_COLOR)
        else:
            self._indicator_label.value = "AUTO"
            self._indicator_label.color = ft.Colors.ON_SURFACE_VARIANT
            self._indicator_bar.bgcolor = ft.Colors.SURFACE_CONTAINER_LOW
        try:
            if self.page is not None:
                self._indicator_bar.update()
        except Exception:
            pass

    def is_manual(self) -> bool:
        """Whether the pill currently shows MANUAL."""
        return self._indicator_label.value == "MANUAL"

    def set_active_ticket(self, ticket_id: str) -> None:
        """Mark which ticket is currently the active topic. Re-renders so
        the highlight tracks. Called on every WS `topic` event."""
        new_id = (ticket_id or "").strip()
        if new_id == self._active_ticket_id:
            return
        self._active_ticket_id = new_id
        self._render()
        # Scroll the now-active card into view if it's offscreen.
        # Flet's ListView.scroll_to(key=...) requires the target row to
        # carry a `key`. We set key=ticket_id on each row in _row().
        if new_id:
            try:
                self._list_view.scroll_to(key=new_id, duration=200)
            except Exception as exc:
                # Older Flet builds may not support key-based scroll —
                # silent fall-through, the highlight is still correct.
                import logging
                logging.getLogger(__name__).debug(
                    "topics scroll_to(%s) failed: %s", new_id, exc,
                )

    # ----- internals -----

    def _section_order(self) -> list[dict]:
        """Compute the order of status sections to render.

        Prefers the MCP-supplied ``self._columns`` (user's actual board
        layout, position-ordered). Falls back to a sensible default
        (in_progress → in_review → todo → done) when columns is empty,
        e.g. in tests or before the first /topics fetch lands.
        """
        if self._columns:
            # Sort by position, dedupe by key (multiple boards may share
            # a status key — keep the first encountered, since column
            # naming is usually consistent across a user's boards).
            seen: set[str] = set()
            ordered: list[dict] = []
            for c in sorted(self._columns, key=lambda c: c.get("position", 0)):
                key = (c.get("key") or "").lower()
                if not key or key in seen:
                    continue
                seen.add(key)
                ordered.append(c)
            return ordered
        # Fallback when columns aren't loaded yet.
        return [
            {"key": "in_progress", "name": "In progress", "kind": "in_progress"},
            {"key": "in_review",   "name": "In review",   "kind": "in_progress"},
            {"key": "todo",        "name": "Todo",        "kind": "todo"},
            {"key": "done",        "name": "Done",        "kind": "done"},
        ]

    def _render(self) -> None:
        sections_meta = self._section_order()
        section_keys = {c["key"] for c in sections_meta}

        # Group topics by status key; collect any unrecognized statuses
        # into an "Other" bucket at the end (defensive — data might
        # reference a status we don't have a column entry for).
        by_status: dict[str, list[dict]] = {c["key"]: [] for c in sections_meta}
        other: list[dict] = []
        for t in self._topics:
            status = (t.get("status") or "").lower()
            if status in section_keys:
                by_status[status].append(t)
            else:
                other.append(t)

        sections: list[ft.Control] = []
        for col in sections_meta:
            items = by_status.get(col["key"]) or []
            if not items:
                continue
            label = col.get("name") or col["key"].replace("_", " ").title()
            sections.append(self._section_header(label, len(items)))
            accent = _resolve_column_color(col)
            for t in items:
                sections.append(self._row(t, accent))
        if other:
            sections.append(self._section_header("Other", len(other)))
            for t in other:
                sections.append(self._row(t, "#6b7280"))

        self._list_view.controls = sections
        # Flet raises RuntimeError on `self.page` until the panel is
        # mounted, so guard with a try/except instead of `is not None`.
        try:
            if self.page is not None:
                self.page.update()
        except Exception:
            pass

    def _section_header(self, label: str, count: int) -> ft.Control:
        return ft.Container(
            content=ft.Row(
                [
                    ft.Text(
                        label.upper(),
                        size=10,
                        weight=ft.FontWeight.W_700,
                        color=ft.Colors.ON_SURFACE_VARIANT,
                    ),
                    ft.Text(
                        f"{count}",
                        size=10,
                        color=ft.Colors.OUTLINE,
                    ),
                ],
                spacing=6,
            ),
            padding=ft.Padding.only(top=8, bottom=2),
        )

    def _row(self, topic: dict, accent_default: str) -> ft.Container:
        ticket_id = str(topic.get("id") or "")
        title = topic.get("title") or "(untitled)"
        is_active = ticket_id == self._active_ticket_id

        # Active card gets the universal active-color highlight; inactive
        # cards get the column's MCP-configured color.
        accent = _ACTIVE_COLOR if is_active else accent_default
        # Tinted background for the active card so the user spots it
        # immediately without hunting; subtle for inactive cards.
        bg = (
            ft.Colors.with_opacity(0.10, _ACTIVE_COLOR)
            if is_active
            else ft.Colors.SURFACE_CONTAINER_LOWEST
        )

        children = [
            ft.Text(
                title,
                size=13,
                weight=ft.FontWeight.W_600 if is_active else ft.FontWeight.W_500,
                selectable=False,
                no_wrap=False,
                max_lines=3,
                overflow=ft.TextOverflow.ELLIPSIS,
            ),
        ]
        meta_parts: list[str] = []
        if ticket_id:
            meta_parts.append(f"#{ticket_id}")
        sprint = topic.get("sprint_name") or ""
        if sprint:
            meta_parts.append(sprint)
        if meta_parts:
            children.append(
                ft.Text(
                    "  ·  ".join(meta_parts),
                    size=10,
                    color=ft.Colors.OUTLINE,
                )
            )

        return ft.Container(
            # `key=ticket_id` makes the card targetable by scroll_to so
            # set_active_ticket() can bring it into view when offscreen.
            key=ticket_id or None,
            padding=ft.Padding.symmetric(horizontal=10, vertical=8),
            border=ft.Border.only(left=ft.BorderSide(3, accent)),
            border_radius=6,
            bgcolor=bg,
            content=ft.Column(children, spacing=3),
            ink=True,
            on_click=lambda _e, t=topic: self._handle_click(t),
            tooltip=f"Set as current topic: {title}",
        )

    def _handle_click(self, topic: dict) -> None:
        # Optimistic highlight — flip the active marker now so the user
        # gets instant feedback even before the daemon round-trip lands.
        new_id = str(topic.get("id") or "")
        self._active_ticket_id = new_id
        self._render()
        # Bring the picked card fully into view if the user clicked one
        # near the edge — set_active_ticket already scrolls on highlight
        # change, but we explicitly scroll here too because click → render
        # may not re-trigger the early-return-on-same-id path.
        if new_id:
            try:
                self._list_view.scroll_to(key=new_id, duration=200)
            except Exception:
                pass
        try:
            self._on_pick(topic)
        except Exception:
            # Caller is responsible for surfacing failures; we don't want
            # an exception from `on_pick` to wedge the panel.
            pass
