"""Reusable tasks panel — used on the Dashboard (live) and Recordings (past) screens."""

from __future__ import annotations

import subprocess

import flet as ft

TEAL = "#4ec9b0"


class TasksPanel(ft.Column):
    """List of extracted tasks with per-task and copy-all buttons.

    ``expand``: True (default) for the live Copilot side pane where the
    panel claims remaining height and the inner list scrolls. False for
    embedded use (e.g. Recordings detail) where the panel sizes to its
    content and the host page scrolls instead.
    """

    def __init__(self, title: str = "Tasks", expand: bool = True) -> None:
        super().__init__(spacing=8, expand=expand)
        self._title = title
        self._tasks: list[dict] = []
        self._expand = expand

        self._copy_all_btn = ft.TextButton(
            "Copy all",
            icon=ft.Icons.COPY_ALL,
            on_click=self._on_copy_all,
            disabled=True,
        )
        self._header = ft.Row(
            [
                ft.Text(title, size=14, weight=ft.FontWeight.W_600),
                self._copy_all_btn,
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        )

        self._empty_state = ft.Text(
            "No tasks yet — click Extract Task on the overlay.",
            size=12,
            italic=True,
            color=ft.Colors.OUTLINE,
        )

        self._list_column = ft.Column(
            spacing=6,
            scroll=ft.ScrollMode.AUTO if expand else None,
            expand=expand,
        )

        self.controls = [self._header, self._empty_state, self._list_column]

    def set_tasks(self, tasks: list[dict]) -> None:
        """Replace the displayed list."""
        self._tasks = list(tasks)
        self._copy_all_btn.disabled = not self._tasks
        self._empty_state.visible = not self._tasks
        self._list_column.controls = [self._row(t) for t in self._tasks]
        # Flet raises RuntimeError on `self.page` until the panel is
        # mounted. Wrap so callers can set tasks before mount (and tests
        # don't need a real Page).
        try:
            if self.page is not None:
                self.page.update()
        except Exception:
            pass

    def _row(self, task: dict) -> ft.Container:
        title = task.get("title") or task.get("text", "")
        description = task.get("description", "")
        quote = task.get("source_quote", "")
        children = [
            ft.Text(title, size=14, weight=ft.FontWeight.W_600, selectable=True),
        ]
        if description:
            children.append(
                ft.Text(description, size=12, selectable=True)
            )
        if quote:
            children.append(
                ft.Text(f"“{quote}”", size=10,
                        color=ft.Colors.OUTLINE, italic=True, selectable=True)
            )
        copy_payload = f"{title}\n{description}".strip() if description else title
        return ft.Container(
            padding=ft.Padding.symmetric(horizontal=10, vertical=8),
            border=ft.Border.all(1, ft.Colors.OUTLINE_VARIANT),
            border_radius=6,
            content=ft.Row(
                [
                    ft.Column(children, spacing=4, expand=True),
                    ft.IconButton(
                        icon=ft.Icons.CONTENT_COPY,
                        tooltip="Copy task",
                        on_click=lambda e, t=copy_payload: self._copy_to_clipboard(t),
                    ),
                ],
                vertical_alignment=ft.CrossAxisAlignment.START,
            ),
        )

    def _on_copy_all(self, e):
        lines = []
        for t in self._tasks:
            title = t.get("title") or t.get("text", "")
            desc = t.get("description", "")
            if not title:
                continue
            lines.append(f"- {title}" + (f" — {desc}" if desc else ""))
        self._copy_to_clipboard("\n".join(lines))

    def _copy_to_clipboard(self, text: str) -> None:
        if not text:
            return
        subprocess.run(["pbcopy"], input=text.encode(), check=True)
