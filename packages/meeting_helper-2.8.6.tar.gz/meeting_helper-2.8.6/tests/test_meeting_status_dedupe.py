"""Tests for the meeting_status WS event dedupe.

The bug: every WS reconnect triggered the daemon's late-joiner replay
(`{type: meeting_status, active: True, meeting_name: ...}`), which
unconditionally called `self._thread.clear()`. So a tab switch / WS
flap mid-meeting wiped the conversation. Fix: dedupe by meeting name —
only clear on a NEW meeting.
"""

from __future__ import annotations

import asyncio
from unittest.mock import MagicMock

import pytest


@pytest.fixture
def screen():
    from meeting_helper.flet_gui.screens.copilot import CopilotScreen
    page = MagicMock()
    page.run_thread = MagicMock()
    page.run_task = MagicMock()
    page.update = MagicMock()
    cfg = MagicMock()
    cfg.port = 7891
    cfg.local_todo_configured = True
    cfg.provider_configured = True
    return CopilotScreen(page, cfg)


def test_first_meeting_status_clears_thread(screen):
    asyncio.run(screen._dispatch_ws_event({
        "type": "meeting_status", "active": True, "meeting_name": "Alpha",
    }))
    assert screen._last_cleared_meeting_name == "Alpha"


def test_duplicate_meeting_status_does_not_re_clear(screen):
    """The user reported: switching tabs during a meeting cleared the
    conversation. Root cause was unconditional clear on every replay
    of meeting_status. With the dedupe, identical meeting_name skips."""
    # First meeting_status: clears.
    asyncio.run(screen._dispatch_ws_event({
        "type": "meeting_status", "active": True, "meeting_name": "Alpha",
    }))
    # User adds some content.
    screen._thread.append("you", "hello")
    # WS reconnect / replay sends meeting_status again with same name.
    asyncio.run(screen._dispatch_ws_event({
        "type": "meeting_status", "active": True, "meeting_name": "Alpha",
    }))
    # Conversation must still have the user's message — dedupe worked.
    assert any(t.text == "hello" for t in screen._thread.turns)


def test_different_meeting_name_does_clear(screen):
    """A genuine new meeting (different name) re-arms the clear."""
    asyncio.run(screen._dispatch_ws_event({
        "type": "meeting_status", "active": True, "meeting_name": "Alpha",
    }))
    screen._thread.append("you", "hello")
    asyncio.run(screen._dispatch_ws_event({
        "type": "meeting_status", "active": True, "meeting_name": "Beta",
    }))
    # New meeting → conversation should be cleared.
    assert all(t.text != "hello" for t in screen._thread.turns)
    assert screen._last_cleared_meeting_name == "Beta"


def test_meeting_ended_resets_dedupe(screen):
    """After meeting_ended, the next meeting_status (same name OR new)
    must clear properly — the dedupe sentinel resets."""
    asyncio.run(screen._dispatch_ws_event({
        "type": "meeting_status", "active": True, "meeting_name": "Alpha",
    }))
    # Sentinel set.
    assert screen._last_cleared_meeting_name == "Alpha"
    # End meeting.
    asyncio.run(screen._dispatch_ws_event({"type": "meeting_ended"}))
    # Sentinel reset → next meeting_status (even with same name "Alpha")
    # would clear again.
    assert screen._last_cleared_meeting_name is None
