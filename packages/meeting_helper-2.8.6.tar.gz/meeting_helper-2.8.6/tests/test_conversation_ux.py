"""Tests for the round-2 UX changes in ConversationThread / ConversationView.

Covers:
- Merged-turn length cap (no more wall-of-text bubbles).
- Autoscroll follow-state stays armed during content growth (only user-
  initiated scroll-up disarms it).
- scroll_to_bottom debounce: concurrent calls coalesce.
"""

from __future__ import annotations

import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest


def test_merged_turn_capped_at_max_chars():
    """Long monologues split into multiple bubbles instead of one
    growing wall-of-text. A 90-second speaker who'd previously be one
    bubble now becomes 2-3 readable groups."""
    from meeting_helper.flet_gui.components.conversation import ConversationThread

    thread = ConversationThread()

    # First sentence: new turn.
    turn1, extended1 = thread.append_or_extend_transcript("self", "First piece.")
    assert extended1 is False

    # Add sentences until just under the cap. They merge into turn1.
    chunk = "another piece of speech " * 5  # ~120 chars
    for _ in range(2):
        turn, extended = thread.append_or_extend_transcript("self", chunk)
        assert extended is True
        assert turn is turn1

    # Now turn1.text is well past 200 chars. Adding more should still merge
    # while under MAX_MERGED_TURN_CHARS (400).
    if len(turn1.text) < ConversationThread.MAX_MERGED_TURN_CHARS:
        turn, extended = thread.append_or_extend_transcript("self", chunk)
    # Once merged_text exceeds the cap, the next sentence MUST start a
    # fresh turn — even though same speaker, even though within burst window.
    while len(turn1.text) < ConversationThread.MAX_MERGED_TURN_CHARS:
        turn1.text += " filler"
    next_turn, extended = thread.append_or_extend_transcript("self", "Next bubble starts here.")
    assert extended is False
    assert next_turn is not turn1


def test_self_bubble_has_width_cap_via_flex_so_long_text_wraps():
    """SELF turns are right-aligned in a Row with [spacer expand=1, bubble
    expand=4] so the bubble caps at ~80% of the conversation width.

    Without an expand ratio (earlier draft used expand=False) the bubble
    grew to fit its content unbounded, so a long sentence overflowed the
    right edge — visible symptom: text cut off mid-word ("string typ...")
    on the user's screen.
    """
    import flet as ft
    from meeting_helper.flet_gui.components.conversation import (
        ConversationThread, ConversationView, Turn,
    )

    view = ConversationView(ConversationThread())
    long_text = (
        "the method was log event attribute no bank string for no bank string "
        "for target it accept the it don't accept the string types unless they "
        "matched a small whitelist."
    )
    turn = Turn(role="self", text=long_text)

    wrapped, body, _ = view._build_turn(turn)
    # Outer wrapper must be a Row (right-align mechanism).
    assert isinstance(wrapped, ft.Row)
    # Bubble (the second element) must have a flex value > 1 so it has
    # a bounded width — guarantees wrap.
    bubble = wrapped.controls[1]
    assert getattr(bubble, "expand", None) and bubble.expand >= 2, \
        f"SELF bubble must have flex >=2 so text wraps; got expand={getattr(bubble,'expand',None)!r}"


def test_other_speaker_still_starts_fresh_turn():
    """Burst-merge only applies within the same speaker. A different
    speaker always opens a new bubble, regardless of length."""
    from meeting_helper.flet_gui.components.conversation import ConversationThread

    thread = ConversationThread()
    thread.append_or_extend_transcript("self", "Hello")
    other_turn, extended = thread.append_or_extend_transcript("other", "Hi back")
    assert extended is False
    assert other_turn.role == "other"


# ---------------------------------------------------------------------------
# Autoscroll follow-state
# ---------------------------------------------------------------------------

def _make_view():
    from meeting_helper.flet_gui.components.conversation import (
        ConversationThread, ConversationView,
    )
    return ConversationView(ConversationThread())


def test_follow_state_stays_armed_when_content_grows_without_user_scroll():
    """Critical: when AI streaming pushes the bottom past the threshold
    between an autoscroll dispatch and its landing, the follow state must
    NOT flip off. Old behavior was a ping-pong that stranded the user
    mid-chat. New behavior gates on negative scroll_delta (user scroll-up)."""
    view = _make_view()
    view._set_following(True)

    # Simulate an event that COULD look like "user scrolled away" but is
    # really just content growth (no user delta).
    fake_event = SimpleNamespace(
        max_scroll_extent=1000.0,
        pixels=800.0,  # 200 px from bottom — well past the 60 px threshold
        scroll_delta=0,  # NOT user-initiated
    )
    view._handle_scroll(fake_event)
    assert view.is_following() is True


def test_follow_state_disarms_on_user_scroll_up():
    """Real user scroll-up (negative delta) does disarm follow."""
    view = _make_view()
    view._set_following(True)

    fake_event = SimpleNamespace(
        max_scroll_extent=1000.0,
        pixels=200.0,  # well above the bottom
        scroll_delta=-150,  # user scrolled up
    )
    view._handle_scroll(fake_event)
    assert view.is_following() is False


def test_follow_state_rearms_when_user_scrolls_back_to_bottom():
    """When a user scrolls back near the bottom, follow re-arms even
    without an explicit user gesture (passive landing at bottom counts)."""
    view = _make_view()
    view._set_following(False)

    fake_event = SimpleNamespace(
        max_scroll_extent=1000.0,
        pixels=970.0,  # within 60px of bottom
        scroll_delta=0,
    )
    view._handle_scroll(fake_event)
    assert view.is_following() is True


# ---------------------------------------------------------------------------
# scroll_to_bottom debounce
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_scroll_to_bottom_coalesces_concurrent_calls():
    """During chunk-burst + transcript-burst the GUI used to fire 10-20
    scroll_to IPC calls per second. Debounce: only one in flight at a time."""
    view = _make_view()
    # Mock the underlying ListView.scroll_to as an awaitable that
    # records call count.
    view._list = MagicMock()
    call_count = {"n": 0}

    async def fake_scroll_to(**kwargs):
        call_count["n"] += 1
        # Simulate ~one paint frame of latency.
        await asyncio.sleep(0.01)

    view._list.scroll_to = fake_scroll_to

    # Fire 5 concurrent calls — only one should land.
    await asyncio.gather(*[view.scroll_to_bottom() for _ in range(5)])
    assert call_count["n"] == 1
    # After completion, _scroll_pending must be cleared so subsequent
    # calls work.
    assert view._scroll_pending is False
    await view.scroll_to_bottom()
    assert call_count["n"] == 2


# ---------------------------------------------------------------------------
# Multi-answer carousel rendering
# ---------------------------------------------------------------------------

def _carousel_thread():
    from meeting_helper.flet_gui.components.conversation import ConversationThread
    t = ConversationThread()
    t.begin_streaming("ai")
    t.open_answer("A", provider="claude", model="sonnet-4-6")
    t.append_chunk_to_answer("A", "alpha answer")
    t.set_answer_latency("A", 420)
    t.open_answer("B", provider="gemini", model="flash")
    t.append_chunk_to_answer("B", "beta answer")
    return t


def test_single_answer_turn_renders_provider_caption():
    import flet as ft
    from meeting_helper.flet_gui.components.conversation import (
        ConversationThread, ConversationView,
    )
    t = ConversationThread()
    t.begin_streaming("ai")
    t.open_answer("A", provider="claude", model="sonnet-4-6")
    t.append_chunk_to_answer("A", "solo answer")
    t.set_answer_latency("A", 410)
    view = ConversationView(t)
    turn = t.turns[-1]
    bubble, body, _ = view._build_turn(turn)
    # No carousel arrows for a single answer.
    flat = repr(bubble)
    assert "CHEVRON" not in flat.upper()
    # Body shows the visible answer's text.
    assert isinstance(body, ft.Markdown) and body.value == "solo answer"


def test_two_answer_turn_renders_chevrons_and_switches():
    import flet as ft
    from meeting_helper.flet_gui.components.conversation import ConversationView
    t = _carousel_thread()
    view = ConversationView(t)
    turn = t.turns[-1]
    view.notify_appended(turn)
    bubble, body, _ = view._build_turn(turn)
    # Visible answer defaults to the primary (A).
    assert isinstance(body, ft.Markdown) and body.value == "alpha answer"
    # The answer header row has two IconButtons (chevrons).
    # Find the answer-header row inside the bubble column.
    col = bubble.content
    icon_buttons = []
    for ctrl in col.controls:
        if isinstance(ctrl, ft.Row):
            for sub in ctrl.controls:
                if isinstance(sub, ft.IconButton):
                    icon_buttons.append(sub)
    assert len(icon_buttons) == 2
    left, right = icon_buttons
    assert left.disabled is True   # at index 0
    assert right.disabled is False
    # Click "next" — switches to B and rebuilds the row.
    right.on_click(None)
    new_bubble, new_body, _ = view._build_turn(turn)
    assert turn.visible_answer_index == 1
    assert isinstance(new_body, ft.Markdown) and new_body.value == "beta answer"


def test_errored_visible_answer_renders_error_caption():
    import flet as ft
    from meeting_helper.flet_gui.components.conversation import (
        ConversationThread, ConversationView,
    )
    t = ConversationThread()
    t.begin_streaming("ai")
    t.open_answer("A", provider="claude", model="m")
    t.set_answer_error("A", "boom")
    view = ConversationView(t)
    turn = t.turns[-1]
    _bubble, body, _ = view._build_turn(turn)
    assert isinstance(body, ft.Text)
    assert "boom" in body.value and "Claude" in body.value


def test_notify_updated_rebuilds_carousel_turn():
    from meeting_helper.flet_gui.components.conversation import ConversationView
    t = _carousel_thread()
    view = ConversationView(t)
    turn = t.turns[-1]
    view.notify_appended(turn)
    old_row = view._row_for_turn[id(turn)][0]
    # A new chunk on B → notify_updated should rebuild (carousel turn).
    t.append_chunk_to_answer("B", " more")
    view.notify_updated(turn)
    new_row = view._row_for_turn[id(turn)][0]
    assert new_row is not old_row
