"""Tests for CopilotScreen._dispatch_ws_event handlers.

These exercise the WS message → UI state path without a real Page or daemon.
The _dispatch_ws_event method is async; we run each handler under
asyncio.run with mocked dependencies.
"""

from __future__ import annotations

import asyncio
from unittest.mock import MagicMock

import pytest


@pytest.fixture
def screen():
    from meeting_helper.flet_gui.screens.copilot import CopilotScreen

    page = MagicMock()
    page.run_thread = MagicMock()
    page.run_task = MagicMock()
    page.update = MagicMock()
    cfg = MagicMock()
    cfg.port = 7891
    cfg.local_todo_configured = True
    cfg.provider_configured = True
    return CopilotScreen(page, cfg)


def test_transcriber_dead_event_marks_pill(screen):
    """The transcriber_dead listener must annotate the pill so the user
    sees the failure (this is the A1 self-inflicted gap from 9c03d13)."""
    asyncio.run(
        screen._dispatch_ws_event({
            "type": "transcriber_dead",
            "role": "self",
            "reason": "reconnect_exhausted",
        })
    )
    assert "⚠" in screen._transcriber_pill.label
    assert "self" in screen._transcriber_pill.label.lower()


def test_transcriber_dead_event_idempotent(screen):
    """Repeated transcriber_dead events shouldn't keep appending warning
    markers ('Deepgram ⚠ self ⚠ self ⚠ self...')."""
    asyncio.run(screen._dispatch_ws_event({"type": "transcriber_dead", "role": "self"}))
    label_after_first = screen._transcriber_pill.label
    asyncio.run(screen._dispatch_ws_event({"type": "transcriber_dead", "role": "self"}))
    assert screen._transcriber_pill.label == label_after_first


def test_interim_transcript_appears_in_caption_bar(screen):
    """Phase 1 fix: interim transcripts are NOT silently dropped — they
    render into the live caption bar so users see words within ~200 ms
    instead of waiting 1–3 s for finals.

    Bar visibility is now gated on session_active via update_status; the
    dispatch handler doesn't toggle it. We simulate a meeting being active
    before checking the visible flag."""
    screen.update_status(daemon_running=True, session_active=True, meeting_name="Test")
    asyncio.run(
        screen._dispatch_ws_event({
            "type": "transcript",
            "role": "self",
            "text": "hello there",
            "interim": True,
        })
    )
    assert "hello there" in screen._self_interim_text.value
    # And the bar is visible because update_status set it (session active).
    assert screen._live_caption_bar.visible is True


def test_final_transcript_clears_role_interim(screen):
    """When a final lands the corresponding role's interim must clear,
    so the caption bar doesn't keep the half-typed sentence forever."""
    # Set up an interim first.
    asyncio.run(screen._dispatch_ws_event({
        "type": "transcript", "role": "self",
        "text": "half-typed", "interim": True,
    }))
    assert screen._self_interim_text.value
    # Now a final.
    asyncio.run(screen._dispatch_ws_event({
        "type": "transcript", "role": "self",
        "text": "Final sentence.", "interim": False,
    }))
    assert screen._self_interim_text.value == ""


def test_other_role_interim_independent_from_self(screen):
    """Self and other interim slots are independent; an interim from one
    must not clear the other."""
    asyncio.run(screen._dispatch_ws_event({
        "type": "transcript", "role": "self",
        "text": "I'm talking", "interim": True,
    }))
    asyncio.run(screen._dispatch_ws_event({
        "type": "transcript", "role": "other",
        "text": "they're talking", "interim": True,
    }))
    assert screen._self_interim_text.value
    assert screen._other_interim_text.value
    # Final on `self` must not clear `other`.
    asyncio.run(screen._dispatch_ws_event({
        "type": "transcript", "role": "self",
        "text": "self final", "interim": False,
    }))
    assert screen._self_interim_text.value == ""
    assert screen._other_interim_text.value  # still set


def test_unknown_role_is_ignored(screen):
    """Bogus role values shouldn't blow up the dispatcher."""
    asyncio.run(screen._dispatch_ws_event({
        "type": "transcript", "role": "bystander",
        "text": "x", "interim": True,
    }))
    assert screen._self_interim_text.value == ""
    assert screen._other_interim_text.value == ""


# ---------------------------------------------------------------------------
# ai_latency event → first-token badge
# ---------------------------------------------------------------------------

def test_ai_latency_event_stamps_streaming_turn(screen):
    asyncio.run(screen._dispatch_ws_event({"type": "start"}))
    asyncio.run(screen._dispatch_ws_event({"type": "ai_latency", "first_token_ms": 372}))
    turns = screen._thread.turns
    assert len(turns) == 1
    assert turns[0].role == "ai"
    assert turns[0].first_token_ms == 372
    # The header badge widget reflects it.
    latency_text = screen._view._latency_for_turn.get(id(turns[0]))
    assert latency_text is not None and "372" in latency_text.value


def test_ai_latency_event_without_streaming_turn_is_ignored(screen):
    # No prior `start` → nothing streaming. Must not raise or create a turn.
    asyncio.run(screen._dispatch_ws_event({"type": "ai_latency", "first_token_ms": 100}))
    assert screen._thread.turns == []


def test_ai_latency_event_ignores_non_numeric_payload(screen):
    asyncio.run(screen._dispatch_ws_event({"type": "start"}))
    asyncio.run(screen._dispatch_ws_event({"type": "ai_latency", "first_token_ms": "oops"}))
    assert screen._thread.turns[0].first_token_ms is None


# ---------------------------------------------------------------------------
# Cascade wire protocol: answer_open / chunk+answer_id / per-answer done /
# all_done — the multi-answer carousel path.
# ---------------------------------------------------------------------------

# The plan refers to the screen fixture as `copilot_screen`; alias it.
@pytest.fixture
def copilot_screen(screen):
    return screen


async def test_dispatch_answer_open_and_chunk(copilot_screen):
    """answer_open registers an Answer; chunk with answer_id appends to it;
    two answers stay isolated; all_done ends streaming."""
    scr = copilot_screen
    await scr._dispatch_ws_event({"type": "start"})
    await scr._dispatch_ws_event({"type": "answer_open", "answer_id": "A",
                                  "provider": "claude", "model": "sonnet-4-6"})
    await scr._dispatch_ws_event({"type": "chunk", "answer_id": "A", "text": "Hi"})
    await scr._dispatch_ws_event({"type": "answer_open", "answer_id": "B",
                                  "provider": "gemini", "model": "flash"})
    await scr._dispatch_ws_event({"type": "chunk", "answer_id": "B", "text": "Yo"})
    await scr._dispatch_ws_event({"type": "all_done"})
    turn = scr._thread.turns[-1]
    assert [a.answer_id for a in turn.answers] == ["A", "B"]
    assert turn.answers[0].text == "Hi" and turn.answers[1].text == "Yo"
    assert turn.answers[0].provider == "claude" and turn.answers[0].model == "sonnet-4-6"
    assert turn.answers[1].provider == "gemini"
    # Streaming closed.
    assert scr._thread.streaming_turn is None


async def test_dispatch_chunk_without_answer_id_is_legacy(copilot_screen):
    scr = copilot_screen
    await scr._dispatch_ws_event({"type": "start"})
    await scr._dispatch_ws_event({"type": "chunk", "text": "plain"})
    assert scr._thread.turns[-1].text == "plain"
    assert scr._thread.turns[-1].answers == []


async def test_dispatch_per_answer_done_stamps_latency(copilot_screen):
    scr = copilot_screen
    await scr._dispatch_ws_event({"type": "start"})
    await scr._dispatch_ws_event({"type": "answer_open", "answer_id": "A",
                                  "provider": "claude", "model": "m"})
    await scr._dispatch_ws_event({"type": "chunk", "answer_id": "A", "text": "x"})
    await scr._dispatch_ws_event({"type": "done", "answer_id": "A",
                                  "first_token_ms": 410})
    await scr._dispatch_ws_event({"type": "all_done"})
    assert scr._thread.turns[-1].answers[0].first_token_ms == 410


async def test_dispatch_legacy_done_with_cards_still_works(copilot_screen):
    scr = copilot_screen
    await scr._dispatch_ws_event({"type": "start"})
    await scr._dispatch_ws_event({"type": "chunk", "text": "answer body"})
    await scr._dispatch_ws_event({"type": "done", "cards": [{"id": "X-1", "title": "T"}]})
    turn = scr._thread.turns[-1]
    assert turn.text == "answer body"
    assert turn.cards == [{"id": "X-1", "title": "T"}]
    assert scr._thread.streaming_turn is None
