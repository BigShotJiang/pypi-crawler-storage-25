"""Tests for the auto-rename plumbing on meeting end.

Covers the pure helpers in session.py (`_rename_meeting_artifacts`,
`_has_ai_provider`) and the AI client's name cleaner.
"""

from __future__ import annotations

from pathlib import Path

from meeting_helper.ai.client import _clean_meeting_name
from meeting_helper.config import AppConfig
from meeting_helper.session import _has_ai_provider, _rename_meeting_artifacts


# ---------------------------------------------------------------------------
# _clean_meeting_name
# ---------------------------------------------------------------------------

def test_clean_meeting_name_strips_quotes_and_punctuation():
    assert _clean_meeting_name('"Payments API Migration"') == "Payments API Migration"
    assert _clean_meeting_name("Payments API Migration.") == "Payments API Migration"
    assert _clean_meeting_name("`Payments API Sync`") == "Payments API Sync"


def test_clean_meeting_name_caps_at_eight_words():
    raw = "one two three four five six seven eight nine ten"
    assert _clean_meeting_name(raw).split() == [
        "one", "two", "three", "four", "five", "six", "seven", "eight",
    ]


def test_clean_meeting_name_drops_non_ascii():
    assert _clean_meeting_name("Reunião Semanal Equipe") == "Reuni o Semanal Equipe"


def test_clean_meeting_name_handles_empty():
    assert _clean_meeting_name("") == ""
    assert _clean_meeting_name("   \n\n") == ""
    # Punctuation-only collapses to empty
    assert _clean_meeting_name("---") == ""


def test_clean_meeting_name_takes_first_line():
    assert _clean_meeting_name("Payments Sync\nExtra junk\nMore") == "Payments Sync"


# ---------------------------------------------------------------------------
# _has_ai_provider
# ---------------------------------------------------------------------------

def test_has_ai_provider_anthropic():
    assert _has_ai_provider(AppConfig(anthropic_api_key="sk-x")) is True


def test_has_ai_provider_google():
    assert _has_ai_provider(AppConfig(google_api_key="g-x")) is True


def test_has_ai_provider_local():
    assert _has_ai_provider(AppConfig(preferred_provider="local")) is True


def test_has_ai_provider_none():
    assert _has_ai_provider(AppConfig()) is False


# ---------------------------------------------------------------------------
# _rename_meeting_artifacts
# ---------------------------------------------------------------------------

def _touch(p: Path, body: str = "x") -> None:
    p.write_text(body)


def test_rename_artifacts_renames_full_set(tmp_path):
    base = tmp_path / "2026-05-13_143000_Old_Title.mp3"
    _touch(base)
    _touch(base.with_suffix(".live.txt"))
    _touch(base.with_suffix(".transcript.txt"))
    _touch(base.with_suffix(".summary.txt"))
    _touch(base.with_suffix(".tasks.json"))

    new_mp3 = _rename_meeting_artifacts(base, "Payments API Migration")
    assert new_mp3 is not None
    assert new_mp3.name == "2026-05-13_143000_Payments_API_Migration.mp3"
    for suffix in (".mp3", ".live.txt", ".transcript.txt", ".summary.txt", ".tasks.json"):
        assert (tmp_path / f"2026-05-13_143000_Payments_API_Migration{suffix}").exists()
        assert not base.with_suffix(suffix).exists()


def test_rename_artifacts_renames_when_only_mp3_exists(tmp_path):
    base = tmp_path / "2026-05-13_143000.mp3"
    _touch(base)

    new_mp3 = _rename_meeting_artifacts(base, "Standup")
    assert new_mp3 is not None
    assert new_mp3.name == "2026-05-13_143000_Standup.mp3"


def test_rename_artifacts_skips_when_no_timestamp_prefix(tmp_path):
    base = tmp_path / "MyRecording.mp3"
    _touch(base)
    assert _rename_meeting_artifacts(base, "Something") is None
    assert base.exists()


def test_rename_artifacts_skips_when_label_sanitizes_to_empty(tmp_path):
    base = tmp_path / "2026-05-13_143000.mp3"
    _touch(base)
    assert _rename_meeting_artifacts(base, "!!! ???") is None
    assert base.exists()


def test_rename_artifacts_skips_on_collision(tmp_path):
    base = tmp_path / "2026-05-13_143000_Old.mp3"
    _touch(base)
    # Pre-create the destination file
    _touch(tmp_path / "2026-05-13_143000_New.mp3")
    assert _rename_meeting_artifacts(base, "New") is None
    assert base.exists()


def test_rename_artifacts_no_op_when_label_unchanged(tmp_path):
    base = tmp_path / "2026-05-13_143000_Sync.mp3"
    _touch(base)
    assert _rename_meeting_artifacts(base, "Sync") is None
    assert base.exists()
