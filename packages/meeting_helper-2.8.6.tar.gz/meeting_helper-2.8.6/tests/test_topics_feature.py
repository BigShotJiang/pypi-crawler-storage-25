"""Tests for the Topics tab feature.

Covers:
- GET /topics returns the slim shape the panel expects.
- POST /topic/set updates state, broadcasts, and pins manual_until.
- TopicWorker._run skips when manual_until is in the future.
- TopicsPanel constructs, set_topics groups by status, click → on_pick.
"""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


@pytest.fixture(autouse=True)
def _reset_global_state_after_each_test():
    """Reset shared module-level state on teardown so a failing assertion
    can't pollute later tests with a stale manual pin / hydrated cards /
    leftover local_todo mock. Inline cleanup at the end of each test only
    fired on success — the autouse `try/finally` here fires unconditionally.
    """
    from meeting_helper.state import state as global_state
    yield
    global_state.topic_manual_mode = False
    global_state.current_topic_cards = []
    global_state.local_todo = None
    global_state.current_topic = {
        "topic": "", "ticket_ids": [], "search_query": "", "last_user_statement": "",
    }


# ---------------------------------------------------------------------------
# /topics endpoint
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_topics_endpoint_returns_slim_topics(aiohttp_client):
    from aiohttp import web
    from meeting_helper.server.routes import setup_routes
    from meeting_helper.state import state as global_state

    fake_local_todo = MagicMock()
    fake_local_todo.my_active_tasks = AsyncMock(return_value=[
        {
            "id": "PROJ-1", "title": "Auth refactor", "status": "in_progress",
            "priority": "high", "board_id": 2, "board_name": "Engineering",
            "sprint_name": "W19", "url": "https://x.test/PROJ-1",
            "extra": "ignored", "search_tsv": "noise",
        },
        {
            "id": "PROJ-2", "title": "Docs cleanup", "status": "todo",
            "board_id": 2,
        },
    ])
    # Endpoint now also fetches per-board columns from MCP — provide a
    # stub so the call resolves quickly. Returns the schema MCP actually
    # produces (key, name, kind, color, position).
    fake_local_todo.list_board_columns = AsyncMock(return_value=[
        {"key": "todo", "name": "Todo", "kind": "todo", "color": "slate", "position": 0},
        {"key": "in_progress", "name": "In Progress", "kind": "in_progress", "color": "blue", "position": 1},
        {"key": "done", "name": "Done", "kind": "done", "color": "emerald", "position": 4},
    ])
    global_state.local_todo = fake_local_todo

    class FakeConfig:
        anthropic_api_key = "x"

    app = web.Application()
    app["config"] = FakeConfig()
    setup_routes(app)
    client = await aiohttp_client(app)

    resp = await client.get("/topics")
    assert resp.status == 200
    body = await resp.json()
    topics = body["topics"]
    columns = body["columns"]
    assert len(topics) == 2
    # Columns flowed through with the MCP shape (key/name/kind/color/position).
    assert len(columns) == 3
    assert {c["key"] for c in columns} == {"todo", "in_progress", "done"}
    # Slim shape — only the fields TopicsPanel needs.
    t0 = topics[0]
    assert set(t0.keys()) == {
        "id", "title", "status", "priority", "board_id", "board_name",
        "sprint_name", "url",
    }
    assert t0["id"] == "PROJ-1"
    assert t0["status"] == "in_progress"
    # No raw search_tsv leaking out.
    assert "search_tsv" not in t0


@pytest.mark.asyncio
async def test_topics_endpoint_503_when_local_todo_missing(aiohttp_client):
    from aiohttp import web
    from meeting_helper.server.routes import setup_routes
    from meeting_helper.state import state as global_state

    global_state.local_todo = None

    class FakeConfig:
        anthropic_api_key = "x"

    app = web.Application()
    app["config"] = FakeConfig()
    setup_routes(app)
    client = await aiohttp_client(app)

    resp = await client.get("/topics")
    assert resp.status == 503


# ---------------------------------------------------------------------------
# /topic/set endpoint
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_topic_set_pins_state_and_broadcasts(aiohttp_client):
    from aiohttp import web
    from meeting_helper.server.routes import setup_routes
    from meeting_helper.state import state as global_state

    class FakeConfig:
        anthropic_api_key = "x"

    app = web.Application()
    app["config"] = FakeConfig()
    setup_routes(app)
    client = await aiohttp_client(app)

    # Capture broadcasts + a hydrated card from local-todo.
    broadcasts: list[dict] = []

    async def fake_broadcast(message: dict) -> None:
        broadcasts.append(message)

    fake_local_todo = MagicMock()
    fake_local_todo.get = AsyncMock(return_value={
        "id": "ENGT-99",
        "title": "Auth refactor",
        "body_md": "Replace token refresh with rotating session id.",
        "status": "in_progress",
        "comments": [
            {"body": "PR up at #1234", "created_at": "2024-01-01"},
        ],
        "subtasks": [],
    })
    global_state.local_todo = fake_local_todo

    with patch("meeting_helper.server.websocket.broadcast", side_effect=fake_broadcast):
        resp = await client.post(
            "/topic/set",
            json={"ticket_id": "ENGT-99", "title": "Auth refactor", "board_id": 2},
        )

    assert resp.status == 200
    body = await resp.json()
    assert body["ok"] is True
    # State is pinned.
    assert global_state.current_topic["topic"] == "Auth refactor"
    assert global_state.current_topic["ticket_ids"] == ["ENGT-99"]
    assert global_state.current_topic["manual"] is True
    # MANUAL mode is sticky — no countdown, just a boolean flag.
    assert global_state.topic_manual_mode is True
    # Card hydrated — AI now has body+comments grounding context, not just
    # a topic string. This is the bug-fix this test was added for.
    assert len(global_state.current_topic_cards) == 1
    card = global_state.current_topic_cards[0]
    assert card["id"] == "ENGT-99"
    assert "Replace token refresh" in (card.get("body_md") or "")
    assert len(card.get("comments") or []) == 1
    fake_local_todo.get.assert_awaited_once_with("task", "ENGT-99", 2)
    # Broadcast fired with the right payload.
    topic_broadcasts = [b for b in broadcasts if b.get("type") == "topic"]
    assert len(topic_broadcasts) == 1
    assert topic_broadcasts[0]["topic"] == "Auth refactor"
    assert topic_broadcasts[0]["manual"] is True
    # autouse fixture handles cleanup


@pytest.mark.asyncio
async def test_topic_set_falls_back_to_thin_card_when_hydrate_fails(aiohttp_client):
    """If get_task fails (timeout, board mismatch, MCP wedged) the manual
    pin still happens — AI gets a thin card with title only instead of
    the topic vanishing entirely."""
    from aiohttp import web
    from meeting_helper.server.routes import setup_routes
    from meeting_helper.state import state as global_state

    fake_local_todo = MagicMock()
    fake_local_todo.get = AsyncMock(side_effect=RuntimeError("MCP wedged"))
    global_state.local_todo = fake_local_todo

    class FakeConfig:
        anthropic_api_key = "x"

    app = web.Application()
    app["config"] = FakeConfig()
    setup_routes(app)
    client = await aiohttp_client(app)

    with patch("meeting_helper.server.websocket.broadcast", new=AsyncMock()):
        resp = await client.post(
            "/topic/set",
            json={"ticket_id": "X-1", "title": "Fallback", "board_id": 5},
        )
    assert resp.status == 200
    # Pin still happened — single thin card with the title we sent.
    assert len(global_state.current_topic_cards) == 1
    assert global_state.current_topic_cards[0]["id"] == "X-1"
    assert global_state.current_topic_cards[0]["title"] == "Fallback"
    # autouse fixture handles cleanup


@pytest.mark.asyncio
async def test_pre_flight_topic_refresh_skips_during_manual_pin():
    """Critical: when topic_manual_mode is True, the pre-flight refresh on
    /query MUST skip its LLM pick. Without this gate every query overwrote
    the user's pinned topic with whatever the picker inferred from recent
    transcript noise."""
    from meeting_helper.ai.client import _pre_flight_topic_refresh
    from meeting_helper.state import state

    state.local_todo = MagicMock()  # non-None so the early-return on
                                    # local_todo is None doesn't fire
    state.topic_manual_mode = True

    with patch("meeting_helper.ai.client.pick_topic_ticket") as mock_pick, \
         patch("meeting_helper.ai.client.refresh_sprint_tickets") as mock_refresh:
        await _pre_flight_topic_refresh(state, MagicMock(), question="any")

    mock_pick.assert_not_called()
    mock_refresh.assert_not_called()
    # autouse fixture handles cleanup


@pytest.mark.asyncio
async def test_topic_set_400_on_missing_title(aiohttp_client):
    from aiohttp import web
    from meeting_helper.server.routes import setup_routes

    class FakeConfig:
        anthropic_api_key = "x"

    app = web.Application()
    app["config"] = FakeConfig()
    setup_routes(app)
    client = await aiohttp_client(app)

    resp = await client.post("/topic/set", json={"ticket_id": "X-1"})
    assert resp.status == 400


# ---------------------------------------------------------------------------
# TopicWorker manual-pin gate
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_topic_worker_skips_during_manual_pin():
    """When state.topic_manual_mode is True, _run must return early
    without calling pick_topic_ticket. Otherwise the user's pinned
    selection gets stomped on the next tick."""
    from meeting_helper.topic_worker import TopicWorker
    from meeting_helper.buffer import SentenceBuffer
    from meeting_helper.state import state

    config = MagicMock()
    buf = SentenceBuffer(role="self")
    worker = TopicWorker(config=config, self_buffer=buf)
    worker._enabled = True

    state.topic_manual_mode = True

    with patch("meeting_helper.ai.client.pick_topic_ticket") as mock_pick, \
         patch("meeting_helper.ai.client.refresh_sprint_tickets"):
        await worker._run()

    mock_pick.assert_not_called()
    # autouse fixture handles cleanup


# ---------------------------------------------------------------------------
# TopicsPanel component
# ---------------------------------------------------------------------------

def test_topics_panel_constructs_and_groups_by_status():
    """Panel renders distinct sections for each status it has data for."""
    from meeting_helper.flet_gui.components.topics_panel import TopicsPanel

    picks: list[dict] = []
    panel = TopicsPanel(on_pick=lambda t: picks.append(t))
    panel.set_topics([
        {"id": "1", "title": "A", "status": "in_progress"},
        {"id": "2", "title": "B", "status": "todo"},
        {"id": "3", "title": "C", "status": "in_progress"},
        {"id": "4", "title": "D", "status": "in_review"},
    ])
    # 3 section headers (in_progress, in_review, todo) + 4 rows = 7 controls.
    # Rendering order is by status priority — section headers interleave.
    # `_list_view` is the ListView holding the rendered rows.
    assert len(panel._list_view.controls) == 7


def test_topics_panel_active_highlight_via_set_active_ticket():
    """set_active_ticket re-renders so the highlighted card matches the
    daemon's current_topic broadcast."""
    from meeting_helper.flet_gui.components.topics_panel import TopicsPanel

    panel = TopicsPanel(on_pick=lambda _t: None)
    panel.set_topics([
        {"id": "1", "title": "A", "status": "in_progress"},
        {"id": "2", "title": "B", "status": "in_progress"},
    ])
    panel.set_active_ticket("2")
    assert panel._active_ticket_id == "2"
    # set_active_ticket with the same id is a no-op (avoids re-render flicker).
    panel.set_active_ticket("2")
    assert panel._active_ticket_id == "2"


def test_topics_panel_click_invokes_on_pick():
    """Clicking a topic card calls on_pick(topic_dict). Active highlight
    flips optimistically so the user gets immediate feedback."""
    from meeting_helper.flet_gui.components.topics_panel import TopicsPanel

    picks: list[dict] = []
    panel = TopicsPanel(on_pick=lambda t: picks.append(t))
    topic = {"id": "42", "title": "Deepgram migration", "status": "in_progress"}
    panel.set_topics([topic])

    # Trigger the internal click handler directly.
    panel._handle_click(topic)

    assert len(picks) == 1
    assert picks[0]["id"] == "42"
    # Optimistic active highlight.
    assert panel._active_ticket_id == "42"
