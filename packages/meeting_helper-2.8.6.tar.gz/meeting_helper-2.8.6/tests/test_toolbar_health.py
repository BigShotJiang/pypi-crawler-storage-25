"""Tests for the CopilotScreen daemon-health toolbar helper.

The _format_health_line staticmethod is a pure function — no Flet page needed.
We also do a construction smoke-check to confirm the health pill exists.
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest


@pytest.fixture
def fake_page():
    page = MagicMock()
    page.run_thread = MagicMock()
    page.run_task = MagicMock()
    page.update = MagicMock()
    return page


@pytest.fixture
def fake_config():
    cfg = MagicMock()
    cfg.port = 7891
    cfg.local_todo_configured = True
    cfg.provider_configured = True
    return cfg


# ---------------------------------------------------------------------------
# _format_health_line unit tests (pure-function, no screen instance needed)
# Returns (compact_text, degraded). Loop status is the trailing dot in the UI,
# not part of this text.
# ---------------------------------------------------------------------------

def _fhl(h):
    from meeting_helper.flet_gui.screens.copilot import CopilotScreen
    return CopilotScreen._format_health_line(h)


def test_format_health_line_empty_dict():
    text, degraded = _fhl({})
    assert text == "—"
    assert degraded is False


def test_format_health_line_normal():
    h = {
        "last_ai_call_age_sec": 8,
        "cpu_percent": 31.0,
        "rss_mb": 412.0,
        "event_loop_lag_ms": 12.0,
        "active_query": False,
        "active_query_age_sec": 0.0,
    }
    text, degraded = _fhl(h)
    assert text == "8s · 31% · 412 MB"
    assert degraded is False


def test_format_health_line_partial_metrics():
    # Only an age, no cpu/rss yet → just the age segment.
    text, degraded = _fhl({"last_ai_call_age_sec": 3.0})
    assert text == "3s"
    assert degraded is False


def test_format_health_line_slow_loop_is_degraded():
    h = {
        "last_ai_call_age_sec": 5.0,
        "cpu_percent": 50.0,
        "rss_mb": 300.0,
        "event_loop_lag_ms": 820.0,
        "active_query": False,
        "active_query_age_sec": 0.0,
    }
    text, degraded = _fhl(h)
    assert text == "5s · 50% · 300 MB"
    assert degraded is True


def test_format_health_line_stuck_query_is_degraded():
    h = {
        "last_ai_call_age_sec": 20.0,
        "cpu_percent": 40.0,
        "rss_mb": 250.0,
        "event_loop_lag_ms": 10.0,   # loop fine
        "active_query": True,
        "active_query_age_sec": 40.0,  # stuck >15s → degraded
    }
    _text, degraded = _fhl(h)
    assert degraded is True


def test_format_health_line_not_degraded_when_query_young():
    h = {
        "last_ai_call_age_sec": 3.0,
        "event_loop_lag_ms": 100.0,    # under the 500ms threshold
        "active_query": True,
        "active_query_age_sec": 5.0,   # <15s → not degraded
    }
    _text, degraded = _fhl(h)
    assert degraded is False


# ---------------------------------------------------------------------------
# Construction smoke check — the health pill (and its inner text/dot) must exist
# ---------------------------------------------------------------------------

def test_copilot_screen_has_health_pill(fake_page, fake_config):
    from meeting_helper.flet_gui.screens.copilot import CopilotScreen

    screen = CopilotScreen(fake_page, fake_config)
    assert hasattr(screen, "_health_pill"), "_health_pill missing from CopilotScreen"
    assert screen._health_pill is not None
    # Inner widgets the poller mutates must also be present.
    assert hasattr(screen, "_health_text") and screen._health_text is not None
    assert hasattr(screen, "_health_dot") and screen._health_dot is not None
    assert hasattr(screen, "_health_icon") and screen._health_icon is not None
