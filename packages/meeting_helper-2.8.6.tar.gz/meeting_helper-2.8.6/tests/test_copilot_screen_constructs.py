"""Smoke tests for the Flet Copilot screen construction.

These tests would have caught the `PopupMenuItem(text=...)` regression that
crashed the GUI at startup. The point isn't to test behavior end-to-end —
that requires a real Page — but to confirm every Flet widget kwarg we use
is recognized by the installed Flet version.

If Flet's API changes (PopupMenuItem args renamed, IconButton drops a kwarg,
etc.) one of these tests will fail loudly in CI instead of in the user's GUI.
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest


@pytest.fixture
def fake_page():
    """A Page mock that absorbs the calls CopilotScreen makes during __init__:
    `run_thread`, `run_task`, `update`, etc. We don't run the loops; we just
    need the constructor to succeed."""
    page = MagicMock()
    page.run_thread = MagicMock()
    page.run_task = MagicMock()
    page.update = MagicMock()
    return page


@pytest.fixture
def fake_config():
    cfg = MagicMock()
    cfg.port = 7891
    cfg.local_todo_configured = True
    cfg.provider_configured = True
    return cfg


def test_copilot_screen_constructs(fake_page, fake_config):
    """CopilotScreen.__init__ must succeed against the installed Flet
    version. A wrong kwarg on any control raises TypeError at import-time
    of the screen, which is exactly the GUI-not-opening bug we want to
    catch in CI."""
    from meeting_helper.flet_gui.screens.copilot import CopilotScreen

    screen = CopilotScreen(fake_page, fake_config)

    # The redesign moved several controls — assert the references the rest
    # of the screen depends on still exist after construction.
    assert screen._overflow_btn is not None
    assert screen._self_interim_text is not None
    assert screen._other_interim_text is not None
    assert screen._live_caption_bar is not None
    assert screen._trigger_btn is not None
    assert screen._send_btn is not None
    # Lifecycle plumbing for Phase 4b.
    assert screen._stop_event is not None
    assert screen._is_active is True


def test_copilot_screen_dispose_sets_stop_event(fake_page, fake_config):
    """dispose() must signal background loops to exit. Without this, the
    loops survived workspace switches and wrote into stale widgets."""
    from meeting_helper.flet_gui.screens.copilot import CopilotScreen

    screen = CopilotScreen(fake_page, fake_config)
    assert not screen._stop_event.is_set()
    screen.dispose()
    assert screen._stop_event.is_set()
    assert screen._is_active is False


def test_copilot_screen_on_deactivate_marks_inactive(fake_page, fake_config):
    """on_deactivate flips _is_active so polling loops skip widget mutations
    on a tab the user can't see."""
    from meeting_helper.flet_gui.screens.copilot import CopilotScreen

    screen = CopilotScreen(fake_page, fake_config)
    screen.on_deactivate()
    assert screen._is_active is False
    # Re-activate should restore it.
    screen.on_activate()
    assert screen._is_active is True


def test_copilot_screen_reset_live_captions_clears_state(fake_page, fake_config):
    """Stale interim text must be wiped on WS reconnect / on_activate /
    new meeting. Without this, the last interim before a disconnect
    sticks forever waiting for a final that won't arrive.

    The bar itself stays visible (fixed-height footer); only the text
    inside is cleared, so the conversation layout above doesn't shift.
    """
    from meeting_helper.flet_gui.screens.copilot import CopilotScreen

    screen = CopilotScreen(fake_page, fake_config)
    screen._self_interim_text.value = "🎙  half-typed sentence"
    screen._other_interim_text.value = "🔊  other speaker"

    screen._reset_live_captions()

    assert screen._self_interim_text.value == ""
    assert screen._other_interim_text.value == ""
