"""Tests for the AUTO/MANUAL topic mode toggle (binary, no countdown)."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from aiohttp import web


@pytest.fixture(autouse=True)
def _reset_global_state():
    """Reset shared module-level state between tests so a stale flag from
    a previous test can't bleed into the next one."""
    from meeting_helper.state import state as global_state
    yield
    global_state.topic_manual_mode = False
    global_state.current_topic_cards = []
    global_state.current_topic = {}
    global_state.last_cards = []
    global_state.local_todo = None


def _make_app() -> web.Application:
    """Construct a minimal aiohttp app with the topic routes wired up.
    Mirrors the pattern used in tests/test_topics_feature.py."""
    from meeting_helper.server.routes import setup_routes

    class FakeConfig:
        anthropic_api_key = "x"

    app = web.Application()
    app["config"] = FakeConfig()
    setup_routes(app)
    return app


@pytest.mark.asyncio
async def test_topic_set_enters_manual_mode_indefinitely(aiohttp_client):
    """POST /topic/set must flip topic_manual_mode to True with no time limit."""
    from meeting_helper.state import state as global_state

    global_state.topic_manual_mode = False
    # Provide a fake local_todo so the hydrate path doesn't touch real MCP.
    fake_local_todo = MagicMock()
    fake_local_todo.get = AsyncMock(return_value={
        "id": "42", "title": "ClickHouse query path", "body_md": "", "comments": [],
    })
    global_state.local_todo = fake_local_todo

    client = await aiohttp_client(_make_app())
    with patch("meeting_helper.server.websocket.broadcast", new=AsyncMock()):
        resp = await client.post("/topic/set", json={
            "ticket_id": "42",
            "title": "ClickHouse query path",
            "board_id": 1,
        })

    assert resp.status == 200
    body = await resp.json()
    assert body["ok"] is True
    assert body.get("manual") is True
    # The sticky boolean is the whole point of the new behavior.
    assert global_state.topic_manual_mode is True
    # No countdown leaked into the response payload.
    assert "manual_remaining_sec" not in body
    assert "manual_until_monotonic" not in body


@pytest.mark.asyncio
async def test_topic_auto_clears_manual_mode(aiohttp_client):
    """POST /topic/auto must flip topic_manual_mode back to False and clear
    the pinned topic so TopicWorker can resume picking."""
    from meeting_helper.state import state as global_state

    global_state.topic_manual_mode = True
    global_state.current_topic = {"topic": "old", "ticket_ids": ["42"]}
    global_state.current_topic_cards = [{"id": "42"}]

    client = await aiohttp_client(_make_app())
    with patch("meeting_helper.server.websocket.broadcast", new=AsyncMock()):
        resp = await client.post("/topic/auto", json={})

    assert resp.status == 200
    body = await resp.json()
    assert body == {"ok": True}
    assert global_state.topic_manual_mode is False
    assert global_state.current_topic == {}
    assert global_state.current_topic_cards == []


@pytest.mark.asyncio
async def test_topic_auto_is_idempotent(aiohttp_client):
    """Calling /topic/auto twice in a row is a no-op the second time —
    no errors, still cleared."""
    from meeting_helper.state import state as global_state

    global_state.topic_manual_mode = False
    global_state.current_topic = {}

    client = await aiohttp_client(_make_app())
    with patch("meeting_helper.server.websocket.broadcast", new=AsyncMock()):
        resp1 = await client.post("/topic/auto", json={})
        resp2 = await client.post("/topic/auto", json={})

    assert resp1.status == 200
    assert resp2.status == 200
    assert global_state.topic_manual_mode is False


def test_topics_panel_indicator_toggles_state():
    """set_indicator(True/False) flips is_manual() correspondingly."""
    from meeting_helper.flet_gui.components.topics_panel import TopicsPanel

    panel = TopicsPanel(on_pick=lambda _t: None)
    # Default: AUTO.
    assert panel.is_manual() is False
    panel.set_indicator(manual=True)
    assert panel.is_manual() is True
    panel.set_indicator(manual=False)
    assert panel.is_manual() is False


def test_topics_panel_indicator_is_clickable_when_callback_provided():
    """Constructing with on_indicator_click wires the indicator container
    so it has an on_click handler the GUI can fire."""
    from meeting_helper.flet_gui.components.topics_panel import TopicsPanel

    fired: list[bool] = []
    panel = TopicsPanel(
        on_pick=lambda _t: None,
        on_indicator_click=lambda: fired.append(True),
    )
    assert panel._indicator_bar.on_click is not None
    # Simulate a click — the lambda forwards to our callback.
    panel._indicator_bar.on_click(None)
    assert fired == [True]
