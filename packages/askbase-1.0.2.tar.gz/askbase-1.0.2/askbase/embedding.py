"""LiteLLM embedding helpers for hybrid retrieval."""

from __future__ import annotations

import array
import math
from pathlib import Path

from . import db
from .config import EmbeddingConfig


def _embed_texts(texts: list[str], config: EmbeddingConfig) -> list[list[float]]:
  from litellm import embedding

  if not texts:
    return []

  vectors: list[list[float]] = []

  for start in range(0, len(texts), config.batch_size):
    batch = texts[start : start + config.batch_size]
    response = embedding(
      model=config.model,
      input=batch,
      api_key=config.api_key,
    )
    if len(response.data) != len(batch):
      raise ValueError(
        f"embedding response count mismatch: requested {len(batch)}, "
        f"received {len(response.data)}"
      )
    vectors.extend(
      _normalize_vector(list(item["embedding"]))
      for item in sorted(response.data, key=lambda item: int(item.get("index", 0)))
    )

  return vectors


def populate_cache(database_path: Path, config: EmbeddingConfig) -> None:
  missing = db.chunks_missing_embeddings(database_path)
  if not missing:
    return

  vectors = _embed_texts([text for _, text in missing], config)
  db.upsert_chunk_embeddings(
    database_path,
    [
      {"chunk_id": chunk_id, "embedding": _vector_to_blob(vector)}
      for (chunk_id, _), vector in zip(missing, vectors)
    ],
  )


def search_chunks(
  database_path: Path,
  query: str,
  limit: int,
  config: EmbeddingConfig,
) -> list[tuple[str, str]]:
  query_vector = _embed_texts([query], config)[0]
  scored = [
    (_dot_product(query_vector, _blob_to_vector(embedding)), citation, text)
    for citation, text, embedding in db.embedding_chunks(database_path)
  ]
  scored.sort(reverse=True, key=lambda row: row[0])
  return [(citation, text) for _, citation, text in scored[:limit]]


def _normalize_vector(vector: list[float]) -> list[float]:
  magnitude = math.sqrt(sum(value * value for value in vector))
  if not magnitude:
    return vector
  return [value / magnitude for value in vector]


def _vector_to_blob(vector: list[float]) -> bytes:
  return array.array("f", vector).tobytes()


def _blob_to_vector(blob: bytes) -> array.array[float]:
  vector = array.array("f")
  vector.frombytes(blob)
  return vector


def _dot_product(left: list[float], right: array.array[float]) -> float:
  return sum(left_value * right_value for left_value, right_value in zip(left, right))
