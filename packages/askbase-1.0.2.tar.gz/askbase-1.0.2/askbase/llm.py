"""LiteLLM completion wrapper for askbase."""

from .config import LlmConfig


def complete(system: str, prompt: str, config: LlmConfig) -> str:
  from litellm import completion

  response = completion(
    model=config.model,
    api_key=config.api_key,
    messages=[
      {"role": "system", "content": system},
      {"role": "user", "content": prompt},
    ],
  )
  content = response.choices[0].message.content
  return content or ""
