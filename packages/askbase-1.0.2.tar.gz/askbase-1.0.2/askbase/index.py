"""Index source documents into askbase storage."""

from pathlib import Path
from typing import TypedDict

from . import db
from .chunk import is_indexable_chunk, line_citation, text_chunks
from .config import EmbeddingConfig
from .embedding import populate_cache
from .extract import extract_text
from .files import file_sha256, relative_source_path, source_files
from .paths import db_path


class IndexResult(TypedDict):
  path: Path
  total_files: int
  changed_files: int
  deleted_files: int


def document_values(directory: Path, path: Path, sha256: str) -> db.DocumentRow:
  media_type, raw_text = extract_text(path)
  return {
    "path": relative_source_path(path, directory),
    "media_type": media_type,
    "sha256": sha256,
    "raw_text": raw_text,
  }


def chunk_values(path: str, raw_text: str) -> list[db.ChunkRow]:
  return [
    {
      "citation": line_citation(
        path, start_line=int(chunk["start_line"]), end_line=int(chunk["end_line"])
      ),
      "text": str(chunk["text"]),
    }
    for chunk in text_chunks(raw_text)
    if is_indexable_chunk(chunk)
  ]


def indexed_document(directory: Path, path: Path, sha256: str) -> db.IndexedDocument:
  document = document_values(directory, path, sha256)
  chunks = chunk_values(document["path"], document["raw_text"])
  return {"document": document, "chunks": chunks}


def changed_documents(
  directory: Path, files: list[Path], existing_hashes: dict[str, str]
) -> list[db.IndexedDocument]:
  documents: list[db.IndexedDocument] = []
  for path in files:
    relative_path = relative_source_path(path, directory)
    sha256 = file_sha256(path)
    if existing_hashes.get(relative_path) == sha256:
      continue
    documents.append(indexed_document(directory, path, sha256))
  return documents


def stale_paths(existing_hashes: dict[str, str], current_paths: set[str]) -> list[str]:
  return sorted(set(existing_hashes) - current_paths)


def resolve_directory(directory: Path) -> Path:
  resolved = directory.expanduser().resolve()
  if not resolved.is_dir():
    raise ValueError(f"not a directory: {resolved}")
  return resolved


def index_directory(directory: Path, embedding_config: EmbeddingConfig) -> IndexResult:
  directory = resolve_directory(directory)
  files = source_files(directory)
  database_path = db_path(directory)
  existing_hashes = db.document_hashes(database_path)
  current_paths = {relative_source_path(path, directory) for path in files}
  delete_paths = stale_paths(existing_hashes, current_paths)
  documents = changed_documents(directory, files, existing_hashes)
  db.update_index(
    database_path,
    delete_paths=delete_paths,
    documents=documents,
  )
  populate_cache(database_path, embedding_config)
  return {
    "path": database_path,
    "total_files": len(files),
    "changed_files": len(documents),
    "deleted_files": len(delete_paths),
  }
