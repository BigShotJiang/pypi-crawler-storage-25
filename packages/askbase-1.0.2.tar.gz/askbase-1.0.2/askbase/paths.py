"""Filesystem paths for the new askbase implementation."""

from pathlib import Path

ASKBASE_DIR = ".askbase"
ASKBASE_DB = "askbase.sqlite"


def db_path(directory: Path) -> Path:
  return directory / ASKBASE_DIR / ASKBASE_DB
