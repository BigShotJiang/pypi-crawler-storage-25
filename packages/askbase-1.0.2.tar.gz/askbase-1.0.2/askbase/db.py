"""SQLite storage for the new askbase implementation."""

from contextlib import contextmanager
from collections.abc import Iterator
import sqlite3
from pathlib import Path
from typing import TypedDict


class DocumentRow(TypedDict):
  path: str
  media_type: str
  sha256: str
  raw_text: str


class ChunkRow(TypedDict):
  citation: str
  text: str


class EmbeddingRow(TypedDict):
  chunk_id: int
  embedding: bytes


class IndexedDocument(TypedDict):
  document: DocumentRow
  chunks: list[ChunkRow]


@contextmanager
def _open_db(
  path: Path, *, create_parent: bool = False, require_exists: bool = False
) -> Iterator[sqlite3.Connection]:
  if require_exists and not path.exists():
    raise ValueError(f"index not found at {path}; run askbase index first")
  if create_parent:
    path.parent.mkdir(parents=True, exist_ok=True)
  db = sqlite3.connect(path)
  db.execute("pragma foreign_keys = on")
  try:
    yield db
    db.commit()
  except Exception:
    db.rollback()
    raise
  finally:
    db.close()


def _delete_documents(db: sqlite3.Connection, paths: list[str]) -> None:
  if not paths:
    return
  placeholders = ", ".join("?" for _ in paths)
  db.execute(
    f"""
    delete from chunks_fts
    where rowid in (
      select chunks.id
      from chunks
      join documents on documents.id = chunks.document_id
      where documents.path in ({placeholders})
    )
    """,
    paths,
  )
  db.execute(
    f"""
    delete from documents
    where path in ({placeholders})
    """,
    paths,
  )


def _create_schema(db: sqlite3.Connection) -> None:
  db.execute("""
    create table if not exists documents (
      id integer primary key,
      path text not null unique,
      media_type text not null,
      sha256 text not null,
      raw_text text not null
    )
  """)
  db.execute("""
    create table if not exists chunks (
      id integer primary key,
      document_id integer not null references documents(id) on delete cascade,
      citation text not null,
      text text not null
    )
  """)
  db.execute("create virtual table if not exists chunks_fts using fts5(text)")
  _reset_legacy_embedding_cache(db)
  db.execute("""
    create table if not exists chunk_embeddings (
      chunk_id integer primary key references chunks(id) on delete cascade,
      embedding blob not null
    )
  """)


def _reset_legacy_embedding_cache(db: sqlite3.Connection) -> None:
  columns = db.execute("pragma table_info(chunk_embeddings)").fetchall()
  if any(str(column[1]) == "model" for column in columns):
    db.execute("drop table chunk_embeddings")


def _insert_document(db: sqlite3.Connection, document: DocumentRow) -> int:
  cursor = db.execute(
    """
    insert into documents(path, media_type, sha256, raw_text)
    values (?, ?, ?, ?)
    """,
    (
      document["path"],
      document["media_type"],
      document["sha256"],
      document["raw_text"],
    ),
  )
  return int(cursor.lastrowid)


def _insert_chunk(db: sqlite3.Connection, document_id: int, chunk: ChunkRow) -> int:
  cursor = db.execute(
    """
    insert into chunks(document_id, citation, text)
    values (?, ?, ?)
    """,
    (document_id, chunk["citation"], chunk["text"]),
  )
  db.execute(
    "insert into chunks_fts(rowid, text) values (?, ?)",
    (cursor.lastrowid, chunk["text"]),
  )
  return int(cursor.lastrowid)


def _document_hashes(db: sqlite3.Connection) -> dict[str, str]:
  rows = db.execute("select path, sha256 from documents").fetchall()
  return {str(path): str(sha) for path, sha in rows}


def document_hashes(path: Path) -> dict[str, str]:
  with _open_db(path, create_parent=True) as db:
    _create_schema(db)
    return _document_hashes(db)


def search_chunks(path: Path, query: str, limit: int) -> list[tuple[str, str]]:
  with _open_db(path, require_exists=True) as db:
    _create_schema(db)
    rows = db.execute(
      """
      select chunks.citation, chunks.text
      from chunks_fts
      join chunks on chunks.id = chunks_fts.rowid
      where chunks_fts match ?
      order by bm25(chunks_fts)
      limit ?
      """,
      (query, limit),
    ).fetchall()
  return [(str(citation), str(text)) for citation, text in rows]


def chunks_missing_embeddings(path: Path) -> list[tuple[int, str]]:
  with _open_db(path, require_exists=True) as db:
    _create_schema(db)
    rows = db.execute(
      """
      select chunks.id, chunks.text
      from chunks
      left join chunk_embeddings
        on chunk_embeddings.chunk_id = chunks.id
      where chunk_embeddings.chunk_id is null
      order by chunks.id
      """,
    ).fetchall()
  return [(int(chunk_id), str(text)) for chunk_id, text in rows]


def upsert_chunk_embeddings(path: Path, rows: list[EmbeddingRow]) -> None:
  with _open_db(path, require_exists=True) as db:
    _create_schema(db)
    db.executemany(
      """
      insert into chunk_embeddings(chunk_id, embedding)
      values (?, ?)
      on conflict(chunk_id) do update set
        embedding = excluded.embedding
      """,
      [(row["chunk_id"], row["embedding"]) for row in rows],
    )


def embedding_chunks(path: Path) -> list[tuple[str, str, bytes]]:
  with _open_db(path, require_exists=True) as db:
    _create_schema(db)
    rows = db.execute(
      """
      select chunks.citation, chunks.text, chunk_embeddings.embedding
      from chunk_embeddings
      join chunks on chunks.id = chunk_embeddings.chunk_id
      order by chunks.id
      """,
    ).fetchall()
  return [
    (str(citation), str(text), bytes(embedding)) for citation, text, embedding in rows
  ]


def update_index(
  path: Path, *, delete_paths: list[str], documents: list[IndexedDocument]
) -> None:
  with _open_db(path, create_parent=True) as db:
    _create_schema(db)
    paths = delete_paths + [str(document["document"]["path"]) for document in documents]
    _delete_documents(db, sorted(set(paths)))
    for document in documents:
      document_id = _insert_document(db, document["document"])
      for chunk in document["chunks"]:
        _insert_chunk(db, document_id, chunk)
