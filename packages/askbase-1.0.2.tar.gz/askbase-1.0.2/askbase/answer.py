"""Evidence-based answer presentation."""

import re
from pathlib import Path

from .config import EmbeddingConfig, LlmConfig
from .llm import complete
from .search import search_chunks

REFUSAL = (
  "I could not find enough information in the indexed sources to answer that question."
)
VALIDATION_FAILURE = (
  "I could not generate an answer that satisfied citation validation."
)
CITATION_RE = re.compile(r"\[([^\]]+)\]")
DECIMAL_RE = re.compile(r"(?<=\d)\.(?=\d)")
DECIMAL_POINT_PLACEHOLDER = "<DECIMAL_POINT>"
ABBREVIATION_RE = re.compile(
  r"\b(?:Dr|Mr|Mrs|Ms|Prof|Sr|Jr|vs)\.|\b(?:e\.g|i\.e)\.", re.IGNORECASE
)
ABBREVIATION_POINT_PLACEHOLDER = "<ABBREVIATION_POINT>"
SENTENCE_RE = re.compile(r"\S.*?(?:[.!?]+[\"'”’)]*(?:\s*\[[^\]]+\])*|$)")
OPTION_LABEL_RE = re.compile(r"[A-Z][.)]")
ANSWER_LABEL_RE = re.compile(
  r"Answer:\s*(?:True|False|[A-Z](?:\s*(?:,\s*and|,|and|&)\s*[A-Z])*)[.!]?",
  re.IGNORECASE,
)
ANSWER_SELECTION_RE = re.compile(
  r"^\s*Answer:\s*(True|False|[A-Z](?:\s*(?:,\s*and|,|and|&)\s*[A-Z])*)\b",
  re.IGNORECASE,
)

SYSTEM_PROMPT = f"""You are a citation-first question answering assistant.

Rules:
- Answer using only the provided evidence.
- Do not use outside knowledge.
- Cite only numeric citation IDs exactly as provided in the allowed citation list.
- The only valid citations are IDs from the allowed citation list.
- Every factual sentence must include at least one citation.
- Put citations in the same sentence as each factual answer statement.
- A standalone multiple-choice or true/false label such as "Answer: D." may be uncited only when a cited explanation immediately follows.
- You may combine multiple evidence excerpts to support one answer when the excerpts directly address the same topic.
- For multiple-choice questions, compare each option against the evidence and choose the option or options supported by the evidence.
- For multiple-choice questions, after the answer, briefly explain why each unselected option is wrong, contradicted, less appropriate, or unsupported by the evidence.
- When explaining why an option is wrong, cite the evidence that contradicts it or supports the more appropriate alternative; if no direct contradiction is available, say the option is not supported by the provided evidence.
- If the prompt says the question uses radio buttons or is single-answer, choose exactly one best option.
- If the prompt says the question uses checkboxes or is multiple-answer, choose every supported option.
- For exception questions using wording like "not", "except", or "not included", choose the exception when the evidence supports the included alternatives or contradicts the exception.
- For true/false questions, answer True when the evidence supports the statement and False when the evidence contradicts it.
- If a multiple-choice question has one option that means "all of the above" or "all are useful/correct", choose only that combined option when the evidence supports every listed component.
- Do not refuse just because the evidence uses different wording than the question or the support is split across multiple excerpts.
- Do not transfer facts from an unrelated example or neighboring topic to the question.
- For multiple-choice and true/false questions, begin with "Answer: " followed by the selected letter(s) or True/False.
- On the "Answer: " line, write only the selected letter(s) or True/False, not the option text or explanation.
- If the evidence is genuinely unrelated or insufficient, answer exactly: {REFUSAL}
- Keep the answer concise.
"""


def answer_question(
  directory: Path,
  question: str,
  *,
  embedding_config: EmbeddingConfig,
  llm_config: LlmConfig,
  show_evidence: bool = False,
  choice_mode: str = "auto",
) -> str:
  rows = search_chunks(directory, question, embedding_config=embedding_config, limit=32)
  if not rows:
    return REFUSAL
  prompt = answer_prompt(question, rows, choice_mode)
  answer = complete(SYSTEM_PROMPT, prompt, llm_config).strip()
  errors = validate_answer(answer, rows, choice_mode)
  if errors:
    answer = complete(
      SYSTEM_PROMPT,
      repair_prompt(question, rows, answer, errors, choice_mode),
      llm_config,
    ).strip()
    errors = validate_answer(answer, rows, choice_mode)
  if errors:
    answer = format_validation_failure(errors)
  if show_evidence:
    return f"{answer}\n\n{format_evidence(rows)}"
  return answer


def answer_prompt(
  question: str, rows: list[dict[str, str]], choice_mode: str = "auto"
) -> str:
  return "\n".join(
    [
      "Answer the question using only the evidence below.",
      "Cite only the allowed citation IDs exactly as shown, in square brackets.",
      "For multiple-choice questions, include a concise cited explanation for why every unselected option is wrong or unsupported.",
      choice_mode_instruction(choice_mode),
      "",
      format_citations(rows),
      "",
      format_evidence(rows),
      "",
      "Question:",
      question,
    ]
  )


def repair_prompt(
  question: str,
  rows: list[dict[str, str]],
  invalid_answer: str,
  errors: list[str],
  choice_mode: str = "auto",
) -> str:
  return "\n".join(
    [
      answer_prompt(question, rows, choice_mode),
      "",
      "Your previous answer failed validation:",
      *[f"- {error}" for error in errors],
      "",
      "Rewrite the answer so it follows every rule exactly.",
      (
        "Every factual sentence must include at least one valid citation "
        "unless the answer is the exact refusal sentence."
      ),
      (
        "For multiple-choice questions, include concise cited elimination notes "
        "for every unselected option."
      ),
      choice_mode_instruction(choice_mode),
      "",
      "Previous answer:",
      invalid_answer,
    ]
  )


def choice_mode_instruction(choice_mode: str) -> str:
  if choice_mode == "single":
    return (
      "Question format: radio buttons / single-answer. Choose exactly one best "
      "option, even when another option contains a true but less direct statement."
    )
  if choice_mode == "multiple":
    return (
      "Question format: checkboxes / multiple-answer. Choose every supported option."
    )
  return "Question format: infer from wording unless a radio/checkbox hint is present."


def validate_answer(
  answer: str, rows: list[dict[str, str]], choice_mode: str = "auto"
) -> list[str]:
  answer = answer.strip()
  if answer == REFUSAL:
    return []

  errors: list[str] = []
  if not answer:
    return ["Answer is empty."]

  allowed_ids = {str(index) for index in range(1, len(rows) + 1)}
  citation_ids = extract_citation_ids(answer)
  invalid_ids = sorted(
    {citation_id for citation_id in citation_ids if citation_id not in allowed_ids}
  )
  if invalid_ids:
    errors.append(f"Unknown or malformed citation ID(s): {', '.join(invalid_ids)}.")
  if not citation_ids:
    errors.append("Answer contains no citations.")

  if choice_mode == "single":
    answer_letters = extract_answer_letters(answer)
    if len(answer_letters) > 1:
      errors.append(
        "Single-answer question selected multiple options: "
        f"{', '.join(answer_letters)}."
      )

  for statement in uncited_answer_statements(answer, allowed_ids):
    errors.append(f"Statement has no valid citation: {statement}")

  return errors


def extract_citation_ids(answer: str) -> list[str]:
  return [match.strip() for match in CITATION_RE.findall(answer)]


def extract_answer_letters(answer: str) -> list[str]:
  match = ANSWER_SELECTION_RE.search(answer)
  if not match:
    return []
  selection = match.group(1)
  if selection.lower() in {"true", "false"}:
    return []
  return re.findall(r"\b[A-Z]\b", selection.upper())


def uncited_answer_statements(answer: str, allowed_ids: set[str]) -> list[str]:
  statements: list[str] = []
  seen_content_line = False
  for line in answer.splitlines():
    stripped_line = line.strip()
    if not stripped_line:
      continue
    is_answer_line = not seen_content_line and stripped_line.lower().startswith(
      "answer:"
    )
    seen_content_line = True
    for statement in sentence_statements(line):
      if is_standalone_answer_label(statement) or is_answer_line:
        continue
      text_without_citations = CITATION_RE.sub("", statement).strip()
      if not re.search(r"[A-Za-z0-9]", text_without_citations):
        continue
      statement_citations = extract_citation_ids(statement)
      if not any(citation_id in allowed_ids for citation_id in statement_citations):
        statements.append(statement)
  return statements


def sentence_statements(line: str) -> list[str]:
  statements: list[str] = []
  line = protect_sentence_periods(line.strip())
  for match in SENTENCE_RE.finditer(line):
    statement = restore_sentence_periods(match.group(0).strip())
    if statement and not OPTION_LABEL_RE.fullmatch(statement):
      statements.append(statement)
  return statements


def protect_sentence_periods(line: str) -> str:
  line = DECIMAL_RE.sub(DECIMAL_POINT_PLACEHOLDER, line)
  return ABBREVIATION_RE.sub(
    lambda match: match.group(0).replace(".", ABBREVIATION_POINT_PLACEHOLDER), line
  )


def restore_sentence_periods(line: str) -> str:
  return line.replace(DECIMAL_POINT_PLACEHOLDER, ".").replace(
    ABBREVIATION_POINT_PLACEHOLDER, "."
  )


def is_standalone_answer_label(statement: str) -> bool:
  return ANSWER_LABEL_RE.fullmatch(statement.strip()) is not None


def format_validation_failure(errors: list[str]) -> str:
  return "\n".join(
    [VALIDATION_FAILURE, "", "Validation errors:", *[f"- {error}" for error in errors]]
  )


def format_citations(rows: list[dict[str, str]]) -> str:
  lines = ["Citations:"]
  for index, row in enumerate(rows, start=1):
    lines.append(f"[{index}] {row['citation']}")
  return "\n".join(lines)


def format_evidence(rows: list[dict[str, str]]) -> str:
  lines = ["Relevant evidence:"]
  for index, row in enumerate(rows, start=1):
    lines.extend(["", f"[{index}] {row['citation']}", row["text"].rstrip()])
  return "\n".join(lines)
