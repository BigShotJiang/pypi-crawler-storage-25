#!/usr/bin/env python3
"""New askbase command-line entrypoint."""

import argparse
from pathlib import Path
import sys

from .answer import answer_question
from .config import ConfigError, ask_configs_from_env, embedding_config_from_env
from .index import index_directory


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
  parser = argparse.ArgumentParser(prog="askbase")
  subparsers = parser.add_subparsers(dest="command", required=True)

  index_parser = subparsers.add_parser("index")
  index_parser.add_argument("-d", "--directory", type=Path, default=Path("."))

  ask_parser = subparsers.add_parser("ask")
  ask_parser.add_argument("-d", "--directory", type=Path, default=Path("."))
  ask_parser.add_argument(
    "--show-evidence", action=argparse.BooleanOptionalAction, default=True
  )
  ask_parser.add_argument(
    "--choice-mode",
    choices=["auto", "single", "multiple"],
    default="auto",
    help="Hint for multiple-choice questions: radio buttons are single, checkboxes are multiple.",
  )
  ask_parser.add_argument("question")

  return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
  args = parse_args(argv)

  try:
    if args.command == "index":
      embedding_config = embedding_config_from_env()
      result = index_directory(args.directory, embedding_config)
      print(
        f"Indexed {result['changed_files']} changed file(s) "
        f"out of {result['total_files']} total into {result['path']}"
      )
      if result["deleted_files"]:
        print(f"Removed {result['deleted_files']} stale file(s) from the index")
    elif args.command == "ask":
      embedding_config, llm_config = ask_configs_from_env()
      print(
        answer_question(
          args.directory,
          args.question,
          embedding_config=embedding_config,
          llm_config=llm_config,
          show_evidence=args.show_evidence,
          choice_mode=args.choice_mode,
        )
      )
  except ConfigError as error:
    print(f"error: {error}", file=sys.stderr)
    return 2

  return 0


if __name__ == "__main__":
  raise SystemExit(main())
