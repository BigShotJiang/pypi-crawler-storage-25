"""File helpers for the new askbase implementation."""

from hashlib import sha256
from pathlib import Path

from .paths import ASKBASE_DIR

SOURCE_SUFFIXES = {".md", ".markdown", ".txt", ".text", ".pdf"}


def file_sha256(path: Path) -> str:
  digest = sha256()
  with path.open("rb") as file:
    for chunk in iter(lambda: file.read(1024 * 1024), b""):
      digest.update(chunk)
  return digest.hexdigest()


def source_files(directory: Path) -> list[Path]:
  return sorted(
    path
    for path in directory.rglob("*")
    if path.is_file()
    and path.suffix.lower() in SOURCE_SUFFIXES
    and ASKBASE_DIR not in path.parts
  )


def relative_source_path(path: Path, directory: Path) -> str:
  return path.relative_to(directory).as_posix()
