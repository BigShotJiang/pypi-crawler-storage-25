"""Chunk extracted text for indexing."""


def numbered_lines(text: str) -> list[tuple[int, str]]:
  return list(enumerate(text.splitlines(), start=1))


def word_count(text: str) -> int:
  return len(text.split())


def make_chunk(text: str, *, start_line: int, end_line: int) -> dict[str, object]:
  return {"text": text, "start_line": start_line, "end_line": end_line}


def is_heading(block: dict[str, object]) -> bool:
  return str(block["text"]).lstrip().startswith("#")


def is_metadata_block(text: str) -> bool:
  stripped = text.strip()
  return stripped in {"---", "***", "___", r"\newpage"} or stripped.startswith("[^")


def is_indexable_chunk(chunk: dict[str, object]) -> bool:
  blocks = str(chunk["text"]).split("\n\n")
  return any(block.strip() and not is_metadata_block(block) for block in blocks)


def paragraph_blocks(text: str) -> list[dict[str, object]]:
  blocks: list[dict[str, object]] = []
  current: list[str] = []
  start_line = 0
  end_line = 0
  for line_number, line in numbered_lines(text):
    if line.strip():
      start_line = start_line or line_number
      end_line = line_number
      current.append(line)
    elif current:
      blocks.append(
        make_chunk("\n".join(current), start_line=start_line, end_line=end_line)
      )
      current = []
      start_line = 0
  if current:
    blocks.append(
      make_chunk("\n".join(current), start_line=start_line, end_line=end_line)
    )
  return blocks


def text_chunks(text: str, *, max_words: int = 180) -> list[dict[str, object]]:
  chunks: list[dict[str, object]] = []
  current: list[dict[str, object]] = []
  current_words = 0
  for block in paragraph_blocks(text):
    block_words = word_count(str(block["text"]))
    if is_metadata_block(str(block["text"])):
      if current:
        chunks.append(_combined_chunk(current))
        current = []
        current_words = 0
      continue
    if current and is_heading(block):
      chunks.append(_combined_chunk(current))
      current = []
      current_words = 0
    if current and current_words + block_words > max_words:
      chunks.append(_combined_chunk(current))
      current = []
      current_words = 0
    current.append(block)
    current_words += block_words
  if current:
    chunks.append(_combined_chunk(current))
  return chunks


def _combined_chunk(blocks: list[dict[str, object]]) -> dict[str, object]:
  return make_chunk(
    "\n\n".join(str(block["text"]) for block in blocks),
    start_line=int(blocks[0]["start_line"]),
    end_line=int(blocks[-1]["end_line"]),
  )


def line_citation(path: str, *, start_line: int, end_line: int) -> str:
  if start_line == end_line:
    return f"{path}:L{start_line}"
  return f"{path}:L{start_line}-L{end_line}"
