"""Search indexed askbase chunks."""

import re
from pathlib import Path

from . import db
from .config import EmbeddingConfig
from .embedding import search_chunks as search_embedding_chunks
from .paths import db_path

STOPWORDS = {"a", "an", "and", "are", "is", "of", "the", "to", "what"}
BM25_LIMIT = 16
EMBEDDING_LIMIT = 16


def fts_query(query: str) -> str:
  terms = [
    term for term in re.findall(r"[a-zA-Z0-9]+", query) if term.lower() not in STOPWORDS
  ]
  if not terms:
    raise ValueError("query contains no searchable terms")
  return " OR ".join(f'"{term}"' for term in terms)


def search_chunks(
  directory: Path,
  query: str,
  *,
  embedding_config: EmbeddingConfig,
  limit: int = 8,
) -> list[dict[str, str]]:
  path = db_path(directory.expanduser().resolve())
  bm25_rows = db.search_chunks(path, fts_query(query), min(BM25_LIMIT, limit))
  embedding_rows = search_embedding_chunks(
    path, query, min(EMBEDDING_LIMIT, limit), embedding_config
  )

  rows: list[dict[str, str]] = []
  seen: set[tuple[str, str]] = set()
  for citation, text in [*bm25_rows, *embedding_rows]:
    key = (citation, text)
    if key in seen:
      continue
    seen.add(key)
    rows.append({"citation": citation, "text": text})
    if len(rows) >= limit:
      break
  return rows
