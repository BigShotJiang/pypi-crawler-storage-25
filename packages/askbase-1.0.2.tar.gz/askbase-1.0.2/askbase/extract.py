"""Extract text from source documents."""

from functools import lru_cache
from pathlib import Path

TEXT_MEDIA_TYPES = {
  ".md": "text/markdown",
  ".markdown": "text/markdown",
  ".txt": "text/plain",
  ".text": "text/plain",
}
PDF_MEDIA_TYPE = "application/pdf"


def extract_text(path: Path) -> tuple[str, str]:
  suffix = path.suffix.lower()
  if suffix in TEXT_MEDIA_TYPES:
    return TEXT_MEDIA_TYPES[suffix], path.read_text(encoding="utf-8")
  if suffix == ".pdf":
    return PDF_MEDIA_TYPE, _extract_pdf_text(path)
  raise ValueError(f"unsupported source file type: {path}")


def _extract_pdf_text(path: Path) -> str:
  result = _pdf_converter().convert(path)
  text = _clean_docling_markdown(result.document.export_to_markdown())
  if not text.strip():
    raise ValueError(f"no text extracted from PDF: {path}")
  return text


def _clean_docling_markdown(text: str) -> str:
  lines = [line for line in text.splitlines() if line.strip() != "<!-- image -->"]
  return "\n".join(lines).strip() + "\n"


@lru_cache(maxsize=1)
def _pdf_converter():
  try:
    from docling.datamodel.base_models import InputFormat
    from docling.datamodel.pipeline_options import (
      AcceleratorOptions,
      PdfPipelineOptions,
      RapidOcrOptions,
    )
    from docling.document_converter import DocumentConverter, PdfFormatOption
    from rapidocr import EngineType, LangDet, LangRec, ModelType, OCRVersion
  except ImportError as error:
    raise RuntimeError(
      "PDF indexing dependencies are missing. Reinstall askbase with "
      "`uv tool install --reinstall askbase`."
    ) from error

  options = PdfPipelineOptions(
    do_ocr=True,
    do_table_structure=False,
    accelerator_options=AcceleratorOptions(num_threads=4, device="cpu"),
    ocr_options=RapidOcrOptions(
      backend="onnxruntime",
      lang=["english"],
      rapidocr_params={
        "Det.engine_type": EngineType.MNN,
        "Det.lang_type": LangDet.CH,
        "Det.model_type": ModelType.MOBILE,
        "Det.ocr_version": OCRVersion.PPOCRV5,
        "Rec.engine_type": EngineType.MNN,
        "Rec.lang_type": LangRec.EN,
        "Rec.model_type": ModelType.MOBILE,
        "Rec.ocr_version": OCRVersion.PPOCRV5,
        "Cls.engine_type": EngineType.MNN,
      },
    ),
  )
  return DocumentConverter(
    format_options={InputFormat.PDF: PdfFormatOption(pipeline_options=options)}
  )
