"""Runtime configuration loaded at command boundaries."""

from collections.abc import Mapping
from dataclasses import dataclass
import os


EMBEDDING_ENV_VARS = (
  "ASKBASE_EMBEDDING_MODEL",
  "ASKBASE_EMBEDDING_MODEL_API_KEY",
  "ASKBASE_EMBEDDING_BATCH_SIZE",
)
LLM_ENV_VARS = (
  "ASKBASE_MODEL",
  "ASKBASE_MODEL_API_KEY",
)


class ConfigError(ValueError):
  """Raised when required runtime configuration is missing or invalid."""


@dataclass(frozen=True)
class EmbeddingConfig:
  model: str
  api_key: str
  batch_size: int


@dataclass(frozen=True)
class LlmConfig:
  model: str
  api_key: str


def embedding_config_from_env(
  environ: Mapping[str, str] = os.environ,
) -> EmbeddingConfig:
  require_env(environ, EMBEDDING_ENV_VARS)
  return EmbeddingConfig(
    model=environ["ASKBASE_EMBEDDING_MODEL"],
    api_key=environ["ASKBASE_EMBEDDING_MODEL_API_KEY"],
    batch_size=parse_batch_size(environ["ASKBASE_EMBEDDING_BATCH_SIZE"]),
  )


def llm_config_from_env(environ: Mapping[str, str] = os.environ) -> LlmConfig:
  require_env(environ, LLM_ENV_VARS)
  return LlmConfig(
    model=environ["ASKBASE_MODEL"],
    api_key=environ["ASKBASE_MODEL_API_KEY"],
  )


def ask_configs_from_env(
  environ: Mapping[str, str] = os.environ,
) -> tuple[EmbeddingConfig, LlmConfig]:
  require_env(environ, EMBEDDING_ENV_VARS + LLM_ENV_VARS)
  return (
    EmbeddingConfig(
      model=environ["ASKBASE_EMBEDDING_MODEL"],
      api_key=environ["ASKBASE_EMBEDDING_MODEL_API_KEY"],
      batch_size=parse_batch_size(environ["ASKBASE_EMBEDDING_BATCH_SIZE"]),
    ),
    LlmConfig(
      model=environ["ASKBASE_MODEL"],
      api_key=environ["ASKBASE_MODEL_API_KEY"],
    ),
  )


def require_env(environ: Mapping[str, str], names: tuple[str, ...]) -> None:
  missing = [name for name in names if not environ.get(name)]
  if missing:
    raise ConfigError("Missing required environment variable(s): " + ", ".join(missing))


def parse_batch_size(value: str) -> int:
  try:
    batch_size = int(value)
  except ValueError as error:
    raise ConfigError("ASKBASE_EMBEDDING_BATCH_SIZE must be an integer") from error
  if batch_size < 1:
    raise ConfigError("ASKBASE_EMBEDDING_BATCH_SIZE must be at least 1")
  return batch_size
