# askbase

Question answering for local knowledge bases with exact source citations.

## Setup

```bash
uv tool install askbase
```

Set these environment variables before indexing or asking questions:

- `ASKBASE_MODEL`
- `ASKBASE_MODEL_API_KEY`
- `ASKBASE_EMBEDDING_MODEL`
- `ASKBASE_EMBEDDING_MODEL_API_KEY`
- `ASKBASE_EMBEDDING_BATCH_SIZE`

## Usage

Build a local SQLite index for a directory:

```bash
askbase index -d /path/to/docs
```

This writes `.askbase/askbase.sqlite` inside the target directory.

Ask a question against that index:

```bash
askbase ask -d /path/to/docs "What does the source say?"
```

## Main Files

- `askbase/cli.py`: command-line entry point.
- `askbase/index.py`: indexes source files into SQLite.
- `askbase/extract.py`: extracts text from Markdown, text, and PDF files.
- `askbase/chunk.py`: creates line-preserving chunks.
- `askbase/db.py`: stores documents, chunks, FTS rows, and embeddings.
- `askbase/search.py`: combines BM25 and embedding retrieval.
- `askbase/answer.py`: builds evidence prompts and validates citations.
