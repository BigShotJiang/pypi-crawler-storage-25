"""Minimal Python entrypoint that calls compiled CLI core."""

from __future__ import annotations


def main() -> None:
    try:
        from cli.agent_cli import main as compiled_main
    except Exception as exc:
        raise RuntimeError(
            "Luckee CLI binary extensions are unavailable for this platform. "
            "Install a supported wheel build from PyPI."
        ) from exc
    compiled_main()


if __name__ == "__main__":
    main()
