from __future__ import annotations
from collections.abc import Callable
from plecost.models import ScanOptions, Finding, Plugin, Theme, User, WooCommerceInfo, WPECommerceInfo, MagecartInfo


class ScanContext:
    """Shared state for all scan modules."""

    def __init__(
        self,
        opts: ScanOptions,
        on_finding: Callable[[Finding], None] | None = None,
        on_progress: Callable[[str, int, int], None] | None = None,
    ) -> None:
        self.opts = opts
        self.url = opts.url.rstrip("/")
        self._ssl_verify_failed: bool = False
        self.is_wordpress: bool = False
        self.wordpress_version: str | None = None
        self.waf_detected: str | None = None
        self.blocked: bool = False
        self.woocommerce: WooCommerceInfo | None = None
        self.wp_ecommerce: WPECommerceInfo | None = None
        self.magecart: MagecartInfo | None = None
        self.plugins: list[Plugin] = []
        self.themes: list[Theme] = []
        self.users: list[User] = []
        self.findings: list[Finding] = []
        self._on_finding = on_finding
        self._on_progress = on_progress

    def report_progress(self, module: str, current: int, total: int) -> None:
        if self._on_progress:
            self._on_progress(module, current, total)

    def add_finding(self, finding: Finding) -> None:
        self.findings.append(finding)
        if self._on_finding:
            self._on_finding(finding)

    def add_plugin(self, plugin: Plugin) -> None:
        self.plugins.append(plugin)

    def add_theme(self, theme: Theme) -> None:
        self.themes.append(theme)

    def add_user(self, user: User) -> None:
        self.users.append(user)
