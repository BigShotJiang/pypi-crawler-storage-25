import json
import os

import boto3

from reach_commons.clients._auth import reach_api_bearer_header


class CallbackProcessorClient:
    def __init__(self, environment=None):
        self.environment = environment or os.environ.get("ENV", "Staging")
        self.lambda_client = boto3.client("lambda")

    @property
    def function_name(self):
        return f"{self.environment}-Callback-Processor-lambda"

    @property
    def auth_header(self):
        return reach_api_bearer_header()

    def meevo_soft_disable(self, business_id: int):
        payload = {
            "resource": "/callbacks/internal/meevo/soft-disable",
            "headers": {
                "Authorization": self.auth_header,
            },
            "body": json.dumps(
                {
                    "business_id": business_id,
                }
            ),
        }
        return self.lambda_client.invoke(
            FunctionName=self.function_name,
            InvocationType="RequestResponse",
            Payload=json.dumps(payload),
        )
