import json
import os

import boto3


class NightlyLambdaClient:
    def __init__(self, environment=None):
        self.environment = environment or os.environ.get("ENV", "Staging")
        self.lambda_client = boto3.client("lambda")

    @property
    def function_name(self):
        return f"{self.environment}-nightly-lambda"

    def meevo_reactivate(self, business_id: int):
        payload = {
            "event": "onboard",
            "override_status": True,
            "business_ids": [business_id],
        }
        return self.lambda_client.invoke(
            FunctionName=self.function_name,
            InvocationType="Event",
            Payload=json.dumps(payload),
        )
