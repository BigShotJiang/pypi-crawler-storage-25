from reach_commons._ssm import env_segment, get_secure


def reach_api_bearer_header() -> str:
    """Bearer token shared across reach internal APIs (callback / event / ops / data-bridge).

    Reads from SSM SecureString `/api-keys/{env}/lambda-function-api-key`, cached
    per-process. Consumer lambdas need `ssm:GetParameter` IAM on that path.
    """
    return f"Bearer {get_secure(f'/api-keys/{env_segment()}/lambda-function-api-key')}"
