"""SSM SecureString lookup with in-process TTL caching.

reach_commons reads its credentials (Bearer tokens, Twilio creds, Outscraper
token + webhook) directly from AWS Systems Manager Parameter Store at runtime,
sourced from `/terraform/shared-config.tf`'s `shared_ssm_secure` block.

Cache: in-memory dict with 1h TTL. Cold start = 1 GetParameter per credential
(~50ms each). Warm container reuses the cached value until expiry. After 1h
a rotation in SSM is picked up automatically on the next call without redeploy.

Consumers must grant `ssm:GetParameter` IAM on the SSM paths they touch
(`/api-keys/*`, `/twilio/*`, `/outscraper/*`); see consumer .lambda.tf in
/terraform.
"""

import os
import time
from functools import lru_cache

import boto3

_TTL_SECONDS = 3600
_cache: "dict[str, tuple[float, str]]" = {}


@lru_cache(maxsize=1)
def _client():
    return boto3.client("ssm", region_name=os.environ.get("AWS_REGION", "us-east-1"))


def get_secure(path: str) -> str:
    """Fetch a SecureString from SSM. In-memory cached with 1h TTL."""
    now = time.monotonic()
    entry = _cache.get(path)
    if entry is not None and now - entry[0] < _TTL_SECONDS:
        return entry[1]
    value = _client().get_parameter(Name=path, WithDecryption=True)["Parameter"]["Value"]
    _cache[path] = (now, value)
    return value


def env_segment() -> str:
    """Returns 'staging' or 'prod' to use as the SSM path env segment."""
    return os.environ.get("ENV", "Staging").lower()
