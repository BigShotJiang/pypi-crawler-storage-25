from __future__ import annotations

import argparse
from pathlib import Path

from .parser import extract_invoice_fields
from .xls_generator import (
    generate_xlsx_by_month_day,
    generate_xlsx_single,
)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="ebia")

    ap.add_argument("--path", required=True, help="PDF file path OR a folder containing PDFs")
    ap.add_argument(
        "--out",
        default=None,
        help=(
            "Single-PDF mode: output .xlsx file path (default: output.xlsx). "
            "Folder mode: output directory where one YYYY-MM.xlsx is created per month "
            "(default: current directory)."
        ),
    )

    ap.add_argument("--tva", type=float, default=0.20, help="TVA rate (default 0.20)")

    # Incrémentation pour dossier
    ap.add_argument("--start-piece", type=int, default=1, help="Starting Pièce number (default 1)")
    ap.add_argument(
        "--start-document", type=int, default=1, help="Starting Document number (default 1)"
    )
    ap.add_argument("--piece-width", type=int, default=4, help="Pièce zero-fill width (default 4)")
    ap.add_argument(
        "--document-width", type=int, default=5, help="Document zero-fill width (default 5)"
    )

    # Pour un seul PDF (optionnel : override)
    ap.add_argument("--piece", default=None, help="Override Pièce for single PDF (e.g. 0000)")
    ap.add_argument(
        "--document", default=None, help="Override Document for single PDF (e.g. 00000)"
    )

    ap.add_argument("--no-headers", action="store_true", help="Generate Excel without header row")
    ap.add_argument(
        "--recursive", action="store_true", help="Scan subfolders for PDFs (folder mode)"
    )

    args = ap.parse_args(argv)

    p = Path(args.path)
    include_headers = not args.no_headers

    if p.is_file():
        # Single PDF mode
        data = extract_invoice_fields(str(p))

        out_file = args.out if args.out is not None else "output.xlsx"

        # piece/document: si non fournis, on utilise start_* avec widths
        if args.piece is None:
            piece = str(args.start_piece).zfill(args.piece_width)
        else:
            piece = args.piece

        if args.document is None:
            document = str(args.start_document).zfill(args.document_width)
        else:
            document = args.document

        generate_xlsx_single(
            data,
            out_file,
            piece=piece,
            document=document,
            tva_rate=args.tva,
            include_headers=include_headers,
        )
        print(f"OK (single) -> {out_file}")
        return 0

    if p.is_dir():
        # Folder mode
        if args.recursive:
            pdfs = sorted(p.rglob("*.pdf")) + sorted(p.rglob("*.PDF"))
        else:
            pdfs = sorted(p.glob("*.pdf")) + sorted(p.glob("*.PDF"))

        if not pdfs:
            raise SystemExit(f"No PDF files found in folder: {p}")

        invoice_dicts = []
        skipped = 0

        for pdf in pdfs:
            try:
                invoice_dicts.append(extract_invoice_fields(str(pdf)))
            except Exception as e:
                skipped += 1
                print(f"[SKIP] {pdf}: {e}")

        out_dir = args.out if args.out is not None else "./reports"

        generated = generate_xlsx_by_month_day(
            invoice_dicts,
            out_dir,
            start_piece=args.start_piece,
            start_document=args.start_document,
            piece_width=args.piece_width,
            document_width=args.document_width,
            tva_rate=args.tva,
            include_headers=include_headers,
        )

        print(f"OK (folder) | parsed={len(invoice_dicts)} skipped={skipped}")
        for f in generated:
            print(f"  -> {f}")
        return 0

    raise SystemExit(f"Invalid path: {p}")


if __name__ == "__main__":
    raise SystemExit(main())
