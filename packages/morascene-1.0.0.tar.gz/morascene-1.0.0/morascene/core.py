"""
morascene — простая Python-библиотека для создания 2D-сцен с помощью pygame.

Команды:
    morascene.create("Название", id)
    morascene.id_1.page(800, 600)
    morascene.id_1.pagecolor(r, g, b)
    morascene.id_1.pageclear(r, g, b)
    morascene.id_1.pagetext(x, y, "Arial", 40, "Текст", r, g, b)
    morascene.id_1.pageline(x1, y1, x2, y2, толщина, r, g, b)
    morascene.id_1.pagesquer(x, y, w, h, залит, толщина, r, g, b)
    morascene.id_1.pagecircle(cx, cy, радиус, залит, толщина, r, g, b)
    morascene.id_1.pagewait(секунды)
    morascene.id_1.pagecruch()         — закрыть окно
    morascene.id_1.pagecont(2)         — перейти на сцену 2 (окно остаётся,
                                         меняется название и активная сцена)
"""

import pygame
import sys
import time
import threading
import queue as _queue_mod


# ─────────────────────────────────────────────────────────────────────────────
#  Один общий pygame-поток для всех сцен
# ─────────────────────────────────────────────────────────────────────────────
_cmd_queue: _queue_mod.Queue = _queue_mod.Queue()
_pygame_ready = threading.Event()
_pygame_thread = None


def _ensure_pygame_thread():
    global _pygame_thread
    if _pygame_thread is not None and _pygame_thread.is_alive():
        return
    _pygame_thread = threading.Thread(target=_pygame_loop, daemon=False)
    _pygame_thread.start()
    _pygame_ready.wait()


def _pygame_loop():
    pygame.init()
    _pygame_ready.set()

    surface = None
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # Выполняем команды из очереди
        while not _cmd_queue.empty():
            try:
                cmd = _cmd_queue.get_nowait()
                if cmd is None:          # сигнал завершения
                    running = False
                    break
                result = cmd(surface)
                if isinstance(result, pygame.Surface):
                    surface = result     # новое окно
            except _queue_mod.Empty:
                break

        if surface and running:
            pygame.display.flip()

        pygame.time.delay(16)

    pygame.quit()


def _run(fn):
    """Поставить команду в очередь и подождать её выполнения."""
    done = threading.Event()
    result_box = [None]

    def wrapper(surface):
        result_box[0] = fn(surface)
        done.set()
        return result_box[0]

    _cmd_queue.put(wrapper)
    done.wait()
    return result_box[0]



def _force_focus():
    """Принудительно вывести pygame-окно на передний план (Windows)."""
    import sys as _sys
    if _sys.platform != "win32":
        return
    try:
        import ctypes
        u32 = ctypes.windll.user32
        k32 = ctypes.windll.kernel32
        hwnd = pygame.display.get_wm_info()["window"]
        # Получаем поток переднего окна и прикрепляем к нему наш поток
        fg_hwnd   = u32.GetForegroundWindow()
        fg_tid    = u32.GetWindowThreadProcessId(fg_hwnd, None)
        our_tid   = k32.GetCurrentThreadId()
        attached  = False
        if fg_tid and fg_tid != our_tid:
            u32.AttachThreadInput(our_tid, fg_tid, True)
            attached = True
        u32.ShowWindow(hwnd, 9)          # SW_RESTORE
        u32.BringWindowToTop(hwnd)
        u32.SetForegroundWindow(hwnd)
        if attached:
            u32.AttachThreadInput(our_tid, fg_tid, False)
    except Exception:
        pass

# ─────────────────────────────────────────────────────────────────────────────
#  Класс сцены
# ─────────────────────────────────────────────────────────────────────────────
class _Scene:
    def __init__(self, name: str, scene_id: int, manager):
        self.name      = name
        self.scene_id  = scene_id
        self._manager  = manager
        self._active   = False   # True когда у этой сцены открыто окно

    # ── Открыть окно ─────────────────────────────────────────────────────────
    def page(self, width: int, height: int):
        _ensure_pygame_thread()

        def _open(surface):
            s = pygame.display.set_mode((width, height))
            pygame.display.set_caption(self.name)
            # Выводим окно на передний план
            pygame.event.pump()
            _force_focus()
            self._active = True
            self._manager._current_scene = self
            return s

        _run(_open)

    # ── Заливка ──────────────────────────────────────────────────────────────
    def pagecolor(self, r: int, g: int, b: int):
        self._check()
        def _f(surface): surface.fill((r, g, b))
        _run(_f)

    def pageclear(self, r: int, g: int, b: int):
        self.pagecolor(r, g, b)

    # ── Текст ────────────────────────────────────────────────────────────────
    def pagetext(self, x, y, font_name, font_size, text, r, g, b):
        self._check()
        def _f(surface):
            font = pygame.font.SysFont(font_name, font_size)
            surf = font.render(text, True, (r, g, b))
            surface.blit(surf, (x, y))
        _run(_f)

    # ── Линия ────────────────────────────────────────────────────────────────
    def pageline(self, x1, y1, x2, y2, width, r, g, b):
        self._check()
        def _f(surface):
            pygame.draw.line(surface, (r, g, b), (x1, y1), (x2, y2), width)
        _run(_f)

    # ── Прямоугольник ────────────────────────────────────────────────────────
    def pagesquer(self, x, y, w, h, filled, width, r, g, b):
        self._check()
        def _f(surface):
            t = 0 if filled else width
            pygame.draw.rect(surface, (r, g, b), pygame.Rect(x, y, w, h), t)
        _run(_f)

    # ── Круг ─────────────────────────────────────────────────────────────────
    def pagecircle(self, cx, cy, radius, filled, width, r, g, b):
        self._check()
        def _f(surface):
            t = 0 if filled else width
            pygame.draw.circle(surface, (r, g, b), (cx, cy), radius, t)
        _run(_f)

    # ── Пауза ────────────────────────────────────────────────────────────────
    def pagewait(self, seconds: float):
        self._check()
        time.sleep(seconds)

    # ── Закрыть окно ─────────────────────────────────────────────────────────
    def pagecruch(self):
        """Закрыть окно этой сцены."""
        self._check()
        self._active = False
        self._manager._current_scene = None
        _cmd_queue.put(None)   # сигнал pygame-потоку завершиться
        # Ждём пока поток действительно завершится
        if _pygame_thread:
            _pygame_thread.join(timeout=2)

    # ── Переход на другую сцену ──────────────────────────────────────────────
    def pagecont(self, target_id: int):
        """
        Переход на сцену с target_id.
        Окно НЕ закрывается — меняется только название и активная сцена.
        """
        self._check()
        target = self._manager._scenes.get(target_id)
        if target is None:
            raise RuntimeError(
                f"morascene: сцена id={target_id} не найдена. "
                f"Сначала вызови morascene.create(..., {target_id})"
            )
        # Переключаем активную сцену
        self._active = False
        target._active = True
        self._manager._current_scene = target

        def _f(surface):
            pygame.display.set_caption(target.name)
            surface.fill((0, 0, 0))   # очищаем экран
            # Выводим окно на передний план
            pygame.event.pump()
            _force_focus()
        _run(_f)

    # ── Приватное ────────────────────────────────────────────────────────────
    def _check(self):
        if not self._active:
            raise RuntimeError(
                f"Сцена id_{self.scene_id} не активна. "
                f"Вызови .page(w, h) или перейди через pagecont."
            )


# ─────────────────────────────────────────────────────────────────────────────
#  Менеджер
# ─────────────────────────────────────────────────────────────────────────────
class _MoraScene:
    def __init__(self):
        self._scenes: dict[int, _Scene] = {}
        self._current_scene = None

    def create(self, name: str, scene_id: int) -> _Scene:
        scene = _Scene(name, scene_id, self)
        self._scenes[scene_id] = scene
        return scene

    def __getattr__(self, item: str) -> _Scene:
        if item.startswith("id_"):
            try:
                sid = int(item[3:])
            except ValueError:
                raise AttributeError(f"morascene: неверный атрибут '{item}'")
            if sid in self._scenes:
                return self._scenes[sid]
            raise AttributeError(
                f"morascene: сцена id={sid} не найдена. "
                f"Сначала вызови morascene.create(..., {sid})"
            )
        raise AttributeError(f"morascene: нет атрибута '{item}'")


# ─────────────────────────────────────────────────────────────────────────────
morascene = _MoraScene()