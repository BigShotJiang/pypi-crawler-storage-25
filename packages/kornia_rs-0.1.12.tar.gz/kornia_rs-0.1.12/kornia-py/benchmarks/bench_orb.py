"""Benchmark kornia-rs ORB vs OpenCV ORB vs NVIDIA VPI ORB on natural imagery.

Timing target: 640x480 and 1920x1080 (set via ORB_BENCH_SIZES). Primary
image is a natural SLAM frame (set via ORB_BENCH_IMG, defaults to dog.jpeg
which has rich outdoor-like texture and matches the Rust-side quality test
`test_orb_compare_with_opencv`).

Reports:
  * kornia-rs vs OpenCV vs VPI(CPU) vs VPI(CUDA) wall-time (ms per call).
  * Keypoint overlap @ 1/3/5 px — quality vs OpenCV. The Rust test floor is
    15% at 3 px; natural images typically land in the 40–75% band.

Tip: drop a KITTI odometry frame into tests/data/ and point ORB_BENCH_IMG
at it for true outdoor imagery.
"""
import glob
import json
import os
import sys
from pathlib import Path

import numpy as np
import kornia_rs as K
from kornia_rs.image import Image
import cv2

from _bench import bench as _bench_fn, compat_print


def _load_gray(path, size=None):
    """Load an image as 2D u8 grayscale via the kornia Image API.

    `size` is `(width, height)` if a resize is needed. cv2 appears in this
    bench only as a timing comparison target — never in the setup path.
    """
    img = Image.load(str(path)).to_grayscale()
    if size is not None:
        w, h = size
        img = img.resize(width=w, height=h, interpolation="bilinear")
    return img.to_numpy()[..., 0]

# VPI ships its Python bindings outside the standard site-packages tree.
# Honor an explicit override (KORNIA_VPI_PYPATH); otherwise probe the usual
# `/opt/nvidia/vpi*/lib/<arch>/python` install layout. Skip silently if VPI
# isn't installed — `HAVE_VPI` becomes False and the bench reports kornia
# vs OpenCV only.
_vpi_path = os.environ.get("KORNIA_VPI_PYPATH") or next(
    iter(glob.glob("/opt/nvidia/vpi*/lib/*/python")), None
)
if _vpi_path and os.path.isdir(_vpi_path):
    sys.path.insert(0, _vpi_path)
try:
    import vpi
    HAVE_VPI = True
except ImportError:
    HAVE_VPI = False

DATA_DIR = Path(__file__).resolve().parents[2] / "tests" / "data"

N_ITERS = int(os.environ.get("ORB_BENCH_N", "200"))
N_WARMUP = int(os.environ.get("ORB_BENCH_WARMUP", "10"))
TEST_IMG = os.environ.get("ORB_BENCH_IMG", str(DATA_DIR / "dog.jpeg"))
QUALITY_IMGS = [
    str(DATA_DIR / "dog.jpeg"),
    str(DATA_DIR / "mh01_frame1.png"),
    str(DATA_DIR / "mh01_frame2.png"),
]

# VPI ORB parameters — matches the sample defaults scaled up for 500 features.
VPI_PARAMS = dict(intensity_threshold=20, max_features_per_level=500, max_pyr_levels=3)


def bench(name, fn, n=None, warmup=None):
    return compat_print(name, _bench_fn(fn))


def _xy_from_vpi(corners_array):
    """VPI returns (x, y, level, reserved); scale xy back to base-image coords."""
    if corners_array.size == 0:
        return np.zeros((0, 2), dtype=np.float32)
    scale = np.power(2.0, corners_array[:, 2]).astype(np.float32)
    return np.stack([corners_array[:, 0] * scale, corners_array[:, 1] * scale], axis=1)


def vpi_orb_run(gray, backend, src=None):
    """Call VPI ORB end-to-end (pyramid + orb) and return base-image xy coords.

    If `src` is None (default) the numpy array is wrapped on every call, which
    adds ~1 ms/call of pure overhead that a real pipeline would not pay (the
    image is wrapped once at ingest, not per frame). Pass a cached
    `vpi.asimage(gray)` to time the kernel path fairly — the bench uses the
    cached version for timing and the uncached path only for one-shot quality
    checks."""
    if src is None:
        src = vpi.asimage(gray)
    with backend:
        pyr = src.gaussian_pyramid(VPI_PARAMS["max_pyr_levels"])
        corners, descriptors = pyr.orb(**VPI_PARAMS)
    with corners.rlock_cpu() as c:
        return _xy_from_vpi(np.asarray(c, dtype=np.float32))


def overlap_stats(kps_a, kps_b):
    """Overlap of kps_a against reference kps_b at 1/3/5 px."""
    a_xy = np.asarray(kps_a, dtype=np.float32).reshape(-1, 2)
    b_xy = np.asarray(kps_b, dtype=np.float32).reshape(-1, 2)
    if len(a_xy) == 0 or len(b_xy) == 0:
        return {1: 0.0, 3: 0.0, 5: 0.0}
    d = np.linalg.norm(a_xy[:, None, :] - b_xy[None, :, :], axis=2)
    min_d = d.min(axis=1)
    return {t: float((min_d <= t).mean()) for t in (1, 3, 5)}


def cv_xy(kps_cv):
    return np.asarray([kp.pt for kp in kps_cv], dtype=np.float32) if kps_cv else np.zeros((0, 2), dtype=np.float32)


def quality_report():
    """Cross-image overlap vs OpenCV — same config as the timing bench."""
    print(f"\n{'='*72}\nQuality check across natural images (overlap vs OpenCV)\n{'='*72}")
    orb_cv = cv2.ORB_create(nfeatures=500, scaleFactor=1.2, nlevels=8,
                             edgeThreshold=31, firstLevel=0, WTA_K=2,
                             scoreType=cv2.ORB_HARRIS_SCORE,
                             patchSize=31, fastThreshold=20)
    hdr = f"  {'image':28s} {'n_k':>4s} {'n_cv':>4s} {'n_vpi':>5s}"
    hdr += f"  {'k@3':>5s} {'vpi@3':>6s}"
    print(hdr)
    for path in QUALITY_IMGS:
        if not os.path.isfile(path):
            continue
        img = _load_gray(path)
        feat_k = K.features.orb_detect_and_compute(img)
        kps_cv, _ = orb_cv.detectAndCompute(img, None)
        k_xy = np.asarray(feat_k.keypoints_xy, dtype=np.float32).reshape(-1, 2)
        cv_pts = cv_xy(kps_cv)
        ok = overlap_stats(k_xy, cv_pts)

        if HAVE_VPI:
            vpi_xy = vpi_orb_run(img, vpi.Backend.CPU)
            ov = overlap_stats(vpi_xy, cv_pts)
            n_vpi = len(vpi_xy)
            vpi_3 = f"{ov[3]*100:5.1f}%"
        else:
            n_vpi = 0
            vpi_3 = "  n/a"

        name = os.path.basename(path)
        print(f"  {name:28s} {len(k_xy):>4d} {len(kps_cv):>4d} {n_vpi:>5d}"
              f"  {ok[3]*100:4.1f}% {vpi_3:>6s}")


def run_benchmarks():
    results = {}

    for label, (h, w) in [("640x480", (480, 640)), ("1920x1080", (1080, 1920))]:
        print(f"\n{'='*72}")
        print(f"Image size: {label} (HxW={h}x{w}, gray uint8)")
        print(f"{'='*72}")

        assert os.path.isfile(TEST_IMG), f"missing test image: {TEST_IMG}"
        gray = _load_gray(TEST_IMG, size=(w, h))

        orb_cv = cv2.ORB_create(nfeatures=500, scaleFactor=1.2, nlevels=8,
                                 edgeThreshold=31, firstLevel=0, WTA_K=2,
                                 scoreType=cv2.ORB_HARRIS_SCORE,
                                 patchSize=31, fastThreshold=20)

        print(f"\n--- ORB detect + compute  (input: {os.path.basename(TEST_IMG)}) ---")
        feat_k = K.features.orb_detect_and_compute(gray)
        kps_cv, _ = orb_cv.detectAndCompute(gray, None)
        k_xy = np.asarray(feat_k.keypoints_xy, dtype=np.float32).reshape(-1, 2)
        cv_pts = cv_xy(kps_cv)
        o_k = overlap_stats(k_xy, cv_pts)
        print(f"  kornia={len(k_xy)} kps, opencv={len(kps_cv)} kps")
        print(f"  kornia overlap vs OpenCV: 1px={o_k[1]*100:4.1f}%  "
              f"3px={o_k[3]*100:4.1f}%  5px={o_k[5]*100:4.1f}%")

        if HAVE_VPI:
            vpi_cpu_xy = vpi_orb_run(gray, vpi.Backend.CPU)
            vpi_cuda_xy = vpi_orb_run(gray, vpi.Backend.CUDA)
            o_vpi_cpu = overlap_stats(vpi_cpu_xy, cv_pts)
            o_vpi_cuda = overlap_stats(vpi_cuda_xy, cv_pts)
            print(f"  vpi-cpu={len(vpi_cpu_xy)} kps  overlap vs OpenCV: "
                  f"1px={o_vpi_cpu[1]*100:4.1f}%  3px={o_vpi_cpu[3]*100:4.1f}%  "
                  f"5px={o_vpi_cpu[5]*100:4.1f}%")
            print(f"  vpi-cuda={len(vpi_cuda_xy)} kps  overlap vs OpenCV: "
                  f"1px={o_vpi_cuda[1]*100:4.1f}%  3px={o_vpi_cuda[3]*100:4.1f}%  "
                  f"5px={o_vpi_cuda[5]*100:4.1f}%")

        row = {
            "kornia":  bench("kornia-rs",  lambda: K.features.orb_detect_and_compute(gray)),
            "opencv":  bench("opencv",     lambda: orb_cv.detectAndCompute(gray, None)),
        }
        if HAVE_VPI:
            # Cache the VPI image wrapper outside the hot loop — a real app wraps once
            # and reuses; the per-call `vpi.asimage(gray)` is pure bench-harness overhead.
            vpi_src = vpi.asimage(gray)
            row["vpi_cpu"] = bench(
                "vpi (CPU, cached src)",
                lambda: vpi_orb_run(gray, vpi.Backend.CPU, src=vpi_src),
            )
            row["vpi_cuda"] = bench(
                "vpi (CUDA, cached src)",
                lambda: vpi_orb_run(gray, vpi.Backend.CUDA, src=vpi_src),
            )

        results[label] = row

    return results


if __name__ == "__main__":
    if not HAVE_VPI:
        print("[warn] VPI not importable — VPI comparison will be skipped.")
    quality_report()
    results = run_benchmarks()
    print("\n" + json.dumps(results, indent=2))
