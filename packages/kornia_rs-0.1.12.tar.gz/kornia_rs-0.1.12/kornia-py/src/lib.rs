mod apriltag;
mod augmentations;
mod ba;
mod blur;
mod brightness;
mod color;
mod cpu;
mod crop;
mod depth;
mod enhance;
mod feature_match;
mod flip;
mod histogram;
mod homography;
mod icp;
mod image;
mod io;
mod normalize;
mod orb;
mod pgo;
mod pipeline;
mod pnp;
mod pointcloud;
mod pyutils;
mod ransac;
mod resize;
mod segmentation;
mod twoview;
mod warp;

use crate::icp::{PyICPConvergenceCriteria, PyICPResult};
use crate::image::{PyImageLayout, PyImageSize, PyPixelFormat};
#[cfg(feature = "turbojpeg")]
use crate::io::jpegturbo::{PyImageDecoder, PyImageEncoder};
use numpy::{PyArray1, PyArray2};
use pyo3::exceptions::PyDeprecationWarning;
use pyo3::prelude::*;

pub fn get_version() -> String {
    let version = env!("CARGO_PKG_VERSION").to_string();
    // cargo uses "1.0-alpha1" etc. while python uses "1.0.0a1", this is not full compatibility,
    // but it's good enough for now
    // see https://docs.rs/semver/1.0.9/semver/struct.Version.html#method.parse for rust spec
    // see https://peps.python.org/pep-0440/ for python spec
    // it seems the dot after "alpha/beta" e.g. "-alpha.1" is not necessary, hence why this works
    version.replace("-alpha", "a").replace("-beta", "b")
}

/// Helper to emit a deprecation warning in Python
fn warn_deprecation(py: Python<'_>, message: &str) -> PyResult<()> {
    use std::ffi::CString;
    let message_cstr = CString::new(message).map_err(|_| {
        PyErr::new::<pyo3::exceptions::PyValueError, _>(
            "Deprecation warning message contained a null byte",
        )
    })?;

    pyo3::PyErr::warn(
        py,
        &py.get_type::<PyDeprecationWarning>(),
        message_cstr.as_c_str(),
        2,
    )
}

// Root Level Deprecated Wrappers

// Color
#[pyfunction(name = "rgb_from_gray")]
pub fn rgb_from_gray_deprecated(py: Python<'_>, image: image::PyImage) -> PyResult<image::PyImage> {
    warn_deprecation(
        py,
        "kornia_rs.rgb_from_gray is deprecated. Use kornia_rs.imgproc.rgb_from_gray.",
    )?;
    color::rgb_from_gray(py, image)
}

#[pyfunction(name = "rgb_from_rgba")]
#[pyo3(signature = (image, background=None))]
pub fn rgb_from_rgba_deprecated(
    py: Python<'_>,
    image: image::PyImage,
    background: Option<[u8; 3]>,
) -> PyResult<image::PyImage> {
    warn_deprecation(
        py,
        "kornia_rs.rgb_from_rgba is deprecated. Use kornia_rs.imgproc.rgb_from_rgba.",
    )?;
    color::rgb_from_rgba(py, image, background)
}

#[pyfunction(name = "rgb_from_bgra")]
#[pyo3(signature = (image, background=None))]
pub fn rgb_from_bgra_deprecated(
    py: Python<'_>,
    image: image::PyImage,
    background: Option<[u8; 3]>,
) -> PyResult<image::PyImage> {
    warn_deprecation(
        py,
        "kornia_rs.rgb_from_bgra is deprecated. Use kornia_rs.imgproc.rgb_from_bgra.",
    )?;
    color::rgb_from_bgra(py, image, background)
}

#[pyfunction(name = "bgr_from_rgb")]
pub fn bgr_from_rgb_deprecated(py: Python<'_>, image: image::PyImage) -> PyResult<image::PyImage> {
    warn_deprecation(
        py,
        "kornia_rs.bgr_from_rgb is deprecated. Use kornia_rs.imgproc.bgr_from_rgb.",
    )?;
    color::bgr_from_rgb(py, image)
}

#[pyfunction(name = "gray_from_rgb")]
pub fn gray_from_rgb_deprecated(py: Python<'_>, image: image::PyImage) -> PyResult<image::PyImage> {
    warn_deprecation(
        py,
        "kornia_rs.gray_from_rgb is deprecated. Use kornia_rs.imgproc.gray_from_rgb.",
    )?;
    color::gray_from_rgb(py, image)
}

// Enhance / Histogram
#[pyfunction(name = "add_weighted")]
pub fn add_weighted_deprecated(
    py: Python<'_>,
    src1: image::PyImage,
    alpha: f32,
    src2: image::PyImage,
    beta: f32,
    gamma: f32,
) -> PyResult<image::PyImage> {
    warn_deprecation(
        py,
        "kornia_rs.add_weighted is deprecated. Use kornia_rs.imgproc.add_weighted.",
    )?;
    enhance::add_weighted(py, src1, alpha, src2, beta, gamma)
}

#[pyfunction(name = "compute_histogram")]
pub fn compute_histogram_deprecated(
    py: Python<'_>,
    image: image::PyImage,
    nbins: usize,
) -> PyResult<Vec<usize>> {
    warn_deprecation(
        py,
        "kornia_rs.compute_histogram is deprecated. Use kornia_rs.imgproc.compute_histogram.",
    )?;
    histogram::compute_histogram(py, image, nbins)
}

// ICP
#[pyfunction(name = "icp_vanilla")]
pub fn icp_vanilla_deprecated(
    py: Python<'_>,
    source: pointcloud::PyPointCloud,
    target: pointcloud::PyPointCloud,
    initial_rot: Py<PyArray2<f64>>,
    initial_trans: Py<PyArray1<f64>>,
    criteria: PyICPConvergenceCriteria,
) -> PyResult<PyICPResult> {
    warn_deprecation(
        py,
        "kornia_rs.icp_vanilla is deprecated. Use kornia_rs.k3d.icp_vanilla.",
    )?;

    icp::icp_vanilla(source, target, initial_rot, initial_trans, criteria)
}

// IO
#[pyfunction(name = "read_image")]
pub fn read_image_deprecated(py: Python<'_>, file_path: Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
    warn_deprecation(
        py,
        "kornia_rs.read_image is deprecated. Use kornia_rs.io.read_image.",
    )?;
    io::functional::read_image(py, file_path)
}

// JPEG
#[pyfunction(name = "read_image_jpeg")]
pub fn read_image_jpeg_deprecated(
    py: Python<'_>,
    file_path: &str,
    mode: &str,
) -> PyResult<image::PyImage> {
    warn_deprecation(
        py,
        "kornia_rs.read_image_jpeg is deprecated. Use kornia_rs.io.read_image_jpeg.",
    )?;
    io::jpeg::read_image_jpeg(py, file_path, mode)
}

#[pyfunction(name = "write_image_jpeg")]
pub fn write_image_jpeg_deprecated(
    py: Python<'_>,
    file_path: &str,
    image: image::PyImage,
    mode: &str,
    quality: u8,
) -> PyResult<()> {
    warn_deprecation(
        py,
        "kornia_rs.write_image_jpeg is deprecated. Use kornia_rs.io.write_image_jpeg.",
    )?;
    io::jpeg::write_image_jpeg(py, file_path, image, mode, quality)
}

// PNG
#[pyfunction(name = "read_image_png_u8")]
pub fn read_image_png_u8_deprecated(
    py: Python<'_>,
    file_path: &str,
    mode: &str,
) -> PyResult<image::PyImage> {
    warn_deprecation(
        py,
        "kornia_rs.read_image_png_u8 is deprecated. Use kornia_rs.io.read_image_png_u8.",
    )?;
    io::png::read_image_png_u8(py, file_path, mode)
}

#[pyfunction(name = "write_image_png_u8")]
pub fn write_image_png_u8_deprecated(
    py: Python<'_>,
    file_path: &str,
    image: image::PyImage,
    mode: &str,
) -> PyResult<()> {
    warn_deprecation(
        py,
        "kornia_rs.write_image_png_u8 is deprecated. Use kornia_rs.io.write_image_png_u8.",
    )?;
    io::png::write_image_png_u8(py, file_path, image, mode)
}

// Resize
#[pyfunction(name = "resize")]
pub fn resize_deprecated(
    py: Python<'_>,
    image: image::PyImage,
    new_size: (usize, usize),
    interpolation: &str,
) -> PyResult<image::PyImage> {
    warn_deprecation(
        py,
        "kornia_rs.resize is deprecated. Use kornia_rs.imgproc.resize.",
    )?;
    resize::resize(py, image, new_size, interpolation, true)
}

// Warp
#[pyfunction(name = "warp_affine")]
pub fn warp_affine_deprecated(
    py: Python<'_>,
    image: image::PyImage,
    m: [f32; 6],
    new_size: (usize, usize),
    interpolation: &str,
) -> PyResult<image::PyImage> {
    warn_deprecation(
        py,
        "kornia_rs.warp_affine is deprecated. Use kornia_rs.imgproc.warp_affine.",
    )?;
    warp::warp_affine(py, image, m, new_size, interpolation, None)
}

#[pyfunction(name = "warp_perspective")]
pub fn warp_perspective_deprecated(
    py: Python<'_>,
    image: image::PyImage,
    m: [f32; 9],
    new_size: (usize, usize),
    interpolation: &str,
) -> PyResult<image::PyImage> {
    warn_deprecation(
        py,
        "kornia_rs.warp_perspective is deprecated. Use kornia_rs.imgproc.warp_perspective.",
    )?;
    warp::warp_perspective(py, image, m, new_size, interpolation, None)
}

// Main Python Module Definition

#[pymodule(gil_used = false)]
pub fn kornia_rs(m: &Bound<'_, PyModule>) -> PyResult<()> {
    let py = m.py();
    m.add("__version__", get_version())?;

    // Deprecated root-level functions
    m.add_function(wrap_pyfunction!(rgb_from_gray_deprecated, m)?)?;
    m.add_function(wrap_pyfunction!(rgb_from_rgba_deprecated, m)?)?;
    m.add_function(wrap_pyfunction!(rgb_from_bgra_deprecated, m)?)?;
    m.add_function(wrap_pyfunction!(bgr_from_rgb_deprecated, m)?)?;
    m.add_function(wrap_pyfunction!(gray_from_rgb_deprecated, m)?)?;
    m.add_function(wrap_pyfunction!(add_weighted_deprecated, m)?)?;
    m.add_function(wrap_pyfunction!(compute_histogram_deprecated, m)?)?;
    m.add_function(wrap_pyfunction!(icp_vanilla_deprecated, m)?)?;
    m.add_function(wrap_pyfunction!(read_image_deprecated, m)?)?;
    m.add_function(wrap_pyfunction!(
        io::functional::read_image_any_deprecated,
        m
    )?)?;
    m.add_function(wrap_pyfunction!(read_image_jpeg_deprecated, m)?)?;
    m.add_function(wrap_pyfunction!(write_image_jpeg_deprecated, m)?)?;
    m.add_function(wrap_pyfunction!(read_image_png_u8_deprecated, m)?)?;
    m.add_function(wrap_pyfunction!(write_image_png_u8_deprecated, m)?)?;
    m.add_function(wrap_pyfunction!(resize_deprecated, m)?)?;
    m.add_function(wrap_pyfunction!(warp_affine_deprecated, m)?)?;
    m.add_function(wrap_pyfunction!(warp_perspective_deprecated, m)?)?;

    // Deprecated root-level classes
    // PyO3 does not support emitting a deprecation warning when a class is imported.
    // These top-level classes are retained for backward compatibility purposes only.
    // Users should import them from `kornia_rs::k3d`
    m.add_class::<PyICPConvergenceCriteria>()?;
    m.add_class::<PyICPResult>()?;

    // Image submodule
    let image_mod = PyModule::new(py, "image")?;
    image_mod.add_class::<PyImageSize>()?;
    image_mod.add_class::<PyPixelFormat>()?;
    image_mod.add_class::<PyImageLayout>()?;
    image_mod.add_class::<image::PyImageApi>()?;
    m.add_submodule(&image_mod)?;

    // ---------------------------------------------------------------------------
    // IO submodule (Python-only)
    //
    // The helpers registered below (`kornia_rs.io.read_image`, `decode_image_*`,
    // `write_image_*`) are Python-only convenience APIs. They are intentionally
    // NOT part of the Rust public API of `kornia-io`. Rust consumers should use
    // the typed per-format functions in `kornia_io::{jpeg, png, tiff}` directly,
    // or `kornia_io::functional::read_image_any_rgb8` for a single generic RGB8
    // path. See https://github.com/kornia/kornia-rs/issues/637.
    // ---------------------------------------------------------------------------
    let io_mod = PyModule::new(py, "io")?;

    // NOTE:
    // Some IO helpers (e.g. decode/enc helpers and TIFF internals)
    // are now available only under `kornia_rs.io`.
    // There are no deprecated root-scoped aliases among these functions.
    io_mod.add_function(wrap_pyfunction!(io::functional::read_image, &io_mod)?)?;
    io_mod.add_function(wrap_pyfunction!(io::png::decode_image_png_u8, &io_mod)?)?;
    io_mod.add_function(wrap_pyfunction!(io::png::decode_image_png_u16, &io_mod)?)?;
    io_mod.add_function(wrap_pyfunction!(io::png::read_image_png_u8, &io_mod)?)?;
    io_mod.add_function(wrap_pyfunction!(io::png::read_image_png_u16, &io_mod)?)?;
    io_mod.add_function(wrap_pyfunction!(io::png::write_image_png_u8, &io_mod)?)?;
    io_mod.add_function(wrap_pyfunction!(io::png::write_image_png_u16, &io_mod)?)?;
    io_mod.add_function(wrap_pyfunction!(io::jpeg::decode_image_jpeg, &io_mod)?)?;
    io_mod.add_function(wrap_pyfunction!(io::jpeg::read_image_jpeg, &io_mod)?)?;
    io_mod.add_function(wrap_pyfunction!(io::jpeg::write_image_jpeg, &io_mod)?)?;
    io_mod.add_function(wrap_pyfunction!(io::jpeg::encode_image_jpeg, &io_mod)?)?;
    io_mod.add_function(wrap_pyfunction!(io::tiff::read_image_tiff_f32, &io_mod)?)?;
    io_mod.add_function(wrap_pyfunction!(io::tiff::read_image_tiff_u8, &io_mod)?)?;
    io_mod.add_function(wrap_pyfunction!(io::tiff::read_image_tiff_u16, &io_mod)?)?;
    io_mod.add_function(wrap_pyfunction!(io::tiff::write_image_tiff_f32, &io_mod)?)?;
    io_mod.add_function(wrap_pyfunction!(io::tiff::write_image_tiff_u8, &io_mod)?)?;
    io_mod.add_function(wrap_pyfunction!(io::tiff::write_image_tiff_u16, &io_mod)?)?;
    io_mod.add_function(wrap_pyfunction!(io::rvl::encode_image_rvl, &io_mod)?)?;
    io_mod.add_function(wrap_pyfunction!(io::rvl::decode_image_rvl, &io_mod)?)?;
    io_mod.add_function(wrap_pyfunction!(io::rvl::write_image_rvl, &io_mod)?)?;
    io_mod.add_function(wrap_pyfunction!(io::rvl::read_image_rvl, &io_mod)?)?;
    #[cfg(feature = "turbojpeg")]
    io_mod.add_function(wrap_pyfunction!(
        io::jpegturbo::decode_image_jpegturbo,
        &io_mod
    )?)?;
    #[cfg(feature = "turbojpeg")]
    io_mod.add_function(wrap_pyfunction!(
        io::jpegturbo::encode_image_jpegturbo,
        &io_mod
    )?)?;
    #[cfg(feature = "turbojpeg")]
    io_mod.add_function(wrap_pyfunction!(
        io::jpegturbo::read_image_jpegturbo,
        &io_mod
    )?)?;
    #[cfg(feature = "turbojpeg")]
    io_mod.add_function(wrap_pyfunction!(
        io::jpegturbo::write_image_jpegturbo,
        &io_mod
    )?)?;
    #[cfg(feature = "turbojpeg")]
    io_mod.add_class::<PyImageDecoder>()?;
    #[cfg(feature = "turbojpeg")]
    io_mod.add_class::<PyImageEncoder>()?;
    m.add_submodule(&io_mod)?;

    // Imgproc submodule
    let imgproc_mod = PyModule::new(py, "imgproc")?;
    imgproc_mod.add_function(wrap_pyfunction!(color::rgb_from_gray, &imgproc_mod)?)?;
    imgproc_mod.add_function(wrap_pyfunction!(color::rgb_from_rgba, &imgproc_mod)?)?;
    imgproc_mod.add_function(wrap_pyfunction!(color::rgb_from_bgra, &imgproc_mod)?)?;
    imgproc_mod.add_function(wrap_pyfunction!(color::bgr_from_rgb, &imgproc_mod)?)?;
    imgproc_mod.add_function(wrap_pyfunction!(color::gray_from_rgb, &imgproc_mod)?)?;
    imgproc_mod.add_function(wrap_pyfunction!(color::apply_colormap, &imgproc_mod)?)?;
    imgproc_mod.add_function(wrap_pyfunction!(enhance::add_weighted, &imgproc_mod)?)?;
    imgproc_mod.add_function(wrap_pyfunction!(
        histogram::compute_histogram,
        &imgproc_mod
    )?)?;
    imgproc_mod.add_function(wrap_pyfunction!(resize::resize, &imgproc_mod)?)?;
    imgproc_mod.add_function(wrap_pyfunction!(warp::warp_affine, &imgproc_mod)?)?;
    imgproc_mod.add_function(wrap_pyfunction!(warp::warp_perspective, &imgproc_mod)?)?;
    imgproc_mod.add_function(wrap_pyfunction!(flip::horizontal_flip, &imgproc_mod)?)?;
    imgproc_mod.add_function(wrap_pyfunction!(flip::vertical_flip, &imgproc_mod)?)?;
    imgproc_mod.add_function(wrap_pyfunction!(crop::crop, &imgproc_mod)?)?;
    imgproc_mod.add_function(wrap_pyfunction!(blur::gaussian_blur, &imgproc_mod)?)?;
    imgproc_mod.add_function(wrap_pyfunction!(blur::box_blur, &imgproc_mod)?)?;
    imgproc_mod.add_function(wrap_pyfunction!(
        brightness::adjust_brightness_py,
        &imgproc_mod
    )?)?;
    imgproc_mod.add_function(wrap_pyfunction!(
        normalize::normalize_mean_std,
        &imgproc_mod
    )?)?;
    m.add_submodule(&imgproc_mod)?;

    // Features submodule — feature detectors and descriptors.
    let features_mod = PyModule::new(py, "features")?;
    features_mod.add_class::<orb::PyOrbFeatures>()?;
    features_mod.add_function(wrap_pyfunction!(
        orb::orb_detect_and_compute,
        &features_mod
    )?)?;
    features_mod.add_function(wrap_pyfunction!(orb::fast_detect, &features_mod)?)?;
    features_mod.add_function(wrap_pyfunction!(
        feature_match::match_descriptors_py,
        &features_mod
    )?)?;
    m.add_submodule(&features_mod)?;

    // Augmentations submodule
    let aug_mod = PyModule::new(py, "augmentations")?;
    aug_mod.add_class::<augmentations::PyColorJitter>()?;
    aug_mod.add_class::<augmentations::PyRandomHorizontalFlip>()?;
    aug_mod.add_class::<augmentations::PyRandomVerticalFlip>()?;
    aug_mod.add_class::<augmentations::PyRandomCrop>()?;
    aug_mod.add_class::<augmentations::PyRandomRotation>()?;
    aug_mod.add_class::<augmentations::PyCompose>()?;
    aug_mod.add_function(wrap_pyfunction!(augmentations::set_seed, &aug_mod)?)?;
    m.add_submodule(&aug_mod)?;

    // K3D submodule — 3D geometry: ICP, two-view pose, F/H/E model fits, triangulation.
    let k3d_mod = PyModule::new(py, "k3d")?;
    k3d_mod.add_function(wrap_pyfunction!(icp::icp_vanilla, &k3d_mod)?)?;
    k3d_mod.add_class::<PyICPConvergenceCriteria>()?;
    k3d_mod.add_class::<PyICPResult>()?;
    k3d_mod.add_class::<twoview::PyTwoViewPose>()?;
    k3d_mod.add_class::<twoview::PyFundamental8ptSolver>()?;
    k3d_mod.add_class::<twoview::PyEssentialNister5ptSolver>()?;
    k3d_mod.add_class::<twoview::PyLmRefiner>()?;
    k3d_mod.add_class::<twoview::PyNoopRefiner>()?;
    k3d_mod.add_class::<twoview::PyTwoViewEstimator>()?;
    k3d_mod.add_function(wrap_pyfunction!(twoview::two_view_estimate_py, &k3d_mod)?)?;
    k3d_mod.add_function(wrap_pyfunction!(
        homography::ransac_homography_py,
        &k3d_mod
    )?)?;
    k3d_mod.add_function(wrap_pyfunction!(homography::find_homography_py, &k3d_mod)?)?;
    k3d_mod.add_function(wrap_pyfunction!(homography::find_fundamental_py, &k3d_mod)?)?;
    k3d_mod.add_function(wrap_pyfunction!(pnp::solve_pnp_ransac_py, &k3d_mod)?)?;
    k3d_mod.add_function(wrap_pyfunction!(ba::bundle_adjust_py, &k3d_mod)?)?;
    k3d_mod.add_function(wrap_pyfunction!(pgo::pose_graph_optimize_py, &k3d_mod)?)?;
    m.add_submodule(&k3d_mod)?;

    // Apriltag submodule
    let apriltag_mod = PyModule::new(py, "apriltag")?;
    apriltag_mod.add_class::<apriltag::PyDecodeTagsConfig>()?;
    apriltag_mod.add_class::<apriltag::PyFitQuadConfig>()?;
    apriltag_mod.add_class::<apriltag::PyAprilTagDecoder>()?;
    apriltag_mod.add_class::<apriltag::PyApriltagDetection>()?;
    apriltag_mod.add_class::<apriltag::PyQuad>()?;
    apriltag_mod.add_class::<apriltag::family::PyTagFamilyKind>()?;

    let apriltag_family_mod = PyModule::new(py, "family")?;
    apriltag_family_mod.add_class::<apriltag::family::PyTagFamily>()?;
    apriltag_family_mod.add_class::<apriltag::family::PyTagFamilyKind>()?;
    apriltag_family_mod.add_class::<apriltag::family::PyQuickDecode>()?;
    apriltag_family_mod.add_class::<apriltag::family::PySharpeningBuffer>()?;
    apriltag_mod.add_submodule(&apriltag_family_mod)?;

    m.add_submodule(&apriltag_mod)?;

    // RANSAC submodule — generic robust estimation + the F/E/H/EPnP
    // estimators wired into a single `kornia_rs.ransac.*` namespace. The
    // Python signatures mirror OpenCV's calling convention so that
    // benchmark scripts can swap one import for the other.
    ransac::register(py, m)?;

    // CPU submodule — runtime SIMD feature probe. Lets installed wheels
    // self-report which SIMD paths the host actually exposes, complementing
    // the build-time `verify_simd_kernels.sh` that proves the assembly is
    // present in the binary.
    let cpu_mod = PyModule::new(py, "cpu")?;
    cpu_mod.add_class::<cpu::PyCpuFeatures>()?;
    cpu_mod.add_function(wrap_pyfunction!(cpu::cpu_features, &cpu_mod)?)?;
    m.add_submodule(&cpu_mod)?;

    // Pipeline submodule — fused preprocessing kernels.
    let pipeline_mod = PyModule::new(py, "pipeline")?;
    pipeline_mod.add_function(wrap_pyfunction!(
        pipeline::resize_normalize_to_tensor,
        &pipeline_mod
    )?)?;
    pipeline_mod.add_class::<pipeline::Preprocessor>()?;
    m.add_submodule(&pipeline_mod)?;

    // Segmentation submodule — COCO RLE ↔ mask conversions.
    let seg_mod = PyModule::new(py, "segmentation")?;
    seg_mod.add_function(wrap_pyfunction!(segmentation::rle_to_mask, &seg_mod)?)?;
    seg_mod.add_function(wrap_pyfunction!(segmentation::mask_to_rle, &seg_mod)?)?;
    m.add_submodule(&seg_mod)?;

    // Depth submodule — depth sampling under segmentation masks.
    let depth_mod = PyModule::new(py, "depth")?;
    depth_mod.add_function(wrap_pyfunction!(depth::sample_depth, &depth_mod)?)?;
    m.add_submodule(&depth_mod)?;

    // Register submodules in sys.modules so `from kornia_rs.image import Image` works
    let modules =
        unsafe { pyo3::Bound::from_borrowed_ptr(py, pyo3::ffi::PyImport_GetModuleDict()) };
    for (name, submod) in [
        ("kornia_rs.image", &image_mod),
        ("kornia_rs.io", &io_mod),
        ("kornia_rs.imgproc", &imgproc_mod),
        ("kornia_rs.k3d", &k3d_mod),
        ("kornia_rs.apriltag", &apriltag_mod),
        ("kornia_rs.augmentations", &aug_mod),
        ("kornia_rs.pipeline", &pipeline_mod),
        ("kornia_rs.features", &features_mod),
        ("kornia_rs.cpu", &cpu_mod),
        ("kornia_rs.segmentation", &seg_mod),
        ("kornia_rs.depth", &depth_mod),
    ] {
        modules.set_item(name, submod)?;
    }

    Ok(())
}
