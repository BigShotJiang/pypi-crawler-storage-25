# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [5.0.1] - 2026-04-22

### Fixed
- License validation API hardened against 500 errors with top-level exception handling, atomic database writes, and JSON structure validation
- Exploit PoC files now correctly land inside per-scan report directories instead of root exploits/ folder
- License validation URL path corrected to include /api prefix matching FastAPI router mount
- Per-scan report directories organize scan outputs by project name, date, and session ID to prevent overwrites
- Auth dependencies (passlib, authlib, httpx, itsdangerous) added to core dependencies for CI compatibility
- Input validation added to all API request models (license key format, machine ID length, version format)
- Rate limiting added to license validation and deactivation endpoints
- Stripe webhook signature verification made mandatory
- Admin endpoint /api/license/info now requires authentication
- CORS middleware configured for production origins
- Security event logging added for failed validations, deactivations, and webhook failures
- MANIFEST.in updated from garrison.toml to counterscarp.toml references
- Automated cleanup for state files, reports, uploads, and log rotation

### Security
- API hardening: input validation, rate limiting, authentication controls
- Stripe webhook: unsigned payloads now rejected when webhook secret is not configured
- Session secret: warning issued when using insecure default
- Path traversal protection on report download endpoints
- File upload validation ensures UTF-8 text content only

## [5.0.0] - 2026-04-22

### Added
- Complete rebrand from Garrison Engine to Counterscarp Engine
- User authentication with Google OAuth 2.0 and email/password registration
- Per-user license management — licenses linked to user accounts instead of server-wide
- Automatic license auto-linking at Stripe checkout for logged-in users
- Automatic license discovery on registration (links pre-purchased licenses by email)
- Auto-apply user license on login across any device
- Enhanced `/admin/users` endpoint with license key (masked), tier, auth method, and last login
- Login/register pages with dark theme matching existing UI
- Session-based authentication with cookie management
- Protected settings page (requires login)
- Conditional navigation bar (logged-in vs guest)

### Changed
- License activation moved from server-wide environment variable to per-user account storage
- Settings page license management now per-user with backward-compatible env var fallback
- Checkout success page shows auto-link confirmation for logged-in users or login prompt for guests

### Dependencies
- Added `authlib>=1.3.0`, `httpx>=0.25.0`, `itsdangerous>=2.1.0`, `passlib[bcrypt]>=1.7.4`

## [4.0.0] - 2026-04-21

### Added
- Stripe Checkout integration with automatic license key provisioning
- Pricing page with Pro Monthly and Pro Annual plans
- Webhook handler for `checkout.session.completed` events
- GUI-based license key management on settings page

## [3.4.0] - 2026-04-21

### Added
- Bundled offline threat intelligence database (`data/threat_intel_db.json`) with 63 vulnerability patterns for air-gapped deployments
- Automatic offline fallback in threat intel fetchers — network failures gracefully fall back to bundled database
- `offline_mode` and `bundled_db_path` configuration in `[threat_intel]` section
- `--update-signatures` CLI command to refresh threat intel and protocol databases on demand
- Graceful AI Copilot offline failure — scan continues without LLM enrichment when API is unreachable
- 11 new protocol fork signatures: SushiSwap, PancakeSwap, QuickSwap, Cream Finance, Venus, Benqi, Radiant Capital, Spark Protocol, GMX V1, GMX V2, Vela Exchange
- Fork-specific logic checks: AMM rounding errors, Compound oracle staleness, Aave flash loan callback validation, GMX price manipulation, fee-on-transfer handling
- Community protocol signature contribution system (`data/community_signatures/`, `data/protocol_template.json`)
- `docs/CONTRIBUTING_SIGNATURES.md` documentation for signature contributors
- `signature_updater.py` module for programmatic database updates

### Changed
- `--target` is no longer required when using `--update-signatures`
- Protocol database (`protocol_db.py`) now loads from JSON file as source of truth with hardcoded fallback
- `fingerprint_scanner.py` auto-loads community signatures and runs fork-specific checks after protocol matches
- `knowledge_fetcher.py` catches network errors and falls back to bundled threat intel
- `rag_engine.py` skips remaining enrichments after first offline detection to avoid repeated timeouts

## [3.3.0] - 2026-04-21

### Added
- Docker environment isolation with pinned tool versions (Slither 0.11.5, Aderyn 0.6.2, Medusa 0.1.8, Mythril 0.24.8, Foundry 1.0.0)
- Tool version manifest (`tool-versions.json`) for reproducible builds
- Container health check verifying all analyzer tools on startup
- `--preflight` CLI flag to validate tool versions before scanning
- Confidence scoring (1-10) for all 29 heuristic rules
- Inline suppression comments (`// counterscarp-suppress: RULE_ID [reason]`)
- `--min-confidence` CLI filter to set minimum confidence threshold
- `--min-severity` CLI filter to set minimum severity threshold
- `.dockerignore` for optimized Docker builds

### Changed
- Dockerfile now pins exact versions for all security analysis tools
- docker-compose.yml includes container health checks
- Report output shows confidence scores in executive summary, top-10 table, and finding details
- Config file (`counterscarp.toml`) supports `min_confidence` and `min_severity` under `[heuristics]`

## [3.2.0] - 2026-04-20

### Added
- Executive Summary section in all reports with severity breakdown and Top 10 priority issues
- Duplicate finding consolidation — groups similar findings across network-variant contracts with "Also found in" references
- Automatic exploit PoC generation for CRITICAL/HIGH findings (Pro tier, uses existing ExploitGenerator + 8 Foundry templates)
- New Section 11 in ACTION_PLAN: "Exploit Proof-of-Concept Tests" with forge test instructions

### Changed
- Finding dataclass extended with similar_locations and duplicate_count fields
- Report generator now deduplicates before grouping into sections

## [3.1.3] - 2026-04-20

### Fixed
- Report header now correctly reflects critical findings from all engines (heuristic, Slither, fuzz)
- Slither subprocess isolation with PYTHONWARNINGS=ignore prevents dependency warnings from corrupting JSON output
- Automatic per-file fallback when directory target produces no Slither JSON (handles non-Foundry projects)
- Engine version in reports now dynamically resolved from package metadata instead of hardcoded "2.2"
- ValueError crash in report generation for Slither multi-line location formats

## [3.1.2] - 2026-04-20

### Fixed
- Comprehensive robustness hardening across 9 source files (17 issues resolved)
- Subprocess timeout enforcement: Slither (300s), fuzzing (3600s), git log (300s), git show (30s)
- Windows Slither binary resolution with shutil.which() fallback
- JSON parsing with brace-counting fallback for trailing data
- License validation retry with exponential backoff (3 attempts)
- Thread-safe logging setup with threading.Lock
- TOML parse error handling with specific exception types
- Report generator NaN/infinity guard on risk scores
- Heuristic scanner encoding errors="replace" for non-UTF8 files
- Safe exception formatting with repr() for detail values

### Added
- Built-in dual-output file logging (FileHandler + StreamHandler) for guaranteed result persistence
- Git subprocess timeout with TimeoutExpired handling in history_scanner.py

## [3.1.1] - 2026-04-19

### Added
- Three new heuristic rules for enhanced pattern detection
- Foundry integration for Slither analysis on forge-based projects

### Fixed
- Slither solc fallback behavior when forge is unavailable
- Shell piping reliability issues with Tee-Object

## [3.1.0] - 2026-04-18

### Added
- 5-tier pricing restructure (Community Free, Developer $49, Pro $149, Team $399, Enterprise Custom)
- Solana Analyzer and branded HTML/SARIF reports available at Developer tier
- Stripe Checkout integration with license provisioning
- Web application with drag-and-drop upload
- SARIF 2.1.0 report format support

### Changed
- Feature gating moved to tier-based model
- AI Audit Copilot, Attack Graph, Exploit PoC Generator, Time-Travel Git Scanner, Protocol Fingerprinting gated at Pro tier

## [3.0.0] - 2026-04-15

### Added
- License-gated Pro features with server-side validation
- Commercial EULA for Pro tier
- PyPI package distribution
- 21 integrated security analyzers
- 31 EVM heuristic rules + 35 Solana vulnerability patterns
- Configurable execution profiles (counterscarp.toml, counterscarp-audit.toml, counterscarp-pr.toml, counterscarp-bounty.toml)
- Professional audit report generation (HTML, Markdown, SARIF, JSON)
- AI-powered RAG enrichment with customer-managed OpenAI API key

### Changed
- Migrated from open-source to commercial model with free Community tier
