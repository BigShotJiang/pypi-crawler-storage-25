# SAARA

SAARA is a Python package for building local LLM workflows around data creation, fine-tuning, evaluation, export, and visualization.

It is aimed at a practical teacher-student workflow:

1. extract text from PDFs or raw text
2. generate synthetic supervision with a stronger local model
3. fine-tune a smaller model
4. evaluate quality, speed, memory, and optional teacher agreement
5. export and quantize for deployment
6. inspect the workflow through CLI or Gradio

## Features

- PDF to text extraction with `PyMuPDF` and `pdfplumber`
- synthetic dataset generation for factual, reasoning, conversational, instruction, code, and creative tasks
- local provider abstraction for `Ollama`, `vLLM`, and `llama.cpp`
- fine-tuning helpers for LoRA and QLoRA workflows
- evaluation helpers for custom datasets, benchmarks, and teacher-student comparison
- export helpers for `safetensors`, `GGUF`, `AWQ`, `GPTQ`, `ONNX`, `TensorRT`, and PyTorch formats
- Gradio dashboard and CLI entrypoints

## Install

From PyPI:

```bash
pip install saara-ai
```

Common installs:

```bash
pip install "saara-ai[training]"
pip install "saara-ai[export]"
pip install "saara-ai[providers,training,evaluation,export]"
```

From source:

```bash
git clone https://github.com/nikhil49023/saara-ai.git
cd saara-ai
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
```

Optional extras:

```bash
pip install -e ".[dev]"
pip install -e ".[edge]"
pip install -e ".[providers,training,evaluation,export]"
```

Base `saara-ai` intentionally keeps the install lighter. Heavy native stacks such as `auto-gptq`, `autoawq`, `llama-cpp-python`, `vllm`, and training toolchains are opt-in extras.

Note: a virtual environment is strongly recommended.

## Quick Start

### 1. Start a local model provider

For Ollama:

```bash
ollama pull mistral
ollama serve
```

### 2. Build a dataset from a PDF

```python
from saara import DatasetBuilder
from saara.dataset.types import DataType
from saara.providers.ollama_provider import OllamaProvider, ProviderConfig

provider = OllamaProvider(
    ProviderConfig(model="mistral", base_url="http://localhost:11434")
)

builder = DatasetBuilder(provider)
samples = builder.from_pdf(
    "document.pdf",
    data_types=[DataType.INSTRUCTION, DataType.FACTUAL],
    pairs_per_type=5,
    min_quality=0.65,
)

builder.save(samples, "dataset.jsonl")
```

### 3. Launch the GUI

```bash
saara gui
```

## Core Workflow

### Dataset creation

```python
from saara import DatasetBuilder
from saara.dataset.types import DataType

builder = DatasetBuilder(provider)
samples = builder.from_text(
    "Transformers use attention mechanisms for sequence modeling.",
    data_types=[DataType.FACTUAL, DataType.INSTRUCTION],
    pairs_per_type=3,
)
```

### Fine-tuning

```python
from saara import FineTuner
from saara.training.config import TrainingConfig

config = TrainingConfig(
    model_name="mistralai/Mistral-7B-v0.1",
    num_train_epochs=3,
    use_lora=True,
)

finetuner = FineTuner(config)
finetuner.train("dataset.jsonl")
finetuner.save("./output/models/my-finetune")
```

### Evaluation

```python
from saara import ModelEvaluator
from saara.providers.ollama_provider import OllamaProvider, ProviderConfig

student = OllamaProvider(ProviderConfig(model="mistral-7b-finetuned"))
teacher = OllamaProvider(ProviderConfig(model="llama-3-70b"))

evaluator = ModelEvaluator(student, teacher)
metrics = evaluator.evaluate(
    "test.jsonl",
    run_benchmarks=True,
    benchmark_names=["mmlu", "gsm8k"],
)

print(metrics.summary())
```

### Export and quantization

```python
from saara import ModelExporter
from saara.export.formats import ExportFormat
from saara.export.quantization import QuantizationConfig

exporter = ModelExporter(
    model="./output/models/my-finetune",
    config=QuantizationConfig(bits=4),
)

results = exporter.export(
    "./output/exports",
    formats=[ExportFormat.GGUF, ExportFormat.AWQ, ExportFormat.ONNX],
    quantize=True,
)
```

## CLI

```bash
saara dataset from-pdf document.pdf -o ./output --data-types instruction factual
saara train finetune dataset.jsonl --model mistralai/Mistral-7B-v0.1 --epochs 3
saara eval model test.jsonl --model mistral --teacher llama-3-70b --benchmarks mmlu gsm8k
saara export model ./models/final --formats gguf awq --quantize --bits 4
saara gui --port 7860
```

## Documentation

- User guide: [USER_GUIDE.md](USER_GUIDE.md)
- Package structure: [PACKAGE_STRUCTURE.md](PACKAGE_STRUCTURE.md)
- Examples: [`examples/`](examples)

## Examples

- `examples/01_pdf_to_dataset.py`
- `examples/02_synthetic_data.py`
- `examples/03_finetune.py`
- `examples/04_evaluate.py`
- `examples/05_export.py`
- `examples/06_complete_pipeline.py`
- `examples/07_gui.py`
- `examples/08_saara_demo_notebook.ipynb`
- `examples/09_edge_ai_solutions_gemma_vllm.ipynb`
- `examples/10_finetune_workflow_notebook.ipynb`
- `examples/11_evaluation_workflow_notebook.ipynb`
- `examples/12_export_workflow_notebook.ipynb`
- `examples/13_gui_workflow_notebook.ipynb`

Compatibility imports for older notebooks are also supported:

```python
from saara.core import DatasetBuilder, ProviderConfig
from saara.enums import DataType, DatasetFormat
from saara.providers import VLLMProvider, DemoProvider
```

## Recommended Starting Point

If you're trying SAARA for the first time, start with:

- `OllamaProvider`
- one small PDF or a short text file
- LoRA or QLoRA fine-tuning
- `GGUF` and `safetensors` export first

## Development

```bash
pytest tests/
black saara/
ruff check saara/
mypy saara/
```

## PyPI

`https://pypi.org/project/saara-ai/`

## License

MIT. See [LICENSE](LICENSE).
