"""Benchmark suites for model evaluation."""

from typing import Optional, Callable
from dataclasses import dataclass

from saara.evaluation.metrics import EvaluationMetrics


@dataclass
class BenchmarkResult:
    """Result from a single benchmark."""

    name: str
    score: float
    samples: int
    correct: int
    metadata: dict = None

    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}


class BenchmarkSuite:
    """Standard benchmark evaluation suite."""

    BENCHMARKS = {
        "mmlu": "Multi-task Language Understanding",
        "gsm8k": "Grade School Math 8K",
        "humaneval": "HumanEval Code Generation",
        "boolq": "Boolean Questions",
        "hellaswag": "HellaSwag Commonsense NLI",
        "truthfulqa": "TruthfulQA",
        "winogrande": "WinoGrande Commonsense Reasoning",
        "arc_easy": "ARC Easy Science Questions",
        "arc_challenge": "ARC Challenge Science Questions",
    }

    def __init__(self, provider=None, model=None, tokenizer=None):
        """
        Initialize benchmark suite.

        Args:
            provider: Model provider for evaluation
            model: PyTorch model (optional, for direct evaluation)
            tokenizer: Tokenizer (optional)
        """
        self.provider = provider
        self.model = model
        self.tokenizer = tokenizer

    def run(
        self,
        benchmarks: list[str],
        num_fewshot: int = 5,
        limit: Optional[int] = None,
    ) -> dict[str, BenchmarkResult]:
        """
        Run benchmarks.

        Args:
            benchmarks: List of benchmark names
            num_fewshot: Number of few-shot examples
            limit: Limit samples per benchmark

        Returns:
            Dictionary of benchmark results
        """
        try:
            from lm_eval import evaluator
            from lm_eval.models.huggingface import HFLM

            results = {}

            for benchmark in benchmarks:
                if benchmark not in self.BENCHMARKS:
                    print(f"Unknown benchmark: {benchmark}")
                    continue

                print(f"Running {benchmark}...")

                # Run benchmark
                eval_results = evaluator.simple_evaluate(
                    model="hf" if self.model else "local",
                    model_args={
                        "pretrained": self.model,
                        "tokenizer": self.tokenizer,
                    }
                    if self.model
                    else {},
                    tasks=[benchmark],
                    num_fewshot=num_fewshot,
                    limit=limit,
                )

                # Extract score
                score = eval_results["results"][benchmark]
                acc = score.get("acc", score.get("acc_norm", 0))

                results[benchmark] = BenchmarkResult(
                    name=benchmark,
                    score=acc,
                    samples=score.get("n", 0),
                    correct=int(acc * score.get("n", 0)),
                    metadata=score,
                )

                print(f"  {benchmark}: {acc:.4f}")

            return results

        except ImportError:
            raise ImportError("lm-eval not installed. Run: pip install lm-eval")

    def run_custom(
        self,
        dataset: list[dict],
        metric_fn: Callable,
        name: str = "custom",
    ) -> BenchmarkResult:
        """
        Run custom benchmark.

        Args:
            dataset: List of samples with 'input' and 'target'
            metric_fn: Function to compute metric
            name: Benchmark name

        Returns:
            Benchmark result
        """
        if self.provider is None:
            raise ValueError("Provider required for custom benchmarks")

        correct = 0
        total = len(dataset)

        for sample in dataset:
            try:
                response = self.provider.generate(sample["input"])
                metric = metric_fn(response.text, sample["target"])
                if metric > 0.5:
                    correct += 1
            except Exception:
                pass

        return BenchmarkResult(
            name=name,
            score=correct / total if total > 0 else 0,
            samples=total,
            correct=correct,
        )

    def get_available_benchmarks(self) -> list[str]:
        """Get list of available benchmarks."""
        return list(self.BENCHMARKS.keys())

    def get_benchmark_description(self, name: str) -> str:
        """Get description of a benchmark."""
        return self.BENCHMARKS.get(name, "Unknown benchmark")
