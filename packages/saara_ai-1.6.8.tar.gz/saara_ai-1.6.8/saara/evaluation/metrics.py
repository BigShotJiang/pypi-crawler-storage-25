"""Evaluation metrics."""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class EvaluationMetrics:
    """Container for evaluation metrics."""

    # Accuracy metrics
    accuracy: Optional[float] = None
    f1_score: Optional[float] = None
    precision: Optional[float] = None
    recall: Optional[float] = None

    # LLM-specific metrics
    perplexity: Optional[float] = None
    bleu_score: Optional[float] = None
    rouge_l: Optional[float] = None

    # Benchmark scores
    mmlu_score: Optional[float] = None
    gsm8k_score: Optional[float] = None
    humaneval_score: Optional[float] = None

    # Performance metrics
    avg_latency_ms: Optional[float] = None
    tokens_per_second: Optional[float] = None
    peak_memory_mb: Optional[float] = None

    # Power metrics
    power_watts: Optional[float] = None
    energy_kwh: Optional[float] = None
    carbon_kg: Optional[float] = None

    # Teacher-student comparison
    teacher_agreement: Optional[float] = None
    hallucination_rate: Optional[float] = None

    # Custom metrics
    custom_metrics: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "accuracy": self.accuracy,
            "f1_score": self.f1_score,
            "perplexity": self.perplexity,
            "mmlu_score": self.mmlu_score,
            "gsm8k_score": self.gsm8k_score,
            "humaneval_score": self.humaneval_score,
            "avg_latency_ms": self.avg_latency_ms,
            "tokens_per_second": self.tokens_per_second,
            "peak_memory_mb": self.peak_memory_mb,
            "power_watts": self.power_watts,
            "energy_kwh": self.energy_kwh,
            "carbon_kg": self.carbon_kg,
            "teacher_agreement": self.teacher_agreement,
            "hallucination_rate": self.hallucination_rate,
            **self.custom_metrics,
        }

    def summary(self) -> str:
        """Get human-readable summary."""
        lines = ["=== Evaluation Metrics ==="]

        if self.accuracy is not None:
            lines.append(f"Accuracy: {self.accuracy:.2%}")
        if self.mmlu_score is not None:
            lines.append(f"MMLU: {self.mmlu_score:.2f}")
        if self.gsm8k_score is not None:
            lines.append(f"GSM8K: {self.gsm8k_score:.2f}")
        if self.humaneval_score is not None:
            lines.append(f"HumanEval: {self.humaneval_score:.2f}")
        if self.tokens_per_second is not None:
            lines.append(f"Speed: {self.tokens_per_second:.1f} tok/s")
        if self.power_watts is not None:
            lines.append(f"Power: {self.power_watts:.1f}W")
        if self.teacher_agreement is not None:
            lines.append(f"Teacher Agreement: {self.teacher_agreement:.2%}")

        return "\n".join(lines)
