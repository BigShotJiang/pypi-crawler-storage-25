"""Model evaluation with teacher-student comparison."""

import time
from typing import Optional
from pathlib import Path

from saara.providers.base import ModelProvider
from saara.evaluation.metrics import EvaluationMetrics
from saara.evaluation.benchmarks import BenchmarkSuite


class ModelEvaluator:
    """Evaluate models with comprehensive metrics."""

    def __init__(
        self,
        student_provider: ModelProvider,
        teacher_provider: Optional[ModelProvider] = None,
    ):
        """
        Initialize evaluator.

        Args:
            student_provider: Provider for student model
            teacher_provider: Provider for teacher model (optional)
        """
        self.student_provider = student_provider
        self.teacher_provider = teacher_provider
        self.benchmark_suite = BenchmarkSuite(provider=student_provider)

    def evaluate(
        self,
        dataset: str | list[dict],
        run_benchmarks: bool = True,
        benchmark_names: list[str] = None,
        measure_performance: bool = True,
        measure_power: bool = False,
    ) -> EvaluationMetrics:
        """
        Comprehensive model evaluation.

        Args:
            dataset: Evaluation dataset
            run_benchmarks: Whether to run standard benchmarks
            benchmark_names: Specific benchmarks to run
            measure_performance: Whether to measure speed/memory
            measure_power: Whether to measure power consumption

        Returns:
            Evaluation metrics
        """
        metrics = EvaluationMetrics()

        # Run standard benchmarks
        if run_benchmarks:
            benchmark_results = self._run_benchmarks(
                benchmark_names or ["mmlu", "gsm8k", "humaneval"]
            )
            metrics = self._update_from_benchmarks(metrics, benchmark_results)

        # Evaluate on custom dataset
        if dataset:
            dataset_metrics = self._evaluate_dataset(dataset)
            metrics = self._merge_metrics(metrics, dataset_metrics)

        # Measure performance
        if measure_performance:
            perf_metrics = self._measure_performance()
            metrics = self._merge_metrics(metrics, perf_metrics)

        # Measure power consumption
        if measure_power:
            power_metrics = self._measure_power()
            metrics = self._merge_metrics(metrics, power_metrics)

        # Teacher-student comparison
        if self.teacher_provider:
            comparison_metrics = self._compare_with_teacher(dataset)
            metrics = self._merge_metrics(metrics, comparison_metrics)

        return metrics

    def _run_benchmarks(self, benchmark_names: list[str]) -> dict:
        """Run standard benchmarks."""
        return self.benchmark_suite.run(benchmark_names)

    def _evaluate_dataset(self, dataset: str | list[dict]) -> EvaluationMetrics:
        """Evaluate on custom dataset."""
        import json

        if isinstance(dataset, str):
            with open(dataset, "r", encoding="utf-8") as f:
                samples = [json.loads(line) for line in f]
        else:
            samples = dataset

        correct = 0
        total = len(samples)

        for sample in samples:
            try:
                prompt = sample.get("instruction", "")
                if sample.get("input"):
                    prompt += f"\n{sample['input']}"

                response = self.student_provider.generate(prompt)

                # Simple exact match (can be improved)
                if response.text.strip() == sample.get("output", "").strip():
                    correct += 1
            except Exception:
                pass

        return EvaluationMetrics(accuracy=correct / total if total > 0 else 0)

    def _measure_performance(self) -> EvaluationMetrics:
        """Measure inference performance."""
        import psutil
        import torch

        # Warm up
        self.student_provider.generate("Test prompt")

        # Measure latency and throughput
        prompts = ["Generate a short story.", "Explain quantum computing."] * 5
        total_tokens = 0
        total_time = 0

        start_memory = get_gpu_memory() if torch.cuda.is_available() else 0

        for prompt in prompts:
            start = time.time()
            response = self.student_provider.generate(prompt)
            elapsed = time.time() - start

            total_tokens += response.completion_tokens
            total_time += elapsed

        end_memory = get_gpu_memory() if torch.cuda.is_available() else 0

        return EvaluationMetrics(
            avg_latency_ms=(total_time / len(prompts)) * 1000,
            tokens_per_second=total_tokens / total_time,
            peak_memory_mb=end_memory,
        )

    def _measure_power(self) -> EvaluationMetrics:
        """Measure power consumption."""
        try:
            import pynvml
            from codecarbon import EmissionsTracker

            pynvml.nvmlInit()
            handle = pynvml.nvmlDeviceGetHandleByIndex(0)

            # Measure power during inference
            power_samples = []

            with EmissionsTracker() as tracker:
                for _ in range(10):
                    self.student_provider.generate("Test prompt")
                    power = pynvml.nvmlDeviceGetPowerUsage(handle) / 1000.0
                    power_samples.append(power)

            emissions = tracker.final_emissions

            pynvml.nvmlShutdown()

            return EvaluationMetrics(
                power_watts=sum(power_samples) / len(power_samples),
                energy_kwh=emissions * 0.1,
                carbon_kg=emissions,
            )

        except ImportError:
            print("Power measurement requires: pip install pynvml codecarbon")
            return EvaluationMetrics()

    def _compare_with_teacher(
        self,
        dataset: str | list[dict],
    ) -> EvaluationMetrics:
        """Compare student with teacher model."""
        import json

        if isinstance(dataset, str):
            with open(dataset, "r", encoding="utf-8") as f:
                samples = [json.loads(line) for line in f]
        else:
            samples = dataset

        agreements = 0
        total = len(samples)
        hallucinations = 0

        for sample in samples:
            try:
                prompt = sample.get("instruction", "")
                if sample.get("input"):
                    prompt += f"\n{sample['input']}"

                # Get both responses
                student_response = self.student_provider.generate(prompt)
                teacher_response = self.teacher_provider.generate(prompt)

                # Check agreement (simple string comparison)
                if student_response.text.strip() == teacher_response.text.strip():
                    agreements += 1

                # Check for hallucination (student says something teacher doesn't)
                student_text = student_response.text.lower()
                teacher_text = teacher_response.text.lower()

                # Simple heuristic: if student mentions something teacher doesn't
                if "according to" in student_text and "according to" not in teacher_text:
                    hallucinations += 1

            except Exception:
                pass

        return EvaluationMetrics(
            teacher_agreement=agreements / total if total > 0 else 0,
            hallucination_rate=hallucinations / total if total > 0 else 0,
        )

    def _update_from_benchmarks(
        self,
        metrics: EvaluationMetrics,
        results: dict,
    ) -> EvaluationMetrics:
        """Update metrics from benchmark results."""
        for name, result in results.items():
            if name == "mmlu":
                metrics.mmlu_score = result.score
            elif name == "gsm8k":
                metrics.gsm8k_score = result.score
            elif name == "humaneval":
                metrics.humaneval_score = result.score

        return metrics

    def _merge_metrics(
        self,
        metrics1: EvaluationMetrics,
        metrics2: EvaluationMetrics,
    ) -> EvaluationMetrics:
        """Merge two metric objects."""
        merged = EvaluationMetrics()

        for field in metrics1.__dataclass_fields__:
            value = getattr(metrics2, field) or getattr(metrics1, field)
            setattr(merged, field, value)

        merged.custom_metrics = {
            **metrics1.custom_metrics,
            **metrics2.custom_metrics,
        }

        return merged


def get_gpu_memory() -> float:
    """Get GPU memory usage in MB."""
    import torch

    if not torch.cuda.is_available():
        return 0

    return torch.cuda.memory_allocated() / 1024 / 1024
