"""Model evaluation and benchmarking."""

from importlib import import_module

__all__ = ["ModelEvaluator", "BenchmarkSuite", "EvaluationMetrics"]

_LAZY_IMPORTS = {
    "ModelEvaluator": ("saara.evaluation.evaluator", "ModelEvaluator"),
    "BenchmarkSuite": ("saara.evaluation.benchmarks", "BenchmarkSuite"),
    "EvaluationMetrics": ("saara.evaluation.metrics", "EvaluationMetrics"),
}


def __getattr__(name: str):
    if name not in _LAZY_IMPORTS:
        raise AttributeError(f"module 'saara.evaluation' has no attribute {name!r}")

    module_name, attr_name = _LAZY_IMPORTS[name]
    module = import_module(module_name)
    value = getattr(module, attr_name)
    globals()[name] = value
    return value
