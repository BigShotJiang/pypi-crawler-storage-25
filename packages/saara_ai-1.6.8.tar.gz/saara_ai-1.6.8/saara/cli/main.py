"""Command-line interface."""

import json

import click
from saara.version import __version__


@click.group()
@click.version_option(version=__version__)
def cli():
    """SAARA - End-to-end ML Pipeline CLI."""
    pass


@cli.group()
def dataset():
    """Dataset creation commands."""
    pass


@dataset.command()
@click.argument("pdf_path", type=click.Path(exists=True))
@click.option("--output-dir", "-o", default="./output", help="Output directory")
@click.option("--data-types", "-t", multiple=True, default=["instruction"], help="Data types")
@click.option("--pairs", "-p", default=5, help="Pairs per type")
@click.option("--quality", "-q", default=0.65, help="Minimum quality")
@click.option("--format", "-f", default="jsonl", help="Output format")
def from_pdf(pdf_path, output_dir, data_types, pairs, quality, format):
    """Create dataset from PDF."""
    from saara import DatasetBuilder
    from saara.dataset.types import DataType, DatasetFormat
    from saara.providers.ollama_provider import OllamaProvider, ProviderConfig

    click.echo(f"📊 Creating dataset from {pdf_path}")

    # Setup provider
    config = ProviderConfig(model="mistral")
    provider = OllamaProvider(config)

    # Create builder
    builder = DatasetBuilder(
        provider,
        output_dir=output_dir,
        output_format=DatasetFormat(format),
    )

    # Generate
    samples = builder.from_pdf(
        pdf_path,
        data_types=[DataType(t) for t in data_types],
        pairs_per_type=pairs,
        min_quality=quality,
    )

    # Save
    output_path = builder.save(samples, "dataset.jsonl")

    click.echo(f"✅ Generated {len(samples)} samples")
    click.echo(f"📁 Saved to: {output_path}")


@dataset.command()
@click.argument("text_file", type=click.Path(exists=True))
@click.option("--output-dir", "-o", default="./output", help="Output directory")
@click.option("--data-types", "-t", multiple=True, default=["instruction"], help="Data types")
@click.option("--pairs", "-p", default=5, help="Pairs per type")
@click.option("--quality", "-q", default=0.65, help="Minimum quality")
def from_text(text_file, output_dir, data_types, pairs, quality):
    """Create dataset from text file."""
    from saara import DatasetBuilder
    from saara.dataset.types import DataType
    from saara.providers.ollama_provider import OllamaProvider, ProviderConfig

    click.echo(f"📊 Creating dataset from {text_file}")

    with open(text_file, "r") as f:
        text = f.read()

    config = ProviderConfig(model="mistral")
    provider = OllamaProvider(config)

    builder = DatasetBuilder(provider, output_dir=output_dir)

    samples = builder.from_text(
        text,
        data_types=[DataType(t) for t in data_types],
        pairs_per_type=pairs,
        min_quality=quality,
    )

    output_path = builder.save(samples, "dataset.jsonl")

    click.echo(f"✅ Generated {len(samples)} samples")
    click.echo(f"📁 Saved to: {output_path}")


@cli.group()
def train():
    """Training commands."""
    pass


@train.command()
@click.argument("dataset_path", type=click.Path(exists=True))
@click.option("--model", "-m", default="mistralai/Mistral-7B-v0.1", help="Model name")
@click.option("--epochs", "-e", default=3, help="Number of epochs")
@click.option("--batch-size", "-b", default=4, help="Batch size")
@click.option("--lr", default=2e-4, help="Learning rate")
@click.option("--output-dir", "-o", default="./output/training", help="Output directory")
@click.option("--lora/--no-lora", default=True, help="Use LoRA")
def finetune(dataset_path, model, epochs, batch_size, lr, output_dir, lora):
    """Fine-tune a model."""
    from saara import FineTuner
    from saara.training.config import TrainingConfig

    click.echo(f"🎯 Fine-tuning {model}")

    config = TrainingConfig(
        model_name=model,
        num_train_epochs=epochs,
        per_device_train_batch_size=batch_size,
        learning_rate=lr,
        use_lora=lora,
        output_dir=output_dir,
    )

    finetuner = FineTuner(config)
    result = finetuner.train(dataset_path)

    click.echo(f"✅ Training completed!")
    click.echo(f"Metrics: {json.dumps(result['metrics'], indent=2)}")


@cli.group()
def eval():
    """Evaluation commands."""
    pass


@eval.command()
@click.argument("dataset_path", type=click.Path(exists=True))
@click.option("--model", "-m", default="mistral", help="Model name")
@click.option("--teacher", "-t", default=None, help="Teacher model")
@click.option("--benchmarks", "-b", multiple=True, default=["mmlu", "gsm8k"], help="Benchmarks")
@click.option("--perf/--no-perf", default=True, help="Measure performance")
def model(dataset_path, model, teacher, benchmarks, perf):
    """Evaluate a model."""
    from saara import ModelEvaluator
    from saara.providers.ollama_provider import OllamaProvider, ProviderConfig

    click.echo(f"📈 Evaluating {model}")

    student_config = ProviderConfig(model=model)
    student_provider = OllamaProvider(student_config)

    teacher_provider = None
    if teacher:
        teacher_config = ProviderConfig(model=teacher)
        teacher_provider = OllamaProvider(teacher_config)

    evaluator = ModelEvaluator(student_provider, teacher_provider)

    metrics = evaluator.evaluate(
        dataset=dataset_path,
        run_benchmarks=True,
        benchmark_names=list(benchmarks),
        measure_performance=perf,
    )

    click.echo("\n" + metrics.summary())


@cli.group()
def export():
    """Export commands."""
    pass


@export.command()
@click.argument("model_path", type=click.Path(exists=True))
@click.option(
    "--formats", "-f", multiple=True, default=["safetensors", "gguf"], help="Export formats"
)
@click.option("--quantize/--no-quantize", default=True, help="Quantize model")
@click.option("--bits", "-b", default=4, help="Quantization bits")
@click.option("--output-dir", "-o", default="./output/export", help="Output directory")
def model(model_path, formats, quantize, bits, output_dir):
    """Export model to various formats."""
    from saara import ModelExporter
    from saara.export.formats import ExportFormat
    from saara.export.quantization import QuantizationConfig

    click.echo(f"📦 Exporting {model_path}")

    config = QuantizationConfig(bits=bits)
    exporter = ModelExporter(model=model_path, config=config)

    export_formats = [ExportFormat(f) for f in formats]

    results = exporter.export(
        output_dir=output_dir,
        formats=export_formats,
        quantize=quantize,
    )

    click.echo("\nExport Results:")
    for fmt, result in results.items():
        if "error" in result:
            click.echo(f"  ❌ {fmt}: {result['error']}")
        else:
            click.echo(f"  ✅ {fmt}: {result['size_mb']:.1f} MB")


@cli.command()
@click.option("--port", "-p", default=7860, help="Port number")
@click.option("--host", "-h", default="0.0.0.0", help="Host")
@click.option("--share", "-s", is_flag=True, help="Create public link")
def gui(port, host, share):
    """Launch Gradio GUI."""
    click.echo("🚀 Launching SAARA GUI...")

    from saara import SaaraDashboard

    dashboard = SaaraDashboard()
    dashboard.launch(server_port=port, server_name=host, share=share)


if __name__ == "__main__":
    cli()
