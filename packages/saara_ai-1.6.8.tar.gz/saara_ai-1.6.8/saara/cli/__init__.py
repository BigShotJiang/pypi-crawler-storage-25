"""Command-line interface."""

from saara.cli.main import cli

__all__ = ["cli"]
