"""Logging utilities."""

import logging
import sys
from typing import Optional


def setup_logging(
    level: str = "INFO",
    format: Optional[str] = None,
    filename: Optional[str] = None,
) -> None:
    """
    Setup logging configuration.

    Args:
        level: Logging level
        format: Log format string
        filename: Optional file to log to
    """
    if format is None:
        format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

    handlers = [logging.StreamHandler(sys.stdout)]

    if filename:
        handlers.append(logging.FileHandler(filename))

    logging.basicConfig(
        level=getattr(logging, level.upper()),
        format=format,
        handlers=handlers,
    )


def get_logger(name: str) -> logging.Logger:
    """
    Get logger instance.

    Args:
        name: Logger name

    Returns:
        Logger instance
    """
    return logging.getLogger(name)
