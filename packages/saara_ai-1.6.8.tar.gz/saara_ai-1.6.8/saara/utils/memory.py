"""Memory utilities."""

import torch


def get_gpu_memory(device: int = 0) -> float:
    """
    Get GPU memory usage in MB.

    Args:
        device: GPU device index

    Returns:
        Memory usage in MB
    """
    if not torch.cuda.is_available():
        return 0.0

    return torch.cuda.memory_allocated(device) / 1024 / 1024


def get_cpu_memory() -> float:
    """
    Get CPU memory usage in MB.

    Returns:
        Memory usage in MB
    """
    import psutil

    process = psutil.Process()
    return process.memory_info().rss / 1024 / 1024


def get_gpu_info() -> dict:
    """
    Get GPU information.

    Returns:
        Dictionary with GPU info
    """
    if not torch.cuda.is_available():
        return {"available": False}

    return {
        "available": True,
        "device_count": torch.cuda.device_count(),
        "device_name": torch.cuda.get_device_name(0),
        "memory_allocated": get_gpu_memory(),
        "memory_cached": torch.cuda.memory_reserved() / 1024 / 1024,
    }
