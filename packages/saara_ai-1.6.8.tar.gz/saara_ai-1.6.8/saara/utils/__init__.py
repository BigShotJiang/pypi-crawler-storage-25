"""Utility functions and helpers."""

from importlib import import_module

__all__ = [
    "load_jsonl",
    "save_jsonl",
    "load_yaml",
    "save_yaml",
    "setup_logging",
    "get_logger",
    "get_gpu_memory",
    "get_cpu_memory",
]

_LAZY_IMPORTS = {
    "load_jsonl": ("saara.utils.io", "load_jsonl"),
    "save_jsonl": ("saara.utils.io", "save_jsonl"),
    "load_yaml": ("saara.utils.io", "load_yaml"),
    "save_yaml": ("saara.utils.io", "save_yaml"),
    "setup_logging": ("saara.utils.logging", "setup_logging"),
    "get_logger": ("saara.utils.logging", "get_logger"),
    "get_gpu_memory": ("saara.utils.memory", "get_gpu_memory"),
    "get_cpu_memory": ("saara.utils.memory", "get_cpu_memory"),
}


def __getattr__(name: str):
    if name not in _LAZY_IMPORTS:
        raise AttributeError(f"module 'saara.utils' has no attribute {name!r}")

    module_name, attr_name = _LAZY_IMPORTS[name]
    module = import_module(module_name)
    value = getattr(module, attr_name)
    globals()[name] = value
    return value
