"""Quantization configuration."""

from dataclasses import dataclass
from typing import Optional


@dataclass
class QuantizationConfig:
    """Configuration for model quantization."""

    # Bit width
    bits: int = 4
    group_size: int = 128
    desc_act: bool = False

    # Quantization method
    method: str = "awq"  # awq, gptq, bitsandbytes

    # AWQ-specific
    zero_point: bool = True
    qkv_bias: bool = False

    # GPTQ-specific
    damp_percent: float = 0.01
    true_sequential: bool = True

    # Quality settings
    sym: bool = False
    lm_head: bool = False

    # Hardware targeting
    target_device: str = "cuda"  # cuda, cpu, metal, jetson
    compute_dtype: str = "float16"

    # Validation
    validate: bool = True
    calibration_samples: int = 128

    def __post_init__(self):
        if self.bits not in [2, 3, 4, 8]:
            raise ValueError("bits must be 2, 3, 4, or 8")

        if self.method not in ["awq", "gptq", "bitsandbytes"]:
            raise ValueError("method must be 'awq', 'gptq', or 'bitsandbytes'")
