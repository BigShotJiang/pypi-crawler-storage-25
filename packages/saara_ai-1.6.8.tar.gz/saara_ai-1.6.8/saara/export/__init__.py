"""Model export and quantization."""

from importlib import import_module

__all__ = ["ModelExporter", "QuantizationConfig", "ExportFormat"]

_LAZY_IMPORTS = {
    "ModelExporter": ("saara.export.exporter", "ModelExporter"),
    "QuantizationConfig": ("saara.export.quantization", "QuantizationConfig"),
    "ExportFormat": ("saara.export.formats", "ExportFormat"),
}


def __getattr__(name: str):
    if name not in _LAZY_IMPORTS:
        raise AttributeError(f"module 'saara.export' has no attribute {name!r}")

    module_name, attr_name = _LAZY_IMPORTS[name]
    module = import_module(module_name)
    value = getattr(module, attr_name)
    globals()[name] = value
    return value
