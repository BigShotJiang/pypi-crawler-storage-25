"""Model export and quantization."""

import os
import json
from pathlib import Path
from typing import Optional, Union

from saara.export.formats import ExportFormat
from saara.export.quantization import QuantizationConfig


class ModelExporter:
    """Export models to various formats with quantization."""

    def __init__(self, model=None, tokenizer=None, config: Optional[QuantizationConfig] = None):
        """
        Initialize model exporter.

        Args:
            model: PyTorch model or path to model
            tokenizer: Tokenizer or path to tokenizer
            config: Quantization configuration
        """
        self.model = model
        self.tokenizer = tokenizer
        self.config = config or QuantizationConfig()

    def export(
        self,
        output_dir: str,
        formats: list[ExportFormat],
        quantize: bool = True,
        run_benchmark: bool = True,
    ) -> dict:
        """
        Export model to multiple formats.

        Args:
            output_dir: Output directory
            formats: List of export formats
            quantize: Whether to quantize
            run_benchmark: Run benchmarks before export

        Returns:
            Export results with file sizes and metrics
        """
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        results = {}

        for fmt in formats:
            print(f"Exporting to {fmt.value}...")

            try:
                if fmt == ExportFormat.SAFETENSORS:
                    result = self._export_safetensors(output_path / "safetensors")
                elif fmt == ExportFormat.GGUF:
                    result = self._export_gguf(output_path / "gguf", quantize)
                elif fmt == ExportFormat.AWQ:
                    result = self._export_awq(output_path / "awq", quantize)
                elif fmt == ExportFormat.GPTQ:
                    result = self._export_gptq(output_path / "gptq", quantize)
                elif fmt == ExportFormat.ONNX:
                    result = self._export_onnx(output_path / "onnx", quantize)
                elif fmt == ExportFormat.TENSORRT:
                    result = self._export_tensorrt(output_path / "tensorrt", quantize)
                elif fmt == ExportFormat.PYTORCH:
                    result = self._export_pytorch(output_path / "pytorch")
                else:
                    raise ValueError(f"Unknown format: {fmt}")

                results[fmt.value] = result

            except Exception as e:
                results[fmt.value] = {"error": str(e)}
                print(f"  Failed: {e}")

        # Save export report
        report_path = output_path / "export_report.json"
        with open(report_path, "w") as f:
            json.dump(results, f, indent=2)

        return results

    def _export_safetensors(self, output_path: Path) -> dict:
        """Export to safetensors format."""
        from safetensors.torch import save_file

        output_path.mkdir(parents=True, exist_ok=True)

        if hasattr(self.model, "state_dict"):
            state_dict = self.model.state_dict()
            save_file(state_dict, output_path / "model.safetensors")
        else:
            # Assume path
            self.model = str(self.model)
            # Copy files
            import shutil

            for file in Path(self.model).glob("*.safetensors"):
                shutil.copy(file, output_path / file.name)

        # Save tokenizer
        if self.tokenizer:
            self.tokenizer.save_pretrained(output_path)

        size = sum(f.stat().st_size for f in output_path.glob("**/*") if f.is_file())

        return {
            "format": "safetensors",
            "path": str(output_path),
            "size_bytes": size,
            "size_mb": size / 1024 / 1024,
        }

    def _export_gguf(self, output_path: Path, quantize: bool) -> dict:
        """Export to GGUF format."""
        try:
            from llama_cpp import llama_model_loader, llama_model_dump

            output_path.mkdir(parents=True, exist_ok=True)

            if quantize:
                # Quantize to GGUF
                from llama_cpp import llama_model_quantize_params

                params = llama_model_quantize_params()
                params.nthread = 4

                if self.config.bits == 4:
                    params.quantization_type = 14  # Q4_K_M
                elif self.config.bits == 8:
                    params.quantization_type = 8  # Q8_0
                else:
                    params.quantization_type = 15  # Q5_K_M

                output_file = output_path / f"model_q{self.config.bits}.gguf"
                llama_model_dump(str(self.model), str(output_file), params)
            else:
                output_file = output_path / "model.gguf"
                llama_model_dump(str(self.model), str(output_file))

            size = output_file.stat().st_size

            return {
                "format": "gguf",
                "path": str(output_file),
                "size_bytes": size,
                "size_mb": size / 1024 / 1024,
                "quantized": quantize,
                "bits": self.config.bits if quantize else None,
            }

        except ImportError:
            raise ImportError("llama-cpp-python not installed. Run: pip install llama-cpp-python")

    def _export_awq(self, output_path: Path, quantize: bool) -> dict:
        """Export to AWQ format."""
        try:
            from awq import AutoAWQForCausalLM

            output_path.mkdir(parents=True, exist_ok=True)

            if quantize:
                # Load and quantize
                quantized_model = AutoAWQForCausalLM.from_pretrained(
                    str(self.model),
                    trust_remote_code=True,
                )

                quantized_model.quantize(
                    tokenizer=self.tokenizer,
                    w_bit=self.config.bits,
                    q_group_size=self.config.group_size,
                    zero_point=self.config.zero_point,
                )

                quantized_model.save_quantized(
                    str(output_path),
                    safetensors=True,
                )
            else:
                # Just save
                self.model.save_pretrained(output_path)
                self.tokenizer.save_pretrained(output_path)

            size = sum(f.stat().st_size for f in output_path.glob("**/*") if f.is_file())

            return {
                "format": "awq",
                "path": str(output_path),
                "size_bytes": size,
                "size_mb": size / 1024 / 1024,
                "quantized": quantize,
                "bits": self.config.bits if quantize else None,
            }

        except ImportError:
            raise ImportError("autoawq not installed. Run: pip install autoawq")

    def _export_gptq(self, output_path: Path, quantize: bool) -> dict:
        """Export to GPTQ format."""
        try:
            from auto_gptq import AutoGPTQForCausalLM, BaseQuantizeConfig

            output_path.mkdir(parents=True, exist_ok=True)

            if quantize:
                quantize_config = BaseQuantizeConfig(
                    bits=self.config.bits,
                    group_size=self.config.group_size,
                    desc_act=self.config.desc_act,
                )

                model = AutoGPTQForCausalLM.from_pretrained(
                    str(self.model),
                    quantize_config,
                    trust_remote_code=True,
                )

                # Calibrate (would need calibration dataset in practice)
                # model.quantize(calibration_dataset)

                model.save_quantized(str(output_path))
            else:
                self.model.save_pretrained(output_path)

            if self.tokenizer:
                self.tokenizer.save_pretrained(output_path)

            size = sum(f.stat().st_size for f in output_path.glob("**/*") if f.is_file())

            return {
                "format": "gptq",
                "path": str(output_path),
                "size_bytes": size,
                "size_mb": size / 1024 / 1024,
                "quantized": quantize,
                "bits": self.config.bits if quantize else None,
            }

        except ImportError:
            raise ImportError("auto-gptq not installed. Run: pip install auto-gptq")

    def _export_onnx(self, output_path: Path, quantize: bool) -> dict:
        """Export to ONNX format."""
        import onnx
        import torch
        import torch.onnx

        output_path.mkdir(parents=True, exist_ok=True)

        self.model.eval()

        # Create dummy input
        dummy_input = torch.randint(
            0,
            1000,
            (1, self.config.group_size),
            dtype=torch.long,
        )

        # Export
        onnx_path = output_path / "model.onnx"

        torch.onnx.export(
            self.model,
            dummy_input,
            str(onnx_path),
            export_params=True,
            opset_version=14,
            do_constant_folding=True,
            input_names=["input_ids"],
            output_names=["logits"],
            dynamic_axes={
                "input_ids": {0: "batch_size", 1: "sequence_length"},
                "logits": {0: "batch_size"},
            },
        )

        # Optionally quantize ONNX
        if quantize:
            from onnxruntime.quantization import quantize_dynamic, QuantType

            quantized_path = output_path / "model_quantized.onnx"
            quantize_dynamic(
                onnx_path,
                quantized_path,
                quant_type=QuantType.QUInt8,
            )
            onnx_path = quantized_path

        size = onnx_path.stat().st_size

        return {
            "format": "onnx",
            "path": str(onnx_path),
            "size_bytes": size,
            "size_mb": size / 1024 / 1024,
            "quantized": quantize,
        }

    def _export_tensorrt(self, output_path: Path, quantize: bool) -> dict:
        """Export to TensorRT format (for NVIDIA Jetson)."""
        try:
            import tensorrt as trt
            import onnx

            output_path.mkdir(parents=True, exist_ok=True)

            # First export to ONNX
            onnx_result = self._export_onnx(output_path / "onnx_temp", quantize=False)
            onnx_path = onnx_result["path"]

            # Build TensorRT engine
            logger = trt.Logger(trt.Logger.WARNING)
            builder = trt.Builder(logger)
            network = builder.create_network(
                1 << int(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH)
            )
            parser = trt.OnnxParser(network, logger)

            with open(onnx_path, "rb") as f:
                parser.parse(f.read())

            config = builder.create_builder_config()
            config.max_workspace_size = 1 << 30  # 1GB

            if quantize:
                config.set_flag(trt.BuilderFlag.FP16)

            engine = builder.build_serialized_network(network, config)

            engine_path = output_path / "model.engine"
            with open(engine_path, "wb") as f:
                f.write(engine)

            # Cleanup temp
            import shutil

            shutil.rmtree(output_path / "onnx_temp")

            size = engine_path.stat().st_size

            return {
                "format": "tensorrt",
                "path": str(engine_path),
                "size_bytes": size,
                "size_mb": size / 1024 / 1024,
                "quantized": quantize,
                "target": "jetson",
            }

        except ImportError:
            raise ImportError("TensorRT not installed. Run: pip install tensorrt")

    def _export_pytorch(self, output_path: Path) -> dict:
        """Export to PyTorch format."""
        import torch

        output_path.mkdir(parents=True, exist_ok=True)

        if hasattr(self.model, "save_pretrained"):
            self.model.save_pretrained(output_path)
        else:
            torch.save(self.model.state_dict(), output_path / "pytorch_model.bin")

        if self.tokenizer:
            self.tokenizer.save_pretrained(output_path)

        size = sum(f.stat().st_size for f in output_path.glob("**/*") if f.is_file())

        return {
            "format": "pytorch",
            "path": str(output_path),
            "size_bytes": size,
            "size_mb": size / 1024 / 1024,
        }
