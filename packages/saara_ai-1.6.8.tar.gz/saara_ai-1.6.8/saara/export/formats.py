"""Export formats."""

from enum import Enum


class ExportFormat(Enum):
    """Model export formats."""

    SAFETENSORS = "safetensors"
    GGUF = "gguf"
    AWQ = "awq"
    GPTQ = "gptq"
    ONNX = "onnx"
    TENSORRT = "tensorrt"
    PYTORCH = "pytorch"
