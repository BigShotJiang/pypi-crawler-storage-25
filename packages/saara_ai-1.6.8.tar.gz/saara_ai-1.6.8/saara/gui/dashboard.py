"""Gradio GUI dashboard."""

from __future__ import annotations

from saara.gui.components import DatasetBuilderUI, EvaluationDashboard, TrainingMonitor


def _gr():
    try:
        import gradio as gr
    except ImportError as exc:
        raise ImportError(
            "Gradio is required for the SAARA GUI. Install it with `pip install gradio`."
        ) from exc
    return gr


class SaaraDashboard:
    """Main Gradio dashboard for SAARA."""

    LUXURY_CSS = """
    :root {
        --saara-bg: #0b0b0f;
        --saara-panel: linear-gradient(180deg, rgba(28, 28, 34, 0.95), rgba(15, 15, 20, 0.96));
        --saara-panel-solid: #14141a;
        --saara-gold: #d4af37;
        --saara-gold-soft: #f1d27a;
        --saara-text: #f5f1e6;
        --saara-muted: #b7ad8f;
        --saara-border: rgba(212, 175, 55, 0.22);
        --saara-shadow: 0 18px 50px rgba(0, 0, 0, 0.38);
    }

    .gradio-container {
        background:
            radial-gradient(circle at top left, rgba(212, 175, 55, 0.10), transparent 28%),
            radial-gradient(circle at top right, rgba(212, 175, 55, 0.07), transparent 24%),
            linear-gradient(180deg, #09090c 0%, #111117 100%);
        color: var(--saara-text);
    }

    .saara-shell {
        max-width: 1280px;
        margin: 0 auto;
    }

    .saara-hero {
        padding: 28px;
        border: 1px solid var(--saara-border);
        background: linear-gradient(135deg, rgba(24, 24, 29, 0.98), rgba(9, 9, 12, 0.98));
        border-radius: 24px;
        box-shadow: var(--saara-shadow);
        margin-bottom: 18px;
        overflow: hidden;
        position: relative;
    }

    .saara-hero::after {
        content: "";
        position: absolute;
        inset: 0;
        background: linear-gradient(115deg, transparent, rgba(212, 175, 55, 0.08), transparent 70%);
        pointer-events: none;
    }

    .saara-eyebrow {
        letter-spacing: 0.22em;
        text-transform: uppercase;
        color: var(--saara-gold-soft);
        font-size: 12px;
        margin-bottom: 10px;
    }

    .saara-title {
        font-size: 42px;
        line-height: 1.05;
        font-weight: 700;
        margin: 0;
        color: var(--saara-text);
    }

    .saara-title strong {
        color: var(--saara-gold);
        font-weight: 700;
    }

    .saara-subtitle {
        margin-top: 14px;
        max-width: 760px;
        color: var(--saara-muted);
        font-size: 16px;
        line-height: 1.7;
    }

    .saara-kpi-grid {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 14px;
        margin-top: 22px;
    }

    .saara-kpi {
        background: rgba(18, 18, 24, 0.9);
        border: 1px solid var(--saara-border);
        border-radius: 18px;
        padding: 16px 18px;
    }

    .saara-kpi-label {
        color: var(--saara-muted);
        font-size: 12px;
        text-transform: uppercase;
        letter-spacing: 0.12em;
    }

    .saara-kpi-value {
        color: var(--saara-gold-soft);
        font-size: 26px;
        font-weight: 700;
        margin-top: 8px;
    }

    .saara-panel,
    .saara-stat-panel {
        background: var(--saara-panel);
        border: 1px solid var(--saara-border);
        border-radius: 22px;
        box-shadow: var(--saara-shadow);
    }

    .saara-panel {
        padding: 18px;
    }

    .saara-stat-panel {
        padding: 16px;
        min-height: 116px;
    }

    .saara-section-title {
        margin: 0 0 6px 0;
        color: var(--saara-gold-soft);
        font-size: 18px;
        font-weight: 700;
    }

    .saara-section-copy {
        margin: 0 0 18px 0;
        color: var(--saara-muted);
        font-size: 14px;
    }

    .saara-mini-label {
        color: var(--saara-muted);
        text-transform: uppercase;
        font-size: 11px;
        letter-spacing: 0.14em;
    }

    .saara-mini-value {
        color: var(--saara-text);
        font-size: 24px;
        font-weight: 700;
        margin-top: 8px;
    }

    .saara-mini-copy {
        margin-top: 8px;
        color: var(--saara-muted);
        font-size: 13px;
    }

    .saara-status {
        border-left: 3px solid var(--saara-gold);
        padding: 10px 14px;
        background: rgba(212, 175, 55, 0.07);
        border-radius: 12px;
        color: var(--saara-text);
        margin-bottom: 14px;
    }

    .saara-tab-note {
        color: var(--saara-muted);
        margin-bottom: 14px;
    }

    .gr-button-primary {
        background: linear-gradient(135deg, #c8a43d, #f0d381) !important;
        color: #111117 !important;
        border: none !important;
        font-weight: 700 !important;
        box-shadow: 0 12px 26px rgba(212, 175, 55, 0.26) !important;
    }

    .gr-button-secondary {
        background: #1b1b22 !important;
        border: 1px solid var(--saara-border) !important;
        color: var(--saara-text) !important;
    }

    .gr-box,
    .gr-form,
    .gr-panel,
    .gr-group,
    .gr-accordion {
        border-color: var(--saara-border) !important;
    }

    .gr-input,
    .gr-textbox,
    .gr-dataframe,
    .gr-json,
    .gr-code,
    .gr-file,
    .gr-radio,
    .gr-checkboxgroup,
    .gr-dropdown,
    .gr-number {
        background: rgba(17, 17, 22, 0.92) !important;
    }

    @media (max-width: 900px) {
        .saara-kpi-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }
        .saara-title {
            font-size: 32px;
        }
    }
    """

    def __init__(self):
        self.dataset_ui = DatasetBuilderUI()
        self.training_monitor = TrainingMonitor()
        self.evaluation_dashboard = EvaluationDashboard()

    def build(self):
        """Build the Gradio app without launching it."""
        gr = _gr()
        theme = gr.themes.Base(
            primary_hue="amber",
            secondary_hue="yellow",
            neutral_hue="zinc",
            radius_size=gr.themes.sizes.radius_lg,
            font=[gr.themes.GoogleFont("Cormorant Garamond"), "serif"],
            font_mono=[gr.themes.GoogleFont("IBM Plex Mono"), "monospace"],
        )
        with gr.Blocks(title="SAARA - ML Pipeline", theme=theme, css=self.LUXURY_CSS) as demo:
            with gr.Column(elem_classes=["saara-shell"]):
                gr.HTML(
                    """
                    <section class='saara-hero'>
                      <div class='saara-eyebrow'>SAARA Studio</div>
                      <h1 class='saara-title'>Luxury <strong>LLM Ops</strong> for data, tuning, evaluation, and export.</h1>
                      <div class='saara-subtitle'>
                        Build PDF-driven datasets, run vLLM-first generation workflows, compare student models against teachers,
                        and ship quantized artifacts through an interface designed for research teams and product engineers.
                      </div>
                      <div class='saara-kpi-grid'>
                        <div class='saara-kpi'><div class='saara-kpi-label'>Inference</div><div class='saara-kpi-value'>vLLM</div></div>
                        <div class='saara-kpi'><div class='saara-kpi-label'>Training</div><div class='saara-kpi-value'>LoRA / QLoRA</div></div>
                        <div class='saara-kpi'><div class='saara-kpi-label'>Evaluation</div><div class='saara-kpi-value'>Teacher-Led</div></div>
                        <div class='saara-kpi'><div class='saara-kpi-label'>Deployment</div><div class='saara-kpi-value'>GGUF / AWQ / ONNX</div></div>
                      </div>
                    </section>
                    """
                )

                with gr.Row(equal_height=True):
                    gr.HTML(
                        """
                        <div class='saara-stat-panel'>
                          <div class='saara-mini-label'>Workflow</div>
                          <div class='saara-mini-value'>PDF to Model</div>
                          <div class='saara-mini-copy'>Move from raw domain documents to deployable artifacts in one visual surface.</div>
                        </div>
                        """
                    )
                    gr.HTML(
                        """
                        <div class='saara-stat-panel'>
                          <div class='saara-mini-label'>Providers</div>
                          <div class='saara-mini-value'>vLLM First</div>
                          <div class='saara-mini-copy'>Use Ollama and llama.cpp when needed, but optimize for high-throughput local GPU inference.</div>
                        </div>
                        """
                    )
                    gr.HTML(
                        """
                        <div class='saara-stat-panel'>
                          <div class='saara-mini-label'>UX</div>
                          <div class='saara-mini-value'>Visual Execution</div>
                          <div class='saara-mini-copy'>Each tab is structured as a production console instead of a toy demo page.</div>
                        </div>
                        """
                    )

                gr.HTML(
                    "<div class='saara-status'>Recommended starting setup: use <strong>vLLM</strong> for generation and evaluation, then export to <strong>GGUF</strong> or <strong>AWQ</strong> for deployment.</div>"
                )

                with gr.Tabs():
                    with gr.Tab("Dataset Atelier"):
                        self.dataset_ui.render()
                    with gr.Tab("Fine-Tune Suite"):
                        self.training_monitor.render()
                    with gr.Tab("Evaluation Salon"):
                        self.evaluation_dashboard.render()
                    with gr.Tab("Export Vault"):
                        self._render_export_tab()
                    with gr.Tab("Code Concierge"):
                        self._render_code_view_tab()

        return demo

    def launch(
        self, share: bool = False, server_name: str = "0.0.0.0", server_port: int = 7860
    ) -> None:
        """Launch the dashboard."""
        demo = self.build()
        demo.launch(share=share, server_name=server_name, server_port=server_port)

    def _render_export_tab(self) -> None:
        gr = _gr()
        gr.HTML(
            "<div class='saara-panel'><div class='saara-section-title'>Export Vault</div><div class='saara-section-copy'>Package fine-tuned checkpoints into deployment-ready formats with quantization controls suited for edge and GPU runtimes.</div></div>"
        )

        with gr.Row():
            with gr.Column():
                model_path = gr.Textbox(label="Model Path", placeholder="/path/to/model")
                formats = gr.CheckboxGroup(
                    label="Export Formats",
                    choices=[
                        ("Safetensors", "safetensors"),
                        ("GGUF", "gguf"),
                        ("AWQ", "awq"),
                        ("GPTQ", "gptq"),
                        ("ONNX", "onnx"),
                        ("TensorRT", "tensorrt"),
                    ],
                    value=["safetensors", "gguf"],
                )
                quantize = gr.Checkbox(label="Quantize", value=True)
                bits = gr.Slider(label="Quantization Bits", minimum=2, maximum=8, step=1, value=4)
                export_btn = gr.Button("Export", variant="primary")

            with gr.Column():
                export_output = gr.JSON(label="Export Results")
                export_status = gr.Textbox(label="Status")

        def do_export(model_path, formats, quantize, bits):
            try:
                from saara import ExportFormat, ModelExporter, QuantizationConfig

                config = QuantizationConfig(bits=int(bits))
                exporter = ModelExporter(model=model_path, config=config)
                export_formats = [ExportFormat(item) for item in formats]
                results = exporter.export(
                    output_dir="./output/export", formats=export_formats, quantize=quantize
                )
                return results, "Export completed successfully"
            except Exception as exc:
                return None, f"Error: {exc}"

        export_btn.click(
            do_export,
            inputs=[model_path, formats, quantize, bits],
            outputs=[export_output, export_status],
        )

    def _render_code_view_tab(self) -> None:
        gr = _gr()
        gr.HTML(
            "<div class='saara-panel'><div class='saara-section-title'>Code Concierge</div><div class='saara-section-copy'>Drop in SAARA code and get a structured reading of the workflow components it uses. This is useful for translating scripts into UI-friendly execution paths.</div></div>"
        )

        with gr.Row():
            with gr.Column(scale=2):
                code_input = gr.Code(
                    label="Python Code",
                    language="python",
                    value="""from saara import DatasetBuilder, FineTuner, ModelEvaluator

builder = DatasetBuilder(provider)
samples = builder.from_pdf("document.pdf", data_types=[DataType.INSTRUCTION])
builder.save(samples, "dataset.jsonl")

finetuner = FineTuner(config)
finetuner.train("dataset.jsonl")

evaluator = ModelEvaluator(student_provider, teacher_provider)
metrics = evaluator.evaluate("test.jsonl")
""",
                )
                generate_btn = gr.Button("Generate GUI", variant="primary")

            with gr.Column(scale=1):
                gr.Markdown("### Generated Components")
                generated_components = gr.JSON(label="Components")
                status = gr.Textbox(label="Status")

        def generate_gui(code):
            components = []
            if "DatasetBuilder" in code:
                components.append("Dataset Builder")
            if "FineTuner" in code:
                components.append("Training Monitor")
            if "ModelEvaluator" in code:
                components.append("Evaluation Dashboard")
            if "ModelExporter" in code:
                components.append("Export Wizard")
            if components:
                return {"detected_components": components}, f"Detected {len(components)} components"
            return {"detected_components": []}, "No SAARA components detected"

        generate_btn.click(
            generate_gui, inputs=[code_input], outputs=[generated_components, status]
        )
