"""Gradio GUI components and dashboards."""

from importlib import import_module

__all__ = ["SaaraDashboard", "DatasetBuilderUI", "TrainingMonitor", "EvaluationDashboard"]

_LAZY_IMPORTS = {
    "SaaraDashboard": ("saara.gui.dashboard", "SaaraDashboard"),
    "DatasetBuilderUI": ("saara.gui.components", "DatasetBuilderUI"),
    "TrainingMonitor": ("saara.gui.components", "TrainingMonitor"),
    "EvaluationDashboard": ("saara.gui.components", "EvaluationDashboard"),
}


def __getattr__(name: str):
    if name not in _LAZY_IMPORTS:
        raise AttributeError(f"module 'saara.gui' has no attribute {name!r}")

    module_name, attr_name = _LAZY_IMPORTS[name]
    module = import_module(module_name)
    value = getattr(module, attr_name)
    globals()[name] = value
    return value
