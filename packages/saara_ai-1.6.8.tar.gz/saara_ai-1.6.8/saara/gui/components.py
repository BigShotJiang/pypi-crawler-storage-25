"""Individual GUI components."""

from __future__ import annotations


def _gr():
    try:
        import gradio as gr
    except ImportError as exc:
        raise ImportError(
            "Gradio is required for the SAARA GUI. Install it with `pip install gradio`."
        ) from exc
    return gr


def _build_provider(provider_kind: str, model: str, base_url: str):
    from saara.providers.base import ProviderConfig

    if provider_kind == "vllm":
        from saara.providers.vllm_provider import VLLMProvider

        return VLLMProvider(ProviderConfig(model=model, max_tokens=1024, temperature=0.7))

    if provider_kind == "llama.cpp":
        from saara.providers.llamacpp_provider import LlamaCppProvider

        return LlamaCppProvider(ProviderConfig(model=model, max_tokens=1024, temperature=0.7))

    from saara.providers.ollama_provider import OllamaProvider

    return OllamaProvider(
        ProviderConfig(
            model=model,
            base_url=base_url or "http://localhost:11434",
            max_tokens=1024,
            temperature=0.7,
        )
    )


def _provider_help_text(provider_kind: str) -> str:
    if provider_kind == "vllm":
        return "Using local vLLM inference. The base URL field is ignored in this mode."
    if provider_kind == "llama.cpp":
        return "Using llama.cpp. Enter a local GGUF path in the model field for CPU or edge-friendly execution."
    return (
        "Using Ollama. Keep the Ollama daemon running and use a local model name such as `mistral`."
    )


class DatasetBuilderUI:
    """GUI for dataset creation."""

    def render(self):
        gr = _gr()
        gr.HTML(
            "<div class='saara-panel'><div class='saara-section-title'>Dataset Atelier</div><div class='saara-section-copy'>Curate instruction data from PDFs or free text with a provider-first workflow and fast sample preview.</div></div>"
        )

        with gr.Row():
            with gr.Column(scale=5):
                with gr.Group(elem_classes=["saara-panel"]):
                    gr.Markdown("#### Provider Configuration")
                    provider_kind = gr.Radio(
                        label="Provider",
                        choices=[
                            ("vLLM", "vllm"),
                            ("Ollama", "ollama"),
                            ("llama.cpp", "llama.cpp"),
                        ],
                        value="vllm",
                    )
                    with gr.Row():
                        provider_model = gr.Textbox(
                            label="Model",
                            value="meta-llama/Meta-Llama-3-8B-Instruct",
                            scale=3,
                        )
                        provider_base_url = gr.Textbox(
                            label="Base URL",
                            value="http://localhost:11434",
                            scale=2,
                        )
                    provider_help = gr.Markdown(
                        _provider_help_text("vllm"), elem_classes=["saara-tab-note"]
                    )

                with gr.Group(elem_classes=["saara-panel"]):
                    gr.Markdown("#### Source Material")
                    source_type = gr.Radio(
                        label="Source Type",
                        choices=["PDF File", "Text Input"],
                        value="PDF File",
                    )
                    pdf_file = gr.File(label="Upload PDF", file_types=[".pdf"])
                    text_input = gr.Textbox(
                        label="Text Input",
                        placeholder="Paste your raw source text here...",
                        lines=12,
                        visible=False,
                    )

                with gr.Group(elem_classes=["saara-panel"]):
                    gr.Markdown("#### Generation Profile")
                    data_types = gr.CheckboxGroup(
                        label="Data Types",
                        choices=[
                            ("Factual Q&A", "factual"),
                            ("Reasoning", "reasoning"),
                            ("Conversational", "conversational"),
                            ("Instruction", "instruction"),
                            ("Code", "code"),
                            ("Creative", "creative"),
                        ],
                        value=["instruction", "factual"],
                    )
                    with gr.Row():
                        pairs_per_type = gr.Slider(
                            label="Pairs per Type",
                            minimum=1,
                            maximum=20,
                            step=1,
                            value=5,
                        )
                        min_quality = gr.Slider(
                            label="Minimum Quality",
                            minimum=0.0,
                            maximum=1.0,
                            step=0.05,
                            value=0.65,
                        )

                generate_btn = gr.Button("Generate Dataset", variant="primary")

            with gr.Column(scale=4):
                gr.HTML(
                    "<div class='saara-panel'><div class='saara-section-title'>Output Preview</div><div class='saara-section-copy'>Review generated samples before pushing them into training.</div></div>"
                )
                progress = gr.Textbox(label="Execution Status", interactive=False)
                preview = gr.JSON(label="Sample Output")
                download_btn = gr.DownloadButton(label="Download Dataset", variant="secondary")

        def toggle_source(source):
            return gr.update(visible=source == "PDF File"), gr.update(
                visible=source == "Text Input"
            )

        def update_provider_help(provider):
            return _provider_help_text(provider)

        def generate_dataset(
            provider_type, model_name, base_url, pdf, text, source, types, pairs, quality
        ):
            try:
                from saara import DataType, DatasetBuilder

                provider = _build_provider(provider_type, model_name, base_url)
                builder = DatasetBuilder(provider)
                enum_types = [DataType(item) for item in types]

                if source == "PDF File" and pdf:
                    samples = builder.from_pdf(
                        pdf.name,
                        data_types=enum_types,
                        pairs_per_type=int(pairs),
                        min_quality=float(quality),
                    )
                else:
                    samples = builder.from_text(
                        text,
                        data_types=enum_types,
                        pairs_per_type=int(pairs),
                        min_quality=float(quality),
                    )

                path = builder.save(samples, "dataset.jsonl")
                preview_data = [sample.to_dict() for sample in samples[:5]]
                return f"Generated {len(samples)} samples", preview_data, path
            except Exception as exc:
                return f"Error: {exc}", None, None

        provider_kind.change(update_provider_help, inputs=[provider_kind], outputs=[provider_help])
        source_type.change(toggle_source, inputs=[source_type], outputs=[pdf_file, text_input])
        generate_btn.click(
            generate_dataset,
            inputs=[
                provider_kind,
                provider_model,
                provider_base_url,
                pdf_file,
                text_input,
                source_type,
                data_types,
                pairs_per_type,
                min_quality,
            ],
            outputs=[progress, preview, download_btn],
        )


class TrainingMonitor:
    """GUI for monitoring training."""

    def render(self):
        gr = _gr()
        gr.HTML(
            "<div class='saara-panel'><div class='saara-section-title'>Fine-Tune Suite</div><div class='saara-section-copy'>Configure a compact LoRA or QLoRA run with the essential controls front and center.</div></div>"
        )

        with gr.Row():
            with gr.Column(scale=5):
                with gr.Group(elem_classes=["saara-panel"]):
                    gr.Markdown("#### Base Model")
                    model_name = gr.Textbox(label="Model Name", value="mistralai/Mistral-7B-v0.1")
                    dataset_file = gr.File(label="Dataset File", file_types=[".jsonl", ".json"])

                with gr.Group(elem_classes=["saara-panel"]):
                    gr.Markdown("#### Training Profile")
                    with gr.Row():
                        epochs = gr.Slider(label="Epochs", minimum=1, maximum=10, step=1, value=3)
                        batch_size = gr.Slider(
                            label="Batch Size",
                            minimum=1,
                            maximum=32,
                            step=1,
                            value=4,
                        )
                    with gr.Row():
                        learning_rate = gr.Number(label="Learning Rate", value=2e-4)
                        use_lora = gr.Checkbox(label="Use LoRA", value=True)

                train_btn = gr.Button("Start Training", variant="primary")

            with gr.Column(scale=4):
                gr.HTML(
                    "<div class='saara-panel'><div class='saara-section-title'>Training Telemetry</div><div class='saara-section-copy'>Observe status, logs, and basic progress signals while the run executes.</div></div>"
                )
                status = gr.Textbox(label="Status", interactive=False)
                logs = gr.Textbox(label="Training Logs", lines=10, interactive=False)
                with gr.Row():
                    current_epoch = gr.Number(label="Epoch")
                    current_step = gr.Number(label="Step")
                loss_plot = gr.Plot(label="Loss Curve")

        def train_model(model, dataset, epochs, batch_size, lr, use_lora):
            try:
                from saara import FineTuner, TrainingConfig

                config = TrainingConfig(
                    model_name=model,
                    num_train_epochs=int(epochs),
                    per_device_train_batch_size=int(batch_size),
                    learning_rate=float(lr),
                    use_lora=bool(use_lora),
                )
                finetuner = FineTuner(config)
                result = finetuner.train(dataset.name if dataset else [])
                return (
                    "Training completed",
                    f"Metrics: {result['metrics']}",
                    result["state"],
                    epochs,
                    None,
                )
            except Exception as exc:
                return f"Error: {exc}", "", 0, 0, None

        train_btn.click(
            train_model,
            inputs=[model_name, dataset_file, epochs, batch_size, learning_rate, use_lora],
            outputs=[status, logs, current_step, current_epoch, loss_plot],
        )


class EvaluationDashboard:
    """GUI for model evaluation."""

    def render(self):
        gr = _gr()
        gr.HTML(
            "<div class='saara-panel'><div class='saara-section-title'>Evaluation Salon</div><div class='saara-section-copy'>Compare a student model against benchmarks and an optional teacher with a review-oriented layout.</div></div>"
        )

        with gr.Row():
            with gr.Column(scale=5):
                with gr.Group(elem_classes=["saara-panel"]):
                    gr.Markdown("#### Provider")
                    provider_kind = gr.Radio(
                        label="Provider",
                        choices=[
                            ("vLLM", "vllm"),
                            ("Ollama", "ollama"),
                            ("llama.cpp", "llama.cpp"),
                        ],
                        value="vllm",
                    )
                    base_url = gr.Textbox(label="Base URL", value="http://localhost:11434")
                    provider_help = gr.Markdown(
                        _provider_help_text("vllm"), elem_classes=["saara-tab-note"]
                    )

                with gr.Group(elem_classes=["saara-panel"]):
                    gr.Markdown("#### Models and Dataset")
                    student_model = gr.Textbox(
                        label="Student Model",
                        placeholder="Student model or local path",
                    )
                    teacher_model = gr.Textbox(
                        label="Teacher Model (Optional)",
                        placeholder="Teacher model or local path",
                    )
                    eval_dataset = gr.File(
                        label="Evaluation Dataset", file_types=[".jsonl", ".json"]
                    )

                with gr.Group(elem_classes=["saara-panel"]):
                    gr.Markdown("#### Evaluation Profile")
                    benchmarks = gr.CheckboxGroup(
                        label="Benchmarks",
                        choices=[
                            ("MMLU", "mmlu"),
                            ("GSM8K", "gsm8k"),
                            ("HumanEval", "humaneval"),
                            ("BoolQ", "boolq"),
                            ("HellaSwag", "hellaswag"),
                        ],
                        value=["mmlu", "gsm8k"],
                    )
                    with gr.Row():
                        measure_perf = gr.Checkbox(label="Measure Performance", value=True)
                        measure_power = gr.Checkbox(label="Measure Power", value=False)

                evaluate_btn = gr.Button("Run Evaluation", variant="primary")

            with gr.Column(scale=4):
                gr.HTML(
                    "<div class='saara-panel'><div class='saara-section-title'>Scoreboard</div><div class='saara-section-copy'>Inspect metrics, benchmark outputs, latency, throughput, and energy signals in one place.</div></div>"
                )
                status = gr.Textbox(label="Status", interactive=False)
                metrics_json = gr.JSON(label="Metrics")
                with gr.Row():
                    accuracy = gr.Number(label="Accuracy")
                    mmlu = gr.Number(label="MMLU Score")
                    gsm8k = gr.Number(label="GSM8K Score")
                with gr.Row():
                    latency = gr.Number(label="Latency (ms)")
                    throughput = gr.Number(label="Tokens/sec")
                    power = gr.Number(label="Power (W)")

        def update_provider_help(provider):
            return _provider_help_text(provider)

        def run_evaluation(
            provider_type, base_url, student, teacher, dataset, benchmarks, perf, power_flag
        ):
            try:
                from saara import ModelEvaluator

                student_provider = _build_provider(provider_type, student or "mistral", base_url)
                teacher_provider = (
                    _build_provider(provider_type, teacher, base_url) if teacher else None
                )
                evaluator = ModelEvaluator(student_provider, teacher_provider)
                metrics = evaluator.evaluate(
                    dataset=dataset.name if dataset else [],
                    run_benchmarks=True,
                    benchmark_names=list(benchmarks),
                    measure_performance=bool(perf),
                    measure_power=bool(power_flag),
                )
                metrics_dict = metrics.to_dict()
                return (
                    "Evaluation completed",
                    metrics_dict,
                    metrics_dict.get("accuracy", 0),
                    metrics_dict.get("mmlu_score", 0),
                    metrics_dict.get("gsm8k_score", 0),
                    metrics_dict.get("avg_latency_ms", 0),
                    metrics_dict.get("tokens_per_second", 0),
                    metrics_dict.get("power_watts", 0),
                )
            except Exception as exc:
                return f"Error: {exc}", None, 0, 0, 0, 0, 0, 0

        provider_kind.change(update_provider_help, inputs=[provider_kind], outputs=[provider_help])
        evaluate_btn.click(
            run_evaluation,
            inputs=[
                provider_kind,
                base_url,
                student_model,
                teacher_model,
                eval_dataset,
                benchmarks,
                measure_perf,
                measure_power,
            ],
            outputs=[status, metrics_json, accuracy, mmlu, gsm8k, latency, throughput, power],
        )
