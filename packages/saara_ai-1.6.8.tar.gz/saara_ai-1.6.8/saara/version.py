"""SAARA version information."""

__version__ = "1.6.8"
__version_tuple__ = (1, 6, 8)
