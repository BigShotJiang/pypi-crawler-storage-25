"""Training configuration."""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class TrainingConfig:
    """Configuration for fine-tuning."""

    # Model settings
    model_name: str = "mistralai/Mistral-7B-v0.1"
    tokenizer_name: Optional[str] = None

    # LoRA settings
    use_lora: bool = True
    lora_r: int = 16
    lora_alpha: int = 32
    lora_dropout: float = 0.05
    lora_target_modules: list = field(
        default_factory=lambda: [
            "q_proj",
            "k_proj",
            "v_proj",
            "o_proj",
            "gate_proj",
            "up_proj",
            "down_proj",
        ]
    )

    # Training settings
    per_device_train_batch_size: int = 2
    per_device_eval_batch_size: int = 4
    gradient_accumulation_steps: int = 4
    num_train_epochs: int = 3
    learning_rate: float = 2e-4
    weight_decay: float = 0.01
    warmup_ratio: float = 0.03
    lr_scheduler_type: str = "cosine"

    # Optimization
    fp16: bool = True
    bf16: bool = False
    gradient_checkpointing: bool = True
    optim: str = "paged_adamw_8bit"

    # Logging & evaluation
    logging_steps: int = 10
    eval_strategy: str = "steps"
    eval_steps: int = 100
    save_steps: int = 100
    save_total_limit: int = 3

    # Resource settings
    max_seq_length: int = 2048
    load_in_4bit: bool = True
    load_in_8bit: bool = False
    device_map: str = "auto"

    # Output settings
    output_dir: str = "./output/training"
    overwrite_output_dir: bool = True

    def __post_init__(self):
        if self.tokenizer_name is None:
            self.tokenizer_name = self.model_name
