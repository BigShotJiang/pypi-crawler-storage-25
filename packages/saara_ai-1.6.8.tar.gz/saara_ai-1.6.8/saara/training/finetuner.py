"""Fine-tuning using Unsloth and TRL."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional, Callable
from dataclasses import asdict

from saara.training.config import TrainingConfig
from saara.training.callbacks import TrainingCallback


class FineTuner:
    """Fine-tune models using QLoRA/LoRA."""

    def __init__(
        self,
        config: TrainingConfig,
        callbacks: Optional[list[TrainingCallback]] = None,
    ):
        """
        Initialize fine-tuner.

        Args:
            config: Training configuration
            callbacks: List of training callbacks
        """
        self.config = config
        self.callbacks = callbacks or []
        self._model = None
        self._tokenizer = None
        self._trainer = None

    def load_model(self, model_name: Optional[str] = None) -> None:
        """Load model and tokenizer using Unsloth."""
        try:
            from unsloth import FastLanguageModel

            model_name = model_name or self.config.model_name

            self._model, self._tokenizer = FastLanguageModel.from_pretrained(
                model_name=model_name,
                max_seq_length=self.config.max_seq_length,
                dtype=None,
                load_in_4bit=self.config.load_in_4bit,
            )

            if self.config.use_lora:
                self._model = FastLanguageModel.get_peft_model(
                    self._model,
                    r=self.config.lora_r,
                    target_modules=self.config.lora_target_modules,
                    lora_alpha=self.config.lora_alpha,
                    lora_dropout=self.config.lora_dropout,
                    bias="none",
                    use_gradient_checkpointing=self.config.gradient_checkpointing,
                    random_state=42,
                )

        except ImportError:
            raise ImportError("Unsloth not installed. Run: pip install unsloth")

    def train(
        self,
        dataset: str | list[dict],
        validation_split: float = 0.1,
        formatting_func: Optional[Callable] = None,
    ) -> dict:
        """
        Train the model.

        Args:
            dataset: Path to dataset file or list of samples
            validation_split: Fraction for validation
            formatting_func: Function to format samples

        Returns:
            Training history
        """
        from datasets import Dataset, DatasetDict
        from trl import SFTTrainer
        from transformers import TrainingArguments

        if self._model is None:
            self.load_model()

        # Load dataset
        train_dataset, eval_dataset = self._load_dataset(dataset, validation_split, formatting_func)

        # Configure training
        training_args = TrainingArguments(
            output_dir=self.config.output_dir,
            per_device_train_batch_size=self.config.per_device_train_batch_size,
            per_device_eval_batch_size=self.config.per_device_eval_batch_size,
            gradient_accumulation_steps=self.config.gradient_accumulation_steps,
            num_train_epochs=self.config.num_train_epochs,
            learning_rate=self.config.learning_rate,
            weight_decay=self.config.weight_decay,
            warmup_ratio=self.config.warmup_ratio,
            lr_scheduler_type=self.config.lr_scheduler_type,
            fp16=self.config.fp16,
            bf16=self.config.bf16,
            gradient_checkpointing=self.config.gradient_checkpointing,
            optim=self.config.optim,
            logging_steps=self.config.logging_steps,
            evaluation_strategy=self.config.eval_strategy,
            eval_steps=self.config.eval_steps,
            save_steps=self.config.save_steps,
            save_total_limit=self.config.save_total_limit,
            overwrite_output_dir=self.config.overwrite_output_dir,
        )

        # Create trainer
        self._trainer = SFTTrainer(
            model=self._model,
            tokenizer=self._tokenizer,
            train_dataset=train_dataset,
            eval_dataset=eval_dataset,
            args=training_args,
            dataset_text_field="text",
            max_seq_length=self.config.max_seq_length,
        )

        # Notify callbacks
        for callback in self.callbacks:
            callback.on_train_begin(self._trainer)

        # Train
        train_result = self._trainer.train()

        # Notify callbacks
        for callback in self.callbacks:
            callback.on_train_end(self._trainer)

        return {
            "metrics": train_result.metrics,
            "state": self._trainer.state.global_step,
        }

    def _load_dataset(
        self,
        dataset: str | list[dict],
        validation_split: float,
        formatting_func: Optional[Callable],
    ) -> tuple[Dataset, Dataset]:
        """Load and prepare dataset."""
        import json

        if isinstance(dataset, str):
            # Load from file
            with open(dataset, "r", encoding="utf-8") as f:
                data = [json.loads(line) for line in f]
        else:
            data = dataset

        # Apply formatting function if provided
        if formatting_func:
            data = [formatting_func(sample) for sample in data]
        else:
            # Default formatting for Alpaca-style
            data = [self._format_alpaca(sample) for sample in data]

        # Create dataset
        full_dataset = Dataset.from_list(data)

        # Split
        if validation_split > 0:
            split = full_dataset.train_test_split(test_size=validation_split)
            train_dataset = split["train"]
            eval_dataset = split["test"]
        else:
            train_dataset = full_dataset
            eval_dataset = None

        return train_dataset, eval_dataset

    def _format_alpaca(self, sample: dict) -> dict:
        """Format sample in Alpaca style."""
        instruction = sample.get("instruction", "")
        input_text = sample.get("input", "")
        output = sample.get("output", "")

        if input_text:
            text = f"""Below is an instruction that describes a task, paired with an input that provides further context. Write a response that appropriately completes the request.

### Instruction:
{instruction}

### Input:
{input_text}

### Response:
{output}"""
        else:
            text = f"""Below is an instruction that describes a task. Write a response that appropriately completes the request.

### Instruction:
{instruction}

### Response:
{output}"""

        return {"text": text}

    def save(self, output_dir: str) -> str:
        """
        Save trained model.

        Args:
            output_dir: Directory to save model

        Returns:
            Path to saved model
        """
        if self._model is None:
            raise ValueError("No model loaded. Call load_model() or train() first.")

        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        # Save LoRA adapter
        self._model.save_pretrained(str(output_path))
        self._tokenizer.save_pretrained(str(output_path))

        return str(output_path)

    def push_to_hub(self, repo_id: str) -> str:
        """Push model to HuggingFace Hub."""
        if self._model is None:
            raise ValueError("No model loaded.")

        self._model.push_to_hub(repo_id)
        self._tokenizer.push_to_hub(repo_id)

        return f"https://huggingface.co/{repo_id}"

    def get_model(self):
        """Get the trained model."""
        return self._model

    def get_tokenizer(self):
        """Get the tokenizer."""
        return self._tokenizer
