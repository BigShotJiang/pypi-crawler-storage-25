"""Model fine-tuning pipelines."""

from importlib import import_module

__all__ = ["FineTuner", "TrainingConfig", "TrainingCallback"]

_LAZY_IMPORTS = {
    "FineTuner": ("saara.training.finetuner", "FineTuner"),
    "TrainingConfig": ("saara.training.config", "TrainingConfig"),
    "TrainingCallback": ("saara.training.callbacks", "TrainingCallback"),
}


def __getattr__(name: str):
    if name not in _LAZY_IMPORTS:
        raise AttributeError(f"module 'saara.training' has no attribute {name!r}")

    module_name, attr_name = _LAZY_IMPORTS[name]
    module = import_module(module_name)
    value = getattr(module, attr_name)
    globals()[name] = value
    return value
