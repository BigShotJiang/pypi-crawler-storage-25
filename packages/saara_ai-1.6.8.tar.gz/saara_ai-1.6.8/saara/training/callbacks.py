"""Training callbacks."""

from typing import Optional, Any
from abc import ABC, abstractmethod


class TrainingCallback(ABC):
    """Base class for training callbacks."""

    def on_train_begin(self, trainer: Any) -> None:
        """Called at the beginning of training."""
        pass

    def on_train_end(self, trainer: Any) -> None:
        """Called at the end of training."""
        pass

    def on_epoch_begin(self, trainer: Any, epoch: int) -> None:
        """Called at the beginning of each epoch."""
        pass

    def on_epoch_end(self, trainer: Any, epoch: int, logs: dict) -> None:
        """Called at the end of each epoch."""
        pass

    def on_step_end(self, trainer: Any, step: int, logs: dict) -> None:
        """Called at the end of each training step."""
        pass

    def on_log(self, trainer: Any, logs: dict) -> None:
        """Called when logs are written."""
        pass


class ProgressCallback(TrainingCallback):
    """Track training progress."""

    def __init__(self):
        self.epoch = 0
        self.step = 0
        self.logs_history = []

    def on_epoch_end(self, trainer: Any, epoch: int, logs: dict) -> None:
        self.epoch = epoch
        self.logs_history.append(logs)

    def on_step_end(self, trainer: Any, step: int, logs: dict) -> None:
        self.step = step

    def get_progress(self) -> dict:
        """Get current progress."""
        return {
            "epoch": self.epoch,
            "step": self.step,
            "logs": self.logs_history[-1] if self.logs_history else {},
        }


class EarlyStoppingCallback(TrainingCallback):
    """Early stopping based on evaluation metric."""

    def __init__(
        self,
        metric: str = "eval_loss",
        patience: int = 3,
        min_delta: float = 0.001,
        mode: str = "min",
    ):
        self.metric = metric
        self.patience = patience
        self.min_delta = min_delta
        self.mode = mode
        self.best_value = None
        self.wait = 0
        self.should_stop = False

    def on_epoch_end(self, trainer: Any, epoch: int, logs: dict) -> None:
        current_value = logs.get(self.metric)

        if current_value is None:
            return

        if self.best_value is None:
            self.best_value = current_value
            self.wait = 0
        else:
            if self.mode == "min":
                improved = current_value < self.best_value - self.min_delta
            else:
                improved = current_value > self.best_value + self.min_delta

            if improved:
                self.best_value = current_value
                self.wait = 0
            else:
                self.wait += 1
                if self.wait >= self.patience:
                    self.should_stop = True
