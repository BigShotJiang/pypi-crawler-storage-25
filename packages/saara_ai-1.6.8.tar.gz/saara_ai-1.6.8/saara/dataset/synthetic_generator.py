"""Synthetic data generation using LLMs."""

from typing import Optional
from concurrent.futures import ThreadPoolExecutor

from saara.providers.base import ModelProvider, ProviderConfig
from saara.dataset.types import DataType, DataSample


class SyntheticDataGenerator:
    """Generate synthetic training data using LLMs."""

    TEMPLATES = {
        DataType.FACTUAL: """Generate {count} factual question-answer pairs from the following text.
Focus on key facts, definitions, and important information.

Text:
{text}

Output format (JSON):
[
  {{"instruction": "question", "input": "", "output": "answer"}},
  ...
]""",
        DataType.REASONING: """Generate {count} reasoning questions from the following text.
Questions should require logical thinking, inference, or multi-step reasoning.

Text:
{text}

Output format (JSON):
[
  {{"instruction": "question", "input": "", "output": "answer with reasoning"}},
  ...
]""",
        DataType.CONVERSATIONAL: """Generate {count} conversational exchanges based on the following text.
Create natural dialogues where someone asks about the content.

Text:
{text}

Output format (JSON):
[
  {{"instruction": "question", "input": "", "output": "natural response"}},
  ...
]""",
        DataType.INSTRUCTION: """Generate {count} instruction-following examples from the following text.
Create tasks that require using information from the text.

Text:
{text}

Output format (JSON):
[
  {{"instruction": "task description", "input": "optional input", "output": "expected output"}},
  ...
]""",
        DataType.CODE: """Generate {count} coding tasks related to the following text.
Create programming problems or code explanations.

Text:
{text}

Output format (JSON):
[
  {{"instruction": "coding task", "input": "code snippet", "output": "solution/explanation"}},
  ...
]""",
        DataType.CREATIVE: """Generate {count} creative writing prompts inspired by the following text.
Create imaginative scenarios or stories.

Text:
{text}

Output format (JSON):
[
  {{"instruction": "creative prompt", "input": "", "output": "creative response"}},
  ...
]""",
    }

    def __init__(
        self,
        provider: ModelProvider,
        min_quality: float = 0.65,
        max_workers: int = 4,
    ):
        """
        Initialize synthetic data generator.

        Args:
            provider: Model provider for generation
            min_quality: Minimum quality score threshold
            max_workers: Maximum parallel workers for batch generation
        """
        self.provider = provider
        self.min_quality = min_quality
        self.max_workers = max_workers

    def generate(
        self,
        text: str,
        data_types: list[DataType],
        pairs_per_type: int = 5,
        min_quality: Optional[float] = None,
    ) -> list[DataSample]:
        """
        Generate synthetic data from text.

        Args:
            text: Source text
            data_types: Types of data to generate
            pairs_per_type: Number of pairs per type
            min_quality: Override default minimum quality

        Returns:
            List of generated data samples
        """
        min_quality = min_quality or self.min_quality
        all_samples = []

        for data_type in data_types:
            samples = self._generate_type(text, data_type, pairs_per_type, min_quality)
            all_samples.extend(samples)

        return all_samples

    def _generate_type(
        self,
        text: str,
        data_type: DataType,
        count: int,
        min_quality: float,
    ) -> list[DataSample]:
        """Generate samples for a specific data type."""
        template = self.TEMPLATES.get(data_type)
        if not template:
            raise ValueError(f"Unknown data type: {data_type}")

        prompt = template.format(count=count, text=text[:4000])

        try:
            response = self.provider.generate(prompt)
            samples = self._parse_response(response.text, data_type, min_quality)
            return samples
        except Exception as e:
            print(f"Generation failed for {data_type.value}: {e}")
            return []

    def _parse_response(
        self,
        response_text: str,
        data_type: DataType,
        min_quality: float,
    ) -> list[DataSample]:
        """Parse LLM response into data samples."""
        import json
        import re

        samples = []

        # Try to extract JSON from response
        json_match = re.search(r"\[.*\]", response_text, re.DOTALL)
        if json_match:
            try:
                data = json.loads(json_match.group())
                for item in data:
                    sample = DataSample(
                        instruction=item.get("instruction", ""),
                        input=item.get("input", ""),
                        output=item.get("output", ""),
                        data_type=data_type,
                        quality_score=0.0,
                    )
                    if sample.instruction and sample.output:
                        samples.append(sample)
            except json.JSONDecodeError:
                pass

        return samples

    def generate_batch(
        self,
        texts: list[str],
        data_types: list[DataType],
        pairs_per_type: int = 5,
    ) -> list[list[DataSample]]:
        """Generate synthetic data for multiple texts in parallel."""
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = [
                executor.submit(self.generate, text, data_types, pairs_per_type) for text in texts
            ]
            results = [future.result() for future in futures]
        return results

    def judge_quality(
        self,
        samples: list[DataSample],
        judge_provider: Optional[ModelProvider] = None,
    ) -> list[DataSample]:
        """
        Judge quality of generated samples.

        Args:
            samples: Samples to judge
            judge_provider: Provider for judging (uses main provider if None)

        Returns:
            Samples with quality scores
        """
        judge = judge_provider or self.provider

        for sample in samples:
            try:
                prompt = f"""Rate this Q&A pair quality from 0.0 to 1.0:
Question: {sample.instruction}
Answer: {sample.output}

Rate on: clarity, correctness, completeness, relevance.
Output only a number between 0.0 and 1.0."""

                response = judge.generate(prompt)
                score = float(response.text.strip()[:3])
                sample.quality_score = max(0.0, min(1.0, score))
            except Exception:
                sample.quality_score = 0.5

        return samples
