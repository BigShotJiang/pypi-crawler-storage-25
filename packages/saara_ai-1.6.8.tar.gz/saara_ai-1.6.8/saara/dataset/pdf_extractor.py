"""PDF extraction utilities."""

import os
from pathlib import Path
from typing import Optional


class PDFExtractor:
    """Extract text from PDF files."""

    def __init__(self, backend: str = "pymupdf"):
        """
        Initialize PDF extractor.

        Args:
            backend: Extraction backend ("pymupdf" or "pdfplumber")
        """
        self.backend = backend
        self._backend_module = None
        if self.backend not in {"pymupdf", "pdfplumber"}:
            raise ValueError(f"Unknown backend: {self.backend}")

    def _init_backend(self) -> None:
        """Initialize the extraction backend."""
        if self.backend == "pymupdf":
            try:
                import fitz

                self._backend_module = fitz
            except ImportError:
                raise ImportError("PyMuPDF not installed. Run: pip install pymupdf")
        elif self.backend == "pdfplumber":
            try:
                import pdfplumber

                self._backend_module = pdfplumber
            except ImportError:
                raise ImportError("pdfplumber not installed. Run: pip install pdfplumber")
        else:
            raise ValueError(f"Unknown backend: {self.backend}")

    def extract(self, pdf_path: str, pages: Optional[list[int]] = None) -> str:
        """
        Extract text from PDF.

        Args:
            pdf_path: Path to PDF file
            pages: Specific pages to extract (None = all)

        Returns:
            Extracted text
        """
        pdf_path = str(pdf_path)
        if not os.path.exists(pdf_path):
            raise FileNotFoundError(f"PDF not found: {pdf_path}")

        self._ensure_backend()

        if self.backend == "pymupdf":
            return self._extract_pymupdf(pdf_path, pages)
        else:
            return self._extract_pdfplumber(pdf_path, pages)

    def _extract_pymupdf(self, pdf_path: str, pages: Optional[list[int]]) -> str:
        """Extract using PyMuPDF."""
        doc = self._backend_module.open(pdf_path)

        if pages is None:
            pages = list(range(len(doc)))

        text_parts = []
        for page_num in pages:
            if page_num < len(doc):
                page = doc[page_num]
                text_parts.append(page.get_text())

        doc.close()
        return "\n\n".join(text_parts)

    def _extract_pdfplumber(self, pdf_path: str, pages: Optional[list[int]]) -> str:
        """Extract using pdfplumber."""
        with self._backend_module.open(pdf_path) as pdf:
            if pages is None:
                pages = range(len(pdf.pages))

            text_parts = []
            for page_num in pages:
                if page_num < len(pdf.pages):
                    page = pdf.pages[page_num]
                    text = page.extract_text()
                    if text:
                        text_parts.append(text)

        return "\n\n".join(text_parts)

    def extract_batch(self, pdf_paths: list[str]) -> dict[str, str]:
        """
        Extract text from multiple PDFs.

        Args:
            pdf_paths: List of PDF paths

        Returns:
            Dictionary mapping path to extracted text
        """
        results = {}
        for path in pdf_paths:
            try:
                results[path] = self.extract(path)
            except Exception as e:
                results[path] = f"ERROR: {str(e)}"
        return results

    def get_metadata(self, pdf_path: str) -> dict:
        """Get PDF metadata."""
        pdf_path = str(pdf_path)
        self._ensure_backend()

        if self.backend == "pymupdf":
            doc = self._backend_module.open(pdf_path)
            metadata = {
                "pages": len(doc),
                "metadata": doc.metadata,
            }
            doc.close()
            return metadata
        else:
            with self._backend_module.open(pdf_path) as pdf:
                return {
                    "pages": len(pdf.pages),
                    "metadata": pdf.metadata,
                }

    def _ensure_backend(self) -> None:
        """Load the configured PDF backend only when PDF operations are used."""
        if self._backend_module is None:
            self._init_backend()
