"""Dataset creation and synthetic data generation."""

from importlib import import_module

__all__ = [
    "DatasetBuilder",
    "PDFExtractor",
    "SyntheticDataGenerator",
    "DataType",
    "DatasetFormat",
    "DataSample",
]

_LAZY_IMPORTS = {
    "DatasetBuilder": ("saara.dataset.builder", "DatasetBuilder"),
    "PDFExtractor": ("saara.dataset.pdf_extractor", "PDFExtractor"),
    "SyntheticDataGenerator": ("saara.dataset.synthetic_generator", "SyntheticDataGenerator"),
    "DataType": ("saara.dataset.types", "DataType"),
    "DatasetFormat": ("saara.dataset.types", "DatasetFormat"),
    "DataSample": ("saara.dataset.types", "DataSample"),
}


def __getattr__(name: str):
    if name not in _LAZY_IMPORTS:
        raise AttributeError(f"module 'saara.dataset' has no attribute {name!r}")

    module_name, attr_name = _LAZY_IMPORTS[name]
    module = import_module(module_name)
    value = getattr(module, attr_name)
    globals()[name] = value
    return value
