"""Dataset types and formats."""

from enum import Enum
from dataclasses import dataclass


class DataType(Enum):
    """Types of synthetic data."""

    FACTUAL = "factual"
    REASONING = "reasoning"
    CONVERSATIONAL = "conversational"
    INSTRUCTION = "instruction"
    CODE = "code"
    CREATIVE = "creative"


class DatasetFormat(Enum):
    """Output formats for datasets."""

    ALPACA = "alpaca"
    CHATML = "chatml"
    SHAREGPT = "sharegpt"
    DPO = "dpo"
    COMPLETION = "completion"
    JSONL = "jsonl"


@dataclass
class DataSample:
    """Single data sample."""

    instruction: str
    input: str = ""
    output: str = ""
    data_type: DataType = DataType.INSTRUCTION
    quality_score: float = 0.0
    metadata: dict = None

    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "instruction": self.instruction,
            "input": self.input,
            "output": self.output,
            "data_type": self.data_type.value,
            "quality_score": self.quality_score,
            "metadata": self.metadata,
        }
