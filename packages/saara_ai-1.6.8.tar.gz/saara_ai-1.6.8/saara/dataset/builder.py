"""Dataset builder - orchestrates dataset creation."""

import json
import os
from pathlib import Path
from typing import Optional

from saara.dataset.types import DataType, DatasetFormat, DataSample
from saara.dataset.pdf_extractor import PDFExtractor
from saara.dataset.synthetic_generator import SyntheticDataGenerator
from saara.providers.base import ModelProvider


class DatasetBuilder:
    """Build datasets from PDFs and synthetic generation."""

    def __init__(
        self,
        provider: ModelProvider,
        output_dir: str = "./output",
        output_format: DatasetFormat = DatasetFormat.ALPACA,
    ):
        """
        Initialize dataset builder.

        Args:
            provider: Model provider for generation
            output_dir: Directory for output files
            output_format: Output format for datasets
        """
        self.provider = provider
        self.output_dir = Path(output_dir)
        self.output_format = output_format
        self.output_dir.mkdir(parents=True, exist_ok=True)

        self.pdf_extractor = PDFExtractor()
        self.synthetic_generator = SyntheticDataGenerator(provider)

    def from_pdf(
        self,
        pdf_path: str,
        data_types: list[DataType],
        pairs_per_type: int = 5,
        chunk_size: int = 2000,
        chunk_overlap: int = 200,
        min_quality: float = 0.65,
    ) -> list[DataSample]:
        """
        Create dataset from PDF.

        Args:
            pdf_path: Path to PDF file
            data_types: Types of data to generate
            pairs_per_type: Number of pairs per type per chunk
            chunk_size: Size of text chunks
            chunk_overlap: Overlap between chunks
            min_quality: Minimum quality threshold

        Returns:
            List of generated samples
        """
        # Extract text from PDF
        text = self.pdf_extractor.extract(pdf_path)

        # Chunk text
        chunks = self._chunk_text(text, chunk_size, chunk_overlap)

        # Generate synthetic data for each chunk
        all_samples = []
        for chunk in chunks:
            samples = self.synthetic_generator.generate(
                chunk,
                data_types,
                pairs_per_type,
                min_quality,
            )
            all_samples.extend(samples)

        # Filter by quality
        filtered = [s for s in all_samples if s.quality_score >= min_quality]

        return filtered

    def from_text(
        self,
        text: str,
        data_types: list[DataType],
        pairs_per_type: int = 5,
        min_quality: float = 0.65,
    ) -> list[DataSample]:
        """
        Create dataset from text.

        Args:
            text: Source text
            data_types: Types of data to generate
            pairs_per_type: Number of pairs per type
            min_quality: Minimum quality threshold

        Returns:
            List of generated samples
        """
        samples = self.synthetic_generator.generate(
            text,
            data_types,
            pairs_per_type,
            min_quality,
        )

        # Filter by quality
        filtered = [s for s in samples if s.quality_score >= min_quality]

        return filtered

    def save(
        self,
        samples: list[DataSample],
        filename: str,
        format: Optional[DatasetFormat] = None,
    ) -> str:
        """
        Save samples to file.

        Args:
            samples: Samples to save
            filename: Output filename
            format: Override default format

        Returns:
            Path to saved file
        """
        format = format or self.output_format
        output_path = self.output_dir / filename

        if format == DatasetFormat.JSONL:
            self._save_jsonl(samples, output_path)
        elif format == DatasetFormat.ALPACA:
            self._save_alpaca(samples, output_path)
        elif format == DatasetFormat.CHATML:
            self._save_chatml(samples, output_path)
        elif format == DatasetFormat.SHAREGPT:
            self._save_sharegpt(samples, output_path)
        elif format == DatasetFormat.DPO:
            self._save_dpo(samples, output_path)
        else:
            raise ValueError(f"Unsupported format: {format}")

        return str(output_path)

    def _chunk_text(
        self,
        text: str,
        chunk_size: int,
        chunk_overlap: int,
    ) -> list[str]:
        """Split text into overlapping chunks."""
        if chunk_size <= 0:
            raise ValueError("chunk_size must be greater than 0")
        if chunk_overlap < 0:
            raise ValueError("chunk_overlap must be greater than or equal to 0")
        if chunk_overlap >= chunk_size:
            raise ValueError("chunk_overlap must be smaller than chunk_size")

        chunks = []
        start = 0

        while start < len(text):
            end = start + chunk_size
            chunk = text[start:end]

            # Try to break at sentence boundary
            if end < len(text):
                last_period = chunk.rfind(".")
                if last_period > chunk_size * 0.5:
                    chunk = chunk[: last_period + 1]
                    end = start + last_period + 1

            stripped_chunk = chunk.strip()
            if stripped_chunk:
                chunks.append(stripped_chunk)
            start = end - chunk_overlap

        return chunks

    def _save_jsonl(self, samples: list[DataSample], path: Path) -> None:
        """Save as JSONL."""
        with open(path, "w", encoding="utf-8") as f:
            for sample in samples:
                f.write(json.dumps(sample.to_dict()) + "\n")

    def _save_alpaca(self, samples: list[DataSample], path: Path) -> None:
        """Save in Alpaca format."""
        data = []
        for sample in samples:
            data.append(
                {
                    "instruction": sample.instruction,
                    "input": sample.input,
                    "output": sample.output,
                }
            )

        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def _save_chatml(self, samples: list[DataSample], path: Path) -> None:
        """Save in ChatML format."""
        data = []
        for sample in samples:
            messages = [
                {"role": "user", "content": f"{sample.instruction}\n{sample.input}".strip()},
                {"role": "assistant", "content": sample.output},
            ]
            data.append({"messages": messages})

        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def _save_sharegpt(self, samples: list[DataSample], path: Path) -> None:
        """Save in ShareGPT format."""
        data = []
        for sample in samples:
            conversations = [
                {"from": "human", "value": f"{sample.instruction}\n{sample.input}".strip()},
                {"from": "gpt", "value": sample.output},
            ]
            data.append({"conversations": conversations})

        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def _save_dpo(self, samples: list[DataSample], path: Path) -> None:
        """Save in DPO format (requires preference data)."""
        # For now, save as simple preference pairs
        data = []
        for sample in samples:
            data.append(
                {
                    "prompt": sample.instruction,
                    "chosen": sample.output,
                    "rejected": "",
                }
            )

        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
