"""Backward-compatible public API surface for notebooks and older examples."""

from importlib import import_module

__all__ = [
    "DatasetBuilder",
    "FineTuner",
    "TrainingConfig",
    "ModelEvaluator",
    "ModelExporter",
    "ModelProvider",
    "ProviderConfig",
    "QuantizationConfig",
    "ExportFormat",
]

_LAZY_IMPORTS = {
    "DatasetBuilder": ("saara.dataset.builder", "DatasetBuilder"),
    "FineTuner": ("saara.training.finetuner", "FineTuner"),
    "TrainingConfig": ("saara.training.config", "TrainingConfig"),
    "ModelEvaluator": ("saara.evaluation.evaluator", "ModelEvaluator"),
    "ModelExporter": ("saara.export.exporter", "ModelExporter"),
    "ModelProvider": ("saara.providers.base", "ModelProvider"),
    "ProviderConfig": ("saara.providers.base", "ProviderConfig"),
    "QuantizationConfig": ("saara.export.quantization", "QuantizationConfig"),
    "ExportFormat": ("saara.export.formats", "ExportFormat"),
}


def __getattr__(name: str):
    if name not in _LAZY_IMPORTS:
        raise AttributeError(f"module 'saara.core' has no attribute {name!r}")

    module_name, attr_name = _LAZY_IMPORTS[name]
    module = import_module(module_name)
    value = getattr(module, attr_name)
    globals()[name] = value
    return value
