"""vLLM provider for high-throughput GPU inference."""

import time
from typing import Any, Generator

from saara.providers.base import ModelProvider, ProviderConfig, GenerationResponse


class VLLMProvider(ModelProvider):
    """vLLM provider for local GPU inference."""

    def __init__(self, config: ProviderConfig):
        super().__init__(config)
        self._engine = None

    def initialize(self) -> None:
        """Initialize vLLM engine."""
        try:
            from vllm import LLM, SamplingParams

            self._sampling_params = SamplingParams(
                max_tokens=self.config.max_tokens,
                temperature=self.config.temperature,
                top_p=self.config.top_p,
            )

            self._engine = LLM(
                model=self.config.model,
                tensor_parallel_size=self.config.tensor_parallel_size,
                gpu_memory_utilization=self.config.gpu_memory_utilization,
            )
            self._initialized = True

        except ImportError:
            raise ImportError("vLLM not installed. Run: pip install vllm")

    def generate(self, prompt: str, **kwargs) -> GenerationResponse:
        """Generate text using vLLM."""
        if not self._initialized:
            self.initialize()

        start_time = time.time()
        outputs = self._engine.generate([prompt], self._sampling_params)
        latency_ms = (time.time() - start_time) * 1000

        output = outputs[0]
        return GenerationResponse(
            text=output.outputs[0].text,
            tokens=len(output.outputs[0].token_ids),
            prompt_tokens=len(output.prompt_token_ids),
            completion_tokens=len(output.outputs[0].token_ids),
            finish_reason=output.outputs[0].finish_reason,
            latency_ms=latency_ms,
        )

    def generate_batch(self, prompts: list[str], **kwargs) -> list[GenerationResponse]:
        """Generate text for multiple prompts."""
        if not self._initialized:
            self.initialize()

        start_time = time.time()
        outputs = self._engine.generate(prompts, self._sampling_params)
        latency_ms = (time.time() - start_time) * 1000

        responses = []
        for output in outputs:
            responses.append(
                GenerationResponse(
                    text=output.outputs[0].text,
                    tokens=len(output.outputs[0].token_ids),
                    prompt_tokens=len(output.prompt_token_ids),
                    completion_tokens=len(output.outputs[0].token_ids),
                    finish_reason=output.outputs[0].finish_reason,
                    latency_ms=latency_ms,
                )
            )

        return responses

    def generate_stream(self, prompt: str, **kwargs) -> Generator[str, None, None]:
        """Stream generation (vLLM doesn't support streaming, yield full text)."""
        response = self.generate(prompt, **kwargs)
        yield response.text

    def get_model_info(self) -> dict[str, Any]:
        """Get model information."""
        return {
            "provider": "vllm",
            "model": self.config.model,
            "tensor_parallel_size": self.config.tensor_parallel_size,
            "gpu_memory_utilization": self.config.gpu_memory_utilization,
        }

    def cleanup(self) -> None:
        """Cleanup vLLM engine."""
        if self._engine is not None:
            del self._engine
        self._initialized = False
