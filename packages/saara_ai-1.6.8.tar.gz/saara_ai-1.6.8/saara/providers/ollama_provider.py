"""Ollama provider for simple local inference."""

import time
from typing import Any, Generator

from saara.providers.base import ModelProvider, ProviderConfig, GenerationResponse


class OllamaProvider(ModelProvider):
    """Ollama provider for local inference."""

    def __init__(self, config: ProviderConfig):
        super().__init__(config)
        self._client = None
        if not self.config.base_url:
            self.config.base_url = "http://localhost:11434"

    def initialize(self) -> None:
        """Initialize Ollama client."""
        try:
            import ollama

            self._client = ollama.Client(host=self.config.base_url)
            self._initialized = True

        except ImportError:
            raise ImportError("Ollama not installed. Run: pip install ollama")

    def generate(self, prompt: str, **kwargs) -> GenerationResponse:
        """Generate text using Ollama."""
        if not self._initialized:
            self.initialize()

        start_time = time.time()
        response = self._client.generate(
            model=self.config.model,
            prompt=prompt,
            options={
                "num_predict": self.config.max_tokens,
                "temperature": self.config.temperature,
                "top_p": self.config.top_p,
            },
        )
        latency_ms = (time.time() - start_time) * 1000

        return GenerationResponse(
            text=response["response"],
            tokens=response.get("eval_count", 0),
            prompt_tokens=response.get("prompt_eval_count", 0),
            completion_tokens=response.get("eval_count", 0),
            finish_reason="stop",
            latency_ms=latency_ms,
        )

    def generate_batch(self, prompts: list[str], **kwargs) -> list[GenerationResponse]:
        """Generate text for multiple prompts sequentially."""
        return [self.generate(prompt, **kwargs) for prompt in prompts]

    def generate_stream(self, prompt: str, **kwargs) -> Generator[str, None, None]:
        """Stream generation token by token."""
        if not self._initialized:
            self.initialize()

        stream = self._client.generate(
            model=self.config.model,
            prompt=prompt,
            stream=True,
            options={
                "num_predict": self.config.max_tokens,
                "temperature": self.config.temperature,
                "top_p": self.config.top_p,
            },
        )

        for chunk in stream:
            if chunk["done"]:
                break
            yield chunk.get("response", "")

    def get_model_info(self) -> dict[str, Any]:
        """Get model information."""
        return {
            "provider": "ollama",
            "model": self.config.model,
            "base_url": self.config.base_url,
        }

    def cleanup(self) -> None:
        """Cleanup Ollama client."""
        self._client = None
        self._initialized = False
