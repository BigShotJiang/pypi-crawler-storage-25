"""Deterministic provider for local demos, tests, and notebook-safe execution."""

from __future__ import annotations

import json
from typing import Any, Generator

from saara.providers.base import GenerationResponse, ModelProvider, ProviderConfig


class DemoProvider(ModelProvider):
    """A tiny provider that returns deterministic JSON samples.

    This is not a real LLM backend. It exists so notebooks and examples can run in
    constrained environments without vLLM, Ollama, or llama.cpp.
    """

    def initialize(self) -> None:
        self._initialized = True

    def generate(self, prompt: str, **kwargs) -> GenerationResponse:
        if not self._initialized:
            self.initialize()

        text = self._build_response(prompt)
        return GenerationResponse(
            text=text,
            tokens=max(1, len(text.split())),
            prompt_tokens=max(1, len(prompt.split())),
            completion_tokens=max(1, len(text.split())),
            finish_reason="stop",
            latency_ms=1.0,
        )

    def generate_batch(self, prompts: list[str], **kwargs) -> list[GenerationResponse]:
        return [self.generate(prompt, **kwargs) for prompt in prompts]

    def generate_stream(self, prompt: str, **kwargs) -> Generator[str, None, None]:
        yield self.generate(prompt, **kwargs).text

    def get_model_info(self) -> dict[str, Any]:
        return {
            "provider": "demo",
            "model": self.config.model,
            "description": "Deterministic notebook-safe provider",
        }

    def _build_response(self, prompt: str) -> str:
        topic = "the requested topic"
        if "Text:" in prompt:
            topic = prompt.split("Text:", 1)[1].strip().splitlines()[0][:80] or topic

        payload = [
            {
                "instruction": f"Summarize the key idea behind {topic}.",
                "input": "",
                "output": f"{topic} focuses on practical deployment constraints, measurable tradeoffs, and real-world implementation details.",
            },
            {
                "instruction": f"List one implementation challenge for {topic}.",
                "input": "",
                "output": f"A common challenge in {topic} is balancing latency, memory, and reliability under constrained hardware budgets.",
            },
            {
                "instruction": f"Explain when {topic} is a strong fit.",
                "input": "",
                "output": f"{topic} is a strong fit when local processing, privacy, low latency, or intermittent connectivity matter more than centralized inference.",
            },
        ]
        return json.dumps(payload, indent=2)
