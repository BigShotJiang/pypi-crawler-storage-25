"""Model provider abstraction layer."""

from importlib import import_module

__all__ = [
    "ModelProvider",
    "ProviderConfig",
    "GenerationResponse",
    "DemoProvider",
    "VLLMProvider",
    "OllamaProvider",
    "LlamaCppProvider",
]

_LAZY_IMPORTS = {
    "ModelProvider": ("saara.providers.base", "ModelProvider"),
    "ProviderConfig": ("saara.providers.base", "ProviderConfig"),
    "GenerationResponse": ("saara.providers.base", "GenerationResponse"),
    "DemoProvider": ("saara.providers.demo_provider", "DemoProvider"),
    "VLLMProvider": ("saara.providers.vllm_provider", "VLLMProvider"),
    "OllamaProvider": ("saara.providers.ollama_provider", "OllamaProvider"),
    "LlamaCppProvider": ("saara.providers.llamacpp_provider", "LlamaCppProvider"),
}


def __getattr__(name: str):
    if name not in _LAZY_IMPORTS:
        raise AttributeError(f"module 'saara.providers' has no attribute {name!r}")

    module_name, attr_name = _LAZY_IMPORTS[name]
    module = import_module(module_name)
    value = getattr(module, attr_name)
    globals()[name] = value
    return value
