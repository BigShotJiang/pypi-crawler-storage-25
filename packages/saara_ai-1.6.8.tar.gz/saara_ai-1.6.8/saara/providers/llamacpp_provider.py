"""llama.cpp provider for CPU/metal inference."""

import time
from typing import Any, Generator

from saara.providers.base import ModelProvider, ProviderConfig, GenerationResponse


class LlamaCppProvider(ModelProvider):
    """llama.cpp provider for CPU/metal inference."""

    def __init__(self, config: ProviderConfig):
        super().__init__(config)
        self._model = None

    def initialize(self) -> None:
        """Initialize llama.cpp model."""
        try:
            from llama_cpp import Llama

            self._model = Llama(
                model_path=self.config.model,
                n_ctx=self.config.max_tokens,
                n_threads=4,
                verbose=False,
            )
            self._initialized = True

        except ImportError:
            raise ImportError("llama-cpp-python not installed. Run: pip install llama-cpp-python")

    def generate(self, prompt: str, **kwargs) -> GenerationResponse:
        """Generate text using llama.cpp."""
        if not self._initialized:
            self.initialize()

        start_time = time.time()
        output = self._model(
            prompt,
            max_tokens=self.config.max_tokens,
            temperature=self.config.temperature,
            top_p=self.config.top_p,
        )
        latency_ms = (time.time() - start_time) * 1000

        text = output["choices"][0]["text"]
        return GenerationResponse(
            text=text,
            tokens=output.get("usage", {}).get("completion_tokens", 0),
            prompt_tokens=output.get("usage", {}).get("prompt_tokens", 0),
            completion_tokens=output.get("usage", {}).get("completion_tokens", 0),
            finish_reason=output["choices"][0].get("finish_reason"),
            latency_ms=latency_ms,
        )

    def generate_batch(self, prompts: list[str], **kwargs) -> list[GenerationResponse]:
        """Generate text for multiple prompts sequentially."""
        return [self.generate(prompt, **kwargs) for prompt in prompts]

    def generate_stream(self, prompt: str, **kwargs) -> Generator[str, None, None]:
        """Stream generation token by token."""
        if not self._initialized:
            self.initialize()

        for chunk in self._model(
            prompt,
            max_tokens=self.config.max_tokens,
            temperature=self.config.temperature,
            top_p=self.config.top_p,
            stream=True,
        ):
            yield chunk["choices"][0]["text"]

    def get_model_info(self) -> dict[str, Any]:
        """Get model information."""
        return {
            "provider": "llama.cpp",
            "model": self.config.model,
        }

    def cleanup(self) -> None:
        """Cleanup llama.cpp model."""
        if self._model is not None:
            del self._model
        self._initialized = False
