"""Base provider interface."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Generator, Optional


@dataclass
class ProviderConfig:
    """Configuration for model providers."""

    model: str
    base_url: Optional[str] = None
    api_key: Optional[str] = None
    max_tokens: int = 2048
    temperature: float = 0.7
    top_p: float = 0.9
    timeout: int = 120
    gpu_memory_utilization: float = 0.9
    tensor_parallel_size: int = 1


@dataclass
class GenerationResponse:
    """Response from model generation."""

    text: str
    tokens: int
    prompt_tokens: int
    completion_tokens: int
    finish_reason: Optional[str] = None
    latency_ms: Optional[float] = None


class ModelProvider(ABC):
    """Abstract base class for model providers."""

    def __init__(self, config: ProviderConfig):
        self.config = config
        self._initialized = False

    @abstractmethod
    def initialize(self) -> None:
        """Initialize the provider and load model."""
        pass

    @abstractmethod
    def generate(self, prompt: str, **kwargs) -> GenerationResponse:
        """Generate text from a prompt."""
        pass

    @abstractmethod
    def generate_batch(self, prompts: list[str], **kwargs) -> list[GenerationResponse]:
        """Generate text from multiple prompts."""
        pass

    @abstractmethod
    def generate_stream(self, prompt: str, **kwargs) -> Generator[str, None, None]:
        """Stream generation token by token."""
        pass

    @abstractmethod
    def get_model_info(self) -> dict[str, Any]:
        """Get model information."""
        pass

    def is_available(self) -> bool:
        """Check if provider is available."""
        try:
            self.initialize()
            return True
        except Exception:
            return False

    def __enter__(self):
        self.initialize()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.cleanup()

    def cleanup(self) -> None:
        """Cleanup resources."""
        self._initialized = False
