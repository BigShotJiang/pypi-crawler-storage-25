"""SAARA public package interface."""

from importlib import import_module

from saara.version import __version__

__all__ = [
    "__version__",
    "DatasetBuilder",
    "DataType",
    "DatasetFormat",
    "FineTuner",
    "TrainingConfig",
    "ModelEvaluator",
    "ModelExporter",
    "ModelProvider",
    "ProviderConfig",
    "DemoProvider",
    "VLLMProvider",
    "OllamaProvider",
    "LlamaCppProvider",
    "QuantizationConfig",
    "ExportFormat",
    "SaaraDashboard",
]

_LAZY_IMPORTS = {
    "DatasetBuilder": ("saara.dataset.builder", "DatasetBuilder"),
    "DataType": ("saara.dataset.types", "DataType"),
    "DatasetFormat": ("saara.dataset.types", "DatasetFormat"),
    "FineTuner": ("saara.training.finetuner", "FineTuner"),
    "TrainingConfig": ("saara.training.config", "TrainingConfig"),
    "ModelEvaluator": ("saara.evaluation.evaluator", "ModelEvaluator"),
    "ModelExporter": ("saara.export.exporter", "ModelExporter"),
    "ModelProvider": ("saara.providers.base", "ModelProvider"),
    "ProviderConfig": ("saara.providers.base", "ProviderConfig"),
    "DemoProvider": ("saara.providers.demo_provider", "DemoProvider"),
    "VLLMProvider": ("saara.providers.vllm_provider", "VLLMProvider"),
    "OllamaProvider": ("saara.providers.ollama_provider", "OllamaProvider"),
    "LlamaCppProvider": ("saara.providers.llamacpp_provider", "LlamaCppProvider"),
    "QuantizationConfig": ("saara.export.quantization", "QuantizationConfig"),
    "ExportFormat": ("saara.export.formats", "ExportFormat"),
    "SaaraDashboard": ("saara.gui.dashboard", "SaaraDashboard"),
}


def __getattr__(name: str):
    if name not in _LAZY_IMPORTS:
        raise AttributeError(f"module 'saara' has no attribute {name!r}")

    module_name, attr_name = _LAZY_IMPORTS[name]
    module = import_module(module_name)
    value = getattr(module, attr_name)
    globals()[name] = value
    return value
