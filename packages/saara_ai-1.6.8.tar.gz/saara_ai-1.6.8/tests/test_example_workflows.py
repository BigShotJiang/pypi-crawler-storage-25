"""Executable tests for the example workflow scripts."""

from __future__ import annotations

import importlib.util
from pathlib import Path

import pytest

from saara.dataset.types import DataSample


ROOT = Path(__file__).resolve().parents[1]
EXAMPLES = ROOT / "examples"


def load_example(filename: str):
    """Load numeric example scripts as regular Python modules."""
    module_name = f"example_{Path(filename).stem}"
    spec = importlib.util.spec_from_file_location(module_name, EXAMPLES / filename)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


class DummyProvider:
    def __init__(self, config):
        self.config = config


class DummyBuilder:
    instances = []

    def __init__(self, provider, output_dir="./output", output_format=None):
        self.provider = provider
        self.output_dir = output_dir
        self.output_format = output_format
        self.calls = []
        self.saved = []
        DummyBuilder.instances.append(self)

    def from_pdf(self, pdf_path, **kwargs):
        self.calls.append(("from_pdf", pdf_path, kwargs))
        return []

    def from_text(self, text, **kwargs):
        self.calls.append(("from_text", text, kwargs))
        return [
            DataSample(
                instruction="Explain edge deployment.",
                output="Edge deployment runs inference close to users or devices.",
                quality_score=1.0,
            )
        ]

    def save(self, samples, filename, format=None):
        self.saved.append((samples, filename, format))
        return f"/tmp/{filename}"


class DummyFineTuner:
    instances = []

    def __init__(self, config, callbacks=None):
        self.config = config
        self.callbacks = callbacks or []
        self.trained_dataset = None
        DummyFineTuner.instances.append(self)

    def train(self, dataset, validation_split=0.1):
        self.trained_dataset = dataset
        return {"metrics": {"loss": 0.0}, "state": 1}

    def save(self, output_dir):
        return output_dir


class DummyMetrics:
    accuracy = 0.0
    mmlu_score = 0.0
    gsm8k_score = 0.0
    humaneval_score = 0.0
    tokens_per_second = 0.0
    teacher_agreement = 0.0
    hallucination_rate = 0.0

    def summary(self):
        return "No evaluation samples were available."


class DummyEvaluator:
    instances = []

    def __init__(self, student_provider, teacher_provider=None):
        self.student_provider = student_provider
        self.teacher_provider = teacher_provider
        DummyEvaluator.instances.append(self)

    def evaluate(self, dataset, **kwargs):
        self.dataset = dataset
        self.kwargs = kwargs
        return DummyMetrics()


class DummyExporter:
    instances = []

    def __init__(self, model=None, tokenizer=None, config=None):
        self.model = model
        self.tokenizer = tokenizer
        self.config = config
        DummyExporter.instances.append(self)

    def export(self, output_dir, formats, quantize=True, run_benchmark=True):
        self.output_dir = output_dir
        self.formats = formats
        self.quantize = quantize
        self.run_benchmark = run_benchmark
        return {fmt.value: {"error": "missing optional exporter backend"} for fmt in formats}


class DummyDashboard:
    instances = []

    def __init__(self):
        self.launch_args = None
        DummyDashboard.instances.append(self)

    def launch(self, **kwargs):
        self.launch_args = kwargs


@pytest.fixture(autouse=True)
def reset_dummy_state():
    DummyBuilder.instances.clear()
    DummyFineTuner.instances.clear()
    DummyEvaluator.instances.clear()
    DummyExporter.instances.clear()
    DummyDashboard.instances.clear()


def test_pdf_to_dataset_example_handles_empty_pdf_generation(monkeypatch):
    module = load_example("01_pdf_to_dataset.py")
    monkeypatch.setattr(module, "OllamaProvider", DummyProvider)
    monkeypatch.setattr(module, "DatasetBuilder", DummyBuilder)

    module.main()

    builder = DummyBuilder.instances[0]
    assert builder.saved[0][0] == []
    assert builder.calls[0][0] == "from_pdf"


def test_synthetic_data_example_saves_all_declared_formats(monkeypatch):
    module = load_example("02_synthetic_data.py")
    monkeypatch.setattr(module, "OllamaProvider", DummyProvider)
    monkeypatch.setattr(module, "DatasetBuilder", DummyBuilder)

    module.main()

    saved_formats = [saved_format.value for _, _, saved_format in DummyBuilder.instances[0].saved]
    assert saved_formats == ["alpaca", "chatml", "jsonl"]


def test_finetune_example_runs_with_empty_metrics(monkeypatch):
    module = load_example("03_finetune.py")
    monkeypatch.setattr(module, "FineTuner", DummyFineTuner)

    module.main()

    finetuner = DummyFineTuner.instances[0]
    assert finetuner.trained_dataset == "output/datasets/dataset.jsonl"
    assert finetuner.callbacks


def test_evaluate_example_handles_empty_dataset_metrics(monkeypatch):
    module = load_example("04_evaluate.py")
    monkeypatch.setattr(module, "OllamaProvider", DummyProvider)
    monkeypatch.setattr(module, "ModelEvaluator", DummyEvaluator)

    module.main()

    evaluator = DummyEvaluator.instances[0]
    assert evaluator.dataset == "output/datasets/test.jsonl"
    assert evaluator.kwargs["benchmark_names"] == ["mmlu", "gsm8k", "humaneval"]


def test_export_example_reports_backend_errors_without_crashing(monkeypatch):
    module = load_example("05_export.py")
    monkeypatch.setattr(module, "ModelExporter", DummyExporter)

    module.main()

    exporter = DummyExporter.instances[0]
    assert exporter.quantize is True
    assert [fmt.value for fmt in exporter.formats] == ["safetensors", "gguf", "awq", "onnx"]


def test_complete_pipeline_passes_quantization_config_to_exporter(monkeypatch):
    module = load_example("06_complete_pipeline.py")
    monkeypatch.setattr(module, "OllamaProvider", DummyProvider)
    monkeypatch.setattr(module, "DatasetBuilder", DummyBuilder)
    monkeypatch.setattr(module, "FineTuner", DummyFineTuner)
    monkeypatch.setattr(module, "ModelEvaluator", DummyEvaluator)
    monkeypatch.setattr(module, "ModelExporter", DummyExporter)

    module.main()

    exporter = DummyExporter.instances[0]
    assert exporter.model == "./output/models/final"
    assert exporter.config.bits == 4
    assert exporter.tokenizer is None


def test_gui_example_delegates_launch_without_starting_server(monkeypatch):
    module = load_example("07_gui.py")
    monkeypatch.setattr(module, "SaaraDashboard", DummyDashboard)

    module.main()

    assert DummyDashboard.instances[0].launch_args == {"share": False, "server_port": 7860}


def test_chunk_text_rejects_non_advancing_overlap():
    from saara.dataset.builder import DatasetBuilder
    from saara.providers import DemoProvider, ProviderConfig

    builder = DatasetBuilder(DemoProvider(ProviderConfig(model="demo")))

    with pytest.raises(ValueError, match="chunk_overlap must be smaller"):
        builder._chunk_text("abcdef", chunk_size=3, chunk_overlap=3)


def test_chunk_text_omits_empty_whitespace_chunks():
    from saara.dataset.builder import DatasetBuilder
    from saara.providers import DemoProvider, ProviderConfig

    builder = DatasetBuilder(DemoProvider(ProviderConfig(model="demo")))

    assert builder._chunk_text("   ", chunk_size=3, chunk_overlap=0) == []
