"""Tests for SAARA package."""

import pytest
from pathlib import Path


class TestProviders:
    """Test model providers."""

    def test_provider_config_creation(self):
        from saara.providers.base import ProviderConfig

        config = ProviderConfig(model="mistral")
        assert config.model == "mistral"
        assert config.max_tokens == 2048

    def test_ollama_provider_initialization(self):
        from saara.providers.ollama_provider import OllamaProvider, ProviderConfig

        config = ProviderConfig(model="mistral")
        provider = OllamaProvider(config)

        assert provider.config.model == "mistral"
        assert provider._initialized == False


class TestDataset:
    """Test dataset creation."""

    def test_data_types_enum(self):
        from saara.dataset.types import DataType

        assert DataType.FACTUAL.value == "factual"
        assert DataType.INSTRUCTION.value == "instruction"

    def test_dataset_format_enum(self):
        from saara.dataset.types import DatasetFormat

        assert DatasetFormat.ALPACA.value == "alpaca"
        assert DatasetFormat.JSONL.value == "jsonl"

    def test_data_sample_creation(self):
        from saara.dataset.types import DataSample, DataType

        sample = DataSample(
            instruction="What is AI?",
            output="Artificial Intelligence",
            data_type=DataType.FACTUAL,
        )

        assert sample.instruction == "What is AI?"
        assert sample.data_type == DataType.FACTUAL

    def test_data_sample_to_dict(self):
        from saara.dataset.types import DataSample

        sample = DataSample(
            instruction="Test",
            output="Response",
        )

        d = sample.to_dict()
        assert "instruction" in d
        assert "output" in d


class TestTraining:
    """Test training components."""

    def test_training_config_defaults(self):
        from saara.training.config import TrainingConfig

        config = TrainingConfig()

        assert config.model_name == "mistralai/Mistral-7B-v0.1"
        assert config.use_lora == True
        assert config.lora_r == 16
        assert config.num_train_epochs == 3

    def test_training_config_custom(self):
        from saara.training.config import TrainingConfig

        config = TrainingConfig(
            model_name="test-model",
            num_train_epochs=5,
            lora_r=32,
        )

        assert config.model_name == "test-model"
        assert config.num_train_epochs == 5
        assert config.lora_r == 32


class TestEvaluation:
    """Test evaluation components."""

    def test_metrics_creation(self):
        from saara.evaluation.metrics import EvaluationMetrics

        metrics = EvaluationMetrics(
            accuracy=0.95,
            mmlu_score=78.5,
        )

        assert metrics.accuracy == 0.95
        assert metrics.mmlu_score == 78.5

    def test_metrics_to_dict(self):
        from saara.evaluation.metrics import EvaluationMetrics

        metrics = EvaluationMetrics(accuracy=0.9)
        d = metrics.to_dict()

        assert "accuracy" in d
        assert d["accuracy"] == 0.9

    def test_benchmark_suite_available(self):
        from saara.evaluation.benchmarks import BenchmarkSuite

        suite = BenchmarkSuite()
        benchmarks = suite.get_available_benchmarks()

        assert "mmlu" in benchmarks
        assert "gsm8k" in benchmarks


class TestExport:
    """Test export components."""

    def test_export_format_enum(self):
        from saara.export.formats import ExportFormat

        assert ExportFormat.SAFETENSORS.value == "safetensors"
        assert ExportFormat.GGUF.value == "gguf"
        assert ExportFormat.AWQ.value == "awq"

    def test_quantization_config_defaults(self):
        from saara.export.quantization import QuantizationConfig

        config = QuantizationConfig()

        assert config.bits == 4
        assert config.method == "awq"
        assert config.group_size == 128

    def test_quantization_config_invalid_bits(self):
        from saara.export.quantization import QuantizationConfig

        with pytest.raises(ValueError):
            QuantizationConfig(bits=5)

    def test_quantization_config_invalid_method(self):
        from saara.export.quantization import QuantizationConfig

        with pytest.raises(ValueError):
            QuantizationConfig(method="invalid")


class TestUtils:
    """Test utility functions."""

    def test_save_load_jsonl(self, tmp_path):
        from saara.utils.io import save_jsonl, load_jsonl

        data = [
            {"instruction": "Q1", "output": "A1"},
            {"instruction": "Q2", "output": "A2"},
        ]

        path = tmp_path / "test.jsonl"
        save_jsonl(data, str(path))

        loaded = load_jsonl(str(path))
        assert len(loaded) == 2
        assert loaded[0]["instruction"] == "Q1"

    def test_get_logger(self):
        from saara.utils.logging import get_logger

        logger = get_logger("test")
        assert logger.name == "test"


class TestIntegration:
    """Integration tests."""

    def test_import_package(self):
        """Test that the top-level package imports without optional stacks."""
        import saara

        assert saara.__version__
        assert "DatasetBuilder" in saara.__all__
        assert "ModelExporter" in saara.__all__

    def test_import_providers(self):
        """Test provider imports."""
        from saara.providers import (
            ModelProvider,
            VLLMProvider,
            OllamaProvider,
            LlamaCppProvider,
        )

        assert all(
            [
                ModelProvider,
                VLLMProvider,
                OllamaProvider,
                LlamaCppProvider,
            ]
        )

    def test_import_dataset(self):
        """Test dataset module imports."""
        from saara.dataset import (
            DatasetBuilder,
            PDFExtractor,
            SyntheticDataGenerator,
            DataType,
            DatasetFormat,
        )

        assert all(
            [
                DatasetBuilder,
                PDFExtractor,
                SyntheticDataGenerator,
                DataType,
                DatasetFormat,
            ]
        )

    def test_lazy_top_level_imports_for_light_components(self):
        """Test lazy resolution for light top-level exports."""
        from saara import DatasetBuilder, ModelProvider

        assert DatasetBuilder is not None
        assert ModelProvider is not None

    def test_core_compatibility_imports(self):
        """Test backward-compatible notebook imports."""
        from saara.core import DatasetBuilder, ProviderConfig

        assert DatasetBuilder is not None
        assert ProviderConfig is not None

    def test_enums_compatibility_imports(self):
        """Test backward-compatible enums imports."""
        from saara.enums import DataType, DatasetFormat, ExportFormat

        assert DataType.INSTRUCTION.value == "instruction"
        assert DatasetFormat.JSONL.value == "jsonl"
        assert ExportFormat.GGUF.value == "gguf"

    def test_demo_provider_imports(self):
        """Test demo provider for notebook-safe execution."""
        from saara.providers import DemoProvider, ProviderConfig

        provider = DemoProvider(ProviderConfig(model="demo"))
        response = provider.generate("test prompt")

        assert response.text
        assert response.finish_reason == "stop"
