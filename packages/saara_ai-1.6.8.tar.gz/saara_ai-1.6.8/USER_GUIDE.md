# SAARA User Guide

## Overview

SAARA helps you build a practical local LLM pipeline around five stages:

1. Ingest source material.
2. Generate training data.
3. Fine-tune a model.
4. Evaluate quality and performance.
5. Export the model for deployment.

The package exposes the same workflow through Python, CLI, and Gradio.

## Installation

### From PyPI

```bash
pip install saara-ai
```

Useful extras:

```bash
pip install "saara-ai[training]"
pip install "saara-ai[export]"
pip install "saara-ai[providers,training,evaluation,export]"
```

### From Source

```bash
git clone https://github.com/nikhil49023/saara-ai.git
cd saara-ai
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
```

### Optional Extras

```bash
pip install -e ".[dev]"
pip install -e ".[edge]"
pip install -e ".[providers,training,evaluation,export]"
```

The base install avoids pulling in every heavyweight compiled ML dependency. Add extras only for the features you need.

## Local Provider Setup

SAARA is currently best suited to local and self-hosted providers.

### Ollama

Install Ollama, pull a model, and keep the local server running.

```bash
ollama pull mistral
ollama serve
```

Python setup:

```python
from saara.providers.ollama_provider import OllamaProvider, ProviderConfig

provider = OllamaProvider(
    ProviderConfig(model="mistral", base_url="http://localhost:11434")
)
```

### vLLM

Use `VLLMProvider` when you have a CUDA machine and want higher-throughput local inference.

```python
from saara.providers.vllm_provider import VLLMProvider
from saara.providers.base import ProviderConfig

provider = VLLMProvider(
    ProviderConfig(
        model="meta-llama/Meta-Llama-3-8B-Instruct",
        max_tokens=1024,
        tensor_parallel_size=1,
    )
)
```

### llama.cpp

Use `LlamaCppProvider` when you want local CPU or edge-friendly inference from a GGUF model.

```python
from saara.providers.llamacpp_provider import LlamaCppProvider
from saara.providers.base import ProviderConfig

provider = LlamaCppProvider(ProviderConfig(model="./models/model.gguf"))
```

## Workflow 1: PDF to Dataset

```python
from saara import DatasetBuilder
from saara.dataset.types import DataType

builder = DatasetBuilder(provider)
samples = builder.from_pdf(
    "paper.pdf",
    data_types=[DataType.INSTRUCTION, DataType.FACTUAL, DataType.REASONING],
    pairs_per_type=4,
    chunk_size=2000,
    chunk_overlap=200,
    min_quality=0.65,
)

builder.save(samples, "paper_dataset.jsonl")
```

### Supported Data Types

- `DataType.FACTUAL`
- `DataType.REASONING`
- `DataType.CONVERSATIONAL`
- `DataType.INSTRUCTION`
- `DataType.CODE`
- `DataType.CREATIVE`

### Supported Output Formats

- `DatasetFormat.ALPACA`
- `DatasetFormat.CHATML`
- `DatasetFormat.SHAREGPT`
- `DatasetFormat.DPO`
- `DatasetFormat.COMPLETION`
- `DatasetFormat.JSONL`

## Workflow 2: Generate Synthetic Data from Raw Text

```python
from saara import DatasetBuilder
from saara.dataset.types import DataType

text = """
Transformers are neural network architectures designed for sequence modeling.
They rely on attention mechanisms instead of recurrent computation.
"""

builder = DatasetBuilder(provider)
samples = builder.from_text(
    text,
    data_types=[DataType.FACTUAL, DataType.INSTRUCTION],
    pairs_per_type=3,
    min_quality=0.7,
)
```

## Workflow 3: Fine-Tuning

```python
from saara import FineTuner
from saara.training.config import TrainingConfig

config = TrainingConfig(
    model_name="mistralai/Mistral-7B-v0.1",
    num_train_epochs=3,
    per_device_train_batch_size=2,
    gradient_accumulation_steps=4,
    learning_rate=2e-4,
    use_lora=True,
    output_dir="./output/training",
)

finetuner = FineTuner(config)
result = finetuner.train("paper_dataset.jsonl")
model_path = finetuner.save("./output/models/final")
```

### Fine-Tuning Notes

- Start with LoRA or QLoRA before trying full fine-tuning.
- Use smaller batch sizes on limited VRAM.
- Keep sequence length conservative until the pipeline is stable.
- Treat Unsloth, TRL, and quantization dependencies as optional heavy dependencies.

## Workflow 4: Evaluation

```python
from saara import ModelEvaluator
from saara.providers.ollama_provider import OllamaProvider, ProviderConfig

student = OllamaProvider(ProviderConfig(model="student-model"))
teacher = OllamaProvider(ProviderConfig(model="teacher-model"))

evaluator = ModelEvaluator(student, teacher)
metrics = evaluator.evaluate(
    dataset="test.jsonl",
    run_benchmarks=True,
    benchmark_names=["mmlu", "gsm8k"],
    measure_performance=True,
    measure_power=False,
)

print(metrics.summary())
```

### What Evaluation Can Measure

- Accuracy on your dataset
- Benchmark scores such as `mmlu`, `gsm8k`, and `humaneval`
- Latency and tokens per second
- Peak memory usage
- Optional teacher agreement and hallucination rate
- Optional power and carbon estimates when compatible tools are installed

## Workflow 5: Export and Quantization

```python
from saara import ModelExporter
from saara.export.formats import ExportFormat
from saara.export.quantization import QuantizationConfig

exporter = ModelExporter(
    model="./output/models/final",
    config=QuantizationConfig(bits=4, method="awq"),
)

results = exporter.export(
    output_dir="./output/exports",
    formats=[
        ExportFormat.SAFETENSORS,
        ExportFormat.GGUF,
        ExportFormat.AWQ,
        ExportFormat.ONNX,
    ],
    quantize=True,
)
```

### Export Targets

- `safetensors` for Hugging Face-style artifacts
- `GGUF` for llama.cpp and CPU-friendly deployments
- `AWQ` and `GPTQ` for quantized GPU inference
- `ONNX` for broader runtime compatibility
- `TensorRT` for NVIDIA edge deployments

## CLI Guide

### Dataset Creation

```bash
saara dataset from-pdf document.pdf -o ./output --data-types instruction factual
saara dataset from-text source.txt -o ./output --data-types reasoning instruction
```

### Fine-Tuning

```bash
saara train finetune dataset.jsonl --model mistralai/Mistral-7B-v0.1 --epochs 3
```

### Evaluation

```bash
saara eval model test.jsonl --model mistral --teacher llama-3-70b --benchmarks mmlu gsm8k
```

### Export

```bash
saara export model ./models/final --formats gguf awq --quantize --bits 4
```

### GUI

```bash
saara gui --port 7860
```

## Gradio Guide

Launch the dashboard:

```bash
saara gui
```

The dashboard exposes tabs for:

- dataset creation
- fine-tuning
- evaluation
- export
- code view

Use the GUI when you want a guided visual workflow. Use Python or CLI when you want scripting and repeatability.

## Suggested First Project

1. Start with Ollama and one small local model.
2. Generate a small dataset from one PDF.
3. Inspect the generated samples manually.
4. Fine-tune with LoRA only.
5. Evaluate on a small hand-written validation set.
6. Export to `GGUF` and `safetensors` first.

## Troubleshooting

### Import Errors for Heavy Dependencies

Some SAARA modules rely on optional packages such as `vllm`, `unsloth`, `trl`, `autoawq`, `auto-gptq`, `onnx`, and `tensorrt`.

Install only the parts you need first, then add the heavier stacks later.

### PyPI Installation in Managed Python Environments

If your OS blocks system-wide `pip install`, use a virtual environment:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install saara-ai
```

### Ollama Connection Issues

Check that the Ollama service is running and that the model exists:

```bash
ollama serve
ollama list
```

### GPU Memory Issues

- reduce batch size
- reduce sequence length
- use 4-bit loading
- prefer LoRA or QLoRA
- test on a smaller base model first

## Reference

- Package overview: [README.md](README.md)
- Package layout: [PACKAGE_STRUCTURE.md](PACKAGE_STRUCTURE.md)
- Examples: [`examples/`](examples)
- Demo notebook: [`examples/08_saara_demo_notebook.ipynb`](examples/08_saara_demo_notebook.ipynb)
- Edge AI demo notebook: [`examples/09_edge_ai_solutions_gemma_vllm.ipynb`](examples/09_edge_ai_solutions_gemma_vllm.ipynb)
- Fine-tuning notebook: [`examples/10_finetune_workflow_notebook.ipynb`](examples/10_finetune_workflow_notebook.ipynb)
- Evaluation notebook: [`examples/11_evaluation_workflow_notebook.ipynb`](examples/11_evaluation_workflow_notebook.ipynb)
- Export notebook: [`examples/12_export_workflow_notebook.ipynb`](examples/12_export_workflow_notebook.ipynb)
- GUI notebook: [`examples/13_gui_workflow_notebook.ipynb`](examples/13_gui_workflow_notebook.ipynb)
