"""Example: Launch Gradio GUI."""

from saara import SaaraDashboard


def main():
    print("🚀 Launching SAARA GUI...")
    print("   Open http://localhost:7860 in your browser")

    dashboard = SaaraDashboard()
    dashboard.launch(share=False, server_port=7860)


if __name__ == "__main__":
    main()
