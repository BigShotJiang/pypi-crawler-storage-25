"""Example: Generate synthetic data."""

from saara import DatasetBuilder
from saara.dataset.types import DataType, DatasetFormat
from saara.providers.ollama_provider import OllamaProvider, ProviderConfig


def main():
    # Setup provider
    config = ProviderConfig(model="mistral")
    provider = OllamaProvider(config)

    # Sample text
    text = """
    Machine learning is a subset of artificial intelligence that enables systems
    to learn and improve from experience without being explicitly programmed.
    It focuses on developing computer programs that can access data and use it
    to learn for themselves. The process begins with observations or data,
    such as examples, direct experience, or instruction, to look for patterns
    in data and make better decisions in the future.
    """

    # Create builder
    builder = DatasetBuilder(provider)

    # Generate synthetic data
    print("🤖 Generating synthetic data...")
    samples = builder.from_text(
        text=text,
        data_types=[
            DataType.FACTUAL,
            DataType.REASONING,
            DataType.CONVERSATIONAL,
            DataType.INSTRUCTION,
        ],
        pairs_per_type=3,
        min_quality=0.7,
    )

    print(f"✅ Generated {len(samples)} high-quality samples")

    # Save in different formats
    builder.save(samples, "synthetic_alpaca.json", format=DatasetFormat.ALPACA)
    builder.save(samples, "synthetic_chatml.json", format=DatasetFormat.CHATML)
    builder.save(samples, "synthetic.jsonl", format=DatasetFormat.JSONL)

    print("📁 Saved datasets in multiple formats")


if __name__ == "__main__":
    main()
