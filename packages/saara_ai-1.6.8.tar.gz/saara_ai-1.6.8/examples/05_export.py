"""Example: Export and quantize model."""

from saara import ModelExporter
from saara.export.formats import ExportFormat
from saara.export.quantization import QuantizationConfig


def main():
    # Configure quantization
    config = QuantizationConfig(
        bits=4,
        method="awq",
        group_size=128,
        validate=True,
    )

    # Create exporter
    exporter = ModelExporter(
        model="./output/models/my-finetune/final",
        config=config,
    )

    # Export to multiple formats
    print("📦 Exporting model...")
    results = exporter.export(
        output_dir="./output/exports",
        formats=[
            ExportFormat.SAFETENSORS,
            ExportFormat.GGUF,
            ExportFormat.AWQ,
            ExportFormat.ONNX,
        ],
        quantize=True,
        run_benchmark=True,
    )

    # Print results
    print("\n✅ Export completed!")
    print("\n📊 Export Summary:")

    for fmt, result in results.items():
        if "error" in result:
            print(f"  ❌ {fmt.upper()}: {result['error']}")
        else:
            print(f"  ✅ {fmt.upper()}: {result['size_mb']:.1f} MB")

    # Compare formats
    print("\n📈 Size Comparison:")
    for fmt, result in results.items():
        if "size_mb" in result:
            print(f"  {fmt.upper():12} {result['size_mb']:8.1f} MB")


if __name__ == "__main__":
    main()
