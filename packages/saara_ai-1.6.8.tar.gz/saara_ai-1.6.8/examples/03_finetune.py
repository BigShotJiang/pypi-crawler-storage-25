"""Example: Fine-tune a model."""

from saara import FineTuner
from saara.training.config import TrainingConfig
from saara.training.callbacks import ProgressCallback


def main():
    # Configure training
    config = TrainingConfig(
        model_name="mistralai/Mistral-7B-v0.1",
        num_train_epochs=3,
        per_device_train_batch_size=2,
        gradient_accumulation_steps=4,
        learning_rate=2e-4,
        use_lora=True,
        lora_r=16,
        lora_alpha=32,
        output_dir="./output/models/my-finetune",
    )

    # Setup callback
    progress = ProgressCallback()

    # Create finetuner
    finetuner = FineTuner(config, callbacks=[progress])

    # Train
    print("🎯 Starting fine-tuning...")
    result = finetuner.train(
        dataset="output/datasets/dataset.jsonl",
        validation_split=0.1,
    )

    print(f"✅ Training completed!")
    print(f"Metrics: {result['metrics']}")

    # Save model
    model_path = finetuner.save("./output/models/my-finetune/final")
    print(f"💾 Model saved to: {model_path}")

    # Optional: Push to HuggingFace
    # finetuner.push_to_hub("username/my-finetune")


if __name__ == "__main__":
    main()
