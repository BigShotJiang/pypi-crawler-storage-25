"""Example: Evaluate model with teacher comparison."""

from saara import ModelEvaluator
from saara.evaluation.benchmarks import BenchmarkSuite
from saara.providers.ollama_provider import OllamaProvider, ProviderConfig


def main():
    # Setup providers
    student_config = ProviderConfig(model="mistral-7b-finetuned")
    teacher_config = ProviderConfig(model="llama-3-70b")

    student_provider = OllamaProvider(student_config)
    teacher_provider = OllamaProvider(teacher_config)

    # Create evaluator
    evaluator = ModelEvaluator(
        student_provider=student_provider,
        teacher_provider=teacher_provider,
    )

    # Evaluate
    print("📈 Evaluating model...")
    metrics = evaluator.evaluate(
        dataset="output/datasets/test.jsonl",
        run_benchmarks=True,
        benchmark_names=["mmlu", "gsm8k", "humaneval"],
        measure_performance=True,
        measure_power=False,
    )

    # Print results
    print("\n" + metrics.summary())

    # Access individual metrics
    print(f"\n📊 Detailed Results:")
    print(f"  Accuracy: {metrics.accuracy:.2%}")
    print(f"  MMLU: {metrics.mmlu_score:.2f}")
    print(f"  GSM8K: {metrics.gsm8k_score:.2f}")
    print(f"  HumanEval: {metrics.humaneval_score:.2f}")
    print(f"  Speed: {metrics.tokens_per_second:.1f} tok/s")
    print(f"  Teacher Agreement: {metrics.teacher_agreement:.2%}")
    print(f"  Hallucination Rate: {metrics.hallucination_rate:.2%}")


if __name__ == "__main__":
    main()
