"""Example: Create dataset from PDF."""

from saara import DatasetBuilder
from saara.dataset.types import DataType, DatasetFormat
from saara.providers.ollama_provider import OllamaProvider, ProviderConfig


def main():
    # Setup provider
    config = ProviderConfig(
        model="mistral",
        base_url="http://localhost:11434",
    )
    provider = OllamaProvider(config)

    # Create dataset builder
    builder = DatasetBuilder(
        provider,
        output_dir="./output/datasets",
        output_format=DatasetFormat.ALPACA,
    )

    # Generate from PDF
    print("📊 Extracting from PDF...")
    samples = builder.from_pdf(
        pdf_path="document.pdf",
        data_types=[DataType.INSTRUCTION, DataType.FACTUAL, DataType.REASONING],
        pairs_per_type=5,
        chunk_size=2000,
        min_quality=0.65,
    )

    print(f"✅ Generated {len(samples)} samples")

    # Save dataset
    output_path = builder.save(samples, "dataset.jsonl")
    print(f"📁 Saved to: {output_path}")

    # Preview first sample
    if samples:
        print("\n📝 Sample:")
        print(f"Instruction: {samples[0].instruction}")
        print(f"Output: {samples[0].output}")


if __name__ == "__main__":
    main()
