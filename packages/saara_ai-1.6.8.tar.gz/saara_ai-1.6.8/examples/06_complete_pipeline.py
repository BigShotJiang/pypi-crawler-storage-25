"""Example: Complete end-to-end pipeline."""

from saara import DatasetBuilder, FineTuner, ModelEvaluator, ModelExporter
from saara.dataset.types import DataType, DatasetFormat
from saara.training.config import TrainingConfig
from saara.export.formats import ExportFormat
from saara.export.quantization import QuantizationConfig
from saara.providers.ollama_provider import OllamaProvider, ProviderConfig


def main():
    print("🚀 SAARA End-to-End Pipeline")
    print("=" * 50)

    # Step 1: Setup providers
    print("\n1️⃣  Setting up providers...")
    config = ProviderConfig(model="mistral")
    provider = OllamaProvider(config)

    # Step 2: Create dataset from PDF
    print("\n2️⃣  Creating dataset from PDF...")
    builder = DatasetBuilder(provider)

    samples = builder.from_pdf(
        "document.pdf",
        data_types=[DataType.INSTRUCTION, DataType.FACTUAL],
        pairs_per_type=5,
        min_quality=0.65,
    )

    dataset_path = builder.save(samples, "dataset.jsonl")
    print(f"   ✅ Generated {len(samples)} samples")

    # Step 3: Fine-tune model
    print("\n3️⃣  Fine-tuning model...")
    train_config = TrainingConfig(
        model_name="mistralai/Mistral-7B-v0.1",
        num_train_epochs=3,
        output_dir="./output/models/final",
    )

    finetuner = FineTuner(train_config)
    finetuner.train(dataset_path)
    model_path = finetuner.save("./output/models/final")
    print(f"   ✅ Model saved to {model_path}")

    # Step 4: Evaluate
    print("\n4️⃣  Evaluating model...")
    evaluator = ModelEvaluator(provider)

    metrics = evaluator.evaluate(
        dataset_path,
        run_benchmarks=True,
        benchmark_names=["mmlu"],
        measure_performance=True,
    )

    print(f"   {metrics.summary()}")

    # Step 5: Export
    print("\n5️⃣  Exporting model...")
    export_config = QuantizationConfig(bits=4)
    exporter = ModelExporter(model=model_path, config=export_config)

    results = exporter.export(
        "./output/exports",
        formats=[ExportFormat.SAFETENSORS, ExportFormat.GGUF],
        quantize=True,
    )

    print(f"   ✅ Exported to {len(results)} formats")

    print("\n" + "=" * 50)
    print("🎉 Pipeline completed successfully!")


if __name__ == "__main__":
    main()
