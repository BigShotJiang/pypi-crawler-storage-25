# SAARA Package Structure

```
saara_ai-1.6.4/
├── saara/                          # Main package
│   ├── __init__.py                 # Package exports
│   ├── version.py                  # Version information
│   │
│   ├── providers/                  # Model provider abstraction
│   │   ├── __init__.py
│   │   ├── base.py                 # Abstract base class (ModelProvider)
│   │   ├── vllm_provider.py        # vLLM GPU inference
│   │   ├── ollama_provider.py      # Ollama local inference
│   │   └── llamacpp_provider.py    # llama.cpp CPU/metal inference
│   │
│   ├── dataset/                    # Dataset creation
│   │   ├── __init__.py
│   │   ├── types.py                # DataType, DatasetFormat, DataSample
│   │   ├── pdf_extractor.py        # PDF text extraction
│   │   ├── synthetic_generator.py  # Synthetic data generation
│   │   └── builder.py              # DatasetBuilder orchestration
│   │
│   ├── training/                   # Fine-tuning pipelines
│   │   ├── __init__.py
│   │   ├── config.py               # TrainingConfig dataclass
│   │   ├── callbacks.py            # Training callbacks
│   │   └── finetuner.py            # FineTuner with QLoRA/LoRA
│   │
│   ├── evaluation/                 # Model evaluation
│   │   ├── __init__.py
│   │   ├── metrics.py              # EvaluationMetrics dataclass
│   │   ├── benchmarks.py           # BenchmarkSuite (MMLU, GSM8K, etc.)
│   │   └── evaluator.py            # ModelEvaluator with teacher-student
│   │
│   ├── export/                     # Model export & quantization
│   │   ├── __init__.py
│   │   ├── formats.py              # ExportFormat enum
│   │   ├── quantization.py         # QuantizationConfig
│   │   └── exporter.py             # ModelExporter (GGUF, AWQ, GPTQ, ONNX, TensorRT)
│   │
│   ├── gui/                        # Gradio GUI components
│   │   ├── __init__.py
│   │   ├── dashboard.py            # Main SaaraDashboard
│   │   └── components.py           # DatasetBuilderUI, TrainingMonitor, EvaluationDashboard
│   │
│   ├── cli/                        # Command-line interface
│   │   ├── __init__.py
│   │   └── main.py                 # Click-based CLI
│   │
│   └── utils/                      # Utilities
│       ├── __init__.py
│       ├── io.py                   # JSONL, YAML I/O
│       ├── logging.py              # Logging setup
│       └── memory.py               # GPU/CPU memory utilities
│
├── tests/                          # Test suite
│   └── test_saara.py               # Unit and integration tests
│
├── examples/                       # Example scripts
│   ├── 01_pdf_to_dataset.py
│   ├── 02_synthetic_data.py
│   ├── 03_finetune.py
│   ├── 04_evaluate.py
│   ├── 05_export.py
│   ├── 06_complete_pipeline.py
│   └── 07_gui.py
│
├── pyproject.toml                  # Package configuration
├── README.md                       # Documentation
├── LICENSE                         # MIT License
└── .venv/                          # Virtual environment (gitignored)
```

## Module Summary

### Providers (`saara.providers`)
- **ModelProvider** - Abstract base class for all providers
- **VLLMProvider** - High-throughput GPU inference with vLLM
- **OllamaProvider** - Simple local inference via Ollama
- **LlamaCppProvider** - CPU/metal inference with llama.cpp

### Dataset (`saara.dataset`)
- **DatasetBuilder** - Orchestrates dataset creation from PDFs or text
- **PDFExtractor** - Extract text from PDFs (PyMuPDF/pdfplumber backends)
- **SyntheticDataGenerator** - Generate synthetic data with LLMs
- **DataType** - Enum: FACTUAL, REASONING, CONVERSATIONAL, INSTRUCTION, CODE, CREATIVE
- **DatasetFormat** - Enum: ALPACA, CHATML, SHAREGPT, DPO, COMPLETION, JSONL

### Training (`saara.training`)
- **FineTuner** - QLoRA/LoRA fine-tuning using Unsloth and TRL
- **TrainingConfig** - Comprehensive training configuration
- **TrainingCallback** - Callback system for training monitoring

### Evaluation (`saara.evaluation`)
- **ModelEvaluator** - Comprehensive evaluation with teacher-student comparison
- **BenchmarkSuite** - Standard benchmarks (MMLU, GSM8K, HumanEval, etc.)
- **EvaluationMetrics** - Metrics container (accuracy, speed, power, hallucination rate)

### Export (`saara.export`)
- **ModelExporter** - Export to multiple formats
- **QuantizationConfig** - Quantization settings (2/3/4/8-bit)
- **ExportFormat** - Enum: SAFETENSORS, GGUF, AWQ, GPTQ, ONNX, TENSORRT, PYTORCH

### GUI (`saara.gui`)
- **SaaraDashboard** - Main Gradio dashboard with tabs
- **DatasetBuilderUI** - Visual dataset creation interface
- **TrainingMonitor** - Training progress visualization
- **EvaluationDashboard** - Evaluation metrics display

### CLI (`saara.cli`)
- **cli** - Click-based command-line interface
- Commands: `dataset`, `train`, `eval`, `export`, `gui`

### Utils (`saara.utils`)
- **I/O** - JSONL/YAML loading and saving
- **Logging** - Logging configuration
- **Memory** - GPU/CPU memory monitoring

## Key Features

1. **Opinionated defaults** - Works out of the box with sensible configurations
2. **Provider abstraction** - Switch between vLLM, Ollama, llama.cpp seamlessly
3. **Multiple export formats** - Deploy anywhere (edge, cloud, CPU, GPU)
4. **Teacher-student evaluation** - Compare fine-tuned models against larger teachers
5. **Power-aware metrics** - Track energy consumption and carbon footprint
6. **Gradio GUI** - Visual interface for the entire pipeline
7. **CLI support** - Scriptable command-line interface

## Usage Patterns

### Programmatic API
```python
from saara import DatasetBuilder, FineTuner, ModelEvaluator, ModelExporter
```

### CLI
```bash
saara dataset from-pdf document.pdf
saara train finetune dataset.jsonl
saara eval model test.jsonl
saara export model ./models/final
saara gui
```

### GUI
```python
from saara import SaaraDashboard
SaaraDashboard().launch()
```

## Documentation

- Overview: [README.md](README.md)
- End-user walkthrough: [USER_GUIDE.md](USER_GUIDE.md)
- Examples: [`examples/`](examples)

## Testing

```bash
# Run all tests
pytest tests/

# Run specific test class
pytest tests/test_saara.py::TestProviders

# Run with coverage
pytest tests/ --cov=saara
```
