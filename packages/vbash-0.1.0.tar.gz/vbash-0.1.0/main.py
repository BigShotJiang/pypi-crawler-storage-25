def main():
    print("Hello from vbash!")


if __name__ == "__main__":
    main()
