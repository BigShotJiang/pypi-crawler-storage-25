from fastapi.testclient import TestClient
import numpy as np

from image_archive.api.app import create_app
from image_archive.indexing.pipeline import IndexingPipeline
from image_archive.indexing.video import SelectedVideoFrame


def seed_assets(test_state, image_factory):
    library = test_state.root / "library"
    library.mkdir(exist_ok=True)
    image_factory("library/red.jpg", (255, 0, 0))
    image_factory("library/blue.jpg", (0, 0, 255))

    pipeline = IndexingPipeline(
        config=test_state.config,
        config_manager=test_state.config_manager,
        database=test_state.database,
        vector_store=test_state.vector_store,
        embedding_model=test_state.embedding_model,
        enrichment_model=test_state.enrichment_model,
    )
    pipeline.run([str(library)])


def test_text_search_endpoint_returns_ranked_results(test_state, image_factory) -> None:
    seed_assets(test_state, image_factory)
    app = create_app(
        config=test_state.config,
        database=test_state.database,
        vector_store=test_state.vector_store,
        embedding_model=test_state.embedding_model,
    )
    client = TestClient(app)

    response = client.post("/search/text", json={"query": "warm portrait", "top_k": 5})

    assert response.status_code == 200
    payload = response.json()
    assert payload["results"]
    assert "portrait" in payload["results"][0]["auto_tags"]


def test_similar_search_endpoint_uses_asset_embedding(test_state, image_factory) -> None:
    seed_assets(test_state, image_factory)
    app = create_app(
        config=test_state.config,
        database=test_state.database,
        vector_store=test_state.vector_store,
        embedding_model=test_state.embedding_model,
    )
    client = TestClient(app)

    red_asset = test_state.database.list_search_matches(["red"], limit=1)[0]
    response = client.post(
        "/search/similar",
        files={},
        data={"asset_id": str(red_asset["id"]), "top_k": "5"},
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["results"]
    assert payload["results"][0]["id"] != red_asset["id"]


def test_text_search_can_filter_by_content_type(test_state, image_factory) -> None:
    seed_assets(test_state, image_factory)
    app = create_app(
        config=test_state.config,
        database=test_state.database,
        vector_store=test_state.vector_store,
        embedding_model=test_state.embedding_model,
    )
    client = TestClient(app)

    response = client.post("/search/text", json={"query": "screen", "content_type": "screenshot", "top_k": 5})

    assert response.status_code == 200
    payload = response.json()
    assert payload["results"]
    assert all(item["content_type"] == "screenshot" for item in payload["results"])


def test_text_search_filters_weak_low_information_results(test_state, image_factory) -> None:
    library = test_state.root / "library"
    library.mkdir(exist_ok=True)
    image_factory("library/blank-slide.png", (180, 180, 180))

    pipeline = IndexingPipeline(
        config=test_state.config,
        config_manager=test_state.config_manager,
        database=test_state.database,
        vector_store=test_state.vector_store,
        embedding_model=test_state.embedding_model,
        enrichment_model=test_state.enrichment_model,
    )
    pipeline.run([str(library)])

    row = dict(test_state.database.get_asset_by_path(str(library / "blank-slide.png")))
    test_state.vector_store.vectors[int(row["id"])] = np.array([0.275, 0.0, 0.0, 0.0], dtype=np.float32)
    test_state.config.low_information_max_score = 0.30
    app = create_app(
        config=test_state.config,
        database=test_state.database,
        vector_store=test_state.vector_store,
        embedding_model=test_state.embedding_model,
    )
    client = TestClient(app)

    response = client.post("/search/text", json={"query": "warm", "top_k": 5})

    assert response.status_code == 200
    assert response.json()["results"] == []


def test_text_search_keeps_low_information_results_when_query_mentions_them(test_state, image_factory) -> None:
    library = test_state.root / "library"
    library.mkdir(exist_ok=True)
    image_factory("library/blank-slide.png", (180, 180, 180))

    pipeline = IndexingPipeline(
        config=test_state.config,
        config_manager=test_state.config_manager,
        database=test_state.database,
        vector_store=test_state.vector_store,
        embedding_model=test_state.embedding_model,
        enrichment_model=test_state.enrichment_model,
    )
    pipeline.run([str(library)])
    row = dict(test_state.database.get_asset_by_path(str(library / "blank-slide.png")))
    test_state.vector_store.vectors[int(row["id"])] = np.array([0.275, 0.0, 0.0, 0.0], dtype=np.float32)
    test_state.config.low_information_max_score = 0.30
    app = create_app(
        config=test_state.config,
        database=test_state.database,
        vector_store=test_state.vector_store,
        embedding_model=test_state.embedding_model,
    )
    client = TestClient(app)

    response = client.post("/search/text", json={"query": "warm slide", "top_k": 5})

    assert response.status_code == 200
    assert response.json()["results"]


def test_text_search_groups_video_frame_hits_by_source(test_state, image_factory, video_factory, monkeypatch) -> None:
    library = test_state.root / "library"
    library.mkdir(exist_ok=True)
    video_path = video_factory("library/clip.mp4", payload=b"video-source")
    frame_one = image_factory("frames/frame-a.jpg", (255, 0, 0))
    frame_two = image_factory("frames/frame-b.jpg", (250, 5, 5))

    monkeypatch.setattr(
        "image_archive.indexing.pipeline.VideoFrameSelector.select_frames",
        lambda _self, _path: [
            SelectedVideoFrame(
                asset_key=f"{video_path}#t=1000",
                source_path=video_path,
                frame_path=frame_one,
                timestamp_ms=1000,
                duration_ms=12_000,
                frame_index=1,
                selection_policy="tight",
                source_signature="video-signature",
            ),
            SelectedVideoFrame(
                asset_key=f"{video_path}#t=2000",
                source_path=video_path,
                frame_path=frame_two,
                timestamp_ms=2000,
                duration_ms=12_000,
                frame_index=2,
                selection_policy="tight",
                source_signature="video-signature",
            ),
        ],
    )

    pipeline = IndexingPipeline(
        config=test_state.config,
        config_manager=test_state.config_manager,
        database=test_state.database,
        vector_store=test_state.vector_store,
        embedding_model=test_state.embedding_model,
        enrichment_model=test_state.enrichment_model,
    )
    pipeline.run([str(library)])

    app = create_app(
        config=test_state.config,
        database=test_state.database,
        vector_store=test_state.vector_store,
        embedding_model=test_state.embedding_model,
    )
    client = TestClient(app)

    response = client.post("/search/text", json={"query": "warm portrait", "top_k": 5})

    assert response.status_code == 200
    payload = response.json()
    assert len(payload["results"]) == 1
    assert payload["results"][0]["asset_kind"] == "video_frame"
    assert payload["results"][0]["file_path"] == str(video_path)
    assert payload["results"][0]["timestamp_ms"] in {1000, 2000}


def test_video_frame_endpoints_serve_frame_and_source(test_state, image_factory, video_factory, monkeypatch) -> None:
    library = test_state.root / "library"
    library.mkdir(exist_ok=True)
    video_path = video_factory("library/clip.mp4", payload=b"video-source")
    frame_one = image_factory("frames/frame-a.jpg", (255, 0, 0))

    monkeypatch.setattr(
        "image_archive.indexing.pipeline.VideoFrameSelector.select_frames",
        lambda _self, _path: [
            SelectedVideoFrame(
                asset_key=f"{video_path}#t=1000",
                source_path=video_path,
                frame_path=frame_one,
                timestamp_ms=1000,
                duration_ms=12_000,
                frame_index=1,
                selection_policy="balanced",
                source_signature="video-signature",
            )
        ],
    )

    pipeline = IndexingPipeline(
        config=test_state.config,
        config_manager=test_state.config_manager,
        database=test_state.database,
        vector_store=test_state.vector_store,
        embedding_model=test_state.embedding_model,
        enrichment_model=test_state.enrichment_model,
    )
    pipeline.run([str(library)])
    row = test_state.database.list_assets_by_source_path(str(video_path))[0]

    app = create_app(
        config=test_state.config,
        database=test_state.database,
        vector_store=test_state.vector_store,
        embedding_model=test_state.embedding_model,
    )
    client = TestClient(app)

    frame_response = client.get(f"/assets/{row['id']}/image")
    source_response = client.get(f"/assets/{row['id']}/source")

    assert frame_response.status_code == 200
    assert frame_response.headers["content-type"].startswith("image/")
    assert source_response.status_code == 200
    assert source_response.content == b"video-source"
