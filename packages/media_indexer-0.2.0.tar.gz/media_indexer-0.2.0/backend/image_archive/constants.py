"""Project constants."""

from __future__ import annotations

SUPPORTED_IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png"}
SUPPORTED_VIDEO_EXTENSIONS = {".mp4", ".mov", ".m4v", ".avi", ".mkv", ".webm"}
SUPPORTED_EXTENSIONS = SUPPORTED_IMAGE_EXTENSIONS | SUPPORTED_VIDEO_EXTENSIONS
APP_NAME = "media-indexer"
DEFAULT_CONFIG_FILENAME = "config.yaml"
DEFAULT_PIPELINE_VERSION = "mvp-v2-video"
DEFAULT_EMBEDDING_DIMENSION = 512
