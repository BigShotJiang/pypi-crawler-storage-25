"""Incremental indexing pipeline."""

from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import numpy as np
from PIL import Image, ImageOps
from tqdm import tqdm

from image_archive.config import AppConfig, ConfigManager
from image_archive.constants import SUPPORTED_VIDEO_EXTENSIONS
from image_archive.db import Database, utc_now_iso
from image_archive.faiss_store import VectorStore
from image_archive.indexing.discovery import discover_media_files
from image_archive.indexing.fingerprint import file_sha256, stat_signature
from image_archive.indexing.metadata import AssetMetadata, extract_image_metadata, extract_video_frame_metadata
from image_archive.indexing.thumbnails import generate_thumbnail
from image_archive.indexing.video import VideoFrameSelector
from image_archive.models.base import EmbeddingModel, EnrichmentModel
from image_archive.types import EnrichmentResult, PipelineTimings


@dataclass
class PipelineStats:
    """Summary counters for an indexing run."""

    scanned: int = 0
    planned: int = 0
    indexed: int = 0
    skipped: int = 0
    failed: int = 0
    timings: PipelineTimings = field(default_factory=PipelineTimings)

    @property
    def avg_ms_per_asset(self) -> float:
        if self.indexed <= 0:
            return 0.0
        return round((self.timings.total_seconds / self.indexed) * 1000.0, 2)


@dataclass
class PendingAsset:
    """A discovered asset with its current DB state and work flags."""

    asset_key: str
    source_path: Path
    asset_kind: str
    existing: Optional[dict]
    signature: str
    frame_path: Optional[Path]
    timestamp_ms: Optional[int]
    duration_ms: Optional[int]
    frame_index: Optional[int]
    selection_policy: Optional[str]
    needs_hash: bool
    needs_metadata: bool
    needs_thumbnail: bool
    needs_embedding: bool
    needs_enrichment: bool

    @property
    def needs_processing(self) -> bool:
        return any(
            [
                self.needs_hash,
                self.needs_metadata,
                self.needs_thumbnail,
                self.needs_embedding,
                self.needs_enrichment,
            ]
        )


@dataclass
class PreparedAsset:
    """In-memory prepared data for persistence."""

    pending: PendingAsset
    image: Optional[Image.Image]
    metadata: Optional[AssetMetadata]
    file_hash: Optional[str]
    thumbnail_path: Optional[str]
    embedding: Optional[np.ndarray]
    enrichment: Optional[EnrichmentResult]


def _row_to_dict(row: Optional[object]) -> Optional[dict[str, Any]]:
    if row is None:
        return None
    return dict(row)


class IndexingPipeline:
    """Incremental, resumable image indexing pipeline."""

    def __init__(
        self,
        *,
        config: AppConfig,
        config_manager: ConfigManager,
        database: Database,
        vector_store: VectorStore,
        embedding_model: EmbeddingModel,
        enrichment_model: EnrichmentModel,
    ) -> None:
        self.config = config
        self.config_manager = config_manager
        self.database = database
        self.vector_store = vector_store
        self.embedding_model = embedding_model
        self.enrichment_model = enrichment_model
        resolved = config_manager.ensure_directories(config)
        self.thumbnail_dir = resolved["thumbnail_dir"]
        self.video_selector = VideoFrameSelector(
            config=config,
            frame_cache_dir=resolved["frame_cache_dir"],
            embedding_model=embedding_model,
        )

    def run(self, paths: list[str]) -> PipelineStats:
        """Index one or more folders."""
        return self.run_with_options(paths)

    def run_with_options(self, paths: list[str], *, limit: Optional[int] = None) -> PipelineStats:
        """Index one or more folders with optional discovery limits."""

        target_paths = [str(Path(item).expanduser().resolve()) for item in paths]
        run_id = self.database.start_index_run(target_paths)
        stats = PipelineStats()
        status = "completed"
        try:
            scan_started = time.perf_counter()
            pending_assets = self._plan(target_paths, stats, limit=limit)
            stats.timings.scan_seconds += time.perf_counter() - scan_started
            stats.planned = len(pending_assets)
            tqdm.write(
                "Discovered "
                f"{stats.scanned} supported assets. "
                f"To process: {stats.planned}. "
                f"Already current: {stats.skipped}."
            )
            if pending_assets:
                self._process_pending(pending_assets, stats)
                self.vector_store.save()
        except KeyboardInterrupt:
            status = "interrupted"
            raise
        except Exception:
            status = "failed"
            raise
        finally:
            self.database.finish_index_run(
                run_id,
                status=status,
                num_scanned=stats.scanned,
                num_indexed=stats.indexed,
                num_skipped=stats.skipped,
                num_failed=stats.failed,
                timings=stats.timings.to_dict(),
                avg_ms_per_asset=stats.avg_ms_per_asset,
                throughput_per_min=stats.timings.throughput_per_minute(stats.indexed),
            )
        return stats

    def _plan(self, paths: list[str], stats: PipelineStats, *, limit: Optional[int] = None) -> list[PendingAsset]:
        candidates = discover_media_files(
            paths,
            excluded_dir_names=self.config.excluded_dir_names,
            excluded_path_fragments=self.config.excluded_path_fragments,
        )
        if limit is not None and limit >= 0:
            candidates = candidates[:limit]
        pending: list[PendingAsset] = []

        for file_path in tqdm(candidates, desc="Scanning", unit="file"):
            stats.scanned += 1
            if file_path.suffix.lower() in SUPPORTED_VIDEO_EXTENSIONS and self.config.video_enabled:
                tqdm.write(f"Video scan: selecting representative frames from {file_path.name}")
                pending.extend(self._plan_video(file_path, stats))
                continue

            item = self._build_pending_asset(
                asset_key=str(file_path),
                source_path=file_path,
                asset_kind="image",
                signature=stat_signature(file_path),
            )
            if item.needs_processing:
                pending.append(item)
            else:
                stats.skipped += 1
        return pending

    def _build_pending_asset(
        self,
        *,
        asset_key: str,
        source_path: Path,
        asset_kind: str,
        signature: str,
        frame_path: Optional[Path] = None,
        timestamp_ms: Optional[int] = None,
        duration_ms: Optional[int] = None,
        frame_index: Optional[int] = None,
        selection_policy: Optional[str] = None,
    ) -> PendingAsset:
        existing = _row_to_dict(self.database.get_asset_by_path(asset_key))
        changed = existing is None or existing.get("stat_signature") != signature

        thumbnail_exists = bool(existing and existing.get("thumbnail_path") and Path(existing["thumbnail_path"]).exists())
        has_enrichment = bool(existing and existing.get("enrichment_model") and existing.get("search_text"))
        enrichment_stale = bool(existing) and (
            existing.get("enrichment_model") != self.enrichment_model.model_name
            or existing.get("enrichment_version") != self.enrichment_model.enrichment_version
            or existing.get("enrichment_mode") != self.config.enrichment_mode
        )
        embedding_stale = bool(existing) and existing.get("embedding_model") != self.config.embedding_model_name
        needs_metadata = changed or not (
            existing and existing.get("width") and existing.get("height") and existing.get("modified_at")
        )
        needs_hash = changed or not (existing and existing.get("file_hash"))
        needs_thumbnail = changed or not thumbnail_exists
        needs_embedding = changed or not (existing and existing.get("vector_blob")) or embedding_stale
        needs_enrichment = changed or not has_enrichment or enrichment_stale
        stale_pipeline = bool(existing) and existing.get("pipeline_version") != self.config.pipeline_version
        if stale_pipeline:
            needs_metadata = True
            needs_thumbnail = True
            needs_embedding = True
            needs_enrichment = True

        return PendingAsset(
            asset_key=asset_key,
            source_path=source_path,
            asset_kind=asset_kind,
            existing=existing,
            signature=signature,
            frame_path=frame_path,
            timestamp_ms=timestamp_ms,
            duration_ms=duration_ms,
            frame_index=frame_index,
            selection_policy=selection_policy,
            needs_hash=needs_hash,
            needs_metadata=needs_metadata,
            needs_thumbnail=needs_thumbnail,
            needs_embedding=needs_embedding,
            needs_enrichment=needs_enrichment,
        )

    def _plan_video(self, source_path: Path, stats: PipelineStats) -> list[PendingAsset]:
        try:
            selected_frames = self.video_selector.select_frames(source_path)
        except Exception as exc:  # pragma: no cover - depends on local ffmpeg/runtime
            stats.failed += 1
            self.database.log_error(str(source_path), "video-select", str(exc))
            tqdm.write(f"Video scan: failed on {source_path.name} ({exc})")
            return []

        active_keys = {frame.asset_key for frame in selected_frames}
        self.database.mark_deleted_for_source_path_except(str(source_path), active_keys)
        policy = selected_frames[0].selection_policy if selected_frames else "none"
        tqdm.write(
            f"Video scan: selected {len(selected_frames)} frame"
            f"{'' if len(selected_frames) == 1 else 's'} from {source_path.name} using {policy} policy"
        )

        pending: list[PendingAsset] = []
        for frame in selected_frames:
            signature = f"{frame.source_signature}:{frame.timestamp_ms}:{frame.selection_policy}"
            item = self._build_pending_asset(
                asset_key=frame.asset_key,
                source_path=frame.source_path,
                asset_kind="video_frame",
                signature=signature,
                frame_path=frame.frame_path,
                timestamp_ms=frame.timestamp_ms,
                duration_ms=frame.duration_ms,
                frame_index=frame.frame_index,
                selection_policy=frame.selection_policy,
            )
            if item.needs_processing:
                pending.append(item)
            else:
                stats.skipped += 1
        return pending

    def _process_pending(self, pending_assets: list[PendingAsset], stats: PipelineStats) -> None:
        batch_size = max(int(self.config.batch_size), 1)
        overall = tqdm(total=len(pending_assets), desc="Indexing", unit="image")
        try:
            for start in range(0, len(pending_assets), batch_size):
                batch = pending_assets[start : start + batch_size]
                prep_started = time.perf_counter()
                prepared = self._prepare_batch(batch, stats)
                stats.timings.prep_seconds += time.perf_counter() - prep_started
                if not prepared:
                    continue

                embedding_targets = [item for item in prepared if item.pending.needs_embedding and item.image is not None]
                if embedding_targets:
                    embed_started = time.perf_counter()
                    try:
                        vectors = self.embedding_model.encode_images([item.image for item in embedding_targets])
                        for item, vector in zip(embedding_targets, vectors):
                            item.embedding = vector
                    except Exception as exc:  # pragma: no cover - depends on model backend
                        for item in embedding_targets:
                            stats.failed += 1
                            self.database.log_error(str(item.pending.source_path), "embedding", str(exc))
                    stats.timings.embedding_seconds += time.perf_counter() - embed_started

                enrichment_targets = [item for item in prepared if item.pending.needs_enrichment and item.image is not None]
                if enrichment_targets:
                    enrich_started = time.perf_counter()
                    self._enrich_batch(enrichment_targets, stats)
                    stats.timings.enrichment_seconds += time.perf_counter() - enrich_started

                persist_started = time.perf_counter()
                for item in tqdm(prepared, desc="Persisting", unit="asset", leave=False, position=1):
                    self._persist_prepared(item)
                    stats.indexed += 1
                    overall.update(1)
                    overall.set_postfix(indexed=f"{stats.indexed}/{stats.planned}", failed=stats.failed)
                stats.timings.persist_seconds += time.perf_counter() - persist_started

                for item in prepared:
                    if item.image is not None:
                        item.image.close()
        finally:
            overall.close()

    def _prepare_batch(self, batch: list[PendingAsset], stats: PipelineStats) -> list[PreparedAsset]:
        prepared_items: list[PreparedAsset] = []
        with ThreadPoolExecutor(max_workers=max(1, int(self.config.num_workers))) as executor:
            futures = {executor.submit(self._prepare_item, item): item for item in batch}
            for future in tqdm(futures, desc="Processing", unit="asset", leave=False, position=1):
                item = futures[future]
                try:
                    prepared_items.append(future.result())
                except Exception as exc:  # pragma: no cover - exercised indirectly
                    stats.failed += 1
                    self.database.log_error(str(item.source_path), "prepare", str(exc))
        return prepared_items

    def _enrich_batch(self, items: list[PreparedAsset], stats: PipelineStats) -> None:
        try:
            fast_results = self.enrichment_model.enrich_images([item.image for item in items if item.image is not None], mode="fast")
        except Exception as exc:  # pragma: no cover - depends on Ollama/runtime
            for item in items:
                stats.failed += 1
                self.database.log_error(str(item.pending.source_path), "enrichment-fast", str(exc))
            return

        for item, result in zip(items, fast_results):
            item.enrichment = result

        if self.config.enrichment_mode != "balanced":
            return

        detailed_items = [item for item in items if item.enrichment and item.enrichment.requires_document_pass()]
        if not detailed_items:
            return

        try:
            detailed_results = self.enrichment_model.enrich_images(
                [item.image for item in detailed_items if item.image is not None],
                mode="document",
            )
            for item, result in zip(detailed_items, detailed_results):
                assert item.enrichment is not None
                item.enrichment = item.enrichment.merge(result)
        except Exception as exc:  # pragma: no cover - depends on Ollama/runtime
            for item in detailed_items:
                stats.failed += 1
                self.database.log_error(str(item.pending.source_path), "enrichment-document", str(exc))

    def _persist_prepared(self, item: PreparedAsset) -> None:
        existing = item.pending.existing or {}
        metadata = item.metadata
        summary = item.enrichment.short_summary if item.enrichment else existing.get("short_summary") or existing.get("caption")
        payload = {
            "file_path": item.pending.asset_key,
            "asset_kind": item.pending.asset_kind,
            "source_path": metadata.source_path if metadata else existing.get("source_path"),
            "frame_path": metadata.frame_path if metadata else existing.get("frame_path"),
            "timestamp_ms": metadata.timestamp_ms if metadata else existing.get("timestamp_ms"),
            "duration_ms": metadata.duration_ms if metadata else existing.get("duration_ms"),
            "frame_index": metadata.frame_index if metadata else existing.get("frame_index"),
            "selection_policy": metadata.selection_policy if metadata else existing.get("selection_policy"),
            "file_hash": item.file_hash or existing.get("file_hash"),
            "file_type": metadata.file_type if metadata else existing.get("file_type"),
            "file_size": metadata.file_size if metadata else existing.get("file_size"),
            "width": metadata.width if metadata else existing.get("width"),
            "height": metadata.height if metadata else existing.get("height"),
            "created_at": metadata.created_at if metadata else existing.get("created_at"),
            "modified_at": metadata.modified_at if metadata else existing.get("modified_at"),
            "indexed_at": utc_now_iso(),
            "folder": metadata.folder if metadata else existing.get("folder"),
            "thumbnail_path": item.thumbnail_path or existing.get("thumbnail_path"),
            "caption": summary,
            "caption_model": self.enrichment_model.model_name if summary else existing.get("caption_model"),
            "stat_signature": item.pending.signature,
            "pipeline_version": self.config.pipeline_version,
            "is_deleted": 0,
        }

        asset_id = self.database.upsert_asset(payload)
        if item.pending.needs_embedding and item.embedding is not None:
            vector = np.asarray(item.embedding, dtype=np.float32)
            self.vector_store.add_or_update(asset_id, vector)
            self.database.upsert_embedding(
                asset_id,
                faiss_row_id=asset_id,
                embedding_model=self.config.embedding_model_name,
                embedding_dim=int(vector.shape[-1]),
                vector_blob=vector.astype(np.float32).tobytes(),
            )

        if item.pending.needs_enrichment and item.enrichment is not None:
            record = item.enrichment.to_record()
            self.database.upsert_enrichment(
                asset_id,
                {
                    **record,
                    "enrichment_model": self.enrichment_model.model_name,
                    "enrichment_version": self.enrichment_model.enrichment_version,
                    "enrichment_mode": self.config.enrichment_mode,
                    "enriched_at": utc_now_iso(),
                },
            )

    def _prepare_item(self, item: PendingAsset) -> PreparedAsset:
        existing = item.existing or {}
        needs_image = item.needs_embedding or item.needs_enrichment or item.needs_thumbnail
        image = None
        if needs_image:
            target_path = item.source_path if item.asset_kind == "image" else item.frame_path
            if target_path is None:
                raise ValueError(f"Missing frame path for {item.asset_key}")
            with Image.open(target_path) as opened:
                image = ImageOps.exif_transpose(opened).convert("RGB")

        metadata: Optional[AssetMetadata]
        if item.needs_metadata:
            if item.asset_kind == "image":
                metadata = extract_image_metadata(item.source_path)
            else:
                if image is None or item.frame_path is None or item.timestamp_ms is None or item.frame_index is None:
                    raise ValueError(f"Incomplete video frame state for {item.asset_key}")
                metadata = extract_video_frame_metadata(
                    item.source_path,
                    frame_path=item.frame_path,
                    width=image.width,
                    height=image.height,
                    timestamp_ms=item.timestamp_ms,
                    duration_ms=item.duration_ms,
                    frame_index=item.frame_index,
                    selection_policy=item.selection_policy or "balanced",
                )
        else:
            metadata = None

        if item.asset_kind == "image":
            file_hash = file_sha256(item.source_path) if item.needs_hash else existing.get("file_hash")
            thumbnail_source = item.source_path
        else:
            file_hash = f"video:{item.signature}" if item.needs_hash else existing.get("file_hash")
            thumbnail_source = item.frame_path
        thumbnail_path = (
            generate_thumbnail(
                thumbnail_source,
                self.thumbnail_dir,
                file_hash or existing.get("file_hash") or item.signature,
            )
            if item.needs_thumbnail and thumbnail_source is not None
            else existing.get("thumbnail_path")
        )
        return PreparedAsset(
            pending=item,
            image=image,
            metadata=metadata,
            file_hash=file_hash,
            thumbnail_path=thumbnail_path,
            embedding=None,
            enrichment=None,
        )
