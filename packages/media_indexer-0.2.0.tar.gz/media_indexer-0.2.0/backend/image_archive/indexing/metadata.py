"""Asset metadata extraction."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Union

from PIL import Image


def _timestamp_to_iso(value: Optional[float]) -> Optional[str]:
    if value is None:
        return None
    return datetime.fromtimestamp(value, tz=timezone.utc).isoformat()


@dataclass
class AssetMetadata:
    """Normalized metadata for an indexed asset."""

    asset_kind: str
    file_type: str
    file_size: int
    width: int
    height: int
    created_at: Optional[str]
    modified_at: Optional[str]
    folder: str
    source_path: Optional[str] = None
    frame_path: Optional[str] = None
    timestamp_ms: Optional[int] = None
    duration_ms: Optional[int] = None
    frame_index: Optional[int] = None
    selection_policy: Optional[str] = None


def extract_image_metadata(path: Union[str, Path]) -> AssetMetadata:
    """Read dimensions and filesystem timestamps."""

    file_path = Path(path).expanduser().resolve()
    stat = file_path.stat()
    with Image.open(file_path) as image:
        width, height = image.size

    created_raw = getattr(stat, "st_birthtime", None)
    modified_raw = getattr(stat, "st_mtime", None)
    return AssetMetadata(
        asset_kind="image",
        file_type=file_path.suffix.lower().lstrip("."),
        file_size=int(stat.st_size),
        width=int(width),
        height=int(height),
        created_at=_timestamp_to_iso(created_raw),
        modified_at=_timestamp_to_iso(modified_raw),
        folder=str(file_path.parent),
    )


def extract_video_frame_metadata(
    path: Union[str, Path],
    *,
    frame_path: Union[str, Path],
    width: int,
    height: int,
    timestamp_ms: int,
    duration_ms: Optional[int],
    frame_index: int,
    selection_policy: str,
) -> AssetMetadata:
    """Read video-backed frame metadata using the source video timestamps."""

    file_path = Path(path).expanduser().resolve()
    stat = file_path.stat()
    created_raw = getattr(stat, "st_birthtime", None)
    modified_raw = getattr(stat, "st_mtime", None)
    return AssetMetadata(
        asset_kind="video_frame",
        file_type=file_path.suffix.lower().lstrip("."),
        file_size=int(stat.st_size),
        width=int(width),
        height=int(height),
        created_at=_timestamp_to_iso(created_raw),
        modified_at=_timestamp_to_iso(modified_raw),
        folder=str(file_path.parent),
        source_path=str(file_path),
        frame_path=str(Path(frame_path).expanduser().resolve()),
        timestamp_ms=int(timestamp_ms),
        duration_ms=int(duration_ms) if duration_ms is not None else None,
        frame_index=int(frame_index),
        selection_policy=selection_policy,
    )
