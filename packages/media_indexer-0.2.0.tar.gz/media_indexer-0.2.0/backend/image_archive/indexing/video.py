"""Video probing and sparse representative frame selection."""

from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np
from PIL import Image

from image_archive.config import AppConfig
from image_archive.indexing.fingerprint import stat_signature
from image_archive.models.base import EmbeddingModel


@dataclass
class VideoProbe:
    duration_seconds: float
    width: int
    height: int
    fps: float


@dataclass
class VideoSelectionPolicy:
    name: str
    decode_stride_seconds: float
    min_gap_seconds: float
    max_gap_seconds: float
    semantic_threshold: float


@dataclass
class DecodedFrame:
    timestamp_ms: int
    frame_index: int
    temp_path: Path
    image: Image.Image
    quality_score: float
    visual_delta: float = 0.0
    scene_cut: bool = False
    embedding: Optional[np.ndarray] = None


@dataclass
class SelectedVideoFrame:
    asset_key: str
    source_path: Path
    frame_path: Path
    timestamp_ms: int
    duration_ms: int
    frame_index: int
    selection_policy: str
    source_signature: str


def ffmpeg_available() -> bool:
    return bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))


def _safe_open_image(path: Path) -> Image.Image:
    with Image.open(path) as opened:
        return opened.convert("RGB")


def _grayscale_array(image: Image.Image, *, size: tuple[int, int] = (64, 64)) -> np.ndarray:
    return np.asarray(image.resize(size).convert("L"), dtype=np.float32)


def _quality_score(image: Image.Image) -> float:
    gray = _grayscale_array(image)
    contrast = float(gray.std()) / 64.0
    edge_energy = float(np.abs(np.diff(gray, axis=0)).mean() + np.abs(np.diff(gray, axis=1)).mean()) / 64.0
    brightness = float(gray.mean()) / 255.0
    exposure_penalty = abs(brightness - 0.5) * 0.6
    return max(0.0, contrast * 0.45 + edge_energy * 0.75 - exposure_penalty)


def _visual_delta(previous: Image.Image, current: Image.Image) -> float:
    first = _grayscale_array(previous)
    second = _grayscale_array(current)
    mean_diff = float(np.abs(first - second).mean()) / 255.0
    std_diff = abs(float(first.std()) - float(second.std())) / 255.0
    return mean_diff * 0.75 + std_diff * 0.25


class VideoFrameSelector:
    """Adaptive sparse selector backed by ffmpeg frame extraction."""

    def __init__(
        self,
        *,
        config: AppConfig,
        frame_cache_dir: Path,
        embedding_model: EmbeddingModel,
    ) -> None:
        self.config = config
        self.frame_cache_dir = Path(frame_cache_dir).expanduser().resolve()
        self.embedding_model = embedding_model
        self.frame_cache_dir.mkdir(parents=True, exist_ok=True)

    def select_frames(self, video_path: Path) -> list[SelectedVideoFrame]:
        if not self.config.video_enabled or video_path.suffix.lower() not in self._video_extensions():
            return []
        if not ffmpeg_available():
            raise RuntimeError("ffmpeg and ffprobe are required to index videos")

        probe = self._probe(video_path)
        coarse = self._decode_candidates(video_path, stride_seconds=self.config.video_classifier_stride_seconds, probe=probe)
        if not coarse:
            return []

        policy = self._classify_policy(coarse)
        candidates = coarse
        if abs(policy.decode_stride_seconds - self.config.video_classifier_stride_seconds) > 1e-6:
            self._close_frames(coarse)
            candidates = self._decode_candidates(video_path, stride_seconds=policy.decode_stride_seconds, probe=probe)
        if not candidates:
            return []

        self._annotate_deltas(candidates)
        self._attach_embeddings(candidates)
        selected = self._select_sparse_frames(candidates, policy)
        source_signature = stat_signature(video_path)
        duration_ms = int(round(probe.duration_seconds * 1000.0))
        persisted = [
            self._persist_frame(
                video_path=video_path,
                frame=frame,
                duration_ms=duration_ms,
                policy=policy.name,
                source_signature=source_signature,
            )
            for frame in selected
        ]
        self._close_frames(candidates)
        return persisted[: max(int(self.config.video_max_frames_per_video), 1)]

    def _video_extensions(self) -> set[str]:
        from image_archive.constants import SUPPORTED_VIDEO_EXTENSIONS

        return SUPPORTED_VIDEO_EXTENSIONS

    def _probe(self, video_path: Path) -> VideoProbe:
        command = [
            "ffprobe",
            "-v",
            "error",
            "-select_streams",
            "v:0",
            "-show_entries",
            "stream=width,height,avg_frame_rate:format=duration",
            "-of",
            "json",
            str(video_path),
        ]
        result = subprocess.run(command, check=True, capture_output=True, text=True)
        payload = json.loads(result.stdout or "{}")
        streams = payload.get("streams") or [{}]
        stream = streams[0] or {}
        format_data = payload.get("format") or {}
        fps_raw = str(stream.get("avg_frame_rate") or "0/1")
        numerator, _, denominator = fps_raw.partition("/")
        fps = 0.0
        try:
            fps = float(numerator) / max(float(denominator or "1"), 1e-6)
        except ValueError:
            fps = 0.0
        return VideoProbe(
            duration_seconds=max(float(format_data.get("duration") or 0.0), 0.0),
            width=int(stream.get("width") or 0),
            height=int(stream.get("height") or 0),
            fps=fps,
        )

    def _decode_candidates(self, video_path: Path, *, stride_seconds: float, probe: VideoProbe) -> list[DecodedFrame]:
        if stride_seconds <= 0.0:
            raise ValueError("stride_seconds must be positive")

        with tempfile.TemporaryDirectory(prefix="image-archive-video-") as temp_dir:
            output_pattern = str(Path(temp_dir) / "frame_%06d.jpg")
            command = [
                "ffmpeg",
                "-hide_banner",
                "-loglevel",
                "error",
                "-i",
                str(video_path),
                "-vf",
                f"fps=1/{stride_seconds}",
                "-q:v",
                "3",
                output_pattern,
            ]
            subprocess.run(command, check=True, capture_output=True)
            files = sorted(Path(temp_dir).glob("frame_*.jpg"))
            if not files:
                return []

            candidates: list[DecodedFrame] = []
            for index, file_path in enumerate(files):
                image = _safe_open_image(file_path)
                quality = _quality_score(image)
                timestamp_ms = int(round(index * stride_seconds * 1000.0))
                candidates.append(
                    DecodedFrame(
                        timestamp_ms=min(timestamp_ms, int(round(probe.duration_seconds * 1000.0))),
                        frame_index=index,
                        temp_path=file_path,
                        image=image,
                        quality_score=quality,
                    )
                )

            # Move temp files out of the temporary directory so PIL-backed frames can survive.
            persisted_candidates: list[DecodedFrame] = []
            hold_dir = Path(tempfile.mkdtemp(prefix="image-archive-video-hold-"))
            for frame in candidates:
                target = hold_dir / frame.temp_path.name
                shutil.copy2(frame.temp_path, target)
                frame.temp_path = target
                persisted_candidates.append(frame)
            return persisted_candidates

    def _classify_policy(self, coarse_frames: list[DecodedFrame]) -> VideoSelectionPolicy:
        self._annotate_deltas(coarse_frames)
        if len(coarse_frames) < 2:
            return self._balanced_policy()

        motion = float(np.mean([frame.visual_delta for frame in coarse_frames[1:]]))
        cuts = sum(1 for frame in coarse_frames[1:] if frame.visual_delta >= self.config.video_scene_cut_threshold)
        cut_rate = cuts / max(len(coarse_frames) - 1, 1)
        quality_mean = float(np.mean([frame.quality_score for frame in coarse_frames]))
        quality_spread = float(np.std([frame.quality_score for frame in coarse_frames]))
        score = motion * 0.55 + cut_rate * 1.9 + quality_spread * 0.45 + max(0.0, quality_mean - 0.24) * 0.15

        if score < 0.20:
            return VideoSelectionPolicy(
                name="loose",
                decode_stride_seconds=float(self.config.video_loose_stride_seconds),
                min_gap_seconds=float(self.config.video_loose_min_gap_seconds),
                max_gap_seconds=float(self.config.video_loose_max_gap_seconds),
                semantic_threshold=float(self.config.video_loose_semantic_threshold),
            )
        if score > 0.44:
            return VideoSelectionPolicy(
                name="tight",
                decode_stride_seconds=float(self.config.video_tight_stride_seconds),
                min_gap_seconds=float(self.config.video_tight_min_gap_seconds),
                max_gap_seconds=float(self.config.video_tight_max_gap_seconds),
                semantic_threshold=float(self.config.video_tight_semantic_threshold),
            )
        return self._balanced_policy()

    def _balanced_policy(self) -> VideoSelectionPolicy:
        return VideoSelectionPolicy(
            name="balanced",
            decode_stride_seconds=float(self.config.video_balanced_stride_seconds),
            min_gap_seconds=float(self.config.video_balanced_min_gap_seconds),
            max_gap_seconds=float(self.config.video_balanced_max_gap_seconds),
            semantic_threshold=float(self.config.video_balanced_semantic_threshold),
        )

    def _annotate_deltas(self, frames: list[DecodedFrame]) -> None:
        previous = None
        for frame in frames:
            if previous is None:
                frame.visual_delta = 0.0
                frame.scene_cut = True
            else:
                frame.visual_delta = _visual_delta(previous.image, frame.image)
                frame.scene_cut = frame.visual_delta >= float(self.config.video_scene_cut_threshold)
            previous = frame

    def _attach_embeddings(self, frames: list[DecodedFrame]) -> None:
        unresolved = [frame for frame in frames if frame.embedding is None]
        if not unresolved:
            return
        vectors = self.embedding_model.encode_images([frame.image for frame in unresolved])
        for frame, vector in zip(unresolved, vectors):
            value = np.asarray(vector, dtype=np.float32)
            norm = float(np.linalg.norm(value))
            frame.embedding = value if norm <= 1e-12 else value / norm

    def _passes_quality(self, frame: DecodedFrame) -> bool:
        return frame.quality_score >= float(self.config.video_low_quality_threshold)

    def _select_sparse_frames(
        self,
        frames: list[DecodedFrame],
        policy: VideoSelectionPolicy,
    ) -> list[DecodedFrame]:
        if not frames:
            return []

        selected: list[DecodedFrame] = []
        last_kept: Optional[DecodedFrame] = None
        candidate_pool: list[DecodedFrame] = []
        max_frames = max(int(self.config.video_max_frames_per_video), 1)
        min_gap_ms = int(round(policy.min_gap_seconds * 1000.0))
        max_gap_ms = int(round(policy.max_gap_seconds * 1000.0))

        for frame in frames:
            if not self._passes_quality(frame):
                continue

            if last_kept is None:
                selected.append(frame)
                last_kept = frame
                candidate_pool = []
                continue

            gap_ms = frame.timestamp_ms - last_kept.timestamp_ms
            semantic_distance = 0.0
            if last_kept.embedding is not None and frame.embedding is not None:
                semantic_distance = 1.0 - float(np.dot(last_kept.embedding, frame.embedding))

            if gap_ms >= min_gap_ms:
                candidate_pool.append(frame)

            should_keep = gap_ms >= min_gap_ms and (frame.scene_cut or semantic_distance >= policy.semantic_threshold)
            forced_keep = gap_ms >= max_gap_ms
            if not should_keep and not forced_keep:
                continue

            chosen = frame
            if candidate_pool:
                chosen = max(
                    candidate_pool,
                    key=lambda item: (
                        int(item.scene_cut),
                        item.quality_score + item.visual_delta * 0.35,
                        item.timestamp_ms,
                    ),
                )

            if chosen.timestamp_ms > last_kept.timestamp_ms:
                selected.append(chosen)
                last_kept = chosen
                candidate_pool = []
                if len(selected) >= max_frames:
                    break

        if selected and len(selected) < max_frames:
            last_frame = max(
                (frame for frame in frames if self._passes_quality(frame)),
                key=lambda item: item.timestamp_ms,
                default=None,
            )
            if last_frame is not None and last_frame.timestamp_ms > selected[-1].timestamp_ms:
                tail_gap = last_frame.timestamp_ms - selected[-1].timestamp_ms
                if tail_gap >= max_gap_ms // 2:
                    selected.append(last_frame)

        deduped: list[DecodedFrame] = []
        seen_timestamps: set[int] = set()
        for frame in selected:
            if frame.timestamp_ms in seen_timestamps:
                continue
            seen_timestamps.add(frame.timestamp_ms)
            deduped.append(frame)
        return deduped[:max_frames]

    def _persist_frame(
        self,
        *,
        video_path: Path,
        frame: DecodedFrame,
        duration_ms: int,
        policy: str,
        source_signature: str,
    ) -> SelectedVideoFrame:
        key_material = f"{video_path}:{source_signature}:{frame.timestamp_ms}:{policy}".encode("utf-8")
        digest = hashlib.sha256(key_material).hexdigest()[:24]
        target = self.frame_cache_dir / f"{digest}.jpg"
        if not target.exists():
            frame.image.save(target, format="JPEG", quality=92)
        asset_key = f"{video_path}#t={frame.timestamp_ms}"
        return SelectedVideoFrame(
            asset_key=asset_key,
            source_path=video_path,
            frame_path=target,
            timestamp_ms=frame.timestamp_ms,
            duration_ms=duration_ms,
            frame_index=frame.frame_index,
            selection_policy=policy,
            source_signature=source_signature,
        )

    def _close_frames(self, frames: list[DecodedFrame]) -> None:
        for frame in frames:
            frame.image.close()
            try:
                if frame.temp_path.exists():
                    frame.temp_path.unlink()
                    parent = frame.temp_path.parent
                    if parent.name.startswith("image-archive-video-hold-") and parent.exists():
                        parent.rmdir()
            except OSError:
                continue
