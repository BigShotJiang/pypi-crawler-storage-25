import re
import uuid
import zipfile
from io import BytesIO
from pathlib import Path

from ebooklib import epub
from PIL import Image

from ..models.output_format import OutputFormat


class MultiFormatExporter:
    """Merges images into a merged format, either in memory or to disk."""

    def _sanitize(self, path: str) -> str:
        """Sanitize a path to be used as a filename.

        Args:
            path: The path to sanitize

        Returns:
            str: The sanitized path
        """
        # Remove characters that are invalid on Windows or Unix filesystems
        # This includes: < > : " / \ | ? * and control characters
        # All other characters (alphanumeric, spaces, hyphens, underscores, periods, brackets, parentheses) are kept
        sanitized = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "", path)

        # Replace multiple spaces with single space
        sanitized = re.sub(r"\s+", " ", sanitized)

        # Strip leading/trailing whitespace
        sanitized = sanitized.strip()

        # Ensure filename isn't empty
        if not sanitized:
            sanitized = "untitled"

        return sanitized

    def _generate_cbz(self, images: list[Image.Image], write_location: Path | BytesIO) -> bytes:
        """Generate a CBZ file from a list of images.

        Args:
            images: The list of images to generate
            write_location: The location to write the CBZ file

        Returns:
            bytes: The CBZ file data
        """

        with zipfile.ZipFile(write_location, "w", compression=zipfile.ZIP_DEFLATED) as cbz:
            for i, img in enumerate(images, start=1):
                img_buf = BytesIO()
                img.save(img_buf, format="PNG")
                img_buf.seek(0)
                cbz.writestr(f"page_{i:03}.png", img_buf.read())

        if isinstance(write_location, BytesIO):
            return write_location.getvalue()

        return b""

    def _generate_pdf(
        self,
        images: list[Image.Image],
        write_location: Path | BytesIO,
        quality: int = 75,
        optimize: bool = False,
    ) -> None:
        """Generate a PDF file from a list of images.

        Args:
            images: The list of images to generate
            write_location: The location to write the PDF file

        Returns:
            None: The PDF file data is written to the write_location regardless of if it was a BytesIO or Path
        """

        images[0].save(
            write_location,
            format=str(OutputFormat.PDF),
            save_all=True,
            append_images=images[1:],
            quality=quality,
            optimize=optimize,
        )

    def _generate_epub(
        self,
        images: list[Image.Image],
        write_location: Path | BytesIO,
    ) -> None:
        """Generate an EPUB file from a list of images (single chapter format).

        Args:
            images: The list of images to generate
            write_location: The location to write the EPUB file

        Returns:
            None: The EPUB file is written to write_location
        """

        book = epub.EpubBook()
        book.set_identifier(str(uuid.uuid4()))
        book.set_language("en")

        css = """
            body { margin: 0; padding: 0; width: 100%; height: 100%; }
            img { width: 100%; height: 100%; display: block; }
            """
        nav_css = epub.EpubItem(
            uid="style_nav",
            file_name="style/nav.css",
            media_type="text/css",
            content=css,
        )
        book.add_item(nav_css)

        pages = []
        for i, img in enumerate(images, start=1):
            buffer = BytesIO()
            img.save(buffer, format="JPEG")
            img_data = buffer.getvalue()

            img_item = epub.EpubItem(
                uid=f"page_{i}",
                file_name=f"images/page_{i:03}.jpg",
                media_type="image/jpeg",
                content=img_data,
            )
            book.add_item(img_item)

            page = epub.EpubHtml(
                title=f"Page {i}",
                file_name=f"page_{i}.xhtml",
            )
            page.set_content(
                f"<html><head></head><body><img src='images/page_{i:03}.jpg' alt='Page {i}'/></body></html>"
            )
            page.add_item(nav_css)
            book.add_item(page)
            pages.append(page)

            if i == 1:
                book.set_cover("cover.jpg", img_data)

        book.add_item(epub.EpubNcx())
        book.add_item(epub.EpubNav())
        book.spine = pages

        epub.write_epub(write_location, book, {})

    def _validate_inputs(
        self,
        image_data_list: list[bytes],
        output_directory: Path,
        output_name: str,
        quality: int,
    ) -> None:
        """Validate inputs for the generate method.

        Args:
            image_data_list: The list of image data to merge
            output_directory: The directory to save the file
            output_name: The name of the output file
            quality: The quality of the PDF (1-100)

        Raises:
            ValueError: If any of the arguments are invalid
        """
        if not image_data_list:
            raise ValueError("Image data list cannot be empty")

        if not output_directory.exists() or not output_directory.is_dir():
            raise ValueError(f"Output directory must be a valid directory: {output_directory}")

        if not output_name:
            raise ValueError("Output name cannot be empty")

        if quality < 1 or quality > 100:
            raise ValueError("Quality must be between 1 and 100")

    def _load_images(self, image_data_list: list[bytes]) -> list[Image.Image]:
        """Load images from bytes and convert to RGB.

        Args:
            image_data_list: The list of image data to load

        Returns:
            list[Image.Image]: List of loaded images in RGB mode

        Raises:
            ValueError: If any image data is invalid
        """
        images: list[Image.Image] = []

        for image_data in image_data_list:
            try:
                img = Image.open(BytesIO(image_data))
            except Exception as e:
                raise ValueError(f"Invalid image data: {e}") from e

            if img.mode in ("RGBA", "P"):
                img = img.convert("RGB")

            images.append(img)

        if not images:
            raise ValueError("No valid images to generate output")

        return images

    def generate(
        self,
        image_data_list: list[bytes],
        output_directory: Path,
        output_name: str,
        output_format: OutputFormat,
        quality: int = 75,
        optimize: bool = False,
        return_bytes: bool = False,
    ) -> tuple[str, bytes]:
        """Merge images into a merged format.

        Processes image bytes and generates a PDF, CBZ, or EPUB file.
        Can write output to disk or return file data based on the return_bytes flag.

        Args:
            image_data_list: The list of image data to merge
            output_directory: The directory to save the file
            output_name: The name of the output file
            output_format: The format of the output file
            quality: The quality of the PDF (1-100, default: 75)
            optimize: Whether to optimize PDF file size (default: False)
            return_bytes: If True, return file bytes instead of writing to disk (default: False)

        Returns:
            tuple[str, bytes]: (full_name, file_bytes)
            - file_name: The full filename with extension
            - file_bytes: If return_bytes=True, the file bytes; otherwise empty bytes

        Raises:
            ValueError: If any of the arguments are invalid
        """
        self._validate_inputs(image_data_list, output_directory, output_name, quality)

        file_name: str = f"{self._sanitize(output_name)}.{str(output_format)}"
        full_output_path: Path = output_directory / file_name

        output_data: bytes = b""
        file_data: bytes = b""

        images = self._load_images(image_data_list)

        try:
            if output_format == OutputFormat.CBZ:
                write_location = BytesIO() if return_bytes else full_output_path
                file_data = self._generate_cbz(images, write_location)

            elif output_format == OutputFormat.EPUB:
                write_location = BytesIO() if return_bytes else full_output_path
                self._generate_epub(images, write_location)

                if isinstance(write_location, BytesIO):
                    file_data = write_location.getvalue()

            else:
                write_location = BytesIO() if return_bytes else full_output_path
                self._generate_pdf(images, write_location, quality, optimize)

                if isinstance(write_location, BytesIO):
                    file_data = write_location.getvalue()

            if return_bytes and file_data:
                # conditional needed because CBZ path always returns bytes
                output_data = file_data

            return file_name, output_data
        finally:
            for img in images:
                img.close()
