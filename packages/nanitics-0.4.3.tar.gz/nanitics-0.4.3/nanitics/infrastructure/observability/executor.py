"""TracedExecutor — run lifecycle management with real-time event persistence.

Composes :class:`InMemoryEmitter`, :class:`TraceCollector`, and
:class:`PersistentTraceStore` into a single entry point that wraps any
async execution with run registration, streaming event persistence, and
status finalisation.

Typical usage::

    executor = TracedExecutor(trace_store)
    run_id, result = await executor.execute(
        lambda emitter, run_id: my_agent_factory(emitter).run(input),
        metadata={"agent": "extraction"},
    )

The factory receives two positional arguments: the run-scoped
:class:`EventEmitter` and the pre-generated ``run_id``. The ``run_id``
passed into the factory is identical to the first element of the
returned ``(run_id, result)`` tuple — making it available inside the
factory lets callers key external durable state (HITL requests,
resumable workflows, auction waiter registries) on the Observatory
``run_id`` before ``execute`` returns.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from typing import Any, TypeVar
from uuid import uuid4

from nanitics.infrastructure.observability.collector import TraceCollector
from nanitics.infrastructure.observability.emitter import EventEmitter, InMemoryEmitter
from nanitics.infrastructure.observability.levels import TraceLevel
from nanitics.infrastructure.observability.redaction import RedactionHook
from nanitics.infrastructure.observability.storage import (
    PersistentTraceStore,
    RunResult,
    TerminationReason,
)

T = TypeVar("T")


class TracedExecutor:
    """Wraps async execution with run lifecycle management and event persistence.

    Handles the full run lifecycle: generate IDs, register the run, create an
    emitter, wire a :class:`TraceCollector` for real-time persistence, execute
    the callable, and finalise run status. Events are persisted continuously
    (not batched after completion), so failed and suspended runs retain their
    trace data.

    Args:
        trace_store: Persistent store for run records and trace events.
    """

    def __init__(self, trace_store: PersistentTraceStore) -> None:
        self._trace_store = trace_store

    async def execute(
        self,
        fn: Callable[[EventEmitter, str], Awaitable[T]],
        metadata: dict[str, Any] | None = None,
        *,
        run_id: str | None = None,
        queue: asyncio.Queue[dict[str, object]] | None = None,
        min_level: TraceLevel = "info",
        redaction_hook: RedactionHook | None = None,
    ) -> tuple[str, T]:
        """Execute *fn* with full run lifecycle and trace persistence.

        Callers that need the ``run_id`` before ``fn`` runs (e.g., HTTP
        routes that return ``202 {"run_id": "..."}`` before scheduling the
        executor on a background task, so the client can open an SSE
        connection keyed on that id before ``fn`` starts) should pass it
        in via the ``run_id`` kwarg. Callers whose deadline is "before
        ``execute`` returns" can instead read the ``run_id`` argument
        passed into ``fn``; both paths surface the same identifier.

        Args:
            fn: Async callable receiving an :class:`EventEmitter` and the
                ``run_id`` and returning a result. Free to create agents,
                workflows, or any async work. The ``run_id`` passed in is
                identical to the first element of the returned tuple — the
                caller-supplied value when one is given via the ``run_id``
                kwarg, otherwise an internally generated UUID.
            metadata: Optional dictionary persisted with the run record.
            run_id: Optional caller-supplied run identifier. When ``None``
                (default), ``execute`` generates a UUID internally; when a
                string is supplied, that string is used as the run id and
                the caller is responsible for ensuring uniqueness. Empty
                strings and other falsy non-``None`` values are passed
                through unchanged — only ``None`` triggers internal
                generation. Duplicate-id behavior is delegated to the
                trace store: :class:`PostgresTraceStore` surfaces a
                unique-violation ``IntegrityError`` from its ``runs.id``
                ``PRIMARY KEY`` constraint;
                :class:`InMemoryPersistentTraceStore` overwrites silently.
            queue: Optional async queue for live SSE streaming. The internal
                :class:`TraceCollector` pushes qualifying events here.
            min_level: Minimum event level pushed to *queue*. Defaults to
                ``"info"``.
            redaction_hook: Optional adopter-supplied
                :class:`RedactionHook` forwarded to the internal
                :class:`TraceCollector`. When provided, the hook runs
                once per emitted event before persistence and before
                SSE queue push, so any field the hook scrubs is scrubbed
                on both downstream surfaces. A hook that raises causes
                the affected event to be neither persisted nor enqueued
                and the run to fail fast (see
                ``docs/guides/observability.md#trace-surface-hygiene``).
                The parameter lives on ``execute()`` rather than
                ``__init__`` so redaction policy can vary per run
                (tenant, user, request).

        Returns:
            A ``(run_id, result)`` tuple where *run_id* is the
            caller-supplied value when one was given, otherwise the
            internally generated UUID, and *result* is whatever *fn*
            returned.

        Raises:
            SuspendExecution: Re-raised after persisting events and marking
                the run as suspended.
            Exception: Any other exception is re-raised after persisting
                events and marking the run as failed.
        """
        # Deferred import: ``SuspendExecution`` lives in ``composition.durability``
        # which layers above ``infrastructure``. Importing it at module level
        # would invert the dependency direction.
        from nanitics.composition.durability.suspension import SuspendExecution

        run_id = run_id if run_id is not None else str(uuid4())
        trace_id = str(uuid4())

        await self._trace_store.register_run(run_id, trace_id, metadata or {})

        emitter = InMemoryEmitter(trace_id=trace_id)
        collector = TraceCollector(
            store=self._trace_store,
            parent_id=run_id,
            queue=queue,
            min_level=min_level,
            redaction_hook=redaction_hook,
        )
        emitter.add_listener(collector.handle, internal=True)

        try:
            result = await fn(emitter, run_id)
        except SuspendExecution:
            await collector.close()
            await self._trace_store.update_run_status(run_id, "suspended")
            raise
        except Exception as exc:
            await collector.close()
            await self._trace_store.update_run_status(run_id, "failed", error=str(exc))
            raise

        await collector.close()
        adapted = _adapt_result(result)
        await self._trace_store.update_run_status(run_id, "completed", result=adapted)

        return run_id, result


def _adapt_result(result: object) -> RunResult:
    """Map an arbitrary run return value into the typed :class:`RunResult`.

    Native strategy result types (ReActResult, CodeActResult, etc.) expose
    ``output``, ``termination_reason``, and ``total_steps`` either as
    attributes (Pydantic models, dataclasses) or as dict keys. Strings
    are treated as the run's output. Unknown termination strings land in
    :attr:`TerminationReason.OTHER` with the original string preserved
    in :attr:`RunResult.termination_reason_raw`.
    """
    if result is None:
        return RunResult()
    if isinstance(result, RunResult):
        return result
    if isinstance(result, str):
        return RunResult(output=result)

    output = _extract_str(result, "output")
    raw_reason = _extract_str(result, "termination_reason")
    reason, reason_raw = _normalize_termination(raw_reason)
    total_steps = _extract_int(result, "total_steps")

    return RunResult(
        output=output,
        termination_reason=reason,
        termination_reason_raw=reason_raw,
        total_steps=total_steps,
    )


def _extract_field(obj: object, name: str) -> object | None:
    if isinstance(obj, dict):
        return obj.get(name)
    return getattr(obj, name, None)


def _extract_str(obj: object, name: str) -> str | None:
    value = _extract_field(obj, name)
    return value if isinstance(value, str) else None


def _extract_int(obj: object, name: str) -> int | None:
    value = _extract_field(obj, name)
    return value if isinstance(value, int) and not isinstance(value, bool) else None


def _normalize_termination(raw: str | None) -> tuple[TerminationReason | None, str | None]:
    if raw is None:
        return None, None
    try:
        return TerminationReason(raw), None
    except ValueError:
        return TerminationReason.OTHER, raw
