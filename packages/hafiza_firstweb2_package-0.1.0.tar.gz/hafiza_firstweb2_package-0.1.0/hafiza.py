def say_hello():
    print("Hello! This is Hafiza.")