import os

from .api import API
from .auth import LoyaAuth

# Один раз создаётся при первом импорте
_api_instance: API | None = None


def get_api() -> API:
    global _api_instance
    if _api_instance is None:
        auth = LoyaAuth(
            email=os.getenv("LOYA_EMAIL"),
            password=os.getenv("LOYA_PASSWORD"),
            apikey=os.getenv("LOYA_APIKEY"),
        )
        _api_instance = API(
            auth=auth,
            host=os.getenv("LOYA_HOST", "http://loya.office.ru"),
            loya_database_host=os.getenv("LOYA_DATABASE_HOST", "10.33.33.124"),
            loya_database=os.getenv("LOYA_DATABASE", "coper"),
            loya_database_user=os.getenv("LOYA_DATABASE_USER", "root"),
            loya_database_password=os.getenv("LOYA_DATABASE_PASSWORD", ""),
        )
    return _api_instance
