__all__ = ["get_logger", "BasicLogger"]
import sys

import logging


from datetime import datetime
from .common import Union, List, Path, Number, Optional, Dict, Literal


from .file import (
    save_text,
    load_text,
    load_yaml,
    save_yaml,
    load_json,
    save_json,
    is_pathlike,
)
from .misc import get_current_time
from pathlib import Path


# ANSI escape sequences for terminal colors
COLORS = {
    "DEBUG": "\033[94m",  # Blue
    "INFO": "\033[92m",  # Green
    "WARNING": "\033[93m",  # Yellow
    "ERROR": "\033[91m",  # Red
    "CRITICAL": "\033[95m",  # Magenta
    "RESET": "\033[0m",  # Reset
}


class BasicLogger(logging.Formatter):
    def __init__(
        self,
        dir_to_save: Optional[str] = None,
        save_logs: bool = False,
        encoding: Optional[str] = "utf-8",
        errors: Union[str, Literal["strict", "ignore"]] = "strict",
    ):
        super().__init__()
        self.dir_save = None
        self.saving_fn = lambda message, title, level, time: None
        self.encoding = encoding
        self.errors = errors
        self._key_save_type: Optional[Literal["json", "yaml"]] = None
        if save_logs:
            self.dir_save = Path(
                dir_to_save
                if is_pathlike(dir_to_save, True, False)
                else f"./logs/{get_current_time()}.log"
            )
            if not self.dir_save.name.endswith((".log", ".txt", ".json", ".yaml")):
                self.dir_save = Path(self.dir_save, get_current_time() + ".log")
                self.saving_fn = self._save_text
            else:
                if self.dir_save.name.endswith((".json", ".yaml")):
                    self._key_save_type = self.dir_save.name[-4:]
                    self.saving_fn = self._save_by_keys
                else:
                    self.saving_fn = self._save_text
            self.dir_save.parent.mkdir(exist_ok=True, parents=True)

    def _save_by_keys(self, message: str, title: str, level: str, time: str):
        contents = []
        if self._key_save_type == "json":
            contents = load_json(
                self.dir_save, [], encoding=self.encoding, errors=self.errors
            )
        else:
            contents = load_yaml(self.dir_save, [], False)
        contents.append(
            {
                "title": title.replace(" ", "_"),
                "time": time,
                "level": level,
                "message": message,
            }
        )
        if self._key_save_type == "json":
            save_json(
                path=self.dir_save,
                content=contents,
                encoding=self.encoding,
                errors=self.errors,
            )
        else:
            save_yaml(
                path=self.dir_save,
                content=contents,
                encoding=self.encoding,
                errors=self.errors,
            )

    def _save_text(self, message: str, title: str, level: str, time: str):
        contents = load_text(
            self.dir_save,
            encoding=self.encoding,
            errors=self.errors,
            default_value="\n",
        ).rstrip()

        content = (
            f"[{title} | {time}]: {message.strip()}"
            if title == level
            else f"[{title} - {level} | {time}]: {message.strip()}"
        )
        if contents:
            contents += f"\n"
        contents += f"{content}"
        save_text(
            path=self.dir_save,
            content=contents,
            encoding=self.encoding,
            errors=self.errors,
        )

    def format(self, record):
        log_time = datetime.now().strftime("%H:%M:%S - %d/%m/%Y")
        level = record.levelname
        reset = COLORS["RESET"]
        color = getattr(record, "color", COLORS.get(level, reset))

        # Title from record or default to level name
        title = getattr(record, "title", level)
        msg = record.getMessage()
        message = f"[{log_time}] ({title.capitalize()}): {msg}"
        self.saving_fn(message=msg, title=title, level=level, time=log_time)
        return f"{color}{message}{reset}"


def get_logger(
    name: str = "Base",
    logs_location: Optional[str] = None,
    level=logging.DEBUG,
    save_logs: bool = False,
    *,
    encoding: Optional[str] = "utf-8",
    errors: Union[str, Literal["strict", "ignore"]] = "strict",
) -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(level)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(
            BasicLogger(
                logs_location, save_logs=save_logs, encoding=encoding, errors=errors
            )
        )
        logger.addHandler(handler)

    return logger


_LT_BASE_LOGGER = get_logger("lt_base")


def log_traceback(
    exception: Exception,
    title: Optional[str] = None,
    invert_traceback: bool = False,
    stack_size: Optional[int] = None,
    logger: logging.Logger = _LT_BASE_LOGGER,
    logger_level: int = logging.ERROR,
    logger_stacklevel: int = 1,
    *,
    only_show_lines_containing: Optional[List[str]] = None,
    exclude_lines_containing: Optional[List[str]] = None,
    inspect_stack_skip: int = 1,
    inspect_stack_depth: int = 3,
    **kwargs,
) -> Dict[str, Union[str, Number, List[str], Dict[str, Union[str, int, List[str]]]]]:
    """Logs the traceback stack of an exception, with optional title, limit, and inversion settings.

    Args:
        exception (Exception): The exception object.
        title (Optional[str], optional): A title for the exception that will be displayed, can be a reference that
                                        may help to locate where the error ocurred easier. Defaults to None.
        limit (Optional[int], optional): Limit for the traceback. Defaults to None.
        invert_traceback (bool, optional): If is preferred that the traceback is printed in inverse order. Defaults to False.
        stack_size (Optional[int], optional): Setting any value above zero here will slice the logging size to that size (from the final stack)

    Returns:
        Dict[str, Union[str, Number, List[str]], Dict[str, Union[str, int, List[str]]]]: A dictionary containing all the traceback history.
    """
    import inspect
    import traceback

    info = {
        "exception": None,
        "class": None,
        "lines": [],
        "sources": [],
        "t_data": {},
    }
    stacks = inspect.stack()
    if stacks:
        inspect_stack_depth = max(min(int(inspect_stack_depth), len(stacks)), 0)
        inspect_stack_skip = max(
            min(int(inspect_stack_skip), inspect_stack_depth - 1), 0
        )
        if inspect_stack_skip:
            stacks = stacks[inspect_stack_skip:]
        if inspect_stack_depth:
            stacks = stacks[:inspect_stack_depth]

        def _get_stack_data(stack: inspect.FrameInfo):
            fname = getattr(stack, "filename", None)
            if isinstance(fname, (str, bytes)):
                fname = fname.replace("\\", "/")
            line = None
            if hasattr(stack, "positions"):
                p = stack.positions
                if hasattr(p, "lineno"):
                    line = p.lineno

            return {
                "file": fname,
                "context": getattr(stack, "code_context", None),
                "line": line,
            }

        info["sources"] = [_get_stack_data(stack) for stack in stacks]

    def check_if_line_val(line: str):
        if not isinstance(line, str):
            return False

        if not line.strip():
            return False
        if only_show_lines_containing:
            if not any([x in line for x in only_show_lines_containing]):
                return False
        if exclude_lines_containing:
            if any([x in line for x in exclude_lines_containing]):
                return False
        return True

    info["lines"] = [
        x.strip()
        for x in traceback.format_exception(
            type(exception), exception, exception.__traceback__, limit=None
        )
        if check_if_line_val(x)
    ]
    for k, v in exception.__traceback__.tb_frame.f_globals.items():
        try:
            info["t_data"][str(k)] = str(v)
        except:
            pass

    trace_text = "\n\n===========================\n\n"
    if isinstance(title, str) and title.strip():
        trace_text += (
            f"-----[ {title} - Type: [{exception.__class__.__name__}] ]-----\n"
        )
    else:
        trace_text += f"-----[ {exception.__class__.__name__} ]-----\n"
    trace_text += info["lines"][-1]
    trace_text += "\n\n-------[ Traceback ]-------\n"
    if isinstance(stack_size, (float, int)) and stack_size >= 1:
        info["lines"] = info["lines"][-int(stack_size) :]

    if invert_traceback:
        info["lines"].reverse()

    trace_text += "\n".join(info["lines"])
    trace_text += "\n\n===========================\n\n"

    logger.log(
        logger_level,
        f"{trace_text}",
        stacklevel=logger_stacklevel,
    )

    return info
