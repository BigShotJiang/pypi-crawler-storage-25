import torch
import numpy as np
from torch import nn, Tensor
from ...common import (
    Sequence,
    Optional,
    List,
    Tuple,
    Union,
    Any,
    Dict,
)


def move_list_to_device(
    entries: Union[List[Union[Any, Tensor]], Tuple[Union[Any, Tensor], ...]],
    device: Union[str, torch.device],
    max_depth: int = 3,
    *,
    _depth: int = 0,
):
    was_tuple = isinstance(entries, tuple)
    if was_tuple:
        entries_list = [x for x in entries]
        entries = entries_list

    for i in range(len(entries)):
        if isinstance(entries[i], Tensor):
            entries[i] = entries[i].to(device=device)
        elif _depth >= max_depth:
            continue
        elif isinstance(entries[i], dict):
            entries[i] = move_dict_to_device(
                entries[i], device=device, _depth=_depth + 1
            )
        elif isinstance(entries[i], (tuple, list)):
            entries[i] = move_list_to_device(
                entries[i], device=device, _depth=_depth + 1
            )
    if was_tuple:
        return tuple(entries)
    return entries


def move_dict_to_device(
    entries: Dict[str, Union[Any, Tensor]],
    device: Union[str, torch.device],
    max_depth: int = 3,
    *,
    _depth: int = 0,
):
    keys = list(entries.keys())
    for k in keys:
        if isinstance(entries[k], Tensor):
            entries[k] = entries[k].to(device)
        elif _depth >= max_depth:
            continue
        elif isinstance(entries[k], dict):
            entries[k] = move_dict_to_device(
                entries[k], device=device, _depth=_depth + 1
            )
        elif isinstance(entries[k], (list, tuple)):
            entries[k] = move_list_to_device(
                entries[k], device=device, _depth=_depth + 1
            )
    return entries


def time_weighted_avg(data: Tensor, alpha: float = 0.9) -> Tensor:
    """
    Compute time-weighted moving average for smoothing.
    Args:
        data: [T] or [N, T] tensor / array (time series)
        alpha: smoothing factor (0 < alpha < 1), higher = smoother
    Returns:
        smoothed Tensor of same shape
    """
    data = torch.as_tensor(data)
    if data.ndim <= 1:
        data = data.view(1, -1)

    out = torch.zeros_like(data)
    out[..., 0] = data[..., 0]

    for t in range(1, data.size(-1)):
        out[..., t] = alpha * out[..., t - 1] + (1 - alpha) * data[..., t]
    return out


def time_weighted_ema(
    x: Tensor,
    time_weights: Optional[Tensor] = None,
    alpha: float = 0.9,
    normalize: bool = False,
    eps: float = 1e-7,
) -> Tensor:
    """
    Compute a time-weighted exponential moving average (EMA) for a 1D or 2D tensor.

    Args:
        x (torch.Tensor): Input tensor of shape (T,) or (B, T)
        time_weights (torch.Tensor, optional): Relative weights per time step.
            Must be broadcastable to x.shape. If None, uses uniform spacing.
        alpha (float): Smoothing factor in [0,1]. Higher means slower decay.
        normalize (bool): If True, normalize EMA output to zero mean/unit variance.
        eps (float): Small constant to prevent division by zero.

    Returns:
        Tensor: Time-weighted EMA of same shape as input.
    """

    x = torch.as_tensor(x)

    if x.ndim <= 1:
        x = x.view(1, -1)

    T = x.size(-1)

    if time_weights is None:
        time_weights = torch.ones(T, device=x.device)
    else:
        time_weights = torch.as_tensor(time_weights, device=x.device)

    # Normalize time weights to ensure stability
    time_weights = time_weights / (time_weights.max() + eps)

    ema = torch.zeros_like(x)
    ema[..., 0] = x[..., 0]

    for t in range(1, T):
        # Adjust decay using time weighting
        decay = alpha ** time_weights[t]
        ema[..., t] = decay * ema[..., t - 1] + (1 - decay) * x[..., t]

    if normalize:
        mean = ema.mean(dim=-1, keepdim=True)
        std = ema.std(dim=-1, keepdim=True).clamp(min=eps)
        ema = (ema - mean) / std

    return ema


def normalize_minmax(
    x: Tensor,
    min_val: float = -1.0,
    max_val: float = 1.0,
    dim: Union[Sequence[int], int] = (),
    eps: float = 1e-7,
) -> Tensor:
    """Scales tensor to [min_val, max_val] range."""
    x_min, x_max = x.amin(dim=dim), x.amax(dim=dim)
    return (x - x_min) / (x_max - x_min + eps) * (max_val - min_val) + min_val
