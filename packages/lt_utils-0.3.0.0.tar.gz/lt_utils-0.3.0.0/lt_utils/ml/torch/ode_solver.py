"""Notice:
Simplified version of the torchdiffeq's odeint solver (repo: https://github.com/rtqichen/torchdiffeq)

It might not work as intended, and have many missing features.

No further changes will be made, only for compatibility if needed.

License:
---
MIT License

Copyright (c) 2018 Ricky Tian Qi Chen

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

---
"""

__all__ = [
    "ODESolver",
    "EulerSolver",
    "MidpointSolver",
    "odeint",
]
from abc import abstractmethod, ABC
import torch
from torch import Tensor
from lt_utils.common import (
    Optional,
    Dict,
    Tuple,
    Literal,
    Number,
    Callable,
    Type,
)


class ODESolver(ABC):
    def __init__(
        self,
        func: Callable[[Tensor, Tensor], Tensor],
        y0: Tensor,
        step_size: Optional[Number] = None,
        interp: Literal["linear", "cubic"] = "linear",
        **_,
    ):
        if interp not in ["linear", "cubic"]:
            raise ValueError(f"Unknown interpolation method {self.interp}")
        if not callable(func):
            raise ValueError("A callable function is required to use this solver.")
        self.func = func
        self.y0 = y0
        self.dtype = y0.dtype
        self.device = y0.device
        self.interp = interp
        self.step_size = step_size
        self.batch_size = y0.size(0)
        if step_size is None:
            self.grid_constructor = lambda t: t
        else:
            self.grid_constructor = self._grid_constructor_from_step_size(step_size)

    @staticmethod
    def _grid_constructor_from_step_size(step_size):
        def _grid_constructor(t):
            start_time = t[0]
            end_time = t[-1]

            niters = torch.ceil((end_time - start_time) / step_size + 1).item()
            t_infer = (
                torch.arange(0, niters, dtype=t.dtype, device=t.device) * step_size
                + start_time
            )
            t_infer[-1] = t[-1]

            return t_infer

        return _grid_constructor

    def _solve_single(self, t: Tensor, batch_id: int = 0):
        time_grid = self.grid_constructor(t)
        y0 = self.y0[batch_id].clone()
        solution = torch.empty(len(t), *y0.shape, dtype=self.dtype, device=self.device)
        solution[0] = self.y0[batch_id].clone()

        j = 1
        for t0, t1 in zip(time_grid[:-1], time_grid[1:]):
            dt = t1 - t0
            dy, f0 = self._step_func(t0, dt, y0)
            y1 = y0 + dy

            while j < len(t) and t1 >= t[j]:
                if self.interp == "linear":
                    solution[j] = self._linear_interp(t0, t1, y0, y1, t[j])
                else:
                    f1 = self.func(t1, y1)
                    solution[j] = self._cubic_hermite_interp(
                        t0, y0, f0, t1, y1, f1, t[j]
                    )
                j += 1
            y0 = y1
        return solution

    def __call__(self, t: Tensor):
        solutions = []
        for b in range(self.batch_size):
            solution = self._solve_single(t, b)
            solutions.append(solution)
        return torch.stack(solutions, dim=0)

    @abstractmethod
    def _step_func(
        self, t: Tensor, dt: Tensor, y0: Tensor
    ) -> Tuple[Tensor, Tensor]: ...

    def _cubic_hermite_interp(self, t0, y0, f0, t1, y1, f1, t):
        h = (t - t0) / (t1 - t0)
        h00 = (1 + 2 * h) * (1 - h) * (1 - h)
        h10 = h * (1 - h) * (1 - h)
        h01 = h * h * (3 - 2 * h)
        h11 = h * h * (h - 1)
        dt = t1 - t0
        return h00 * y0 + h10 * dt * f0 + h01 * y1 + h11 * dt * f1

    def _linear_interp(self, t0, t1, y0, y1, t):
        if t == t0:
            return y0
        if t == t1:
            return y1
        slope = (t - t0) / (t1 - t0)
        return y0 + slope * (y1 - y0)


class EulerSolver(ODESolver):
    def _step_func(self, t, dt, y0):
        f0 = self.func(t, y0)
        return dt * f0, f0


class MidpointSolver(ODESolver):
    def _step_func(self, t, dt, y0):
        half_dt = 0.5 * dt
        f0 = self.func(t, y0)
        y_mid = y0 + f0 * half_dt
        return dt * self.func(t + half_dt, y_mid), f0


SOLVERS: Dict[str, Type[ODESolver]] = {
    "euler": EulerSolver,
    "midpoint": MidpointSolver,
}


def odeint(
    function: Callable[[Tensor, Tensor], Tensor],
    t: Tensor,
    y0: Tensor,
    *,
    solver: Literal["euler", "midpoint"] = "euler",
    step_size: Optional[Number] = None,
    interp: Literal["linear", "cubic"] = "linear",
):
    solver = solver.strip().lower()
    assert solver in [
        "euler",
        "midpoint",
    ], f"Unknown solver '{solver}'. Use either 'euler' or 'midpoint'"
    solver_cls = SOLVERS[solver](
        func=function,
        y0=y0,
        step_size=step_size,
        interp=interp,
    )
    return solver_cls(t)
