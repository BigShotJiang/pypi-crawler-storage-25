from datetime import UTC, datetime

import pytest

from nvd_cve_mcp_server.nvd_client import NVDAPIError, NVDClient, _format_nvd_datetime, format_cve_response


def test_format_nvd_datetime_uses_utc_suffix() -> None:
    value = datetime(2026, 1, 2, 3, 4, 5, tzinfo=UTC)
    assert _format_nvd_datetime(value) == "2026-01-02T03:04:05.000Z"


def test_search_by_severity_rejects_invalid_severity() -> None:
    client = NVDClient(api_key=None)

    with pytest.raises(NVDAPIError):
        client.search_by_severity("INVALID")


def test_format_cve_response_normalizes_and_limits_items() -> None:
    payload = {
        "totalResults": 2,
        "vulnerabilities": [
            {
                "cve": {
                    "id": "CVE-2025-0001",
                    "published": "2025-01-01T00:00:00.000",
                    "lastModified": "2025-01-02T00:00:00.000",
                    "descriptions": [{"lang": "en", "value": "First"}],
                    "metrics": {
                        "cvssMetricV31": [
                            {
                                "baseSeverity": "HIGH",
                                "cvssData": {
                                    "baseScore": 7.5,
                                    "vectorString": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H",
                                },
                            }
                        ]
                    },
                    "references": [{"url": "https://example.com/1"}],
                    "weaknesses": [{"description": [{"value": "CWE-79"}]}],
                }
            },
            {
                "cve": {
                    "id": "CVE-2024-0002",
                    "published": "2024-01-01T00:00:00.000",
                    "lastModified": "2024-01-02T00:00:00.000",
                    "descriptions": [{"lang": "en", "value": "Second"}],
                    "metrics": {},
                    "references": [],
                    "weaknesses": [],
                }
            },
        ],
    }

    formatted = format_cve_response(payload, limit=1)

    assert formatted["total_results"] == 2
    assert formatted["returned_results"] == 1
    assert formatted["cves"][0]["id"] == "CVE-2025-0001"
    assert formatted["cves"][0]["severity"] == "HIGH"
