from __future__ import annotations

from collections import deque
from typing import Any, cast

import httpx
import pytest

from nvd_cve_mcp_server import nvd_client, server


class DummyHttpClient:
    def __init__(self, callback: Any) -> None:
        self._callback = callback

    def get(self, url: str, params: dict[str, Any]) -> httpx.Response:
        return cast(httpx.Response, self._callback(url, params))


def _make_response(status_code: int, body: bytes = b"{}") -> httpx.Response:
    request = httpx.Request("GET", nvd_client.NVD_BASE_URL)
    return httpx.Response(status_code, request=request, content=body)


def test_backoff_delay_prefers_retry_after_header() -> None:
    response = _make_response(429)
    response.headers["Retry-After"] = "12"

    assert nvd_client._backoff_delay(0, response) == 12.0


def test_backoff_delay_ignores_invalid_retry_after(monkeypatch: pytest.MonkeyPatch) -> None:
    response = _make_response(429)
    response.headers["Retry-After"] = "not-a-number"
    monkeypatch.setattr("nvd_cve_mcp_server.nvd_client.random.uniform", lambda _a, _b: 0.0)

    assert nvd_client._backoff_delay(2, response) == 4.0


def test_rate_limiter_waits_until_window_expires(monkeypatch: pytest.MonkeyPatch) -> None:
    limiter = nvd_client.RateLimiter(max_requests=1, window_seconds=10)
    limiter._timestamps = deque([0.0])

    monotonic_values = iter([5.0, 10.1])
    sleep_calls: list[float] = []

    monkeypatch.setattr("nvd_cve_mcp_server.nvd_client.time.monotonic", lambda: next(monotonic_values))
    monkeypatch.setattr("nvd_cve_mcp_server.nvd_client.time.sleep", lambda seconds: sleep_calls.append(seconds))

    limiter.acquire()

    assert sleep_calls == [5.0]
    assert len(limiter._timestamps) == 1
    assert limiter._timestamps[0] == pytest.approx(10.1)


def test_client_post_init_uses_renamed_user_agent_and_api_key(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("NVD_RATE_LIMIT_REQUESTS", "7")
    monkeypatch.setenv("NVD_RATE_LIMIT_WINDOW_SECONDS", "9")

    client = nvd_client.NVDClient(api_key="secret")
    try:
        assert client._rate_limiter.max_requests == 7
        assert client._rate_limiter.window_seconds == 9
        assert client._http_client.headers["User-Agent"] == "nvd-cve-mcp-server/0.1.0"
        assert client._http_client.headers["apiKey"] == "secret"
    finally:
        client._http_client.close()


def test_request_retries_then_returns_payload(monkeypatch: pytest.MonkeyPatch) -> None:
    client = nvd_client.NVDClient(api_key=None)
    attempts: list[int] = []
    sleep_calls: list[float] = []

    monkeypatch.setattr(client._rate_limiter, "acquire", lambda: None)
    monkeypatch.setattr("nvd_cve_mcp_server.nvd_client.time.sleep", lambda seconds: sleep_calls.append(seconds))

    def fake_attempt(self: nvd_client.NVDClient, params: dict[str, Any], attempt: int) -> dict[str, Any]:
        attempts.append(attempt)
        if attempt == 0:
            raise nvd_client._RetryNeeded(0.25)
        return {"ok": True, "params": params}

    monkeypatch.setattr(nvd_client.NVDClient, "_attempt", fake_attempt)

    assert client._request({"q": 1}) == {"ok": True, "params": {"q": 1}}
    assert attempts == [0, 1]
    assert sleep_calls == [0.25]


def test_request_raises_after_retries_exhausted(monkeypatch: pytest.MonkeyPatch) -> None:
    client = nvd_client.NVDClient(api_key=None)

    monkeypatch.setattr(client._rate_limiter, "acquire", lambda: None)
    monkeypatch.setattr("nvd_cve_mcp_server.nvd_client.time.sleep", lambda _seconds: None)
    monkeypatch.setattr(
        nvd_client.NVDClient,
        "_attempt",
        lambda _self, _params, _attempt: (_ for _ in ()).throw(nvd_client._RetryNeeded(0.01)),
    )

    with pytest.raises(nvd_client.NVDAPIError, match="failed after retries"):
        client._request({})


def test_attempt_success_and_error_paths(monkeypatch: pytest.MonkeyPatch) -> None:
    client = nvd_client.NVDClient(api_key=None)

    monkeypatch.setattr(
        client,
        "_http_client",
        DummyHttpClient(lambda _url, _params: _make_response(200, b'{"ok": true}')),
    )
    assert client._attempt({"a": 1}, 0) == {"ok": True}

    retryable_response = _make_response(503, b"busy")
    monkeypatch.setattr(client, "_http_client", DummyHttpClient(lambda _url, _params: retryable_response))
    with pytest.raises(nvd_client._RetryNeeded):
        client._attempt({}, 0)

    with pytest.raises(nvd_client.NVDAPIError, match="status 503"):
        client._attempt({}, 3)

    def raise_timeout(_url: str, _params: dict[str, Any]) -> httpx.Response:
        raise httpx.TimeoutException("timed out")

    monkeypatch.setattr(client, "_http_client", DummyHttpClient(raise_timeout))
    with pytest.raises(nvd_client._RetryNeeded):
        client._attempt({}, 0)
    with pytest.raises(nvd_client.NVDAPIError, match="timed out"):
        client._attempt({}, 3)

    def raise_request_error(_url: str, _params: dict[str, Any]) -> httpx.Response:
        raise httpx.ConnectError("boom", request=httpx.Request("GET", nvd_client.NVD_BASE_URL))

    monkeypatch.setattr(client, "_http_client", DummyHttpClient(raise_request_error))
    with pytest.raises(nvd_client._RetryNeeded):
        client._attempt({}, 0)
    with pytest.raises(nvd_client.NVDAPIError, match="request error"):
        client._attempt({}, 3)

    monkeypatch.setattr(client, "_http_client", DummyHttpClient(lambda _url, _params: _make_response(200, b"not json")))
    with pytest.raises(nvd_client.NVDAPIError, match="invalid JSON"):
        client._attempt({}, 0)


def test_search_helpers_build_expected_request_parameters(monkeypatch: pytest.MonkeyPatch) -> None:
    client = nvd_client.NVDClient(api_key=None)
    captured: list[dict[str, Any]] = []

    def capture_request(_self: nvd_client.NVDClient, params: dict[str, Any]) -> dict[str, Any]:
        captured.append(params)
        return {"ok": True}

    monkeypatch.setattr(nvd_client.NVDClient, "_request", capture_request)

    assert client.search_cve_by_id("cve-2026-0001") == {"ok": True}
    assert client.search_cve_by_keyword("openssl", limit=5000) == {"ok": True}
    assert client.search_by_severity("high", limit=0) == {"ok": True}
    assert client.get_recent_cves(limit=9999, days_back=1) == {"ok": True}

    assert captured[0] == {"cveId": "CVE-2026-0001"}
    assert captured[1] == {"keywordSearch": "openssl", "resultsPerPage": 2000}
    assert captured[2] == {"cvssV3Severity": "HIGH", "resultsPerPage": 1}
    assert captured[3]["resultsPerPage"] == 2000
    assert "pubStartDate" in captured[3]
    assert "pubEndDate" in captured[3]


@pytest.mark.parametrize("days_back", [0, 121])
def test_search_keyword_rejects_invalid_date_ranges(days_back: int) -> None:
    client = nvd_client.NVDClient(api_key=None)

    with pytest.raises(nvd_client.NVDAPIError, match="days_back"):
        client.search_cve_by_keyword("openssl", days_back=days_back)


@pytest.mark.parametrize("days_back", [0, 121])
def test_recent_cves_rejects_invalid_date_ranges(days_back: int) -> None:
    client = nvd_client.NVDClient(api_key=None)

    with pytest.raises(nvd_client.NVDAPIError, match="days_back"):
        client.get_recent_cves(days_back=days_back)


def test_extract_primary_metric_prefers_newest_supported_version() -> None:
    metrics = {
        "cvssMetricV2": [{"cvssData": {"baseScore": 4.0, "vectorString": "v2"}, "baseSeverity": "LOW"}],
        "cvssMetricV30": [{"cvssData": {"baseScore": 6.0, "vectorString": "v30"}, "baseSeverity": "MEDIUM"}],
        "cvssMetricV31": [{"cvssData": {"baseScore": 8.0, "vectorString": "v31"}, "baseSeverity": "HIGH"}],
    }

    assert nvd_client._extract_primary_metric(metrics) == {"severity": "HIGH", "base_score": 8.0, "vector": "v31"}
    assert nvd_client._extract_primary_metric({}) == {"severity": None, "base_score": None, "vector": None}


def test_server_tools_cover_success_and_error_paths(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(server, "format_cve_response", lambda payload, limit: {"payload": payload, "limit": limit})

    class StubClient:
        def search_cve_by_id(self, cve_id: str) -> dict[str, Any]:
            assert cve_id == "CVE-1"
            return {"id": cve_id}

        def search_cve_by_keyword(self, keyword: str, limit: int, days_back: int | None) -> dict[str, Any]:
            assert (keyword, limit, days_back) == ("openssl", 5, 3)
            return {"keyword": keyword}

        def get_recent_cves(self, limit: int, days_back: int) -> dict[str, Any]:
            assert (limit, days_back) == (4, 2)
            return {"recent": True}

        def search_by_severity(self, severity: str, limit: int) -> dict[str, Any]:
            if severity == "HIGH":
                return {"severity": severity, "limit": limit}
            raise nvd_client.NVDAPIError("bad severity")

    monkeypatch.setattr(server, "_nvd_client", StubClient())

    assert server._error_response(ValueError("oops")) == {"success": False, "error": "oops"}
    assert server.search_cve_by_id("CVE-1") == {"success": True, "payload": {"id": "CVE-1"}, "limit": 1}
    assert server.search_cve_by_keyword("openssl", limit=5, days_back=3) == {
        "success": True,
        "payload": {"keyword": "openssl"},
        "limit": 5,
    }
    assert server.get_recent_cves(limit=4, days_back=2) == {
        "success": True,
        "payload": {"recent": True},
        "limit": 4,
    }
    assert server.search_by_severity(" high ", limit=7) == {
        "success": True,
        "payload": {"severity": "HIGH", "limit": 7},
        "limit": 7,
    }

    assert server.search_by_severity("invalid") == {
        "success": False,
        "error": "Invalid severity 'invalid'. Use one of: ['CRITICAL', 'HIGH', 'LOW', 'MEDIUM']",
    }


def test_server_tool_error_paths_and_main(monkeypatch: pytest.MonkeyPatch) -> None:
    class FailingClient:
        def search_cve_by_id(self, _cve_id: str) -> dict[str, Any]:
            raise nvd_client.NVDAPIError("id failed")

        def search_cve_by_keyword(self, keyword: str, limit: int, days_back: int | None) -> dict[str, Any]:
            raise nvd_client.NVDAPIError(f"keyword failed: {keyword}/{limit}/{days_back}")

        def get_recent_cves(self, limit: int, days_back: int) -> dict[str, Any]:
            raise nvd_client.NVDAPIError(f"recent failed: {limit}/{days_back}")

        def search_by_severity(self, severity: str, limit: int) -> dict[str, Any]:
            raise nvd_client.NVDAPIError(f"severity failed: {severity}/{limit}")

    run_calls: list[str] = []

    monkeypatch.setattr(server, "_nvd_client", FailingClient())
    monkeypatch.setattr(server.mcp, "run", lambda transport: run_calls.append(transport))

    assert server.search_cve_by_id("CVE-2") == {"success": False, "error": "id failed"}
    assert server.search_cve_by_keyword("curl", limit=2, days_back=None) == {
        "success": False,
        "error": "keyword failed: curl/2/None",
    }
    assert server.get_recent_cves(limit=1, days_back=7) == {
        "success": False,
        "error": "recent failed: 1/7",
    }
    assert server.search_by_severity("medium", limit=3) == {
        "success": False,
        "error": "severity failed: MEDIUM/3",
    }

    server.main()

    assert run_calls == ["stdio"]