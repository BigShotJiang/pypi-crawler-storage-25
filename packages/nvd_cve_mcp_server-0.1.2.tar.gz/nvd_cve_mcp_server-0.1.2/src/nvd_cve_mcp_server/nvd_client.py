"""NVD API v2.0 client with basic rate limiting and response formatting."""

from __future__ import annotations

import os
import random
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from typing import Any, cast

import httpx

NVD_BASE_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"
VALID_SEVERITIES = {"CRITICAL", "HIGH", "MEDIUM", "LOW"}
_NVD_MAX_DATE_RANGE_DAYS = 120  # NVD API rejects date windows larger than 120 days

# Status codes that warrant a retry (transient server-side problems).
_RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}
_MAX_RETRIES = 3
_RETRY_BASE_DELAY = 1.0  # seconds before first retry
_RETRY_MAX_DELAY = 60.0  # cap on any single sleep


class NVDAPIError(RuntimeError):
    """Raised when the NVD API request fails."""


class _RetryNeeded(Exception):
    """Internal signal that a request should be retried after `delay` seconds."""

    def __init__(self, delay: float) -> None:
        self.delay = delay


def _backoff_delay(attempt: int, response: httpx.Response | None) -> float:
    """Exponential backoff with jitter, honouring Retry-After when present."""
    if response is not None:
        retry_after = response.headers.get("Retry-After")
        if retry_after:
            try:
                return min(float(retry_after), _RETRY_MAX_DELAY)
            except ValueError:
                pass
    base = cast(float, min(_RETRY_BASE_DELAY * (2**attempt), _RETRY_MAX_DELAY))
    return base + random.uniform(0, base * 0.25)


class RateLimiter:
    """Simple sliding-window rate limiter for outbound API requests."""

    def __init__(self, max_requests: int, window_seconds: int) -> None:
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self._timestamps: deque[float] = deque()
        self._lock = threading.Lock()

    def acquire(self) -> None:
        """Blocks until a new request is allowed."""
        while True:
            now = time.monotonic()
            with self._lock:
                while self._timestamps and now - self._timestamps[0] >= self.window_seconds:
                    self._timestamps.popleft()

                if len(self._timestamps) < self.max_requests:
                    self._timestamps.append(now)
                    return

                wait_seconds = self.window_seconds - (now - self._timestamps[0])

            time.sleep(max(wait_seconds, 0.05))


@dataclass(slots=True)
class NVDClient:
    """Thin client wrapper around the NVD CVE API."""

    api_key: str | None = None
    timeout_seconds: float = 30.0
    _rate_limiter: RateLimiter = field(init=False, repr=False)
    _http_client: httpx.Client = field(init=False, repr=False)

    def __post_init__(self) -> None:
        if self.api_key:
            max_requests = int(os.getenv("NVD_RATE_LIMIT_REQUESTS", "50"))
            window_seconds = int(os.getenv("NVD_RATE_LIMIT_WINDOW_SECONDS", "30"))
        else:
            max_requests = int(os.getenv("NVD_RATE_LIMIT_REQUESTS", "5"))
            window_seconds = int(os.getenv("NVD_RATE_LIMIT_WINDOW_SECONDS", "30"))

        self._rate_limiter = RateLimiter(max_requests=max_requests, window_seconds=window_seconds)
        headers = {"User-Agent": "nvd-cve-mcp-server/0.1.0"}
        if self.api_key:
            headers["apiKey"] = self.api_key

        self._http_client = httpx.Client(
            timeout=self.timeout_seconds,
            headers=headers,
            # Retry at the TCP/connection level for transient network blips.
            transport=httpx.HTTPTransport(retries=1),
        )

    def _request(self, params: dict[str, Any]) -> dict[str, Any]:
        for attempt in range(_MAX_RETRIES + 1):
            self._rate_limiter.acquire()
            try:
                return self._attempt(params, attempt)
            except _RetryNeeded as exc:
                time.sleep(exc.delay)
        raise NVDAPIError("NVD API request failed after retries")  # pragma: no cover

    def _attempt(self, params: dict[str, Any], attempt: int) -> dict[str, Any]:
        """Single HTTP attempt; raises _RetryNeeded for transient errors or NVDAPIError for fatal ones."""
        try:
            response = self._http_client.get(NVD_BASE_URL, params=params)
            response.raise_for_status()
            return cast(dict[str, Any], response.json())
        except httpx.HTTPStatusError as exc:
            status = exc.response.status_code
            if status in _RETRYABLE_STATUS_CODES and attempt < _MAX_RETRIES:
                raise _RetryNeeded(_backoff_delay(attempt, exc.response)) from exc
            raise NVDAPIError(f"NVD API request failed with status {status}: {exc.response.text[:400]}") from exc
        except httpx.TimeoutException as exc:
            if attempt < _MAX_RETRIES:
                raise _RetryNeeded(_backoff_delay(attempt, None)) from exc
            raise NVDAPIError("NVD API request timed out") from exc
        except httpx.RequestError as exc:
            if attempt < _MAX_RETRIES:
                raise _RetryNeeded(_backoff_delay(attempt, None)) from exc
            raise NVDAPIError(f"NVD API request error: {exc}") from exc
        except ValueError as exc:
            raise NVDAPIError("NVD API returned invalid JSON") from exc

    def search_cve_by_id(self, cve_id: str) -> dict[str, Any]:
        return self._request({"cveId": cve_id.upper()})

    def search_cve_by_keyword(
        self,
        keyword: str,
        limit: int = 20,
        days_back: int | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {
            "keywordSearch": keyword,
            "resultsPerPage": max(1, min(limit, 2000)),
        }
        if days_back is not None:
            if days_back < 1:
                raise NVDAPIError("days_back must be >= 1")
            if days_back > _NVD_MAX_DATE_RANGE_DAYS:
                raise NVDAPIError(
                    f"days_back ({days_back}) exceeds the NVD API limit of {_NVD_MAX_DATE_RANGE_DAYS} days. "
                    "Use a smaller window or omit days_back to search without a date constraint."
                )
            now = datetime.now(UTC)
            params["pubStartDate"] = _format_nvd_datetime(now - timedelta(days=days_back))
            params["pubEndDate"] = _format_nvd_datetime(now)
        return self._request(params)

    def search_by_severity(self, severity: str, limit: int = 20) -> dict[str, Any]:
        normalized = severity.upper()
        if normalized not in VALID_SEVERITIES:
            raise NVDAPIError(f"Invalid severity '{severity}'. Use one of: {sorted(VALID_SEVERITIES)}")

        return self._request(
            {
                "cvssV3Severity": normalized,
                "resultsPerPage": max(1, min(limit, 2000)),
            }
        )

    def get_recent_cves(self, limit: int = 20, days_back: int = 7) -> dict[str, Any]:
        if days_back < 1:
            raise NVDAPIError("days_back must be >= 1")
        if days_back > _NVD_MAX_DATE_RANGE_DAYS:
            raise NVDAPIError(
                f"days_back ({days_back}) exceeds the NVD API limit of {_NVD_MAX_DATE_RANGE_DAYS} days. "
                "Use a smaller window or omit days_back to search without a date constraint."
            )

        now = datetime.now(UTC)
        start = now - timedelta(days=days_back)
        return self._request(
            {
                "pubStartDate": _format_nvd_datetime(start),
                "pubEndDate": _format_nvd_datetime(now),
                "resultsPerPage": max(1, min(limit, 2000)),
            }
        )


def _format_nvd_datetime(value: datetime) -> str:
    return value.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%S.000Z")


def format_cve_response(payload: dict[str, Any], limit: int | None = None) -> dict[str, Any]:
    """Normalize NVD API payload into a compact MCP-friendly response."""
    vulnerabilities = payload.get("vulnerabilities", [])
    items: list[dict[str, Any]] = []

    for item in vulnerabilities:
        cve = item.get("cve", {})
        metrics = cve.get("metrics", {})
        primary_metric = _extract_primary_metric(metrics)

        refs = []
        for ref in cve.get("references", []):
            url = ref.get("url")
            if url:
                refs.append(url)

        descriptions = cve.get("descriptions", [])
        english_description = next(
            (d.get("value", "") for d in descriptions if d.get("lang") == "en"),
            descriptions[0].get("value", "") if descriptions else "",
        )

        cwes = []
        for weakness in cve.get("weaknesses", []):
            for desc in weakness.get("description", []):
                value = desc.get("value")
                if value:
                    cwes.append(value)

        items.append(
            {
                "id": cve.get("id"),
                "published": cve.get("published"),
                "last_modified": cve.get("lastModified"),
                "description": english_description,
                "severity": primary_metric.get("severity"),
                "base_score": primary_metric.get("base_score"),
                "vector": primary_metric.get("vector"),
                "cwes": sorted(set(cwes)),
                "references": refs,
            }
        )

    items.sort(key=lambda x: x.get("published") or "", reverse=True)
    if limit is not None:
        items = items[:limit]

    return {
        "total_results": payload.get("totalResults", len(items)),
        "returned_results": len(items),
        "cves": items,
    }


def _extract_primary_metric(metrics: dict[str, Any]) -> dict[str, Any]:
    # Preferred order: CVSS v3.1, v3.0, then v2.
    ordered_keys = ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2")
    for key in ordered_keys:
        values = metrics.get(key, [])
        if not values:
            continue

        metric = values[0]
        cvss_data = metric.get("cvssData", {})
        return {
            "severity": metric.get("baseSeverity") or cvss_data.get("baseSeverity"),
            "base_score": cvss_data.get("baseScore"),
            "vector": cvss_data.get("vectorString"),
        }

    return {"severity": None, "base_score": None, "vector": None}
