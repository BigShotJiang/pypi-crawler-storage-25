"""MCP server exposing NVD CVE search tools over stdio transport."""

from __future__ import annotations

import os
from typing import Any

from mcp.server.fastmcp import FastMCP

from nvd_cve_mcp_server.nvd_client import (
    VALID_SEVERITIES,
    NVDAPIError,
    NVDClient,
    format_cve_response,
)

mcp = FastMCP("nvd-cve-mcp-server")
_nvd_client = NVDClient(api_key=os.getenv("NVD_API_KEY"))


def _error_response(error: Exception) -> dict[str, Any]:
    return {"success": False, "error": str(error)}


@mcp.tool()
def search_cve_by_id(cve_id: str) -> dict[str, Any]:
    """Search for a CVE by ID (example: CVE-2024-1234)."""
    try:
        payload = _nvd_client.search_cve_by_id(cve_id)
        return {"success": True, **format_cve_response(payload, limit=1)}
    except NVDAPIError as exc:
        return _error_response(exc)


@mcp.tool()
def search_cve_by_keyword(
    keyword: str,
    limit: int = 20,
    days_back: int | None = None,
) -> dict[str, Any]:
    """Search CVEs by product name or any keyword. Optionally limit to the last `days_back` days (max 120)."""
    try:
        payload = _nvd_client.search_cve_by_keyword(keyword=keyword, limit=limit, days_back=days_back)
        return {"success": True, **format_cve_response(payload, limit=limit)}
    except NVDAPIError as exc:
        return _error_response(exc)


@mcp.tool()
def get_recent_cves(limit: int = 20, days_back: int = 7) -> dict[str, Any]:
    """Fetch recent CVEs from the last `days_back` days (max 120 due to NVD API limit)."""
    try:
        payload = _nvd_client.get_recent_cves(limit=limit, days_back=days_back)
        return {"success": True, **format_cve_response(payload, limit=limit)}
    except NVDAPIError as exc:
        return _error_response(exc)


@mcp.tool()
def search_by_severity(severity: str, limit: int = 20) -> dict[str, Any]:
    """Filter CVEs by severity (CRITICAL, HIGH, MEDIUM, LOW)."""
    severity_upper = severity.upper().strip()
    if severity_upper not in VALID_SEVERITIES:
        return _error_response(ValueError(f"Invalid severity '{severity}'. Use one of: {sorted(VALID_SEVERITIES)}"))

    try:
        payload = _nvd_client.search_by_severity(severity=severity_upper, limit=limit)
        return {"success": True, **format_cve_response(payload, limit=limit)}
    except NVDAPIError as exc:
        return _error_response(exc)


def main() -> None:
    # stdio is the recommended MCP transport for desktop clients.
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
