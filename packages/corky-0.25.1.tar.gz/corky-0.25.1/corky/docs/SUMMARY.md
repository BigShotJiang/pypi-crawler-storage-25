# Summary

[Introduction](introduction.md)

# Getting Started

- [Installation](getting-started/installation.md)
- [Quick Start](getting-started/quick-start.md)
- [Configuration](getting-started/configuration.md)

# Guide

- [Commands](guide/commands.md)
- [File Formats](guide/file-formats.md)
- [Mailboxes](guide/mailboxes.md)
- [Contacts](guide/contacts.md)
- [Watch Daemon](guide/watch.md)
- [Sandboxing](guide/sandboxing.md)
- [Self-Hosted Gmail](guide/self-hosted-gmail.md)

# Development

- [Building](development/building.md)
- [Conventions](development/conventions.md)

# Reference

- [Specification](reference/specs.md)
- [Changelog](reference/changelog.md)
- [Privacy Policy](reference/privacy-policy.md)
- [Terms of Service](reference/terms-of-service.md)
