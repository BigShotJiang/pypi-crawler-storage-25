"""
locationformatter.py
────────────────────
Core module for the locationformatter package.

Provides:
  - LocationFormatter  — main entry-point class (load once, parse many times)
  - parse_location     — convenience function
  - clean_string       — text normalisation helper
  - clean_house_number — housenumber expansion helper
  - extract_house_and_bus_number — bus-number splitting helper
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from typing import List, Optional, Tuple

import torch
import torch.nn as nn
from transformers import (
    AutoTokenizer,
    PreTrainedModel,
    XLMRobertaConfig,
    XLMRobertaModel,
)
from transformers.modeling_outputs import ModelOutput
from torchcrf import CRF


# ── Label sets ────────────────────────────────────────────────────────────────

ENTITY_TYPES: List[str] = [
    "STREET", "ROAD", "HOUSENUMBER", "POSTCODE", "CITY", "PROVINCE",
    "BUILDING", "INTERSECTION", "PARCEL", "DISTRICT",
    "GRAVE_LOCATION", "DOMAIN_ZONE_AREA",
]
BIO_LABELS: List[str] = ["O"] + [f"{p}-{e}" for e in ENTITY_TYPES for p in ("B", "I")]
LOC_BIO_LABELS: List[str] = ["O", "B-LOCATION", "I-LOCATION"]
MAX_LENGTH: int = 256

_DEFAULT_REPO = "svercoutere/abb-dual-location-component-ner"


# ── Model architecture ────────────────────────────────────────────────────────

class DualNERConfig(XLMRobertaConfig):
    model_type = "dual_ner_xlm_roberta"

    def __init__(
        self,
        num_component_labels: int = len(BIO_LABELS),
        num_location_labels: int = len(LOC_BIO_LABELS),
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.num_component_labels = num_component_labels
        self.num_location_labels = num_location_labels


@dataclass
class DualNEROutput(ModelOutput):
    loss: Optional[torch.FloatTensor] = None
    component_logits: torch.FloatTensor = None
    location_logits: torch.FloatTensor = None


class DualHeadLocationNER(PreTrainedModel):
    config_class = DualNERConfig
    base_model_prefix = "roberta"

    def __init__(self, config: DualNERConfig):
        super().__init__(config)
        self.roberta = XLMRobertaModel(config, add_pooling_layer=False)
        self.dropout = nn.Dropout(config.hidden_dropout_prob)
        self.component_head = nn.Sequential(
            nn.Linear(config.hidden_size, 256),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(256, config.num_component_labels),
        )
        self.location_head = nn.Sequential(
            nn.Linear(config.hidden_size, 256),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(256, config.num_location_labels),
        )
        self.component_crf = CRF(config.num_component_labels, batch_first=True)
        self.location_crf = CRF(config.num_location_labels, batch_first=True)
        self.post_init()

    def forward(self, input_ids=None, attention_mask=None, **kwargs):
        h = self.dropout(
            self.roberta(
                input_ids=input_ids, attention_mask=attention_mask
            ).last_hidden_state
        )
        return DualNEROutput(
            component_logits=self.component_head(h),
            location_logits=self.location_head(h),
        )


# ── Text cleaning ─────────────────────────────────────────────────────────────

def clean_string(input_string: str) -> str:
    """Normalize whitespace and unicode in raw location text."""
    cleaned = input_string.replace("\n", " ").strip()
    cleaned = re.sub(r"\s+", " ", cleaned)
    cleaned = unicodedata.normalize("NFKD", cleaned)
    return cleaned


# ── House-number helpers ──────────────────────────────────────────────────────

def clean_house_number(housenumber: str) -> List[str]:
    """Expand a housenumber string into a list of individual number strings.

    Handles Dutch, English, and German variants:
      - numeric ranges         ``3-7``          → [3, 5, 7]
      - comma / conjunctions   ``1, 3``  ``1 en 3``  ``1 und 3``  ``1 and 3``  → [1, 3]
      - Dutch 'tot'            ``3 tot 7``      → [3, 4, 5, 6]   (exclusive end)
      - Dutch 't.e.m.'         ``3 t.e.m. 7``   → [3, 4, 5, 6, 7] (inclusive)
      - German 'bis'           ``3 bis 7``      → [3, 4, 5, 6, 7] (inclusive)
      - English 'to'/'through' ``3 to 7``       → [3, 4, 5, 6, 7] (inclusive)
      - slash notation         ``8/2``          → [8, 2]
      - descriptive words      huisnummer / nr / number / Hausnummer stripped
    """
    hn = housenumber.replace("  ", " ")
    # Normalise multi-word range keywords before splitting
    hn = re.sub(r"\btot en met\b", "t.e.m.", hn, flags=re.IGNORECASE)
    hn = re.sub(
        r"\b(huisnummer|huisnr|nr|nummer|number|hausnummer|hausnr)\b",
        "", hn, flags=re.IGNORECASE,
    )
    hn = re.sub(r"\s+", " ", hn).strip()

    # Split on comma or sequence conjunctions (word-boundary safe)
    parts = [
        item.strip()
        for item in re.split(r",|\b(?:en|und|and)\b", hn)
        if item and item.strip()
    ]
    result: List[str] = []

    for part in parts:
        part = part.strip()
        if not part:
            continue

        if "-" in part:
            segments = part.split("-")
            if len(segments) == 2:
                start_s, end_s = segments
                if start_s.strip().isdigit() and end_s.strip().isdigit():
                    start, end = int(start_s.strip()), int(end_s.strip())
                    if start < 1000 and end < 1000 and 0 < end - start < 20:
                        result.extend(map(str, range(start, end + 1, 2)))
                    else:
                        result.extend([str(start), str(end)])
                else:
                    result.extend([start_s.strip(), end_s.strip()])
            else:
                result.extend(seg.strip() for seg in segments if seg.strip())

        elif re.search(
            r"\bt\.e\.m\.\b|\btot\b|\bbis\b|\bto\b|\bthrough\b",
            part, flags=re.IGNORECASE,
        ):
            numbers = [num for num in re.split(r"\D+", part) if num]
            if len(numbers) == 2:
                start, end = int(numbers[0]), int(numbers[1])
                # Only Dutch 'tot' (without t.e.m.) is exclusive
                if (re.search(r"\btot\b", part, flags=re.IGNORECASE)
                        and not re.search(r"\bt\.e\.m\.\b", part, flags=re.IGNORECASE)):
                    end -= 1
                result.extend(map(str, range(start, end + 1)))
            else:
                result.append(part)

        elif "/" in part and not re.search(r"\bbus\b", part, flags=re.IGNORECASE):
            for seg in part.split("/"):
                seg = seg.strip()
                if seg:
                    result.append(seg)

        else:
            result.append(part)

    return result


# Sub-unit (apartment/mailbox) keywords across Dutch, English, and German.
# Using lookahead/lookbehind instead of \b to correctly handle dot-suffixed
# abbreviations like "apt." and "whg.".
_SUB_UNIT_RE = re.compile(
    r"(?<![\w])"
    r"(bus|apt\.?|appartement|apartment|unit|suite|flat"
    r"|wohnung|whg\.?|app\.?|top)"
    r"(?![\w])",
    flags=re.IGNORECASE,
)


def extract_house_and_bus_number(housenumber: str) -> dict:
    """Split a housenumber token into a base number and an optional sub-unit.

    Recognises sub-unit keywords in Dutch, English, and German:

    - Dutch:   ``bus``
    - English: ``apt`` / ``apt.`` / ``apartment`` / ``unit`` / ``suite`` / ``flat``
    - German:  ``wohnung`` / ``whg`` / ``whg.`` / ``app`` / ``app.`` / ``top`` (AT)

    Sub-unit values may be numeric or alphanumeric (e.g. ``3``, ``2A``, ``B``).

    Returns a dict with keys ``housenumber`` (str | None) and ``bus`` (str | None).

    Examples::

        >>> extract_house_and_bus_number("5 bus 3")
        {"housenumber": "5", "bus": "3"}
        >>> extract_house_and_bus_number("8 apt. 2A")
        {"housenumber": "8", "bus": "2A"}
        >>> extract_house_and_bus_number("12 Wohnung 4")
        {"housenumber": "12", "bus": "4"}
        >>> extract_house_and_bus_number("8/2")
        {"housenumber": "8", "bus": None}
    """
    bus_number: Optional[str] = None
    house_number: Optional[str] = None

    if _SUB_UNIT_RE.search(housenumber):
        # re.split with a capturing group returns [before, keyword, after]
        parts = _SUB_UNIT_RE.split(housenumber, maxsplit=1)
        before = parts[0].strip() if parts[0] else ""
        after  = parts[2].strip() if len(parts) > 2 else ""
        house_number = before or None
        bus_number   = after  or None
    else:
        house_number = housenumber.strip() or None

    if house_number and "/" in house_number:
        house_number = house_number.split("/")[0].strip() or None

    return {"housenumber": house_number, "bus": bus_number}


# ── Internal tokenisation / span extraction ───────────────────────────────────

def _tokenize_location(text: str) -> Tuple[List[str], List[Tuple[int, int]]]:
    tokens, offsets = [], []
    for m in re.finditer(r"[,;()\[\]{}]|[^\s,;()\[\]{}]+", text):
        tokens.append(m.group())
        offsets.append((m.start(), m.end()))
    return tokens, offsets


def _classify_housenumber_type(hn: str) -> str:
    hn = hn.strip()
    if re.search(r"\d\s*[-\u2013]\s*\d", hn):
        return "range"
    if re.search(r"[,;]|\band\b|\ben\b", hn):
        return "sequence"
    return "single"


# ── Conjunction merging ───────────────────────────────────────────────────────

_CONJUNCTION_GAP_RE = re.compile(
    r"^\s*,?\s*\b(?:and|en|und)\b\s*,?\s*$",
    re.IGNORECASE,
)


def _merge_split_locations(text: str, locations: List[dict]) -> None:
    """Propagate shared fields across adjacent locations split by conjunctions.

    When the model splits 'Street 23 and 25, 2000 City' into two location
    spans, the second loses the street and the first may lose postcode/city.
    This detects conjunction gaps, copies missing fields between neighbours,
    and unifies the ``location`` text so every entry carries the full span.
    """
    for i in range(len(locations) - 1):
        cur, nxt = locations[i], locations[i + 1]
        gap = text[cur["_char_end"]:nxt["_char_start"]]
        if not _CONJUNCTION_GAP_RE.match(gap):
            continue
        # Propagate street forward when the next span has a housenumber but no street
        if nxt.get("housenumber") and not nxt.get("street") and cur.get("street"):
            nxt["street"] = cur["street"]
        # Shared context fields: propagate bidirectionally
        for field in ("postcode", "city", "province"):
            if cur.get(field) and not nxt.get(field):
                nxt[field] = cur[field]
            elif nxt.get(field) and not cur.get(field):
                cur[field] = nxt[field]
        # Unify the location text: span from earliest start to latest end
        merged_start = min(cur["_char_start"], nxt["_char_start"])
        merged_end   = max(cur["_char_end"],   nxt["_char_end"])
        full_loc = text[merged_start:merged_end]
        cur["location"] = full_loc
        nxt["location"] = full_loc
        cur["_char_start"] = merged_start
        cur["_char_end"]   = merged_end
        nxt["_char_start"] = merged_start
        nxt["_char_end"]   = merged_end


def _extract_bio_spans(
    tokens: List[str],
    tag_ids: List[int],
    id2l: dict,
    offsets: List[Tuple[int, int]],
) -> List[dict]:
    spans, ent, start = [], None, 0
    for i, tid in enumerate(tag_ids):
        tag = id2l[tid]
        if tag.startswith("B-"):
            if ent is not None:
                spans.append({
                    "entity": ent, "start_tok": start, "end_tok": i - 1,
                    "char_start": offsets[start][0], "char_end": offsets[i - 1][1],
                })
            ent, start = tag[2:], i
        elif tag.startswith("I-") and ent == tag[2:]:
            pass
        else:
            if ent is not None:
                spans.append({
                    "entity": ent, "start_tok": start, "end_tok": i - 1,
                    "char_start": offsets[start][0], "char_end": offsets[i - 1][1],
                })
            ent = None
    if ent is not None:
        spans.append({
            "entity": ent, "start_tok": start, "end_tok": len(tokens) - 1,
            "char_start": offsets[start][0], "char_end": offsets[-1][1],
        })
    return spans


# ── Low-level inference ───────────────────────────────────────────────────────

def _predict(
    text: str,
    model: DualHeadLocationNER,
    tokenizer,
    id2label: dict,
    loc_id2label: dict,
    device: str,
) -> dict:
    """Run the dual NER model and return raw span groups (no expansion)."""
    text = clean_string(text)
    tokens, offsets = _tokenize_location(text)
    if not tokens:
        return {"original": text, "locations": []}

    enc = tokenizer(
        tokens, is_split_into_words=True, return_tensors="pt",
        truncation=True, max_length=MAX_LENGTH,
    )
    word_ids = enc.word_ids()

    with torch.no_grad():
        out = model(**{k: v.to(device) for k, v in enc.items()})

    mask = enc["attention_mask"].bool().to(device)
    cpreds = model.component_crf.decode(out.component_logits, mask=mask)[0]
    lpreds = model.location_crf.decode(out.location_logits, mask=mask)[0]

    wcomp, wloc, prev = [], [], None
    for idx, wid in enumerate(word_ids):
        if wid is None:
            continue
        if wid != prev:
            wcomp.append(cpreds[idx])
            wloc.append(lpreds[idx])
        prev = wid

    loc_spans  = _extract_bio_spans(tokens, wloc,  loc_id2label, offsets)
    comp_spans = _extract_bio_spans(tokens, wcomp, id2label,     offsets)

    locations, assigned = [], set()
    for ls in loc_spans:
        loc = {"location": text[ls["char_start"]:ls["char_end"]],
               "_char_start": ls["char_start"], "_char_end": ls["char_end"]}
        for ci, cs in enumerate(comp_spans):
            if cs["start_tok"] >= ls["start_tok"] and cs["end_tok"] <= ls["end_tok"]:
                loc[cs["entity"].lower()] = text[cs["char_start"]:cs["char_end"]]
                assigned.add(ci)
        if "housenumber" in loc:
            loc["housenumber_type"] = _classify_housenumber_type(loc["housenumber"])
        locations.append(loc)

    for ci, cs in enumerate(comp_spans):
        if ci not in assigned:
            loc = {
                "location": text[cs["char_start"]:cs["char_end"]],
                cs["entity"].lower(): text[cs["char_start"]:cs["char_end"]],
                "_char_start": cs["char_start"], "_char_end": cs["char_end"],
            }
            if "housenumber" in loc:
                loc["housenumber_type"] = _classify_housenumber_type(loc["housenumber"])
            locations.append(loc)

    _merge_split_locations(text, locations)
    for loc in locations:
        loc.pop("_char_start", None)
        loc.pop("_char_end", None)

    return {"original": text, "locations": locations}


# ── Post-processing: expand housenumbers ──────────────────────────────────────

def _expand_housenumbers(result: dict) -> dict:
    """Expand range/sequence housenumbers into individual address entries."""
    expanded: List[dict] = []

    for loc in result["locations"]:
        raw_hn = loc.get("housenumber")

        if not raw_hn:
            expanded.append(loc)
            continue

        hn_type = loc.get("housenumber_type", "single")

        if hn_type in ("range", "sequence"):
            for num in clean_house_number(raw_hn):
                hn_info = extract_house_and_bus_number(num)
                entry = {k: v for k, v in loc.items()
                         if k not in ("housenumber", "housenumber_type", "bus")}
                entry["housenumber"] = hn_info["housenumber"]
                entry["housenumber_type"] = "single"
                if hn_info["bus"]:
                    entry["bus"] = hn_info["bus"]
                expanded.append(entry)
        else:
            hn_info = extract_house_and_bus_number(raw_hn)
            entry = {k: v for k, v in loc.items()
                     if k not in ("housenumber", "bus")}
            entry["housenumber"] = hn_info["housenumber"]
            if hn_info["bus"]:
                entry["bus"] = hn_info["bus"]
            expanded.append(entry)

    return {"original": result["original"], "locations": expanded}


# ── Public API ────────────────────────────────────────────────────────────────

class LocationFormatter:
    """Load the dual-head NER model once and parse location strings.

    Parameters
    ----------
    repo:
        Hugging Face Hub repository ID (default: ``svercoutere/abb-dual-location-component-ner``).
    device:
        ``"cuda"`` or ``"cpu"``.  Auto-detected when *None*.

    Examples
    --------
    >>> from locationformatter import LocationFormatter
    >>> lf = LocationFormatter()
    >>> lf.parse("Scaldisstraat 23-25, 2000 Antwerpen")
    {'original': 'Scaldisstraat 23-25, 2000 Antwerpen',
     'locations': [{'location': ..., 'street': ..., 'housenumber': '23', ...}, ...]}
    """

    def __init__(
        self,
        repo: str = _DEFAULT_REPO,
        device: Optional[str] = None,
    ) -> None:
        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"
        self.device = device
        self._id2label = {i: l for i, l in enumerate(BIO_LABELS)}
        self._loc_id2label = {i: l for i, l in enumerate(LOC_BIO_LABELS)}

        config = DualNERConfig.from_pretrained(
            repo,
            num_component_labels=len(BIO_LABELS),
            num_location_labels=len(LOC_BIO_LABELS),
        )
        self._tokenizer = AutoTokenizer.from_pretrained(repo)
        self._model = DualHeadLocationNER.from_pretrained(repo, config=config)
        self._model.to(device).eval()

    def predict(self, text: str) -> dict:
        """Run the NER model and return raw span groups.

        Housenumber ranges are *not* expanded; the raw ``housenumber`` string
        and ``housenumber_type`` are returned as-is.

        Returns
        -------
        dict with keys ``original`` (str) and ``locations`` (list of dicts).
        """
        return _predict(
            text, self._model, self._tokenizer,
            self._id2label, self._loc_id2label, self.device,
        )

    def parse(self, text: str) -> dict:
        """Full pipeline: clean → NER → expand housenumbers.

        Housenumber ranges and sequences are expanded into individual entries,
        and bus numbers are split into a separate ``bus`` field.

        Returns
        -------
        dict with keys ``original`` (str) and ``locations`` (list of dicts).
        """
        raw = self.predict(text)
        return _expand_housenumbers(raw)


# ── Module-level convenience function ────────────────────────────────────────

def parse_location(
    text: str,
    repo: str = _DEFAULT_REPO,
    device: Optional[str] = None,
) -> dict:
    """One-shot helper — loads model, parses *text*, returns result.

    For repeated calls prefer instantiating :class:`LocationFormatter` directly
    to avoid reloading the model on every call.
    """
    formatter = LocationFormatter(repo=repo, device=device)
    return formatter.parse(text)
