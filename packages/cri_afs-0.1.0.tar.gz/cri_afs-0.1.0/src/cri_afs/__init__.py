"""
cri-afs — reader/writer for the CRI AFS archive format.

CRI AFS is the bulk archive format CRI Middleware shipped with their PS2 /
Dreamcast / GameCube authoring tools. A flat container of fixed-offset
sub-files (typically 0x800-aligned to CD sectors), with an optional
trailing filename TOC. Examples: Magna Carta: Tears of Blood, Burnout,
various Sega titles.

Usage:
    from cri_afs import Afs, write_afs

    afs = Afs.open("SHIP.AFS")
    names = afs.read_filename_toc()
    with open("SHIP.AFS", "rb") as fh:
        blob = afs.read_entry(0, fh)

    write_afs("OUT.AFS",
              [(n, b) for n, b in zip(names, payloads)],
              toc_metadata=afs.read_toc_metadata())
"""

from .container import (
    AFS_MAGIC,
    Afs,
    AfsEntry,
    SECTOR,
    classify,
    write_afs,
)

__version__ = "0.1.0"
__all__ = [
    "AFS_MAGIC",
    "Afs",
    "AfsEntry",
    "SECTOR",
    "classify",
    "write_afs",
]
