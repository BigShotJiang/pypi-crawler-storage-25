"""CLI for cri-afs.

Usage:
    # Inspect an AFS file
    python -m cri_afs info SHIP.AFS

    # Extract every sub-file to a directory (named by the trailing TOC if present)
    python -m cri_afs extract SHIP.AFS --out ship_extracted/

    # Pack a directory back into an AFS
    python -m cri_afs pack ship_extracted/ -o SHIP.AFS
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .container import Afs, classify, write_afs


def cmd_info(args: argparse.Namespace) -> int:
    afs = Afs.open(args.input)
    print(f"=== {args.input} ===")
    print(f"entries: {len(afs.entries)}  toc@{afs.toc_offset:#x} size={afs.toc_size}")
    names = afs.read_filename_toc()
    sample = list(range(min(12, len(afs.entries)))) + list(
        range(max(0, len(afs.entries) - 4), len(afs.entries))
    )
    seen: set[int] = set()
    with open(args.input, "rb") as fh:
        for i in sample:
            if i in seen:
                continue
            seen.add(i)
            e = afs.entries[i]
            magic = afs.sniff(i)
            tag = classify(magic)
            label = f" name={names[i]!r}" if names else ""
            print(
                f"  [{i:5d}] off={e.offset:#011x} size={e.size:>10d}  "
                f"{tag:<14}  head={magic[:12].hex()}{label}"
            )
        hist: dict[str, int] = {}
        for e in afs.entries:
            if e.size == 0:
                hist["empty"] = hist.get("empty", 0) + 1
                continue
            fh.seek(e.offset)
            tag = classify(fh.read(8))
            hist[tag] = hist.get(tag, 0) + 1
    print("type histogram:")
    for k, v in sorted(hist.items(), key=lambda kv: -kv[1]):
        print(f"  {k:<20s} {v}")
    return 0


def cmd_extract(args: argparse.Namespace) -> int:
    afs = Afs.open(args.input)
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    names = afs.read_filename_toc()
    with open(args.input, "rb") as fh:
        for i, e in enumerate(afs.entries):
            name = names[i] if names and names[i] else f"entry_{i:05d}.bin"
            (out_dir / name).write_bytes(afs.read_entry(i, fh))
    print(f"extracted {len(afs.entries)} entries to {out_dir}")
    return 0


def cmd_pack(args: argparse.Namespace) -> int:
    src_dir = Path(args.input)
    if not src_dir.is_dir():
        print(f"error: {src_dir} is not a directory", file=sys.stderr)
        return 1
    files = sorted(p for p in src_dir.iterdir() if p.is_file())
    entries = [(p.name, p.read_bytes()) for p in files]
    write_afs(args.output, entries)
    print(f"packed {len(entries)} files into {args.output}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(prog="cri-afs")
    sub = ap.add_subparsers(dest="cmd", required=True)

    i = sub.add_parser("info", help="show AFS file info")
    i.add_argument("input", type=Path)
    i.set_defaults(func=cmd_info)

    e = sub.add_parser("extract", help="extract every sub-file to a directory")
    e.add_argument("input", type=Path)
    e.add_argument("--out", type=Path, required=True)
    e.set_defaults(func=cmd_extract)

    p = sub.add_parser("pack", help="pack a directory of sub-files into an AFS")
    p.add_argument("input", type=Path)
    p.add_argument("-o", "--output", type=Path, required=True)
    p.set_defaults(func=cmd_pack)

    args = ap.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
