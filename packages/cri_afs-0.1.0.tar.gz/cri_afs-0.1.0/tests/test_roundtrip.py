"""Round-trip parser → writer == byte-identical for real CRI AFS archives.

These tests use the Magna Carta: Tears of Blood ISOs from the
`magna-carta-tears-of-blood-undub` work directory if present, since they
exercise the full TOC + metadata round-trip across three regions and four
archive shapes (SHIP, MUSIC, LINEAR, FILE). Skipped automatically when the
work files aren't available.
"""
from __future__ import annotations

import hashlib
from pathlib import Path

import pytest

from cri_afs import Afs, write_afs


WORK_ROOT = Path(
    "/Users/samuelzubaid/Workspace/magna-carta-tears-of-blood-undub/work"
)


def _candidates() -> list[Path]:
    out: list[Path] = []
    for region in ("usa", "kr", "jp"):
        for name in ("SHIP.AFS", "MUSIC.AFS", "LINEAR.AFS", "FILE.AFS"):
            p = WORK_ROOT / region / name
            if p.exists():
                out.append(p)
    return out


@pytest.mark.parametrize("src", _candidates(), ids=lambda p: f"{p.parent.name}/{p.name}")
def test_byte_identical_roundtrip(src: Path, tmp_path: Path) -> None:
    afs = Afs.open(src)
    names = afs.read_filename_toc()
    assert names is not None, f"{src}: missing filename TOC"
    md = afs.read_toc_metadata()
    assert md is not None, f"{src}: missing TOC metadata"

    with src.open("rb") as fh:
        entries = [(names[i], afs.read_entry(i, fh)) for i in range(len(afs.entries))]

    out = tmp_path / src.name
    try:
        write_afs(out, entries, toc_metadata=md)
        src_hash = hashlib.sha256(src.read_bytes()).hexdigest()
        out_hash = hashlib.sha256(out.read_bytes()).hexdigest()
        assert src.stat().st_size == out.stat().st_size, "size differs"
        assert src_hash == out_hash, "byte content differs"
    finally:
        # Reclaim disk eagerly — round-trip files can be 1.5 GB each, and
        # pytest's tmp_path cleanup is session-scoped, so without this
        # parallel cases pile up and fill the disk on a constrained host.
        if out.exists():
            out.unlink()


def test_classify_known_magic() -> None:
    from cri_afs import classify

    assert classify(b"\x80\x00\x00\x00") == "ADX"
    assert classify(b"AHX(") == "AHX"
    assert classify(b"RIFF") == "RIFF/WAV"
    assert classify(b"AFS\x00") == "AFS (nested)"
    assert classify(b"\x00\x00\x01\xba") == "MPEG-PS/SFD"
    assert classify(b"\x00\x00\x00\x00") == "zero/padding"
    assert classify(b"\xde\xad\xbe\xef") == "unknown(deadbeef)"
    assert classify(b"\xab") == "tiny"
