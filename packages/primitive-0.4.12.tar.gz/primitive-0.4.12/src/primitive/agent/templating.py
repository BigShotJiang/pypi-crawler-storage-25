import re
from typing import Any, Dict

_INPUT_EXPR = re.compile(r"\$\{\{\s*inputs\.([A-Za-z_][A-Za-z0-9_-]*)\s*\}\}")
_UNSAFE_ENV_CHAR = re.compile(r"[^A-Z0-9_]")


def input_env_var_name(name: str) -> str:
    """Return the shell-safe ``PRIMITIVE_INPUT_*`` env var name for ``name``.

    Input identifiers may legally contain hyphens (GitHub Actions parity), but
    POSIX shells can't reference env vars with non-``[A-Z0-9_]`` characters.
    Uppercase the name, then replace each unsafe character with ``_``.
    Different input names can collide after normalization (e.g. ``release-id``
    and ``release_id`` both map to ``PRIMITIVE_INPUT_RELEASE_ID``); callers
    should detect collisions and warn.
    """
    return "PRIMITIVE_INPUT_" + _UNSAFE_ENV_CHAR.sub("_", name.upper())


def stringify_input(value: Any) -> str:
    """Coerce a JobRun input value to its env-var/string representation.

    Booleans render as lowercase ``"true"``/``"false"`` to match common shell
    conventions and GitHub Actions semantics; everything else uses ``str()``.
    """
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


def expand_inputs(value: str, inputs: Dict[str, Any]) -> str:
    """Expand `${{ inputs.<name> }}` placeholders in ``value``.

    Unknown keys render as an empty string (GitHub Actions parity). Other
    `${{ ... }}` expressions (e.g. `${{ secrets.FOO }}`) are left untouched.
    """

    def _sub(match: "re.Match[str]") -> str:
        name = match.group(1)
        if name not in inputs:
            return ""
        return stringify_input(inputs[name])

    return _INPUT_EXPR.sub(_sub, value)
