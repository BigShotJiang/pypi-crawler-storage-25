from datetime import datetime, timezone

import click
from loguru import logger

from ..utils import power


@click.group()
def cli():
    """cross-platform system commands"""
    pass


@cli.command("reboot")
@click.pass_context
def reboot(context):
    """Restarts or reboots the system."""
    primitive = context.obj.get("PRIMITIVE") if context.obj else None
    if primitive is not None:
        try:
            details = primitive.hardware.get_own_hardware_details()
            hardware_id = details.get("id") if details else None
            if hardware_id:
                primitive.hardware.update_hardware(
                    hardware_id=hardware_id,
                    is_online=False,
                    is_rebooting=True,
                    start_rebooting_at=datetime.now(timezone.utc).isoformat(),
                )
        except Exception as e:
            # Never block the actual reboot on a backend-signal failure —
            # a wedged agent still needs to be able to cycle the box.
            logger.warning(f"Could not signal hardware reboot before rebooting: {e}")

    power.reboot()


@cli.command("halt")
def halt():
    """Instructs hardware to stop CPU functions."""

    power.halt()


@cli.command("poweroff")
def poweroff():
    """Instruct the system to power down."""

    power.poweroff()
