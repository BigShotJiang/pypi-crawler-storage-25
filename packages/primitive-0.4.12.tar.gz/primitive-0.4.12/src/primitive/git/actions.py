from pathlib import Path
import shutil
from subprocess import run, CalledProcessError

from gql import gql
from loguru import logger

from primitive.utils.actions import BaseAction

from ..utils.auth import guard
from .graphql.queries import github_app_token_query


def _head_matches_ref(source_dir: Path, git_ref: str) -> bool:
    """Return True iff `source_dir` is a git checkout whose HEAD resolves
    to the same commit as `git_ref`.

    Compares full SHAs on both sides so a branch name, tag, or short SHA
    passed as `git_ref` still works. Any git failure (not a repo, invalid
    ref, etc.) returns False so the caller falls back to a fresh clone.
    """
    if not (source_dir / ".git").exists():
        return False
    try:
        head = run(
            ["git", "rev-parse", "HEAD"],
            cwd=source_dir,
            capture_output=True,
            text=True,
            check=True,
        ).stdout.strip()
        target = run(
            ["git", "rev-parse", git_ref],
            cwd=source_dir,
            capture_output=True,
            text=True,
            check=True,
        ).stdout.strip()
    except (CalledProcessError, FileNotFoundError):
        return False
    return bool(head) and head == target


class Git(BaseAction):
    @guard
    def get_github_access_token(self) -> str:
        query = gql(github_app_token_query)
        filters = {}
        variables = {
            "filters": filters,
        }
        result = self.primitive.session.execute(
            query, variable_values=variables, get_execution_result=True
        )
        return result

    def download_git_repository_at_ref(
        self,
        git_repo_full_name: str,
        github_access_token: str,
        git_ref: str = "main",
        destination: Path = Path.cwd(),
    ) -> Path:
        logger.debug(f"Downloading source code from {git_repo_full_name} {git_ref}")

        url = (
            f"https://oauth2:{github_access_token}@github.com/{git_repo_full_name}.git"
        )
        source_dir = Path(destination).joinpath(git_repo_full_name.split("/")[-1])

        # If the destination already contains a checkout at the exact ref,
        # skip the clone. Lets Runner.setup() be safely re-run on resume
        # after a mid-run reboot without re-downloading the repository.
        if source_dir.exists():
            if _head_matches_ref(source_dir, git_ref):
                logger.info(
                    f"Source for {git_repo_full_name} already at ref {git_ref}; skipping clone"
                )
                return source_dir
            shutil.rmtree(path=source_dir)

        try:
            run(
                ["git", "clone", url, source_dir, "--no-checkout"],
                check=True,
                # stdout=DEVNULL,
                # stderr=DEVNULL,
            )
        except CalledProcessError:
            raise Exception("Failed to download repository")

        try:
            run(
                ["git", "checkout", git_ref],
                check=True,
                cwd=source_dir,
                # stdout=DEVNULL,
                # stderr=DEVNULL,
            )
        except CalledProcessError:
            # Clean up directory if checkout failed
            shutil.rmtree(path=source_dir)
            raise Exception("Failed to checkout ref")

        return source_dir
