job_run_update_mutation = """
mutation jobRunUpdate($input: JobRunUpdateInput!) {
    jobRunUpdate(input: $input) {
        ... on JobRun {
            id
            status
            conclusion
        }
    }
}
"""

job_run_step_start_mutation = """
mutation jobRunStepStart($input: JobRunStepInput!) {
    jobRunStepStart(input: $input) {
        ... on JobRun {
            id
            stepsStarted
            stepsCompleted
        }
        ... on OperationInfo {
            messages { kind message field code }
        }
    }
}
"""

job_run_step_complete_mutation = """
mutation jobRunStepComplete($input: JobRunStepInput!) {
    jobRunStepComplete(input: $input) {
        ... on JobRun {
            id
            stepsStarted
            stepsCompleted
        }
        ... on OperationInfo {
            messages { kind message field code }
        }
    }
}
"""

job_run_resume_mutation = """
mutation jobRunResume($input: JobRunResumeInput!) {
    jobRunResume(input: $input) {
        ... on JobRun {
            id
            status
            stepsStarted
            stepsCompleted
        }
        ... on OperationInfo {
            messages { kind message field code }
        }
    }
}
"""
