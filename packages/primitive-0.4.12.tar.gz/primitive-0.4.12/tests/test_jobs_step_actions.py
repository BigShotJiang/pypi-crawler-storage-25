from unittest.mock import MagicMock

import pytest

from primitive.client import Primitive


@pytest.fixture
def primitive_with_mock_session():
    p = Primitive(host="localhost", token="t", transport="aiohttp")
    p.session = MagicMock()
    p.session.execute = MagicMock(return_value=MagicMock(data={}))
    return p


def test_job_run_step_start_sends_correct_variables(primitive_with_mock_session):
    p = primitive_with_mock_session

    p.jobs.job_run_step_start(id="abc", step_index=2)

    call_args = p.session.execute.call_args
    variables = call_args.kwargs["variable_values"]
    assert variables == {"input": {"jobRunId": "abc", "stepIndex": 2}}


def test_job_run_step_complete_sends_correct_variables(primitive_with_mock_session):
    p = primitive_with_mock_session

    p.jobs.job_run_step_complete(id="abc", step_index=3)

    call_args = p.session.execute.call_args
    variables = call_args.kwargs["variable_values"]
    assert variables == {"input": {"jobRunId": "abc", "stepIndex": 3}}


def test_job_run_resume_sends_correct_variables(primitive_with_mock_session):
    p = primitive_with_mock_session

    p.jobs.job_run_resume(id="abc")

    call_args = p.session.execute.call_args
    variables = call_args.kwargs["variable_values"]
    assert variables == {"input": {"jobRunId": "abc"}}
