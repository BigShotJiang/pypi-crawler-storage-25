"""Regression tests for download_git_repository_at_ref idempotency.

Resume-after-reboot calls Runner.setup() a second time against a workspace
that already contains the job's source. The git download must short-circuit
when HEAD already matches the requested ref; otherwise resume pays a full
re-clone on every restart and — worse — transiently removes the tree.
"""

from pathlib import Path
from subprocess import run
from unittest.mock import patch

import pytest

from primitive.git.actions import Git, _head_matches_ref


@pytest.fixture
def real_repo(tmp_path: Path) -> tuple[Path, str]:
    """Initialise a real git checkout in tmp_path and return (path, head_sha)."""
    work = tmp_path / "sources" / "primitive-corp"
    work.mkdir(parents=True)
    run(["git", "init", "--initial-branch=main"], cwd=work, check=True)
    run(["git", "config", "user.email", "test@example.com"], cwd=work, check=True)
    run(["git", "config", "user.name", "Test"], cwd=work, check=True)
    (work / "README.md").write_text("hello\n")
    run(["git", "add", "README.md"], cwd=work, check=True)
    run(
        ["git", "commit", "-m", "initial", "--no-gpg-sign"],
        cwd=work,
        check=True,
    )
    sha = run(
        ["git", "rev-parse", "HEAD"],
        cwd=work,
        capture_output=True,
        text=True,
        check=True,
    ).stdout.strip()
    return work, sha


def test_head_matches_ref_detects_matching_sha(real_repo: tuple[Path, str]) -> None:
    work, sha = real_repo
    assert _head_matches_ref(work, sha) is True


def test_head_matches_ref_rejects_mismatched_sha(real_repo: tuple[Path, str]) -> None:
    work, _ = real_repo
    # A real-looking SHA that doesn't exist in this repo.
    assert _head_matches_ref(work, "0" * 40) is False


def test_head_matches_ref_rejects_non_repo(tmp_path: Path) -> None:
    plain = tmp_path / "not-a-repo"
    plain.mkdir()
    assert _head_matches_ref(plain, "deadbeef") is False


def test_skips_clone_when_head_already_matches_ref(
    real_repo: tuple[Path, str], tmp_path: Path
) -> None:
    work, sha = real_repo
    destination = work.parent  # sources/
    marker = work / "README.md"
    marker_contents = marker.read_text()

    git = Git.__new__(Git)

    # Spy on subprocess.run via the module-level binding. We expect zero
    # subprocess calls from download_git_repository_at_ref itself — the
    # _head_matches_ref helper goes through the real run() because we
    # only patch the call sites inside download_git_repository_at_ref
    # via `shutil.rmtree` asserts + a token-clone mock.
    with (
        patch("primitive.git.actions.shutil.rmtree") as rmtree_mock,
        patch("primitive.git.actions.run") as run_mock,
    ):
        # Force _head_matches_ref to use the *real* subprocess.run so it
        # can actually read HEAD; download_git_repository_at_ref itself
        # sees the mock.
        def _dispatch(*args, **kwargs):
            cmd = args[0] if args else kwargs.get("args", [])
            if len(cmd) >= 2 and cmd[:2] == ["git", "rev-parse"]:
                from subprocess import run as real_run

                return real_run(*args, **kwargs)
            # Any other invocation (clone/checkout) should not happen.
            raise AssertionError(f"unexpected subprocess call: {cmd}")

        run_mock.side_effect = _dispatch

        result = git.download_git_repository_at_ref(
            git_repo_full_name="primitive-corp/primitive-corp",
            github_access_token="not-used",
            git_ref=sha,
            destination=destination,
        )

    assert result == work
    rmtree_mock.assert_not_called()
    # Workspace still on disk, contents intact.
    assert marker.read_text() == marker_contents


def test_reclones_when_head_does_not_match_ref(
    real_repo: tuple[Path, str], tmp_path: Path
) -> None:
    work, _ = real_repo
    destination = work.parent

    git = Git.__new__(Git)

    with (
        patch("primitive.git.actions._head_matches_ref", return_value=False),
        patch("primitive.git.actions.shutil.rmtree") as rmtree_mock,
        patch("primitive.git.actions.run") as run_mock,
    ):
        run_mock.return_value = None  # clone + checkout are fire-and-forget

        git.download_git_repository_at_ref(
            git_repo_full_name="primitive-corp/primitive-corp",
            github_access_token="fake-token",
            git_ref="some-other-sha",
            destination=destination,
        )

    rmtree_mock.assert_called_once_with(path=work)
    # clone + checkout = two run() calls.
    assert run_mock.call_count == 2
    clone_argv = run_mock.call_args_list[0].args[0]
    assert clone_argv[:2] == ["git", "clone"]
    checkout_argv = run_mock.call_args_list[1].args[0]
    assert checkout_argv[:2] == ["git", "checkout"]
