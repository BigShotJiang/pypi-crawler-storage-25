import json
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from primitive.files.commands import cli


def _context(debug=False):
    primitive = MagicMock()
    return primitive, {"PRIMITIVE": primitive, "DEBUG": debug, "JSON": False}


class TestFileUploadCommand:
    """file_upload_command — behavioral tests via CliRunner."""

    def test_direct_success_prints_id_and_pk(self, tmp_path):
        test_file = tmp_path / "data.tar.gz"
        test_file.write_bytes(b"x" * 1024)
        primitive, ctx = _context()
        ctx["JSON"] = True
        primitive.files.upload_file_direct.return_value = {"id": "file-abc", "pk": "99"}

        result = CliRunner().invoke(
            cli, ["upload", str(test_file), "--direct"], obj=ctx
        )

        assert result.exit_code == 0
        output = json.loads(result.output)
        assert output["id"] == "file-abc"
        assert output["pk"] == "99"
        assert output["status"] == "uploaded"

    def test_api_success_prints_id_and_pk(self, tmp_path):
        test_file = tmp_path / "data.zip"
        test_file.write_bytes(b"x" * 512)
        primitive, ctx = _context()
        ctx["JSON"] = True
        primitive.files.upload_file_via_api.return_value = {"id": "file-xyz", "pk": "7"}

        result = CliRunner().invoke(cli, ["upload", str(test_file)], obj=ctx)

        assert result.exit_code == 0
        output = json.loads(result.output)
        assert output["id"] == "file-xyz"
        assert output["pk"] == "7"
        assert output["status"] == "uploaded"

    def test_direct_failure_logs_upload_path_and_file(self, tmp_path):
        test_file = tmp_path / "data.tar.gz"
        test_file.write_bytes(b"x" * 1024)
        primitive, ctx = _context()
        primitive.files.upload_file_direct.side_effect = Exception(
            "Upload incomplete: one or more parts failed"
        )

        with patch("primitive.files.commands.logger") as mock_logger:
            result = CliRunner().invoke(
                cli, ["upload", str(test_file), "--direct"], obj=ctx
            )

        assert result.exit_code == 1
        mock_logger.error.assert_called_once()
        error_msg = mock_logger.error.call_args[0][0]
        assert "[direct]" in error_msg
        assert "data.tar.gz" in error_msg
        assert "Upload incomplete" in error_msg

    def test_api_failure_logs_http_status(self, tmp_path):
        test_file = tmp_path / "large.zip"
        test_file.write_bytes(b"x" * 512)
        primitive, ctx = _context()
        primitive.files.upload_file_via_api.side_effect = Exception(
            "Upload failed: HTTP 413 from server. Body: Request Entity Too Large"
        )

        with patch("primitive.files.commands.logger") as mock_logger:
            result = CliRunner().invoke(cli, ["upload", str(test_file)], obj=ctx)

        assert result.exit_code == 1
        mock_logger.error.assert_called_once()
        error_msg = mock_logger.error.call_args[0][0]
        assert "[api]" in error_msg
        assert "HTTP 413" in error_msg

    def test_debug_mode_reraises_on_failure(self, tmp_path):
        test_file = tmp_path / "data.zip"
        test_file.write_bytes(b"x" * 512)
        primitive, ctx = _context(debug=True)
        primitive.files.upload_file_direct.side_effect = Exception("boom")

        with patch("primitive.files.commands.logger"):
            result = CliRunner().invoke(
                cli, ["upload", str(test_file), "--direct"], obj=ctx
            )

        assert result.exception is not None
        assert str(result.exception) == "boom"


class TestUploadFileViaApiResponseHandling:
    """upload_file_via_api — non-2xx and server-side error handling."""

    def _make_files(self):
        from primitive.files.actions import Files

        primitive = MagicMock()
        primitive.host_config = {
            "transport": "https",
            "host": "api.dev.primitive.tech",
        }
        primitive.session = MagicMock()
        return Files(primitive)

    def test_non_2xx_raises_with_status_and_body(self, tmp_path):
        test_file = tmp_path / "big.zip"
        test_file.write_bytes(b"x" * 100)

        mock_response = MagicMock()
        mock_response.ok = False
        mock_response.status_code = 413
        mock_response.text = "Request Entity Too Large"

        with patch("primitive.files.actions.create_requests_session") as mock_factory:
            mock_factory.return_value.post.return_value = mock_response
            with pytest.raises(Exception, match="HTTP 413"):
                self._make_files().upload_file_via_api(path=test_file)

    def test_success_returns_id_and_pk(self, tmp_path):
        test_file = tmp_path / "data.zip"
        test_file.write_bytes(b"x" * 100)

        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {
            "data": {"fileUpload": {"id": "file-999", "pk": "42"}}
        }

        with patch("primitive.files.actions.create_requests_session") as mock_factory:
            mock_factory.return_value.post.return_value = mock_response
            result = self._make_files().upload_file_via_api(path=test_file)

        assert result == {"id": "file-999", "pk": "42"}

    def test_graphql_messages_raise_exception(self, tmp_path):
        test_file = tmp_path / "data.zip"
        test_file.write_bytes(b"x" * 100)

        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {
            "data": {
                "fileUpload": {
                    "messages": [{"message": "File too large for organization quota"}]
                }
            }
        }

        with patch("primitive.files.actions.create_requests_session") as mock_factory:
            mock_factory.return_value.post.return_value = mock_response
            with pytest.raises(
                Exception, match="File too large for organization quota"
            ):
                self._make_files().upload_file_via_api(path=test_file)
