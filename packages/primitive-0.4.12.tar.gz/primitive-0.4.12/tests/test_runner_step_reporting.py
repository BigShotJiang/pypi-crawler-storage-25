from unittest.mock import MagicMock

import pytest


def _make_runner(run_task_result: bool):
    """Build a Runner instance with the minimum attributes needed by
    ``execute_job_run`` and a deterministic ``run_task`` coroutine.
    """
    from primitive.agent.runner import Runner

    primitive = MagicMock()
    # get_job_status must return a response shaped like the real GraphQL
    # result so the cancellation check inside execute_job_run passes.
    primitive.jobs.get_job_status.return_value = MagicMock(
        data={
            "jobRun": {
                "status": "in_progress",
                "conclusion": None,
            }
        }
    )

    runner = Runner.__new__(Runner)
    runner.primitive = primitive
    runner.config = {
        "executes": [
            {"label": "step-0", "cmd": "echo 0"},
            {"label": "step-1", "cmd": "echo 1"},
        ]
    }
    runner.job_run = {"id": "jr-1"}
    runner.job = {"slug": "test"}
    runner.initial_env = {}
    runner.modified_env = {}

    async def fake_run_task(_task):
        return run_task_result

    runner.run_task = MagicMock(side_effect=fake_run_task)
    return runner, primitive


@pytest.fixture
def runner_with_two_steps():
    return _make_runner(run_task_result=False)


def _step_indices(calls):
    return [c.kwargs.get("step_index", c.args[-1] if c.args else None) for c in calls]


def test_runner_fires_start_and_complete_per_step(runner_with_two_steps):
    runner, primitive = runner_with_two_steps

    runner.execute_job_run()

    assert _step_indices(primitive.jobs.job_run_step_start.call_args_list) == [0, 1]
    assert _step_indices(primitive.jobs.job_run_step_complete.call_args_list) == [
        0,
        1,
    ]


def test_runner_fires_start_but_not_complete_on_failure():
    runner, primitive = _make_runner(run_task_result=True)

    runner.execute_job_run()

    assert primitive.jobs.job_run_step_start.call_count == 1
    assert primitive.jobs.job_run_step_complete.call_count == 0


def test_runner_resumes_at_start_index(runner_with_two_steps):
    runner, primitive = runner_with_two_steps

    runner.execute_job_run(start_index=1)

    start_calls = primitive.jobs.job_run_step_start.call_args_list
    assert len(start_calls) == 1
    assert _step_indices(start_calls) == [1]
    assert _step_indices(primitive.jobs.job_run_step_complete.call_args_list) == [1]
