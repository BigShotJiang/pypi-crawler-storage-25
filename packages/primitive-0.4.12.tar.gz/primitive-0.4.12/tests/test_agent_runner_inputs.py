from unittest.mock import MagicMock, patch

from primitive.agent.templating import expand_inputs, input_env_var_name


class TestExpandInputs:
    def test_expands_known_string_input(self):
        assert expand_inputs("${{ inputs.release }}", {"release": "v1.5.0"}) == "v1.5.0"

    def test_expands_multiple_inputs_in_one_value(self):
        out = expand_inputs(
            "${{ inputs.release }}-${{ inputs.category }}",
            {"release": "v1", "category": "fast"},
        )
        assert out == "v1-fast"

    def test_boolean_true_renders_as_lowercase_string(self):
        assert expand_inputs("${{ inputs.dry_run }}", {"dry_run": True}) == "true"

    def test_boolean_false_renders_as_lowercase_string(self):
        assert expand_inputs("${{ inputs.dry_run }}", {"dry_run": False}) == "false"

    def test_number_renders_as_string(self):
        assert expand_inputs("${{ inputs.retries }}", {"retries": 3}) == "3"
        assert expand_inputs("${{ inputs.ratio }}", {"ratio": 1.5}) == "1.5"

    def test_unknown_input_renders_as_empty_string(self):
        assert expand_inputs("${{ inputs.missing }}", {"release": "v1"}) == ""

    def test_leaves_non_input_expressions_untouched(self):
        assert (
            expand_inputs("${{ secrets.FOO }}", {"release": "v1"})
            == "${{ secrets.FOO }}"
        )

    def test_literal_passes_through_unchanged(self):
        assert expand_inputs("no templating here", {"release": "v1"}) == (
            "no templating here"
        )

    def test_handles_whitespace_inside_braces(self):
        assert expand_inputs("${{   inputs.release   }}", {"release": "v1"}) == "v1"

    def test_no_inputs_dict(self):
        assert expand_inputs("${{ inputs.release }}", {}) == ""


class TestInputEnvVarName:
    def test_uppercases_simple_name(self):
        assert input_env_var_name("release") == "PRIMITIVE_INPUT_RELEASE"

    def test_replaces_hyphens_with_underscores(self):
        assert input_env_var_name("release-id") == "PRIMITIVE_INPUT_RELEASE_ID"

    def test_replaces_other_unsafe_chars(self):
        assert input_env_var_name("release.tag") == "PRIMITIVE_INPUT_RELEASE_TAG"

    def test_preserves_underscores(self):
        assert input_env_var_name("dry_run") == "PRIMITIVE_INPUT_DRY_RUN"

    def test_preserves_digits(self):
        assert input_env_var_name("v2_mode") == "PRIMITIVE_INPUT_V2_MODE"


def _make_job_run(inputs=None, config=None):
    return {
        "id": "JobRun:1",
        "pk": 1,
        "jobRunNumber": 1,
        "inputs": inputs if inputs is not None else {},
        "job": {"id": "Job:1", "pk": 1, "slug": "test", "name": "test"},
        "jobSettings": {
            "containerArgs": "",
            "rootDirectory": "",
            "config": config or {"executes": []},
        },
        "gitCommit": {"sha": "abc", "branch": "main", "repoFullName": "x/y"},
    }


def _make_runner(job_run):
    """Build a Runner without triggering hardware/secret fetches."""
    from primitive.agent.runner import Runner

    primitive = MagicMock()
    primitive.hardware.get_own_hardware_details.return_value = {"id": "HW:1"}
    primitive.hardware.get_hardware_secret.return_value = {}

    with (
        patch("primitive.agent.runner.logger"),
        patch("primitive.agent.runner.BatchedSink"),
    ):
        # max_log_size=0 disables file logging so we don't create a logs dir.
        return Runner(primitive=primitive, job_run=job_run, max_log_size=0)


class TestRunnerInputs:
    def test_inputs_default_to_empty_dict_when_missing(self):
        job_run = _make_job_run(inputs=None)
        job_run.pop("inputs")
        runner = _make_runner(job_run)
        assert runner.inputs == {}

    def test_inputs_default_to_empty_dict_when_none(self):
        runner = _make_runner(_make_job_run(inputs=None))
        assert runner.inputs == {}

    def test_inputs_populated_from_job_run(self):
        runner = _make_runner(_make_job_run(inputs={"release": "v1"}))
        assert runner.inputs == {"release": "v1"}


class TestBuildStepEnv:
    def test_returns_copy_when_task_has_no_env(self):
        runner = _make_runner(_make_job_run(inputs={"release": "v1"}))
        runner.modified_env = {"PATH": "/usr/bin", "EXISTING": "1"}

        step_env = runner._build_step_env({"label": "s", "cmd": "echo"})

        assert step_env == {"PATH": "/usr/bin", "EXISTING": "1"}
        # Mutating the returned dict must not leak back into modified_env.
        step_env["NEW"] = "x"
        assert "NEW" not in runner.modified_env

    def test_expands_input_placeholder_into_step_env(self):
        runner = _make_runner(_make_job_run(inputs={"release": "v1.5.0"}))
        runner.modified_env = {"PATH": "/usr/bin"}

        step_env = runner._build_step_env(
            {
                "label": "deploy",
                "cmd": "echo",
                "env": {"RELEASE": "${{ inputs.release }}"},
            }
        )

        assert step_env["RELEASE"] == "v1.5.0"
        assert step_env["PATH"] == "/usr/bin"

    def test_task_env_overrides_existing_env_for_step_only(self):
        runner = _make_runner(_make_job_run(inputs={}))
        runner.modified_env = {"RELEASE": "base-value"}

        step_env = runner._build_step_env(
            {
                "label": "s",
                "cmd": "echo",
                "env": {"RELEASE": "override"},
            }
        )

        assert step_env["RELEASE"] == "override"
        # modified_env is untouched between steps.
        assert runner.modified_env["RELEASE"] == "base-value"

    def test_non_string_task_env_values_are_stringified(self):
        runner = _make_runner(_make_job_run(inputs={}))
        runner.modified_env = {}

        step_env = runner._build_step_env(
            {"label": "s", "cmd": "echo", "env": {"RETRIES": 3}}
        )

        assert step_env["RETRIES"] == "3"

    def test_unknown_input_renders_empty_string_in_env(self):
        runner = _make_runner(_make_job_run(inputs={}))
        runner.modified_env = {}

        step_env = runner._build_step_env(
            {
                "label": "s",
                "cmd": "echo",
                "env": {"RELEASE": "${{ inputs.missing }}"},
            }
        )

        assert step_env["RELEASE"] == ""


class TestPrimitiveInputEnvInjection:
    """Runner.setup() injects PRIMITIVE_INPUT_<NAME> for every resolved input."""

    def _run_setup_with_inputs(self, inputs):
        runner = _make_runner(_make_job_run(inputs=inputs))

        # Stub external I/O in setup() so we only exercise env construction.
        runner.primitive.jobs.github_access_token_for_job_run.return_value = "tok"
        runner.primitive.git.download_git_repository_at_ref.return_value = MagicMock()
        runner.primitive.jobs.get_job_secrets_for_job_run.return_value = {}

        # The jobSettings.rootDirectory is empty string, so source_dir
        # resolves to the download dir. We only care about initial_env.
        with patch("primitive.agent.runner.get_sources_cache"):
            runner.setup()
        return runner

    def test_injects_uppercased_input_env_vars(self):
        runner = self._run_setup_with_inputs({"release": "v1", "category": "fast"})
        assert runner.initial_env["PRIMITIVE_INPUT_RELEASE"] == "v1"
        assert runner.initial_env["PRIMITIVE_INPUT_CATEGORY"] == "fast"

    def test_boolean_inputs_render_as_lowercase_strings(self):
        runner = self._run_setup_with_inputs({"dry_run": True, "force": False})
        assert runner.initial_env["PRIMITIVE_INPUT_DRY_RUN"] == "true"
        assert runner.initial_env["PRIMITIVE_INPUT_FORCE"] == "false"

    def test_number_inputs_stringified(self):
        runner = self._run_setup_with_inputs({"retries": 3})
        assert runner.initial_env["PRIMITIVE_INPUT_RETRIES"] == "3"

    def test_no_env_vars_injected_when_inputs_empty(self):
        runner = self._run_setup_with_inputs({})
        primitive_input_keys = [
            k for k in runner.initial_env if k.startswith("PRIMITIVE_INPUT_")
        ]
        assert primitive_input_keys == []

    def test_hyphenated_name_normalized_to_shell_safe_var(self):
        runner = self._run_setup_with_inputs({"release-id": "v1"})
        assert runner.initial_env["PRIMITIVE_INPUT_RELEASE_ID"] == "v1"
        assert "PRIMITIVE_INPUT_RELEASE-ID" not in runner.initial_env

    def test_colliding_names_warn_and_last_wins(self):
        with patch("primitive.agent.runner.logger") as mock_logger:
            runner = self._run_setup_with_inputs(
                {"release-id": "first", "release_id": "second"}
            )
        assert runner.initial_env["PRIMITIVE_INPUT_RELEASE_ID"] == "second"
        assert mock_logger.warning.called
