import urllib.error
from unittest.mock import MagicMock, patch

from primitive.hardware.actions import Hardware, _UNSET


def _make_hardware():
    hw = Hardware.__new__(Hardware)
    hw.primitive = MagicMock()
    hw._cached_ec2_instance_id = _UNSET
    return hw


def _mock_response(data: bytes):
    resp = MagicMock()
    resp.read.return_value = data
    resp.__enter__ = MagicMock(return_value=resp)
    resp.__exit__ = MagicMock(return_value=False)
    return resp


class TestGetEc2InstanceId:
    def test_returns_instance_id_on_ec2(self):
        hw = _make_hardware()
        token_resp = _mock_response(b"my-imds-token")
        meta_resp = _mock_response(b"i-0abc123def456789")

        def urlopen_side_effect(req, timeout=None):
            if req.get_method() == "PUT":
                return token_resp
            return meta_resp

        with patch("urllib.request.urlopen", side_effect=urlopen_side_effect):
            assert hw._get_ec2_instance_id() == "i-0abc123def456789"

    def test_strips_whitespace_from_response(self):
        hw = _make_hardware()
        token_resp = _mock_response(b"my-imds-token")
        meta_resp = _mock_response(b"  i-0abc123def456789\n")

        def urlopen_side_effect(req, timeout=None):
            if req.get_method() == "PUT":
                return token_resp
            return meta_resp

        with patch("urllib.request.urlopen", side_effect=urlopen_side_effect):
            assert hw._get_ec2_instance_id() == "i-0abc123def456789"

    def test_returns_none_on_token_request_timeout(self):
        hw = _make_hardware()
        with patch("urllib.request.urlopen", side_effect=TimeoutError):
            assert hw._get_ec2_instance_id() is None

    def test_returns_none_on_token_request_url_error(self):
        hw = _make_hardware()
        with patch(
            "urllib.request.urlopen",
            side_effect=urllib.error.URLError("connection refused"),
        ):
            assert hw._get_ec2_instance_id() is None

    def test_returns_none_on_metadata_request_failure(self):
        hw = _make_hardware()
        token_resp = _mock_response(b"my-imds-token")
        call_count = 0

        def urlopen_side_effect(req, timeout=None):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return token_resp
            raise urllib.error.URLError("metadata fetch failed")

        with patch("urllib.request.urlopen", side_effect=urlopen_side_effect):
            assert hw._get_ec2_instance_id() is None

    def test_returns_none_on_os_error(self):
        hw = _make_hardware()
        with patch(
            "urllib.request.urlopen",
            side_effect=OSError("network unreachable"),
        ):
            assert hw._get_ec2_instance_id() is None

    def test_returns_none_on_empty_response(self):
        hw = _make_hardware()
        token_resp = _mock_response(b"my-imds-token")
        meta_resp = _mock_response(b"")

        def urlopen_side_effect(req, timeout=None):
            if req.get_method() == "PUT":
                return token_resp
            return meta_resp

        with patch("urllib.request.urlopen", side_effect=urlopen_side_effect):
            assert hw._get_ec2_instance_id() is None


class TestEc2InstanceIdCaching:
    def test_imds_only_called_once_across_multiple_invocations(self):
        hw = _make_hardware()
        token_resp = _mock_response(b"my-imds-token")
        meta_resp = _mock_response(b"i-0abc123def456789")

        def urlopen_side_effect(req, timeout=None):
            if req.get_method() == "PUT":
                return token_resp
            return meta_resp

        with patch(
            "urllib.request.urlopen", side_effect=urlopen_side_effect
        ) as mock_urlopen:
            result1 = hw._get_ec2_instance_id()
            result2 = hw._get_ec2_instance_id()

        assert result1 == "i-0abc123def456789"
        assert result2 == "i-0abc123def456789"
        # PUT + GET = 2 calls on first invocation, 0 on second
        assert mock_urlopen.call_count == 2

    def test_none_result_is_also_cached(self):
        hw = _make_hardware()

        with patch("urllib.request.urlopen", side_effect=TimeoutError) as mock_urlopen:
            result1 = hw._get_ec2_instance_id()
            result2 = hw._get_ec2_instance_id()

        assert result1 is None
        assert result2 is None
        # Only 1 call on first invocation (token PUT fails), 0 on second
        assert mock_urlopen.call_count == 1


class TestSystemInfoIncludesEc2InstanceId:
    def test_system_info_contains_ec2_instance_id(self):
        hw = _make_hardware()
        hw._get_ec2_instance_id = MagicMock(return_value="i-0abc123def456789")
        hw._get_network_interfaces = MagicMock(return_value={})
        hw.primitive.gpu._get_gpu_config.return_value = {}

        with patch("primitive.hardware.actions.platform") as mock_platform:
            mock_platform.system.return_value = "Linux"
            mock_platform.platform.return_value = "Linux-5.15"
            mock_platform.node.return_value = "ip-10-0-1-42"
            mock_platform.release.return_value = "5.15.0"
            mock_platform.version.return_value = "#1 SMP"
            mock_platform.processor.return_value = "x86_64"
            mock_platform.machine.return_value = "x86_64"
            mock_platform.architecture.return_value = ("64bit", "ELF")
            mock_platform.os.cpu_count.return_value = 4
            mock_platform.freedesktop_os_release.return_value = {"ID": "amzn"}

            with patch.object(
                hw, "_get_ubuntu_values", return_value={"linux_machine_id": "abc123"}
            ):
                result = hw.get_system_info()

        assert result["ec2_instance_id"] == "i-0abc123def456789"
        assert result["name"] == "ip-10-0-1-42"
