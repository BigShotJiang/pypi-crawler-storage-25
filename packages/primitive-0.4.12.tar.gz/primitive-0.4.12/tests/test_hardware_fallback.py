from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from primitive.hardware.actions import Hardware
from primitive.hardware.commands import cli


class TestRegisterGuards:
    def _make_hardware(self):
        hw = Hardware.__new__(Hardware)
        hw.primitive = MagicMock()
        return hw

    def test_register_returns_false_when_data_is_none(self):
        """register() returns False when result.data is None."""
        hw = self._make_hardware()
        hw.get_system_info = MagicMock(return_value={})

        mock_result = MagicMock()
        mock_result.data = None
        hw.primitive.session.execute.return_value = mock_result

        assert hw.register() is False

    def test_register_returns_false_when_register_hardware_is_none(self):
        """register() returns False when registerHardware is null."""
        hw = self._make_hardware()
        hw.get_system_info = MagicMock(return_value={})

        mock_result = MagicMock()
        mock_result.data = {"registerHardware": None}
        hw.primitive.session.execute.return_value = mock_result

        assert hw.register() is False

    def test_register_returns_false_when_fingerprint_is_missing(self):
        """register() returns False when fingerprint is not in the response."""
        hw = self._make_hardware()
        hw.get_system_info = MagicMock(return_value={})

        mock_result = MagicMock()
        mock_result.data = {"registerHardware": {"messages": None, "fingerprint": None}}
        hw.primitive.session.execute.return_value = mock_result

        assert hw.register() is False


class TestCheckInHttpFallback:
    def _make_hardware(self):
        hw = Hardware.__new__(Hardware)
        hw.primitive = MagicMock()
        return hw

    def test_check_in_uses_messaging_when_ready(self):
        """check_in sends via messaging when ready and not forced to HTTP."""
        hw = self._make_hardware()
        hw.primitive.messaging.ready = True

        with patch.object(hw, "check_in_http") as mock_http:
            hw.check_in(is_online=True)
            hw.primitive.messaging.send_message.assert_called_once()
            mock_http.assert_not_called()

    def test_check_in_falls_back_to_http_on_messaging_failure(self):
        """check_in falls back to HTTP when messaging raises."""
        hw = self._make_hardware()
        hw.primitive.messaging.ready = True
        hw.primitive.messaging.send_message.side_effect = ConnectionRefusedError(
            "refused"
        )

        with patch.object(hw, "check_in_http") as mock_http:
            hw.check_in(is_online=True, is_healthy=True)
            mock_http.assert_called_once_with(
                is_healthy=True,
                is_quarantined=False,
                is_available=False,
                is_online=True,
                stopping_agent=False,
            )

    def test_check_in_uses_http_when_messaging_not_ready(self):
        """check_in goes straight to HTTP when messaging is not ready."""
        hw = self._make_hardware()
        hw.primitive.messaging.ready = False

        with patch.object(hw, "check_in_http") as mock_http:
            hw.check_in(is_online=True)
            mock_http.assert_called_once()

    def test_check_in_uses_http_when_http_flag_set(self):
        """check_in uses HTTP when http=True regardless of messaging state."""
        hw = self._make_hardware()
        hw.primitive.messaging.ready = True

        with patch.object(hw, "check_in_http") as mock_http:
            hw.check_in(is_online=True, http=True)
            mock_http.assert_called_once()
            hw.primitive.messaging.send_message.assert_not_called()


class TestRegisterCommandCertificate:
    """Verify that register always issues a certificate after successful registration."""

    def _invoke_register(self, args=None):
        runner = CliRunner()
        mock_primitive = MagicMock()
        mock_primitive.hardware.register.return_value = MagicMock(
            data={"registerHardware": {"id": "abc123", "pk": 1}}
        )
        mock_primitive.hardware.certificate_create.return_value = MagicMock(
            certificate_pem="-----BEGIN CERTIFICATE-----\ntest\n-----END CERTIFICATE-----"
        )

        with (
            patch(
                "primitive.hardware.commands.generate_csr_pem", return_value="csr-pem"
            ) as mock_csr,
            patch("primitive.hardware.commands.write_certificate_pem") as mock_write,
        ):
            result = runner.invoke(
                cli,
                args or ["register"],
                obj={"PRIMITIVE": mock_primitive, "JSON": False, "DEBUG": False},
            )
            return result, mock_primitive, mock_csr, mock_write

    def test_register_always_issues_certificate(self):
        """register command issues a certificate without any flags."""
        result, mock_primitive, mock_csr, mock_write = self._invoke_register()
        assert result.exit_code == 0
        mock_primitive.hardware.certificate_create.assert_called_once()
        mock_csr.assert_called_once_with(hardware_id=1)
        mock_write.assert_called_once()

    def test_register_does_not_accept_issue_certificate_flag(self):
        """--issue-certificate flag has been removed."""
        result, _, _, _ = self._invoke_register(["register", "--issue-certificate"])
        assert result.exit_code != 0
