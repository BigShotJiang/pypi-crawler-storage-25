import asyncio
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from primitive.operating_systems.exceptions import P_CLI_201

from tests.test_agent_runner_inputs import _make_job_run, _make_runner


def _pxeboot_task(cmd: str = 'pxeboot "${OPERATING_SYSTEM}"') -> dict:
    return {
        "label": "PXE Boot",
        "workdir": "",
        "tags": {},
        "cmd": cmd,
        "env": {"OPERATING_SYSTEM": "${{ inputs.operating_system }}"},
    }


def _runner_with_pxe_setup(inputs, hardware_default_os_slug=None):
    """Build a Runner with target_hardware/secret populated so the pxeboot
    branch is taken, and with all downstream I/O stubbed out."""
    runner = _make_runner(_make_job_run(inputs=inputs))

    default_os: dict = {}
    if hardware_default_os_slug is not None:
        default_os = {
            "slug": hardware_default_os_slug,
            "isoFile": {"fileName": "hw-default.iso"},
        }
    runner.target_hardware = {
        "organization": {"id": "Org:1"},
        "defaultOperatingSystem": default_os,
        "defaultMacAddress": "AA:BB:CC:DD:EE:FF",
        "slug": "target-hw",
        "defaultBmcIpv4Address": "10.0.0.2",
        "defaultIpv4Address": "10.0.0.3",
    }
    runner.target_hardware_id = "HW:2"
    runner.target_hardware_secret = {
        "username": "user",
        "password": "pass",
    }

    # Stub VLAN IP resolution and token creation so they succeed by default.
    runner.primitive.hardware.get_ip_address.return_value = "10.0.0.1"

    token_result = MagicMock()
    token_result.data = {"authenticationTokenCreate": {"key": "tok"}}
    runner.primitive.auth.acreate_token = AsyncMock(return_value=token_result)
    runner.primitive.hardware.aupdate_hardware = AsyncMock()

    return runner


def _run(coro):
    return asyncio.run(coro)


class TestPxebootBranchMatch:
    def test_new_cmd_form_takes_pxeboot_branch(self):
        """Regression guard: `pxeboot "${OPERATING_SYSTEM}"` still matches."""
        runner = _runner_with_pxe_setup(
            inputs={"operating_system": "ubuntu-22-04"},
        )
        runner.primitive.operating_systems._get_organization_or_global_operating_system.return_value = (
            {"slug": "ubuntu-22-04", "isoFile": {"fileName": "ubuntu.iso"}},
            False,
        )

        with (
            patch("primitive.agent.runner.pxe_boot"),
            patch("primitive.agent.runner.wait_for_ssh"),
            patch("primitive.agent.runner.time.sleep"),
        ):
            failed = _run(runner.run_task(_pxeboot_task()))

        assert failed is False
        runner.primitive.operating_systems._get_organization_or_global_operating_system.assert_called_once_with(
            organization_id="Org:1", slug="ubuntu-22-04"
        )
        runner.primitive.operating_systems._prepare_operating_system_for_pxe.assert_called_once()

    def test_pxebootctl_does_not_false_match(self):
        """`pxebootctl` must NOT trip the pxeboot branch — first-token equality."""
        runner = _runner_with_pxe_setup(inputs={})
        runner.source_dir = Path("/tmp")

        # Force the sshpass fall-through path to bail out cleanly so we can
        # detect "fell through to subprocess" without actually spawning one.
        with (
            patch(
                "primitive.agent.runner.asyncio.create_subprocess_exec",
                new=AsyncMock(side_effect=RuntimeError("subprocess fallthrough")),
            ),
            patch("primitive.agent.runner.pxe_boot") as mock_pxe_boot,
        ):
            with pytest.raises(RuntimeError, match="subprocess fallthrough"):
                _run(runner.run_task(_pxeboot_task(cmd="pxebootctl foo")))

        # Confirm the pxeboot special-case never triggered.
        mock_pxe_boot.assert_not_called()
        runner.primitive.operating_systems._get_organization_or_global_operating_system.assert_not_called()


class TestPxebootSlugFromInputs:
    def test_happy_path_uses_slug_from_inputs_and_iso_from_lookup(self):
        runner = _runner_with_pxe_setup(
            inputs={"operating_system": "ubuntu-22-04"},
            hardware_default_os_slug="should-not-be-used",
        )
        runner.primitive.operating_systems._get_organization_or_global_operating_system.return_value = (
            {"slug": "ubuntu-22-04", "isoFile": {"fileName": "ubuntu.iso"}},
            False,
        )

        with (
            patch("primitive.agent.runner.pxe_boot"),
            patch("primitive.agent.runner.wait_for_ssh"),
            patch("primitive.agent.runner.time.sleep"),
        ):
            failed = _run(runner.run_task(_pxeboot_task()))

        assert failed is False
        call = runner.primitive.operating_systems._prepare_operating_system_for_pxe.call_args
        assert call.kwargs["operating_system_slug"] == "ubuntu-22-04"
        assert call.kwargs["iso_filename"] == "ubuntu.iso"

    def test_uses_server_returned_slug_over_input_slug(self):
        """Server-returned slug is authoritative (handles any normalization)."""
        runner = _runner_with_pxe_setup(
            inputs={"operating_system": "Ubuntu-22-04"},
        )
        runner.primitive.operating_systems._get_organization_or_global_operating_system.return_value = (
            {"slug": "ubuntu-22-04", "isoFile": {"fileName": "ubuntu.iso"}},
            False,
        )

        with (
            patch("primitive.agent.runner.pxe_boot"),
            patch("primitive.agent.runner.wait_for_ssh"),
            patch("primitive.agent.runner.time.sleep"),
        ):
            _run(runner.run_task(_pxeboot_task()))

        call = runner.primitive.operating_systems._prepare_operating_system_for_pxe.call_args
        assert call.kwargs["operating_system_slug"] == "ubuntu-22-04"


class TestPxebootFailsOnMissingOrUnknownSlug:
    def test_missing_slug_fails_task(self):
        runner = _runner_with_pxe_setup(inputs={})

        with patch("primitive.agent.runner.pxe_boot") as mock_pxe_boot:
            failed = _run(runner.run_task(_pxeboot_task()))

        assert failed is True
        mock_pxe_boot.assert_not_called()
        runner.primitive.operating_systems._prepare_operating_system_for_pxe.assert_not_called()
        runner.primitive.operating_systems._get_organization_or_global_operating_system.assert_not_called()

    def test_empty_string_slug_fails_task(self):
        runner = _runner_with_pxe_setup(inputs={"operating_system": ""})

        with patch("primitive.agent.runner.pxe_boot") as mock_pxe_boot:
            failed = _run(runner.run_task(_pxeboot_task()))

        assert failed is True
        mock_pxe_boot.assert_not_called()
        runner.primitive.operating_systems._prepare_operating_system_for_pxe.assert_not_called()
        runner.primitive.operating_systems._get_organization_or_global_operating_system.assert_not_called()

    def test_unknown_slug_fails_task(self):
        runner = _runner_with_pxe_setup(
            inputs={"operating_system": "nonexistent-os"},
        )
        runner.primitive.operating_systems._get_organization_or_global_operating_system.side_effect = P_CLI_201(
            message="No operating system found for slug nonexistent-os."
        )

        with patch("primitive.agent.runner.pxe_boot") as mock_pxe_boot:
            failed = _run(runner.run_task(_pxeboot_task()))

        assert failed is True
        mock_pxe_boot.assert_not_called()
        runner.primitive.operating_systems._prepare_operating_system_for_pxe.assert_not_called()

    def test_no_fallback_to_hardware_default_when_inputs_empty(self):
        """Even with a valid `defaultOperatingSystem` on the hardware, an
        empty inputs slug must fail the task — no silent fallback."""
        runner = _runner_with_pxe_setup(
            inputs={},
            hardware_default_os_slug="ubuntu-22-04",
        )

        with patch("primitive.agent.runner.pxe_boot") as mock_pxe_boot:
            failed = _run(runner.run_task(_pxeboot_task()))

        assert failed is True
        mock_pxe_boot.assert_not_called()
        runner.primitive.operating_systems._get_organization_or_global_operating_system.assert_not_called()
