from unittest.mock import MagicMock, patch

from click.testing import CliRunner


def test_system_reboot_signals_backend_before_rebooting():
    from primitive.system.commands import cli as system_cli

    primitive = MagicMock()
    primitive.hardware.get_own_hardware_details.return_value = {"id": "hw-1"}

    order = []

    def record_update(**kwargs):
        order.append(("update", kwargs))

    def record_reboot():
        order.append(("reboot",))

    primitive.hardware.update_hardware.side_effect = record_update

    with patch("primitive.system.commands.power.reboot", side_effect=record_reboot):
        runner = CliRunner()
        result = runner.invoke(system_cli, ["reboot"], obj={"PRIMITIVE": primitive})

    assert result.exit_code == 0, result.output
    assert [name for name, *_ in order] == ["update", "reboot"]
    update_kwargs = order[0][1]
    assert update_kwargs.get("is_rebooting") is True
    assert update_kwargs.get("is_online") is False
    assert update_kwargs.get("hardware_id") == "hw-1"
    assert "start_rebooting_at" in update_kwargs


def test_system_reboot_still_reboots_if_signal_fails():
    """If the backend signal raises, the reboot must still happen so a stuck
    agent can still clear the box."""
    from primitive.system.commands import cli as system_cli

    primitive = MagicMock()
    primitive.hardware.get_own_hardware_details.return_value = {"id": "hw-1"}
    primitive.hardware.update_hardware.side_effect = RuntimeError("boom")

    reboot_called = []

    with patch(
        "primitive.system.commands.power.reboot",
        side_effect=lambda: reboot_called.append(True),
    ):
        runner = CliRunner()
        result = runner.invoke(system_cli, ["reboot"], obj={"PRIMITIVE": primitive})

    assert result.exit_code == 0, result.output
    assert reboot_called == [True]


def test_system_reboot_works_without_primitive_context():
    """reboot remains callable outside the normal CLI context (e.g. in tests
    or ad-hoc invocations) — a missing primitive client must not block the
    actual power.reboot() call."""
    from primitive.system.commands import cli as system_cli

    with patch("primitive.system.commands.power.reboot") as mock_reboot:
        runner = CliRunner()
        result = runner.invoke(system_cli, ["reboot"], obj={})

    assert result.exit_code == 0, result.output
    mock_reboot.assert_called_once()
