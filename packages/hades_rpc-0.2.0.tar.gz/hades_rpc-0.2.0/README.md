# hades-rpc

Python client and tooling for the Hades RPC framework.

## Migration from 0.1.x to 0.2.0

The internal layout was reorganised to remove duplication and a god class.
The CLI surface (`hades` console script and its subcommands) is unchanged,
but several Python imports moved or were renamed:

| Old (0.1.x)                                          | New (0.2.0)                                          |
| ---------------------------------------------------- | ---------------------------------------------------- |
| `hades_rpc.rpc.rpc.Hades`                          | `hades_rpc.rpc.client.HadesClient`                 |
| `hades_rpc.rpc.rpc.HadesRPCEndpoint`               | `hades_rpc.rpc.sessions.ServiceSession`            |
| `hades_rpc.rpc.protocol.HadesEndpoint`             | `hades_rpc.rpc.sessions.ProtocolSession`           |
| `hades_rpc.rpc.protocol.HadesProtocol`             | `hades_rpc.rpc.protocol.HadesProtocol` (unchanged) |
| `hades_rpc.rpc.protocol.HadesProtocolVersion`      | `hades_rpc.rpc.protocol.HadesProtocolVersion`      |
| `hades_rpc.rpc.transports.transport`               | `hades_rpc.rpc.transports.base`                    |
| `hades_rpc.apps.hades:app`                         | `hades_rpc.apps.main:app`                          |
| `hades_rpc.apps.shell.message_to_json`             | `hades_rpc.rpc.json_utils.message_to_json`         |
| `hades_rpc.apps.rpc._build_request`                | `hades_rpc.rpc.request_builder.build_request`      |

The wire-protocol version (`HadesClient.HADES_VERSION`) is unchanged.
