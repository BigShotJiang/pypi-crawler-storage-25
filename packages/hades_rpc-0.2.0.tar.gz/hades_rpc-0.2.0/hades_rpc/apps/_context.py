"""Per-Typer-app context shared between the callback and its commands."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class AppContext:
    connection: Optional[Any] = None
    service_definition: Optional[str] = None
    extras: dict = field(default_factory=dict)
