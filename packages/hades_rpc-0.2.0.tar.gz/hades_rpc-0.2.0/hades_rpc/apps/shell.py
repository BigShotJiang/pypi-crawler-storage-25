"""Interactive REPL for invoking Hades RPC methods.

This module is intentionally free of Typer wiring so that ``HadesShell`` can
be exercised directly from tests without spinning up a transport.
"""

from __future__ import annotations

import shlex
import sys
import time
from pathlib import Path
from typing import Callable, List, Optional

from hades_rpc.rpc.client import HadesClient
from hades_rpc.rpc.formatters import render_tree
from hades_rpc.rpc.json_utils import message_to_json
from hades_rpc.rpc.protocol import HadesProtocolVersion
from hades_rpc.rpc.request_builder import build_request as default_build_request
from hades_rpc.rpc.service_tree import Method, Namespace, build_subtree_dict


HELP_TEXT = """\
Commands inside the shell:
  <method> [args...]   Invoke an RPC. Resolved relative to the current
                       namespace; use a leading '/' for absolute paths.
  <namespace>          Bare namespace path enters that namespace.
  ..                   Go up one level.
  /                    Return to root.
  ls [path]            Show the subtree rooted at the current (or given)
                       namespace, including method signatures.
  help                 Show help.
  quit | exit          Leave the shell (Ctrl-D / Ctrl-Z+Enter also works).
"""

BANNER = (
    "\n"
    "    ┌──────────────────────────────────────────────────┐\n"
    "    │                                                  │\n"
    "    │  ██╗  ██╗  █████╗  ██████╗  ███████╗ ███████╗    │\n"
    "    │  ██║  ██║ ██╔══██╗ ██╔══██╗ ██╔════╝ ██╔════╝    │\n"
    "    │  ███████║ ███████║ ██║  ██║ █████╗   ███████╗    │\n"
    "    │  ██╔══██║ ██╔══██║ ██║  ██║ ██╔══╝   ╚════██║    │\n"
    "    │  ██║  ██║ ██║  ██║ ██████╔╝ ███████╗ ███████║    │\n"
    "    │  ╚═╝  ╚═╝ ╚═╝  ╚═╝ ╚═════╝  ╚══════╝ ╚══════╝    │\n"
    "    │                                                  │\n"
    "    └──────────────────────────────────────────────────┘\n"
)


class HadesShell:
    """REPL that dispatches commands against a connected Hades service tree."""

    BUILTIN_COMMANDS = ("ls", "help", "quit", "exit")

    def __init__(
        self,
        service_tree: Namespace,
        request_builder: Callable[[type, List[str]], dict] = default_build_request,
        *,
        timing: bool = False,
        history_path: Optional[Path] = None,
        stdin=None,
        stdout=None,
        stderr=None,
    ):
        self.tree = service_tree
        self._build_request = request_builder
        self.timing = timing
        self.history_path = history_path or (Path.home() / ".hades" / "shell_history")
        self.stdin = stdin or sys.stdin
        self.stdout = stdout or sys.stdout
        self.stderr = stderr or sys.stderr
        self.path_stack: List[str] = []

    # ------------------------------------------------------------------ #
    # Tree introspection                                                 #
    # ------------------------------------------------------------------ #

    @staticmethod
    def is_namespace(value: object) -> bool:
        return isinstance(value, Namespace)

    @staticmethod
    def is_method(value: object) -> bool:
        return isinstance(value, Method)

    @classmethod
    def children(cls, node: object) -> List[str]:
        if not isinstance(node, Namespace):
            return []
        names: List[str] = []
        for name in node:
            value = node.children[name]
            if cls.is_namespace(value) or cls.is_method(value):
                names.append(name)
        return names

    @staticmethod
    def resolve_path(stack: List[str], target: str) -> List[str]:
        """Resolve a path expression to a candidate stack.

        Path segments are separated by '/'. A leading '/' makes the path
        absolute. A '..' segment walks up one level. Each non-'..' segment
        may itself contain dots (proto package names use '.'), which are
        split into hops.
        """
        if target.startswith("/"):
            candidate: List[str] = []
            target = target.lstrip("/")
        else:
            candidate = list(stack)
        if not target:
            return candidate
        for segment in target.split("/"):
            if segment in ("", "."):
                continue
            if segment == "..":
                if candidate:
                    candidate.pop()
                continue
            for hop in segment.split("."):
                if hop:
                    candidate.append(hop)
        return candidate

    def walk(self, stack: List[str]) -> object:
        node = self.tree
        for hop in stack:
            node = getattr(node, hop)
        return node

    def current_node(self) -> object:
        return self.walk(self.path_stack)

    def format_pwd(self) -> str:
        return "/" + "/".join(self.path_stack)

    # ------------------------------------------------------------------ #
    # Output helpers                                                     #
    # ------------------------------------------------------------------ #

    def _err(self, msg: str) -> None:
        print(msg, file=self.stderr)

    def _out(self, msg: str = "") -> None:
        print(msg, file=self.stdout)

    def print_banner(
        self,
        endpoint_version: HadesProtocolVersion,
        negotiated_size: int,
        proposed_size: int,
    ) -> None:
        client_v = HadesClient.HADES_VERSION
        self._err(BANNER)
        self._err(
            f"  client v{client_v.major}.{client_v.minor}.{client_v.revision}"
            f"   endpoint v{endpoint_version.major}.{endpoint_version.minor}.{endpoint_version.revision}"
            f"   buffer={negotiated_size}B (proposed {proposed_size}B)"
        )
        self._err(
            "  'help' for commands \u00b7 'quit' to exit \u00b7 \u2191/\u2193 history \u00b7 "
            "Tab to complete \u00b7 \u2192 accept suggestion\n"
        )

    # ------------------------------------------------------------------ #
    # Commands                                                           #
    # ------------------------------------------------------------------ #

    def cmd_help(self) -> None:
        self._err(HELP_TEXT)

    def cmd_ls(self, rest: List[str]) -> None:
        target_path = rest[0] if rest else ""
        try:
            stack = (
                self.resolve_path(self.path_stack, target_path)
                if target_path
                else list(self.path_stack)
            )
            node = self.walk(stack)
        except AttributeError:
            self._err(f"ls: no such path: {target_path}")
            return

        if not isinstance(node, Namespace):
            self._err(f"ls: not a namespace: {target_path or self.format_pwd()}")
            return

        lines = render_tree(build_subtree_dict(node))
        if lines:
            self._out("\n".join(lines))

    def try_navigate(self, cmd: str) -> bool:
        """If ``cmd`` resolves to a namespace, enter it and return True."""
        try:
            stack = self.resolve_path(self.path_stack, cmd)
            node = self.walk(stack)
        except AttributeError:
            return False
        except Exception:
            return False
        if not stack:
            self.path_stack = []
            return True
        if self.is_namespace(node):
            self.path_stack = stack
            return True
        return False

    def invoke_method(self, cmd: str, rest: List[str]) -> None:
        try:
            stack = self.resolve_path(self.path_stack, cmd)
            if not stack:
                self._err("error: empty method path")
                return
            parent = self.walk(stack[:-1])
            method_name = stack[-1]
            target_method = getattr(parent, method_name, None)
            if not self.is_method(target_method):
                self._err(f"error: '{cmd}' is not a method")
                return

            request = self._build_request(target_method.input_type, rest)

            t0 = time.perf_counter()
            response = target_method(**request)
            elapsed_ms = (time.perf_counter() - t0) * 1000.0

            self._out(message_to_json(response))
            if self.timing:
                self._err(f"[{elapsed_ms:.3f} ms]")
        except AttributeError:
            self._err(f"error: unknown method '{cmd}'")
        except Exception as e:
            self._err(f"error: {type(e).__name__}: {e}")

    def dispatch(self, line: str) -> bool:
        """Process one input line. Returns False if the shell should exit."""
        try:
            tokens = shlex.split(line, posix=True)
        except ValueError as e:
            self._err(f"parse error: {e}")
            return True

        if not tokens:
            return True

        cmd, rest = tokens[0], tokens[1:]

        if cmd in ("quit", "exit"):
            return False
        if cmd == "help":
            self.cmd_help()
            return True
        if cmd == "ls":
            self.cmd_ls(rest)
            return True

        if not rest and self.try_navigate(cmd):
            return True

        self.invoke_method(cmd, rest)
        return True

    # ------------------------------------------------------------------ #
    # REPL loop                                                          #
    # ------------------------------------------------------------------ #

    def _make_completer(self):
        from prompt_toolkit.completion import Completer, Completion

        shell = self

        class HadesCompleter(Completer):
            def get_completions(self, document, complete_event):
                text = document.text_before_cursor
                tokens = text.split()

                if not tokens or (len(tokens) == 1 and not text.endswith(" ")):
                    word = tokens[0] if tokens else ""
                    options = list(HadesShell.BUILTIN_COMMANDS) + shell.children(
                        shell.current_node()
                    )
                    for opt in sorted(set(options)):
                        if opt.startswith(word):
                            yield Completion(opt, start_position=-len(word))
                    return

                cmd = tokens[0]
                if cmd != "ls":
                    return

                word = tokens[-1] if not text.endswith(" ") else ""
                if "/" in word:
                    head, _, leaf = word.rpartition("/")
                    prefix = head + "/" if head or word.startswith("/") else ""
                elif "." in word:
                    head, _, leaf = word.rpartition(".")
                    prefix = head + "."
                else:
                    prefix, leaf = "", word
                try:
                    prefix_clean = (
                        prefix.rstrip("/.") if prefix not in ("/", "") else prefix
                    )
                    if prefix == "/":
                        base_stack: List[str] = []
                    elif prefix_clean:
                        base_stack = shell.resolve_path(shell.path_stack, prefix_clean)
                    else:
                        base_stack = list(shell.path_stack)
                    base = shell.walk(base_stack)
                except AttributeError:
                    return
                for child in shell.children(base):
                    if child.startswith(leaf):
                        yield Completion(child, start_position=-len(leaf))

        return HadesCompleter()

    def run(self) -> None:
        interactive = self.stdin.isatty()

        session = None
        if interactive:
            from prompt_toolkit import PromptSession
            from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
            from prompt_toolkit.history import FileHistory

            self.history_path.parent.mkdir(parents=True, exist_ok=True)
            session = PromptSession(
                history=FileHistory(str(self.history_path)),
                auto_suggest=AutoSuggestFromHistory(),
                completer=self._make_completer(),
                complete_while_typing=False,
            )

        while True:
            try:
                if interactive:
                    line = session.prompt(f"hades:{self.format_pwd()}> ")
                else:
                    line = self.stdin.readline()
                    if not line:
                        break
            except (EOFError, KeyboardInterrupt):
                if interactive:
                    self._err("")
                break

            line = line.strip()
            if not line or line.startswith("#"):
                continue

            if not self.dispatch(line):
                break
