import logging
import sys

import typer
from typing_extensions import Annotated

from hades_rpc.apps.cli_endpoint import app as endpoint_app
from hades_rpc.apps.cli_generator import app as generator_app
from hades_rpc.apps.cli_rpc import app as rpc_app
from hades_rpc.apps.cli_shell import shell as shell_command

app = typer.Typer()

app.add_typer(generator_app, name="generate")
app.add_typer(endpoint_app, name="endpoint")
app.add_typer(rpc_app, name="rpc")
app.command(name="shell")(shell_command)


@app.callback()
def main(
    verbose: Annotated[
        int,
        typer.Option(
            "--verbose",
            "-v",
            count=True,
            help="Enable verbose logging. -v for INFO, -vv for DEBUG (RPC latency logs).",
        ),
    ] = 0,
):
    if verbose >= 2:
        level = logging.DEBUG
    elif verbose == 1:
        level = logging.INFO
    else:
        level = logging.WARNING

    logging.basicConfig(
        level=level,
        format="%(asctime)s.%(msecs)03d %(levelname)s %(name)s: %(message)s",
        datefmt="%H:%M:%S",
        stream=sys.stderr,
    )
    logging.getLogger("hades_rpc").setLevel(level)


if __name__ == "__main__":
    app()
