"""Typer commands that operate on the protocol layer (no service tree)."""

import sys
from typing import Any

import typer
from typing_extensions import Annotated

from hades_rpc.apps._connection import parse_connection
from hades_rpc.apps._context import AppContext
from hades_rpc.rpc.sessions import ProtocolSession

app = typer.Typer()


@app.callback()
def endpoint(
    ctx: typer.Context,
    connection: Annotated[
        Any,
        typer.Option(
            parser=parse_connection,
            help="Connection string for the target endpoint",
            envvar="HADES_CONNECTION",
        ),
    ],
):
    """Interacts with a given endpoint."""
    if not connection:
        raise typer.BadParameter("Connection was not given")

    ctx.obj = AppContext(connection=connection)


@app.command()
def query_version(ctx: typer.Context):
    with ProtocolSession(ctx.obj.connection) as protocol:
        print(protocol.get_version())


@app.command()
def query_message_size(ctx: typer.Context):
    with ProtocolSession(ctx.obj.connection) as protocol:
        print(protocol.negotiate_size(sys.maxsize))
