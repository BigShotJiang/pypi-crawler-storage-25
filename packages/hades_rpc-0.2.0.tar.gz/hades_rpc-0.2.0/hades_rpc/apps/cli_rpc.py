"""Typer ``rpc`` subcommand group: list, exec, shell."""

from typing import Any, List, Optional

import typer
from typing_extensions import Annotated

from hades_rpc.apps._connection import parse_connection
from hades_rpc.apps._context import AppContext
from hades_rpc.rpc.client import HadesClient
from hades_rpc.rpc.json_utils import message_to_json
from hades_rpc.rpc.request_builder import build_request
from hades_rpc.rpc.sessions import ServiceSession

app = typer.Typer()


@app.callback()
def rpc(
    ctx: typer.Context,
    proto: Annotated[
        str,
        typer.Option(
            help="Proto file that defines the service interface",
            envvar="HADES_SERVICE_DEFINITION",
        ),
    ],
):
    """Command set to invoke rpc methods on remote endpoint."""
    ctx.obj = AppContext(service_definition=proto)


@app.command(name="list")
def list_methods(ctx: typer.Context):
    """Lists the available services and methods."""
    print(HadesClient(ctx.obj.service_definition).describe(), end="")


@app.command(
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)
def exec(
    ctx: typer.Context,
    connection: Annotated[
        Any,
        typer.Option(
            parser=parse_connection,
            help="Connection string for the target endpoint",
            envvar="HADES_CONNECTION",
        ),
    ],
    method: Annotated[str, typer.Argument(help="Method to invoke (e.g. test.string.echo)")],
    args: Annotated[
        Optional[List[str]],
        typer.Argument(
            help=(
                "Request fields. Pass either positional values in field order "
                "(e.g. 'hi'), name=value pairs (e.g. message=hi), or a single "
                "JSON object (e.g. '{\"message\":\"hi\"}')."
            ),
        ),
    ] = None,
):
    args = [*ctx.args, *(args or [])]

    with ServiceSession(proto_path=ctx.obj.service_definition, transport=connection) as tree:
        target_method = tree
        for hop in method.split("."):
            target_method = getattr(target_method, hop)

        request = build_request(target_method.input_type, args)
        print(message_to_json(target_method(**request)))
