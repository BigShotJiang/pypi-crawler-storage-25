"""Shared connection-string parser for Typer commands.

Format: ``import.path.ClassName(key=value, key=value, ...)``

The import path is resolved relative to ``hades_rpc.rpc.transports``.
"""

from __future__ import annotations

import importlib
import re
from typing import Any


_CONNECTION_RE = re.compile(r"(.+)\.(.+)\((.*)\)")


def parse_connection(connection_string: str) -> Any:
    result = _CONNECTION_RE.search(connection_string)
    if not result:
        raise ValueError(f"Unable to parse connection string: {connection_string!r}")

    import_path = result.group(1)
    class_name = result.group(2)
    raw_params = result.group(3).strip()
    params = (
        dict(item.split("=") for item in raw_params.split(","))
        if raw_params
        else {}
    )

    module = importlib.import_module(f"hades_rpc.rpc.transports.{import_path}")
    target_class = getattr(module, class_name)
    return target_class(**params)
