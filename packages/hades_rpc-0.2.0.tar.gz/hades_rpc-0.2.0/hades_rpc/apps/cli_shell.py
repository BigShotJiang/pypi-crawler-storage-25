"""Top-level ``shell`` command — interactive REPL over a Hades endpoint.

Promoted out of the ``rpc`` group: the shell is the primary day-to-day
entry point and is more discoverable as ``hades shell``. The ``rpc`` group
remains for one-shot, non-interactive operations (``list``, ``exec``).
"""

import sys
from typing import Any

import typer
from typing_extensions import Annotated

from hades_rpc.apps._connection import parse_connection
from hades_rpc.apps.shell import HadesShell
from hades_rpc.rpc.client import HadesClient
from hades_rpc.rpc.protocol import HadesProtocol


def shell(
    proto: Annotated[
        str,
        typer.Option(
            help="Proto file that defines the service interface",
            envvar="HADES_SERVICE_DEFINITION",
        ),
    ],
    connection: Annotated[
        Any,
        typer.Option(
            parser=parse_connection,
            help="Connection string for the target endpoint",
            envvar="HADES_CONNECTION",
        ),
    ],
    timing: Annotated[
        bool,
        typer.Option(
            "--timing/--no-timing",
            help="Print elapsed time after each call.",
        ),
    ] = False,
):
    """Interactive REPL that keeps the connection open across many RPC calls."""
    run_shell(proto_path=proto, connection=connection, timing=timing)


def run_shell(proto_path: str, connection: Any, timing: bool = False) -> None:
    client = HadesClient(proto_path)
    protocol = HadesProtocol(connection)
    protocol.open()
    try:
        endpoint_version = protocol.get_version()
        proposed_size = 1024
        negotiated_size = protocol.negotiate_size(proposed_size)
        tree = client.build_service_tree(protocol)

        shell_obj = HadesShell(tree, timing=timing)
        if sys.stdin.isatty():
            shell_obj.print_banner(endpoint_version, negotiated_size, proposed_size)
        shell_obj.run()
    finally:
        protocol.close()
