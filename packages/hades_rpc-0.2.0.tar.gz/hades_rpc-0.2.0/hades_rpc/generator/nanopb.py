import os
import pathlib
import subprocess
import sys
from typing import Optional

import nanopb


class NanoPBException(Exception):
    pass


class NanoPBWrapper:

    @staticmethod
    def generate(target_path: str, output_directory: str, proto_directory: Optional[str] = None):
        nanopb_generator = os.path.join(nanopb.__path__[0], "generator/nanopb_generator")

        # Forward this process's import path to the child. When hades is run
        # from a build system that wires up sys.path at bootstrap (e.g.
        # rules_python's py_binary, PEX, zipapps), PYTHONPATH alone is empty
        # and the nanopb_generator subprocess can't find google.protobuf.
        env = os.environ.copy()
        existing = env.get("PYTHONPATH", "")
        forwarded = os.pathsep.join(p for p in sys.path if p and p not in (".",))
        env["PYTHONPATH"] = (
            os.pathsep.join([forwarded, existing]) if existing else forwarded
        )

        result = subprocess.run(
            [
                sys.executable,
                nanopb_generator,
                f"--proto-path={proto_directory}",
                f"--output-dir={output_directory}",
                target_path,
            ],
            capture_output=True,
            text=True,
            env=env,
        )

        if result.returncode != 0:
            raise NanoPBException(
                f"nanopb failed with {result.returncode}:\n"
                f"stdout:\n{result.stdout}\n"
                f"stderr:\n{result.stderr}"
            )

    @staticmethod
    def get_associated_include(proto_path: str) -> str:
        return str(
            os.path.join(os.path.dirname(proto_path), f"{pathlib.Path(proto_path).stem}.pb.h")
        )

    @staticmethod
    def get_associated_symbol(symbol: str) -> str:
        return symbol.replace(".", "_")
