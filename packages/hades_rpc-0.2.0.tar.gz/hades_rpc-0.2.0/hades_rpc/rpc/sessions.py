"""Context managers that own the lifetime of a transport-backed session."""

from __future__ import annotations

from hades_rpc.rpc.client import HadesClient
from hades_rpc.rpc.protocol import HadesProtocol
from hades_rpc.rpc.transports.base import Transport


class ProtocolSession:
    """Context manager yielding an open :class:`HadesProtocol`."""

    def __init__(self, transport: Transport):
        self.protocol = HadesProtocol(transport=transport)

    def __enter__(self) -> HadesProtocol:
        self.protocol.open()
        return self.protocol

    def __exit__(self, exc_type, exc_value, exc_traceback):
        if self.protocol:
            self.protocol.close()


class ServiceSession:
    """Context manager yielding a connected service tree (Namespace)."""

    def __init__(self, proto_path: str, transport: Transport, proposed_size: int = 1024):
        self.client = HadesClient(proto_path=proto_path)
        self.transport = transport
        self.proposed_size = proposed_size
        self.tree = None

    def __enter__(self):
        self.tree = self.client.connect(self.transport, proposed_size=self.proposed_size)
        return self.tree

    def __exit__(self, exc_type, exc_value, exc_traceback):
        if self.tree is not None and "close" in self.tree:
            self.tree.close()
