"""Explicit Namespace/Method node types for the RPC service tree."""

from __future__ import annotations

import hashlib
import logging
import time
from typing import Any, Dict, Iterator, List

from google.protobuf import descriptor

from hades_rpc.rpc.formatters import format_message
from hades_rpc.rpc.protocol import HadesProtocol
from hades_rpc.rpc.proto_loader import resolve_files

logger = logging.getLogger(__name__)


class Namespace:
    """A node in the service tree containing child namespaces and methods.

    Children are accessible as attributes (``ns.foo``) for ergonomic
    dotted-access. Iteration yields child names sorted alphabetically.
    """

    def __init__(self, name: str):
        self._name = name
        self._children: Dict[str, Any] = {}

    @property
    def name(self) -> str:
        return self._name

    @property
    def children(self) -> Dict[str, Any]:
        return self._children

    def _add(self, name: str, child: Any) -> None:
        self._children[name] = child

    def __getattr__(self, name: str) -> Any:
        # __getattr__ is only called when normal attribute lookup fails, so
        # it cannot interfere with self._children / self._name access.
        children = self.__dict__.get("_children", {})
        if name in children:
            return children[name]
        raise AttributeError(
            f"Namespace '{self.__dict__.get('_name', '?')}' has no child '{name}'"
        )

    def __iter__(self) -> Iterator[str]:
        return iter(sorted(self._children))

    def __contains__(self, name: str) -> bool:
        return name in self._children

    def __repr__(self) -> str:
        return f"Namespace({self._name!r}, children={list(self._children)!r})"


class Method:
    """A callable RPC method bound to a HadesProtocol."""

    def __init__(
        self,
        full_name: str,
        method_id: bytes,
        input_type: type,
        output_type: type,
        protocol: HadesProtocol,
    ):
        self.full_name = full_name
        self.id = method_id
        self.input_type = input_type
        self.output_type = output_type
        self._protocol = protocol

    def __call__(self, **kwargs):
        rpc_name = (
            f"{self.input_type.DESCRIPTOR.full_name} -> "
            f"{self.output_type.DESCRIPTOR.full_name}"
        )
        t_start = time.perf_counter()

        request = self.input_type(**kwargs)
        serialized = request.SerializeToString()
        t_serialized = time.perf_counter()

        raw_response = self._protocol.send_rpc(self.id, serialized)
        t_response = time.perf_counter()

        parsed = self.output_type()
        parsed.ParseFromString(raw_response)
        t_parsed = time.perf_counter()

        logger.debug(
            "RPC %s: total=%.3fms serialize=%.3fms protocol=%.3fms deserialize=%.3fms "
            "request_bytes=%d response_bytes=%d",
            rpc_name,
            (t_parsed - t_start) * 1000.0,
            (t_serialized - t_start) * 1000.0,
            (t_response - t_serialized) * 1000.0,
            (t_parsed - t_response) * 1000.0,
            len(serialized),
            len(raw_response),
        )

        return parsed

    def __repr__(self) -> str:
        return f"Method({self.full_name!r})"


class ServiceTreeBuilder:
    """Build a Namespace tree from a loaded proto module's descriptors."""

    def __init__(self, protocol: HadesProtocol):
        self._protocol = protocol

    def build(self, root_descriptor: descriptor.FileDescriptor) -> Namespace:
        root = Namespace("root")
        files = resolve_files(root_descriptor)

        for file in files:
            for message in file.message_types_by_name.values():
                self._insert_message(root, message)
            for enum in file.enum_types_by_name.values():
                self._insert_enum(root, enum)
            for service in file.services_by_name.values():
                for method in service.methods:
                    self._insert_method(root, method)

        return root

    def _ensure_path(self, root: Namespace, hops: List[str]) -> Namespace:
        current = root
        for hop in hops:
            if hop not in current:
                current._add(hop, Namespace(hop))
            child = current.children[hop]
            if not isinstance(child, Namespace):
                # Existing leaf with the same name; replace with a namespace
                # that adopts the leaf under itself? In practice proto names
                # don't collide like this. Raise to surface the issue early.
                raise ValueError(f"Path collision at '{hop}': existing child is not a namespace")
            current = child
        return current

    def _insert_message(self, root: Namespace, message: descriptor.Descriptor) -> None:
        package_hops = message.full_name.split(".")[:-1]
        parent = self._ensure_path(root, package_hops)
        parent._add(message.name, message._concrete_class)

    def _insert_enum(self, root: Namespace, enum: descriptor.EnumDescriptor) -> None:
        package_hops = enum.full_name.split(".")[:-1]
        parent = self._ensure_path(root, package_hops)
        enum_node = Namespace(enum.name)
        for value in enum.values:
            enum_node._add(value.name, value.number)
        parent._add(enum.name, enum_node)

    def _insert_method(
        self, root: Namespace, method_desc: descriptor.MethodDescriptor
    ) -> None:
        package_hops = method_desc.full_name.split(".")[:-1]
        parent = self._ensure_path(root, package_hops)
        method_id = hashlib.sha1(str.encode(method_desc.full_name)).digest()
        method = Method(
            full_name=method_desc.full_name,
            method_id=method_id,
            input_type=method_desc.input_type._concrete_class,
            output_type=method_desc.output_type._concrete_class,
            protocol=self._protocol,
        )
        parent._add(method_desc.name, method)


def build_subtree_dict(node: Namespace) -> Dict[str, dict]:
    """Render a Namespace into the nested-dict form consumed by render_tree.

    Only Namespace and Method children are surfaced; message classes and
    enum-value ints attached to the tree are skipped so ``ls`` stays focused
    on what users can actually invoke or navigate into.
    """
    out: Dict[str, dict] = {}
    for child_name in node:
        child = node.children[child_name]
        if isinstance(child, Method):
            label = (
                f"{child_name}("
                f"{format_message(child.input_type.DESCRIPTOR)}"
                f") -> {format_message(child.output_type.DESCRIPTOR)}"
            )
            out[label] = {}
        elif isinstance(child, Namespace):
            out[child_name] = build_subtree_dict(child)
    return out
