"""Version-agnostic wrapper for protobuf's MessageToJson.

The keyword controlling whether default-valued scalars appear in the output was
renamed in newer protobuf releases:

* ``including_default_value_fields`` — older releases.
* ``always_print_fields_with_no_presence`` — newer releases.

We probe the installed signature once at import time and use whichever name is
available. If neither exists (very old protobuf), we fall back to no kwarg.
"""

from __future__ import annotations

import inspect

from google.protobuf.json_format import MessageToJson


def _detect_print_defaults_kwarg() -> dict:
    params = inspect.signature(MessageToJson).parameters
    if "always_print_fields_with_no_presence" in params:
        return {"always_print_fields_with_no_presence": True}
    if "including_default_value_fields" in params:
        return {"including_default_value_fields": True}
    return {}


_PRINT_DEFAULTS_KW = _detect_print_defaults_kwarg()


def message_to_json(message) -> str:
    """Serialize a protobuf message to JSON, including default-valued scalars."""
    return MessageToJson(message, **_PRINT_DEFAULTS_KW)
