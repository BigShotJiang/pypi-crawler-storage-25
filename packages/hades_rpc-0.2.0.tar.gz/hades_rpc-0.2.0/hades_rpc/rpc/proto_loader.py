"""Helpers for loading proto files and walking dependency graphs."""

from __future__ import annotations

import itertools
import logging
import os
import sys
import time
from typing import Any, Set

import grpc
from google.protobuf import descriptor

logger = logging.getLogger(__name__)


def load_proto(proto_path: str) -> Any:
    """Load a .proto file via grpc.protos and return the generated module.

    This mutates ``sys.path`` and the current working directory so that
    grpc/protoc can find sibling proto files. Behavior matches the original
    implementation in ``Hades.__init__``.
    """
    t_start = time.perf_counter()
    proto_path = os.path.abspath(proto_path)
    sys.path.insert(0, os.path.dirname(proto_path))
    os.chdir(os.path.dirname(proto_path))
    t_pre = time.perf_counter()
    protos = grpc.protos(os.path.basename(proto_path))
    t_loaded = time.perf_counter()

    logger.debug(
        "Proto load %s: grpc.protos=%.3fms setup=%.3fms total=%.3fms",
        os.path.basename(proto_path),
        (t_loaded - t_pre) * 1000.0,
        (t_pre - t_start) * 1000.0,
        (t_loaded - t_start) * 1000.0,
    )

    return protos


def resolve_files(target: descriptor.FileDescriptor) -> Set[descriptor.FileDescriptor]:
    """Recursively gather a FileDescriptor and all of its (transitive) dependencies."""
    files: Set[descriptor.FileDescriptor] = set()
    files.add(target)

    for dependency in itertools.chain(target.public_dependencies, target.dependencies):
        files = files | resolve_files(dependency)

    return files
