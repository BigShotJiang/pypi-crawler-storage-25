import ctypes


class CTypeExtension:
    def __str__(self):
        return "{}: {{{}}}".format(
            self.__class__.__name__,
            ", ".join(
                ["{}: {}".format(field[0], getattr(self, field[0])) for field in self._fields_]
            ),
        )

    def pack(self):
        return ctypes.string_at(ctypes.byref(self), ctypes.sizeof(self))


class HadesRequestHeader(ctypes.LittleEndianStructure, CTypeExtension):
    _pack_ = 1
    _fields_ = [
        ("request", ctypes.c_uint16, 1),
        ("request_id", ctypes.c_uint16, 15),
        ("command", ctypes.c_uint16),
    ]


class HadesResponseHeader(ctypes.LittleEndianStructure, CTypeExtension):
    _pack_ = 1
    _fields_ = [
        ("request", ctypes.c_uint16, 1),
        ("request_id", ctypes.c_uint16, 15),
        ("status", ctypes.c_uint16),
    ]


class HadesRequestVersion(ctypes.LittleEndianStructure, CTypeExtension):
    CMD_ID = 0
    _pack_ = 1


class HadesResponseVersion(ctypes.LittleEndianStructure, CTypeExtension):
    CMD_ID = 0
    _pack_ = 1
    _fields_ = [
        ("major", ctypes.c_uint32, 10),
        ("minor", ctypes.c_uint32, 11),
        ("revision", ctypes.c_uint32, 11),
    ]


class HadesRequestNegotiateSize(ctypes.LittleEndianStructure, CTypeExtension):
    CMD_ID = 1
    _pack_ = 1
    _fields_ = [("proposed_size", ctypes.c_uint32)]


class HadesResponseNegotiateSize(ctypes.LittleEndianStructure, CTypeExtension):
    CMD_ID = 1
    _pack_ = 1
    _fields_ = [("negotiated_size", ctypes.c_uint32)]


class HadesRequestRPC(ctypes.LittleEndianStructure, CTypeExtension):
    CMD_ID = 2
    _pack_ = 1
    _fields_ = [
        ("target", ctypes.c_ubyte * 20),
        ("size", ctypes.c_uint32),
    ]


class HadesResponseRPC(ctypes.LittleEndianStructure, CTypeExtension):
    CMD_ID = 2
    _pack_ = 1
    _fields_ = [("size", ctypes.c_uint32)]
