from attrs import define


@define
class HadesProtocolVersion:
    major: int
    minor: int
    revision: int
