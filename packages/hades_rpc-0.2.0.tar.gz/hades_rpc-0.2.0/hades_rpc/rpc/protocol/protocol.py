import ctypes
import logging
import time

from hades_rpc.rpc.protocol.messages import (
    HadesRequestHeader,
    HadesRequestNegotiateSize,
    HadesRequestRPC,
    HadesRequestVersion,
    HadesResponseHeader,
    HadesResponseNegotiateSize,
    HadesResponseRPC,
    HadesResponseVersion,
)
from hades_rpc.rpc.protocol.version import HadesProtocolVersion
from hades_rpc.rpc.transports.base import Transport

logger = logging.getLogger(__name__)


class HadesProtocolException(Exception):
    pass


class HadesProtocol:

    REQUEST_ID_MASK = 0x7FFF  # request_id is a 15-bit field; rolls over at 0x7FFF.

    def __init__(self, transport: Transport):
        self.transport = transport
        self.request_id = 0
        self.negotiated_size = 1024

    def open(self):
        self.transport.open()

    def close(self):
        self.transport.close()

    def get_version(self) -> HadesProtocolVersion:
        request = HadesRequestVersion()
        response = self._send_request(HadesRequestVersion.CMD_ID, request.pack())

        if len(response) < ctypes.sizeof(HadesResponseVersion):
            raise HadesProtocolException("Malformed response")

        version = HadesResponseVersion.from_buffer(bytearray(response))
        return HadesProtocolVersion(
            major=version.major, minor=version.minor, revision=version.revision
        )

    def negotiate_size(self, proposed_size) -> int:
        request = HadesRequestNegotiateSize(proposed_size=proposed_size)
        response = self._send_request(HadesRequestNegotiateSize.CMD_ID, request.pack())

        if len(response) < ctypes.sizeof(HadesResponseNegotiateSize):
            raise HadesProtocolException("Malformed response")

        negotiated_size = HadesResponseNegotiateSize.from_buffer(bytearray(response))
        self.negotiated_size = negotiated_size.negotiated_size
        return negotiated_size.negotiated_size

    def send_rpc(self, id: bytes, payload: bytes) -> bytes:
        request = HadesRequestRPC(target=(ctypes.c_ubyte * 20)(*id), size=len(payload))
        response = self._send_request(HadesRequestRPC.CMD_ID, request.pack() + payload)

        if len(response) < ctypes.sizeof(HadesResponseRPC):
            raise HadesProtocolException("Malformed response")

        return response[ctypes.sizeof(HadesResponseRPC):]

    def _send_request(self, command_id: int, request: bytes) -> bytes:
        request_id = self._get_request_id()
        header = HadesRequestHeader(
            request=1, request_id=request_id, command=command_id
        )

        t_start = time.perf_counter()
        payload = header.pack() + request
        self.transport.send(payload)
        t_sent = time.perf_counter()
        response = self.transport.receive()
        t_received = time.perf_counter()

        logger.debug(
            "Protocol cmd=%d req_id=%d: send=%.3fms receive=%.3fms total=%.3fms "
            "tx_bytes=%d rx_bytes=%d",
            command_id,
            request_id,
            (t_sent - t_start) * 1000.0,
            (t_received - t_sent) * 1000.0,
            (t_received - t_start) * 1000.0,
            len(payload),
            len(response),
        )

        if len(response) < ctypes.sizeof(HadesResponseHeader):
            raise HadesProtocolException("Malformed response, response is less than expected size")

        response_header = HadesResponseHeader.from_buffer(
            bytearray(response[: ctypes.sizeof(HadesResponseHeader)])
        )

        if response_header.request != 0:
            raise HadesProtocolException("Expected response, received request")

        if response_header.status != 0:
            raise HadesProtocolException(f"Endpoint responded error: {response_header.status}")

        return response[ctypes.sizeof(HadesResponseHeader):]

    def _get_request_id(self) -> int:
        self.request_id = (self.request_id + 1) & HadesProtocol.REQUEST_ID_MASK
        return self.request_id
