"""High-level client facade — load a proto and connect to an endpoint."""

from __future__ import annotations

from typing import Any, Dict

from hades_rpc.rpc.formatters import format_message, render_tree
from hades_rpc.rpc.protocol import HadesProtocol, HadesProtocolVersion
from hades_rpc.rpc.proto_loader import load_proto, resolve_files
from hades_rpc.rpc.service_tree import Namespace, ServiceTreeBuilder
from hades_rpc.rpc.transports.base import Transport


class HadesException(Exception):
    pass


class HadesClient:
    """Loads a proto file and (optionally) connects to a remote endpoint.

    The wire-protocol version (``HADES_VERSION``) is the version this client
    speaks on the wire — distinct from the package version.
    """

    HADES_VERSION = HadesProtocolVersion(major=0, minor=1, revision=5)

    def __init__(self, proto_path: str):
        self.protos = load_proto(proto_path)

    def describe(self) -> str:
        """Render the available services/methods as an ASCII tree."""
        tree: Dict[str, Any] = {}
        files = resolve_files(self.protos.DESCRIPTOR)

        for file in files:
            for service in file.services_by_name.values():
                if len(service.methods) == 0:
                    continue

                hops = service.full_name.split(".")
                current = tree
                for hop in hops:
                    current = current.setdefault(hop, {})

                for method in service.methods:
                    label = (
                        f"{method.name}("
                        f"{format_message(method.input_type)}"
                        f") -> {format_message(method.output_type)}"
                    )
                    current[label] = {}

        lines = render_tree(tree)
        return "\n".join(lines) + ("\n" if lines else "")

    def connect(self, transport: Transport, proposed_size: int = 1024) -> Namespace:
        protocol = HadesProtocol(transport)
        protocol.open()

        version = protocol.get_version()
        if version.major != HadesClient.HADES_VERSION.major:
            raise HadesException(f"Endpoint version is not supported: {version}")

        protocol.negotiate_size(proposed_size)
        tree = ServiceTreeBuilder(protocol).build(self.protos.DESCRIPTOR)
        # Attach a close() so callers can tear down the underlying transport.
        tree._add("close", protocol.close)
        return tree

    def build_service_tree(self, protocol: HadesProtocol) -> Namespace:
        """Build a service tree against an already-open protocol.

        Used by the shell, which wants to print a banner with the negotiated
        size before constructing the tree.
        """
        return ServiceTreeBuilder(protocol).build(self.protos.DESCRIPTOR)
