"""Build a protobuf request message dict from CLI-style argument strings.

Supports three argument styles, which may be mixed:

* JSON object as a single arg: ``'{"message":"hi"}'``
* ``name=value`` pairs:        ``message=hi``
* Bare positional values:       ``hi``
"""

from __future__ import annotations

import json
import re
from typing import Any, List

import typer
from google.protobuf import descriptor as _descriptor


_KWARG_NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*=")


def _looks_like_kwarg(token: str) -> bool:
    return bool(_KWARG_NAME.match(token))


def _field_by_name(fields, name: str):
    for field in fields:
        if field.name == name:
            return field
    raise typer.BadParameter(
        f"Unknown field '{name}'. Known: {', '.join(f.name for f in fields)}"
    )


def build_request(input_type: type, raw_args: List[str]) -> dict:
    """Convert CLI args into a kwargs dict for the request message constructor."""
    fields = input_type.DESCRIPTOR.fields  # ordered

    if len(raw_args) == 1 and raw_args[0].lstrip().startswith("{"):
        return json.loads(raw_args[0])

    positional_index = 0
    parsed: dict = {}
    fd = _descriptor.FieldDescriptor

    for token in raw_args:
        if "=" in token and _looks_like_kwarg(token):
            name, _, value = token.partition("=")
            field = _field_by_name(fields, name)
            parsed[field.name] = coerce_field(field, value)
        else:
            if positional_index >= len(fields):
                raise typer.BadParameter(
                    f"Too many positional arguments for {input_type.DESCRIPTOR.full_name} "
                    f"(expected at most {len(fields)})."
                )
            field = fields[positional_index]
            if field.label == fd.LABEL_REPEATED:
                parsed.setdefault(field.name, []).append(coerce_scalar(field, token))
            else:
                positional_index += 1
                parsed[field.name] = coerce_field(field, token)

    return parsed


def coerce_field(field, value: str) -> Any:
    """Coerce a CLI string into the proto field's native type.

    For a repeated field used as a single keyword (e.g. ``values=[1,2,3]``),
    the value must be a JSON array. For per-element use (positional spread),
    use :func:`coerce_scalar`.
    """
    fd = _descriptor.FieldDescriptor

    if field.label == fd.LABEL_REPEATED:
        decoded = json.loads(value)
        if not isinstance(decoded, list):
            raise typer.BadParameter(
                f"Field '{field.name}' is repeated; expected a JSON array, got {value!r}."
            )
        return decoded

    if field.type == fd.TYPE_MESSAGE:
        return json.loads(value)

    return coerce_scalar(field, value)


def coerce_scalar(field, value: str) -> Any:
    """Coerce a single element string into the field's element type."""
    fd = _descriptor.FieldDescriptor

    if field.type in (fd.TYPE_INT32, fd.TYPE_INT64, fd.TYPE_UINT32, fd.TYPE_UINT64,
                      fd.TYPE_SINT32, fd.TYPE_SINT64, fd.TYPE_FIXED32, fd.TYPE_FIXED64,
                      fd.TYPE_SFIXED32, fd.TYPE_SFIXED64):
        return int(value, 0)

    if field.type in (fd.TYPE_FLOAT, fd.TYPE_DOUBLE):
        return float(value)

    if field.type == fd.TYPE_BOOL:
        lowered = value.lower()
        if lowered in ("true", "1", "yes", "y", "on"):
            return True
        if lowered in ("false", "0", "no", "n", "off"):
            return False
        raise typer.BadParameter(f"Invalid bool for field '{field.name}': {value!r}")

    if field.type == fd.TYPE_ENUM:
        try:
            return int(value, 0)
        except ValueError:
            pass
        enum_value = field.enum_type.values_by_name.get(value)
        if enum_value is None:
            allowed = ", ".join(field.enum_type.values_by_name.keys())
            raise typer.BadParameter(
                f"Invalid enum value for field '{field.name}': {value!r}. Allowed: {allowed}"
            )
        return enum_value.number

    if field.type == fd.TYPE_BYTES:
        return value.encode()

    return value
