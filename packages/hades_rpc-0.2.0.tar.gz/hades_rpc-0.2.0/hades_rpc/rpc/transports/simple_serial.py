import ctypes
import logging
import time
from typing import Optional

import serial

from hades_rpc.rpc.transports.base import Transport, TransportException

logger = logging.getLogger(__name__)


class SimpleSerialHeader(ctypes.LittleEndianStructure):
    HEADER_MAGIC = 0xF33D10B0
    _pack_ = 1
    _fields_ = [("magic", ctypes.c_uint32), ("size", ctypes.c_uint32)]

    def __init__(self, size):
        self.magic = SimpleSerialHeader.HEADER_MAGIC
        self.size = size

    def pack(self):
        return ctypes.string_at(ctypes.byref(self), ctypes.sizeof(self))


class SimpleSerial(Transport):

    def __init__(self, port: str, baud: int):
        self.port = port
        self.baud = baud
        self.serial: Optional[serial.Serial] = None

    def open(self):
        if self.serial:
            self.close()

        self.serial = serial.Serial(port=self.port, baudrate=self.baud)

    def close(self):
        if self.serial:
            self.serial.close()
            self.serial = None

    def send(self, payload: bytes):
        if not self.serial:
            raise TransportException("Connection has not been opened")

        header = SimpleSerialHeader(len(payload))
        frame = header.pack() + payload

        t_start = time.perf_counter()
        self.serial.write(frame)
        t_written = time.perf_counter()

        logger.debug(
            "Serial send: write=%.3fms bytes=%d (header=%d, payload=%d)",
            (t_written - t_start) * 1000.0,
            len(frame),
            ctypes.sizeof(SimpleSerialHeader),
            len(payload),
        )

    def receive(self) -> bytes:
        if not self.serial:
            raise TransportException("Connection has not been opened")

        t_start = time.perf_counter()
        read_bytes = self.serial.read(ctypes.sizeof(SimpleSerialHeader))
        t_header = time.perf_counter()

        response = SimpleSerialHeader.from_buffer(bytearray(read_bytes))
        if response.magic != SimpleSerialHeader.HEADER_MAGIC:
            raise TransportException(f"Bad message expected header, bad magic: {response.magic}")

        body = self.serial.read(response.size)
        t_body = time.perf_counter()

        logger.debug(
            "Serial receive: header_read=%.3fms body_read=%.3fms total=%.3fms "
            "header_bytes=%d body_bytes=%d",
            (t_header - t_start) * 1000.0,
            (t_body - t_header) * 1000.0,
            (t_body - t_start) * 1000.0,
            len(read_bytes),
            len(body),
        )

        return body
