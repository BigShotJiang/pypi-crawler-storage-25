"""Pretty-printers for the service tree and protobuf message signatures."""

from __future__ import annotations

from typing import Any, Dict, List

from google.protobuf import descriptor


def render_tree(node: Dict[str, Any], prefix: str = "", lines: List[str] = None) -> List[str]:
    """Render a nested dict tree into ASCII lines.

    Single-child package chains are collapsed into dotted segments
    (e.g. ``foo -> bar -> baz`` becomes ``foo.bar.baz``) for compactness.
    Leaves (empty dicts) are sorted last.
    """
    if lines is None:
        lines = []
    items = sorted(node.items(), key=lambda kv: (len(kv[1]) == 0, kv[0]))
    for index, (name, children) in enumerate(items):
        is_last = index == len(items) - 1
        connector = "└── " if is_last else "├── "

        display = name
        current_children = children
        while (
            len(current_children) == 1
            and len(next(iter(current_children.values()))) > 0
        ):
            only_name, only_children = next(iter(current_children.items()))
            display += f".{only_name}"
            current_children = only_children

        lines.append(f"{prefix}{connector}{display}")
        if current_children:
            extension = "    " if is_last else "│   "
            render_tree(current_children, prefix + extension, lines)
    return lines


def format_message(message: descriptor.Descriptor) -> str:
    """Render a message descriptor as ``Name {type field, ...}``."""
    if not message.fields:
        return message.name
    fields = ", ".join(
        f"{format_field_type(f)} {f.name}" for f in message.fields
    )
    return f"{message.name} {{{fields}}}"


def format_field_type(field: descriptor.FieldDescriptor) -> str:
    fd = descriptor.FieldDescriptor
    type_names = {
        fd.TYPE_DOUBLE: "double", fd.TYPE_FLOAT: "float",
        fd.TYPE_INT64: "int64", fd.TYPE_UINT64: "uint64",
        fd.TYPE_INT32: "int32", fd.TYPE_FIXED64: "fixed64",
        fd.TYPE_FIXED32: "fixed32", fd.TYPE_BOOL: "bool",
        fd.TYPE_STRING: "string", fd.TYPE_BYTES: "bytes",
        fd.TYPE_UINT32: "uint32", fd.TYPE_SFIXED32: "sfixed32",
        fd.TYPE_SFIXED64: "sfixed64", fd.TYPE_SINT32: "sint32",
        fd.TYPE_SINT64: "sint64",
    }
    if field.type == fd.TYPE_MESSAGE:
        type_str = field.message_type.name
    elif field.type == fd.TYPE_ENUM:
        type_str = field.enum_type.name
    else:
        type_str = type_names.get(field.type, f"type{field.type}")

    if field.label == fd.LABEL_REPEATED:
        type_str = f"repeated {type_str}"
    return type_str
