"""Core functionality for codrninja."""

import json
import os
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Any

from .config import Config
from .providers import ProviderManager
from .tools import ToolRegistry


class Session:
    """Represents a coding session."""
    
    def __init__(self, id: str, name: str, created_at: str, messages: List[Dict] = None):
        self.id = id
        self.name = name
        self.created_at = created_at
        self.messages = messages or []
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "created_at": self.created_at,
            "messages": self.messages
        }


class AICode:
    """Main class for codrninja functionality."""
    
    def __init__(self, config: Optional[Config] = None):
        self.config = config or Config.from_env()
        self.config.ensure_db_dir()
        self._init_db()
        self.provider_manager = ProviderManager({
            "provider": self.config.default_provider,
            "providers": {
                "ollama": {
                    "url": self.config.ollama_url,
                    "model": self.config.default_model,
                    "reasoning_level": self.config.reasoning_level
                },
                "openai": {
                    "api_key": self.config.openai_api_key,
                    "model": self.config.default_model,
                    "reasoning_level": self.config.reasoning_level
                },
                "anthropic": {
                    "api_key": self.config.anthropic_api_key,
                    "model": self.config.default_model,
                    "reasoning_level": self.config.reasoning_level
                },
                "openrouter": {
                    "api_key": self.config.openrouter_api_key,
                    "model": self.config.default_model,
                    "reasoning_level": self.config.reasoning_level
                }
            }
        })
        self.tools = ToolRegistry()
    
    def _init_db(self):
        """Initialize SQLite database."""
        conn = sqlite3.connect(self.config.db_path)
        c = conn.cursor()
        
        c.execute('''
            CREATE TABLE IF NOT EXISTS sessions (
                id TEXT PRIMARY KEY,
                name TEXT UNIQUE NOT NULL,
                created_at TEXT,
                updated_at TEXT
            )
        ''')
        
        c.execute('''
            CREATE TABLE IF NOT EXISTS messages (
                id TEXT PRIMARY KEY,
                session_id TEXT NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                model TEXT,
                tokens_input INTEGER,
                tokens_output INTEGER,
                created_at TEXT,
                FOREIGN KEY (session_id) REFERENCES sessions(id)
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def create_session(self, name: str) -> Session:
        """Create a new session."""
        conn = sqlite3.connect(self.config.db_path)
        c = conn.cursor()
        
        # Check if exists
        c.execute("SELECT id FROM sessions WHERE name = ?", (name,))
        existing = c.fetchone()
        if existing:
            conn.close()
            return self.get_session(name)
        
        sid = str(uuid.uuid4())
        now = datetime.now(timezone.utc).isoformat()
        c.execute(
            "INSERT INTO sessions (id, name, created_at, updated_at) VALUES (?, ?, ?, ?)",
            (sid, name, now, now)
        )
        conn.commit()
        conn.close()
        
        return Session(sid, name, now)
    
    def get_session(self, name: str) -> Optional[Session]:
        """Get session by name."""
        conn = sqlite3.connect(self.config.db_path)
        c = conn.cursor()
        
        c.execute("SELECT id, name, created_at FROM sessions WHERE name = ?", (name,))
        row = c.fetchone()
        
        if not row:
            conn.close()
            return None
        
        # Get messages
        c.execute(
            "SELECT role, content FROM messages WHERE session_id = ? ORDER BY created_at",
            (row[0],)
        )
        messages = [{"role": r[0], "content": r[1]} for r in c.fetchall()]
        
        conn.close()
        return Session(row[0], row[1], row[2], messages)
    
    def list_sessions(self) -> List[Dict[str, str]]:
        """List all sessions."""
        conn = sqlite3.connect(self.config.db_path)
        c = conn.cursor()
        c.execute("SELECT name, created_at FROM sessions ORDER BY updated_at DESC")
        sessions = [{"name": row[0], "created_at": row[1]} for row in c.fetchall()]
        conn.close()
        return sessions
    
    def send_message(self, session_name: str, content: str, model: Optional[str] = None) -> Dict[str, Any]:
        """Send a message and get response."""
        session = self.get_session(session_name)
        if not session:
            session = self.create_session(session_name)
        
        # Build message history
        messages = [{"role": "system", "content": self.config.system_prompt}]
        messages.extend(session.messages)
        messages.append({"role": "user", "content": content})
        
        # Use provider manager
        try:
            provider = self.provider_manager.get_provider()
            result = provider.chat(messages, model)
        except Exception as e:
            return {"success": False, "error": str(e), "session": session_name}
        
        if result.get("error"):
            return {"success": False, "error": result["error"], "session": session_name}
        
        # Save to database
        self._save_message(session.id, "user", content)
        self._save_message(
            session.id,
            "assistant",
            result.get("content", ""),
            model=result.get("model", model or self.config.default_model),
            tokens_in=result.get("tokens_input", 0),
            tokens_out=result.get("tokens_output", 0)
        )
        
        return {
            "success": True,
            "response": result.get("content", ""),
            "session": session_name,
            "model": result.get("model", model or self.config.default_model),
            "tokens": {
                "input": result.get("tokens_input", 0),
                "output": result.get("tokens_output", 0)
            }
        }
    
    def _call_ollama(self, messages: List[Dict], model: str) -> Dict[str, Any]:
        """Call Ollama API."""
        try:
            response = requests.post(
                f"{self.config.ollama_url}/api/chat",
                json={
                    "model": model,
                    "messages": messages,
                    "stream": False,
                    "options": {
                        "temperature": 0.7,
                        "num_predict": 4096
                    }
                },
                timeout=300
            )
            response.raise_for_status()
            data = response.json()
            
            return {
                "content": data.get("message", {}).get("content", ""),
                "model": model,
                "tokens_input": data.get("prompt_eval_count", 0),
                "tokens_output": data.get("eval_count", 0),
                "done": data.get("done", False)
            }
        except requests.exceptions.Timeout:
            return {"error": "Request timed out after 5 minutes"}
        except requests.exceptions.ConnectionError:
            return {"error": f"Cannot connect to Ollama at {self.config.ollama_url}"}
        except Exception as e:
            return {"error": str(e)}
    
    def _save_message(self, session_id: str, role: str, content: str,
                     model: Optional[str] = None, tokens_in: int = 0, tokens_out: int = 0):
        """Save a message to the database."""
        conn = sqlite3.connect(self.config.db_path)
        c = conn.cursor()
        mid = str(uuid.uuid4())
        now = datetime.now(timezone.utc).isoformat()
        c.execute(
            "INSERT INTO messages (id, session_id, role, content, model, tokens_input, tokens_output, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (mid, session_id, role, content, model, tokens_in, tokens_out, now)
        )
        conn.commit()
        conn.close()
    
    def get_history(self, session_name: str) -> Optional[Dict[str, Any]]:
        """Get full session history."""
        session = self.get_session(session_name)
        if not session:
            return None
        
        return {
            "session": session_name,
            "created_at": session.created_at,
            "messages": session.messages
        }
