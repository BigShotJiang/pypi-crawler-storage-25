"""Command-line interface for codrninja with dual modes."""

import json
import os
import shlex
import sys
from pathlib import Path

from .agent import AgentMode
from .config import Config
from .core import AICode
from .skills import SkillRegistry
from .tui import TUI
from .mcp import MCPManager
from .permissions import PermissionManager, PermissionRule
from .todo import TodoManager, format_todo_item
from .tools import ToolRegistry


BUILTIN_SUBAGENT_MODES = {
    'general': AgentMode.BUILD,
    'explore': AgentMode.PLAN,
}


def main():
    """Main CLI entry point — supports both human and AI modes."""
    automation_mode = os.environ.get('AI_CODE_MODE') == 'automation' or '--json' in sys.argv

    if len(sys.argv) < 2:
        start_tui("default")
        return

    first_arg = sys.argv[1]
    known_commands = [
        'create-session', 'send', 'list-sessions', 'show-session',
        'config', 'agent', 'run', 'chat', 'interactive', 'i',
        'new', 'help', '--help', '-h', '--version', '-v',
        'tui', 'onboard', 'skills', 'mcp', 'lsp',
        'build', 'plan', 'review', 'explain', 'test', 'commit', 'exec',
        'search', 'fetch', 'subagent', 'subagents', 'todo', 'permissions'
    ]

    if first_arg not in known_commands and not first_arg.startswith('-'):
        start_tui(first_arg)
        return

    command = first_arg
    ai = AICode()

    if command == 'tui':
        session_name = sys.argv[2] if len(sys.argv) > 2 else 'default'
        start_tui(session_name)
        return

    if command == 'create-session':
        if len(sys.argv) < 3:
            error_out('Usage: codrninja create-session <name>', automation_mode)
        session = ai.create_session(sys.argv[2])
        output({'id': session.id, 'name': session.name, 'created': True}, automation_mode)

    elif command == 'send':
        if len(sys.argv) < 4:
            error_out('Usage: codrninja send <session> <message>', automation_mode)
        result = ai.send_message(sys.argv[2], sys.argv[3])
        output(result, automation_mode)

    elif command == 'list-sessions':
        output({'sessions': ai.list_sessions()}, automation_mode)

    elif command == 'show-session':
        if len(sys.argv) < 3:
            error_out('Usage: codrninja show-session <name>', automation_mode)
        result = ai.get_history(sys.argv[2])
        if result:
            output(result, automation_mode)
        else:
            error_out(f"Session '{sys.argv[2]}' not found", automation_mode)

    elif command == 'config':
        config = Config.from_env()
        output({
            'ollama_url': config.ollama_url,
            'default_model': config.default_model,
            'db_path': config.db_path,
        }, automation_mode)

    elif command == 'onboard':
        start_onboarding()

    elif command == 'skills':
        handle_skills(sys.argv[2:])

    elif command == 'mcp':
        handle_mcp(sys.argv[2:], automation_mode)

    elif command == 'lsp':
        handle_lsp(sys.argv[2:], automation_mode)

    elif command in ('agent', 'run'):
        mode = 'build'
        args = sys.argv[2:]
        for i, arg in enumerate(list(args)):
            if arg == '--mode' and i + 1 < len(args):
                mode = args[i + 1]
                args = args[:i] + args[i + 2:]
                break

        if len(args) < 2:
            error_out('Usage: codrninja agent [--mode build|plan] <session> <message>', automation_mode)

        session_name = args[0]
        message = args[1]
        ai.create_session(session_name)

        from .agent import Agent
        agent = Agent(ai, session_name, max_iterations=10, mode=mode)

        if not automation_mode:
            def on_progress(msg):
                print(f"  {msg}")
            agent.on_progress = on_progress

        result = agent.run(message, auto_approve=automation_mode)

        if automation_mode:
            output(result, True)
        elif result['success']:
            print(f"\n[OK] Task completed in {result['iterations']} iterations")
            print(f"Tools used: {result['tool_calls']}")
            print(f"\nResponse:\n{result['response'][:500]}...")
        else:
            print(f"\n[FAIL] Error: {result.get('error', 'Unknown error')}")

    elif command == 'build':
        if len(sys.argv) < 4:
            error_out('Usage: codrninja build <session> <message>', automation_mode)
        run_agent_mode(ai, sys.argv[2], sys.argv[3], AgentMode.BUILD, automation_mode)

    elif command == 'plan':
        if len(sys.argv) < 4:
            error_out('Usage: codrninja plan <session> <message>', automation_mode)
        run_agent_mode(ai, sys.argv[2], sys.argv[3], AgentMode.PLAN, automation_mode)

    elif command == 'review':
        if len(sys.argv) < 4:
            error_out('Usage: codrninja review <session> <file>', automation_mode)
        session_name, target = sys.argv[2], sys.argv[3]
        result = ai.tools.read_file(target)
        if result.success:
            run_agent_mode(ai, session_name, f'Review this code:\n\n{result.output}', AgentMode.PLAN, automation_mode)
        else:
            error_out(f'Error reading file: {result.error}', automation_mode)

    elif command == 'explain':
        if len(sys.argv) < 4:
            error_out('Usage: codrninja explain <session> <topic>', automation_mode)
        run_agent_mode(ai, sys.argv[2], f'Explain: {sys.argv[3]}', AgentMode.PLAN, automation_mode)

    elif command == 'test':
        session_name = sys.argv[2] if len(sys.argv) > 2 else 'default'
        test_cmd = sys.argv[3] if len(sys.argv) > 3 else 'pytest -q'
        result = ai.tools.execute_command(test_cmd)
        output({'success': result.success, 'output': result.output, 'error': result.error}, automation_mode)

    elif command == 'commit':
        if len(sys.argv) < 3:
            error_out('Usage: codrninja commit <message>', automation_mode)
        msg = sys.argv[2]
        ai.tools.execute_command('git add -A')
        result = ai.tools.execute_command(f'git commit -m {shlex.quote(msg)}')
        output({'success': result.success, 'output': result.output, 'error': result.error}, automation_mode)

    elif command == 'exec':
        if len(sys.argv) < 3:
            error_out('Usage: codrninja exec <command>', automation_mode)
        cmd = ' '.join(sys.argv[2:])
        result = ai.tools.execute_command(cmd)
        output({'success': result.success, 'output': result.output, 'error': result.error}, automation_mode)

    elif command == 'search':
        if len(sys.argv) < 3:
            error_out('Usage: codrninja search <query>', automation_mode)
        query = ' '.join(sys.argv[2:])
        result = ai.tools.web_search(query)
        payload = {'success': result.success, 'results': None, 'output': result.output, 'error': result.error}
        if result.success:
            try:
                payload['results'] = json.loads(result.output)
            except json.JSONDecodeError:
                payload['results'] = result.output
        output(payload, automation_mode)

    elif command == 'fetch':
        if len(sys.argv) < 3:
            error_out('Usage: codrninja fetch <url>', automation_mode)
        url = sys.argv[2]
        result = ai.tools.web_fetch(url)
        output({'success': result.success, 'content': result.output if result.success else None, 'error': result.error}, automation_mode)

    elif command == 'todo':
        handle_todo(sys.argv[2:], automation_mode)

    elif command == 'permissions':
        handle_permissions(sys.argv[2:], automation_mode)

    elif command == 'subagent':
        if len(sys.argv) < 5:
            error_out('Usage: codrninja subagent <session> <name> <task>', automation_mode)
        session_name, name = sys.argv[2], sys.argv[3]
        task = ' '.join(sys.argv[4:])
        ai.create_session(session_name)
        from .agent import Agent
        agent = Agent(ai, session_name, max_iterations=10, mode=AgentMode.BUILD)
        mode = BUILTIN_SUBAGENT_MODES.get(name.lower(), AgentMode.BUILD)
        subagent = agent.spawn_subagent(name, task, mode)
        result = subagent.run(task, auto_approve=automation_mode)
        output({
            'success': result.get('success', False),
            'session': session_name,
            'subagent': {
                'name': name,
                'session_id': subagent.session_name,
                'task': task,
                'mode': subagent.mode,
            },
            'result': result,
        }, automation_mode)

    elif command == 'subagents':
        if len(sys.argv) < 3:
            error_out('Usage: codrninja subagents <session>', automation_mode)
        session_name = sys.argv[2]
        ai.create_session(session_name)
        from .agent import Agent
        agent = Agent(ai, session_name, max_iterations=10, mode=AgentMode.BUILD)
        output({'session': session_name, 'subagents': agent.subagent_manager.list()}, automation_mode)

    elif command == 'reasoning':
        levels = ['none', 'low', 'medium', 'high']
        if len(sys.argv) < 3:
            current = ai.config.reasoning_level
            if automation_mode:
                output({'current': current, 'levels': levels}, True)
            else:
                print(f'Current reasoning level: {current}')
                print(f'Levels: {", ".join(levels)}')
                print(f'Usage: codrninja reasoning <{"|".join(levels)}>')
        else:
            level = sys.argv[2].lower()
            if level not in levels:
                error_out(f'Invalid level: {level}. Must be one of: {", ".join(levels)}', automation_mode)
            ai.config.reasoning_level = level
            # Save to config file
            try:
                import json as _json
                config_path = os.path.expanduser('~/.codrninja/config.json')
                config = {}
                if os.path.exists(config_path):
                    with open(config_path) as f:
                        config = _json.load(f)
                config['reasoning_level'] = level
                os.makedirs(os.path.dirname(config_path), exist_ok=True)
                with open(config_path, 'w') as f:
                    _json.dump(config, f, indent=2)
            except Exception:
                pass
            if automation_mode:
                output({'success': True, 'level': level}, True)
            else:
                print(f'Reasoning level set to: {level}')

    elif command in ('chat', 'interactive', 'i'):
        session_name = sys.argv[2] if len(sys.argv) > 2 else 'default'
        ai.create_session(session_name)
        interactive = TUI(ai, session_name)
        interactive.start()

    elif command == 'new':
        session_name = sys.argv[2] if len(sys.argv) > 2 else f"session-{os.urandom(4).hex()}"
        ai.create_session(session_name)
        if automation_mode:
            output({'session': session_name, 'status': 'created'}, True)
        else:
            print(f"Created session: {session_name}")
            interactive = TUI(ai, session_name)
            interactive.start()

    elif command in ('help', '--help', '-h'):
        if automation_mode:
            output({'help': get_help_text()}, True)
        else:
            print_help()

    elif command in ('--version', '-v'):
        print('codrninja 0.5.0')

    else:
        error_out(f'Unknown command: {command}', automation_mode)


def output(data: dict, automation_mode: bool):
    if automation_mode:
        print(json.dumps(data))
    else:
        print(json.dumps(data, indent=2))


def error_out(message: str, automation_mode: bool):
    if automation_mode:
        print(json.dumps({'error': message}))
    else:
        print(f'Error: {message}')
    sys.exit(1)


def print_help():
    help_text = """
Usage:

  Human Mode (interactive):
    codrninja chat [session]      Start interactive chat session
    codrninja new [session]       Create and enter new session
    codrninja tui [session]       Start prompt_toolkit TUI
    codrninja onboard             Run onboarding wizard
    codrninja skills              List installed skills
    codrninja skills --add <dir>  Add a skill directory
    codrninja mcp list            List configured MCP servers
    codrninja mcp add <name> <config_json>
    codrninja mcp remove <name>
    codrninja mcp tools           List discovered MCP tools
    codrninja lsp status          Show language server status
    codrninja lsp start <lang>    Start language server
    codrninja lsp stop <lang>     Stop language server
    codrninja lsp diagnostics <file>  Show diagnostics
    codrninja help                Show this help

  Agent Mode (one-shot commands):
    codrninja lsp status [--json]      JSON-capable language server status
    codrninja build <session> <message>   Build mode (full access)
    codrninja plan <session> <message>    Plan mode (read-only)
    codrninja review <session> <file>     Review code
    codrninja explain <session> <topic>   Explain code/concept
    codrninja test [command]              Run tests (default: pytest -q)
    codrninja commit <message>            Git commit
    codrninja exec <command>              Execute shell command
    codrninja search <query>              Search the web
    codrninja fetch <url>                 Fetch and clean a web page
    codrninja todo list [session]         List todos
    codrninja todo add <session> <task>   Add todo
    codrninja todo done <id>              Complete todo
    codrninja todo remove <id>            Remove todo
    codrninja permissions list            List permission rules
    codrninja permissions add <pattern> <action> [scope]
    codrninja permissions remove <pattern>
    codrninja permissions default <action>
    codrninja permissions explain <action> <path>
    codrninja reasoning [level]        Get/set reasoning level (none/low/medium/high)
    codrninja subagent <session> <name> <task>   Run a child subagent task
    codrninja subagents <session>                List active subagents

  AI Mode (automation — JSON output):
    AI_CODE_MODE=automation codrninja create-session <name>
    AI_CODE_MODE=automation codrninja send <session> <message>
    AI_CODE_MODE=automation codrninja list-sessions
    AI_CODE_MODE=automation codrninja show-session <name>

  Anywhere:
    codrninja config              Show configuration
    codrninja agent --mode build|plan <session> <message>

Environment Variables:
  OLLAMA_URL       Ollama endpoint (default: http://localhost:11434)
  OLLAMA_MODEL     Default model (default: codellama)
  AI_CODE_MODE     Set to 'automation' for JSON output
"""
    print(help_text)


def get_help_text() -> str:
    return """Available commands:
  create-session <name>  Create a new session
  send <session> <msg>   Send a message to a session
  list-sessions          List all sessions
  show-session <name>    Show session history
  config                 Show configuration
  chat [session]         Interactive mode
  new [session]          Quick start
  tui [session]          Start TUI
  onboard                Run onboarding wizard
  skills                 List skills
  skills --add <dir>     Add skill directory
  mcp ...                Manage MCP servers
  lsp ...                Language server operations
  build <s> <msg>        Build mode (full access)
  plan <s> <msg>         Plan mode (read-only)
  review <s> <file>      Review code
  explain <s> <topic>    Explain code/concept
  test [command]         Run tests
  commit <message>       Git commit
  exec <command>         Execute shell command
  search <query>         Search the web
  fetch <url>            Fetch and clean a web page
  todo list [session]    List todos
  todo add <s> <task>    Add todo
  todo done <id>         Complete todo
  todo remove <id>       Remove todo
  permissions ...        Manage permission rules
  subagent <s> <n> <t>   Run a child subagent task
  subagents <session>    List active subagents
  agent --mode ...       Run coding agent
  help                   Show help
"""


def run_agent_mode(ai, session_name, message, mode, automation_mode):
    """Run agent in a specific mode — for both TUI and CLI."""
    from .agent import Agent
    ai.create_session(session_name)
    agent = Agent(ai, session_name, max_iterations=10, mode=mode)

    if not automation_mode:
        def on_progress(msg):
            print(f"  {msg}")
        agent.on_progress = on_progress

    result = agent.run(message, auto_approve=automation_mode)

    if automation_mode:
        output(result, True)
    elif result['success']:
        print(f"\n[OK] Task completed in {result['iterations']} iterations")
        print(f"Tools used: {result['tool_calls']}")
        print(f"\nResponse:\n{result['response'][:500]}...")
    else:
        print(f"\n[FAIL] Error: {result.get('error', 'Unknown error')}")


def start_tui(session_name: str = 'default'):
    try:
        ai = AICode()
        tui = TUI(ai, session_name)
        tui.start()
    except ImportError:
        print('[FAIL] Rich not installed. Install with: pip3 install rich')
        print('   Or use: codrninja chat my-session')
        sys.exit(1)
    except Exception as e:
        print(f'[FAIL] Error starting TUI: {e}')
        sys.exit(1)


def start_onboarding():
    ai = AICode()
    tui = TUI(ai, 'onboarding')
    tui._onboarding()


def handle_skills(args):
    registry = SkillRegistry()
    registry.discover()

    if not args:
        skills = registry.list_skills()
        if not skills:
            print('No skills installed.')
            return
        for skill in skills:
            print(f"{skill['name']}: {skill['description']}")
        return

    if args[0] == '--add':
        if len(args) < 2:
            error_out('Usage: codrninja skills --add <path>', False)
        source = Path(args[1]).expanduser()
        skill = registry.add_skill(str(source))
        if not skill:
            error_out('Failed to add skill. Ensure the directory contains SKILL.md.', False)
        print(f'Added skill: {skill.name}')
        return

    error_out('Usage: codrninja skills [--add <path>]', False)


def handle_todo(args, automation_mode: bool):
    manager = TodoManager()

    if not args or args[0] == 'list':
        session = args[1] if len(args) > 1 else None
        todos = manager.list(session) if session else manager.list_all()
        payload = [
            {
                'id': todo.id,
                'session_id': todo.session_id,
                'task': todo.task,
                'status': todo.status,
                'created_at': todo.created_at,
                'completed_at': todo.completed_at,
                'display': format_todo_item(todo),
            }
            for todo in todos
        ]
        output({'todos': payload}, automation_mode)
        return

    action = args[0]

    if action == 'add':
        if len(args) < 3:
            error_out('Usage: codrninja todo add <session> <task>', automation_mode)
        session = args[1]
        task = ' '.join(args[2:]).strip()
        todo_id = manager.add(task, session)
        todo = manager.get(todo_id)
        output({'success': True, 'todo': {
            'id': todo.id,
            'session_id': todo.session_id,
            'task': todo.task,
            'status': todo.status,
            'created_at': todo.created_at,
            'completed_at': todo.completed_at,
            'display': format_todo_item(todo),
        }}, automation_mode)
        return

    if action == 'done':
        if len(args) < 2:
            error_out('Usage: codrninja todo done <id>', automation_mode)
        ok = manager.complete(args[1])
        if not ok:
            error_out(f"Todo not found: {args[1]}", automation_mode)
        todo = manager.get(args[1])
        output({'success': True, 'todo': {
            'id': todo.id,
            'session_id': todo.session_id,
            'task': todo.task,
            'status': todo.status,
            'created_at': todo.created_at,
            'completed_at': todo.completed_at,
            'display': format_todo_item(todo),
        }}, automation_mode)
        return

    if action == 'remove':
        if len(args) < 2:
            error_out('Usage: codrninja todo remove <id>', automation_mode)
        ok = manager.remove(args[1])
        if not ok:
            error_out(f"Todo not found: {args[1]}", automation_mode)
        output({'success': True, 'removed': args[1]}, automation_mode)
        return

    error_out('Usage: codrninja todo [list [session]|add <session> <task>|done <id>|remove <id>]', automation_mode)


def handle_permissions(args, automation_mode: bool):
    manager = PermissionManager(mode=Config.from_env().permissions_mode)

    if not args or args[0] == 'list':
        rules = [
            {
                'pattern': rule.pattern,
                'action': rule.action,
                'scope': rule.scope,
                'agent_type': rule.agent_type,
                'priority': rule.priority,
            }
            for rule in manager.list_rules()
        ]
        output({'default': manager.default_action, 'rules': rules}, automation_mode)
        return

    command = args[0]

    if command == 'add':
        if len(args) < 3:
            error_out('Usage: codrninja permissions add <pattern> <action> [scope]', automation_mode)
        pattern = args[1]
        action = args[2]
        scope = args[3] if len(args) > 3 else 'all'
        manager.add_rule(PermissionRule(pattern, action, scope, 'all', 100))
        output({'success': True, 'added': pattern}, automation_mode)
        return

    if command == 'remove':
        if len(args) < 2:
            error_out('Usage: codrninja permissions remove <pattern>', automation_mode)
        removed = manager.remove_rule(args[1])
        output({'success': removed, 'removed': args[1]}, automation_mode)
        return

    if command == 'default':
        if len(args) < 2:
            error_out('Usage: codrninja permissions default <action>', automation_mode)
        manager.set_default(args[1])
        output({'success': True, 'default': manager.default_action}, automation_mode)
        return

    if command == 'explain':
        if len(args) < 3:
            error_out('Usage: codrninja permissions explain <action> <path>', automation_mode)
        output({'explanation': manager.explain(args[1], args[2], 'build')}, automation_mode)
        return

    error_out('Usage: codrninja permissions [list|add|remove|default|explain]', automation_mode)


def handle_mcp(args, automation_mode: bool):
    manager = MCPManager()

    if not args or args[0] == 'list':
        servers = [
            {
                'name': server.name,
                'type': server.type,
                'enabled': server.enabled,
                'tool_count': len(server.tools),
            }
            for server in manager.list_servers()
        ]
        output({'servers': servers}, automation_mode)
        return

    command = args[0]

    if command == 'add':
        if len(args) < 3:
            error_out('Usage: codrninja mcp add <name> <config_json>', automation_mode)
        name = args[1]
        try:
            config = json.loads(' '.join(args[2:]))
        except json.JSONDecodeError as e:
            error_out(f'Invalid JSON: {e}', automation_mode)
        config['name'] = name
        server = manager.add_server(config)
        output({'added': server.name}, automation_mode)
        return

    if command == 'remove':
        if len(args) < 2:
            error_out('Usage: codrninja mcp remove <name>', automation_mode)
        output({'removed': manager.remove_server(args[1])}, automation_mode)
        return

    if command == 'tools':
        tools = manager.discover_tools(force=True)
        output({'tools': tools}, automation_mode)
        return

    error_out('Usage: codrninja mcp [list|add|remove|tools]', automation_mode)


def handle_lsp(args, automation_mode: bool):
    tools = ToolRegistry()

    if not args or args[0] == 'status':
        output({'servers': tools.lsp.status()}, automation_mode)
        return

    command = args[0]

    if command == 'start':
        if len(args) < 2:
            error_out('Usage: codrninja lsp start <lang>', automation_mode)
        language = args[1]
        client = tools.lsp.get_client(language)
        if not client:
            error_out(tools.lsp.install_hint(language), automation_mode)
        output({'started': language, 'command': client.command}, automation_mode)
        return

    if command == 'stop':
        if len(args) < 2:
            error_out('Usage: codrninja lsp stop <lang>', automation_mode)
        language = args[1]
        stopped = tools.lsp.stop(language)
        output({'stopped': stopped, 'language': language}, automation_mode)
        return

    if command == 'diagnostics':
        if len(args) < 2:
            error_out('Usage: codrninja lsp diagnostics <file>', automation_mode)
        result = tools.lsp_diagnostics(args[1])
        payload = {'success': result.success, 'file': args[1], 'diagnostics': result.output if result.success else None, 'error': result.error}
        output(payload, automation_mode)
        return

    error_out('Usage: codrninja lsp [status|start <lang>|stop <lang>|diagnostics <file>]', automation_mode)


if __name__ == '__main__':
    main()
