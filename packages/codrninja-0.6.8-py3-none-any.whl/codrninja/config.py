"""Configuration management for codrninja."""

import os
from dataclasses import dataclass, field
from typing import Literal, Optional, Dict, Any


@dataclass
class Config:
    """Configuration for codrninja."""
    
    # Provider settings
    default_provider: str = field(default_factory=lambda: os.environ.get("CODRNINJA_PROVIDER", "ollama"))
    default_model: str = field(default_factory=lambda: os.environ.get("CODRNINJA_MODEL", "codellama"))
    
    # Ollama
    ollama_url: str = field(default_factory=lambda: os.environ.get("OLLAMA_URL", "http://localhost:11434"))
    
    # OpenAI
    openai_api_key: str = field(default_factory=lambda: os.environ.get("OPENAI_API_KEY", ""))
    
    # Anthropic
    anthropic_api_key: str = field(default_factory=lambda: os.environ.get("ANTHROPIC_API_KEY", ""))
    
    # OpenRouter
    openrouter_api_key: str = field(default_factory=lambda: os.environ.get("OPENROUTER_API_KEY", ""))
    
    # Reasoning level
    reasoning_level: Literal["none", "low", "medium", "high"] = field(
        default_factory=lambda: os.environ.get("CODRNINJA_REASONING_LEVEL", "medium")
    )
    
    # Database
    db_path: str = field(default_factory=lambda: os.path.expanduser("~/.codrninja/sessions.db"))

    # Permissions
    permissions_mode: Literal["strict", "relaxed", "custom"] = field(
        default_factory=lambda: os.environ.get("CODRNINJA_PERMISSIONS_MODE", "custom")
    )
    
    # Prompt
    system_prompt: str = """You are an expert software engineer. You help write, review, and modify code.
When asked to create or modify files, respond with the file content in a code block.
Always specify the file path in the response.
Be concise and practical.
You can fetch web pages and search the internet for up-to-date information."""
    
    def get_provider_config(self, provider: Optional[str] = None) -> Dict[str, Any]:
        """Get configuration for a specific provider."""
        p = provider or self.default_provider
        
        configs = {
            "ollama": {
                "url": self.ollama_url,
                "model": self.default_model,
                "reasoning_level": self.reasoning_level
            },
            "openai": {
                "api_key": self.openai_api_key,
                "model": self.default_model,
                "reasoning_level": self.reasoning_level
            },
            "anthropic": {
                "api_key": self.anthropic_api_key,
                "model": self.default_model,
                "reasoning_level": self.reasoning_level
            },
            "openrouter": {
                "api_key": self.openrouter_api_key,
                "model": self.default_model,
                "reasoning_level": self.reasoning_level
            }
        }
        
        return configs.get(p, configs["ollama"])
    
    def update_provider_config(self):
        """Sync provider manager with current config."""
        from .providers import ProviderManager
        self.provider_manager = ProviderManager({
            "provider": self.default_provider,
            "providers": {
                "ollama": self.get_provider_config("ollama"),
                "openai": self.get_provider_config("openai"),
                "anthropic": self.get_provider_config("anthropic"),
                "openrouter": self.get_provider_config("openrouter")
            }
        })
    
    @classmethod
    def from_env(cls) -> "Config":
        """Create configuration from environment variables."""
        return cls()
    
    def ensure_db_dir(self):
        """Ensure database directory exists."""
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
