"""Agent loop for codrninja — makes it a real coding tool."""

import hashlib
import json
import os
import re
from typing import Dict, List, Optional, Any, Callable, TYPE_CHECKING

if TYPE_CHECKING:
    from .subagent import SubagentManager

from .config import Config
from .core import AICode
from .tools import ToolRegistry
from .permissions import PermissionManager, PermissionRule
from .skills import SkillRegistry
from .todo import TodoManager, TodoItem, format_todo_item


BASE_SYSTEM_PROMPT = """You are an expert software engineer. You help write, review, and modify code.

When you need to perform actions, use the TOOL format:

```tool
{
  "tool": "tool_name",
  "params": {
    "param1": "value1",
    "param2": "value2"
  }
}
```

Available tools:
- read_file: Read file contents. Params: path, offset, limit
- write_file: Write content to file. Params: path, content
- edit_file: Edit file by replacing text. Params: path, old_text, new_text
- execute_command: Run shell command. Params: command, cwd
- list_files: List directory contents. Params: path, depth
- search_files: Search for files. Params: pattern, path
- web_fetch: Fetch and clean a web page. Params: url, max_length, timeout
- web_search: Search the internet for up-to-date information. Params: query, num_results
- todo_add: Create a session todo item. Params: task, session_id(optional)
- todo_list: List session todo items. Params: session_id(optional)
- todo_complete: Mark a todo item as done. Params: todo_id
- todo_remove: Delete a todo item. Params: todo_id
- lsp_definition: Go to definition. Params: file_path, line, column
- lsp_hover: Get hover/type information. Params: file_path, line, column
- lsp_references: Find references. Params: file_path, line, column
- lsp_diagnostics: Get language diagnostics. Params: file_path
- lsp_symbols: Get document outline/symbols. Params: file_path
- lsp_rename: Preview rename edits. Params: file_path, line, column, new_name

Rules:
1. Always check existing files before modifying them
2. Use execute_command for builds, tests, git operations
3. Show file paths when creating or modifying files
4. Be concise but thorough
5. If a task requires multiple steps, use multiple tool calls
6. For multi-step work, use todo_add to track tasks and todo_list to review progress

After using tools, summarize what you did and any important findings.
You can fetch web pages and search the internet for up-to-date information.
You can use LSP tools for go-to-definition, hover info, find references, diagnostics, and symbols."""


class AgentMode:
    """Agent operating modes."""
    BUILD = "build"
    PLAN = "plan"
    SUBAGENT = "subagent"


class Agent:
    """Agent that can use tools to accomplish coding tasks."""

    def __init__(
        self,
        ai: AICode,
        session_name: str,
        max_iterations: int = 10,
        mode: str = AgentMode.BUILD,
        permission_manager: Optional[PermissionManager] = None,
        parent_permission_manager: Optional[PermissionManager] = None,
        max_steps: Optional[int] = None,
    ):
        self.ai = ai
        self.session_name = session_name
        self.config = Config.from_env()
        self.tools = ToolRegistry()
        self.tools.set_session(session_name)
        self.todo_manager = TodoManager()
        self.max_iterations = max_iterations
        self.mode = mode
        self.message_history = []
        self.on_progress: Optional[Callable[[str], None]] = None
        self.subagent_messages: List[Dict[str, Any]] = []
        self.subagent_manager: Optional["SubagentManager"] = None
        self.permission_decisions: List[Dict[str, Any]] = []
        self.doom_loop_counts: Dict[str, int] = {}
        self.max_steps = max_steps or int(os.environ.get("CODRNINJA_MAX_STEPS", "50"))
        self.step_count = 0
        self.skill_registry = SkillRegistry()
        self.skill_registry.discover()
        self.skill_registry.register_tools(self.tools)
        self.system_prompt = self._build_system_prompt()
        self.agent_type = self._resolve_agent_type(mode)
        self.permissions = permission_manager or PermissionManager(
            mode=self.config.permissions_mode,
            project_root=os.getcwd(),
            parent=parent_permission_manager,
        )
        self.tools.set_permissions(self.permissions, self.agent_type)

        if self.mode == AgentMode.PLAN:
            self._restrict_to_readonly()

        from .subagent import SubagentManager
        self.subagent_manager = SubagentManager(ai, self)

    def run(self, message: str, auto_approve: bool = False) -> Dict[str, Any]:
        """Run the agent loop with tool execution."""
        self.message_history.append({"role": "user", "content": message})
        context = self._build_context(message)
        iteration = 0
        tool_results = []
        content = ""
        previous_todo_ids = {item.id for item in self.todo_manager.list(self.session_name)}

        while iteration < self.max_iterations:
            iteration += 1
            response = self._call_ai(context)

            if not response.get('success'):
                return {
                    'success': False,
                    'error': response.get('error', 'Unknown error'),
                    'iterations': iteration,
                }

            content = response['response']
            tool_calls = self._parse_tool_calls(content)

            if not tool_calls:
                self.message_history.append({"role": "assistant", "content": content})
                todos = self.todo_manager.list(self.session_name)
                new_todos = [item for item in todos if item.id not in previous_todo_ids]
                return {
                    'success': True,
                    'response': content,
                    'iterations': iteration,
                    'tool_calls': len(tool_results),
                    'tools_used': tool_results,
                    'subagent_messages': self.subagent_messages,
                    'permission_decisions': self.permission_decisions,
                    'todos': [self._todo_to_dict(item) for item in todos],
                    'new_todos': [self._todo_to_dict(item) for item in new_todos],
                }

            for tool_call in tool_calls:
                if self.step_count >= self.max_steps:
                    return {
                        'success': False,
                        'error': f'Max steps exceeded ({self.max_steps})',
                        'iterations': iteration,
                        'permission_decisions': self.permission_decisions,
                    }

                tool_name = tool_call['tool']
                params = tool_call['params']
                loop_block = self._detect_doom_loop(tool_name, params)
                if loop_block:
                    tool_results.append({
                        'tool': tool_name,
                        'params': params,
                        'success': False,
                        'output': loop_block,
                    })
                    context += f"\n\n[Tool Result: {tool_name}]\nError: {loop_block}"
                    continue

                if not auto_approve:
                    permission_error = self._enforce_permission(tool_name, params)
                    if permission_error:
                        return {
                            'success': False,
                            'error': permission_error,
                            'iterations': iteration,
                            'permission_decisions': self.permission_decisions,
                        }

                self.step_count += 1
                result = self.tools.call(tool_name, **params)
                tool_results.append({
                    'tool': tool_name,
                    'params': params,
                    'success': result.success,
                    'output': result.output[:500] if result.success else (result.error or result.output),
                })

                context += f"\n\n[Tool Result: {tool_name}]\n"
                context += f"Success: {result.output[:500]}" if result.success else f"Error: {result.error or result.output}"

                if self.on_progress:
                    preview = result.output if result.success else (result.error or result.output or "")
                    self.on_progress(f"[OK] {tool_name}: {preview[:100]}...")

        self.message_history.append({"role": "assistant", "content": content})
        todos = self.todo_manager.list(self.session_name)
        new_todos = [item for item in todos if item.id not in previous_todo_ids]
        return {
            'success': True,
            'response': content,
            'iterations': iteration,
            'tool_calls': len(tool_results),
            'tools_used': tool_results,
            'subagent_messages': self.subagent_messages,
            'permission_decisions': self.permission_decisions,
            'todos': [self._todo_to_dict(item) for item in todos],
            'new_todos': [self._todo_to_dict(item) for item in new_todos],
            'note': 'Max iterations reached',
        }

    def _build_system_prompt(self) -> str:
        """Build the system prompt with active skills and reasoning level."""
        prompt = BASE_SYSTEM_PROMPT

        # Add reasoning level instructions
        level = self.config.reasoning_level
        if level == "none":
            prompt += "\n\nReasoning: Be concise. Do not explain your thought process."""
        elif level == "low":
            prompt += "\n\nReasoning: Provide brief reasoning (1-2 sentences max) for major decisions only."""
        elif level == "medium":
            prompt += "\n\nReasoning: Explain your approach briefly before implementing. Show key steps."""
        elif level == "high":
            prompt += "\n\nReasoning: Think step by step. Explain your reasoning thoroughly before each action. Consider alternatives and trade-offs."""

        skill_prompts = self.skill_registry.get_system_prompts()
        if skill_prompts:
            prompt += f"\n\nAdditional active skills:\n{skill_prompts}"
        return prompt

    def _build_context(self, message: str) -> str:
        """Build context for the AI including project info."""
        context = self.system_prompt + "\n\n"
        context += "Current directory: " + os.getcwd() + "\n"

        result = self.tools.list_files(path=".", depth=1)
        if result.success:
            context += "Files in current directory:\n" + result.output + "\n\n"

        context += "User: " + message + "\n\n"
        context += "Assistant: "
        return context

    def _call_ai(self, context: str) -> Dict[str, Any]:
        """Call the AI with context."""
        original_prompt = self.ai.config.system_prompt
        try:
            self.ai.config.system_prompt = self.system_prompt
            return self.ai.send_message(self.session_name, context)
        finally:
            self.ai.config.system_prompt = original_prompt

    def _parse_tool_calls(self, content: str) -> List[Dict[str, Any]]:
        """Parse tool calls from AI response."""
        tool_calls = []
        pattern = r'```tool\s*\n(.*?)\n```'
        matches = re.findall(pattern, content, re.DOTALL)

        for match in matches:
            try:
                tool_data = json.loads(match.strip())
                if 'tool' in tool_data and 'params' in tool_data:
                    tool_calls.append(tool_data)
            except json.JSONDecodeError:
                continue

        return tool_calls

    def _restrict_to_readonly(self):
        """Remove write/execute tools for plan mode."""
        readonly = {k: v for k, v in self.tools.tools.items() if k in ('read_file', 'list_files', 'search_files')}
        self.tools.tools = readonly

    def _resolve_agent_type(self, mode: str) -> str:
        if mode == AgentMode.PLAN:
            return "plan"
        if mode == AgentMode.SUBAGENT:
            return "subagent"
        return "build"

    def _permission_request(self, tool_name: str, params: Dict[str, Any]) -> tuple[str, str]:
        if tool_name == 'execute_command':
            return 'execute', params.get('command', '')
        return ('read' if tool_name == 'read_file' else 'write'), params.get('path', '')

    def _enforce_permission(self, tool_name: str, params: Dict[str, Any]) -> Optional[str]:
        action, target = self._permission_request(tool_name, params)
        decision = self.permissions.decide(action, target, self.agent_type)
        explanation = self.permissions.explain(action, target, self.agent_type)
        self.permission_decisions.append({
            'tool': tool_name,
            'action': action,
            'target': target,
            'decision': decision.action,
            'explanation': explanation,
        })

        if decision.action == 'deny':
            return f'Permission denied for {tool_name}: {explanation}'
        if decision.action == 'ask' and not self._ask_permission(action, target):
            return f'User denied permission for {tool_name}: {explanation}'
        return None

    def _ask_permission(self, action: str, target: str) -> bool:
        """Ask user for permission (interactive mode)."""
        prompt = f"Allow {action} on {target}? [y/N/always/never] "
        try:
            response = input(prompt).strip().lower()
        except (EOFError, KeyboardInterrupt):
            return False

        if response in {'y', 'yes'}:
            self.permission_decisions.append({'interactive': 'yes', 'action': action, 'target': target})
            return True
        if response == 'always':
            self.permissions.add_rule(PermissionRule(target or '*', 'allow', action, self.agent_type, 1000))
            self.permission_decisions.append({'interactive': 'always', 'action': action, 'target': target})
            return True
        if response == 'never':
            self.permissions.add_rule(PermissionRule(target or '*', 'deny', action, self.agent_type, 1000))
            self.permission_decisions.append({'interactive': 'never', 'action': action, 'target': target})
            return False
        return False

    def _detect_doom_loop(self, tool_name: str, params: Dict[str, Any]) -> Optional[str]:
        signature = hashlib.sha256(json.dumps({'tool': tool_name, 'params': params}, sort_keys=True).encode()).hexdigest()
        count = self.doom_loop_counts.get(signature, 0) + 1
        self.doom_loop_counts[signature] = count
        if count >= 3:
            warning = f'Doom loop detected for {tool_name} with identical input; auto-denied after {count} attempts'
            self.permission_decisions.append({'tool': tool_name, 'decision': 'deny', 'reason': warning})
            return warning
        return None

    def spawn_subagent(self, name: str, task: str, mode: str = AgentMode.BUILD):
        """Spawn and return a child subagent."""
        if not self.subagent_manager:
            from .subagent import SubagentManager
            self.subagent_manager = SubagentManager(self.ai, self)
        return self.subagent_manager.spawn(name=name, task=task, mode=mode)

    def receive_subagent_message(self, message: Dict[str, Any]):
        """Receive a result from a subagent."""
        self.subagent_messages.append(message)
        summary = message.get("result", {}).get("response") or message.get("result", {}).get("error") or "Subagent completed"
        self.message_history.append({
            "role": "assistant",
            "content": f"[Subagent {message.get('name')}] {summary}",
        })

    def _todo_to_dict(self, item: TodoItem) -> Dict[str, Any]:
        return {
            'id': item.id,
            'task': item.task,
            'status': item.status,
            'created_at': item.created_at,
            'completed_at': item.completed_at,
            'session_id': item.session_id,
            'display': format_todo_item(item),
        }

    def format_todos_for_display(self, todos: List[Dict[str, Any]]) -> str:
        return "\n".join(todo.get('display', f"□ [{todo['id']}] {todo['task']}") for todo in todos)

    def stream_run(self, message: str, auto_approve: bool = False):
        """Run with streaming output."""
        result = self.run(message, auto_approve)
        yield result
