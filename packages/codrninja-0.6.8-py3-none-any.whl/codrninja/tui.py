#!/usr/bin/env python3
"""
codrninja TUI -- Interactive coding assistant using prompt_toolkit.
Features: Auto-onboarding, provider/model selection, slash commands.
"""

import json
import os
import shlex
import sys
from typing import Optional

try:
    from prompt_toolkit import PromptSession
    from prompt_toolkit.completion import Completer, Completion
    from prompt_toolkit.styles import Style
    HAS_PROMPT = True
except ImportError:
    HAS_PROMPT = False

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.syntax import Syntax
    from rich.markdown import Markdown
    from rich.status import Status
    from rich.table import Table
    from rich.text import Text
    from rich import box
    HAS_RICH = True
except ImportError:
    HAS_RICH = False

from codrninja.core import AICode
from codrninja.agent import Agent, AgentMode
from codrninja.tools import ToolRegistry
from codrninja.skills import SkillRegistry
from codrninja.mcp import MCPManager
from codrninja.permissions import PermissionRule
from codrninja.todo import format_todo_item


CODRNINJA_LOGO = """
╔═════════════════════════════════════════════════════════════════════════════════════╗
║                                                                                     ║
║   ██████╗  ██████╗  ██████╗   ██████╗  ███╗   ██╗ ██╗ ███╗   ██╗      ██╗  █████╗   ║
║  ██╔════╝ ██╔═══██╗ ██╔══ ██╗ ██╔══██╗ ████╗  ██║ ██║ ████╗  ██║      ██║ ██╔══██╗  ║
║  ██║      ██║   ██║ ██║   ██║ ██████╔╝ ██╔██╗ ██║ ██║ ██╔██╗ ██║      ██║ ███████║  ║
║  ██║      ██║   ██║ ██║   ██║ ██╔══██╗ ██║╚██╗██║ ██║ ██║╚██╗██║ ██   ██║ ██╔══██║  ║
║  ╚██████╗ ╚██████╔╝ ██████╔╝  ██║  ██║ ██║ ╚████║ ██║ ██║ ╚████║ ╚█████╔╝ ██║  ██║  ║
║   ╚═════╝  ╚═════╝  ╚═════╝   ╚═╝  ╚═╝ ╚═╝  ╚═══╝ ╚═╝ ╚═╝  ╚═══╝  ╚════╝  ╚═╝  ╚═╝  ║
║                                                                                     ║
║                       AI-first coding assistant for automation                      ║
║                                                                                     ║
╚═════════════════════════════════════════════════════════════════════════════════════╝
"""

SLASH_COMMANDS = {
    "/build": "Implement a task in build mode",
    "/clear": "Clear screen",
    "/commit": "Git commit changes",
    "/context": "Show project context",
    "/exec": "Execute shell command",
    "/exit": "Exit codrninja",
    "/explain": "Explain code or concept",
    "/fetch": "Fetch and clean a web page",
    "/files": "List files in directory",
    "/help": "Show detailed help",
    "/mcp": "Manage MCP servers and tools",
    "/model": "Show AI configuration",
    "/lsp": "Manage language servers and diagnostics",
    "/permissions": "Manage permission rules",
    "/plan": "Plan a feature or task",
    "/reasoning": "Set reasoning level (none/low/medium/high)",
    "/read": "Read file",
    "/review": "Review code for issues",
    "/search": "Search the web",
    "/session": "Show session info",
    "/skills": "List installed skills",
    "/subagents": "List or kill active subagents",
    "/test": "Run tests",
    "/todo": "Manage session todos",
}

BUILTIN_SUBAGENTS = {
    "general": AgentMode.BUILD,
    "explore": AgentMode.PLAN,
}

PROVIDERS = {
    "ollama": {
        "name": "Ollama (local or cloud subscription)",
        "models": [],  # populated dynamically from /api/tags
        "needs_key": False,
        "default_url": "http://localhost:11434",
        "can_custom_url": True,
    },
    "openai": {
        "name": "OpenAI (GPT-4, GPT-3.5)",
        "models": ["gpt-4", "gpt-4-turbo", "gpt-3.5-turbo"],
        "needs_key": True,
        "env_var": "OPENAI_API_KEY",
    },
    "anthropic": {
        "name": "Anthropic (Claude)",
        "models": ["claude-3-opus-20240229", "claude-3-sonnet-20240229", "claude-3-haiku-20240307"],
        "needs_key": True,
        "env_var": "ANTHROPIC_API_KEY",
    },
    "openrouter": {
        "name": "OpenRouter (all models)",
        "models": ["openai/gpt-4", "anthropic/claude-3-opus", "google/gemini-pro"],
        "needs_key": True,
        "env_var": "OPENROUTER_API_KEY",
    },
}

CONFIG_DIR = os.path.expanduser("~/.config/codrninja")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")


if HAS_PROMPT:
    class SlashCompleter(Completer):
        """Custom completer for slash commands."""

        def get_completions(self, document, complete_event):
            text = document.text
            if not text.startswith('/'):
                return

            partial = text[1:]
            for cmd, desc in SLASH_COMMANDS.items():
                if cmd[1:].startswith(partial):
                    yield Completion(
                        cmd,
                        start_position=-len(text),
                        display=f"{cmd:18} {desc}",
                        display_meta=desc,
                    )


class TUI:
    """Terminal User Interface using prompt_toolkit."""

    def __init__(self, ai: AICode, session_name: str):
        self.ai = ai
        self.session_name = session_name
        self.console = Console() if HAS_RICH else None
        self.tools = ToolRegistry()
        self.mcp = MCPManager()
        self.skill_registry = SkillRegistry()
        self.skill_registry.discover()
        self.agent = Agent(ai, session_name)

    def start(self):
        """Start the TUI."""
        if not HAS_PROMPT:
            print("Error: prompt_toolkit not installed")
            print("Run: pip3 install prompt_toolkit")
            return

        if not self._has_config():
            self._onboarding()

        self._show_welcome()

        style = Style.from_dict({
            'prompt': '#00aa00 bold',
            'completion-menu': 'bg:#333333 #ffffff',
            'completion-menu.completion.current': 'bg:#ffffff #000000',
        })

        session = PromptSession(
            completer=SlashCompleter(),
            style=style,
            complete_while_typing=True,
            multiline=False,
        )

        while True:
            try:
                message = session.prompt(self._prompt_text())

                if not message.strip():
                    continue
                if message.lower() in ['exit', 'quit', 'q']:
                    print("\nGoodbye!\n")
                    break
                if message.startswith('/'):
                    if not self._handle_command(message):
                        break
                    continue

                if self._handle_subagent_mention(message):
                    continue

                self._run_agent(message, AgentMode.BUILD)
            except KeyboardInterrupt:
                print("\nInterrupted. Type 'exit' to quit.")
            except EOFError:
                break

    def _has_config(self) -> bool:
        return os.path.exists(CONFIG_FILE)

    def _load_config(self) -> dict:
        if not self._has_config():
            return {}
        with open(CONFIG_FILE, 'r') as f:
            return json.load(f)

    def _save_config(self, config: dict):
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=2)

    def _select_option(self, options: list[str], prompt_text: str = "Select:") -> int:
        """Arrow-key selectable list using prompt_toolkit."""
        from prompt_toolkit.application import Application
        from prompt_toolkit.key_binding import KeyBindings
        from prompt_toolkit.layout import Layout, HSplit, Window, FormattedTextControl

        selected = [0]

        kb = KeyBindings()

        @kb.add('up')
        def _(event):
            selected[0] = (selected[0] - 1) % len(options)
            event.app.invalidate()

        @kb.add('down')
        def _(event):
            selected[0] = (selected[0] + 1) % len(options)
            event.app.invalidate()

        @kb.add('enter')
        def _(event):
            event.app.exit(result=selected[0])

        @kb.add('c-c')
        @kb.add('c-q')
        def _(event):
            event.app.exit(result=None)

        def get_text():
            lines = [prompt_text]
            for i, opt in enumerate(options):
                prefix = "> " if i == selected[0] else "  "
                lines.append(f"{prefix}{opt}")
            return "\n".join(lines) + "\n"

        root = HSplit([
            Window(FormattedTextControl(get_text), height=len(options) + 1)
        ])

        app = Application(layout=Layout(root), key_bindings=kb, full_screen=False)
        return app.run()

    def _onboarding(self):
        print("\n" + "=" * 80)
        print("  Welcome to codrninja!")
        print("  Let's set up your AI provider.")
        print("=" * 80 + "\n")

        print("Step 1: Choose your AI provider\n")
        providers_list = list(PROVIDERS.items())
        provider_names = [info['name'] for _, info in providers_list]
        idx = self._select_option(provider_names, "Select AI provider (↑↓ arrows, Enter to confirm):")
        if idx is None:
            print("Setup cancelled.")
            return

        provider_key, provider_info = providers_list[idx]
        print(f"\n  Selected: {provider_info['name']}\n")

        api_key = None
        if provider_info.get('needs_key'):
            env_var = provider_info['env_var']
            existing = os.environ.get(env_var, "")

            if existing:
                print(f"  Found {env_var} in environment.")
                use_existing = input("  Use existing key? [Y/n]: ").strip().lower()
                if use_existing in ['', 'y', 'yes']:
                    api_key = existing

            if not api_key:
                print(f"\n  Please enter your {provider_info['name'].split('(')[0].strip()} API key:")
                api_key = input("  > ").strip()

                if api_key:
                    shell_config = self._get_shell_config()
                    if shell_config:
                        with open(shell_config, "a") as f:
                            f.write("\n# codrninja config\n")
                            f.write(f"export {env_var}=\"{api_key}\"\n")
                        print(f"\n  Saved to {shell_config}")

        # Ollama URL handling with auto-detection
        ollama_url = None
        if provider_key == "ollama":
            default_url = provider_info.get('default_url', 'http://localhost:11434')
            print(f"\nStep 1b: Ollama server URL")
            print(f"  Default: {default_url}")
            print(f"  (Enter custom URL or press Enter for default)\n")
            custom_url = input("  Ollama URL: ").strip()
            ollama_url = custom_url if custom_url else default_url
            print(f"  Using: {ollama_url}\n")

            print("  Detecting available models...")
            detected = self._detect_ollama_models(ollama_url)
            if detected:
                print(f"  Found {len(detected)} model(s): {', '.join(detected)}\n")
            else:
                print("  No models detected. Make sure Ollama is running.\n")

        print(f"\nStep 2: Choose a model for {provider_info['name']}\n")
        if provider_key == "ollama" and detected:
            models = detected
        else:
            models = provider_info['models']

        if not models:
            print("  No models available. Using default.")
            model = "codellama"
        else:
            model_idx = self._select_option(models, f"Select model for {provider_info['name']}:")
            if model_idx is None:
                print("Setup cancelled.")
                return
            model = models[model_idx]

        print(f"\n  Selected model: {model}\n")

        config = {"provider": provider_key, "model": model}
        if ollama_url:
            config["ollama_url"] = ollama_url
        if api_key:
            config["api_key"] = api_key
        self._save_config(config)

        self.ai.config.default_provider = provider_key
        self.ai.config.default_model = model
        if ollama_url:
            self.ai.config.ollama_url = ollama_url
        self.ai.config.update_provider_config()

        print("=" * 80)
        print("  Setup complete!")
        print(f"  Provider: {provider_info['name']}")
        print(f"  Model: {model}")
        if ollama_url:
            print(f"  URL: {ollama_url}")
        print("=" * 80 + "\n")
        print("  You can change this later with /model")
        print("  Press Enter to continue...\n")
        input()

    def _detect_ollama_models(self, url: str) -> list[str]:
        """Query Ollama /api/tags to detect available models."""
        try:
            import requests
            resp = requests.get(f"{url}/api/tags", timeout=5)
            if resp.status_code == 200:
                data = resp.json()
                return [m["name"] for m in data.get("models", [])]
        except Exception:
            pass
        return []

    def _get_shell_config(self) -> Optional[str]:
        if os.path.exists(os.path.expanduser("~/.zshrc")):
            return os.path.expanduser("~/.zshrc")
        if os.path.exists(os.path.expanduser("~/.bashrc")):
            return os.path.expanduser("~/.bashrc")
        if os.path.exists(os.path.expanduser("~/.bash_profile")):
            return os.path.expanduser("~/.bash_profile")
        return None

    def _show_welcome(self):
        web_status = "enabled" if os.environ.get("NO_WEB", "").strip().lower() not in {"1", "true", "yes", "on"} else "disabled"
        reasoning = self.agent.config.reasoning_level
        ctx_map = {"none": "2K", "low": "4K", "medium": "8K", "high": "16K"}
        ctx_size = ctx_map.get(reasoning, "8K")
        if self.console:
            for line in CODRNINJA_LOGO.strip().split('\n'):
                self.console.print(f"[bold cyan]{line}[/bold cyan]")
            self.console.print(f"\n  Session: [bold yellow]{self.session_name}[/bold yellow]")
            self.console.print(f"  MCP tools: [bold green]{self.tools.mcp.tool_count()}[/bold green]")
            self.console.print(f"  Web tools: [bold green]{web_status}[/bold green]")
            self.console.print(f"  Pending todos: [bold yellow]{self._pending_todo_count()}[/bold yellow]")
            self.console.print(f"  Permissions: [bold magenta]{self.agent.config.permissions_mode}[/bold magenta]")
            self.console.print(f"  Reasoning: [bold blue]{reasoning}[/bold blue] ([bold blue]{ctx_size} ctx[/bold blue])")
            self.console.print("  Type / for commands, or just start typing\n")
        else:
            print(CODRNINJA_LOGO)
            print(f"\n  Session: {self.session_name}")
            print(f"  MCP tools: {self.tools.mcp.tool_count()}")
            print(f"  Web tools: {web_status}")
            print(f"  Pending todos: {self._pending_todo_count()}")
            print(f"  Permissions: {self.agent.config.permissions_mode}")
            print(f"  Reasoning: {reasoning} ({ctx_size} ctx)")
            print("  Type / for commands\n")

    def _run_agent(self, message: str, mode: str):
        self.agent = Agent(self.ai, self.session_name, mode=mode)
        if self.console:
            with Status("[bold yellow]Thinking...[/bold yellow]", spinner="dots", console=self.console):
                result = self.agent.run(message, auto_approve=False)
        else:
            print("Thinking...")
            result = self.agent.run(message, auto_approve=False)

        if not result['success']:
            error_text = result.get('error', 'Unknown error')
            if self.console:
                style = 'yellow' if 'requires confirmation' in error_text else 'red'
                self.console.print(f"\n[bold {style}]Error:[/bold {style}] {error_text}")
            else:
                print(f"\nError: {error_text}")
            return

        if self.console:
            self._display_response(result['response'])
            if result.get('new_todos'):
                self._show_todo_panel(result['new_todos'], title='New Todos')
            if result.get('tool_calls', 0) > 0:
                self._show_tool_usage(result['tools_used'], result['iterations'])
        else:
            print(f"\nAI: {result['response']}")
            if result.get('new_todos'):
                print("\nNew Todos:")
                for todo in result['new_todos']:
                    print(f"  {todo.get('display')}")

    def _handle_command(self, command: str) -> bool:
        parts = shlex.split(command)
        cmd = parts[0].lower()

        if cmd == '/exit':
            print("\nGoodbye!\n")
            return False
        if cmd == '/help':
            print("\nCommands:")
            for c, d in SLASH_COMMANDS.items():
                print(f"  {c:16} {d}")
            print()
            return True
        if cmd == '/clear':
            os.system('clear' if os.name != 'nt' else 'cls')
            self._show_welcome()
            return True
        if cmd == '/files':
            result = self.tools.list_files(path='.', depth=2)
            self._render_tool_output('Files', result, 'blue')
            return True
        if cmd == '/model':
            self._show_model_config()
            return True
        if cmd == '/reasoning':
            self._handle_reasoning_command()
            return True
        if cmd == '/permissions':
            self._handle_permissions_command(parts[1:])
            return True
        if cmd == '/mcp':
            self._handle_mcp_command(parts[1:])
            return True
        if cmd == '/lsp':
            self._handle_lsp_command(parts[1:])
            return True
        if cmd == '/session':
            history = self.ai.get_history(self.session_name)
            if history:
                print(f"\nSession: {self.session_name}")
                print(f"Messages: {len(history['messages'])}")
            else:
                print(f"\nSession: {self.session_name} (new)")
            subagents = self.agent.subagent_manager.list() if self.agent.subagent_manager else []
            print(f"Active subagents: {len(subagents)}")
            for subagent in subagents:
                print(f"  - {subagent['session_id']} [{subagent['mode']}] {subagent['task']}")
            return True
        if cmd == '/skills':
            self._show_skills()
            return True
        if cmd == '/subagents':
            action = parts[1].lower() if len(parts) > 1 else 'list'
            manager = self.agent.subagent_manager
            if not manager:
                print("No subagent manager available.")
                return True
            if action == 'kill':
                if len(parts) < 3:
                    print("Usage: /subagents kill <session_id>")
                    return True
                if manager.kill(parts[2]):
                    print(f"Killed subagent: {parts[2]}")
                else:
                    print(f"Subagent not found: {parts[2]}")
                return True
            subagents = manager.list()
            if not subagents:
                print("No active subagents.")
                return True
            print("Active subagents:")
            for subagent in subagents:
                print(f"  - {subagent['session_id']} [{subagent['mode']}] {subagent['task']}")
            return True
        if cmd == '/exec' and len(parts) > 1:
            result = self.tools.execute_command(' '.join(parts[1:]))
            self._render_tool_output('Command', result, 'green')
            return True
        if cmd == '/todo':
            self._handle_todo_command(parts[1:])
            return True
        if cmd == '/search' and len(parts) > 1:
            result = self.tools.web_search(' '.join(parts[1:]))
            self._render_tool_output('Search', result, 'cyan')
            return True
        if cmd == '/fetch' and len(parts) > 1:
            result = self.tools.web_fetch(parts[1])
            self._render_tool_output('Fetch', result, 'cyan')
            return True
        if cmd == '/read' and len(parts) > 1:
            result = self.tools.read_file(parts[1])
            if result.success:
                self._maybe_open_lsp_document(parts[1])
            if result.success and self.console:
                ext = os.path.splitext(parts[1])[1]
                lang_map = {'.py': 'python', '.js': 'javascript', '.ts': 'typescript', '.jsx': 'javascript', '.tsx': 'typescript', '.json': 'json', '.css': 'css', '.html': 'html', '.md': 'markdown'}
                syntax = Syntax(result.output, lang_map.get(ext, 'text'), theme='monokai', line_numbers=True)
                self.console.print(Panel(syntax, title=parts[1], border_style='blue'))
            elif result.success:
                print(f"\n{result.output}")
            else:
                print(f"Error: {result.error}")
            return True
        if cmd == '/plan':
            topic = ' '.join(parts[1:]) if len(parts) > 1 else input('What to plan? ')
            self._run_agent(f"Create a detailed plan for: {topic}", AgentMode.PLAN)
            return True
        if cmd == '/build':
            topic = ' '.join(parts[1:]) if len(parts) > 1 else input('What to build? ')
            self._run_agent(f"Implement: {topic}", AgentMode.BUILD)
            return True
        if cmd == '/review':
            target = parts[1] if len(parts) > 1 else input('File to review? ')
            result = self.tools.read_file(target)
            if result.success:
                self._run_agent(f"Review this code:\n\n{result.output}", AgentMode.PLAN)
            else:
                print(f"Error: {result.error}")
            return True
        if cmd == '/explain':
            target = ' '.join(parts[1:]) if len(parts) > 1 else input('What to explain? ')
            self._run_agent(f"Explain: {target}", AgentMode.PLAN)
            return True
        if cmd == '/test':
            target = ' '.join(parts[1:]) if len(parts) > 1 else 'pytest -q'
            result = self.tools.execute_command(target)
            self._render_tool_output(target, result, 'green')
            return True
        if cmd == '/commit':
            msg = ' '.join(parts[1:]) if len(parts) > 1 else input('Commit message? ')
            self.tools.execute_command('git add -A')
            result = self.tools.execute_command(f'git commit -m {shlex.quote(msg)}')
            if result.success:
                print(f"[OK] Committed: {msg}")
            else:
                print(f"Error: {result.error}")
            return True

        print(f"Unknown command: {cmd}. Type /help for list.")
        return True

    def _handle_subagent_mention(self, message: str) -> bool:
        if not message.startswith('@'):
            return False
        mention, _, task = message.partition(' ')
        name = mention[1:].strip().lower()
        task = task.strip()
        if not name or not task:
            print("Usage: @subagent_name task")
            return True

        mode = BUILTIN_SUBAGENTS.get(name, AgentMode.BUILD)
        subagent = self.agent.spawn_subagent(name, task, mode)
        if self.console:
            with Status(f"[bold yellow]Subagent {name} thinking...[/bold yellow]", spinner="dots", console=self.console):
                result = subagent.run(task, auto_approve=False)
        else:
            print(f"Subagent {name} thinking...")
            result = subagent.run(task, auto_approve=False)

        label = f"Subagent @{name}"
        if result.get('success'):
            if self.console:
                self.console.print(f"\n[bold magenta]{label}:[/bold magenta]")
                self._display_response(result['response'])
            else:
                print(f"\n{label}: {result['response']}")
        else:
            print(f"{label} error: {result.get('error', 'Unknown error')}")
        return True

    def _prompt_text(self) -> str:
        return f"You[{self._pending_todo_count()}]{self._lsp_prompt_status()}: "

    def _pending_todo_count(self) -> int:
        stats = self.tools.todo_manager.stats(self.session_name)
        return stats.get('pending', 0)

    def _todo_style(self, status: str) -> str:
        if status == 'done':
            return 'green'
        if status == 'cancelled':
            return 'red'
        return 'yellow'

    def _show_todo_panel(self, todos: list[dict], title: str = 'Todos'):
        if not self.console:
            return
        renderable = Text()
        for todo in todos:
            renderable.append(todo.get('display', ''), style=self._todo_style(todo.get('status', 'pending')))
            renderable.append('\n')
        self.console.print(Panel(renderable, title=title, border_style='yellow'))

    def _handle_lsp_command(self, args: list[str]):
        action = args[0].lower() if args else 'status'
        if action == 'status':
            rows = self.tools.lsp.status()
            if not rows:
                print('No language server configurations found.')
                return
            for row in rows:
                state = 'running' if row['running'] else 'stopped'
                availability = 'available' if row['available'] else 'missing'
                suffix = f" — {row['last_error']}" if row.get('last_error') else ''
                print(f"{row['language']}: {state}, {availability}, command={' '.join(row['command'])}{suffix}")
            return
        if action == 'start':
            if len(args) < 2:
                print('Usage: /lsp start <lang>')
                return
            client = self.tools.lsp.get_client(args[1])
            if client:
                print(f"Started LSP server for {args[1]}: {' '.join(client.command)}")
            else:
                print(self.tools.lsp.install_hint(args[1]))
            return
        if action == 'stop':
            if len(args) < 2:
                print('Usage: /lsp stop <lang>')
                return
            if self.tools.lsp.stop(args[1]):
                print(f"Stopped LSP server for {args[1]}")
            else:
                print(f"No running LSP server for {args[1]}")
            return
        if action == 'diagnostics':
            if len(args) < 2:
                print('Usage: /lsp diagnostics <file>')
                return
            result = self.tools.lsp_diagnostics(args[1])
            self._render_tool_output('LSP Diagnostics', result, 'yellow')
            return
        if action == 'symbols':
            if len(args) < 2:
                print('Usage: /lsp symbols <file>')
                return
            result = self.tools.lsp_symbols(args[1])
            self._render_tool_output('LSP Symbols', result, 'blue')
            return
        print('Usage: /lsp [status|start <lang>|stop <lang>|diagnostics <file>|symbols <file>]')

    def _lsp_prompt_status(self) -> str:
        active = [row for row in self.tools.lsp.status() if row['running']]
        if not active:
            return ''
        label = active[0]['command'][0].split('/')[-1]
        extra = f" +{len(active) - 1}" if len(active) > 1 else ''
        return f" [{label} ✓{extra}]"

    def _maybe_open_lsp_document(self, file_path: str):
        try:
            self.tools.lsp.ensure_document_open(file_path)
        except Exception:
            return

    def _handle_todo_command(self, args: list[str]):
        action = args[0].lower() if args else 'list'
        if action == 'list':
            todos = self.tools.todo_manager.list(self.session_name)
            if not todos:
                print('No todos for this session.')
                return
            payload = [
                {
                    'display': format_todo_item(todo),
                    'status': todo.status,
                }
                for todo in todos
            ]
            if self.console:
                self._show_todo_panel(payload)
            else:
                for todo in payload:
                    print(todo['display'])
            return
        if action == 'add':
            task = ' '.join(args[1:]).strip()
            if not task:
                print('Usage: /todo add <task>')
                return
            result = self.tools.todo_add(task, session_id=self.session_name)
            self._render_tool_output('Todo', result, 'yellow')
            return
        if action == 'done':
            if len(args) < 2:
                print('Usage: /todo done <id>')
                return
            result = self.tools.todo_complete(args[1])
            self._render_tool_output('Todo', result, 'green')
            return
        if action == 'remove':
            if len(args) < 2:
                print('Usage: /todo remove <id>')
                return
            result = self.tools.todo_remove(args[1])
            self._render_tool_output('Todo', result, 'red')
            return
        if action == 'clear':
            removed = self.tools.todo_manager.clear_completed(self.session_name)
            print(f'Removed {removed} completed todos.')
            return
        print('Usage: /todo [add <task>|done <id>|remove <id>|clear]')

    def _handle_permissions_command(self, args: list[str]):
        action = args[0].lower() if args else 'list'
        manager = self.agent.permissions

        if action == 'list':
            rules = manager.list_rules()
            if not rules:
                print('No permission rules configured.')
                return
            for rule in rules:
                print(f"{rule.priority:>5} {rule.action:<5} {rule.scope:<7} {rule.agent_type:<8} {rule.pattern}")
            return

        if action == 'add':
            if len(args) < 3:
                print('Usage: /permissions add <pattern> <action> [<scope>]')
                return
            pattern = args[1]
            rule_action = args[2]
            scope = args[3] if len(args) > 3 else 'all'
            manager.add_rule(PermissionRule(pattern, rule_action, scope, 'all', 100))
            print(f'Added rule: {pattern} -> {rule_action} ({scope})')
            return

        if action == 'remove':
            if len(args) < 2:
                print('Usage: /permissions remove <pattern>')
                return
            if manager.remove_rule(args[1]):
                print(f'Removed rule: {args[1]}')
            else:
                print(f'Rule not found: {args[1]}')
            return

        if action == 'default':
            if len(args) < 2:
                print('Usage: /permissions default <action>')
                return
            manager.set_default(args[1])
            print(f'Default permission set to: {args[1]}')
            return

        if action == 'explain':
            if len(args) < 3:
                print('Usage: /permissions explain <action> <path>')
                return
            print(manager.explain(args[1], args[2], self.agent.agent_type))
            return

        print('Usage: /permissions [add|remove|default|explain]')

    def _show_model_config(self):
        """Interactive model/provider config with arrow-key selection."""
        config = self._load_config()
        current_provider = config.get('provider', self.ai.config.default_provider)
        current_model = config.get('model', self.ai.config.default_model)

        print("\n" + "=" * 60)
        print("  Current Configuration")
        print("=" * 60)
        print(f"  Provider: {current_provider}")
        print(f"  Model: {current_model}")
        if 'ollama_url' in config:
            print(f"  Ollama URL: {config['ollama_url']}")
        print("=" * 60)

        # Step 1: Select provider
        providers_list = list(PROVIDERS.items())
        provider_names = [info['name'] for _, info in providers_list]
        provider_idx = self._select_option(
            provider_names,
            "Select provider (↑↓ arrows, Enter to confirm, Ctrl+C to cancel):"
        )
        if provider_idx is None:
            print("\nCancelled.")
            return

        provider_key, provider_info = providers_list[provider_idx]
        print(f"\n  Selected: {provider_info['name']}")

        # Handle API key if needed
        api_key = None
        if provider_info.get('needs_key'):
            env_var = provider_info['env_var']
            existing = os.environ.get(env_var, "")

            if existing:
                print(f"  Found {env_var} in environment.")
                use_existing = input("  Use existing key? [Y/n]: ").strip().lower()
                if use_existing in ['', 'y', 'yes']:
                    api_key = existing

            if not api_key:
                print(f"\n  Please enter your {provider_info['name'].split('(')[0].strip()} API key:")
                api_key = input("  > ").strip()

                if api_key:
                    shell_config = self._get_shell_config()
                    if shell_config:
                        with open(shell_config, "a") as f:
                            f.write("\n# codrninja config\n")
                            f.write(f"export {env_var}=\"{api_key}\"\n")
                        print(f"\n  Saved to {shell_config}")

        # Handle Ollama URL
        ollama_url = None
        if provider_key == "ollama":
            default_url = config.get('ollama_url', provider_info.get('default_url', 'http://localhost:11434'))
            print(f"\n  Current Ollama URL: {default_url}")
            custom_url = input("  New URL (or Enter to keep): ").strip()
            ollama_url = custom_url if custom_url else default_url
            print(f"  Using: {ollama_url}\n")
            print("  Detecting models...")
            detected = self._detect_ollama_models(ollama_url)
            if detected:
                print(f"  Found {len(detected)} model(s)\n")
            else:
                print("  No models detected. Is Ollama running?\n")

        # Step 2: Select model
        if provider_key == "ollama" and detected:
            models = detected
        else:
            models = provider_info['models']

        if not models:
            print("  No models available. Using default.")
            model = "codellama"
        else:
            model_idx = self._select_option(
                models,
                f"Select model for {provider_info['name']} (↑↓ arrows, Enter to confirm):"
            )
            if model_idx is None:
                print("\nCancelled.")
                return
            model = models[model_idx]

        print(f"\n  Selected model: {model}")

        # Save config
        new_config = {"provider": provider_key, "model": model}
        if ollama_url:
            new_config["ollama_url"] = ollama_url
        if api_key:
            new_config["api_key"] = api_key
        self._save_config(new_config)

        self.ai.config.default_provider = provider_key
        self.ai.config.default_model = model
        if ollama_url:
            self.ai.config.ollama_url = ollama_url
        self.ai.config.update_provider_config()

        print("\n" + "=" * 60)
        print("  Configuration updated!")
        print(f"  Provider: {provider_info['name']}")
        print(f"  Model: {model}")
        if ollama_url:
            print(f"  URL: {ollama_url}")
        print("=" * 60 + "\n")

    def _handle_reasoning_command(self):
        """Interactive reasoning level selection with arrow keys."""
        levels = ["none", "low", "medium", "high"]
        descriptions = [
            "none   — No reasoning, just do it",
            "low    — Brief reasoning (1-2 sentences)",
            "medium — Explain approach before implementing",
            "high   — Think step by step, consider alternatives",
        ]
        current = self.agent.config.reasoning_level

        print("\n" + "=" * 60)
        print("  Reasoning Level")
        print("=" * 60)
        print(f"  Current: {current}\n")

        idx = self._select_option(
            descriptions,
            "Select reasoning level (↑↓ arrows, Enter to confirm, Ctrl+C to cancel):"
        )
        if idx is None:
            print("\nCancelled.")
            return

        level = levels[idx]
        self.agent.config.reasoning_level = level
        self.ai.config.reasoning_level = level

        # Update provider config so models get the real reasoning parameter
        provider = self.ai.config.default_provider
        provider_config = self.ai.config.get_provider_config(provider)
        provider_config["reasoning_level"] = level

        # Save to config file
        config = self._load_config()
        config["reasoning_level"] = level
        self._save_config(config)

        print(f"\n  Reasoning level set to: {level}")
        print("=" * 60 + "\n")

    def _handle_mcp_command(self, args: list[str]):
        action = args[0].lower() if args else 'list'

        if action == 'list':
            self.tools.refresh_mcp_tools(force=True)
            servers = self.mcp.list_servers()
            if not servers:
                print("No MCP servers configured.")
                return
            print("MCP servers:")
            for server in servers:
                status = 'enabled' if server.enabled else 'disabled'
                print(f"  - {server.name} [{server.type}] {status} ({len(server.tools)} tools)")
            return

        if action in {'enable', 'disable'}:
            if len(args) < 2:
                print(f"Usage: /mcp {action} <server>")
                return
            ok = self.mcp.enable(args[1]) if action == 'enable' else self.mcp.disable(args[1])
            if ok:
                self.tools.refresh_mcp_tools(force=True)
                print(f"MCP server {action}d: {args[1]}")
            else:
                print(f"Unknown MCP server: {args[1]}")
            return

        if action == 'add':
            if len(args) > 1:
                config_text = ' '.join(args[1:])
            else:
                print("Paste MCP server JSON config:")
                config_text = input('> ').strip()
            try:
                config = json.loads(config_text)
                self.mcp.add_server(config)
                self.tools.refresh_mcp_tools(force=True)
                print(f"Added MCP server: {config['name']}")
            except Exception as e:
                print(f"Failed to add MCP server: {e}")
            return

        print("Usage: /mcp [list|add|enable|disable]")

    def _show_skills(self):
        self.skill_registry.discover()
        skills = self.skill_registry.list_skills()
        if not skills:
            print("\nNo skills installed.")
            return
        print("\nInstalled skills:")
        for skill in skills:
            print(f"  - {skill['name']}: {skill['description']}")

    def _display_response(self, response: str):
        parts = response.split('```')
        for i, part in enumerate(parts):
            if i % 2 == 0:
                if part.strip():
                    self.console.print("\n[bold blue]AI:[/bold blue]")
                    self.console.print(Markdown(part.strip()))
            else:
                lines = part.split('\n')
                lang = lines[0].strip() if lines else ''
                code = '\n'.join(lines[1:]) if lines else part
                if code.strip():
                    syntax = Syntax(code, lang or 'text', theme='monokai', line_numbers=True)
                    self.console.print(syntax)

    def _show_tool_usage(self, tools_used: list, iterations: int):
        table = Table(title=f"Tools ({len(tools_used)} calls, {iterations} iterations)", box=box.ROUNDED)
        table.add_column('Tool', style='cyan')
        table.add_column('Status', style='green')
        table.add_column('Result', style='white')
        for tool in tools_used:
            status = 'OK' if tool['success'] else 'FAIL'
            result = tool['output'][:60] + '...' if len(tool['output']) > 60 else tool['output']
            table.add_row(tool['tool'], status, result)
        self.console.print(table)

    def _render_tool_output(self, title: str, result, border_style: str):
        if result.success:
            if self.console:
                self.console.print(Panel(result.output, title=title, border_style=border_style))
            else:
                print(f"\n{result.output}")
        else:
            print(f"Error: {result.error}")


def main():
    if len(sys.argv) < 2:
        print("Usage: codrninja-tui <session-name>")
        sys.exit(1)

    session_name = sys.argv[1]
    ai = AICode()
    tui = TUI(ai, session_name)
    tui.start()


if __name__ == "__main__":
    main()
