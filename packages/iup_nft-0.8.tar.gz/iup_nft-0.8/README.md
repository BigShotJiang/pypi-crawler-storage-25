# Enablement

## 1. dns

pkg:

```shell
chinadns-ng
dnsmasq-full
https-dns-proxy
luci-app-chinadns-ng
luci-app-https-dns-proxy
```

config:

`/etc/config/dhcp`

```shell
config dnsmasq
        option authoritative '1'
        option local '/lan/'
        option localservice '0'
        option rebind_protection '1'
        list confdir '/etc/dnsmasq.d'
        option domain 'openwrt.lan'
        option domainneeded '1'
        option cachesize '10000'
        list server '127.0.0.1#5353'
```

## 2. IPV6

refers to:

https://openwrt.org/docs/guide-user/network/ipv6/configuration

`/etc/config/dhcp`

```
config dhcp 'lan'
        option interface 'lan'
        option start '100'
        option limit '150'
        option leasetime '12h'
        option dhcpv4 'server'
        option dhcpv6 'relay'
        option ra 'relay'
        option ndp 'relay'

config dhcp 'USB0'
        option interface 'USB0'
        option ra 'hybrid'
        option dhcpv6 'hybrid'
        list ra_flags 'managed-config'
        list ra_flags 'other-config'

config dhcp 'USB0_V6'
        option interface 'USB0_V6'
        option ra 'relay'
        option dhcpv6 'relay'
        option master '1'
        option ndp 'relay'
```

`/etc/config/network`

````shell
config interface 'loopback'
        option device 'lo'
        option proto 'static'
        option ipaddr '127.0.0.1'
        option netmask '255.0.0.0'

config globals 'globals'
        option ula_prefix 'fdca:b666:b49f::/48'
        option packet_steering '1'

config device
        option name 'br-lan'
        option type 'bridge'
        list ports 'eth0'
        option ipv6 '1'

config interface 'lan'
        option device 'br-lan'
        option proto 'static'
        option ipaddr '192.168.1.1'
        option netmask '255.255.255.0'
        list dns '127.0.0.1'
        list dns_search 'openwrt.lan'
        option delegate '0'
        option ip6assign '64'

config interface 'USB0'
        option proto 'dhcp'
        option device 'usb0'
        option ip6assign '64'

config interface 'USB0_V6'
        option proto 'dhcpv6'
        option device 'usb0'
        option reqaddress 'try'
        option reqprefix 'auto'

config device
        option name 'usb0'
        option ipv6 '1'

config device
        option name 'eth0'
        option ipv6 '1'
````

## 3. SS

refers to:

https://openwrt.org/docs/guide-user/services/proxy/shadowsocks

https://github.com/openwrt/packages/blob/openwrt-23.05/net/shadowsocks-libev/README.md

PKG

```shell
luci-app-shadowsocks-libev
shadowsocks-libev-config
shadowsocks-libev-ss-local
shadowsocks-libev-ss-redir
shadowsocks-libev-ss-rules
shadowsocks-libev-ss-server
shadowsocks-libev-ss-tunnel
```

`/etc/config/shadowsocks-libev`

```shell
config ss_local
        option server 'sss0'
        option local_address '0.0.0.0'
        option local_port '1080'
        option timeout '30'
        option mode 'tcp_and_udp'
        option no_delay '1'
        option reuse_port '1'

config ss_tunnel
        option server 'sss0'
        option local_address '0.0.0.0'
        option local_port '8053'
        option tunnel_address '8.8.8.8:53'
        option mode 'tcp_only'
        option timeout '60'
        option reuse_port '1'
        option mtu '1492'
        option verbose '1'
        option no_delay '1'
        option disabled '1'

config ss_redir 'hi'
        option server 'sss0'
        option local_address '0.0.0.0'
        option local_port '1100'
        option mode 'tcp_and_udp'
        option timeout '60'
        option verbose '1'
        option reuse_port '1'
        option no_delay '1'
        option disabled '0'

config ss_redir 'hj'
        option server 'sss0'
        option local_address '::'
        option local_port '1100'
        option mode 'tcp_and_udp'
        option timeout '60'
        option verbose '1'
        option reuse_port '1'
        option no_delay '1'
        option disabled '0'

config ss_rules 'ss_rules'
        option src_default 'checkdst'
        option dst_default 'bypass'
        option local_default 'bypass'
        list ifnames 'br-lan'
        list ifnames 'eth0'
        option redir_tcp 'hi'
        option redir_udp 'hi'
        option nft_tcp_extra 'tcp dport { 80, 443, 8443}'
        option nft_udp_extra 'udp dport { 53 }'
        option dst_ips_forward_file '/etc/shadowsocks-libev/gfw_ips.txt'

config server 'sss0'
        option server '?????'
        option server_port '443'
        option password '?????'
        option method 'chacha20-ietf-poly1305'
        option plugin 'v2ray-plugin'
        option plugin_opts 'tls;host=????????;path=/?;fast-open;mux=0'
```

