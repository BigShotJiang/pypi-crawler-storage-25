#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse
import ipaddress
from os import path
import re

import paramiko
from paramiko.ssh_exception import AuthenticationException, NoValidConnectionsError, SSHException

import iup
from iup.config import Config


HOSTNAME_PATTERN = r'^([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$'
CFG_FILE = 'config.ini'
CMD_DNSMASQ = '/etc/init.d/dnsmasq restart'
CMD_CHNDNS = '/etc/init.d/chinadns-ng restart'

MODE_UPDATE = 'update'
MODE_DELETE = 'delete'

MODE_CONFIG = {
    MODE_UPDATE: {
        'cmd_template': 'iup {}',
        'magic_dns': 'update rule to',
        'magic_cdns': 'update blk',
        'description': '参数说明',
        'action_text': 'update',
        'empty_text': '没有读取到有效域名，请检查！！！',
        'config_prompt_refresh': True,
    },
    MODE_DELETE: {
        'cmd_template': 'iupd {}',
        'magic_dns': 'del dnsmasq rule',
        'magic_cdns': 'del chinadns rule',
        'description': 'iupd参数说明',
        'action_text': 'delete',
        'empty_text': '没有读取到有效域名，请检查！！！',
        'config_prompt_refresh': False,
    },
}


def is_domain_name(string: str):
    if re.match(HOSTNAME_PATTERN, string):
        return True
    else:
        return False


def is_ip_address(ip_str: str):
    try:
        ip = ipaddress.ip_address(ip_str)
        return ip is not None
    except ValueError:
        return False


def parse_host_name(hostname_str: str):
    if is_domain_name(hostname_str):
        return hostname_str
    return None


def parse_ssh_host(hostname_str: str):
    if is_domain_name(hostname_str) or is_ip_address(hostname_str):
        return hostname_str
    return None


def parse_port(port: str):
    if port.isdigit():
        port_num = int(port)
        if port_num > 1 and port_num < 65535:
            return port
    return None


def parse_yes_or_no(msg: str):
    msg = msg.upper()
    if msg in ['Y', 'YES', 'T', 'TRUE']:
        return True
    if msg in ['N', 'NO', 'F', 'FALSE']:
        return False
    return None


def read_hostname_from_file(file_path: str):
    hostnames = []
    with open(file_path, 'r') as f:
        for line in f:
            host_name_str = line.strip()
            parsed = parse_host_name(host_name_str)
            if parsed:
                hostnames.append(parsed)
    hostnames = list(dict.fromkeys(hostnames))
    return hostnames


def load_and_overlay_config(mode: str):
    mode_config = MODE_CONFIG[mode]
    parser = argparse.ArgumentParser(description=mode_config['description'])
    parser.add_argument("sources", nargs='+', help='域名或者域名文件路径')
    parser.add_argument("-nr", "--no_refresh", action='store_true', default=False, help="是否刷新")
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s version {iup.__version__} installed in {path.dirname(__file__)}",
    )
    args = parser.parse_args()
    config_path = path.join(path.dirname(__file__), CFG_FILE)
    if not path.exists(config_path):
        gen_config(mode)
    print('当前配置文件路径为:', config_path)
    config = Config(config_path)
    if args.no_refresh:
        config.refresh = False
    print('是否重启相关服务:', config.refresh)
    return args.sources, config


def format_ssh_error(config: Config, err: Exception):
    target = f'{config.host}:{config.port}'
    if isinstance(err, AuthenticationException):
        return f'SSH 认证失败，请检查用户名或密码: {target}'
    if isinstance(err, NoValidConnectionsError):
        return f'SSH 连接失败，目标主机不可达或端口未开放: {target}'
    if isinstance(err, TimeoutError):
        return f'SSH 连接超时，请检查目标主机和网络: {target}'
    if isinstance(err, SSHException):
        return f'SSH 通信异常: {target}，{err}'
    if isinstance(err, OSError):
        return f'SSH 网络异常: {target}，{err}'
    return f'SSH 操作失败: {target}，{err}'


def update_rule_by_ssh(hostnames: list, config: Config, mode: str):
    mode_config = MODE_CONFIG[mode]
    need_restart_dns = False
    need_restart_cdns = False
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        ssh.connect(config.host, port=config.port, username=config.username, password=config.password)
        for hostname in hostnames:
            cmd = mode_config['cmd_template'].format(hostname)
            _, stdout, stderr = ssh.exec_command(cmd)
            msg = stdout.readlines()
            err = stderr.readlines()
            if mode_config['magic_dns'] in str(msg):
                need_restart_dns = True
            if mode_config['magic_cdns'] in str(msg):
                need_restart_cdns = True
            print('msg', msg) if msg else print()
            print('err', err) if err else print()
        if config.refresh:
            if need_restart_cdns:
                print('reboot chinadns')
                _, stdout, stderr = ssh.exec_command(CMD_CHNDNS)
                msg = stdout.readlines()
                err = stderr.readlines()
                print('msg', msg) if msg else print()
                print('err', err) if err else print()
            if need_restart_dns:
                print('reboot dnsmasq')
                _, stdout, stderr = ssh.exec_command(CMD_DNSMASQ)
                msg = stdout.readlines()
                err = stderr.readlines()
                print('msg', msg) if msg else print()
                print('err', err) if err else print()
        return True
    except Exception as err:
        print(format_ssh_error(config, err))
        return False
    finally:
        ssh.close()


def gen_hostnames_by_sources(sources):
    hostnames = []
    for source in sources:
        if not path.exists(source):
            parsed = parse_host_name(source)
            if parsed:
                hostnames.append(parsed)
        elif path.isfile(source):
            hostnames += read_hostname_from_file(source)
    return list(dict.fromkeys(hostnames))


def run(mode: str):
    mode_config = MODE_CONFIG[mode]
    sources, config = load_and_overlay_config(mode)
    print('sources:', sources)
    hostnames = gen_hostnames_by_sources(sources)
    if hostnames:
        print(f"hostnames to {mode_config['action_text']}:", hostnames)
        update_rule_by_ssh(hostnames, config, mode)
    else:
        print(mode_config['empty_text'])


def main():
    run(MODE_UPDATE)


def main_delete():
    run(MODE_DELETE)


def read_info_from_input(prompt, parser=None):
    while True:
        info = input(prompt)
        if parser:
            info = parser(info)
            if not info is None:
                break
            else:
                print('输入有误，请重新输入！')
                continue
        break
    return info


def gen_config(mode: str = MODE_UPDATE):
    print('配置向导，请按提示输入信息...')
    host = read_info_from_input('请输入有效主机名或 IP:\n', parse_ssh_host)
    port = int(read_info_from_input('请输入有效端口:\n', parse_port))
    username = read_info_from_input('请输入openwrt用户名:\n')
    password = read_info_from_input('请输入openwrt密码:\n')
    config = Config()
    if MODE_CONFIG[mode]['config_prompt_refresh']:
        refresh = read_info_from_input(
            '是否重启相关服务(dnsmasq、chinadns),Y(es)/N(o)/T(rue)/F(alse):\n',
            parse_yes_or_no
        )
        config.update(host, port, username, password, refresh)
    else:
        config.update(host, port, username, password, config.refresh)
    config_path = path.join(path.dirname(__file__), CFG_FILE)
    config.save_to(config_path)
    print('已生成配置文件写入到{}'.format(config_path))


if __name__ == '__main__':
    gen_config()
