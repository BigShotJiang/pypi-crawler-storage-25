#!/usr/bin/env python3

from setuptools import setup, find_packages


# with open("README_en.md", "r", encoding="utf-8") as f:
#     readme = f.read()

setup(
    name='iup-nft',
    version='0.8',
    description='nftset updater for openwrt',
    # long_description=readme,
    author="nobitaqaq",
    author_email="xiaoleigs@gmail.com",
    keywords=["ipset", "openwrt"],
    packages=find_packages(include=['iup']),
    entry_points={
        'console_scripts': [
            'iup = iup.main:main',
            'iup-cfg = iup.main:gen_config',
            'iupd = iup.main:main_delete'
        ]
    },
    python_requires=">=3.8",
    install_requires=[
        'paramiko',
    ],
)
