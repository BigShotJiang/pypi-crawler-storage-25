from __future__ import annotations

import importlib
import importlib.metadata
from pathlib import Path
import re

import elements_mcp


def project_name() -> str:
    pyproject = Path("pyproject.toml").read_text(encoding="utf-8")
    match = re.search(r'(?m)^name\s*=\s*"([^"]+)"', pyproject)
    assert match is not None
    return match.group(1)


def test_package_version_uses_installed_distribution_metadata(monkeypatch) -> None:
    def fake_version(distribution_name: str) -> str:
        if distribution_name == project_name():
            return "9.9.9"
        raise importlib.metadata.PackageNotFoundError(distribution_name)

    monkeypatch.setattr(importlib.metadata, "version", fake_version)

    reloaded_package = importlib.reload(elements_mcp)

    assert reloaded_package.__version__ == "9.9.9"


def test_package_version_falls_back_when_distribution_metadata_is_unavailable(monkeypatch) -> None:
    def missing_version(distribution_name: str) -> str:
        raise importlib.metadata.PackageNotFoundError(distribution_name)

    monkeypatch.setattr(importlib.metadata, "version", missing_version)

    reloaded_package = importlib.reload(elements_mcp)

    assert reloaded_package.__version__ == "0.0.0"


def test_manifest_only_includes_runtime_content_and_readmes() -> None:
    manifest = Path("MANIFEST.in").read_text(encoding="utf-8").splitlines()

    assert "include README.zh-CN.md" in manifest
    assert "recursive-include src/elements_mcp/resources/content *" in manifest
    assert "recursive-include src/elements_mcp/prompts/content *" in manifest
    assert "prune docs" in manifest
    assert "recursive-include docs *.md" not in manifest


def test_packaged_skill_content_does_not_contain_known_cross_dc_upload_typo() -> None:
    content_root = Path("src/elements_mcp/resources/content")

    for content_file in content_root.rglob("*"):
        if content_file.is_file():
            assert "crossDCUploadRequestRequest" not in content_file.read_text(encoding="utf-8")
