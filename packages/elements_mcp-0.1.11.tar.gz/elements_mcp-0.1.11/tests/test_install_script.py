from pathlib import Path


def test_python_install_helper_installs_latest_package_to_fixed_directory() -> None:
    script = Path("scripts/install_elements_mcp.py").read_text(encoding="utf-8")

    assert "def get_install_dir() -> Path:" in script
    assert 'return Path(os.environ.get("SystemDrive", "C:") + r"\\Tools\\elements-mcp")' in script
    assert 'return Path.home() / "Tools" / "elements-mcp"' in script
    assert "install_dir = get_install_dir()" in script
    assert 'venv_dir = install_dir / ".venv"' in script
    assert 'return venv_dir / "Scripts" / "python.exe"' in script
    assert 'return venv_dir / "bin" / "python"' in script
    assert 'shutil.which("uv")' in script
    assert '"venv", "--python", sys.executable, str(venv_dir)' in script
    assert '"pip", "install", "--python", str(venv_python), "--upgrade", "elements-mcp"' in script
    assert '"pip", "show", "--python", str(venv_python), "elements-mcp"' in script
    assert "This installer does not accept arguments." in script
    assert "--install-dir" not in script
    assert "--package-name" not in script
    assert "--version" not in script

def test_user_guide_documents_pypi_install_options() -> None:
    guide = Path("docs/install-elements-mcp-user-guide-zh.md").read_text(encoding="utf-8")

    assert "https://github.com/astral-sh/uv/releases/download/0.11.15/uv-x86_64-pc-windows-msvc.zip" in guide
    assert "在系统环境变量 `Path` 中加入包含 `uv.exe` 的父层 folder" in guide
    assert "`uvx` 是 `uv tool run` 的简写" in guide
    assert '"command": "uvx"' in guide
    assert '"args": ["elements-mcp"]' in guide
    assert "Command: uvx elements-mcp" in guide
    assert "uvx elements-mcp" in guide
    assert "uv tool install elements-mcp" not in guide
    assert "uv tool upgrade elements-mcp" not in guide
    assert "Windows：`C:\\Tools\\elements-mcp`" in guide
    assert "macOS/Linux：`~/Tools/elements-mcp`" in guide
    assert "uv venv C:\\Tools\\elements-mcp\\.venv" in guide
    assert "uv pip install --python C:\\Tools\\elements-mcp\\.venv\\Scripts\\python.exe --upgrade elements-mcp" in guide
    assert "uv venv ~/Tools/elements-mcp/.venv" in guide
    assert "uv pip install --python ~/Tools/elements-mcp/.venv/bin/python --upgrade elements-mcp" in guide
    assert "python scripts\\install_elements_mcp.py" in guide
    assert "python scripts/install_elements_mcp.py" in guide
    assert "--install-dir" not in guide
    assert ".\\scripts\\install-elements-mcp.ps1" not in guide


def test_maintainer_guide_uses_project_venv_for_development_and_release() -> None:
    guide = Path("README.zh-CN.md").read_text(encoding="utf-8")

    assert "开发者只使用 `uv` 和项目根目录的 `.venv`" in guide
    assert "uv venv .venv" in guide
    assert 'uv pip install --python .\\.venv\\Scripts\\python.exe -e ".[dev]"' in guide
    assert ".\\.venv\\Scripts\\python.exe -m pytest" in guide
    assert "scripts\\publish-pypi.ps1` 会通过 `uv` 创建或更新这个环境" in guide
    assert ".\\.venv\\Scripts\\python.exe" in guide
    assert "python -m pip install --user --upgrade elements-mcp" not in guide


def test_english_readme_summarizes_install_and_release_paths() -> None:
    readme = Path("README.md").read_text(encoding="utf-8")

    assert "# elements-mcp Project Guide" in readme
    assert "This document is for maintainers." in readme
    assert "English version of this maintainer guide." in readme
    assert "fixed `Tools\\elements-mcp` directory" in readme
    assert "Maintainers should use `uv` and the project-root `.venv`" in readme
    assert ".\\scripts\\publish-pypi.ps1" in readme
