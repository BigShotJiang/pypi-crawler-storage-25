from pathlib import Path

import pytest

from elements_mcp.resources.registry import SkillNotFoundError, SkillRegistry


def test_packaged_registry_lists_skills_without_scopes() -> None:
    registry = SkillRegistry()

    assert "ui-standard-layout" in [skill.name for skill in registry.list_skills()]
    assert registry.root.as_posix().endswith("elements_mcp/resources/content/skills")


def write_skill(root: Path, name: str, body: str = "# Example Skill\n") -> Path:
    skill_dir = root / name
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text(body, encoding="utf-8")
    return skill_dir


def test_registry_lists_skills_and_templates(tmp_path: Path) -> None:
    skill_dir = write_skill(
        tmp_path,
        "ui-standard-layout",
        "---\n"
        "description: UIStandardLayout rules\n"
        "metadata:\n"
        "  keywords:\n"
        "    - UIStandardLayout\n"
        "    - 标准布局\n"
        "---\n"
        "# UI Standard Layout\n",
    )
    templates_dir = skill_dir / "templates"
    templates_dir.mkdir()
    (templates_dir / "page-shell.template.mdx").write_text("# Page Shell\n", encoding="utf-8")

    registry = SkillRegistry(tmp_path)

    skill = registry.list_skills()[0]
    assert skill.name == "ui-standard-layout"
    assert skill.summary == "UIStandardLayout rules"
    assert skill.keywords == ("UIStandardLayout", "标准布局")
    assert registry.read_skill("ui-standard-layout").startswith("---")
    assert registry.list_templates("ui-standard-layout") == ["page-shell.template.mdx"]
    assert registry.read_template("ui-standard-layout", "page-shell.template.mdx") == "# Page Shell\n"


def test_registry_searches_skill_name_summary_and_body(tmp_path: Path) -> None:
    write_skill(
        tmp_path,
        "api-integration",
        "---\n"
        "description: REST API integration guidance\n"
        "metadata:\n"
        "  keywords:\n"
        "    - 跨 DC\n"
        "---\n"
        "# API Integration\n"
        "Use crossDCRequest when required.\n",
    )
    registry = SkillRegistry(tmp_path)

    assert [skill.name for skill in registry.search("crossDCRequest")] == ["api-integration"]
    assert [skill.name for skill in registry.search("REST API")] == ["api-integration"]
    assert [skill.name for skill in registry.search("跨 DC")] == ["api-integration"]


def test_registry_rejects_path_traversal_segments(tmp_path: Path) -> None:
    write_skill(tmp_path, "safe-skill")
    registry = SkillRegistry(tmp_path)

    with pytest.raises(SkillNotFoundError):
        registry.read_skill("../safe-skill")

    with pytest.raises(SkillNotFoundError):
        registry.read_template("safe-skill", "../secret.template.mdx")


def test_registry_raises_for_missing_skill(tmp_path: Path) -> None:
    registry = SkillRegistry(tmp_path)

    with pytest.raises(SkillNotFoundError):
        registry.read_skill("missing")
