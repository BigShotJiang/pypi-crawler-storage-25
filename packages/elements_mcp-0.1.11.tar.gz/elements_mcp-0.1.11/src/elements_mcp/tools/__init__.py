from __future__ import annotations

from typing import Any

from elements_mcp.resources.registry import SkillRegistry

from .project_guidance import register_project_guidance_tool
from .skill_catalog import register_skill_catalog_tools


def register_tools(mcp: Any, registry: SkillRegistry) -> None:
    register_project_guidance_tool(mcp, registry)
    register_skill_catalog_tools(mcp, registry)
