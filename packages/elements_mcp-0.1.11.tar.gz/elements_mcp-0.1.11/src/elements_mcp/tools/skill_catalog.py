from __future__ import annotations

from typing import Any

from elements_mcp.resources.registry import SkillRegistry

from .common import READ_ONLY_TOOL_ANNOTATIONS, SKILL_LIST_OUTPUT_SCHEMA, SkillEntryResult, skill_entry_result


def register_skill_catalog_tools(mcp: Any, registry: SkillRegistry) -> None:
    @mcp.tool(annotations=READ_ONLY_TOOL_ANNOTATIONS, output_schema=SKILL_LIST_OUTPUT_SCHEMA)
    def list_project_skills() -> list[SkillEntryResult]:
        """List available skills."""
        return [skill_entry_result(skill) for skill in registry.list_skills()]

    @mcp.tool(annotations=READ_ONLY_TOOL_ANNOTATIONS)
    def read_project_skill(skill_name: str) -> str:
        """Read a SKILL.md file by skill name."""
        return registry.read_skill(skill_name)

    @mcp.tool(annotations=READ_ONLY_TOOL_ANNOTATIONS, output_schema=SKILL_LIST_OUTPUT_SCHEMA)
    def search_project_skills(query: str) -> list[SkillEntryResult]:
        """Search skills by name, summary, and body text."""
        return [skill_entry_result(skill) for skill in registry.search(query)]

    @mcp.tool(annotations=READ_ONLY_TOOL_ANNOTATIONS)
    def list_skill_templates(skill_name: str) -> list[str]:
        """List templates for a skill."""
        return registry.list_templates(skill_name)

    @mcp.tool(annotations=READ_ONLY_TOOL_ANNOTATIONS)
    def read_skill_template(skill_name: str, template_name: str) -> str:
        """Read a named template from a skill's templates directory."""
        return registry.read_template(skill_name, template_name)
