from __future__ import annotations

import re
from typing import Any

from elements_mcp.resources.registry import SkillEntry, SkillRegistry

from .common import (
    PROJECT_GUIDANCE_OUTPUT_SCHEMA,
    READ_ONLY_TOOL_ANNOTATIONS,
    ProjectGuidanceResult,
    skill_entry_result,
)


_NO_GUIDANCE_MESSAGE = (
    "No Elements project skill matched this task. Continue with normal coding behavior. "
    "Do not invent project-specific rules."
)

_TOKEN_PATTERN = re.compile(r"[A-Za-z0-9]+|[\u4e00-\u9fff]+")
_GUIDANCE_STOP_WORDS = {
    "add",
    "and",
    "build",
    "create",
    "creating",
    "for",
    "from",
    "help",
    "make",
    "new",
    "please",
    "that",
    "the",
    "this",
    "use",
    "with",
}
_EXACT_MATCH_BOOST = 30
_MINIMUM_SCORE_FLOOR = 4
_MINIMUM_SCORE_CEILING = 20
_BODY_ONLY_MINIMUM_SCORE = 8


def register_project_guidance_tool(mcp: Any, registry: SkillRegistry) -> None:
    @mcp.tool(annotations=READ_ONLY_TOOL_ANNOTATIONS, output_schema=PROJECT_GUIDANCE_OUTPUT_SCHEMA)
    def get_project_guidance(task: str, max_skills: int = 3) -> ProjectGuidanceResult:
        """Get relevant Elements project skills and templates for a natural-language task."""
        matching_skills = _find_guidance_skills(registry, task, max_skills)
        if not matching_skills:
            return {
                "matched": False,
                "query": task,
                "skills": [],
                "guidance": _NO_GUIDANCE_MESSAGE,
            }

        return {
            "matched": True,
            "query": task,
            "skills": [skill_entry_result(skill) for skill in matching_skills],
            "guidance": _format_project_guidance(registry, task, matching_skills),
        }


def _find_guidance_skills(
    registry: SkillRegistry,
    task: str,
    max_skills: int,
) -> list[SkillEntry]:
    limit = max(1, min(max_skills, 5))
    exact_matches = {skill.name for skill in registry.search(task)}
    scored_skills: list[tuple[int, SkillEntry]] = []

    for skill in registry.list_skills():
        score = _score_skill_for_task(registry, skill, task)
        if skill.name in exact_matches:
            score += _EXACT_MATCH_BOOST
        if score > 0:
            scored_skills.append((score, skill))

    scored_skills.sort(key=lambda scored: (-scored[0], scored[1].name))
    if not scored_skills:
        return []

    minimum_score = min(
        _MINIMUM_SCORE_CEILING,
        max(_MINIMUM_SCORE_FLOOR, scored_skills[0][0] // 2),
    )
    strong_matches = [skill for score, skill in scored_skills if score >= minimum_score]
    return strong_matches[:limit]


def _score_skill_for_task(registry: SkillRegistry, skill: SkillEntry, task: str) -> int:
    tokens = _task_tokens(task)
    normalized_task = _normalize_guidance_text(task)

    body = registry.read_skill(skill.name).lower()
    name_text = _normalize_guidance_text(skill.name)
    summary_text = _normalize_guidance_text(skill.summary)
    searchable_text = _normalize_guidance_text("\n".join([skill.name, skill.summary, body]))

    score = 0
    token_hits = 0
    metadata_hits = 0

    if name_text and name_text in normalized_task:
        score += 40
        metadata_hits += 1

    for keyword in skill.keywords:
        keyword_text = _normalize_guidance_text(keyword)
        if not keyword_text:
            continue
        if keyword_text in normalized_task:
            score += 20
            metadata_hits += 1
            continue
        for keyword_token in _task_tokens(keyword):
            if keyword_token in tokens:
                score += 12
                metadata_hits += 1

    for token in tokens:
        hit = False
        if token in name_text:
            score += 10
            hit = True
            metadata_hits += 1
        if token in summary_text:
            score += 5
            hit = True
            metadata_hits += 1
        if token in body:
            score += 1
            hit = True
        if hit:
            token_hits += 1

    if token_hits == 0 and metadata_hits == 0:
        return 0

    phrase = " ".join(tokens)
    if len(tokens) >= 2 and phrase in searchable_text:
        score += 10
    if metadata_hits == 0 and score < _BODY_ONLY_MINIMUM_SCORE:
        return 0
    if score < 4:
        return 0
    return score


def _task_tokens(task: str) -> list[str]:
    return [
        token
        for token in _TOKEN_PATTERN.findall(task.lower())
        if len(token) >= 3 and token not in _GUIDANCE_STOP_WORDS
    ]


def _normalize_guidance_text(value: str) -> str:
    return " ".join(_TOKEN_PATTERN.findall(value.lower()))


def _format_project_guidance(registry: SkillRegistry, task: str, skills: list[SkillEntry]) -> str:
    sections = [
        "Elements project guidance matched this task.",
        f"Task: {task}",
        "",
        "Matched skills:",
    ]
    for skill in skills:
        summary = f": {skill.summary}" if skill.summary else ""
        sections.append(f"- {skill.name}{summary}")

    for skill in skills:
        skill_body = registry.read_skill(skill.name)
        sections.extend(
            [
                "",
                f"## Skill: {skill.name}/SKILL.md",
                skill_body,
            ]
        )
        for template_name in _guidance_template_names(skill, skill_body):
            sections.extend(
                [
                    "",
                    f"## Template: {skill.name}/templates/{template_name}",
                    registry.read_template(skill.name, template_name),
                ]
            )

    return "\n".join(sections)


def _guidance_template_names(skill: SkillEntry, body: str) -> list[str]:
    if (
        "request-input.template.yaml" in skill.templates
        and "request-input.template.yaml" in body
        and ("mandatory" in body.lower() or "hard gate" in body.lower())
    ):
        return ["request-input.template.yaml"]
    return []
