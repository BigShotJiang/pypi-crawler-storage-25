from __future__ import annotations

from typing import Any, TypedDict

from elements_mcp.resources.registry import SkillEntry


class SkillEntryResult(TypedDict):
    name: str
    summary: str
    keywords: list[str]
    templates: list[str]
    uri: str


class ProjectGuidanceResult(TypedDict):
    matched: bool
    query: str
    skills: list[SkillEntryResult]
    guidance: str


READ_ONLY_TOOL_ANNOTATIONS = {
    "readOnlyHint": True,
    "destructiveHint": False,
    "idempotentHint": True,
    "openWorldHint": False,
}

SKILL_ENTRY_SCHEMA: dict[str, Any] = {
    "type": "object",
    "additionalProperties": False,
    "required": ["name", "summary", "keywords", "templates", "uri"],
    "properties": {
        "name": {"type": "string"},
        "summary": {"type": "string"},
        "keywords": {"type": "array", "items": {"type": "string"}},
        "templates": {"type": "array", "items": {"type": "string"}},
        "uri": {"type": "string"},
    },
}

SKILL_LIST_OUTPUT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "required": ["result"],
    "properties": {
        "result": {
            "type": "array",
            "items": SKILL_ENTRY_SCHEMA,
        }
    },
    "x-fastmcp-wrap-result": True,
}

PROJECT_GUIDANCE_OUTPUT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "required": ["result"],
    "properties": {
        "result": {
            "type": "object",
            "additionalProperties": False,
            "required": ["matched", "query", "skills", "guidance"],
            "properties": {
                "matched": {"type": "boolean"},
                "query": {"type": "string"},
                "skills": {
                    "type": "array",
                    "items": SKILL_ENTRY_SCHEMA,
                },
                "guidance": {"type": "string"},
            },
        }
    },
    "x-fastmcp-wrap-result": True,
}


def skill_entry_result(skill: SkillEntry) -> SkillEntryResult:
    return {
        "name": skill.name,
        "summary": skill.summary,
        "keywords": list(skill.keywords),
        "templates": list(skill.templates),
        "uri": skill.uri,
    }
