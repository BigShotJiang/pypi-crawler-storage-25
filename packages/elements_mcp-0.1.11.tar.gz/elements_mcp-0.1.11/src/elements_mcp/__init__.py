"""Elements MCP package."""

from importlib.metadata import PackageNotFoundError, version

__all__ = ["__version__"]

try:
    __version__ = version("elements-mcp")
except PackageNotFoundError:  # pragma: no cover - only used from an uninstalled source tree
    __version__ = "0.0.0"
