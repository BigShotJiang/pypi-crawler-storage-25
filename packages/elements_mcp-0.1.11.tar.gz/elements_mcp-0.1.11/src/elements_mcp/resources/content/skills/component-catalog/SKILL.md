---
name: component-catalog
description: "Comprehensive catalog of all custom UI/BI components organized by functionality with selection guides."
metadata:
  keywords:
    - component catalog
    - custom component
    - BI component
    - UI component
    - component selection
    - selection guide
    - reusable component
    - 组件目录
    - 自定义组件
    - 组件选择
    - 组件指南
---

# Partner Portal UI Component Catalog

This document provides a comprehensive catalog of all custom components in the Partner Portal UI project. Components are categorized by functionality to help AI agents quickly identify the appropriate component for specific use cases.

---

## 📋 Table of Contents

- [Tables & Data Grids](#tables--data-grids) - Table components and data grid functionality
- [Charts & Visualizations](#charts--visualizations) - Data visualization and chart components
- [Form Controls & Inputs](#form-controls--inputs) - Form fields, inputs, and validation
- [File & Upload](#file--upload) - File upload and browser components
- [Dialogs & Modals](#dialogs--modals) - Dialog boxes, modals, and panels
- [Notifications & Messages](#notifications--messages) - Toast, alerts, and message displays
- [Loading & Empty States](#loading--empty-states) - Loading indicators and empty state displays
- [Navigation & Layout](#navigation--layout) - Navigation and page layout components
- [Content Display](#content-display) - Content presentation and display components
- [Advanced Features](#advanced-features) - Filtering, rich editors, drag-drop, and specialized features
- [Business Domain](#business-domain) - Business-specific domain components
- [Component Selection Guide](#component-selection-guide) - Quick reference for choosing components

---

## Tables & Data Grids

### ui-table-column-filter ⭐ (Recommended)
**Path**: `src/components/ui-table-column-filter/`
**Purpose**: Advanced table component with sorting, global filtering, column filter, column management, and pagination built-in.
**Use When**: Need full-featured table with filtering, sorting, and column customization.

### ui-table
**Path**: `src/components/ui-table/`
**Purpose**: Advanced table component with sorting, filtering, column management, and pagination built-in.
**Use When**: Displaying complex tabular data with rich interaction features.
**Note**: ⚠️ Not recommended. Use `ui-table-column-filter` instead.

### ui-table-column
**Path**: `src/components/ui-table-column/`
**Purpose**: Reusable table column component.
**Use When**: Building custom table columns with consistent styling.

### ui-view
**Path**: `src/components/ui-view/`
**Purpose**: For table components, manages saved views with sorting, searching, and filtering configurations. Displays a list of all saved views for quick filtering.
**Use When**: Table has a view button after the Filter button for managing multiple filter presets.

### ui-export-table
**Path**: `src/components/ui-export-table/`
**Purpose**: Table export functionality to various formats.
**Use When**: Need to export table data to CSV, Excel, or other formats.

---

## Charts & Visualizations

### ui-echart-bar
**Path**: `src/components/ui-echart-bar/`
**Purpose**: Enhanced bar chart using ECharts library with advanced features.
**Use When**: Need advanced bar chart features like stacking, grouping, or animations.

### ui-echart-line
**Path**: `src/components/ui-echart-line/`
**Purpose**: Enhanced line chart using ECharts library.
**Use When**: Need advanced line chart features like multiple series or custom tooltips.

### ui-echart-pie
**Path**: `src/components/ui-echart-pie/`
**Purpose**: Enhanced pie chart using ECharts library.
**Use When**: Need advanced pie chart features like 3D effects or custom labels.

### ui-echart-graph
**Path**: `src/components/ui-echart-graph/`
**Purpose**: Graph/network visualization component using ECharts.
**Use When**: Displaying relationship graphs or network diagrams.

### ui-echart-mix
**Path**: `src/components/ui-echart-mix/`
**Purpose**: Mixed chart component combining multiple chart types.
**Use When**: Displaying data that requires different visualization types in one chart.


---

## Form Controls & Inputs

### Text Inputs

#### ui-searchbox
**Path**: `src/components/ui-searchbox/`
**Purpose**: Search input field with search functionality.
**Use When**: Need search capability for filtering lists or finding content.

#### ui-textfield
**Path**: `src/components/ui-textfield/`
**Purpose**: Enhanced text input field component.
**Use When**: Need text input with additional validation or formatting features.

#### ui-customize-textfield
**Path**: `src/components/ui-customize-textfield/`
**Purpose**: Customized text field with extended features.
**Use When**: Need text input with custom validation or formatting beyond standard textfield.

### Date & Time Pickers

#### ui-datepicker-allure
**Path**: `src/components/ui-datepicker-allure/`
**Purpose**: Date picker component based on Allure design system.
**Use When**: Need date input following Allure design guidelines.

#### ui-time-picker
**Path**: `src/components/ui-time-picker/`
**Purpose**: Time picker component for selecting time values.
**Use When**: Users need to select specific time points.

#### ui-monthpicker
**Path**: `src/components/ui-monthpicker/`
**Purpose**: Month picker component for selecting month/year.
**Use When**: Need month-level date selection (e.g., for monthly reports).

#### ui-calendar
**Path**: `src/components/ui-calendar/`
**Purpose**: Calendar component for date selection and display.
**Use When**: Need calendar view for date selection or event display.

### Dropdowns & Selectors

#### ui-dropdown
**Path**: `src/components/ui-dropdown/`
**Purpose**: Dropdown select component for single or multiple selection.
**Use When**: Need basic dropdown selection functionality.

#### ui-multi-dropdown
**Path**: `src/components/ui-multi-dropdown/`
**Purpose**: Multi-select dropdown component with checkboxes.
**Use When**: Users need to select multiple options from a dropdown list.

#### ui-combobox-scroll-api
**Path**: `src/components/ui-combobox-scroll-api/`
**Purpose**: ComboBox with API-driven scrolling and lazy loading.
**Use When**: Dropdown with large datasets that load on scroll.

#### ui-dynamic-combobox-with-tag
**Path**: `src/components/ui-dynamic-combobox-with-tag/`
**Purpose**: Dynamic combobox supporting tag input.
**Use When**: Users can select from options or add custom tags.

#### ui-search-choice-group
**Path**: `src/components/ui-search-choice-group/`
**Purpose**: Radio button group with search functionality.
**Use When**: Large number of radio options requiring search.

#### dropdownwithtree
**Path**: `src/components/dropdownwithtree/`
**Purpose**: Dropdown with tree structure for hierarchical selection.
**Use When**: Need hierarchical selection in dropdown format.

#### groupDropdown
**Path**: `src/components/groupDropdown/`
**Purpose**: Dropdown with searchable grouped options and multi-select support.
**Use When**: Selecting from categorized/grouped items (e.g., grouped service list).

#### colorComboBox
**Path**: `src/components/colorComboBox/`
**Purpose**: Dropdown color picker with callout palette and error handling.
**Use When**: Selecting colors in forms or settings with visual feedback.

#### zoomComboBox
**Path**: `src/components/zoomComboBox/`
**Purpose**: Zoom level selector dropdown with increment/decrement controls.
**Use When**: Providing zoom/scaling controls for content viewing.

### People Pickers

#### ui-people-picker-single
**Path**: `src/components/ui-people-picker-single/`
**Purpose**: Single user picker component.
**Use When**: Selecting one user for assignment or filtering.

#### ui-peoplepicker-multi
**Path**: `src/components/ui-peoplepicker-multi/`
**Purpose**: Multiple user picker component.
**Use When**: Selecting multiple users for group assignments.

#### ui-facepileGroup
**Path**: `src/components/ui-facepileGroup/`
**Purpose**: Component displaying multiple user avatars in a compact group.
**Use When**: Showing multiple assigned users or collaborators.

#### ui-picker
**Path**: `src/components/ui-picker/`
**Purpose**: People picker variants (`UICompactPeoplePicker`, `UIListPeoplePicker`) for selecting users from directory.
**Use When**: User selection in forms (compact for space-constrained, list for detailed view).

#### ui-persona-initials
**Path**: `src/components/ui-persona-initials/`
**Purpose**: User avatar component displaying initials with color-coded background.
**Use When**: Showing user avatars where profile images aren't available.

### Checkboxes & Choices

#### ui-color-checkbox
**Path**: `src/components/ui-color-checkbox/`
**Purpose**: Checkbox with color indicator.
**Use When**: Selecting items that have associated colors.

#### ui-dynamic-checkbox
**Path**: `src/components/ui-dynamic-checkbox/`
**Purpose**: Paginated, searchable checkbox list for dynamic data sources.
**Use When**: Selecting multiple items from large datasets with search/filter capability.

#### ui-dynamic-choice-group
**Path**: `src/components/ui-dynamic-choice-group/`
**Purpose**: Paginated, searchable radio button group for dynamic data sources.
**Use When**: Single-selection from dynamic data with pagination and search.

### Other Input Controls

#### ui-slider
**Path**: `src/components/ui-slider/`
**Purpose**: Slider component for selecting values from a range.
**Use When**: Users need to select numeric values within a specified range.

#### uiSpinButton
**Path**: `src/components/uiSpinButton/`
**Purpose**: Spin button for numeric increment/decrement.
**Use When**: Adjusting numeric values with buttons.

#### ui-color-picker
**Path**: `src/components/ui-color-picker/`
**Purpose**: Color picker component for color selection.
**Use When**: Users need to select colors.

## File & Upload

### ui-file-uploader
**Path**: `src/components/ui-file-uploader/`
**Purpose**: File upload component with drag-and-drop support.
**Use When**: Users need to upload files with drag-and-drop functionality.

### ui-upload-img
**Path**: `src/components/ui-upload-img/`
**Purpose**: Image upload component with preview.
**Use When**: Uploading and previewing images.

### ui-upload-single-file
**Path**: `src/components/ui-upload-single-file/`
**Purpose**: Single file upload component.
**Use When**: Uploading one file at a time with restrictions.

### ui-single-file-browser
**Path**: `src/components/ui-single-file-browser/`
**Purpose**: File browser for selecting single files.
**Use When**: Browsing and selecting files from a list.

---

## Dialogs & Modals

### dialogBox
**Path**: `src/components/dialogBox/`
**Purpose**: Generic dialog box component.
**Use When**: Custom dialog scenarios with flexible content.

### areyousure
**Path**: `src/components/areyousure/`
**Purpose**: Confirmation dialog with "Are you sure?" pattern.
**Use When**: Confirming destructive actions.

### disconnect-tenant-dialog
**Path**: `src/components/disconnect-tenant-dialog/`
**Purpose**: Dialog for disconnecting tenant connections.
**Use When**: Users disconnect tenants, confirming the action.

### disconnect-failed-dialog
**Path**: `src/components/disconnect-failed-dialog/`
**Purpose**: Dialog showing disconnect failure information.
**Use When**: Tenant disconnection fails and error details need to be shown.

### ui-panel
**Path**: `src/components/ui-panel/`
**Purpose**: Side panel component that slides in from screen edge.
**Use When**: Displaying details, forms, or secondary content without leaving the current page.

---

## Notifications & Messages

### ui-notification
**Path**: `src/components/ui-notification/`
**Purpose**: Toast notification system for displaying temporary messages.
**Use When**: Need to show success, error, warning, or info messages to users.

### errorMessage
**Path**: `src/components/errorMessage/`
**Purpose**: Error message display component.
**Use When**: Showing error messages in a consistent format.

### out-of-policy-message-bar
**Path**: `src/components/out-of-policy-message-bar/`
**Purpose**: Message bar for out-of-policy notifications.
**Use When**: Alerting users about policy violations.

---

## Loading & Empty States

### ui-loading
**Path**: `src/components/ui-loading/`
**Purpose**: Loading indicator component with multiple display modes.
**Use When**: Need to show loading state during data fetching or processing.

### render-no-items-show
**Path**: `src/components/render-no-items-show/`
**Purpose**: Component for rendering empty state when no items exist.
**Use When**: Lists or grids have no items to display.

---

## Navigation & Layout

### Navigation

#### ui-breadcrumb-common
**Path**: `src/components/ui-breadcrumb-common/`
**Purpose**: Common breadcrumb navigation component showing the current page's position in the site hierarchy.
**Use When**: Need to help users understand their current location and navigate back to parent pages.

#### ui-pivot
**Path**: `src/components/ui-pivot/`
**Purpose**: Tab navigation component for switching between different views.
**Use When**: Need to organize content into separate tabbed sections.

#### ui-menu-tab
**Path**: `src/components/ui-menu-tab/`
**Purpose**: Tab interface with pivot items and dropdown overflow support.
**Use When**: Tabbed navigation with optional dropdown for overflow tabs.

### Layout

#### ui-standard-layout
**Path**: `src/components/ui-standard-layout/`
**Purpose**: Standard page layout component with header, sidebar, and content areas.
**Use When**: Creating pages with consistent layout structure.

---

## Content Display

### ui-carousel
**Path**: `src/components/ui-carousel/`
**Purpose**: Image/content carousel component with auto-play and manual navigation.
**Use When**: Displaying multiple images or content items in a rotating carousel.

### ui-collapse
**Path**: `src/components/ui-collapse/`
**Purpose**: Collapsible panel component for showing/hiding content sections.
**Use When**: Need to save space by allowing users to expand/collapse content sections.

### ui-tags
**Path**: `src/components/ui-tags/`
**Purpose**: Tag display component for showing multiple tags.
**Use When**: Displaying categories, labels, or keywords.

### ui-tag-custom
**Path**: `src/components/ui-tag-custom/`
**Purpose**: Customizable tag component with various styles.
**Use When**: Need custom styled tags beyond standard ui-tags.

### ui-tooltip
**Path**: `src/components/ui-tooltip/`
**Purpose**: Tooltip component for displaying additional information on hover.
**Use When**: Need to provide extra context or help text without cluttering the UI.

### ui-progress-bar
**Path**: `src/components/ui-progress-bar/`
**Purpose**: Progress bar showing task completion percentage.
**Use When**: Displaying upload progress, task completion, or step progress.

### topbarStatus
**Path**: `src/components/topbarStatus/`
**Purpose**: Status indicator in top bar.
**Use When**: Showing system or connection status in header.

### summaryCard
**Path**: `src/components/summaryCard/`
**Purpose**: Clickable card container with triangle decoration and navigation support.
**Use When**: Creating dashboard-style grid layouts with navigable cards.

### ui-image-carousel
**Path**: `src/components/ui-image-carousel/`
**Purpose**: Image carousel/slideshow with prev/next navigation.
**Use When**: Displaying multiple images with manual navigation controls.

### ui-summary
**Path**: `src/components/ui-summary/`
**Purpose**: Definition list component (`UISummary`, `UISummaryDT`, `UISummaryDD`) for key-value pair display with shimmer support.
**Use When**: Data summaries (specifications, details) in columnar layout.

---

## Advanced Features

### Filtering & Search

#### ui-new-filter
**Path**: `src/components/ui-new-filter/`
**Purpose**: Advanced filter component with multiple criteria support.
**Use When**: Need complex filtering capabilities with various filter types.

### Rich Text Editor

#### ui-rich-editor-action
**Path**: `src/components/ui-rich-editor-action/`
**Purpose**: Rich text editor action buttons.
**Use When**: Adding custom actions to rich text editor.

#### ui-rich-editor-toolbar
**Path**: `src/components/ui-rich-editor-toolbar/`
**Purpose**: Toolbar for rich text editor.
**Use When**: Need rich text editing toolbar with formatting options.

### Other Advanced Components

#### react-flow
**Path**: `src/components/react-flow/`
**Purpose**: React Flow integration for workflow diagrams.
**Use When**: Building interactive workflow diagrams.

#### ui-google-map
**Path**: `src/components/ui-google-map/`
**Purpose**: Google Maps integration component.
**Use When**: Displaying locations on Google Maps.

#### ui-sample-data
**Path**: `src/components/ui-sample-data/`
**Purpose**: Sample data display component.
**Use When**: Showing example or sample data.

### View Controls

#### ui-select-reference
**Path**: `src/components/ui-select-reference/`
**Purpose**: Rich text editor with reference/placeholder insertion buttons.
**Use When**: Email templates or content where variable placeholders need insertion.

---

## Business Domain

### new-connect-tenant
**Path**: `src/components/new-connect-tenant/`
**Purpose**: Component for connecting new tenant accounts.
**Use When**: Onboarding new tenants.

### common-customer-tenant
**Path**: `src/components/common-customer-tenant/`
**Purpose**: Common component for customer-tenant relationships.
**Use When**: Displaying customer-tenant information.

### audit-log-component
**Path**: `src/components/audit-log-component/`
**Purpose**: Audit log display component.
**Use When**: Showing audit trail and activity logs.

---

## Component Selection Guide

### For Tables
- **✅ Recommended**: `ui-table-column-filter` - Full-featured with sorting, global filter, column filters, and view management
- **Avoid**: `ui-table` - Use ui-table-column-filter instead
- **Avoid**: `ui-table-group` - Cannot support backend pagination

### For Charts
- **Bar Charts**: `ui-echart-bar`
- **Line Charts**: `ui-echart-line` (advanced) or `ui-chart-line` (basic)
- **Pie Charts**: `ui-echart-pie` (advanced) or `ui-chart-pie` (basic)
- **Multiple Chart Types**: `ui-echart-mix`
- **Network/Relationship Graphs**: `ui-echart-graph`

### For Dialogs & Modals
- **Custom Dialog (PRIMARY)**: `dialogBox` — use `DialogBox` + `DialogBoxTitle` + `DialogBoxContent` + `DialogBoxActions`

### For Forms
- **Form Wrapper**: `lvForm`
- **Field Wrapper**: `lvFormControl`, `ui-form-item-control`
- **Date Selection**: `ui-datepicker-allure`
- **Time Selection**: `ui-time-picker`
- **Month Selection**: `ui-monthpicker`
- **Calendar View**: `ui-calendar`
- **User Selection (Single)**: `ui-people-picker-single`
- **User Selection (Multiple)**: `ui-peoplepicker-multi` or `ui-list-people-picker`
- **User Avatar**: `ui-persona-initials` (initials), `ui-facepileGroup` (group)
- **Dropdown**: `ui-dropdown` (basic), `ui-multi-dropdown` (multi-select), `ui-combobox-scroll-api` (large datasets)
- **Grouped Dropdown**: `groupDropdown`
- **Hierarchical Selection**: `dropdownwithtree`
- **Color Selection**: `colorComboBox`, `ui-color-picker`
- **File Upload**: `ui-file-uploader` (general), `ui-upload-img` (images), `ui-gr-upload-img` (base64)

### For Notifications
- **Toast Messages**: `ui-notification`
- **Error Messages**: `errorMessage`
- **Policy Violations**: `out-of-policy-message-bar`

### For Loading States
- **General Loading**: `ui-loading`

### For Empty States
- **No Items**: `render-no-items-show`

### For Navigation
- **Breadcrumbs**: `ui-breadcrumb-common`
- **Tabs**: `ui-pivot` (basic), `ui-menu-tab` (with overflow dropdown)

### For Layout
- **Standard Page Layout**: `ui-standard-layout`
- **Generic Wrapper**: `ui-layout-wrapper`

### For Content Display
- **Cards**: `ui-card` (report/expand/summary/workspace), `summaryCard` (dashboard navigable)
- **Image Carousel**: `ui-carousel` (auto-play), `ui-image-carousel` (manual nav)
- **Collapsible Sections**: `ui-collapse` (basic), `ui-new-collapse` (3 style variants)
- **Tags**: `ui-tags` (basic) or `ui-tag-custom` (custom styling)
- **Tooltips**: `ui-tooltip`
- **Progress Bar**: `ui-progress-bar`
- **Key-Value Display**: `ui-summary`

### For Advanced Features
- **Filtering**: `ui-new-filter`
- **Rich Text Editing**: `ui-rich-editor-toolbar`, `ui-rich-editor-action`
- **Reference/Placeholder Editor**: `ui-select-reference`
- **Drag & Drop**: `ui-drag-drop` (basic), `ui-drag-drop-sortable` (sortable lists)
- **Workflow Diagrams**: `react-flow`
- **Maps**: `ui-google-map`
- **Zoom Control**: `zoomComboBox`

---

**Note**: This catalog is maintained to help AI agents quickly identify the appropriate component for specific use cases in the Partner Portal UI project. When in doubt, search the component's source code for detailed props and usage examples.
