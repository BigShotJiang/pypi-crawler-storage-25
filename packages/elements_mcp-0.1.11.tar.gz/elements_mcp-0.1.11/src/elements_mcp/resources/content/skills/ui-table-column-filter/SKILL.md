---
name: ui-table-column-filter
description: "Use when creating, modifying, debugging, replacing, or reviewing pages that use UITableColumnFilter, useInitFilter, UINewFilter, column-level filters, global filtering, sorting, search, pagination, saved views, column management, or table filter child types."
metadata:
  keywords:
    - UITableColumnFilter
    - table filter
    - filter table
    - column filter
    - global filter
    - sort
    - search
    - pagination
    - saved views
    - column management
    - useInitFilter
    - UINewFilter
    - 筛选表格
    - 表格筛选
    - 排序
    - 搜索
---

# ui-table-column-filter

## Overview

`UITableColumnFilter` wraps `UITable` and adds column-header filters, sorting,
search, pagination, a global filter panel, saved views, and column management.
It is the standard table page surface for this repository's Allure 1 direction.

Start from structured table intent, inspect real API and row type facts before
choosing columns or filters, then wire `useInitFilter`, `UINewFilter`,
`UITableColumnFilter`, request payload state, renderers, i18n, and verification
from observed contracts. Do not replace it with raw Fluent UI `DetailsList`.

## Template References

Use templates as references in this order. The request template is mandatory;
implementation templates are loaded only after intake and relevant code/API
inspection.

| Template | Use |
| --- | --- |
| `templates/request-input.template.yaml` | Mandatory first user-facing draft for new table pages or broad table rewrites. |
| `templates/standard-table.template.mdx` | Split page, table wiring, hooks, payload flow, search, pagination, and command bar. |
| `templates/view-management.template.mdx` | Saved views and column management add-on. |
| `templates/filter-recipes.template.mdx` | Static, dropdown, date, dynamic, paginated, and searchable filter recipes. |
| `templates/column-definition.template.mdx` | Column metadata, filter keys, field names, sort config, and renderer setup. |

**Required companion:** use `ui-table-column` for every column `onRender`
helper decision.

Templates are examples, not authority. Align service names, row fields, payload
shape, i18n helpers, state names, imports, and table behavior with inspected
local code.

## When To Use

- The task creates, modifies, debugs, replaces, or reviews a table page that
  uses `UITableColumnFilter`, `useInitFilter`, or `UINewFilter`.
- The task touches column-level filters, global filters, sorting, search,
  pagination, selection, command bar actions, saved views, or column
  management.
- The task chooses among `ENewFilterChildType` filter variants such as
  `CheckBox`, `Radio`, `Date`, `DateRange`, dropdown filters, or dynamic
  filters.
- The task wires filter request payloads, `selectedAllOptionsApplied`,
  `filterDynamicDataSource`, `childList`, `mappedColumns`, or table reload
  behavior.

Use `UITableColumnFilter` for normal table pages. Configure it for the scenario
instead of switching to a different table component.

## When Not To Use

- Tree-structured data that requires a tree component.
- Inline-editable grids or spreadsheet-like editing flows.
- A simple list, card collection, drawer, or non-table workflow.
- Cell-renderer-only changes; use `ui-table-column` unless table filtering,
  sorting, search, or payload wiring also changes.
- Shared dropdown component work outside table filters; use `ui-dropdown`.

## Hard Gates

### Gate 1: Request Intake

For new table pages, broad rewrites, or requests that do not identify the API,
columns, filters, and expected behavior, the first user-facing output after
loading this skill must be the exact contents of
`templates/request-input.template.yaml` for the user to review.

Copy the YAML verbatim, including examples, accepted values, inline comments,
and blank lines. Do not replace example values with `~`, remove comments,
choose filters, inspect API code, or read implementation templates before the
user approves or edits the draft.

For narrow fixes where the target table and broken behavior are already clear,
identify the target, expected behavior, current behavior, scope, and required
output before inspecting code. Ask only for missing facts that cannot be safely
inferred from the request or nearby code.

### Gate 2: Existing Context Inspection

Before selecting an implementation path or writing code, inspect the relevant
existing context:

- target page, table wrapper, imports, hooks, and neighboring table examples
- service/API function, response shape, row interface, primary key, and payload
  contract
- existing columns, `fieldName`, `key`, sort config, filters, renderers, and
  i18n patterns
- `useInitFilter`, `UINewFilter`, `UITableColumnFilter`, `childList`,
  `mappedColumns`, `setKey`, `filterDynamicDataSource`, and event handlers
- search, pagination, selection, command bar, saved views, loading, empty,
  error, and permission behavior
- tests, stories, or manual verification patterns for the touched module

Do not invent API fields, row properties, filter keys, i18n IDs, state names,
payload fields, pagination shapes, or test helpers.

### Gate 3: Decision Summary Before Implementation

For new pages, generated pages, saved views, dynamic filters, API payload
changes, search/pagination changes, or fragile filter state wiring, provide a
summary before writing code:

```text
Table Page Summary
Path:        src/pages/customer-management/customer-list/
Component:   CustomerList
API:         FileHubService.GetPackageRevisions
Item type:   ICustomerItem
Columns:     5 (3 filterable, 2 sortable)
Search:      yes (name field)
Filters:     static status, dynamic customer, date range
Extras:      view management, Export, Refresh
Structure:   split page + column hook + data hook + types + constants + utils
Risks:       <unknowns or assumptions>

Proceed? [Yes / Edit columns / Start over]
```

For generated table pages, also provide a short "Generated File Plan" listing
each file and responsibility before writing files.

### Gate 4: Verification Before Completion

Before reporting completion, verify the selected table pattern, column/filter
contracts, request payload flow, search/sort/filter interactions, i18n,
loading/empty/error states when relevant, and any tests, type checks, lint
checks, or manual checks that apply.

## Workflow

1. Understand the target table, task type, user goal, expected behavior, current
   behavior, API/data source, columns, filters, search, and extras.
2. Use the request template for new or broad work; keep unknown required fields
   visible instead of guessing.
3. Inspect the target page, nearby examples, API/type sources, i18n files, and
   table helper usage before selecting a pattern.
4. Select the table path, filter types, renderer helpers, payload flow, and file
   structure by behavior and data contract.
5. Produce the Table Page Summary and Generated File Plan when required.
6. Implement minimal scoped changes using existing imports, names, i18n helpers,
   payload helpers, Allure 1 patterns, and page structure.
7. Verify with the checklist and report changed files, checks run, skipped
   checks, and remaining risks.

## Component Matrix

### Implementation Path

| Need / Behavior | Use | Reference |
| --- | --- | --- |
| Normal table page | `UITableColumnFilter` with `useInitFilter` and `UINewFilter` | `standard-table.template.mdx` |
| Saved views or column management | Standard table plus view management add-on | `view-management.template.mdx` |
| Column-level filter recipes | `filtersInformation` with matching child type | `filter-recipes.template.mdx` |
| Column metadata and sort/render wiring | `IColumn` definitions plus table renderer helpers | `column-definition.template.mdx` and `ui-table-column` |
| Tree data | Tree component | outside this skill |
| Inline editable grid | Existing editable grid pattern | outside this skill |

### Filter Types

| Need / Behavior | `ENewFilterChildType` | Data Source | Paginated |
| --- | --- | --- | --- |
| Static multi-select options | `.CheckBox` | static `dataSource[]` | No |
| Static multi-select with icon | `.CheckBox` plus `icon` | static `dataSource[]` | No |
| Static single-select options | `.Radio` | static `dataSource[]` with All option | No |
| Single date | `.Date` | date value | No |
| Date range | `.DateRange` | start/end date values | No |
| Dropdown multi-select | `.DropDownMultiSelect` | static `dataSource[]` | No |
| Dropdown single-select | `.DropDownSingleSelect` | static `dataSource[]` | No |
| Dynamic options loaded once | `.DynamicMultiDropDown` | `getDataFunction` | No |
| Dynamic paginated/searchable multi-select | `.DynamicCheckbox` | `getPaginationDataFunction` | Yes |
| Dynamic paginated/searchable single-select | `.DynamicRadio` | `getPaginationDataFunction` | Yes |

Select by user-facing behavior, option source, selected value contract, and
documented filter support. Do not choose by naming similarity, unsupported
flags, or guessed API fields.

### Generated Page Structure

| File / Folder | Responsibility |
| --- | --- |
| `{PageComponent}.tsx` | Table wiring: `useInitFilter`, `UINewFilter`, `UITableColumnFilter`, and event handoff. |
| `hooks/Use{PageComponent}Columns.tsx` | Column metadata, filter recipes, renderer helpers, and dynamic filter loaders. |
| `hooks/Use{PageComponent}TableData.tsx` | Table state, search state, pagination, `payloadRef`, `syncRequestAndLoadData`, clear/reset handlers. |
| `Types.ts` | Row, payload, response, and hook contract interfaces. |
| `Constants.ts` | Page size, default sort field, filter option metadata, stable IDs, and field maps. |
| `utils/` | Payload conversion helpers and API/mock service adapters. |
| `components/` | Page-specific child components only when the page needs them. |
| `index.module.scss` | Page-scoped styles. |
| `index.tsx` | Page export entry. |

Do not generate production table pages as one large `.tsx` file unless the user
explicitly asks for a throwaway prototype. Folder names stay lowercase.

## Value Shape Rules

- `filtersInformation[].key`, `filtersInformation[].columnKey`, and column
  `key` must match for every filterable column.
- Column `fieldName` must match the inspected row item property.
- Set `isColumnFiltered: true` on every filterable column; otherwise the filter
  icon can be missing.
- Pass `mappedColumns` returned by `useInitFilter` to `UITableColumnFilter`,
  not raw `columns`.
- Build `childList` from `columns.flatMap(col => col.filtersInformation ?? [])`.
- Keep `setKey` unique per table instance.
- `syncRequestAndLoadData` is the single entry point for filter apply, sort,
  search, clear, and reload behavior.
- `syncRequestAndLoadData` is the only place that updates
  `selectedAllOptionsApplied`.
- `searchKey` drives the input box; `payloadRef.current.searchValue` stores the
  request value. `onSearch` and `onClear` must update both through
  `syncRequestAndLoadData`.
- Dynamic filters require both `filterDynamicDataSource` and
  `setFilterDynamicDataSource`.
- Dynamic paginated filters must return
  `{ data, jumpPage, pageSize, searchValue, hasNextPage }`.
- Radio filters need an All option such as
  `{ key: 'All', text: 'All', isDefaultSelectedOption: true }` unless existing
  code provides an equivalent clear path.
- Column names, filter titles, placeholders, empty text, command bar labels,
  saved view labels, and option text must use existing repo i18n helpers.
- Use stable IDs or backend keys for filters, rows, view IDs, and command
  actions. Do not store display text as the value unless existing code already
  uses that contract.
- Long-text columns use `ui-table-column` renderer helpers such as
  `tooltipPlainText`; do not hand-roll raw span cells.
- Generated comments should be short and plain, such as `// Table state` or
  `// Global filter panel`; avoid decorative divider comments.

Default values after inspection confirms they are appropriate:

| Setting | Default |
| --- | --- |
| `sortable` | `no` |
| `filter` | `none` |
| `renderer` | `tooltipPlainText` |
| `search.enabled` | `true` |
| `extras.view_management` | `false` |
| `extras.selection_mode` | `multiple` |

## Pressure Rules and Red Flags

Pressure does not bypass intake, inspection, summary, file plan, or
verification. Stop, inspect, ask, or document an assumption when:

- the user says "just write it", "make it quick", "use your best guess", or
  "small change" while the target, API, columns, or expected behavior is unclear
- the target page, module, API, row type, or primary key is unknown
- columns are requested as "all fields" before the API/type source is inspected
- a filter key, `fieldName`, state variable, payload field, i18n key, or option
  key would be invented
- selected filter type conflicts with option source, pagination, or single vs
  multi-select behavior
- raw `columns` would be passed to the table instead of `mappedColumns`
- `setSelectedAllOptionsApplied` would be updated outside
  `syncRequestAndLoadData`
- search, sort, filter, and clear paths would update different request state
  sources
- dynamic filters are missing `filterDynamicDataSource`,
  `setFilterDynamicDataSource`, or the required pagination return shape
- radio filters lack a clear or All option
- user-visible text would be hardcoded
- implementation would collapse generated files into one large component,
  change shared table behavior, add unsupported props, or introduce a new
  dependency
- verification cannot be performed

## Common Mistakes

- Skipping request intake for a new page and generating from
  `standard-table.template.mdx` before API/type facts are known.
- Choosing filter types by similar names instead of behavior and data source.
- Forgetting `isColumnFiltered: true` on filterable columns.
- Breaking the triple-key match between filter `key`, `columnKey`, and column
  `key`.
- Passing raw `columns` to `UITableColumnFilter`.
- Splitting filter, sort, search, and clear into separate reload chains.
- Treating `searchKey` state as the request value without syncing
  `payloadRef.current.searchValue`.
- Updating `selectedAllOptionsApplied` in multiple handlers.
- Forgetting dynamic filter data source state or returning the wrong pagination
  shape.
- Hardcoding column names, filter titles, option text, command labels, or saved
  view labels.
- Putting raw column arrays, payload conversion, or API/mock service logic in
  the entry component.

## Checklist

### Intake

- [ ] Target page, task type, user goal, expected behavior, and current behavior are known.
- [ ] For new or broad work, the request YAML was sent and approved or edited.
- [ ] `page_path`, `component_name`, API/data source, row type, primary key, columns, filters, search, and extras are known or visible as unknowns.
- [ ] Unknown paths, fields, keys, state names, payload fields, and i18n IDs were not invented.

### Selection

- [ ] Existing table examples and target table code were inspected.
- [ ] API/service source, response shape, row interface, and payload contract were inspected when relevant.
- [ ] Selected filter types match behavior, data source, pagination, and value contract.
- [ ] Renderer helpers were selected through `ui-table-column`.
- [ ] Saved views, command bar, selection, loading, empty, error, and permission patterns match local usage.
- [ ] Red flags were resolved before implementation.

### Implementation

- [ ] Changes are minimal and scoped to the approved table behavior.
- [ ] Filter triple-key match and `fieldName` contracts are correct.
- [ ] Filterable columns set `isColumnFiltered: true`.
- [ ] `mappedColumns` from `useInitFilter` is passed to `UITableColumnFilter`.
- [ ] `childList` uses `columns.flatMap(col => col.filtersInformation ?? [])`.
- [ ] `syncRequestAndLoadData` owns filter, sort, search, clear, payload update, and reload behavior.
- [ ] `selectedAllOptionsApplied` is updated only inside `syncRequestAndLoadData`.
- [ ] Search state and request payload search value stay synchronized.
- [ ] Dynamic filter data source props and pagination return shape are correct.
- [ ] Radio filters have a clear or All option.
- [ ] Generated table pages are split into page component, column hook, data hook, types, constants, and utilities.
- [ ] User-visible text uses i18n helpers; no hardcoded labels, titles, placeholders, or option text.
- [ ] No unrelated files, new dependencies, or shared table behavior changed unless explicitly requested.

### Verification

- [ ] Table Page Summary and Generated File Plan were provided when required.
- [ ] Main load, pagination, filter apply, filter clear, sort, search, and search clear flows were verified when touched.
- [ ] Dynamic filter loading and paginated search were verified when relevant.
- [ ] Saved views, command bar, selection, loading, empty, error, and permission states were verified when relevant.
- [ ] i18n and cell overflow/rendering behavior were checked when relevant.
- [ ] Tests, type checks, lint checks, or manual checks are recorded; skipped checks include a reason.

## Output Format

For completed work, report:

```text
Done:
- <what changed>

Changed:
- <file>: <summary>

Verified:
- <checks run>

Not Verified:
- <checks not run and why>

Risks / Notes:
- <remaining assumptions or follow-up>
```

For missing input, report only the missing fields:

```text
Missing Required Input:
- <field>: <why this is required>

Please provide:
<YAML fields that need user input>
```

For blocked execution, report:

```text
Blocked:
- <reason>

What I checked:
- <checked item>

What is missing:
- <missing context>

Next step:
- <specific next action>
```
