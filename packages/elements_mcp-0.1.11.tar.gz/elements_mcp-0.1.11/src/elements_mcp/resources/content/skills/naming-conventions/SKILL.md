---
name: naming-conventions
description: "Use when creating, renaming, modifying, or reviewing React/TypeScript files, folders, variables, components, hooks, CSS modules, interfaces, types, enums, constants, or i18n keys during feature work, refactors, page creation, and code review."
metadata:
  keywords:
    - naming convention
    - file naming
    - folder naming
    - component naming
    - hook naming
    - type naming
    - enum naming
    - i18n key naming
    - independent page
    - independently accessible page
    - 命名规范
    - 文件命名
    - 组件命名
    - 目录命名
    - 独立可访问
    - 独立页面
    - 可访问页面
---

# Naming Conventions

## Overview

Use this as a quick naming reference. Names should match nearby repository
patterns and the thing's actual domain meaning. Do not invent paths, fields,
callbacks, CSS classes, or i18n keys when existing code can answer.

## When To Use

- Creating or renaming files, folders, components, hooks, variables, methods,
  interfaces, types, enums, constants, CSS modules, SCSS classes, or i18n keys.
- Reviewing naming consistency during feature work, page creation, refactors,
  migrations, or code review.

## When Not To Use

Do not use this to rename external contracts such as backend fields, routes,
persisted keys, telemetry names, or public API exports unless the user asked for
that contract change.

## Hard Gates

- Identify the target category and domain meaning before choosing a name.
- Inspect sibling files, folders, components, hooks, models, services, helpers,
  types, constants, CSS modules, i18n prefixes, imports, exports, tests, routes,
  and references before renaming.
- Stop before guessing an i18n key, CSS class, field, state name, callback, or
  external contract name.

## Workflow

1. Understand the target, task type, category, and domain meaning.
2. Inspect local naming patterns and affected references.
3. Apply the naming matrix.
4. Preserve external contracts and update affected references.
5. Verify imports, exports, JSX, SCSS, tests, routes, locale references, and
   user-visible text handling.

## Component Matrix

| Target | Rule | Example |
| --- | --- | --- |
| Variable / method | `lowerCamelCase` | `firstName`, `getCustomerDetails` |
| Class / React component | `UpperCamelCase` | `CustomerDetails`, `DynamicRuleBuilder` |
| Acronym at name start | Keep acronym uppercase. | `BIExportReport`, `UIButton`, `APIService` |
| Interface | `I` + `UpperCamelCase` | `ICustomerDetail`, `IRuleItem` |
| Type alias | `T` + `UpperCamelCase` | `TStateType`, `TCustomerData` |
| Enum | `E` + `UpperCamelCase` | `ECustomerStatus`, `EDynamicFieldType` |
| React hook | `use` + `lowerCamelCase`; hook file uses `Use{Name}.ts`. | `useCustomerData`, `UseCustomerData.ts` |
| Constant | `UPPER_SNAKE_CASE` | `MAX_VALUE`, `API_TIMEOUT` |
| Folder | `lowercase-with-hyphens` | `customer-detail`, `user-management` |
| React / TS file | `PascalCase` | `CustomerDetails.tsx`, `FormatHelpers.ts` |
| Page structure file | Fixed repository names. | `Types.ts`, `Constants.ts`, `index.tsx`, `index.module.scss` |
| CSS module class | `lowerCamelCase`; access with `Styles.className`. | `customerDetailShow` |
| i18n key | `Partner_Gui_{Context}_{Type}_{Description}` | `Partner_Gui_Customer_Label_Name` |

## Value Shape Rules

- Import CSS modules as `Styles` and use direct property access:
  `Styles.customerDetailShow`.
- Keep SCSS class names aligned with TSX usage; do not create orphaned classes
  or guessed class names.
- User-visible labels, placeholders, buttons, errors, empty states, and
  tooltips must use repo i18n patterns.
- Reuse existing i18n context/type segments when adding keys. Use
  `i18n-usage` when full locale behavior is involved.
- Preserve backend fields, route params, persisted keys, telemetry names, public
  exports, snapshots, and API contracts unless explicitly changed.

## Pressure Rules and Red Flags

Stop, inspect, ask, or document an assumption when:

- the proposed name is generic: `Data`, `Info`, `Item`, `List`, `Detail`, or
  `Modal`
- the i18n key, CSS class, field, state name, or callback would be guessed
- a rename crosses module boundaries or touches routes, API contracts, storage,
  telemetry, snapshots, exports, or locale files
- nearby code conflicts with the generic rule
- user-visible text would be hardcoded
- verification cannot be performed

## Common Mistakes

- Renaming API fields or route params to satisfy UI naming rules.
- Choosing a name by nearby similarity instead of domain meaning.
- Updating TSX class usage without updating `index.module.scss`, or the reverse.
- Creating a new i18n key when an existing semantic key should be reused.
- Leaving stale imports, exports, tests, or locale references after a rename.

## Checklist

### Intake

- [ ] Target, task type, category, and domain meaning are known.

### Selection

- [ ] Existing local naming patterns and affected references were checked.
- [ ] Name matches the category rule and domain meaning.

### Implementation

- [ ] Renames update imports, exports, JSX, SCSS, tests, routes, and locale
  references where relevant.
- [ ] External contracts are preserved unless explicitly changed.
- [ ] No hardcoded user-visible strings were introduced.

### Verification

- [ ] Result matches the request.
- [ ] Affected references resolve.
- [ ] Checks run or skipped checks are recorded with reasons.
