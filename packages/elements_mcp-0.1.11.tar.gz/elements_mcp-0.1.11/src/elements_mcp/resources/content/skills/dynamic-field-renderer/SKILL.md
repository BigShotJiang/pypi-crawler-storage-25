---
name: dynamic-field-renderer
description: "Use when creating, modifying, debugging, replacing, or reviewing DynamicFieldsRenderer forms, IDynamicFieldConfig arrays, DynamicFieldsRenderer refs, field dependencies, LvForm validations, custom fields, people pickers, or schema-to-field mapping."
metadata:
  keywords:
    - DynamicFieldsRenderer
    - dynamic field
    - IDynamicFieldConfig
    - LvForm
    - form validation
    - field dependency
    - people picker
    - schema mapping
    - 动态字段
    - 动态表单
    - 表单校验
    - 字段依赖
---

# dynamic-field-renderer

## Overview

`DynamicFieldsRenderer` converts `IDynamicFieldConfig[]` into LvForm/Allure
controls, keeps merged form values, and exposes `getValues`, `setValues`,
`reset`, and `validate` through a ref.

Start from template intake, inspect repository facts only after the intake is
approved, then choose field config, value shapes, validation, dependencies,
custom-field ownership, schema mapping, and i18n from observed contracts.

## Template References

Use templates as references in this order. The request template is mandatory;
the implementation templates are loaded only after intake approval and local
inspection.

| Template | Use |
| --- | --- |
| `templates/request-input.template.yaml` | Mandatory first user-facing output for every DynamicFieldsRenderer request. |
| `templates/renderer-usage.template.mdx` | Page-level renderer setup, ref usage, submit/reset wiring, and initial values. |
| `templates/field-config.template.mdx` | Adding or changing `IDynamicFieldConfig[]` entries. |
| `templates/customize-field.template.mdx` | `EDynamicFieldType.Customize` patterns where caller owns value, errors, validation, reset, and submit merge. |
| `templates/schema-mapping.template.mdx` | Mapping backend/product schema metadata into field config. |

Templates are examples, not authority. Align imports, helper names, i18n style,
state shape, and submit contracts with inspected local code.

## When To Use

- The task creates, modifies, debugs, replaces, or reviews a dynamic,
  schema-driven, or configuration-driven form.
- The task touches `DynamicFieldsRenderer`, `IDynamicFieldConfig[]`,
  `EDynamicFieldType`, renderer refs, field dependencies, or LvForm validation
  through the renderer.
- The task maps backend/product schema metadata into dynamic field config.
- The task adds renderer custom fields, people pickers, dropdown fields,
  checkbox groups, radio groups, dates, submit/reset behavior, or i18n wiring.

Prefer `DynamicFieldsRenderer` when the field list comes from metadata or a
page-local config and the renderer already owns the matching control behavior.

## When Not To Use

- Simple static forms where local page code is clearer.
- Inline editable tables, filter panels, drawers, or non-form layouts.
- Shared dropdown behavior outside `DynamicFieldsRenderer`; use `ui-dropdown`.
- Custom fields that need renderer-managed value or error state.
  `Customize` fields are caller-managed by design.
- Direct changes to shared renderer behavior unless the user explicitly asks to
  extend the renderer for all consumers.

## Hard Gates

### Gate 1: Request Intake

<HARD-GATE>
For every DynamicFieldsRenderer request, the first user-facing output after
loading this skill MUST be the exact contents of
`templates/request-input.template.yaml` for the user to review.

Copy the YAML verbatim, including comments, example values, inline comments,
and blank lines. Do not adapt it to the request, replace examples with `~`,
complete unknown fields, shorten comments, or inspect implementation files.

After sending the YAML draft, STOP. Continue only after the user returns edited
YAML or explicitly approves the draft.
</HARD-GATE>

Send only a short sentence asking the user to edit or confirm the YAML plus the
YAML block. Do not ask the user to choose internal imports, helper names,
callback names, generated state names, or renderer internals.

### Gate 2: Existing Context Inspection

After YAML approval, inspect only the context named by the approved YAML:

- `page_path`, nearby page/component patterns, and existing renderer usage
- `schema_source`, `schema_model`, service calls, backend metadata, local
  config, or TypeScript types
- `fields`, existing value shapes, validation helpers, dependency fields,
  custom field ownership, reset behavior, and submit/get-values flow
- provided i18n keys and the surrounding module's localization pattern
- tests, stories, or manual verification patterns for the touched module

Do not invent field keys, API/schema functions, i18n IDs, state variables,
value shapes, validation helpers, dependency conditions, or submit payload
contracts. If a required fact is still unknown, update the YAML or ask a
focused question before selecting a pattern.

### Gate 3: Dynamic Form Summary Before Implementation

Before writing DynamicFieldsRenderer code, provide a Dynamic Form Summary and
wait for the user to approve, edit, or restart.

```text
Dynamic Form Summary
Path:        src/pages/example-feature/example-form/
Component:   ExampleConfigurationForm
Fields:      6 (4 required, 1 dependency, 1 custom)
Values:      outer actions use ref.getValues()/validate()
Validation:  LvForm fields + caller-managed custom validation
I18n:        labels, placeholders, options, buttons, errors use intl/getMessage
Proceed? [Yes / Edit fields / Start over]
```

### Gate 4: Verification Before Completion

Before reporting completion, verify field types, value shapes, initial values,
dependencies, custom-field submit/reset/validation behavior, i18n, and submit
payload contracts for the touched form.

## Workflow

1. Send the exact request YAML template and wait for approval or edits.
2. Preserve unknown non-i18n fields as visible `~`; leave blank
   `*_i18n_key` values blank instead of inventing keys.
3. Inspect only the files, schemas, fields, and actions named by the approved
   YAML or required to resolve those facts.
4. Select the implementation path and field types by behavior, value contract,
   and existing repository usage.
5. Send the Dynamic Form Summary and wait for approval.
6. Implement minimal scoped changes with the matching template as a reference.
7. Verify using the checklist and report changed files, checks, skipped checks,
   and remaining risks.

## Component Matrix

### Implementation Path

| Need / Behavior | Use | Reference |
| --- | --- | --- |
| New page-level dynamic form | `DynamicFieldsRenderer` with page-owned ref | `renderer-usage.template.mdx` |
| Add or change existing fields | `IDynamicFieldConfig[]` entries | `field-config.template.mdx` |
| Backend/product schema drives fields | Schema-to-config mapper | `schema-mapping.template.mdx` |
| Control cannot be represented by built-in field types | `EDynamicFieldType.Customize` | `customize-field.template.mdx` |
| Shared dropdown behavior outside the renderer | `@components/ui-dropdown` skill | none in this skill |

Choose by requested behavior and data contract, not by label text, naming
similarity, or unsupported props that make one field mimic another.

### Field Types

| Type | Control | Value shape | Validation |
| --- | --- | --- | --- |
| `TextInput` | `LvTextField` | `string` | `stringRequired`, email, custom |
| `TextArea` | `LvTextField multiline` | `string` | `stringRequired`, custom |
| `NumberInput` | `LvSpinButton` | `number` or `''` | custom range |
| `DropDownSingleSelect` | `LvDropDownSingleSelectionSearch` | `string` | `stringRequired` |
| `DropDownMultiSelect` | `LvMultipleSelect` | `string[]` | `arrayRequired` |
| `CheckBox` | `CheckboxWithValidation` | `string[]` | `arrayRequired` |
| `Radio` | `ChoiceGroupWithValidation` | `string` | `stringRequired` |
| `Date` | `LvUIDatePicker` | `Date` | `dateRequired` |
| `PeoplePickerCompact` | `LvUICompactPeoplePicker` | `IPersonaProps[]` | `arrayRequired` |
| `PeoplePickerList` | `LvUIListPeoplePicker` | `IPersonaProps[]` | `arrayRequired` |
| `Customize` | `field.customRender()` | caller-owned | caller-owned |

## Value Shape Rules

- `initialValues`, `setValues`, `getValues`, and submitted values must match
  the field type matrix.
- `initialValues` seeds renderer state on mount; keep every renderer-managed
  field present with the correct shape.
- `onChange` receives the full merged form object after renderer-managed field
  changes.
- `setValues(values)` shallow-merges values and calls `onChange`.
- `reset()` restores `initialValues` and calls `onChange`.
- `validate()` validates LvForm-managed fields only. Combine it with
  caller-managed validation when `EDynamicFieldType.Customize` is present.
- `Customize` values, errors, reset behavior, and submit merge stay in the
  caller.
- Hidden dependency fields are not rendered, but their existing values remain
  in form data.
- Labels, placeholders, option text, button text, and validation messages must
  use repo i18n helpers. Blank intake `*_i18n_key` fields are not permission to
  hardcode text or invent keys.
- Pass field-specific props directly in field config. Use `extraProps` only for
  underlying control props not modeled by the field type.
- When adding a new field type, update the enum, field config interface, union
  type, `getCorrespondingComponentByFieldType`, schema mapping if needed, and a
  focused example.

### Dependency Contract

Dependencies are evaluated against current `formData`.

| Action | Behavior |
| --- | --- |
| `show` | Render field only when condition is true |
| `hide` | Hide field when condition is true |
| `enable` | Disable field unless condition is true |
| `disable` | Disable field when condition is true |

Keep dependency conditions small and local. If a condition uses business rules,
extract a named helper so the config stays readable.

## Pressure Rules and Red Flags

Pressure does not bypass request intake, inspection, summary approval, or
verification. Stop, inspect, ask, or return to the required gate when:

- the user says "just write it", "quick fix", "small change", or "debug this"
  before approving request YAML
- TSX/schema/API/i18n files are about to be read before the request YAML is
  approved
- a Dynamic Form Summary would be sent before request YAML approval
- missing schema names, i18n IDs, option keys, field keys, state variables,
  validation helpers, dependency conditions, or value shapes would be guessed
- blank `*_i18n_key` intake values would be filled with invented keys
- the first intake YAML would be adapted instead of copied verbatim
- template comments would be stripped from the request YAML
- a single-value field is wired with an array value, or a multi-value field is
  wired with a scalar value
- `Customize` is treated as renderer-managed
- `validate()` is assumed to cover custom fields
- user-visible labels, placeholders, option text, button text, or errors would
  be hardcoded
- implementation would add unsupported props, broad renderer changes, unrelated
  refactors, or a new dependency
- verification cannot be performed

## Common Mistakes

- Skipping `request-input.template.yaml` review because the task seems small.
- Inspecting page code, schema functions, API types, i18n files, or templates
  before YAML approval.
- Choosing a field type by similar name instead of behavior and value shape.
- Inventing i18n keys, field keys, state variables, validation helpers, or
  dependency expressions.
- Assuming `validate()` covers `Customize` fields.
- Forgetting to merge caller-owned custom values into submit/get-values flows.
- Passing string dates to `Date` fields instead of `Date` values.
- Changing shared renderer behavior to solve one local page request.

## Checklist

### Intake

- [ ] The exact `request-input.template.yaml` contents were sent before any inspection.
- [ ] The user explicitly approved or edited the request YAML.
- [ ] The first intake YAML preserved comments, example values, inline comments, and blank lines.
- [ ] Unknown non-i18n fields remain visible as `~` instead of invented values.
- [ ] Blank `*_i18n_key` fields remain blank in intake facts instead of invented values.

### Selection

- [ ] Inspection followed `page_path`, `schema_source`, `schema_model`, `fields`, and action settings from the approved YAML.
- [ ] Existing page, schema, API, i18n, validation, dependency, and submit patterns were inspected when relevant.
- [ ] Selected implementation path matches the requested behavior.
- [ ] Field types match behavior and value contracts.
- [ ] Field `key` values are stable and unique.
- [ ] Dependencies use correct `show`/`hide`/`enable`/`disable` semantics.
- [ ] Red flags were resolved before implementation.

### Implementation

- [ ] Changes are minimal and scoped to the approved form request.
- [ ] `initialValues` includes every renderer-managed field with the correct shape.
- [ ] Labels, placeholders, option text, button text, and validation messages use i18n.
- [ ] Required text/radio/single-select fields use string validation.
- [ ] Required checkbox/multi-select/people picker fields use array validation.
- [ ] Required dates use date validation and `Date` initial values.
- [ ] Custom fields merge values into submit/get-values flows.
- [ ] Custom fields validate, reset, and clear errors in caller code.
- [ ] Outer submit calls `validate()` and submits only when renderer and custom validations pass.
- [ ] No unrelated files, new dependencies, or shared renderer behavior changed unless explicitly requested.

### Verification

- [ ] Dynamic Form Summary was approved before writing code.
- [ ] Value shape and validation match every selected field type.
- [ ] Submit/reset/get-values behavior matches the approved YAML.
- [ ] No user-visible string is hardcoded.
- [ ] Schema/API mapping matches inspected source facts.
- [ ] Main form flow and relevant edge cases were verified.
- [ ] Tests, type checks, lint checks, or manual checks are recorded; skipped checks include a reason.

## Output Format

For completed work, report:

```text
Done:
- <what changed>

Changed:
- <file>: <summary>

Verified:
- <checks run>

Not Verified:
- <checks not run and why>

Risks / Notes:
- <remaining assumptions or follow-up>
```

For missing input, report only the missing fields:

```text
Missing Required Input:
- <field>: <why this is required>

Please provide:
<YAML fields that need user input>
```
