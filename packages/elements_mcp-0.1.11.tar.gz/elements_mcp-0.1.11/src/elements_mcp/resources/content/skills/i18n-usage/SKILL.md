---
name: i18n-usage
description: "Use when adding, updating, auditing, or reviewing i18n keys, locale values, intl.formatMessage usage, locale file placement, module locale scope, placeholders, JSX interpolation, or user-visible text."
metadata:
  keywords:
    - i18n
    - locale
    - intl.formatMessage
    - translation key
    - user-visible text
    - placeholder
    - JSX interpolation
    - locale file
    - 国际化
    - 文案
    - 翻译
    - 语言包
    - 多语言
---

# Internationalization Usage

## Overview

Use this as the project i18n reference. The canonical runtime pattern is
`import { intl } from '@utils/i18n'` with `intl.formatMessage({ id })`; do not
use `useIntl()` or custom `useI18N` hooks in this repo.

Reuse existing semantic keys first. Add or update English locale files only;
non-English locale files are synced from a third-party system and manual
changes will be overwritten.

## When To Use

- Adding, updating, auditing, or reviewing any i18n key or locale value.
- Replacing hardcoded labels, placeholders, buttons, tooltips, errors, empty
  states, confirmations, statuses, table columns, or messages.
- Choosing global versus module locale file placement.
- Wiring `intl.formatMessage` with primitives, placeholders, or JSX elements.

## When Not To Use

Do not use this to change product wording strategy, backend localization
contracts, translation sync behavior, or non-English locale files unless the
user explicitly requested that contract change.

## Hard Gates

- Search existing global and module locale files before adding a new key.
- Stop before editing any non-English locale file.
- Stop before guessing a context, type segment, placeholder name, locale file,
  or module scope.
- Stop before duplicating the same semantic text in global and module files.

## Workflow

1. Understand the user-visible text, task type, module/page context, and
   placeholders.
2. Inspect existing keys in global and relevant module locale files.
3. Reuse a semantic match, or choose the correct scope and key shape.
4. Wire `intl.formatMessage` and update only the approved English locale file.
5. Verify usage, key naming, scope, placeholder names, and locale JSON validity.

## Component Matrix

| Need / Behavior | Rule | Example |
| --- | --- | --- |
| Basic text | `intl.formatMessage({ id })` | `intl.formatMessage({ id: 'Partner_Gui_Customer_Title_Details' })` |
| Primitive placeholder | Pass values as the second argument; prefer matching variable names. | `intl.formatMessage({ id }, { count })` |
| JSX interpolation | Pass JSX as a named placeholder and keep link/button text separately localized. | `intl.formatMessage({ id }, { link: <a>{text}</a> })` |
| Shared/common UI text | Use global locale scope. | `src/locales/aosp.en.json` |
| Module-specific business text | Use that module locale file. | `src/modules/{module-name}/locales/{moduleName}.en.json` |
| Existing semantic key | Reuse the existing key and location. | Do not duplicate new keys. |

## Value Shape Rules

- Key shape: `Partner_Gui_{Context}_{Type}_{Description}`.
- Common type segments include `Title`, `Label`, `Button`, `Message`, `Error`,
  `Confirm`, `Placeholder`, `Status`, `Tooltip`, and `Column`.
- Placeholders in code and locale values must match exactly, such as
  `{ count }` with `"You have {count} items"`.
- Insert new keys in logical feature/context grouping, not randomly or only by
  alphabetical order.
- Global English file: `src/locales/aosp.en.json`.
- Module English file:
  `src/modules/{module-name}/locales/{moduleName}.en.json`.
- Do not manually edit non-English files such as `aosp.de.json` or
  `aosp.ja.json`.

## Pressure Rules and Red Flags

Stop, inspect, ask, or document an assumption when:

- the text's feature context or module scope is unclear
- an existing key might already match the same semantics
- a key, placeholder, locale file, or type segment would be guessed
- code needs user-visible text but no i18n pattern has been inspected
- a non-English locale file would be changed
- the same text would be duplicated in global and module locale files
- verification cannot be performed

## Common Mistakes

- Using `useIntl()` or a custom hook instead of `intl` from `@utils/i18n`.
- Creating generic keys such as `Partner_Gui_Common_Button_1`.
- Adding module-only language to `src/locales/aosp.en.json`.
- Changing translated locale files by hand.
- Letting placeholder names differ between code and locale values.
- Hardcoding labels, buttons, placeholders, or error messages in TSX.

## Checklist

### Intake

- [ ] User-visible text, module/page context, task type, and placeholders are
  known.

### Selection

- [ ] Existing global and module keys were inspected for reuse.
- [ ] Global versus module scope is justified.
- [ ] Key follows `Partner_Gui_{Context}_{Type}_{Description}`.

### Implementation

- [ ] Code uses `intl.formatMessage({ id })` from `@utils/i18n`.
- [ ] Only approved English locale files are edited.
- [ ] Placeholder names match between code and locale values.
- [ ] Keys are inserted in logical feature/context grouping.

### Verification

- [ ] Result matches the request.
- [ ] Locale JSON remains valid.
- [ ] No non-English locale files were modified.
- [ ] Checks run or skipped checks are recorded with reasons.
