---
name: ui-table-column
description: "Use when implementing or modifying any table column's `onRender` cell renderer. Covers all tooltip helpers (text, link, persona, facepile, status, date, icon, tenant) from `@components/ui-table-column`. Trigger this skill whenever you need to display data inside a table cell with tooltip / overflow / persona / status / link semantics."
metadata:
  keywords:
    - ui-table-column
    - table column renderer
    - onRender
    - cell renderer
    - tooltipPlainText
    - tooltipDatePlainText
    - persona renderer
    - status renderer
    - column tooltip
    - 表格列渲染
    - 单元格渲染
    - 列 tooltip
---

# ui-table-column — Cell Renderer Toolkit

`@components/ui-table-column` is **not** a React component — it is a set of
**cell renderer helper functions** used inside a column's `onRender`. Always
prefer these helpers over hand-rolling `TooltipHost + ellipsis + span`.

- **Code templates**: use the focused files in `templates/`:
  - Text and tooltip cells: [text-renderers.template.mdx](./templates/text-renderers.template.mdx)
  - Interactive/action cells: [interactive-renderers.template.mdx](./templates/interactive-renderers.template.mdx)
  - Rich visual cells: [rich-renderers.template.mdx](./templates/rich-renderers.template.mdx)
- **Used by**: [ui-table-column-filter](../ui-table-column-filter/SKILL.md) skill

## When to Use

Use one of these helpers in **every** column's `onRender`. Do not write raw
`<span>{value}</span>` inside columns — overflow tooltips will be missing.

```tsx
// ❌ raw span, no overflow tooltip, no decode
{
  key: 'name',
  fieldName: 'name',
  onRender: item => <span>{item.name}</span>
}

// ✅ use a helper
{
  key: 'name',
  fieldName: 'name',
  onRender: (item, index, column) => tooltipPlainText({ item, index, column })
}
```

## Renderer Catalog

| Scenario                                | Helper                       |
| --------------------------------------- | ---------------------------- |
| Plain text, single line + tooltip       | `tooltipPlainText`           |
| Plain text + right-side label           | `tooltipPlainTextWithLabel`  |
| Multi-line text (preserve `\n`)         | `tooltipNewLine`             |
| Always-visible tooltip                  | `tooltipAlwaysShowText`      |
| Primary + secondary text (two rows)     | `tooltipPlainSecondText`     |
| Clickable text (no link styling)        | `tooltipJointText`           |
| Link text (Allure `Link`)               | `tooltipLinkText`            |
| Link text + right-side label            | `tooltipLinkTextWithLabel`   |
| Single icon (clickable, with tooltip)   | `tooltipIcon`                |
| Icon + text                             | `tooltipIconText`            |
| Status dot + text                       | `tooltipStatusText`          |
| Date (date only)                        | `tooltipDatePlainText`       |
| Date + time                             | `tooltipDateTimePlainText`   |
| Persona (avatar + name [+ secondary])   | `tooltipPersona`             |
| Tenant (large persona variant)          | `RenderTenant`               |
| Multiple users (overlapping avatars)    | `tooltipFacepileGroup`       |

## Common Props (`TooltipColumTemplateProps`)

Most helpers share this prop shape:

| Prop          | Type                           | Notes                                                                |
| ------------- | ------------------------------ | -------------------------------------------------------------------- |
| `item`        | row data                       | Pass the `item` from `onRender` — value is read via `column.fieldName` |
| `index`       | `number`                       | Pass the `index` from `onRender`; used as React `key`                |
| `column`      | `IColumn`                      | Pass the `column` from `onRender`                                    |
| `text`        | `string`                       | Override the value resolved from `item[column.fieldName]`            |
| `content`     | `string \| JSX.Element`        | Override tooltip content (defaults to the displayed text)            |
| `rootStyle`   | `React.CSSProperties`          | Style overrides for the wrapper element                              |
| `onItemClick` | event handler                  | Available on clickable variants (link / joint / persona)             |

## Critical Rules

1. **Always pass `item`, `index`, `column`** to value-bound helpers so `fieldName` resolution works
2. **Use `text` to override** when displayed text differs from `item[fieldName]` (e.g. translated enum)
3. **Use `content` to override tooltip** when the visible text is truncated (e.g. join multiple fields)
4. **Use `intl.formatMessage`** for any user-visible string — never hardcode
5. **Persona / Tenant**: `text` carries the primary text; `secondaryText` and `imageUrl` are separate props
6. **Date helpers** read the value from `item[column.fieldName]` and expect a numeric timestamp (ms)

## Common Mistakes (❌ → ✅)

### Missing overflow tooltip
```tsx
// ❌
onRender: item => <div>{item.description}</div>
// ✅
onRender: (item, index, column) => tooltipPlainText({ item, index, column })
```

### Hardcoded display text
```tsx
// ❌
onRender: item => tooltipPlainText({ item, text: 'Active' })
// ✅
onRender: item => tooltipPlainText({ item, text: intl.formatMessage({ id: 'common.active' }) })
```

### Multi-line text collapsed to one line
```tsx
// ❌ tooltipPlainText strips newlines
onRender: (item, index, column) => tooltipPlainText({ item, index, column })
// ✅ tooltipNewLine preserves \n
onRender: (item, index, column) => tooltipNewLine({ item, index, column })
```

### Wrong helper for clickable cells
```tsx
// ❌ wraps a div with onClick (poor a11y)
onRender: item => <div onClick={...}>{item.name}</div>
// ✅ semantic Link element
onRender: (item, index, column) => tooltipLinkText({ item, index, column, onItemClick: () => navigate(item.id) })
```

### Date column passing a string
```tsx
// ❌ getDateStr expects a number
onRender: item => tooltipDatePlainText({ item, text: '2026-05-01' })
// ✅ pass numeric timestamp via fieldName
onRender: (item, index, column) => tooltipDatePlainText({ item, index, column })
```

## Checklist

- [ ] Every column's `onRender` uses a helper from `ui-table-column`
- [ ] `item`, `index`, `column` forwarded for value-bound helpers
- [ ] `text` / `content` overrides use `intl.formatMessage` when user-visible
- [ ] Multi-line text columns use `tooltipNewLine`, not `tooltipPlainText`
- [ ] Clickable cells use `tooltipLinkText` / `tooltipJointText` (not raw `<div onClick>`)
- [ ] Date columns store numeric timestamps and use the date helpers
