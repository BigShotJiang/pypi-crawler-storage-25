---
name: api-integration
description: "Use when adding, updating, or reviewing REST API integrations, service files, API models, cross-DC requests, request/download/upload helpers, direct React Hook fetching, or Redux-Saga API usage."
metadata:
  keywords:
    - REST API
    - API integration
    - service file
    - API model
    - crossDCRequest
    - request helper
    - upload
    - download
    - Redux-Saga
    - 接口
    - 服务文件
    - 跨 DC
    - 上传
    - 下载
---

# api-integration

## Overview

Use this as the quick reference for API integration placement and wiring. Start
from the endpoint ownership, inspect nearby service/model patterns, then choose
module vs global placement, normal vs cross-DC request, and direct service calls
by data contract. Do not invent endpoints, model fields, customer/DC routing, or
exports when existing repository code can answer.

When writing implementation code, open the matching template in `templates/` and
adapt it to the surrounding service style.

## Template References

| Template | Use When |
| --- | --- |
| `templates/direct-service-call.template.mdx` | A React page/component fetches data directly through a service call. |
| `templates/module-service.template.mdx` | The endpoint and models are owned by one module. |
| `templates/global-service.template.mdx` | The endpoint or models are shared by `src/api`, legacy pages, shared UI, or platform flows. |
| `templates/cross-dc-service.template.mdx` | The API must call a customer data-center URL through the cross-DC helper. |

## When To Use

- Add, modify, move, or review REST API service methods.
- Create or update request/response model files for API calls.
- Decide whether an API belongs under `src/modules/{module-name}` or `src/api`.
- Decide whether a service method needs `request`, `download`,
  `uploadRequest`, `crossDCRequest`, or `crossDCUploadRequest`.
- Replace or review Redux-Saga usage for normal page/component fetching.

## When Not To Use

Do not use this to redesign backend API contracts, invent response shapes,
change shared routing behavior, add new HTTP libraries, or choose UI loading and
error copy. Use repo i18n and UI skills for user-visible behavior.

## Hard Gates

- Search existing services and models before choosing a new file or export.
- Identify endpoint ownership before choosing module vs global API placement.
- Identify whether a reliable `customerId` is available before using
  cross-DC helpers.
- Stop before changing backend fields, endpoint paths, persisted keys, shared
  exports, or API semantics unless the user explicitly requested that contract
  change.

## Workflow

1. Understand the endpoint, caller, module, request shape, response shape, and
   whether customer/DC routing is required.
2. Inspect nearby services, models, imports, exports, HTTP helper usage, and
   caller data handling.
3. Apply the component matrix and matching template.
4. Preserve API contracts, encode dynamic path segments, update required
   exports, and keep user-visible text in i18n flows.
5. Verify the changed service/model/caller behavior and report checks.

## Component Matrix

| Need / Behavior | Use | Location / Helper | Notes |
| --- | --- | --- | --- |
| Module-owned endpoint | Module service/model | `src/modules/{module-name}/services/{domain}.ts`, `src/modules/{module-name}/models/{domain}.ts` | Use when callers and types stay inside one module. |
| Shared or legacy endpoint | Global service/model | `src/api/services/{domain}.ts`, `src/api/models/{domain}.ts` | Use when shared modules, `src/pages`, shared components, layouts, or platform flows consume it. |
| Normal JSON API | Existing HTTP request helper | Module: `src/api/helpers/http`; global: `@API` or nearby existing style | Follow sibling service imports. |
| File download | `download` | Existing HTTP layer | Keep call shape consistent with nearby download services. |
| File upload | `uploadRequest` | Existing HTTP layer | Use only when request payload is upload/form-data behavior. |
| Customer data-center API | `crossDCRequest` | `src/api/helpers/cross-DC-request` | Use when endpoint operates on customer/tenant data and `customerId` is reliable. |
| Customer data-center upload | `crossDCUploadRequest` | `src/api/helpers/cross-DC-request` | Do not hand-build DC URLs in feature code. |
| Normal component/page fetch | Direct service call in React hooks | Service file plus caller hook/component | Prefer this over Redux-Saga for routine fetching. |
| Global orchestration | Redux-Saga only with justification | Existing saga pattern | Use only for true global cancellation/orchestration or team-approved side effects. |

## Value Shape Rules

- Keep module-owned services/models inside the owning module unless the API is
  shared.
- Keep shared services/models under `src/api` and export them from
  `src/api/index.ts` or `src/api/models/index.ts` only when callers should use
  `@API` or `@API/models`.
- Do not duplicate the same endpoint or model in both module and global scopes.
- Use `data: JSON.stringify(params)` for JSON request bodies when that matches
  the existing HTTP helper pattern.
- Encode dynamic path segments with `encodeURIComponent`.
- For cross-DC calls, pass the relative API path in `url` and HTTP options in
  `requestInitOptions`.
- Let the global HTTP layer handle common failures; check `undefined`, empty, or
  falsey results in callers when the UI must branch.
- Do not wrap service calls in `try/catch` only to show generic user-visible
  errors.
- Do not hardcode user-visible loading, empty, or error strings in API examples
  or call sites.

## Pressure Rules and Red Flags

Stop, inspect, ask, or document an assumption when:

- Endpoint ownership, caller scope, module boundary, or reuse boundary is
  unknown.
- Request body, response model, path params, `customerId`, or data-center
  routing is guessed.
- Nearby services conflict with the generic module/global or normal/cross-DC
  rule.
- A change would rename backend fields, endpoint paths, route params, shared
  exports, persisted keys, or public API models.
- Implementing the request would add Redux-Saga, a new dependency, hand-built DC
  URLs, or broad shared behavior.
- Verification cannot be performed.

## Common Mistakes

- Creating a new service file before checking whether a semantic service already
  exists.
- Putting a module-only endpoint under `src/api` just because an import alias is
  convenient.
- Duplicating global and module models for the same endpoint.
- Using `crossDCRequest` without a reliable `customerId`.
- Moving routine component fetching into Redux-Saga.

## Checklist

### Intake

- [ ] Endpoint, caller, module, request shape, and response shape are known.
- [ ] Customer/DC routing requirement is known or explicitly ruled out.

### Selection

- [ ] Existing services, models, imports, exports, and helper style were
  inspected.
- [ ] Module/global placement and normal/cross-DC helper choice follow the
  matrix.
- [ ] Matching template was opened when implementation code was needed.

### Implementation

- [ ] Service/model changes are minimal and scoped.
- [ ] Required exports and affected imports resolve.
- [ ] Backend contracts, endpoint paths, model fields, and user-visible i18n
  behavior are preserved unless explicitly changed.

### Verification

- [ ] Result matches the request and selected API pattern.
- [ ] Main caller behavior, falsey result handling, and cross-DC path when
  applicable are checked.
- [ ] Tests, type checks, lint checks, or skipped checks are recorded with
  reasons.
