---
name: ui-component-guidelines
description: "Component architecture (3-tier hierarchy, reusability rules) and UI library selection (Allure 1 / Fluent UI 8 priority, import patterns)."
metadata:
  keywords:
    - UI component
    - component architecture
    - Allure
    - Fluent UI
    - shared wrapper
    - component state
    - raw Fluent UI
    - import pattern
    - UI 组件
    - 组件规范
    - 共享封装
    - 样式规范
---

# UI Component Guidelines

## Component Architecture

### 3-Tier Component Hierarchy

```
Page Components (src/pages/)
    ↓ uses
bi-* Components (src/components/bi-*)  [Business Logic]
    ↓ uses
ui-* Components (src/components/ui-*)  [Pure UI, No Business Logic]
```

### ui-* Components
- **Location**: `src/components/ui-*/`
- **Rule**: Zero business logic, only props & callbacks
- **Naming**: Component name uses `UI` prefix (all caps): `UIDropdown`
- **Structure**:
  ```
  ui-dropdown/
  ├── UIDropdown.tsx      # Main component
  ├── index.tsx           # Export
  └── index.module.scss
  ```

### bi-* Components
- **Location**: `src/components/bi-*/`
- **Rule**: Contains domain logic, can call API services
- **Naming**: Component name uses `BI` prefix (all caps): `BIExportReport`
- **Structure**:
  ```
  bi-export-report/
  ├── index.tsx           # Main component: BIExportReport
  ├── Types.ts
  └── index.module.scss
  ```

### Page Components
- **Location**: `src/pages/{feature}/{page-name}/`
- **Rule**: Orchestrates logic, composes ui-*/bi-* components

### Reusability Rule

**Golden Rule**: Used in 2+ pages → Extract to `/components`

❌ Never inline shared logic in multiple pages
✅ Always extract to appropriate component tier

### Avoid Prop Drilling
**Problem**: Props passed through >3 intermediate components that don't use them.

**Solutions**:
- **Use `children` prop** — For layout/wrapper components
- **Use Context API** — For deeply shared state (user, theme, etc.)
- **Use render props** — For flexible component composition

**Decision Rule**: Props pass through >3 layers without being consumed → Refactor with above patterns.

### Extract Complex Logic to Custom Hooks
**Rule**: Component with >50 lines of hook-based logic (`useState` + `useEffect`) → Extract to `src/hooks/Use{Name}.ts`

**Examples**: `UseCustomerData.ts`, `UseDebounce.ts`, `UsePermission.ts`

---

## Overview

This project uses multiple UI libraries with **Project Wrappers** as the primary component source. Understanding the hierarchy and compatibility is critical for consistent development.

**Key Principle**: Always search `src/components/ui-*` first. If no wrapper exists, use Allure 1. Fallback to Fluent UI 8 only when necessary.

---

## Component Library Hierarchy

### Priority Order

```
1. Project Wrappers (src/components/ui-*)                 ← PRIMARY (Customized wrappers)
   ↓ (if not available in wrappers)
2. Allure 1 (@gui/fluent-ui-allure)                       ← SECONDARY (Base library)
   ↓ (if not available in Allure)
3. Fluent UI 8 (@fluentui/react)                          ← FALLBACK
```

---

## Library Details

### 1. Project Wrappers (`src/components/ui-*`) - PRIMARY

**Status**: Custom wrappers ensuring consistent styling and behavior
**Search Paths**:
- Primary: `src/components/ui-*/`

**Import Pattern**:
```typescript
import { UIButton } from '@components/ui-button';
import { UIDropdown } from '@components/ui-dropdown';
```

**When to Use**:
- ✅ ALWAYS check here first
- ✅ Common atoms: `ui-button`, `ui-input`, `ui-dropdown`
- ✅ Specialized components: `ui-datepicker-allure`

**Before Creating New Wrapper**:
1. Search existing: `semantic_search("UIButton component wrapper")`
2. Check if similar wrapper exists
3. Verify need for wrapper (avoid unnecessary abstraction)

---

### 2. Allure 1 (`@gui/fluent-ui-allure`) - SECONDARY

**Based on**: Fluent UI 8
**Status**: Base component library
**Import Pattern**:
```typescript
import { Button, TextField, Dropdown, Dialog } from '@gui/fluent-ui-allure';
```

**When to Use**:
- ✅ Wrapper does not exist
- ✅ Need raw component for custom composition

---

### 3. Fluent UI 8 (`@fluentui/react`) - FALLBACK

**Based on**: Microsoft Fluent UI 8
**Status**: Use only when component missing in Allure 1
**Import Pattern**:
```typescript
import { Persona, DocumentCard } from '@fluentui/react';
```

**When to Use**:
- ✅ Component not available in Allure 1
- ✅ Advanced components (Persona, DocumentCard, etc.)
- ✅ Type imports (only if not available in Allure 1)

**Example - Component Not in Allure 1**:
```typescript
import { Button } from '@gui/fluent-ui-allure'; // ✅ Available in Allure 1
import { Persona } from '@fluentui/react'; // ✅ Not in Allure 1, use Fluent UI 8

const UserProfile: React.FC<{ user: IUser }> = ({ user }) => {
  return (
    <div>
      {/* Persona not in Allure 1 */}
      <Persona
        text={user.name}
        secondaryText={user.role}
        imageUrl={user.avatar}
      />
      <Button text="Edit Profile" primary />
    </div>
  );
};
```

**Type Imports**:
```typescript
// ✅ PREFERRED: Import types from Allure 1 first
import type {
  IDropdownOption,
  IStackTokens,
  ITextFieldStyles,
  IButtonProps
} from '@gui/fluent-ui-allure';

// ⚠️ FALLBACK: Only if type not available in Allure 1
import type { IPersonaProps } from '@fluentui/react';
```

---

## Component Search Workflow

### Step-by-Step Process

**Before using any component:**

1. **Check Project Wrappers FIRST**
   ```
   file_search("src/components/ui-*/**")
   semantic_search("UIButton component")
   ```

2. **Search Existing Codebase**
   ```
   semantic_search("Button component import")
   semantic_search("Dropdown usage example")
   ```

3. **Verify Import Source**
   ```typescript
   // ✅ CORRECT
   import { Button } from '@gui/fluent-ui-allure';
   import { UIButton } from '@components/ui-button';

   // ⚠️ CHECK if Allure 1 has it first
   import { Persona } from '@fluentui/react';

   // ❌ WRONG
   import { Button } from 'unsupported-ui-library';
   ```

---

## Common Component Mappings

### Buttons

```typescript
// ✅ Allure 1 (PRIMARY)
import { Button, IconButton, PrimaryButton } from '@gui/fluent-ui-allure';

<Button text="Click me" />
<PrimaryButton text="Save" />
<IconButton iconProps={{ iconName: 'Edit' }} />

// ✅ Project Wrapper
import { UIButton } from '@components/ui-button';

<UIButton text="Custom Button" primary />
```

### Text Inputs

```typescript
// ✅ Allure 1 (PRIMARY)
import { TextField } from '@gui/fluent-ui-allure';

<TextField
  label="Customer Name"
  required
  onChange={(e, value) => console.log(value)}
/>

// ✅ Project Wrapper
import { UIInput } from '@components/ui-input';

<UIInput label="Email" type="email" />
```

### Dropdowns

```typescript
// ✅ Allure 1 (PRIMARY)
import { Dropdown, ComboBox } from '@gui/fluent-ui-allure';

const options = [
  { key: 'active', text: 'Active' },
  { key: 'inactive', text: 'Inactive' }
];

<Dropdown
  label="Status"
  options={options}
  selectedKey="active"
/>

// ✅ Project Wrapper
import { UIDropdown } from '@components/ui-dropdown';

<UIDropdown label="Status" options={options} />
```

### Dialogs/Modals

```typescript
// ✅ Project Wrapper (PRIMARY) - dialogBox
import {
  DialogBox,
  DialogBoxTitle,
  DialogBoxContent,
  DialogBoxActions
} from '@components/dialogBox';
import { DialogLoading } from '@components/ui-loading';
import { DefaultButton, PrimaryButton } from '@gui/fluent-ui-allure';

// Basic usage
<DialogBox open={isOpen} onClose={onClose} width={480}>
  <DialogBoxTitle title="Confirm Delete" />
  <DialogBoxContent>
    <p>Are you sure?</p>
  </DialogBoxContent>
  <DialogBoxActions>
    <PrimaryButton text="Confirm" onClick={onConfirm} />
    <DefaultButton text="Cancel" onClick={onClose} />
  </DialogBoxActions>
</DialogBox>

// With two loading states (content + full-dialog overlay)
// - isContentLoading: covers only DialogBoxContent (e.g. initial data fetch)
// - isAllLoading: covers the entire dialog including footer (e.g. submit)
<DialogBox open={isOpen} onClose={onClose} width={480}>
  <DialogBoxTitle title="Edit Item" />
  <DialogBoxContent>
    <DialogLoading hasLoading={isContentLoading}  />
    {!isContentLoading && <form>...</form>}
  </DialogBoxContent>
  <DialogBoxActions>
    <PrimaryButton disabled={isContentLoading || isAllLoading} onClick={onSubmit} />
    <DefaultButton disabled={isContentLoading || isAllLoading} onClick={onClose} />
  </DialogBoxActions>
  {/* Full-dialog overlay — place AFTER DialogBoxActions */}
  <DialogLoading hasLoading={isAllLoading} finalLoading={isAllLoading}/>
</DialogBox>
```

### Data Tables

```typescript
// ✅ Allure 1 (PRIMARY)
import { DetailsList, DetailsListLayoutMode } from '@gui/fluent-ui-allure';

const columns = [
  { key: 'name', name: 'Name', fieldName: 'name', minWidth: 100 },
  { key: 'email', name: 'Email', fieldName: 'email', minWidth: 150 }
];

<DetailsList
  items={customers}
  columns={columns}
  layoutMode={DetailsListLayoutMode.justified}
/>
```

### Loading States

```typescript
// ✅ Allure 1 (PRIMARY)
import { Spinner, ProgressIndicator } from '@gui/fluent-ui-allure';

<Spinner label="Loading customers..." />

<ProgressIndicator
  label="Processing"
  percentComplete={0.5}
/>

// ✅ Project Wrapper
import { UILoading } from '@components/ui-loading';

<UILoading />
```

---

## Version Compatibility Matrix

| Library | Fluent UI Version | Status | Use in New Code |
|---------|------------------|--------|-----------------|
| Allure 1 | 8.x | ✅ Active | **YES** (Primary) |
| Fluent UI 8 | 8.x | ✅ Stable | YES (Fallback) |
| components | 8.x based | ✅ Active | YES (If exists) |

---

## Styling Components

### Using Fluent UI 8 Styling APIs

```typescript
import { Button } from '@gui/fluent-ui-allure';
import type { IButtonStyles } from '@gui/fluent-ui-allure';

const buttonStyles: IButtonStyles = {
  root: {
    backgroundColor: '#0078d4',
    borderRadius: '4px'
  },
  rootHovered: {
    backgroundColor: '#106ebe'
  }
};

<Button text="Styled Button" styles={buttonStyles} />
```

### Using CSS Modules

```typescript
import { Button } from '@gui/fluent-ui-allure';
import Styles from './index.module.scss';

<div className={Styles.customerActions}>
  <Button text="Action" />
</div>
```

---

## Common Mistakes

### ❌ Mistake 1: Using Unsupported UI Libraries

```typescript
// ❌ WRONG: Unsupported library
import { Button } from 'unsupported-ui-library';

// ✅ CORRECT: Fluent UI 8
import { Button } from '@gui/fluent-ui-allure';
import { Button } from '@fluentui/react'; // Only if not in Allure 1
```

### ❌ Mistake 2: Mixing Supported and Unsupported UI Libraries

```typescript
// ❌ WRONG: Mixing supported and unsupported imports
import { Button } from '@gui/fluent-ui-allure'; // Fluent UI 8
import { Dialog } from 'unsupported-ui-library';

// ✅ CORRECT: Stay inside the supported stack
import { Button, Dialog } from '@gui/fluent-ui-allure';
```

### ❌ Mistake 3: Skipping Search

```typescript
// ❌ WRONG: Creating new component without checking
const MyButton = () => <button>Click</button>;

// ✅ CORRECT: Search first, reuse if exists
// 1. semantic_search("Button component ui-button")
// 2. Found UIButton in src/components/ui-button
import { UIButton } from '@components/ui-button';
```

---

## Quick Reference

### Import Cheat Sheet

```typescript
// ✅ PRIMARY: Project Wrappers (ALWAYS CHECK FIRST)
import { UIButton } from '@components/ui-button';
import { UIDropdown } from '@components/ui-dropdown';
import { UIInput } from '@components/ui-input';

// ✅ SECONDARY: Allure 1 (if no wrapper exists)
import {
  Button,
  TextField,
  Dropdown,
  Dialog,
  DatePicker,
  DetailsList,
  Spinner
} from '@gui/fluent-ui-allure';

// ✅ FALLBACK: Fluent UI 8 (for components not in Allure 1)
import { Persona, DocumentCard } from '@fluentui/react';

// ✅ TYPES: Prefer Allure 1 first
import type {
  IDropdownOption,
  IStackTokens,
  IButtonStyles
} from '@gui/fluent-ui-allure';

// ⚠️ TYPES FALLBACK: Only if not in Allure 1
import type { IPersonaProps } from '@fluentui/react';

// ❌ FORBIDDEN: unsupported UI library
import { Button } from 'unsupported-ui-library';
```

---

## Checklist

Before using any UI component:

- [ ] **Checked Project Wrappers FIRST** - `file_search("src/components/ui-*")`
- [ ] **Searched existing usage** - `semantic_search("ComponentName")`
- [ ] **Verified Allure 1 availability** - Check Allure 1 exports if no wrapper
- [ ] **Used correct import** - Wrappers → `@gui/fluent-ui-allure` / `@fluentui/react` only
- [ ] **Avoided unsupported UI libraries** - Stay inside the approved stack
- [ ] **Followed hierarchy** - Wrappers → Allure 1 → Fluent UI 8

**Remember**: When in doubt, search first! Most components already have established patterns in the codebase.
