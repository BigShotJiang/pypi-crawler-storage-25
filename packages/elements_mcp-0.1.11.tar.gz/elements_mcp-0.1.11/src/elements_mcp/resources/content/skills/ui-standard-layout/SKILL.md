---
name: ui-standard-layout
description: "Use when creating, modifying, or debugging pages that use UIStandardLayout, common layout breadcrumbs, top action buttons, changeProcessor, customer license gating, NewUILayoutContext, or topBarLeftNode."
metadata:
  keywords:
    - UIStandardLayout
    - standard layout
    - page layout
    - breadcrumb
    - top action button
    - top right button
    - delete button
    - changeProcessor
    - NewUILayoutContext
    - topBarLeftNode
    - 标准布局
    - 右上角
    - 右上角按钮
    - 顶部操作按钮
    - 删除按钮
---

# ui-standard-layout - Page Layout Quick Guide

`UIStandardLayout` is the standard shell for new-style pages. It is provided by
`@components/ui-standard-layout` and follows the existing Allure 1 / Fluent UI 8
direction. Do **not** replace it with ad-hoc page containers.

- **Code templates**: use the focused files in `templates/`:
  - Page shell and body variants: [page-shell.template.mdx](./templates/page-shell.template.mdx)
  - License-gated pages and module layout: [license-gated-layout.template.mdx](./templates/license-gated-layout.template.mdx)
  - Pending changes: [change-processor.template.mdx](./templates/change-processor.template.mdx)
- **Table content**: use [ui-table-column-filter](../ui-table-column-filter/SKILL.md) when the layout body contains `UITableColumnFilter`

## When to Use

Use `UIStandardLayout` when a page needs the common page frame: breadcrumb,
top actions, scroll container, optional pending-change apply button, or customer
license gating.

Do not use it for:

- Small inline components inside an existing page body
- Standalone drawer content that already receives its page shell from a parent
- Legacy pages that intentionally use a different layout system

## Decision Tree

```
Need a full page shell?
  - Basic page, header actions, table body, or mixed content -> templates/page-shell.template.mdx
  - Tenant/customer license check, out-of-policy message, or topBarLeftNode -> templates/license-gated-layout.template.mdx
  - Detail/edit page with pending changes -> templates/change-processor.template.mdx

Need table content inside the body?
  - Use UIStandardLayout for the shell
  - Use UITableColumnFilter inside DataGridContainer
  - If the body has content besides the table, wrap only the table with DataGridContainer
```

## Layout Flow

`UIStandardLayout` owns page chrome. Consumers own business content.

```
UIStandardLayout
  1. optionally checks customer license/general info
  2. renders header shimmer while the check is pending
  3. renders breadcrumb + top actions only when licensed
  4. provides NewUILayoutContext
  5. renders children inside ScrollContainer
```

Important behavior:

- `checkCustomerLicenseFunction` makes `showLoading` true until it resolves.
- During loading, `children` still render inside `ScrollContainer`; the header is shimmered.
- When the customer has no license and `customerNoLicenseElement` is provided, the no-license element replaces `children`.
- `outOfPolicyMessageElement`, breadcrumb, top actions, ellipsis actions, and `changeProcessor` render only after the license check passes.
- `topBarLeftNode` updates the global top nav only after the license check passes and is cleaned up on unmount.

## Body Layout Rules

1. `UIStandardLayout` already wraps `children` with `ScrollContainer`; do not add another
   `ScrollContainer` inside it.
2. `DataGridContainer` is for table areas only.
3. For table-only pages, `DataGridContainer` can be the direct child of `UIStandardLayout`.
4. For mixed pages, pass the page body directly to `UIStandardLayout` and wrap only the table with
   `DataGridContainer`.

## License Gate Rules

1. Use inline `checkCustomerLicenseFunction` for a one-off page; reuse an existing license-gated module layout when the module has one; create a new wrapper only when many pages share the same check and no wrapper exists.
2. Return at least `{ hasLicense, licenses }` from `checkCustomerLicenseFunction`.
3. If child tabs/tables should not behave as loaded before the check finishes, keep local `hasLicense` state or module context and pass loading props such as `displayItemLoading={!hasLicense}`.
4. Pass `customerNoLicenseElement` when a tenant/customer view needs a fallback page.
5. Pass `outOfPolicyMessageElement` only for licensed pages that need policy warnings.
6. For module-specific extra context (tenant status, last updated time, loading state), use a module context/wrapper; `NewUILayoutContext` is only the shared layout context.
7. Child components using `useNewUILayoutContext()` must render under `UIStandardLayout`.

## Header Rules

1. Use `breadcrumb.items` from `EBreadcrumbLinkType`; do not build breadcrumb labels manually.
2. Breadcrumb items may be memoized and may include `{ link, onClick }` entries when navigation depends on route state.
3. Use `topActionButtonsElement` for custom action groups and permission-aware buttons.
4. Use `topLeftButtonElement` only when the page has `IContextualMenuProps` actions that should render as DefaultButtons beside top actions.
5. Use `topEllipsisActionButtons` for secondary menu actions.
6. Use `topBarLeftNode` for global top-nav status content; memoize it with `useCallback` and return `undefined` when the data/license is not ready.
7. Use `changeProcessor` for unsaved-change apply behavior, not a custom header button.
8. Use `intl.formatMessage()` / module `getMessage()` for all user-visible strings.

## Common Mistakes

### Hardcoded action text
```tsx
// Wrong
<PrimaryButton text="Add" />

// Right
<PrimaryButton text={intl.formatMessage({ id: '{{I18N_ADD_KEY}}' })} />
```

### Repeating license checks on every page
```tsx
// Wrong: duplicate the same check in each page
<UIStandardLayout checkCustomerLicenseFunction={checkGeneralInfo}>
  {children}
</UIStandardLayout>

// Right: create a module-specific wrapper once
<ModuleStandardLayout getGeneralInfo={getGeneralInfo}>
  {children}
</ModuleStandardLayout>
```

### Treating children as blocked during license loading
```tsx
// Wrong: child content assumes license is ready just because UIStandardLayout is checking
<UIStandardLayout checkCustomerLicenseFunction={checkLicense}>
  <UIMenuTab tabItems={tabItems} />
</UIStandardLayout>

// Right: explicitly pass loading/license state to children that need it
<UIStandardLayout checkCustomerLicenseFunction={() => checkLicense(setHasLicense)}>
  <UIMenuTab tabItems={tabItems} displayItemLoading={!hasLicense} />
</UIStandardLayout>
```

### Reading layout context outside the provider
```tsx
// Wrong: this throws if no UIStandardLayout is above it
const { hasLicense } = useNewUILayoutContext();

// Right: call it only in descendants of UIStandardLayout
<UIStandardLayout>{children}</UIStandardLayout>
```

## Checklist

- [ ] Page shell uses `UIStandardLayout` or a module wrapper built on it
- [ ] Breadcrumb uses `EBreadcrumbLinkType` entries
- [ ] Main content is passed as `children`; `UIStandardLayout` supplies `ScrollContainer`
- [ ] `DataGridContainer` wraps only table content, not the entire mixed page body
- [ ] Top action labels use `intl.formatMessage()`
- [ ] Secondary actions use `topEllipsisActionButtons`
- [ ] `topBarLeftNode` is stable and returns `undefined` until license/data is ready
- [ ] Pending edit/detail pages use `changeProcessor`
- [ ] Repeated license/general-info logic is wrapped in a module-specific layout; one-off pages can pass `checkCustomerLicenseFunction` inline
- [ ] Children that depend on license state receive explicit loading/license props
- [ ] No-license tenant pages pass `customerNoLicenseElement`
- [ ] Policy warning pages pass `outOfPolicyMessageElement`
- [ ] Context consumers use `useNewUILayoutContext()` only under the provider
