---
name: page-structure
description: "Use when creating, reorganizing, modifying, or reviewing React/TypeScript pages, routes, page folders, page-local components, hooks, utilities, styles, exports, or i18n placement in page-based modules."
metadata:
  keywords:
    - page structure
    - independent page
    - independently accessible page
    - accessible page
    - route page
    - page folder
    - page component
    - page-local hook
    - page export
    - 独立可访问
    - 独立页面
    - 可访问页面
    - 页面结构
    - 页面目录
    - 路由页面
---

# page-structure

## Overview

Use this as the page ownership and folder-structure reference. Start from the
user goal, inspect nearby repository patterns, then place files by ownership,
reuse, and contract. Do not invent paths, routes, exports, fields, CSS classes,
or i18n keys.

**Required companion:** use `naming-conventions` for files, folders, symbols,
CSS classes, and i18n keys.

## When To Use

- Creating a new route-level page, page folder, page entry, or page component.
- Moving code between a page, page-local component, shared component, hook, or
  utility.
- Adding or reviewing `components/`, `hooks/`, `utils/`, `Types.ts`,
  `Constants.ts`, `index.tsx`, or `index.module.scss`.
- Deciding whether code belongs page-local, feature-local, or shared.

## When Not To Use

Do not use this for naming-only work, backend/API contract changes, or shared
UI component behavior unless page placement is part of the task.

## Hard Gates

- Inspect sibling pages, route registrations, imports/exports, nearby folders,
  shared usages, i18n key prefixes, styles, and tests before choosing a
  structure.
- Stop before guessing a path, route, export, CSS class, field, state name, or
  i18n key.
- Stop before changing routes, exports, API/model contracts, storage,
  telemetry, or shared behavior unless the user explicitly requested that
  contract change.
- When creating a page, moving files, changing exports/routes, or changing a
  reuse boundary, summarize the target, selected location, ownership, nearby
  pattern, contract impact, and assumptions before editing.

## Workflow

1. Understand the target page, feature, task type, and reuse boundary.
2. Inspect sibling page structure, route wiring, imports, exports, styles,
   i18n keys, and tests.
3. Apply the placement matrix or a more specific nearby pattern.
4. Preserve contracts and update affected references.
5. Verify placement, naming, imports, exports, routes, styles, i18n, and the
   main affected behavior.

## Component Matrix

| Need / Behavior | Rule | Location / Example |
| --- | --- | --- |
| New route-level page | Create a page folder that matches sibling route/export patterns. | `src/pages/{feature}/{page-name}/` |
| Small page-only visual unit | Use one flat component file. | `components/{Component}.tsx` |
| Complex page-only unit | Use a component folder when it owns styles, hooks, utils, types, constants, or child components. | `components/{component-name}/` |
| Page-owned React logic | Put it in a page hook file and export a `useName` hook. | `hooks/Use{Name}.ts` |
| Page-owned pure helper | Put it in page utilities with no React state or hidden contract changes. | `utils/{Name}.ts` |
| Page UI types | Put UI-only types in the page types file. | `Types.ts` |
| Page constants/field names | Put non-display constants in the page constants file. | `Constants.ts` |
| Scoped page styles | Use a CSS module imported as `Styles`; classes are `lowerCamelCase`. | `index.module.scss` |
| Reused by multiple pages/features | Move to an existing shared folder only when actual reuse and shared contracts are clear. | Existing shared location |

Use this layout for new page folders only when nearby code does not show a more
specific pattern:

```text
src/pages/{feature}/{page-name}/
|-- components/
|   |-- ComponentA.tsx
|   `-- component-b/
|       |-- components/
|       |-- hooks/
|       |-- utils/
|       |-- index.tsx
|       |-- Types.ts
|       |-- Constants.ts
|       `-- index.module.scss
|-- hooks/
|-- utils/
|-- index.tsx
|-- Types.ts
|-- Constants.ts
`-- index.module.scss
```

## Value Shape Rules

- Keep page-local code page-local until real reuse requires a shared location.
- Preserve backend fields, route paths, persisted keys, telemetry names, API
  contracts, and public exports unless the user explicitly requests a contract
  change.
- Keep display text, labels, placeholders, tooltips, errors, empty states, and
  button text in repo i18n patterns.
- Do not add dependencies, wrapper folders, barrel exports, or broad
  abstractions for a page-structure change.
- Do not choose a structure by name similarity alone; choose by behavior,
  ownership, reuse, data contracts, and local repository patterns.

## Pressure Rules and Red Flags

Stop, inspect, ask, or document an assumption when:

- target page, feature, route, or reuse scope is unknown
- a path, route, export, CSS class, field, state name, or i18n key would be
  guessed
- nearby code conflicts with the canonical layout
- page-local work starts touching shared or module-wide behavior
- code is moved to shared folders for possible future reuse only
- an API/model contract would be renamed to fit UI naming
- user-visible text would be hardcoded
- verification cannot be performed

## Common Mistakes

- Applying the canonical layout without checking sibling pages first.
- Creating nested component folders for components that only need one `.tsx`.
- Adding `Types.ts` or `Constants.ts` for one trivial item when nearby code
  keeps that item inline.
- Re-exporting everything from `index.tsx` and expanding the public surface.
- Renaming API fields, route params, storage keys, or telemetry values to match
  UI naming rules.

## Checklist

### Intake

- [ ] Target page, feature, task type, and reuse boundary are known.

### Selection

- [ ] Sibling page patterns and affected references were inspected.
- [ ] Placement follows the matrix or a more specific nearby pattern.

### Implementation

- [ ] Imports, exports, route references, styles, and i18n references resolve.
- [ ] Shared behavior and external contracts are preserved unless explicitly
  changed.

### Verification

- [ ] Result matches the request.
- [ ] Naming follows `naming-conventions`.
- [ ] Main user flow or affected behavior is checked when applicable.
- [ ] Checks run or skipped checks are recorded with reasons.
