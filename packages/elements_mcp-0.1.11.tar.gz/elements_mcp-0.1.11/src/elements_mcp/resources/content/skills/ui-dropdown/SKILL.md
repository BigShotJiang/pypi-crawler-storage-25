---
name: ui-dropdown
description: "Use when creating, modifying, debugging, replacing, or reviewing @components/ui-dropdown usages, dropdown component selection, UIDropDownBase, single-select search, API-loaded dropdowns, remote API search dropdowns, multi-select dropdowns, select-all behavior, dropdown footer actions, or dropdown i18n/value wiring."
metadata:
  keywords:
    - dropdown
    - ui-dropdown
    - UIDropDownBase
    - single select
    - multi select
    - remote search dropdown
    - API-loaded dropdown
    - select all
    - dropdown footer
    - 下拉框
    - 单选下拉
    - 多选下拉
    - 远程搜索
---

# ui-dropdown - Dropdown Component Quick Guide

`ui-dropdown` is a set of scenario-specific wrappers around Allure / Fluent UI
`Dropdown`. Start from the request template, inspect only the approved facts,
then pick the component by behavior and wire value shape, option source, search,
footer, and i18n consistently.

- **Request input**: start from [request-input.template.yaml](./templates/request-input.template.yaml).
- **Component selection**: use [component-selection.template.mdx](./templates/component-selection.template.mdx).
- **Single select**: use [single-select.template.mdx](./templates/single-select.template.mdx).
- **Multi select**: use [multi-select.template.mdx](./templates/multi-select.template.mdx).
- **API loading / remote search**: use [api-loading.template.mdx](./templates/api-loading.template.mdx).
- **Footer actions**: use [option-action.template.mdx](./templates/option-action.template.mdx).

## When to Use

Use this skill for any request that creates, modifies, debugs, replaces, or
reviews a shared dropdown from `@components/ui-dropdown`, including incorrect
value shape, search behavior, API loading, select-all behavior, footer actions,
or i18n/value wiring.

Do not use this skill for:
- LvForm wrapper components unless the task is about the underlying dropdown.
- ComboBox scroll/tag components.
- Dynamic schema-driven forms; use `dynamic-field-renderer` for those.

## Hard Gates

<HARD-GATE>
For every dropdown request, the first user-facing output after loading this skill
MUST be the exact contents of `request-input.template.yaml` for the user to
review. Copy the YAML verbatim, including comments, example values, inline
comments, and blank lines. Do not rewrite example values as `~`, do not
complete unknown fields, and do not shorten or remove template comments. This
applies to create, modify, debug, replace, and review requests.

After sending the YAML draft, STOP. Do not inspect page code, select a component,
read implementation templates, write code, or provide a Dropdown Summary.

Continue only after the user sends back edited YAML or explicitly approves the
YAML draft.
</HARD-GATE>

<HARD-GATE>
Before writing dropdown code, the agent MUST provide a Dropdown Summary and wait
for the user to approve, edit, or restart.
</HARD-GATE>

## Workflow

### 1. Template Intake

1. Send a `Request Input YAML` block by copying
   `templates/request-input.template.yaml` exactly as it appears on disk.
   Preserve every comment, example value, inline comment, and blank line.
2. Do not ask the user to choose internal component names, data source labels,
   state names, callback prop names, or wrapper internals.
3. Do not adapt the template to the current request before the user reviews it.
   The user owns the first edit from example values to real values or `~`.
4. If the user returns edited YAML with unknown non-i18n fields, keep those
   unknowns as `~` and make them visible before component selection or
   implementation.
5. `*_i18n_key` fields are optional intake fields: use the value when the user
   provides it, and leave it blank when they do not.
6. Send only:
   - a short sentence asking the user to edit or confirm the YAML
   - the YAML block
7. Wait for the user's returned YAML or explicit approval.

### 2. Template-Driven Inspect

After YAML approval, inspect only what the YAML points to:

1. If `usage.page_path` is provided, search for it first. If it exists, read
   and use it. If it does not exist, create it with the default page behavior
   from the approved YAML.
2. If `usage.page_path` is blank, search for an existing page or component that
   matches the request context. If none exists, choose a conventional page path
   and create it with the default page behavior from the approved YAML.
3. Use `data.provided_by` to inspect either local options or API-backed options.
4. Use `existing_code` to find selected value state, disabled logic, error
   message expressions, and custom renderers.
5. Use provided i18n fields to verify localization keys. Blank `*_i18n_key`
   values mean the user did not provide a key; keep them blank in the intake
   facts instead of inventing IDs.

Do not invent option keys, API functions, i18n IDs, state variables, value
shapes, callback names, or disabled/error expressions. If required facts are
still unknown, update the YAML or ask before selecting a component.

### 3. Component Selection

Map the approved YAML and inspected facts to exactly one dropdown component from
`component-selection.template.mdx`.

Search mode comes from the option source:
- direct options search against the local option data
- API-backed options call the API function for search

Do not add separate minimum-character search flags unless the selected component
API explicitly supports them. Do not add flags to make one component imitate
another.

### 4. Dropdown Summary Gate

Confirm the generated summary before writing code:

```text
Dropdown Summary
Path:        src/pages/example-feature/index.tsx
Component:   ExampleDropdown
Value:       selectedKeys: string[]
Options:     local IDropdownOption[]
Search:      local text filter
Actions:     Apply/Cancel, select all
I18n:        label, placeholder, option text, footer text use intl/getMessage
Proceed? [Yes / Edit / Start over]
```

Continue only after the user approves the summary.

### 5. Implement and Verify

Use the matching template and keep state close to the page or form section that
owns the value. Verify value shape, search mode, API loading, Apply semantics,
select-all behavior, footer actions, and i18n before declaring the dropdown done.

## Component Matrix

| Need | Component | Import |
| --- | --- | --- |
| Plain single select | `UIDropDownBase` | `@components/ui-dropdown/base` |
| Single select with local search | `UIDropDownSingleSelectionSearch` | `@components/ui-dropdown/single-selection-search` |
| Single select that loads data when opened | `UIDropDownSingleSelectionSearchApi` | `@components/ui-dropdown/single-select-api-search` |
| Multi-select local options with Apply/Cancel | `UIDropDownMultiSelect` | `@components/ui-dropdown/multi-select` |
| Multi-select that loads data when opened | `UIDropDownMultiSelectAPISearch` | `@components/ui-dropdown/multi-select-api-search` |
| Single select plus create/manage footer actions | `UIDropDownWithOptionAction` | `@components/ui-dropdown/option-action` |

## Value Shape Rules

| Component | Value prop | Callback |
| --- | --- | --- |
| Single select components | `selectedKey` as `string | number` | `onChange(_, option)` |
| `UIDropDownWithOptionAction` | `selectedKey` as `string | number` | `onChange(_, option)` |
| `UIDropDownMultiSelect` | `selectedKeys` as `string[] | number[]` | `callback(options)` after Apply |
| `UIDropDownMultiSelectAPISearch` | `selectedKeys` as `string[] | number[]` | `callback(options)` after Apply, or immediately when custom footer is used |

## Critical Rules

1. **Template first**: every dropdown request starts with
   `request-input.template.yaml`.
2. **I18n intake optional**: `*_i18n_key` values are user-provided hints. Use
   them when present, and leave them blank when absent.
3. **I18n only in code**: labels, placeholders, option text, footer text, and
   error messages must use repo i18n helpers.
4. **Choose by behavior**: do not add flags to make one component imitate another.
5. **Use the correct value shape**: single select owns one key; multi-select owns
   an array of keys.
6. **Multi-select Apply semantics**: `callback` receives applied options, not
   every checkbox click, unless custom footer behavior says otherwise.
7. **Select all and max count conflict**: in `UIDropDownMultiSelect`,
   `maxSelectedCount` suppresses select-all rendering.
8. **Footer action priority**: `option-action` uses `onClick` before `targetURL`.
9. **Preserve selected remote option**: with remote search, keep `selectedKey`
   aligned with the `keyFieldName` result.

## Pressure Rules and Red Flags

If any red flag appears, STOP and return to the required gate:

- The user says "just write it", "quick fix", "small change", or "debug this"
  before approving request YAML.
- The agent starts reading TSX/API/i18n files before the request YAML is
  approved.
- The agent sends a Dropdown Summary before the request YAML is approved.
- The agent fills missing API names, i18n IDs, option fields, state variables, or
  value shapes from guesses. Missing `*_i18n_key` intake values must stay blank.
- The agent changes the first intake YAML instead of copying
  `request-input.template.yaml` verbatim.
- The agent strips all template comments from the request YAML, making it harder
  for the user to review required choices.
- The agent uses `selectedKey` or `onChange` for multi-select.
- The agent uses `selectedKeys` for single-select.
- The agent treats API-backed search as local filtering or local options as API
  search.
- The agent writes hardcoded user-visible labels, placeholders, footer text, or
  error messages.

## Common Mistakes

### Skipping request YAML review

If the user has not reviewed `request-input.template.yaml`, STOP and send the
request YAML first.

### Inspecting without template approval

Do not read page code, API functions, or i18n files until the approved YAML tells
you what to inspect.

### Hardcoded user-visible strings

```tsx
// Wrong
label="Customer"
searchBoxPlaceholder="Search customer"

// Right
label={intl.formatMessage({ id: '{{LABEL_I18N}}' })}
searchBoxPlaceholder={intl.formatMessage({ id: '{{SEARCH_PLACEHOLDER_I18N}}' })}
```

### Multi-select wired like single select

```tsx
// Wrong
<UIDropDownMultiSelect selectedKey={selectedCustomer} onChange={handleChange} />

// Right
<UIDropDownMultiSelect
  selectedKeys={selectedCustomerKeys}
  callback={options => setSelectedCustomerKeys(options.map(option => option.key.toString()))}
/>
```

## Checklist

### Intake checklist

- [ ] The exact `request-input.template.yaml` contents were sent before any inspection.
- [ ] The user explicitly approved or edited the request YAML.
- [ ] The first intake YAML preserved every comment, example value, inline comment, and blank line.
- [ ] User-edited unknown non-i18n fields remain visible as `~` instead of invented values.
- [ ] User-edited blank `*_i18n_key` fields remain blank instead of invented values.

### Selection checklist

- [ ] `usage.page_path` was searched first; existing matches were read and missing paths were created with default behavior.
- [ ] Inspection followed `usage.page_path`, `data`, and `existing_code` from the approved YAML.
- [ ] Dropdown component matches the requested behavior.
- [ ] Existing page state uses `selectedKey` for single select or `selectedKeys` for multi-select.
- [ ] `IDropdownOption[]` keys are stable and unique.

### Implementation checklist

- [ ] Labels, placeholders, option text, footer text, and error messages use i18n.
- [ ] Search behavior follows the option source: direct searches local options; API-backed searches call the API function.
- [ ] Local search components use `isHasSearchOption` and `searchBoxPlaceholder`.
- [ ] API-loading components receive `getDataFunction` and caller-owned option state.
- [ ] Multi-select components use `callback`, not `onChange`, for applied values.
- [ ] Select-all, default-select-all, and max-count behavior is intentional.
- [ ] Footer action rows use stable keys and localized text.

### Verification checklist

- [ ] Dropdown Summary was approved before writing code.
- [ ] Value prop and callback match the selected component.
- [ ] No user-visible string is hardcoded.
- [ ] API/search behavior matches the approved YAML and inspected facts.
