---
name: dialog-box
description: Use when creating, modifying, debugging, migrating, or reviewing UI-Backup modal dialog flows that use @components/dialogBox, DialogBoxTitle/renderTitle, DialogBoxContent, DialogBoxActions, DialogLoading, controlled close behavior, sizing, i18n, accessibility, or Allure/Fluent UI 8 dialog conventions.
metadata:
  keywords:
    - dialog
    - modal
    - DialogBox
    - DialogBoxTitle
    - DialogBoxContent
    - DialogBoxActions
    - DialogLoading
    - controlled close
    - 弹窗
    - 模态框
    - 对话框
    - 关闭弹窗
---

# Dialog Box

## Overview

Build modal dialog code around the shared `@components/dialogBox` shell. The shared components own modal structure, title accessibility, content scrolling, actions, sizing hooks, and close dispatch. The consuming page or module owns data, permissions, validation, submit side effects, message feedback, cleanup, and API errors.

Use repository facts before choosing a pattern. Do not invent paths, i18n keys, state names, callbacks, API shapes, or unsupported component props.

## Template References

Use templates as optional references after intake and local inspection. Skip them
for tiny edits where nearby code already shows the right dialog pattern.

Use one template only when it saves time for the current workflow:

| Template | Use |
| --- | --- |
| `templates/basic-controlled-dialog.template.mdx` | Simple controlled dialog without submit side effects, loading, or message feedback. |
| `templates/loading-dialog.template.mdx` | Dialog with submit loading, content loading, `DialogLoading`, or `useDisplayMessageBar` feedback. |
| `templates/custom-title.template.mdx` | Dialog title needs custom heading markup or title-side status content. |

Templates are examples, not authority. Align imports, terms, button labels,
state names, callbacks, and behavior with nearby code.

## When To Use

- The task creates, fixes, migrates, or reviews a modal dialog that imports from `@components/dialogBox`.
- The task touches `DialogBox`, `DialogBoxTitle`, `DialogBoxTitleSlot`, `DialogBoxContent`, `DialogBoxActions`, or `DialogLoading`.
- The task involves dialog close behavior, submit loading, content loading, footer disabling, custom title markup, width/height, accessibility, or i18n.
- The task replaces older modal code with the shared dialog shell.

## When Not To Use

- The UI is a drawer, panel, popover, callout, dropdown, page section, or non-modal workflow.
- The caller intentionally uses another existing dialog abstraction such as a module-specific confirm popup or alert dialog, and the task does not ask for migration.
- The request is only about the business API or form fields and does not change dialog composition, behavior, or shell wiring.

## Hard Gates

### Gate 1: Intake

Before implementation, identify:

- target file, module, and dialog purpose
- task type: create, modify, debug, migrate, or review
- expected open, close, cancel, submit success, submit failure, and cleanup behavior
- loading model: none, content-only, submit-only, or full-dialog blocking
- source of user-visible text: `terms`, `getMessage`, `intl.formatMessage`, or existing module helper
- permissions, validation, and side effects that the caller must preserve

If any required behavior cannot be inferred from nearby code or the user request, ask a focused question or document an explicit assumption before editing.

### Gate 2: Existing Context Inspection

Before choosing a pattern or writing code, inspect relevant local examples:

- nearby dialogs in the same module or feature
- `src/components/dialogBox/README.md` or component source when prop behavior is uncertain
- existing i18n message keys and helper style
- existing loading, error, permission, and callback naming
- tests or manual verification patterns for the touched module

### Gate 3: Decision Summary Before Implementation

For migrations, new dialogs, custom title markup, async submit flows, or fragile close/cleanup wiring, produce a concise decision summary before editing or keep the same facts explicit in your reasoning:

```text
Decision Summary
Target:      <file/component>
Goal:        <dialog behavior>
Pattern:     <basic | loading | custom-title | existing module pattern>
Text source: <terms | getMessage | intl.formatMessage | existing helper>
Loading:     <none | content | submit | full dialog>
Close path:  <one idempotent handler and cleanup>
Risks:       <unknowns or assumptions>
```

Small low-risk edits may proceed without asking for confirmation, but the decision must still be grounded in inspected code.

### Gate 4: Verification Before Completion

Before reporting completion, verify the main dialog states that are relevant to the change: open, close, title close, cancel, submit success, submit failure, validation or error display, loading, permissions, cleanup, i18n, and accessibility.

## Workflow

1. Understand the requested behavior and classify the dialog workflow.
2. Inspect nearby code and shared dialog documentation or source as needed.
3. Select the smallest matching pattern: keep existing abstraction, basic controlled dialog, loading dialog, custom title, or migration to `@components/dialogBox`.
4. Implement minimal scoped changes using existing imports, terms, callbacks, state naming, and Allure/Fluent UI 8 conventions.
5. Verify the checklist and report checks run plus any unchecked risk.

## Component Matrix

| Need / Behavior | Use | Notes |
| --- | --- |
| Normal modal shell | `DialogBox` with controlled `open` and `onClose` | Caller owns state and side effects. |
| Normal heading | `DialogBoxTitle title={...}` | Prefer this unless custom title markup is required. |
| Custom heading markup | `DialogBoxTitle renderTitle={titleId => ...}` | Apply `id={titleId}` to the rendered heading. |
| Title-side badge/status | `DialogBoxTitleSlot` inside `DialogBoxTitle` | Keep title semantics owned by `DialogBoxTitle`. |
| Body content, validation, warnings, body-only loading | `DialogBoxContent` | Keep validation and errors in the content region. |
| Footer buttons | `DialogBoxActions` | Match nearby button order and button types. |
| Disable the whole footer during blocking submit | `DialogBoxActions disabled={isBusy}` | Verify custom action children accept `disabled`. |
| Full-dialog blocking overlay | `DialogLoading` after `DialogBoxActions` | Use when the whole dialog should be blocked. |
| Body-only loading overlay | `DialogLoading` inside `DialogBoxContent` | Use when footer actions should stay available. |
| Stable scroll region or wizard-like layout | Explicit `height`, `maxHeight`, or full-height state | Otherwise prefer width with content-driven height. |

## Value Shape Rules

For dialog work, value shape means the composition order, controlled open/close
contract, loading scope, i18n source, and accessibility contract.

- Compose in this order unless existing code proves a local exception: `DialogBox`, `DialogBoxTitle`, `DialogBoxContent`, `DialogBoxActions`, optional full-dialog `DialogLoading`.
- Keep `open` controlled by the caller.
- Route modal dismiss, title close, cancel, and post-success cleanup through one idempotent close handler when they should share behavior.
- Do not hide the title close button unless the dialog is an intentional blocking decision.
- Keep validation and error messages visible in `DialogBoxContent`.
- Use existing module i18n patterns. Do not add hardcoded user-visible strings, placeholder carets, or guessed message keys.
- Reuse existing message keys before adding new ones.
- Preserve `renderTitle` accessibility: the provided ID must be applied to the rendered heading.
- Prefer fixed `width` and content-driven height for normal dialogs. Add `height`, `maxHeight`, or full-height states only when the body needs predictable internal scrolling.
- Match nearby Allure 1 / Fluent UI 8 spacing, size, button order, and button types.

## Pressure Rules and Red Flags

Pressure does not bypass intake, inspection, or verification. Stop to inspect, ask, or state an assumption when:

- target file, module, or dialog abstraction is unknown
- expected close, cancel, submit, or cleanup behavior is unclear
- loading scope is unclear
- i18n helper or message key pattern is unknown
- current dialog uses a different abstraction and migration was not requested
- custom title markup omits the generated heading ID
- submit loading can double-submit or leave the footer enabled
- implementation would add unsupported props, fake flags, or broad shared-component changes
- verification cannot be performed

## Common Mistakes

- Choosing `@components/dialogBox` only by name while nearby code requires a module-specific popup.
- Splitting dismiss, cancel, and success cleanup into divergent paths without a reason.
- Putting full-dialog `DialogLoading` inside `DialogBoxContent`, leaving footer actions clickable.
- Moving body validation or errors outside the scrollable content area.
- Using `renderTitle` without applying the provided `titleId`.
- Hardcoding visible strings or adding guessed i18n keys.
- Adding `height` to every dialog instead of using content-driven height.
- Changing shared dialog components to solve one local workflow.

## Checklist

### Intake

- [ ] Target file, module, task type, and dialog purpose are known.
- [ ] Expected open, close, cancel, submit, error, loading, permission, and cleanup behavior is known when relevant.
- [ ] User-visible text source and i18n pattern are known.
- [ ] Unknowns remain visible instead of invented.

### Selection

- [ ] Nearby dialog patterns were inspected.
- [ ] The selected pattern matches behavior, loading scope, and close contract.
- [ ] Existing abstraction is preserved unless migration is requested.
- [ ] Template use, if any, matches the workflow.

### Implementation

- [ ] Changes are minimal and scoped to the requested dialog flow.
- [ ] `DialogBox` composition and controlled close behavior are correct.
- [ ] Loading placement and footer disabling match the blocking behavior.
- [ ] i18n, accessibility, validation, errors, permissions, and cleanup are preserved.
- [ ] Styling follows nearby Allure 1 / Fluent UI 8 conventions.

### Verification

- [ ] Main user flow was checked.
- [ ] Close, cancel, title close, submit success, submit failure, and cleanup were checked when relevant.
- [ ] Loading, disabled footer, validation/error, i18n, and accessibility were checked when relevant.
- [ ] Tests, type checks, lint checks, or manual checks are recorded; skipped checks include a reason.

## Output Format

For completed work, report:

```text
Done:
- <what changed>

Changed:
- <file>: <summary>

Verified:
- <checks run>

Not Verified:
- <checks not run and why>

Risks / Notes:
- <remaining assumptions or follow-up>
```
