from __future__ import annotations

from dataclasses import dataclass
from importlib import resources
from pathlib import Path
import re
from typing import Iterable

_SAFE_SEGMENT = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]*$")


class SkillNotFoundError(ValueError):
    """Raised when a requested skill or template is not available."""


@dataclass(frozen=True)
class SkillEntry:
    name: str
    summary: str
    keywords: tuple[str, ...]
    templates: tuple[str, ...]
    uri: str


class SkillRegistry:
    def __init__(self, root: Path | None = None) -> None:
        self.root = root if root is not None else _default_content_root()

    def list_skills(self) -> list[SkillEntry]:
        if not self.root.exists():
            return []

        skills: list[SkillEntry] = []
        for skill_path in sorted(path for path in self.root.iterdir() if path.is_dir()):
            skill_file = skill_path / "SKILL.md"
            if not skill_file.is_file() or not _is_safe_segment(skill_path.name):
                continue
            skills.append(self._entry_from_path(skill_path.name, skill_file))
        return sorted(skills, key=lambda skill: skill.name)

    def read_skill(self, name: str) -> str:
        skill_path = self._skill_path(name)
        skill_file = skill_path / "SKILL.md"
        if not skill_file.is_file():
            raise SkillNotFoundError(f"Skill not found: {name}")
        return skill_file.read_text(encoding="utf-8")

    def list_templates(self, name: str) -> list[str]:
        templates_dir = self._skill_path(name) / "templates"
        if not templates_dir.is_dir():
            return []
        return sorted(path.name for path in templates_dir.iterdir() if path.is_file() and _is_safe_segment(path.name))

    def read_template(self, name: str, template_name: str) -> str:
        self._validate_segment(template_name)
        template_path = self._skill_path(name) / "templates" / template_name
        if not template_path.is_file():
            raise SkillNotFoundError(f"Template not found: {name}/{template_name}")
        return template_path.read_text(encoding="utf-8")

    def search(self, query: str) -> list[SkillEntry]:
        normalized_query = query.strip().lower()
        if not normalized_query:
            return []

        matches: list[SkillEntry] = []
        for skill in self.list_skills():
            body = self.read_skill(skill.name).lower()
            haystack = "\n".join([skill.name, skill.summary, *skill.keywords, body]).lower()
            if normalized_query in haystack:
                matches.append(skill)
        return matches

    def _entry_from_path(self, name: str, skill_file: Path) -> SkillEntry:
        body = skill_file.read_text(encoding="utf-8")
        frontmatter = _extract_frontmatter(body)
        return SkillEntry(
            name=name,
            summary=_extract_summary(body, frontmatter),
            keywords=tuple(frontmatter.get("keywords", [])),
            templates=tuple(self.list_templates(name)),
            uri=f"elements-skill://{name}/SKILL.md",
        )

    def _skill_path(self, name: str) -> Path:
        self._validate_segment(name)
        skill_path = self.root / name
        if not skill_path.is_dir():
            raise SkillNotFoundError(f"Skill not found: {name}")
        return skill_path

    @staticmethod
    def _validate_segment(segment: str) -> None:
        if not _is_safe_segment(segment):
            raise SkillNotFoundError(f"Unsafe path segment: {segment}")


def _default_content_root() -> Path:
    return Path(str(resources.files("elements_mcp").joinpath("resources", "content", "skills")))


def _is_safe_segment(segment: str) -> bool:
    return bool(_SAFE_SEGMENT.fullmatch(segment))


def _extract_summary(body: str, frontmatter: dict[str, list[str]] | None = None) -> str:
    description = (frontmatter or _extract_frontmatter(body)).get("description", [])
    if description:
        return description[0]

    for line in _iter_non_frontmatter_lines(body):
        stripped = line.strip()
        if stripped.startswith("#"):
            return stripped.lstrip("#").strip()
        if stripped:
            return stripped[:160]
    return ""


def _extract_frontmatter(body: str) -> dict[str, list[str]]:
    lines = body.splitlines()
    if not lines or lines[0].strip().lstrip("\ufeff") != "---":
        return {}

    metadata: dict[str, list[str]] = {}
    current_key = ""
    for line in lines[1:]:
        stripped = line.strip()
        if stripped == "---":
            return metadata
        if not stripped:
            continue
        if stripped.startswith("-") and current_key:
            value = stripped[1:].strip().strip("\"'")
            if value:
                metadata.setdefault(current_key, []).append(value)
            continue
        if ":" not in stripped:
            current_key = ""
            continue

        key, raw_value = stripped.split(":", 1)
        current_key = key.strip()
        value = raw_value.strip()
        metadata.setdefault(current_key, [])
        if value:
            metadata[current_key].append(value.strip("\"'"))

    return metadata


def _iter_non_frontmatter_lines(body: str) -> Iterable[str]:
    lines = body.splitlines()
    if not lines or lines[0].strip().lstrip("\ufeff") != "---":
        yield from lines
        return

    in_frontmatter = True
    for line in lines[1:]:
        if in_frontmatter and line.strip() == "---":
            in_frontmatter = False
            continue
        if not in_frontmatter:
            yield line
