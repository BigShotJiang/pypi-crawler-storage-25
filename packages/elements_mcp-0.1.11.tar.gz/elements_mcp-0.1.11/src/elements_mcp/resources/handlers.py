from __future__ import annotations

from typing import Any

from .registry import SkillRegistry


def register_resource_handlers(mcp: Any, registry: SkillRegistry) -> None:
    @mcp.resource(
        "elements-skill://{skill_name}/SKILL.md",
        mime_type="text/markdown",
        description="Read a shared Elements project skill by skill name.",
    )
    def skill_resource(skill_name: str) -> str:
        return registry.read_skill(skill_name)

    @mcp.resource(
        "elements-template://{skill_name}/{template_name}",
        mime_type="text/markdown",
        description="Read a reusable template that belongs to a shared Elements project skill.",
    )
    def template_resource(skill_name: str, template_name: str) -> str:
        return registry.read_template(skill_name, template_name)
