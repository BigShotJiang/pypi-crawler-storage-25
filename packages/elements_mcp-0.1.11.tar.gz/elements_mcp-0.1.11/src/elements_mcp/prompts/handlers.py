from __future__ import annotations

from typing import Any

from elements_mcp.resources.registry import SkillRegistry

from .registry import PromptRegistry


_CUSTOM_FILE_PROMPTS = {"check-i18n", "create-filter-table"}


def register_prompt_handlers(mcp: Any, skill_registry: SkillRegistry, prompt_registry: PromptRegistry) -> None:
    @mcp.prompt(
        description="Apply a shared Elements project skill to a specific coding task.",
    )
    def apply_project_skill(skill_name: str, task: str) -> str:
        skill_body = skill_registry.read_skill(skill_name)
        return (
            f"Use the following project skill for this task.\n\n"
            f"Skill: {skill_name}\n"
            f"Task: {task}\n\n"
            f"{skill_body}"
        )

    _register_check_i18n_prompt(mcp)
    _register_create_filter_table_prompt(mcp)

    for entry in prompt_registry.list_prompts():
        if entry.name in _CUSTOM_FILE_PROMPTS:
            continue
        _register_file_prompt(mcp, prompt_registry, entry.name, entry.description)


def _register_check_i18n_prompt(mcp: Any) -> None:
    @mcp.prompt(
        name="check-i18n",
        description="Scan a narrow file or folder for hardcoded UI strings; optionally prepare autofix.",
    )
    def check_i18n(target_path: str = "", autofix: str = "false") -> str:
        target = target_path.strip() or "the current active file"
        autofix_requested = _parse_bool(autofix)
        mode = "autofix" if autofix_requested else "scan only"
        return (
            "# /check-i18n\n\n"
            "Run the Elements i18n workflow for a specific target.\n\n"
            f"- target path: {target}\n"
            f"- mode: {mode}\n"
            f"- autofix requested: {'yes' if autofix_requested else 'no'}\n\n"
            "Follow this execution contract:\n\n"
            "1. Call `get_project_guidance` with the user's original request before scanning or editing.\n"
            "2. Reject broad targets such as `.`, the whole workspace, or `src`; ask for a specific feature folder or file.\n"
            "3. Scan first and report findings in a Markdown table with columns: `Original String`, `Suggested Key`, `Line Number`, `Status`.\n"
            "4. Use only these status values: `ExistingKeyReused`, `NewKeySuggested`, `Ignored`, `ManualRefactorRequired`.\n"
            "5. If autofix is requested, apply focused edits only after the scan result is reviewed or the user explicitly confirms autofix.\n"
            "6. Preserve existing i18n keys, imports, business logic, tests, generated files, and unrelated formatting.\n"
            "7. Run the relevant repository verification command when available and report the result.\n"
        )


def _register_create_filter_table_prompt(mcp: Any) -> None:
    @mcp.prompt(
        name="create-filter-table",
        description="Start an interactive UITableColumnFilter table-page wizard from a short request.",
    )
    def create_filter_table(request: str = "", page_route: str = "", feature_name: str = "") -> str:
        normalized_request = request.strip() or "Create a UITableColumnFilter table page."
        route_line = f"- page route: {page_route.strip()}\n" if page_route.strip() else ""
        feature_line = f"- feature/module name: {feature_name.strip()}\n" if feature_name.strip() else ""
        return (
            "# /create-filter-table\n\n"
            "Start the Elements `UITableColumnFilter` + `UINewFilter` table-page workflow.\n\n"
            f"- user request: {normalized_request}\n"
            f"{route_line}"
            f"{feature_line}"
            "\nFollow this execution contract:\n\n"
            "1. Call `get_project_guidance` with the user's original request before planning or writing code.\n"
            "2. If guidance provides an input contract, present that contract and collect the missing values.\n"
            "3. Otherwise collect the minimum table details: route, module, API source, response shape, primary key, columns, filters, actions, permissions, states, and i18n prefix.\n"
            "4. Read the real API, model, and type sources before inferring fields, enum values, filter options, or permissions.\n"
            "5. Present a concise implementation summary and wait for confirmation before editing files.\n"
            "6. Generate a split file plan that follows MCP guidance and nearby repository conventions.\n"
            "7. Implement with existing table, filter, request, permission, and i18n helpers; do not invent project-specific rules.\n"
            "8. Run relevant typecheck, lint, or tests when available and report the result.\n"
        )


def _register_file_prompt(mcp: Any, prompt_registry: PromptRegistry, prompt_name: str, description: str) -> None:
    @mcp.prompt(name=prompt_name, description=description)
    def packaged_prompt() -> str:
        return prompt_registry.read_prompt(prompt_name)


def _parse_bool(value: str) -> bool:
    return value.strip().lower() in {"1", "true", "yes", "y", "on", "--autofix", "autofix"}
