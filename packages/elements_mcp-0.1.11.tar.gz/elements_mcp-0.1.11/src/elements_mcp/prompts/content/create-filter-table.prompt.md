---
description: "Parameterized UITableColumnFilter table-page wizard"
---

# /mcp.elements.create-filter-table

This MCP prompt is registered by a custom handler so clients can pass structured
arguments instead of receiving this whole Markdown file as the executable prompt.

## Arguments

- `request`: initial table-page request from the user.
- `page_route`: optional route when already known.
- `feature_name`: optional feature or module name when already known.

## Execution Contract

1. Call `get_project_guidance` with the user's original request before planning
   or writing code.
2. If guidance provides an input contract, present that contract and collect the
   missing values.
3. Otherwise collect the minimum table details: route, module, API source,
   response shape, primary key, columns, filters, actions, permissions, states,
   and i18n prefix.
4. Read the real API, model, and type sources before inferring fields, enum
   values, filter options, or permissions.
5. Present a concise implementation summary and wait for confirmation before
   editing files.
6. Generate a split file plan that follows MCP guidance and nearby repository
   conventions.
7. Implement with existing table, filter, request, permission, and i18n helpers.
8. Run relevant typecheck, lint, or tests when available and report the result.
