---
description: "Parameterized i18n scan/autofix workflow for a narrow target"
---

# /mcp.elements.check-i18n

This MCP prompt is registered by a custom handler so clients can pass structured
arguments instead of receiving this whole Markdown file as the executable prompt.

## Arguments

- `target_path`: optional target file or narrow feature folder. Leave empty for
  the current active file.
- `autofix`: optional string boolean. Accepted truthy values include `true`,
  `yes`, `1`, `on`, `autofix`, and `--autofix`.

## Execution Contract

1. Call `get_project_guidance` with the user's original request before scanning
   or editing.
2. Reject broad targets such as `.`, the whole workspace, or `src`; ask for a
   specific feature folder or file.
3. Scan first and report findings in a Markdown table with columns:
   `Original String`, `Suggested Key`, `Line Number`, and `Status`.
4. Use only these status values: `ExistingKeyReused`, `NewKeySuggested`,
   `Ignored`, and `ManualRefactorRequired`.
5. If autofix is requested, apply focused edits only after scan review or
   explicit user confirmation.
6. Preserve existing i18n keys, imports, business logic, tests, generated files,
   and unrelated formatting.
7. Run relevant verification when available and report the result.
