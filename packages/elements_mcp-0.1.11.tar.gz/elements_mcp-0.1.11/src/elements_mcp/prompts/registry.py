from __future__ import annotations

from dataclasses import dataclass
from importlib import resources
from pathlib import Path
import re
from typing import Iterable


_SAFE_PROMPT_FILE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]*\.prompt\.md$")
_PROMPT_SUFFIX = ".prompt.md"


class PromptNotFoundError(ValueError):
    """Raised when a requested packaged prompt is not available."""


@dataclass(frozen=True)
class PromptEntry:
    name: str
    description: str
    path: Path


class PromptRegistry:
    def __init__(self, root: Path | None = None) -> None:
        self.root = root if root is not None else _default_content_root()

    def list_prompts(self) -> list[PromptEntry]:
        if not self.root.exists():
            return []
        prompts: list[PromptEntry] = []
        for path in sorted(self.root.iterdir()):
            if path.is_file() and _is_safe_prompt_file(path.name):
                prompts.append(self._entry_from_path(path))
        return prompts

    def read_prompt(self, name: str) -> str:
        prompt_path = self._prompt_path(name)
        return prompt_path.read_text(encoding="utf-8")

    def _entry_from_path(self, path: Path) -> PromptEntry:
        body = path.read_text(encoding="utf-8")
        return PromptEntry(
            name=_prompt_name(path.name),
            description=_extract_frontmatter_description(body),
            path=path,
        )

    def _prompt_path(self, name: str) -> Path:
        file_name = f"{name}{_PROMPT_SUFFIX}"
        if not _is_safe_prompt_file(file_name):
            raise PromptNotFoundError(f"Unsafe prompt name: {name}")
        prompt_path = self.root / file_name
        if not prompt_path.is_file():
            raise PromptNotFoundError(f"Prompt not found: {name}")
        return prompt_path


def _default_content_root() -> Path:
    return Path(str(resources.files("elements_mcp").joinpath("prompts", "content")))


def _is_safe_prompt_file(file_name: str) -> bool:
    return bool(_SAFE_PROMPT_FILE.fullmatch(file_name))


def _prompt_name(file_name: str) -> str:
    return file_name[: -len(_PROMPT_SUFFIX)]


def _extract_frontmatter_description(body: str) -> str:
    lines = body.splitlines()
    if not lines or lines[0].strip() != "---":
        return ""
    for line in _iter_frontmatter_lines(lines[1:]):
        stripped = line.strip()
        if stripped.startswith("description:"):
            return stripped.split(":", 1)[1].strip().strip('"')
    return ""


def _iter_frontmatter_lines(lines: list[str]) -> Iterable[str]:
    for line in lines:
        if line.strip() == "---":
            return
        yield line
