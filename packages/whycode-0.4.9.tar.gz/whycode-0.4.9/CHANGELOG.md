# Changelog

## 0.4.9 — 2026-04-17

### Audit notes

A live Windows testing session generated a 9-fix prompt for this
release. The audit before coding flagged four claims that did not
match the codebase:

- **Tags / staleness_signals double-serialization** (Fix 1): the
  `Decision` round-trip through `_serialize_value` / `_deserialize_value`
  already returns Python lists. No change needed; if a client sees
  string tags, the cause is upstream of the serializer (likely a
  stale 0.4.7 install or a custom code path).
- **Memory page missing `project_id`** (Fix 3): the frontend does
  omit `project_id`, but `tool_handlers._resolve_project_id` already
  falls back to `default_project_id`. Empty results indicate an empty
  embedding index, not a missing parameter.
- **File watcher needs `PollingObserver` on Windows** (Fix 5): the
  watcher uses `watchdog.observers.Observer`, which auto-selects the
  per-platform observer. The "AST changes = 0" symptom was diagnosed
  separately as a path-normalisation issue (fixed below).
- **`decision.list active_only` default** (Fix 9): already
  `active_only=True` since v0.4.7.

### Fixed

**Persistent projects table (Fix 2)**
- New v12 migration creates a `projects` table with `(id, name,
  cwd, user_id, created_at, updated_at)` columns and a unique
  `(name, COALESCE(user_id, ''))` index.
- `project_create` and `project_list` now read and write that table
  directly. `project_list` always includes the bootstrap default,
  so the dashboard is never blank.
- Server startup runs `_bootstrap_default_project`, which inserts
  or refreshes the row matching `ToolHandlers.default_project_id`
  with the cwd from `whycode.toml`.
- `POST /api/projects` accepts an optional `cwd` field.

**Provenance edges on `decision.create` (Fix 7)**
- `decision_create` now accepts `files_affected` and `project_id`.
- For each affected file, a `provenance_edges` row is written with
  `source_type='decision'`, `target_type='file'`, `target_id=<path>`,
  `relationship='affects'`. The function is idempotent against
  re-runs.
- When the active session has matching `ast_changes` rows for the
  same file + project, decision → ast_change edges are also created
  using the existing reverse-trace convention, so the dashboard
  provenance panel surfaces them automatically.

**Decision schema linkage (Fix 6 subset)**
- v12 also adds `decisions.project_id`, `decisions.files_affected`,
  and `decisions.confidence` columns. `Decision` model and its
  `to_dict` / `from_dict` round-trip the new fields. SQLite stores
  `files_affected` as JSON; the model returns a Python list.

**`whycode backfill-provenance` CLI (Fix 8)**
- New idempotent command that scans every decision with a non-empty
  `files_affected` and writes any missing `decision → file`
  provenance edges. Run once after upgrading.

**Path normalisation for cross-platform storage (Fix 5 subset)**
- New `backend/utils/paths.py` exports `normalise_path`, which
  converts Windows backslash paths to forward-slash form and is a
  no-op on POSIX paths.
- File watcher applies it before snapshotting and posting to
  `/api/hooks/file-change`, so Windows path lookups match Unix
  storage downstream.
- `decision_create` applies it to every entry in `files_affected`
  before writing the row and the provenance edges.

**ExplorerView placeholder (Fix 4)**
- Removed the random `Math.random()` data points and the yellow
  "placeholder data only" banner.
- Replaced with a clean dashed-border empty state that explains
  what the semantic map will show once enough decisions exist.

## 0.4.8 — 2026-04-17

### Fixed

**File tracking (all clients)**
- `hooks_file_context` (PreToolUse path) now appends the edited
  file to the session's `files_touched` list on every call, with
  deduplication and a `last_tool_call_at` refresh. Previously
  `Session.files_touched` was declared on the model and schema but
  never written by any code path — the Windows production session
  that surfaced this bug reported `files_touched: []` no matter
  how many files the agent edited.
- `hooks_session_context` (UserPromptSubmit path) now ensures a
  session exists for the `(cwd, agent_name)` pair and emits a
  `hook_project_root` SessionEvent on the first call. Without that
  event, the Stop-hook's `hooks_close_session` could not locate
  the session and silently returned `{status: closed}` with no
  inference run. This was the root cause of the cascading
  "inferred_decisions: none" symptom.
- Both hook endpoints now echo `session_id` in the response so
  clients that want to chain calls can pass it forward.

**Passive inference**
- `_session_unlinked_files` now merges `Session.files_touched`
  with the historical `ast_changes`-derived file set. Installs
  without git (no post-commit hook) and without a running file
  watcher (Windows or locked-down VMs) now surface unlinked files
  at session end based on the PreToolUse signal alone, so
  `session.end` returns `completed_with_warnings` as intended and
  the inference + auto-confirm paths run.

**Cursor and Windsurf — no changes required**
- `ensure_session_and_inject_context` (wired into every MCP tool
  via `_bootstrap_session` at the MCP server layer) already
  auto-creates a session for non-hook clients on their first tool
  call. `whycode connect` and `whycode token write-config --client
  cursor|windsurf` already generate the right MCP configs.
  Verified; no code change.

**Churn threshold (documentation-only)**
- The v0.4.7 live-testing analysis prompt used
  `hours_below_median > 50%` to flag "high churn risk". That
  predicate is statistically unreachable on even-length series
  because the median splits the series 50/50 by definition.
  Future analysis must use `>= 50%` (or compare against the mean
  instead of the median to avoid the split issue entirely).
  No change to production code — the threshold is not embedded
  in the backend.

**CLAUDE.md**
- Client-specific section split into distinct **Claude Code**,
  **Cursor**, and **Windsurf** blurbs. The Claude Code block now
  includes the `whycode connect --fix-hooks` pointer for the
  Windows bash-missing case.

## 0.4.7 — 2026-04-17

### Fixed

- **`sentence-transformers` promoted from optional to required.** The
  package now ships with the local embedder built in, so semantic
  search is available out of the box even when Ollama is unreachable.
  First startup downloads ``all-MiniLM-L6-v2`` (~80 MB) if the model
  is not cached; subsequent starts are offline. Removes the
  ``[local-embed]`` extra (the dep is now load-bearing).
- **Embeddings are always initialized at startup — `semantic_search`
  is never `None`.** `create_app` constructs a `SemanticSearch` with
  an `OllamaEmbedder` when the daemon answers its probe, or a
  `SentenceTransformerEmbedder` otherwise. The resolved backend and
  dimension are logged once at boot. `ToolHandlers` + `DecisionInferrer`
  receive the live semantic search, so dedup (GR-7) and context
  retrieval work on fresh installs without extra setup.
- **`decision.list` filters superseded decisions by default.** The
  new `active_only` parameter (default `True`) hides rows whose
  `superseded_by` is non-null; pass `active_only=False` to include
  the full decision history for audit or provenance use.
- **`whycode connect` auto-refreshes stale `cl_solo_*` tokens** in
  `~/.claude/settings.json` (regex rewrite that preserves every
  surrounding structure) and `~/.claude.json` (JSON-level rewrite of
  the `mcpServers.{whycode,codeledger}.headers.Authorization`
  header). Solo-mode tokens rotate on every `whycode init`, so this
  fix prevents the silent-401 loop that followed a token refresh.
- **Vault auto-migrates `~/.codeledger` → `~/.whycode` on first run.**
  `backend.auth.credential_manager.auto_migrate_vault_dir` copies
  the legacy tree into the new location the first time any
  CredentialManager is constructed. Non-destructive — the legacy
  directory is preserved. Triggered by both the CLI and server
  entry points so users upgrading across the rename don't need to
  run `mv` by hand.

## 0.4.6 — 2026-04-17

### Fixed

- **Windows Claude Code hooks now use `python3 -c` instead of
  `bash -lc`.** `cmd.exe` ships with neither bash nor curl, so every
  hook installed by `whycode connect` on Windows silently exited 0,
  which meant sessions never started, file context was never injected,
  and `session.end` never fired. The new
  `backend.utils.hook_builder.build_hook_command` emits `python3 -c`
  + `urllib.request` on Windows and preserves the historical
  `bash -lc` + `curl` form on Linux/macOS. `cwd` falls back to
  `os.getcwd()` when `CLAUDE_CWD` is not set (it isn't, under plain
  `cmd.exe`).
- **`whycode connect --fix-hooks` rewrites Claude Code hooks for the
  current platform without touching MCP server entries.** Use this
  on Windows after upgrading across this release to replace any
  stale bash hooks. A warning surfaces when the existing
  `settings.json` still contains `bash -lc` commands on Windows.
- **`write_claude_code_settings` drops the pre-rename `codeledger`
  MCP entry** when adding `whycode`, so Claude Code does not load
  the same server twice under two names.
- **`whycode desktop-guide` prints a Windows-specific hook
  troubleshooting block** when run on Windows (verify python3 on
  PATH, check for stale `bash -lc` in `settings.json`, re-run
  `whycode connect --fix-hooks`, restart Claude Code).

## 0.4.5 — 2026-04-17

### Fixed

- **`whycode init` auto-initializes a git repository.** When the
  project root is not already a git working tree, init runs
  `git init && git add . && git commit` with a WhyCode author so
  the richer git change-detection backend is available on first
  run. When `git` is missing from `PATH`, init prints a warning
  and falls back to `change_detection.backend = "file_watcher"`
  instead of silently registering git hooks that will never fire.
- **SQLite default path is now `data/whycode.db`.** The
  `DatabaseConfig.sqlite_path` default was still `data/codeledger.db`
  from the pre-rename era even though the generated `whycode.toml`
  already wrote `data/whycode.db`. Fresh installs and users with
  explicit config are unaffected; users who rely on the default
  (no `[database]` section) now pick up the renamed path.
- **MCP client configs always use `http://` for loopback hosts.**
  `write_mcp_client_config` and `write_claude_code_settings` now
  route any `https://127.0.0.1` / `https://localhost` URL through
  `_force_http_for_loopback` before writing. Claude Desktop,
  Cursor, and Windsurf refuse self-signed TLS on MCP connections,
  so solo installs must never end up with a `https://` URL in
  their client config.
- **Google/GitHub login works out of the box via an OAuth relay.**
  `providers.toml` now accepts an optional `client_id` field
  holding the public client ID for the WhyCode-hosted OAuth app.
  When no local client_secret is configured, the OAuth callback
  delegates the `code → token` exchange to the WhyCode relay
  (`auth.whycode.dev`, overridable via `WHYCODE_OAUTH_RELAY_URL`).
  User-supplied OAuth apps continue to work via the existing
  direct flow — the relay is only used when the local install has
  a client_id but no secret. *The relay server itself must be
  deployed separately before this path resolves end-to-end.* The
  login page no longer gates Google/GitHub buttons on local
  configuration.
- **Dashboard views survive `null` API responses.** `DecisionsView`,
  `SessionsView`, `SprintView`, and `ProvenanceView` coalesce
  `data ?? []` explicitly instead of relying on React Query's
  destructuring default (which only applies when `data` is
  `undefined`). A successful response that returns `null` — or a
  trace with a missing `change_events`/`ast_changes` array — no
  longer blanks the view.

## 0.4.4 — 2026-04-17

### Changed

- **Project renamed from CodeLedger to WhyCode.**
  - PyPI package: `whycode` (was `codeledger-ai`).
  - npm package: `whycode` (was `codeledger-ai`; jumps from 0.1.5 to
    0.4.4 to match the Python version).
  - CLI entry point: `whycode` (was `codeledger`).
  - Config file: `whycode.toml` (was `codeledger.toml`; legacy file
    still loads with a deprecation warning).
  - Vault directory default: `~/.whycode/` (was `~/.codeledger/`;
    legacy directory still used if `~/.whycode` is absent).
  - CLAUDE.md / .cursorrules / .windsurfrules / .clinerules markers:
    `<!-- WHYCODE:START -->` / `<!-- WHYCODE:END -->` (legacy
    `<!-- CODELEDGER:* -->` markers are still recognised on read, so a
    single `whycode init` upgrades the block in place).
  - SQLite default path kept at `data/codeledger.db` so users
    upgrading in place do not orphan their existing database. Override
    in `whycode.toml` under `[database] sqlite_path` when ready.

### Fixed

- **Connector OAuth shows a setup guide instead of a 503 JSON blob
  when client credentials are not yet configured.** Clicking Connect
  on Gmail/Slack/Jira/etc. without a Client ID/Secret now redirects
  the browser to an HTML page with provider-specific instructions
  for creating an OAuth app and pasting the callback URL, instead of
  dumping a JSON 503 into the browser window.

- **DB connector credential forms replace the opaque JSON/DSN
  placeholder with typed fields** (host, port, api_key,
  database, etc.) rendered dynamically from a new
  `credential_schema` on each connector, plus per-field help text.
  A new `GET /api/connectors/{slug}/schema` endpoint exposes the
  schema to the dashboard. Connectors whose optional driver is not
  installed now surface a "run `pip install whycode[<extra>]`" hint
  in the dashboard instead of silently disappearing.

### Migration

Users upgrading from CodeLedger 0.4.3 do not need to take any action
for backward compatibility: `codeledger.toml`, `~/.codeledger/`, and
`CODELEDGER_CONFIG` are all still accepted. To fully migrate:

```
mv codeledger.toml whycode.toml
mv ~/.codeledger ~/.whycode
# Rename CODELEDGER_* env vars to WHYCODE_* in your shell/CI config.
```

The old `codeledger` CLI command is removed; use `whycode` instead.

## 0.4.3 — 2026-04-17

### Fixed

- **Login broken when server CWD ≠ project root.** `providers.toml`
  and `vault.vault_path` were resolved relative to the process CWD,
  so a server launched from a systemd unit, container, or any
  directory other than the project root silently loaded zero OAuth
  providers (greying out Google/GitHub buttons) and rejected every
  solo bearer token with 401 (vault file not found). Added
  `CodeLedgerConfig.resolve_path()` which anchors relative paths to
  `project_root`; wired it into `load_providers()` call sites in
  `backend/main.py` and into `CredentialManager`'s vault-path
  resolution. `CredentialManager.__init__` now accepts an optional
  `project_root`. Startup now logs the resolved `db`, `vault`, and
  `providers` paths and emits an explicit warning when
  `providers.toml` is missing at the resolved location.

## 0.4.2 — 2026-04-17

### Added

- **Restart-invalidated dashboard sessions.** Every JWT carries an
  ``iss`` claim bound to a process-scoped ``SERVER_INSTANCE_ID``.
  ``verify_jwt`` rejects mismatched tokens with
  ``AuthError("server_restarted")``, so a ``codeledger serve``
  restart kills every dashboard session server-side without rotating
  the vault-stored signing key (SEC-08 unchanged). Solo bearer tokens
  and PATs are untouched — Claude Code's MCP connection survives
  restarts.
- **Auto-recovery from stale auth.** The shared frontend client
  clears ``cl.token``, ``cl.cookie_session``, and
  ``cl.server_instance`` on any 401 and dispatches a storage event so
  ``App.tsx`` flips back to ``LoginView``. On load the dashboard
  fetches ``GET /api/server/instance`` (new public endpoint) and
  wipes markers when the id differs from what localStorage
  remembers.
- **Sign-out button** next to the Live indicator in the dashboard
  header. Calls ``api.auth.logout()`` and reloads.
- **Change-detection backend selectable from Settings.** New
  ``POST /api/server/change-detection-backend`` endpoint installs or
  removes the git post-commit hooks, rewrites
  ``[change_detection] backend`` in ``codeledger.toml``, and
  validates that ``.git/`` exists before accepting ``git`` mode. The
  Settings view now shows a radio picker with precondition hints and
  a restart-required message. ``/api/setup/status`` gained a
  ``git_available`` field.

### Fixed

- ``LiveIndicator`` now routes through the shared API client, so a
  401 during the 30-second poll clears auth markers instead of
  leaving the dashboard stuck on "Disconnected" forever.

## 0.4.1 — 2026-04-17

### Added

- ``codeledger dashboard`` CLI command: opens the dashboard in the
  default browser with the solo bearer token pre-applied via a URL
  hash fragment (``#token=...``). The frontend consumes the fragment
  on load, stores the token in ``localStorage``, and scrubs the URL so
  the token does not linger in browser history. Subsequent visits
  from the same browser profile auth automatically. Solo mode only;
  team mode continues to use OAuth. Flags: ``--no-browser`` prints the
  URL instead of launching; ``--server`` overrides host/port.

### Security

- Hash fragments are never transmitted to the server, so the solo
  token does not appear in access logs. The frontend clears the
  fragment via ``history.replaceState`` immediately after reading it.

## 0.4.0 — 2026-04-17

### Added — Connector Marketplace

Large new subsystem: external-tool and database connectors usable from
the MCP tool surface, dashboard, REST API, and CLI. One
``backend/connectors/bootstrap.py::build_default_registry`` populates
every entry point with the same connector set.

**External connectors (12, always installed — httpx only):**
Gmail, Google Drive, Google Calendar, Slack, Jira, Confluence,
Linear, Notion, GitHub Issues, Asana, Microsoft Teams, Outlook.

**Database connectors (14, each gated on its own optional extra):**
PostgreSQL, TimescaleDB, MySQL/MariaDB, MongoDB, Redis,
Elasticsearch, InfluxDB 2, InfluxDB 3, AWS DynamoDB, Databricks,
Snowflake, Google BigQuery, ClickHouse, Apache Cassandra. Sync
drivers (Databricks, Snowflake, BigQuery, ClickHouse, Cassandra) run
every call through ``run_in_executor`` so they never block the MCP
event loop.

**New public surface:**

- HTTP — ``/api/connectors/status``, ``/{slug}/health``,
  ``/{slug}/setup``, ``/{slug}/disconnect`` (all auth-required),
  plus public ``/oauth/{slug}/connect`` and ``/oauth/{slug}/callback``
  with per-slug CSRF cookies (``codeledger_connector_state_{slug}``).
- MCP — single ``connectors`` tool with method dispatch covering
  ``status``, ``search_all``, ``search``, ``get_item``,
  ``link_to_decision``, ``list_tables``, ``describe_table``,
  ``sample_rows``, ``get_schema_summary``. 10-second per-call timeout.
- CLI — ``codeledger connectors list|status|connect|disconnect|test``
  and ``codeledger connectors db schema``.
- Dashboard — new **Connectors** tab with Connected / Available sections
  grouped by category. Settings "Connect" buttons now drive the real
  OAuth flow instead of faking a client-only state.

**New optional extras:** ``[mysql]``, ``[mongodb]``, ``[redis-connector]``,
``[influxdb2]``, ``[influxdb3]``, ``[databricks]``, ``[snowflake]``,
``[bigquery]``, ``[elasticsearch]``, ``[dynamodb]``, ``[clickhouse]``,
``[cassandra]``, plus ``[all-databases]``.

### Security

- SEC-02: connector error logs use ``exc.__class__.__name__``, never
  ``str(exc)`` — provider URLs / token values stay out of log output.
- SEC-03: ``ConnectorResult.summary`` hard-capped at 500 chars in
  ``__post_init__``; explicit PII boundary tests for Gmail, Calendar,
  Outlook, Teams, Confluence, Slack.
- SEC-04: every connector credential (access tokens, refresh tokens,
  API keys, connection strings, cloud_id, workspace_gid) routes
  through ``CredentialManager`` under the ``connector_{slug}``
  namespace. No SQL column, no disk file.
- SEC-05: MCP ``connectors.*`` calls resolve ``user_id`` first;
  HTTP write endpoints (``/setup``, ``/disconnect``) require a session.
- SEC-06: per-slug state + PKCE verifier cookies on every OAuth flow.
- SQL-injection boundary: ``AbstractDatabaseConnector._validate_table``
  whitelist-validates every table name against ``list_tables()`` before
  any SQL interpolation.
- Path-traversal guard: ``get_item`` in Confluence, Drive, Google
  Calendar, Jira, Notion, Outlook, Teams, Asana rejects ``..`` and
  ``/`` in the caller-supplied item id.

### Fixed — dashboard UX (8 bugs)

- MCP Servers page: API-key input field now appears when auth=api_key;
  auth dropdown hidden for stdio transport; form validation with inline
  error messages; edit mode shows distinct title + Cancel button; edit
  submit preserves ``toolCount``/``status``/``tools`` unless URL changed;
  server list persisted to ``localStorage[cl.mcpServers]``.
- Appearance: theme preference persisted to ``localStorage[cl.theme]``.
- Connected services: "Connect" buttons now drive the real OAuth flow
  via ``/api/connectors/oauth/{slug}/connect`` instead of faking a
  local-only ``{connected: true}`` state.

### Tests

1648 pass / 6 skip / 0 fail. 362 new connector-specific tests covering
import guards, timeout isolation, CSRF, PKCE, path traversal, PII
boundaries, SQL injection guards, and the full HTTP/MCP/CLI surface.

## 0.3.4 — 2026-04-17

### Added — dashboard OAuth browser redirect flow
- `GET /api/auth/oauth/{provider}/callback` completes the Google and
  GitHub authorization-code exchange: validates the per-provider
  `codeledger_oauth_state_{provider}` cookie with
  `hmac.compare_digest` (CSRF), reads the PKCE verifier from the
  `codeledger_oauth_verifier_{provider}` cookie, exchanges the code,
  fetches the profile, upserts the user, and issues a JWT via the
  existing `AuthService.issue_jwt`.
- `GET /api/auth/oauth/{provider}` now persists `state` (and, for
  PKCE providers, `code_verifier`) in short-lived HttpOnly cookies
  scoped to `/api/auth/oauth/` so the callback can validate them.
  `SameSite=Lax` so the provider redirect still carries them;
  `Secure` follows `server.mode` (team ⇒ true, solo ⇒ false on
  loopback HTTP).
- Successful callback sets the `codeledger_session` HttpOnly cookie
  and redirects to `/?oauth=success`. Failure modes funnel to
  `/?oauth_error={reason}` — `oauth_denied`, `oauth_csrf`,
  `oauth_invalid`, `oauth_exchange_failed`, `oauth_userinfo_failed`,
  `oauth_no_email`, `oauth_not_configured`.
- GitHub email fallback: when `/user` omits the email (private
  account), the callback fetches `/user/emails` and picks the primary
  verified address before upserting.

### Added — session identity and sign-out endpoints
- `GET /api/auth/me` returns the authenticated user's public profile
  (`id`, `email`, `name`, `provider`, `avatar_url`). 401 when the
  session cookie or bearer token is missing. Never returns hashes or
  tokens (SEC-03).
- `POST /api/auth/logout` clears the `codeledger_session` cookie and
  returns 204. Public so an expired or absent session still completes
  a clean browser sign-out.

### Changed — frontend OAuth landing
- `LoginView` reads `?oauth=success` on return from the callback,
  sets a `cl.cookie_session` marker (JWT stays in the HttpOnly cookie
  — never in localStorage or URL fragment), strips the query, and
  flips the auth gate.
- `?oauth_error={reason}` is mapped to a user-facing message and
  shown inline.
- `App.tsx` treats either `cl.token` (bearer) or `cl.cookie_session`
  (OAuth) as signed-in.
- `api.auth.logout` now awaits `POST /api/auth/logout` before
  clearing the local flags so the server-side cookie is expired.

### Tests
- New: `tests/integration/test_oauth_callback.py` — 12 cases
  covering initiate state-cookie setting (Google + GitHub), CSRF
  rejection, provider-error/missing-code funnel, happy-path session
  cookie + redirect, user-upsert idempotency, `/api/auth/me`
  401/200 paths, and logout clearing the cookie.

## 0.3.3 — 2026-04-17

### Fixed
- BLOCKING: `credential_manager` crashed with `keyring.errors.NoKeyringError`
  on clean installs in any environment without a system keyring — headless
  Linux, CI, and minimal venvs. `serve` could not start because
  `AuthService` needed to write a JWT signing key through keyring.
  Now falls back to an encrypted file store at
  `<vault_dir>/vault.fallback.enc` (AES-256-GCM + PBKDF2-HMAC-SHA256,
  600,000 iterations) with a machine-local key at `.credential_key`
  (0o600). The fallback uses a separate filename from `config.vault_path`
  so it never collides with an existing explicit-passphrase vault.
  System keyring is still used when available — desktop installs are
  unchanged.

## 0.3.2 — 2026-04-16

### Fixed
- Republish of the 0.3.1 `click` pin fix. The 0.3.1 artifact on PyPI did
  not reflect the widened `click>=8.1,<9.0` pin in practice, so users
  continued to see the `typer>=0.24` conflict. 0.3.2 is a clean rebuild
  from the post-fix tree with no code changes versus 0.3.1's intent.

## 0.3.1 — 2026-04-16

### Fixed
- Widen `click` dependency pin from `~=8.1.0` (which excluded 8.2+) to
  `>=8.1,<9.0`. The prior pin conflicted with `typer>=0.24` (requires
  `click>=8.2.1`) and with any environment that had already upgraded
  `click` to 8.2 or 8.3, causing pip to downgrade `click` on install and
  break unrelated tools in the user's Python environment.

## 0.3.0 — 2026-04-16

### Added — passive decision inference (GR-1 through GR-10)
- `backend/intelligence/inference_evidence.py` — evidence taxonomy with 13
  typed signals, a 129-module Python stdlib blocklist, a noise-packages
  list, and the `classify_import` helper used to reject `import json` as
  architectural noise (GR-10).
- `backend/intelligence/decision_inferrer.py` extended with a full
  evidence pipeline: library-grouped `Add <pkg> dependency` candidates,
  config-file / migration-file detection, 10-second `asyncio.wait_for`
  budget (GR-5), semantic-search deduplication against existing
  decisions (GR-7), and structured evidence persisted to a new
  `inferred_decisions.evidence` column (GR-4).
- Calibrated confidence scoring — single-signal cap at 0.65, multi-signal
  cap at 0.85, `MIN_VIABLE_CONFIDENCE` filter at 0.20 (GR-2). The
  previous 0.75 single-file ladder is gone by design.

### Added — context verification layer (VGR-1 through VGR-7)
- `backend/verification/context_verifier.py` — `ContextVerifier` stamps
  every retrieved decision with `verification_status` (VERIFIED, DRIFTED,
  STALE, SUPERSEDED, UNVERIFIED, INFERRED), action guidance, and (when
  drifted) the exact violating file and line.
- SUPERSEDED decisions are filtered before triage and reported on a
  separate excluded list (VGR-5); DRIFTED decisions are kept with a
  `[DRIFT]` marker so the agent can see both the intent and the
  violation (VGR-4).
- `backend/advanced/drift_detector.py` now persists violations to a
  cached `drift_violations` table and exposes
  `get_violations_for_decision` as a pure SELECT — the verifier reads
  from cache, never re-walks the filesystem (VGR-3).
- `backend/verification/harness.py` gained a `score_verification_health`
  sensor + `VerificationHealth` result; `score_session` now reports a
  1.0 / 0.7 / 0.5 / 0.4 / unavailable score based on how the session
  engaged with drifted context (VGR-6).
- Context retrieval is wired into all six surfaces: `context.get_relevant`,
  `context.get_for_file`, `context.before_edit`,
  `ensure_session_and_inject_context`, `hooks.session_context`,
  `hooks.file_context`. `context_retrieval` session events feed the
  harness sensor.
- `backend/intelligence/context_triage.py` formatter renders `[DRIFT]`,
  `[SUPERSEDED BY]`, and `[→]` guidance lines inline; token budgeting is
  unchanged.

### Schema
- Migration v9 — `inferred_decisions.evidence TEXT NOT NULL DEFAULT '[]'`.
- Migration v10 — `drift_violations` cache table with
  `(project_id, status)` and `(decision_id, status)` indexes.

### Tests
- 15 new verification guard-rail tests (VGR-1..VGR-7) and 62 inference
  guard-rail tests (GR-1..GR-10, plus taxonomy coverage).
- Full suite: 960 passed, 6 skipped, 0 failed.

## 0.2.4 — 2026-04-16

### Added
- Intelligent instruction-file manager (`backend/utils/instruction_file_manager.py`):
  creates `CLAUDE.md`, `.cursorrules`, `.windsurfrules`, and `.clinerules`
  when missing; updates the CodeLedger-managed block in place when present;
  never destroys content outside that block.
- `codeledger sync [--client all|claude-code|cursor|windsurf|cline]` — re-sync
  per-client instruction files without re-running full init.
- `codeledger desktop-guide` — prints a paste-in briefing for Claude Desktop
  users who have no project-file surface area.
- `codeledger init` now generates all four instruction files automatically.
- `codeledger connect` re-syncs instruction files with the resolved server URL
  so team servers and port overrides propagate into CLAUDE.md / .cursorrules.
- Onboarding step 2 lists all four supported clients and calls out the new
  `codeledger desktop-guide` and `codeledger sync` commands.
- `POST /api/projects` REST endpoint backed by `handlers.project_create`.
- Frontend `api.projects.{list, create}` client methods; project picker now
  persists to `localStorage` and round-trips new projects to the server.

### Fixed
- MCP tools no longer require the caller to pass an explicit `user_id`:
  `AuthMiddleware` now publishes the resolved user through a `ContextVar`
  which `_resolve_user_id` reads as a fallback. Solo-mode Claude Code /
  Cursor / Windsurf sessions can call `session.list`, `decision.create`,
  etc. without knowing their synthetic user UUID.
- "New project…" button in the header project picker now actually creates
  a project — previous behavior updated Zustand state only and lost it on
  refresh. State is now persisted to `localStorage` and mirrored to the
  backend.

## 0.1.8 — 2026-04-16

### Fixed
- Sessions, Memory, and Decisions tabs now render proper empty states
  instead of a blank container when there is no data.
- Sprint velocity chart hides when there are no completed sprints and
  shows an explanatory placeholder; x/y axes now have labels.
- Sprint kanban columns use readable labels (Backlog, In Progress,
  In Review, Done) with a story-count badge, replacing raw enums.
- Explorer tab's stub-data notice is now a prominent banner with UMAP
  axis labels and a per-type colour legend.
- Theme toggle is consolidated in Settings → Appearance; the button
  label and icon now reflect the current theme instead of the inverse.
- MCP Servers list adds an expandable tool panel, a kebab menu
  (Edit / Copy URL / Disconnect), and an auth-type tooltip.
- Settings: security invariants are now expandable with full
  descriptions; Personal Access Tokens section adds a copy-to-clipboard
  button and documentation link.
- Provenance tab shows an onboarding callout when no decisions exist,
  a concise intro, and a colour/shape legend.

### Added
- Header project picker — rename the active project, create a new
  project, and switch between projects inline.
- Header live indicator (30s auto-refresh) with manual refresh button
  and a disconnected state.
- Hash-based deep-linking for every tab (`#memory`, `#decisions`,
  `#sprint`, `#sessions`, `#explorer`, `#provenance`, `#mcp-servers`,
  `#settings`) plus browser back/forward support.
- Memory search: relevance / type sort, page-size selector
  (10 / 25 / 50), previous / next pagination, and in-result term
  highlighting via `<mark>`.
- Decisions detail panel: sticky header with ID + close, status and
  tag chips, "View provenance →" jump, and a per-decision note field.
- Sprint board: "+ Add story" modal (title, description, points,
  priority) and HTML5 drag-and-drop between lanes.
- Settings → Connected services: GitHub, Linear, Jira, and Slack cards
  with connect / disconnect and last-sync timestamps.
- Accessibility pass: visible focus rings on every interactive
  control, `aria-pressed` on filter buttons, `aria-selected` on tabs,
  `role="status"` on empty / loading regions, and explicit foreground
  colour on all select elements.
- Main layout now reserves bottom safe-area padding so externally
  injected overlays (e.g. Claude agent controls) no longer obscure
  app content.

## 0.1.7 — 2026-04-16

### Added
- `codeledger token show` — print the solo bearer token and a
  ready-to-paste MCP config snippet, with the correct Claude Desktop
  config path for the current platform.
- `codeledger token write-config --client claude-desktop|cursor|windsurf`
  — merge the CodeLedger MCP entry into the selected client's config
  automatically, preserving existing `mcpServers` entries.
- `codeledger config set-oauth --provider google|github` — configure
  OAuth client credentials for dashboard login.
- `codeledger init` now prompts for optional Google and GitHub OAuth
  credentials on interactive TTYs; press Enter to skip either.
- New public endpoint `GET /api/auth/oauth/providers` reports which
  OAuth providers are configured, so the login page can disable
  unconfigured buttons instead of producing a confusing error.
- Windows path added to Claude Desktop auto-detection in
  `codeledger connect` (`%APPDATA%\Claude\claude_desktop_config.json`).

### Fixed
- Solo bearer tokens (`cl_solo_…`) are now accepted by `AuthMiddleware`,
  so pasting the token into the dashboard login form actually signs
  the user in instead of looping back to 401.
- OAuth initiate route `/api/auth/oauth/{provider}` is now public and
  returns a 503 with an actionable `setup_command` when credentials
  are missing — replaces the misleading 401 "Missing credentials"
  error the dashboard surfaced when Google or GitHub was clicked
  without configuration.
- `codeledger connect` now prints a clear fallback message pointing at
  `codeledger token write-config --client claude-desktop` when the
  Claude Desktop config directory hasn't been created yet (Desktop has
  not been launched).
- Dashboard login page now shows the solo bearer token field first and
  documents `codeledger token show`; OAuth buttons are disabled with
  an inline setup command when the corresponding provider isn't
  configured.

## 0.1.6 — 2026-04-16

### Fixed
- Dashboard accessible at http://localhost:8100 without credentials
- Root route / and /assets/* added to public paths in auth middleware
- Frontend index.html served at root when frontend/dist exists
- Pre-built frontend now bundled in the wheel (backend/frontend_dist/)

## 0.1.5 — 2026-04-16

### Fixed
- Removed all references to codeledger.dev (domain not live yet)
- Replaced with github.com/codeledgerAI/codeledger throughout

## 0.1.4 — 2026-04-16

### Fixed
- **`codeledger serve` on Windows (and any platform) now bails with an
  actionable error when run before `codeledger init`.** Previously the
  CLI fell through to `uvicorn.run("backend.main:app", ...)` which then
  surfaced the cryptic *"Attribute app not found in module
  backend.main"* — caused by `backend/main.py`'s module-level
  `app = create_app()` raising `FileNotFoundError` (no
  `codeledger.toml` to load) and being silently suppressed. The CLI
  now checks for `codeledger.toml` in the current directory before
  invoking uvicorn and prints:

  ```
  CodeLedger is not initialised in this directory.
    Looked for: /full/path/to/codeledger.toml
    Run `codeledger init` here first.
  ```

  Exit code is `2`. After running `codeledger init`, `codeledger serve`
  works as before.

### Verified — no other Windows-startup blockers
- No unix-only signal handlers in `backend/main.py`.
- No `fcntl`/`termios`/`pty`/`grp`/`pwd` imports anywhere.
- No hardcoded `/tmp`, `/var`, `/etc`, `/usr` paths in the CLI or the
  app factory.
- All home-directory references use `Path.home()` (cross-platform).
- `/health` endpoint exists at `backend/main.py:318`, gated outside
  `AuthMiddleware` (per SEC-05) — npm bootstrap probe will resolve.

## 0.1.3 — 2026-04-16

### Fixed
- **Windows compatibility: `asyncpg`** moved from required to the new
  `[postgres]` optional extra. Team-mode PostgreSQL users run
  `pip install codeledger-ai[postgres]`; solo SQLite users no longer
  pay the native-build cost (asyncpg has no Windows wheel on Python
  3.14 as of this release).
- **Windows compatibility: `tiktoken`** moved to the `[tiktoken]`
  optional extra. When tiktoken is absent, `count_tokens` and
  `_truncate_to_tokens` fall back to a character-based approximation
  (~4 chars/token for `cl100k_base` English). Context-budget math
  stays conservative; install tiktoken for exact counts.
- **`uvloop`** was never a direct dependency in this project — no
  change needed.

### Install matrix
- Solo SQLite (default, no compilation):
  `pip install codeledger-ai`
- Team PostgreSQL:
  `pip install codeledger-ai[postgres]`
- Exact token accounting:
  `pip install codeledger-ai[tiktoken]`
- Local embedding fallback (no Ollama):
  `pip install codeledger-ai[local-embed]`
- Everything:
  `pip install codeledger-ai[postgres,tiktoken,local-embed]`

### No behaviour change when the extras are present
Projects that already install `asyncpg` and `tiktoken` (explicitly or
via an extra) see identical behaviour to 0.1.2. Fallbacks engage only
when the optional dependency is not importable.

## 0.1.2 — 2026-04-16

### Fixed
- **Windows compatibility.** Replaced `sqlite-vss` (no Windows wheel
  published) with `sqlite-vec`, the actively-maintained successor by
  the same author. Windows wheels are available for all supported
  CPython versions, so `pip install codeledger-ai` now works on
  Windows, macOS, and Linux without additional native-toolchain
  prerequisites.

### Changed
- Internal vector index now uses `sqlite-vec`'s `vec0` virtual table
  with `distance_metric=cosine` (was `sqlite-vss`'s `vss0` with
  squared-L2). Scoring semantics are preserved: `score = 1 - distance`
  gives cosine similarity in `[-1.0, 1.0]`. Vectors are serialized as
  packed `float32` bytes instead of JSON strings — smaller index size
  for the same data.
- Internal table renamed: `vss_items` → `vec_items`. The
  `SqliteVssStore` class name is retained for API stability.

### Migration
- New installs on 0.1.2 get the new schema automatically.
- Upgrading from 0.1.1 on Linux/macOS: existing vectors live in the
  old `vss_items` virtual table, which no longer exists in 0.1.2. The
  simplest reset is to delete `data/codeledger.db` and re-run
  `codeledger init` for a clean slate — decisions, stories, sessions,
  and provenance records rebuild from source via the change-detection
  backend on the next commit or file save. 0.1.1 was available for
  under a day, so the migration impact is minimal.

## 0.1.1 — 2026-04-16

First real PyPI release. Full MCP server with ~50 tools:
bidirectional code provenance, active context injection via Claude
Code hooks, independent quality harness, drift detection,
tautological-test detection, rollback impact planning. Solo mode
free; team mode with shared decision history. Onboarding walkthrough
at `http://localhost:8100`. Linux and macOS support (Windows blocked
by sqlite-vss native wheel — fixed in 0.1.2).

## 0.0.1 — 0.0.2

Name-reservation placeholders. Yanked.
