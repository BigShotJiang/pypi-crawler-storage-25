#!/usr/bin/env python3
"""Stdlib-only helper: install WhyCode git hooks into a repository.

Runs the same code path as ``whycode init --reinstall-hooks`` but
as a standalone script — useful in CI contexts where the project is
checked out before ``pip install`` has run.

Usage:
    python scripts/install_hooks.py \\
        --server http://127.0.0.1:8100 \\
        --token-file ~/.whycode/hook_token \\
        /path/to/repo
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "repo_root",
        type=Path,
        nargs="?",
        default=Path.cwd(),
        help="Path to the repo (defaults to the current working directory).",
    )
    parser.add_argument(
        "--server",
        default="http://127.0.0.1:8100",
        help="WhyCode server URL the hook will POST to.",
    )
    parser.add_argument(
        "--token-file",
        default=str(Path.home() / ".whycode" / "hook_token"),
        help="Path to the 0600-perm token file the hook reads.",
    )
    args = parser.parse_args()

    # Defer the import so ``--help`` works without an installed package.
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from backend.utils.git_hooks import GitHookError, install_hooks

    try:
        written = install_hooks(
            args.repo_root,
            server_url=args.server.rstrip("/"),
            token_file=args.token_file,
        )
    except GitHookError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    for path in written:
        print(f"Installed: {path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
