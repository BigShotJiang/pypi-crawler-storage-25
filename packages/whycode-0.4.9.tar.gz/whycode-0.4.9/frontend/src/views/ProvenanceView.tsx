import { useState } from "react";
import ReactECharts from "echarts-for-react";
import { useQuery } from "@tanstack/react-query";
import { Network } from "lucide-react";
import { api } from "../api/client";
import { useAppStore } from "../store/appStore";
import { Card, Select } from "../components/ui";

const NODE_COLORS = {
  decision: "#9b7fff",
  commit: "#94a3b8",
  snapshot: "#00d4ff",
  ast: "#10b981",
} as const;

function LegendItem({
  color,
  label,
  shape = "circle",
}: {
  color: string;
  label: string;
  shape?: "circle" | "diamond";
}) {
  return (
    <span className="inline-flex items-center gap-1.5 text-xs text-[var(--text-secondary)]">
      <span
        aria-hidden="true"
        className={`inline-block w-2.5 h-2.5 ${shape === "circle" ? "rounded-full" : ""}`}
        style={{
          background: color,
          transform: shape === "diamond" ? "rotate(45deg)" : undefined,
          boxShadow: `0 0 8px ${color}`,
        }}
      />
      {label}
    </span>
  );
}

export function ProvenanceView() {
  const setActiveTab = useAppStore((s) => s.setActiveTab);
  const { data: decisionsData } = useQuery({
    queryKey: ["decisions"],
    queryFn: () => api.decisions.list(),
  });
  const decisions = decisionsData ?? [];
  const [selected, setSelected] = useState<string | null>(null);
  const { data: tree } = useQuery({
    queryKey: ["provenance-forward", selected],
    queryFn: () =>
      selected ? api.decisions.trace(selected) : Promise.resolve(null),
    enabled: Boolean(selected),
  });

  type GraphNode = {
    id: string;
    name: string;
    symbol: string;
    itemStyle: { color: string; shadowBlur?: number; shadowColor?: string };
    symbolSize: number;
  };
  const nodes: GraphNode[] = [];
  const links: { source: string; target: string }[] = [];
  if (tree) {
    nodes.push({
      id: tree.decision.id,
      name: tree.decision.title || "decision",
      symbol: "circle",
      itemStyle: {
        color: NODE_COLORS.decision,
        shadowBlur: 16,
        shadowColor: NODE_COLORS.decision,
      },
      symbolSize: 28,
    });
    for (const e of tree.change_events ?? []) {
      const eventNodeId = `evt-${e.change_event_id}`;
      // v11: three possible sources. Render the non-git ones with a
      // diamond so the visual cue still distinguishes them from
      // commits; agent-reported nodes inherit the same "non-commit"
      // styling as snapshots for now.
      const isGit = e.change_event_source === "git_commit";
      nodes.push({
        id: eventNodeId,
        name: e.label,
        symbol: isGit ? "circle" : "diamond",
        itemStyle: {
          color: isGit ? NODE_COLORS.commit : NODE_COLORS.snapshot,
          shadowBlur: 10,
          shadowColor: isGit ? NODE_COLORS.commit : NODE_COLORS.snapshot,
        },
        symbolSize: 20,
      });
      links.push({ source: tree.decision.id, target: eventNodeId });
      e.ast_changes.forEach((a, i) => {
        const astId = `ast-${eventNodeId}-${i}`;
        nodes.push({
          id: astId,
          name: String(a.entity_name ?? "ast"),
          symbol: "circle",
          itemStyle: {
            color: NODE_COLORS.ast,
            shadowBlur: 6,
            shadowColor: NODE_COLORS.ast,
          },
          symbolSize: 12,
        });
        links.push({ source: eventNodeId, target: astId });
      });
    }
  }

  const option = {
    backgroundColor: "transparent",
    textStyle: { color: "var(--text-primary)", fontFamily: "Inter, sans-serif" },
    tooltip: {
      backgroundColor: "rgba(15, 31, 58, 0.95)",
      borderColor: "rgba(124, 92, 255, 0.25)",
      textStyle: { color: "#e8f0fe" },
    },
    series: [
      {
        type: "graph",
        layout: "force",
        roam: true,
        label: {
          show: true,
          fontSize: 10,
          color: "var(--text-secondary)",
        },
        lineStyle: {
          color: "rgba(124, 92, 255, 0.3)",
          width: 1.5,
          curveness: 0.1,
        },
        force: { repulsion: 220, edgeLength: 80 },
        data: nodes,
        links,
      },
    ],
  };

  const hasDecisions = decisions.length > 0;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-4 justify-between">
        <p className="text-sm text-[var(--text-secondary)] max-w-2xl">
          A provenance graph shows the sequence of code changes, git commits,
          and AI decisions that led to a particular outcome.
        </p>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <Select
          value={selected ?? ""}
          onChange={(e) => setSelected(e.target.value || null)}
          aria-label="Select decision"
          disabled={!hasDecisions}
          className="w-80"
        >
          <option value="">Select a decision…</option>
          {decisions.map((d) => (
            <option key={d.id} value={d.id}>
              {d.title}
            </option>
          ))}
        </Select>
        <div className="flex items-center gap-3 flex-wrap text-xs text-[var(--text-secondary)]">
          <LegendItem color={NODE_COLORS.decision} label="decision" />
          <LegendItem color={NODE_COLORS.commit} label="git commit" />
          <LegendItem color={NODE_COLORS.snapshot} label="file snapshot" shape="diamond" />
          <LegendItem color={NODE_COLORS.ast} label="AST change" />
        </div>
      </div>

      {!hasDecisions ? (
        <Card
          role="status"
          className="flex flex-col items-center justify-center py-16 px-4 space-y-3 border-dashed"
        >
          <div className="w-12 h-12 rounded-xl bg-[var(--accent-dim)] border border-[var(--border-mid)] flex items-center justify-center">
            <Network size={20} className="text-[var(--accent-bright)]" aria-hidden="true" />
          </div>
          <p className="text-sm text-[var(--text-primary)]">
            No decisions available to visualise.
          </p>
          <p className="text-xs text-[var(--text-secondary)] max-w-md text-center">
            Provenance graphs are generated automatically from decisions logged in the{" "}
            <button
              type="button"
              onClick={() => setActiveTab("decisions")}
              className="text-[var(--accent-bright)] underline focus:ring-2 focus:ring-[var(--accent)] focus:outline-none rounded"
            >
              Decisions tab
            </button>
            .
          </p>
        </Card>
      ) : selected ? (
        <Card className="p-3">
          <ReactECharts option={option} style={{ height: 500 }} />
        </Card>
      ) : (
        <Card
          role="status"
          className="flex flex-col items-center justify-center py-16 px-4 space-y-2"
        >
          <Network
            size={22}
            className="text-[var(--text-tertiary)]"
            aria-hidden="true"
          />
          <p className="text-sm text-[var(--text-secondary)]">
            Pick a decision above to visualise its provenance.
          </p>
        </Card>
      )}
    </div>
  );
}
