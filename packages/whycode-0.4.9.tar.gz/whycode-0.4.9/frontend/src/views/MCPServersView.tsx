import { useEffect, useRef, useState } from "react";
import {
  ChevronDown,
  ChevronRight,
  MoreVertical,
  Server as ServerIcon,
} from "lucide-react";
import { Badge, Button, Card, Input, Select } from "../components/ui";

type Transport = "http" | "sse" | "stdio";
type AuthKind = "oauth" | "api_key" | "none";

interface ServerEntry {
  name: string;
  url: string;
  transport: Transport;
  auth: AuthKind;
  apiKey?: string;
  toolCount: number;
  tools?: string[];
  status: "connected" | "disconnected";
  connectedSince?: string;
}

const LS_MCP_SERVERS = "cl.mcpServers";

const DEFAULT_SERVERS: ServerEntry[] = [
  {
    name: "whycode",
    url: "http://localhost:8100/mcp",
    transport: "http",
    auth: "api_key",
    toolCount: 16,
    tools: undefined,
    status: "connected",
    connectedSince: new Date().toISOString(),
  },
];

function loadServers(): ServerEntry[] {
  if (typeof window === "undefined") return DEFAULT_SERVERS;
  try {
    const raw = window.localStorage.getItem(LS_MCP_SERVERS);
    if (!raw) return DEFAULT_SERVERS;
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) return parsed as ServerEntry[];
  } catch {
    // corrupted payload — fall back to the default seed
  }
  return DEFAULT_SERVERS;
}

const AUTH_LABELS: Record<AuthKind, string> = {
  oauth: "Authenticated via OAuth",
  api_key: "Authenticated via API Key",
  none: "No authentication",
};

const DEFAULT_TOOLS = [
  "context.create",
  "context.read",
  "context.list",
  "decision.create",
  "decision.trace",
  "story.create",
  "story.update",
  "sprint.status",
  "session.start",
  "session.end",
  "verify.status",
  "harness.score",
  "provenance.forward",
  "provenance.reverse",
  "session.conflicts",
  "standup.generate",
];

function ServerCard({
  entry,
  onDisconnect,
  onEdit,
}: {
  entry: ServerEntry;
  onDisconnect: () => void;
  onEdit: () => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!menuOpen) return;
    const onClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [menuOpen]);

  const copyUrl = async () => {
    try {
      await navigator.clipboard.writeText(entry.url);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
    setMenuOpen(false);
  };

  return (
    <Card glow className="overflow-hidden p-0">
      <div className="flex items-center gap-4 p-4">
        <div className="w-10 h-10 rounded-lg bg-[var(--accent-dim)] border border-[var(--border-dim)] flex items-center justify-center">
          <ServerIcon size={18} className="text-[var(--accent-bright)]" aria-hidden="true" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="font-medium text-[var(--text-primary)] truncate">
              {entry.name}
            </span>
            <span
              aria-hidden="true"
              className={`w-1.5 h-1.5 rounded-full ${
                entry.status === "connected"
                  ? "bg-[var(--success)] animate-pulse"
                  : "bg-[var(--danger)]"
              }`}
            />
          </div>
          <div className="text-xs text-[var(--text-secondary)] font-mono truncate">
            {entry.url}
          </div>
          {entry.connectedSince && (
            <div className="text-xs text-[var(--text-tertiary)] font-mono">
              connected since {new Date(entry.connectedSince).toLocaleString()}
            </div>
          )}
        </div>
        <Badge variant="ghost" title={`Transport: ${entry.transport}`}>
          <span className="font-mono">{entry.transport}</span>
        </Badge>
        <Badge variant="cyan" title={AUTH_LABELS[entry.auth]}>
          <span className="font-mono">{entry.auth}</span>
        </Badge>
        <button
          type="button"
          onClick={() => setExpanded((v) => !v)}
          aria-expanded={expanded}
          className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium text-[var(--accent-bright)] border border-[var(--border-dim)] bg-[var(--accent-dim)] hover:border-[var(--border-mid)] transition-all focus:ring-2 focus:ring-[var(--accent)] focus:outline-none"
        >
          {expanded ? (
            <ChevronDown size={12} strokeWidth={2} />
          ) : (
            <ChevronRight size={12} strokeWidth={2} />
          )}
          {entry.toolCount} tools
        </button>
        <div ref={menuRef} className="relative">
          <button
            type="button"
            aria-label="Server actions"
            aria-haspopup="menu"
            onClick={() => setMenuOpen((v) => !v)}
            className="w-8 h-8 rounded-lg flex items-center justify-center border border-[var(--border-dim)] bg-[var(--bg-elevated)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:border-[var(--border-mid)] transition-all focus:ring-2 focus:ring-[var(--accent)] focus:outline-none"
          >
            <MoreVertical size={13} strokeWidth={2} />
          </button>
          {menuOpen && (
            <div className="absolute right-0 top-full mt-1.5 w-40 rounded-lg border border-[var(--border-mid)] bg-[var(--bg-overlay)] shadow-elevated z-20 text-sm overflow-hidden">
              <button
                onClick={() => {
                  onEdit();
                  setMenuOpen(false);
                }}
                className="w-full text-left px-3 py-1.5 text-[var(--text-primary)] hover:bg-[var(--bg-hover)] transition-colors"
              >
                Edit
              </button>
              <button
                onClick={copyUrl}
                className="w-full text-left px-3 py-1.5 text-[var(--text-primary)] hover:bg-[var(--bg-hover)] transition-colors"
              >
                {copied ? "Copied!" : "Copy URL"}
              </button>
              <button
                onClick={() => {
                  onDisconnect();
                  setMenuOpen(false);
                }}
                className="w-full text-left px-3 py-1.5 text-[var(--danger)] hover:bg-[var(--danger-dim)] transition-colors"
              >
                Disconnect
              </button>
            </div>
          )}
        </div>
      </div>
      {expanded && (
        <div
          className="border-t border-[var(--border-dim)] px-4 py-3 overflow-y-auto text-xs text-[var(--text-secondary)] font-mono bg-[var(--bg-base)]"
          style={{ maxHeight: 200 }}
        >
          {(entry.tools ?? DEFAULT_TOOLS).map((t) => (
            <div key={t} className="py-0.5">
              {t}
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}

const BLANK_FORM: Partial<ServerEntry> = {
  transport: "http",
  auth: "none",
  apiKey: "",
};

export function MCPServersView() {
  const [servers, setServers] = useState<ServerEntry[]>(loadServers);
  const [form, setForm] = useState<Partial<ServerEntry>>(BLANK_FORM);
  const [editingName, setEditingName] = useState<string | null>(null);
  const [errors, setErrors] = useState<{ name?: string; url?: string }>({});

  useEffect(() => {
    try {
      window.localStorage.setItem(LS_MCP_SERVERS, JSON.stringify(servers));
    } catch {
      // storage quota / disabled — non-fatal
    }
  }, [servers]);

  const resetForm = () => {
    setForm(BLANK_FORM);
    setEditingName(null);
    setErrors({});
  };

  const removeServer = (name: string) => {
    setServers((prev) => prev.filter((s) => s.name !== name));
    if (editingName === name) resetForm();
  };

  const editServer = (name: string) => {
    const target = servers.find((s) => s.name === name);
    if (!target) return;
    setForm({ ...BLANK_FORM, ...target });
    setEditingName(name);
    setErrors({});
  };

  // stdio transport communicates via local subprocess — no HTTP auth applies
  const authVisible = form.transport !== "stdio";
  const apiKeyVisible = authVisible && form.auth === "api_key";

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        {servers.map((s) => (
          <ServerCard
            key={s.name}
            entry={s}
            onDisconnect={() => removeServer(s.name)}
            onEdit={() => editServer(s.name)}
          />
        ))}
      </div>

      <Card variant="glass" className="p-5">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            const name = form.name?.trim() ?? "";
            const url = form.url?.trim() ?? "";
            const nextErrors: { name?: string; url?: string } = {};
            if (!name) nextErrors.name = "Server name is required";
            if (!url) nextErrors.url = "URL or command is required";
            if (nextErrors.name || nextErrors.url) {
              setErrors(nextErrors);
              return;
            }

            const transport = (form.transport as Transport) ?? "http";
            const auth: AuthKind =
              transport === "stdio" ? "none" : ((form.auth as AuthKind) ?? "none");
            const apiKey = auth === "api_key" ? form.apiKey?.trim() || undefined : undefined;

            setServers((prev) => {
              const existing = prev.find((s) => s.name === (editingName ?? name));
              const urlChanged = existing ? existing.url !== url : false;
              const merged: ServerEntry = existing
                ? {
                    ...existing,
                    name,
                    url,
                    transport,
                    auth,
                    apiKey,
                    ...(urlChanged
                      ? { status: "disconnected", toolCount: 0, tools: undefined, connectedSince: undefined }
                      : {}),
                  }
                : {
                    name,
                    url,
                    transport,
                    auth,
                    apiKey,
                    toolCount: 0,
                    status: "disconnected",
                  };
              const withoutOld = prev.filter((s) => s.name !== (editingName ?? name));
              return [...withoutOld, merged];
            });
            resetForm();
          }}
          className="space-y-3"
        >
          <h3 className="font-display text-base font-semibold text-[var(--text-primary)]">
            {editingName ? `Edit server: ${editingName}` : "Add MCP server"}
          </h3>
          <div>
            <Input
              placeholder="Name"
              aria-label="Server name"
              aria-invalid={Boolean(errors.name)}
              value={form.name ?? ""}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className={errors.name ? "border-[var(--danger)] focus:ring-[var(--danger)]" : ""}
            />
            {errors.name && (
              <p className="mt-1 text-xs text-[var(--danger)]">{errors.name}</p>
            )}
          </div>
          <div>
            <Input
              placeholder="URL or command"
              aria-label="Server URL or command"
              aria-invalid={Boolean(errors.url)}
              value={form.url ?? ""}
              onChange={(e) => setForm({ ...form, url: e.target.value })}
              className={errors.url ? "border-[var(--danger)] focus:ring-[var(--danger)]" : ""}
            />
            {errors.url && (
              <p className="mt-1 text-xs text-[var(--danger)]">{errors.url}</p>
            )}
          </div>
          <div className="flex gap-2">
            <Select
              value={form.transport}
              onChange={(e) => {
                const transport = e.target.value as Transport;
                setForm((prev) => ({
                  ...prev,
                  transport,
                  ...(transport === "stdio" ? { auth: "none", apiKey: "" } : {}),
                }));
              }}
              aria-label="Transport"
              className="w-40"
            >
              <option value="http">HTTP/SSE</option>
              <option value="sse">SSE</option>
              <option value="stdio">stdio</option>
            </Select>
            {authVisible && (
              <Select
                value={form.auth}
                onChange={(e) => {
                  const auth = e.target.value as AuthKind;
                  setForm((prev) => ({
                    ...prev,
                    auth,
                    ...(auth === "api_key" ? {} : { apiKey: "" }),
                  }));
                }}
                aria-label="Authentication"
                className="w-40"
              >
                <option value="none">No auth</option>
                <option value="oauth">OAuth</option>
                <option value="api_key">API key</option>
              </Select>
            )}
            <div className="ml-auto flex gap-2">
              {editingName && (
                <Button
                  type="button"
                  variant="secondary"
                  size="md"
                  onClick={resetForm}
                >
                  Cancel
                </Button>
              )}
              <Button type="submit" variant="primary" size="md">
                {editingName ? "Save changes" : "Connect"}
              </Button>
            </div>
          </div>
          {apiKeyVisible && (
            <Input
              type="password"
              placeholder="API key"
              aria-label="API key"
              autoComplete="off"
              value={form.apiKey ?? ""}
              onChange={(e) => setForm({ ...form, apiKey: e.target.value })}
            />
          )}
        </form>
      </Card>
    </div>
  );
}
