import { useEffect, useState } from "react";
import { AlertTriangle, KeyRound } from "lucide-react";
import { Button, Card, Input } from "../components/ui";

const OAUTH_ERROR_MESSAGES: Record<string, string> = {
  oauth_denied: "Login cancelled at the provider.",
  oauth_csrf: "Security check failed. Start the sign-in again.",
  oauth_invalid: "Invalid response from the provider. Try again.",
  oauth_exchange_failed:
    "Could not complete the sign-in. Check the server logs for details.",
  oauth_userinfo_failed:
    "Provider did not return a profile. Try again or use a bearer token.",
  oauth_no_email:
    "Provider did not return a verified email address for this account.",
  oauth_not_configured:
    "OAuth is not configured on the server. Run whycode config set-oauth.",
};

export function LoginView({ onLogin }: { onLogin: (token: string) => void }) {
  const [token, setToken] = useState("");
  const [oauthHint, setOauthHint] = useState<string | null>(null);

  useEffect(() => {
    // Handle a return trip from /api/auth/oauth/{provider}/callback.
    // The callback writes the JWT to an HttpOnly whycode_session
    // cookie, so the SPA only needs a local marker to flip its auth
    // gate — the cookie itself is invisible to JS by design.
    const params = new URLSearchParams(window.location.search);
    const oauth = params.get("oauth");
    const oauthError = params.get("oauth_error");

    if (oauth === "success") {
      localStorage.setItem("cl.cookie_session", "1");
      localStorage.removeItem("cl.token");
      // Strip the marker so a manual refresh doesn't re-trigger.
      window.history.replaceState(null, "", window.location.pathname);
      onLogin("");
      return;
    }

    if (oauthError) {
      setOauthHint(
        OAUTH_ERROR_MESSAGES[oauthError] ?? "Sign-in failed. Try again.",
      );
      window.history.replaceState(null, "", window.location.pathname);
    }
  }, [onLogin]);

  function startOAuth(provider: "google" | "github") {
    // Buttons are always clickable — Google/GitHub login works
    // out-of-the-box via the WhyCode OAuth relay even when the user
    // has not configured their own OAuth app.
    window.location.href = `/api/auth/oauth/${provider}`;
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4 relative">
      <Card variant="glass" className="w-full max-w-md p-8 space-y-5">
        <div className="flex flex-col items-center space-y-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[var(--accent)] to-[var(--accent-mid)] flex items-center justify-center shadow-accent">
            <svg width="22" height="22" viewBox="0 0 14 14" fill="none" aria-hidden="true">
              <rect x="1" y="2" width="12" height="2" rx="1" fill="white" opacity="0.9" />
              <rect x="1" y="6" width="8" height="2" rx="1" fill="white" opacity="0.7" />
              <rect x="1" y="10" width="10" height="2" rx="1" fill="white" opacity="0.5" />
            </svg>
          </div>
          <h1 className="font-display text-2xl font-semibold text-[var(--text-primary)] tracking-tight">
            Sign in to WhyCode
          </h1>
          <p className="text-xs text-[var(--text-secondary)] text-center max-w-xs">
            Paste your solo bearer token, or sign in with OAuth. Run{" "}
            <code className="font-mono text-[var(--accent-bright)]">
              whycode token show
            </code>{" "}
            to see your token.
          </p>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            const trimmed = token.trim();
            if (trimmed) {
              localStorage.setItem("cl.token", trimmed);
              onLogin(trimmed);
            }
          }}
          className="space-y-3"
        >
          <label
            htmlFor="solo-token"
            className="block text-xs font-medium uppercase tracking-widest text-[var(--text-secondary)]"
          >
            Solo bearer token
          </label>
          <Input
            id="solo-token"
            type="password"
            placeholder="cl_solo_…"
            value={token}
            onChange={(e) => setToken(e.target.value)}
          />
          <Button type="submit" variant="primary" size="md" className="w-full">
            <KeyRound size={14} strokeWidth={2} />
            Sign in with token
          </Button>
        </form>

        <div className="flex items-center gap-3 text-xs text-[var(--text-tertiary)]">
          <div className="flex-1 h-px bg-[var(--border-dim)]" />
          <span>or continue with</span>
          <div className="flex-1 h-px bg-[var(--border-dim)]" />
        </div>

        <div className="grid grid-cols-2 gap-2">
          <Button
            type="button"
            variant="secondary"
            size="md"
            onClick={() => startOAuth("google")}
          >
            Google
          </Button>
          <Button
            type="button"
            variant="secondary"
            size="md"
            onClick={() => startOAuth("github")}
          >
            GitHub
          </Button>
        </div>

        {oauthHint && (
          <div className="flex items-start gap-2 text-xs text-[var(--warning)] bg-[var(--warning-dim)] border border-[rgba(245,158,11,0.25)] rounded-md p-3">
            <AlertTriangle size={13} strokeWidth={2} className="flex-shrink-0 mt-0.5" />
            <span>{oauthHint}</span>
          </div>
        )}
      </Card>
    </div>
  );
}
