import { useEffect, useState } from "react";
import {
  CheckCircle2,
  CircleDot,
  Database,
  ExternalLink,
  MessageSquare,
  Plug,
  Briefcase,
  Folder,
  type LucideIcon,
} from "lucide-react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "../api/client";
import { Badge, Button, Card, Input } from "../components/ui";

type AuthType = "oauth2" | "api_key" | "connection_string" | "basic";

interface CredentialField {
  key: string;
  label: string;
  placeholder: string;
  type: "text" | "password" | "number" | "select";
  required: boolean;
  help_text: string;
  options: string[];
}

interface ConnectorRow {
  slug: string;
  display_name: string;
  category: string;
  description: string;
  auth_type: AuthType;
  configured: boolean;
  connect_url: string | null;
  credential_fields?: CredentialField[];
  driver_available?: boolean;
  driver_install_hint?: string;
}

const CATEGORY_ICON: Record<string, LucideIcon> = {
  communication: MessageSquare,
  project_management: Briefcase,
  cloud_storage: Folder,
  database: Database,
  ci_cd: Plug,
  analytics: Plug,
};

const CATEGORY_LABEL: Record<string, string> = {
  communication: "Communication",
  project_management: "Project management",
  cloud_storage: "Cloud storage",
  database: "Database",
  ci_cd: "CI / CD",
  analytics: "Analytics",
};

const CATEGORY_ORDER = [
  "communication",
  "project_management",
  "cloud_storage",
  "database",
  "ci_cd",
  "analytics",
];

function groupByCategory(
  connectors: ConnectorRow[],
): Array<[string, ConnectorRow[]]> {
  const groups = new Map<string, ConnectorRow[]>();
  for (const c of connectors) {
    const key = c.category || "other";
    const bucket = groups.get(key) ?? [];
    bucket.push(c);
    groups.set(key, bucket);
  }
  return CATEGORY_ORDER.filter((c) => groups.has(c)).map(
    (c) => [c, groups.get(c)!] as [string, ConnectorRow[]],
  );
}

function ConnectorCard({
  row,
  onChanged,
}: {
  row: ConnectorRow;
  onChanged: () => void;
}) {
  const [setupOpen, setSetupOpen] = useState(false);
  const [fieldValues, setFieldValues] = useState<Record<string, string>>({});
  const [credentialValue, setCredentialValue] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const Icon = CATEGORY_ICON[row.category] ?? Plug;
  const schemaFields = row.credential_fields ?? [];
  const driverAvailable = row.driver_available !== false;

  const startOAuth = () => {
    if (!row.connect_url) return;
    window.location.href = row.connect_url;
  };

  const handleSubmitSetup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      if (schemaFields.length > 0) {
        const missing = schemaFields
          .filter((f) => f.required && !(fieldValues[f.key] ?? "").trim())
          .map((f) => f.label);
        if (missing.length > 0) {
          setError(`Required: ${missing.join(", ")}`);
          setSubmitting(false);
          return;
        }
        await api.connectors.setup(row.slug, fieldValues);
      } else {
        if (!credentialValue.trim()) {
          setError("Value is required");
          setSubmitting(false);
          return;
        }
        const field =
          row.auth_type === "api_key" ? "api_key" : "connection_string";
        await api.connectors.setup(row.slug, { [field]: credentialValue });
      }
      setCredentialValue("");
      setFieldValues({});
      setSetupOpen(false);
      onChanged();
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "Setup failed";
      setError(message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDisconnect = async () => {
    if (
      !window.confirm(
        `Disconnect ${row.display_name}? Stored credentials will be cleared.`,
      )
    ) {
      return;
    }
    try {
      await api.connectors.disconnect(row.slug);
      onChanged();
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "Disconnect failed";
      setError(message);
    }
  };

  const placeholder =
    row.auth_type === "api_key"
      ? "Paste API key"
      : "JSON config or DSN (see connector docs)";

  return (
    <Card glow className="p-4 flex flex-col gap-3">
      <div className="flex items-start gap-3">
        <div className="w-9 h-9 rounded-lg bg-[var(--accent-dim)] border border-[var(--border-dim)] flex items-center justify-center">
          <Icon
            size={16}
            className="text-[var(--accent-bright)]"
            aria-hidden="true"
          />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="font-medium text-[var(--text-primary)] truncate">
              {row.display_name}
            </span>
            {row.configured && (
              <CheckCircle2
                size={14}
                className="text-[var(--success)] shrink-0"
                aria-label="Configured"
              />
            )}
          </div>
          <div className="text-xs text-[var(--text-secondary)] mt-0.5 line-clamp-2">
            {row.description || row.slug}
          </div>
        </div>
        <Badge variant="ghost" title={row.auth_type}>
          <span className="font-mono text-[10px]">{row.auth_type}</span>
        </Badge>
      </div>

      <div className="flex items-center gap-2">
        {row.configured ? (
          <Button
            type="button"
            variant="secondary"
            size="sm"
            onClick={handleDisconnect}
          >
            Disconnect
          </Button>
        ) : !driverAvailable ? (
          <Button type="button" variant="secondary" size="sm" disabled>
            Driver not installed
          </Button>
        ) : row.auth_type === "oauth2" ? (
          <Button
            type="button"
            variant="primary"
            size="sm"
            onClick={startOAuth}
            disabled={!row.connect_url}
          >
            <ExternalLink size={11} strokeWidth={2} />
            Connect
          </Button>
        ) : (
          <Button
            type="button"
            variant="primary"
            size="sm"
            onClick={() => setSetupOpen((v) => !v)}
          >
            <Plug size={11} strokeWidth={2} />
            {setupOpen ? "Cancel" : "Connect"}
          </Button>
        )}
      </div>

      {!driverAvailable && row.driver_install_hint && (
        <p className="text-[11px] text-[var(--text-tertiary)] font-mono bg-[var(--bg-elevated,rgba(0,0,0,0.04))] rounded px-2 py-1">
          {row.driver_install_hint}
        </p>
      )}

      {setupOpen && !row.configured && row.auth_type !== "oauth2" && driverAvailable && (
        <form onSubmit={handleSubmitSetup} className="space-y-3">
          {schemaFields.length > 0 ? (
            schemaFields.map((field) => (
              <div key={field.key} className="space-y-1">
                <label
                  htmlFor={`${row.slug}-${field.key}`}
                  className="text-xs text-[var(--text-secondary)] block"
                >
                  {field.label}
                  {field.required && (
                    <span className="text-[var(--danger)]"> *</span>
                  )}
                </label>
                <Input
                  id={`${row.slug}-${field.key}`}
                  type={field.type === "password" ? "password" : field.type === "number" ? "number" : "text"}
                  autoComplete="off"
                  placeholder={field.placeholder}
                  value={fieldValues[field.key] ?? ""}
                  onChange={(e) =>
                    setFieldValues((v) => ({ ...v, [field.key]: e.target.value }))
                  }
                  aria-label={field.label}
                />
                {field.help_text && (
                  <p className="text-[10px] text-[var(--text-tertiary)] leading-snug">
                    {field.help_text}
                  </p>
                )}
              </div>
            ))
          ) : (
            <Input
              type="password"
              autoComplete="off"
              placeholder={placeholder}
              value={credentialValue}
              onChange={(e) => setCredentialValue(e.target.value)}
              aria-label={`${row.display_name} credential`}
            />
          )}
          <div className="flex items-center gap-2">
            <Button
              type="submit"
              variant="primary"
              size="sm"
              disabled={submitting}
            >
              {submitting ? "Connecting…" : "Save"}
            </Button>
            <p className="text-[10px] text-[var(--text-tertiary)]">
              Stored encrypted in the local vault — never sent to third parties.
            </p>
          </div>
          {error && (
            <p className="text-xs text-[var(--danger)]">{error}</p>
          )}
        </form>
      )}

      {error && !setupOpen && (
        <p className="text-xs text-[var(--danger)]">{error}</p>
      )}
    </Card>
  );
}

const OAUTH_ERROR_MESSAGES: Record<string, string> = {
  oauth_denied: "Connection cancelled in the provider login screen.",
  oauth_invalid: "Invalid response from the provider. Try again.",
  oauth_csrf: "Security check failed — please try connecting again.",
  oauth_exchange_failed: "Could not exchange the auth code for a token. Check that your Client Secret is correct.",
  oauth_pkce_missing: "PKCE verifier cookie was missing. Try connecting again in the same browser tab.",
  oauth_unconfigured: "OAuth configuration is incomplete. Re-check your Client ID and Client Secret.",
  oauth_unknown_connector: "Connector not registered on this server.",
};

export function ConnectorsView() {
  const queryClient = useQueryClient();
  const { data, isLoading, error } = useQuery({
    queryKey: ["connectors-status"],
    queryFn: () => api.connectors.status(),
    retry: false,
  });
  const [banner, setBanner] = useState<
    { kind: "success" | "error"; text: string } | null
  >(null);

  const refresh = () =>
    queryClient.invalidateQueries({ queryKey: ["connectors-status"] });

  // The OAuth callback redirects the browser back to the dashboard with
  // ?connector_connected=<slug> on success or ?connector_error=<reason>&connector=<slug>
  // on failure. Read those once on mount, surface a banner, then strip the
  // params so a subsequent refresh doesn't re-show the message.
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const connected = params.get("connector_connected");
    const errReason = params.get("connector_error");
    const errSlug = params.get("connector");

    if (connected) {
      setBanner({ kind: "success", text: `${connected} connected.` });
      refresh();
    } else if (errReason) {
      const msg = OAUTH_ERROR_MESSAGES[errReason] ?? errReason;
      const who = errSlug ? `Could not connect ${errSlug}` : "Connection failed";
      setBanner({ kind: "error", text: `${who}: ${msg}` });
    }
    if (connected || errReason) {
      const clean = window.location.pathname + window.location.hash;
      window.history.replaceState(null, "", clean);
    }
    // Mount-only — callback redirects land here once per flow.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (isLoading) {
    return (
      <div className="p-6 text-sm text-[var(--text-secondary)]">
        Loading connectors…
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="p-6 text-sm text-[var(--danger)]">
        Failed to load connectors. Is the server reachable?
      </div>
    );
  }

  const connectors = data.connectors;
  const connected = connectors.filter((c) => c.configured);
  const available = connectors.filter((c) => !c.configured);
  const availableGrouped = groupByCategory(available);

  return (
    <div className="space-y-8">
      {banner && (
        <div
          role="status"
          className={
            banner.kind === "success"
              ? "rounded-md border border-[var(--success)] bg-[var(--success-dim,rgba(16,185,129,0.08))] px-3 py-2 text-sm text-[var(--success)]"
              : "rounded-md border border-[var(--danger)] bg-[var(--danger-dim,rgba(220,38,38,0.08))] px-3 py-2 text-sm text-[var(--danger)]"
          }
        >
          <button
            type="button"
            onClick={() => setBanner(null)}
            aria-label="Dismiss"
            className="float-right text-xs text-[var(--text-tertiary)] hover:text-[var(--text-primary)]"
          >
            ×
          </button>
          {banner.text}
        </div>
      )}
      {connected.length > 0 && (
        <section className="space-y-3">
          <h2 className="text-xs font-semibold uppercase tracking-widest text-[var(--text-secondary)] flex items-center gap-2">
            <CircleDot
              size={13}
              className="text-[var(--success)]"
              aria-hidden="true"
            />
            Connected ({connected.length})
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {connected.map((row) => (
              <ConnectorCard key={row.slug} row={row} onChanged={refresh} />
            ))}
          </div>
        </section>
      )}

      <section className="space-y-5">
        <h2 className="text-xs font-semibold uppercase tracking-widest text-[var(--text-secondary)] flex items-center gap-2">
          <Plug
            size={13}
            className="text-[var(--accent-bright)]"
            aria-hidden="true"
          />
          Available ({available.length})
        </h2>
        {availableGrouped.length === 0 && (
          <p className="text-sm text-[var(--text-secondary)]">
            Every registered connector is already configured.
          </p>
        )}
        {availableGrouped.map(([category, rows]) => (
          <div key={category} className="space-y-2">
            <h3 className="text-xs font-medium text-[var(--text-tertiary)]">
              {CATEGORY_LABEL[category] ?? category}
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {rows.map((row) => (
                <ConnectorCard key={row.slug} row={row} onChanged={refresh} />
              ))}
            </div>
          </div>
        ))}
      </section>
    </div>
  );
}
