import { useEffect, useState } from "react";
import { Compass } from "lucide-react";
import { Card } from "../components/ui";
import { api } from "../api/client";

const MIN_DECISIONS_FOR_MAP = 5;

export function ExplorerView() {
  const [decisionCount, setDecisionCount] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    api.decisions
      .list()
      .then((rows) => {
        if (cancelled) return;
        setDecisionCount(Array.isArray(rows) ? rows.length : 0);
      })
      .catch((exc) => {
        if (cancelled) return;
        setError(exc instanceof Error ? exc.message : "Failed to load decisions");
        setDecisionCount(0);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const message = (() => {
    if (error) {
      return `Could not load decision count (${error}). Try again once the server is reachable.`;
    }
    if (decisionCount === null) {
      return "Loading…";
    }
    if (decisionCount < MIN_DECISIONS_FOR_MAP) {
      return `Record at least ${MIN_DECISIONS_FOR_MAP} decisions to populate the semantic map (currently ${decisionCount}).`;
    }
    return "Embedding index is being built. The semantic map will appear here once decisions and context items have been embedded.";
  })();

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 text-sm text-[var(--text-secondary)]">
        <Compass size={14} className="text-[var(--accent-bright)]" aria-hidden="true" />
        2D UMAP projection of embedded context items.
      </div>

      <Card className="flex flex-col items-center justify-center gap-3 border-dashed py-20 px-6 text-center">
        <p className="text-base font-medium text-[var(--text-primary)]">
          Semantic map
        </p>
        <p className="max-w-md text-sm leading-relaxed text-[var(--text-secondary)]">
          {message}
        </p>
      </Card>
    </div>
  );
}
