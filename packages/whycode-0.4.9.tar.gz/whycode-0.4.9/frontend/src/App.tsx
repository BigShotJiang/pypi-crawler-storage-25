import { useState, useEffect } from "react";
import { Layout } from "./components/Layout";
import { LoginView } from "./views/LoginView";
import { MemoryView } from "./views/MemoryView";
import { DecisionsView } from "./views/DecisionsView";
import { SprintView } from "./views/SprintView";
import { SessionsView } from "./views/SessionsView";
import { ExplorerView } from "./views/ExplorerView";
import { ProvenanceView } from "./views/ProvenanceView";
import { MCPServersView } from "./views/MCPServersView";
import { ConnectorsView } from "./views/ConnectorsView";
import { SettingsView } from "./views/SettingsView";
import { OnboardingView } from "./views/OnboardingView";
import { useAppStore } from "./store/appStore";

// `whycode dashboard` opens the UI with the solo token in a hash
// fragment (`#token=...`). Fragments never hit the server, so the token
// stays out of access logs. Consume it once at module load — before the
// App component mounts — move it into localStorage, and scrub the URL
// so the token doesn't linger in browser history.
(function consumeTokenFromUrl() {
  try {
    const hash = window.location.hash;
    if (!hash.startsWith("#")) return;
    const params = new URLSearchParams(hash.slice(1));
    const token = params.get("token");
    if (!token) return;
    localStorage.setItem("cl.token", token);
    const clean = window.location.pathname + window.location.search;
    window.history.replaceState(null, "", clean);
  } catch {
    // Best-effort — fall through to the normal login flow on any error.
  }
})();

type SetupState = "loading" | "onboarding" | "dashboard";

export default function App() {
  const activeTab = useAppStore((s) => s.activeTab);
  const [authed, setAuthed] = useState<boolean>(() =>
    Boolean(
      localStorage.getItem("cl.token") ||
        localStorage.getItem("cl.cookie_session"),
    ),
  );
  const [setupState, setSetupState] = useState<SetupState>("loading");

  useEffect(() => {
    // Keep auth state in sync if the token is removed elsewhere.
    const onStorage = () =>
      setAuthed(
        Boolean(
          localStorage.getItem("cl.token") ||
            localStorage.getItem("cl.cookie_session"),
        ),
      );
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  useEffect(() => {
    // On every load, (a) check the server instance id and wipe local
    // auth markers if the server has restarted since we last saw it,
    // then (b) ask whether onboarding still needs to run. Both
    // endpoints are unauthenticated so this works before the developer
    // has configured any credentials.
    let cancelled = false;

    const reconcileInstance = async (): Promise<void> => {
      try {
        const res = await fetch("/api/server/instance");
        if (!res.ok) return;
        const data = (await res.json()) as { instance_id?: string };
        const current = data?.instance_id;
        if (!current) return;
        const stored = localStorage.getItem("cl.server_instance");
        if (stored !== current) {
          // Server restarted (or first ever load). Any session bound to
          // the previous instance is rejected server-side; clear the
          // browser markers so the LoginView renders.
          localStorage.removeItem("cl.token");
          localStorage.removeItem("cl.cookie_session");
          localStorage.setItem("cl.server_instance", current);
          setAuthed(false);
        }
      } catch {
        // Network error — leave markers alone; the 401 handler in
        // client.ts will clean up if the credentials are actually dead.
      }
    };

    const loadSetupStatus = async (): Promise<void> => {
      try {
        const res = await fetch("/api/setup/status");
        const data = await res.json();
        if (cancelled) return;
        setSetupState(data?.setup_complete ? "dashboard" : "onboarding");
      } catch {
        if (cancelled) return;
        setSetupState("dashboard");
      }
    };

    (async () => {
      await reconcileInstance();
      await loadSetupStatus();
    })();

    return () => {
      cancelled = true;
    };
  }, []);

  if (setupState === "loading") {
    return (
      <div className="min-h-screen flex items-center justify-center text-muted">
        Loading WhyCode…
      </div>
    );
  }

  if (setupState === "onboarding") {
    return (
      <OnboardingView onComplete={() => setSetupState("dashboard")} />
    );
  }

  if (!authed) {
    return <LoginView onLogin={() => setAuthed(true)} />;
  }

  return (
    <Layout>
      {activeTab === "memory" && <MemoryView />}
      {activeTab === "decisions" && <DecisionsView />}
      {activeTab === "sprint" && <SprintView />}
      {activeTab === "sessions" && <SessionsView />}
      {activeTab === "explorer" && <ExplorerView />}
      {activeTab === "provenance" && <ProvenanceView />}
      {activeTab === "mcp" && <MCPServersView />}
      {activeTab === "connectors" && <ConnectorsView />}
      {activeTab === "settings" && <SettingsView />}
    </Layout>
  );
}
