# WhyCode — Phase Execution Guide

This document is your operational playbook for driving each phase in Claude Code. Each phase lists the exact prompts to give Claude Code, the expected outputs, the verification steps you run manually, and the gate checklist that must clear before moving on.

---

## Pre-Phase Setup (Run Once)

```bash
mkdir -p ~/whycode && cd ~/whycode
git init && git checkout -b main
git remote add origin git@github.com:deepsaini80537/codeledge.git
```

**Create `.gitignore` BEFORE anything else. First file, first commit.**

**Prompt for Claude Code:**
> Read CLAUDE.md. Create a .gitignore file for this project. It must exclude: whycode.toml, all .env files, all .enc files, the data/ directory, the ~/.whycode/ directory, __pycache__/, *.pyc, node_modules/, dist/, .vite/, coverage/, .mypy_cache/, .ruff_cache/, .pytest_cache/, *.egg-info/, build/. Do NOT exclude: whycode.toml.example, providers.toml, CLAUDE.md, LICENSE, README.md. Then create the LICENSE file with the full Apache 2.0 text. Then create an initial README.md with a one-paragraph project description, the stack list, and a "Development is tracked in CLAUDE.md" note.

**Verify:** .gitignore covers all sensitive paths. `whycode.toml.example` and `providers.toml` are NOT excluded.

```bash
git add .gitignore LICENSE README.md CLAUDE.md
git commit -m "[P0] Repository setup: gitignore, license, readme, project spec"
git push -u origin main
```

**Enable branch protection on GitHub:** Settings → Branches → Add rule → `main` → Require PR review → Require status checks → Save.

**Prompt for Claude Code:**
> Read CLAUDE.md. Create the pyproject.toml with all backend dependencies listed in the Dependencies section, pinned to compatible versions. Include watchdog in the dependencies. Create the directory structure exactly as shown in the Repository Structure section — all directories and empty __init__.py files. Create whycode.toml.example with documented configuration options, including a change_detection_backend field (values: "git" or "file_watcher", set automatically by whycode init). Create providers.toml with pre-configured entries for Google, GitHub, GitLab, Atlassian, Slack, Linear, and Notion. Do not write any application code yet — only scaffolding.

**Verify:**
- Directory tree matches CLAUDE.md exactly, including `file_watcher.py` and `snapshot_store.py` in `backend/utils/`
- `pip install -e ".[dev]"` succeeds with no conflicts
- All `__init__.py` files exist
- `providers.toml` has all seven providers

**Commit:** `[P0] Project scaffolding, dependencies, config example, provider registry`

---

## Phase 1 — Foundation

### Module 1.1: config.py

**Prompt:**
> Read CLAUDE.md. Implement backend/config.py. It loads whycode.toml using tomllib, provides frozen dataclasses for all config sections (ServerConfig, DatabaseConfig, AuthConfig, EmbeddingConfig, CredentialConfig, GitConfig, ChangeDetectionConfig, WhyCodeConfig). ChangeDetectionConfig has: backend (Literal["git", "file_watcher"]), watch_extensions (list[str], default: [".py", ".ts", ".tsx", ".js", ".go", ".rs", ".java", ".c", ".cpp", ".rb", ".cs"]), debounce_ms (int, default: 100), ignore_patterns (list[str], default: [".git", "node_modules", "dist", "__pycache__", "data"]). Enforce: file permission validation (no world-readable), path traversal prevention (reject paths escaping project root via ../), secrets referenced by env var name only. Include a load_config() function. Then implement tests/unit/test_config.py covering: valid config loading, permission rejection, path traversal rejection, missing file handling, default values, env var resolution, and ChangeDetectionConfig defaults.

**Verify:** `pytest tests/unit/test_config.py -v` — all pass.

**Commit:** `[P1] Config loader with permission, path traversal validation, and change detection config`

### Module 1.2: models.py

**Prompt:**
> Read CLAUDE.md. Implement backend/models.py. Define dataclasses for: User, Decision, Story, Sprint, Session, ContextItem, Verification, ASTChange, ProvenanceEdge, ServiceConnection, PersonalAccessToken, UnlinkedCommit, UnlinkedFileChange, FileSnapshot.
>
> Key designs:
>
> ASTChange has: id (UUID), file_path, change_type (function_added/function_removed/function_modified/class_added/class_removed/import_added/import_removed/signature_changed), entity_name, details, change_event_id (str), change_event_type (Literal["git_commit", "file_snapshot"]), project_id, created_at, updated_at.
>
> ProvenanceEdge has: id (UUID), decision_id, change_event_id (str), change_event_type (Literal["git_commit", "file_snapshot"]), confidence, project_id, created_at, updated_at.
>
> UnlinkedCommit has: id (UUID), commit_hash, project_id, detected_at, structurally_changed_symbols (list[str]), session_id (nullable), override_reason (nullable), created_at, updated_at.
>
> UnlinkedFileChange has: id (UUID), snapshot_id (str — the after_snapshot_id), file_path, project_id, detected_at, structurally_changed_symbols (list[str]), session_id (nullable), override_reason (nullable), created_at, updated_at.
>
> FileSnapshot has: id (UUID), project_id, file_path, content_hash (SHA-256 of content), content (str), snapshot_at (datetime), session_id (nullable).
>
> Decision has: id, title, description, tags, status (unverified/pending/passed/failed), recorded_by_user_id, recorded_in_session_id, created_at, updated_at.
>
> Story has: id, title, description, acceptance_criteria (list[str]), status (backlog/in_progress/review/done), points, sprint_id, created_at, updated_at.
>
> Session has: id, user_id, agent_name, started_at, ended_at, status (active/idle/completed/completed_forced), files_touched (list[str]), change_detection_backend (Literal["git", "file_watcher"]), created_at, updated_at.
>
> Then implement tests/unit/test_models.py covering all models, serialization round-trips, and the change_event_type literal constraint.

**Verify:** `pytest tests/unit/test_models.py -v` — all pass.

**Commit:** `[P1] Data models with change_event abstraction for git and file_watcher backends`

### Module 1.3: log_sanitizer.py

**Prompt:**
> Read CLAUDE.md. Implement backend/utils/log_sanitizer.py. It wraps Python's logging module and redacts any string matching credential patterns: Bearer tokens (Bearer eyJ...), API keys (sk-..., sk_..., ghp_..., gho_..., xoxb-..., xoxp-...), JWTs (eyJ...\.eyJ...\.xxx), generic tokens (token=xxx, key=xxx, secret=xxx, password=xxx). Replacement text is "[REDACTED]". Provide a setup_logging() function that configures the root logger with the sanitizing formatter. Then implement tests/security/test_no_creds_in_logs.py that logs messages containing fake credentials and asserts the output contains "[REDACTED]" and not the original values.

**Verify:** `pytest tests/security/test_no_creds_in_logs.py -v` — all pass.

**Commit:** `[P1] Log sanitizer with credential pattern redaction`

### Module 1.4: credential_manager.py

**Prompt:**
> Read CLAUDE.md. Implement backend/auth/credential_manager.py. Unified API: get(provider, key), set(provider, key, value), delete(provider, key), rotate(provider, key, new_value). Three backends: (1) OS keyring — service name format "whycode:{provider}", (2) AES-256-GCM encrypted file vault — PBKDF2 key derivation, 600,000 iterations, random salt, (3) environment variables — pattern WHYCODE_CRED_{PROVIDER}_{KEY}. Priority: env vars first, keyring second, file vault third. rotate() is atomic — new value written before old deleted. Then implement tests/unit/test_credential_manager.py testing all three backends, rotation atomicity, and missing key handling. Also implement tests/security/test_file_permissions.py verifying vault files are created with 600 permissions.

**Verify:** `pytest tests/unit/test_credential_manager.py tests/security/test_file_permissions.py -v` — all pass.

**Commit:** `[P1] Credential manager with keyring, file vault, and env backends`

### Module 1.5: oauth_manager.py

**Prompt:**
> Read CLAUDE.md. Implement backend/auth/oauth_manager.py. Loads providers from providers.toml. Supports: (1) Browser OAuth with PKCE S256 and state validation, (2) Device authorization flow, (3) Manual API key. Token lifecycle: auto-refresh access tokens before expiry. Access tokens held in memory only. Then implement tests/security/test_oauth_state.py, tests/security/test_pkce.py, tests/integration/test_oauth_flow.py (mock provider, full browser flow), tests/integration/test_device_auth_flow.py.

**Verify:** `pytest tests/security/test_oauth_state.py tests/security/test_pkce.py tests/integration/test_oauth_flow.py tests/integration/test_device_auth_flow.py -v` — all pass.

**Commit:** `[P1] OAuth manager with browser flow, device flow, PKCE, state validation`

### Module 1.6: auth_service.py + auth_middleware.py

**Prompt:**
> Read CLAUDE.md. Implement backend/auth/auth_service.py. Handles: (1) Google OIDC sign-in — validate ID token, extract profile, create or find user. (2) GitHub OAuth sign-in — exchange code, fetch profile, discard token, create or find user. (3) Email/password registration and login — Argon2id (64MB memory, 3 iterations, parallelism 4). (4) JWT session issuance — HMAC-SHA256, 24h expiry, signing key from vault. (5) PAT creation — cryptographically random token, SHA-256 hash stored in DB, plaintext returned once. (6) PAT validation — hash incoming, compare stored.
>
> Implement backend/auth/auth_middleware.py. Extracts auth from: HttpOnly cookie (dashboard), Authorization Bearer header (MCP clients), WHYCODE_TOKEN env var (CI). Validates JWT or PAT. Injects user into request state. Returns 401 on failure. Exceptions: /health (unauthenticated), /api/hooks/post-commit (webhook secret auth), /api/hooks/file-change (webhook secret auth).
>
> Implement tests/security/test_auth_enforcement.py — all routes return 401 without auth (webhook endpoints verified separately with and without webhook secret). Implement tests/security/test_pat_hashing.py.

**Verify:** `pytest tests/security/ -v` — all security tests pass.

**Commit:** `[P1] Auth service (Google, GitHub, email/password, JWT, PAT) + middleware`

### Module 1.7: db_backend.py + migrations.py

**Prompt:**
> Read CLAUDE.md. Implement backend/db/db_backend.py. Abstract DatabaseBackend with async methods: insert, get_by_id, query, update, delete, execute_raw. SQLiteBackend (aiosqlite, WAL mode) and PostgreSQLBackend (asyncpg, connection pooling). All queries parameterized — no string concatenation.
>
> Implement backend/db/migrations.py. Idempotent schema creation. Tables: users, decisions, stories, sprints, sessions, context_items, verifications, ast_changes, provenance_edges, service_connections, personal_access_tokens, session_events, unlinked_commits, unlinked_file_changes, file_snapshots, _migrations.
>
> ast_changes table schema: id, file_path, change_type, entity_name, details, change_event_id (TEXT), change_event_type (TEXT CHECK IN ('git_commit','file_snapshot')), project_id, created_at, updated_at.
>
> provenance_edges table schema: id, decision_id, change_event_id (TEXT), change_event_type (TEXT CHECK IN ('git_commit','file_snapshot')), confidence, project_id, created_at, updated_at.
>
> unlinked_commits table: id, commit_hash, project_id, detected_at, structurally_changed_symbols (JSON), session_id (nullable), override_reason (nullable), created_at, updated_at.
>
> unlinked_file_changes table: id, snapshot_id, file_path, project_id, detected_at, structurally_changed_symbols (JSON), session_id (nullable), override_reason (nullable), created_at, updated_at.
>
> file_snapshots table: id, project_id, file_path, content_hash, content (TEXT), snapshot_at, session_id (nullable), created_at, updated_at.
>
> Additive-only migrations — never drop columns or tables. Migration version tracked in _migrations.
>
> Implement tests/unit/test_db_backend.py and tests/security/test_no_creds_in_db.py.

**Verify:** `pytest tests/unit/test_db_backend.py tests/security/test_no_creds_in_db.py -v` — all pass. Run against both SQLite and PostgreSQL.

**Commit:** `[P1] Database backend + migrations with change_event abstraction tables`

### Module 1.8: snapshot_store.py

**Prompt:**
> Read CLAUDE.md. We are in Phase 1, Module 1.8. Implement backend/utils/snapshot_store.py. This module provides file content snapshotting for the non-git change detection backend.
>
> Class SnapshotStore with constructor taking DatabaseBackend. Methods:
>
> take_snapshot(file_path: str, project_id: str, session_id: str | None) -> FileSnapshot: reads the current content of file_path, computes SHA-256 hash of content, compares against the most recent snapshot for this file_path and project_id. If the content hash differs (or no prior snapshot exists), inserts a new FileSnapshot record and returns it. If content is unchanged, returns the existing snapshot without inserting a duplicate. Raises FileNotFoundError if the file does not exist. Raises PermissionError if the file cannot be read.
>
> get_last_snapshot(file_path: str, project_id: str) -> FileSnapshot | None: returns the most recent FileSnapshot for this file and project, or None if no snapshot exists.
>
> diff_snapshots(before_snapshot_id: str, after_snapshot_id: str) -> str: fetches both snapshots from the database, generates a unified diff string (using Python's difflib.unified_diff) between before_content and after_content. Returns an empty string if content is identical. The diff string format is compatible with ast_tracker.parse_diff.
>
> delete_old_snapshots(file_path: str, project_id: str, keep_last_n: int = 10): deletes all but the most recent keep_last_n snapshots for a given file and project. Prevents unbounded growth of the file_snapshots table.
>
> Then implement tests/unit/test_snapshot_store.py. Test: snapshot creation on first call, no duplicate insertion when content unchanged, new snapshot inserted when content changes, diff_snapshots produces correct unified diff for known before/after content, diff_snapshots returns empty string for identical content, delete_old_snapshots keeps only the requested count, FileNotFoundError raised for missing file.

**Verify:** `pytest tests/unit/test_snapshot_store.py -v` — all pass.

**Commit:** `[P1] Snapshot store for non-git file content diffing`

### Module 1.9: file_watcher.py

**Prompt:**
> Read CLAUDE.md. We are in Phase 1, Module 1.9. Implement backend/utils/file_watcher.py. This module provides watchdog-based file change detection for non-git projects.
>
> Class WhyCodeFileWatcher with constructor taking: project_root (Path), project_id (str), server_url (str), config (ChangeDetectionConfig). Methods:
>
> start() -> None: creates a watchdog Observer with a WhyCodeEventHandler and starts it watching project_root recursively. The observer runs in a daemon thread. Does not block.
>
> stop() -> None: stops the watchdog observer cleanly.
>
> is_running() -> bool: returns True if the observer is alive.
>
> Class WhyCodeEventHandler(FileSystemEventHandler) with constructor taking project_id, server_url, config, and a SnapshotStore instance. Implements on_modified(event): ignores directories, ignores files not matching config.watch_extensions, ignores files matching config.ignore_patterns (path prefix match), debounces rapid saves (only fires once per file within config.debounce_ms milliseconds using a threading.Timer per file path). On debounce trigger: calls snapshot_store.take_snapshot for the modified file. If the snapshot is new (content changed): calls snapshot_store.get_last_snapshot to retrieve the prior snapshot. If a prior snapshot exists, calls snapshot_store.diff_snapshots and sends a POST to {server_url}/api/hooks/file-change with the payload: {file_path, project_id, before_snapshot_id, after_snapshot_id, active_session_id (None if no session active — queried from server)}. If no prior snapshot exists (first time this file has been seen), sends the hook with before_snapshot_id: None to indicate a new file baseline. Handles connection errors from the server gracefully — logs a warning, does not raise.
>
> The file watcher registers only on files with extensions in config.watch_extensions. Binary files, test fixture files in tests/, and the data/ directory are never watched.
>
> Then implement tests/unit/test_file_watcher.py. Tests must mock the watchdog Observer and the HTTP POST call — do not require a running server or real filesystem changes. Test: start/stop lifecycle, extension filtering (only .py files trigger, .json does not), ignore pattern filtering (.git/ path is ignored), debounce collapses rapid saves into one event, connection error to server is handled without raising, on_modified with unchanged content does not POST.
>
> Also implement tests/integration/test_file_watcher_pipeline.py. This test creates a real temporary directory (not a git repo), starts the full WhyCode server, creates a WhyCodeFileWatcher, writes a Python file with a function, waits for the debounce window, and verifies: (1) a FileSnapshot record exists in the DB, (2) an ASTChange record exists for the added function, (3) an UnlinkedFileChange record exists because no session is active. Then starts a session, records a decision, modifies the file again, verifies: (1) new snapshot, (2) new ASTChange, (3) no UnlinkedFileChange (linked to decision).

**Verify:** `pytest tests/unit/test_file_watcher.py -v` — all pass. `pytest tests/integration/test_file_watcher_pipeline.py -v` — all pass.

**Commit:** `[P1] File watcher with watchdog, debounce, extension filtering, and snapshot integration`

### Module 1.10: mcp_server.py + tool_handlers.py + routes.py

**Prompt:**
> Read CLAUDE.md. We are in Phase 1, Module 1.10. Implement backend/mcp/mcp_server.py. FastMCP sub-app mounted at /mcp. Register all Phase 1 MCP tools.
>
> Implement backend/mcp/tool_handlers.py. Business logic behind each tool. session.end handler enforces recording completeness: before marking the session completed, query all SessionEvents for the session to identify files modified (from git hook or file watcher callbacks) but with no associated decision.create referencing those file paths. If unlinked files found, return status: "completed_with_warnings", unlinked_files: [...], message: "Decisions were not recorded for N modified files. Pass force: true to override." If force: true is passed, mark session completed with status "completed_forced", record override_reason in SessionEvent log with override: true and timestamp.
>
> Implement backend/api/routes.py. REST endpoints mirroring MCP tools. All require auth.
>
> Implement tests/integration/test_mcp_tools.py covering every Phase 1 tool with valid auth and without auth (401). Include: session.end with unlinked files returns "completed_with_warnings", session.end with force: true completes and records override, session.end with all files linked returns "completed" cleanly.

**Verify:** `pytest tests/integration/test_mcp_tools.py -v` — all pass.

**Commit:** `[P1] MCP server with 18 CRUD tools, session.end enforcement, REST API`

### Module 1.11: project_claude_md.py

**Prompt:**
> Read CLAUDE.md. We are in Phase 1, Module 1.11. Implement backend/utils/project_claude_md.py. This module generates a CLAUDE.md into the user's project root when whycode init is run.
>
> Function generate_project_claude_md(project_name: str, server_url: str, change_detection_backend: str) -> str returns the rendered template string. The template must contain five sections:
>
> (1) "WhyCode is active" header — states that MCP tools are connected at server_url and must be used. Notes the change detection backend (git or file watcher) and what it means for provenance.
>
> (2) Session lifecycle rules — call session.start at the beginning of every session with agent_name and initial_files. Call session.end when complete. If session.end returns "completed_with_warnings" with unlinked_files: either call decision.create for each unlinked file and then call session.end again, or call session.end with force: true and override_reason explaining why no decision is needed. Do not exit without calling session.end.
>
> (3) Decision recording rules — call decision.create before writing any new function, class, module, or architectural change. Record during the work, not after. Every decision must include title (imperative, under 72 chars), description (the why, not the what), tags, and files_affected. Include a full working example.
>
> (4) Context retrieval rules — call context.get_relevant at session start. Call context.get_for_file before editing a specific file. Review injected context before making changes.
>
> (5) Explicit prohibitions — do not add new imports without checking decision.reverse_trace first. Do not skip session.end. Do not record decisions in bulk retroactively. Do not record trivial decisions to satisfy tooling — use force: true with override_reason instead.
>
> Function write_project_claude_md(project_root: Path, project_name: str, server_url: str, change_detection_backend: str) writes the file. If no CLAUDE.md exists: creates it in full. If CLAUDE.md exists and contains the "## Project-Specific Instructions" delimiter: replaces only the WhyCode section above the delimiter, preserving everything below. If CLAUDE.md exists without the delimiter: prepends the WhyCode section and appends "## Project-Specific Instructions\n\n<!-- User content here -->" followed by the original content.
>
> Implement tests/unit/test_project_claude_md.py. Test: generated output contains all five sections, change_detection_backend appears correctly in the header for both "git" and "file_watcher" values, re-init preserves content below delimiter, re-init on file without delimiter prepends header and preserves original content, re-init does not duplicate the WhyCode section, generate_project_claude_md includes correct server_url in examples.

**Verify:** `pytest tests/unit/test_project_claude_md.py -v` — all pass.

**Commit:** `[P1] Project CLAUDE.md generator with five-section template and safe re-init`

### Module 1.12: cli.py + git_hooks.py

**Prompt:**
> Read CLAUDE.md. We are in Phase 1, Module 1.12. Implement backend/utils/git_hooks.py. Installs post-commit and post-merge hooks into .git/hooks/. The post-commit hook: (1) reads commit hash and generates unified diff via git show --unified=0 HEAD, (2) POSTs to {server_url}/api/hooks/post-commit with commit_hash, diff_text, project_id, active_session_id, (3) if response contains unlinked_changes, prints formatted warning to stderr listing structurally changed symbols with no linked decision, (4) if server unreachable, prints single-line warning and exits 0. Hook never blocks a commit.
>
> Implement cli.py at project root using click. Commands:
>
> whycode init [--mode solo|team] [--port N] [--reinstall-hooks]: (1) creates whycode.toml from template, (2) creates ~/.whycode/ vault directory with 700 permissions, (3) generates solo-mode bearer token stored in vault, (4) creates data/whycode.db, runs migrations, (5) detects change detection backend: if .git/ exists, calls git_hooks.install_hooks() and sets change_detection_backend="git" in config; if no .git/, writes file watcher config and sets change_detection_backend="file_watcher", prints advisory about CI verification limitation and upgrade path, (6) calls project_claude_md.write_project_claude_md() with correct backend value, (7) prints summary of all actions taken. --reinstall-hooks re-runs step 5 regardless of prior state.
>
> whycode serve [--host H] [--port N] [--skip-frontend]: starts FastAPI + MCP server. If change_detection_backend is "file_watcher", starts WhyCodeFileWatcher in background before accepting requests.
>
> whycode connect [--server URL]: scans known MCP client config files, adds or updates whycode entry, preserves existing configs.
>
> whycode login [--server URL]: device auth flow.
>
> whycode token set <token>, whycode token revoke: vault operations.
>
> whycode config set-credential <key> <value>: stores credential in vault.
>
> whycode install-service: generates and enables systemd unit.
>
> whycode mcp [--token T]: starts MCP server in stdio mode.
>
> Implement tests/integration/test_git_hook_pipeline.py: hook installs with execute permission, fires on test commit, calls server with correct payload, prints unlinked warning when server returns unlinked_changes, exits 0 when server unreachable.

**Verify:**
- `whycode init` in a git repo: hook installed in `.git/hooks/post-commit`, `CLAUDE.md` generated with `git` backend noted in header.
- `whycode init` in a plain directory: no hook installed, file watcher config written, `CLAUDE.md` generated with `file_watcher` backend noted in header, advisory message printed.
- Re-run `whycode init` on project with existing `CLAUDE.md` with user content below delimiter: content preserved, no duplication.
- `whycode serve` in file watcher project: file watcher starts, making a structural file change creates snapshot and triggers the change event pipeline.
- `pytest tests/integration/test_git_hook_pipeline.py -v` — all pass.

**Commit:** `[P1] CLI (init, serve, login, token, connect) + git hooks + git/file_watcher backend selection`

### Module 1.13: main.py

**Prompt:**
> Read CLAUDE.md. We are in Phase 1, Module 1.13. Implement backend/main.py. Creates FastAPI app, mounts FastMCP at /mcp, registers auth middleware, registers API routes, configures CORS, calls setup_logging(), loads config, runs migrations on startup.
>
> Endpoints: GET /health (200, unauthenticated — the only unauthenticated endpoint). POST /api/hooks/post-commit (webhook secret auth — validates X-Webhook-Secret header against the stored secret for the project, no bearer token required; in Phase 1 records commit hash in a pending_commits table and returns {received: true, unlinked_changes: []} as a stub — AST processing wired in Phase 2). POST /api/hooks/file-change (webhook secret auth; in Phase 1 records the snapshot IDs in a pending_file_changes table and returns {received: true, unlinked_changes: []} as a stub).
>
> On startup: load config, run migrations, if change_detection_backend is "file_watcher" start the WhyCodeFileWatcher.

**Verify:** Start server, hit /health (200), any other endpoint without auth (401), /api/hooks/post-commit without webhook secret (401), /api/hooks/post-commit with correct webhook secret (200 stub response).

**Commit:** `[P1] Main app with FastMCP mount, dual hook endpoints, startup watcher`

### Phase 1 Gate

```bash
ruff check .
mypy --strict backend/
pytest tests/security/ -v
pytest tests/unit/ -v --cov=backend --cov-report=term-missing
pytest tests/integration/ -v
pytest tests/ -v
pip-audit
```

**Manual verification:**
- Review every file for hardcoded secrets.
- Test solo mode end-to-end in a git repo: `whycode init` → verify `CLAUDE.md` generated with git backend section → `whycode serve` → create decision via MCP → verify in DB.
- Test solo mode in a non-git directory: `whycode init` → verify advisory printed → verify `CLAUDE.md` generated with file_watcher backend section → `whycode serve` → make a structural file change → verify FileSnapshot + ASTChange + UnlinkedFileChange records created in DB.
- Verify `whycode init --reinstall-hooks` after running `git init` in a previously non-git project switches to git backend and installs hooks.
- Verify re-running `whycode init` on a project with existing `CLAUDE.md` with content below `## Project-Specific Instructions` preserves that content.
- Test git post-commit hook: make a structural commit without an active session, verify `UnlinkedCommit` record created, verify stderr warning printed. Make a structural commit inside an active session with a linked decision, verify no `UnlinkedCommit` record.
- Test file watcher: start server in a non-git directory, save a Python file with a new function, verify `ASTChange` record created with `change_event_type: "file_snapshot"`.
- Test `session.end` enforcement: start session, modify files without calling `decision.create`, call `session.end` — verify `status: "completed_with_warnings"` and unlinked file list. Call `session.end` with `force: true` — verify session closes and override recorded.

**If all pass:** Merge to main. Tag `v0.1.0-phase1`. Begin Phase 2.

---

## Phase 2 — Intelligence

**Pre-Phase Setup:**
```bash
curl -fsSL https://ollama.com/install.sh | sh
ollama pull nomic-embed-text
curl http://localhost:11434/api/embeddings -d '{"model":"nomic-embed-text","prompt":"test"}'
```

Expect a JSON response with a 768-float `embedding` array. If received, Phase 2 can begin.

### Module 2.1: token_counter.py

**Prompt:**
> Read CLAUDE.md. We are in Phase 2, Module 2.1. All Phase 1 modules are complete and tested. Do not modify Phase 1 modules. Implement backend/utils/token_counter.py. Functions: count_tokens(text: str) -> int using cl100k_base encoding, count_tokens_batch(texts: list[str]) -> list[int], estimate_budget_usage(items: list[dict], budget: int) -> dict with total_tokens, items_that_fit, remaining_budget. Implement tests/unit/test_token_counter.py: single string, empty string, batch, budget fit, budget exceeded, Unicode.

**Verify:** `pytest tests/unit/test_token_counter.py -v` — all pass.

**Commit:** `[P2] Token counter with tiktoken`

### Module 2.2: embedder.py

**Prompt:**
> Read CLAUDE.md. We are in Phase 2, Module 2.2. Implement backend/intelligence/embedder.py. Class Embedder wrapping Ollama /api/embeddings. embed_text(text) -> list[float] (768-dim). embed_batch(texts, batch_size=32). Constructor validates Ollama reachable and model available. Error handling: connection error, model not found (404), timeout (configurable, default 30s per batch). Retry with exponential backoff (3 attempts) for transient failures. Tests mock the Ollama HTTP API — no running Ollama required for unit tests.

**Verify:** `pytest tests/unit/test_embedder.py -v` — all pass.

**Commit:** `[P2] Embedder with Ollama API, batching, retry`

### Module 2.3: vector_store.py

**Prompt:**
> Read CLAUDE.md. We are in Phase 2, Module 2.3. Implement backend/db/vector_store.py. Abstract VectorStore with SqliteVssStore and PgVectorStore. Methods: insert(item_id, vector, metadata), search(query_vector, top_k, project_id) -> list[dict], delete(item_id), delete_by_project(project_id), count(project_id). Factory function get_vector_store(config). Tests: insert and retrieve, cosine similarity ranking, project isolation, deletion, count. PG tests skip if PG unavailable.

**Verify:** `pytest tests/unit/test_vector_store.py -v` — all pass.

**Commit:** `[P2] Vector store abstraction with sqlite-vss and pgvector`

### Module 2.4: semantic_search.py

**Prompt:**
> Read CLAUDE.md. We are in Phase 2, Module 2.4. Implement backend/intelligence/semantic_search.py. Class SemanticSearch(Embedder, VectorStore). Methods: index_item(item_id, text, item_type, project_id, metadata), search(query, project_id, top_k) -> list[SearchResult], search_by_file(file_path, file_content, project_id, top_k), reindex_item(item_id, new_text), remove_item(item_id). SearchResult dataclass: item_id, score, item_type, metadata. Tests mock Embedder with deterministic vectors.

**Verify:** `pytest tests/unit/test_semantic_search.py -v` — all pass.

**Commit:** `[P2] Semantic search with embedding and ranking`

### Module 2.5: context_triage.py

**Prompt:**
> Read CLAUDE.md. We are in Phase 2, Module 2.5. Implement backend/intelligence/context_triage.py. Class ContextTriage(token_counter). triage(items, budget) -> TriageResult: walk items highest-to-lowest relevance. Items that fit fully: included at full text. Next item exceeds budget by less than 50%: summarized (first sentence + key terms, ~30% original tokens). Remaining: collapsed into excluded_summary. TriageResult: included_items, summarized_items, excluded_summary, total_tokens_used, budget_remaining. format_context_block(triage_result, context_for) -> str: structured block with [DECISION], [STORY], [SUMMARY] headers, relevance %, verification status. Tests: all fit, some excluded, summarization triggered, budget within 5% tolerance.

**Verify:** `pytest tests/unit/test_context_triage.py -v` — all pass.

**Commit:** `[P2] Context triage with token budget enforcement`

### Module 2.6: tree_sitter_langs.py + ast_tracker.py

**Prompt:**
> Read CLAUDE.md. We are in Phase 2, Module 2.6. Implement backend/intelligence/tree_sitter_langs.py. Class LanguageRegistry: get_parser(language) -> Parser, detect_language(file_path) -> str (maps extensions to language names for all 10 supported languages), supported_languages() -> list[str].
>
> Implement backend/intelligence/ast_tracker.py. Class ASTTracker(LanguageRegistry, DatabaseBackend). Methods:
>
> parse_diff(diff_text: str, file_path: str) -> list[ASTChange]: parses unified diff, extracts structural changes using tree-sitter. Returns ASTChange objects without change_event_id set — caller sets these before persisting.
>
> link_changes_to_decision(changes: list[ASTChange], change_event_id: str, change_event_type: Literal["git_commit","file_snapshot"], project_id: str) -> tuple[list[ASTChange], list[str]]: attempts to link changes to decisions by file path overlap and temporal proximity (same session or within 24 hours). Sets change_event_id and change_event_type on linked changes. Creates ProvenanceEdge records. Returns (linked_changes, unlinked_symbol_names).
>
> process_change_event(change_event_id: str, change_event_type: Literal["git_commit","file_snapshot"], diff_text: str, project_id: str, active_session_id: str | None) -> dict: unified entry point called by both /api/hooks/post-commit and /api/hooks/file-change. Calls parse_diff then link_changes_to_decision. For unlinked changes: creates UnlinkedCommit (if change_event_type is "git_commit") or UnlinkedFileChange (if "file_snapshot") record. Returns {linked_changes, unlinked_changes (symbol name list)}.
>
> Tests: language detection for all 10 extensions, Python function addition from git diff, Python function addition from snapshot-generated diff (both must produce identical ASTChange records), TypeScript class addition, import detection, decision linking, UnlinkedCommit created for git backend unlinked, UnlinkedFileChange created for file_watcher backend unlinked, process_change_event end-to-end for both backends.
>
> Also implement tests/integration/test_embedding_pipeline.py (requires Ollama — skip if unavailable).

**Verify:** `pytest tests/unit/test_ast_tracker.py -v` — all pass. `pytest tests/integration/test_embedding_pipeline.py -v` — passes if Ollama running, skipped otherwise.

**Commit:** `[P2] AST tracker with unified process_change_event for git and file_watcher backends`

### Module 2.7: MCP tool expansion + hook endpoint wiring

**Prompt:**
> Read CLAUDE.md. We are in Phase 2, Module 2.7. Update backend/mcp/mcp_server.py and tool_handlers.py to add Phase 2 MCP tools: context.get_relevant, context.get_for_file, decision.trace, decision.reverse_trace.
>
> Update backend/main.py to wire the /api/hooks/post-commit and /api/hooks/file-change endpoints to ast_tracker.process_change_event. Both endpoints now call: ast_tracker.process_change_event(change_event_id, change_event_type, diff_text, project_id, active_session_id). For post-commit: change_event_id = commit_hash, change_event_type = "git_commit". For file-change: change_event_id = after_snapshot_id, change_event_type = "file_snapshot". Both endpoints respond with {received: true, linked_changes: [...], unlinked_changes: [symbol_name, ...]}.
>
> Update tests/integration/test_mcp_tools.py to cover all new tools.

**Verify:** `pytest tests/integration/test_mcp_tools.py -v` — all Phase 1 and Phase 2 tools pass.

**Commit:** `[P2] MCP tools for semantic retrieval + hook endpoints wired to ast_tracker`

### Phase 2 Gate

```bash
ruff check .
mypy --strict backend/
pytest tests/security/ -v
pytest tests/unit/ -v --cov=backend --cov-report=term-missing
pytest tests/integration/ -v
pytest tests/ -v
pip-audit
```

**Manual verification:**
- Test semantic search end-to-end with real Ollama: create 10 decisions, search, verify top-3 relevance.
- In a git project: make a structural commit without a session, verify `ASTChange` records created with `change_event_type: "git_commit"`, verify `UnlinkedCommit` record created.
- In a non-git directory: save a Python file adding a function inside an active session with a linked decision, verify `ASTChange` records created with `change_event_type: "file_snapshot"`, verify no `UnlinkedFileChange` record.
- Verify both backends produce structurally identical `ASTChange` records for the same source change.

**If all pass:** Merge to main. Tag `v0.2.0-phase2`. Begin Phase 3.

---

## Phase 3 — Verification and Multi-Agent

### Module 3.1: verifier.py

**Prompt:**
> Read CLAUDE.md. We are in Phase 3, Module 3.1. All Phase 1 and Phase 2 modules complete. Implement backend/verification/verifier.py. Class Verifier(DatabaseBackend). register_webhook(provider, project_id) -> dict. process_webhook(payload, provider, project_id): parses CI result, identifies commit_hash, finds decisions linked via ProvenanceEdge where change_event_type="git_commit" and change_event_id=commit_hash, transitions status. Status transitions: unverified→pending (CI starts), pending→passed (CI succeeds), pending→failed (CI fails), failed→pending (new CI run). get_status(decision_id) -> str. get_unverified(project_id) -> list[Decision]. get_failed(project_id) -> list[Decision].
>
> get_status and get_unverified must handle file_watcher mode: if the project's change_detection_backend is "file_watcher", return {verification_status: "unavailable", change_detection_backend: "file_watcher", message: "CI verification requires a git repository. Run git init and whycode init --reinstall-hooks to enable."} rather than raising an error.
>
> Webhook endpoint at /webhooks/ci/{provider}: unauthenticated but validated by webhook secret from vault. Tests: status transitions, GitHub Actions and GitLab CI webhook parsing, webhook secret validation, file_watcher mode returns unavailable response gracefully.

**Verify:** `pytest tests/unit/test_verifier.py -v` — all pass.

**Commit:** `[P3] Verification engine with CI webhooks and file_watcher mode handling`

### Module 3.2: harness.py

**Prompt:**
> Read CLAUDE.md. We are in Phase 3, Module 3.2. Implement backend/verification/harness.py. Class QualityHarness(DatabaseBackend, ASTTracker).
>
> score_commit(commit_hash, project_id, repo_path) -> HarnessScore. Only callable when change_detection_backend is "git". If called in file_watcher mode, raises ValueError with message "score_commit requires git backend. Use score_snapshot for file watcher projects."
>
> score_snapshot(after_snapshot_id, project_id) -> HarnessScore. Called in file_watcher mode. Computes complexity and import health sensors from the post-change snapshot content. Coverage delta is unavailable without a test runner integration — returns coverage_delta: None with status "unavailable" and detail "Coverage sensor requires git backend for stash-based before/after comparison."
>
> score_session(session_id) -> SessionHarnessScore: aggregates scores across all change events in a session. Works for both backends. Uses score_commit for git events and score_snapshot for file_snapshot events.
>
> All HarnessScore objects include: coverage_delta (float | None), complexity_score, import_health, drift_violations, decision_density (float), decision_density_status ("critical"/"low"/"adequate"), harness_status ("passing"/"warning"/"failing"), change_detection_backend.
>
> decision_density sensor: queries count of ASTChange records with change_event_id in the session's change events and count of decisions with status "passed" or "pending" recorded in the session. density = decisions / max(structural_changes, 1). critical below 0.1, low between 0.1 and 0.3, adequate above 0.3. critical → harness_status "failing".
>
> SessionHarnessScore includes session_coverage_metric: sessions_with_decisions / total_completed_sessions for the project.
>
> Tests: coverage delta for git, complexity scoring, import health circular dep detection, drift violation, decision_density 0.0 returns critical and failing, decision_density 0.4 returns adequate, score_snapshot returns coverage_delta: None, session aggregation for mixed git/file_snapshot sessions.

**Verify:** `pytest tests/unit/test_harness.py -v` — all pass.

**Commit:** `[P3] Quality harness with dual backend support and decision density sensor`

### Module 3.3: conflict_detector.py

**Prompt:**
> Read CLAUDE.md. We are in Phase 3, Module 3.3. Implement backend/verification/conflict_detector.py. Class ConflictDetector(DatabaseBackend). register_session(session_id, project_id, agent_name, files). update_session_files(session_id, files). end_session(session_id). check_conflicts(session_id, project_id) -> list[Conflict]. Conflict dataclass: conflicting_session_id, conflicting_agent, overlapping_files, overlapping_decisions, severity (low/medium/high). Import dependency check via AST tracker import parsing. get_active_sessions(project_id) -> list[dict]. Performance: ≤100ms for 10 concurrent sessions. Tests: no conflict different files, conflict same file, severity escalation via shared imports, session end removes from tracking, 100ms target.

**Verify:** `pytest tests/unit/test_conflict_detector.py -v` — all pass.

**Commit:** `[P3] Multi-agent conflict detector`

### Module 3.4: provenance.py

**Prompt:**
> Read CLAUDE.md. We are in Phase 3, Module 3.4. Implement backend/verification/provenance.py. Class ProvenanceEngine(DatabaseBackend).
>
> forward_trace(decision_id) -> ProvenanceTree: returns decision + all linked change events + their ASTChanges. ProvenanceTree.commits is now ProvenanceTree.change_events (list), each with: change_event_id, change_event_type, label (commit message for git_commit; "Snapshot [file_path] at [timestamp]" for file_snapshot), date, ast_changes list.
>
> reverse_trace(file_path, entity_name, project_id) -> list[ReverseTraceResult]: finds ASTChanges for the entity, follows ProvenanceEdge back to decision. Works for both change_event_types. ReverseTraceResult: decision, change_event_id, change_event_type, change_event_label, ast_change, confidence_score.
>
> get_decision_dependencies(decision_id) -> list[Decision]. get_impact_graph(decision_id) -> dict: full dependency graph — decision, dependents, change_events (both types), AST changes.
>
> All queries use recursive CTEs. Tests: forward trace for git_commit events, forward trace for file_snapshot events, reverse trace both event types, dependencies, impact graph, empty trace.

**Verify:** `pytest tests/unit/test_provenance.py -v` — all pass.

**Commit:** `[P3] Provenance engine supporting git_commit and file_snapshot change events`

### Module 3.5: Session replay + MCP tool expansion

**Prompt:**
> Read CLAUDE.md. We are in Phase 3, Module 3.5. Update tool_handlers.py: every MCP tool call logged as SessionEvent (event_type: "tool_call", tool name, input params, output summary, context_snapshot_ids). File change events from git hook or file watcher logged as SessionEvent (event_type: "git_commit" or "file_snapshot", change_event_id, change_event_type, structural changes list).
>
> Add MCP tools: session.replay(session_id) — full SessionEvent timeline including both event types. session.conflicts(session_id). verify.status(decision_id) — returns unavailable response for file_watcher projects. verify.list_unverified(project_id) — same. provenance.forward(decision_id). provenance.reverse(file_path, entity_name, project_id). harness.score(session_id) — includes decision_density, decision_density_status, session_coverage_metric, change_detection_backend. harness.score_commit(commit_hash, project_id) — only for git projects.
>
> Update tests/integration/test_mcp_tools.py: all Phase 1, 2, and 3 tools pass. Test that harness.score on a session with no decisions returns decision_density_status: "critical". Test that verify.status for a file_watcher project returns verification_available: false.

**Verify:** `pytest tests/integration/test_mcp_tools.py -v` — all pass.

**Commit:** `[P3] Session replay, conflict, verify, provenance, harness MCP tools`

### Module 3.6: E2E tests

**Prompt:**
> Read CLAUDE.md. We are in Phase 3, Module 3.6.
>
> Implement tests/e2e/test_full_decision_lifecycle.py (git backend): create project in git repo, start session, record decision, simulate git commit with structural diff, verify ASTChange records with change_event_type "git_commit", verify ProvenanceEdge links decision to commit, simulate CI webhook, verify decision → "passed", verify forward trace returns complete tree, verify reverse trace from function name returns originating decision. Also verify structural commit without session creates UnlinkedCommit. Also verify session.end with unlinked files returns "completed_with_warnings".
>
> Implement tests/e2e/test_full_decision_lifecycle_no_git.py (file watcher backend): create project in plain temp directory (no git), start server with file watcher, start session, record decision, write a Python file with a new function (simulates file save), wait for debounce, verify FileSnapshot created, ASTChange created with change_event_type "file_snapshot", ProvenanceEdge links decision, verify forward trace returns tree with change_event_type "file_snapshot" and snapshot label, verify reverse trace works. Verify verify.status returns verification_available: false. Verify session.end behaves identically to git mode.
>
> Implement tests/e2e/test_multi_agent_conflict.py: two sessions overlapping files, conflict detected, overlap removed, conflict clears.

**Verify:** `pytest tests/e2e/ -v` — all pass.

**Commit:** `[P3] E2E tests for both git and file_watcher decision lifecycle`

### Phase 3 Gate

```bash
ruff check .
mypy --strict backend/
pytest tests/security/ -v
pytest tests/unit/ -v --cov=backend --cov-report=term-missing
pytest tests/integration/ -v
pytest tests/e2e/ -v
pytest tests/ -v
pip-audit
```

**Manual verification:**
- Test CI webhook with real GitHub Actions if available: push commit, verify decision status transitions.
- Make a commit introducing a circular import, verify import health sensor catches it.
- In a non-git project: run `harness.score` on a session with structural file changes and no decisions — verify `decision_density: 0.0`, `decision_density_status: "critical"`, `harness_status: "failing"`.
- In a non-git project: call `verify.status` on a decision — verify `verification_available: false` returned without error.
- Verify SEC-01 through SEC-11 all pass. For SEC-11: check that both `UnlinkedCommit` and `UnlinkedFileChange` counts appear in the audit output.

**If all pass:** Merge to main. Tag `v0.3.0-phase3`. Begin Phase 4.

---

## Phase 4 — Dashboard and Sprint Intelligence

**Pre-Phase Setup:**
```bash
cd frontend && npm install && npm run dev
```
Verify Vite dev server starts before beginning.

### Module 4.1: API client + Zustand stores

**Prompt:**
> Read CLAUDE.md. We are in Phase 4, Module 4.1. Implement frontend/src/api/client.ts — typed API client with auth handling, base URL config, error handling. API functions for: projects, decisions, stories, sprints, sessions, context, provenance, verification (including verification_available flag handling), harness, mcp_servers, auth, connected_services. Create authStore.ts (user state), projectStore.ts (active project, change_detection_backend of active project), appStore.ts (active tab, theme). All Zustand with strict TypeScript.

**Verify:** `cd frontend && npx vitest run` — all pass.

**Commit:** `[P4] Frontend API client and Zustand stores`

### Module 4.2: Auth views + layout shell

**Prompt:**
> Read CLAUDE.md. We are in Phase 4, Module 4.2. Implement App.tsx: auth gate, header (logo, project selector, active agent count, change detection mode badge — shows "git" in blue or "file watcher" in amber, theme toggle, user avatar), tab nav (Memory, Decisions, Sprint, Sessions, Explorer, MCP Servers, Settings). Theme: detect OS preference, watch matchMedia, manual toggle, store in Zustand, CSS custom properties for all colors. LoginView.tsx: Google, GitHub, email/password form, CLI device auth note.

**Verify:** Build succeeds. Visual check: login page, theme toggle, change detection badge in header.

**Commit:** `[P4] Auth views, layout shell, theme system, change detection mode badge`

### Module 4.3: MemoryView

**Prompt:**
> Read CLAUDE.md. We are in Phase 4, Module 4.3. Implement MemoryView.tsx: semantic search input, type filters (All/Decisions/Stories/Sessions), token budget indicator bar (green <80%, red >80%), scrollable context item cards (type badge, text, token count, similarity bar). React Query for data fetching with loading/error states.

**Verify:** Visual check: renders, search triggers API call, filters work, budget bar updates.

**Commit:** `[P4] MemoryView`

### Module 4.4: DecisionsView

**Prompt:**
> Read CLAUDE.md. We are in Phase 4, Module 4.4. Implement DecisionsView.tsx: two-panel layout. Decision list: status filters (All/Verified/Pending/Failed), decision cards (status dot, title, tags, agent, date, commit/snapshot count, similarity bar, harness scores including decision_density bar). Provenance panel (opens on selection): decision text, verification badge (or "verification unavailable" message for file_watcher projects), change event timeline. Each change event expands to show AST changes. Git events labeled "commit [hash]", file snapshot events labeled "snapshot [timestamp] — [file]".

**Verify:** Visual check: list, filters, provenance panel renders both event types correctly.

**Commit:** `[P4] DecisionsView with provenance panel for git and file_watcher events`

### Module 4.5: SprintView

**Prompt:**
> Read CLAUDE.md. We are in Phase 4, Module 4.5. Implement SprintView.tsx: metric cards (sprint name/dates, points completed/total, velocity), four-lane kanban (Backlog/In Progress/Review/Done), burndown line chart (ideal vs actual), velocity bar chart (last 6 sprints). Add sprint.burndown and sprint.velocity MCP tools in backend and corresponding REST routes.

**Verify:** Visual check: kanban, metric cards, charts render.

**Commit:** `[P4] SprintView with kanban and charts`

### Module 4.6: SessionsView

**Prompt:**
> Read CLAUDE.md. We are in Phase 4, Module 4.6. Implement SessionsView.tsx. Session cards: status badge (active/idle/completed green/gray), agent name, file paths, timestamp, harness score (green ≥90, amber ≥75, red <75). Three badge conditions: (1) amber left border + amber "conflict" badge with expansion showing conflicting session and overlapping files, (2) red left border + red "no decisions recorded" badge when decision_density_status is "critical", (3) amber "file watcher" mode badge when change_detection_backend is "file_watcher". Session that was force-closed shows gray "completed (forced)" badge with override reason in expansion. Data from sessions.list, session.conflicts, harness.score.

**Verify:** Visual check: all badge states render correctly.

**Commit:** `[P4] SessionsView with conflict, density warning, and mode badges`

### Module 4.7: ExplorerView + ProvenanceView

**Prompt:**
> Read CLAUDE.md. We are in Phase 4, Module 4.7. Implement ExplorerView.tsx: 2D scatter plot of all embedded context items via UMAP (add /api/explorer/projection endpoint returning x,y per item). ECharts scatter. Points color-coded by type (purple decisions, teal stories, gray sessions). Hover tooltip: type badge, text preview, similarity score, token count. Type legend.
>
> Implement ProvenanceView.tsx: force-directed ECharts graph. Node types: purple decisions, gray git_commit events, teal file_snapshot events (distinct shape from git — use diamond vs circle), green AST changes. Edge thickness = change count. Click node → details in side panel. Node label for file_snapshot events shows "snapshot [date]" instead of a commit hash.

**Verify:** Visual check: scatter plot, provenance graph renders both change event node types distinctly.

**Commit:** `[P4] ExplorerView (UMAP) and ProvenanceView (git + file_snapshot nodes)`

### Module 4.8: MCPServersView

**Prompt:**
> Read CLAUDE.md. We are in Phase 4, Module 4.8. Implement MCPServersView.tsx: connected MCP server list (name, URL, status badge, tool count, transport badge, auth badge, re-auth button). Add server form: name, URL/command, transport selector (HTTP/SSE, Local HTTP, stdio), auth selector (OAuth, API key, None), conditional fields. Connect calls /api/mcp-servers/create.

**Verify:** Visual check: list renders, form toggles, selectors work.

**Commit:** `[P4] MCPServersView`

### Module 4.9: SettingsView

**Prompt:**
> Read CLAUDE.md. We are in Phase 4, Module 4.9. Implement SettingsView.tsx. Three-column layout. Left: connected services (status, re-auth, disconnect), PATs (list with name/expiry/last-used/revoke, generate new PAT form). Right: appearance (theme toggle), agent profiles (cards: name, score, session count, pass rate, strong/weak domains), security status panel.
>
> Security status panel calls /api/security/status. Shows SEC-01 through SEC-11. SEC-11 row shows: total unlinked count (UnlinkedCommit + UnlinkedFileChange combined), a breakdown "(N git, M file watcher)", View link opening modal listing each unlinked event with change_event_type, symbol names, file, timestamp. Each symbol has a "Record decision ↗" button that calls sendPrompt.
>
> Project info section shows change_detection_backend badge and, if "file_watcher", a note: "CI verification unavailable. Run git init and whycode init --reinstall-hooks to enable."

**Verify:** Visual check: all sections render, SEC-11 panel shows both git and file_watcher unlinked counts.

**Commit:** `[P4] SettingsView with SEC-01 through SEC-11 panel, dual backend unlinked counts`

### Module 4.10: Frontend build integration

**Prompt:**
> Read CLAUDE.md. We are in Phase 4, Module 4.10. Update main.py to serve frontend/dist/ as static files at root. SPA routing: non-API non-/mcp paths serve index.html. Add npm run build outputting to frontend/dist/. Update whycode serve to build frontend if dist/ absent. Add --skip-frontend flag.

**Verify:** `cd frontend && npm run build`, then `whycode serve`, open http://localhost:8100 — all views load, API calls reach backend.

**Commit:** `[P4] Frontend build integration`

### Phase 4 Gate

```bash
ruff check .
mypy --strict backend/
pytest tests/security/ -v
pytest tests/unit/ -v --cov=backend --cov-report=term-missing
pytest tests/integration/ -v
pytest tests/e2e/ -v
pytest tests/ -v
pip-audit
cd frontend && npx vitest run && npm run build
```

**Manual verification:**
- Open dashboard, navigate every view.
- In SessionsView: create a session with structural file changes and no decisions in file_watcher mode — verify red "no decisions recorded" badge and "file watcher" amber badge both appear.
- In DecisionsView: click a decision from a file_watcher project — verify provenance panel shows "snapshot [timestamp]" labels instead of commit hashes, and verification panel shows "verification unavailable" message.
- In ProvenanceView: verify file_snapshot nodes render as diamonds, git_commit nodes as circles.
- In SettingsView: verify SEC-11 row shows combined count with "(N git, M file watcher)" breakdown.

**If all pass:** Merge to main. Tag `v0.4.0-phase4`. Begin Phase 5.

---

## Phase 5 — Advanced Intelligence

### Module 5.1: drift_detector.py

**Prompt:**
> Read CLAUDE.md. We are in Phase 5, Module 5.1. All Phase 1–4 modules complete. Implement backend/advanced/drift_detector.py. Class DriftDetector(DatabaseBackend, ASTTracker, SemanticSearch). check_drift(project_id, repo_path) -> DriftReport (list of DriftViolation). Logic: (1) extract constraints from verified decisions via semantic search for constraint language, (2) parse current codebase imports via tree-sitter to build import graph, (3) compare import graph against constraints, flag violations. DriftViolation: decision_id, decision_title, constraint_description, violating_file, violating_line, violation_description, severity. Works for both backends — operates on current file content, not on git diffs. Tests: violation detected, no violation when conformant, multiple violations, severity assignment.

**Verify:** `pytest tests/unit/test_drift_detector.py -v` — all pass.

**Commit:** `[P5] Architectural drift detector`

### Module 5.2: tautology_detector.py

**Prompt:**
> Read CLAUDE.md. We are in Phase 5, Module 5.2. Implement backend/advanced/tautology_detector.py. Class TautologyDetector(DatabaseBackend, ASTTracker, SemanticSearch). check_tests(project_id, repo_path) -> TautologyReport (list of TautologyFlag). Logic: (1) parse test files for test functions and assertions, (2) semantic search for most relevant story with acceptance criteria, (3) flag tests with similarity below 0.3 to any criterion. TautologyFlag: test_file, test_function, assertion_summary, linked_story_id, linked_acceptance_criteria, confidence, reason. Works for both backends. Tests: grounded test not flagged, ungrounded test flagged, confidence scoring, edge cases.

**Verify:** `pytest tests/unit/test_tautology_detector.py -v` — all pass.

**Commit:** `[P5] Tautological test detector`

### Module 5.3: rollback_planner.py

**Prompt:**
> Read CLAUDE.md. We are in Phase 5, Module 5.3. Implement backend/advanced/rollback_planner.py. Class RollbackPlanner(DatabaseBackend, ProvenanceEngine). plan_rollback(decision_id) -> RollbackPlan. RollbackPlan: target_decision, dependent_decisions, affected_change_events (list of {change_event_id, change_event_type, label}), affected_files, ast_changes_to_revert, risk_assessment (low/medium/high), recommended_action. For git projects: label is commit message. For file_watcher projects: label is "Snapshot [file] at [timestamp]". Risk and dependency logic identical for both backends. Tests: no dependents (low risk), unverified dependents (medium), verified dependents (high), both event types in impact graph.

**Verify:** `pytest tests/unit/test_rollback_planner.py -v` — all pass.

**Commit:** `[P5] Rollback planner with dual backend change event support`

### Module 5.4: Persona system + MCP tool expansion

**Prompt:**
> Read CLAUDE.md. We are in Phase 5, Module 5.4. Update semantic_search.py and context_triage.py to support persona parameter: "architect", "reviewer", "planner", "implementer". Each applies re-ranking multipliers (1.3x boost for persona-relevant items, 0.7x reduction for others). No items hidden — only reordered.
>
> Add MCP tools: drift.check(project_id), drift.report(project_id), test.check_tautology(project_id), rollback.plan(decision_id), context.get_relevant updated with persona parameter. Update REST routes.
>
> Tests: persona re-ranking, drift/tautology/rollback tools return correct structures for both backends.

**Verify:** `pytest tests/ -v` — all pass.

**Commit:** `[P5] Persona retrieval, drift, tautology, rollback MCP tools`

### Phase 5 Gate

```bash
ruff check .
mypy --strict backend/
pytest tests/security/ -v
pytest tests/unit/ -v --cov=backend --cov-report=term-missing
pytest tests/integration/ -v
pytest tests/e2e/ -v
pytest tests/ -v
pip-audit
cd frontend && npx vitest run && npm run build
```

**Manual verification:** Test drift detection, tautology detection, rollback planner in both git and non-git project modes. Verify rollback plan labels show snapshot timestamps for file_watcher projects.

**If all pass:** Merge to main. Tag `v0.5.0-phase5`. Begin Phase 6.

---

## Phase 6 — Ecosystem

### Module 6.1: knowledge_packs.py

**Prompt:**
> Read CLAUDE.md. We are in Phase 6, Module 6.1. Implement backend/advanced/knowledge_packs.py. Class KnowledgePackManager(DatabaseBackend, SemanticSearch, Embedder). export_pack(project_id, decision_ids, pack_name) -> KnowledgePack: exports verified (passed) decisions only — error if any selected decision is unverified or failed. Pack contains: metadata, sanitized decisions (text, tags, status — no file paths), pre-computed embeddings. import_pack(project_id, pack) -> none: creates Decision records tagged "imported", inserts embeddings into vector store. list_exportable(project_id) -> list[dict]. serialize_pack / deserialize_pack (gzipped JSON). Works for both backends — knowledge packs are backend-agnostic since they contain no commit hashes or snapshot IDs. Tests: export verified, error on unverified, import creates records, imported decisions searchable, serialization round-trip, sanitization.

**Verify:** `pytest tests/unit/test_knowledge_packs.py -v` — all pass.

**Commit:** `[P6] Knowledge pack export/import`

### Module 6.2: agent_profiler.py

**Prompt:**
> Read CLAUDE.md. We are in Phase 6, Module 6.2. Implement backend/advanced/agent_profiler.py. Class AgentProfiler(DatabaseBackend). get_profile(agent_name, project_id) -> AgentProfile: total_sessions, verification_pass_rate (unavailable for file_watcher projects — returns None with note), average_harness_score, strong_domains (pass rate >85%), weak_domains (pass rate <70%), session_history. Minimum 5 sessions required; return "insufficient data" otherwise. recommend_agent(story_id, project_id) -> list[AgentRecommendation]. get_context_adjustment(agent_name, story_id) -> dict. Tests: profile generation, pass rate (null handling for file_watcher), domain classification, recommendations, context adjustment, insufficient data handling.

**Verify:** `pytest tests/unit/test_agent_profiler.py -v` — all pass.

**Commit:** `[P6] Agent capability profiler`

### Module 6.3: MCP tool expansion + documentation

**Prompt:**
> Read CLAUDE.md. We are in Phase 6, Module 6.3. Expand MCP surface to 50+ methods. Add: knowledge.export, knowledge.import, knowledge.list_packs, knowledge.list_exportable, agent.profile, agent.recommend, agent.context_adjustment, standup.generate (enhanced), retrospective.generate, project.create, project.list, project.switch, project.members, decision.search, story.search, session.search. Update REST routes. Verify total ≥50.
>
> Create documentation: docs/SECURITY.md (threat model, credential storage, SEC-01 through SEC-11, vulnerability reporting). docs/ARCHITECTURE.md (system design, four-stage context pipeline, module responsibilities, both change detection backends including initialization, data flow, the change_event_id abstraction, limitations of file_watcher mode — CI verification unavailable, coverage delta sensor unavailable). docs/API.md (all REST endpoints and MCP tools with schemas; note which tools return degraded responses in file_watcher mode: verify.status, verify.list_unverified, harness.score_commit, agent.profile verification_pass_rate). Update README.md.

**Verify:** Tool count ≥50. Documentation complete. `pytest tests/ -v` — full regression.

**Commit:** `[P6] MCP expansion to 50+ tools, complete documentation`

### Module 6.4: License key validation

**Prompt:**
> Read CLAUDE.md. We are in Phase 6, Module 6.4. Implement backend/auth/license.py. Class LicenseValidator. validate(license_key) -> LicenseInfo: tier (community/team/enterprise), max_seats, expires_at, features. License key is Ed25519-signed JWT. Community tier: no key required, all community features available. Feature flags: "multi_user", "conflict_detection", "agent_profiling", "drift_detection", "tautology_detection", "postgresql_backend", "sprint_intelligence" (team+enterprise); "knowledge_transfer", "rollback_planning", "rbac", "audit_export", "sso_saml" (enterprise). Update auth_middleware.py to check feature flags. Tests: community features without key, team features rejected without key, valid key enables features, expired key rejects, Ed25519 verification (test keypair in fixtures).

**Verify:** `pytest tests/unit/test_license.py -v` — all pass. Server starts without license key; all community features work.

**Commit:** `[P6] License key validation with Ed25519 JWT`

### Phase 6 Gate

```bash
ruff check .
mypy --strict backend/
pytest tests/security/ -v
pytest tests/unit/ -v --cov=backend --cov-report=term-missing
pytest tests/integration/ -v
pytest tests/e2e/ -v
pytest tests/ -v
pip-audit
cd frontend && npx vitest run && npm run build
```

**Manual verification:**
- Install from pyproject.toml on fresh Python 3.11 environment — installs cleanly.
- `whycode init && whycode serve` in a git repo — starts, dashboard loads, CLAUDE.md generated with git backend.
- `whycode init && whycode serve` in a plain directory — starts, dashboard loads, CLAUDE.md generated with file_watcher backend, advisory visible.
- Run `git init && whycode init --reinstall-hooks` on a previously file_watcher project — switches to git backend, hooks installed, existing snapshot provenance preserved.
- Test knowledge pack export/import between two projects.
- Count MCP tools — must be ≥50.
- Verify adoption enforcement chain end-to-end in both modes: structural change → no decision → unlinked record → SEC-11 audit panel → harness critical → dashboard badge.
- Read all documentation for accuracy. Verify docs describe both backends and their limitations correctly.
- Run without license key — all community features work.

**If all pass:** Merge to main. Tag `v1.0.0`. Product is feature-complete.

---

## Post-Phase 6: Launch Preparation

Run final security audit: `git log --all -p | grep -i "password\|secret\|token\|api_key"` — verify zero results.

Create GitHub release at v1.0.0 tag with release notes.

Publish to PyPI: `python -m build && twine upload dist/*`. Verify `pip install whycode` on clean machine.

Write launch posts (HackerNews, Reddit r/programming, dev.to). Record 3-minute demo showing semantic retrieval, provenance trace, and both git and file_watcher backend modes.

Flip repository to public: Settings → Danger Zone → Change visibility → Make public.

---

## Emergency Procedures

**Security invariant fails:** Stop immediately. Fix violation. Add regression test. Re-run `pytest tests/security/ -v`. All SEC-01 through SEC-11 must pass before continuing. Hotfix from phase tag if violation shipped.

**Prior-phase test breaks:** Do not modify the failing test. Fix the new code. If prior behavior genuinely needs to change: document in commit message, update test, add explanation comment, get explicit review.

**Dependency vulnerability (pip-audit fails):** Read the CVE. If the vulnerable path is exercised by WhyCode: pin to patched version or replace dependency. If not exercised: document in docs/SECURITY.md with CVE reference and justification. Never ship with unacknowledged vulnerabilities.

**File watcher not detecting changes:** Check that `watchdog` is installed and the process has read permission on the project directory. Check that the file extension is in `change_detection_backend.watch_extensions`. Check that the file path does not match any `ignore_patterns`. Verify the debounce window (default 100ms) is not filtering events — increase if auto-save frequency is high.

**Upgrading file_watcher project to git:** Run `git init`, then `whycode init --reinstall-hooks`. The server updates `change_detection_backend = "git"` in config, installs git hooks, stops the file watcher. Existing `file_snapshot` provenance records are preserved and remain queryable.
