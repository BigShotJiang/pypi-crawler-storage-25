# Contributing to WhyCode

Thanks for helping build WhyCode. This guide covers the development
setup, test workflow, PR requirements, and how to report security issues.

## Development setup

Requires Python 3.11+ and Node.js 18+.

```bash
git clone https://github.com/whycodeAI/whycode.git
cd whycode
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -e ".[dev]"
```

The editable install pulls in the full runtime stack plus `ruff`,
`mypy`, `pytest`, `pytest-asyncio`, `pytest-cov`, and `pip-audit`.

Frontend development (optional, only if you are changing the dashboard):

```bash
cd frontend
npm install
npm run dev
```

## Running tests

The project has four test suites, each with its own directory and
purpose. Run them individually during development and all together
before submitting a PR.

```bash
# Security invariants — SEC-01 through SEC-11
pytest tests/security/ -v

# Unit tests with coverage
pytest tests/unit/ -v --cov=backend --cov-report=term-missing

# Integration tests
pytest tests/integration/ -v

# End-to-end tests (Phase 3+)
pytest tests/e2e/ -v

# Everything — required before opening a PR
pytest tests/ -v --cov=backend --cov-fail-under=82
```

Use `pytest -k "name"` to run a single test and `pytest -x` to stop
on the first failure while iterating.

## Running the benchmark harness

The benchmark harness measures retrieval quality against LongMemEval-S
and LOCOMO. Install the benchmark extras and run against either
dataset:

```bash
pip install -e ".[benchmark]"
whycode-benchmark run --dataset longmemeval --output results.json
whycode-benchmark run --dataset locomo --output results.json
```

Results are JSON; full methodology and baseline comparisons live in
`scripts/benchmark/README.md`.

## PR requirements

Every PR must pass these checks before review:

1. **Lint** — `ruff check .` reports zero warnings.
2. **Types** — `mypy --strict backend/` reports zero errors.
3. **Tests and coverage** — `pytest tests/ --cov=backend --cov-fail-under=82`
   passes with no failures and coverage stays at or above 82%.
4. **No new runtime CVEs** — `pip-audit` reports zero new vulnerabilities
   in runtime dependencies.
5. **Security invariants hold** — `pytest tests/security/ -v` passes.
   SEC-01 through SEC-11 are invariants, not guidelines.

PR scope: one module per PR. Tightly coupled pairs (for example
`file_watcher` plus `snapshot_store`) may be combined when they
cannot be merged independently.

Branch naming: `phase-{N}/{module-name}` — for example
`phase-2/context-triage`.

Commit messages: imperative, 72-char limit, phase reference. Example:
`[P2] Add token-budget-aware context triage`.

Test files mirror source files. If you add `backend/foo/bar.py`, add
`tests/unit/test_bar.py`.

## Reporting security issues

Do not open a public issue for a security vulnerability.

- Open a GitHub Security Advisory on the repository, or
- Email `security@whycodeai.github.io` with reproduction steps.

We commit to a 48-hour initial response. The full threat model,
credential storage architecture, and the SEC-01 through SEC-11
invariants are documented in [SECURITY.md](SECURITY.md).

## Code of Conduct

This project follows the [Contributor Covenant](https://www.contributor-covenant.org/version/2/1/code_of_conduct/),
version 2.1.

**Our pledge.** We pledge to make participation in our community a
harassment-free experience for everyone, regardless of age, body size,
visible or invisible disability, ethnicity, sex characteristics, gender
identity and expression, level of experience, education, socio-economic
status, nationality, personal appearance, race, caste, colour, religion,
or sexual identity and orientation.

**Our standards.** Examples of behaviour that contributes to a positive
environment include demonstrating empathy and kindness, being respectful
of differing opinions and viewpoints, giving and gracefully accepting
constructive feedback, accepting responsibility and apologising for
mistakes, and focusing on what is best for the overall community.

Examples of unacceptable behaviour include the use of sexualised
language or imagery, trolling, insulting or derogatory comments,
personal or political attacks, public or private harassment, publishing
others' private information without permission, and other conduct
which could reasonably be considered inappropriate in a professional
setting.

**Enforcement.** Instances of abusive, harassing, or otherwise
unacceptable behaviour may be reported to the maintainers at
`conduct@whycodeai.github.io`. All complaints will be reviewed
and investigated promptly and fairly. Maintainers are obligated to
respect the privacy and security of the reporter of any incident.

The full text of the Contributor Covenant is available at
https://www.contributor-covenant.org/version/2/1/code_of_conduct/.
