# WhyCode Architecture

WhyCode is a verified context infrastructure for AI-assisted development. This document describes the system design, the four-stage context pipeline, the module responsibilities, and — importantly — both change detection backends and their limitations.

## High-level topology

```
┌────────────────────┐      MCP       ┌──────────────────────────┐
│ AI agents (Claude, │───────────────▶│ WhyCode server (FastAPI│
│  Cursor, …)        │                │ + FastMCP mounted at /mcp │
└────────────────────┘                │                           │
       ▲                              │  ┌───────────────────┐    │
       │ REST /api                    │  │ Tool handlers     │    │
       │                              │  │ (business logic)  │    │
       ▼                              │  └───────────────────┘    │
┌────────────────────┐                │  ┌───────────────────┐    │
│ React dashboard    │────────────────│  │ Intelligence      │    │
│ (Vite build)       │                │  │  embedder +       │    │
└────────────────────┘                │  │  vector store +   │    │
                                      │  │  ast_tracker      │    │
                                      │  └───────────────────┘    │
                                      │  ┌───────────────────┐    │
                                      │  │ Verification      │    │
                                      │  │  verifier + harness│   │
                                      │  │  + conflict +     │    │
                                      │  │  provenance       │    │
                                      │  └───────────────────┘    │
                                      │  ┌───────────────────┐    │
                                      │  │ Advanced          │    │
                                      │  │  drift + tautology│    │
                                      │  │  + rollback +     │    │
                                      │  │  knowledge_packs +│    │
                                      │  │  agent_profiler   │    │
                                      │  └───────────────────┘    │
                                      │           │               │
                                      │           ▼               │
                                      │  ┌───────────────────┐    │
                                      │  │ Storage           │    │
                                      │  │ SQLite (sqlite-vss)│   │
                                      │  │ or PostgreSQL     │    │
                                      │  │ (pgvector)        │    │
                                      │  └───────────────────┘    │
                                      └──────────────────────────┘
```

## Four-stage context pipeline

1. **Change capture** — `git_hooks.py` (post-commit) or `file_watcher.py` (watchdog).
2. **Structural extraction** — `ast_tracker.process_change_event` parses the unified diff with tree-sitter.
3. **Decision linking** — AST changes are linked to open decisions by file-name overlap and temporal proximity; unlinked changes yield `UnlinkedCommit` or `UnlinkedFileChange` records for SEC-11.
4. **Retrieval + triage** — `semantic_search.search` ranks by cosine similarity; `context_triage.triage` trims to a token budget.

## Change detection backends

WhyCode detects structural code changes through two backends, selected automatically at `whycode init` time based on whether a `.git/` directory exists. Both backends produce identical `ASTChange` and `ProvenanceEdge` records through the change_event abstraction.

### Git backend (default when `.git/` exists)

* Post-commit hook calls `/api/hooks/post-commit` with the commit hash and unified diff.
* `commit_hash` anchors all provenance records.
* CI webhooks reference the same commit hash to transition verification status.
* Full provenance, verification, drift detection, and rollback planning are available.
* `ast_changes.change_event_type = "git_commit"`.

### File watcher backend (used when no `.git/` exists)

* `watchdog` monitors the project directory for source file modifications.
* On modification, `snapshot_store.take_snapshot` captures before/after content, generates a synthetic unified diff, and calls `/api/hooks/file-change`.
* A `change_event_id` prefixed `snap_` replaces the commit hash in all provenance records.
* File snapshots are stored in the `file_snapshots` database table.
* CI verification is unavailable — `verify.status` and `verify.list_unverified` return `verification_available: false`.
* All other capabilities (memory, decisions, harness, drift, tautology, rollback, knowledge packs, agent profiling) are fully available.

### The `change_event` abstraction

`ASTChange` and `ProvenanceEdge` use `change_event_id: str` and `change_event_type: Literal["git_commit", "file_snapshot"]` instead of a bare `commit_hash`. All Phase 2–6 modules operate identically regardless of backend. The dashboard renders the change-event-type-appropriate label automatically.

### Upgrading file watcher → git

Run `git init`, then `whycode init --reinstall-hooks`. The server updates `change_detection_backend = "git"` in the config, installs git hooks, and stops the file watcher. Existing file_snapshot provenance records are preserved and remain queryable.

## Module responsibilities

| Module | Responsibility |
| --- | --- |
| `config.py` | Typed config from `whycode.toml`; permission + path-traversal checks |
| `models.py` | Dataclasses for every domain object + serialization helpers |
| `credential_manager.py` | Three-tier vault: env → keyring → AES-256-GCM file |
| `oauth_manager.py` | Browser PKCE flow, device flow, token refresh |
| `auth_service.py` | OIDC, email/password, JWT, PAT issuance |
| `auth_middleware.py` | Validate bearer tokens / PATs, inject user |
| `db_backend.py` | Async CRUD over SQLite / PostgreSQL with parameterised queries |
| `migrations.py` | Additive schema migrations (v1, v2, v3) |
| `embedder.py` | Ollama embedding client with retry and batching |
| `vector_store.py` | sqlite-vss and pgvector abstraction |
| `semantic_search.py` | index + search + persona re-ranking |
| `context_triage.py` | Token-budget-aware triage + summarisation |
| `ast_tracker.py` | tree-sitter parser + decision linker + unlinked-change audit |
| `tree_sitter_langs.py` | Grammar registry |
| `verifier.py` | CI webhook → decision status transitions |
| `harness.py` | Decision-density, complexity, import-health sensors |
| `conflict_detector.py` | Real-time multi-agent overlap detection |
| `provenance.py` | Forward/reverse graph walks; dependency + impact graphs |
| `drift_detector.py` | Architectural constraints vs current import graph |
| `tautology_detector.py` | Test-vs-acceptance-criterion similarity |
| `rollback_planner.py` | Decision dependency graph + risk assessment |
| `knowledge_packs.py` | Portable decision bundles (export/import) |
| `agent_profiler.py` | Per-agent capability stats |
| `git_hooks.py` | `.git/hooks/post-commit` installer |
| `file_watcher.py` | watchdog Observer + debounce |
| `snapshot_store.py` | File content snapshots for non-git diff |
| `project_claude_md.py` | CLAUDE.md template generator |
| `log_sanitizer.py` | Credential redaction formatter |
| `token_counter.py` | `cl100k_base` tiktoken wrapper |

## Limitations of file-watcher mode

* CI verification is unavailable. There is no commit hash for CI to reference. `verify.status`, `verify.list_unverified`, and `harness.score_commit` return `verification_available: false` with an explanatory note.
* Coverage delta sensor in `harness.score_snapshot` always returns `None` — the sensor requires a stash-based before/after state for git.
* `rollback_planner.plan_rollback` lists snapshot IDs in `affected_change_events` rather than commits; the risk assessment logic is identical.

All other capabilities — memory, decisions, harness decision-density, drift, tautology, rollback planning, knowledge packs, and agent profiling — are fully available in file-watcher mode.
