# WhyCode API Reference

This document lists every REST endpoint and every MCP tool method. All REST endpoints require bearer authentication (JWT or PAT); the webhook endpoints require `X-Webhook-Secret` instead.

Tools whose response degrades in `file_watcher` mode are marked **(file_watcher: degraded)**.

## Authentication

| Method | Description |
| --- | --- |
| HTTP cookies | Browser dashboard — `HttpOnly` JWT cookie |
| `Authorization: Bearer <token>` | MCP clients — JWT or PAT |
| `WHYCODE_TOKEN` env var | CI / Docker — solo-mode bearer token |

## REST endpoints

### Context
* `POST /api/context` — create
* `GET /api/context/{id}` — read
* `PATCH /api/context/{id}` — update
* `DELETE /api/context/{id}` — delete
* `GET /api/context` — list
* `POST /api/context/relevant` — semantic retrieval + token-budget triage
* `POST /api/context/for-file` — file-scoped retrieval

### Decisions
* `POST /api/decisions` — create
* `GET /api/decisions/{id}` — read
* `GET /api/decisions` — list
* `GET /api/decisions/{id}/trace` — forward provenance
* `POST /api/decisions/reverse-trace` — reverse provenance

### Stories / Sprints
* `POST /api/stories`, `GET /api/stories/{id}`, `PATCH /api/stories/{id}`, `GET /api/stories`
* `POST /api/sprints`, `GET /api/sprints/{id}/status`
* `GET /api/sprints/{sprint_id}/burndown` — burndown series
* `GET /api/sprints/velocity` — last-N-sprint velocity
* `GET /api/sprints/{sprint_id}/retrospective` — completed + carryover + failed decisions

### Sessions
* `POST /api/sessions` — start
* `POST /api/sessions/{id}/end` — end (with optional `force` + `override_reason`)
* `GET /api/sessions` — list
* `GET /api/sessions/{id}/replay` — full `SessionEvent` timeline
* `GET /api/sessions/{id}/conflicts` — real-time conflicts

### Verification **(file_watcher: degraded)**
* `GET /api/verify/status/{decision_id}` — returns `verification_available: false` in file_watcher mode
* `GET /api/verify/unverified` — same

### Provenance
* `GET /api/provenance/forward/{decision_id}` — decision → change events → AST changes
* `POST /api/provenance/reverse` — file + entity → decisions

### Harness
* `GET /api/harness/score/{session_id}` — session aggregate
* `GET /api/harness/score-commit/{commit_hash}` **(file_watcher: degraded — returns 400 with message)**

### Drift / Tautology / Rollback (Phase 5)
* `GET /api/drift/check` — architectural drift report
* `GET /api/test/check-tautology` — flagged tests
* `GET /api/rollback/plan/{decision_id}` — rollback plan

### Knowledge packs / Agents / Projects / Security (Phase 6)
* `POST /api/knowledge/export`, `POST /api/knowledge/import`, `GET /api/knowledge/exportable`
* `GET /api/agents/{agent_name}/profile` **(file_watcher: `verification_pass_rate` null)**
* `GET /api/agents/recommend/{story_id}`
* `GET /api/projects`
* `GET /api/security/status` — SEC-01 … SEC-11 status panel

### Standup
* `GET /api/standup`

### Hooks (webhook-secret-authenticated)
* `POST /api/hooks/post-commit`
* `POST /api/hooks/file-change`

### Health
* `GET /health` — unauthenticated

## MCP tools

All tools share a `method` parameter on the namespaced tool. Caller supplies `user_id` (resolved by the auth layer).

| Namespace | Methods |
| --- | --- |
| `context` | `create`, `read`, `update`, `delete`, `list`, `get_relevant`, `get_for_file` |
| `decision` | `create`, `read`, `list`, `trace`, `reverse_trace`, `search` |
| `story` | `create`, `read`, `update`, `list`, `search` |
| `sprint` | `create`, `status`, `burndown`, `velocity`, `retrospective` |
| `session` | `start`, `end`, `list`, `replay`, `conflicts`, `search` |
| `standup` | `generate` |
| `verify` **(file_watcher: degraded)** | `status`, `list_unverified` |
| `provenance` | `forward`, `reverse` |
| `harness` | `score`, `score_commit` **(file_watcher: unavailable)** |
| `drift` | `check`, `report` |
| `test` | `check_tautology` |
| `rollback` | `plan` |
| `knowledge` | `export`, `import`, `list_exportable`, `list_packs` |
| `agent` | `profile` **(file_watcher: `verification_pass_rate` null)**, `recommend`, `context_adjustment` |
| `project` | `create`, `list`, `switch`, `members` |
| `retrospective` | `generate` |

**Total: 52 methods** across 16 namespaces.

## File-watcher degradation matrix

| Tool / endpoint | Behaviour in `file_watcher` mode |
| --- | --- |
| `verify.status` / `GET /api/verify/status/{id}` | `{verification_available: false, change_detection_backend: "file_watcher"}` |
| `verify.list_unverified` / `GET /api/verify/unverified` | Same as above |
| `harness.score_commit` | `HandlerError` — there is no commit hash in file_watcher mode |
| `harness.score_snapshot` (internal) | `coverage_delta: None`, `coverage_status: "unavailable"` |
| `agent.profile` | `verification_pass_rate: null` with an explanatory note |
| `rollback.plan` | `affected_change_events` labels use `"Snapshot <path> at <timestamp>"` rather than commit hashes |
| `provenance.forward` / `provenance.reverse` | Event labels rendered per event type (snapshot vs commit) |
| `drift.check`, `test.check_tautology`, `knowledge.*`, `agent.recommend` | Fully available |
