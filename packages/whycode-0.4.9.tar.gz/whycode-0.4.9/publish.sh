#!/bin/bash
# WhyCode PyPI publish script
# Run this when ready to publish to PyPI
# Requires: twine configured with API token in ~/.pypirc or TWINE_PASSWORD env var

set -e

echo "Publishing whycode to PyPI..."
echo ""

# Verify dist-ready exists
if [ ! -d "dist-ready" ]; then
  echo "ERROR: dist-ready/ not found. Run: python3 -m build --outdir dist-ready/"
  exit 1
fi

# Show what will be uploaded
echo "Files to upload:"
ls -la dist-ready/
echo ""

# Confirm
read -p "Upload these files to PyPI? (y/N): " confirm
if [ "$confirm" != "y" ] && [ "$confirm" != "Y" ]; then
  echo "Cancelled."
  exit 0
fi

# Upload
twine upload dist-ready/*

echo ""
echo "Published successfully."
echo "View at: https://pypi.org/project/whycode/"
