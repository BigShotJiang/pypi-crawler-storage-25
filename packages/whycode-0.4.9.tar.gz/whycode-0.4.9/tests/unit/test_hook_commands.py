"""Platform-aware Claude Code hook command tests.

Covers the 0.4.6 fix where Windows hosts receive ``python3 -c "…"``
hook commands instead of the Linux/macOS ``bash -lc '…'`` + ``curl``
form. The critical invariants:

* On Windows the generated command never contains ``bash`` or ``curl``.
* On Linux/macOS the command keeps the historical bash+curl shape.
* The Windows command's embedded Python parses cleanly with
  :mod:`ast` so a typo here surfaces in CI instead of at runtime on a
  user's box where the hook would silently exit 0.
* :func:`write_claude_code_settings` drops the pre-rename
  ``codeledger`` MCP entry and preserves the user's existing ``env``
  block.
"""

from __future__ import annotations

import ast
import json
import platform
from pathlib import Path

import pytest

from backend.utils.hook_builder import HookSpec, build_hook_command


_SAMPLE_FIELDS = {"cwd": "CLAUDE_CWD", "prompt": "CLAUDE_USER_PROMPT"}


def _spec(**overrides: object) -> HookSpec:
    defaults: dict[str, object] = {
        "endpoint": "/api/hooks/session-context",
        "server_url": "http://127.0.0.1:8100",
        "token": "test_token",
        "payload_fields": _SAMPLE_FIELDS,
        "output_mode": "context_block",
        "timeout_ms": 3000,
    }
    defaults.update(overrides)
    return HookSpec(**defaults)  # type: ignore[arg-type]


def test_windows_hook_uses_python_not_bash(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(platform, "system", lambda: "Windows")
    cmd = build_hook_command(_spec())
    assert "bash" not in cmd
    assert "curl" not in cmd
    assert "python3" in cmd
    assert "urllib.request" in cmd
    assert "test_token" in cmd
    assert "/api/hooks/session-context" in cmd


def test_linux_hook_uses_bash(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(platform, "system", lambda: "Linux")
    cmd = build_hook_command(_spec())
    assert "bash -lc" in cmd
    assert "curl" in cmd
    assert "test_token" in cmd


def test_macos_hook_uses_bash(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(platform, "system", lambda: "Darwin")
    cmd = build_hook_command(
        _spec(
            endpoint="/api/hooks/close-session",
            payload_fields={"cwd": "CLAUDE_CWD"},
            output_mode="none",
            timeout_ms=4000,
        )
    )
    assert "bash -lc" in cmd


def test_windows_hook_command_is_valid_python(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The embedded Python must parse — a syntax error here ships
    broken hooks that exit 0 silently on every Windows box."""
    monkeypatch.setattr(platform, "system", lambda: "Windows")
    cmd = build_hook_command(_spec(token="tok123"))
    # Extract the Python body from: python3 -c "…" 2>NUL || exit /b 0
    python_code = cmd.split('"', 1)[1].rsplit('"', 1)[0]
    try:
        ast.parse(python_code)
    except SyntaxError as exc:
        raise AssertionError(
            f"Generated Python code is invalid: {exc}\nCode: {python_code}"
        ) from exc


@pytest.mark.parametrize(
    "output_mode",
    ["none", "context_block", "conflict_warning", "import_warning"],
)
def test_windows_all_output_modes_parse(
    monkeypatch: pytest.MonkeyPatch, output_mode: str
) -> None:
    monkeypatch.setattr(platform, "system", lambda: "Windows")
    cmd = build_hook_command(
        _spec(
            output_mode=output_mode,
            payload_fields={
                "cwd": "CLAUDE_CWD",
                "file_path": "CLAUDE_TOOL_FILE_PATH",
            },
        )
    )
    python_code = cmd.split('"', 1)[1].rsplit('"', 1)[0]
    ast.parse(python_code)


def test_windows_cwd_falls_back_to_getcwd(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """CLAUDE_CWD is not always set — the fallback to os.getcwd() is
    what makes the hook work from a plain cmd.exe spawn."""
    monkeypatch.setattr(platform, "system", lambda: "Windows")
    cmd = build_hook_command(_spec())
    assert "os.getcwd()" in cmd


def test_linux_cwd_falls_back_to_getcwd(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(platform, "system", lambda: "Linux")
    cmd = build_hook_command(_spec())
    assert "os.getcwd()" in cmd


def test_build_settings_removes_duplicate_codeledger_entry(
    tmp_path: Path,
) -> None:
    """Pre-rename installs left a stale ``codeledger`` key; the new
    writer must pop it so Claude Code does not load the same server
    under two names."""
    from backend.cli import write_claude_code_settings

    settings_path = tmp_path / "settings.json"
    existing = {
        "mcpServers": {
            "codeledger": {"url": "http://127.0.0.1:8100/mcp"},
            "whycode": {"url": "http://127.0.0.1:8100/mcp"},
            "someone-else": {"url": "http://localhost:9000/mcp"},
        }
    }
    settings_path.write_text(json.dumps(existing), encoding="utf-8")

    write_claude_code_settings(
        settings_path, "http://127.0.0.1:8100", "tok"
    )
    result = json.loads(settings_path.read_text(encoding="utf-8"))
    assert "codeledger" not in result["mcpServers"]
    assert "whycode" in result["mcpServers"]
    # Unrelated MCP entries survive the rewrite.
    assert "someone-else" in result["mcpServers"]


def test_settings_preserves_existing_env_block(tmp_path: Path) -> None:
    """Existing ``env`` entries (e.g. NODE_TLS_REJECT_UNAUTHORIZED)
    must survive a hook refresh — users set these deliberately."""
    from backend.cli import write_claude_code_settings

    settings_path = tmp_path / "settings.json"
    existing = {
        "env": {
            "NODE_TLS_REJECT_UNAUTHORIZED": "0",
            "NODE_EXTRA_CA_CERTS": "C:/some/path.pem",
        }
    }
    settings_path.write_text(json.dumps(existing), encoding="utf-8")

    write_claude_code_settings(
        settings_path, "http://127.0.0.1:8100", "tok"
    )
    result = json.loads(settings_path.read_text(encoding="utf-8"))
    assert result["env"]["NODE_TLS_REJECT_UNAUTHORIZED"] == "0"
    assert result["env"]["NODE_EXTRA_CA_CERTS"] == "C:/some/path.pem"


def test_windows_hook_escapes_token_safely(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Tokens never come from untrusted input (vault-generated), but a
    token containing a double quote would still break the generated
    command. Verify the vault token format (cl_solo_<base64url>) is
    round-trippable as-is."""
    monkeypatch.setattr(platform, "system", lambda: "Windows")
    cmd = build_hook_command(
        _spec(token="cl_solo_abc123-_ABC"),
    )
    assert "cl_solo_abc123-_ABC" in cmd
    python_code = cmd.split('"', 1)[1].rsplit('"', 1)[0]
    ast.parse(python_code)
