"""Regression tests for the v0.4.7 fix batch.

Covers:

* ``decision.list`` defaults to ``active_only=True`` and excludes
  rows whose ``superseded_by`` is set.
* ``_update_claude_settings_token`` and ``_update_claude_json_token``
  rewrite stale ``cl_solo_*`` tokens in ``~/.claude/settings.json``
  and ``~/.claude.json`` without trampling surrounding config.
* ``auto_migrate_vault_dir`` copies ``~/.codeledger`` into
  ``~/.whycode`` on first call and is a no-op afterwards.
* ``_build_embedder`` always returns a non-``None`` embedder and
  resolves to the local backend when Ollama is unreachable.
"""

from __future__ import annotations

import json
import uuid
from pathlib import Path
from typing import Any

import pytest

from backend.cli import (
    _update_claude_json_token,
    _update_claude_settings_token,
)
from backend.db.db_backend import SQLiteBackend
from backend.mcp.tool_handlers import ToolHandlers
from backend.models import Decision


# ---------------------------------------------------------------------------
# decision.list active_only filter
# ---------------------------------------------------------------------------


async def _make_handlers(tmp_path: Path) -> ToolHandlers:
    db = SQLiteBackend(str(tmp_path / "whycode.db"))
    await db.connect()
    from backend.db.migrations import apply_migrations

    await apply_migrations(db)
    return ToolHandlers(db=db)


async def _insert_decision(
    handlers: ToolHandlers,
    *,
    title: str,
    superseded_by: str | None = None,
) -> Decision:
    decision = Decision(title=title, description="x")
    if superseded_by is not None:
        decision.superseded_by = superseded_by
    await handlers.db.insert("decisions", decision.to_dict())
    return decision


@pytest.mark.asyncio
async def test_decision_list_excludes_superseded_by_default(
    tmp_path: Path,
) -> None:
    handlers = await _make_handlers(tmp_path)
    active = await _insert_decision(handlers, title="active")
    await _insert_decision(
        handlers, title="superseded", superseded_by=str(active.id)
    )

    rows = await handlers.decision_list(user_id=uuid.uuid4())
    titles = [r["title"] for r in rows]
    assert "active" in titles
    assert "superseded" not in titles


@pytest.mark.asyncio
async def test_decision_list_includes_superseded_when_asked(
    tmp_path: Path,
) -> None:
    handlers = await _make_handlers(tmp_path)
    active = await _insert_decision(handlers, title="active")
    await _insert_decision(
        handlers, title="superseded", superseded_by=str(active.id)
    )

    rows = await handlers.decision_list(
        user_id=uuid.uuid4(), active_only=False
    )
    titles = {r["title"] for r in rows}
    assert titles == {"active", "superseded"}


@pytest.mark.asyncio
async def test_decision_list_active_only_with_status_filter(
    tmp_path: Path,
) -> None:
    """Status + active_only compose via AND."""
    handlers = await _make_handlers(tmp_path)
    active = await _insert_decision(handlers, title="active")
    d2 = Decision(title="passed-superseded", status="passed")
    d2.superseded_by = str(active.id)
    await handlers.db.insert("decisions", d2.to_dict())
    d3 = Decision(title="passed-active", status="passed")
    await handlers.db.insert("decisions", d3.to_dict())

    rows = await handlers.decision_list(user_id=uuid.uuid4(), status="passed")
    titles = [r["title"] for r in rows]
    assert "passed-active" in titles
    assert "passed-superseded" not in titles


# ---------------------------------------------------------------------------
# _update_claude_settings_token — regex rewrite
# ---------------------------------------------------------------------------


def test_update_claude_settings_token_replaces_stale(tmp_path: Path) -> None:
    settings = tmp_path / "settings.json"
    settings.write_text(
        '{"mcpServers":{"whycode":{"headers":{"Authorization":'
        '"Bearer cl_solo_oldtoken123-foo"}}}}',
        encoding="utf-8",
    )
    assert _update_claude_settings_token(settings, "cl_solo_newtoken456") is True
    written = settings.read_text(encoding="utf-8")
    assert "cl_solo_newtoken456" in written
    assert "cl_solo_oldtoken123-foo" not in written


def test_update_claude_settings_token_no_change_if_same(tmp_path: Path) -> None:
    settings = tmp_path / "settings.json"
    settings.write_text(
        '{"token":"cl_solo_same_abc"}', encoding="utf-8"
    )
    assert _update_claude_settings_token(settings, "cl_solo_same_abc") is False


def test_update_claude_settings_token_replaces_all_occurrences(
    tmp_path: Path,
) -> None:
    """Hook commands embed the token inline; every occurrence must
    flip so hooks start working on the next prompt."""
    settings = tmp_path / "settings.json"
    settings.write_text(
        'Authorization: Bearer cl_solo_stale1 and Bearer cl_solo_stale2',
        encoding="utf-8",
    )
    assert _update_claude_settings_token(settings, "cl_solo_fresh") is True
    written = settings.read_text(encoding="utf-8")
    assert "cl_solo_stale1" not in written
    assert "cl_solo_stale2" not in written
    assert written.count("cl_solo_fresh") == 2


def test_update_claude_settings_token_missing_file(tmp_path: Path) -> None:
    assert (
        _update_claude_settings_token(
            tmp_path / "does-not-exist.json", "cl_solo_fresh"
        )
        is False
    )


# ---------------------------------------------------------------------------
# _update_claude_json_token — JSON-level rewrite
# ---------------------------------------------------------------------------


def test_update_claude_json_token_updates_whycode_entry(
    tmp_path: Path,
) -> None:
    path = tmp_path / ".claude.json"
    path.write_text(
        json.dumps(
            {
                "mcpServers": {
                    "whycode": {
                        "headers": {"Authorization": "Bearer cl_solo_old"}
                    },
                    "other": {
                        "headers": {"Authorization": "Bearer cl_solo_untouched"}
                    },
                }
            }
        ),
        encoding="utf-8",
    )
    updated = _update_claude_json_token(path, "cl_solo_new")
    assert updated == ["whycode"]
    data = json.loads(path.read_text(encoding="utf-8"))
    assert (
        data["mcpServers"]["whycode"]["headers"]["Authorization"]
        == "Bearer cl_solo_new"
    )
    # Unrelated entries are left alone — we don't know what token they use.
    assert (
        data["mcpServers"]["other"]["headers"]["Authorization"]
        == "Bearer cl_solo_untouched"
    )


def test_update_claude_json_token_updates_codeledger_entry(
    tmp_path: Path,
) -> None:
    """Pre-rename installs wrote ``codeledger`` as the MCP server name;
    the helper must refresh that entry too."""
    path = tmp_path / ".claude.json"
    path.write_text(
        json.dumps(
            {
                "mcpServers": {
                    "codeledger": {
                        "headers": {"Authorization": "Bearer cl_solo_legacy"}
                    }
                }
            }
        ),
        encoding="utf-8",
    )
    updated = _update_claude_json_token(path, "cl_solo_new")
    assert updated == ["codeledger"]


def test_update_claude_json_token_noop_when_same(tmp_path: Path) -> None:
    path = tmp_path / ".claude.json"
    path.write_text(
        json.dumps(
            {
                "mcpServers": {
                    "whycode": {
                        "headers": {"Authorization": "Bearer cl_solo_same"}
                    }
                }
            }
        ),
        encoding="utf-8",
    )
    assert _update_claude_json_token(path, "cl_solo_same") == []


def test_update_claude_json_token_missing_file(tmp_path: Path) -> None:
    assert (
        _update_claude_json_token(tmp_path / "missing.json", "cl_solo_x")
        == []
    )


# ---------------------------------------------------------------------------
# auto_migrate_vault_dir
# ---------------------------------------------------------------------------


def test_auto_migrate_copies_legacy_dir(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    import backend.auth.credential_manager as cm

    legacy = tmp_path / ".codeledger"
    whycode = tmp_path / ".whycode"
    legacy.mkdir()
    (legacy / "vault.enc").write_text("opaque-bytes", encoding="utf-8")

    monkeypatch.setattr(cm, "_LEGACY_VAULT_DIR", legacy)
    monkeypatch.setattr(cm, "_WHYCODE_VAULT_DIR", whycode)

    result = cm.auto_migrate_vault_dir()
    assert result == whycode
    assert (whycode / "vault.enc").read_text(encoding="utf-8") == "opaque-bytes"
    # Legacy dir is preserved — non-destructive copy.
    assert legacy.exists()
    assert (legacy / "vault.enc").exists()


def test_auto_migrate_noop_when_whycode_exists(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    import backend.auth.credential_manager as cm

    legacy = tmp_path / ".codeledger"
    whycode = tmp_path / ".whycode"
    whycode.mkdir()
    (whycode / "vault.enc").write_text("live", encoding="utf-8")
    legacy.mkdir()
    (legacy / "vault.enc").write_text("stale", encoding="utf-8")

    monkeypatch.setattr(cm, "_LEGACY_VAULT_DIR", legacy)
    monkeypatch.setattr(cm, "_WHYCODE_VAULT_DIR", whycode)

    cm.auto_migrate_vault_dir()
    # Live file must survive — migration should not overwrite.
    assert (whycode / "vault.enc").read_text(encoding="utf-8") == "live"


def test_auto_migrate_creates_fresh_dir_when_neither_exists(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    import backend.auth.credential_manager as cm

    legacy = tmp_path / ".codeledger"
    whycode = tmp_path / ".whycode"
    monkeypatch.setattr(cm, "_LEGACY_VAULT_DIR", legacy)
    monkeypatch.setattr(cm, "_WHYCODE_VAULT_DIR", whycode)

    assert cm.auto_migrate_vault_dir() == whycode
    assert whycode.is_dir()


# ---------------------------------------------------------------------------
# _build_embedder — always returns a non-None embedder
# ---------------------------------------------------------------------------


def test_build_embedder_falls_back_to_local_when_ollama_unreachable(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If Ollama is unreachable, the factory must fall back to the
    local sentence-transformers embedder rather than returning None
    or raising — the whole point of the v0.4.7 fix.

    Stubs the ``sentence_transformers`` package at the ``sys.modules``
    level so the test runs in CI without actually installing torch.
    Required because ``backend.main`` runs ``app = create_app()`` at
    module import time, which constructs a real embedder.
    """
    import sys
    import types

    if "sentence_transformers" not in sys.modules:
        stub = types.ModuleType("sentence_transformers")

        class _StubModel:
            def __init__(self, *_a: Any, **_k: Any) -> None:
                pass

            def encode(self, texts: Any, **_k: Any) -> list[list[float]]:
                if isinstance(texts, str):
                    return [0.0] * 384  # type: ignore[return-value]
                return [[0.0] * 384 for _ in texts]

        stub.SentenceTransformer = _StubModel  # type: ignore[attr-defined]
        monkeypatch.setitem(sys.modules, "sentence_transformers", stub)

    # Force reimport so the stubbed module is picked up by
    # SentenceTransformerEmbedder's lazy import.
    import backend.main as backend_main
    from backend.config import WhyCodeConfig

    monkeypatch.setattr(backend_main, "_probe_ollama", lambda *_a, **_k: False)

    cfg = WhyCodeConfig()
    embedder, resolved, dim = backend_main._build_embedder(cfg)
    assert embedder is not None
    assert resolved == "local"
    assert dim == 384
