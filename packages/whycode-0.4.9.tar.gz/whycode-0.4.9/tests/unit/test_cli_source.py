"""Tests for the ``whycode source`` CLI command group.

Exercised through Click's :class:`CliRunner`. The tests monkeypatch
:func:`backend.cli._load_registry_for_cli` so they do not require an
on-disk SQLite file or migrations to run — the command surface is what
is under test, not the registry plumbing (covered in
``test_detection_registry``).
"""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime
from typing import Any

import pytest
from click.testing import CliRunner

from backend import cli as cli_module
from backend.detection.base import DetectorStatus


class _FakeDetector:
    def __init__(self) -> None:
        self._status = DetectorStatus.HEALTHY

    async def health(self) -> DetectorStatus:
        return self._status


class _FakeRegistry:
    """In-memory stand-in for the real DetectorRegistry."""

    def __init__(self) -> None:
        self._preferences: dict[str, str] = {}
        self.audit: list[tuple[str, str, str]] = []

    async def get_preferred_source(self, project_id: str) -> str:
        return self._preferences.get(project_id, "git_commit")

    async def status(self, project_id: str) -> dict[str, Any]:
        return {
            "project_id": project_id,
            "current_source": await self.get_preferred_source(project_id),
            "actor_config": {
                "types_allowed": ["agent", "ci_bot", "human", "webhook_bot"]
            },
            "detector_health": "healthy",
            "queue_depth": 0,
        }

    async def switch_source(
        self, project_id: str, new_source: str
    ):  # type: ignore[no-untyped-def]
        from backend.detection.registry import SwitchResult

        prev = await self.get_preferred_source(project_id)
        if prev == new_source:
            return SwitchResult(
                success=True,
                reason="noop",
                previous_source=prev,
                new_source=new_source,
            )
        self._preferences[project_id] = new_source
        self.audit.append((project_id, prev, new_source))
        return SwitchResult(
            success=True, previous_source=prev, new_source=new_source
        )


class _FakeBackend:
    async def close(self) -> None:
        return None


@pytest.fixture
def patched_registry(monkeypatch: pytest.MonkeyPatch) -> _FakeRegistry:
    registry = _FakeRegistry()
    backend = _FakeBackend()

    async def _load_fake() -> tuple[Any, Any]:
        return backend, registry

    monkeypatch.setattr(cli_module, "_load_registry_for_cli", _load_fake)
    monkeypatch.setattr(cli_module, "_project_id_for_cwd", lambda: "proj")
    return registry


class TestSourceShow:
    def test_prints_current_status(
        self, patched_registry: _FakeRegistry
    ) -> None:
        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["source", "show"])
        assert result.exit_code == 0, result.output
        assert "project_id: proj" in result.output
        assert "current_source: git_commit" in result.output
        assert "detector health: healthy" in result.output


class TestSourceHealth:
    def test_prints_health_line(
        self, patched_registry: _FakeRegistry
    ) -> None:
        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["source", "health"])
        assert result.exit_code == 0, result.output
        assert "source: git_commit" in result.output
        assert "health: healthy" in result.output


class TestSourceSet:
    def test_yes_flag_skips_prompt(
        self, patched_registry: _FakeRegistry
    ) -> None:
        runner = CliRunner()
        result = runner.invoke(
            cli_module.cli,
            ["source", "set", "--source", "file_snapshot", "--yes"],
        )
        assert result.exit_code == 0, result.output
        assert "git_commit -> file_snapshot" in result.output
        assert patched_registry._preferences["proj"] == "file_snapshot"

    def test_interactive_accept(
        self, patched_registry: _FakeRegistry
    ) -> None:
        runner = CliRunner()
        result = runner.invoke(
            cli_module.cli,
            ["source", "set", "--source", "file_snapshot"],
            input="y\n",
        )
        assert result.exit_code == 0, result.output
        assert "file_snapshot" in result.output

    def test_interactive_decline(
        self, patched_registry: _FakeRegistry
    ) -> None:
        runner = CliRunner()
        result = runner.invoke(
            cli_module.cli,
            ["source", "set", "--source", "file_snapshot"],
            input="n\n",
        )
        assert result.exit_code == 1
        assert "aborted" in result.output
        assert "proj" not in patched_registry._preferences

    def test_same_source_is_noop_with_message(
        self, patched_registry: _FakeRegistry
    ) -> None:
        runner = CliRunner()
        result = runner.invoke(
            cli_module.cli,
            ["source", "set", "--source", "git_commit", "--yes"],
        )
        assert result.exit_code == 0
        assert "already set to git_commit" in result.output

    def test_invalid_source_rejected_by_click(
        self, patched_registry: _FakeRegistry
    ) -> None:
        runner = CliRunner()
        result = runner.invoke(
            cli_module.cli,
            ["source", "set", "--source", "svn", "--yes"],
        )
        assert result.exit_code != 0
        assert "Invalid value" in result.output


class TestSourceHealthFailureExit:
    def test_degraded_exits_nonzero(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        registry = _FakeRegistry()

        # Override status to report degraded.
        orig_status = registry.status

        async def degraded_status(pid: str) -> dict[str, Any]:
            data = await orig_status(pid)
            data["detector_health"] = "degraded"
            return data

        registry.status = degraded_status  # type: ignore[method-assign]
        monkeypatch.setattr(
            cli_module,
            "_load_registry_for_cli",
            lambda: _as_coro(registry),
        )
        monkeypatch.setattr(cli_module, "_project_id_for_cwd", lambda: "proj")
        runner = CliRunner()
        result = runner.invoke(cli_module.cli, ["source", "health"])
        assert result.exit_code == 1
        assert "degraded" in result.output


async def _as_coro(registry: _FakeRegistry) -> tuple[Any, Any]:
    return _FakeBackend(), registry
