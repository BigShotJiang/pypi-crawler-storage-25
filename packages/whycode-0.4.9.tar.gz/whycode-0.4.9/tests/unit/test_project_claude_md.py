"""Tests for backend.utils.project_claude_md — project CLAUDE.md generation.

Covers: all five required sections present, correct backend blurb for git
vs file_watcher, server URL embedded in examples, safe re-init (user
content below the delimiter preserved), delimiter insertion when missing,
and no duplication on repeated runs.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from backend.utils.project_claude_md import (
    generate_project_claude_md,
    write_project_claude_md,
)

if TYPE_CHECKING:
    from pathlib import Path


SERVER = "http://localhost:8100"


# ---------------------------------------------------------------------------
# generate_project_claude_md
# ---------------------------------------------------------------------------


class TestGenerate:
    """Structural checks on the rendered template string."""

    def test_contains_all_five_sections(self) -> None:
        text = generate_project_claude_md("my-proj", SERVER, "git")
        assert "## WhyCode is active" in text
        assert "## Session lifecycle" in text
        assert "## Decision recording" in text
        assert "## Context retrieval" in text
        assert "## Explicit prohibitions" in text

    def test_git_backend_blurb(self) -> None:
        text = generate_project_claude_md("p", SERVER, "git")
        assert "backend: **git**" in text
        assert "file watcher" not in text.lower().split("## session")[0] or \
            "backend: **git**" in text

    def test_file_watcher_backend_blurb(self) -> None:
        text = generate_project_claude_md("p", SERVER, "file_watcher")
        assert "backend: **file watcher**" in text
        assert "whycode init --reinstall-hooks" in text

    def test_server_url_in_examples(self) -> None:
        text = generate_project_claude_md(
            "p", "http://example.internal:9000", "git"
        )
        assert "http://example.internal:9000" in text

    def test_rejects_invalid_backend(self) -> None:
        with pytest.raises(ValueError):
            generate_project_claude_md("p", SERVER, "svn")

    def test_project_name_in_header(self) -> None:
        text = generate_project_claude_md("my-service", SERVER, "git")
        assert "# CLAUDE.md — my-service" in text

    def test_empty_project_name_tolerated(self) -> None:
        text = generate_project_claude_md("", SERVER, "git")
        assert "CLAUDE.md" in text


# ---------------------------------------------------------------------------
# write_project_claude_md — creation
# ---------------------------------------------------------------------------


class TestWriteCreate:
    """Writing into an empty project root produces a complete file."""

    def test_creates_file_when_absent(self, tmp_path: Path) -> None:
        path = write_project_claude_md(tmp_path, "proj", SERVER, "git")
        assert path.exists()
        body = path.read_text(encoding="utf-8")
        assert "## WhyCode is active" in body
        assert "## Project-Specific Instructions" in body

    def test_missing_project_root_raises(self, tmp_path: Path) -> None:
        target = tmp_path / "nope"
        with pytest.raises(OSError):
            write_project_claude_md(target, "p", SERVER, "git")

    def test_file_backend_section_when_no_git(self, tmp_path: Path) -> None:
        path = write_project_claude_md(tmp_path, "p", SERVER, "file_watcher")
        body = path.read_text(encoding="utf-8")
        assert "backend: **file watcher**" in body


# ---------------------------------------------------------------------------
# write_project_claude_md — re-init with delimiter
# ---------------------------------------------------------------------------


class TestWriteReinitWithDelimiter:
    """User content below the delimiter survives re-init."""

    def test_preserves_user_content_below_delimiter(
        self, tmp_path: Path
    ) -> None:
        original = (
            "# CLAUDE.md — old\n\n"
            "old header text\n\n"
            "## Project-Specific Instructions\n\n"
            "user-written notes about the API\n"
            "more custom rules here\n"
        )
        (tmp_path / "CLAUDE.md").write_text(original, encoding="utf-8")

        write_project_claude_md(tmp_path, "p", SERVER, "git")
        body = (tmp_path / "CLAUDE.md").read_text(encoding="utf-8")
        assert "user-written notes about the API" in body
        assert "more custom rules here" in body
        # Managed section refreshed
        assert "## WhyCode is active" in body

    def test_no_duplication_on_repeated_runs(self, tmp_path: Path) -> None:
        write_project_claude_md(tmp_path, "p", SERVER, "git")
        write_project_claude_md(tmp_path, "p", SERVER, "git")
        body = (tmp_path / "CLAUDE.md").read_text(encoding="utf-8")
        assert body.count("## WhyCode is active") == 1
        assert body.count("## Project-Specific Instructions") == 1

    def test_switches_backend_description(self, tmp_path: Path) -> None:
        write_project_claude_md(tmp_path, "p", SERVER, "file_watcher")
        write_project_claude_md(tmp_path, "p", SERVER, "git")
        body = (tmp_path / "CLAUDE.md").read_text(encoding="utf-8")
        assert "backend: **git**" in body
        assert "backend: **file watcher**" not in body


# ---------------------------------------------------------------------------
# write_project_claude_md — re-init without delimiter
# ---------------------------------------------------------------------------


class TestWriteReinitWithoutDelimiter:
    """When the existing file has no delimiter, existing content is preserved."""

    def test_prepends_and_preserves(self, tmp_path: Path) -> None:
        existing = "# Project notes\n\nLegacy content here.\n"
        (tmp_path / "CLAUDE.md").write_text(existing, encoding="utf-8")

        write_project_claude_md(tmp_path, "p", SERVER, "git")
        body = (tmp_path / "CLAUDE.md").read_text(encoding="utf-8")

        # Managed section appears first
        header_idx = body.find("## WhyCode is active")
        delim_idx = body.find("## Project-Specific Instructions")
        legacy_idx = body.find("Legacy content here.")
        assert 0 <= header_idx < delim_idx < legacy_idx

    def test_original_content_not_lost(self, tmp_path: Path) -> None:
        existing = "Important: don't touch file X.\n"
        (tmp_path / "CLAUDE.md").write_text(existing, encoding="utf-8")
        write_project_claude_md(tmp_path, "p", SERVER, "git")
        body = (tmp_path / "CLAUDE.md").read_text(encoding="utf-8")
        assert "Important: don't touch file X." in body


class TestClientSpecificSection:
    """Client-specific guidance in the generated template."""

    def test_claude_code_section_present(self) -> None:
        from backend.utils.project_claude_md import generate_project_claude_md

        rendered = generate_project_claude_md(
            project_name="demo",
            server_url="http://127.0.0.1:8100",
            change_detection_backend="git",
        )
        assert "### Claude Code" in rendered
        assert "UserPromptSubmit" in rendered

    def test_non_claude_code_section_includes_before_edit(self) -> None:
        from backend.utils.project_claude_md import generate_project_claude_md

        rendered = generate_project_claude_md(
            project_name="demo",
            server_url="http://127.0.0.1:8100",
            change_detection_backend="git",
        )
        # Both Cursor and Windsurf clients should be named, and the
        # single tool they use in place of hooks should be called out.
        assert "Cursor" in rendered
        assert "Windsurf" in rendered
        assert "context.before_edit" in rendered
        assert "inactivity_timeout_minutes" in rendered
