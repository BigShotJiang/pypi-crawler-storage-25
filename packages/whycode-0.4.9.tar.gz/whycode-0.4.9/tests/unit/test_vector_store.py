"""Unit tests for backend/db/vector_store.py.

Covers the SqliteVssStore implementation end-to-end using temporary SQLite
database files. PgVectorStore tests are skipped unless ``WHYCODE_PG_DSN``
points at a reachable Postgres instance with pgvector installed.

Known-vector fixtures let us check that cosine ranking is correct without
relying on a live Ollama instance.
"""

from __future__ import annotations

import asyncio
import math
import os
from itertools import pairwise
from typing import TYPE_CHECKING, Any

import pytest

from backend.config import DatabaseConfig
from backend.db.vector_store import (
    DEFAULT_DIM,
    PgVectorStore,
    SqliteVssStore,
    VectorStoreError,
    get_vector_store,
)

if TYPE_CHECKING:
    from pathlib import Path

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _unit(index: int, dim: int = DEFAULT_DIM) -> list[float]:
    """Return a unit basis vector with a 1.0 at ``index`` and zeros elsewhere."""
    vec = [0.0] * dim
    vec[index] = 1.0
    return vec


def _blend(a: list[float], b: list[float], weight_a: float) -> list[float]:
    """Return an un-normalised linear combination ``a*weight_a + b*(1-weight_a)``."""
    weight_b = 1.0 - weight_a
    return [weight_a * x + weight_b * y for x, y in zip(a, b, strict=True)]


# ---------------------------------------------------------------------------
# SqliteVssStore — lifecycle, validation, and CRUD
# ---------------------------------------------------------------------------


class TestSqliteVssLifecycle:
    async def test_connect_creates_tables_and_virtual_table(
        self, tmp_path: Path
    ) -> None:
        store = SqliteVssStore(tmp_path / "vectors.db")
        await store.connect()
        try:
            assert store.dim == DEFAULT_DIM
            # Fresh DB starts empty
            assert await store.count() == 0
        finally:
            await store.close()

    async def test_operations_before_connect_raise(self, tmp_path: Path) -> None:
        store = SqliteVssStore(tmp_path / "vectors.db")
        with pytest.raises(VectorStoreError):
            await store.count()
        with pytest.raises(VectorStoreError):
            await store.insert("id-1", _unit(0), {})

    async def test_close_is_idempotent(self, tmp_path: Path) -> None:
        store = SqliteVssStore(tmp_path / "vectors.db")
        await store.connect()
        await store.close()
        # Second close is a no-op, not an error.
        await store.close()

    async def test_connect_creates_parent_directory(self, tmp_path: Path) -> None:
        nested = tmp_path / "nested" / "deep" / "vectors.db"
        store = SqliteVssStore(nested)
        await store.connect()
        try:
            assert nested.parent.is_dir()
        finally:
            await store.close()


class TestSqliteVssValidation:
    @pytest.fixture
    async def store(self, tmp_path: Path) -> Any:
        store = SqliteVssStore(tmp_path / "v.db")
        await store.connect()
        yield store
        await store.close()

    async def test_insert_rejects_empty_item_id(self, store: SqliteVssStore) -> None:
        with pytest.raises(VectorStoreError):
            await store.insert("", _unit(0), {})

    async def test_insert_rejects_wrong_dim(self, store: SqliteVssStore) -> None:
        with pytest.raises(VectorStoreError):
            await store.insert("id-1", [0.0, 1.0], {})

    async def test_insert_rejects_non_numeric(self, store: SqliteVssStore) -> None:
        bad = [0.0] * DEFAULT_DIM
        bad[0] = "oops"  # type: ignore[call-overload]
        with pytest.raises(VectorStoreError):
            await store.insert("id-1", bad, {})

    async def test_insert_rejects_bool_in_vector(self, store: SqliteVssStore) -> None:
        bad = [0.0] * DEFAULT_DIM
        bad[0] = True  # type: ignore[call-overload]
        with pytest.raises(VectorStoreError):
            await store.insert("id-1", bad, {})

    async def test_insert_rejects_non_dict_metadata(
        self, store: SqliteVssStore
    ) -> None:
        with pytest.raises(VectorStoreError):
            await store.insert("id-1", _unit(0), "not-a-dict")  # type: ignore[arg-type]

    async def test_insert_rejects_non_string_project_id(
        self, store: SqliteVssStore
    ) -> None:
        with pytest.raises(VectorStoreError):
            await store.insert("id-1", _unit(0), {"project_id": 42})

    async def test_insert_rejects_duplicate_item_id(
        self, store: SqliteVssStore
    ) -> None:
        await store.insert("id-1", _unit(0), {})
        with pytest.raises(VectorStoreError):
            await store.insert("id-1", _unit(1), {})

    async def test_search_rejects_non_positive_top_k(
        self, store: SqliteVssStore
    ) -> None:
        await store.insert("id-1", _unit(0), {})
        with pytest.raises(VectorStoreError):
            await store.search(_unit(0), top_k=0)
        with pytest.raises(VectorStoreError):
            await store.search(_unit(0), top_k=-1)

    async def test_search_rejects_wrong_dim_query(
        self, store: SqliteVssStore
    ) -> None:
        with pytest.raises(VectorStoreError):
            await store.search([0.0, 0.1, 0.2], top_k=1)

    async def test_delete_by_project_rejects_empty(
        self, store: SqliteVssStore
    ) -> None:
        with pytest.raises(VectorStoreError):
            await store.delete_by_project("")


class TestSqliteVssSearch:
    @pytest.fixture
    async def store(self, tmp_path: Path) -> Any:
        store = SqliteVssStore(tmp_path / "v.db")
        await store.connect()
        yield store
        await store.close()

    async def test_insert_and_retrieve_by_self_query(
        self, store: SqliteVssStore
    ) -> None:
        vec = _unit(0)
        await store.insert("a", vec, {"label": "alpha"})
        results = await store.search(vec, top_k=1)
        assert len(results) == 1
        assert results[0]["item_id"] == "a"
        assert results[0]["metadata"] == {"label": "alpha"}
        # Identical unit vectors produce cosine score ~ 1.0
        assert results[0]["score"] == pytest.approx(1.0, abs=1e-5)

    async def test_cosine_ranking_orders_by_similarity(
        self, store: SqliteVssStore
    ) -> None:
        # Target axis is dim 0; closer items should rank higher.
        await store.insert("exact", _unit(0), {})
        await store.insert("near", _blend(_unit(0), _unit(1), 0.95), {})
        await store.insert("mid", _blend(_unit(0), _unit(1), 0.5), {})
        await store.insert("far", _unit(1), {})
        await store.insert("opposite", [-x for x in _unit(0)], {})

        results = await store.search(_unit(0), top_k=5)
        order = [r["item_id"] for r in results]
        assert order[0] == "exact"
        assert order[1] == "near"
        assert order[2] == "mid"
        # "far" (orthogonal) and "opposite" are both less similar than "mid".
        assert set(order[3:]) == {"far", "opposite"}
        # Scores are monotonically non-increasing
        scores = [r["score"] for r in results]
        for earlier, later in pairwise(scores):
            assert earlier + 1e-6 >= later

    async def test_score_matches_cosine_similarity(
        self, store: SqliteVssStore
    ) -> None:
        await store.insert("same", _unit(0), {})
        await store.insert("orthogonal", _unit(1), {})
        await store.insert("opposite", [-x for x in _unit(0)], {})

        results = {
            r["item_id"]: r["score"]
            for r in await store.search(_unit(0), top_k=3)
        }
        assert results["same"] == pytest.approx(1.0, abs=1e-5)
        assert results["orthogonal"] == pytest.approx(0.0, abs=1e-5)
        assert results["opposite"] == pytest.approx(-1.0, abs=1e-5)

    async def test_project_isolation_in_search(
        self, store: SqliteVssStore
    ) -> None:
        await store.insert("a", _unit(0), {"project_id": "proj-A"})
        await store.insert("b", _unit(0), {"project_id": "proj-B"})
        await store.insert("c", _unit(1), {"project_id": "proj-A"})

        a_results = await store.search(
            _unit(0), top_k=10, project_id="proj-A"
        )
        assert {r["item_id"] for r in a_results} == {"a", "c"}

        b_results = await store.search(
            _unit(0), top_k=10, project_id="proj-B"
        )
        assert {r["item_id"] for r in b_results} == {"b"}

        # No filter returns items from both projects
        all_results = await store.search(_unit(0), top_k=10)
        assert {r["item_id"] for r in all_results} == {"a", "b", "c"}

    async def test_top_k_caps_results(self, store: SqliteVssStore) -> None:
        for i in range(5):
            await store.insert(f"id-{i}", _unit(i), {})
        results = await store.search(_unit(0), top_k=2)
        assert len(results) == 2
        assert results[0]["item_id"] == "id-0"

    async def test_project_filter_overfetches_to_satisfy_top_k(
        self, store: SqliteVssStore
    ) -> None:
        # Insert many project-B items closer to the query than any project-A
        # item — the inner limit must over-fetch or all matches get dropped.
        for i in range(10):
            await store.insert(f"b-{i}", _unit(i % 5), {"project_id": "B"})
        await store.insert("a-far", _unit(20), {"project_id": "A"})
        await store.insert("a-closer", _unit(0), {"project_id": "A"})

        results = await store.search(_unit(0), top_k=1, project_id="A")
        assert len(results) == 1
        assert results[0]["item_id"] == "a-closer"

    async def test_metadata_round_trips(self, store: SqliteVssStore) -> None:
        meta = {
            "project_id": "proj-1",
            "item_type": "decision",
            "tags": ["auth", "security"],
            "title": "Use Argon2id",
        }
        await store.insert("d-1", _unit(0), meta)
        results = await store.search(_unit(0), top_k=1)
        assert results[0]["metadata"] == meta

    async def test_empty_store_search_returns_empty(
        self, store: SqliteVssStore
    ) -> None:
        assert await store.search(_unit(0), top_k=5) == []

    async def test_non_unit_query_is_normalised(
        self, store: SqliteVssStore
    ) -> None:
        await store.insert("a", _unit(0), {})
        # Query vector with magnitude 10 along dim 0 should behave the same
        # as a unit vector along dim 0 after normalisation.
        query = [0.0] * DEFAULT_DIM
        query[0] = 10.0
        results = await store.search(query, top_k=1)
        assert results[0]["score"] == pytest.approx(1.0, abs=1e-5)


class TestSqliteVssGet:
    @pytest.fixture
    async def store(self, tmp_path: Path) -> Any:
        store = SqliteVssStore(tmp_path / "v.db")
        await store.connect()
        yield store
        await store.close()

    async def test_get_returns_stored_metadata(
        self, store: SqliteVssStore
    ) -> None:
        meta = {"project_id": "p", "item_type": "decision", "tags": ["a"]}
        await store.insert("d-1", _unit(0), meta)
        got = await store.get("d-1")
        assert got == meta

    async def test_get_missing_returns_none(
        self, store: SqliteVssStore
    ) -> None:
        assert await store.get("never-there") is None


class TestSqliteVssDeletion:
    @pytest.fixture
    async def store(self, tmp_path: Path) -> Any:
        store = SqliteVssStore(tmp_path / "v.db")
        await store.connect()
        yield store
        await store.close()

    async def test_delete_removes_vector_and_metadata(
        self, store: SqliteVssStore
    ) -> None:
        await store.insert("a", _unit(0), {"project_id": "p"})
        await store.insert("b", _unit(1), {"project_id": "p"})
        await store.delete("a")
        assert await store.count() == 1
        results = await store.search(_unit(0), top_k=5)
        assert [r["item_id"] for r in results] == ["b"]
        # Can re-insert the same id after deletion.
        await store.insert("a", _unit(0), {"project_id": "p"})
        assert await store.count() == 2

    async def test_delete_missing_item_is_silent(
        self, store: SqliteVssStore
    ) -> None:
        await store.delete("never-existed")

    async def test_delete_by_project_removes_only_matching(
        self, store: SqliteVssStore
    ) -> None:
        await store.insert("a1", _unit(0), {"project_id": "A"})
        await store.insert("a2", _unit(1), {"project_id": "A"})
        await store.insert("b1", _unit(2), {"project_id": "B"})

        await store.delete_by_project("A")

        assert await store.count() == 1
        assert await store.count(project_id="A") == 0
        assert await store.count(project_id="B") == 1
        all_results = await store.search(_unit(2), top_k=10)
        assert {r["item_id"] for r in all_results} == {"b1"}


class TestSqliteVssCount:
    async def test_count_tracks_inserts_and_deletes(
        self, tmp_path: Path
    ) -> None:
        store = SqliteVssStore(tmp_path / "v.db")
        await store.connect()
        try:
            assert await store.count() == 0
            await store.insert("a", _unit(0), {"project_id": "A"})
            await store.insert("b", _unit(1), {"project_id": "B"})
            await store.insert("c", _unit(2), {"project_id": "A"})
            assert await store.count() == 3
            assert await store.count(project_id="A") == 2
            assert await store.count(project_id="B") == 1
            assert await store.count(project_id="missing") == 0
            await store.delete("a")
            assert await store.count() == 2
            assert await store.count(project_id="A") == 1
        finally:
            await store.close()


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


class TestFactory:
    def test_factory_returns_sqlite_store(self, tmp_path: Path) -> None:
        cfg = DatabaseConfig(backend="sqlite", sqlite_path=str(tmp_path / "v.db"))
        store = get_vector_store(cfg)
        assert isinstance(store, SqliteVssStore)

    def test_factory_rejects_unknown_backend(self) -> None:
        cfg = DatabaseConfig(backend="sqlite")
        # Construct an invalid backend by bypassing the frozen dataclass
        # constructor — the factory must still reject it.
        object.__setattr__(cfg, "backend", "mystery")
        with pytest.raises(VectorStoreError):
            get_vector_store(cfg)

    def test_factory_requires_pg_dsn_env(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.delenv("WHYCODE_PG_DSN", raising=False)
        cfg = DatabaseConfig(
            backend="postgresql", pg_dsn_env="WHYCODE_PG_DSN"
        )
        with pytest.raises(VectorStoreError):
            get_vector_store(cfg)

    def test_factory_returns_pg_store_when_env_set(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("WHYCODE_PG_DSN", "postgresql://fake/fake")
        cfg = DatabaseConfig(
            backend="postgresql", pg_dsn_env="WHYCODE_PG_DSN"
        )
        store = get_vector_store(cfg)
        assert isinstance(store, PgVectorStore)


# ---------------------------------------------------------------------------
# PgVectorStore — only runs when a reachable PG with pgvector is configured
# ---------------------------------------------------------------------------


def _pg_dsn() -> str | None:
    return os.environ.get("WHYCODE_PG_TEST_DSN")


async def _pg_is_reachable(dsn: str) -> bool:
    try:
        import asyncpg
    except ImportError:
        return False
    try:
        conn = await asyncpg.connect(dsn)
    except Exception:
        return False
    try:
        try:
            await conn.execute("CREATE EXTENSION IF NOT EXISTS vector")
        except Exception:
            return False
    finally:
        await conn.close()
    return True


_PG_SKIP_REASON = (
    "Set WHYCODE_PG_TEST_DSN to a Postgres DSN with pgvector installed "
    "to run PgVectorStore tests"
)


def _should_skip_pg() -> bool:
    dsn = _pg_dsn()
    if not dsn:
        return True
    try:
        return not asyncio.get_event_loop().run_until_complete(
            _pg_is_reachable(dsn)
        )
    except RuntimeError:
        # If no loop, run in a fresh one
        return not asyncio.run(_pg_is_reachable(dsn))


@pytest.mark.skipif(
    _pg_dsn() is None,
    reason=_PG_SKIP_REASON,
)
class TestPgVectorStore:
    @pytest.fixture
    async def store(self) -> Any:
        dsn = _pg_dsn()
        assert dsn is not None
        store = PgVectorStore(dsn)
        await store.connect()
        # Fresh table state for each test
        import asyncpg

        conn = await asyncpg.connect(dsn)
        try:
            await conn.execute("TRUNCATE TABLE vector_items")
        finally:
            await conn.close()
        yield store
        await store.close()

    async def test_insert_and_search(self, store: PgVectorStore) -> None:
        await store.insert("a", _unit(0), {"project_id": "proj"})
        results = await store.search(_unit(0), top_k=1)
        assert results[0]["item_id"] == "a"
        assert results[0]["score"] == pytest.approx(1.0, abs=1e-5)

    async def test_project_isolation(self, store: PgVectorStore) -> None:
        await store.insert("a", _unit(0), {"project_id": "A"})
        await store.insert("b", _unit(0), {"project_id": "B"})
        results = await store.search(_unit(0), top_k=10, project_id="A")
        assert {r["item_id"] for r in results} == {"a"}

    async def test_delete_and_count(self, store: PgVectorStore) -> None:
        await store.insert("a", _unit(0), {"project_id": "A"})
        await store.insert("b", _unit(1), {"project_id": "A"})
        assert await store.count() == 2
        await store.delete("a")
        assert await store.count() == 1

    async def test_delete_by_project(self, store: PgVectorStore) -> None:
        await store.insert("a", _unit(0), {"project_id": "A"})
        await store.insert("b", _unit(1), {"project_id": "B"})
        await store.delete_by_project("A")
        assert await store.count() == 1
        assert await store.count(project_id="A") == 0


# ---------------------------------------------------------------------------
# Cosine math sanity check — guards against regressions in normalisation
# ---------------------------------------------------------------------------


class TestNormalisationMath:
    async def test_midpoint_score_matches_cosine_formula(
        self, tmp_path: Path
    ) -> None:
        store = SqliteVssStore(tmp_path / "v.db")
        await store.connect()
        try:
            # Insert a vector at 45 degrees from _unit(0) in the dim-0/dim-1
            # plane. Cosine similarity should be cos(45) = 1/sqrt(2).
            vec = [0.0] * DEFAULT_DIM
            vec[0] = 1.0
            vec[1] = 1.0
            await store.insert("diag", vec, {})
            results = await store.search(_unit(0), top_k=1)
            expected = 1.0 / math.sqrt(2.0)
            assert results[0]["score"] == pytest.approx(expected, abs=1e-5)
        finally:
            await store.close()
