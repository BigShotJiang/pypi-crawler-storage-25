"""Tests for backend.cli — CLI commands.

Exercises init, connect, token set/revoke, and config set-credential using
click's CliRunner. The interactive/blocking commands (serve, login) are
stubbed via mocks where tested.
"""

from __future__ import annotations

import json
import os
import stat
import subprocess
import sys
from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from backend.cli import (
    MCP_CLIENT_CONFIGS,
    cli,
    detect_mcp_client_configs,
    write_mcp_client_config,
)

if TYPE_CHECKING:
    from pathlib import Path


def _init_git(path: Path) -> None:
    subprocess.run(
        ["git", "init", "-q", "-b", "main", str(path)],
        check=True,
        capture_output=True,
    )


# ---------------------------------------------------------------------------
# init
# ---------------------------------------------------------------------------


class TestInit:
    """`whycode init` creates config, vault dir, and git hooks."""

    def test_init_solo_mode(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _init_git(tmp_path)
        monkeypatch.setenv("WHYCODE_VAULT_PASSPHRASE", "test-pass")
        monkeypatch.setenv("HOME", str(tmp_path / "home"))
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr(
            "backend.cli.DEFAULT_VAULT_DIR", tmp_path / "home" / ".whycode"
        )
        monkeypatch.setattr(
            "backend.cli.HOOK_TOKEN_FILE",
            tmp_path / "home" / ".whycode" / "hook_token",
        )

        runner = CliRunner()
        result = runner.invoke(
            cli,
            ["init", "--mode", "solo", "--vault-backend", "file"],
        )
        assert result.exit_code == 0, result.output

        assert (tmp_path / "whycode.toml").exists()
        assert (tmp_path / "data").is_dir()
        assert (tmp_path / ".git" / "hooks" / "post-commit").exists()
        assert (tmp_path / "home" / ".whycode" / "hook_token").exists()

    def test_init_refuses_overwrite(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _init_git(tmp_path)
        monkeypatch.chdir(tmp_path)
        (tmp_path / "whycode.toml").write_text("existing")

        runner = CliRunner()
        result = runner.invoke(cli, ["init"])
        assert result.exit_code != 0
        assert "Refusing to overwrite" in result.output

    @pytest.mark.skipif(sys.platform == "win32", reason="POSIX perms only")
    def test_init_writes_secure_perms(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _init_git(tmp_path)
        monkeypatch.setenv("WHYCODE_VAULT_PASSPHRASE", "test-pass")
        monkeypatch.setenv("HOME", str(tmp_path / "home"))
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr(
            "backend.cli.DEFAULT_VAULT_DIR", tmp_path / "home" / ".whycode"
        )
        monkeypatch.setattr(
            "backend.cli.HOOK_TOKEN_FILE",
            tmp_path / "home" / ".whycode" / "hook_token",
        )

        runner = CliRunner()
        runner.invoke(
            cli, ["init", "--mode", "solo", "--vault-backend", "file"]
        )

        config_mode = (tmp_path / "whycode.toml").stat().st_mode
        assert config_mode & stat.S_IROTH == 0, "config is world-readable"

        token_mode = (
            tmp_path / "home" / ".whycode" / "hook_token"
        ).stat().st_mode
        assert token_mode & stat.S_IROTH == 0, "token file is world-readable"

    def test_init_team_mode_no_solo_token(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _init_git(tmp_path)
        monkeypatch.setenv("HOME", str(tmp_path / "home"))
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr(
            "backend.cli.DEFAULT_VAULT_DIR", tmp_path / "home" / ".whycode"
        )
        monkeypatch.setattr(
            "backend.cli.HOOK_TOKEN_FILE",
            tmp_path / "home" / ".whycode" / "hook_token",
        )

        runner = CliRunner()
        result = runner.invoke(
            cli, ["init", "--mode", "team", "--vault-backend", "keyring"]
        )
        assert result.exit_code == 0
        # In team mode, the hook_token file is not created (no solo token).
        assert not (
            tmp_path / "home" / ".whycode" / "hook_token"
        ).exists()


# ---------------------------------------------------------------------------
# token set / revoke
# ---------------------------------------------------------------------------


class TestToken:
    """token set/revoke write and remove PATs from the vault."""

    def test_token_set(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("WHYCODE_VAULT_PASSPHRASE", "test")

        with patch("backend.cli._load_credential_manager_for_cli") as mock:
            creds = MagicMock()
            mock.return_value = creds
            runner = CliRunner()
            result = runner.invoke(cli, ["token", "set", "cl_pat_abc123"])

        assert result.exit_code == 0
        creds.set.assert_called_once_with("whycode", "pat", "cl_pat_abc123")

    def test_token_revoke(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("WHYCODE_VAULT_PASSPHRASE", "test")

        with patch("backend.cli._load_credential_manager_for_cli") as mock:
            creds = MagicMock()
            mock.return_value = creds
            runner = CliRunner()
            result = runner.invoke(cli, ["token", "revoke"])

        assert result.exit_code == 0
        creds.delete.assert_called_once_with("whycode", "pat")

    def test_token_revoke_failure(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("WHYCODE_VAULT_PASSPHRASE", "test")

        with patch("backend.cli._load_credential_manager_for_cli") as mock:
            creds = MagicMock()
            creds.delete.side_effect = RuntimeError("not found")
            mock.return_value = creds
            runner = CliRunner()
            result = runner.invoke(cli, ["token", "revoke"])

        assert result.exit_code != 0


# ---------------------------------------------------------------------------
# connect: write_mcp_client_config
# ---------------------------------------------------------------------------


class TestMcpClientConfig:
    """write_mcp_client_config preserves existing MCP server entries."""

    def test_writes_new_config(self, tmp_path: Path) -> None:
        path = tmp_path / "client.json"
        write_mcp_client_config(
            path, "http://127.0.0.1:8100", "cl_pat_token"
        )

        data = json.loads(path.read_text())
        assert "whycode" in data["mcpServers"]
        entry = data["mcpServers"]["whycode"]
        assert entry["url"] == "http://127.0.0.1:8100/mcp"
        assert entry["headers"]["Authorization"] == "Bearer cl_pat_token"

    def test_preserves_existing_entries(self, tmp_path: Path) -> None:
        path = tmp_path / "client.json"
        path.write_text(
            json.dumps(
                {
                    "mcpServers": {
                        "existing-server": {"url": "http://other:9000/mcp"}
                    }
                }
            )
        )
        write_mcp_client_config(path, "http://127.0.0.1:8100", "t")
        data = json.loads(path.read_text())
        assert "existing-server" in data["mcpServers"]
        assert "whycode" in data["mcpServers"]

    def test_rejects_invalid_json(self, tmp_path: Path) -> None:
        path = tmp_path / "client.json"
        path.write_text("this is not { valid json")
        with pytest.raises(RuntimeError, match="Invalid existing JSON"):
            write_mcp_client_config(path, "http://x", "t")

    def test_rejects_non_object_root(self, tmp_path: Path) -> None:
        path = tmp_path / "client.json"
        path.write_text("[]")
        with pytest.raises(RuntimeError, match="not a JSON object"):
            write_mcp_client_config(path, "http://x", "t")

    @pytest.mark.skipif(sys.platform == "win32", reason="POSIX perms only")
    def test_written_file_is_owner_only(self, tmp_path: Path) -> None:
        path = tmp_path / "client.json"
        write_mcp_client_config(path, "http://x", "t")
        mode = path.stat().st_mode
        assert mode & stat.S_IROTH == 0


# ---------------------------------------------------------------------------
# connect command
# ---------------------------------------------------------------------------


class TestConnect:
    """`whycode connect` writes to MCP client configs."""

    def test_connect_explicit_paths(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("WHYCODE_VAULT_PASSPHRASE", "test")
        client_config = tmp_path / "cursor.json"

        with patch("backend.cli._load_credential_manager_for_cli") as mock:
            creds = MagicMock()
            creds.get.return_value = "cl_solo_token"
            mock.return_value = creds

            runner = CliRunner()
            result = runner.invoke(
                cli,
                [
                    "connect",
                    "--server",
                    "http://127.0.0.1:8100",
                    "--config-paths",
                    str(client_config),
                ],
            )

        assert result.exit_code == 0, result.output
        data = json.loads(client_config.read_text())
        assert data["mcpServers"]["whycode"]["url"] == "http://127.0.0.1:8100/mcp"

    def test_connect_fails_without_token(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("WHYCODE_VAULT_PASSPHRASE", "test")

        with patch("backend.cli._load_credential_manager_for_cli") as mock:
            creds = MagicMock()
            creds.get.return_value = None
            mock.return_value = creds

            runner = CliRunner()
            result = runner.invoke(
                cli,
                ["connect", "--config-paths", str(tmp_path / "x.json")],
            )

        assert result.exit_code != 0
        assert "No token found" in result.output

    def test_detect_mcp_client_configs_returns_list(self) -> None:
        result = detect_mcp_client_configs()
        assert isinstance(result, list)
        for path in result:
            assert path in MCP_CLIENT_CONFIGS.values()


# ---------------------------------------------------------------------------
# install-service
# ---------------------------------------------------------------------------


class TestInstallService:
    """`whycode install-service` prints a systemd unit template."""

    def test_prints_unit(self) -> None:
        runner = CliRunner()
        result = runner.invoke(cli, ["install-service"])
        assert result.exit_code == 0
        assert "[Unit]" in result.output
        assert "ExecStart=whycode serve" in result.output


# ---------------------------------------------------------------------------
# config set-credential
# ---------------------------------------------------------------------------


class TestConfigSetCredential:
    """`whycode config set-credential` stores into the vault."""

    def test_sets_credential(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("WHYCODE_VAULT_PASSPHRASE", "test")

        with patch("backend.cli._load_credential_manager_for_cli") as mock:
            creds = MagicMock()
            mock.return_value = creds
            runner = CliRunner()
            result = runner.invoke(
                cli,
                ["config", "set-credential", "github_client_id", "abc123"],
            )

        assert result.exit_code == 0
        creds.set.assert_called_once_with(
            "whycode", "github_client_id", "abc123"
        )


# ---------------------------------------------------------------------------
# mcp stdio command
# ---------------------------------------------------------------------------


class TestMcpStdio:
    """`whycode mcp` requires a token."""

    def test_mcp_without_token_fails(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        # Ensure no WHYCODE_TOKEN is set
        monkeypatch.delenv("WHYCODE_TOKEN", raising=False)
        runner = CliRunner()
        result = runner.invoke(cli, ["mcp"])
        assert result.exit_code != 0
        assert "Missing token" in result.output

    def test_mcp_with_token_runs(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        runner = CliRunner()
        result = runner.invoke(
            cli, ["mcp", "--token", "cl_pat_abc123"]
        )
        assert result.exit_code == 0
        # Output may be captured on stdout or stderr depending on click version;
        # the important thing is the command ran to completion without error.


# ---------------------------------------------------------------------------
# Smoke: `--help` on every subcommand
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "command",
    [
        [],
        ["init"],
        ["serve"],
        ["token"],
        ["token", "set"],
        ["token", "revoke"],
        ["token", "generate"],
        ["connect"],
        ["login"],
        ["config"],
        ["config", "set-credential"],
        ["mcp"],
        ["install-service"],
    ],
)
def test_help_is_available(command: list[str]) -> None:
    runner = CliRunner()
    result = runner.invoke(cli, [*command, "--help"])
    assert result.exit_code == 0
    assert "Usage" in result.output or "Commands" in result.output


def test_env_home_isolation() -> None:
    """Sanity: tests run without clobbering the real ~/.whycode."""
    assert os.environ.get("HOME") is not None


# ---------------------------------------------------------------------------
# Claude Code hooks writer (Phase 3 active context injection)
# ---------------------------------------------------------------------------


class TestClaudeCodeHooksWriter:
    """``connect`` writes hooks into Claude Code's settings.json."""

    def test_fresh_write_installs_all_three_hook_events(
        self, tmp_path: pytest.TempPathFactory
    ) -> None:
        from backend.cli import write_claude_code_settings

        target = tmp_path / ".claude" / "settings.json"
        write_claude_code_settings(
            target, server_url="http://127.0.0.1:8100", token="cl_solo_x"
        )
        settings = json.loads(target.read_text(encoding="utf-8"))
        assert "whycode" in settings["mcpServers"]
        assert settings["mcpServers"]["whycode"]["url"].endswith("/mcp")
        hooks = settings["hooks"]
        assert {"UserPromptSubmit", "PreToolUse", "Stop"} <= set(hooks)
        # Every hook command carries the bearer token.
        user_cmd = hooks["UserPromptSubmit"][0]["hooks"][0]["command"]
        assert "Bearer cl_solo_x" in user_cmd
        assert "session-context" in user_cmd

    def test_merge_preserves_unrelated_hooks_and_servers(
        self, tmp_path: pytest.TempPathFactory
    ) -> None:
        from backend.cli import write_claude_code_settings

        target = tmp_path / ".claude" / "settings.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(
            json.dumps(
                {
                    "mcpServers": {"other-server": {"url": "x"}},
                    "hooks": {
                        "PostToolUse": [
                            {"hooks": [{"type": "command", "command": "echo hi"}]}
                        ]
                    },
                    "someOtherKey": "preserved",
                }
            ),
            encoding="utf-8",
        )
        write_claude_code_settings(
            target, server_url="http://127.0.0.1:8100", token="cl_solo_y"
        )
        settings = json.loads(target.read_text(encoding="utf-8"))
        # Unrelated MCP server preserved.
        assert "other-server" in settings["mcpServers"]
        # Unrelated hook event preserved.
        assert "PostToolUse" in settings["hooks"]
        # Unrelated top-level keys preserved.
        assert settings["someOtherKey"] == "preserved"
        # Our hooks landed.
        assert "UserPromptSubmit" in settings["hooks"]

    def test_hooks_matcher_on_pretooluse(
        self, tmp_path: pytest.TempPathFactory
    ) -> None:
        from backend.cli import write_claude_code_settings

        target = tmp_path / ".claude" / "settings.json"
        write_claude_code_settings(target, "http://x", "tok")
        settings = json.loads(target.read_text(encoding="utf-8"))
        pretool = settings["hooks"]["PreToolUse"][0]
        assert "matcher" in pretool
        assert "Edit" in pretool["matcher"]


# ---------------------------------------------------------------------------
# Custom port propagation (Part 2)
# ---------------------------------------------------------------------------


class TestCustomPort:
    """``--port N`` propagates through init, connect, and config reads."""

    def test_init_writes_port_into_toml(
        self, tmp_path: pytest.TempPathFactory, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from backend.cli import cli

        monkeypatch.setenv("WHYCODE_VAULT_PASSPHRASE", "test")
        monkeypatch.setattr(
            "backend.cli.DEFAULT_VAULT_DIR", tmp_path / ".whycode"
        )
        monkeypatch.setattr(
            "backend.cli.HOOK_TOKEN_FILE",
            tmp_path / ".whycode" / "hook_token",
        )
        runner = CliRunner()
        result = runner.invoke(
            cli,
            [
                "init",
                "--port",
                "9000",
                "--project-root",
                str(tmp_path),
                "--no-install-hooks",
            ],
        )
        assert result.exit_code == 0, result.output
        body = (tmp_path / "whycode.toml").read_text(encoding="utf-8")
        assert "port = 9000" in body

    def test_resolve_serve_bindings_reads_from_toml(
        self, tmp_path: pytest.TempPathFactory, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from backend.cli import _resolve_serve_bindings

        (tmp_path / "whycode.toml").write_text(
            "[server]\n"
            'mode = "solo"\n'
            'host = "127.0.0.1"\n'
            "port = 7777\n"
            'log_level = "info"\n',
            encoding="utf-8",
        )
        if sys.platform != "win32":
            (tmp_path / "whycode.toml").chmod(0o600)
        monkeypatch.chdir(tmp_path)
        host, port, mode = _resolve_serve_bindings()
        assert host == "127.0.0.1"
        assert port == 7777
        assert mode == "solo"

    def test_save_port_rewrites_toml(
        self, tmp_path: pytest.TempPathFactory, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from backend.cli import _save_port_to_toml

        target = tmp_path / "whycode.toml"
        target.write_text(
            "[server]\n"
            'mode = "solo"\n'
            "port = 8100\n",
            encoding="utf-8",
        )
        monkeypatch.chdir(tmp_path)
        _save_port_to_toml(9900)
        assert "port = 9900" in target.read_text(encoding="utf-8")


class TestPortPropagationThroughConnect:
    def test_connect_uses_config_port(
        self, tmp_path: pytest.TempPathFactory, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from backend.cli import write_claude_code_settings

        # Simulate a config that says port 7777 — the writer should embed
        # http://127.0.0.1:7777 in the hooks curl commands.
        target_settings = tmp_path / ".claude" / "settings.json"
        write_claude_code_settings(
            target_settings,
            server_url="http://127.0.0.1:7777",
            token="cl_solo_token",
        )
        body = target_settings.read_text(encoding="utf-8")
        assert "http://127.0.0.1:7777" in body
        assert "/api/hooks/session-context" in body
