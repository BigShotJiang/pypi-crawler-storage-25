"""Unit tests for backend.utils.instruction_file_manager.

Covers the three-way behavior (create / append / update / unchanged) for
both the CLAUDE.md pathway (which delegates to the existing project
CLAUDE.md generator) and the non-CLAUDE.md pathway (``.cursorrules``,
``.windsurfrules``, ``.clinerules``).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from backend.utils.instruction_file_manager import (
    WHYCODE_SECTION_END,
    WHYCODE_SECTION_START,
    build_claude_desktop_guide,
    instruction_filename,
    sync_all_instruction_files,
    sync_instruction_file,
)

if TYPE_CHECKING:
    from pathlib import Path


_BASE_KW: dict[str, str] = {
    "project_id": "proj_test",
    "project_name": "test-project",
    "server_url": "http://127.0.0.1:8100",
    "mode": "solo",
    "change_detection_backend": "git",
}


# ---------------------------------------------------------------------------
# CLAUDE.md (delegates to write_project_claude_md — delimiter-based scheme)
# ---------------------------------------------------------------------------


def test_creates_claude_md_when_missing(tmp_path: Path) -> None:
    result = sync_instruction_file(tmp_path, client="claude-code", **_BASE_KW)
    assert result["action"] == "created"
    assert result["existed_before"] is False
    assert result["client"] == "claude-code"
    content = (tmp_path / "CLAUDE.md").read_text(encoding="utf-8")
    assert "WhyCode is active" in content
    assert "decision.create" in content
    assert "## Project-Specific Instructions" in content


def test_unchanged_when_claude_md_current(tmp_path: Path) -> None:
    sync_instruction_file(tmp_path, client="claude-code", **_BASE_KW)
    result = sync_instruction_file(tmp_path, client="claude-code", **_BASE_KW)
    assert result["action"] == "unchanged"
    assert result["existed_before"] is True


def test_preserves_user_section_below_delimiter(tmp_path: Path) -> None:
    claude_md = tmp_path / "CLAUDE.md"
    user_body = (
        "# Managed\n\n"
        "## Project-Specific Instructions\n\n"
        "IMPORTANT USER CONTENT — must survive reinit.\n"
    )
    claude_md.write_text(user_body, encoding="utf-8")
    sync_instruction_file(tmp_path, client="claude-code", **_BASE_KW)
    after = claude_md.read_text(encoding="utf-8")
    assert "IMPORTANT USER CONTENT — must survive reinit." in after


def test_claude_md_without_delimiter_is_preserved(tmp_path: Path) -> None:
    claude_md = tmp_path / "CLAUDE.md"
    user_body = "# My project\n\nExisting content.\n"
    claude_md.write_text(user_body, encoding="utf-8")
    result = sync_instruction_file(tmp_path, client="claude-code", **_BASE_KW)
    after = claude_md.read_text(encoding="utf-8")
    assert result["action"] == "updated"
    assert "Existing content." in after
    assert "## Project-Specific Instructions" in after


# ---------------------------------------------------------------------------
# .cursorrules / .windsurfrules / .clinerules (HTML-marker scheme)
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("client", "filename"),
    [
        ("cursor", ".cursorrules"),
        ("windsurf", ".windsurfrules"),
        ("cline", ".clinerules"),
    ],
)
def test_creates_non_claude_file_when_missing(
    tmp_path: Path, client: str, filename: str
) -> None:
    result = sync_instruction_file(
        tmp_path,
        client=client,  # type: ignore[arg-type]
        **_BASE_KW,
    )
    assert result["action"] == "created"
    assert result["existed_before"] is False
    content = (tmp_path / filename).read_text(encoding="utf-8")
    assert WHYCODE_SECTION_START in content
    assert WHYCODE_SECTION_END in content
    assert "context.before_edit" in content
    assert "decision.create" in content
    assert "session.end" in content
    assert "proj_test" in content
    assert "http://127.0.0.1:8100" in content


def test_appends_to_existing_non_claude_file(tmp_path: Path) -> None:
    path = tmp_path / ".cursorrules"
    path.write_text("# My existing rules\n\nExisting content here.\n", encoding="utf-8")
    result = sync_instruction_file(tmp_path, client="cursor", **_BASE_KW)
    assert result["action"] == "appended"
    assert result["existed_before"] is True
    content = path.read_text(encoding="utf-8")
    assert "Existing content here." in content
    assert WHYCODE_SECTION_START in content
    assert WHYCODE_SECTION_END in content


def test_updates_existing_whycode_section_in_place(tmp_path: Path) -> None:
    path = tmp_path / ".cursorrules"
    old = (
        "# User rules\n\n"
        f"{WHYCODE_SECTION_START}\nOLD STALE CONTENT\n{WHYCODE_SECTION_END}\n"
        "# Footer rules\n"
    )
    path.write_text(old, encoding="utf-8")
    result = sync_instruction_file(tmp_path, client="cursor", **_BASE_KW)
    content = path.read_text(encoding="utf-8")
    assert result["action"] == "updated"
    assert "OLD STALE CONTENT" not in content
    assert "# User rules" in content
    assert "# Footer rules" in content
    assert "context.before_edit" in content
    assert content.count(WHYCODE_SECTION_START) == 1
    assert content.count(WHYCODE_SECTION_END) == 1


def test_unchanged_when_non_claude_section_current(tmp_path: Path) -> None:
    sync_instruction_file(tmp_path, client="cursor", **_BASE_KW)
    result = sync_instruction_file(tmp_path, client="cursor", **_BASE_KW)
    assert result["action"] == "unchanged"
    assert result["existed_before"] is True


def test_never_destroys_existing_non_claude_content(tmp_path: Path) -> None:
    path = tmp_path / ".cursorrules"
    original = "# My project rules\n\nLine one must survive.\n\nLine two must survive.\n"
    path.write_text(original, encoding="utf-8")
    sync_instruction_file(tmp_path, client="cursor", **_BASE_KW)
    content = path.read_text(encoding="utf-8")
    assert "Line one must survive." in content
    assert "Line two must survive." in content


# ---------------------------------------------------------------------------
# sync_all_instruction_files orchestration
# ---------------------------------------------------------------------------


def test_sync_all_creates_every_file(tmp_path: Path) -> None:
    results = sync_all_instruction_files(
        project_root=tmp_path,
        project_id=_BASE_KW["project_id"],
        project_name=_BASE_KW["project_name"],
        server_url=_BASE_KW["server_url"],
        mode=_BASE_KW["mode"],
        change_detection_backend=_BASE_KW["change_detection_backend"],
    )
    clients = {r["client"] for r in results}
    assert clients == {"claude-code", "cursor", "windsurf", "cline"}
    for r in results:
        assert r["action"] == "created"
    assert (tmp_path / "CLAUDE.md").exists()
    assert (tmp_path / ".cursorrules").exists()
    assert (tmp_path / ".windsurfrules").exists()
    assert (tmp_path / ".clinerules").exists()


def test_sync_all_narrowed_clients(tmp_path: Path) -> None:
    results = sync_all_instruction_files(
        project_root=tmp_path,
        project_id=_BASE_KW["project_id"],
        project_name=_BASE_KW["project_name"],
        server_url=_BASE_KW["server_url"],
        mode=_BASE_KW["mode"],
        change_detection_backend=_BASE_KW["change_detection_backend"],
        clients=("cursor", "windsurf"),
    )
    assert [r["client"] for r in results] == ["cursor", "windsurf"]
    assert not (tmp_path / "CLAUDE.md").exists()
    assert not (tmp_path / ".clinerules").exists()
    assert (tmp_path / ".cursorrules").exists()
    assert (tmp_path / ".windsurfrules").exists()


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


def test_rejects_unsupported_client(tmp_path: Path) -> None:
    with pytest.raises(ValueError):
        sync_instruction_file(tmp_path, client="bogus", **_BASE_KW)  # type: ignore[arg-type]


def test_rejects_missing_project_root(tmp_path: Path) -> None:
    missing = tmp_path / "nope"
    with pytest.raises(OSError):
        sync_instruction_file(missing, client="cursor", **_BASE_KW)


def test_rejects_non_directory_project_root(tmp_path: Path) -> None:
    f = tmp_path / "file.txt"
    f.write_text("x", encoding="utf-8")
    with pytest.raises(OSError):
        sync_instruction_file(f, client="cursor", **_BASE_KW)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def test_instruction_filename_returns_expected() -> None:
    assert instruction_filename("claude-code") == "CLAUDE.md"
    assert instruction_filename("cursor") == ".cursorrules"
    assert instruction_filename("windsurf") == ".windsurfrules"
    assert instruction_filename("cline") == ".clinerules"


def test_claude_desktop_guide_mentions_tools_and_project() -> None:
    guide = build_claude_desktop_guide(
        project_id="proj_test",
        project_name="test-project",
        server_url="http://127.0.0.1:8100",
    )
    assert "proj_test" in guide
    assert "http://127.0.0.1:8100/mcp" in guide
    assert "context.before_edit" in guide
    assert "decision.create" in guide
    assert "provenance.reverse" in guide
    assert "drift.check" in guide
