"""Tests for backend.db.db_backend — database backend abstraction.

Covers: connection lifecycle, CRUD operations (insert, get_by_id, query, update,
delete, execute_raw), table whitelist enforcement, migration idempotency, and
round-trip persistence of Model objects. Runs against SQLite; PostgreSQL tests
are skipped unless ``WHYCODE_PG_DSN`` is set.
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

import pytest

from backend.db.db_backend import (
    ALLOWED_TABLES,
    DatabaseError,
    PostgreSQLBackend,
    SQLiteBackend,
)
from backend.db.migrations import apply_migrations
from backend.models import Decision, Sprint, Story, User

if TYPE_CHECKING:
    from pathlib import Path


# ---------------------------------------------------------------------------
# SQLite fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
async def sqlite_backend(tmp_path: Path) -> SQLiteBackend:
    backend = SQLiteBackend(tmp_path / "test.db")
    await backend.connect()
    await apply_migrations(backend)
    yield backend
    await backend.close()


# ---------------------------------------------------------------------------
# Connection lifecycle
# ---------------------------------------------------------------------------


class TestConnection:
    """Connect / close behavior and usage before connect."""

    @pytest.mark.asyncio
    async def test_connect_creates_db_file(self, tmp_path: Path) -> None:
        db_path = tmp_path / "fresh.db"
        backend = SQLiteBackend(db_path)
        await backend.connect()
        try:
            assert db_path.exists()
        finally:
            await backend.close()

    @pytest.mark.asyncio
    async def test_wal_mode_enabled(self, tmp_path: Path) -> None:
        backend = SQLiteBackend(tmp_path / "wal.db")
        await backend.connect()
        try:
            rows = await backend.execute_raw("PRAGMA journal_mode")
            assert rows[0]["journal_mode"].lower() == "wal"
        finally:
            await backend.close()

    @pytest.mark.asyncio
    async def test_operation_before_connect_raises(self, tmp_path: Path) -> None:
        backend = SQLiteBackend(tmp_path / "x.db")
        with pytest.raises(DatabaseError, match="not connected"):
            await backend.insert("users", {"id": "x"})


# ---------------------------------------------------------------------------
# Table whitelist (SEC-01)
# ---------------------------------------------------------------------------


class TestTableWhitelist:
    """Unknown table names are rejected before query assembly."""

    @pytest.mark.asyncio
    async def test_unknown_table_insert_rejected(
        self, sqlite_backend: SQLiteBackend
    ) -> None:
        with pytest.raises(DatabaseError, match="Unknown or disallowed"):
            await sqlite_backend.insert("evil_table", {"id": "x"})

    @pytest.mark.asyncio
    async def test_unknown_table_get_rejected(
        self, sqlite_backend: SQLiteBackend
    ) -> None:
        with pytest.raises(DatabaseError, match="Unknown or disallowed"):
            await sqlite_backend.get_by_id("evil_table", "x")

    @pytest.mark.asyncio
    async def test_unknown_table_query_rejected(
        self, sqlite_backend: SQLiteBackend
    ) -> None:
        with pytest.raises(DatabaseError, match="Unknown or disallowed"):
            await sqlite_backend.query("evil_table")

    @pytest.mark.asyncio
    async def test_unknown_table_update_rejected(
        self, sqlite_backend: SQLiteBackend
    ) -> None:
        with pytest.raises(DatabaseError, match="Unknown or disallowed"):
            await sqlite_backend.update("evil_table", "x", {"name": "y"})

    @pytest.mark.asyncio
    async def test_unknown_table_delete_rejected(
        self, sqlite_backend: SQLiteBackend
    ) -> None:
        with pytest.raises(DatabaseError, match="Unknown or disallowed"):
            await sqlite_backend.delete("evil_table", "x")

    @pytest.mark.asyncio
    async def test_malicious_column_rejected(
        self, sqlite_backend: SQLiteBackend
    ) -> None:
        with pytest.raises(DatabaseError, match="Invalid column name"):
            await sqlite_backend.insert("users", {"id; DROP TABLE users;--": "x"})


# ---------------------------------------------------------------------------
# CRUD operations
# ---------------------------------------------------------------------------


class TestCrudOperations:
    """Insert, read, update, and delete round-trip."""

    @pytest.mark.asyncio
    async def test_insert_and_get(self, sqlite_backend: SQLiteBackend) -> None:
        user = User(email="alice@example.com", name="Alice", provider="google")
        await sqlite_backend.insert("users", user.to_dict())
        got = await sqlite_backend.get_by_id("users", str(user.id))
        assert got is not None
        assert got["email"] == "alice@example.com"
        assert got["name"] == "Alice"

    @pytest.mark.asyncio
    async def test_get_missing_returns_none(
        self, sqlite_backend: SQLiteBackend
    ) -> None:
        assert await sqlite_backend.get_by_id("users", "nonexistent") is None

    @pytest.mark.asyncio
    async def test_query_with_where(self, sqlite_backend: SQLiteBackend) -> None:
        a = Decision(title="A", status="passed")
        b = Decision(title="B", status="failed")
        c = Decision(title="C", status="passed")
        for d in (a, b, c):
            await sqlite_backend.insert("decisions", d.to_dict())

        rows = await sqlite_backend.query("decisions", {"status": "passed"})
        assert len(rows) == 2
        titles = {r["title"] for r in rows}
        assert titles == {"A", "C"}

    @pytest.mark.asyncio
    async def test_query_no_filter_returns_all(
        self, sqlite_backend: SQLiteBackend
    ) -> None:
        for i in range(5):
            await sqlite_backend.insert(
                "decisions", Decision(title=f"T{i}").to_dict()
            )
        rows = await sqlite_backend.query("decisions")
        assert len(rows) == 5

    @pytest.mark.asyncio
    async def test_query_with_limit(self, sqlite_backend: SQLiteBackend) -> None:
        for i in range(10):
            await sqlite_backend.insert(
                "decisions", Decision(title=f"T{i}").to_dict()
            )
        rows = await sqlite_backend.query("decisions", limit=3)
        assert len(rows) == 3

    @pytest.mark.asyncio
    async def test_query_with_order_by(
        self, sqlite_backend: SQLiteBackend
    ) -> None:
        await sqlite_backend.insert(
            "decisions", Decision(title="B").to_dict()
        )
        await sqlite_backend.insert(
            "decisions", Decision(title="A").to_dict()
        )
        await sqlite_backend.insert(
            "decisions", Decision(title="C").to_dict()
        )
        rows = await sqlite_backend.query("decisions", order_by="title ASC")
        assert [r["title"] for r in rows] == ["A", "B", "C"]

    @pytest.mark.asyncio
    async def test_update(self, sqlite_backend: SQLiteBackend) -> None:
        story = Story(title="Original", points=3)
        await sqlite_backend.insert("stories", story.to_dict())
        await sqlite_backend.update(
            "stories", str(story.id), {"title": "Updated", "points": 5}
        )
        got = await sqlite_backend.get_by_id("stories", str(story.id))
        assert got is not None
        assert got["title"] == "Updated"
        assert got["points"] == 5

    @pytest.mark.asyncio
    async def test_update_empty_data_is_noop(
        self, sqlite_backend: SQLiteBackend
    ) -> None:
        story = Story(title="Original")
        await sqlite_backend.insert("stories", story.to_dict())
        await sqlite_backend.update("stories", str(story.id), {})
        got = await sqlite_backend.get_by_id("stories", str(story.id))
        assert got is not None
        assert got["title"] == "Original"

    @pytest.mark.asyncio
    async def test_delete(self, sqlite_backend: SQLiteBackend) -> None:
        sprint = Sprint(name="Sprint 1")
        await sqlite_backend.insert("sprints", sprint.to_dict())
        assert await sqlite_backend.get_by_id("sprints", str(sprint.id)) is not None

        await sqlite_backend.delete("sprints", str(sprint.id))
        assert await sqlite_backend.get_by_id("sprints", str(sprint.id)) is None

    @pytest.mark.asyncio
    async def test_delete_missing_no_error(
        self, sqlite_backend: SQLiteBackend
    ) -> None:
        await sqlite_backend.delete("sprints", "nonexistent-id")

    @pytest.mark.asyncio
    async def test_insert_empty_data_raises(
        self, sqlite_backend: SQLiteBackend
    ) -> None:
        with pytest.raises(DatabaseError, match="empty row"):
            await sqlite_backend.insert("users", {})


# ---------------------------------------------------------------------------
# Model round-trip
# ---------------------------------------------------------------------------


class TestModelRoundTrip:
    """Domain models round-trip through insert and get_by_id cleanly."""

    @pytest.mark.asyncio
    async def test_decision_round_trip(
        self, sqlite_backend: SQLiteBackend
    ) -> None:
        original = Decision(
            title="Use PostgreSQL",
            description="For scalability",
            tags=["database", "infra"],
            status="passed",
        )
        await sqlite_backend.insert("decisions", original.to_dict())
        row = await sqlite_backend.get_by_id("decisions", str(original.id))
        assert row is not None
        restored = Decision.from_dict(row)
        assert restored == original

    @pytest.mark.asyncio
    async def test_unique_email_enforced(
        self, sqlite_backend: SQLiteBackend
    ) -> None:
        await sqlite_backend.insert(
            "users", User(email="dup@example.com").to_dict()
        )
        with pytest.raises(DatabaseError):
            await sqlite_backend.insert(
                "users", User(email="dup@example.com").to_dict()
            )


# ---------------------------------------------------------------------------
# Raw SQL
# ---------------------------------------------------------------------------


class TestExecuteRaw:
    """execute_raw supports parameterized queries."""

    @pytest.mark.asyncio
    async def test_raw_select(self, sqlite_backend: SQLiteBackend) -> None:
        await sqlite_backend.insert(
            "decisions", Decision(title="Hello").to_dict()
        )
        rows = await sqlite_backend.execute_raw(
            "SELECT title FROM decisions WHERE title = ?", ("Hello",)
        )
        assert rows == [{"title": "Hello"}]

    @pytest.mark.asyncio
    async def test_raw_dml_returns_empty(
        self, sqlite_backend: SQLiteBackend
    ) -> None:
        rows = await sqlite_backend.execute_raw(
            "UPDATE decisions SET title = ? WHERE title = ?",
            ("new", "nonexistent"),
        )
        assert rows == []


# ---------------------------------------------------------------------------
# Migrations
# ---------------------------------------------------------------------------


class TestMigrations:
    """Migrations are idempotent and create all expected tables."""

    @pytest.mark.asyncio
    async def test_migrations_idempotent(self, tmp_path: Path) -> None:
        backend = SQLiteBackend(tmp_path / "mig.db")
        await backend.connect()
        try:
            applied_first = await apply_migrations(backend)
            assert applied_first == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]

            applied_second = await apply_migrations(backend)
            assert applied_second == []
        finally:
            await backend.close()

    @pytest.mark.asyncio
    async def test_all_tables_created(
        self, sqlite_backend: SQLiteBackend
    ) -> None:
        rows = await sqlite_backend.execute_raw(
            "SELECT name FROM sqlite_master WHERE type='table'"
        )
        actual = {r["name"] for r in rows}
        expected = ALLOWED_TABLES - {"_migrations"} | {"_migrations"}
        # Every domain table should exist
        for table in expected:
            assert table in actual, f"Missing table: {table}"

    @pytest.mark.asyncio
    async def test_migrations_table_records_version(
        self, sqlite_backend: SQLiteBackend
    ) -> None:
        rows = await sqlite_backend.execute_raw(
            "SELECT version, name FROM _migrations"
        )
        assert any(
            r["version"] == 1 and r["name"] == "initial_schema" for r in rows
        )


# ---------------------------------------------------------------------------
# PostgreSQL (skipped unless a DSN is provided)
# ---------------------------------------------------------------------------


_PG_DSN = os.environ.get("WHYCODE_PG_DSN")


@pytest.mark.skipif(_PG_DSN is None, reason="WHYCODE_PG_DSN not set")
class TestPostgreSQLBackend:
    """Smoke tests against a live PostgreSQL instance."""

    @pytest.mark.asyncio
    async def test_pg_round_trip(self) -> None:
        assert _PG_DSN is not None
        backend = PostgreSQLBackend(_PG_DSN)
        await backend.connect()
        try:
            await apply_migrations(backend)
            d = Decision(title="PG test")
            await backend.insert("decisions", d.to_dict())
            got = await backend.get_by_id("decisions", str(d.id))
            assert got is not None
            assert got["title"] == "PG test"
            await backend.delete("decisions", str(d.id))
        finally:
            await backend.close()
