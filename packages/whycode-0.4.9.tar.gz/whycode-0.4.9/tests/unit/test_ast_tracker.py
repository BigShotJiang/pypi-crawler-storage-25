"""Unit tests for backend/intelligence/ast_tracker.py.

Covers entity extraction for all 10 supported languages, diff parsing for
additions/removals/signature changes, and the decision-linking pipeline.
Tests use in-memory SQLite via the real :class:`SQLiteBackend` to exercise
the persistence path end-to-end.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any

import pytest

from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.intelligence.ast_tracker import (
    ASTTracker,
    ASTTrackerError,
    Entity,
)
from backend.intelligence.tree_sitter_langs import LanguageRegistry
from backend.models import Decision

if TYPE_CHECKING:
    from pathlib import Path

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
async def db(tmp_path: Path) -> Any:
    backend = SQLiteBackend(str(tmp_path / "whycode.db"))
    await backend.connect()
    await apply_migrations(backend)
    yield backend
    await backend.close()


@pytest.fixture
def tracker(db: SQLiteBackend) -> ASTTracker:
    return ASTTracker(db=db, registry=LanguageRegistry())


@pytest.fixture
def fixed_now() -> datetime:
    return datetime(2026, 4, 15, 12, 0, 0, tzinfo=UTC)


@pytest.fixture
def tracker_fixed_clock(
    db: SQLiteBackend, fixed_now: datetime
) -> ASTTracker:
    return ASTTracker(
        db=db,
        registry=LanguageRegistry(),
        now=lambda: fixed_now,
    )


# ---------------------------------------------------------------------------
# parse_file_content — per-language extraction
# ---------------------------------------------------------------------------


class TestParseFileContentPython:
    def test_extracts_function_class_import(
        self, tracker: ASTTracker
    ) -> None:
        src = (
            "import os\n"
            "from typing import Any\n"
            "def foo(x: int) -> int:\n"
            "    return x + 1\n"
            "class Bar:\n"
            "    pass\n"
        )
        entities = tracker.parse_file_content(src, "sample.py")
        kinds = {(e.kind, e.name) for e in entities}
        assert ("function", "foo") in kinds
        assert ("class", "Bar") in kinds
        # Either import is acceptable — grammar-specific first-child identifier.
        assert any(e.kind == "import" for e in entities)


class TestParseFileContentOtherLanguages:
    def test_typescript(self, tracker: ASTTracker) -> None:
        src = (
            'import { a } from "mod";\n'
            "export function foo(x: number): number { return x+1; }\n"
            "class Bar {}\n"
        )
        entities = tracker.parse_file_content(src, "sample.ts")
        kinds = {(e.kind, e.name) for e in entities}
        assert ("function", "foo") in kinds
        assert ("class", "Bar") in kinds

    def test_go(self, tracker: ASTTracker) -> None:
        src = (
            "package main\n"
            'import "fmt"\n'
            "func Foo(x int) int { return x + 1 }\n"
            "type Bar struct {}\n"
        )
        entities = tracker.parse_file_content(src, "main.go")
        names = {e.name for e in entities}
        assert "Foo" in names

    def test_rust(self, tracker: ASTTracker) -> None:
        src = (
            "use std::io;\n"
            "fn foo(x: i32) -> i32 { x + 1 }\n"
            "struct Bar {}\n"
        )
        entities = tracker.parse_file_content(src, "mod.rs")
        names = {e.name for e in entities}
        assert "foo" in names
        assert "Bar" in names

    def test_java(self, tracker: ASTTracker) -> None:
        src = (
            "import java.util.List;\n"
            "class Bar { public int foo(int x) { return x+1; } }\n"
        )
        entities = tracker.parse_file_content(src, "Bar.java")
        kinds = {(e.kind, e.name) for e in entities}
        assert ("class", "Bar") in kinds

    def test_c(self, tracker: ASTTracker) -> None:
        src = (
            "#include <stdio.h>\n"
            "int foo(int x) { return x + 1; }\n"
        )
        entities = tracker.parse_file_content(src, "lib.c")
        functions = [e for e in entities if e.kind == "function"]
        assert functions
        assert any(e.name == "foo" for e in functions)

    def test_cpp(self, tracker: ASTTracker) -> None:
        src = (
            "#include <vector>\n"
            "class Bar { public: int foo(int x) { return x + 1; } };\n"
        )
        entities = tracker.parse_file_content(src, "main.cpp")
        names = {e.name for e in entities}
        assert "Bar" in names

    def test_ruby(self, tracker: ASTTracker) -> None:
        src = (
            'require "json"\n'
            "def foo(x); x + 1; end\n"
            "class Bar; end\n"
        )
        entities = tracker.parse_file_content(src, "sample.rb")
        kinds = {(e.kind, e.name) for e in entities}
        assert ("function", "foo") in kinds
        assert ("class", "Bar") in kinds
        assert ("import", "json") in kinds

    def test_csharp(self, tracker: ASTTracker) -> None:
        src = (
            "using System;\n"
            "class Bar { public int Foo(int x) { return x + 1; } }\n"
        )
        entities = tracker.parse_file_content(src, "Bar.cs")
        kinds = {(e.kind, e.name) for e in entities}
        assert ("class", "Bar") in kinds


class TestParseFileContentValidation:
    def test_non_string_rejected(self, tracker: ASTTracker) -> None:
        with pytest.raises(ASTTrackerError):
            tracker.parse_file_content(123, "sample.py")  # type: ignore[arg-type]

    def test_unsupported_extension_rejected(
        self, tracker: ASTTracker
    ) -> None:
        with pytest.raises(ASTTrackerError):
            tracker.parse_file_content("anything", "README.md")

    def test_empty_content_returns_empty(self, tracker: ASTTracker) -> None:
        assert tracker.parse_file_content("", "sample.py") == []


# ---------------------------------------------------------------------------
# parse_diff — add / remove / modify
# ---------------------------------------------------------------------------


class TestParseDiff:
    def test_function_added_detected(self, tracker: ASTTracker) -> None:
        diff = (
            "@@ -1,2 +1,5 @@\n"
            " existing\n"
            " context\n"
            "+def new_fn(x):\n"
            "+    return x + 1\n"
            "+\n"
        )
        changes = tracker.parse_diff(diff, "sample.py")
        types = [(c.change_type, c.entity_name) for c in changes]
        assert ("function_added", "new_fn") in types

    def test_function_removed_detected(self, tracker: ASTTracker) -> None:
        diff = (
            "@@ -1,5 +1,1 @@\n"
            " context\n"
            "-def old_fn(x):\n"
            "-    return x - 1\n"
            "-\n"
            "-class Legacy:\n"
            "-    pass\n"
        )
        changes = tracker.parse_diff(diff, "sample.py")
        types = [(c.change_type, c.entity_name) for c in changes]
        assert ("function_removed", "old_fn") in types
        assert ("class_removed", "Legacy") in types

    def test_signature_changed_detected(
        self, tracker: ASTTracker
    ) -> None:
        diff = (
            "@@ -1,2 +1,2 @@\n"
            "-def foo(x):\n"
            "-    return x\n"
            "+def foo(x: int) -> int:\n"
            "+    return x + 1\n"
        )
        changes = tracker.parse_diff(diff, "sample.py")
        sig_changes = [
            c for c in changes if c.change_type == "signature_changed"
        ]
        assert len(sig_changes) == 1
        change = sig_changes[0]
        assert change.entity_name == "foo"
        assert change.old_signature is not None
        assert change.new_signature is not None
        assert change.old_signature != change.new_signature

    def test_import_added_detected(self, tracker: ASTTracker) -> None:
        diff = (
            "@@ -1,1 +1,2 @@\n"
            " existing\n"
            "+import os\n"
        )
        changes = tracker.parse_diff(diff, "sample.py")
        imports = [c for c in changes if c.entity_type == "import"]
        assert len(imports) >= 1
        assert imports[0].change_type == "import_added"

    def test_typescript_function_added(
        self, tracker: ASTTracker
    ) -> None:
        diff = (
            "@@ -1,1 +1,3 @@\n"
            " existing\n"
            "+function addOne(x: number): number {\n"
            "+    return x + 1;\n"
            "+}\n"
        )
        changes = tracker.parse_diff(diff, "sample.ts")
        names = [c.entity_name for c in changes if c.change_type == "function_added"]
        assert "addOne" in names

    def test_unsupported_file_raises(self, tracker: ASTTracker) -> None:
        with pytest.raises(ASTTrackerError):
            tracker.parse_diff("+any content", "README.md")

    def test_no_changes_returns_empty(self, tracker: ASTTracker) -> None:
        diff = "@@ -1,1 +1,1 @@\n context only\n"
        assert tracker.parse_diff(diff, "sample.py") == []


# ---------------------------------------------------------------------------
# Multi-file process_commit + diff splitting
# ---------------------------------------------------------------------------


class TestProcessCommit:
    async def test_persists_changes_and_skips_unsupported(
        self,
        tracker_fixed_clock: ASTTracker,
        db: SQLiteBackend,
    ) -> None:
        diff = (
            "diff --git a/src/foo.py b/src/foo.py\n"
            "--- a/src/foo.py\n"
            "+++ b/src/foo.py\n"
            "@@ -1,1 +1,3 @@\n"
            " existing\n"
            "+def added_fn(x):\n"
            "+    return x * 2\n"
            "diff --git a/docs/README.md b/docs/README.md\n"
            "--- a/docs/README.md\n"
            "+++ b/docs/README.md\n"
            "@@ -1,1 +1,1 @@\n"
            "-old\n"
            "+new\n"
        )
        changes, edges = await tracker_fixed_clock.process_commit(
            commit_hash="deadbeef",
            diff_text=diff,
            project_id="proj-1",
        )
        assert len(changes) == 1
        assert changes[0].entity_name == "added_fn"
        assert changes[0].file_path == "src/foo.py"
        # Persisted in ast_changes
        rows = await db.query("ast_changes")
        assert len(rows) == 1
        assert rows[0]["commit_hash"] == "deadbeef"
        # No decisions → no edges.
        assert edges == []


# ---------------------------------------------------------------------------
# Decision linking
# ---------------------------------------------------------------------------


class TestLinkChangesToDecision:
    async def test_temporal_link_within_window(
        self,
        db: SQLiteBackend,
        tracker_fixed_clock: ASTTracker,
        fixed_now: datetime,
    ) -> None:
        recent = Decision(
            title="Recent decision",
            description="Use Argon2id",
        )
        recent.created_at = fixed_now - timedelta(hours=1)
        await db.insert("decisions", recent.to_dict())

        stale = Decision(title="Stale decision")
        stale.created_at = fixed_now - timedelta(days=7)
        await db.insert("decisions", stale.to_dict())

        diff = (
            "@@ -1,0 +1,2 @@\n"
            "+def new_fn(x):\n"
            "+    return x\n"
        )
        changes = tracker_fixed_clock.parse_diff(diff, "auth.py")
        edges = await tracker_fixed_clock.link_changes_to_decision(
            changes, commit_hash="c1", project_id="proj-1"
        )
        # One edge per (change, in-window decision) pair → 1 * 1.
        assert len(edges) == 1
        assert edges[0].source_id == recent.id
        assert edges[0].relationship == "temporally_related"

    async def test_file_mention_promotes_to_touches(
        self,
        db: SQLiteBackend,
        tracker_fixed_clock: ASTTracker,
        fixed_now: datetime,
    ) -> None:
        decision = Decision(
            title="Rework auth.py for Argon2id",
            description="Switch password hashing to Argon2id.",
        )
        decision.created_at = fixed_now - timedelta(minutes=10)
        await db.insert("decisions", decision.to_dict())

        changes = tracker_fixed_clock.parse_diff(
            "@@ -0,0 +1 @@\n+def hash_password(p):\n+    pass\n",
            "auth.py",
        )
        edges = await tracker_fixed_clock.link_changes_to_decision(
            changes, commit_hash="c2", project_id="proj-1"
        )
        assert edges
        assert all(e.relationship == "touches" for e in edges)

    async def test_session_match_promotes_to_touches(
        self,
        db: SQLiteBackend,
        tracker_fixed_clock: ASTTracker,
        fixed_now: datetime,
    ) -> None:
        session_id = uuid.uuid4()
        decision = Decision(title="Session decision")
        decision.recorded_in_session_id = session_id
        decision.created_at = fixed_now - timedelta(minutes=5)
        await db.insert("decisions", decision.to_dict())

        changes = tracker_fixed_clock.parse_diff(
            "@@ -0,0 +1 @@\n+def something(): pass\n",
            "other.py",
        )
        edges = await tracker_fixed_clock.link_changes_to_decision(
            changes,
            commit_hash="c3",
            project_id="proj-1",
            session_id=str(session_id),
        )
        assert edges
        assert edges[0].relationship == "touches"

    async def test_no_candidates_yields_no_edges(
        self,
        db: SQLiteBackend,
        tracker_fixed_clock: ASTTracker,
        fixed_now: datetime,
    ) -> None:
        # Decision is outside the window and no session match.
        old = Decision(title="Old")
        old.created_at = fixed_now - timedelta(days=5)
        await db.insert("decisions", old.to_dict())

        changes = tracker_fixed_clock.parse_diff(
            "@@ -0,0 +1 @@\n+def x(): pass\n",
            "a.py",
        )
        edges = await tracker_fixed_clock.link_changes_to_decision(
            changes, commit_hash="c4", project_id="proj-1"
        )
        assert edges == []

    async def test_empty_change_list_yields_no_edges(
        self,
        tracker_fixed_clock: ASTTracker,
    ) -> None:
        edges = await tracker_fixed_clock.link_changes_to_decision(
            [], commit_hash="c5", project_id="proj-1"
        )
        assert edges == []

    async def test_changes_persisted_even_with_no_decisions(
        self,
        db: SQLiteBackend,
        tracker_fixed_clock: ASTTracker,
    ) -> None:
        changes = tracker_fixed_clock.parse_diff(
            "@@ -0,0 +1 @@\n+def foo(): pass\n",
            "foo.py",
        )
        await tracker_fixed_clock.link_changes_to_decision(
            changes, commit_hash="c6", project_id="proj-1"
        )
        rows = await db.query("ast_changes")
        assert any(r["entity_name"] == "foo" for r in rows)


# ---------------------------------------------------------------------------
# Entity dataclass
# ---------------------------------------------------------------------------


class TestEntityKey:
    def test_key_is_kind_and_name(self) -> None:
        e = Entity(kind="function", name="foo", signature="def foo():")
        assert e.key == ("function", "foo")


# ---------------------------------------------------------------------------
# process_change_event — unified git + file_watcher entry point
# ---------------------------------------------------------------------------


_DIFF_ADD_FN = (
    "diff --git a/x.py b/x.py\n"
    "--- a/x.py\n"
    "+++ b/x.py\n"
    "@@ -0,0 +1,2 @@\n"
    "+def added_fn(n):\n"
    "+    return n\n"
)


class TestProcessChangeEvent:
    """Dispatches on change_event_source and writes unlinked audit records."""

    async def test_rejects_unknown_event_type(
        self, tracker_fixed_clock: ASTTracker
    ) -> None:
        with pytest.raises(ASTTrackerError):
            await tracker_fixed_clock.process_change_event(
                change_event_id="c1",
                change_event_source="svn_commit",
                diff_text=_DIFF_ADD_FN,
                project_id="proj-1",
            )

    async def test_requires_non_empty_change_event_id(
        self, tracker_fixed_clock: ASTTracker
    ) -> None:
        with pytest.raises(ASTTrackerError):
            await tracker_fixed_clock.process_change_event(
                change_event_id="",
                change_event_source="git_commit",
                diff_text=_DIFF_ADD_FN,
                project_id="proj-1",
            )

    async def test_git_commit_no_decision_creates_unlinked_commit(
        self, db: SQLiteBackend, tracker_fixed_clock: ASTTracker
    ) -> None:
        result = await tracker_fixed_clock.process_change_event(
            change_event_id="deadbeef",
            change_event_source="git_commit",
            diff_text=_DIFF_ADD_FN,
            project_id="proj-1",
        )
        assert result["linked_changes"] == []
        assert result["unlinked_changes"] == ["added_fn"]

        ast_rows = await db.query("ast_changes")
        assert len(ast_rows) == 1
        assert ast_rows[0]["change_event_id"] == "deadbeef"
        assert ast_rows[0]["change_event_source"] == "git_commit"
        assert ast_rows[0]["project_id"] == "proj-1"

        unlinked = await db.query("unlinked_commits")
        assert len(unlinked) == 1
        assert unlinked[0]["commit_hash"] == "deadbeef"
        assert unlinked[0]["project_id"] == "proj-1"

    async def test_file_snapshot_no_decision_creates_unlinked_file_change(
        self, db: SQLiteBackend, tracker_fixed_clock: ASTTracker
    ) -> None:
        snap_id = "snap_abc"
        result = await tracker_fixed_clock.process_change_event(
            change_event_id=snap_id,
            change_event_source="file_snapshot",
            diff_text=_DIFF_ADD_FN,
            project_id="proj-1",
        )
        assert result["unlinked_changes"] == ["added_fn"]

        ast_rows = await db.query("ast_changes")
        assert ast_rows[0]["change_event_source"] == "file_snapshot"
        assert ast_rows[0]["change_event_id"] == snap_id

        unlinked_file = await db.query("unlinked_file_changes")
        assert len(unlinked_file) == 1
        assert unlinked_file[0]["snapshot_id"] == snap_id
        assert unlinked_file[0]["file_path"] == "x.py"

        # Git table should be empty.
        unlinked_commits = await db.query("unlinked_commits")
        assert unlinked_commits == []

    async def test_linked_decision_suppresses_unlinked_record(
        self,
        db: SQLiteBackend,
        tracker_fixed_clock: ASTTracker,
        fixed_now: datetime,
    ) -> None:
        d = Decision(
            title="Touch x.py",
            description="Needs added_fn in x.py",
        )
        d.created_at = fixed_now - timedelta(minutes=1)
        await db.insert("decisions", d.to_dict())

        result = await tracker_fixed_clock.process_change_event(
            change_event_id="commit-123",
            change_event_source="git_commit",
            diff_text=_DIFF_ADD_FN,
            project_id="proj-1",
        )
        assert result["linked_changes"] == ["added_fn"]
        assert result["unlinked_changes"] == []

        assert await db.query("unlinked_commits") == []

    async def test_identical_ast_change_rows_for_both_backends(
        self, db: SQLiteBackend, tracker_fixed_clock: ASTTracker
    ) -> None:
        """Same source change → structurally identical ASTChange rows."""
        await tracker_fixed_clock.process_change_event(
            change_event_id="commit-a",
            change_event_source="git_commit",
            diff_text=_DIFF_ADD_FN,
            project_id="proj-git",
        )
        await tracker_fixed_clock.process_change_event(
            change_event_id="snap-a",
            change_event_source="file_snapshot",
            diff_text=_DIFF_ADD_FN,
            project_id="proj-snap",
        )
        rows = await db.query("ast_changes")
        assert len(rows) == 2
        # Non-event fields should match.
        git_row = next(r for r in rows if r["change_event_source"] == "git_commit")
        snap_row = next(
            r for r in rows if r["change_event_source"] == "file_snapshot"
        )
        for key in (
            "file_path",
            "language",
            "change_type",
            "entity_name",
            "entity_type",
        ):
            assert git_row[key] == snap_row[key]
