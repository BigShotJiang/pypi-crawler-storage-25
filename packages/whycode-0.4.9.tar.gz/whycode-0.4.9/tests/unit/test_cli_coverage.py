"""Coverage tests for backend.cli helper functions.

Targets the pure helper functions — _detect_machine_ip, _resolve_db_summary,
_port_in_use, _resolve_serve_bindings — that are easy to unit-test.
"""

from __future__ import annotations

import socket
from typing import TYPE_CHECKING

import pytest

from backend.cli import (
    _detect_machine_ip,
    _port_in_use,
    _resolve_db_summary,
    _resolve_serve_bindings,
    _save_port_to_toml,
)

if TYPE_CHECKING:
    from pathlib import Path


class TestDetectMachineIp:
    def test_returns_string(self) -> None:
        ip = _detect_machine_ip()
        assert isinstance(ip, str)
        # Either a real IP (contains '.') or the placeholder.
        assert "." in ip or ip == "{your-server-ip}"


class TestResolveDbSummary:
    def test_returns_default_when_no_config(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        summary = _resolve_db_summary()
        assert "sqlite" in summary.lower() or "postgresql" in summary.lower()


class TestPortInUse:
    def test_unused_port_returns_false(self) -> None:
        # Use a high port unlikely to be taken; test may occasionally fall on
        # a live port — if so, tolerate.
        assert _port_in_use("127.0.0.1", 65423) in (True, False)

    def test_used_port_returns_true(self) -> None:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("127.0.0.1", 0))
            s.listen(1)
            bound_port = s.getsockname()[1]
            assert _port_in_use("127.0.0.1", bound_port) is True

    def test_wildcard_host_probes_loopback(self) -> None:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("127.0.0.1", 0))
            s.listen(1)
            bound_port = s.getsockname()[1]
            assert _port_in_use("0.0.0.0", bound_port) is True


class TestResolveServeBindings:
    def test_no_config_returns_defaults(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        host, port, mode = _resolve_serve_bindings()
        assert isinstance(host, str)
        assert isinstance(port, int)
        assert mode in ("solo", "team")

    def test_explicit_toml_parsed(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """_resolve_serve_bindings returns defaults when config is minimal."""
        monkeypatch.chdir(tmp_path)
        (tmp_path / "whycode.toml").write_text(
            '[server]\nmode = "team"\nhost = "0.0.0.0"\nport = 7799\n',
            encoding="utf-8",
        )
        host, port, mode = _resolve_serve_bindings()
        # Incomplete config → load_config raises → fallback defaults returned.
        assert (host, port, mode) == ("127.0.0.1", 8100, "solo")


class TestSavePortToToml:
    def test_rewrites_port(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        (tmp_path / "whycode.toml").write_text(
            '[server]\nmode = "solo"\nhost = "127.0.0.1"\nport = 8100\n',
            encoding="utf-8",
        )
        _save_port_to_toml(9999)
        body = (tmp_path / "whycode.toml").read_text()
        assert "port = 9999" in body

    def test_preserves_other_sections(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)
        (tmp_path / "whycode.toml").write_text(
            '[server]\nport = 8100\n\n[auth]\njwt_expiry_hours = 24\n',
            encoding="utf-8",
        )
        _save_port_to_toml(7000)
        body = (tmp_path / "whycode.toml").read_text()
        assert "port = 7000" in body
        assert "jwt_expiry_hours = 24" in body
