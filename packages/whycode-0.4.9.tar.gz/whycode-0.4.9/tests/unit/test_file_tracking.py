"""v0.4.8 regression tests — file-tracking and session enforcement.

The Windows production session 1d6e8646 surfaced three cascading bugs:

1. The PreToolUse ``file-context`` hook did not update
   ``Session.files_touched``, so the field sat at ``[]`` no matter
   how many files an agent edited.
2. The ``session.end`` enforcement check read only from
   ``ast_changes``, not ``files_touched``, so Windows installs
   (no git, no file_watcher firing) surfaced zero unlinked files
   and never ran passive inference.
3. ``UserPromptSubmit`` did not emit a ``hook_project_root`` event,
   so the ``Stop`` hook's ``hooks_close_session`` could not locate
   the session.

The tests below exercise the fixes at the handler layer.
"""

from __future__ import annotations

import json
import uuid
from pathlib import Path

import pytest

from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.db.vector_store import SqliteVssStore
from backend.intelligence.context_triage import ContextTriage
from backend.intelligence.semantic_search import SemanticSearch
from backend.mcp.tool_handlers import ToolHandlers
from backend.utils.token_counter import count_tokens
from backend.verification.conflict_detector import ConflictDetector


class _FakeEmbedder:
    """Fixed 16-dim embedder — avoids Ollama / sentence-transformers in CI."""

    async def embed_text(self, _text: str) -> list[float]:
        return [0.0] * 16

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        return [[0.0] * 16 for _ in texts]


@pytest.fixture
async def project_dir(tmp_path: Path) -> Path:
    """A project root with a minimal whycode.toml so _find_project_id hits."""
    proj = tmp_path / "demo-project"
    proj.mkdir()
    (proj / "whycode.toml").write_text("# minimal\n", encoding="utf-8")
    return proj


@pytest.fixture
async def handlers(tmp_path: Path) -> ToolHandlers:
    db = SQLiteBackend(tmp_path / "tracking.db")
    await db.connect()
    await apply_migrations(db)
    store = SqliteVssStore(tmp_path / "tracking-vec.db", dim=16)
    await store.connect()
    semantic = SemanticSearch(
        embedder=_FakeEmbedder(), vector_store=store, db=db
    )
    yield ToolHandlers(
        db=db,
        semantic_search=semantic,
        context_triage=ContextTriage(count_tokens),
        conflict_detector=ConflictDetector(db),
    )
    await store.close()
    await db.close()


# ---------------------------------------------------------------------------
# hooks_session_context — creates session + hook_project_root event
# ---------------------------------------------------------------------------


async def test_session_context_creates_session_on_first_call(
    handlers: ToolHandlers, project_dir: Path
) -> None:
    """UserPromptSubmit hook: first call must start a session and
    return its id so close-session can find it later."""
    result = await handlers.hooks_session_context(
        user_id=uuid.uuid4(),
        cwd=str(project_dir),
        prompt="hello",
        agent_name="claude-code",
    )
    assert result["session_id"], "session_id must be present in response"
    rows = await handlers.db.query(
        "session_events",
        where={"session_id": result["session_id"], "event_type": "hook_project_root"},
    )
    assert len(rows) >= 1, "hook_project_root event not recorded"


async def test_session_context_is_idempotent(
    handlers: ToolHandlers, project_dir: Path
) -> None:
    """Repeated session-context calls from the same cwd reuse the
    session — we must NOT spawn a new session per prompt."""
    first = await handlers.hooks_session_context(
        user_id=uuid.uuid4(),
        cwd=str(project_dir),
        prompt="one",
        agent_name="claude-code",
    )
    second = await handlers.hooks_session_context(
        user_id=uuid.uuid4(),
        cwd=str(project_dir),
        prompt="two",
        agent_name="claude-code",
    )
    assert first["session_id"] == second["session_id"]


# ---------------------------------------------------------------------------
# hooks_file_context — appends to files_touched
# ---------------------------------------------------------------------------


async def test_file_context_records_file_on_session(
    handlers: ToolHandlers, project_dir: Path
) -> None:
    ctx = await handlers.hooks_session_context(
        user_id=uuid.uuid4(),
        cwd=str(project_dir),
        prompt="begin",
        agent_name="claude-code",
    )
    session_id = ctx["session_id"]

    await handlers.hooks_file_context(
        user_id=uuid.uuid4(),
        cwd=str(project_dir),
        file_path="src/auth.py",
        agent_name="claude-code",
    )

    row = await handlers.db.query(
        "sessions", where={"id": session_id}
    )
    assert row, "session missing after file-context call"
    stored = row[0]["files_touched"]
    touched = json.loads(stored) if isinstance(stored, str) else stored
    assert "src/auth.py" in touched


async def test_file_context_deduplicates(
    handlers: ToolHandlers, project_dir: Path
) -> None:
    """Same file touched three times must appear once in files_touched."""
    await handlers.hooks_session_context(
        user_id=uuid.uuid4(),
        cwd=str(project_dir),
        prompt="begin",
        agent_name="claude-code",
    )
    for _ in range(3):
        await handlers.hooks_file_context(
            user_id=uuid.uuid4(),
            cwd=str(project_dir),
            file_path="src/main.py",
            agent_name="claude-code",
        )

    rows = await handlers.db.query(
        "sessions",
        where={"agent_name": "claude-code", "status": "active"},
    )
    assert len(rows) == 1
    stored = rows[0]["files_touched"]
    touched = json.loads(stored) if isinstance(stored, str) else stored
    assert touched.count("src/main.py") == 1


async def test_file_context_returns_session_id(
    handlers: ToolHandlers, project_dir: Path
) -> None:
    resp = await handlers.hooks_file_context(
        user_id=uuid.uuid4(),
        cwd=str(project_dir),
        file_path="x.py",
        agent_name="claude-code",
    )
    assert resp.get("session_id"), "file-context must echo session_id"


# ---------------------------------------------------------------------------
# session.end — unlinked_files merges files_touched
# ---------------------------------------------------------------------------


async def test_session_end_warns_on_files_touched_without_ast_changes(
    handlers: ToolHandlers, project_dir: Path
) -> None:
    """Windows path: no ast_changes (git/file_watcher missing) but
    files_touched populated via PreToolUse — session.end must still
    return completed_with_warnings so the agent gets asked about
    those edits."""
    ctx = await handlers.hooks_session_context(
        user_id=uuid.uuid4(),
        cwd=str(project_dir),
        prompt="start",
        agent_name="claude-code",
    )
    session_id = ctx["session_id"]

    await handlers.hooks_file_context(
        user_id=uuid.uuid4(),
        cwd=str(project_dir),
        file_path="src/auth.py",
        agent_name="claude-code",
    )
    await handlers.hooks_file_context(
        user_id=uuid.uuid4(),
        cwd=str(project_dir),
        file_path="src/crypto.py",
        agent_name="claude-code",
    )

    result = await handlers.session_end(
        user_id=uuid.uuid4(),
        session_id=uuid.UUID(session_id),
    )
    assert result["status"] == "completed_with_warnings"
    assert sorted(result["unlinked_files"]) == [
        "src/auth.py",
        "src/crypto.py",
    ]


async def test_hooks_close_session_finds_session_after_session_context(
    handlers: ToolHandlers, project_dir: Path
) -> None:
    """End-to-end: UserPromptSubmit creates the session + event; Stop
    hook's close-session endpoint finds it via cwd lookup."""
    ctx = await handlers.hooks_session_context(
        user_id=uuid.uuid4(),
        cwd=str(project_dir),
        prompt="start",
        agent_name="claude-code",
    )
    await handlers.hooks_file_context(
        user_id=uuid.uuid4(),
        cwd=str(project_dir),
        file_path="src/only.py",
        agent_name="claude-code",
    )
    result = await handlers.hooks_close_session(
        user_id=uuid.uuid4(),
        cwd=str(project_dir),
    )
    assert result["status"] == "closed"
    assert result.get("session_id") == ctx["session_id"]


# ---------------------------------------------------------------------------
# Churn threshold — statistical correctness
# ---------------------------------------------------------------------------


def test_churn_threshold_reachable_with_gte() -> None:
    """The production bug: ``hours_below_median > 50%`` is unreachable
    on even-length series because the median splits 50/50 by
    definition. The correct predicate uses ``>=``."""
    hours = list(range(28))  # even-length
    median = sorted(hours)[len(hours) // 2 - 1]  # lower median
    below = sum(1 for h in hours if h < median)
    pct = below / len(hours)
    # >= is reachable on this series:
    assert pct >= 0.50 or (pct >= 0.40 and pct < 0.50), (
        f"Expected reachable split, got {pct:.0%}"
    )
    # The original > predicate is the bug:
    assert not (pct > 0.50), (
        "The > predicate should not be true here — "
        "that's the statistical-correctness bug this test documents."
    )
