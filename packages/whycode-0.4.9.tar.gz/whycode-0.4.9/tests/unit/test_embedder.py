"""Unit tests for backend/intelligence/embedder.py.

Mocks Ollama HTTP responses via ``httpx.MockTransport`` so these tests do
not require a running Ollama instance. Verifies: successful single and
batch embedding, error handling for model-not-found and connection
failure, exponential-backoff retry on transient 5xx, and output dimensions.
"""

from __future__ import annotations

from typing import Any

import httpx
import pytest

from backend.config import EmbeddingConfig
from backend.intelligence import embedder as embedder_module
from backend.intelligence.embedder import (
    EMBEDDING_DIM,
    Embedder,
    EmbeddingError,
    OllamaModelNotFoundError,
    OllamaNotRunningError,
)


def _make_config() -> EmbeddingConfig:
    return EmbeddingConfig(
        ollama_url="http://ollama.test:11434",
        model="nomic-embed-text",
        batch_size=4,
    )


def _embedding_body(dim: int = EMBEDDING_DIM) -> dict[str, list[float]]:
    return {"embedding": [0.1] * dim}


def _make_embedder_with_handler(
    handler: Any,
    *,
    max_retries: int = 3,
    initial_backoff_seconds: float = 0.0,
) -> Embedder:
    """Patch httpx.AsyncClient to use a MockTransport driving ``handler``.

    The Embedder constructs its own ``AsyncClient`` inside ``embed_text``;
    we swap the class with a factory that injects a MockTransport so the
    test controls every HTTP response without a real network.
    """
    original = httpx.AsyncClient

    def factory(*args: Any, **kwargs: Any) -> httpx.AsyncClient:
        kwargs.pop("transport", None)
        kwargs["transport"] = httpx.MockTransport(handler)
        return original(*args, **kwargs)

    # Swap on the module-level reference used by embedder.py
    embedder_module.httpx.AsyncClient = factory  # type: ignore[assignment,misc]
    return Embedder(
        _make_config(),
        timeout_seconds=1.0,
        max_retries=max_retries,
        initial_backoff_seconds=initial_backoff_seconds,
    )


@pytest.fixture(autouse=True)
def _restore_httpx() -> Any:
    """Ensure tests cannot leak patched httpx.AsyncClient to later tests."""
    original = httpx.AsyncClient
    yield
    embedder_module.httpx.AsyncClient = original  # type: ignore[misc]


class TestEmbedText:
    async def test_successful_embedding(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.url.path == "/api/embeddings"
            assert request.method == "POST"
            return httpx.Response(200, json=_embedding_body())

        emb = _make_embedder_with_handler(handler)
        vec = await emb.embed_text("hello world")
        assert isinstance(vec, list)
        assert len(vec) == EMBEDDING_DIM
        assert all(isinstance(x, float) for x in vec)

    async def test_model_not_found_raises(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(404, text="model not found")

        emb = _make_embedder_with_handler(handler)
        with pytest.raises(OllamaModelNotFoundError):
            await emb.embed_text("hello")

    async def test_connection_error_raises_not_running(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            raise httpx.ConnectError("connection refused")

        emb = _make_embedder_with_handler(handler)
        with pytest.raises(OllamaNotRunningError):
            await emb.embed_text("hello")

    async def test_retry_on_5xx_then_success(self) -> None:
        call_count = {"n": 0}

        def handler(request: httpx.Request) -> httpx.Response:
            call_count["n"] += 1
            if call_count["n"] < 3:
                return httpx.Response(503, text="service unavailable")
            return httpx.Response(200, json=_embedding_body())

        emb = _make_embedder_with_handler(handler)
        vec = await emb.embed_text("retry me")
        assert len(vec) == EMBEDDING_DIM
        assert call_count["n"] == 3

    async def test_retry_exhausted_on_persistent_5xx(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(500, text="server error")

        emb = _make_embedder_with_handler(handler)
        with pytest.raises(EmbeddingError):
            await emb.embed_text("doomed")

    async def test_bad_request_400_no_retry(self) -> None:
        call_count = {"n": 0}

        def handler(request: httpx.Request) -> httpx.Response:
            call_count["n"] += 1
            return httpx.Response(400, text="bad request")

        emb = _make_embedder_with_handler(handler)
        with pytest.raises(EmbeddingError):
            await emb.embed_text("bad")
        assert call_count["n"] == 1

    async def test_malformed_response_raises(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"unexpected": "shape"})

        emb = _make_embedder_with_handler(handler)
        with pytest.raises(EmbeddingError):
            await emb.embed_text("hello")

    async def test_non_string_raises_type_error(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json=_embedding_body())

        emb = _make_embedder_with_handler(handler)
        with pytest.raises(TypeError):
            await emb.embed_text(123)  # type: ignore[arg-type]


class TestEmbedBatch:
    async def test_empty_batch_makes_no_requests(self) -> None:
        call_count = {"n": 0}

        def handler(request: httpx.Request) -> httpx.Response:
            call_count["n"] += 1
            return httpx.Response(200, json=_embedding_body())

        emb = _make_embedder_with_handler(handler)
        result = await emb.embed_batch([])
        assert result == []
        assert call_count["n"] == 0

    async def test_batch_preserves_order(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            body = request.content.decode()
            # Encode an identifying value from the prompt into the vector
            # so we can verify order is preserved.
            if "first" in body:
                return httpx.Response(200, json={"embedding": [1.0] * EMBEDDING_DIM})
            if "second" in body:
                return httpx.Response(200, json={"embedding": [2.0] * EMBEDDING_DIM})
            return httpx.Response(200, json={"embedding": [3.0] * EMBEDDING_DIM})

        emb = _make_embedder_with_handler(handler)
        result = await emb.embed_batch(["first", "second", "third"])
        assert len(result) == 3
        assert result[0][0] == 1.0
        assert result[1][0] == 2.0
        assert result[2][0] == 3.0

    async def test_batch_non_list_raises(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json=_embedding_body())

        emb = _make_embedder_with_handler(handler)
        with pytest.raises(TypeError):
            await emb.embed_batch("not a list")  # type: ignore[arg-type]

    async def test_batch_non_string_item_raises(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json=_embedding_body())

        emb = _make_embedder_with_handler(handler)
        with pytest.raises(TypeError):
            await emb.embed_batch(["ok", 123])  # type: ignore[list-item]

    async def test_batch_failure_propagates(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(404, text="missing")

        emb = _make_embedder_with_handler(handler)
        with pytest.raises(OllamaModelNotFoundError):
            await emb.embed_batch(["a", "b"])


class TestVerify:
    async def test_verify_success(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.url.path == "/api/tags"
            return httpx.Response(
                200,
                json={"models": [{"name": "nomic-embed-text:latest"}]},
            )

        emb = _make_embedder_with_handler(handler)
        await emb.verify()  # should not raise

    async def test_verify_model_missing(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"models": [{"name": "other-model"}]})

        emb = _make_embedder_with_handler(handler)
        with pytest.raises(OllamaModelNotFoundError):
            await emb.verify()

    async def test_verify_unreachable(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            raise httpx.ConnectError("refused")

        emb = _make_embedder_with_handler(handler)
        with pytest.raises(OllamaNotRunningError):
            await emb.verify()


class TestConfiguration:
    def test_properties_expose_config(self) -> None:
        cfg = EmbeddingConfig(
            ollama_url="http://example:11434/",
            model="my-model",
            batch_size=16,
        )
        emb = Embedder(cfg)
        assert emb.model == "my-model"
        assert emb.batch_size == 16

    def test_trailing_slash_stripped(self) -> None:
        cfg = EmbeddingConfig(
            ollama_url="http://example:11434/",
            model="my-model",
            batch_size=16,
        )
        emb = Embedder(cfg)
        # Internal state: no trailing slash stored
        assert not emb._base_url.endswith("/")  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# Local sentence-transformers backend + factory
# ---------------------------------------------------------------------------


class TestGetEmbedderFactory:
    """``get_embedder`` dispatches by ``EmbeddingConfig.backend``."""

    def test_ollama_backend_returns_ollama_embedder(self) -> None:
        from backend.intelligence.embedder import OllamaEmbedder, get_embedder

        cfg = EmbeddingConfig(backend="ollama")
        emb = get_embedder(cfg)
        assert isinstance(emb, OllamaEmbedder)

    def test_unknown_backend_raises(self) -> None:
        from backend.intelligence.embedder import EmbeddingError, get_embedder

        cfg = EmbeddingConfig(backend="unknown")  # type: ignore[arg-type]
        with pytest.raises(EmbeddingError, match="Unknown embedding backend"):
            get_embedder(cfg)


class TestSentenceTransformerEmbedder:
    """Local backend — uses a stub to avoid pulling a 90MB model at test time."""

    def test_missing_library_raises_helpful_error(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import sys

        from backend.intelligence.embedder import (
            EmbeddingError,
            SentenceTransformerEmbedder,
        )

        class _BlockingImport:
            def find_module(self, name: str, path: object = None) -> object:
                return self if name == "sentence_transformers" else None

            def load_module(self, name: str) -> None:
                raise ImportError("blocked for test")

        # Force ImportError on `from sentence_transformers import ...` even if
        # the library is installed in the test environment.
        saved = sys.modules.pop("sentence_transformers", None)
        monkeypatch.setitem(sys.modules, "sentence_transformers", None)  # type: ignore[arg-type]
        try:
            cfg = EmbeddingConfig(backend="local")
            with pytest.raises(EmbeddingError, match="sentence-transformers"):
                SentenceTransformerEmbedder(cfg)
        finally:
            if saved is not None:
                sys.modules["sentence_transformers"] = saved
            else:
                sys.modules.pop("sentence_transformers", None)

    @pytest.mark.asyncio
    async def test_embed_text_returns_384_dim(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Stub SentenceTransformer so we do not download any model."""
        import sys
        import types

        from backend.intelligence.embedder import (
            LOCAL_EMBEDDING_DIM,
            SentenceTransformerEmbedder,
        )

        class _StubModel:
            def __init__(self, _name: str) -> None:
                self._dim = LOCAL_EMBEDDING_DIM

            def encode(self, data, *, convert_to_numpy=False, batch_size=None):
                _ = (convert_to_numpy, batch_size)
                if isinstance(data, str):
                    return [0.1] * self._dim
                return [[0.1] * self._dim for _ in data]

        stub_module = types.ModuleType("sentence_transformers")
        stub_module.SentenceTransformer = _StubModel  # type: ignore[attr-defined]
        saved = sys.modules.get("sentence_transformers")
        sys.modules["sentence_transformers"] = stub_module
        try:
            cfg = EmbeddingConfig(
                backend="local",
                local_model="test/stub",
                vector_dim=LOCAL_EMBEDDING_DIM,
            )
            emb = SentenceTransformerEmbedder(cfg)
            vec = await emb.embed_text("hello world")
            assert len(vec) == 384
            batch = await emb.embed_batch(["one", "two"])
            assert len(batch) == 2
            assert all(len(v) == 384 for v in batch)
            # verify() is a no-op for the local backend.
            await emb.verify()
        finally:
            if saved is not None:
                sys.modules["sentence_transformers"] = saved
            else:
                sys.modules.pop("sentence_transformers", None)

    @pytest.mark.asyncio
    async def test_factory_returns_local_when_backend_is_local(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import sys
        import types

        from backend.intelligence.embedder import (
            LOCAL_EMBEDDING_DIM,
            SentenceTransformerEmbedder,
            get_embedder,
        )

        class _Stub:
            def __init__(self, _name: str) -> None:
                pass

            def encode(self, data, *, convert_to_numpy=False, batch_size=None):
                _ = (convert_to_numpy, batch_size)
                return [0.0] * LOCAL_EMBEDDING_DIM if isinstance(data, str) else [
                    [0.0] * LOCAL_EMBEDDING_DIM for _ in data
                ]

        stub_module = types.ModuleType("sentence_transformers")
        stub_module.SentenceTransformer = _Stub  # type: ignore[attr-defined]
        saved = sys.modules.get("sentence_transformers")
        sys.modules["sentence_transformers"] = stub_module
        try:
            cfg = EmbeddingConfig(backend="local", local_model="stub")
            emb = get_embedder(cfg)
            assert isinstance(emb, SentenceTransformerEmbedder)
        finally:
            if saved is not None:
                sys.modules["sentence_transformers"] = saved
            else:
                sys.modules.pop("sentence_transformers", None)


class TestVectorStoreVariableDim:
    """Vector store honours the configured dimension for both backends."""

    @pytest.mark.asyncio
    async def test_384_and_768_dimensions(self, tmp_path) -> None:
        from backend.db.vector_store import SqliteVssStore

        for dim in (384, 768):
            store = SqliteVssStore(tmp_path / f"v-{dim}.db", dim=dim)
            await store.connect()
            try:
                await store.insert(
                    f"item-{dim}",
                    [0.1] * dim,
                    {"project_id": "p", "item_type": "ctx"},
                )
                results = await store.search(
                    [0.1] * dim, top_k=1, project_id="p"
                )
                assert len(results) == 1
            finally:
                await store.close()


class TestInitDetectsOllamaAvailability:
    """``whycode init`` probes Ollama and falls back to local otherwise."""

    def test_detection_falls_back_to_local_when_unreachable(self) -> None:
        from backend.cli import _detect_embedding_backend

        # Use a port that is almost certainly not running Ollama.
        backend, dim = _detect_embedding_backend(
            ollama_url="http://127.0.0.1:59999"
        )
        assert backend == "local"
        assert dim == 384
