"""Coverage tests for backend.auth.oauth_manager error and lookup paths.

Covers load_providers (missing file, non-dict entries), get_provider
(unknown), get_client_credentials (missing env), store/load API key,
get_access_token caching, and error extraction.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from backend.auth.credential_manager import CredentialManager
from backend.auth.oauth_manager import (
    OAuthError,
    OAuthManager,
    ProviderConfig,
    load_providers,
)
from backend.config import CredentialConfig

if TYPE_CHECKING:
    from pathlib import Path


def _mk_creds(tmp_path: Path) -> CredentialManager:
    return CredentialManager(
        CredentialConfig(
            backend="file", vault_path=str(tmp_path / "oauth-vault.enc")
        ),
        passphrase="oauth-test",
    )


class TestLoadProviders:
    def test_missing_file_returns_empty_dict(
        self, tmp_path: Path
    ) -> None:
        """F — load_providers on a missing path logs a warning, returns {}."""
        providers = load_providers(tmp_path / "no-such.toml")
        assert providers == {}

    def test_valid_toml_parsed(self, tmp_path: Path) -> None:
        """Valid provider toml yields a populated ProviderConfig."""
        f = tmp_path / "providers.toml"
        f.write_text(
            '[google]\n'
            'display_name = "Google"\n'
            'auth_type = "oauth2"\n'
            'authorize_url = "https://accounts.google.com/o/oauth2/v2/auth"\n'
            'token_url = "https://oauth2.googleapis.com/token"\n'
            'userinfo_url = "https://openidconnect.googleapis.com/v1/userinfo"\n'
            'scopes = ["openid", "email"]\n'
            'pkce = true\n'
            'client_id_env = "GOOGLE_ID"\n'
            'client_secret_env = "GOOGLE_SECRET"\n',
            encoding="utf-8",
        )
        result = load_providers(f)
        assert "google" in result
        assert result["google"].display_name == "Google"
        assert result["google"].pkce is True


class TestGetProvider:
    def test_unknown_provider_raises(self, tmp_path: Path) -> None:
        mgr = OAuthManager(providers={}, credential_manager=_mk_creds(tmp_path))
        with pytest.raises(OAuthError, match="Unknown provider"):
            mgr.get_provider("nosuchthing")


class TestGetClientCredentials:
    def test_missing_client_id_raises(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.delenv("OAUTH_X_ID", raising=False)
        monkeypatch.delenv("OAUTH_X_SECRET", raising=False)
        provider = ProviderConfig(
            name="x",
            display_name="X",
            auth_type="oauth2",
            authorize_url="",
            token_url="",
            userinfo_url="",
            scopes=[],
            use_for_identity=False,
            use_for_service=False,
            pkce=True,
            client_id_env="OAUTH_X_ID",
            client_secret_env="OAUTH_X_SECRET",
            device_code_url="",
        )
        mgr = OAuthManager(
            providers={"x": provider},
            credential_manager=_mk_creds(tmp_path),
        )
        with pytest.raises(OAuthError, match="Client ID not found"):
            mgr.get_client_credentials(provider)

    def test_missing_secret_returns_empty_for_relay_fallback(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """v0.4.5: a present client_id with no client_secret is a valid
        configuration that routes token exchange through the WhyCode
        relay. ``get_client_credentials`` returns an empty secret
        instead of raising, and ``has_client_secret`` reports ``False``.
        """
        monkeypatch.setenv("OAUTH_Y_ID", "present")
        monkeypatch.delenv("OAUTH_Y_SECRET", raising=False)
        provider = ProviderConfig(
            name="y",
            display_name="Y",
            auth_type="oauth2",
            authorize_url="",
            token_url="",
            userinfo_url="",
            scopes=[],
            use_for_identity=False,
            use_for_service=False,
            pkce=True,
            client_id_env="OAUTH_Y_ID",
            client_secret_env="OAUTH_Y_SECRET",
            device_code_url="",
        )
        mgr = OAuthManager(
            providers={"y": provider},
            credential_manager=_mk_creds(tmp_path),
        )
        client_id, secret = mgr.get_client_credentials(provider)
        assert client_id == "present"
        assert secret == ""
        assert mgr.has_client_secret(provider) is False

    def test_credentials_from_env(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("OAUTH_Z_ID", "the-id")
        monkeypatch.setenv("OAUTH_Z_SECRET", "the-secret")
        provider = ProviderConfig(
            name="z",
            display_name="Z",
            auth_type="oauth2",
            authorize_url="",
            token_url="",
            userinfo_url="",
            scopes=[],
            use_for_identity=False,
            use_for_service=False,
            pkce=True,
            client_id_env="OAUTH_Z_ID",
            client_secret_env="OAUTH_Z_SECRET",
            device_code_url="",
        )
        mgr = OAuthManager(
            providers={"z": provider},
            credential_manager=_mk_creds(tmp_path),
        )
        client_id, secret = mgr.get_client_credentials(provider)
        assert client_id == "the-id"
        assert secret == "the-secret"


class TestDeviceFlowUnsupported:
    async def test_device_flow_missing_url_raises(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("OAUTH_D_ID", "id")
        monkeypatch.setenv("OAUTH_D_SECRET", "secret")
        provider = ProviderConfig(
            name="d",
            display_name="D",
            auth_type="oauth2",
            authorize_url="",
            token_url="",
            userinfo_url="",
            scopes=[],
            use_for_identity=False,
            use_for_service=False,
            pkce=True,
            client_id_env="OAUTH_D_ID",
            client_secret_env="OAUTH_D_SECRET",
            device_code_url="",
        )
        mgr = OAuthManager(
            providers={"d": provider},
            credential_manager=_mk_creds(tmp_path),
        )
        with pytest.raises(OAuthError, match="Device flow not supported"):
            await mgr.device_flow("d")


class TestApiKeyStorage:
    def test_store_api_key_roundtrip(self, tmp_path: Path) -> None:
        mgr = OAuthManager(
            providers={}, credential_manager=_mk_creds(tmp_path)
        )
        mgr.store_api_key("svc", "key-abc-123")
        loaded = mgr._creds.get("svc", "api_key:default")
        assert loaded == "key-abc-123"


class TestGetAccessTokenNoRefresh:
    async def test_no_refresh_returns_none(self, tmp_path: Path) -> None:
        """With no cached access token AND no refresh token in vault, returns None."""
        provider = ProviderConfig(
            name="gh",
            display_name="GitHub",
            auth_type="oauth2",
            authorize_url="",
            token_url="https://github.com/login/oauth/access_token",
            userinfo_url="",
            scopes=[],
            use_for_identity=False,
            use_for_service=False,
            pkce=True,
            client_id_env="",
            client_secret_env="",
            device_code_url="",
        )
        mgr = OAuthManager(
            providers={"gh": provider},
            credential_manager=_mk_creds(tmp_path),
        )
        result = await mgr.get_access_token("gh", "u1")
        assert result is None
