"""Regression tests for the v0.4.9 fix batch.

Covers the fixes that survived the audit (fixes 2, 4, 5-subset, 6-subset,
7, 8 from the v0.4.9 prompt). Fixes 1, 3, 5-full, and 9 were
investigated and rejected — see the audit notes in CHANGELOG.

* ``backend.utils.paths.normalise_path`` converts Windows backslash
  paths to forward-slash form and round-trips POSIX paths unchanged.
* ``Decision`` round-trips ``files_affected`` as a Python list, not a
  JSON string, through both ``to_dict`` and ``from_dict``.
* ``project_create`` writes to the ``projects`` table and is
  idempotent on the (id) primary key.
* ``project_list`` returns rows from the table plus the bootstrap
  default, so the dashboard is never blank after POST + GET.
* ``decision_create`` writes ``provenance_edges`` rows for every
  entry in ``files_affected``.
"""

from __future__ import annotations

import uuid
from pathlib import Path

import pytest

from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.mcp.tool_handlers import ToolHandlers
from backend.models import Decision
from backend.utils.paths import normalise_path


async def _make_handlers(tmp_path: Path) -> ToolHandlers:
    db = SQLiteBackend(str(tmp_path / "whycode.db"))
    await db.connect()
    await apply_migrations(db)
    return ToolHandlers(db=db, project_root=str(tmp_path))


# ---------------------------------------------------------------------------
# Path normalisation (Fix 5 subset)
# ---------------------------------------------------------------------------


def test_normalise_path_handles_windows_path() -> None:
    assert (
        normalise_path("C:\\Users\\msingh\\file.py")
        == "C:/Users/msingh/file.py"
    )


def test_normalise_path_passes_posix_through() -> None:
    assert normalise_path("src/main.py") == "src/main.py"


def test_normalise_path_handles_none_and_empty() -> None:
    assert normalise_path(None) == ""
    assert normalise_path("") == ""


# ---------------------------------------------------------------------------
# Decision.files_affected round-trip
# ---------------------------------------------------------------------------


def test_decision_files_affected_round_trips_as_list() -> None:
    d = Decision(title="t", files_affected=["a.py", "b.py"])
    serialised = d.to_dict()
    # Stored as JSON string for SQLite.
    assert isinstance(serialised["files_affected"], str)
    revived = Decision.from_dict(serialised)
    assert isinstance(revived.files_affected, list)
    assert revived.files_affected == ["a.py", "b.py"]


# ---------------------------------------------------------------------------
# Projects table — Fix 2
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_project_create_then_list_round_trips(
    tmp_path: Path,
) -> None:
    handlers = await _make_handlers(tmp_path)
    user_id = uuid.uuid4()

    created = await handlers.project_create(
        user_id=user_id,
        project_id="proj-x99",
        name="Project X99",
        cwd="/tmp/x99",
    )
    assert created["created"] is True
    assert created["project_id"] == "proj-x99"

    rows = await handlers.project_list(user_id=user_id)
    by_id = {r["project_id"]: r for r in rows}
    assert "proj-x99" in by_id
    assert by_id["proj-x99"]["name"] == "Project X99"
    assert by_id["proj-x99"]["cwd"] == "/tmp/x99"


@pytest.mark.asyncio
async def test_project_create_is_idempotent(tmp_path: Path) -> None:
    handlers = await _make_handlers(tmp_path)
    user_id = uuid.uuid4()

    first = await handlers.project_create(
        user_id=user_id, project_id="dup", name="First"
    )
    second = await handlers.project_create(
        user_id=user_id, project_id="dup", name="Second"
    )
    assert first["created"] is True
    assert second["created"] is False
    assert second["name"] == "Second"

    rows = await handlers.project_list(user_id=user_id)
    matches = [r for r in rows if r["project_id"] == "dup"]
    assert len(matches) == 1


@pytest.mark.asyncio
async def test_project_list_includes_default_when_table_empty(
    tmp_path: Path,
) -> None:
    handlers = await _make_handlers(tmp_path)
    rows = await handlers.project_list(user_id=uuid.uuid4())
    assert any(r["project_id"] == handlers.default_project_id for r in rows)


# ---------------------------------------------------------------------------
# Provenance edges on decision.create — Fix 7
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_decision_create_writes_provenance_edges(
    tmp_path: Path,
) -> None:
    handlers = await _make_handlers(tmp_path)
    before = await handlers.db.execute_raw(
        "SELECT COUNT(*) AS n FROM provenance_edges"
    )
    before_count = int(before[0]["n"])

    result = await handlers.decision_create(
        user_id=uuid.uuid4(),
        title="Switch to JWT",
        description="Why JWT",
        files_affected=["backend/auth.py", "backend/middleware.py"],
    )
    assert result["title"] == "Switch to JWT"
    assert result["files_affected"] == [
        "backend/auth.py",
        "backend/middleware.py",
    ]

    rows = await handlers.db.execute_raw(
        "SELECT target_id FROM provenance_edges "
        "WHERE source_type = 'decision' AND source_id = ? "
        "AND target_type = 'file'",
        (result["id"],),
    )
    targets = {str(r["target_id"]) for r in rows}
    assert targets == {"backend/auth.py", "backend/middleware.py"}

    after = await handlers.db.execute_raw(
        "SELECT COUNT(*) AS n FROM provenance_edges"
    )
    assert int(after[0]["n"]) == before_count + 2


@pytest.mark.asyncio
async def test_decision_create_provenance_normalises_windows_paths(
    tmp_path: Path,
) -> None:
    handlers = await _make_handlers(tmp_path)
    result = await handlers.decision_create(
        user_id=uuid.uuid4(),
        title="t",
        files_affected=["src\\auth\\jwt.py"],
    )
    assert result["files_affected"] == ["src/auth/jwt.py"]
    rows = await handlers.db.execute_raw(
        "SELECT target_id FROM provenance_edges "
        "WHERE source_type = 'decision' AND source_id = ? "
        "AND target_type = 'file'",
        (result["id"],),
    )
    assert {str(r["target_id"]) for r in rows} == {"src/auth/jwt.py"}


@pytest.mark.asyncio
async def test_decision_create_no_files_no_edges(tmp_path: Path) -> None:
    handlers = await _make_handlers(tmp_path)
    before = await handlers.db.execute_raw(
        "SELECT COUNT(*) AS n FROM provenance_edges"
    )
    await handlers.decision_create(
        user_id=uuid.uuid4(),
        title="metadata-only",
    )
    after = await handlers.db.execute_raw(
        "SELECT COUNT(*) AS n FROM provenance_edges"
    )
    assert int(after[0]["n"]) == int(before[0]["n"])


# ---------------------------------------------------------------------------
# v12 migration shape — Fix 6 subset
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_v12_migration_adds_projects_table(tmp_path: Path) -> None:
    db = SQLiteBackend(str(tmp_path / "v12.db"))
    await db.connect()
    await apply_migrations(db)
    rows = await db.execute_raw(
        "SELECT name FROM sqlite_master WHERE type = 'table' "
        "AND name = 'projects'"
    )
    assert len(rows) == 1


@pytest.mark.asyncio
async def test_v12_migration_adds_decision_columns(tmp_path: Path) -> None:
    db = SQLiteBackend(str(tmp_path / "v12.db"))
    await db.connect()
    await apply_migrations(db)
    rows = await db.execute_raw("PRAGMA table_info(decisions)")
    cols = {str(r["name"]) for r in rows}
    assert {"project_id", "files_affected", "confidence"}.issubset(cols)
