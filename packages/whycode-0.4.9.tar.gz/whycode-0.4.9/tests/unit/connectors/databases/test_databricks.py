"""Unit tests for ``backend.connectors.databases.databricks_connector``."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from backend.connectors.databases import databricks_connector as db_mod
from backend.connectors.databases.databricks_connector import (
    DatabricksConnector,
)


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _cm() -> _FakeCM:
    cm = _FakeCM()
    cm.set(
        "connector_databricks",
        "connection_string",
        '{"server_hostname": "h.cloud.databricks.com", '
        '"http_path": "/sql/1.0/x", "access_token": "dapi", '
        '"catalog": "main", "schema": "default"}',
    )
    return cm


def test_import_guard() -> None:
    with pytest.raises(RuntimeError, match=r"whycode\[databricks\]"):
        DatabricksConnector(_cm())


def test_class_attributes() -> None:
    assert DatabricksConnector.slug == "databricks"
    assert DatabricksConnector.display_name == "Databricks"


async def test_list_tables_with_mocked_driver() -> None:
    cursor = MagicMock()
    cursor.execute = MagicMock()
    cursor.fetchall = MagicMock(
        return_value=[
            ("main", "default", "orders", False),
            ("main", "default", "users", False),
        ]
    )
    cursor.close = MagicMock()
    conn = MagicMock()
    conn.cursor = MagicMock(return_value=cursor)
    conn.close = MagicMock()
    fake_driver = MagicMock()
    fake_driver.connect = MagicMock(return_value=conn)

    with (
        patch.object(db_mod, "_driver", fake_driver),
        patch.object(db_mod, "_AVAILABLE", True),
    ):
        tables = await DatabricksConnector(_cm()).list_tables()

    assert tables == ["orders", "users"]
    # Connection kwargs carried through from the JSON config
    kwargs = fake_driver.connect.call_args.kwargs
    assert kwargs["server_hostname"] == "h.cloud.databricks.com"
    assert kwargs["http_path"] == "/sql/1.0/x"
    assert kwargs["access_token"] == "dapi"


async def test_list_tables_empty_without_required_config() -> None:
    cm = _FakeCM()
    cm.set(
        "connector_databricks",
        "connection_string",
        '{"server_hostname": "h"}',  # missing http_path + access_token
    )
    fake_driver = MagicMock()
    with (
        patch.object(db_mod, "_driver", fake_driver),
        patch.object(db_mod, "_AVAILABLE", True),
    ):
        assert await DatabricksConnector(cm).list_tables() == []
    fake_driver.connect.assert_not_called()
