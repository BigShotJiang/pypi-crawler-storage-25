"""Unit tests for ``backend.connectors.databases.bigquery_connector``."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from backend.connectors.databases import bigquery_connector as bq_mod
from backend.connectors.databases.bigquery_connector import BigQueryConnector


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _cm() -> _FakeCM:
    cm = _FakeCM()
    cm.set(
        "connector_bigquery",
        "connection_string",
        json.dumps(
            {
                "service_account_json": json.dumps(
                    {"type": "service_account", "project_id": "p1"}
                ),
                "project": "p1",
                "dataset": "analytics",
            }
        ),
    )
    return cm


def test_import_guard() -> None:
    with pytest.raises(RuntimeError, match=r"whycode\[bigquery\]"):
        BigQueryConnector(_cm())


def test_class_attributes() -> None:
    assert BigQueryConnector.slug == "bigquery"
    assert BigQueryConnector.display_name == "Google BigQuery"


async def test_list_tables_uses_list_tables_api() -> None:
    table_a = MagicMock()
    table_a.table_id = "orders"
    table_b = MagicMock()
    table_b.table_id = "users"
    client = MagicMock()
    client.dataset = MagicMock(return_value="dataset_ref")
    client.list_tables = MagicMock(return_value=[table_a, table_b])
    client.close = MagicMock()

    fake_bq = MagicMock()
    fake_bq.Client = MagicMock(return_value=client)
    fake_creds = MagicMock()
    fake_creds.from_service_account_info = MagicMock(return_value="creds")

    with (
        patch.object(bq_mod, "_driver", fake_bq),
        patch.object(bq_mod, "_credentials_cls", fake_creds),
        patch.object(bq_mod, "_AVAILABLE", True),
    ):
        tables = await BigQueryConnector(_cm()).list_tables()

    assert tables == ["orders", "users"]
    client.list_tables.assert_called_once_with("dataset_ref")
    # Credentials path: from_service_account_info called with parsed dict
    call_arg = fake_creds.from_service_account_info.call_args.args[0]
    assert call_arg == {"type": "service_account", "project_id": "p1"}


async def test_list_tables_empty_without_required_config() -> None:
    cm = _FakeCM()
    cm.set(
        "connector_bigquery",
        "connection_string",
        '{"project": "p"}',  # missing service_account_json + dataset
    )
    with (
        patch.object(bq_mod, "_driver", MagicMock()),
        patch.object(bq_mod, "_AVAILABLE", True),
    ):
        assert await BigQueryConnector(cm).list_tables() == []
