"""Unit tests for ``backend.connectors.databases.dynamodb.DynamoDBConnector``."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from backend.connectors.databases import dynamodb as ddb_mod
from backend.connectors.databases.dynamodb import DynamoDBConnector


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _cm() -> _FakeCM:
    cm = _FakeCM()
    cm.set(
        "connector_dynamodb",
        "connection_string",
        '{"region": "us-east-1", "access_key": "AK", "secret_key": "S"}',
    )
    return cm


def test_import_guard() -> None:
    with pytest.raises(RuntimeError, match=r"whycode\[dynamodb\]"):
        DynamoDBConnector(_cm())


def test_class_attributes() -> None:
    assert DynamoDBConnector.slug == "dynamodb"


async def test_list_tables_with_mocked_session() -> None:
    client = MagicMock()
    client.list_tables = AsyncMock(
        return_value={"TableNames": ["users", "orders"]}
    )
    client_cm = MagicMock()
    client_cm.__aenter__ = AsyncMock(return_value=client)
    client_cm.__aexit__ = AsyncMock(return_value=False)

    session = MagicMock()
    session.client = MagicMock(return_value=client_cm)
    fake_driver = MagicMock()
    fake_driver.Session = MagicMock(return_value=session)

    with (
        patch.object(ddb_mod, "_driver", fake_driver),
        patch.object(ddb_mod, "_AVAILABLE", True),
    ):
        tables = await DynamoDBConnector(_cm()).list_tables()
    assert tables == ["users", "orders"]
    # Credentials passed correctly to Session
    session_kwargs = fake_driver.Session.call_args.kwargs
    assert session_kwargs["region_name"] == "us-east-1"
    assert session_kwargs["aws_access_key_id"] == "AK"


async def test_list_tables_empty_without_required_config() -> None:
    cm = _FakeCM()
    cm.set(
        "connector_dynamodb",
        "connection_string",
        '{"region": "us-east-1"}',
    )
    fake_driver = MagicMock()
    with (
        patch.object(ddb_mod, "_driver", fake_driver),
        patch.object(ddb_mod, "_AVAILABLE", True),
    ):
        assert await DynamoDBConnector(cm).list_tables() == []
    fake_driver.Session.assert_not_called()
