"""Unit tests for ``backend.connectors.external.teams.TeamsConnector``."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx

from backend.connectors.external.teams import TeamsConnector, _strip_tags


class _FakeCM:
    def __init__(self) -> None:
        self.store: dict[tuple[str, str], str] = {}

    def get(self, provider: str, key: str) -> str | None:
        return self.store.get((provider, key))

    def set(self, provider: str, key: str, value: str) -> None:
        self.store[(provider, key)] = value

    def delete(self, provider: str, key: str) -> None:
        self.store.pop((provider, key), None)


def _response(status_code: int = 200, body=None) -> MagicMock:  # type: ignore[no-untyped-def]
    r = MagicMock(spec=httpx.Response)
    r.status_code = status_code
    r.json.return_value = body
    return r


def _configured() -> TeamsConnector:
    cm = _FakeCM()
    cm.set("connector_teams", "access_token", "tok")
    return TeamsConnector(cm)


async def test_search_returns_chat_message_result_with_graph_path_id() -> None:
    body = {
        "value": [
            {
                "hitsContainers": [
                    {
                        "hits": [
                            {
                                "hitId": "h1",
                                "summary": "Hello <c0>launch</c0> team!",
                                "resource": {
                                    "@odata.type": "#microsoft.graph.chatMessage",
                                    "id": "msg-123",
                                    "chatId": "19:abc",
                                    "createdDateTime": "2026-04-17T09:00:00Z",
                                    "from": {"user": {"displayName": "Alice"}},
                                    "body": {
                                        "content": "<p>launch plan</p>",
                                        "contentType": "html",
                                    },
                                    "webUrl": "https://teams.microsoft.com/m/msg-123",
                                },
                            }
                        ]
                    }
                ]
            }
        ]
    }
    with patch.object(
        TeamsConnector,
        "_http_post",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        [r] = await _configured().search("launch", "p")

    assert r.item_id == "chats/19:abc/messages/msg-123"
    assert "[chat]" in r.title
    assert "Alice" in r.title
    # HTML tags + <c0> markers stripped from preview
    assert "launch" in r.summary
    assert "<c0>" not in r.summary
    assert "<p>" not in r.summary
    assert r.url == "https://teams.microsoft.com/m/msg-123"
    assert r.metadata["sender"] == "Alice"


async def test_search_handles_channel_message_resource() -> None:
    body = {
        "value": [
            {
                "hitsContainers": [
                    {
                        "hits": [
                            {
                                "hitId": "h2",
                                "summary": "Hi",
                                "resource": {
                                    "id": "msg-999",
                                    "channelIdentity": {
                                        "teamId": "T1",
                                        "channelId": "C1",
                                    },
                                    "from": {"user": {"displayName": "Bob"}},
                                },
                            }
                        ]
                    }
                ]
            }
        ]
    }
    with patch.object(
        TeamsConnector,
        "_http_post",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        [r] = await _configured().search("q", "p")
    assert r.item_id == "teams/T1/channels/C1/messages/msg-999"
    assert "[channel]" in r.title


async def test_search_skips_unknown_resource_shape() -> None:
    body = {
        "value": [
            {
                "hitsContainers": [
                    {
                        "hits": [
                            {"hitId": "h3", "resource": {"id": "orphan"}},
                        ]
                    }
                ]
            }
        ]
    }
    with patch.object(
        TeamsConnector,
        "_http_post",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        assert await _configured().search("q", "p") == []


async def test_search_empty_on_non_200() -> None:
    with patch.object(
        TeamsConnector,
        "_http_post",
        new=AsyncMock(return_value=_response(500)),
    ):
        assert await _configured().search("q", "p") == []


async def test_get_item_rejects_empty_id() -> None:
    assert await _configured().get_item("", "p") is None


async def test_get_item_rejects_traversal_path() -> None:
    assert await _configured().get_item("../../secret", "p") is None


async def test_get_item_returns_message_resource() -> None:
    body = {
        "id": "msg-77",
        "from": {"user": {"displayName": "Carol"}},
        "createdDateTime": "2026-04-17T10:00:00Z",
        "body": {"content": "<b>Hi there</b>", "contentType": "html"},
        "webUrl": "https://teams.microsoft.com/m/msg-77",
    }
    with patch.object(
        TeamsConnector,
        "_http_get",
        new=AsyncMock(return_value=_response(200, body)),
    ):
        r = await _configured().get_item("chats/19:xy/messages/msg-77", "p")
    assert r is not None
    assert r.title == "Teams message from Carol"
    assert "Hi there" in r.summary
    assert "<b>" not in r.summary


def test_strip_tags_collapses_nested_markers() -> None:
    assert _strip_tags("a <c0>b</c0> c") == "a b c"
    assert _strip_tags("<p>hello <b>world</b></p>") == "hello world"
    assert _strip_tags("no markup") == "no markup"
    # Malformed — tolerate gracefully, never crash
    assert "keep" in _strip_tags("<<bad>>keep")


def test_oauth_config_microsoft_shape() -> None:
    cfg = TeamsConnector.oauth_config
    assert cfg is not None
    assert cfg.authorize_url.endswith("/oauth2/v2.0/authorize")
    assert "offline_access" in cfg.scopes
    assert cfg.pkce is True
    assert cfg.client_id_env == "WHYCODE_MICROSOFT_CLIENT_ID"
