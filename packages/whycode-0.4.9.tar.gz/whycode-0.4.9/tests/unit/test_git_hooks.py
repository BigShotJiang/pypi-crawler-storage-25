"""Tests for backend.utils.git_hooks — git hook installation."""

from __future__ import annotations

import stat
import subprocess
import sys
from typing import TYPE_CHECKING

import pytest

from backend.utils.git_hooks import (
    GitHookError,
    install_hooks,
    uninstall_hooks,
    write_token_file,
)

if TYPE_CHECKING:
    from pathlib import Path


def _init_git(path: Path) -> None:
    subprocess.run(
        ["git", "init", "-q", "-b", "main", str(path)],
        check=True,
        capture_output=True,
    )


class TestInstallHooks:
    """install_hooks writes both hooks to .git/hooks with exec permissions."""

    def test_installs_both_hooks(self, tmp_path: Path) -> None:
        _init_git(tmp_path)
        written = install_hooks(
            tmp_path,
            server_url="http://127.0.0.1:8100",
            token_file="/tmp/fake-token",
        )
        assert len(written) == 2
        names = {p.name for p in written}
        assert names == {"post-commit", "post-merge"}
        for path in written:
            assert path.exists()
            content = path.read_text()
            assert "WhyCode" in content
            assert "http://127.0.0.1:8100" in content
            assert "/tmp/fake-token" in content

    @pytest.mark.skipif(sys.platform == "win32", reason="POSIX perms only")
    def test_hook_is_executable(self, tmp_path: Path) -> None:
        _init_git(tmp_path)
        written = install_hooks(
            tmp_path, server_url="http://x", token_file="/y"
        )
        for path in written:
            mode = path.stat().st_mode
            assert mode & stat.S_IXUSR, f"{path} is not owner-executable"

    def test_rejects_non_git_directory(self, tmp_path: Path) -> None:
        with pytest.raises(GitHookError, match="Not a git repository"):
            install_hooks(
                tmp_path, server_url="http://x", token_file="/y"
            )

    def test_overwrites_existing_hook(self, tmp_path: Path) -> None:
        _init_git(tmp_path)
        hook_path = tmp_path / ".git" / "hooks" / "post-commit"
        hook_path.write_text("# old hook\n")
        install_hooks(tmp_path, server_url="http://x", token_file="/y")
        assert "WhyCode" in hook_path.read_text()


class TestUninstallHooks:
    """uninstall_hooks removes only WhyCode-owned hooks."""

    def test_removes_whycode_hooks(self, tmp_path: Path) -> None:
        _init_git(tmp_path)
        install_hooks(tmp_path, server_url="http://x", token_file="/y")
        removed = uninstall_hooks(tmp_path)
        assert len(removed) == 2
        for path in removed:
            assert not path.exists()

    def test_preserves_non_whycode_hooks(self, tmp_path: Path) -> None:
        _init_git(tmp_path)
        hook_path = tmp_path / ".git" / "hooks" / "post-commit"
        hook_path.write_text("#!/bin/sh\n# user's own hook\n")
        removed = uninstall_hooks(tmp_path)
        assert removed == []
        assert hook_path.exists()


class TestTokenFile:
    """write_token_file creates a 0600 file with the token."""

    def test_writes_token(self, tmp_path: Path) -> None:
        path = tmp_path / "sub" / "token"
        write_token_file(path, "secret-value")
        assert path.read_text() == "secret-value"

    @pytest.mark.skipif(sys.platform == "win32", reason="POSIX perms only")
    def test_token_file_is_owner_only(self, tmp_path: Path) -> None:
        path = tmp_path / "token"
        write_token_file(path, "s")
        mode = path.stat().st_mode
        assert mode & stat.S_IROTH == 0
        assert mode & stat.S_IWOTH == 0
        assert mode & stat.S_IRGRP == 0
