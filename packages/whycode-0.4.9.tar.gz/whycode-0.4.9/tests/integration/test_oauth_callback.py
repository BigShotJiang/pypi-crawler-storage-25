"""Integration tests for the dashboard OAuth callback.

Exercises the ``/api/auth/oauth/{provider}/callback`` route end-to-end:

- Initiate ``/api/auth/oauth/google`` sets a per-provider state cookie.
- Callback with a missing or mismatched state cookie redirects the browser
  to ``/?oauth_error=oauth_csrf`` and does not establish a session.
- Callback with a provider error param redirects to
  ``/?oauth_error=oauth_denied``.
- The happy path exchanges the code with a mock provider, upserts the
  user, issues a JWT, sets the ``whycode_session`` cookie, and
  redirects to ``/?oauth=success``.
"""

from __future__ import annotations

import json
import sys
import textwrap
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import TYPE_CHECKING, Any
from urllib.parse import parse_qs, urlparse

import pytest
from fastapi.testclient import TestClient

from backend.config import load_config
from backend.main import create_app

if TYPE_CHECKING:
    from pathlib import Path


# ---------------------------------------------------------------------------
# Mock provider (mirrors tests/integration/test_oauth_flow.py layout)
# ---------------------------------------------------------------------------


class _MockProvider:
    def __init__(self) -> None:
        self.access_token = "MOCK-ACCESS-TOKEN"
        self.token_requests: list[dict[str, list[str]]] = []
        self.userinfo_email = "oauth-user@example.com"
        self.userinfo_sub = "provider-user-42"
        self.userinfo_name = "Mock User"


def _start_mock_server(state: _MockProvider) -> HTTPServer:
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            if parsed.path == "/userinfo":
                self._send_json(
                    200,
                    {
                        "sub": state.userinfo_sub,
                        "email": state.userinfo_email,
                        "name": state.userinfo_name,
                    },
                )
                return
            self.send_response(404)
            self.end_headers()

        def do_POST(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length).decode("utf-8") if length else ""
            params = parse_qs(body)
            if parsed.path == "/token":
                state.token_requests.append(params)
                self._send_json(
                    200,
                    {
                        "access_token": state.access_token,
                        "token_type": "Bearer",
                        "expires_in": 3600,
                    },
                )
                return
            self.send_response(404)
            self.end_headers()

        def log_message(self, format: str, *args: object) -> None:  # noqa: A002
            pass

        def _send_json(self, status: int, payload: dict[str, Any]) -> None:
            data = json.dumps(payload).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

    server = HTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server


# ---------------------------------------------------------------------------
# Fixtures: app + mock provider + seeded client credentials
# ---------------------------------------------------------------------------


def _write_test_config(tmp_path: Path, providers_path: Path) -> Path:
    content = textwrap.dedent(f"""\
        [server]
        mode = "solo"
        host = "127.0.0.1"
        port = 8100
        log_level = "warning"

        [database]
        backend = "sqlite"
        sqlite_path = "data/whycode.db"

        [vault]
        backend = "file"
        vault_path = "vault.enc"

        [providers]
        registry_path = "{providers_path.as_posix()}"

        [auth]
        jwt_expiry_hours = 24
        argon2_memory_cost_kb = 512
        argon2_time_cost = 1
        argon2_parallelism = 1
    """)
    config_file = tmp_path / "whycode.toml"
    config_file.write_text(content, encoding="utf-8")
    if sys.platform != "win32":
        config_file.chmod(0o600)
    return config_file


def _write_test_providers(tmp_path: Path, base_url: str) -> Path:
    # Redirect google + github to the mock provider so the callback can
    # complete the token exchange without touching the real internet.
    content = textwrap.dedent(f"""\
        [google]
        display_name = "Google"
        auth_type = "oauth2"
        authorize_url = "{base_url}/authorize"
        token_url = "{base_url}/token"
        userinfo_url = "{base_url}/userinfo"
        scopes = ["openid", "email", "profile"]
        use_for_identity = true
        use_for_service = true
        pkce = true
        client_id_env = "TEST_GOOGLE_CLIENT_ID"
        client_secret_env = "TEST_GOOGLE_CLIENT_SECRET"

        [github]
        display_name = "GitHub"
        auth_type = "oauth2"
        authorize_url = "{base_url}/authorize"
        token_url = "{base_url}/token"
        userinfo_url = "{base_url}/userinfo"
        scopes = ["read:user", "user:email"]
        use_for_identity = true
        use_for_service = true
        pkce = false
        client_id_env = "TEST_GITHUB_CLIENT_ID"
        client_secret_env = "TEST_GITHUB_CLIENT_SECRET"
    """)
    providers_file = tmp_path / "providers.toml"
    providers_file.write_text(content, encoding="utf-8")
    if sys.platform != "win32":
        providers_file.chmod(0o600)
    return providers_file


@pytest.fixture
def mock_provider() -> Any:
    state = _MockProvider()
    server = _start_mock_server(state)
    base = f"http://127.0.0.1:{server.server_address[1]}"
    try:
        yield state, base
    finally:
        server.shutdown()
        server.server_close()


@pytest.fixture
def oauth_app(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    mock_provider: Any,
) -> Any:
    _, base = mock_provider
    monkeypatch.setenv("WHYCODE_VAULT_PASSPHRASE", "test-passphrase")
    monkeypatch.setenv("TEST_GOOGLE_CLIENT_ID", "google-client-id")
    monkeypatch.setenv("TEST_GOOGLE_CLIENT_SECRET", "google-client-secret")
    monkeypatch.setenv("TEST_GITHUB_CLIENT_ID", "github-client-id")
    monkeypatch.setenv("TEST_GITHUB_CLIENT_SECRET", "github-client-secret")

    providers_file = _write_test_providers(tmp_path, base)
    config_file = _write_test_config(tmp_path, providers_file)
    config = load_config(config_file, project_root=tmp_path)
    app = create_app(config)
    # TestClient as a context manager fires the FastAPI lifespan so the
    # SQLite backend is connected before the handlers run. follow_redirects
    # is off because we need to inspect Location and Set-Cookie on the
    # 302 responses themselves.
    with TestClient(app, follow_redirects=False) as client:
        yield client


# ---------------------------------------------------------------------------
# /api/auth/oauth/{provider} — initiate sets state cookie
# ---------------------------------------------------------------------------


class TestInitiateSetsStateCookie:
    def test_google_initiate_sets_state_and_verifier_cookies(
        self, oauth_app: TestClient, mock_provider: Any
    ) -> None:
        _, base = mock_provider
        response = oauth_app.get("/api/auth/oauth/google")
        assert response.status_code == 302
        assert response.headers["location"].startswith(f"{base}/authorize?")

        cookies = response.headers.get_list("set-cookie")
        assert any(
            "whycode_oauth_state_google=" in c for c in cookies
        ), cookies
        # google has pkce = true so a verifier cookie must accompany state
        assert any(
            "whycode_oauth_verifier_google=" in c for c in cookies
        ), cookies

    def test_github_initiate_sets_state_but_no_verifier(
        self, oauth_app: TestClient
    ) -> None:
        response = oauth_app.get("/api/auth/oauth/github")
        assert response.status_code == 302
        cookies = response.headers.get_list("set-cookie")
        assert any(
            "whycode_oauth_state_github=" in c for c in cookies
        )
        # github test config has pkce = false
        assert not any(
            "whycode_oauth_verifier_github=" in c for c in cookies
        )


# ---------------------------------------------------------------------------
# /api/auth/oauth/{provider}/callback — failure modes
# ---------------------------------------------------------------------------


class TestCallbackRejectsWithoutState:
    def test_missing_state_cookie_redirects_with_csrf_error(
        self, oauth_app: TestClient
    ) -> None:
        # No prior /api/auth/oauth/google GET means no state cookie.
        response = oauth_app.get(
            "/api/auth/oauth/google/callback",
            params={"code": "any-code", "state": "any-state"},
        )
        assert response.status_code == 302
        assert (
            response.headers["location"]
            == "/?oauth_error=oauth_csrf&provider=google"
        )
        # No session cookie was issued.
        cookies = response.headers.get_list("set-cookie")
        assert not any("whycode_session=" in c for c in cookies)

    def test_state_mismatch_redirects_with_csrf_error(
        self, oauth_app: TestClient
    ) -> None:
        initiate = oauth_app.get("/api/auth/oauth/google")
        assert initiate.status_code == 302
        # Send a wrong state value; the per-provider cookie is attached
        # automatically by TestClient's cookie jar from the initiate.
        response = oauth_app.get(
            "/api/auth/oauth/google/callback",
            params={"code": "any", "state": "not-the-right-state"},
        )
        assert response.status_code == 302
        assert (
            response.headers["location"]
            == "/?oauth_error=oauth_csrf&provider=google"
        )

    def test_provider_error_redirects_with_denied(
        self, oauth_app: TestClient
    ) -> None:
        response = oauth_app.get(
            "/api/auth/oauth/google/callback",
            params={"error": "access_denied"},
        )
        assert response.status_code == 302
        assert (
            response.headers["location"]
            == "/?oauth_error=oauth_denied&provider=google"
        )

    def test_missing_code_redirects_with_invalid(
        self, oauth_app: TestClient
    ) -> None:
        response = oauth_app.get(
            "/api/auth/oauth/google/callback",
            params={"state": "nostate"},
        )
        assert response.status_code == 302
        assert (
            response.headers["location"]
            == "/?oauth_error=oauth_invalid&provider=google"
        )


# ---------------------------------------------------------------------------
# /api/auth/oauth/{provider}/callback — happy path
# ---------------------------------------------------------------------------


class TestCallbackHappyPath:
    def _extract_state_from_location(self, location: str) -> str:
        query = parse_qs(urlparse(location).query)
        return query["state"][0]

    def test_callback_sets_session_cookie_and_redirects_to_root(
        self, oauth_app: TestClient, mock_provider: Any
    ) -> None:
        mock_state, _ = mock_provider

        initiate = oauth_app.get("/api/auth/oauth/google")
        assert initiate.status_code == 302
        provider_state = self._extract_state_from_location(
            initiate.headers["location"]
        )

        response = oauth_app.get(
            "/api/auth/oauth/google/callback",
            params={"code": "MOCK-AUTH-CODE", "state": provider_state},
        )
        assert response.status_code == 302
        assert response.headers["location"] == "/?oauth=success"

        cookies = response.headers.get_list("set-cookie")
        session_cookie = next(
            (c for c in cookies if c.startswith("whycode_session=")),
            None,
        )
        assert session_cookie is not None, cookies
        lowered = session_cookie.lower()
        assert "httponly" in lowered
        # SameSite=Lax is required so the provider→callback redirect carries
        # the cookie on the same-site hop without exposing it cross-site.
        assert "samesite=lax" in lowered

        # The token request received client credentials and the expected
        # grant type (PKCE verifier is present because google has pkce=true).
        assert len(mock_state.token_requests) == 1
        token_req = mock_state.token_requests[0]
        assert token_req["grant_type"] == ["authorization_code"]
        assert token_req["code"] == ["MOCK-AUTH-CODE"]
        assert token_req["client_id"] == ["google-client-id"]
        assert "code_verifier" in token_req

    def test_callback_persists_user_and_reauthorizes_on_existing_login(
        self, oauth_app: TestClient, mock_provider: Any
    ) -> None:
        """Second sign-in for the same email reuses the existing user record."""
        mock_state, _ = mock_provider

        def _drive_flow() -> None:
            initiate = oauth_app.get("/api/auth/oauth/google")
            provider_state = parse_qs(
                urlparse(initiate.headers["location"]).query
            )["state"][0]
            callback = oauth_app.get(
                "/api/auth/oauth/google/callback",
                params={"code": "MOCK-AUTH-CODE", "state": provider_state},
            )
            assert callback.status_code == 302

        _drive_flow()
        # Clear cookies so the second flow starts fresh.
        oauth_app.cookies.clear()
        _drive_flow()

        # Both flows completed without duplicating the user row.
        import anyio

        async def count_users() -> int:
            db = oauth_app.app.state.db
            rows = await db.query(
                "users", {"email": mock_state.userinfo_email}
            )
            return len(rows)

        assert anyio.run(count_users) == 1


# ---------------------------------------------------------------------------
# /api/auth/me and /api/auth/logout — session identity + sign-out
# ---------------------------------------------------------------------------


def _complete_oauth_flow(client: TestClient) -> None:
    """Drive the google OAuth flow to completion so the TestClient holds a
    ``whycode_session`` cookie usable for subsequent authed calls."""
    initiate = client.get("/api/auth/oauth/google")
    provider_state = parse_qs(urlparse(initiate.headers["location"]).query)[
        "state"
    ][0]
    callback = client.get(
        "/api/auth/oauth/google/callback",
        params={"code": "MOCK-AUTH-CODE", "state": provider_state},
    )
    assert callback.status_code == 302
    assert "whycode_session" in client.cookies


class TestAuthMe:
    def test_me_unauthenticated_returns_401(
        self, oauth_app: TestClient
    ) -> None:
        response = oauth_app.get("/api/auth/me")
        assert response.status_code == 401

    def test_me_with_session_cookie_returns_identity(
        self, oauth_app: TestClient, mock_provider: Any
    ) -> None:
        mock_state, _ = mock_provider
        _complete_oauth_flow(oauth_app)

        response = oauth_app.get("/api/auth/me")
        assert response.status_code == 200
        body = response.json()
        assert body["email"] == mock_state.userinfo_email
        assert body["name"] == mock_state.userinfo_name
        assert body["provider"] == "google"
        # SEC-03: response must not leak secrets/hashes.
        forbidden = {"password_hash", "pat_hash", "token", "access_token"}
        assert forbidden.isdisjoint(body.keys())


class TestAuthLogout:
    def test_logout_without_session_returns_204(
        self, oauth_app: TestClient
    ) -> None:
        response = oauth_app.post("/api/auth/logout")
        assert response.status_code == 204

    def test_logout_clears_session_cookie_and_blocks_next_request(
        self, oauth_app: TestClient
    ) -> None:
        _complete_oauth_flow(oauth_app)
        # Baseline: the session cookie authenticates /api/auth/me.
        assert oauth_app.get("/api/auth/me").status_code == 200

        response = oauth_app.post("/api/auth/logout")
        assert response.status_code == 204
        cookies = response.headers.get_list("set-cookie")
        session_clear = next(
            (c for c in cookies if c.startswith("whycode_session=")),
            None,
        )
        assert session_clear is not None, cookies
        # Servers clear cookies by sending an empty value with an
        # expiration in the past; starlette emits Max-Age=0.
        lowered = session_clear.lower()
        assert "max-age=0" in lowered or "expires=" in lowered

        # After the Set-Cookie lands, the client's cookie jar drops the
        # session cookie, so /api/auth/me is 401 again.
        assert "whycode_session" not in oauth_app.cookies
        assert oauth_app.get("/api/auth/me").status_code == 401
