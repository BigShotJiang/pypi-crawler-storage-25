"""Team-mode setup tests (Workflow 10)."""

from __future__ import annotations

import asyncio
from pathlib import Path

import pytest
from click.testing import CliRunner

from backend.cli import cli
from backend.db.db_backend import SQLiteBackend


class TestTeamMode:
    def test_team_init_binds_0000_in_config(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Team init writes host = "0.0.0.0" in whycode.toml."""
        monkeypatch.setenv("WHYCODE_VAULT_PASSPHRASE", "qa")
        monkeypatch.setenv("WHYCODE_ADMIN_EMAIL", "admin@team.test")
        monkeypatch.setenv("WHYCODE_ADMIN_PASSWORD", "pw12345")
        monkeypatch.delenv("WHYCODE_PG_DSN", raising=False)
        monkeypatch.setattr(
            "backend.cli.DEFAULT_VAULT_DIR", tmp_path / ".whycode"
        )
        monkeypatch.setattr(
            "backend.cli.HOOK_TOKEN_FILE",
            tmp_path / ".whycode" / "hook_token",
        )
        result = CliRunner().invoke(
            cli,
            [
                "init",
                "--mode",
                "team",
                "--port",
                "8100",
                "--project-root",
                str(tmp_path),
                "--no-install-hooks",
                "--vault-backend",
                "file",
            ],
        )
        assert result.exit_code == 0, result.output
        body = (tmp_path / "whycode.toml").read_text(encoding="utf-8")
        assert 'host = "0.0.0.0"' in body

    def test_team_init_writes_team_setup_md(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Team init generates team-setup.md in the project root."""
        monkeypatch.setenv("WHYCODE_VAULT_PASSPHRASE", "qa")
        monkeypatch.setenv("WHYCODE_ADMIN_EMAIL", "admin@team.test")
        monkeypatch.setenv("WHYCODE_ADMIN_PASSWORD", "pw12345")
        monkeypatch.delenv("WHYCODE_PG_DSN", raising=False)
        monkeypatch.setattr(
            "backend.cli.DEFAULT_VAULT_DIR", tmp_path / ".whycode"
        )
        monkeypatch.setattr(
            "backend.cli.HOOK_TOKEN_FILE",
            tmp_path / ".whycode" / "hook_token",
        )
        CliRunner().invoke(
            cli,
            [
                "init",
                "--mode",
                "team",
                "--port",
                "9001",
                "--project-root",
                str(tmp_path),
                "--no-install-hooks",
                "--vault-backend",
                "file",
            ],
        )
        setup_md = tmp_path / "team-setup.md"
        assert setup_md.exists()
        text = setup_md.read_text(encoding="utf-8")
        assert ":9001" in text
        assert "whycode login --server" in text
        assert "whycode connect --server" in text

    def test_team_init_creates_admin_user(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """The team-mode admin account lands in the users table."""
        monkeypatch.setenv("HOME", str(tmp_path / "home"))
        (tmp_path / "home" / ".whycode").mkdir(parents=True, exist_ok=True)
        monkeypatch.setenv("WHYCODE_VAULT_PASSPHRASE", "qa")
        monkeypatch.setenv("WHYCODE_ADMIN_EMAIL", "lead@team.test")
        monkeypatch.setenv("WHYCODE_ADMIN_PASSWORD", "pw12345")
        monkeypatch.delenv("WHYCODE_PG_DSN", raising=False)
        monkeypatch.setattr(
            "backend.cli.DEFAULT_VAULT_DIR",
            tmp_path / "home" / ".whycode",
        )
        monkeypatch.setattr(
            "backend.cli.HOOK_TOKEN_FILE",
            tmp_path / "home" / ".whycode" / "hook_token",
        )
        result = CliRunner().invoke(
            cli,
            [
                "init",
                "--mode",
                "team",
                "--port",
                "8100",
                "--project-root",
                str(tmp_path),
                "--no-install-hooks",
                "--vault-backend",
                "file",
            ],
        )
        assert result.exit_code == 0, result.output

        async def _check() -> bool:
            db = SQLiteBackend(tmp_path / "data" / "whycode.db")
            await db.connect()
            try:
                rows = await db.query(
                    "users", where={"email": "lead@team.test"}
                )
                return len(rows) == 1
            finally:
                await db.close()

        assert asyncio.run(_check()) is True

    def test_solo_init_keeps_loopback(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Solo init writes host = "127.0.0.1"."""
        monkeypatch.setenv("WHYCODE_VAULT_PASSPHRASE", "qa")
        monkeypatch.setattr(
            "backend.cli.DEFAULT_VAULT_DIR", tmp_path / ".whycode"
        )
        monkeypatch.setattr(
            "backend.cli.HOOK_TOKEN_FILE",
            tmp_path / ".whycode" / "hook_token",
        )
        result = CliRunner().invoke(
            cli,
            [
                "init",
                "--port",
                "8100",
                "--project-root",
                str(tmp_path),
                "--no-install-hooks",
                "--vault-backend",
                "file",
            ],
        )
        assert result.exit_code == 0, result.output
        body = (tmp_path / "whycode.toml").read_text(encoding="utf-8")
        assert 'host = "127.0.0.1"' in body

    def test_login_with_server_url_prints_target(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """`whycode login --server` surfaces the team server URL."""
        result = CliRunner().invoke(
            cli,
            ["login", "--server", "http://team.example:9000"],
        )
        assert result.exit_code == 0
        assert "team.example:9000" in result.output
