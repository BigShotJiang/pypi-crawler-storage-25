"""Shared fixtures for the production-grade QA suite.

Every fixture here is function-scoped so tests run in isolation. No
fixture touches the real home directory, the real vault, Ollama, or
any network service — external dependencies are always mocked.
"""

from __future__ import annotations

import asyncio
import hashlib
import sys
import textwrap
import uuid
from pathlib import Path
from typing import TYPE_CHECKING, Any, AsyncGenerator, cast

import pytest
from fastapi.testclient import TestClient

from backend.config import load_config
from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.main import create_app
from backend.models import Decision, Session

if TYPE_CHECKING:
    from fastapi import FastAPI


# ---------------------------------------------------------------------------
# Config + app
# ---------------------------------------------------------------------------


def _write_qa_config(tmp_path: Path, *, port: int = 9999) -> Path:
    """Minimal whycode.toml for the QA fixture stack."""
    content = textwrap.dedent(
        f"""\
        [server]
        mode = "solo"
        host = "127.0.0.1"
        port = {port}
        log_level = "info"

        [database]
        backend = "sqlite"
        sqlite_path = "data/whycode.db"

        [vault]
        backend = "file"
        vault_path = "qa-vault.enc"

        [session]
        inactivity_timeout_minutes = 0

        [embeddings]
        backend = "local"
        vector_dim = 16

        [change_detection]
        backend = "file_watcher"

        [auth]
        jwt_expiry_hours = 24
        argon2_memory_cost_kb = 512
        argon2_time_cost = 1
        argon2_parallelism = 1
        """
    )
    target = tmp_path / "whycode.toml"
    target.write_text(content, encoding="utf-8")
    if sys.platform != "win32":
        target.chmod(0o600)
    return target


@pytest.fixture
async def db(tmp_path: Path) -> AsyncGenerator[SQLiteBackend, None]:
    """Fresh SQLite backend with all migrations applied."""
    backend = SQLiteBackend(tmp_path / "qa.db")
    await backend.connect()
    await apply_migrations(backend)
    yield backend
    await backend.close()


@pytest.fixture
def app(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> FastAPI:
    """Full FastAPI app configured for the QA suite."""
    monkeypatch.setenv("WHYCODE_VAULT_PASSPHRASE", "qa-test-passphrase")
    cfg_path = _write_qa_config(tmp_path)
    config = load_config(cfg_path, project_root=tmp_path)
    return create_app(config)


@pytest.fixture
def client(app: FastAPI) -> TestClient:
    """HTTP client speaking against the QA app."""
    return TestClient(app)


@pytest.fixture
def authed_client(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> TestClient:
    """Client pre-loaded with a registered user's bearer JWT."""
    monkeypatch.setenv("WHYCODE_VAULT_PASSPHRASE", "qa-test-passphrase")
    cfg_path = _write_qa_config(tmp_path)
    config = load_config(cfg_path, project_root=tmp_path)
    app = create_app(config)
    client = TestClient(app)
    with client:
        import anyio

        async def _register() -> str:
            user = await app.state.auth.register_email_user(
                "qa@test.com", "QA User", "qa-password-123"
            )
            return cast(str, app.state.auth.issue_jwt(user))

        jwt = anyio.run(_register)
    client.headers.update({"Authorization": f"Bearer {jwt}"})
    return client


# ---------------------------------------------------------------------------
# Domain fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def project() -> dict[str, Any]:
    """Test project metadata — project_id lives alongside stored rows."""
    return {"project_id": "qa-project", "name": "QA Project"}


@pytest.fixture
async def test_decision(
    db: SQLiteBackend, project: dict[str, Any]
) -> dict[str, Any]:
    """A seeded Decision row for reuse in tests."""
    d = Decision(
        title="Use Argon2id for password hashing",
        description="Security decision for QA fixtures.",
        tags=["auth", "security"],
        status="passed",
    )
    await db.insert("decisions", d.to_dict())
    return d.to_dict()


@pytest.fixture
async def test_session(
    db: SQLiteBackend, project: dict[str, Any]
) -> dict[str, Any]:
    """A seeded active session owned by the QA user."""
    s = Session(
        agent_name="qa-agent",
        status="active",
        project_id=project["project_id"],
        cwd=str(Path.cwd()),
    )
    await db.insert("sessions", s.to_dict())
    return s.to_dict()


# ---------------------------------------------------------------------------
# Environment fixtures (git/non-git directories, vaults, embedders)
# ---------------------------------------------------------------------------


@pytest.fixture
def git_repo(tmp_path: Path) -> Path:
    """A temporary git-initialised directory."""
    import subprocess

    repo = tmp_path / "repo"
    repo.mkdir()
    subprocess.run(
        ["git", "init", "-q"], cwd=repo, check=True, capture_output=True
    )
    subprocess.run(
        ["git", "-c", "user.email=qa@test.com",
         "-c", "user.name=QA", "commit",
         "--allow-empty", "-m", "init", "-q"],
        cwd=repo,
        check=True,
        capture_output=True,
    )
    return repo


@pytest.fixture
def non_git_dir(tmp_path: Path) -> Path:
    """A temporary directory with no .git — file-watcher territory."""
    d = tmp_path / "non-git"
    d.mkdir()
    return d


@pytest.fixture
def vault(tmp_path: Path) -> tuple[Path, str]:
    """A file-backed credential vault seeded with a test bearer token."""
    from backend.auth.credential_manager import CredentialManager
    from backend.config import CredentialConfig

    vault_dir = tmp_path / ".whycode"
    vault_dir.mkdir()
    vault_path = vault_dir / "vault.enc"
    token = "cl_solo_" + "x" * 32
    creds = CredentialManager(
        CredentialConfig(backend="file", vault_path=str(vault_path)),
        passphrase="qa-vault-passphrase",
    )
    creds.set("whycode", "solo_bearer_token", token)
    return vault_path, token


class _DeterministicEmbedder:
    """Hash-based 16-dim embedder — makes similarity tests deterministic."""

    async def embed_text(self, text: str) -> list[float]:
        digest = hashlib.sha256(text.encode("utf-8")).digest()
        return [b / 255.0 for b in digest[:16]]

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        return [await self.embed_text(t) for t in texts]


@pytest.fixture
def mock_embedder() -> _DeterministicEmbedder:
    """Deterministic embedder — same text always produces the same vector."""
    return _DeterministicEmbedder()


def _fake_uuid() -> uuid.UUID:
    """Generate a random UUID for test tool calls."""
    return uuid.uuid4()


# Expose for direct import by other test modules that want to assert
# against the same contract without importing the fixture directly.
__all__ = [
    "_DeterministicEmbedder",
    "_fake_uuid",
    "_write_qa_config",
]


# Silence asyncio cleanup chatter from uvicorn background tasks.
_ = asyncio
