"""Performance budgets across the active-context hot path.

Every test measures wall-clock latency against documented targets. A
failure here is a real regression — performance budgets are contract.
"""

from __future__ import annotations

import time
import uuid
from pathlib import Path
from typing import AsyncGenerator, cast

import pytest

from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.db.vector_store import SqliteVssStore
from backend.intelligence.ast_tracker import ASTTracker
from backend.intelligence.context_triage import ContextTriage
from backend.intelligence.decision_inferrer import DecisionInferrer
from backend.intelligence.semantic_search import SemanticSearch
from backend.mcp.tool_handlers import ToolHandlers
from backend.models import Decision, Session
from backend.utils.token_counter import count_tokens
from backend.verification.conflict_detector import ConflictDetector


async def _seed_heavy(handlers: ToolHandlers) -> None:
    """Insert 500 decisions and 100 completed sessions."""
    rows = []
    for i in range(500):
        d = Decision(
            title=f"Decision {i}",
            description=(
                f"Decision {i} covering authentication, caching, "
                "migrations, or retrieval."
            ),
            status="passed" if i % 3 == 0 else "unverified",
        )
        rows.append(d.to_dict())
    for row in rows:
        await handlers.db.insert("decisions", row)
    for i in range(100):
        s = Session(agent_name=f"agent-{i % 5}", status="completed")
        await handlers.db.insert("sessions", s.to_dict())


@pytest.fixture
async def perf_handlers(
    tmp_path: Path,
) -> AsyncGenerator[ToolHandlers, None]:
    """Handlers wired with all engines for performance measurements."""

    class _Fake:
        async def embed_text(self, text: str) -> list[float]:
            return [0.0] * 15 + [1.0]

        async def embed_batch(self, texts: list[str]) -> list[list[float]]:
            return [await self.embed_text(t) for t in texts]

    from backend.intelligence.embedder import OllamaEmbedder

    db = SQLiteBackend(tmp_path / "perf.db")
    await db.connect()
    await apply_migrations(db)
    store = SqliteVssStore(tmp_path / "perf-vec.db", dim=16)
    await store.connect()
    tracker = ASTTracker(db=db)
    yield ToolHandlers(
        db=db,
        semantic_search=SemanticSearch(
            embedder=cast(OllamaEmbedder, _Fake()),
            vector_store=store,
            db=db,
        ),
        context_triage=ContextTriage(count_tokens),
        conflict_detector=ConflictDetector(db),
        decision_inferrer=DecisionInferrer(db=db, ast_tracker=tracker),
    )
    await store.close()
    await db.close()


class TestHookLatencyBudgets:
    async def test_ensure_session_under_300ms(
        self, perf_handlers: ToolHandlers
    ) -> None:
        """hooks_ensure_session with 500 decisions + 100 sessions."""
        await _seed_heavy(perf_handlers)
        proj = Path(".").resolve()
        (proj / "whycode.toml").parent.mkdir(exist_ok=True, parents=True)
        start = time.perf_counter()
        await perf_handlers.hooks_ensure_session(
            user_id=uuid.uuid4(), cwd=str(proj), agent="perf"
        )
        elapsed = (time.perf_counter() - start) * 1000
        assert elapsed < 300, f"ensure-session {elapsed:.1f}ms"

    async def test_conflict_check_under_100ms(
        self, perf_handlers: ToolHandlers, tmp_path: Path
    ) -> None:
        """Ten concurrent sessions + 50 files per session stays under 100 ms."""
        assert perf_handlers.conflict_detector is not None
        for i in range(10):
            perf_handlers.conflict_detector.register_session(
                session_id=f"s-{i}",
                project_id="perf",
                agent_name=f"agent-{i}",
                files=[f"f-{i}-{j}.py" for j in range(50)],
            )
        start = time.perf_counter()
        await perf_handlers.conflict_detector.check_conflicts(
            "s-0", "perf"
        )
        elapsed = (time.perf_counter() - start) * 1000
        assert elapsed < 100, f"conflict check {elapsed:.1f}ms"

    async def test_import_check_under_150ms(
        self, perf_handlers: ToolHandlers
    ) -> None:
        """import-check with constraints extracted from verified decisions."""
        # Seed a handful of verified decisions with constraint language.
        for i in range(20):
            d = Decision(
                title=f"Layering {i}",
                description=f"module.{i} must not import forbidden.{i}.",
                status="passed",
            )
            await perf_handlers.db.insert("decisions", d.to_dict())
        start = time.perf_counter()
        await perf_handlers.hooks_import_check(
            user_id=uuid.uuid4(),
            content="\n".join([f"import x.{i}" for i in range(10)]),
            file_path="some/module/1.py",
            cwd=".",
        )
        elapsed = (time.perf_counter() - start) * 1000
        assert elapsed < 150, f"import check {elapsed:.1f}ms"


class TestBM25Performance:
    async def test_bm25_index_rebuild_under_200ms_for_500_items(
        self, tmp_path: Path
    ) -> None:
        """BM25Index.build completes under 200 ms on 500 decisions."""
        from backend.intelligence.semantic_search import BM25Index

        db = SQLiteBackend(tmp_path / "bm25.db")
        await db.connect()
        try:
            await apply_migrations(db)
            now = "2026-04-16T00:00:00+00:00"
            for i in range(500):
                await db.insert(
                    "decisions",
                    {
                        "id": f"d-{i}",
                        "title": f"Decision {i} on authentication",
                        "description": f"Body {i}",
                        "tags": "[]",
                        "status": "unverified",
                        "recorded_by_user_id": None,
                        "recorded_in_session_id": None,
                        "inference_status": "explicit",
                        "inference_confidence": 1.0,
                        "last_accessed_at": None,
                        "access_count": 0,
                        "staleness_score": 0.0,
                        "staleness_signals": "[]",
                        "superseded_by": None,
                        "supersedes": None,
                        "created_at": now,
                        "updated_at": now,
                    },
                )
            index = BM25Index(db, "perf")
            start = time.perf_counter()
            await index.build()
            elapsed = (time.perf_counter() - start) * 1000
            assert elapsed < 200, f"bm25 rebuild {elapsed:.1f}ms"
        finally:
            await db.close()
