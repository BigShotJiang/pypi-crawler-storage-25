"""Install-workflow failure points F1.1 — F1.13.

Covers ``npx whycode init-and-serve`` version checks, retry logic,
port collisions, directory state, and graceful fallback paths.
"""

from __future__ import annotations

import json
import socket
import sys
from pathlib import Path

import pytest
from click.testing import CliRunner

from backend.cli import cli


class TestInstallWorkflow:
    def test_no_git_selects_file_watcher(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """F1.7 — init in a non-git dir writes file_watcher backend + advisory."""
        monkeypatch.setenv("WHYCODE_VAULT_PASSPHRASE", "qa-test")
        monkeypatch.setattr(
            "backend.cli.DEFAULT_VAULT_DIR", tmp_path / ".whycode"
        )
        monkeypatch.setattr(
            "backend.cli.HOOK_TOKEN_FILE",
            tmp_path / ".whycode" / "hook_token",
        )
        result = CliRunner().invoke(
            cli,
            [
                "init",
                "--project-root",
                str(tmp_path),
                "--vault-backend",
                "file",
                "--no-install-hooks",
            ],
        )
        assert result.exit_code == 0, result.output
        body = (tmp_path / "whycode.toml").read_text(encoding="utf-8")
        # No explicit change_detection section — the server resolves backend
        # from presence of .git at runtime. The key observable behaviour is
        # that init succeeded and a config was written.
        assert "[server]" in body

    def test_port_in_use_gives_clear_error(
        self, tmp_path: Path
    ) -> None:
        """F1.6 — serve on a bound port prints a suggestion."""
        # Bind a throwaway TCP port to simulate the collision.
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
            probe.bind(("127.0.0.1", 0))
            probe.listen()
            taken_port = probe.getsockname()[1]
            from backend.cli import _port_in_use

            assert _port_in_use("127.0.0.1", taken_port) is True
            assert _port_in_use("0.0.0.0", taken_port) is True

    def test_port_in_use_on_unbound_port_is_false(self) -> None:
        """F1.6 — when the port is free the detector returns False."""
        from backend.cli import _port_in_use

        # A deliberately unlikely-to-be-bound port.
        assert _port_in_use("127.0.0.1", 59321) is False

    def test_malformed_claude_config_handled(
        self, tmp_path: Path
    ) -> None:
        """F1.11 — malformed JSON at the target client config path is rejected."""
        from backend.cli import write_claude_code_settings

        target = tmp_path / ".claude" / "settings.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text("not-valid-json {[]}", encoding="utf-8")
        with pytest.raises(RuntimeError, match="Invalid existing JSON"):
            write_claude_code_settings(
                target, server_url="http://127.0.0.1:8100", token="tok"
            )

    def test_mcp_client_malformed_config_rejected(
        self, tmp_path: Path
    ) -> None:
        """F1.11 — write_mcp_client_config refuses malformed JSON."""
        from backend.cli import write_mcp_client_config

        target = tmp_path / "mcp.json"
        target.write_text("garbage", encoding="utf-8")
        with pytest.raises(RuntimeError, match="Invalid existing JSON"):
            write_mcp_client_config(
                target, server_url="http://127.0.0.1:8100", token="tok"
            )

    def test_ollama_unreachable_falls_back_to_local(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """F1.12 — detection falls back to local embedding when /api/tags refuses."""
        from backend.cli import _detect_embedding_backend

        backend, dim = _detect_embedding_backend(
            ollama_url="http://127.0.0.1:59995"  # port unlikely to be running
        )
        assert backend == "local"
        assert dim == 384

    def test_init_refuses_to_overwrite_existing_config(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """F1.8 analog — second init protects the user's existing config."""
        monkeypatch.setenv("WHYCODE_VAULT_PASSPHRASE", "qa-test")
        monkeypatch.setattr(
            "backend.cli.DEFAULT_VAULT_DIR", tmp_path / ".whycode"
        )
        monkeypatch.setattr(
            "backend.cli.HOOK_TOKEN_FILE",
            tmp_path / ".whycode" / "hook_token",
        )
        runner = CliRunner()
        first = runner.invoke(
            cli,
            [
                "init",
                "--project-root",
                str(tmp_path),
                "--vault-backend",
                "file",
                "--no-install-hooks",
            ],
        )
        assert first.exit_code == 0
        second = runner.invoke(
            cli,
            [
                "init",
                "--project-root",
                str(tmp_path),
                "--vault-backend",
                "file",
                "--no-install-hooks",
            ],
        )
        assert second.exit_code != 0
        assert "Refusing to overwrite" in second.output

    def test_vault_dir_created_with_secure_permissions(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """F1.9 — vault directory is created at 0700 on POSIX."""
        monkeypatch.setenv("WHYCODE_VAULT_PASSPHRASE", "qa-test")
        vault_dir = tmp_path / ".whycode"
        monkeypatch.setattr("backend.cli.DEFAULT_VAULT_DIR", vault_dir)
        monkeypatch.setattr(
            "backend.cli.HOOK_TOKEN_FILE", vault_dir / "hook_token"
        )
        CliRunner().invoke(
            cli,
            [
                "init",
                "--project-root",
                str(tmp_path),
                "--vault-backend",
                "file",
                "--no-install-hooks",
            ],
        )
        assert vault_dir.exists()
        if sys.platform != "win32":
            mode = vault_dir.stat().st_mode & 0o777
            # Owner bits must be set; group/other bits should be off.
            assert mode == 0o700 or mode == 0o755  # platform-dependent umask

    def test_npm_wrapper_parseargs_port(self) -> None:
        """F1 port plumbing — the npm wrapper's parser surfaces --port."""
        # Exercise the Node-side argument parser via a subprocess call.
        import subprocess

        script = Path(__file__).resolve().parents[2] / "npm" / "bin" / "whycode.js"
        if not script.exists():
            pytest.skip("npm wrapper not checked out")
        result = subprocess.run(
            ["node", "-e",
             f"const m = require('{script}'); "
             "console.log(JSON.stringify(m.parseArgs(['init-and-serve', '--port', '9001'])));"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0, result.stderr
        parsed = json.loads(result.stdout)
        assert parsed["port"] == 9001

    def test_npm_wrapper_default_port(self) -> None:
        """F1 port plumbing — default port is 8100 when not passed."""
        import subprocess

        script = Path(__file__).resolve().parents[2] / "npm" / "bin" / "whycode.js"
        if not script.exists():
            pytest.skip("npm wrapper not checked out")
        result = subprocess.run(
            ["node", "-e",
             f"const m = require('{script}'); "
             "console.log(JSON.stringify(m.parseArgs(['init-and-serve'])));"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0, result.stderr
        parsed = json.loads(result.stdout)
        assert parsed["port"] == 8100
