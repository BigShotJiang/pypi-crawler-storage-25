"""Top-level pytest conftest.

Stubs the ``sentence_transformers`` package at collection time so
tests that import :mod:`backend.main` don't require the full
``torch`` + ``sentence-transformers`` wheel (~2 GB) to be installed
in the test venv. The stub produces 384-dim zero vectors — good
enough for unit-test code paths that only verify wiring.

Production installs pull ``sentence-transformers`` via the
package's required dependencies; the stub is test-only.
"""

from __future__ import annotations

import sys
import types
from typing import Any

import pytest


def _build_stub_module() -> types.ModuleType:
    """Construct a fresh ``sentence_transformers`` stub module.

    Used both at collection time (to let ``backend.main``'s module-level
    ``create_app()`` succeed) and by the autouse fixture below (to
    repair any damage ``test_embedder`` tests do to ``sys.modules``
    while asserting how the real import error surfaces).
    """
    stub = types.ModuleType("sentence_transformers")

    class _StubSentenceTransformer:
        def __init__(self, *_args: Any, **_kwargs: Any) -> None:
            self._dim = 384

        def encode(
            self, texts: Any, **_kwargs: Any
        ) -> list[float] | list[list[float]]:
            if isinstance(texts, str):
                return [0.0] * self._dim
            return [[0.0] * self._dim for _ in texts]

    stub.SentenceTransformer = _StubSentenceTransformer  # type: ignore[attr-defined]
    return stub


def _install_sentence_transformers_stub() -> None:
    if "sentence_transformers" in sys.modules and sys.modules[
        "sentence_transformers"
    ] is not None:
        return
    sys.modules["sentence_transformers"] = _build_stub_module()


_install_sentence_transformers_stub()


@pytest.fixture(autouse=True)
def _restore_sentence_transformers_stub() -> None:
    """Re-install the stub before each test.

    ``test_embedder.TestSentenceTransformerEmbedder::test_missing_library_*``
    clears ``sys.modules["sentence_transformers"]`` to force an
    ImportError, then restores what was there originally. A bug in
    that restore path (or monkeypatch undoing the restore first) can
    leave the stub missing, which then breaks every subsequent test
    that imports ``backend.main``. Re-installing here is cheap and
    idempotent.
    """
    entry = sys.modules.get("sentence_transformers")
    if entry is None or not hasattr(entry, "SentenceTransformer"):
        sys.modules["sentence_transformers"] = _build_stub_module()
