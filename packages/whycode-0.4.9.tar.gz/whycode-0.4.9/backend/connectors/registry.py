"""ConnectorRegistry — registration, parallel search, and health fan-out.

Every connector registered here is addressable by its slug. The registry
guarantees isolation: one connector timing out or raising during a
``search_all`` / ``health_all`` fan-out never prevents the others from
returning results. Per-call timeout defaults to
:data:`backend.connectors.base.CONNECTOR_TIMEOUT_SECONDS` but is overridable
(tests use a short timeout to exercise the real ``asyncio.wait_for`` path).

Security invariants:
- SEC-03: ``dashboard_status`` returns only metadata — never credentials,
  never tokens.
- SEC-02: connector errors are logged with slug + exception class, not with
  exception messages that could contain sensitive URL/credential material.
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

from backend.connectors.base import (
    CONNECTOR_TIMEOUT_SECONDS,
    AbstractConnector,
    AuthType,
    ConnectorHealth,
    ConnectorResult,
    ConnectorStatus,
)

if TYPE_CHECKING:
    from collections.abc import Iterable

logger = logging.getLogger(__name__)


class ConnectorRegistry:
    """In-memory registry of connectors addressable by ``slug``."""

    def __init__(self, *, timeout: float = float(CONNECTOR_TIMEOUT_SECONDS)) -> None:
        self._connectors: dict[str, AbstractConnector] = {}
        self._timeout = timeout
        # Metadata about connectors whose optional driver was not installed.
        # Populated by ``bootstrap.build_default_registry`` so the dashboard
        # can surface a "pip install whycode[<extra>]" hint instead of the
        # connector silently disappearing from the catalogue.
        self._unavailable_drivers: dict[str, dict[str, str]] = {}

    def record_unavailable_driver(
        self,
        *,
        slug: str,
        display_name: str,
        category: str,
        description: str,
        auth_type: str,
        install_hint: str,
    ) -> None:
        """Remember a connector whose driver is missing so the dashboard can list it."""
        self._unavailable_drivers[slug] = {
            "display_name": display_name,
            "category": category,
            "description": description,
            "auth_type": auth_type,
            "install_hint": install_hint,
        }

    # ------------------------------------------------------------------ #
    # Registration                                                       #
    # ------------------------------------------------------------------ #

    def register(self, connector: AbstractConnector) -> None:
        """Register a connector under its declared slug.

        If a connector with the same slug is already registered, it is
        replaced and a warning is logged — this usually indicates a bug in
        the registration loop rather than an intentional swap.
        """
        if connector.slug in self._connectors:
            logger.warning(
                "Connector slug %r already registered — replacing", connector.slug
            )
        self._connectors[connector.slug] = connector
        logger.info("Connector registered: %s", connector.slug)

    def get(self, slug: str) -> AbstractConnector | None:
        return self._connectors.get(slug)

    def all(self) -> list[AbstractConnector]:
        return list(self._connectors.values())

    def configured(self) -> list[AbstractConnector]:
        """Subset of registered connectors whose ``is_configured`` returns True.

        A connector whose ``is_configured`` raises is treated as unconfigured
        — the registry defers to the fail-closed default.
        """
        ready: list[AbstractConnector] = []
        for connector in self._connectors.values():
            try:
                if connector.is_configured():
                    ready.append(connector)
            except Exception:
                logger.warning(
                    "[%s] is_configured raised — treating as not configured",
                    connector.slug,
                    exc_info=True,
                )
        return ready

    # ------------------------------------------------------------------ #
    # Fan-out operations                                                 #
    # ------------------------------------------------------------------ #

    async def health_all(self) -> list[ConnectorHealth]:
        """Run ``health()`` on every connector in parallel.

        A connector whose ``health`` raises or times out is reported with
        ``ConnectorStatus.ERROR`` — the registry never propagates an
        exception to the caller.
        """
        connectors = list(self._connectors.values())
        if not connectors:
            return []

        async def safe_health(connector: AbstractConnector) -> ConnectorHealth:
            try:
                return await asyncio.wait_for(
                    connector.health(), timeout=self._timeout
                )
            except TimeoutError:
                return ConnectorHealth(
                    slug=connector.slug,
                    status=ConnectorStatus.ERROR,
                    message="health check timed out",
                    configured=_safe_is_configured(connector),
                )
            except Exception as exc:
                logger.warning(
                    "[%s] health raised %s",
                    connector.slug,
                    exc.__class__.__name__,
                    exc_info=True,
                )
                return ConnectorHealth(
                    slug=connector.slug,
                    status=ConnectorStatus.ERROR,
                    message=f"{exc.__class__.__name__}",
                    configured=_safe_is_configured(connector),
                )

        return await asyncio.gather(*(safe_health(c) for c in connectors))

    async def search_all(
        self,
        query: str,
        project_id: str,
        max_results_per_connector: int = 5,
        connector_slugs: Iterable[str] | None = None,
    ) -> list[ConnectorResult]:
        """Search every configured connector in parallel, ranked by score.

        ``connector_slugs`` (optional) restricts the fan-out to the named
        slugs. Unconfigured connectors are always excluded.
        """
        targets = self.configured()
        if connector_slugs is not None:
            allowed = set(connector_slugs)
            targets = [c for c in targets if c.slug in allowed]

        if not targets:
            return []

        async def safe_search(connector: AbstractConnector) -> list[ConnectorResult]:
            try:
                return await asyncio.wait_for(
                    connector.search(query, project_id, max_results_per_connector),
                    timeout=self._timeout,
                )
            except TimeoutError:
                logger.warning("[%s] search timed out", connector.slug)
                return []
            except Exception as exc:
                logger.warning(
                    "[%s] search raised %s",
                    connector.slug,
                    exc.__class__.__name__,
                    exc_info=True,
                )
                return []

        per_connector = await asyncio.gather(*(safe_search(c) for c in targets))
        merged: list[ConnectorResult] = [r for batch in per_connector for r in batch]
        merged.sort(key=lambda r: r.relevance_score, reverse=True)
        return merged

    # ------------------------------------------------------------------ #
    # Dashboard helper                                                   #
    # ------------------------------------------------------------------ #

    def dashboard_status(self) -> list[dict[str, object]]:
        """Metadata view used by the Connectors UI.

        Returns only the data needed to render connector cards — no tokens,
        no credentials, no internal state.
        """
        rows: list[dict[str, object]] = []
        for c in self._connectors.values():
            rows.append(
                {
                    "slug": c.slug,
                    "display_name": c.display_name,
                    "category": c.category.value,
                    "description": c.description,
                    "auth_type": c.auth_type.value,
                    "configured": _safe_is_configured(c),
                    # OAuth connectors redirect via the public /oauth/ prefix
                    # so the browser reaches the connect handler without an
                    # auth-middleware 401.
                    "connect_url": (
                        f"/api/connectors/oauth/{c.slug}/connect"
                        if c.auth_type == AuthType.OAUTH2
                        else None
                    ),
                    "credential_fields": c.get_credential_schema(),
                    "driver_available": True,
                }
            )
        # Connectors whose optional driver failed to import at bootstrap are
        # reported separately so the dashboard can surface "run pip install ..."
        # rather than silently hiding them.
        for slug, info in self._unavailable_drivers.items():
            rows.append(
                {
                    "slug": slug,
                    "display_name": info["display_name"],
                    "category": info["category"],
                    "description": info["description"],
                    "auth_type": info["auth_type"],
                    "configured": False,
                    "connect_url": None,
                    "credential_fields": [],
                    "driver_available": False,
                    "driver_install_hint": info["install_hint"],
                }
            )
        return rows


def _safe_is_configured(connector: AbstractConnector) -> bool:
    try:
        return connector.is_configured()
    except Exception:
        return False
