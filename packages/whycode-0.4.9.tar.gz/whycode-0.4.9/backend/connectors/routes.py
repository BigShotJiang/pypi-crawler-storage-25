"""HTTP routes for the connector marketplace.

Exposes six endpoints under ``/api/connectors``:

Public (reached before the auth middleware runs):
- ``GET  /oauth/{slug}/connect``   — initiate OAuth (state + PKCE cookie set)
- ``GET  /oauth/{slug}/callback``  — provider redirect, exchange code, store tokens

Auth-required (normal middleware applies):
- ``GET  /status``                  — dashboard metadata, never credentials
- ``GET  /{slug}/health``           — live connector health check
- ``POST /{slug}/setup``            — API-key / connection-string submit
- ``POST /{slug}/disconnect``       — clear stored credentials

CSRF defense: per-slug cookies ``whycode_connector_state_{slug}`` and
``whycode_connector_verifier_{slug}`` so two in-flight connector flows
in separate browser tabs do not stomp on each other (A-1 §1.8 risk #4).
"""

from __future__ import annotations

import hmac
import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

from backend.auth.oauth_manager import (
    ProviderConfig,
    build_auth_url,
    generate_pkce,
    generate_state,
)
from backend.connectors.base import AuthType
from backend.connectors.oauth_token_manager import ConnectorOAuthConfig

if TYPE_CHECKING:
    from backend.connectors.base import AbstractConnector
    from backend.connectors.oauth_token_manager import OAuthTokenManager
    from backend.connectors.registry import ConnectorRegistry

logger = logging.getLogger(__name__)


_COOKIE_MAX_AGE = 600
_COOKIE_PATH = "/api/connectors/oauth/"
_DASHBOARD_SUCCESS_URL = "/?connector_connected={slug}"
_DASHBOARD_ERROR_URL = "/?connector_error={reason}&connector={slug}"


@dataclass(frozen=True)
class ConnectorsRouterConfig:
    """Knobs a caller (usually ``main.py``) passes in at router construction.

    Keeping these as a frozen dataclass makes the factory contract explicit
    and avoids loading the full ``WhyCodeConfig`` inside this module.
    """

    server_host: str
    server_port: int
    cookie_secure: bool


def _state_cookie(slug: str) -> str:
    return f"whycode_connector_state_{slug}"


def _verifier_cookie(slug: str) -> str:
    return f"whycode_connector_verifier_{slug}"


def _redirect_uri(cfg: ConnectorsRouterConfig, slug: str) -> str:
    return (
        f"http://{cfg.server_host}:{cfg.server_port}"
        f"/api/connectors/oauth/{slug}/callback"
    )


def _error_redirect(slug: str, reason: str) -> RedirectResponse:
    resp = RedirectResponse(
        url=_DASHBOARD_ERROR_URL.format(reason=reason, slug=slug),
        status_code=302,
    )
    resp.delete_cookie(_state_cookie(slug), path=_COOKIE_PATH)
    resp.delete_cookie(_verifier_cookie(slug), path=_COOKIE_PATH)
    return resp


def _get_registry(request: Request) -> ConnectorRegistry | None:
    registry: ConnectorRegistry | None = getattr(
        request.app.state, "connector_registry", None
    )
    return registry


def _get_token_manager(request: Request) -> OAuthTokenManager | None:
    tm: OAuthTokenManager | None = getattr(
        request.app.state, "connector_oauth_manager", None
    )
    return tm


def create_connectors_router(
    cfg: ConnectorsRouterConfig,
) -> APIRouter:
    """Build the connector marketplace router.

    The connector registry and OAuth token manager are read from
    ``request.app.state`` at request time so the same router plays nicely
    with the rest of the FastAPI app's startup lifecycle.
    """
    router = APIRouter(prefix="/api/connectors", tags=["connectors"])

    # ------------------------------------------------------------------ #
    # GET /status                                                        #
    # ------------------------------------------------------------------ #
    @router.get("/status", include_in_schema=False)
    async def connectors_status(request: Request) -> Any:
        registry = _get_registry(request)
        if registry is None:
            return JSONResponse(
                status_code=503,
                content={"detail": "Connector registry not initialized"},
            )
        return {"connectors": registry.dashboard_status()}

    # ------------------------------------------------------------------ #
    # GET /{slug}/schema                                                 #
    # ------------------------------------------------------------------ #
    @router.get("/{slug}/schema", include_in_schema=False)
    async def connector_schema(slug: str, request: Request) -> Any:
        """Return the credential field schema for a single connector.

        The dashboard fetches this to render one labelled input per field
        (connection string, api key, region, …) instead of the old single
        JSON/DSN textarea.
        """
        registry = _get_registry(request)
        if registry is None:
            return JSONResponse(
                status_code=503, content={"detail": "registry unavailable"}
            )
        connector = registry.get(slug)
        if connector is None:
            return JSONResponse(
                status_code=404, content={"detail": f"Unknown connector: {slug}"}
            )
        return {
            "slug": slug,
            "display_name": connector.display_name,
            "auth_type": connector.auth_type.value,
            "description": connector.description,
            "credential_fields": connector.get_credential_schema(),
            "is_configured": _safe_bool(connector.is_configured),
        }

    # ------------------------------------------------------------------ #
    # GET /{slug}/health                                                 #
    # ------------------------------------------------------------------ #
    @router.get("/{slug}/health", include_in_schema=False)
    async def connector_health(slug: str, request: Request) -> Any:
        registry = _get_registry(request)
        if registry is None:
            return JSONResponse(status_code=503, content={"detail": "registry unavailable"})
        connector = registry.get(slug)
        if connector is None:
            return JSONResponse(status_code=404, content={"detail": f"Unknown connector: {slug}"})
        try:
            health = await connector.health()
        except Exception:
            logger.warning("[%s] health raised during route call", slug, exc_info=True)
            return JSONResponse(status_code=500, content={"detail": "health check failed"})
        return {
            "slug": health.slug,
            "status": health.status.value,
            "message": health.message,
            "configured": health.configured,
        }

    # ------------------------------------------------------------------ #
    # POST /{slug}/setup                                                 #
    # ------------------------------------------------------------------ #
    @router.post("/{slug}/setup", include_in_schema=False)
    async def connector_setup(slug: str, request: Request) -> Any:
        registry = _get_registry(request)
        if registry is None:
            return JSONResponse(status_code=503, content={"detail": "registry unavailable"})
        connector = registry.get(slug)
        if connector is None:
            return JSONResponse(status_code=404, content={"detail": f"Unknown connector: {slug}"})

        try:
            body = await request.json()
        except Exception:
            return JSONResponse(status_code=400, content={"detail": "Body must be JSON"})
        credentials = body.get("credentials") if isinstance(body, dict) else None
        if not isinstance(credentials, dict):
            return JSONResponse(
                status_code=400,
                content={"detail": "credentials must be an object"},
            )

        auth_type = connector.auth_type
        schema = list(getattr(connector, "credential_schema", []) or [])

        if auth_type == AuthType.OAUTH2:
            return JSONResponse(
                status_code=400,
                content={
                    "detail": (
                        f"{slug} uses {auth_type.value} auth — "
                        f"use /api/connectors/oauth/{slug}/connect instead"
                    )
                },
            )

        if schema:
            # Typed multi-field form: validate required fields and store each
            # under its own vault key so connectors can read them individually.
            missing: list[str] = []
            for field_def in schema:
                value = credentials.get(field_def.key)
                if field_def.required and (
                    not isinstance(value, str) or not value
                ):
                    missing.append(field_def.key)
            if missing:
                return JSONResponse(
                    status_code=400,
                    content={
                        "detail": f"Missing required fields: {', '.join(missing)}",
                        "missing": missing,
                    },
                )
            for field_def in schema:
                value = credentials.get(field_def.key)
                if isinstance(value, str) and value:
                    connector._set_credential(field_def.key, value)
        elif auth_type == AuthType.API_KEY:
            api_key = credentials.get("api_key")
            if not isinstance(api_key, str) or not api_key:
                return JSONResponse(
                    status_code=400, content={"detail": "api_key required"}
                )
            connector._set_credential("api_key", api_key)
        elif auth_type == AuthType.CONNECTION_STRING:
            conn_str = credentials.get("connection_string")
            if not isinstance(conn_str, str) or not conn_str:
                return JSONResponse(
                    status_code=400,
                    content={"detail": "connection_string required"},
                )
            connector._set_credential("connection_string", conn_str)
        else:
            return JSONResponse(
                status_code=400,
                content={
                    "detail": (
                        f"{slug} uses {auth_type.value} auth — "
                        f"use /api/connectors/oauth/{slug}/connect instead"
                    )
                },
            )

        try:
            health = await connector.health()
        except Exception:
            logger.warning("[%s] health raised after setup", slug, exc_info=True)
            return {"connected": True, "health": None}
        return {
            "connected": health.configured,
            "health": {
                "status": health.status.value,
                "message": health.message,
            },
        }

    # ------------------------------------------------------------------ #
    # POST /{slug}/disconnect                                            #
    # ------------------------------------------------------------------ #
    @router.post("/{slug}/disconnect", include_in_schema=False)
    async def connector_disconnect(slug: str, request: Request) -> Any:
        registry = _get_registry(request)
        token_manager = _get_token_manager(request)
        if registry is None:
            return JSONResponse(status_code=503, content={"detail": "registry unavailable"})
        connector = registry.get(slug)
        if connector is None:
            return JSONResponse(status_code=404, content={"detail": f"Unknown connector: {slug}"})

        for key in (
            "access_token",
            "refresh_token",
            "token_expiry",
            "api_key",
            "connection_string",
            "cloud_id",
            "site_url",
            "workspace_gid",
            "db_name",
        ):
            connector._delete_credential(key)

        # Token manager is a no-op for non-OAuth connectors; call anyway to
        # keep behavior uniform across auth types.
        if token_manager is not None:
            token_manager.clear_tokens(slug)

        return {"disconnected": True}

    # ------------------------------------------------------------------ #
    # GET /oauth/{slug}/connect                                          #
    # ------------------------------------------------------------------ #
    @router.get("/oauth/{slug}/connect", include_in_schema=False)
    async def oauth_connect(slug: str, request: Request) -> Any:
        registry = _get_registry(request)
        token_manager = _get_token_manager(request)
        if registry is None or token_manager is None:
            return JSONResponse(
                status_code=503, content={"detail": "connector framework unavailable"}
            )
        connector = registry.get(slug)
        if connector is None:
            return JSONResponse(
                status_code=404, content={"detail": f"Unknown connector: {slug}"}
            )
        if connector.auth_type != AuthType.OAUTH2:
            return JSONResponse(
                status_code=400,
                content={
                    "detail": f"{slug} does not use OAuth — POST to /setup instead"
                },
            )
        oauth_config = _connector_oauth_config(connector)
        if oauth_config is None:
            return JSONResponse(
                status_code=500,
                content={"detail": f"{slug} missing oauth_config"},
            )

        client_id, client_secret = token_manager.get_client_credentials(oauth_config)
        if not client_id or not client_secret:
            # The Connect button is a plain browser navigation, so returning
            # JSON here would render as raw text in the tab. Surface an HTML
            # setup guide with provider-specific steps instead.
            return HTMLResponse(
                content=_render_oauth_setup_guide(slug, connector, request),
                status_code=200,
            )

        state = generate_state()
        code_verifier: str | None = None
        code_challenge: str | None = None
        if oauth_config.pkce:
            code_verifier, code_challenge = generate_pkce()

        # build_auth_url reads name / authorize_url / scopes / pkce from a
        # ProviderConfig — build a lightweight one just for that call.
        provider_shim = ProviderConfig(
            name=slug,
            authorize_url=oauth_config.authorize_url,
            scopes=oauth_config.scopes,
            pkce=oauth_config.pkce,
        )
        url = build_auth_url(
            provider_shim,
            client_id,
            _redirect_uri(cfg, slug),
            state,
            code_challenge,
        )
        # Append connector-specific extra authorize params (e.g. Atlassian's
        # audience=api.atlassian.com, Google's access_type=offline).
        if oauth_config.extra_authorize_params:
            from urllib.parse import urlencode

            sep = "&" if "?" in url else "?"
            url = f"{url}{sep}{urlencode(oauth_config.extra_authorize_params)}"

        response = RedirectResponse(url=url, status_code=302)
        response.set_cookie(
            _state_cookie(slug),
            state,
            max_age=_COOKIE_MAX_AGE,
            httponly=True,
            samesite="lax",
            secure=cfg.cookie_secure,
            path=_COOKIE_PATH,
        )
        if code_verifier:
            response.set_cookie(
                _verifier_cookie(slug),
                code_verifier,
                max_age=_COOKIE_MAX_AGE,
                httponly=True,
                samesite="lax",
                secure=cfg.cookie_secure,
                path=_COOKIE_PATH,
            )
        return response

    # ------------------------------------------------------------------ #
    # GET /oauth/{slug}/callback                                         #
    # ------------------------------------------------------------------ #
    @router.get("/oauth/{slug}/callback", include_in_schema=False)
    async def oauth_callback(
        slug: str,
        request: Request,
        code: str | None = None,
        state: str | None = None,
        error: str | None = None,
    ) -> Any:
        if error:
            logger.info("[%s] OAuth provider error: %s", slug, error)
            return _error_redirect(slug, "oauth_denied")
        if not code or not state:
            return _error_redirect(slug, "oauth_invalid")

        stored_state = request.cookies.get(_state_cookie(slug))
        if not stored_state or not hmac.compare_digest(
            stored_state.encode(), state.encode()
        ):
            logger.warning("[%s] OAuth state mismatch — possible CSRF", slug)
            return _error_redirect(slug, "oauth_csrf")

        registry = _get_registry(request)
        token_manager = _get_token_manager(request)
        if registry is None or token_manager is None:
            return _error_redirect(slug, "oauth_unconfigured")
        connector = registry.get(slug)
        if connector is None:
            return _error_redirect(slug, "oauth_unknown_connector")
        oauth_config = _connector_oauth_config(connector)
        if oauth_config is None:
            return _error_redirect(slug, "oauth_unconfigured")

        code_verifier: str | None = None
        if oauth_config.pkce:
            code_verifier = request.cookies.get(_verifier_cookie(slug))
            if not code_verifier:
                return _error_redirect(slug, "oauth_pkce_missing")

        redirect_uri = _redirect_uri(cfg, slug)
        ok = await token_manager.exchange_code(
            oauth_config, code, redirect_uri, code_verifier
        )
        if not ok:
            return _error_redirect(slug, "oauth_exchange_failed")

        response = RedirectResponse(
            url=_DASHBOARD_SUCCESS_URL.format(slug=slug),
            status_code=302,
        )
        response.delete_cookie(_state_cookie(slug), path=_COOKIE_PATH)
        response.delete_cookie(_verifier_cookie(slug), path=_COOKIE_PATH)
        return response

    return router


# ---------------------------------------------------------------------- #
# Helpers                                                                #
# ---------------------------------------------------------------------- #


def _connector_oauth_config(
    connector: AbstractConnector,
) -> ConnectorOAuthConfig | None:
    """Safely pull the connector's ``oauth_config`` class attribute."""
    cfg = getattr(connector, "oauth_config", None)
    return cfg if isinstance(cfg, ConnectorOAuthConfig) else None


def _safe_bool(fn: Any) -> bool:
    """Call a zero-arg bool-returning method, converting exceptions to False."""
    try:
        return bool(fn())
    except Exception:
        return False


# ---------------------------------------------------------------------- #
# OAuth setup-guide HTML                                                 #
# ---------------------------------------------------------------------- #


# Provider-specific setup steps. The values are rendered into an HTML
# <ol> so each step may contain inline HTML (anchor tags, <code>, etc.).
_SETUP_GUIDES: dict[str, dict[str, object]] = {
    "gmail": {
        "steps": [
            "Go to <a href='https://console.cloud.google.com' target='_blank' rel='noopener'>console.cloud.google.com</a>.",
            "Create a project → APIs &amp; Services → Credentials.",
            "Click Create Credentials → OAuth 2.0 Client ID.",
            "Application type: Web application.",
            "Add redirect URI: <code>{callback}</code>.",
            "Copy Client ID and Client Secret.",
        ],
        "env_vars": "WHYCODE_GOOGLE_CLIENT_ID and WHYCODE_GOOGLE_CLIENT_SECRET",
    },
    "drive": {
        "steps": [
            "Go to <a href='https://console.cloud.google.com' target='_blank' rel='noopener'>console.cloud.google.com</a>.",
            "Enable Google Drive API under APIs &amp; Services → Library.",
            "Create OAuth 2.0 Client ID (same project as Gmail if you have one).",
            "Add redirect URI: <code>{callback}</code>.",
            "Copy Client ID and Client Secret.",
        ],
        "env_vars": "WHYCODE_GOOGLE_CLIENT_ID and WHYCODE_GOOGLE_CLIENT_SECRET",
    },
    "gcal": {
        "steps": [
            "Go to <a href='https://console.cloud.google.com' target='_blank' rel='noopener'>console.cloud.google.com</a>.",
            "Enable Google Calendar API under APIs &amp; Services → Library.",
            "Create OAuth 2.0 Client ID (same project as Gmail/Drive if you have one).",
            "Add redirect URI: <code>{callback}</code>.",
            "Copy Client ID and Client Secret.",
        ],
        "env_vars": "WHYCODE_GOOGLE_CLIENT_ID and WHYCODE_GOOGLE_CLIENT_SECRET",
    },
    "slack": {
        "steps": [
            "Go to <a href='https://api.slack.com/apps' target='_blank' rel='noopener'>api.slack.com/apps</a>.",
            "Click Create New App → From scratch.",
            "Go to OAuth &amp; Permissions.",
            "Add redirect URL: <code>{callback}</code>.",
            "Add scopes: channels:read, search:read, users:read.",
            "Copy Client ID and Client Secret from Basic Information.",
        ],
        "env_vars": "WHYCODE_SLACK_CLIENT_ID and WHYCODE_SLACK_CLIENT_SECRET",
    },
    "jira": {
        "steps": [
            "Go to <a href='https://developer.atlassian.com/console/myapps/' target='_blank' rel='noopener'>developer.atlassian.com/console/myapps</a>.",
            "Create app → OAuth 2.0 (3LO).",
            "Add callback URL: <code>{callback}</code>.",
            "Add scopes: read:jira-work, read:jira-user, offline_access.",
            "Copy Client ID and Client Secret.",
        ],
        "env_vars": "WHYCODE_JIRA_CLIENT_ID and WHYCODE_JIRA_CLIENT_SECRET",
    },
    "confluence": {
        "steps": [
            "Use the same Atlassian app as Jira — reuse those OAuth credentials.",
            "Add the <code>read:confluence-content.all</code> scope on the existing app.",
            "Callback URL: <code>{callback}</code>.",
        ],
        "env_vars": "Shares credentials with Jira (WHYCODE_JIRA_CLIENT_ID / WHYCODE_JIRA_CLIENT_SECRET)",
    },
    "linear": {
        "steps": [
            "Go to <a href='https://linear.app/settings/api' target='_blank' rel='noopener'>linear.app/settings/api</a>.",
            "Click Create new OAuth application.",
            "Add callback URL: <code>{callback}</code>.",
            "Copy Client ID and Client Secret.",
        ],
        "env_vars": "WHYCODE_LINEAR_CLIENT_ID and WHYCODE_LINEAR_CLIENT_SECRET",
    },
    "notion": {
        "steps": [
            "Go to <a href='https://www.notion.so/my-integrations' target='_blank' rel='noopener'>notion.so/my-integrations</a>.",
            "Click + New integration.",
            "Set integration type to Public.",
            "Add redirect URI: <code>{callback}</code>.",
            "Copy OAuth client_id and OAuth client_secret.",
        ],
        "env_vars": "WHYCODE_NOTION_CLIENT_ID and WHYCODE_NOTION_CLIENT_SECRET",
    },
    "github_issues": {
        "steps": [
            "Go to <a href='https://github.com/settings/applications/new' target='_blank' rel='noopener'>github.com/settings/applications/new</a>.",
            "Application name: WhyCode.",
            "Authorization callback URL: <code>{callback}</code>.",
            "Click Register application.",
            "Copy Client ID and generate Client Secret.",
        ],
        "env_vars": "WHYCODE_GITHUB_CLIENT_ID and WHYCODE_GITHUB_CLIENT_SECRET",
    },
    "asana": {
        "steps": [
            "Go to <a href='https://app.asana.com/0/my-apps' target='_blank' rel='noopener'>app.asana.com/0/my-apps</a>.",
            "Click + Create new app.",
            "Add redirect URI: <code>{callback}</code>.",
            "Copy Client ID and Client Secret.",
        ],
        "env_vars": "WHYCODE_ASANA_CLIENT_ID and WHYCODE_ASANA_CLIENT_SECRET",
    },
    "teams": {
        "steps": [
            "Go to <a href='https://portal.azure.com' target='_blank' rel='noopener'>portal.azure.com</a>.",
            "Azure Active Directory → App registrations → New registration.",
            "Add redirect URI: <code>{callback}</code>.",
            "API permissions → Add Microsoft Graph: Chat.Read, ChannelMessage.Read.All.",
            "Certificates &amp; secrets → New client secret.",
            "Copy Application (client) ID and client secret value.",
        ],
        "env_vars": "WHYCODE_TEAMS_CLIENT_ID and WHYCODE_TEAMS_CLIENT_SECRET",
    },
    "outlook": {
        "steps": [
            "Use the same Azure app as Teams — add the <code>Mail.Read</code> scope.",
            "Reuse the same client_id and client_secret.",
            "Callback URL: <code>{callback}</code>.",
        ],
        "env_vars": "Shares credentials with Teams (WHYCODE_TEAMS_CLIENT_ID / WHYCODE_TEAMS_CLIENT_SECRET)",
    },
}


def _render_oauth_setup_guide(
    slug: str, connector: AbstractConnector, request: Request,
) -> str:
    """Render the HTML page shown when client_id/secret are not yet stored.

    The page explains how to create the OAuth app in the provider's console
    and how to feed the resulting Client ID / Client Secret back into
    WhyCode. Served as HTML (not JSON) because the Connect button is a
    plain browser navigation.
    """
    display_name = connector.display_name
    base = str(request.base_url).rstrip("/")
    callback = f"{base}/api/connectors/oauth/{slug}/callback"

    guide = _SETUP_GUIDES.get(slug)
    if guide is None:
        steps = [
            f"Register an OAuth app in {display_name}'s developer console.",
            f"Set the redirect URI to <code>{callback}</code>.",
            "Copy Client ID and Client Secret.",
        ]
        env_vars = f"WHYCODE_{slug.upper()}_CLIENT_ID and WHYCODE_{slug.upper()}_CLIENT_SECRET"
    else:
        steps = [str(s).replace("{callback}", callback) for s in guide["steps"]]
        env_vars = str(guide["env_vars"])

    steps_html = "\n".join(f"    <li>{step}</li>" for step in steps)
    setup_command = (
        f"curl -X POST {base}/api/connectors/{slug}/setup \\\n"
        f"  -H 'Content-Type: application/json' \\\n"
        f"  -d '{{\"credentials\":{{\"client_id\":\"...\",\"client_secret\":\"...\"}}}}'"
    )

    return f"""<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Connect {display_name} — WhyCode</title>
  <style>
    body {{ font-family: system-ui, -apple-system, sans-serif; max-width: 680px;
           margin: 60px auto; padding: 0 20px; color: #111; line-height: 1.55; }}
    h1 {{ font-size: 22px; font-weight: 500; margin-bottom: 8px; }}
    h2 {{ font-size: 15px; font-weight: 600; margin: 24px 0 10px; color: #222; }}
    p {{ color: #555; margin-bottom: 16px; }}
    ol {{ padding-left: 22px; }}
    ol li {{ margin-bottom: 6px; }}
    code {{ background: #f4f4f4; padding: 2px 6px;
            border-radius: 4px; font-size: 12px; word-break: break-all; }}
    pre.cmd {{ background: #1e1e1e; color: #d4d4d4; padding: 12px 16px;
            border-radius: 8px; font-family: ui-monospace, monospace;
            font-size: 12px; overflow-x: auto; white-space: pre; }}
    .env {{ font-size: 12px; color: #666; }}
    .back {{ display: inline-block; margin-top: 24px; color: #0a5; text-decoration: none; }}
    .back:hover {{ text-decoration: underline; }}
  </style>
</head>
<body>
  <h1>Connect {display_name}</h1>
  <p>
    {display_name} uses OAuth. Create an OAuth application in the
    {display_name} developer console, then give WhyCode the resulting
    Client ID and Client Secret.
  </p>

  <h2>Setup steps</h2>
  <ol>
{steps_html}
  </ol>

  <h2>Give WhyCode the credentials</h2>
  <p>Either paste them into the dashboard's setup form, or POST to the setup endpoint:</p>
  <pre class="cmd">{setup_command}</pre>
  <p class="env">Or set environment variables {env_vars} and restart <code>whycode serve</code>.</p>

  <a class="back" href="/#connectors">← Back to dashboard</a>
</body>
</html>"""
