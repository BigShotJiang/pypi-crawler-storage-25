"""Shared constants for Microsoft Graph connectors (Teams, Outlook).

All Microsoft 365 connectors share:

- The ``common`` multi-tenant OAuth endpoints — no per-tenant discovery step
  is needed (unlike Atlassian's cloud_id dance).
- Identical client credentials (``WHYCODE_MICROSOFT_*``); Graph app
  registrations scope access via scopes, not via per-app client IDs.
- The same Graph v1 base URL for resource access.

This module only holds constants and a small config factory; there is no
runtime state here.
"""

from __future__ import annotations

from backend.connectors.oauth_token_manager import ConnectorOAuthConfig

MICROSOFT_AUTHORIZE_URL = (
    "https://login.microsoftonline.com/common/oauth2/v2.0/authorize"
)
MICROSOFT_TOKEN_URL = (
    "https://login.microsoftonline.com/common/oauth2/v2.0/token"
)
GRAPH_API_V1 = "https://graph.microsoft.com/v1.0"


def microsoft_oauth_config(
    slug: str, scopes: list[str]
) -> ConnectorOAuthConfig:
    """Build a ``ConnectorOAuthConfig`` for a Microsoft Graph connector."""
    return ConnectorOAuthConfig(
        slug=slug,
        authorize_url=MICROSOFT_AUTHORIZE_URL,
        token_url=MICROSOFT_TOKEN_URL,
        scopes=scopes,
        pkce=True,
        client_id_env="WHYCODE_MICROSOFT_CLIENT_ID",
        client_secret_env="WHYCODE_MICROSOFT_CLIENT_SECRET",
        extra_authorize_params={"prompt": "consent"},
    )
