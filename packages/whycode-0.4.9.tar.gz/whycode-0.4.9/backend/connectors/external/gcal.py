"""Google Calendar connector — link meetings and planning sessions to decisions.

Uses Calendar v3 REST API on the primary calendar. Only event title,
time range, and attendee count are exposed — attendee names and event
descriptions may contain PII and are withheld from ``search`` results.
``get_item`` returns the same safe fields.
"""

from __future__ import annotations

from typing import Any, ClassVar

from backend.connectors.base import (
    AuthType,
    ConnectorCategory,
    ConnectorResult,
)
from backend.connectors.external._base import ExternalConnector
from backend.connectors.oauth_token_manager import ConnectorOAuthConfig

_CAL_SCOPES: list[str] = [
    "https://www.googleapis.com/auth/calendar.readonly",
]

_API_ROOT = "https://www.googleapis.com/calendar/v3/calendars/primary"


class CalendarConnector(ExternalConnector):
    slug = "calendar"
    display_name = "Google Calendar"
    auth_type = AuthType.OAUTH2
    category = ConnectorCategory.COMMUNICATION
    oauth_scopes: ClassVar[list[str]] = _CAL_SCOPES
    description = "Link meetings and planning sessions to decisions"
    health_probe_url: ClassVar[str | None] = f"{_API_ROOT}?fields=id"

    oauth_config: ClassVar[ConnectorOAuthConfig | None] = ConnectorOAuthConfig(
        slug="calendar",
        authorize_url="https://accounts.google.com/o/oauth2/v2/auth",
        token_url="https://oauth2.googleapis.com/token",
        scopes=_CAL_SCOPES,
        pkce=True,
        client_id_env="WHYCODE_GOOGLE_CLIENT_ID",
        client_secret_env="WHYCODE_GOOGLE_CLIENT_SECRET",
        extra_authorize_params={"access_type": "offline", "prompt": "consent"},
    )

    async def search(
        self, query: str, project_id: str, max_results: int = 10
    ) -> list[ConnectorResult]:
        resp = await self._http_get(
            f"{_API_ROOT}/events",
            params={
                "q": query,
                "maxResults": max_results,
                "singleEvents": "true",
                "orderBy": "startTime",
            },
        )
        if resp is None or resp.status_code != 200:
            return []
        try:
            data = resp.json()
        except ValueError:
            return []
        items = data.get("items") or []
        return [_event_to_result(e) for e in items if isinstance(e, dict) and e.get("id")]

    async def get_item(
        self, item_id: str, project_id: str
    ) -> ConnectorResult | None:
        if not item_id or "/" in item_id or ".." in item_id:
            return None
        resp = await self._http_get(f"{_API_ROOT}/events/{item_id}")
        if resp is None or resp.status_code != 200:
            return None
        try:
            data = resp.json()
        except ValueError:
            return None
        if not data.get("id"):
            return None
        return _event_to_result(data)


def _event_to_result(data: dict[str, Any]) -> ConnectorResult:
    event_id = str(data.get("id", ""))
    title = str(data.get("summary") or "(untitled event)")
    start = _event_time(data.get("start"))
    end = _event_time(data.get("end"))
    attendees = data.get("attendees") or []
    attendee_count = len(attendees) if isinstance(attendees, list) else 0
    url = str(data.get("htmlLink") or "")
    summary_parts: list[str] = []
    if start:
        summary_parts.append(f"starts {start}")
    if end:
        summary_parts.append(f"ends {end}")
    if attendee_count:
        summary_parts.append(f"{attendee_count} attendees")
    return ConnectorResult(
        item_id=event_id,
        title=title,
        summary=" — ".join(summary_parts) if summary_parts else "no time info",
        url=url or None,
        connector_slug="calendar",
        item_type="event",
        metadata={"start": start, "end": end, "attendee_count": attendee_count},
    )


def _event_time(slot: Any) -> str:
    if not isinstance(slot, dict):
        return ""
    # Calendar returns either {"dateTime": "..."} or {"date": "..."} for all-day events
    return str(slot.get("dateTime") or slot.get("date") or "")
