"""Confluence connector — link wiki pages to decisions.

Uses the Atlassian cloud Confluence v1 REST API via the api.atlassian.com
proxy. Search uses CQL (Confluence Query Language). Page bodies are not
returned — only titles, URLs, space names, and modified timestamps.
"""

from __future__ import annotations

from typing import Any, ClassVar

from backend.connectors.base import (
    AuthType,
    ConnectorCategory,
    ConnectorHealth,
    ConnectorResult,
    ConnectorStatus,
)
from backend.connectors.external._atlassian import AtlassianConnector
from backend.connectors.oauth_token_manager import ConnectorOAuthConfig

_CONFLUENCE_SCOPES: list[str] = [
    "read:confluence-content.all",
    "offline_access",
]


def _confluence_api(cloud_id: str) -> str:
    return f"https://api.atlassian.com/ex/confluence/{cloud_id}/wiki/rest/api"


class ConfluenceConnector(AtlassianConnector):
    slug = "confluence"
    display_name = "Confluence"
    auth_type = AuthType.OAUTH2
    category = ConnectorCategory.CLOUD_STORAGE
    oauth_scopes: ClassVar[list[str]] = _CONFLUENCE_SCOPES
    description = "Search wiki pages and link documentation to decisions"

    oauth_config: ClassVar[ConnectorOAuthConfig | None] = ConnectorOAuthConfig(
        slug="confluence",
        authorize_url="https://auth.atlassian.com/authorize",
        token_url="https://auth.atlassian.com/oauth/token",
        scopes=_CONFLUENCE_SCOPES,
        pkce=True,
        client_id_env="WHYCODE_ATLASSIAN_CLIENT_ID",
        client_secret_env="WHYCODE_ATLASSIAN_CLIENT_SECRET",
        extra_authorize_params={
            "audience": "api.atlassian.com",
            "prompt": "consent",
        },
    )

    async def health(self) -> ConnectorHealth:
        if not self.is_configured():
            return ConnectorHealth(
                slug=self.slug,
                status=ConnectorStatus.NOT_CONFIGURED,
                message="connector not configured",
                configured=False,
            )
        site = await self._site_info()
        if site is None:
            return ConnectorHealth(
                slug=self.slug,
                status=ConnectorStatus.AUTH_EXPIRED,
                message="could not resolve Atlassian workspace",
                configured=True,
            )
        cid, _ = site
        # Hitting /space with limit=1 is cheap and confirms both token and
        # cloud_id are still valid.
        return await self._probe_health(
            f"{_confluence_api(cid)}/space?limit=1"
        )

    async def search(
        self, query: str, project_id: str, max_results: int = 10
    ) -> list[ConnectorResult]:
        site = await self._site_info()
        if site is None:
            return []
        cid, site_url = site
        # CQL text search — escape double-quotes to keep the CQL string well-formed.
        safe_query = query.replace('"', r"\"")
        resp = await self._http_get(
            f"{_confluence_api(cid)}/content/search",
            params={
                "cql": f'text ~ "{safe_query}"',
                "limit": max_results,
                "expand": "space,history.lastUpdated",
            },
        )
        if resp is None or resp.status_code != 200:
            return []
        try:
            data = resp.json()
        except ValueError:
            return []
        results = data.get("results") or []
        if not isinstance(results, list):
            return []
        return [
            _content_to_result(r, site_url)
            for r in results
            if isinstance(r, dict) and r.get("id")
        ]

    async def get_item(
        self, item_id: str, project_id: str
    ) -> ConnectorResult | None:
        if not item_id or "/" in item_id or ".." in item_id:
            return None
        site = await self._site_info()
        if site is None:
            return None
        cid, site_url = site
        resp = await self._http_get(
            f"{_confluence_api(cid)}/content/{item_id}",
            params={"expand": "space,history.lastUpdated"},
        )
        if resp is None or resp.status_code != 200:
            return None
        try:
            data = resp.json()
        except ValueError:
            return None
        if not data.get("id"):
            return None
        return _content_to_result(data, site_url)


def _content_to_result(
    data: dict[str, Any], site_url: str
) -> ConnectorResult:
    content_id = str(data.get("id") or "")
    title = str(data.get("title") or "(untitled)")
    space = data.get("space") or {}
    space_name = (
        str(space.get("name") or space.get("key") or "")
        if isinstance(space, dict)
        else ""
    )
    history = data.get("history") or {}
    last_updated = ""
    if isinstance(history, dict):
        last = history.get("lastUpdated") or {}
        if isinstance(last, dict):
            last_updated = str(last.get("when") or "")
    links = data.get("_links") or {}
    webui = ""
    if isinstance(links, dict):
        webui = str(links.get("webui") or "")
    url = f"{site_url}/wiki{webui}" if webui else None

    summary_parts: list[str] = []
    if space_name:
        summary_parts.append(f"space={space_name}")
    if last_updated:
        summary_parts.append(f"updated {last_updated}")
    return ConnectorResult(
        item_id=content_id,
        title=title,
        summary=" — ".join(summary_parts) if summary_parts else "",
        url=url,
        connector_slug="confluence",
        item_type="page",
        metadata={"space": space_name, "last_updated": last_updated},
    )
