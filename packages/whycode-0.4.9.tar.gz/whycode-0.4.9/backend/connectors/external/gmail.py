"""Gmail connector — search messages and link email threads to decisions.

Uses the Gmail v1 REST API. ``search`` fans out: one messages.list call to
collect IDs, then parallel messages.get calls (format=metadata) to read
``Subject``, ``From``, ``Date``, and the provider-supplied ``snippet``
field. The snippet is the only message-body content returned, and is
already truncated by the Gmail API.
"""

from __future__ import annotations

import asyncio
from typing import Any, ClassVar

from backend.connectors.base import (
    AuthType,
    ConnectorCategory,
    ConnectorResult,
)
from backend.connectors.external._base import ExternalConnector
from backend.connectors.oauth_token_manager import ConnectorOAuthConfig

_GMAIL_SCOPES: list[str] = [
    "https://www.googleapis.com/auth/gmail.readonly",
    "openid",
    "email",
]

_API_ROOT = "https://gmail.googleapis.com/gmail/v1/users/me"


class GmailConnector(ExternalConnector):
    slug = "gmail"
    display_name = "Gmail"
    auth_type = AuthType.OAUTH2
    category = ConnectorCategory.COMMUNICATION
    oauth_scopes: ClassVar[list[str]] = _GMAIL_SCOPES
    description = "Search emails and link threads to decisions"
    health_probe_url: ClassVar[str | None] = f"{_API_ROOT}/profile"

    oauth_config: ClassVar[ConnectorOAuthConfig | None] = ConnectorOAuthConfig(
        slug="gmail",
        authorize_url="https://accounts.google.com/o/oauth2/v2/auth",
        token_url="https://oauth2.googleapis.com/token",
        scopes=_GMAIL_SCOPES,
        pkce=True,
        client_id_env="WHYCODE_GOOGLE_CLIENT_ID",
        client_secret_env="WHYCODE_GOOGLE_CLIENT_SECRET",
        extra_authorize_params={"access_type": "offline", "prompt": "consent"},
    )

    async def search(
        self, query: str, project_id: str, max_results: int = 10
    ) -> list[ConnectorResult]:
        list_resp = await self._http_get(
            f"{_API_ROOT}/messages",
            params={"q": query, "maxResults": max_results},
        )
        if list_resp is None or list_resp.status_code != 200:
            return []
        try:
            data = list_resp.json()
        except ValueError:
            return []
        refs = data.get("messages") or []
        if not refs:
            return []
        fetched = await asyncio.gather(
            *(self._fetch_metadata(ref.get("id", "")) for ref in refs if ref.get("id"))
        )
        return [r for r in fetched if r is not None]

    async def get_item(
        self, item_id: str, project_id: str
    ) -> ConnectorResult | None:
        return await self._fetch_metadata(item_id)

    async def _fetch_metadata(self, message_id: str) -> ConnectorResult | None:
        if not message_id:
            return None
        resp = await self._http_get(
            f"{_API_ROOT}/messages/{message_id}",
            params={
                "format": "metadata",
                "metadataHeaders": ["Subject", "From", "Date"],
            },
        )
        if resp is None or resp.status_code != 200:
            return None
        try:
            data = resp.json()
        except ValueError:
            return None
        return _metadata_to_result(message_id, data)


def _metadata_to_result(
    message_id: str, data: dict[str, Any]
) -> ConnectorResult:
    payload = data.get("payload") or {}
    raw_headers = payload.get("headers") or []
    headers = {
        str(h.get("name", "")).lower(): str(h.get("value", ""))
        for h in raw_headers
        if isinstance(h, dict)
    }
    subject = headers.get("subject") or "(no subject)"
    sender = headers.get("from") or ""
    date = headers.get("date") or ""
    snippet = str(data.get("snippet") or "")
    summary = f"From: {sender} — {snippet}" if snippet else f"From: {sender}"
    return ConnectorResult(
        item_id=message_id,
        title=subject,
        summary=summary,
        url=f"https://mail.google.com/mail/u/0/#inbox/{message_id}",
        connector_slug="gmail",
        item_type="email",
        metadata={"sender": sender, "date": date},
    )
