"""Linear connector — link issues to decisions and code changes.

Linear has no REST API; all access is GraphQL at a single endpoint
(``POST https://api.linear.app/graphql``). This connector issues typed
queries and rides on :meth:`ExternalConnector._http_post` for auth/timeout.
``_graphql`` centralizes request construction and error mapping.
"""

from __future__ import annotations

from typing import Any, ClassVar

from backend.connectors.base import (
    AuthType,
    ConnectorCategory,
    ConnectorHealth,
    ConnectorResult,
    ConnectorStatus,
)
from backend.connectors.external._base import ExternalConnector
from backend.connectors.oauth_token_manager import ConnectorOAuthConfig

_LINEAR_SCOPES: list[str] = ["read"]
_GRAPHQL_URL = "https://api.linear.app/graphql"

_SEARCH_QUERY = """
query SearchIssues($query: String!, $first: Int!) {
  issueSearch(query: $query, first: $first) {
    nodes {
      id identifier title priority url
      state { name }
    }
  }
}
""".strip()

_ISSUE_QUERY = """
query GetIssue($id: String!) {
  issue(id: $id) {
    id identifier title priority url description
    state { name }
  }
}
""".strip()

_VIEWER_QUERY = "{ viewer { id name } }"


class LinearConnector(ExternalConnector):
    slug = "linear"
    display_name = "Linear"
    auth_type = AuthType.OAUTH2
    category = ConnectorCategory.PROJECT_MANAGEMENT
    oauth_scopes: ClassVar[list[str]] = _LINEAR_SCOPES
    description = "Link Linear issues to decisions and code changes"
    # Linear has no GET health endpoint — health() is overridden below.
    health_probe_url: ClassVar[str | None] = None

    oauth_config: ClassVar[ConnectorOAuthConfig | None] = ConnectorOAuthConfig(
        slug="linear",
        authorize_url="https://linear.app/oauth/authorize",
        token_url="https://api.linear.app/oauth/token",
        scopes=_LINEAR_SCOPES,
        pkce=True,
        client_id_env="WHYCODE_LINEAR_CLIENT_ID",
        client_secret_env="WHYCODE_LINEAR_CLIENT_SECRET",
    )

    async def health(self) -> ConnectorHealth:
        if not self.is_configured():
            return ConnectorHealth(
                slug=self.slug,
                status=ConnectorStatus.NOT_CONFIGURED,
                message="connector not configured",
                configured=False,
            )
        data = await self._graphql(_VIEWER_QUERY, None)
        if data is None:
            return ConnectorHealth(
                slug=self.slug,
                status=ConnectorStatus.ERROR,
                message="graphql viewer query failed",
                configured=True,
            )
        viewer = data.get("viewer")
        if not isinstance(viewer, dict) or not viewer.get("id"):
            return ConnectorHealth(
                slug=self.slug,
                status=ConnectorStatus.AUTH_EXPIRED,
                message="viewer query returned no user",
                configured=True,
            )
        return ConnectorHealth(
            slug=self.slug,
            status=ConnectorStatus.CONNECTED,
            message="ok",
            configured=True,
        )

    async def search(
        self, query: str, project_id: str, max_results: int = 10
    ) -> list[ConnectorResult]:
        data = await self._graphql(
            _SEARCH_QUERY, {"query": query, "first": max_results}
        )
        if data is None:
            return []
        search = data.get("issueSearch") or {}
        nodes = search.get("nodes") if isinstance(search, dict) else None
        if not isinstance(nodes, list):
            return []
        return [
            _issue_node_to_result(n) for n in nodes if isinstance(n, dict) and n.get("id")
        ]

    async def get_item(
        self, item_id: str, project_id: str
    ) -> ConnectorResult | None:
        if not item_id:
            return None
        data = await self._graphql(_ISSUE_QUERY, {"id": item_id})
        if data is None:
            return None
        issue = data.get("issue")
        if not isinstance(issue, dict) or not issue.get("id"):
            return None
        return _issue_node_to_result(issue)

    async def _graphql(
        self, query: str, variables: dict[str, Any] | None
    ) -> dict[str, Any] | None:
        """Run a GraphQL query and return the ``data`` payload or ``None``.

        Treats GraphQL ``errors`` in the response as a failure — we never
        partially trust a response that the server flagged as problematic.
        """
        resp = await self._http_post(
            _GRAPHQL_URL,
            json={
                "query": query,
                "variables": variables or {},
            },
        )
        if resp is None or resp.status_code != 200:
            return None
        try:
            payload = resp.json()
        except ValueError:
            return None
        if not isinstance(payload, dict):
            return None
        if payload.get("errors"):
            return None
        data = payload.get("data")
        return data if isinstance(data, dict) else None


def _issue_node_to_result(node: dict[str, Any]) -> ConnectorResult:
    identifier = str(node.get("identifier") or "")
    title = str(node.get("title") or "")
    state = node.get("state") or {}
    state_name = (
        str(state.get("name")) if isinstance(state, dict) else ""
    )
    priority = node.get("priority")
    url = str(node.get("url") or "")
    summary_parts: list[str] = []
    if state_name:
        summary_parts.append(f"state={state_name}")
    if priority is not None:
        summary_parts.append(f"priority={priority}")
    display_title = f"{identifier}: {title}" if identifier and title else (title or identifier)
    return ConnectorResult(
        item_id=str(node.get("id") or ""),
        title=display_title,
        summary=" ".join(summary_parts),
        url=url or None,
        connector_slug="linear",
        item_type="issue",
        metadata={
            "identifier": identifier,
            "state": state_name,
            "priority": priority if priority is not None else "",
        },
    )
