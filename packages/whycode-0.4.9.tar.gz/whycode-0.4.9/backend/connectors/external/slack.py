"""Slack connector — search messages and link discussions to decisions.

Uses the Slack Web API. Even on HTTP 200, Slack may return
``{"ok": false, "error": "..."}`` — this connector treats that as a
failure and returns ``[]`` / ``None``. Message text is surfaced but
capped by the ``ConnectorResult`` 500-char summary cap; attachments
and file shares are not exposed.

Item IDs encode the channel+timestamp pair (``{channel_id}:{ts}``)
needed to round-trip to a single message via ``conversations.replies``.
"""

from __future__ import annotations

from typing import Any, ClassVar

from backend.connectors.base import (
    AuthType,
    ConnectorCategory,
    ConnectorResult,
)
from backend.connectors.external._base import ExternalConnector
from backend.connectors.oauth_token_manager import ConnectorOAuthConfig

_SLACK_SCOPES: list[str] = ["channels:read", "search:read", "users:read"]


class SlackConnector(ExternalConnector):
    slug = "slack"
    display_name = "Slack"
    auth_type = AuthType.OAUTH2
    category = ConnectorCategory.COMMUNICATION
    oauth_scopes: ClassVar[list[str]] = _SLACK_SCOPES
    description = "Search Slack messages and link discussions to decisions"
    health_probe_url: ClassVar[str | None] = "https://slack.com/api/auth.test"

    oauth_config: ClassVar[ConnectorOAuthConfig | None] = ConnectorOAuthConfig(
        slug="slack",
        authorize_url="https://slack.com/oauth/v2/authorize",
        token_url="https://slack.com/api/oauth.v2.access",
        scopes=_SLACK_SCOPES,
        pkce=False,
        client_id_env="WHYCODE_SLACK_CLIENT_ID",
        client_secret_env="WHYCODE_SLACK_CLIENT_SECRET",
    )

    async def search(
        self, query: str, project_id: str, max_results: int = 10
    ) -> list[ConnectorResult]:
        resp = await self._http_get(
            "https://slack.com/api/search.messages",
            params={"query": query, "count": max_results},
        )
        if resp is None or resp.status_code != 200:
            return []
        try:
            data = resp.json()
        except ValueError:
            return []
        if not data.get("ok"):
            return []
        messages = (data.get("messages") or {}).get("matches") or []
        if not isinstance(messages, list):
            return []
        return [
            _message_match_to_result(m) for m in messages if isinstance(m, dict)
        ]

    async def get_item(
        self, item_id: str, project_id: str
    ) -> ConnectorResult | None:
        if not item_id or ":" not in item_id:
            return None
        channel, ts = item_id.split(":", 1)
        if not channel or not ts:
            return None
        resp = await self._http_get(
            "https://slack.com/api/conversations.replies",
            params={"channel": channel, "ts": ts, "limit": 1},
        )
        if resp is None or resp.status_code != 200:
            return None
        try:
            data = resp.json()
        except ValueError:
            return None
        if not data.get("ok"):
            return None
        messages = data.get("messages") or []
        if not isinstance(messages, list) or not messages:
            return None
        root = messages[0]
        if not isinstance(root, dict):
            return None
        return _message_to_result(channel, root)


def _message_match_to_result(match: dict[str, Any]) -> ConnectorResult:
    channel = match.get("channel") or {}
    channel_id = (
        str(channel.get("id") or "") if isinstance(channel, dict) else ""
    )
    channel_name = (
        str(channel.get("name") or "")
        if isinstance(channel, dict)
        else ""
    )
    ts = str(match.get("ts") or "")
    user = str(match.get("username") or match.get("user") or "")
    text = str(match.get("text") or "")
    permalink = str(match.get("permalink") or "")
    title = f"#{channel_name}" if channel_name else "(direct message)"
    if user:
        title = f"{title} — {user}"
    return ConnectorResult(
        item_id=f"{channel_id}:{ts}" if channel_id and ts else ts,
        title=title,
        summary=text,
        url=permalink or None,
        connector_slug="slack",
        item_type="message",
        metadata={"channel": channel_name, "user": user, "ts": ts},
    )


def _message_to_result(
    channel_id: str, msg: dict[str, Any]
) -> ConnectorResult:
    ts = str(msg.get("ts") or "")
    user = str(msg.get("user") or "")
    text = str(msg.get("text") or "")
    return ConnectorResult(
        item_id=f"{channel_id}:{ts}",
        title=f"slack message {ts}",
        summary=text,
        url=None,
        connector_slug="slack",
        item_type="message",
        metadata={"user": user, "ts": ts, "channel_id": channel_id},
    )
