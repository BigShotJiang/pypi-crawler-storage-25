"""Google BigQuery connector via ``google-cloud-bigquery`` (sync driver).

Expects JSON in ``connection_string``::

    {"service_account_json": "<stringified JSON blob>",
     "project": "my-gcp-project",
     "dataset": "analytics"}

The service-account JSON is parsed client-side and passed to
``Credentials.from_service_account_info`` — no file on disk, no env var
leak. All blocking driver calls go through :func:`run_sync`.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from backend.connectors.base import CredentialField
from backend.connectors.databases._base import (
    AbstractDatabaseConnector,
    parse_json_config,
    require_driver,
    run_sync,
)

logger = logging.getLogger(__name__)

try:
    from google.cloud import bigquery as _bq
    from google.oauth2.service_account import Credentials as _Credentials

    _driver: Any = _bq
    _credentials_cls: Any = _Credentials
    _AVAILABLE = True
except ImportError:
    _driver = None
    _credentials_cls = None
    _AVAILABLE = False


class BigQueryConnector(AbstractDatabaseConnector):
    slug = "bigquery"
    display_name = "Google BigQuery"
    description = "Query BigQuery datasets (read-only by default)"
    credential_schema = [
        CredentialField(
            key="project_id",
            label="GCP project ID",
            placeholder="my-gcp-project-123",
            help_text="Found in the Google Cloud Console header.",
        ),
        CredentialField(
            key="dataset",
            label="Dataset",
            placeholder="my_dataset",
            help_text="The BigQuery dataset to query.",
        ),
        CredentialField(
            key="connection_string",
            label="Service account JSON",
            placeholder='{"type":"service_account","project_id":"...","private_key":"..."}',
            type="password",
            help_text=(
                "Paste the contents of your service account JSON key file. "
                "Create one at: IAM & Admin → Service Accounts → Keys → Add Key."
            ),
        ),
    ]

    def __init__(self, credential_manager, db=None):  # type: ignore[no-untyped-def]
        require_driver(_driver, self.slug, "bigquery")
        super().__init__(credential_manager, db)

    def _config(self) -> dict[str, Any]:
        return parse_json_config(self._get_credential("connection_string"))

    def _has_connection_params(self) -> bool:
        cfg = self._config()
        return bool(
            cfg.get("service_account_json")
            and cfg.get("project")
            and cfg.get("dataset")
        )

    def _build_client(self) -> Any:
        """Construct a BigQuery client from the vault config. Sync — caller wraps."""
        cfg = self._config()
        raw_sa = cfg["service_account_json"]
        try:
            sa_info = (
                json.loads(raw_sa) if isinstance(raw_sa, str) else raw_sa
            )
        except (ValueError, TypeError):
            return None
        if not isinstance(sa_info, dict):
            return None
        creds = _credentials_cls.from_service_account_info(sa_info)
        return _driver.Client(credentials=creds, project=cfg["project"])

    async def test_connection(self) -> bool:
        if not self._has_connection_params():
            return False

        def _sync() -> bool:
            client = self._build_client()
            if client is None:
                return False
            try:
                job = client.query("SELECT 1 AS ok")
                rows = list(job.result())
                return bool(rows and rows[0].ok == 1)
            finally:
                client.close()

        try:
            return await run_sync(_sync)
        except Exception:
            return False

    async def list_tables(self) -> list[str]:
        if not self._has_connection_params():
            return []
        cfg = self._config()

        def _sync() -> list[str]:
            client = self._build_client()
            if client is None:
                return []
            try:
                dataset_ref = client.dataset(cfg["dataset"])
                return [
                    str(t.table_id) for t in client.list_tables(dataset_ref)
                ]
            finally:
                client.close()

        try:
            return await run_sync(_sync)
        except Exception:
            return []

    async def describe_table(self, table: str) -> dict[str, Any]:
        if not await self._validate_table(table):
            return {"columns": []}
        cfg = self._config()

        def _sync() -> list[dict[str, str]]:
            client = self._build_client()
            if client is None:
                return []
            try:
                table_ref = client.dataset(cfg["dataset"]).table(table)
                tbl = client.get_table(table_ref)
                return [
                    {"name": str(f.name), "type": str(f.field_type)}
                    for f in (tbl.schema or [])
                ]
            finally:
                client.close()

        try:
            columns = await run_sync(_sync)
            return {"columns": columns}
        except Exception:
            return {"columns": []}

    async def sample_rows(
        self, table: str, limit: int = 5
    ) -> list[dict[str, Any]]:
        if not isinstance(limit, int) or limit <= 0 or limit > 1000:
            return []
        if not await self._validate_table(table):
            return []
        cfg = self._config()
        project = cfg["project"]
        dataset = cfg["dataset"]

        def _sync() -> list[dict[str, Any]]:
            client = self._build_client()
            if client is None:
                return []
            try:
                # Table name is whitelist-validated. Backtick-quoted per
                # standard BigQuery SQL identifier escaping.
                sql = (
                    f"SELECT * FROM `{project}.{dataset}.{table}` "
                    f"LIMIT {int(limit)}"
                )
                job = client.query(sql)
                return [dict(row) for row in job.result()]
            finally:
                client.close()

        try:
            return await run_sync(_sync)
        except Exception:
            return []
