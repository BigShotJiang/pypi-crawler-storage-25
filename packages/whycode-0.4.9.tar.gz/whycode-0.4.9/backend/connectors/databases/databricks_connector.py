"""Databricks connector via ``databricks-sql-connector`` (sync driver).

All blocking driver calls go through :func:`run_sync`. Expects JSON in
``connection_string``::

    {"server_hostname": "dbc-xxx.cloud.databricks.com",
     "http_path": "/sql/1.0/warehouses/abc",
     "access_token": "dapi...",
     "catalog": "main",
     "schema": "default"}
"""

from __future__ import annotations

import logging
from typing import Any

from backend.connectors.base import CredentialField
from backend.connectors.databases._base import (
    AbstractDatabaseConnector,
    parse_json_config,
    require_driver,
    run_sync,
)

logger = logging.getLogger(__name__)

try:
    from databricks import sql as _driver
    _AVAILABLE = True
except ImportError:
    _driver = None
    _AVAILABLE = False


class DatabricksConnector(AbstractDatabaseConnector):
    slug = "databricks"
    display_name = "Databricks"
    description = "Query Databricks SQL warehouses and Delta Lake tables"
    credential_schema = [
        CredentialField(
            key="server_hostname",
            label="Server hostname",
            placeholder="adb-1234567890.12.azuredatabricks.net",
            help_text="Cluster → Advanced Options → JDBC/ODBC.",
        ),
        CredentialField(
            key="http_path",
            label="HTTP path",
            placeholder="/sql/1.0/warehouses/abc123def456",
            help_text="SQL Warehouse → Connection Details.",
        ),
        CredentialField(
            key="api_key",
            label="Personal access token",
            placeholder="dapiXXXXXXXXXXXXXX",
            type="password",
            help_text="Settings → Developer → Access Tokens → Generate new token.",
        ),
        CredentialField(
            key="catalog",
            label="Catalog (optional)",
            placeholder="main",
            required=False,
            help_text="Leave blank to use the default catalog.",
        ),
        CredentialField(
            key="schema",
            label="Schema (optional)",
            placeholder="default",
            required=False,
            help_text="Leave blank to use the default schema.",
        ),
    ]

    def __init__(self, credential_manager, db=None):  # type: ignore[no-untyped-def]
        require_driver(_driver, self.slug, "databricks")
        super().__init__(credential_manager, db)

    def _config(self) -> dict[str, Any]:
        return parse_json_config(self._get_credential("connection_string"))

    def _has_connection_params(self) -> bool:
        cfg = self._config()
        return bool(
            cfg.get("server_hostname")
            and cfg.get("http_path")
            and cfg.get("access_token")
        )

    def _qualified(self, table: str) -> str:
        cfg = self._config()
        catalog = cfg.get("catalog") or "hive_metastore"
        schema = cfg.get("schema") or "default"
        return f"`{catalog}`.`{schema}`.`{table}`"

    async def test_connection(self) -> bool:
        if not self._has_connection_params():
            return False
        cfg = self._config()

        def _sync() -> bool:
            conn = _driver.connect(
                server_hostname=cfg["server_hostname"],
                http_path=cfg["http_path"],
                access_token=cfg["access_token"],
            )
            try:
                cur = conn.cursor()
                cur.execute("SELECT 1")
                row = cur.fetchone()
                cur.close()
                return bool(row and row[0] == 1)
            finally:
                conn.close()

        try:
            return await run_sync(_sync)
        except Exception:
            return False

    async def list_tables(self) -> list[str]:
        if not self._has_connection_params():
            return []
        cfg = self._config()
        catalog = cfg.get("catalog") or "hive_metastore"
        schema = cfg.get("schema") or "default"

        def _sync() -> list[str]:
            conn = _driver.connect(
                server_hostname=cfg["server_hostname"],
                http_path=cfg["http_path"],
                access_token=cfg["access_token"],
            )
            try:
                cur = conn.cursor()
                cur.execute(f"SHOW TABLES IN `{catalog}`.`{schema}`")
                rows = cur.fetchall()
                cur.close()
                # Row layout: (catalog, schema, tableName, isTemporary)
                out: list[str] = []
                for r in rows:
                    if not r:
                        continue
                    # Databricks returns (database, tableName, isTemporary) or
                    # (catalog, schema, tableName, isTemporary) depending on
                    # catalog support — the table name is always the 2nd-last.
                    name = r[-2] if len(r) >= 2 else r[0]
                    out.append(str(name))
                return out
            finally:
                conn.close()

        try:
            return await run_sync(_sync)
        except Exception:
            return []

    async def describe_table(self, table: str) -> dict[str, Any]:
        if not await self._validate_table(table):
            return {"columns": []}
        cfg = self._config()
        qualified = self._qualified(table)

        def _sync() -> list[dict[str, str]]:
            conn = _driver.connect(
                server_hostname=cfg["server_hostname"],
                http_path=cfg["http_path"],
                access_token=cfg["access_token"],
            )
            try:
                cur = conn.cursor()
                cur.execute(f"DESCRIBE TABLE {qualified}")
                rows = cur.fetchall()
                cur.close()
                columns: list[dict[str, str]] = []
                for r in rows:
                    if not r or not r[0]:
                        continue
                    # DESCRIBE separates data rows from metadata rows with a
                    # blank separator; bail out at the first empty name.
                    name = str(r[0]).strip()
                    if not name or name.startswith("#"):
                        break
                    kind = str(r[1]) if len(r) > 1 else ""
                    columns.append({"name": name, "type": kind})
                return columns
            finally:
                conn.close()

        try:
            columns = await run_sync(_sync)
            return {"columns": columns}
        except Exception:
            return {"columns": []}

    async def sample_rows(
        self, table: str, limit: int = 5
    ) -> list[dict[str, Any]]:
        if not isinstance(limit, int) or limit <= 0 or limit > 1000:
            return []
        if not await self._validate_table(table):
            return []
        cfg = self._config()
        qualified = self._qualified(table)

        def _sync() -> list[dict[str, Any]]:
            conn = _driver.connect(
                server_hostname=cfg["server_hostname"],
                http_path=cfg["http_path"],
                access_token=cfg["access_token"],
            )
            try:
                cur = conn.cursor()
                cur.execute(f"SELECT * FROM {qualified} LIMIT {int(limit)}")
                rows = cur.fetchall()
                cols = [d[0] for d in (cur.description or [])]
                cur.close()
                return [dict(zip(cols, r, strict=False)) for r in rows]
            finally:
                conn.close()

        try:
            return await run_sync(_sync)
        except Exception:
            return []
