"""TimescaleDB connector — reuses the PostgreSQL driver.

TimescaleDB is a PostgreSQL extension; the connection protocol and
``asyncpg`` driver are identical. This connector differs from
:class:`PostgreSQLConnector` only in ``list_tables``, which unions regular
public tables with rows from ``timescaledb_information.hypertables`` so
time-series tables surface even when they live in a non-``public`` schema.
"""

from __future__ import annotations

import logging

import asyncpg  # type: ignore[import-untyped]  # asyncpg ships no py.typed marker

from backend.connectors.base import CredentialField
from backend.connectors.databases.postgresql import PostgreSQLConnector

logger = logging.getLogger(__name__)


class TimescaleDBConnector(PostgreSQLConnector):
    slug = "timescaledb"
    display_name = "TimescaleDB"
    description = "Query TimescaleDB hypertables and regular Postgres tables"
    credential_schema = [
        CredentialField(
            key="connection_string",
            label="Connection string",
            placeholder="postgresql://user:pass@localhost:5432/dbname",
            type="password",
            help_text="Format: postgresql://user:pass@host:port/database (TimescaleDB runs on PostgreSQL).",
        ),
    ]

    async def list_tables(self) -> list[str]:
        conn = await self._connect()
        if conn is None:
            return []
        try:
            rows = await conn.fetch(
                """
                SELECT table_name FROM information_schema.tables
                 WHERE table_schema = 'public'
                   AND table_type = 'BASE TABLE'
                UNION
                SELECT hypertable_name AS table_name
                  FROM timescaledb_information.hypertables
                ORDER BY table_name
                """
            )
            return [str(r["table_name"]) for r in rows]
        except asyncpg.PostgresError as exc:
            # If the timescaledb extension isn't installed, the union query
            # fails — fall back to the vanilla Postgres enumeration.
            logger.info(
                "[%s] hypertable union failed (%s) — falling back to base",
                self.slug,
                exc.__class__.__name__,
            )
            await self._close(conn)
            return await super().list_tables()
        finally:
            await self._close(conn)
