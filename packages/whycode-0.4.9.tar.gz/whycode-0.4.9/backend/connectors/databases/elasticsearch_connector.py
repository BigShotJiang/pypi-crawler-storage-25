"""Elasticsearch connector via ``elasticsearch`` async client.

Expects JSON in ``connection_string``::

    {"hosts": ["https://host:9200"], "api_key": "..."}

or optionally ``{"hosts": [...], "basic_auth": ["user", "pass"]}``.

Indices map to "tables"; mapping properties map to "columns"; source
documents returned by ``match_all`` map to "rows".
"""

from __future__ import annotations

import logging
from typing import Any

from backend.connectors.base import CredentialField
from backend.connectors.databases._base import (
    AbstractDatabaseConnector,
    parse_json_config,
    require_driver,
)

logger = logging.getLogger(__name__)

try:
    from elasticsearch import AsyncElasticsearch as _AsyncES

    _driver: Any = _AsyncES
    _AVAILABLE = True
except ImportError:
    _driver = None
    _AVAILABLE = False


class ElasticsearchConnector(AbstractDatabaseConnector):
    slug = "elasticsearch"
    display_name = "Elasticsearch"
    description = "Search and sample Elasticsearch indices"
    credential_schema = [
        CredentialField(
            key="host",
            label="Host URL",
            placeholder="https://localhost:9200",
            help_text="For Elastic Cloud use your cluster URL.",
        ),
        CredentialField(
            key="api_key",
            label="API key",
            placeholder="base64encodedapikey==",
            type="password",
            help_text=(
                "Create in Kibana: Stack Management → API Keys → Create. "
                "Format: encoded_id:encoded_api_key."
            ),
        ),
        CredentialField(
            key="index",
            label="Default index (optional)",
            placeholder="my-index-*",
            required=False,
            help_text="Index pattern to search by default. Wildcards allowed.",
        ),
    ]

    def __init__(self, credential_manager, db=None):  # type: ignore[no-untyped-def]
        require_driver(_driver, self.slug, "elasticsearch")
        super().__init__(credential_manager, db)

    def _client(self) -> Any:
        config = parse_json_config(self._get_credential("connection_string"))
        hosts = config.get("hosts")
        if not isinstance(hosts, list) or not hosts:
            return None
        kwargs: dict[str, Any] = {"hosts": hosts, "request_timeout": 10}
        if "api_key" in config:
            kwargs["api_key"] = config["api_key"]
        if "basic_auth" in config and isinstance(config["basic_auth"], list):
            kwargs["basic_auth"] = tuple(config["basic_auth"])
        try:
            return _driver(**kwargs)
        except Exception as exc:
            logger.info(
                "[%s] client init failed: %s", self.slug, exc.__class__.__name__
            )
            return None

    @staticmethod
    async def _aclose(client: Any) -> None:
        if client is None:
            return
        try:
            await client.close()
        except Exception:
            logger.debug("elasticsearch close failed", exc_info=True)

    async def test_connection(self) -> bool:
        client = self._client()
        if client is None:
            return False
        try:
            resp = await client.ping()
            return bool(resp)
        except Exception:
            return False
        finally:
            await self._aclose(client)

    async def list_tables(self) -> list[str]:
        client = self._client()
        if client is None:
            return []
        try:
            resp = await client.cat.indices(format="json", h="index")
            if not isinstance(resp, list):
                return []
            return [
                str(r.get("index", ""))
                for r in resp
                if isinstance(r, dict) and r.get("index")
            ]
        except Exception:
            return []
        finally:
            await self._aclose(client)

    async def describe_table(self, table: str) -> dict[str, Any]:
        if not await self._validate_table(table):
            return {"columns": []}
        client = self._client()
        if client is None:
            return {"columns": []}
        try:
            resp = await client.indices.get_mapping(index=table)
            body = resp.get(table, {}) if isinstance(resp, dict) else {}
            mapping = body.get("mappings", {}) if isinstance(body, dict) else {}
            props = mapping.get("properties") if isinstance(mapping, dict) else None
            if not isinstance(props, dict):
                return {"columns": []}
            return {
                "columns": [
                    {"name": str(name), "type": str(spec.get("type", "object"))}
                    for name, spec in props.items()
                    if isinstance(spec, dict)
                ]
            }
        except Exception:
            return {"columns": []}
        finally:
            await self._aclose(client)

    async def sample_rows(
        self, table: str, limit: int = 5
    ) -> list[dict[str, Any]]:
        if not isinstance(limit, int) or limit <= 0 or limit > 1000:
            return []
        if not await self._validate_table(table):
            return []
        client = self._client()
        if client is None:
            return []
        try:
            resp = await client.search(
                index=table,
                size=limit,
                query={"match_all": {}},
            )
            hits = ((resp.get("hits") or {}).get("hits") or []) if isinstance(resp, dict) else []
            return [
                {"_id": str(h.get("_id", "")), **(h.get("_source") or {})}
                for h in hits
                if isinstance(h, dict)
            ]
        except Exception:
            return []
        finally:
            await self._aclose(client)
