"""MongoDB connector via ``motor``.

``motor.motor_asyncio.AsyncIOMotorClient`` handles connection parsing
natively for any ``mongodb://...`` / ``mongodb+srv://...`` URI. Database
name is either embedded in the URI path or stashed separately in the
vault under ``db_name``.

NoSQL shape: collections map to "tables", documents map to "rows",
top-level keys of a sampled document map to "columns".
"""

from __future__ import annotations

import contextlib
import logging
from typing import Any

from backend.connectors.base import CredentialField
from backend.connectors.databases._base import (
    AbstractDatabaseConnector,
    require_driver,
)

logger = logging.getLogger(__name__)

try:
    import motor.motor_asyncio as _driver
    _AVAILABLE = True
except ImportError:
    _driver = None
    _AVAILABLE = False


class MongoDBConnector(AbstractDatabaseConnector):
    slug = "mongodb"
    display_name = "MongoDB"
    description = "Search MongoDB collections and inspect documents"
    credential_schema = [
        CredentialField(
            key="connection_string",
            label="Connection string",
            placeholder="mongodb://user:pass@localhost:27017/dbname",
            type="password",
            help_text="Format: mongodb://user:pass@host:port/database (or mongodb+srv:// for Atlas)",
        ),
    ]

    def __init__(self, credential_manager, db=None):  # type: ignore[no-untyped-def]
        require_driver(_driver, self.slug, "mongodb")
        super().__init__(credential_manager, db)

    def _client(self) -> Any:
        uri = self._get_credential("connection_string")
        if not uri:
            return None
        try:
            return _driver.AsyncIOMotorClient(
                uri, serverSelectionTimeoutMS=5000
            )
        except Exception as exc:
            logger.info(
                "[%s] client init failed: %s", self.slug, exc.__class__.__name__
            )
            return None

    def _db_handle(self, client: Any) -> Any:
        """Resolve the target database from the URI path or vault override."""
        override = self._get_credential("db_name")
        if override:
            return client[override]
        default = client.get_default_database()
        return default

    async def test_connection(self) -> bool:
        client = self._client()
        if client is None:
            return False
        try:
            await client.admin.command("ping")
            return True
        except Exception:
            return False
        finally:
            with contextlib.suppress(Exception):
                client.close()

    async def list_tables(self) -> list[str]:
        client = self._client()
        if client is None:
            return []
        try:
            db_handle = self._db_handle(client)
            if db_handle is None:
                return []
            names = await db_handle.list_collection_names()
            return [str(n) for n in names]
        except Exception:
            return []
        finally:
            with contextlib.suppress(Exception):
                client.close()

    async def describe_table(self, table: str) -> dict[str, Any]:
        if not await self._validate_table(table):
            return {"columns": []}
        client = self._client()
        if client is None:
            return {"columns": []}
        try:
            db_handle = self._db_handle(client)
            if db_handle is None:
                return {"columns": []}
            doc = await db_handle[table].find_one()
            if not isinstance(doc, dict):
                return {"columns": []}
            columns = [
                {"name": str(k), "type": type(v).__name__}
                for k, v in doc.items()
            ]
            return {"columns": columns}
        except Exception:
            return {"columns": []}
        finally:
            with contextlib.suppress(Exception):
                client.close()

    async def sample_rows(
        self, table: str, limit: int = 5
    ) -> list[dict[str, Any]]:
        if not isinstance(limit, int) or limit <= 0 or limit > 1000:
            return []
        if not await self._validate_table(table):
            return []
        client = self._client()
        if client is None:
            return []
        try:
            db_handle = self._db_handle(client)
            if db_handle is None:
                return []
            cursor = db_handle[table].find({}).limit(limit)
            docs = await cursor.to_list(length=limit)
            return [_sanitize_doc(d) for d in docs if isinstance(d, dict)]
        except Exception:
            return []
        finally:
            with contextlib.suppress(Exception):
                client.close()


def _sanitize_doc(doc: dict[str, Any]) -> dict[str, Any]:
    """Convert ObjectId / bson types to strings for JSON-friendly output."""
    out: dict[str, Any] = {}
    for k, v in doc.items():
        if v.__class__.__name__ == "ObjectId":
            out[str(k)] = str(v)
        else:
            out[str(k)] = v
    return out
