"""Redis connector via ``redis.asyncio``.

Treats Redis keys as "tables" and key types as "columns". ``SCAN`` with a
``MATCH`` pattern is used for search; the first 1000 keys are enumerated
for ``list_tables``.

Value inspection uses the type-appropriate accessor:

- ``string`` → ``GET``
- ``hash``   → ``HGETALL``
- ``list``   → ``LRANGE key 0 limit-1``
- ``set``    → ``SMEMBERS`` (truncated)
- ``zset``   → ``ZRANGE key 0 limit-1 WITHSCORES``
"""

from __future__ import annotations

import logging
from typing import Any

from backend.connectors.base import CredentialField
from backend.connectors.databases._base import (
    AbstractDatabaseConnector,
    require_driver,
)

logger = logging.getLogger(__name__)

try:
    import redis.asyncio as _driver
    _AVAILABLE = True
except ImportError:
    _driver = None
    _AVAILABLE = False

_MAX_KEYS_LISTED = 1000
_VALUE_PREVIEW_CHARS = 500


class RedisConnector(AbstractDatabaseConnector):
    slug = "redis"
    display_name = "Redis"
    description = "Inspect Redis keys, types, and sampled values"
    credential_schema = [
        CredentialField(
            key="connection_string",
            label="Connection string",
            placeholder="redis://localhost:6379/0",
            type="password",
            help_text="Format: redis://host:port/db (or redis://:password@host:port/db)",
        ),
    ]

    def __init__(self, credential_manager, db=None):  # type: ignore[no-untyped-def]
        require_driver(_driver, self.slug, "redis-connector")
        super().__init__(credential_manager, db)

    def _client(self) -> Any:
        url = self._get_credential("connection_string")
        if not url:
            return None
        try:
            return _driver.from_url(
                url,
                decode_responses=True,
                socket_connect_timeout=5.0,
            )
        except Exception as exc:
            logger.info(
                "[%s] from_url failed: %s", self.slug, exc.__class__.__name__
            )
            return None

    @staticmethod
    async def _aclose(client: Any) -> None:
        if client is None:
            return
        try:
            await client.aclose()
        except Exception:
            logger.debug("redis aclose failed", exc_info=True)

    async def test_connection(self) -> bool:
        client = self._client()
        if client is None:
            return False
        try:
            pong = await client.ping()
            return bool(pong)
        except Exception:
            return False
        finally:
            await self._aclose(client)

    async def list_tables(self) -> list[str]:
        client = self._client()
        if client is None:
            return []
        try:
            keys: list[str] = []
            async for k in client.scan_iter(match="*", count=100):
                keys.append(str(k))
                if len(keys) >= _MAX_KEYS_LISTED:
                    break
            return keys
        except Exception:
            return []
        finally:
            await self._aclose(client)

    async def describe_table(self, table: str) -> dict[str, Any]:
        if not await self._validate_table(table):
            return {"columns": []}
        client = self._client()
        if client is None:
            return {"columns": []}
        try:
            key_type = await client.type(table)
            ttl = await client.ttl(table)
            return {
                "columns": [
                    {"name": "type", "type": str(key_type)},
                    {"name": "ttl", "type": str(ttl)},
                ]
            }
        except Exception:
            return {"columns": []}
        finally:
            await self._aclose(client)

    async def sample_rows(
        self, table: str, limit: int = 5
    ) -> list[dict[str, Any]]:
        if not isinstance(limit, int) or limit <= 0 or limit > 1000:
            return []
        if not await self._validate_table(table):
            return []
        client = self._client()
        if client is None:
            return []
        try:
            key_type = await client.type(table)
            return await _fetch_by_type(client, table, key_type, limit)
        except Exception:
            return []
        finally:
            await self._aclose(client)


async def _fetch_by_type(
    client: Any, key: str, key_type: str, limit: int
) -> list[dict[str, Any]]:
    if key_type == "string":
        value = await client.get(key)
        return [{"value": _truncate(value)}]
    if key_type == "hash":
        data = await client.hgetall(key)
        if not isinstance(data, dict):
            return []
        return [{str(k): _truncate(v) for k, v in data.items()}]
    if key_type == "list":
        items = await client.lrange(key, 0, limit - 1)
        return [{"index": i, "value": _truncate(v)} for i, v in enumerate(items)]
    if key_type == "set":
        members = await client.smembers(key)
        members_list = list(members)[:limit]
        return [{"member": _truncate(m)} for m in members_list]
    if key_type == "zset":
        pairs = await client.zrange(key, 0, limit - 1, withscores=True)
        return [
            {"member": _truncate(m), "score": s} for m, s in pairs
        ]
    return []


def _truncate(value: Any) -> str:
    s = str(value) if value is not None else ""
    return s if len(s) <= _VALUE_PREVIEW_CHARS else s[:_VALUE_PREVIEW_CHARS] + "…"
