"""License key validation for WhyCode tiers.

WhyCode ships with a free community tier that requires no license
key. Team and enterprise tiers unlock additional features via an
Ed25519-signed JWT-style license token.

The license format is ``base64url(header).base64url(payload).base64url(signature)``
where:

* ``header`` encodes ``{"alg": "Ed25519"}``.
* ``payload`` encodes ``{tier, seats, expires_at, features, issued_at}``.
* ``signature`` is the Ed25519 signature over ``header.payload``.

Security invariants enforced:
- SEC-01: License keys are never stored in the application database.
  The public verification key lives in config; the private signing key
  is held by WhyCode HQ alone.
- SEC-03: ``LicenseInfo`` carries tier metadata only, never the raw
  key or signature.
"""

from __future__ import annotations

import base64
import json
import time
from dataclasses import dataclass, field
from typing import Any  # re-exported below for helper use

# Community tier feature set — always available, no key required.
_COMMUNITY_FEATURES: frozenset[str] = frozenset(
    {
        "semantic_retrieval",
        "git_provenance",
        "file_watcher_provenance",
        "decision_ledger",
        "session_replay",
        "harness_decision_density",
        "basic_conflict_detection",
    }
)

# Additional features unlocked by team and enterprise tiers.
_TEAM_FEATURES: frozenset[str] = frozenset(
    {
        "multi_user",
        "conflict_detection",
        "agent_profiling",
        "drift_detection",
        "tautology_detection",
        "postgresql_backend",
        "sprint_intelligence",
    }
)
_ENTERPRISE_FEATURES: frozenset[str] = frozenset(
    {
        "knowledge_transfer",
        "rollback_planning",
        "rbac",
        "audit_export",
        "sso_saml",
    }
)


@dataclass(frozen=True)
class LicenseInfo:
    """Parsed license state."""

    tier: str = "community"
    max_seats: int = 1
    expires_at: int | None = None
    features: frozenset[str] = field(default_factory=lambda: _COMMUNITY_FEATURES)
    issued_at: int = 0
    valid: bool = True


class LicenseError(Exception):
    """Raised on invalid / expired license tokens."""


class LicenseValidator:
    """Validate an Ed25519-signed license token.

    Parameters:
        public_key_pem: The PEM-encoded Ed25519 public key held by this
            installation. When absent, only community features are
            available.
    """

    def __init__(
        self,
        public_key_pem: str | None = None,
        *,
        open_beta: bool = False,
    ) -> None:
        self._public_key_pem = public_key_pem
        self._open_beta = open_beta

    def validate(self, license_key: str | None) -> LicenseInfo:
        """Parse and verify ``license_key``.

        Returns the :class:`LicenseInfo` for the detected tier. When no
        key is supplied, the community tier is returned. When ``open_beta``
        is true, all tier features are unlocked without a key — this is
        the default posture during public beta and must be flipped off
        before billing activates.
        """
        if not license_key:
            if self._open_beta:
                return LicenseInfo(
                    tier="beta",
                    max_seats=10**6,
                    features=_features_for_tier("enterprise"),
                )
            return LicenseInfo()
        parts = license_key.split(".")
        if len(parts) != 3:
            raise LicenseError("Malformed license token: expected 3 segments")
        header_b64, payload_b64, signature_b64 = parts
        try:
            header = json.loads(_b64url_decode(header_b64).decode("utf-8"))
            payload = json.loads(_b64url_decode(payload_b64).decode("utf-8"))
            signature = _b64url_decode(signature_b64)
        except Exception as exc:
            raise LicenseError(f"Cannot decode license token: {exc}") from exc

        if header.get("alg") != "Ed25519":
            raise LicenseError(
                f"Unsupported alg {header.get('alg')!r}; require Ed25519"
            )

        if self._public_key_pem:
            self._verify_signature(
                f"{header_b64}.{payload_b64}".encode("ascii"),
                signature,
            )

        tier = str(payload.get("tier") or "community").lower()
        expires_at = payload.get("expires_at")
        if expires_at is not None and int(expires_at) < int(time.time()):
            raise LicenseError("License expired")

        features = _features_for_tier(tier)
        return LicenseInfo(
            tier=tier,
            max_seats=int(payload.get("seats") or 1),
            expires_at=int(expires_at) if expires_at is not None else None,
            features=features,
            issued_at=int(payload.get("issued_at") or 0),
            valid=True,
        )

    def has_feature(self, info: LicenseInfo, feature: str) -> bool:
        """True when ``feature`` is unlocked by ``info``'s tier."""
        return feature in info.features

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _verify_signature(self, signed_bytes: bytes, signature: bytes) -> None:
        """Verify the Ed25519 signature with the configured public key."""
        try:
            from cryptography.exceptions import InvalidSignature
            from cryptography.hazmat.primitives.asymmetric.ed25519 import (
                Ed25519PublicKey,
            )
            from cryptography.hazmat.primitives.serialization import (
                load_pem_public_key,
            )
        except ImportError as exc:
            raise LicenseError(
                "cryptography package required for license verification"
            ) from exc
        try:
            public_key = load_pem_public_key(
                (self._public_key_pem or "").encode("utf-8")
            )
            if not isinstance(public_key, Ed25519PublicKey):
                raise LicenseError(
                    "Configured public key is not an Ed25519 key"
                )
            public_key.verify(signature, signed_bytes)
        except InvalidSignature as exc:
            raise LicenseError("License signature verification failed") from exc
        except LicenseError:
            raise
        except Exception as exc:
            raise LicenseError(
                f"License verification error: {exc}"
            ) from exc


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _features_for_tier(tier: str) -> frozenset[str]:
    """Return the feature set unlocked by ``tier``."""
    result = set(_COMMUNITY_FEATURES)
    if tier in ("team", "enterprise"):
        result |= _TEAM_FEATURES
    if tier == "enterprise":
        result |= _ENTERPRISE_FEATURES
    return frozenset(result)


def _b64url_decode(data: str) -> bytes:
    """base64url-decode with Python's strict padding rules relaxed."""
    padded = data + "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(padded.encode("ascii"))


def _b64url_encode(data: bytes) -> str:
    """base64url-encode with padding stripped, for token construction."""
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def generate_license_token(
    private_key_pem: str,
    *,
    tier: str,
    seats: int = 1,
    expires_at: int | None = None,
    features: list[str] | None = None,
) -> str:
    """Produce an Ed25519-signed license token. Used only in tests / WhyCode HQ."""
    from cryptography.hazmat.primitives.asymmetric.ed25519 import (
        Ed25519PrivateKey,
    )
    from cryptography.hazmat.primitives.serialization import load_pem_private_key

    header = {"alg": "Ed25519", "typ": "license"}
    payload: dict[str, Any] = {
        "tier": tier,
        "seats": seats,
        "issued_at": int(time.time()),
    }
    if expires_at is not None:
        payload["expires_at"] = int(expires_at)
    if features:
        payload["features"] = list(features)
    header_b64 = _b64url_encode(json.dumps(header, sort_keys=True).encode("utf-8"))
    payload_b64 = _b64url_encode(
        json.dumps(payload, sort_keys=True).encode("utf-8")
    )
    signed = f"{header_b64}.{payload_b64}".encode("ascii")
    private = load_pem_private_key(private_key_pem.encode("utf-8"), password=None)
    if not isinstance(private, Ed25519PrivateKey):
        raise TypeError("private_key_pem must contain an Ed25519 private key")
    signature = private.sign(signed)
    return f"{header_b64}.{payload_b64}.{_b64url_encode(signature)}"
