"""OAuth token-exchange relay client.

When WhyCode ships with a default OAuth ``client_id`` for a provider
(Google, GitHub) but the client_secret is not locally configured, the
authorization-code → token exchange is routed through the WhyCode
relay endpoint. The relay holds the client_secret for the WhyCode
hosted OAuth app and performs the upstream exchange on behalf of the
local install, returning the resulting access/refresh tokens verbatim.

Security invariants:
- The relay endpoint is TLS-only.
- Request payloads carry only the authorization code, redirect_uri,
  and provider name — never WhyCode user data or secrets.
- Responses are passed through unchanged and stored by the caller via
  the normal :class:`OAuthManager` path (refresh tokens → vault,
  access tokens → memory).

Endpoint contract:

* ``POST {RELAY_BASE_URL}/exchange/{provider}``
* Request body: ``{"code": str, "redirect_uri": str}``
* Response body: ``{"access_token": str, "refresh_token": str | None,
  "expires_in": int, "token_type": str}``

The relay server itself lives outside this repository. When the relay
host is unreachable, :func:`exchange_via_relay` returns ``None`` and
the caller reports an ``oauth_exchange_failed`` error to the user —
identical to a direct upstream failure.
"""

from __future__ import annotations

import logging
import os
from typing import Any

import httpx

logger = logging.getLogger(__name__)


RELAY_BASE_URL = os.environ.get(
    "WHYCODE_OAUTH_RELAY_URL", "https://auth.whycode.dev"
)
"""Base URL for the WhyCode OAuth relay.

Override via the ``WHYCODE_OAUTH_RELAY_URL`` environment variable for
staging, local relay development, or air-gapped deployments.
"""

_RELAY_TIMEOUT = 10.0


async def exchange_via_relay(
    provider: str,
    code: str,
    redirect_uri: str,
) -> dict[str, Any] | None:
    """Exchange an OAuth authorization code via the WhyCode relay.

    Returns the provider's token response (``access_token``,
    ``refresh_token``, ``expires_in``) on success, or ``None`` when the
    relay is unreachable or responds with a non-2xx status. The caller
    treats ``None`` as an exchange failure and redirects the user back
    to the login page with ``oauth_exchange_failed``.
    """
    url = f"{RELAY_BASE_URL.rstrip('/')}/exchange/{provider}"
    try:
        async with httpx.AsyncClient(timeout=_RELAY_TIMEOUT) as client:
            response = await client.post(
                url,
                json={"code": code, "redirect_uri": redirect_uri},
            )
    except (httpx.HTTPError, OSError) as exc:
        logger.warning("OAuth relay request failed for %s: %s", provider, exc)
        return None

    if response.status_code != 200:
        logger.warning(
            "OAuth relay returned %d for %s: %s",
            response.status_code,
            provider,
            response.text[:200],
        )
        return None

    try:
        payload = response.json()
    except ValueError as exc:
        logger.warning("OAuth relay returned non-JSON for %s: %s", provider, exc)
        return None
    if not isinstance(payload, dict) or "access_token" not in payload:
        logger.warning("OAuth relay returned malformed payload for %s", provider)
        return None
    return payload
