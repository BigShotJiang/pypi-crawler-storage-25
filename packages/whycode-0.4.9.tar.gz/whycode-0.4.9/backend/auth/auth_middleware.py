"""FastAPI authentication middleware.

Extracts credentials from incoming requests in priority order:

1. ``Authorization: Bearer <token>`` header (MCP clients, dashboard API)
2. ``whycode_session`` HttpOnly cookie (dashboard browser)
3. ``WHYCODE_TOKEN`` environment variable (CI, headless Docker)

A token that matches either a JWT session token or a PAT is accepted. On
success, the resolved ``User`` is attached to ``request.state.user``. On any
failure, the request is rejected with HTTP 401.

Security invariants enforced:
- SEC-05: Every endpoint requires auth (except paths listed in the optional
  whitelist). There is no anonymous access beyond ``/health``.
"""

from __future__ import annotations

import hmac
import os
from contextvars import ContextVar
from typing import TYPE_CHECKING

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

from backend.auth.auth_service import AuthError

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from starlette.requests import Request
    from starlette.responses import Response
    from starlette.types import ASGIApp

    from backend.auth.auth_service import AuthService
    from backend.auth.credential_manager import CredentialManager
    from backend.models import User


_COOKIE_NAME = "whycode_session"
_ENV_TOKEN_NAME = "WHYCODE_TOKEN"
_SOLO_TOKEN_PROVIDER = "whycode"
_SOLO_TOKEN_KEY = "solo_bearer_token"
_SOLO_TOKEN_PREFIX = "cl_solo_"

# ContextVar mirroring request.state.user so code that does not have access
# to the Request object (notably FastMCP tool handlers, which run inside a
# mounted Starlette sub-app and only receive their declared args) can still
# reach the authenticated user. The value is set before call_next and reset
# in a finally block so downstream tasks see it and the original task is
# unchanged after dispatch returns.
_current_user: ContextVar[User | None] = ContextVar(
    "whycode_current_user", default=None
)


def get_current_user() -> User | None:
    """Return the authenticated user for the active request, if any."""
    return _current_user.get()


class AuthMiddleware(BaseHTTPMiddleware):
    """Starlette middleware that gates every request on a valid credential."""

    def __init__(
        self,
        app: ASGIApp,
        auth_service: AuthService,
        *,
        public_paths: frozenset[str] | None = None,
        public_prefixes: tuple[str, ...] | None = None,
        credentials: CredentialManager | None = None,
    ) -> None:
        super().__init__(app)
        self._auth = auth_service
        self._creds = credentials
        self._public_paths: frozenset[str] = public_paths or frozenset({"/health"})
        self._public_prefixes: tuple[str, ...] = public_prefixes or ()

    async def dispatch(
        self,
        request: Request,
        call_next: Callable[[Request], Awaitable[Response]],
    ) -> Response:
        path = request.url.path
        if path in self._public_paths or any(
            path.startswith(prefix) for prefix in self._public_prefixes
        ):
            return await call_next(request)

        token = self._extract_token(request)
        if not token:
            return _unauthorized("Missing credentials")

        try:
            user = await self._resolve_user(token)
        except AuthError as exc:
            return _unauthorized(str(exc))

        request.state.user = user
        ctx_token = _current_user.set(user)  # type: ignore[arg-type]
        try:
            return await call_next(request)
        finally:
            _current_user.reset(ctx_token)

    def _extract_token(self, request: Request) -> str | None:
        auth_header = request.headers.get("authorization", "")
        if auth_header.lower().startswith("bearer "):
            return auth_header[7:].strip() or None

        cookie_value = request.cookies.get(_COOKIE_NAME)
        if cookie_value:
            return cookie_value

        env_token = os.environ.get(_ENV_TOKEN_NAME)
        if env_token:
            return env_token

        return None

    async def _resolve_user(self, token: str) -> object:
        """Return a User for the token, trying JWT, solo token, then PAT."""
        # JWT session tokens are structured (three dot-separated segments).
        if token.count(".") == 2:
            try:
                payload = self._auth.verify_jwt(token)
            except AuthError:
                pass
            else:
                from backend.models import User

                rows = await self._auth._db.query("users", {"id": payload["sub"]})
                if not rows:
                    raise AuthError("User not found for JWT subject")
                return User.from_dict(rows[0])

        # Solo bearer token: a ``cl_solo_<random>`` string generated at
        # ``whycode init`` time and persisted in the credential vault.
        # Match against the stored value in constant time, then return a
        # synthetic admin user so the dashboard and API work in solo mode
        # without a populated ``users`` table.
        if token.startswith(_SOLO_TOKEN_PREFIX) and self._creds is not None:
            stored = self._creds.get(_SOLO_TOKEN_PROVIDER, _SOLO_TOKEN_KEY)
            if stored and hmac.compare_digest(stored, token):
                from backend.models import User

                return User(
                    email="solo@local",
                    name="Solo User",
                    provider="solo",
                    password_hash=None,
                )

        return await self._auth.validate_pat(token)


def _unauthorized(detail: str) -> JSONResponse:
    return JSONResponse(
        status_code=401,
        content={"detail": detail},
        headers={"WWW-Authenticate": "Bearer"},
    )
