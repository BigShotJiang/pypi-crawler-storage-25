"""Token counter for context budget calculations.

Wraps the tiktoken library to provide accurate token counts using the
``cl100k_base`` encoding (the encoding shared by GPT-4 and Claude-class
chat models and the conservative baseline for context-budget planning).

The encoder is loaded once on first use and reused — tiktoken's BPE
tables are expensive to initialise, so caching avoids per-call overhead
in hot paths like semantic retrieval and context triage.

Security invariants enforced:
- None directly. This module processes arbitrary text and emits integers;
  it never reads secrets or produces network I/O.
"""

from __future__ import annotations

from functools import lru_cache
from typing import Any  # Any: context item dicts have heterogeneous metadata values

try:
    import tiktoken  # type: ignore[import-untyped]
    _TIKTOKEN_AVAILABLE = True
except ImportError:
    tiktoken = None  # type: ignore[assignment]
    _TIKTOKEN_AVAILABLE = False

_ENCODING_NAME = "cl100k_base"


@lru_cache(maxsize=1)
def _encoder() -> Any:
    """Return the cached ``cl100k_base`` encoder.

    Only called when ``_TIKTOKEN_AVAILABLE`` is True. tiktoken's
    ``get_encoding`` is safe to call repeatedly but does a table rebuild
    each time; caching at the module level ensures O(1) subsequent
    access with no thread-safety concerns (the encoder is read-only).
    """
    return tiktoken.get_encoding(_ENCODING_NAME)


def _approximate_count(text: str) -> int:
    """Character-based token approximation used when tiktoken is absent.

    cl100k_base averages ~4 characters per token for English text. Round
    up so any non-empty string is at least 1 token — context-budget math
    stays conservative (overestimates slightly rather than underestimates).
    """
    if not text:
        return 0
    return max(1, (len(text) + 3) // 4)


def count_tokens(text: str) -> int:
    """Return the number of tokens for a single text string.

    Uses tiktoken's ``cl100k_base`` when available; otherwise falls back
    to a character-based approximation (~4 chars/token). Install tiktoken
    for exact counts: ``pip install whycode[tiktoken]``.

    Args:
        text: Any text, including empty strings and Unicode.

    Returns:
        Token count as a non-negative integer. Empty input returns 0.

    Raises:
        TypeError: If ``text`` is not a string.
    """
    if not isinstance(text, str):
        raise TypeError(f"count_tokens requires str, got {type(text).__name__}")
    if not text:
        return 0
    if _TIKTOKEN_AVAILABLE:
        return len(_encoder().encode(text))
    return _approximate_count(text)


def count_tokens_batch(texts: list[str]) -> list[int]:
    """Return token counts for a list of text strings, preserving order.

    Uses tiktoken's ``encode_batch`` which processes all inputs in parallel
    worker threads when the batch is large enough — significantly faster
    than calling ``count_tokens`` in a Python loop for large batches.

    Args:
        texts: List of strings. May be empty. Individual entries may be
            empty strings.

    Returns:
        List of token counts, one per input, in the same order.

    Raises:
        TypeError: If ``texts`` is not a list or contains non-string items.
    """
    if not isinstance(texts, list):
        raise TypeError(f"count_tokens_batch requires list, got {type(texts).__name__}")
    if not texts:
        return []
    for i, item in enumerate(texts):
        if not isinstance(item, str):
            raise TypeError(
                f"count_tokens_batch requires list[str], item {i} is {type(item).__name__}"
            )
    if _TIKTOKEN_AVAILABLE:
        encoded = _encoder().encode_batch(texts)
        return [len(tokens) for tokens in encoded]
    return [_approximate_count(t) for t in texts]


def estimate_budget_usage(
    items: list[dict[str, Any]],
    budget: int,
) -> dict[str, int]:
    """Count tokens across a list of context items against a token budget.

    Walks items in the order provided. Each item contributes its token
    count to the running total; an item "fits" if adding it to the running
    total does not exceed the budget. Once an item overflows, later items
    are still counted toward ``total_tokens`` but are not counted as
    fitting — callers that need prioritised inclusion should sort items
    before calling this function.

    Args:
        items: List of dicts, each with a ``"text"`` field holding the
            string to count. Items missing ``"text"`` contribute 0 tokens.
        budget: Token budget. Must be non-negative.

    Returns:
        Dict with three keys:
            - ``total_tokens``: Sum of token counts across all items.
            - ``items_that_fit``: Count of items whose cumulative inclusion
              stays within the budget.
            - ``remaining_budget``: ``max(0, budget - tokens_consumed)``
              where ``tokens_consumed`` is the sum of tokens in fitting
              items only.

    Raises:
        TypeError: If ``items`` is not a list or ``budget`` is not int.
        ValueError: If ``budget`` is negative.
    """
    if not isinstance(items, list):
        raise TypeError(f"estimate_budget_usage requires list, got {type(items).__name__}")
    if not isinstance(budget, int) or isinstance(budget, bool):
        raise TypeError(f"budget must be int, got {type(budget).__name__}")
    if budget < 0:
        raise ValueError(f"budget must be non-negative, got {budget}")

    texts = [str(item.get("text", "")) if isinstance(item, dict) else "" for item in items]
    counts = count_tokens_batch(texts)

    total_tokens = sum(counts)
    tokens_consumed = 0
    items_that_fit = 0
    for c in counts:
        if tokens_consumed + c <= budget:
            tokens_consumed += c
            items_that_fit += 1
        else:
            # Later items may be smaller and fit, but we stop at the first
            # overflow to preserve the prioritised-order semantics used by
            # context triage. Callers wanting a best-fit packing should
            # sort items by size or priority first.
            break

    return {
        "total_tokens": total_tokens,
        "items_that_fit": items_that_fit,
        "remaining_budget": max(0, budget - tokens_consumed),
    }
