"""Cross-platform path helpers.

Single canonical form is **forward-slash, POSIX-style** because that's
what every other piece of the system already produces (``Path.as_posix()``,
git diff, JS/TS frontends). Windows backends are the only producers
of backslash paths; normalise at storage and lookup boundaries so the
rest of the codebase stays portable.
"""

from __future__ import annotations

from pathlib import PurePath


def normalise_path(path: str | PurePath | None) -> str:
    """Return ``path`` with forward slashes, no trailing separator.

    Empty string and ``None`` round-trip to ``""`` so callers that
    splat the value into a query parameter still produce a valid SQL
    placeholder. A drive letter on Windows (``C:\\users\\x``) becomes
    ``C:/users/x`` — preserving the volume so disambiguation works on
    Windows hosts that look up a file by its full path.
    """
    if path is None:
        return ""
    text = str(path)
    if not text:
        return ""
    return text.replace("\\", "/")
