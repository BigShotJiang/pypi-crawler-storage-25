"""Platform-aware Claude Code hook command generation.

Claude Code runs each ``settings.json`` hook ``command`` string through
the platform's default shell. On Linux and macOS that's a POSIX shell
where ``bash -lc '…'`` + ``curl`` is the natural choice. On Windows
the shell is ``cmd.exe``, which ships with *neither* bash nor curl —
any ``bash -lc`` hook returns a "bash is not recognised" error,
``cmd.exe`` interprets that as a non-zero exit, and the hook silently
falls off the end. Users then see no session starting, no context
injection, and no ``session.end``.

This module builds a hook command string that matches the host OS:

* **Windows** — ``python3 -c "…"`` with ``urllib.request`` only.
  No shell pipelines, no external tools, no quoting tricks beyond
  what ``json.dumps`` already handles. The generated Python code is
  guaranteed to parse with :func:`ast.parse`.
* **Linux / macOS** — the historical ``bash -lc '…'`` + ``curl``
  form is preserved so existing deployments keep the exact behavior
  they were QA'd against.

The caller supplies:

* ``endpoint`` — path appended to ``server_url`` (e.g.
  ``/api/hooks/session-context``).
* ``payload_fields`` — mapping from the JSON field name sent to the
  endpoint to the environment variable the hook reads for it.
  ``cwd`` falls back to :func:`os.getcwd` when the env var is empty.
* ``output_mode`` — how to shape the hook's stdout (see
  :class:`OutputMode`).
* ``timeout_ms`` — per-request timeout passed to the HTTP client.

A failure anywhere (missing python3, unreachable server, timeout)
resolves to exit code 0 so the agent is never blocked.
"""

from __future__ import annotations

import platform
from dataclasses import dataclass
from typing import Literal


OutputMode = Literal["none", "context_block", "conflict_warning", "import_warning"]
"""How the hook should shape its stdout before returning.

* ``none`` — drop the response; the hook is fire-and-forget.
* ``context_block`` — print the ``context_block`` field from the JSON
  response, or an empty string if it's absent/null. Matches the
  behavior of the ``session-context`` / ``file-context`` endpoints.
* ``conflict_warning`` — print ``[WhyCode conflict] <message>`` when
  ``conflict`` is truthy in the response, else nothing. Used by the
  ``conflict-check`` hook.
* ``import_warning`` — print one ``[WhyCode drift] <constraint>`` line
  per entry in ``violations``. Used by the ``import-check`` hook.
"""


@dataclass(frozen=True)
class HookSpec:
    """Inputs for :func:`build_hook_command`."""

    endpoint: str
    server_url: str
    token: str
    payload_fields: dict[str, str]
    output_mode: OutputMode = "none"
    timeout_ms: int = 3000


def build_hook_command(spec: HookSpec) -> str:
    """Return a hook command string for the current platform."""
    if platform.system() == "Windows":
        return _build_python_hook_command(spec)
    return _build_bash_hook_command(spec)


# ---------------------------------------------------------------------------
# Windows — python3 + urllib
# ---------------------------------------------------------------------------


def _py_payload_expr(payload_fields: dict[str, str]) -> str:
    """Render the Python dict-literal that assembles the request payload.

    ``cwd`` gets :func:`os.getcwd` as a fallback so Windows hooks work
    even when Claude Code has not set ``CLAUDE_CWD``; other fields
    default to an empty string.
    """
    parts = []
    for field, env_var in payload_fields.items():
        if field == "cwd":
            parts.append(
                f"'{field}': (os.environ.get('{env_var}') or os.getcwd())"
            )
        else:
            parts.append(f"'{field}': os.environ.get('{env_var}', '')")
    return "{" + ", ".join(parts) + "}"


def _py_output_snippet(output_mode: OutputMode, timeout_s: int) -> str:
    """Render the Python snippet that performs the request and prints output.

    The snippet begins with ``resp=urllib.request.urlopen(r,timeout=N)``
    so the request is always executed; the output-shaping logic sits
    after that. Every path is wrapped in a ``try/except`` by the caller
    via the outer ``2>NUL || exit 0`` command shell fallback.
    """
    base = f"resp=urllib.request.urlopen(r,timeout={timeout_s})"
    if output_mode == "none":
        return base
    body = f"{base};d=json.loads(resp.read() or b'null') or {{}}"
    if output_mode == "context_block":
        return f"{body};print(d.get('context_block') or '')"
    if output_mode == "conflict_warning":
        return (
            f"{body};m=d.get('message','') if d.get('conflict') else '';"
            "print(('[WhyCode conflict] '+m) if m else '')"
        )
    if output_mode == "import_warning":
        return (
            f"{body};vs=d.get('violations') or [];"
            "print('\\n'.join('[WhyCode drift] '+str(v.get('constraint','')) "
            "for v in vs))"
        )
    raise ValueError(f"Unknown output_mode: {output_mode}")


def _build_python_hook_command(spec: HookSpec) -> str:
    """Windows / fallback hook — pure python3 + urllib, no shell deps."""
    timeout_s = max(1, spec.timeout_ms // 1000)
    payload_expr = _py_payload_expr(spec.payload_fields)
    output_snippet = _py_output_snippet(spec.output_mode, timeout_s)

    # Single-line Python. ``json.dumps`` handles payload escaping; the
    # token is formatted directly into the header string (it comes from
    # the vault and is controlled by WhyCode itself). Double quotes
    # wrap the -c argument, so the generated Python must avoid bare ``"``.
    python_code = (
        "import json,os,urllib.request;"
        f"p=json.dumps({payload_expr}).encode();"
        "r=urllib.request.Request("
        f"'{spec.server_url}{spec.endpoint}',"
        "data=p,"
        "headers={"
        "'Content-Type':'application/json',"
        f"'Authorization':'Bearer {spec.token}'"
        "},method='POST');"
        f"{output_snippet}"
    )

    # ``2>NUL`` swallows stderr (missing python3, network errors),
    # ``|| exit /b 0`` forces cmd.exe to return success either way so
    # Claude Code never blocks on a hook failure.
    return f'python3 -c "{python_code}" 2>NUL || exit /b 0'


# ---------------------------------------------------------------------------
# Linux / macOS — bash + curl (preserved historical behavior)
# ---------------------------------------------------------------------------


def _bash_payload_cmd(payload_fields: dict[str, str]) -> str:
    """Render the ``python3 -c '…'`` sub-command that builds the JSON body.

    The bash wrapper single-quotes this whole string, so we cannot use
    bare single quotes inside. JSON field names are wrapped with
    escaped double quotes.
    """
    parts = []
    for field, env_var in payload_fields.items():
        if field == "cwd":
            parts.append(
                f'\\"{field}\\": (os.environ.get(\\"{env_var}\\") or os.getcwd())'
            )
        else:
            parts.append(
                f'\\"{field}\\": os.environ.get(\\"{env_var}\\", \\"\\")'
            )
    keys = ", ".join(parts)
    return f'python3 -c "import json,os; print(json.dumps({{{keys}}}))"'


def _bash_extract_snippet(output_mode: OutputMode) -> str:
    """Return the Python one-liner that reads ``$response`` from stdin.

    Runs inside ``echo \"$response\" | python3 -c \"…\"`` so bare
    double quotes need escaping.
    """
    if output_mode == "none":
        return "pass"
    if output_mode == "context_block":
        return (
            "import json,sys; d=json.load(sys.stdin); "
            "print(d.get(\\\"context_block\\\") or \\\"\\\")"
        )
    if output_mode == "conflict_warning":
        return (
            "import json,sys; d=json.load(sys.stdin); "
            "m=d.get(\\\"message\\\",\\\"\\\") if d.get(\\\"conflict\\\") else \\\"\\\"; "
            "print(\\\"[WhyCode conflict] \\\"+m if m else \\\"\\\")"
        )
    if output_mode == "import_warning":
        return (
            "import json,sys; d=json.load(sys.stdin); "
            "vs=d.get(\\\"violations\\\") or []; "
            "print(\\\"\\\\n\\\".join(\\\"[WhyCode drift] \\\"+"
            "str(v.get(\\\"constraint\\\",\\\"\\\")) for v in vs))"
        )
    raise ValueError(f"Unknown output_mode: {output_mode}")


def _build_bash_hook_command(spec: HookSpec) -> str:
    """Linux / macOS hook — bash -lc + curl, preserved verbatim."""
    timeout_s = max(1, spec.timeout_ms // 1000)
    base_url = spec.server_url.rstrip("/")
    payload_cmd = _bash_payload_cmd(spec.payload_fields)
    extract_snippet = _bash_extract_snippet(spec.output_mode)

    curl_cmd = (
        f"curl -sS -m {timeout_s} -X POST "
        f'-H \\"Content-Type: application/json\\" '
        f'-H \\"Authorization: Bearer {spec.token}\\" '
        f'-d \\"$payload\\" '
        f'\\"{base_url}{spec.endpoint}\\" 2>/dev/null'
    )

    if spec.output_mode == "none":
        post_block = f"response=$({curl_cmd}) || exit 0; true"
    else:
        post_block = (
            f"response=$({curl_cmd}) || exit 0; "
            f'echo \\"$response\\" | python3 -c \\"{extract_snippet}\\" '
            "2>/dev/null || true"
        )

    return (
        f"bash -lc 'payload=$({payload_cmd}); "
        f"{post_block}'"
    )
