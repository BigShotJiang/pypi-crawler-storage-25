"""Sync WhyCode instructions into per-project MCP-client guidance files.

Handles three classes of file:

- ``CLAUDE.md`` — delegated to
  :func:`backend.utils.project_claude_md.write_project_claude_md`, which has
  its own mature ``## Project-Specific Instructions`` delimiter scheme. This
  module wraps that call so callers have a single entry point for all
  clients.
- ``.cursorrules`` / ``.windsurfrules`` / ``.clinerules`` — created if
  missing, otherwise the WhyCode-managed block delimited by
  ``<!-- WHYCODE:START -->`` / ``<!-- WHYCODE:END -->`` is updated in
  place. Any content outside those markers is preserved verbatim.

The non-CLAUDE.md files are always written (not gated on local IDE
installation) because these files belong in the user's project repository
and are read by teammates on other machines.

Security invariants enforced:
- SEC-02: Template strings never embed secrets — only project metadata
  provided by the caller.
- SEC-09: Files are created with the process default umask; callers are
  expected to commit them to source control, so they are world-readable
  by design (no tokens are embedded).
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Literal, TypedDict

from backend.utils.project_claude_md import write_project_claude_md

if TYPE_CHECKING:
    from pathlib import Path

ClientType = Literal["claude-code", "cursor", "windsurf", "cline"]

# Markers for non-CLAUDE.md files. HTML-style comments render as comments
# in plain text editors as well, so ``.cursorrules`` (raw text) and
# ``.windsurfrules`` both tolerate them without displaying visible noise
# in IDEs that parse these files.
WHYCODE_SECTION_START = "<!-- WHYCODE:START -->"
WHYCODE_SECTION_END = "<!-- WHYCODE:END -->"
# Legacy markers from when the project was named CodeLedger. Recognised on
# read so a single `whycode init` in a previously-initialised project
# upgrades the block in place instead of appending a duplicate.
_LEGACY_SECTION_START = "<!-- CODELEDGER:START -->"
_LEGACY_SECTION_END = "<!-- CODELEDGER:END -->"

_INSTRUCTION_FILES: dict[ClientType, str] = {
    "claude-code": "CLAUDE.md",
    "cursor": ".cursorrules",
    "windsurf": ".windsurfrules",
    "cline": ".clinerules",
}

_NON_CLAUDE_CLIENTS: frozenset[ClientType] = frozenset(
    {"cursor", "windsurf", "cline"}
)


class SyncResult(TypedDict):
    """Outcome of a single instruction-file sync."""

    action: Literal["created", "appended", "updated", "unchanged"]
    path: str
    existed_before: bool
    client: ClientType


def instruction_filename(client: ClientType) -> str:
    """Return the filename WhyCode writes for ``client``."""
    return _INSTRUCTION_FILES[client]


def _build_non_claude_section(
    project_id: str,
    project_name: str,
    server_url: str,
    client: ClientType,
    mode: str,
) -> str:
    """Render the WhyCode block written into ``.cursorrules`` et al.

    Tool names and signatures mirror the actual handlers in
    ``backend/mcp/tool_handlers.py`` so agents following these instructions
    will issue valid MCP tool calls.
    """
    client_label = client.replace("-", " ").title()
    return (
        f"{WHYCODE_SECTION_START}\n"
        f"# WhyCode — verified context for AI-assisted development\n"
        f"\n"
        f"## Connection\n"
        f"- Server: {server_url}\n"
        f"- Project: {project_name} (id: {project_id})\n"
        f"- Mode: {mode}\n"
        f"- Client: {client_label} (no client-side hooks — session "
        f"lifecycle runs on the server)\n"
        f"\n"
        f"## Before editing any file\n"
        f"Call `context.before_edit` with the file path and the current "
        f"content. The response returns any relevant decisions, active "
        f"conflicts on that file, and import constraints. Honor the "
        f"returned decisions — they are architectural constraints.\n"
        f"\n"
        f"## Before making architectural changes\n"
        f"Call `decision.create` with:\n"
        f"- `title` — imperative, under 72 characters\n"
        f"- `description` — the *why*, not the *what*\n"
        f"- `tags` — short labels, e.g. `[\"auth\", \"security\"]`\n"
        f"- `files_affected` — files that will change as a result\n"
        f"\n"
        f"## To understand why code exists\n"
        f"Call `provenance.reverse` with the file path and entity name. "
        f"The response includes the originating decision, change event, "
        f"and CI verification status.\n"
        f"\n"
        f"## To check codebase health\n"
        f"Call `drift.check` — returns any architectural violations. "
        f"Call `harness.score` after `session.end` for a quality summary.\n"
        f"\n"
        f"## Session lifecycle (managed on the server)\n"
        f"Your first tool call that includes `cwd`, `agent_name`, and "
        f"`project_id` opens or resumes a session and injects a context "
        f"block in the response under `session_context`. Sessions "
        f"auto-close after 30 minutes of inactivity (configurable in "
        f"`whycode.toml`). Call `session.end` explicitly when a logical "
        f"unit of work is finished; if it returns "
        f"`completed_with_warnings` with an `unlinked_files` list, either "
        f"record a `decision.create` for each or re-run with "
        f"`force: true` and an `override_reason`.\n"
        f"\n"
        f"Always pass `project_id=\"{project_id}\"` in tool calls.\n"
        f"\n"
        f"## Core tools\n"
        f"- `session.start` — open a coding session\n"
        f"- `session.end` — close session, run harness, check density\n"
        f"- `context.get_relevant` — semantic search over all decisions\n"
        f"- `context.get_for_file` — decisions governing a specific file\n"
        f"- `context.before_edit` — file context + conflict + drift check\n"
        f"- `decision.create` — record an architectural decision\n"
        f"- `decision.list` — list all decisions for this project\n"
        f"- `provenance.reverse` — why does this function exist?\n"
        f"- `provenance.forward` — what code did this decision produce?\n"
        f"- `drift.check` — check for architectural violations\n"
        f"- `harness.score` — quality scores for a session\n"
        f"- `rollback.plan` — impact analysis before reverting a decision\n"
        f"{WHYCODE_SECTION_END}"
    )


def _sync_non_claude_file(
    project_root: Path,
    project_id: str,
    project_name: str,
    server_url: str,
    client: ClientType,
    mode: str,
) -> SyncResult:
    """Create, update, or append the WhyCode section for a non-MD file."""
    filename = _INSTRUCTION_FILES[client]
    target = project_root / filename
    existed_before = target.exists()

    new_section = _build_non_claude_section(
        project_id=project_id,
        project_name=project_name,
        server_url=server_url,
        client=client,
        mode=mode,
    )

    if not existed_before:
        try:
            target.write_text(new_section + "\n", encoding="utf-8")
        except OSError as exc:
            raise OSError(f"Cannot write {target}: {exc}") from exc
        return SyncResult(
            action="created",
            path=str(target),
            existed_before=False,
            client=client,
        )

    try:
        existing = target.read_text(encoding="utf-8")
    except OSError as exc:
        raise OSError(f"Cannot read {target}: {exc}") from exc

    if WHYCODE_SECTION_START in existing or _LEGACY_SECTION_START in existing:
        start_marker = (
            WHYCODE_SECTION_START
            if WHYCODE_SECTION_START in existing
            else _LEGACY_SECTION_START
        )
        end_marker = (
            WHYCODE_SECTION_END
            if start_marker == WHYCODE_SECTION_START
            else _LEGACY_SECTION_END
        )
        pattern = re.compile(
            re.escape(start_marker) + r".*?" + re.escape(end_marker),
            re.DOTALL,
        )
        # ``re.sub`` treats the replacement string as a regex template —
        # use a lambda so backslashes and group-like sequences inside the
        # rendered section are inserted literally.
        updated = pattern.sub(lambda _m: new_section, existing, count=1)
        if updated == existing:
            return SyncResult(
                action="unchanged",
                path=str(target),
                existed_before=True,
                client=client,
            )
        try:
            target.write_text(updated, encoding="utf-8")
        except OSError as exc:
            raise OSError(f"Cannot write {target}: {exc}") from exc
        return SyncResult(
            action="updated",
            path=str(target),
            existed_before=True,
            client=client,
        )

    # File exists but has no WhyCode section — append, preserving
    # everything above and ensuring exactly one blank line of separation.
    preserved = existing.rstrip("\n") + "\n\n"
    try:
        target.write_text(preserved + new_section + "\n", encoding="utf-8")
    except OSError as exc:
        raise OSError(f"Cannot write {target}: {exc}") from exc
    return SyncResult(
        action="appended",
        path=str(target),
        existed_before=True,
        client=client,
    )


def _sync_claude_code_file(
    project_root: Path,
    project_name: str,
    server_url: str,
    change_detection_backend: str,
) -> SyncResult:
    """Sync CLAUDE.md through the existing managed-header machinery.

    The existing generator preserves everything at and below the
    ``## Project-Specific Instructions`` delimiter. We classify the outcome
    as ``created``/``updated``/``unchanged`` based on whether the file
    existed and whether its contents changed.
    """
    target = project_root / "CLAUDE.md"
    existed_before = target.exists()
    before = target.read_text(encoding="utf-8") if existed_before else ""

    path = write_project_claude_md(
        project_root=project_root,
        project_name=project_name,
        server_url=server_url,
        change_detection_backend=change_detection_backend,
    )

    after = path.read_text(encoding="utf-8")
    if not existed_before:
        action: Literal["created", "appended", "updated", "unchanged"] = "created"
    elif after == before:
        action = "unchanged"
    else:
        action = "updated"
    return SyncResult(
        action=action,
        path=str(path),
        existed_before=existed_before,
        client="claude-code",
    )


def sync_instruction_file(
    project_root: Path,
    project_id: str,
    project_name: str,
    server_url: str,
    client: ClientType,
    mode: str = "solo",
    change_detection_backend: str = "git",
) -> SyncResult:
    """Sync one client's instruction file.

    Args:
        project_root: Directory that receives the file.
        project_id: Stable project identifier used in tool-call arguments.
        project_name: Human-readable display name.
        server_url: Base URL of the running WhyCode server.
        client: Which client's file to write.
        mode: ``"solo"`` or ``"team"``; surfaced in the generated block.
        change_detection_backend: ``"git"`` or ``"file_watcher"``; only
            consumed by the CLAUDE.md generator.

    Returns:
        Structured result describing what happened to the file.

    Raises:
        ValueError: ``client`` is not a supported value, or
            ``change_detection_backend`` is invalid (CLAUDE.md only).
        OSError: ``project_root`` is not a writable directory.
    """
    if client not in _INSTRUCTION_FILES:
        raise ValueError(
            f"Unsupported client: {client!r}. "
            f"Expected one of: {sorted(_INSTRUCTION_FILES)}"
        )
    if not project_root.exists():
        raise OSError(f"Project root does not exist: {project_root}")
    if not project_root.is_dir():
        raise OSError(f"Project root is not a directory: {project_root}")

    if client == "claude-code":
        return _sync_claude_code_file(
            project_root=project_root,
            project_name=project_name,
            server_url=server_url,
            change_detection_backend=change_detection_backend,
        )
    return _sync_non_claude_file(
        project_root=project_root,
        project_id=project_id,
        project_name=project_name,
        server_url=server_url,
        client=client,
        mode=mode,
    )


def sync_all_instruction_files(
    project_root: Path,
    project_id: str,
    project_name: str,
    server_url: str,
    mode: str = "solo",
    change_detection_backend: str = "git",
    clients: tuple[ClientType, ...] = (
        "claude-code",
        "cursor",
        "windsurf",
        "cline",
    ),
) -> list[SyncResult]:
    """Sync instruction files for every client in ``clients``.

    By default every supported instruction file is written, regardless of
    whether the matching IDE is installed on the local machine: these
    files belong in the project repository, not in per-user IDE config.
    Pass a narrower ``clients`` tuple to restrict the sync.
    """
    results: list[SyncResult] = []
    for client in clients:
        results.append(
            sync_instruction_file(
                project_root=project_root,
                project_id=project_id,
                project_name=project_name,
                server_url=server_url,
                client=client,
                mode=mode,
                change_detection_backend=change_detection_backend,
            )
        )
    return results


def build_claude_desktop_guide(
    project_id: str,
    project_name: str,
    server_url: str,
) -> str:
    """Render the paste-into-Claude-Desktop guide.

    Claude Desktop has no project directory and does not read CLAUDE.md —
    users paste this guide at the start of a conversation to brief the
    model on the WhyCode tools and the project context.
    """
    return (
        "============================================================\n"
        "WHYCODE — CLAUDE DESKTOP GUIDE\n"
        "Paste this at the start of your Claude Desktop conversation\n"
        "============================================================\n"
        "\n"
        f"I have WhyCode running at {server_url}/mcp\n"
        f"Project: {project_name} (id: {project_id})\n"
        "\n"
        "You have access to these WhyCode MCP tools.\n"
        "\n"
        "BEFORE editing any file:\n"
        "  Call context.before_edit with the file path and current content.\n"
        "  Read the returned decisions — follow them.\n"
        "\n"
        "BEFORE making architectural decisions:\n"
        "  Call decision.create with title, description, tags,\n"
        "  and files_affected — record the decision first.\n"
        "\n"
        "TO understand why code exists:\n"
        "  Call provenance.reverse with the file path and entity name.\n"
        "\n"
        "TO check codebase health:\n"
        "  Call drift.check and harness.score.\n"
        "\n"
        "TO see all recorded decisions:\n"
        "  Call decision.list.\n"
        "\n"
        f"Always pass project_id=\"{project_id}\" with every tool call.\n"
        "\n"
        "============================================================\n"
    )
