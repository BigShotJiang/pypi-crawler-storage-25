"""Watchdog-based file change detection for non-git projects.

When a project has no ``.git/`` directory, WhyCode uses this module
instead of git hooks to detect structural code changes. Each modification
debounces briefly, takes a :class:`FileSnapshot` via :class:`SnapshotStore`,
compares it against the previous snapshot, and POSTs a unified diff to
``{server_url}/api/hooks/file-change`` so the downstream pipeline can
run tree-sitter analysis and audit SEC-11 completeness.

Security invariants enforced:
- SEC-02: HTTP errors are logged via the standard logger (which is
  sanitizer-wrapped by ``log_sanitizer.setup_logging``); request bodies
  never include credential material.
- SEC-05: Requests to ``/api/hooks/file-change`` carry the webhook secret
  header configured for the project; bearer auth is not used.
- Ignore patterns and extension filters prevent the watcher from
  snapshotting ``.git/`` internals, ``node_modules/``, build output, or
  the WhyCode data directory.
"""

from __future__ import annotations

import asyncio
import logging
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Protocol

import httpx
from watchdog.events import FileSystemEvent, FileSystemEventHandler
from watchdog.observers import Observer

from backend.utils.paths import normalise_path

if TYPE_CHECKING:
    from collections.abc import Callable

    from backend.utils.snapshot_store import SnapshotStore


_logger = logging.getLogger(__name__)


class _WatcherConfig(Protocol):
    """Structural subset of ``ChangeDetectionConfig`` consumed by the watcher."""

    watch_extensions: tuple[str, ...]
    debounce_ms: int
    ignore_patterns: tuple[str, ...]


@dataclass(frozen=True)
class _HookPayload:
    """Payload shape sent to ``POST /api/hooks/file-change``."""

    file_path: str
    project_id: str
    before_snapshot_id: str | None
    after_snapshot_id: str
    active_session_id: str | None

    def as_dict(self) -> dict[str, Any]:
        return {
            "file_path": self.file_path,
            "project_id": self.project_id,
            "before_snapshot_id": self.before_snapshot_id,
            "after_snapshot_id": self.after_snapshot_id,
            "active_session_id": self.active_session_id,
        }


def _should_ignore(
    path: str, project_root: Path, ignore_patterns: tuple[str, ...]
) -> bool:
    """Return True when ``path`` sits underneath an ignored directory."""
    try:
        rel = Path(path).resolve().relative_to(project_root.resolve())
    except ValueError:
        # Path is outside the project root — treat as ignored.
        return True
    parts = rel.parts
    for pattern in ignore_patterns:
        if not pattern:
            continue
        if pattern in parts:
            return True
    return False


def _matches_extension(path: str, extensions: tuple[str, ...]) -> bool:
    """Return True when ``path`` ends with one of the watched extensions."""
    if not extensions:
        return False
    suffix = Path(path).suffix
    return suffix in extensions


def _validate_path(file_path: str, project_root: Path) -> Path:
    """Reject resolved paths that escape ``project_root`` (path traversal)."""
    try:
        resolved = Path(file_path).expanduser().resolve()
        root_resolved = Path(project_root).expanduser().resolve()
    except OSError as exc:
        raise ValueError(f"Cannot resolve {file_path!r}: {exc}") from exc
    try:
        resolved.relative_to(root_resolved)
    except ValueError as exc:
        raise ValueError(
            f"Path traversal attempt: {resolved} is outside {root_resolved}"
        ) from exc
    return resolved


class WhyCodeEventHandler(FileSystemEventHandler):
    """Filter, debounce, and react to filesystem modifications.

    The handler does three things per structural file save:

    1. Filter out directories, non-matching extensions, and ignored paths.
    2. Debounce rapid saves (editors often emit two events per save).
    3. On the debounce trigger, call :meth:`SnapshotStore.take_snapshot`
       and — if the snapshot is new — POST a diff payload to the server.

    All network and database failures are caught and logged: the watcher
    must never crash the user's editor loop.
    """

    def __init__(
        self,
        project_root: Path,
        project_id: str,
        server_url: str,
        config: _WatcherConfig,
        snapshot_store: SnapshotStore,
        *,
        webhook_secret: str = "",
        loop: asyncio.AbstractEventLoop | None = None,
        http_post: Callable[[str, dict[str, Any], dict[str, str]], Any] | None = None,
        active_session_provider: Callable[[], str | None] | None = None,
    ) -> None:
        self._project_root = project_root
        self._project_id = project_id
        self._server_url = server_url.rstrip("/")
        self._config = config
        self._snapshot_store = snapshot_store
        self._webhook_secret = webhook_secret
        self._loop = loop
        self._http_post = http_post or _default_http_post
        self._active_session_provider = active_session_provider or (lambda: None)

        self._timers_lock = threading.Lock()
        self._timers: dict[str, threading.Timer] = {}

    # ------------------------------------------------------------------
    # Filtering + debounce (invoked by watchdog on its thread)
    # ------------------------------------------------------------------

    def on_modified(self, event: FileSystemEvent) -> None:
        """Schedule ``_process_modification`` after the configured debounce."""
        if event.is_directory:
            return
        path = str(event.src_path)
        if not _matches_extension(path, self._config.watch_extensions):
            return
        if _should_ignore(
            path, self._project_root, self._config.ignore_patterns
        ):
            return
        self._schedule(path)

    def on_created(self, event: FileSystemEvent) -> None:
        """Treat file creation identically to modification for snapshotting."""
        if event.is_directory:
            return
        path = str(event.src_path)
        if not _matches_extension(path, self._config.watch_extensions):
            return
        if _should_ignore(
            path, self._project_root, self._config.ignore_patterns
        ):
            return
        self._schedule(path)

    def _schedule(self, path: str) -> None:
        """Replace any existing debounce timer for ``path`` with a fresh one."""
        delay_s = max(self._config.debounce_ms, 0) / 1000.0
        with self._timers_lock:
            existing = self._timers.pop(path, None)
            if existing is not None:
                existing.cancel()
            timer = threading.Timer(
                delay_s, self._fire_debounced, args=(path,)
            )
            timer.daemon = True
            self._timers[path] = timer
            timer.start()

    def _fire_debounced(self, path: str) -> None:
        """Debounce expired — run the full processing pipeline for ``path``."""
        with self._timers_lock:
            self._timers.pop(path, None)
        try:
            self._process_modification(path)
        except Exception:
            _logger.exception(
                "file_watcher: unexpected error processing %s", path
            )

    # ------------------------------------------------------------------
    # Core pipeline — directly unit-testable
    # ------------------------------------------------------------------

    def _process_modification(self, file_path: str) -> None:
        """Take a snapshot and — if new — POST a diff to the server.

        Called directly by the debounce timer. Exceptions from snapshot
        persistence or the HTTP call are logged and swallowed. Rejects
        paths that resolve outside the configured project root
        (SEC path-traversal defence).
        """
        try:
            _validate_path(file_path, self._project_root)
        except ValueError as exc:
            _logger.warning("file_watcher: %s", exc)
            return
        # Forward-slash form so Windows watcher writes match Unix
        # downstream lookups (decisions.files_affected, provenance edges,
        # snapshot lookups). See docs/audits — paths are stored canonically.
        file_path = normalise_path(file_path)
        prior = self._run(
            self._snapshot_store.get_last_snapshot(
                file_path, self._project_id
            )
        )
        try:
            new_snapshot = self._run(
                self._snapshot_store.take_snapshot(
                    file_path, self._project_id
                )
            )
        except FileNotFoundError:
            _logger.debug(
                "file_watcher: %s disappeared before snapshot", file_path
            )
            return
        except PermissionError:
            _logger.warning(
                "file_watcher: permission denied reading %s", file_path
            )
            return
        except Exception as exc:
            _logger.warning(
                "file_watcher: snapshot failed for %s: %s", file_path, exc
            )
            return

        if prior is not None and prior.id == new_snapshot.id:
            # Content unchanged — no new snapshot was persisted.
            return

        payload = _HookPayload(
            file_path=file_path,
            project_id=self._project_id,
            before_snapshot_id=str(prior.id) if prior is not None else None,
            after_snapshot_id=str(new_snapshot.id),
            active_session_id=self._active_session_provider(),
        )
        self._post_hook(payload)

    def _post_hook(self, payload: _HookPayload) -> None:
        """POST to ``/api/hooks/file-change``; log and swallow all errors."""
        url = f"{self._server_url}/api/hooks/file-change"
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self._webhook_secret:
            headers["X-Webhook-Secret"] = self._webhook_secret
        try:
            self._http_post(url, payload.as_dict(), headers)
        except Exception as exc:
            _logger.warning(
                "file_watcher: failed to POST file-change hook for %s: %s",
                payload.file_path,
                exc,
            )

    # ------------------------------------------------------------------
    # asyncio helper
    # ------------------------------------------------------------------

    def _run(self, coro: Any) -> Any:
        """Run ``coro`` on the injected loop, or create one for this thread."""
        if self._loop is not None and self._loop.is_running():
            future = asyncio.run_coroutine_threadsafe(coro, self._loop)
            return future.result()
        return asyncio.run(coro)

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def cancel_pending(self) -> None:
        """Cancel every outstanding debounce timer (used on shutdown)."""
        with self._timers_lock:
            for timer in self._timers.values():
                timer.cancel()
            self._timers.clear()


def _default_http_post(
    url: str, payload: dict[str, Any], headers: dict[str, str]
) -> None:
    """Default synchronous POST used when no custom ``http_post`` is provided."""
    with httpx.Client(timeout=5.0) as client:
        client.post(url, json=payload, headers=headers)


class WhyCodeFileWatcher:
    """Daemon-thread watchdog wrapper for the file-watcher backend.

    Lifecycle:

    * :meth:`start` creates an :class:`Observer`, schedules the
      :class:`WhyCodeEventHandler` on ``project_root`` recursively,
      and starts the observer's daemon thread.
    * :meth:`stop` cancels outstanding debounce timers and stops the
      observer cleanly.
    * :meth:`is_running` reflects the observer thread's ``is_alive``
      state.
    """

    def __init__(
        self,
        project_root: Path,
        project_id: str,
        server_url: str,
        config: _WatcherConfig,
        snapshot_store: SnapshotStore,
        *,
        webhook_secret: str = "",
        loop: asyncio.AbstractEventLoop | None = None,
        observer_factory: Callable[[], Any] | None = None,
        http_post: Callable[[str, dict[str, Any], dict[str, str]], Any] | None = None,
        active_session_provider: Callable[[], str | None] | None = None,
    ) -> None:
        if not isinstance(project_root, Path):
            raise TypeError(
                f"project_root must be a Path, got {type(project_root).__name__}"
            )
        if not isinstance(project_id, str) or not project_id:
            raise ValueError("project_id must be a non-empty string")
        if not isinstance(server_url, str) or not server_url:
            raise ValueError("server_url must be a non-empty string")
        self._project_root = project_root
        self._handler = WhyCodeEventHandler(
            project_root=project_root,
            project_id=project_id,
            server_url=server_url,
            config=config,
            snapshot_store=snapshot_store,
            webhook_secret=webhook_secret,
            loop=loop,
            http_post=http_post,
            active_session_provider=active_session_provider,
        )
        self._observer_factory = observer_factory or Observer
        self._observer: Any = None

    def start(self) -> None:
        """Create the observer and begin watching ``project_root`` recursively."""
        if self._observer is not None:
            return
        observer = self._observer_factory()
        observer.schedule(
            self._handler, str(self._project_root), recursive=True
        )
        observer.daemon = True
        observer.start()
        self._observer = observer

    def stop(self) -> None:
        """Stop the observer and cancel any pending debounce timers."""
        self._handler.cancel_pending()
        observer = self._observer
        if observer is None:
            return
        try:
            observer.stop()
            if hasattr(observer, "join"):
                observer.join(timeout=2.0)
        except Exception as exc:
            _logger.warning("file_watcher: observer stop failed: %s", exc)
        finally:
            self._observer = None

    def is_running(self) -> bool:
        """Return True when the observer thread is alive."""
        observer = self._observer
        if observer is None:
            return False
        is_alive = getattr(observer, "is_alive", None)
        if callable(is_alive):
            result = is_alive()
            return bool(result)
        return True

    @property
    def handler(self) -> WhyCodeEventHandler:
        """Expose the handler for direct unit-test access."""
        return self._handler
