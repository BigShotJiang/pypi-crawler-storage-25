"""Embedding clients: Ollama (default) and sentence-transformers (local fallback).

Both backends produce float vectors from text. ``OllamaEmbedder`` talks to
a running Ollama server on localhost and produces 768-dim vectors for the
``nomic-embed-text`` model. ``SentenceTransformerEmbedder`` runs fully
in-process using ``sentence-transformers`` and the 384-dim
``all-MiniLM-L6-v2`` model — no server, no model pull, installs as a pip
optional dependency.

The ``Embedder`` name is preserved as an alias of :class:`OllamaEmbedder`
for backward compatibility with existing call sites. Use
:func:`get_embedder` to select the right implementation based on the
caller's :class:`EmbeddingConfig`.

Security invariants enforced:
- SEC-02: No credentials in logs. Ollama is called unauthenticated on
  localhost; request metadata written to logs flows through the
  sanitising formatter in ``backend.utils.log_sanitizer``.
- The local backend runs entirely on the machine — no network I/O at
  embedding time, so there is nothing to leak in flight.
"""

from __future__ import annotations

import asyncio
import logging

# Any: Ollama JSON response bodies use a dynamic shape.
from typing import TYPE_CHECKING, Any, Protocol

import httpx

if TYPE_CHECKING:
    from backend.config import EmbeddingConfig

logger = logging.getLogger(__name__)

EMBEDDING_DIM = 768  # Ollama default; kept for backward compatibility.
LOCAL_EMBEDDING_DIM = 384  # sentence-transformers all-MiniLM-L6-v2.


class EmbeddingError(Exception):
    """Raised when embedding generation fails and cannot be retried."""


class OllamaNotRunningError(EmbeddingError):
    """Raised when the Ollama server is unreachable."""


class OllamaModelNotFoundError(EmbeddingError):
    """Raised when the configured model is not available on the Ollama server."""


class BaseEmbedder(Protocol):
    """Protocol shared by the Ollama and local embedding backends."""

    async def embed_text(self, text: str) -> list[float]:
        ...

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        ...


class OllamaEmbedder:
    """Async embedding client for the Ollama ``/api/embeddings`` endpoint.

    The constructor does not perform network I/O so that instances can be
    created at application start without requiring Ollama to be already
    running. Use ``verify()`` to confirm reachability and model availability
    when the caller wants an early failure signal.
    """

    def __init__(
        self,
        config: EmbeddingConfig,
        *,
        timeout_seconds: float = 30.0,
        max_retries: int = 3,
        initial_backoff_seconds: float = 0.5,
    ) -> None:
        self._config = config
        self._timeout = timeout_seconds
        self._max_retries = max_retries
        self._initial_backoff = initial_backoff_seconds
        self._base_url = config.ollama_url.rstrip("/")
        self._model = config.model
        self._batch_size = max(1, config.batch_size)

    @property
    def model(self) -> str:
        """The configured embedding model name."""
        return self._model

    @property
    def batch_size(self) -> int:
        """The configured concurrency ceiling for batch calls."""
        return self._batch_size

    async def verify(self) -> None:
        """Raise if Ollama is unreachable or the configured model is absent.

        Called explicitly by code that wants a startup-time check.
        ``embed_text``/``embed_batch`` also raise the same exceptions on
        first use, so ``verify`` is optional.

        Raises:
            OllamaNotRunningError: Ollama server did not respond.
            OllamaModelNotFoundError: Server responded but the configured
                model is not listed among available models.
        """
        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                response = await client.get(f"{self._base_url}/api/tags")
                response.raise_for_status()
                data = response.json()
        except httpx.ConnectError as exc:
            raise OllamaNotRunningError(
                f"Cannot reach Ollama at {self._base_url}. "
                f"Start Ollama with: curl -fsSL https://ollama.com/install.sh | sh"
            ) from exc
        except httpx.HTTPError as exc:
            raise OllamaNotRunningError(
                f"Ollama HTTP error at {self._base_url}: {exc}"
            ) from exc

        models = {m.get("name", "").split(":")[0] for m in data.get("models", [])}
        if self._model not in models and self._model.split(":")[0] not in models:
            raise OllamaModelNotFoundError(
                f"Model '{self._model}' not available. Run: ollama pull {self._model}"
            )

    async def embed_text(self, text: str) -> list[float]:
        """Generate an embedding vector for a single text string.

        Args:
            text: Input text. Empty strings are accepted but Ollama still
                returns a zero-ish vector; callers should filter upstream
                when possible.

        Returns:
            768-dimensional vector as a list of floats.

        Raises:
            OllamaNotRunningError: Ollama unreachable after retries.
            OllamaModelNotFoundError: Model missing on the server.
            EmbeddingError: Other failure after retries exhausted.
        """
        if not isinstance(text, str):
            raise TypeError(f"embed_text requires str, got {type(text).__name__}")
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            return await self._embed_one(client, text)

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings for multiple text strings, preserving order.

        Dispatches up to ``batch_size`` requests concurrently using a
        semaphore so Ollama does not receive more simultaneous requests
        than the pool configured in ``EmbeddingConfig``. Order of the
        returned list matches the order of ``texts``.

        Args:
            texts: List of strings. Empty list returns ``[]`` without
                making any HTTP calls.

        Returns:
            List of 768-dimensional vectors, one per input, in order.

        Raises:
            Same as ``embed_text``; the first failure aborts the batch.
        """
        if not isinstance(texts, list):
            raise TypeError(f"embed_batch requires list, got {type(texts).__name__}")
        if not texts:
            return []
        for i, item in enumerate(texts):
            if not isinstance(item, str):
                raise TypeError(
                    f"embed_batch requires list[str], item {i} is {type(item).__name__}"
                )

        sem = asyncio.Semaphore(self._batch_size)

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            async def embed_guarded(t: str) -> list[float]:
                async with sem:
                    return await self._embed_one(client, t)

            return await asyncio.gather(*(embed_guarded(t) for t in texts))

    async def _embed_one(
        self,
        client: httpx.AsyncClient,
        text: str,
    ) -> list[float]:
        """Issue one embedding request with retry on transient failures.

        Retries on network-level errors and HTTP 5xx with exponential
        backoff. 404 (model missing) and 400 (bad request) are non-transient
        and raise immediately.
        """
        url = f"{self._base_url}/api/embeddings"
        payload = {"model": self._model, "prompt": text}

        last_exc: Exception | None = None
        backoff = self._initial_backoff

        for attempt in range(1, self._max_retries + 1):
            try:
                response = await client.post(url, json=payload)
            except (httpx.ConnectError, httpx.ReadError, httpx.WriteError) as exc:
                last_exc = exc
                logger.warning(
                    "Ollama connection error attempt %d/%d: %s",
                    attempt,
                    self._max_retries,
                    exc.__class__.__name__,
                )
                if attempt == self._max_retries:
                    raise OllamaNotRunningError(
                        f"Cannot reach Ollama at {self._base_url} after "
                        f"{self._max_retries} attempts: {exc}"
                    ) from exc
                await asyncio.sleep(backoff)
                backoff *= 2
                continue
            except httpx.TimeoutException as exc:
                last_exc = exc
                logger.warning(
                    "Ollama timeout attempt %d/%d after %.1fs",
                    attempt,
                    self._max_retries,
                    self._timeout,
                )
                if attempt == self._max_retries:
                    raise EmbeddingError(
                        f"Ollama timeout after {self._max_retries} attempts"
                    ) from exc
                await asyncio.sleep(backoff)
                backoff *= 2
                continue

            if response.status_code == 404:
                raise OllamaModelNotFoundError(
                    f"Model '{self._model}' not found on Ollama server. "
                    f"Run: ollama pull {self._model}"
                )

            if response.status_code == 400:
                raise EmbeddingError(
                    f"Ollama rejected request (400): {response.text[:200]}"
                )

            if response.status_code >= 500:
                last_exc = httpx.HTTPStatusError(
                    f"Server error {response.status_code}",
                    request=response.request,
                    response=response,
                )
                logger.warning(
                    "Ollama 5xx attempt %d/%d: %d",
                    attempt,
                    self._max_retries,
                    response.status_code,
                )
                if attempt == self._max_retries:
                    raise EmbeddingError(
                        f"Ollama server error {response.status_code} after "
                        f"{self._max_retries} attempts"
                    ) from last_exc
                await asyncio.sleep(backoff)
                backoff *= 2
                continue

            if response.status_code != 200:
                raise EmbeddingError(
                    f"Unexpected Ollama status {response.status_code}: "
                    f"{response.text[:200]}"
                )

            return self._parse_embedding_response(response.json())

        # Unreachable: loop body either returns or raises on the final attempt
        raise EmbeddingError(
            f"Embedding failed after {self._max_retries} attempts"
        ) from last_exc

    def _parse_embedding_response(
        self, data: dict[str, Any]
    ) -> list[float]:
        """Extract the embedding vector from Ollama's JSON response.

        Ollama's v0.4+ response shape is ``{"embedding": [...]}`` for the
        legacy ``/api/embeddings`` endpoint.
        """
        vector = data.get("embedding")
        if not isinstance(vector, list) or not vector:
            raise EmbeddingError(
                f"Ollama response missing 'embedding' field: {str(data)[:200]}"
            )
        if not all(isinstance(x, int | float) for x in vector):
            raise EmbeddingError("Ollama embedding contains non-numeric values")
        result = [float(x) for x in vector]
        if len(result) != EMBEDDING_DIM:
            logger.warning(
                "Embedding dimension %d does not match expected %d",
                len(result),
                EMBEDDING_DIM,
            )
        return result


# ---------------------------------------------------------------------------
# Local sentence-transformers backend
# ---------------------------------------------------------------------------


class SentenceTransformerEmbedder:
    """In-process embedding backend using ``sentence-transformers``.

    Defaults to ``all-MiniLM-L6-v2`` — 22M params, 384-dim output, ~90MB
    on disk, CPU-friendly. The model is downloaded from Hugging Face the
    first time it is used and cached under the user's transformers cache
    directory (no network I/O on subsequent runs).

    The underlying library is synchronous — we run ``model.encode`` in a
    thread executor so the server event loop stays responsive.
    """

    def __init__(
        self,
        config: EmbeddingConfig,
        *,
        batch_size: int | None = None,
    ) -> None:
        try:
            from sentence_transformers import SentenceTransformer  # type: ignore[import-not-found]
        except ImportError as exc:
            raise EmbeddingError(
                "sentence-transformers is not installed. "
                "Install with: pip install 'whycode[local-embed]'"
            ) from exc
        self._config = config
        self._model_name = config.local_model
        self._batch_size = batch_size or max(1, config.batch_size)
        self._model = SentenceTransformer(self._model_name)

    @property
    def model(self) -> str:
        """The configured local model name."""
        return self._model_name

    @property
    def batch_size(self) -> int:
        """Batch size for ``embed_batch``."""
        return self._batch_size

    async def verify(self) -> None:
        """No-op for the local backend — the model is loaded in __init__."""
        return None

    async def embed_text(self, text: str) -> list[float]:
        """Encode a single string to a 384-dim vector."""
        if not isinstance(text, str):
            raise TypeError(
                f"embed_text requires str, got {type(text).__name__}"
            )
        loop = asyncio.get_running_loop()
        vector = await loop.run_in_executor(
            None, self._encode_one, text
        )
        return vector

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        """Encode a list of strings, preserving input order."""
        if not isinstance(texts, list):
            raise TypeError(
                f"embed_batch requires list, got {type(texts).__name__}"
            )
        if not texts:
            return []
        for i, item in enumerate(texts):
            if not isinstance(item, str):
                raise TypeError(
                    f"embed_batch requires list[str], item {i} is "
                    f"{type(item).__name__}"
                )
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self._encode_many, texts)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _encode_one(self, text: str) -> list[float]:
        vec = self._model.encode(text, convert_to_numpy=False)
        # sentence-transformers returns torch.Tensor or numpy array — normalise
        # to a plain Python list of floats.
        if hasattr(vec, "tolist"):
            vec = vec.tolist()
        return [float(x) for x in vec]

    def _encode_many(self, texts: list[str]) -> list[list[float]]:
        vectors = self._model.encode(
            texts,
            batch_size=self._batch_size,
            convert_to_numpy=False,
        )
        return [
            [float(x) for x in (v.tolist() if hasattr(v, "tolist") else v)]
            for v in vectors
        ]


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


# Backward-compatible alias — legacy code constructs ``Embedder(config)`` and
# expects the Ollama client. The name lives on; dispatch goes through
# :func:`get_embedder` for new callers.
Embedder = OllamaEmbedder


def get_embedder(config: EmbeddingConfig) -> BaseEmbedder:
    """Return the embedder implementation selected by ``config.backend``.

    * ``"ollama"`` → :class:`OllamaEmbedder` (unchanged default).
    * ``"local"`` → :class:`SentenceTransformerEmbedder`.

    Raises:
        EmbeddingError: ``config.backend`` is unknown.
    """
    backend = getattr(config, "backend", "ollama")
    if backend == "ollama":
        return OllamaEmbedder(config)
    if backend == "local":
        return SentenceTransformerEmbedder(config)
    raise EmbeddingError(f"Unknown embedding backend: {backend!r}")
