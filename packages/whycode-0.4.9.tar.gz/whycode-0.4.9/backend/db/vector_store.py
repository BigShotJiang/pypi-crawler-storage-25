"""Vector store abstraction with sqlite-vec and pgvector backends.

Provides similarity search over embedding vectors for semantic retrieval.
Both backends store per-item metadata (including ``project_id`` for
multi-project isolation) and return cosine-similarity-ordered results.

Vectors are unit-normalised on insert and query so the backend-native
cosine distance (``sqlite-vec`` ``vec0`` with ``distance_metric=cosine``
or ``pgvector`` ``<=>``) maps onto a common ``score = 1 - distance``
in the range ``[-1.0, 1.0]`` — higher is more similar, ``1.0`` means
identical direction, ``0.0`` means orthogonal, ``-1.0`` means opposite
direction. The score is included on every ``search`` result.

Security invariants enforced:
- SEC-01: The vector store holds only embedding vectors and metadata
  supplied by the semantic-search pipeline. It does not persist tokens,
  API keys, passwords, or any secret material. Callers are expected to
  keep metadata free of credentials; embeddings themselves are one-way
  lossy representations of input text.
- No dynamic SQL composition from caller input — table and column names
  are hard-coded; every value is bound through a parameterised placeholder.
"""

from __future__ import annotations

import abc
import asyncio
import json
import math
import os
import sqlite3
from pathlib import Path
from typing import TYPE_CHECKING, Any  # Any: asyncpg Pool not reliably typed

if TYPE_CHECKING:
    from backend.config import DatabaseConfig


DEFAULT_DIM = 768


class VectorStoreError(Exception):
    """Raised for vector store operation failures."""


def _normalize(vector: list[float]) -> list[float]:
    """Return a unit-length copy of ``vector``. Zero vectors pass through unchanged."""
    squared_sum = 0.0
    for x in vector:
        squared_sum += x * x
    if squared_sum == 0.0:
        return [float(x) for x in vector]
    scale = 1.0 / math.sqrt(squared_sum)
    return [float(x) * scale for x in vector]


def _validate_vector(vector: object, dim: int) -> list[float]:
    """Reject non-list or wrong-dimension vectors; coerce numeric entries to float."""
    if not isinstance(vector, list):
        raise VectorStoreError(
            f"vector must be list[float], got {type(vector).__name__}"
        )
    if len(vector) != dim:
        raise VectorStoreError(
            f"vector length {len(vector)} does not match configured dim {dim}"
        )
    result: list[float] = []
    for i, x in enumerate(vector):
        if isinstance(x, bool) or not isinstance(x, int | float):
            raise VectorStoreError(
                f"vector[{i}] must be numeric, got {type(x).__name__}"
            )
        result.append(float(x))
    return result


def _validate_item_id(item_id: object) -> str:
    if not isinstance(item_id, str) or not item_id:
        raise VectorStoreError("item_id must be a non-empty string")
    return item_id


def _validate_metadata(metadata: object) -> dict[str, Any]:
    if not isinstance(metadata, dict):
        raise VectorStoreError(
            f"metadata must be dict, got {type(metadata).__name__}"
        )
    return metadata


def _extract_project_id(metadata: dict[str, Any]) -> str | None:
    """Pull ``project_id`` from metadata, enforcing str-or-None type."""
    project_id = metadata.get("project_id")
    if project_id is None:
        return None
    if not isinstance(project_id, str):
        raise VectorStoreError(
            f"metadata['project_id'] must be string, got {type(project_id).__name__}"
        )
    return project_id


def _vector_to_pg_literal(vector: list[float]) -> str:
    """Serialise a vector as a pgvector string literal ``[x,y,z]``."""
    return "[" + ",".join(repr(float(x)) for x in vector) + "]"


# ---------------------------------------------------------------------------
# Abstract interface
# ---------------------------------------------------------------------------


class VectorStore(abc.ABC):
    """Async interface for embedding storage and similarity search."""

    @abc.abstractmethod
    async def connect(self) -> None:
        """Open the underlying connection or pool and ensure tables exist."""

    @abc.abstractmethod
    async def close(self) -> None:
        """Release all connections held by the store."""

    @abc.abstractmethod
    async def insert(
        self,
        item_id: str,
        vector: list[float],
        metadata: dict[str, Any],
    ) -> None:
        """Persist an embedding vector keyed by ``item_id`` with arbitrary metadata.

        ``metadata['project_id']`` — when present and a string — is indexed
        separately for project-scoped filtering in ``search`` and ``count``.
        """

    @abc.abstractmethod
    async def search(
        self,
        query_vector: list[float],
        top_k: int = 10,
        project_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """Return the top-K most similar items.

        Each result is a dict with ``item_id``, ``score`` (cosine similarity
        in the range ``[-1.0, 1.0]`` — ``1.0`` identical, ``0.0`` orthogonal,
        ``-1.0`` opposite), and ``metadata``. When ``project_id`` is provided,
        only items whose stored ``metadata['project_id']`` matches are
        returned.
        """

    @abc.abstractmethod
    async def get(self, item_id: str) -> dict[str, Any] | None:
        """Return stored metadata for ``item_id`` or ``None`` if absent.

        Used by ``semantic_search.SemanticSearch.reindex_item`` to preserve
        ``item_type`` and ``project_id`` when replacing an entry's text.
        """

    @abc.abstractmethod
    async def delete(self, item_id: str) -> None:
        """Remove the embedding for ``item_id``. Silent no-op when absent."""

    @abc.abstractmethod
    async def delete_by_project(self, project_id: str) -> None:
        """Remove every embedding belonging to ``project_id``."""

    @abc.abstractmethod
    async def count(self, project_id: str | None = None) -> int:
        """Return the number of stored vectors, optionally scoped to a project."""


# ---------------------------------------------------------------------------
# SQLite + sqlite-vec backend
# ---------------------------------------------------------------------------


class SqliteVssStore(VectorStore):
    """SQLite + sqlite-vec implementation.

    Uses an auxiliary ``vector_metadata`` table to associate ``item_id`` and
    ``project_id`` with virtual-table ``rowid`` values. This enables
    project-scoped filtering on top of the ``vec0`` similarity-search virtual
    table which does not support arbitrary WHERE predicates itself.

    The connection is a synchronous ``sqlite3.Connection`` run on a worker
    thread via ``asyncio.to_thread`` — ``aiosqlite`` does not expose
    ``enable_load_extension`` in its public API, which ``sqlite_vec`` requires.
    WAL mode is enabled so this store can coexist with the main
    ``SQLiteBackend`` on the same database file.

    The class name ``SqliteVssStore`` is retained for API stability across
    the sqlite-vss → sqlite-vec migration in 0.1.2.
    """

    def __init__(self, db_path: str | Path, *, dim: int = DEFAULT_DIM) -> None:
        self._db_path = str(db_path)
        self._dim = dim
        self._conn: sqlite3.Connection | None = None
        self._lock = asyncio.Lock()

    @property
    def dim(self) -> int:
        """Configured embedding dimensionality."""
        return self._dim

    async def connect(self) -> None:
        def _open() -> sqlite3.Connection:
            import sqlite_vec  # type: ignore[import-untyped]  # no stubs

            db_path = Path(self._db_path)
            db_path.parent.mkdir(parents=True, exist_ok=True)
            # check_same_thread=False: ``asyncio.to_thread`` borrows workers
            # from a pool, so operations do not consistently land on the
            # creating thread. Serialisation is enforced by ``self._lock``
            # around every operation instead.
            conn = sqlite3.connect(
                self._db_path,
                isolation_level=None,
                check_same_thread=False,
            )
            conn.row_factory = sqlite3.Row
            try:
                conn.enable_load_extension(True)
                sqlite_vec.load(conn)
                conn.enable_load_extension(False)
            except sqlite3.OperationalError as exc:
                conn.close()
                raise VectorStoreError(
                    f"Failed to load sqlite-vec extension: {exc}"
                ) from exc

            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS vector_metadata (
                    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
                    item_id TEXT UNIQUE NOT NULL,
                    project_id TEXT,
                    metadata TEXT NOT NULL
                )
                """
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_vm_project "
                "ON vector_metadata(project_id)"
            )
            conn.execute(
                f"CREATE VIRTUAL TABLE IF NOT EXISTS vec_items "
                f"USING vec0(embedding float[{self._dim}] distance_metric=cosine)"
            )
            return conn

        try:
            self._conn = await asyncio.to_thread(_open)
        except VectorStoreError:
            raise
        except sqlite3.Error as exc:
            raise VectorStoreError(f"Failed to open SQLite database: {exc}") from exc

    async def close(self) -> None:
        conn = self._conn
        if conn is None:
            return
        self._conn = None
        try:
            await asyncio.to_thread(conn.close)
        except sqlite3.Error as exc:
            raise VectorStoreError(f"Failed to close SQLite connection: {exc}") from exc

    def _require_conn(self) -> sqlite3.Connection:
        if self._conn is None:
            raise VectorStoreError("SqliteVssStore is not connected")
        return self._conn

    async def insert(
        self,
        item_id: str,
        vector: list[float],
        metadata: dict[str, Any],
    ) -> None:
        import sqlite_vec  # type: ignore[import-untyped]  # no stubs

        item_id = _validate_item_id(item_id)
        metadata = _validate_metadata(metadata)
        validated = _validate_vector(vector, self._dim)
        project_id = _extract_project_id(metadata)
        try:
            meta_json = json.dumps(metadata)
        except (TypeError, ValueError) as exc:
            raise VectorStoreError(f"metadata is not JSON-serialisable: {exc}") from exc
        vec_blob = sqlite_vec.serialize_float32(_normalize(validated))
        conn = self._require_conn()

        def _run() -> None:
            conn.execute("BEGIN")
            try:
                cursor = conn.execute(
                    "INSERT INTO vector_metadata (item_id, project_id, metadata) "
                    "VALUES (?, ?, ?)",
                    (item_id, project_id, meta_json),
                )
                rowid = cursor.lastrowid
                if rowid is None:
                    raise VectorStoreError(
                        f"Insert did not produce a rowid for {item_id!r}"
                    )
                conn.execute(
                    "INSERT INTO vec_items(rowid, embedding) VALUES (?, ?)",
                    (rowid, vec_blob),
                )
                conn.execute("COMMIT")
            except sqlite3.IntegrityError as exc:
                conn.execute("ROLLBACK")
                raise VectorStoreError(
                    f"item_id {item_id!r} already exists"
                ) from exc
            except sqlite3.Error as exc:
                conn.execute("ROLLBACK")
                raise VectorStoreError(f"Insert failed: {exc}") from exc

        async with self._lock:
            await asyncio.to_thread(_run)

    async def search(
        self,
        query_vector: list[float],
        top_k: int = 10,
        project_id: str | None = None,
    ) -> list[dict[str, Any]]:
        import sqlite_vec  # type: ignore[import-untyped]  # no stubs

        if not isinstance(top_k, int) or isinstance(top_k, bool) or top_k <= 0:
            raise VectorStoreError(f"top_k must be a positive int, got {top_k!r}")
        if project_id is not None and not isinstance(project_id, str):
            raise VectorStoreError("project_id must be a string when provided")
        validated = _validate_vector(query_vector, self._dim)
        vec_blob = sqlite_vec.serialize_float32(_normalize(validated))
        # Over-fetch when filtering by project so we still have top_k matches
        # after the project predicate trims vec0 MATCH output.
        inner_limit = top_k * 10 if project_id is not None else top_k
        conn = self._require_conn()

        def _run() -> list[dict[str, Any]]:
            # Short-circuit on an empty index. Defensive even though vec0
            # handles empty indexes cleanly — keeps behaviour consistent
            # with the old sqlite-vss path.
            try:
                probe = conn.execute(
                    "SELECT 1 FROM vector_metadata LIMIT 1"
                ).fetchone()
            except sqlite3.Error as exc:
                raise VectorStoreError(f"Search failed: {exc}") from exc
            if probe is None:
                return []

            sql_parts = [
                "SELECT vm.item_id AS item_id, vm.metadata AS metadata, "
                "s.distance AS distance ",
                "FROM (",
                "  SELECT rowid, distance FROM vec_items ",
                "  WHERE embedding MATCH ? ",
                "  ORDER BY distance ",
                "  LIMIT ?",
                ") s ",
                "JOIN vector_metadata vm ON s.rowid = vm.rowid ",
            ]
            params: list[Any] = [vec_blob, inner_limit]
            if project_id is not None:
                sql_parts.append("WHERE vm.project_id = ? ")
                params.append(project_id)
            sql_parts.append("ORDER BY s.distance LIMIT ?")
            params.append(top_k)
            try:
                cursor = conn.execute("".join(sql_parts), tuple(params))
                rows = cursor.fetchall()
            except sqlite3.Error as exc:
                raise VectorStoreError(f"Search failed: {exc}") from exc

            results: list[dict[str, Any]] = []
            for row in rows:
                try:
                    meta = json.loads(row["metadata"])
                    if not isinstance(meta, dict):
                        meta = {}
                except json.JSONDecodeError:
                    meta = {}
                # vec0 with distance_metric=cosine returns cosine distance
                # directly; score = 1 - distance gives cosine similarity
                # in [-1.0, 1.0].
                distance = float(row["distance"])
                score = 1.0 - distance
                if score < -1.0:
                    score = -1.0
                elif score > 1.0:
                    score = 1.0
                results.append(
                    {"item_id": row["item_id"], "score": score, "metadata": meta}
                )
            return results

        async with self._lock:
            return await asyncio.to_thread(_run)

    async def get(self, item_id: str) -> dict[str, Any] | None:
        item_id = _validate_item_id(item_id)
        conn = self._require_conn()

        def _run() -> dict[str, Any] | None:
            try:
                cursor = conn.execute(
                    "SELECT metadata FROM vector_metadata WHERE item_id = ?",
                    (item_id,),
                )
                row = cursor.fetchone()
            except sqlite3.Error as exc:
                raise VectorStoreError(f"Get failed: {exc}") from exc
            if row is None:
                return None
            try:
                meta = json.loads(row["metadata"])
            except json.JSONDecodeError:
                return {}
            if not isinstance(meta, dict):
                return {}
            return meta

        async with self._lock:
            return await asyncio.to_thread(_run)

    async def delete(self, item_id: str) -> None:
        item_id = _validate_item_id(item_id)
        conn = self._require_conn()

        def _run() -> None:
            conn.execute("BEGIN")
            try:
                cursor = conn.execute(
                    "SELECT rowid FROM vector_metadata WHERE item_id = ?",
                    (item_id,),
                )
                row = cursor.fetchone()
                if row is None:
                    conn.execute("ROLLBACK")
                    return
                rowid = int(row["rowid"])
                conn.execute("DELETE FROM vec_items WHERE rowid = ?", (rowid,))
                conn.execute(
                    "DELETE FROM vector_metadata WHERE item_id = ?", (item_id,)
                )
                conn.execute("COMMIT")
            except sqlite3.Error as exc:
                conn.execute("ROLLBACK")
                raise VectorStoreError(f"Delete failed: {exc}") from exc

        async with self._lock:
            await asyncio.to_thread(_run)

    async def delete_by_project(self, project_id: str) -> None:
        if not isinstance(project_id, str) or not project_id:
            raise VectorStoreError("project_id must be a non-empty string")
        conn = self._require_conn()

        def _run() -> None:
            conn.execute("BEGIN")
            try:
                cursor = conn.execute(
                    "SELECT rowid FROM vector_metadata WHERE project_id = ?",
                    (project_id,),
                )
                rowids = [int(r["rowid"]) for r in cursor.fetchall()]
                for rowid in rowids:
                    conn.execute("DELETE FROM vec_items WHERE rowid = ?", (rowid,))
                conn.execute(
                    "DELETE FROM vector_metadata WHERE project_id = ?",
                    (project_id,),
                )
                conn.execute("COMMIT")
            except sqlite3.Error as exc:
                conn.execute("ROLLBACK")
                raise VectorStoreError(f"delete_by_project failed: {exc}") from exc

        async with self._lock:
            await asyncio.to_thread(_run)

    async def count(self, project_id: str | None = None) -> int:
        if project_id is not None and not isinstance(project_id, str):
            raise VectorStoreError("project_id must be a string when provided")
        conn = self._require_conn()

        def _run() -> int:
            try:
                if project_id is None:
                    cursor = conn.execute(
                        "SELECT COUNT(*) AS c FROM vector_metadata"
                    )
                else:
                    cursor = conn.execute(
                        "SELECT COUNT(*) AS c FROM vector_metadata "
                        "WHERE project_id = ?",
                        (project_id,),
                    )
                row = cursor.fetchone()
            except sqlite3.Error as exc:
                raise VectorStoreError(f"Count failed: {exc}") from exc
            return int(row["c"]) if row is not None else 0

        async with self._lock:
            return await asyncio.to_thread(_run)


# ---------------------------------------------------------------------------
# PostgreSQL + pgvector backend
# ---------------------------------------------------------------------------


class PgVectorStore(VectorStore):
    """PostgreSQL + pgvector implementation.

    Uses asyncpg's connection pool. Requires the ``vector`` extension to be
    available (created on first connect). Cosine similarity is computed via
    pgvector's ``<=>`` operator; since vectors are unit-normalised on insert,
    ``score = 1 - (a <=> b)`` gives the same result as the generic cosine
    similarity of the raw input vectors.
    """

    def __init__(self, dsn: str, *, dim: int = DEFAULT_DIM) -> None:
        self._dsn = dsn
        self._dim = dim
        # asyncpg.Pool has no public stable type annotation in this project
        self._pool: Any = None

    @property
    def dim(self) -> int:
        """Configured embedding dimensionality."""
        return self._dim

    async def connect(self) -> None:
        try:
            import asyncpg  # type: ignore[import-untyped]  # no stubs
        except ImportError as exc:
            raise VectorStoreError(
                "PgVectorStore requires asyncpg. "
                "Install with: pip install whycode[postgres]"
            ) from exc

        try:
            self._pool = await asyncpg.create_pool(self._dsn)
        except Exception as exc:
            raise VectorStoreError(
                f"Failed to open PostgreSQL pool: {exc}"
            ) from exc

        async with self._pool.acquire() as conn:
            try:
                await conn.execute("CREATE EXTENSION IF NOT EXISTS vector")
                await conn.execute(
                    f"""
                    CREATE TABLE IF NOT EXISTS vector_items (
                        item_id TEXT PRIMARY KEY,
                        project_id TEXT,
                        embedding vector({self._dim}),
                        metadata JSONB NOT NULL DEFAULT '{{}}'::jsonb
                    )
                    """
                )
                await conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_vi_project "
                    "ON vector_items(project_id)"
                )
            except Exception as exc:
                raise VectorStoreError(
                    f"Failed to initialise pgvector schema: {exc}"
                ) from exc

    async def close(self) -> None:
        if self._pool is None:
            return
        pool = self._pool
        self._pool = None
        try:
            await pool.close()
        except Exception as exc:
            raise VectorStoreError(f"Failed to close pool: {exc}") from exc

    def _require_pool(self) -> Any:
        if self._pool is None:
            raise VectorStoreError("PgVectorStore is not connected")
        return self._pool

    async def insert(
        self,
        item_id: str,
        vector: list[float],
        metadata: dict[str, Any],
    ) -> None:
        item_id = _validate_item_id(item_id)
        metadata = _validate_metadata(metadata)
        validated = _validate_vector(vector, self._dim)
        project_id = _extract_project_id(metadata)
        try:
            meta_json = json.dumps(metadata)
        except (TypeError, ValueError) as exc:
            raise VectorStoreError(f"metadata is not JSON-serialisable: {exc}") from exc
        vec_literal = _vector_to_pg_literal(_normalize(validated))
        pool = self._require_pool()

        async with pool.acquire() as conn:
            try:
                await conn.execute(
                    "INSERT INTO vector_items (item_id, project_id, embedding, metadata) "
                    "VALUES ($1, $2, $3::vector, $4::jsonb)",
                    item_id,
                    project_id,
                    vec_literal,
                    meta_json,
                )
            except Exception as exc:
                message = str(exc).lower()
                if "unique" in message or "duplicate" in message:
                    raise VectorStoreError(
                        f"item_id {item_id!r} already exists"
                    ) from exc
                raise VectorStoreError(f"Insert failed: {exc}") from exc

    async def search(
        self,
        query_vector: list[float],
        top_k: int = 10,
        project_id: str | None = None,
    ) -> list[dict[str, Any]]:
        if not isinstance(top_k, int) or isinstance(top_k, bool) or top_k <= 0:
            raise VectorStoreError(f"top_k must be a positive int, got {top_k!r}")
        if project_id is not None and not isinstance(project_id, str):
            raise VectorStoreError("project_id must be a string when provided")
        validated = _validate_vector(query_vector, self._dim)
        vec_literal = _vector_to_pg_literal(_normalize(validated))
        pool = self._require_pool()

        async with pool.acquire() as conn:
            try:
                if project_id is None:
                    sql = (
                        "SELECT item_id, metadata, "
                        "1 - (embedding <=> $1::vector) AS score "
                        "FROM vector_items "
                        "ORDER BY embedding <=> $1::vector "
                        "LIMIT $2"
                    )
                    rows = await conn.fetch(sql, vec_literal, top_k)
                else:
                    sql = (
                        "SELECT item_id, metadata, "
                        "1 - (embedding <=> $1::vector) AS score "
                        "FROM vector_items "
                        "WHERE project_id = $2 "
                        "ORDER BY embedding <=> $1::vector "
                        "LIMIT $3"
                    )
                    rows = await conn.fetch(sql, vec_literal, project_id, top_k)
            except Exception as exc:
                raise VectorStoreError(f"Search failed: {exc}") from exc

        results: list[dict[str, Any]] = []
        for row in rows:
            meta_raw = row["metadata"]
            if isinstance(meta_raw, str):
                try:
                    meta = json.loads(meta_raw)
                    if not isinstance(meta, dict):
                        meta = {}
                except json.JSONDecodeError:
                    meta = {}
            elif isinstance(meta_raw, dict):
                meta = meta_raw
            else:
                meta = {}
            raw_score = float(row["score"])
            if raw_score < -1.0:
                raw_score = -1.0
            elif raw_score > 1.0:
                raw_score = 1.0
            results.append(
                {"item_id": row["item_id"], "score": raw_score, "metadata": meta}
            )
        return results

    async def get(self, item_id: str) -> dict[str, Any] | None:
        item_id = _validate_item_id(item_id)
        pool = self._require_pool()
        async with pool.acquire() as conn:
            try:
                row = await conn.fetchrow(
                    "SELECT metadata FROM vector_items WHERE item_id = $1",
                    item_id,
                )
            except Exception as exc:
                raise VectorStoreError(f"Get failed: {exc}") from exc
        if row is None:
            return None
        meta_raw = row["metadata"]
        if isinstance(meta_raw, str):
            try:
                meta = json.loads(meta_raw)
            except json.JSONDecodeError:
                return {}
            return meta if isinstance(meta, dict) else {}
        if isinstance(meta_raw, dict):
            return meta_raw
        return {}

    async def delete(self, item_id: str) -> None:
        item_id = _validate_item_id(item_id)
        pool = self._require_pool()
        async with pool.acquire() as conn:
            try:
                await conn.execute(
                    "DELETE FROM vector_items WHERE item_id = $1", item_id
                )
            except Exception as exc:
                raise VectorStoreError(f"Delete failed: {exc}") from exc

    async def delete_by_project(self, project_id: str) -> None:
        if not isinstance(project_id, str) or not project_id:
            raise VectorStoreError("project_id must be a non-empty string")
        pool = self._require_pool()
        async with pool.acquire() as conn:
            try:
                await conn.execute(
                    "DELETE FROM vector_items WHERE project_id = $1", project_id
                )
            except Exception as exc:
                raise VectorStoreError(f"delete_by_project failed: {exc}") from exc

    async def count(self, project_id: str | None = None) -> int:
        if project_id is not None and not isinstance(project_id, str):
            raise VectorStoreError("project_id must be a string when provided")
        pool = self._require_pool()
        async with pool.acquire() as conn:
            try:
                if project_id is None:
                    row = await conn.fetchrow(
                        "SELECT COUNT(*) AS c FROM vector_items"
                    )
                else:
                    row = await conn.fetchrow(
                        "SELECT COUNT(*) AS c FROM vector_items WHERE project_id = $1",
                        project_id,
                    )
            except Exception as exc:
                raise VectorStoreError(f"Count failed: {exc}") from exc
        return int(row["c"]) if row is not None else 0


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def get_vector_store(
    config: DatabaseConfig, *, dim: int = DEFAULT_DIM
) -> VectorStore:
    """Return the vector store matching ``config.backend``.

    For ``postgresql`` the DSN is read from the environment variable named
    by ``config.pg_dsn_env`` — never stored in the config file itself
    (SEC-04).

    Raises:
        VectorStoreError: Unknown backend or missing PG DSN env var.
    """
    if config.backend == "sqlite":
        return SqliteVssStore(config.sqlite_path, dim=dim)
    if config.backend == "postgresql":
        dsn = os.environ.get(config.pg_dsn_env)
        if not dsn:
            raise VectorStoreError(
                f"PostgreSQL DSN env var {config.pg_dsn_env} is not set"
            )
        return PgVectorStore(dsn, dim=dim)
    raise VectorStoreError(f"Unknown database backend: {config.backend!r}")
