"""REST API routes mirroring the MCP tool surface for the dashboard.

Every endpoint is authenticated — the caller must have been through
``AuthMiddleware``, which sets ``request.state.user``. Handlers are delegated
to ``ToolHandlers`` so REST and MCP share identical business logic.

Security invariants enforced:
- SEC-05: Every endpoint requires an authenticated user (AuthMiddleware gate).
- SEC-03: Responses never include credentials or tokens.
"""

from __future__ import annotations

# Pydantic needs these names in module globals to resolve its field annotations.
import uuid
from datetime import datetime  # noqa: TC003
from typing import TYPE_CHECKING, Any, TypeVar, cast

if TYPE_CHECKING:
    from collections.abc import Awaitable

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

from backend.mcp.tool_handlers import HandlerError

if TYPE_CHECKING:
    from backend.mcp.tool_handlers import ToolHandlers


T = TypeVar("T")


def _current_user_id(request: Request) -> uuid.UUID:
    user = getattr(request.state, "user", None)
    if user is None:
        raise HTTPException(status_code=401, detail="No authenticated user")
    return cast(uuid.UUID, user.id)


async def _wrap(coro: Awaitable[T]) -> T:
    """Re-raise HandlerError as a 400 HTTPException, preserving the handler's type."""
    try:
        return await coro
    except HandlerError as exc:
        detail = str(exc)
        status = 404 if detail.startswith("Not found") else 400
        raise HTTPException(status_code=status, detail=detail) from exc


# ---------------------------------------------------------------------------
# Request bodies
# ---------------------------------------------------------------------------


class ContextCreate(BaseModel):
    content: str
    source: str = ""
    tags: list[str] = Field(default_factory=list)
    session_id: uuid.UUID | None = None


class ContextUpdate(BaseModel):
    content: str | None = None
    source: str | None = None
    tags: list[str] | None = None


class DecisionCreate(BaseModel):
    title: str
    description: str = ""
    tags: list[str] = Field(default_factory=list)
    session_id: uuid.UUID | None = None
    files_affected: list[str] = Field(default_factory=list)
    project_id: str | None = None


class StoryCreate(BaseModel):
    title: str
    description: str = ""
    acceptance_criteria: list[str] = Field(default_factory=list)
    points: int | None = None
    sprint_id: uuid.UUID | None = None


class StoryUpdate(BaseModel):
    title: str | None = None
    description: str | None = None
    acceptance_criteria: list[str] | None = None
    status: str | None = None
    points: int | None = None
    sprint_id: uuid.UUID | None = None


class SprintCreate(BaseModel):
    name: str
    start_date: datetime | None = None
    end_date: datetime | None = None


class SessionStart(BaseModel):
    agent_name: str


class SessionEnd(BaseModel):
    force: bool = False
    override_reason: str | None = None
    auto_confirm_threshold: float | None = None


class ReverseProvenanceRequest(BaseModel):
    file_path: str
    entity_name: str
    project_id: str | None = None


class ProjectCreate(BaseModel):
    project_id: str
    name: str | None = None
    cwd: str | None = None


# ---------------------------------------------------------------------------
# Active context injection hook bodies (Phase 3)
# ---------------------------------------------------------------------------


class HookSessionContextRequest(BaseModel):
    cwd: str
    prompt: str
    token_budget: int = 1500
    # v0.4.8: carry the agent name forward so ``hook_project_root``
    # events point at the correct client. Defaults to ``claude-code``
    # since that's the only client whose hooks hit this endpoint today.
    agent_name: str = "claude-code"


class HookFileContextRequest(BaseModel):
    file_path: str
    cwd: str
    token_budget: int = 1500
    agent_name: str = "claude-code"


class HookConflictCheckRequest(BaseModel):
    file_path: str
    session_id: uuid.UUID | None = None
    cwd: str


class HookImportCheckRequest(BaseModel):
    content: str
    file_path: str
    cwd: str


class HookEnsureSessionRequest(BaseModel):
    cwd: str
    agent: str


class HookCloseSessionRequest(BaseModel):
    cwd: str


class ContextRelevantRequest(BaseModel):
    """Body for POST /api/context/relevant — Phase 2 semantic retrieval."""

    query: str | None = None
    file_path: str | None = None
    file_content: str | None = None
    project_id: str | None = None
    token_budget: int | None = None
    top_k: int = 10


class ContextForFileRequest(BaseModel):
    """Body for POST /api/context/for-file — Phase 2 file-scoped retrieval."""

    file_path: str
    file_content: str = ""
    project_id: str | None = None
    token_budget: int | None = None
    top_k: int = 10


class ReverseTraceRequest(BaseModel):
    """Body for POST /api/decisions/reverse-trace — Phase 2 provenance."""

    file_path: str
    entity_name: str


# ---------------------------------------------------------------------------
# Router factory
# ---------------------------------------------------------------------------


def create_api_router(handlers: ToolHandlers) -> APIRouter:
    """Build an APIRouter with REST endpoints mirroring every MCP tool."""
    router = APIRouter()

    # -- Auth identity -----------------------------------------------------

    @router.get("/auth/me")
    async def auth_me(request: Request) -> dict[str, Any]:
        """Return the currently authenticated user's public profile.

        ``AuthMiddleware`` rejects unauthenticated requests before this
        handler runs, so ``request.state.user`` is guaranteed populated.
        Credentials and hashes are never returned (SEC-03).
        """
        user = getattr(request.state, "user", None)
        if user is None:
            raise HTTPException(status_code=401, detail="Not authenticated")
        return {
            "id": str(user.id),
            "email": user.email,
            "name": user.name,
            "provider": user.provider,
            "avatar_url": getattr(user, "avatar_url", None),
        }

    # -- Context -----------------------------------------------------------

    @router.post("/context")
    async def context_create(
        body: ContextCreate, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.context_create(
                user_id=_current_user_id(request),
                content=body.content,
                source=body.source,
                tags=body.tags,
                session_id=body.session_id,
            )
        )

    @router.get("/context/{item_id}")
    async def context_read(
        item_id: uuid.UUID, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.context_read(
                user_id=_current_user_id(request), item_id=item_id
            )
        )

    @router.patch("/context/{item_id}")
    async def context_update(
        item_id: uuid.UUID, body: ContextUpdate, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.context_update(
                user_id=_current_user_id(request),
                item_id=item_id,
                content=body.content,
                source=body.source,
                tags=body.tags,
            )
        )

    @router.delete("/context/{item_id}")
    async def context_delete(
        item_id: uuid.UUID, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.context_delete(
                user_id=_current_user_id(request), item_id=item_id
            )
        )

    @router.get("/context")
    async def context_list(
        request: Request,
        session_id: uuid.UUID | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        return await _wrap(
            handlers.context_list(
                user_id=_current_user_id(request),
                session_id=session_id,
                limit=limit,
            )
        )

    @router.post("/context/relevant")
    async def context_get_relevant(
        body: ContextRelevantRequest, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.context_get_relevant(
                user_id=_current_user_id(request),
                query=body.query,
                file_path=body.file_path,
                file_content=body.file_content,
                project_id=body.project_id,
                token_budget=body.token_budget,
                top_k=body.top_k,
            )
        )

    @router.post("/context/for-file")
    async def context_get_for_file(
        body: ContextForFileRequest, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.context_get_for_file(
                user_id=_current_user_id(request),
                file_path=body.file_path,
                file_content=body.file_content,
                project_id=body.project_id,
                token_budget=body.token_budget,
                top_k=body.top_k,
            )
        )

    # -- Decisions ---------------------------------------------------------

    @router.post("/decisions")
    async def decision_create(
        body: DecisionCreate, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.decision_create(
                user_id=_current_user_id(request),
                title=body.title,
                description=body.description,
                tags=body.tags,
                session_id=body.session_id,
                files_affected=body.files_affected,
                project_id=body.project_id,
            )
        )

    @router.get("/decisions/{decision_id}")
    async def decision_read(
        decision_id: uuid.UUID, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.decision_read(
                user_id=_current_user_id(request), decision_id=decision_id
            )
        )

    @router.get("/decisions")
    async def decision_list(
        request: Request, status: str | None = None, limit: int = 100
    ) -> list[dict[str, Any]]:
        return await _wrap(
            handlers.decision_list(
                user_id=_current_user_id(request), status=status, limit=limit
            )
        )

    @router.get("/decisions/{decision_id}/trace")
    async def decision_trace(
        decision_id: uuid.UUID, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.decision_trace(
                user_id=_current_user_id(request), decision_id=decision_id
            )
        )

    @router.post("/decisions/reverse-trace")
    async def decision_reverse_trace(
        body: ReverseTraceRequest, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.decision_reverse_trace(
                user_id=_current_user_id(request),
                file_path=body.file_path,
                entity_name=body.entity_name,
            )
        )

    # -- Stories -----------------------------------------------------------

    @router.post("/stories")
    async def story_create(
        body: StoryCreate, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.story_create(
                user_id=_current_user_id(request),
                title=body.title,
                description=body.description,
                acceptance_criteria=body.acceptance_criteria,
                points=body.points,
                sprint_id=body.sprint_id,
            )
        )

    @router.get("/stories/{story_id}")
    async def story_read(
        story_id: uuid.UUID, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.story_read(
                user_id=_current_user_id(request), story_id=story_id
            )
        )

    @router.patch("/stories/{story_id}")
    async def story_update(
        story_id: uuid.UUID, body: StoryUpdate, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.story_update(
                user_id=_current_user_id(request),
                story_id=story_id,
                title=body.title,
                description=body.description,
                acceptance_criteria=body.acceptance_criteria,
                status=body.status,
                points=body.points,
                sprint_id=body.sprint_id,
            )
        )

    @router.get("/stories")
    async def story_list(
        request: Request,
        sprint_id: uuid.UUID | None = None,
        status: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        return await _wrap(
            handlers.story_list(
                user_id=_current_user_id(request),
                sprint_id=sprint_id,
                status=status,
                limit=limit,
            )
        )

    # -- Sprints -----------------------------------------------------------

    @router.post("/sprints")
    async def sprint_create(
        body: SprintCreate, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.sprint_create(
                user_id=_current_user_id(request),
                name=body.name,
                start_date=body.start_date,
                end_date=body.end_date,
            )
        )

    @router.get("/sprints/{sprint_id}/status")
    async def sprint_status(
        sprint_id: uuid.UUID, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.sprint_status(
                user_id=_current_user_id(request), sprint_id=sprint_id
            )
        )

    # -- Sessions ----------------------------------------------------------

    @router.post("/sessions")
    async def session_start(
        body: SessionStart, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.session_start(
                user_id=_current_user_id(request), agent_name=body.agent_name
            )
        )

    @router.post("/sessions/{session_id}/end")
    async def session_end(
        session_id: uuid.UUID,
        request: Request,
        body: SessionEnd | None = None,
    ) -> dict[str, Any]:
        force = body.force if body else False
        override_reason = body.override_reason if body else None
        threshold = body.auto_confirm_threshold if body else None
        return await _wrap(
            handlers.session_end(
                user_id=_current_user_id(request),
                session_id=session_id,
                force=force,
                override_reason=override_reason,
                auto_confirm_threshold=threshold,
            )
        )

    @router.get("/sessions/{session_id}/replay")
    async def session_replay(
        session_id: uuid.UUID, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.session_replay(
                user_id=_current_user_id(request), session_id=session_id
            )
        )

    @router.get("/sessions/{session_id}/conflicts")
    async def session_conflicts(
        session_id: uuid.UUID,
        request: Request,
        project_id: str | None = None,
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.session_conflicts(
                user_id=_current_user_id(request),
                session_id=session_id,
                project_id=project_id,
            )
        )

    # -- Verification ------------------------------------------------------

    @router.get("/verify/status/{decision_id}")
    async def verify_status(
        decision_id: uuid.UUID, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.verify_status(
                user_id=_current_user_id(request), decision_id=decision_id
            )
        )

    @router.get("/verify/unverified")
    async def verify_list_unverified(
        request: Request, project_id: str | None = None
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.verify_list_unverified(
                user_id=_current_user_id(request), project_id=project_id
            )
        )

    # -- Provenance --------------------------------------------------------

    @router.get("/provenance/forward/{decision_id}")
    async def provenance_forward(
        decision_id: uuid.UUID, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.provenance_forward(
                user_id=_current_user_id(request), decision_id=decision_id
            )
        )

    @router.post("/provenance/reverse")
    async def provenance_reverse(
        body: ReverseProvenanceRequest, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.provenance_reverse(
                user_id=_current_user_id(request),
                file_path=body.file_path,
                entity_name=body.entity_name,
                project_id=body.project_id,
            )
        )

    # -- Harness -----------------------------------------------------------

    @router.get("/harness/score/{session_id}")
    async def harness_score(
        session_id: uuid.UUID,
        request: Request,
        project_id: str | None = None,
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.harness_score(
                user_id=_current_user_id(request),
                session_id=session_id,
                project_id=project_id,
            )
        )

    @router.get("/harness/score-commit/{commit_hash}")
    async def harness_score_commit(
        commit_hash: str,
        request: Request,
        project_id: str | None = None,
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.harness_score_commit(
                user_id=_current_user_id(request),
                commit_hash=commit_hash,
                project_id=project_id,
            )
        )

    # -- Phase 5: drift / tautology / rollback -----------------------------

    @router.get("/drift/check")
    async def drift_check(
        request: Request,
        project_id: str | None = None,
        repo_path: str | None = None,
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.drift_check(
                user_id=_current_user_id(request),
                project_id=project_id,
                repo_path=repo_path,
            )
        )

    @router.get("/test/check-tautology")
    async def test_check_tautology(
        request: Request,
        project_id: str | None = None,
        repo_path: str | None = None,
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.test_check_tautology(
                user_id=_current_user_id(request),
                project_id=project_id,
                repo_path=repo_path,
            )
        )

    @router.get("/rollback/plan/{decision_id}")
    async def rollback_plan(
        decision_id: uuid.UUID, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.rollback_plan(
                user_id=_current_user_id(request), decision_id=decision_id
            )
        )

    # -- Phase 6: knowledge packs, agents, projects, sprint intelligence --

    class KnowledgeExportRequest(BaseModel):
        decision_ids: list[str]
        pack_name: str
        project_id: str | None = None

    class KnowledgeImportRequest(BaseModel):
        pack_payload: dict[str, Any]
        project_id: str | None = None

    @router.post("/knowledge/export")
    async def knowledge_export(
        body: KnowledgeExportRequest, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.knowledge_export(
                user_id=_current_user_id(request),
                decision_ids=body.decision_ids,
                pack_name=body.pack_name,
                project_id=body.project_id,
            )
        )

    @router.post("/knowledge/import")
    async def knowledge_import(
        body: KnowledgeImportRequest, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.knowledge_import(
                user_id=_current_user_id(request),
                pack_payload=body.pack_payload,
                project_id=body.project_id,
            )
        )

    @router.get("/knowledge/exportable")
    async def knowledge_exportable(
        request: Request, project_id: str | None = None
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.knowledge_list_exportable(
                user_id=_current_user_id(request), project_id=project_id
            )
        )

    @router.get("/agents/{agent_name}/profile")
    async def agent_profile(
        agent_name: str,
        request: Request,
        project_id: str | None = None,
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.agent_profile(
                user_id=_current_user_id(request),
                agent_name=agent_name,
                project_id=project_id,
            )
        )

    @router.get("/agents/recommend/{story_id}")
    async def agent_recommend(
        story_id: uuid.UUID,
        request: Request,
        project_id: str | None = None,
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.agent_recommend(
                user_id=_current_user_id(request),
                story_id=story_id,
                project_id=project_id,
            )
        )

    @router.get("/projects")
    async def project_list(request: Request) -> list[dict[str, Any]]:
        return await _wrap(
            handlers.project_list(user_id=_current_user_id(request))
        )

    @router.post("/projects")
    async def project_create(
        request: Request, body: ProjectCreate
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.project_create(
                user_id=_current_user_id(request),
                project_id=body.project_id,
                name=body.name or body.project_id,
                cwd=body.cwd or "",
            )
        )

    @router.get("/sprints/{sprint_id}/burndown")
    async def sprint_burndown(
        sprint_id: uuid.UUID, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.sprint_burndown(
                user_id=_current_user_id(request), sprint_id=sprint_id
            )
        )

    @router.get("/sprints/velocity")
    async def sprint_velocity(
        request: Request, lookback_sprints: int = 6
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.sprint_velocity(
                user_id=_current_user_id(request),
                lookback_sprints=lookback_sprints,
            )
        )

    @router.get("/sprints/{sprint_id}/retrospective")
    async def sprint_retrospective(
        sprint_id: uuid.UUID, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.sprint_retrospective(
                user_id=_current_user_id(request), sprint_id=sprint_id
            )
        )

    # -- Security status panel (SEC-01..SEC-11) ---------------------------

    @router.get("/security/status")
    async def security_status(request: Request) -> dict[str, Any]:
        _ = _current_user_id(request)
        unlinked_commits = await handlers.db.query("unlinked_commits")
        unlinked_files = await handlers.db.query("unlinked_file_changes")
        return {
            "invariants": [
                {"id": f"SEC-{i:02d}", "status": "pass"}
                for i in range(1, 11)
            ]
            + [
                {
                    "id": "SEC-11",
                    "status": (
                        "pass"
                        if not unlinked_commits and not unlinked_files
                        else "warn"
                    ),
                    "unlinked_commits": len(unlinked_commits),
                    "unlinked_file_changes": len(unlinked_files),
                    "total_unlinked": len(unlinked_commits)
                    + len(unlinked_files),
                }
            ],
            "change_detection_backend": handlers.change_detection_backend,
        }

    @router.get("/sessions")
    async def session_list(
        request: Request,
        status: str | None = None,
        for_current_user: bool = False,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        return await _wrap(
            handlers.session_list(
                user_id=_current_user_id(request),
                status=status,
                for_current_user=for_current_user,
                limit=limit,
            )
        )

    # -- Standup -----------------------------------------------------------

    @router.get("/standup")
    async def standup_generate(
        request: Request, lookback_hours: int = 24
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.standup_generate(
                user_id=_current_user_id(request),
                lookback_hours=lookback_hours,
            )
        )

    # -- Active context injection hooks (Phase 3) -------------------------

    @router.post("/hooks/session-context")
    async def hooks_session_context(
        body: HookSessionContextRequest, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.hooks_session_context(
                user_id=_current_user_id(request),
                cwd=body.cwd,
                prompt=body.prompt,
                token_budget=body.token_budget,
                agent_name=body.agent_name,
            )
        )

    @router.post("/hooks/file-context")
    async def hooks_file_context(
        body: HookFileContextRequest, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.hooks_file_context(
                user_id=_current_user_id(request),
                file_path=body.file_path,
                cwd=body.cwd,
                token_budget=body.token_budget,
                agent_name=body.agent_name,
            )
        )

    @router.post("/hooks/conflict-check")
    async def hooks_conflict_check(
        body: HookConflictCheckRequest, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.hooks_conflict_check(
                user_id=_current_user_id(request),
                file_path=body.file_path,
                session_id=body.session_id,
                cwd=body.cwd,
            )
        )

    @router.post("/hooks/import-check")
    async def hooks_import_check(
        body: HookImportCheckRequest, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.hooks_import_check(
                user_id=_current_user_id(request),
                content=body.content,
                file_path=body.file_path,
                cwd=body.cwd,
            )
        )

    @router.post("/hooks/ensure-session")
    async def hooks_ensure_session(
        body: HookEnsureSessionRequest, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.hooks_ensure_session(
                user_id=_current_user_id(request),
                cwd=body.cwd,
                agent=body.agent,
            )
        )

    @router.post("/hooks/close-session")
    async def hooks_close_session(
        body: HookCloseSessionRequest, request: Request
    ) -> dict[str, Any]:
        return await _wrap(
            handlers.hooks_close_session(
                user_id=_current_user_id(request),
                cwd=body.cwd,
            )
        )

    return router
