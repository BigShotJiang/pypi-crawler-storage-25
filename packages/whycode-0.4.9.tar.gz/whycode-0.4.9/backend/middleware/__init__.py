"""Custom ASGI middleware used by the WhyCode FastAPI app."""
