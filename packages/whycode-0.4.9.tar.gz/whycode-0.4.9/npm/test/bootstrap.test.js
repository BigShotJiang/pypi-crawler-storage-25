"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const path = require("node:path");
const fs = require("node:fs");
const os = require("node:os");

const { parseArgs, NPM_CONFIG_PATH, saveNpmConfig, readNpmConfig } = require(
  path.join(__dirname, "..", "bin", "whycode.js"),
);

test("parseArgs: --port parses integer", () => {
  const args = parseArgs(["init-and-serve", "--port", "9000"]);
  assert.equal(args.port, 9000);
  assert.deepEqual(args.positional, ["init-and-serve"]);
});

test("parseArgs: --port=9000 also works", () => {
  const args = parseArgs(["init-and-serve", "--port=9000"]);
  assert.equal(args.port, 9000);
});

test("parseArgs: defaults to 8100", () => {
  const args = parseArgs(["init-and-serve"]);
  assert.equal(args.port, 8100);
});

test("parseArgs: --mode team sets team mode", () => {
  const args = parseArgs(["init-and-serve", "--mode", "team", "--port", "9100"]);
  assert.equal(args.mode, "team");
  assert.equal(args.port, 9100);
});

test("parseArgs: help flag", () => {
  const args = parseArgs(["--help"]);
  assert.equal(args.help, true);
});

test("readNpmConfig / saveNpmConfig round-trip", () => {
  const existing = fs.existsSync(NPM_CONFIG_PATH)
    ? fs.readFileSync(NPM_CONFIG_PATH, "utf-8")
    : null;
  try {
    saveNpmConfig({ port: 7777, mode: "team" });
    const cfg = readNpmConfig();
    assert.equal(cfg.port, 7777);
    assert.equal(cfg.mode, "team");
  } finally {
    if (existing !== null) {
      fs.writeFileSync(NPM_CONFIG_PATH, existing);
    } else if (fs.existsSync(NPM_CONFIG_PATH)) {
      fs.unlinkSync(NPM_CONFIG_PATH);
    }
  }
});

test("saveNpmConfig creates the config dir", () => {
  const existing = fs.existsSync(NPM_CONFIG_PATH);
  const configDir = path.dirname(NPM_CONFIG_PATH);
  saveNpmConfig({ port: 8100 });
  assert.ok(fs.existsSync(configDir));
  if (!existing) {
    try {
      fs.unlinkSync(NPM_CONFIG_PATH);
    } catch {}
  }
});

// We don't invoke the init-and-serve spawn path from tests — it starts a
// subprocess. The unit-level exports cover the parsing contract.
void os;
