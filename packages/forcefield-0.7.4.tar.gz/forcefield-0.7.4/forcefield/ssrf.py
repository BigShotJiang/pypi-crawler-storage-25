"""SSRF (Server-Side Request Forgery) validation for user-supplied URLs.

Validates that endpoint URLs do not resolve to private/internal IP addresses.
Ported from NVIDIA NemoClaw's ssrf.ts with additions for Python ecosystem.

Usage::

    from forcefield.ssrf import validate_endpoint_url, is_private_ip

    # Raises ValueError if URL resolves to private IP
    validate_endpoint_url("https://api.openai.com/v1/chat/completions")

    # Direct IP check
    is_private_ip("10.0.0.1")  # True
    is_private_ip("8.8.8.8")   # False
"""

from __future__ import annotations

import ipaddress
import socket
from typing import List, Optional, Tuple
from urllib.parse import urlparse

# Private/internal network ranges that must never be reachable via user-supplied URLs.
# Covers RFC 1918, RFC 6598 (CGNAT), link-local, loopback, IPv6 ULA, and
# cloud metadata endpoints.
_PRIVATE_NETWORKS = [
    ipaddress.ip_network("127.0.0.0/8"),        # Loopback
    ipaddress.ip_network("10.0.0.0/8"),          # RFC 1918
    ipaddress.ip_network("172.16.0.0/12"),       # RFC 1918
    ipaddress.ip_network("192.168.0.0/16"),      # RFC 1918
    ipaddress.ip_network("169.254.0.0/16"),      # Link-local
    ipaddress.ip_network("100.64.0.0/10"),       # RFC 6598 CGNAT
    ipaddress.ip_network("0.0.0.0/8"),           # "This" network
    ipaddress.ip_network("192.0.0.0/24"),        # IETF Protocol Assignments
    ipaddress.ip_network("192.0.2.0/24"),        # TEST-NET-1
    ipaddress.ip_network("198.51.100.0/24"),     # TEST-NET-2
    ipaddress.ip_network("203.0.113.0/24"),      # TEST-NET-3
    ipaddress.ip_network("224.0.0.0/4"),         # Multicast
    ipaddress.ip_network("240.0.0.0/4"),         # Reserved
    ipaddress.ip_network("::1/128"),             # IPv6 loopback
    ipaddress.ip_network("fd00::/8"),            # IPv6 ULA
    ipaddress.ip_network("fe80::/10"),           # IPv6 link-local
    ipaddress.ip_network("::ffff:0:0/96"),       # IPv4-mapped IPv6
    ipaddress.ip_network("fc00::/7"),            # IPv6 unique local
]

_ALLOWED_SCHEMES = frozenset({"https", "http"})

# Cloud metadata IPs that must always be blocked even if they appear public.
_CLOUD_METADATA_IPS = frozenset({
    "169.254.169.254",   # AWS, GCP, Azure metadata
    "169.254.170.2",     # AWS ECS task metadata
    "fd00:ec2::254",     # AWS IPv6 metadata
})


def is_private_ip(addr: str) -> bool:
    """Check if an IP address is in a private/internal range.

    Also catches cloud metadata IPs and IPv4-mapped IPv6 addresses.
    """
    if addr in _CLOUD_METADATA_IPS:
        return True

    try:
        ip = ipaddress.ip_address(addr)
    except ValueError:
        return False

    # IPv4-mapped IPv6 (::ffff:x.x.x.x) -- extract the embedded IPv4
    if isinstance(ip, ipaddress.IPv6Address) and ip.ipv4_mapped:
        ip = ip.ipv4_mapped

    for network in _PRIVATE_NETWORKS:
        try:
            if ip in network:
                return True
        except TypeError:
            continue

    return False


def _resolve_hostname(hostname: str) -> List[Tuple[str, int]]:
    """Resolve a hostname to all IP addresses via DNS.

    Returns list of (address, family) tuples.
    Raises ValueError on resolution failure.
    """
    try:
        results = socket.getaddrinfo(
            hostname, None,
            socket.AF_UNSPEC,
            socket.SOCK_STREAM,
        )
    except socket.gaierror as exc:
        raise ValueError(f"Cannot resolve hostname '{hostname}': {exc}") from exc

    addresses = []
    seen = set()
    for family, _type, _proto, _canonname, sockaddr in results:
        addr = sockaddr[0]
        if addr not in seen:
            seen.add(addr)
            addresses.append((addr, family))

    if not addresses:
        raise ValueError(f"Hostname '{hostname}' resolved to zero addresses")

    return addresses


def validate_endpoint_url(
    url: str,
    *,
    allowed_schemes: Optional[frozenset] = None,
    allow_private: bool = False,
    skip_dns: bool = False,
) -> str:
    """Validate that an endpoint URL is safe to connect to.

    Checks:
    1. URL is well-formed with an allowed scheme (https/http).
    2. Hostname is not an IP literal in a private range.
    3. DNS resolution does not return any private/internal addresses.

    Args:
        url: The URL to validate.
        allowed_schemes: Override the default allowed schemes.
        allow_private: If True, skip private IP checks (for testing).
        skip_dns: If True, skip DNS resolution (for unit tests).

    Returns:
        The validated URL (unchanged).

    Raises:
        ValueError: If the URL is invalid, uses a disallowed scheme,
            or resolves to a private/internal address.
    """
    schemes = allowed_schemes or _ALLOWED_SCHEMES

    try:
        parsed = urlparse(url)
    except Exception as exc:
        raise ValueError(f"Malformed URL: {url}") from exc

    if not parsed.scheme:
        raise ValueError(f"No scheme in URL: {url}")

    if parsed.scheme.lower() not in schemes:
        allowed = ", ".join(f"{s}://" for s in sorted(schemes))
        raise ValueError(
            f"Unsupported URL scheme '{parsed.scheme}://'. Only {allowed} are allowed."
        )

    hostname = parsed.hostname
    if not hostname:
        raise ValueError(f"No hostname found in URL: {url}")

    if allow_private:
        return url

    # Check if hostname is already an IP literal
    try:
        ip = ipaddress.ip_address(hostname)
        if is_private_ip(str(ip)):
            raise ValueError(
                f"Endpoint URL contains private/internal IP address {ip}. "
                "Connections to internal networks are not allowed."
            )
        return url
    except ValueError as exc:
        if "private/internal" in str(exc) or "Connections to internal" in str(exc):
            raise
        # Not an IP literal, continue to DNS resolution

    if skip_dns:
        return url

    # DNS resolution -- check ALL resolved addresses
    addresses = _resolve_hostname(hostname)
    for addr, _family in addresses:
        if is_private_ip(addr):
            raise ValueError(
                f"Endpoint URL resolves to private/internal address {addr}. "
                "Connections to internal networks are not allowed."
            )

    return url
