Python project generator library
