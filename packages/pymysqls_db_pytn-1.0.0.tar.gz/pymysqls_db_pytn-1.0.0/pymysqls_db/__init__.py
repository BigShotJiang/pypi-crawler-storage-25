from pathlib import Path

def write_file(path, content):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content.strip() + "\n")

def create_all():
    files = {
        "models/item.py": r'''class Item:
    def __init__(self, **kwargs):
        for k, v in kwargs.items(): setattr(self, k, v)

    @staticmethod
    def from_db_row(row):
        return Item(**row) if row else None
''',

        "models/order.py": r'''class Order:
    def __init__(self, **kwargs):
        for k, v in kwargs.items(): setattr(self, k, v)

    @staticmethod
    def from_db_row(row):
        return Order(**row) if row else None
''',

        "models/user.py": r'''class User:
    def __init__(self, user_id, fio, login, role_name):
        self.user = user_id
        self.fio = fio
        self.login = login
        self.role_name = role_name

    @staticmethod
    def from_db_row(row):
        if not row: return None
        return User(
            user_id=row['user_id'],
            fio=row['fio'],
            login=row['login'],
            role_name=row['role_name']
        )

    @staticmethod
    def create_guest():
        return User(0, "Гость", "guest", "guest")
''',

        "database/repository.py": r'''import pymysql
from models.order import Order
from models.user import User
from models.item import Item

class Repository:
    def connect_db(self):
        return pymysql.connect(
            host="localhost",
            user="root",
            password="",
            db="sport_shop",
            charset="utf8mb4",
            cursorclass=pymysql.cursors.DictCursor
        )

    def find_user(self, login, password):
        conn = self.connect_db()
        try:
            with conn.cursor() as cur:
                sql = """
                    SELECT u.*, r.role_name
                    FROM users u
                    JOIN roles r ON u.role_id = r.role_id
                    WHERE u.login = %s AND u.password = %s
                """

                cur.execute(sql, (login, password))
                row = cur.fetchone()
                if row: return User.from_db_row(row)
        finally:
            conn.close()

    def get_items(self, search="", category_name="Все", sort="ASC"):
        conn = self.connect_db()
        try:
            with conn.cursor() as cur:
                sql = """
                    SELECT i.*, c.category_name,
                    b.brand_name, s.supplier_name,
                    ip.image_path
                    FROM items i
                    LEFT JOIN categories c ON i.category_id = c.category_id
                    LEFT JOIN brands b ON i.brand_id = b.brand_id
                    LEFT JOIN suppliers s ON i.supplier_id = s.supplier_id
                    LEFT JOIN images ip ON i.image_id = ip.image_id
                    WHERE (
                        i.item_name LIKE %s OR
                        c.category_name LIKE %s OR
                        b.brand_name LIKE %s OR
                        s.supplier_name LIKE %s OR
                        i.description LIKE %s
                    )
                """

                search_param = f'%{search}%'
                params = [search_param] * 5

                if category_name != "Все":
                    sql += " AND c.category_name LIKE %s"
                    params.append(category_name)

                sql += f" ORDER BY i.price {sort}"

                cur.execute(sql, params)
                rows = cur.fetchall()
                if rows: return [Item.from_db_row(row) for row in rows]
        finally:
            conn.close()

    def get_categories(self):
        conn = self.connect_db()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT category_name FROM categories")
                return [row['category_name'] for row in cur.fetchall()]
        finally:
            conn.close()

    def get_orders(self):
        conn = self.connect_db()
        try:
            with conn.cursor() as cur:
                sql = """
                    SELECT o.order_id, s.status,
                    o.address, o.order_date, o.arrival_date,
                    GROUP_CONCAT(i.item_name SEPARATOR ', ') as items_list
                    FROM orders o
                    LEFT JOIN statuses s ON o.status_id = s.status_id
                    LEFT JOIN order_items oi ON o.order_id = oi.order_id
                    LEFT JOIN items i ON oi.item_id = i.item_id
                    GROUP BY o.order_id
                    ORDER BY o.order_date DESC
                """
                cur.execute(sql)
                rows = cur.fetchall()
                if rows: return [Order.from_db_row(row) for row in rows]
        finally:
            conn.close()

    def delete_item(self, item_id):
        conn = self.connect_db()
        try:
            with conn.cursor() as cur:
                cur.execute("DELETE FROM items WHERE item_id = %s", (item_id,))
                conn.commit()
                return "success"
        except Exception as e:
            return str(e)
        finally:
            conn.close()

    def add_item(self, name, cat_id, br_id, sup_id, price, discount, stock, img, desc):
        conn = self.connect_db()
        try:
            with conn.cursor() as cur:
                sql = """INSERT INTO items (item_name, category_id, brand_id, supplier_id, price, discount, stock, image_id, description)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"""
                cur.execute(sql, (name, cat_id, br_id, sup_id, price, discount, stock, img, desc))
                conn.commit()
                return "success"
        except Exception as e:
            return str(e)
        finally:
            conn.close()

    def update_item(self, item_id, name, cat_id, br_id, sup_id, price, discount, stock, img, desc):
        conn = self.connect_db()
        try:
            with conn.cursor() as cur:
                sql = """
                    UPDATE items SET item_name=%s, category_id=%s, brand_id=%s, supplier_id=%s, price=%s, discount=%s,
                    stock=%s, image_id=%s, description=%s WHERE item_id=%s
                """
                cur.execute(sql, (name, cat_id, br_id, sup_id, price, discount, stock, img, desc, item_id))
                conn.commit()
                return "success"
        except Exception as e:
            return str(e)
        finally:
            conn.close()
''',

        "items_window.py": r'''from PyQt6.QtWidgets import QWidget, QLabel, QLineEdit, QScrollArea, QComboBox, QBoxLayout, QHBoxLayout, QVBoxLayout, \
    QPushButton
from PyQt6.QtCore import Qt
from database.repository import Repository
from item_widget import ItemWidget
from orders_window import OrdersWindow

class ItemsWindow(QWidget):
    def __init__(self, user):
        super().__init__()
        self.user = user
        self.role = user.role_name.lower()
        self.repo = Repository()

        self.setWindowTitle("Магазин товаров")
        self.resize(1100,700)

        main_lay = QVBoxLayout(self)

        header = QHBoxLayout()
        self.info = QLabel(f"Вы зашли как {user.fio} | Роль {user.role_name}")
        self.ex_btn = QPushButton("Выйти")
        self.ex_btn.clicked.connect(self.logout)
        header.addWidget(self.info)
        header.addStretch()
        header.addWidget(self.ex_btn)
        if self.role == "admin":
            self.add_btn = QPushButton("Добавить товар")
            self.add_btn.clicked.connect(self.open_add_form)
            header.addWidget(self.add_btn)

            self.ord_btn = QPushButton("Заявки")
            self.ord_btn.clicked.connect(self.show_orders)
            header.addWidget(self.ord_btn)
        main_lay.addLayout(header)

        controls = QHBoxLayout()

        self.search_lbl = QLabel("Поиск:")
        self.search_bar = QLineEdit()
        self.search_bar.textChanged.connect(self.load_data)

        controls.addWidget(self.search_lbl)
        controls.addWidget(self.search_bar)

        self.category_lbl = QLabel("Категории:")
        self.category_bar = QComboBox()
        self.category_bar.addItem("Все")
        self.category_bar.addItems(self.repo.get_categories())
        self.category_bar.currentTextChanged.connect(self.load_data)

        self.sort_lbl = QLabel("Сортировка")
        self.sort_bar = QComboBox()
        self.sort_bar.addItems(["По возрастанию", "По убыванию"])
        self.sort_bar.currentIndexChanged.connect(self.load_data)

        if self.role in ['admin', 'manager']:
            controls.addWidget(self.category_lbl)
            controls.addWidget(self.category_bar)
            controls.addWidget(self.sort_lbl)
            controls.addWidget(self.sort_bar)

        main_lay.addLayout(controls)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.container = QWidget()
        self.lay_list = QVBoxLayout(self.container)
        self.lay_list.setAlignment(Qt.AlignmentFlag.AlignTop)

        self.scroll.setWidget(self.container)
        main_lay.addWidget(self.scroll)

        self.load_data()

    def load_data(self):
        while self.lay_list.count():
            item = self.lay_list.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        search = self.search_bar.text()

        category_name = "Все"
        if self.role in ['admin', 'manager'] and self.category_bar.currentText() != category_name:
            category_name = self.category_bar.currentText()

        sort = "ASC"
        if self.role in ['admin', 'manager'] and self.sort_bar.currentIndex() == 1:
            sort = "DESC"

        items = self.repo.get_items(search, category_name, sort) or []

        for i in items:
            card = ItemWidget(i, self.role, self.load_data)
            self.lay_list.addWidget(card)

    def logout(self):
        from main import LoginWindow
        self.close()
        self.i = LoginWindow()
        self.i.show()

    def show_orders(self):
        self.close()
        self.o = OrdersWindow(self.user)
        self.o.show()

    def open_add_form(self):
        from item_form_window import ItemFormWindow
        self.form = ItemFormWindow(item=None, callback=self.load_data)
        self.form.show()

    def open_edit_form(self):
        from item_form_window import ItemFormWindow
        self.form = ItemFormWindow(item=self.i, callback=self.delete_signal)
        self.form.show()
''',

        "item_widget.py": r'''from PyQt6.QtWidgets import QFrame, QHBoxLayout, QVBoxLayout, QLabel, QPushButton, QMessageBox
from PyQt6.QtGui import QPixmap
from PyQt6.QtCore import Qt
from database.repository import Repository

class ItemWidget(QFrame):
    def __init__(self, i, role, delete_signal):
        super().__init__()
        self.i = i
        self.role = role
        self.delete_signal = delete_signal
        self.repo = Repository()

        shape = QFrame.Shape.Box
        self.setFrameShape(shape)
        self.setFixedHeight(180)

        main_lay = QHBoxLayout(self)
        main_lay.setSpacing(15)

        img_lbl = QLabel()
        img_lbl.setFrameShape(shape)
        img_lbl.setFixedSize(140, 140)
        img_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)

        fname = f"data/images/{i.image_path}" if i.image_path else "picture.png"
        pix = QPixmap(fname)
        if pix.isNull(): pix = QPixmap("data/images/picture.png")

        img_lbl.setPixmap(pix.scaled(130, 130, Qt.AspectRatioMode.KeepAspectRatio))
        main_lay.addWidget(img_lbl)

        info_fr = QFrame()
        info_fr.setFrameShape(shape)
        info_lay = QVBoxLayout(info_fr)

        info_lay.addWidget(QLabel(f"<b>{i.item_name} | {i.category_name}</b>"))
        info_lay.addWidget(QLabel(f"Бренд: {i.brand_name}"))
        info_lay.addWidget(QLabel(f"Поставщик: {i.supplier_name}"))
        if i.discount > 0:
            new_price = float(i.price) * (1 - int(i.discount) / 100)
            text = f"Цена: <s style='color:red'>{i.price}</s> <b>{new_price:.2f}</b>"
        else:
            text = f"<b>Цена: {i.price}</b>"
        info_lay.addWidget(QLabel(text))
        info_lay.addWidget(QLabel(f"Описание {i.description}"))
        info_lay.addWidget(QLabel(f"Остаток {i.stock}"))
        main_lay.addWidget(info_fr, stretch=1)

        disc_fr = QFrame()
        disc_fr.setFrameShape(shape)
        disc_fr.setFixedWidth(200)
        disc_lay = QVBoxLayout(disc_fr)
        disc_lay.setAlignment(Qt.AlignmentFlag.AlignCenter)

        disc_lay.addWidget(QLabel(f"Действующая скидка {i.discount}"))
        if self.role == "admin":
            self.edit_btn = QPushButton("Редактировать")
            self.edit_btn.clicked.connect(self.open_edit_form)
            disc_lay.addWidget(self.edit_btn)

            self.del_btn = QPushButton("Удалить")
            self.del_btn.clicked.connect(self.handle_delete)
            disc_lay.addWidget(self.del_btn)

        main_lay.addWidget(disc_fr)

        if i.stock == 0:
            self.setStyleSheet("background-color: #91918c; color: white;")
        elif i.discount > 15:
            self.setStyleSheet("background-color: #22e08e; color: black;")

    def handle_delete(self):
        ans = QMessageBox.question(None, "Подтверждение", "Вы точно хотите удалить товар?")
        if ans == QMessageBox.StandardButton.Yes:
            res = self.repo.delete_item(self.i.item_id)
            if res == "success":
                QMessageBox.information(None, "Успех", "Товар был удалён")
                self.delete_signal()
            else:
                QMessageBox.critical(None, "Ошибка", f"Не удалось удалить товар {res}")

    def open_edit_form(self):
        from item_form_window import ItemFormWindow
        self.form = ItemFormWindow(item=self.i, callback=self.delete_signal)
        self.form.show()
''',

        "item_form_window.py": r'''from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLineEdit, QPushButton, QMessageBox
from database.repository import Repository

class ItemFormWindow(QWidget):
    def __init__(self, item=None, callback=None):
        super().__init__()
        self.item = item
        self.callback = callback
        self.repo = Repository()

        self.setWindowTitle("Редактировать товар" if item else "Добавить товар")
        self.resize(350, 450)

        lay = QVBoxLayout(self)
        lay.setSpacing(10)

        self.fields = {
            "item_name": QLineEdit(placeholderText="Название товара"),
            "category_id": QLineEdit(placeholderText="ID Категории (1, 2, 3...)"),
            "brand_id": QLineEdit(placeholderText="ID Бренда (1, 2, 3...)"),
            "supplier_id": QLineEdit(placeholderText="ID Поставщика (1, 2, 3...)"),
            "price": QLineEdit(placeholderText="Цена"),
            "discount": QLineEdit(placeholderText="Скидка %"),
            "stock": QLineEdit(placeholderText="Остаток на складе"),
            "image_path": QLineEdit(placeholderText="Имя файла картинки (например, item.jpg)"),
            "description": QLineEdit(placeholderText="Описание товара")
        }

        for widget in self.fields.values():
            lay.addWidget(widget)

        if self.item:
            for key, widget in self.fields.items():
                widget.setText(str(getattr(self.item, key, '')))

        self.btn = QPushButton("Сохранить")
        self.btn.clicked.connect(self.save)
        lay.addWidget(self.btn)

    def save(self):
        d = {k: w.text().strip() for k, w in self.fields.items()}

        if not d["item_name"] or not d["price"]:
            QMessageBox.warning(self, "Валидация", "Название и Цена обязательны к заполнению!")
            return

        try:
            price_val = float(d["price"])
            discount_val = int(d["discount"]) if d["discount"] else 0
            stock_val = int(d["stock"]) if d["stock"] else 0

            if price_val < 0 or discount_val < 0 or discount_val > 100 or stock_val < 0:
                raise ValueError()
        except ValueError:
            QMessageBox.warning(self, "Валидация", "Проверьте корректность числовых полей (Скидка от 0 до 100)!")
            return

        if self.item:
            res = self.repo.update_item(
                self.item.item_id, d["item_name"], d["category_id"], d["brand_id"],
                d["supplier_id"], d["price"], d["discount"], d["stock"],
                d["description"], d["image_path"]
            )
        else:
            res = self.repo.add_item(
                d["item_name"], d["category_id"], d["brand_id"],
                d["supplier_id"], d["price"], d["discount"], d["stock"],
                d["description"], d["image_path"]
            )

        if res == "success":
            QMessageBox.information(self, "Успех", "Данные успешно сохранены!")
            if self.callback:
                self.callback()
            self.close()
        else:
            QMessageBox.critical(self, "Ошибка БД", f"Не удалось сохранить: {res}")
''',

        "orders_window.py": r'''from PyQt6.QtWidgets import QWidget, QLabel, QLineEdit, QScrollArea, QComboBox, QBoxLayout, QHBoxLayout, QVBoxLayout, \
    QPushButton
from PyQt6.QtCore import Qt
from database.repository import Repository
from order_widget import OrderWidget

class OrdersWindow(QWidget):
    def __init__(self, user):
        super().__init__()
        self.user = user
        self.role = user.role_name.lower()
        self.repo = Repository()

        self.setWindowTitle("Магазин товаров")
        self.resize(1100,700)

        main_lay = QVBoxLayout(self)

        header = QHBoxLayout()
        self.ex_btn = QPushButton("Назад")
        self.ex_btn.clicked.connect(self.exit)
        header.addWidget(self.ex_btn)
        header.addStretch()
        main_lay.addLayout(header)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.container = QWidget()
        self.lay_list = QVBoxLayout(self.container)
        self.lay_list.setAlignment(Qt.AlignmentFlag.AlignTop)

        self.scroll.setWidget(self.container)
        main_lay.addWidget(self.scroll)

        self.load_orders()

    def load_orders(self):
        while self.lay_list.count():
            item = self.lay_list.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        orders = self.repo.get_orders() or []

        for o in orders:
            card = OrderWidget(o)
            self.lay_list.addWidget(card)

    def exit(self):
        from items_window import ItemsWindow
        self.close()
        self.i = ItemsWindow(self.user)
        self.i.show()
''',

        "order_widget.py": r'''from PyQt6.QtWidgets import QFrame, QHBoxLayout, QVBoxLayout, QLabel, QPushButton, QMessageBox
from PyQt6.QtCore import Qt
from database.repository import Repository

class OrderWidget(QFrame):
    def __init__(self, order):
        super().__init__()
        self.order = order
        self.repo = Repository()

        shape = QFrame.Shape.Box
        self.setFrameShape(shape)
        self.setFixedHeight(180)

        main_lay = QHBoxLayout(self)
        main_lay.setSpacing(15)

        info_fr = QFrame()
        info_fr.setFrameShape(shape)
        info_lay = QVBoxLayout(info_fr)

        info_lay.addWidget(QLabel(f"<b>Артикул {order.order_id}</b>"))
        info_lay.addWidget(QLabel(f"Статус: {order.status}"))
        info_lay.addWidget(QLabel(f"Адрес: {order.address}"))
        info_lay.addWidget(QLabel(f"Дата заказа {order.order_date}"))
        info_lay.addWidget(QLabel(f"Состав заказа{order.items_list}"))
        main_lay.addWidget(info_fr, stretch=1)

        disc_fr = QFrame()
        disc_fr.setFrameShape(shape)
        disc_fr.setFixedWidth(200)
        disc_lay = QVBoxLayout(disc_fr)
        disc_lay.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # Исправлена кавычка внутри f-строки
        disc_lay.addWidget(QLabel(f"Дата прибытия {order.arrival_date if order.arrival_date else 'Не назначена'}"))
        main_lay.addWidget(disc_fr)
''',

        "main.py": r'''from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLineEdit, QPushButton, QMessageBox, QApplication
from database.repository import Repository
from items_window import ItemsWindow
from models.user import User
import sys
import traceback

def exp(a,b,c):
    f = "".join(traceback.format_exception(a,b,c))
    print(f)
    sys.exit(1)

sys.excepthook = exp

class LoginWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.repo = Repository()

        self.setWindowTitle("Авторизация")
        self.resize(300, 200)

        main_lay = QVBoxLayout(self)

        self.login = QLineEdit(placeholderText="Логин")
        self.password = QLineEdit(placeholderText="Пароль", echoMode=QLineEdit.EchoMode.Password)
        self.en_btn = QPushButton("Войти")
        self.g_btn = QPushButton("Войти как гость")
        self.en_btn.clicked.connect(self.auth)
        self.g_btn.clicked.connect(self.open_guest)

        main_lay.addWidget(self.login)
        main_lay.addWidget(self.password)
        main_lay.addWidget(self.en_btn)
        main_lay.addWidget(self.g_btn)

    def auth(self):
        user = self.repo.find_user(self.login.text(), self.password.text())
        if user: self.open_catalog(user)
        else: QMessageBox.critical(self, "Ошибка", "Такого пользователя нет")

    def open_guest(self):
        self.open_catalog(User.create_guest())

    def open_catalog(self, user):
        self.l = ItemsWindow(user)
        self.l.show()
        self.close()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    w = LoginWindow()
    w.show()
    app.exec()
'''
    }

    for path, content in files.items():
        write_file(path, content)