"""Stable plugin-facing protocols."""
