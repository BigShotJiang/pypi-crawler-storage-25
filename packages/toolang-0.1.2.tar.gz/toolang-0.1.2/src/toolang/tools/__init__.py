"""Built-in tool plugins."""
