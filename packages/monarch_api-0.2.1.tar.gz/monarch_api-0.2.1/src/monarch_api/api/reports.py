from __future__ import annotations

from ..documents import (
    GET_CASH_FLOW_DASHBOARD,
    GET_CASH_FLOW_ENTITY_AGGREGATES,
    GET_CASH_FLOW_TIMEFRAME_AGGREGATES,
    GET_REPORTS_DATA,
)
from ..models.reports import (
    CashFlowDashboardResult,
    CashFlowEntityAggregatesResult,
    CashFlowTimeframeAggregatesResult,
    ReportsDataRequest,
    ReportsDataResult,
)
from ..models.transactions import TransactionFilter
from ..transport import MonarchTransport


class ReportsAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def cash_flow_dashboard(self, *, filters: TransactionFilter | None = None) -> CashFlowDashboardResult:
        return CashFlowDashboardResult.from_api(self._transport.graphql(
            "Common_GetCashFlowDashboard",
            GET_CASH_FLOW_DASHBOARD,
            {"filters": filters.to_input() if filters is not None else {}},
        ))

    def cash_flow_entity_aggregates(self, *, filters: TransactionFilter | None = None) -> CashFlowEntityAggregatesResult:
        return CashFlowEntityAggregatesResult.from_api(self._transport.graphql(
            "Common_GetCashFlowEntityAggregates",
            GET_CASH_FLOW_ENTITY_AGGREGATES,
            {"filters": filters.to_input() if filters is not None else {}},
        ))

    def cash_flow_timeframe_aggregates(self, *, filters: TransactionFilter | None = None) -> CashFlowTimeframeAggregatesResult:
        return CashFlowTimeframeAggregatesResult.from_api(self._transport.graphql(
            "Common_GetCashFlowTimeframeAggregates",
            GET_CASH_FLOW_TIMEFRAME_AGGREGATES,
            {"filters": filters.to_input() if filters is not None else {}},
        ))

    def data(self, request: ReportsDataRequest) -> ReportsDataResult:
        return ReportsDataResult.from_api(self._transport.graphql(
            "Common_GetReportsData",
            GET_REPORTS_DATA,
            request.to_input(),
        ))
