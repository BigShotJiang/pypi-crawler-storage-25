from __future__ import annotations

from ..documents import (
    GET_INVESTMENTS_ACCOUNTS,
    GET_INVESTMENTS_DASHBOARD_CARD,
    GET_PORTFOLIO,
    GET_SECURITIES_HISTORICAL_PERFORMANCE,
)
from ..models.investments import (
    InvestmentAccount,
    InvestmentsDashboardCard,
    Portfolio,
    PortfolioRequest,
    SecurityHistoricalPerformance,
    SecurityHistoricalPerformanceRequest,
)
from ..transport import MonarchTransport


class InvestmentsAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def accounts(self) -> list[InvestmentAccount]:
        data = self._transport.graphql(
            "Web_GetInvestmentsAccounts",
            GET_INVESTMENTS_ACCOUNTS,
            {},
        )
        return [InvestmentAccount.from_api(item) for item in data["accounts"]]

    def dashboard_card(self) -> InvestmentsDashboardCard:
        return InvestmentsDashboardCard.from_api(self._transport.graphql(
            "Web_GetInvestmentsDashboardCard",
            GET_INVESTMENTS_DASHBOARD_CARD,
            {},
        ))

    def portfolio(self, request: PortfolioRequest | None = None) -> Portfolio:
        data = self._transport.graphql(
            "Web_GetPortfolio",
            GET_PORTFOLIO,
            {"portfolioInput": request.to_input() if request is not None else None},
        )
        return Portfolio.from_api(data["portfolio"])

    def securities_historical_performance(
        self,
        request: SecurityHistoricalPerformanceRequest,
    ) -> list[SecurityHistoricalPerformance]:
        data = self._transport.graphql(
            "Web_GetSecuritiesHistoricalPerformance",
            GET_SECURITIES_HISTORICAL_PERFORMANCE,
            {"input": request.to_input()},
        )
        return [SecurityHistoricalPerformance.from_api(item) for item in data["securityHistoricalPerformance"]]
