from __future__ import annotations

from typing import Any, Mapping

from ..documents import (
    CREATE_TRANSACTION_RULE,
    DELETE_ALL_TRANSACTION_RULES,
    DELETE_TRANSACTION_RULE,
    GET_TRANSACTION_RULES,
    PREVIEW_TRANSACTION_RULE,
    UPDATE_TRANSACTION_RULE,
    UPDATE_TRANSACTION_RULE_ORDER,
)
from ..exceptions import MonarchGraphQLError
from ..models.rules import (
    CreateTransactionRuleRequest,
    DeleteAllTransactionRulesResult,
    DeleteTransactionRuleResult,
    TransactionRule,
    TransactionRuleMutationResult,
    TransactionRulePreviewRequest,
    TransactionRulePreviewResult,
    UpdateTransactionRuleOrderResult,
    UpdateTransactionRuleRequest,
)
from ..transport import MonarchTransport


class RulesAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def list(self) -> list[TransactionRule]:
        data = self._transport.graphql(
            "GetTransactionRules",
            GET_TRANSACTION_RULES,
            {},
        )
        return [TransactionRule.from_api(item) for item in data["transactionRules"]]

    def create(self, request: CreateTransactionRuleRequest) -> TransactionRuleMutationResult:
        return TransactionRuleMutationResult.from_api(self._payload(
            "createTransactionRuleV2",
            self._transport.graphql(
                "Common_CreateTransactionRuleMutationV2",
                CREATE_TRANSACTION_RULE,
                {"input": request.to_input()},
            ),
        ))

    def update(self, request: UpdateTransactionRuleRequest) -> TransactionRuleMutationResult:
        return TransactionRuleMutationResult.from_api(self._payload(
            "updateTransactionRuleV2",
            self._transport.graphql(
                "Common_UpdateTransactionRuleMutationV2",
                UPDATE_TRANSACTION_RULE,
                {"input": request.to_input()},
            ),
        ))

    def delete(self, rule_id: str) -> DeleteTransactionRuleResult:
        return DeleteTransactionRuleResult.from_api(self._payload(
            "deleteTransactionRule",
            self._transport.graphql(
                "Common_DeleteTransactionRule",
                DELETE_TRANSACTION_RULE,
                {"id": rule_id},
            ),
        ))

    def preview(self, request: TransactionRulePreviewRequest, *, offset: int | None = None) -> TransactionRulePreviewResult:
        variables: dict[str, Any] = {"rule": request.to_input()}
        if offset is not None:
            variables["offset"] = offset
        data = self._transport.graphql(
            "Common_PreviewTransactionRule",
            PREVIEW_TRANSACTION_RULE,
            variables,
        )
        return TransactionRulePreviewResult.from_api(data["transactionRulePreview"])

    def update_order(self, rule_id: str, order: int) -> UpdateTransactionRuleOrderResult:
        return UpdateTransactionRuleOrderResult.from_api(self._payload(
            "updateTransactionRuleOrderV2",
            self._transport.graphql(
                "Web_UpdateRuleOrderMutation",
                UPDATE_TRANSACTION_RULE_ORDER,
                {"id": rule_id, "order": order},
            ),
        ))

    def delete_all(self) -> DeleteAllTransactionRulesResult:
        return DeleteAllTransactionRulesResult.from_api(self._payload(
            "deleteAllTransactionRules",
            self._transport.graphql(
                "Web_DeleteAllTransactionRulesMutation",
                DELETE_ALL_TRANSACTION_RULES,
                {},
            ),
        ))

    @staticmethod
    def _payload(field_name: str, data: Mapping[str, Any]) -> Mapping[str, Any]:
        payload = data.get(field_name)
        if not isinstance(payload, Mapping):
            raise MonarchGraphQLError(f"Expected payload object for {field_name}.", data)
        return payload
