from __future__ import annotations

from ..documents import (
    GET_BUSINESS_ENTITIES,
    GET_BUSINESS_ENTITIES_BANNER_PROFILE,
    GET_DASHBOARD_CONFIG,
    GET_HAS_ACTIVITY,
    GET_HOUSEHOLD_MEMBER_SETTINGS,
    GET_NOTIFICATION_PREFERENCES,
    GET_OLDEST_DELETABLE_SYNCED_SNAPSHOT_DATE,
    GET_OLDEST_DELETABLE_TRANSACTION_DATE,
    GET_REVIEW_SUMMARY_BY_USER,
    GET_SECURITY_SETTINGS,
    GET_SIDEBAR_DATA,
    GET_USER_PROFILE_FLAGS,
)
from ..models.settings import (
    BusinessEntitiesBannerProfile,
    BusinessEntity,
    HasActivityStatus,
    HouseholdDashboard,
    HouseholdMemberSettings,
    NotificationPreference,
    ReviewSummaryByUserEntry,
    SecuritySettings,
    SidebarData,
    UserProfileFlags,
)
from ..transport import MonarchTransport


class SettingsAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def user_profile_flags(self) -> UserProfileFlags:
        data = self._transport.graphql(
            "Common_UserProfileFlags",
            GET_USER_PROFILE_FLAGS,
            {},
        )
        return UserProfileFlags.from_api(data["userProfile"])

    def dashboard_config(self) -> HouseholdDashboard:
        data = self._transport.graphql(
            "GetDashboardConfig",
            GET_DASHBOARD_CONFIG,
            {},
        )
        return HouseholdDashboard.from_api(data["myHousehold"])

    def oldest_deletable_synced_snapshot_date(self) -> str | None:
        data = self._transport.graphql(
            "OldestDeletableSyncedSnapshotDate",
            GET_OLDEST_DELETABLE_SYNCED_SNAPSHOT_DATE,
            {},
        )
        return data.get("oldestDeletableSyncedSnapshotDate")

    def oldest_deletable_transaction_date(
        self,
        *,
        include_synced: bool = False,
        include_uploaded: bool = False,
        include_manual: bool = False,
    ) -> str | None:
        data = self._transport.graphql(
            "Common_OldestDeletableTransactionDate",
            GET_OLDEST_DELETABLE_TRANSACTION_DATE,
            {
                "includeSynced": include_synced,
                "includeUploaded": include_uploaded,
                "includeManual": include_manual,
            },
        )
        return data.get("oldestDeletableTransactionDate")

    def sidebar_data(self, *, promo_code: str | None = None) -> SidebarData:
        return SidebarData.from_api(self._transport.graphql(
            "Web_GetSidebarData",
            GET_SIDEBAR_DATA,
            {"promoCode": promo_code},
        ))

    def household_member_settings(self) -> HouseholdMemberSettings:
        return HouseholdMemberSettings.from_api(self._transport.graphql(
            "Common_GetHouseHoldMemberSettings",
            GET_HOUSEHOLD_MEMBER_SETTINGS,
            {},
        ))

    def security_settings(self) -> SecuritySettings:
        return SecuritySettings.from_api(self._transport.graphql(
            "Web_GetSecuritySettings",
            GET_SECURITY_SETTINGS,
            {},
        ))

    def notification_preferences(self) -> list[NotificationPreference]:
        data = self._transport.graphql(
            "Common_GetNotificationPreferences",
            GET_NOTIFICATION_PREFERENCES,
            {},
        )
        return [NotificationPreference.from_api(item) for item in data["notificationPreferences"]]

    def review_summary_by_user(self) -> list[ReviewSummaryByUserEntry]:
        data = self._transport.graphql(
            "Common_GetReviewSummaryByUser",
            GET_REVIEW_SUMMARY_BY_USER,
            {},
        )
        return [ReviewSummaryByUserEntry.from_api(item) for item in data["byNeedsReviewByUser"]]

    def business_entities_banner_profile(self) -> BusinessEntitiesBannerProfile | None:
        data = self._transport.graphql(
            "Common_GetBusinessEntitiesBannerProfile",
            GET_BUSINESS_ENTITIES_BANNER_PROFILE,
            {},
        )
        profile = (data.get("me") or {}).get("profile")
        return BusinessEntitiesBannerProfile.from_api(profile) if isinstance(profile, dict) else None

    def business_entities(self) -> list[BusinessEntity]:
        data = self._transport.graphql(
            "Common_GetBusinessEntities",
            GET_BUSINESS_ENTITIES,
            {},
        )
        return [BusinessEntity.from_api(item) for item in data["businessEntities"]]

    def has_activity(self) -> HasActivityStatus:
        data = self._transport.graphql(
            "Common_HasActivity",
            GET_HAS_ACTIVITY,
            {},
        )
        return HasActivityStatus.from_api(data["me"])
