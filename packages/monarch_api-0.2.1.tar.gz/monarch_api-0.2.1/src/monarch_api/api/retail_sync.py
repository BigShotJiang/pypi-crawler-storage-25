from __future__ import annotations

from typing import Any, Mapping

from ..documents import (
    COMPLETE_RETAIL_SYNC,
    CREATE_BULK_RETAIL_SYNC,
    CREATE_RETAIL_SYNC,
    DELETE_RETAIL_SYNC,
    GET_RETAIL_EXTENSION_SETTINGS,
    GET_RETAIL_SYNC,
    LIST_RETAIL_SYNCS,
    MATCH_RETAIL_TRANSACTION,
    START_RETAIL_SYNC,
    UNMATCH_RETAIL_TRANSACTION,
    UPDATE_RETAIL_ORDER,
    UPDATE_RETAIL_VENDOR_SETTINGS,
)
from ..exceptions import MonarchGraphQLError
from ..models.retail_sync import (
    BulkRetailSyncMutationResult,
    CreateBulkRetailSyncRequest,
    CreateRetailSyncRequest,
    DeleteRetailSyncResult,
    RetailExtensionSettings,
    RetailSync,
    RetailSyncFilter,
    RetailSyncListResult,
    RetailSyncMutationResult,
    UpdateRetailOrderRequest,
    UpdateRetailVendorSettingsRequest,
    UpdateRetailVendorSettingsResult,
)
from ..transport import MonarchTransport


class RetailSyncAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def get_settings(self) -> RetailExtensionSettings:
        data = self._transport.graphql(
            "Common_GetRetailExtensionSettings",
            GET_RETAIL_EXTENSION_SETTINGS,
            {},
        )
        return RetailExtensionSettings.from_api(data["retailExtensionSettings"])

    def get(self, sync_id: str) -> RetailSync:
        data = self._transport.graphql(
            "Common_RetailSyncQuery",
            GET_RETAIL_SYNC,
            {"syncId": sync_id},
        )
        return RetailSync.from_api(data["retailSync"])

    def list(
        self,
        *,
        filters: RetailSyncFilter,
        offset: int = 0,
        limit: int = 50,
        include_total_count: bool = True,
    ) -> RetailSyncListResult:
        data = self._transport.graphql(
            "Common_RetailSyncsQueryWithTotal",
            LIST_RETAIL_SYNCS,
            {
                "filters": filters.to_input(),
                "offset": offset,
                "limit": limit,
                "includeTotalCount": include_total_count,
            },
        )
        return RetailSyncListResult.from_api(data["retailSyncsWithTotal"])

    def create(self, request: CreateRetailSyncRequest) -> RetailSyncMutationResult:
        return RetailSyncMutationResult.from_api(self._payload(
            "createRetailSync",
            self._transport.graphql(
                "Common_CreateRetailSync",
                CREATE_RETAIL_SYNC,
                {"input": request.to_input()},
            ),
        ))

    def create_bulk(self, request: CreateBulkRetailSyncRequest) -> BulkRetailSyncMutationResult:
        return BulkRetailSyncMutationResult.from_api(self._payload(
            "createBulkRetailSync",
            self._transport.graphql(
                "Common_CreateBulkRetailSync",
                CREATE_BULK_RETAIL_SYNC,
                {"input": request.to_input()},
            ),
        ))

    def start(self, sync_id: str) -> RetailSyncMutationResult:
        return RetailSyncMutationResult.from_api(self._payload(
            "startRetailSync",
            self._transport.graphql(
                "Common_StartRetailSync",
                START_RETAIL_SYNC,
                {"syncId": sync_id},
            ),
        ))

    def complete(self, sync_id: str) -> RetailSyncMutationResult:
        return RetailSyncMutationResult.from_api(self._payload(
            "completeRetailSync",
            self._transport.graphql(
                "Common_CompleteRetailSync",
                COMPLETE_RETAIL_SYNC,
                {"syncId": sync_id},
            ),
        ))

    def delete(self, sync_id: str) -> DeleteRetailSyncResult:
        return DeleteRetailSyncResult.from_api(self._payload(
            "deleteUnmatchedRetailSync",
            self._transport.graphql(
                "Common_DeleteRetailSync",
                DELETE_RETAIL_SYNC,
                {"syncId": sync_id},
            ),
        ))

    def match_transaction(self, retail_transaction_id: str, transaction_id: str) -> RetailSyncMutationResult:
        return RetailSyncMutationResult.from_api(self._payload(
            "matchRetailTransaction",
            self._transport.graphql(
                "Common_MatchRetailTransaction",
                MATCH_RETAIL_TRANSACTION,
                {"retailTransactionId": retail_transaction_id, "transactionId": transaction_id},
            ),
        ))

    def unmatch_transaction(self, retail_transaction_id: str) -> RetailSyncMutationResult:
        return RetailSyncMutationResult.from_api(self._payload(
            "unmatchRetailTransaction",
            self._transport.graphql(
                "Web_UnmatchRetailTransaction",
                UNMATCH_RETAIL_TRANSACTION,
                {"retailTransactionId": retail_transaction_id},
            ),
        ))

    def update_order(self, request: UpdateRetailOrderRequest) -> RetailSyncMutationResult:
        return RetailSyncMutationResult.from_api(self._payload(
            "updateRetailOrder",
            self._transport.graphql(
                "Common_UpdateRetailOrder",
                UPDATE_RETAIL_ORDER,
                {"input": request.to_input()},
            ),
        ))

    def update_vendor_settings(self, request: UpdateRetailVendorSettingsRequest) -> UpdateRetailVendorSettingsResult:
        return UpdateRetailVendorSettingsResult.from_api(self._payload(
            "updateRetailVendorSettings",
            self._transport.graphql(
                "Common_UpdateRetailVendorSettings",
                UPDATE_RETAIL_VENDOR_SETTINGS,
                {"input": request.to_input()},
            ),
        ))

    @staticmethod
    def _payload(field_name: str, data: Mapping[str, Any]) -> Mapping[str, Any]:
        payload = data.get(field_name)
        if not isinstance(payload, Mapping):
            raise MonarchGraphQLError(f"Expected {field_name} payload.", data)
        return payload
