from __future__ import annotations

from ..documents import GET_BUDGET_DATA, GET_JOINT_PLANNING_DATA
from ..models.planning import BudgetDataResult, JointPlanningDataResult
from ..transport import MonarchTransport


class PlanningAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def budget_data(self, *, start_date: str, end_date: str) -> BudgetDataResult:
        return BudgetDataResult.from_api(self._transport.graphql(
            "Common_BudgetDataQuery",
            GET_BUDGET_DATA,
            {
                "startDate": start_date,
                "endDate": end_date,
            },
        ))

    def joint_planning_data(self, *, start_date: str, end_date: str) -> JointPlanningDataResult:
        return JointPlanningDataResult.from_api(self._transport.graphql(
            "Common_GetJointPlanningData",
            GET_JOINT_PLANNING_DATA,
            {
                "startDate": start_date,
                "endDate": end_date,
            },
        ))
