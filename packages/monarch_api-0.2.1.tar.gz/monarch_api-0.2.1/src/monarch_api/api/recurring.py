from __future__ import annotations

from ..documents import (
    GET_AGGREGATED_RECURRING_ITEMS,
    GET_DASHBOARD_UPCOMING_RECURRING_ITEMS,
    GET_RECURRING_PAUSED_BANNER,
    GET_RECURRING_STREAMS,
)
from ..models.recurring import (
    AggregatedRecurringItemsRequest,
    AggregatedRecurringItemsResult,
    DashboardUpcomingRecurringItemsRequest,
    DashboardUpcomingRecurringItemsResult,
    RecurringPausedBanner,
    RecurringStreamEntry,
)
from ..transport import MonarchTransport


class RecurringAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def streams(self, *, include_liabilities: bool | None = None) -> list[RecurringStreamEntry]:
        data = self._transport.graphql(
            "Common_GetRecurringStreams",
            GET_RECURRING_STREAMS,
            {"includeLiabilities": include_liabilities},
        )
        return [RecurringStreamEntry.from_api(item) for item in data["recurringTransactionStreams"]]

    def aggregated_items(self, request: AggregatedRecurringItemsRequest) -> AggregatedRecurringItemsResult:
        data = self._transport.graphql(
            "Common_GetAggregatedRecurringItems",
            GET_AGGREGATED_RECURRING_ITEMS,
            request.to_input(),
        )
        return AggregatedRecurringItemsResult.from_api(data["aggregatedRecurringItems"])

    def dashboard_upcoming_items(
        self,
        request: DashboardUpcomingRecurringItemsRequest,
    ) -> DashboardUpcomingRecurringItemsResult:
        return DashboardUpcomingRecurringItemsResult.from_api(self._transport.graphql(
            "Web_GetDashboardUpcomingRecurringTransactionItems",
            GET_DASHBOARD_UPCOMING_RECURRING_ITEMS,
            request.to_input(),
        ))

    def paused_banner(self) -> RecurringPausedBanner:
        return RecurringPausedBanner.from_api(self._transport.graphql(
            "Web_RecurringPausedBanner",
            GET_RECURRING_PAUSED_BANNER,
            {},
        ))
