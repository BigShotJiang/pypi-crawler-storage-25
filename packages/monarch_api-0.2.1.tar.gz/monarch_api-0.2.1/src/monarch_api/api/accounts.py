from __future__ import annotations

from typing import Any, Mapping
from urllib.parse import urlencode

from ..documents import (
    FORCE_REFRESH_ACCOUNT,
    FORCE_REFRESH_ALL_ACCOUNTS,
    GET_ACTIVE_INSTITUTION_NOTICES,
    GET_AGGREGATE_SNAPSHOTS,
    GET_ACCOUNT_FILTER_QUERY,
    GET_ACCOUNT_TYPES,
    GET_ACCOUNTS_PAGE,
    GET_ACCOUNTS_PAGE_RECENT_BALANCE,
    GET_ACCOUNTS_SYNCING,
    GET_DISPLAY_BALANCE_AT_DATE,
    GET_FILTERED_ACCOUNTS,
    GET_FORCE_REFRESH_ACCOUNT,
    GET_FORCE_REFRESH_OPERATION,
    GET_HAS_ACCOUNTS,
    GET_INSTITUTION_SETTINGS,
    GET_LATEST_FORCE_REFRESH_OPERATION,
    GET_SNAPSHOTS_BY_ACCOUNT_TYPE,
)
from ..exceptions import MonarchGraphQLError
from ..models.accounts import (
    AccountFilter,
    AccountFilterOptions,
    AccountListItem,
    AccountsPage,
    AccountsSyncStatus,
    AccountTypeDetail,
    ActiveInstitutionNotice,
    AggregateSnapshotFilter,
    AggregateSnapshot,
    DisplayBalanceAccount,
    FilteredAccount,
    ForceRefreshAccountRequest,
    ForceRefreshAccountStatus,
    ForceRefreshAllAccountsRequest,
    ForceRefreshOperation,
    ForceRefreshResult,
    InstitutionMetadata,
    InstitutionMetadataList,
    InstitutionSettings,
    RecentBalanceAccount,
    SnapshotsByAccountTypeRequest,
    SnapshotsByAccountTypeResult,
)
from ..transport import MonarchTransport

INSTITUTIONS_BASE_URL = "https://iss-api.monarch.com/api/v1/institutions/"


class AccountsAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def has_accounts(self) -> bool:
        data = self._transport.graphql(
            "Common_GetHasAccounts",
            GET_HAS_ACCOUNTS,
            {},
        )
        return bool(data["hasAccounts"])

    def active_institution_notices(self) -> list[ActiveInstitutionNotice]:
        data = self._transport.graphql(
            "Common_AllActiveInstitutionNotices",
            GET_ACTIVE_INSTITUTION_NOTICES,
            {},
        )
        return [ActiveInstitutionNotice.from_api(item) for item in data["activeInstitutionNotices"]]

    def aggregate_snapshots(self, *, filters: AggregateSnapshotFilter | None = None) -> list[AggregateSnapshot]:
        data = self._transport.graphql(
            "Common_GetAggregateSnapshots",
            GET_AGGREGATE_SNAPSHOTS,
            {"filters": filters.to_input() if filters is not None else {}},
        )
        return [AggregateSnapshot.from_api(item) for item in data["aggregateSnapshots"]]

    def syncing_status(self) -> AccountsSyncStatus:
        return AccountsSyncStatus.from_api(self._transport.graphql(
            "Common_ForceRefreshAccountsQuery",
            GET_ACCOUNTS_SYNCING,
            {},
        ))

    def latest_force_refresh_operation(self) -> ForceRefreshOperation | None:
        data = self._transport.graphql(
            "Common_LatestForceRefreshOperation",
            GET_LATEST_FORCE_REFRESH_OPERATION,
            {},
        )
        payload = data.get("latestForceRefreshOperation")
        return ForceRefreshOperation.from_api(payload) if isinstance(payload, dict) else None

    def force_refresh_operation(self, operation_id: str) -> ForceRefreshOperation:
        data = self._transport.graphql(
            "Common_ForceRefreshOperationQuery",
            GET_FORCE_REFRESH_OPERATION,
            {"id": operation_id},
        )
        return ForceRefreshOperation.from_api(data["forceRefreshOperation"])

    def force_refresh_account_status(self, account_id: str) -> ForceRefreshAccountStatus:
        data = self._transport.graphql(
            "Common_ForceRefreshAccountQuery",
            GET_FORCE_REFRESH_ACCOUNT,
            {"accountId": account_id},
        )
        return ForceRefreshAccountStatus.from_api(data["account"])

    def display_balance_at_date(self, *, date: str, filters: AccountFilter | None = None) -> list[DisplayBalanceAccount]:
        data = self._transport.graphql(
            "Common_GetDisplayBalanceAtDate",
            GET_DISPLAY_BALANCE_AT_DATE,
            {"date": date, "filters": filters.to_input() if filters is not None else {}},
        )
        return [DisplayBalanceAccount.from_api(item) for item in data["accounts"]]

    def snapshots_by_account_type(
        self,
        request: SnapshotsByAccountTypeRequest,
        *,
        filters: AccountFilter | None = None,
    ) -> SnapshotsByAccountTypeResult:
        return SnapshotsByAccountTypeResult.from_api(self._transport.graphql(
            "Common_GetSnapshotsByAccountType",
            GET_SNAPSHOTS_BY_ACCOUNT_TYPE,
            {
                **request.to_input(),
                "filters": filters.to_input() if filters is not None else {},
            },
        ))

    def page(self, *, filters: AccountFilter | None = None) -> AccountsPage:
        return AccountsPage.from_api(self._transport.graphql(
            "Web_GetAccountsPage",
            GET_ACCOUNTS_PAGE,
            {"filters": filters.to_input() if filters is not None else {}},
        ))

    def recent_balances(self, *, start_date: str | None = None) -> list[RecentBalanceAccount]:
        data = self._transport.graphql(
            "Web_GetAccountsPageRecentBalance",
            GET_ACCOUNTS_PAGE_RECENT_BALANCE,
            {"startDate": start_date},
        )
        return [RecentBalanceAccount.from_api(item) for item in data["accounts"]]

    def filtered(self, *, filters: AccountFilter | None = None) -> list[FilteredAccount]:
        data = self._transport.graphql(
            "Web_GetFilteredAccounts",
            GET_FILTERED_ACCOUNTS,
            {"filters": filters.to_input() if filters is not None else {}},
        )
        return [FilteredAccount.from_api(item) for item in data["accounts"]]

    def filters(self) -> AccountFilterOptions:
        return AccountFilterOptions.from_api(self._transport.graphql(
            "Web_AccountFilterQuery",
            GET_ACCOUNT_FILTER_QUERY,
            {},
        ))

    def account_types(self) -> list[AccountTypeDetail]:
        data = self._transport.graphql(
            "Web_GetAccountTypes",
            GET_ACCOUNT_TYPES,
            {},
        )
        return [AccountTypeDetail.from_api(item) for item in data["accountTypes"]]

    def institution_settings(self) -> InstitutionSettings:
        return InstitutionSettings.from_api(self._transport.graphql(
            "Web_GetInstitutionSettings",
            GET_INSTITUTION_SETTINGS,
            {},
        ))

    def force_refresh_account(self, request: ForceRefreshAccountRequest) -> ForceRefreshResult:
        return ForceRefreshResult.from_api(self._payload(
            "forceRefreshAccount",
            self._transport.graphql(
                "Common_ForceRefreshAccountMutation",
                FORCE_REFRESH_ACCOUNT,
                {"input": request.to_input()},
            ),
        ))

    def force_refresh_all(self, request: ForceRefreshAllAccountsRequest | None = None) -> ForceRefreshResult:
        variables: dict[str, Any] = {}
        if request is not None:
            variables["input"] = request.to_input()
        return ForceRefreshResult.from_api(self._payload(
            "forceRefreshAllAccounts",
            self._transport.graphql(
                "Common_ForceRefreshAccountsMutation",
                FORCE_REFRESH_ALL_ACCOUNTS,
                variables,
            ),
        ))

    def institutions(
        self,
        *,
        ids: list[str] | None = None,
        include_logo: bool | None = None,
    ) -> InstitutionMetadataList:
        query_items: list[tuple[str, str]] = []
        for institution_id in ids or []:
            query_items.append(("ids", institution_id))
        if include_logo is not None:
            query_items.append(("include_logo", str(include_logo).lower()))
        query = f"?{urlencode(query_items, doseq=True)}" if query_items else ""
        return InstitutionMetadataList.from_api(
            self._transport.rest_json(
                "GET",
                f"{INSTITUTIONS_BASE_URL}{query}",
                authenticated=False,
            )
        )

    def institution(self, institution_id: str) -> InstitutionMetadata:
        return InstitutionMetadata.from_api(
            self._transport.rest_json(
                "GET",
                f"{INSTITUTIONS_BASE_URL}{institution_id}",
                authenticated=False,
            )
        )

    @staticmethod
    def _payload(field_name: str, data: Mapping[str, Any]) -> Mapping[str, Any]:
        payload = data.get(field_name)
        if not isinstance(payload, Mapping):
            raise MonarchGraphQLError(f"Expected payload object for {field_name}.", data)
        return payload
