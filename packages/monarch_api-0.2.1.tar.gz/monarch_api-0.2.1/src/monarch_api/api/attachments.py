from __future__ import annotations

from typing import Any, Mapping

from ..documents import (
    ADD_TRANSACTION_ATTACHMENT,
    DELETE_ATTACHMENT,
    GET_ATTACHMENT_DETAILS,
    GET_TRANSACTION_ATTACHMENT_UPLOAD_INFO,
)
from ..exceptions import MonarchGraphQLError
from ..models.attachments import AddTransactionAttachmentRequest, AddTransactionAttachmentResult, AttachmentDetail, AttachmentUploadInfo
from ..transport import MonarchTransport


class AttachmentsAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def get_upload_info(self, transaction_id: str) -> AttachmentUploadInfo:
        data = self._transport.graphql(
            "Common_GetTransactionAttachmentUploadInfo",
            GET_TRANSACTION_ATTACHMENT_UPLOAD_INFO,
            {"transactionId": transaction_id},
        )
        return AttachmentUploadInfo.from_api(data["getTransactionAttachmentUploadInfo"])

    def add(self, request: AddTransactionAttachmentRequest) -> AddTransactionAttachmentResult:
        data = self._transport.graphql(
            "Common_AddTransactionAttachment",
            ADD_TRANSACTION_ATTACHMENT,
            {"input": request.to_input()},
        )
        payload = data.get("addTransactionAttachment")
        if not isinstance(payload, Mapping):
            raise MonarchGraphQLError("Expected addTransactionAttachment payload.", data)
        return AddTransactionAttachmentResult.from_api(payload)

    def get(self, attachment_id: str) -> AttachmentDetail:
        data = self._transport.graphql(
            "Mobile_GetAttachmentDetails",
            GET_ATTACHMENT_DETAILS,
            {"attachmentId": attachment_id},
        )
        return AttachmentDetail.from_api(data["transactionAttachment"])

    def delete(self, attachment_id: str) -> bool:
        data = self._transport.graphql(
            "Web_TransactionDrawerDeleteAttachment",
            DELETE_ATTACHMENT,
            {"id": attachment_id},
        )
        return bool(data["deleteTransactionAttachment"]["deleted"])
