from __future__ import annotations

from ..documents import (
    GET_GOALS_DASHBOARD_CARD,
    GET_LEGACY_GOALS_MIGRATION,
    GET_SAVINGS_GOAL_ACCOUNT,
    GET_SAVINGS_GOALS,
    GET_SAVINGS_GOALS_WITH_THIS_MONTH_BALANCES,
)
from ..models.goals import (
    GoalDashboardRow,
    LegacyGoalsMigrationStatus,
    SavingsGoal,
    SavingsGoalAccount,
    SavingsGoalsWithBalancesResult,
)
from ..transport import MonarchTransport


class GoalsAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def savings_goals(self) -> list[SavingsGoal]:
        data = self._transport.graphql(
            "Common_SavingsGoals",
            GET_SAVINGS_GOALS,
            {},
        )
        return [SavingsGoal.from_api(item) for item in data["savingsGoals"]]

    def savings_goals_with_this_month_balances(self) -> SavingsGoalsWithBalancesResult:
        return SavingsGoalsWithBalancesResult.from_api(self._transport.graphql(
            "Common_SavingsGoalsWithThisMonthBalances",
            GET_SAVINGS_GOALS_WITH_THIS_MONTH_BALANCES,
            {},
        ))

    def savings_goal_account(self, account_id: str) -> SavingsGoalAccount:
        data = self._transport.graphql(
            "Common_SavingsGoalAccount",
            GET_SAVINGS_GOAL_ACCOUNT,
            {"id": account_id},
        )
        return SavingsGoalAccount.from_api(data["account"])

    def dashboard_card(self) -> list[GoalDashboardRow]:
        data = self._transport.graphql(
            "Web_GoalsDashboardCardV2",
            GET_GOALS_DASHBOARD_CARD,
            {},
        )
        return [GoalDashboardRow.from_api(item) for item in data["goalsV2"]]

    def legacy_migration(self) -> LegacyGoalsMigrationStatus:
        return LegacyGoalsMigrationStatus.from_api(self._transport.graphql(
            "Common_LegacyGoalsMigrationQuery",
            GET_LEGACY_GOALS_MIGRATION,
            {},
        ))
