from __future__ import annotations

from typing import Any, Mapping

from ..documents import (
    CREATE_TRANSACTION,
    DELETE_TRANSACTION,
    GET_CATEGORIES,
    GET_HOUSEHOLD_TRANSACTION_TAGS,
    GET_TRANSACTION_DRAWER,
    GET_TRANSACTIONS_FILTER_QUERY,
    GET_TRANSACTIONS_LIST,
    GET_TRANSACTION_FILTERS_METADATA,
    SET_TRANSACTION_TAGS,
    UPDATE_TRANSACTION,
)
from ..exceptions import MonarchGraphQLError
from ..models.shared import MerchantRef, TagRef
from ..models.transactions import (
    BulkTransactionDataParams,
    TransactionCategoriesResult,
    CreateTransactionRequest,
    CreateTransactionResult,
    DeleteTransactionResult,
    SetTransactionTagsResult,
    TransactionDetail,
    TransactionFilter,
    TransactionFiltersMetadata,
    TransactionFiltersResult,
    TransactionListResult,
    UpdateTransactionRequest,
    UpdateTransactionResult,
)
from ..transport import MonarchTransport


class TransactionsAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def list(
        self,
        *,
        offset: int | None = None,
        limit: int = 25,
        filters: TransactionFilter | None = None,
        order_by: str = "date",
    ) -> TransactionListResult:
        resolved_filters = (
            filters.to_input()
            if filters is not None
            else TransactionFilter(transaction_visibility="non_hidden_transactions_only").to_input()
        )
        data = self._transport.graphql(
            "Web_GetTransactionsList",
            GET_TRANSACTIONS_LIST,
            {
                "offset": offset,
                "limit": limit,
                "filters": resolved_filters,
                "orderBy": order_by,
            },
        )
        return TransactionListResult.from_api(data)

    def get(self, transaction_id: str, *, redirect_posted: bool = True) -> TransactionDetail:
        data = self._transport.graphql(
            "GetTransactionDrawer",
            GET_TRANSACTION_DRAWER,
            {"id": transaction_id, "redirectPosted": redirect_posted},
        )
        return TransactionDetail.from_api(data["getTransaction"])

    def filters(self, *, search: str | None = None, include_ids: list[str] | None = None) -> TransactionFiltersResult:
        return TransactionFiltersResult.from_api(self._transport.graphql(
            "Web_TransactionsFilterQuery",
            GET_TRANSACTIONS_FILTER_QUERY,
            {"search": search, "includeIds": include_ids},
        ))

    def filters_metadata(self, filters: TransactionFilter) -> TransactionFiltersMetadata:
        data = self._transport.graphql(
            "Web_GetTransactionFiltersMetadata",
            GET_TRANSACTION_FILTERS_METADATA,
            {"input": filters.to_input()},
        )
        return TransactionFiltersMetadata.from_api(data["transactionFiltersMetadata"])

    def create(self, request: CreateTransactionRequest) -> CreateTransactionResult:
        return CreateTransactionResult.from_api(self._require_payload(
            "createTransaction",
            self._transport.graphql(
                "Common_CreateTransactionMutation",
                CREATE_TRANSACTION,
                {"input": request.to_input()},
            ),
        ))

    def update(self, request: UpdateTransactionRequest) -> UpdateTransactionResult:
        return UpdateTransactionResult.from_api(self._require_payload(
            "updateTransaction",
            self._transport.graphql(
                "Web_TransactionDrawerUpdateTransaction",
                UPDATE_TRANSACTION,
                {"input": request.to_input()},
            ),
        ))

    def delete(self, transaction_id: str) -> DeleteTransactionResult:
        return DeleteTransactionResult.from_api(self._require_payload(
            "deleteTransaction",
            self._transport.graphql(
                "Common_DeleteTransactionMutation",
                DELETE_TRANSACTION,
                {"input": {"transactionId": transaction_id}},
            ),
        ))

    def set_tags(self, transaction_id: str, tag_ids: list[str]) -> SetTransactionTagsResult:
        return SetTransactionTagsResult.from_api(self._require_payload(
            "setTransactionTags",
            self._transport.graphql(
                "Web_SetTransactionTags",
                SET_TRANSACTION_TAGS,
                {"input": {"transactionId": transaction_id, "tagIds": tag_ids}},
            ),
        ))

    def tags(
        self,
        *,
        search: str | None = None,
        limit: int | None = None,
        bulk_params: BulkTransactionDataParams | None = None,
        include_transaction_count: bool = False,
    ) -> list[TagRef]:
        data = self._transport.graphql(
            "Common_GetHouseholdTransactionTags",
            GET_HOUSEHOLD_TRANSACTION_TAGS,
            {
                "search": search,
                "limit": limit,
                "bulkParams": bulk_params.to_input() if bulk_params is not None else None,
                "includeTransactionCount": include_transaction_count,
            },
        )
        return [TagRef.from_api(item) for item in data["householdTransactionTags"]]

    def categories(self, *, include_system_disabled_categories: bool | None = None) -> TransactionCategoriesResult:
        return TransactionCategoriesResult.from_api(self._transport.graphql(
            "Common_GetCategories",
            GET_CATEGORIES,
            {"includeSystemDisabledCategories": include_system_disabled_categories},
        ))

    @staticmethod
    def _require_payload(field_name: str, data: Mapping[str, Any]) -> Mapping[str, Any]:
        payload = data.get(field_name)
        if not isinstance(payload, Mapping):
            raise MonarchGraphQLError(f"Expected payload object for {field_name}.", data)
        return payload
