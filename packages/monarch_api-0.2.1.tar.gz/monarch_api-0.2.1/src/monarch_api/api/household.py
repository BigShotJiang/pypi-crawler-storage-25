from __future__ import annotations

from ..documents import GET_HOUSEHOLD_MEMBERS, GET_HOUSEHOLD_PREFERENCES, GET_MY_HOUSEHOLD
from ..models.household import Household, HouseholdMembersResult, HouseholdPreferencesResult
from ..transport import MonarchTransport


class HouseholdAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def get(self) -> Household:
        data = self._transport.graphql(
            "Common_GetMyHousehold",
            GET_MY_HOUSEHOLD,
            {},
        )
        return Household.from_api(data["myHousehold"])

    def members(self) -> HouseholdMembersResult:
        return HouseholdMembersResult.from_api(
            self._transport.graphql(
            "Common_GetHouseholdMembers",
            GET_HOUSEHOLD_MEMBERS,
            {},
            )
        )

    def preferences(self) -> HouseholdPreferencesResult:
        return HouseholdPreferencesResult.from_api(
            self._transport.graphql(
            "Common_GetHouseholdPreferences",
            GET_HOUSEHOLD_PREFERENCES,
            {},
            )
        )
