from __future__ import annotations

from ..documents import (
    GET_ENTITLEMENTS,
    GET_FEATURE_ENTITLEMENT_PARAMS,
    GET_GIFTED_SUBSCRIPTIONS,
    GET_PLUS_TIER_ACCESS,
    GET_PREMIUM_UPGRADE_PLANS,
    GET_REFERRAL_SETTINGS,
    GET_SUBSCRIPTION,
    GET_SUBSCRIPTION_DETAILS,
    GET_SUBSCRIPTION_MODAL,
    GET_TRIAL_STATUS,
)
from ..models.base import required_mapping
from ..models.subscription import (
    FeatureEntitlementParams,
    GiftedSubscription,
    HouseholdSubscription,
    PremiumUpgradePlansRequest,
    ReferralSettings,
    ReferralSettingsRequest,
    SubscriptionModal,
    SubscriptionResult,
)
from ..transport import MonarchTransport


class SubscriptionAPI:
    def __init__(self, transport: MonarchTransport) -> None:
        self._transport = transport

    def details(self) -> HouseholdSubscription:
        data = self._transport.graphql(
            "Common_GetSubscriptionDetails",
            GET_SUBSCRIPTION_DETAILS,
            {},
        )
        return HouseholdSubscription.from_api(data["subscription"])

    def subscription(self) -> SubscriptionResult:
        return SubscriptionResult.from_api(self._transport.graphql(
            "Web_GetSubscription",
            GET_SUBSCRIPTION,
            {},
        ))

    def modal(self, *, promo_code: str | None = None, stripe_price_id: str = "") -> SubscriptionModal:
        return SubscriptionModal.from_api(self._transport.graphql(
            "Web_GetSubscriptionModal",
            GET_SUBSCRIPTION_MODAL,
            {
                "promoCode": promo_code,
                "stripePriceId": stripe_price_id,
            },
        ))

    def premium_upgrade_plans(
        self,
        request: PremiumUpgradePlansRequest,
    ) -> SubscriptionModal:
        return SubscriptionModal.from_api(self._transport.graphql(
            "Common_GetPremiumUpgradePlans",
            GET_PREMIUM_UPGRADE_PLANS,
            request.to_input(),
        ))

    def trial_status(self) -> HouseholdSubscription:
        data = self._transport.graphql(
            "GetTrialStatus",
            GET_TRIAL_STATUS,
            {},
        )
        return HouseholdSubscription.from_api(data["subscription"])

    def entitlements(self) -> HouseholdSubscription:
        data = self._transport.graphql(
            "Common_GetEntitlements",
            GET_ENTITLEMENTS,
            {},
        )
        return HouseholdSubscription.from_api(data["subscription"])

    def feature_entitlement_params(self) -> FeatureEntitlementParams:
        data = self._transport.graphql(
            "Common_GetFeatureEntitlementParams",
            GET_FEATURE_ENTITLEMENT_PARAMS,
            {},
        )
        return FeatureEntitlementParams.from_api(required_mapping(data["subscription"], "entitlementParams"))

    def plus_tier_access(self) -> HouseholdSubscription:
        data = self._transport.graphql(
            "Common_GetPlusTierAccess",
            GET_PLUS_TIER_ACCESS,
            {},
        )
        return HouseholdSubscription.from_api(data["subscription"])

    def gifted_subscriptions(self) -> list[GiftedSubscription]:
        data = self._transport.graphql(
            "Common_GetGiftedSubscriptions",
            GET_GIFTED_SUBSCRIPTIONS,
            {},
        )
        return [GiftedSubscription.from_api(item) for item in data["giftedSubscriptionsPurchasedByHousehold"]]

    def referral_settings(self, request: ReferralSettingsRequest) -> ReferralSettings:
        return ReferralSettings.from_api(self._transport.graphql(
            "Common_GetReferralSettings",
            GET_REFERRAL_SETTINGS,
            request.to_input(),
        ))
