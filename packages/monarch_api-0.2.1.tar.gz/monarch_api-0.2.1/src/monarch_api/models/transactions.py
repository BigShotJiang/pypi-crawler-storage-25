from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from .base import InputModel, OutputModel, list_of_mappings, map_list, optional_bool, optional_float, optional_int, optional_list, optional_mapping, optional_str, required_mapping, required_str
from .shared import (
    AccountRef,
    BusinessEntityRef,
    BusinessEntitySetInput,
    CategoryGroupRef,
    CategoryRef,
    MerchantRef,
    OwnershipSetInput,
    PayloadError,
    TagRef,
    UserRef,
)


@dataclass(slots=True)
class TransactionFilter(InputModel):
    abs_amount_gte: float | None = field(default=None, metadata={"api_name": "absAmountGte"})
    abs_amount_lte: float | None = field(default=None, metadata={"api_name": "absAmountLte"})
    accounts: list[str] | None = None
    budget_variability: str | None = field(default=None, metadata={"api_name": "budgetVariability"})
    business_entity_set: BusinessEntitySetInput | None = field(default=None, metadata={"api_name": "businessEntitySet"})
    categories: list[str] | None = None
    category_groups: list[str] | None = field(default=None, metadata={"api_name": "categoryGroups"})
    category_type: str | None = field(default=None, metadata={"api_name": "categoryType"})
    credits_only: bool | None = field(default=None, metadata={"api_name": "creditsOnly"})
    debits_only: bool | None = field(default=None, metadata={"api_name": "debitsOnly"})
    deleted_transaction_visibility: str | None = field(default=None, metadata={"api_name": "deletedTransactionVisibility"})
    end_date: str | None = field(default=None, metadata={"api_name": "endDate"})
    exclude_ids: list[str] | None = field(default=None, metadata={"api_name": "excludeIds"})
    goal_id: str | None = field(default=None, metadata={"api_name": "goalId"})
    goals: list[str] | None = None
    has_attachments: bool | None = field(default=None, metadata={"api_name": "hasAttachments"})
    has_goal_reconciliation_record: bool | None = field(default=None, metadata={"api_name": "hasGoalReconciliationRecord"})
    has_notes: bool | None = field(default=None, metadata={"api_name": "hasNotes"})
    hide_from_reports: bool | None = field(default=None, metadata={"api_name": "hideFromReports"})
    household_merchants: list[str] | None = field(default=None, metadata={"api_name": "householdMerchants"})
    ids: list[str] | None = None
    imported_from_mint: bool | None = field(default=None, metadata={"api_name": "importedFromMint"})
    is_flex_spending: bool | None = field(default=None, metadata={"api_name": "isFlexSpending"})
    is_investment_account: bool | None = field(default=None, metadata={"api_name": "isInvestmentAccount"})
    is_pending: bool | None = field(default=None, metadata={"api_name": "isPending"})
    is_recurring: bool | None = field(default=None, metadata={"api_name": "isRecurring"})
    is_split: bool | None = field(default=None, metadata={"api_name": "isSplit"})
    is_uncategorized: bool | None = field(default=None, metadata={"api_name": "isUncategorized"})
    is_untagged: bool | None = field(default=None, metadata={"api_name": "isUntagged"})
    merchants: list[str] | None = None
    needs_review: bool | None = field(default=None, metadata={"api_name": "needsReview"})
    needs_review_by_user: str | None = field(default=None, metadata={"api_name": "needsReviewByUser"})
    needs_review_unassigned: bool | None = field(default=None, metadata={"api_name": "needsReviewUnassigned"})
    ownership_set: OwnershipSetInput | None = field(default=None, metadata={"api_name": "ownershipSet"})
    savings_goals: list[str] | None = field(default=None, metadata={"api_name": "savingsGoals"})
    search: str | None = None
    start_date: str | None = field(default=None, metadata={"api_name": "startDate"})
    synced_from_institution: bool | None = field(default=None, metadata={"api_name": "syncedFromInstitution"})
    tags: list[str] | None = None
    timeframe_period: "TimeframePeriodInput" | None = field(default=None, metadata={"api_name": "timeframePeriod"})
    transaction_visibility: str | None = field(default=None, metadata={"api_name": "transactionVisibility"})
    uploaded_statement: str | None = field(default=None, metadata={"api_name": "uploadedStatement"})


@dataclass(slots=True)
class TimeframePeriodInput(InputModel):
    include_current: bool = field(metadata={"api_name": "includeCurrent"})
    unit: str
    value: int


@dataclass(slots=True)
class BulkTransactionDataParams(InputModel):
    excluded_transaction_ids: list[str] | None = field(default=None, metadata={"api_name": "excludedTransactionIds"})
    expected_affected_transaction_count: int | None = field(default=None, metadata={"api_name": "expectedAffectedTransactionCount"})
    filters: TransactionFilter | None = None
    is_all_selected: bool | None = field(default=None, metadata={"api_name": "isAllSelected"})
    selected_transaction_ids: list[str] | None = field(default=None, metadata={"api_name": "selectedTransactionIds"})


@dataclass(slots=True)
class CreateTransactionRequest(InputModel):
    account_id: str = field(metadata={"api_name": "accountId"})
    amount: float
    category_id: str = field(metadata={"api_name": "categoryId"})
    date: str
    merchant_name: str = field(metadata={"api_name": "merchantName"})
    business_entity_id: str | None = field(default=None, metadata={"api_name": "businessEntityId"})
    goal_id: str | None = field(default=None, metadata={"api_name": "goalId"})
    notes: str | None = None
    owner_user_id: str | None = field(default=None, metadata={"api_name": "ownerUserId"})
    retail_transaction_id: str | None = field(default=None, metadata={"api_name": "retailTransactionId"})
    retail_user_attachment_id: str | None = field(default=None, metadata={"api_name": "retailUserAttachmentId"})
    should_update_balance: bool | None = field(default=None, metadata={"api_name": "shouldUpdateBalance"})


@dataclass(slots=True)
class UpdateTransactionRequest(InputModel):
    id: str
    amount: float | None = None
    business_entity_id: str | None = field(default=None, metadata={"api_name": "businessEntityId"})
    category: str | None = None
    date: str | None = None
    goal_id: str | None = field(default=None, metadata={"api_name": "goalId"})
    hide_from_reports: bool | None = field(default=None, metadata={"api_name": "hideFromReports"})
    is_recommended_category: bool | None = field(default=None, metadata={"api_name": "isRecommendedCategory"})
    is_recommended_name: bool | None = field(default=None, metadata={"api_name": "isRecommendedName"})
    is_recurring: bool | None = field(default=None, metadata={"api_name": "isRecurring"})
    name: str | None = None
    needs_review: bool | None = field(default=None, metadata={"api_name": "needsReview"})
    needs_review_by_user: str | None = field(default=None, metadata={"api_name": "needsReviewByUser"})
    notes: str | None = None
    owner_user_id: str | None = field(default=None, metadata={"api_name": "ownerUserId"})
    review_status: str | None = field(default=None, metadata={"api_name": "reviewStatus"})
    reviewed: bool | None = None
    should_create_enrichment_evidence: bool | None = field(default=None, metadata={"api_name": "shouldCreateEnrichmentEvidence"})


@dataclass(slots=True)
class TransactionMutationTag(OutputModel):
    id: str

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "TransactionMutationTag":
        return cls(id=required_str(payload, "id"))


@dataclass(slots=True)
class TransactionMutationTransaction(OutputModel):
    id: str
    tags: list[TransactionMutationTag] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "TransactionMutationTransaction":
        return cls(
            id=required_str(payload, "id"),
            tags=map_list(list_of_mappings(payload, "tags"), TransactionMutationTag.from_api),
        )


@dataclass(slots=True)
class CreateTransactionResult(OutputModel):
    transaction: TransactionMutationTransaction | None = None
    errors: list[PayloadError] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "CreateTransactionResult":
        return cls(
            transaction=TransactionMutationTransaction.from_api(t) if (t := optional_mapping(payload, "transaction")) else None,
            errors=map_list(list_of_mappings(payload, "errors"), PayloadError.from_api),
        )


@dataclass(slots=True)
class UpdateTransactionResult(OutputModel):
    transaction: "TransactionDetail" | None = None
    errors: list[PayloadError] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "UpdateTransactionResult":
        return cls(
            transaction=TransactionDetail.from_api(t) if (t := optional_mapping(payload, "transaction")) else None,
            errors=map_list(list_of_mappings(payload, "errors"), PayloadError.from_api),
        )


@dataclass(slots=True)
class DeleteTransactionResult(OutputModel):
    deleted: bool = False
    errors: list[PayloadError] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "DeleteTransactionResult":
        return cls(
            deleted=bool(payload.get("deleted")),
            errors=map_list(list_of_mappings(payload, "errors"), PayloadError.from_api),
        )


@dataclass(slots=True)
class SetTransactionTagsResult(OutputModel):
    transaction: TransactionMutationTransaction | None = None
    errors: list[PayloadError] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "SetTransactionTagsResult":
        return cls(
            transaction=TransactionMutationTransaction.from_api(t) if (t := optional_mapping(payload, "transaction")) else None,
            errors=map_list(list_of_mappings(payload, "errors"), PayloadError.from_api),
        )


@dataclass(slots=True)
class TransactionAttachmentRef(OutputModel):
    id: str
    extension: str | None = None
    size_bytes: int | None = None
    filename: str | None = None
    original_asset_url: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "TransactionAttachmentRef":
        return cls(
            id=required_str(payload, "id"),
            extension=optional_str(payload, "extension"),
            size_bytes=optional_int(payload, "sizeBytes"),
            filename=optional_str(payload, "filename"),
            original_asset_url=optional_str(payload, "originalAssetUrl"),
        )


@dataclass(slots=True)
class GoalRef(OutputModel):
    id: str
    name: str | None = None
    image_storage_provider: str | None = None
    image_storage_provider_id: str | None = None
    archived_at: str | None = None
    priority: int | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "GoalRef":
        return cls(
            id=required_str(payload, "id"),
            name=optional_str(payload, "name"),
            image_storage_provider=optional_str(payload, "imageStorageProvider"),
            image_storage_provider_id=optional_str(payload, "imageStorageProviderId"),
            archived_at=optional_str(payload, "archivedAt"),
            priority=optional_int(payload, "priority"),
        )


@dataclass(slots=True)
class SavingsGoalEventRef(OutputModel):
    id: str
    goal: GoalRef | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "SavingsGoalEventRef":
        return cls(
            id=required_str(payload, "id"),
            goal=GoalRef.from_api(g) if (g := optional_mapping(payload, "goal")) else None,
        )


@dataclass(slots=True)
class TransactionCategory(OutputModel):
    id: str
    name: str | None = None
    icon: str | None = None
    system_category: str | None = None
    group_id: str | None = None
    group_type: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "TransactionCategory":
        group = optional_mapping(payload, "group") or {}
        return cls(
            id=required_str(payload, "id"),
            name=optional_str(payload, "name"),
            icon=optional_str(payload, "icon"),
            system_category=optional_str(payload, "systemCategory"),
            group_id=optional_str(group, "id"),
            group_type=optional_str(group, "type"),
        )


@dataclass(slots=True)
class CategoryRolloverPeriod(OutputModel):
    id: str
    start_month: int | None = None
    starting_balance: float | None = None
    frequency: str | None = None
    target_amount: float | None = None
    type: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "CategoryRolloverPeriod":
        return cls(
            id=required_str(payload, "id"),
            start_month=optional_int(payload, "startMonth"),
            starting_balance=optional_float(payload, "startingBalance"),
            frequency=optional_str(payload, "frequency"),
            target_amount=optional_float(payload, "targetAmount"),
            type=optional_str(payload, "type"),
        )


@dataclass(slots=True)
class Category(OutputModel):
    id: str
    name: str | None = None
    order: int | None = None
    icon: str | None = None
    is_system_category: bool | None = None
    exclude_from_budget: bool | None = None
    budget_variability: str | None = None
    is_disabled: bool | None = None
    group: CategoryGroupRef | None = None
    rollover_period: CategoryRolloverPeriod | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "Category":
        return cls(
            id=required_str(payload, "id"),
            name=optional_str(payload, "name"),
            order=optional_int(payload, "order"),
            icon=optional_str(payload, "icon"),
            is_system_category=optional_bool(payload, "isSystemCategory"),
            exclude_from_budget=optional_bool(payload, "excludeFromBudget"),
            budget_variability=optional_str(payload, "budgetVariability"),
            is_disabled=optional_bool(payload, "isDisabled"),
            group=CategoryGroupRef.from_api(g) if (g := optional_mapping(payload, "group")) else None,
            rollover_period=CategoryRolloverPeriod.from_api(r)
            if (r := optional_mapping(payload, "rolloverPeriod"))
            else None,
        )


@dataclass(slots=True)
class CategoryGroup(OutputModel):
    id: str
    name: str
    order: int | None = None
    type: str | None = None
    group_level_budgeting_enabled: bool | None = None
    budget_variability: str | None = None
    rollover_period: CategoryRolloverPeriod | None = None
    categories: list[CategoryRef] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "CategoryGroup":
        return cls(
            id=required_str(payload, "id"),
            name=required_str(payload, "name"),
            order=optional_int(payload, "order"),
            type=optional_str(payload, "type"),
            group_level_budgeting_enabled=optional_bool(payload, "groupLevelBudgetingEnabled"),
            budget_variability=optional_str(payload, "budgetVariability"),
            rollover_period=CategoryRolloverPeriod.from_api(r)
            if (r := optional_mapping(payload, "rolloverPeriod"))
            else None,
            categories=map_list(list_of_mappings(payload, "categories"), CategoryRef.from_api),
        )


@dataclass(slots=True)
class TransactionOverview(OutputModel):
    id: str
    amount: float | None = None
    pending: bool | None = None
    date: str | None = None
    hide_from_reports: bool | None = None
    hidden_by_account: bool | None = None
    plaid_name: str | None = None
    notes: str | None = None
    is_recurring: bool | None = None
    review_status: str | None = None
    needs_review: bool | None = None
    is_split_transaction: bool | None = None
    data_provider_description: str | None = None
    deleted_at: str | None = None
    deleted_by_type: str | None = None
    attachments: list[TransactionAttachmentRef] = field(default_factory=list)
    goal: GoalRef | None = None
    savings_goal_event: SavingsGoalEventRef | None = None
    category: TransactionCategory | None = None
    merchant: MerchantRef | None = None
    tags: list[TagRef] = field(default_factory=list)
    account: AccountRef | None = None
    owned_by_user: UserRef | None = None
    business_entity: BusinessEntityRef | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "TransactionOverview":
        return cls(
            id=required_str(payload, "id"),
            amount=optional_float(payload, "amount"),
            pending=optional_bool(payload, "pending"),
            date=optional_str(payload, "date"),
            hide_from_reports=optional_bool(payload, "hideFromReports"),
            hidden_by_account=optional_bool(payload, "hiddenByAccount"),
            plaid_name=optional_str(payload, "plaidName"),
            notes=optional_str(payload, "notes"),
            is_recurring=optional_bool(payload, "isRecurring"),
            review_status=optional_str(payload, "reviewStatus"),
            needs_review=optional_bool(payload, "needsReview"),
            is_split_transaction=optional_bool(payload, "isSplitTransaction"),
            data_provider_description=optional_str(payload, "dataProviderDescription"),
            deleted_at=optional_str(payload, "deletedAt"),
            deleted_by_type=optional_str(payload, "deletedByType"),
            attachments=map_list(list_of_mappings(payload, "attachments"), TransactionAttachmentRef.from_api),
            goal=GoalRef.from_api(g) if (g := optional_mapping(payload, "goal")) else None,
            savings_goal_event=SavingsGoalEventRef.from_api(s)
            if (s := optional_mapping(payload, "savingsGoalEvent"))
            else None,
            category=TransactionCategory.from_api(c) if (c := optional_mapping(payload, "category")) else None,
            merchant=MerchantRef.from_api(m) if (m := optional_mapping(payload, "merchant")) else None,
            tags=map_list(list_of_mappings(payload, "tags"), TagRef.from_api),
            account=AccountRef.from_api(a) if (a := optional_mapping(payload, "account")) else None,
            owned_by_user=UserRef.from_api(u) if (u := optional_mapping(payload, "ownedByUser")) else None,
            business_entity=BusinessEntityRef.from_api(b) if (b := optional_mapping(payload, "businessEntity")) else None,
        )


@dataclass(slots=True)
class TransactionSplitSummary(OutputModel):
    id: str
    amount: float | None = None
    merchant: MerchantRef | None = None
    category: TransactionCategory | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "TransactionSplitSummary":
        return cls(
            id=required_str(payload, "id"),
            amount=optional_float(payload, "amount"),
            merchant=MerchantRef.from_api(m) if (m := optional_mapping(payload, "merchant")) else None,
            category=TransactionCategory.from_api(c) if (c := optional_mapping(payload, "category")) else None,
        )


@dataclass(slots=True)
class OriginalTransactionRef(OutputModel):
    id: str
    date: str | None = None
    amount: float | None = None
    merchant: MerchantRef | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "OriginalTransactionRef":
        return cls(
            id=required_str(payload, "id"),
            date=optional_str(payload, "date"),
            amount=optional_float(payload, "amount"),
            merchant=MerchantRef.from_api(m) if (m := optional_mapping(payload, "merchant")) else None,
        )


@dataclass(slots=True)
class TransactionDetail(TransactionOverview):
    original_date: str | None = None
    reviewed_at: str | None = None
    reviewed_by_user: UserRef | None = None
    has_split_transactions: bool | None = None
    is_manual: bool | None = None
    updated_by_retail_sync: bool | None = None
    linked_retail_transaction_id: str | None = None
    split_transactions: list[TransactionSplitSummary] = field(default_factory=list)
    original_transaction: OriginalTransactionRef | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "TransactionDetail":
        base = TransactionOverview.from_api(payload)
        return cls(
            id=base.id,
            amount=base.amount,
            pending=base.pending,
            date=base.date,
            hide_from_reports=base.hide_from_reports,
            hidden_by_account=base.hidden_by_account,
            plaid_name=base.plaid_name,
            notes=base.notes,
            is_recurring=base.is_recurring,
            review_status=base.review_status,
            needs_review=base.needs_review,
            is_split_transaction=base.is_split_transaction,
            data_provider_description=base.data_provider_description,
            deleted_at=base.deleted_at,
            deleted_by_type=base.deleted_by_type,
            attachments=map_list(list_of_mappings(payload, "attachments"), TransactionAttachmentRef.from_api),
            goal=base.goal,
            savings_goal_event=base.savings_goal_event,
            category=base.category,
            merchant=base.merchant,
            tags=base.tags,
            account=base.account,
            owned_by_user=base.owned_by_user,
            business_entity=base.business_entity,
            original_date=optional_str(payload, "originalDate"),
            reviewed_at=optional_str(payload, "reviewedAt"),
            reviewed_by_user=UserRef.from_api(u) if (u := optional_mapping(payload, "reviewedByUser")) else None,
            has_split_transactions=optional_bool(payload, "hasSplitTransactions"),
            is_manual=optional_bool(payload, "isManual"),
            updated_by_retail_sync=optional_bool(payload, "updatedByRetailSync"),
            linked_retail_transaction_id=optional_str(payload, "linkedRetailTransactionId"),
            split_transactions=map_list(list_of_mappings(payload, "splitTransactions"), TransactionSplitSummary.from_api),
            original_transaction=OriginalTransactionRef.from_api(o)
            if (o := optional_mapping(payload, "originalTransaction"))
            else None,
        )


@dataclass(slots=True)
class TransactionRuleRef(OutputModel):
    id: str

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "TransactionRuleRef":
        return cls(id=required_str(payload, "id"))


@dataclass(slots=True)
class TransactionsPageSummary(OutputModel):
    total_count: int | None = None
    total_selectable_count: int | None = None
    results: list[TransactionOverview] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "TransactionsPageSummary":
        return cls(
            total_count=optional_int(payload, "totalCount"),
            total_selectable_count=optional_int(payload, "totalSelectableCount"),
            results=map_list(list_of_mappings(payload, "results"), TransactionOverview.from_api),
        )


@dataclass(slots=True)
class TransactionListResult(OutputModel):
    all_transactions: TransactionsPageSummary
    transaction_rules: list[TransactionRuleRef] = field(default_factory=list)

    @property
    def results(self) -> list[TransactionOverview]:
        return self.all_transactions.results

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "TransactionListResult":
        return cls(
            all_transactions=TransactionsPageSummary.from_api(required_mapping(payload, "allTransactions")),
            transaction_rules=map_list(list_of_mappings(payload, "transactionRules"), TransactionRuleRef.from_api),
        )


@dataclass(slots=True)
class TransactionFiltersResult(OutputModel):
    category_groups: list[CategoryGroup] = field(default_factory=list)
    goals: list[GoalRef] = field(default_factory=list)
    savings_goals: list[GoalRef] = field(default_factory=list)
    merchants: list[MerchantRef] = field(default_factory=list)
    accounts: list[AccountRef] = field(default_factory=list)
    household_transaction_tags: list[TagRef] = field(default_factory=list)
    my_household_users: list[UserRef] = field(default_factory=list)
    account_group_order: list[str] | None = None
    collaboration_tools_enabled: bool | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "TransactionFiltersResult":
        my_household = optional_mapping(payload, "myHousehold") or {}
        prefs = optional_mapping(payload, "householdPreferences") or {}
        raw_order = payload.get("householdPreferences", {}).get("accountGroupOrder") if isinstance(payload.get("householdPreferences"), Mapping) else None
        account_group_order = [item for item in raw_order if isinstance(item, str)] if isinstance(raw_order, list) else None
        return cls(
            category_groups=map_list(list_of_mappings(payload, "categoryGroups"), CategoryGroup.from_api),
            goals=map_list(list_of_mappings(payload, "goalsV2"), GoalRef.from_api),
            savings_goals=map_list(list_of_mappings(payload, "savingsGoals"), GoalRef.from_api),
            merchants=map_list(list_of_mappings(payload, "merchants"), MerchantRef.from_api),
            accounts=map_list(list_of_mappings(payload, "accounts"), AccountRef.from_api),
            household_transaction_tags=map_list(list_of_mappings(payload, "householdTransactionTags"), TagRef.from_api),
            my_household_users=map_list(list_of_mappings(my_household, "users"), UserRef.from_api),
            account_group_order=account_group_order,
            collaboration_tools_enabled=optional_bool(prefs, "collaborationToolsEnabled"),
        )


@dataclass(slots=True)
class OwnershipSet(OutputModel):
    include_jointly_owned: bool | None = None
    users: list[UserRef] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "OwnershipSet":
        return cls(
            include_jointly_owned=optional_bool(payload, "includeJointlyOwned"),
            users=map_list(list_of_mappings(payload, "users"), UserRef.from_api),
        )


@dataclass(slots=True)
class BusinessEntitySet(OutputModel):
    include_unassigned: bool | None = None
    business_entities: list[BusinessEntityRef] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "BusinessEntitySet":
        return cls(
            include_unassigned=optional_bool(payload, "includeUnassigned"),
            business_entities=map_list(list_of_mappings(payload, "businessEntities"), BusinessEntityRef.from_api),
        )


@dataclass(slots=True)
class TransactionFiltersMetadata(OutputModel):
    categories: list[CategoryRef] = field(default_factory=list)
    category_groups: list[CategoryGroupRef] = field(default_factory=list)
    accounts: list[AccountRef] = field(default_factory=list)
    merchants: list[MerchantRef] = field(default_factory=list)
    tags: list[TagRef] = field(default_factory=list)
    goals: list[GoalRef] = field(default_factory=list)
    savings_goals: list[GoalRef] = field(default_factory=list)
    needs_review_by_user: list[UserRef] = field(default_factory=list)
    ownership_set: OwnershipSet | None = None
    business_entity_set: BusinessEntitySet | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "TransactionFiltersMetadata":
        return cls(
            categories=map_list(list_of_mappings(payload, "categories"), CategoryRef.from_api),
            category_groups=map_list(list_of_mappings(payload, "categoryGroups"), CategoryGroupRef.from_api),
            accounts=map_list(list_of_mappings(payload, "accounts"), AccountRef.from_api),
            merchants=map_list(list_of_mappings(payload, "merchants"), MerchantRef.from_api),
            tags=map_list(list_of_mappings(payload, "tags"), TagRef.from_api),
            goals=map_list(list_of_mappings(payload, "goals"), GoalRef.from_api),
            savings_goals=map_list(list_of_mappings(payload, "savingsGoals"), GoalRef.from_api),
            needs_review_by_user=map_list(list_of_mappings(payload, "needsReviewByUser"), UserRef.from_api),
            ownership_set=OwnershipSet.from_api(o) if (o := optional_mapping(payload, "ownershipSet")) else None,
            business_entity_set=BusinessEntitySet.from_api(b)
            if (b := optional_mapping(payload, "businessEntitySet"))
            else None,
        )


@dataclass(slots=True)
class TransactionCategoriesResult(OutputModel):
    category_groups: list[CategoryGroup] = field(default_factory=list)
    categories: list[Category] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "TransactionCategoriesResult":
        return cls(
            category_groups=map_list(list_of_mappings(payload, "categoryGroups"), CategoryGroup.from_api),
            categories=map_list(list_of_mappings(payload, "categories"), Category.from_api),
        )
