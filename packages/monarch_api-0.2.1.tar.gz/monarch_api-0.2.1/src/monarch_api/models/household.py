from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from .base import OutputModel, list_of_mappings, map_list, optional_bool, optional_list, optional_str, required_mapping, required_str
from .shared import UserRef


@dataclass(slots=True)
class Household(OutputModel):
    id: str
    name: str | None = None
    address: str | None = None
    city: str | None = None
    state: str | None = None
    zip_code: str | None = None
    country: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "Household":
        return cls(
            id=required_str(payload, "id"),
            name=optional_str(payload, "name"),
            address=optional_str(payload, "address"),
            city=optional_str(payload, "city"),
            state=optional_str(payload, "state"),
            zip_code=optional_str(payload, "zipCode", "zip_code"),
            country=optional_str(payload, "country"),
        )


@dataclass(slots=True)
class HouseholdMember(UserRef):
    household_role: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "HouseholdMember":
        base = UserRef.from_api(payload)
        return cls(
            id=base.id,
            display_name=base.display_name,
            name=base.name,
            profile_picture_url=base.profile_picture_url,
            email=base.email,
            household_role=optional_str(payload, "householdRole", "household_role"),
        )


@dataclass(slots=True)
class HouseholdMembersHousehold(OutputModel):
    id: str
    users: list[HouseholdMember]

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "HouseholdMembersHousehold":
        return cls(
            id=required_str(payload, "id"),
            users=map_list(list_of_mappings(payload, "users"), HouseholdMember.from_api),
        )


@dataclass(slots=True)
class HouseholdMembersResult(OutputModel):
    me: UserRef
    my_household: HouseholdMembersHousehold

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "HouseholdMembersResult":
        return cls(
            me=UserRef.from_api(required_mapping(payload, "me")),
            my_household=HouseholdMembersHousehold.from_api(required_mapping(payload, "myHousehold")),
        )


@dataclass(slots=True)
class HouseholdPreferences(OutputModel):
    id: str | None = None
    new_transactions_need_review: bool | None = None
    uncategorized_transactions_need_review: bool | None = None
    pending_transactions_can_be_edited: bool | None = None
    account_group_order: list[str] | str | None = None
    ai_assistant_enabled: bool | None = None
    llm_enrichment_enabled: bool | None = None
    investment_transactions_enabled: bool | None = None
    budget_apply_to_future_months_default: bool | None = None
    hidden_transactions_beta_enabled: bool | None = None
    collaboration_tools_enabled: bool | None = None
    agg_data_sharing_enabled: bool | None = None
    ai_model_training_on_user_data_enabled: bool | None = None
    exclude_business_from_budget: bool | None = None
    continuous_financial_monitoring_enabled: bool | None = None
    eligible_for_financial_insights: bool | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "HouseholdPreferences":
        account_group_order: list[str] | str | None
        raw_order = payload.get("accountGroupOrder")
        if isinstance(raw_order, list):
            account_group_order = [item for item in raw_order if isinstance(item, str)]
        elif isinstance(raw_order, str):
            account_group_order = raw_order
        else:
            account_group_order = None
        return cls(
            id=optional_str(payload, "id"),
            new_transactions_need_review=optional_bool(payload, "newTransactionsNeedReview"),
            uncategorized_transactions_need_review=optional_bool(payload, "uncategorizedTransactionsNeedReview"),
            pending_transactions_can_be_edited=optional_bool(payload, "pendingTransactionsCanBeEdited"),
            account_group_order=account_group_order,
            ai_assistant_enabled=optional_bool(payload, "aiAssistantEnabled"),
            llm_enrichment_enabled=optional_bool(payload, "llmEnrichmentEnabled"),
            investment_transactions_enabled=optional_bool(payload, "investmentTransactionsEnabled"),
            budget_apply_to_future_months_default=optional_bool(payload, "budgetApplyToFutureMonthsDefault"),
            hidden_transactions_beta_enabled=optional_bool(payload, "hiddenTransactionsBetaEnabled"),
            collaboration_tools_enabled=optional_bool(payload, "collaborationToolsEnabled"),
            agg_data_sharing_enabled=optional_bool(payload, "aggDataSharingEnabled"),
            ai_model_training_on_user_data_enabled=optional_bool(payload, "aiModelTrainingOnUserDataEnabled"),
            exclude_business_from_budget=optional_bool(payload, "excludeBusinessFromBudget"),
            continuous_financial_monitoring_enabled=optional_bool(payload, "continuousFinancialMonitoringEnabled"),
            eligible_for_financial_insights=optional_bool(payload, "eligibleForFinancialInsights"),
        )


@dataclass(slots=True)
class HouseholdPreferencesResult(OutputModel):
    household_preferences: HouseholdPreferences
    budget_system: str | None = None
    budget_apply_to_future_months_default: bool | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "HouseholdPreferencesResult":
        return cls(
            household_preferences=HouseholdPreferences.from_api(required_mapping(payload, "householdPreferences")),
            budget_system=optional_str(payload, "budgetSystem"),
            budget_apply_to_future_months_default=optional_bool(payload, "budgetApplyToFutureMonthsDefault"),
        )
