from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from .base import OutputModel, list_of_mappings, map_list, optional_bool, optional_float, optional_int, optional_mapping, optional_str, required_mapping, required_str
from .shared import AccountRef, AccountSubtypeRef, InstitutionRef


@dataclass(slots=True)
class GoalAccountAllocation(OutputModel):
    goal_id: str | None = None
    adjustment_amount: float | None = None
    total_amount: float | None = None
    spending_amount: float | None = None
    contributions_amount: float | None = None
    withdrawals_amount: float | None = None
    account: AccountRef | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "GoalAccountAllocation":
        return cls(
            goal_id=optional_str(payload, "goalId"),
            adjustment_amount=optional_float(payload, "adjustmentAmount"),
            total_amount=optional_float(payload, "totalAmount"),
            spending_amount=optional_float(payload, "spendingAmount"),
            contributions_amount=optional_float(payload, "contributionsAmount"),
            withdrawals_amount=optional_float(payload, "withdrawalsAmount"),
            account=AccountRef.from_api(a) if (a := optional_mapping(payload, "account")) else None,
        )


@dataclass(slots=True)
class SavingsGoal(OutputModel):
    id: str
    type: str | None = None
    name: str | None = None
    created_at: str | None = None
    archived_at: str | None = None
    image_storage_provider: str | None = None
    image_storage_provider_id: str | None = None
    status: str | None = None
    progress: float | None = None
    current_balance: float | None = None
    target_date: str | None = None
    target_amount: float | None = None
    planned_monthly_contribution: float | None = None
    balance_this_month: float | None = None
    priority: int | None = None
    is_sinking_fund: bool | None = None
    allocations: list[GoalAccountAllocation] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "SavingsGoal":
        return cls(
            id=required_str(payload, "id"),
            type=optional_str(payload, "type"),
            name=optional_str(payload, "name"),
            created_at=optional_str(payload, "createdAt"),
            archived_at=optional_str(payload, "archivedAt"),
            image_storage_provider=optional_str(payload, "imageStorageProvider"),
            image_storage_provider_id=optional_str(payload, "imageStorageProviderId"),
            status=optional_str(payload, "status"),
            progress=optional_float(payload, "progress"),
            current_balance=optional_float(payload, "currentBalance"),
            target_date=optional_str(payload, "targetDate"),
            target_amount=optional_float(payload, "targetAmount"),
            planned_monthly_contribution=optional_float(payload, "plannedMonthlyContribution"),
            balance_this_month=optional_float(payload, "balanceThisMonth"),
            priority=optional_int(payload, "priority"),
            is_sinking_fund=optional_bool(payload, "isSinkingFund"),
            allocations=map_list(list_of_mappings(payload, "allocationAmountsByAccount"), GoalAccountAllocation.from_api),
        )


@dataclass(slots=True)
class SavingsGoalsWithBalancesResult(OutputModel):
    savings_goals: list[SavingsGoal] = field(default_factory=list)
    goals_balance_this_month: float | None = None
    current_total_balance_for_goals: float | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "SavingsGoalsWithBalancesResult":
        return cls(
            savings_goals=map_list(list_of_mappings(payload, "savingsGoals"), SavingsGoal.from_api),
            goals_balance_this_month=optional_float(payload, "goalsBalanceThisMonth"),
            current_total_balance_for_goals=optional_float(payload, "currentTotalBalanceForGoals"),
        )


@dataclass(slots=True)
class SavingsGoalAccount(OutputModel):
    id: str
    display_name: str | None = None
    display_balance: float | str | None = None
    icon: str | None = None
    available_balance_for_goals_unmemoized: float | None = None
    include_in_goal_contributions: bool | None = None
    goal_allocated_amount: float | None = None
    linked_goal_id: str | None = None
    subtype: AccountSubtypeRef | None = None
    institution: InstitutionRef | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "SavingsGoalAccount":
        institution_payload = optional_mapping(payload, "institution")
        return cls(
            id=required_str(payload, "id"),
            display_name=optional_str(payload, "displayName"),
            display_balance=payload.get("displayBalance"),
            icon=optional_str(payload, "icon"),
            available_balance_for_goals_unmemoized=optional_float(payload, "availableBalanceForGoalsUnmemoized"),
            include_in_goal_contributions=optional_bool(payload, "includeInGoalContributions"),
            goal_allocated_amount=optional_float(payload, "goalAllocatedAmount"),
            linked_goal_id=optional_str(optional_mapping(payload, "linkedGoal") or {}, "id"),
            subtype=AccountSubtypeRef.from_api(s) if (s := optional_mapping(payload, "subtype")) else None,
            institution=InstitutionRef.from_api(institution_payload) if institution_payload else None,
        )


@dataclass(slots=True)
class GoalDashboardRow(OutputModel):
    id: str
    name: str | None = None
    image_storage_provider: str | None = None
    image_storage_provider_id: str | None = None
    current_amount: float | None = None
    completion_percent: float | None = None
    completed_at: str | None = None
    archived_at: str | None = None
    type: str | None = None
    priority: int | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "GoalDashboardRow":
        return cls(
            id=required_str(payload, "id"),
            name=optional_str(payload, "name"),
            image_storage_provider=optional_str(payload, "imageStorageProvider"),
            image_storage_provider_id=optional_str(payload, "imageStorageProviderId"),
            current_amount=optional_float(payload, "currentAmount"),
            completion_percent=optional_float(payload, "completionPercent"),
            completed_at=optional_str(payload, "completedAt"),
            archived_at=optional_str(payload, "archivedAt"),
            type=optional_str(payload, "type"),
            priority=optional_int(payload, "priority"),
        )


@dataclass(slots=True)
class LegacyGoalMigrationEntry(OutputModel):
    id: str
    new_goal_id: str | None = None
    type: str | None = None
    archived_at: str | None = None
    completed_at: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "LegacyGoalMigrationEntry":
        return cls(
            id=required_str(payload, "id"),
            new_goal_id=optional_str(payload, "newGoalId"),
            type=optional_str(payload, "type"),
            archived_at=optional_str(payload, "archivedAt"),
            completed_at=optional_str(payload, "completedAt"),
        )


@dataclass(slots=True)
class DebtAccount(OutputModel):
    id: str
    display_name: str
    display_balance: float | str | None = None
    icon: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "DebtAccount":
        return cls(
            id=required_str(payload, "id"),
            display_name=required_str(payload, "displayName"),
            display_balance=payload.get("displayBalance"),
            icon=optional_str(payload, "icon"),
        )


@dataclass(slots=True)
class LegacyGoalsMigrationStatus(OutputModel):
    migrated_to_savings_goals: bool
    legacy_goals_migration_data: list[LegacyGoalMigrationEntry] = field(default_factory=list)
    debt_accounts: list[DebtAccount] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "LegacyGoalsMigrationStatus":
        return cls(
            migrated_to_savings_goals=bool(payload.get("migratedToSavingsGoals")),
            legacy_goals_migration_data=map_list(
                list_of_mappings(payload, "legacyGoalsMigrationData"),
                LegacyGoalMigrationEntry.from_api,
            ),
            debt_accounts=map_list(list_of_mappings(payload, "debtAccounts"), DebtAccount.from_api),
        )
