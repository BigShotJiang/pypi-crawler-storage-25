from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from .base import OutputModel, list_of_mappings, map_list, optional_bool, optional_float, optional_int, optional_list, optional_mapping, optional_str, required_mapping, required_str
from .household import HouseholdMember, HouseholdMembersHousehold
from .shared import AccountRef, BusinessEntityRef, UserRef
from .subscription import HouseholdSubscription, SubscriptionOffering


@dataclass(slots=True)
class UserProfileFlags(OutputModel):
    id: str
    has_reviewed_spending: bool | None = None
    has_seen_categories_management_tour: bool | None = None
    has_seen_weekly_review_tour: bool | None = None
    has_hidden_referral_program_prompts: bool | None = None
    display_ownership_on_transactions_list: bool | None = None
    dismissed_ownership_walkthrough_at: str | None = None
    finished_ownership_setup_at: str | None = None
    dismissed_plus_tier_walkthrough_at: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "UserProfileFlags":
        return cls(
            id=required_str(payload, "id"),
            has_reviewed_spending=optional_bool(payload, "hasReviewedSpending"),
            has_seen_categories_management_tour=optional_bool(payload, "hasSeenCategoriesManagementTour"),
            has_seen_weekly_review_tour=optional_bool(payload, "hasSeenWeeklyReviewTour"),
            has_hidden_referral_program_prompts=optional_bool(payload, "hasHiddenReferralProgramPrompts"),
            display_ownership_on_transactions_list=optional_bool(payload, "displayOwnershipOnTransactionsList"),
            dismissed_ownership_walkthrough_at=optional_str(payload, "dismissedOwnershipWalkthroughAt"),
            finished_ownership_setup_at=optional_str(payload, "finishedOwnershipSetupAt"),
            dismissed_plus_tier_walkthrough_at=optional_str(payload, "dismissedPlusTierWalkthroughAt"),
        )


@dataclass(slots=True)
class PlatformDashboardConfig(OutputModel):
    layout: list[str] = field(default_factory=list)
    widgets: list[str] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "PlatformDashboardConfig":
        layout = optional_list(payload, "layout") or []
        widgets = optional_list(payload, "widgets") or []
        return cls(
            layout=[item for item in layout if isinstance(item, str)],
            widgets=[item for item in widgets if isinstance(item, str)],
        )


@dataclass(slots=True)
class DashboardConfig(OutputModel):
    web: PlatformDashboardConfig | None = None
    mobile: PlatformDashboardConfig | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "DashboardConfig":
        return cls(
            web=PlatformDashboardConfig.from_api(p) if (p := optional_mapping(payload, "web")) else None,
            mobile=PlatformDashboardConfig.from_api(p) if (p := optional_mapping(payload, "mobile")) else None,
        )


@dataclass(slots=True)
class HouseholdDashboard(OutputModel):
    id: str
    dashboard_config: DashboardConfig | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "HouseholdDashboard":
        preferences = optional_mapping(payload, "preferences") or {}
        dashboard = optional_mapping(preferences, "dashboardConfig")
        return cls(
            id=required_str(payload, "id"),
            dashboard_config=DashboardConfig.from_api(dashboard) if dashboard else None,
        )


@dataclass(slots=True)
class SidebarData(OutputModel):
    me: UserRef
    subscription: HouseholdSubscription
    subscription_offering: SubscriptionOffering | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "SidebarData":
        return cls(
            me=UserRef.from_api(required_mapping(payload, "me")),
            subscription=HouseholdSubscription.from_api(required_mapping(payload, "subscription")),
            subscription_offering=SubscriptionOffering.from_api(s)
            if (s := optional_mapping(payload, "subscriptionOffering"))
            else None,
        )


@dataclass(slots=True)
class FinancialProfile(OutputModel):
    id: str
    birthday: str | None = None
    gross_annual_income: float | None = None
    employment_status: str | None = None
    tax_filing_status: str | None = None
    relationship_to_owner: str | None = None
    number_of_dependents: int | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "FinancialProfile":
        return cls(
            id=required_str(payload, "id"),
            birthday=optional_str(payload, "birthday"),
            gross_annual_income=optional_float(payload, "grossAnnualIncome"),
            employment_status=optional_str(payload, "employmentStatus"),
            tax_filing_status=optional_str(payload, "taxFilingStatus"),
            relationship_to_owner=optional_str(payload, "relationshipToOwner"),
            number_of_dependents=optional_int(payload, "numberOfDependents"),
        )


@dataclass(slots=True)
class HouseholdSettingsMember(HouseholdMember):
    financial_profile: FinancialProfile | None = None
    has_mfa_on: bool | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "HouseholdSettingsMember":
        member = HouseholdMember.from_api(payload)
        return cls(
            id=member.id,
            display_name=member.display_name,
            name=member.name,
            profile_picture_url=member.profile_picture_url,
            email=optional_str(payload, "email"),
            household_role=member.household_role,
            financial_profile=FinancialProfile.from_api(fp) if (fp := optional_mapping(payload, "financialProfile")) else None,
            has_mfa_on=optional_bool(payload, "hasMfaOn"),
        )


@dataclass(slots=True)
class HouseholdSettingsHousehold(OutputModel):
    id: str
    users: list[HouseholdSettingsMember]

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "HouseholdSettingsHousehold":
        return cls(
            id=required_str(payload, "id"),
            users=map_list(list_of_mappings(payload, "users"), HouseholdSettingsMember.from_api),
        )


@dataclass(slots=True)
class HouseholdInvite(OutputModel):
    id: str
    invited_email: str | None = None
    created_at: str | None = None
    is_revoked: bool | None = None
    used_at: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "HouseholdInvite":
        return cls(
            id=required_str(payload, "id"),
            invited_email=optional_str(payload, "invitedEmail"),
            created_at=optional_str(payload, "createdAt"),
            is_revoked=optional_bool(payload, "isRevoked"),
            used_at=optional_str(payload, "usedAt"),
        )


@dataclass(slots=True)
class HouseholdAccessGrant(OutputModel):
    id: str
    to_email: str | None = None
    to_name: str | None = None
    created_at: str | None = None
    expires_at: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "HouseholdAccessGrant":
        return cls(
            id=required_str(payload, "id"),
            to_email=optional_str(payload, "toEmail"),
            to_name=optional_str(payload, "toName"),
            created_at=optional_str(payload, "createdAt"),
            expires_at=optional_str(payload, "expiresAt"),
        )


@dataclass(slots=True)
class HouseholdMemberSettings(OutputModel):
    me: HouseholdMember
    my_household: HouseholdSettingsHousehold
    household_invites: list[HouseholdInvite] = field(default_factory=list)
    household_access_grants: list[HouseholdAccessGrant] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "HouseholdMemberSettings":
        return cls(
            me=HouseholdMember.from_api(required_mapping(payload, "me")),
            my_household=HouseholdSettingsHousehold.from_api(required_mapping(payload, "myHousehold")),
            household_invites=map_list(list_of_mappings(payload, "householdInvites"), HouseholdInvite.from_api),
            household_access_grants=map_list(list_of_mappings(payload, "householdAccessGrants"), HouseholdAccessGrant.from_api),
        )


@dataclass(slots=True)
class ExternalAuthProvider(OutputModel):
    provider: str
    email: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "ExternalAuthProvider":
        return cls(
            provider=required_str(payload, "provider"),
            email=optional_str(payload, "email"),
        )


@dataclass(slots=True)
class PendingEmailUpdateVerification(OutputModel):
    email: str

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "PendingEmailUpdateVerification":
        return cls(email=required_str(payload, "email"))


@dataclass(slots=True)
class SupportAccountAccessGrant(OutputModel):
    id: str
    created_at: str | None = None
    expires_at: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "SupportAccountAccessGrant":
        return cls(
            id=required_str(payload, "id"),
            created_at=optional_str(payload, "createdAt"),
            expires_at=optional_str(payload, "expiresAt"),
        )


@dataclass(slots=True)
class SecurityUser(UserRef):
    has_mfa_on: bool | None = None
    is_verified: bool | None = None
    has_password: bool | None = None
    external_auth_providers: list[ExternalAuthProvider] = field(default_factory=list)
    pending_email_update_verification: PendingEmailUpdateVerification | None = None
    active_support_account_access_grant: SupportAccountAccessGrant | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "SecurityUser":
        base = UserRef.from_api(payload)
        return cls(
            id=base.id,
            display_name=base.display_name,
            name=base.name,
            profile_picture_url=base.profile_picture_url,
            email=base.email,
            has_mfa_on=optional_bool(payload, "hasMfaOn"),
            is_verified=optional_bool(payload, "isVerified"),
            has_password=optional_bool(payload, "hasPassword"),
            external_auth_providers=map_list(list_of_mappings(payload, "externalAuthProviders"), ExternalAuthProvider.from_api),
            pending_email_update_verification=PendingEmailUpdateVerification.from_api(v)
            if (v := optional_mapping(payload, "pendingEmailUpdateVerification"))
            else None,
            active_support_account_access_grant=SupportAccountAccessGrant.from_api(g)
            if (g := optional_mapping(payload, "activeSupportAccountAccessGrant"))
            else None,
        )


@dataclass(slots=True)
class DiscordUserData(OutputModel):
    id: str | None = None
    discord_id: str | None = None
    username: str | None = None
    roles: list[str] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "DiscordUserData":
        roles = optional_list(payload, "roles") or []
        return cls(
            id=optional_str(payload, "id"),
            discord_id=optional_str(payload, "discordId"),
            username=optional_str(payload, "username"),
            roles=[item for item in roles if isinstance(item, str)],
        )


@dataclass(slots=True)
class SecuritySettings(OutputModel):
    me: SecurityUser
    user_discord_data: DiscordUserData | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "SecuritySettings":
        return cls(
            me=SecurityUser.from_api(required_mapping(payload, "me")),
            user_discord_data=DiscordUserData.from_api(d) if (d := optional_mapping(payload, "userDiscordData")) else None,
        )


@dataclass(slots=True)
class NotificationPreference(OutputModel):
    id: str
    group: str | None = None
    type: str | None = None
    title: str | None = None
    description: str | None = None
    email_enabled: bool | None = None
    push_enabled: bool | None = None
    in_app_enabled: bool | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "NotificationPreference":
        return cls(
            id=required_str(payload, "id"),
            group=optional_str(payload, "group"),
            type=optional_str(payload, "type"),
            title=optional_str(payload, "title"),
            description=optional_str(payload, "description"),
            email_enabled=optional_bool(payload, "emailEnabled", "EMAIL"),
            push_enabled=optional_bool(payload, "pushEnabled", "PUSH"),
            in_app_enabled=optional_bool(payload, "inAppEnabled"),
        )


@dataclass(slots=True)
class ReviewSummaryByUserEntry(OutputModel):
    user: UserRef | None = None
    count: int | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "ReviewSummaryByUserEntry":
        group_by = optional_mapping(payload, "groupBy") or {}
        user_payload = optional_mapping(group_by, "needsReviewByUser")
        summary = optional_mapping(payload, "summary") or {}
        return cls(
            user=UserRef.from_api(user_payload) if user_payload else None,
            count=optional_int(summary, "count"),
        )


@dataclass(slots=True)
class BusinessEntitiesBannerProfile(OutputModel):
    id: str
    should_show_business_entities_banner: bool | None = None
    business_entities_banner_count: int | None = None
    dismissed_business_entities_banner_at: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "BusinessEntitiesBannerProfile":
        return cls(
            id=required_str(payload, "id"),
            should_show_business_entities_banner=optional_bool(payload, "shouldShowBusinessEntitiesBanner"),
            business_entities_banner_count=optional_int(payload, "businessEntitiesBannerCount"),
            dismissed_business_entities_banner_at=optional_str(payload, "dismissedBusinessEntitiesBannerAt"),
        )


@dataclass(slots=True)
class BusinessEntity(OutputModel):
    id: str
    name: str
    description: str | None = None
    logo_url: str | None = None
    color: str | None = None
    notes: str | None = None
    structure: str | None = None
    created_at: str | None = None
    updated_at: str | None = None
    accounts: list[AccountRef] = field(default_factory=list)
    accounts_count: int | None = None
    transactions_count: int | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "BusinessEntity":
        return cls(
            id=required_str(payload, "id"),
            name=required_str(payload, "name"),
            description=optional_str(payload, "description"),
            logo_url=optional_str(payload, "logoUrl"),
            color=optional_str(payload, "color"),
            notes=optional_str(payload, "notes"),
            structure=optional_str(payload, "structure"),
            created_at=optional_str(payload, "createdAt"),
            updated_at=optional_str(payload, "updatedAt"),
            accounts=map_list(list_of_mappings(payload, "accounts"), AccountRef.from_api),
            accounts_count=optional_int(payload, "accountsCount"),
            transactions_count=optional_int(payload, "transactionsCount"),
        )


@dataclass(slots=True)
class HasActivityStatus(OutputModel):
    id: str
    has_new_activity: bool | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "HasActivityStatus":
        return cls(
            id=required_str(payload, "id"),
            has_new_activity=optional_bool(payload, "hasNewActivity"),
        )
