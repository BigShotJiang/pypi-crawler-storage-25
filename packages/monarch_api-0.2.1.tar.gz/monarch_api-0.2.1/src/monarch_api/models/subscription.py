from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from .base import (
    InputModel,
    OutputModel,
    list_of_mappings,
    map_list,
    optional_bool,
    optional_float,
    optional_int,
    optional_list,
    optional_mapping,
    optional_str,
    required_mapping,
    required_str,
)
from .shared import UserRef


@dataclass(slots=True)
class PaymentMethod(OutputModel):
    brand: str | None = None
    last_four: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "PaymentMethod":
        return cls(
            brand=optional_str(payload, "brand"),
            last_four=optional_str(payload, "lastFour", "last_four"),
        )


@dataclass(slots=True)
class ActivePromoCode(OutputModel):
    code: str
    description: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "ActivePromoCode":
        return cls(
            code=required_str(payload, "code"),
            description=optional_str(payload, "description"),
        )


@dataclass(slots=True)
class ActiveSponsorship(OutputModel):
    id: str
    sponsor: UserRef | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "ActiveSponsorship":
        sponsor_payload = optional_mapping(payload, "sponsor")
        return cls(
            id=required_str(payload, "id"),
            sponsor=UserRef.from_api(sponsor_payload) if sponsor_payload else None,
        )


@dataclass(slots=True)
class ReferralRedemption(OutputModel):
    id: str | None = None
    campaign: str | None = None
    credits_earned: float | None = None
    credits_earned_at: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "ReferralRedemption":
        return cls(
            id=optional_str(payload, "id"),
            campaign=optional_str(payload, "campaign"),
            credits_earned=optional_float(payload, "creditsEarned"),
            credits_earned_at=optional_str(payload, "creditsEarnedAt"),
        )


@dataclass(slots=True)
class HouseholdSubscription(OutputModel):
    id: str
    billing_period: str | None = None
    payment_source: str | None = None
    is_on_free_trial: bool | None = None
    has_premium_entitlement: bool | None = None
    next_payment_amount: float | None = None
    trial_ends_at: str | None = None
    trial_duration_days: int | None = None
    plus_trial_ends_at: str | None = None
    canceled_plus_trial_at: str | None = None
    trial_type: str | None = None
    entitlements: list[str] = field(default_factory=list)
    eligible_for_trial: bool | None = None
    will_cancel_at_period_end: bool | None = None
    payment_method: PaymentMethod | None = None
    active_sponsorship: ActiveSponsorship | None = None
    active_promo_code: ActivePromoCode | None = None
    sponsored_by: UserRef | None = None
    has_billing_issue: bool | None = None
    is_sponsor: bool | None = None
    has_had_free_trial_extension: bool | None = None
    has_stripe_subscription_id: bool | None = None
    has_charged_for_lifetime: bool | None = None
    current_period_ends_at: str | None = None
    is_eligible_for_core_to_plus_promo: bool | None = None
    plus_upgrade_prorated_amount: float | None = None
    referral_code: str | None = None
    referral_redemption: ReferralRedemption | None = None
    analytics_freemium_summary_status: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "HouseholdSubscription":
        entitlements = optional_list(payload, "entitlements") or []
        return cls(
            id=required_str(payload, "id"),
            billing_period=optional_str(payload, "billingPeriod"),
            payment_source=optional_str(payload, "paymentSource"),
            is_on_free_trial=optional_bool(payload, "isOnFreeTrial"),
            has_premium_entitlement=optional_bool(payload, "hasPremiumEntitlement"),
            next_payment_amount=optional_float(payload, "nextPaymentAmount"),
            trial_ends_at=optional_str(payload, "trialEndsAt"),
            trial_duration_days=optional_int(payload, "trialDurationDays"),
            plus_trial_ends_at=optional_str(payload, "plusTrialEndsAt"),
            canceled_plus_trial_at=optional_str(payload, "canceledPlusTrialAt"),
            trial_type=optional_str(payload, "trialType"),
            entitlements=[item for item in entitlements if isinstance(item, str)],
            eligible_for_trial=optional_bool(payload, "eligibleForTrial"),
            will_cancel_at_period_end=optional_bool(payload, "willCancelAtPeriodEnd"),
            payment_method=PaymentMethod.from_api(pm) if (pm := optional_mapping(payload, "paymentMethod")) else None,
            active_sponsorship=ActiveSponsorship.from_api(a) if (a := optional_mapping(payload, "activeSponsorship")) else None,
            active_promo_code=ActivePromoCode.from_api(a) if (a := optional_mapping(payload, "activePromoCode")) else None,
            sponsored_by=UserRef.from_api(s) if (s := optional_mapping(payload, "sponsoredBy")) else None,
            has_billing_issue=optional_bool(payload, "hasBillingIssue"),
            is_sponsor=optional_bool(payload, "isSponsor"),
            has_had_free_trial_extension=optional_bool(payload, "hasHadFreeTrialExtension"),
            has_stripe_subscription_id=optional_bool(payload, "hasStripeSubscriptionId"),
            has_charged_for_lifetime=optional_bool(payload, "hasChargedForLifetime"),
            current_period_ends_at=optional_str(payload, "currentPeriodEndsAt"),
            is_eligible_for_core_to_plus_promo=optional_bool(payload, "isEligibleForCoreToPlusPromo"),
            plus_upgrade_prorated_amount=optional_float(payload, "plusUpgradeProratedAmount"),
            referral_code=optional_str(payload, "referralCode"),
            referral_redemption=ReferralRedemption.from_api(r) if (r := optional_mapping(payload, "referralRedemption")) else None,
            analytics_freemium_summary_status=optional_str(payload, "analyticsFreemiumSummaryStatus"),
        )


@dataclass(slots=True)
class Invoice(OutputModel):
    id: str
    date: str | None = None
    amount: float | None = None
    receipt_url: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "Invoice":
        return cls(
            id=required_str(payload, "id"),
            date=optional_str(payload, "date"),
            amount=optional_float(payload, "amount"),
            receipt_url=optional_str(payload, "receiptUrl"),
        )


@dataclass(slots=True)
class SubscriptionConstants(OutputModel):
    monthly_price_dollars: float | None = None
    referral_annual_reward_limit_usd: float | None = None
    referral_v2_program_launch_date: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "SubscriptionConstants":
        return cls(
            monthly_price_dollars=optional_float(payload, "monthlyPriceDollars"),
            referral_annual_reward_limit_usd=optional_float(payload, "referralAnnualRewardLimitUsd"),
            referral_v2_program_launch_date=optional_str(payload, "referralV2ProgramLaunchDate"),
        )


@dataclass(slots=True)
class SubscriptionPlan(OutputModel):
    name: str | None = None
    period: str | None = None
    tier: str | None = None
    price_per_period_dollars: float | None = None
    discounted_price_per_period_dollars: float | None = None
    stripe_id: str | None = None
    new_trial_ends_at: str | None = None
    require_payment_method: bool | None = None
    sponsored_by: UserRef | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "SubscriptionPlan":
        return cls(
            name=optional_str(payload, "name"),
            period=optional_str(payload, "period"),
            tier=optional_str(payload, "tier"),
            price_per_period_dollars=optional_float(payload, "pricePerPeriodDollars"),
            discounted_price_per_period_dollars=optional_float(payload, "discountedPricePerPeriodDollars"),
            stripe_id=optional_str(payload, "stripeId"),
            new_trial_ends_at=optional_str(payload, "newTrialEndsAt"),
            require_payment_method=optional_bool(payload, "requirePaymentMethod"),
            sponsored_by=UserRef.from_api(s) if (s := optional_mapping(payload, "sponsoredBy")) else None,
        )


@dataclass(slots=True)
class SubscriptionOffering(OutputModel):
    promo_code_error: str | None = None
    promo_code_description: str | None = None
    promo_code_duration: str | None = None
    promo_code_duration_in_months: int | None = None
    plans: list[SubscriptionPlan] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "SubscriptionOffering":
        return cls(
            promo_code_error=optional_str(payload, "promoCodeError"),
            promo_code_description=optional_str(payload, "promoCodeDescription"),
            promo_code_duration=optional_str(payload, "promoCodeDuration"),
            promo_code_duration_in_months=optional_int(payload, "promoCodeDurationInMonths"),
            plans=map_list(list_of_mappings(payload, "plans"), SubscriptionPlan.from_api),
        )


@dataclass(slots=True)
class PlusUpgradeTrial(OutputModel):
    trial_days: int | None = None
    is_eligible: bool | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "PlusUpgradeTrial":
        return cls(
            trial_days=optional_int(payload, "trialDays"),
            is_eligible=optional_bool(payload, "isEligible"),
        )


@dataclass(slots=True)
class SubscriptionResult(OutputModel):
    subscription: HouseholdSubscription
    invoices: list[Invoice] = field(default_factory=list)
    credit_balance: float | None = None
    constants: SubscriptionConstants | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "SubscriptionResult":
        constants = optional_mapping(payload, "constants")
        return cls(
            subscription=HouseholdSubscription.from_api(required_mapping(payload, "subscription")),
            invoices=map_list(list_of_mappings(payload, "invoices"), Invoice.from_api),
            credit_balance=optional_float(payload, "creditBalance"),
            constants=SubscriptionConstants.from_api(constants) if constants else None,
        )


@dataclass(slots=True)
class SubscriptionModal(OutputModel):
    subscription: HouseholdSubscription | None = None
    plus_upgrade_trial: PlusUpgradeTrial | None = None
    subscription_offering: SubscriptionOffering | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "SubscriptionModal":
        return cls(
            subscription=HouseholdSubscription.from_api(s) if (s := optional_mapping(payload, "subscription")) else None,
            plus_upgrade_trial=PlusUpgradeTrial.from_api(p) if (p := optional_mapping(payload, "plusUpgradeTrial")) else None,
            subscription_offering=SubscriptionOffering.from_api(s) if (s := optional_mapping(payload, "subscriptionOffering")) else None,
        )


@dataclass(slots=True)
class FeatureEntitlement(OutputModel):
    feature: str
    required_entitlements: list[str] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "FeatureEntitlement":
        raw = optional_list(payload, "requiredEntitlements") or []
        return cls(
            feature=required_str(payload, "feature"),
            required_entitlements=[item for item in raw if isinstance(item, str)],
        )


@dataclass(slots=True)
class EntitlementConstant(OutputModel):
    entitlement: str
    max_credentials: int | None = None
    max_transaction_rules: int | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "EntitlementConstant":
        return cls(
            entitlement=required_str(payload, "entitlement"),
            max_credentials=optional_int(payload, "maxCredentials"),
            max_transaction_rules=optional_int(payload, "maxTransactionRules"),
        )


@dataclass(slots=True)
class FeatureEntitlementParams(OutputModel):
    features: list[FeatureEntitlement] = field(default_factory=list)
    constants: list[EntitlementConstant] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "FeatureEntitlementParams":
        return cls(
            features=map_list(list_of_mappings(payload, "features"), FeatureEntitlement.from_api),
            constants=map_list(list_of_mappings(payload, "constants"), EntitlementConstant.from_api),
        )


@dataclass(slots=True)
class GiftedSubscription(OutputModel):
    id: str
    created_at: str | None = None
    recipient_name: str | None = None
    promo_code: str | None = None
    status: str | None = None
    redeemed_at: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "GiftedSubscription":
        return cls(
            id=required_str(payload, "id"),
            created_at=optional_str(payload, "createdAt"),
            recipient_name=optional_str(payload, "recipientName"),
            promo_code=optional_str(payload, "promoCode"),
            status=optional_str(payload, "status"),
            redeemed_at=optional_str(payload, "redeemedAt"),
        )


@dataclass(slots=True)
class ReferralStatistics(OutputModel):
    credits_earned: float | None = None
    subscribed: int | None = None
    signed_up: int | None = None
    pending_count: int | None = None
    earned_credits_count: int | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "ReferralStatistics":
        return cls(
            credits_earned=optional_float(payload, "creditsEarned"),
            subscribed=optional_int(payload, "subscribed"),
            signed_up=optional_int(payload, "signedUp"),
            pending_count=optional_int(payload, "pendingCount"),
            earned_credits_count=optional_int(payload, "earnedCreditsCount"),
        )


@dataclass(slots=True)
class ReferralSettings(OutputModel):
    constants: SubscriptionConstants | None = None
    legacy_referral_statistics: ReferralStatistics | None = None
    referral_statistics: ReferralStatistics | None = None
    referral_redemptions: list[ReferralRedemption] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "ReferralSettings":
        constants = optional_mapping(payload, "constants")
        return cls(
            constants=SubscriptionConstants.from_api(constants) if constants else None,
            legacy_referral_statistics=ReferralStatistics.from_api(s)
            if (s := optional_mapping(payload, "legacyReferralStatistics"))
            else None,
            referral_statistics=ReferralStatistics.from_api(s)
            if (s := optional_mapping(payload, "referralStatistics"))
            else None,
            referral_redemptions=map_list(list_of_mappings(payload, "referralRedemptions"), ReferralRedemption.from_api),
        )


@dataclass(slots=True)
class PremiumUpgradePlansRequest(InputModel):
    promo_code: str | None = field(default=None, metadata={"api_name": "promoCode"})
    referral_code: str | None = field(default=None, metadata={"api_name": "referralCode"})
    selected_plan_id: str | None = field(default=None, metadata={"api_name": "selectedPlanId"})


@dataclass(slots=True)
class ReferralSettingsRequest(InputModel):
    statistics_start_date: str = field(metadata={"api_name": "statisticsStartDate"})
    statistics_end_date: str = field(metadata={"api_name": "statisticsEndDate"})
    v1_payout_method: str = field(metadata={"api_name": "v1PayoutMethod"})
    v2_payout_method: str = field(metadata={"api_name": "v2PayoutMethod"})
