from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from .base import InputModel, OutputModel, list_of_mappings, map_list, optional_bool, optional_float, optional_int, optional_mapping, optional_str, required_str
from .shared import CategoryRef, MerchantRef, PayloadError


def _optional_decimal(payload: Mapping[str, Any], name: str) -> float | None:
    value = payload.get(name)
    if value is None:
        return None
    if isinstance(value, bool):
        raise TypeError(f"{name} must be a decimal-compatible value when present.")
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        return float(value)
    raise TypeError(f"{name} must be a decimal-compatible value when present.")


@dataclass(slots=True)
class RetailVendorSettings(OutputModel):
    id: str
    vendor: str | None = None
    should_categorize_and_split_transactions: bool | None = None
    should_update_transactions_notes: bool | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "RetailVendorSettings":
        return cls(
            id=required_str(payload, "id"),
            vendor=optional_str(payload, "vendor"),
            should_categorize_and_split_transactions=optional_bool(payload, "shouldCategorizeAndSplitTransactions"),
            should_update_transactions_notes=optional_bool(payload, "shouldUpdateTransactionsNotes"),
        )


@dataclass(slots=True)
class RetailExtensionSettings(OutputModel):
    id: str
    retail_vendor_settings: list[RetailVendorSettings] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "RetailExtensionSettings":
        return cls(
            id=required_str(payload, "id"),
            retail_vendor_settings=map_list(list_of_mappings(payload, "retailVendorSettings"), RetailVendorSettings.from_api),
        )


@dataclass(slots=True)
class RetailOrderAttachment(OutputModel):
    id: str
    storage_id: str | None = None
    filename: str | None = None
    extension: str | None = None
    size_bytes: int | None = None
    original_asset_url: str | None = None
    thumbnail_url: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "RetailOrderAttachment":
        return cls(
            id=required_str(payload, "id"),
            storage_id=optional_str(payload, "storageId"),
            filename=optional_str(payload, "filename"),
            extension=optional_str(payload, "extension"),
            size_bytes=optional_int(payload, "sizeBytes"),
            original_asset_url=optional_str(payload, "originalAssetUrl"),
            thumbnail_url=optional_str(payload, "thumbnailUrl"),
        )


@dataclass(slots=True)
class RetailLineItem(OutputModel):
    id: str
    title: str | None = None
    quantity: int | None = None
    price: float | None = None
    total: float | None = None
    is_associated_to_retail_transaction: bool | None = None
    category: CategoryRef | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "RetailLineItem":
        return cls(
            id=required_str(payload, "id"),
            title=optional_str(payload, "title"),
            quantity=optional_int(payload, "quantity"),
            price=optional_float(payload, "price"),
            total=optional_float(payload, "total"),
            is_associated_to_retail_transaction=optional_bool(payload, "isAssociatedToRetailTransaction"),
            category=CategoryRef.from_api(c) if (c := optional_mapping(payload, "category")) else None,
        )


@dataclass(slots=True)
class RetailMatchedTransaction(OutputModel):
    id: str
    is_manual: bool | None = None
    has_split_transactions: bool | None = None
    merchant: MerchantRef | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "RetailMatchedTransaction":
        return cls(
            id=required_str(payload, "id"),
            is_manual=optional_bool(payload, "isManual"),
            has_split_transactions=optional_bool(payload, "hasSplitTransactions"),
            merchant=MerchantRef.from_api(m) if (m := optional_mapping(payload, "merchant")) else None,
        )


@dataclass(slots=True)
class RetailTransaction(OutputModel):
    id: str
    date: str | None = None
    total: float | None = None
    transaction_type: str | None = None
    transaction_update_skipped: bool | None = None
    transaction: RetailMatchedTransaction | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "RetailTransaction":
        return cls(
            id=required_str(payload, "id"),
            date=optional_str(payload, "date"),
            total=_optional_decimal(payload, "total"),
            transaction_type=optional_str(payload, "transactionType"),
            transaction_update_skipped=optional_bool(payload, "transactionUpdateSkipped"),
            transaction=RetailMatchedTransaction.from_api(t) if (t := optional_mapping(payload, "transaction")) else None,
        )


@dataclass(slots=True)
class RetailOrder(OutputModel):
    id: str
    merchant_name: str | None = None
    vendor: str | None = None
    vendor_order_id: str | None = None
    date: str | None = None
    total_for_products: float | None = None
    shipping: float | None = None
    delivery_fee: float | None = None
    additional_charges: float | None = None
    adjustments_amount: float | None = None
    total_before_tax: float | None = None
    tax: float | None = None
    tip: float | None = None
    gift_card_amount: float | None = None
    grand_total: float | None = None
    display_status: str | None = None
    retail_line_items: list[RetailLineItem] = field(default_factory=list)
    retail_transactions: list[RetailTransaction] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "RetailOrder":
        return cls(
            id=required_str(payload, "id"),
            merchant_name=optional_str(payload, "merchantName"),
            vendor=optional_str(payload, "vendor"),
            vendor_order_id=optional_str(payload, "vendorOrderId"),
            date=optional_str(payload, "date"),
            total_for_products=_optional_decimal(payload, "totalForProducts"),
            shipping=_optional_decimal(payload, "shipping"),
            delivery_fee=_optional_decimal(payload, "deliveryFee"),
            additional_charges=_optional_decimal(payload, "additionalCharges"),
            adjustments_amount=_optional_decimal(payload, "adjustmentsAmount"),
            total_before_tax=_optional_decimal(payload, "totalBeforeTax"),
            tax=_optional_decimal(payload, "tax"),
            tip=_optional_decimal(payload, "tip"),
            gift_card_amount=_optional_decimal(payload, "giftCardAmount"),
            grand_total=_optional_decimal(payload, "grandTotal"),
            display_status=optional_str(payload, "displayStatus"),
            retail_line_items=map_list(list_of_mappings(payload, "retailLineItems"), RetailLineItem.from_api),
            retail_transactions=map_list(list_of_mappings(payload, "retailTransactions"), RetailTransaction.from_api),
        )


@dataclass(slots=True)
class RetailSync(OutputModel):
    id: str
    vendor: str | None = None
    status: str | None = None
    started_at: str | None = None
    ended_at: str | None = None
    created_at: str | None = None
    updated_at: str | None = None
    attachments: list[RetailOrderAttachment] = field(default_factory=list)
    orders: list[RetailOrder] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "RetailSync":
        return cls(
            id=required_str(payload, "id"),
            vendor=optional_str(payload, "vendor"),
            status=optional_str(payload, "status"),
            started_at=optional_str(payload, "startedAt"),
            ended_at=optional_str(payload, "endedAt"),
            created_at=optional_str(payload, "createdAt"),
            updated_at=optional_str(payload, "updatedAt"),
            attachments=map_list(list_of_mappings(payload, "attachments"), RetailOrderAttachment.from_api),
            orders=map_list(list_of_mappings(payload, "orders"), RetailOrder.from_api),
        )


@dataclass(slots=True)
class RetailSyncListResult(OutputModel):
    total_count: int | None = None
    results: list[RetailSync] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "RetailSyncListResult":
        return cls(
            total_count=optional_int(payload, "totalCount"),
            results=map_list(list_of_mappings(payload, "results"), RetailSync.from_api),
        )


@dataclass(slots=True)
class RetailSyncFilter(InputModel):
    status: str | None = None
    vendor: str | None = None


@dataclass(slots=True)
class CreateRetailSyncRequest(InputModel):
    vendor: str
    is_backfill: bool | None = field(default=None, metadata={"api_name": "isBackfill"})


@dataclass(slots=True)
class CreateBulkRetailSyncRequest(InputModel):
    count: int


@dataclass(slots=True)
class RetailLineItemUpdateInput(InputModel):
    retail_line_item_id: str = field(metadata={"api_name": "retailLineItemId"})
    category_id: str | None = field(default=None, metadata={"api_name": "categoryId"})
    delete: bool | None = None
    price: float | None = None
    quantity: int | None = None
    title: str | None = None


@dataclass(slots=True)
class RetailTransactionUpdateInput(InputModel):
    retail_transaction_id: str = field(metadata={"api_name": "retailTransactionId"})
    date: str | None = None
    total: float | None = None


@dataclass(slots=True)
class UpdateRetailOrderRequest(InputModel):
    retail_order_id: str = field(metadata={"api_name": "retailOrderId"})
    date: str | None = None
    grand_total: float | None = field(default=None, metadata={"api_name": "grandTotal"})
    line_item_updates: list[RetailLineItemUpdateInput] | None = field(default=None, metadata={"api_name": "lineItemUpdates"})
    merchant_name: str | None = field(default=None, metadata={"api_name": "merchantName"})
    tax: float | None = None
    tip: float | None = None
    total_before_tax: float | None = field(default=None, metadata={"api_name": "totalBeforeTax"})
    transaction_updates: list[RetailTransactionUpdateInput] | None = field(default=None, metadata={"api_name": "transactionUpdates"})


@dataclass(slots=True)
class UpdateRetailVendorSettingsRequest(InputModel):
    vendor: str
    merchant_name: str | None = field(default=None, metadata={"api_name": "merchantName"})
    should_categorize_and_split_transactions: bool | None = field(default=None, metadata={"api_name": "shouldCategorizeAndSplitTransactions"})
    should_update_past_transactions: bool | None = field(default=None, metadata={"api_name": "shouldUpdatePastTransactions"})
    should_update_transactions_notes: bool | None = field(default=None, metadata={"api_name": "shouldUpdateTransactionsNotes"})


@dataclass(slots=True)
class RetailSyncMutationResult(OutputModel):
    retail_sync: RetailSync | None = None
    errors: list[PayloadError] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "RetailSyncMutationResult":
        return cls(
            retail_sync=RetailSync.from_api(r) if (r := optional_mapping(payload, "retailSync")) else None,
            errors=map_list(list_of_mappings(payload, "errors"), PayloadError.from_api),
        )


@dataclass(slots=True)
class BulkRetailSyncMutationResult(OutputModel):
    retail_syncs: list[RetailSync] = field(default_factory=list)
    errors: list[PayloadError] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "BulkRetailSyncMutationResult":
        return cls(
            retail_syncs=map_list(list_of_mappings(payload, "retailSyncs"), RetailSync.from_api),
            errors=map_list(list_of_mappings(payload, "errors"), PayloadError.from_api),
        )


@dataclass(slots=True)
class DeleteRetailSyncResult(OutputModel):
    success: bool = False
    errors: list[PayloadError] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "DeleteRetailSyncResult":
        return cls(
            success=bool(payload.get("success")),
            errors=map_list(list_of_mappings(payload, "errors"), PayloadError.from_api),
        )


@dataclass(slots=True)
class UpdateRetailVendorSettingsResult(OutputModel):
    retail_vendor_settings: RetailVendorSettings | None = None
    errors: list[PayloadError] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "UpdateRetailVendorSettingsResult":
        return cls(
            retail_vendor_settings=RetailVendorSettings.from_api(r)
            if (r := optional_mapping(payload, "retailVendorSettings"))
            else None,
            errors=map_list(list_of_mappings(payload, "errors"), PayloadError.from_api),
        )
