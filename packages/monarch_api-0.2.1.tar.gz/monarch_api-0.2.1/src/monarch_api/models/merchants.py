from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from .base import InputModel, OutputModel, list_of_mappings, map_list, optional_bool, optional_float, optional_mapping, optional_str, required_str
from .recurring import RecurringStream
from .shared import PayloadError
from .shared import MerchantRef


@dataclass(slots=True)
class RecommendedMerchant(MerchantRef):
    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "RecommendedMerchant":
        base = MerchantRef.from_api(payload)
        return cls(
            name=base.name,
            id=base.id,
            logo_url=base.logo_url,
            transactions_count=base.transactions_count,
            source=base.source,
        )


@dataclass(slots=True)
class UpdateRecurrenceFieldsInput(InputModel):
    is_recurring: bool = field(metadata={"api_name": "isRecurring"})
    amount: float | None = None
    base_date: str | None = field(default=None, metadata={"api_name": "baseDate"})
    day_of_the_month: str | None = field(default=None, metadata={"api_name": "dayOfTheMonth"})
    frequency: str | None = None
    is_active: bool | None = field(default=None, metadata={"api_name": "isActive"})


@dataclass(slots=True)
class UpdateMerchantRequest(InputModel):
    merchant_id: str = field(metadata={"api_name": "merchantId"})
    name: str | None = None
    recurrence: UpdateRecurrenceFieldsInput | None = None


@dataclass(slots=True)
class UpdatedMerchant(OutputModel):
    id: str
    name: str | None = None
    recurring_transaction_stream: RecurringStream | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "UpdatedMerchant":
        return cls(
            id=required_str(payload, "id"),
            name=optional_str(payload, "name"),
            recurring_transaction_stream=RecurringStream.from_api(r)
            if (r := optional_mapping(payload, "recurringTransactionStream"))
            else None,
        )


@dataclass(slots=True)
class UpdateMerchantResult(OutputModel):
    merchant: UpdatedMerchant | None = None
    errors: list[PayloadError] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "UpdateMerchantResult":
        return cls(
            merchant=UpdatedMerchant.from_api(m) if (m := optional_mapping(payload, "merchant")) else None,
            errors=map_list(list_of_mappings(payload, "errors"), PayloadError.from_api),
        )
