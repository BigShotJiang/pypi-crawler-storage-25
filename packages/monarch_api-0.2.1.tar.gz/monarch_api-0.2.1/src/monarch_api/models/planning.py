from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from .base import OutputModel, list_of_mappings, map_list, optional_bool, optional_float, optional_int, optional_mapping, optional_str, required_str
from .goals import SavingsGoal
from .shared import CategoryGroupRef, CategoryRef


@dataclass(slots=True)
class BudgetStatus(OutputModel):
    has_budget: bool | None = None
    has_transactions: bool | None = None
    will_create_budget_from_empty_default_categories: bool | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "BudgetStatus":
        return cls(
            has_budget=optional_bool(payload, "hasBudget"),
            has_transactions=optional_bool(payload, "hasTransactions"),
            will_create_budget_from_empty_default_categories=optional_bool(
                payload,
                "willCreateBudgetFromEmptyDefaultCategories",
            ),
        )


@dataclass(slots=True)
class BudgetMonthlyAmount(OutputModel):
    month: str | None = None
    planned_cash_flow_amount: float | None = None
    planned_set_aside_amount: float | None = None
    actual_amount: float | None = None
    remaining_amount: float | None = None
    previous_month_rollover_amount: float | None = None
    rollover_type: str | None = None
    cumulative_actual_amount: float | None = None
    rollover_target_amount: float | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "BudgetMonthlyAmount":
        return cls(
            month=optional_str(payload, "month"),
            planned_cash_flow_amount=optional_float(payload, "plannedCashFlowAmount"),
            planned_set_aside_amount=optional_float(payload, "plannedSetAsideAmount"),
            actual_amount=optional_float(payload, "actualAmount"),
            remaining_amount=optional_float(payload, "remainingAmount"),
            previous_month_rollover_amount=optional_float(payload, "previousMonthRolloverAmount"),
            rollover_type=optional_str(payload, "rolloverType"),
            cumulative_actual_amount=optional_float(payload, "cumulativeActualAmount"),
            rollover_target_amount=optional_float(payload, "rolloverTargetAmount"),
        )


@dataclass(slots=True)
class BudgetCategoryMonthlyAmounts(OutputModel):
    category: CategoryRef | None = None
    monthly_amounts: list[BudgetMonthlyAmount] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "BudgetCategoryMonthlyAmounts":
        return cls(
            category=CategoryRef.from_api(c) if (c := optional_mapping(payload, "category")) else None,
            monthly_amounts=map_list(list_of_mappings(payload, "monthlyAmounts"), BudgetMonthlyAmount.from_api),
        )


@dataclass(slots=True)
class BudgetCategoryGroupMonthlyAmounts(OutputModel):
    category_group: CategoryGroupRef | None = None
    monthly_amounts: list[BudgetMonthlyAmount] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "BudgetCategoryGroupMonthlyAmounts":
        return cls(
            category_group=CategoryGroupRef.from_api(c)
            if (c := optional_mapping(payload, "categoryGroup"))
            else None,
            monthly_amounts=map_list(list_of_mappings(payload, "monthlyAmounts"), BudgetMonthlyAmount.from_api),
        )


@dataclass(slots=True)
class BudgetFlexMonthlyAmounts(OutputModel):
    budget_variability: str | None = None
    monthly_amounts: list[BudgetMonthlyAmount] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "BudgetFlexMonthlyAmounts":
        return cls(
            budget_variability=optional_str(payload, "budgetVariability"),
            monthly_amounts=map_list(list_of_mappings(payload, "monthlyAmounts"), BudgetMonthlyAmount.from_api),
        )


@dataclass(slots=True)
class BudgetTotals(OutputModel):
    actual_amount: float | None = None
    planned_amount: float | None = None
    previous_month_rollover_amount: float | None = None
    remaining_amount: float | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "BudgetTotals":
        return cls(
            actual_amount=optional_float(payload, "actualAmount"),
            planned_amount=optional_float(payload, "plannedAmount"),
            previous_month_rollover_amount=optional_float(payload, "previousMonthRolloverAmount"),
            remaining_amount=optional_float(payload, "remainingAmount"),
        )


@dataclass(slots=True)
class BudgetMonthTotals(OutputModel):
    month: str | None = None
    total_income: BudgetTotals | None = None
    total_expenses: BudgetTotals | None = None
    total_fixed_expenses: BudgetTotals | None = None
    total_non_monthly_expenses: BudgetTotals | None = None
    total_flexible_expenses: BudgetTotals | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "BudgetMonthTotals":
        return cls(
            month=optional_str(payload, "month"),
            total_income=BudgetTotals.from_api(t) if (t := optional_mapping(payload, "totalIncome")) else None,
            total_expenses=BudgetTotals.from_api(t) if (t := optional_mapping(payload, "totalExpenses")) else None,
            total_fixed_expenses=BudgetTotals.from_api(t)
            if (t := optional_mapping(payload, "totalFixedExpenses"))
            else None,
            total_non_monthly_expenses=BudgetTotals.from_api(t)
            if (t := optional_mapping(payload, "totalNonMonthlyExpenses"))
            else None,
            total_flexible_expenses=BudgetTotals.from_api(t)
            if (t := optional_mapping(payload, "totalFlexibleExpenses"))
            else None,
        )


@dataclass(slots=True)
class BudgetRolloverPeriod(OutputModel):
    id: str
    start_month: int | None = None
    end_month: int | None = None
    starting_balance: float | None = None
    target_amount: float | None = None
    frequency: str | None = None
    type: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "BudgetRolloverPeriod":
        return cls(
            id=required_str(payload, "id"),
            start_month=optional_int(payload, "startMonth"),
            end_month=optional_int(payload, "endMonth"),
            starting_balance=optional_float(payload, "startingBalance"),
            target_amount=optional_float(payload, "targetAmount"),
            frequency=optional_str(payload, "frequency"),
            type=optional_str(payload, "type"),
        )


@dataclass(slots=True)
class BudgetCategoryGroupLink(OutputModel):
    id: str
    type: str | None = None
    budget_variability: str | None = None
    group_level_budgeting_enabled: bool | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "BudgetCategoryGroupLink":
        return cls(
            id=required_str(payload, "id"),
            type=optional_str(payload, "type"),
            budget_variability=optional_str(payload, "budgetVariability"),
            group_level_budgeting_enabled=optional_bool(payload, "groupLevelBudgetingEnabled"),
        )


@dataclass(slots=True)
class BudgetCategory(OutputModel):
    id: str
    name: str | None = None
    icon: str | None = None
    order: int | None = None
    budget_variability: str | None = None
    exclude_from_budget: bool | None = None
    is_system_category: bool | None = None
    updated_at: str | None = None
    group: BudgetCategoryGroupLink | None = None
    rollover_period: BudgetRolloverPeriod | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "BudgetCategory":
        return cls(
            id=required_str(payload, "id"),
            name=optional_str(payload, "name"),
            icon=optional_str(payload, "icon"),
            order=optional_int(payload, "order"),
            budget_variability=optional_str(payload, "budgetVariability"),
            exclude_from_budget=optional_bool(payload, "excludeFromBudget"),
            is_system_category=optional_bool(payload, "isSystemCategory"),
            updated_at=optional_str(payload, "updatedAt"),
            group=BudgetCategoryGroupLink.from_api(g) if (g := optional_mapping(payload, "group")) else None,
            rollover_period=BudgetRolloverPeriod.from_api(r)
            if (r := optional_mapping(payload, "rolloverPeriod"))
            else None,
        )


@dataclass(slots=True)
class BudgetCategoryGroup(OutputModel):
    id: str
    name: str | None = None
    order: int | None = None
    type: str | None = None
    budget_variability: str | None = None
    updated_at: str | None = None
    group_level_budgeting_enabled: bool | None = None
    categories: list[BudgetCategory] = field(default_factory=list)
    rollover_period: BudgetRolloverPeriod | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "BudgetCategoryGroup":
        return cls(
            id=required_str(payload, "id"),
            name=optional_str(payload, "name"),
            order=optional_int(payload, "order"),
            type=optional_str(payload, "type"),
            budget_variability=optional_str(payload, "budgetVariability"),
            updated_at=optional_str(payload, "updatedAt"),
            group_level_budgeting_enabled=optional_bool(payload, "groupLevelBudgetingEnabled"),
            categories=map_list(list_of_mappings(payload, "categories"), BudgetCategory.from_api),
            rollover_period=BudgetRolloverPeriod.from_api(r)
            if (r := optional_mapping(payload, "rolloverPeriod"))
            else None,
        )


@dataclass(slots=True)
class GoalPlannedContribution(OutputModel):
    id: str
    month: str | None = None
    amount: float | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "GoalPlannedContribution":
        return cls(
            id=required_str(payload, "id"),
            month=optional_str(payload, "month"),
            amount=optional_float(payload, "amount"),
        )


@dataclass(slots=True)
class GoalMonthlyContributionSummary(OutputModel):
    month: str | None = None
    sum: float | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "GoalMonthlyContributionSummary":
        return cls(
            month=optional_str(payload, "month"),
            sum=optional_float(payload, "sum"),
        )


@dataclass(slots=True)
class PlanningGoal(OutputModel):
    id: str
    name: str | None = None
    archived_at: str | None = None
    completed_at: str | None = None
    priority: int | None = None
    image_storage_provider: str | None = None
    image_storage_provider_id: str | None = None
    planned_contributions: list[GoalPlannedContribution] = field(default_factory=list)
    monthly_contribution_summaries: list[GoalMonthlyContributionSummary] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "PlanningGoal":
        return cls(
            id=required_str(payload, "id"),
            name=optional_str(payload, "name"),
            archived_at=optional_str(payload, "archivedAt"),
            completed_at=optional_str(payload, "completedAt"),
            priority=optional_int(payload, "priority"),
            image_storage_provider=optional_str(payload, "imageStorageProvider"),
            image_storage_provider_id=optional_str(payload, "imageStorageProviderId"),
            planned_contributions=map_list(
                list_of_mappings(payload, "plannedContributions"),
                GoalPlannedContribution.from_api,
            ),
            monthly_contribution_summaries=map_list(
                list_of_mappings(payload, "monthlyContributionSummaries"),
                GoalMonthlyContributionSummary.from_api,
            ),
        )


@dataclass(slots=True)
class SavingsGoalMonthlyAmount(OutputModel):
    id: str
    month: str | None = None
    planned_amount: float | None = None
    actual_amount: float | None = None
    remaining_amount: float | None = None
    total_planned_amount: float | None = None
    total_actual_amount: float | None = None
    total_remaining_amount: float | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "SavingsGoalMonthlyAmount":
        return cls(
            id=required_str(payload, "id"),
            month=optional_str(payload, "month"),
            planned_amount=optional_float(payload, "plannedAmount"),
            actual_amount=optional_float(payload, "actualAmount"),
            remaining_amount=optional_float(payload, "remainingAmount"),
            total_planned_amount=optional_float(payload, "totalPlannedAmount"),
            total_actual_amount=optional_float(payload, "totalActualAmount"),
            total_remaining_amount=optional_float(payload, "totalRemainingAmount"),
        )


@dataclass(slots=True)
class SavingsGoalMonthlyBudgetAmounts(OutputModel):
    id: str
    savings_goal: SavingsGoal | None = None
    monthly_amounts: list[SavingsGoalMonthlyAmount] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "SavingsGoalMonthlyBudgetAmounts":
        return cls(
            id=required_str(payload, "id"),
            savings_goal=SavingsGoal.from_api(s) if (s := optional_mapping(payload, "savingsGoal")) else None,
            monthly_amounts=map_list(list_of_mappings(payload, "monthlyAmounts"), SavingsGoalMonthlyAmount.from_api),
        )


@dataclass(slots=True)
class BudgetData(OutputModel):
    monthly_amounts_by_category: list[BudgetCategoryMonthlyAmounts] = field(default_factory=list)
    monthly_amounts_by_category_group: list[BudgetCategoryGroupMonthlyAmounts] = field(default_factory=list)
    monthly_amounts_for_flex_expense: list[BudgetFlexMonthlyAmounts] = field(default_factory=list)
    totals_by_month: list[BudgetMonthTotals] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "BudgetData":
        return cls(
            monthly_amounts_by_category=map_list(
                list_of_mappings(payload, "monthlyAmountsByCategory"),
                BudgetCategoryMonthlyAmounts.from_api,
            ),
            monthly_amounts_by_category_group=map_list(
                list_of_mappings(payload, "monthlyAmountsByCategoryGroup"),
                BudgetCategoryGroupMonthlyAmounts.from_api,
            ),
            monthly_amounts_for_flex_expense=map_list(
                list_of_mappings(payload, "monthlyAmountsForFlexExpense"),
                BudgetFlexMonthlyAmounts.from_api,
            ),
            totals_by_month=map_list(list_of_mappings(payload, "totalsByMonth"), BudgetMonthTotals.from_api),
        )


@dataclass(slots=True)
class BudgetDataResult(OutputModel):
    budget_system: str | None = None
    budget_status: BudgetStatus | None = None
    budget_data: BudgetData | None = None
    category_groups: list[BudgetCategoryGroup] = field(default_factory=list)
    goals: list[PlanningGoal] = field(default_factory=list)
    savings_goal_monthly_budget_amounts: list[SavingsGoalMonthlyBudgetAmounts] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "BudgetDataResult":
        return cls(
            budget_system=optional_str(payload, "budgetSystem"),
            budget_status=BudgetStatus.from_api(b) if (b := optional_mapping(payload, "budgetStatus")) else None,
            budget_data=BudgetData.from_api(b) if (b := optional_mapping(payload, "budgetData")) else None,
            category_groups=map_list(list_of_mappings(payload, "categoryGroups"), BudgetCategoryGroup.from_api),
            goals=map_list(list_of_mappings(payload, "goalsV2"), PlanningGoal.from_api),
            savings_goal_monthly_budget_amounts=map_list(
                list_of_mappings(payload, "savingsGoalMonthlyBudgetAmounts"),
                SavingsGoalMonthlyBudgetAmounts.from_api,
            ),
        )


@dataclass(slots=True)
class JointPlanningDataResult(OutputModel):
    budget_system: str | None = None
    budget_data: BudgetData | None = None
    category_groups: list[BudgetCategoryGroup] = field(default_factory=list)
    goals: list[PlanningGoal] = field(default_factory=list)
    savings_goal_monthly_budget_amounts: list[SavingsGoalMonthlyBudgetAmounts] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "JointPlanningDataResult":
        return cls(
            budget_system=optional_str(payload, "budgetSystem"),
            budget_data=BudgetData.from_api(b) if (b := optional_mapping(payload, "budgetData")) else None,
            category_groups=map_list(list_of_mappings(payload, "categoryGroups"), BudgetCategoryGroup.from_api),
            goals=map_list(list_of_mappings(payload, "goalsV2"), PlanningGoal.from_api),
            savings_goal_monthly_budget_amounts=map_list(
                list_of_mappings(payload, "savingsGoalMonthlyBudgetAmounts"),
                SavingsGoalMonthlyBudgetAmounts.from_api,
            ),
        )
