from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from .base import InputModel, OutputModel, list_of_mappings, map_list, optional_bool, optional_float, optional_int, optional_mapping, optional_str, required_mapping, required_str
from .household import HouseholdPreferences
from .shared import (
    AccountRef,
    AccountSubtypeRef,
    AccountTypeRef,
    BusinessEntitySetInput,
    BusinessEntityRef,
    CredentialRef,
    InstitutionRef,
    OwnershipSetInput,
    PayloadError,
    UserRef,
)


@dataclass(slots=True)
class ActiveInstitutionNotice(OutputModel):
    id: str
    public_message: str | None = None
    severity: str | None = None
    starts_at: str | None = None
    institution_id: str | None = None
    data_provider: str | None = None
    show_as_warn_before_connecting: bool | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "ActiveInstitutionNotice":
        return cls(
            id=required_str(payload, "id"),
            public_message=optional_str(payload, "publicMessage"),
            severity=optional_str(payload, "severity"),
            starts_at=optional_str(payload, "startsAt"),
            institution_id=optional_str(payload, "institutionId"),
            data_provider=optional_str(payload, "dataProvider"),
            show_as_warn_before_connecting=optional_bool(payload, "showAsWarnBeforeConnecting"),
        )


@dataclass(slots=True)
class AggregateSnapshot(OutputModel):
    date: str
    balance: float | None = None
    assets_balance: float | None = None
    liabilities_balance: float | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "AggregateSnapshot":
        return cls(
            date=required_str(payload, "date"),
            balance=optional_float(payload, "balance"),
            assets_balance=optional_float(payload, "assetsBalance"),
            liabilities_balance=optional_float(payload, "liabilitiesBalance"),
        )


@dataclass(slots=True)
class AccountsSyncStatus(OutputModel):
    has_accounts_syncing: bool

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "AccountsSyncStatus":
        return cls(has_accounts_syncing=bool(payload.get("hasAccountsSyncing")))


@dataclass(slots=True)
class AccountTypeDetail(OutputModel):
    name: str
    display: str | None = None
    group: str | None = None
    show_for_synced_accounts: bool | None = None
    possible_subtypes: list[AccountSubtypeRef] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "AccountTypeDetail":
        return cls(
            name=required_str(payload, "name"),
            display=optional_str(payload, "display"),
            group=optional_str(payload, "group"),
            show_for_synced_accounts=optional_bool(payload, "showForSyncedAccounts"),
            possible_subtypes=map_list(list_of_mappings(payload, "possibleSubtypes"), AccountSubtypeRef.from_api),
        )


@dataclass(slots=True)
class DisplayBalanceAccount(OutputModel):
    id: str
    display_balance: float | str | None = None
    include_in_net_worth: bool | None = None
    type_name: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "DisplayBalanceAccount":
        type_payload = optional_mapping(payload, "type") or {}
        return cls(
            id=required_str(payload, "id"),
            display_balance=payload.get("displayBalance"),
            include_in_net_worth=optional_bool(payload, "includeInNetWorth"),
            type_name=optional_str(type_payload, "name"),
        )


@dataclass(slots=True)
class SnapshotByAccountType(OutputModel):
    account_type: str
    month: str | None = None
    balance: float | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "SnapshotByAccountType":
        return cls(
            account_type=required_str(payload, "accountType"),
            month=optional_str(payload, "month"),
            balance=optional_float(payload, "balance"),
        )


@dataclass(slots=True)
class SnapshotsByAccountTypeResult(OutputModel):
    snapshots_by_account_type: list[SnapshotByAccountType] = field(default_factory=list)
    account_types: list[AccountTypeRef] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "SnapshotsByAccountTypeResult":
        return cls(
            snapshots_by_account_type=map_list(
                list_of_mappings(payload, "snapshotsByAccountType"),
                SnapshotByAccountType.from_api,
            ),
            account_types=map_list(list_of_mappings(payload, "accountTypes"), AccountTypeRef.from_api),
        )


@dataclass(slots=True)
class SnapshotsByAccountTypeRequest(InputModel):
    start_date: str = field(metadata={"api_name": "startDate"})
    timeframe: str = field(metadata={"api_name": "timeframe"})


@dataclass(slots=True)
class AccountFilter(InputModel):
    account_subtype: str | None = field(default=None, metadata={"api_name": "accountSubtype"})
    account_subtypes: list[str] | None = field(default=None, metadata={"api_name": "accountSubtypes"})
    account_type: str | None = field(default=None, metadata={"api_name": "accountType"})
    account_types: list[str] | None = field(default=None, metadata={"api_name": "accountTypes"})
    business_entity_set: BusinessEntitySetInput | None = field(default=None, metadata={"api_name": "businessEntitySet"})
    exclude_account_subtypes: list[str] | None = field(default=None, metadata={"api_name": "excludeAccountSubtypes"})
    exclude_account_types: list[str] | None = field(default=None, metadata={"api_name": "excludeAccountTypes"})
    groups: list[str] | None = None
    ids: list[str] | None = None
    ignore_hidden_from_net_worth: bool | None = field(default=None, metadata={"api_name": "ignoreHiddenFromNetWorth"})
    ignore_mapped_to_liability: bool | None = field(default=None, metadata={"api_name": "ignoreMappedToLiability"})
    include_deleted: bool | None = field(default=None, metadata={"api_name": "includeDeleted"})
    include_hidden: bool | None = field(default=None, metadata={"api_name": "includeHidden"})
    include_manual: bool | None = field(default=None, metadata={"api_name": "includeManual"})
    is_included_in_goal_contributions: bool | None = field(default=None, metadata={"api_name": "isIncludedInGoalContributions"})
    ownership_set: OwnershipSetInput | None = field(default=None, metadata={"api_name": "ownershipSet"})


@dataclass(slots=True)
class AggregateSnapshotFilter(InputModel):
    account_filters: AccountFilter | None = field(default=None, metadata={"api_name": "accountFilters"})
    account_type: str | None = field(default=None, metadata={"api_name": "accountType"})
    end_date: str | None = field(default=None, metadata={"api_name": "endDate"})
    start_date: str | None = field(default=None, metadata={"api_name": "startDate"})
    use_adaptive_granularity: bool | None = field(default=None, metadata={"api_name": "useAdaptiveGranularity"})


@dataclass(slots=True)
class ForceRefreshAccountRequest(InputModel):
    account_id: str = field(metadata={"api_name": "accountId"})
    source: str | None = None


@dataclass(slots=True)
class ForceRefreshAllAccountsRequest(InputModel):
    source: str | None = None


@dataclass(slots=True)
class ForceRefreshOperationAccount(OutputModel):
    account_id: str
    state: str | None = None
    new_transaction_count: int | None = None
    updated_transaction_count: int | None = None
    completed_at: str | None = None
    started_at: str | None = None
    timed_out: bool | None = None
    error_message: str | None = None
    error_detail: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "ForceRefreshOperationAccount":
        return cls(
            account_id=required_str(payload, "accountId"),
            state=optional_str(payload, "state"),
            new_transaction_count=optional_int(payload, "newTransactionCount"),
            updated_transaction_count=optional_int(payload, "updatedTransactionCount"),
            completed_at=optional_str(payload, "completedAt"),
            started_at=optional_str(payload, "startedAt"),
            timed_out=optional_bool(payload, "timedOut"),
            error_message=optional_str(payload, "errorMessage"),
            error_detail=optional_str(payload, "errorDetail"),
        )


@dataclass(slots=True)
class ForceRefreshOperation(OutputModel):
    id: str
    state: str | None = None
    completed_account_count: int | None = None
    total_account_count: int | None = None
    accounts: list[ForceRefreshOperationAccount] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "ForceRefreshOperation":
        return cls(
            id=required_str(payload, "id"),
            state=optional_str(payload, "state"),
            completed_account_count=optional_int(payload, "completedAccountCount"),
            total_account_count=optional_int(payload, "totalAccountCount"),
            accounts=map_list(list_of_mappings(payload, "accounts"), ForceRefreshOperationAccount.from_api),
        )


@dataclass(slots=True)
class ForceRefreshAccountStatus(OutputModel):
    id: str
    can_be_force_refreshed: bool | None = None
    has_sync_or_recent_refresh_request: bool | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "ForceRefreshAccountStatus":
        return cls(
            id=required_str(payload, "id"),
            can_be_force_refreshed=optional_bool(payload, "canBeForceRefreshed"),
            has_sync_or_recent_refresh_request=optional_bool(payload, "hasSyncOrRecentRefreshRequest"),
        )


@dataclass(slots=True)
class ForceRefreshResult(OutputModel):
    success: bool
    force_refresh_operation_id: str | None = None
    errors: list[PayloadError] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "ForceRefreshResult":
        return cls(
            success=bool(payload.get("success")),
            force_refresh_operation_id=optional_str(payload, "forceRefreshOperationId"),
            errors=map_list(list_of_mappings(payload, "errors"), PayloadError.from_api),
        )


@dataclass(slots=True)
class AccountListItem(OutputModel):
    id: str
    display_name: str | None = None
    display_balance: float | str | None = None
    signed_balance: float | None = None
    updated_at: str | None = None
    sync_disabled: bool | None = None
    icon: str | None = None
    logo_url: str | None = None
    is_hidden: bool | None = None
    is_asset: bool | None = None
    include_in_net_worth: bool | None = None
    include_balance_in_net_worth: bool | None = None
    display_last_updated_at: str | None = None
    mask: str | None = None
    type: AccountTypeRef | None = None
    subtype: AccountSubtypeRef | None = None
    credential: CredentialRef | None = None
    institution: InstitutionRef | None = None
    owned_by_user: UserRef | None = None
    business_entity: BusinessEntityRef | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "AccountListItem":
        return cls(
            id=required_str(payload, "id"),
            display_name=optional_str(payload, "displayName"),
            display_balance=payload.get("displayBalance"),
            signed_balance=optional_float(payload, "signedBalance"),
            updated_at=optional_str(payload, "updatedAt"),
            sync_disabled=optional_bool(payload, "syncDisabled"),
            icon=optional_str(payload, "icon"),
            logo_url=optional_str(payload, "logoUrl"),
            is_hidden=optional_bool(payload, "isHidden"),
            is_asset=optional_bool(payload, "isAsset"),
            include_in_net_worth=optional_bool(payload, "includeInNetWorth"),
            include_balance_in_net_worth=optional_bool(payload, "includeBalanceInNetWorth"),
            display_last_updated_at=optional_str(payload, "displayLastUpdatedAt"),
            mask=optional_str(payload, "mask"),
            type=AccountTypeRef.from_api(t) if (t := optional_mapping(payload, "type")) else None,
            subtype=AccountSubtypeRef.from_api(s) if (s := optional_mapping(payload, "subtype")) else None,
            credential=CredentialRef.from_api(c) if (c := optional_mapping(payload, "credential")) else None,
            institution=InstitutionRef.from_api(i) if (i := optional_mapping(payload, "institution")) else None,
            owned_by_user=UserRef.from_api(u) if (u := optional_mapping(payload, "ownedByUser")) else None,
            business_entity=BusinessEntityRef.from_api(b) if (b := optional_mapping(payload, "businessEntity")) else None,
        )


@dataclass(slots=True)
class FilteredAccount(OutputModel):
    id: str
    created_at: str | None = None
    display_name: str | None = None
    display_balance: float | str | None = None
    display_last_updated_at: str | None = None
    data_provider: str | None = None
    icon: str | None = None
    logo_url: str | None = None
    order: int | None = None
    is_asset: bool | None = None
    include_balance_in_net_worth: bool | None = None
    deactivated_at: str | None = None
    manual_investments_tracking_method: str | None = None
    is_manual: bool | None = None
    sync_disabled: bool | None = None
    type: AccountTypeRef | None = None
    credential: CredentialRef | None = None
    institution: InstitutionRef | None = None
    owned_by_user: UserRef | None = None
    business_entity: BusinessEntityRef | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "FilteredAccount":
        return cls(
            id=required_str(payload, "id"),
            created_at=optional_str(payload, "createdAt"),
            display_name=optional_str(payload, "displayName"),
            display_balance=payload.get("displayBalance"),
            display_last_updated_at=optional_str(payload, "displayLastUpdatedAt"),
            data_provider=optional_str(payload, "dataProvider"),
            icon=optional_str(payload, "icon"),
            logo_url=optional_str(payload, "logoUrl"),
            order=optional_int(payload, "order"),
            is_asset=optional_bool(payload, "isAsset"),
            include_balance_in_net_worth=optional_bool(payload, "includeBalanceInNetWorth"),
            deactivated_at=optional_str(payload, "deactivatedAt"),
            manual_investments_tracking_method=optional_str(payload, "manualInvestmentsTrackingMethod"),
            is_manual=optional_bool(payload, "isManual"),
            sync_disabled=optional_bool(payload, "syncDisabled"),
            type=AccountTypeRef.from_api(t) if (t := optional_mapping(payload, "type")) else None,
            credential=CredentialRef.from_api(c) if (c := optional_mapping(payload, "credential")) else None,
            institution=InstitutionRef.from_api(i) if (i := optional_mapping(payload, "institution")) else None,
            owned_by_user=UserRef.from_api(u) if (u := optional_mapping(payload, "ownedByUser")) else None,
            business_entity=BusinessEntityRef.from_api(b) if (b := optional_mapping(payload, "businessEntity")) else None,
        )


@dataclass(slots=True)
class RecentBalanceAccount(OutputModel):
    id: str
    recent_balances: list[float] = field(default_factory=list)
    type: AccountTypeRef | None = None
    include_in_net_worth: bool | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "RecentBalanceAccount":
        raw = payload.get("recentBalances")
        recent = [float(item) for item in raw if isinstance(item, (int, float)) and not isinstance(item, bool)] if isinstance(raw, list) else []
        return cls(
            id=required_str(payload, "id"),
            recent_balances=recent,
            type=AccountTypeRef.from_api(t) if (t := optional_mapping(payload, "type")) else None,
            include_in_net_worth=optional_bool(payload, "includeInNetWorth"),
        )


@dataclass(slots=True)
class AccountTypeSummary(OutputModel):
    type: AccountTypeRef
    accounts: list[AccountListItem] = field(default_factory=list)
    is_asset: bool | None = None
    total_display_balance: float | str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "AccountTypeSummary":
        return cls(
            type=AccountTypeRef.from_api(required_mapping(payload, "type")),
            accounts=map_list(list_of_mappings(payload, "accounts"), AccountListItem.from_api),
            is_asset=optional_bool(payload, "isAsset"),
            total_display_balance=payload.get("totalDisplayBalance"),
        )


@dataclass(slots=True)
class AccountsPage(OutputModel):
    has_accounts: bool
    account_type_summaries: list[AccountTypeSummary] = field(default_factory=list)
    household_preferences: HouseholdPreferences | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "AccountsPage":
        return cls(
            has_accounts=bool(payload.get("hasAccounts")),
            account_type_summaries=map_list(list_of_mappings(payload, "accountTypeSummaries"), AccountTypeSummary.from_api),
            household_preferences=HouseholdPreferences.from_api(p)
            if (p := optional_mapping(payload, "householdPreferences"))
            else None,
        )


@dataclass(slots=True)
class AccountFilterOptions(OutputModel):
    accounts: list[AccountRef] = field(default_factory=list)
    my_household_users: list[UserRef] = field(default_factory=list)
    household_preferences: HouseholdPreferences | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "AccountFilterOptions":
        my_household = optional_mapping(payload, "myHousehold") or {}
        return cls(
            accounts=map_list(list_of_mappings(payload, "accounts"), AccountRef.from_api),
            my_household_users=map_list(list_of_mappings(my_household, "users"), UserRef.from_api),
            household_preferences=HouseholdPreferences.from_api(p)
            if (p := optional_mapping(payload, "householdPreferences"))
            else None,
        )


@dataclass(slots=True)
class CredentialSettingsCard(OutputModel):
    id: str
    update_required: bool | None = None
    disconnected_from_data_provider_at: str | None = None
    sync_disabled_at: str | None = None
    sync_disabled_reason: str | None = None
    data_provider: str | None = None
    display_last_updated_at: str | None = None
    institution: InstitutionRef | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "CredentialSettingsCard":
        return cls(
            id=required_str(payload, "id"),
            update_required=optional_bool(payload, "updateRequired"),
            disconnected_from_data_provider_at=optional_str(payload, "disconnectedFromDataProviderAt"),
            sync_disabled_at=optional_str(payload, "syncDisabledAt"),
            sync_disabled_reason=optional_str(payload, "syncDisabledReason"),
            data_provider=optional_str(payload, "dataProvider"),
            display_last_updated_at=optional_str(payload, "displayLastUpdatedAt"),
            institution=InstitutionRef.from_api(i) if (i := optional_mapping(payload, "institution")) else None,
        )


@dataclass(slots=True)
class InstitutionSettingsAccount(OutputModel):
    id: str
    created_at: str | None = None
    display_name: str | None = None
    subtype: AccountSubtypeRef | None = None
    mask: str | None = None
    credential_id: str | None = None
    deleted_at: str | None = None
    hide_from_list: bool | None = None
    owned_by_user: UserRef | None = None
    display_last_updated_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "InstitutionSettingsAccount":
        return cls(
            id=required_str(payload, "id"),
            created_at=optional_str(payload, "createdAt"),
            display_name=optional_str(payload, "displayName"),
            subtype=AccountSubtypeRef.from_api(s) if (s := optional_mapping(payload, "subtype")) else None,
            mask=optional_str(payload, "mask"),
            credential_id=optional_str(optional_mapping(payload, "credential") or {}, "id"),
            deleted_at=optional_str(payload, "deletedAt"),
            hide_from_list=optional_bool(payload, "hideFromList"),
            owned_by_user=UserRef.from_api(u) if (u := optional_mapping(payload, "ownedByUser")) else None,
            display_last_updated_at=optional_str(payload, "displayLastUpdatedAt"),
            updated_at=optional_str(payload, "updatedAt"),
        )


@dataclass(slots=True)
class InstitutionSettings(OutputModel):
    credentials: list[CredentialSettingsCard] = field(default_factory=list)
    accounts: list[InstitutionSettingsAccount] = field(default_factory=list)
    has_premium_entitlement: bool | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "InstitutionSettings":
        subscription = optional_mapping(payload, "subscription") or {}
        return cls(
            credentials=map_list(list_of_mappings(payload, "credentials"), CredentialSettingsCard.from_api),
            accounts=map_list(list_of_mappings(payload, "accounts"), InstitutionSettingsAccount.from_api),
            has_premium_entitlement=optional_bool(subscription, "hasPremiumEntitlement"),
        )


@dataclass(slots=True)
class InstitutionMetadataData(OutputModel):
    id: str
    name: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "InstitutionMetadataData":
        return cls(
            id=required_str(payload, "id"),
            name=optional_str(payload, "name"),
        )


@dataclass(slots=True)
class InstitutionMetadata(OutputModel):
    id: str
    name: str | None = None
    type: str | None = None
    data: InstitutionMetadataData | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "InstitutionMetadata":
        data = optional_mapping(payload, "data")
        top_level_id = optional_str(payload, "id")
        if top_level_id is None:
            if data is None:
                raise KeyError("Institution metadata requires an id.")
            top_level_id = required_str(data, "id")
        return cls(
            id=top_level_id,
            name=optional_str(payload, "name") or optional_str(data or {}, "name"),
            type=optional_str(payload, "type"),
            data=InstitutionMetadataData.from_api(data) if data else None,
        )


@dataclass(slots=True)
class InstitutionMetadataList(OutputModel):
    type: str | None = None
    items: list[InstitutionMetadata] = field(default_factory=list)
    count: int | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "InstitutionMetadataList":
        return cls(
            type=optional_str(payload, "type"),
            items=map_list(list_of_mappings(payload, "items"), InstitutionMetadata.from_api),
            count=optional_int(payload, "count"),
        )
