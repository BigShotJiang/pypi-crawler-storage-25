from __future__ import annotations

from dataclasses import fields, is_dataclass
from enum import Enum
from typing import Any, Callable, Mapping


class _MissingType:
    pass


MISSING = _MissingType()


def expect_mapping(value: Any, *, context: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{context} must be a mapping, got {type(value).__name__}.")
    return value


def get_value(payload: Mapping[str, Any], *names: str, default: Any = MISSING) -> Any:
    for name in names:
        if name in payload:
            return payload[name]
    if default is not MISSING:
        return default
    joined = ", ".join(names)
    raise KeyError(f"Missing required field. Tried: {joined}")


def required_str(payload: Mapping[str, Any], *names: str) -> str:
    value = get_value(payload, *names)
    if not isinstance(value, str):
        joined = ", ".join(names)
        raise TypeError(f"{joined} must be a string.")
    return value


def required_bool(payload: Mapping[str, Any], *names: str) -> bool:
    value = get_value(payload, *names)
    if not isinstance(value, bool):
        joined = ", ".join(names)
        raise TypeError(f"{joined} must be a bool.")
    return value


def required_int(payload: Mapping[str, Any], *names: str) -> int:
    value = get_value(payload, *names)
    if not isinstance(value, int) or isinstance(value, bool):
        joined = ", ".join(names)
        raise TypeError(f"{joined} must be an int.")
    return value


def required_mapping(payload: Mapping[str, Any], *names: str) -> Mapping[str, Any]:
    value = get_value(payload, *names)
    return expect_mapping(value, context=", ".join(names))


def optional_str(payload: Mapping[str, Any], *names: str) -> str | None:
    value = get_value(payload, *names, default=None)
    if value is None:
        return None
    if not isinstance(value, str):
        joined = ", ".join(names)
        raise TypeError(f"{joined} must be a string when present.")
    return value


def optional_bool(payload: Mapping[str, Any], *names: str) -> bool | None:
    value = get_value(payload, *names, default=None)
    if value is None:
        return None
    if not isinstance(value, bool):
        joined = ", ".join(names)
        raise TypeError(f"{joined} must be a bool when present.")
    return value


def optional_int(payload: Mapping[str, Any], *names: str) -> int | None:
    value = get_value(payload, *names, default=None)
    if value is None:
        return None
    if not isinstance(value, int) or isinstance(value, bool):
        joined = ", ".join(names)
        raise TypeError(f"{joined} must be an int when present.")
    return value


def required_float(payload: Mapping[str, Any], *names: str) -> float:
    value = get_value(payload, *names)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        joined = ", ".join(names)
        raise TypeError(f"{joined} must be a number.")
    return float(value)


def optional_float(payload: Mapping[str, Any], *names: str) -> float | None:
    value = get_value(payload, *names, default=None)
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        joined = ", ".join(names)
        raise TypeError(f"{joined} must be a number when present.")
    return float(value)


def optional_mapping(payload: Mapping[str, Any], *names: str) -> Mapping[str, Any] | None:
    value = get_value(payload, *names, default=None)
    if value is None:
        return None
    return expect_mapping(value, context=", ".join(names))


def optional_list(payload: Mapping[str, Any], *names: str) -> list[Any] | None:
    value = get_value(payload, *names, default=None)
    if value is None:
        return None
    if not isinstance(value, list):
        joined = ", ".join(names)
        raise TypeError(f"{joined} must be a list when present.")
    return value


def list_of_mappings(payload: Mapping[str, Any], *names: str) -> list[Mapping[str, Any]]:
    values = optional_list(payload, *names)
    if values is None:
        return []
    return [expect_mapping(item, context=", ".join(names)) for item in values]


def map_list(values: list[Mapping[str, Any]], parser: Callable[[Mapping[str, Any]], Any]) -> list[Any]:
    return [parser(item) for item in values]


def optional_path(payload: Mapping[str, Any], *names: str) -> tuple[str | int, ...]:
    value = get_value(payload, *names, default=None)
    if value is None:
        return ()
    if not isinstance(value, list):
        joined = ", ".join(names)
        raise TypeError(f"{joined} must be a list when present.")
    normalized: list[str | int] = []
    for item in value:
        if isinstance(item, (str, int)) and not isinstance(item, bool):
            normalized.append(item)
            continue
        raise TypeError("GraphQL error paths may only contain strings or integers.")
    return tuple(normalized)


def serialize_value(value: Any, *, omit_none: bool, use_field_alias: bool) -> Any:
    if value is None:
        return None
    if isinstance(value, Enum):
        return value.value
    if is_dataclass(value):
        result: dict[str, Any] = {}
        for field in fields(value):
            name = field.metadata.get("api_name", field.name) if use_field_alias else field.name
            field_value = serialize_value(getattr(value, field.name), omit_none=omit_none, use_field_alias=use_field_alias)
            if omit_none and field_value is None:
                continue
            result[name] = field_value
        return result
    if isinstance(value, Mapping):
        result = {}
        for key, item in value.items():
            serialized = serialize_value(item, omit_none=omit_none, use_field_alias=use_field_alias)
            if omit_none and serialized is None:
                continue
            result[key] = serialized
        return result
    if isinstance(value, list):
        return [serialize_value(item, omit_none=omit_none, use_field_alias=use_field_alias) for item in value]
    if isinstance(value, tuple):
        return [serialize_value(item, omit_none=omit_none, use_field_alias=use_field_alias) for item in value]
    return value


class OutputModel:
    def to_dict(self) -> dict[str, Any]:
        return serialize_value(self, omit_none=False, use_field_alias=False)


class InputModel:
    def to_input(self, *, omit_none: bool = True) -> dict[str, Any]:
        return serialize_value(self, omit_none=omit_none, use_field_alias=True)
