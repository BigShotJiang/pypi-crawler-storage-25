from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from .base import (
    InputModel,
    OutputModel,
    expect_mapping,
    optional_bool,
    optional_int,
    optional_mapping,
    optional_path,
    optional_str,
    required_str,
)


@dataclass(slots=True)
class PayloadError(OutputModel):
    message: str
    code: str | None = None
    path: tuple[str | int, ...] = ()

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "PayloadError":
        payload = expect_mapping(payload, context="PayloadError")
        extensions = optional_mapping(payload, "extensions") or {}
        return cls(
            message=required_str(payload, "message"),
            code=optional_str(extensions, "code") or optional_str(payload, "code"),
            path=optional_path(payload, "path"),
        )


@dataclass(slots=True)
class OwnershipSetInput(InputModel):
    include_jointly_owned: bool = field(metadata={"api_name": "includeJointlyOwned"})
    user_ids: list[str] | None = field(default=None, metadata={"api_name": "userIds"})


@dataclass(slots=True)
class BusinessEntitySetInput(InputModel):
    include_unassigned: bool = field(metadata={"api_name": "includeUnassigned"})
    business_entity_ids: list[str] | None = field(default=None, metadata={"api_name": "businessEntityIds"})


@dataclass(slots=True)
class UserRef(OutputModel):
    id: str
    display_name: str | None = None
    name: str | None = None
    profile_picture_url: str | None = None
    email: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "UserRef":
        payload = expect_mapping(payload, context="UserRef")
        return cls(
            id=required_str(payload, "id"),
            display_name=optional_str(payload, "displayName", "display_name"),
            name=optional_str(payload, "name"),
            profile_picture_url=optional_str(payload, "profilePictureUrl", "profile_picture_url"),
            email=optional_str(payload, "email"),
        )


@dataclass(slots=True)
class HouseholdRef(OutputModel):
    id: str
    name: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "HouseholdRef":
        payload = expect_mapping(payload, context="HouseholdRef")
        return cls(
            id=required_str(payload, "id"),
            name=optional_str(payload, "name"),
        )


@dataclass(slots=True)
class BusinessEntityRef(OutputModel):
    id: str
    name: str | None = None
    logo_url: str | None = None
    color: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "BusinessEntityRef":
        payload = expect_mapping(payload, context="BusinessEntityRef")
        return cls(
            id=required_str(payload, "id"),
            name=optional_str(payload, "name"),
            logo_url=optional_str(payload, "logoUrl", "logo_url"),
            color=optional_str(payload, "color"),
        )


@dataclass(slots=True)
class CategoryGroupRef(OutputModel):
    id: str
    name: str
    order: int | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "CategoryGroupRef":
        payload = expect_mapping(payload, context="CategoryGroupRef")
        return cls(
            id=required_str(payload, "id"),
            name=required_str(payload, "name"),
            order=optional_int(payload, "order"),
        )


@dataclass(slots=True)
class CategoryRef(OutputModel):
    id: str
    name: str
    icon: str | None = None
    order: int | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "CategoryRef":
        payload = expect_mapping(payload, context="CategoryRef")
        return cls(
            id=required_str(payload, "id"),
            name=required_str(payload, "name"),
            icon=optional_str(payload, "icon"),
            order=optional_int(payload, "order"),
        )


@dataclass(slots=True)
class MerchantRef(OutputModel):
    name: str
    id: str | None = None
    logo_url: str | None = None
    transactions_count: int | None = None
    source: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "MerchantRef":
        payload = expect_mapping(payload, context="MerchantRef")
        return cls(
            id=optional_str(payload, "id"),
            name=required_str(payload, "name"),
            logo_url=optional_str(payload, "logoUrl", "logo_url"),
            transactions_count=optional_int(
                payload,
                "transactionsCount",
                "transactionCount",
                "transactions_count",
            ),
            source=optional_str(payload, "source"),
        )


@dataclass(slots=True)
class AccountRef(OutputModel):
    id: str
    display_name: str
    icon: str | None = None
    logo_url: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "AccountRef":
        payload = expect_mapping(payload, context="AccountRef")
        return cls(
            id=required_str(payload, "id"),
            display_name=required_str(payload, "displayName", "display_name"),
            icon=optional_str(payload, "icon"),
            logo_url=optional_str(payload, "logoUrl", "logo_url"),
        )


@dataclass(slots=True)
class AccountTypeRef(OutputModel):
    name: str
    display: str | None = None
    group: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "AccountTypeRef":
        payload = expect_mapping(payload, context="AccountTypeRef")
        return cls(
            name=required_str(payload, "name"),
            display=optional_str(payload, "display"),
            group=optional_str(payload, "group"),
        )


@dataclass(slots=True)
class AccountSubtypeRef(OutputModel):
    display: str | None = None
    name: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "AccountSubtypeRef":
        payload = expect_mapping(payload, context="AccountSubtypeRef")
        display = optional_str(payload, "display")
        name = optional_str(payload, "name")
        if display is None and name is None:
            raise ValueError("AccountSubtypeRef requires at least one of display or name.")
        return cls(display=display, name=name)


@dataclass(slots=True)
class TagRef(OutputModel):
    id: str
    name: str
    color: str | None = None
    order: int | None = None
    transaction_count: int | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "TagRef":
        payload = expect_mapping(payload, context="TagRef")
        return cls(
            id=required_str(payload, "id"),
            name=required_str(payload, "name"),
            color=optional_str(payload, "color"),
            order=optional_int(payload, "order"),
            transaction_count=optional_int(payload, "transactionCount"),
        )


@dataclass(slots=True)
class InstitutionRef(OutputModel):
    id: str | None = None
    name: str | None = None
    status: str | None = None
    balance_status: str | None = None
    transactions_status: str | None = None
    logo: str | None = None
    primary_color: str | None = None
    has_issues_reported: bool | None = None
    has_issues_reported_message: str | None = None
    new_connections_disabled: bool | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "InstitutionRef":
        payload = expect_mapping(payload, context="InstitutionRef")
        instance = cls(
            id=optional_str(payload, "id"),
            name=optional_str(payload, "name"),
            status=optional_str(payload, "status"),
            balance_status=optional_str(payload, "balanceStatus", "balance_status"),
            transactions_status=optional_str(payload, "transactionsStatus", "transactions_status"),
            logo=optional_str(payload, "logo"),
            primary_color=optional_str(payload, "primaryColor", "primary_color"),
            has_issues_reported=optional_bool(payload, "hasIssuesReported", "has_issues_reported"),
            has_issues_reported_message=optional_str(
                payload,
                "hasIssuesReportedMessage",
                "has_issues_reported_message",
            ),
            new_connections_disabled=optional_bool(
                payload,
                "newConnectionsDisabled",
                "new_connections_disabled",
            ),
        )
        if not any(value is not None for value in instance.to_dict().values()):
            raise ValueError("InstitutionRef payload did not contain any known fields.")
        return instance


@dataclass(slots=True)
class CredentialRef(OutputModel):
    id: str
    data_provider: str | None = None
    update_required: bool | None = None
    disconnected_from_data_provider_at: str | None = None
    sync_disabled_at: str | None = None
    sync_disabled_reason: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "CredentialRef":
        payload = expect_mapping(payload, context="CredentialRef")
        return cls(
            id=required_str(payload, "id"),
            data_provider=optional_str(payload, "dataProvider", "data_provider"),
            update_required=optional_bool(payload, "updateRequired", "update_required"),
            disconnected_from_data_provider_at=optional_str(
                payload,
                "disconnectedFromDataProviderAt",
                "disconnected_from_data_provider_at",
            ),
            sync_disabled_at=optional_str(payload, "syncDisabledAt", "sync_disabled_at"),
            sync_disabled_reason=optional_str(payload, "syncDisabledReason", "sync_disabled_reason"),
        )
