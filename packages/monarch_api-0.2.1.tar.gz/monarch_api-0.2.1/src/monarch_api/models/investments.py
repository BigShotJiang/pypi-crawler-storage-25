from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from .base import InputModel, OutputModel, list_of_mappings, map_list, optional_bool, optional_float, optional_int, optional_mapping, optional_str, required_mapping, required_str
from .shared import AccountRef, AccountSubtypeRef, AccountTypeRef, InstitutionRef


@dataclass(slots=True)
class PortfolioRequest(InputModel):
    start_date: str | None = field(default=None, metadata={"api_name": "startDate"})
    end_date: str | None = field(default=None, metadata={"api_name": "endDate"})


@dataclass(slots=True)
class SecurityHistoricalPerformanceRequest(InputModel):
    security_ids: list[str] = field(metadata={"api_name": "securityIds"})
    start_date: str = field(metadata={"api_name": "startDate"})
    end_date: str = field(metadata={"api_name": "endDate"})


@dataclass(slots=True)
class InvestmentAccount(OutputModel):
    id: str
    display_name: str
    is_taxable: bool | None = None
    icon: str | None = None
    order: int | None = None
    logo_url: str | None = None
    include_in_net_worth: bool | None = None
    sync_disabled: bool | None = None
    subtype: AccountSubtypeRef | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "InvestmentAccount":
        return cls(
            id=required_str(payload, "id"),
            display_name=required_str(payload, "displayName"),
            is_taxable=optional_bool(payload, "isTaxable"),
            icon=optional_str(payload, "icon"),
            order=optional_int(payload, "order"),
            logo_url=optional_str(payload, "logoUrl"),
            include_in_net_worth=optional_bool(payload, "includeInNetWorth"),
            sync_disabled=optional_bool(payload, "syncDisabled"),
            subtype=AccountSubtypeRef.from_api(s) if (s := optional_mapping(payload, "subtype")) else None,
        )


@dataclass(slots=True)
class TopMover(OutputModel):
    id: str
    name: str | None = None
    ticker: str | None = None
    one_day_change_percent: float | None = None
    current_price: float | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "TopMover":
        return cls(
            id=required_str(payload, "id"),
            name=optional_str(payload, "name"),
            ticker=optional_str(payload, "ticker"),
            one_day_change_percent=optional_float(payload, "oneDayChangePercent"),
            current_price=optional_float(payload, "currentPrice"),
        )


@dataclass(slots=True)
class PerformancePoint(OutputModel):
    date: str
    return_percent: float | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "PerformancePoint":
        return cls(
            date=required_str(payload, "date"),
            return_percent=optional_float(payload, "returnPercent"),
        )


@dataclass(slots=True)
class BenchmarkPerformance(OutputModel):
    security_id: str | None = None
    ticker: str | None = None
    name: str | None = None
    one_day_change_percent: float | None = None
    historical_chart: list[PerformancePoint] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "BenchmarkPerformance":
        security = optional_mapping(payload, "security") or {}
        return cls(
            security_id=optional_str(security, "id"),
            ticker=optional_str(security, "ticker"),
            name=optional_str(security, "name"),
            one_day_change_percent=optional_float(security, "oneDayChangePercent"),
            historical_chart=map_list(list_of_mappings(payload, "historicalChart"), PerformancePoint.from_api),
        )


@dataclass(slots=True)
class InvestmentPerformance(OutputModel):
    total_value: float | None = None
    total_change_percent: float | None = None
    total_change_dollars: float | None = None
    one_day_change_percent: float | None = None
    one_day_change_dollars: float | None = None
    historical_chart: list[PerformancePoint] = field(default_factory=list)
    benchmarks: list[BenchmarkPerformance] = field(default_factory=list)
    top_movers: list[TopMover] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "InvestmentPerformance":
        return cls(
            total_value=optional_float(payload, "totalValue"),
            total_change_percent=optional_float(payload, "totalChangePercent"),
            total_change_dollars=optional_float(payload, "totalChangeDollars"),
            one_day_change_percent=optional_float(payload, "oneDayChangePercent"),
            one_day_change_dollars=optional_float(payload, "oneDayChangeDollars"),
            historical_chart=map_list(list_of_mappings(payload, "historicalChart"), PerformancePoint.from_api),
            benchmarks=map_list(list_of_mappings(payload, "benchmarks"), BenchmarkPerformance.from_api),
            top_movers=map_list(list_of_mappings(payload, "topMovers"), TopMover.from_api),
        )


@dataclass(slots=True)
class InvestmentsDashboardCard(OutputModel):
    performance: InvestmentPerformance

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "InvestmentsDashboardCard":
        return cls(performance=InvestmentPerformance.from_api(required_mapping(required_mapping(payload, "portfolio"), "performance")))


@dataclass(slots=True)
class HoldingAccount(OutputModel):
    id: str
    mask: str | None = None
    icon: str | None = None
    logo_url: str | None = None
    institution: InstitutionRef | None = None
    type: AccountTypeRef | None = None
    subtype: AccountSubtypeRef | None = None
    display_name: str | None = None
    order: int | None = None
    current_balance: float | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "HoldingAccount":
        return cls(
            id=required_str(payload, "id"),
            mask=optional_str(payload, "mask"),
            icon=optional_str(payload, "icon"),
            logo_url=optional_str(payload, "logoUrl"),
            institution=InstitutionRef.from_api(i) if (i := optional_mapping(payload, "institution")) else None,
            type=AccountTypeRef.from_api(t) if (t := optional_mapping(payload, "type")) else None,
            subtype=AccountSubtypeRef.from_api(s) if (s := optional_mapping(payload, "subtype")) else None,
            display_name=optional_str(payload, "displayName"),
            order=optional_int(payload, "order"),
            current_balance=optional_float(payload, "currentBalance"),
        )


@dataclass(slots=True)
class TaxLot(OutputModel):
    id: str
    created_at: str | None = None
    acquisition_date: str | None = None
    acquisition_quantity: float | None = None
    cost_basis_per_unit: float | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "TaxLot":
        return cls(
            id=required_str(payload, "id"),
            created_at=optional_str(payload, "createdAt"),
            acquisition_date=optional_str(payload, "acquisitionDate"),
            acquisition_quantity=optional_float(payload, "acquisitionQuantity"),
            cost_basis_per_unit=optional_float(payload, "costBasisPerUnit"),
        )


@dataclass(slots=True)
class HoldingDetail(OutputModel):
    id: str
    type: str | None = None
    type_display: str | None = None
    name: str | None = None
    ticker: str | None = None
    closing_price: float | None = None
    closing_price_updated_at: str | None = None
    quantity: float | None = None
    value: float | None = None
    cost_basis: float | None = None
    user_cost_basis: float | None = None
    account: HoldingAccount | None = None
    tax_lots: list[TaxLot] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "HoldingDetail":
        return cls(
            id=required_str(payload, "id"),
            type=optional_str(payload, "type"),
            type_display=optional_str(payload, "typeDisplay"),
            name=optional_str(payload, "name"),
            ticker=optional_str(payload, "ticker"),
            closing_price=optional_float(payload, "closingPrice"),
            closing_price_updated_at=optional_str(payload, "closingPriceUpdatedAt"),
            quantity=optional_float(payload, "quantity"),
            value=optional_float(payload, "value"),
            cost_basis=optional_float(payload, "costBasis"),
            user_cost_basis=optional_float(payload, "userCostBasis"),
            account=HoldingAccount.from_api(a) if (a := optional_mapping(payload, "account")) else None,
            tax_lots=map_list(list_of_mappings(payload, "taxLots"), TaxLot.from_api),
        )


@dataclass(slots=True)
class AggregateHolding(OutputModel):
    id: str
    quantity: float | None = None
    cost_basis: float | None = None
    total_value: float | None = None
    security_price_change_dollars: float | None = None
    security_price_change_percent: float | None = None
    last_synced_at: str | None = None
    holdings: list[HoldingDetail] = field(default_factory=list)
    security_id: str | None = None
    security_name: str | None = None
    security_ticker: str | None = None
    current_price: float | None = None
    security_type: str | None = None
    security_type_display: str | None = None
    category_group: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "AggregateHolding":
        security = optional_mapping(payload, "security") or {}
        return cls(
            id=required_str(payload, "id"),
            quantity=optional_float(payload, "quantity"),
            cost_basis=optional_float(payload, "costBasis"),
            total_value=optional_float(payload, "totalValue"),
            security_price_change_dollars=optional_float(payload, "securityPriceChangeDollars"),
            security_price_change_percent=optional_float(payload, "securityPriceChangePercent"),
            last_synced_at=optional_str(payload, "lastSyncedAt"),
            holdings=map_list(list_of_mappings(payload, "holdings"), HoldingDetail.from_api),
            security_id=optional_str(security, "id"),
            security_name=optional_str(security, "name"),
            security_ticker=optional_str(security, "ticker"),
            current_price=optional_float(security, "currentPrice"),
            security_type=optional_str(security, "type"),
            security_type_display=optional_str(security, "typeDisplay"),
            category_group=optional_str(security, "categoryGroup"),
        )


@dataclass(slots=True)
class Portfolio(OutputModel):
    performance: InvestmentPerformance
    aggregate_holdings: list[AggregateHolding] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "Portfolio":
        aggregate_holdings_payload = optional_mapping(payload, "aggregateHoldings") or {}
        edges = list_of_mappings(aggregate_holdings_payload, "edges")
        nodes = [required_mapping(edge, "node") for edge in edges]
        return cls(
            performance=InvestmentPerformance.from_api(required_mapping(payload, "performance")),
            aggregate_holdings=map_list(nodes, AggregateHolding.from_api),
        )


@dataclass(slots=True)
class SecurityHistoricalPerformance(OutputModel):
    security_id: str
    historical_chart: list[PerformancePoint] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "SecurityHistoricalPerformance":
        return cls(
            security_id=required_str(required_mapping(payload, "security"), "id"),
            historical_chart=map_list(list_of_mappings(payload, "historicalChart"), PerformancePoint.from_api),
        )
