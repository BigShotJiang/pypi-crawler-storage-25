from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from .base import InputModel, OutputModel, list_of_mappings, map_list, optional_float, optional_int, optional_mapping, optional_str, required_mapping
from .shared import BusinessEntityRef, CategoryGroupRef, CategoryRef, MerchantRef
from .transactions import TransactionFilter


@dataclass(slots=True)
class CashFlowDayAggregate(OutputModel):
    day: str | None = None
    sum_expense: float | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "CashFlowDayAggregate":
        return cls(
            day=optional_str(optional_mapping(payload, "groupBy") or {}, "day"),
            sum_expense=optional_float(optional_mapping(payload, "summary") or {}, "sumExpense"),
        )


@dataclass(slots=True)
class CashFlowDashboardResult(OutputModel):
    by_day: list[CashFlowDayAggregate] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "CashFlowDashboardResult":
        return cls(by_day=map_list(list_of_mappings(payload, "byDay"), CashFlowDayAggregate.from_api))


@dataclass(slots=True)
class CashFlowSummary(OutputModel):
    sum_income: float | None = None
    sum_expense: float | None = None
    savings: float | None = None
    savings_rate: float | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "CashFlowSummary":
        return cls(
            sum_income=optional_float(payload, "sumIncome"),
            sum_expense=optional_float(payload, "sumExpense"),
            savings=optional_float(payload, "savings"),
            savings_rate=optional_float(payload, "savingsRate"),
        )


@dataclass(slots=True)
class CategoryAggregate(OutputModel):
    category: CategoryRef | None = None
    summary: CashFlowSummary | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "CategoryAggregate":
        group_by = optional_mapping(payload, "groupBy") or {}
        return cls(
            category=CategoryRef.from_api(c) if (c := optional_mapping(group_by, "category")) else None,
            summary=CashFlowSummary.from_api(s) if (s := optional_mapping(payload, "summary")) else None,
        )


@dataclass(slots=True)
class CategoryGroupAggregate(OutputModel):
    category_group: CategoryGroupRef | None = None
    summary: CashFlowSummary | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "CategoryGroupAggregate":
        group_by = optional_mapping(payload, "groupBy") or {}
        return cls(
            category_group=CategoryGroupRef.from_api(c) if (c := optional_mapping(group_by, "categoryGroup")) else None,
            summary=CashFlowSummary.from_api(s) if (s := optional_mapping(payload, "summary")) else None,
        )


@dataclass(slots=True)
class MerchantAggregate(OutputModel):
    merchant: MerchantRef | None = None
    summary: CashFlowSummary | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "MerchantAggregate":
        group_by = optional_mapping(payload, "groupBy") or {}
        return cls(
            merchant=MerchantRef.from_api(m) if (m := optional_mapping(group_by, "merchant")) else None,
            summary=CashFlowSummary.from_api(s) if (s := optional_mapping(payload, "summary")) else None,
        )


@dataclass(slots=True)
class CashFlowEntityAggregatesResult(OutputModel):
    by_category: list[CategoryAggregate] = field(default_factory=list)
    by_category_group: list[CategoryGroupAggregate] = field(default_factory=list)
    by_merchant: list[MerchantAggregate] = field(default_factory=list)
    summary: CashFlowSummary | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "CashFlowEntityAggregatesResult":
        summary_aggregate = optional_mapping(payload, "summary")
        return cls(
            by_category=map_list(list_of_mappings(payload, "byCategory"), CategoryAggregate.from_api),
            by_category_group=map_list(list_of_mappings(payload, "byCategoryGroup"), CategoryGroupAggregate.from_api),
            by_merchant=map_list(list_of_mappings(payload, "byMerchant"), MerchantAggregate.from_api),
            summary=CashFlowSummary.from_api(optional_mapping(summary_aggregate or {}, "summary") or {})
            if summary_aggregate
            else None,
        )


@dataclass(slots=True)
class TimeframeAggregate(OutputModel):
    period: str | None = None
    summary: CashFlowSummary | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any], field_name: str) -> "TimeframeAggregate":
        group_by = optional_mapping(payload, "groupBy") or {}
        return cls(
            period=optional_str(group_by, field_name),
            summary=CashFlowSummary.from_api(s) if (s := optional_mapping(payload, "summary")) else None,
        )


@dataclass(slots=True)
class CashFlowTimeframeAggregatesResult(OutputModel):
    by_year: list[TimeframeAggregate] = field(default_factory=list)
    by_month: list[TimeframeAggregate] = field(default_factory=list)
    by_quarter: list[TimeframeAggregate] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "CashFlowTimeframeAggregatesResult":
        return cls(
            by_year=[TimeframeAggregate.from_api(item, "year") for item in list_of_mappings(payload, "byYear")],
            by_month=[TimeframeAggregate.from_api(item, "month") for item in list_of_mappings(payload, "byMonth")],
            by_quarter=[TimeframeAggregate.from_api(item, "quarter") for item in list_of_mappings(payload, "byQuarter")],
        )


@dataclass(slots=True)
class ReportsSummary(OutputModel):
    sum: float | None = None
    avg: float | None = None
    count: int | None = None
    max: float | None = None
    sum_income: float | None = None
    sum_expense: float | None = None
    savings: float | None = None
    savings_rate: float | None = None
    first: float | None = None
    last: float | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "ReportsSummary":
        return cls(
            sum=optional_float(payload, "sum"),
            avg=optional_float(payload, "avg"),
            count=optional_int(payload, "count"),
            max=optional_float(payload, "max"),
            sum_income=optional_float(payload, "sumIncome"),
            sum_expense=optional_float(payload, "sumExpense"),
            savings=optional_float(payload, "savings"),
            savings_rate=optional_float(payload, "savingsRate"),
            first=optional_float(payload, "first"),
            last=optional_float(payload, "last"),
        )


@dataclass(slots=True)
class ReportsGroupByData(OutputModel):
    date: str | None = None
    category: CategoryRef | None = None
    category_group: CategoryGroupRef | None = None
    merchant: MerchantRef | None = None
    business_entity: BusinessEntityRef | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "ReportsGroupByData":
        return cls(
            date=optional_str(payload, "date"),
            category=CategoryRef.from_api(c) if (c := optional_mapping(payload, "category")) else None,
            category_group=CategoryGroupRef.from_api(cg) if (cg := optional_mapping(payload, "categoryGroup")) else None,
            merchant=MerchantRef.from_api(m) if (m := optional_mapping(payload, "merchant")) else None,
            business_entity=BusinessEntityRef.from_api(be) if (be := optional_mapping(payload, "businessEntity")) else None,
        )


@dataclass(slots=True)
class ReportsCollection(OutputModel):
    group_by: list[ReportsGroupByData] = field(default_factory=list)
    summary: ReportsSummary | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "ReportsCollection":
        return cls(
            group_by=map_list(list_of_mappings(payload, "groupBy"), ReportsGroupByData.from_api),
            summary=ReportsSummary.from_api(s) if (s := optional_mapping(payload, "summary")) else None,
        )


@dataclass(slots=True)
class ReportsDataResult(OutputModel):
    reports: ReportsCollection | None = None
    aggregates: ReportsSummary | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "ReportsDataResult":
        reports_obj = optional_mapping(payload, "reports")
        aggregates_obj = optional_mapping(payload, "aggregates") or {}
        return cls(
            reports=ReportsCollection.from_api(reports_obj) if reports_obj else None,
            aggregates=ReportsSummary.from_api(s) if (s := optional_mapping(aggregates_obj, "summary")) else None,
        )


@dataclass(slots=True)
class ReportsDataRequest(InputModel):
    filters: TransactionFilter
    group_by: list[str] | None = field(default=None, metadata={"api_name": "groupBy"})
    group_by_timeframe: str | None = field(default=None, metadata={"api_name": "groupByTimeframe"})
    sort_by: str | None = field(default=None, metadata={"api_name": "sortBy"})
    include_category: bool = field(default=False, metadata={"api_name": "includeCategory"})
    include_category_group: bool = field(default=False, metadata={"api_name": "includeCategoryGroup"})
    include_merchant: bool = field(default=False, metadata={"api_name": "includeMerchant"})
    include_business_entity: bool = field(default=False, metadata={"api_name": "includeBusinessEntity"})
    include_budget_variability: bool = field(default=False, metadata={"api_name": "includeBudgetVariability"})
    fill_empty_values: bool = field(default=True, metadata={"api_name": "fillEmptyValues"})
