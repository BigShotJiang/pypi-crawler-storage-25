from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from .base import InputModel, OutputModel, list_of_mappings, map_list, optional_bool, optional_float, optional_int, optional_mapping, optional_str, required_mapping, required_str
from .shared import AccountRef, CategoryRef, MerchantRef


@dataclass(slots=True)
class RecurringTransactionFilter(InputModel):
    is_completed: bool | None = field(default=None, metadata={"api_name": "isCompleted"})


@dataclass(slots=True)
class AggregatedRecurringItemsRequest(InputModel):
    start_date: str = field(metadata={"api_name": "startDate"})
    end_date: str = field(metadata={"api_name": "endDate"})
    filters: RecurringTransactionFilter | None = field(default=None, metadata={"api_name": "filters"})


@dataclass(slots=True)
class DashboardUpcomingRecurringItemsRequest(InputModel):
    start_date: str = field(metadata={"api_name": "startDate"})
    end_date: str = field(metadata={"api_name": "endDate"})
    include_liabilities: bool | None = field(default=None, metadata={"api_name": "includeLiabilities"})
    filters: RecurringTransactionFilter | None = field(default=None, metadata={"api_name": "filters"})


@dataclass(slots=True)
class RecurringStream(OutputModel):
    id: str
    review_status: str | None = None
    frequency: str | None = None
    amount: float | None = None
    base_date: str | None = None
    day_of_the_month: int | None = None
    is_approximate: bool | None = None
    name: str | None = None
    logo_url: str | None = None
    recurring_type: str | None = None
    merchant: MerchantRef | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "RecurringStream":
        return cls(
            id=required_str(payload, "id"),
            review_status=optional_str(payload, "reviewStatus"),
            frequency=optional_str(payload, "frequency"),
            amount=optional_float(payload, "amount"),
            base_date=optional_str(payload, "baseDate"),
            day_of_the_month=optional_int(payload, "dayOfTheMonth"),
            is_approximate=optional_bool(payload, "isApproximate"),
            name=optional_str(payload, "name"),
            logo_url=optional_str(payload, "logoUrl"),
            recurring_type=optional_str(payload, "recurringType"),
            merchant=MerchantRef.from_api(m) if (m := optional_mapping(payload, "merchant")) else None,
        )


@dataclass(slots=True)
class RecurringStreamEntry(OutputModel):
    stream: RecurringStream

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "RecurringStreamEntry":
        return cls(stream=RecurringStream.from_api(required_mapping(payload, "stream")))


@dataclass(slots=True)
class RecurringLiabilityItem(OutputModel):
    id: str
    minimum_payment_amount: float | None = None
    status: str | None = None
    remaining_balance: float | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "RecurringLiabilityItem":
        payments = optional_mapping(payload, "paymentsInformation") or {}
        return cls(
            id=required_str(payload, "id"),
            minimum_payment_amount=optional_float(payload, "minimumPaymentAmount"),
            status=optional_str(payments, "status"),
            remaining_balance=optional_float(payments, "remainingBalance"),
        )


@dataclass(slots=True)
class RecurringCalendarItem(OutputModel):
    stream: RecurringStream | None = None
    date: str | None = None
    is_past: bool | None = None
    is_late: bool | None = None
    marked_paid_at: str | None = None
    is_completed: bool | None = None
    transaction_id: str | None = None
    amount: float | None = None
    amount_diff: float | None = None
    is_amount_different_than_original: bool | None = None
    credit_report_liability_statement_id: str | None = None
    category: CategoryRef | None = None
    account: AccountRef | None = None
    liability_statement: RecurringLiabilityItem | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "RecurringCalendarItem":
        return cls(
            stream=RecurringStream.from_api(s) if (s := optional_mapping(payload, "stream")) else None,
            date=optional_str(payload, "date"),
            is_past=optional_bool(payload, "isPast"),
            is_late=optional_bool(payload, "isLate"),
            marked_paid_at=optional_str(payload, "markedPaidAt"),
            is_completed=optional_bool(payload, "isCompleted"),
            transaction_id=optional_str(payload, "transactionId"),
            amount=optional_float(payload, "amount"),
            amount_diff=optional_float(payload, "amountDiff"),
            is_amount_different_than_original=optional_bool(payload, "isAmountDifferentThanOriginal"),
            credit_report_liability_statement_id=optional_str(payload, "creditReportLiabilityStatementId"),
            category=CategoryRef.from_api(c) if (c := optional_mapping(payload, "category")) else None,
            account=AccountRef.from_api(a) if (a := optional_mapping(payload, "account")) else None,
            liability_statement=RecurringLiabilityItem.from_api(l)
            if (l := optional_mapping(payload, "liabilityStatement"))
            else None,
        )


@dataclass(slots=True)
class RecurringGroupSummaryTotal(OutputModel):
    total: float | None = None
    completed: float | None = None
    remaining: float | None = None
    count: int | None = None
    pending_amount_count: int | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "RecurringGroupSummaryTotal":
        return cls(
            total=optional_float(payload, "total"),
            completed=optional_float(payload, "completed"),
            remaining=optional_float(payload, "remaining"),
            count=optional_int(payload, "count"),
            pending_amount_count=optional_int(payload, "pendingAmountCount"),
        )


@dataclass(slots=True)
class AggregatedRecurringGroup(OutputModel):
    status: str | None = None
    results: list[RecurringCalendarItem] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "AggregatedRecurringGroup":
        group_by = optional_mapping(payload, "groupBy") or {}
        return cls(
            status=optional_str(group_by, "status"),
            results=map_list(list_of_mappings(payload, "results"), RecurringCalendarItem.from_api),
        )


@dataclass(slots=True)
class AggregatedRecurringItemsResult(OutputModel):
    groups: list[AggregatedRecurringGroup] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "AggregatedRecurringItemsResult":
        return cls(groups=map_list(list_of_mappings(payload, "groups"), AggregatedRecurringGroup.from_api))


@dataclass(slots=True)
class RecurringRemainingDue(OutputModel):
    amount: float | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "RecurringRemainingDue":
        return cls(amount=optional_float(payload, "amount"))


@dataclass(slots=True)
class RecurringUpcomingItem(OutputModel):
    stream: RecurringStream | None = None
    is_past: bool | None = None
    date: str | None = None
    amount: float | None = None
    account: AccountRef | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "RecurringUpcomingItem":
        return cls(
            stream=RecurringStream.from_api(s) if (s := optional_mapping(payload, "stream")) else None,
            is_past=optional_bool(payload, "isPast"),
            date=optional_str(payload, "date"),
            amount=optional_float(payload, "amount"),
            account=AccountRef.from_api(a) if (a := optional_mapping(payload, "account")) else None,
        )


@dataclass(slots=True)
class DashboardUpcomingRecurringItemsResult(OutputModel):
    recurring_remaining_due: RecurringRemainingDue | None = None
    recurring_transaction_items: list[RecurringUpcomingItem] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "DashboardUpcomingRecurringItemsResult":
        return cls(
            recurring_remaining_due=RecurringRemainingDue.from_api(r)
            if (r := optional_mapping(payload, "recurringRemainingDue"))
            else None,
            recurring_transaction_items=map_list(
                list_of_mappings(payload, "recurringTransactionItems"),
                RecurringUpcomingItem.from_api,
            ),
        )


@dataclass(slots=True)
class RecurringPausedBanner(OutputModel):
    is_bill_sync_tracking_enabled: bool | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "RecurringPausedBanner":
        spinwheel_user = optional_mapping(payload, "spinwheelUser") or {}
        return cls(is_bill_sync_tracking_enabled=optional_bool(spinwheel_user, "isBillSyncTrackingEnabled"))
