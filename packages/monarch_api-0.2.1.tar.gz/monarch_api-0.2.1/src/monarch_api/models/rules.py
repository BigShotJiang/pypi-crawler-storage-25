from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from .base import InputModel, OutputModel, list_of_mappings, map_list, optional_bool, optional_float, optional_int, optional_mapping, optional_str, required_mapping, required_str
from .shared import AccountRef, BusinessEntityRef, CategoryRef, MerchantRef, PayloadError, TagRef, UserRef
from .transactions import GoalRef


@dataclass(slots=True)
class MerchantCriterion(InputModel, OutputModel):
    operator: str
    value: str

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "MerchantCriterion":
        return cls(
            operator=required_str(payload, "operator"),
            value=required_str(payload, "value"),
        )


@dataclass(slots=True)
class DecimalRange(InputModel, OutputModel):
    lower: float
    upper: float

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "DecimalRange":
        return cls(
            lower=float(payload["lower"]),
            upper=float(payload["upper"]),
        )


@dataclass(slots=True)
class AmountCriteriaField(InputModel, OutputModel):
    is_expense: bool = field(metadata={"api_name": "isExpense"})
    operator: str
    value: float | None = None
    value_range: DecimalRange | None = field(default=None, metadata={"api_name": "valueRange"})

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "AmountCriteriaField":
        return cls(
            is_expense=bool(payload.get("isExpense")),
            operator=required_str(payload, "operator"),
            value=optional_float(payload, "value"),
            value_range=DecimalRange.from_api(v) if (v := optional_mapping(payload, "valueRange")) else None,
        )


@dataclass(slots=True)
class SplitTransactionsActionInfo(InputModel, OutputModel):
    amount: float
    business_entity_id: str | None = field(default=None, metadata={"api_name": "businessEntityId"})
    business_entity_is_unassigned: bool | None = field(default=None, metadata={"api_name": "businessEntityIsUnassigned"})
    category_id: str | None = field(default=None, metadata={"api_name": "categoryId"})
    goal_id: str | None = field(default=None, metadata={"api_name": "goalId"})
    hide_from_reports: bool | None = field(default=None, metadata={"api_name": "hideFromReports"})
    merchant_name: str | None = field(default=None, metadata={"api_name": "merchantName"})
    needs_review: bool | None = field(default=None, metadata={"api_name": "needsReview"})
    needs_review_by_user_id: str | None = field(default=None, metadata={"api_name": "needsReviewByUserId"})
    owner_is_joint: bool | None = field(default=None, metadata={"api_name": "ownerIsJoint"})
    owner_user_id: str | None = field(default=None, metadata={"api_name": "ownerUserId"})
    review_status: str | None = field(default=None, metadata={"api_name": "reviewStatus"})
    savings_goal_id: str | None = field(default=None, metadata={"api_name": "savingsGoalId"})
    tags: list[str] | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "SplitTransactionsActionInfo":
        raw_tags = payload.get("tags")
        tags = [item for item in raw_tags if isinstance(item, str)] if isinstance(raw_tags, list) else None
        return cls(
            amount=float(payload["amount"]),
            business_entity_id=optional_str(payload, "businessEntityId"),
            business_entity_is_unassigned=optional_bool(payload, "businessEntityIsUnassigned"),
            category_id=optional_str(payload, "categoryId"),
            goal_id=optional_str(payload, "goalId"),
            hide_from_reports=optional_bool(payload, "hideFromReports"),
            merchant_name=optional_str(payload, "merchantName"),
            needs_review=optional_bool(payload, "needsReview"),
            needs_review_by_user_id=optional_str(payload, "needsReviewByUserId"),
            owner_is_joint=optional_bool(payload, "ownerIsJoint"),
            owner_user_id=optional_str(payload, "ownerUserId"),
            review_status=optional_str(payload, "reviewStatus"),
            savings_goal_id=optional_str(payload, "savingsGoalId"),
            tags=tags,
        )


@dataclass(slots=True)
class SplitTransactionsAction(InputModel, OutputModel):
    splits_info: list[SplitTransactionsActionInfo] = field(metadata={"api_name": "splitsInfo"})
    amount_type: str | None = field(default=None, metadata={"api_name": "amountType"})

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "SplitTransactionsAction":
        return cls(
            splits_info=map_list(list_of_mappings(payload, "splitsInfo"), SplitTransactionsActionInfo.from_api),
            amount_type=optional_str(payload, "amountType"),
        )


@dataclass(slots=True, kw_only=True)
class TransactionRuleInputBase(InputModel):
    account_ids: list[str] | None = field(default=None, metadata={"api_name": "accountIds"})
    action_set_business_entity: str | None = field(default=None, metadata={"api_name": "actionSetBusinessEntity"})
    action_set_business_entity_is_unassigned: bool | None = field(default=None, metadata={"api_name": "actionSetBusinessEntityIsUnassigned"})
    action_set_owner: str | None = field(default=None, metadata={"api_name": "actionSetOwner"})
    action_set_owner_is_joint: bool | None = field(default=None, metadata={"api_name": "actionSetOwnerIsJoint"})
    add_tags_action: list[str] | None = field(default=None, metadata={"api_name": "addTagsAction"})
    amount_criteria: AmountCriteriaField | None = field(default=None, metadata={"api_name": "amountCriteria"})
    apply_to_existing_transactions: bool | None = field(default=None, metadata={"api_name": "applyToExistingTransactions"})
    category_ids: list[str] | None = field(default=None, metadata={"api_name": "categoryIds"})
    criteria_business_entity_ids: list[str] | None = field(default=None, metadata={"api_name": "criteriaBusinessEntityIds"})
    criteria_business_entity_is_unassigned: bool | None = field(default=None, metadata={"api_name": "criteriaBusinessEntityIsUnassigned"})
    criteria_owner_is_joint: bool | None = field(default=None, metadata={"api_name": "criteriaOwnerIsJoint"})
    criteria_owner_user_ids: list[str] | None = field(default=None, metadata={"api_name": "criteriaOwnerUserIds"})
    link_goal_action: str | None = field(default=None, metadata={"api_name": "linkGoalAction"})
    link_savings_goal_action: str | None = field(default=None, metadata={"api_name": "linkSavingsGoalAction"})
    merchant_criteria: list[MerchantCriterion] | None = field(default=None, metadata={"api_name": "merchantCriteria"})
    merchant_criteria_use_original_statement: bool | None = field(default=None, metadata={"api_name": "merchantCriteriaUseOriginalStatement"})
    merchant_name_criteria: list[MerchantCriterion] | None = field(default=None, metadata={"api_name": "merchantNameCriteria"})
    needs_review_by_user_action: str | None = field(default=None, metadata={"api_name": "needsReviewByUserAction"})
    original_statement_criteria: list[MerchantCriterion] | None = field(default=None, metadata={"api_name": "originalStatementCriteria"})
    review_status_action: str | None = field(default=None, metadata={"api_name": "reviewStatusAction"})
    send_notification_action: bool | None = field(default=None, metadata={"api_name": "sendNotificationAction"})
    set_category_action: str | None = field(default=None, metadata={"api_name": "setCategoryAction"})
    set_hide_from_reports_action: bool | None = field(default=None, metadata={"api_name": "setHideFromReportsAction"})
    set_merchant_action: str | None = field(default=None, metadata={"api_name": "setMerchantAction"})
    split_transactions_action: SplitTransactionsAction | None = field(default=None, metadata={"api_name": "splitTransactionsAction"})


@dataclass(slots=True, kw_only=True)
class CreateTransactionRuleRequest(TransactionRuleInputBase):
    pass


@dataclass(slots=True, kw_only=True)
class UpdateTransactionRuleRequest(TransactionRuleInputBase):
    id: str


@dataclass(slots=True, kw_only=True)
class TransactionRulePreviewRequest(TransactionRuleInputBase):
    pass


@dataclass(slots=True)
class TransactionRule(OutputModel):
    id: str
    order: int | None = None
    merchant_criteria_use_original_statement: bool | None = None
    merchant_criteria: list[MerchantCriterion] = field(default_factory=list)
    original_statement_criteria: list[MerchantCriterion] = field(default_factory=list)
    merchant_name_criteria: list[MerchantCriterion] = field(default_factory=list)
    amount_criteria: AmountCriteriaField | None = None
    category_ids: list[str] | None = None
    account_ids: list[str] | None = None
    categories: list[CategoryRef] = field(default_factory=list)
    accounts: list[AccountRef] = field(default_factory=list)
    criteria_owner_is_joint: bool | None = None
    criteria_owner_user_ids: list[str] | None = None
    criteria_owner_users: list[UserRef] = field(default_factory=list)
    criteria_business_entity_ids: list[str] | None = None
    criteria_business_entity_is_unassigned: bool | None = None
    set_merchant_action: MerchantRef | None = None
    set_category_action: CategoryRef | None = None
    add_tags_action: list[TagRef] = field(default_factory=list)
    link_goal_action: GoalRef | None = None
    link_savings_goal_action: GoalRef | None = None
    needs_review_by_user_action: UserRef | None = None
    unassign_needs_review_by_user_action: bool | None = None
    send_notification_action: bool | None = None
    set_hide_from_reports_action: bool | None = None
    review_status_action: str | None = None
    action_set_owner_is_joint: bool | None = None
    action_set_owner: UserRef | None = None
    action_set_business_entity: BusinessEntityRef | None = None
    action_set_business_entity_is_unassigned: bool | None = None
    recent_application_count: int | None = None
    last_applied_at: str | None = None
    split_transactions_action: SplitTransactionsAction | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "TransactionRule":
        raw_category_ids = payload.get("categoryIds")
        raw_account_ids = payload.get("accountIds")
        raw_owner_ids = payload.get("criteriaOwnerUserIds")
        raw_entity_ids = payload.get("criteriaBusinessEntityIds")
        return cls(
            id=required_str(payload, "id"),
            order=optional_int(payload, "order"),
            merchant_criteria_use_original_statement=optional_bool(payload, "merchantCriteriaUseOriginalStatement"),
            merchant_criteria=map_list(list_of_mappings(payload, "merchantCriteria"), MerchantCriterion.from_api),
            original_statement_criteria=map_list(list_of_mappings(payload, "originalStatementCriteria"), MerchantCriterion.from_api),
            merchant_name_criteria=map_list(list_of_mappings(payload, "merchantNameCriteria"), MerchantCriterion.from_api),
            amount_criteria=AmountCriteriaField.from_api(a) if (a := optional_mapping(payload, "amountCriteria")) else None,
            category_ids=[item for item in raw_category_ids if isinstance(item, str)] if isinstance(raw_category_ids, list) else None,
            account_ids=[item for item in raw_account_ids if isinstance(item, str)] if isinstance(raw_account_ids, list) else None,
            categories=map_list(list_of_mappings(payload, "categories"), CategoryRef.from_api),
            accounts=map_list(list_of_mappings(payload, "accounts"), AccountRef.from_api),
            criteria_owner_is_joint=optional_bool(payload, "criteriaOwnerIsJoint"),
            criteria_owner_user_ids=[item for item in raw_owner_ids if isinstance(item, str)] if isinstance(raw_owner_ids, list) else None,
            criteria_owner_users=map_list(list_of_mappings(payload, "criteriaOwnerUsers"), UserRef.from_api),
            criteria_business_entity_ids=[item for item in raw_entity_ids if isinstance(item, str)] if isinstance(raw_entity_ids, list) else None,
            criteria_business_entity_is_unassigned=optional_bool(payload, "criteriaBusinessEntityIsUnassigned"),
            set_merchant_action=MerchantRef.from_api(m) if (m := optional_mapping(payload, "setMerchantAction")) else None,
            set_category_action=CategoryRef.from_api(c) if (c := optional_mapping(payload, "setCategoryAction")) else None,
            add_tags_action=map_list(list_of_mappings(payload, "addTagsAction"), TagRef.from_api),
            link_goal_action=GoalRef.from_api(g) if (g := optional_mapping(payload, "linkGoalAction")) else None,
            link_savings_goal_action=GoalRef.from_api(g) if (g := optional_mapping(payload, "linkSavingsGoalAction")) else None,
            needs_review_by_user_action=UserRef.from_api(u) if (u := optional_mapping(payload, "needsReviewByUserAction")) else None,
            unassign_needs_review_by_user_action=optional_bool(payload, "unassignNeedsReviewByUserAction"),
            send_notification_action=optional_bool(payload, "sendNotificationAction"),
            set_hide_from_reports_action=optional_bool(payload, "setHideFromReportsAction"),
            review_status_action=optional_str(payload, "reviewStatusAction"),
            action_set_owner_is_joint=optional_bool(payload, "actionSetOwnerIsJoint"),
            action_set_owner=UserRef.from_api(u) if (u := optional_mapping(payload, "actionSetOwner")) else None,
            action_set_business_entity=BusinessEntityRef.from_api(b)
            if (b := optional_mapping(payload, "actionSetBusinessEntity"))
            else None,
            action_set_business_entity_is_unassigned=optional_bool(payload, "actionSetBusinessEntityIsUnassigned"),
            recent_application_count=optional_int(payload, "recentApplicationCount"),
            last_applied_at=optional_str(payload, "lastAppliedAt"),
            split_transactions_action=SplitTransactionsAction.from_api(s)
            if (s := optional_mapping(payload, "splitTransactionsAction"))
            else None,
        )


@dataclass(slots=True)
class TransactionRuleMutationResult(OutputModel):
    errors: list[PayloadError] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "TransactionRuleMutationResult":
        return cls(errors=map_list(list_of_mappings(payload, "errors"), PayloadError.from_api))


@dataclass(slots=True)
class DeleteTransactionRuleResult(OutputModel):
    deleted: bool = False
    errors: list[PayloadError] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "DeleteTransactionRuleResult":
        return cls(
            deleted=bool(payload.get("deleted")),
            errors=map_list(list_of_mappings(payload, "errors"), PayloadError.from_api),
        )


@dataclass(slots=True)
class TransactionRulePreviewTransaction(OutputModel):
    id: str
    date: str | None = None
    amount: float | None = None
    merchant: MerchantRef | None = None
    category: CategoryRef | None = None
    owned_by_user: UserRef | None = None
    business_entity: BusinessEntityRef | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "TransactionRulePreviewTransaction":
        return cls(
            id=required_str(payload, "id"),
            date=optional_str(payload, "date"),
            amount=optional_float(payload, "amount"),
            merchant=MerchantRef.from_api(m) if (m := optional_mapping(payload, "merchant")) else None,
            category=CategoryRef.from_api(c) if (c := optional_mapping(payload, "category")) else None,
            owned_by_user=UserRef.from_api(u) if (u := optional_mapping(payload, "ownedByUser")) else None,
            business_entity=BusinessEntityRef.from_api(b) if (b := optional_mapping(payload, "businessEntity")) else None,
        )


@dataclass(slots=True)
class TransactionRulePreviewMatch(OutputModel):
    transaction: TransactionRulePreviewTransaction
    new_name: str | None = None
    new_split_transactions: bool | None = None
    new_category: CategoryRef | None = None
    new_owner_is_joint: bool | None = None
    new_owner_user: UserRef | None = None
    new_hide_from_reports: bool | None = None
    new_tags: list[TagRef] = field(default_factory=list)
    new_goal: GoalRef | None = None
    new_business_entity: BusinessEntityRef | None = None
    new_business_entity_is_unassigned: bool | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "TransactionRulePreviewMatch":
        return cls(
            transaction=TransactionRulePreviewTransaction.from_api(required_mapping(payload, "transaction")),
            new_name=optional_str(payload, "newName"),
            new_split_transactions=optional_bool(payload, "newSplitTransactions"),
            new_category=CategoryRef.from_api(c) if (c := optional_mapping(payload, "newCategory")) else None,
            new_owner_is_joint=optional_bool(payload, "newOwnerIsJoint"),
            new_owner_user=UserRef.from_api(u) if (u := optional_mapping(payload, "newOwnerUser")) else None,
            new_hide_from_reports=optional_bool(payload, "newHideFromReports"),
            new_tags=map_list(list_of_mappings(payload, "newTags"), TagRef.from_api),
            new_goal=GoalRef.from_api(g) if (g := optional_mapping(payload, "newGoal")) else None,
            new_business_entity=BusinessEntityRef.from_api(b) if (b := optional_mapping(payload, "newBusinessEntity")) else None,
            new_business_entity_is_unassigned=optional_bool(payload, "newBusinessEntityIsUnassigned"),
        )


@dataclass(slots=True)
class TransactionRulePreviewResult(OutputModel):
    total_count: int | None = None
    results: list[TransactionRulePreviewMatch] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "TransactionRulePreviewResult":
        return cls(
            total_count=optional_int(payload, "totalCount"),
            results=map_list(list_of_mappings(payload, "results"), TransactionRulePreviewMatch.from_api),
        )


@dataclass(slots=True)
class UpdateTransactionRuleOrderResult(OutputModel):
    transaction_rules: list[TransactionRule] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "UpdateTransactionRuleOrderResult":
        return cls(
            transaction_rules=map_list(list_of_mappings(payload, "transactionRules"), TransactionRule.from_api),
        )


@dataclass(slots=True)
class DeleteAllTransactionRulesResult(OutputModel):
    deleted: bool = False

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "DeleteAllTransactionRulesResult":
        return cls(deleted=bool(payload.get("deleted")))
