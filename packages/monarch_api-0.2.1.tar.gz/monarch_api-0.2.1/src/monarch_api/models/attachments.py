from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from .base import InputModel, OutputModel, list_of_mappings, map_list, optional_int, optional_mapping, optional_str, required_mapping, required_str
from .shared import PayloadError
from .transactions import TransactionAttachmentRef


@dataclass(slots=True)
class AttachmentUploadRequestParams(OutputModel):
    timestamp: str | None = None
    folder: str | None = None
    signature: str | None = None
    api_key: str | None = None
    upload_preset: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "AttachmentUploadRequestParams":
        return cls(
            timestamp=optional_str(payload, "timestamp"),
            folder=optional_str(payload, "folder"),
            signature=optional_str(payload, "signature"),
            api_key=optional_str(payload, "api_key"),
            upload_preset=optional_str(payload, "upload_preset"),
        )


@dataclass(slots=True)
class AttachmentUploadInfo(OutputModel):
    path: str | None = None
    request_params: AttachmentUploadRequestParams | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "AttachmentUploadInfo":
        info = required_mapping(payload, "info")
        return cls(
            path=optional_str(info, "path"),
            request_params=AttachmentUploadRequestParams.from_api(p)
            if (p := optional_mapping(info, "requestParams"))
            else None,
        )


@dataclass(slots=True)
class AttachmentDetail(OutputModel):
    id: str
    original_asset_url: str | None = None

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "AttachmentDetail":
        return cls(
            id=required_str(payload, "id"),
            original_asset_url=optional_str(payload, "originalAssetUrl"),
        )


@dataclass(slots=True)
class AddTransactionAttachmentRequest(InputModel):
    extension: str
    filename: str
    public_id: str = field(metadata={"api_name": "publicId"})
    size_bytes: int = field(metadata={"api_name": "sizeBytes"})
    transaction_id: str = field(metadata={"api_name": "transactionId"})


@dataclass(slots=True)
class AddTransactionAttachmentResult(OutputModel):
    attachment: TransactionAttachmentRef | None = None
    errors: list[PayloadError] = field(default_factory=list)

    @classmethod
    def from_api(cls, payload: Mapping[str, Any]) -> "AddTransactionAttachmentResult":
        return cls(
            attachment=TransactionAttachmentRef.from_api(a) if (a := optional_mapping(payload, "attachment")) else None,
            errors=map_list(list_of_mappings(payload, "errors"), PayloadError.from_api),
        )
