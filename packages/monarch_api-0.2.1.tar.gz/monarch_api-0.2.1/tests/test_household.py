from __future__ import annotations

import json

import httpx

from monarch_api import MonarchClient


def test_household_get_uses_expected_operation() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_GetMyHousehold"
        assert payload["variables"] == {}
        return httpx.Response(
            200,
            json={"data": {"myHousehold": {"id": "household-1", "name": "Rubsteins"}}},
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.household.get()
    assert payload.name == "Rubsteins"


def test_household_preferences_returns_query_payload() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_GetHouseholdPreferences"
        assert "HouseholdPreferencesFields" in payload["query"]
        return httpx.Response(
            200,
            json={
                "data": {
                    "householdPreferences": {"id": "prefs-1", "accountGroupOrder": "manual"},
                    "budgetSystem": "categories",
                    "budgetApplyToFutureMonthsDefault": True,
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.household.preferences()
    assert payload.household_preferences.id == "prefs-1"
