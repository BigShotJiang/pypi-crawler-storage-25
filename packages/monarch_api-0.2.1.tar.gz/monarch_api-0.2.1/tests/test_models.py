from __future__ import annotations

from dataclasses import dataclass, field

from monarch_api.models import (
    AccountRef,
    CredentialRef,
    InputModel,
    InstitutionRef,
    MonarchSession,
    PayloadError,
    UserRef,
)


def test_monarch_session_import_and_login_response_parser() -> None:
    session = MonarchSession.from_login_response(
        {
            "token": "token-123",
            "id": "user-1",
            "email": "user@example.com",
            "display_name": "User",
            "household": {"id": "household-1"},
        },
        device_uuid="device-1",
    )

    assert session.token == "token-123"
    assert session.user_id == "user-1"
    assert session.display_name == "User"
    assert session.household_id == "household-1"
    assert session.device_uuid == "device-1"


def test_shared_refs_parse_graphql_style_payloads() -> None:
    user = UserRef.from_api(
        {
            "id": "user-1",
            "displayName": "Erik",
            "name": "Erik Rubstein",
            "profilePictureUrl": "https://example.com/avatar.png",
        }
    )
    account = AccountRef.from_api(
        {
            "id": "account-1",
            "displayName": "Checking",
            "icon": "dollar-sign",
            "logoUrl": "https://example.com/logo.png",
        }
    )
    institution = InstitutionRef.from_api(
        {
            "id": "institution-1",
            "status": "HEALTHY",
            "newConnectionsDisabled": False,
        }
    )
    credential = CredentialRef.from_api(
        {
            "id": "credential-1",
            "dataProvider": "plaid",
            "updateRequired": True,
            "syncDisabledReason": "reauth_required",
        }
    )

    assert user.display_name == "Erik"
    assert account.display_name == "Checking"
    assert institution.status == "HEALTHY"
    assert credential.update_required is True


def test_payload_error_from_graphql_error_shape() -> None:
    error = PayloadError.from_api(
        {
            "message": "Bad request",
            "path": ["query", "transactions", 0],
            "extensions": {"code": "BAD_USER_INPUT"},
        }
    )

    assert error.message == "Bad request"
    assert error.code == "BAD_USER_INPUT"
    assert error.path == ("query", "transactions", 0)


def test_input_model_serializes_with_aliases_and_omits_none() -> None:
    @dataclass(slots=True)
    class Child(InputModel):
        value: str = field(metadata={"api_name": "childValue"})
        ignored: str | None = None

    @dataclass(slots=True)
    class Example(InputModel):
        account_id: str = field(metadata={"api_name": "accountId"})
        child: Child
        optional_value: str | None = field(default=None, metadata={"api_name": "optionalValue"})

    payload = Example(account_id="account-1", child=Child(value="ok")).to_input()

    assert payload == {
        "accountId": "account-1",
        "child": {"childValue": "ok"},
    }
