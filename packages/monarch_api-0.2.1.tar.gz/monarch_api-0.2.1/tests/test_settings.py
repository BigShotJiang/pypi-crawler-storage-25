from __future__ import annotations

import json

import httpx

from monarch_api import MonarchClient


def test_settings_user_profile_flags_and_dashboard_config_use_expected_operations() -> None:
    responses = {
        "Common_UserProfileFlags": {"data": {"userProfile": {"id": "profile-1", "hasReviewedSpending": True}}},
        "GetDashboardConfig": {
            "data": {
                "myHousehold": {
                    "id": "house-1",
                    "preferences": {"dashboardConfig": {"web": {"layout": ["a"], "widgets": ["b"]}}},
                }
            }
        },
    }

    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["variables"] == {}
        return httpx.Response(200, json=responses[payload["operationName"]])

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    assert client.settings.user_profile_flags().has_reviewed_spending is True
    assert client.settings.dashboard_config().dashboard_config is not None
    assert client.settings.dashboard_config().dashboard_config.web is not None
    assert client.settings.dashboard_config().dashboard_config.web.layout == ["a"]


def test_settings_sidebar_data_and_household_member_settings_use_expected_variables() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        if payload["operationName"] == "Web_GetSidebarData":
            assert payload["variables"] == {"promoCode": "SPRING"}
            return httpx.Response(
                200,
                json={"data": {"me": {"id": "user-1"}, "subscription": {"id": "sub-1"}, "subscriptionOffering": {}}},
            )
        assert payload["operationName"] == "Common_GetHouseHoldMemberSettings"
        assert payload["variables"] == {}
        return httpx.Response(
            200,
            json={"data": {"me": {"id": "user-1"}, "myHousehold": {"id": "house-1"}, "householdInvites": []}},
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    assert client.settings.sidebar_data(promo_code="SPRING").subscription.id == "sub-1"
    assert client.settings.household_member_settings().my_household.id == "house-1"


def test_settings_security_and_notification_queries_return_expected_shapes() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        if payload["operationName"] == "Web_GetSecuritySettings":
            assert payload["variables"] == {}
            return httpx.Response(
                200,
                json={"data": {"me": {"id": "user-1", "hasMfaOn": True}, "userDiscordData": {"username": "cg"}}},
            )
        assert payload["operationName"] == "Common_GetNotificationPreferences"
        assert payload["variables"] == {}
        return httpx.Response(
            200,
            json={"data": {"notificationPreferences": [{"id": "notif-1", "group": "weekly_review"}]}},
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    assert client.settings.security_settings().me.has_mfa_on is True
    assert client.settings.notification_preferences()[0].id == "notif-1"


def test_settings_business_entity_and_review_queries_use_expected_operations() -> None:
    responses = {
        "Common_GetBusinessEntities": {"data": {"businessEntities": [{"id": "be-1", "name": "SolaSec"}]}},
        "Common_GetBusinessEntitiesBannerProfile": {
            "data": {"me": {"profile": {"id": "profile-1", "shouldShowBusinessEntitiesBanner": True}}}
        },
        "Common_GetReviewSummaryByUser": {
            "data": {"byNeedsReviewByUser": [{"groupBy": {"needsReviewByUser": {"id": "user-1"}}, "summary": {"count": 2}}]}
        },
        "Common_HasActivity": {"data": {"me": {"id": "user-1", "hasNewActivity": True}}},
    }

    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["variables"] == {}
        return httpx.Response(200, json=responses[payload["operationName"]])

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    assert client.settings.business_entities()[0].name == "SolaSec"
    banner = client.settings.business_entities_banner_profile()
    assert banner is not None
    assert banner.should_show_business_entities_banner is True
    assert client.settings.review_summary_by_user()[0].count == 2
    assert client.settings.has_activity().has_new_activity is True


def test_settings_oldest_deletable_dates_use_expected_variables() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        if payload["operationName"] == "OldestDeletableSyncedSnapshotDate":
            assert payload["variables"] == {}
            return httpx.Response(200, json={"data": {"oldestDeletableSyncedSnapshotDate": "2024-01-01"}})
        assert payload["operationName"] == "Common_OldestDeletableTransactionDate"
        assert payload["variables"] == {
            "includeSynced": True,
            "includeUploaded": True,
            "includeManual": True,
        }
        return httpx.Response(200, json={"data": {"oldestDeletableTransactionDate": "2023-01-01"}})

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    assert client.settings.oldest_deletable_synced_snapshot_date() == "2024-01-01"
    assert (
        client.settings.oldest_deletable_transaction_date(
            include_synced=True,
            include_uploaded=True,
            include_manual=True,
        )
        == "2023-01-01"
    )
