from __future__ import annotations

import json

import httpx

from monarch_api import MonarchClient
from monarch_api.models import (
    AddTransactionAttachmentRequest,
    CreateBulkRetailSyncRequest,
    CreateRetailSyncRequest,
    UpdateMerchantRequest,
    UpdateRecurrenceFieldsInput,
)


def test_attachments_add_uses_typed_request() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_AddTransactionAttachment"
        assert payload["variables"] == {
            "input": {
                "extension": "jpg",
                "filename": "receipt.jpg",
                "publicId": "public-1",
                "sizeBytes": 1234,
                "transactionId": "txn-1",
            }
        }
        return httpx.Response(
            200,
            json={
                "data": {
                    "addTransactionAttachment": {
                        "attachment": {"id": "attachment-1", "filename": "receipt.jpg"},
                        "errors": [],
                    }
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.attachments.add(
        AddTransactionAttachmentRequest(
            extension="jpg",
            filename="receipt.jpg",
            public_id="public-1",
            size_bytes=1234,
            transaction_id="txn-1",
        )
    )
    assert payload.attachment is not None
    assert payload.attachment.id == "attachment-1"


def test_merchants_update_uses_typed_request() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_UpdateMerchant"
        assert payload["variables"] == {
            "input": {
                "merchantId": "merchant-1",
                "name": "Cash Wise",
                "recurrence": {
                    "isRecurring": True,
                    "amount": 24.51,
                    "isActive": True,
                },
            }
        }
        return httpx.Response(
            200,
            json={
                "data": {
                    "updateMerchant": {
                        "merchant": {
                            "id": "merchant-1",
                            "name": "Cash Wise",
                            "recurringTransactionStream": {"id": "stream-1", "amount": 24.51, "isActive": True},
                        },
                        "errors": [],
                    }
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.merchants.update(
        UpdateMerchantRequest(
            merchant_id="merchant-1",
            name="Cash Wise",
            recurrence=UpdateRecurrenceFieldsInput(is_recurring=True, amount=24.51, is_active=True),
        )
    )
    assert payload.merchant is not None
    assert payload.merchant.id == "merchant-1"


def test_retail_sync_create_requests_use_typed_models() -> None:
    expected_operations = [
        ("Common_CreateRetailSync", {"input": {"vendor": "amazon", "isBackfill": True}}),
        ("Common_CreateBulkRetailSync", {"input": {"count": 2}}),
    ]
    call_index = {"value": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        idx = call_index["value"]
        call_index["value"] += 1
        payload = json.loads(request.content.decode("utf-8"))
        expected_operation, expected_variables = expected_operations[idx]
        assert payload["operationName"] == expected_operation
        assert payload["variables"] == expected_variables
        if expected_operation == "Common_CreateRetailSync":
            return httpx.Response(
                200,
                json={"data": {"createRetailSync": {"retailSync": {"id": "sync-1", "vendor": "amazon"}, "errors": []}}},
            )
        return httpx.Response(
            200,
            json={"data": {"createBulkRetailSync": {"retailSyncs": [{"id": "sync-2"}], "errors": []}}},
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    created = client.retail_sync.create(CreateRetailSyncRequest(vendor="amazon", is_backfill=True))
    bulk = client.retail_sync.create_bulk(CreateBulkRetailSyncRequest(count=2))

    assert created.retail_sync is not None
    assert created.retail_sync.id == "sync-1"
    assert bulk.retail_syncs[0].id == "sync-2"
