from __future__ import annotations

import json

import httpx

from monarch_api import MonarchClient
from monarch_api.models import CreateTransactionRequest, TransactionFilter, UpdateTransactionRequest


def test_transactions_list_sends_expected_operation_name() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/graphql"
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Web_GetTransactionsList"
        assert payload["variables"]["limit"] == 10
        assert request.headers["Authorization"] == "Token token-123"
        return httpx.Response(
            200,
            json={
                "data": {
                    "allTransactions": {
                        "totalCount": 1,
                        "totalSelectableCount": 1,
                        "results": [{"id": "txn-1", "amount": 100}],
                    },
                    "transactionRules": [{"id": "rule-1"}],
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.transactions.list(limit=10)
    assert payload.results[0].id == "txn-1"


def test_transaction_delete_wraps_input_shape() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_DeleteTransactionMutation"
        assert payload["variables"] == {"input": {"transactionId": "txn-1"}}
        return httpx.Response(
            200,
            json={"data": {"deleteTransaction": {"deleted": True, "errors": []}}},
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.transactions.delete("txn-1")
    assert payload.deleted is True


def test_transaction_create_uses_typed_request() -> None:
    request = CreateTransactionRequest(
        account_id="account-1",
        amount=24.51,
        category_id="category-1",
        date="2026-04-12",
        merchant_name="Coffee Shop",
        notes="typed",
    )

    def handler(request_obj: httpx.Request) -> httpx.Response:
        payload = json.loads(request_obj.content.decode("utf-8"))
        assert payload["operationName"] == "Common_CreateTransactionMutation"
        assert payload["variables"] == {
            "input": {
                "accountId": "account-1",
                "amount": 24.51,
                "categoryId": "category-1",
                "date": "2026-04-12",
                "merchantName": "Coffee Shop",
                "notes": "typed",
            }
        }
        return httpx.Response(
            200,
            json={"data": {"createTransaction": {"transaction": {"id": "txn-1"}, "errors": []}}},
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.transactions.create(request)
    assert payload.transaction is not None
    assert payload.transaction.id == "txn-1"


def test_transaction_update_uses_typed_request() -> None:
    request = UpdateTransactionRequest(id="txn-1", name="Renamed", hide_from_reports=True)

    def handler(request_obj: httpx.Request) -> httpx.Response:
        payload = json.loads(request_obj.content.decode("utf-8"))
        assert payload["operationName"] == "Web_TransactionDrawerUpdateTransaction"
        assert payload["variables"] == {"input": {"id": "txn-1", "name": "Renamed", "hideFromReports": True}}
        return httpx.Response(
            200,
            json={"data": {"updateTransaction": {"transaction": {"id": "txn-1", "hideFromReports": True}, "errors": []}}},
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.transactions.update(request)
    assert payload.transaction is not None
    assert payload.transaction.id == "txn-1"


def test_attachment_upload_info_uses_bundle_derived_mutation() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_GetTransactionAttachmentUploadInfo"
        assert payload["variables"] == {"transactionId": "txn-1"}
        return httpx.Response(
            200,
            json={
                "data": {
                    "getTransactionAttachmentUploadInfo": {
                        "info": {
                            "path": "folder/file",
                            "requestParams": {"api_key": "abc"},
                        }
                    }
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.attachments.get_upload_info("txn-1")
    assert payload.path == "folder/file"
