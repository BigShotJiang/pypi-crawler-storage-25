from __future__ import annotations

import json

import httpx

from monarch_api import MonarchClient
from monarch_api.models import PremiumUpgradePlansRequest, ReferralSettingsRequest


def test_subscription_details_uses_expected_operation() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_GetSubscriptionDetails"
        assert payload["variables"] == {}
        return httpx.Response(
            200,
            json={"data": {"subscription": {"id": "sub-1", "billingPeriod": "MONTHLY"}}},
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.subscription.details()
    assert payload.id == "sub-1"


def test_subscription_modal_uses_expected_variables() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Web_GetSubscriptionModal"
        assert payload["variables"] == {
            "promoCode": "SPRING",
            "stripePriceId": "price-123",
        }
        return httpx.Response(
            200,
            json={"data": {"subscription": {"id": "sub-1"}, "plusUpgradeTrial": {"trialDays": 7}}},
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.subscription.modal(promo_code="SPRING", stripe_price_id="price-123")
    assert payload.plus_upgrade_trial is not None
    assert payload.plus_upgrade_trial.trial_days == 7


def test_subscription_premium_upgrade_plans_uses_expected_variables() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_GetPremiumUpgradePlans"
        assert payload["variables"] == {
            "promoCode": "SPRING",
            "referralCode": "friend-code",
            "selectedPlanId": "price-annual",
        }
        return httpx.Response(
            200,
            json={"data": {"subscriptionOffering": {"plans": [{"stripeId": "price-annual"}]}}},
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.subscription.premium_upgrade_plans(
        PremiumUpgradePlansRequest(
            promo_code="SPRING",
            referral_code="friend-code",
            selected_plan_id="price-annual",
        )
    )
    assert payload.subscription_offering is not None
    assert payload.subscription_offering.plans[0].stripe_id == "price-annual"


def test_subscription_trial_and_entitlements_queries_return_subscription_object() -> None:
    expected_operations = {
        "GetTrialStatus": {"eligibleForTrial": False},
        "Common_GetEntitlements": {"entitlements": ["premium"]},
        "Common_GetPlusTierAccess": {"entitlements": ["premium_plus"]},
    }

    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        operation_name = payload["operationName"]
        assert payload["variables"] == {}
        return httpx.Response(
            200,
            json={"data": {"subscription": {"id": "sub-1", **expected_operations[operation_name]}}},
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    assert client.subscription.trial_status().eligible_for_trial is False
    assert client.subscription.entitlements().entitlements == ["premium"]
    assert client.subscription.plus_tier_access().entitlements == ["premium_plus"]


def test_subscription_feature_entitlement_params_uses_expected_operation() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_GetFeatureEntitlementParams"
        assert payload["variables"] == {}
        return httpx.Response(
            200,
            json={
                "data": {
                    "subscription": {
                        "id": "sub-1",
                        "entitlementParams": {
                            "features": [{"feature": "attachments"}],
                            "constants": [{"entitlement": "premium"}],
                        },
                    }
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.subscription.feature_entitlement_params()
    assert payload.features[0].feature == "attachments"


def test_subscription_gifted_subscriptions_returns_list() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_GetGiftedSubscriptions"
        assert payload["variables"] == {}
        return httpx.Response(
            200,
            json={"data": {"giftedSubscriptionsPurchasedByHousehold": [{"id": "gift-1"}]}},
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.subscription.gifted_subscriptions()
    assert payload[0].id == "gift-1"


def test_subscription_referral_settings_uses_expected_variables() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_GetReferralSettings"
        assert payload["variables"] == {
            "statisticsStartDate": "2026-01-01T00:00:00.000-06:00",
            "statisticsEndDate": "2026-12-31T23:59:59.999-06:00",
            "v1PayoutMethod": "v1_subscription_credit",
            "v2PayoutMethod": "v2_gift_card",
        }
        return httpx.Response(
            200,
            json={"data": {"constants": {"referralAnnualRewardLimitUsd": 480.0}}},
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.subscription.referral_settings(
        ReferralSettingsRequest(
            statistics_start_date="2026-01-01T00:00:00.000-06:00",
            statistics_end_date="2026-12-31T23:59:59.999-06:00",
            v1_payout_method="v1_subscription_credit",
            v2_payout_method="v2_gift_card",
        )
    )
    assert payload.constants is not None
    assert payload.constants.referral_annual_reward_limit_usd == 480.0
