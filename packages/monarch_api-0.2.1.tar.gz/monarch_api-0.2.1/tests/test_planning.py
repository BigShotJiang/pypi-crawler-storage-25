from __future__ import annotations

import json

import httpx

from monarch_api import MonarchClient


def test_budget_data_uses_expected_variables() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_BudgetDataQuery"
        assert payload["variables"] == {
            "startDate": "2026-04-01",
            "endDate": "2026-04-30",
        }
        return httpx.Response(
            200,
            json={
                "data": {
                    "budgetSystem": "simple",
                    "budgetStatus": {"hasBudget": True},
                    "budgetData": {"monthlyAmountsByCategory": [], "monthlyAmountsByCategoryGroup": [], "monthlyAmountsForFlexExpense": [], "totalsByMonth": []},
                    "categoryGroups": [],
                    "goalsV2": [],
                    "savingsGoalMonthlyBudgetAmounts": [],
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.planning.budget_data(start_date="2026-04-01", end_date="2026-04-30")
    assert payload.budget_system == "simple"
    assert payload.budget_status is not None
    assert payload.budget_status.has_budget is True


def test_joint_planning_data_uses_expected_variables() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_GetJointPlanningData"
        assert payload["variables"] == {
            "startDate": "2026-03-01",
            "endDate": "2026-06-01",
        }
        return httpx.Response(
            200,
            json={
                "data": {
                    "budgetSystem": "rollover",
                    "budgetData": {"monthlyAmountsByCategory": [], "monthlyAmountsByCategoryGroup": [], "monthlyAmountsForFlexExpense": [], "totalsByMonth": []},
                    "categoryGroups": [],
                    "goalsV2": [],
                    "savingsGoalMonthlyBudgetAmounts": [],
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.planning.joint_planning_data(start_date="2026-03-01", end_date="2026-06-01")
    assert payload.budget_system == "rollover"
