from __future__ import annotations

import json

import httpx

from monarch_api import MonarchClient
from monarch_api.models import CreateTransactionRuleRequest, MerchantCriterion, TransactionRulePreviewRequest, UpdateTransactionRuleRequest


def test_rules_list_uses_expected_query() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "GetTransactionRules"
        assert "TransactionRuleFields" in payload["query"]
        return httpx.Response(
            200,
            json={
                "data": {
                    "transactionRules": [{"id": "rule-1", "order": 1, "merchantCriteria": []}],
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.rules.list()
    assert payload[0].id == "rule-1"


def test_rules_create_uses_expected_mutation() -> None:
    expected_input = {"merchantNameCriteria": [{"operator": "contains", "value": "coffee"}]}

    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_CreateTransactionRuleMutationV2"
        assert payload["variables"] == {"input": expected_input}
        return httpx.Response(
            200,
            json={"data": {"createTransactionRuleV2": {"errors": []}}},
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.rules.create(
        CreateTransactionRuleRequest(merchant_name_criteria=[MerchantCriterion(operator="contains", value="coffee")])
    )
    assert payload.errors == []


def test_rules_update_uses_expected_mutation() -> None:
    expected_input = {"id": "rule-1", "setHideFromReportsAction": True}

    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_UpdateTransactionRuleMutationV2"
        assert payload["variables"] == {"input": expected_input}
        return httpx.Response(
            200,
            json={"data": {"updateTransactionRuleV2": {"errors": []}}},
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.rules.update(UpdateTransactionRuleRequest(id="rule-1", set_hide_from_reports_action=True))
    assert payload.errors == []


def test_rules_delete_uses_expected_mutation() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_DeleteTransactionRule"
        assert payload["variables"] == {"id": "rule-1"}
        return httpx.Response(
            200,
            json={"data": {"deleteTransactionRule": {"deleted": True, "errors": []}}},
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.rules.delete("rule-1")
    assert payload.deleted is True


def test_rules_preview_uses_expected_query() -> None:
    expected_rule = {"merchantNameCriteria": [{"operator": "contains", "value": "aldi"}]}

    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_PreviewTransactionRule"
        assert payload["variables"] == {"rule": expected_rule, "offset": 30}
        assert "transactionRulePreview(input: $rule)" in payload["query"]
        assert "newBusinessEntityIsUnassigned" in payload["query"]
        return httpx.Response(
            200,
            json={
                "data": {
                    "transactionRulePreview": {
                        "totalCount": 1,
                        "results": [{"transaction": {"id": "tx-1"}}],
                    }
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.rules.preview(
        TransactionRulePreviewRequest(merchant_name_criteria=[MerchantCriterion(operator="contains", value="aldi")]),
        offset=30,
    )
    assert payload.total_count == 1


def test_rules_update_order_uses_expected_mutation() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Web_UpdateRuleOrderMutation"
        assert payload["variables"] == {"id": "rule-1", "order": 3}
        return httpx.Response(
            200,
            json={
                "data": {
                    "updateTransactionRuleOrderV2": {
                        "transactionRules": [{"id": "rule-1", "order": 3}],
                    }
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.rules.update_order("rule-1", 3)
    assert payload.transaction_rules[0].order == 3


def test_rules_delete_all_uses_expected_mutation() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Web_DeleteAllTransactionRulesMutation"
        assert payload["variables"] == {}
        return httpx.Response(
            200,
            json={"data": {"deleteAllTransactionRules": {"deleted": True}}},
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.rules.delete_all()
    assert payload.deleted is True
