from __future__ import annotations

import json

import httpx

from monarch_api import MonarchClient
from monarch_api.models import ReportsDataRequest, TransactionFilter


def test_reports_data_uses_expected_variables() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_GetReportsData"
        assert payload["variables"]["filters"] == {"categoryType": "expense", "transactionVisibility": "non_hidden_transactions_only"}
        assert payload["variables"]["groupBy"] == ["category"]
        assert payload["variables"]["sortBy"] == "sum_expense"
        assert payload["variables"]["includeCategory"] is True
        return httpx.Response(
            200,
            json={
                "data": {
                    "reports": {"groupBy": [], "summary": {"sumExpense": 123}},
                    "aggregates": {"summary": {"sumExpense": 123}},
                }
            },
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.reports.data(
        ReportsDataRequest(
            filters=TransactionFilter(
                category_type="expense",
                transaction_visibility="non_hidden_transactions_only",
            ),
            group_by=["category"],
            sort_by="sum_expense",
            include_category=True,
        )
    )
    assert payload.reports is not None
    assert payload.reports.summary is not None
    assert payload.reports.summary.sum_expense == 123


def test_cash_flow_entity_aggregates_uses_expected_operation() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content.decode("utf-8"))
        assert payload["operationName"] == "Common_GetCashFlowEntityAggregates"
        assert payload["variables"]["filters"] == {"accounts": [], "tags": []}
        return httpx.Response(
            200,
            json={"data": {"summary": {"summary": {"savingsRate": 0.4}}}},
        )

    client = MonarchClient(
        token="token-123",
        http_client=httpx.Client(base_url="https://api.monarch.com", transport=httpx.MockTransport(handler)),
    )
    payload = client.reports.cash_flow_entity_aggregates(filters=TransactionFilter(accounts=[], tags=[]))
    assert payload.summary is not None
    assert payload.summary.savings_rate == 0.4
