"""Fidelity tests for athena-python-docx vs stock python-docx.

Each test case is a small script that uses the python-docx `docx` namespace.
The same script runs against:
  - stock `python-docx` (in an isolated venv)      -> produces .docx A
  - `athena-python-docx` via Daytona + Superdoc    -> produces .docx B

Both .docx files are then read back through stock python-docx for feature
extraction, and the extracted structures are compared. Differences that
matter (missing text, wrong style, different cell count) are scored as
FAIL; stylistic differences (default font, theme color) are tolerated.

See `README.md` for running.
"""
