"""Fidelity runner — orchestrates stock python-docx + athena-python-docx
across all cases in ``cases.CASES`` and prints a scorecard.

Usage
-----
    cd agora && doppler run --project agora --config dev -- \
        uv run python ../docx-studio/python-sdk/tests/fidelity/runner.py

The runner needs:
  - a Daytona API key (from agora settings) — used to spin up a sandbox
    and execute the athena-python-docx side
  - a Keryx private key + WS URL (from agora settings) — to sign a token
    for the sandbox
  - a reusable SuperDoc asset to write against (default asset on staging
    is hard-coded; override with ATHENA_DOCX_FIDELITY_ASSET_ID)
  - stock python-docx installed somewhere (we install it on-demand into
    ``/tmp/docx-fidelity-stock-site-packages`` if missing)

Output is a table listing each case with status (PASS / FAIL / STUB-HIT /
ERROR), plus any diffs.
"""

from __future__ import annotations

import asyncio
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

# Allow running this file as a script: add the sdk root so "docx.*" and
# the tests/fidelity package both resolve.
_SDK_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_SDK_ROOT))

from tests.fidelity.cases import CASES, Case  # noqa: E402
from tests.fidelity.extract import compare, extract_features  # noqa: E402


# ── configuration ─────────────────────────────────────────────────────

DEFAULT_ASSET_ID = os.environ.get(
    "ATHENA_DOCX_FIDELITY_ASSET_ID",
    "asset_de593a96-3031-45ea-bc52-60cb4b2b16ad",  # "PR18540 SuperDoc Test"
)
STOCK_SITE_PACKAGES = Path("/tmp/docx-fidelity-stock-site-packages")
ARTIFACT_DIR = Path("/tmp/docx-fidelity-artifacts")


# ── stock python-docx setup ───────────────────────────────────────────


def ensure_stock_python_docx() -> Path:
    """Install stock python-docx into an isolated directory if not present."""
    marker = STOCK_SITE_PACKAGES / "docx" / "__init__.py"
    if marker.exists():
        return STOCK_SITE_PACKAGES
    print(f"[fidelity] installing stock python-docx -> {STOCK_SITE_PACKAGES}")
    STOCK_SITE_PACKAGES.mkdir(parents=True, exist_ok=True)
    # Use `uv pip install --target` — agora's .venv is uv-managed and
    # doesn't include stdlib `pip`. Fall back to `python -m pip` only if
    # `uv` isn't on PATH (shouldn't happen inside `doppler run -- uv run`).
    uv = _which("uv")
    if uv:
        cmd = [uv, "pip", "install", "--quiet", "--target", str(STOCK_SITE_PACKAGES), "python-docx>=1.1"]
    else:
        cmd = [sys.executable, "-m", "pip", "install", "--quiet", "--target", str(STOCK_SITE_PACKAGES), "python-docx>=1.1"]
    subprocess.run(cmd, check=True)
    return STOCK_SITE_PACKAGES


def _which(name: str) -> str | None:
    import shutil
    return shutil.which(name)


def run_stock_script(script: str, out_path: Path) -> None:
    """Run a script with stock python-docx, writing output to `out_path`.

    The subprocess is invoked with PYTHONPATH pointed at our isolated
    stock site-packages so we don't collide with our SDK's `docx` ns.
    """
    stock = ensure_stock_python_docx()
    wrapped = (
        "import sys\n"
        f"sys.path.insert(0, {str(stock)!r})\n"
        "from docx import Document\n"
        "doc = Document()\n"
        f"{script}\n"
        f"doc.save({str(out_path)!r})\n"
    )
    result = subprocess.run(
        [sys.executable, "-c", wrapped],
        capture_output=True,
        text=True,
        timeout=30,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"stock python-docx subprocess failed:\n"
            f"  stdout: {result.stdout}\n"
            f"  stderr: {result.stderr}",
        )


# ── athena-python-docx via Daytona ────────────────────────────────────


def build_sandbox_script(cases_batch: list[Case], asset_id: str) -> str:
    """Return a Python program to run inside the Daytona sandbox.

    It iterates cases, for each:
      - clears the doc via superdoc-sdk.doc.clear_content()
      - executes the case's script with `doc` pre-bound
      - exports the resulting .docx to /tmp/fidelity_out/<case_name>.docx
      - records success/exception into /tmp/fidelity_results.json
    """
    cases_json = json.dumps(
        [{"name": c.name, "script": c.script, "expected_exc": c.expected_athena_exc} for c in cases_batch],
    )
    return f'''
import asyncio
import json
import os
import traceback
from pathlib import Path

import docx as _docx_mod
print(f"[sandbox] athena-python-docx __version__ = {{_docx_mod.__version__}}")
print(f"[sandbox] loaded from {{_docx_mod.__file__}}")

OUT_DIR = Path("/tmp/fidelity_out")
OUT_DIR.mkdir(parents=True, exist_ok=True)
ASSET_ID = {asset_id!r}
CASES = json.loads({cases_json!r})

from superdoc import AsyncSuperDocClient
from superdoc.generated.client import DocOpenParams, DocOpenParamsCollaborationVariant1

async def with_session(callback):
    token = os.environ["SUPERDOC_COLLAB_TOKEN"]
    ws_url = os.environ["KERYX_WS_URL"]
    ws_id = os.environ["ATHENA_WORKSPACE_ID"]
    client = AsyncSuperDocClient(
        user={{"name":"fidelity-runner","email":"fidelity@athenaintel.com"}},
        env={{"SUPERDOC_COLLAB_TOKEN": token}},
        request_timeout_ms=30_000,
        watchdog_timeout_ms=60_000,
    )
    try:
        collab: DocOpenParamsCollaborationVariant1 = {{
            "url": f"{{ws_url}}/ws/{{ws_id}}",
            "documentId": ASSET_ID,
            "tokenEnv": "SUPERDOC_COLLAB_TOKEN",
            "providerType": "y-websocket",
        }}
        h = await client.open({{"collaboration": collab}})
        try:
            return await callback(h)
        finally:
            await asyncio.sleep(0.5)
            await h.close({{"discard": True}})
    finally:
        await client.dispose()


async def clear_asset():
    async def _clear(h):
        try:
            await h.clear_content({{}})
        except Exception as e:
            # If "already empty" fine
            if "already empty" not in str(e).lower():
                raise
    await with_session(_clear)


async def export_to(path):
    async def _export(h):
        await h.save({{"out": str(path)}})
    await with_session(_export)


def run_case_locally(script):
    """Run script against athena-python-docx via sync facade."""
    from docx import Document
    with Document(ASSET_ID) as doc:
        # RGBColor and Pt are intentionally not pre-bound — each script that
        # needs them imports them explicitly (matching how agents write code).
        from docx.shared import RGBColor, Pt
        local_ns = dict(doc=doc, RGBColor=RGBColor, Pt=Pt)
        exec(compile(script, "<case>", "exec"), local_ns, local_ns)
        doc.save()


results = []
for case in CASES:
    name = case["name"]
    script = case["script"]
    expected = case["expected_exc"]

    # Step 1: clear the asset
    try:
        asyncio.run(clear_asset())
    except Exception as e:
        results.append({{
            "name": name,
            "status": "SETUP_ERROR",
            "detail": f"clear_content failed: {{e!r}}",
        }})
        continue

    # Step 2: run the case's script via athena-python-docx
    script_error = None
    try:
        run_case_locally(script)
    except Exception as e:
        script_error = (type(e).__name__, str(e)[:400])

    # Step 3: compare error vs expectation
    if expected is not None:
        if script_error is not None and script_error[0] == expected:
            results.append({{"name": name, "status": "STUB_HIT", "detail": script_error[1][:200]}})
            continue
        if script_error is None:
            results.append({{"name": name, "status": "UNEXPECTED_PASS", "detail": f"expected {{expected}} but succeeded"}})
            continue
        results.append({{
            "name": name,
            "status": "WRONG_EXC",
            "detail": f"expected {{expected}}, got {{script_error[0]}}: {{script_error[1]}}",
        }})
        continue

    if script_error is not None:
        results.append({{
            "name": name,
            "status": "SCRIPT_ERROR",
            "detail": f"{{script_error[0]}}: {{script_error[1]}}",
        }})
        continue

    # Step 4: export and record artifact
    out_path = OUT_DIR / f"{{name}}.docx"
    try:
        asyncio.run(export_to(out_path))
    except Exception as e:
        results.append({{"name": name, "status": "EXPORT_ERROR", "detail": f"{{type(e).__name__}}: {{e}}"}})
        continue

    size = out_path.stat().st_size if out_path.exists() else 0
    results.append({{"name": name, "status": "OK", "detail": f"exported {{size}} bytes", "export_path": str(out_path)}})

Path("/tmp/fidelity_results.json").write_text(json.dumps(results, indent=2))
print(json.dumps(results, indent=2))
'''


async def run_daytona_batch(cases: list[Case], asset_id: str) -> tuple[list[dict], dict[str, bytes]]:
    """Spin up a sandbox, run all cases, download every exported .docx."""
    from agora.services.keryx.client import get_keryx_client
    from agora.services.auth.docx_auth import build_docx_collab_bundle  # noqa: F401 ensures agora is loadable
    from agora.settings import settings
    from daytona_sdk import AsyncDaytona, CreateSandboxFromSnapshotParams, DaytonaConfig

    routing_bundle = await _build_collab_bundle(asset_id)
    kc = get_keryx_client()
    # Fresh token for the sandbox.
    token = kc._sign_token(user_id="fidelity-runner")  # noqa: SLF001

    daytona = AsyncDaytona(
        config=DaytonaConfig(
            api_key=settings.daytona_full_api_key,
            api_url=settings.daytona_api_url,
            organization_id=settings.daytona_organization_id,
            target=settings.daytona_target,
        ),
    )
    snapshot = settings.daytona_document_exec_snapshot or "document-exec:v1"
    print(f"[fidelity] daytona snapshot: {snapshot}")

    sandbox = await daytona.create(
        CreateSandboxFromSnapshotParams(
            name=f"docx-fidelity-{int(time.time())}",
            snapshot=snapshot,
            env_vars={
                "SUPERDOC_COLLAB_TOKEN": token,
                "KERYX_WS_URL": settings.keryx_ws_url,
                "ATHENA_WORKSPACE_ID": routing_bundle["ATHENA_WORKSPACE_ID"],
            },
            auto_stop_interval=30,
            auto_archive_interval=60,
        ),
        timeout=120,
    )
    print(f"[fidelity] sandbox {sandbox.id} started")

    try:
        # Upload the latest-built athena-python-docx wheel so the sandbox runs
        # whichever version is currently in dist/, not the one baked into the
        # image. This keeps the fidelity harness honest during SDK iteration.
        wheel_dir = _SDK_ROOT / "dist"
        wheels = sorted(wheel_dir.glob("athena_python_docx-*.whl"))
        if wheels:
            latest_wheel = wheels[-1]
            await sandbox.fs.upload_file(
                latest_wheel.read_bytes(),
                f"/tmp/{latest_wheel.name}",
            )
            install_cmd = f"pip install --quiet --force-reinstall --no-deps /tmp/{latest_wheel.name}"
            install_res = await sandbox.process.exec(install_cmd, timeout=120)
            print(
                f"[fidelity] installed {latest_wheel.name} "
                f"(exit={install_res.exit_code})",
            )

        script = build_sandbox_script(cases, asset_id)
        await sandbox.fs.upload_file(script.encode(), "/tmp/fidelity_runner.py")
        exec_result = await sandbox.process.exec(
            "python3 /tmp/fidelity_runner.py",
            timeout=600,
        )
        print(f"[fidelity] sandbox exit_code={exec_result.exit_code}")
        # Surface sandbox stdout so [sandbox] diagnostics are visible in the log.
        sandbox_stdout = getattr(exec_result, "result", None) or ""
        if sandbox_stdout:
            print("─── sandbox stdout ─────────────────────────────────")
            print(sandbox_stdout)
            print("────────────────────────────────────────────────────")
        # Load the results JSON
        raw = await sandbox.fs.download_file("/tmp/fidelity_results.json")
        results: list[dict] = json.loads(raw.decode())

        # Download every successfully-exported .docx artifact
        artifacts: dict[str, bytes] = {}
        for r in results:
            if r["status"] == "OK" and "export_path" in r:
                try:
                    data = await sandbox.fs.download_file(r["export_path"])
                    artifacts[r["name"]] = data
                except Exception as e:
                    r["status"] = "DOWNLOAD_ERROR"
                    r["detail"] = f"fs.download_file: {e}"
        return results, artifacts
    finally:
        try:
            await sandbox.delete()
        except Exception as e:
            print(f"[fidelity] sandbox delete failed: {e}")


async def _build_collab_bundle(asset_id: str) -> dict[str, str]:
    from agora.services.auth.docx_auth import build_docx_collab_bundle
    b = await build_docx_collab_bundle(asset_id=asset_id, user_id="fidelity-runner")
    return dict(b)


# ── scorecard ─────────────────────────────────────────────────────────


def print_scorecard(
    cases: list[Case],
    daytona_results: list[dict],
    diffs_by_name: dict[str, list[str]],
) -> int:
    """Print a scorecard. Return exit code (0 = all green)."""
    print()
    print("=" * 88)
    from docx import __version__ as _sdk_version
    print(
        f"FIDELITY SCORECARD — athena-python-docx {_sdk_version} vs stock python-docx",
    )
    print("=" * 88)

    by_name = {r["name"]: r for r in daytona_results}
    status_icons = {
        "OK": "✅",
        "STUB_HIT": "🟡",
        "UNEXPECTED_PASS": "🟠",
        "WRONG_EXC": "🔴",
        "SCRIPT_ERROR": "❌",
        "SETUP_ERROR": "❌",
        "EXPORT_ERROR": "❌",
        "DOWNLOAD_ERROR": "❌",
    }

    fails = 0
    for case in cases:
        r = by_name.get(case.name, {"status": "MISSING", "detail": "not run"})
        status = r["status"]
        icon = status_icons.get(status, "❓")
        diff_suffix = ""
        if status == "OK" and not case.skip_content_diff:
            diffs = diffs_by_name.get(case.name, [])
            if diffs:
                status = "DIFF"
                icon = "⚠️"
                diff_suffix = f"  ({len(diffs)} diff(s))"

        line = f"  {icon} [{status:14}] {case.name:32} — {case.description}{diff_suffix}"
        print(line)
        if status not in {"OK", "STUB_HIT"}:
            if status == "DIFF":
                for d in diffs_by_name.get(case.name, [])[:3]:
                    print(f"      ↳ {d}")
                if len(diffs_by_name.get(case.name, [])) > 3:
                    print(f"      ↳ …and {len(diffs_by_name[case.name])-3} more")
            else:
                detail = r.get("detail", "")
                if detail:
                    print(f"      ↳ {detail[:150]}")
            if status not in {"STUB_HIT"}:
                fails += 1

    print()
    n_ok = sum(1 for r in daytona_results if r["status"] == "OK")
    n_stub = sum(1 for r in daytona_results if r["status"] == "STUB_HIT")
    n_diff = sum(
        1 for c in cases
        if by_name.get(c.name, {}).get("status") == "OK"
        and diffs_by_name.get(c.name)
    )
    total = len(cases)
    print(f"  {n_ok}/{total} cases ran successfully in Athena SDK")
    print(f"  {n_stub}/{total} cases hit expected NotImplementedError stubs (known Phase-2 gaps)")
    print(f"  {n_diff}/{n_ok} successful-run cases have content-level diffs vs stock python-docx")
    print(f"  exit code: {0 if fails == 0 else 1}")
    return 0 if fails == 0 else 1


# ── main ──────────────────────────────────────────────────────────────


async def main() -> int:
    print(f"[fidelity] case count: {len(CASES)}")
    print(f"[fidelity] target asset: {DEFAULT_ASSET_ID}")
    ensure_stock_python_docx()
    ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)

    # 1) Generate all stock python-docx outputs locally
    print("[fidelity] running stock python-docx side ...")
    stock_paths: dict[str, Path] = {}
    for case in CASES:
        out = ARTIFACT_DIR / f"stock_{case.name}.docx"
        try:
            run_stock_script(case.script, out)
            stock_paths[case.name] = out
        except Exception as e:
            print(f"  !! {case.name} stock subprocess error: {e}")

    # 2) Run the athena side via Daytona in a single batch
    print("[fidelity] running athena-python-docx via Daytona ...")
    daytona_results, athena_artifacts = await run_daytona_batch(CASES, DEFAULT_ASSET_ID)

    # 3) Save athena artifacts locally and extract/compare features
    diffs_by_name: dict[str, list[str]] = {}
    for case in CASES:
        if case.name not in athena_artifacts:
            continue
        if case.skip_content_diff:
            continue
        athena_path = ARTIFACT_DIR / f"athena_{case.name}.docx"
        athena_path.write_bytes(athena_artifacts[case.name])
        stock_path = stock_paths.get(case.name)
        if stock_path is None:
            continue
        try:
            stock_feat = extract_features(stock_path, str(STOCK_SITE_PACKAGES))
            ath_feat = extract_features(athena_path, str(STOCK_SITE_PACKAGES))
            diffs_by_name[case.name] = compare(stock_feat, ath_feat)
        except Exception as e:
            diffs_by_name[case.name] = [f"extractor error: {e}"]

    # 4) Scorecard
    code = print_scorecard(CASES, daytona_results, diffs_by_name)
    print(f"\n[fidelity] artifacts in {ARTIFACT_DIR}")
    return code


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
