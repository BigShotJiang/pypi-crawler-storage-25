"""Feature extractor — reads a .docx (produced by either SDK) with stock
python-docx and returns a normalized structure for comparison.

The extractor focuses on features that SHOULD round-trip regardless of
template differences between stock python-docx and Superdoc:
  - paragraph text content and style name
  - runs within each paragraph: text + bold + italic + underline + color
  - table row/col counts + cell texts

It does NOT try to compare defaults, fonts, margins, or theme colors —
those legitimately differ between a blank python-docx template and the
Superdoc SuperDoc-default template, and would produce false positives.
"""

from __future__ import annotations

import importlib
import sys
import types
from pathlib import Path
from typing import TypedDict


# ── isolated python-docx loader ────────────────────────────────────────
# We run this extractor in a process that has the athena-python-docx
# `docx` namespace installed. To read real .docx files we need STOCK
# python-docx. Load it from an isolated path and return a module handle.

_STOCK_CACHE: types.ModuleType | None = None


def _load_stock_python_docx(stock_site_packages: str) -> types.ModuleType:
    """Import the stock python-docx module from an isolated site-packages.

    Mirrors the pattern from pptx-studio's
    test_python_pptx_api_parity.py::_load_standard_module.
    """
    global _STOCK_CACHE
    if _STOCK_CACHE is not None:
        return _STOCK_CACHE

    original_path = sys.path.copy()
    original_modules = {k: v for k, v in sys.modules.items() if k.startswith("docx")}
    for key in list(sys.modules):
        if key.startswith("docx"):
            del sys.modules[key]

    sys.path.insert(0, stock_site_packages)
    try:
        mod = importlib.import_module("docx")
        _STOCK_CACHE = mod
        return mod
    finally:
        sys.path[:] = original_path
        # Restore our own `docx.*` modules so later imports of the Athena
        # SDK work. (The cached stock module stays importable as long as
        # _STOCK_CACHE holds a reference.)
        for key in list(sys.modules):
            if key.startswith("docx"):
                del sys.modules[key]
        sys.modules.update(original_modules)


# ── feature types ──────────────────────────────────────────────────────

class RunFeature(TypedDict, total=False):
    text: str
    bold: bool
    italic: bool
    underline: bool
    color: str | None  # hex string, e.g. "006600", or None


class ParaFeature(TypedDict, total=False):
    text: str
    style: str
    runs: list[RunFeature]


class CellFeature(TypedDict):
    text: str


class TableFeature(TypedDict):
    rows: int
    cols: int
    cells: list[list[CellFeature]]  # rows × cols


class DocxFeatures(TypedDict):
    paragraphs: list[ParaFeature]
    tables: list[TableFeature]
    paragraph_count: int
    table_count: int


# ── the extractor ──────────────────────────────────────────────────────


def _ensure_styles_with_effects(docx_path: Path) -> Path:
    """Patch a .docx to contain a stub `word/stylesWithEffects.xml`.

    New python-docx (≥0.8.10) requires that part when `word/_rels/
    document.xml.rels` references it (older Office template legacy).
    Superdoc's export doesn't include it, which makes python-docx raise
    "There is no item named 'word/stylesWithEffects.xml' in the archive"
    the first time a style is dereferenced.

    We add a minimal valid-but-empty styles document. Mutation happens in
    a sibling tmpfile so the original export stays intact for inspection.
    """
    import shutil
    import zipfile

    import tempfile
    with zipfile.ZipFile(docx_path, "r") as z:
        names = set(z.namelist())
    if "word/stylesWithEffects.xml" in names:
        return docx_path
    patched = Path(tempfile.mkstemp(prefix="patched_", suffix=".docx")[1])
    shutil.copy2(docx_path, patched)
    stub = (
        b'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        b'<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        b'</w:styles>'
    )
    with zipfile.ZipFile(patched, "a") as z:
        if "word/stylesWithEffects.xml" not in set(z.namelist()):
            z.writestr("word/stylesWithEffects.xml", stub)
    return patched


def extract_features(docx_path: Path, stock_site_packages: str) -> DocxFeatures:
    """Extract normalized features from a .docx file."""
    docx_path = _ensure_styles_with_effects(docx_path)
    docx_mod = _load_stock_python_docx(stock_site_packages)
    # Open the file. We re-import via the isolated stock docx to avoid
    # confusion with our SDK's `docx` namespace.
    orig_sys_path = sys.path.copy()
    orig_mods = {k: v for k, v in sys.modules.items() if k.startswith("docx")}
    for key in list(sys.modules):
        if key.startswith("docx"):
            del sys.modules[key]
    sys.path.insert(0, stock_site_packages)
    try:
        docx_mod = importlib.import_module("docx")
        stock_Document = docx_mod.Document  # type: ignore[attr-defined]

        doc = stock_Document(str(docx_path))

        paragraphs: list[ParaFeature] = []
        for p in doc.paragraphs:
            runs: list[RunFeature] = []
            for r in p.runs:
                rf: RunFeature = {
                    "text": r.text,
                    "bold": bool(r.bold) if r.bold is not None else False,
                    "italic": bool(r.italic) if r.italic is not None else False,
                    "underline": bool(r.underline) if r.underline is not None else False,
                    "color": None,
                }
                try:
                    rgb = r.font.color.rgb
                    if rgb is not None:
                        rf["color"] = str(rgb)
                except Exception:
                    pass
                runs.append(rf)
            style_name = ""
            try:
                style_name = p.style.name if p.style is not None else ""
            except Exception:
                style_name = ""
            paragraphs.append({
                "text": p.text,
                "style": style_name,
                "runs": runs,
            })

        tables: list[TableFeature] = []
        for t in doc.tables:
            rows = len(t.rows)
            cols = len(t.rows[0].cells) if rows > 0 else 0
            cells: list[list[CellFeature]] = []
            for row in t.rows:
                cells.append([{"text": c.text} for c in row.cells])
            tables.append({
                "rows": rows,
                "cols": cols,
                "cells": cells,
            })

        return {
            "paragraphs": paragraphs,
            "tables": tables,
            "paragraph_count": len(paragraphs),
            "table_count": len(tables),
        }
    finally:
        sys.path[:] = orig_sys_path
        for key in list(sys.modules):
            if key.startswith("docx"):
                del sys.modules[key]
        sys.modules.update(orig_mods)


# ── comparator ─────────────────────────────────────────────────────────


def compare(stock: DocxFeatures, athena: DocxFeatures) -> list[str]:
    """Return a list of semantic differences. Empty list = pass."""
    diffs: list[str] = []

    # Paragraph count. Superdoc's Word-default template often inserts an
    # extra empty paragraph at the end (no text, no runs). We tolerate
    # a +/- 1 gap as long as the non-empty content matches.
    stock_nonempty = [p for p in stock["paragraphs"] if p["text"] or p["runs"]]
    athena_nonempty = [p for p in athena["paragraphs"] if p["text"] or p["runs"]]
    if len(stock_nonempty) != len(athena_nonempty):
        diffs.append(
            f"non-empty paragraph count: stock={len(stock_nonempty)} "
            f"athena={len(athena_nonempty)}",
        )

    for i, (s, a) in enumerate(zip(stock_nonempty, athena_nonempty)):
        if s["text"] != a["text"]:
            diffs.append(
                f"paragraph[{i}] text: stock={s['text']!r} athena={a['text']!r}",
            )
        # Style name: stock uses "Heading 1" style names; Superdoc may
        # use "Heading1" (no space) or the same. Normalize whitespace.
        s_style = (s.get("style") or "").replace(" ", "").lower()
        a_style = (a.get("style") or "").replace(" ", "").lower()
        if s_style != a_style:
            diffs.append(
                f"paragraph[{i}] style: stock={s['style']!r} athena={a['style']!r}",
            )

    # Table structure
    if stock["table_count"] != athena["table_count"]:
        diffs.append(
            f"table count: stock={stock['table_count']} athena={athena['table_count']}",
        )
    for i, (st, at) in enumerate(zip(stock["tables"], athena["tables"])):
        if st["rows"] != at["rows"] or st["cols"] != at["cols"]:
            diffs.append(
                f"table[{i}] shape: stock={st['rows']}x{st['cols']} "
                f"athena={at['rows']}x{at['cols']}",
            )
        # Cell content
        for r, (s_row, a_row) in enumerate(zip(st["cells"], at["cells"])):
            for c, (s_cell, a_cell) in enumerate(zip(s_row, a_row)):
                if s_cell["text"] != a_cell["text"]:
                    diffs.append(
                        f"table[{i}].cell({r},{c}).text: "
                        f"stock={s_cell['text']!r} athena={a_cell['text']!r}",
                    )

    return diffs
