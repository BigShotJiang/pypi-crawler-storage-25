"""Parity contract tests. Verify that athena-python-docx exposes the
same public surface as python-docx.

Rather than attempt to load both packages side-by-side (same top-level
name), we assert a required-attr set per class. The required set is
derived from python-docx's official documentation and periodically
cross-checked by human review.

Run with:
    uv run pytest tests/test_python_docx_api_parity.py -v
"""

from __future__ import annotations

import inspect
from typing import Any

import pytest


def _public_attrs(cls: type) -> set[str]:
    return {name for name, _ in inspect.getmembers(cls) if not name.startswith("_")}


def _import_dotted(path: str) -> Any:
    mod_path, _, name = path.rpartition(".")
    mod = __import__(mod_path, fromlist=[name])
    return getattr(mod, name)


@pytest.mark.parametrize(
    "cls_path,required",
    [
        (
            "docx.document.Document",
            {
                "add_paragraph",
                "add_heading",
                "add_table",
                "add_picture",
                "add_page_break",
                "paragraphs",
                "tables",
                "save",
                "close",
            },
        ),
        (
            "docx.text.paragraph.Paragraph",
            {
                "text",
                "style",
                "alignment",
                "add_run",
                "runs",
            },
        ),
        (
            "docx.text.run.Run",
            {
                "text",
                "bold",
                "italic",
                "underline",
                "font",
            },
        ),
        (
            "docx.text.run.Font",
            {
                "name",
                "size",
                "color",
            },
        ),
        (
            "docx.table.Table",
            {
                "rows",
                "columns",
                "cell",
                "add_row",
                "add_column",
                "style",
            },
        ),
        (
            "docx.table._Row",
            {"cells"},
        ),
        (
            "docx.table._Column",
            {"cells"},
        ),
        (
            "docx.table._Cell",
            {"text", "merge"},
        ),
    ],
)
def test_class_surface_parity(cls_path: str, required: set[str]) -> None:
    """Our class must expose every attribute in the required set."""
    cls = _import_dotted(cls_path)
    actual = _public_attrs(cls)
    missing = required - actual
    assert not missing, (
        f"{cls_path} is missing attributes required by python-docx parity: "
        f"{missing}. Actual: {sorted(actual)}"
    )


def test_document_factory_signature() -> None:
    """docx.Document(docx=None) — first positional arg is `docx`."""
    from docx import Document

    sig = inspect.signature(Document)
    params = list(sig.parameters.values())
    assert params, "Document() must accept at least one parameter"
    assert params[0].name == "docx"


def test_rgbcolor_parity() -> None:
    from docx.shared import RGBColor

    c = RGBColor(0x00, 0x80, 0x00)
    assert str(c) == "008000"
    assert c == (0, 0x80, 0)
    assert RGBColor.from_string("#ff0000") == (0xFF, 0, 0)


def test_units_parity() -> None:
    from docx.shared import Cm, Emu, Inches, Mm, Pt

    assert Inches(1) == Emu(914400)
    assert Pt(12) == Emu(152400)
    assert Cm(1) == Emu(360000)
    assert Mm(10) == Emu(360000)
    # Round-trip
    assert Inches(2).inches == 2.0
    assert Pt(14).pt == 14.0


def test_WD_ALIGN_PARAGRAPH_has_core_members() -> None:
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    # python-docx has these as the primary 4
    assert hasattr(WD_ALIGN_PARAGRAPH, "LEFT")
    assert hasattr(WD_ALIGN_PARAGRAPH, "CENTER")
    assert hasattr(WD_ALIGN_PARAGRAPH, "RIGHT")
    assert hasattr(WD_ALIGN_PARAGRAPH, "JUSTIFY")


def test_Document_is_factory_function() -> None:
    """`from docx import Document` resolves to the factory function,
    not the class directly. This matches python-docx's import pattern.
    """
    from docx import Document
    from docx.document import Document as DocumentClass

    assert Document is not DocumentClass
    assert callable(Document)
