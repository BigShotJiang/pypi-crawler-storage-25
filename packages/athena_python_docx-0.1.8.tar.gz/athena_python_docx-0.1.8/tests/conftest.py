"""Shared pytest fixtures for athena-python-docx tests."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest


class FakeSuperDocMethods:
    """Record SDK ops called by the SDK; returns scripted responses.

    Used to drive unit tests without a real Keryx server.
    """

    def __init__(self) -> None:
        self.calls: list[tuple[str, Any]] = []
        self.scripted_returns: dict[str, Any] = {}

    def __getattr__(self, name: str) -> Any:
        return _FakeNamespace(self, [name])


class _FakeNamespace:
    def __init__(self, recorder: FakeSuperDocMethods, path: list[str]) -> None:
        self._recorder = recorder
        self._path = path

    def __getattr__(self, name: str) -> Any:
        return _FakeNamespace(self._recorder, [*self._path, name])

    async def __call__(self, params: dict | None = None) -> Any:
        op_name: str = ".".join(self._path)
        self._recorder.calls.append((op_name, params))
        if op_name in self._recorder.scripted_returns:
            return self._recorder.scripted_returns[op_name]
        # Sensible defaults
        if op_name == "insert":
            return {
                "result": {
                    "insertedNodes": [
                        {"nodeId": f"node_{len(self._recorder.calls)}", "type": "paragraph"},
                    ],
                },
            }
        if op_name == "find":
            return {"items": []}
        if op_name == "blocks.list":
            return []
        if op_name == "blocks.get":
            return {"nodeId": "node_x", "text": "", "inline": {}}
        if op_name == "save":
            return {"ok": True}
        if op_name == "close":
            return {"ok": True}
        if op_name == "create.table":
            return {"result": {"table": {"nodeId": f"table_{len(self._recorder.calls)}"}}}
        if op_name == "create.image":
            return {"result": {"image": {"nodeId": f"img_{len(self._recorder.calls)}"}}}
        if op_name == "tables.get":
            return {"rows": 2, "cols": 2, "styleId": "TableGrid"}
        if op_name == "tables.get_cell":
            return {"text": ""}
        return {"ok": True}


@pytest.fixture
def fake_sd_methods() -> FakeSuperDocMethods:
    """Fake Superdoc SDK surface. Attach to a mocked Session.doc."""
    return FakeSuperDocMethods()


@pytest.fixture
def mock_session(fake_sd_methods: FakeSuperDocMethods):
    """A mocked docx.client.Session whose `.doc` is the fake SDK."""
    from docx.client import Session

    session = MagicMock(spec=Session)
    session.asset_id = "asset_test"
    session.is_open = True
    session.doc = fake_sd_methods
    session.open = AsyncMock()
    session.save = AsyncMock()
    session.close = AsyncMock()
    return session
