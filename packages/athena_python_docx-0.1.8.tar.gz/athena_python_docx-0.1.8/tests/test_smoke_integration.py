"""End-to-end smoke test. Requires:
    SUPERDOC_COLLAB_TOKEN, KERYX_WS_URL, ATHENA_WORKSPACE_ID env vars
    TEST_ASSET_ID env var (pre-created SuperDoc asset on yhub)

Skipped if any env var is missing. Run with:
    uv run pytest tests/test_smoke_integration.py -v -m integration
"""

from __future__ import annotations

import os

import pytest

pytestmark = pytest.mark.integration


def _should_skip() -> bool:
    required = (
        "SUPERDOC_COLLAB_TOKEN",
        "KERYX_WS_URL",
        "ATHENA_WORKSPACE_ID",
        "TEST_ASSET_ID",
    )
    return any(not os.environ.get(k) for k in required)


@pytest.mark.skipif(_should_skip(), reason="integration env vars not set")
def test_end_to_end_basic_authoring() -> None:
    from docx import Document

    asset_id = os.environ["TEST_ASSET_ID"]

    with Document(asset_id) as doc:
        doc.add_heading("Smoke Test Report", level=1)

        p = doc.add_paragraph()
        r1 = p.add_run("This run is bold. ")
        r1.bold = True
        r2 = p.add_run("This run is italic.")
        r2.italic = True

        t = doc.add_table(rows=2, cols=2, style="TableGrid")
        t.cell(0, 0).text = "Header A"
        t.cell(0, 1).text = "Header B"
        t.cell(1, 0).text = "Row 1 Col A"
        t.cell(1, 1).text = "Row 1 Col B"

        doc.save()

    # Re-open and verify
    with Document(asset_id) as doc2:
        paragraphs = doc2.paragraphs
        assert any("Smoke Test Report" in p.text for p in paragraphs)
        tables = doc2.tables
        assert len(tables) >= 1
