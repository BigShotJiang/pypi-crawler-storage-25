# athena-python-docx SDK — Claude Instructions

## API Parity Rule (MANDATORY)

**This SDK MUST be a 100% exact replica of the standard [python-docx](https://python-docx.readthedocs.io/) API.**

Every class, method, property, and parameter name must match python-docx exactly. The goal is that any code written for python-docx works identically with this SDK — no surprises, no differences.

### What this means in practice

- **Do NOT add new methods** that don't exist in python-docx
- **Do NOT add new properties** that don't exist in python-docx
- **Do NOT rename parameters** — use the exact same parameter names as python-docx
- **Do NOT change method signatures** — if python-docx's `add_heading()` takes `(text, level=1)`, ours must too
- **Do NOT change return types** — if python-docx's `paragraph.runs` returns `list[Run]`, ours must too

### How to verify parity

Before adding or modifying any API surface:

1. Check the [python-docx documentation](https://python-docx.readthedocs.io/)
2. Check the [python-docx source code](https://github.com/python-openxml/python-docx)
3. Confirm the method/property/parameter exists with the same name and signature
4. If it doesn't exist in python-docx, **do not add it** without explicit user approval

Run `uv run pytest tests/test_python_docx_api_parity.py -v -s` to verify parity.

### Intentionally omitted (Superdoc SDK limitations)

These standard python-docx members don't apply to a Superdoc-backed SDK:

- `Paragraph._p`, `Run._r` — XML element access (no local XML)
- `Document.part`, `Paragraph.part`, `Run.part` — package part access
- `Document.core_properties.last_modified_by` — we use Keryx attribution instead
- `Document.settings` — Word app settings (not surfaced by Superdoc)
- `InlineShape.chart` — charts (Phase 2+)

### If you need a deviation

If there is a genuine technical reason why a deviation from python-docx is necessary:

1. **Stop and ask the user** before implementing
2. Explain what the deviation is and why it's needed
3. Get explicit confirmation that the deviation is acceptable
4. Document the deviation in the "Intentionally omitted" list above

## Architecture

This is an **async-Superdoc-SDK-backed client** that mimics the sync python-docx API.

- Sync façade (matches python-docx) — `doc.save()`, `paragraph.add_run()`
- Under the hood, a persistent event-loop thread in `_batching.py` runs `AsyncSuperDocClient` coroutines
- No XML manipulation — calls translate to Superdoc SDK ops (insert, find, replace, tables.*, format.apply, create.image, hyperlinks.wrap)
- Mutations write directly to Keryx Y.Doc; users and other agents see them live

## Development

```bash
uv venv
uv pip install -e ".[dev]"
uv run pytest tests/ -x -q
uv run pytest tests/test_python_docx_api_parity.py -v
```
