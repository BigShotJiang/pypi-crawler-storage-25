#!/usr/bin/env bash
# Publish athena-python-docx to PyPI.
#
# Usage:
#   ./scripts/publish.sh <version>
#
# Requires: python3 -m build, twine, and PyPI credentials in ~/.pypirc.

set -euo pipefail

if [ $# -ne 1 ]; then
  echo "Usage: $0 <version> (e.g., 0.1.0)"
  exit 1
fi

VERSION="$1"
SDK_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$SDK_DIR"

# Update version in pyproject.toml
sed -i.bak "s/^version = \".*\"/version = \"$VERSION\"/" pyproject.toml
rm -f pyproject.toml.bak

# Update version in docx/__init__.py
sed -i.bak "s/^__version__ = \".*\"/__version__ = \"$VERSION\"/" docx/__init__.py
rm -f docx/__init__.py.bak

# Clean previous builds
rm -rf dist/ build/ *.egg-info

# Build sdist + wheel
python3 -m build

# Upload
twine upload dist/*

echo "Published athena-python-docx==$VERSION"
