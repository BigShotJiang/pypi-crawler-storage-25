"""Paragraph alignment — python-docx parity (docx.enum.text).

python-docx exposes a richer set (DISTRIBUTE, THAI_JUSTIFY, etc.). Phase 1
implements the top 4 (LEFT, CENTER, RIGHT, JUSTIFY) — the others return
None from the getter and accept-but-no-op on the setter.
"""

from __future__ import annotations

from enum import Enum


class WD_ALIGN_PARAGRAPH(Enum):
    """Paragraph alignment. python-docx exposes these exact names."""

    LEFT = "left"
    CENTER = "center"
    RIGHT = "right"
    JUSTIFY = "justify"

    def to_superdoc(self) -> str:
        return self.value

    @classmethod
    def from_superdoc(cls, s: str) -> "WD_ALIGN_PARAGRAPH | None":
        try:
            return cls(s.lower())
        except ValueError:
            return None
