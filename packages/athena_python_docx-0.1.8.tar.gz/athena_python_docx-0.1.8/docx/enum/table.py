"""Table-related enums — python-docx parity (docx.enum.table).

Phase 1 includes only WD_ROW_HEIGHT_RULE as a placeholder; Phase 2 will
expand to WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT, etc.
"""

from __future__ import annotations

from enum import Enum


class WD_ROW_HEIGHT_RULE(Enum):
    AUTO = "auto"
    AT_LEAST = "atLeast"
    EXACTLY = "exact"
