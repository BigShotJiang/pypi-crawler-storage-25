"""Enum submodule — mirrors python-docx.enum."""
