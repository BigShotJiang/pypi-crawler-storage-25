"""The `Document` factory — matches python-docx's `docx.Document(path)`.

python-docx signature:
    Document(docx=None) -> Document

Our signature deviates from the path-based one because we don't open
.docx files from disk — we open Y.Doc assets from Keryx. The parameter
is reused: you pass an asset_id string where python-docx would take a
file path.

If the caller truly needs to load a local .docx (rare inside Daytona),
they can upload it first via the apps/api upload route (Phase 2+) or
use the existing `replaceFile` flow from the Olympus side.
"""

from __future__ import annotations

from docx.document import Document as _Document


def Document(docx: str | None = None) -> _Document:
    """Open a Word document for editing.

    Args:
        docx: Athena asset_id of the SuperDoc document to open.
              In python-docx this takes a file path; here it takes
              an asset_id. None is not supported in Phase 1.

    Returns:
        A Document instance bound to the asset.

    Raises:
        ValueError: if `docx` is None or empty.
    """
    if not docx:
        raise ValueError(
            "athena-python-docx requires an asset_id. "
            "Pass the SuperDoc asset ID as the first argument: "
            "Document('asset_xxx...')",
        )
    return _Document(asset_id=docx)
