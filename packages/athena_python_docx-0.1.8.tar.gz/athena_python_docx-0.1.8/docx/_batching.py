"""Sync→async bridge. Runs a single event loop in a background thread
and dispatches coroutines from sync callers.

This is the only place in the SDK that uses threading.
"""

from __future__ import annotations

import asyncio
import threading
from typing import Any, Coroutine, TypeVar

T = TypeVar("T")

# Default per-op timeout. Individual Superdoc SDK calls should complete well
# under this — the value is a safety net so a WebSocket stall or Keryx
# downtime surfaces a TimeoutError instead of wedging the calling thread
# until the outer Daytona INSTRUCTION_TIMEOUT_SECONDS kill.
DEFAULT_OP_TIMEOUT_SECONDS: float = 60.0

_loop: asyncio.AbstractEventLoop | None = None
_thread: threading.Thread | None = None
_lock = threading.Lock()


def _ensure_loop() -> asyncio.AbstractEventLoop:
    """Return the persistent background event loop. Starts it lazily."""
    global _loop, _thread

    with _lock:
        if _loop is not None and _loop.is_running():
            return _loop

        loop = asyncio.new_event_loop()
        loop_ready = threading.Event()

        def _run() -> None:
            asyncio.set_event_loop(loop)
            loop_ready.set()
            loop.run_forever()

        thread = threading.Thread(
            target=_run,
            name="docx-sdk-loop",
            daemon=True,
        )
        thread.start()
        loop_ready.wait(timeout=5)
        _loop = loop
        _thread = thread
        return loop


def run_sync(
    coro: Coroutine[Any, Any, T],
    *,
    timeout: float | None = DEFAULT_OP_TIMEOUT_SECONDS,
) -> T:
    """Run a coroutine on the background loop and block until it returns.

    Args:
        coro: The coroutine to execute.
        timeout: Maximum seconds to wait. ``None`` blocks indefinitely
            (use sparingly — prefer the default so stalls surface early).

    Raises:
        concurrent.futures.TimeoutError: if the coroutine does not
            complete within `timeout` seconds.
        The coroutine's exception, re-raised in the calling thread.
    """
    loop = _ensure_loop()
    future = asyncio.run_coroutine_threadsafe(coro, loop)
    return future.result(timeout=timeout)


def shutdown() -> None:
    """Stop the background event loop. For test teardown."""
    global _loop, _thread
    with _lock:
        if _loop is None:
            return
        _loop.call_soon_threadsafe(_loop.stop)
        if _thread is not None:
            _thread.join(timeout=5)
        _loop = None
        _thread = None
