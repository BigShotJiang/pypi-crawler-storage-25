"""Table, _Row, _Column, _Cell — python-docx parity.

Phase 1 supported:
    Table.rows / columns      — via doc.tables.get
    Table.cell(r, c)          — builds a _Cell proxy (lazy)
    Table.add_row / add_column — via doc.tables.insert_row / insert_column
    Table.style setter         — via doc.tables.set_style
    _Cell.text getter          — via doc.tables.get_cells (filtered)
    _Cell.merge(other)         — via doc.tables.merge_cells

Phase 1 NOT supported (NotImplementedError):
    Table.style getter         — via doc.tables.getStyles/getProperties
    _Cell.text setter          — needs find+replace-in-cell design
"""

from __future__ import annotations

import sys
from typing import TYPE_CHECKING

from docx._batching import run_sync
from docx.errors import ValidationError

if TYPE_CHECKING:
    from docx.client import Session


_STUB_SUFFIX = (
    " — not yet mapped to a Superdoc SDK primitive; see "
    "docx-studio/python-sdk/CLAUDE.md for Phase 2 scope."
)


def _log_warn(msg: str) -> None:
    print(f"[docx-sdk] WARN: {msg}", file=sys.stderr)


class Table:
    def __init__(self, *, session: "Session", node_id: str) -> None:
        self._session: "Session" = session
        self._node_id: str = node_id

    def _fresh_node_id(self) -> str:
        """Re-find this table by its original nodeId first; warn+last-in-list
        as a last resort (set_style etc. can rotate ids)."""
        find_result: object = run_sync(
            self._session.doc.find({"type": "table"}),
        )
        items_obj: object = (
            find_result.get("items", []) if isinstance(find_result, dict) else []
        )
        items: list = items_obj if isinstance(items_obj, list) else []
        for item in items:
            if not isinstance(item, dict):
                continue
            addr = item.get("address", {})
            if isinstance(addr, dict) and addr.get("nodeId") == self._node_id:
                return self._node_id
        if items:
            last = items[-1] if isinstance(items[-1], dict) else {}
            last_addr = last.get("address", {}) if isinstance(last, dict) else {}
            new_id: str = str(last_addr.get("nodeId", ""))
            if new_id:
                _log_warn(
                    f"table nodeId rotated: {self._node_id} -> {new_id}",
                )
                self._node_id = new_id
        return self._node_id

    @property
    def rows(self) -> list["_Row"]:
        nid: str = self._fresh_node_id()
        info: object = run_sync(self._session.doc.tables.get({"nodeId": nid}))
        info_dict: dict = info if isinstance(info, dict) else {}
        # doc.tables.get may return row count at various paths
        row_count: int = int(
            info_dict.get("rows")
            or info_dict.get("rowCount")
            or (info_dict.get("table", {}) or {}).get("rows")
            or 0,
        )
        return [_Row(table=self, index=i) for i in range(row_count)]

    @property
    def columns(self) -> list["_Column"]:
        nid: str = self._fresh_node_id()
        info: object = run_sync(self._session.doc.tables.get({"nodeId": nid}))
        info_dict: dict = info if isinstance(info, dict) else {}
        col_count: int = int(
            info_dict.get("columns")
            or info_dict.get("cols")
            or info_dict.get("columnCount")
            or (info_dict.get("table", {}) or {}).get("columns")
            or 0,
        )
        return [_Column(table=self, index=j) for j in range(col_count)]

    def cell(self, row_idx: int, col_idx: int) -> "_Cell":
        return _Cell(table=self, row=row_idx, col=col_idx)

    def add_row(self) -> "_Row":
        nid: str = self._fresh_node_id()
        row_count: int = len(self.rows)
        if row_count < 1:
            raise ValidationError(f"Cannot add row to empty table {nid}")
        # Real params: nodeId, rowIndex, position, count
        run_sync(
            self._session.doc.tables.insert_row(
                {
                    "nodeId": nid,
                    "rowIndex": row_count - 1,
                    "position": "below",
                    "count": 1,
                },
            ),
        )
        return _Row(table=self, index=row_count)

    def add_column(self) -> "_Column":
        nid: str = self._fresh_node_id()
        col_count: int = len(self.columns)
        if col_count < 1:
            raise ValidationError(f"Cannot add column to empty table {nid}")
        run_sync(
            self._session.doc.tables.insert_column(
                {
                    "nodeId": nid,
                    "columnIndex": col_count - 1,
                    "position": "right",
                    "count": 1,
                },
            ),
        )
        return _Column(table=self, index=col_count)

    @property
    def style(self) -> str | None:
        raise NotImplementedError("Table.style getter" + _STUB_SUFFIX)

    @style.setter
    def style(self, value: str | None) -> None:
        nid: str = self._fresh_node_id()
        run_sync(
            self._session.doc.tables.set_style(
                {"nodeId": nid, "styleId": value or "TableGrid"},
            ),
        )


class _Row:
    def __init__(self, *, table: Table, index: int) -> None:
        self._table: Table = table
        self._index: int = index

    @property
    def cells(self) -> list["_Cell"]:
        col_count: int = len(self._table.columns)
        return [
            _Cell(table=self._table, row=self._index, col=j)
            for j in range(col_count)
        ]


class _Column:
    def __init__(self, *, table: Table, index: int) -> None:
        self._table: Table = table
        self._index: int = index

    @property
    def cells(self) -> list["_Cell"]:
        row_count: int = len(self._table.rows)
        return [
            _Cell(table=self._table, row=i, col=self._index)
            for i in range(row_count)
        ]


class _Cell:
    def __init__(self, *, table: Table, row: int, col: int) -> None:
        self._table: Table = table
        self._row: int = row
        self._col: int = col

    @property
    def text(self) -> str:
        nid: str = self._table._fresh_node_id()
        result: object = run_sync(
            self._table._session.doc.tables.get_cells(
                {
                    "nodeId": nid,
                    "rowIndex": self._row,
                    "columnIndex": self._col,
                },
            ),
        )
        if not isinstance(result, dict):
            return ""
        cells_obj: object = result.get("cells", result.get("items", []))
        cells: list = cells_obj if isinstance(cells_obj, list) else []
        if not cells or not isinstance(cells[0], dict):
            return ""
        first = cells[0]
        text: object = first.get("text")
        if isinstance(text, str):
            return text
        return ""

    @text.setter
    def text(self, value: str) -> None:  # noqa: ARG002
        raise NotImplementedError("_Cell.text setter" + _STUB_SUFFIX)

    def merge(self, other: "_Cell") -> "_Cell":
        if other._table is not self._table:
            raise ValidationError(
                "Cannot merge cells from different tables.",
            )
        nid: str = self._table._fresh_node_id()
        run_sync(
            self._table._session.doc.tables.merge_cells(
                {
                    "nodeId": nid,
                    "start": {"rowIndex": self._row, "columnIndex": self._col},
                    "end": {"rowIndex": other._row, "columnIndex": other._col},
                },
            ),
        )
        return self
