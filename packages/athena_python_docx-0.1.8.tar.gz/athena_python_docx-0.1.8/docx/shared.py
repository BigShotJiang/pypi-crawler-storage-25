"""Length and color types — python-docx parity.

python-docx defines these in docx.shared. We mirror the class surface,
but delegate underlying math (Inches→Emu, Pt→Emu) to simple formulas.
"""

from __future__ import annotations


class Emu(int):
    """English Metric Unit. 914400 EMU = 1 inch."""

    def __new__(cls, value: int | float) -> "Emu":
        return super().__new__(cls, int(value))

    @property
    def emu(self) -> int:
        return int(self)

    @property
    def inches(self) -> float:
        return int(self) / 914400

    @property
    def cm(self) -> float:
        return int(self) / 360000

    @property
    def mm(self) -> float:
        return int(self) / 36000

    @property
    def pt(self) -> float:
        return int(self) / 12700


class Inches(Emu):
    def __new__(cls, value: float) -> "Inches":
        return super().__new__(cls, int(value * 914400))  # type: ignore[return-value]


class Pt(Emu):
    def __new__(cls, value: float) -> "Pt":
        return super().__new__(cls, int(value * 12700))  # type: ignore[return-value]


class Cm(Emu):
    def __new__(cls, value: float) -> "Cm":
        return super().__new__(cls, int(value * 360000))  # type: ignore[return-value]


class Mm(Emu):
    def __new__(cls, value: float) -> "Mm":
        return super().__new__(cls, int(value * 36000))  # type: ignore[return-value]


class RGBColor(tuple):
    """24-bit RGB color. python-docx parity."""

    def __new__(cls, r: int, g: int, b: int) -> "RGBColor":
        if not all(0 <= v <= 255 for v in (r, g, b)):
            raise ValueError(
                f"RGBColor components must be 0..255; got ({r}, {g}, {b})",
            )
        return super().__new__(cls, (r, g, b))  # type: ignore[arg-type]

    def __str__(self) -> str:
        r, g, b = self
        return f"{r:02X}{g:02X}{b:02X}"

    def __repr__(self) -> str:
        return f"RGBColor(0x{self[0]:02X}, 0x{self[1]:02X}, 0x{self[2]:02X})"

    @classmethod
    def from_string(cls, rgb_hex_str: str) -> "RGBColor":
        s: str = rgb_hex_str.lstrip("#")
        if len(s) != 6:
            raise ValueError(
                f"RGBColor.from_string expects 6 hex chars; got {rgb_hex_str!r}",
            )
        return cls(int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16))
