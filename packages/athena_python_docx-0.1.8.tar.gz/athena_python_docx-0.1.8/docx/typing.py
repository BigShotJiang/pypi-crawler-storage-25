"""Internal TypedDicts shared across the SDK."""

from __future__ import annotations

from typing import TypedDict


class UserInfo(TypedDict):
    """Identity info passed to AsyncSuperDocClient for activity log attribution."""

    name: str
    email: str


class TextRange(TypedDict):
    """A Superdoc text range target.

    Used in format.apply, replace, hyperlinks.wrap, etc.
    """

    kind: str
    blockId: str
    range: "CharRange"


class CharRange(TypedDict):
    """Start/end character offsets within a block."""

    start: int
    end: int
