"""Superdoc SDK session wrapper — auth, open/close lifecycle, error mapping.

This module is the only place in the SDK that talks to `superdoc_sdk`
directly. All other classes (Document, Paragraph, Run, Table) go
through a `Session` instance.

Environment variables expected inside Daytona:
    SUPERDOC_COLLAB_TOKEN: short-lived Keryx JWT (signed by Athena backend)
    KERYX_WS_URL:          Keryx WebSocket base URL (e.g. "wss://keryx.athena...")
    ATHENA_WORKSPACE_ID:   workspace routing path segment
"""

from __future__ import annotations

import asyncio
import os
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, Any

from docx.errors import (
    AuthenticationError,
    DocumentClosedError,
    SessionError,
)

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

_TOKEN_ENV = "SUPERDOC_COLLAB_TOKEN"  # noqa: S105
_WS_URL_ENV = "KERYX_WS_URL"
_WORKSPACE_ENV = "ATHENA_WORKSPACE_ID"


def _log_info(msg: str) -> None:
    """Minimal stderr logger. We avoid loguru here to keep the SDK
    runtime dependency tree small — this code runs inside Daytona sandboxes.
    """
    import sys

    print(f"[docx-sdk] {msg}", file=sys.stderr)


def _log_warning(msg: str) -> None:
    import sys

    print(f"[docx-sdk] WARN: {msg}", file=sys.stderr)


class Session:
    """Manages the lifecycle of an AsyncSuperDocClient session.

    Lifecycle:
        create Session (does NOT open yet) → first op triggers open() →
        subsequent ops reuse the same client → save() flushes → close()
        disposes.

    Thread safety: NOT thread-safe. Each Document should have its own
    Session. The sync facade serializes all calls through a single
    event-loop thread (see _batching.py).
    """

    def __init__(
        self,
        *,
        asset_id: str,
        user_info: dict[str, str] | None = None,
    ) -> None:
        self._asset_id: str = asset_id
        self._user_info: dict[str, str] = user_info or {
            "name": "Athena Agent",
            "email": "agent@athenaintel.com",
        }
        self._client: Any | None = None
        self._doc_handle: Any | None = None
        self._opened: bool = False
        self._closed: bool = False

    @property
    def asset_id(self) -> str:
        return self._asset_id

    @property
    def is_open(self) -> bool:
        return self._opened and not self._closed

    async def open(self) -> None:
        """Open the Superdoc SDK session against Keryx.

        Raises:
            AuthenticationError: if SUPERDOC_COLLAB_TOKEN is missing/invalid.
            SessionError: on any other open-time failure.
        """
        if self._closed:
            raise DocumentClosedError(
                f"Session for asset {self._asset_id} was already closed.",
            )
        if self._opened:
            return

        token: str | None = os.environ.get(_TOKEN_ENV)
        ws_url: str | None = os.environ.get(_WS_URL_ENV)
        workspace_id: str | None = os.environ.get(_WORKSPACE_ENV)

        if not token:
            raise AuthenticationError(
                f"Missing environment variable {_TOKEN_ENV}. "
                "The Athena backend must mint a short-lived Keryx JWT "
                "and inject it into the Daytona sandbox.",
            )
        if not ws_url:
            raise SessionError(
                f"Missing environment variable {_WS_URL_ENV}.",
            )
        if not workspace_id:
            raise SessionError(
                f"Missing environment variable {_WORKSPACE_ENV}.",
            )

        # Lazy import so `import docx` doesn't pay for superdoc_sdk init cost
        from superdoc import AsyncSuperDocClient
        from superdoc.generated.client import (
            DocOpenParams,
            DocOpenParamsCollaborationVariant1,
        )

        collab_base_url: str = f"{ws_url}/ws/{workspace_id}"
        self._client = AsyncSuperDocClient(
            user=self._user_info,
            env={_TOKEN_ENV: token},
            request_timeout_ms=30_000,
            watchdog_timeout_ms=60_000,
        )

        collab_config: DocOpenParamsCollaborationVariant1 = {
            "url": collab_base_url,
            "documentId": self._asset_id,
            "tokenEnv": _TOKEN_ENV,
            "providerType": "y-websocket",
        }
        open_params: DocOpenParams = {"collaboration": collab_config}

        try:
            self._doc_handle = await self._client.open(open_params)
        except Exception as e:
            msg: str = str(e).lower()
            if "401" in msg or "unauthorized" in msg or "forbidden" in msg:
                raise AuthenticationError(
                    f"Keryx rejected the collab token: {e}",
                ) from e
            raise SessionError(
                f"Failed to open Superdoc session for {self._asset_id}: {e}",
            ) from e

        self._opened = True
        _log_info(f"Opened {self._asset_id}")

    @property
    def doc(self) -> Any:
        """Return the opened Superdoc doc handle.

        Lazy-opens on first access. Blocks on the event-loop thread
        via the sync bridge; do not call this from inside a coroutine.
        """
        if not self._opened:
            raise SessionError(
                "Session not yet opened; call await session.open() first "
                "or use the sync facade via Document().",
            )
        if self._closed:
            raise DocumentClosedError(
                f"Session for asset {self._asset_id} is closed.",
            )
        return self._doc_handle

    async def save(self, *, in_place: bool = True) -> None:  # noqa: ARG002
        """Ensure pending mutations have flushed to Keryx.

        In collab mode (our only mode), the Y-Websocket provider streams
        updates to Keryx as they happen — there's no explicit save RPC
        to call. The underlying Superdoc SDK's ``save({"inPlace": True})``
        targets file-backed docs and errors with "this session has no
        source path" for collab sessions. So save() is a thin flush:
        sleep briefly so in-flight WebSocket frames land, then return.

        The ``in_place`` kwarg is accepted for python-docx parity but
        has no effect in collab mode (there is no alternate target).
        """
        if not self._opened:
            raise SessionError("Cannot save a session that was never opened.")
        if self._closed:
            raise DocumentClosedError(f"Session {self._asset_id} is closed.")

        # Short flush — matches superdoc_write_utils.py's 1-second pre-close
        # delay. Keeps a single in-flight frame from being dropped on close.
        await asyncio.sleep(1)
        _log_info(f"Saved (flushed) {self._asset_id}")

    async def close(self) -> None:
        """Close the Superdoc session. Idempotent."""
        if self._closed:
            return

        if self._opened and self._doc_handle is not None:
            try:
                # Match the 1-second flush delay from superdoc_write_utils
                # before tearing down the WebSocket
                await asyncio.sleep(1)
                await self._doc_handle.close({"discard": True})
            except Exception as close_err:
                _log_warning(
                    f"Doc close failed for {self._asset_id}: {close_err}",
                )

        if self._client is not None:
            try:
                await self._client.dispose()
            except Exception as dispose_err:
                _log_warning(
                    f"Client dispose failed for {self._asset_id}: {dispose_err}",
                )

        self._closed = True
        _log_info(f"Closed {self._asset_id}")


@asynccontextmanager
async def open_session(
    *,
    asset_id: str,
    user_info: dict[str, str] | None = None,
) -> "AsyncIterator[Session]":
    """Async context manager for a Session. Yields an opened session."""
    session = Session(asset_id=asset_id, user_info=user_info)
    try:
        await session.open()
        yield session
    finally:
        await session.close()
