"""Paragraph — mirrors python-docx's Paragraph class.

Phase 1 supported:
    .text (getter, via doc.get_node_by_id)

Phase 1 NOT supported (raises NotImplementedError with a clear message):
    .text setter       — Superdoc has no direct block-text replace
    .runs              — returns []; iterating post-hoc runs requires
                         a node-content walker we haven't built yet
    .style getter      — works via get_node_by_id
    .style setter      — uses doc.styles.paragraph.set_style
    .alignment get/set — no direct Superdoc equivalent wired yet
    .add_run(text)     — works via doc.insert with target at end of block

All stubs point at the follow-up design note in CLAUDE.md so agents
see actionable errors instead of opaque AttributeErrors from the
underlying SDK.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from docx._batching import run_sync

if TYPE_CHECKING:
    from docx.client import Session
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.text.run import Run


_STUB_SUFFIX = (
    " — not yet mapped to a Superdoc SDK primitive; see "
    "docx-studio/python-sdk/CLAUDE.md for Phase 2 scope."
)


def _node_text(session: "Session", node_id: str) -> str:
    """Fetch a block's full text via doc.get_node_by_id.

    The response shape for a paragraph is:
        {"node": {"paragraph": {"inlines": [{"run": {"text": "..."}}, ...]}}}
    We concatenate each run's ``text`` in order. Non-paragraph blocks or
    empty responses return ``""``.
    """
    info: object = run_sync(
        session.doc.get_node_by_id({"id": node_id}),
    )
    if not isinstance(info, dict):
        return ""
    node: object = info.get("node")
    if not isinstance(node, dict):
        return ""
    paragraph: object = node.get("paragraph")
    if not isinstance(paragraph, dict):
        return ""
    inlines: object = paragraph.get("inlines")
    if not isinstance(inlines, list):
        return ""
    parts: list[str] = []
    for inline in inlines:
        if not isinstance(inline, dict):
            continue
        run: object = inline.get("run")
        if not isinstance(run, dict):
            continue
        text: object = run.get("text")
        if isinstance(text, str):
            parts.append(text)
    return "".join(parts)


class Paragraph:
    """A paragraph block in a Word document."""

    def __init__(self, *, session: "Session", node_id: str) -> None:
        self._session: "Session" = session
        self._node_id: str = node_id

    @property
    def text(self) -> str:
        """Return the plain-text content of this paragraph."""
        return _node_text(self._session, self._node_id)

    @text.setter
    def text(self, value: str) -> None:  # noqa: ARG002
        raise NotImplementedError(
            "Paragraph.text setter" + _STUB_SUFFIX,
        )

    @property
    def runs(self) -> list["Run"]:
        """Return the runs in this paragraph.

        Returns `[]` until the Phase 2 node-content walker lands.
        """
        return []

    @property
    def style(self) -> str | None:
        info: object = run_sync(
            self._session.doc.get_node_by_id({"id": self._node_id}),
        )
        if not isinstance(info, dict):
            return None
        node: object = info.get("node")
        if not isinstance(node, dict):
            return None
        style_id: object = node.get("styleId") or node.get("style")
        return str(style_id) if style_id else None

    @style.setter
    def style(self, value: str | None) -> None:
        target: dict = {
            "kind": "block",
            "nodeType": "paragraph",
            "nodeId": self._node_id,
        }
        run_sync(
            self._session.doc.styles.paragraph.set_style(
                {"target": target, "styleId": value or "Normal"},
            ),
        )

    @property
    def alignment(self) -> "WD_ALIGN_PARAGRAPH | None":
        raise NotImplementedError(
            "Paragraph.alignment getter" + _STUB_SUFFIX,
        )

    @alignment.setter
    def alignment(self, value: "WD_ALIGN_PARAGRAPH | None") -> None:  # noqa: ARG002
        raise NotImplementedError(
            "Paragraph.alignment setter" + _STUB_SUFFIX,
        )

    def add_run(
        self,
        text: str = "",
        style: str | None = None,  # noqa: ARG002
    ) -> "Run":
        """Append a run to this paragraph.

        Inserts `text` at the END of the block via doc.insert with a
        block-targeted range. Returns a Run proxy that references the
        newly-inserted character span.
        """
        from docx.text.run import Run

        # Fetch the block's current text to know where "end of block" is.
        current: str = _node_text(self._session, self._node_id)
        start: int = len(current)

        # Superdoc expects a selection target with text cursors. A zero-
        # length selection (start == end) is an insertion point, not a
        # replace-range.
        cursor: dict = {
            "kind": "text",
            "blockId": self._node_id,
            "offset": start,
        }
        run_sync(
            self._session.doc.insert(
                {
                    "target": {
                        "kind": "selection",
                        "start": cursor,
                        "end": cursor,
                    },
                    "value": text,
                    "type": "text",
                },
            ),
        )
        return Run(
            session=self._session,
            block_id=self._node_id,
            range_=(start, start + len(text)),
        )
