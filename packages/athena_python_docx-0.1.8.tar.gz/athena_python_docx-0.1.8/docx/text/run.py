"""Run and Font — mirrors python-docx's run.Run and text.font.Font.

Phase 1 supported:
    Run.text  getter — via doc.get_node_by_id, sliced by range
    Run.text  setter — via doc.replace (exists)
    Run.bold / italic / underline setters — via doc.format.apply (exists)
    Font.name / size / color.rgb setters  — via doc.format.apply

Phase 1 NOT supported (NotImplementedError with a clear message):
    Run.bold / italic / underline getters   — needs inline-format reader
    Font.name / size / color.rgb getters    — needs inline-format reader
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from docx._batching import run_sync
from docx.shared import Pt, RGBColor

if TYPE_CHECKING:
    from docx.client import Session


_STUB_SUFFIX = (
    " — not yet mapped to a Superdoc SDK primitive; see "
    "docx-studio/python-sdk/CLAUDE.md for Phase 2 scope."
)


def _block_text(session: "Session", block_id: str) -> str:
    info: object = run_sync(
        session.doc.get_node_by_id({"id": block_id}),
    )
    if not isinstance(info, dict):
        return ""
    node: object = info.get("node")
    if isinstance(node, dict):
        text: object = node.get("text")
        if isinstance(text, str):
            return text
    return ""


class Run:
    """A text run — a contiguous span with uniform formatting."""

    def __init__(
        self,
        *,
        session: "Session",
        block_id: str,
        range_: tuple[int, int],
    ) -> None:
        self._session: "Session" = session
        self._block_id: str = block_id
        self._range: tuple[int, int] = range_

    @property
    def _text_range(self) -> dict:
        return {
            "kind": "text",
            "blockId": self._block_id,
            "range": {"start": self._range[0], "end": self._range[1]},
        }

    @property
    def text(self) -> str:
        full: str = _block_text(self._session, self._block_id)
        return full[self._range[0] : self._range[1]]

    @text.setter
    def text(self, value: str) -> None:
        run_sync(
            self._session.doc.replace(
                {"target": self._text_range, "text": value},
            ),
        )
        new_end: int = self._range[0] + len(value)
        self._range = (self._range[0], new_end)

    def _apply_inline(self, **kwargs: object) -> None:
        run_sync(
            self._session.doc.format.apply(
                {"target": self._text_range, "inline": kwargs},
            ),
        )

    @property
    def bold(self) -> bool | None:
        raise NotImplementedError("Run.bold getter" + _STUB_SUFFIX)

    @bold.setter
    def bold(self, value: bool | None) -> None:
        if value is None:
            return
        self._apply_inline(bold=value)

    @property
    def italic(self) -> bool | None:
        raise NotImplementedError("Run.italic getter" + _STUB_SUFFIX)

    @italic.setter
    def italic(self, value: bool | None) -> None:
        if value is None:
            return
        self._apply_inline(italic=value)

    @property
    def underline(self) -> bool | None:
        raise NotImplementedError("Run.underline getter" + _STUB_SUFFIX)

    @underline.setter
    def underline(self, value: bool | None) -> None:
        if value is None:
            return
        self._apply_inline(underline=value)

    @property
    def font(self) -> "Font":
        return Font(self)


class Font:
    """Font properties of a Run. Accessed via `run.font`; do not instantiate."""

    def __init__(self, run: Run) -> None:
        self._run: Run = run

    @property
    def name(self) -> str | None:
        raise NotImplementedError("Font.name getter" + _STUB_SUFFIX)

    @name.setter
    def name(self, value: str | None) -> None:
        if value is None:
            return
        self._run._apply_inline(fontFamily=value)

    @property
    def size(self) -> "Pt | None":
        raise NotImplementedError("Font.size getter" + _STUB_SUFFIX)

    @size.setter
    def size(self, value: "Pt | int | None") -> None:
        if value is None:
            return
        pt_value: float = (
            float(value.pt) if hasattr(value, "pt") else float(value)
        )
        self._run._apply_inline(fontSize=pt_value)

    @property
    def color(self) -> "_ColorProxy":
        return _ColorProxy(self._run)


class _ColorProxy:
    """Matches python-docx's `run.font.color` — has .rgb get/set."""

    def __init__(self, run: Run) -> None:
        self._run: Run = run

    @property
    def rgb(self) -> "RGBColor | None":
        raise NotImplementedError("Font.color.rgb getter" + _STUB_SUFFIX)

    @rgb.setter
    def rgb(self, value: "RGBColor | None") -> None:
        if value is None:
            return
        self._run._apply_inline(color=str(value))
