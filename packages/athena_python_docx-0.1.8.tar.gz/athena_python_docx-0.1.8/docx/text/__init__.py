"""Text submodule — Paragraph and Run (mirrors python-docx.text)."""

from __future__ import annotations

from docx.text.paragraph import Paragraph
from docx.text.run import Run

__all__ = ["Paragraph", "Run"]
