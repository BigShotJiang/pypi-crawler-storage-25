# athena-python-docx

Drop-in replacement for [python-docx](https://python-docx.readthedocs.io/) that connects to Athena's Superdoc + Keryx collaborative document stack.

## Quick start

```python
from docx import Document
from docx.shared import Inches, Pt, RGBColor

# Open an existing SuperDoc asset by its Athena asset_id
with Document("asset_abc123") as doc:
    doc.add_heading("Market Analysis", level=1)

    p = doc.add_paragraph()
    r = p.add_run("Revenue grew ")
    highlight = p.add_run("12.3% year-over-year")
    highlight.bold = True
    highlight.font.color.rgb = RGBColor(0x00, 0x80, 0x00)
    p.add_run(".")

    t = doc.add_table(rows=2, cols=2, style="TableGrid")
    t.cell(0, 0).text = "Segment"
    t.cell(0, 1).text = "Revenue"
    t.cell(1, 0).text = "Enterprise"
    t.cell(1, 1).text = "$4.3M"

    doc.save()
```

## API parity rule

This SDK mirrors python-docx's public API **exactly**. See `CLAUDE.md` for the full contract.

## Development

```bash
uv venv
uv pip install -e ".[dev]"
uv run pytest tests/ -x
```

## Environment variables

Required when connecting to Keryx (set by Athena backend when executing in Daytona):

- `SUPERDOC_COLLAB_TOKEN` — short-lived Keryx JWT
- `KERYX_WS_URL` — Keryx WebSocket base URL
- `ATHENA_WORKSPACE_ID` — workspace routing segment

## License

MIT
