import speech_recognition as sr

def listen():
    recognizer = sr.Recognizer()

    with sr.Microphone() as source:
        print("Listening...")

        audio = recognizer.listen(source)

        try:
            text = recognizer.recognize_google(audio)

            print(f"User: {text}")

            return text

        except Exception as e:
            print("Error:", e)