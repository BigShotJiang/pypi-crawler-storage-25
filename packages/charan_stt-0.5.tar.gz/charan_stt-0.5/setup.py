from setuptools import setup, find_packages

setup(
    name="charan-stt",
    version="0.5",
    author="Charan Harsha",
    author_email="charanharsha@gmail.com",
    description="Speech to text package",
    packages=find_packages(),
    install_requires=[
        "selenium",
        "webdriver-manager"
    ],
    python_requires=">=3.8",
)