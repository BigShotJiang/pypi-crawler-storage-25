from pathlib import Path
import sys
import yaml
from importlib.resources import files

# Treiber-Pakete, die als Fallback fuer Host-/App-YAMLs durchsucht werden.
# Diese werden optional importiert (try/except ImportError).
_DRIVER_PACKAGES = [
    "okw_web_selenium.locators",
    "okw_java_remoteswing.locators",
]


# -----------------------------------------------------------------------
# !include Tag -- Bindet externe YAML-Dateien ein
# -----------------------------------------------------------------------
class _IncludeLoader(yaml.SafeLoader):
    """SafeLoader mit ``!include``-Unterstuetzung.

    Syntax in YAML::

        MainFrame: !include dialogs/MainFrame.yaml

    Der Pfad wird relativ zur YAML-Datei aufgeloest, die das
    ``!include`` enthaelt.
    """


def _include_constructor(loader: _IncludeLoader, node: yaml.ScalarNode):
    """Laedt die referenzierte YAML-Datei und gibt ihren Inhalt zurueck."""
    rel_path = loader.construct_scalar(node)
    # Basisverzeichnis der aktuell geladenen YAML-Datei
    base_dir = Path(loader.name).resolve().parent
    include_path = (base_dir / rel_path).resolve()

    if not include_path.exists():
        raise FileNotFoundError(
            f"!include: Datei nicht gefunden: {include_path} "
            f"(referenziert aus {loader.name})"
        )

    with open(include_path, "r", encoding="utf-8") as f:
        return yaml.load(f, _IncludeLoader)


_IncludeLoader.add_constructor("!include", _include_constructor)


# -----------------------------------------------------------------------
# !include-merge Tag -- Bindet externe YAML ein und merged flach
# -----------------------------------------------------------------------
class _MergeMarker:
    """Marker fuer !include-merge — wird beim Post-Processing aufgeloest."""
    def __init__(self, data: dict):
        self.data = data


def _include_merge_constructor(loader: _IncludeLoader, node: yaml.ScalarNode):
    """Laedt eine YAML-Datei und markiert den Inhalt zum flachen Mergen."""
    content = _include_constructor(loader, node)
    if not isinstance(content, dict):
        raise TypeError(
            f"!include-merge: Datei muss ein dict liefern, "
            f"bekommen: {type(content).__name__}"
        )
    return _MergeMarker(content)


_IncludeLoader.add_constructor("!include-merge", _include_merge_constructor)


def _resolve_merges(data):
    """Loest _MergeMarker rekursiv auf: merged Inhalt flach in den Parent."""
    if isinstance(data, dict):
        merged = {}
        for key, value in data.items():
            if isinstance(value, _MergeMarker):
                for mk, mv in value.data.items():
                    merged[mk] = _resolve_merges(mv)
            else:
                merged[key] = _resolve_merges(value)
        return merged
    if isinstance(data, list):
        return [_resolve_merges(item) for item in data]
    return data


# -----------------------------------------------------------------------
# Oeffentliche API
# -----------------------------------------------------------------------
def _get_robot_source_dir() -> "Path | None":
    """Return the directory of the currently executing .robot file, or None."""
    try:
        from robot.libraries.BuiltIn import BuiltIn
        source = BuiltIn().get_variable_value("${SUITE SOURCE}")
        if source:
            p = Path(source)
            return p.parent if p.is_file() else p
    except Exception:
        pass
    return None


def _add_project_to_sys_path(yaml_path: Path):
    """Fuegt das Projektverzeichnis (Parent von locators/) zu sys.path hinzu.

    Damit koennen projektspezifische Widget-Klassen per ``class:``-Key im
    YAML importiert werden, z.B.::

        class: widgets.webpark_datefield.WebPark_DateField

    Das ``widgets``-Package liegt neben ``locators/`` im Projektverzeichnis.
    Durch den automatischen sys.path-Eintrag ist kein ``--pythonpath``
    noetig.
    """
    project_dir = yaml_path.resolve().parent.parent
    project_str = str(project_dir)
    if project_str not in sys.path:
        sys.path.insert(0, project_str)


def load_yaml_with_fallback(name: str) -> dict:
    """
    Laedt eine YAML-Datei aus dem Projektverzeichnis oder faellt auf
    Treiber-Pakete zurueck.
    ``name`` ist ein relativer Pfad ohne ".yaml" - z. B. "LoginDialog"

    Suchreihenfolge:
    1. Projektverzeichnis: ./locators/<name>.yaml  (relativ zum CWD)
    2. Robot-Suite-Verzeichnis: <suite-dir>/locators/<name>.yaml
    3. Treiber-Pakete: okw_web_selenium.locators, okw_java_remoteswing.locators (falls installiert)

    Unterstuetzt ``!include`` in allen YAML-Dateien.

    Seiteneffekt: Das Projektverzeichnis (Parent von locators/) wird
    automatisch zu sys.path hinzugefuegt, damit projektspezifische
    Widget-Klassen importiert werden koennen.
    """
    parts = name.split("/")
    searched = []

    # 1. Projektverzeichnis: ./locators/<name>.yaml
    local_path = Path("locators") / f"{name}.yaml"
    searched.append(f"CWD ./locators/")
    if local_path.exists():
        _add_project_to_sys_path(local_path)
        with open(local_path, "r", encoding="utf-8") as f:
            return _resolve_merges(yaml.load(f, _IncludeLoader))

    # 2. Robot-Suite-Verzeichnis und Elternverzeichnisse
    #    Sucht locators/ neben und oberhalb der .robot-Datei.
    #    z.B. tests/Test.robot -> sucht tests/locators/, dann ./locators/
    suite_dir = _get_robot_source_dir()
    if suite_dir:
        for ancestor in [suite_dir, suite_dir.parent, suite_dir.parent.parent]:
            candidate = ancestor / "locators" / f"{name}.yaml"
            searched.append(str(ancestor / "locators/"))
            if candidate.exists():
                _add_project_to_sys_path(candidate)
                with open(candidate, "r", encoding="utf-8") as f:
                    return _resolve_merges(yaml.load(f, _IncludeLoader))

    # 3. Treiber-Pakete (optional installiert)
    for pkg in _DRIVER_PACKAGES:
        result = _try_load_from_package(pkg, parts)
        if result is not None:
            return result
    searched.append(f"driver packages: {', '.join(_DRIVER_PACKAGES)}")

    raise FileNotFoundError(
        f"App YAML not found: {name}.yaml "
        f"(searched: {', '.join(searched)})"
    )


def _try_load_from_package(base_pkg: str, parts: list[str]) -> dict | None:
    """Versucht eine YAML-Datei aus einem Paket zu laden. Gibt None zurueck bei Fehler."""
    try:
        if len(parts) == 1:
            res_path = files(base_pkg).joinpath(f"{parts[0]}.yaml")
        else:
            subpkg = ".".join([base_pkg] + parts[:-1])
            res_path = files(subpkg).joinpath(f"{parts[-1]}.yaml")

        if res_path.exists():
            with open(res_path, "r", encoding="utf-8") as f:
                return _resolve_merges(yaml.load(f, _IncludeLoader))
    except (ImportError, ModuleNotFoundError, TypeError):
        # Paket nicht installiert - ueberspringen
        pass
    return None
