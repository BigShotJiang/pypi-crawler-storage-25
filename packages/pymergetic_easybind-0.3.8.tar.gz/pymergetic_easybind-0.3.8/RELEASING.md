# Releasing to PyPI

## How the version is chosen

- The **PyPI distribution** and **`pip install`** name are **`pymergetic-easybind`**. **Import** as **`pymergetic.easybind`**.
- The **version string** is computed automatically by **setuptools-scm** from **Git**:
  - Tag the release commit with **`vMAJOR.MINOR.PATCH`** (leading `v` is supported), e.g. `v0.1.0`.
  - On **exactly** that tagged commit, the wheel/sdist version is **`0.1.0`** (with `no-guess-dev` + `no-local-version`, suitable for PyPI).
  - Untagged / between tags you get a **development** version like `0.0.1.post1.devN` (fallback + distance). Fine for test uploads to TestPyPI; for production PyPI, **always build from a clean tree on a release tag**.

## Renamed from `easybind` on PyPI

Older releases were published as **`easybind`** (`pypi.org/project/easybind/`). New releases use **`pymergetic-easybind`**. PyPI does not rename projects in place — the next **`v*`** tag creates/uploads under the new name automatically (same CI workflow; `[project].name` in `pyproject.toml` drives the target).

**Downstream pins:** change `easybind~=X.Y.Z` → `pymergetic-easybind~=X.Y.Z`. Optionally publish one final **`easybind`** metapackage release that depends on **`pymergetic-easybind==X.Y.Z`** for a soft migration window.

## One-off upload (manual)

```bash
python -m pip install build twine
git fetch --tags
python -m build        # produces dist/*.whl and dist/*.tar.gz
twine check dist/*
twine upload dist/*    # or TestPyPI: twine upload --repository testpypi dist/*
```

Configure credentials with **API token** (`~/.pypirc` or environment variables) or use **trusted publishing** (OIDC) from GitHub Actions.

## Helper: next semver tag + push

**`pymergetic-release-tag`** (install **`pymergetic-common`** first — via **`pymergetic-easybind`** or **`uv sync`**) picks the latest **`vMAJOR.MINOR.PATCH`** tag, bumps **patch** by default (or **`--minor`** / **`--major`**), then **`fetch` / `checkout` / `pull`** (unless **`--no-pull`**), creates an **annotated** tag, and **`push`**es branch + tag (unless **`--no-push`** or **`--dry-run`**).

```bash
pymergetic-release-tag --dry-run
pymergetic-release-tag
pymergetic-release-tag --minor
pymergetic-release-tag --major
```

``[project].name`` comes from ``pyproject.toml`` (use **`--project-root PATH`** from outside the repo). Git operations use the git root at or above that directory. If the **only** dirty file is **`pyproject.toml`**, it is **committed**, **pushed to the branch**, then the new tag is created and pushed. Other dirty files abort. **`--no-auto-commit`** requires a clean tree. Without install: **`PYTHONPATH=src_py python -m pymergetic.common.devtools.release_tag`**.

**Publish CI** uses **`[tool.pymergetic.pins]`** with **`wait = true`** and the sole **`[build-system]`** `~=` line. Bump with **`pymergetic-pin-pyproject --project-root .`** (no flags).

**Tag ≠ PyPI success:** the tag appears on GitHub immediately; the **Publish** workflow can still fail (build, auditwheel, twine). Fix the branch, then tag again or re-run the workflow — PyPI may not have that version until CI goes green.

## CI upload

Pushing a tag matching `v*` triggers `.github/workflows/publish.yml`, which builds and uploads to PyPI.

**Re-running the workflow for the same tag** after a successful upload will hit PyPI **“File already exists”** — you cannot replace wheels for a released version. The workflow uses **`skip-existing: true`** so a retry skips files already on PyPI (e.g. after a partial failure) instead of erroring. To ship a **new** build, bump the version and push a **new** `v*` tag.

**Downstream:** projects that pin **pymergetic-easybind** can use **`pymergetic-wait-pypi --distribution pymergetic-easybind`** in their own CI.

Create a **repository secret** `PYPI_API_TOKEN` with a PyPI API token scoped to this project (or switch the workflow to [trusted publishing](https://docs.pypi.org/trusted-publishers/)).

## Platforms

**CI** (`.github/workflows/publish.yml`) builds an **sdist** (Linux job) plus **manylinux** and **Windows amd64** wheels via **cibuildwheel** on `ubuntu-latest` and `windows-latest`. Linux wheels use the **`manylinux_2_28`** image (`manylinux-x86_64-image` in `pyproject.toml`). Windows wheels are repaired with **delvewheel** so extension DLLs are bundled.

There is **no** official PyPA Docker image for **`manylinux_2_27`**; the closest policy with maintained images is **`manylinux_2_28`** (glibc 2.28+). For broader Linux compatibility (older glibc), switch the cibuildwheel image to **`manylinux2014`** in `[tool.cibuildwheel]`.

Locally, a plain `python -m build` on Linux may still emit a bare `linux_x86_64` wheel; do not upload that to PyPI.

## Submodule / monorepo note

If this repo is a **git submodule** inside another project, **tags for versioning must exist on this repository’s own remote**, not only on the parent repo. Tag and release from the `easybind` repo (or push tags there after merging).

## Downstream: cppdantic

The **cppdantic** demo package depends on **pymergetic-easybind** with a compatible-release pin (`pymergetic-easybind~=A.B.C` in its `pyproject.toml`). **Release pymergetic-easybind to PyPI first**, then bump those pins in the cppdantic repo to the new **`A.B.C`** before tagging cppdantic. See **cppdantic**’s **`RELEASING.md`** for the full order.
