#include <pymergetic/easybind/bind.hpp>


//
// Extension-side bindings for pymergetic.easybind.module.
//


EASYBIND_NS_MODULE(pymergetic::easybind::module, m, false, {

});