# nonebot-plugin-webui

一个面向 NoneBot2 的 WebUI 插件雏形，目标是集中管理 NoneBot 运行配置、已加载插件、插件设置与插件商店。

## 当前能力

- 挂载到 FastAPI 驱动提供的 `server_app`
- 查看 NoneBot 运行信息
- 查看已读取的配置项，并自动遮蔽疑似密钥、令牌、密码字段
- 查看已加载插件与 `PluginMetadata`
- 从 NoneBot 官方 registry 拉取插件商店列表，并给出 `nb plugin install` 命令
- 提供无构建链的静态 WebUI，方便先验证交互和后端接口

## 使用方式

安装到你的 NoneBot 项目环境后，在入口中加载插件：

```python
nonebot.load_plugin("nonebot_plugin_webui")
```

确保项目使用 FastAPI 驱动，例如：

```dotenv
DRIVER=~fastapi
```

启动 NoneBot 后访问：

```text
http://127.0.0.1:8080/webui
```

## 配置

```dotenv
WEBUI_PATH=/webui
WEBUI_STORE_URL=https://registry.nonebot.dev/plugins.json
WEBUI_STORE_TIMEOUT=10
```

## 路线图

- 支持编辑 `.env` / `.env.*` 配置文件并生成变更预览
- 为插件配置类生成可编辑表单
- 调用 `nb-cli` 安装、更新、卸载插件
- 增加鉴权与访问控制
- 前端迁移到正式构建链并补充更完整的状态管理

