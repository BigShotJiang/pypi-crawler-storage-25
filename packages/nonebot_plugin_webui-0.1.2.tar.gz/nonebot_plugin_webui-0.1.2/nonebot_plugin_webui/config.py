from nonebot import get_driver

try:
    from nonebot import get_plugin_config
except ImportError:  # pragma: no cover
    get_plugin_config = None
from pydantic import BaseModel, Field


class Config(BaseModel):
    webui_path: str = Field(default="/webui")
    webui_store_url: str = Field(default="https://registry.nonebot.dev/plugins.json")
    webui_store_timeout: float = Field(default=10)

    class Config:
        extra = "ignore"


def get_config() -> Config:
    if get_plugin_config is not None:
        return get_plugin_config(Config)

    driver_config = get_driver().config
    if hasattr(driver_config, "dict"):
        return Config(**driver_config.dict())
    if hasattr(driver_config, "model_dump"):
        return Config(**driver_config.model_dump())
    return Config()

