from pathlib import Path

from nonebot import get_driver, logger
from nonebot.plugin import PluginMetadata

from .config import Config, get_config
from .routes import create_router

__plugin_meta__ = PluginMetadata(
    name="NoneBot WebUI",
    description="管理 NoneBot 运行配置、插件信息和插件商店的 WebUI。",
    usage="使用 FastAPI 驱动启动 NoneBot 后访问 /webui。",
    type="application",
    config=Config,
    supported_adapters=None,
)

_driver = get_driver()
_config = get_config()


def _mount_webui() -> None:
    server_app = getattr(_driver, "server_app", None)
    if server_app is None:
        logger.warning("nonebot-plugin-webui requires the FastAPI driver to mount WebUI")
        return

    try:
        from fastapi.staticfiles import StaticFiles
    except ImportError:
        logger.warning("FastAPI is not installed, nonebot-plugin-webui cannot mount")
        return

    static_dir = Path(__file__).parent / "static"
    base_path = _config.webui_path.rstrip("/") or "/webui"

    server_app.include_router(create_router(_config), prefix=base_path)
    server_app.mount(
        f"{base_path}/assets",
        StaticFiles(directory=static_dir / "assets"),
        name="nonebot_webui_assets",
    )
    logger.info("NoneBot WebUI mounted at {}", base_path)


_mount_webui()
