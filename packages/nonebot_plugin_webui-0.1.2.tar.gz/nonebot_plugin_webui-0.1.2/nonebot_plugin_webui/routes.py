from __future__ import annotations

import platform
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Any

import httpx
import nonebot
from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse, RedirectResponse

from .config import Config

SECRET_KEYWORDS = (
    "token",
    "secret",
    "password",
    "passwd",
    "key",
    "access",
    "authorization",
    "credential",
)


def create_router(config: Config) -> APIRouter:
    router = APIRouter()
    static_dir = Path(__file__).parent / "static"

    @router.get("", include_in_schema=False)
    async def index_without_slash() -> RedirectResponse:
        return RedirectResponse(f"{config.webui_path.rstrip('/')}/")

    @router.get("/", include_in_schema=False)
    async def index() -> FileResponse:
        return FileResponse(static_dir / "index.html")

    @router.get("/api/runtime")
    async def runtime() -> dict[str, Any]:
        driver = nonebot.get_driver()
        return {
            "driver": getattr(driver, "type", driver.__class__.__name__),
            "nonebot_version": _package_version("nonebot2"),
            "python_version": platform.python_version(),
            "platform": platform.platform(),
            "cwd": str(Path.cwd()),
            "webui_path": config.webui_path,
        }

    @router.get("/api/config")
    async def runtime_config() -> dict[str, Any]:
        driver_config = nonebot.get_driver().config
        return {
            "items": _flatten_config(_dump_model(driver_config)),
            "masked_keywords": SECRET_KEYWORDS,
        }

    @router.get("/api/plugins")
    async def plugins() -> dict[str, Any]:
        loaded_plugins = sorted(nonebot.get_loaded_plugins(), key=lambda item: item.name)
        available_names = sorted(nonebot.get_available_plugin_names())
        return {
            "loaded": [_serialize_plugin(plugin) for plugin in loaded_plugins],
            "available": available_names,
        }

    @router.get("/api/store/plugins")
    async def store_plugins(q: str = "", limit: int = 80) -> dict[str, Any]:
        limit = max(1, min(limit, 200))
        try:
            async with httpx.AsyncClient(timeout=config.webui_store_timeout) as client:
                response = await client.get(config.webui_store_url)
                response.raise_for_status()
                payload = response.json()
        except Exception as exc:
            raise HTTPException(
                status_code=502,
                detail=f"Failed to fetch NoneBot plugin registry: {exc}",
            ) from exc

        items = _extract_store_items(payload)
        if q:
            needle = q.casefold()
            items = [
                item
                for item in items
                if needle in " ".join(str(value) for value in item.values()).casefold()
            ]

        return {
            "items": items[:limit],
            "total": len(items),
            "source": config.webui_store_url,
        }

    return router


def _package_version(package: str) -> str | None:
    try:
        return version(package)
    except PackageNotFoundError:
        return None


def _dump_model(value: Any) -> dict[str, Any]:
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    if hasattr(value, "dict"):
        return value.dict()
    if isinstance(value, dict):
        return value
    return {
        key: item
        for key, item in vars(value).items()
        if not key.startswith("_")
    }


def _flatten_config(data: dict[str, Any]) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    for key in sorted(data):
        value = data[key]
        masked = _is_secret_key(key)
        items.append(
            {
                "key": key,
                "value": "***" if masked and value not in (None, "") else value,
                "type": type(value).__name__,
                "masked": masked,
            }
        )
    return items


def _is_secret_key(key: str) -> bool:
    lowered = key.casefold()
    return any(keyword in lowered for keyword in SECRET_KEYWORDS)


def _serialize_plugin(plugin: Any) -> dict[str, Any]:
    metadata = getattr(plugin, "metadata", None)
    return {
        "name": plugin.name,
        "module_name": plugin.module_name,
        "metadata": _serialize_metadata(metadata),
        "matcher_count": len(getattr(plugin, "matcher", set()) or set()),
        "sub_plugins": sorted(child.name for child in getattr(plugin, "sub_plugins", set())),
    }


def _serialize_metadata(metadata: Any) -> dict[str, Any] | None:
    if metadata is None:
        return None

    config_model = getattr(metadata, "config", None)
    return {
        "name": getattr(metadata, "name", None),
        "description": getattr(metadata, "description", None),
        "usage": getattr(metadata, "usage", None),
        "type": getattr(metadata, "type", None),
        "homepage": getattr(metadata, "homepage", None),
        "supported_adapters": sorted(getattr(metadata, "supported_adapters", []) or []),
        "config_schema": _model_schema(config_model),
        "extra": getattr(metadata, "extra", {}) or {},
    }


def _model_schema(model: Any) -> dict[str, Any] | None:
    if model is None:
        return None
    if hasattr(model, "model_json_schema"):
        return model.model_json_schema()
    if hasattr(model, "schema"):
        return model.schema()
    return None


def _extract_store_items(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, dict):
        raw_items = payload.get("plugins") or payload.get("items") or payload.get("data") or []
    elif isinstance(payload, list):
        raw_items = payload
    else:
        raw_items = []

    items: list[dict[str, Any]] = []
    for raw in raw_items:
        if not isinstance(raw, dict):
            continue

        homepage = raw.get("homepage") or raw.get("link")
        module_name = raw.get("module_name") or raw.get("module") or raw.get("name")
        package_name = (
            raw.get("project_name")
            or raw.get("project_link")
            or raw.get("package")
            or module_name
        )
        plugin_name = raw.get("name") or raw.get("module_name") or package_name

        items.append(
            {
                "name": plugin_name,
                "module_name": module_name,
                "package_name": package_name,
                "description": raw.get("desc") or raw.get("description") or "",
                "homepage": homepage,
                "author": raw.get("author") or "",
                "tags": _normalize_tags(raw.get("tags") or []),
                "type": raw.get("type"),
                "version": raw.get("version"),
                "valid": raw.get("valid"),
                "is_official": bool(raw.get("is_official", False)),
                "install_command": f"nb plugin install {package_name}",
            }
        )

    return items


def _normalize_tags(tags: Any) -> list[str]:
    normalized: list[str] = []
    if not isinstance(tags, list):
        return normalized

    for tag in tags:
        if isinstance(tag, str):
            normalized.append(tag)
        elif isinstance(tag, dict) and tag.get("label"):
            normalized.append(str(tag["label"]))

    return normalized
