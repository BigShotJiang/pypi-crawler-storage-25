import { Outlet, createRootRoute, createRoute } from "@tanstack/react-router";

import { Shell } from "@/app/shell";
import { ConfigPage } from "@/app/pages/config-page";
import { OverviewPage } from "@/app/pages/overview-page";
import { PluginsPage } from "@/app/pages/plugins-page";
import { StorePage } from "@/app/pages/store-page";

const rootRoute = createRootRoute({
  component: () => (
    <Shell>
      <Outlet />
    </Shell>
  ),
});

const indexRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/",
  component: OverviewPage,
});

const configRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/config",
  component: ConfigPage,
});

const pluginsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/plugins",
  component: PluginsPage,
});

const storeRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/store",
  component: StorePage,
});

export const routeTree = rootRoute.addChildren([
  indexRoute,
  configRoute,
  pluginsRoute,
  storeRoute,
]);

