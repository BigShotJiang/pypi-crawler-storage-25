import axios from "axios";

export type RuntimeInfo = {
  driver: string;
  nonebot_version: string | null;
  python_version: string;
  platform: string;
  cwd: string;
  webui_path: string;
};

export type ConfigItem = {
  key: string;
  value: unknown;
  type: string;
  masked: boolean;
};

export type PluginMetadata = {
  name?: string;
  description?: string;
  usage?: string;
  type?: string;
  homepage?: string;
  supported_adapters?: string[];
  config_schema?: Record<string, unknown> | null;
  extra?: Record<string, unknown>;
};

export type LoadedPlugin = {
  name: string;
  module_name: string;
  metadata: PluginMetadata | null;
  matcher_count: number;
  sub_plugins: string[];
};

export type PluginsResponse = {
  loaded: LoadedPlugin[];
  available: string[];
};

export type StorePlugin = {
  name: string;
  module_name: string;
  package_name: string;
  description: string;
  homepage?: string;
  author: string;
  tags: string[];
  type?: string;
  version?: string;
  valid?: boolean;
  is_official: boolean;
  install_command: string;
};

export type StorePluginsResponse = {
  items: StorePlugin[];
  total: number;
  source: string;
};

function apiPrefix() {
  if (window.location.port === "5173") {
    return "/webui/api";
  }

  const path = window.location.pathname.replace(/\/$/, "");
  return `${path || "/webui"}/api`;
}

export const api = axios.create({
  baseURL: apiPrefix(),
  timeout: 15000,
});

export async function getRuntime() {
  const response = await api.get<RuntimeInfo>("/runtime");
  return response.data;
}

export async function getConfig() {
  const response = await api.get<{ items: ConfigItem[] }>("/config");
  return response.data;
}

export async function getPlugins() {
  const response = await api.get<PluginsResponse>("/plugins");
  return response.data;
}

export async function getStorePlugins(query = "") {
  const response = await api.get<StorePluginsResponse>("/store/plugins", {
    params: query ? { q: query } : undefined,
  });
  return response.data;
}
