import { create } from "zustand";

const themes = ["light", "dark", "system"] as const;
const sidebarVariants = ["inset", "floating", "sidebar"] as const;
const layoutModes = ["default", "compact", "full"] as const;
const directions = ["ltr", "rtl"] as const;

function readEnumStorage<T extends string>(
  key: string,
  values: readonly T[],
  fallback: T,
) {
  if (typeof window === "undefined") {
    return fallback;
  }

  const value = window.localStorage.getItem(key);
  return values.includes(value as T) ? (value as T) : fallback;
}

type UiState = {
  storeSearch: string;
  theme: (typeof themes)[number];
  sidebarCollapsed: boolean;
  sidebarVariant: (typeof sidebarVariants)[number];
  layoutMode: (typeof layoutModes)[number];
  offcanvasOpen: boolean;
  direction: (typeof directions)[number];
  setStoreSearch: (value: string) => void;
  setTheme: (theme: (typeof themes)[number]) => void;
  setSidebarVariant: (variant: (typeof sidebarVariants)[number]) => void;
  setLayoutMode: (mode: (typeof layoutModes)[number]) => void;
  setDirection: (direction: (typeof directions)[number]) => void;
  resetAppearance: () => void;
  toggleSidebar: () => void;
};

export const useUiStore = create<UiState>((set) => ({
  storeSearch: "",
  theme: readEnumStorage("webui-theme", themes, "system"),
  sidebarCollapsed:
    typeof window !== "undefined"
      ? window.localStorage.getItem("webui-sidebar") === "collapsed"
      : false,
  sidebarVariant: readEnumStorage("webui-sidebar-variant", sidebarVariants, "inset"),
  layoutMode: readEnumStorage("webui-layout-mode", layoutModes, "default"),
  offcanvasOpen: false,
  direction: readEnumStorage("webui-direction", directions, "ltr"),
  setStoreSearch: (storeSearch) => set({ storeSearch }),
  setTheme: (theme) =>
    set(() => {
      window.localStorage.setItem("webui-theme", theme);
      return { theme };
    }),
  setSidebarVariant: (sidebarVariant) =>
    set(() => {
      window.localStorage.setItem("webui-sidebar-variant", sidebarVariant);
      return { sidebarVariant };
    }),
  setLayoutMode: (layoutMode) =>
    set(() => {
      window.localStorage.setItem("webui-layout-mode", layoutMode);
      window.localStorage.setItem(
        "webui-sidebar",
        layoutMode === "compact" ? "collapsed" : "expanded",
      );
      return {
        layoutMode,
        sidebarCollapsed: layoutMode === "compact",
        offcanvasOpen: false,
      };
    }),
  setDirection: (direction) =>
    set(() => {
      window.localStorage.setItem("webui-direction", direction);
      document.documentElement.setAttribute("dir", direction);
      return { direction };
    }),
  resetAppearance: () =>
    set(() => {
      window.localStorage.setItem("webui-theme", "system");
      window.localStorage.setItem("webui-sidebar-variant", "inset");
      window.localStorage.setItem("webui-layout-mode", "default");
      window.localStorage.setItem("webui-direction", "ltr");
      window.localStorage.setItem("webui-sidebar", "expanded");
      document.documentElement.setAttribute("dir", "ltr");
      return {
        theme: "system",
        sidebarVariant: "inset",
        layoutMode: "default",
        direction: "ltr",
        sidebarCollapsed: false,
        offcanvasOpen: false,
      };
    }),
  toggleSidebar: () =>
    set((state) => {
      if (state.layoutMode === "full") {
        return { offcanvasOpen: !state.offcanvasOpen };
      }

      const sidebarCollapsed = !state.sidebarCollapsed;
      const layoutMode = sidebarCollapsed ? "compact" : "default";
      window.localStorage.setItem(
        "webui-sidebar",
        sidebarCollapsed ? "collapsed" : "expanded",
      );
      window.localStorage.setItem("webui-layout-mode", layoutMode);
      return { sidebarCollapsed, layoutMode };
    }),
}));
