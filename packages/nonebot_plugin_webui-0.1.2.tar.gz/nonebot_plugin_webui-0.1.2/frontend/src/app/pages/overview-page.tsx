import { useQuery } from "@tanstack/react-query";

import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { getConfig, getPlugins, getRuntime, getStorePlugins } from "@/lib/api";

export function OverviewPage() {
  const runtime = useQuery({ queryKey: ["runtime"], queryFn: getRuntime });
  const config = useQuery({ queryKey: ["config"], queryFn: getConfig });
  const plugins = useQuery({ queryKey: ["plugins"], queryFn: getPlugins });
  const store = useQuery({
    queryKey: ["store", ""],
    queryFn: () => getStorePlugins(""),
    enabled: false,
  });

  const loaded = plugins.data?.loaded ?? [];
  const withMetadata = loaded.filter((plugin) => plugin.metadata).length;
  const withSchema = loaded.filter((plugin) => plugin.metadata?.config_schema).length;
  const matchers = loaded.reduce((total, plugin) => total + plugin.matcher_count, 0);

  return (
    <div className="grid gap-4">
      <div className="grid flex-none grid-cols-2 gap-2 xl:grid-cols-4">
        <StatCard label="已加载插件" value={loaded.length || "-"} />
        <StatCard label="可用插件名" value={plugins.data?.available.length ?? "-"} />
        <StatCard label="配置项" value={config.data?.items.length ?? "-"} />
        <StatCard label="商店索引" value={store.data?.total ?? "未载入"} accent />
      </div>

      <div className="grid grid-cols-[1.2fr_.8fr] gap-4 max-lg:grid-cols-1">
        <Card>
          <CardHeader>
            <CardTitle>运行信息</CardTitle>
            <CardDescription>当前进程、驱动与版本</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-2">
            {[
              ["驱动", runtime.data?.driver],
              ["NoneBot", runtime.data?.nonebot_version],
              ["Python", runtime.data?.python_version],
              ["平台", runtime.data?.platform],
              ["工作目录", runtime.data?.cwd],
              ["挂载路径", runtime.data?.webui_path],
            ].map(([label, value]) => (
              <div key={label} className="grid grid-cols-[140px_minmax(0,1fr)] gap-3 rounded-md border bg-muted/40 p-3 text-sm max-sm:grid-cols-1">
                <span className="text-muted-foreground">{label}</span>
                <strong className="break-all font-medium">{value || "-"}</strong>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>插件概览</CardTitle>
            <CardDescription>已加载插件的元数据分布</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-2">
            <Insight label="元数据完整" value={`${withMetadata} / ${loaded.length}`} />
            <Insight label="带配置 schema" value={`${withSchema} / ${loaded.length}`} />
            <Insight label="Matcher 总数" value={matchers} />
            <Insight
              label="Library 插件"
              value={loaded.filter((plugin) => plugin.metadata?.type === "library").length}
            />
            {runtime.isLoading || plugins.isLoading || config.isLoading ? (
              <Badge className="w-fit">加载中</Badge>
            ) : null}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function StatCard({
  label,
  value,
  accent,
}: {
  label: string;
  value: string | number;
  accent?: boolean;
}) {
  return (
    <Card className={accent ? "border-chart-1/40" : undefined}>
      <CardContent className="px-3 xl:px-4">
        <div className="mb-2 text-xs font-medium xl:text-sm">{label}</div>
        <div className="text-lg font-bold tabular-nums xl:text-xl">{value}</div>
        <p className="truncate text-[11px] text-muted-foreground xl:text-xs">当前实例</p>
      </CardContent>
    </Card>
  );
}

function Insight({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="grid grid-cols-[140px_minmax(0,1fr)] gap-3 rounded-md border bg-muted/40 p-3 text-sm">
      <span className="text-muted-foreground">{label}</span>
      <strong className="font-medium">{value}</strong>
    </div>
  );
}
