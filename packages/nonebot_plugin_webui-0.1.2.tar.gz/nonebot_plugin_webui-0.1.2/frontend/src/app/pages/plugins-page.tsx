import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";

import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { getPlugins } from "@/lib/api";

export function PluginsPage() {
  const [search, setSearch] = useState("");
  const [type, setType] = useState("");
  const plugins = useQuery({ queryKey: ["plugins"], queryFn: getPlugins });

  const filtered = useMemo(() => {
    return (plugins.data?.loaded ?? []).filter((plugin) => {
      const meta = plugin.metadata ?? {};
      const haystack = [plugin.name, plugin.module_name, meta.name, meta.description]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();
      return haystack.includes(search.toLowerCase()) && (!type || meta.type === type);
    });
  }, [plugins.data?.loaded, search, type]);

  return (
    <Card>
      <CardHeader className="grid-cols-[1fr_auto] gap-4 max-md:grid-cols-1">
        <div>
          <CardTitle>已加载插件</CardTitle>
          <CardDescription>模块、matcher 数量与插件配置 schema</CardDescription>
        </div>
        <div className="flex gap-2 max-sm:w-full max-sm:flex-col">
          <Input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="搜索插件"
            className="w-72 max-sm:w-full"
          />
          <select
            value={type}
            onChange={(event) => setType(event.target.value)}
            className="h-9 rounded-lg border bg-card px-3 text-sm"
          >
            <option value="">全部类型</option>
            <option value="application">application</option>
            <option value="library">library</option>
          </select>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-[repeat(auto-fill,minmax(300px,1fr))] gap-4">
          {filtered.map((plugin) => {
            const meta = plugin.metadata ?? {};
            return (
              <article key={plugin.module_name} className="flex min-h-56 flex-col gap-3 rounded-xl border bg-card p-4 shadow-sm">
                <div className="flex items-start justify-between gap-3">
                  <h3 className="text-lg font-semibold">{meta.name || plugin.name}</h3>
                  {meta.type ? <Badge>{meta.type}</Badge> : null}
                </div>
                <p className="min-h-12 text-sm leading-6 text-muted-foreground">
                  {meta.description || "未提供插件描述"}
                </p>
                <div className="flex flex-wrap gap-2">
                  <Badge>{plugin.module_name}</Badge>
                  <Badge>{plugin.matcher_count} matchers</Badge>
                  {meta.config_schema ? (
                    <Badge className="bg-emerald-100 text-emerald-800">config schema</Badge>
                  ) : (
                    <Badge className="bg-amber-100 text-amber-800">no schema</Badge>
                  )}
                </div>
                <div className="mt-auto flex items-center justify-between gap-3 text-sm">
                  <span className="text-muted-foreground">{plugin.sub_plugins.length} sub plugins</span>
                  {meta.homepage ? (
                    <a className="font-medium text-primary" href={meta.homepage} target="_blank" rel="noreferrer">
                      主页
                    </a>
                  ) : null}
                </div>
              </article>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
