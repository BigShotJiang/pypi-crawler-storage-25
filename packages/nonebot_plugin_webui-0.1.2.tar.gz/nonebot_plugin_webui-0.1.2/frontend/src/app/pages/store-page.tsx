import { useQuery } from "@tanstack/react-query";
import { Search } from "lucide-react";
import { useMemo, useState } from "react";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { getStorePlugins } from "@/lib/api";
import { useUiStore } from "@/stores/ui-store";

export function StorePage() {
  const storeSearch = useUiStore((state) => state.storeSearch);
  const setStoreSearch = useUiStore((state) => state.setStoreSearch);
  const [submitted, setSubmitted] = useState(storeSearch);
  const [type, setType] = useState("");
  const store = useQuery({
    queryKey: ["store", submitted],
    queryFn: () => getStorePlugins(submitted),
  });

  const filtered = useMemo(
    () => (store.data?.items ?? []).filter((plugin) => !type || plugin.type === type),
    [store.data?.items, type],
  );

  return (
    <Card>
      <CardHeader className="grid-cols-[1fr_auto] gap-4 max-md:grid-cols-1">
        <div>
          <CardTitle>插件商店</CardTitle>
          <CardDescription>来自 NoneBot registry 的插件索引</CardDescription>
        </div>
        <div className="flex gap-2 max-sm:w-full max-sm:flex-col">
          <Input
            value={storeSearch}
            onChange={(event) => setStoreSearch(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter") setSubmitted(storeSearch);
            }}
            placeholder="搜索插件、作者、标签"
            className="w-80 max-sm:w-full"
          />
          <select
            value={type}
            onChange={(event) => setType(event.target.value)}
            className="h-9 rounded-lg border bg-card px-3 text-sm"
          >
            <option value="">全部类型</option>
            <option value="application">application</option>
            <option value="library">library</option>
          </select>
          <Button onClick={() => setSubmitted(storeSearch)}>
            <Search className="h-4 w-4" />
            搜索
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-4 rounded-md border bg-muted/40 px-3 py-2 text-sm text-muted-foreground">
          {store.data
            ? `当前显示 ${filtered.length} 个，registry 共匹配 ${store.data.total} 个，来源 ${store.data.source}`
            : "正在载入商店索引"}
        </div>
        <div className="grid grid-cols-[repeat(auto-fill,minmax(320px,1fr))] gap-4">
          {filtered.map((plugin) => (
            <article key={`${plugin.package_name}:${plugin.module_name}`} className="flex min-h-60 flex-col gap-3 rounded-xl border bg-card p-4 shadow-sm">
              <div className="flex items-start justify-between gap-3">
                <h3 className="text-lg font-semibold">{plugin.name}</h3>
                <Badge className={plugin.valid ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"}>
                  {plugin.valid ? "valid" : "unchecked"}
                </Badge>
              </div>
              <p className="min-h-12 text-sm leading-6 text-muted-foreground">
                {plugin.description || "未提供商店描述"}
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge>{plugin.package_name}</Badge>
                {plugin.type ? <Badge>{plugin.type}</Badge> : null}
                {plugin.version ? <Badge>v{plugin.version}</Badge> : null}
                {plugin.tags.slice(0, 4).map((tag) => (
                  <Badge key={tag}>{tag}</Badge>
                ))}
              </div>
              <div className="mt-auto flex items-center justify-between gap-3 text-sm">
                <code className="break-all text-accent">{plugin.install_command}</code>
                {plugin.homepage ? (
                  <a className="font-medium text-primary" href={plugin.homepage} target="_blank" rel="noreferrer">
                    主页
                  </a>
                ) : null}
              </div>
            </article>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
