import { useQuery } from "@tanstack/react-query";
import type { ColumnDef } from "@tanstack/react-table";
import { useMemo, useState } from "react";

import { DataTable } from "@/app/components/data-table";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { getConfig, type ConfigItem } from "@/lib/api";

export function ConfigPage() {
  const [search, setSearch] = useState("");
  const [secretOnly, setSecretOnly] = useState(false);
  const config = useQuery({ queryKey: ["config"], queryFn: getConfig });

  const columns = useMemo<ColumnDef<ConfigItem>[]>(
    () => [
      {
        accessorKey: "key",
        header: "键",
        cell: ({ row }) => <code>{row.original.key}</code>,
      },
      {
        accessorKey: "value",
        header: "值",
        cell: ({ row }) => (
          <code className="break-all">
            {typeof row.original.value === "string"
              ? row.original.value
              : JSON.stringify(row.original.value)}
          </code>
        ),
      },
      { accessorKey: "type", header: "类型" },
      {
        accessorKey: "masked",
        header: "状态",
        cell: ({ row }) =>
          row.original.masked ? (
            <Badge className="bg-amber-100 text-amber-800">masked</Badge>
          ) : (
            <Badge className="bg-emerald-100 text-emerald-800">visible</Badge>
          ),
      },
    ],
    [],
  );

  const data = (config.data?.items ?? []).filter((item) => {
    const matchesSearch = item.key.toLowerCase().includes(search.toLowerCase());
    const matchesSecret = !secretOnly || item.masked;
    return matchesSearch && matchesSecret;
  });

  return (
    <Card>
      <CardHeader className="grid-cols-[1fr_auto] gap-4 max-md:grid-cols-1">
        <div>
          <CardTitle>运行配置</CardTitle>
          <CardDescription>NoneBot 已读取的配置，敏感字段自动遮蔽</CardDescription>
        </div>
        <div className="flex gap-2 max-sm:w-full max-sm:flex-col">
          <Input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="搜索配置项"
            className="w-72 max-sm:w-full"
          />
          <label className="flex h-9 items-center gap-2 rounded-lg border bg-card px-3 text-sm text-muted-foreground">
            <input
              type="checkbox"
              checked={secretOnly}
              onChange={(event) => setSecretOnly(event.target.checked)}
            />
            仅敏感项
          </label>
        </div>
      </CardHeader>
      <CardContent className="px-0 sm:px-6">
        <DataTable columns={columns} data={data} />
      </CardContent>
    </Card>
  );
}
