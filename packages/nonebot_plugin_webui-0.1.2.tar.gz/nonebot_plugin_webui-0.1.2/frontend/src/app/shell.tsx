import { Link, useRouterState } from "@tanstack/react-router";
import {
  Boxes,
  ChevronsUpDown,
  LayoutDashboard,
  Menu,
  RefreshCw,
  Settings,
  Store,
} from "lucide-react";
import type { ReactNode } from "react";

import { ConfigDrawer } from "@/app/components/config-drawer";
import { SearchButton } from "@/app/components/search-button";
import { ThemeSwitch } from "@/app/components/theme-switch";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { queryClient } from "@/lib/query-client";
import { cn } from "@/lib/utils";
import { useUiStore } from "@/stores/ui-store";

const nav = [
  { to: "/", label: "总览", desc: "Overview", icon: LayoutDashboard },
  { to: "/config", label: "配置", desc: "Config", icon: Settings },
  { to: "/plugins", label: "插件", desc: "Plugins", icon: Boxes },
  { to: "/store", label: "商店", desc: "Store", icon: Store },
];

const titles: Record<string, string> = {
  "/": "总览",
  "/config": "配置",
  "/plugins": "插件",
  "/store": "商店",
};

function getSidebarLayoutState({
  layoutMode,
  sidebarVariant,
  sidebarCollapsed,
  offcanvasOpen,
}: {
  layoutMode: "default" | "compact" | "full";
  sidebarVariant: "inset" | "floating" | "sidebar";
  sidebarCollapsed: boolean;
  offcanvasOpen: boolean;
}) {
  const fullLayout = layoutMode === "full";
  const compactLayout = layoutMode === "compact" || sidebarCollapsed;
  const insetLayout = sidebarVariant === "inset";
  const floatingLayout = sidebarVariant === "floating";
  const standardLayout = sidebarVariant === "sidebar";
  const contentCollapsed = compactLayout || (fullLayout && !offcanvasOpen);
  const collapsedSidebarWidth = floatingLayout || insetLayout ? "w-16" : "w-12";
  const expandedSidebarWidth = "w-64";

  return {
    fullLayout,
    insetLayout,
    floatingLayout,
    standardLayout,
    contentCollapsed,
    state: contentCollapsed ? "collapsed" : "expanded",
    collapsible: fullLayout ? "offcanvas" : compactLayout ? "icon" : "",
    gapWidth: fullLayout
      ? offcanvasOpen
        ? compactLayout
          ? collapsedSidebarWidth
          : expandedSidebarWidth
        : "w-0"
      : compactLayout
        ? collapsedSidebarWidth
        : expandedSidebarWidth,
    containerWidth: contentCollapsed ? collapsedSidebarWidth : expandedSidebarWidth,
    triggerTitle: fullLayout || compactLayout ? "展开侧栏" : "收起侧栏",
  };
}

export function Shell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const sidebarCollapsed = useUiStore((state) => state.sidebarCollapsed);
  const sidebarVariant = useUiStore((state) => state.sidebarVariant);
  const layoutMode = useUiStore((state) => state.layoutMode);
  const offcanvasOpen = useUiStore((state) => state.offcanvasOpen);
  const toggleSidebar = useUiStore((state) => state.toggleSidebar);
  const sidebar = getSidebarLayoutState({
    layoutMode,
    sidebarVariant,
    sidebarCollapsed,
    offcanvasOpen,
  });

  return (
    <div
      data-slot="sidebar-wrapper"
      data-variant={sidebar.insetLayout ? "inset" : sidebar.floatingLayout ? "floating" : "sidebar"}
      className={cn(
        "group/sidebar-wrapper flex h-svh w-full overflow-hidden",
        sidebar.insetLayout ? "bg-sidebar" : "bg-background",
      )}
    >
      <aside
        data-slot="sidebar"
        data-state={sidebar.state}
        data-collapsible={sidebar.collapsible}
        data-variant={sidebarVariant}
        data-side="start"
        className={cn(
          "group peer shrink-0 bg-transparent text-sidebar-foreground transition-[width] duration-300 ease-linear",
          "hidden md:block",
          sidebar.gapWidth,
        )}
      >
        <div
          data-slot="sidebar-container"
          className={cn(
            "fixed inset-y-0 z-30 hidden transition-[inset-inline-start,width] duration-300 ease-linear md:flex",
            sidebar.fullLayout ? "-start-64" : "start-0",
            sidebar.standardLayout && "border-e border-sidebar-border",
            (sidebar.floatingLayout || sidebar.insetLayout) && "p-2",
            sidebar.fullLayout && "w-64 border-e border-sidebar-border",
            sidebar.fullLayout && sidebar.insetLayout && "border-e-0",
            sidebar.fullLayout && offcanvasOpen && "start-0",
            sidebar.fullLayout && offcanvasOpen && sidebar.standardLayout && "shadow-xl",
            sidebar.fullLayout && sidebar.floatingLayout && "p-2 border-e-0",
            sidebar.containerWidth,
          )}
        >
          <div
            data-sidebar="sidebar"
            data-slot="sidebar-inner"
            className={cn(
              "flex h-full w-full flex-col bg-sidebar",
              sidebar.floatingLayout && "rounded-lg border border-sidebar-border shadow-sm",
            )}
          >
            <div data-slot="sidebar-header" className="flex flex-col gap-2 p-2">
              <button
                data-slot="sidebar-menu-button"
                data-size="lg"
                className={cn(
                  "peer/menu-button flex h-12 w-full items-center gap-2 overflow-hidden rounded-md p-2 text-start text-sm outline-none ring-sidebar-ring transition-[width,height,padding] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground [&>svg]:size-4 [&>svg]:shrink-0",
                  sidebar.contentCollapsed && "size-8 p-0",
                )}
              >
                <div className="flex aspect-square size-8 items-center justify-center rounded-lg bg-sidebar-primary text-xs font-black text-sidebar-primary-foreground">
                  NB
                </div>
                <div className="grid min-w-0 flex-1 text-start text-sm leading-tight">
                  <span className="truncate font-semibold">NoneBot WebUI</span>
                  <span className="truncate text-xs">runtime console</span>
                </div>
                <ChevronsUpDown className="ms-auto shrink-0 text-muted-foreground" />
              </button>
            </div>

            <div
              data-slot="sidebar-content"
              className="flex min-h-0 flex-1 flex-col gap-2 overflow-auto p-2"
            >
              <div data-slot="sidebar-group" className="relative flex w-full min-w-0 flex-col">
                <div
                  data-slot="sidebar-group-label"
                  className={cn(
                    "flex h-8 shrink-0 items-center rounded-md px-2 text-xs font-medium text-sidebar-foreground/70 ring-sidebar-ring outline-hidden transition-[margin,opacity] duration-300 ease-linear",
                    sidebar.contentCollapsed && "-mt-8 opacity-0",
                  )}
                >
                  控制台
                </div>
                <div data-slot="sidebar-group-content" className="w-full text-sm">
                  <ul data-slot="sidebar-menu" className="flex w-full min-w-0 flex-col gap-1">
                    {nav.map((item) => {
                      const Icon = item.icon;
                      const active = pathname === item.to;
                      return (
                        <li
                          key={item.to}
                          data-slot="sidebar-menu-item"
                          className="group/menu-item relative"
                        >
                          <Link
                            data-slot="sidebar-menu-button"
                            data-active={active}
                            data-size="default"
                            to={item.to}
                            className={cn(
                              "peer/menu-button flex h-8 w-full items-center gap-2 overflow-hidden rounded-md p-2 text-start text-sm outline-hidden ring-sidebar-ring transition-[width,height,padding] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground data-[active=true]:bg-sidebar-accent data-[active=true]:font-medium data-[active=true]:text-sidebar-accent-foreground [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0",
                              sidebar.contentCollapsed && "size-8 p-2",
                            )}
                            title={item.label}
                          >
                            <Icon />
                            <span>{item.label}</span>
                          </Link>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              </div>
            </div>

            <button
              data-slot="sidebar-rail"
              aria-label="Toggle Sidebar"
              tabIndex={-1}
              onClick={toggleSidebar}
              title="Toggle Sidebar"
              className="absolute inset-y-0 -end-4 z-20 hidden w-4 -translate-x-1/2 transition-all ease-linear after:absolute after:inset-y-0 after:start-1/2 after:w-0.5 hover:after:bg-sidebar-border rtl:translate-x-1/2 sm:flex"
            />
          </div>
        </div>
      </aside>

      <div
        data-slot="sidebar-inset"
        className={cn(
          "relative flex min-w-0 flex-1 flex-col overflow-hidden bg-background max-md:m-0 max-md:h-svh max-md:rounded-none",
          sidebar.insetLayout && "m-2 h-[calc(100svh-1rem)] rounded-xl border border-border/60 shadow-sm",
          sidebar.insetLayout && !sidebar.contentCollapsed && "ms-0",
          sidebar.floatingLayout && "h-svh",
          sidebar.standardLayout && "h-svh",
        )}
      >
        <header className="z-50 h-16 shrink-0 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="relative flex h-full items-center gap-3 px-4 sm:gap-4">
            <Button
              data-sidebar="trigger"
              data-slot="sidebar-trigger"
              variant="ghost"
              size="icon"
              className="aspect-square size-8 max-md:scale-125"
              onClick={toggleSidebar}
              title={sidebar.triggerTitle}
            >
              <Menu className="size-4" />
              <span className="sr-only">Toggle Sidebar</span>
            </Button>
            <Separator orientation="vertical" className="h-6" />
            <SearchButton className="me-auto" placeholder={`搜索${titles[pathname] ?? ""}`} />
            <ThemeSwitch />
            <ConfigDrawer />
            <Button variant="outline" size="sm" onClick={() => queryClient.invalidateQueries()}>
              <RefreshCw className="size-4" />
              刷新
            </Button>
          </div>
        </header>

        <main className="min-h-0 flex-1 overflow-y-auto px-4 py-6">
          <div className="@7xl/content:mx-auto @7xl/content:w-full @7xl/content:max-w-7xl">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
