import { Root as Radio, Item } from "@radix-ui/react-radio-group";
import { CircleCheck, RotateCcw, Settings } from "lucide-react";
import type { ReactElement, SVGProps } from "react";

import { IconDir } from "@/assets/custom/icon-dir";
import { IconLayoutCompact } from "@/assets/custom/icon-layout-compact";
import { IconLayoutDefault } from "@/assets/custom/icon-layout-default";
import { IconLayoutFull } from "@/assets/custom/icon-layout-full";
import { IconSidebarFloating } from "@/assets/custom/icon-sidebar-floating";
import { IconSidebarInset } from "@/assets/custom/icon-sidebar-inset";
import { IconSidebarSidebar } from "@/assets/custom/icon-sidebar-sidebar";
import { IconThemeDark } from "@/assets/custom/icon-theme-dark";
import { IconThemeLight } from "@/assets/custom/icon-theme-light";
import { IconThemeSystem } from "@/assets/custom/icon-theme-system";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import { useUiStore } from "@/stores/ui-store";

type Option<T extends string> = {
  value: T;
  label: string;
  icon: (props: SVGProps<SVGSVGElement>) => ReactElement;
};

const themeOptions = [
  { value: "system", label: "跟随系统", icon: IconThemeSystem },
  { value: "light", label: "浅色", icon: IconThemeLight },
  { value: "dark", label: "深色", icon: IconThemeDark },
] satisfies Option<"system" | "light" | "dark">[];

const sidebarOptions = [
  { value: "inset", label: "嵌入", icon: IconSidebarInset },
  { value: "floating", label: "悬浮", icon: IconSidebarFloating },
  { value: "sidebar", label: "标准", icon: IconSidebarSidebar },
] satisfies Option<"inset" | "floating" | "sidebar">[];

const layoutOptions = [
  { value: "default", label: "默认", icon: IconLayoutDefault },
  { value: "compact", label: "紧凑", icon: IconLayoutCompact },
  { value: "full", label: "完整布局", icon: IconLayoutFull },
] satisfies Option<"default" | "compact" | "full">[];

const directionOptions = [
  {
    value: "ltr",
    label: "从左到右",
    icon: (props: SVGProps<SVGSVGElement>) => <IconDir dir="ltr" {...props} />,
  },
  {
    value: "rtl",
    label: "从右到左",
    icon: (props: SVGProps<SVGSVGElement>) => <IconDir dir="rtl" {...props} />,
  },
] satisfies Option<"ltr" | "rtl">[];

export function ConfigDrawer() {
  const resetAppearance = useUiStore((state) => state.resetAppearance);

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button
          size="icon"
          variant="ghost"
          aria-label="打开主题设置"
          className="rounded-full"
        >
          <Settings aria-hidden="true" />
        </Button>
      </SheetTrigger>
      <SheetContent className="flex flex-col">
        <SheetHeader className="pb-0 text-start">
          <SheetTitle>主题设置</SheetTitle>
          <SheetDescription>
            调整界面外观、侧栏样式和布局偏好。
          </SheetDescription>
        </SheetHeader>
        <div className="space-y-6 overflow-y-auto px-4">
          <ThemeConfig />
          <SidebarConfig />
          <LayoutConfig />
          <DirConfig />
        </div>
        <SheetFooter className="gap-2">
          <Button variant="secondary" onClick={resetAppearance}>
            重置
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}

function SectionTitle({
  title,
  showReset = false,
  onReset,
  resetAriaLabel,
  className,
}: {
  title: string;
  showReset?: boolean;
  onReset?: () => void;
  resetAriaLabel?: string;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "mb-2 flex items-center gap-2 text-sm font-semibold text-muted-foreground",
        className,
      )}
    >
      {title}
      {showReset && onReset ? (
        <Button
          type="button"
          size="icon"
          variant="secondary"
          className="size-4 rounded-full"
          onClick={onReset}
          aria-label={resetAriaLabel}
        >
          <RotateCcw className="size-3" />
        </Button>
      ) : null}
    </div>
  );
}

function RadioGroupItem<T extends string>({
  item,
  isTheme = false,
}: {
  item: Option<T>;
  isTheme?: boolean;
}) {
  const Icon = item.icon;

  return (
    <Item
      value={item.value}
      className={cn("group outline-none", "transition duration-200 ease-in")}
      aria-label={`选择${item.label}`}
      aria-describedby={`${item.value}-description`}
    >
      <div
        className={cn(
          "relative rounded-[6px] ring-[1px] ring-border",
          "group-data-[state=checked]:shadow-2xl group-data-[state=checked]:ring-primary",
          "group-focus-visible:ring-2",
        )}
        role="img"
        aria-hidden="false"
        aria-label={`${item.label}选项预览`}
      >
        <CircleCheck
          className={cn(
            "size-6 fill-primary stroke-white",
            "group-data-[state=unchecked]:hidden",
            "absolute right-0 top-0 translate-x-1/2 -translate-y-1/2",
          )}
          aria-hidden="true"
        />
        <Icon
          className={cn(
            !isTheme &&
              "fill-primary stroke-primary group-data-[state=unchecked]:fill-muted-foreground group-data-[state=unchecked]:stroke-muted-foreground",
          )}
          aria-hidden="true"
        />
      </div>
      <div className="mt-1 text-xs" id={`${item.value}-description`} aria-live="polite">
        {item.label}
      </div>
    </Item>
  );
}

function ThemeConfig() {
  const theme = useUiStore((state) => state.theme);
  const setTheme = useUiStore((state) => state.setTheme);
  const defaultTheme = "system";

  return (
    <div>
      <SectionTitle
        title="主题"
        showReset={theme !== defaultTheme}
        onReset={() => setTheme(defaultTheme)}
        resetAriaLabel="重置主题偏好"
      />
      <Radio
        value={theme}
        onValueChange={(value) => setTheme(value as typeof theme)}
        className="grid w-full max-w-md grid-cols-3 gap-4"
        aria-label="选择主题偏好"
        aria-describedby="theme-description"
      >
        {themeOptions.map((item) => (
          <RadioGroupItem key={item.value} item={item} isTheme />
        ))}
      </Radio>
      <div id="theme-description" className="sr-only">
        在跟随系统、浅色和深色主题之间切换
      </div>
    </div>
  );
}

function SidebarConfig() {
  const variant = useUiStore((state) => state.sidebarVariant);
  const setVariant = useUiStore((state) => state.setSidebarVariant);
  const defaultVariant = "inset";

  return (
    <div className="max-md:hidden">
      <SectionTitle
        title="侧栏"
        showReset={variant !== defaultVariant}
        onReset={() => setVariant(defaultVariant)}
        resetAriaLabel="重置侧栏样式"
      />
      <Radio
        value={variant}
        onValueChange={(value) => setVariant(value as typeof variant)}
        className="grid w-full max-w-md grid-cols-3 gap-4"
        aria-label="选择侧栏样式"
        aria-describedby="sidebar-description"
      >
        {sidebarOptions.map((item) => (
          <RadioGroupItem key={item.value} item={item} />
        ))}
      </Radio>
      <div id="sidebar-description" className="sr-only">
        在嵌入、悬浮和标准侧栏样式之间切换
      </div>
    </div>
  );
}

function LayoutConfig() {
  const layout = useUiStore((state) => state.layoutMode);
  const setLayout = useUiStore((state) => state.setLayoutMode);
  const defaultLayout = "default";

  return (
    <div className="max-md:hidden">
      <SectionTitle
        title="布局"
        showReset={layout !== defaultLayout}
        onReset={() => setLayout(defaultLayout)}
        resetAriaLabel="重置布局选项"
      />
      <Radio
        value={layout}
        onValueChange={(value) => setLayout(value as typeof layout)}
        className="grid w-full max-w-md grid-cols-3 gap-4"
        aria-label="选择布局样式"
        aria-describedby="layout-description"
      >
        {layoutOptions.map((item) => (
          <RadioGroupItem key={item.value} item={item} />
        ))}
      </Radio>
      <div id="layout-description" className="sr-only">
        在默认展开、紧凑图标和完整布局模式之间切换
      </div>
    </div>
  );
}

function DirConfig() {
  const direction = useUiStore((state) => state.direction);
  const setDirection = useUiStore((state) => state.setDirection);
  const defaultDirection = "ltr";

  return (
    <div>
      <SectionTitle
        title="方向"
        showReset={direction !== defaultDirection}
        onReset={() => setDirection(defaultDirection)}
        resetAriaLabel="重置文字方向"
      />
      <Radio
        value={direction}
        onValueChange={(value) => setDirection(value as typeof direction)}
        className="grid w-full max-w-md grid-cols-3 gap-4"
        aria-label="选择页面方向"
        aria-describedby="direction-description"
      >
        {directionOptions.map((item) => (
          <RadioGroupItem key={item.value} item={item} />
        ))}
      </Radio>
      <div id="direction-description" className="sr-only">
        在从左到右和从右到左的页面方向之间切换
      </div>
    </div>
  );
}
