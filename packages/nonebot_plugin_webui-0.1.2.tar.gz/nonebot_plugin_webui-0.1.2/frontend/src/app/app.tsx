import { QueryClientProvider } from "@tanstack/react-query";
import { RouterProvider, createRouter } from "@tanstack/react-router";
import { useEffect } from "react";

import { queryClient } from "@/lib/query-client";
import { routeTree } from "@/routeTree";
import { useUiStore } from "@/stores/ui-store";

const router = createRouter({
  routeTree,
  basepath: new URL(document.baseURI).pathname.replace(/\/$/, ""),
});

declare module "@tanstack/react-router" {
  interface Register {
    router: typeof router;
  }
}

export function App() {
  const theme = useUiStore((state) => state.theme);
  const direction = useUiStore((state) => state.direction);
  const sidebarVariant = useUiStore((state) => state.sidebarVariant);

  useEffect(() => {
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const apply = () => {
      document.documentElement.classList.toggle(
        "dark",
        theme === "dark" || (theme === "system" && media.matches),
      );
    };

    apply();
    media.addEventListener("change", apply);
    return () => media.removeEventListener("change", apply);
  }, [theme]);

  useEffect(() => {
    document.documentElement.setAttribute("dir", direction);
  }, [direction]);

  useEffect(() => {
    const useSidebarBackground = sidebarVariant === "inset";
    document.body.classList.toggle("webui-sidebar-bg", useSidebarBackground);
    return () => document.body.classList.remove("webui-sidebar-bg");
  }, [sidebarVariant]);

  return (
    <QueryClientProvider client={queryClient}>
      <RouterProvider router={router} />
    </QueryClientProvider>
  );
}
