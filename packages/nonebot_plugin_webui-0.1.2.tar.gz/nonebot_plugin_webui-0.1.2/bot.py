import nonebot

nonebot.init(driver="~fastapi")
nonebot.load_plugin("nonebot_plugin_webui")


if __name__ == "__main__":
    nonebot.run(host="127.0.0.1", port=8080)
