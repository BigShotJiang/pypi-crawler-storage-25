from .Helper import (
    Task,
    GUI,
    prefix,
    ArgumentNotGivenError,
    PrefixFunctionMismatchError,
    WrongArgumentError,
)

__all__ = [
    "Task",
    "GUI",
    "prefix",
    "ArgumentNotGivenError",
    "PrefixFunctionMismatchError",
    "WrongArgumentError",
]

__version__ = "1.0.0"
__author__ = "Alan"
__email__ = "alancodes012@gmail.com"
