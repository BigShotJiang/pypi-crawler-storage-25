"""
Helper for working with confidence area point arrays.

The confidenceArea field returned by the IP Geolocation and Network Engineering APIs
encodes one or more closed polygons in a flat list. Polygons are separated by a
repeated closing coordinate — when a point matches the first point of the current
polygon, that polygon is complete and a new one begins.

Do NOT treat the entire array as a single polygon ring.
"""
from __future__ import annotations
from typing import List
from .models.common import GeoPoint


def split_into_polygons(points: List[GeoPoint]) -> List[List[GeoPoint]]:
    """
    Splits a flat confidence area point list into individual closed polygon rings.

    :param points: The raw confidenceArea list from the API response.
    :returns: A list of polygon rings. Each ring is a closed list where the first
              and last point are identical. Returns an empty list if input is empty.

    Example::

        geo = client.ip_geolocation.get_full("1.1.1.1")
        polygons = split_into_polygons(geo.confidence_area)
        for ring in polygons:
            print(f"Polygon with {len(ring)} points")
            for pt in ring:
                print(f"  {pt.latitude}, {pt.longitude}")
    """
    if not points:
        return []

    polygons: List[List[GeoPoint]] = []
    current: List[GeoPoint] = []

    for point in points:
        if current:
            first = current[0]
            if _approx_equal(first.latitude, point.latitude) and \
               _approx_equal(first.longitude, point.longitude):
                current.append(point)  # include the closing point
                if len(current) >= 4:  # minimum: 3 distinct + 1 closing
                    polygons.append(current)
                current = []
                continue
        current.append(point)

    # Handle unclosed trailing polygon
    if len(current) >= 3:
        current.append(current[0])  # close it
        polygons.append(current)

    return polygons


def is_multi_polygon(points: List[GeoPoint]) -> bool:
    """Returns True when the confidence area encodes more than one polygon."""
    return len(split_into_polygons(points)) > 1


def _approx_equal(a: float, b: float, tolerance: float = 1e-5) -> bool:
    return abs(a - b) < tolerance
