"""
BigDataCloud Python SDK
Official client for BigDataCloud APIs.

Quick start::

    from bigdatacloud import BigDataCloudClient

    client = BigDataCloudClient.from_environment()
    geo = client.ip_geolocation.get("1.1.1.1")
    print(f"{geo.location.city}, {geo.country.name}")
"""
from .client import BigDataCloudClient, BigDataCloudException
from .confidence_area import split_into_polygons, is_multi_polygon
from .models import *

__version__ = "1.1.0"
__all__ = [
    "BigDataCloudClient",
    "BigDataCloudException",
    "split_into_polygons",
    "is_multi_polygon",
]
