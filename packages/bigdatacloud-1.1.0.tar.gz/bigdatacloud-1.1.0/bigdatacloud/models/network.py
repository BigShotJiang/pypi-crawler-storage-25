from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional
from .common import Carrier, GeoPoint, Country


@dataclass
class HazardReportResponse:
    """Standalone hazard report from the /data/hazard-report endpoint."""
    is_known_as_tor_server: bool = False
    is_known_as_vpn: bool = False
    is_known_as_proxy: bool = False
    is_spamhaus_drop: bool = False
    is_spamhaus_edrop: bool = False
    is_spamhaus_asn_drop: bool = False
    is_blacklisted_uceprotect: bool = False
    is_blacklisted_blocklist_de: bool = False
    is_known_as_mail_server: bool = False
    is_known_as_public_router: bool = False
    is_bogon: bool = False
    is_unreachable: bool = False
    hosting_likelihood: int = 0
    """The likelihood (0–10) that this IP originates from a hosting/cloud environment."""
    is_hosting_asn: bool = False
    is_cellular: bool = False
    i_cloud_private_relay: bool = False


@dataclass
class UserRiskResponse:
    """Risk assessment for an IP address — suitable for e-commerce and sign-up forms."""
    risk: Optional[str] = None
    """Risk level: 'Low', 'Moderate', or 'High'."""
    description: Optional[str] = None
    """Human-readable description and recommended action."""


@dataclass
class AsnInfoResponse:
    """Full ASN information including peers, transit relationships, and service area."""
    asn: Optional[str] = None
    asn_numeric: Optional[int] = None
    organisation: Optional[str] = None
    name: Optional[str] = None
    registry: Optional[str] = None
    registered_country: Optional[str] = None
    registered_country_name: Optional[str] = None
    registration_last_change: Optional[str] = None
    total_ipv4_addresses: Optional[int] = None
    total_ipv4_prefixes: Optional[int] = None
    total_ipv4_bogon_prefixes: Optional[int] = None
    total_ipv6_prefixes: Optional[int] = None
    total_ipv6_bogon_prefixes: Optional[int] = None
    total_receiving_from: Optional[int] = None
    total_transit_to: Optional[int] = None
    rank: Optional[int] = None
    rank_text: Optional[str] = None
    receiving_from: List[Carrier] = field(default_factory=list)
    """Upstream providers (ASNs from which this ASN receives traffic)."""
    transit_to: List[Carrier] = field(default_factory=list)
    """Downstream peers (ASNs to which this ASN provides transit)."""
    confidence_area: List[GeoPoint] = field(default_factory=list)
    """
    Flat list encoding one or more closed polygons representing the ASN's service area.
    Use ConfidenceAreaHelper.split_into_polygons() to split into individual rings.
    """


@dataclass
class AsnInfoShortResponse:
    """Short ASN information (no peers/transit lists)."""
    asn: Optional[str] = None
    asn_numeric: Optional[int] = None
    organisation: Optional[str] = None
    name: Optional[str] = None
    registry: Optional[str] = None
    registered_country: Optional[str] = None
    registered_country_name: Optional[str] = None
    registration_last_change: Optional[str] = None
    total_ipv4_addresses: Optional[int] = None
    total_ipv4_prefixes: Optional[int] = None
    total_ipv4_bogon_prefixes: Optional[int] = None
    total_ipv6_prefixes: Optional[int] = None
    total_ipv6_bogon_prefixes: Optional[int] = None
    rank: Optional[int] = None
    rank_text: Optional[str] = None


@dataclass
class AsnPeersResponse:
    """Paginated upstream providers for an ASN."""
    asn: Optional[str] = None
    total_receiving_from: Optional[int] = None
    receiving_from: List[Carrier] = field(default_factory=list)


@dataclass
class AsnTransitResponse:
    """Paginated downstream peers for an ASN."""
    asn: Optional[str] = None
    total_transit_to: Optional[int] = None
    transit_to: List[Carrier] = field(default_factory=list)


@dataclass
class BgpPrefix:
    """A single BGP prefix entry."""
    bgp_prefix: Optional[str] = None
    """BGP prefix in CIDR format (e.g. '1.1.1.0/24')."""
    bgp_prefix_network_address: Optional[str] = None
    bgp_prefix_last_address: Optional[str] = None
    registry_status: Optional[str] = None
    is_bogon: bool = False
    is_announced: bool = False
    carriers: List[Carrier] = field(default_factory=list)


@dataclass
class PrefixesListResponse:
    """Paginated list of BGP prefixes."""
    total: int = 0
    offset: int = 0
    batch: int = 0
    prefixes: List[BgpPrefix] = field(default_factory=list)


@dataclass
class CidrNetwork:
    """Network details for a CIDR range."""
    cidr: Optional[str] = None
    type: Optional[str] = None
    registry: Optional[str] = None
    registry_status: Optional[str] = None
    registered_country: Optional[str] = None
    registered_country_name: Optional[str] = None
    organisation: Optional[str] = None
    is_bogon: bool = False
    is_reachable_globally: bool = False
    carriers: List[Carrier] = field(default_factory=list)


@dataclass
class NetworkByCidrResponse:
    """Response from the Networks by CIDR API."""
    cidr: Optional[str] = None
    parent: Optional[str] = None
    network: Optional[CidrNetwork] = None
    """Present only when the range maps to a single BGP prefix."""
    subnets: List[CidrNetwork] = field(default_factory=list)
    """Present only when the range spans multiple BGP prefixes."""


@dataclass
class NetworkByIpResponse:
    """Detailed network information for an IP address."""
    ip: Optional[str] = None
    registry: Optional[str] = None
    registry_status: Optional[str] = None
    registered_country: Optional[str] = None
    registered_country_name: Optional[str] = None
    organisation: Optional[str] = None
    is_reachable_globally: bool = False
    is_bogon: bool = False
    bgp_prefix: Optional[str] = None
    bgp_prefix_network_address: Optional[str] = None
    bgp_prefix_last_address: Optional[str] = None
    total_addresses: Optional[int] = None
    carriers: List[Carrier] = field(default_factory=list)
    via_carriers: List[Carrier] = field(default_factory=list)


@dataclass
class CountryByIpResponse:
    """Country information geolocated from an IP address."""
    ip: Optional[str] = None
    locality_language_requested: Optional[str] = None
    is_reachable_globally: bool = False
    country: Optional[Country] = None
    last_updated: Optional[str] = None


@dataclass
class AsnRankEntry:
    """A single ASN entry in the rank list."""
    asn: Optional[str] = None
    asn_numeric: Optional[int] = None
    organisation: Optional[str] = None
    name: Optional[str] = None
    registry: Optional[str] = None
    registered_country: Optional[str] = None
    registered_country_name: Optional[str] = None
    total_ipv4_addresses: Optional[int] = None
    rank: Optional[int] = None


@dataclass
class AsnRankListResponse:
    """Paginated list of all ASNs ranked by IPv4 address space."""
    total: int = 0
    offset: int = 0
    batch: int = 0
    asns: List[AsnRankEntry] = field(default_factory=list)


@dataclass
class TorExitNode:
    """A single geolocated Tor exit node."""
    ip: Optional[str] = None
    country_name: Optional[str] = None
    country_code: Optional[str] = None
    carriers: List[Carrier] = field(default_factory=list)


@dataclass
class TorExitNodesResponse:
    """Paginated list of active Tor exit nodes."""
    total: int = 0
    offset: int = 0
    batch: int = 0
    nodes: List[TorExitNode] = field(default_factory=list)
