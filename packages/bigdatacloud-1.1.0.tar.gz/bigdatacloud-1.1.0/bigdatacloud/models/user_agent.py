from __future__ import annotations
from dataclasses import dataclass
from typing import Optional


@dataclass
class UserAgentResponse:
    """Response from the User Agent Parser API."""
    device: Optional[str] = None
    """Device type (e.g. 'Desktop', 'Mobile', 'Tablet', 'Spider')."""
    os: Optional[str] = None
    """Operating system (e.g. 'iOS', 'Android', 'Windows')."""
    user_agent: Optional[str] = None
    """Browser or user-agent name (e.g. 'Chrome', 'Safari', 'curl')."""
    family: Optional[str] = None
    """Browser family (e.g. 'Chrome Mobile', 'Mobile Safari')."""
    is_spider: Optional[bool] = None
    is_mobile: Optional[bool] = None
    user_agent_display: Optional[str] = None
    """Human-readable summary (e.g. 'iOS Mobile Safari 17.0')."""
