from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class Language:
    """An ISO 639-1 administrative language associated with a country."""
    iso_alpha3: Optional[str] = None
    """ISO 639-3 three-letter language code (e.g. 'eng')."""
    iso_alpha2: Optional[str] = None
    """ISO 639-1 two-letter language code (e.g. 'en')."""
    iso_name: Optional[str] = None
    """English name of the language as defined by ISO (e.g. 'English')."""
    native_name: Optional[str] = None
    """The language's own name written in that language (e.g. 'हिन्दी' for Hindi)."""


@dataclass
class Currency:
    """Currency information as defined by ISO 4217."""
    numeric_code: Optional[int] = None
    """ISO 4217 numeric currency code (e.g. 36 for AUD)."""
    code: Optional[str] = None
    """ISO 4217 three-letter currency code (e.g. 'AUD')."""
    name: Optional[str] = None
    """English name of the currency (e.g. 'Australian Dollar')."""
    minor_units: Optional[int] = None
    """Number of minor units (decimal places) for the currency."""


@dataclass
class WorldBankRegion:
    """A World Bank classification node (region or income level)."""
    id: Optional[str] = None
    iso2_code: Optional[str] = None
    value: Optional[str] = None
    """Human-readable classification name (e.g. 'South Asia' or 'Lower middle income')."""


@dataclass
class Country:
    """Detailed country information including ISO codes, languages, currency, and World Bank classification."""
    iso_alpha2: Optional[str] = None
    """ISO 3166-1 Alpha-2 two-letter country code (e.g. 'AU')."""
    iso_alpha3: Optional[str] = None
    """ISO 3166-1 Alpha-3 three-letter country code (e.g. 'AUS')."""
    m49_code: Optional[int] = None
    """United Nations M.49 numeric country code."""
    name: Optional[str] = None
    """Country name localised to the requested language."""
    iso_name: Optional[str] = None
    """Short English country name as defined by ISO 3166-1."""
    iso_name_full: Optional[str] = None
    """Full official English country name as defined by ISO 3166-1."""
    iso_admin_languages: List[Language] = field(default_factory=list)
    """Administrative languages as defined by ISO 3166-1."""
    un_region: Optional[str] = None
    """Region name as defined by the United Nations."""
    currency: Optional[Currency] = None
    """Currency as defined by ISO 4217."""
    wb_region: Optional[WorldBankRegion] = None
    """World Bank region classification."""
    wb_income_level: Optional[WorldBankRegion] = None
    """World Bank income level classification."""
    calling_code: Optional[str] = None
    """International dialling code without the leading '+' (e.g. '61' for Australia)."""
    country_flag_emoji: Optional[str] = None
    """Country flag as a Unicode emoji (e.g. '🇦🇺')."""
    wikidata_id: Optional[str] = None
    """Wikidata item identifier for the country."""
    geoname_id: Optional[int] = None
    """GeoNames.org unique identifier for the country."""
    is_independent: Optional[bool] = None
    """Whether the country/territory is independent according to ISO 3166 records."""


@dataclass
class Location:
    """Geolocation data including city, subdivision, coordinates, and postcode."""
    principal_subdivision: Optional[str] = None
    """Localised principal subdivision name (state or province)."""
    iso_principal_subdivision: Optional[str] = None
    """Principal subdivision name as defined by ISO 3166-2."""
    iso_principal_subdivision_code: Optional[str] = None
    """ISO 3166-2 code for the principal subdivision (e.g. 'AU-NSW')."""
    continent: Optional[str] = None
    """Localised continent name."""
    continent_code: Optional[str] = None
    """ISO continent code (e.g. 'OC' for Oceania)."""
    city: Optional[str] = None
    """The most significant populated place. Use locality_name as fallback."""
    locality_name: Optional[str] = None
    """The most granular named locality (suburb, village, or town)."""
    postcode: Optional[str] = None
    """Postcode for the location, if available."""
    latitude: Optional[float] = None
    """Latitude of the estimated geolocation point in decimal degrees (WGS 84)."""
    longitude: Optional[float] = None
    """Longitude of the estimated geolocation point in decimal degrees (WGS 84)."""
    plus_code: Optional[str] = None
    """Open Location Code (Plus Code) for this location (e.g. '4RRH46J6+22')."""
    country_name: Optional[str] = None
    """Localised country name."""
    country_code: Optional[str] = None
    """ISO 3166-1 Alpha-2 country code."""
    time_zone: Optional[object] = None
    """Timezone information for this location, if included. Use as TimezoneResponse."""


@dataclass
class Carrier:
    """An Autonomous System (carrier) that announces a network on BGP."""
    asn: Optional[str] = None
    """The ASN in prefixed string format (e.g. 'AS13335')."""
    asn_numeric: Optional[int] = None
    """The ASN as an integer (e.g. 13335)."""
    organisation: Optional[str] = None
    """The organisation the AS is registered for."""
    name: Optional[str] = None
    """The short handle or network name assigned by the RIR (e.g. 'CLOUDFLARENET')."""
    registry: Optional[str] = None
    """The Regional Internet Registry (e.g. 'ARIN', 'RIPE', 'APNIC')."""
    registered_country: Optional[str] = None
    """ISO 3166-1 Alpha-2 code of the country the AS is registered in."""
    registered_country_name: Optional[str] = None
    """Localised name of the country the AS is registered in."""
    total_ipv4_addresses: Optional[int] = None
    """Total number of IPv4 addresses announced by this AS."""
    rank: Optional[int] = None
    """Global rank of the AS by total IPv4 address space (1 = largest)."""
    rank_text: Optional[str] = None
    """Human-readable rank string (e.g. '#297 out of 79,835')."""


@dataclass
class GeoPoint:
    """A latitude/longitude coordinate point."""
    latitude: float = 0.0
    longitude: float = 0.0


@dataclass
class Network:
    """Short network information for an IP address."""
    registry: Optional[str] = None
    registry_status: Optional[str] = None
    registered_country: Optional[str] = None
    registered_country_name: Optional[str] = None
    organisation: Optional[str] = None
    type: Optional[str] = None
    hosting_likelihood: Optional[int] = None
    """The likelihood (0–10) that this IP originates from a hosting/cloud environment."""
    is_reachable_globally: Optional[bool] = None
    is_bogon: Optional[bool] = None
    bgp_prefix: Optional[str] = None
    bgp_prefix_network_address: Optional[str] = None
    bgp_prefix_last_address: Optional[str] = None
    total_addresses: Optional[int] = None
    carriers: List[Carrier] = field(default_factory=list)
    via_carriers: List[Carrier] = field(default_factory=list)
