from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional
from .common import Country, Location, Carrier, GeoPoint


@dataclass
class HazardReport:
    """Detailed hazard and threat report for an IP address."""
    is_known_as_tor_server: bool = False
    is_known_as_vpn: bool = False
    is_known_as_proxy: bool = False
    is_spamhaus_drop: bool = False
    """Listed on the Spamhaus DROP (Don't Route Or Peer) list."""
    is_spamhaus_edrop: bool = False
    """Listed on the Spamhaus EDROP list."""
    is_spamhaus_asn_drop: bool = False
    """Listed on the Spamhaus ASN-drop list."""
    is_blacklisted_uceprotect: bool = False
    is_blacklisted_blocklist_de: bool = False
    is_known_as_mail_server: bool = False
    is_known_as_public_router: bool = False
    is_bogon: bool = False
    is_unreachable: bool = False
    hosting_likelihood: int = 0
    """The likelihood (0–10) that this IP originates from a hosting/cloud environment."""
    is_hosting_asn: bool = False
    is_cellular: bool = False
    i_cloud_private_relay: bool = False


@dataclass
class IpNetwork:
    """Network information for an IP address including BGP prefix and carrier ASNs."""
    registry: Optional[str] = None
    registry_status: Optional[str] = None
    registered_country: Optional[str] = None
    registered_country_name: Optional[str] = None
    organisation: Optional[str] = None
    is_reachable_globally: bool = False
    is_bogon: bool = False
    bgp_prefix: Optional[str] = None
    bgp_prefix_network_address: Optional[str] = None
    bgp_prefix_last_address: Optional[str] = None
    total_addresses: Optional[int] = None
    carriers: List[Carrier] = field(default_factory=list)
    via_carriers: List[Carrier] = field(default_factory=list)


@dataclass
class IpGeolocationResponse:
    """Response from the IP Geolocation API."""
    ip: Optional[str] = None
    """The requested IP address in string format."""
    locality_language_requested: Optional[str] = None
    is_reachable_globally: bool = False
    """Whether the IP is present on the global BGP routing table."""
    country: Optional[Country] = None
    location: Optional[Location] = None
    network: Optional[IpNetwork] = None
    last_updated: Optional[str] = None
    """UTC timestamp (ISO 8601) when the geolocation was last assessed."""


@dataclass
class IpGeolocationWithConfidenceAreaResponse(IpGeolocationResponse):
    """Extends IpGeolocationResponse with confidence level and area polygon."""
    confidence: Optional[str] = None
    """Confidence level: 'low', 'moderate', or 'high'."""
    confidence_area: List[GeoPoint] = field(default_factory=list)
    """
    Flat list encoding one or more closed polygons. May contain multiple polygons
    concatenated together. Use ConfidenceAreaHelper.split_into_polygons() to split
    into individual rings before rendering or spatial operations.
    """


@dataclass
class IpGeolocationFullResponse(IpGeolocationWithConfidenceAreaResponse):
    """Extends confidence area response with a full hazard report and security threat summary."""
    security_threat: Optional[str] = None
    """Human-readable summary of the most significant security threat detected."""
    hazard_report: Optional[HazardReport] = None
