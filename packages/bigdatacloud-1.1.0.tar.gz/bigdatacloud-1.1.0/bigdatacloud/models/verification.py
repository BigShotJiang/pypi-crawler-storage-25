from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
from .common import Country


@dataclass
class PhoneValidationResponse:
    """Response from the Phone Number Validation API."""
    is_valid: bool = False
    e164_format: Optional[str] = None
    """Phone number in E.164 format (e.g. '+61412345678')."""
    international_format: Optional[str] = None
    """Phone number in international dialling format with spaces."""
    national_format: Optional[str] = None
    """Phone number formatted for local dialling within its country."""
    location: Optional[str] = None
    """Estimated geographic location of the number."""
    line_type: Optional[str] = None
    """Line type: MOBILE, FIXED_LINE, VOIP, TOLL_FREE, etc."""
    country: Optional[Country] = None


@dataclass
class PhoneValidationByIpResponse(PhoneValidationResponse):
    """Phone validation using caller IP for country detection."""
    pass


@dataclass
class EmailVerificationResponse:
    """Response from the Email Verification API."""
    input_data: Optional[str] = None
    """The original email address submitted for verification."""
    is_valid: bool = False
    """Whether the email passed all verification checks."""
    is_syntax_valid: bool = False
    is_mail_server_defined: Optional[bool] = None
    """Whether the domain has an MX record and is configured to receive emails."""
    is_known_spammer_domain: bool = False
    is_disposable: bool = False
    """Whether the domain is a known disposable/temporary email service."""
