from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional
from .time_and_location import TimezoneResponse


@dataclass
class LocalityItem:
    """A single entry in the locality information hierarchy."""
    name: Optional[str] = None
    description: Optional[str] = None
    iso_name: Optional[str] = None
    order: Optional[int] = None
    admin_level: Optional[int] = None
    """OpenStreetMap administrative level (2=country, 4=state, 8=city etc.)."""
    iso_code: Optional[str] = None
    wikidata_id: Optional[str] = None
    geoname_id: Optional[int] = None


@dataclass
class LocalityInfo:
    """Structured locality information organised into administrative and informative hierarchies."""
    administrative: List[LocalityItem] = field(default_factory=list)
    informative: List[LocalityItem] = field(default_factory=list)


@dataclass
class ReverseGeocodeResponse:
    """Response from the Reverse Geocoding API."""
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    locality_language_requested: Optional[str] = None
    continent: Optional[str] = None
    continent_code: Optional[str] = None
    country_name: Optional[str] = None
    country_code: Optional[str] = None
    principal_subdivision: Optional[str] = None
    principal_subdivision_code: Optional[str] = None
    city: Optional[str] = None
    locality: Optional[str] = None
    """The most granular named locality (suburb, village, or town)."""
    postcode: Optional[str] = None
    plus_code: Optional[str] = None
    """Open Location Code (Plus Code) for this location."""
    locality_info: Optional[LocalityInfo] = None


@dataclass
class ReverseGeocodeWithTimezoneResponse(ReverseGeocodeResponse):
    """Extends reverse geocode response with full timezone information."""
    time_zone: Optional[TimezoneResponse] = None
