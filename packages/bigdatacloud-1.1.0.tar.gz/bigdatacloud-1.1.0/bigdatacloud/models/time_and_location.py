from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional
from .common import Country, WorldBankRegion, Currency, Language


@dataclass
class TimezoneResponse:
    """Timezone information including IANA ID, UTC offset, DST status, and local time."""
    iana_time_id: Optional[str] = None
    """IANA timezone ID (e.g. 'Australia/Sydney')."""
    display_name: Optional[str] = None
    """User-friendly display name (e.g. '(UTC+10:00) Eastern Australia Time')."""
    effective_time_zone_full: Optional[str] = None
    """Full name of the effective timezone, adjusted for DST."""
    effective_time_zone_short: Optional[str] = None
    """Abbreviated timezone name, adjusted for DST (e.g. 'AEST')."""
    utc_offset_seconds: Optional[int] = None
    """Effective UTC offset in seconds, adjusted for DST."""
    utc_offset: Optional[str] = None
    """Effective UTC offset as formatted string (e.g. '+10')."""
    is_daylight_saving_time: Optional[bool] = None
    local_time: Optional[str] = None
    """Current local time in ISO 8601 format."""


@dataclass
class CountryInfoResponse(Country):
    """Response from the Country Info API — detailed information about a country by ISO code."""
    pass
