"""
Lightweight JSON → dataclass deserialiser.
Converts snake_case and camelCase field names automatically.
"""
from __future__ import annotations
import re
from typing import Any, Dict, List, Optional, Type, TypeVar, get_type_hints
import dataclasses

T = TypeVar("T")


def _to_snake(name: str) -> str:
    """Convert camelCase or PascalCase to snake_case."""
    s1 = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1_\2", name)
    return re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", s1).lower()


def _get_origin(tp: Any) -> Any:
    return getattr(tp, "__origin__", None)


def _get_args(tp: Any) -> tuple:
    return getattr(tp, "__args__", ())


def from_dict(cls: Type[T], data: Optional[Dict[str, Any]]) -> Optional[T]:
    """Deserialise a dict into a dataclass instance, handling nested types."""
    if data is None:
        return None
    if not isinstance(data, dict):
        return None

    if not dataclasses.is_dataclass(cls):
        return data  # type: ignore

    try:
        hints = get_type_hints(cls)
    except Exception:
        # Fall back to field annotations if get_type_hints fails (forward refs etc.)
        hints = {f.name: f.type for f in dataclasses.fields(cls)}  # type: ignore
    kwargs: Dict[str, Any] = {}

    for f in dataclasses.fields(cls):  # type: ignore
        field_name = f.name  # snake_case field name
        # Try snake_case first, then camelCase variants
        camel = re.sub(r"_([a-z])", lambda m: m.group(1).upper(), field_name)
        # Special: i_cloud → iCloud
        camel2 = re.sub(r"_([A-Z])", lambda m: m.group(1), camel)

        raw = data.get(field_name) or data.get(camel) or data.get(camel2)

        if raw is None:
            # Use the default
            kwargs[field_name] = f.default if f.default is not dataclasses.MISSING else (
                f.default_factory() if f.default_factory is not dataclasses.MISSING else None  # type: ignore
            )
            continue

        field_type = hints.get(field_name)
        kwargs[field_name] = _convert(raw, field_type)

    return cls(**kwargs)  # type: ignore


def _convert(value: Any, tp: Any) -> Any:
    """Recursively convert value to the target type."""
    if tp is None or value is None:
        return value

    origin = _get_origin(tp)
    args = _get_args(tp)

    # Optional[X] → unwrap
    if origin is type(None):
        return None
    if str(origin) in ("<class 'typing.Union'>", "typing.Union") or (
        hasattr(tp, "__origin__") and tp.__origin__ is type(None)
    ):
        # Handle Optional properly
        pass

    # Check for Union (Optional is Union[X, None])
    import typing
    if hasattr(typing, "get_args"):
        actual_args = typing.get_args(tp)
        actual_origin = typing.get_origin(tp)
        if actual_origin is typing.Union:
            # Pick the non-None type
            non_none = [a for a in actual_args if a is not type(None)]
            if non_none:
                return _convert(value, non_none[0])
            return value

    # List[X]
    if origin is list:
        item_type = args[0] if args else None
        if isinstance(value, list):
            return [_convert(item, item_type) for item in value]
        return []

    # Dataclass
    if dataclasses.is_dataclass(tp) and isinstance(value, dict):
        return from_dict(tp, value)

    # Primitives
    if tp in (int, float, str, bool) and value is not None:
        try:
            return tp(value)
        except (ValueError, TypeError):
            return value

    return value
