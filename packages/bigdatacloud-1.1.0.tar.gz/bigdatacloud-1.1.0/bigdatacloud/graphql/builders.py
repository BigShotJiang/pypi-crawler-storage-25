"""Fluent query builders for GraphQL field selection."""
from __future__ import annotations
from typing import Callable, Optional


class _QB:
    """Internal query builder accumulator."""
    def __init__(self):
        self._fields: list[str] = []

    def add(self, field: str) -> "_QB":
        self._fields.append(field)
        return self

    def nested(self, field: str, inner: "_QB") -> "_QB":
        self._fields.append(f"{field} {{ {inner.build()} }}")
        return self

    def build(self) -> str:
        return " ".join(self._fields)


class IpDataQueryBuilder:
    """
    Fluent builder for ipData GraphQL field selection.

    Example::

        result = client.graphql.ip_geolocation.ip_data("1.1.1.1",
            lambda q: q.locality().confidence().hazard_report())
    """
    def __init__(self):
        self._b = _QB()

    def lat_lng(self) -> "IpDataQueryBuilder":
        """Include latitude, longitude and plus code."""
        self._b.nested("latLng", _QB().add("latitude").add("longitude").add("plusCode"))
        return self

    def confidence(self) -> "IpDataQueryBuilder":
        """Include confidence level and description."""
        self._b.nested("confidence", _QB().add("value").add("description"))
        return self

    def country(self, configure: Optional[Callable[["_CountryQB"], None]] = None) -> "IpDataQueryBuilder":
        """Include country information."""
        cb = _CountryQB()
        if configure: configure(cb)
        self._b.nested("country", cb._b)
        return self

    def locality(self, configure: Optional[Callable[["_LocalityQB"], None]] = None) -> "IpDataQueryBuilder":
        """Include locality information (city, subdivision, postcode etc.)."""
        lb = _LocalityQB()
        if configure: configure(lb)
        self._b.nested("locality", lb._b)
        return self

    def timezone(self) -> "IpDataQueryBuilder":
        """Include timezone information."""
        self._b.nested("timezone", _QB().add("ianaTimeId").add("utcOffset").add("isDaylightSavingTime").add("localTime"))
        return self

    def hazard_report(self) -> "IpDataQueryBuilder":
        """Include hazard and threat report."""
        self._b.nested("hazardReport", _QB()
            .add("securityThreat").add("isKnownAsTorServer").add("isKnownAsVpn")
            .add("isKnownAsProxy").add("isSpamhausDrop").add("hostingLikelihood")
            .add("isCellular").nested("userRisk", _QB().add("risk").add("description")))
        return self

    def network(self) -> "IpDataQueryBuilder":
        """Include network information."""
        self._b.nested("network", _QB()
            .add("registryStatus").add("isBogon")
            .nested("bgpPrefix", _QB().add("cidrString")
                .nested("firstIp", _QB().add("ipString"))
                .nested("lastIp", _QB().add("ipString"))))
        return self

    def build(self) -> str:
        return self._b.build()


class LocationDataQueryBuilder:
    """Fluent builder for locationData (Reverse Geocoding) GraphQL field selection."""
    def __init__(self):
        self._b = _QB()

    def lat_lng(self) -> "LocationDataQueryBuilder":
        self._b.nested("latLng", _QB().add("latitude").add("longitude").add("plusCode"))
        return self

    def country(self, configure: Optional[Callable[["_CountryQB"], None]] = None) -> "LocationDataQueryBuilder":
        cb = _CountryQB()
        if configure: configure(cb)
        self._b.nested("country", cb._b)
        return self

    def locality(self, configure: Optional[Callable[["_LocalityQB"], None]] = None) -> "LocationDataQueryBuilder":
        lb = _LocalityQB()
        if configure: configure(lb)
        self._b.nested("locality", lb._b)
        return self

    def timezone(self) -> "LocationDataQueryBuilder":
        self._b.nested("timezone", _QB().add("ianaTimeId").add("utcOffset").add("isDaylightSavingTime").add("localTime"))
        return self

    def build(self) -> str:
        return self._b.build()


class AsnInfoFullQueryBuilder:
    """Fluent builder for asnInfoFull (Network Engineering) GraphQL field selection."""
    def __init__(self):
        self._b = _QB()

    def basic_info(self) -> "AsnInfoFullQueryBuilder":
        """Include ASN, organisation, name, registry, rank, and prefix counts."""
        self._b.add("asn").add("asnNumeric").add("organisation").add("name")
        self._b.add("registry")
        self._b.nested("registeredCountry", _QB().add("isoAlpha2").add("name"))
        self._b.add("rank").add("rankText")
        self._b.add("totalIpv4Addresses").add("totalIpv4Prefixes").add("totalIpv6Prefixes")
        return self

    def receiving_from(self) -> "AsnInfoFullQueryBuilder":
        """Include upstream providers."""
        self._b.add("totalReceivingFrom")
        self._b.nested("receivingFrom", _QB().add("asn").add("organisation").add("rank"))
        return self

    def transit_to(self) -> "AsnInfoFullQueryBuilder":
        """Include downstream peers."""
        self._b.add("totalTransitTo")
        self._b.nested("transitTo", _QB().add("asn").add("organisation").add("rank"))
        return self

    def confidence_area(self) -> "AsnInfoFullQueryBuilder":
        """Include operational service area polygon."""
        self._b.nested("confidenceArea", _QB().add("latitude").add("longitude"))
        return self

    def build(self) -> str:
        return self._b.build()


class _CountryQB:
    """Internal country field builder."""
    def __init__(self):
        self._b = _QB()
        self._b.add("isoAlpha2").add("name").add("callingCode")

    def iso_names(self) -> "_CountryQB":
        self._b.add("isoAlpha3").add("isoName").add("isoNameFull")
        return self

    def world_bank(self) -> "_CountryQB":
        self._b.nested("wbRegion", _QB().add("value"))
        self._b.nested("wbIncomeLevel", _QB().add("value"))
        return self

    def currency(self) -> "_CountryQB":
        self._b.nested("currency", _QB().add("code").add("isoName"))
        return self

    def flag_emoji(self) -> "_CountryQB":
        self._b.add("countryFlagEmoji")
        return self


class _LocalityQB:
    """Internal locality field builder."""
    def __init__(self):
        self._b = _QB()
        self._b.add("city").add("localityName").add("principalSubdivision").add("postcode").add("continentCode")

    def iso_subdivision(self) -> "_LocalityQB":
        self._b.add("isoPrincipalSubdivisionCode")
        return self

    def administrative(self) -> "_LocalityQB":
        self._b.nested("administrative", _QB().add("name").add("adminLevel").add("isoCode"))
        return self
