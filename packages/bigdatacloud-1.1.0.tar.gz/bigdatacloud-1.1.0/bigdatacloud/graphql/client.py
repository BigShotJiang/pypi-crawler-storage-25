"""GraphQL client — one sub-client per API package."""
from __future__ import annotations
import json
from typing import Any, Callable, Dict, Optional
import httpx
from .builders import IpDataQueryBuilder, LocationDataQueryBuilder, AsnInfoFullQueryBuilder


class BigDataCloudGraphQLException(Exception):
    """Raised when a GraphQL response contains errors."""
    def __init__(self, message: str, errors: list):
        super().__init__(message)
        self.errors = errors


class GraphQLClient:
    """
    GraphQL interface — one sub-client per API package.
    Each package has its own dedicated endpoint; queries cannot cross packages.

    Example::

        result = client.graphql.ip_geolocation.ip_data("1.1.1.1",
            lambda q: q.locality().confidence())
        print(result["locality"]["city"])

    For full control, send raw queries::

        data = client.graphql.ip_geolocation.query_raw(
            '{ ipData(ip: "1.1.1.1") { locality { city } } }'
        )
    """

    def __init__(self, http: httpx.Client, api_key: str):
        self._http = http
        self._api_key = api_key
        self.ip_geolocation = IpGeolocationGraphQL(self)
        self.reverse_geocoding = ReverseGeocodingGraphQL(self)
        self.verification = VerificationGraphQL(self)
        self.network_engineering = NetworkEngineeringGraphQL(self)

    def _execute(self, endpoint: str, query: str) -> Dict[str, Any]:
        """Execute a GraphQL query against a package endpoint."""
        url = f"graphql/{endpoint}?key={self._api_key}"
        response = self._http.post(
            url,
            content=json.dumps({"query": query}),
            headers={"Content-Type": "application/json"},
        )
        data = response.json()
        if "errors" in data:
            msg = data["errors"][0].get("message", "GraphQL error")
            raise BigDataCloudGraphQLException(
                f"GraphQL error on '{endpoint}': {msg}", data["errors"]
            )
        return data.get("data", {})

    def close(self):
        self._http.close()


class IpGeolocationGraphQL:
    """GraphQL queries for the IP Geolocation package."""

    def __init__(self, client: GraphQLClient):
        self._c = client

    def ip_data(
        self,
        ip: Optional[str] = None,
        configure: Optional[Callable[[IpDataQueryBuilder], None]] = None,
        locale: str = "en",
    ) -> Dict[str, Any]:
        """
        Query ipData — the primary IP Geolocation GraphQL query.
        Use the builder to select exactly the fields you need.

        Example::

            result = client.graphql.ip_geolocation.ip_data("1.1.1.1",
                lambda q: q.locality().confidence().country(lambda c: c.flag_emoji()))
            print(result["locality"]["city"])
        """
        builder = IpDataQueryBuilder()
        if configure is None:
            builder.lat_lng().confidence().country().locality().timezone()
        else:
            configure(builder)
        ip_arg = f'ip: "{ip}", ' if ip else ""
        query = f'{{ ipData({ip_arg}locale: "{locale}") {{ {builder.build()} }} }}'
        return self._c._execute("ip-geolocation", query)["ipData"]

    def country_info(self, country_code: str, locale: str = "en") -> Dict[str, Any]:
        """Query countryInfo — detailed country information by ISO code."""
        query = f'{{ countryInfo(code: "{country_code}", locale: "{locale}") {{ isoAlpha2 name callingCode currency {{ code name }} wbRegion {{ value }} wbIncomeLevel {{ value }} }} }}'
        return self._c._execute("ip-geolocation", query)["countryInfo"]

    def user_agent(self, user_agent_string: str) -> Dict[str, Any]:
        """Query userAgent — parses a User-Agent string."""
        escaped = user_agent_string.replace('"', '\\"')
        query = f'{{ userAgent(ua: "{escaped}") {{ device os family isMobile isSpider userAgentDisplay }} }}'
        return self._c._execute("ip-geolocation", query)["userAgent"]

    def timezone_info(self, iana_time_zone_id: str) -> Dict[str, Any]:
        """Query timezoneInfo — timezone details by IANA ID."""
        query = f'{{ timezoneInfo(timeZoneId: "{iana_time_zone_id}") {{ ianaTimeId displayName utcOffset utcOffsetSeconds isDaylightSavingTime localTime }} }}'
        return self._c._execute("ip-geolocation", query)["timezoneInfo"]

    def query_raw(self, query: str) -> Dict[str, Any]:
        """Send a raw GraphQL query string to the IP Geolocation endpoint."""
        return self._c._execute("ip-geolocation", query)


class ReverseGeocodingGraphQL:
    """GraphQL queries for the Reverse Geocoding package."""

    def __init__(self, client: GraphQLClient):
        self._c = client

    def location_data(
        self,
        latitude: float,
        longitude: float,
        configure: Optional[Callable[[LocationDataQueryBuilder], None]] = None,
        locale: str = "en",
    ) -> Dict[str, Any]:
        """
        Query locationData — resolves GPS coordinates to locality, country, and timezone.

        Example::

            result = client.graphql.reverse_geocoding.location_data(-33.87, 151.21,
                lambda q: q.locality().country(lambda c: c.flag_emoji()).timezone())
        """
        builder = LocationDataQueryBuilder()
        if configure is None:
            builder.country().locality().timezone()
        else:
            configure(builder)
        query = f'{{ locationData(latitude: {latitude}, longitude: {longitude}, locale: "{locale}") {{ {builder.build()} }} }}'
        return self._c._execute("reverse-geocoding", query)["locationData"]

    def query_raw(self, query: str) -> Dict[str, Any]:
        return self._c._execute("reverse-geocoding", query)


class VerificationGraphQL:
    """GraphQL queries for the Phone & Email Verification package."""

    def __init__(self, client: GraphQLClient):
        self._c = client

    def email_verification(self, email_address: str) -> Dict[str, Any]:
        """Query emailVerification — verifies an email address."""
        escaped = email_address.replace('"', '\\"')
        query = f'{{ emailVerification(email: "{escaped}") {{ inputData isValid isSyntaxValid isMailServerDefined isKnownSpammerDomain isDisposable }} }}'
        return self._c._execute("phone-email", query)["emailVerification"]

    def phone_number(self, phone_number: str, country_code: Optional[str] = None) -> Dict[str, Any]:
        """Query phoneNumber — validates and formats a phone number."""
        escaped = phone_number.replace('"', '\\"')
        country_arg = f', countryCode: "{country_code}"' if country_code else ""
        query = f'{{ phoneNumber(number: "{escaped}"{country_arg}) {{ isValid e164Format internationalFormat nationalFormat lineType country {{ isoAlpha2 name callingCode }} }} }}'
        return self._c._execute("phone-email", query)["phoneNumber"]

    def query_raw(self, query: str) -> Dict[str, Any]:
        return self._c._execute("phone-email", query)


class NetworkEngineeringGraphQL:
    """GraphQL queries for the Network Engineering package."""

    def __init__(self, client: GraphQLClient):
        self._c = client

    def asn_info_full(
        self,
        asn: str,
        configure: Optional[Callable[[AsnInfoFullQueryBuilder], None]] = None,
        locale: str = "en",
    ) -> Dict[str, Any]:
        """Query asnInfoFull — full ASN information including peers and service area."""
        builder = AsnInfoFullQueryBuilder()
        if configure is None:
            builder.basic_info().receiving_from()
        else:
            configure(builder)
        query = f'{{ asnInfoFull(asn: "{asn}", locale: "{locale}") {{ {builder.build()} }} }}'
        return self._c._execute("network-engineering", query)["asnInfoFull"]

    def network_by_ip(self, ip: str, locale: str = "en") -> Dict[str, Any]:
        """Query network — network information for an IP address."""
        query = f'{{ network(ip: "{ip}", locale: "{locale}") {{ bgpPrefix {{ cidrString firstIp {{ ipString }} lastIp {{ ipString }} }} registryStatus isBogon carriers {{ asn organisation registeredCountry }} }} }}'
        return self._c._execute("network-engineering", query)["network"]

    def query_raw(self, query: str) -> Dict[str, Any]:
        return self._c._execute("network-engineering", query)
