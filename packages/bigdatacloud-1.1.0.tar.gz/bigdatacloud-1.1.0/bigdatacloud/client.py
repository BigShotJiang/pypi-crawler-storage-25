"""
BigDataCloud Python SDK
Official client for BigDataCloud APIs.
"""
from __future__ import annotations
import os
from typing import Any, Dict, List, Optional, Type, TypeVar
import httpx
from ._deserialise import from_dict
from .models import *
from .models.time_and_location import CountryInfoResponse, TimezoneResponse
from .models.user_agent import UserAgentResponse
from .models.network import (
    HazardReportResponse, UserRiskResponse, AsnInfoResponse, AsnInfoShortResponse,
    AsnPeersResponse, AsnTransitResponse, PrefixesListResponse, NetworkByCidrResponse,
    NetworkByIpResponse, CountryByIpResponse, AsnRankListResponse, TorExitNodesResponse,
)
from .graphql import GraphQLClient

T = TypeVar("T")

DEFAULT_BASE_URL = "https://api-bdc.net/data/"
DEFAULT_GRAPHQL_BASE_URL = "https://api-bdc.net/"


class BigDataCloudException(Exception):
    """Raised when the BigDataCloud API returns an error response."""
    def __init__(self, status_code: int, message: str, response_body: str = ""):
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body


class BigDataCloudClient:
    """
    Official Python client for BigDataCloud APIs.
    Thread-safe — create once and reuse across your application.

    Usage::

        # Reads BIGDATACLOUD_API_KEY from environment
        client = BigDataCloudClient.from_environment()

        # Or pass the key directly
        client = BigDataCloudClient("your-api-key")

        # IP Geolocation
        geo = client.ip_geolocation.get("1.1.1.1")
        print(geo.location.city)

    Use as a context manager for automatic connection cleanup::

        with BigDataCloudClient.from_environment() as client:
            geo = client.ip_geolocation.get("1.1.1.1")
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
        http_client: Optional[httpx.Client] = None,
    ):
        if not api_key or not api_key.strip():
            raise ValueError("API key must not be empty.")
        self._api_key = api_key
        self._owns_client = http_client is None
        self._http = http_client or httpx.Client(
            base_url=base_url,
            timeout=timeout,
            headers={"Accept": "application/json"},
        )
        graphql_client = httpx.Client(
            base_url=DEFAULT_GRAPHQL_BASE_URL,
            timeout=timeout,
            headers={"Accept": "application/json"},
        )
        self.ip_geolocation = IpGeolocationApi(self)
        self.reverse_geocoding = ReverseGeocodingApi(self)
        self.verification = VerificationApi(self)
        self.network_engineering = NetworkEngineeringApi(self)
        self.graphql = GraphQLClient(graphql_client, api_key)

    @classmethod
    def from_environment(cls) -> "BigDataCloudClient":
        """
        Create a client using the BIGDATACLOUD_API_KEY environment variable.

        Set the key::

            export BIGDATACLOUD_API_KEY=your-key-here

        Or for local development::

            # In your .env file
            BIGDATACLOUD_API_KEY=your-key-here
        """
        key = os.environ.get("BIGDATACLOUD_API_KEY")
        if not key:
            raise EnvironmentError(
                "BIGDATACLOUD_API_KEY environment variable is not set. "
                "Set it with: export BIGDATACLOUD_API_KEY=your-key-here"
            )
        return cls(key)

    def _get(self, endpoint: str, params: Dict[str, Any], response_type: Type[T]) -> T:
        """Core GET + deserialise. Thread-safe — no shared mutable state."""
        params = {k: v for k, v in params.items() if v is not None}
        params["key"] = self._api_key
        response = self._http.get(endpoint, params=params)
        if not response.is_success:
            raise BigDataCloudException(
                response.status_code,
                f"BigDataCloud API error {response.status_code} on '{endpoint}'.",
                response.text,
            )
        data = response.json()
        if isinstance(data, list):
            # List response (e.g. countries)
            item_type = response_type.__args__[0] if hasattr(response_type, "__args__") else None
            if item_type:
                return [from_dict(item_type, item) for item in data]  # type: ignore
            return data  # type: ignore
        return from_dict(response_type, data)  # type: ignore

    def close(self):
        """Close the underlying HTTP connections."""
        if self._owns_client:
            self._http.close()
        self.graphql.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


# ── IP Geolocation Package ────────────────────────────────────────────────────

class IpGeolocationApi:
    """IP Geolocation package — 12 endpoints."""

    def __init__(self, client: BigDataCloudClient):
        self._c = client

    def get(self, ip: Optional[str] = None, locality_language: str = "en") -> IpGeolocationResponse:
        """Returns geolocation data for an IP address."""
        p: Dict[str, Any] = {"localityLanguage": locality_language}
        if ip: p["ip"] = ip
        return self._c._get("ip-geolocation", p, IpGeolocationResponse)

    def get_with_confidence_area(self, ip: Optional[str] = None, locality_language: str = "en") -> IpGeolocationWithConfidenceAreaResponse:
        """Returns geolocation including confidence area polygon(s)."""
        p: Dict[str, Any] = {"localityLanguage": locality_language}
        if ip: p["ip"] = ip
        return self._c._get("ip-geolocation-with-confidence", p, IpGeolocationWithConfidenceAreaResponse)

    def get_full(self, ip: Optional[str] = None, locality_language: str = "en") -> IpGeolocationFullResponse:
        """Returns full geolocation including confidence area and hazard report."""
        p: Dict[str, Any] = {"localityLanguage": locality_language}
        if ip: p["ip"] = ip
        return self._c._get("ip-geolocation-full", p, IpGeolocationFullResponse)

    def get_country_by_ip(self, ip: Optional[str] = None, locality_language: str = "en") -> CountryByIpResponse:
        """Returns country information for an IP address."""
        p: Dict[str, Any] = {"localityLanguage": locality_language}
        if ip: p["ip"] = ip
        return self._c._get("country-by-ip", p, CountryByIpResponse)

    def get_country_info(self, country_code: str, locality_language: str = "en") -> CountryInfoResponse:
        """Returns detailed information about a country by ISO code."""
        return self._c._get("country-info", {"code": country_code, "localityLanguage": locality_language}, CountryInfoResponse)

    def get_all_countries(self, locality_language: str = "en") -> List[CountryInfoResponse]:
        """Returns a list of all countries with full details."""
        return self._c._get("countries", {"localityLanguage": locality_language}, List[CountryInfoResponse])  # type: ignore

    def get_hazard_report(self, ip: Optional[str] = None) -> HazardReportResponse:
        """Returns a detailed hazard and threat report for an IP address."""
        p: Dict[str, Any] = {}
        if ip: p["ip"] = ip
        return self._c._get("hazard-report", p, HazardReportResponse)

    def get_user_risk(self, ip: Optional[str] = None) -> UserRiskResponse:
        """Returns a risk assessment for an IP address — suitable for e-commerce and sign-up forms."""
        p: Dict[str, Any] = {}
        if ip: p["ip"] = ip
        return self._c._get("user-risk", p, UserRiskResponse)

    def get_asn_info(self, asn: str, locality_language: str = "en") -> AsnInfoShortResponse:
        """Returns short ASN information (no peers/transit lists)."""
        return self._c._get("asn-info", {"asn": asn, "localityLanguage": locality_language}, AsnInfoShortResponse)

    def get_network_by_ip(self, ip: str, locality_language: str = "en") -> NetworkByIpResponse:
        """Returns detailed network information for an IP address."""
        return self._c._get("network-by-ip", {"ip": ip, "localityLanguage": locality_language}, NetworkByIpResponse)

    def get_timezone_by_iana_id(self, iana_time_zone_id: str, utc_reference_seconds: Optional[int] = None) -> TimezoneResponse:
        """Returns timezone information for an IANA timezone ID (e.g. 'Australia/Sydney')."""
        p: Dict[str, Any] = {"timeZoneId": iana_time_zone_id}
        if utc_reference_seconds is not None: p["utcReference"] = utc_reference_seconds
        return self._c._get("timezone-info", p, TimezoneResponse)

    def get_timezone_by_ip(self, ip: Optional[str] = None) -> TimezoneResponse:
        """Returns timezone information for an IP address."""
        p: Dict[str, Any] = {}
        if ip: p["ip"] = ip
        return self._c._get("timezone-by-ip", p, TimezoneResponse)

    def parse_user_agent(self, user_agent_string: str) -> UserAgentResponse:
        """Parses a User-Agent string into structured device, OS and browser info."""
        if not user_agent_string.strip():
            raise ValueError("User-Agent string must not be empty.")
        return self._c._get("user-agent-info", {"userAgentRaw": user_agent_string}, UserAgentResponse)


# ── Reverse Geocoding Package ─────────────────────────────────────────────────

class ReverseGeocodingApi:
    """Reverse Geocoding package — 3 endpoints."""

    def __init__(self, client: BigDataCloudClient):
        self._c = client

    def reverse_geocode(self, latitude: float, longitude: float, locality_language: str = "en") -> ReverseGeocodeResponse:
        """Converts GPS coordinates to city, locality, subdivision, country, and full locality info."""
        return self._c._get("reverse-geocode", {
            "latitude": latitude, "longitude": longitude, "localityLanguage": locality_language
        }, ReverseGeocodeResponse)

    def reverse_geocode_with_timezone(self, latitude: float, longitude: float, locality_language: str = "en") -> ReverseGeocodeWithTimezoneResponse:
        """Converts GPS coordinates to locality and timezone in a single call."""
        return self._c._get("reverse-geocode-with-timezone", {
            "latitude": latitude, "longitude": longitude, "localityLanguage": locality_language
        }, ReverseGeocodeWithTimezoneResponse)

    def get_timezone_by_location(self, latitude: float, longitude: float) -> TimezoneResponse:
        """Returns timezone information for GPS coordinates."""
        return self._c._get("timezone-by-location", {
            "latitude": latitude, "longitude": longitude
        }, TimezoneResponse)


# ── Phone & Email Verification Package ───────────────────────────────────────

class VerificationApi:
    """Phone & Email Verification package — 3 endpoints."""

    def __init__(self, client: BigDataCloudClient):
        self._c = client

    def validate_phone(self, phone_number: str, country_code: str) -> PhoneValidationResponse:
        """Validates a phone number and returns its E.164 format, line type, and country.

        ``country_code`` is required (e.g. ``'AU'``, ``'US'``). It is used to resolve
        numbers that lack a country dial prefix. If you know the caller's IP address
        but not their country, use ``validate_phone_by_ip`` instead.

        Returns ``isValid: false`` for numbers that parse but do not exist.
        """
        if not phone_number.strip():
            raise ValueError("Phone number must not be empty.")
        if not country_code or not country_code.strip():
            raise ValueError(
                "country_code is required for validate_phone (e.g. 'AU', 'US'). "
                "If you know the caller's IP address, use validate_phone_by_ip instead."
            )
        return self._c._get("phone-number-validate", {"number": phone_number, "countryCode": country_code}, PhoneValidationResponse)

    def validate_phone_by_ip(self, phone_number: str, ip: str) -> PhoneValidationByIpResponse:
        """Validates a phone number using a known IP address for country detection.

        ``ip`` is required — pass the end user's IP address, not the server's.
        If you already know the country, use ``validate_phone`` with ``country_code`` instead.
        """
        if not phone_number.strip():
            raise ValueError("Phone number must not be empty.")
        if not ip or not ip.strip():
            raise ValueError(
                "ip is required for validate_phone_by_ip. "
                "Pass the end user's IP address. If you know the country instead, use validate_phone."
            )
        return self._c._get("phone-number-validate-by-ip", {"number": phone_number, "ip": ip}, PhoneValidationByIpResponse)

    def verify_email(self, email_address: str) -> EmailVerificationResponse:
        """Verifies an email address — checks syntax, mail server, and disposable status."""
        if not email_address.strip():
            raise ValueError("Email address must not be empty.")
        return self._c._get("email-verify", {"emailAddress": email_address}, EmailVerificationResponse)


# ── Network Engineering Package ───────────────────────────────────────────────

class NetworkEngineeringApi:
    """Network Engineering package — 4 published endpoints + sub-endpoints."""

    def __init__(self, client: BigDataCloudClient):
        self._c = client

    def get_asn_info_extended(self, asn: str, locality_language: str = "en") -> AsnInfoResponse:
        """Returns extended ASN info including peers, transit, prefix counts, and service area."""
        return self._c._get("asn-info-full", {"asn": asn, "localityLanguage": locality_language}, AsnInfoResponse)

    def get_receiving_from(self, asn: str, batch_size: int = 25, offset: int = 0, locality_language: str = "en") -> AsnPeersResponse:
        """Returns paginated list of upstream providers (ASNs from which this ASN receives traffic)."""
        return self._c._get("asn-info-receiving-from", {
            "asn": asn, "batchSize": batch_size, "offset": offset, "localityLanguage": locality_language
        }, AsnPeersResponse)

    def get_transit_to(self, asn: str, batch_size: int = 25, offset: int = 0, locality_language: str = "en") -> AsnTransitResponse:
        """Returns paginated list of downstream peers (ASNs to which this ASN provides transit)."""
        return self._c._get("asn-info-transit-to", {
            "asn": asn, "batchSize": batch_size, "offset": offset, "localityLanguage": locality_language
        }, AsnTransitResponse)

    def get_bgp_prefixes(self, asn: str, ipv4: bool = True, batch_size: int = 25, offset: int = 0) -> PrefixesListResponse:
        """Returns paginated list of active BGP prefixes (IPv4 or IPv6) for an ASN."""
        return self._c._get("prefixes-list", {
            "asn": asn, "isv4": "true" if ipv4 else "false",
            "batchSize": batch_size, "offset": offset
        }, PrefixesListResponse)

    def get_networks_by_cidr(self, cidr: str, locality_language: str = "en") -> NetworkByCidrResponse:
        """Returns all networks currently announced on BGP within a given CIDR range."""
        return self._c._get("network-by-cidr", {"cidr": cidr, "localityLanguage": locality_language}, NetworkByCidrResponse)

    def get_asn_rank_list(self, batch_size: int = 15, offset: int = 0) -> AsnRankListResponse:
        """Returns paginated ranked list of all ASNs by IPv4 address space."""
        return self._c._get("asn-rank-list", {"batchSize": batch_size, "offset": offset}, AsnRankListResponse)

    def get_tor_exit_nodes(self, batch_size: int = 25, offset: int = 0) -> TorExitNodesResponse:
        """Returns paginated list of active Tor exit nodes, geolocated to country and carrier."""
        return self._c._get("tor-exit-nodes-list", {"batchSize": batch_size, "offset": offset}, TorExitNodesResponse)
