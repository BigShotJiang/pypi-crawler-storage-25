"""
CAUM Wrappers — Zero-code integration for Anthropic and OpenAI.

Usage:
    import anthropic
    import caum

    caum.init("caum_live_xxx")
    client = caum.wrap_anthropic(anthropic.Anthropic())

    # Use client exactly as before — CAUM observes automatically
    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        messages=[{"role": "user", "content": "Fix the bug in auth.py"}],
        tools=[...],
    )
"""
import json
import logging
import uuid
from typing import Optional

from . import client as caum_client

logger = logging.getLogger("caum.wrapper")

_step_counters = {}  # session_id -> step count


def _next_step(session_id: str) -> int:
    _step_counters[session_id] = _step_counters.get(session_id, 0) + 1
    return _step_counters[session_id]


def _extract_tool_calls_anthropic(response) -> list:
    """Extract tool calls from an Anthropic response."""
    tools = []
    try:
        for block in response.content:
            if block.type == "tool_use":
                tools.append({
                    "tool": block.name,
                    "content": json.dumps(block.input)[:500] if block.input else "",
                    "id": block.id,
                })
            elif block.type == "text" and block.text:
                tools.append({
                    "tool": "reasoning",
                    "content": block.text[:500],
                })
    except Exception as e:
        logger.debug(f"Error extracting Anthropic tools: {e}")
    return tools


def _extract_tool_calls_openai(response) -> list:
    """Extract tool calls from an OpenAI response."""
    tools = []
    try:
        msg = response.choices[0].message
        if msg.tool_calls:
            for tc in msg.tool_calls:
                tools.append({
                    "tool": tc.function.name,
                    "content": tc.function.arguments[:500] if tc.function.arguments else "",
                    "id": tc.id,
                })
        if msg.content:
            tools.append({
                "tool": "reasoning",
                "content": msg.content[:500],
            })
    except Exception as e:
        logger.debug(f"Error extracting OpenAI tools: {e}")
    return tools


class _AnthropicMessagesWrapper:
    """Wraps anthropic.Anthropic().messages to auto-observe tool calls."""

    def __init__(self, original_messages, session_id: Optional[str] = None):
        self._original = original_messages
        self._session_id = session_id or f"caum-{uuid.uuid4().hex[:12]}"

    def create(self, **kwargs):
        response = self._original.create(**kwargs)

        # Extract and observe tool calls
        tool_calls = _extract_tool_calls_anthropic(response)
        for tc in tool_calls:
            caum_client.observe(
                session_id=self._session_id,
                tool=tc["tool"],
                content=tc["content"],
                step=_next_step(self._session_id),
            )

        # Estimate cost from usage
        if hasattr(response, "usage"):
            input_tokens = getattr(response.usage, "input_tokens", 0)
            output_tokens = getattr(response.usage, "output_tokens", 0)
            # Rough cost estimate (Claude Sonnet pricing)
            cost = (input_tokens * 3 + output_tokens * 15) / 1_000_000
            if cost > 0 and tool_calls:
                tool_calls[-1]["cost_usd"] = cost

        return response

    def __getattr__(self, name):
        return getattr(self._original, name)


class _AnthropicWrapper:
    """Wraps anthropic.Anthropic() client."""

    def __init__(self, original_client, session_id: Optional[str] = None):
        self._original = original_client
        self._session_id = session_id
        self.messages = _AnthropicMessagesWrapper(
            original_client.messages, session_id)

    def __getattr__(self, name):
        if name == "messages":
            return self.messages
        return getattr(self._original, name)


class _OpenAIChatCompletionsWrapper:
    """Wraps openai.OpenAI().chat.completions to auto-observe."""

    def __init__(self, original_completions, session_id: Optional[str] = None):
        self._original = original_completions
        self._session_id = session_id or f"caum-{uuid.uuid4().hex[:12]}"

    def create(self, **kwargs):
        response = self._original.create(**kwargs)

        tool_calls = _extract_tool_calls_openai(response)
        for tc in tool_calls:
            caum_client.observe(
                session_id=self._session_id,
                tool=tc["tool"],
                content=tc["content"],
                step=_next_step(self._session_id),
            )

        return response

    def __getattr__(self, name):
        return getattr(self._original, name)


class _OpenAIChatWrapper:
    def __init__(self, original_chat, session_id):
        self._original = original_chat
        self.completions = _OpenAIChatCompletionsWrapper(
            original_chat.completions, session_id)

    def __getattr__(self, name):
        if name == "completions":
            return self.completions
        return getattr(self._original, name)


class _OpenAIWrapper:
    def __init__(self, original_client, session_id):
        self._original = original_client
        self.chat = _OpenAIChatWrapper(original_client.chat, session_id)

    def __getattr__(self, name):
        if name == "chat":
            return self.chat
        return getattr(self._original, name)


def wrap_anthropic(client, session_id: Optional[str] = None):
    """Wrap an Anthropic client to auto-observe all tool calls.

    Args:
        client: An anthropic.Anthropic() instance
        session_id: Optional session ID (auto-generated if not provided)

    Returns:
        Wrapped client — use exactly like the original

    Example:
        import anthropic, caum
        caum.init("caum_live_xxx")
        client = caum.wrap_anthropic(anthropic.Anthropic())
        response = client.messages.create(...)  # CAUM observes automatically
    """
    return _AnthropicWrapper(client, session_id)


def wrap_openai(client, session_id: Optional[str] = None):
    """Wrap an OpenAI client to auto-observe all tool calls.

    Args:
        client: An openai.OpenAI() instance
        session_id: Optional session ID (auto-generated if not provided)

    Returns:
        Wrapped client — use exactly like the original

    Example:
        import openai, caum
        caum.init("caum_live_xxx")
        client = caum.wrap_openai(openai.OpenAI())
        response = client.chat.completions.create(...)  # CAUM observes automatically
    """
    return _OpenAIWrapper(client, session_id)
