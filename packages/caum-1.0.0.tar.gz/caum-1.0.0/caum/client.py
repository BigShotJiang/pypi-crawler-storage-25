"""
CAUM Client — Core API client for observing AI agents.
"""
import json
import logging
import threading
from typing import Optional

import requests

logger = logging.getLogger("caum")

_API_URL = "https://caum-observation-production.up.railway.app"
_API_KEY = None
_TIMEOUT = 10


def init(api_key: str, api_url: Optional[str] = None):
    """Initialize CAUM with your API key.

    Args:
        api_key: Your CAUM API key (starts with caum_live_)
        api_url: Optional custom API URL (for self-hosted)
    """
    global _API_KEY, _API_URL
    _API_KEY = api_key
    if api_url:
        _API_URL = api_url.rstrip("/")
    logger.info(f"CAUM initialized (endpoint: {_API_URL})")


def _post(path: str, data: dict) -> dict:
    """Make authenticated POST request to CAUM API."""
    if not _API_KEY:
        raise RuntimeError("CAUM not initialized. Call caum.init('your_api_key') first.")
    try:
        resp = requests.post(
            f"{_API_URL}{path}",
            json=data,
            headers={
                "Authorization": f"Bearer {_API_KEY}",
                "Content-Type": "application/json",
            },
            timeout=_TIMEOUT,
        )
        resp.raise_for_status()
        return resp.json()
    except requests.exceptions.RequestException as e:
        logger.warning(f"CAUM API error: {e}")
        return {"error": str(e)}


def _post_async(path: str, data: dict):
    """Non-blocking POST. Fire and forget — never slows down the agent."""
    thread = threading.Thread(target=_post, args=(path, data), daemon=True)
    thread.start()


def observe(session_id: str, tool: str, content: str = "",
            step: Optional[int] = None, agent_name: Optional[str] = None,
            task: Optional[str] = None, cost_usd: float = 0.0,
            blocking: bool = False) -> Optional[dict]:
    """Observe a single tool call from your AI agent.

    This is the core function. Call it every time your agent uses a tool.
    By default it's non-blocking (fire-and-forget) so it never slows your agent.

    Args:
        session_id: Unique ID for this agent session
        tool: Tool name (bash, edit, read, reasoning, etc.)
        content: What the tool did (optional, CAUM doesn't read semantics)
        step: Step number (auto-incremented if not provided)
        agent_name: Name of the agent (optional)
        task: Task description (optional)
        cost_usd: Cost of this step in USD (optional)
        blocking: If True, wait for response. If False (default), fire-and-forget.

    Returns:
        If blocking=True: dict with regime, failure_risk, tier, etc.
        If blocking=False: None (result sent async)
    """
    data = {
        "session_id": session_id,
        "tool": tool,
        "content": content[:500] if content else "",
        "cost_usd": cost_usd,
    }
    if step is not None:
        data["step"] = step
    if agent_name:
        data["agent_name"] = agent_name
    if task:
        data["task"] = task

    if blocking:
        return _post("/v1/step", data)
    else:
        _post_async("/v1/step", data)
        return None


def end(session_id: str, resolved: Optional[bool] = None) -> dict:
    """End a session and get the final assessment.

    Args:
        session_id: The session to finalize
        resolved: Did the agent succeed? True/False/None (auto-infer)

    Returns:
        dict with uds, tier, regime, cost, etc.
    """
    data = {}
    if resolved is not None:
        data["resolved"] = resolved
    return _post(f"/v1/session/{session_id}/end", data)


def get_status() -> dict:
    """Get your CAUM usage and calibration status."""
    if not _API_KEY:
        raise RuntimeError("CAUM not initialized.")
    try:
        resp = requests.get(
            f"{_API_URL}/v1/usage",
            headers={"Authorization": f"Bearer {_API_KEY}"},
            timeout=_TIMEOUT,
        )
        resp.raise_for_status()
        return resp.json()
    except requests.exceptions.RequestException as e:
        return {"error": str(e)}
