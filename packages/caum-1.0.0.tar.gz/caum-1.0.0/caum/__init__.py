"""
CAUM SDK — AI Agent Observability
==================================
Detect when your AI agent is wasting money. 5 lines to integrate.

Quick start:
    import caum
    caum.init("caum_live_your_api_key")
    caum.observe("my-session", tool="bash", content="pytest tests/")
    caum.observe("my-session", tool="edit", content="Fixed bug on line 42")
    result = caum.end("my-session")
    print(result["tier"])  # T1-T5

As a proxy (zero code changes):
    caum watch --api-key caum_live_xxx --provider anthropic
"""

__version__ = "1.0.0"

from .client import init, observe, end, get_status
from .proxy import CaumProxy
from .wrappers import wrap_anthropic, wrap_openai

__all__ = [
    "init", "observe", "end", "get_status",
    "CaumProxy",
    "wrap_anthropic", "wrap_openai",
]
