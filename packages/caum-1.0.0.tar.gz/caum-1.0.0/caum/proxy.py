"""
CAUM Proxy — Sits between your agent and the LLM API.
Zero code changes required.

Usage:
    from caum_sdk import CaumProxy
    proxy = CaumProxy(api_key="caum_live_xxx", provider="anthropic")
    proxy.start(port=8080)

    # Point your agent's API base URL to http://localhost:8080
    # CAUM intercepts, observes, and forwards to the real API
"""
import logging

logger = logging.getLogger("caum.proxy")


class CaumProxy:
    """HTTP proxy that intercepts LLM API calls and observes tool usage.

    This is a placeholder for the full proxy implementation.
    The proxy will:
    1. Listen on a local port
    2. Intercept POST requests to /v1/messages (Anthropic) or /v1/chat/completions (OpenAI)
    3. Forward to the real API
    4. Parse the response for tool_use blocks
    5. Send observations to CAUM API (non-blocking)
    6. Return the original response unchanged

    The agent sees no difference. CAUM observes everything.
    """

    def __init__(self, api_key: str, provider: str = "anthropic",
                 caum_api_url: str = None):
        self.api_key = api_key
        self.provider = provider
        self.caum_api_url = caum_api_url
        from . import client
        client.init(api_key, caum_api_url)

    def start(self, port: int = 8080):
        """Start the proxy server."""
        logger.info(f"CAUM proxy starting on port {port} (provider: {self.provider})")
        logger.info("Point your agent's API base URL to http://localhost:{port}")
        # TODO: implement with httpx or aiohttp reverse proxy
        raise NotImplementedError(
            "Full proxy coming soon. Use caum.wrap_anthropic() or caum.wrap_openai() instead."
        )
