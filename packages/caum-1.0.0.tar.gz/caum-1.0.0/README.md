# CAUM — AI Agent Observability

Detect when your AI agent is wasting money. Zero semantic access.

## Install

```bash
pip install caum
```

## Quick Start (5 lines)

```python
import caum

caum.init("caum_live_your_api_key")
caum.observe("session-1", tool="bash", content="pytest tests/")
caum.observe("session-1", tool="edit", content="Fixed the bug")
result = caum.end("session-1")
print(f"Tier: {result['tier']}, Cost wasted: ${result['cost']}")
```

## Zero-Code Integration (Anthropic)

```python
import anthropic
import caum

caum.init("caum_live_your_api_key")
client = caum.wrap_anthropic(anthropic.Anthropic())

# Use client exactly as before — CAUM observes automatically
response = client.messages.create(
    model="claude-sonnet-4-20250514",
    messages=[{"role": "user", "content": "Fix the auth bug"}],
    tools=[...],
)
```

## Zero-Code Integration (OpenAI)

```python
import openai
import caum

caum.init("caum_live_your_api_key")
client = caum.wrap_openai(openai.OpenAI())

# Use client exactly as before
response = client.chat.completions.create(
    model="gpt-5",
    messages=[...],
    tools=[...],
)
```

## What CAUM Detects

| Regime | Meaning | Your Agent Is... |
|--------|---------|------------------|
| EXPLORER | Healthy | Using diverse tools, making progress |
| GRIND | Degraded | Repeating similar actions |
| LOOP | Critical | Stuck in a repetitive cycle |
| REASONING_LOOP | Critical | Thinking in circles, not acting |
| STAGNATION | Critical | Same tool, same result, over and over |

## How It Works

CAUM observes the **structure** of your agent's behavior — which tools it uses, in what order, how often it repeats. It never reads your prompts, code, or data.

When your agent enters a wasteful pattern (looping, stagnating, circular reasoning), CAUM detects it and alerts you. You decide what to do. CAUM never stops your agent.

## Get Your API Key

Sign up at [caum.systems/pilot](https://caum.systems/pilot/) — 14-day free trial, 1,000 steps included.

## Links

- Website: [caum.systems](https://caum.systems)
- Dashboard: [caum.systems/dashboard](https://caum.systems/dashboard)
- Docs: [caum.systems/docs](https://caum.systems/docs)
