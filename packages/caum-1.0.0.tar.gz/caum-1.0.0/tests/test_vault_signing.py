"""
tests/test_vault_signing.py
============================
CAUM v9.2 — Vault signing tests (Ed25519 or HMAC-SHA256 fallback).
"""
import pytest, os, json, tempfile
from pathlib import Path
import sys

# Ensure tools/ is on path
TOOLS_DIR = Path(__file__).parent.parent / "tools"
sys.path.insert(0, str(TOOLS_DIR))

from sign_vault import VaultSigner


def _make_vault(tmp_path: Path, root: str = "deadbeef1234567890abcdef") -> Path:
    """Create a minimal vault directory with merkle_root.txt."""
    vault = tmp_path / "vault"
    vault.mkdir(parents=True, exist_ok=True)
    (vault / "merkle_root.txt").write_text(root + "\n")
    return vault



class TestVaultSigner:

    def test_sign_creates_all_files(self, tmp_path):
        """sign_vault() creates signature.txt, public_key.txt, signing_meta.json."""
        vault  = _make_vault(tmp_path)
        signer = VaultSigner()
        meta   = signer.sign_vault(str(vault))
        assert (vault / "signature.txt").exists()
        assert (vault / "public_key.txt").exists()
        assert (vault / "signing_meta.json").exists()

    def test_signing_meta_schema(self, tmp_path):
        """signing_meta.json has required fields."""
        vault  = _make_vault(tmp_path)
        signer = VaultSigner()
        signer.sign_vault(str(vault))
        meta = json.loads((vault / "signing_meta.json").read_text())
        for key in ("algorithm", "key_id", "merkle_root", "signature",
                    "public_key", "signed_utc"):
            assert key in meta, f"Missing field: {key}"

    def test_algorithm_is_ed25519_or_hmac(self, tmp_path):
        """Algorithm is Ed25519 (preferred) or HMAC-SHA256 (fallback)."""
        vault  = _make_vault(tmp_path)
        signer = VaultSigner()
        meta   = signer.sign_vault(str(vault))
        assert meta["algorithm"] in ("Ed25519", "HMAC-SHA256")

    def test_verify_after_sign_passes(self, tmp_path):
        """verify_vault() returns True immediately after sign_vault()."""
        vault  = _make_vault(tmp_path)
        signer = VaultSigner()
        signer.sign_vault(str(vault))
        assert signer.verify_vault(str(vault)) is True

    def test_tampered_root_fails_verification(self, tmp_path):
        """Tamper merkle_root.txt after signing → verify fails."""
        vault  = _make_vault(tmp_path)
        signer = VaultSigner()
        signer.sign_vault(str(vault))
        # Tamper root
        (vault / "merkle_root.txt").write_text("000000000000000000000000\n")
        assert signer.verify_vault(str(vault)) is False

    def test_tampered_signature_fails(self, tmp_path):
        """Tamper signature.txt → verify fails."""
        vault  = _make_vault(tmp_path)
        signer = VaultSigner()
        signer.sign_vault(str(vault))
        (vault / "signature.txt").write_text("0000" * 16 + "\n")
        assert signer.verify_vault(str(vault)) is False

    def test_signature_is_hex(self, tmp_path):
        """signature.txt contains a valid hex string."""
        vault  = _make_vault(tmp_path)
        signer = VaultSigner()
        signer.sign_vault(str(vault))
        sig = (vault / "signature.txt").read_text().strip()
        assert all(c in "0123456789abcdef" for c in sig.lower()), f"Not hex: {sig[:20]}..."

    def test_public_key_is_hex(self, tmp_path):
        """public_key.txt contains a valid hex string."""
        vault  = _make_vault(tmp_path)
        signer = VaultSigner()
        signer.sign_vault(str(vault))
        pk = (vault / "public_key.txt").read_text().strip()
        assert all(c in "0123456789abcdef" for c in pk.lower())

    def test_key_id_is_short_hex(self, tmp_path):
        signer = VaultSigner()
        assert len(signer.key_id) == 16
        assert all(c in "0123456789abcdef" for c in signer.key_id)

    def test_different_roots_different_signatures(self, tmp_path):
        """Two different vaults with same key produce different signatures."""
        signer = VaultSigner()
        vault1 = _make_vault(tmp_path / "v1", root="aaa111")
        vault2 = _make_vault(tmp_path / "v2", root="bbb222")
        signer.sign_vault(str(vault1))
        signer.sign_vault(str(vault2))
        sig1 = (vault1 / "signature.txt").read_text().strip()
        sig2 = (vault2 / "signature.txt").read_text().strip()
        assert sig1 != sig2

    def test_same_root_same_signature_ed25519(self, tmp_path):
        """Same key + same root => same signature (Ed25519 is deterministic)."""
        signer = VaultSigner()
        vault1 = _make_vault(tmp_path / "v1", root="identical_root")
        vault2 = _make_vault(tmp_path / "v2", root="identical_root")
        signer.sign_vault(str(vault1))
        signer.sign_vault(str(vault2))
        sig1 = (vault1 / "signature.txt").read_text().strip()
        sig2 = (vault2 / "signature.txt").read_text().strip()
        # Ed25519 is deterministic; HMAC too
        assert sig1 == sig2

    def test_missing_root_raises(self, tmp_path):
        """sign_vault() raises FileNotFoundError if merkle_root.txt missing."""
        vault  = tmp_path / "empty_vault"
        vault.mkdir()
        signer = VaultSigner()
        with pytest.raises(FileNotFoundError):
            signer.sign_vault(str(vault))
