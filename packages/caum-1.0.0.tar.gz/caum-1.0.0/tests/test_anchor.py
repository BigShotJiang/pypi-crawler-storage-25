"""
tests/test_anchor.py
====================
CAUM v9.0 — ANCHOR P1 layer tests (Phase 2).
"""
import pytest
from caum.anchor import (
    normalize_claim,
    p1_hard_loop_detect,
    AnchorDetector,
    anchor_consensus_2of3,
)
from caum.streaming import StreamingAuditor
from caum.embeddings import EmbeddingBridge
import numpy as np


class TestNormalizeClaim:

    def test_lowercase(self):
        assert normalize_claim("The Answer Is Paris") == "the answer is paris"

    def test_trailing_punctuation(self):
        assert normalize_claim("Done.") == "done"
        assert normalize_claim("Result!") == "result"
        assert normalize_claim("OK;") == "ok"

    def test_collapse_whitespace(self):
        assert normalize_claim("  too   many   spaces  ") == "too many spaces"

    def test_empty_string(self):
        assert normalize_claim("") == ""


class TestP1HardLoopDetect:

    def test_empty_returns_no_anchor(self):
        r = p1_hard_loop_detect([], w=5, k=3)
        assert r["anchor"] is False

    def test_diverse_no_anchor(self):
        claims = [f"unique claim {i}" for i in range(30)]
        r = p1_hard_loop_detect(claims, w=30, k=3)
        assert r["anchor"] is False

    def test_hard_loop_detected(self):
        base = ["different claim A", "different claim B"]
        stuck = ["the answer is paris"] * 5
        claims = base + stuck
        r = p1_hard_loop_detect(claims, w=30, k=3)
        assert r["anchor"] is True
        assert "paris" in r["dominant_claim"]

    def test_window_only_uses_last_w(self):
        # 50 diverse claims followed by 5 repeated — should detect
        claims = [f"claim {i}" for i in range(50)] + ["loop loop loop"] * 5
        r = p1_hard_loop_detect(claims, w=30, k=3)
        assert r["anchor"] is True

    def test_coverage_between_0_and_1(self):
        claims = ["yes"] * 10 + ["no"] * 20
        r = p1_hard_loop_detect(claims, w=30, k=3)
        assert 0.0 <= r["coverage"] <= 1.0

    def test_threshold_exact_k(self):
        claims = ["loop"] * 3 + ["other"] * 27
        r = p1_hard_loop_detect(claims, w=30, k=3)
        assert r["anchor"] is True

    def test_threshold_below_k(self):
        # 2 occurrences of 'loop' in a window of 10 — below k=3
        det = AnchorDetector(window=10, k=3)
        claims = ["loop", "loop"] + [f"other {i}" for i in range(8)]
        r = None
        for c in claims:
            r = det.push(c)
        assert r["anchor"] is False


    def test_window_smaller_than_claims(self):
        claims = ["loop"] * 100
        r = p1_hard_loop_detect(claims, w=10, k=3)
        assert r["anchor"] is True
        assert r["window_size"] == 10


class TestAnchorDetector:

    def test_no_anchor_diverse(self):
        det = AnchorDetector(window=10, k=3)
        for i in range(10):
            r = det.push(f"unique output number {i}")
        assert r["anchor"] is False

    def test_anchor_detected_loop(self):
        det = AnchorDetector(window=10, k=3)
        for _ in range(5):
            r = det.push("the capital is paris")
        assert r["anchor"] is True
        assert "paris" in r["dominant_claim"]

    def test_step_increments(self):
        det = AnchorDetector()
        for i in range(5):
            det.push(f"text {i}")
        assert det.step == 5

    def test_reset_clears_state(self):
        det = AnchorDetector(window=10, k=3)
        for _ in range(5):
            det.push("loop claim")
        det.reset()
        assert det.step == 0

    def test_below_k_no_anchor(self):
        det = AnchorDetector(window=10, k=3)
        for i in range(8):
            det.push("only twice" if i < 2 else f"different {i}")
        assert det.push("something else")["anchor"] is False


class TestAnchorConsensus2of3:

    def test_2of3_triggers_when_p0_and_p1_loop(self):
        p0 = ["x"] * 5 + ["other"] * 25
        p1 = ["y"] * 5 + ["other"] * 25
        r  = anchor_consensus_2of3(p0, p1, w=30, k=3)
        assert r["anchor_consensus"] is True
        assert "P0" in r["triggered_layers"]
        assert "P1" in r["triggered_layers"]

    def test_1of3_not_consensus(self):
        p0 = ["loop"] * 5 + ["other"] * 25
        p1 = [f"unique {i}" for i in range(30)]
        r  = anchor_consensus_2of3(p0, p1, w=30, k=3)
        assert r["anchor_consensus"] is False

    def test_all_diverse_no_consensus(self):
        p0 = [f"p0 claim {i}" for i in range(30)]
        p1 = [f"p1 claim {i}" for i in range(30)]
        r  = anchor_consensus_2of3(p0, p1, w=30, k=3)
        assert r["anchor_consensus"] is False

    def test_meta_layer_included(self):
        p0   = [f"p0 {i}" for i in range(30)]
        p1   = ["loop claim"] * 5 + [f"p1 {i}" for i in range(25)]
        meta = ["meta loop"] * 5 + [f"meta {i}" for i in range(25)]
        r    = anchor_consensus_2of3(p0, p1, meta_claims=meta, w=30, k=3)
        assert len(r["layer_results"]) == 3


class TestStreamingAuditorAnchorIntegration:

    def test_push_text_returns_anchor_flag(self):
        auditor = StreamingAuditor(min_steps=3)
        bridge  = EmbeddingBridge()   # hash fallback — no SBERT needed
        for i in range(5):
            r = auditor.push_text("agent_1", f"unique output {i}", bridge)
        assert "anchor_flag"     in r
        assert r["anchor_flag"]  is False   # diverse → no anchor

    def test_push_text_detects_anchor_loop(self):
        auditor = StreamingAuditor(min_steps=3, anchor_k=3)
        bridge  = EmbeddingBridge()
        # Push the same claim 5 times to exceed anchor_k=3
        for _ in range(5):
            r = auditor.push_text("agent_1", "the answer is always paris", bridge)
        # After 5 identical claims, anchor should fire
        assert r["anchor_flag"] is True
        assert r["anchor_claim"] is not None

    def test_push_vector_has_anchor_false(self):
        """push() (vector only) always returns anchor_flag=False."""
        auditor = StreamingAuditor(min_steps=3)
        for i in range(20):
            r = auditor.push("agent_1", np.random.randn(6))
        assert r.get("anchor_flag") is False
