"""
tests/test_adaptive_baseline.py
================================
CAUM v9.2 — Adaptive Baseline Dual Policy tests.
"""
import pytest
import numpy as np
from caum.streaming import StreamingAuditor
from caum.config import (
    MIN_BASELINE_STEPS, MIN_BASELINE_STEPS_SHORT, BASELINE_FRACTION
)

RNG = np.random.default_rng(2026)


class TestAdaptiveBaseline:

    def test_long_agent_uses_full_baseline(self):
        """Without expected_steps, min_steps == MIN_BASELINE_STEPS."""
        a = StreamingAuditor()
        assert a.min_steps == MIN_BASELINE_STEPS

    def test_short_agent_uses_adaptive_min(self):
        """expected_steps=50 -> effective_min = max(30, int(50*0.3)) = 15 -> max(30,15) = 30."""
        a = StreamingAuditor(expected_steps=50)
        expected = max(MIN_BASELINE_STEPS_SHORT, int(50 * BASELINE_FRACTION))
        assert a.min_steps == expected

    def test_short_agent_expected_100(self):
        """expected_steps=100 -> effective_min = max(30, int(100*0.3)) = 30."""
        a = StreamingAuditor(expected_steps=100)
        assert a.min_steps == 30

    def test_short_agent_expected_10(self):
        """expected_steps=10 -> int(10*0.3)=3 -> max(30,3)=30 (floor)."""
        a = StreamingAuditor(expected_steps=10)
        assert a.min_steps == MIN_BASELINE_STEPS_SHORT

    def test_short_agent_warms_up_faster(self):
        """Short-agent auditor starts auditing within 30 steps."""
        a = StreamingAuditor(expected_steps=80)
        # Feed 35 steps — should exit WARMING_UP sooner than default 200
        result = None
        for _ in range(35):
            result = a.push("a", RNG.normal(0, 0.3, 6))
        assert result is not None
        # After 35 steps on an agent expecting 80, must be past warming_up
        assert result["regime"] != "WARMING_UP", \
            f"Still WARMING_UP at step 35 with expected_steps=80 (min_steps={a.min_steps})"

    def test_default_agent_still_warming_at_step_50(self):
        """Default auditor (no expected_steps) is still warming at step 50."""
        a = StreamingAuditor()
        result = None
        for _ in range(50):
            result = a.push("a", RNG.normal(0, 0.3, 6))
        assert result["regime"] == "WARMING_UP"

    def test_explicit_min_steps_overrides_all(self):
        """Explicit min_steps=5 always wins regardless of expected_steps."""
        a = StreamingAuditor(min_steps=5, expected_steps=1000)
        # min(adaptive_from_1000=200, explicit=5) -> 5
        assert a.min_steps == 5

    def test_expected_steps_stored(self):
        """expected_steps is stored for reference."""
        a = StreamingAuditor(expected_steps=75)
        assert a.expected_steps == 75

    def test_no_expected_steps_is_none(self):
        a = StreamingAuditor()
        assert a.expected_steps is None

    def test_adaptive_floor_is_min_baseline_short(self):
        """Adaptive floor MAX(MIN_BASELINE_STEPS_SHORT, ...) is always respected."""
        for exp in [1, 5, 10, 20]:
            a = StreamingAuditor(expected_steps=exp)
            assert a.min_steps >= MIN_BASELINE_STEPS_SHORT, \
                f"expected_steps={exp}: min_steps={a.min_steps} below floor"

    def test_adaptive_ceiling_is_min_baseline_steps(self):
        """For standard use, effective_min never exceeds MIN_BASELINE_STEPS."""
        # expected_steps=1000 → adaptive = max(30, int(1000*0.3)) = 300
        # but min(300, default_min_steps=200) = 200
        a = StreamingAuditor(expected_steps=1000)
        assert a.min_steps == MIN_BASELINE_STEPS
