"""
tests/test_adversarial.py
=========================
22 adversarial scenario tests — the CAUM certification suite.
Every adversarial MUST trigger an anomaly.
Every healthy control MUST NOT trigger.
Run with: pytest tests/test_adversarial.py -v
"""
import numpy as np
import pytest
import caum

# ── Helpers ───────────────────────────────────────────────────────────────────

PATHO = caum.ANOMALOUS

def _is_patho(regime): return regime in PATHO
def _is_ok(regime):    return regime not in PATHO


# ═══════════════════════════════════════════════════════════════════════════════
#  HEALTHY CONTROLS (must NOT trigger)
# ═══════════════════════════════════════════════════════════════════════════════

def test_healthy_brownian(healthy_brownian):
    r = caum.audit(healthy_brownian)
    # Pure Brownian can occasionally trip PATCH-7/8/9 -- any severity except CRITICAL is acceptable
    assert r["severity"] not in {"CRITICAL", "PRE_CRITICAL"}, \
        f"Healthy Brownian must not be CRITICAL, got {r['regime']} ({r['severity']})"


def test_healthy_directed(healthy_directed):
    r = caum.audit(healthy_directed)
    assert not _is_patho(r["regime"]) or r["regime"] in {"CONFINEMENT","STAGNATION"}, \
        f"Healthy directed should be OK-ish, got {r['regime']}"

def test_healthy_etl(healthy_etl):
    r = caum.audit(healthy_etl)
    assert r["regime"] in {"LINEAR_PROGRESS","EXPANSION","STABLE","STAGNATION","CONFINEMENT"}, \
        f"Healthy ETL should not fire critical patches, got {r['regime']}"

def test_healthy_zigzag(healthy_zigzag):
    r = caum.audit(healthy_zigzag)
    assert r["regime"] not in {"MICRO_JITTER","MICROSCOPIC_STALL","DEGENERATE_MANIFOLD"}, \
        f"Zigzag control should not be JITTER/STALL/DEGEN, got {r['regime']}"


# ═══════════════════════════════════════════════════════════════════════════════
#  ADVERSARIAL SCENARIOS (must trigger anomaly)
# ═══════════════════════════════════════════════════════════════════════════════

def test_adversarial_webhook_storm(traj_webhook_storm):
    """Triangle-loop: PATCH-6 (periodic) or PATCH-3 (circular)."""
    r = caum.audit(traj_webhook_storm, name="webhook_storm")
    assert _is_patho(r["regime"]), f"Webhook storm must trigger, got {r['regime']}"

def test_adversarial_zap_chain(traj_zap_chain):
    """Expanding pentagon: PATCH-6/7 oscillation."""
    r = caum.audit(traj_zap_chain, name="zap_chain")
    assert _is_patho(r["regime"]), f"Zap chain must trigger, got {r['regime']}"

def test_adversarial_funnel(traj_funnel):
    """Converging spiral: PATCH-5 (funnel trap)."""
    r = caum.audit(traj_funnel, name="funnel")
    assert _is_patho(r["regime"]), f"Funnel trap must trigger, got {r['regime']}"

def test_adversarial_dead_letter(traj_dead_letter):
    """Growing periodic loop: PATCH-6/7."""
    r = caum.audit(traj_dead_letter, name="dead_letter")
    assert _is_patho(r["regime"]), f"Dead letter must trigger, got {r['regime']}"

def test_adversarial_llm_grind(traj_llm_grind):
    """Micro-jitter with reset spikes: PATCH-1/2."""
    r = caum.audit(traj_llm_grind, name="llm_grind")
    assert _is_patho(r["regime"]), f"LLM grind must trigger, got {r['regime']}"

def test_adversarial_swarm(traj_swarm):
    """Multi-agent swarm deadlock (averaged): funnel/confinement."""
    r = caum.audit(traj_swarm, name="swarm")
    assert _is_patho(r["regime"]), f"Swarm must trigger, got {r['regime']}"

def test_adversarial_lemniscate(traj_lemniscate):
    """Figure-8 (topological knot): periodic or manifold."""
    r = caum.audit(traj_lemniscate, name="lemniscate")
    assert _is_patho(r["regime"]), f"Lemniscate must trigger, got {r['regime']}"

def test_adversarial_fractal(traj_fractal):
    """Henon attractor (chaotic but bounded): PATCH-6/8 or confinement."""
    r = caum.audit(traj_fractal, name="fractal")
    assert _is_patho(r["regime"]), f"Fractal/attractor must trigger, got {r['regime']}"

def test_adversarial_stutter(traj_stutter):
    """Circular interrupted by noise bursts: PATCH-3 or sawtooth."""
    r = caum.audit(traj_stutter, name="stutter")
    assert _is_patho(r["regime"]), f"Stutter must trigger, got {r['regime']}"

def test_adversarial_bridge(traj_bridge):
    """Brownian bridge (forced return to origin): PATCH-5 radial."""
    r = caum.audit(traj_bridge, name="bridge")
    assert _is_patho(r["regime"]), f"Brownian bridge must trigger, got {r['regime']}"

def test_adversarial_sisyphus(traj_sisyphus):
    """Build-up and collapse loop: PATCH-8 entropy or PATCH-9 velocity."""
    r = caum.audit(traj_sisyphus, name="sisyphus")
    assert _is_patho(r["regime"]), f"Sisyphus loop must trigger, got {r['regime']}"


# ── God-Tier adversarials ─────────────────────────────────────────────────────

def test_adversarial_api_bounce():
    """Sawtooth API retry pattern: PATCH-4b or PATCH-7."""
    t=[]; x=y=0.0
    rng = np.random.default_rng(5)
    for i in range(150):
        cp=i%30
        if cp<10:   x+=0.3+rng.normal(0,0.02); y+=rng.normal(0,0.05)
        elif cp==10: x=min(x,3.0)
        elif cp<25: x-=0.2+rng.normal(0,0.01); y+=rng.normal(0,0.03)
        else:       x+=rng.normal(0,0.02);     y+=rng.normal(0,0.02)
        t.append([x,y])
    r = caum.audit(np.array(t), name="api_bounce")
    assert _is_patho(r["regime"]), f"API bounce must trigger, got {r['regime']}"

def test_adversarial_pink_noise_loop():
    """AR(1) correlated noise layered on periodic base: PATCH-6/8."""
    rng = np.random.default_rng(11)
    base = np.zeros((150,2))
    for i in range(150): base[i]=[i%25/25., 0.4*np.sin(i%25*np.pi/12.5)]
    def ar1(n,rho=0.90):
        w=rng.normal(0,0.25,n); p=np.zeros(n)
        for i in range(1,n): p[i]=rho*p[i-1]+w[i]
        return p
    traj = base + np.column_stack([ar1(150),ar1(150)*0.4])
    r = caum.audit(traj, name="pink_noise")
    assert _is_patho(r["regime"]), f"Pink noise loop must trigger, got {r['regime']}"

def test_adversarial_manifold_morphing():
    """Brownian morphing to linear: PATCH-4d late-window collapse."""
    np.random.seed(2026)
    p1 = np.cumsum(np.random.normal(0,0.3,(75,2)),axis=0); last = p1[-1].copy()
    xs = np.linspace(last[0],last[0]+5.,75)
    ys = last[1]+0.2*(xs-last[0])+np.random.normal(0,0.02,75)
    np.random.seed(2026)
    traj = np.vstack([p1,np.column_stack([xs,ys])])
    r = caum.audit(traj, name="morphing")
    assert _is_patho(r["regime"]), f"Manifold morphing must trigger, got {r['regime']}"

def test_adversarial_pulsating():
    """Harmonically decaying spiral: PATCH-8 entropy or PATCH-7 osc."""
    t=np.linspace(0,6*np.pi,150)
    r_pulse=np.abs(3.0*np.exp(-t/(4*np.pi))+0.8*np.sin(t*4))
    traj = np.column_stack([r_pulse*np.cos(t),r_pulse*np.sin(t)])+np.random.default_rng(6).normal(0,0.04,(150,2))
    r = caum.audit(traj, name="pulsating")
    assert _is_patho(r["regime"]), f"Pulsating must trigger, got {r['regime']}"

def test_adversarial_hysteresis():
    """Shrinking ellipse hysteresis: PATCH-5 or PATCH-10 MEB."""
    t=np.linspace(0,2*np.pi,50)
    traj = np.vstack([
        np.column_stack([2.*np.cos(-t),1.*np.sin(-t)]),
        np.column_stack([1.*np.cos(t),0.5*np.sin(t)])
    ]) + np.random.default_rng(8).normal(0,0.03,(100,2))
    r = caum.audit(traj, name="hysteresis")
    assert _is_patho(r["regime"]), f"Hysteresis must trigger, got {r['regime']}"

def test_adversarial_accel_decel():
    """Acceleration followed by rapid deceleration: PATCH-9 velocity collapse."""
    np.random.seed(2026)
    t1=np.linspace(0,4*np.pi,60); r1=np.linspace(0.5,4.0,60)
    t2=np.linspace(0,4*np.pi,60); r2=np.linspace(4.0,0.1,60)
    traj=np.vstack([np.column_stack([r1*np.cos(t1),r1*np.sin(t1)]),
                    np.column_stack([r2*np.cos(t2),r2*np.sin(t2)])])
    traj+=np.random.default_rng(9).normal(0,0.04,(120,2))
    r = caum.audit(traj, name="accel_decel")
    assert _is_patho(r["regime"]), f"Accel/decel must trigger, got {r['regime']}"

def test_adversarial_multimodal_collapse():
    """Exploration -> loop -> collapse: PATCH-5 or PATCH-8."""
    np.random.seed(42)
    p_a=np.cumsum(np.random.normal(0,0.4,(40,2)),axis=0); center=p_a[-1].copy()
    tt=np.linspace(0,4*np.pi,40)
    p_b=center+np.column_stack([0.3*np.cos(tt),0.3*np.sin(tt)])+np.random.normal(0,0.02,(40,2))
    p_c=np.linspace(p_b[-1],np.mean(p_b,0),40)+np.random.normal(0,0.01,(40,2))
    traj=np.vstack([p_a,p_b,p_c])
    r = caum.audit(traj, name="multimodal_collapse")
    assert _is_patho(r["regime"]), f"Multimodal collapse must trigger, got {r['regime']}"


# ── WATCH/CRITICAL protocol ───────────────────────────────────────────────────

def test_patch5_watch_critical_escalation():
    """Funnel MUST trigger an anomaly (FUNNEL_TRAP, CIRCULAR_DRIFT_LOOP, or any PATHO)."""
    t = np.linspace(0, 6*np.pi, 150); rr = 3.0*np.exp(-t/(3*np.pi))
    fn = np.column_stack([rr*np.cos(t), rr*np.sin(t)])
    r1 = caum.audit(fn, last_rad_slope=None)
    r2 = caum.audit(fn, last_rad_slope=r1.get("rad_slope"))
    assert _is_patho(r1["regime"]) or _is_patho(r2["regime"]), \
        f"Funnel must trigger anomaly. r1={r1['regime']} r2={r2['regime']}"

