"""
tests/test_adaptive.py
======================
CAUM v9.0 — AdaptiveStreamingAuditor tests (Phase 1).
"""
import pytest
import numpy as np
from caum.adaptive import AdaptiveStreamingAuditor

np.random.seed(2026)


class TestAdaptiveStreamingAuditor:

    def _make_auditor(self, windows=(16, 32, 64), persist=3, min_steps=3):
        return AdaptiveStreamingAuditor(windows=windows, persist=persist,
                                        min_steps=min_steps)

    def test_instantiation(self):
        a = self._make_auditor()
        assert a.windows == (16, 32, 64)
        assert a.persist == 3
        assert len(a._engines) == 3

    def test_push_returns_correct_schema(self):
        a    = self._make_auditor()
        vec  = np.random.randn(6)
        res  = a.push("agent_1", vec)
        assert "per_window"      in res
        assert "vote_regime"     in res
        assert "vote_confidence" in res
        assert "any_anomaly"     in res
        assert set(res["per_window"].keys()) == {16, 32, 64}

    def test_undecided_during_warmup(self):
        a = self._make_auditor(min_steps=10)
        for _ in range(5):
            r = a.push("agent_1", np.random.randn(6))
        # During per-window warmup, engines return WARMING_UP (not enough steps yet).
        # UNDECIDED fires only after warmup when no window has stable persistence.
        assert r["vote_regime"] in ("UNDECIDED", "WARMING_UP")


    def test_vote_converges_on_stable_trajectory(self):
        """After enough steps of healthy Brownian motion, vote stabilizes."""
        a    = self._make_auditor(windows=(16, 32), persist=3, min_steps=3)
        traj = np.cumsum(np.random.randn(200, 6), axis=0)
        result = None
        for vec in traj:
            result = a.push("agent_1", vec)
        assert result["vote_regime"] != "UNDECIDED"
        assert 0.0 < result["vote_confidence"] <= 1.0

    def test_any_anomaly_flag_propagates(self):
        """If any window flags anomaly, any_anomaly=True."""
        a = self._make_auditor(windows=(16,), persist=3, min_steps=3)
        # Funnel trap: converging trajectory
        center = np.zeros(6)
        result = None
        for i in range(80):
            scale = max(0.01, 1.0 - i / 80.0)
            vec   = center + np.random.randn(6) * scale
            result = a.push("agent_1", vec)
        # any_anomaly propagates from per_window results
        anomalies = [r.get("is_anomaly", False)
                     for r in result["per_window"].values()]
        assert result["any_anomaly"] == any(anomalies)

    def test_multi_agent_isolation(self):
        """Two agents get isolated per-window state."""
        a = self._make_auditor(min_steps=3)
        traj_a = np.cumsum(np.random.randn(50, 6), axis=0)
        traj_b = np.zeros((50, 6))        # stuck — different behavior
        for i in range(50):
            a.push("agent_a", traj_a[i])
            a.push("agent_b", traj_b[i])
        assert "agent_a" in a.active_agents()
        assert "agent_b" in a.active_agents()

    def test_reset_clears_state(self):
        a = self._make_auditor(min_steps=3)
        for _ in range(20):
            a.push("agent_1", np.random.randn(6))
        a.reset("agent_1")
        assert "agent_1" not in a.active_agents()

    def test_reset_all(self):
        a = self._make_auditor(min_steps=3)
        for _ in range(5):
            a.push("a", np.random.randn(6))
            a.push("b", np.random.randn(6))
        a.reset_all()
        assert a.active_agents() == []

    def test_window_summary(self):
        a = self._make_auditor(min_steps=3)
        for _ in range(5):
            a.push("agent_1", np.random.randn(6))
        s = a.window_summary("agent_1")
        assert set(s.keys()) == {16, 32, 64}

    def test_confidence_0_to_1(self):
        a = self._make_auditor(min_steps=3)
        traj = np.cumsum(np.random.randn(200, 6), axis=0)
        for vec in traj:
            r = a.push("a", vec)
        assert 0.0 <= r["vote_confidence"] <= 1.0

    def test_single_window_mode(self):
        """Single-window mode: confidence equals 1.0 when vote fires."""
        a = AdaptiveStreamingAuditor(windows=(32,), persist=3, min_steps=3)
        traj = np.cumsum(np.random.randn(200, 6), axis=0)
        for vec in traj:
            r = a.push("a", vec)
        if r["vote_regime"] != "UNDECIDED":
            assert r["vote_confidence"] == pytest.approx(1.0, abs=0.01)
