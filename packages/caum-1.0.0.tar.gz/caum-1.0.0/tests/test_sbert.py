"""
tests/test_sbert.py — SBERT 384D embedding tests.
Requires: pip install caum[sbert]
Skip gracefully if sentence-transformers not installed.
"""
import pytest
import numpy as np

sbert = pytest.importorskip("sentence_transformers", reason="sentence-transformers not installed")
import caum
from caum import EmbeddingBridge


@pytest.fixture(scope="module")
def bridge():
    return EmbeddingBridge("all-MiniLM-L6-v2")


@pytest.mark.sbert
def test_sbert_bridge_mode(bridge):
    """Bridge must be in SBERT mode when sentence-transformers is installed."""
    assert "SBERT" in bridge.mode
    assert bridge.dim == 384


@pytest.mark.sbert
def test_sbert_unit_sphere(bridge):
    """SBERT embeddings must lie on the unit hypersphere."""
    from caum.metrics import is_unit_sphere
    texts = ["test sentence %d" % i for i in range(20)]
    traj = bridge.encode_sequence(texts)
    assert is_unit_sphere(traj), "SBERT embeddings must be L2-normalized"


@pytest.mark.sbert
def test_sbert_diverse_exploration_is_stable(bridge):
    """
    H1: Diverse multi-topic exploration must NOT be flagged as anomalous.
    Regime must be STABLE (spherical taxonomy branch).
    """
    topics = ["databases","APIs","auth","caching","queues","models","pipelines","testing"]
    texts = ["Step %d exploring %s in context %d" % (i, topics[i%8], i//8+1)
             for i in range(80)]
    traj = bridge.encode_sequence(texts)
    r = caum.audit(traj, name="H1_diverse")
    assert r["regime"] == "STABLE", \
        f"H1 diverse SBERT must be STABLE, got {r['regime']} (bb={r['bbox']:.3f} jr={r['jr']:.3f})"
    assert not r["is_anomaly"]


@pytest.mark.sbert
def test_sbert_repetitive_stall_is_caught(bridge):
    """H2: Repetitive identical text must fire MICRO_JITTER (PATCH-1)."""
    texts = ["Retry the operation with exactly same parameters"] * 80
    traj = bridge.encode_sequence(texts)
    r = caum.audit(traj, name="H2_stall")
    assert r["is_anomaly"], \
        f"H2 stall must be anomalous, got {r['regime']}"
    assert r["regime"] == "MICRO_JITTER", \
        f"H2 stall must be MICRO_JITTER, got {r['regime']}"


@pytest.mark.sbert
def test_sbert_semantic_funnel_is_caught(bridge):
    """H3: Semantically converging text must fire PATCH-1 or PATCH-2."""
    texts = [("focused " * min(i//10, 6) + "final answer to the question") for i in range(80)]
    traj = bridge.encode_sequence(texts)
    r = caum.audit(traj, name="H3_funnel")
    assert r["is_anomaly"], \
        f"H3 semantic funnel must be anomalous, got {r['regime']}"


@pytest.mark.sbert
def test_streaming_auditor_with_sbert(bridge):
    """StreamingAuditor.push_text() must process SBERT texts correctly."""
    auditor = caum.StreamingAuditor(min_steps=10)
    topics = ["databases","APIs","auth","caching","queues","models"]
    for i in range(30):
        text = "Exploring %s concept %d" % (topics[i%6], i)
        result = auditor.push_text("llm_agent", text, bridge)
    assert result["regime"] != "WARMING_UP"
    assert "severity" in result


@pytest.mark.sbert
def test_sbert_spherical_jr_is_high_for_diverse(bridge):
    """
    Diverse SBERT texts must produce jr > p1_jr threshold (not stalled).
    Validates that spherical_mean_step metric correctly differentiates
    exploration from stall.
    """
    topics = ["databases","APIs","auth","caching","queues","models","pipelines","testing"]
    texts = ["Step %d exploring %s" % (i, topics[i%8]) for i in range(80)]
    traj = bridge.encode_sequence(texts)
    r = caum.audit(traj, name="jr_check")
    assert r["jr"] > caum.CFG_DEFAULT["p1_jr"], \
        f"Diverse SBERT jr={r['jr']:.5f} must exceed p1_jr={caum.CFG_DEFAULT['p1_jr']}"
