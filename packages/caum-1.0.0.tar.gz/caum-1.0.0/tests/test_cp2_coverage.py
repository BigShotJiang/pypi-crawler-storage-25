"""
tests/test_cp2_coverage.py
===========================
CAUM v9.1 — CP2 v2 Coverage + Confidence tests (Phase 3).
"""
import pytest, time
import numpy as np
from caum.integrations.crewai import TimeBucketManager


class TestTimeBucketManagerV2:

    def _tm(self, bucket_ms=1000):
        return TimeBucketManager(bucket_ms=bucket_ms, history_buckets=5)

    def test_bucket_diagnose_schema(self):
        tm  = self._tm()
        ts  = time.time()
        bid = tm.add("a", np.random.randn(4), timestamp=ts)
        tm.add("b", np.random.randn(4), timestamp=ts)
        d   = tm.bucket_diagnose(bid)
        required = {"bucket_id","agents_present","agents_expected","n_present","n_expected",
                    "bucket_coverage","bucket_correlation_mean","bucket_correlation_std",
                    "bucket_confidence","swarm_confidence"}
        assert required.issubset(d.keys()), f"Missing keys: {required - d.keys()}"

    def test_full_coverage_is_high(self):
        """All expected agents present → HIGH confidence."""
        tm = self._tm()
        ts = time.time()
        for agent in ["a","b","c"]:
            tm.add(agent, np.random.randn(4), timestamp=ts)
        bid = tm.latest_bucket()
        d   = tm.bucket_diagnose(bid)
        assert d["bucket_coverage"] == pytest.approx(1.0)
        assert d["swarm_confidence"] == "HIGH"

    def test_partial_coverage_moderate(self):
        """2 of 3 agents present → MODERATE (0.67 >= 0.6)."""
        tm = self._tm()
        ts = time.time()
        # Prime the history with all 3 agents
        for agent in ["a","b","c"]:
            tm.add(agent, np.random.randn(4), timestamp=ts - 2.0)
        # New bucket: only 2 agents
        ts2 = ts + 1.5
        for agent in ["a","b"]:
            tm.add(agent, np.random.randn(4), timestamp=ts2)
        bid = tm.latest_bucket()
        d   = tm.bucket_diagnose(bid)
        assert 0.6 <= d["bucket_coverage"] <= 1.0
        assert d["swarm_confidence"] in ("MODERATE", "HIGH")

    def test_single_agent_is_low_evidence(self):
        """Only 1 of expected agents → LOW_EVIDENCE."""
        tm = self._tm()
        ts = time.time()
        # Prime: 4 agents expected
        for agent in ["a","b","c","d"]:
            tm.add(agent, np.random.randn(4), timestamp=ts - 2.0)
        # New bucket: only agent_a (1/4 = 25%)
        tm.add("a", np.random.randn(4), timestamp=ts + 1.5)
        bid = tm.latest_bucket()
        d   = tm.bucket_diagnose(bid)
        assert d["bucket_coverage"] < 0.6
        assert d["swarm_confidence"] == "LOW_EVIDENCE"

    def test_no_false_echo_single_agent(self):
        """P8: Single agent bucket → correlation is None."""
        tm  = self._tm()
        ts  = time.time()
        bid = tm.add("only_one", np.random.randn(6), timestamp=ts)
        assert tm.cross_bucket_correlation(bid) is None
        d   = tm.bucket_diagnose(bid)
        assert d["bucket_correlation_mean"] is None

    def test_two_agents_correlation_returned(self):
        """Two agents → correlation mean in [-1, 1]."""
        tm  = self._tm()
        ts  = time.time()
        bid1 = tm.add("a", np.array([1.0, 0.0, 0.0, 0.0]), timestamp=ts)
        bid2 = tm.add("b", np.array([0.0, 1.0, 0.0, 0.0]), timestamp=ts)
        assert bid1 == bid2
        d = tm.bucket_diagnose(bid1)
        assert d["bucket_correlation_mean"] is not None
        assert -1.0 <= d["bucket_correlation_mean"] <= 1.0

    def test_parallel_agents_high_correlation(self):
        """Agents with very similar vectors → high cosine similarity."""
        tm  = self._tm()
        ts  = time.time()
        v   = np.array([1.0, 0.5, 0.2, 0.1])
        for i, ag in enumerate(["a","b","c"]):
            noise = v + np.random.randn(4) * 0.001
            tm.add(ag, noise, timestamp=ts)
        bid = tm.latest_bucket()
        d   = tm.bucket_diagnose(bid)
        assert d["bucket_correlation_mean"] > 0.9, \
            f"Expected high corr, got {d['bucket_correlation_mean']}"

    def test_opposing_agents_low_correlation(self):
        """Agents with opposite vectors → correlation near -1."""
        tm  = self._tm()
        ts  = time.time()
        tm.add("a", np.array([ 1.0,  0.0]), timestamp=ts)
        tm.add("b", np.array([-1.0,  0.0]), timestamp=ts)
        bid = tm.latest_bucket()
        d   = tm.bucket_diagnose(bid)
        assert d["bucket_correlation_mean"] < -0.5, \
            f"Expected negative corr, got {d['bucket_correlation_mean']}"

    def test_agents_expected_tracks_history(self):
        """agents_expected includes all agent IDs from last N buckets."""
        tm = self._tm()
        ts = time.time()
        tm.add("a", np.random.randn(4), timestamp=ts)
        tm.add("b", np.random.randn(4), timestamp=ts + 1.5)
        tm.add("c", np.random.randn(4), timestamp=ts + 3.0)
        expected = tm.agents_expected()
        assert {"a","b","c"}.issubset(expected)

    def test_prune_bounds_memory(self):
        """prune() removes old buckets keeping only last N."""
        tm = self._tm()
        ts = time.time()
        for i in range(20):
            tm.add("a", np.random.randn(4), timestamp=ts + i * 1.5)
        assert len(tm._buckets) == 20
        tm.prune(keep_last=5)
        assert len(tm._buckets) == 5

    def test_bucket_confidence_is_zero_for_single_agent(self):
        """Single agent: coverage low, confidence should be low."""
        tm = self._tm()
        ts = time.time()
        for ag in ["a","b","c","d"]:
            tm.add(ag, np.random.randn(4), timestamp=ts - 2.0)
        tm.add("a", np.random.randn(4), timestamp=ts + 1.5)
        bid = tm.latest_bucket()
        d   = tm.bucket_diagnose(bid)
        # Coverage = 1/4 = 0.25, confidence must be low
        assert d["bucket_confidence"] < 0.5
