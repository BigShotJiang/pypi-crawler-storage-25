"""
tests/test_integrations.py
===========================
Integration tests for caum.integrations (LangChain, CrewAI, Telemetry).
Uses mock objects — no real LangChain or CrewAI install required.
"""
import os
import json
import tempfile
import numpy as np
import pytest

import caum
from caum.integrations.langchain  import CAUMCallbackHandler
from caum.integrations.crewai     import CAUMCrewObserver
from caum.integrations.telemetry  import CAUMTelemetryLogger


# ── Mock objects ──────────────────────────────────────────────────────────────

class MockAgentAction:
    def __init__(self, log="Thought: I need to search. Action: search"):
        self.log  = log
        self.tool = "search"
        self.tool_input = "query"

class MockAgentFinish:
    def __init__(self, output="Final answer: here is the result"):
        self.return_values = {"output": output}

class MockTaskOutput:
    def __init__(self, agent="researcher", raw="Analysis complete. Result: X"):
        self.agent = agent
        self.raw   = raw


# ═══════════════════════════════════════════════════════════════════════════════
#  LANGCHAIN CALLBACK HANDLER
# ═══════════════════════════════════════════════════════════════════════════════

class TestCAUMCallbackHandler:

    def test_import_without_langchain(self):
        """Handler must import without langchain installed."""
        assert CAUMCallbackHandler is not None

    def test_instantiation(self):
        handler = CAUMCallbackHandler(min_steps=5)
        assert handler is not None

    def test_on_agent_action_feeds_step(self):
        """on_agent_action must feed a vector into the auditor."""
        handler = CAUMCallbackHandler(min_steps=5)
        action = MockAgentAction("Thought: exploring option A")
        handler.on_agent_action(action, run_id="run1")
        state = handler._auditor.state(handler.agent_id)
        assert state is not None
        assert state.step == 1

    def test_on_tool_end_accumulates(self):
        handler = CAUMCallbackHandler(min_steps=5)
        for i in range(10):
            handler.on_tool_end(f"tool result number {i}", run_id="run1")
        state = handler._auditor.state(handler.agent_id)
        assert state.step == 10

    def test_alert_fn_called_on_anomaly(self):
        """alert_fn must be called when agent enters anomalous regime."""
        alerts = []
        handler = CAUMCallbackHandler(
            min_steps=0, alert_fn=lambda r: alerts.append(r["regime"])
        )
        # Feed a repetitive stall-like pattern (same vector = MICRO_JITTER)
        vec = np.zeros(6)
        for _ in range(25):
            handler._feed(handler.agent_id, vec)
        assert len(alerts) > 0, "alert_fn must fire on anomaly"

    def test_on_agent_finish_resets_state(self):
        handler = CAUMCallbackHandler(min_steps=5)
        for _ in range(8):
            handler.on_agent_action(MockAgentAction(), run_id="run1")
        assert handler._auditor.state(handler.agent_id) is not None
        handler.on_agent_finish(MockAgentFinish(), run_id="run1")
        # State reset after finish
        assert handler._auditor.state(handler.agent_id) is None

    def test_error_feeds_as_step(self):
        handler = CAUMCallbackHandler(min_steps=5)
        handler.on_chain_error(ValueError("timeout"), run_id="run1")
        state = handler._auditor.state(handler.agent_id)
        assert state is not None and state.step == 1

    def test_last_result_returns_dict(self):
        handler = CAUMCallbackHandler(min_steps=0)
        for i in range(5):
            handler.on_agent_action(MockAgentAction(f"step {i}"), run_id="r1")
        r = handler.last_result("r1")
        assert r is not None
        assert "regime" in r

    def test_telemetry_writes_jsonl(self):
        with tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False, mode="w") as f:
            path = f.name
        try:
            handler = CAUMCallbackHandler(min_steps=0, telemetry_path=path)
            for i in range(20):
                handler.on_tool_end(f"output {i}", run_id="r1")
            # Read back JSONL
            lines = [l for l in open(path).readlines() if l.strip()]
            assert len(lines) > 0
            record = json.loads(lines[0])
            assert "regime" in record
            assert "agent_id" in record
        finally:
            os.unlink(path)


# ═══════════════════════════════════════════════════════════════════════════════
#  CREWAI OBSERVER
# ═══════════════════════════════════════════════════════════════════════════════

class TestCAUMCrewObserver:

    def test_import_without_crewai(self):
        assert CAUMCrewObserver is not None

    def test_on_task_end_feeds_agent(self):
        observer = CAUMCrewObserver(min_steps=5)
        task_out = MockTaskOutput(agent="researcher", raw="Research done.")
        observer.on_task_end(task_out)
        state = observer._auditor.state("researcher")
        assert state is not None and state.step == 1

    def test_multi_agent_isolation(self):
        """Different agents (roles) must have separate state."""
        observer = CAUMCrewObserver(min_steps=5)
        for i in range(8):
            observer.on_task_end(MockTaskOutput("researcher", f"step {i}"))
            observer.on_task_end(MockTaskOutput("writer", f"step {i}"))
        s_r = observer._auditor.state("researcher")
        s_w = observer._auditor.state("writer")
        assert s_r is not s_w
        assert s_r.step == 8 and s_w.step == 8

    def test_swarm_deadlock_detected(self):
        """When >50% agents are in PATHO, swarm_check must return SWARM_DEADLOCK."""
        alerts = []
        observer = CAUMCrewObserver(
            min_steps=0, alert_fn=lambda r: alerts.append(r),
            swarm_deadlock_threshold=0.5
        )
        # Feed zero vectors (MICRO_JITTER) to 3 agents
        zero = np.zeros((25, 6))
        for agent in ["a1", "a2", "a3"]:
            for vec in zero: observer._feed(agent, vec)
        deadlock = observer._swarm_check()
        # All 3 agents should be anomalous -> deadlock
        assert deadlock is not None, "Swarm deadlock must be detected"
        assert deadlock["regime"] == "SWARM_DEADLOCK"

    def test_swarm_status_returns_dict(self):
        observer = CAUMCrewObserver(min_steps=5)
        observer.on_task_end(MockTaskOutput("a1", "task done"))
        s = observer.swarm_status()
        assert "active_agents" in s
        assert "deadlock_risk" in s
        assert isinstance(s["deadlock_risk"], bool)

    def test_on_step_hook(self):
        """on_step must accept any object and not crash."""
        observer = CAUMCrewObserver(min_steps=5)
        class MockStep:
            agent = "planner"
            log   = "Planning next action..."
        observer.on_step(MockStep())
        state = observer._auditor.state("planner")
        assert state is not None

    def test_repr_shows_status(self):
        observer = CAUMCrewObserver()
        r = repr(observer)
        assert "CAUMCrewObserver" in r


# ═══════════════════════════════════════════════════════════════════════════════
#  TELEMETRY LOGGER
# ═══════════════════════════════════════════════════════════════════════════════

class TestCAUMTelemetryLogger:

    def test_log_returns_result(self):
        with tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False) as f:
            path = f.name
        try:
            logger = CAUMTelemetryLogger(output_path=path, min_steps=5)
            rng = np.random.default_rng(42)
            for _ in range(10):
                r = logger.log("agent_1", rng.normal(0, 0.2, 6))
            assert "regime" in r
        finally:
            os.unlink(path)

    def test_jsonl_format_correct(self):
        with tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False, mode="w") as f:
            path = f.name
        try:
            logger = CAUMTelemetryLogger(output_path=path, min_steps=0, run_id="test123")
            for i in range(20):
                logger.log("agent_1", np.random.default_rng(i).normal(0, 0.2, 6))
            lines = [l for l in open(path).readlines() if l.strip()]
            assert len(lines) > 0
            r = json.loads(lines[0])
            assert "regime" in r and "agent_id" in r and "timestamp" in r
        finally:
            os.unlink(path)

    def test_log_batch(self):
        with tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False) as f:
            path = f.name
        try:
            logger = CAUMTelemetryLogger(output_path=path, min_steps=5)
            vecs = [np.random.default_rng(k).normal(0, 0.2, 6) for k in range(30)]
            results = logger.log_batch("agent_1", vecs)
            assert len(results) == 30
        finally:
            os.unlink(path)

    def test_anomaly_summary(self):
        with tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False) as f:
            path = f.name
        try:
            logger = CAUMTelemetryLogger(output_path=path, min_steps=0)
            # Feed zero vecs = MICRO_JITTER anomaly
            for _ in range(25): logger.log("stuck_agent", np.zeros(6))
            summary = logger.anomaly_summary()
            # stuck_agent should appear
            ids = [a["agent_id"] for a in summary]
            assert "stuck_agent" in ids
        finally:
            os.unlink(path)

    def test_dump_history(self):
        with tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False) as f:
            path = f.name
        try:
            logger = CAUMTelemetryLogger(output_path=path, min_steps=0, run_id="hist")
            for i in range(15):
                logger.log("agent_1", np.random.default_rng(i).normal(0, 0.2, 6))
            history = logger.dump_history("agent_1")
            assert isinstance(history, list)
            assert all("step" in h for h in history)
        finally:
            os.unlink(path)
