from setuptools import setup, find_packages

setup(
    name="caum",
    version="1.0.0",
    description="AI Agent Observability — Detect when your agent is wasting money",
    long_description=open("README.md").read() if __import__("os").path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    author="Andres Silva",
    author_email="contact@caum.systems",
    url="https://caum.systems",
    packages=find_packages(),
    install_requires=[
        "requests>=2.28.0",
    ],
    python_requires=">=3.8",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Testing",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
    ],
)
