# Principles

This section defines the architectural assumptions and design principles behind Patchwork.

These principles are not optional recommendations — they define the expected behavior of all compatible components.

---

## Assumptions

The system is designed under the following assumptions:

- The message broker provides transactional semantics (messages can be acknowledged or rolled back)
- The broker can retry unacknowledged or failed messages
- A single data model is owned by exactly one component, but multiple instances of that component may run concurrently
- Message formats must be backward compatible across at least one version
- Components may fail at any time without data loss
- Messages may be delivered more than once
- Duplicate message delivery must not cause incorrect side effects
- Direct communication between components is not allowed (except for read-only data retrieval)
- All create, update, and delete operations are performed via events
- Multiple producers and consumers may exist for the same event type
- All operations are asynchronous and non-blocking

---

## Delivery semantics

Patchwork is built around **at-least-once delivery semantics**.

This means:

- a message is guaranteed to be delivered at least once
- duplicates are possible
- message loss is not expected under normal broker operation

---

### Transactional broker behavior

To support reliability, the broker must support a mechanism similar to:

- receive message
- process message
- commit or rollback

A message is removed from the queue only after successful commit.

Alternatively, brokers such as Kafka may use offset-based tracking with retention policies.

---

### Handling duplicates

Because duplicate delivery is expected, all operations must be **idempotent**.

Common strategies include:

- using a unique `event_id` per message
- tracking processed message IDs locally (deduplication cache)
- designing updates as “create or update” operations instead of pure inserts
- relying on natural ordering guarantees where available

---

!!! warning

    Exactly-once delivery is not realistically achievable in distributed systems.

    Only the following guarantees exist:

    - **At-least-once**: messages may be duplicated, but are not lost
    - **At-most-once**: messages are never duplicated, but may be lost

    Patchwork is explicitly designed for at-least-once delivery.

---

## Broker retries and retention

Message brokers must support retrying or retaining unprocessed messages.

Retention time should be configured based on operational needs (typically hours to days depending on throughput and
message size).

---

### Message size considerations

Messages should remain small.

Large payloads should be stored externally (e.g. object storage), with messages containing references.

Most brokers are not optimized for large messages (commonly recommended limit: a few kilobytes).

---

!!! hint

    Keep retention time long enough to allow recovery and operational intervention.

    Dynamic retention policies (increasing retention during incidents) are recommended when supported by the broker.

---

## Ownership of data

Each data model must be owned and modified by a single component.

This prevents:

- conflicting writes
- distributed locking requirements
- consistency issues across services

---

Multiple instances of the same component may run concurrently.

To avoid conflicts between instances:

- messages related to the same resource should be routed consistently to the same instance (e.g. partitioning by
  resource ID)
- systems must tolerate duplicate processing of the same event

---

## Message versioning

Message formats must be backward compatible.

It is not possible to upgrade all components simultaneously in a distributed system.

Therefore:

- new fields must be additive
- consumers must ignore unknown fields
- message versioning should be supported explicitly or implicitly

---

### Recommended approach

- use flexible serialization formats (e.g. MessagePack or JSON)
- avoid strict schemas that break backward compatibility
- treat missing fields as optional
- avoid modifying meaning of existing fields

---

!!! note

    Over time, message schemas may grow.

    Obsolete fields can eventually be deprecated and ignored, but must not break existing consumers.

---

## Fault tolerance

Components must be designed under the assumption that failure can occur at any time.

A typical failure scenario:

1. A component receives and processes a message
2. It crashes before committing the result
3. The broker re-delivers the message to another instance
4. The system must still produce correct results

---

### Idempotent processing

To handle this safely:

- operations must be repeatable without side effects
- processing must not depend on local transient state alone
- resource-level routing can be used to ensure consistency

---

## No direct communication

Components must not communicate directly with each other for state changes.

All state changes must be expressed as events.

Only read-only operations may use direct requests.

---

### Rationale

Direct communication introduces:

- hidden coupling
- implicit dependencies
- unpredictable evolution paths

Event-based communication ensures that:

- all state changes are observable
- multiple consumers can react independently
- system evolution remains flexible

---

### Caching

Caching is encouraged for read-heavy workloads.

However, cached data must be invalidated using events emitted by the owning component.

---

!!! hint

    Nothing in the system should be assumed immutable.

    All cached data must be considered stale unless explicitly validated or invalidated.

---

## Event-driven communication model

Events are not owned by consumers.

This implies:

- multiple producers may emit the same event type
- multiple consumers may listen to the same event type
- some events may have no consumers

---

### Design guidelines

Avoid both extremes:

- overly generic events (e.g. “event(data)”)
- overly granular event explosion

A balanced model is recommended.

In most systems, a small set of core events is sufficient:

- create
- update
- delete

---

## Asynchronous execution

All operations are asynchronous by design.

The system does not block waiting for downstream effects.

This is intentional and required for scalability.

---

### Response model

A successful operation means:

- the event has been accepted by the broker
- not that all side effects have completed

---

User-facing systems should:

- respond immediately after event submission
- use asynchronous updates (e.g. WebSockets or polling) to reflect state changes

---

### Correlation

Correlation IDs may be used to track event chains across components.

However, systems should avoid introducing unnecessary synchronous waiting flows.

---

!!! hint

    In interactive systems, users should not wait for full distributed completion.

    Instead, they should be notified when state changes occur.

    This improves scalability and user experience.