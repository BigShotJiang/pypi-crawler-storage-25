# Node architecture

A **Node** is the fundamental runtime unit in Patchwork.

Each node is an independently deployable component responsible for a well-defined subset of the system, typically
aligned with a specific resource type or domain responsibility.

Nodes are horizontally scalable. Running multiple instances of the same node is not only allowed but encouraged.

---

## Runtime model

Technically, a node is a Python process that consumes messages from a broker, executes processors, and handles lifecycle
and operational concerns such as monitoring and coordination.

---

## Internal components

A node is composed of the following internal modules:

### Worker

The root entry point of the node.

Responsible for:

- initializing the runtime
- wiring dependencies
- starting and stopping the system

---

### Executor

Responsible for:

- consuming messages from configured clients
- dispatching tasks to the processing layer
- managing execution flow

---

### Processing Unit

Responsible for:

- executing business logic for a given task
- ensuring isolation of task execution
- reporting execution results back to the executor

This is the main extension point for application developers.

---

### Manager

Responsible for:

- exposing node state and health information
- tracking runtime metrics
- maintaining internal lifecycle state

---

### Coordinator (planned)

A future component responsible for:

- communication between node instances
- resource-based routing decisions
- consensus or coordination of distributed processing (e.g. partition ownership)

---

## Extensibility model

Each internal module (with the exception of the Worker) can be replaced by an alternative implementation provided by
external libraries.

This allows customization of:

- execution strategy
- processing model
- monitoring system
- coordination logic

All replacements are configured via dependency injection or configuration changes, without modifying core node code.

---

## Deployment model

Nodes can be deployed in multiple ways:

- as standalone Python applications
- as containerized services (recommended for production)

---

!!! hint

    A ready-to-use Patchwork node is available as a Docker image.

    If no customization is required, you can deploy a node by:

    - providing processor code in the application directory
    - running the container

    On startup, the node will:
    - discover available processors
    - initialize runtime components
    - begin consuming messages from configured brokers