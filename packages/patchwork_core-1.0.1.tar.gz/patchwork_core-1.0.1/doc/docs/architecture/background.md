# Background

Modern applications are increasingly built using microservice architectures. In this model, data models and business
capabilities are split across multiple independent services.

In practice, achieving true independence is difficult.

As systems grow, communication between services becomes increasingly complex. Most commonly, this is handled using
direct service-to-service communication via APIs (e.g. REST over HTTP, or gRPC behind an API gateway).

---

## The problem with orchestration-heavy systems

Consider a user registration flow.

A user submits a registration form, which is sent to an API Gateway and processed by a dedicated registration service.

However, user registration is rarely a single operation. It often involves:

- validation
- user record creation
- sending confirmation emails
- provisioning resources
- integration with external systems

As the system evolves, additional steps are introduced, such as:

- multiple user types
- third-party integrations
- migration and synchronization with external platforms

Over time, the “registration service” becomes a central orchestration layer coordinating multiple microservices.

---

## Why this becomes a problem

At first, delegating responsibilities to multiple services via synchronous calls may seem reasonable.

However, this approach introduces several issues:

- tight coupling between services
- complex request chains across multiple systems
- fragile error handling and retry logic
- difficult scaling and deployment coordination
- slow end-user response times due to chained dependencies

If any downstream service fails during processing, the entire operation may fail or become inconsistent.

In practice, the system becomes a distributed monolith.

---

## Moving to event-driven architecture

To address these limitations, many systems introduce message queues and event-driven communication.

Instead of direct service-to-service calls:

- services publish events
- other services subscribe and react independently
- no service needs to know the full set of downstream consumers

This decouples system components and improves scalability and resilience.

---

## The remaining challenge

Event-driven systems introduce a new challenge:

> How do we notify the user when the entire process is complete?

In a fully decoupled system, we do not know:

- how many services will react to an event
- which services are required for “completion”
- when all side effects are finished

This is intentional.

---

!!! note

    In Patchwork, this is a core principle:

    **We do not know — and do not want to know — how many components react to an event.**

    Introducing explicit coordination logic would tightly couple services again, defeating the purpose of the architecture.

---

## Rethinking synchronous responses

In many cases, users do not require immediate completion of an operation.

For example:

- account creation
- content publishing
- background processing tasks

In such systems, it is sufficient to acknowledge that a request has been accepted, not fully completed.

Only data retrieval operations are expected to return immediate results.

---

## Reliability requirement

While responses are asynchronous, the system must still guarantee:

- eventual processing of accepted events
- no silent message loss
- recoverability in case of component failure

This requires careful design of each component and its interaction with the message broker.

---

## Analogy: real-time games

This model is similar to multiplayer games.

A client does not wait for confirmation of every action before continuing gameplay.

Instead:

- actions are sent to the server
- the game continues locally
- the authoritative state is later synchronized via updates

For example:

- the player issues a movement command
- the server processes it asynchronously
- the updated position is later broadcast in a game state update

This enables responsiveness without blocking execution.

---

## Patchwork design goal

Patchwork is designed around these principles.

It provides a lightweight foundation for building asynchronous, event-driven services in Python.

The framework aims to:

- reduce boilerplate in distributed systems
- standardize client and worker behavior
- handle messaging, retries, and consistency patterns
- allow developers to focus only on business logic

---

## Future capabilities (design intent)

The long-term goal is to support:

- service monitoring
- horizontal scaling
- blue/green deployments
- fault recovery mechanisms
- strong delivery guarantees at the component level

Note: these capabilities are not provided magically by the framework alone, but are enabled through consistent component
design and infrastructure support.