# Changelog

## 0.3.0 [BREAKING]

Released 2026-04-10

Framework core refactored, key changes:

1) removed subclass Config, removed pydantic config validation

   Now config is passed just a args in components \_\_init__, validation should be done in
   application code.

2) removed ClassPath and FnPath

   No longer needed config types for classes and functions. Class and function is not configurable
   by import path - pass the instance directly as argument to \_\_init__.

4) now package is managed by uv

5) dropped support for Python 3.7, 3.8, 3.9, 3.10; lib needs at least Python 3.11

6) updated dependencies
