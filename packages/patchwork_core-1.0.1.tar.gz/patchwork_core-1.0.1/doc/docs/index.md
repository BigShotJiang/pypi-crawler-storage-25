# Welcome to Patchwork Core

[![PyPI version](https://badge.fury.io/py/patchwork-core.svg)](https://badge.fury.io/py/patchwork-core)
[![MIT](https://img.shields.io/badge/license-MIT-blue)](license.md)

Patchwork Core is a lightweight framework for building asynchronous microservice ecosystems.

Instead of relying on HTTP or gRPC, Patchwork systems communicate through message brokers, enabling event-driven and
distributed workflows.

---

## Project status

Patchwork is under active development. The Core API is considered stable and should not change significantly.

Kafka integration and node components are already operational and used in production environments. However, due to
limited time and resources, the framework is not yet fully documented or comprehensively tested across all modules.

If you would like to contribute, report issues, or share feedback, please visit the project on GitLab:

👉 https://gitlab.com/patchwork-framework/core

---

!!! warning

    As of Patchwork Core 0.2 requires Pydantic 2.0.

    As of Patchwork Core 0.3 requires Python 3.11

---

## Why use Patchwork?

Patchwork is designed around simplicity, scalability, and asynchronous-first design:

- **Simple** — only essential core functionality is included; additional features are provided via specialized packages
- **Asynchronous-first** — built entirely around async execution at the architecture level
- **Easy to integrate** — can run as a standalone service (Docker/Kubernetes) or be embedded into existing async Python
  applications
- **Reliable** — supports delivery guarantees, acknowledgements, retries, and backoff-based processing

---

## Installation

The Core package is not a standalone application. It provides shared foundations for the entire Patchwork ecosystem,
including both producers and workers.

To build a working system, you can either extend the Core or use one of the prebuilt components:

- `patchwork-kafka-client`  
  Producer for publishing messages via Apache Kafka  
  [![PyPI version](https://badge.fury.io/py/patchwork-client-kafka.svg)](https://badge.fury.io/py/patchwork-client-kafka)

- `patchwork-node`  
  Worker implementation for processing messages, usable both standalone and as part of a cluster  
  [![PyPI version](https://badge.fury.io/py/patchwork-node.svg)](https://badge.fury.io/py/patchwork-node)

- `patchwork-websoccer`  
  Gateway service for bridging internal message brokers with external systems via WebSockets  
  [![PyPI version](https://badge.fury.io/py/patchwork-websoccer.svg)](https://badge.fury.io/py/patchwork-websoccer)

---

### Install Core only

```bash
pip install patchwork-core
```