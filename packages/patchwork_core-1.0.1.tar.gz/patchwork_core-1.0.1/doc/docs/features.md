# Patchwork µFramework

!!! danger

    This framework should currently be considered **beta software**.

Patchwork is an asynchronous microframework for building distributed, event-driven microservice systems.

It is designed for queue-based architectures where multiple services cooperate to form complex applications.

While the concept may sound complex, Patchwork provides a minimal and opinionated foundation for building modern Python
microservice systems.

---

## Architecture overview

Patchwork is built around a strict separation of concerns:

- Each service owns its resources exclusively
- Services communicate through events, not direct state mutation
- All updates are propagated via a message broker (e.g. RabbitMQ or Apache Kafka)
- Direct service-to-service communication is limited to read-only operations

This design encourages scalability, fault isolation, and predictable system behavior.

---

## Key features

- **Minimal** — install only what you need; thin clients are available for lightweight integration
- **Modern** — Python 3+ only, fully asynchronous design
- **Async-first** — everything is non-blocking by design
- **Simple to implement** — focus only on business logic; concerns like retries, serialization, logging, and task
  durability are handled by the framework
- **Easy to deploy** — works with existing infrastructure using Kafka, RabbitMQ, or Redis
- **Resilient** — supports replaying and retrying queued tasks after failures
- **No data loss (design goal)** — transactional event handling combined with proper broker configuration minimizes risk
  of data loss
- **Opinionated architecture** — includes explicit design rules to keep distributed systems maintainable over time