# Overview

Client packages provide integration with third-party message brokers.

The Patchwork node itself does not include any built-in broker implementation. Instead, it relies on external client
packages that implement a defined interface.

This design keeps the core framework minimal and allows broker support to evolve independently.

Clients can also be used outside of Patchwork nodes to send tasks from existing applications without installing the full
framework.

Both synchronous and asynchronous clients share the same interface.

The only difference is implementation style:

- synchronous clients use blocking methods
- asynchronous clients use coroutines

Client type is determined using the `is_asynchronous` flag.

---

## Synchronous client

A synchronous client integrates easily with existing blocking applications.

All operations are blocking and return only when completed or failed.

!!! warning

    Synchronous clients must not be used inside Patchwork nodes.

---

## Asynchronous client

An asynchronous client implements the same interface using coroutines.

All operations must be non-blocking.

If an underlying transport library does not support asyncio natively, blocking calls should be executed using a
thread-based executor (e.g. `ThreadPoolExecutor`).

!!! hint

    If supporting legacy Python versions, ensure that asynchronous code paths are not executed on unsupported interpreters.

    Feature gating based on interpreter version (e.g. `sys.version_info`) is recommended.

---

## Client lifecycle

### Initialization

To use a client, it must be instantiated.

All clients accept at least the following arguments:

- `name` — human-readable client name used for logging and diagnostics
- `serializer` — an object implementing:
    - `dumps()`
    - `loads()`

!!! note

    Depending on the transport implementation, additional initialization parameters may be required. Refer to the specific
    client documentation.

---

### Starting a client

A client must be explicitly started using `start()` before it can send or receive tasks.

Starting a client establishes a connection with the underlying message broker.

---

### Stopping a client

When the client is no longer needed, it must be stopped using `stop()`.

This ensures that all buffered data is flushed and resources are properly released.

!!! danger

    Only a properly stopped client should be destroyed.
    Failure to call `stop()` may result in data loss, as implementations are allowed to buffer messages or use lazy commits.

!!! note

    For asynchronous clients, both `start()` and `stop()` are coroutines and must be awaited.

---

## Task serialization

Tasks are serialized into binary-safe formats before being transmitted over the network.

Serialization is handled by a user-provided serializer implementing:

- `dumps(obj) -> bytes | str`
- `loads(data) -> obj`

The serializer operates on **task state**, which must consist only of built-in Python types.

Custom classes are not serialized directly.

---

### Recommended serializers

- [MessagePack](https://msgpack.org/)  
  Fast, compact, and efficient. Produces binary output that is not human-readable.

- [JSON](https://docs.python.org/3/library/json.html)  
  Slower but human-readable. Useful for debugging and development environments.

!!! note

    Conversion between task objects and serializable state is handled internally by the task class via `__getstate__()` and
    `__setstate__()`.

    Because not all serializers support these methods directly, the client explicitly invokes them before serialization.

!!! danger

    Using `pickle` as a serializer is strongly discouraged.
    It is unsafe and may lead to arbitrary code execution when processing malformed or malicious data.

    See Python’s [pickle security documentation](https://docs.python.org/3/library/pickle.html) for details.