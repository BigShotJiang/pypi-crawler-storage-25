# Writing custom clients

As described in the [Overview](overview.md) chapter, a client is a class that implements a defined interface.

To create a custom client, inherit from `SynchronousClient` or `AsyncClient` from the `patchwork-client-base` package.

It is also possible to implement a client from scratch, but the base package provides core functionality shared across
all clients and is the recommended starting point.

---

## Required methods

Each client must implement the following methods:

- `_send()`
- `_fetch_one()`
- `_commit()`
- `_rollback()`

The following methods are optional:

- `_setup()`
- `_teardown()`

The method signatures are identical for synchronous and asynchronous clients. The only difference is that async
implementations must use coroutines.

---

## Sending messages

The `_send()` method must accept three arguments:

- `payload` (`bytes`)  
  Serialized task payload. If the transport expects text data, encoding must be handled here.

- `meta` (`Mapping[str, Union[str, bytes, int, float, bool]]`)  
  Metadata associated with the message.  
  Metadata is not part of the payload but may contain routing or control information.  
  Some transports may use metadata for retries, partitioning, or delivery control.

- `timeout` (`float | None`)  
  Maximum time allowed for sending (in seconds):
    - `None` → no timeout
    - `0` → immediate / transport default
    - `> 0` → timeout in seconds

If the timeout is exceeded, the method must raise a standard Python `TimeoutError`.

!!! warning

    Always raise the **standard `TimeoutError`** exception.

    Many libraries define their own timeout exceptions that are not derived from the built-in one. These must be caught and re-raised.

    Only the standard `TimeoutError` is handled correctly by Patchwork components.

!!! danger

    `asyncio.TimeoutError` is **not** compatible with Patchwork error handling.

    If raised (e.g. from `asyncio.wait_for()`), it must be caught and re-raised as a standard `TimeoutError`.

The method is not expected to return a value.

If a value is returned, it indicates that the message was successfully accepted by the transport.

!!! hint

    If the transport supports acknowledgements (ACKs), `_send()` should wait for confirmation before returning.

    If multiple ACK levels exist, they should be exposed as a client configuration option.

---

## Fetching messages

The `_fetch_one()` method accepts a single argument:

- `timeout` (`float | None`)  
  Maximum wait time for a message:
    - `None` → wait indefinitely
    - `0` → do not wait; return immediately if no message is available
    - `> 0` → wait up to the given number of seconds

If no message is received within the timeout, the method must raise a standard `TimeoutError`.

!!! warning

    Always raise the **standard `TimeoutError`** exception.

!!! danger

    `asyncio.TimeoutError` must be converted into a standard `TimeoutError`.

The method must return:

```text
(payload: bytes, metadata: Mapping)
```