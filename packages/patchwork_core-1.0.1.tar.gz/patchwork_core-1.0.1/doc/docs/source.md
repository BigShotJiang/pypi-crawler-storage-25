# Patchwork Core

Project source code can be found at [GitLab](https://gitlab.com/pawelpecio/patchwork/core).

Package name: `patchwork-core`

This package contains a core files of Patchwork Microframework. Core has been extracted to a separate package to allow
building thin packages which works in Patchwork ecosystem.

## Component

::: core.component

## Client

::: core.client.subscriber
::: core.client.publisher
::: core.client.local

## Misc

::: core.utils