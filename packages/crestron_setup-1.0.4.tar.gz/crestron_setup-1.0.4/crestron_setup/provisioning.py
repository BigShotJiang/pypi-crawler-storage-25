"""Provisioning logic — 5-phase setup with animated progress tracking."""

from __future__ import annotations

import io
import logging
import os
import platform
import re
import subprocess
import sys
import tempfile
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.spinner import Spinner
from rich.table import Table
from rich.text import Text

from .firmware import (
    _parse_puf_metadata,
    download_firmware_quiet,
    find_local_firmware,
    version_compare,
)
from .models import Config, Device
from .ssh import CrestronFirstBoot, CrestronSSH, check_ssh_ready, sftp_upload
from .timezones import timezone_label

PHASE_NAMES = [
    "Account Creation",
    "Public Key Upload",
    "Configure Processor",
    "Network Configuration",
    "Reboot",
    "Firmware Upload",
]


def _resolve_pubkey(pubkey_file: str) -> Path | None:
    """Resolve a pubkey source (local path or URL) to a local file path.

    If pubkey_file looks like a URL (http/https), downloads the content to a
    temp file and returns that path. Otherwise treats it as a local path.
    Returns None if the key cannot be resolved.
    """
    parsed = urlparse(pubkey_file)
    if parsed.scheme in ("http", "https"):
        try:
            import httpx

            resp = httpx.get(pubkey_file, timeout=15, follow_redirects=True)
            resp.raise_for_status()
            content = resp.text.strip()
            if not content:
                return None
            # Use first key line if multiple are returned (e.g. GitHub .keys)
            first_key = content.splitlines()[0]
            # Write to a named temp file that persists for the session
            tmp = tempfile.NamedTemporaryFile(
                mode="w", suffix=".pub", prefix="crestron_key_", delete=False
            )
            tmp.write(first_key + "\n")
            tmp.close()
            return Path(tmp.name)
        except Exception:
            return None
    else:
        path = Path(pubkey_file).expanduser()
        return path if path.exists() else None


@contextmanager
def _quiet_ssh():
    """Suppress paramiko/cryptography/ssh logging and stderr noise."""
    loggers = ["paramiko", "paramiko.transport", "cryptography"]
    saved = {name: logging.getLogger(name).level for name in loggers}
    for name in loggers:
        logging.getLogger(name).setLevel(logging.CRITICAL)
    old_stderr = sys.stderr
    sys.stderr = io.StringIO()
    try:
        yield
    finally:
        sys.stderr = old_stderr
        for name, level in saved.items():
            logging.getLogger(name).setLevel(level)


class _NullLive:
    """No-op replacement for rich.live.Live used in headless/parallel mode."""

    def update(self, _renderable=None) -> None:
        pass

    def __enter__(self) -> _NullLive:
        return self

    def __exit__(self, *_args: object) -> None:
        pass


class _StepTracker:
    """Tracks and renders provisioning step progress with animated spinners."""

    def __init__(self, device_label: str, phases: list[str]):
        self.device_label = device_label
        self.phases = phases
        self.statuses: list[str] = ["pending"] * len(phases)
        self.details: list[str] = [""] * len(phases)
        self._panel_title = f"Provisioning {self.device_label}"
        # Persist one spinner so the animation frame advances across renders
        self._spinner = Spinner("dots", style="cyan")

    def start(self, index: int, detail: str = "") -> None:
        self.statuses[index] = "active"
        self.details[index] = detail

    def ok(self, index: int, detail: str = "") -> None:
        self.statuses[index] = "ok"
        if detail:
            self.details[index] = detail

    def fail(self, index: int, detail: str = "") -> None:
        self.statuses[index] = "fail"
        if detail:
            self.details[index] = detail

    def skip(self, index: int, detail: str = "skipped") -> None:
        self.statuses[index] = "skip"
        self.details[index] = detail

    def render_static(self) -> Table:
        """Render the step list without spinners (for final display)."""
        return self._build_table(animated=False)

    def _build_table(self, animated: bool = True) -> Table:
        table = Table.grid(padding=(0, 1))
        table.add_column(width=3)
        table.add_column(width=3)
        table.add_column()

        for i, phase in enumerate(self.phases):
            status = self.statuses[i]
            detail = self.details[i]
            num = f"{i + 1}."
            detail_suffix = f"  [dim]{detail}[/dim]" if detail else ""

            if status == "active":
                icon: object = self._spinner if animated else "●"
                label: object = Text.from_markup(
                    f"[bold cyan]{phase}[/bold cyan]{detail_suffix}"
                )
            elif status == "ok":
                icon = Text.from_markup("[green]✓[/green]")
                label = Text.from_markup(f"{phase}{detail_suffix}")
            elif status == "fail":
                icon = Text.from_markup("[red]✗[/red]")
                label = Text.from_markup(f"[red]{phase}[/red]{detail_suffix}")
            elif status == "skip":
                icon = Text.from_markup("[dim]–[/dim]")
                label = Text.from_markup(f"[dim]{phase}{detail_suffix}[/dim]")
            else:
                icon = Text.from_markup("[dim]○[/dim]")
                label = Text.from_markup(f"[dim]{phase}[/dim]")

            table.add_row(icon, num, label)

        return table

    def __rich__(self) -> Panel:
        return Panel(
            self._build_table(animated=True),
            title=f"[bold]{self._panel_title}[/bold]",
            border_style="cyan",
            padding=(1, 2),
        )


def _clear() -> None:
    os.system("cls" if os.name == "nt" else "clear")


def provision_device(
    device: Device,
    username: str,
    password: str,
    config: Config,
    console: Console,
    skip_firmware: bool = False,
    skip_reboot: bool = False,
    headless: bool = False,
    tracker: _StepTracker | None = None,
) -> bool | tuple[bool, _StepTracker, dict[str, str]]:
    """Run all 5 provisioning phases against a single device.

    When headless=True, returns (success, tracker, results) without displaying.
    Otherwise returns True/False and shows results on console.
    """
    host = device.ip or device.hostname
    if tracker is None:
        tracker = _StepTracker(host, list(PHASE_NAMES))
    results: dict[str, str] = {"host": host, "username": username}

    if headless:
        success = _run_provisioning(
            host, device, username, password, config, console,
            tracker, results, skip_firmware, skip_reboot,
            headless=True,
        )
        return success, tracker, results

    _clear()
    success = _run_provisioning(
        host, device, username, password, config, console,
        tracker, results, skip_firmware, skip_reboot,
    )
    _show_results(console, tracker, results, success, config)
    return success


def _run_provisioning(
    host: str,
    device: Device,
    username: str,
    password: str,
    config: Config,
    console: Console,
    tracker: _StepTracker,
    results: dict[str, str],
    skip_firmware: bool,
    skip_reboot: bool,
    headless: bool = False,
) -> bool:
    """Execute all phases inside a Live display. Returns True on success."""
    model_name = ""
    current_puf_version = ""
    pubkey_path = _resolve_pubkey(config.pubkey_file)
    # Track whether we downloaded the key (needs cleanup)
    _is_temp_key = pubkey_path is not None and str(pubkey_path).startswith(
        tempfile.gettempdir()
    )

    try:
        return _run_provisioning_inner(
            host, device, username, password, config, console,
            tracker, results, skip_firmware, skip_reboot, pubkey_path,
            headless=headless,
        )
    finally:
        if _is_temp_key and pubkey_path and pubkey_path.exists():
            pubkey_path.unlink()


def _run_provisioning_inner(
    host: str,
    device: Device,
    username: str,
    password: str,
    config: Config,
    console: Console,
    tracker: _StepTracker,
    results: dict[str, str],
    skip_firmware: bool,
    skip_reboot: bool,
    pubkey_path: Path | None,
    headless: bool = False,
) -> bool:
    """Execute all phases inside a Live display. Returns True on success."""
    model_name = ""
    current_puf_version = ""

    live_cm: Live | _NullLive = _NullLive() if headless else Live(tracker, console=console, refresh_per_second=10)
    with live_cm as live:

        # ── Phase 1: Account Creation ──────────────────────────────────
        tracker.start(0, "Checking credentials…")
        live.update(tracker)

        with _quiet_ssh():
            login_ok = not device.is_first_boot and _try_login(host, username, password)

        if not login_ok:
            tracker.details[0] = "Creating account…"
            live.update(tracker)
            with _quiet_ssh():
                created = CrestronFirstBoot.try_create_account(host, username, password)
            if created:
                tracker.ok(0, f"Account '{username}' created")
            elif _try_login(host, username, password):
                tracker.ok(0, f"Account '{username}' already exists")
            else:
                tracker.fail(0, "Cannot create account or log in")
                live.update(tracker)
                time.sleep(2)
                return False
        else:
            tracker.ok(0, f"Logged in as '{username}'")
        live.update(tracker)
        time.sleep(2)  # Let processor settle

        # ── Phase 2: Upload Public Key ─────────────────────────────────
        tracker.start(1, "Uploading…")
        live.update(tracker)

        if not pubkey_path:
            tracker.skip(1, "Key not found")
        else:
            if sftp_upload(host, username, password, str(pubkey_path), "/user"):
                tracker.ok(1, pubkey_path.name)
            else:
                tracker.fail(1, "Upload failed")
                live.update(tracker)
                time.sleep(2)
                return False
        live.update(tracker)

        # ── Phase 3: Configure Processor ───────────────────────────────
        tracker.start(2, "Connecting…")
        live.update(tracker)

        now = datetime.now()
        current_time = now.strftime("%H:%M:%S")
        current_date = now.strftime("%m-%d-%Y")

        commands: list[tuple[str, str]] = []
        pubkey_basename = pubkey_path.name if pubkey_path else ""
        if pubkey_basename:
            commands.append((
                f"ADDPUBKEYTOUSER -N:{username} -K:{pubkey_basename}",
                "Registering public key",
            ))
        commands += [
            (f"TIMEZONE {config.timezone}", "Setting timezone"),
            (f"TIMEDATE {current_time} {current_date}", "Setting date/time"),
            (f"SNTP SERVER:{config.ntp_server}", "Configuring NTP"),
            ("SNTP SYNC", "Syncing time"),
            (f"WEBPORT {config.web_port}", "Setting web port"),
            (f"SECUREWEBPORT {config.secure_web_port}", "Setting secure web port"),
            (f"SETUSERLOGINATTEMPTS {config.user_login_attempts}", "Login attempts"),
            (f"SETUSERLOCKOUTTIME {config.user_lockout_time}", "Lockout time"),
            (f"SETLOGINATTEMPTS {config.login_attempts}", "Console login attempts"),
            (f"SETLOCKOUTTIME {config.lockout_time}", "Console lockout time"),
            (f"FIPSMODE {config.fips_mode}", "Setting FIPS mode"),
        ]

        try:
            with CrestronSSH(host, username, password) as ssh:
                model_name = ssh.model
                results["model"] = model_name

                for i, (cmd, desc) in enumerate(commands):
                    tracker.details[2] = f"{desc} ({i + 1}/{len(commands)})"
                    live.update(tracker)
                    ssh.send_command(cmd)

                tracker.details[2] = "Reading version info…"
                live.update(tracker)
                ver_output = ssh.send_command("VER -V", timeout=20)

                for line in ver_output.splitlines():
                    if "PUF:" in line.upper() and "PUFEXEC" not in line.upper():
                        m = re.search(r"PUF:\s*([\d.]+)", line, re.IGNORECASE)
                        if m:
                            current_puf_version = m.group(1)
                            break

        except Exception as e:
            tracker.fail(2, str(e))
            live.update(tracker)
            time.sleep(2)
            return False

        detail = f"{len(commands)} settings applied"
        if model_name:
            device.model = model_name
            detail = f"{model_name} — {detail}"
        tracker.ok(2, detail)
        results["puf_version"] = current_puf_version
        live.update(tracker)

        # ── Phase 4: Network Configuration ─────────────────────────────
        net = device.network
        if not net:
            tracker.skip(3, "No changes requested")
            live.update(tracker)
        elif net.mode == "dhcp":
            tracker.start(3, "Enabling DHCP…")
            live.update(tracker)
            try:
                with CrestronSSH(host, username, password) as ssh:
                    if net.hostname:
                        ssh.send_command(f"HOSTNAME {net.hostname}")
                    ssh.send_command("DHCP 0 ON /now")
                    # Confirm via IPCONFIG
                    tracker.details[3] = "Verifying…"
                    live.update(tracker)
                    ip_output = ssh.send_command("IPCONFIG /ALL", timeout=10)
                    results["ip_config"] = ip_output
                detail = "DHCP enabled"
                if net.hostname:
                    detail += f" — hostname: {net.hostname}"
                tracker.ok(3, detail)
            except Exception as e:
                tracker.fail(3, str(e))
                live.update(tracker)
                time.sleep(2)
                return False
            live.update(tracker)
        else:
            tracker.start(3, "Setting static IP…")
            live.update(tracker)
            try:
                with CrestronSSH(host, username, password) as ssh:
                    # Set IP details first (without /now), then disable DHCP
                    # last with /now so all changes activate together.
                    net_cmds = []
                    if net.hostname:
                        net_cmds.append((f"HOSTNAME {net.hostname}", f"Hostname → {net.hostname}"))
                    net_cmds += [
                        (f"IPADDRESS 0 {net.ip_address}", f"IP → {net.ip_address}"),
                        (f"IPMASK 0 {net.subnet_mask}", f"Mask → {net.subnet_mask}"),
                        (f"DEFROUTER 0 {net.gateway}", f"Gateway → {net.gateway}"),
                    ]
                    total = len(net_cmds) + len(net.dns_servers) + 1  # +1 for DHCP OFF
                    for i, (cmd, desc) in enumerate(net_cmds):
                        tracker.details[3] = f"{desc} ({i + 1}/{total})"
                        live.update(tracker)
                        ssh.send_command(cmd)

                    for i, dns in enumerate(net.dns_servers):
                        tracker.details[3] = f"DNS → {dns} ({len(net_cmds) + i + 1}/{total})"
                        live.update(tracker)
                        ssh.send_command(f"ADDDNS {dns}")

                    # Disable DHCP last — activates all pending static settings
                    tracker.details[3] = f"Disabling DHCP ({total}/{total})"
                    live.update(tracker)
                    ssh.send_command("DHCP 0 OFF /now")

                    # Confirm via IPCONFIG
                    tracker.details[3] = "Verifying…"
                    live.update(tracker)
                    ip_output = ssh.send_command("IPCONFIG /ALL", timeout=10)
                    results["ip_config"] = ip_output

                # After static IP change the host may have moved
                if net.ip_address:
                    host = net.ip_address

                tracker.ok(3, f"{net.ip_address}/{net.subnet_mask}")
            except Exception as e:
                tracker.fail(3, str(e))
                live.update(tracker)
                time.sleep(2)
                return False
            live.update(tracker)

        # ── Phase 5: Reboot ────────────────────────────────────────────
        if skip_reboot:
            tracker.skip(4)
            live.update(tracker)
        else:
            tracker.start(4, "Sending reboot command…")
            live.update(tracker)

            try:
                with CrestronSSH(host, username, password) as ssh:
                    ssh.channel.sendall(b"REBOOT\r")  # type: ignore[union-attr]
                    time.sleep(1)
            except Exception:
                pass  # Connection drops immediately

            tracker.details[4] = "Waiting for processor to go offline…"
            live.update(tracker)
            min_wait = 30
            for sec in range(min_wait):
                tracker.details[4] = f"Rebooting… {min_wait - sec}s before first check"
                time.sleep(1)

            reboot_timeout = 300
            poll_interval = 5
            elapsed = 0
            came_back = False
            next_ping_at = 0  # ping immediately on first iteration
            ping_ok = False

            while elapsed < reboot_timeout:
                tracker.details[4] = (
                    f"Ping OK — checking SSH… {elapsed}s"
                    if ping_ok
                    else f"Waiting for response… {elapsed}s"
                )

                if elapsed >= next_ping_at:
                    ping_ok = _ping(host)
                    if ping_ok:
                        with _quiet_ssh():
                            if check_ssh_ready(host, username, password, timeout=5):
                                came_back = True
                                break
                    next_ping_at = elapsed + poll_interval

                time.sleep(1)
                elapsed += 1

            if came_back:
                tracker.ok(4, f"Back online after {elapsed}s")
            else:
                tracker.fail(4, f"Timed out after {reboot_timeout}s")
                live.update(tracker)
                time.sleep(2)
                return False
            live.update(tracker)

        # ── Phase 6: Firmware Upload ───────────────────────────────────
        if skip_firmware:
            tracker.skip(5)
            live.update(tracker)
        else:
            tracker.start(5, "Checking firmware…")
            live.update(tracker)

            if not model_name:
                tracker.skip(5, "No model detected")
            else:
                fw_path, fw_version = find_local_firmware(model_name, config)
                if not fw_path:
                    # Try downloading from configured URL
                    tracker.details[5] = "Downloading firmware…"
                    live.update(tracker)
                    fw_path = download_firmware_quiet(model_name, config)
                    if fw_path:
                        fw_version, _ = _parse_puf_metadata(fw_path)
                if not fw_path:
                    tracker.skip(5, "No firmware file found")
                elif current_puf_version and fw_version:
                    cmp = version_compare(fw_version, current_puf_version)
                    if cmp == 0:
                        tracker.ok(5, f"Already at v{fw_version}")
                    elif cmp < 0:
                        tracker.ok(
                            5,
                            f"Local v{fw_version} older than v{current_puf_version}",
                        )
                    else:
                        tracker.details[5] = f"Uploading {fw_path.name}…"
                        live.update(tracker)
                        if sftp_upload(
                            host, username, password, str(fw_path), "/firmware"
                        ):
                            tracker.details[5] = "Installing firmware…"
                            live.update(tracker)
                            try:
                                with _quiet_ssh():
                                    with CrestronSSH(host, username, password) as ssh:
                                        ssh.send_command("PUF", timeout=60)
                            except Exception:
                                pass  # PUF triggers reboot, connection drops
                            tracker.ok(5, f"Uploaded v{fw_version} — installing (device will reboot)")
                            results["firmware"] = fw_version
                        else:
                            tracker.fail(5, "Upload failed")
                else:
                    tracker.details[5] = f"Uploading {fw_path.name}…"
                    live.update(tracker)
                    if sftp_upload(
                        host, username, password, str(fw_path), "/firmware"
                    ):
                        tracker.details[5] = "Installing firmware…"
                        live.update(tracker)
                        try:
                            with _quiet_ssh():
                                with CrestronSSH(host, username, password) as ssh:
                                    ssh.send_command("PUF", timeout=60)
                        except Exception:
                            pass  # PUF triggers reboot, connection drops
                        tracker.ok(5, f"Uploaded {fw_path.name} — installing (device will reboot)")
                        results["firmware"] = fw_version or fw_path.name
                    else:
                        tracker.fail(5, "Upload failed")
            live.update(tracker)

        # Brief pause so user sees the completed tracker
        time.sleep(1)

    return all(s in ("ok", "skip") for s in tracker.statuses)


def _show_results(
    console: Console,
    tracker: _StepTracker,
    results: dict[str, str],
    success: bool,
    config: Config,
) -> None:
    """Clear screen and display a results summary panel."""
    _clear()

    if success:
        title = "[bold green]Provisioning Complete[/bold green]"
        border = "green"
    else:
        title = "[bold red]Provisioning Failed[/bold red]"
        border = "red"

    console.print(
        Panel(
            tracker.render_static(),
            title=title,
            border_style=border,
            padding=(1, 2),
        )
    )
    console.print()

    if success:
        info = Table.grid(padding=(0, 2))
        info.add_column(style="bold")
        info.add_column()

        host = results.get("host", "")
        model = results.get("model", "")
        info.add_row("Device:", f"{model} @ {host}" if model else host)
        info.add_row("Account:", results.get("username", ""))
        info.add_row("Timezone:", timezone_label(config.timezone))
        info.add_row("NTP Server:", config.ntp_server)
        info.add_row("Web Port:", str(config.web_port))
        info.add_row("Secure Port:", str(config.secure_web_port))
        info.add_row("FIPS Mode:", config.fips_mode)
        if results.get("puf_version"):
            info.add_row("PUF Version:", results["puf_version"])
        if results.get("firmware"):
            info.add_row("Firmware:", results["firmware"])
        if results.get("ip_config"):
            console.print(info)
            console.print()
            console.print("[bold]Network Configuration:[/bold]")
            console.print(results["ip_config"])
        else:
            console.print(info)
        console.print()


RESTORE_PHASE_NAMES = [
    "Initialize",
    "Reboot (1 of 2)",
    "Restore",
    "Reboot (2 of 2)",
]


def restore_device(
    device: Device,
    username: str,
    password: str,
    console: Console,
    headless: bool = False,
    tracker: _StepTracker | None = None,
) -> bool | tuple[bool, _StepTracker]:
    """Initialize and restore a device to factory defaults.

    When headless=True, returns (success, tracker) without displaying.
    Otherwise returns True/False and shows results on console.
    """
    host = device.ip or device.hostname
    if tracker is None:
        tracker = _StepTracker(host, list(RESTORE_PHASE_NAMES))
        tracker._panel_title = f"Restore & Erase {host}"

    if headless:
        success = _run_restore(host, username, password, console, tracker, headless=True)
        return success, tracker

    _clear()
    success = _run_restore(host, username, password, console, tracker)
    _show_restore_results(console, tracker, host, success)
    return success


def _run_restore(
    host: str,
    username: str,
    password: str,
    console: Console,
    tracker: _StepTracker,
    headless: bool = False,
) -> bool:
    """Execute initialize/restore phases inside a Live display."""

    live_cm: Live | _NullLive = _NullLive() if headless else Live(tracker, console=console, refresh_per_second=10)
    with live_cm as live:

        # ── Phase 1: Initialize ────────────────────────────────────────
        tracker.start(0, "Connecting…")
        live.update(tracker)

        try:
            with _quiet_ssh():
                with CrestronSSH(host, username, password) as ssh:
                    tracker.details[0] = "Sending initialize command…"
                    live.update(tracker)
                    ssh.channel.sendall(b"initialize -y\r")  # type: ignore[union-attr]
                    time.sleep(2)
        except Exception as e:
            tracker.fail(0, str(e))
            live.update(tracker)
            time.sleep(2)
            return False

        tracker.ok(0, "Initialize command sent")
        live.update(tracker)

        # ── Phase 2: Reboot (1 of 2) ──────────────────────────────────
        tracker.start(1, "Waiting for processor to go offline…")
        live.update(tracker)

        if not _wait_for_reboot(host, username, password, tracker, 1, live):
            return False

        # ── Phase 3: Restore ──────────────────────────────────────────
        tracker.start(2, "Connecting…")
        live.update(tracker)

        try:
            with _quiet_ssh():
                with CrestronSSH(host, username, password) as ssh:
                    tracker.details[2] = "Sending restore command…"
                    live.update(tracker)
                    ssh.channel.sendall(b"restore -y\r")  # type: ignore[union-attr]
                    time.sleep(2)
        except Exception as e:
            tracker.fail(2, str(e))
            live.update(tracker)
            time.sleep(2)
            return False

        tracker.ok(2, "Restore command sent")
        live.update(tracker)

        # ── Phase 4: Reboot (2 of 2) ──────────────────────────────────
        tracker.start(3, "Waiting for processor to go offline…")
        live.update(tracker)

        if not _wait_for_reboot(host, username, password, tracker, 3, live, ping_only=True):
            return False

        time.sleep(1)

    return all(s in ("ok", "skip") for s in tracker.statuses)


def _wait_for_reboot(
    host: str,
    username: str,
    password: str,
    tracker: _StepTracker,
    phase: int,
    live: Live,
    ping_only: bool = False,
) -> bool:
    """Wait for a device to reboot and come back online.

    If ping_only is True, only wait for ping (device will be factory-reset
    so SSH credentials may no longer work).
    """
    min_wait = 30
    for sec in range(min_wait):
        tracker.details[phase] = f"Rebooting… {min_wait - sec}s before first check"
        live.update(tracker)
        time.sleep(1)

    reboot_timeout = 300
    poll_interval = 5
    elapsed = 0
    came_back = False
    next_ping_at = 0
    ping_ok = False

    while elapsed < reboot_timeout:
        if ping_only:
            tracker.details[phase] = (
                f"Ping OK — device online" if ping_ok
                else f"Waiting for response… {elapsed}s"
            )
        else:
            tracker.details[phase] = (
                f"Ping OK — checking SSH… {elapsed}s" if ping_ok
                else f"Waiting for response… {elapsed}s"
            )

        if elapsed >= next_ping_at:
            ping_ok = _ping(host)
            if ping_ok:
                if ping_only:
                    came_back = True
                    break
                with _quiet_ssh():
                    if check_ssh_ready(host, username, password, timeout=5):
                        came_back = True
                        break
            next_ping_at = elapsed + poll_interval

        live.update(tracker)
        time.sleep(1)
        elapsed += 1

    if came_back:
        tracker.ok(phase, f"Back online after {elapsed}s")
    else:
        tracker.fail(phase, f"Timed out after {reboot_timeout}s")
        live.update(tracker)
        time.sleep(2)
        return False
    live.update(tracker)
    return True


def _show_restore_results(
    console: Console,
    tracker: _StepTracker,
    host: str,
    success: bool,
) -> None:
    """Display restore results summary."""
    _clear()

    if success:
        title = "[bold green]Restore & Erase Complete[/bold green]"
        border = "green"
    else:
        title = "[bold red]Restore & Erase Failed[/bold red]"
        border = "red"

    console.print(
        Panel(
            tracker.render_static(),
            title=title,
            border_style=border,
            padding=(1, 2),
        )
    )
    console.print()

    if success:
        console.print(f"[green][OK][/green] {host} has been restored to factory defaults.")
        console.print("[dim]The device is now in first-boot mode.[/dim]")
    console.print()


def _try_login(host: str, username: str, password: str) -> bool:
    """Quick SSH login test."""
    return check_ssh_ready(host, username, password, timeout=5)


def _ping(host: str) -> bool:
    """Ping a host once. Cross-platform."""
    param = "-n" if platform.system() == "Windows" else "-c"
    timeout_param = "-w" if platform.system() == "Windows" else "-W"
    try:
        result = subprocess.run(
            ["ping", param, "1", timeout_param, "2", host],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=5,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


# --------------------------------------------------------------------------- #
#  Program Upload
# --------------------------------------------------------------------------- #

PROGRAM_PHASE_NAMES = [
    "Upload Program",
    "Load Program",
]


def upload_program(
    host: str,
    username: str,
    password: str,
    program_path: str,
    slot: int,
    console: Console,
    headless: bool = False,
    tracker: _StepTracker | None = None,
) -> bool | tuple[bool, _StepTracker]:
    """Upload a program file to a processor and load it.

    1. SFTP the file to /programXX/
    2. Run PROGLOAD -P:XX to load it

    When headless=True, returns (success, tracker) without displaying.
    Otherwise returns True/False.
    """
    if tracker is None:
        tracker = _StepTracker(host, list(PROGRAM_PHASE_NAMES))
        tracker._panel_title = f"Program Upload — {host}"

    slot_str = f"{slot:02d}"
    remote_dir = f"/program{slot_str}"
    local = Path(program_path).expanduser()

    live_cm: Live | _NullLive = _NullLive() if headless else Live(tracker, console=console, refresh_per_second=10)
    success = False
    with live_cm as live:
        # ── Phase 1: Upload ────────────────────────────────────────────
        tracker.start(0, f"Uploading {local.name}…")
        live.update(tracker)

        if not local.exists():
            tracker.fail(0, f"File not found: {local}")
            live.update(tracker)
        elif not sftp_upload(host, username, password, str(local), remote_dir):
            tracker.fail(0, "Upload failed")
            live.update(tracker)
        else:
            tracker.ok(0, f"{local.name} → {remote_dir}/")
            live.update(tracker)

            # ── Phase 2: Load ──────────────────────────────────────────
            tracker.start(1, f"Loading program in slot {slot_str}…")
            live.update(tracker)

            try:
                with CrestronSSH(host, username, password) as ssh:
                    output = ssh.send_command(f"PROGLOAD -P:{slot_str}", timeout=30)
                    tracker.ok(1, f"Slot {slot_str} loaded")
                    success = True
            except Exception as e:
                tracker.fail(1, str(e))
            live.update(tracker)

    if headless:
        return success, tracker

    if success:
        console.print()
        console.print(f"[green][OK][/green] Program uploaded and loaded in slot {slot_str}")
    return success


# --------------------------------------------------------------------------- #
#  Parallel Execution
# --------------------------------------------------------------------------- #

@dataclass
class DeviceResult:
    """Outcome of a parallel action on a single device."""
    device_label: str
    action: str
    success: bool
    tracker: _StepTracker
    results: dict[str, str] = field(default_factory=dict)


class _ParallelDisplay:
    """Combined live renderable showing per-step progress of all parallel actions."""

    def __init__(self, device_results: list[DeviceResult]) -> None:
        self._results = device_results
        self._spinner = Spinner("dots", style="cyan")

    def _step_icons(self, tracker: _StepTracker) -> Text:
        """Build a compact step progress line like: ✓ ✓ ● ○ ○ ○"""
        parts: list[tuple[str, str]] = []
        for i, s in enumerate(tracker.statuses):
            if s == "ok":
                parts.append(("✓", "green"))
            elif s == "fail":
                parts.append(("✗", "red"))
            elif s == "skip":
                parts.append(("–", "dim"))
            elif s == "active":
                parts.append(("●", "cyan bold"))
            else:
                parts.append(("○", "dim"))
        result = Text()
        for j, (char, style) in enumerate(parts):
            if j > 0:
                result.append(" ")
            result.append(char, style=style)
        return result

    def __rich__(self) -> Panel:
        outer = Table.grid(padding=(0, 0))
        outer.add_column()

        for dr in self._results:
            tracker = dr.tracker

            # Find active/last phase info
            active_detail = ""
            overall = "pending"
            for i, s in enumerate(tracker.statuses):
                if s == "active":
                    overall = "active"
                    active_detail = tracker.phases[i]
                    d = tracker.details[i]
                    if d:
                        active_detail += f" — {d}"
                    break
                elif s == "fail":
                    overall = "fail"
                    active_detail = tracker.phases[i]
                    d = tracker.details[i]
                    if d:
                        active_detail += f" — {d}"
                    break
            if overall == "pending" and all(
                s in ("ok", "skip") for s in tracker.statuses
            ):
                overall = "done"

            # Device header row with status icon
            row = Table.grid(padding=(0, 1))
            row.add_column(width=3)
            row.add_column(min_width=30)
            row.add_column()

            if overall == "active":
                icon: object = self._spinner
                label = Text.from_markup(
                    f"[bold cyan]{dr.device_label}[/bold cyan]"
                )
            elif overall == "fail":
                icon = Text.from_markup("[red]✗[/red]")
                label = Text.from_markup(
                    f"[red]{dr.device_label}[/red]"
                )
            elif overall == "done":
                icon = Text.from_markup("[green]✓[/green]")
                label = Text.from_markup(f"{dr.device_label}")
            else:
                icon = Text.from_markup("[dim]○[/dim]")
                label = Text.from_markup(f"[dim]{dr.device_label}[/dim]")

            steps = self._step_icons(tracker)
            row.add_row(icon, label, steps)
            outer.add_row(row)

            # Detail line showing current/last phase
            if active_detail:
                detail_style = "red" if overall == "fail" else "dim"
                outer.add_row(
                    Text.from_markup(f"    [{detail_style}]{active_detail}[/{detail_style}]")
                )
            elif overall == "done":
                outer.add_row(Text.from_markup("    [dim]Complete[/dim]"))
            else:
                outer.add_row(Text.from_markup("    [dim]Waiting…[/dim]"))

            # Spacer between devices
            outer.add_row(Text(""))

        return Panel(
            outer,
            title="[bold]Parallel Execution[/bold]",
            border_style="cyan",
            padding=(1, 2),
        )
