"""Interactive CLI console for Crestron processor provisioning."""

from __future__ import annotations

import os
import select
import sys
import time
from concurrent.futures import ThreadPoolExecutor

try:
    import termios
    import tty
    _HAS_TERMIOS = True
except ImportError:
    _HAS_TERMIOS = False

import questionary
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from .config import load_config, save_config
from .discovery import discover_devices, print_device_table
from .firmware import cache_info, clear_cache, download_firmware, download_firmware_quiet, find_local_firmware
from .models import Config, Device, NetworkConfig
from .provisioning import (
    DeviceResult,
    _ParallelDisplay,
    _StepTracker,
    provision_device,
    restore_device,
    upload_program,
)
from .ssh import CrestronFirstBoot
from .timezones import timezone_choices, timezone_label
from . import __version__

console = Console()


def _clear() -> None:
    """Clear the terminal screen."""
    os.system("cls" if os.name == "nt" else "clear")


def _load_animation() -> tuple[list, int]:
    """Load and parse the welcome animation JSON into frame data.

    Returns (frames, canvas_height) where frames is a list of
    (line_text, color_map) tuples, color_map is {(col, row): hex_color}.
    """
    import json
    from pathlib import Path

    try:
        # PyInstaller extracts data files to sys._MEIPASS
        base = Path(getattr(sys, "_MEIPASS", ""))
        anim_file = base / "crestron_setup" / "welcome_animation.json"
        if not anim_file.is_file():
            from importlib.resources import files

            anim_file = files("crestron_setup").joinpath("welcome_animation.json")
        data = json.loads(anim_file.read_text(encoding="utf-8"))
    except Exception:
        return [], 0

    canvas_height = data.get("canvas", {}).get("height", 22)
    frames = []
    for frame in data["frames"]:
        lines = frame["contentString"].split("\n")

        # Parse foreground color map
        fg_raw = frame.get("colors", {}).get("foreground", "{}")
        if isinstance(fg_raw, str):
            fg_map = json.loads(fg_raw)
        else:
            fg_map = fg_raw

        # Convert "x,y" keys to (x, y) tuples
        color_map: dict[tuple[int, int], str] = {}
        for key, color in fg_map.items():
            parts = key.split(",")
            color_map[(int(parts[0]), int(parts[1]))] = color

        frames.append((lines, color_map))

    return frames, canvas_height


def _render_frame(
    lines: list[str],
    color_map: dict[tuple[int, int], str],
    target_height: int = 0,
) -> Text:
    """Render a single animation frame as a Rich Text object with per-char colors."""
    result = Text()
    # Pad to target height so text below doesn't jump
    padded = list(lines)
    while target_height and len(padded) < target_height:
        padded.append("")
    for row, line in enumerate(padded):
        for col, char in enumerate(line):
            color = color_map.get((col, row))
            if color:
                result.append(char, style=color)
            else:
                result.append(char)
        if row < len(padded) - 1:
            result.append("\n")
    return result


def _key_pressed() -> bool:
    """Check if a key has been pressed (non-blocking)."""
    if not _HAS_TERMIOS:
        # Windows: use msvcrt if available
        try:
            import msvcrt
            return msvcrt.kbhit()
        except ImportError:
            return False
    try:
        return bool(select.select([sys.stdin], [], [], 0)[0])
    except Exception:
        return False


def _splash() -> None:
    """Show the animated welcome screen looping until any key is pressed."""
    _clear()

    frames, canvas_height = _load_animation()
    if not frames:
        # Fallback: simple text banner if animation file missing
        console.print(
            Panel(
                Text.assemble(
                    Text("Crestron Processor Setup", style="bold cyan"),
                    "  ",
                    Text(f"v{__version__}", style="dim"),
                ),
                border_style="cyan",
                padding=(0, 2),
            )
        )
        console.print()
        questionary.press_any_key_to_continue("Press any key to continue...").ask()
        return

    # Build the static info text shown below the animation
    info = Text.from_markup(
        f"\n[bold cyan]Crestron Processor Setup[/bold cyan]  [dim]v{__version__}[/dim]\n"
        "\n"
        "[dim]Automated provisioning tool for Crestron control processors.\n"
        "Configure settings in ~/.config/crestron-setup/config.yaml\n"
        "or create a config.yaml file in this directory.\n"
        "\n"
        "Press any key to continue…[/dim]"
    )

    # Switch terminal to cbreak mode so keypresses are immediate
    old_settings = None
    if _HAS_TERMIOS:
        fd = sys.stdin.fileno()
        try:
            old_settings = termios.tcgetattr(fd)
            tty.setcbreak(fd)
        except Exception:
            pass

    try:
        with Live(console=console, refresh_per_second=30, transient=True) as live:
            while True:
                for lines, color_map in frames:
                    if _key_pressed():
                        # Drain the keypress
                        try:
                            sys.stdin.read(1)
                        except Exception:
                            pass
                        return
                    rendered = _render_frame(lines, color_map, canvas_height)
                    rendered.append_text(info)
                    live.update(rendered)
                    time.sleep(1 / 30)
    finally:
        if old_settings is not None:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)


def _banner() -> None:
    """Print the application banner at the top of the screen."""
    title = Text("Crestron Processor Setup", style="bold cyan")
    subtitle = Text(f"v{__version__}", style="dim")
    console.print(
        Panel(
            Text.assemble(title, "  ", subtitle),
            border_style="cyan",
            padding=(0, 2),
        )
    )
    console.print()


def _header(section: str) -> None:
    """Clear screen and show banner + section header."""
    _clear()
    _banner()
    console.rule(f"[bold]{section}[/bold]")
    console.print()


def _pause() -> None:
    """Wait for user to press Enter before returning to menu."""
    console.print()
    questionary.press_any_key_to_continue("Press any key to continue...").ask()


def main() -> None:
    """Entry point for the Crestron setup console."""
    config = load_config()

    _splash()

    while True:
        _clear()
        _banner()

        choice = questionary.select(
            "Main Menu",
            choices=[
                questionary.Choice("Discover Devices", value="discover"),
                questionary.Choice("Setup Device (manual IP)", value="setup"),
                questionary.Choice("Upload Program", value="program"),
                questionary.Choice("Restore & Erase Device", value="restore"),
                questionary.Choice("Download Firmware", value="firmware"),
                questionary.Choice("Clear Firmware Cache", value="cache"),
                questionary.Choice("Settings", value="settings"),
                questionary.Choice("Exit", value="exit"),
            ],
        ).ask()

        if choice is None or choice == "exit":
            _clear()
            console.print("[dim]Goodbye.[/dim]")
            break
        elif choice == "discover":
            config = _flow_discover(config)
        elif choice == "setup":
            _flow_manual_setup(config)
        elif choice == "program":
            config = _flow_upload_program(config)
        elif choice == "restore":
            _flow_restore()
        elif choice == "firmware":
            _flow_firmware(config)
        elif choice == "cache":
            _flow_clear_cache()
        elif choice == "settings":
            config = _flow_settings(config)


# --------------------------------------------------------------------------- #
#  Discovery flow
# --------------------------------------------------------------------------- #


def _flow_discover(config: Config) -> Config:
    """Discover devices on the LAN, select an action, pick devices, and execute."""
    _header("Discover Devices")
    devices = discover_devices(config, console)

    if not devices:
        console.print("[yellow]No devices found.[/yellow] "
                      "Make sure you're on the same subnet and running with "
                      "elevated privileges (sudo).")
        _pause()
        return config

    # Check first-boot state for each device
    console.print("Checking first-boot state...")
    for dev in devices:
        dev.is_first_boot = CrestronFirstBoot.check_first_boot(dev.ip)

    _header("Discover Devices")
    print_device_table(devices, console)
    console.print()

    # Pick action first
    action = questionary.select(
        "What do you want to do?",
        choices=[
            questionary.Choice("Provision", value="provision"),
            questionary.Choice("Upload Program", value="program"),
            questionary.Choice("Restore & Erase", value="restore"),
            questionary.Choice("Back to Main Menu", value="back"),
        ],
    ).ask()

    if action is None or action == "back":
        return config

    # Select devices
    device_choices = [
        questionary.Choice(
            f"{dev.ip:<17} {dev.hostname:<20} {dev.model:<12} "
            f"{'[FIRST BOOT]' if dev.is_first_boot else ''}",
            value=i,
        )
        for i, dev in enumerate(devices)
    ]

    selected_indices = questionary.checkbox(
        "Select devices:",
        choices=device_choices,
    ).ask()

    if not selected_indices:
        console.print("[dim]No devices selected.[/dim]")
        _pause()
        return config

    selected_devices = [devices[i] for i in selected_indices]

    # Get credentials (all actions need them)
    creds = _prompt_credentials()
    if not creds:
        return config
    username, password = creds

    # Gather action-specific inputs before starting parallel execution
    program_path: str = ""
    slot: int = 1

    if action == "provision":
        # Network configuration per device
        if len(selected_devices) == 1:
            net = _prompt_network_config(selected_devices[0].ip)
            if net:
                selected_devices[0].network = net
        else:
            net_mode = questionary.select(
                "Network configuration:",
                choices=[
                    questionary.Choice("Skip (keep DHCP on all)", value="skip"),
                    questionary.Choice("Configure each device individually", value="each"),
                ],
            ).ask()
            if net_mode == "each":
                for dev in selected_devices:
                    net = _prompt_network_config(dev.ip)
                    if net:
                        dev.network = net

        # Check firmware availability for unique models
        models_with_url: set[str] = set()
        for dev in selected_devices:
            if dev.model and config.firmware_urls.get(dev.model.upper()):
                models_with_url.add(dev.model.upper())

        if models_with_url:
            # Show current local firmware status per model
            for mdl in sorted(models_with_url):
                fw_path, fw_ver = find_local_firmware(mdl, config)
                if fw_path:
                    console.print(
                        f"[cyan][INFO][/cyan] {mdl}: local firmware {fw_path.name} (v{fw_ver})"
                    )
                else:
                    console.print(
                        f"[cyan][INFO][/cyan] {mdl}: no local firmware found"
                    )

            dl = questionary.confirm(
                "Check for latest firmware from download URL?", default=True,
            ).ask()
            if dl:
                for mdl in sorted(models_with_url):
                    console.print()
                    download_firmware(mdl, config, console)
                console.print()

    elif action == "program":
        default_path = config.last_program_file or ""
        program_path = questionary.path(
            "Program file path:",
            default=default_path,
        ).ask()
        if not program_path:
            return config

        slot_input = questionary.text("Program slot:", default="1").ask()
        if not slot_input:
            return config
        try:
            slot = int(slot_input)
            if slot < 1:
                raise ValueError
        except ValueError:
            console.print("[red]Invalid slot number.[/red]")
            _pause()
            return config

        config.last_program_file = program_path
        save_config(config)

    elif action == "restore":
        device_list = ", ".join(d.ip or d.hostname for d in selected_devices)
        console.print(f"\n[yellow][WARN][/yellow] This will erase all settings and "
                      f"programs on: {device_list}\n")
        confirm = questionary.confirm(
            "Are you sure you want to erase and restore these devices?",
            default=False,
        ).ask()
        if not confirm:
            console.print("[dim]Cancelled.[/dim]")
            _pause()
            return config

    # ── Single device: run normally with full display ──────────────────
    if len(selected_devices) == 1:
        dev = selected_devices[0]
        if action == "provision":
            provision_device(dev, username, password, config, console)
        elif action == "program":
            host = dev.ip or dev.hostname
            upload_program(host, username, password, program_path, slot, console)
        elif action == "restore":
            restore_device(dev, username, password, console)
        _pause()
        return config

    # ── Multiple devices: run in parallel with combined display ────────
    device_results = _run_parallel(
        action, selected_devices, username, password,
        config, program_path, slot,
    )
    _show_parallel_summary(device_results, config)
    return config


# --------------------------------------------------------------------------- #
#  Parallel execution helpers
# --------------------------------------------------------------------------- #


def _run_parallel(
    action: str,
    devices: list[Device],
    username: str,
    password: str,
    config: Config,
    program_path: str = "",
    slot: int = 1,
) -> list[DeviceResult]:
    """Run an action on multiple devices in parallel with a combined live display."""
    # Pre-create DeviceResult entries with placeholder trackers for display
    device_results: list[DeviceResult] = []
    for dev in devices:
        ip = dev.ip or dev.hostname
        label = f"{ip}  {dev.hostname}" if dev.hostname and dev.hostname != ip else ip
        if dev.model:
            label += f"  ({dev.model})"
        if action == "provision":
            from .provisioning import PHASE_NAMES
            tracker = _StepTracker(label, list(PHASE_NAMES))
        elif action == "program":
            from .provisioning import PROGRAM_PHASE_NAMES
            tracker = _StepTracker(label, list(PROGRAM_PHASE_NAMES))
        else:  # restore
            from .provisioning import RESTORE_PHASE_NAMES
            tracker = _StepTracker(label, list(RESTORE_PHASE_NAMES))
        device_results.append(DeviceResult(
            device_label=label, action=action, success=False, tracker=tracker,
        ))

    display = _ParallelDisplay(device_results)

    def _worker(dev: Device, dr: DeviceResult) -> None:
        """Thread worker — runs action headlessly using dr.tracker for live updates."""
        host = dev.ip or dev.hostname
        if action == "provision":
            result = provision_device(
                dev, username, password, config, console,
                headless=True, tracker=dr.tracker,
            )
            dr.success, _, dr.results = result  # type: ignore[misc]
        elif action == "program":
            result = upload_program(
                host, username, password, program_path, slot, console,
                headless=True, tracker=dr.tracker,
            )
            dr.success = result[0]  # type: ignore[index]
        elif action == "restore":
            result = restore_device(
                dev, username, password, console,
                headless=True, tracker=dr.tracker,
            )
            dr.success = result[0]  # type: ignore[index]

    _clear()
    with Live(display, console=console, refresh_per_second=8) as live:
        with ThreadPoolExecutor(max_workers=len(devices)) as pool:
            futures = [
                pool.submit(_worker, dev, dr)
                for dev, dr in zip(devices, device_results)
            ]
            # Poll until all futures complete, refreshing display continuously
            while not all(f.done() for f in futures):
                live.update(display)
                time.sleep(0.25)
        live.update(display)

    return device_results


def _show_parallel_summary(
    device_results: list[DeviceResult],
    config: Config,
) -> None:
    """Show a summary table and let the user drill into individual results."""
    while True:
        _clear()
        _banner()

        # Summary table
        all_ok = all(dr.success for dr in device_results)
        title = ("[bold green]All Devices Complete[/bold green]" if all_ok
                 else "[bold yellow]Results Summary[/bold yellow]")
        border = "green" if all_ok else "yellow"

        table = Table(show_header=True, padding=(0, 1))
        table.add_column("#", style="dim", width=3)
        table.add_column("Device", style="cyan", min_width=18)
        table.add_column("Action", min_width=12)
        table.add_column("Result", min_width=10)
        table.add_column("Details", min_width=30)

        for i, dr in enumerate(device_results):
            status = "[green]✓ OK[/green]" if dr.success else "[red]✗ Failed[/red]"
            # Get last phase detail
            detail = ""
            for j in range(len(dr.tracker.statuses) - 1, -1, -1):
                s = dr.tracker.statuses[j]
                if s in ("ok", "fail", "skip"):
                    detail = dr.tracker.details[j] or dr.tracker.phases[j]
                    if s == "fail":
                        detail = f"[red]{detail}[/red]"
                    break
            table.add_row(str(i + 1), dr.device_label, dr.action.title(), status, detail)

        console.print(Panel(table, title=title, border_style=border, padding=(1, 2)))
        console.print()

        # Drill-down menu
        choices = [
            questionary.Choice(
                f"{dr.device_label} — {'OK' if dr.success else 'FAILED'}",
                value=i,
            )
            for i, dr in enumerate(device_results)
        ]
        choices.append(questionary.Choice("Back to Main Menu", value=-1))

        pick = questionary.select(
            "View details for a device:",
            choices=choices,
        ).ask()

        if pick is None or pick == -1:
            return

        # Show detailed tracker for selected device
        dr = device_results[pick]
        _clear()
        _banner()

        success_label = "[bold green]Success[/bold green]" if dr.success else "[bold red]Failed[/bold red]"
        console.print(
            Panel(
                dr.tracker.render_static(),
                title=f"{dr.device_label} — {success_label}",
                border_style="green" if dr.success else "red",
                padding=(1, 2),
            )
        )
        console.print()
        _pause()


# --------------------------------------------------------------------------- #
#  Manual setup flow
# --------------------------------------------------------------------------- #


def _flow_manual_setup(config: Config) -> None:
    """Provision a single device by IP/hostname."""
    _header("Setup Device")
    host = questionary.text("Processor hostname or IP:").ask()
    if not host:
        return

    creds = _prompt_credentials()
    if not creds:
        return
    username, password = creds

    device = Device(ip=host)

    # Quick first-boot check
    console.print("Checking first-boot state...")
    device.is_first_boot = CrestronFirstBoot.check_first_boot(host)
    if device.is_first_boot:
        console.print("[cyan][INFO][/cyan] Device appears to be in first-boot mode.")

    # Network configuration
    net = _prompt_network_config(host)
    if net:
        device.network = net

    provision_device(device, username, password, config, console)
    _pause()


# --------------------------------------------------------------------------- #
#  Upload Program flow
# --------------------------------------------------------------------------- #


def _flow_upload_program(config: Config) -> Config:
    """Upload a program file to a processor and load it."""
    _header("Upload Program")

    host = questionary.text("Processor hostname or IP:").ask()
    if not host:
        return config

    username = questionary.text("Admin username:").ask()
    if not username:
        return config

    password = questionary.password("Admin password:").ask()
    if not password:
        return config

    default_path = config.last_program_file or ""
    program_path = questionary.path(
        "Program file path:",
        default=default_path,
    ).ask()
    if not program_path:
        return config

    slot_input = questionary.text("Program slot:", default="1").ask()
    if not slot_input:
        return config
    try:
        slot = int(slot_input)
        if slot < 1:
            raise ValueError
    except ValueError:
        console.print("[red]Invalid slot number.[/red]")
        _pause()
        return config

    # Remember the program file for next time
    config.last_program_file = program_path
    save_config(config)

    upload_program(host, username, password, program_path, slot, console)
    _pause()
    return config


# --------------------------------------------------------------------------- #
#  Restore & Erase flow
# --------------------------------------------------------------------------- #


def _flow_restore() -> None:
    """Restore a device to factory defaults (initialize + restore)."""
    _header("Restore & Erase Device")
    console.print("[yellow][WARN][/yellow] This will erase all settings and programs "
                  "and restore the device to factory defaults.\n")

    host = questionary.text("Processor hostname or IP:").ask()
    if not host:
        return

    username = questionary.text("Admin username:").ask()
    if not username:
        return

    password = questionary.password("Admin password:").ask()
    if not password:
        return

    confirm = questionary.confirm(
        f"Are you sure you want to erase and restore {host}?",
        default=False,
    ).ask()
    if not confirm:
        console.print("[dim]Cancelled.[/dim]")
        _pause()
        return

    device = Device(ip=host)
    restore_device(device, username, password, console)
    _pause()


# --------------------------------------------------------------------------- #
#  Firmware download flow
# --------------------------------------------------------------------------- #


def _flow_firmware(config: Config) -> None:
    """Download firmware for a specific model."""
    _header("Download Firmware")
    available = list(config.firmware_urls.keys())
    if not available:
        console.print(
            "[yellow]No firmware URLs configured.[/yellow]\n"
            "Add entries under firmware_urls in your config.yaml.\n"
            "See config.example.yaml for the format."
        )
        _pause()
        return

    model = questionary.select(
        "Select model to download firmware for:",
        choices=available + ["Cancel"],
    ).ask()

    if not model or model == "Cancel":
        return

    # Check for existing local firmware first
    fw_path, fw_version = find_local_firmware(model, config)
    if fw_path:
        console.print(f"[cyan][INFO][/cyan] Local firmware found: {fw_path.name} (v{fw_version})")
        if not questionary.confirm("Download anyway?", default=False).ask():
            return

    download_firmware(model, config, console)
    _pause()


# --------------------------------------------------------------------------- #
#  Clear firmware cache flow
# --------------------------------------------------------------------------- #


def _flow_clear_cache() -> None:
    """Show cached firmware files and let the user delete them."""
    _header("Clear Firmware Cache")
    cache_dir, files = cache_info()

    if not files:
        console.print("[dim]Firmware cache is empty.[/dim]")
        console.print(f"[dim]Cache directory: {cache_dir}[/dim]")
        _pause()
        return

    total_size = sum(s for _, s in files)
    console.print(f"[bold]Cache directory:[/bold] {cache_dir}")
    console.print(f"[bold]Total size:[/bold] {total_size / 1_048_576:.1f} MB "
                  f"({len(files)} file{'s' if len(files) != 1 else ''})\n")

    choices = [
        questionary.Choice(
            f"{f.name}  ({size / 1_048_576:.1f} MB)",
            value=i,
        )
        for i, (f, size) in enumerate(files)
    ]

    action = questionary.select(
        "What to clear?",
        choices=[
            questionary.Choice("Delete all cached files", value="all"),
            questionary.Choice("Select files to delete", value="pick"),
            questionary.Choice("Cancel", value="cancel"),
        ],
    ).ask()

    if action is None or action == "cancel":
        return

    if action == "all":
        confirm = questionary.confirm(
            f"Delete all {len(files)} cached files ({total_size / 1_048_576:.1f} MB)?",
            default=False,
        ).ask()
        if confirm:
            count = clear_cache()
            console.print(f"[green][OK][/green] Deleted {count} file(s).")
    else:
        selected = questionary.checkbox(
            "Select files to delete:",
            choices=choices,
        ).ask()
        if selected:
            paths = [files[i][0] for i in selected]
            count = clear_cache(paths)
            console.print(f"[green][OK][/green] Deleted {count} file(s).")
        else:
            console.print("[dim]No files selected.[/dim]")

    _pause()


# --------------------------------------------------------------------------- #
#  Settings flow
# --------------------------------------------------------------------------- #


def _flow_settings(config: Config) -> Config:
    """View and edit configuration."""
    while True:
        _header("Settings")
        console.print("[bold]Current Settings[/bold]")
        console.print(f"  Timezone:            {config.timezone} — {timezone_label(config.timezone)}")
        console.print(f"  NTP Server:          {config.ntp_server}")
        console.print(f"  Public Key:          {config.pubkey_file}")
        console.print(f"  Firmware Directory:  {config.firmware_dir}")
        console.print(f"  Web Port:            {config.web_port}")
        console.print(f"  Secure Web Port:     {config.secure_web_port}")
        console.print(f"  FIPS Mode:           {config.fips_mode}")
        console.print(f"  Firmware URLs:       {len(config.firmware_urls)} configured")
        console.print()

        action = questionary.select(
            "Settings",
            choices=[
                questionary.Choice("Edit a setting", value="edit"),
                questionary.Choice("Add firmware URL", value="add_fw"),
                questionary.Choice("Save to disk", value="save"),
                questionary.Choice("Back to main menu", value="back"),
            ],
        ).ask()

        if action is None or action == "back":
            return config
        elif action == "edit":
            config = _edit_setting(config)
        elif action == "add_fw":
            config = _add_firmware_url(config)
        elif action == "save":
            path = save_config(config)
            console.print(f"[green][OK][/green] Config saved to {path}")

    return config


def _edit_setting(config: Config) -> Config:
    """Edit a single config setting."""
    field = questionary.select(
        "Which setting?",
        choices=[
            questionary.Choice("Timezone", value="timezone"),
            questionary.Choice("NTP Server", value="ntp_server"),
            questionary.Choice("Public Key File", value="pubkey_file"),
            questionary.Choice("Firmware Directory", value="firmware_dir"),
            questionary.Choice("Web Port", value="web_port"),
            questionary.Choice("Secure Web Port", value="secure_web_port"),
            questionary.Choice("FIPS Mode", value="fips_mode"),
            questionary.Choice("Cancel", value="cancel"),
        ],
    ).ask()

    if not field or field == "cancel":
        return config

    if field == "timezone":
        return _pick_timezone(config)

    current = getattr(config, field)
    new_value = questionary.text(
        f"{field}:", default=str(current)
    ).ask()

    if new_value is not None:
        if field in ("web_port", "secure_web_port"):
            setattr(config, field, int(new_value))
        else:
            setattr(config, field, new_value)

    return config


def _pick_timezone(config: Config) -> Config:
    """Interactive timezone picker with type-to-filter."""
    choices = [
        questionary.Choice(label, value=tz_id)
        for tz_id, label in timezone_choices()
    ]
    current = config.timezone.zfill(3)
    # Find the matching choice to set as default
    default = None
    for c in choices:
        if c.value == current:
            default = c.value
            break

    result = questionary.select(
        "Select timezone (type to filter):",
        choices=choices,
        default=default,
        use_shortcuts=False,
    ).ask()

    if result is not None:
        config.timezone = result
    return config


def _add_firmware_url(config: Config) -> Config:
    """Add or update a firmware download URL."""
    model = questionary.text("Model name (e.g., CP4, MC4):").ask()
    if not model:
        return config

    url = questionary.text("Firmware download URL:").ask()
    if not url:
        return config

    auth_header = questionary.text(
        "Authorization header (optional, e.g., Bearer TOKEN):",
        default="",
    ).ask()

    from .models import FirmwareSource

    headers = {}
    if auth_header:
        headers["Authorization"] = auth_header

    config.firmware_urls[model.upper()] = FirmwareSource(url=url, headers=headers)
    console.print(f"[green][OK][/green] Firmware URL added for {model.upper()}")
    return config


# --------------------------------------------------------------------------- #
#  Helpers
# --------------------------------------------------------------------------- #


def _prompt_credentials() -> tuple[str, str] | None:
    """Prompt for admin username and password."""
    username = questionary.text("Admin username:").ask()
    if not username:
        return None

    password = questionary.password("Admin password:").ask()
    if not password:
        return None

    confirm = questionary.password("Confirm password:").ask()
    if password != confirm:
        console.print("[red]Passwords do not match.[/red]")
        return None

    return username, password


def _prompt_network_config(device_label: str = "") -> NetworkConfig | None:
    """Prompt for network configuration (DHCP or static IP)."""
    prefix = f"[{device_label}] " if device_label else ""

    mode = questionary.select(
        f"{prefix}IP address mode:",
        choices=[
            questionary.Choice("DHCP (no changes needed)", value="dhcp"),
            questionary.Choice("Static IP", value="static"),
            questionary.Choice("Skip network config", value="skip"),
        ],
    ).ask()

    if mode is None or mode == "skip":
        return None

    new_hostname = questionary.text(
        f"{prefix}Hostname (blank to skip):", default=""
    ).ask()

    if mode == "dhcp":
        return NetworkConfig(mode="dhcp", hostname=new_hostname or "")

    ip = questionary.text(f"{prefix}IP address:").ask()
    if not ip:
        return None

    mask = questionary.text(
        f"{prefix}Subnet mask:", default="255.255.255.0"
    ).ask()
    if not mask:
        return None

    gw = questionary.text(f"{prefix}Default gateway:").ask()
    if not gw:
        return None

    dns_input = questionary.text(
        f"{prefix}DNS servers (comma-separated, or blank to skip):",
        default="",
    ).ask()

    dns_servers = [s.strip() for s in (dns_input or "").split(",") if s.strip()]

    return NetworkConfig(
        mode="static",
        hostname=new_hostname or "",
        ip_address=ip,
        subnet_mask=mask,
        gateway=gw,
        dns_servers=dns_servers,
    )
