"""Status command: show project status summary."""

import json as _json
import os
import sys

from ..targets import TARGETS
from ..utils import (
    extract_changelog_entry,
    get_current_branch,
    is_clean_tree,
    run,
)
from ..workspace import find_workspace_root, load_workspace, resolve_project


def _collect_status(registry):
    """Collect status data as a dict.

    Returns None and prints an error if the project does not exist.
    """
    reg = TARGETS[registry]

    if not reg.check_project_exists("."):
        print(f"No {registry} project found in current directory.", file=sys.stderr)
        sys.exit(1)

    version = reg.read_version(".")
    vars_dict = reg.get_template_vars(".")
    name = vars_dict.get("name") or "(unknown)"

    # Git branch
    try:
        branch = get_current_branch()
    except Exception:
        branch = None

    # Last tag
    try:
        tag = run("git", ["describe", "--tags", "--abbrev=0"])
    except Exception:
        tag = None

    # Clean tree
    try:
        clean = is_clean_tree()
    except Exception:
        clean = None

    # Changelog
    changelog_path = "CHANGELOG.md"
    if os.path.exists(changelog_path):
        entry = extract_changelog_entry(changelog_path, version)
        changelog = bool(entry)
    else:
        changelog = None

    # CI workflows
    ci = os.path.exists(".github/workflows/ci.yml")
    publish = os.path.exists(".github/workflows/publish.yml") or os.path.exists(
        ".github/workflows/workflow.yml"
    )

    return {
        "name": name,
        "version": version,
        "target": registry,
        "branch": branch,
        "tag": tag,
        "clean": clean,
        "changelog": changelog,
        "ci": ci,
        "publish": publish,
    }


def run_cmd(registry, args, flags):
    """Status command handler.

    Shows a quick 'where am I' summary: package info, git state, changelog, CI.
    With --json, outputs machine-readable JSON instead.
    """
    data = _collect_status(registry)

    if flags.get("json"):
        print(_json.dumps(data, indent=2))
        return

    print(f"Package:   {data['name']}")

    # Show version info for all detected registries
    for r_name, r_mod in TARGETS.items():
        if r_mod.check_project_exists("."):
            ver = r_mod.read_version(".")
            file = r_mod.get_version_file() or "git tag"
            print(f"Version:   {ver} ({r_name}, {file})")

    # Git info
    if data["branch"] is not None:
        print(f"Branch:    {data['branch']}")
    else:
        print("Branch:    (not a git repo)")

    # Last tag
    if data["tag"] is not None:
        print(f"Last tag:  {data['tag']}")
    else:
        print("Last tag:  (none)")

    # Clean tree
    if data["clean"] is not None:
        print(f"Clean:     {'yes' if data['clean'] else 'no'}")
    else:
        print("Clean:     (unknown)")

    # Changelog
    if data["changelog"] is None:
        print("Changelog: (not found)")
    elif data["changelog"]:
        print(f"Changelog: has entry for {data['version']}")
    else:
        print(f"Changelog: no entry for {data['version']}")

    # CI workflows
    print(f"CI:        {'yes' if data['ci'] else 'missing'}")
    print(f"Publish:   {'yes' if data['publish'] else 'missing'}")

    # Monorepo awareness
    try:
        ws_root = find_workspace_root(".")
        if ws_root is not None:
            projects = load_workspace(ws_root)
            project = resolve_project(ws_root, ".")
            if project is not None:
                mono_tag = f"{project['name']}@v{data['version']}"
                print(f"Mono tag:  {mono_tag}")
            count = len(projects)
            print(f"Part of monorepo ({count} project{'s' if count != 1 else ''}). Run 'rlsbl monorepo status' for all.")
    except Exception:
        pass
