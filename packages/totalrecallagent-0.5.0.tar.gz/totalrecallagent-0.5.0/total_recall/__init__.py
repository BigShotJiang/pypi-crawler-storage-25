"""
Total Recall — On-chain memory infrastructure for AI agents.
https://www.totalrecallagent.com
"""

from .client    import TotalRecallClient, TotalRecallError, MemoryEntry, SpaceClient, SpaceError
from .templates import MemoryTemplate, TemplateField, BUILT_IN_TEMPLATES

__all__ = [
    "TotalRecallClient",
    "TotalRecallError",
    "MemoryEntry",
    "SpaceClient",
    "SpaceError",
    "MemoryTemplate",
    "TemplateField",
    "BUILT_IN_TEMPLATES",
]
__version__ = "0.5.0"
