"""telegram-slskd-local-bot - Automated music discovery and download via Telegram bot."""

__version__ = "0.7.1"
