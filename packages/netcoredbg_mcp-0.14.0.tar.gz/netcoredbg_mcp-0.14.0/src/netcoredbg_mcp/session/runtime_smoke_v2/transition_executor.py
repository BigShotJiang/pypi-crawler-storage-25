from __future__ import annotations

import asyncio
import inspect
from typing import Any

from .actions import ActionContext, dispatch_action
from .diff import compute_diff
from .metrics import capture_metric_snapshot, finish_transition_metrics
from .probe_dispatcher import ProbeContext, dispatch_probe, probe_path

DEFAULT_IDLE_MS = 250
DEFAULT_TRACEPOINT_TIMEOUT_MS = 2000
TRACEPOINT_POLL_MS = 50


async def execute_transition(
    transition: dict[str, Any],
    action_context: ActionContext,
) -> tuple[dict[str, Any], int]:
    probes = [dict(probe) for probe in transition.get("probes", [])]
    probe_context = ProbeContext(action_context=action_context)
    before_results = await _collect_probe_results(probes, probe_context, phase="before")
    before = _probe_value_map(probes, before_results)

    action = dict(transition.get("action") or {})
    metrics_started = capture_metric_snapshot(action_context)
    action_result = await dispatch_action(action, action_context)
    action_count = 1
    actions = [action_result]
    if action_result.get("status") != "PASS":
        status = _status_from_records([action_result])
        reason = str(action_result.get("reason") or "action failed")
        result = {
            "id": transition.get("id"),
            "status": status,
            "reason": reason,
            "actions": actions,
            "metrics": finish_transition_metrics(metrics_started, action_context),
            "before": before,
            "after": {},
            "diff": {},
            "probes": {"before": before_results, "after": []},
        }
        if status == "BLOCKED":
            result["blocked"] = _blocked_from_record(action_result)
        return result, action_count

    settle = await _settle(dict(transition.get("settle") or {}), action_context)
    metrics = finish_transition_metrics(metrics_started, action_context)
    if settle.get("status") != "PASS":
        status = _status_from_records([*before_results, settle])
        reason = _reason_from_records([settle, *before_results])
        return (
            {
                "id": transition.get("id"),
                "status": status,
                "reason": reason,
                "actions": actions,
                "metrics": metrics,
                "settle": settle,
                "before": before,
                "after": {},
                "diff": {},
                "probes": {"before": before_results, "after": []},
                **({"blocked": _blocked_from_record(settle)} if status == "BLOCKED" else {}),
            },
            action_count,
        )
    after_results = await _collect_probe_results(probes, probe_context, phase="after")
    after = _probe_value_map(probes, after_results)
    diff = compute_diff(before=before, after=after)

    status = _status_from_records([*before_results, *after_results, settle])
    reason = _reason_from_records([*after_results, *before_results, settle])
    blocked_record = _find_blocked_record([*before_results, *after_results])
    return (
        {
            "id": transition.get("id"),
            "status": status,
            "reason": reason,
            "actions": actions,
            "metrics": metrics,
            "settle": settle,
            "before": before,
            "after": after,
            "diff": diff,
            "probes": {"before": before_results, "after": after_results},
            **({"blocked": _blocked_from_record(blocked_record)} if status == "BLOCKED" else {}),
        },
        action_count,
    )


async def _collect_probe_results(
    probes: list[dict[str, Any]],
    context: ProbeContext,
    *,
    phase: str,
) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    for probe in probes:
        result = await dispatch_probe(probe, context, phase=phase)
        result["path"] = probe_path(probe)
        results.append(result)
    return results


def _probe_value_map(
    probes: list[dict[str, Any]],
    results: list[dict[str, Any]],
) -> dict[str, Any]:
    return {
        probe_path(probe): result.get("value")
        for probe, result in zip(probes, results, strict=True)
    }


async def _settle(
    settle: dict[str, Any],
    context: ActionContext,
) -> dict[str, Any]:
    tracepoint_id = settle.get("await_tracepoint_id")
    if tracepoint_id:
        timeout_ms = int(settle.get("tracepoint_timeout_ms", DEFAULT_TRACEPOINT_TIMEOUT_MS))
        deadline = context.clock() + (timeout_ms / 1000)
        while context.clock() <= deadline:
            result = await context.call_adapter(
                "debug.tracepoint_status",
                tracepoint_id=str(tracepoint_id),
            )
            if result.get("status") == "PASS" and result.get("hit") is True:
                return {
                    "status": "PASS",
                    "await_tracepoint_id": str(tracepoint_id),
                    "tracepoint_timeout_ms": timeout_ms,
                }
            if context.clock() >= deadline:
                break
            await _sleep_ms(context, TRACEPOINT_POLL_MS)
        return {
            "status": "BLOCKED",
            "reason": "settle condition not met",
            "await_tracepoint_id": str(tracepoint_id),
            "tracepoint_timeout_ms": timeout_ms,
        }

    idle_ms = int(settle.get("idle_ms", DEFAULT_IDLE_MS))
    await _sleep_ms(context, idle_ms)
    return {"status": "PASS", "idle_ms": idle_ms}


async def _sleep_ms(context: ActionContext, idle_ms: int) -> None:
    sleeper = getattr(context.clock, "sleep_ms", None)
    if callable(sleeper):
        result = sleeper(idle_ms)
        if inspect.isawaitable(result):
            await result
        return
    await asyncio.sleep(idle_ms / 1000)


def _status_from_records(records: list[dict[str, Any]]) -> str:
    statuses = [str(record.get("status", "PASS")) for record in records]
    if "FAIL" in statuses:
        return "FAIL"
    if "BLOCKED" in statuses:
        return "BLOCKED"
    if "IMPASSE" in statuses:
        return "IMPASSE"
    return "PASS"


def _reason_from_records(records: list[dict[str, Any]]) -> str:
    for preferred_status in ("FAIL", "BLOCKED", "IMPASSE"):
        for record in records:
            if record.get("status") == preferred_status:
                return str(record.get("reason") or preferred_status.lower())
    return "transition passed"


def _blocked_from_record(record: dict[str, Any]) -> dict[str, Any]:
    return {
        "reason": str(record.get("reason") or "blocked"),
        "requested": dict(record.get("requested") or {}),
        "accepted": dict(record.get("accepted") or {}),
        "next_step": str(record.get("next_step") or "Inspect the blocked transition."),
    }


def _find_blocked_record(records: list[dict[str, Any]]) -> dict[str, Any]:
    for record in records:
        if record.get("status") == "BLOCKED":
            return record
    return {}
