package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"path/filepath"

	tea "github.com/charmbracelet/bubbletea"

	"jaca/internal/jaca/app"
	"jaca/internal/jaca/config"
	"jaca/internal/jaca/rpc"
)

func main() {
	if err := run(); err != nil {
		fmt.Fprintf(os.Stderr, "jaca: %v\n", err)
		os.Exit(1)
	}
}

func run() error {
	cfg, err := config.Load()
	if err != nil {
		return err
	}
	config.ApplyToEnv(cfg)
	if err := config.ApplyTraceModeToEnv(cfg["trace_mode"]); err != nil {
		return err
	}

	defaultModel := resolveDefaultModel(cfg)

	model := flag.String("model", defaultModel, "Model to use")
	workspaceRoot := flag.String("workspace-root", ".", "Workspace root directory")
	sessionsRoot := flag.String("sessions-root", "", "Sessions storage directory")
	sessionID := flag.String("session-id", "", "Existing session id to resume")
	sessionName := flag.String("session-name", "", "Resolved human session name for the resumed session")
	forkedFromSessionID := flag.String("forked-from-session-id", "", "Parent session id for a forked session")
	forkedFromSessionName := flag.String("forked-from-session-name", "", "Resolved human parent session name for a forked session")
	thinking := flag.String("thinking", "", "Thinking level")
	backendCommandJSON := flag.String("backend-command-json", "", "JSON array command used to start the canonical headless backend")
	appVersion := flag.String("app-version", "", "Installed JACA package version")
	flag.Parse()
	if *model == "" {
		return fmt.Errorf("missing model; launch via the installed jaca wrapper or set JACA_MODEL/default_model")
	}

	backendCommand, err := parseBackendCommandJSON(*backendCommandJSON)
	if err != nil {
		return err
	}

	absWorkspace, err := filepath.Abs(*workspaceRoot)
	if err != nil {
		return err
	}
	resolvedSessionsRoot, err := resolveSessionsRoot(*sessionsRoot)
	if err != nil {
		return err
	}

	manager := rpc.NewManager(rpc.BackendConfig{
		Model:         *model,
		WorkspaceRoot: absWorkspace,
		SessionsRoot:  resolvedSessionsRoot,
		Command:       backendCommand,
		Env:           os.Environ(),
	})
	defer func() {
		_ = manager.Shutdown(context.Background())
	}()

	program := tea.NewProgram(
		app.New(app.Options{
			AppVersion:            *appVersion,
			Model:                 *model,
			WorkspaceRoot:         absWorkspace,
			SessionsRoot:          resolvedSessionsRoot,
			SessionID:             *sessionID,
			SessionName:           *sessionName,
			ForkedFromSessionID:   *forkedFromSessionID,
			ForkedFromSessionName: *forkedFromSessionName,
			Thinking:              normalizeThinking(*thinking),
			Backend:               manager,
		}),
		tea.WithAltScreen(),
		tea.WithMouseCellMotion(),
	)
	_, err = program.Run()
	return err
}

func resolveDefaultModel(cfg map[string]string) string {
	defaultModel := os.Getenv("JACA_MODEL")
	if defaultModel != "" {
		return defaultModel
	}
	if value := cfg["default_model"]; value != "" {
		return value
	}
	return ""
}

func resolveSessionsRoot(raw string) (string, error) {
	if raw == "" {
		home, err := os.UserHomeDir()
		if err != nil {
			return "", err
		}
		raw = filepath.Join(home, ".jaca", "sessions")
	}
	resolved, err := filepath.Abs(raw)
	if err != nil {
		return "", err
	}
	if err := os.MkdirAll(resolved, 0o755); err != nil {
		return "", err
	}
	return resolved, nil
}

func normalizeThinking(raw string) string {
	switch raw {
	case "", "true", "false", "minimal", "low", "medium", "high", "xhigh":
		return raw
	default:
		return ""
	}
}

func parseBackendCommandJSON(raw string) ([]string, error) {
	if raw == "" {
		return nil, fmt.Errorf("missing --backend-command-json; launch via the installed jaca wrapper or pass an explicit backend command")
	}
	var command []string
	if err := json.Unmarshal([]byte(raw), &command); err != nil {
		return nil, fmt.Errorf("invalid --backend-command-json: %w", err)
	}
	if len(command) == 0 {
		return nil, fmt.Errorf("invalid --backend-command-json: command cannot be empty")
	}
	for _, part := range command {
		if part == "" {
			return nil, fmt.Errorf("invalid --backend-command-json: command parts cannot be empty")
		}
	}
	return command, nil
}
