"""Persistent runtime configuration stored at ~/.jaca/config.json."""

from __future__ import annotations

import json
import os
from pathlib import Path

from just_another_coding_agent.contracts.model_catalog import default_model_for_provider

CONFIG_DIR = Path.home() / ".jaca"
CONFIG_PATH = CONFIG_DIR / "config.json"
DEFAULT_MODEL = default_model_for_provider("openai")


def load_config() -> dict[str, str]:
    if not CONFIG_PATH.exists():
        return {}
    try:
        return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def apply_config_to_env(config: dict[str, str]) -> None:
    env_keys = {
        "OPENAI_BASE_URL",
    }
    for key in env_keys:
        if key in config and key not in os.environ:
            os.environ[key] = config[key]


def apply_trace_mode_to_env(config: dict[str, str]) -> None:
    trace_mode = config.get("trace_mode", "").strip().lower()
    if trace_mode in {"", "off"}:
        os.environ.pop("JACA_TRACE_MODE", None)
        return
    if trace_mode in {"local", "logfire"}:
        os.environ["JACA_TRACE_MODE"] = trace_mode
        return
    raise RuntimeError(
        "Invalid trace_mode in ~/.jaca/config.json: expected off, local, or logfire"
    )


def resolve_default_model(config: dict[str, str]) -> str:
    env_model = os.environ.get("JACA_MODEL", "").strip()
    if env_model:
        return env_model
    saved_model = config.get("default_model", "").strip()
    if saved_model:
        return saved_model
    return DEFAULT_MODEL
__all__ = [
    "apply_config_to_env",
    "apply_trace_mode_to_env",
    "DEFAULT_MODEL",
    "load_config",
    "resolve_default_model",
]
