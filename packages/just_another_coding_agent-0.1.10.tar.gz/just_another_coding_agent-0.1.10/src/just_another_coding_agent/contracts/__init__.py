"""Canonical contract package."""
