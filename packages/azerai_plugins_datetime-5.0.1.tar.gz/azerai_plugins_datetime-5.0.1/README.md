# 🕐 AzerAI DateTime Plugin

**AzerAI** - Azərbaycan dilində qabaqcıl səsli AI asistent tarix və zaman üçün plugin

## Xüsusiyyətlər

- 🕐 **Cari vaxt** - Azərbaycan vaxt zonasında (UTC+4)
- 📅 **Cari tarix** - Tam tarix məlumatları
- 🌍 **Azərbaycan dilində** - Bütün məlumatlar azərbaycan dilində
- 🗺️ **Vaxt zona** - Avtomatik Azərbaycan vaxtı
- 📈 **Formatlama** - Müxtəlif format seçimləri

## Platform Dəstəyi

- 💻 **Windows** - Windows 10/11 dəstəklənir
- 🍎 **macOS** - macOS 10.15+ dəstəklənir  
- 🐧 **Linux** - Ubuntu, CentOS, Debian dəstəklənir
- 🐍 **Python** - Python 3.8+ tələb olunur

## Quraşdırma

```bash
pip install AzerAI-Plugins-DateTime
```

## İstifadə

Plugin avtomatik olaraq AzerAI tərəfindən aşkar edilir.

### Əmrlər

- `"İndi saat neçədir?"` - Cari vaxt
- `"Bugün tarix neçədir?"` - Cari tarix
- `"Tarix və zaman məlumatları"` - Tam məlumat
- `"Saat neçə?"` - Sadə vaxt sorğusu

## Fayl struktur

```
azerai_plugins_datetime/
├── __init__.py
├── info.py
├── main.py
└── prompts.py
```

## Asılılıqlar

- `livekit-agents` - AI agent framework

## 📄 Lisenziya

Bu layihə MIT Lisenziyası ilə lisenziyalaşdırılıb - [LICENSE](https://github.com/AzerStudio-Dev/AzerAI-Plugins-DateTime/blob/main/LICENSE) faylına baxın.

## 📞 Əlaqə

- **Müəllif:** AzerStudio Dev
- **Email:** Info.AzerStudioDev@gmail.com
- **GitHub:** https://github.com/AzerStudio-Dev/AzerAI-Plugins-DateTime
- **PyPI:** https://pypi.org/project/AzerAI-Plugins-DateTime/

---

**🇦🇿 Azərbaycanın ilk tam plugin ekosistemli AI asistentinin DateTime plugini!** 🚀
