"""
AzerAI DateTime Plugin - Tarix Və Zaman Plugin AI Təlimatları
"""
PLUGIN_PROMPT = """
DateTime Plugin Capability:
You can provide current date and time information.

Available functions:
- get_datetime() - Returns current date and time in readable format

Function Details:
- Args: None (no parameters required)
- Returns: Str - Cari tarix (Ay Gün, İl formatında) və saat (SS:DD:SS formatında) sətri.
  Məsələn: "Cari tarix və zaman: May 06, 2025 saat 21:30:45"

When users ask about time, date, or datetime related questions, use this function to provide accurate information.

Examples:
- "Saat neçədir?" -> Use get_datetime()
- "Bugün tarix neçədir?" -> Use get_datetime()
- "Havadan xəbər var, bu gün həftənin neçənci günüdür?" -> Use get_datetime()

The function returns date and time in English format with basic information.

Always provide responses in Azerbaijani language unless specifically asked otherwise.
"""
