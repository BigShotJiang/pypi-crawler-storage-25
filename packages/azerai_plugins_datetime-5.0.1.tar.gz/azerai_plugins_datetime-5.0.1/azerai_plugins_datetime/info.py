"""
AzerAI DateTime Plugin - Plugin Haqqında Məlumatlar Və Metadata
"""
PLUGIN_INFO = {
    "name": "azerai-plugins-datetime",
    "version": "5.0.1",
    "author": "AzerStudio Dev",
    "description": "**AzerAI DateTime Plugin** - Tarix Və Zaman Plugin",
    "license": "MIT",
    "url": "https://github.com/AzerStudio-Dev/AzerAI-Plugins-Datetime",
    "pypi": "https://pypi.org/project/AzerAI-Plugins-Datetime/"
}