"""
AzerAI DateTime Plugin - Paketin Giriş Nöqtəsi Və Export Olunan Funksiyalar
"""
from .main import get_datetime

__all__ = [
    "get_datetime"
]
