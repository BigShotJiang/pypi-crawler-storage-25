"""
AzerAI DateTime Plugin - Tarix Və Zaman Alətləri
"""
import logging
from datetime import datetime
from livekit.agents import function_tool, RunContext

logger = logging.getLogger("AzerAI-Plugins-Datetime")

@function_tool()
async def get_datetime(
    ctx: RunContext,  # type: ignore
) -> str:
    """Cari tarix və zamanı al."""
    
    try:
        now = datetime.now()
        date_time_str = now.strftime("%Y-%m-%d %H:%M:%S")
        date_str = now.strftime("%B %d, %Y")
        time_str = now.strftime("%H:%M:%S")
        logger.info(f"Cari tarix və zaman: {date_time_str}")
        return f"Cari tarix və zaman: {date_str} saat {time_str}"
    except Exception as e:
        logger.error(f"Tarix və zaman alınarkən xəta: {e}")
        return f"Tarix və zaman alınarkən xəta baş verdi."
