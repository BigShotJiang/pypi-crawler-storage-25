# bSSG – B Static Site Generator
bSSG is an extensible static site generator that builds on top of [staticjinja](https://github.com/staticjinja/staticjinja). It includes support for templates (Jinja), translations (pyBabel), optimized thumbnail generation (Pillow), and build size minimization by excluding unreferenced files.

Features:
 - Support for templates (with Jinja)
 - Support for translations (with pyBabel)
 - Includes a thumbnail generator for responsive images (uses Pillow)
 - Efficient output by including only referenced static files
 - Opinionated on URL structure

## Architecture
A site that uses bSSG will have this URL a source structure as:
```
input/
 +- templates/
 |   +- <tree>
 +- static/
 |   +- <static files used in templates>
 +- translations/
     +- <language code>/
     |   +- LC_MESSAGES/
     |       +- messages.po
     ...
     +- <language code>/
         +- LC_MESSAGES/
             +- messages.po
```

And the generated site will be structured as:
```
output/
 +- <language code>/
 |   +- <tree>
 ...
 +- <language code>/
 |   +- <tree>
 +- <static files used in templates>
 +- thumb/
     +- <generated thumbnails>
```

And after generation, it can be accessed by an URL with the form `{URL_PREFIX}/[{LANG_CODE}/]{SUFFIX}`. Since the generated site is static, a web server has to be configured so that `URL_PREFIX` points to the path of the `output` directory.

An additional prefix (`STATIC_PREFIX`) can be added for static files so that they are not all placed directly at the root. Thumbnails are generated to the static files directory, but an additional prefix (`THUMB_PREFIX`) may be added to use an exclusive directory for thumbnails.

## Usage
Creating a website with bSSG can be done as follows:
1. Write the jinja templates, using `_('...')` for localized strings, the `static` filter for static files, and the `thumb` and `thumb_src` filters for images that want to thumbnailize.
2. Translate (if applicable).
    1. Extract the translations from the templates to a `.pot` file.
    2. Update (or init, if it is the first time) the message catalogs (one `.po` file for each language).
    3. Compile the message catalogs (generates one `.mo` file for each language).
3. Build the site. The script will make the thumbnails, use the compiled translations, and generate the localized trees following the structure of the templates.

