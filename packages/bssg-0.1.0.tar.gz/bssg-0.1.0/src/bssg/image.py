import math

import PIL.Image


def get_aspect_ratio_crop_box(size: tuple[int, int], width: float, height: float = 1.0) -> tuple[int, int, int, int]:
    """Returns a box that defines a centered and maximal region of image of size *size* cropped to
        have an aspect ratio of *width*/*height*"""

    # we have to find if we need a horizontal or vertical crop
    #   compare image aspect (image.w / image.h) with desired aspect (w / h)
    # but we can rearrange the comparison to be (image.w * h) with (image.h * w)
    #   to avoid divisions and rounding errors

    image_w, image_h = size

    relative_w = image_w * height
    relative_h = image_h * width

    box = [0, 0, image_w, image_h]

    if relative_w < relative_h:
        # portraiter than width:height -> crop height
        cropped_h = math.ceil(relative_w / width)
        box[1] = math.ceil((image_h - cropped_h) / 2)
        box[3] = box[1] + cropped_h
    elif relative_w > relative_h:
        # landscaper than width:height -> crop width
        cropped_w = math.ceil(relative_h / height)
        box[0] = math.ceil((image_w - cropped_w) / 2)
        box[2] = box[0] + cropped_w
    else:
        # image aspect ratio is equal to width:height
        pass

    return box


def make_thumbnail(image: PIL.Image, resolution: int, aspect: float | tuple[float, float] | None = None,
    resample: int | None = None, allow_upscale: bool = False) -> PIL.Image:
    """Returns a thumbnail of *image*, downscaled so that the largest dimension is <= *resolution*.
        In addition, if *aspect* is specified, the thumbnail will be cropped to match the aspect ratio.
        The Pillow resampling filter can be specified with *resample*."""

    new_size = list(image.size)

    # compute crop box if aspect is defined
    box = None
    if aspect:
        if not isinstance(aspect, (list, tuple)):
            aspect = (aspect, 1.0)
        box = get_aspect_ratio_crop_box(image.size, aspect[0], aspect[1])
        new_size = [box[2] - box[0], box[3] - box[1]]

    # compute (down)scaled size
    """max_dim = max(new_size)
    if max_dim > resolution or max_dim < resolution and allow_upscale:
        new_size = (w / max_dim * resolution, h / max_dim * resolution)"""
    if new_size[0] > resolution or new_size[0] < resolution and allow_upscale:
        new_size[1] = round(new_size[1] / new_size[0] * resolution)
        new_size[0] = resolution

    return image.resize(new_size, resample, box)
