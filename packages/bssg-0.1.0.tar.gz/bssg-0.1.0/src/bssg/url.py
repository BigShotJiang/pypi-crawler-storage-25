import urllib.parse


class UrlManager:
    def __init__(self, prefix: str):
        self._prefix = prefix

    def to_absolute(self, url: str) -> str:
        return urllib.parse.urljoin(self._prefix, url)

    def root_url(self) -> str:
        return self._prefix
