import json
import logging
import os
import pathlib
import shutil
import urllib.parse


class StaticFileManager:
    def __init__(self, prefix: str, files: set = None):
        self._prefix = prefix
        self._used_files = files or set()

    def to_static(self, path: str) -> str:
        """Register file and return with static prefix"""
        self._used_files.add(path)

        return urllib.parse.urljoin(self._prefix, path)

    def store(self, path: str) -> None:
        """Save list of used files to disk"""
        logger = logging.getLogger(__package__)
        logger.info(f'Storing StaticFileManager database to \'{path}\'')

        _parent = pathlib.Path(path).parent
        if not _parent.exists():
            logger.warning(f'Creating directory \'{_parent}\'')
            _parent.mkdir(parents=True)

        with open(path, 'w') as db:
            data = {
                'prefix': self._prefix,
                'files' : list(self._used_files)
            }

            json.dump(data, db)

    def load(path: str) -> set[str]:
        """Load a StaticFileManager from disk"""
        logger = logging.getLogger(__package__)
        logger.info(f'Loading StaticFileManager database from \'{path}\'')

        mgr = None

        with open(path, 'r') as db:
            data = json.load(db)
            mgr = StaticFileManager(data['prefix'], data['files'])

        return mgr

    def copy_files(self, src_dir: pathlib.Path, dst_dir: pathlib.Path) -> None:
        """Copy registered files from src_dir/ to dst_dir/prefix/"""
        logger = logging.getLogger(__package__)
        logger.info(f'Copying files in StaticFileManager database \'{src_dir}\' -> \'{dst_dir} / {self._prefix}\'')

        _dst_dir = dst_dir / self._prefix

        if not _dst_dir.exists():
            logger.warning(f'Creating directory \'{_dst_dir}\'')
            _dst_dir.mkdir(parents=True)

        for _path in self._used_files:
            src_path = pathlib.Path(src_dir, _path)
            dst_path = pathlib.Path(_dst_dir, _path)

            if not dst_path.parent.exists():
                logger.debug(f'Creating directory \'{dst_path.parent}\'')
                dst_path.parent.mkdir(parents=True)

            if src_path.is_dir():
                logger.debug(f'Copying directory \'{src_path}\' -> \'{dst_path}\'')
                shutil.copytree(src_path, dst_path, dirs_exist_ok=True)
            else:
                logger.debug(f'Copying file \'{src_path}\' -> \'{dst_path}\'')
                shutil.copy2(src_path, dst_path)
