from .config import Config
from .static import StaticFileManager
from .url import UrlManager
from .image import make_thumbnail

import PIL.Image

import babel.support
from babel.dates import format_date

import staticjinja

import datetime
import json
import logging
import os
import pathlib
import urllib.parse


class URLTranslator:
    def __init__(self, hide=None):
        self.hide = hide
        #self.transrel = {lng: Translations.load('locale', lng) for lng in languages}

    def trans_url(self, url, rlang=None):
        outlang = rlang or self.lang
        if outlang not in languages:
            raise RuntimeError(f'Language \'{outlang}\' not installed')

        if self.hide and self.hide == outlang:
            outlang = ''

        # lookup translation for url for selected language
        #trans_url = self.transrel[outlang].gettext(url) if url else url

        #print(url, "->", os.path.join(ROOT_URL, outlang, url))
        return os.path.join(ROOT_URL, outlang, url)


def load_images_data():
    datafile = 'photos.json'
    PHOTO_PATH = '/input/photo'  # disk location of original photos
    PHOTO_URL = 'photo'  # slug to access photos
    THUMB_URL = 'thumb'  # slug to access thumbnails
    PHOTO_DIR = os.path.join(cdndir, PHOTO_URL)  # directory to be published
    THUMB_DIR = os.path.join(cdndir, THUMB_URL)

    if not os.path.exists(PHOTO_DIR):
        os.makedirs(PHOTO_DIR, exist_ok=True)
    if not os.path.exists(THUMB_DIR):
        os.makedirs(THUMB_DIR, exist_ok=True)

    res = []
    with open(datafile) as df:
        data = json.load(df)
        for gallery in data:
            gal = {}
            gal['name'] = gallery['name']
            gal['photos'] = []

            print(f'Gallery \"{gal["name"]}\"')

            for img in gallery['photos']:
                img_name = img['url']
                print(f'Processing {img_name}...')

                # date translations
                date = img['date']
                img['date'] = {}
                for lc in languages:
                    try:
                        img['date'][lc] = format_date(datetime.datetime.fromisoformat(date), format='long', locale=lc)
                        img['isodate'] = date
                    except:
                        img['date'][lc] = date

                # path
                img_path = os.path.join(PHOTO_PATH, img_name)
                img['url'] = cdn_url(os.path.join(PHOTO_URL, img_name))

                picture = Image.open(img_path)
                fullres_path = os.path.join(PHOTO_DIR, img_name)
                if not os.path.exists(fullres_path):
                    picture.save(fullres_path)  # copy original
                img['resolution'] = f'{picture.size[0]}&times;{picture.size[1]}'
                img['bytes'] = os.stat(img_path).st_size
                img['thumbs'] = {}
                img_thumb_name = pathlib.Path(img_name).with_suffix('.webp')

                for thumb_w in [200, 300, 400, 500, 600]: # [150, 300, 600, 900]:
                    thumb_path = os.path.join(THUMB_DIR, str(thumb_w), img_thumb_name)
                    img['thumbs'][thumb_w] = cdn_url(os.path.join(THUMB_URL, str(thumb_w), img_thumb_name))

                    if not os.path.exists(thumb_path):
                        os.makedirs(os.path.dirname(thumb_path), exist_ok=True)
                        makeThumbnail(picture, thumb_w, (3, 2)).save(thumb_path)

                gal['photos'].append(img)

            gal['featured'] = gal['photos'][gallery.get('featured', 0)]
            res.append(gal)

    return res


def translate_and_render_new(template, outpath, ofdir, ofname, language, **kwargs):
    if language != 'en':
        ofdir = os.path.join(language, ofdir)
    out_file = os.path.join(outpath, ofdir, ofname)
    fileurl = os.path.join(ofdir, '' if ofname == 'index.html' else ofname)

    print(f'  DISK {out_file} | URL {fileurl}')

    # Make dir if doesn't exist
    if not os.path.exists(out_file):
        os.makedirs(os.path.dirname(out_file), exist_ok=True)

    # Get translations
    site.env.install_gettext_translations(transrel[language])
    translator = URLTranslator(hide='en')
    translator.lang = language

    # Render
    template.stream(
            lang_code=language,
            root_url=ROOT_URL,
            static=static_url,
            cdn=cdn_url,
            url=translator.trans_url,
            this_url=fileurl,
            **kwargs
    ).dump(out_file, encoding='utf-8')

    # Clear translations
    site.env.uninstall_gettext_translations(transrel[language])


def translate_and_render(site, template, **kwargs):
    print(site)
    translator = URLTranslator(hide='en')

    # We prefer to use 'x' to 'x/index.html' for links
    filepath, filename = os.path.split(template.name)
    fileurl = filepath if filename == 'index.html' else template.name

    for language in languages:
        # Outpath is <out>/<lang_code>/<template>
        out_dir = os.path.join(site.outpath, language) if language != 'en' else site.outpath
        out_file = os.path.join(out_dir, template.name)
        if not os.path.exists(out_file):
            os.makedirs(os.path.dirname(out_file), exist_ok=True)

        # Get translations
        translations = transrel[language]
        site.env.install_gettext_translations(translations)
        translator.lang = language

        # Render
        template.stream(
                lang_code=language,
                root_url=ROOT_URL,
                static=static_url,
                cdn=cdn_url,
                url=translator.trans_url,
                this_url=fileurl,
                **kwargs
        ).dump(out_file)

        # Clear translations
        site.env.uninstall_gettext_translations(translations)


def translate_and_render_parts(site, template, **context):
    tdir, tname = os.path.split(template.name)
    print(f'Rendering {template} as ({len(context["parts"])}) parts')

    for part in context['parts']:
        # TODO translated slugs
        slug = part['slug']

        for language in languages:
            fdir = os.path.join(tdir, slug)
            translate_and_render_new(template, site.outpath, fdir, tname, language, part=part)


def tr(site, template, *args, **kwargs):
    out_path = pathlib.Path(site.outpath)
    template_path = pathlib.Path(template.name)

    # disk path to save rendered file to
    this_path = out_path / template_path
    if not this_path.parent.exists():
        this_path.parent.mkdir(parents=True)

    # url to use in web documents
    # we prefer to use 'x' instead of 'x/index.<ext>' for links
    this_url = str(template_path)
    if template_path.stem == 'index':
        # leave empty if there is just a dot (i.e. topmost index.* template)
        this_url = f'{template_path.parent}/' if template_path.parent.parts else ''

    #print(f'  -> DISK {this_path} | URL {os.path.join(url_prefix, this_url)}')
    #print([thumb_url, thumb_widths])

    # render
    template.stream(
        url_prefix=template.environment.globals['url_prefix'],
        lang=template.environment.globals['language'],
        this_url=this_url,
        **kwargs
    ).dump(str(this_path))


def render(cfg: Config):
    logger = logging.getLogger(__package__)

    # get current timestamp
    timestamp = datetime.datetime.now()

    # create managers
    url_mgr = UrlManager(cfg.url_prefix)
    static_mgr = StaticFileManager(cfg.static_prefix)
    thumb_mgr = StaticFileManager(os.path.join(cfg.static_prefix, cfg.thumb_prefix))

    todo_th = dict()

    # functions to use in templates
    def thumb_src(path, width, aspect=None, suffix='.webp'):
        # register to process in batches
        if not path in todo_th:
            todo_th[path] = set()
        todo_th[path].add((width, aspect, suffix))

        # construct static url
        th_name = str(pathlib.Path(str(width), path).with_suffix(suffix))
        th_url = thumb_mgr.to_static(th_name)

        return str(th_url)

    def thumb_srcset(path: str, widths: list[int], fn=lambda x: x, aspect=None, suffix: str ='.webp'):
        srcset = []
        for width in widths:
            th_url = fn(thumb_src(path, width, aspect, suffix))

            # add url to srcset
            srcset.append(f'{th_url} {width}w')

        return ', '.join(srcset)

    # render site for each language
    for language in cfg.languages:
        def translate_url(url: str, lang_code: str = language) -> str:
            prefix = ''
            lc = lang_code
            suffix = url

            if lang_code == cfg.root_language:
                # if the language is the root one, we do not add a language code
                lc = ''

            if url.startswith(cfg.url_prefix):
                # if the url has the site prefix, remove it from the suffix
                p = len(cfg.url_prefix)
                prefix = url[:p]
                suffix = url[p:]

            if len(lc) > 0 and len(suffix) > 0:
                # do not add a slash if url does not have it
                lc = f'{lc}/'

            if suffix.startswith('/'):
                # if the url starts with a slash, move it before the language
                suffix = url[1:]
                lc = f'/{lc}'

            #print([prefix, lc, suffix])

            base = f'{prefix}{lc}'
            turl = urllib.parse.urljoin(base, suffix)

            #print(f'TRANS {url} @ {lang_code} -> {turl}') #urllib.parse.urljoin(prolog, lang_code + "/", url)
            return turl

        logger.info(f'Rendering site for language \'{language.upper()}\'')
        # setup site
        site = staticjinja.Site.make_site(
            searchpath = cfg.templates_path,
            outpath = cfg.out_path if language == cfg.root_language else cfg.out_path / language,
            contexts = [
                ('.*.(html|xhtml)', {
                }),
            ],
            rules = [
                ('.*.(html|xhtml)', tr), #translate_and_render),
            ],
            #encoding = 'utf-8',
            #followlinks = True,
            extensions = ['jinja2.ext.i18n'],  # 'jinja2.ext.autoescape', 'jinja2.ext.with_'],
            filters = {
                'absolute': url_mgr.to_absolute,
                'static': static_mgr.to_static,
                'urltranslate': translate_url,
                'thumbs': thumb_srcset,
                'thumb': thumb_src,
                'datefmt': format_date,
            },
            env_globals = {
                'url_prefix': cfg.url_prefix,
                'language': language,
                'languages': cfg.languages,
                #'thumb_url': thumb_url,
                'timestamp': timestamp,
                'generator': f'{staticjinja.__name__} {staticjinja.__version__}'
            },
            env_kwargs = {'enable_async': False},
        )

        # load translation
        translations = babel.support.Translations.load(cfg.localecache_path, language)
        site.env.install_gettext_translations(translations)

        # render site
        site.render(use_reloader=False)

        # clear translations
        site.env.uninstall_gettext_translations(translations)

    # export used static files
    thumb_mgr.store(cfg.thumbdb_path)
    static_mgr.store(cfg.staticdb_path)

    # generate thumbnails TODO -> do alone
    logger.info('Creating thumbnails')
    for (path, ths) in todo_th.items():
        im_path = os.path.join(cfg.static_path, path)

        with PIL.Image.open(im_path) as original:
            for (width, aspect, suffix) in ths:
                th_name = pathlib.Path(str(width), path).with_suffix(suffix)
                th_path = cfg.thumbcache_path / th_name

                if th_path.exists():
                    logger.debug(f'Thumbnail \'{th_path}\' already exists -- skipping')
                    # if exists, skip (use cached)
                    continue

                if not th_path.parent.exists():
                    th_path.parent.mkdir(parents=True)

                #print(f'THUMB {th_path}')
                logger.debug(f'Creating thumbnail \'{th_path}\' ')
                make_thumbnail(original, width, aspect or original.size).save(th_path)
