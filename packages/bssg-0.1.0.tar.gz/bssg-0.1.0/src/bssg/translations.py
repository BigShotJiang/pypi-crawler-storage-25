# maybe TODO: use pybabel directly instead of running subprocesses

import importlib
import logging
import subprocess

from .config import Config


def get_translations(cfg: Config):
    logger = logging.getLogger(__package__)

    # extract messages to be translated
    if not cfg.localecache_path.exists():
        logger.warning(f'Locale cache directory \'{cfg.localecache_path}\' does not exist -- creating')
        cfg.localecache_path.mkdir(parents=True)

    babel_cfg = importlib.resources.files(f'{__package__}.resources').joinpath('babel.cfg')
    potfile = cfg.localecache_path / f'messages.pot'

    logger.info(f'Extracting template messages')
    subprocess.run(['pybabel', 'extract', '-F', babel_cfg, '-o', str(potfile), str(cfg.templates_path)])

    # initialize translations
    if not cfg.locale_path.exists():
        logger.warning(f'Locale directory \'{cfg.locale_path}\' does not exist -- creating')
        cfg.locale_path.mkdir(parents=True)

    logger.info(f'Creating/updating message catalogs')
    for lang_code in cfg.languages:
        pofile = cfg.locale_path / lang_code / 'LC_MESSAGES' / 'messages.po'

        if not pofile.exists():
            logger.debug(f'Creating message catalog for language \'{lang_code}\'')
            subprocess.run(['pybabel', 'init', '-l', lang_code, '-i', str(potfile), '-o', str(pofile)])
        else:
            logger.debug(f'Message catalog for language \'{lang_code}\' already exists -- updating')
            subprocess.run(['pybabel', 'update', '-l', lang_code, '-i', str(potfile), '-o', str(pofile)])


def compile_translations(cfg: Config):
    logger = logging.getLogger(__package__)

    logger.info('Compiling translations')
    for lang_code in cfg.languages:
        pofile = cfg.locale_path / lang_code / 'LC_MESSAGES' / 'messages.po'
        mofile = cfg.localecache_path / lang_code / 'LC_MESSAGES' / 'messages.mo'

        if not mofile.parent.exists():
            logger.warning(f'Locale \'{lang_code}\' cache directory \'{mofile.parent}\' does not exist -- creating')
            mofile.parent.mkdir(parents=True)

        logger.debug(f'Compiling message catalog for language \'{lang_code}\'')
        subprocess.run(['pybabel', 'compile', '-l', lang_code, '-i', str(pofile), '-o', str(mofile)])
