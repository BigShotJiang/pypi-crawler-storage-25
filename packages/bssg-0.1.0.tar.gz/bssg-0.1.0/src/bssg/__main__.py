#!/usr/bin/python3

import argparse
import importlib.metadata
import importlib.resources
import logging
import pathlib
import shutil
import subprocess
import sys

from .config import Config
from .render import render
from .static import StaticFileManager
from .translations import get_translations, compile_translations


def print_config(cfg: Config):
    print(str(cfg))


def build(cfg: Config):
    compile_translations(cfg)
    render(cfg)
    #TODO extract thumbnail compilation from *render* to a separate function


def copy_static(cfg: Config):
    logger = logging.getLogger(__package__)

    logger.info(f'Copying thumbnails \'{cfg.thumbcache_path}\' -> \'{cfg.out_path}\'')
    thumbmgr = StaticFileManager.load(cfg.thumbdb_path)
    thumbmgr.copy_files(cfg.thumbcache_path, cfg.out_path)

    logger.info(f'Copying static files \'{cfg.static_path}\' -> \'{cfg.out_path}\'')
    staticmgr = StaticFileManager.load(cfg.staticdb_path)
    staticmgr.copy_files(cfg.static_path, cfg.out_path)


def _getparser():
    metadata = importlib.metadata.metadata(__package__)
    parser = argparse.ArgumentParser(
                        prog=metadata['Name'],
                        description=metadata['Summary'],
                        epilog=f'{metadata["Name"]} v{metadata["Version"]} © {metadata["License-Expression"]} {metadata["Author-email"]}')

    subparsers = parser.add_subparsers(dest='subcommand')
    parser.add_argument('--cfg', type=pathlib.Path, default='./bssg.toml', help='Configuration file')
    parser.add_argument('-v', action='count', default=0, help='Be verbose')

    parser_printcfg = subparsers.add_parser('print-config', help='Display configuration from configuration file')
    parser_printcfg.set_defaults(func=print_config)

    parser_init = subparsers.add_parser('init', help='Initialize a new website')

    parser_gettr = subparsers.add_parser('get-translations', help='Create or update message catalogs from translatable strings in templates')
    parser_gettr.set_defaults(func=get_translations)

    parser_build = subparsers.add_parser('build', help='Compile message catalogs, render templates to output directory, and create thumbnails')
    parser_build.set_defaults(func=build)

    parser_copystatic = subparsers.add_parser('copy-static', help='Copy static files (only those used in templates) to output directory')
    parser_copystatic.set_defaults(func=copy_static)

    return parser


def cli():
    parser = _getparser()
    args = parser.parse_args()

    # check if no command
    if args.subcommand is None:
        parser.print_help()
        return

    # configure logger
    formatter = logging.Formatter('[%(levelname)s] %(name)s/%(filename)s:%(lineno)d: %(message)s')

    handler = logging.StreamHandler()
    handler.setFormatter(formatter)

    logger = logging.getLogger(__package__)
    logger.addHandler(handler)
    logger.setLevel([logging.NOTSET, logging.INFO, logging.DEBUG][min(args.v, 2)])

    # handle special case that may not have a configuration file
    if args.subcommand == 'init':
        # create config file if it does not exist
        if args.cfg.exists():
            logger.info(f'Configuration file \'{str(args.cfg)}\' already exists -- skipping')
        else:
            logger.info(f'Initializing \'{str(args.cfg)}\' with default configuration')
            default_cfgfile = importlib.resources.files(f'{__package__}.resources').joinpath('default-bssg.toml')
            shutil.copy2(default_cfgfile, args.cfg)
        return

    # load config file
    config = Config(args.cfg)

    args.func(config)


if __name__ == '__main__':
    cli()
