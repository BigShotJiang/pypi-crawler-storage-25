import logging
import pathlib
import tomllib

import urllib.parse


def normalize_prefix(prefix: str) -> str:
    # don't modify empty prefix
    if not prefix:
        return ''

    # parse
    url_prefix = urllib.parse.urlparse(prefix)
    path = url_prefix.path

    # add trailing slash
    if not path.endswith('/'):
        url_prefix = url_prefix._replace(path=(path + '/'))

    return url_prefix.geturl()


def normalize_path(path: str) -> pathlib.Path:
    return pathlib.Path(path).resolve()


class Config:
    def __init__(self, config_path: pathlib.Path):
        self.config_path = str(config_path)

        with open(config_path, 'rb') as f:
            cfg = tomllib.load(f)

            self.languages = cfg['site']['languages']
            self.root_language = cfg['site'].get('root_language', None)
            self.url_prefix = normalize_prefix(cfg['site']['url_prefix'])
            self.static_prefix = normalize_prefix(cfg['site']['static_prefix'])
            self.thumb_prefix = normalize_prefix(cfg['site']['thumbnail_prefix'])

            self.templates_path = normalize_path(cfg['paths']['templates'])
            self.locale_path = normalize_path(cfg['paths']['locale'])
            self.static_path = normalize_path(cfg['paths']['static'])
            self.cache_path = normalize_path(cfg['paths']['cache'])
            self.out_path = normalize_path(cfg['paths']['build'])

            self.staticdb_path = self.cache_path / 'static_files.json'
            self.thumbdb_path = self.cache_path / 'static_thumbnails.json'
            self.thumbcache_path = self.cache_path / 'thumbnails'
            self.localecache_path = self.cache_path / 'locale'


    def __str__(self):
        sitecfg = '\n'.join((
             '  SITE',
            f'    Languages:           {self.languages}',
            f'    Root language:       {self.root_language}',
            f'    Url prefix:          {self.url_prefix}',
            f'    Static prefix:       {self.static_prefix}',
            f'    Thumb prefix:        {self.thumb_prefix}',
        ))
        pathscfg = '\n'.join((
             '  PATHS',
            f'    Templates directory: {self.templates_path}',
            f'    Locale directory:    {self.locale_path}',
            f'    Static directory:    {self.static_path}',
            f'    Cache directory:     {self.cache_path}',
            f'      Static database:   {self.staticdb_path}',
            f'      Thumb database:    {self.thumbdb_path}',
            f'      Thumb cache:       {self.thumbcache_path}',
            f'      Locale cache:      {self.localecache_path}',
            f'    Output directory:    {self.out_path}'
        ))

        return '\n'.join((
             'Configuration',
            f'  CFG PATH               {self.config_path}',
            sitecfg,
            pathscfg
        ))
