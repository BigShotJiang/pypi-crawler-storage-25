#!/usr/bin/env python3
"""{{PLUGIN_NAME}} — LoongClaw MCP 插件

入口文件，负责注册工具并启动 MCP 服务。
核心业务逻辑请放在其他 .py 文件中（发布时会自动加密）。
"""

from pathlib import Path

from mcp.server.fastmcp import FastMCP

# 插件根目录（安装后 project.zip 的内容直接解压到这里）
# ⚠️ 不要在后面拼 / "project" 等子目录，zip 解压不会创建额外层级
PLUGIN_DIR = Path(__file__).resolve().parent

mcp = FastMCP(
    "{{PLUGIN_ID}}",
    instructions=(
        "{{PLUGIN_DESCRIPTION}}"
    ),
)


@mcp.tool()
def hello(name: str) -> str:
    """向用户问好。这是一个示例工具，请替换为你的实际功能。

    Args:
        name: 用户的名字
    """
    return f"你好，{name}！这是 {{PLUGIN_NAME}} 插件。"


# 在下方注册更多工具...
# 核心逻辑建议放在单独的 .py 文件中（如 core.py），然后 import 使用：
#
# from core import process_data
#
# @mcp.tool()
# def my_tool(input_text: str) -> str:
#     """工具描述（AI 只看这段 docstring，写清楚功能和参数）"""
#     return process_data(input_text)


if __name__ == "__main__":
    mcp.run(transport="stdio")
