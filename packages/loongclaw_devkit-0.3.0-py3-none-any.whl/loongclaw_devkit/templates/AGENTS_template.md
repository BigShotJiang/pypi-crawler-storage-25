# LoongClaw MCP 插件开发指南

## 你正在开发什么

这是一个 LoongClaw MCP 插件项目。MCP（Model Context Protocol）是让 AI 助手调用外部工具的标准协议。
你写的每个 `@mcp.tool()` 函数都会变成 AI 可以调用的工具。

## 项目结构

```
server.py           ← MCP 入口文件（必须保持明文，不要在这里写核心逻辑）
core.py             ← 核心业务逻辑（发布时自动加密编译成 .so/.pyd）
requirements.txt    ← Python 依赖
publish.py          ← 一键发布脚本（不要修改）
.publish.json       ← 发布配置（自动生成，不要手动编辑）
```

## 开发规范

### 入口文件 server.py
- 必须叫 `server.py`，不能改名
- 必须使用 `from mcp.server.fastmcp import FastMCP`
- 必须以 `mcp.run(transport="stdio")` 结尾
- 只做 import + 注册工具 + 启动，不写业务逻辑
- server.py 发布时**不会被加密**（Python 需要它来启动）

### 工具函数
- 每个 `@mcp.tool()` 的 **docstring 是 AI 看到的唯一说明**，必须写清楚：
  - 这个工具做什么
  - 每个参数的含义
  - 返回什么
- 参数用 Python 类型注解（`str`, `int`, `bool`, `list[str]`）
- 返回值必须是 `str`（MCP 协议要求）
- 复杂返回值用 `json.dumps()` 序列化

### 核心逻辑
- 放在独立的 .py 文件中（如 `core.py`、`utils.py`）
- 在 server.py 中 `from core import xxx` 引用
- 这些文件发布时**自动加密编译**为 .so/.pyd，用户看不到源码

### 用户配置
- 通过环境变量传递：`os.environ.get("MY_CONFIG", "默认值")`
- publish.py 会自动扫描 `os.environ.get()` 调用，生成配置界面
- 用户在 LoongClaw 安装时会看到配置表单

## 发布

### 交互模式（你来操作）
```bash
python publish.py
```
按提示回答问题即可。

### 自动模式（AI 操作）
```bash
# 首次发布
python publish.py --auto --id my-plugin --version 1.0.0 --access public --upload --json-output

# 后续更新（读取 .publish.json 配置）
python publish.py --auto --version 1.1.0 --json-output

# 纯本地打包，不上传
python publish.py --auto --no-upload --json-output
```

### 命令行参数
| 参数 | 说明 | 示例 |
|------|------|------|
| `--auto` | 自动模式（不交互） | |
| `--id` | 插件 ID | `--id my-plugin` |
| `--name` | 显示名称 | `--name "我的插件"` |
| `--version` | 版本号 | `--version 1.0.0` |
| `--access` | public 或 private | `--access private` |
| `--skip-encrypt` | 不加密的文件 | `--skip-encrypt "config.py,utils.py"` |
| `--upload` | 上传到服务器 | |
| `--no-upload` | 不上传 | |
| `--token` | API Token | `--token lc-xxx` |
| `--json-output` | JSON 输出 | |
| `--reconfigure` | 重新配置 | |

### JSON 输出格式
成功：
```json
{"status": "success", "version": "1.0.0", "files_encrypted": 3, "uploaded": true}
```

失败：
```json
{"status": "error", "step": "encrypt", "error": "SyntaxError at line 42", "fix": "检查 core.py 第 42 行的语法错误"}
```

**`fix` 字段包含修复建议**——直接按建议修改代码，然后重新运行 `python publish.py --auto --json-output`。

## 常见错误

| 错误 | 原因 | 修复 |
|------|------|------|
| `Cython not found` | 未安装编译器 | `pip install cython` |
| `编译失败` | macOS 缺 Xcode 工具 | `xcode-select --install` |
| `缺少入口文件 server.py` | 文件名不对 | 确保入口叫 `server.py` |
| `未找到 FastMCP 实例` | server.py 没用 FastMCP | 检查 import 和实例化 |
| `HTTP 401` | Token 无效 | 重新获取 Store Key 或设置 `LOONGCLAW_STORE_KEY` 环境变量 |

## 本地测试

```bash
# 直接运行测试
python server.py

# 或用 MCP inspector
mcp dev server.py
```
