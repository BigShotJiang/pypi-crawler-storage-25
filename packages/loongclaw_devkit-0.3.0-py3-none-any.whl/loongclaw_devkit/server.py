"""LoongClaw DevKit MCP Server

提供 3 个工具，让 AI 助手直接完成 MCP 插件的创建、发布、状态查看。
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

from mcp.server.fastmcp import FastMCP

# 包目录（pip install 后 publish.py 和 templates/ 在同一目录下）
PACKAGE_DIR = Path(__file__).resolve().parent
PUBLISH_SCRIPT = PACKAGE_DIR / "publish.py"
TEMPLATES_DIR = PACKAGE_DIR / "templates"

mcp = FastMCP(
    "loongclaw-devkit",
    instructions=(
        "LoongClaw MCP 开发者工具包。"
        "帮助开发者创建、加密打包、发布 MCP 插件到 LoongClaw 商店。"
        "一条命令完成整个流程，无需手动操作。"
    ),
)


@mcp.tool()
def create_mcp_project(
    project_dir: str,
    plugin_id: str,
    plugin_name: str = "",
    description: str = "",
) -> str:
    """在指定目录创建一个新的 LoongClaw MCP 插件项目。

    自动生成 server.py、requirements.txt、AGENTS.md、publish.py 等文件。
    创建完成后可直接开始编写工具函数。

    Args:
        project_dir: 项目目录的绝对路径（会自动创建）
        plugin_id: 插件 ID（字母数字和连字符，如 my-plugin）
        plugin_name: 插件显示名称（留空则用 plugin_id）
        description: 插件描述
    """
    target = Path(project_dir).resolve()

    if target.exists() and any(target.iterdir()):
        return json.dumps({
            "status": "error",
            "error": f"目录 {target} 已存在且非空",
            "fix": "选择一个空目录或不存在的目录",
        }, ensure_ascii=False)

    target.mkdir(parents=True, exist_ok=True)

    name = plugin_name or plugin_id

    # 复制模板文件
    server_template = TEMPLATES_DIR / "server_template.py"
    if server_template.exists():
        content = server_template.read_text(encoding="utf-8")
        content = content.replace("{{PLUGIN_ID}}", plugin_id)
        content = content.replace("{{PLUGIN_NAME}}", name)
        content = content.replace("{{PLUGIN_DESCRIPTION}}", description)
        (target / "server.py").write_text(content, encoding="utf-8")

    agents_template = TEMPLATES_DIR / "AGENTS_template.md"
    if agents_template.exists():
        shutil.copy2(agents_template, target / "AGENTS.md")

    req_template = TEMPLATES_DIR / "requirements_template.txt"
    if req_template.exists():
        shutil.copy2(req_template, target / "requirements.txt")

    # 复制 publish.py
    if PUBLISH_SCRIPT.exists():
        shutil.copy2(PUBLISH_SCRIPT, target / "publish.py")

    # 生成初始 .publish.json
    config = {
        "id": plugin_id,
        "name": name,
        "description": description,
        "version": "1.0.0",
        "author": "",
        "icon": "🔧",
        "access": "public",
        "skipEncrypt": [],
        "upload": False,
    }
    (target / ".publish.json").write_text(
        json.dumps(config, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    return json.dumps({
        "status": "success",
        "project_dir": str(target),
        "files_created": ["server.py", "requirements.txt", "AGENTS.md", "publish.py", ".publish.json"],
        "next_steps": [
            f"编辑 {target}/server.py 添加你的工具函数",
            "核心业务逻辑放在 core.py 等独立文件中（自动加密）",
            f"测试: cd {target} && python server.py",
            f"发布: cd {target} && python publish.py",
        ],
    }, ensure_ascii=False)


@mcp.tool()
def publish_mcp(
    project_dir: str,
    version: str = "",
    access: str = "",
    upload: bool = False,
    skip_encrypt: str = "",
    token: str = "",
) -> str:
    """一键加密打包并发布 MCP 插件到 LoongClaw 商店。

    自动完成：校验项目 → Cython 加密编译 → 打包 zip → 生成 manifest → 上传服务器。
    配置保存在 .publish.json 中，后续更新只需传 version。

    Args:
        project_dir: 项目目录的绝对路径
        version: 版本号（如 1.0.0），留空则读取 .publish.json 中的版本
        access: 访问类型 public 或 private，留空则读取配置
        upload: 是否上传到 LoongClaw 服务器
        skip_encrypt: 不加密的文件列表（逗号分隔），留空则全部加密
        token: LoongClaw Store Key（也可用 LOONGCLAW_STORE_KEY 环境变量，前往 loongclaw.net.cn/dev/ 获取）
    """
    target = Path(project_dir).resolve()
    if not target.exists():
        return json.dumps({
            "status": "error",
            "error": f"目录不存在: {target}",
            "fix": "检查路径是否正确",
        }, ensure_ascii=False)

    if not PUBLISH_SCRIPT.exists():
        return json.dumps({
            "status": "error",
            "error": "publish.py 未找到",
            "fix": f"确认 loongclaw-devkit 安装完整，预期位置: {PUBLISH_SCRIPT}",
        }, ensure_ascii=False)

    # 构造命令
    cmd = [
        sys.executable, str(PUBLISH_SCRIPT),
        "--auto", "--json-output",
        "--dir", str(target),
    ]
    if version:
        cmd.extend(["--version", version])
    if access:
        cmd.extend(["--access", access])
    if upload:
        cmd.append("--upload")
    else:
        cmd.append("--no-upload")
    if skip_encrypt:
        cmd.extend(["--skip-encrypt", skip_encrypt])
    if token:
        cmd.extend(["--token", token])

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=str(target),
        )

        # 尝试从 stdout 提取 JSON（最后一行）
        lines = result.stdout.strip().split("\n")
        for line in reversed(lines):
            line = line.strip()
            if line.startswith("{"):
                try:
                    parsed = json.loads(line)
                    return json.dumps(parsed, ensure_ascii=False)
                except json.JSONDecodeError:
                    continue

        # 没找到 JSON → 返回原始输出
        return json.dumps({
            "status": "error" if result.returncode != 0 else "unknown",
            "stdout": result.stdout[-2000:] if result.stdout else "",
            "stderr": result.stderr[-2000:] if result.stderr else "",
            "fix": "检查 publish.py 输出",
        }, ensure_ascii=False)

    except Exception as e:
        return json.dumps({
            "status": "error",
            "error": str(e),
            "fix": "检查 Python 环境和 publish.py 是否可执行",
        }, ensure_ascii=False)


@mcp.tool()
def check_mcp_status(plugin_id: str = "", project_dir: str = "") -> str:
    """查看 MCP 插件的当前状态。

    传入 plugin_id 查询已发布的状态，或传入 project_dir 查看本地项目状态。

    Args:
        plugin_id: 插件 ID（查询已发布状态时使用）
        project_dir: 项目目录路径（查看本地项目状态时使用）
    """
    result: dict = {}

    if project_dir:
        target = Path(project_dir).resolve()
        if not target.exists():
            return json.dumps({
                "status": "error",
                "error": f"目录不存在: {target}",
            }, ensure_ascii=False)

        # 读取 .publish.json
        config_path = target / ".publish.json"
        if config_path.exists():
            try:
                config = json.loads(config_path.read_text(encoding="utf-8"))
                result["config"] = config
            except Exception:
                result["config"] = None

        # 检查项目文件
        result["files"] = {
            "server.py": (target / "server.py").exists(),
            "requirements.txt": (target / "requirements.txt").exists(),
            "publish.py": (target / "publish.py").exists(),
            "AGENTS.md": (target / "AGENTS.md").exists(),
            "project.zip": (target / "project.zip").exists(),
            ".publish.json": config_path.exists(),
        }

        # 统计 .py 文件数量
        py_files = list(target.rglob("*.py"))
        result["py_file_count"] = len(py_files)
        result["status"] = "ok"

    if plugin_id:
        # 尝试查询 Cloud API（需要 token）
        token = os.environ.get("LOONGCLAW_STORE_KEY", "")
        if token:
            import urllib.request
            import urllib.error
            url = "https://api.loongclaw.net.cn/v1/store/mcp/registry.json"
            req = urllib.request.Request(
                url, headers={"Authorization": f"Bearer {token}"},
            )
            try:
                with urllib.request.urlopen(req) as resp:
                    registry = json.loads(resp.read().decode("utf-8"))
                    servers = registry.get("servers", [])
                    for s in servers:
                        if s.get("id") == plugin_id:
                            result["published"] = s
                            break
                    if "published" not in result:
                        result["published"] = None
                        result["message"] = f"'{plugin_id}' 未在商店中找到"
            except Exception as e:
                result["registry_error"] = str(e)
        else:
            result["registry_note"] = "设置 LOONGCLAW_STORE_KEY 环境变量可查询已发布状态"

        result["status"] = result.get("status", "ok")

    if not plugin_id and not project_dir:
        return json.dumps({
            "status": "error",
            "error": "请至少提供 plugin_id 或 project_dir",
            "fix": "传入要查询的插件 ID 或项目目录路径",
        }, ensure_ascii=False)

    return json.dumps(result, ensure_ascii=False, indent=2)


def main():
    mcp.run(transport="stdio")
