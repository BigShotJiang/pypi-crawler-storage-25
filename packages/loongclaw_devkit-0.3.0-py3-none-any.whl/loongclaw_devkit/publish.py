#!/usr/bin/env python3
"""LoongClaw MCP 一键发布工具

交互模式（人类用）：
    python publish.py

自动模式（AI 用）：
    python publish.py --auto --id my-mcp --version 1.0.0 --access public --json-output

首次运行后配置保存到 .publish.json，后续 --auto 自动读取。
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

# ── 常量 ──────────────────────────────────────────────────
CLOUD_API_BASE = "https://api.loongclaw.net.cn"
UPLOAD_ENDPOINT = "/v1/store/upload"
ENTRYPOINT = "server.py"  # 入口文件，始终明文
CONFIG_FILE = ".publish.json"
IGNORE_PATTERNS = {
    "__pycache__", ".pytest_cache", ".ruff_cache", ".git", ".venv",
    "logs", "cache", ".coverage", "*.pyc", "*.pyo", ".publish.json",
    "publish.py", "setup.py", "build", "dist", "*.egg-info",
}


# ── 工具函数 ──────────────────────────────────────────────

def should_skip(name: str) -> bool:
    if name in IGNORE_PATTERNS:
        return True
    return any(
        name.endswith(p[1:]) for p in IGNORE_PATTERNS if p.startswith("*")
    )


def print_step(n: int, total: int, msg: str) -> None:
    print(f"\n[{n}/{total}] {msg}")


def detect_project_info(project_dir: Path) -> dict:
    """从 server.py 的 FastMCP 实例中提取插件信息。"""
    entry = project_dir / ENTRYPOINT
    if not entry.exists():
        return {}

    text = entry.read_text(encoding="utf-8", errors="replace")
    info: dict = {}

    # FastMCP("name", ...) 或 FastMCP(name="...")
    m = re.search(r'FastMCP\(\s*["\']([^"\']+)["\']', text)
    if m:
        info["id"] = m.group(1)

    # instructions=("...") 或 description="..."
    m = re.search(r'(?:instructions|description)\s*=\s*["\'\(]+(.*?)[\)"\']', text, re.DOTALL)
    if m:
        info["description"] = " ".join(m.group(1).split())[:200]

    return info


def find_py_files(project_dir: Path) -> list[Path]:
    """递归查找所有 .py 文件，排除忽略项。"""
    results = []
    for p in sorted(project_dir.rglob("*.py")):
        if any(should_skip(part) for part in p.relative_to(project_dir).parts):
            continue
        results.append(p)
    return results


def validate_project(project_dir: Path) -> list[str]:
    """校验项目结构，返回错误列表。"""
    errors = []
    entry = project_dir / ENTRYPOINT
    if not entry.exists():
        errors.append(f"缺少入口文件 {ENTRYPOINT}")
    else:
        text = entry.read_text(encoding="utf-8", errors="replace")
        if "FastMCP" not in text:
            errors.append(f"{ENTRYPOINT} 中未找到 FastMCP 实例")
        if "mcp.run(" not in text and ".run(" not in text:
            errors.append(f"{ENTRYPOINT} 中未找到 mcp.run() 调用")

    req = project_dir / "requirements.txt"
    if not req.exists():
        errors.append("缺少 requirements.txt")

    return errors


# ── 跨平台兼容性检查 ─────────────────────────────────────

# 已知需要 C 编译器的包——严格锁版在无编译器的平台（Windows）容易安装失败
_C_EXT_PKGS = {
    "greenlet", "numpy", "scipy", "pandas", "lxml", "pillow",
    "cryptography", "grpcio", "psycopg2", "cffi", "pyyaml",
    "markupsafe", "msgpack", "aiohttp", "uvloop",
}


def check_requirements_compat(project_dir: Path) -> list[str]:
    """检查 requirements.txt 跨平台兼容性，返回警告列表。"""
    warnings = []
    req = project_dir / "requirements.txt"
    if not req.exists():
        return warnings

    for line in req.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("-"):
            continue
        m = re.match(r"^([a-zA-Z0-9_.-]+)==(\S+)", line)
        if m:
            pkg = m.group(1).lower().replace("-", "_")
            if pkg in _C_EXT_PKGS:
                warnings.append(
                    f"{m.group(1)}=={m.group(2)} 严格锁定版本，"
                    f"可能导致部分平台安装失败。建议改为 >={m.group(2)}"
                )
    return warnings


def verify_zip_paths(project_dir: Path, zip_path: Path) -> list[str]:
    """校验 server.py 中引用的子目录是否存在于 zip 中。

    防止开发环境有 project/ 子目录但打包时丢失层级的典型错误。
    """
    warnings = []
    entry = project_dir / ENTRYPOINT
    if not entry.exists() or not zip_path.exists():
        return warnings

    text = entry.read_text(encoding="utf-8", errors="replace")

    # 收集 zip 中的顶级目录和文件
    with zipfile.ZipFile(zip_path, "r") as zf:
        zip_entries = set(zf.namelist())
    zip_top_dirs = {n.split("/")[0] for n in zip_entries if "/" in n}
    zip_top_files = {n for n in zip_entries if "/" not in n}
    zip_top = zip_top_dirs | zip_top_files

    # 匹配 PLUGIN_DIR / "xxx" 或 Path(__file__).parent / "xxx" 等模式
    pattern = (
        r"(?:PLUGIN_DIR|PROJECT_DIR|BASE_DIR|ROOT_DIR|"
        r"Path\(__file__\)(?:\.resolve\(\))?\.parent)"
        r'\s*/\s*["\']([^"\']+)["\']'
    )
    for m in re.finditer(pattern, text):
        ref = m.group(1)
        if ref in ("__pycache__", ".venv", "venv", "node_modules"):
            continue
        if ref not in zip_top:
            warnings.append(
                f'{ENTRYPOINT} 引用路径 "{ref}"，但 project.zip '
                f"中不存在此路径。安装后 server.py 将无法找到该目录/文件。"
            )

    return warnings


# ── 加密（Cython 编译）──────────────────────────────────

def encrypt_files(
    project_dir: Path,
    py_files: list[Path],
    skip_encrypt: list[str],
    staging_dir: Path,
) -> tuple[list[str], list[str]]:
    """编译 .py → .so/.pyd，返回 (加密文件列表, 明文文件列表)。"""
    always_plain = {ENTRYPOINT, "publish.py", "setup.py", "__init__.py"}
    skip_set = set(skip_encrypt) | always_plain

    to_encrypt = []
    plain_files = []

    for f in py_files:
        rel = str(f.relative_to(project_dir))
        name = f.name
        if name in skip_set or rel in skip_set:
            plain_files.append(rel)
        else:
            to_encrypt.append(f)

    if not to_encrypt:
        print("  ℹ 无需加密的文件")
        return [], [str(f.relative_to(project_dir)) for f in py_files]

    # 检查 Cython 是否安装
    try:
        import Cython  # noqa: F401
    except ImportError:
        print("  ⚠ Cython 未安装，正在安装...")
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", "cython", "-q"],
        )

    encrypted_names = []
    for f in to_encrypt:
        rel = f.relative_to(project_dir)
        module_name = f.stem
        work_dir = staging_dir / rel.parent
        work_dir.mkdir(parents=True, exist_ok=True)

        # 复制为 .pyx
        pyx_path = work_dir / f"{module_name}.pyx"
        shutil.copy2(f, pyx_path)

        # 编译
        print(f"  🔒 编译 {rel}...")
        setup_code = (
            "from setuptools import setup\n"
            "from Cython.Build import cythonize\n"
            f"setup(ext_modules=cythonize('{module_name}.pyx', "
            "compiler_directives={'language_level': '3'}))\n"
        )
        setup_file = work_dir / "_setup_tmp.py"
        setup_file.write_text(setup_code)

        result = subprocess.run(
            [sys.executable, str(setup_file), "build_ext", "--inplace"],
            cwd=str(work_dir),
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            print(f"  ❌ 编译失败: {rel}")
            print(f"     {result.stderr[:500]}")
            # 回退：保留明文
            plain_files.append(str(rel))
            continue

        # 收集编译产物
        so_files = list(work_dir.glob(f"{module_name}.cpython-*.so")) + \
                   list(work_dir.glob(f"{module_name}.cp*-*.pyd"))
        if so_files:
            encrypted_names.append(str(rel))
        else:
            print(f"  ⚠ 未找到编译产物: {rel}，保留明文")
            plain_files.append(str(rel))

        # 清理中间文件
        for tmp in [pyx_path, setup_file]:
            tmp.unlink(missing_ok=True)
        for c_file in work_dir.glob(f"{module_name}.c"):
            c_file.unlink(missing_ok=True)
        for build_dir in work_dir.glob("build"):
            shutil.rmtree(build_dir, ignore_errors=True)

    return encrypted_names, plain_files


# ── 打包 ─────────────────────────────────────────────────

def package_project(
    project_dir: Path,
    staging_dir: Path,
    plain_files: list[str],
) -> Path:
    """收集明文文件 + 编译产物 + vendor wheels → project.zip"""
    # 复制明文文件
    for rel in plain_files:
        src = project_dir / rel
        dst = staging_dir / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if src.exists():
            shutil.copy2(src, dst)

    # 复制非 .py 文件（配置、模板等）
    for f in sorted(project_dir.rglob("*")):
        if f.is_dir():
            continue
        rel = f.relative_to(project_dir)
        if any(should_skip(part) for part in rel.parts):
            continue
        if f.suffix == ".py":
            continue  # .py 已处理
        dst = staging_dir / rel
        if not dst.exists():
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(f, dst)

    # requirements.txt → vendor wheels
    req = staging_dir / "requirements.txt"
    if req.exists():
        vendor_dir = staging_dir / "_vendor"
        vendor_dir.mkdir(exist_ok=True)
        print("  📦 下载离线 wheel 包...")
        result = subprocess.run(
            [
                sys.executable, "-m", "pip", "download",
                "-r", str(req), "-d", str(vendor_dir),
                "--only-binary=:all:",
            ],
            capture_output=True, text=True,
        )
        if result.returncode != 0:
            # 尝试清华镜像
            subprocess.run(
                [
                    sys.executable, "-m", "pip", "download",
                    "-r", str(req), "-d", str(vendor_dir),
                    "--only-binary=:all:",
                    "-i", "https://pypi.tuna.tsinghua.edu.cn/simple",
                    "--trusted-host", "pypi.tuna.tsinghua.edu.cn",
                ],
                capture_output=True, text=True,
            )

    # 打 zip
    zip_path = project_dir / "project.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(staging_dir):
            dirs[:] = [d for d in dirs if not should_skip(d)]
            for fname in sorted(files):
                if should_skip(fname):
                    continue
                full = Path(root) / fname
                arcname = full.relative_to(staging_dir)
                zf.write(full, arcname)

    return zip_path


# ── Manifest 生成 ────────────────────────────────────────

def generate_manifest(
    project_dir: Path,
    staging_dir: Path,
    config: dict,
) -> dict:
    """生成 manifest.json。"""
    # 收集 staging 中的所有文件
    all_files = []
    for f in sorted(staging_dir.rglob("*")):
        if f.is_dir():
            continue
        rel = str(f.relative_to(staging_dir))
        if not should_skip(f.name):
            all_files.append(rel)

    # 检测 configFields
    config_fields = []
    entry = project_dir / ENTRYPOINT
    if entry.exists():
        text = entry.read_text(encoding="utf-8", errors="replace")
        for m in re.finditer(
            r'os\.environ\.get\(["\'](\w+)["\'](?:,\s*["\']([^"\']*)["\'])?\)',
            text,
        ):
            key = m.group(1)
            default = m.group(2) or ""
            if key not in ("PATH", "HOME", "USER", "LANG"):
                config_fields.append({
                    "key": key,
                    "label": key.replace("_", " ").title(),
                    "default": default,
                    "required": default == "",
                })

    manifest = {
        "id": config["id"],
        "name": config.get("name", config["id"]),
        "description": config.get("description", ""),
        "version": config["version"],
        "author": config.get("author", ""),
        "icon": config.get("icon", "🔧"),
        "runtime": "python",
        "entrypoint": ENTRYPOINT,
        "files": [],
        "env": {},
        "configFields": config_fields,
        "sourceArchive": "project.zip",
    }

    # 写到 staging
    manifest_path = staging_dir / "manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    return manifest


# ── 上传 ──────────────────────────────────────────────────

def upload_to_cloud(
    project_dir: Path,
    config: dict,
    manifest: dict,
) -> dict:
    """上传到 LoongClaw Cloud API。"""
    import urllib.request
    import urllib.error

    token = config.get("token", "")
    if not token:
        token = os.environ.get("LOONGCLAW_STORE_KEY", "")
    if not token:
        return {"status": "error", "step": "upload",
                "error": "缺少 Store Key。设置环境变量 LOONGCLAW_STORE_KEY 或在 .publish.json 中配置 token",
                "fix": "前往 https://loongclaw.net.cn/dev/ 申请开发者并生成 Store Key"}

    # 构造上传请求
    zip_path = project_dir / "project.zip"
    if not zip_path.exists():
        return {"status": "error", "step": "upload",
                "error": "project.zip 不存在",
                "fix": "检查打包步骤是否成功"}

    manifest_path = project_dir / "_staging" / "manifest.json"
    if not manifest_path.exists():
        manifest_path = project_dir / "manifest.json"

    # multipart/form-data 上传
    boundary = "----LoongClawUpload"
    body = b""

    # manifest.json 部分
    body += f"--{boundary}\r\n".encode()
    body += b'Content-Disposition: form-data; name="manifest"; filename="manifest.json"\r\n'
    body += b"Content-Type: application/json\r\n\r\n"
    body += json.dumps(manifest, ensure_ascii=False).encode("utf-8")
    body += b"\r\n"

    # project.zip 部分
    body += f"--{boundary}\r\n".encode()
    body += b'Content-Disposition: form-data; name="archive"; filename="project.zip"\r\n'
    body += b"Content-Type: application/zip\r\n\r\n"
    body += zip_path.read_bytes()
    body += b"\r\n"

    # accessType 部分
    body += f"--{boundary}\r\n".encode()
    body += b'Content-Disposition: form-data; name="accessType"\r\n\r\n'
    body += config.get("access", "public").encode()
    body += b"\r\n"

    body += f"--{boundary}--\r\n".encode()

    url = f"{CLOUD_API_BASE}{UPLOAD_ENDPOINT}"
    req = urllib.request.Request(
        url,
        data=body,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": f"multipart/form-data; boundary={boundary}",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            return {"status": "success", **result}
    except urllib.error.HTTPError as e:
        err_body = e.read().decode("utf-8", errors="replace")
        return {"status": "error", "step": "upload",
                "error": f"HTTP {e.code}: {err_body[:300]}",
                "fix": "检查 token 是否有效，或联系管理员"}
    except urllib.error.URLError as e:
        return {"status": "error", "step": "upload",
                "error": f"网络错误: {e.reason}",
                "fix": "检查网络连接和 CLOUD_API_BASE 地址"}


# ── 配置管理 ─────────────────────────────────────────────

def load_config(project_dir: Path) -> dict | None:
    cfg_path = project_dir / CONFIG_FILE
    if cfg_path.exists():
        try:
            return json.loads(cfg_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
    return None


def save_config(project_dir: Path, config: dict) -> None:
    cfg_path = project_dir / CONFIG_FILE
    # 不保存 token 到配置文件（安全）
    safe = {k: v for k, v in config.items() if k != "token"}
    cfg_path.write_text(
        json.dumps(safe, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


# ── 交互式配置 ───────────────────────────────────────────

def interactive_config(project_dir: Path, detected: dict) -> dict:
    """交互式引导配置。"""
    print("\n═══ LoongClaw MCP 发布工具 ═══\n")

    config: dict = {}

    # ID
    default_id = detected.get("id", project_dir.name)
    val = input(f"▶ 插件 ID [{default_id}]: ").strip()
    config["id"] = val if val else default_id

    # 名称
    default_name = config["id"]
    val = input(f"▶ 插件名称 [{default_name}]: ").strip()
    config["name"] = val if val else default_name

    # 描述
    default_desc = detected.get("description", "")
    if default_desc:
        print(f"  （自动检测到描述：{default_desc[:60]}...）")
    val = input(f"▶ 插件描述 [{default_desc[:60] or '无'}]: ").strip()
    config["description"] = val if val else default_desc

    # 版本
    val = input("▶ 版本号 [1.0.0]: ").strip()
    config["version"] = val if val else "1.0.0"

    # 作者
    val = input("▶ 作者名: ").strip()
    config["author"] = val

    # 图标
    val = input("▶ 图标 emoji [🔧]: ").strip()
    config["icon"] = val if val else "🔧"

    # 不加密文件
    py_files = find_py_files(project_dir)
    encryptable = [
        str(f.relative_to(project_dir)) for f in py_files
        if f.name not in {ENTRYPOINT, "publish.py", "setup.py", "__init__.py"}
    ]
    if encryptable:
        print(f"\n▶ 以下 {len(encryptable)} 个 .py 文件将被加密编译：")
        for name in encryptable:
            print(f"    {name}")
        val = input("  不需要加密的文件（逗号分隔，留空=全加密）: ").strip()
        config["skipEncrypt"] = [s.strip() for s in val.split(",") if s.strip()] if val else []
    else:
        config["skipEncrypt"] = []

    # 访问类型
    print("\n▶ 访问类型：")
    print("  [1] 公开（所有用户免费使用）")
    print("  [2] 付费（需联系商务开通）")
    val = input("  选择 [1]: ").strip()
    config["access"] = "private" if val == "2" else "public"

    # 上传
    val = input("\n▶ 自动上传到 LoongClaw 服务器？[Y/n]: ").strip().lower()
    config["upload"] = val != "n"

    if config["upload"]:
        val = input("▶ LoongClaw Store Key（环境变量 LOONGCLAW_STORE_KEY 也可，前往 loongclaw.net.cn/dev/ 获取）: ").strip()
        if val:
            config["token"] = val

    return config


# ── 主流程 ────────────────────────────────────────────────

def run(config: dict, project_dir: Path, json_output: bool = False) -> dict:
    """执行完整发布流程，返回结果字典。"""
    total_steps = 6 if config.get("upload") else 5
    result: dict = {"status": "success", "steps": {}}

    # Step 1: 校验
    print_step(1, total_steps, "校验项目结构...")
    errors = validate_project(project_dir)
    if errors:
        result = {
            "status": "error", "step": "validate",
            "errors": errors,
            "fix": "; ".join(errors),
        }
        if json_output:
            print(json.dumps(result, ensure_ascii=False))
        else:
            for e in errors:
                print(f"  ❌ {e}")
        return result
    print("  ✅ 项目结构正确")

    # 跨平台兼容性警告（不阻断，但在 JSON 中记录）
    compat_warnings = check_requirements_compat(project_dir)
    if compat_warnings:
        result["warnings"] = compat_warnings
        for w in compat_warnings:
            print(f"  ⚠ {w}")
    result["steps"]["validate"] = "ok"

    # Step 2: 准备 staging
    staging_dir = project_dir / "_staging"
    if staging_dir.exists():
        shutil.rmtree(staging_dir)
    staging_dir.mkdir()

    # Step 3: 加密编译
    print_step(2, total_steps, "Cython 加密编译...")
    py_files = find_py_files(project_dir)
    encrypted, plain = encrypt_files(
        project_dir, py_files,
        config.get("skipEncrypt", []),
        staging_dir,
    )
    print(f"  ✅ 加密 {len(encrypted)} 个，明文 {len(plain)} 个")
    result["steps"]["encrypt"] = {"encrypted": len(encrypted), "plain": len(plain)}

    # Step 4: 打包
    print_step(3, total_steps, "打包 project.zip...")
    zip_path = package_project(project_dir, staging_dir, plain)
    size_mb = zip_path.stat().st_size / 1024 / 1024
    print(f"  ✅ {zip_path.name} ({size_mb:.1f} MB)")
    result["steps"]["package"] = {"size_mb": round(size_mb, 1)}

    # 路径一致性校验
    zip_warnings = verify_zip_paths(project_dir, zip_path)
    if zip_warnings:
        result["status"] = "error"
        result["step"] = "verify"
        result["errors"] = zip_warnings
        result["fix"] = (
            "server.py 引用的路径在打包后不存在。"
            "请确保 server.py 中的路径引用与 project.zip 的目录结构一致。"
        )
        if json_output:
            print(json.dumps(result, ensure_ascii=False))
        else:
            for w in zip_warnings:
                print(f"  ❌ {w}")
            print("  💡 常见原因：开发环境中 project.zip 从子目录内部打包，"
                  "导致 zip 中缺少了一层目录前缀。")
        # 清理 staging 但保留 zip 以便排查
        shutil.rmtree(staging_dir, ignore_errors=True)
        return result

    # Step 5: 生成 manifest
    print_step(4, total_steps, "生成 manifest.json...")
    manifest = generate_manifest(project_dir, staging_dir, config)
    print(f"  ✅ {manifest['id']} v{manifest['version']}")
    result["steps"]["manifest"] = manifest

    # Step 6: 上传（可选）
    if config.get("upload"):
        print_step(5, total_steps, "上传到 LoongClaw 服务器...")
        upload_result = upload_to_cloud(project_dir, config, manifest)
        if upload_result["status"] == "error":
            result["status"] = "error"
            result["step"] = "upload"
            result["error"] = upload_result["error"]
            result["fix"] = upload_result.get("fix", "")
            if json_output:
                print(json.dumps(result, ensure_ascii=False))
            else:
                print(f"  ❌ {upload_result['error']}")
            # 清理 staging 但保留 zip
            shutil.rmtree(staging_dir, ignore_errors=True)
            return result
        print("  ✅ 上传成功")
        result["steps"]["upload"] = "ok"

    # 保存配置
    save_config(project_dir, config)

    # 清理
    shutil.rmtree(staging_dir, ignore_errors=True)

    result["version"] = config["version"]
    result["files_encrypted"] = len(encrypted)
    result["uploaded"] = config.get("upload", False)

    if json_output:
        print(json.dumps(result, ensure_ascii=False))
    else:
        print(f"\n{'═' * 50}")
        print(f"  发布完成！ {config['id']} v{config['version']}")
        if config.get("access") == "private":
            print("  📌 访问类型: 付费（需商务开通）")
        else:
            print("  📌 访问类型: 公开")
        print(f"{'═' * 50}")

    return result


def main() -> None:
    parser = argparse.ArgumentParser(description="LoongClaw MCP 一键发布工具")
    parser.add_argument("--auto", action="store_true",
                        help="自动模式，使用 .publish.json 或命令行参数")
    parser.add_argument("--reconfigure", action="store_true",
                        help="重新配置（忽略 .publish.json）")
    parser.add_argument("--json-output", action="store_true",
                        help="JSON 格式输出（适合 AI 解析）")
    parser.add_argument("--id", type=str, help="插件 ID")
    parser.add_argument("--name", type=str, help="插件名称")
    parser.add_argument("--version", type=str, help="版本号")
    parser.add_argument("--access", choices=["public", "private"], help="访问类型")
    parser.add_argument("--skip-encrypt", type=str, default="",
                        help="不加密的文件（逗号分隔）")
    parser.add_argument("--upload", action="store_true", help="上传到服务器")
    parser.add_argument("--no-upload", action="store_true", help="不上传")
    parser.add_argument("--token", type=str, help="LoongClaw Store Key")
    parser.add_argument("--dir", type=str, default=".",
                        help="项目目录（默认当前目录）")
    args = parser.parse_args()

    project_dir = Path(args.dir).resolve()
    json_output = args.json_output

    if args.auto:
        # 自动模式：优先命令行参数 > .publish.json > 自动检测
        saved = load_config(project_dir) or {}
        detected = detect_project_info(project_dir)

        config = {
            "id": args.id or saved.get("id") or detected.get("id") or project_dir.name,
            "name": args.name or saved.get("name") or saved.get("id", project_dir.name),
            "version": args.version or saved.get("version", "1.0.0"),
            "description": saved.get("description") or detected.get("description", ""),
            "author": saved.get("author", ""),
            "icon": saved.get("icon", "🔧"),
            "access": args.access or saved.get("access", "public"),
            "skipEncrypt": (
                [s.strip() for s in args.skip_encrypt.split(",") if s.strip()]
                if args.skip_encrypt
                else saved.get("skipEncrypt", [])
            ),
            "upload": args.upload or (not args.no_upload and saved.get("upload", False)),
            "token": args.token or os.environ.get("LOONGCLAW_STORE_KEY", ""),
        }
    elif args.reconfigure or not load_config(project_dir):
        # 交互模式
        detected = detect_project_info(project_dir)
        config = interactive_config(project_dir, detected)
    else:
        # 有配置文件 → 直接用
        config = load_config(project_dir) or {}
        if not config.get("id"):
            detected = detect_project_info(project_dir)
            config = interactive_config(project_dir, detected)

    run(config, project_dir, json_output)


if __name__ == "__main__":
    main()
