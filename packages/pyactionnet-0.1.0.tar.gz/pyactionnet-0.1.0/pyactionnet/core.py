"""
PyActionNet - Python client for ActionNet P2P.

Connects to the same WebSocket tracker as ActionNetJS and establishes
a WebRTC data channel for peer-to-peer communication with browser peers.

Usage:
    from pyactionnet import PyActionNet
    import asyncio

    client = PyActionNet("app-id-00000", "PythonPlayer")

    @client.on("connected")
    def on_connected(peer_id):
        print(f"Connected to {peer_id}")

    @client.on("message")
    def on_message(data):
        print(f"Got: {data}")
        client.send({"reply": "hello from python"})

    async def main():
        await client.connect()

    asyncio.run(main())
"""
import asyncio
import hashlib
import json
import logging
import uuid

import websockets

log = logging.getLogger("pyactionnet")


class PyActionNet:
    """
    ActionNet P2P client for Python.

    Connects to the same WebSocket tracker as ActionNetJS and establishes
    a WebRTC data channel for peer-to-peer communication with browser peers.
    """

    # Public WebSocket trackers used by ActionNetJS
    TRACKER_URLS = [
        "wss://tracker.openwebtorrent.com/",
        "wss://tracker.btorrent.xyz/",
        "wss://tracker.fastcast.nz/",
    ]

    def __init__(self, app_id: str, username: str = "Player"):
        """
        Args:
            app_id: Application/game ID (must match browser peers).
            username: Display name for this peer.
        """
        self.app_id = app_id
        self.username = username
        self.peer_id = f"peer_{uuid.uuid4().hex[:9]}"
        self.infohash = hashlib.sha1(app_id.encode()).hexdigest()

        self._ws = None
        self._pc = None
        self._data_channel = None
        self._connected_peer = None
        self._incoming_pc = None
        self._incoming_channel = None
        self._handlers = {}

    def on(self, event, callback=None):
        """
        Register an event handler.

        Args:
            event: Event name ("connected", "disconnected", "message", "peer_confirmed").
            callback: Function to call. Can be omitted to use as decorator.

        Events:
            connected(peer_id): Connected to a peer.
            disconnected(peer_id): Peer disconnected.
            message(data): Received data from peer (dict or str).
            peer_confirmed(data): Handshake received (contains peerId, username, applicationId).
        """
        if callback is None:
            def decorator(fn):
                self._handlers.setdefault(event, []).append(fn)
            return decorator
        self._handlers.setdefault(event, []).append(callback)

    def _emit(self, event, *args):
        for cb in self._handlers.get(event, []):
            try:
                cb(*args)
            except Exception as e:
                log.error(f"Handler error on {event}: {e}")

    async def connect(self, tracker_url=None):
        """
        Connect to the tracker and wait for a peer connection.

        Blocks until a peer is found and connected, or all trackers fail.

        Args:
            tracker_url: Optional specific tracker URL. If None, tries all
                        public trackers in order.

        Raises:
            RuntimeError: If no tracker is reachable.
        """
        if tracker_url:
            urls = [tracker_url]
        else:
            urls = self.TRACKER_URLS

        log.info(f"Peer ID: {self.peer_id}")
        log.info(f"Infohash: {self.infohash}")

        # Create WebRTC peer connection
        from aiortc import RTCPeerConnection
        self._pc = RTCPeerConnection()

        self._pc.on("icecandidate", self._on_ice_candidate)

        # Create outgoing data channel
        self._data_channel = self._pc.createDataChannel("app", ordered=True)
        self._data_channel.on("open", self._on_dc_open)
        self._data_channel.on("close", self._on_dc_close)
        self._data_channel.on("message", self._on_dc_message)

        # Create WebRTC offer
        offer = await self._pc.createOffer()
        await self._pc.setLocalDescription(offer)

        # Wait for ICE gathering to complete
        await self._wait_for_ice()
        self._local_offer = self._pc.localDescription
        self._local_offer_id = uuid.uuid4().hex

        # Connect to tracker
        ws = None
        for url in urls:
            try:
                ws = await websockets.connect(url)
                log.info(f"Connected to tracker: {url}")
                break
            except Exception as e:
                log.warning(f"Failed to connect to {url}: {e}")

        if not ws:
            raise RuntimeError("Could not connect to any tracker")

        self._ws = ws

        # Announce with our offer
        announce_msg = {
            "action": "announce",
            "info_hash": self.infohash,
            "peer_id": self.peer_id,
            "numwant": 10,
            "username": self.username,
            "offers": [
                {
                    "offer_id": self._local_offer_id,
                    "offer": {
                        "type": self._local_offer.type,
                        "sdp": self._local_offer.sdp,
                    },
                }
            ],
        }
        await self._ws.send(json.dumps(announce_msg))

        # Listen for tracker messages (blocks until disconnected)
        await self._listen_for_tracker()

    async def send(self, data):
        """
        Send data to the connected peer.

        Args:
            data: Dict or string to send.

        Returns:
            True if sent, False if data channel is not open.
        """
        if not self._data_channel or self._data_channel.readyState != "open":
            return False
        msg = data if isinstance(data, str) else json.dumps(data)
        self._data_channel.send(msg)
        return True

    async def disconnect(self):
        """Close all connections."""
        if self._ws:
            await self._ws.close()
        if self._pc:
            await self._pc.close()
        if self._incoming_pc:
            await self._incoming_pc.close()

    # ---- Internal: WebRTC ----

    async def _wait_for_ice(self):
        while self._pc.iceGatheringState != "complete":
            await asyncio.sleep(0.1)

    async def _on_ice_candidate(self, candidate):
        pass

    def _on_dc_open(self):
        self._emit("connected", self._connected_peer)
        handshake = {
            "type": "handshake",
            "peerId": self.peer_id,
            "username": self.username,
            "applicationId": self.app_id,
        }
        self._data_channel.send(json.dumps(handshake))

    def _on_dc_close(self):
        self._emit("disconnected", self._connected_peer)
        self._connected_peer = None

    def _on_dc_message(self, message):
        try:
            data = json.loads(message)
            if data.get("type") == "handshake":
                self._emit("peer_confirmed", data)
            else:
                self._emit("message", data)
        except json.JSONDecodeError:
            self._emit("message", {"type": "text", "data": message})

    # ---- Internal: Tracker Protocol ----

    async def _listen_for_tracker(self):
        try:
            async for raw in self._ws:
                msg = json.loads(raw)

                if msg.get("offer") and msg.get("peer_id"):
                    await self._handle_incoming_offer(msg)
                elif msg.get("answer") and msg.get("peer_id"):
                    await self._handle_incoming_answer(msg)
                elif msg.get("action") == "announce":
                    pass  # Announce response, no action needed
                elif msg.get("failure reason"):
                    log.error(f"Tracker failure: {msg['failure reason']}")

        except websockets.exceptions.ConnectionClosed:
            pass

    async def _handle_incoming_offer(self, msg):
        peer_id = msg["peer_id"]
        offer_data = msg["offer"]
        offer_id = msg.get("offer_id", "unknown")

        from aiortc import RTCPeerConnection

        incoming_pc = RTCPeerConnection()
        incoming_channel = None

        @incoming_pc.on("datachannel")
        def on_dc(channel):
            nonlocal incoming_channel
            incoming_channel = channel
            channel.on("open", self._on_incoming_dc_open)
            channel.on("close", self._on_incoming_dc_close)
            channel.on("message", self._on_incoming_dc_message)

        remote_offer = type("SDP", (), {"type": "offer", "sdp": offer_data["sdp"]})()
        await incoming_pc.setRemoteDescription(remote_offer)

        answer = await incoming_pc.createAnswer()
        await incoming_pc.setLocalDescription(answer)

        while incoming_pc.iceGatheringState != "complete":
            await asyncio.sleep(0.1)

        local_answer = incoming_pc.localDescription

        self._incoming_pc = incoming_pc
        self._incoming_channel = incoming_channel
        self._connected_peer = peer_id

        answer_msg = {
            "action": "announce",
            "info_hash": self.infohash,
            "peer_id": self.peer_id,
            "to_peer_id": peer_id,
            "offer_id": offer_id,
            "answer": {
                "type": local_answer.type,
                "sdp": local_answer.sdp,
            },
        }
        await self._ws.send(json.dumps(answer_msg))

    async def _handle_incoming_answer(self, msg):
        peer_id = msg["peer_id"]
        answer_data = msg["answer"]

        remote_answer = type("SDP", (), {"type": "answer", "sdp": answer_data["sdp"]})()
        await self._pc.setRemoteDescription(remote_answer)

        self._connected_peer = peer_id

    def _on_incoming_dc_open(self):
        self._data_channel = self._incoming_channel
        self._emit("connected", self._connected_peer)
        handshake = {
            "type": "handshake",
            "peerId": self.peer_id,
            "username": self.username,
            "applicationId": self.app_id,
        }
        self._data_channel.send(json.dumps(handshake))

    def _on_incoming_dc_close(self):
        self._emit("disconnected", self._connected_peer)
        self._connected_peer = None

    def _on_incoming_dc_message(self, message):
        try:
            data = json.loads(message)
            if data.get("type") == "handshake":
                self._emit("peer_confirmed", data)
            else:
                self._emit("message", data)
        except json.JSONDecodeError:
            self._emit("message", {"type": "text", "data": message})
