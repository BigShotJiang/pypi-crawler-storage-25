# PyActionNet

Python client for ActionNet P2P multiplayer networking.

Connects to the same WebSocket tracker as [ActionNetJS](https://github.com/) and establishes a WebRTC data channel for peer-to-peer communication with browser peers.

Zero server setup. No infrastructure. Just Python talking to JavaScript over WebRTC through public trackers.

## Installation

```bash
pip install .
```

Or install dependencies manually:

```bash
pip install aiortc websockets
```

## Quick Start

```python
from pyactionnet import PyActionNet
import asyncio

client = PyActionNet("my-game-1", "Player1")

@client.on("connected")
def on_connected(peer_id):
    print(f"Connected to {peer_id}")

@client.on("message")
def on_message(data):
    print(f"Got: {data}")
    client.send({"reply": "hello"})

async def main():
    await client.connect()

asyncio.run(main())
```

## Events

- `connected(peer_id)` - WebRTC data channel opened with peer
- `disconnected(peer_id)` - Peer disconnected
- `message(data)` - Received data from peer (dict or str)
- `peer_confirmed(data)` - Handshake received (contains peerId, username, applicationId)

## API

- `PyActionNet(app_id, username="Player")` - Create a new client
- `client.on(event, callback)` - Register event handler (also usable as decorator)
- `await client.connect(tracker_url=None)` - Connect to tracker and wait for peer
- `await client.send(data)` - Send data to connected peer (dict or str)
- `await client.disconnect()` - Close all connections

## Architecture

PyActionNet connects to the same public WebSocket trackers as ActionNetJS:

- `wss://tracker.openwebtorrent.com/`
- `wss://tracker.btorrent.xyz/`
- `wss://tracker.fastcast.nz/`

The flow:

1. Python creates a WebRTC offer and connects to a tracker via WebSocket
2. Tracker relays the offer to browser peers (ActionNetJS)
3. Browser responds with a WebRTC answer through the tracker
4. Direct P2P data channel is established — game data flows peer-to-peer

No server needed. No bridge. The tracker only handles WebRTC signaling.

## Example

Run the example to test browser↔Python P2P:

```bash
python examples/test_link.py
```

Open `demo.html` from ActionNetJS in your browser, join with app ID `app-id-00000`, and the Python client will find it.

## Testing

```bash
pytest
```

## License

MIT
