from pyactionnet import PyActionNet


def test_create_client():
    client = PyActionNet("test-app", "TestPlayer")
    assert client.app_id == "test-app"
    assert client.username == "TestPlayer"
    assert client.peer_id.startswith("peer_")
    assert len(client.infohash) == 40  # SHA-1 hex digest


def test_client_events():
    client = PyActionNet("test-app")
    received = []

    @client.on("message")
    def handler(data):
        received.append(data)

    client._emit("message", {"hello": "world"})
    assert len(received) == 1
    assert received[0] == {"hello": "world"}


def test_send_requires_open_channel():
    import asyncio
    client = PyActionNet("test-app")
    # Without a real connection, send should return False
    result = asyncio.run(client.send({"test": "data"}))
    assert result is False
