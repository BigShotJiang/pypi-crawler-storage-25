// ABOUTME: Chat panel UI module — tabbed chat panel for ACP agent conversations.
// ABOUTME: Manages chat tabs, WebSocket connections, streaming text, and tool call cards.

(function () {
  "use strict";

  // --- Markdown setup ---
  marked.setOptions({
    highlight: function (code, lang) {
      if (lang && hljs.getLanguage(lang)) {
        return hljs.highlight(code, { language: lang }).value;
      }
      return hljs.highlightAuto(code).value;
    },
    breaks: true,
    gfm: true,
  });

  // --- State ---
  var chatTabs = {};
  var activeChatTabId = null;
  var chatTabIdCounter = 0;

  // --- DOM refs ---
  var $chatPanel = document.getElementById("chat-panel");
  var $chatTabs = document.getElementById("chat-tabs");
  var $chatMessages = document.getElementById("chat-messages");
  var $chatInput = document.getElementById("chat-input");
  var $chatSend = document.getElementById("chat-send");
  var $chatStop = document.getElementById("chat-stop");
  var $chatCost = document.getElementById("chat-cost");
  var $imagePreview = document.getElementById("chat-image-preview");
  var $chatEmpty = document.getElementById("chat-empty");

  if ($chatMessages) {
    $chatMessages.addEventListener("scroll", trackScrollPosition);
  }

  // --- Helpers ---

  function escapeHtml(s) {
    var div = document.createElement("div");
    div.textContent = s;
    return div.innerHTML;
  }

  function renderMarkdown(text) {
    return DOMPurify.sanitize(marked.parse(text || ""));
  }

  function generateChatTabId() {
    return "chat-" + (chatTabIdCounter++);
  }

  // Only auto-scroll if user is already near the bottom (within 80px).
  // This lets users scroll up to read older messages while output streams.
  var userNearBottom = true;

  function scrollToBottom() {
    if (!$chatMessages) return;
    if (!userNearBottom) return;
    $chatMessages.scrollTop = $chatMessages.scrollHeight;
  }

  function trackScrollPosition() {
    if (!$chatMessages) return;
    var threshold = 80;
    var distFromBottom = $chatMessages.scrollHeight - $chatMessages.scrollTop - $chatMessages.clientHeight;
    userNearBottom = distFromBottom <= threshold;
  }

  // --- Tool call icons by kind ---
  var TOOL_ICONS = {
    read: "&#128196;",     // page
    edit: "&#9998;",       // pencil
    execute: "&#9654;",    // play
    search: "&#128269;",   // magnifier
    "delete": "&#128465;", // trash
    think: "&#128161;",    // lightbulb
    fetch: "&#127760;",    // globe
  };

  // --- Empty state ---

  function updateEmptyState() {
    if (!$chatEmpty) return;
    var hasTabs = Object.keys(chatTabs).length > 0;
    $chatEmpty.classList.toggle("hidden", hasTabs);
    // Hide input bar and header when no tabs
    var inputBar = $chatPanel.querySelector(".chat-input-bar");
    if (inputBar) inputBar.style.display = hasTabs ? "" : "none";
    var header = $chatPanel.querySelector(".chat-panel-header");
    if (header) header.style.display = hasTabs ? "" : "none";
    var body = $chatPanel.querySelector(".chat-body");
    if (body) body.style.display = hasTabs ? "" : "none";
  }

  // --- Tab Management ---

  function renderChatTabs() {
    $chatTabs.innerHTML = "";
    Object.keys(chatTabs).forEach(function (tabId) {
      var tab = chatTabs[tabId];
      var el = document.createElement("div");
      el.className = "chat-tab" + (tabId === activeChatTabId ? " active" : "") +
        (tab.streaming ? " streaming" : "");
      el.innerHTML =
        '<span class="chat-tab-title">' + escapeHtml(tab.title) + "</span>" +
        '<span class="chat-tab-close">&times;</span>';

      el.querySelector(".chat-tab-title").addEventListener("click", function () {
        switchChatTab(tabId);
      });
      el.querySelector(".chat-tab-close").addEventListener("click", function (e) {
        e.stopPropagation();
        closeChatTab(tabId);
      });
      $chatTabs.appendChild(el);
    });
  }

  function switchChatTab(tabId) {
    if (!chatTabs[tabId]) return;
    if (activeChatTabId && chatTabs[activeChatTabId]) {
      chatTabs[activeChatTabId].container.classList.remove("active");
    }
    activeChatTabId = tabId;
    chatTabs[tabId].container.classList.add("active");
    renderChatTabs();
    renderTurnSidebar(chatTabs[tabId]);
    updateInputState();
    renderImagePreview();
    scrollToBottom();
    $chatInput.focus();
  }

  function closeChatTab(tabId) {
    var tab = chatTabs[tabId];
    if (!tab) return;
    var closedSessionId = tab.sessionId;
    if (tab.ws && tab.ws.readyState === WebSocket.OPEN) {
      tab.ws.close();
    }
    if (tab.container && tab.container.parentNode) {
      tab.container.parentNode.removeChild(tab.container);
    }
    delete chatTabs[tabId];
    if (closedSessionId) {
      emitSessionEvent("agent-session-closed", { sessionId: closedSessionId });
    }

    var remaining = Object.keys(chatTabs);
    if (remaining.length > 0) {
      switchChatTab(remaining[remaining.length - 1]);
    } else {
      activeChatTabId = null;
    }
    renderChatTabs();
    updateEmptyState();
  }

  // --- Chat Tab Creation ---

  function createChatTab(title, agent, cwd, existingSessionId, sessionSummary) {
    var tabId = generateChatTabId();

    var container = document.createElement("div");
    container.className = "chat-tab-container";
    $chatMessages.appendChild(container);

    var tabData = {
      id: tabId,
      ws: null,
      sessionId: null,
      agent: agent,
      cwd: cwd,
      container: container,
      title: title,
      streaming: false,
      messageQueue: [],
      currentTextAccum: "",
      currentTextEl: null,
      thinkingAccum: "",
      thinkingEl: null,
      renderScheduled: false,
      sessionSummary: sessionSummary || null,
      userTurns: [],
      activeTurnIndex: -1,
      pendingImages: [],
    };
    chatTabs[tabId] = tabData;

    // Hide previous active tab
    if (activeChatTabId && chatTabs[activeChatTabId]) {
      chatTabs[activeChatTabId].container.classList.remove("active");
    }
    activeChatTabId = tabId;
    container.classList.add("active");

    renderChatTabs();
    renderTurnSidebar(tabData);
    updateInputState();
    renderImagePreview();
    updateEmptyState();
    connectWebSocket(tabData, existingSessionId);
    $chatInput.focus();

    return tabId;
  }

  // --- WebSocket ---

  function connectWebSocket(tabData, sessionId) {
    var wsProtocol = location.protocol === "https:" ? "wss:" : "ws:";
    var wsUrl = wsProtocol + "//" + location.host + "/ws/chat";
    var ws = new WebSocket(wsUrl);
    tabData.ws = ws;

    ws.onopen = function () {
      ws.send(JSON.stringify({
        type: "start",
        agent: tabData.agent,
        cwd: tabData.cwd,
        sessionId: sessionId || undefined,
      }));
    };

    ws.onmessage = function (evt) {
      try {
        var msg = JSON.parse(evt.data);
        handleServerMessage(tabData, msg);
      } catch (e) {
        console.error("Failed to parse chat message:", e);
      }
    };

    ws.onclose = function () {
      tabData.streaming = false;
      updateInputState();
      renderChatTabs();
    };

    ws.onerror = function () {
      appendSystemMessage(tabData, "Connection error");
    };
  }

  // --- Message Routing ---

  function handleServerMessage(tabData, msg) {
    switch (msg.type) {
      case "session_init":
        tabData.sessionId = msg.sessionId;
        if (msg.agentInfo) {
          appendSystemMessage(tabData, msg.agentInfo.title + " connected");
        }
        if (!msg.historyLoaded && tabData.sessionSummary) {
          appendInfoBanner(tabData, "Previous messages not available. " + tabData.sessionSummary);
        }
        emitSessionEvent("agent-session-started", {
          sessionId: msg.sessionId,
          agent: tabData.agent,
          cwd: tabData.cwd,
          title: tabData.title,
        });
        break;

      case "update":
        handleUpdate(tabData, msg);
        break;

      case "turn_complete":
        finalizeAssistantMessage(tabData);
        collapseCompletedTools(tabData);
        tabData.streaming = false;
        flushMessageQueue(tabData);
        updateInputState();
        renderChatTabs();
        emitSessionEvent("agent-session-updated", {
          sessionId: tabData.sessionId,
          streaming: tabData.streaming,
        });
        break;

      case "error":
        appendSystemMessage(tabData, "Error: " + (msg.message || "Unknown error"));
        tabData.streaming = false;
        updateInputState();
        renderChatTabs();
        break;

      case "auth_required":
        appendAuthBanner(tabData, msg);
        break;

      case "session_terminated":
        tabData.streaming = false;
        tabData.terminated = true;
        appendSessionTerminated(tabData);
        updateInputState();
        renderChatTabs();
        break;

      case "session_restarted":
        tabData.terminated = false;
        tabData.sessionId = msg.sessionId || tabData.sessionId;
        appendSystemMessage(tabData, "Session resumed");
        break;

      default:
        console.log("Unknown chat message type:", msg.type);
    }
  }

  function handleUpdate(tabData, msg) {
    var su = msg.sessionUpdate;
    switch (su) {
      case "agent_message_chunk":
        var text = (msg.content && msg.content.text) || "";
        if (text) appendAgentText(tabData, text);
        break;

      case "agent_thought_chunk":
        var thought = (msg.content && msg.content.text) || "";
        if (thought) appendThinking(tabData, thought);
        break;

      case "user_message_chunk":
        var userText = (msg.content && msg.content.text) || "";
        if (userText) {
          var localCmd = parseLocalCommand(userText);
          if (localCmd) {
            appendLocalCommand(tabData, localCmd);
          } else {
            appendUserBubble(tabData, userText);
          }
        }
        break;

      case "tool_call":
        renderToolCall(tabData, msg);
        break;

      case "tool_call_update":
        updateToolCall(tabData, msg);
        break;

      case "usage_update":
        renderUsage(msg);
        break;

      case "plan":
        renderPlan(tabData, msg.entries || []);
        break;

      default:
        break;
    }
  }

  // --- Local Command Detection ---

  // Matches <command-name>/foo</command-name> with optional args/message tags
  var LOCAL_CMD_RE = /<command-name>\s*(.+?)\s*<\/command-name>/;
  // Matches <local-command-stdout>...</local-command-stdout>
  var LOCAL_STDOUT_RE = /<local-command-stdout>([\s\S]*?)<\/local-command-stdout>/;
  // Matches <local-command-caveat>...</local-command-caveat> (system boilerplate)
  var LOCAL_CAVEAT_RE = /^\s*<local-command-caveat>/;

  function parseLocalCommand(text) {
    if (LOCAL_CAVEAT_RE.test(text)) return { type: "caveat" };
    var cmdMatch = LOCAL_CMD_RE.exec(text);
    if (cmdMatch) return { type: "command", name: cmdMatch[1].trim() };
    var stdoutMatch = LOCAL_STDOUT_RE.exec(text);
    if (stdoutMatch) return { type: "stdout", text: stdoutMatch[1].trim() };
    return null;
  }

  function appendLocalCommand(tabData, parsed) {
    if (parsed.type === "caveat") return; // hide system boilerplate

    var el = document.createElement("div");
    el.className = "chat-local-command";

    if (parsed.type === "command") {
      el.innerHTML =
        '<span class="chat-local-cmd-icon">&#9654;</span>' +
        '<span class="chat-local-cmd-name">' + escapeHtml(parsed.name) + "</span>";
    } else if (parsed.type === "stdout") {
      var output = parsed.text || "(no output)";
      el.innerHTML =
        '<span class="chat-local-cmd-output">' + escapeHtml(output) + "</span>";
    }
    tabData.container.appendChild(el);
    scrollToBottom();
  }

  // --- Rendering: User Messages ---

  function appendUserBubble(tabData, text, images) {
    finalizeAssistantMessage(tabData);

    var turnIndex = tabData.userTurns.length;
    var bubble = document.createElement("div");
    bubble.className = "chat-bubble user";
    bubble.setAttribute("data-turn-index", turnIndex);
    if (images && images.length) {
      var imgStrip = document.createElement("div");
      imgStrip.className = "chat-bubble-images";
      images.forEach(function (img) {
        var el = document.createElement("img");
        el.src = "data:" + img.mimeType + ";base64," + img.data;
        el.className = "chat-bubble-img";
        imgStrip.appendChild(el);
      });
      bubble.appendChild(imgStrip);
    }
    if (text) {
      var textEl = document.createElement("span");
      textEl.textContent = text;
      bubble.appendChild(textEl);
    }
    tabData.container.appendChild(bubble);

    tabData.userTurns.push({ index: turnIndex, element: bubble, text: text || "(image)" });
    renderTurnSidebar(tabData);
    scrollToBottom();
  }

  // --- Rendering: Agent Text (streaming) ---

  function appendAgentText(tabData, text) {
    finalizeThinking(tabData);

    tabData.currentTextAccum += text;
    if (!tabData.currentTextEl) {
      var bubble = document.createElement("div");
      bubble.className = "chat-bubble assistant";
      var content = document.createElement("div");
      content.className = "chat-md-content";
      bubble.appendChild(content);
      tabData.container.appendChild(bubble);
      tabData.currentTextEl = content;
    }
    scheduleRender(tabData);
  }

  function scheduleRender(tabData) {
    if (tabData.renderScheduled) return;
    tabData.renderScheduled = true;
    requestAnimationFrame(function () {
      tabData.renderScheduled = false;
      if (tabData.currentTextEl) {
        tabData.currentTextEl.innerHTML = renderMarkdown(tabData.currentTextAccum);
      }
      scrollToBottom();
    });
  }

  function finalizeAssistantMessage(tabData) {
    if (tabData.currentTextEl && tabData.currentTextAccum) {
      tabData.currentTextEl.innerHTML = renderMarkdown(tabData.currentTextAccum);
    }
    tabData.currentTextEl = null;
    tabData.currentTextAccum = "";
    finalizeThinking(tabData);
  }

  // --- Rendering: Thinking ---

  function appendThinking(tabData, text) {
    tabData.thinkingAccum += text;
    if (!tabData.thinkingEl) {
      var block = document.createElement("details");
      block.className = "chat-thinking";
      block.innerHTML = "<summary>Thinking...</summary><div class='chat-thinking-content'></div>";
      tabData.container.appendChild(block);
      tabData.thinkingEl = block.querySelector(".chat-thinking-content");
    }
    tabData.thinkingEl.textContent = tabData.thinkingAccum;
    scrollToBottom();
  }

  function finalizeThinking(tabData) {
    tabData.thinkingEl = null;
    tabData.thinkingAccum = "";
  }

  // --- Rendering: Tool Calls ---

  function renderToolCall(tabData, tc) {
    finalizeAssistantMessage(tabData);

    var card = document.createElement("details");
    card.className = "chat-tool-card";
    card.setAttribute("data-tool-id", tc.toolCallId || "");

    var status = tc.status || "pending";
    var kind = tc.kind || "other";
    var icon = TOOL_ICONS[kind] || "&#128295;";
    var title = tc.title || "Tool call";
    var locationText = "";
    if (tc.locations && tc.locations.length > 0) {
      var loc = tc.locations[0];
      var path = (loc && loc.path) || "";
      locationText = '<span class="chat-tool-path">' + escapeHtml(path.split("/").pop()) + "</span>";
    }

    card.innerHTML =
      '<summary class="chat-tool-header">' +
        '<span class="chat-tool-icon">' + icon + "</span>" +
        '<span class="chat-tool-title">' + escapeHtml(title) + "</span>" +
        locationText +
        '<span class="chat-tool-status ' + escapeHtml(status) + '">' + escapeHtml(status) + "</span>" +
      "</summary>" +
      '<div class="chat-tool-body"></div>';

    tabData.container.appendChild(card);
    scrollToBottom();
  }

  function updateToolCall(tabData, update) {
    var card = tabData.container.querySelector(
      '.chat-tool-card[data-tool-id="' + (update.toolCallId || "") + '"]'
    );
    if (!card) return;

    if (update.status) {
      var badge = card.querySelector(".chat-tool-status");
      if (badge) {
        badge.textContent = update.status;
        badge.className = "chat-tool-status " + update.status;
      }
    }

    if (update.content && update.content.length > 0) {
      var body = card.querySelector(".chat-tool-body");
      if (body) {
        update.content.forEach(function (item) {
          if (item.type === "diff") {
            renderDiff(body, item);
          } else if (item.type === "content" && item.content) {
            var text = item.content.text || "";
            if (text) {
              var pre = document.createElement("pre");
              pre.className = "chat-tool-output";
              pre.textContent = text.length > 2000 ? text.substring(0, 2000) + "\n...(truncated)" : text;
              body.appendChild(pre);
            }
          }
        });
      }
    }
    scrollToBottom();
  }

  function renderDiff(container, diff) {
    var el = document.createElement("div");
    el.className = "chat-diff";
    var header = document.createElement("div");
    header.className = "chat-diff-header";
    header.textContent = diff.path || "file";
    el.appendChild(header);

    var pre = document.createElement("pre");
    pre.className = "chat-diff-content";
    pre.textContent = diff.newText || "";
    el.appendChild(pre);
    container.appendChild(el);
  }

  // --- Rendering: Plan ---

  function renderPlan(tabData, entries) {
    var existing = tabData.container.querySelector(".chat-plan");
    if (existing) existing.parentNode.removeChild(existing);

    if (!entries.length) return;

    var el = document.createElement("div");
    el.className = "chat-plan";
    el.innerHTML = "<div class='chat-plan-title'>Plan</div>";
    var list = document.createElement("ul");
    entries.forEach(function (entry) {
      var li = document.createElement("li");
      var statusIcon = entry.status === "completed" ? "&#10003;" : entry.status === "failed" ? "&#10007;" : "&#9744;";
      li.innerHTML = '<span class="chat-plan-icon">' + statusIcon + '</span> ' + escapeHtml(entry.content || "");
      li.className = "chat-plan-entry " + (entry.status || "pending");
      list.appendChild(li);
    });
    el.appendChild(list);
    tabData.container.appendChild(el);
    scrollToBottom();
  }

  // --- Rendering: Usage ---

  function renderUsage(msg) {
    if (!$chatCost) return;
    var parts = [];

    if (msg.cost && msg.cost.amount != null) {
      parts.push("$" + msg.cost.amount.toFixed(4));
    }

    if (msg.used != null && msg.size != null && msg.size > 0) {
      var usedK = Math.round(msg.used / 1000);
      var sizeK = Math.round(msg.size / 1000);
      var pct = Math.round((msg.used / msg.size) * 100);
      parts.push(usedK + "K / " + sizeK + "K (" + pct + "%)");
    }

    if (parts.length > 0) {
      $chatCost.textContent = parts.join(" | ");
      $chatCost.classList.remove("hidden", "context-warn", "context-critical");
      if (msg.used != null && msg.size != null && msg.size > 0) {
        var pct = (msg.used / msg.size) * 100;
        if (pct >= 90) {
          $chatCost.classList.add("context-critical");
        } else if (pct >= 75) {
          $chatCost.classList.add("context-warn");
        }
      }
    }
  }

  // --- Turn Navigation Sidebar ---

  var $turnSidebar = document.getElementById("chat-turn-sidebar");

  function renderTurnSidebar(tabData) {
    if (!$turnSidebar) return;
    var list = $turnSidebar.querySelector(".turn-list");
    if (list) list.innerHTML = "";
    var turns = tabData.userTurns;
    if (turns.length === 0) {
      $turnSidebar.classList.add("hidden");
      return;
    }

    $turnSidebar.classList.remove("hidden");
    if (!list) return;

    turns.forEach(function (turn) {
      var item = document.createElement("div");
      item.className = "turn-item" + (turn.index === tabData.activeTurnIndex ? " active" : "");
      item.setAttribute("data-turn-index", turn.index);

      var label = document.createElement("span");
      label.className = "turn-label";
      label.textContent = (turn.index + 1);

      var preview = document.createElement("span");
      preview.className = "turn-preview";
      var previewText = turn.text.length > 60 ? turn.text.substring(0, 60) + "..." : turn.text;
      preview.textContent = previewText;

      item.appendChild(label);
      item.appendChild(preview);
      item.addEventListener("click", function () {
        jumpToTurn(tabData, turn.index);
      });
      list.appendChild(item);
    });

    var counter = $turnSidebar.querySelector(".turn-counter");
    if (counter) {
      var current = tabData.activeTurnIndex >= 0 ? (tabData.activeTurnIndex + 1) : "-";
      counter.textContent = current + " / " + turns.length;
    }
  }

  function jumpToTurn(tabData, turnIndex) {
    var turns = tabData.userTurns;
    if (turnIndex < 0 || turnIndex >= turns.length) return;

    tabData.activeTurnIndex = turnIndex;
    var el = turns[turnIndex].element;
    el.scrollIntoView({ behavior: "smooth", block: "center" });

    el.classList.add("turn-highlight");
    setTimeout(function () { el.classList.remove("turn-highlight"); }, 1500);

    renderTurnSidebar(tabData);
  }

  function jumpToPreviousTurn(tabData) {
    if (!tabData || tabData.userTurns.length === 0) return;
    var next = tabData.activeTurnIndex <= 0 ? 0 : tabData.activeTurnIndex - 1;
    jumpToTurn(tabData, next);
  }

  function jumpToNextTurn(tabData) {
    if (!tabData || tabData.userTurns.length === 0) return;
    var max = tabData.userTurns.length - 1;
    var next = tabData.activeTurnIndex >= max ? max : tabData.activeTurnIndex + 1;
    jumpToTurn(tabData, next);
  }

  function toggleTurnSidebar() {
    if (!$turnSidebar) return;
    $turnSidebar.classList.toggle("collapsed");
  }

  // --- Tool Collapsing ---

  function collapseCompletedTools(tabData) {
    var container = tabData.container;
    var children = Array.from(container.children);
    var i = 0;

    while (i < children.length) {
      if (isCompletedToolCard(children[i])) {
        var runStart = i;
        while (i < children.length && isCompletedToolCard(children[i])) {
          i++;
        }
        var runLength = i - runStart;
        if (runLength >= 3) {
          var details = container.ownerDocument.createElement("details");
          details.className = "chat-tool-group";
          var summary = container.ownerDocument.createElement("summary");
          summary.textContent = runLength + " tool calls completed";
          details.appendChild(summary);

          container.insertBefore(details, children[runStart]);
          for (var j = runStart; j < runStart + runLength; j++) {
            details.appendChild(children[j]);
          }
        }
      } else {
        i++;
      }
    }
  }

  function isCompletedToolCard(el) {
    if (!el || !el.classList || !el.classList.contains("chat-tool-card")) return false;
    var statusEl = el.querySelector(".chat-tool-status");
    return statusEl && statusEl.classList.contains("completed");
  }

  // --- Rendering: System / Info / Auth ---

  function appendSystemMessage(tabData, text) {
    var el = document.createElement("div");
    el.className = "chat-system-msg";
    el.textContent = text;
    tabData.container.appendChild(el);
    scrollToBottom();
  }

  function appendInfoBanner(tabData, text) {
    var el = document.createElement("div");
    el.className = "chat-info-banner";
    el.textContent = text;
    tabData.container.appendChild(el);
    scrollToBottom();
  }

  function appendSessionTerminated(tabData) {
    var el = document.createElement("div");
    el.className = "chat-system-msg chat-terminated";
    el.textContent = "Session ended \u2014 send a message to resume";
    tabData.container.appendChild(el);
    scrollToBottom();
  }

  function appendAuthBanner(tabData, msg) {
    var el = document.createElement("div");
    el.className = "chat-auth-banner";
    el.innerHTML =
      '<div class="chat-auth-text">' + escapeHtml(msg.message || "Authentication required") + "</div>" +
      '<button class="chat-auth-retry">Retry</button>';
    el.querySelector(".chat-auth-retry").addEventListener("click", function () {
      if (tabData.ws && tabData.ws.readyState === WebSocket.OPEN) {
        tabData.ws.send(JSON.stringify({ type: "retry" }));
        el.parentNode.removeChild(el);
      }
    });
    tabData.container.appendChild(el);
    scrollToBottom();
  }

  // --- Input Handling ---

  function sendUserMessage() {
    if (!activeChatTabId || !chatTabs[activeChatTabId]) return;
    var tab = chatTabs[activeChatTabId];

    var text = $chatInput.value.trim();
    var images = tab.pendingImages.slice();
    if (!text && !images.length) return;
    $chatInput.value = "";
    $chatInput.style.height = "auto";

    userNearBottom = true;
    appendUserBubble(tab, text, images);
    tab.pendingImages = [];
    renderImagePreview();
    updateInputPlaceholder();

    var queuedMsg = { type: "user_message", text: text };
    if (images.length) {
      queuedMsg.images = images.map(function (img) {
        return { data: img.data, mimeType: img.mimeType };
      });
    }

    if (tab.streaming) {
      if (!tab.messageQueue) tab.messageQueue = [];
      tab.messageQueue.push(queuedMsg);
      updateInputState();
      return;
    }

    sendToAgent(tab, queuedMsg);
  }

  function sendToAgent(tab, msg) {
    if (tab.ws && tab.ws.readyState === WebSocket.OPEN) {
      tab.ws.send(JSON.stringify(msg));
      tab.streaming = true;
      updateInputState();
      renderChatTabs();
      emitSessionEvent("agent-session-updated", {
        sessionId: tab.sessionId,
        streaming: true,
      });
    }
  }

  function flushMessageQueue(tab) {
    if (!tab.messageQueue || tab.messageQueue.length === 0) return;
    var next = tab.messageQueue.shift();
    sendToAgent(tab, next);
  }

  function cancelAgent() {
    if (!activeChatTabId || !chatTabs[activeChatTabId]) return;
    var tab = chatTabs[activeChatTabId];
    if (!tab.streaming) return;
    if (tab.ws && tab.ws.readyState === WebSocket.OPEN) {
      tab.ws.send(JSON.stringify({ type: "cancel" }));
    }
    tab.messageQueue = [];
    tab.streaming = false;
    appendSystemMessage(tab, "Cancelled by user");
    finalizeAssistantMessage(tab);
    updateInputState();
    renderChatTabs();
  }

  function updateInputState() {
    var tab = activeChatTabId ? chatTabs[activeChatTabId] : null;
    var streaming = tab && tab.streaming;
    var queued = tab && tab.messageQueue && tab.messageQueue.length > 0;
    $chatInput.disabled = false;
    if (streaming) {
      $chatSend.classList.add("hidden");
      $chatStop.classList.remove("hidden");
    } else {
      $chatSend.classList.remove("hidden");
      $chatStop.classList.add("hidden");
    }
    if (streaming && queued) {
      $chatInput.placeholder = queued + " queued...";
    } else if (streaming) {
      $chatInput.placeholder = "Agent working... Esc to stop";
    } else if (tab && tab.terminated) {
      $chatInput.placeholder = "Send a message to resume session...";
    } else {
      $chatInput.placeholder = "Send a message...";
    }
  }

  // Auto-grow textarea
  $chatInput.addEventListener("input", function () {
    this.style.height = "auto";
    this.style.height = Math.min(this.scrollHeight, 150) + "px";
  });

  // Enter to send, Shift+Enter for newline, Esc to stop
  $chatInput.addEventListener("keydown", function (e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendUserMessage();
    } else if (e.key === "Escape") {
      var tab = activeChatTabId ? chatTabs[activeChatTabId] : null;
      if (tab && tab.streaming) {
        e.preventDefault();
        cancelAgent();
      }
    }
  });

  $chatStop.addEventListener("click", cancelAgent);
  $chatSend.addEventListener("click", sendUserMessage);

  // --- Image Paste ---

  $chatInput.addEventListener("paste", function (e) {
    var tab = activeChatTabId ? chatTabs[activeChatTabId] : null;
    if (!tab || tab.streaming) return;

    var items = e.clipboardData && e.clipboardData.items;
    if (!items) return;

    for (var i = 0; i < items.length; i++) {
      if (items[i].type.indexOf("image/") === 0) {
        e.preventDefault();
        var file = items[i].getAsFile();
        if (!file) continue;
        readImageFile(tab, file);
      }
    }
  });

  function readImageFile(tab, file) {
    var reader = new FileReader();
    reader.onload = function () {
      var parts = reader.result.split(",");
      var mimeType = file.type || "image/png";
      var data = parts[1];
      tab.pendingImages.push({ data: data, mimeType: mimeType });
      renderImagePreview();
      updateInputPlaceholder();
    };
    reader.readAsDataURL(file);
  }

  function updateInputPlaceholder() {
    var tab = activeChatTabId ? chatTabs[activeChatTabId] : null;
    if (!tab || tab.streaming || tab.terminated) return;
    var n = tab.pendingImages.length;
    if (n > 0) {
      $chatInput.placeholder = n + " image" + (n > 1 ? "s" : "") + " attached \u2014 add text or press Enter to send";
    } else {
      $chatInput.placeholder = "Send a message...";
    }
  }

  function renderImagePreview() {
    var tab = activeChatTabId ? chatTabs[activeChatTabId] : null;
    $imagePreview.innerHTML = "";
    if (!tab || !tab.pendingImages.length) {
      $imagePreview.classList.remove("active");
      return;
    }
    $imagePreview.classList.add("active");
    tab.pendingImages.forEach(function (img, idx) {
      var thumb = document.createElement("div");
      thumb.className = "image-preview-thumb";
      var imgEl = document.createElement("img");
      imgEl.src = "data:" + img.mimeType + ";base64," + img.data;
      thumb.appendChild(imgEl);
      var removeBtn = document.createElement("button");
      removeBtn.className = "image-preview-remove";
      removeBtn.textContent = "\u00d7";
      removeBtn.setAttribute("data-idx", idx);
      removeBtn.addEventListener("click", function () {
        tab.pendingImages.splice(idx, 1);
        renderImagePreview();
        updateInputPlaceholder();
      });
      thumb.appendChild(removeBtn);
      $imagePreview.appendChild(thumb);
    });
  }

  // Turn navigation keyboard shortcuts (Ctrl+Up/Down)
  document.addEventListener("keydown", function (e) {
    if (!activeChatTabId || !chatTabs[activeChatTabId]) return;
    var tab = chatTabs[activeChatTabId];

    if (e.ctrlKey && e.key === "ArrowUp") {
      e.preventDefault();
      jumpToPreviousTurn(tab);
    } else if (e.ctrlKey && e.key === "ArrowDown") {
      e.preventDefault();
      jumpToNextTurn(tab);
    } else if (e.ctrlKey && e.key === "t") {
      e.preventDefault();
      toggleTurnSidebar();
    }
  });

  // Initialize empty state
  updateEmptyState();

  // --- Custom Events ---

  function emitSessionEvent(eventName, detail) {
    window.dispatchEvent(new CustomEvent(eventName, { detail: detail }));
  }

  // --- Public API (called from app.js) ---

  window.AgentChat = {
    getActiveSessionIds: function () {
      var ids = new Set();
      Object.keys(chatTabs).forEach(function (tabId) {
        var tab = chatTabs[tabId];
        if (tab.sessionId) ids.add(tab.sessionId);
      });
      return ids;
    },

    getActiveSessions: function () {
      var sessions = {};
      Object.keys(chatTabs).forEach(function (tabId) {
        var tab = chatTabs[tabId];
        if (tab.sessionId) {
          sessions[tab.sessionId] = {
            streaming: tab.streaming,
            agent: tab.agent,
            cwd: tab.cwd,
            title: tab.title,
          };
        }
      });
      return sessions;
    },

    openChat: function (session) {
      var ids = Object.keys(chatTabs);
      for (var i = 0; i < ids.length; i++) {
        if (chatTabs[ids[i]].sessionId === session.id) {
          switchChatTab(ids[i]);
          return;
        }
      }
      var agent = session.source || "claude";
      var title = session.summary || session.id.substring(0, 8);
      createChatTab(title, agent, session.cwd, session.id, session.summary);
    },

    openNewChat: function (cwd, agent) {
      agent = agent || localStorage.getItem("ak-default-agent") || "claude";
      var displayName = cwd.split("/").filter(Boolean).pop() || cwd;
      createChatTab("New: " + displayName, agent, cwd, null, null);
    },
  };

  // Exposed for testing
  window._chatInternals = {
    handleServerMessage: handleServerMessage,
    handleUpdate: handleUpdate,
    parseLocalCommand: parseLocalCommand,
    appendLocalCommand: appendLocalCommand,
    appendAgentText: appendAgentText,
    appendUserBubble: appendUserBubble,
    finalizeAssistantMessage: finalizeAssistantMessage,
    renderToolCall: renderToolCall,
    collapseCompletedTools: collapseCompletedTools,
    sendUserMessage: sendUserMessage,
    switchChatTab: switchChatTab,
    updateInputState: updateInputState,
    buildMessagePayload: function (text, images) {
      var msg = { type: "user_message", text: text };
      if (images && images.length) {
        msg.images = images.map(function (img) {
          return { data: img.data, mimeType: img.mimeType };
        });
      }
      return msg;
    },
    getState: function () {
      return { chatTabs: chatTabs, activeChatTabId: activeChatTabId };
    },
    createTabData: function (container) {
      return {
        id: "test-tab",
        ws: null,
        sessionId: null,
        agent: "claude",
        cwd: "/tmp",
        container: container,
        title: "Test",
        streaming: false,
        messageQueue: [],
        currentTextAccum: "",
        currentTextEl: null,
        thinkingAccum: "",
        thinkingEl: null,
        renderScheduled: false,
        sessionSummary: null,
        userTurns: [],
        activeTurnIndex: -1,
        pendingImages: [],
      };
    },
  };
})();
