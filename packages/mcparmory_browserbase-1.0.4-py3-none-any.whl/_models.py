"""
Browserbase MCP Server - Pydantic Models

Generated: 2026-05-11 23:11:54 UTC
Generator: MCP Blacksmith v1.1.0 (https://mcpblacksmith.com)
"""

from __future__ import annotations

from typing import Any, Literal

from _validators import PermissiveModel, StrictModel
from pydantic import Field

__all__ = [
    "ContextsCreateRequest",
    "ContextsGetRequest",
    "ContextsUpdateRequest",
    "ExtensionsDeleteRequest",
    "ExtensionsGetRequest",
    "ExtensionsUploadRequest",
    "ProjectsGetRequest",
    "ProjectsUsageRequest",
    "SessionsCreateRequest",
    "SessionsGetDebugRequest",
    "SessionsGetDownloadsRequest",
    "SessionsGetLogsRequest",
    "SessionsGetRecordingRequest",
    "SessionsGetRequest",
    "SessionsListRequest",
    "SessionsUpdateRequest",
    "SessionsUploadFileRequest",
    "SessionsCreateBodyBrowserSettingsFingerprint",
]

# ============================================================================
# Request Models
# ============================================================================

# Operation: create_context
class ContextsCreateRequestBody(StrictModel):
    project_id: str = Field(default=..., validation_alias="projectId", serialization_alias="projectId", description="The unique identifier of the project under which the context will be created. Locatable in the Browserbase account Settings page.")
class ContextsCreateRequest(StrictModel):
    """Creates a new browser context within a specified project, enabling isolated session management and configuration for automated browsing tasks."""
    body: ContextsCreateRequestBody

# Operation: get_context
class ContextsGetRequestPath(StrictModel):
    id_: str = Field(default=..., validation_alias="id", serialization_alias="id", description="The unique identifier of the context to retrieve.")
class ContextsGetRequest(StrictModel):
    """Retrieves a specific context by its unique identifier. Returns the full details of the requested context object."""
    path: ContextsGetRequestPath

# Operation: update_context
class ContextsUpdateRequestPath(StrictModel):
    id_: str = Field(default=..., validation_alias="id", serialization_alias="id", description="The unique identifier of the context to update.")
class ContextsUpdateRequest(StrictModel):
    """Updates an existing context by its unique identifier. Use this to modify the properties or configuration of a previously created context."""
    path: ContextsUpdateRequestPath

# Operation: upload_extension
class ExtensionsUploadRequestBody(StrictModel):
    file_: str = Field(default=..., validation_alias="file", serialization_alias="file", description="Base64-encoded file content for upload. The binary file containing the extension package to be uploaded.", json_schema_extra={'format': 'byte'})
class ExtensionsUploadRequest(StrictModel):
    """Upload an extension package to the system, making it available for installation and use. Accepts a binary file representing the extension bundle."""
    body: ExtensionsUploadRequestBody

# Operation: get_extension
class ExtensionsGetRequestPath(StrictModel):
    id_: str = Field(default=..., validation_alias="id", serialization_alias="id", description="The unique identifier of the extension to retrieve.")
class ExtensionsGetRequest(StrictModel):
    """Retrieves detailed information about a specific extension by its unique identifier. Use this to inspect extension configuration, status, or metadata."""
    path: ExtensionsGetRequestPath

# Operation: delete_extension
class ExtensionsDeleteRequestPath(StrictModel):
    id_: str = Field(default=..., validation_alias="id", serialization_alias="id", description="The unique identifier of the extension to delete.")
class ExtensionsDeleteRequest(StrictModel):
    """Permanently deletes a specific extension by its unique identifier. This action is irreversible and removes the extension and its associated data."""
    path: ExtensionsDeleteRequestPath

# Operation: get_project
class ProjectsGetRequestPath(StrictModel):
    id_: str = Field(default=..., validation_alias="id", serialization_alias="id", description="The unique identifier of the project to retrieve.")
class ProjectsGetRequest(StrictModel):
    """Retrieves detailed information about a specific project by its unique identifier. Use this to fetch project metadata, status, and configuration."""
    path: ProjectsGetRequestPath

# Operation: get_project_usage
class ProjectsUsageRequestPath(StrictModel):
    id_: str = Field(default=..., validation_alias="id", serialization_alias="id", description="The unique identifier of the project whose usage data you want to retrieve.")
class ProjectsUsageRequest(StrictModel):
    """Retrieves usage statistics and consumption metrics for a specific project. Useful for monitoring resource utilization and tracking project activity over time."""
    path: ProjectsUsageRequestPath

# Operation: list_sessions
class SessionsListRequestQuery(StrictModel):
    status: Literal["RUNNING", "ERROR", "TIMED_OUT", "COMPLETED"] | None = Field(default=None, description="Filters the returned sessions by their current lifecycle status. Accepted values are RUNNING (active), ERROR (failed), TIMED_OUT (expired), or COMPLETED (finished successfully).")
class SessionsListRequest(StrictModel):
    """Retrieves a list of sessions, optionally filtered by their current status. Useful for monitoring active, completed, or failed sessions."""
    query: SessionsListRequestQuery | None = None

# Operation: create_session
class SessionsCreateRequestBodyBrowserSettingsContext(StrictModel):
    id_: str = Field(default=..., validation_alias="id", serialization_alias="id", description="The unique identifier of an existing browser context to associate with this session, enabling context persistence and reuse.")
    persist: bool | None = Field(default=None, validation_alias="persist", serialization_alias="persist", description="Whether to persist the browser context (cookies, storage, etc.) after the session ends, allowing reuse in future sessions. Defaults to false.")
class SessionsCreateRequestBodyBrowserSettingsViewport(StrictModel):
    width: int | None = Field(default=None, validation_alias="width", serialization_alias="width")
    height: int | None = Field(default=None, validation_alias="height", serialization_alias="height")
class SessionsCreateRequestBodyBrowserSettings(StrictModel):
    extension_id: str | None = Field(default=None, validation_alias="extensionId", serialization_alias="extensionId", description="The ID of a previously uploaded browser extension to load into this session's browser environment.")
    fingerprint: SessionsCreateBodyBrowserSettingsFingerprint | None = Field(default=None, validation_alias="fingerprint", serialization_alias="fingerprint", description="Browser fingerprint configuration to control how the browser identifies itself, used for stealth and anti-detection purposes.")
    block_ads: bool | None = Field(default=None, validation_alias="blockAds", serialization_alias="blockAds", description="Whether to enable ad blocking within the browser session. Defaults to false.")
    solve_captchas: bool | None = Field(default=None, validation_alias="solveCaptchas", serialization_alias="solveCaptchas", description="Whether to enable automatic captcha solving during the session. Defaults to true.")
    record_session: bool | None = Field(default=None, validation_alias="recordSession", serialization_alias="recordSession", description="Whether to record the browser session for later playback and debugging. Defaults to true.")
    log_session: bool | None = Field(default=None, validation_alias="logSession", serialization_alias="logSession", description="Whether to capture and store session logs for debugging and auditing purposes. Defaults to true.")
    context: SessionsCreateRequestBodyBrowserSettingsContext
    viewport: SessionsCreateRequestBodyBrowserSettingsViewport | None = None
class SessionsCreateRequestBody(StrictModel):
    project_id: str = Field(default=..., validation_alias="projectId", serialization_alias="projectId", description="The unique identifier of the project under which this session will be created. Found in your Browserbase account Settings.")
    timeout: int | None = Field(default=None, description="Maximum duration in seconds before the session is automatically terminated. Must be between 60 and 21600 seconds. Defaults to the project's configured default timeout.", ge=60, le=21600)
    keep_alive: bool | None = Field(default=None, validation_alias="keepAlive", serialization_alias="keepAlive", description="When true, keeps the session alive after client disconnections rather than terminating it, allowing reconnection. Available on the Startup plan only.")
    proxies: Any | None = Field(default=None, description="Proxy configuration for the session. Pass true to use the default proxy, or provide an array of proxy configuration objects for custom routing.")
    region: Literal["us-west-2", "us-east-1", "eu-central-1", "ap-southeast-1"] | None = Field(default=None, description="The geographic region in which to run the browser session, affecting latency and geo-targeted content.")
    browser_settings: SessionsCreateRequestBodyBrowserSettings = Field(default=..., validation_alias="browserSettings", serialization_alias="browserSettings")
class SessionsCreateRequest(StrictModel):
    """Creates a new browser session within a specified project, with configurable settings for fingerprinting, proxies, recording, and session lifecycle management."""
    body: SessionsCreateRequestBody

# Operation: get_session
class SessionsGetRequestPath(StrictModel):
    id_: str = Field(default=..., validation_alias="id", serialization_alias="id", description="The unique identifier of the session to retrieve.")
class SessionsGetRequest(StrictModel):
    """Retrieves the details of a specific session by its unique identifier. Useful for checking session status, metadata, or associated activity."""
    path: SessionsGetRequestPath

# Operation: release_session
class SessionsUpdateRequestPath(StrictModel):
    id_: str = Field(default=..., validation_alias="id", serialization_alias="id", description="The unique identifier of the session to update.")
class SessionsUpdateRequestBody(StrictModel):
    project_id: str = Field(default=..., validation_alias="projectId", serialization_alias="projectId", description="The Project ID associated with the session. Can be found in the Browserbase Settings page.")
    status: Literal["REQUEST_RELEASE"] = Field(default=..., description="The desired status update for the session. Set to REQUEST_RELEASE to signal that the session is complete and should be released before its scheduled timeout.")
class SessionsUpdateRequest(StrictModel):
    """Updates a session's status to request an early release, signaling that the session has completed. Use this before the session's timeout to avoid incurring additional charges."""
    path: SessionsUpdateRequestPath
    body: SessionsUpdateRequestBody

# Operation: get_session_debug_urls
class SessionsGetDebugRequestPath(StrictModel):
    id_: str = Field(default=..., validation_alias="id", serialization_alias="id", description="The unique identifier of the session for which to retrieve debug URLs.")
class SessionsGetDebugRequest(StrictModel):
    """Retrieves live debug URLs for an active browser session, enabling real-time inspection and monitoring of the session's state."""
    path: SessionsGetDebugRequestPath

# Operation: list_session_downloads
class SessionsGetDownloadsRequestPath(StrictModel):
    id_: str = Field(default=..., validation_alias="id", serialization_alias="id", description="The unique identifier of the session whose downloads you want to retrieve.")
class SessionsGetDownloadsRequest(StrictModel):
    """Retrieves all downloads associated with a specific session. Useful for reviewing files or resources that were downloaded during a given session."""
    path: SessionsGetDownloadsRequestPath

# Operation: get_session_logs
class SessionsGetLogsRequestPath(StrictModel):
    id_: str = Field(default=..., validation_alias="id", serialization_alias="id", description="The unique identifier of the session whose logs you want to retrieve.")
class SessionsGetLogsRequest(StrictModel):
    """Retrieves the log output for a specific session, useful for debugging, auditing, or monitoring session activity."""
    path: SessionsGetLogsRequestPath

# Operation: get_session_recording
class SessionsGetRecordingRequestPath(StrictModel):
    id_: str = Field(default=..., validation_alias="id", serialization_alias="id", description="The unique identifier of the session whose recording you want to retrieve.")
class SessionsGetRecordingRequest(StrictModel):
    """Retrieves the recording associated with a specific session. Returns the recording data or media for playback or download."""
    path: SessionsGetRecordingRequestPath

# Operation: upload_session_file
class SessionsUploadFileRequestPath(StrictModel):
    id_: str = Field(default=..., validation_alias="id", serialization_alias="id", description="The unique identifier of the session to which the file will be uploaded.")
class SessionsUploadFileRequestBody(StrictModel):
    file_: str = Field(default=..., validation_alias="file", serialization_alias="file", description="Base64-encoded file content for upload. The binary file content to upload to the session.", json_schema_extra={'format': 'byte'})
class SessionsUploadFileRequest(StrictModel):
    """Uploads a file to an existing session, attaching it as a resource for use within that session's context."""
    path: SessionsUploadFileRequestPath
    body: SessionsUploadFileRequestBody

# ============================================================================
# Component Models
# ============================================================================

class Project(PermissiveModel):
    id_: str = Field(..., validation_alias="id", serialization_alias="id")
    created_at: str = Field(..., validation_alias="createdAt", serialization_alias="createdAt", json_schema_extra={'format': 'date-time'})
    updated_at: str = Field(..., validation_alias="updatedAt", serialization_alias="updatedAt", json_schema_extra={'format': 'date-time'})
    name: str = Field(..., min_length=1)
    owner_id: str = Field(..., validation_alias="ownerId", serialization_alias="ownerId")
    default_timeout: int = Field(..., validation_alias="defaultTimeout", serialization_alias="defaultTimeout", ge=60, le=21600)

class SessionsCreateBodyBrowserSettingsFingerprintScreen(PermissiveModel):
    max_height: int | None = Field(None, validation_alias="maxHeight", serialization_alias="maxHeight")
    max_width: int | None = Field(None, validation_alias="maxWidth", serialization_alias="maxWidth")
    min_height: int | None = Field(None, validation_alias="minHeight", serialization_alias="minHeight")
    min_width: int | None = Field(None, validation_alias="minWidth", serialization_alias="minWidth")

class SessionsCreateBodyBrowserSettingsFingerprint(PermissiveModel):
    """See usage examples [in the Stealth Mode page](/features/stealth-mode#fingerprinting)."""
    http_version: Literal[1, 2] | None = Field(None, validation_alias="httpVersion", serialization_alias="httpVersion")
    browsers: list[Literal["chrome", "edge", "firefox", "safari"]] | None = None
    devices: list[Literal["desktop", "mobile"]] | None = None
    locales: list[str] | None = Field(None, description="Full list of locales is available [here](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Accept-Language).")
    operating_systems: list[Literal["android", "ios", "linux", "macos", "windows"]] | None = Field(None, validation_alias="operatingSystems", serialization_alias="operatingSystems", description="Note: `operatingSystems` set to `ios` or `android` requires `devices` to include `\"mobile\"`.")
    screen: SessionsCreateBodyBrowserSettingsFingerprintScreen | None = None


# Rebuild models to resolve forward references (required for circular refs)
Project.model_rebuild()
SessionsCreateBodyBrowserSettingsFingerprint.model_rebuild()
SessionsCreateBodyBrowserSettingsFingerprintScreen.model_rebuild()
