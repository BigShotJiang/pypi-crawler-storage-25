"""Athanor CLI — the platform in your terminal.

Usage:
    athanor run --token <token>                     # Start runner
    athanor score --task <slug> --file solution.py  # Score a file
    athanor config --set KEY=VALUE                  # Set config
"""

import argparse
import json
import os
import sys


def cmd_run(args):
    """Start the runner."""
    from athanor.runner import Runner

    token = args.token or os.environ.get("ATHANOR_TOKEN") or os.environ.get("CRON_SECRET")
    if not token:
        print("Error: --token required or set ATHANOR_TOKEN env var")
        sys.exit(1)

    runner = Runner(
        token=token,
        platform_url=args.platform,
        name=args.name,
    )
    runner.run_forever()


def cmd_score(args):
    """Score a file against a task."""
    from athanor.runner import Runner

    token = args.token or os.environ.get("ATHANOR_TOKEN") or os.environ.get("CRON_SECRET")
    if not token:
        print("Error: --token required or set ATHANOR_TOKEN env var")
        sys.exit(1)

    if not args.file or not os.path.exists(args.file):
        print(f"Error: file not found: {args.file}")
        sys.exit(1)

    student_code = open(args.file).read()

    runner = Runner(token=token, platform_url=args.platform)
    image = f"ghcr.io/athanor-ai/{args.env}:latest"
    runner.pull_image(image)

    result = runner.run_score(
        image=image,
        task_config={"task_slug": args.task, "stub_filename": os.path.basename(args.file)},
        student_code=student_code,
    )

    print(json.dumps(result, indent=2))


def cmd_solve(args):
    """Solve a task with a model — full agent loop with retry."""
    from athanor.runner import Runner

    token = args.token or os.environ.get("ATHANOR_TOKEN") or os.environ.get("CRON_SECRET")
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not token:
        print("Error: --token required or set ATHANOR_TOKEN env var")
        sys.exit(1)
    if not api_key:
        print("Error: ANTHROPIC_API_KEY env var required for solve")
        sys.exit(1)

    runner = Runner(token=token, platform_url=args.platform)
    image = f"ghcr.io/athanor-ai/{args.env}:latest"
    runner.pull_image(image)

    # Fetch task info from platform
    print(f"Solving {args.task} on {args.env} with {args.model}...")
    try:
        task_info = runner._request("GET", f"/api/tasks?slug={args.task}&env={args.env}")
        if isinstance(task_info, list) and task_info:
            task_data = task_info[0]
        elif isinstance(task_info, dict) and task_info.get("data"):
            task_data = task_info["data"][0]
        else:
            task_data = {}
    except Exception:
        task_data = {}

    task_config = {
        "task_slug": args.task,
        "task_description": task_data.get("description", args.task),
        "stub_code": (task_data.get("metadata") or {}).get("stub_code", ""),
        "stub_filename": (task_data.get("metadata") or {}).get("stub_filename", f"{args.task}.py"),
    }

    if not task_config["stub_code"]:
        # Try extracting from container
        import subprocess
        result = subprocess.run(
            [runner.docker_bin, "run", "--rm", image, "cat", f"/workdir/data/{task_config['stub_filename']}"],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode == 0:
            task_config["stub_code"] = result.stdout

    result = runner.run_solve(image, task_config, model=args.model, api_key=api_key)
    print(f"\nFinal score: {result.get('score', 0):.3f}")
    print(f"Turns: {result.get('tool_calls_total', 0)}")
    print(f"Time: {result.get('time_seconds', 0):.1f}s")

    # Save results
    output = args.output or f"{args.task}_solve.json"
    json.dump(result, open(output, "w"), indent=2)
    print(f"Saved: {output}")


def cmd_build(args):
    """Build a task using Opus 4.6."""
    token = args.token or os.environ.get("ATHANOR_TOKEN") or os.environ.get("CRON_SECRET")
    api_key = args.api_key or os.environ.get("ANTHROPIC_API_KEY")

    if not token:
        print("Error: --token required or set ATHANOR_TOKEN env var")
        sys.exit(1)
    if not api_key:
        print("Error: --api-key required or set ANTHROPIC_API_KEY env var")
        print("Task Builder uses YOUR Opus 4.6 API key.")
        sys.exit(1)

    print(f"Building task: {args.name}")
    print(f"  Environment: {args.env}")
    print(f"  Difficulty: {args.difficulty}")
    print(f"  Proof backend: {args.proof_backend}")
    print(f"  Description: {args.description[:100]}...")
    print()

    # Call Opus to generate the task
    try:
        import urllib.request
        prompt = f"""Generate a verified training task for the "{args.env}" environment.

Task name: {args.name}
Description: {args.description}
Difficulty: {args.difficulty}
Category: {args.category}
Proof backend: {args.proof_backend}
Scoring: {args.scoring}

Generate:
1. A student stub file (the starting code the agent edits)
2. A scoring configuration (sigmoid_center, sigmoid_scale, checks)
3. A proof template if proof_backend is not "none"

Output as JSON with keys: stub_code, scoring_config, proof_template (or null), description, task_id
"""
        payload = json.dumps({
            "model": "claude-opus-4-6",
            "max_tokens": 4096,
            "messages": [{"role": "user", "content": prompt}],
        }).encode()

        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=payload,
            headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
        )
        resp = json.loads(urllib.request.urlopen(req, timeout=120).read())
        content = resp.get("content", [{}])[0].get("text", "")
        print("=== Opus 4.6 Output ===")
        print(content[:2000])

        # Try to parse JSON from the response
        try:
            # Find JSON block in response
            import re
            json_match = re.search(r'\{[\s\S]*\}', content)
            if json_match:
                task_data = json.loads(json_match.group())
                print(f"\nTask generated: {task_data.get('task_id', args.name)}")
                print(f"Stub code: {len(task_data.get('stub_code', ''))} chars")
                print(f"Proof template: {'Yes' if task_data.get('proof_template') else 'No'}")

                # Save to files
                out_dir = args.output or "."
                os.makedirs(out_dir, exist_ok=True)
                if task_data.get("stub_code"):
                    stub_file = os.path.join(out_dir, f"{args.name}.py")
                    open(stub_file, "w").write(task_data["stub_code"])
                    print(f"Saved: {stub_file}")
                if task_data.get("scoring_config"):
                    cfg_file = os.path.join(out_dir, f"{args.name}.json")
                    json.dump(task_data["scoring_config"], open(cfg_file, "w"), indent=2)
                    print(f"Saved: {cfg_file}")
                if task_data.get("proof_template"):
                    ext = ".lean" if args.proof_backend == "lean4" else ".dfy" if args.proof_backend == "dafny" else ".proof"
                    proof_file = os.path.join(out_dir, f"{args.name}{ext}")
                    open(proof_file, "w").write(task_data["proof_template"])
                    print(f"Saved: {proof_file}")
        except (json.JSONDecodeError, ValueError):
            print("\nCould not parse structured output — review the raw text above.")

    except Exception as e:
        print(f"Error calling Opus: {e}")
        sys.exit(1)


def cmd_config(args):
    """Manage configuration."""
    config_dir = os.path.expanduser("~/.athanor")
    config_file = os.path.join(config_dir, "config.json")
    os.makedirs(config_dir, exist_ok=True)

    config = {}
    if os.path.exists(config_file):
        config = json.load(open(config_file))

    if args.set:
        key, _, value = args.set.partition("=")
        config[key] = value
        json.dump(config, open(config_file, "w"), indent=2)
        print(f"Set {key}")
    else:
        for k, v in config.items():
            display = v[:8] + "..." if len(str(v)) > 20 else v
            print(f"  {k}={display}")


def main():
    parser = argparse.ArgumentParser(
        prog="athanor",
        description="Athanor AI — formal verification as agentic training signal",
    )
    sub = parser.add_subparsers(dest="command")

    # run
    p_run = sub.add_parser("run", help="Start the self-hosted runner")
    p_run.add_argument("--token", help="Sync token (or set ATHANOR_TOKEN)")
    p_run.add_argument("--platform", default="https://tahoe.athanor-ai.com", help="Platform URL")
    p_run.add_argument("--name", default="default", help="Runner name")

    # score
    p_score = sub.add_parser("score", help="Score a file against a task")
    p_score.add_argument("--token", help="Sync token")
    p_score.add_argument("--platform", default="https://tahoe.athanor-ai.com")
    p_score.add_argument("--env", required=True, help="Environment slug")
    p_score.add_argument("--task", required=True, help="Task slug")
    p_score.add_argument("--file", required=True, help="Path to student file")

    # solve
    p_solve = sub.add_parser("solve", help="Solve a task with a model")
    p_solve.add_argument("--token", help="Sync token")
    p_solve.add_argument("--platform", default="https://tahoe.athanor-ai.com")
    p_solve.add_argument("--env", required=True, help="Environment slug")
    p_solve.add_argument("--task", required=True, help="Task slug")
    p_solve.add_argument("--model", default="claude-opus-4-6", help="Model to use")
    p_solve.add_argument("--output", "-o", help="Output JSON path")

    # build
    p_build = sub.add_parser("build", help="Build a task using Opus 4.6")
    p_build.add_argument("--token", help="Sync token")
    p_build.add_argument("--platform", default="https://tahoe.athanor-ai.com")
    p_build.add_argument("--api-key", help="Anthropic API key for Opus 4.6")
    p_build.add_argument("--env", required=True, help="Environment slug")
    p_build.add_argument("--name", required=True, help="Task name (snake_case)")
    p_build.add_argument("--description", required=True, help="What the agent should do")
    p_build.add_argument("--difficulty", default="medium", choices=["easy", "medium", "hard"])
    p_build.add_argument("--category", default="implementation",
                         choices=["bug_fix", "implementation", "verification", "optimization", "translation"])
    p_build.add_argument("--proof-backend", default="none",
                         choices=["none", "lean4", "dafny", "ebmc", "verus"])
    p_build.add_argument("--scoring", default="property_tests",
                         choices=["property_tests", "simulation", "compilation", "output_match"])
    p_build.add_argument("--output", help="Output directory for generated files")

    # config
    p_config = sub.add_parser("config", help="Manage configuration")
    p_config.add_argument("--set", help="Set a config value (KEY=VALUE)")

    args = parser.parse_args()
    if args.command == "run":
        cmd_run(args)
    elif args.command == "score":
        cmd_score(args)
    elif args.command == "solve":
        cmd_solve(args)
    elif args.command == "build":
        cmd_build(args)
    elif args.command == "config":
        cmd_config(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
