"""Self-hosted runner — polls the Athanor platform for jobs and executes them locally.

Usage:
    athanor run --token <sync-token>
    athanor run --token <sync-token> --platform https://tahoe.athanor-ai.com

The runner:
1. Registers with the platform
2. Polls for jobs (score, solve, evaluate, build)
3. Pulls the scoring container from GHCR
4. Runs scoring locally with Docker
5. Reports results back to the platform

Requirements: Docker, Python 3.10+, outbound HTTPS
"""

import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request


class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    """Prevent urllib from following redirects (which drops the Authorization header)."""
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise urllib.error.HTTPError(newurl, code, msg, headers, fp)


class Runner:
    def __init__(self, token: str, platform_url: str = "https://tahoe.athanor-ai.com", name: str = "default"):
        self.token = token
        self.platform_url = platform_url.rstrip("/")
        self.name = name
        self.runner_id: str | None = None
        self.docker_bin = shutil.which("docker") or shutil.which("podman")
        if not self.docker_bin:
            raise RuntimeError("Docker or Podman is required. Install Docker and try again.")
        self._opener = urllib.request.build_opener(_NoRedirectHandler)

    def _request(self, method: str, path: str, data: dict | None = None) -> dict:
        url = f"{self.platform_url}{path}"
        body = json.dumps(data).encode() if data else None
        req = urllib.request.Request(
            url,
            data=body,
            headers={
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json",
                "User-Agent": "athanor-runner/0.2.0",
            },
            method=method,
        )
        try:
            resp = self._opener.open(req, timeout=35)
            return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            body = e.read().decode() if e.fp else ""
            raise RuntimeError(f"API error {e.code}: {body[:200]}")

    def register(self):
        """Register this runner with the platform."""
        result = self._request("POST", "/api/runner", {"name": self.name})
        self.runner_id = result.get("runner_id")
        print(f"Runner registered: {self.runner_id}")
        return self.runner_id

    def poll(self) -> dict | None:
        """Poll for the next job. Returns None if no jobs queued."""
        result = self._request("GET", f"/api/runner/poll?runner_id={self.runner_id}")
        return result.get("job")

    def report(self, job_id: str, result: dict | None = None, error: str | None = None):
        """Report job results back to the platform."""
        self._request("POST", "/api/runner/results", {
            "job_id": job_id,
            "status": "failed" if error else "completed",
            "result": result,
            "error": error,
        })

    def pull_image(self, image: str):
        """Pull a container image if not already present."""
        check = subprocess.run(
            [self.docker_bin, "image", "inspect", image],
            capture_output=True,
        )
        if check.returncode != 0:
            print(f"  Pulling {image}...")
            subprocess.run(
                [self.docker_bin, "pull", image],
                check=True,
            )

    def run_score(self, image: str, task_config: dict, student_code: str | None = None,
                  data_dir: str | None = None, shared_dir: str | None = None) -> dict:
        """Run scoring in a container and return the result.

        If data_dir is provided, scores files in-place (used by run_solve).
        Otherwise creates a temp dir and optionally writes student_code.
        """
        cleanup = False
        if data_dir is None:
            tmpdir = tempfile.mkdtemp(prefix="athanor-score-")
            data_dir = os.path.join(tmpdir, "data")
            shared_dir = os.path.join(tmpdir, "shared")
            os.makedirs(data_dir)
            os.makedirs(shared_dir)
            cleanup = True

            # Write student code if provided
            stub_filename = task_config.get("stub_filename", "solution.py")
            if student_code:
                with open(os.path.join(data_dir, stub_filename), "w") as f:
                    f.write(student_code)

        if shared_dir is None:
            shared_dir = os.path.join(os.path.dirname(data_dir), "shared")
            os.makedirs(shared_dir, exist_ok=True)

        task_slug = task_config.get("task_slug", "unknown")
        config_path = f"/root_data/eval/configs/{task_slug}.json"

        result = subprocess.run(
            [
                self.docker_bin, "run", "--rm", "--user", "root",
                "--network=none", "--memory=4g", "--pids-limit=256",
                "--cap-drop=ALL", "--cap-add=SETUID", "--cap-add=SETGID",
                "-v", f"{data_dir}:/workdir/data",
                "-v", f"{shared_dir}:/workdir/shared:ro",
                image, "bash", "-c",
                f"/root/.venv/bin/python /root_data/eval/scoring.py "
                f"{config_path} /tmp/score.json >/dev/null 2>&1; "
                f"cat /tmp/score.json 2>/dev/null || "
                f'echo \'{{"score": 0.0, "metadata": {{"error": "scoring crashed"}}}}\'',
            ],
            capture_output=True, text=True, timeout=300,
        )

        try:
            score_data = json.loads(result.stdout.strip())
        except (json.JSONDecodeError, ValueError):
            score_data = {"score": 0.0, "metadata": {"error": f"Parse error: {result.stdout[:200]}"}}

        # Read student files after scoring
        student_files = {}
        for f in os.listdir(data_dir):
            fpath = os.path.join(data_dir, f)
            if os.path.isfile(fpath) and os.path.getsize(fpath) < 50000:
                try:
                    student_files[f"data/{f}"] = open(fpath).read()
                except Exception:
                    pass

        if cleanup:
            import shutil as _shutil
            _shutil.rmtree(tmpdir, ignore_errors=True)

        return {
            "task": task_slug,
            "score": score_data.get("score", 0.0),
            "scoring_metadata": score_data.get("metadata", {}),
            "student_files": student_files,
            "tool_calls_total": 0,
            "time_seconds": 0,
        }

    # Tool definitions for the agent solve loop (Anthropic tool_use format)
    SOLVE_TOOLS = [
        {
            "name": "read_file",
            "description": "Read a file from the working directory. Paths are relative to /workdir/ (e.g. 'data/solution.py', 'shared/reference.txt').",
            "input_schema": {
                "type": "object",
                "properties": {"path": {"type": "string", "description": "File path relative to /workdir/"}},
                "required": ["path"],
            },
        },
        {
            "name": "write_file",
            "description": "Write content to a file in /workdir/data/. Only files in data/ can be written.",
            "input_schema": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "File path relative to /workdir/data/ (e.g. 'solution.py')"},
                    "content": {"type": "string", "description": "Full file content to write"},
                },
                "required": ["path", "content"],
            },
        },
        {
            "name": "bash",
            "description": "Run a bash command inside the scoring container. Network is disabled. Timeout 30s.",
            "input_schema": {
                "type": "object",
                "properties": {"command": {"type": "string", "description": "Command to execute"}},
                "required": ["command"],
            },
        },
    ]

    def _call_anthropic(self, messages: list, api_key: str, model: str,
                        tools: list | None = None, api_base: str | None = None) -> dict:
        """Call the Anthropic Messages API and return the raw response."""
        base = api_base or os.environ.get("ANTHROPIC_BASE_URL") or "https://api.anthropic.com"
        base = base.rstrip("/")
        url = f"{base}/v1/messages"

        payload: dict = {
            "model": model,
            "max_tokens": 8192,
            "messages": messages,
        }
        if tools:
            payload["tools"] = tools

        body = json.dumps(payload).encode()
        req = urllib.request.Request(
            url, data=body,
            headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
                "User-Agent": "athanor-runner/0.2.0",
            },
        )
        resp = urllib.request.urlopen(req, timeout=180)
        return json.loads(resp.read())

    def _exec_tool(self, name: str, args: dict, data_dir: str, shared_dir: str, image: str) -> str:
        """Execute a tool call and return the result string."""
        if name == "read_file":
            path = args.get("path", "")
            # Resolve to data/ or shared/
            if path.startswith("data/"):
                full = os.path.join(os.path.dirname(data_dir), path)
            elif path.startswith("shared/"):
                full = os.path.join(os.path.dirname(data_dir), path)
            else:
                full = os.path.join(data_dir, path)
            if not os.path.isfile(full):
                return f"Error: file not found: {path}"
            try:
                content = open(full).read()
                return content[:30000]
            except Exception as e:
                return f"Error reading file: {e}"

        elif name == "write_file":
            path = args.get("path", "")
            content = args.get("content", "")
            # Only write to data/
            full = os.path.join(data_dir, os.path.basename(path))
            with open(full, "w") as f:
                f.write(content)
            return f"Written {len(content)} chars to data/{os.path.basename(path)}"

        elif name == "bash":
            cmd = args.get("command", "")
            try:
                result = subprocess.run(
                    [
                        self.docker_bin, "run", "--rm", "--user", "root",
                        "--network=none", "--memory=4g", "--pids-limit=256",
                        "--cap-drop=ALL", "--cap-add=SETUID", "--cap-add=SETGID",
                        "-v", f"{data_dir}:/workdir/data",
                        "-v", f"{shared_dir}:/workdir/shared:ro",
                        image, "bash", "-c", cmd,
                    ],
                    capture_output=True, text=True, timeout=30,
                )
                output = result.stdout[:5000]
                if result.stderr:
                    output += f"\nSTDERR:\n{result.stderr[:2000]}"
                if result.returncode != 0:
                    output += f"\n(exit code {result.returncode})"
                return output or "(no output)"
            except subprocess.TimeoutExpired:
                return "Error: command timed out (30s)"
            except Exception as e:
                return f"Error: {e}"

        return f"Unknown tool: {name}"

    def run_solve(self, image: str, task_config: dict, model: str = "claude-opus-4-6",
                   api_key: str | None = None, max_turns: int = 30) -> dict:
        """Run a full agent solve loop with tool use: read/write files, bash, score, retry."""
        api_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
        if not api_key:
            return {"error": "ANTHROPIC_API_KEY required for solve"}

        task_slug = task_config.get("task_slug", "unknown")
        stub_code = task_config.get("stub_code", "")
        stub_filename = task_config.get("stub_filename", "solution.py")
        description = task_config.get("task_description", "")

        print(f"  Solving {task_slug} with {model}...")

        # Set up workdir
        tmpdir = tempfile.mkdtemp(prefix="athanor-solve-")
        data_dir = os.path.join(tmpdir, "data")
        shared_dir = os.path.join(tmpdir, "shared")
        os.makedirs(data_dir)
        os.makedirs(shared_dir)

        # Write stub file(s)
        student_path = os.path.join(data_dir, stub_filename)
        with open(student_path, "w") as f:
            f.write(stub_code)

        # Write additional stub files if present (multi-file tasks)
        extra_files = task_config.get("extra_files", {})
        for fname, content in extra_files.items():
            with open(os.path.join(data_dir, fname), "w") as f:
                f.write(content)

        # Copy shared data from container
        subprocess.run(
            [self.docker_bin, "run", "--rm", image, "tar", "-cf", "-", "-C", "/workdir/shared", "."],
            stdout=open(os.path.join(tmpdir, "shared.tar"), "wb"),
            timeout=30,
        )
        subprocess.run(["tar", "-xf", os.path.join(tmpdir, "shared.tar"), "-C", shared_dir], timeout=10)

        # List available files for context
        data_files = os.listdir(data_dir)
        shared_files = []
        try:
            shared_files = os.listdir(shared_dir)
        except OSError:
            pass

        # Build system prompt
        system = (
            "You are solving a coding task. Use the provided tools to read files, write solutions, "
            "and run commands.\n\n"
            f"Task: {description}\n\n"
            f"Files in data/ (editable): {', '.join(data_files)}\n"
            f"Files in shared/ (read-only): {', '.join(shared_files[:20])}\n\n"
            f"Primary file to edit: data/{stub_filename}\n"
            "Write your solution using write_file, then I will score it automatically."
        )

        messages: list[dict] = [
            {"role": "user", "content": (
                f"Solve this task by editing the file(s) in data/.\n\n"
                f"--- data/{stub_filename} ---\n{stub_code}\n\n"
                "Start by reading any shared/ reference files you need, then write your solution."
            )},
        ]

        best_score = 0.0
        best_files: dict[str, str] = {}
        tool_call_count = 0
        score_result: dict = {}
        start_time = time.time()

        for turn in range(max_turns):
            # Call LLM
            try:
                resp = self._call_anthropic(
                    messages, api_key, model,
                    tools=self.SOLVE_TOOLS,
                )
            except Exception as e:
                print(f"    Turn {turn + 1}: API error: {e}")
                break

            stop_reason = resp.get("stop_reason", "end_turn")
            content_blocks = resp.get("content", [])

            # Build assistant message for conversation history
            assistant_content = []
            for block in content_blocks:
                if block.get("type") == "text":
                    assistant_content.append({"type": "text", "text": block["text"]})
                elif block.get("type") == "tool_use":
                    assistant_content.append(block)

            messages.append({"role": "assistant", "content": assistant_content})

            # Process tool calls
            tool_results = []
            has_tool_use = False
            for block in content_blocks:
                if block.get("type") != "tool_use":
                    continue
                has_tool_use = True
                tool_call_count += 1
                tool_name = block["name"]
                tool_args = block.get("input", {})
                result_text = self._exec_tool(tool_name, tool_args, data_dir, shared_dir, image)
                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": block["id"],
                    "content": result_text[:10000],
                })

            if tool_results:
                messages.append({"role": "user", "content": tool_results})
                continue  # Let the model keep using tools

            # No tool calls — model is done with this attempt. Score it.
            score_result = self.run_score(image, task_config, data_dir=data_dir, shared_dir=shared_dir)
            score = score_result.get("score", 0.0)
            meta = score_result.get("scoring_metadata", {})
            print(f"    Turn {turn + 1}: score={score:.3f} (tools={tool_call_count})")

            if score > best_score:
                best_score = score
                best_files = {}
                for f in os.listdir(data_dir):
                    fpath = os.path.join(data_dir, f)
                    if os.path.isfile(fpath) and os.path.getsize(fpath) < 50000:
                        try:
                            best_files[f"data/{f}"] = open(fpath).read()
                        except Exception:
                            pass

            if score >= 0.95:
                print(f"  Solved! Score: {score:.3f}")
                break

            # Build retry feedback
            feedback = f"Score: {score:.3f}."
            if meta.get("error"):
                feedback += f" Error: {meta['error']}"
            if meta.get("checks_passed") is not None:
                feedback += f" Checks: {meta['checks_passed']}/{meta.get('checks_total', '?')}"
            if meta.get("sorry_count") is not None:
                feedback += f" Sorry count: {meta['sorry_count']}"
            if meta.get("compilation_errors"):
                errors = meta["compilation_errors"]
                if isinstance(errors, str):
                    feedback += f"\nCompilation:\n{errors[:1500]}"

            messages.append({"role": "user", "content": (
                f"{feedback}\n\nTry again. Use the tools to fix the issues."
            )})

        elapsed = time.time() - start_time

        # Collect final student files
        student_files = best_files or {}
        if not student_files:
            for f in os.listdir(data_dir):
                fpath = os.path.join(data_dir, f)
                if os.path.isfile(fpath) and os.path.getsize(fpath) < 50000:
                    try:
                        student_files[f"data/{f}"] = open(fpath).read()
                    except Exception:
                        pass

        # Clean up
        import shutil as _shutil
        _shutil.rmtree(tmpdir, ignore_errors=True)

        return {
            "task": task_slug,
            "score": best_score,
            "scoring_metadata": score_result.get("scoring_metadata", {}),
            "student_files": student_files,
            "tool_calls_total": tool_call_count,
            "time_seconds": round(elapsed, 1),
        }

    def run_build(self, image: str, config: dict, api_key: str) -> dict:
        """Generate a task using Opus 4.6 and validate scoring works."""
        task_name = config.get("task_name", "unnamed_task")
        description = config.get("description", "")
        difficulty = config.get("difficulty", "medium")
        category = config.get("category", "implementation")
        proof_backend = config.get("proof_backend", "none")
        scoring_type = config.get("scoring_type", "property_tests")
        env_slug = config.get("environment", "")

        print(f"  Building task: {task_name}")

        prompt = (
            f'Generate a verified training task for the "{env_slug}" environment.\n\n'
            f"Task name: {task_name}\n"
            f"Description: {description}\n"
            f"Difficulty: {difficulty}\n"
            f"Category: {category}\n"
            f"Proof backend: {proof_backend}\n"
            f"Scoring: {scoring_type}\n\n"
            "Generate:\n"
            "1. A student stub file (the starting code the agent edits)\n"
            "2. A scoring configuration (sigmoid_center, sigmoid_scale, checks)\n"
            "3. A proof template if proof_backend is not 'none'\n\n"
            "Output as JSON with keys: stub_code, scoring_config, proof_template (or null), "
            "description, task_id, stub_filename"
        )

        try:
            resp = self._call_anthropic(
                [{"role": "user", "content": prompt}],
                api_key, "claude-opus-4-6",
            )
            text = resp.get("content", [{}])[0].get("text", "")

            # Parse JSON from response
            import re as _re
            json_match = _re.search(r'\{[\s\S]*\}', text)
            if not json_match:
                return {"error": "Could not parse JSON from Opus response", "raw": text[:2000]}

            task_data = json.loads(json_match.group())
            task_id = task_data.get("task_id", task_name)
            stub_code = task_data.get("stub_code", "")
            stub_filename = task_data.get("stub_filename", f"{task_name}.py")

            # Validate: score the stub to ensure scoring works
            if stub_code:
                score_result = self.run_score(
                    image,
                    {"task_slug": task_id, "stub_filename": stub_filename},
                    student_code=stub_code,
                )
                task_data["validation_score"] = score_result.get("score", 0.0)
                task_data["validation_metadata"] = score_result.get("scoring_metadata", {})

            return {
                "task_id": task_id,
                "task_name": task_name,
                "generated": task_data,
                "status": "validated" if stub_code else "generated",
            }

        except Exception as e:
            return {"error": f"Build failed: {e}"}

    def execute_job(self, job: dict) -> dict:
        """Execute a job and return the result."""
        job_type = job["type"]
        image = job["image"]
        config = job.get("config", {})

        print(f"  Job {job['id'][:8]}: {job_type} on {job['environment']}")

        self.pull_image(image)

        if job_type == "score":
            student_code = config.get("student_code")
            result = self.run_score(image, config, student_code)
            print(f"  Score: {result['score']:.3f}")
            return result

        elif job_type == "solve":
            model = config.get("model", "claude-opus-4-6")
            api_key = config.get("api_key") or os.environ.get("ANTHROPIC_API_KEY")
            max_turns = config.get("max_turns", 30)
            result = self.run_solve(image, config, model=model, api_key=api_key, max_turns=max_turns)
            print(f"  Score: {result.get('score', 0):.3f} ({result.get('tool_calls_total', 0)} turns)")
            return result

        elif job_type == "evaluate":
            # TODO: run evaluate.py --all-tasks
            return {"error": "evaluate not yet implemented in runner"}

        elif job_type == "build":
            api_key = config.get("api_key") or os.environ.get("ANTHROPIC_API_KEY")
            if not api_key:
                return {"error": "ANTHROPIC_API_KEY required for build jobs"}
            result = self.run_build(image, config, api_key=api_key)
            print(f"  Build: {result.get('task_id', 'unknown')}")
            return result

        return {"error": f"Unknown job type: {job_type}"}

    def run_forever(self):
        """Main loop — poll for jobs and execute them."""
        if not self.runner_id:
            self.register()

        print(f"Runner '{self.name}' ready. Polling {self.platform_url}...")
        print(f"Docker: {self.docker_bin}")
        print()

        consecutive_empty = 0
        while True:
            try:
                job = self.poll()
                if job:
                    consecutive_empty = 0
                    try:
                        result = self.execute_job(job)
                        self.report(job["id"], result=result)
                    except Exception as e:
                        print(f"  Job failed: {e}")
                        self.report(job["id"], error=str(e))
                else:
                    consecutive_empty += 1
                    # Back off: 2s → 5s → 10s
                    delay = min(2 * consecutive_empty, 10)
                    time.sleep(delay)

            except KeyboardInterrupt:
                print("\nShutting down...")
                break
            except Exception as e:
                print(f"Poll error: {e}")
                time.sleep(10)
