"""Docent MCP server for IDE plugins."""

import argparse
import json
import sys
from pathlib import Path
from typing import Any, cast

from mcp.server.fastmcp import FastMCP  # type: ignore[import-untyped]

from docent.sdk.client import Docent

_client: Docent | None = None
_config_file: str | Path | None = None


def get_client() -> Docent:
    global _client
    if _client is None:
        _client = Docent(config_file=_config_file, log_stream=sys.stderr)
    return _client


mcp = FastMCP("docent", json_response=True)  # type: ignore[reportUnknownVariableType]


@mcp.tool()  # type: ignore[reportUnknownMemberType, reportUntypedFunctionDecorator]
def get_metadata_fields(collection_id: str) -> str:
    """Get the available metadata fields for agent runs in a collection.

    These can be accessed on the metadata_json column in DQL, e.g. foo.bar can be accessed as
    `metadata_json->'foo'->>'bar'`.
    """
    client = get_client()
    try:
        response = client.get_metadata_fields(
            collection_id, include_sample_values=True, sample_limit=10
        )

        fields = response.get("fields", [])
        total_runs = response.get("total_runs")

        if not fields:
            return f"No metadata fields found for collection {collection_id}"

        def _render_value(value: str) -> str:
            value = value.replace("\n", "\\n")
            if len(value) > 80:
                return value[:77] + "..."
            return value

        lines: list[str] = []
        for field in fields:
            name = str(field.get("name", "(unknown)"))
            name = name.removeprefix("metadata.")
            field_type = str(field.get("type", "str"))
            line = f"- {name} ({field_type})"

            sample_values = cast(list[dict[str, Any]], field.get("sample_values") or [])
            total_unique_values = cast(int | None, field.get("total_unique_values"))
            if sample_values:
                rendered_samples = ", ".join(
                    f"{_render_value(str(s.get('value', '')))} ({int(s.get('count', 0))} runs)"
                    for s in sample_values
                    if s.get("value") is not None
                )
                other_suffix = ""
                if total_unique_values is not None:
                    other_count = total_unique_values - len(sample_values)
                    if other_count > 0:
                        other_suffix = f" (+{other_count} other values)"
                line = f"{line}: {rendered_samples}{other_suffix}"

            lines.append(line)

        field_list = "\n".join(lines)
        tool_output = f"Metadata fields for collection {collection_id}:\n{field_list}"
        if total_runs is not None:
            tool_output += f"\n\nTotal runs: {total_runs}"
        return tool_output
    except Exception as e:
        api_url = client.backend_url
        error_msg = str(e)
        if "404" in error_msg:
            return f"Collection not found on {api_url}: {collection_id}"
        return f"Error fetching metadata fields from {api_url}: {e}"


@mcp.tool()  # type: ignore[reportUnknownMemberType, reportUntypedFunctionDecorator]
def save_report_file(
    path: str,
) -> str:
    """Create a persisted report from a local Markdown file."""
    client = get_client()
    try:
        response = client.save_report_file(path)
        resolved_collection_id = str(response.get("collection_id", ""))
        report_id = str(response.get("id", ""))
        report_title = str(response.get("title", "(untitled)"))
        revision = response.get("revision")
        report_url = f"{client.frontend_url}/dashboard/{resolved_collection_id}/reports/{report_id}"
        return (
            f"Saved report '{report_title}'\n"
            f"- Collection: {resolved_collection_id}\n"
            f"- Report ID: {report_id}\n"
            f"- Revision: {revision}\n"
            f"- URL: {report_url}"
        )
    except Exception as e:
        return f"Error saving report file: {e}"


@mcp.tool()  # type: ignore[reportUnknownMemberType, reportUntypedFunctionDecorator]
def update_report_file(path: str, report_id: str, expected_revision: int) -> str:
    """Update a persisted report from a local Markdown file."""
    client = get_client()
    try:
        response = client.update_report_file(
            path,
            report_id=report_id,
            expected_revision=expected_revision,
        )
        resolved_collection_id = str(response.get("collection_id", ""))
        report_id = str(response.get("id", ""))
        report_title = str(response.get("title", "(untitled)"))
        revision = response.get("revision")
        report_url = f"{client.frontend_url}/dashboard/{resolved_collection_id}/reports/{report_id}"
        return (
            f"Updated report '{report_title}'\n"
            f"- Collection: {resolved_collection_id}\n"
            f"- Report ID: {report_id}\n"
            f"- Revision: {revision}\n"
            f"- URL: {report_url}"
        )
    except Exception as e:
        return f"Error updating report file: {e}"


@mcp.tool()  # type: ignore[reportUnknownMemberType, reportUntypedFunctionDecorator]
def get_report(collection_id: str, report_id: str) -> str:
    """Get a persisted report by ID."""
    client = get_client()
    try:
        report = client.get_report(collection_id, report_id)
        title = str(report.get("title", "(untitled)"))
        revision = report.get("revision")
        source_reading_plan_id = str(report.get("source_reading_plan_id", ""))
        markdown = str(report.get("markdown", ""))
        preview = markdown[:500]
        if len(markdown) > 500:
            preview += "..."
        return (
            f"Report: {title}\n"
            f"- ID: {report_id}\n"
            f"- Revision: {revision}\n"
            f"- Source reading plan: {source_reading_plan_id}\n\n"
            f"{preview}"
        )
    except Exception as e:
        return f"Error fetching report: {e}"


@mcp.tool()  # type: ignore[reportUnknownMemberType, reportUntypedFunctionDecorator]
def list_reports(
    collection_id: str,
    source_reading_plan_id: str | None = None,
    prefix: str | None = None,
    owned_only: bool = True,
) -> str:
    """List persisted reports in a collection."""
    client = get_client()
    try:
        reports = client.list_reports(
            collection_id,
            source_reading_plan_id=source_reading_plan_id,
            prefix=prefix,
            owned_only=owned_only,
        )
        if not reports:
            if source_reading_plan_id is not None and prefix:
                return (
                    f"No reports found for collection {collection_id} with "
                    f"source_reading_plan_id '{source_reading_plan_id}' and prefix '{prefix}'"
                )
            if source_reading_plan_id is not None:
                return (
                    f"No reports found for collection {collection_id} with "
                    f"source_reading_plan_id '{source_reading_plan_id}'"
                )
            if prefix:
                return f"No reports found for collection {collection_id} with prefix '{prefix}'"
            return f"No reports found for collection {collection_id}"

        lines: list[str] = []
        for report in reports:
            title = str(report.get("title", "(untitled)"))
            report_id = str(report.get("id", ""))
            revision = report.get("revision")
            updated_at = report.get("updated_at")
            owner = str(report.get("created_by", ""))
            report_source_reading_plan_id = str(report.get("source_reading_plan_id", ""))
            lines.append(
                f"- {title} (ID: {report_id}, owner: {owner}, revision: {revision}, "
                f"source_reading_plan_id: {report_source_reading_plan_id}, updated_at: {updated_at})"
            )
        return f"Reports for collection {collection_id}:\n" + "\n".join(lines)
    except Exception as e:
        return f"Error listing reports: {e}"


@mcp.tool()  # type: ignore[reportUnknownMemberType, reportUntypedFunctionDecorator]
def list_reading_presets(collection_id: str, name_filter: str | None = None) -> str:
    "List saved reading presets in a collection. Presets are reusable reading configurations (prompt template, model, output schema) that can be run via client.read_with_preset(). Use name_filter to search by name substring."
    client = get_client()
    if not collection_id:
        return "Error: collection_id is required (pass explicitly or set DOCENT_COLLECTION_ID)"

    try:
        presets = client.list_reading_presets(collection_id)

        if name_filter:
            lower_filter = name_filter.lower()
            presets = [p for p in presets if lower_filter in (p.get("name") or "").lower()]

        if not presets:
            filter_msg = f" matching '{name_filter}'" if name_filter else ""
            return f"No reading presets found for collection {collection_id}{filter_msg}"

        if len(presets) <= 20:
            lines: list[str] = []
            for p in presets:
                preset_id = p.get("id", "")
                name = p.get("name") or "(unnamed)"
                version_count = len(p.get("versions") or [])

                detail_parts = [f"ID: {preset_id}", f"{version_count} version(s)"]
                try:
                    config = client.get_reading_preset_config(collection_id, preset_id)
                    reading_config = cast(dict[str, Any], config.get("reading_config") or {})
                    model = cast(dict[str, Any], reading_config.get("model") or {})
                    provider = str(model.get("provider", ""))
                    model_name = str(model.get("model_name", ""))
                    if provider and model_name:
                        detail_parts.append(f"model: {provider}/{model_name}")
                    segments = cast(list[Any], reading_config.get("prompt_template_segments") or [])
                    text_parts = [str(s) for s in segments if isinstance(s, str)]
                    if text_parts:
                        preview = " ".join(text_parts)[:120]
                        if len(" ".join(text_parts)) > 120:
                            preview += "..."
                        detail_parts.append(f'prompt: "{preview}"')
                except Exception:
                    pass

                lines.append(f"- {name} ({', '.join(detail_parts)})")

            return f"Reading presets for collection {collection_id}:\n" + "\n".join(lines)

        lines = [f"- {p.get('name') or '(unnamed)'} (ID: {p.get('id', '')})" for p in presets]
        return (
            f"Found {len(presets)} reading presets for collection {collection_id} "
            f"(showing names only; call again with name_filter to see details):\n"
            + "\n".join(lines)
        )
    except Exception as e:
        api_url = client.backend_url
        error_msg = str(e)
        if "404" in error_msg:
            return f"Collection not found on {api_url}: {collection_id}"
        return f"Error fetching reading presets from {api_url}: {e}"


@mcp.tool()  # type: ignore[reportUnknownMemberType, reportUntypedFunctionDecorator]
def get_reading_models() -> str:
    "List the LLM models available for readings. Returns model name, provider, context window size, and whether BYOK (bring-your-own-key) is required."
    client = get_client()
    try:
        models = client.get_reading_models()
        if not models:
            return "No reading models available"

        lines: list[str] = []
        for m in models:
            provider = str(m.get("provider", ""))
            model_name = str(m.get("model_name", ""))
            context_window = m.get("context_window")
            uses_byok = m.get("uses_byok", False)
            reasoning_effort = m.get("reasoning_effort")

            parts = [f"{provider}/{model_name}"]
            if context_window is not None:
                parts.append(f"context: {int(context_window):,} tokens")
            if reasoning_effort:
                parts.append(f"reasoning: {reasoning_effort}")
            if uses_byok:
                parts.append("BYOK required")
            lines.append(f"- {' | '.join(parts)}")

        return "Available reading models:\n" + "\n".join(lines)
    except Exception as e:
        api_url = client.backend_url
        return f"Error fetching reading models from {api_url}: {e}"


MAX_READING_RESULTS = 30
MAX_DQL_ROWS = 100


@mcp.tool()  # type: ignore[reportUnknownMemberType, reportUntypedFunctionDecorator]
def execute_dql(collection_id: str, dql: str) -> str:
    """Execute a read-only DQL query against a collection and return results as a formatted table.

    Use this for ad-hoc exploration: counting runs, checking score distributions, inspecting
    metadata values, etc. Results are returned directly (not shown in the Docent UI).

    Args:
        collection_id: The collection to query.
        dql: The DQL query string. Follows SQL syntax with Docent-specific tables
            (agent_runs, transcripts, judge_results, etc.).
    """
    client = get_client()
    try:
        dql_result = client.execute_dql(collection_id, dql, source="mcp")
        return _format_dql_results("Query result", dql_result)
    except Exception as e:
        return f"Error executing DQL query: {e}"


def _format_plan_overview(plan: dict[str, Any], result_counts: dict[str, int]) -> str:
    """Format a plan state dict into a human-readable overview."""
    name = plan.get("name") or "(unnamed)"
    plan_id = plan.get("plan_id", "")
    lines = [f'Plan: "{name}" (plan_id: {plan_id})', ""]

    steps = cast(list[dict[str, Any]], plan.get("steps") or [])
    if not steps:
        lines.append("No steps in this plan.")
        return "\n".join(lines)

    lines.append("Steps:")
    for i, step in enumerate(steps, 1):
        step_type = str(step.get("type", ""))
        alias = step.get("alias", "")
        step_name = step.get("name") or step.get("label") or alias
        status = step.get("derived_status", "unknown")

        if step_type == "begin_step_group":
            lines.append(f'  {i}. [group] "{step_name}"')
        elif step_type == "end_step_group":
            lines.append(f"  {i}. [end group]")
        elif step_type == "dql_only":
            lines.append(f'  {i}. "{step_name}" (dql_only, status: {status})')
        elif step_type == "reading":
            count = result_counts.get(alias)
            count_str = f", {count} result{'s' if count != 1 else ''}" if count is not None else ""
            lines.append(f'  {i}. "{step_name}" (reading, status: {status}{count_str})')
        else:
            lines.append(f"  {i}. {step_name} ({step_type})")

    return "\n".join(lines)


def _format_reading_results(
    step_name: str, reading_id: str, results: list[dict[str, Any]], total: int
) -> str:
    """Format reading results into a human-readable string."""
    lines = [
        f'Reading step: "{step_name}" ({total} result{"s" if total != 1 else ""})',
        f"Reading ID: {reading_id} (query via DQL `reading_results` / `reading_result_links`)",
    ]

    completed = sum(1 for r in results if r.get("status") == "completed")
    failed = sum(1 for r in results if r.get("status") == "failed")
    pending = sum(1 for r in results if r.get("status") == "pending")
    status_parts: list[str] = []
    if completed:
        status_parts.append(f"{completed} completed")
    if failed:
        status_parts.append(f"{failed} failed")
    if pending:
        status_parts.append(f"{pending} pending")
    if status_parts:
        lines.append(f"Status: {', '.join(status_parts)}")
    lines.append("")

    shown = results[:MAX_READING_RESULTS]
    for i, r in enumerate(shown, 1):
        lines.append(f"--- Result {i} ---")
        args = cast(dict[str, Any], r.get("arguments_dict") or {})
        if args:
            args_str = ", ".join(f"{k}: {v}" for k, v in args.items())
            lines.append(f"Arguments: {{{args_str}}}")
        output = r.get("output")
        error = r.get("error")
        if error is not None:
            lines.append(f"Error: {json.dumps(error)}")
        elif output is not None:
            lines.append(f"Output: {json.dumps(output)}")
        else:
            lines.append("Status: pending")
        lines.append("")

    if total > MAX_READING_RESULTS:
        lines.append(f"(showing {MAX_READING_RESULTS} of {total} results)")

    return "\n".join(lines)


def _format_dql_results(step_name: str, dql_result: dict[str, Any]) -> str:
    """Format DQL execution results into a human-readable table."""
    columns = cast(list[str], dql_result.get("columns") or [])
    rows = cast(list[list[Any]], dql_result.get("rows") or [])
    total_rows = len(rows)

    lines = [f'DQL step: "{step_name}" ({total_rows} row{"s" if total_rows != 1 else ""})']
    lines.append("")

    if not columns or not rows:
        lines.append("(no results)")
        return "\n".join(lines)

    display_rows = rows[:MAX_DQL_ROWS]

    str_rows = [[str(v) if v is not None else "NULL" for v in row] for row in display_rows]
    col_widths = [len(c) for c in columns]
    for row in str_rows:
        for j, cell in enumerate(row):
            if j < len(col_widths):
                col_widths[j] = max(col_widths[j], len(cell))

    header = " | ".join(c.ljust(col_widths[j]) for j, c in enumerate(columns))
    separator = "-+-".join("-" * w for w in col_widths)
    lines.append(header)
    lines.append(separator)
    for row in str_rows:
        line = " | ".join(
            (row[j] if j < len(row) else "").ljust(col_widths[j]) for j in range(len(columns))
        )
        lines.append(line)

    if total_rows > MAX_DQL_ROWS:
        lines.append(f"\n(showing {MAX_DQL_ROWS} of {total_rows} rows)")

    return "\n".join(lines)


@mcp.tool()  # type: ignore[reportUnknownMemberType, reportUntypedFunctionDecorator]
def get_reading_plan_results(
    collection_id: str,
    plan_name: str,
    step_name: str | None = None,
) -> str:
    """View the status and results of a reading plan. Reading plans are created by analysis scripts using the Docent SDK (client.read(), client.show_query_result(), etc.).

    - Without step_name: shows an overview of all steps with their types, statuses, and result counts.
    - With step_name: shows the actual results for that step. For reading steps, this is the LLM output. For dql_only steps, this executes the DQL query and returns the table.

    Args:
        collection_id: The collection ID.
        plan_name: The name of the reading plan (set via client.plan_name in the script).
        step_name: Optional step name to view results for. If omitted, shows the plan overview.
    """
    client = get_client()
    try:
        plans = client.list_reading_plans(
            collection_id,
            name=plan_name,
        )
        if not plans:
            return f'No reading plans found with name "{plan_name}" in collection {collection_id}'

        plans.sort(key=lambda p: p.get("updated_at") or p.get("created_at") or "", reverse=True)
        plan_id = plans[0]["plan_id"]

        plan = client.get_reading_plan(collection_id, plan_id)
        steps = cast(list[dict[str, Any]], plan.get("steps") or [])

        if step_name is None:
            result_counts: dict[str, int] = {}
            for step in steps:
                if step.get("type") == "reading" and step.get("reading_id"):
                    try:
                        results = client.get_reading_results(
                            collection_id,
                            step["reading_id"],
                            include_output=False,
                        )
                        result_counts[step["alias"]] = len(results)
                    except Exception:
                        pass
            return _format_plan_overview(plan, result_counts)

        matching_step: dict[str, Any] | None = None
        for step in steps:
            if step.get("name") == step_name:
                matching_step = step
                break
        if matching_step is None:
            for step in steps:
                if step.get("alias") == step_name:
                    matching_step = step
                    break
        if matching_step is None:
            available = [
                s.get("name") or s.get("label") or s.get("alias", "")
                for s in steps
                if s.get("type") in ("reading", "dql_only")
            ]
            return (
                f'Step "{step_name}" not found in plan "{plan_name}".\n'
                f"Available steps: {', '.join(available)}"
            )

        step_type = matching_step.get("type")
        display_name = matching_step.get("name") or matching_step.get("alias", "")

        if step_type == "reading":
            reading_id = matching_step.get("reading_id")
            if not reading_id:
                status = matching_step.get("derived_status", "unknown")
                return f'Reading step "{display_name}" has not been resolved yet (status: {status})'
            results = client.get_reading_results(collection_id, reading_id)
            return _format_reading_results(display_name, reading_id, results, len(results))

        if step_type == "dql_only":
            dql_query = matching_step.get("dql_query")
            if not dql_query:
                return f'DQL step "{display_name}" has no query'
            dql_result = client.execute_dql(
                collection_id, dql_query, reading_plan_id=plan_id, source="mcp"
            )
            return _format_dql_results(display_name, dql_result)

        return f'Step "{display_name}" is of type "{step_type}" which does not produce viewable results'

    except Exception as e:
        api_url = client.backend_url
        error_msg = str(e)
        if "404" in error_msg:
            return f"Not found on {api_url}: {e}"
        return f"Error querying {api_url}: {e}"


def main():
    global _config_file

    parser = argparse.ArgumentParser(description="Docent MCP Server")
    parser.add_argument(
        "--config-file",
        type=str,
        help="Path to a dotenv config file with DOCENT_API_KEY, DOCENT_API_URL, etc.",
    )
    args = parser.parse_args()

    if args.config_file:
        _config_file = args.config_file

    mcp.run(transport="stdio")  # type: ignore[reportUnknownMemberType]
