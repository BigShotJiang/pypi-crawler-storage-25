from typing import Any


class LLMException(Exception):
    error_type_id = "other"
    user_message = "The model failed to respond. Please try again later."

    def serialize(self) -> dict[str, Any]:
        data: dict[str, Any] = {
            "type": self.__class__.__name__,
            "user_message": getattr(self, "user_message", None),
            "error_type_id": getattr(self, "error_type_id", None),
        }
        if failed_output := getattr(self, "failed_output", None):
            data["failed_output"] = str(failed_output)
        return data

    @classmethod
    def serialize_llm_errors(cls, errors: list["LLMException"]) -> list[dict[str, Any]]:
        return [error.serialize() for error in errors]


class CompletionTooLongException(LLMException):
    error_type_id = "completion_too_long"
    user_message = (
        "The model stopped because the completion hit max_new_tokens. "
        "Increase max_new_tokens and try again."
    )


class RateLimitException(LLMException):
    error_type_id = "rate_limit"
    user_message = "Rate limited by the model provider. Please wait and try again."


class ContextWindowException(LLMException):
    error_type_id = "context_window"
    user_message = "Context window exceeded."


class InvalidPromptException(LLMException):
    error_type_id = "invalid_prompt"
    user_message = "The model provider rejected this prompt for safety reasons."


class NoResponseException(LLMException):
    error_type_id = "no_response"
    user_message = "The model returned an empty response. Please try again later."


class DocentUsageLimitException(LLMException):
    error_type_id = "docent_usage_limit"
    user_message = (
        "Free weekly usage limit reached. Add your own API key in settings or "
        "email docent@transluce.org to inquire about custom usage limits."
    )


class ProviderAuthenticationException(LLMException):
    error_type_id = "provider_authentication"

    def __init__(self, message: str = ""):
        super().__init__(message)
        self.user_message = (
            "The model provider API key could not be authenticated. "
            "If you added your own key, update it in Settings > Model providers."
        )


class ValidationFailedException(LLMException):
    error_type_id = "validation_failed"
    user_message = "The model returned invalid output that failed validation."

    def __init__(self, message: str = "", failed_output: str | None = None):
        super().__init__(message)
        self.failed_output = failed_output


class TimeoutException(LLMException):
    error_type_id = "timeout"
    user_message = "The request timed out. The model took too long to respond."


LLM_ERROR_TYPES: list[type[LLMException]] = [
    LLMException,
    CompletionTooLongException,
    RateLimitException,
    ContextWindowException,
    InvalidPromptException,
    NoResponseException,
    DocentUsageLimitException,
    ProviderAuthenticationException,
    ValidationFailedException,
    TimeoutException,
]
