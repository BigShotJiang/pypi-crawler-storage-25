from datetime import datetime
from typing import Annotated, Any, Literal, TypeAlias, cast
from uuid import uuid4

from pydantic import BaseModel, Field, model_validator

from docent._llm_util.providers.preference_types import ModelOption
from docent.data_models.context_config import ParameterContextConfig

# ── Shared building blocks ──────────────────────────────────────────


ReadingParamType = Literal[
    "agent_run", "transcript", "transcript_slice", "reading_result", "text", "unknown"
]
AnnotatableReadingParamType = Literal[
    "agent_run", "transcript", "transcript_slice", "reading_result", "text"
]


class ReadingParamPlaceholder(BaseModel):
    param_name: str
    param_type: ReadingParamType
    is_list: bool = False


ReadingTemplateSegment = str | ReadingParamPlaceholder

DEFAULT_READING_MAX_NEW_TOKENS = 8192


def _with_legacy_max_new_tokens_default(value: Any) -> Any:
    if not isinstance(value, dict):
        return value

    value_dict = cast(dict[str, Any], value)
    if value_dict.get("max_new_tokens") is not None:
        return value_dict

    normalized_value: dict[str, Any] = dict(value_dict)
    normalized_value["max_new_tokens"] = DEFAULT_READING_MAX_NEW_TOKENS
    return normalized_value


"""Controls caching granularity when submitting a reading step.

Reading identity is determined by a content hash. For template readings this covers the
prompt template, model config, output schema, and the resolved DQL arguments (the DQL
query is always executed regardless of cache mode). For scripted readings it covers the
prompt segments, model config, output schema, and user-supplied arguments.

- ``"reading"``: reuse an existing reading with the same content hash and its cached
  results (by cache key hash). If a match is found, no new records are created.
- ``"results"``: always create a new reading record, but still reuse cached results when
  a matching cache key hash is found (avoids redundant LLM calls).
- ``"none"``: no caching — always create a new reading and new results, forcing full
  re-evaluation.
"""
ReadingCacheMode = Literal["reading", "results", "none"]
ReadingStatus = Literal["completed", "failed", "pending", "cached", "needs_approval", "unresolved"]


class PartialReadingConfig(BaseModel):
    """Preset-side reading configuration with nullable top-level fields."""

    prompt_template_segments: list[ReadingTemplateSegment] | None = None
    context_configs: dict[str, ParameterContextConfig] | None = None
    model: ModelOption | None = None
    output_schema: dict[str, Any] | None = None
    max_new_tokens: int | None = None


class ReadingConfig(BaseModel):
    """Canonical runnable reading configuration."""

    prompt_template_segments: list[ReadingTemplateSegment]
    context_configs: dict[str, ParameterContextConfig] = Field(default_factory=dict)
    model: ModelOption
    output_schema: dict[str, Any]
    max_new_tokens: int

    @model_validator(mode="before")
    @classmethod
    def _apply_legacy_max_new_tokens_default(cls, value: Any) -> Any:
        # TODO: remove once all clients explicitly send max_new_tokens.
        return _with_legacy_max_new_tokens_default(value)


# ── Reading presets ─────────────────────────────────────────────────


class ReadingPreset(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid4()))
    collection_id: str
    name: str
    created_at: datetime | None = None
    created_by: str | None = None
    updated_at: datetime | None = None


class ReadingPresetVersion(PartialReadingConfig):
    reading_preset_id: str
    version_index: int
    created_at: datetime | None = None


# ── Core reading / result domain models ─────────────────────────────


class Reading(BaseModel):
    """
    Attributes:
        content_hash: represents the full identity including resolved arguments, used to deduplicate readings
        is_template: whether the reading is a template or an scripted request
        prompt_template_segments: None for scripted readings
        context_configs: None for scripted readings
        dql_query: None for scripted readings
        source_reading_preset_id: preset this reading was created from (config may not match exactly if user made changes)
    """

    id: str = Field(default_factory=lambda: str(uuid4()))
    collection_id: str
    content_hash: str
    is_template: bool
    prompt_template_segments: list[ReadingTemplateSegment] | None = None
    context_configs: dict[str, ParameterContextConfig] | None = None
    dql_query: str | None = None
    model: ModelOption
    output_schema: dict[str, Any]
    max_new_tokens: int
    user_metadata: dict[str, Any] | None = None
    source_reading_preset_id: str | None = None
    source_reading_preset_version: int | None = None
    created_at: datetime | None = None
    created_by: str | None = None


class ReadingResult(BaseModel):
    """
    This is created before the LLM call is made, so most attributes start out as None.

    Attributes:
        cache_key_hash: before calling the LLM, we look for an existing result with the same cache_key_hash; if one exists, we reuse it and link it
        arguments_dict: arguments filled into template slots; for scripted readings this is user-supplied
        prompt_segments: None for template readings
        llm_context_spec: None for template readings
        created_at: set by DB, None until then
    """

    id: str = Field(default_factory=lambda: str(uuid4()))
    cache_key_hash: str
    arguments_dict: dict[str, Any] = Field(default_factory=dict)
    prompt_segments: list[Any] | None = None
    llm_context_spec: dict[str, Any] | None = None
    output: dict[str, Any] | None = None
    error: dict[str, Any] | None = None
    input_tokens: int | None = None
    output_tokens: int | None = None
    item_token_estimates: dict[str, int] | None = None
    created_at: datetime | None = None


# ── Plan steps (persisted in ReadingPlan) ────────────────────────────


class BeginGroupStep(BaseModel):
    type: Literal["begin_step_group"] = "begin_step_group"
    alias: str
    label: str
    submitted_at: datetime | None = None


class EndGroupStep(BaseModel):
    type: Literal["end_step_group"] = "end_step_group"
    alias: str
    submitted_at: datetime | None = None


class DqlOnlyStep(BaseModel):
    type: Literal["dql_only"] = "dql_only"
    alias: str
    name: str | None = None
    dql_query: str
    submitted_at: datetime | None = None


class ReadingStep(BaseModel):
    type: Literal["reading"] = "reading"
    alias: str
    name: str | None = None
    reading_id: str | None = None
    dql_query: str | None = None
    dql_step_alias: str | None = None
    prompt_template_segments: list[Any] | None = None
    context_configs: dict[str, Any] | None = None
    model: ModelOption
    output_schema: dict[str, Any]
    max_new_tokens: int
    user_metadata: dict[str, Any] | None = None
    source_reading_preset_id: str | None = None
    source_reading_preset_version: int | None = None
    cache_mode: ReadingCacheMode = "reading"
    approved_at: datetime | None = None
    submitted_at: datetime | None = None

    @model_validator(mode="before")
    @classmethod
    def _apply_legacy_max_new_tokens_default(cls, value: Any) -> Any:
        # TODO: remove once persisted reading_plan steps always include max_new_tokens.
        return _with_legacy_max_new_tokens_default(value)

    @model_validator(mode="after")
    def _validate_preset_reference(self) -> "ReadingStep":
        if self.source_reading_preset_version is not None and self.source_reading_preset_id is None:
            raise ValueError(
                "ReadingStep: source_reading_preset_version cannot be set without "
                "source_reading_preset_id"
            )
        return self

    def to_submission(self, *, dql_query: str | None = None) -> "ReadingStepSubmission":
        """Convert to a ReadingStepSubmission for resolve_reading_entry.

        Optionally overrides dql_query (e.g. after alias substitution). The
        stored step's own dql_query may be None when dql_step_alias is set;
        callers are expected to pass the resolved DQL explicitly in that case.
        When a concrete DQL is supplied, clear dql_step_alias so the
        submission continues to satisfy the "exactly one DQL source" contract.
        """
        return ReadingStepSubmission(
            alias=self.alias,
            name=self.name,
            model=self.model,
            output_schema=self.output_schema,
            max_new_tokens=self.max_new_tokens,
            user_metadata=self.user_metadata,
            prompt_template_segments=self.prompt_template_segments,
            context_configs=self.context_configs,
            dql_query=dql_query if dql_query is not None else self.dql_query,
            dql_step_alias=None if dql_query is not None else self.dql_step_alias,
            source_reading_preset_id=self.source_reading_preset_id,
            source_reading_preset_version=self.source_reading_preset_version,
            cache_mode=self.cache_mode,
        )


PlanStep: TypeAlias = BeginGroupStep | EndGroupStep | DqlOnlyStep | ReadingStep


class ReadingPlan(BaseModel):
    """A plan is an ordered list of reading steps.

    Each step is a discriminated union (PlanStep) with a "type" field:
      - "step_group" / "end_step_group": visual grouping markers
      - "reading": an LLM reading step (has alias, reading_id once resolved, etc.)
      - "dql_only": a query-only step with no LLM call

    reading_id is backfilled on each reading step once the step is resolved.
    Dependent steps (whose DQL references $alias of an upstream step) start
    with reading_id=null and are resolved by the plan worker at execution time.
    """

    id: str = Field(default_factory=lambda: str(uuid4()))
    collection_id: str
    name: str | None = None
    steps: list[PlanStep] = Field(default_factory=list)  # type: ignore[reportUnknownVariableType]
    created_at: datetime | None = None
    created_by: str | None = None
    updated_at: datetime | None = None


# ── Submission format (SDK → server) ───────────────────────────────


class ScriptedRequest(BaseModel):
    """A single LLM request in a scripted reading.
    Attributes:
        arguments_dict: optional user-supplied metadata, stored on the result and included in the cache key but not used to resolve any template parameters."""

    prompt_segments: list[Any]
    arguments_dict: dict[str, Any] = Field(default_factory=dict)
    llm_context_spec: dict[str, Any]


class StepGroupSubmission(BaseModel):
    entry_type: Literal["step_group"] = "step_group"
    alias: str
    label: str


class EndStepGroupSubmission(BaseModel):
    entry_type: Literal["end_step_group"] = "end_step_group"
    alias: str


class ReadingStepSubmission(BaseModel):
    entry_type: Literal["reading"] = "reading"
    alias: str
    name: str | None = None
    model: ModelOption
    output_schema: dict[str, Any] | None = None
    max_new_tokens: int
    user_metadata: dict[str, Any] | None = None
    source_reading_preset_id: str | None = None
    source_reading_preset_version: int | None = None
    cache_mode: ReadingCacheMode = "reading"

    # Template reading fields (mutually exclusive with requests)
    prompt_template_segments: list[Any] | None = None
    context_configs: dict[str, ParameterContextConfig] | None = None
    dql_query: str | None = None
    # References a DqlOnlyStep in the same plan whose rows feed this reading.
    # Mutually exclusive with dql_query for template entries.
    dql_step_alias: str | None = None

    # Scripted reading fields (mutually exclusive with template fields)
    requests: list[ScriptedRequest] | None = None

    @model_validator(mode="before")
    @classmethod
    def _apply_legacy_max_new_tokens_default(cls, value: Any) -> Any:
        # TODO: remove once all plan-submit clients explicitly send max_new_tokens.
        return _with_legacy_max_new_tokens_default(value)

    @model_validator(mode="after")
    def _validate(self) -> "ReadingStepSubmission":
        # Scripted and template are mutually exclusive
        if (self.requests is None) == (self.prompt_template_segments is None):
            raise ValueError(
                "ReadingStepSubmission: must set one of requests / prompt_template_segments"
            )

        # Validate scripted reading
        if self.requests is not None:
            if (
                self.dql_query is not None
                or self.dql_step_alias is not None
                or self.context_configs is not None
            ):
                raise ValueError(
                    "ReadingStepSubmission: scripted readings must not set dql_query, dql_step_alias, or context_configs"
                )
            if (
                self.source_reading_preset_version is not None
                or self.source_reading_preset_id is not None
            ):
                raise ValueError(
                    "ReadingStepSubmission: scripted readings cannot be associated with a reading preset"
                )

        # Validate template reading
        else:
            if (
                self.source_reading_preset_version is not None
                and self.source_reading_preset_id is None
            ):
                raise ValueError(
                    "ReadingStepSubmission: source_reading_preset_version cannot be set "
                    "without source_reading_preset_id"
                )
            if (self.dql_query is None) == (self.dql_step_alias is None):
                raise ValueError(
                    "ReadingStepSubmission: template readings must set exactly one of dql_query / dql_step_alias"
                )

        return self


class PresetReadingStepSubmission(BaseModel):
    entry_type: Literal["preset_reading"] = "preset_reading"
    alias: str
    name: str | None = None
    source_reading_preset_id: str | None = None
    source_reading_preset_name: str | None = None
    source_reading_preset_version: int | None = None
    user_metadata: dict[str, Any] | None = None
    model: ModelOption | None = None
    output_schema: dict[str, Any] | None = None
    max_new_tokens: int | None = None
    prompt_template_segments: list[Any] | None = None
    context_configs: dict[str, ParameterContextConfig] | None = None
    dql_query: str | None = None
    dql_step_alias: str | None = None
    cache_mode: ReadingCacheMode = "reading"

    @model_validator(mode="after")
    def _validate(self) -> "PresetReadingStepSubmission":
        if (self.source_reading_preset_id is None) == (self.source_reading_preset_name is None):
            raise ValueError(
                "PresetReadingStepSubmission: set exactly one of "
                "source_reading_preset_id / source_reading_preset_name"
            )
        if (self.dql_query is None) == (self.dql_step_alias is None):
            raise ValueError(
                "PresetReadingStepSubmission: set exactly one of dql_query / dql_step_alias"
            )
        return self


class DqlOnlyStepSubmission(BaseModel):
    entry_type: Literal["dql_only"] = "dql_only"
    alias: str
    name: str | None = None
    dql_query: str


PlanStepSubmission = (
    StepGroupSubmission
    | EndStepGroupSubmission
    | ReadingStepSubmission
    | PresetReadingStepSubmission
    | DqlOnlyStepSubmission
)


class PlanSubmissionRequest(BaseModel):
    plan_id: str | None = None
    plan_name: str | None = None
    source_script: str | None = None
    entries: list[PlanStepSubmission]


class DqlPreview(BaseModel):
    columns: list[str]
    rows: list[list[Any]]
    truncated: bool
    row_count: int


class ReadingResultPreview(BaseModel):
    id: str
    output: dict[str, Any] | None = None
    error: dict[str, Any] | None = None


class PlanStepSubmissionStatus(BaseModel):
    alias: str
    entry_type: str
    status: ReadingStatus
    reading_id: str | None = None
    result_count: int | None = None
    dql_preview: DqlPreview | None = None
    result_preview: list[ReadingResultPreview] | None = None


class PlanSubmissionResponse(BaseModel):
    plan_id: str
    plan_name: str | None = None
    previous_latest_plan_id: str | None = None
    has_active_listeners: bool = False
    entry_statuses: list[PlanStepSubmissionStatus]


# ── Plan SSE stream events (server → SDK) ────────────────────────────


class PlanStreamStepStatus(BaseModel):
    """Minimal step shape carried inside a snapshot event."""

    alias: str
    reading_id: str | None = None
    derived_status: str


class PlanSnapshotEvent(BaseModel):
    type: Literal["snapshot"] = "snapshot"
    steps: list[PlanStreamStepStatus]


class PlanStepError(BaseModel):
    message: str


class PlanStepStartedEvent(BaseModel):
    type: Literal["step_started"] = "step_started"
    plan_id: str
    step_alias: str
    job_id: str
    reading_id: str


class PlanStepCompletedEvent(BaseModel):
    type: Literal["step_completed"] = "step_completed"
    plan_id: str
    step_alias: str
    job_id: str
    reading_id: str
    result_count: int | None = None


class PlanStepFailedEvent(BaseModel):
    type: Literal["step_failed"] = "step_failed"
    plan_id: str
    step_alias: str
    job_id: str
    error: PlanStepError | None = None


class PlanStepsUpdatedEvent(BaseModel):
    type: Literal["steps_updated"] = "steps_updated"
    plan_id: str


class PlanJobStartedEvent(BaseModel):
    type: Literal["job_started"] = "job_started"
    plan_id: str
    job_id: str


class PlanJobCompletedEvent(BaseModel):
    type: Literal["job_completed"] = "job_completed"
    plan_id: str
    job_id: str


class PlanJobFailedEvent(BaseModel):
    type: Literal["job_failed"] = "job_failed"
    plan_id: str
    job_id: str
    error: PlanStepError | None = None


class PlanSupersededEvent(BaseModel):
    type: Literal["plan_superseded"] = "plan_superseded"
    plan_id: str
    superseded_by_plan_id: str
    name: str | None = None


class PlanJobCancelledEvent(BaseModel):
    type: Literal["job_cancelled"] = "job_cancelled"
    plan_id: str


PlanStreamEvent: TypeAlias = Annotated[
    PlanSnapshotEvent
    | PlanStepStartedEvent
    | PlanStepCompletedEvent
    | PlanStepFailedEvent
    | PlanStepsUpdatedEvent
    | PlanJobStartedEvent
    | PlanJobCompletedEvent
    | PlanJobFailedEvent
    | PlanJobCancelledEvent
    | PlanSupersededEvent,
    Field(discriminator="type"),
]


__all__ = [
    "AnnotatableReadingParamType",
    "BeginGroupStep",
    "DEFAULT_READING_MAX_NEW_TOKENS",
    "DqlOnlyStep",
    "DqlOnlyStepSubmission",
    "DqlPreview",
    "EndGroupStep",
    "EndStepGroupSubmission",
    "PartialReadingConfig",
    "ScriptedRequest",
    "PlanStep",
    "PlanStepSubmission",
    "PlanStepSubmissionStatus",
    "PlanSubmissionRequest",
    "PlanSubmissionResponse",
    "ReadingCacheMode",
    "ReadingParamPlaceholder",
    "ReadingParamType",
    "ReadingResultPreview",
    "ReadingStatus",
    "ReadingStep",
    "ReadingStepSubmission",
    "ReadingTemplateSegment",
    "Reading",
    "ReadingConfig",
    "ReadingPlan",
    "ReadingPreset",
    "ReadingPresetVersion",
    "ReadingResult",
    "StepGroupSubmission",
    "PresetReadingStepSubmission",
    "PlanStreamEvent",
    "PlanStreamStepStatus",
    "PlanSnapshotEvent",
    "PlanStepStartedEvent",
    "PlanStepCompletedEvent",
    "PlanStepError",
    "PlanStepFailedEvent",
    "PlanStepsUpdatedEvent",
    "PlanJobStartedEvent",
    "PlanJobCompletedEvent",
    "PlanJobFailedEvent",
    "PlanJobCancelledEvent",
    "PlanSupersededEvent",
]
