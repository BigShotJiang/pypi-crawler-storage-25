import fnmatch
import json
from collections.abc import Sequence
from typing import Any, cast

from pydantic import BaseModel, ConfigDict, Field
from pydantic_core import to_jsonable_python


class GlobFilter(BaseModel):
    model_config = ConfigDict(frozen=True)

    include: tuple[str, ...] = Field(default_factory=tuple)
    exclude: tuple[str, ...] = Field(default_factory=tuple)


EXCLUDE_ALL_GLOB_FILTER = GlobFilter(exclude=("*",))
INCLUDE_ALL_GLOB_FILTER = GlobFilter(include=("*",))


class _MissingMetadata:
    pass


_MISSING_METADATA = _MissingMetadata()


def _split_metadata_path(path: str) -> tuple[str, ...]:
    return tuple(segment for segment in path.split(".") if segment)


def json_pointer_from_path(path: Sequence[str]) -> str:
    """Encode a key path as a JSON Pointer (RFC 6901). Empty path encodes as ""."""
    if not path:
        return ""
    return "/" + "/".join(segment.replace("~", "~0").replace("/", "~1") for segment in path)


def _pattern_matches_path(
    pattern_segments: tuple[str, ...], path_segments: tuple[str, ...]
) -> bool:
    if not pattern_segments:
        return not path_segments

    if not path_segments:
        return False

    pattern_head = pattern_segments[0]
    return fnmatch.fnmatchcase(path_segments[0], pattern_head) and _pattern_matches_path(
        pattern_segments[1:], path_segments[1:]
    )


def _pattern_specificity(pattern: str) -> tuple[int, int]:
    segments = _split_metadata_path(pattern)
    exact_segments = 0
    wildcard_segments = 0
    for segment in segments:
        wildcard_segments += 1
        if not any(ch in segment for ch in "*?["):
            exact_segments += 1
    return (exact_segments, wildcard_segments)


def _best_filter_match(
    path_segments: tuple[str, ...], glob_filter: GlobFilter
) -> tuple[bool, tuple[int, int]] | None:
    best: tuple[bool, tuple[int, int]] | None = None

    def _consider(pattern: str, include: bool, prefix_segments: tuple[str, ...]) -> None:
        nonlocal best
        if not _pattern_matches_path(_split_metadata_path(pattern), prefix_segments):
            return
        specificity = _pattern_specificity(pattern)
        if best is None:
            best = (include, specificity)
            return
        best_include, best_specificity = best
        if specificity > best_specificity or (
            specificity == best_specificity and best_include and not include
        ):
            best = (include, specificity)

    for prefix_len in range(len(path_segments) + 1):
        prefix_segments = path_segments[:prefix_len]
        for pattern in glob_filter.include:
            _consider(pattern, True, prefix_segments)
        for pattern in glob_filter.exclude:
            _consider(pattern, False, prefix_segments)

    return best


def glob_filter_decision(
    path: str, glob_filter: GlobFilter = EXCLUDE_ALL_GLOB_FILTER
) -> tuple[bool, tuple[int, int]]:
    """Return whether a path is included and the winning pattern specificity.

    Parent path matches apply to descendant paths. If include and exclude rules
    tie on specificity, exclusion wins.
    """
    match = _best_filter_match(_split_metadata_path(path), glob_filter)
    if match is None:
        return False, (-1, -1)
    return match


def metadata_path_matches_filter(
    path: str, glob_filter: GlobFilter = EXCLUDE_ALL_GLOB_FILTER
) -> bool:
    included, _specificity = glob_filter_decision(path, glob_filter)
    return included


def _path_included_by_filter(path_segments: tuple[str, ...], glob_filter: GlobFilter) -> bool:
    match = _best_filter_match(path_segments, glob_filter)
    if match is None:
        return False
    included, _specificity = match
    return included


def _filter_metadata_value(
    value: Any,
    path_segments: tuple[str, ...],
    glob_filter: GlobFilter,
) -> Any | _MissingMetadata:
    included_here = _path_included_by_filter(path_segments, glob_filter)

    if isinstance(value, dict):
        value_dict = cast(dict[str, Any], value)
        filtered: dict[str, Any] = {}
        for key, child_value in value_dict.items():
            child_path = (*path_segments, str(key))
            filtered_value = _filter_metadata_value(
                child_value,
                child_path,
                glob_filter,
            )
            if not isinstance(filtered_value, _MissingMetadata):
                filtered[key] = filtered_value
        if filtered or included_here:
            return filtered
        return _MISSING_METADATA

    if included_here:
        return value
    return _MISSING_METADATA


def filter_metadata_by_paths(
    metadata: dict[str, Any], glob_filter: GlobFilter = EXCLUDE_ALL_GLOB_FILTER
) -> dict[str, Any]:
    filtered = _filter_metadata_value(metadata, (), glob_filter)
    if isinstance(filtered, _MissingMetadata) or not isinstance(filtered, dict):
        return {}
    return cast(dict[str, Any], filtered)


def dump_metadata(
    metadata: dict[str, Any], glob_filter: GlobFilter = EXCLUDE_ALL_GLOB_FILTER
) -> str | None:
    """
    Dump metadata to a JSON string.
    We used to use YAML to save tokens, but JSON makes it easier to find cited ranges on the frontend because the frontend uses JSON.
    """
    metadata = filter_metadata_by_paths(metadata, glob_filter)
    if not metadata:
        return None
    metadata_obj = to_jsonable_python(metadata)
    text = json.dumps(metadata_obj, indent=2)
    return text.strip()


def deep_merge_metadata(destination: dict[str, Any], source: dict[str, Any]) -> dict[str, Any]:
    """
    Recursively merge metadata dictionaries in-place.

    Nested dictionaries are merged to preserve existing keys while allowing
    later values to override earlier ones.
    """
    for key, value in source.items():
        dest_value = destination.get(key)
        if isinstance(dest_value, dict) and isinstance(value, dict):
            deep_merge_metadata(cast(dict[str, Any], dest_value), cast(dict[str, Any], value))
        else:
            destination[key] = value
    return destination
