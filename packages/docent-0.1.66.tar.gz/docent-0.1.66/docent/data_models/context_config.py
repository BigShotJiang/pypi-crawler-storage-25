from __future__ import annotations

import json
from typing import Annotated, Literal, TypeAlias

from pydantic import BaseModel, Field, TypeAdapter

from docent.data_models.metadata_util import (
    EXCLUDE_ALL_GLOB_FILTER,
    INCLUDE_ALL_GLOB_FILTER,
    GlobFilter,
    glob_filter_decision,
)


class BaseParameterContextConfig(BaseModel):
    pass


class AgentRunContextConfig(BaseParameterContextConfig):
    type: Literal["agent_run"] = "agent_run"

    # Agent run
    agent_run_metadata: GlobFilter = Field(default_factory=lambda: EXCLUDE_ALL_GLOB_FILTER)

    # Transcript group
    transcript_group_names: GlobFilter = Field(default_factory=lambda: INCLUDE_ALL_GLOB_FILTER)
    transcript_group_metadata: GlobFilter = Field(default_factory=lambda: EXCLUDE_ALL_GLOB_FILTER)

    # Transcript
    transcript_names: GlobFilter = Field(default_factory=lambda: INCLUDE_ALL_GLOB_FILTER)
    transcript_metadata: GlobFilter = Field(default_factory=lambda: EXCLUDE_ALL_GLOB_FILTER)
    message_metadata: GlobFilter = Field(default_factory=lambda: EXCLUDE_ALL_GLOB_FILTER)


class TranscriptContextConfig(BaseParameterContextConfig):
    type: Literal["transcript"] = "transcript"

    transcript_metadata: GlobFilter = Field(default_factory=lambda: EXCLUDE_ALL_GLOB_FILTER)
    message_metadata: GlobFilter = Field(default_factory=lambda: EXCLUDE_ALL_GLOB_FILTER)


class TranscriptSliceContextConfig(BaseParameterContextConfig):
    type: Literal["transcript_slice"] = "transcript_slice"

    transcript_metadata: GlobFilter = Field(default_factory=lambda: EXCLUDE_ALL_GLOB_FILTER)
    message_metadata: GlobFilter = Field(default_factory=lambda: EXCLUDE_ALL_GLOB_FILTER)


ParameterContextConfig: TypeAlias = Annotated[
    AgentRunContextConfig | TranscriptContextConfig | TranscriptSliceContextConfig,
    Field(discriminator="type"),
]

_ParameterContextConfigAdapter: TypeAdapter[ParameterContextConfig] = TypeAdapter(
    ParameterContextConfig
)


def context_config_cache_key(config: BaseParameterContextConfig | None) -> str:
    if config is None:
        return ""
    return json.dumps(
        config.model_dump(mode="json", exclude_defaults=True),
        sort_keys=True,
        separators=(",", ":"),
    )


def validate_parameter_context_config(value: object) -> ParameterContextConfig:
    return _ParameterContextConfigAdapter.validate_python(value)


def name_filter_decision(
    name: str | None, glob_filter: GlobFilter, fallback_id: str | None = None
) -> tuple[bool, tuple[int, int]]:
    """Return whether a named object matches a name filter.

    Names are the primary matching input for transcript and transcript group
    filters. If the name is unset, use the stable object ID when available so
    optional-name objects are still visible under the default include-all filter
    and can be explicitly targeted.
    """
    if name is not None:
        return glob_filter_decision(name, glob_filter)
    if fallback_id is not None:
        return glob_filter_decision(fallback_id, glob_filter)
    return False, (-1, -1)
