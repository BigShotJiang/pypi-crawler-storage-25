"""Data structures for reading-backed feedback elicitation."""

import json
from datetime import datetime
from hashlib import sha256
from typing import Any, Literal, TypeAlias

from pydantic import BaseModel, ConfigDict, Field, model_validator

from docent.data_models.citation import InlineCitation
from docent.judges.types import Rubric
from docent.judges.util.voting import OutputDistribution


def _stable_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True)


def _indent_lines(lines: list[str], indent: int) -> list[str]:
    prefix = " " * max(0, indent)
    return [f"{prefix}{line}" if line else "" for line in lines]


def _tag_block(tag: str, body_lines: list[str], indent: int) -> list[str]:
    lines = [f"<{tag}>"]
    if body_lines:
        lines.extend(_indent_lines(body_lines, indent))
    else:
        lines.extend(_indent_lines(["N/A"], indent))
    lines.append(f"</{tag}>")
    return lines


def _text_or_na(text: str | None) -> str:
    if text is None:
        return "N/A"
    stripped = text.strip()
    return stripped if stripped else "N/A"


def _text_lines_or_na(text: str | None) -> list[str]:
    return _text_or_na(text).splitlines()


def _render_citations_block(citations: list[InlineCitation], indent: int) -> list[str]:
    citation_payload = [citation.model_dump(mode="json") for citation in citations]
    citation_text = _stable_json(citation_payload) if citation_payload else "N/A"
    return _tag_block("Citations", [citation_text], indent)


# ============================================================================
# Persisted question and answer records
# These models represent the durable question/answer rows that get stored and
# later re-hydrated. They are distinct from the mutable per-session app state
# used to track generation progress.
# ============================================================================


class FeedbackQuestionGenerationTrace(BaseModel):
    """LLM generation trace for an automatically generated feedback question."""

    exhaustive_crux_brainstorming: str | None = None
    deduplication_reasoning: str | None = None


class FeedbackQuestionContent(BaseModel):
    """Structured question content shown to a human."""

    text: str
    citations: list[InlineCitation] = Field(default_factory=lambda: list[InlineCitation]())
    generation_trace: FeedbackQuestionGenerationTrace | None = None

    def to_str(self, indent: int = 0) -> str:
        body_lines = _text_lines_or_na(self.text)
        body_lines.extend(_render_citations_block(self.citations, indent))
        return "\n".join(_tag_block("Question", body_lines, indent))


class FeedbackContextSummaryContent(BaseModel):
    """LLM-generated context shown before a human labels a target."""

    text: str

    def to_str(self, indent: int = 0) -> str:
        body_lines = _text_lines_or_na(self.text)
        return "\n".join(_tag_block("Context Summary", body_lines, indent))


class FeedbackBasisDirection(BaseModel):
    """One semantic direction along which evidence can update a user."""

    model_config = ConfigDict(extra="forbid")

    output_schema_key: str
    basis_name: str
    extrema: list[str]

    @model_validator(mode="after")
    def validate_direction(self) -> "FeedbackBasisDirection":
        self.output_schema_key = self.output_schema_key.strip()
        self.basis_name = self.basis_name.strip()
        self.extrema = [extremum.strip() for extremum in self.extrema]
        if not self.output_schema_key:
            raise ValueError("FeedbackBasisDirection.output_schema_key must be non-empty")
        if not self.basis_name:
            raise ValueError("FeedbackBasisDirection.basis_name must be non-empty")
        if len(self.extrema) < 2:
            raise ValueError("FeedbackBasisDirection.extrema must contain at least two values")
        if any(not extremum for extremum in self.extrema):
            raise ValueError("FeedbackBasisDirection.extrema values must be non-empty")
        return self


def feedback_basis_direction_key(direction: FeedbackBasisDirection) -> str:
    return sha256(
        json.dumps(direction.model_dump(mode="json"), sort_keys=True).encode("utf-8")
    ).hexdigest()


class FeedbackBasis(BaseModel):
    """Session-level semantic basis for feedback updates."""

    directions: list[FeedbackBasisDirection] = Field(
        default_factory=lambda: list[FeedbackBasisDirection]()
    )

    @model_validator(mode="after")
    def validate_direction_keys(self) -> "FeedbackBasis":
        direction_keys = [feedback_basis_direction_key(direction) for direction in self.directions]
        if len(direction_keys) != len(set(direction_keys)):
            raise ValueError("FeedbackBasis directions must have unique derived keys")
        return self


FeedbackUpdateDirection = str
FeedbackUpdateStrength = Literal["weak", "moderate", "strong"]


class FeedbackQuestionAnswer(BaseModel):
    """Persisted answer for a specific question."""

    question_id: str
    basis_direction_key: str | None = None
    free_text_answer: str | None = None
    selected_direction: FeedbackUpdateDirection | Literal["no_update"] | None = None
    strength: FeedbackUpdateStrength | None = None
    explanation: str | None = None
    created_at: datetime
    updated_at: datetime

    @model_validator(mode="after")
    def validate_answer_shape(self) -> "FeedbackQuestionAnswer":
        self.question_id = self.question_id.strip()
        if not self.question_id:
            raise ValueError("FeedbackQuestionAnswer.question_id must be non-empty")

        if self.basis_direction_key is not None:
            self.basis_direction_key = self.basis_direction_key.strip()
            if not self.basis_direction_key:
                raise ValueError("basis_direction_key must be non-empty when provided")

        if self.free_text_answer is not None:
            self.free_text_answer = self.free_text_answer.strip()
        if self.selected_direction is not None:
            self.selected_direction = self.selected_direction.strip()
            if not self.selected_direction:
                raise ValueError("selected_direction must be non-empty when provided")

        if self.basis_direction_key is None:
            if not self.free_text_answer:
                raise ValueError("free_text_answer is required for high-level answers")
            if self.selected_direction is not None:
                raise ValueError("selected_direction must be null for high-level answers")
            if self.strength is not None:
                raise ValueError("strength must be null for high-level answers")
            return self

        if self.free_text_answer is not None:
            raise ValueError("free_text_answer must be null for crux-basis answers")
        if self.selected_direction is None:
            raise ValueError("selected_direction is required for crux-basis answers")
        if self.selected_direction == "no_update":
            if self.strength is not None:
                raise ValueError("strength must be null when selected_direction is no_update")
        elif self.strength is None:
            raise ValueError("strength is required unless selected_direction is no_update")
        return self

    def to_str(self, question: "FeedbackQuestion", indent: int = 0) -> str:
        lines = question.question.to_str(indent=indent).splitlines()
        if self.basis_direction_key is None:
            lines.append(f"User answer: {_text_or_na(self.free_text_answer)}")
        else:
            lines.append(f"Basis direction key: {self.basis_direction_key}")
            lines.append(f"Selected direction: {_text_or_na(self.selected_direction)}")
            lines.append(f"Strength: {_text_or_na(self.strength)}")
        lines.append(f"User explanation: {_text_or_na(self.explanation)}")
        return "\n".join(lines)


class FeedbackQuestion(BaseModel):
    """Persisted question record."""

    id: str
    feedback_session_id: str
    question: FeedbackQuestionContent
    created_at: datetime


# ============================================================================
# Mutable feedback-session application state
# These models capture orchestration state for round generation: sampled runs,
# groupings, requested label targets, and other transient workflow bookkeeping.
# They are not the user-authored answer/label payloads themselves.
# ============================================================================


FeedbackTargetObjectType = Literal[
    "agent_run",
    "transcript",
    "transcript_slice",
    "reading_result",
]
FeedbackTargetIdentity: TypeAlias = tuple[FeedbackTargetObjectType, str]


class FeedbackLabelTarget(BaseModel):
    """Canonical identity set for one requested feedback target."""

    target_identities: list[FeedbackTargetIdentity]
    target_key: str
    target_key_hash: str

    @model_validator(mode="after")
    def validate_target_identities(self) -> "FeedbackLabelTarget":
        normalized_identities: list[FeedbackTargetIdentity] = []
        seen: set[FeedbackTargetIdentity] = set()
        for identity in self.target_identities:
            if len(identity) != 2:
                raise ValueError("FeedbackLabelTarget.target_identities must be (type, id) pairs")
            object_type, object_id = identity
            stripped_id = object_id.strip()
            if not stripped_id:
                raise ValueError("FeedbackLabelTarget target IDs must be non-empty strings")
            normalized_identity: FeedbackTargetIdentity = (object_type, stripped_id)
            if normalized_identity in seen:
                raise ValueError(
                    "FeedbackLabelTarget.target_identities must not contain duplicates"
                )
            seen.add(normalized_identity)
            normalized_identities.append(normalized_identity)
        if not normalized_identities:
            raise ValueError("FeedbackLabelTarget.target_identities must contain at least one item")
        self.target_identities = normalized_identities
        self.target_key = self.target_key.strip()
        self.target_key_hash = self.target_key_hash.strip()
        if not self.target_key:
            raise ValueError("FeedbackLabelTarget.target_key must be non-empty")
        if not self.target_key_hash:
            raise ValueError("FeedbackLabelTarget.target_key_hash must be non-empty")
        return self

    def key(self) -> str:
        return self.target_key_hash


FeedbackSurveyOptionMode = Literal["auto", "always", "never"]


class FeedbackSurveyOptions(BaseModel):
    """Creation-time controls for the human feedback survey experience."""

    context_summary_mode: FeedbackSurveyOptionMode = "auto"
    crux_question_mode: FeedbackSurveyOptionMode = "auto"
    long_context_token_threshold: int = 10_000

    @model_validator(mode="after")
    def validate_survey_options(self) -> "FeedbackSurveyOptions":
        if self.long_context_token_threshold <= 0:
            raise ValueError("long_context_token_threshold must be > 0")
        return self


class FeedbackRoundGenerationParams(BaseModel):
    """Inputs used to generate one feedback round."""

    num_samples: int
    num_high_level_questions: int
    num_targets_per_high_level_question: int
    max_cruxes_per_target: int
    seed: int


class FeedbackRoundInvocationEstimate(BaseModel):
    """Stored p_u metadata for one sampled reading invocation within a round."""

    target_key_hash: str
    target_key: str
    target_identities: list[FeedbackTargetIdentity] = Field(
        default_factory=lambda: list[FeedbackTargetIdentity]()
    )
    arguments_dict: dict[str, Any] = Field(default_factory=dict)
    materialized_prompt: str
    context_summary: FeedbackContextSummaryContent | None = None
    user_distribution: OutputDistribution | None = None
    reasoning: str | None = None
    reasoning_citations: list[InlineCitation] = Field(
        default_factory=lambda: list[InlineCitation]()
    )


class FeedbackQuestionGroupState(BaseModel):
    """Application-state record tying questions to representative invocations."""

    high_level_question_id: str
    representative_target_key_hashes: list[str] = Field(default_factory=lambda: list[str]())
    run_specific_question_ids_by_target_key_hash: dict[str, list[str]] = Field(
        default_factory=lambda: dict[str, list[str]]()
    )


class FeedbackRoundState(BaseModel):
    """Application-state record for one generated round."""

    round_index: int
    generation_params: FeedbackRoundGenerationParams
    sampled_target_key_hashes: list[str] = Field(default_factory=lambda: list[str]())
    invocation_estimates: list[FeedbackRoundInvocationEstimate] = Field(
        default_factory=lambda: list[FeedbackRoundInvocationEstimate]()
    )
    question_groups: list[FeedbackQuestionGroupState] = Field(
        default_factory=lambda: list[FeedbackQuestionGroupState]()
    )
    created_at: datetime = Field(default_factory=datetime.now)


class FeedbackSessionAppState(BaseModel):
    """Mutable application state for a feedback session."""

    version: int = 3
    feedback_basis: FeedbackBasis | None = None
    current_round: int = 0
    requested_label_targets: list[FeedbackLabelTarget] = Field(
        default_factory=lambda: list[FeedbackLabelTarget]()
    )
    rounds: list[FeedbackRoundState] = Field(default_factory=lambda: list[FeedbackRoundState]())

    def get_round(self, round_index: int) -> FeedbackRoundState | None:
        for round_state in self.rounds:
            if round_state.round_index == round_index:
                return round_state
        return None

    def has_requested_label_target(self, target: FeedbackLabelTarget) -> bool:
        target_key = target.key()
        return any(
            existing_target.key() == target_key for existing_target in self.requested_label_targets
        )


# ============================================================================
# Persisted session record
# This is the durable feedback-session row that stores rubric metadata plus the
# mutable app-state payload above.
# ============================================================================


class FeedbackSession(BaseModel):
    """Feedback-session metadata persisted on the server."""

    id: str
    reading_preset_id: str
    reading_preset_version: int
    dql_query: str
    survey_options: FeedbackSurveyOptions = Field(default_factory=FeedbackSurveyOptions)
    app_state: FeedbackSessionAppState = Field(default_factory=FeedbackSessionAppState)
    created_at: datetime


# ============================================================================
# Hydrated API response models
# These are read-oriented payloads assembled from persisted records plus app
# state so the client can render a round or poll job state.
# ============================================================================


class FeedbackQuestionWithAnswer(BaseModel):
    """Hydrated question payload returned by the API."""

    question: FeedbackQuestion
    answer: FeedbackQuestionAnswer | None = None
    crux_basis_answers: list[FeedbackQuestionAnswer] = Field(
        default_factory=lambda: list[FeedbackQuestionAnswer]()
    )


class FeedbackRepresentativeInvocationPrompt(BaseModel):
    """Hydrated representative-invocation payload returned by the feedback API."""

    target_key_hash: str
    target_key: str
    target_identities: list[FeedbackTargetIdentity] = Field(
        default_factory=lambda: list[FeedbackTargetIdentity]()
    )
    arguments_dict: dict[str, Any] = Field(default_factory=dict)
    materialized_prompt: str
    context_summary: FeedbackContextSummaryContent | None = None
    user_distribution: OutputDistribution | None = None
    user_distribution_reasoning: str | None = None
    user_distribution_reasoning_citations: list[InlineCitation] = Field(
        default_factory=lambda: list[InlineCitation]()
    )
    questions: list["FeedbackQuestionWithAnswer"] = Field(
        default_factory=lambda: list[FeedbackQuestionWithAnswer]()
    )
    label_target: FeedbackLabelTarget


class FeedbackQuestionGroup(BaseModel):
    """Hydrated high-level question plus its representative invocations."""

    high_level_question: FeedbackQuestionWithAnswer
    representative_invocations: list[FeedbackRepresentativeInvocationPrompt] = Field(
        default_factory=lambda: list[FeedbackRepresentativeInvocationPrompt]()
    )


class FeedbackRound(BaseModel):
    """Round-scoped feedback payload returned by the REST API."""

    feedback_session_id: str
    round_index: int
    output_schema: dict[str, Any]
    feedback_basis: FeedbackBasis
    groups: list[FeedbackQuestionGroup] = Field(
        default_factory=lambda: list[FeedbackQuestionGroup]()
    )


FeedbackJobStatus = Literal["pending", "running", "cancelling", "canceled", "completed"]


class StartFeedbackRoundJobResponse(BaseModel):
    """Response for enqueueing or reusing a feedback round-generation job."""

    job_id: str


class FeedbackRoundJobStateResponse(BaseModel):
    """Current feedback round job status and the active round payload."""

    job_id: str | None
    job_status: FeedbackJobStatus | None
    current_round: int
    round: FeedbackRound | None = None


# ============================================================================
# Stored user feedback payloads
# These models represent the actual persisted labels derived from the
# reading-backed feedback workflow.
# ============================================================================


class FeedbackLabel(BaseModel):
    """Persisted label row stored for a canonical feedback target."""

    id: str
    feedback_session_id: str
    target_key: str
    target_key_hash: str
    label_value: dict[str, Any]
    explanation: str | None = None
    created_at: datetime
    updated_at: datetime


# ============================================================================
# Rubric optimization job/result models
# These are derived evaluation payloads returned by optimization workflows,
# rather than raw user answers or mutable session state.
# ============================================================================


class RubricOptimizationMetrics(BaseModel):
    """Aggregate rubric performance on labeled feedback contexts."""

    total_labeled: int
    correct: int
    incorrect: int
    failure: int
    accuracy: float | None


class RubricOptimizationCandidate(BaseModel):
    """One rubric candidate returned by the optimization job."""

    candidate_index: int
    generation: int
    parent_candidate_index: int | None
    rubric: Rubric
    train_metrics: RubricOptimizationMetrics
    test_metrics: RubricOptimizationMetrics


class RubricOptimizationResult(BaseModel):
    """Compact completed-job payload for feedback rubric optimization."""

    feedback_session_id: str
    base_rubric: Rubric
    baseline_train_metrics: RubricOptimizationMetrics
    baseline_test_metrics: RubricOptimizationMetrics
    raw_context_count: int
    filtered_context_count: int
    contexts_with_labels: int
    contexts_with_answered_qa: int
    train_labeled_count: int
    train_qa_only_count: int
    test_labeled_count: int
    rubrics: list[RubricOptimizationCandidate] = Field(
        default_factory=lambda: list[RubricOptimizationCandidate]()
    )


class StartFeedbackRubricOptimizationJobResponse(BaseModel):
    """Response for enqueueing or reusing a feedback rubric optimization job."""

    job_id: str


class FeedbackRubricOptimizationJobStateResponse(BaseModel):
    """Current feedback rubric optimization job status and result payload."""

    job_id: str | None
    job_status: FeedbackJobStatus | None
    result: RubricOptimizationResult | None = None


# ============================================================================
