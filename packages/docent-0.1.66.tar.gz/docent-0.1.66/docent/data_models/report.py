from datetime import datetime
from uuid import uuid4

from pydantic import BaseModel, Field


class Report(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid4()))
    collection_id: str
    source_reading_plan_id: str
    title: str
    markdown: str
    revision: int = 1
    created_by: str
    created_at: datetime
    updated_at: datetime
