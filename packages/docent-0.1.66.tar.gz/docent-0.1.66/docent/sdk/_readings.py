"""Reading presets, plans, lazy readings, flush, and plan streaming."""

from __future__ import annotations

import atexit
import json
import sys
import time
import webbrowser
from collections.abc import Iterator
from pathlib import Path
from textwrap import dedent
from typing import Any, Literal, cast

import requests
from pydantic import TypeAdapter, ValidationError

from docent._llm_util.providers.preference_types import ModelOption
from docent.data_models.context_config import ParameterContextConfig
from docent.data_models.reading import (
    DEFAULT_READING_MAX_NEW_TOKENS,
    DqlOnlyStepSubmission,
    EndStepGroupSubmission,
    PlanJobCancelledEvent,
    PlanJobCompletedEvent,
    PlanJobFailedEvent,
    PlanSnapshotEvent,
    PlanStepCompletedEvent,
    PlanStepFailedEvent,
    PlanStepStartedEvent,
    PlanStepSubmission,
    PlanStepSubmissionStatus,
    PlanStreamEvent,
    PlanSubmissionRequest,
    PlanSubmissionResponse,
    PresetReadingStepSubmission,
    ReadingCacheMode,
    ReadingStepSubmission,
    ScriptedRequest,
    StepGroupSubmission,
)


class _ReadingPlanFailure(RuntimeError):
    """Fatal reading-plan failure that should stop SDK scripts."""


_plan_stream_event_adapter: TypeAdapter[PlanStreamEvent] = TypeAdapter(PlanStreamEvent)
from docent.sdk._base import DocentBase
from docent.sdk.llm_context import ContextItemRef, Prompt
from docent.sdk.reading import (
    ColumnRef,
    PendingEntry,
    PromptSegment,
    QueryResult,
    Reading,
    ReadingResult,
    StepGroupContext,
    _PendingDqlOnlyStep,  # pyright: ignore[reportPrivateUsage]
    _PendingEndStepGroup,  # pyright: ignore[reportPrivateUsage]
    _PendingPresetReading,  # pyright: ignore[reportPrivateUsage]
    _PendingReading,  # pyright: ignore[reportPrivateUsage]
    _PendingStepGroup,  # pyright: ignore[reportPrivateUsage]
)


class DocentReadingsMixin(DocentBase):
    """High-level reading plan API."""

    # ────────────────────────── Reading Presets ────────────────────────────────

    def _to_jsonable_payload(self, value: Any) -> Any:
        if hasattr(value, "model_dump"):
            return value.model_dump(mode="json")
        return value

    def list_reading_presets(
        self,
        collection_id: str,
        *,
        owned_only: bool = True,
    ) -> list[dict[str, Any]]:
        """List reading presets in a collection.

        Args:
            collection_id: Collection ID.
            owned_only: When True, return only presets created by the current user.

        Returns:
            List of preset dicts with id, collection_id, name, created_at,
            updated_at, and versions.
        """
        url = f"{self._api_url}/reading/{collection_id}/presets"
        response = self._session.get(url, params={"owned_only": "true" if owned_only else "false"})
        self._handle_response_errors(response)
        return cast(list[dict[str, Any]], response.json())

    def get_reading_preset_config(self, collection_id: str, preset_id: str) -> dict[str, Any]:
        """Get the current reading configuration for a preset.

        Returns:
            Dict with reading_config, dql_query, reading_id, and result_count.
        """
        url = f"{self._api_url}/reading/{collection_id}/preset/{preset_id}/resolve-current-reading"
        response = self._session.get(url)
        self._handle_response_errors(response)
        return cast(dict[str, Any], response.json())

    def create_reading_preset(
        self,
        collection_id: str,
        name: str,
        reading_config: Any,
    ) -> dict[str, Any]:
        """Create a reading preset and return its server response."""
        url = f"{self._api_url}/reading/{collection_id}/preset"
        payload = {
            "name": name,
            "reading_config": self._to_jsonable_payload(reading_config),
        }
        response = self._session.post(url, json=payload)
        self._handle_response_errors(response)
        return cast(dict[str, Any], response.json())

    def save_reading_preset_version(
        self,
        collection_id: str,
        preset_id: str,
        reading_config: Any,
    ) -> dict[str, Any]:
        """Create a new version for an existing reading preset."""
        url = f"{self._api_url}/reading/{collection_id}/preset/{preset_id}/save-version"
        payload = {"reading_config": self._to_jsonable_payload(reading_config)}
        response = self._session.post(url, json=payload)
        self._handle_response_errors(response)
        return cast(dict[str, Any], response.json())

    def update_reading_preset_name(
        self,
        collection_id: str,
        preset_id: str,
        name: str,
    ) -> dict[str, Any]:
        """Rename a reading preset."""
        url = f"{self._api_url}/reading/{collection_id}/preset/{preset_id}/name"
        response = self._session.put(url, json={"name": name})
        self._handle_response_errors(response)
        return cast(dict[str, Any], response.json())

    def get_reading_models(self) -> list[dict[str, Any]]:
        """Get the available models for readings.

        Returns:
            List of model dicts with provider, model_name, reasoning_effort,
            context_window, and uses_byok.
        """
        url = f"{self._api_url}/reading/reading-models"
        response = self._session.get(url)
        self._handle_response_errors(response)
        return cast(list[dict[str, Any]], response.json())

    # ────────────────────── Reading Plan Inspection ─────────────────────

    def list_reading_plans(
        self,
        collection_id: str,
        *,
        name: str | None = None,
    ) -> list[dict[str, Any]]:
        """List reading plans in a collection, optionally filtered by name.

        Returns:
            List of plan dicts with plan_id, name, created_by, created_at, updated_at,
            and step_count.
        """
        url = f"{self._api_url}/reading/{collection_id}/reading-plans"
        params: dict[str, str] = {}
        if name is not None:
            params["name"] = name
        response = self._session.get(url, params=params)
        self._handle_response_errors(response)
        return cast(list[dict[str, Any]], response.json())

    def get_reading_plan(self, collection_id: str, plan_id: str) -> dict[str, Any]:
        """Get the full state of a reading plan including steps and their statuses.

        Returns:
            Dict with plan_id, collection_id, name, created_at, updated_at,
            steps (list of step dicts with derived_status), and active_job_id.
        """
        return self._get_reading_plan_state(collection_id, plan_id)

    def get_reading_results(
        self,
        collection_id: str,
        reading_id: str,
        *,
        limit: int | None = None,
        include_output: bool = True,
    ) -> list[dict[str, Any]]:
        """Get results for a specific reading.

        Args:
            collection_id: Collection ID.
            reading_id: Reading ID.
            limit: Optional maximum number of results to return.
            include_output: When False, omit output and error fields from the
                response. Useful for counting or listing results without
                fetching large payloads.

        Returns:
            List of result dicts with id, status, output, error, arguments_dict, etc.
        """
        url = f"{self._api_url}/reading/{collection_id}/reading/{reading_id}/results"
        params: dict[str, Any] = {}
        if limit is not None:
            params["limit"] = limit
        if not include_output:
            params["include_output"] = False
        response = self._session.get(url, params=params)
        self._handle_response_errors(response)
        data: Any = response.json()
        return cast(
            list[dict[str, Any]],
            data if isinstance(data, list) else data.get("results", []),
        )

    # ────────────────────────── Reading Plans ──────────────────────────

    def _next_alias(self) -> str:
        alias = str(self._alias_counter)
        self._alias_counter += 1
        return alias

    def _enqueue_pending(self, entry: PendingEntry) -> None:
        self._pending.append(entry)

    def _register_atexit(self) -> None:
        if self._atexit_registered:
            return
        self._atexit_registered = True

        _original_excepthook = sys.excepthook

        def _on_unhandled_exception(
            exc_type: type[BaseException],
            exc_value: BaseException,
            exc_tb: Any,
        ) -> None:
            self._crash_detected = True
            _original_excepthook(exc_type, exc_value, exc_tb)

        sys.excepthook = _on_unhandled_exception

        def _atexit_flush() -> None:
            if self._crash_detected:
                return
            if self._pending and self._auto_flush:
                self._logger.info(
                    "Auto-flushing pending readings via atexit. "
                    "Set client.auto_flush = False to disable."
                )
                try:
                    self.flush(open_in_browser=True)
                except _ReadingPlanFailure as exc:
                    self._logger.error("%s", exc)
                    raise SystemExit(1) from exc
                except Exception:
                    self._logger.exception("Auto-flush failed")

        atexit.register(_atexit_flush)

    def _register_notebook_hook(self) -> None:
        if self._notebook_hook_registered:
            return
        try:
            ip = get_ipython()  # type: ignore[name-defined]
        except NameError:
            return
        if ip is None:
            return
        self._is_notebook = True
        self._notebook_hook_registered = True

        def _cell_post_run(*args: Any, **kwargs: Any) -> None:
            if self._pending and self._auto_flush:
                open_browser = self._plan_id is None
                try:
                    cast(Any, self).flush(open_in_browser=open_browser)
                except _ReadingPlanFailure as exc:
                    self._logger.error("%s", exc)
                    raise
                except Exception:
                    self._logger.exception("Notebook auto-flush failed")

        ip.events.register("post_run_cell", _cell_post_run)  # type: ignore[reportUnknownMemberType]

    def _detect_source_script(self) -> str | None:
        """Best-effort detection of the calling script or notebook name."""
        if self._is_notebook:
            try:
                ip: Any = get_ipython()  # type: ignore[name-defined]
                if ip is not None:
                    kernel = getattr(ip, "kernel", None)  # pyright: ignore[reportUnknownArgumentType]
                    if kernel is not None:
                        session_name: str | None = getattr(kernel, "_session_name", None)  # pyright: ignore[reportUnknownArgumentType]
                        if session_name is None:
                            session_name = getattr(kernel, "session_name", None)  # pyright: ignore[reportUnknownArgumentType]
                        if session_name:
                            return Path(session_name).name
            except NameError:
                pass
            return None

        import __main__

        main_file = getattr(__main__, "__file__", None)
        if main_file:
            return Path(main_file).name
        return None

    def query(
        self,
        collection_id: str,
        dql: str,
        *,
        name: str | None = None,
    ) -> QueryResult:
        """Create a lazy DQL query handle backed by a plan step.

        A corresponding ``dql_only`` step is appended to the pending plan
        immediately so the query is visible in the plan UI, even if the
        QueryResult is never consumed by a reading.

        Args:
            collection_id: Collection ID.
            dql: DQL query string.
            name: Optional display name for the dql-only step.

        Returns:
            QueryResult handle. Access attributes to get ColumnRef objects.
        """
        alias = self._next_alias()
        resolved_dql = dedent(dql).strip()
        self._enqueue_pending(
            _PendingDqlOnlyStep(
                alias=alias,
                collection_id=collection_id,
                dql_query=resolved_dql,
                name=name,
            )
        )
        self._register_atexit()
        return QueryResult(collection_id, resolved_dql, plan_alias=alias)

    def read(
        self,
        *,
        prompt_template: list[PromptSegment] | None = None,
        prompts_list: list[list[str | ContextItemRef]] | None = None,
        model: str,
        output_schema: dict[str, Any] | None = None,
        collection_id: str | None = None,
        name: str | None = None,
        context_configs: dict[str, ParameterContextConfig] | None = None,
        reasoning_effort: Literal["minimal", "low", "medium", "high"] | None = None,
        max_new_tokens: int = DEFAULT_READING_MAX_NEW_TOKENS,
        user_metadata: dict[str, Any] | None = None,
        cache_mode: ReadingCacheMode = "reading",
    ) -> Reading:
        """Register a lazy reading.

        Use prompt_template= for the template path (with ColumnRefs from a QueryResult).
        Use prompts_list= for the scripted path (explicit per-request prompts).
        They are mutually exclusive.

        Args:
            prompt_template: Template prompt segments (strings, ColumnRefs, ContextItemRefs).
            prompts_list: Scripted requests, each a list of prompt segments.
            model: Model string in "provider/model_name" format.
            output_schema: JSON schema for the LLM output.
            name: Optional display name for this reading step.
            context_configs: Optional context configuration dict keyed by prompt parameter name.
            reasoning_effort: Optional reasoning effort hint.
            max_new_tokens: Maximum number of new tokens to generate per result. Defaults to 8192.
            user_metadata: Optional metadata stored on the reading row and used in reading deduplication.

        Returns:
            A lazy Reading handle.
        """
        if prompt_template is not None and prompts_list is not None:
            raise ValueError("prompt_template and prompts_list are mutually exclusive")
        if prompt_template is None and prompts_list is None:
            raise ValueError("Must provide either prompt_template or prompts_list")

        if self._is_notebook and name is None:
            self._logger.warning(
                "Reading submitted without a name. In notebook mode, named steps are "
                "required for cell re-runs to update existing steps instead of duplicating."
            )

        model_json = self._parse_model_option(model=model, reasoning_effort=reasoning_effort)
        assert model_json is not None

        alias = self._next_alias()
        handle = Reading(client=self, alias=alias)

        if prompt_template is not None:
            template_segments, dql_step_alias, ctx_configs, inferred_cid = (
                self._serialize_template_prompt(prompt_template, context_configs)
            )
            resolved_cid = collection_id or inferred_cid
            pending = _PendingReading(
                alias=alias,
                handle=handle,
                collection_id=resolved_cid,
                name=name,
                model_json=model_json,
                output_schema=output_schema,
                max_new_tokens=max_new_tokens,
                user_metadata=user_metadata,
                cache_mode=cache_mode,
                prompt_template_segments=template_segments,
                context_configs=ctx_configs,
                dql_query=None,
                dql_step_alias=dql_step_alias,
                requests=None,
            )
        else:
            assert prompts_list is not None
            scripted_reqs = self._serialize_scripted_requests(prompts_list)
            pending = _PendingReading(
                alias=alias,
                handle=handle,
                collection_id=collection_id,
                name=name,
                model_json=model_json,
                output_schema=output_schema,
                max_new_tokens=max_new_tokens,
                user_metadata=user_metadata,
                cache_mode=cache_mode,
                prompt_template_segments=None,
                context_configs=None,
                dql_query=None,
                dql_step_alias=None,
                requests=scripted_reqs,
            )

        self._enqueue_pending(pending)
        self._register_atexit()
        return handle

    def _parse_model_option(
        self,
        *,
        model: str | None,
        reasoning_effort: Literal["minimal", "low", "medium", "high"] | None,
    ) -> ModelOption | None:
        if model is None:
            if reasoning_effort is not None:
                raise ValueError("reasoning_effort requires model to also be set")
            return None

        if "/" not in model:
            raise ValueError("model must be in 'provider/model_name' format")
        provider, model_name = model.split("/", 1)
        return ModelOption(
            provider=provider,
            model_name=model_name,
            reasoning_effort=reasoning_effort,
        )

    def _serialize_template_prompt(
        self,
        prompt: list[PromptSegment],
        context_configs: dict[str, ParameterContextConfig] | None,
    ) -> tuple[list[Any], str | None, dict[str, ParameterContextConfig] | None, str | None]:
        """Convert prompt segments into template format.

        Returns (segments_json, dql_step_alias, context_configs_dict, collection_id).
        The reading is bound to the single QueryResult used in the prompt via
        its plan alias; if none is present the returned alias is ``None``.
        """
        segments: list[Any] = []
        seen_qr: QueryResult | None = None
        inferred_collection_id: str | None = None

        for seg in prompt:
            if isinstance(seg, str):
                segments.append(dedent(seg))
            elif isinstance(seg, ColumnRef):
                qr = seg.query_result
                if seen_qr is None:
                    seen_qr = qr
                    inferred_collection_id = qr.collection_id
                elif qr is not seen_qr:
                    raise ValueError(
                        "All ColumnRefs in a prompt must reference the same QueryResult"
                    )

                param_name = seg.column_name
                param_type = seg.type_annotation or "unknown"
                # Unknown type means "defer to server-side inference"; false here does not
                # mean the caller explicitly declared a scalar placeholder.
                segments.append(
                    {
                        "param_name": param_name,
                        "param_type": param_type,
                        "is_list": seg.is_list_annotation if seg.type_annotation else False,
                    }
                )
            else:
                segments.append(seg.model_dump(mode="json"))

        for i, s in enumerate(segments):
            if isinstance(s, str):
                segments[i] = s.lstrip()
                break
        for i in range(len(segments) - 1, -1, -1):
            if isinstance(segments[i], str):
                segments[i] = segments[i].rstrip()
                break

        dql_step_alias = seen_qr.plan_alias if seen_qr is not None else None
        return (
            segments,
            dql_step_alias,
            context_configs,
            inferred_collection_id,
        )

    def _serialize_scripted_requests(
        self,
        prompts_list: list[list[str | ContextItemRef]],
    ) -> list[dict[str, Any]]:
        """Convert scripted request lists into serializable format."""
        result: list[dict[str, Any]] = []
        for req_segments in prompts_list:
            arguments: dict[str, Any] = {}
            for seg in req_segments:
                if not isinstance(seg, str):
                    label = getattr(seg, "_ref_label", None)
                    if label:
                        ref_dict = seg.model_dump(mode="json")
                        arguments[label] = ref_dict.get("id", "")

            processed: list[str | ContextItemRef] = [
                dedent(seg) if isinstance(seg, str) else seg for seg in req_segments
            ]
            spec_dict, segments = Prompt(processed).to_storage()

            for i, s in enumerate(segments):
                if isinstance(s, str):
                    segments[i] = s.lstrip()
                    break
            for i in range(len(segments) - 1, -1, -1):
                s = segments[i]
                if isinstance(s, str):
                    segments[i] = s.rstrip()
                    break

            result.append(
                {
                    "prompt_segments": segments,
                    "arguments_dict": arguments,
                    "llm_context_spec": spec_dict,
                }
            )
        return result

    def show_query_result(self, query_result: QueryResult, *, name: str | None = None) -> None:
        """Deprecated: `client.query(...)` now auto-registers a dql-only step.

        Retained as a no-op for backwards compatibility. If ``name`` is
        provided and the query's dql-only step has no name yet, we update
        it so the preview still gets a human-readable label.
        """
        import warnings

        warnings.warn(
            "show_query_result() is deprecated; client.query() already registers a "
            "dql-only plan step. Pass name= to client.query() to label it.",
            DeprecationWarning,
            stacklevel=2,
        )
        if name is None or query_result.plan_alias is None:
            return
        for p in self._pending:
            if isinstance(p, _PendingDqlOnlyStep) and p.alias == query_result.plan_alias:
                if p.name is None:
                    p.name = name
                break

    def read_with_preset(
        self,
        preset_id: str | None = None,
        query_result: QueryResult | None = None,
        *,
        preset_name: str | None = None,
        name: str | None = None,
        prompt_template: list[PromptSegment] | None = None,
        model: str | None = None,
        output_schema: dict[str, Any] | None = None,
        context_configs: dict[str, ParameterContextConfig] | None = None,
        reasoning_effort: Literal["minimal", "low", "medium", "high"] | None = None,
        max_new_tokens: int | None = None,
        source_reading_preset_version: int | None = None,
        user_metadata: dict[str, Any] | None = None,
        cache_mode: ReadingCacheMode = "reading",
    ) -> Reading:
        """Register a reading step backed by a preset.

        The server resolves the preset's latest config at submission time.

        Args:
            preset_id: The reading preset ID to use.
            query_result: QueryResult supplying the preset's input rows.
            preset_name: Exact preset name to resolve within the collection.
            name: Optional display name for the step.
            prompt_template: Optional runtime prompt segments that fill an unset preset field.
            model: Optional runtime model in "provider/model_name" format.
            output_schema: Optional runtime JSON schema that fills an unset preset field.
            context_configs: Optional runtime context configuration dict keyed by parameter name.
            reasoning_effort: Optional runtime reasoning effort hint.
            max_new_tokens: Optional runtime maximum number of new tokens to generate per result.
                When omitted, the preset can supply the pinned value.
            source_reading_preset_version: Optional preset version to use.
                When omitted, the server resolves the latest version.
            user_metadata: Optional metadata stored on the reading row and used in reading deduplication.

        Returns:
            A Reading handle that will be populated with results after flush().
        """
        if query_result is None:
            raise ValueError("read_with_preset requires a QueryResult")
        if preset_id is None and preset_name is None:
            raise ValueError("read_with_preset requires preset_id or preset_name")
        if preset_id is not None and preset_name is not None:
            raise ValueError("read_with_preset accepts only one of preset_id or preset_name")

        model_json = self._parse_model_option(model=model, reasoning_effort=reasoning_effort)
        (
            runtime_prompt_template_segments,
            runtime_context_configs,
        ) = self._serialize_preset_runtime_overrides(
            query_result=query_result,
            prompt_template=prompt_template,
            context_configs=context_configs,
        )

        alias = self._next_alias()
        collection_id = query_result.collection_id
        dql_step_alias = query_result.plan_alias
        handle = Reading(client=self, alias=alias)
        self._enqueue_pending(
            _PendingPresetReading(
                alias=alias,
                handle=handle,
                collection_id=collection_id,
                name=name,
                source_reading_preset_id=preset_id,
                source_reading_preset_name=preset_name,
                source_reading_preset_version=source_reading_preset_version,
                user_metadata=user_metadata,
                model_json=model_json,
                output_schema=output_schema,
                max_new_tokens=max_new_tokens,
                prompt_template_segments=runtime_prompt_template_segments,
                context_configs=runtime_context_configs,
                dql_query=None,
                dql_step_alias=dql_step_alias,
                cache_mode=cache_mode,
            )
        )
        self._register_atexit()
        return handle

    def _serialize_preset_runtime_overrides(
        self,
        *,
        query_result: QueryResult,
        prompt_template: list[PromptSegment] | None,
        context_configs: dict[str, ParameterContextConfig] | None,
    ) -> tuple[list[Any] | None, dict[str, ParameterContextConfig] | None]:
        if prompt_template is None:
            return None, context_configs

        (
            prompt_template_segments,
            template_dql_step_alias,
            serialized_context_configs,
            inferred_collection_id,
        ) = self._serialize_template_prompt(prompt_template, context_configs)
        if (
            inferred_collection_id is not None
            and inferred_collection_id != query_result.collection_id
        ):
            raise ValueError(
                "prompt_template ColumnRefs must reference the same collection as query_result"
            )
        if (
            template_dql_step_alias is not None
            and template_dql_step_alias != query_result.plan_alias
        ):
            raise ValueError(
                "prompt_template ColumnRefs must reference the same QueryResult passed to read_with_preset"
            )
        return prompt_template_segments, serialized_context_configs

    def step_group(self, label: str) -> StepGroupContext:
        """Open a labeled step group in the pending step list.

        Can be used standalone (group applies to everything that follows)
        or as a context manager to auto-close the group scope on exit::

            with plan.step_group("Section A"):
                plan.read(...)
            plan.read(...)  # back to top-level

        Args:
            label: The group label.
        """
        alias = self._next_alias()
        self._pending.append(_PendingStepGroup(alias=alias, label=label))
        return StepGroupContext(self._pending, alias)

    def flush(
        self,
        *,
        open_in_browser: bool = True,
        auto_approve: bool = False,
    ) -> PlanSubmissionResponse:
        """Submit all pending readings to the server.

        After submission, previews cached DQL and reading results to stdout.
        If any reading steps are not cached, blocks until all steps from this
        flush are settled (completed or failed), logging previews as each step
        finishes. When auto-approval is enabled, the SDK approves newly
        submitted reading steps before waiting.

        Args:
            open_in_browser: Whether to open the session page in the browser.
            auto_approve: Whether to automatically approve newly submitted
                reading steps for this flush.

        Returns:
            Typed submission response with plan_id and entry statuses.
        """
        if not self._pending:
            return PlanSubmissionResponse(plan_id=self._plan_id or "", entry_statuses=[])

        entries: list[PlanStepSubmission] = []
        reading_handles: dict[str, Reading] = {}
        pending_names: dict[str, str | None] = {}

        for p in self._pending:
            if isinstance(p, _PendingReading):
                reading_handles[p.alias] = p.handle
                pending_names[p.alias] = p.name
                entry = ReadingStepSubmission(
                    alias=p.alias,
                    name=p.name,
                    model=p.model_json,
                    output_schema=p.output_schema,
                    max_new_tokens=p.max_new_tokens,
                    user_metadata=p.user_metadata,
                    cache_mode=p.cache_mode,
                    prompt_template_segments=p.prompt_template_segments,
                    context_configs=p.context_configs,
                    dql_query=p.dql_query,
                    dql_step_alias=p.dql_step_alias,
                    requests=[ScriptedRequest(**r) for r in p.requests] if p.requests else None,
                )
                entries.append(entry)
            elif isinstance(p, _PendingPresetReading):
                reading_handles[p.alias] = p.handle
                pending_names[p.alias] = p.name
                entries.append(
                    PresetReadingStepSubmission(
                        alias=p.alias,
                        name=p.name,
                        source_reading_preset_id=p.source_reading_preset_id,
                        source_reading_preset_name=p.source_reading_preset_name,
                        source_reading_preset_version=p.source_reading_preset_version,
                        user_metadata=p.user_metadata,
                        model=p.model_json,
                        output_schema=p.output_schema,
                        max_new_tokens=p.max_new_tokens,
                        prompt_template_segments=p.prompt_template_segments,
                        context_configs=p.context_configs,
                        dql_query=p.dql_query,
                        dql_step_alias=p.dql_step_alias,
                        cache_mode=p.cache_mode,
                    )
                )
            elif isinstance(p, _PendingDqlOnlyStep):
                pending_names[p.alias] = p.name
                entries.append(
                    DqlOnlyStepSubmission(
                        alias=p.alias,
                        name=p.name,
                        dql_query=p.dql_query,
                    )
                )
            elif isinstance(p, _PendingStepGroup):
                entries.append(
                    StepGroupSubmission(
                        alias=p.alias,
                        label=p.label,
                    )
                )
            else:
                assert isinstance(p, _PendingEndStepGroup)
                entries.append(
                    EndStepGroupSubmission(
                        alias=p.alias,
                    )
                )

        plan_name = self._plan_name if not self._plan_name_sent else None
        source_script = (
            self._detect_source_script()
            if not self._plan_name_sent and not self._plan_name
            else None
        )

        request_body = PlanSubmissionRequest(
            plan_id=self._plan_id,
            plan_name=plan_name,
            source_script=source_script,
            entries=entries,
        )
        is_first_flush_for_plan = self._plan_id is None

        collection_id = self._resolve_flush_collection_id()

        url = f"{self._api_url}/reading/{collection_id}/reading-plan/submit"
        response = self._session.post(url, json=request_body.model_dump(mode="json"))
        self._handle_response_errors(response)

        submit_response = PlanSubmissionResponse.model_validate(response.json())
        self._plan_id = submit_response.plan_id
        self._flushed_collection_id = collection_id
        self._plan_name_sent = True

        self._pending.clear()

        for es in submit_response.entry_statuses:
            if es.alias in reading_handles and es.reading_id:
                reading_handles[es.alias]._set_reading_id(es.reading_id)  # pyright: ignore[reportPrivateUsage]

        if auto_approve:
            self._auto_approve_plan_steps(
                collection_id=collection_id,
                plan_id=submit_response.plan_id,
                submit_response=submit_response,
            )

        should_auto_open = (
            open_in_browser and is_first_flush_for_plan and not submit_response.has_active_listeners
        )
        if should_auto_open:
            plan_url = (
                f"{self._frontend_url}/dashboard/{collection_id}/reading-plan/{self._plan_id}"
            )
            self._logger.info("Opening reading plan in browser: %s", plan_url)
            webbrowser.open(plan_url)

        self._preview_and_wait(
            submit_response=submit_response,
            collection_id=collection_id,
            reading_handles=reading_handles,
            pending_names=pending_names,
        )

        return submit_response

    def _auto_approve_plan_steps(
        self,
        *,
        collection_id: str,
        plan_id: str,
        submit_response: PlanSubmissionResponse,
    ) -> None:
        """Approve newly submitted reading steps that would otherwise block execution."""
        aliases_to_approve = [
            es.alias
            for es in submit_response.entry_statuses
            if es.entry_type == "reading" and es.status in ("needs_approval", "unresolved")
        ]
        if not aliases_to_approve:
            return

        url = f"{self._api_url}/reading/{collection_id}/reading-plan/{plan_id}/approve"
        try:
            response = self._session.post(url, json={"step_aliases": aliases_to_approve})
            self._handle_response_errors(response)
        except Exception as exc:
            raise RuntimeError(
                "Reading plan submitted, but auto-approval failed; approve the plan in the UI "
                "or retry with auto_approve disabled."
            ) from exc

        label = "step" if len(aliases_to_approve) == 1 else "steps"
        self._logger.info(
            "Auto-approved %d reading %s for plan %s",
            len(aliases_to_approve),
            label,
            plan_id,
        )

    def _resolve_flush_collection_id(self) -> str:
        """Determine and validate the collection_id for a flush.

        Every pending entry must target the same collection. Entries with an
        explicit collection_id are checked for consistency; entries without one
        inherit from default_collection_id.
        """
        seen: str | None = None
        for p in self._pending:
            cid: str | None = None
            if isinstance(p, (_PendingReading, _PendingPresetReading, _PendingDqlOnlyStep)):
                cid = p.collection_id
            if cid is None:
                continue
            if seen is None:
                seen = cid
            elif cid != seen:
                raise ValueError(
                    f"All entries in a flush must target the same collection. "
                    f"Found both {seen!r} and {cid!r}."
                )

        resolved = seen or self.default_collection_id
        if not resolved:
            raise ValueError(
                "Cannot determine collection_id. Pass collection_id to read(), "
                "or set client.default_collection_id."
            )
        return resolved

    _FLUSH_TIMEOUT_SECONDS = 600

    @staticmethod
    def _format_step_label(name: str | None, alias: str, default: str) -> str:
        """Format a step label that always includes the alias."""
        if name:
            return f"{name} [${alias}]"
        return f"{default} [${alias}]"

    def _reading_plan_url(self, collection_id: str, plan_id: str) -> str:
        return f"{self._frontend_url}/dashboard/{collection_id}/reading-plan/{plan_id}"

    def _plan_failure(
        self,
        *,
        collection_id: str,
        plan_id: str,
        message: str,
        alias: str | None = None,
        name: str | None = None,
        default_label: str = "Reading",
    ) -> _ReadingPlanFailure:
        plan_url = self._reading_plan_url(collection_id, plan_id)
        if alias is None:
            return _ReadingPlanFailure(
                f"Reading plan {plan_id} failed: {message}. Open plan: {plan_url}"
            )
        label = self._format_step_label(name, alias, default_label)
        return _ReadingPlanFailure(
            f"{label} failed in reading plan {plan_id}: {message}. Open plan: {plan_url}"
        )

    def _format_alias_labels(
        self,
        aliases: list[str],
        pending_names: dict[str, str | None],
        *,
        default_label: str = "Reading",
    ) -> str:
        return ", ".join(
            self._format_step_label(pending_names.get(alias), alias, default_label)
            for alias in aliases
        )

    def _log_waiting_for_approval(
        self,
        aliases: list[str],
        *,
        pending_names: dict[str, str | None],
    ) -> None:
        if not aliases:
            return
        self._logger.info(
            "Waiting for approval of reading %s: %s.",
            "step" if len(aliases) == 1 else "steps",
            self._format_alias_labels(aliases, pending_names),
        )

    def _log_step_started(
        self,
        alias: str,
        *,
        pending_names: dict[str, str | None],
    ) -> None:
        self._logger.info(
            "Started running reading step: %s",
            self._format_step_label(pending_names.get(alias), alias, "Reading"),
        )

    @staticmethod
    def _event_error_message(error: Any) -> str:
        if error is None:
            return "unknown error"
        if hasattr(error, "message"):
            return str(error.message)
        if isinstance(error, dict):
            error_data = cast(dict[str, Any], error)
            message = error_data.get("message")
            if message is not None:
                return str(message)
        return str(cast(object, error))

    def _iter_plan_stream_lines(
        self,
        response: requests.Response,
        *,
        collection_id: str,
        plan_id: str,
        alias: str | None = None,
        name: str | None = None,
        deadline: float | None = None,
    ) -> Iterator[str]:
        try:
            for line in response.iter_lines(decode_unicode=True):
                if deadline is not None and time.monotonic() > deadline:
                    raise self._plan_failure(
                        collection_id=collection_id,
                        plan_id=plan_id,
                        alias=alias,
                        name=name,
                        message="timed out waiting for reading plan updates",
                    )
                yield line
        except KeyboardInterrupt:
            raise self._plan_failure(
                collection_id=collection_id,
                plan_id=plan_id,
                alias=alias,
                name=name,
                message=(
                    "interrupted while waiting for reading plan updates. "
                    "The plan may still be running"
                ),
            ) from None
        except requests.exceptions.RequestException as exc:
            raise self._plan_failure(
                collection_id=collection_id,
                plan_id=plan_id,
                alias=alias,
                name=name,
                message=(
                    "lost connection to the Docent server while waiting for reading plan "
                    f"updates ({exc}). The plan may still be running"
                ),
            ) from None

    def _iter_plan_stream_events(
        self,
        *,
        collection_id: str,
        plan_id: str,
        job_id: str | None = None,
        alias: str | None = None,
        name: str | None = None,
        deadline: float | None = None,
    ) -> Iterator[PlanStreamEvent]:
        stream_url = f"{self._api_url}/reading/{collection_id}/reading-plan/{plan_id}/stream"
        if job_id is not None:
            stream_url += f"?job_id={job_id}"

        response = self._session.get(stream_url, stream=True)
        try:
            self._handle_response_errors(response)
            for line in self._iter_plan_stream_lines(
                response,
                collection_id=collection_id,
                plan_id=plan_id,
                alias=alias,
                name=name,
                deadline=deadline,
            ):
                if not line or not line.startswith("data: "):
                    continue
                payload = line[len("data: ") :]
                if payload == "[DONE]":
                    break
                try:
                    yield _plan_stream_event_adapter.validate_json(payload)
                except ValidationError:
                    continue
        finally:
            response.close()

    def _preview_and_wait(
        self,
        *,
        submit_response: PlanSubmissionResponse,
        collection_id: str,
        reading_handles: dict[str, Reading],
        pending_names: dict[str, str | None],
    ) -> None:
        """Log previews for cached steps and block until unapproved steps settle."""
        unsettled_reading_aliases: set[str] = set()
        unsettled_dql_aliases: dict[str, PlanStepSubmissionStatus] = {}

        for es in submit_response.entry_statuses:
            if es.entry_type == "dql_only":
                if es.status == "cached":
                    if es.dql_preview is not None:
                        self._log_dql_preview(pending_names.get(es.alias), es.alias, es.dql_preview)
                    else:
                        unsettled_dql_aliases[es.alias] = es
                elif es.status == "failed":
                    raise self._plan_failure(
                        collection_id=collection_id,
                        plan_id=submit_response.plan_id,
                        alias=es.alias,
                        name=pending_names.get(es.alias),
                        default_label="DQL",
                        message="DQL step failed during submission",
                    )
                else:
                    unsettled_dql_aliases[es.alias] = es

            elif es.entry_type == "reading":
                if es.status == "cached":
                    self._log_reading_preview(
                        pending_names.get(es.alias),
                        es.alias,
                        es.result_count,
                        es.result_preview,
                    )
                elif es.status == "failed":
                    raise self._plan_failure(
                        collection_id=collection_id,
                        plan_id=submit_response.plan_id,
                        alias=es.alias,
                        name=pending_names.get(es.alias),
                        message="reading step failed during submission",
                    )
                else:
                    unsettled_reading_aliases.add(es.alias)

        plan_id = submit_response.plan_id
        assert plan_id is not None

        if not unsettled_reading_aliases:
            self._validate_unsettled_dql_aliases(
                collection_id=collection_id,
                plan_id=plan_id,
                unsettled_dql_aliases=unsettled_dql_aliases,
                pending_names=pending_names,
            )
            return

        self._block_on_plan_stream(
            collection_id=collection_id,
            plan_id=plan_id,
            unsettled_reading_aliases=unsettled_reading_aliases,
            unsettled_dql_aliases=unsettled_dql_aliases,
            reading_handles=reading_handles,
            pending_names=pending_names,
        )

    def _block_on_plan_stream(
        self,
        *,
        collection_id: str,
        plan_id: str,
        unsettled_reading_aliases: set[str],
        unsettled_dql_aliases: dict[str, PlanStepSubmissionStatus],
        reading_handles: dict[str, Reading],
        pending_names: dict[str, str | None],
    ) -> None:
        """Connect to the plan SSE stream and block until all submitted steps settle."""
        pending = set(unsettled_reading_aliases)
        deadline = time.monotonic() + self._FLUSH_TIMEOUT_SECONDS
        approval_status_by_alias: dict[str, str] = {}
        logged_started_aliases: set[str] = set()

        for event in self._iter_plan_stream_events(
            collection_id=collection_id,
            plan_id=plan_id,
            deadline=deadline,
        ):
            if isinstance(event, PlanSnapshotEvent):
                newly_needing_approval: list[str] = []
                for step in event.steps:
                    previous_status = approval_status_by_alias.get(step.alias)
                    approval_status_by_alias[step.alias] = step.derived_status
                    if (
                        step.alias in pending
                        and step.derived_status == "needs_approval"
                        and previous_status != "needs_approval"
                    ):
                        newly_needing_approval.append(step.alias)
                    if step.alias in pending and step.derived_status in ("completed", "cached"):
                        pending.discard(step.alias)
                        if step.reading_id is not None:
                            self._log_step_completed_preview(
                                collection_id,
                                step.reading_id,
                                pending_names.get(step.alias),
                                step.alias,
                                reading_handles.get(step.alias),
                            )
                    elif step.alias in pending and step.derived_status == "failed":
                        raise self._plan_failure(
                            collection_id=collection_id,
                            plan_id=plan_id,
                            alias=step.alias,
                            name=pending_names.get(step.alias),
                            message="step reached failed status",
                        )
                self._log_waiting_for_approval(
                    newly_needing_approval,
                    pending_names=pending_names,
                )
                self._try_preview_unresolved_dql(
                    collection_id,
                    plan_id,
                    unsettled_dql_aliases,
                    pending_names,
                )
                if not pending and not unsettled_dql_aliases:
                    break
                continue

            if isinstance(event, PlanStepStartedEvent):
                approval_status_by_alias[event.step_alias] = "running"
                if event.step_alias in pending and event.step_alias not in logged_started_aliases:
                    self._log_step_started(event.step_alias, pending_names=pending_names)
                    logged_started_aliases.add(event.step_alias)

            elif isinstance(event, PlanStepCompletedEvent):
                if event.step_alias in pending:
                    pending.discard(event.step_alias)
                    self._log_step_completed_preview(
                        collection_id,
                        event.reading_id,
                        pending_names.get(event.step_alias),
                        event.step_alias,
                        reading_handles.get(event.step_alias),
                        result_count=event.result_count,
                    )
                self._try_preview_unresolved_dql(
                    collection_id,
                    plan_id,
                    unsettled_dql_aliases,
                    pending_names,
                )

            elif isinstance(event, PlanStepFailedEvent) and event.step_alias in pending:
                raise self._plan_failure(
                    collection_id=collection_id,
                    plan_id=plan_id,
                    alias=event.step_alias,
                    name=pending_names.get(event.step_alias),
                    message=self._event_error_message(event.error),
                )

            elif isinstance(event, PlanJobCancelledEvent):
                remaining = sorted(pending | set(unsettled_dql_aliases))
                raise self._plan_failure(
                    collection_id=collection_id,
                    plan_id=plan_id,
                    message=(
                        "job was cancelled"
                        + (f"; remaining steps: {', '.join(remaining)}" if remaining else "")
                    ),
                )

            elif isinstance(event, PlanJobFailedEvent):
                raise self._plan_failure(
                    collection_id=collection_id,
                    plan_id=plan_id,
                    message=f"job failed: {self._event_error_message(event.error)}",
                )

            if not pending and not unsettled_dql_aliases:
                break

        if pending:
            raise self._plan_failure(
                collection_id=collection_id,
                plan_id=plan_id,
                message=f"stream ended before steps settled: {', '.join(sorted(pending))}",
            )
        self._validate_unsettled_dql_aliases(
            collection_id=collection_id,
            plan_id=plan_id,
            unsettled_dql_aliases=unsettled_dql_aliases,
            pending_names=pending_names,
        )

    def _try_preview_unresolved_dql(
        self,
        collection_id: str,
        plan_id: str,
        unsettled_dql_aliases: dict[str, PlanStepSubmissionStatus],
        pending_names: dict[str, str | None],
    ) -> None:
        """Check if any unresolved DQL steps can now be previewed."""
        newly_resolved: list[str] = []
        for alias in list(unsettled_dql_aliases):
            dql_result = self._try_execute_dql_for_alias(
                collection_id, plan_id, alias, pending_names.get(alias)
            )
            if dql_result is not None:
                newly_resolved.append(alias)
        for alias in newly_resolved:
            unsettled_dql_aliases.pop(alias, None)

    def _validate_unsettled_dql_aliases(
        self,
        *,
        collection_id: str,
        plan_id: str,
        unsettled_dql_aliases: dict[str, PlanStepSubmissionStatus],
        pending_names: dict[str, str | None],
    ) -> None:
        """Execute any remaining DQL-only steps or fail if they cannot resolve."""
        self._try_preview_unresolved_dql(
            collection_id,
            plan_id,
            unsettled_dql_aliases,
            pending_names,
        )
        if not unsettled_dql_aliases:
            return

        aliases = ", ".join(
            self._format_step_label(pending_names.get(alias), alias, "DQL")
            for alias in sorted(unsettled_dql_aliases)
        )
        raise self._plan_failure(
            collection_id=collection_id,
            plan_id=plan_id,
            message=f"DQL step dependencies did not resolve: {aliases}",
        )

    def _try_execute_dql_for_alias(
        self,
        collection_id: str,
        plan_id: str,
        alias: str,
        name: str | None,
    ) -> dict[str, Any] | None:
        """Attempt to execute a DQL step that was previously unresolved."""
        plan_state = self._get_reading_plan_state(collection_id, plan_id)
        for step in plan_state.get("steps", []):
            if step.get("alias") == alias:
                status = step.get("derived_status")
                if status == "cached":
                    dql_query = step.get("dql_query")
                    if not dql_query:
                        raise self._plan_failure(
                            collection_id=collection_id,
                            plan_id=plan_id,
                            alias=alias,
                            name=name,
                            default_label="DQL",
                            message="DQL step has no query",
                        )
                    try:
                        result = cast(Any, self).execute_dql(
                            collection_id,
                            dql_query,
                            reading_plan_id=plan_id,
                        )
                    except Exception as exc:
                        raise self._plan_failure(
                            collection_id=collection_id,
                            plan_id=plan_id,
                            alias=alias,
                            name=name,
                            default_label="DQL",
                            message=str(exc),
                        ) from exc
                    from docent.data_models.reading import DqlPreview

                    preview = DqlPreview(
                        columns=result.get("columns", []),
                        rows=result.get("rows", [])[:10],
                        truncated=result.get("truncated", False),
                        row_count=result.get("row_count", 0),
                    )
                    self._log_dql_preview(name, alias, preview)
                    return result
                if status == "failed":
                    raise self._plan_failure(
                        collection_id=collection_id,
                        plan_id=plan_id,
                        alias=alias,
                        name=name,
                        default_label="DQL",
                        message="DQL step reached failed status",
                    )
                break
        return None

    def _log_step_completed_preview(
        self,
        collection_id: str,
        reading_id: str | None,
        name: str | None,
        alias: str,
        handle: Reading | None,
        result_count: int | None = None,
    ) -> None:
        """Fetch results for a just-completed step, log preview, populate handle."""
        label = self._format_step_label(name, alias, "Reading")
        if reading_id is None:
            self._logger.info("%s: completed", label)
            return

        if handle is not None:
            self._fetch_reading_results(handle, collection_id, reading_id)

        count_str = f" ({result_count} results)" if result_count is not None else ""
        results = handle._results if handle is not None and handle._results is not None else None  # pyright: ignore[reportPrivateUsage]
        if results:
            preview = results[:3]
            self._logger.info("%s: completed%s", label, count_str)
            for r in preview:
                if r.output:
                    summary = json.dumps(r.output, default=str)
                    if len(summary) > 200:
                        summary = summary[:197] + "..."
                    self._logger.info("  %s", summary)
                elif r.error:
                    self._logger.info("  [error] %s", r.error)
        else:
            self._logger.info("%s: completed%s", label, count_str)

    def _log_dql_preview(self, name: str | None, alias: str, dql_preview: Any) -> None:
        """Log a DQL result preview to stdout."""
        from docent.data_models.reading import DqlPreview

        if isinstance(dql_preview, dict):
            dql_preview = DqlPreview.model_validate(dql_preview)

        label = self._format_step_label(name, alias, "DQL")
        cols = dql_preview.columns
        rows = dql_preview.rows
        truncated = dql_preview.truncated
        row_count = dql_preview.row_count

        count_note = f" ({row_count} rows"
        if truncated:
            count_note += ", truncated"
        count_note += ")"

        self._logger.info("%s:%s", label, count_note)
        if not rows:
            return

        col_widths = [len(c) for c in cols]
        for row in rows[:5]:
            for i, val in enumerate(row):
                s = str(val) if val is not None else ""
                if len(s) > 60:
                    s = s[:57] + "..."
                if i < len(col_widths):
                    col_widths[i] = max(col_widths[i], len(s))

        header = "  " + " | ".join(c.ljust(col_widths[i]) for i, c in enumerate(cols))
        sep = "  " + "-+-".join("-" * w for w in col_widths)
        self._logger.info(header)
        self._logger.info(sep)
        for row in rows[:5]:
            cells: list[str] = []
            for i, val in enumerate(row):
                s = str(val) if val is not None else ""
                if len(s) > 60:
                    s = s[:57] + "..."
                w = col_widths[i] if i < len(col_widths) else 0
                cells.append(s.ljust(w))
            self._logger.info("  %s", " | ".join(cells))
        if len(rows) > 5:
            self._logger.info("  ... and %d more rows", len(rows) - 5)

    def _log_reading_preview(
        self,
        name: str | None,
        alias: str,
        result_count: int | None,
        result_preview: list[Any] | None,
    ) -> None:
        """Log a reading result preview to stdout."""
        label = self._format_step_label(name, alias, "Reading")
        count_str = f" ({result_count} results)" if result_count is not None else ""
        self._logger.info("%s: cached%s", label, count_str)
        if result_preview:
            for rp in result_preview[:3]:
                output = rp.output if hasattr(rp, "output") else rp.get("output")
                error = rp.error if hasattr(rp, "error") else rp.get("error")
                if output:
                    summary = json.dumps(output, default=str)
                    if len(summary) > 200:
                        summary = summary[:197] + "..."
                    self._logger.info("  %s", summary)
                elif error:
                    self._logger.info("  [error] %s", error)

    def _force_flush(self, reading: Reading) -> None:
        """Flush pending readings if the given reading is still pending."""
        for p in self._pending:
            if isinstance(p, (_PendingReading, _PendingPresetReading)) and p.handle is reading:
                self.flush(open_in_browser=True)
                return

    def _get_reading_plan_state(self, collection_id: str, plan_id: str) -> dict[str, Any]:
        """Fetch the latest reading-plan state for SDK waiting/polling."""
        url = f"{self._api_url}/reading/{collection_id}/reading-plan/{plan_id}"
        response = self._session.get(url)
        self._handle_response_errors(response)
        data = response.json()
        if not isinstance(data, dict):
            raise RuntimeError(f"Unexpected reading plan payload for {plan_id!r}")
        return cast(dict[str, Any], data)

    def _wait_for_plan_step(
        self,
        *,
        collection_id: str,
        plan_id: str,
        job_id: str,
        alias: str,
        deadline: float | None = None,
    ) -> str | None:
        """Wait for a specific alias on a job-scoped reading-plan stream."""
        for event in self._iter_plan_stream_events(
            collection_id=collection_id,
            plan_id=plan_id,
            job_id=job_id,
            alias=alias,
            deadline=deadline,
        ):
            if isinstance(event, PlanSnapshotEvent):
                for step in event.steps:
                    if step.alias != alias:
                        continue
                    if (
                        step.derived_status in ("completed", "cached")
                        and step.reading_id is not None
                    ):
                        return step.reading_id
                    if step.derived_status == "failed":
                        raise self._plan_failure(
                            collection_id=collection_id,
                            plan_id=plan_id,
                            alias=alias,
                            message="step reached failed status",
                        )
                continue

            if isinstance(event, PlanStepCompletedEvent) and event.step_alias == alias:
                return event.reading_id

            if isinstance(event, PlanStepFailedEvent) and event.step_alias == alias:
                raise self._plan_failure(
                    collection_id=collection_id,
                    plan_id=plan_id,
                    alias=alias,
                    message=self._event_error_message(event.error),
                )

            if isinstance(event, PlanJobFailedEvent):
                raise self._plan_failure(
                    collection_id=collection_id,
                    plan_id=plan_id,
                    alias=alias,
                    message=(
                        f"job {job_id!r} failed before step completed: "
                        f"{self._event_error_message(event.error)}"
                    ),
                )

            if isinstance(event, PlanJobCompletedEvent):
                break
        return None

    def _wait_for_reading(self, reading: Reading) -> None:
        """Block until a reading's results are available."""
        if reading._results is not None:  # pyright: ignore[reportPrivateUsage]
            return

        collection_id = self._flushed_collection_id or self.default_collection_id
        if not collection_id:
            raise ValueError("Cannot determine collection_id for waiting")

        plan_id = self._plan_id
        alias = reading._alias  # pyright: ignore[reportPrivateUsage]
        assert plan_id is not None, "Cannot wait for reading without a plan_id"

        reading_id: str | None = None
        deadline = time.monotonic() + 300

        try:
            while time.monotonic() < deadline:
                plan_state = self._get_reading_plan_state(collection_id, plan_id)
                raw_steps = cast(list[Any] | None, plan_state.get("steps"))
                if not isinstance(raw_steps, list):
                    raise RuntimeError(f"Reading plan {plan_id!r} returned invalid step state")
                steps: list[dict[str, Any]] = []
                for raw_step in raw_steps:
                    if isinstance(raw_step, dict):
                        steps.append(cast(dict[str, Any], raw_step))

                matching_step: dict[str, Any] | None = None
                for step in steps:
                    if step.get("alias") == alias:
                        matching_step = step
                        break
                if matching_step is None:
                    raise RuntimeError(f"Failed to find reading plan entry {alias!r}")

                step_status = cast(str | None, matching_step.get("derived_status"))
                step_reading_id = cast(str | None, matching_step.get("reading_id"))
                if isinstance(step_reading_id, str) and step_status in ("completed", "cached"):
                    reading_id = step_reading_id
                    break
                if step_status == "failed":
                    raise self._plan_failure(
                        collection_id=collection_id,
                        plan_id=plan_id,
                        alias=alias,
                        message="step reached failed status",
                    )

                active_job_id = plan_state.get("active_job_id")
                if isinstance(active_job_id, str) and active_job_id:
                    reading_id = self._wait_for_plan_step(
                        collection_id=collection_id,
                        plan_id=plan_id,
                        job_id=active_job_id,
                        alias=alias,
                        deadline=deadline,
                    )
                    if reading_id is not None:
                        break

                time.sleep(1)
        except KeyboardInterrupt:
            raise self._plan_failure(
                collection_id=collection_id,
                plan_id=plan_id,
                alias=alias,
                message=(
                    "interrupted while waiting for reading results. The plan may still be running"
                ),
            ) from None

        if reading_id is None:
            raise RuntimeError(f"Failed to resolve reading for plan entry {alias!r}")

        reading._set_reading_id(reading_id)  # pyright: ignore[reportPrivateUsage]
        self._fetch_reading_results(reading, collection_id, reading_id)

    def _fetch_reading_results(self, reading: Reading, collection_id: str, reading_id: str) -> None:
        """Fetch final results for a reading via REST."""
        url = f"{self._api_url}/reading/{collection_id}/reading/{reading_id}/results"
        response = self._session.get(url)
        self._handle_response_errors(response)
        data: Any = response.json()
        result_list = cast(
            list[dict[str, Any]],
            data if isinstance(data, list) else data.get("results", []),
        )
        reading._set_reading_id(reading_id)  # pyright: ignore[reportPrivateUsage]
        reading._set_results(  # pyright: ignore[reportPrivateUsage]
            [
                ReadingResult(
                    id=r.get("id"),
                    output=r.get("output"),
                    error=r.get("error"),
                    arguments=r.get("arguments_dict", {}),
                )
                for r in result_list
            ]
        )
