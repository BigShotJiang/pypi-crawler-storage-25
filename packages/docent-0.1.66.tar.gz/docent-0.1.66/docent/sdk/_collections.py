"""Collection CRUD and agent-run upload jobs."""

from __future__ import annotations

import gzip
import time
from typing import Any, Literal

from tqdm import tqdm

from docent.data_models.agent_run import AgentRun
from docent.sdk._base import DocentBase
from docent.sdk._client_util import MAX_AGENT_RUN_PAYLOAD_BYTES, yield_agent_run_batches_by_size


class DocentCollectionsMixin(DocentBase):
    """Methods for collections and batched agent-run ingestion."""

    def create_collection(
        self,
        collection_id: str | None = None,
        name: str | None = None,
        description: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """Creates a new Collection.

        Creates a new Collection and sets up a default MECE dimension
        for grouping on the homepage.

        Args:
            collection_id: Optional ID for the new Collection. If not provided, one will be generated.
            name: Optional name for the Collection.
            description: Optional description for the Collection.
            metadata: Optional metadata dict to attach to the Collection.

        Returns:
            str: The ID of the created Collection.

        Raises:
            ValueError: If the response is missing the Collection ID.
            requests.exceptions.HTTPError: If the API request fails.
        """
        url = f"{self._api_url}/create"
        payload: dict[str, Any] = {
            "collection_id": collection_id,
            "name": name,
            "description": description,
        }
        if metadata is not None:
            payload["metadata"] = metadata

        response = self._session.post(url, json=payload)
        self._handle_response_errors(response)

        response_data = response.json()
        collection_id = response_data.get("collection_id")
        if collection_id is None:
            raise ValueError("Failed to create collection: 'collection_id' missing in response.")

        self._logger.info("Successfully created Collection with id='%s'", collection_id)

        self._logger.info(
            "Collection creation complete. Frontend available at: %s",
            self._collection_dashboard_url(collection_id),
        )
        return collection_id

    def update_collection(
        self,
        collection_id: str,
        name: str | None = None,
        description: str | None = None,
    ) -> None:
        """Updates a Collection's name and/or description.

        Requires WRITE permission on the collection.

        Args:
            collection_id: ID of the Collection to update.
            name: New name for the Collection. If None, the name will be left unchanged.
            description: New description for the Collection. If None, the description will be left unchanged.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        url = f"{self._api_url}/{collection_id}/collection"
        payload: dict[str, Any] = {}
        if name is not None:
            payload["name"] = name
        if description is not None:
            payload["description"] = description

        response = self._session.put(url, json=payload)
        self._handle_response_errors(response)

        self._logger.info("Successfully updated Collection '%s'", collection_id)

    def add_agent_runs(
        self,
        collection_id: str,
        agent_runs: list[AgentRun],
        *,
        compression: Literal["gzip", "none"] = "gzip",
        wait: bool = True,
        poll_interval: float = 1.0,
        # Deprecated
        batch_size: int | None = None,
    ) -> dict[str, Any]:
        """Adds agent runs to a Collection.

        Agent runs represent execution traces that can be visualized and analyzed.
        Requests are automatically chunked to stay under the backend's payload limit.

        Args:
            collection_id: ID of the Collection.
            agent_runs: List of AgentRun objects to add.
            compression: Compression algorithm for request bodies. Defaults to gzip.
                Set to "none" to retain legacy behavior.
            wait: If True (default), wait for all ingestion jobs to complete before returning.
                If False, return immediately after enqueuing jobs.
            poll_interval: Seconds between status checks when wait=True. Defaults to 1.0.

        Returns:
            dict: API response data containing:
                - status: "success" if all jobs completed, "enqueued" if wait=False
                - total_runs_added: Number of agent runs submitted
                - job_ids: List of job IDs for tracking

        Raises:
            ValueError: If any single agent run exceeds the maximum payload size.
            requests.exceptions.HTTPError: If the API request fails.
            RuntimeError: If any job fails during processing (when wait=True).
        """

        if batch_size is not None:
            self._logger.warning(
                "The 'batch_size' parameter is deprecated and will be removed in a future version. "
                "We have transitioned to a new batching strategy based on the size of the payload."
            )

        url = f"{self._api_url}/{collection_id}/agent_runs"
        total_runs = len(agent_runs)
        job_ids: list[str] = []

        # Process agent runs in batches
        desc = f"Uploading agent runs (compression={compression})"
        with tqdm(total=total_runs, desc=desc, unit="runs") as pbar:
            for n_runs_in_batch, payload_bytes in yield_agent_run_batches_by_size(
                agent_runs, MAX_AGENT_RUN_PAYLOAD_BYTES
            ):
                request_kwargs: dict[str, Any] = {}
                if compression == "none":
                    request_kwargs["data"] = payload_bytes
                    request_kwargs["headers"] = {"Content-Type": "application/json"}
                elif compression == "gzip":
                    request_kwargs["data"] = gzip.compress(payload_bytes)
                    request_kwargs["headers"] = {
                        "Content-Type": "application/json",
                        "Content-Encoding": "gzip",
                    }
                else:
                    raise ValueError(f"Unsupported compression '{compression}'")

                response = self._post_with_retry(url, **request_kwargs)
                self._handle_response_errors(response)

                # Server returns 202 with job_id for async processing
                response_data = response.json()
                job_id = response_data.get("job_id")
                if job_id:
                    job_ids.append(job_id)

                pbar.update(n_runs_in_batch)

        if not wait:
            self._logger.info(
                "Enqueued %s agent runs to Collection '%s' (%s job(s)). Use get_agent_run_job_status() to check progress.",
                total_runs,
                collection_id,
                len(job_ids),
            )
            return {
                "status": "enqueued",
                "total_runs_added": total_runs,
                "job_ids": job_ids,
            }

        # Wait for all jobs to complete
        if job_ids:
            self._logger.info(
                "Uploaded %s agent runs in %s batch(es). Waiting for server-side processing to complete... (set wait=False to skip waiting)",
                total_runs,
                len(job_ids),
            )
            self._wait_for_jobs(collection_id, job_ids, poll_interval)

        self._logger.info(
            "Successfully added %s agent runs to Collection '%s'. All %s job(s) completed. View the collection at: %s",
            total_runs,
            collection_id,
            len(job_ids),
            self._collection_dashboard_url(collection_id),
        )
        return {"status": "success", "total_runs_added": total_runs, "job_ids": job_ids}

    def _wait_for_jobs(
        self,
        collection_id: str,
        job_ids: list[str],
        poll_interval: float = 1.0,
    ) -> None:
        """Wait for all jobs to complete, showing progress.

        Args:
            collection_id: ID of the Collection.
            job_ids: List of job IDs to wait for.
            poll_interval: Seconds between status checks.

        Raises:
            RuntimeError: If any job fails or is canceled.
        """
        pending_jobs = set(job_ids)
        failed_jobs: dict[str, str] = {}

        with tqdm(total=len(job_ids), desc="Waiting for server processing", unit="jobs") as pbar:
            while pending_jobs:
                statuses = self.get_agent_run_job_statuses(collection_id, list(pending_jobs))

                for job_status in statuses:
                    job_id = job_status["job_id"]
                    status = job_status["status"]

                    if status == "completed":
                        pending_jobs.discard(job_id)
                        pbar.update(1)
                    elif status == "canceled":
                        pending_jobs.discard(job_id)
                        failed_jobs[job_id] = "Job was canceled"
                        pbar.update(1)

                if pending_jobs:
                    time.sleep(poll_interval)

        if failed_jobs:
            failed_msg = ", ".join(f"{k}: {v}" for k, v in failed_jobs.items())
            raise RuntimeError(f"Some jobs failed: {failed_msg}")

    def get_agent_run_job_statuses(
        self, collection_id: str, job_ids: list[str]
    ) -> list[dict[str, Any]]:
        """Get the status of multiple agent run ingestion jobs.

        Args:
            collection_id: ID of the Collection.
            job_ids: List of job IDs to check (max 100).

        Returns:
            list: List of job status dictionaries, each containing:
                - job_id: The job ID
                - status: One of "pending", "running", "completed", "canceled"
                - type: The job type
                - created_at: ISO timestamp of job creation

        Raises:
            ValueError: If more than 100 job IDs are provided.
            requests.exceptions.HTTPError: If the API request fails.
        """
        if len(job_ids) > 100:
            raise ValueError("Cannot request more than 100 job IDs at once")

        url = f"{self._api_url}/{collection_id}/agent_runs/jobs/batch_status"
        response = self._session.post(url, json={"job_ids": job_ids})
        self._handle_response_errors(response)
        return response.json()["jobs"]

    def get_agent_run_job_status(self, collection_id: str, job_id: str) -> dict[str, Any]:
        """Get the status of an agent run ingestion job.

        Args:
            collection_id: ID of the Collection.
            job_id: The ID of the job to check.

        Returns:
            dict: Job status information including:
                - job_id: The job ID
                - status: One of "pending", "running", "completed", "canceled"
                - type: The job type
                - created_at: ISO timestamp of job creation

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        url = f"{self._api_url}/{collection_id}/agent_runs/jobs/{job_id}"
        response = self._session.get(url)
        self._handle_response_errors(response)
        return response.json()

    def list_collections(self) -> list[dict[str, Any]]:
        """Lists all available Collections.

        Returns:
            list: List of Collection summary objects, including owner,
                permission, and precomputed count information.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        url = f"{self._api_url}/collections"
        response = self._session.get(url)
        self._handle_response_errors(response)
        return response.json()

    def get_collection(self, collection_id: str) -> dict[str, Any] | None:
        """Get details about a specific Collection.

        Requires READ permission on the collection.

        Args:
            collection_id: ID of the Collection to retrieve.

        Returns:
            Collection: Collection details with owner, permission, and
                precomputed count information. Returns None if collection not found.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        url = f"{self._api_url}/{collection_id}/collection_details"
        response = self._session.get(url)
        self._handle_response_errors(response)
        return response.json()

    def update_collection_metadata(
        self,
        collection_id: str,
        metadata: dict[str, Any],
    ) -> dict[str, Any]:
        """Deep-merge metadata into a collection's existing metadata.

        Args:
            collection_id: ID of the Collection.
            metadata: Metadata dict to merge into the existing collection metadata.

        Returns:
            The full merged metadata dict.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        url = f"{self._api_url}/{collection_id}/collection/metadata"
        response = self._session.put(url, json={"metadata": metadata})
        self._handle_response_errors(response)
        return response.json()

    def delete_collection_metadata_keys(
        self,
        collection_id: str,
        keys: list[str],
    ) -> tuple[dict[str, Any], list[str]]:
        """Remove keys from collection metadata. Supports dot-paths for nested keys.

        Args:
            collection_id: ID of the Collection.
            keys: List of keys to remove. Use dot notation for nested keys (e.g. "config.model").

        Returns:
            Tuple of (metadata after deletion, list of keys that were not found).

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        url = f"{self._api_url}/{collection_id}/collection/metadata/delete"
        response = self._session.post(url, json={"keys": keys})
        self._handle_response_errors(response)
        data = response.json()
        return data["metadata"], data["not_found"]

    def get_collection_metadata(
        self,
        collection_id: str,
    ) -> dict[str, Any]:
        """Get a collection's metadata.

        Args:
            collection_id: ID of the Collection.

        Returns:
            The collection's metadata dict.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        url = f"{self._api_url}/{collection_id}/collection/metadata"
        response = self._session.get(url)
        self._handle_response_errors(response)
        return response.json()

    def get_metadata_fields(
        self,
        collection_id: str,
        include_sample_values: bool = False,
        sample_limit: int = 10,
    ) -> dict[str, Any]:
        """Get the available metadata fields for agent runs in a collection.

        Args:
            collection_id: ID of the Collection.
            include_sample_values: Whether to include sample values for each field.
            sample_limit: Maximum number of sample values to return per field.

        Returns:
            List of metadata field dictionaries with 'name', 'type', and optionally
            'sample_values' and 'total_unique_values'.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        url = f"{self._api_url}/{collection_id}/agent_run_metadata_fields?metadata_only=true"
        params = {
            "include_sample_values": str(include_sample_values).lower(),
            "sample_limit": sample_limit,
        }
        response = self._session.get(url, params=params)
        self._handle_response_errors(response)
        return response.json()
