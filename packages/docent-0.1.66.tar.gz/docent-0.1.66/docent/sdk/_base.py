"""Core Docent SDK client: configuration, session, and HTTP helpers."""

from __future__ import annotations

import os
import time
from pathlib import Path
from typing import IO, Any, cast
from urllib.parse import urlsplit

import requests

from docent._log_util.logger import get_logger
from docent.sdk._client_util import LOCAL_DOMAINS, domain_host, load_config_file, normalize_or_none
from docent.sdk.reading import PendingEntry


class DocentBase:
    """Shared initialization and request plumbing for :class:`Docent`."""

    @classmethod
    def from_url(cls, url: str, **kwargs: Any) -> "DocentBase":
        """Create a Docent client from a dashboard URL.

        Parses URLs like https://docent.transluce.org/dashboard/668354d8-...
        to extract the domain and collection ID.

        Any additional keyword arguments are forwarded to the Docent constructor.
        """
        parsed = urlsplit(url)
        # Use netloc (host:port) rather than hostname so non-default ports
        # survive. Strip any userinfo defensively.
        netloc = parsed.netloc
        if "@" in netloc:
            netloc = netloc.split("@", 1)[1]
        domain = netloc or parsed.hostname
        parts = [p for p in parsed.path.strip("/").split("/") if p]
        collection_id = None
        for i, part in enumerate(parts):
            if part == "dashboard" and i + 1 < len(parts):
                collection_id = parts[i + 1]
                break
        return cls(domain=domain, collection_id=collection_id, **kwargs)

    def __init__(
        self,
        *,
        domain: str | None = None,
        use_https: bool = True,
        api_key: str | None = None,
        collection_id: str | None = None,
        config_file: str | Path | None = None,
        profile: str | None = None,
        log_stream: IO[str] | None = None,
        api_url: str | None = None,
        frontend_url: str | None = None,
        # Deprecated (use api_url and frontend_url instead)
        server_url: str | None = None,
        web_url: str | None = None,
    ):
        """Initialize the Docent client.

        Args:
            domain: The domain of the Docent instance. Defaults to "docent.transluce.org".
                The API and frontend URLs will be constructed from this domain automatically (unless overridden).
                Local domains require explicit API and frontend URL overrides.
            api_key: API key for authentication. If not provided, will attempt to read
                from the DOCENT_API_KEY environment variable or from a config file.
            collection_id: Default collection ID to use for API calls. If not provided,
                will attempt to read from DOCENT_COLLECTION_ID in the config file or environment.
                Methods that require a collection_id will use this default if not explicitly passed.
            config_file: Optional path to a dotenv config file. If not provided, will search
                for 'docent.env' in the current directory and parent directories.
                Supports DOCENT_API_KEY, DOCENT_API_URL, DOCENT_FRONTEND_URL, DOCENT_DOMAIN,
                and DOCENT_COLLECTION_ID.
            profile: Optional named profile to load from a multi-profile config file.
                If not provided, falls back to the DOCENT_PROFILE environment variable.
                Multi-profile config files use INI-style [section] headers.
            log_stream: Output stream for log messages. Defaults to sys.stdout.
            api_url: Direct URL of the Docent API server.
            frontend_url: Direct URL of the Docent frontend UI.
            server_url: (Deprecated) Direct URL of the Docent API server. Use `api_url` instead.
            web_url: (Deprecated) Direct URL of the Docent frontend UI. Use `frontend_url` instead.
                Providing only one of server_url/web_url currently emits a warning and
                will become an error in a future version.

        Raises:
            ValueError: If no API key is provided and DOCENT_API_KEY is not set.

        Example:
            >>> client = Docent(domain="my-instance.docent.com", api_key="sk-...")
            >>> # Or use a config file with default collection
            >>> client = Docent(config_file="/path/to/config.env")
            >>> # Or let it auto-discover docent.env
            >>> client = Docent()
        """
        self._logger = get_logger(__name__, stream=log_stream)

        # Warn about deprecated parameters
        if server_url is not None:
            self._logger.warning(
                "The 'server_url' parameter is deprecated and will be removed in a future version. "
                "Please use 'api_url' instead."
            )
        if web_url is not None:
            self._logger.warning(
                "The 'web_url' parameter is deprecated and will be removed in a future version. "
                "Please use 'frontend_url' instead."
            )

        # Load config file
        resolved_profile = profile or os.getenv("DOCENT_PROFILE")
        config = load_config_file(config_file, logger=self._logger, profile=resolved_profile)

        # Set domain; precedence: param > env > config file > default
        domain = (
            domain
            or os.getenv("DOCENT_DOMAIN")
            or config.get("DOCENT_DOMAIN")
            or "docent.transluce.org"
        )
        self._domain = domain

        # URL overrides precedence: new params > legacy params > env > config file
        normalized_api_url = normalize_or_none(api_url, strip_trailing_slash=True)
        normalized_server_url = normalize_or_none(server_url, strip_trailing_slash=True)
        if (
            normalized_api_url is not None
            and normalized_server_url is not None
            and normalized_api_url != normalized_server_url
        ):
            raise ValueError("Received conflicting values for api_url and server_url.")

        normalized_frontend_url = normalize_or_none(frontend_url, strip_trailing_slash=True)
        normalized_web_url = normalize_or_none(web_url, strip_trailing_slash=True)
        if (
            normalized_frontend_url is not None
            and normalized_web_url is not None
            and normalized_frontend_url != normalized_web_url
        ):
            raise ValueError("Received conflicting values for frontend_url and web_url.")

        resolved_api_url = (
            normalized_api_url
            or normalized_server_url
            or normalize_or_none(os.getenv("DOCENT_API_URL"), strip_trailing_slash=True)
            or normalize_or_none(config.get("DOCENT_API_URL"), strip_trailing_slash=True)
        )
        resolved_frontend_url = (
            normalized_frontend_url
            or normalized_web_url
            or normalize_or_none(os.getenv("DOCENT_FRONTEND_URL"), strip_trailing_slash=True)
            or normalize_or_none(config.get("DOCENT_FRONTEND_URL"), strip_trailing_slash=True)
        )

        has_api_override = resolved_api_url is not None
        has_frontend_override = resolved_frontend_url is not None
        if has_api_override != has_frontend_override:
            self._logger.warning(
                "Only one of API/frontend URL overrides is set. This is deprecated and will "
                "become an error in a future version. Set both DOCENT_API_URL and "
                "DOCENT_FRONTEND_URL (or pass both api_url/frontend_url)."
            )

        prefix = "https://" if use_https else "http://"

        if not (has_api_override and has_frontend_override):
            if domain_host(domain) in LOCAL_DOMAINS:
                raise ValueError(
                    "Local domains require explicit DOCENT_API_URL and DOCENT_FRONTEND_URL "
                    "(or pass both api_url and frontend_url)."
                )

        api_url_raw = resolved_api_url if resolved_api_url is not None else f"{prefix}api.{domain}"
        if not api_url_raw.endswith("/rest"):
            api_url_raw = f"{api_url_raw}/rest"
        self._api_url = api_url_raw

        self._frontend_url = (
            resolved_frontend_url if resolved_frontend_url is not None else f"{prefix}{domain}"
        )
        # Backward-compatible aliases for legacy private attribute usage.
        self._server_url = self._api_url
        self._web_url = self._frontend_url

        # Set default collection ID; precedence: param > config file > None
        self.default_collection_id: str | None = collection_id or config.get("DOCENT_COLLECTION_ID")

        # Use requests.Session for connection pooling and persistent headers
        self._session = requests.Session()

        # Set API key; precedence: param > config file > env
        api_key = api_key or config.get("DOCENT_API_KEY") or os.getenv("DOCENT_API_KEY")

        if api_key is None:
            raise ValueError(
                "api_key is required. Please provide an api_key, set the DOCENT_API_KEY "
                "environment variable, or include DOCENT_API_KEY in a docent.env file."
            )

        self._login(api_key)

        # ── Reading plan state ──
        self._plan_id: str | None = None
        self._flushed_collection_id: str | None = None
        self._pending: list[PendingEntry] = []
        self._alias_counter: int = 1
        self._auto_flush: bool = True
        self._atexit_registered: bool = False
        self._crash_detected: bool = False
        self._plan_name: str | None = None
        self._plan_name_sent: bool = False
        self._is_notebook: bool = False
        self._notebook_hook_registered: bool = False

        self._register_notebook_hook()

    def _register_notebook_hook(self) -> None:
        if self._notebook_hook_registered:
            return
        try:
            ip = get_ipython()  # type: ignore[name-defined]
        except NameError:
            return
        if ip is None:
            return
        self._is_notebook = True
        self._notebook_hook_registered = True

        def _cell_post_run(*args: Any, **kwargs: Any) -> None:
            if self._pending and self._auto_flush:
                open_browser = self._plan_id is None
                try:
                    cast(Any, self).flush(open_in_browser=open_browser)
                except Exception:
                    self._logger.exception("Notebook auto-flush failed")

        ip.events.register("post_run_cell", _cell_post_run)  # type: ignore[reportUnknownMemberType]

    @property
    def frontend_url(self) -> str:
        """Resolved Docent frontend base URL."""
        return self._frontend_url

    @property
    def backend_url(self) -> str:
        """Resolved Docent backend/API base URL."""
        return self._api_url

    def _collection_dashboard_url(self, collection_id: str, path: str | None = None) -> str:
        """Build a frontend URL for a collection dashboard page."""
        base_url = f"{self._frontend_url}/dashboard/{collection_id}"
        if path is None:
            return base_url

        normalized_path = path.strip("/")
        if not normalized_path:
            return base_url

        return f"{base_url}/{normalized_path}"

    @property
    def plan_name(self) -> str | None:
        return self._plan_name

    @plan_name.setter
    def plan_name(self, value: str | None) -> None:
        if self._plan_name_sent and self._plan_name is not None and value != self._plan_name:
            raise RuntimeError(
                f"Cannot rename plan from {self._plan_name!r} to {value!r} after it has been sent"
            )
        self._plan_name = value

    @property
    def auto_flush(self) -> bool:
        return self._auto_flush

    @auto_flush.setter
    def auto_flush(self, value: bool) -> None:
        self._auto_flush = value

    def _handle_response_errors(self, response: requests.Response):
        """Handle API response and raise informative errors."""
        status_code = cast(int | None, response.status_code)
        if status_code is not None and status_code >= 400:
            try:
                error_data = response.json()
                detail = error_data.get("detail", response.text)
            except Exception:
                content_type = response.headers.get("content-type", "")
                if "html" in content_type.lower():
                    detail = (
                        f"Non-API response (HTML) from {response.url}. "
                        "This usually means the URL is not pointing at a Docent API server. "
                        "The API is typically at api.<domain>."
                    )
                else:
                    text = response.text
                    if len(text) > 500:
                        detail = text[:500] + f"... ({len(text)} chars total, truncated)"
                    else:
                        detail = text

            raise requests.HTTPError(f"HTTP {response.status_code}: {detail}", response=response)

    def _post_with_retry(
        self,
        url: str,
        max_retries: int = 3,
        backoff_factor: float = 1.0,
        **kwargs: Any,
    ) -> requests.Response:
        """POST with retries on 5xx errors."""
        last_response: requests.Response | None = None
        for attempt in range(max_retries + 1):
            last_response = self._session.post(url, **kwargs)
            if last_response.status_code < 500 or attempt == max_retries:
                return last_response
            wait = backoff_factor * (2**attempt)
            self._logger.warning(
                "Server error %s on POST %s, retrying in %.1fs (attempt %s/%s)",
                last_response.status_code,
                url,
                wait,
                attempt + 1,
                max_retries,
            )
            time.sleep(wait)
        assert last_response is not None
        return last_response

    def _login(self, api_key: str):
        """Login with email/password to establish session."""
        self._session.headers.update({"Authorization": f"Bearer {api_key}"})
        self._logger.info(
            "Authenticating Docent client with frontend_url='%s' and api_url='%s'",
            self._frontend_url,
            self._api_url,
        )

        url = f"{self._api_url}/api-keys/test"
        response = self._session.get(url)
        self._handle_response_errors(response)

        self._logger.info("Logged in with API key")
        return
