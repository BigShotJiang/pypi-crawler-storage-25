"""Feedback sessions and rubric optimization jobs."""

from __future__ import annotations

from typing import Any

from docent.data_models.feedback import (
    FeedbackRoundJobStateResponse,
    FeedbackRubricOptimizationJobStateResponse,
    FeedbackSession,
    FeedbackSurveyOptions,
    StartFeedbackRoundJobResponse,
    StartFeedbackRubricOptimizationJobResponse,
)
from docent.sdk._base import DocentBase


class DocentFeedbackMixin(DocentBase):
    """Feedback API wrappers."""

    def create_feedback_session(
        self,
        collection_id: str,
        reading_preset_id: str,
        reading_preset_version: int,
        dql_query: str,
        survey_options: FeedbackSurveyOptions | dict[str, Any] | None = None,
    ) -> str:
        """Create a feedback session for a pinned reading preset version and DQL query."""
        url = f"{self._api_url}/feedback/{collection_id}/session"
        payload: dict[str, Any] = {
            "reading_preset_id": reading_preset_id,
            "reading_preset_version": reading_preset_version,
            "dql_query": dql_query,
        }
        if survey_options is not None:
            payload["survey_options"] = (
                survey_options.model_dump(mode="json")
                if isinstance(survey_options, FeedbackSurveyOptions)
                else survey_options
            )
        response = self._session.post(url, json=payload)
        self._handle_response_errors(response)
        return response.json()["feedback_session_id"]

    def get_feedback_session(
        self,
        collection_id: str,
        feedback_session_id: str,
    ) -> FeedbackSession:
        """Get feedback-session metadata for a persisted feedback session."""
        url = f"{self._api_url}/feedback/{collection_id}/session/{feedback_session_id}"
        response = self._session.get(url)
        self._handle_response_errors(response)
        return FeedbackSession.model_validate(response.json())

    def start_feedback_round_job(
        self,
        collection_id: str,
        feedback_session_id: str,
        num_samples: int = 50,
        num_high_level_questions: int = 20,
        num_targets_per_high_level_question: int = 1,
        max_cruxes_per_target: int = 5,
        seed: int = 0,
        increment_round: bool = False,
    ) -> StartFeedbackRoundJobResponse:
        """Start or reuse a background job to compute the active feedback round for a session."""
        payload = {
            "feedback_session_id": feedback_session_id,
            "num_samples": num_samples,
            "num_high_level_questions": num_high_level_questions,
            "num_targets_per_high_level_question": num_targets_per_high_level_question,
            "max_cruxes_per_target": max_cruxes_per_target,
            "seed": seed,
            "increment_round": increment_round,
        }
        url = f"{self._api_url}/feedback/{collection_id}/rounds/start"
        response = self._session.post(url, json=payload)
        self._handle_response_errors(response)
        return StartFeedbackRoundJobResponse.model_validate(response.json())

    def get_feedback_round_state(
        self,
        collection_id: str,
        feedback_session_id: str,
    ) -> FeedbackRoundJobStateResponse:
        """Get feedback round state for a session, including job status and active round data."""
        payload = {
            "feedback_session_id": feedback_session_id,
        }
        url = f"{self._api_url}/feedback/{collection_id}/rounds/state"
        response = self._session.post(url, json=payload)
        self._handle_response_errors(response)
        return FeedbackRoundJobStateResponse.model_validate(response.json())

    def start_feedback_rubric_optimization_job(
        self,
        collection_id: str,
        feedback_session_id: str,
        train_ratio: float = 0.8,
        seed: int = 0,
        population_size: int = 3,
        offspring_per_rubric: int = 3,
        num_rounds: int = 1,
    ) -> StartFeedbackRubricOptimizationJobResponse:
        """Start or reuse a background job to optimize a rubric from feedback-session data."""
        payload = {
            "feedback_session_id": feedback_session_id,
            "train_ratio": train_ratio,
            "seed": seed,
            "population_size": population_size,
            "offspring_per_rubric": offspring_per_rubric,
            "num_rounds": num_rounds,
        }
        url = f"{self._api_url}/feedback/{collection_id}/rubric-optimization/start"
        response = self._session.post(url, json=payload)
        self._handle_response_errors(response)
        return StartFeedbackRubricOptimizationJobResponse.model_validate(response.json())

    def get_feedback_rubric_optimization_state(
        self,
        collection_id: str,
        feedback_session_id: str,
    ) -> FeedbackRubricOptimizationJobStateResponse:
        """Get feedback rubric optimization job state and the completed result payload."""
        payload = {
            "feedback_session_id": feedback_session_id,
        }
        url = f"{self._api_url}/feedback/{collection_id}/rubric-optimization/state"
        response = self._session.post(url, json=payload)
        self._handle_response_errors(response)
        return FeedbackRubricOptimizationJobStateResponse.model_validate(response.json())

    def upsert_feedback_question_answer(
        self,
        collection_id: str,
        question_id: str,
        answer: str,
        explanation: str | None = None,
    ) -> None:
        """Create, update, or remove an answer for a feedback question."""
        payload = {
            "question_id": question_id,
            "answer": answer,
            "explanation": explanation,
        }
        url = f"{self._api_url}/feedback/{collection_id}/question-answer"
        response = self._session.put(url, json=payload)
        self._handle_response_errors(response)

    def upsert_crux_basis_answer(
        self,
        collection_id: str,
        question_id: str,
        basis_direction_key: str,
        selected_direction: str,
        strength: str | None = None,
        explanation: str | None = None,
    ) -> None:
        """Create or update a structured basis answer for a run-specific crux."""
        payload = {
            "question_id": question_id,
            "basis_direction_key": basis_direction_key,
            "selected_direction": selected_direction,
            "strength": strength,
            "explanation": explanation,
        }
        url = f"{self._api_url}/feedback/{collection_id}/crux-basis-answer"
        response = self._session.put(url, json=payload)
        self._handle_response_errors(response)

    def upsert_feedback_label(
        self,
        collection_id: str,
        feedback_session_id: str,
        target_key_hash: str,
        label_value: dict[str, Any],
        explanation: str | None = None,
    ) -> None:
        """Create or update a label for one requested feedback target."""
        payload = {
            "feedback_session_id": feedback_session_id,
            "target_key_hash": target_key_hash,
            "label_value": label_value,
            "explanation": explanation,
        }
        url = f"{self._api_url}/feedback/{collection_id}/label"
        response = self._session.put(url, json=payload)
        self._handle_response_errors(response)
