"""Legacy result-set submission and dataframe export."""

from __future__ import annotations

import webbrowser
from typing import Any, Literal, cast

import pandas as pd

from docent._llm_util.providers.preference_types import ModelOption
from docent.sdk._base import DocentBase
from docent.sdk.llm_request import ExternalAnalysisResult, LLMRequest


class DocentResultsMixin(DocentBase):
    """Result-set API (deprecated in favor of readings)."""

    def submit_llm_requests(
        self,
        collection_id: str,
        requests: list[LLMRequest],
        result_set_name: str | None = None,
        exists_ok: bool = False,
        model_string: str | None = None,
        reasoning_effort: Literal["minimal", "low", "medium", "high"] | None = None,
        output_schema: dict[str, Any] | None = None,
        max_concurrency: int | None = None,
    ) -> dict[str, Any]:
        """
        Deprecated - use readings instead.

        Submit LLM requests for processing.

        Creates a result set and submits requests for background LLM processing.
        Prints the result set URL and returns submission details.

        Args:
            collection_id: ID of the Collection.
            requests: List of LLMRequest objects to process.
            result_set_name: Optional name for the result set. Uses hierarchical
                naming convention (e.g., "analysis/v1/clusters").
            exists_ok: If True, append to existing result set with same name.
                If False (default), raise error if name already exists.
            model_string: Optional model override in the form "<provider>/<model_name>".
            reasoning_effort: Optional reasoning effort hint passed to the provider, if supported.
            output_schema: JSON schema for LLM output. Defaults to simple string with citations.
                For structured output, provide an object schema with properties.
            max_concurrency: Optional maximum number of concurrent LLM calls for this job.
                If not set, the server default is used.

        Returns:
            dict containing:
                - result_set_id: UUID of the result set
                - job_id: UUID of the processing job
                - url: Frontend URL to view results

        Raises:
            ValueError: If requests list is empty.
            requests.exceptions.HTTPError: If the API request fails.

        Example:
            ```python
            from docent.sdk import Docent
            from docent.sdk.llm_request import LLMRequest
            from docent.sdk.llm_context import Prompt, AgentRunRef

            client = Docent()
            run = AgentRunRef(id="run_id", collection_id=collection_id)

            requests = [
                LLMRequest(prompt=Prompt([run, "Analyze this trace..."]))
            ]

            result = client.submit_llm_requests(
                collection_id,
                requests,
                result_set_name="analysis/experiment_1",
            )
            print(f"View results at: {result['url']}")
            ```
        """
        if not requests:
            raise ValueError("requests must be a non-empty list")

        # Use name or generate placeholder
        id_or_name = result_set_name or "unnamed"

        url = f"{self._api_url}/results/{collection_id}/submit/{id_or_name}"
        analysis_model: dict[str, Any] | None = None
        if model_string is not None:
            if "/" not in model_string:
                raise ValueError("model_string must be in the form '<provider>/<model_name>'")
            provider, model_name = model_string.split("/", 1)
            analysis_model = ModelOption(
                provider=provider,
                model_name=model_name,
                reasoning_effort=reasoning_effort,
            ).model_dump()

        payload: dict[str, Any] = {
            "requests": [r.model_dump() for r in requests],
            "exists_ok": exists_ok,
            "analysis_model": analysis_model,
        }
        if output_schema is not None:
            payload["output_schema"] = output_schema
        if max_concurrency is not None:
            payload["max_concurrency"] = max_concurrency

        response = self._session.post(url, json=payload)
        self._handle_response_errors(response)

        result = response.json()
        full_url = f"{self._frontend_url}{result['url']}"

        self._logger.info("Submitted %s LLM requests to result set", len(requests))
        print(f"Result set ID: {result['result_set_id']}")
        print(f"View results at: {full_url}")

        return {
            "result_set_id": result["result_set_id"],
            "job_id": result.get("job_id"),
            "url": full_url,
        }

    def submit_results(
        self,
        collection_id: str,
        results: list[ExternalAnalysisResult],
        result_set_name: str | None = None,
        exists_ok: bool = False,
    ) -> dict[str, Any]:
        """
        Deprecated.

        Submit pre-computed results directly.

        For use when you've run analysis locally (e.g., with a local LLM)
        and want to upload the results to Docent for viewing.

        Args:
            collection_id: ID of the Collection.
            results: List of ExternalAnalysisResult objects to upload.
            result_set_name: Optional name for the result set.
            exists_ok: If True, append to existing result set with same name.

        Returns:
            dict containing:
                - result_set_id: UUID of the result set
                - url: Frontend URL to view results

        Raises:
            ValueError: If results list is empty.
            requests.exceptions.HTTPError: If the API request fails.
        """
        if not results:
            raise ValueError("results must be a non-empty list")

        id_or_name = result_set_name or "unnamed"

        url = f"{self._api_url}/results/{collection_id}/submit/{id_or_name}"
        payload = {
            "results": [r.model_dump() for r in results],
            "exists_ok": exists_ok,
        }

        response = self._session.post(url, json=payload)
        self._handle_response_errors(response)

        result = response.json()
        full_url = f"{self._frontend_url}{result['url']}"

        self._logger.info("Submitted %s results to result set", len(results))
        print(f"Result set ID: {result['result_set_id']}")
        print(f"View results at: {full_url}")

        return {
            "result_set_id": result["result_set_id"],
            "url": full_url,
        }

    def get_result_set(
        self,
        collection_id: str,
        name_or_id: str,
    ) -> dict[str, Any]:
        """
        Deprecated - use readings instead.

        Get a result set by name or ID.

        Args:
            collection_id: ID of the Collection.
            name_or_id: Name or UUID of the result set.

        Returns:
            dict containing result set metadata (id, name, output_schema, created_at,
            result_count, first_prompt_preview).

        Raises:
            requests.exceptions.HTTPError: If the result set is not found or API fails.
        """
        url = f"{self._api_url}/results/{collection_id}/result-sets/{name_or_id}"
        response = self._session.get(url)
        self._handle_response_errors(response)
        return response.json()

    def get_result_set_dataframe(
        self,
        collection_id: str,
        name_or_id: str,
        with_auto_joins: bool = False,
        include_incomplete: bool = False,
    ) -> "pd.DataFrame":
        """
        Deprecated - use readings instead.

        Get result set contents as a pandas DataFrame.

        Args:
            collection_id: ID of the Collection.
            name_or_id: Name or UUID of the result set.
            with_auto_joins: If True, automatically join related data for columns
                ending in _result_id or _run_id.
            include_incomplete: If False (default), only return successful results.
                If True, also include in-progress and errored results.

        Returns:
            pd.DataFrame: DataFrame containing results with flattened columns.
                Nested dicts in user_metadata, output, and joined are expanded
                into prefixed columns (e.g., user_metadata.field, output.score).

        Raises:
            requests.exceptions.HTTPError: If the result set is not found or API fails.
        """
        url = f"{self._api_url}/results/{collection_id}/results/{name_or_id}"
        params = {"with_auto_joins": with_auto_joins, "include_incomplete": include_incomplete}
        response = self._session.get(url, params=params)
        self._handle_response_errors(response)

        results: list[dict[str, Any]] = response.json()

        flattened_results: list[dict[str, Any]] = []
        for result in results:
            flat: dict[str, Any] = {}
            for key, value in result.items():
                if key == "user_metadata" and isinstance(value, dict):
                    nested = cast(dict[str, Any], value)
                    for sub_key, sub_value in nested.items():
                        flat[f"user_metadata.{sub_key}"] = sub_value
                elif key == "output" and isinstance(value, dict):
                    nested = cast(dict[str, Any], value)
                    for sub_key, sub_value in nested.items():
                        flat[f"output.{sub_key}"] = sub_value
                elif key == "joined" and isinstance(value, dict):
                    joined = cast(dict[str, Any], value)
                    for prefix, joined_data in joined.items():
                        if isinstance(joined_data, dict):
                            joined_nested = cast(dict[str, Any], joined_data)
                            for sub_key, sub_value in joined_nested.items():
                                flat[f"joined.{prefix}.{sub_key}"] = sub_value
                else:
                    flat[key] = value
            flattened_results.append(flat)

        return pd.DataFrame(flattened_results)

    def list_result_sets(
        self,
        collection_id: str,
        prefix: str | None = None,
    ) -> list[dict[str, Any]]:
        """List result sets in a collection.

        Args:
            collection_id: ID of the Collection.
            prefix: Optional name prefix to filter result sets (e.g., "analysis/v1").

        Returns:
            list of result set metadata dictionaries, sorted by most recent first.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        url = f"{self._api_url}/results/{collection_id}/result-sets"
        params = {"prefix": prefix} if prefix else None
        response = self._session.get(url, params=params)
        self._handle_response_errors(response)
        return response.json()

    def open_result_set(
        self,
        collection_id: str,
        name_or_id: str,
    ) -> str:
        """
        Deprecated - use readings instead.

        Open a result set in the browser.

        Args:
            collection_id: ID of the Collection.
            name_or_id: Name or UUID of the result set.

        Returns:
            str: The URL that was opened.
        """
        url = self._collection_dashboard_url(collection_id, f"results/{name_or_id}")
        self._logger.info("Opening result set in browser: %s", url)
        webbrowser.open(url)
        return url
