"""DQL execution, agent-run listing, ingest helpers, and trace deep links."""

from __future__ import annotations

import webbrowser
from pathlib import Path
from typing import Any, Literal

import pandas as pd
from tqdm import tqdm

from docent.loaders import load_inspect
from docent.sdk._base import DocentBase
from docent.sdk._client_util import batched


class DocentDqlMixin(DocentBase):
    """Query and agent-run maintenance helpers."""

    def get_dql_schema(self, collection_id: str) -> dict[str, Any]:
        """Retrieve the DQL schema for a collection.

        Args:
            collection_id: ID of the Collection.

        Returns:
            dict: Dictionary containing available tables, columns, and metadata for DQL queries.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        url = f"{self._api_url}/dql/{collection_id}/schema"
        response = self._session.get(url)
        self._handle_response_errors(response)
        return response.json()

    def execute_dql(
        self,
        collection_id: str,
        dql: str,
        *,
        reading_plan_id: str | None = None,
        source: Literal["endpoint", "mcp"] = "endpoint",
    ) -> dict[str, Any]:
        """Execute a DQL query against a collection.

        Args:
            collection_id: ID of the Collection.
            dql: The DQL query string to execute.
            reading_plan_id: Optional reading plan ID for $alias substitution
                in queries that reference reading step aliases.
            source: Analytics source for the execution path.

        Returns:
            dict: Query execution results including rows, columns, execution metadata, and selected columns.

        Raises:
            ValueError: If `dql` is empty.
            requests.exceptions.HTTPError: If the API request fails or the query is invalid.
        """
        if not dql.strip():
            raise ValueError("dql must be a non-empty string")

        url = f"{self._api_url}/dql/{collection_id}/execute"
        body: dict[str, Any] = {"dql": dql, "source": source}
        if reading_plan_id is not None:
            body["reading_plan_id"] = reading_plan_id
        response = self._session.post(url, json=body)
        self._handle_response_errors(response)
        return response.json()

    def dql_result_to_dicts(self, dql_result: dict[str, Any]) -> list[dict[str, Any]]:
        """Convert a DQL result to a list of dictionaries."""
        cols = dql_result["columns"]
        rows = dql_result["rows"]
        return [dict(zip(cols, row)) for row in rows]

    def dql_result_to_df_experimental(self, dql_result: dict[str, Any]):
        """The implementation is not stable by any means!"""

        cols = dql_result["columns"]
        rows = dql_result["rows"]

        def _cast_value(v: Any) -> Any:
            """Cast a value to int, float, bool, or str as appropriate."""
            if v is None:
                return None
            if isinstance(v, (bool, int, float)):
                return v

            # If a string, try to cast into a number
            if isinstance(v, str):
                try:
                    if "." not in v:
                        return int(v)
                except (ValueError, TypeError):
                    pass

                try:
                    return float(v)
                except (ValueError, TypeError):
                    pass

            # Keep as original
            return v

        dicts: list[dict[str, Any]] = []
        for row in rows:
            combo = list(zip(cols, row))
            combo = {k: _cast_value(v) for k, v in combo}
            dicts.append(combo)

        return pd.DataFrame(dicts)

    def select_agent_run_ids(
        self,
        collection_id: str,
        where_clause: str | None = None,
        limit: int | None = None,
    ) -> list[str]:
        """Convenience helper to fetch agent run IDs via DQL.

        Args:
            collection_id: ID of the Collection to query.
            where_clause: Optional DQL WHERE clause applied to the agent_runs table.
            limit: Optional LIMIT applied to the underlying DQL query.

        Returns:
            list[str]: Agent run IDs matching the criteria.

        Raises:
            ValueError: If the inputs are invalid.
            requests.exceptions.HTTPError: If the API request fails.
        """
        query = "SELECT agent_runs.id AS agent_run_id FROM agent_runs"

        if where_clause:
            where_clause = where_clause.strip()
            if not where_clause:
                raise ValueError("where_clause must be a non-empty string when provided")
            query += f" WHERE {where_clause}"

        if limit is not None:
            if limit <= 0:
                raise ValueError("limit must be a positive integer when provided")
            query += f" LIMIT {limit}"

        result = self.execute_dql(collection_id, query)
        rows = result.get("rows", [])
        agent_run_ids = [str(row[0]) for row in rows if row]

        if result.get("truncated"):
            self._logger.warning(
                "DQL query truncated at applied limit %s; returning %s agent run IDs",
                result.get("applied_limit"),
                len(agent_run_ids),
            )

        return agent_run_ids

    def list_agent_run_ids(
        self,
        collection_id: str,
        *,
        apply_base_filter: bool = False,
    ) -> list[str]:
        """Get all agent run IDs for a collection.

        Args:
            collection_id: ID of the Collection.
            apply_base_filter: Deprecated. View base filters are no longer applied implicitly.

        Returns:
            list[str]: Agent run IDs for the collection.

        Raises:
            ValueError: If apply_base_filter is True.
            requests.exceptions.HTTPError: If the API request fails.
        """
        if apply_base_filter:
            raise ValueError(
                "apply_base_filter=True is no longer sufficient because view base filters are no "
                "longer part of agent-run browsing. Pass an explicit filter to the query endpoint "
                "instead."
            )

        url = f"{self._api_url}/{collection_id}/agent_run_ids/query"
        response = self._session.post(url, json={})
        self._handle_response_errors(response)
        return response.json()

    def delete_agent_runs(self, collection_id: str, agent_run_ids: list[str]) -> int:
        """Delete agent runs from a collection.

        Args:
            collection_id: ID of the Collection.
            agent_run_ids: List of agent run IDs to delete.

        Returns:
            int: Number of agent runs deleted.

        Raises:
            ValueError: If agent_run_ids is empty.
            requests.exceptions.HTTPError: If the API request fails.
        """
        if not agent_run_ids:
            raise ValueError("agent_run_ids must contain at least one entry")

        url = f"{self._api_url}/{collection_id}/agent_runs"
        response = self._session.delete(url, json={"agent_run_ids": agent_run_ids})
        self._handle_response_errors(response)
        deleted_count: int = response.json()["deleted_count"]
        return deleted_count

    def recursively_ingest_inspect_logs(self, collection_id: str, fpath: str):
        """Recursively search directory for .eval files and ingest them as agent runs.

        Args:
            collection_id: ID of the Collection to add agent runs to.
            fpath: Path to directory to search recursively.

        Raises:
            ValueError: If the path doesn't exist or isn't a directory.
            requests.exceptions.HTTPError: If any API requests fail.
        """
        root_path = Path(fpath)
        if not root_path.exists():
            raise ValueError(f"Path does not exist: {fpath}")
        if not root_path.is_dir():
            raise ValueError(f"Path is not a directory: {fpath}")

        # Find all .eval files recursively
        eval_files = list(root_path.rglob("*.eval"))

        if not eval_files:
            self._logger.info("No .eval files found in %s", fpath)
            return

        self._logger.info("Found %s .eval files in %s", len(eval_files), fpath)

        total_runs_added = 0
        batch_size = 100

        # Process each .eval file
        for eval_file in tqdm(eval_files, desc="Processing .eval files", unit="files"):
            # Get total samples for progress tracking
            total_samples = load_inspect.get_total_samples(eval_file, format="eval")

            if total_samples == 0:
                self._logger.info("No samples found in %s", eval_file)
                continue

            # Load runs from file
            with open(eval_file, "rb") as f:
                _, runs_generator = load_inspect.runs_from_file(f, format="eval")

                # Process runs in batches
                runs_from_file = 0
                batches = batched(runs_generator, batch_size)

                with tqdm(
                    total=total_samples,
                    desc=f"Processing {eval_file.name}",
                    unit="runs",
                    leave=False,
                ) as file_pbar:
                    for batch in batches:
                        batch_list = list(batch)  # Convert generator batch to list
                        if not batch_list:
                            break

                        # Add batch to collection
                        url = f"{self._api_url}/{collection_id}/agent_runs"
                        payload = {"agent_runs": [ar.model_dump(mode="json") for ar in batch_list]}

                        response = self._session.post(url, json=payload)
                        self._handle_response_errors(response)

                        runs_from_file += len(batch_list)
                        file_pbar.update(len(batch_list))

            total_runs_added += runs_from_file
            self._logger.info("Added %s runs from %s", runs_from_file, eval_file)

        self._logger.info(
            "Successfully ingested %s total agent runs from %s files",
            total_runs_added,
            len(eval_files),
        )

    def open_agent_run(self, collection_id: str, agent_run_id: str) -> str:
        """Open an agent run in the browser.

        Args:
            collection_id: ID of the Collection containing the agent run.
            agent_run_id: ID of the agent run to open.

        Returns:
            str: The URL that was opened.

        Example:
            ```python
            from docent.sdk import Docent

            client = Docent()
            client.open_agent_run(collection_id, agent_run_id)
            # Opens browser to agent run page
            ```
        """
        agent_run_url = self._collection_dashboard_url(collection_id, f"agent_run/{agent_run_id}")
        self._logger.info("Opening agent run in browser: %s", agent_run_url)

        webbrowser.open(agent_run_url)

        return agent_run_url
