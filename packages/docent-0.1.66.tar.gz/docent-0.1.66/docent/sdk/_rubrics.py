"""Rubrics, judges, clustering, and rubric deep links."""

from __future__ import annotations

import webbrowser
from typing import TYPE_CHECKING, Any

from docent.sdk._base import DocentBase

if TYPE_CHECKING:
    from docent.judges.impl import BaseJudge
    from docent.judges.types import Rubric


class DocentRubricsMixin(DocentBase):
    """Rubric and judge helpers."""

    def list_rubrics(self, collection_id: str) -> list[dict[str, Any]]:
        """List all rubrics for a given collection.

        Args:
            collection_id: ID of the Collection.

        Returns:
            list: List of dictionaries containing rubric information.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        url = f"{self._api_url}/rubric/{collection_id}/rubrics"
        response = self._session.get(url)
        self._handle_response_errors(response)
        return response.json()

    def create_rubric(
        self,
        collection_id: str,
        rubric: "Rubric",
    ) -> str:
        """Create a new rubric in a collection.

        Args:
            collection_id: ID of the Collection.
            rubric: The Rubric configuration to create. Must have version=1.

        Returns:
            str: The ID of the created rubric.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
            ValueError: If rubric.version != 1.

        Example:
            >>> from docent.sdk import Docent, Rubric
            >>> client = Docent(api_key="...")
            >>> rubric = Rubric(
            ...     rubric_text="Judge whether the agent completed the task...",
            ...     output_schema={
            ...         "type": "object",
            ...         "properties": {
            ...             "label": {"type": "string", "enum": ["pass", "fail"]},
            ...             "explanation": {"type": "string"},
            ...         },
            ...         "required": ["label", "explanation"],
            ...     },
            ... )
            >>> rubric_id = client.create_rubric(collection_id, rubric)
        """
        url = f"{self._api_url}/rubric/{collection_id}/rubric"
        payload = {"rubric": rubric.model_dump(mode="json")}
        response = self._session.post(url, json=payload)
        self._handle_response_errors(response)
        return response.json()

    def get_rubric(
        self,
        collection_id: str,
        rubric_id: str,
        version: int | None = None,
    ) -> "Rubric":
        """Get a rubric configuration by ID.

        Args:
            collection_id: ID of the Collection.
            rubric_id: ID of the rubric to retrieve.
            version: Optional version number. If None, returns latest version.

        Returns:
            Rubric: The rubric configuration object.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        from docent.judges.types import Rubric

        url = f"{self._api_url}/rubric/{collection_id}/rubric/{rubric_id}"
        params = {"version": version} if version is not None else None
        response = self._session.get(url, params=params)
        self._handle_response_errors(response)
        return Rubric.model_validate(response.json())

    def get_judge(
        self,
        collection_id: str,
        rubric_id: str,
        version: int | None = None,
    ) -> "BaseJudge":
        """Get a ready-to-use judge by rubric ID.

        Downloads the rubric configuration and creates a callable judge.
        API keys are read from environment variables (OPENAI_API_KEY,
        ANTHROPIC_API_KEY, etc.) based on the rubric's configured provider.

        Args:
            collection_id: ID of the Collection.
            rubric_id: ID of the rubric/judge to retrieve.
            version: Optional version number. If None, returns latest version.

        Returns:
            BaseJudge: A callable judge. Use `await judge(agent_run)` to run.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.

        Example:
            >>> judge = client.get_judge(collection_id, rubric_id)
            >>> # Inspect the config
            >>> print(judge.cfg.rubric_text)
            >>> # Run locally (async)
            >>> result = await judge(agent_run)
        """
        from docent._llm_util.llm_svc import BaseLLMService
        from docent.judges.impl import build_judge

        rubric = self.get_rubric(collection_id, rubric_id, version)
        llm_svc = BaseLLMService()  # reads API keys from environment
        return build_judge(rubric, llm_svc)

    def start_rubric_eval_job(
        self,
        collection_id: str,
        rubric_id: str,
        max_agent_runs: int | None = None,
        n_rollouts_per_input: int = 1,
        max_parallel: int | None = None,
        include_metadata: bool = True,
    ) -> str:
        """Start or reuse a rubric evaluation job.

        Args:
            collection_id: ID of the Collection.
            rubric_id: The ID of the rubric to evaluate.
            max_agent_runs: Optional limit on the number of agent runs to evaluate.
            n_rollouts_per_input: Number of judge rollouts to generate per agent run.
            max_parallel: Optional backend concurrency override for the evaluation job.
            include_metadata: Whether the judge prompt should include metadata.

        Returns:
            str: The ID of the created or reused job.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
            ValueError: If the response does not contain a job ID.
        """
        url = f"{self._api_url}/rubric/{collection_id}/{rubric_id}/evaluate"
        payload = {
            "max_agent_runs": max_agent_runs,
            "n_rollouts_per_input": n_rollouts_per_input,
            "max_parallel": max_parallel,
            "include_metadata": include_metadata,
        }
        response = self._session.post(url, json=payload)
        self._handle_response_errors(response)

        job_id = response.json().get("job_id")
        if job_id is None:
            raise ValueError("Failed to start rubric eval job: 'job_id' missing in response.")
        return job_id

    def get_rubric_run_state(
        self,
        collection_id: str,
        rubric_id: str,
        version: int | None = None,
        filter_dict: dict[str, Any] | None = None,
        include_failures: bool = False,
    ) -> dict[str, Any]:
        """Get rubric evaluation results and progress for a collection/rubric.

        Args:
            collection_id: ID of the Collection.
            rubric_id: The ID of the rubric to get run state for.
            version: The version of the rubric to get run state for. If None, the latest version is used.
            filter_dict: Optional filter dictionary to apply to the results.
            include_failures: Whether to include failed results in the response.

        Returns:
            dict: Dictionary containing rubric run state with results, job_id, and total_results_needed.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.

        Note:
            This method does not start evaluation. Use `start_rubric_eval_job()` to
            enqueue or reuse a rubric evaluation job.
        """
        url = f"{self._api_url}/rubric/{collection_id}/{rubric_id}/rubric_run_state"
        body = {
            "filter_dict": filter_dict,
            "include_failures": include_failures,
        }
        params: dict[str, Any] = {}
        if version is not None:
            params["version"] = version
        response = self._session.post(url, json=body, params=params)
        self._handle_response_errors(response)
        return response.json()

    def get_clustering_state(self, collection_id: str, rubric_id: str) -> dict[str, Any]:
        """Get clustering state for a given collection and rubric.

        Args:
            collection_id: ID of the Collection.
            rubric_id: The ID of the rubric to get clustering state for.

        Returns:
            dict: Dictionary containing job_id, centroids, and assignments.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        url = f"{self._api_url}/rubric/{collection_id}/{rubric_id}/clustering_job"
        response = self._session.get(url)
        self._handle_response_errors(response)
        return response.json()

    def get_cluster_centroids(self, collection_id: str, rubric_id: str) -> list[dict[str, Any]]:
        """Get centroids for a given collection and rubric.

        Args:
            collection_id: ID of the Collection.
            rubric_id: The ID of the rubric to get centroids for.

        Returns:
            list: List of dictionaries containing centroid information.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        clustering_state = self.get_clustering_state(collection_id, rubric_id)
        return clustering_state.get("centroids", [])

    def get_cluster_assignments(self, collection_id: str, rubric_id: str) -> dict[str, list[str]]:
        """Get centroid assignments for a given rubric.

        Args:
            collection_id: ID of the Collection.
            rubric_id: The ID of the rubric to get assignments for.

        Returns:
            dict: Dictionary mapping centroid IDs to lists of judge result IDs.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        clustering_state = self.get_clustering_state(collection_id, rubric_id)
        return clustering_state.get("assignments", {})

    def open_rubric(
        self,
        collection_id: str,
        rubric_id: str,
        agent_run_id: str | None = None,
        judge_result_id: str | None = None,
    ) -> str:
        """Open a rubric, agent run, or judge result in the browser.

        Args:
            collection_id: ID of the Collection.
            rubric_id: ID of the rubric.
            agent_run_id: Optional ID of the agent run to view within the rubric.
            judge_result_id: Optional ID of the judge result to view. Requires agent_run_id.

        Returns:
            str: The URL that was opened.

        Raises:
            ValueError: If judge_result_id is provided without agent_run_id.

        Example:
            ```python
            from docent.sdk import Docent

            client = Docent()
            # Open rubric overview
            client.open_rubric(collection_id, rubric_id)
            # Open specific agent run within rubric
            client.open_rubric(collection_id, rubric_id, agent_run_id)
            # Open specific judge result
            client.open_rubric(collection_id, rubric_id, agent_run_id, judge_result_id)
            ```
        """
        if judge_result_id is not None and agent_run_id is None:
            raise ValueError("judge_result_id requires agent_run_id to be specified")

        url = self._collection_dashboard_url(collection_id, f"rubric/{rubric_id}")
        if agent_run_id is not None:
            url = self._collection_dashboard_url(
                collection_id, f"rubric/{rubric_id}/agent_run/{agent_run_id}"
            )
        if judge_result_id is not None:
            url = self._collection_dashboard_url(
                collection_id,
                f"rubric/{rubric_id}/agent_run/{agent_run_id}/result/{judge_result_id}",
            )

        self._logger.info("Opening rubric in browser: %s", url)
        webbrowser.open(url)

        return url
