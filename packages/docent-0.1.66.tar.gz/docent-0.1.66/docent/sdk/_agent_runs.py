"""Agent run fetch, metadata, transcript groups, and chat sessions."""

from __future__ import annotations

from typing import Any

from docent.data_models.agent_run import AgentRun
from docent.sdk._base import DocentBase


class DocentAgentRunsMixin(DocentBase):
    """Agent run and transcript-group operations."""

    def get_agent_run(self, collection_id: str, agent_run_id: str) -> AgentRun | None:
        """Get a specific agent run by its ID.

        Args:
            collection_id: ID of the Collection.
            agent_run_id: The ID of the agent run to retrieve.

        Returns:
            dict: Dictionary containing the agent run information.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        url = f"{self._api_url}/{collection_id}/agent_run"
        response = self._session.get(url, params={"agent_run_id": agent_run_id})
        self._handle_response_errors(response)
        if response.json() is None:
            return None
        else:
            # We do this to avoid metadata validation failing
            # TODO(mengk): kinda hacky
            return AgentRun.model_validate(response.json())

    def update_agent_run_metadata(
        self,
        collection_id: str,
        agent_run_id: str,
        metadata: dict[str, Any],
    ) -> dict[str, Any]:
        """Merge metadata into an agent run's existing metadata.

        Uses a deep merge: nested dictionaries are merged recursively so
        existing keys are preserved, while non-dict values are overwritten.
        Keys not present in ``metadata`` are left unchanged.

        Requires WRITE permission on the collection.

        Args:
            collection_id: ID of the Collection containing the agent run.
            agent_run_id: ID of the agent run to update.
            metadata: Dictionary of metadata fields to merge.

        Returns:
            The full merged metadata dictionary after the update.

        Raises:
            requests.exceptions.HTTPError: If the API request fails (e.g., 404 if the agent run is not found).
        """
        url = f"{self._server_url}/{collection_id}/agent_run/{agent_run_id}/metadata"
        response = self._session.put(url, json={"metadata": metadata})
        self._handle_response_errors(response)
        data: dict[str, Any] = response.json()
        return data

    def delete_agent_run_metadata_keys(
        self,
        collection_id: str,
        agent_run_id: str,
        keys: list[str],
    ) -> tuple[dict[str, Any], list[str]]:
        """Remove keys from an agent run's metadata.

        Supports dot-delimited paths for nested deletion. For example,
        ``"config.model"`` removes the ``model`` key inside ``config``
        without affecting other keys in that dict.

        Requires WRITE permission on the collection.

        Args:
            collection_id: ID of the Collection containing the agent run.
            agent_run_id: ID of the agent run to modify.
            keys: Metadata keys to remove. Use dot-delimited paths for nested
                keys (e.g. ``["top_level_key", "nested.child_key"]``).

        Returns:
            A tuple of (metadata after deletion, list of keys that were not found).

        Raises:
            requests.exceptions.HTTPError: If the API request fails (e.g., 404 if the agent run is not found).
        """
        url = f"{self._server_url}/{collection_id}/agent_run/{agent_run_id}/metadata/delete"
        response = self._session.post(url, json={"keys": keys})
        self._handle_response_errors(response)
        data: dict[str, Any] = response.json()
        metadata: dict[str, Any] = data["metadata"]
        not_found: list[str] = data["not_found"]
        return metadata, not_found

    def get_agent_run_metadata(
        self,
        collection_id: str,
        agent_run_id: str,
    ) -> dict[str, Any]:
        """Get an agent run's metadata.

        Args:
            collection_id: ID of the Collection containing the agent run.
            agent_run_id: ID of the agent run.

        Returns:
            The agent run's metadata dict.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        url = f"{self._server_url}/{collection_id}/agent_run/{agent_run_id}/metadata"
        response = self._session.get(url)
        self._handle_response_errors(response)
        return response.json()

    # ──────────────────────────────────────────
    # Transcript group metadata
    # ──────────────────────────────────────────

    def get_transcript_group_metadata(
        self,
        collection_id: str,
        transcript_group_id: str,
    ) -> dict[str, Any]:
        """Get a transcript group's metadata.

        Args:
            collection_id: ID of the Collection containing the transcript group.
            transcript_group_id: ID of the transcript group.

        Returns:
            The transcript group's metadata dict.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        url = f"{self._server_url}/{collection_id}/transcript_group/{transcript_group_id}/metadata"
        response = self._session.get(url)
        self._handle_response_errors(response)
        return response.json()

    def update_transcript_group_metadata(
        self,
        collection_id: str,
        transcript_group_id: str,
        metadata: dict[str, Any],
    ) -> dict[str, Any]:
        """Deep-merge metadata into a transcript group's existing metadata.

        Args:
            collection_id: ID of the Collection containing the transcript group.
            transcript_group_id: ID of the transcript group.
            metadata: Metadata dict to merge into the existing metadata.

        Returns:
            The full merged metadata dict.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        url = f"{self._server_url}/{collection_id}/transcript_group/{transcript_group_id}/metadata"
        response = self._session.put(url, json={"metadata": metadata})
        self._handle_response_errors(response)
        return response.json()

    def delete_transcript_group_metadata_keys(
        self,
        collection_id: str,
        transcript_group_id: str,
        keys: list[str],
    ) -> tuple[dict[str, Any], list[str]]:
        """Remove keys from a transcript group's metadata.

        Supports dot-delimited paths for nested deletion.

        Args:
            collection_id: ID of the Collection containing the transcript group.
            transcript_group_id: ID of the transcript group.
            keys: Keys to remove. Use dot notation for nested keys.

        Returns:
            Tuple of (metadata after deletion, list of keys that were not found).

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        url = f"{self._server_url}/{collection_id}/transcript_group/{transcript_group_id}/metadata/delete"
        response = self._session.post(url, json={"keys": keys})
        self._handle_response_errors(response)
        data = response.json()
        return data["metadata"], data["not_found"]

    def get_chat_sessions(self, collection_id: str, agent_run_id: str) -> list[dict[str, Any]]:
        """Get all chat sessions for an agent run, excluding judge result sessions.

        Args:
            collection_id: ID of the Collection.
            agent_run_id: The ID of the agent run to retrieve chat sessions for.

        Returns:
            list: List of chat session dictionaries.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        url = f"{self._api_url}/chat/{collection_id}/{agent_run_id}/sessions"
        response = self._session.get(url)
        self._handle_response_errors(response)
        return response.json()
