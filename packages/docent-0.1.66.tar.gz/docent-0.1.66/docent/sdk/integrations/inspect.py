"""Helpers for converting and ingesting Inspect `.eval` logs."""

from __future__ import annotations

from collections.abc import Callable, Iterator
from pathlib import Path

from tqdm import tqdm

from docent._log_util.logger import LoggerAdapter, get_logger
from docent.data_models.agent_run import AgentRun
from docent.loaders import load_inspect
from docent.sdk.integrations.util import (
    require_existing_directory as _require_existing_directory,
)
from docent.sdk.integrations.util import (
    require_existing_file as _require_existing_file,
)
from docent.sdk.util import batched

_LOGGER = get_logger(__name__)


def find_inspect_eval_files(root: str | Path) -> list[Path]:
    """Recursively find Inspect `.eval` files under a root directory."""
    root_path = _require_existing_directory(Path(root), context="Inspect root path")
    return sorted(root_path.rglob("*.eval"))


def convert_inspect_eval_file_to_agent_runs(file_path: str | Path) -> list[AgentRun]:
    """Convert a single Inspect `.eval` archive into AgentRuns.

    Args:
        file_path: Path to an Inspect `.eval` file.

    Returns:
        Parsed Docent `AgentRun` objects for each sample in the archive.

    Raises:
        ValueError: If `file_path` does not exist or is not a file.
    """
    inspect_path = _require_existing_file(Path(file_path), context="Inspect eval file")
    with inspect_path.open("rb") as file:
        _, runs_generator = load_inspect.runs_from_file(file, format="eval")
        return list(runs_generator)


def _iter_inspect_eval_file_agent_runs(file_path: str | Path) -> Iterator[AgentRun]:
    """Yield AgentRuns from a single Inspect `.eval` archive without materializing all runs."""
    inspect_path = _require_existing_file(Path(file_path), context="Inspect eval file")
    with inspect_path.open("rb") as file:
        _, runs_generator = load_inspect.runs_from_file(file, format="eval")
        yield from runs_generator


def convert_inspect_directory_to_agent_runs(root: str | Path) -> list[AgentRun]:
    """Convert every Inspect `.eval` file found under a directory into AgentRuns.

    Args:
        root: Directory to scan recursively for Inspect `.eval` files.

    Returns:
        Parsed Docent `AgentRun` objects for every sample across all discovered
        `.eval` files.

    Raises:
        ValueError: If `root` does not exist or is not a directory.
    """
    agent_runs: list[AgentRun] = []
    for eval_file in find_inspect_eval_files(root):
        agent_runs.extend(convert_inspect_eval_file_to_agent_runs(eval_file))
    return agent_runs


def ingest_inspect_directory(
    collection_id: str,
    fpath: str | Path,
    *,
    upload_agent_run_batch: Callable[[list[AgentRun]], None],
    logger: LoggerAdapter | None = None,
    batch_size: int = 100,
) -> int:
    """Recursively ingest Inspect `.eval` files into a Docent collection.

    Args:
        collection_id: Collection receiving the converted AgentRuns. Used for
            logging; the upload callback is expected to target this collection.
        fpath: Directory to scan recursively for Inspect `.eval` files.
        upload_agent_run_batch: Callback that uploads one batch of parsed
            `AgentRun` objects.
        logger: Optional logger. Defaults to the module logger.
        batch_size: Number of AgentRuns to send per upload callback invocation.

    Returns:
        Total number of AgentRuns uploaded across all discovered `.eval` files.

    Raises:
        ValueError: If `fpath` is invalid or `batch_size` is not positive.
        requests.exceptions.HTTPError: Propagated from the upload callback when
            uploads fail.
    """
    if batch_size <= 0:
        raise ValueError("batch_size must be a positive integer")

    active_logger = logger or _LOGGER
    root_path = _require_existing_directory(Path(fpath), context="Inspect root path")
    eval_files = find_inspect_eval_files(root_path)

    if not eval_files:
        active_logger.info("No .eval files found in %s", root_path)
        return 0

    active_logger.info("Found %s .eval files in %s", len(eval_files), root_path)

    total_runs_added = 0

    for eval_file in tqdm(eval_files, desc="Processing .eval files", unit="files"):
        total_samples = load_inspect.get_total_samples(eval_file, format="eval")

        if total_samples == 0:
            active_logger.info("No samples found in %s", eval_file)
            continue

        runs_from_file = 0
        batches = batched(_iter_inspect_eval_file_agent_runs(eval_file), batch_size)

        with tqdm(
            total=total_samples,
            desc=f"Processing {eval_file.name}",
            unit="runs",
            leave=False,
        ) as file_pbar:
            for batch in batches:
                batch_list = list(batch)

                upload_agent_run_batch(batch_list)

                runs_from_file += len(batch_list)
                file_pbar.update(len(batch_list))

        total_runs_added += runs_from_file
        active_logger.info("Added %s runs from %s", runs_from_file, eval_file)

    active_logger.info(
        "Successfully ingested %s total agent runs into Collection '%s' from %s files",
        total_runs_added,
        collection_id,
        len(eval_files),
    )
    return total_runs_added
