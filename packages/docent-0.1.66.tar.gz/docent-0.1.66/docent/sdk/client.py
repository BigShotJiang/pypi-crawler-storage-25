"""Docent API client (composed from domain mixins)."""

from __future__ import annotations

from docent.sdk import _client_util
from docent.sdk._agent_runs import DocentAgentRunsMixin
from docent.sdk._base import DocentBase
from docent.sdk._collections import DocentCollectionsMixin
from docent.sdk._dql import DocentDqlMixin
from docent.sdk._feedback import DocentFeedbackMixin
from docent.sdk._labels import DocentLabelsMixin
from docent.sdk._readings import DocentReadingsMixin
from docent.sdk._reports import DocentReportsMixin
from docent.sdk._results import DocentResultsMixin
from docent.sdk._rubrics import DocentRubricsMixin
from docent.sdk._sharing import DocentSharingMixin

load_config_file = _client_util.load_config_file
batched = _client_util.batched
MAX_AGENT_RUN_PAYLOAD_BYTES = _client_util.MAX_AGENT_RUN_PAYLOAD_BYTES


class Docent(
    DocentReportsMixin,
    DocentReadingsMixin,
    DocentResultsMixin,
    DocentDqlMixin,
    DocentSharingMixin,
    DocentAgentRunsMixin,
    DocentLabelsMixin,
    DocentFeedbackMixin,
    DocentRubricsMixin,
    DocentCollectionsMixin,
    DocentBase,
):
    """Client for interacting with the Docent API.

    This client provides methods for creating and managing Collections,
    dimensions, agent runs, and filters in the Docent system. It handles
    authentication via API keys and provides a high-level interface for
    logging, querying, and analyzing agent traces.

    Example:
        >>> from docent import Docent
        >>> client = Docent(api_key="your-api-key")
        >>> collection_id = client.create_collection(name="My Collection")
    """
