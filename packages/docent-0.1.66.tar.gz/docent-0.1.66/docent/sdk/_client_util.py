"""Shared helpers for the Docent SDK HTTP client."""

from __future__ import annotations

import json
from itertools import islice
from pathlib import Path
from typing import Iterable, Iterator, TypeVar
from urllib.parse import urlsplit

from dotenv import dotenv_values
from pydantic_core import to_jsonable_python

from docent._log_util.logger import LoggerAdapter
from docent.data_models.agent_run import AgentRun

MAX_AGENT_RUN_PAYLOAD_BYTES = 100 * 1024 * 1024  # 100MB backend limit
_AGENT_RUNS_PAYLOAD_PREFIX = b'{"agent_runs":['
_AGENT_RUNS_PAYLOAD_SUFFIX = b"]}"


_T = TypeVar("_T")
LOCAL_DOMAINS = {"localhost", "127.0.0.1", "0.0.0.0", "::1"}


def batched(iterable: Iterable[_T], n: int) -> Iterator[tuple[_T, ...]]:
    """Backport of itertools.batched for Python <3.12."""
    if n < 1:
        raise ValueError("n must be at least one")
    it = iter(iterable)
    while batch := tuple(islice(it, n)):
        yield batch


def domain_host(domain: str) -> str:
    """Extract normalized host from a domain string, handling optional port and IPv6 brackets."""
    normalized = domain.strip().lower()
    return urlsplit(f"//{normalized}").hostname or normalized


def normalize_or_none(
    value: str | None,
    *,
    strip_trailing_slash: bool = False,
) -> str | None:
    """Return None for missing/empty strings, otherwise return a normalized string."""
    if value is None:
        return None

    normalized = value.strip()
    if strip_trailing_slash:
        normalized = normalized.rstrip("/")
    return normalized if normalized else None


def serialize_agent_run(agent_run: AgentRun) -> bytes:
    """Serialize an AgentRun to compact JSON bytes."""
    return json.dumps(to_jsonable_python(agent_run), separators=(",", ":")).encode("utf-8")


def build_agent_runs_payload(serialized_runs: list[bytes]) -> bytes:
    """Wrap serialized individual runs into the API payload envelope."""
    body = b",".join(serialized_runs)
    return _AGENT_RUNS_PAYLOAD_PREFIX + body + _AGENT_RUNS_PAYLOAD_SUFFIX


def yield_agent_run_batches_by_size(
    agent_runs: list[AgentRun], max_payload_bytes: int
) -> Iterator[tuple[int, bytes]]:
    """Yield batches of agent runs whose serialized payloads stay within max_payload_bytes."""
    envelope_len = len(_AGENT_RUNS_PAYLOAD_PREFIX) + len(_AGENT_RUNS_PAYLOAD_SUFFIX)
    comma_len = 1

    current_serialized: list[bytes] = []
    current_size = envelope_len

    for agent_run in agent_runs:
        serialized = serialize_agent_run(agent_run)
        serialized_len = len(serialized)

        if envelope_len + serialized_len > max_payload_bytes:
            raise ValueError(
                f"A single agent run (id={agent_run.id}) exceeds the maximum payload size of "
                f"{max_payload_bytes} bytes. Reduce the size of that run before uploading."
            )

        delimiter = 0 if not current_serialized else comma_len
        projected_size = current_size + delimiter + serialized_len

        if current_serialized and projected_size > max_payload_bytes:
            yield len(current_serialized), build_agent_runs_payload(current_serialized)

            current_serialized = [serialized]
            current_size = envelope_len + serialized_len
        else:
            current_serialized.append(serialized)
            current_size = projected_size

    if current_serialized:
        yield len(current_serialized), build_agent_runs_payload(current_serialized)


def _has_profile_sections(path: Path) -> bool:
    """Check if a config file contains INI-style [section] headers."""
    with open(path) as f:
        for line in f:
            stripped = line.strip()
            if stripped.startswith("[") and stripped.endswith("]"):
                return True
    return False


def _strip_dotenv_quotes(value: str) -> str:
    """Remove surrounding single or double quotes, mirroring python-dotenv.

    configparser preserves quote characters verbatim; python-dotenv strips
    them. Users porting a plain dotenv file to [profile] sections expect
    the same semantics.
    """
    trimmed = value.strip()
    if len(trimmed) >= 2 and trimmed[0] == trimmed[-1] and trimmed[0] in ('"', "'"):
        return trimmed[1:-1]
    return trimmed


def _load_profiled_config(path: Path, profile: str | None) -> dict[str, str]:
    """Load config from a file with INI-style [section] headers."""
    import configparser

    parser = configparser.RawConfigParser()
    parser.optionxform = str  # type: ignore[assignment]
    parser.read(path)

    sections = parser.sections()
    if not sections:
        return {}

    if profile is not None:
        if profile not in sections:
            raise ValueError(
                f"Profile '{profile}' not found in {path}. "
                f"Available profiles: {', '.join(sections)}"
            )
        section = profile
    else:
        section = "default" if "default" in sections else sections[0]

    return {k: _strip_dotenv_quotes(v) for k, v in parser.items(section)}


def load_config_file(
    config_file: str | Path | None = None,
    logger: LoggerAdapter | None = None,
    profile: str | None = None,
) -> dict[str, str]:
    """Load configuration from a dotenv file.

    Args:
        config_file: Optional explicit path to a config file. If not provided,
            searches for 'docent.env' starting from the current working directory
            and traversing up the directory tree.
        logger: Optional logger for status messages.
        profile: Optional named profile to load from a multi-profile config file.
            If the file contains INI-style [section] headers, this selects which
            section to use. If not provided, uses [default] or the first section.
            Ignored if the file has no section headers (plain dotenv format).

    Returns:
        Dictionary of configuration values loaded from the file. Returns an empty
        dict if no file is found.
    """

    def _load_from_path(config_path: Path) -> dict[str, str]:
        if _has_profile_sections(config_path):
            if logger and profile:
                logger.info("Loading profile '%s' from %s", profile, config_path)
            elif logger:
                logger.info("Loading config from %s", config_path)
            return _load_profiled_config(config_path, profile)
        else:
            if profile and logger:
                logger.warning(
                    "Profile '%s' requested but %s has no profile sections. Loading as plain dotenv.",
                    profile,
                    config_path,
                )
            values = dotenv_values(config_path)
            return {k: v for k, v in values.items() if v is not None}

    if config_file is not None:
        config_path = Path(config_file)
        if not config_path.exists():
            raise FileNotFoundError(f"Config file not found: {config_file}")
        if logger:
            logger.info("Loading config from %s", config_path)
        return _load_from_path(config_path)

    current_dir = Path.cwd()
    while True:
        candidate = current_dir / "docent.env"
        if candidate.exists():
            if logger:
                logger.info("Found config file at %s", candidate)
            return _load_from_path(candidate)

        if current_dir == current_dir.parent:
            break
        current_dir = current_dir.parent

    return {}
