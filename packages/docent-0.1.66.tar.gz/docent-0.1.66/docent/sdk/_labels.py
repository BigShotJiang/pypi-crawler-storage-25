"""Label sets, tags, comments, and reading preset version fetch."""

from __future__ import annotations

from typing import Any

from docent.data_models.judge import Label
from docent.data_models.reading import ReadingPresetVersion
from docent.judges.util.meta_schema import validate_judge_result_schema
from docent.sdk._base import DocentBase


class DocentLabelsMixin(DocentBase):
    """Labels, tags, comments, and preset metadata."""

    def get_reading_preset_version(
        self,
        collection_id: str,
        preset_id: str,
        version_index: int,
    ) -> ReadingPresetVersion:
        """Fetch one pinned reading preset version."""
        url = f"{self._api_url}/reading/{collection_id}/preset/{preset_id}/version/{version_index}"
        response = self._session.get(url)
        self._handle_response_errors(response)
        return ReadingPresetVersion.model_validate(response.json())

    def create_label_set(
        self,
        collection_id: str,
        name: str,
        label_schema: dict[str, Any],
        description: str | None = None,
    ) -> str:
        """Create a new label set with a JSON schema.

        Args:
            collection_id: ID of the collection.
            name: Name of the label set.
            label_schema: JSON schema for validating labels in this set.
            description: Optional description of the label set.

        Returns:
            str: The ID of the created label set.

        Raises:
            ValueError: If the response is missing the label_set_id.
            jsonschema.ValidationError: If the label schema is invalid.
            requests.exceptions.HTTPError: If the API request fails.
        """
        validate_judge_result_schema(label_schema)

        url = f"{self._api_url}/label/{collection_id}/label_set"
        payload = {
            "name": name,
            "label_schema": label_schema,
            "description": description,
        }
        response = self._session.post(url, json=payload)
        self._handle_response_errors(response)
        return response.json()["label_set_id"]

    def add_label(
        self,
        collection_id: str,
        label: Label,
    ) -> dict[str, str]:
        """Create a label in a label set.

        Args:
            collection_id: ID of the Collection.
            label: A `Label` object that must comply with the label set's schema.

        Returns:
            dict: API response containing the label_id.

        Raises:
            requests.exceptions.HTTPError: If the API request fails or validation errors occur.
        """
        url = f"{self._api_url}/label/{collection_id}/label"
        payload = {"label": label.model_dump(mode="json")}
        response = self._session.post(url, json=payload)
        self._handle_response_errors(response)
        return response.json()

    def add_labels(
        self,
        collection_id: str,
        labels: list[Label],
    ) -> dict[str, Any]:
        """Create multiple labels.

        Args:
            collection_id: ID of the Collection.
            labels: List of `Label` objects.

        Returns:
            dict: API response containing label_ids list and optional errors list.

        Raises:
            ValueError: If no labels are provided.
            requests.exceptions.HTTPError: If the API request fails.
        """
        if not labels:
            raise ValueError("labels must contain at least one entry")

        url = f"{self._api_url}/label/{collection_id}/labels"
        payload = {"labels": [label.model_dump(mode="json") for label in labels]}
        response = self._session.post(url, json=payload)
        self._handle_response_errors(response)
        return response.json()

    def get_label_sets(self, collection_id: str) -> list[dict[str, Any]]:
        """Retrieve all label sets in a collection.

        Args:
            collection_id: ID of the Collection.

        Returns:
            list: List of label set dictionaries.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        url = f"{self._api_url}/label/{collection_id}/label_sets"
        response = self._session.get(url)
        self._handle_response_errors(response)
        return response.json()

    def get_labels(
        self, collection_id: str, label_set_id: str, filter_valid_labels: bool = False
    ) -> list[dict[str, Any]]:
        """Retrieve all labels in a label set.

        Args:
            collection_id: ID of the Collection.
            label_set_id: ID of the label set to fetch labels for.
            filter_valid_labels: If True, only return labels that match the label set schema
                INCLUDING requirements. Default is False (returns all labels).

        Returns:
            list: List of label dictionaries.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        url = f"{self._api_url}/label/{collection_id}/label_set/{label_set_id}/labels"
        params = {"filter_valid_labels": filter_valid_labels}
        response = self._session.get(url, params=params)
        self._handle_response_errors(response)
        return response.json()

    def tag_transcript(self, collection_id: str, agent_run_id: str, value: str) -> None:
        """Add a tag to an agent run transcript.

        Args:
            collection_id: ID of the Collection.
            agent_run_id: The agent run to tag.
            value: The tag value (max length enforced by the server).

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        url = f"{self._api_url}/label/{collection_id}/tag"
        payload = {"agent_run_id": agent_run_id, "value": value}
        response = self._session.post(url, json=payload)
        self._handle_response_errors(response)

    def get_tags(self, collection_id: str, value: str | None = None) -> list[dict[str, Any]]:
        """Get all tags in a collection, optionally filtered by value."""
        url = f"{self._api_url}/label/{collection_id}/tags"
        params = {"value": value} if value is not None else None
        response = self._session.get(url, params=params)
        self._handle_response_errors(response)
        return response.json()

    def get_tags_for_agent_run(self, collection_id: str, agent_run_id: str) -> list[dict[str, Any]]:
        """Get all tags attached to a specific agent run."""
        url = f"{self._api_url}/label/{collection_id}/agent_run/{agent_run_id}/tags"
        response = self._session.get(url)
        self._handle_response_errors(response)
        return response.json()

    def delete_tag(self, collection_id: str, tag_id: str) -> None:
        """Delete a tag by ID."""
        url = f"{self._api_url}/label/{collection_id}/tag/{tag_id}"
        response = self._session.delete(url)
        self._handle_response_errors(response)

    def get_comments(self, collection_id: str) -> list[dict[str, Any]]:
        """Get all comments in a collection.

        Args:
            collection_id: ID of the Collection.

        Returns:
            list: List of comment dictionaries.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        url = f"{self._api_url}/label/{collection_id}/comments"
        response = self._session.get(url)
        self._handle_response_errors(response)
        return response.json()

    def get_comments_for_agent_run(
        self, collection_id: str, agent_run_id: str
    ) -> list[dict[str, Any]]:
        """Get all comments for a specific agent run.

        Args:
            collection_id: ID of the Collection.
            agent_run_id: ID of the agent run to get comments for.

        Returns:
            list: List of comment dictionaries.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        url = f"{self._api_url}/label/{collection_id}/agent_run/{agent_run_id}/comments"
        response = self._session.get(url)
        self._handle_response_errors(response)
        return response.json()
