from __future__ import annotations

import webbrowser
from pathlib import Path
from typing import Any, cast

import requests
import yaml

from docent.sdk._base import DocentBase


class ReportConflictError(requests.HTTPError):
    def __init__(
        self,
        message: str,
        *,
        expected_revision: int | None = None,
        current_revision: int | None = None,
        response: requests.Response | None = None,
    ):
        super().__init__(message, response=response)
        self.expected_revision = expected_revision
        self.current_revision = current_revision


class DocentReportsMixin(DocentBase):
    def create_report(
        self,
        collection_id: str,
        *,
        title: str,
        markdown: str,
        source_reading_plan_id: str,
    ) -> dict[str, Any]:
        url = f"{self._api_url}/report/{collection_id}/reports"
        response = self._session.post(
            url,
            json={
                "title": title,
                "markdown": markdown,
                "source_reading_plan_id": source_reading_plan_id,
            },
        )
        self._handle_report_response_errors(response)
        return cast(dict[str, Any], response.json())

    def update_report(
        self,
        collection_id: str,
        report_id: str,
        *,
        title: str | None = None,
        markdown: str | None = None,
        expected_revision: int,
    ) -> dict[str, Any]:
        url = f"{self._api_url}/report/{collection_id}/reports/{report_id}"
        body = {
            "title": title,
            "markdown": markdown,
            "expected_revision": expected_revision,
        }
        response = self._session.patch(url, json=body)
        self._handle_report_response_errors(response)
        return cast(dict[str, Any], response.json())

    def get_report(self, collection_id: str, report_id: str) -> dict[str, Any]:
        url = f"{self._api_url}/report/{collection_id}/reports/{report_id}"
        response = self._session.get(url)
        self._handle_report_response_errors(response)
        return cast(dict[str, Any], response.json())

    def list_reports(
        self,
        collection_id: str,
        *,
        source_reading_plan_id: str | None = None,
        prefix: str | None = None,
        owned_only: bool = True,
    ) -> list[dict[str, Any]]:
        url = f"{self._api_url}/report/{collection_id}/reports"
        params: dict[str, str] = {}
        if source_reading_plan_id is not None:
            params["source_reading_plan_id"] = source_reading_plan_id
        if prefix is not None:
            params["prefix"] = prefix
        params["owned_only"] = "true" if owned_only else "false"
        response = self._session.get(url, params=params)
        self._handle_report_response_errors(response)
        return cast(list[dict[str, Any]], response.json())

    def open_report(self, collection_id: str, report_id: str) -> str:
        url = self._collection_dashboard_url(collection_id, f"reports/{report_id}")
        self._logger.info("Opening report in browser: %s", url)
        webbrowser.open(url)
        return url

    def save_report_file(
        self,
        path: str | Path,
    ) -> dict[str, Any]:
        """Create a persisted report from a local Markdown file."""
        frontmatter, markdown, report_path = self._read_report_file(path)
        self._reject_persisted_report_frontmatter(frontmatter, report_path, "save_report_file")

        collection_id = self._require_frontmatter_str(
            frontmatter,
            "docent_collection_id",
            report_path,
            "save_report_file",
        )
        source_reading_plan_id = self._require_frontmatter_str(
            frontmatter,
            "docent_source_reading_plan_id",
            report_path,
            "save_report_file",
        )
        title = self._require_frontmatter_str(frontmatter, "title", report_path, "save_report_file")

        return self.create_report(
            collection_id,
            title=title,
            markdown=markdown,
            source_reading_plan_id=source_reading_plan_id,
        )

    def update_report_file(
        self,
        path: str | Path,
        *,
        report_id: str,
        expected_revision: int,
    ) -> dict[str, Any]:
        """Update a persisted report from a local Markdown file."""
        frontmatter, markdown, report_path = self._read_report_file(path)
        self._reject_persisted_report_frontmatter(frontmatter, report_path, "update_report_file")

        collection_id = self._require_frontmatter_str(
            frontmatter,
            "docent_collection_id",
            report_path,
            "update_report_file",
        )
        source_reading_plan_id = self._require_frontmatter_str(
            frontmatter,
            "docent_source_reading_plan_id",
            report_path,
            "update_report_file",
        )
        title = self._require_frontmatter_str(
            frontmatter,
            "title",
            report_path,
            "update_report_file",
        )
        report = self.get_report(collection_id, report_id)
        persisted_source_reading_plan_id = self._as_optional_str(
            report.get("source_reading_plan_id")
        )
        if persisted_source_reading_plan_id != source_reading_plan_id:
            raise ValueError(
                "update_report_file() requires docent_source_reading_plan_id in frontmatter "
                "to match the persisted report."
            )

        return self.update_report(
            collection_id,
            report_id,
            title=title,
            markdown=markdown,
            expected_revision=expected_revision,
        )

    def _handle_report_response_errors(self, response: requests.Response) -> None:
        if response.status_code == 409:
            response_json: dict[str, Any] = {}
            try:
                raw_json: object = response.json()
                if isinstance(raw_json, dict):
                    response_json = cast(dict[str, Any], raw_json)
            except Exception:
                pass
            detail = response_json.get("detail", {})
            if isinstance(detail, dict):
                detail_dict = cast(dict[str, Any], detail)
                message = cast(str, detail_dict.get("message") or response.text or "Conflict")
                expected_revision = self._as_optional_int(detail_dict.get("expected_revision"))
                current_revision = self._as_optional_int(detail_dict.get("current_revision"))
            else:
                message = str(detail) if detail else response.text
                expected_revision = None
                current_revision = None
            raise ReportConflictError(
                message,
                expected_revision=expected_revision,
                current_revision=current_revision,
                response=response,
            )

        self._handle_response_errors(response)

    def _read_report_file(self, path: str | Path) -> tuple[dict[str, Any], str, Path]:
        report_path = Path(path)
        raw_text = report_path.read_text(encoding="utf-8")
        frontmatter, markdown = self._parse_report_file(raw_text, report_path)
        return frontmatter, markdown, report_path

    def _parse_report_file(self, raw_text: str, report_path: Path) -> tuple[dict[str, Any], str]:
        lines = raw_text.splitlines(keepends=True)
        if not lines or lines[0].strip() != "---":
            return {}, raw_text

        closing_index: int | None = None
        for index, line in enumerate(lines[1:], start=1):
            if line.strip() == "---":
                closing_index = index
                break

        if closing_index is None:
            return {}, raw_text

        frontmatter_text = "".join(lines[1:closing_index])
        body = "".join(lines[closing_index + 1 :]).lstrip("\r\n")
        try:
            loaded_obj = yaml.safe_load(frontmatter_text)
        except yaml.YAMLError as exc:
            raise ValueError(f"Failed to parse report frontmatter in {report_path}: {exc}") from exc

        loaded: object = {} if loaded_obj is None else loaded_obj
        if not isinstance(loaded, dict):
            raise ValueError(f"Report frontmatter in {report_path} must be a YAML mapping.")

        return cast(dict[str, Any], loaded), body

    def _reject_persisted_report_frontmatter(
        self,
        frontmatter: dict[str, Any],
        report_path: Path,
        function_name: str,
    ) -> None:
        report_id = self._as_optional_str(frontmatter.get("docent_report_id"))
        revision = self._as_optional_int(frontmatter.get("docent_revision"))
        if report_id is None and revision is None:
            return
        raise ValueError(
            f"{function_name}() does not read docent_report_id or docent_revision from "
            f"{report_path}. Pass report_id/expected_revision explicitly to update_report_file(), "
            "or remove the persisted report metadata from frontmatter."
        )

    def _require_frontmatter_str(
        self,
        frontmatter: dict[str, Any],
        key: str,
        report_path: Path,
        function_name: str,
    ) -> str:
        value = self._as_optional_str(frontmatter.get(key))
        if value is None:
            raise ValueError(
                f"{function_name}() requires {key} in the YAML frontmatter of {report_path}."
            )
        return value

    def _as_optional_str(self, value: Any) -> str | None:
        if value is None:
            return None
        if isinstance(value, str):
            stripped = value.strip()
            return stripped or None
        return str(value)

    def _as_optional_int(self, value: Any) -> int | None:
        if value is None or value == "":
            return None
        if isinstance(value, int):
            return value
        try:
            return int(value)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"Expected integer revision, got {value!r}") from exc
