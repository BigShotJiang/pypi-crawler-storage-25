"""Organizations, collaborators, and collection sharing."""

from __future__ import annotations

from typing import Any, Literal

from docent.sdk._base import DocentBase


class DocentSharingMixin(DocentBase):
    """Sharing and permission helpers."""

    def make_collection_public(
        self,
        collection_id: str,
        *,
        permission: Literal["read", "write"] = "read",
    ) -> dict[str, Any]:
        """Make a collection publicly accessible to anyone with the link.
        DEPRECATED -- for backwards compatibility only

        Args:
            collection_id: ID of the Collection to make public.
            permission: Public permission level. Use ``"read"`` for read-only public
                access or ``"write"`` for write access.

        Returns:
            dict: API response data.

        Raises:
            ValueError: If ``permission`` is not one of ``"read"`` or ``"write"``.
            requests.exceptions.HTTPError: If the API request fails.
        """
        self.share_collection_with_public(collection_id, permission=permission)
        return {
            "status": "success",
            "message": f"Collection is now public with {permission} access",
        }

    def share_collection_with_email(self, collection_id: str, email: str) -> dict[str, Any]:
        """Share a collection with a specific user by email address.

        Args:
            collection_id: ID of the Collection to share.
            email: Email address of the user to share with.

        Returns:
            dict: API response data.

        Raises:
            requests.exceptions.HTTPError: If the API request fails.
        """
        url = f"{self._api_url}/{collection_id}/share_with_email"
        payload = {"email": email}
        response = self._session.post(url, json=payload)

        self._handle_response_errors(response)

        self._logger.info("Successfully shared Collection '%s' with %s", collection_id, email)
        return response.json()

    def get_my_organizations(self) -> list[dict[str, Any]]:
        """List organizations the authenticated user belongs to."""
        url = f"{self._api_url}/organizations"
        response = self._session.get(url)
        self._handle_response_errors(response)
        return response.json()

    def get_organization_users(self, organization_id: str) -> list[dict[str, Any]]:
        """List users in an organization.

        Args:
            organization_id: Organization ID.
        """
        url = f"{self._api_url}/organizations/{organization_id}/users"
        response = self._session.get(url)
        self._handle_response_errors(response)
        return response.json()

    def get_collection_collaborators(self, collection_id: str) -> list[dict[str, Any]]:
        """List collaborators (users, organizations, public) for a collection."""
        url = f"{self._api_url}/collections/{collection_id}/collaborators"
        response = self._session.get(url)
        self._handle_response_errors(response)
        return response.json()

    def share_collection_with_public(
        self,
        collection_id: str,
        *,
        permission: Literal["read", "write"] = "read",
    ) -> None:
        """Share a collection publicly.

        Note: The backend requires admin permission on the collection to manage sharing.
        """
        if permission not in {"read", "write"}:
            raise ValueError("permission must be one of ['read', 'write']")

        url = f"{self._api_url}/collections/{collection_id}/collaborators/upsert"
        payload = {
            "subject_id": "public",
            "subject_type": "public",
            "collection_id": collection_id,
            "permission_level": permission,
        }
        response = self._session.put(url, json=payload)
        self._handle_response_errors(response)
        return None

    def unshare_collection_with_public(self, collection_id: str) -> None:
        """Remove public access to a collection."""
        url = f"{self._api_url}/collections/{collection_id}/collaborators/delete"
        payload = {
            "subject_id": "public",
            "subject_type": "public",
            "collection_id": collection_id,
        }
        response = self._session.delete(url, json=payload)
        self._handle_response_errors(response)
        return None

    def share_collection_with_user(
        self,
        collection_id: str,
        user_id: str,
        *,
        permission: Literal["read", "write", "admin"] = "read",
    ) -> None:
        """Share a collection with a user by user ID.

        Note: The backend requires admin permission on the collection to manage sharing.
        """
        if permission not in {"read", "write", "admin"}:
            raise ValueError("permission must be one of ['admin', 'read', 'write']")

        url = f"{self._api_url}/collections/{collection_id}/collaborators/upsert"
        payload = {
            "subject_id": user_id,
            "subject_type": "user",
            "collection_id": collection_id,
            "permission_level": permission,
        }
        response = self._session.put(url, json=payload)
        self._handle_response_errors(response)
        return None

    def unshare_collection_with_user(self, collection_id: str, user_id: str) -> None:
        """Remove a user's access to a collection."""
        url = f"{self._api_url}/collections/{collection_id}/collaborators/delete"
        payload = {
            "subject_id": user_id,
            "subject_type": "user",
            "collection_id": collection_id,
        }
        response = self._session.delete(url, json=payload)
        self._handle_response_errors(response)
        return None

    def share_collection_with_organization(
        self,
        collection_id: str,
        organization_id: str,
        *,
        permission: Literal["read", "write", "admin"] = "read",
    ) -> None:
        """Share a collection with an organization.

        Note: The backend requires admin permission on the collection to manage sharing.
        """
        if permission not in {"read", "write", "admin"}:
            raise ValueError("permission must be one of ['admin', 'read', 'write']")

        url = f"{self._api_url}/collections/{collection_id}/collaborators/upsert"
        payload = {
            "subject_id": organization_id,
            "subject_type": "organization",
            "collection_id": collection_id,
            "permission_level": permission,
        }
        response = self._session.put(url, json=payload)
        self._handle_response_errors(response)
        return None

    def unshare_collection_with_organization(
        self, collection_id: str, organization_id: str
    ) -> None:
        """Remove an organization's access to a collection."""
        url = f"{self._api_url}/collections/{collection_id}/collaborators/delete"
        payload = {
            "subject_id": organization_id,
            "subject_type": "organization",
            "collection_id": collection_id,
        }
        response = self._session.delete(url, json=payload)
        self._handle_response_errors(response)
        return None

    def collection_exists(self, collection_id: str) -> bool:
        """Check if a collection exists without raising if it does not."""
        url = f"{self._api_url}/{collection_id}/exists"
        response = self._session.get(url)
        self._handle_response_errors(response)
        return bool(response.json())

    def has_collection_permission(self, collection_id: str, permission: str = "write") -> bool:
        """Check whether the authenticated user has a specific permission on a collection.

        Args:
            collection_id: Collection to check.
            permission: Permission level to verify (`read`, `write`, or `admin`).

        Returns:
            bool: True if the current API key has the requested permission; otherwise False.

        Raises:
            ValueError: If an unsupported permission value is provided.
            requests.exceptions.HTTPError: If the API request fails.
        """
        valid_permissions = {"read", "write", "admin"}
        if permission not in valid_permissions:
            raise ValueError(f"permission must be one of {sorted(valid_permissions)}")

        url = f"{self._api_url}/{collection_id}/has_permission"
        response = self._session.get(url, params={"permission": permission})
        self._handle_response_errors(response)

        payload = response.json()
        return bool(payload.get("has_permission", False))
