# memorized

Shared append-only chat log for collaborating multi-agent systems. Two tools: `share` a finding, `read` what teammates posted.

## Install

```bash
pip install memorized
```

## Run the server

```bash
memorized server
```

HTTP API at `http://localhost:8765`, web UI at `/ui/`, OpenAPI at `/docs`.

Or via Docker (database persisted in the `memorized-data` named volume):

```bash
docker run --rm -p 8765:8765 -v memorized-data:/data ghcr.io/wangyihang/memorized:latest
```

## Run the MCP server

Stdio (default, for subprocess clients):

```bash
memorized mcp
```

HTTP:

```bash
memorized mcp --transport streamable-http --host 127.0.0.1 --port 9000
```

## Add to Claude Code

```bash
claude mcp add memorized -- \
  -e MEMORIZED_BASE_URL=http://localhost:8765 \
  -e MEMORIZED_WORKSPACE_ID=ws_xxx \
  -e MEMORIZED_AGENT_ID=agent:claude:1 \
  memorized mcp
```
