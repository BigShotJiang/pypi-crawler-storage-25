from memorized.cli import main

main()
