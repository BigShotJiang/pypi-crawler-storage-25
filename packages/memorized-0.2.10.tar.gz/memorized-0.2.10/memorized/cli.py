"""Single ``memorized`` CLI with four subcommand groups.

    memorized server --db PATH --host HOST --port PORT
    memorized mcp
    memorized ws create NAME
    memorized ws list
    memorized msg send WORKSPACE AGENT_ID TEXT [--tag ...]
    memorized msg read  WORKSPACE [--since N] [--limit N]

``server`` starts the HTTP + Web UI process. ``mcp`` starts the stdio MCP
server (used by MCP clients that spawn subprocesses). ``ws`` and ``msg``
are the client-side operations an operator or CI script would use.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Annotated

import typer
import uvicorn
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from memorized.client import MemorizedClient
from memorized.exceptions import MemorizedError
from memorized.mcp_server import main as mcp_main
from memorized.server import create_app
from memorized.server.config import Settings

console = Console()
err_console = Console(stderr=True)

app = typer.Typer(
    name="memorized",
    help="Shared append-only chat log for collaborating multi-agent systems.",
    no_args_is_help=True,
    add_completion=False,
)
ws_app = typer.Typer(help="Workspace commands.", no_args_is_help=True)
msg_app = typer.Typer(help="Message commands.", no_args_is_help=True)
app.add_typer(ws_app, name="ws")
app.add_typer(msg_app, name="msg")


BASE_URL_ENV = "MEMORIZED_BASE_URL"
API_KEY_ENV = "MEMORIZED_API_KEY"
DEFAULT_BASE_URL = "http://127.0.0.1:8765"


def _base_url() -> str:
    return os.environ.get(BASE_URL_ENV, DEFAULT_BASE_URL)


def _api_key() -> str | None:
    return os.environ.get(API_KEY_ENV)


# ---------------------------------------------------------------------------
# server / mcp
# ---------------------------------------------------------------------------


_DEFAULT_DB = Path("memorized.db")


@app.command()
def server(
    db: Annotated[Path, typer.Option(help="SQLite file backing the workspace.")] = _DEFAULT_DB,
    host: Annotated[str, typer.Option(help="Bind host.")] = "127.0.0.1",
    port: Annotated[int, typer.Option(help="Bind port.")] = 8765,
) -> None:
    """Run the HTTP + Web UI server."""
    settings = Settings(db_path=db, host=host, port=port)
    auth_line = "[green]enabled[/green]" if settings.api_key else "[yellow]disabled[/yellow]"
    console.print(
        Panel.fit(
            f"[bold]memorized[/bold]\n"
            f"db       [cyan]{db}[/cyan]\n"
            f"http     [cyan]http://{host}:{port}[/cyan]\n"
            f"ui       [cyan]http://{host}:{port}/ui/[/cyan]\n"
            f"openapi  [cyan]http://{host}:{port}/docs[/cyan]\n"
            f"auth     {auth_line}",
            title="starting",
            border_style="green",
        )
    )
    uvicorn.run(create_app(settings), host=host, port=port, log_level="info")


@app.command()
def mcp(
    transport: Annotated[
        str,
        typer.Option(
            "--transport",
            "-t",
            help="MCP transport: stdio (default, for subprocess clients), "
            "streamable-http, or sse.",
        ),
    ] = "stdio",
    host: Annotated[
        str,
        typer.Option(help="Bind host (http/sse transports only)."),
    ] = "127.0.0.1",
    port: Annotated[
        int,
        typer.Option(help="Bind port (http/sse transports only)."),
    ] = 8000,
) -> None:
    """Run the MCP server. Defaults to stdio; pass --transport for HTTP."""
    if transport not in ("stdio", "streamable-http", "sse"):
        raise typer.BadParameter(
            f"transport must be stdio|streamable-http|sse, got {transport!r}"
        )
    mcp_main(transport=transport, host=host, port=port)  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# workspaces
# ---------------------------------------------------------------------------


@ws_app.command("create")
def ws_create(id: str) -> None:
    """Create (or return existing) workspace with the given ID."""
    ws = MemorizedClient.create_workspace(_base_url(), id, api_key=_api_key())
    console.print(f"[green]created[/green] [cyan]{ws.id}[/cyan]")


@ws_app.command("list")
def ws_list() -> None:
    """List all workspaces on the server."""
    workspaces = MemorizedClient.list_workspaces(_base_url(), api_key=_api_key())
    table = Table(title="Workspaces")
    table.add_column("id", style="cyan")
    table.add_column("metadata")
    table.add_column("created_at", justify="right")
    for w in workspaces:
        meta_str = json.dumps(w.metadata, ensure_ascii=False) if w.metadata else ""
        table.add_row(w.id, meta_str, f"{w.created_at:.0f}")
    console.print(table)


# ---------------------------------------------------------------------------
# messages
# ---------------------------------------------------------------------------


@msg_app.command("send")
def msg_send(
    workspace: str,
    agent_id: str,
    text: Annotated[
        str | None,
        typer.Argument(help="Message text. Omit to read from stdin."),
    ] = None,
    tag: Annotated[
        list[str] | None,
        typer.Option("--tag", help="Repeat for multiple tags."),
    ] = None,
    confidence: Annotated[
        float | None,
        typer.Option("--confidence", "-c", help="Confidence score 0.0–1.0."),
    ] = None,
) -> None:
    """Post a message to a workspace chat."""
    if text is None:
        text = sys.stdin.read()
    if not text.strip():
        err_console.print("[red]error[/red] empty message (nothing on stdin?)")
        raise typer.Exit(code=1)
    with MemorizedClient(_base_url(), workspace, agent_id=agent_id, api_key=_api_key()) as c:
        r = c.share(text, tags=tag or [], confidence=confidence)
    console.print(f"[green]sent[/green] id=[cyan]{r.id}[/cyan]")


@msg_app.command("read")
def msg_read(
    workspace: str,
    since: Annotated[int, typer.Option(help="Only return messages with id > since.")] = 0,
    limit: Annotated[int, typer.Option(help="Max messages to return.")] = 500,
) -> None:
    """Read messages from a workspace chat."""
    with MemorizedClient(_base_url(), workspace, api_key=_api_key()) as c:
        msgs = c.read(since=since, limit=limit)
    table = Table(title=f"Messages ({len(msgs)}) · since={since}")
    table.add_column("id", style="cyan", justify="right")
    table.add_column("agent_id")
    table.add_column("conf", justify="right")
    table.add_column("tags")
    table.add_column("text")
    for m in msgs:
        conf_str = f"{m.confidence:.0%}" if m.confidence is not None else ""
        table.add_row(str(m.id), m.agent_id, conf_str, ",".join(m.tags), m.text)
    console.print(table)


@msg_app.command("edit")
def msg_edit(
    workspace: str,
    msg_id: Annotated[int, typer.Argument(help="Message ID to edit.")],
    text: Annotated[str | None, typer.Option("--text", help="New message text.")] = None,
    tag: Annotated[list[str] | None, typer.Option("--tag", help="New tags (replaces all).")] = None,
    confidence: Annotated[float | None, typer.Option("--confidence", "-c", help="New confidence 0.0–1.0.")] = None,
) -> None:
    """Edit an existing message."""
    with MemorizedClient(_base_url(), workspace, api_key=_api_key()) as c:
        m = c.edit(msg_id, text=text, tags=tag, confidence=confidence)
    console.print(f"[green]edited[/green] id=[cyan]{m.id}[/cyan]")


@msg_app.command("delete")
def msg_delete(
    workspace: str,
    msg_id: Annotated[int, typer.Argument(help="Message ID to delete.")],
) -> None:
    """Soft-delete a message."""
    with MemorizedClient(_base_url(), workspace, api_key=_api_key()) as c:
        c.delete(msg_id)
    console.print(f"[green]deleted[/green] id=[cyan]{msg_id}[/cyan]")


@msg_app.command("comment")
def msg_comment(
    workspace: str,
    msg_id: Annotated[int, typer.Argument(help="Message ID to comment on.")],
    agent_id: str = typer.Argument(..., help="Who is commenting."),
    text: str = typer.Argument(..., help="Comment text."),
) -> None:
    """Add a comment to a message."""
    with MemorizedClient(_base_url(), workspace, agent_id=agent_id, api_key=_api_key()) as c:
        r = c.add_comment(msg_id, text)
    console.print(f"[green]commented[/green] id=[cyan]{r.id}[/cyan] on msg [cyan]{msg_id}[/cyan]")


@msg_app.command("comments")
def msg_comments(
    workspace: str,
    msg_id: Annotated[int, typer.Argument(help="Message ID.")],
) -> None:
    """List comments on a message."""
    with MemorizedClient(_base_url(), workspace, api_key=_api_key()) as c:
        comments = c.list_comments(msg_id)
    table = Table(title=f"Comments on message {msg_id} ({len(comments)})")
    table.add_column("id", style="cyan", justify="right")
    table.add_column("agent_id")
    table.add_column("text")
    for co in comments:
        table.add_row(str(co.id), co.agent_id, co.text)
    console.print(table)


# ---------------------------------------------------------------------------
# error rendering
# ---------------------------------------------------------------------------


def _render_error(exc: MemorizedError) -> None:
    err_console.print(
        f"[red]error[/red] [bold]{exc.code.value}[/bold] "
        f"([yellow]{exc.status}[/yellow])"
    )
    err_console.print(f"  {exc.message}")
    if exc.hint:
        err_console.print(f"  [dim]hint:[/dim] {exc.hint}")
    if exc.fields:
        err_console.print("  [dim]fields:[/dim]")
        for f in exc.fields:
            err_console.print(f"    [yellow]{f.loc}[/yellow]: {f.msg} [dim]({f.type})[/dim]")
    if exc.context:
        err_console.print("  [dim]context:[/dim]")
        for k, v in exc.context.items():
            err_console.print(f"    {k}: {v}")


def main() -> None:
    """Entry point for the ``memorized`` console script."""
    try:
        app()
    except MemorizedError as exc:
        _render_error(exc)
        sys.exit(2)


if __name__ == "__main__":
    main()
