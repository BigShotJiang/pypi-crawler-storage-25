"""MCP server exposing memorized as two tools: ``share`` and ``read``.

Launched by ``memorized mcp`` (or ``python -m memorized mcp``). Defaults to
stdio transport; ``--transport streamable-http`` (or ``sse``) runs it as an
HTTP server instead. The scheduler is expected to inject three environment
variables when it spawns the MCP process:

- ``MEMORIZED_BASE_URL``      (default ``http://127.0.0.1:8765``)
- ``MEMORIZED_WORKSPACE_ID``  (required — which workspace this agent joins)
- ``MEMORIZED_AGENT_ID``      (required — the agent's unique id)

Only two tools are exposed because an LLM facing a small, unambiguous tool
set makes better choices than one facing a dozen overlapping ones.
Workspace creation / listing is deliberately a scheduler concern, not an
agent concern, so those operations are not tools.
"""
from __future__ import annotations

import asyncio
import atexit
import functools
import os
from collections.abc import Awaitable, Callable
from typing import Annotated, Any, Literal, TypeVar

Transport = Literal["stdio", "sse", "streamable-http"]

from mcp.server.fastmcp import FastMCP
from pydantic import Field

from memorized.client import AsyncMemorizedClient
from memorized.exceptions import MemorizedError
from memorized.schemas import MessageCreateOut, MessageOut

BASE_URL = os.environ.get("MEMORIZED_BASE_URL", "http://127.0.0.1:8765")
WORKSPACE_ID = os.environ.get("MEMORIZED_WORKSPACE_ID")
AGENT_ID = os.environ.get("MEMORIZED_AGENT_ID")
API_KEY = os.environ.get("MEMORIZED_API_KEY")

mcp = FastMCP("memorized")


class _ClientHolder:
    """Process-wide slot for the lazily-built MCP client.

    A class attribute avoids the ``global`` statement that ruff (and most
    style guides) discourage, while keeping the same "construct once,
    reuse forever" semantics.
    """

    instance: AsyncMemorizedClient | None = None

    @classmethod
    async def close(cls) -> None:
        if cls.instance is not None:
            await cls.instance.aclose()
            cls.instance = None


async def _get_client() -> AsyncMemorizedClient:
    if _ClientHolder.instance is None:
        if WORKSPACE_ID is None:
            raise RuntimeError(
                "MEMORIZED_WORKSPACE_ID must be set before memorized mcp starts"
            )
        if AGENT_ID is None:
            raise RuntimeError(
                "MEMORIZED_AGENT_ID must be set before memorized mcp starts"
            )
        _ClientHolder.instance = AsyncMemorizedClient(
            BASE_URL, WORKSPACE_ID, agent_id=AGENT_ID, api_key=API_KEY
        )
    return _ClientHolder.instance


def _cleanup_client() -> None:
    if _ClientHolder.instance is not None:
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                loop.create_task(_ClientHolder.close())
            else:
                loop.run_until_complete(_ClientHolder.close())
        except RuntimeError:
            # No event loop available at exit — connection will be GC'd.
            pass


atexit.register(_cleanup_client)


T = TypeVar("T")


def _tool_errors(
    fn: Callable[..., Awaitable[T]],
) -> Callable[..., Awaitable[T | dict[str, Any]]]:
    """Turn every ``MemorizedError`` into a structured tool result.

    Without this, an unhandled SDK exception escapes to the MCP layer and
    FastMCP reports it as a tool error with a raw stack trace — meaningless
    to an LLM. Wrapping each tool lets the caller branch on result shape.
    """

    @functools.wraps(fn)
    async def wrapper(*args: Any, **kwargs: Any) -> T | dict[str, Any]:
        try:
            return await fn(*args, **kwargs)
        except MemorizedError as exc:
            return {"error": exc.to_body().model_dump(mode="json")}

    return wrapper


@mcp.tool()
@_tool_errors
async def share(
    text: Annotated[
        str,
        Field(
            description=(
                "A meaningful finding you want the whole team to know about. "
                "Only call this when you have real progress worth pinning for "
                "teammates who start later or restart after a failure — a "
                "significant finding, validated result, confirmed dead-end, "
                "or decision worth preserving. Do NOT post trivial status "
                "updates, thinking-out-loud, or acknowledgements."
            ),
            min_length=1,
        ),
    ],
    tags: Annotated[
        list[str] | None,
        Field(description="Optional free-form tags, e.g. ['finding'] or ['result','ingestion']."),
    ] = None,
    confidence: Annotated[
        float | None,
        Field(
            description=(
                "How confident you are in this information, from 0.0 (guess) "
                "to 1.0 (certain). Omit if unknown."
            ),
            ge=0.0,
            le=1.0,
        ),
    ] = None,
) -> MessageCreateOut:
    """Post a message to the shared workspace chat.

    Every agent assigned to this workspace — including ones that start later
    or restart after a crash — will be able to read it back via ``read``.
    This is the only way to hand knowledge to a future teammate, so use it
    when (and only when) you have something worth preserving.
    """
    client = await _get_client()
    return await client.share(text, tags=tags, confidence=confidence)


@mcp.tool()
@_tool_errors
async def read(
    since: Annotated[
        int,
        Field(
            description=(
                "Last message id you have already processed. Pass 0 to read "
                "the full history from the start of this workspace — do this "
                "once when your agent starts up, then track the max id you "
                "have seen and poll with that value."
            ),
            ge=0,
        ),
    ] = 0,
    limit: Annotated[int, Field(ge=1, le=2000)] = 500,
) -> list[MessageOut]:
    """Read messages from the shared workspace chat.

    Returns messages with ``id > since``, in ascending id order
    (chronological). Call once with ``since=0`` on startup to catch up on
    what your teammates have found; then poll periodically with the largest
    id you have seen.
    """
    client = await _get_client()
    return await client.read(since=since, limit=limit)


def main(
    transport: Transport = "stdio",
    host: str | None = None,
    port: int | None = None,
) -> None:
    """Entry point for ``memorized mcp``. Defaults to stdio transport."""
    if host is not None:
        mcp.settings.host = host
    if port is not None:
        mcp.settings.port = port
    mcp.run(transport=transport)


if __name__ == "__main__":
    main()
