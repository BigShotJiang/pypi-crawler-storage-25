"""Sync + async HTTP clients for the memorized server.

Two classes, ``MemorizedClient`` (sync) and ``AsyncMemorizedClient`` (async),
wrap the server's four-endpoint surface:

- ``create_workspace`` / ``list_workspaces`` (classmethods — no workspace_id)
- ``share`` / ``read`` (instance methods — scoped to one workspace)

The scheduler injects ``workspace_id`` and ``agent_id`` when it constructs
the client. ``agent_id`` is required for ``share`` but unused by ``read``,
so it is optional — a read-only client (e.g. a dashboard) can pass ``None``.

Example::

    from memorized import MemorizedClient

    with MemorizedClient(base_url, workspace_id, agent_id="agent:worker:1") as mem:
        history = mem.read(since=0)           # catch up on restart
        mem.share(
            "finished ingesting q3.csv: 128k rows, 3 schema drifts",
            tags=["ingestion", "result"],
        )
        new = mem.read(since=history[-1].id if history else 0)
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx

from memorized.exceptions import raise_for_response, wrap_transport_error
from memorized.schemas import (
    CommentIn,
    CommentOut,
    MessageCreateOut,
    MessageIn,
    MessageOut,
    MessageUpdate,
    WorkspaceCreate,
    WorkspaceOut,
)

# ---------------------------------------------------------------------------
# Wire operations — transport-agnostic description of each endpoint
# ---------------------------------------------------------------------------

_UNSET: Any = object()
"""Sentinel distinguishing 'caller omitted the argument' from 'caller passed None'."""


@dataclass(frozen=True, slots=True)
class _Op:
    method: str
    path: str
    json: dict[str, Any] | None = None
    params: dict[str, Any] | None = None


def _op_create_workspace(id: str, metadata: dict[str, Any] | None = None) -> _Op:
    return _Op("POST", "/workspaces", json=WorkspaceCreate(id=id, metadata=metadata or {}).model_dump(mode="json"))


def _op_list_workspaces() -> _Op:
    return _Op("GET", "/workspaces")


def _op_share(ws: str, agent_id: str, text: str, tags: list[str], confidence: float | None = None) -> _Op:
    body = MessageIn(agent_id=agent_id, text=text, tags=tags, confidence=confidence).model_dump(mode="json")
    return _Op("POST", f"/workspaces/{ws}/messages", json=body)


def _op_read(ws: str, since: int, limit: int) -> _Op:
    return _Op(
        "GET",
        f"/workspaces/{ws}/messages",
        params={"since": since, "limit": limit},
    )


def _op_edit(ws: str, msg_id: int, text: str | None, tags: list[str] | None, confidence: float | None, fields_set: set[str]) -> _Op:
    body = MessageUpdate(text=text, tags=tags, confidence=confidence)
    # Only include fields the caller explicitly set.
    payload = body.model_dump(mode="json", include=fields_set)
    return _Op("PATCH", f"/workspaces/{ws}/messages/{msg_id}", json=payload)


def _op_delete(ws: str, msg_id: int) -> _Op:
    return _Op("DELETE", f"/workspaces/{ws}/messages/{msg_id}")


def _op_add_comment(ws: str, msg_id: int, agent_id: str, comment_text: str) -> _Op:
    body = CommentIn(agent_id=agent_id, text=comment_text).model_dump(mode="json")
    return _Op("POST", f"/workspaces/{ws}/messages/{msg_id}/comments", json=body)


def _op_list_comments(ws: str, msg_id: int) -> _Op:
    return _Op("GET", f"/workspaces/{ws}/messages/{msg_id}/comments")


def _auth_headers(api_key: str | None) -> dict[str, str]:
    if api_key:
        return {"Authorization": f"Bearer {api_key}"}
    return {}


def _require_agent(agent_id: str | None) -> str:
    if agent_id is None:
        raise ValueError(
            "agent_id is required for share(); pass it when constructing the client"
        )
    return agent_id


# ---------------------------------------------------------------------------
# Synchronous client
# ---------------------------------------------------------------------------


class MemorizedClient:
    """Synchronous HTTP client."""

    def __init__(
        self,
        base_url: str,
        workspace_id: str,
        *,
        agent_id: str | None = None,
        api_key: str | None = None,
        timeout: float = 30.0,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.workspace_id = workspace_id
        self.agent_id = agent_id
        headers = _auth_headers(api_key)
        self._http = httpx.Client(
            base_url=self.base_url,
            timeout=timeout,
            transport=transport,
            headers=headers,
        )

    def _do(self, op: _Op) -> httpx.Response:
        try:
            r = self._http.request(
                op.method, op.path, json=op.json, params=op.params
            )
        except httpx.TransportError as exc:
            raise wrap_transport_error(exc, base_url=self.base_url) from exc
        raise_for_response(r)
        return r

    # workspaces -------------------------------------------------------
    @classmethod
    def create_workspace(
        cls, base_url: str, id: str, metadata: dict[str, Any] | None = None,
        *, api_key: str | None = None,
    ) -> WorkspaceOut:
        with httpx.Client(base_url=base_url.rstrip("/"), headers=_auth_headers(api_key)) as http:
            op = _op_create_workspace(id, metadata)
            try:
                r = http.request(op.method, op.path, json=op.json)
            except httpx.TransportError as exc:
                raise wrap_transport_error(exc, base_url=base_url) from exc
            raise_for_response(r)
            return WorkspaceOut.model_validate(r.json())

    @classmethod
    def list_workspaces(cls, base_url: str, *, api_key: str | None = None) -> list[WorkspaceOut]:
        with httpx.Client(base_url=base_url.rstrip("/"), headers=_auth_headers(api_key)) as http:
            op = _op_list_workspaces()
            try:
                r = http.request(op.method, op.path)
            except httpx.TransportError as exc:
                raise wrap_transport_error(exc, base_url=base_url) from exc
            raise_for_response(r)
            return [WorkspaceOut.model_validate(item) for item in r.json()]

    # messages ---------------------------------------------------------
    def share(self, text: str, tags: list[str] | None = None, confidence: float | None = None) -> MessageCreateOut:
        op = _op_share(self.workspace_id, _require_agent(self.agent_id), text, tags or [], confidence=confidence)
        return MessageCreateOut.model_validate(self._do(op).json())

    def read(self, since: int = 0, limit: int = 500) -> list[MessageOut]:
        op = _op_read(self.workspace_id, since, limit)
        return [MessageOut.model_validate(item) for item in self._do(op).json()]

    def edit(
        self,
        msg_id: int,
        *,
        text: str | None | Any = _UNSET,
        tags: list[str] | None | Any = _UNSET,
        confidence: float | None | Any = _UNSET,
    ) -> MessageOut:
        # Track which kwargs the caller actually passed.
        fields: set[str] = set()
        if text is not _UNSET:
            fields.add("text")
        if tags is not _UNSET:
            fields.add("tags")
        if confidence is not _UNSET:
            fields.add("confidence")
        op = _op_edit(
            self.workspace_id, msg_id,
            text if text is not _UNSET else None,
            tags if tags is not _UNSET else None,
            confidence if confidence is not _UNSET else None,
            fields,
        )
        return MessageOut.model_validate(self._do(op).json())

    def delete(self, msg_id: int) -> None:
        op = _op_delete(self.workspace_id, msg_id)
        self._do(op)

    def add_comment(self, msg_id: int, text: str) -> CommentOut:
        op = _op_add_comment(self.workspace_id, msg_id, _require_agent(self.agent_id), text)
        return CommentOut.model_validate(self._do(op).json())

    def list_comments(self, msg_id: int) -> list[CommentOut]:
        op = _op_list_comments(self.workspace_id, msg_id)
        return [CommentOut.model_validate(item) for item in self._do(op).json()]

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> MemorizedClient:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()


# ---------------------------------------------------------------------------
# Asynchronous client
# ---------------------------------------------------------------------------


class AsyncMemorizedClient:
    """Async mirror of ``MemorizedClient``."""

    def __init__(
        self,
        base_url: str,
        workspace_id: str,
        *,
        agent_id: str | None = None,
        api_key: str | None = None,
        timeout: float = 30.0,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.workspace_id = workspace_id
        self.agent_id = agent_id
        headers = _auth_headers(api_key)
        self._http = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=timeout,
            transport=transport,
            headers=headers,
        )

    async def _do(self, op: _Op) -> httpx.Response:
        try:
            r = await self._http.request(
                op.method, op.path, json=op.json, params=op.params
            )
        except httpx.TransportError as exc:
            raise wrap_transport_error(exc, base_url=self.base_url) from exc
        raise_for_response(r)
        return r

    @classmethod
    async def create_workspace(
        cls, base_url: str, id: str, metadata: dict[str, Any] | None = None,
        *, api_key: str | None = None,
    ) -> WorkspaceOut:
        headers = _auth_headers(api_key)
        async with httpx.AsyncClient(base_url=base_url.rstrip("/"), headers=headers) as http:
            op = _op_create_workspace(id, metadata)
            try:
                r = await http.request(op.method, op.path, json=op.json)
            except httpx.TransportError as exc:
                raise wrap_transport_error(exc, base_url=base_url) from exc
            raise_for_response(r)
            return WorkspaceOut.model_validate(r.json())

    @classmethod
    async def list_workspaces(
        cls, base_url: str, *, api_key: str | None = None,
    ) -> list[WorkspaceOut]:
        headers = _auth_headers(api_key)
        async with httpx.AsyncClient(base_url=base_url.rstrip("/"), headers=headers) as http:
            op = _op_list_workspaces()
            try:
                r = await http.request(op.method, op.path)
            except httpx.TransportError as exc:
                raise wrap_transport_error(exc, base_url=base_url) from exc
            raise_for_response(r)
            return [WorkspaceOut.model_validate(item) for item in r.json()]

    async def share(
        self, text: str, tags: list[str] | None = None, confidence: float | None = None,
    ) -> MessageCreateOut:
        op = _op_share(self.workspace_id, _require_agent(self.agent_id), text, tags or [], confidence=confidence)
        r = await self._do(op)
        return MessageCreateOut.model_validate(r.json())

    async def read(self, since: int = 0, limit: int = 500) -> list[MessageOut]:
        r = await self._do(_op_read(self.workspace_id, since, limit))
        return [MessageOut.model_validate(item) for item in r.json()]

    async def edit(
        self,
        msg_id: int,
        *,
        text: str | None | Any = _UNSET,
        tags: list[str] | None | Any = _UNSET,
        confidence: float | None | Any = _UNSET,
    ) -> MessageOut:
        fields: set[str] = set()
        if text is not _UNSET:
            fields.add("text")
        if tags is not _UNSET:
            fields.add("tags")
        if confidence is not _UNSET:
            fields.add("confidence")
        op = _op_edit(
            self.workspace_id, msg_id,
            text if text is not _UNSET else None,
            tags if tags is not _UNSET else None,
            confidence if confidence is not _UNSET else None,
            fields,
        )
        r = await self._do(op)
        return MessageOut.model_validate(r.json())

    async def delete(self, msg_id: int) -> None:
        await self._do(_op_delete(self.workspace_id, msg_id))

    async def add_comment(self, msg_id: int, text: str) -> CommentOut:
        op = _op_add_comment(self.workspace_id, msg_id, _require_agent(self.agent_id), text)
        r = await self._do(op)
        return CommentOut.model_validate(r.json())

    async def list_comments(self, msg_id: int) -> list[CommentOut]:
        r = await self._do(_op_list_comments(self.workspace_id, msg_id))
        return [CommentOut.model_validate(item) for item in r.json()]

    async def aclose(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> AsyncMemorizedClient:
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.aclose()
