"""SQLite persistence: engine, tables, and CRUD helpers.

The ``Database`` class owns the async engine + session maker. ``Workspace``
and ``Message`` are the only two tables. The CRUD helpers are plain async
functions so unit tests can drive them against an in-memory aiosqlite DB
without needing FastAPI.
"""
from __future__ import annotations

import time
from pathlib import Path
from typing import Any

import json

from sqlalchemy import JSON, Column, text
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.pool import NullPool
from sqlmodel import Field, SQLModel, select
from sqlmodel.ext.asyncio.session import AsyncSession

from memorized.exceptions import NotFoundError




# ---------------------------------------------------------------------------
# Tables
# ---------------------------------------------------------------------------


class Workspace(SQLModel, table=True):
    """One problem / task / session. Acts as a namespace for everything else."""

    __tablename__ = "workspaces"

    id: str = Field(primary_key=True)
    meta: dict[str, Any] = Field(default_factory=dict, sa_column=Column("metadata", JSON))
    created_at: float = Field(default_factory=time.time)


class Message(SQLModel, table=True):
    """A single chat message posted to a workspace.

    The integer primary key doubles as the monotonic cursor used by clients:
    ``GET /messages?since=<id>`` returns every message with ``id > since``, in
    ascending order, so a restarted agent can replay the workspace history
    from ``since=0`` and then poll with the max id it has seen.
    """

    __tablename__ = "messages"

    id: int | None = Field(default=None, primary_key=True)
    workspace_id: str = Field(foreign_key="workspaces.id", index=True)
    agent_id: str
    text: str
    tags: list[str] = Field(default_factory=list, sa_column=Column(JSON))
    confidence: float | None = Field(default=None)
    ts: float = Field(default_factory=time.time)
    edited_at: float | None = Field(default=None)
    deleted: bool = Field(default=False)


class Comment(SQLModel, table=True):
    """A comment / annotation on a message."""

    __tablename__ = "comments"

    id: int | None = Field(default=None, primary_key=True)
    message_id: int = Field(foreign_key="messages.id", index=True)
    agent_id: str
    text: str
    ts: float = Field(default_factory=time.time)


# ---------------------------------------------------------------------------
# Database connection manager
# ---------------------------------------------------------------------------


_PRAGMAS = [
    "PRAGMA journal_mode = WAL",
    "PRAGMA synchronous = NORMAL",
    "PRAGMA foreign_keys = ON",
]

_FTS_STATEMENTS = [
    """
    CREATE VIRTUAL TABLE IF NOT EXISTS messages_fts USING fts5(
        text,
        content='messages',
        content_rowid='id',
        tokenize='porter unicode61'
    )
    """,
    """
    CREATE TRIGGER IF NOT EXISTS messages_ai AFTER INSERT ON messages BEGIN
        INSERT INTO messages_fts(rowid, text) VALUES (new.id, new.text);
    END
    """,
    """
    CREATE TRIGGER IF NOT EXISTS messages_ad AFTER DELETE ON messages BEGIN
        INSERT INTO messages_fts(messages_fts, rowid, text)
            VALUES('delete', old.id, old.text);
    END
    """,
    """
    CREATE TRIGGER IF NOT EXISTS messages_au AFTER UPDATE ON messages BEGIN
        INSERT INTO messages_fts(messages_fts, rowid, text)
            VALUES('delete', old.id, old.text);
        INSERT INTO messages_fts(rowid, text) VALUES (new.id, new.text);
    END
    """,
    "INSERT INTO messages_fts(messages_fts) VALUES('rebuild')",
]


class Database:
    """Owns the async engine + session maker. One instance per running app."""

    def __init__(self, db_path: Path | str) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._engine: AsyncEngine = create_async_engine(
            f"sqlite+aiosqlite:///{self.db_path}",
            future=True,
            echo=False,
            poolclass=NullPool,
        )
        self._sessionmaker: async_sessionmaker[AsyncSession] = async_sessionmaker(
            self._engine,
            class_=AsyncSession,
            expire_on_commit=False,
        )

    async def create_all(self) -> None:
        async with self._engine.begin() as conn:
            await conn.run_sync(SQLModel.metadata.create_all)
            for stmt in _PRAGMAS:
                await conn.exec_driver_sql(stmt)
            for stmt in _FTS_STATEMENTS:
                await conn.exec_driver_sql(stmt)

    async def dispose(self) -> None:
        await self._engine.dispose()

    def session(self) -> AsyncSession:
        return self._sessionmaker()


# ---------------------------------------------------------------------------
# CRUD helpers (pure async functions; unit-testable against an in-memory DB)
# ---------------------------------------------------------------------------


async def create_workspace(
    session: AsyncSession,
    *,
    id: str,
    metadata: dict[str, Any] | None = None,
) -> Workspace:
    stmt = select(Workspace).where(Workspace.id == id)
    existing = (await session.exec(stmt)).first()
    if existing is not None:
        return existing
    ws = Workspace(id=id, meta=metadata or {})
    session.add(ws)
    await session.flush()
    return ws


async def list_workspaces(session: AsyncSession) -> list[Workspace]:
    stmt = select(Workspace).order_by(Workspace.created_at.desc())
    return list((await session.exec(stmt)).all())


async def ensure_workspace(session: AsyncSession, workspace_id: str) -> None:
    """Raise ``NotFoundError`` if the workspace does not exist."""
    stmt = select(Workspace.id).where(Workspace.id == workspace_id)
    if (await session.exec(stmt)).first() is None:
        raise NotFoundError.workspace(workspace_id)


async def create_message(
    session: AsyncSession,
    *,
    workspace_id: str,
    agent_id: str,
    text: str,
    tags: list[str],
    confidence: float | None = None,
) -> Message:
    msg = Message(
        workspace_id=workspace_id,
        agent_id=agent_id,
        text=text,
        tags=tags,
        confidence=confidence,
    )
    session.add(msg)
    await session.flush()
    return msg


async def list_messages(
    session: AsyncSession,
    *,
    workspace_id: str,
    since: int = 0,
    limit: int = 500,
) -> list[Message]:
    stmt = (
        select(Message)
        .where(Message.workspace_id == workspace_id)
        .where(Message.id > since)
        .where(Message.deleted == False)  # noqa: E712
        .order_by(Message.id)
        .limit(limit)
    )
    return list((await session.exec(stmt)).all())


def _build_fts_query(raw: str) -> str:
    tokens = raw.split()
    if not tokens:
        return ""
    return " ".join(f'"{t.replace(chr(34), chr(34)*2)}"*' for t in tokens)


async def search_messages(
    session: AsyncSession,
    *,
    workspace_id: str,
    q: str | None = None,
    tags: list[str] | None = None,
    since: int = 0,
    limit: int = 500,
) -> list[Message]:
    tags = tags or []
    fts_query = _build_fts_query(q) if q else ""

    if not fts_query and not tags:
        return await list_messages(
            session, workspace_id=workspace_id, since=since, limit=limit
        )

    clauses: list[str] = [
        "m.workspace_id = :workspace_id",
        "m.id > :since",
        "m.deleted = 0",
    ]
    params: dict[str, object] = {
        "workspace_id": workspace_id,
        "since": since,
        "limit": limit,
    }

    if fts_query:
        clauses.append("m.id IN (SELECT rowid FROM messages_fts WHERE messages_fts MATCH :fts_query)")
        params["fts_query"] = fts_query

    for i, tag in enumerate(tags):
        key = f"tag_{i}"
        clauses.append(
            f"EXISTS (SELECT 1 FROM json_each(m.tags) WHERE value = :{key})"
        )
        params[key] = tag

    where = " AND ".join(clauses)
    sql = text(
        f"SELECT m.id, m.workspace_id, m.agent_id, m.text, m.tags, "
        f"m.confidence, m.ts, m.edited_at, m.deleted "
        f"FROM messages m WHERE {where} ORDER BY m.id LIMIT :limit"
    )

    conn = await session.connection()
    rows = (await conn.execute(sql, params)).fetchall()
    return [
        Message(
            id=r.id,
            workspace_id=r.workspace_id,
            agent_id=r.agent_id,
            text=r.text,
            tags=json.loads(r.tags) if isinstance(r.tags, str) else r.tags,
            confidence=r.confidence,
            ts=r.ts,
            edited_at=r.edited_at,
            deleted=bool(r.deleted),
        )
        for r in rows
    ]


async def get_message(
    session: AsyncSession,
    *,
    workspace_id: str,
    message_id: int,
) -> Message:
    """Fetch a single message by ID, scoped to the workspace.

    Raises ``NotFoundError`` if the message does not exist or belongs to a
    different workspace.
    """
    stmt = (
        select(Message)
        .where(Message.id == message_id)
        .where(Message.workspace_id == workspace_id)
    )
    msg = (await session.exec(stmt)).first()
    if msg is None:
        raise NotFoundError.for_message(message_id)
    return msg


async def update_message(
    session: AsyncSession,
    *,
    workspace_id: str,
    message_id: int,
    text: str | None = None,
    tags: list[str] | None = None,
    confidence: float | None = None,
    fields_set: set[str] | None = None,
) -> Message:
    """Partial update of a message. Only fields present in *fields_set* are
    applied so that ``None`` can be distinguished from "not provided"."""
    fields_set = fields_set or set()
    msg = await get_message(session, workspace_id=workspace_id, message_id=message_id)
    if "text" in fields_set and text is not None:
        msg.text = text
    if "tags" in fields_set and tags is not None:
        msg.tags = tags
    if "confidence" in fields_set:
        msg.confidence = confidence
    msg.edited_at = time.time()
    session.add(msg)
    await session.flush()
    return msg


async def delete_message(
    session: AsyncSession,
    *,
    workspace_id: str,
    message_id: int,
) -> Message:
    """Soft-delete a message. The row stays so the monotonic cursor is
    preserved, but the text is wiped and the ``deleted`` flag is set."""
    msg = await get_message(session, workspace_id=workspace_id, message_id=message_id)
    msg.deleted = True
    msg.text = "[deleted]"
    session.add(msg)
    await session.flush()
    return msg


async def create_comment(
    session: AsyncSession,
    *,
    message_id: int,
    agent_id: str,
    text: str,
) -> Comment:
    comment = Comment(message_id=message_id, agent_id=agent_id, text=text)
    session.add(comment)
    await session.flush()
    return comment


async def list_comments(
    session: AsyncSession,
    *,
    message_id: int,
) -> list[Comment]:
    stmt = (
        select(Comment)
        .where(Comment.message_id == message_id)
        .order_by(Comment.id)
    )
    return list((await session.exec(stmt)).all())
