"""HTTP route handlers.

Two small routers — workspaces and messages — that thinly adapt the CRUD
helpers in ``db.py`` to the pydantic wire schemas. FastAPI dependencies for
database, session, and workspace existence are defined at the top of the
file; there is no separate ``deps.py`` because deps are thirty lines.
"""
from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Annotated

from fastapi import APIRouter, Depends, Query, Request
from sqlmodel.ext.asyncio.session import AsyncSession

from memorized.schemas import (
    CommentIn,
    CommentOut,
    MessageCreateOut,
    MessageIn,
    MessageOut,
    MessageUpdate,
    WorkspaceCreate,
    WorkspaceOut,
)
from memorized.server import db

# ---------------------------------------------------------------------------
# Dependencies
# ---------------------------------------------------------------------------


def get_database(request: Request) -> db.Database:
    """Return the app-wide ``Database`` instance.

    Exposed as its own dependency (instead of reading ``request.app.state``
    inline inside ``get_session``) so tests can swap it via
    ``app.dependency_overrides[get_database] = ...`` if they ever need to.
    """
    return request.app.state.db


DbDep = Annotated[db.Database, Depends(get_database)]


async def get_session(database: DbDep) -> AsyncIterator[AsyncSession]:
    """Yield a session scoped to one request.

    Commits are the handler's responsibility and MUST happen before the
    handler returns — FastAPI runs this dependency's post-yield cleanup
    *after* the response has been delivered, so a commit here would not
    be visible to the client's next request. We only roll back on
    exception and close the session on exit.
    """
    async with database.session() as session:
        try:
            yield session
        except Exception:
            await session.rollback()
            raise


SessionDep = Annotated[AsyncSession, Depends(get_session)]


async def ensure_workspace(ws: str, session: SessionDep) -> str:
    await db.ensure_workspace(session, ws)
    return ws


WorkspaceDep = Annotated[str, Depends(ensure_workspace)]


# ---------------------------------------------------------------------------
# Workspaces
# ---------------------------------------------------------------------------


workspaces_router = APIRouter(prefix="/workspaces", tags=["workspaces"])


@workspaces_router.post("", response_model=WorkspaceOut)
async def post_workspace(body: WorkspaceCreate, session: SessionDep) -> WorkspaceOut:
    ws = await db.create_workspace(session, id=body.id, metadata=body.metadata)
    await session.commit()
    return WorkspaceOut(id=ws.id, metadata=ws.meta, created_at=ws.created_at)


@workspaces_router.get("", response_model=list[WorkspaceOut])
async def get_workspaces(session: SessionDep) -> list[WorkspaceOut]:
    rows = await db.list_workspaces(session)
    return [WorkspaceOut(id=w.id, metadata=w.meta, created_at=w.created_at) for w in rows]


# ---------------------------------------------------------------------------
# Messages
# ---------------------------------------------------------------------------


messages_router = APIRouter(prefix="/workspaces/{ws}/messages", tags=["messages"])


def _to_out(m: db.Message) -> MessageOut:
    if m.id is None:
        raise ValueError("persisted Message must have an id")
    return MessageOut(
        id=m.id,
        agent_id=m.agent_id,
        text=m.text,
        tags=m.tags,
        confidence=m.confidence,
        ts=m.ts,
        edited_at=m.edited_at,
        deleted=m.deleted,
    )


@messages_router.post("", response_model=MessageCreateOut)
async def post_message(
    body: MessageIn,
    ws: WorkspaceDep,
    session: SessionDep,
) -> MessageCreateOut:
    msg = await db.create_message(
        session,
        workspace_id=ws,
        agent_id=body.agent_id,
        text=body.text,
        tags=body.tags,
        confidence=body.confidence,
    )
    await session.commit()
    if msg.id is None:
        raise ValueError("persisted Message must have an id")
    return MessageCreateOut(id=msg.id)


@messages_router.get("", response_model=list[MessageOut])
async def get_messages(
    ws: WorkspaceDep,
    session: SessionDep,
    since: int = Query(default=0, ge=0),
    limit: int = Query(default=500, ge=1, le=2000),
    q: str | None = Query(default=None, max_length=500),
    tags: list[str] = Query(default_factory=list),
) -> list[MessageOut]:
    if q or tags:
        rows = await db.search_messages(
            session, workspace_id=ws, q=q, tags=tags, since=since, limit=limit,
        )
    else:
        rows = await db.list_messages(
            session, workspace_id=ws, since=since, limit=limit,
        )
    return [_to_out(m) for m in rows]


@messages_router.patch("/{msg_id}", response_model=MessageOut)
async def patch_message(
    msg_id: int,
    body: MessageUpdate,
    ws: WorkspaceDep,
    session: SessionDep,
) -> MessageOut:
    msg = await db.update_message(
        session,
        workspace_id=ws,
        message_id=msg_id,
        text=body.text,
        tags=body.tags,
        confidence=body.confidence,
        fields_set=body.model_fields_set,
    )
    await session.commit()
    return _to_out(msg)


@messages_router.delete("/{msg_id}", status_code=204)
async def delete_message(
    msg_id: int,
    ws: WorkspaceDep,
    session: SessionDep,
) -> None:
    await db.delete_message(session, workspace_id=ws, message_id=msg_id)
    await session.commit()


# ---------------------------------------------------------------------------
# Comments
# ---------------------------------------------------------------------------


def _comment_out(c: db.Comment) -> CommentOut:
    assert c.id is not None
    return CommentOut(
        id=c.id,
        message_id=c.message_id,
        agent_id=c.agent_id,
        text=c.text,
        ts=c.ts,
    )


@messages_router.post("/{msg_id}/comments", response_model=CommentOut)
async def post_comment(
    msg_id: int,
    body: CommentIn,
    ws: WorkspaceDep,
    session: SessionDep,
) -> CommentOut:
    await db.get_message(session, workspace_id=ws, message_id=msg_id)
    comment = await db.create_comment(
        session, message_id=msg_id, agent_id=body.agent_id, text=body.text,
    )
    await session.commit()
    return _comment_out(comment)


@messages_router.get("/{msg_id}/comments", response_model=list[CommentOut])
async def get_comments(
    msg_id: int,
    ws: WorkspaceDep,
    session: SessionDep,
) -> list[CommentOut]:
    await db.get_message(session, workspace_id=ws, message_id=msg_id)
    rows = await db.list_comments(session, message_id=msg_id)
    return [_comment_out(c) for c in rows]
