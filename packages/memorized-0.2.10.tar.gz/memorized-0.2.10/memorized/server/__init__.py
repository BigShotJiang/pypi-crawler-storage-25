"""FastAPI app factory + unified exception handling.

``create_app(settings)`` builds a fully-wired FastAPI application with:
  - SQLite database bootstrapped via lifespan
  - two routers (workspaces + messages)
  - static Web UI mounted at ``/ui/``
  - a single pipeline that renders every error — ours, pydantic's, Starlette's,
    unhandled — into the shared ``ErrorBody`` envelope
"""
from __future__ import annotations

import logging
import secrets
import traceback
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from http import HTTPStatus
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.middleware.base import BaseHTTPMiddleware

from memorized.exceptions import AuthenticationError, MemorizedError, ValidationError
from memorized.schemas import ErrorBody, ErrorCode, ErrorResponse, FieldError
from memorized.server.config import Settings
from memorized.server.db import Database
from memorized.server.routes import messages_router, workspaces_router

STATIC_DIR = Path(__file__).parent / "static"

_PUBLIC_PREFIXES = ("/ui", "/docs", "/redoc", "/openapi.json", "/favicon")


class _BearerAuthMiddleware(BaseHTTPMiddleware):
    """Reject API requests when ``settings.api_key`` is set and the caller
    does not present a matching ``Authorization: Bearer <key>`` header.

    Static UI assets and docs pages are exempt so the browser can load them
    without a token.
    """

    async def dispatch(self, request: Request, call_next):  # type: ignore[override]
        api_key: str | None = request.app.state.settings.api_key
        if api_key is not None:
            path = request.url.path
            if path == "/" or path.startswith(_PUBLIC_PREFIXES):
                return await call_next(request)
            auth = request.headers.get("authorization", "")
            scheme, _, token = auth.partition(" ")
            if scheme.lower() != "bearer" or not secrets.compare_digest(token, api_key):
                exc = AuthenticationError.missing_or_invalid()
                return _envelope(exc.to_body())
        return await call_next(request)

_STATUS_TO_CODE: dict[int, ErrorCode] = {
    HTTPStatus.NOT_FOUND: ErrorCode.not_found,
    HTTPStatus.METHOD_NOT_ALLOWED: ErrorCode.method_not_allowed,
    HTTPStatus.BAD_REQUEST: ErrorCode.bad_request,
}


def _envelope(body: ErrorBody) -> JSONResponse:
    return JSONResponse(
        status_code=body.status,
        content=ErrorResponse(error=body).model_dump(mode="json"),
    )


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or Settings()
    database = Database(settings.db_path)

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        await database.create_all()
        app.state.db = database
        app.state.settings = settings
        try:
            yield
        finally:
            await database.dispose()

    app = FastAPI(title="memorized", version="0.1.0", lifespan=lifespan)
    app.add_middleware(_BearerAuthMiddleware)
    logger = logging.getLogger("memorized.server")

    @app.exception_handler(MemorizedError)
    async def _memorized_error(_: Request, exc: MemorizedError) -> JSONResponse:
        return _envelope(exc.to_body())

    @app.exception_handler(RequestValidationError)
    async def _request_validation(
        _: Request, exc: RequestValidationError
    ) -> JSONResponse:
        # Reshape pydantic errors into compact FieldError entries. We drop
        # `input` because it can echo back large request bodies, which is
        # noise in an LLM's context window.
        fields = [
            FieldError(
                loc=".".join(str(x) for x in err["loc"]),
                msg=err["msg"],
                type=err["type"],
            )
            for err in exc.errors()
        ]
        err = ValidationError.from_fields(
            f"Request validation failed ({len(fields)} field error(s)).",
            fields,
        )
        return _envelope(err.to_body())

    @app.exception_handler(StarletteHTTPException)
    async def _starlette_http(_: Request, exc: StarletteHTTPException) -> JSONResponse:
        code = _STATUS_TO_CODE.get(exc.status_code, ErrorCode.bad_request)
        message = exc.detail if isinstance(exc.detail, str) else str(exc.detail)
        return _envelope(
            ErrorBody(code=code, message=message, status=exc.status_code)
        )

    @app.exception_handler(Exception)
    async def _unhandled(request: Request, exc: Exception) -> JSONResponse:
        tb = traceback.format_exc()
        logger.error("Unhandled error on %s %s\n%s", request.method, request.url.path, tb)
        context: dict[str, object] = {}
        if settings.debug:
            context["exception_type"] = type(exc).__name__
            context["traceback"] = tb.splitlines()
        return _envelope(
            ErrorBody(
                code=ErrorCode.internal_error,
                message="Internal server error.",
                status=HTTPStatus.INTERNAL_SERVER_ERROR,
                hint=(
                    "This is a bug in the server. Set MEMORIZED_DEBUG=true to see "
                    "the traceback in the response body, or check the server logs."
                ),
                context=context,
            )
        )

    app.include_router(workspaces_router)
    app.include_router(messages_router)

    if STATIC_DIR.exists():
        app.mount("/ui", StaticFiles(directory=STATIC_DIR, html=True), name="ui")

    @app.get("/", include_in_schema=False)
    async def _root() -> RedirectResponse:
        return RedirectResponse("/ui/")

    return app


__all__ = ["Settings", "create_app"]
