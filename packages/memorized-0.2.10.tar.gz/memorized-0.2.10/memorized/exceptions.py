"""Unified exception hierarchy for both the server and the SDK.

Server route handlers raise ``MemorizedError`` (or a subclass) directly;
the FastAPI exception handler in ``memorized.server`` renders it into the
shared ``ErrorBody`` envelope. On the client side, ``raise_for_response``
parses that same envelope back into a ``MemorizedError`` subclass so a
failing call looks like a native Python exception.

One hierarchy on both sides means there is no "server error" / "client
error" impedance mismatch — the exception raised inside a route handler
is literally the same class the SDK caller catches.

``MemorizedError`` stores its state in a single ``ErrorBody`` and exposes
read-only properties for ``code`` / ``status`` / ``message`` / ``hint`` /
``context`` / ``fields``. Constructors for concrete errors live on the
subclasses as classmethods so callers never have to hand-build an
``ErrorBody``.
"""
from __future__ import annotations

from http import HTTPStatus
from typing import Any

import httpx

from memorized.schemas import ErrorBody, ErrorCode, ErrorResponse, FieldError


class MemorizedError(Exception):
    """Base class. Every error (server-side or client-side) is one of these."""

    def __init__(self, body: ErrorBody) -> None:
        super().__init__(self._format(body))
        self.body = body

    @staticmethod
    def _format(body: ErrorBody) -> str:
        out = f"[{body.code.value}] {body.message}"
        return f"{out} — {body.hint}" if body.hint else out

    @property
    def code(self) -> ErrorCode:
        return self.body.code

    @property
    def status(self) -> int:
        return self.body.status

    @property
    def message(self) -> str:
        return self.body.message

    @property
    def hint(self) -> str | None:
        return self.body.hint

    @property
    def context(self) -> dict[str, Any]:
        return self.body.context

    @property
    def fields(self) -> list[FieldError]:
        return self.body.fields

    def to_body(self) -> ErrorBody:
        return self.body


class NotFoundError(MemorizedError):
    """404 — workspace or other resource does not exist."""

    @classmethod
    def workspace(cls, workspace_id: str) -> NotFoundError:
        return cls(
            ErrorBody(
                code=ErrorCode.workspace_not_found,
                message=f"workspace {workspace_id} not found",
                status=HTTPStatus.NOT_FOUND,
                hint="Call POST /workspaces to create one, or GET /workspaces to list existing.",
                context={"workspace_id": workspace_id},
            )
        )

    @classmethod
    def for_message(cls, message_id: int) -> NotFoundError:
        return cls(
            ErrorBody(
                code=ErrorCode.not_found,
                message=f"message {message_id} not found",
                status=HTTPStatus.NOT_FOUND,
                hint="Check the message id and workspace.",
                context={"message_id": message_id},
            )
        )


class ValidationError(MemorizedError):
    """422 — request body failed validation. ``.fields`` lists each bad field."""

    @classmethod
    def from_fields(cls, message: str, fields: list[FieldError]) -> ValidationError:
        return cls(
            ErrorBody(
                code=ErrorCode.validation_error,
                message=message,
                status=HTTPStatus.UNPROCESSABLE_ENTITY,
                hint=(
                    "Fix the fields listed in `fields`; each entry has a dot-path "
                    "`loc` and a pydantic `type`."
                ),
                fields=fields,
            )
        )


class AuthenticationError(MemorizedError):
    """401 — missing or invalid API key."""

    @classmethod
    def missing_or_invalid(cls) -> AuthenticationError:
        return cls(
            ErrorBody(
                code=ErrorCode.unauthorized,
                message="Missing or invalid API key.",
                status=HTTPStatus.UNAUTHORIZED,
                hint="Set the Authorization header to 'Bearer <your-api-key>'.",
            )
        )


class TransportError(MemorizedError):
    """Client-side: the request never reached a server."""

    @classmethod
    def from_httpx(cls, exc: httpx.HTTPError, *, base_url: str) -> TransportError:
        return cls(
            ErrorBody(
                code=ErrorCode.transport_error,
                message=f"{type(exc).__name__}: {exc}",
                status=0,
                hint=(
                    f"Could not reach the memorized server at {base_url}. "
                    "Check the base URL and that the server is running."
                ),
                context={"base_url": base_url},
            )
        )


_CODE_TO_CLASS: dict[ErrorCode, type[MemorizedError]] = {
    ErrorCode.workspace_not_found: NotFoundError,
    ErrorCode.not_found: NotFoundError,
    ErrorCode.validation_error: ValidationError,
    ErrorCode.unauthorized: AuthenticationError,
    ErrorCode.transport_error: TransportError,
}


def _from_body(body: ErrorBody) -> MemorizedError:
    cls = _CODE_TO_CLASS.get(body.code, MemorizedError)
    return cls(body)


def _parse_body(response: httpx.Response) -> ErrorBody:
    """Best-effort parse. Falls back to a synthesized envelope if the server
    returned something that isn't our shape (a proxy's plain-text 502, for
    example)."""
    try:
        return ErrorResponse.model_validate(response.json()).error
    except (ValueError, KeyError, TypeError):
        status = response.status_code
        code = _status_to_code(status)
        text = (response.text or "").strip()[:500]
        return ErrorBody(
            code=code,
            message=text or f"HTTP {status} from server",
            status=status,
            hint="Server did not return a structured error envelope — the body may be raw text.",
        )


def _status_to_code(status: int) -> ErrorCode:
    if status == HTTPStatus.NOT_FOUND:
        return ErrorCode.not_found
    if status == HTTPStatus.UNAUTHORIZED:
        return ErrorCode.unauthorized
    if status == HTTPStatus.METHOD_NOT_ALLOWED:
        return ErrorCode.method_not_allowed
    if HTTPStatus.BAD_REQUEST <= status < HTTPStatus.INTERNAL_SERVER_ERROR:
        return ErrorCode.bad_request
    return ErrorCode.internal_error


def raise_for_response(response: httpx.Response) -> None:
    """Drop-in replacement for ``response.raise_for_status()``."""
    if response.is_success:
        return
    raise _from_body(_parse_body(response))


def wrap_transport_error(exc: httpx.HTTPError, *, base_url: str) -> TransportError:
    return TransportError.from_httpx(exc, base_url=base_url)
