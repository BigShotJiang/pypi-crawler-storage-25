"""memorized — shared memory for collaborating multi-agent systems.

Each problem gets one workspace. Every agent can ``share`` a finding
(with an optional confidence score) and ``read`` back everything its
teammates have posted. That is the agent-facing product — two operations.

Human administrators can additionally edit, delete, and comment on
messages via the HTTP API, CLI, or Web UI.

    from memorized import MemorizedClient

    with MemorizedClient(base_url, ws_id, agent_id="agent:worker:1") as mem:
        history = mem.read(since=0)
        mem.share("finished ingesting q3.csv: 128k rows", tags=["result"], confidence=0.9)
        new = mem.read(since=history[-1].id if history else 0)
"""
from __future__ import annotations

from memorized.client import AsyncMemorizedClient, MemorizedClient
from memorized.exceptions import (
    MemorizedError,
    NotFoundError,
    TransportError,
    ValidationError,
)
from memorized.schemas import (
    CommentIn,
    CommentOut,
    ErrorBody,
    ErrorCode,
    ErrorResponse,
    FieldError,
    MessageCreateOut,
    MessageIn,
    MessageOut,
    MessageUpdate,
    WorkspaceCreate,
    WorkspaceOut,
)

__version__ = "0.2.0"

__all__ = [
    "AsyncMemorizedClient",
    "CommentIn",
    "CommentOut",
    "ErrorBody",
    "ErrorCode",
    "ErrorResponse",
    "FieldError",
    "MemorizedClient",
    "MemorizedError",
    "MessageCreateOut",
    "MessageIn",
    "MessageOut",
    "MessageUpdate",
    "NotFoundError",
    "TransportError",
    "ValidationError",
    "WorkspaceCreate",
    "WorkspaceOut",
]
