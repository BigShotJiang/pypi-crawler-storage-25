"""Wire schemas shared by every layer (server, client, MCP, CLI).

Pure pydantic — no FastAPI, no SQLModel, no httpx imports — so both sides of
the wire (server handlers and client parsers) can speak the same types
without pulling in each other's frameworks.
"""
from __future__ import annotations

from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class ErrorCode(StrEnum):
    validation_error = "validation_error"
    workspace_not_found = "workspace_not_found"
    not_found = "not_found"
    method_not_allowed = "method_not_allowed"
    bad_request = "bad_request"
    unauthorized = "unauthorized"
    transport_error = "transport_error"
    internal_error = "internal_error"


class FieldError(BaseModel):
    """One pydantic validation failure, reshaped for agent consumption."""

    loc: str
    msg: str
    type: str


class ErrorBody(BaseModel):
    code: ErrorCode
    message: str
    status: int
    hint: str | None = None
    context: dict[str, Any] = Field(default_factory=dict)
    fields: list[FieldError] = Field(default_factory=list)


class ErrorResponse(BaseModel):
    error: ErrorBody


# ---------------------------------------------------------------------------
# Workspaces
# ---------------------------------------------------------------------------


class WorkspaceCreate(BaseModel):
    id: str = Field(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9_\-\.]+$")
    metadata: dict[str, Any] = Field(default_factory=dict)


class WorkspaceOut(BaseModel):
    id: str
    metadata: dict[str, Any]
    created_at: float


# ---------------------------------------------------------------------------
# Messages
# ---------------------------------------------------------------------------


class MessageIn(BaseModel):
    agent_id: str = Field(min_length=1)
    text: str = Field(min_length=1)
    tags: list[str] = Field(default_factory=list)
    confidence: float | None = Field(default=None, ge=0.0, le=1.0)


class MessageUpdate(BaseModel):
    """Partial update — only fields present in the request body are applied."""

    text: str | None = Field(default=None, min_length=1)
    tags: list[str] | None = None
    confidence: float | None = Field(default=None, ge=0.0, le=1.0)


class MessageOut(BaseModel):
    id: int
    agent_id: str
    text: str
    tags: list[str]
    confidence: float | None = None
    ts: float
    edited_at: float | None = None
    deleted: bool = False


class MessageCreateOut(BaseModel):
    id: int


# ---------------------------------------------------------------------------
# Comments
# ---------------------------------------------------------------------------


class CommentIn(BaseModel):
    agent_id: str = Field(min_length=1)
    text: str = Field(min_length=1)


class CommentOut(BaseModel):
    id: int
    message_id: int
    agent_id: str
    text: str
    ts: float
