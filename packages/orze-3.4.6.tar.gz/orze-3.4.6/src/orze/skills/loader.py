"""Skill loader — composable prompt fragments for Orze roles.

CALLING SPEC:
    compose_skills(role_cfg, project_root, template_vars=None) -> str
        role_cfg:       dict with a 'skills' list
        project_root:   Path to project directory
        template_vars:  dict of {key: value} for substitution, or None to skip
        returns:        composed prompt string

    load_builtin(name) -> Skill
        name: one of 'core', 'research', 'ops', 'setup'
        returns: Skill namedtuple(name, content)
        raises: FileNotFoundError if name is unknown

SKILLS GRAMMAR:
    role_cfg['skills'] is a list of references in composition order.
    Each ref is one of:
      - '@core' | '@research' | '@ops' | '@setup'
            built-in .skill.md shipped with orze.
      - '@sop:<name>'
            static SOP bundled in orze-pro (orze_pro/sops/<name>.skill.md).
            Resolved via optional import of orze_pro.skills.bundled; if
            orze-pro is not installed the ref is skipped with a warning.
      - './path.md' | 'path.md'
            project-local file relative to project_root. Used for dynamic
            (project-authored) SOPs or free-form prompt fragments.

    Skills declaring frontmatter 'order' are sorted ascending; skills
    declaring 'trigger' are gated by the role's _trigger_context. The
    composed output substitutes template_vars if provided.
"""

import logging
from collections import namedtuple
from pathlib import Path
from typing import Dict, List, Optional

import yaml

logger = logging.getLogger("orze")

Skill = namedtuple("Skill", ["name", "content"])

_SKILLS_DIR = Path(__file__).parent

# Valid built-in skill names
_BUILTINS = {"core", "research", "ops", "setup"}


def parse_frontmatter(text: str) -> tuple:
    """Split ---yaml--- header from content.

    Returns (meta_dict, body_str). If no frontmatter, returns ({}, text).
    """
    if not text.startswith("---"):
        return {}, text
    parts = text.split("---", 2)
    if len(parts) < 3:
        return {}, text
    try:
        meta = yaml.safe_load(parts[1]) or {}
    except yaml.YAMLError:
        meta = {}
    return meta, parts[2].strip()


def load_builtin(name: str) -> Skill:
    """Load a built-in skill from this package's .skill.md files."""
    if name not in _BUILTINS:
        raise FileNotFoundError(
            f"Unknown built-in skill '@{name}'. "
            f"Available: {', '.join(sorted('@' + b for b in _BUILTINS))}")
    path = _SKILLS_DIR / f"{name}.skill.md"
    if not path.exists():
        raise FileNotFoundError(f"Built-in skill file not found: {path}")
    text = path.read_text(encoding="utf-8")
    meta, body = parse_frontmatter(text)
    return Skill(name=meta.get("name", name), content=body)


def load_file(path: Path) -> Skill:
    """Load a skill from a project file.

    Plain .md without frontmatter gets name from filename stem.
    """
    if not path.exists():
        raise FileNotFoundError(f"Skill file not found: {path}")
    text = path.read_text(encoding="utf-8")
    meta, body = parse_frontmatter(text)
    name = meta.get("name", path.stem)
    return Skill(name=name, content=body)


def _substitute(text: str, template_vars: Dict[str, str]) -> str:
    """Safe template var substitution using str.replace."""
    for k, v in template_vars.items():
        text = text.replace(f"{{{k}}}", str(v))
    return text


def compose_skills(role_cfg: dict, project_root: Path,
                   template_vars: Optional[Dict[str, str]] = None) -> str:
    """Compose the prompt string from role_cfg['skills'].

    Returns "" when the role declares no skills. Every role that uses
    a Claude or research-agent prompt must declare a skills list.
    """
    if "skills" not in role_cfg:
        return ""

    # Skills path: compose from list, honoring frontmatter ``order`` and
    # ``trigger`` gates.
    skills_list = role_cfg["skills"]
    if not isinstance(skills_list, list):
        logger.warning("'skills' must be a list, got %s", type(skills_list).__name__)
        return ""

    loaded_with_meta: List[tuple] = []  # [(Skill, meta_dict)]
    for ref in skills_list:
        ref = str(ref).strip()
        if ref.startswith("@sop:"):
            # Bundled SOP from orze-pro (tier 1, static).
            # Delegated import so orze (basic) has no hard dependency on
            # orze-pro (pro feature).
            name = ref[len("@sop:"):]
            try:
                from orze_pro.skills.bundled import load_bundled_skill
            except ImportError:
                logger.warning("Skill %s: orze-pro not installed, "
                               "bundled SOPs unavailable", ref)
                continue
            try:
                text, path = load_bundled_skill(name)
                meta, body = parse_frontmatter(text)
                skill = Skill(name=meta.get("name", path.stem.replace(
                    ".skill", "")), content=body)
                loaded_with_meta.append((skill, meta))
            except FileNotFoundError as e:
                logger.warning("Skill %s: %s", ref, e)
        elif ref.startswith("@"):
            name = ref[1:]
            try:
                loaded_with_meta.append((load_builtin(name), {}))
            except FileNotFoundError as e:
                logger.warning("Skill %s: %s", ref, e)
        else:
            path = Path(ref)
            if not path.is_absolute():
                path = project_root / path
            if not path.exists():
                logger.warning("Skill %s: file not found", ref)
                continue
            try:
                text = path.read_text(encoding="utf-8")
                meta, body = parse_frontmatter(text)
                skill = Skill(name=meta.get("name", path.stem), content=body)
                loaded_with_meta.append((skill, meta))
            except OSError as e:
                logger.warning("Skill %s: %s", ref, e)

    # Trigger gating: skills whose trigger evaluates False are omitted.
    # Role passes the evaluation context via role_cfg["_trigger_context"].
    try:
        from orze.skills.triggers import evaluate_trigger
    except ImportError:  # should not happen, but fail open
        evaluate_trigger = None  # type: ignore

    trigger_ctx = role_cfg.get("_trigger_context", {}) or {}
    gated: List[tuple] = []
    for skill, meta in loaded_with_meta:
        trig = meta.get("trigger") if meta else None
        if evaluate_trigger is None or trig is None:
            gated.append((skill, meta))
            continue
        try:
            if evaluate_trigger(trig, trigger_ctx):
                gated.append((skill, meta))
            else:
                logger.info("Skill %s gated out by trigger %r", skill.name, trig)
        except ValueError as e:
            logger.warning("Skill %s: unknown trigger %r (%s) — including",
                           skill.name, trig, e)
            gated.append((skill, meta))

    # Order sorting — lower ``order`` composed first.
    gated.sort(key=lambda pair: int((pair[1] or {}).get("order", 100)))

    if not gated:
        return ""

    sections = [skill.content for skill, _ in gated]
    composed = "\n\n---\n\n".join(sections)

    if template_vars:
        composed = _substitute(composed, template_vars)

    logger.info("Composed %d skills: %s",
                len(gated), ", ".join(s.name for s, _ in gated))
    return composed
