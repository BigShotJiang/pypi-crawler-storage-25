"""Provider-agnostic secret resolution service."""

from __future__ import annotations

from base64 import urlsafe_b64decode
from dataclasses import dataclass
from datetime import datetime, timezone
import json
import logging
from typing import Any, Dict, Optional, Protocol
from urllib import error as urllib_error
from urllib import parse as urllib_parse
from urllib import request as urllib_request
from uuid import UUID

from sqlalchemy.orm import Session

from preloop.config import settings
from preloop.models.crud.secret_reference import crud_secret_reference
from preloop.models.models.ai_model import AIModel
from preloop.models.models.secret_reference import SecretReference
from preloop.utils.encryption import decrypt_value, encrypt_value

logger = logging.getLogger(__name__)


LOCAL_ENCRYPTED_BACKEND = "local_encrypted"
VAULT_KV_V2_BACKEND = "vault_kv_v2"
OPENBAO_KV_V2_BACKEND = "openbao_kv_v2"
AI_MODEL_API_KEY_SECRET_KIND = "ai_model_api_key"
AI_MODEL_CREDENTIALS_SECRET_KIND = "ai_model_credentials"
OPENAI_CODEX_OAUTH_CREDENTIAL_TYPE = "oauth_openai_codex"
OPENAI_CODEX_CLIENT_ID = "app_EMoamEEZ73f0CkXaXp7hrann"
OPENAI_CODEX_TOKEN_URL = "https://auth.openai.com/oauth/token"
OPENAI_CODEX_JWT_CLAIM_PATH = "https://api.openai.com/auth"
OPENAI_CODEX_REFRESH_SKEW_MS = 60_000


@dataclass
class ResolvedSecret:
    """Resolved secret value plus non-sensitive metadata."""

    value: str
    backend_type: str
    secret_reference_id: Optional[UUID] = None


@dataclass
class ResolvedModelCredentials:
    """Resolved model credentials with logical type information."""

    credential_type: str
    backend_type: str
    value: Optional[str] = None
    payload: Optional[Dict[str, Any]] = None
    secret_reference_id: Optional[UUID] = None


class SecretBackend(Protocol):
    """Interface for secret backend adapters."""

    backend_type: str

    def validate_reference(
        self,
        *,
        external_ref: Optional[str],
        meta_data: Optional[dict],
    ) -> None:
        """Validate a backend-specific reference before storing it."""

    def resolve(self, secret_ref: SecretReference) -> str:
        """Resolve the secret value from the backend."""


class LocalEncryptedSecretBackend:
    """Local encrypted secret backend stored in the database."""

    backend_type = LOCAL_ENCRYPTED_BACKEND

    def validate_reference(
        self,
        *,
        external_ref: Optional[str],
        meta_data: Optional[dict],
    ) -> None:
        if external_ref:
            raise ValueError("local_encrypted backend does not accept external_ref")

    def resolve(self, secret_ref: SecretReference) -> str:
        if not secret_ref.encrypted_value:
            return ""
        return decrypt_value(secret_ref.encrypted_value)


class VaultKVV2SecretBackend:
    """Vault/OpenBao-compatible KV v2 secret backend."""

    def __init__(self, backend_type: str = VAULT_KV_V2_BACKEND) -> None:
        self.backend_type = backend_type

    def validate_reference(
        self,
        *,
        external_ref: Optional[str],
        meta_data: Optional[dict],
    ) -> None:
        if not settings.vault_kv_v2.is_configured:
            raise ValueError(
                f"{self.backend_type} backend is not configured on this Preloop instance"
            )
        if not external_ref:
            raise ValueError(f"{self.backend_type} requires credentials_external_ref")
        field = (meta_data or {}).get("field")
        if field is not None and not isinstance(field, str):
            raise ValueError("credentials_meta_data.field must be a string")
        self._normalize_external_ref(external_ref)

    def resolve(self, secret_ref: SecretReference) -> str:
        self.validate_reference(
            external_ref=secret_ref.external_ref,
            meta_data=secret_ref.meta_data,
        )
        path = self._build_secret_path(secret_ref.external_ref or "")
        payload = self._read_secret(path, secret_ref.meta_data or {})
        data = payload.get("data", {}).get("data", {})
        field = (secret_ref.meta_data or {}).get("field", "value")
        value = data.get(field)
        if value is None:
            raise ValueError(
                f"Secret field '{field}' not found for backend {self.backend_type}"
            )
        return str(value)

    def _build_secret_path(self, external_ref: str) -> str:
        raw_ref = self._normalize_external_ref(external_ref)
        prefix = settings.vault_kv_v2.path_prefix.strip().strip("/")
        path = f"{prefix}/{raw_ref}" if prefix else raw_ref
        return f"{settings.vault_kv_v2.mount.strip('/')}/data/{path}"

    @staticmethod
    def _normalize_external_ref(external_ref: str) -> str:
        raw_ref = external_ref.strip()
        if not raw_ref:
            raise ValueError("credentials_external_ref must not be empty")
        if raw_ref != urllib_parse.unquote(raw_ref):
            raise ValueError(
                "credentials_external_ref must not contain percent-encoded characters"
            )

        normalized_parts: list[str] = []
        for part in raw_ref.split("/"):
            normalized_part = part.strip()
            if normalized_part in {"", ".", ".."}:
                raise ValueError(
                    "credentials_external_ref must be a relative secret path "
                    "without empty or traversal segments"
                )
            if "\\" in normalized_part:
                raise ValueError(
                    "credentials_external_ref must use forward slashes only"
                )
            if any(ord(char) < 32 for char in normalized_part):
                raise ValueError(
                    "credentials_external_ref must not contain control characters"
                )
            normalized_parts.append(normalized_part)

        return "/".join(normalized_parts)

    def _read_secret(self, path: str, meta_data: dict) -> dict:
        base_url = settings.vault_kv_v2.url.rstrip("/")
        params = {}
        if meta_data.get("version") is not None:
            params["version"] = str(meta_data["version"])
        query = f"?{urllib_parse.urlencode(params)}" if params else ""
        url = f"{base_url}/v1/{path}{query}"
        req = urllib_request.Request(
            url,
            headers=self._build_headers(),
            method="GET",
        )
        ssl_context = None
        if not settings.vault_kv_v2.verify_tls:
            import ssl

            ssl_context = ssl._create_unverified_context()
        elif settings.vault_kv_v2.ca_cert_path:
            import ssl

            ssl_context = ssl.create_default_context(
                cafile=settings.vault_kv_v2.ca_cert_path
            )

        try:
            with urllib_request.urlopen(
                req,
                timeout=settings.vault_kv_v2.timeout_seconds,
                context=ssl_context,
            ) as response:
                import json

                return json.loads(response.read().decode("utf-8"))
        except urllib_error.HTTPError as exc:
            raise ValueError(
                f"{self.backend_type} secret lookup failed with status {exc.code}"
            ) from exc
        except urllib_error.URLError as exc:
            raise ValueError(
                f"{self.backend_type} secret lookup failed: {exc.reason}"
            ) from exc

    def _build_headers(self) -> dict[str, str]:
        headers = {"X-Vault-Token": settings.vault_kv_v2.token}
        if settings.vault_kv_v2.namespace:
            headers["X-Vault-Namespace"] = settings.vault_kv_v2.namespace
        return headers


class SecretService:
    """Secret storage and resolution service."""

    def __init__(self) -> None:
        self._backends: dict[str, SecretBackend] = {
            LOCAL_ENCRYPTED_BACKEND: LocalEncryptedSecretBackend(),
        }
        if settings.vault_kv_v2.is_configured:
            self._backends[VAULT_KV_V2_BACKEND] = VaultKVV2SecretBackend(
                VAULT_KV_V2_BACKEND
            )
            self._backends[OPENBAO_KV_V2_BACKEND] = VaultKVV2SecretBackend(
                OPENBAO_KV_V2_BACKEND
            )

    def create_local_secret_reference(
        self,
        db: Session,
        *,
        account_id: Optional[UUID],
        name: str,
        secret_kind: str,
        secret_value: str,
        existing_secret_id: Optional[UUID] = None,
        meta_data: Optional[dict] = None,
    ) -> SecretReference:
        """Create or update a locally encrypted secret reference."""
        encrypted_value = encrypt_value(secret_value)
        now = datetime.now(timezone.utc)

        if existing_secret_id:
            secret_ref = crud_secret_reference.get(db, id=existing_secret_id)
            if secret_ref:
                secret_ref.name = name
                secret_ref.backend_type = LOCAL_ENCRYPTED_BACKEND
                secret_ref.secret_kind = secret_kind
                secret_ref.encrypted_value = encrypted_value
                secret_ref.status = "active"
                secret_ref.last_verified_at = now
                secret_ref.meta_data = meta_data or {}
                db.add(secret_ref)
                db.commit()
                db.refresh(secret_ref)
                return secret_ref

        secret_ref = crud_secret_reference.create(
            db,
            obj_in={
                "account_id": account_id,
                "name": name,
                "backend_type": LOCAL_ENCRYPTED_BACKEND,
                "secret_kind": secret_kind,
                "encrypted_value": encrypted_value,
                "status": "active",
                "last_verified_at": now,
                "meta_data": meta_data or {},
                "created_at": now,
                "updated_at": now,
            },
        )
        return secret_ref

    def create_external_secret_reference(
        self,
        db: Session,
        *,
        account_id: Optional[UUID],
        name: str,
        secret_kind: str,
        backend_type: str,
        external_ref: str,
        meta_data: Optional[dict] = None,
        existing_secret_id: Optional[UUID] = None,
    ) -> SecretReference:
        """Create or update a secret reference backed by an external secret store."""
        backend = self._backends.get(backend_type)
        if not backend:
            raise ValueError(f"Unsupported secret backend: {backend_type}")
        backend.validate_reference(external_ref=external_ref, meta_data=meta_data)
        now = datetime.now(timezone.utc)

        if existing_secret_id:
            secret_ref = crud_secret_reference.get(db, id=existing_secret_id)
            if secret_ref:
                secret_ref.name = name
                secret_ref.backend_type = backend_type
                secret_ref.secret_kind = secret_kind
                secret_ref.encrypted_value = None
                secret_ref.external_ref = external_ref
                secret_ref.status = "active"
                secret_ref.last_verified_at = now
                secret_ref.meta_data = meta_data or {}
                db.add(secret_ref)
                db.commit()
                db.refresh(secret_ref)
                return secret_ref

        return crud_secret_reference.create(
            db,
            obj_in={
                "account_id": account_id,
                "name": name,
                "backend_type": backend_type,
                "secret_kind": secret_kind,
                "encrypted_value": None,
                "external_ref": external_ref,
                "status": "active",
                "last_verified_at": now,
                "meta_data": meta_data or {},
                "created_at": now,
                "updated_at": now,
            },
        )

    def resolve_secret_reference(self, secret_ref: SecretReference) -> ResolvedSecret:
        """Resolve a secret from its backend."""
        backend = self._backends.get(secret_ref.backend_type)
        if not backend:
            raise ValueError(f"Unsupported secret backend: {secret_ref.backend_type}")

        value = backend.resolve(secret_ref)
        return ResolvedSecret(
            value=value,
            backend_type=secret_ref.backend_type,
            secret_reference_id=secret_ref.id,
        )

    def resolve_ai_model_credentials(
        self,
        ai_model: AIModel,
        *,
        db: Optional[Session] = None,
        allow_refresh: bool = False,
    ) -> Optional[ResolvedModelCredentials]:
        """Resolve typed credentials for an AI model."""
        if ai_model.credentials_secret:
            resolved = self.resolve_secret_reference(ai_model.credentials_secret)
            secret_kind = (
                (ai_model.credentials_secret.secret_kind or "").strip().lower()
            )
            if secret_kind == AI_MODEL_CREDENTIALS_SECRET_KIND:
                return self._resolve_structured_ai_model_credentials(
                    ai_model,
                    resolved,
                    db=db,
                    allow_refresh=allow_refresh,
                )
            return ResolvedModelCredentials(
                credential_type="api_key",
                backend_type=resolved.backend_type,
                value=resolved.value,
                secret_reference_id=resolved.secret_reference_id,
            )

        if ai_model.api_key:
            return ResolvedModelCredentials(
                credential_type="api_key",
                backend_type="legacy_plaintext",
                value=ai_model.api_key,
            )

        return None

    def resolve_ai_model_api_key(self, ai_model: AIModel) -> Optional[ResolvedSecret]:
        """Resolve the API key for an AI model."""
        resolved_credentials = self.resolve_ai_model_credentials(ai_model)
        if (
            not resolved_credentials
            or resolved_credentials.credential_type != "api_key"
        ):
            return None
        return ResolvedSecret(
            value=resolved_credentials.value or "",
            backend_type=resolved_credentials.backend_type,
            secret_reference_id=resolved_credentials.secret_reference_id,
        )

    def _resolve_structured_ai_model_credentials(
        self,
        ai_model: AIModel,
        resolved_secret: ResolvedSecret,
        *,
        db: Optional[Session] = None,
        allow_refresh: bool = False,
    ) -> Optional[ResolvedModelCredentials]:
        try:
            payload = json.loads(resolved_secret.value or "")
        except (TypeError, ValueError, json.JSONDecodeError) as exc:
            raise ValueError("AI model credential payload is not valid JSON") from exc

        if not isinstance(payload, dict):
            raise ValueError("AI model credential payload must be a JSON object")

        credential_type = str(payload.get("type") or "").strip()
        if not credential_type:
            raise ValueError("AI model credential payload is missing type")

        if (
            credential_type == OPENAI_CODEX_OAUTH_CREDENTIAL_TYPE
            and allow_refresh
            and self._openai_codex_refresh_required(payload)
        ):
            payload = self._refresh_openai_codex_ai_model_credentials(
                ai_model,
                payload,
                db=db,
            )

        if credential_type == "api_key":
            api_key = str(payload.get("api_key") or payload.get("value") or "").strip()
            return ResolvedModelCredentials(
                credential_type=credential_type,
                backend_type=resolved_secret.backend_type,
                value=api_key or None,
                payload=payload,
                secret_reference_id=resolved_secret.secret_reference_id,
            )

        if credential_type == OPENAI_CODEX_OAUTH_CREDENTIAL_TYPE:
            access_token = str(payload.get("access") or "").strip()
            return ResolvedModelCredentials(
                credential_type=credential_type,
                backend_type=resolved_secret.backend_type,
                value=access_token or None,
                payload=payload,
                secret_reference_id=resolved_secret.secret_reference_id,
            )

        return ResolvedModelCredentials(
            credential_type=credential_type,
            backend_type=resolved_secret.backend_type,
            payload=payload,
            secret_reference_id=resolved_secret.secret_reference_id,
        )

    def _openai_codex_refresh_required(self, payload: Dict[str, Any]) -> bool:
        expires_raw = payload.get("expires")
        expires_ms = self._coerce_epoch_millis(expires_raw)
        if expires_ms is None:
            return False
        return (
            expires_ms
            <= int(datetime.now(timezone.utc).timestamp() * 1000)
            + OPENAI_CODEX_REFRESH_SKEW_MS
        )

    def _refresh_openai_codex_ai_model_credentials(
        self,
        ai_model: AIModel,
        payload: Dict[str, Any],
        *,
        db: Optional[Session] = None,
    ) -> Dict[str, Any]:
        refresh_token = str(payload.get("refresh") or "").strip()
        if not refresh_token:
            return payload

        refreshed = self._refresh_openai_codex_token(refresh_token)
        account_id = refreshed.get("account_id") or payload.get("account_id")
        next_payload = {
            "type": OPENAI_CODEX_OAUTH_CREDENTIAL_TYPE,
            "access": refreshed["access"],
            "refresh": refreshed["refresh"],
            "expires": refreshed["expires"],
        }
        if account_id:
            next_payload["account_id"] = account_id

        if (
            db is not None
            and ai_model.credentials_secret is not None
            and ai_model.credentials_secret.backend_type == LOCAL_ENCRYPTED_BACKEND
        ):
            ai_model.credentials_secret.encrypted_value = encrypt_value(
                json.dumps(next_payload)
            )
            ai_model.credentials_secret.last_verified_at = datetime.now(timezone.utc)
            ai_model.credentials_secret.meta_data = {
                **(
                    ai_model.credentials_secret.meta_data
                    if isinstance(ai_model.credentials_secret.meta_data, dict)
                    else {}
                ),
                "credential_type": OPENAI_CODEX_OAUTH_CREDENTIAL_TYPE,
            }
            db.add(ai_model.credentials_secret)
            db.commit()
            db.refresh(ai_model.credentials_secret)

        return next_payload

    def _refresh_openai_codex_token(self, refresh_token: str) -> Dict[str, Any]:
        body = urllib_parse.urlencode(
            {
                "grant_type": "refresh_token",
                "refresh_token": refresh_token,
                "client_id": OPENAI_CODEX_CLIENT_ID,
            }
        ).encode("utf-8")
        req = urllib_request.Request(
            OPENAI_CODEX_TOKEN_URL,
            data=body,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            method="POST",
        )
        try:
            with urllib_request.urlopen(req, timeout=30) as response:
                payload = json.loads(response.read().decode("utf-8"))
        except urllib_error.HTTPError as exc:
            detail = exc.read().decode("utf-8", "ignore")
            raise ValueError(
                f"OpenAI Codex token refresh failed with status {exc.code}: {detail}"
            ) from exc
        except urllib_error.URLError as exc:
            raise ValueError(
                f"OpenAI Codex token refresh failed: {exc.reason}"
            ) from exc

        access = str(payload.get("access_token") or "").strip()
        refresh = str(payload.get("refresh_token") or "").strip()
        expires_in = payload.get("expires_in")
        if not access or not refresh or not isinstance(expires_in, (int, float)):
            raise ValueError("OpenAI Codex token refresh response missing fields")
        return {
            "access": access,
            "refresh": refresh,
            "expires": int(datetime.now(timezone.utc).timestamp() * 1000)
            + int(expires_in * 1000),
            "account_id": self._extract_openai_codex_account_id(access),
        }

    def _extract_openai_codex_account_id(self, access_token: str) -> Optional[str]:
        parts = access_token.split(".")
        if len(parts) != 3:
            return None
        payload = parts[1]
        padding = "=" * (-len(payload) % 4)
        try:
            decoded = json.loads(
                urlsafe_b64decode((payload + padding).encode("utf-8")).decode("utf-8")
            )
        except (ValueError, json.JSONDecodeError):
            return None
        auth = decoded.get(OPENAI_CODEX_JWT_CLAIM_PATH)
        if not isinstance(auth, dict):
            return None
        account_id = auth.get("chatgpt_account_id")
        return str(account_id).strip() if account_id else None

    @staticmethod
    def _coerce_epoch_millis(value: Any) -> Optional[int]:
        if isinstance(value, (int, float)):
            return int(value)
        if isinstance(value, str):
            try:
                return int(float(value))
            except ValueError:
                return None

        return None


_secret_service: Optional[SecretService] = None


def get_secret_service() -> SecretService:
    """Get or create the singleton secret service."""
    global _secret_service
    if _secret_service is None:
        _secret_service = SecretService()
    return _secret_service
