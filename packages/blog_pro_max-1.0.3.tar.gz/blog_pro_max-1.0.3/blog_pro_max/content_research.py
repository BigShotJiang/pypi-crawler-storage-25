#!/usr/bin/env python3
"""
content_research.py — blog-pro-max 主程式進入點

用法：
  python scripts/content_research.py --keyword "關鍵字" [選項]
"""

import argparse
import re
import sys
from datetime import date
from pathlib import Path

# Ensure UTF-8 output on all platforms (e.g., Windows cp950 terminals)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

try:
    from blog_pro_max._resources import RESOURCE_ROOT
    from blog_pro_max.core import ensure_environment, list_templates, scan_project_status, TEMPLATES
    from blog_pro_max.blog_generator import build_prompt, generate_article
    from blog_pro_max.style_checker import check_content, check_file
    from blog_pro_max.output_md2html import convert_file as md2html
except ImportError:
    RESOURCE_ROOT = Path(__file__).resolve().parent.parent
    sys.path.insert(0, str(RESOURCE_ROOT / "scripts"))
    from core import ensure_environment, list_templates, scan_project_status, TEMPLATES
    from blog_generator import build_prompt, generate_article
    from style_checker import check_content, check_file
    from output_md2html import convert_file as md2html


def slugify(text: str) -> str:
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s]+", "-", text.strip())
    return text.lower()[:80]


def main():
    available_templates = ", ".join(TEMPLATES.keys())

    parser = argparse.ArgumentParser(
        description="blog-pro-max：自動化 SEO 內容創作與部落格文章生成",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--keyword", required=True, help="核心關鍵字（必填）"
    )
    parser.add_argument(
        "--audience", default="30-45 歲知識工作者", help="目標讀者（預設：30-45 歲知識工作者）"
    )
    parser.add_argument(
        "--word-count", type=int, default=1200, help="目標字數（預設：1200）"
    )
    parser.add_argument(
        "--language", default="zh-TW", help="輸出語言（預設：zh-TW）"
    )
    parser.add_argument(
        "--output", default=None, help="輸出檔案路徑（預設：output/{keyword}.md）"
    )
    parser.add_argument(
        "--model", default="gpt-4o", help="OpenAI 模型（預設：gpt-4o）"
    )
    parser.add_argument(
        "--template", default="blog-skill-content",
        help=f"寫作風格模板（預設：blog-skill-content）。可用：{available_templates}",
    )
    parser.add_argument(
        "--check-only", default=None,
        help="僅對指定檔案執行風格檢查，不生成文章",
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="顯示 prompt 但不呼叫 API",
    )
    parser.add_argument(
        "--status", action="store_true",
        help="顯示專案狀態報告",
    )
    parser.add_argument(
        "--list-templates", action="store_true",
        help="列出所有可用模板",
    )

    args = parser.parse_args()

    # Status mode
    if args.status:
        print(scan_project_status())
        return

    # List templates mode
    if args.list_templates:
        print("📚 可用寫作風格模板：\n")
        for name, info in list_templates().items():
            status = "✅" if info["exists"] else "❌"
            print(f"  {status} {name:25s} {info['description']}")
        return

    # Environment check
    if not ensure_environment():
        print("\n❌ 環境檢查未通過，請修正上述問題。")
        sys.exit(1)

    # Style check only mode
    if args.check_only:
        print(f"🔍 檢查檔案：{args.check_only}")
        report = check_file(args.check_only, args.keyword)
        print(report.summary())
        sys.exit(0 if report.passed else 1)

    keyword = args.keyword
    template = args.template
    output_path = args.output or str(
        Path.cwd() / "output" / f"{slugify(keyword)}.md"
    )

    print(f"🔑 核心關鍵字：{keyword}")
    print(f"👥 目標讀者：{args.audience}")
    print(f"📏 目標字數：{args.word_count}")
    print(f"🌐 語言：{args.language}")
    print(f"🤖 模型：{args.model}")
    print(f"🎨 模板：{template}")
    print(f"📄 輸出路徑：{output_path}")
    print()

    # Dry run mode
    if args.dry_run:
        prompt, system_prompt = build_prompt(
            keyword, args.audience, args.word_count, args.language, template
        )
        print("=" * 60)
        print("📋 System Prompt")
        print("=" * 60)
        print(system_prompt[:800] + "..." if len(system_prompt) > 800 else system_prompt)
        print()
        print("=" * 60)
        print("📝 User Prompt（文章生成指令）")
        print("=" * 60)
        print(prompt)
        return

    # Generate article
    print("⏳ 正在生成文章...")
    try:
        article = generate_article(
            keyword=keyword,
            audience=args.audience,
            word_count=args.word_count,
            language=args.language,
            model=args.model,
            template=template,
        )
    except EnvironmentError as e:
        print(f"❌ {e}")
        sys.exit(1)
    except KeyError as e:
        print(f"❌ {e}")
        sys.exit(1)
    except Exception as e:
        print(f"❌ 生成失敗：{e}")
        sys.exit(1)

    # Save output
    output_file = Path(output_path)
    output_file.parent.mkdir(parents=True, exist_ok=True)
    output_file.write_text(article, encoding="utf-8")
    print(f"✅ 文章已儲存至：{output_path}")
    print()

    # Style check
    print("🔍 正在執行風格檢查...")
    report = check_content(article, keyword)
    print(report.summary())

    if not report.passed:
        print()
        print("⚠️  文章已儲存，但有風格問題需要修正。")
        sys.exit(1)
    else:
        print()
        print("🎉 文章生成完成，所有檢查通過！")

    # Convert to HTML
    html_path = str(Path(output_path).with_suffix(".html"))
    print(f"📄 正在轉換 HTML...")
    md2html(output_path, html_path)
    print(f"✅ HTML 已儲存至：{html_path}")


if __name__ == "__main__":
    main()
