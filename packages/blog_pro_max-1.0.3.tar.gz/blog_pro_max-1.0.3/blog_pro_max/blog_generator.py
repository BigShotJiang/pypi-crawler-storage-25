"""
blog_generator.py — LLM 驅動的部落格文章生成引擎
"""

import os
from pathlib import Path

from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

try:
    from blog_pro_max.core import (
        render_template,
        build_system_prompt,
        get_template,
        TEMPLATES,
    )
except ImportError:
    from core import (
        render_template,
        build_system_prompt,
        get_template,
        TEMPLATES,
    )


def build_prompt(
    keyword: str,
    audience: str = "30-45 歲知識工作者",
    word_count: int = 1200,
    language: str = "zh-TW",
    template: str = "blog-skill-content",
) -> tuple[str, str]:
    """Build user prompt and system prompt from a registered template."""
    user_prompt = render_template(template, keyword, audience, word_count, language)
    system_prompt = build_system_prompt(template)
    return user_prompt, system_prompt


GITHUB_MODELS_ENDPOINT = "https://models.inference.ai.azure.com"


def _make_client() -> OpenAI:
    """Return an OpenAI-compatible client.

    Priority:
    1. GITHUB_TOKEN  → GitHub Models endpoint (free tier, no OpenAI account needed)
    2. OPENAI_API_KEY → OpenAI directly
    """
    github_token = os.getenv("GITHUB_TOKEN")
    if github_token:
        return OpenAI(api_key=github_token, base_url=GITHUB_MODELS_ENDPOINT)

    openai_key = os.getenv("OPENAI_API_KEY")
    if openai_key:
        return OpenAI(api_key=openai_key)

    raise EnvironmentError(
        "未設定 API 金鑰。請在 .env 中設定：\n"
        "  GITHUB_TOKEN=ghp_...   ← GitHub PAT（免費，推薦）\n"
        "  OPENAI_API_KEY=sk-...  ← OpenAI API Key"
    )


def generate_article(
    keyword: str,
    audience: str = "30-45 歲知識工作者",
    word_count: int = 1200,
    language: str = "zh-TW",
    model: str = "gpt-4o",
    template: str = "blog-skill-content",
) -> str:
    client = _make_client()
    prompt, system_message = build_prompt(
        keyword, audience, word_count, language, template
    )

    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system_message},
            {"role": "user", "content": prompt},
        ],
        temperature=0.7,
        max_tokens=4096,
    )

    content = response.choices[0].message.content
    return content.strip()
