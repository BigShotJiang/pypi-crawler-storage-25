#!/usr/bin/env python3
"""
blogpro — blog-pro-max CLI 統一入口

用法：
  blogpro init --ai claude           # 注入 skill 到 Claude
  blogpro init --ai copilot --global # 全域安裝到 ~/
  blogpro uninstall --ai claude      # 移除指定平台
  blogpro uninstall                  # 自動偵測並移除
  blogpro versions                   # 顯示版本資訊
  blogpro update                     # 更新到最新版本
"""

import argparse
import json
import shutil
import sys
from datetime import datetime
from pathlib import Path

# Ensure UTF-8 output on all platforms
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

# RESOURCE_ROOT = where bundled assets (templates, scripts) live
# DEV_ROOT      = repo root (only useful when running from git clone, as fallback)
# WORKING_DIR   = Path.cwd(), where the user runs the command (for display only)
_PACKAGE_DIR = Path(__file__).resolve().parent
_is_package = (_PACKAGE_DIR / "__init__.py").is_file() and (_PACKAGE_DIR / "templates").is_dir()
if _is_package:
    RESOURCE_ROOT = _PACKAGE_DIR
else:
    RESOURCE_ROOT = _PACKAGE_DIR.parent

DEV_ROOT = _PACKAGE_DIR.parent  # fallback for dev-mode resources

SKILL_NAME = "blog-pro-max"
VERSION = "1.0.2"
VERSION_HISTORY = [
    {"version": "1.0.2", "date": "2026-03-28", "changes": "修正路徑問題：分離 RESOURCE_ROOT 與工作目錄，從任意路徑執行皆正確"},
    {"version": "1.0.0", "date": "2026-03-28", "changes": "初始版本：SEO 文章生成、Max 風格、風格檢查、MD→HTML、18 平台 init"},
]

# ── AI Assistant 平台定義 ─────────────────────────────

PLATFORMS = {
    "claude": {
        "display": "Claude Code",
        "root": ".claude",
        "sub": f"skills/{SKILL_NAME}",
        "filename": "SKILL.md",
    },
    "cursor": {
        "display": "Cursor",
        "root": ".cursor",
        "sub": f"skills/{SKILL_NAME}",
        "filename": "SKILL.md",
    },
    "windsurf": {
        "display": "Windsurf",
        "root": ".windsurf",
        "sub": f"skills/{SKILL_NAME}",
        "filename": "SKILL.md",
    },
    "copilot": {
        "display": "GitHub Copilot",
        "root": ".github",
        "sub": f"prompts/{SKILL_NAME}",
        "filename": "PROMPT.md",
    },
    "antigravity": {
        "display": "Antigravity",
        "root": ".agents",
        "sub": f"skills/{SKILL_NAME}",
        "filename": "SKILL.md",
    },
    "kiro": {
        "display": "Kiro",
        "root": ".kiro",
        "sub": f"steering/{SKILL_NAME}",
        "filename": "SKILL.md",
    },
    "codex": {
        "display": "Codex CLI",
        "root": ".codex",
        "sub": f"skills/{SKILL_NAME}",
        "filename": "SKILL.md",
    },
    "qoder": {
        "display": "Qoder",
        "root": ".qoder",
        "sub": f"skills/{SKILL_NAME}",
        "filename": "SKILL.md",
    },
    "roocode": {
        "display": "Roo Code",
        "root": ".roo",
        "sub": f"skills/{SKILL_NAME}",
        "filename": "SKILL.md",
    },
    "gemini": {
        "display": "Gemini CLI",
        "root": ".gemini",
        "sub": f"skills/{SKILL_NAME}",
        "filename": "SKILL.md",
    },
    "trae": {
        "display": "Trae",
        "root": ".trae",
        "sub": f"skills/{SKILL_NAME}",
        "filename": "SKILL.md",
    },
    "opencode": {
        "display": "OpenCode",
        "root": ".opencode",
        "sub": f"skills/{SKILL_NAME}",
        "filename": "SKILL.md",
    },
    "continue": {
        "display": "Continue",
        "root": ".continue",
        "sub": f"skills/{SKILL_NAME}",
        "filename": "SKILL.md",
    },
    "codebuddy": {
        "display": "CodeBuddy",
        "root": ".codebuddy",
        "sub": f"skills/{SKILL_NAME}",
        "filename": "SKILL.md",
    },
    "droid": {
        "display": "Droid (Factory)",
        "root": ".factory",
        "sub": f"skills/{SKILL_NAME}",
        "filename": "SKILL.md",
    },
    "kilocode": {
        "display": "KiloCode",
        "root": ".kilocode",
        "sub": f"skills/{SKILL_NAME}",
        "filename": "SKILL.md",
    },
    "warp": {
        "display": "Warp",
        "root": ".warp",
        "sub": f"skills/{SKILL_NAME}",
        "filename": "SKILL.md",
    },
    "augment": {
        "display": "Augment",
        "root": ".augment",
        "sub": f"skills/{SKILL_NAME}",
        "filename": "SKILL.md",
    },
}

COPY_FILES = ["writing-style.md", "copilot.json", "requirements.txt"]

# Python script files to include in skill installs
SCRIPT_FILES = [
    "core.py",
    "blog_generator.py",
    "content_research.py",
    "style_checker.py",
    "output_md2html.py",
    "blogpro.py",
    "__init__.py",
]


# ══════════════════════════════════════════════════════
#  Skill 文件生成
# ══════════════════════════════════════════════════════

def _build_frontmatter(platform_key):
    desc = (
        "自動化 SEO 內容創作與部落格文章生成工具。"
        "支援 SEO 專業風格與 Max 個人心情筆記風格，"
        "內建風格檢查器、Markdown 轉 HTML，"
        "以及多模板管理系統。"
    )
    if platform_key == "claude":
        desc = (
            "Blog content intelligence. "
            "自動化 SEO 內容創作與部落格文章生成。"
            "2 種寫作模板（SEO 專業 / Max 個人風格）、"
            "風格檢查器、MD→HTML 轉換。"
            "Actions: generate, check, convert, plan, write, review, "
            "optimize SEO, create blog posts, analyze style."
        )
    return "\n".join([
        "---",
        f"name: {SKILL_NAME}",
        f"version: {VERSION}",
        f'description: "{desc}"',
        "---",
    ])


def _build_skill_content(platform_key, script_prefix):
    fm = _build_frontmatter(platform_key)
    writing_style = (RESOURCE_ROOT / "writing-style.md").read_text(encoding="utf-8")
    max_template = (RESOURCE_ROOT / "templates" / "max-personal-style.md").read_text(encoding="utf-8")
    seo_template = (RESOURCE_ROOT / "templates" / "blog-skill-content.md").read_text(encoding="utf-8")

    return f"""{fm}

# Blog Pro Max — 自動化 SEO 內容創作與部落格文章生成

## 概述

blog-pro-max 是一套自動化部落格內容生成工具，支援：

- **SEO 專業風格**：精簡、直接、關鍵字最佳化
- **Max 個人風格**：心情筆記、生活化敘事、自我反思
- **風格檢查器**：自動驗證禁止詞彙、標題層級、SEO 規則、標點
- **MD→HTML 轉換**：生成後自動輸出 WordPress 相容 HTML

## 觸發方式

### Workflow Mode（Slash Command）

支援平台：Kiro、GitHub Copilot、Roo Code、KiloCode

使用者輸入 `/blog-pro-max` 開頭的指令時，解析並執行對應的文章生成任務。

**指令格式：**

```
/blog-pro-max 寫一篇[主題關鍵字]文章,受眾[目標讀者],以[風格名稱]風格
```

**範例：**

```
/blog-pro-max 寫一篇[失去才懂珍惜]文章,受眾[一般讀者],以作家Max風格
/blog-pro-max 寫一篇[Python 非同步入門]文章,受眾[中階開發者],以SEO風格
/blog-pro-max 寫一篇[遠端工作的真實面貌]文章
/blog-pro-max 檢查風格 output/my-article.md
/blog-pro-max 列出模板
/blog-pro-max 專案狀態
```

**解析規則：**

當使用者輸入 `/blog-pro-max` 時，AI 應依以下規則解析：

1. `[...]` 中的第一個值 → `--keyword`（核心關鍵字）
2. `受眾[...]` → `--audience`（目標讀者），未指定則預設 `30-45 歲知識工作者`
3. 風格關鍵字對應：
   - `作家Max風格` / `Max風格` / `心情筆記` → `--template max-personal-style`
   - `SEO風格` / `專業風格` / `部落格風格` → `--template blog-skill-content`（預設）
4. `字數[N]` → `--word-count N`
5. `檢查風格 <路徑>` → 執行 `style_checker.py`
6. `列出模板` → 執行 `core.py templates`
7. `專案狀態` → 執行 `core.py status`

**AI 執行步驟：**

收到 `/blog-pro-max` 指令後：

1. 解析使用者意圖，提取關鍵字、受眾、風格、字數
2. 執行對應的 Python 腳本：
   ```bash
   python {script_prefix}scripts/content_research.py --keyword "關鍵字" --audience "受眾" --template 模板名稱
   ```
3. 生成完成後自動執行風格檢查
4. 自動將 .md 轉換為 .html
5. 回報結果與檔案位置

### Script Mode（直接執行）

| 使用情境 | 指令 |
|---|---|
| 生成 SEO 文章 | `python {script_prefix}scripts/content_research.py --keyword "關鍵字"` |
| 生成 Max 風格文章 | `python {script_prefix}scripts/content_research.py --keyword "主題" --template max-personal-style` |
| 僅檢查風格 | `python {script_prefix}scripts/style_checker.py output/文章.md "關鍵字"` |
| 預覽 prompt（不呼叫 API） | `python {script_prefix}scripts/content_research.py --keyword "關鍵字" --dry-run` |
| 查看專案狀態 | `python {script_prefix}scripts/core.py status` |
| 列出可用模板 | `python {script_prefix}scripts/core.py templates` |
| 轉換 MD→HTML | `python {script_prefix}scripts/output_md2html.py input.md output.html` |

## 前置需求

需要 Python 3.10+ 與以下套件：

```bash
pip install -r {script_prefix}requirements.txt
```

## 參數說明

| 參數 | 說明 | 預設值 |
|---|---|---|
| `--keyword` | 核心關鍵字（必填） | — |
| `--audience` | 目標讀者 | 30-45 歲知識工作者 |
| `--word-count` | 目標字數 | 1200 |
| `--language` | 輸出語言 | zh-TW |
| `--template` | 寫作風格模板 | blog-skill-content |
| `--model` | LLM 模型 | gpt-4o |
| `--output` | 輸出檔案路徑 | output/{{keyword}}.md |
| `--dry-run` | 預覽 prompt 不呼叫 API | — |

## 可用模板

| 模板 | 說明 |
|---|---|
| `blog-skill-content` | SEO 部落格文章（專業、精簡、直接） |
| `max-personal-style` | Max 個人風格（心情筆記、生活化、自我反思） |

## API 金鑰設定

在專案根目錄建立 `.env` 檔案：

```
# 推薦：GitHub PAT（免費）
GITHUB_TOKEN=ghp_your-token-here

# 或：OpenAI API Key
OPENAI_API_KEY=sk-your-key-here
```

---

## 寫作風格指南

{writing_style}

---

## SEO 文章模板

{seo_template}

---

## Max 個人風格模板

{max_template}
"""


# ══════════════════════════════════════════════════════
#  init — 安裝 skill
# ══════════════════════════════════════════════════════

def install_for_platform(platform_key, target_root, global_install=False, offline=False):
    plat = PLATFORMS[platform_key]
    display = plat["display"]
    skill_dir = target_root / plat["root"] / plat["sub"]
    skill_file = skill_dir / plat["filename"]

    if global_install:
        prefix = str(skill_dir).replace("\\", "/") + "/"
    else:
        prefix = plat["root"] + "/" + plat["sub"] + "/"

    print(f"  📦 {display}...")

    try:
        skill_dir.mkdir(parents=True, exist_ok=True)

        content = _build_skill_content(platform_key, prefix)
        skill_file.write_text(content, encoding="utf-8")

        # ── Copy templates ──
        tmpl_src = RESOURCE_ROOT / "templates"
        if not tmpl_src.is_dir():
            tmpl_src = DEV_ROOT / "templates"
        tmpl_dst = skill_dir / "templates"
        if tmpl_src.is_dir():
            if tmpl_dst.exists():
                shutil.rmtree(tmpl_dst)
            shutil.copytree(tmpl_src, tmpl_dst)

        # ── Copy scripts ──
        # When installed via pip, Python files are in RESOURCE_ROOT (blog_pro_max/)
        # When in dev mode, they're in DEV_ROOT/scripts/
        scripts_dst = skill_dir / "scripts"
        scripts_dst.mkdir(exist_ok=True)

        scripts_src_pkg = RESOURCE_ROOT  # package mode
        scripts_src_dev = DEV_ROOT / "scripts"  # dev mode

        for fname in SCRIPT_FILES:
            src = scripts_src_pkg / fname
            if not src.is_file():
                src = scripts_src_dev / fname
            if src.is_file():
                shutil.copy2(src, scripts_dst / fname)

        # ── Copy resource files ──
        for file_name in COPY_FILES:
            src = RESOURCE_ROOT / file_name
            if not src.is_file():
                src = DEV_ROOT / file_name
            dst = skill_dir / file_name
            if src.is_file():
                shutil.copy2(src, dst)

        # Also generate requirements.txt if not found
        req_dst = skill_dir / "requirements.txt"
        if not req_dst.is_file():
            req_dst.write_text(
                "openai>=1.0.0\npython-dotenv>=1.0.0\nMarkdown>=3.5.0\nPygments>=2.17.0\n",
                encoding="utf-8",
            )

        (skill_dir / "output").mkdir(exist_ok=True)

        # Write install manifest for uninstall tracking
        manifest = {
            "skill": SKILL_NAME,
            "version": VERSION,
            "platform": platform_key,
            "installed_at": datetime.now().isoformat(),
            "global": global_install,
            "path": str(skill_dir),
        }
        manifest_path = skill_dir / ".blogpro-manifest.json"
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

        print(f"     ✅ {skill_file}")
        return True

    except Exception as e:
        print(f"     ❌ 失敗：{e}")
        return False


def cmd_init(args):
    if args.target:
        target_root = Path(args.target).resolve()
    elif args.global_install:
        target_root = Path.home()
    else:
        target_root = Path.cwd()

    mode = "離線模式" if args.offline else "本地資源"
    scope = "全域" if args.global_install else "本地"
    print(f"🚀 blog-pro-max v{VERSION} skill 安裝（{scope}，{mode}）")
    print(f"📂 安裝目錄：{target_root}")
    print()

    if args.ai == "all":
        targets = list(PLATFORMS.keys())
    else:
        targets = [args.ai]

    success = failed = 0
    for plat in targets:
        if install_for_platform(plat, target_root, args.global_install, args.offline):
            success += 1
        else:
            failed += 1

    print()
    print(f"✅ 完成：{success} 個平台成功" + (f"，{failed} 個失敗" if failed else ""))
    if failed:
        sys.exit(1)


# ══════════════════════════════════════════════════════
#  uninstall — 移除 skill
# ══════════════════════════════════════════════════════

def _find_installed_platforms(search_root):
    """掃描目錄，找出所有已安裝 blog-pro-max 的平台。"""
    found = []
    for key, plat in PLATFORMS.items():
        skill_dir = search_root / plat["root"] / plat["sub"]
        manifest = skill_dir / ".blogpro-manifest.json"
        if manifest.is_file() or (skill_dir / plat["filename"]).is_file():
            found.append((key, plat, skill_dir))
    return found


def _remove_skill_dir(platform_key, skill_dir):
    plat = PLATFORMS[platform_key]
    display = plat["display"]
    print(f"  🗑️  {display}...")
    try:
        if skill_dir.is_dir():
            shutil.rmtree(skill_dir)
            print(f"     ✅ 已移除 {skill_dir}")
            return True
        else:
            print(f"     ⚠️  目錄不存在：{skill_dir}")
            return False
    except Exception as e:
        print(f"     ❌ 失敗：{e}")
        return False


def cmd_uninstall(args):
    if args.global_install:
        search_root = Path.home()
        scope = "全域"
    else:
        search_root = Path.cwd()
        scope = "本地"

    print(f"🗑️  blog-pro-max skill 移除（{scope}）")
    print(f"📂 搜尋目錄：{search_root}")
    print()

    if args.ai:
        # Remove specific platform(s)
        if args.ai == "all":
            targets = list(PLATFORMS.keys())
        else:
            targets = [args.ai]

        success = failed = 0
        for key in targets:
            plat = PLATFORMS[key]
            skill_dir = search_root / plat["root"] / plat["sub"]
            if _remove_skill_dir(key, skill_dir):
                success += 1
            else:
                failed += 1

        print()
        print(f"✅ 完成：{success} 個平台已移除" + (f"，{failed} 個失敗" if failed else ""))
    else:
        # Auto-detect installed platforms
        found = _find_installed_platforms(search_root)
        if not found:
            print("  ℹ️  未偵測到任何已安裝的 blog-pro-max skill。")
            return

        print(f"  偵測到 {len(found)} 個已安裝平台：")
        for key, plat, skill_dir in found:
            print(f"    • {plat['display']} → {skill_dir}")
        print()

        success = failed = 0
        for key, plat, skill_dir in found:
            if _remove_skill_dir(key, skill_dir):
                success += 1
            else:
                failed += 1

        print()
        print(f"✅ 完成：{success} 個平台已移除" + (f"，{failed} 個失敗" if failed else ""))


# ══════════════════════════════════════════════════════
#  versions — 顯示版本資訊
# ══════════════════════════════════════════════════════

def cmd_versions(args):
    print(f"📦 blog-pro-max")
    print(f"   目前版本：v{VERSION}")
    print(f"   安裝位置：{RESOURCE_ROOT}")
    print(f"   工作目錄：{Path.cwd()}")
    print()
    print("📋 版本歷史：")
    print()
    for entry in reversed(VERSION_HISTORY):
        print(f"  v{entry['version']}  ({entry['date']})")
        print(f"    {entry['changes']}")
        print()

    # Show installed platforms
    print("📍 已安裝平台（本地）：")
    local_found = _find_installed_platforms(Path.cwd())
    if local_found:
        for key, plat, skill_dir in local_found:
            # Read version from manifest if available
            manifest_path = skill_dir / ".blogpro-manifest.json"
            installed_ver = "?"
            if manifest_path.is_file():
                try:
                    m = json.loads(manifest_path.read_text(encoding="utf-8"))
                    installed_ver = m.get("version", "?")
                except Exception:
                    pass
            print(f"  ✅ {plat['display']:20s} v{installed_ver}  {skill_dir}")
    else:
        print("  （無）")

    print()
    print("📍 已安裝平台（全域 ~）：")
    global_found = _find_installed_platforms(Path.home())
    if global_found:
        for key, plat, skill_dir in global_found:
            manifest_path = skill_dir / ".blogpro-manifest.json"
            installed_ver = "?"
            if manifest_path.is_file():
                try:
                    m = json.loads(manifest_path.read_text(encoding="utf-8"))
                    installed_ver = m.get("version", "?")
                except Exception:
                    pass
            print(f"  ✅ {plat['display']:20s} v{installed_ver}  {skill_dir}")
    else:
        print("  （無）")


# ══════════════════════════════════════════════════════
#  update — 更新到最新版本
# ══════════════════════════════════════════════════════

def cmd_update(args):
    print(f"🔄 blog-pro-max 更新")
    print(f"   目前版本：v{VERSION}")
    print()

    # Collect all installed platforms (local + global)
    local_found = _find_installed_platforms(Path.cwd())
    global_found = _find_installed_platforms(Path.home())

    all_found = []
    for key, plat, skill_dir in local_found:
        all_found.append((key, skill_dir, False))
    for key, plat, skill_dir in global_found:
        all_found.append((key, skill_dir, True))

    if not all_found:
        print("  ℹ️  未偵測到任何已安裝的平台。請先執行 blogpro init。")
        return

    print(f"  偵測到 {len(all_found)} 個已安裝平台，開始更新...")
    print()

    success = failed = 0
    for key, skill_dir, is_global in all_found:
        target_root = Path.home() if is_global else Path.cwd()
        if install_for_platform(key, target_root, is_global):
            success += 1
        else:
            failed += 1

    print()
    print(f"✅ 更新完成：{success} 個平台成功" + (f"，{failed} 個失敗" if failed else ""))
    print(f"   版本：v{VERSION}")
    if failed:
        sys.exit(1)


# ══════════════════════════════════════════════════════
#  CLI 主入口
# ══════════════════════════════════════════════════════

def main():
    platform_choices = list(PLATFORMS.keys()) + ["all"]

    parser = argparse.ArgumentParser(
        prog="blogpro",
        description="blog-pro-max CLI — 自動化 SEO 內容創作與 AI assistant skill 管理",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subparsers = parser.add_subparsers(dest="command", help="可用指令")

    # ── init ──
    p_init = subparsers.add_parser(
        "init", help="將 skill 注入到 AI assistant",
        epilog=_build_platform_list(),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p_init.add_argument(
        "--ai", required=True, choices=platform_choices,
        metavar="ASSISTANT",
        help="目標 AI assistant（或 all）",
    )
    p_init.add_argument("--global", dest="global_install", action="store_true", help="安裝到使用者家目錄（全域）")
    p_init.add_argument("--target", default=None, help="自訂安裝根目錄")
    p_init.add_argument("--offline", action="store_true", help="跳過下載，使用本地資源")

    # ── uninstall ──
    p_uninstall = subparsers.add_parser(
        "uninstall", help="移除已安裝的 skill",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p_uninstall.add_argument(
        "--ai", default=None, choices=platform_choices,
        metavar="ASSISTANT",
        help="指定移除的平台（留空則自動偵測）",
    )
    p_uninstall.add_argument("--global", dest="global_install", action="store_true", help="從全域安裝移除")

    # ── versions ──
    subparsers.add_parser("versions", help="顯示版本資訊與已安裝平台")

    # ── update ──
    subparsers.add_parser("update", help="更新所有已安裝平台到最新版本")

    args = parser.parse_args()

    if args.command == "init":
        cmd_init(args)
    elif args.command == "uninstall":
        cmd_uninstall(args)
    elif args.command == "versions":
        cmd_versions(args)
    elif args.command == "update":
        cmd_update(args)
    else:
        parser.print_help()
        sys.exit(1)


def _build_platform_list():
    lines = ["", "支援的 AI assistants：", ""]
    for key, plat in PLATFORMS.items():
        lines.append(f"  blogpro init --ai {key:15s}  # {plat['display']}")
    lines.append(f"  blogpro init --ai {'all':15s}  # All assistants")
    lines.append("")
    lines.append("全域安裝：")
    lines.append("  blogpro init --ai claude --global   # Install to ~/.claude/skills/")
    lines.append("  blogpro init --ai cursor --global   # Install to ~/.cursor/skills/")
    return "\n".join(lines)


if __name__ == "__main__":
    main()