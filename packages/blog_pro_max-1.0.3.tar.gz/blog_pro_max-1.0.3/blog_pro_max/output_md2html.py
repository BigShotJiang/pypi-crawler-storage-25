import argparse
import markdown
import re
import sys

def preprocess_markdown(text):
    # 修正 1：確保每個 - 開頭後方至少有一個空格
    # 尋找行首為 - 且緊接非空白字元的狀況，並補上空格
    text = re.sub(r'^-([^\s])', r'- \1', text, flags=re.MULTILINE)
    
    # 修正 2：確保清單與上方段落之間有空行
    # 如果偵測到非空行的下一行直接是清單項目，則插入一個換行符
    text = re.sub(r'([^\n])\n-', r'\1\n\n-', text)
    
    return text

def convert_file(input_path, output_path):
    try:
        with open(input_path, 'r', encoding='utf-8') as f:
            raw_content = f.read()
        
        # 執行前置格式清理
        clean_content = preprocess_markdown(raw_content)
        
        # 轉換為 HTML，加入 extra 擴充以支援表格與任務清單
        html_output = markdown.markdown(clean_content, extensions=['extra', 'codehilite'])
        
        # 封裝成完整的 HTML 結構，方便直接預覽
        full_html = f"""<!DOCTYPE html>
<html lang="zh-Hant">
<head>
    <meta charset="UTF-8">
    <title>Converted Markdown</title>
    <style>
        body {{ font-family: sans-serif; line-height: 1.6; padding: 20px; max-width: 800px; margin: auto; }}
        pre {{ background: #f4f4f4; padding: 10px; border-radius: 5px; overflow-x: auto; }}
        code {{ font-family: monospace; }}
    </style>
</head>
<body>
{html_output}
</body>
</html>"""

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(full_html)
            
        print(f"轉換成功：{output_path}")

    except FileNotFoundError:
        print(f"錯誤：找不到檔案 {input_path}")
    except Exception as e:
        print(f"處理過程中發生錯誤：{e}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='強化的 Markdown 轉 HTML 工具')
    
    parser.add_argument('input', help='輸入的 .md 檔案路記')
    parser.add_argument('output', help='輸出的 .html 檔案路徑')
    
    args = parser.parse_args()
    
    convert_file(args.input, args.output)