# blog-pro-max

自動化 SEO 內容創作與部落格文章生成工具。支援一鍵將寫作 Skill 注入到 20+ 種 AI 編輯器與 Assistant。

## 功能亮點

- **AI 驅動寫作**：根據關鍵字自動進行內容研究並生成 SEO 最佳化的部落格文章。
- **品牌風格一致性**：自動套用品牌寫作風格規範（`writing-style.md`）。
- **內建風格檢查器**：自動驗證產出內容是否符合排版與語氣規範。
- **多樣化模板**：支援多種寫作風格（專業 SEO / Max 個人風格 / 知識轉譯）。
- **AI Skill 注入**：一鍵將 Prompt 與工具鏈注入到 Claude Code, Cursor, GitHub Copilot 等 20 多種平台。
- **自動格式轉換**：內建 Markdown 轉 HTML 引擎，支援代碼高亮與 SEO 優化排版。

---

## 快速開始（5 分鐘上手）

### Step 1：安裝

**從 PyPI 安裝（推薦使用者）**

```bash
pip install blog-pro-max
```

安裝後您將獲得 `blogpro` 全域指令。

**從 GitHub 安裝（開發者）**

```bash
git clone https://github.com/max32002/blog-pro-max.git
cd blog-pro-max
pip install -e .
```

### Step 2：設定 API 金鑰

在您的工作目錄建立 `.env` 檔案：

```bash
# 推薦：GitHub PAT（免費，不需 OpenAI 帳號）
GITHUB_TOKEN=ghp_your-token-here

# 或：OpenAI API Key
OPENAI_API_KEY=sk-your-key-here
```

### Step 3：注入 Skill 到您的 AI Assistant

```bash
blogpro init --ai claude      # 針對 Claude Code
blogpro init --ai copilot     # 針對 GitHub Copilot
blogpro init --ai cursor      # 針對 Cursor
blogpro init --ai all         # 注入到所有偵測到的平台
```

### Step 4：開始創作

在已注入 Skill 的 AI Assistant 中直接輸入：

```
/blog-pro-max 寫一篇[AI 寫作工具]文章,受眾[內容行銷人員],以專業SEO風格
```

---

## AI Assistant 整合支援

`blog-pro-max` 支援將寫作能力無縫整合進以下平台：

| 分類 | 支援平台 |
|---|---|
| **專業開發工具** | Claude Code, Cursor, Windsurf, Trae, Roo Code |
| **擴充套件** | GitHub Copilot, Continue, CodeBuddy, OpenCode |
| **終端機/CLI** | Gemini CLI, Codex CLI, Warp |
| **新興 Agent** | Antigravity, Kiro, Qoder, Droid (Factory), KiloCode |

### 全域安裝（適用於電腦上所有專案）

```bash
blogpro init --ai all --global
```

---

## CLI 指令參考

### 初始化與管理
- `blogpro init`: 偵測環境並注入 Skill 檔案。
- `blogpro uninstall`: 移除已注入的 Skill。
- `blogpro versions`: 檢查版本與已安裝的平台狀態。
- `blogpro update`: 同步更新所有平台的 Skill 檔案至最新版。

### 直接執行生成 (Script Mode)
如果您不想透過 AI Assistant，也可以直接執行：

```bash
# 生成文章
python -m blog_pro_max.content_research --keyword "Python 基礎教學" --template blog-skill-content

# 檢查現有 Markdown 檔案風格
python -m blog_pro_max.style_checker output/my-article.md
```

---

## 參數說明

| 參數 | 說明 | 預設值 |
|---|---|---|
| `--keyword` | 核心關鍵字（必填） | — |
| `--audience` | 目標讀者（如：初學者、資深工程師） | 30-45 歲知識工作者 |
| `--word-count` | 目標字數 | 1200 |
| `--template` | 寫作風格模板 (`blog-skill-content` / `max-personal-style`) | blog-skill-content |

---

## 開發者指南：如何發布到 PyPI

如果您修改了程式碼並想發布新版本：

1. **安裝建置工具**：
   ```bash
   pip install build twine
   ```

2. **建置套件**：
   ```bash
   python -m build
   ```

3. **上傳至 PyPI**：
   ```bash
   python -m twine upload dist/*
   ```

---

## 授權
本專案採用 [MIT License](LICENSE) 授權。
歡迎提交 Issue 或 Pull Request 參與貢獻！
