# cfskit
Common research utilities for our NUIST-GenAI-Lab and CCGM tasks



## Features

- 整合常用的科研库, 减少工具学习成本
- 尽量规范
- 尽量简洁
- 约定大于配置
- 最小化上手难度



## 整合功能

- accelerate封装
- tensorboard封装
- loguru封装
- ipc 信号中断工具
- 常用训练,评估,测试工具
