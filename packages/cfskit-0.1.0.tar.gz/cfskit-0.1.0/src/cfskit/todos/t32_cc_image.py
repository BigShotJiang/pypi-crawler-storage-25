# -*- coding: utf-8 -*-
# @Time    : 2025/6/3 21:11
# @Author  : CFuShn
# @Comments: 单张人脸图像
# @Software: PyCharm

from typing import Optional

import cv2


class CcImage:

    def __init__(self, _id, path=None, origin=None):
        # 基本信息
        self.id: str = _id  # 必传 (格式: 数据集id_{path.basename})
        self.path: Optional[str | None] = path
        self.origin: Optional[str | None] = origin  # 溯源

        # 文本prompt
        self.prompt: str = ""  # prompt 或 image caption

    def img(self, mode="BGR"):
        # img = cv2.imread(self.path, cv2.IMREAD_UNCHANGED)  # IMREAD_UNCHANGED表示保留alpha通道
        bgr_img = cv2.imread(self.path)  # 默认是IMREAD_COLOR模式,只读取彩色, 且默认返回BGR顺序
        if bgr_img is None:
            return None
        img = _ensure_bgr2rgb(bgr_img) if mode == "RGB" else _ensure_bgr(bgr_img)
        return img


# 将 BGR图像转换为RGB, 同时确保是彩色
def _ensure_bgr2rgb(img):
    if img is None:
        return None
    if len(img.shape) == 2:  # 灰度图
        return cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
    elif img.shape[2] == 1:  # 单通道
        return cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
    elif img.shape[2] == 3:  # BGR->RGB
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        return np.clip(img, 0, 255).astype('uint8')  # 新增保证
    else:
        print(f"[WARNING] 非标准图像通道数: {img.shape}")
        return img


def _ensure_bgr(img):
    if img is None:
        return None
    if len(img.shape) == 2:  # 灰度图
        return cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    elif img.shape[2] == 1:  # 单通道
        return cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    elif img.shape[2] == 3:  # 已是BGR
        return img
    elif img.shape[2] == 4:  # BGRA -> BGR
        return cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)
    else:
        print(f"[WARNING] 非标准图像通道数: {img.shape}")
        return img[:, :, :3]  # 默认保前三通道
