# -*- coding: utf-8 -*-
# @Time    : 2025/5/23 16:08
# @Author  : CFuShn
# @Comments: 全局上下文文件,用于加载配置信息,统管上下文
# @Software: PyCharm

try:
    import tomllib  # Python 3.11+
except ModuleNotFoundError:
    import tomli as tomllib  # For Python <3.11
from dataclasses import dataclass
from typing import Optional

from accelerate.utils import set_seed


@dataclass
class CFuShnContext:
    # sys & env
    seed = 3407  # 3407 is all you need

    # 系统,环境
    project_root = ""
    output_root = ""
    ckpt_version = ""

    # 上下文传递
    # ...

    def __str__(self) -> str:
        """一行一行打印参数"""
        pretty = ""
        # for key, value in self.__dict__.items():
        #     pretty += (f"{key}: {value}\n" if key != "_instance" else "")
        # 上面的方法无法保证属性是有序输出的,
        # 使用__annotations__获取成员变量就是有序的, 但是在定义时必须指定其类型
        # eg: version = xxx 就不在__annotations__中, 必须指定类型: version:str = xxx
        for key in self.__annotations__.keys():
            pretty += (f"{key}: {getattr(self, key)}\n" if key != "_instance" else "")
        return pretty

    # 单例实例
    _instance: Optional["CFuShnContext"] = None
    _initialized = False  # 初始化保护

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        """
        整个项目基础上下文的初始化
        """
        if self._initialized:
            return  # 防止重复初始化
        self._initialized = True

        # 设置所有相关的的随机数种子
        # use accelerate lib # set the seed in `random`, `numpy`, `torch`
        set_seed(self.seed)


# 实例化并作为全局配置对象
ctx = CFuShnContext()
