# -*- coding: utf-8 -*-
# @Time    : 2026/5/8 16:13
# @Author  : CFuShn
# @Comments:
# @Software: PyCharm

from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path
from typing import Optional, TYPE_CHECKING

from loguru import logger

if TYPE_CHECKING:  # pragma: no cover
    from loguru import Logger

_LOGGER_INITIALIZED = False
_LOG_PATH = None


class TqdmCompatibleSink:
    """
    用 tqdm.write() 替代普通 print/stderr 写入，避免打乱 tqdm 进度条。
    """

    def __init__(self):
        try:
            from tqdm import tqdm
            self._tqdm = tqdm
        except Exception:
            self._tqdm = None

    def write(self, message: str):
        message = message.rstrip("\n")
        if not message:
            return

        if self._tqdm is not None:
            self._tqdm.write(message)
        else:
            print(message, file=sys.stderr)

    def flush(self):
        pass


def setup_logger(
        log_dir: str | Path = "logs",
        name: Optional[str] = None,
        level: str = "INFO",
        console: bool = True,
        file: bool = True,
        rotation: str = "50 MB",
        retention: str = "30 days",
        enqueue: bool = False,
        allow_reconfigure: bool = False,
) -> tuple["Logger", Path]:
    """
    项目统一 logger 初始化。

    默认行为：
    - 只允许初始化一次
    - 控制台彩色输出
    - txt 文件纯文本输出
    - INFO 级别
    - tqdm 兼容
    - logger.bind(console=False).info(...) 可仅写文件

    如果确实想重新配置，显式传 allow_reconfigure=True。
    """

    global _LOGGER_INITIALIZED, _LOG_PATH

    if _LOGGER_INITIALIZED and not allow_reconfigure:
        raise RuntimeError(
            f"setup_logger() has already been called once. "
            f"Current log file: {_LOG_PATH}. "
            f"If you really want to reconfigure logger, call "
            f"setup_logger(..., allow_reconfigure=True)."
        )

    logger.remove()

    log_dir = Path(log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)

    if name is None:
        name = datetime.now().strftime("%Y%m%d_%H%M%S")

    log_path = log_dir / f"{name}.txt"

    console_fmt = (
        "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | "
        "<level>{level:<8}</level> | "
        "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> | "
        "<level>{message}</level>"
    )

    file_fmt = (
        "{time:YYYY-MM-DD HH:mm:ss.SSS} | "
        "{level:<8} | "
        "{name}:{function}:{line} | "
        "{message}"
    )

    def console_filter(record):
        return record["extra"].get("console", True)

    if console:
        logger.add(
            TqdmCompatibleSink(),
            level=level,
            format=console_fmt,
            filter=console_filter,
            colorize=True,
            enqueue=enqueue,
        )

    if file:
        logger.add(
            log_path,
            level=level,
            format=file_fmt,
            encoding="utf-8",
            rotation=rotation,
            retention=retention,
            colorize=False,
            enqueue=enqueue,
        )

    _LOGGER_INITIALIZED = True
    _LOG_PATH = log_path

    logger.info(f"Log file: {log_path}")

    return logger, log_path
