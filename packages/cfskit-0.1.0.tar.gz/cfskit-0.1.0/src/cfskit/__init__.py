# -*- coding: utf-8 -*-
# @Time    : 2026/5/8 17:32
# @Author  : CFuShn
# @Comments:
# @Software: PyCharm

from __future__ import annotations

from typing import Any

from cfskit.t02_log_util import setup_logger
from cfskit.t03_tb_util import setup_tensorboard, TensorBoardWritter


def _package_version() -> str:
    try:
        from importlib.metadata import PackageNotFoundError, version

        try:
            return version("cfskit")
        except PackageNotFoundError:
            # Editable install / source tree without metadata
            return "0.1.0"
    except Exception:
        return "0.1.0"


__version__ = _package_version()

__all__ = [
    "__version__",
    # log
    "setup_logger",
    # tensorboard
    "setup_tensorboard",
    "TensorBoardWritter",
    # ipc
    "t04_ipc_util",
]

_EXPORTS: dict[str, tuple[str, str]] = {
    # log
    "setup_logger": ("cfskit.t02_log_util", "setup_logger"),
    # tensorboard
    "setup_tensorboard": ("cfskit.t03_tb_util", "setup_tensorboard"),
    "TensorBoardLogger": ("cfskit.t03_tb_util", "TensorBoardLogger"),
    "NullTensorBoardLogger": ("cfskit.t03_tb_util", "NullTensorBoardLogger"),
    # ipc
    "register_signal_handler": ("cfskit.t04_ipc_util", "register_signal_handler"),
    "get_s1": ("cfskit.t04_ipc_util", "get_s1"),
    "get_s2": ("cfskit.t04_ipc_util", "get_s2"),
    "switch_s1": ("cfskit.t04_ipc_util", "switch_s1"),
    "switch_s2": ("cfskit.t04_ipc_util", "switch_s2"),
}


def __getattr__(name: str) -> Any:
    """
    顶层 API 惰性导入，避免 `import cfskit` 因为可选依赖缺失而失败。
    """
    if name not in _EXPORTS:
        raise AttributeError(f"module 'cfskit' has no attribute '{name}'")

    module_name, attr_name = _EXPORTS[name]
    from importlib import import_module

    mod = import_module(module_name)
    return getattr(mod, attr_name)


def __dir__() -> list[str]:
    return sorted(set(globals().keys()) | set(_EXPORTS.keys()))
