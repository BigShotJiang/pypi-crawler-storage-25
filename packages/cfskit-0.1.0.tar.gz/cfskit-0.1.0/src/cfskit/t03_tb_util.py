# -*- coding: utf-8 -*-
# @Time    : 2026/5/8 16:13
# @Author  : CFuShn
# @Comments:
# @Software: PyCharm

from __future__ import annotations

import json
import socket
from datetime import datetime
from pathlib import Path
from typing import Any, Optional, Mapping, Union, TYPE_CHECKING

if TYPE_CHECKING:  # pragma: no cover
    import torch
    from torch.utils.tensorboard import SummaryWriter

_TB_INITIALIZED = False


def _is_main_process(accelerator=None) -> bool:
    if accelerator is None:
        return True
    return bool(accelerator.is_main_process)


def _to_float(value: Any) -> float:
    """
    尽量把 torch scalar / numpy scalar / python number 转成 float。
    """
    try:
        import torch  # type: ignore

        if isinstance(value, torch.Tensor):
            value = value.detach()
            if value.numel() != 1:
                raise ValueError(f"Expected scalar tensor, got shape={tuple(value.shape)}")
            return float(value.item())
    except Exception:
        pass
    return float(value)


def _to_device_cpu(x: Any):
    """
    TensorBoard 写图片/直方图时，尽量 detach + cpu，避免持有计算图或 GPU 显存。
    """
    try:
        import torch  # type: ignore

        if isinstance(x, torch.Tensor):
            return x.detach().cpu()
    except Exception:
        pass
    return x


class NullTensorBoardWritter:
    """
    非主进程使用的空操作 logger。
    这样训练代码可以无脑写 tb.scalar(...)，不用到处 if rank0。
    """

    enabled = False
    log_dir = None
    writer = None

    def __getattr__(self, name):
        def noop(*args, **kwargs):
            return None

        return noop

    def close(self):
        return None

    def flush(self):
        return None


class TensorBoardWritter:
    """
    对 SummaryWriter 的轻量封装。

    常用方法：
    - scalar
    - scalars
    - metrics
    - image
    - images
    - histogram
    - histograms
    - text
    - config
    - graph
    - flush
    - close
    """

    enabled = True

    def __init__(
            self,
            log_dir: str | Path,
            *,
            max_queue: int = 10,
            flush_secs: int = 120,
            comment: str = "",
            filename_suffix: str = "",
    ):
        try:
            from torch.utils.tensorboard import SummaryWriter  # type: ignore
        except Exception as e:  # pragma: no cover
            raise ImportError(
                "TensorBoardLogger 需要 PyTorch。请执行：pip install \"cfskit[torch]\"（或 cfskit[tb]）。"
            ) from e

        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)

        self.writer: "SummaryWriter" = SummaryWriter(
            log_dir=str(self.log_dir),
            comment=comment,
            max_queue=max_queue,
            flush_secs=flush_secs,
            filename_suffix=filename_suffix,
        )

    def scalar(self, tag: str, value: Any, step: int):
        self.writer.add_scalar(tag, _to_float(value), global_step=step)

    def scalars(self, main_tag: str, tag_scalar_dict: Mapping[str, Any], step: int):
        values = {k: _to_float(v) for k, v in tag_scalar_dict.items()}
        self.writer.add_scalars(main_tag, values, global_step=step)

    def metrics(
            self,
            metrics: Mapping[str, Any],
            step: int,
            *,
            prefix: Optional[str] = None,
    ):
        """
        批量写 scalar。

        示例：
            tb.metrics({"loss": loss, "lr": lr}, step, prefix="Train")
        写成：
            Train/loss
            Train/lr
        """
        for k, v in metrics.items():
            tag = f"{prefix}/{k}" if prefix else k
            self.scalar(tag, v, step)

    def image(
            self,
            tag: str,
            img_tensor: "torch.Tensor",
            step: int,
            *,
            dataformats: str = "CHW",
    ):
        """
        写单张图片。

        常见格式：
        - CHW: [C, H, W]
        - HWC: [H, W, C]
        """
        img_tensor = _to_device_cpu(img_tensor)
        self.writer.add_image(
            tag,
            img_tensor,
            global_step=step,
            dataformats=dataformats,
        )

    def images(
            self,
            tag: str,
            img_tensor: "torch.Tensor",
            step: int,
            *,
            dataformats: str = "NCHW",
    ):
        """
        写一组图片。

        常见格式：
        - NCHW: [N, C, H, W]
        - NHWC: [N, H, W, C]
        """
        img_tensor = _to_device_cpu(img_tensor)
        self.writer.add_images(
            tag,
            img_tensor,
            global_step=step,
            dataformats=dataformats,
        )

    def image_grid(
            self,
            tag: str,
            img_tensor: "torch.Tensor",
            step: int,
            *,
            nrow: int = 4,
            normalize: bool = True,
            value_range: Optional[tuple[float, float]] = None,
    ):
        """
        把 [B, C, H, W] 做成 grid 后写入。
        SR / ContSR 任务非常常用。
        """
        from torchvision.utils import make_grid

        img_tensor = _to_device_cpu(img_tensor)

        grid = make_grid(
            img_tensor,
            nrow=nrow,
            normalize=normalize,
            value_range=value_range,
        )
        self.image(tag, grid, step, dataformats="CHW")

    def sr_triplet(
            self,
            tag: str,
            lr: "torch.Tensor",
            sr: "torch.Tensor",
            hr: "torch.Tensor",
            step: int,
            *,
            nrow: int = 4,
            normalize: bool = True,
            with_error: bool = True,
    ):
        """
        超分任务常用：一次性记录 LR / SR / HR / Error Map。

        要求：
        - lr / sr / hr 尽量都是 [B, C, H, W]
        - 如果 LR 尺寸小于 SR/HR，建议你在外面先 interpolate 到相同尺寸
        """
        self.image_grid(f"{tag}/lr", lr, step, nrow=nrow, normalize=normalize)
        self.image_grid(f"{tag}/sr", sr, step, nrow=nrow, normalize=normalize)
        self.image_grid(f"{tag}/hr", hr, step, nrow=nrow, normalize=normalize)

        if with_error:
            err = (sr.detach() - hr.detach()).abs()
            self.image_grid(f"{tag}/error", err, step, nrow=nrow, normalize=True)

    def histogram(self, tag: str, values: "torch.Tensor", step: int, *, bins: str = "tensorflow"):
        values = _to_device_cpu(values)
        self.writer.add_histogram(tag, values, global_step=step, bins=bins)

    def histograms(
            self,
            model: "torch.nn.Module",
            step: int,
            *,
            log_weights: bool = True,
            log_grads: bool = True,
            prefix: str = "",
    ):
        """
        记录模型权重和梯度分布。
        注意：不要每个 step 都写，建议几百/几千 step 写一次。
        """
        prefix = prefix.strip("/")
        for name, param in model.named_parameters():
            safe_name = name.replace(".", "/")
            if prefix:
                safe_name = f"{prefix}/{safe_name}"

            if log_weights:
                self.histogram(f"Weights/{safe_name}", param, step)

            if log_grads and param.grad is not None:
                self.histogram(f"Gradients/{safe_name}", param.grad, step)

    def grad_norms(
            self,
            model: "torch.nn.Module",
            step: int,
            *,
            prefix: str = "GradNorm",
            norm_type: float = 2.0,
    ):
        """
        记录每个参数的梯度范数。
        比 histogram 更轻量。
        """
        for name, param in model.named_parameters():
            if param.grad is None:
                continue
            tag = f"{prefix}/{name.replace('.', '/')}"
            value = param.grad.detach().norm(norm_type)
            self.scalar(tag, value, step)

    def text(self, tag: str, text_string: str, step: int = 0):
        self.writer.add_text(tag, text_string, global_step=step)

    def config(self, config: Any, step: int = 0, tag: str = "Config"):
        """
        写入配置。
        支持 dict / list / str / 其他可 json 化对象。
        """
        if isinstance(config, str):
            text = config
        else:
            try:
                text = json.dumps(config, indent=2, ensure_ascii=False)
                text = f"```json\n{text}\n```"
            except TypeError:
                text = f"```text\n{str(config)}\n```"

        self.text(tag, text, step=step)

    def graph(self, model: "torch.nn.Module", input_to_model: Any):
        """
        记录模型 graph。
        对动态 forward / 多输入模型可能失败，这是 TensorBoard graph 本身限制。
        """
        try:
            import torch  # type: ignore

            if isinstance(input_to_model, torch.Tensor):
                input_to_model = input_to_model.detach()
            elif isinstance(input_to_model, tuple):
                input_to_model = tuple(
                    x.detach() if isinstance(x, torch.Tensor) else x
                    for x in input_to_model
                )
        except Exception:
            pass
        self.writer.add_graph(model, input_to_model)

    def hparams(
            self,
            hparam_dict: Mapping[str, Any],
            metric_dict: Mapping[str, Any],
    ):
        """
        记录超参数。
        注意：SummaryWriter.add_hparams 会生成额外子目录，TensorBoard 里显示方式和普通 scalar 不完全一样。
        """
        clean_metrics = {k: _to_float(v) for k, v in metric_dict.items()}
        self.writer.add_hparams(dict(hparam_dict), clean_metrics)

    def flush(self):
        self.writer.flush()

    def close(self):
        self.writer.flush()
        self.writer.close()


def setup_tensorboard(
        log_dir: str | Path = "runs",
        name: Optional[str] = None,
        *,
        project: Optional[str] = None,
        run_id: Optional[str] = None,
        accelerator=None,
        max_queue: int = 10,
        flush_secs: int = 120,
        comment: str = "",
        filename_suffix: str = "",
        allow_reconfigure: bool = False,
) -> Union["TensorBoardWritter", "NullTensorBoardWritter"]:
    global _TB_INITIALIZED

    if _TB_INITIALIZED and not allow_reconfigure:
        raise RuntimeError(
            "setup_tensorboard() has already been called once. "
            "If you really want to reconfigure it, call "
            "setup_tensorboard(..., allow_reconfigure=True)."
        )

    is_main = _is_main_process(accelerator)

    base_dir = Path(log_dir)

    if run_id is not None:
        run_name = run_id
    else:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        hostname = socket.gethostname()

        if name is None:
            run_name = f"{timestamp}_{hostname}"
        else:
            run_name = f"{timestamp}_{hostname}_{name}"

    if project is not None:
        tb_log_dir = base_dir / project / run_name
    else:
        tb_log_dir = base_dir / run_name

    if is_main:
        tb = TensorBoardWritter(
            tb_log_dir,
            max_queue=max_queue,
            flush_secs=flush_secs,
            comment=comment,
            filename_suffix=filename_suffix,
        )
    else:
        tb = NullTensorBoardWritter()

    _TB_INITIALIZED = True

    return tb
