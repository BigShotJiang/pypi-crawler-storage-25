# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tests.utils import assert_matches_type
from vitable_connect import VitableConnect, AsyncVitableConnect
from vitable_connect.types import BenefitEligibilityPolicyResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestBenefitEligibilityPolicies:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: VitableConnect) -> None:
        benefit_eligibility_policy = client.benefit_eligibility_policies.retrieve(
            "epol_abc123def456",
        )
        assert_matches_type(BenefitEligibilityPolicyResponse, benefit_eligibility_policy, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: VitableConnect) -> None:
        response = client.benefit_eligibility_policies.with_raw_response.retrieve(
            "epol_abc123def456",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        benefit_eligibility_policy = response.parse()
        assert_matches_type(BenefitEligibilityPolicyResponse, benefit_eligibility_policy, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: VitableConnect) -> None:
        with client.benefit_eligibility_policies.with_streaming_response.retrieve(
            "epol_abc123def456",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            benefit_eligibility_policy = response.parse()
            assert_matches_type(BenefitEligibilityPolicyResponse, benefit_eligibility_policy, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_retrieve(self, client: VitableConnect) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `policy_id` but received ''"):
            client.benefit_eligibility_policies.with_raw_response.retrieve(
                "",
            )


class TestAsyncBenefitEligibilityPolicies:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncVitableConnect) -> None:
        benefit_eligibility_policy = await async_client.benefit_eligibility_policies.retrieve(
            "epol_abc123def456",
        )
        assert_matches_type(BenefitEligibilityPolicyResponse, benefit_eligibility_policy, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncVitableConnect) -> None:
        response = await async_client.benefit_eligibility_policies.with_raw_response.retrieve(
            "epol_abc123def456",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        benefit_eligibility_policy = await response.parse()
        assert_matches_type(BenefitEligibilityPolicyResponse, benefit_eligibility_policy, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncVitableConnect) -> None:
        async with async_client.benefit_eligibility_policies.with_streaming_response.retrieve(
            "epol_abc123def456",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            benefit_eligibility_policy = await response.parse()
            assert_matches_type(BenefitEligibilityPolicyResponse, benefit_eligibility_policy, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncVitableConnect) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `policy_id` but received ''"):
            await async_client.benefit_eligibility_policies.with_raw_response.retrieve(
                "",
            )
