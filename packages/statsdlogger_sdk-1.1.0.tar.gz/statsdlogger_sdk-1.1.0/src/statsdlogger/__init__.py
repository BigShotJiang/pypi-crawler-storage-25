"""Minimal monitoring helpers."""

import logging
import time

__version__ = "0.1.0"


class MetricsLogger:
    """Lightweight logger that emits structured metric events."""

    def __init__(self, prefix: str = "", level: int = logging.INFO):
        self.prefix = prefix
        self._log = logging.getLogger(__name__)
        self._log.setLevel(level)

    def _event(self, kind: str, name: str, value, tags=None):
        tags = tags or {}
        return {
            "ts": time.time(),
            "type": kind,
            "name": f"{self.prefix}{name}" if self.prefix else name,
            "value": value,
            "tags": tags,
        }

    def count(self, name: str, value: int = 1, tags=None):
        self._log.info(self._event("count", name, value, tags))

    def gauge(self, name: str, value: float, tags=None):
        self._log.info(self._event("gauge", name, value, tags))

    def timing(self, name: str, ms: float, tags=None):
        self._log.info(self._event("timing", name, ms, tags))


def get_logger(prefix: str = "") -> MetricsLogger:
    return MetricsLogger(prefix=prefix)
