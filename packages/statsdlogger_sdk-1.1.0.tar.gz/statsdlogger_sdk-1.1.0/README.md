# statsdlogger

Instrument services, emit metrics and traces, structure logs, and integrate with Grafana-style observability stacks.

## Installation

```bash
pip install statsdlogger
```

## Usage

```python
import statsdlogger
```

See `src/statsdlogger/__init__.py` for the available API surface.

## License

MIT
