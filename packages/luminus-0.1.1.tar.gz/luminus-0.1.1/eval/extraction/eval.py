"""
eval/extraction/eval.py — Luminus extraction prompt evaluator.

Runs the extraction prompt against hand-crafted transcripts, grades each
output with a model grader, and produces an HTML report.

Usage:
    cd cli-v0
    ANTHROPIC_API_KEY=sk-... python eval/extraction/eval.py

Output:
    eval/extraction/reports/report-YYYY-MM-DD-HHMMSS.html
"""

from __future__ import annotations

import json
import os
import sys
from datetime import datetime
from pathlib import Path
from statistics import mean

import anthropic

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

EVAL_DIR = Path(__file__).parent
PROMPTS_DIR = EVAL_DIR.parent.parent / "luminus" / "prompts"
REPORTS_DIR = EVAL_DIR / "reports"
DATASET_FILE = EVAL_DIR / "dataset.json"

EXTRACTION_PROMPT_FILE = PROMPTS_DIR / "extraction_v0.5.md"

# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------

EXTRACTION_MODEL = "claude-haiku-4-5-20251001"
GRADER_MODEL = "claude-haiku-4-5-20251001"

# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------


def make_client() -> anthropic.Anthropic:
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("Error: ANTHROPIC_API_KEY is not set.")
        sys.exit(1)
    return anthropic.Anthropic(api_key=api_key)


# ---------------------------------------------------------------------------
# Extraction
# ---------------------------------------------------------------------------


def run_extraction(client: anthropic.Anthropic, transcript: str) -> str:
    """Run the extraction prompt against a transcript. Returns raw model output."""
    template = EXTRACTION_PROMPT_FILE.read_text("utf-8")
    prompt = template.replace("{transcript}", transcript)

    response = client.messages.create(
        model=EXTRACTION_MODEL,
        max_tokens=1024,
        messages=[{"role": "user", "content": prompt}],
    )
    return response.content[0].text.strip()


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


def validate_json_array(raw: str) -> tuple[bool, list | None]:
    """
    Returns (is_valid, parsed_value).
    Strips markdown code fences before parsing.
    """
    text = raw
    if text.startswith("```"):
        parts = text.split("```", 2)
        text = parts[1]
        if text.startswith("json"):
            text = text[4:]
        text = text.strip()

    try:
        parsed = json.loads(text)
        if isinstance(parsed, list):
            return True, parsed
        return False, None
    except json.JSONDecodeError:
        return False, None


# ---------------------------------------------------------------------------
# Model grader
# ---------------------------------------------------------------------------

GRADER_PROMPT = """\
Your task is to evaluate the following extraction output with strict rigor.

The extraction prompt was asked to extract named entities (people, situations,
intentions, struggles) from a Luminus companion session transcript. It should
return a JSON array of entity objects.

Original transcript:
<transcript>
{transcript}
</transcript>

Extraction output to evaluate:
<output>
{output}
</output>

Criteria for this specific test case:
<criteria>
{criteria}
</criteria>

Mandatory requirements (ANY violation = score of 3 or lower):
<mandatory>
- Output must be a valid JSON array. Anything else fails immediately.
- Only extract entities the USER mentioned (role: You), not the companion (Luminus).
- Do not fabricate entities not present in the transcript.
- Emotional states caused by an already-extracted entity must NOT appear as a
  separate struggle entity. If the user is afraid because of Sarah, that fear
  belongs in Sarah's companion_note — not as a separate "fear of Sarah" entity.
  Any output that creates a struggle entity for an emotion directly tied to
  another entity in the same output is a violation.
- Theological questions and doctrines (faith, resurrection, inherited belief,
  the nature of God) must NOT be extracted as entities, regardless of how
  specific or personal the phrasing sounds.
</mandatory>

Check each test case criterion independently. A criterion that says something
is NOT extracted must be verified — if the output contains that thing, it fails
that criterion even if everything else looks correct.

Scoring guidelines:
- 1–3: Fails a mandatory requirement
- 4–6: Valid JSON but misses required entities, wrong types, wrong statuses,
       or contains entities that should have been excluded per criteria
- 7–8: Gets the main entities right with minor issues (companion_note phrasing, etc.)
- 9–10: Fully correct — right names, types, statuses, companion_notes,
        and nothing present that the criteria says should be absent

Respond with a JSON object in this exact shape:
{{
    "strengths": ["...", "..."],
    "weaknesses": ["...", "..."],
    "reasoning": "...",
    "score": <number 1-10>
}}

Respond with JSON only. No prose, no markdown fences."""


def grade_output(
    client: anthropic.Anthropic,
    test_case: dict,
    raw_output: str,
) -> dict:
    """Grade extraction output. Returns {score, reasoning, strengths, weaknesses}."""
    criteria_str = "\n".join(f"- {c}" for c in test_case["solution_criteria"])
    transcript = test_case["prompt_inputs"]["transcript"]

    prompt = (
        GRADER_PROMPT
        .replace("{transcript}", transcript)
        .replace("{output}", raw_output)
        .replace("{criteria}", criteria_str)
    )

    response = client.messages.create(
        model=GRADER_MODEL,
        max_tokens=512,
        temperature=0,
        messages=[
            {"role": "user", "content": prompt},
            {"role": "assistant", "content": "```json"},
        ],
        stop_sequences=["```"],
    )
    raw = response.content[0].text.strip()
    return json.loads(raw)


# ---------------------------------------------------------------------------
# Run evaluation
# ---------------------------------------------------------------------------


def run_eval(client: anthropic.Anthropic, dataset: list[dict]) -> list[dict]:
    results = []

    for i, test_case in enumerate(dataset, 1):
        print(f"  [{i}/{len(dataset)}] {test_case['scenario'][:60]}...")

        transcript = test_case["prompt_inputs"]["transcript"]
        raw_output = run_extraction(client, transcript)

        is_valid, _ = validate_json_array(raw_output)
        grade = grade_output(client, test_case, raw_output)

        # If JSON is invalid, cap score regardless of model grade
        score = grade["score"] if is_valid else min(grade["score"], 3)

        results.append({
            "test_case": test_case,
            "output": raw_output,
            "json_valid": is_valid,
            "score": score,
            "reasoning": grade["reasoning"],
            "strengths": grade.get("strengths", []),
            "weaknesses": grade.get("weaknesses", []),
        })

    return results


# ---------------------------------------------------------------------------
# HTML report (adapted from Anthropic prompt eval course)
# ---------------------------------------------------------------------------


def generate_html_report(results: list[dict], prompt_version: str, prompt_text: str = "") -> str:
    total = len(results)
    scores = [r["score"] for r in results]
    avg = mean(scores) if scores else 0
    pass_rate = 100 * len([s for s in scores if s >= 7]) / total if total else 0

    def score_class(s: int) -> str:
        if s >= 8:
            return "score-high"
        if s >= 5:
            return "score-medium"
        return "score-low"

    rows = ""
    for r in results:
        tc = r["test_case"]
        strengths = "".join(f"<li>{s}</li>" for s in r["strengths"])
        weaknesses = "".join(f"<li>{w}</li>" for w in r["weaknesses"])
        criteria = "".join(f"<li>{c}</li>" for c in tc["solution_criteria"])
        json_badge = (
            '<span class="badge badge-pass">JSON ✓</span>'
            if r["json_valid"]
            else '<span class="badge badge-fail">JSON ✗</span>'
        )

        rows += f"""
        <tr>
            <td><strong>{tc["scenario"]}</strong></td>
            <td class="output"><pre>{r["output"]}</pre></td>
            <td><ul>{criteria}</ul></td>
            <td>
                <ul class="strengths">{strengths}</ul>
                <ul class="weaknesses">{weaknesses}</ul>
                {json_badge}
            </td>
            <td class="score-col">
                <span class="score {score_class(r["score"])}">{r["score"]}</span>
            </td>
            <td class="reasoning">{r["reasoning"]}</td>
        </tr>"""

    prompt_block = ""
    if prompt_text:
        escaped = prompt_text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        prompt_block = f"""
    <details class="prompt-details">
      <summary>Show prompt — <code>{prompt_version}</code></summary>
      <pre class="prompt-pre">{escaped}</pre>
    </details>"""

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Luminus Extraction Eval — {prompt_version}</title>
  <style>
    body {{ font-family: Arial, sans-serif; line-height: 1.6; margin: 0; padding: 20px; color: #333; }}
    h1 {{ margin-bottom: 4px; }}
    .meta {{ color: #888; font-size: 14px; margin-bottom: 20px; }}
    .header {{ background: #f5f5f5; padding: 20px; border-radius: 6px; margin-bottom: 24px; }}
    .summary-stats {{ display: flex; gap: 16px; flex-wrap: wrap; margin-top: 16px; }}
    .stat-box {{ background: #fff; border-radius: 6px; padding: 14px 20px;
                 box-shadow: 0 1px 4px rgba(0,0,0,0.1); min-width: 160px; }}
    .stat-label {{ font-size: 13px; color: #888; }}
    .stat-value {{ font-size: 26px; font-weight: bold; margin-top: 2px; }}
    table {{ width: 100%; border-collapse: collapse; margin-top: 8px; font-size: 14px; }}
    th {{ background: #333; color: #fff; text-align: left; padding: 10px 12px; }}
    td {{ padding: 10px 12px; border-bottom: 1px solid #e5e5e5; vertical-align: top; }}
    tr:nth-child(even) {{ background: #fafafa; }}
    pre {{ background: #f5f5f5; border: 1px solid #ddd; border-radius: 4px;
           padding: 10px; font-size: 12px; white-space: pre-wrap; word-break: break-word;
           margin: 0; max-height: 240px; overflow-y: auto; }}
    .score {{ font-weight: bold; padding: 4px 10px; border-radius: 4px; display: inline-block; }}
    .score-high  {{ background: #c8e6c9; color: #2e7d32; }}
    .score-medium {{ background: #fff9c4; color: #f57f17; }}
    .score-low   {{ background: #ffcdd2; color: #c62828; }}
    .score-col {{ width: 60px; text-align: center; }}
    .badge {{ font-size: 12px; padding: 2px 8px; border-radius: 3px;
              display: inline-block; margin-top: 6px; }}
    .badge-pass {{ background: #c8e6c9; color: #2e7d32; }}
    .badge-fail {{ background: #ffcdd2; color: #c62828; }}
    ul {{ margin: 0; padding-left: 18px; }}
    ul.strengths li {{ color: #2e7d32; }}
    ul.weaknesses li {{ color: #c62828; }}
    .reasoning {{ font-size: 13px; color: #555; }}
    .output {{ width: 22%; }}
    .prompt-details {{ margin-top: 16px; }}
    .prompt-details summary {{ cursor: pointer; font-size: 13px; color: #666;
                               user-select: none; }}
    .prompt-details summary:hover {{ color: #333; }}
    .prompt-pre {{ background: #f5f5f5; border: 1px solid #ddd; border-radius: 4px;
                   padding: 14px; font-size: 12px; white-space: pre-wrap;
                   word-break: break-word; margin-top: 10px;
                   max-height: 400px; overflow-y: auto; }}
  </style>
</head>
<body>
  <div class="header">
    <h1>Luminus — Extraction Prompt Eval</h1>
    <div class="meta">Prompt: <strong>{prompt_version}</strong> &nbsp;·&nbsp;
         Model: <strong>{EXTRACTION_MODEL}</strong> &nbsp;·&nbsp;
         Generated: <strong>{datetime.now().strftime("%Y-%m-%d %H:%M")}</strong></div>
    <div class="summary-stats">
      <div class="stat-box">
        <div class="stat-label">Test cases</div>
        <div class="stat-value">{total}</div>
      </div>
      <div class="stat-box">
        <div class="stat-label">Average score</div>
        <div class="stat-value">{avg:.1f} / 10</div>
      </div>
      <div class="stat-box">
        <div class="stat-label">Pass rate (≥ 7)</div>
        <div class="stat-value">{pass_rate:.0f}%</div>
      </div>
    </div>
    {prompt_block}
  </div>

  <table>
    <thead>
      <tr>
        <th>Scenario</th>
        <th>Extraction output</th>
        <th>Criteria</th>
        <th>Strengths / Weaknesses</th>
        <th>Score</th>
        <th>Reasoning</th>
      </tr>
    </thead>
    <tbody>
      {rows}
    </tbody>
  </table>
</body>
</html>"""


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    client = make_client()

    print(f"Loading dataset from {DATASET_FILE}")
    dataset = json.loads(DATASET_FILE.read_text("utf-8"))

    prompt_version = EXTRACTION_PROMPT_FILE.stem  # e.g. "extraction_v0.1"
    print(f"Prompt: {prompt_version}")
    print(f"Running {len(dataset)} test cases...\n")

    results = run_eval(client, dataset)

    scores = [r["score"] for r in results]
    avg = mean(scores)
    pass_count = len([s for s in scores if s >= 7])

    print(f"\nResults:")
    for r in results:
        status = "PASS" if r["score"] >= 7 else "FAIL"
        print(f"  [{status}] {r['score']:2d}/10  {r['test_case']['scenario'][:55]}")

    print(f"\nAverage: {avg:.1f}/10   Pass rate: {pass_count}/{len(scores)}")

    # Write HTML report
    REPORTS_DIR.mkdir(exist_ok=True)
    timestamp = datetime.now().strftime("%Y-%m-%d-%H%M%S")
    report_path = REPORTS_DIR / f"report-{prompt_version}-{timestamp}.html"
    prompt_text = EXTRACTION_PROMPT_FILE.read_text("utf-8")
    html = generate_html_report(results, prompt_version, prompt_text)
    report_path.write_text(html, encoding="utf-8")

    print(f"\nReport saved to: {report_path}")

    # Also write raw results JSON for diffing between prompt versions
    json_path = REPORTS_DIR / f"results-{prompt_version}-{timestamp}.json"
    json_path.write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")
    print(f"Raw results:    {json_path}")


if __name__ == "__main__":
    main()
