"""
Runtime configuration and path constants.

All local storage lives under LUMINUS_HOME (~/.luminus/ by default).
Override with LUMINUS_HOME env var for testing.
"""

import os
from pathlib import Path

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

LUMINUS_HOME = Path(os.environ.get("LUMINUS_HOME", Path.home() / ".luminus"))


def _load_env_file() -> None:
    """Load ~/.luminus/.env into os.environ if ANTHROPIC_API_KEY is not already set."""
    if os.environ.get("ANTHROPIC_API_KEY"):
        return
    env_file = LUMINUS_HOME / ".env"
    if not env_file.exists():
        return
    for line in env_file.read_text("utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, _, value = line.partition("=")
            os.environ.setdefault(key.strip(), value.strip())


_load_env_file()
SESSIONS_DIR = LUMINUS_HOME / "sessions"
COVENANT_FILE = LUMINUS_HOME / "covenant.json"
ENTITIES_FILE = LUMINUS_HOME / "entities.json"


def ensure_dirs() -> None:
    LUMINUS_HOME.mkdir(parents=True, exist_ok=True)
    SESSIONS_DIR.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# Model identifiers
# ---------------------------------------------------------------------------

SESSION_MODEL = "claude-haiku-4-5-20251001"
EXTRACTION_MODEL = "claude-haiku-4-5-20251001"
MORNING_MODEL = "claude-sonnet-4-6"

# ---------------------------------------------------------------------------
# Prompt versions
# ---------------------------------------------------------------------------

SESSION_PROMPT_VERSION = "v1.0"
EXTRACTION_PROMPT_VERSION = "v0.5"
MORNING_PROMPT_VERSION = "v1.1"
ONBOARDING_PROMPT_VERSION = "v1.1"

# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

PROMPTS_DIR = Path(__file__).parent / "prompts"

# ---------------------------------------------------------------------------
# Extraction window
# ---------------------------------------------------------------------------

# Entities last mentioned within this many days are eligible for morning questions
MORNING_ENTITY_WINDOW_DAYS = 7

# Sessions fed as context to session agent
SESSION_CONTEXT_COUNT = 3
