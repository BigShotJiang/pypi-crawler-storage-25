"""
Onboarding agent — drives the luminus start conversation.

Two responsibilities:
1. stream_response(): streaming conversation turn for the onboarding chat.
2. extract_fields(): haiku call to pull structured fields from the finished
   conversation (lens, purpose, struggles, tradition).
"""

from __future__ import annotations

import json
from typing import Generator

import anthropic

from luminus.config import (
    EXTRACTION_MODEL,
    ONBOARDING_PROMPT_VERSION,
    PROMPTS_DIR,
    SESSION_MODEL,
)

COVENANT_START = "---COVENANT---"
COVENANT_END = "---END---"


def load_system_prompt() -> str:
    path = PROMPTS_DIR / "onboarding_v1.1.md"
    return path.read_text("utf-8")


def load_extraction_prompt() -> str:
    path = PROMPTS_DIR / "onboarding_extract_v0.8.md"
    return path.read_text("utf-8")


def stream_response(
    client: anthropic.Anthropic,
    messages: list[dict],
    system: str,
) -> Generator[str, None, str]:
    """
    Yields text chunks as they stream. Returns the full accumulated text.

    Usage:
        gen = stream_response(client, messages, system)
        full = ""
        for chunk in gen:
            print(chunk, end="", flush=True)
        full = gen.return  # not idiomatic — use the wrapper below instead
    """
    full_text = ""
    with client.messages.stream(
        model=SESSION_MODEL,
        max_tokens=1024,
        system=system,
        messages=messages,
    ) as stream:
        for chunk in stream.text_stream:
            full_text += chunk
            yield chunk
    return full_text


def run_turn(
    client: anthropic.Anthropic,
    messages: list[dict],
    system: str,
    on_chunk,
) -> str:
    """
    Run one conversation turn. Calls on_chunk(text) for each streamed chunk.
    Returns the full response text.
    """
    full_text = ""
    with client.messages.stream(
        model=SESSION_MODEL,
        max_tokens=1024,
        system=system,
        messages=messages,
    ) as stream:
        for chunk in stream.text_stream:
            full_text += chunk
            on_chunk(chunk)
    return full_text


def extract_covenant_from_text(text: str) -> str | None:
    """
    Return the covenant text if the companion has proposed one in this turn,
    otherwise None.
    """
    if COVENANT_START not in text or COVENANT_END not in text:
        return None
    inner = text.split(COVENANT_START, 1)[1].split(COVENANT_END, 1)[0]
    return inner.strip()


def extract_fields(
    client: anthropic.Anthropic,
    conversation_text: str,
) -> dict:
    """
    Haiku call: extract lens, purpose, struggles, tradition from the
    finished onboarding conversation.
    """
    prompt_template = load_extraction_prompt()
    prompt = prompt_template.replace("{transcript}", conversation_text)

    response = client.messages.create(
        model=EXTRACTION_MODEL,
        max_tokens=512,
        messages=[{"role": "user", "content": prompt}],
    )
    raw = response.content[0].text.strip()

    # Strip markdown code fences if present
    if raw.startswith("```"):
        raw = raw.split("```", 2)[1]
        if raw.startswith("json"):
            raw = raw[4:]
        raw = raw.strip()

    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        # Fallback: return safe defaults rather than crashing onboarding
        return {
            "lens": "paul",
            "purpose": "",
            "struggles": [],
            "tradition": None,
        }
