"""
Morning question agent — generates one contextual morning question.

Called by luminus morning before opening the morning session.
"""

from __future__ import annotations

from datetime import date, datetime, timezone

import anthropic

from luminus.config import MORNING_MODEL, PROMPTS_DIR
from luminus.storage.models import Covenant, Entity, Session


def _load_morning_prompt() -> str:
    return (PROMPTS_DIR / "morning_v1.1.md").read_text("utf-8")


def _format_entities(entities: list[Entity]) -> str:
    if not entities:
        return "None."
    lines = []
    for e in entities:
        note = e.companion_note or "no note"
        lines.append(
            f"- {e.name} ({e.type.value}) — \"{note}\" [last mentioned: {e.last_mentioned}]"
        )
    return "\n".join(lines)


def _days_since(last_session: Session | None, today: str) -> int:
    if not last_session:
        return 0
    try:
        last = date.fromisoformat(last_session.date)
        now = date.fromisoformat(today)
        return (now - last).days
    except (ValueError, AttributeError):
        return 0


def _days_since_label(days: int) -> str:
    if days == 0:
        return "0 (same day)"
    if days == 1:
        return "1 day ago"
    return f"{days} days ago"


def generate_morning_question(
    client: anthropic.Anthropic,
    covenant: Covenant,
    last_session: Session | None,
    pending_entities: list[Entity],
    today: str | None = None,
) -> str:
    """
    Generate one morning question. Returns the question string.

    If there is no last session and no pending entities, falls back to
    a covenant-based opening.
    """
    if today is None:
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    template = _load_morning_prompt()

    last_session_summary = (
        last_session.session_summary
        if last_session and last_session.session_summary
        else "No previous session yet."
    )

    days = _days_since(last_session, today)

    prompt = (
        template
        .replace("{name}", "you")
        .replace("{covenant_text}", covenant.text)
        .replace("{lens}", covenant.lens)
        .replace("{days_since}", _days_since_label(days))
        .replace("{last_session_summary}", last_session_summary)
        .replace("{pending_entities}", _format_entities(pending_entities))
    )

    response = client.messages.create(
        model=MORNING_MODEL,
        max_tokens=128,
        messages=[{"role": "user", "content": prompt}],
    )
    return response.content[0].text.strip()
