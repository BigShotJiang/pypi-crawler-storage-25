"""
Session agent — drives luminus chat and the chat portion of luminus morning.

Responsibilities:
1. build_session_system_prompt() — format session_v1.0.md with runtime context
2. run_session_turn()            — one streaming conversation turn
3. extract_entities()            — haiku call returning Entity list
4. generate_summary()            — haiku call returning 1-2 sentence summary
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from uuid import uuid4

import anthropic

from luminus.config import (
    EXTRACTION_MODEL,
    EXTRACTION_PROMPT_VERSION,
    PROMPTS_DIR,
    SESSION_MODEL,
    SESSION_PROMPT_VERSION,
)
from luminus.storage.models import (
    Covenant,
    Entity,
    EntityStatus,
    EntityType,
    Session,
)

# ---------------------------------------------------------------------------
# Prompt loading
# ---------------------------------------------------------------------------


def _load_session_prompt() -> str:
    return (PROMPTS_DIR / "session_v1.0.md").read_text("utf-8")


def _load_extraction_prompt() -> str:
    return (PROMPTS_DIR / "extraction_v0.5.md").read_text("utf-8")


# ---------------------------------------------------------------------------
# System prompt construction
# ---------------------------------------------------------------------------


def _format_recent_sessions(sessions: list[Session]) -> str:
    if not sessions:
        return "No previous sessions."
    lines = []
    for s in sessions:
        summary = s.session_summary or "(no summary)"
        lines.append(f"Date: {s.date} ({s.type.value})\nSummary: {summary}")
    return "\n---\n".join(lines)


def _format_entities(entities: list[Entity]) -> str:
    if not entities:
        return "None."
    lines = []
    for e in entities:
        note = e.companion_note or "no note"
        lines.append(
            f"- {e.name} ({e.type.value}) — \"{note}\" [last mentioned: {e.last_mentioned}]"
        )
    return "\n".join(lines)


def build_session_system_prompt(
    covenant: Covenant,
    recent_sessions: list[Session],
    pending_entities: list[Entity],
    today: str | None = None,
) -> str:
    template = _load_session_prompt()
    count = len(recent_sessions)
    today = today or datetime.now().strftime("%A, %B %d, %Y").replace(" 0", " ")

    # Use .replace() to avoid issues with literal {X} in the prompt body
    return (
        template
        .replace("{today}", today)
        .replace("{name}", "you")
        .replace("{covenant_text}", covenant.text)
        .replace("{lens}", covenant.lens)
        .replace("{session_count}", str(count))
        .replace("{recent_sessions}", _format_recent_sessions(recent_sessions))
        .replace("{pending_entities}", _format_entities(pending_entities))
    )


# ---------------------------------------------------------------------------
# Streaming conversation turn
# ---------------------------------------------------------------------------


def run_session_turn(
    client: anthropic.Anthropic,
    messages: list[dict],
    system: str,
    on_chunk,
) -> str:
    """Run one conversation turn, streaming chunks to on_chunk(). Returns full text."""
    full_text = ""
    with client.messages.stream(
        model=SESSION_MODEL,
        max_tokens=1024,
        system=system,
        messages=messages,
    ) as stream:
        for chunk in stream.text_stream:
            full_text += chunk
            on_chunk(chunk)
    return full_text


# ---------------------------------------------------------------------------
# Entity extraction
# ---------------------------------------------------------------------------


def _entity_id(name: str) -> str:
    slug = name.lower().replace(" ", "-")[:20]
    return f"{slug}-{uuid4().hex[:6]}"


def _parse_entity_type(raw: str) -> EntityType:
    try:
        return EntityType(raw)
    except ValueError:
        return EntityType.situation


def _parse_entity_status(raw: str) -> EntityStatus:
    try:
        return EntityStatus(raw)
    except ValueError:
        return EntityStatus.active


def extract_entities(
    client: anthropic.Anthropic,
    transcript: str,
    session_id: str,
    today: str,
) -> list[Entity]:
    """
    Call haiku to extract named entities from a session transcript.
    Returns a list of Entity objects ready for upsert.
    """
    template = _load_extraction_prompt()
    prompt = template.replace("{transcript}", transcript)

    response = client.messages.create(
        model=EXTRACTION_MODEL,
        max_tokens=1024,
        messages=[{"role": "user", "content": prompt}],
    )
    raw = response.content[0].text.strip()

    # Strip markdown code fences if present
    if raw.startswith("```"):
        raw = raw.split("```", 2)[1]
        if raw.startswith("json"):
            raw = raw[4:]
        raw = raw.strip()

    try:
        items = json.loads(raw)
    except json.JSONDecodeError:
        return []

    if not isinstance(items, list):
        return []

    entities = []
    for item in items:
        if not isinstance(item, dict) or "name" not in item:
            continue
        name = item.get("name", "").strip()
        if not name:
            continue
        entity = Entity(
            id=_entity_id(name),
            name=name,
            type=_parse_entity_type(item.get("type", "situation")),
            status=_parse_entity_status(item.get("status", "active")),
            first_session=today,
            last_mentioned=today,
            session_count=1,
            session_ids=[session_id],
            companion_note=item.get("companion_note"),
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        )
        entities.append(entity)

    return entities


# ---------------------------------------------------------------------------
# Session summary generation
# ---------------------------------------------------------------------------

_SUMMARY_PROMPT = """\
In 1–2 sentences, summarize what this person shared in this session.
Focus on named situations, emotional tone, and any stated intentions.
Be specific — not generic. No preamble, no explanation.

Session transcript:
{transcript}"""


def generate_summary(
    client: anthropic.Anthropic,
    transcript: str,
) -> str:
    """Generate a 1-2 sentence summary of a session using haiku."""
    prompt = _SUMMARY_PROMPT.replace("{transcript}", transcript)
    response = client.messages.create(
        model=EXTRACTION_MODEL,
        max_tokens=256,
        messages=[{"role": "user", "content": prompt}],
    )
    return response.content[0].text.strip()


# ---------------------------------------------------------------------------
# Transcript builder
# ---------------------------------------------------------------------------


def build_transcript(messages: list[dict]) -> str:
    lines = []
    for m in messages:
        role = "Luminus" if m["role"] == "assistant" else "You"
        lines.append(f"{role}: {m['content']}")
    return "\n\n".join(lines)
