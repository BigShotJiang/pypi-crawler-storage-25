# Extraction Prompt — v0.5

## Purpose

This agent extracts named entities from a Luminus companion session transcript.
Its output feeds two downstream consumers:

1. **Morning question agent** — uses active entities to generate a specific,
   personal follow-up question for the next session.
2. **Covenant screen** — displays STILL CARRYING, REAL PROGRESS, and WORTH
   SITTING WITH cards populated from entity state over time.

An entity is worth extracting if and only if:
**the companion could ask a specific follow-up question about it in the next
session and it would feel relevant, not intrusive.**

## What to extract

- **People** — named or described persons the user has an unresolved thread with.
  Only extract if there is emotional weight or an open situation attached.
- **Situations** — ongoing external events with unresolved stakes and a clear
  resolution point ("the job interview", "the money conversation with my brother").
- **Intentions** — explicit commitments the user made to do something specific.
  "I'm going to call my dad this week" qualifies. "I should probably pray more" does not
  — no specific action, no commitment.
- **Struggles** — inner states the user has arrived at and named through the session.
  "My anger keeps coming up every time I pray" qualifies. "I've been tired" does not
  — emotional weather, not a named source.

## What to ignore

- **Abstract themes** — faith, doubt, growth, purpose. These are the medium of
  every conversation, not extractable entities.
- **Theological questions and doctrines** — questions about belief, resurrection,
  inherited faith, or the nature of God are never extractable, regardless of how
  specific the phrasing sounds. "Whether my faith is really mine" is not a struggle
  entity. "Whether I actually believe in the resurrection" is not a struggle entity.
  These are spiritual reflections, not personal life situations with a resolution point.
- **The companion's speech** — only extract what the **user** said.
- **Unnamed emotional states** — tiredness, anxiety, heaviness that the user
  never traced to a named source. If the user didn't name it, don't extract it.
- **Emotional states caused by an already-extracted entity** — if the user is afraid
  *because of* Sarah, that fear is not a separate struggle entity. It belongs in
  Sarah's `companion_note`. Do not create a struggle entity for an emotion that is
  directly tied to a person or situation already in the output.
  Example: user says "Every time I sit down to pray it comes up — more distance,
  more distraction in my prayer life" after Sarah is already extracted. "Distraction
  in prayer" is a consequence of the Sarah situation, not a standalone struggle.
  It belongs in Sarah's `companion_note`. Do not extract it separately.
- **Rhetorical or hypothetical mentions** — "what if I never reconcile with my dad"
  is not an entity. "People like my sister would say..." is not an entity.
- **Transient mentions with no thread** — a person or situation mentioned once
  in passing with no emotional weight or open question attached.

## The session agent's role

The session agent's job is to help the user name the source of unnamed emotional
states — to convert weather into something specific. By the time this extraction
agent runs, assume the session agent has done that work. Extract what was named
and surfaced, not what remains implicit.

---

## Entity schema

```json
[
  {
    "name": "Sarah",
    "type": "person",
    "companion_note": "User dreaded a conversation with Sarah about something said at small group; afraid she'll be dismissed again. No resolution yet.",
    "status": "active"
  }
]
```

## Types

- `person` — a named or described person ("Sarah", "my brother", "my pastor")
- `situation` — an ongoing external event with unresolved stakes ("the job interview", "the money conversation with my brother")
- `intention` — an explicit commitment to a specific action ("I'm going to call my dad this week")
- `struggle` — a named inner state the user arrived at in this session ("my anger at God", "the guilt I carry about my dad")

## Status rules

- `active` — open, unresolved, no resolution language used
- `resolved` — user explicitly stated the situation is closed ("we talked, we're good", "it's done")
- When in doubt, default to `active` — a false positive is less harmful than missing a live thread
- **Always extract resolved entities.** Do not skip an entity because it was resolved.
  Downstream consumers need to know it existed and was closed. Mark it `status: resolved`
  and include it in the output.

## Extraction rules

1. Only extract entities the **user** mentioned, not the companion.
2. Use the name as the user spoke it — "my brother" and "David" are separate entities
   even if they may be the same person.
3. Keep `companion_note` factual and specific to what was said in this session.
   One sentence. No interpretation beyond what was stated. Include relevant emotional
   context (fear, dread, relief) in the `companion_note` of the entity it belongs to —
   do not create a separate entity for it.
4. **Person and situation are always separate entities.** When a named person and
   a named situation involving them are both present, you must extract both.
   The person entity and the situation entity are never redundant — they serve
   different purposes downstream.

   Correct output for "my brother and I had a tense money conversation":
   ```json
   [
     {"name": "my brother", "type": "person", "companion_note": "...", "status": "resolved"},
     {"name": "the money conversation", "type": "situation", "companion_note": "...", "status": "resolved"}
   ]
   ```
   Wrong: absorbing the situation into the person's `companion_note` and returning
   only one entity.

   **Intentions are also always separate entities.** Never absorb an intention into
   a person or situation's `companion_note`. If the user said "I'm going to text her
   this week," that is a separate intention entity — even if Sarah and the conversation
   are already in the output.
5. Do not extract unnamed emotional states. If the user said "I've been tired" and
   never named the source, return nothing for that thread.
6. **Bounded follow-up test for struggles** — before extracting a struggle, ask:
   could the morning agent ask "How is [this] going?" and receive a specific, bounded
   answer rooted in a concrete personal situation? "How is the guilt about your dad going?"
   — yes, extract it. "How is your faith going?" or "How is your question about
   the resurrection going?" — no, too abstract or theological, do not extract.
7. **Before creating any struggle entity, check your output so far.** If the
   emotional state you are about to extract is caused by a person or situation
   already in your output — stop. Add it to that entity's `companion_note` instead.
   Do not create a struggle entity whose root cause is an entity already extracted.

   Example: user says "I'm afraid she'll dismiss me again" after you've already
   extracted Sarah as a person entity. That fear belongs in Sarah's `companion_note`,
   not as a separate "fear of dismissal" struggle entity.

   Only create a standalone struggle entity when the inner state exists
   independently — not as a consequence of another entity in this output.
8. **Theological questions and doctrines are never struggles**, regardless of how
   personally they are framed. If the struggle is about belief, doctrine, or the
   nature of faith itself — not a concrete personal situation — do not extract it.
9. Return ONLY a valid JSON array. No prose, no markdown fences, no explanation.
   If nothing qualifies, return `[]`.

## Session transcript

{transcript}
