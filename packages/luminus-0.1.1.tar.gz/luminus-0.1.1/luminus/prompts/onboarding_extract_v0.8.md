# Onboarding Extraction Prompt — v0.8

Given an onboarding conversation transcript, extract the following fields as JSON.

## Output schema

```json
{
  "lens": "paul",
  "purpose": "one sentence describing why they came",
  "struggles": ["specific struggle 1", "specific struggle 2"],
  "tradition": "protestant"
}
```

## Field rules

### `lens`
One of `"paul"`, `"david"`, `"james"`, `"esther"`. Never null. Infer from what
the person gravitates toward — not just their topic but their relationship to it.

Distinguishing Paul vs Esther (the most common confusion):
- **Paul** — the struggle is *conceptual*. The person is wrestling with belief,
  doctrine, grace, or the inner life of faith. Their faith feels shaky at the
  level of ideas. They question what they believe.
- **Esther** — the struggle is *situated*. The person is navigating a concrete
  life decision, calling, or vocation where faith and real life don't connect.
  They know what they believe but can't feel it in their actual circumstances.
  Key signal: they mention a real-world decision (career, relationships, purpose)
  as the place where faith breaks down.

**Tiebreaker — Paul can involve a real-world decision too.** Ask: what came first?
- If the *faith framework* is what's falling apart and the real-world decision
  follows from that crisis → **Paul**.
  ("I'm not sure I believe what I'm preaching anymore... whether to leave ministry")
- If the *real-world situation* is what's falling apart and faith doesn't make
  sense of it → **Esther**.
  ("I left law because I felt called... but faith doesn't connect to my actual life now")

Distinguishing David vs others:
- **David** — raw emotion is the primary mode. Anger, grief, lament, unfiltered
  honesty before God. The person is not primarily questioning doctrine or seeking
  accountability — they are carrying something emotionally heavy and need permission
  to feel it before God.

Distinguishing James vs others:
- **James** — the gap between knowing and doing is the primary tension. They know
  what faith requires but consistently fail to live it. Habits, decisions, integrity,
  consistency. They want to be held accountable to action.

### `purpose`
One sentence in the **user's voice**.

Before writing this field: find the single best sentence the user said that
captures why they came. Copy it — or the core of it — directly. Do not paraphrase,
do not translate into your own language.

If no single sentence works, combine the fewest words possible from what they
actually said. The test: would the user recognize this as something they said?

**Bad (paraphrase):** "The user is wrestling with whether their faith is authentic."
**Good (near-quote):** "The framework I've built everything on feels shaky and I'm going through the motions."

### `struggles`
Array of specific struggles, situations, or people the user named.
Each item is a short phrase (3–8 words).

**What qualifies:**
- A named person ("conflict with business partner")
- A concrete situation ("leaving pastoral ministry") — include this even if it
  also appears in the purpose field. Decisions and situations are always their
  own struggle entries.
- A named decision ("leaving law to start a business")
- A named internal state they explicitly claimed ("anger at God", "ashamed of leading while hollow")

**Consolidation rule:** If two items describe the same situation from different
angles, keep only the most specific one. Do not list both cause and symptom.
Example: "avoiding conversation with partner" and "cutting corners on contract"
are the same situation — keep whichever is more specific to what the user named.

**What does NOT qualify — leave these out:**
- Abstract patterns the user used to summarize their own situation
  ("choosing comfort over conviction", "living a double life") — these are the
  user's own meta-language, not named struggles
- Feelings the user explicitly minimized or called manageable. If they said
  something was lighter than the main thing ("The guilt I can manage — the
  anger is heavier"), do not extract the minimized feeling as a struggle.
- Background context the user mentioned in passing — things that set the scene
  but were not framed as something they are wrestling with.
  Example: "Everyone in my life thinks it was a bad call" is context, not a struggle.
- Feelings or directions the user said they cannot name
  ("unnamed pull", "something I'm not ready to name") — if the user said they
  can't point at it, don't point at it for them
- Interpretive conclusions drawn from emotional tone — only extract what
  was explicitly named

**Pace rule — do not extract things the user was still approaching slowly:**

If Q5 was answered as "I'm not ready to name it yet" OR Q6 was answered as
"Honestly, but slowly," treat the conversation as one where the user set
a cautious pace.

In that context, if something surfaced with hedged language — "Maybe", "I think",
"I'm not sure", "I'm starting to wonder" — it is still being approached, not named.
Do NOT extract it as a struggle even though the user put words around it.

Example: User said Q6="Honestly, but slowly." Later said "Maybe. I think I'm afraid
that calling is something I invented to justify a decision I wanted to make anyway."
→ Do NOT extract the fear. The hedge + slow pace = still circling, not a named struggle.

If no concrete struggles were mentioned, return an empty array `[]`.

### `tradition`
Free text (e.g., "protestant", "catholic", "non-denominational", "Reformed").
**`null` if the user never explicitly mentioned a denomination or faith tradition.**
Do not infer or guess tradition from context. If they didn't say it, it's null.

## Rules

Return ONLY valid JSON. No markdown, no explanation, no prose.

## Transcript

{transcript}
