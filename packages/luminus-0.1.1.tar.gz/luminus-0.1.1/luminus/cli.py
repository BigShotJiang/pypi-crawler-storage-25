"""
luminus — CLI entry point.

Running `luminus` with no subcommand routes automatically:
  - No covenant         → onboarding
  - No session today    → morning
  - Morning done today  → menu: chat / report

Explicit subcommands still work for power users:
  luminus start    — onboarding
  luminus morning  — morning question + session
  luminus chat     — open session
  luminus report   — 7-day terminal report
"""

import click
import questionary
from rich.console import Console
from rich.text import Text

console = Console()

GOLD = "color(214)"
GOLD_HEX = "#d6b88a"


def _route() -> None:
    """Smart context-aware routing."""
    from datetime import datetime, timezone
    from luminus.storage import load_covenant, load_recent_sessions

    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    covenant = load_covenant()

    # No covenant → onboarding
    if not covenant:
        from luminus.commands.start import run
        run(console)
        return

    # Check today's sessions
    recent = load_recent_sessions(count=10)
    todays = [s for s in recent if s.date == today]
    had_morning = any(
        s.type.value == "morning" or s.type.value == "onboarding"
        for s in todays
    )

    # No session today → morning
    if not had_morning:
        from luminus.commands.morning import run
        run(console)
        return

    # Morning done → offer menu
    style = questionary.Style([
        ("question",    f"italic fg:{GOLD_HEX} bold"),
        ("answer",      f"fg:{GOLD_HEX}"),
        ("pointer",     f"fg:{GOLD_HEX} bold"),
        ("highlighted", f"fg:{GOLD_HEX} bold"),
        ("selected",    "fg:#888888"),
    ])

    console.print()
    choice = questionary.select(
        "What would you like to do?",
        choices=[
            questionary.Choice("Open a session with Luminus",        value="chat"),
            questionary.Choice("View your 7-day companion report",   value="report"),
        ],
        style=style,
    ).ask()

    if choice is None:
        return

    if choice == "chat":
        from luminus.commands.chat import run
        run(console)
    elif choice == "report":
        from luminus.commands.report import run
        run(console)


@click.group(invoke_without_command=True)
@click.pass_context
def cli(ctx: click.Context) -> None:
    """Luminus — your daily companion."""
    if ctx.invoked_subcommand is None:
        _route()


@cli.command()
def start() -> None:
    """Companion-led onboarding. Establishes your covenant."""
    from luminus.commands.start import run
    run(console)


@cli.command()
def morning() -> None:
    """Generate morning question and open morning session."""
    from luminus.commands.morning import run
    run(console)


@cli.command()
def chat() -> None:
    """Open a session with the companion."""
    from luminus.commands.chat import run
    run(console)


@cli.command()
def report() -> None:
    """View 7-day terminal report."""
    from luminus.commands.report import run
    run(console)
