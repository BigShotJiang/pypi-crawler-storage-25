"""
luminus start — companion-led onboarding.

Flow:
  1. Check for existing covenant (warn on overwrite).
  2. Run structured intake — 6 questions with pre-defined options (q1–q6).
  3. Inject intake answers as first user message to seed the conversation.
  4. Run streaming onboarding conversation (2–4 exchanges).
  5. Detect covenant proposal from companion (---COVENANT--- marker).
  6. User confirms or types their own covenant text.
  7. Extract structured fields (lens, purpose, struggles, tradition) via haiku.
  8. Save covenant.json + onboarding session.
"""

from __future__ import annotations

import os
import sys
from datetime import datetime, timezone

import time

import anthropic
import questionary
from rich.align import Align
from rich.console import Console, Group
from rich.live import Live
from rich.panel import Panel
from rich.text import Text

from luminus.agents.onboarding import (
    extract_covenant_from_text,
    extract_fields,
    load_system_prompt,
    run_turn,
)
from luminus.config import ONBOARDING_PROMPT_VERSION
from luminus.storage import (
    Covenant,
    FaithContext,
    InputMethod,
    Message,
    MessageRole,
    PromptVersions,
    Session,
    SessionType,
    load_covenant,
    save_covenant,
    save_session,
)

# ---------------------------------------------------------------------------
# Styling helpers
# ---------------------------------------------------------------------------

GOLD = "color(214)"
GOLD_HEX = "#d6b88a"

# Pixel art angel mascot — 2-char-per-pixel grid
ANGEL_LINES = [
    "          ░░░░░░░░          ",
    "        ░░▒▒▒▒▒▒▒░░        ",
    "       ░░▒▒▒▒▒▒▒▒▒░░       ",
    "        ░░░░░░░░░░░        ",
    "        ██████████         ",
    "       ██  ▄  ▄  ██        ",
    "       ██  █  █  ██        ",
    "       ██   ██   ██        ",
    "       ██        ██        ",
    "  ▄▄▄▄████████████▄▄▄▄    ",
    " ████████████████████████  ",
    "  ▀▀▀▀████████████▀▀▀▀    ",
    "       ██████████          ",
    "       ██      ██          ",
    "       ██████████          ",
]

TITLE = "L U M I N U S"
SUBTITLE = "Your Christian companion for what lies between Sundays."


def _animate_header(console: Console) -> None:
    def make_frame(n_art: int, n_title: int, show_sub: bool):
        items: list = [Text("")]
        for line in ANGEL_LINES[:n_art]:
            items.append(Align.center(Text(line, style=GOLD)))
        if n_title:
            items.append(Text(""))
            items.append(Align.center(Text(TITLE[:n_title], style=f"bold {GOLD}")))
        if show_sub:
            items.append(Align.center(Text(SUBTITLE, style="dim")))
        items.append(Text(""))
        return Group(*items)

    with Live(console=console, refresh_per_second=60, transient=False) as live:
        for i in range(1, len(ANGEL_LINES) + 1):
            live.update(make_frame(i, 0, False))
            time.sleep(0.045)
        for i in range(1, len(TITLE) + 1):
            live.update(make_frame(len(ANGEL_LINES), i, False))
            time.sleep(0.04)
        live.update(make_frame(len(ANGEL_LINES), len(TITLE), True))
        time.sleep(0.4)


def _print_companion(console: Console, text: str) -> None:
    console.print(f"\n[italic {GOLD}]{text}[/italic {GOLD}]")


def _print_companion_chunk(console: Console, chunk: str) -> None:
    console.print(chunk, end="", style=f"italic {GOLD}")


def _prompt_user(console: Console) -> str:
    console.print()
    return console.input("[dim]You:[/dim] ").strip()


# ---------------------------------------------------------------------------
# Structured intake questions (q1–q6 from design)
# ---------------------------------------------------------------------------

INTAKE_QUESTIONS: list[dict] = [
    {
        "question": "What are you carrying into this?",
        "options": [
            "A decision I keep avoiding",
            "A relationship that's heavy",
            "Something I stopped praying about",
            "A season I don't understand",
            "A habit I can't seem to break",
        ],
    },
    {
        "question": "Where are you right now, honestly?",
        "options": [
            "Growing and hungry for more",
            "Faithful but dry — going through the motions",
            "Doubting, but still showing up",
            "Coming back after a long time away",
            "I'm not sure — that's part of why I'm here",
        ],
    },
    {
        "question": "What are you hoping this becomes?",
        "options": [
            "Someone who holds me to what I say",
            "A thinking partner for the hard questions",
            "Help staying consistent when I drift",
            "The depth I'm not finding anywhere else",
            "I don't know yet — I'm still figuring that out",
        ],
    },
    {
        "question": "Have you had something like this before?",
        "options": [
            "Yes, and it helped",
            "Yes, but it didn't stick",
            "Sort of — but not like this",
            "No, this is new",
            "I'm not sure",
        ],
    },
    {
        "question": "Is there something you haven't said out loud yet?",
        "options": [
            "Something I'm ashamed of",
            "Something I'm angry about",
            "Something I'm afraid of",
            "Something I've been avoiding",
            "Something I'm not sure how to name",
            "I'm not ready to name it yet",
        ],
    },
    {
        "question": "How honest can I be with you?",
        "options": [
            "Completely. Hold nothing back.",
            "Gently. I'm fragile right now.",
            "Honestly, but slowly.",
            "I'm not sure yet.",
        ],
    },
]


def run_structured_intake(console: Console) -> list[tuple[str, str]]:
    """
    Present q1–q6 as arrow-key selections via questionary.
    Returns list of (question, chosen_answer) tuples.
    """
    answers: list[tuple[str, str]] = []

    console.print()
    console.print(
        Panel(
            "[dim]Six questions. Choose the one that feels most true right now.[/dim]",
            title="[bold]Before we begin[/bold]",
            border_style="dim",
        )
    )

    style = questionary.Style([
        ("question",     f"italic fg:{GOLD_HEX} bold"),
        ("answer",       f"fg:{GOLD_HEX}"),
        ("pointer",      f"fg:{GOLD_HEX} bold"),
        ("highlighted",  f"fg:{GOLD_HEX} bold"),
        ("selected",     "fg:#888888"),
    ])

    for q in INTAKE_QUESTIONS:
        console.print()
        chosen = questionary.select(
            q["question"],
            choices=q["options"],
            style=style,
            use_shortcuts=False,
        ).ask()

        if chosen is None:
            console.print("[dim]Aborted.[/dim]")
            sys.exit(0)

        answers.append((q["question"], chosen))

    return answers


def _format_intake_as_message(answers: list[tuple[str, str]]) -> str:
    """Format intake answers as the first user message to seed the conversation."""
    lines = ["Before we begin, here's what I shared in the intake:\n"]
    for question, answer in answers:
        lines.append(f"— {question}\n  → {answer}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Conversation helpers
# ---------------------------------------------------------------------------


def _build_transcript(messages: list[dict]) -> str:
    lines = []
    for m in messages:
        role = "Luminus" if m["role"] == "assistant" else "You"
        lines.append(f"{role}: {m['content']}")
    return "\n\n".join(lines)


def _strip_covenant_markers(text: str) -> str:
    if "---COVENANT---" not in text:
        return text
    before = text.split("---COVENANT---", 1)[0].rstrip()
    after_block = text.split("---END---", 1)
    after = after_block[1].strip() if len(after_block) > 1 else ""
    parts = [p for p in [before, after] if p]
    return "\n\n".join(parts)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


def run(console: Console) -> None:
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        console.print("[red]ANTHROPIC_API_KEY is not set.[/red]")
        sys.exit(1)

    # Guard: existing covenant
    existing = load_covenant()
    if existing:
        console.print(
            Panel(
                "[yellow]A covenant already exists.[/yellow]\n\n"
                f"[dim]{existing.text}[/dim]\n\n"
                "Running [bold]luminus start[/bold] again will replace it.",
                title="Covenant exists",
                border_style="yellow",
            )
        )
        confirm = console.input("Replace it? [y/N] ").strip().lower()
        if confirm != "y":
            console.print("[dim]Aborted.[/dim]")
            return

    _animate_header(console)

    client = anthropic.Anthropic(api_key=api_key)
    system = load_system_prompt()
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    session_id = f"{today}-onboarding"

    # ---------------------------------------------------------------------------
    # Structured intake — q1–q6
    # ---------------------------------------------------------------------------

    intake_answers = run_structured_intake(console)

    console.print()
    console.print("[dim]One moment...[/dim]", end="\r")

    # Seed messages with intake answers as first user turn
    intake_message = _format_intake_as_message(intake_answers)
    messages: list[dict] = [{"role": "user", "content": intake_message}]
    session_messages: list[Message] = [
        Message(
            role=MessageRole.user,
            content=intake_message,
            timestamp=datetime.now(timezone.utc),
        )
    ]

    proposed_covenant: str | None = None

    # ---------------------------------------------------------------------------
    # Conversation loop
    # ---------------------------------------------------------------------------

    while True:
        # --- Companion turn ---
        full_text = ""

        def on_chunk(chunk: str) -> None:
            nonlocal full_text
            full_text += chunk
            _print_companion_chunk(console, chunk)

        console.print(f"\r[dim]              [/dim]", end="\r")
        console.print()
        full_text = run_turn(client, messages, system, on_chunk)
        console.print()

        proposed = extract_covenant_from_text(full_text)

        messages.append({"role": "assistant", "content": full_text})
        session_messages.append(
            Message(
                role=MessageRole.assistant,
                content=full_text,
                timestamp=datetime.now(timezone.utc),
            )
        )

        if proposed:
            proposed_covenant = proposed
            console.print()
            console.print(
                Panel(
                    f"[italic {GOLD}]{proposed_covenant}[/italic {GOLD}]",
                    title="Covenant",
                    border_style=GOLD,
                    padding=(1, 2),
                )
            )
            break

        # --- User turn ---
        user_input = _prompt_user(console)
        if not user_input:
            continue

        messages.append({"role": "user", "content": user_input})
        session_messages.append(
            Message(
                role=MessageRole.user,
                content=user_input,
                timestamp=datetime.now(timezone.utc),
            )
        )

    # ---------------------------------------------------------------------------
    # Confirmation step
    # ---------------------------------------------------------------------------

    console.print()
    console.print("[dim]Type [bold]yes[/bold] to accept, or enter your own words:[/dim]")
    confirmation = console.input("[dim]→ [/dim]").strip()

    if confirmation.lower() in ("yes", "y", ""):
        final_covenant_text = proposed_covenant
    else:
        final_covenant_text = confirmation

    # ---------------------------------------------------------------------------
    # Extract structured fields
    # ---------------------------------------------------------------------------

    console.print()
    console.print("[dim]Saving...[/dim]", end="")

    transcript = _build_transcript(messages)
    fields = extract_fields(client, transcript)

    lens = fields.get("lens", "paul")
    purpose = fields.get("purpose", "")
    struggles = fields.get("struggles", [])
    tradition = fields.get("tradition")

    # ---------------------------------------------------------------------------
    # Save covenant + session
    # ---------------------------------------------------------------------------

    covenant = Covenant(
        text=final_covenant_text,
        timestamp=datetime.now(timezone.utc),
        input_method=InputMethod.text,
        lens=lens,
        faith_context=FaithContext(
            tradition=tradition,
            struggles=struggles,
            purpose=purpose,
        ),
        prompt_version=ONBOARDING_PROMPT_VERSION,
    )
    save_covenant(covenant)

    session = Session(
        id=session_id,
        type=SessionType.onboarding,
        date=today,
        started_at=session_messages[0].timestamp,
        ended_at=datetime.now(timezone.utc),
        messages=session_messages,
        prompt_versions=PromptVersions(session=ONBOARDING_PROMPT_VERSION),
    )
    save_session(session)

    console.print(f"\r[dim]Saved.    [/dim]")
    console.print()
    console.print(
        Panel(
            f"[italic {GOLD}]{final_covenant_text}[/italic {GOLD}]\n\n"
            f"[dim]Lens: {lens}[/dim]",
            title="[bold]Covenant made[/bold]",
            border_style=GOLD,
            padding=(1, 2),
        )
    )
    console.print()
    console.print("[dim]Run [bold]luminus morning[/bold] to begin tomorrow.[/dim]")
    console.print()
