"""
luminus report — 7-day terminal report.

Displays a rich terminal UI with:
  - Covenant summary + thread count
  - 7-day consistency calendar
  - Session counts + rating averages
  - Per-session table (date, type, ratings, summary)
  - Entity tracker (active entities, mentions, last seen)
  - Best + worst morning questions
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from rich.columns import Columns
from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from luminus.storage import (
    load_all_sessions,
    load_covenant,
    load_entity_store,
)
from luminus.storage.models import EntityStatus, Session, SessionType

GOLD = "color(214)"
REPORT_DAYS = 7

DAY_ABBR = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _avg(values: list) -> str:
    nums = [v for v in values if v is not None]
    if not nums:
        return "—"
    return f"{sum(nums) / len(nums):.1f}"


def _rating_bar(value: int | None, max_val: int = 5) -> Text:
    if value is None:
        return Text("—", style="dim")
    t = Text()
    t.append("█" * value, style=GOLD)
    t.append("░" * (max_val - value), style="dim")
    t.append(f"  {value}/5", style="dim")
    return t


def _days_ago(date_str: str, today: str) -> str:
    delta = (
        datetime.strptime(today, "%Y-%m-%d") - datetime.strptime(date_str, "%Y-%m-%d")
    ).days
    if delta == 0:
        return "today"
    if delta == 1:
        return "yesterday"
    return f"{delta}d ago"


def _sessions_in_window(sessions: list[Session], days: int, today: str) -> list[Session]:
    cutoff = (
        datetime.strptime(today, "%Y-%m-%d") - timedelta(days=days)
    ).strftime("%Y-%m-%d")
    return [s for s in sessions if s.date >= cutoff]


def _day_range(today: str, days: int) -> list[str]:
    start = datetime.strptime(today, "%Y-%m-%d") - timedelta(days=days - 1)
    return [(start + timedelta(days=i)).strftime("%Y-%m-%d") for i in range(days)]


def _covenant_keywords(covenant_text: str) -> list[str]:
    """Extract meaningful words from covenant for thread detection."""
    stopwords = {
        "i", "to", "the", "a", "and", "of", "my", "in", "is", "with",
        "or", "on", "at", "for", "when", "what", "that", "this", "it",
        "be", "am", "are", "was", "will", "do", "not", "but", "so",
        "instead", "commit", "focusing",
    }
    words = covenant_text.lower().replace(",", "").replace(".", "").replace("—", " ").split()
    return [w for w in words if len(w) > 3 and w not in stopwords]


def _session_touches_covenant(session: Session, keywords: list[str]) -> bool:
    """True if this session's summary or messages reference any covenant keyword."""
    haystack = ""
    if session.session_summary:
        haystack += session.session_summary.lower()
    for m in session.messages:
        haystack += m.content.lower()
    return any(kw in haystack for kw in keywords)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def run(console: Console) -> None:
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    covenant = load_covenant()
    all_sessions = load_all_sessions()
    entity_store = load_entity_store()

    window = _sessions_in_window(all_sessions, REPORT_DAYS, today)
    window_sorted = sorted(window, key=lambda s: s.date, reverse=True)
    days = _day_range(today, REPORT_DAYS)
    dates_with_sessions = {s.date for s in window}

    if not window:
        console.print(
            "[yellow]No sessions in the last 7 days. "
            "Run [bold]luminus morning[/bold] or [bold]luminus chat[/bold] first.[/yellow]"
        )
        return

    morning_sessions = [s for s in window if s.type == SessionType.morning]
    chat_sessions = [s for s in window if s.type == SessionType.chat]

    all_mq = [s.ratings.morning_question_quality for s in window if s.ratings.morning_question_quality]
    all_honesty = [s.ratings.companion_honesty for s in window if s.ratings.companion_honesty]

    active_entities = sorted(
        [e for e in entity_store.entities.values() if e.status == EntityStatus.active],
        key=lambda e: e.last_mentioned,
        reverse=True,
    )

    rated_morning = [
        s for s in morning_sessions
        if s.morning_question and s.ratings.morning_question_quality
    ]
    best = max(rated_morning, key=lambda s: s.ratings.morning_question_quality, default=None)
    worst = min(rated_morning, key=lambda s: s.ratings.morning_question_quality, default=None)
    if best and worst and best.id == worst.id:
        worst = None  # only one rated question — don't show same twice

    # Covenant thread
    covenant_keywords = _covenant_keywords(covenant.text) if covenant else []
    covenant_sessions = [
        s for s in window
        if s.type != SessionType.onboarding and _session_touches_covenant(s, covenant_keywords)
    ]
    non_onboarding = [s for s in window if s.type != SessionType.onboarding]

    # -------------------------------------------------------------------------
    # Header
    # -------------------------------------------------------------------------

    console.print()
    console.print(Rule(f"[bold {GOLD}]Luminus — 7-Day Report[/bold {GOLD}]", style=GOLD))
    console.print()

    # -------------------------------------------------------------------------
    # Covenant + thread count
    # -------------------------------------------------------------------------

    if covenant:
        thread_line = ""
        if non_onboarding:
            pct = int(100 * len(covenant_sessions) / len(non_onboarding))
            thread_line = f"\n\nCame up in {len(covenant_sessions)} / {len(non_onboarding)} sessions ({pct}%)"

        console.print(
            Panel(
                Text.assemble(
                    Text(covenant.text, style=f"italic {GOLD}"),
                    Text(thread_line, style="dim"),
                    "\n",
                    Text(f"Lens: {covenant.lens}", style="dim"),
                ),
                title="[bold]Covenant[/bold]",
                border_style=GOLD,
                padding=(1, 2),
            )
        )
        console.print()

    # -------------------------------------------------------------------------
    # 7-day consistency calendar
    # -------------------------------------------------------------------------

    calendar = Text()
    for i, day in enumerate(days):
        abbr = DAY_ABBR[datetime.strptime(day, "%Y-%m-%d").weekday()]
        has_session = day in dates_with_sessions
        is_today = day == today

        if i > 0:
            calendar.append("  ")

        if is_today:
            calendar.append(abbr, style=f"bold {GOLD}" if has_session else "bold dim")
        else:
            calendar.append(abbr, style=GOLD if has_session else "dim")

        calendar.append("\n")
        if has_session:
            calendar.append("  ●  " if is_today else " ●  ", style=GOLD)
        else:
            calendar.append("  ○  " if is_today else " ○  ", style="dim")

        if i > 0:
            # undo the leading spaces from the append above — handled by column spacing
            pass

    # Rebuild as a single horizontal row
    header_row = Text()
    dot_row = Text()
    for i, day in enumerate(days):
        abbr = DAY_ABBR[datetime.strptime(day, "%Y-%m-%d").weekday()]
        has_session = day in dates_with_sessions
        is_today = day == today
        sep = "   " if i > 0 else ""

        if is_today:
            header_row.append(sep + abbr, style=f"bold {GOLD}" if has_session else "bold")
            dot_row.append(sep + " ● " if has_session else sep + " ○ ",
                           style=f"bold {GOLD}" if has_session else "bold dim")
        else:
            header_row.append(sep + abbr, style=GOLD if has_session else "dim")
            dot_row.append(sep + " ● " if has_session else sep + " ○ ",
                           style=GOLD if has_session else "dim")

    days_active = len(dates_with_sessions)
    console.print(
        Panel(
            Text.assemble(header_row, "\n", dot_row),
            title=f"[dim]Consistency — {days_active} / 7 days[/dim]",
            border_style="dim",
            padding=(1, 3),
        )
    )
    console.print()

    # -------------------------------------------------------------------------
    # Summary stat boxes
    # -------------------------------------------------------------------------

    def stat_panel(label: str, value: str) -> Panel:
        return Panel(
            Text.assemble(
                Text(f"{value}\n", style=f"bold {GOLD}"),
                Text(label, style="dim"),
            ),
            border_style="dim",
            padding=(0, 2),
            expand=True,
        )

    console.print(Columns([
        stat_panel("sessions", str(len(window))),
        stat_panel("morning Q avg", f"{_avg(all_mq)} / 5"),
        stat_panel("honesty avg", f"{_avg(all_honesty)} / 5"),
        stat_panel("entities", str(len(active_entities))),
    ], equal=True, expand=True))
    console.print()

    # -------------------------------------------------------------------------
    # Sessions table
    # -------------------------------------------------------------------------

    console.print(Rule("[dim]Sessions[/dim]", style="dim"))
    console.print()

    session_table = Table(
        show_header=True,
        header_style=f"bold {GOLD}",
        box=None,
        pad_edge=False,
        show_edge=False,
        padding=(0, 2),
    )
    session_table.add_column("Date", style="dim", min_width=12)
    session_table.add_column("Type", min_width=12)
    session_table.add_column("Honesty", min_width=16)
    session_table.add_column("Morning Q", min_width=16)
    session_table.add_column("Summary", no_wrap=False, max_width=50)

    type_labels = {
        SessionType.morning: "morning",
        SessionType.chat: "chat",
        SessionType.onboarding: "onboarding",
    }

    for s in window_sorted:
        summary = s.session_summary or ""
        summary_display = (summary[:72] + "…") if len(summary) > 72 else summary

        session_table.add_row(
            s.date,
            type_labels.get(s.type, s.type.value),
            _rating_bar(s.ratings.companion_honesty),
            _rating_bar(s.ratings.morning_question_quality),
            Text(summary_display, style="dim"),
        )

    console.print(session_table)
    console.print()

    # -------------------------------------------------------------------------
    # Entities table
    # -------------------------------------------------------------------------

    if active_entities:
        console.print(Rule("[dim]Entities[/dim]", style="dim"))
        console.print()

        entity_table = Table(
            show_header=True,
            header_style=f"bold {GOLD}",
            box=None,
            pad_edge=False,
            show_edge=False,
            padding=(0, 2),
        )
        entity_table.add_column("Name", min_width=26)
        entity_table.add_column("Type", style="dim", min_width=12)
        entity_table.add_column("Mentions", min_width=10)
        entity_table.add_column("Last seen", min_width=12)

        for e in active_entities:
            entity_table.add_row(
                Text(e.name, style=GOLD),
                e.type.value,
                str(e.session_count),
                _days_ago(e.last_mentioned, today),
            )

        console.print(entity_table)
        console.print()

    # -------------------------------------------------------------------------
    # Best + worst morning questions
    # -------------------------------------------------------------------------

    if best or worst:
        console.print(Rule("[dim]Morning questions[/dim]", style="dim"))
        console.print()

    if best:
        console.print(
            Panel(
                Text(best.morning_question, style=f"italic {GOLD}"),
                title=Text(
                    f"Best  ·  {best.date}  ·  rated {best.ratings.morning_question_quality}/5",
                    style="dim",
                ),
                border_style=GOLD,
                padding=(1, 2),
            )
        )
        console.print()

    if worst:
        console.print(
            Panel(
                Text(worst.morning_question, style="italic dim"),
                title=Text(
                    f"Worst  ·  {worst.date}  ·  rated {worst.ratings.morning_question_quality}/5",
                    style="dim",
                ),
                border_style="dim",
                padding=(1, 2),
            )
        )
        console.print()

    console.print(Rule(style="dim"))
    console.print()
