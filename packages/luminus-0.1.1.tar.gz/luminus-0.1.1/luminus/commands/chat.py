"""
luminus chat — main companion session with inline extraction.

Flow:
  1. Load covenant, recent sessions, pending entities.
  2. Build session system prompt.
  3. Companion opens with a reference to last session / pending entity.
  4. Conversation loop until user types /end.
  5. Extract entities + generate summary (haiku).
  6. Prompt for companion honesty rating (1–5).
  7. Save session JSON.
"""

from __future__ import annotations

import os
import sys
from datetime import datetime, timezone

import anthropic
from rich.console import Console
from rich.panel import Panel

from luminus.agents.session import (
    build_session_system_prompt,
    build_transcript,
    extract_entities,
    generate_summary,
    run_session_turn,
)
from luminus.config import EXTRACTION_PROMPT_VERSION, SESSION_PROMPT_VERSION
from luminus.storage import (
    Message,
    MessageRole,
    PromptVersions,
    Ratings,
    Session,
    SessionType,
    load_covenant,
    load_recent_sessions,
    morning_eligible_entities,
    save_session,
    upsert_entities,
)
from luminus.storage.local import session_path

GOLD = "color(214)"


def _print_chunk(console: Console, chunk: str) -> None:
    console.print(chunk, end="", style=f"italic {GOLD}")


def _get_rating(console: Console, label: str) -> int:
    while True:
        raw = console.input(f"[dim]{label} (1–5): [/dim]").strip()
        if raw.isdigit() and 1 <= int(raw) <= 5:
            return int(raw)
        console.print("[dim]Please enter a number from 1 to 5.[/dim]")


def _make_session_id(today: str) -> str:
    base = f"{today}-chat"
    if not session_path(base).exists():
        return base
    now = datetime.now(timezone.utc)
    return f"{base}-{now.strftime('%H%M%S')}"


def run(console: Console) -> None:
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        console.print("[red]ANTHROPIC_API_KEY is not set.[/red]")
        sys.exit(1)

    covenant = load_covenant()
    if not covenant:
        console.print(
            "[yellow]No covenant found. Run [bold]luminus start[/bold] first.[/yellow]"
        )
        return

    client = anthropic.Anthropic(api_key=api_key)
    today = datetime.now().strftime("%Y-%m-%d")
    session_id = _make_session_id(today)

    recent_sessions = load_recent_sessions(count=3)
    entities = morning_eligible_entities(today)

    system = build_session_system_prompt(covenant, recent_sessions, entities)

    console.print()
    console.print(
        Panel(
            "[dim]Type your thoughts. Type [bold]/end[/bold] when done.[/dim]",
            title="[bold]luminus chat[/bold]",
            border_style="dim",
        )
    )
    console.print()

    messages: list[dict] = [{"role": "user", "content": "Begin."}]
    session_messages: list[Message] = []
    started_at = datetime.now(timezone.utc)

    while True:
        # --- Companion turn ---
        full_text = ""

        def on_chunk(chunk: str) -> None:
            nonlocal full_text
            full_text += chunk
            _print_chunk(console, chunk)

        console.print()
        full_text = run_session_turn(client, messages, system, on_chunk)
        console.print()

        messages.append({"role": "assistant", "content": full_text})
        session_messages.append(
            Message(
                role=MessageRole.assistant,
                content=full_text,
                timestamp=datetime.now(timezone.utc),
            )
        )

        # --- User turn ---
        console.print()
        user_input = console.input("[dim]You (or /end to close): [/dim]").strip()

        if user_input.lower() in ("/end", "/quit", "exit", "quit"):
            break

        if not user_input:
            continue

        messages.append({"role": "user", "content": user_input})
        session_messages.append(
            Message(
                role=MessageRole.user,
                content=user_input,
                timestamp=datetime.now(timezone.utc),
            )
        )

    # ---------------------------------------------------------------------------
    # Post-session: extract + summarise + rate + save
    # ---------------------------------------------------------------------------

    console.print()
    console.print("[dim]Closing session...[/dim]", end="\r")

    # Only extract if there was real conversation (at least one user message)
    has_user_messages = any(m["role"] == "user" for m in messages)

    extracted = []
    summary = None

    if has_user_messages:
        transcript = build_transcript(messages)
        extracted = extract_entities(client, transcript, session_id, today)
        summary = generate_summary(client, transcript)
        upsert_entities(extracted)

    console.print("[dim]                 [/dim]", end="\r")  # clear the "Closing…" line
    console.print()

    rating_honesty = _get_rating(console, "Companion honesty")

    session = Session(
        id=session_id,
        type=SessionType.chat,
        date=today,
        started_at=started_at,
        ended_at=datetime.now(timezone.utc),
        messages=session_messages,
        prompt_versions=PromptVersions(
            session=SESSION_PROMPT_VERSION,
            extraction=EXTRACTION_PROMPT_VERSION,
        ),
        entities_extracted=[e.id for e in extracted],
        ratings=Ratings(companion_honesty=rating_honesty),
        session_summary=summary,
    )
    save_session(session)

    console.print()
    if extracted:
        names = ", ".join(e.name for e in extracted)
        console.print(f"[dim]Noted: {names}[/dim]")
    console.print(
        "[dim]Session saved. Run [bold]luminus morning[/bold] tomorrow.[/dim]"
    )
    console.print()
