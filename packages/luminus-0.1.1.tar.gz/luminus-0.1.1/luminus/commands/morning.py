"""
luminus morning — generate morning question and open morning session.

Flow:
  1. Load covenant, most recent session (yesterday's), pending entities.
  2. Generate one morning question via morning agent.
  3. Display the question in a panel.
  4. Open a morning session: first assistant message = morning question.
  5. Conversation loop until user types /end.
  6. Extract entities + generate summary (haiku).
  7. Prompt for morning question quality (1–5) and companion honesty (1–5).
  8. Save session JSON.
"""

from __future__ import annotations

import os
import sys
from datetime import datetime, timezone

import anthropic
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from luminus.agents.morning_question import generate_morning_question
from luminus.agents.session import (
    build_session_system_prompt,
    build_transcript,
    extract_entities,
    generate_summary,
    run_session_turn,
)
from luminus.config import (
    EXTRACTION_PROMPT_VERSION,
    MORNING_PROMPT_VERSION,
    SESSION_PROMPT_VERSION,
)
from luminus.storage import (
    Message,
    MessageRole,
    PromptVersions,
    Ratings,
    Session,
    SessionType,
    load_covenant,
    load_recent_sessions,
    morning_eligible_entities,
    save_session,
    upsert_entities,
)
from luminus.storage.local import session_path

GOLD = "color(214)"


def _print_chunk(console: Console, chunk: str) -> None:
    console.print(chunk, end="", style=f"italic {GOLD}")


def _get_rating(console: Console, label: str) -> int:
    while True:
        raw = console.input(f"[dim]{label} (1–5): [/dim]").strip()
        if raw.isdigit() and 1 <= int(raw) <= 5:
            return int(raw)
        console.print("[dim]Please enter a number from 1 to 5.[/dim]")


def _make_session_id(today: str) -> str:
    base = f"{today}-morning"
    if not session_path(base).exists():
        return base
    now = datetime.now(timezone.utc)
    return f"{base}-{now.strftime('%H%M%S')}"


def run(console: Console) -> None:
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        console.print("[red]ANTHROPIC_API_KEY is not set.[/red]")
        sys.exit(1)

    covenant = load_covenant()
    if not covenant:
        console.print(
            "[yellow]No covenant found. Run [bold]luminus start[/bold] first.[/yellow]"
        )
        return

    client = anthropic.Anthropic(api_key=api_key)
    today = datetime.now().strftime("%Y-%m-%d")
    session_id = _make_session_id(today)

    # Load context
    recent_sessions = load_recent_sessions(count=3)
    last_session = recent_sessions[0] if recent_sessions else None
    entities = morning_eligible_entities(today)

    # Generate morning question
    console.print()
    console.print("[dim]Preparing your morning...[/dim]", end="\r")
    morning_q = generate_morning_question(client, covenant, last_session, entities, today)
    console.print("[dim]                         [/dim]", end="\r")

    # Display it
    console.print()
    console.print(
        Panel(
            Text(morning_q, style=f"italic {GOLD}"),
            title="[bold]Morning[/bold]",
            border_style=GOLD,
            padding=(1, 2),
        )
    )
    console.print()
    console.print("[dim]Type your thoughts. Type [bold]/end[/bold] when done.[/dim]")
    console.print()

    # Build system prompt (same session agent, no special morning variant needed)
    system = build_session_system_prompt(covenant, recent_sessions, entities)

    # Seed messages with the morning question as the first assistant message
    # so the conversation context is correct from turn one.
    messages: list[dict] = [{"role": "assistant", "content": morning_q}]
    session_messages: list[Message] = [
        Message(
            role=MessageRole.assistant,
            content=morning_q,
            timestamp=datetime.now(timezone.utc),
        )
    ]
    started_at = datetime.now(timezone.utc)

    while True:
        # --- User turn first (morning question already shown) ---
        user_input = console.input("[dim]You (or /end to close): [/dim]").strip()

        if user_input.lower() in ("/end", "/quit", "exit", "quit"):
            break

        if not user_input:
            continue

        messages.append({"role": "user", "content": user_input})
        session_messages.append(
            Message(
                role=MessageRole.user,
                content=user_input,
                timestamp=datetime.now(timezone.utc),
            )
        )

        # --- Companion turn ---
        full_text = ""

        def on_chunk(chunk: str) -> None:
            nonlocal full_text
            full_text += chunk
            _print_chunk(console, chunk)

        console.print()
        full_text = run_session_turn(client, messages, system, on_chunk)
        console.print()
        console.print()

        messages.append({"role": "assistant", "content": full_text})
        session_messages.append(
            Message(
                role=MessageRole.assistant,
                content=full_text,
                timestamp=datetime.now(timezone.utc),
            )
        )

    # ---------------------------------------------------------------------------
    # Post-session: extract + summarise + rate + save
    # ---------------------------------------------------------------------------

    console.print()
    console.print("[dim]Closing session...[/dim]", end="\r")

    has_user_messages = any(m["role"] == "user" for m in messages)

    extracted = []
    summary = None

    if has_user_messages:
        transcript = build_transcript(messages)
        extracted = extract_entities(client, transcript, session_id, today)
        summary = generate_summary(client, transcript)
        upsert_entities(extracted)

    # Determine which entities informed the morning question
    source_entity_ids = [e.id for e in entities if e.name.lower() in morning_q.lower()]

    console.print("[dim]                 [/dim]", end="\r")
    console.print()

    rating_morning = _get_rating(console, "Morning question quality")
    rating_honesty = _get_rating(console, "Companion honesty")

    session = Session(
        id=session_id,
        type=SessionType.morning,
        date=today,
        started_at=started_at,
        ended_at=datetime.now(timezone.utc),
        messages=session_messages,
        morning_question=morning_q,
        morning_question_source_entities=source_entity_ids,
        prompt_versions=PromptVersions(
            session=SESSION_PROMPT_VERSION,
            extraction=EXTRACTION_PROMPT_VERSION,
            morning=MORNING_PROMPT_VERSION,
        ),
        entities_extracted=[e.id for e in extracted],
        ratings=Ratings(
            morning_question_quality=rating_morning,
            companion_honesty=rating_honesty,
        ),
        session_summary=summary,
    )
    save_session(session)

    console.print()
    if extracted:
        names = ", ".join(e.name for e in extracted)
        console.print(f"[dim]Noted: {names}[/dim]")
    console.print("[dim]Session saved. Run [bold]luminus chat[/bold] anytime today.[/dim]")
    console.print()
