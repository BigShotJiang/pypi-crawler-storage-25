"""
Local storage read/write operations.

All I/O goes through these functions. Keeping I/O isolated here means
the rest of the codebase works with Pydantic models only, and TODO-11
(Firestore export) replaces just this module.
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Optional

from luminus.config import (
    COVENANT_FILE,
    ENTITIES_FILE,
    SESSIONS_DIR,
    ensure_dirs,
)
from luminus.storage.models import (
    Covenant,
    Entity,
    EntityStore,
    Session,
    SessionType,
)


# ---------------------------------------------------------------------------
# Covenant
# ---------------------------------------------------------------------------


def save_covenant(covenant: Covenant) -> None:
    ensure_dirs()
    COVENANT_FILE.write_text(
        covenant.model_dump_json(indent=2), encoding="utf-8"
    )


def load_covenant() -> Optional[Covenant]:
    if not COVENANT_FILE.exists():
        return None
    return Covenant.model_validate_json(COVENANT_FILE.read_text("utf-8"))


# ---------------------------------------------------------------------------
# Entities
# ---------------------------------------------------------------------------


def load_entity_store() -> EntityStore:
    if not ENTITIES_FILE.exists():
        return EntityStore()
    return EntityStore.model_validate_json(ENTITIES_FILE.read_text("utf-8"))


def save_entity_store(store: EntityStore) -> None:
    ensure_dirs()
    store.updated_at = datetime.utcnow()
    ENTITIES_FILE.write_text(store.model_dump_json(indent=2), encoding="utf-8")


def upsert_entities(new_entities: list[Entity]) -> None:
    """Merge extracted entities into the store. Updates existing by name match."""
    store = load_entity_store()
    for entity in new_entities:
        existing = _find_by_name(store, entity.name)
        if existing:
            _merge_entity(existing, entity)
        else:
            store.entities[entity.id] = entity
    save_entity_store(store)


def _find_by_name(store: EntityStore, name: str) -> Optional[Entity]:
    for e in store.entities.values():
        if e.name.lower() == name.lower():
            return e
    return None


def _merge_entity(existing: Entity, update: Entity) -> None:
    """Update an existing entity with data from a new extraction."""
    existing.last_mentioned = update.last_mentioned
    existing.session_count += 1
    for sid in update.session_ids:
        if sid not in existing.session_ids:
            existing.session_ids.append(sid)
    if update.companion_note:
        existing.companion_note = update.companion_note
    existing.updated_at = datetime.utcnow()


def morning_eligible_entities(today: str) -> list[Entity]:
    store = load_entity_store()
    return [e for e in store.entities.values() if e.is_morning_eligible(today)]


# ---------------------------------------------------------------------------
# Sessions
# ---------------------------------------------------------------------------


def session_path(session_id: str) -> Path:
    return SESSIONS_DIR / f"{session_id}.json"


def save_session(session: Session) -> None:
    ensure_dirs()
    session_path(session.id).write_text(
        session.model_dump_json(indent=2), encoding="utf-8"
    )


def load_session(session_id: str) -> Optional[Session]:
    path = session_path(session_id)
    if not path.exists():
        return None
    return Session.model_validate_json(path.read_text("utf-8"))


def load_recent_sessions(count: int = 3) -> list[Session]:
    """Return the most recent sessions sorted newest-first."""
    paths = sorted(SESSIONS_DIR.glob("*.json"), reverse=True)
    sessions = []
    for p in paths[:count * 2]:  # over-fetch to account for any corrupt files
        try:
            sessions.append(Session.model_validate_json(p.read_text("utf-8")))
        except Exception:
            continue
        if len(sessions) >= count:
            break
    return sessions


def load_all_sessions() -> list[Session]:
    paths = sorted(SESSIONS_DIR.glob("*.json"))
    sessions = []
    for p in paths:
        try:
            sessions.append(Session.model_validate_json(p.read_text("utf-8")))
        except Exception:
            continue
    return sessions


