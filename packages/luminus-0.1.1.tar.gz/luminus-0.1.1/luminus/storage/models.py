"""
Luminus storage models — Pydantic V2.

These are the canonical schema definitions. Every field here maps 1:1 to
the Firestore schema documented in SCHEMA.md. Do not add fields without
updating SCHEMA.md.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Optional
from uuid import uuid4

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class SessionType(str, Enum):
    onboarding = "onboarding"
    morning = "morning"
    chat = "chat"


class EntityType(str, Enum):
    person = "person"
    situation = "situation"
    intention = "intention"
    struggle = "struggle"


class EntityStatus(str, Enum):
    active = "active"
    resolved = "resolved"
    dismissed = "dismissed"


class MessageRole(str, Enum):
    assistant = "assistant"
    user = "user"


class InputMethod(str, Enum):
    text = "text"
    voice = "voice"


# ---------------------------------------------------------------------------
# covenant.json → Firestore: users/{uid}/covenant/current
# ---------------------------------------------------------------------------


class FaithContext(BaseModel):
    tradition: Optional[str] = None
    struggles: list[str] = Field(default_factory=list)
    purpose: Optional[str] = None


class Covenant(BaseModel):
    text: str
    timestamp: datetime
    input_method: InputMethod = InputMethod.text
    lens: str  # extensible — no hardcoded enum (TODO-02)
    version: str = "v1"
    faith_context: FaithContext = Field(default_factory=FaithContext)
    prompt_version: str = "v1.0"


# ---------------------------------------------------------------------------
# entities.json → Firestore: users/{uid}/entities/{entityId}
# ---------------------------------------------------------------------------


def _entity_id(name: str) -> str:
    """Stable slug + 6-char hex for readability in logs."""
    slug = name.lower().replace(" ", "-")[:20]
    short_uuid = uuid4().hex[:6]
    return f"{slug}-{short_uuid}"


class Entity(BaseModel):
    id: str = Field(default_factory=lambda: _entity_id("entity"))
    name: str
    type: EntityType
    status: EntityStatus = EntityStatus.active
    first_session: str  # YYYY-MM-DD
    last_mentioned: str  # YYYY-MM-DD
    session_count: int = 1
    session_ids: list[str] = Field(default_factory=list)
    companion_note: Optional[str] = None
    resolution_session: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    def is_morning_eligible(self, today: str) -> bool:
        """
        Returns True if this entity should be considered for morning question
        generation.

        Eligibility:
        - status == active
        - last_mentioned within past 7 days
        """
        if self.status != EntityStatus.active:
            return False
        from datetime import date, timedelta
        today_date = date.fromisoformat(today)
        last = date.fromisoformat(self.last_mentioned)
        return (today_date - last).days <= 7


class EntityStore(BaseModel):
    """Top-level structure of entities.json."""
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    entities: dict[str, Entity] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# sessions/{sessionId}.json → Firestore: users/{uid}/sessions/{sessionId}
# ---------------------------------------------------------------------------


class Message(BaseModel):
    role: MessageRole
    content: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class PromptVersions(BaseModel):
    session: Optional[str] = None
    extraction: Optional[str] = None
    morning: Optional[str] = None


class Ratings(BaseModel):
    morning_question_quality: Optional[int] = None  # 1–5
    companion_honesty: Optional[int] = None  # 1–5


class Session(BaseModel):
    id: str  # YYYY-MM-DD-{type}
    type: SessionType
    date: str  # YYYY-MM-DD
    started_at: datetime = Field(default_factory=datetime.utcnow)
    ended_at: Optional[datetime] = None
    messages: list[Message] = Field(default_factory=list)
    morning_question: Optional[str] = None
    morning_question_source_entities: list[str] = Field(default_factory=list)
    prompt_versions: PromptVersions = Field(default_factory=PromptVersions)
    entities_extracted: list[str] = Field(default_factory=list)
    ratings: Ratings = Field(default_factory=Ratings)
    session_summary: Optional[str] = None

    @classmethod
    def make_id(cls, date: str, session_type: SessionType) -> str:
        return f"{date}-{session_type.value}"
