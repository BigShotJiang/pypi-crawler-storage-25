# Luminus CLI V0 — Firestore Schema

## Overview

Local storage at `~/.luminus/` mirrors the Firestore schema 1:1.
No transformation required on export (TODO-11).

Design constraints from TODO-02:
- **Memory portable** — standard JSON, user-owned, no proprietary formats
- **Lens extensible** — `lens` accepts any string; no hardcoded enum enforcement in V1
- **Responses auditable** — every message stored with timestamp + `prompt_versions`

---

## Local → Firestore Path Mapping

| Local file | Firestore path |
|---|---|
| `~/.luminus/covenant.json` | `users/{uid}/covenant/current` |
| `~/.luminus/entities.json` | `users/{uid}/entities/{entityId}` (one doc per entity on export) |
| `~/.luminus/sessions/{sessionId}.json` | `users/{uid}/sessions/{sessionId}` |


---

## covenant.json

Written once on `luminus start` completion. Never mutated — append-only for DELIGHT-01.

```json
{
  "text": "I commit to daily reflection on my faith and...",
  "timestamp": "2026-04-15T09:00:00Z",
  "input_method": "text",
  "lens": "paul",
  "version": "v1",
  "faith_context": {
    "tradition": "protestant",
    "struggles": ["doubt", "consistency in prayer"],
    "purpose": "deepen daily walk with God"
  },
  "prompt_version": "v1.0"
}
```

| Field | Type | Notes |
|---|---|---|
| `text` | string | Verbatim covenant. **Never modified** — DELIGHT-01 reads this on year 1 anniversary. |
| `timestamp` | ISO 8601 UTC | Covenant creation time. Stored permanently. |
| `input_method` | `"text"` \| `"voice"` | Voice deferred to iOS; always `"text"` in CLI V0. |
| `lens` | string | Starting lens. Extensible — denominations/churches add lenses in V3 (TODO-02). |
| `version` | string | Covenant schema version, not user-editable. |
| `faith_context.tradition` | string | Free text. Optional. |
| `faith_context.struggles` | string[] | Extracted from onboarding conversation. |
| `faith_context.purpose` | string | User's stated purpose from onboarding. |
| `prompt_version` | string | Version of onboarding prompt that produced this covenant. Auditable. |

---

## entities.json

Top-level map of all named entities extracted from sessions.

```json
{
  "updated_at": "2026-04-17T08:00:00Z",
  "entities": {
    "sarah-abc123": { "...": "entity object" },
    "brother-def456": { "...": "entity object" }
  }
}
```

On Firestore export (TODO-11), each key in `entities` becomes a separate document
in the `users/{uid}/entities/{entityId}` subcollection.

### Entity Object

```json
{
  "id": "sarah-abc123",
  "name": "Sarah",
  "type": "person",
  "status": "active",
  "first_session": "2026-04-15",
  "last_mentioned": "2026-04-17",
  "session_count": 3,
  "session_ids": [
    "2026-04-15-chat",
    "2026-04-16-morning",
    "2026-04-17-chat"
  ],
  "companion_note": "User mentions Sarah in context of a difficult conversation they're dreading.",
  "resolution_session": null,
  "created_at": "2026-04-15T10:30:00Z",
  "updated_at": "2026-04-17T08:00:00Z"
}
```

| Field | Type | Notes |
|---|---|---|
| `id` | string | `{slug}-{6-char hex}`. Stable — never reassigned. |
| `name` | string | Display name as extracted. May be informal ("my brother", "Sarah"). |
| `type` | `"person"` \| `"situation"` \| `"intention"` \| `"struggle"` | Drives card type on Covenant screen. |
| `status` | `"active"` \| `"resolved"` \| `"dismissed"` | Drives morning question eligibility. |
| `first_session` | YYYY-MM-DD | Date of first mention. |
| `last_mentioned` | YYYY-MM-DD | Date of most recent mention. |
| `session_count` | int | Total number of distinct sessions this entity appears in. |
| `session_ids` | string[] | Ordered list of session IDs. Enables "my brother across 3 sessions" query. |
| `companion_note` | string | Latest companion observation, set by extraction agent. |
| `resolution_session` | string \| null | Session ID where status → `"resolved"`, or null. |
| `created_at` | ISO 8601 UTC | |
| `updated_at` | ISO 8601 UTC | Updated on every upsert. |

**Status transition rules:**
- `active` → `resolved`: extraction detects resolution language in a later session
- `active` → `dismissed`: user explicitly dismisses in `luminus chat`
- `resolved` and `dismissed` entities are excluded from morning question generation (eval case 7)

**Morning question eligibility check:**
```
status == "active"
AND last_mentioned within past 7 days
AND session_count >= 1
```

---

## sessions/{sessionId}.json

One file per session. `sessionId` format: `YYYY-MM-DD-{type}`.

Valid types: `onboarding`, `morning`, `chat`.

Example IDs: `2026-04-14-onboarding`, `2026-04-15-morning`, `2026-04-15-chat`.

```json
{
  "id": "2026-04-15-morning",
  "type": "morning",
  "date": "2026-04-15",
  "started_at": "2026-04-15T07:00:00Z",
  "ended_at": "2026-04-15T07:18:00Z",
  "messages": [
    {
      "role": "assistant",
      "content": "Yesterday you mentioned dreading a conversation with Sarah. Did that happen?",
      "timestamp": "2026-04-15T07:00:00Z"
    },
    {
      "role": "user",
      "content": "It did. It was harder than I expected.",
      "timestamp": "2026-04-15T07:01:30Z"
    }
  ],
  "morning_question": "Yesterday you mentioned dreading a conversation with Sarah. Did that happen?",
  "morning_question_source_entities": ["sarah-abc123"],
  "prompt_versions": {
    "session": "v1.0",
    "extraction": "v0.1",
    "morning": "v1.0"
  },
  "entities_extracted": ["sarah-abc123"],
  "ratings": {
    "morning_question_quality": 5,
    "companion_honesty": 4
  },
  "session_summary": "User had the difficult conversation with Sarah; expressed relief with lingering guilt."
}
```

| Field | Type | Notes |
|---|---|---|
| `id` | string | `YYYY-MM-DD-{type}` |
| `type` | `"onboarding"` \| `"morning"` \| `"chat"` | |
| `date` | YYYY-MM-DD | |
| `started_at` | ISO 8601 UTC | |
| `ended_at` | ISO 8601 UTC | null until session closes. |
| `messages` | Message[] | Full conversation. See Message object below. |
| `morning_question` | string \| null | The generated question. Set only on `morning` sessions. |
| `morning_question_source_entities` | string[] | Entity IDs that informed the morning question. |
| `prompt_versions.session` | string \| null | Session agent prompt version. Auditable (TODO-02). |
| `prompt_versions.extraction` | string \| null | Extraction prompt version. |
| `prompt_versions.morning` | string \| null | Morning question prompt version. |
| `entities_extracted` | string[] | Entity IDs upserted into `entities.json` after this session. |
| `ratings.morning_question_quality` | int (1–5) \| null | Set by user after morning sessions. |
| `ratings.companion_honesty` | int (1–5) \| null | Set by user after every session. |
| `session_summary` | string | 1-2 sentence summary by extraction agent. Used by morning agent. |

### Message Object

```json
{
  "role": "assistant",
  "content": "...",
  "timestamp": "2026-04-15T07:00:00Z"
}
```

| Field | Type | Notes |
|---|---|---|
| `role` | `"assistant"` \| `"user"` | |
| `content` | string | Full message text. |
| `timestamp` | ISO 8601 UTC | |

---

## Eval Case → Schema Coverage

| Eval case | Handled by |
|---|---|
| Session mentions "Sarah" twice → entity created | Extraction upserts entity; `session_count=1` |
| User states intention → next morning references it | `type="intention"` entity; morning agent reads `active` entities |
| No named situations → extraction returns empty | `entities_extracted: []`; `entities.json` unchanged |
| User is evasive → companion pushes back | Prompt behavior, no schema change |
| Stated intention not followed through → surfaces honestly | Entity `last_mentioned` gap > 3 days; morning agent selects it |
| "my brother" across 3 sessions → `session_count=3` | `session_count` incremented on each extraction upsert |
| Entity resolved → morning question doesn't resurface it | `status="resolved"` → excluded from morning eligibility check |

---

## Firestore Security Rules (for TODO-11)

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{uid} {
      allow read, write: if request.auth.uid == uid;

      match /covenant/{doc} {
        allow read, write: if request.auth.uid == uid;
      }
      match /entities/{entityId} {
        allow read, write: if request.auth.uid == uid;
      }
      match /sessions/{sessionId} {
        allow read, write: if request.auth.uid == uid;
      }
    }
  }
}
```
