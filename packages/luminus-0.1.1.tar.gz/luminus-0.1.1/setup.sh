#!/bin/bash
set -e

# -------------------------------------------------------
# Luminus — one-command setup
# -------------------------------------------------------

BOLD="\033[1m"
DIM="\033[2m"
GOLD="\033[38;5;214m"
RED="\033[31m"
RESET="\033[0m"

echo ""
echo -e "${GOLD}${BOLD}L U M I N U S${RESET}"
echo -e "${DIM}Setting up your companion...${RESET}"
echo ""

# 1. Install uv if not present
if ! command -v uv &>/dev/null; then
  echo -e "${DIM}Installing uv...${RESET}"
  curl -LsSf https://astral.sh/uv/install.sh | sh
  # Add uv to PATH for the rest of this script
  export PATH="$HOME/.local/bin:$PATH"
fi

# 2. Install luminus as a global tool
export PATH="$HOME/.local/bin:$PATH"
echo -e "${DIM}Installing luminus...${RESET}"
uv tool install luminus --reinstall

# 3. Ensure uv's tool bin is on PATH permanently
SHELL_RC=""
case "$SHELL" in
  */zsh)  SHELL_RC="$HOME/.zshrc" ;;
  */bash) SHELL_RC="$HOME/.bashrc" ;;
esac

UV_BIN="$HOME/.local/bin"
if [ -n "$SHELL_RC" ] && ! grep -q "$UV_BIN" "$SHELL_RC" 2>/dev/null; then
  echo "" >> "$SHELL_RC"
  echo "# Added by Luminus setup" >> "$SHELL_RC"
  echo "export PATH=\"$UV_BIN:\$PATH\"" >> "$SHELL_RC"
fi

# 4. Prompt for API key if not already saved
LUMINUS_ENV="$HOME/.luminus/.env"
mkdir -p "$HOME/.luminus"

if [ ! -f "$LUMINUS_ENV" ] || ! grep -q "ANTHROPIC_API_KEY" "$LUMINUS_ENV" 2>/dev/null; then
  echo ""
  echo -e "${DIM}Enter your Anthropic API key (starts with sk-ant-):${RESET}"
  read -r -s api_key
  echo "ANTHROPIC_API_KEY=$api_key" > "$LUMINUS_ENV"
  chmod 600 "$LUMINUS_ENV"
fi

# 5. Done
echo ""
echo -e "${GOLD}${BOLD}Done.${RESET}"
echo ""
echo -e "  Run ${BOLD}luminus${RESET} to get started."
echo -e "  ${DIM}(Open a new terminal window if the command isn't found yet.)${RESET}"
echo ""
