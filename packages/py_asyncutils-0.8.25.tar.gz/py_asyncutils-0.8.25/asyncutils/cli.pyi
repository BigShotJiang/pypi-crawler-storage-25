__all__ = 'run',
def run() -> int: '''Run the command-line interface (this module's REPL) and return the integer return code. See `tools.get_cmd_help()` for detailed usage.'''