from nexo.schemas.resource import Resource, ResourceIdentifier

RESOURCE_MEASUREMENT_RESOURCE = Resource(
    identifiers=[
        ResourceIdentifier(
            key="resource_measurement",
            name="Resource Measurement",
            slug="resource_measurements",
        )
    ],
    details=None,
)
