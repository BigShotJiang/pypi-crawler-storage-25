from datetime import datetime
from pydantic import BaseModel, Field
from typing import Annotated


class MessageId(BaseModel):
    message_id: Annotated[str, Field(..., description="Message's ID")]


class PublishedAt(BaseModel):
    published_at: Annotated[datetime, Field(..., description="Published At")]


class InstanceId(BaseModel):
    instance_id: Annotated[str, Field(..., description="Instance's ID")]


class ServiceKey(BaseModel):
    service_key: Annotated[str, Field(..., description="Service's Key")]
