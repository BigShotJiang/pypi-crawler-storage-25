from airscript.data import Kv


class KeyValue:
    """键值对持久化存储工具类，用于在本地保存、读取和删除数据。"""

    @staticmethod
    def save(key: str, value):
        """保存键值对数据到本地存储。

        Args:
            key: 存储键名。
            value: 要保存的值，支持基本数据类型。
        """
        Kv.save(key, value)

    @staticmethod
    def get(key: str, default_value):
        """从本地存储中获取指定键的值。

        Args:
            key: 存储键名。
            default_value: 当键不存在时返回的默认值。

        Returns:
            存储的值，如果键不存在则返回 default_value。
        """
        return Kv.get(key, default_value)

    @staticmethod
    def remove(key: str):
        """从本地存储中删除指定键值对。

        Args:
            key: 要删除的存储键名。

        Returns:
            删除操作的结果。
        """
        return Kv.remove(key)
