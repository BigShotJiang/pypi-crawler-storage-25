import json
import os.path
import time
from abc import ABC, abstractmethod
from airscript.system import R as asR
from airscript.system import Device as asDevice
from airscript.system import Clipboard as asClipboard
from airscript.system import Channel as asChannel
from airscript.data import Kv as asKv
from airscript.intent import Intent as asIntent
from airscript.system import Noti
from airscript.system import Control as asControl
from airscript.system import Progress as asProgress


class R:
    """资源管理类

    提供项目资源路径管理功能，包括模块路径、资源目录、SD 卡路径等。
    同时提供模块基本信息（名称、ID、版本等）的访问。
    """

    name = asR.moudle_name
    context = asR.context()
    package_name = asR.context().getPackageName()
    id = asR.module_id
    version = asR.getVersionCode()
    mode = asR.getMode()

    @staticmethod
    def __make_path__(base_dir, *child_paths):
        """构建路径的内部方法

        将基础目录和子路径拼接为完整路径。

        Args:
            base_dir: 基础目录路径。
            *child_paths: 一个或多个子路径。

        Returns:
            str 或 list[str]: 单个子路径时返回字符串，多个时返回列表。
                无子路径时返回基础目录。
        """
        # 无参数时返回基础路径
        if not child_paths:
            return base_dir

        # 处理可变参数
        results = []
        for path in child_paths:
            # 统一处理路径格式
            stripped_path = str(path).lstrip("/")
            full_path = os.path.join(base_dir, stripped_path)
            results.append(full_path)

        # 根据参数数量决定返回类型
        return results[0] if len(results) == 1 else results

    @staticmethod
    def res(*child_paths):
        """获取 res 资源目录路径

        Args:
            *child_paths: 可选的子路径。

        Returns:
            str 或 list[str]: 拼接后的完整路径。
        """
        # 基础路径
        base_dir = os.path.join(asR.module_path, "res")
        return R.__make_path__(base_dir, *child_paths)

    @staticmethod
    def img(*child_paths):
        """获取图片资源目录路径

        Args:
            *child_paths: 可选的子路径。

        Returns:
            str 或 list[str]: 拼接后的完整路径。
        """
        # 基础路径
        base_dir = os.path.join(asR.module_path, "res/img")
        return R.__make_path__(base_dir, *child_paths)

    @staticmethod
    def ui(*child_paths):
        """获取 UI 资源目录路径

        Args:
            *child_paths: 可选的子路径。

        Returns:
            str 或 list[str]: 拼接后的完整路径。
        """
        base_dir = os.path.join(asR.module_path, "res/ui")
        return R.__make_path__(base_dir, *child_paths)

    @staticmethod
    def root(*child_paths):
        """获取模块根目录路径

        Args:
            *child_paths: 可选的子路径。

        Returns:
            str 或 list[str]: 拼接后的完整路径。
        """
        return R.__make_path__(asR.module_path, *child_paths)

    @staticmethod
    def sd(*child_paths):
        """获取 SD 卡目录路径

        Args:
            *child_paths: 可选的子路径。

        Returns:
            str 或 list[str]: 拼接后的完整路径。
        """
        base_dir = asR.sd()
        return R.__make_path__(base_dir, *child_paths)

    @staticmethod
    def rel(path: str = __file__, *rel_paths):
        """获取相对路径的绝对路径

        根据给定的基础路径和相对路径，计算并返回标准化的绝对路径。

        Args:
            path: 基础路径（文件或目录），默认为当前文件。
            *rel_paths: 一个或多个相对路径。

        Returns:
            str 或 list[str]: 标准化后的绝对路径。
                无相对路径时返回标准化的基础目录路径。
        """
        # 处理基础路径
        if not os.path.isdir(path):
            path = os.path.dirname(path)
        base_path = os.path.normpath(path)

        # 无附加路径时返回基础路径
        if not rel_paths:
            return base_path

        # 处理可变参数
        results = []
        for rp in rel_paths:
            # 拼接并标准化路径
            full_path = os.path.join(base_path, str(rp))
            normalized_path = os.path.normpath(full_path)
            results.append(normalized_path)

        # 智能返回类型
        return results[0] if len(results) == 1 else results

    @staticmethod
    def get_card():
        """获取设备卡号/标识

        Returns:
            str: 设备卡号信息。
        """
        return asR.getCard()


def exit():
    """退出当前脚本

    Returns:
        无返回值。
    """
    asR.exit()
    # pass


def reboot(delay_time: int = 0):
    """重启脚本

    Args:
        delay_time: 延迟重启时间，单位为毫秒，默认 0（立即重启）。

    Returns:
        无返回值。
    """
    asR.reboot(delay_time)


def open(name_or_package: str):
    """打开应用程序

    Args:
        name_or_package: 应用名称或包名。

    Returns:
        无返回值。
    """
    asIntent.run(name_or_package)


def browser(url: str):
    """使用浏览器打开 URL

    Args:
        url: 要打开的网址。

    Returns:
        无返回值。
    """
    asIntent.browser(url)


def get_foreground_app(active_time: int = 60):
    """获取当前前台应用信息

    Args:
        active_time: 活跃时间窗口（秒），默认 60。

    Returns:
        前台应用信息。
    """
    return asR.getForegroundApp(active_time)


def get_info():
    """获取模块信息

    Returns:
        dict: 模块信息字典，包含版本号等。
    """
    t_info = json.loads(asR.getInfo())
    return t_info


def get_version():
    """获取模块版本号

    Returns:
        str: 模块版本号字符串。
    """
    return get_info()["version"]


class Config:
    """配置管理类

    提供脚本运行配置的管理功能。
    """

    @staticmethod
    def set_stop_re_run(is_open: bool):
        """设置脚本异常停止后是否自动重新运行

        Args:
            is_open: 是否开启异常重运行，True 开启，False 关闭。

        Returns:
            无返回值。
        """
        asR.config("control_error_re_run", is_open)

    @staticmethod
    def set_auto_run(is_open: bool):
        """设置脚本是否自动运行

        Args:
            is_open: 是否开启自动运行，True 开启，False 关闭。

        Returns:
            无返回值。
        """
        asR.config("control_auto_run", is_open)


def refresh_and_find_module(module_name: str):
    """刷新并查找模块是否可用

    反复尝试查找指定模块（最多 10 次，每次间隔 0.1 秒），用于等待模块加载完成。

    Args:
        module_name: 模块名称字符串。

    Returns:
        bool: 模块是否可用。
    """
    import importlib
    importlib.invalidate_caches()
    import importlib.util
    for i in range(10):
        is_active = importlib.util.find_spec(module_name)
        if is_active:
            return True
        else:
            importlib.invalidate_caches()
            time.sleep(0.1)

    print("load--刷新")

    return False


def memory():
    """获取设备内存信息

    Returns:
        设备内存使用情况信息。
    """
    return asDevice.Memory()


def get_external_storage_info():
    """获取外部存储信息

    Returns:
        外部存储使用情况信息。
    """
    return asDevice.external_stirageinfo()


def get_internal_storage_info():
    """获取内部存储信息

    Returns:
        内部存储使用情况信息。
    """
    return asDevice.internal_stirageinfo()


def get_navigation_mode():
    """获取导航栏模式

    Returns:
        当前导航栏模式信息。
    """
    return asDevice.navigation_mode()


# info = None
# if __ascript__hp__:
#     json.dumps()


class ShellListener(ABC):
    """Shell 命令监听器基类（抽象类）

    用于监听 Shell 命令的输出、终止和完成事件。
    """

    @abstractmethod
    def commandOutput(self, i: int, s: str):
        """命令输出回调

        Args:
            i: 命令标识符。
            s: 输出内容。
        """
        pass

    @abstractmethod
    def commandTerminated(self, i: int, s: str):
        """命令终止回调

        Args:
            i: 命令标识符。
            s: 终止信息。
        """
        pass

    def commandCompleted(self, i: int, i1: int):
        """命令完成回调

        Args:
            i: 命令标识符。
            i1: 完成状态码。
        """
        pass


def shell(command: str, callback: ShellListener = None):
    """执行 Shell 命令

    Args:
        command: Shell 命令字符串。
        callback: Shell 命令监听器，默认为 None（同步执行并返回结果）。

    Returns:
        str: 命令执行结果（无回调时）。
    """
    if ShellListener:
        asProgress.shell(command, callback)
    else:
        return asProgress.shell(command)


def channel(fun):
    """注册通道回调函数

    Args:
        fun: 回调函数。

    Returns:
        无返回值。
    """
    asChannel(fun)


class Device:
    """设备信息类

    提供获取设备硬件和软件信息的静态方法，包括设备 ID、名称、品牌、型号等。
    """
    @staticmethod
    def id():
        """获取设备唯一 ID

        Returns:
            str: 设备 ID。
        """
        return asDevice.id()

    @staticmethod
    def name():
        """获取设备名称

        Returns:
            str: 设备名称。
        """
        return asDevice.name()

    @staticmethod
    def display():
        """获取屏幕显示信息

        Returns:
            屏幕分辨率等显示信息。
        """
        return asDevice.display()

    @staticmethod
    def status_bar_height():
        """获取状态栏高度

        Returns:
            int: 状态栏高度（像素）。
        """
        return asDevice.getStatusBarHeight()

    @staticmethod
    def brand():
        """获取设备品牌

        Returns:
            str: 设备品牌名称。
        """
        return asDevice.brand()

    @staticmethod
    def model():
        """获取设备型号

        Returns:
            str: 设备型号名称。
        """
        return asDevice.model()

    @staticmethod
    def sdk():
        """获取 Android SDK 版本号

        Returns:
            int: SDK 版本号。
        """
        return asDevice.sdk()

    @staticmethod
    def version():
        """获取 Android 系统版本

        Returns:
            str: 系统版本字符串。
        """
        return asDevice.version()

    @staticmethod
    def ip():
        """获取设备 IP 地址

        Returns:
            str: 设备 IP 地址。
        """
        return asDevice.ip()

    @staticmethod
    def phone_numbers():
        """获取本机手机号列表，多卡时返回多个（去重）。无权限或无法获取时返回空列表。"""
        return list(asDevice.phoneNumbers())

    @staticmethod
    def current_appinfo():
        """获取当前前台应用信息

        Returns:
            当前前台应用的详细信息。
        """
        return asDevice.currentAppInfo()

    @staticmethod
    def apps():
        """获取已安装应用列表

        Returns:
            list: 已安装应用信息列表。
        """
        return asDevice.apps()

    @staticmethod
    def battery():
        """获取电池信息

        Returns:
            电池状态信息（电量、充电状态等）。
        """
        return asDevice.Battery()

    @staticmethod
    def memory():
        """获取设备内存信息

        Returns:
            设备内存使用情况。
        """
        return asDevice.Memory()

    @staticmethod
    def memory_app():
        """获取应用内存使用信息

        Returns:
            list: 应用内存使用数据列表。
        """
        return list(asDevice.MemoryAPP())

    @staticmethod
    def set_brightness(value: int):
        """设置屏幕亮度

        Args:
            value: 亮度值。

        Returns:
            无返回值。
        """
        asDevice.set_brightness(value)

    @staticmethod
    def statue_bar_height():
        """获取状态栏高度（别名方法）

        Returns:
            int: 状态栏高度（像素）。
        """
        return asDevice.getStatueBarHeight()


class Clipboard:
    """剪贴板操作类

    提供系统剪贴板的读写功能。
    """

    @staticmethod
    def put(msg: str):
        """将文本写入剪贴板

        Args:
            msg: 要写入的文本内容。

        Returns:
            无返回值。
        """
        asClipboard.put(msg)

    @staticmethod
    def get():
        """从剪贴板获取文本

        Returns:
            str: 剪贴板中的文本内容。
        """
        return asClipboard.get()


class KeyValue:
    """键值对存储类

    提供简单的键值对持久化存储功能。
    """

    @staticmethod
    def save(key: str, value):
        """保存键值对

        Args:
            key: 键名。
            value: 值（支持多种类型）。

        Returns:
            无返回值。
        """
        asKv.save(key, value)

    @staticmethod
    def get(key: str, default_value):
        """获取键值对

        Args:
            key: 键名。
            default_value: 键不存在时的默认返回值。

        Returns:
            存储的值，键不存在时返回 default_value。
        """
        return asKv.get(key, default_value)

    @staticmethod
    def remove(key: str):
        """删除键值对

        Args:
            key: 要删除的键名。

        Returns:
            删除操作的结果。
        """
        return asKv.remove(key)


class Notification:
    """通知监听类

    提供系统通知的监听功能。
    """

    @staticmethod
    def listen(call):
        """注册通知监听回调

        Args:
            call: 通知回调函数，当有新通知时被调用。

        Returns:
            无返回值。
        """
        Noti.listener(call)


class Control:
    """控制指令类

    用于发送控制指令到脚本运行环境。
    """

    @staticmethod
    def send(params: dict):
        """发送控制指令

        Args:
            params: 控制参数字典，将被序列化为 JSON 发送。

        Returns:
            无返回值。
        """
        asControl.send(json.dumps(params))
