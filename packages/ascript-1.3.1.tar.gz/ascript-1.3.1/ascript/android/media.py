from airscript.system import Media as asMedia


# from airscript.system import AliTTsParam, TTSAliHelper, AliTtsCosyVoiceHelper
# from java.util import HashMap
# import threading
# from typing import Union


def volume(percent: int, type: int = 3):
    """设置系统音量。

    Args:
        percent: 音量百分比值。
        type: 音量类型，默认为 3（媒体音量）。
    """
    asMedia.volume(percent, type)


def get_volume(type: int = 3):
    """获取当前系统音量。

    Args:
        type: 音量类型，默认为 3（媒体音量）。

    Returns:
        int: 当前音量值。
    """
    return asMedia.getVolume(type)


def talk(msg: str):
    """使用系统 TTS 引擎朗读文本。

    Args:
        msg: 要朗读的文本内容。
    """
    asMedia.talk(msg)


def play(path: str, callback=None):
    """播放音频文件。

    Args:
        path: 音频文件路径。
        callback: 可选的播放完成回调函数。
    """
    if callback:
        asMedia.play(path, callback)
    else:
        asMedia.play(path)


def recode(path: str, time=None):
    """录制音频。

    Args:
        path: 录音文件保存路径。
        time: 可选的录音时长（毫秒），不指定则手动停止。

    Returns:
        录音操作的结果。
    """
    if time:
        return asMedia.recode(path, time)
    else:
        return asMedia.recode(path)


def vibrate(time: int = 200):
    """触发设备振动。

    Args:
        time: 振动时长（毫秒），默认为 200。
    """
    asMedia.vibrate(time)


# ali_tts_lock = threading.Lock()
#
#
# def ali_tts(config: dict, tts_msg: str, autp_play: bool = True, save_file=None):
#     with ali_tts_lock:
#         tts = TTSAliHelper.getInstance()
#         tts.init(config['app_key'], config['ak_id'], config['ak_secret'], config['font_name'])
#         tts.setPlay(autp_play)
#         if save_file:
#             tts.saveFile(save_file)
#
#         return tts.change(tts_msg)
#
#
class AliTts:
    “””阿里云 TTS 语音合成（已废弃，请使用 alimedia 插件）。”””

    def __init__(self, app_key: str, ak_id: str, ak_secret: str, font_name: str = “siqi”, speed_level: str = “1”,
                 pitch_level: str = “0”, volume: str = “1.0”):
        “””初始化阿里云 TTS（已废弃）。

        Args:
            app_key: 阿里云应用 Key。
            ak_id: 阿里云 AccessKey ID。
            ak_secret: 阿里云 AccessKey Secret。
            font_name: 发音人名称，默认为 “siqi”。
            speed_level: 语速等级，默认为 “1”。
            pitch_level: 语调等级，默认为 “0”。
            volume: 音量大小，默认为 “1.0”。

        Raises:
            Exception: 此 API 已废弃，请使用 alimedia 插件。
        “””
        raise Exception(“此API已废弃,已迁移至插件中. 详情请见: android-插件列表-”alimedia”)


#
#     def start(self, tts_msg: str, auto_play: bool = True, save_file=None, font_name: str = None,
#               speed_level: str = None,
#               pitch_level: str = None, volume: Union[str, int] = 1):
#         self.tts_core.setPlay(auto_play)
#         self.tts_core.saveFile(save_file)
#         if font_name:
#             self.param.setFont_name(font_name)
#         if speed_level:
#             self.param.setSpeed_level(speed_level)
#         if pitch_level:
#             self.param.setPitch_level(pitch_level)
#         if volume:
#             self.param.setVolume(str(volume))
#         self.tts_core.init_params(self.param)
#         return self.tts_core.change(tts_msg)
#
#     def start_asy(self, tts_msg: str, auto_play: bool = True, save_file=None, call_back=None, font_name: str = "siqi",
#                   speed_level: str = "1",
#                   pitch_level: str = "0", volume: Union[str, int] = 1):
#         self.tts_core.setPlay(auto_play)
#         self.tts_core.saveFile(save_file)
#         if font_name:
#             self.param.setFont_name(font_name)
#         if speed_level:
#             self.param.setSpeed_level(speed_level)
#         if pitch_level:
#             self.param.setPitch_level(pitch_level)
#         if volume:
#             self.param.setVolume(str(volume))
#         self.tts_core.init_params(self.param)
#         if call_back:
#             self.tts_core.callBack(call_back)
#         return self.tts_core.change_asy(tts_msg)
#
#     def close(self):
#         return self.tts_core.close()
#
#
class AliTtsCosyVoice:
    “””阿里云 CosyVoice 语音合成（已废弃，请使用 alimedia 插件）。”””

    def __init__(self, app_key: str,
                 ak_id: str,
                 ak_secret: str,
                 voice: str = “longze”,
                 enable_subtitle: bool = True,
                 format: str = “pcm”,
                 sample_rate: int = 16000,
                 volume: int = 50,
                 speech_rate: int = 0,
                 pitch_rate: int = 0,
                 new_client=False,
                 ):
        “””初始化阿里云 CosyVoice TTS（已废弃）。

        Args:
            app_key: 阿里云应用 Key。
            ak_id: 阿里云 AccessKey ID。
            ak_secret: 阿里云 AccessKey Secret。
            voice: 发音人名称，默认为 “longze”。
            enable_subtitle: 是否启用字幕，默认为 True。
            format: 音频格式，默认为 “pcm”。
            sample_rate: 采样率，默认为 16000。
            volume: 音量大小，默认为 50。
            speech_rate: 语速，默认为 0。
            pitch_rate: 语调，默认为 0。
            new_client: 是否创建新的客户端实例，默认为 False。

        Raises:
            Exception: 此 API 已废弃，请使用 alimedia 插件。
        “””
        raise Exception(“此API已废弃,已迁移至插件中. 详情请见: android-插件列表-”alimedia”)


#         if new_client:
#             self.tts_cosy_voice = AliTtsCosyVoiceHelper.newInstance()
#         else:
#             self.tts_cosy_voice = AliTtsCosyVoiceHelper.getInstance()
#
#         self.tts_cosy_voice.makeToken(app_key, ak_id, ak_secret)
#         self.param = HashMap()
#         self.param.put("enable_subtitle", enable_subtitle)
#         self.param.put("voice", voice)
#         self.param.put("format", format)
#         self.param.put("sample_rate", sample_rate)
#         self.param.put("volume", volume)
#         self.param.put("speech_rate", speech_rate)
#         self.param.put("pitch_rate", pitch_rate)
#         self.tts_cosy_voice.setParams(self.param)
#
#     def start(self, tts_msg: str, listener=None, voice: str = "longze",
#               enable_subtitle: bool = True,
#               format: str = "pcm",
#               sample_rate: int = 16000,
#               volume: int = 50,
#               speech_rate: int = 0,
#               pitch_rate: int = 0):
#         if listener:
#             self.tts_cosy_voice.setPyListener(listener)
#
#         self.param = HashMap()
#         self.param.put("enable_subtitle", enable_subtitle)
#         self.param.put("voice", voice)
#         self.param.put("format", format)
#         self.param.put("sample_rate", sample_rate)
#         self.param.put("volume", volume)
#         self.param.put("speech_rate", speech_rate)
#         self.param.put("pitch_rate", pitch_rate)
#         self.tts_cosy_voice.setParams(self.param)
#
#         self.tts_cosy_voice.play(tts_msg)
#
#     def close(self):
#         return self.tts_cosy_voice.stop()


def image_to_gallery(file_path: str):
    """将图片文件添加到系统相册。

    Args:
        file_path: 图片文件的绝对路径。
    """
    asMedia.file_to_gallery(file_path)
