from typing import Union

from airscript.system import SzkAgent


def shell(command: Union[str, list]):
    """通过 Shizuku 执行 Shell 命令

    使用 Shizuku 权限代理执行 Shell 命令，支持字符串或列表格式的命令。

    Args:
        command: Shell 命令，可以是字符串格式或字符串列表格式。

    Returns:
        str: 命令执行的输出结果。
    """
    if type(command) == str:
        return SzkAgent.shell(command)
    else:
        return SzkAgent.shell_array(command)


def click(x: int, y: int):
    """通过 Shizuku 模拟点击

    使用 Shizuku 权限执行 input tap 命令模拟屏幕点击。

    Args:
        x: 点击位置的 X 坐标。
        y: 点击位置的 Y 坐标。

    Returns:
        str: 命令执行的输出结果。
    """
    return shell(f"input tap {x} {y}")


def swipe(x1: int, y1: int, x2: int, y2: int, dur: int = 200):
    """通过 Shizuku 模拟滑动

    使用 Shizuku 权限执行 input swipe 命令模拟屏幕滑动。

    Args:
        x1: 滑动起始点 X 坐标。
        y1: 滑动起始点 Y 坐标。
        x2: 滑动结束点 X 坐标。
        y2: 滑动结束点 Y 坐标。
        dur: 滑动持续时间，单位为毫秒，默认 200。

    Returns:
        str: 命令执行的输出结果。
    """
    return shell(f"input swipe {x1} {y1} {x2} {y2} {dur}")
