import time

from airscript.ui import Window as asWindow
from airscript.ui.dialog import toast as astoast
from airscript.ui.dialog import alert as asalert
from airscript.ui.dialog import confirm as asconfirm
from airscript.ui.dialog import promat as aspromat
from airscript.ui import Float as asFloat
from airscript.screen import Screen
from . import screen
import numpy as np
import cv2
from PIL import Image

from airscript.system import R as asR

from .system import Device


class WebWindow:
    """Web 窗口组件，用于在 Android 设备上显示 HTML 页面的悬浮窗口。"""

    def __init__(self, html: str, tunnel=None, id: int = None):
        """初始化 Web 窗口。

        Args:
            html: HTML 页面路径或内容。
            tunnel: 可选的消息通道回调函数，用于 JS 与 Python 之间的通信，签名为 tunnel(key, value)。
            id: 可选的窗口唯一标识 ID。
        """
        super().__init__()
        self.id = id
        self._user_tunnel = tunnel
        self._closed = False
        if tunnel:
            self.window = asWindow(html, tunnel)
        else:
            self.window = asWindow(html)

        if id:
            self.window.id(id)

        self.res = None

    def mode(self, mode: int = 0):
        """设置窗口显示模式。

        Args:
            mode: 显示模式，0=普通窗口, 3=悬浮窗等。
        """
        self.window.model(mode)

    def type(self, ftype: int = 0):
        """设置窗口类型。

        Args:
            ftype: 窗口类型值，默认为 0。
        """
        self.window.type(ftype)

    def tunner(self, fun):
        """设置消息通道回调函数。

        Args:
            fun: 回调函数，签名为 fun(key, value)，用于接收 JS 发送的消息。
        """
        self._user_tunnel = fun
        self.window.tunner(fun)

    def size(self, width=None, height=None):
        """设置窗口尺寸。

        Args:
            width: 窗口宽度，支持像素值或 CSS 单位（如 "50vw"）。
            height: 窗口高度，支持像素值或 CSS 单位（如 "50vh"）。
        """
        if width:
            self.window.width(width)

        if height:
            self.window.height(height)

    def width(self, width):
        """设置窗口宽度。

        Args:
            width: 窗口宽度值。
        """
        if width:
            self.window.width(width)

    def height(self, height):
        """设置窗口高度。

        Args:
            height: 窗口高度值。
        """
        if height:
            self.window.height(height)

    def background(self, color: str):
        """设置窗口背景颜色。

        Args:
            color: 颜色值字符串，如 "#FFFFFF" 或 "#00000000"（透明）。
        """
        self.window.background(color)

    def drag(self, is_drag: bool = False):
        """设置窗口是否可拖拽。

        Args:
            is_drag: 是否允许拖拽，默认为 False。
        """
        self.window.drag(is_drag)

    def dim_amount(self, dim: float = 0.5):
        """设置窗口背景遮罩透明度。

        Args:
            dim: 遮罩透明度，0.0 为完全透明，1.0 为完全不透明，默认为 0.5。
        """
        self.window.dimAmount(dim)

    def gravity(self, gravity: int = None, offset_x: int = None, offset_y: int = None):
        """设置窗口位置和偏移。

        Args:
            gravity: 窗口对齐方式。
            offset_x: 水平偏移量。
            offset_y: 垂直偏移量。
        """
        if gravity:
            self.window.gravity(gravity)
        if offset_x:
            self.window.x(offset_x)

        if offset_y:
            self.window.y(offset_y)

    def x(self, offset_x: int):
        """设置窗口水平偏移量。

        Args:
            offset_x: 水平偏移量。
        """
        self.window.x(offset_x)

    def y(self, offset_y: int):
        """设置窗口垂直偏移量。

        Args:
            offset_y: 垂直偏移量。
        """
        self.window.y(offset_y)

    def show(self, wait=False):
        """显示窗口。

        Args:
            wait: 是否阻塞等待窗口关闭，默认为 False。设为 True 时会阻塞当前线程直到窗口被关闭。
        """
        self.window.show()

        if not wait:
            return

        self._closed = False
        user_tunnel = self._user_tunnel

        def _wait_wrapper(key, value):
            if key == "__close" or key == "destory":
                self._closed = True
                return
            if user_tunnel:
                user_tunnel(key, value)

        self.window.tunner(_wait_wrapper)

        while not self._closed:
            time.sleep(0.5)

        if user_tunnel:
            self.window.tunner(user_tunnel)

    def close(self):
        """关闭窗口。"""
        self.window.close()
        self._closed = True

    def go_back(self):
        """WebView 后退到上一页。

        Returns:
            后退操作的结果。
        """
        return self.window.goBack()

    def go_forward(self):
        """WebView 前进到下一页。

        Returns:
            前进操作的结果。
        """
        return self.window.goForward()

    def call(self, js: str, res_callback=None):
        """在 WebView 中执行 JavaScript 代码。

        Args:
            js: 要执行的 JavaScript 代码字符串。
            res_callback: 可选的结果回调函数，接收 JS 执行结果。
        """
        self.window.call(js, res_callback)

    def get_html(self):
        """获取当前 WebView 页面的完整 HTML 内容。

        Returns:
            str: 页面的 HTML 内容字符串，超时（5秒）后返回 None。
        """
        self.res = None

        def res_callback(msg):
            self.res = msg

        self.call("(function() { return document.documentElement.outerHTML; })();", res_callback)

        st = time.time()
        while True:
            if self.res:
                return self.res
            time.sleep(0.1)
            if time.time() - st > 5:
                return None

    def dump(self):
        """导出当前 WebView 页面的 DOM 结构信息。"""
        self.window.dump()


class Dialog:
    """对话框工具类，提供 Toast、Alert、Confirm、Prompt 等常用对话框。"""

    @staticmethod
    def toast(msg, dur=3000, gravity=1 | 16, x=0, y=0.2, bg_color: str = None, color: str = None, font_size: int = 0):
        """显示 Toast 提示消息。

        Args:
            msg: 提示消息内容。
            dur: 显示时长（毫秒），默认为 3000。
            gravity: 显示位置的对齐方式，默认为居中。
            x: 水平偏移比例，默认为 0。
            y: 垂直偏移比例，默认为 0.2。
            bg_color: 可选的背景颜色，如 "#000000"。
            color: 可选的文字颜色，如 "#FFFFFF"。
            font_size: 字体大小，0 表示使用默认大小。
        """
        astoast(msg, dur, gravity, x, y, bg_color, color, font_size)

    @staticmethod
    def alert(msg: str, submit: str = "确认"):
        """显示警告对话框，阻塞等待用户点击确认。

        Args:
            msg: 对话框消息内容。
            submit: 确认按钮文本，默认为 "确认"。

        Returns:
            bool: 用户点击确认后返回 True。
        """
        _res = []

        def tunner(k, v):
            if k == '__alert':
                _res.append(True)

        asalert(msg, tunner, submit)

        while len(_res) < 1:
            time.sleep(0.5)
        return True

    @staticmethod
    def confirm(msg: str, title: str = None, submit: str = "确认", cancel: str = "取消"):
        """显示确认对话框，阻塞等待用户选择确认或取消。

        Args:
            msg: 对话框消息内容。
            title: 可选的对话框标题。
            submit: 确认按钮文本，默认为 "确认"。
            cancel: 取消按钮文本，默认为 "取消"。

        Returns:
            bool: 用户点击确认返回 True，取消返回 False。
        """
        win = asconfirm(msg)
        if title:
            win.title(title)

        __res = []

        def tunner(k, v):
            if k == "__confirm":
                if v == "sure":
                    __res.append(True)
                else:
                    __res.append(False)

        win.submit(submit)
        win.cancle(cancel)
        win.show(tunner)

        while len(__res) < 1:
            time.sleep(0.5)

        return __res[0]

    @staticmethod
    def prompt(msg: str = "请输入信息", title: str = None, value: str = None, hint: str = None, submit: str = "确认",
               cancel: str = "取消"):
        """显示输入对话框，阻塞等待用户输入内容。

        Args:
            msg: 对话框提示消息，默认为 "请输入信息"。
            title: 可选的对话框标题。
            value: 输入框的默认值。
            hint: 输入框的占位提示文本。
            submit: 确认按钮文本，默认为 "确认"。
            cancel: 取消按钮文本，默认为 "取消"。

        Returns:
            str 或 None: 用户点击确认时返回输入的文本内容，取消时返回 None。
        """
        win = aspromat(msg)
        if title:
            win.title(title)

        __res = []

        def tunner(k, v):
            if k == "__promat":
                if v == "cancle":
                    __res.append(False)
                else:
                    __res.extend([True, v])

        win.value(value)
        win.hint(hint)
        win.submit(submit)
        win.cancle(cancel)
        win.show(tunner)

        while len(__res) < 1:
            time.sleep(0.5)

        if __res[0]:
            return __res[1]

        return None


class Loger(WebWindow):
    """日志悬浮窗组件，继承自 WebWindow，用于在屏幕上显示可拖拽的日志窗口。"""

    def __init__(self, html: str = asR.aes("ui/dialog/loger.html")):
        """初始化日志悬浮窗。

        Args:
            html: 日志窗口的 HTML 页面路径，默认使用内置日志页面。
        """
        super().__init__(html, id=11)

        self.drag(True)
        self.withclose = False
        self.dim_amount(0)
        self.background("#00000000")

        display = Device.display()
        if display.widthPixels > display.heightPixels:
            self.size("50vh", "50vh")
        else:
            self.size("50vw", "50vw")

        self.mode(3)


class FloatWindow:
    """系统悬浮球控制类，用于显示、隐藏和自定义悬浮操作菜单。"""

    @staticmethod
    def hide():
        """隐藏悬浮球。"""
        asFloat.hide()

    @staticmethod
    def show(x: float = -1, y: float = -1, dim: float = 1):
        """显示悬浮球。

        Args:
            x: 悬浮球水平位置，-1 表示使用默认位置。
            y: 悬浮球垂直位置，-1 表示使用默认位置。
            dim: 悬浮球透明度，1 为完全不透明。
        """
        asFloat.show(dim, x, y)

    @staticmethod
    def add_menu(menu_id: str, menu_ico: str, menu_click_listener, remove_system: bool = False):
        """向悬浮球添加自定义菜单项。

        Args:
            menu_id: 菜单项唯一标识 ID。
            menu_ico: 菜单图标路径或资源。
            menu_click_listener: 菜单点击回调函数。
            remove_system: 是否移除系统默认菜单项，默认为 False。
        """
        asFloat.addMenu(menu_id, menu_ico, menu_click_listener, remove_system)


class ImageWindow:
    """图片展示窗口，用于在屏幕上显示图片。"""

    @staticmethod
    def show(file_or_bitmap_or_ndarray):
        """在屏幕上显示图片。

        支持多种图片格式输入，包括文件路径、numpy 数组、PIL Image 和 Android Bitmap 对象。

        Args:
            file_or_bitmap_or_ndarray: 图片数据，支持以下类型：
                - str: 图片文件路径
                - numpy.ndarray: OpenCV 格式的图片数组
                - PIL.Image.Image: PIL 图片对象
                - Bitmap: Android Bitmap 对象
        """
        print(type(file_or_bitmap_or_ndarray))
        if type(file_or_bitmap_or_ndarray) == str:
            Screen.show_img_file(file_or_bitmap_or_ndarray)
        elif type(file_or_bitmap_or_ndarray) == np.ndarray:
            # file_or_bitmap_or_ndarray = cv2.cvtColor(file_or_bitmap_or_ndarray, cv2.COLOR_BGR2RGB)
            bitmap = screen.cvimage_to_bitmap(file_or_bitmap_or_ndarray)
            Screen.show_img_bitmap(bitmap)
        elif isinstance(file_or_bitmap_or_ndarray, Image.Image):
            np_image = np.array(file_or_bitmap_or_ndarray)
            opencv_image = cv2.cvtColor(np_image, cv2.COLOR_RGB2BGR)
            bitmap = screen.cvimage_to_bitmap(opencv_image)
            Screen.show_img_bitmap(bitmap)
        else:
            Screen.show_img_bitmap(file_or_bitmap_or_ndarray)
