import json

from airscript.system import Control as asControl
from airscript.system import Channel as asChannel


def connect_to_as(user_dev: str):
    """通过 AirScript 协议连接到远程设备。

    Args:
        user_dev: 目标设备标识字符串。
    """
    asControl.connect(user_dev, 0)


def connect_to_ws(ws_path: str):
    """通过 WebSocket 协议连接到远程设备。

    Args:
        ws_path: WebSocket 连接地址。
    """
    asControl.connect(ws_path, 1)


def send(params: dict):
    """向已连接的远程设备发送控制指令。

    Args:
        params: 指令参数字典，会被序列化为 JSON 发送。
    """
    asControl.send(json.dumps(params))


def close():
    """关闭当前的远程控制连接。"""
    asControl.close()


def channel(fun):
    """注册消息通道回调，用于接收远程设备发来的消息。

    Args:
        fun: 消息回调函数。
    """
    asChannel(fun)
