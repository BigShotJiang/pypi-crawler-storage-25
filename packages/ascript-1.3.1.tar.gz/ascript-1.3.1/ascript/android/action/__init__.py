from typing import Union, List

try:
    from android.graphics import Point
    from airscript.action import click as asclick
    from airscript.action import Catch as asCatch
    from airscript.action import slide as asslide
    from airscript.action import touch as astouch
    from airscript.action import input as asinput
    from airscript.action import key as askey
    from ..node import Selector
    from airscript.action import gesture as asgesture
    from airscript.action import path as aspath
    from airscript.action import hid as aHid
    from airscript.action import IME as asIME
    from android.view.animation import LinearInterpolator
    from java import jfloat, jarray,jint
    import math
except Exception as e:
    print(str(e))


def click(x: Union[int, Point], y: int = None, dur: int = 20):
    """模拟点击

     这个函数可以接受坐标 (x, y) 或者一个 Point 对象作为点击位置。

     :param x: 点击的X坐标或一个Point对象。这是必须提供的参数。
     :param y: 点击的Y坐标。当参数x是int类型时，此参数是必需的。
     :param dur: 点击操作的持续时间，单位是毫秒。

     :return: 无返回值。
     :raises Exception: 如果参数 x 为 None，则抛出异常。
     """

    if x is None:
        raise Exception("click 参数不能为 None")

    if type(x) == float:
        x = int(x)

    if type(y) == float:
        y = int(y)

    if type(x) == int:
        asclick(x, y, dur)
    else:
        asclick(x, dur)


def swipe(x: int, y: int, x1: int, y1: int, dur: int = 20):
    """模拟滑动
    这个函数可以模拟滑动

    :param x: 滑动起始点x坐标
    :param y: 滑动起始点y坐标
    :param x1: 滑动结束点x坐标
    :param y1: 滑动结束点y坐标
    :param dur: 滑动持续的时间(默认20毫秒)，单位是毫秒。

    :return: 无返回值。
    """
    x = int(x)
    y = int(y)
    x1 = int(x1)
    y1 = int(y1)

    return asslide(x, y, x1, y1, dur)


def slide(x: int, y: int, x1: int, y1: int, dur: int = 20, interpolator=None, control_points=None):
    """模拟滑动
    这个函数可以模拟滑动

    :param x: 滑动起始点x坐标
    :param y: 滑动起始点y坐标
    :param x1: 滑动结束点x坐标
    :param y1: 滑动结束点y坐标
    :param dur: 滑动持续的时间(默认20毫秒)，单位是毫秒。
    :interpolator: 差速器,可实现加减速等滑动效果
    :control_points: 贝塞尔控制点
    :return: 无返回值。

    .. tip::
    关于interpolator 差速器:
     该部分主要是android.view.animation.Interpolato 的子类 如:
     LinearInterpolator,AccelerateInterpolator,DecelerateInterpolator,OvershootInterpolator,AnticipateInterpolator,AnticipateOvershootInterpolator,BounceInterpolator

    """

    x = int(x)
    y = int(y)
    x1 = int(x1)
    y1 = int(y1)

    if dur < 0:
        dur = 0

    if interpolator is None and control_points is None:
        res = asslide(x, y, x1, y1, dur)
    else:

        if type(control_points) is int:
            control_points = asslide.generateRandomControlPoints(jfloat(x), jfloat(y), jfloat(x1), jfloat(y1),jint(control_points))

        if control_points is None:
            return asslide.slide_c(jfloat(x), jfloat(y), jfloat(x1), jfloat(y1), dur, interpolator)

        asslide.slide_i(jfloat(x), jfloat(y), jfloat(x1), jfloat(y1), dur, interpolator, jarray(jfloat)(control_points))

    return True


def input(msg: str = "", selector=None):
    """模拟文本输入

    向当前焦点控件输入指定文本内容。可选择性地指定目标控件。

    Args:
        msg: 要输入的文本内容，默认为空字符串。
        selector: 目标控件选择器，为 None 时向当前焦点控件输入。

    Returns:
        无返回值。
    """
    if selector:
        asinput(msg, selector.sel)
    else:
        asinput(msg)


class Touch:
    """触摸操作类

    提供底层触摸事件模拟，包括按下、移动和抬起操作。
    """

    @staticmethod
    def down(x, y, dur: int = 20):
        """模拟触摸按下事件

        Args:
            x: 按下位置的 X 坐标。
            y: 按下位置的 Y 坐标。
            dur: 按下操作的持续时间，单位为毫秒，默认 20。

        Returns:
            无返回值。
        """
        x = int(x)
        y = int(y)
        astouch.down(x, y, dur)

    @staticmethod
    def move(x, y, dur: int = 20):
        """模拟触摸移动事件

        Args:
            x: 移动目标位置的 X 坐标。
            y: 移动目标位置的 Y 坐标。
            dur: 移动操作的持续时间，单位为毫秒，默认 20。

        Returns:
            无返回值。
        """
        x = int(x)
        y = int(y)
        astouch.move(x, y, dur)

    @staticmethod
    def up(x, y, dur: int = 20):
        """模拟触摸抬起事件

        Args:
            x: 抬起位置的 X 坐标。
            y: 抬起位置的 Y 坐标。
            dur: 抬起操作的持续时间，单位为毫秒，默认 20。

        Returns:
            无返回值。
        """
        x = int(x)
        y = int(y)
        astouch.up(x, y, dur)


class Key:
    """按键操作类

    提供模拟物理按键和系统按键的功能，如 Home 键、返回键等。
    """

    @staticmethod
    def home():
        """模拟按下 Home 键

        Returns:
            无返回值。
        """
        askey.home()

    @staticmethod
    def back():
        """模拟按下返回键

        Returns:
            无返回值。
        """
        askey.back()

    @staticmethod
    def notifactions():
        """打开通知栏

        Returns:
            无返回值。
        """
        askey.notifactions()

    @staticmethod
    def lockscreen():
        """模拟锁屏操作

        Returns:
            无返回值。
        """
        askey.lockscreen()

    @staticmethod
    def screenshot():
        """模拟截屏操作

        Returns:
            无返回值。
        """
        askey.screenshot()

    @staticmethod
    def recents():
        """打开最近任务列表

        Returns:
            无返回值。
        """
        askey.recents()


class Hid:
    """HID（人机接口设备）操作类

    通过 HID 协议模拟点击、滑动和按键操作，适用于需要硬件级输入模拟的场景。
    """

    @staticmethod
    def click(x: int, y: int, dur: int = 20):
        """通过 HID 协议模拟点击

        Args:
            x: 点击位置的 X 坐标。
            y: 点击位置的 Y 坐标。
            dur: 点击操作的持续时间，单位为毫秒，默认 20。

        Returns:
            无返回值。
        """
        x = int(x)
        y = int(y)
        aHid.click(x, y, dur)

    @staticmethod
    def swipe(x: int, y: int, x1: int, y1: int, dur: int = 20):
        """通过 HID 协议模拟滑动

        Args:
            x: 滑动起始点 X 坐标。
            y: 滑动起始点 Y 坐标。
            x1: 滑动结束点 X 坐标。
            y1: 滑动结束点 Y 坐标。
            dur: 滑动持续时间，单位为毫秒，默认 20。

        Returns:
            无返回值。
        """
        x = int(x)
        y = int(y)
        x1 = int(x1)
        y1 = int(y1)
        aHid.slide(x, y, x1, y1, dur)

    @staticmethod
    def slide(x: int, y: int, x1: int, y1: int, dur: int = 20):
        """通过 HID 协议模拟滑动（与 swipe 功能相同）

        Args:
            x: 滑动起始点 X 坐标。
            y: 滑动起始点 Y 坐标。
            x1: 滑动结束点 X 坐标。
            y1: 滑动结束点 Y 坐标。
            dur: 滑动持续时间，单位为毫秒，默认 20。

        Returns:
            无返回值。
        """
        x = int(x)
        y = int(y)
        x1 = int(x1)
        y1 = int(y1)
        aHid.slide(x, y, x1, y1, dur)

    @staticmethod
    def key(*keycode):
        """通过 HID 协议模拟按键

        Args:
            *keycode: 一个或多个按键码。

        Returns:
            无返回值。
        """
        aHid.key(keycode)


class Path:
    """手势路径类

    用于构建复杂的手势路径，支持直线、曲线、圆弧等多种路径形状。
    可配合 gesture 函数执行多指手势操作。
    """

    def __init__(self, start_time: int = 0, duration: int = 20, will_continue: bool = False):
        """初始化手势路径

        Args:
            start_time: 手势开始的延迟时间，单位为毫秒，默认 0。
            duration: 手势持续时间，单位为毫秒，默认 20。
            will_continue: 是否在路径结束后保持触摸状态，默认 False。
        """
        self.mpath = aspath(start_time, duration, will_continue)

    def quadTo(self, x1, y1, x2, y2):
        """添加二次贝塞尔曲线到路径

        Args:
            x1: 控制点 X 坐标。
            y1: 控制点 Y 坐标。
            x2: 终点 X 坐标。
            y2: 终点 Y 坐标。
        """
        self.mpath.quadTo(x1, y1, x2, y2)

    def lineTo(self, x1, y1):
        """添加直线到路径

        Args:
            x1: 终点 X 坐标。
            y1: 终点 Y 坐标。
        """
        self.mpath.lineTo(x1, y1)

    def rCubicTo(self, x1, y1, x2, y2, x3, y3):
        """添加相对三次贝塞尔曲线到路径

        使用相对于当前点的坐标偏移量。

        Args:
            x1: 第一个控制点的 X 偏移量。
            y1: 第一个控制点的 Y 偏移量。
            x2: 第二个控制点的 X 偏移量。
            y2: 第二个控制点的 Y 偏移量。
            x3: 终点的 X 偏移量。
            y3: 终点的 Y 偏移量。
        """
        self.mpath.rCubicTo(x1, y1, x2, y2, x3, y3)

    def rMoveTo(self, x1, y1):
        """相对移动路径起点

        使用相对于当前点的坐标偏移量移动起点。

        Args:
            x1: X 方向偏移量。
            y1: Y 方向偏移量。
        """
        self.mpath.rMoveTo(x1, y1)

    def reset(self):
        """重置路径

        清除路径中所有的线条和曲线，但保留填充类型设置。

        Returns:
            无返回值。
        """
        self.mpath.reset()

    def rewind(self):
        """回绕路径

        清除路径中所有线条和曲线，保留内部数据结构以便更快地复用。

        Returns:
            无返回值。
        """
        self.mpath.rewind()

    def moveTo(self, x1, y1):
        """移动路径起点到指定坐标

        Args:
            x1: 目标 X 坐标。
            y1: 目标 Y 坐标。
        """
        self.mpath.moveTo(x1, y1)

    def rQuadTo(self, dx1, dy1, dx2, dy2):
        """添加相对二次贝塞尔曲线到路径

        使用相对于当前点的坐标偏移量。

        Args:
            dx1: 控制点的 X 偏移量。
            dy1: 控制点的 Y 偏移量。
            dx2: 终点的 X 偏移量。
            dy2: 终点的 Y 偏移量。
        """
        self.mpath.rQuadTo(dx1, dy1, dx2, dy2)

    def addArc(self, left, top, right, bottom, startAngle, sweepAngle):
        """添加圆弧到路径

        Args:
            left: 圆弧所在椭圆的外接矩形左边界。
            top: 圆弧所在椭圆的外接矩形上边界。
            right: 圆弧所在椭圆的外接矩形右边界。
            bottom: 圆弧所在椭圆的外接矩形下边界。
            startAngle: 圆弧起始角度（度数）。
            sweepAngle: 圆弧扫过的角度（度数）。
        """
        self.mpath.addArc(left, top, right, bottom, startAngle, sweepAngle)

    def addCircle(self, x, y, radius, dir):
        """添加圆形到路径

        Args:
            x: 圆心 X 坐标。
            y: 圆心 Y 坐标。
            radius: 圆的半径。
            dir: 绘制方向（顺时针/逆时针）。
        """
        self.mpath.addCircle(x, y, radius, dir)

    def addOval(self, left, top, right, bottom, dir):
        """添加椭圆到路径

        Args:
            left: 椭圆外接矩形左边界。
            top: 椭圆外接矩形上边界。
            right: 椭圆外接矩形右边界。
            bottom: 椭圆外接矩形下边界。
            dir: 绘制方向（顺时针/逆时针）。
        """
        self.mpath.addOval(left, top, right, bottom, dir)

    def addRect(self, left, top, right, bottom, dir):
        """添加矩形到路径

        Args:
            left: 矩形左边界。
            top: 矩形上边界。
            right: 矩形右边界。
            bottom: 矩形下边界。
            dir: 绘制方向（顺时针/逆时针）。
        """
        self.mpath.addRect(left, top, right, bottom, dir)

    def addRoundRect(self, left, top, right, bottom, rx, ry, dir):
        """添加圆角矩形到路径

        Args:
            left: 矩形左边界。
            top: 矩形上边界。
            right: 矩形右边界。
            bottom: 矩形下边界。
            rx: X 方向圆角半径。
            ry: Y 方向圆角半径。
            dir: 绘制方向（顺时针/逆时针）。
        """
        self.mpath.addRoundRect(left, top, right, bottom, rx, ry, dir)

    def arcTo(self, left, top, right, bottom, startAngle, sweepAngle, forceMoveTo):
        """添加圆弧到路径（可选强制移动）

        Args:
            left: 圆弧所在椭圆的外接矩形左边界。
            top: 圆弧所在椭圆的外接矩形上边界。
            right: 圆弧所在椭圆的外接矩形右边界。
            bottom: 圆弧所在椭圆的外接矩形下边界。
            startAngle: 圆弧起始角度（度数）。
            sweepAngle: 圆弧扫过的角度（度数）。
            forceMoveTo: 是否强制移动到圆弧起点，而不是从当前点画线连接。
        """
        self.mpath.arcTo(left, top, right, bottom, startAngle, sweepAngle, forceMoveTo)

    def cubicTo(self, x1, y1, x2, y2, x3, y3):
        """添加三次贝塞尔曲线到路径

        Args:
            x1: 第一个控制点 X 坐标。
            y1: 第一个控制点 Y 坐标。
            x2: 第二个控制点 X 坐标。
            y2: 第二个控制点 Y 坐标。
            x3: 终点 X 坐标。
            y3: 终点 Y 坐标。
        """
        self.mpath.cubicTo(x1, y1, x2, y2, x3, y3)

    def setLastPoint(self, dx, dy):
        """设置路径的最后一个点的坐标

        Args:
            dx: 新的 X 坐标。
            dy: 新的 Y 坐标。
        """
        self.mpath.setLastPoint(dx, dy)

    def close(self):
        """关闭当前子路径

        从当前点画一条直线到路径的起始点，形成封闭图形。

        Returns:
            无返回值。
        """
        self.mpath.close()

    def rLineTo(self, dx, dy):
        """添加相对直线到路径

        使用相对于当前点的坐标偏移量。

        Args:
            dx: X 方向偏移量。
            dy: Y 方向偏移量。
        """
        self.mpath.rLineTo(dx, dy)


# def gesture(paths: List[Path], listener=None):
#     py_paths = []
#     for p in paths:
#         py_paths.append(p.mpath)
#
#     asgesture.perform(py_paths, listener)

def gesture(paths: Union[Path, List[Path]], listener=None):
    """执行手势操作

    支持单路径或多路径（多指）手势，通过 Path 对象定义手势轨迹。

    Args:
        paths: 单个 Path 对象或 Path 对象列表，定义手势的运动轨迹。
        listener: 手势执行监听器，用于监听手势执行状态，默认为 None。

    Returns:
        无返回值。
    """
    # 统一处理输入，确保 paths 是列表类型
    if isinstance(paths, Path):
        paths = [paths]

    # 提取所有 Path 对象的 mpath 属性
    py_paths = [p.mpath for p in paths]

    # 调用底层接口
    asgesture.perform(py_paths, listener)


def catch_click(msg: str = None, shine: bool = True):
    """捕获式点击

    在屏幕上显示提示信息，等待用户手动点击并返回点击坐标。

    Args:
        msg: 提示信息文本，默认为 None。
        shine: 是否高亮显示点击位置，默认为 True。

    Returns:
        用户点击的坐标信息。
    """
    asc = asCatch()
    asc.shine(shine)
    asc.msg(msg)
    return asc.click()


class Ime:
    """输入法引擎类

    提供通过输入法引擎进行文本输入和按键模拟的功能。
    """

    @staticmethod
    def is_active():
        """检查输入法是否处于激活状态

        Returns:
            bool: 输入法是否已激活。
        """
        return asIME.is_active()

    @staticmethod
    def input(info: str):
        """通过输入法输入文本

        Args:
            info: 要输入的文本内容。

        Returns:
            无返回值。
        """
        asIME.input(info)

    @staticmethod
    def input_clear():
        """清除输入法中的文本内容

        Returns:
            无返回值。
        """
        asIME.input("")

    @staticmethod
    def keys(keys: Union[int, list], duration: int = 20):
        """通过输入法模拟按键

        Args:
            keys: 按键码，可以是单个整数或整数列表。
            duration: 按键持续时间，单位为毫秒，默认 20。

        Returns:
            无返回值。
        """
        if type(keys) is int:
            keys = [keys]
        asIME.keys(keys, duration)

    @staticmethod
    def enter():
        """模拟按下回车键

        Returns:
            无返回值。
        """
        Ime.keys(66)


# --- 常量 ---
TARGET_FRAME_RATE = 60.0  # 目标帧率
# 使用浮点数表示 TARGET_STEP_MS 以避免早期潜在的整数除法问题
TARGET_STEP_MS = 1000.0 / TARGET_FRAME_RATE  # 目标步长时间（毫秒）


# --- 超级滑动 ---
def simulate_interpolated_swipe_smooth(
        start_x: float, start_y: float,
        end_x: float, end_y: float,
        total_duration_ms: int,
        interpolator=None, ):  # 类型提示：可以是 Interpolator 或 None

    """
    模拟从起点到终点坐标的触摸滑动，持续给定时间，
    使用插值器控制速度，并自动计算步数以保证平滑。

    参数:
        interpolator: 一个拥有 get_interpolation(float) 方法的对象，
                      或者为 None 时使用 LinearInterpolator。
        start_x: 起始 X 坐标。
        start_y: 起始 Y 坐标。
        end_x: 结束 X 坐标。
        end_y: 结束 Y 坐标。
        total_duration_ms: 滑动的总持续时间（毫秒）。
    """
    if interpolator is None:
        interpolator = LinearInterpolator()
        print("插值器为 None，使用线性插值器 (LinearInterpolator)。")

    # 处理总持续时间为零或负数的情况
    if total_duration_ms <= 0:
        print("总持续时间为零或负数。执行瞬时移动。")
        Touch.down(start_x, start_y)
        Touch.move(end_x, end_y, 0)  # 瞬时移动到终点
        Touch.up(end_x, end_y)
        return

    Touch.down(start_x, start_y)

    delta_x = end_x - start_x
    delta_y = end_y - start_y

    # 计算所需的总步数（间隔数）
    # 即使持续时间很短，也确保至少有 1 步
    # 使用 math.ceil 向上取整，然后转为 int
    num_intervals = max(1, int(math.ceil(total_duration_ms / TARGET_STEP_MS)))
    print(f"为 {total_duration_ms} ms 的持续时间计算出的间隔数: {num_intervals}")

    time_elapsed: int = 0  # 跟踪已模拟的时间（毫秒）

    # 循环执行每个移动步骤
    for i in range(1, num_intervals + 1):  # range(1, N+1) 会产生 1, 2, ..., N
        # 1. 计算此步骤结束时对应的归一化时间
        #    使用浮点数除法
        normalized_time = float(i) / num_intervals

        # 2. 计算此步骤结束时对应的理论总时间点
        #    四舍五入到最近的毫秒
        target_time_ms = round(normalized_time * total_duration_ms)

        # 3. 使用归一化时间获取插值进度
        interpolated_fraction = interpolator.get_interpolation(normalized_time)
        #    为了安全，将插值结果限制在 [0, 1] 范围内（以防某些插值器如 Overshoot 超出）
        interpolated_fraction = max(0.0, min(interpolated_fraction, 1.0))

        # 4. 计算此步骤的目标坐标
        target_x = start_x + interpolated_fraction * delta_x
        target_y = start_y + interpolated_fraction * delta_y

        # 5. 计算这个具体步骤（段）需要持续的时间
        segment_duration = target_time_ms - time_elapsed
        #    确保持续时间不为负（理论上不应发生，但以防万一）
        segment_duration = max(0, segment_duration)

        # 6. 如果时间或位置有变化，则执行 Touch.move
        #    避免在 segment_duration 为 0 且位置未变时的无效调用
        if segment_duration > 0 or target_x != Touch.get_current_x() or target_y != Touch.get_current_y():
            Touch.move(target_x, target_y, segment_duration)

        # 7. 更新已消耗的总时间
        time_elapsed = target_time_ms

    # 最终调整：确保最终位置精确在终点
    # 并处理因四舍五入可能产生的微小剩余时间。
    remaining_time = total_duration_ms - time_elapsed
    # 检查是否尚未到达终点，或者理论上还有剩余时间
    if remaining_time > 0 or Touch.get_current_x() != end_x or Touch.get_current_y() != end_y:
        final_move_duration = max(0, remaining_time)  # 最终移动时间至少为0
        print(f"最终调整移动：剩余时间 {final_move_duration} ms, 目标 ({end_x:.1f}, {end_y:.1f})")
        Touch.move(end_x, end_y, final_move_duration)

    Touch.up(end_x, end_y)  # 在最终目的地抬起手指
