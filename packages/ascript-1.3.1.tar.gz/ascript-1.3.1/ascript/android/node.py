import json
from typing import List, Iterable, Union
from airscript.node import Selector as asSelector
from airscript.node import Node as asNode
from ascript.android.ui import WebWindow
from airscript.node import WebSelector as ASWebSelector
import copy


class Node:
    """Android 界面节点封装类，用于表示和操作 UI 控件树中的单个节点。"""

    def __init__(self, node=None):
        """初始化节点对象，从底层节点复制所有属性。

        Args:
            node: 底层 airscript 原始节点对象，包含控件的所有属性信息。
        """
        super().__init__()
        self._node = node
        self.id = node.id
        self.text = node.getSafeText()
        self.type = node.type
        self.desc = node.desc
        self.hintText = node.hintText
        self.packageName = node.packageName
        self.path = node.path
        self.rect = node.rect
        self.childCount = node.childCount
        self.inputType = node.inputType
        self.maxTextLength = node.maxTextLength
        self.drawingOrder = node.drawingOrder
        self.depth = node.depth
        self.clickable = node.clickable
        self.checkable = node.checkable
        self.checked = node.checked
        self.editable = node.editable
        self.enabled = node.enabled
        self.visible = node.visible
        self.dismissable = node.dismissable
        self.focusable = node.focusable
        self.focused = node.focused
        self.heading = node.heading
        self.longClickable = node.longClickable
        self.center_x = node.center_x
        self.center_y = node.center_y

    def __dict__(self):
        """将节点属性转换为字典格式。

        Returns:
            dict: 包含节点所有属性的字典。
        """
        return {
            'id': self.id,
            'text': self.text,
            'type': self.type,
            'desc': self.desc,
            'hintText': self.hintText,
            'packageName': self.packageName,
            'path': self.path,
            'rect': self.rect,
            'childCount': self.childCount,
            'inputType': self.inputType,
            'maxTextLength': self.maxTextLength,
            'drawingOrder': self.drawingOrder,
            'depth': self.depth,
            'clickable': self.clickable,
            'checkable': self.checkable,
            'checked': self.checked,
            'editable': self.editable,
            'enabled': self.enabled,
            'visible': self.visible,
            'dismissable': self.dismissable,
            'focusable': self.focusable,
            'focused': self.focused,
            'longClickable': self.longClickable,
            'center_x': self.center_x,
            'center_y': self.center_y,
        }

    def find(self, selector):
        """在当前节点的子树中查找第一个匹配选择器的节点。

        Args:
            selector: Selector 选择器对象，用于指定查找条件。

        Returns:
            Node: 匹配的第一个节点，未找到则返回 None。
        """
        res = self.find_all(selector)
        if res and len(res) > 0:
            return res[0]
        return None

    def find_all(self, selector):
        """在当前节点的子树中查找所有匹配选择器的节点。

        Args:
            selector: Selector 选择器对象，用于指定查找条件。

        Returns:
            list[Node]: 匹配的节点列表。
        """
        nodes = self._node.find_all(selector.sel)
        res = []
        for n in nodes:
            res.append(Node(n))
        return res

    def __change(self, anode):
        """将底层节点对象转换为 Node 封装对象。

        Args:
            anode: 底层节点对象，可以是单个节点或可迭代的节点集合。

        Returns:
            Node 或 list[Node]: 如果输入是单个节点返回 Node，如果是集合返回 Node 列表，
            输入为 None 时返回 None。
        """
        if not anode:
            return None

        # print(type(type(anode)))
        if isinstance(anode, Iterable):
            res = []
            for n in anode:
                res.append(Node(n))
            return res
        else:
            return Node(anode)

    def parent(self, *val: float):
        """获取当前节点的父节点。

        Args:
            *val: 可选的层级参数，指定向上查找的层数。

        Returns:
            Node 或 list[Node]: 父节点对象。
        """
        return self.__change(self._node.parent(*val))

    def child(self, *val: float):
        """获取当前节点的子节点。

        Args:
            *val: 可选的索引参数，指定要获取的子节点位置。

        Returns:
            Node 或 list[Node]: 子节点对象。
        """
        return self.__change(self._node.child(*val))

    def brother(self, *val: float):
        """获取当前节点的兄弟节点。

        Args:
            *val: 可选的偏移参数，指定兄弟节点的相对位置。

        Returns:
            Node 或 list[Node]: 兄弟节点对象。
        """
        return self.__change(self._node.brother(*val))

    def click(self):
        """点击当前节点。

        Returns:
            Node: 当前节点对象（支持链式调用）。
        """
        self._node.click()
        return self

    def long_click(self):
        """长按当前节点。

        Returns:
            Node: 当前节点对象（支持链式调用）。
        """
        self._node.long_click()
        return self

    def swipe(self, ore: int = -1):
        """在当前节点上执行滑动操作。

        Args:
            ore: 滑动方向，默认为 -1。

        Returns:
            Node: 当前节点对象（支持链式调用）。
        """
        self._node.slide(ore)
        return self

    def slide(self, ore: int = -1):
        """在当前节点上执行滑动操作（与 swipe 功能相同）。

        Args:
            ore: 滑动方向，默认为 -1。

        Returns:
            Node: 当前节点对象（支持链式调用）。
        """
        self._node.slide(ore)
        return self

    def input(self, msg: str = ""):
        """向当前节点输入文本内容。

        Args:
            msg: 要输入的文本内容，默认为空字符串。

        Returns:
            Node: 当前节点对象（支持链式调用）。
        """
        self._node.input(msg)
        return self

    def __str__(self):
        """将节点对象转换为字符串表示。

        Returns:
            str: 节点属性的字典字符串表示。
        """
        return str(self.__dict__())


class Selector:
    """Android 节点选择器，用于通过属性条件查找 UI 控件节点。

    支持链式调用设置多个筛选条件，最终通过 find/find_all 执行查找。

    Attributes:
        MODE_ACC_SIMPLE: 简易无障碍模式。
        MODE_ACC_ALL: 完整无障碍模式。
        MODE_ASS: 辅助服务模式。
        MODE_ROOT: Root 模式。
    """

    MODE_ACC_SIMPLE = 0
    MODE_ACC_ALL = 1
    MODE_ASS = asSelector.MODE_ASS
    MODE_ROOT = asSelector.MODE_ROOT

    def __init__(self, mode: int = 0, xpath: str = None):
        """初始化选择器。

        Args:
            mode: 查找模式，0=简易无障碍, 1=完整无障碍, 可使用 MODE_ASS/MODE_ROOT 常量。
            xpath: 可选的 XPath 表达式，用于 XPath 方式查找节点。
        """
        super().__init__()
        self.sel = asSelector(mode)
        self.sel.xpath = xpath

    def find(self) -> Node:
        """查找第一个匹配当前选择条件的节点。

        Returns:
            Node: 匹配的第一个节点，未找到则返回 None。
        """
        res = self.find_all(1)
        if res and len(res) > 0:
            return res[0]
        return None

    def find_by_text(self, text: str):
        """通过文本内容快速查找节点。

        Args:
            text: 要匹配的文本内容。

        Returns:
            查找到的节点结果。
        """
        return self.sel.find_quick(text, 1)

    def find_by_id(self, id: str):
        """通过资源 ID 快速查找节点。

        Args:
            id: 要匹配的资源 ID。

        Returns:
            查找到的节点结果。
        """
        return self.sel.find_quick(id, 2)

    @staticmethod
    def cache(is_cache: bool, mode: int = 0):
        """设置节点树缓存开关。

        Args:
            is_cache: 是否启用缓存，True 为启用。
            mode: 查找模式，默认为 0。
        """
        asSelector.cache(is_cache,mode)

    @staticmethod
    def on_event(listener):
        """注册节点事件监听器。

        Args:
            listener: 事件回调函数。
        """
        asSelector.on_event(listener)

    @staticmethod
    def dump(mode: int = 0):
        """导出当前界面的节点树信息。

        Args:
            mode: 查找模式，默认为 0。

        Returns:
            当前界面的节点树数据。
        """
        return asSelector.dump(mode)

    @staticmethod
    def refresh(mode: int = 0):
        """刷新节点树缓存。

        Args:
            mode: 查找模式，默认为 0。
        """
        asSelector(mode).refresh()

    def find_all(self, num: int = 99999) -> List[Node]:
        """查找所有匹配当前选择条件的节点。

        Args:
            num: 最大返回数量，默认为 99999。

        Returns:
            list[Node]: 匹配的节点列表，未找到则返回 None。
        """
        nodes = self.sel.find_all(num)
        res = []
        if nodes:
            for n in nodes:
                res.append(Node(n))

        if len(res) > 0:
            return res

        return None

    def id(self, val: str):
        """设置资源 ID 筛选条件。

        Args:
            val: 要匹配的资源 ID 字符串。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        if val is None:
            return self
        self.sel.id(val)
        return self

    def text(self, val: str):
        """设置文本内容筛选条件。

        Args:
            val: 要匹配的文本内容。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        if val is None:
            return self
        self.sel.text(val)
        return self

    def type(self, val: str):
        """设置控件类型筛选条件。

        Args:
            val: 要匹配的控件类型名称。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        if val is None:
            return self
        self.sel.type(val)
        return self

    def desc(self, val: str):
        """设置内容描述筛选条件。

        Args:
            val: 要匹配的内容描述文本。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        if val is None:
            return self
        self.sel.desc(val)
        return self

    def hintText(self, val: str):
        """设置提示文本筛选条件。

        Args:
            val: 要匹配的提示文本。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        if val is None:
            return self
        self.sel.hintText(val)
        return self

    def packageName(self, val: str):
        """设置包名筛选条件。

        Args:
            val: 要匹配的应用包名。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        if val is None:
            return self
        self.sel.packageName(val)
        return self

    def path(self, val: str):
        """设置节点路径筛选条件。

        Args:
            val: 要匹配的节点路径。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        if val is None:
            return self
        self.sel.path(val)
        return self

    def childCount(self, *val: int):
        """设置子节点数量筛选条件。

        Args:
            *val: 子节点数量条件值。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        if val is None:
            return self
        self.sel.childCount(*val)
        return self

    def inputType(self, val: int):
        """设置输入类型筛选条件。

        Args:
            val: 要匹配的输入类型值。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        if val is None:
            return self
        self.sel.inputType(val)
        return self

    def drawingOrder(self, val: int):
        """设置绘制顺序筛选条件。

        Args:
            val: 要匹配的绘制顺序值。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        if val is None:
            return self
        self.sel.drawingOrder(val)
        return self

    def depth(self, val: int):
        """设置节点深度筛选条件。

        Args:
            val: 要匹配的节点深度值。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        if val is None:
            return self
        self.sel.depth(val)
        return self

    def maxTextLength(self, val: int):
        """设置最大文本长度筛选条件。

        Args:
            val: 要匹配的最大文本长度。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        if val is None:
            return self
        self.sel.maxTextLength(val)
        return self

    def clickable(self, val: bool):
        """设置可点击属性筛选条件。

        Args:
            val: 是否可点击。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        if val is None:
            return self
        self.sel.clickable(val)
        return self

    def checkable(self, val: bool):
        """设置可勾选属性筛选条件。

        Args:
            val: 是否可勾选。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        if val is None:
            return self
        self.sel.checkable(val)
        return self

    def checked(self, val: bool):
        """设置已勾选状态筛选条件。

        Args:
            val: 是否已勾选。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        if val is None:
            return self
        self.sel.checked(val)
        return self

    def editable(self, val: bool):
        """设置可编辑属性筛选条件。

        Args:
            val: 是否可编辑。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        if val is None:
            return self
        self.sel.editable(val)
        return self

    def enabled(self, val: bool):
        """设置启用状态筛选条件。

        Args:
            val: 是否启用。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        if val is None:
            return self
        self.sel.enabled(val)
        return self

    def dismissable(self, val: bool):
        """设置可关闭属性筛选条件。

        Args:
            val: 是否可关闭。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        if val is None:
            return self
        self.sel.dismissable(val)
        return self

    def focusable(self, val: bool):
        """设置可聚焦属性筛选条件。

        Args:
            val: 是否可聚焦。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        if val is None:
            return self
        self.sel.focusable(val)
        return self

    def focused(self, val: bool):
        """设置已聚焦状态筛选条件。

        Args:
            val: 是否已聚焦。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        if val is None:
            return self
        self.sel.focused(val)
        return self

    def visible(self, val: bool):
        """设置可见性筛选条件。

        Args:
            val: 是否可见。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        if val is None:
            return self
        self.sel.visible(val)
        return self

    def longClickable(self, val: bool):
        """设置可长按属性筛选条件。

        Args:
            val: 是否可长按。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        if val is None:
            return self
        self.sel.longClickable(val)
        return self

    def parent(self, *val: float):
        """设置父节点关系筛选条件。

        Args:
            *val: 父节点层级参数。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        if val is None:
            return self
        self.sel.parent(*val)
        return self

    def child(self, *val: float):
        """设置子节点关系筛选条件。

        Args:
            *val: 子节点索引参数。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        if val is None:
            return self
        self.sel.child(*val)
        return self

    def brother(self, *val: float):
        """设置兄弟节点关系筛选条件。

        Args:
            *val: 兄弟节点偏移参数。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        if val is None:
            return self
        self.sel.brother(*val)
        return self

    def click(self):
        """对匹配的节点执行点击操作。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        self.sel.click()
        return self

    def long_click(self):
        """对匹配的节点执行长按操作。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        self.sel.long_click()
        return self

    def swipe(self, ore: int = -1):
        """对匹配的节点执行滑动操作。

        Args:
            ore: 滑动方向，默认为 -1。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        self.sel.slide(ore)
        return self

    def slide(self, ore: int = -1):
        """对匹配的节点执行滑动操作（与 swipe 功能相同）。

        Args:
            ore: 滑动方向，默认为 -1。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        self.sel.slide(ore)
        return self

    def input(self, msg: str = ""):
        """向匹配的节点输入文本内容。

        Args:
            msg: 要输入的文本内容，默认为空字符串。

        Returns:
            Selector: 当前选择器对象（支持链式调用）。
        """
        self.sel.input(msg)
        return self


class WebSelector:
    """Web 页面节点选择器，用于在 WebView 中查找和操作 DOM 元素。

    支持链式调用设置多个筛选条件，最终通过 find/find_all 执行查找。
    """

    def __init__(self, web_window: Union[WebWindow, str] = None):
        """初始化 Web 选择器。

        Args:
            web_window: WebWindow 对象或 HTML 字符串。如果传入字符串，会自动创建 WebWindow。
        """
        if web_window:
            if type(web_window) == str:
                self.window = WebWindow(web_window).window
            else:
                self.window = web_window.window

            self.as_webselector = ASWebSelector(self.window)

    def copy(self):
        """深拷贝当前选择器，生成一个独立的副本。

        Returns:
            WebSelector: 当前选择器的深拷贝副本。
        """
        new_obj = WebSelector()
        new_obj.window = self.window
        new_obj.as_webselector = ASWebSelector(self.window)
        new_obj.as_webselector.setSels(self.as_webselector.deepCopySels())
        return new_obj

    def text(self, val: str):
        """设置文本内容筛选条件。

        Args:
            val: 要匹配的文本内容。

        Returns:
            WebSelector: 当前选择器对象（支持链式调用）。
        """
        self.as_webselector.text(val)
        return self

    def tag(self, val: str):
        """设置 HTML 标签名筛选条件。

        Args:
            val: 要匹配的标签名（如 "div", "span" 等）。

        Returns:
            WebSelector: 当前选择器对象（支持链式调用）。
        """
        self.as_webselector.tag(val)
        return self

    def attr(self, key: str, val: str):
        """设置 HTML 属性筛选条件。

        Args:
            key: 属性名称（如 "class", "id" 等）。
            val: 属性值。

        Returns:
            WebSelector: 当前选择器对象（支持链式调用）。
        """
        self.as_webselector.attr(key, val)
        return self

    def value(self, val: str):
        """设置元素 value 属性筛选条件。

        Args:
            val: 要匹配的 value 值。

        Returns:
            WebSelector: 当前选择器对象（支持链式调用）。
        """
        self.as_webselector.value(val)
        return self

    def child(self, *val: int):
        """设置子元素关系筛选条件。

        Args:
            *val: 子元素索引参数。

        Returns:
            WebSelector: 当前选择器对象（支持链式调用）。
        """
        self.as_webselector.child(val)
        return self

    def brother(self, *val: int):
        """设置兄弟元素关系筛选条件。

        Args:
            *val: 兄弟元素偏移参数。

        Returns:
            WebSelector: 当前选择器对象（支持链式调用）。
        """
        self.as_webselector.brother(val)
        return self

    def parent(self, *val: int):
        """设置父元素关系筛选条件。

        Args:
            *val: 父元素层级参数。

        Returns:
            WebSelector: 当前选择器对象（支持链式调用）。
        """
        self.as_webselector.parent(val)
        return self

    def click(self):
        """对匹配的元素执行点击操作。

        Returns:
            WebSelector: 当前选择器对象（支持链式调用）。
        """
        self.as_webselector.click()
        return self

    def long_click(self):
        """对匹配的元素执行长按操作。

        Returns:
            WebSelector: 当前选择器对象（支持链式调用）。
        """
        self.as_webselector.longClick()
        return self

    def input(self, val: str):
        """向匹配的元素输入文本内容。

        Args:
            val: 要输入的文本内容。

        Returns:
            WebSelector: 当前选择器对象（支持链式调用）。
        """
        self.as_webselector.input(val)
        return self

    def find_all(self, find_num: int = 0):
        """查找所有匹配当前选择条件的 Web 节点。

        Args:
            find_num: 最大返回数量，0 表示不限制。

        Returns:
            list[WebNode]: 匹配的 WebNode 列表。
        """
        self.as_webselector.setFindNum(find_num)
        return WebNode.json_to_node(self.as_webselector.find_all(), self)

    def find(self):
        """查找第一个匹配当前选择条件的 Web 节点。

        Returns:
            WebNode: 匹配的第一个节点，未找到则返回 None。
        """
        res = self.find_all(1)
        if res and len(res) > 0:
            return res[0]

        return None


class WebNode:
    """Web 页面节点对象，表示 WebView 中的单个 DOM 元素。"""

    def __init__(self, selector: WebSelector):
        """初始化 Web 节点对象。

        Args:
            selector: 产生此节点的 WebSelector 选择器对象，用于后续操作。
        """
        self.sel = selector
        self.tag_name = None
        self.bounds = None
        self.text = None
        self.value = None
        self.attributes = []

    def click(self):
        """点击当前 Web 节点元素。"""
        temp_sel = self.sel.copy()
        temp_sel.click()
        temp_sel.find()

    def long_click(self):
        """长按当前 Web 节点元素。"""
        temp_sel = copy.deepcopy(self.sel)
        temp_sel.long_click()
        temp_sel.find()

    def input(self, val: str):
        """向当前 Web 节点元素输入文本。

        Args:
            val: 要输入的文本内容。
        """
        temp_sel = copy.deepcopy(self.sel)
        temp_sel.input(val)
        temp_sel.find()

    def child(self, *val: int):
        """获取当前 Web 节点的子元素。

        Args:
            *val: 子元素索引参数。

        Returns:
            WebNode: 子元素节点，未找到则返回 None。
        """
        temp_sel = copy.deepcopy(self.sel)
        temp_sel.child(val)
        return temp_sel.find()

    def brother(self, *val: int):
        """获取当前 Web 节点的兄弟元素。

        Args:
            *val: 兄弟元素偏移参数。

        Returns:
            WebNode: 兄弟元素节点，未找到则返回 None。
        """
        temp_sel = copy.deepcopy(self.sel)
        temp_sel.brother(val)
        return temp_sel.find()

    def parent(self, *val: int):
        """获取当前 Web 节点的父元素。

        Args:
            *val: 父元素层级参数。

        Returns:
            WebNode: 父元素节点，未找到则返回 None。
        """
        temp_sel = copy.deepcopy(self.sel)
        temp_sel.parent(val)
        return temp_sel.find()

    @staticmethod
    def json_to_node(json_data, selector: WebSelector):
        """将 JSON 数据解析为 WebNode 对象列表。

        Args:
            json_data: JSON 格式的节点数据字符串。
            selector: 关联的 WebSelector 选择器对象。

        Returns:
            list[WebNode]: 解析后的 WebNode 对象列表。
        """
        objs = json.loads(json_data)
        res = []
        if objs and len(objs) > 0:
            for obj in objs:
                web_node = WebNode(selector)
                web_node.text = obj["text"]
                web_node.value = obj["value"]
                web_node.attributes = obj["attributes"]
                web_node.tag_name = obj["tagName"]
                web_node.bounds = obj["bounds"]
                res.append(web_node)

        return res

    def to_dict(self):
        """将对象转换为字典格式"""
        return {
            "tag_name": self.tag_name,
            "bounds": self.bounds,
            "text": self.text,
            "value": self.value,
            "attributes": self.attributes,
            "selector": str(self.sel) if self.sel else None
        }

    def __str__(self):
        """以 JSON 形式输出对象"""
        return json.dumps(self.to_dict())
