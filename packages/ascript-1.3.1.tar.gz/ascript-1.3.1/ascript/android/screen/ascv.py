import os

import cv2
import numpy as np
from typing import Union


def find_all_sift():
    """基于 SIFT 特征匹配查找所有匹配图像（未实现）

    Returns:
        None
    """
    pass


def find_all_template_cvimg(image_source, image_search: Union[np.ndarray, list], rect: list = None, threshold=0.5,
                            rgb=False,
                            maxcnt=0):
    """使用模板匹配在主图中查找所有匹配的子图（CV 图像输入版本）

    对已加载为 numpy 数组的图像执行模板匹配，支持灰度和 HSV 色彩空间匹配。

    Args:
        image_source: 主图的 numpy 数组（BGR 格式）。
        image_search: 待搜索的子图 numpy 数组或子图数组列表。
        rect: 搜索区域 [left, top, right, bottom]，用于坐标偏移，默认为 None。
        threshold: 匹配置信度阈值，范围 0-1，默认 0.5。
        rgb: 是否使用 RGB/HSV 色彩空间匹配，False 则使用灰度匹配，默认 False。
        maxcnt: 最大返回匹配数量，0 表示不限制，默认 0。

    Returns:
        list[dict]: 匹配结果列表，每个结果包含 result（中心点）、rectangle（四角坐标）、
            rect（边界矩形）、center_x、center_y、confidence 等字段。
            当输入为 None 时返回 None。
    """
    if image_search is None or image_source is None:
        return None
    # 处理主图 颜色通道
    if not rgb:
        image_source = cv2.cvtColor(image_source, cv2.COLOR_BGR2GRAY)
    else:
        image_source = cv2.cvtColor(image_source, cv2.COLOR_BGR2HSV)
        source_h, source_s, source_v = cv2.split(image_source)
        image_hs = cv2.merge([source_h, source_s])

    # 处理主图 的范围大小
    source_height, source_width = image_source.shape[:2]

    x, y = [0, 0]
    if rect:
        # 这里只做坐标偏移
        x, y, r, b = rect

    image_search_list = []
    if isinstance(image_search, list):
        image_search_list = image_search

    else:
        image_search_list.append(image_search)

    result = []
    method = cv2.TM_CCOEFF_NORMED
    for image_cv in image_search_list:
        res = None
        # print("stp 1")
        # if not os.path.isfile(image_search_path):
        #     raise RuntimeError(f"文件不存在{image_search_path}")
        w, h = image_cv.shape[1], image_cv.shape[0]
        if not rgb:
            # image_search = cv2.imread(image_search_path, cv2.IMREAD_GRAYSCALE)
            # w, h = image_search.shape[1], image_search.shape[0]
            image_cv = cv2.cvtColor(image_cv, cv2.COLOR_BGR2GRAY)
            if source_width > w and source_height > h:
                res = cv2.matchTemplate(image_source, image_cv, method)
        else:
            # 分别计算3通道的rgb值
            # image_search = cv2.imread(image_search_path)
            search_hsv = cv2.cvtColor(image_cv, cv2.COLOR_BGR2HSV)
            search_h, search_s, search_v = cv2.split(search_hsv)
            search_hs = cv2.merge([search_h, search_s])
            if source_width > w and source_height > h:
                res = cv2.matchTemplate(image_hs, search_hs, cv2.TM_CCOEFF_NORMED)
            # res = resbgr[2]

        # print("stp 2")

        while True and res is not None:
            min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
            if method in [cv2.TM_SQDIFF, cv2.TM_SQDIFF_NORMED]:
                top_left = min_loc
            else:
                top_left = max_loc
            if max_val < threshold:
                break

            # calculator middle point
            # 把 范围 x,y 偏移加进去
            top_left = [a + b for a, b in zip(max_loc, [x, y])]
            middle_point = (top_left[0] + w / 2, top_left[1] + h / 2)
            result.append(dict(
                result=middle_point,
                rectangle=(top_left, (top_left[0], top_left[1] + h), (top_left[0] + w, top_left[1]),
                           (top_left[0] + w, top_left[1] + h)),
                rect=[top_left[0], top_left[1], top_left[0] + w, top_left[1] + h],
                center_x=int(middle_point[0]),
                center_y=int(middle_point[1]),
                confidence=max_val
            ))
            if maxcnt and len(result) >= maxcnt:
                break
            # floodfill the already found area
            cv2.floodFill(res, None, max_loc, (-1000,), max_val - threshold + 0.1, 1, flags=cv2.FLOODFILL_FIXED_RANGE)

        # print("stp 3")
    return result


def find_all_template(image_source, image_search: Union[str, list], rect: list = None, threshold=0.5, rgb=False,
                      maxcnt=0, bgremove=False):
    """使用模板匹配在主图中查找所有匹配的子图（文件路径输入版本）

    从文件路径加载子图并执行模板匹配，支持灰度和 HSV 色彩空间匹配。
    使用区域置零替代 floodFill 来屏蔽已匹配区域，提高性能。

    Args:
        image_source: 主图的 numpy 数组（BGR 格式）。
        image_search: 待搜索子图的文件路径或路径列表。
        rect: 搜索区域 [left, top, right, bottom]，用于坐标偏移，默认为 None。
        threshold: 匹配置信度阈值，范围 0-1，默认 0.5。
        rgb: 是否使用 RGB/HSV 色彩空间匹配，False 则使用灰度匹配，默认 False。
        maxcnt: 最大返回匹配数量，0 表示不限制，默认 0。
        bgremove: 是否移除背景（预留参数），默认 False。

    Returns:
        list[dict]: 匹配结果列表，每个结果包含 result（中心点）、rectangle（四角坐标）、
            rect（边界矩形）、center_x、center_y、confidence、index 等字段。
            当输入为 None 时返回 None。

    Raises:
        RuntimeError: 当指定的子图文件不存在时抛出。
    """
    if image_search is None or image_source is None:
        return None
    # 处理主图 颜色通道
    if not rgb:
        image_source = cv2.cvtColor(image_source, cv2.COLOR_BGR2GRAY)
    else:
        image_source = cv2.cvtColor(image_source, cv2.COLOR_BGR2HSV)
        source_h, source_s, source_v = cv2.split(image_source)
        image_hs = cv2.merge([source_h, source_s])
        # 处理主图 的范围大小

    source_height, source_width = image_source.shape[:2]

    x, y = [0, 0]
    if rect:
        # 这里只做坐标偏移
        x, y, r, b = rect

    image_search_list = []
    if isinstance(image_search, list):
        image_search_list = image_search
    else:
        image_search_list.append(image_search)
    result = []
    method = cv2.TM_CCOEFF_NORMED
    for index, image_search_path in enumerate(image_search_list):

        res = None

        if not os.path.isfile(image_search_path):
            raise RuntimeError(f"文件不存在{image_search_path}")

        if not rgb:
            image_search = cv2.imread(image_search_path, cv2.IMREAD_GRAYSCALE)
            w, h = image_search.shape[1], image_search.shape[0]
            if source_width > w and source_height > h:
                res = cv2.matchTemplate(image_source, image_search, method)
        else:
            # 分别计算3通道的rgb值
            image_search = cv2.imread(image_search_path)
            w, h = image_search.shape[1], image_search.shape[0]
            search_hsv = cv2.cvtColor(image_search, cv2.COLOR_BGR2HSV)
            search_h, search_s, search_v = cv2.split(search_hsv)
            search_hs = cv2.merge([search_h, search_s])
            if source_width > w and source_height > h:
                res = cv2.matchTemplate(image_hs, search_hs, cv2.TM_CCOEFF_NORMED)
            # res = resbgr[2]

        # print(res)

        while True and res is not None:
            min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
            if method in [cv2.TM_SQDIFF, cv2.TM_SQDIFF_NORMED]:
                top_left = min_loc
            else:
                top_left = max_loc
            if max_val < threshold:
                break

            # calculator middle point
            # 把 范围 x,y 偏移加进去
            top_left = [a + b for a, b in zip(max_loc, [x, y])]
            middle_point = (top_left[0] + w / 2, top_left[1] + h / 2)
            result.append(dict(
                result=middle_point,
                rectangle=(top_left, (top_left[0], top_left[1] + h), (top_left[0] + w, top_left[1]),
                           (top_left[0] + w, top_left[1] + h)),
                rect=[top_left[0], top_left[1], top_left[0] + w, top_left[1] + h],
                center_x=int(middle_point[0]),
                center_y=int(middle_point[1]),
                confidence=max_val,
                index=index
            ))
            if maxcnt and len(result) >= maxcnt:
                break
            # floodfill the already found area
            # 快速屏蔽已匹配区域（NMS替代floodFill）
            y_start = max(0, max_loc[1] - h // 2)
            y_end = min(res.shape[0], max_loc[1] + h // 2)
            x_start = max(0, max_loc[0] - w // 2)
            x_end = min(res.shape[1], max_loc[0] + w // 2)
            res[y_start:y_end, x_start:x_end] = 0  # 直接置零区域
    return result


surf = None
# 缓存 FLANN 匹配器，避免每次 find_surf 都重新创建（省 ~2MB + 初始化耗时）
_flann_matcher = None


def find_surf(image_source, image_search: Union[str, list], threshold=0.5, off_rect: list = None, rgb: bool = False,
              maxcnt: int = 0):
    """使用 SURF 特征匹配在主图中查找子图

    基于 SURF（加速稳健特征）算法进行图像匹配，支持尺度和旋转不变性。
    使用 FLANN 匹配器进行特征点匹配，并通过 RANSAC 计算单应性矩阵。

    Args:
        image_source: 主图的 numpy 数组（BGR 格式）。
        image_search: 待搜索子图的文件路径或路径列表。
        threshold: 匹配置信度阈值，范围 0-1，默认 0.5。
        off_rect: 坐标偏移区域 [left, top, right, bottom]，默认为 None。
        rgb: 是否使用彩色匹配，False 则使用灰度匹配，默认 False。
        maxcnt: 最大返回匹配数量，0 表示不限制，默认 0。

    Returns:
        list[dict]: 匹配结果列表，每个结果包含 result（中心点）、rectangle（四角坐标）、
            rect（边界矩形）、center_x、center_y、confidence 等字段。
            当输入为 None 时返回 None。

    Raises:
        RuntimeError: 当指定的子图文件不存在时抛出。
    """
    if image_search is None or image_source is None:
        return None

    # 读取图片
    try:
        if not rgb:
            image_source = cv2.cvtColor(image_source, cv2.COLOR_BGR2GRAY)
        # 初始化SURF检测器
        global surf
        if surf is None:
            surf = cv2.xfeatures2d.SURF_create()
    except Exception as e:
        return []

    result = []
    # maxcnt<=1 时不需要掩码（只找一个），省一次全图深拷贝
    mask_source = image_source if maxcnt == 1 else image_source.copy()

    image_search_list = []
    if isinstance(image_search, list):
        image_search_list = image_search
    else:
        image_search_list.append(image_search)

    for image_search_path in image_search_list:
        if not os.path.isfile(image_search_path):
            raise RuntimeError(f"文件不存在{image_search_path}")

        # raise RuntimeError(f"文件地址{image_search_path}")
        small_image = None
        if rgb:
            small_image = cv2.imread(image_search_path)
        else:
            small_image = cv2.imread(image_search_path, cv2.IMREAD_GRAYSCALE)

        while len(result) < maxcnt or maxcnt == 0:
            if small_image is None:
                break

            try:
                # 找到关键点和描述符
                keypoints_large, descriptors_large = surf.detectAndCompute(mask_source, None)
                keypoints_small, descriptors_small = surf.detectAndCompute(small_image, None)
                # 复用 FLANN 匹配器
                global _flann_matcher
                if _flann_matcher is None:
                    FLANN_INDEX_KDTREE = 1
                    index_params = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
                    search_params = dict(checks=50)
                    _flann_matcher = cv2.FlannBasedMatcher(index_params, search_params)
                flann = _flann_matcher

                if descriptors_large is None or descriptors_small is None:
                    break

                if descriptors_large.shape[0] < 2:
                    break

                matches = flann.knnMatch(descriptors_small, descriptors_large, k=2)
                # 应用比率测试
                good_matches = []
                for m, n in matches:
                    if m.distance < 0.8 * n.distance:
                        good_matches.append(m)

                # 如果有足够的匹配点，则计算仿射变换矩阵
                if len(good_matches) > 4:
                    src_pts = np.float32([keypoints_small[m.queryIdx].pt for m in good_matches]).reshape(-1, 1, 2)
                    dst_pts = np.float32([keypoints_large[m.trainIdx].pt for m in good_matches]).reshape(-1, 1, 2)

                    # 计算仿射变换矩阵
                    M, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 5.0)
                    matches_mask = mask.ravel().tolist()
                    confidence = min(1.0 * matches_mask.count(1) / 10, 1.0)

                    if confidence < threshold:
                        break

                    # 使用仿射变换矩阵找到小图在大图中的位置
                    height, width = small_image.shape
                    pts = np.float32([[0, 0], [0, height - 1], [width - 1, height - 1], [width - 1, 0]]).reshape(-1, 1,
                                                                                                                 2)
                    dst = cv2.perspectiveTransform(pts, M)

                    # 计算小图在大图中的位置
                    x, y, w, h = cv2.boundingRect(np.int0(dst))
                    # 增加掩膜
                    cv2.rectangle(mask_source, (x, y), (x + w, y + h), 255, -1)  # -1 表示填充整个矩形
                    if off_rect:
                        # print(off_rect, x, y, w, h)
                        x = x + off_rect[0]
                        y = y + off_rect[1]
                    middle_point = (x + w / 2, y + h / 2)
                    result.append(dict(
                        result=middle_point,
                        rectangle=[(x, y), (x, y + h), (x + w, y), (x + w, y + h)],
                        rect=[x, y, x + w, y + h],
                        center_x=int(middle_point[0]),
                        center_y=int(middle_point[1]),
                        confidence=confidence
                    ))

                    if len(result) > 20:
                        break
                else:
                    # 如果没有足够的匹配点，返回None
                    # print("-none")
                    break
            except RuntimeError:
                break

        del small_image

    del mask_source
    del image_source

    return result


def find_all_sift(image_source, image_search: Union[str, list], rect: list = None, threshold=0.5, rgb=False,
                  maxcnt=0, ):
    """使用 SIFT 特征匹配在主图中查找所有匹配的子图

    基于 SIFT（尺度不变特征变换）算法进行图像匹配。

    Args:
        image_source: 主图的 numpy 数组（BGR 格式）。
        image_search: 待搜索子图的文件路径或路径列表。
        rect: 搜索区域 [left, top, width, height]，默认为 None（全图搜索）。
        threshold: 匹配置信度阈值，范围 0-1，默认 0.5。
        rgb: 是否使用彩色匹配，False 则使用灰度匹配，默认 False。
        maxcnt: 最大返回匹配数量，0 表示不限制，默认 0。

    Returns:
        None: 当输入为 None 时返回 None。
    """
    if image_search is None or image_source is None:
        return None

    if not rgb:
        image_source = cv2.cvtColor(image_source, cv2.COLOR_BGR2GRAY)
        # 处理主图 的范围大小
    x, y = [0, 0]
    if rect:
        x, y, w, h = rect
        image_source = image_source[y:y + h, x:x + w]

    image_search_list = []
    if image_search is list:
        image_search_list = image_search
    else:
        image_search_list.append(image_search)

    for image_search_path in image_search_list:
        if not rgb:
            image_search = cv2.imread(image_search_path, cv2.IMREAD_GRAYSCALE)
        else:
            image_search = cv2.imread(image_search_path)

        pass


def compare_histograms(hist1, hist2, method=cv2.HISTCMP_CORREL):
    """比较两个图像的直方图相似度

    Args:
        hist1: 第一个图像的直方图。
        hist2: 第二个图像的直方图。
        method: OpenCV 直方图比较方法，默认为 cv2.HISTCMP_CORREL（相关性比较）。

    Returns:
        float: 两个直方图的相似度值，具体含义取决于所选比较方法。
    """
    return cv2.compareHist(hist1, hist2, method)


def calc_histogram(image, mask=None, channels=[0, 1, 2]):
    """计算图像的归一化直方图

    Args:
        image: 输入图像的 numpy 数组。
        mask: 掩膜图像，用于指定计算区域，默认为 None（全图）。
        channels: 要计算的通道列表，默认为 [0, 1, 2]（所有 BGR 通道）。

    Returns:
        numpy.ndarray: 归一化后的展平直方图数组。
    """
    # print(image.shape[2])
    hist = cv2.calcHist([image], channels, mask, [256, 256, 256], [0, 256, 0, 256, 0, 256])
    cv2.normalize(hist, hist, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)
    return hist.flatten()
