import json
import uuid
import cv2
import os
from ascript.android.system import R
import importlib
import sys

str_header = []
str_body = []
str_stack_name = "gp_stack"
gp_result = None


def loadfrom_json(json_str, c_img, gp_name):
    """从 JSON 配置生成并执行图像处理管线代码

    根据 JSON 格式的管线配置，自动生成 Python 代码文件并执行，
    将处理结果保存为图片文件。

    Args:
        json_str: JSON 格式的管线配置字符串，包含各处理步骤的参数。
        c_img: 输入图片的文件路径。
        gp_name: 生成的管线模块名称，用于代码文件的命名和模块导入。

    Returns:
        str: JSON 格式的结果字符串，包含 image（结果图片路径）、
            offset_x、offset_y、data 等字段。
    """
    job_data = json.loads(json_str)
    global str_header, str_body
    str_header = []
    str_body = []
    # cv_img = screen.bitmap_to_cvimage(c_img)

    str_header.append("from ascript.android.screen.gp import GPStack")
    str_header.append("import cv2")
    str_header.append("from ascript.android.system import R")
    str_header.append("from ascript.android import plug")
    str_body.append("def gp(cv_img=None):")
    # str_body.append(f"  cv_img = cv2.imread('{c_img}')")
    str_body.append(f"  {str_stack_name} = GPStack(cv_img)")

    # 组装job
    for gp in job_data:
        create_gpcode_with_dict(gp)

    str_body.append(f"  gp_result = {str_stack_name}.run()")
    str_body.append(f"  return gp_result")

    str_body.append(f"# 如需运行,取消以下代码注释")
    str_body.append(f"# res = gp()")
    str_body.append(f"# print(res.data)")

    final_code = '\n'.join(str(item) for item in str_header + str_body)
    print(final_code)
    # exec(final_code, globals())
    # 创建 init 文件,并写入数据.
    init_py_file = f"sdcard/airscript/gp/{gp_name}/__init__.py"

    if not os.path.exists(os.path.dirname(init_py_file)):
        os.makedirs(os.path.dirname(init_py_file))

    with open(init_py_file, 'w', encoding='utf-8') as file:
        file.write(final_code)

    cv_img = cv2.imread(c_img)
    gp_result = load_or_reload_module(gp_name).gp(cv_img)

    img_path = f"sdcard/airscript/screen/gp/{uuid.uuid4()}.jpg"
    # 提取目录部分
    directory = os.path.dirname(img_path)

    # 检查目录是否存在
    if not os.path.exists(directory):
        # 如果目录不存在，则创建它
        os.makedirs(directory)

    cv2.imwrite(img_path, gp_result.image)
    # print(gp_result.data)
    res = {"image": img_path, "offset_x": gp_result.offset_x, "offset_y": gp_result.offset_y, "data": gp_result.data}
    return json.dumps(res)
    # return res


def load(gpdir: str, cv_img=None):
    """从目录加载 GP 管线配置（预留接口）

    Args:
        gpdir: GP 管线配置目录路径。
        cv_img: 输入图像，默认为 None。

    Returns:
        无返回值。
    """
    gpdata_file = R.rel(gpdir, "data.gp")


def load_or_reload_module(module_name_str):
    """加载或重新加载 Python 模块

    如果模块已存在于 sys.modules 中则重新加载，否则首次导入。

    Args:
        module_name_str: 模块的完整名称字符串（如 "ascript.android.screen.gp_tasks"）。

    Returns:
        module: 加载或重新加载后的模块对象。
    """
    try:
        # 尝试从sys.modules中获取模块对象
        module = sys.modules[module_name_str]
        # 如果模块已经存在，则重新加载它
        print(f"Module {module_name_str} already loaded. Reloading...")
        module = importlib.reload(module)
    except KeyError:
        # 如果模块不存在，则导入它
        print(f"Module {module_name_str} not loaded. Importing...")
        module = importlib.import_module(module_name_str)
    return module


def create_gpcode_with_dict(gp):
    """根据字典配置生成单个 GP 任务的代码

    将一个 GP 任务配置字典转换为对应的 Python import 和调用代码，
    追加到全局的代码头部和代码体列表中。

    Args:
        gp: GP 任务配置字典，包含 id（模块路径.类名）、type（任务类型）、
            data（任务参数，可选）、nv（云端插件标识，可选）等字段。

    Returns:
        无返回值。
    """
    jobid = gp["id"]
    jobtype = gp["type"]
    jobnv = gp.get("nv", "")
    jobdata = None
    if "data" in gp:
        jobdata = gp["data"]
    module_name, class_name = jobid.rsplit('.', 1)
    module = importlib.import_module(module_name)
    gp_class = getattr(module, class_name)
    if gp_class:
        # 存在这个类
        global str_header, str_body
        if "云端" in jobtype:
            str_header.append(f"plug.load('{jobnv}')")
        str_header.append(f"from {module_name} import {class_name}")
        str_body.append(f"  {str_stack_name}.add({class_name}({gptask_params(jobdata)}))")


def gptask_params(data):
    """从任务数据中提取参数字符串

    Args:
        data: 任务配置数据字典。

    Returns:
        str: 参数字符串，如果不包含 params 则返回空字符串。
    """
    if "params" in data:
        return data["params"]
    else:
        return ""
