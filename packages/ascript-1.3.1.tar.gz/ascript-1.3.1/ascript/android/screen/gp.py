import sys
from abc import ABC, abstractmethod
import numpy as np
from ascript.android import screen
from airscript.system import R as asR
from ascript.android.system import R
import importlib
import cv2
import os


class Result:
    """图像处理结果类

    封装图像处理管线中每个步骤的输出结果，包括处理后的图像、坐标偏移和附加数据。
    """

    def __init__(self, image: np.ndarray, offset_x: int = 0, offset_y: int = 0, data=None):
        """初始化处理结果

        Args:
            image: 处理后的图像，numpy 数组格式。
            offset_x: 图像相对于原图的 X 坐标偏移量，默认 0。
            offset_y: 图像相对于原图的 Y 坐标偏移量，默认 0。
            data: 附加数据（如识别结果、匹配坐标等），默认为 None。
        """
        self.image = image
        self.offset_x = offset_x
        self.offset_y = offset_y
        self.data = data


class GPTask(ABC):
    """图像处理任务基类（抽象类）

    所有图像处理插件的基类，定义了插件的标准接口。
    子类必须实现 run 方法来执行具体的图像处理逻辑。
    """

    name = "插件名称"
    ui_path = "插件UI地址"

    @abstractmethod
    def run(self, cv_image: np.ndarray, offset_x: int = 0, offset_y: int = 0, data=None) -> Result:
        """执行图像处理任务（抽象方法）

        Args:
            cv_image: 输入图像，numpy 数组格式（BGR）。
            offset_x: 当前图像相对于原图的 X 坐标偏移量，默认 0。
            offset_y: 当前图像相对于原图的 Y 坐标偏移量，默认 0。
            data: 上一步处理传递的附加数据，默认为 None。

        Returns:
            Result: 包含处理后图像和结果数据的 Result 对象。
        """
        pass


class GPStack:
    """图像处理管线（栈）

    将多个 GPTask 图像处理任务按顺序组合成一个处理管线，
    依次执行每个任务并将前一个任务的输出作为下一个任务的输入。
    """

    @staticmethod
    def run_json(json_param: str):
        """从 JSON 参数执行处理管线（预留接口）

        Args:
            json_param: JSON 格式的管线配置字符串。

        Returns:
            无返回值。
        """
        # print(json_param)
        pass

    def __init__(self, cv_image: np.ndarray = None):
        """初始化图像处理管线

        Args:
            cv_image: 输入图像的 numpy 数组，默认为 None（自动截取当前屏幕）。
        """
        super().__init__()
        self.gp_dao = []
        self.image = cv_image
        self.offset_x = 0
        self.offset_y = 0
        if self.image is None:
            self.image = screen.bitmap_to_cvimage()

    def add(self, dao):
        """向管线中添加一个处理任务

        Args:
            dao: GPTask 子类的实例，表示一个图像处理步骤。

        Returns:
            无返回值。
        """
        self.gp_dao.append(dao)

    @staticmethod
    def change_img_channal(cv_image):
        """将图像通道统一转换为 BGR 三通道格式

        如果输入为单通道（灰度/二值）图像，则转换为三通道 BGR 格式。

        Args:
            cv_image: 输入图像的 numpy 数组。

        Returns:
            numpy.ndarray: 转换后的 BGR 三通道图像。
        """
        dims = len(cv_image.shape)
        if dims == 2:
            # 图像是单通道的（可能是灰度或二值）
            channels = 1
        elif dims == 3:
            # 图像是多通道的（可能是BGR等）
            channels = cv_image.shape[2]

        if channels == 1:
            # 图像是单通道的，可能是二值图像或灰度图像
            # 检查像素值范围来区分二值图像和灰度图像
            # if np.all(cv_image >= 0) and np.all(cv_image <= 1):
            #     # 这是二值图像，像素值在0和1之间
            #     # 将其转换为8位无符号整数（0-255）的灰度图像
            #     image = (cv_image * 255).astype('uint8')
            #     # 不论是二值图像还是灰度图像，都转换为RGB图像
            cv_image = cv2.cvtColor(cv_image, cv2.COLOR_GRAY2BGR)
        elif channels == 3:
            # 图像已经是RGB图像，无需转换
            pass

        return cv_image

    def run(self) -> Result:
        """执行整个图像处理管线

        按添加顺序依次执行所有处理任务，自动进行通道转换。

        Returns:
            Result: 最终的处理结果，包含处理后的图像和数据。
        """
        result = Result(self.image, 0, 0, None)
        for dao in self.gp_dao:
            result.image = GPStack.change_img_channal(result.image)
            result = dao.run(result.image, result.offset_x, result.offset_y, result.data)

        return result





# 记录已加载的 gp 模块名，限制缓存数量防止 sys.modules 无限增长
_loaded_gp_modules = []
_MAX_GP_CACHE = 20


def run(gp_file: str, cv_img=None):
    """运行 GP 插件文件

    加载并执行指定的 GP 插件压缩包，自动解压到缓存目录并导入模块。
    使用 LRU 策略限制缓存的模块数量，防止内存无限增长。

    Args:
        gp_file: GP 插件文件路径（.gp 格式的压缩包）。
        cv_img: 输入图像的 numpy 数组，默认为 None（由插件内部截屏）。

    Returns:
        Result: 插件执行的处理结果。
    """
    target_name = os.path.basename(gp_file)
    target_name = os.path.splitext(target_name)[0]
    target_name = "as_gp_" + target_name
    try:
        module = sys.modules[target_name]
    except KeyError:
        target_dir = R.sd("/airscript/gp/" + target_name)
        asR.unzip(gp_file, target_dir)
        module = importlib.import_module(target_name)

        # 记录并限制缓存：超过上限时移除最早加载的模块
        _loaded_gp_modules.append(target_name)
        while len(_loaded_gp_modules) > _MAX_GP_CACHE:
            oldest = _loaded_gp_modules.pop(0)
            sys.modules.pop(oldest, None)

    return module.gp(cv_img)

    # #根据data 生成代码
    # gpdata_file = R.rel(target_dir,"data.gp")
    # with open(gpdata_file, 'r', encoding='utf-8') as file:
    #     content = file.read()
    # print(content)
