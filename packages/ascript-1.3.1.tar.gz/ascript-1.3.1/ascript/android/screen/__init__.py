import io
import json
import os.path
import struct
import sys
import threading
import time
import mmap
from typing import Union
from PIL import Image as pilImage
from PIL.Image import Image
from airscript.screen import Screen
from airscript.screen import FindColors2 as asFindColors
from airscript.screen import FindImages as asFindImages
from airscript.screen import GetColorNum as asGetColorNum
from airscript.screen import yolo_v5 as asyolov5
from airscript.screen import Ocr as asOcr
from airscript.screen import CompareColors as asCompareColors
from airscript.screen import GetColorNumNew as asGetColorNumNew
from airscript.screen import CodeScanner as asCodeScanner
# from airscript.screen import TessOcr
from airscript.screen import MLKitOcrV2
from airscript.screen import ASColor
from ascript.android.system import R
from ascript.android.screen import ascv
from android.graphics import Rect
import aircv
from aircv.isource import Isource
import numpy as np
import cv2
from java import jarray, jint
from ascript.android.screen.gp import GPTask, Result
import re
from airscript.screen import OcrX as asOcrx

from ascript.android.screen import color_tools

IMG_ANDROID_BITMAP = 1
IMG_PYTHON_IMAGE = 2

MODE_FIND = 1
MODE_FIND_ALL = 2
MODE_FIND_SIFT = 3
MODE_FIND_SIFT_ALL = 4
MODE_FIND_TEMPLATE = 5
MODE_FIND_TEMPLATE_ALL = 6

FORMAT_BITMAP = 1
FORMAT_ANDROID_IMAGE = 2
FORMAT_PIL_IMAGE = 3
FORMAT_CV_MAT = 4
FORMAT_IMAGE_DATA = 5

# cache_bitmap = None

cache_data = {}
is_cacheing = False

capture_lock = threading.Lock()


def cache(is_cache: bool = False, bitmap=None, file=None, pixel_format=FORMAT_BITMAP):
    """控制屏幕截图缓存

    开启缓存后，后续的截图操作将返回缓存的图像而不是重新截取。
    关闭缓存时会释放所有已缓存的资源。

    Args:
        is_cache: 是否开启缓存，True 开启，False 关闭，默认 False。
        bitmap: 预留参数，暂未使用。
        file: 预留参数，暂未使用。
        pixel_format: 截图的像素格式，默认为 FORMAT_BITMAP。

    Returns:
        截图数据（开启缓存时）或 None（关闭缓存时）。
    """
    global is_cacheing
    is_cacheing = is_cache
    if is_cacheing:
        # 先释放该格式的旧缓存，防止内存堆积
        old = cache_data.pop(pixel_format, None)
        if old is not None:
            try:
                if hasattr(old, 'close'):
                    old.close()
            except Exception:
                pass
            del old
        cache_data[pixel_format] = capture(pixel_format=pixel_format)
        return cache_data[pixel_format]
    else:
        # 关闭缓存时释放所有资源
        for k, v in list(cache_data.items()):
            try:
                if hasattr(v, 'close'):
                    v.close()
            except Exception:
                pass
        cache_data.clear()
        return None


    # pass
    # global cache_data
    # if is_cache:
    #     cache_data[pixel_format] = capture(pixel_format=pixel_format)
    # else:
    #     for k, v in cache_data.items():
    #         if k == FORMAT_BITMAP:
    #             v.recycle()
    #         if k == FORMAT_ANDROID_IMAGE:
    #             v.close()
    #         if k == FORMAT_PIL_IMAGE:
    #             v.close()
    #     cache_data = {}


def capture(x: int = None, y: int = None, x1: int = None, y1: int = None, pixel_format=FORMAT_BITMAP):
    """截取屏幕图像

    支持全屏截取和区域截取，可返回多种格式的图像数据。
    如果缓存已开启且对应格式有缓存数据，则直接返回缓存。

    Args:
        x: 截取区域左上角 X 坐标，默认为 None（全屏截取）。
        y: 截取区域左上角 Y 坐标。
        x1: 截取区域右下角 X 坐标。
        y1: 截取区域右下角 Y 坐标。
        pixel_format: 返回的图像格式，可选值为 FORMAT_BITMAP、FORMAT_ANDROID_IMAGE、
            FORMAT_PIL_IMAGE、FORMAT_CV_MAT、FORMAT_IMAGE_DATA，默认为 FORMAT_BITMAP。

    Returns:
        根据 pixel_format 返回不同格式的图像数据，截取失败时返回 None。
    """
    global is_cacheing
    if is_cacheing and pixel_format in cache_data:
        return cache_data[pixel_format]

    with capture_lock:
        for _ in range(10):
            try:
                if pixel_format == FORMAT_BITMAP:
                    if x is None:
                        return Screen.bitmap()
                    else:
                        return Screen.bitmap(x, y, x1, y1)

                if pixel_format == FORMAT_ANDROID_IMAGE:
                    print("该方法已过时,请使用FORMAT_ANDROID_IMAGE")
                    return None

                if pixel_format == FORMAT_IMAGE_DATA:
                    return Screen.android_image_data()

                if pixel_format == FORMAT_PIL_IMAGE:
                    # 1. 从 Android 端获取缓存数据
                    android_image_data = Screen.android_image_data()
                    if android_image_data is None:
                        return None

                    # 2. 解包数据，这是唯一可信的数据源
                    byte_data = android_image_data.data
                    row_stride_from_android = android_image_data.rowStride
                    width_from_android = android_image_data.width
                    height_from_android = android_image_data.height

                    # --- 调试日志：在这里打印出获取到的原始尺寸，这是定位问题的关键！---
                    # print(f"Android Raw Data: width={width_from_android}, height={height_from_android}, stride={row_stride_from_android}, data_size={len(byte_data)}")

                    try:
                        # 3. 零拷贝：frombuffer 返回的是原始数据的视图
                        full_np_data = np.frombuffer(byte_data, dtype=np.uint8)

                        # 4. reshape 为二维（视图，不拷贝）
                        image_2d_with_stride = full_np_data.reshape((height_from_android, row_stride_from_android))

                        # 5. 切片有效 RGBA 数据（视图，不拷贝）
                        rgba_2d_view = image_2d_with_stride[:, :width_from_android * 4]

                        # 6. 裁剪
                        if x is not None:
                            crop_left = max(0, x)
                            crop_top = max(0, y)
                            crop_right = min(width_from_android, x1)
                            crop_bottom = min(height_from_android, y1)

                            if crop_right <= crop_left or crop_bottom <= crop_top:
                                return None

                            rgba_2d_view = rgba_2d_view[crop_top:crop_bottom, crop_left * 4:crop_right * 4]
                            final_width = crop_right - crop_left
                            final_height = crop_bottom - crop_top
                        else:
                            final_width = width_from_android
                            final_height = height_from_android

                        # 7. 仅在此处做一次连续化 + reshape（合并为一次拷贝）
                        final_rgba_3d = np.ascontiguousarray(rgba_2d_view).reshape((final_height, final_width, 4))

                        # 8. fromarray 不会再拷贝，直接引用 numpy 内存
                        pil_image = pilImage.fromarray(final_rgba_3d, 'RGBA')

                        return pil_image

                    except ValueError as e:
                        # 捕获 Reshape 错误并打印详细信息，帮助调试
                        print(f"Reshape Error: {e}")
                        print("--- DEBUG INFO ---")
                        print(f"Expected reshape size: ({height_from_android}, {row_stride_from_android})")
                        print(f"Actual data size: {len(byte_data)}")
                        print(
                            f"width={width_from_android}, height={height_from_android}, stride={row_stride_from_android}")
                        return None

                if pixel_format == FORMAT_CV_MAT:
                    android_image_data = Screen.android_image_data()
                    if android_image_data is None:
                        return None

                    byte_data = android_image_data.data
                    row_stride = android_image_data.rowStride
                    orig_width = android_image_data.width
                    orig_height = android_image_data.height

                    np_data = np.frombuffer(byte_data, dtype=np.uint8)

                    # 处理行跨距（三维数组版本）
                    if row_stride == orig_width * 4:
                        rgba_np = np_data.reshape((orig_height, orig_width, 4))
                    else:
                        rgba_np = np_data.reshape((orig_height, row_stride))[:, :orig_width * 4]
                        rgba_np = rgba_np.reshape((orig_height, orig_width, 4))

                    # 裁剪处理（直接操作三维数组）
                    if x is not None:
                        # 参数有效性检查
                        # 确保坐标不越界且符合逻辑顺序
                        x = max(0, min(x, orig_width))  # 限制x在[0, orig_width]
                        y = max(0, min(y, orig_height))  # 限制y在[0, orig_height]
                        x1 = min(max(x1, 0), orig_width)  # 限制x1在[0, orig_width]
                        y1 = min(max(y1, 0), orig_height)  # 限制y1在[0, orig_height]

                        # 确保x1 >= x 且 y1 >= y
                        x1 = max(x, x1)
                        y1 = max(y, y1)

                        # 检查是否还有有效区域
                        if x1 <= x or y1 <= y:
                            # android_image.close()
                            return None  # 无效的裁剪区域

                        # 执行三维数组切片
                        rgba_np = rgba_np[y:y1, x:x1, :]  # 直接内存视图，无拷贝

                        # 更新最终尺寸
                        new_height, new_width = rgba_np.shape[:2]
                    else:
                        new_width, new_height = orig_width, orig_height

                    # 转换为BGR（自动去除Alpha通道）
                    bgr_np = cv2.cvtColor(rgba_np, cv2.COLOR_RGBA2BGR)
                    # android_image.close()
                    return bgr_np
            except Exception as e:
                print(str(e))

        return None


def bitmap_to_file(path: str, bitmap=None, quality=100):
    """将 Bitmap 图像保存到文件

    Args:
        path: 保存文件的路径。
        bitmap: Android Bitmap 对象，默认为 None（自动截取当前屏幕）。
        quality: 图片质量，范围 0-100，默认 100。

    Returns:
        无返回值。
    """
    if bitmap is None:
        bitmap = capture()

    if bitmap is None:
        return None

    Screen.toFile(path, bitmap, quality)

def bitmap_crop(bitmap, rect):
    """裁剪 Bitmap 图像

    Args:
        bitmap: Android Bitmap 对象。
        rect: 裁剪区域 [left, top, right, bottom]。

    Returns:
        裁剪后的 Bitmap 对象，输入为 None 时返回 None。
    """
    if bitmap is None:
        return None

    return Screen.crop(bitmap, rect[0], rect[1], rect[2], rect[3])


def file_to_bitmap(path: str, sampleSize: int = 1):
    """从文件加载 Bitmap 图像

    Args:
        path: 图片文件路径。
        sampleSize: 采样率，值越大图像越小，默认 1（原始大小）。

    Returns:
        Android Bitmap 对象。
    """
    return Screen.file2Bitmap(path, sampleSize)


def bitmap_base64(bitmap=None, mode: int = 0):
    """将 Bitmap 图像转换为 Base64 字符串

    Args:
        bitmap: Android Bitmap 对象，默认为 None（自动截取当前屏幕）。
        mode: 编码模式，默认 0。

    Returns:
        str: Base64 编码的图像字符串。
    """
    if bitmap is None:
        bitmap = capture()
    return Screen.base64(bitmap, mode)


def base64_bitmap(b64=None, mode: int = 0):
    """将 Base64 字符串转换为 Bitmap 图像

    Args:
        b64: Base64 编码的图像字符串。
        mode: 解码模式，默认 0。

    Returns:
        Android Bitmap 对象。
    """
    return Screen.base64ToBitmap(b64, mode)


def bitmap_maxside(bitmap=None, max_side_len=9999):
    """缩放 Bitmap 使最长边不超过指定长度

    Args:
        bitmap: Android Bitmap 对象，默认为 None（自动截取当前屏幕）。
        max_side_len: 最长边的最大像素长度，默认 9999。

    Returns:
        缩放后的 Bitmap 对象。
    """
    if bitmap is None:
        bitmap = capture()
    return Screen.maxside(bitmap, max_side_len)


def bitmap_to_pilimage_test(bitmap=None):
    """将 Bitmap 转换为 PIL Image（测试版本）

    Args:
        bitmap: Android Bitmap 对象，默认为 None（自动截取当前屏幕）。

    Returns:
        PIL.Image.Image: 转换后的 PIL 图像对象。
    """
    if bitmap is None:
        bitmap = capture()
    cv_img = bitmap_to_cvimage(bitmap)
    rgb_image = cv2.cvtColor(cv_img, cv2.COLOR_BGR2RGB)
    # 将NumPy数组转换为Pillow图像对象
    pil_image = pilImage.fromarray(rgb_image)
    return pil_image


def bitmap_to_pilimage(bitmap=None):
    """将 Bitmap 转换为 PIL Image

    Args:
        bitmap: Android Bitmap 对象，默认为 None（自动截取当前屏幕）。

    Returns:
        PIL.Image.Image: 转换后的 PIL 图像对象。
    """
    if bitmap is None:
        bitmap = capture()
    cv_img = bitmap_to_cvimage(bitmap)
    rgb_image = cv2.cvtColor(cv_img, cv2.COLOR_BGR2RGB)
    # 将NumPy数组转换为Pillow图像对象
    pil_image = pilImage.fromarray(rgb_image)
    return pil_image


# def bitmap_to_cvimage(bitmap=None):
#     if bitmap is None:
#         bitmap = capture()
#     height = bitmap.getHeight()
#     width = bitmap.getWidth()
#     pixs = jarray(jint)(width * height)
#     bitmap.getPixels(pixs, 0, bitmap.getWidth(), 0, 0, width, height)
#     argb_values = np.reshape(pixs, (len(pixs), 1))
#     # a = (argb_values >> 24) & 0xFF
#     red = (argb_values >> 16) & 0xFF  # 取最高8位作为红色通道
#     green = (argb_values >> 8) & 0xFF  # 取接下来的8位作为绿色通道
#     blue = (argb_values >> 0) & 0xFF  # 取再接下来的8位作为蓝色通道
#     bgr_values = np.concatenate((blue, green, red), axis=1)
#     # 将二维数组重塑为三维数组，其中第三维是通道数
#     bgr_image = np.reshape(bgr_values, (height, width, 3))
#     bgr_image = bgr_image.astype(np.uint8)
#     return bgr_image

def bitmap_to_cvimage(bitmap=None):
    """将 Bitmap 转换为 OpenCV 图像（numpy 数组）

    将 Android Bitmap 的 ARGB 像素数据提取并转换为 BGR 格式的 numpy 数组。

    Args:
        bitmap: Android Bitmap 对象，默认为 None（自动截取当前屏幕）。

    Returns:
        numpy.ndarray: BGR 格式的图像数组，shape 为 (height, width, 3)。
    """
    if bitmap is None:
        bitmap = capture()
    height = bitmap.getHeight()
    width = bitmap.getWidth()
    pixs = jarray(jint)(width * height)
    bitmap.getPixels(pixs, 0, bitmap.getWidth(), 0, 0, width, height)

    # 将 pixs 转换为 NumPy 数组
    argb_values = np.array(pixs, dtype=np.uint32)

    # 批量提取 R、G、B 通道
    red = (argb_values >> 16) & 0xFF  # 取红色通道
    green = (argb_values >> 8) & 0xFF  # 取绿色通道
    blue = argb_values & 0xFF  # 取蓝色通道

    # 将 R、G、B 通道合并为 BGR 图像
    bgr_image = np.stack((blue, green, red), axis=-1)
    bgr_image = bgr_image.reshape((height, width, 3)).astype(np.uint8)

    return bgr_image


def cvimage_to_bitmap(cvimg):
    """将 OpenCV 图像转换为 Android Bitmap

    将 BGR 格式的 numpy 数组转换为 Android Bitmap 对象。

    Args:
        cvimg: BGR 格式的 numpy 图像数组。

    Returns:
        Android Bitmap 对象。
    """
    cvimg = cv2.cvtColor(cvimg, cv2.COLOR_BGR2RGB)
    pil_image = pilImage.fromarray(cvimg)
    # cvimg = cv2.cvtColor(cvimg, cv2.COLOR_BGR2RGBA)
    # argb_image = cvimg[:, :, [2, 1, 0, 3]]
    # pil_image = pilImage.fromarray(argb_image)

    with io.BytesIO() as output:
        pil_image.save(output, format='PNG')  # 或者使用'PNG'
        byte_array = output.getvalue()

    bitmap = Screen.toBitmap(byte_array)
    return bitmap


def hex_to_bgr(hex_color):
    """将十六进制颜色字符串转换为 BGR 元组

    Args:
        hex_color: 十六进制颜色字符串，如 "#FF0000" 或 "FF0000"。

    Returns:
        tuple: BGR 颜色值元组 (B, G, R)。
    """
    # 去除开头的#（如果有的话）
    hex_color = hex_color.lstrip('#')
    # 转换为BGR，并考虑每两个字符是一个通道的值
    bgr = tuple(int(hex_color[i:i + 2], 16) for i in (0, 2, 4))
    return bgr


def get_color_num(colors: str, rect: list = None, sim: float = 0.9):
    """获取指定颜色的像素数量

    Args:
        colors: 颜色描述字符串。
        rect: 搜索区域 [left, top, right, bottom]，默认为 None（全屏）。
        sim: 颜色相似度阈值，范围 0-1，默认 0.9。

    Returns:
        int: 匹配颜色的像素数量。
    """
    getcnum = asGetColorNum(colors)
    if rect:
        getcnum.rect(rect[0], rect[1], rect[2], rect[3])
    getcnum.sim(sim)
    return getcnum.find()


# 监听横竖屏变化对象
ori_listener = None


def on_ori_change(width: int, height: int):
    """屏幕方向变化回调函数

    当屏幕横竖屏切换时被系统调用。

    Args:
        width: 变化后的屏幕宽度。
        height: 变化后的屏幕高度。

    Returns:
        无返回值。
    """
    global ori_listener
    if ori_listener:
        ori_listener(width, height)


def set_ori_change_listener(obj_listener):
    """设置屏幕方向变化监听器

    Args:
        obj_listener: 监听回调函数，接收 (width, height) 两个参数。

    Returns:
        无返回值。
    """
    global ori_listener
    ori_listener = obj_listener


class Colors(GPTask):
    """颜色数量统计与过滤任务

    统计图像中指定颜色的像素数量，并可在图像上绘制过滤结果。
    """

    name = "颜色数量/过滤"
    ui_path = "/website/gpui/colors_num/"

    DRAW_THRESHOLD = 1
    DRAW_BLACK_BG = 2

    def __init__(self, colors: str, rect: list = None, sim: float = 1, draw_mode=DRAW_THRESHOLD):
        """初始化颜色统计任务

        Args:
            colors: 颜色描述字符串，支持多色和偏色格式。
            rect: 搜索区域 [left, top, right, bottom]，默认为 None（全图）。
            sim: 颜色相似度阈值，范围 0-1，默认 1（精确匹配）。
            draw_mode: 绘制模式，DRAW_THRESHOLD=阈值绘制，DRAW_BLACK_BG=黑色背景，默认 DRAW_THRESHOLD。
        """
        self.colors = colors
        self.rect = rect
        self.sim = sim
        self.draw = draw_mode

    def run(self, cv_image: np.ndarray, offset_x: int = 0, offset_y: int = 0, data=None) -> Result:
        """执行颜色统计与过滤

        Args:
            cv_image: 输入图像的 numpy 数组。
            offset_x: X 坐标偏移量，默认 0。
            offset_y: Y 坐标偏移量，默认 0。
            data: 上一步传递的附加数据，默认为 None。

        Returns:
            Result: 过滤后的图像和颜色像素数量。
        """

        # 获取颜色点数量
        asColorNum = asGetColorNumNew()

        asColorNum.colors(self.colors)

        if self.rect:
            asColorNum.rect(*self.rect)

        asColorNum.sim(self.sim)

        asColorNum.bitmap(cvimage_to_bitmap(cv_image))

        asColorNum.draw(self.draw)

        data = asColorNum.find()
        cv_image = bitmap_to_cvimage(asColorNum.getResBitmap())

        if self.rect:
            width = self.rect[2] - self.rect[0]
            height = self.rect[3] - self.rect[1]

            # 从图片中截取子图像
            cv_image = cv_image[self.rect[1]:self.rect[3], self.rect[0]:self.rect[2]]
            offset_x = self.rect[0]
            offset_y = self.rect[1]

        return Result(cv_image, offset_x, offset_y, data)

        # if self.rect:
        #     start_x, start_y = self.rect[0], self.rect[1]
        #     width, height = self.rect[2] - self.rect[0], self.rect[3] - self.rect[1]
        #     if self.rect[2] < self.rect[0] or self.rect[3] < self.rect[1]:
        #         raise ValueError("尺寸异常")
        #     cv_image = cv_image[start_y:start_y + height, start_x:start_x + width]

        # 开始绘图
        # colors_arr = self.colors.split("|");
        # simdiff = int(255 * (1 - self.sim))
        #
        # colors_dict = {}
        # # 整理数据
        # for c in colors_arr:
        #     c_kandv = c.split("-")
        #     hex_color = c_kandv[0].lstrip('#')
        #     if len(c_kandv) == 2:
        #         hex_diff = c_kandv[1].lstrip('#')
        #         if len(hex_diff) == 6:
        #             colors_dict[c_kandv[0]] = [tuple(int(hex_color[i:i + 2], 16) for i in (4, 2, 0)),
        #                                        tuple(int(hex_diff[i:i + 2], 16) for i in (4, 2, 0))]
        #         else:
        #             raise ValueError("偏色长度不为6")
        #     else:
        #         colors_dict[c_kandv[0]] = [tuple(int(hex_color[i:i + 2], 16) for i in (4, 2, 0)),
        #                                    (simdiff, simdiff, simdiff)]
        # print(colors_dict)
        #
        # # 获取图像的高度和宽度
        # height, width, channels = cv_image.shape
        #
        # c_nums = 0
        #
        # # 遍历图像的每个像素
        # for y in range(height):
        #     for x in range(width):
        #         # 访问当前像素的BGR值（注意是BGR而不是RGB）
        #         b, g, r = cv_image[y, x]
        #         for v in colors_dict.values():
        #             if self.compare_color((b, g, r), v[0], v[1]):
        #                 c_nums = c_nums+1
        #             else:
        #                 cv_image[y, x] = [0, 0, 0]

        # return Result(cv_image, offset_x, offset_y, data)

    def compare_color(self, source: tuple, target: tuple, sim: tuple):
        """比较两个颜色是否在容差范围内

        Args:
            source: 源颜色 BGR 元组。
            target: 目标颜色 BGR 元组。
            sim: 各通道容差值元组。

        Returns:
            bool: 所有通道差值均在容差内则返回 True。
        """
        cha = sim[0] - (abs(source[0] - target[0]))
        if cha < 0:
            return False

        cha = sim[1] - (abs(source[1] - target[1]))
        if cha < 0:
            return False

        cha = sim[2] - (abs(source[2] - target[2]))
        if cha < 0:
            return False

        return True

    @staticmethod
    def count(colors: str, rect: list = None, sim: float = 1, bitmap=None):
        """静态方法：直接统计颜色像素数量

        Args:
            colors: 颜色描述字符串。
            rect: 搜索区域 [left, top, right, bottom]，默认为 None（全图）。
            sim: 颜色相似度阈值，默认 1。
            bitmap: Android Bitmap 对象，默认为 None（自动截屏）。

        Returns:
            int: 匹配颜色的像素数量。
        """
        asColorNum = asGetColorNumNew()

        asColorNum.colors(colors)

        if rect:
            asColorNum.rect(*rect)

        asColorNum.sim(sim)

        if bitmap is not None:
            asColorNum.bitmap(bitmap)

        return asColorNum.find()


class CodeScanner(GPTask):
    """条码/二维码识别任务

    识别图像中的条形码和二维码。
    """

    name = "条码识别"
    ui_path = "/website/gpui/codescanner/"

    def __init__(self, rect: list = None):
        """初始化条码识别任务

        Args:
            rect: 识别区域 [left, top, right, bottom]，默认为 None（全图）。
        """
        self.rect = rect

    def run(self, cv_image: np.ndarray, offset_x: int = 0, offset_y: int = 0, data=None) -> Result:
        """执行条码识别

        Args:
            cv_image: 输入图像的 numpy 数组。
            offset_x: X 坐标偏移量，默认 0。
            offset_y: Y 坐标偏移量，默认 0。
            data: 上一步传递的附加数据，默认为 None。

        Returns:
            Result: 识别结果，data 为条码信息列表。
        """
        bitmap_image = cvimage_to_bitmap(cv_image)
        # from ascript.android.ui import ImageWindow
        # ImageWindow.show(bitmap_image)
        data = CodeScanner.scan(self.rect, bitmap_image)
        return Result(cv_image, offset_x, offset_y, data)

    @staticmethod
    def scan(rect: list = None, bitmap=None):
        """扫描图像中的条码/二维码

        Args:
            rect: 识别区域 [left, top, right, bottom]，默认为 None（全图）。
            bitmap: Android Bitmap 对象，默认为 None。

        Returns:
            list[dict]: 识别结果列表，每个元素包含 format（格式）、type（类型）、
                value（内容）、rect（位置区域）字段。
        """
        res = asCodeScanner.scan_remote(bitmap, rect)
        pres = []
        if res and len(res) > 0:
            for r in res:
                jrect = r.get("rect");
                pres.append({
                    "format": r.get("format"),
                    "type": r.get("type"),
                    "value": r.get("value"),
                    "rect": [jrect.get(0), jrect.get(1), jrect.get(2), jrect.get(3)]
                })
        return pres


class FindColors(GPTask):
    """多点找色任务

    在屏幕截图中搜索符合颜色描述的位置，支持多个颜色点组合匹配。
    """

    name = "多点找色"
    ui_path = "/website/gpui/find_colors/"

    def __init__(self, colors: str, rect: list = None, space: int = 5, ori: int = 2, diff: float = 0.98,
                 p_max_num: int = 999999):
        """初始化多点找色任务

        Args:
            colors: 颜色描述字符串，格式为 "x,y,RRGGBB|dx,dy,RRGGBB|..."。
            rect: 搜索区域 [left, top, right, bottom]，默认为 None（全屏）。
            space: 相邻匹配结果的最小间距，默认 5。
            ori: 扫描方向（1-8），默认 2（从上到下从左到右）。
            diff: 颜色相似度阈值，范围 0-1，默认 0.98。
            p_max_num: 最大返回结果数量，默认 999999。
        """
        self.colors = colors
        self.rect = rect
        self.space = space
        self.ori = ori
        self.diff = diff
        self.p_max_num = p_max_num

    def run(self, cv_image: np.ndarray, offset_x: int = 0, offset_y: int = 0, data=None) -> Result:
        """执行多点找色

        Args:
            cv_image: 输入图像的 numpy 数组。
            offset_x: X 坐标偏移量，默认 0。
            offset_y: Y 坐标偏移量，默认 0。
            data: 上一步传递的附加数据，默认为 None。

        Returns:
            Result: 找色结果，data 为坐标点字典列表 [{"x": x, "y": y}, ...]。
        """
        bitmap_image = cvimage_to_bitmap(cv_image)
        data = FindColors.find_all(self.colors, self.rect, self.space, self.ori, self.diff, bitmap_image,
                                   self.p_max_num)
        py_data = []
        for p in data:
            py_data.append({
                "x": p.x,
                "y": p.y
            })

        return Result(cv_image, offset_x, offset_y, py_data)

    @staticmethod
    def find(colors: str, rect: list = None, space: int = 5, ori: int = 2, diff: float = 0.98, image=None):
        """查找第一个匹配的颜色位置

        Args:
            colors: 颜色描述字符串。
            rect: 搜索区域 [left, top, right, bottom]，默认为 None。
            space: 匹配间距，默认 5。
            ori: 扫描方向（1-8），默认 2。
            diff: 颜色相似度阈值，默认 0.98。
            image: Bitmap 图像，默认为 None（自动截屏）。

        Returns:
            匹配到的坐标点，未找到时返回 None。
        """
        try:
            findc = asFindColors(colors)
            if rect:
                findc.rect(rect[0], rect[1], rect[2], rect[3])

            if image:
                findc.bitmap(image)

            findc.space(space)
            findc.ori(ori)
            hex_diff = str(hex(round((1 - diff) * 255))[2:]).zfill(2)
            findc.diff("#" + hex_diff + hex_diff + hex_diff)
            return findc.find()
        except Exception as e:
            print(str(e))
            return None

    @staticmethod
    def find_all(colors: str, rect: list = None, space: int = 5, ori: int = 2, diff: float = 0.98, image=None,
                 p_max_num: int = 999999):
        """查找所有匹配的颜色位置

        Args:
            colors: 颜色描述字符串。
            rect: 搜索区域 [left, top, right, bottom]，默认为 None。
            space: 匹配间距，默认 5。
            ori: 扫描方向（1-8），默认 2。
            diff: 颜色相似度阈值，默认 0.98。
            image: Bitmap 图像，默认为 None（自动截屏）。
            p_max_num: 最大返回数量，默认 999999。

        Returns:
            list: 所有匹配到的坐标点列表，异常时返回 None。
        """
        try:
            findc = asFindColors(colors)
            if rect:
                findc.rect(rect[0], rect[1], rect[2], rect[3])

            if image:
                findc.bitmap(image)

            findc.space(space)
            findc.ori(ori)
            hex_diff = str(hex(round((1 - diff) * 255))[2:]).zfill(2)
            # print(hex_diff)
            findc.diff("#" + hex_diff + hex_diff + hex_diff)
            return findc.find_all(p_max_num)
        except Exception as e:
            print(str(e))
            return None


class FindImages(GPTask):
    """找图任务

    在屏幕截图或指定图像中搜索目标子图，支持模板匹配、SIFT 特征匹配和混合模式。
    """

    name = "找图"
    ui_path = "/website/gpui/find_images/"
    MODE_TEMPLATE = 0
    MODE_SIFT = 1
    MODE_TAS = 2

    def __init__(self, part_img: Union[str, list], rect: list = None, confidence: float = 0.5, rgb: bool = False,
                 maxcnt: int = 0, mode=MODE_TEMPLATE):
        """初始化找图任务

        Args:
            part_img: 目标子图文件路径或路径列表。
            rect: 搜索区域 [left, top, right, bottom]，默认为 None（全图）。
            confidence: 匹配置信度阈值，范围 0-1，默认 0.5。
            rgb: 是否使用彩色匹配，默认 False。
            maxcnt: 最大返回匹配数量，0 表示不限制，默认 0。
            mode: 匹配模式，MODE_TEMPLATE=模板匹配，MODE_SIFT=SIFT 特征匹配，
                MODE_TAS=混合模式，默认 MODE_TEMPLATE。
        """
        self.part_img = part_img
        self.rect = rect
        self.confidence = confidence
        self.rgb = rgb
        self.maxcnt = maxcnt
        self.mode = mode

    def run(self, cv_image: np.ndarray, offset_x: int = 0, offset_y: int = 0, data=None) -> Result:
        """执行找图操作

        Args:
            cv_image: 输入图像的 numpy 数组。
            offset_x: X 坐标偏移量，默认 0。
            offset_y: Y 坐标偏移量，默认 0。
            data: 上一步传递的附加数据，默认为 None。

        Returns:
            Result: 找图结果，data 为匹配信息列表。
        """

        dims = len(cv_image.shape)
        if dims == 2:
            # 图像是单通道的（可能是灰度或二值）
            channels = 1
        elif dims == 3:
            # 图像是多通道的（可能是BGR等）
            channels = cv_image.shape[2]

        if channels == 1:
            # 图像是单通道的，可能是二值图像或灰度图像
            # 检查像素值范围来区分二值图像和灰度图像
            # if np.all(cv_image >= 0) and np.all(cv_image <= 1):
            #     # 这是二值图像，像素值在0和1之间
            #     # 将其转换为8位无符号整数（0-255）的灰度图像
            #     image = (cv_image * 255).astype('uint8')
            #     # 不论是二值图像还是灰度图像，都转换为RGB图像
            cv_image = cv2.cvtColor(cv_image, cv2.COLOR_GRAY2BGR)
        elif channels == 3:
            # 图像已经是RGB图像，无需转换
            pass

        # 先进行裁剪,因为 bitmap转换cvimg效率慢
        if self.rect:
            x, y, r, b = self.rect
            # print(x,y,r,b)
            cv_image = cv_image[y:b, x:r]

        if self.mode == FindImages.MODE_TEMPLATE:
            py_data = FindImages.find_all_template(self.part_img, self.rect, self.confidence, self.rgb,
                                                   source_img=cv_image, maxcnt=self.maxcnt)
        elif self.mode == FindImages.MODE_SIFT:
            # print(self.maxcnt)
            py_data = FindImages.find_all_sift(self.part_img, rect=self.rect, confidence=self.confidence, rgb=self.rgb,
                                               source_img=cv_image, maxcnt=self.maxcnt)
        elif self.mode == FindImages.MODE_TAS:
            # print(self.maxcnt)
            py_data = FindImages.find_all(self.part_img, rect=self.rect, confidence=self.confidence, rgb=self.rgb,
                                          source_img=cv_image, maxcnt=self.maxcnt)

        return Result(cv_image, offset_x, offset_y, py_data)

    @staticmethod
    def __makedao(part_img: str, rect: list = None, confidence: int = 0.1):
        """创建找图数据访问对象（内部方法）

        Args:
            part_img: 目标子图文件路径。
            rect: 搜索区域 [left, top, right, bottom]，默认为 None。
            confidence: 匹配置信度阈值，默认 0.1。

        Returns:
            找图数据访问对象。

        Raises:
            Exception: 当图片文件不存在时抛出。
        """
        if not os.path.exists(part_img):
            part_img = R.img(part_img)
            if not os.path.exists(part_img):
                raise Exception(f"找不到图片文件:{part_img}")

        findi = asFindImages(part_img)

        if rect:
            findi.rect(rect[0], rect[1], rect[2], rect[3])

        findi.confidence(confidence)
        return findi

    @staticmethod
    def search_image(image_path: str):
        """搜索并验证图片文件路径

        如果直接路径不存在，会尝试从资源 img 目录查找。

        Args:
            image_path: 图片文件路径。

        Returns:
            str: 验证后的有效图片路径。

        Raises:
            Exception: 当图片文件不存在时抛出。
        """
        if not os.path.exists(image_path):
            image_path = R.img(image_path)
            if not os.path.exists(image_path):
                raise Exception(f"找不到图片文件:{image_path}")

        return image_path

    @staticmethod
    def _get_image_source(rect: list = None):
        """获取图像源（内部方法）

        截取屏幕图像并返回 OpenCV 格式。

        Args:
            rect: 截取区域 [left, top, right, bottom]，默认为 None（全屏）。

        Returns:
            numpy.ndarray: BGR 格式的图像数组。
        """
        if rect:
            source_img = capture(rect[0], rect[1], rect[2], rect[3], pixel_format=FORMAT_CV_MAT)
        else:
            source_img = capture(pixel_format=FORMAT_CV_MAT)

        return source_img

    @staticmethod
    def find(part_img: str, rect: list = None, confidence: float = 0.1, rgb: bool = False, source_img=None):
        """查找第一个匹配的子图（先模板匹配，再 SIFT）

        Args:
            part_img: 目标子图文件路径。
            rect: 搜索区域 [left, top, right, bottom]，默认为 None。
            confidence: 匹配置信度阈值，默认 0.1。
            rgb: 是否使用彩色匹配，默认 False。
            source_img: 自定义图像源，默认为 None（自动截屏）。

        Returns:
            dict: 第一个匹配结果，未找到时返回 None。
        """
        res = FindImages.find_template(part_img, rect, confidence, rgb=rgb, source_img=source_img)
        if res is None:
            return FindImages.find_sift(part_img, rect, confidence, source_img=source_img)
        return res

    @staticmethod
    def find_all(part_img: str, rect: list = None, confidence: float = 0.1, rgb: bool = False, source_img=None,
                 maxcnt=0):
        """查找所有匹配的子图（先模板匹配，再 SIFT）

        Args:
            part_img: 目标子图文件路径。
            rect: 搜索区域 [left, top, right, bottom]，默认为 None。
            confidence: 匹配置信度阈值，默认 0.1。
            rgb: 是否使用彩色匹配，默认 False。
            source_img: 自定义图像源，默认为 None（自动截屏）。
            maxcnt: 最大返回数量，0 表示不限制，默认 0。

        Returns:
            list[dict]: 所有匹配结果列表。
        """
        if source_img is None:
            source_img = FindImages._get_image_source(rect)

        res = FindImages.find_all_template(part_img, rect, confidence, rgb=rgb, maxcnt=maxcnt, source_img=source_img)
        if res is None:
            return FindImages.find_all_sift(part_img, rect, confidence, rgb=rgb, maxcnt=maxcnt, source_img=source_img)
        return res

    @staticmethod
    def find_sift(part_img: str, rect: list = None, confidence: float = 0.1, rgb: bool = False, source_img=None):
        """使用 SIFT 特征匹配查找第一个匹配的子图

        Args:
            part_img: 目标子图文件路径。
            rect: 搜索区域 [left, top, right, bottom]，默认为 None。
            confidence: 匹配置信度阈值，默认 0.1。
            rgb: 是否使用彩色匹配，默认 False。
            source_img: 自定义图像源，默认为 None（自动截屏）。

        Returns:
            dict: 第一个匹配结果，未找到时返回 None。
        """

        try:
            res = FindImages.find_all_sift(part_img, rect=rect, confidence=confidence, rgb=rgb,
                                           source_img=source_img, maxcnt=1)
            if res and len(res) > 0:
                return res[0]
        except Exception as e:
            print(str(e))

        return None

    @staticmethod
    def find_all_sift(part_img: str, rect: list = None, confidence: float = 0.1,
                      rgb: bool = False, source_img=None, maxcnt=0):
        """使用 SIFT 特征匹配查找所有匹配的子图

        Args:
            part_img: 目标子图文件路径。
            rect: 搜索区域 [left, top, right, bottom]，默认为 None。
            confidence: 匹配置信度阈值，默认 0.1。
            rgb: 是否使用彩色匹配，默认 False。
            source_img: 自定义图像源，默认为 None（自动截屏）。
            maxcnt: 最大返回数量，0 表示不限制，默认 0。

        Returns:
            list[dict]: 所有匹配结果列表，异常时返回 None。
        """
        try:
            if source_img is None:
                source_img = FindImages._get_image_source(rect)

            return ascv.find_surf(source_img, part_img, off_rect=rect, threshold=confidence, rgb=rgb, maxcnt=maxcnt)
        except Exception as e:
            print(str(e))

        return None

    @staticmethod
    def find_template(part_img: Union[str, list], rect: list = None, confidence: float = 0.5, rgb: bool = False,
                      source_img=None):
        """使用模板匹配查找第一个匹配的子图

        Args:
            part_img: 目标子图文件路径或路径列表。
            rect: 搜索区域 [left, top, right, bottom]，默认为 None。
            confidence: 匹配置信度阈值，默认 0.5。
            rgb: 是否使用彩色匹配，默认 False。
            source_img: 自定义图像源，默认为 None（自动截屏）。

        Returns:
            dict: 第一个匹配结果，未找到时返回 None。
        """
        try:
            res = FindImages.find_all_template(part_img, rect=rect, confidence=confidence, rgb=rgb, maxcnt=1,
                                               source_img=source_img)
            if res and len(res) > 0:
                return res[0]
        except Exception as e:
            print(str(e))
        return None

    @staticmethod
    def find_all_template(part_img: Union[str, list], rect: list = None, confidence: float = 0.5, rgb: bool = False,
                          maxcnt: int = 0, source_img=None):
        """使用模板匹配查找所有匹配的子图

        Args:
            part_img: 目标子图文件路径或路径列表。
            rect: 搜索区域 [left, top, right, bottom]，默认为 None。
            confidence: 匹配置信度阈值，默认 0.5。
            rgb: 是否使用彩色匹配，默认 False。
            maxcnt: 最大返回数量，0 表示不限制，默认 0。
            source_img: 自定义图像源，默认为 None（自动截屏）。

        Returns:
            list[dict]: 所有匹配结果列表，异常时返回 None。
        """
        # print("1")
        try:
            if source_img is None:
                # source_img = bitmap_to_cvimage()
                source_img = FindImages._get_image_source(rect)
                # print(source_img)
            return ascv.find_all_template(source_img, part_img, rect=rect, threshold=confidence, rgb=rgb, maxcnt=maxcnt)
        except Exception as e:
            print(str(e))

        return None
        # offx = 0
        # offy = 0
        # if rect:
        #     offx = rect[0]
        #     offy = rect[1]
        #     if source_img is not None:
        #         width = rect[2]-rect[0]
        #         height = rect[3]-rect[1]
        #         x = offx
        #         y = offy
        #         source_img = source_img[y:y+height, x:x+width]
        #
        # if source_img is None:
        #     source_img = FindImages._get_image_source(rect)
        # res = []
        #
        # if isinstance(part_img,list):
        #     for s_img in part_img:
        #         dao = Isource(source_img, offx, offy)
        #         image_search = aircv.imread(FindImages.search_image(s_img))
        #         res =  res + dao.find_all_template(image_search, confidence, rgb=rgb)
        # else:
        #     dao = Isource(source_img, offx, offy)
        #     image_search = aircv.imread(FindImages.search_image(part_img))
        #     res = dao.find_all_template(image_search, confidence, rgb=rgb)
        #
        # part_img = None
        # source_img = None
        #
        # return res


class YoLov5:
    """YOLOv5 目标检测类

    使用 YOLOv5 模型进行图像目标检测。
    """

    def __init__(self, model_name: str = None, path: str = None):
        """初始化 YOLOv5 检测器

        Args:
            model_name: 内置模型名称，默认为 None。
            path: 自定义模型文件路径，默认为 None。
        """
        super().__init__()
        if model_name:
            self.yolo = asyolov5(model_name)
        elif path:
            self.yolo = asyolov5(path)

    def find_all(self, rect=None, max_size: int = 640):
        """检测图像中的所有目标

        Args:
            rect: 检测区域 [left, top, right, bottom]，默认为 None（全图）。
            max_size: 输入图像最大边长，默认 640。

        Returns:
            list: 检测到的目标列表。
        """

        self.yolo.setMaxSize(max_size)

        if rect:
            return self.yolo.find_all(rect[0], rect[1], rect[2], rect[3])
        return self.yolo.find_all()


class Ocr(GPTask):
    """OCR 文字识别任务

    支持多种 OCR 引擎进行文字识别，包括 MLKit、PaddleOCR v2/v3 和 Tesseract。
    """

    Tess_ENG = "eng"
    Tess_CHI = "chi"
    Tess_NUM = "num"
    RIL_AUTO = -1
    RIL_BLOCK = 0
    RIL_PARA = 1
    RIL_TEXTLINE = 2
    RIL_WORD = 3
    RIL_SYMBOL = 4
    lock = threading.Lock()
    name = "文字识别"
    ui_path = "/website/gpui/ocr/"

    MODE_MLK = 1
    MODE_PADDLE_V2 = 2
    MODE_PADDLE_V3 = 3
    MODE_TESS = 4

    def __init__(self, mode=MODE_MLK, rect=None, pattern: str = None, confidence: int = 0.1):
        """初始化 OCR 文字识别任务

        Args:
            mode: OCR 引擎模式，MODE_MLK=MLKit，MODE_PADDLE_V2=PaddleOCR v2，
                MODE_PADDLE_V3=PaddleOCR v3，MODE_TESS=Tesseract，默认 MODE_MLK。
            rect: 识别区域 [left, top, right, bottom]，默认为 None（全图）。
            pattern: 文字过滤正则表达式，默认为 None（不过滤）。
            confidence: 匹配置信度阈值，默认 0.1。
        """
        self.mode = mode
        self.rect = rect
        self.pattern = pattern
        self.confidence = confidence

    def run(self, cv_image: np.ndarray, offset_x: int = 0, offset_y: int = 0, data=None) -> Result:
        """执行文字识别

        Args:
            cv_image: 输入图像的 numpy 数组。
            offset_x: X 坐标偏移量，默认 0。
            offset_y: Y 坐标偏移量，默认 0。
            data: 上一步传递的附加数据，默认为 None。

        Returns:
            Result: 识别结果，data 为文字信息字典列表，包含 confidence、text、rect、x、y 字段。
        """
        if self.mode == Ocr.MODE_MLK:
            data = Ocr.mlkitocr_v2(self.rect, self.pattern, bitmap=cvimage_to_bitmap(cv_image))
        elif self.mode == Ocr.MODE_PADDLE_V2:
            data = Ocr.paddleocr_v2(self.rect, self.pattern, self.confidence, bitmap=cvimage_to_bitmap(cv_image))
        elif self.mode == Ocr.MODE_PADDLE_V3:
            data = Ocr.paddleocr_v3(self.rect, self.pattern, self.confidence, bitmap=cvimage_to_bitmap(cv_image))
        elif self.mode == Ocr.MODE_TESS:
            data = Ocr.tess(self.rect, self.pattern, self.confidence)

        # pdata = []
        # if data and len(data) > 0:
        #     for d in data:
        #         pdata.append({
        #             "confidence": d.confidence,
        #             "text": d.text,
        #             "rect": [d.region_position.left, d.region_position.top, d.region_position.right,
        #                      d.region_position.bottom],
        #             "x": d.x,
        #             "y": d.y
        #         })
        return Result(cv_image, offset_x, offset_y, Ocr.octtext_to_dict(data))

    @staticmethod
    def paddleocr_v2(
            rect: list = None,
            pattern: str = None,
            confidence: float = 0.1,
            max_side_len: int = 1200,
            precision: int = 16,
            bitmap=None,
            file: str = None):
        """使用 PaddleOCR v2 进行文字识别

        Args:
            rect: 识别区域 [left, top, right, bottom]，默认为 None（全图）。
            pattern: 文字过滤正则表达式，默认为 None。
            confidence: 匹配置信度阈值，默认 0.1。
            max_side_len: 输入图像最大边长，默认 1200。
            precision: 精度等级，默认 16。
            bitmap: Android Bitmap 对象，默认为 None（自动截屏）。
            file: 图片文件路径，默认为 None。

        Returns:
            list: OCR 识别结果列表，异常或无结果时返回 None。
        """
        try:
            with Ocr.lock:
                ocr = asOcr()
                ocr.mode(2)

                if rect:
                    ocr.rect(rect[0], rect[1], rect[2], rect[3])

                if pattern:
                    ocr.pattern(pattern)

                ocr.confidence(confidence)
                ocr.max_side_len(max_side_len)
                ocr.precision(precision)
                if bitmap:
                    ocr.bitmap(bitmap)

                if file:
                    ocr.file(file)

                res = ocr.find_all()

                if not res:
                    return None

                return list(res)
        except Exception as e:
            print(str(e))
            return None

    @staticmethod
    def paddleocr_v3(rect: list = None, pattern: str = None, confidence: float = 0.5, max_side_len: int = 1200,
                     precision: int = 16, bitmap=None,
                     file: str = None):
        """使用 PaddleOCR v3 进行文字识别

        Args:
            rect: 识别区域 [left, top, right, bottom]，默认为 None（全图）。
            pattern: 文字过滤正则表达式，默认为 None。
            confidence: 匹配置信度阈值，默认 0.5。
            max_side_len: 输入图像最大边长，默认 1200。
            precision: 精度等级，默认 16。
            bitmap: Android Bitmap 对象，默认为 None（自动截屏）。
            file: 图片文件路径，默认为 None。

        Returns:
            list: OCR 识别结果列表，异常或无结果时返回 None。
        """
        try:
            with Ocr.lock:
                ocr = asOcr()
                ocr.mode(3)
                if rect:
                    ocr.rect(rect[0], rect[1], rect[2], rect[3])
                if pattern:
                    ocr.pattern(pattern)

                ocr.confidence(confidence)
                ocr.max_side_len(max_side_len)
                ocr.precision(precision)
                if bitmap:
                    ocr.bitmap(bitmap)

                if file:
                    ocr.file(file)

                # return ocr.find_all()
                res = ocr.find_all()

                if not res:
                    return None

                return list(res)
        except Exception as e:
            print(str(e))
            return None

    @staticmethod
    def tess(data_file=Tess_CHI, rect: list = None, pattern: str = None, split_level=RIL_AUTO, white_list: str = None,
             black_list: str = None):
        """使用 Tesseract 进行文字识别（预留接口）

        Args:
            data_file: Tesseract 语言数据文件，默认为中文。
            rect: 识别区域，默认为 None。
            pattern: 文字过滤表达式，默认为 None。
            split_level: 分割级别，默认为自动。
            white_list: 字符白名单，默认为 None。
            black_list: 字符黑名单，默认为 None。

        Returns:
            None: 当前未实现。
        """
        return None

    @staticmethod
    def mlkitocr_v2(rect: list = None, pattern: str = None, confidence: float = 0.5, bitmap=None):
        """使用 MLKit v2 进行文字识别

        Args:
            rect: 识别区域 [left, top, right, bottom]，默认为 None（全图）。
            pattern: 文字过滤正则表达式或子字符串，默认为 None。
            confidence: 匹配置信度阈值，默认 0.5。
            bitmap: Android Bitmap 对象，默认为 None（自动截屏）。

        Returns:
            list: OCR 识别结果列表，异常或无结果时返回 None。
        """
        try:
            res = MLKitOcrV2.chi_run_remote(bitmap, rect)
            if res and pattern:
                n_res = []
                re_pattern = re.compile(pattern)
                for r in res:
                    if pattern in r.text or re_pattern.match(r.text):
                        n_res.append(r)
                res = n_res

            # print(len(res))
            if not res:
                return None

            return list(res)
        except Exception as e:
            print(str(e))
            return None

    @staticmethod
    def octtext_to_dict(res):
        """将 OCR 原始结果转换为字典列表

        Args:
            res: OCR 引擎返回的原始结果列表。

        Returns:
            list[dict]: 转换后的字典列表，每个元素包含 confidence、text、rect、x、y 字段。
        """
        pdata = []
        if res and len(res) > 0:
            for d in res:
                pdata.append({
                    "confidence": d.confidence,
                    "text": d.text,
                    "rect": [d.region_position.left, d.region_position.top, d.region_position.right,
                             d.region_position.bottom],
                    "x": d.x,
                    "y": d.y
                })
        return pdata

    @staticmethod
    def matrix(font_lib: str, rect: list = None, region=0.9):
        """使用点阵字库进行文字识别

        Args:
            font_lib: 字库文件路径。
            rect: 识别区域 [left, top, right, bottom]，默认为 None（全图）。
            region: 识别区域相似度，默认 0.9。

        Returns:
            str: 识别出的文字内容，异常时返回 None。
        """
        try:
            if rect:
                x, y, r, b = rect
                bitmap = capture(x, y, r, b)
            else:
                x = 0
                y = 0
                bitmap = capture()

            res = asOcrx.ocrx(font_lib, bitmap, x, y, int(region * 100))

            return res.getText()
        except Exception as e:
            print(str(e))
            return None


class CompareColors(GPTask):
    """多点比色任务

    对比屏幕上多个坐标点的颜色是否与预期一致，用于判断界面状态。
    """

    name = "多点比色"
    ui_path = "/website/gpui/compare_colors/"

    def __init__(self, colors: str, diff: float = 0.9, until: bool = False):
        """初始化多点比色任务

        Args:
            colors: 颜色描述字符串，格式为 "x,y,RRGGBB|x,y,RRGGBB|..."。
            diff: 颜色相似度阈值，范围 0-1，默认 0.9。
            until: 是否持续等待直到比色成功，默认 False。
        """
        self.colors = colors
        self.diff = diff
        self.until = until

    def run(self, cv_image: np.ndarray, offset_x: int = 0, offset_y: int = 0, data=None) -> Result:
        """执行多点比色

        Args:
            cv_image: 输入图像的 numpy 数组。
            offset_x: X 坐标偏移量，默认 0。
            offset_y: Y 坐标偏移量，默认 0。
            data: 上一步传递的附加数据，默认为 None。

        Returns:
            Result: 比色结果，data 为布尔值表示是否匹配成功。
        """
        image = cvimage_to_bitmap(cv_image)
        if self.until:
            data = CompareColors.compare_until(self.colors, self.diff, image)
        else:
            data = CompareColors.compare(self.colors, self.diff, image)

        return Result(cv_image, offset_x, offset_y, data)

    @staticmethod
    def compare(colors: str, diff: float = 0.9, bitmap=None):
        """执行一次多点比色

        Args:
            colors: 颜色描述字符串。
            diff: 颜色相似度阈值，默认 0.9。
            bitmap: Android Bitmap 对象，默认为 None（自动截屏）。

        Returns:
            bool: 比色结果，异常时返回 None。
        """
        # colors = color_tools.ana_colors(colors)
        # return False
        try:
            compare = asCompareColors(colors)
            hex_diff = str(hex(int((1 - diff) * 255))[2:]).zfill(2)
            compare.diff("#" + hex_diff + hex_diff + hex_diff)
            if bitmap:
                compare.bitmap(bitmap)
            return compare.compare()
        except Exception as e:
            print(str(e))
            return None

    @staticmethod
    def compare_until(colors: str, diff: float = 0.9, bitmap=None):
        """持续等待直到多点比色成功

        Args:
            colors: 颜色描述字符串。
            diff: 颜色相似度阈值，默认 0.9。
            bitmap: Android Bitmap 对象，默认为 None（自动截屏）。

        Returns:
            bool: 比色结果，异常时返回 None。
        """
        try:
            compare = asCompareColors(colors)
            hex_diff = str(hex(int((1 - diff) * 255))[2:]).zfill(2)
            compare.diff("#" + hex_diff + hex_diff + hex_diff)
            if bitmap:
                compare.bitmap(bitmap)
            compare.until()
            return compare.compare()
        except Exception as e:
            print(str(e))
            return None




class Color:
    """颜色值类

    封装从 Bitmap 获取的像素颜色值，提供 RGB、ARGB 等多种格式的访问。
    """

    def __init__(self, bitmap_color: int):
        """初始化颜色值

        Args:
            bitmap_color: Bitmap 像素的整数颜色值（ARGB 格式）。
        """
        self.color = bitmap_color
        self.r = ASColor.r(bitmap_color)
        self.g = ASColor.g(bitmap_color)
        self.b = ASColor.b(bitmap_color)
        self.a = ASColor.a(bitmap_color)
        self.rgb = "#{:02x}{:02x}{:02x}".format(self.r, self.g, self.b)
        self.argb = "#{:02x}{:02x}{:02x}{:02x}".format(self.a, self.r, self.g, self.b)

    def __str__(self):
        """返回颜色的 JSON 字符串表示

        Returns:
            str: 包含 r、g、b、rgb、argb 信息的 JSON 字符串。
        """
        c_dict = {
            "r": self.r,
            "g": self.g,
            "b": self.b,
            "rgb": self.rgb,
            "argb": self.argb
        }
        return json.dumps(c_dict)


def get_color(x: int, y: int, bitmap=None):
    """获取指定坐标的颜色值

    Args:
        x: X 坐标。
        y: Y 坐标。
        bitmap: Android Bitmap 对象，默认为 None（自动截屏）。

    Returns:
        Color: 颜色对象，坐标越界或异常时返回 None。
    """
    try:
        if bitmap is None:
            bitmap = capture()
        x = int(x)
        y = int(y)

        if bitmap.getWidth() < x or bitmap.getHeight() < y:
            return None

        a_color = bitmap.getPixel(x, y)
        return Color(a_color)
    except Exception as e:
        print(str(e))
        return None


def get_colors(bitmap):
    """获取 Bitmap 的所有像素颜色数据

    Args:
        bitmap: Android Bitmap 对象，默认为 None（自动截屏）。

    Returns:
        像素颜色数据数组，异常时返回 None。
    """
    try:
        if bitmap is None:
            bitmap = capture()
        return ASColor.getPixs(bitmap)
    except Exception as e:
        print(str(e))
        return None


class Eraser(GPTask):
    """橡皮擦任务

    将图像中指定矩形区域的像素填充为指定颜色，用于擦除图像中的特定区域。
    """

    name = "橡皮擦"
    ui_path = "/website/gpui/eraser/"

    def __init__(self, rect: list, color: str = None):
        """初始化橡皮擦任务

        Args:
            rect: 擦除区域 [left, top, right, bottom]。
            color: 填充颜色的十六进制字符串（如 "#FFFFFF"），默认为 None（白色）。
        """
        self.rect = rect
        if color:
            self.color = (Eraser.rgba_to_tuple(color))
        else:
            self.color = (255, 255, 255)

    @staticmethod
    def rgba_to_tuple(rgba_str):
        """将 RGBA 十六进制字符串转换为 BGR 元组

        Args:
            rgba_str: RGBA 十六进制字符串，如 "#RRGGBBAA" 或 "#RRGGBB"。

        Returns:
            tuple: BGR 颜色值元组 (B, G, R)，值范围 0-1。

        Raises:
            ValueError: 当字符串格式不正确时抛出。
        """
        if rgba_str[0] != "#":
            raise ValueError("RGBA string should start with '#'")

        # 去除开头的 '#'
        rgba_str = rgba_str[1:]

        # 检查字符串长度是否为7（包括透明度）或4（不包括透明度）
        if len(rgba_str) not in [7, 4]:
            raise ValueError("Invalid RGBA string length")

        # 将RGBA字符串拆分为R, G, B, 和 A 部分
        if len(rgba_str) == 7:
            r, g, b, a = rgba_str[:2], rgba_str[2:4], rgba_str[4:6], rgba_str[6:]
        else:
            r, g, b = rgba_str[:2], rgba_str[2:4], rgba_str[4:]
            a = "FF"  # 默认完全不透明

        # 将十六进制字符串转换为整数，然后除以255以获取0-1范围内的值
        r, g, b, a = (int(c, 16) / 255.0 for c in [r, g, b, a])

        # 返回包含RGBA值的元组
        return b, g, r

    @staticmethod
    def wipe(rect: list, img_file: str = None, cv_img=None, new_color: str = None):
        """擦除图像中指定区域

        将指定矩形区域填充为新颜色。可从文件或 numpy 数组输入图像。

        Args:
            rect: 擦除区域 [left, top, right, bottom]。
            img_file: 图片文件路径，默认为 None。
            cv_img: OpenCV 图像数组，默认为 None。
            new_color: 填充颜色元组 (B, G, R)，默认为 None（白色）。

        Returns:
            numpy.ndarray: 擦除后的图像数组。
        """
        if cv_img is not None:
            pass
        elif img_file:
            cv_img = cv2.imread(img_file)
        else:
            pass

        if new_color is None:
            new_color = (255, 255, 255)

        height, width, channels = cv_img.shape

        left = max(0, rect[0])
        top = max(0, rect[1])
        right = min(width - 1, rect[2])
        bottom = min(height - 1, rect[3])

        # 遍历指定区域内的每个像素，并将其设置为新的颜色
        for y in range(top, bottom + 1):
            for x in range(left, right + 1):
                cv_img[y, x] = new_color

        if img_file:
            cv2.imwrite(img_file, cv_img)

        return cv_img

    def run(self, cv_image: np.ndarray, offset_x: int = 0, offset_y: int = 0, data=None) -> Result:
        """执行橡皮擦操作

        Args:
            cv_image: 输入图像的 numpy 数组。
            offset_x: X 坐标偏移量，默认 0。
            offset_y: Y 坐标偏移量，默认 0。
            data: 上一步传递的附加数据，默认为 None。

        Returns:
            Result: 擦除后的图像。
        """
        cv_image = Eraser.wipe(self.rect, cv_img=cv_image, new_color=self.color)
        return Result(cv_image, offset_x, offset_y, data)


class OcrX(GPTask):
    """点阵字库识别任务

    使用自定义点阵字库进行文字识别，支持字库制作、字库测试和正式识别。
    """

    name = "点阵识字"
    ui_path = "/website/gpui/ocr_x/"

    def __init__(self, fontlib: str = None, make_font_colors: str = None, rect: list = None,
                 save_font_code: dict = None, test_fontlib: dict = None):
        """初始化点阵字库识别任务

        Args:
            fontlib: 字库文件路径，用于正式识别，默认为 None。
            make_font_colors: 制作字库时使用的颜色描述字符串，默认为 None。
            rect: 识别区域 [left, top, right, bottom]，默认为 None（全图）。
            save_font_code: 保存字库编码的字典配置，包含 model、font_lib_name、font_code 字段，默认为 None。
            test_fontlib: 测试字库的字典配置，包含 model、font_lib_name 字段，默认为 None。
        """
        self.fontlib = fontlib
        self.make_font_colors = make_font_colors
        self.rect = rect
        self.save_font_code = save_font_code
        self.test_fontlib = test_fontlib

    @staticmethod
    def append_to_lib(lib_path, content):
        """向字库文件追加内容

        如果文件不存在则创建，文件为空则直接写入，否则换行追加。

        Args:
            lib_path: 字库文件路径。
            content: 要追加的字库编码内容。

        Returns:
            无返回值。
        """
        try:
            # 尝试打开文件以读取模式，这将检查文件是否存在
            with open(lib_path, 'r') as file:
                file_content = file.read()

            # 如果文件内容为空，使用写入模式覆盖文件
            if file_content == '':
                with open(lib_path, 'w') as file:
                    file.write(content)
            else:
                # 如果文件不为空，使用追加模式在文件末尾添加新内容前加换行符
                with open(lib_path, 'a') as file:
                    file.write('\n' + content)
        except FileNotFoundError:
            # 如果文件不存在，则创建文件并写入内容
            with open(lib_path, 'w') as file:
                file.write(content)

    def run(self, cv_image: np.ndarray, offset_x: int = 0, offset_y: int = 0, data=None) -> Result:
        """执行点阵字库识别

        根据初始化参数执行不同操作：制作字库、保存字库编码、测试字库或正式识别。

        Args:
            cv_image: 输入图像的 numpy 数组。
            offset_x: X 坐标偏移量，默认 0。
            offset_y: Y 坐标偏移量，默认 0。
            data: 上一步传递的附加数据，默认为 None。

        Returns:
            Result: 识别结果，data 内容取决于操作类型。
        """

        if self.rect:
            x, y, r, b = self.rect
            offset_x = x
            offset_y = y
            cv_image = cv_image[y:b, x:r]

        if self.make_font_colors:
            cv_bitmap = cvimage_to_bitmap(cv_image)
            f_bitmap = asOcrx.make_font_bimtmap(cv_bitmap, self.make_font_colors)
            # data = asOcrx.make_font(cv_bitmap, self.make_font_colors)
            data = {"make_font_colors": asOcrx.make_font(cv_bitmap, self.make_font_colors)}
            cv_image = bitmap_to_cvimage(f_bitmap)

        if self.save_font_code:
            model = self.save_font_code["model"]
            font_lib = self.save_font_code["font_lib_name"]
            font_code = self.save_font_code["font_code"]
            lib_file = R.sd(f"airscript/model/{model}/res/{font_lib}")
            print(lib_file)
            OcrX.append_to_lib(lib_file, font_code)
            data = {"save_font_code": True}

        if self.test_fontlib:
            model = self.test_fontlib["model"]
            font_lib = self.test_fontlib["font_lib_name"]
            lib_file = R.sd(f"airscript/model/{model}/res/{font_lib}")
            cv_bitmap = cvimage_to_bitmap(cv_image)
            data = {"test_fontlib": asOcrx.ocrx(lib_file, cv_bitmap, offset_x, offset_y, 90).getText()}

        if self.fontlib:
            cv_bitmap = cvimage_to_bitmap(cv_image)
            data = asOcrx.ocrx(self.fontlib, cv_bitmap, offset_x, offset_y, 90)

        return Result(cv_image, offset_x, offset_y, data)

    @staticmethod
    def find_all(font_lib: str, rect: list = None, region=0.9):
        """使用点阵字库识别所有文字

        Args:
            font_lib: 字库文件路径。
            rect: 识别区域 [left, top, right, bottom]，默认为 None（全图）。
            region: 识别相似度阈值，默认 0.9。

        Returns:
            str: 识别出的文字内容，异常时返回 None。
        """
        try:
            if rect:
                x, y, r, b = rect
                bitmap = capture(x, y, r, b)
            else:
                x = 0
                y = 0
                bitmap = capture()

            res = asOcrx.ocrx(font_lib, bitmap, x, y, int(region * 100))

            return res.getText()
        except Exception as e:
            print(str(e))
            return None
