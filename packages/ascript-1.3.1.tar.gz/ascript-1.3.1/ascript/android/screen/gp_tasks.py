import json
from .gp import GPTask, Result
import numpy as np
import cv2
import random
from ascript.android.screen import ascv
from ascript.android import plug
from airscript.system import R as asR


class Crop(GPTask):
    """图片裁剪任务

    从输入图像中裁剪出指定矩形区域。
    """

    name = "图片裁剪"
    ui_path = "/website/gpui/crop/"

    def __init__(self, left: int, top: int, right: int, bottom: int):
        """初始化裁剪任务

        Args:
            left: 裁剪区域左边界 X 坐标。
            top: 裁剪区域上边界 Y 坐标。
            right: 裁剪区域右边界 X 坐标。
            bottom: 裁剪区域下边界 Y 坐标。
        """
        self.left = left
        self.top = top
        self.right = right
        self.bottom = bottom

    def run(self, cv_image: np.ndarray, offset_x: int = 0, offset_y: int = 0, data=None) -> Result:
        """执行图片裁剪

        Args:
            cv_image: 输入图像的 numpy 数组。
            offset_x: X 坐标偏移量，默认 0。
            offset_y: Y 坐标偏移量，默认 0。
            data: 上一步传递的附加数据，默认为 None。

        Returns:
            Result: 裁剪后的图像和更新后的坐标偏移。

        Raises:
            ValueError: 当右边界小于左边界或下边界小于上边界时抛出。
        """
        start_x, start_y = self.left, self.top
        width, height = self.right - self.left, self.bottom - self.top

        if self.right < self.left or self.bottom < self.top:
            raise ValueError("尺寸异常")

        # 使用NumPy数组切片进行裁剪
        cropped_image = cv_image[start_y:start_y + height, start_x:start_x + width]
        return Result(cropped_image, self.left + offset_x, self.top + offset_y, data)


class GrayImage(GPTask):
    """灰度图转换任务

    将彩色图像转换为灰度图像。
    """

    name = "灰度图"
    ui_path = "/website/gpui/grayimage/"

    def __init__(self):
        """初始化灰度图转换任务"""
        pass

    def run(self, cv_image: np.ndarray, offset_x: int = 0, offset_y: int = 0, data=None) -> Result:
        """执行灰度图转换

        Args:
            cv_image: 输入图像的 numpy 数组（BGR 三通道）。
            offset_x: X 坐标偏移量，默认 0。
            offset_y: Y 坐标偏移量，默认 0。
            data: 上一步传递的附加数据，默认为 None。

        Returns:
            Result: 转换后的灰度图像。

        Raises:
            Exception: 当输入图像不是三通道时抛出。
        """
        num_channels = cv_image.shape[2]
        if (num_channels == 3):
            gray_img = cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)
        else:
            raise Exception("颜色通道错误")
        return Result(gray_img, offset_x, offset_y, data)


class Threshold(GPTask):
    """二值化处理任务

    将图像转换为黑白二值图像，支持正向和反向二值化。
    """

    name = "二值化"
    ui_path = "/website/gpui/threshold/"

    def __init__(self, threshold: int, inv: bool = False):
        """初始化二值化任务

        Args:
            threshold: 二值化阈值，像素值大于此值为白色（或反转），范围 0-255。
            inv: 是否反转二值化结果，默认 False。
        """
        self.threshold = threshold
        self.inv = inv

    def run(self, cv_image: np.ndarray, offset_x: int = 0, offset_y: int = 0, data=None) -> Result:
        """执行二值化处理

        Args:
            cv_image: 输入图像的 numpy 数组。
            offset_x: X 坐标偏移量，默认 0。
            offset_y: Y 坐标偏移量，默认 0。
            data: 上一步传递的附加数据，默认为 None。

        Returns:
            Result: 二值化后的图像。
        """

        if len(cv_image.shape) != 2:
            cv_image = cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)

        method = cv2.THRESH_BINARY

        if self.inv:
            method = cv2.THRESH_BINARY_INV

        ret, thresholded_image = cv2.threshold(cv_image, self.threshold, 255, method)

        return Result(thresholded_image, offset_x, offset_y, data)


class Erode(GPTask):
    """图像腐蚀任务

    使用形态学腐蚀操作缩小图像中的白色区域，消除小的白色噪点。
    """

    name = "腐蚀"
    ui_path = "/website/gpui/erode/"

    def __init__(self, kernel_size: int = 5, iterations: int = 1):
        """初始化腐蚀任务

        Args:
            kernel_size: 腐蚀核的大小，默认 5。
            iterations: 腐蚀迭代次数，默认 1。
        """
        self.kernel = np.ones((kernel_size, kernel_size), np.uint8)
        self.iterations = iterations

    def run(self, cv_image: np.ndarray, offset_x: int = 0, offset_y: int = 0, data=None) -> Result:
        """执行腐蚀操作

        Args:
            cv_image: 输入图像的 numpy 数组。
            offset_x: X 坐标偏移量，默认 0。
            offset_y: Y 坐标偏移量，默认 0。
            data: 上一步传递的附加数据，默认为 None。

        Returns:
            Result: 腐蚀处理后的图像。
        """
        erode_img = cv2.erode(cv_image, self.kernel, iterations=self.iterations)
        return Result(erode_img, offset_x, offset_y, data)


class Dilate(GPTask):
    """图像膨胀任务

    使用形态学膨胀操作扩大图像中的白色区域，填充小的黑色空洞。
    """

    name = "膨胀"
    ui_path = "/website/gpui/dilate/"

    def __init__(self, kernel_size: int = 5, iterations: int = 1):
        """初始化膨胀任务

        Args:
            kernel_size: 膨胀核的大小，默认 5。
            iterations: 膨胀迭代次数，默认 1。
        """
        self.kernel = np.ones((kernel_size, kernel_size), np.uint8)
        self.iterations = iterations

    def run(self, cv_image: np.ndarray, offset_x: int = 0, offset_y: int = 0, data=None) -> Result:
        """执行膨胀操作

        Args:
            cv_image: 输入图像的 numpy 数组。
            offset_x: X 坐标偏移量，默认 0。
            offset_y: Y 坐标偏移量，默认 0。
            data: 上一步传递的附加数据，默认为 None。

        Returns:
            Result: 膨胀处理后的图像。
        """
        erode_img = cv2.dilate(cv_image, self.kernel, iterations=self.iterations)
        return Result(erode_img, offset_x, offset_y, data)


class MorphClose(GPTask):
    """形态学闭运算任务

    先膨胀后腐蚀，用于填充前景物体中的小洞和连接邻近物体。
    """

    name = "闭运算"
    ui_path = "/website/gpui/morphclose/"

    def __init__(self, kernel_size: int = 5, iterations: int = 1):
        """初始化闭运算任务

        Args:
            kernel_size: 运算核的大小，默认 5。
            iterations: 迭代次数，默认 1。
        """
        self.kernel = np.ones((kernel_size, kernel_size), np.uint8)
        self.iterations = iterations

    def run(self, cv_image: np.ndarray, offset_x: int = 0, offset_y: int = 0, data=None) -> Result:
        """执行闭运算

        Args:
            cv_image: 输入图像的 numpy 数组。
            offset_x: X 坐标偏移量，默认 0。
            offset_y: Y 坐标偏移量，默认 0。
            data: 上一步传递的附加数据，默认为 None。

        Returns:
            Result: 闭运算处理后的图像。
        """
        closing = cv2.morphologyEx(cv_image, cv2.MORPH_CLOSE, self.kernel)
        return Result(closing, offset_x, offset_y, data)


class MorphOpen(GPTask):
    """形态学开运算任务

    先腐蚀后膨胀，用于消除小的噪点和分离邻近物体。
    """

    name = "开运算"
    ui_path = "/website/gpui/morphopen/"

    def __init__(self, kernel_size: int = 5, iterations: int = 1):
        """初始化开运算任务

        Args:
            kernel_size: 运算核的大小，默认 5。
            iterations: 迭代次数，默认 1。
        """
        self.kernel = np.ones((kernel_size, kernel_size), np.uint8)
        self.iterations = iterations

    def run(self, cv_image: np.ndarray, offset_x: int = 0, offset_y: int = 0, data=None) -> Result:
        """执行开运算

        Args:
            cv_image: 输入图像的 numpy 数组。
            offset_x: X 坐标偏移量，默认 0。
            offset_y: Y 坐标偏移量，默认 0。
            data: 上一步传递的附加数据，默认为 None。

        Returns:
            Result: 开运算处理后的图像。
        """
        closing = cv2.morphologyEx(cv_image, cv2.MORPH_OPEN, self.kernel)
        return Result(closing, offset_x, offset_y, data)


class GaussianBlur(GPTask):
    """高斯模糊任务

    对图像应用高斯模糊滤波，用于降噪和平滑处理。
    """

    name = "高斯模糊"
    ui_path = "/website/gpui/gaussianblur/"

    def __init__(self, ksize: int = 5, sigmaX: int = 0):
        """初始化高斯模糊任务

        Args:
            ksize: 高斯核大小，默认 5。
            sigmaX: X 方向的标准差，0 表示自动计算，默认 0。
        """
        self.kernel = (5, 5)
        self.sigmaX = sigmaX

    def run(self, cv_image: np.ndarray, offset_x: int = 0, offset_y: int = 0, data=None) -> Result:
        """执行高斯模糊

        Args:
            cv_image: 输入图像的 numpy 数组。
            offset_x: X 坐标偏移量，默认 0。
            offset_y: Y 坐标偏移量，默认 0。
            data: 上一步传递的附加数据，默认为 None。

        Returns:
            Result: 模糊处理后的图像。
        """
        blurred_image = cv2.GaussianBlur(cv_image, self.kernel, self.sigmaX)
        return Result(blurred_image, offset_x, offset_y, data)


class Canny(GPTask):
    """Canny 边缘检测任务

    使用 Canny 算法检测图像中的边缘，并提取轮廓信息。
    支持多种轮廓绘制模式和范围过滤条件。
    """

    name = "边缘检测"
    ui_path = "/website/gpui/canny/"
    RETR_TREE = cv2.RETR_TREE
    RETR_LIST = cv2.RETR_LIST
    RETR_EXTERNAL = cv2.RETR_EXTERNAL

    DRAW_NONE = 0
    DRAW_ALL = 1
    DRAW_RECT = 2
    DRAW_RECT_FILL = 3

    def __init__(self, low_threshold: int = 50, high_threshold: int = 150, mode: int = RETR_EXTERNAL,
                 draw: int = DRAW_ALL, desc: bool = False,
                 left_range: list = None, top_range: list = None,
                 width_range: list = None, height_range: list = None):
        """初始化 Canny 边缘检测任务

        Args:
            low_threshold: Canny 检测低阈值，默认 50。
            high_threshold: Canny 检测高阈值，默认 150。
            mode: 轮廓检索模式，默认 RETR_EXTERNAL（仅外部轮廓）。
            draw: 绘制模式，0=不绘制，1=绘制轮廓，2=绘制矩形，3=填充矩形，默认 1。
            desc: 是否在轮廓旁标注坐标和尺寸信息，默认 False。
            left_range: X 坐标过滤范围 [min, max]，默认为 None（不过滤）。
            top_range: Y 坐标过滤范围 [min, max]，默认为 None（不过滤）。
            width_range: 宽度过滤范围 [min, max]，默认为 None（不过滤）。
            height_range: 高度过滤范围 [min, max]，默认为 None（不过滤）。
        """
        self.low_t = low_threshold
        self.high_t = high_threshold
        self.mode = mode
        self.draw = draw
        self.left_range = left_range
        self.top_range = top_range
        self.width_range = width_range
        self.height_range = height_range
        self.desc = desc
        # print([self.left_range, self.top_range, self.width_range, self.height_range])

    @staticmethod
    def in_range(v, v_range: list, max_v):
        """判断值是否在指定范围内

        Args:
            v: 待检查的值。
            v_range: 范围列表 [min, max]，为 None 则始终返回 True。
            max_v: 范围上限的最大允许值。

        Returns:
            bool: 值是否在范围内。
        """
        if not v_range:
            return True

        if len(v_range) == 1:
            v_range.append(max_v)

        if v_range[1] < 1:
            v_range[1] = max_v

        if v_range[0] <= v <= v_range[1]:
            return True

        return False

    def run(self, cv_image: np.ndarray, offset_x: int = 0, offset_y: int = 0, data=None) -> Result:
        """执行边缘检测并提取轮廓

        Args:
            cv_image: 输入图像的 numpy 数组。
            offset_x: X 坐标偏移量，默认 0。
            offset_y: Y 坐标偏移量，默认 0。
            data: 上一步传递的附加数据（会被覆盖），默认为 None。

        Returns:
            Result: 绘制了轮廓的图像和检测到的轮廓数据列表，
                每个元素包含 x、y、w、h 字段。
        """
        # erode_img = cv2.ca(cv_image, self.kernel, iterations=self.iterations)

        data = []

        height, width = cv_image.shape[:2]
        edges = cv2.Canny(cv_image, self.low_t, self.high_t)
        contours, _ = cv2.findContours(edges, self.mode, cv2.CHAIN_APPROX_SIMPLE)
        for cnt in contours:
            x, y, w, h = cv2.boundingRect(cnt)

            if not Canny.in_range(x, self.left_range, width):
                continue

            if not Canny.in_range(y, self.top_range, height):
                continue

            if not Canny.in_range(w, self.width_range, width):
                continue

            if not Canny.in_range(w, self.height_range, width):
                continue

            if self.draw == Canny.DRAW_ALL:
                color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
                cv2.drawContours(cv_image, [cnt], -1, color=color, thickness=2)
            elif self.draw == Canny.DRAW_RECT:
                color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
                cv2.rectangle(cv_image, (x, y), (x + w, y + h), color, 2)
            elif self.draw == Canny.DRAW_RECT_FILL:
                color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
                cv2.rectangle(cv_image, (x, y), (x + w, y + h), (255, 255, 255), -1)
            # 获取边界框

            if self.desc:
                draw_text = f"xy:({x},{y}) wh:({w},{h})"
                cv2.putText(cv_image, draw_text, (x, y), cv2.FONT_HERSHEY_SIMPLEX, 1, color, thickness=2,
                            lineType=cv2.LINE_AA)

            data.append({
                "x": x,
                "y": y,
                "w": w,
                "h": h
            })

        return Result(cv_image, offset_x, offset_y, data)


class CvFontLib(GPTask):
    """图片字库识别任务

    通过模板匹配方式识别图像中的字符，使用预定义的字符图片作为字库。
    支持多行文字识别和按行分组输出。
    """

    name = "图片字库"
    ui_path = "/website/gpui/cvfontlib/"

    def __init__(self, part_img: list, font_lib: list, confidence: int = 0.95, rect: list = None, spacing: int = 5,
                 rgb: bool = False):
        """初始化图片字库识别任务

        Args:
            part_img: 字符模板图片路径列表。
            font_lib: 与模板图片一一对应的字符列表。
            confidence: 匹配置信度阈值，默认 0.95。
            rect: 识别区域 [left, top, right, bottom]，默认为 None（全图）。
            spacing: 行间距阈值，用于判断字符是否在同一行，默认 5。
            rgb: 是否使用彩色匹配，默认 False。
        """
        self.part_img = part_img
        self.font_lib = font_lib
        self.spacing = spacing
        self.confidence = confidence
        self.rect = rect
        self.rgb = rgb

    @staticmethod
    def sort_and_concatenate_chars(data):
        """按位置排序并拼接识别到的字符

        将所有识别到的字符按 Y 坐标分桶、X 坐标排序后拼接为字符串。

        Args:
            data: 字符匹配结果的嵌套列表。

        Returns:
            str: 按位置排序后拼接的字符串。
        """
        # print(data)

        # 提取所有字符的矩形框左边界和字符本身

        # print(data)

        chars_with_left_edge = [(char['rectangle'][0][0],
                                 (char['rectangle'][0][1] + (char['rectangle'][1][1] - char['rectangle'][0][1]) / 2),
                                 char['font']) for sublist in data for char in sublist]

        # print("????", chars_with_left_edge)

        # 根据左边界进行排序
        # sorted_chars = sorted(chars_with_left_edge, key=lambda x: (x[1], x[0]))

        # print(chars_with_left_edge)

        def bucketize_y(y, bucket_size=10):
            # 将y坐标分配到桶中，桶的大小为bucket_size
            return y // bucket_size * bucket_size

        # [(184, 339.5, '/'), (185, 337.5, '/'), (183, 341.5, '/')]

        # 排序键是一个元组：(y的桶值, x坐标)
        sorted_chars = sorted(chars_with_left_edge, key=lambda x: (bucketize_y(x[1]), x[0]))

        # 拼接font字段
        concatenated_font = ''.join(item[2] for item in sorted_chars)

        # print(concatenated_font, "??????")

        return concatenated_font

    @staticmethod
    def group_chars_by_distance(data, threshold=10):
        """按字符间距分组

        将识别到的字符按照水平间距分组为单词。

        Args:
            data: 字符匹配结果的嵌套列表。
            threshold: 字符间距阈值（像素），超过此值则分为不同组，默认 10。

        Returns:
            list[tuple]: 分组结果列表，每个元素为 (左边界坐标, 拼接字符串)。
        """
        # 提取所有字符的矩形框左边界和字符本身，并排序
        left_edges = sorted([(char['rectangle'][0][0], char['font']) for sublist in data for char in sublist])

        # 初始化结果列表和当前词组的起始左边界
        grouped_chars = []
        current_word = ''
        current_word_start_edge = None

        # 遍历排序后的左边界和字符
        for left_edge, char in left_edges:
            # 如果当前词组为空或当前字符与前一个字符的间距小于阈值
            if not current_word or (
                    current_word_start_edge is not None and left_edge - current_word_start_edge < threshold):
                # 添加字符到当前词组
                current_word += char
            else:
                # 如果间距大于或等于阈值，则将当前词组添加到结果列表中，并开始新的词组
                grouped_chars.append((current_word_start_edge, current_word))
                current_word = char
                current_word_start_edge = left_edge

                # 添加最后一个词组（如果有的话）
        if current_word:
            grouped_chars.append((current_word_start_edge, current_word))

        return grouped_chars

    def sort_group(self, data):
        """按行分组排序并拼接字符

        将识别到的字符按 Y 坐标分组为行，每行内按 X 坐标排序后拼接。

        Args:
            data: 字符匹配结果的嵌套列表。

        Returns:
            tuple: (完整拼接字符串, 所有字符的排序列表, 按行分组的字符串列表)。
        """
        # print('????-----s-', data)
        chars_with_left_edge = [(char['rectangle'][0][0],
                                 (char['rectangle'][0][1] + (char['rectangle'][1][1] - char['rectangle'][0][1]) / 2),
                                 char['font']) for sublist in data for char in sublist]

        # print("??????----", chars_with_left_edge)
        groups = []
        for c in chars_with_left_edge:
            center_y = c[1]
            match = False
            for i, g in enumerate(groups):
                if len(g) > 0 and abs(g[0][1] - center_y) < self.spacing:
                    groups[i].append(c)
                    match = True
                    break

            if not match:
                groups.append([c])

        groups.sort(key=lambda x: x[0][1])

        group_text = []
        for g in groups:
            g.sort(key=lambda x: x[0])
            temp_g = [tup[2] for tup in g]
            group_text.append(''.join(temp_g))

        concatenated_font = [item for sublist in groups for item in sublist]

        third_elements = [tup[2] for tup in concatenated_font]

        # 使用 join() 方法将提取出的元素拼接成一个字符串
        result_string = ''.join(third_elements)

        return result_string, concatenated_font, group_text

    def run(self, cv_image: np.ndarray, offset_x: int = 0, offset_y: int = 0, data=None) -> Result:
        """执行图片字库识别

        Args:
            cv_image: 输入图像的 numpy 数组。
            offset_x: X 坐标偏移量，默认 0。
            offset_y: Y 坐标偏移量，默认 0。
            data: 上一步传递的附加数据，默认为 None。

        Returns:
            Result: 识别结果，data 字段包含 text（识别文本）、words（详细匹配信息）、
                group（按行分组的文本列表）。未识别到文字时 data 为 None。
        """
        words = []
        index = -1

        if self.rect:
            x, y, r, b = self.rect
            cv_image = cv_image[y:b, x:r]

        image_copy = cv_image.copy()

        for img in self.part_img:
            index = index + 1
            res = ascv.find_all_template(image_copy, img, rect=self.rect, threshold=self.confidence, rgb=self.rgb)
            for r in res:
                r["font"] = self.font_lib[index]
                # 回填图片,不让
                x, y = r["rectangle"][0]
                r, b = r["rectangle"][3]
                # image = Image.fromarray(image_copy)
                # print(x, y, r, b)

                off_x = 0
                off_y = 0
                if self.rect:
                    off_x = self.rect[0]
                    off_y = self.rect[1]

                cv2.rectangle(image_copy, (x - off_x, y - off_y), (r - off_x, b - off_y), (0, 0, 0), -1)  # -1 表示填充整个矩形

            words.append(res)
        res, all_words, groups = self.sort_group(words)
        # res = CvFontLib.sort_and_concatenate_chars(words)

        # image_save = Image.fromarray(image_copy)
        # image_save.save("sdcard/1/4.png")

        data = {
            "text": res,
            "words": words,
            "group": groups
        }

        if res == "":
            data = None

        return Result(cv_image, offset_x, offset_y, data)



### 图像处理插件

def gp_list():
    """获取所有可用的图像处理插件列表

    收集所有内置 OpenCV 工具、图色工具、调试工程和云端插件的信息。

    Returns:
        list[dict]: 插件信息列表，每个元素包含 name（名称）、ui_path（UI 路径）、
            id（模块路径）、class_name（类名）、type（插件类型）等字段。
    """
    from ascript.android.screen import gp_tool
    gp_cv_list = []
    gp_s_list = []


    gp_cv_list.append("ascript.android.screen.gp_tasks.Crop")
    gp_cv_list.append("ascript.android.screen.gp_tasks.GrayImage")
    gp_cv_list.append("ascript.android.screen.gp_tasks.Threshold")
    gp_cv_list.append("ascript.android.screen.Eraser")
    gp_cv_list.append("ascript.android.screen.gp_tasks.GaussianBlur")
    gp_cv_list.append("ascript.android.screen.gp_tasks.Erode")
    gp_cv_list.append("ascript.android.screen.gp_tasks.Dilate")
    gp_cv_list.append("ascript.android.screen.gp_tasks.MorphOpen")
    gp_cv_list.append("ascript.android.screen.gp_tasks.MorphClose")

    gp_s_list.append("ascript.android.screen.FindColors")
    gp_s_list.append("ascript.android.screen.CompareColors")
    gp_s_list.append("ascript.android.screen.Colors")
    gp_s_list.append("ascript.android.screen.FindImages")
    gp_s_list.append("ascript.android.screen.Ocr")
    gp_s_list.append("ascript.android.screen.OcrX")
    gp_s_list.append("ascript.android.screen.gp_tasks.Canny")
    gp_s_list.append("ascript.android.screen.gp_tasks.CvFontLib")
    gp_s_list.append("ascript.android.screen.CodeScanner")

    class_list = []

    for gp_s in gp_cv_list:
        module_name, class_name = gp_s.rsplit('.', 1)
        module = gp_tool.load_or_reload_module(module_name)
        gp_class = getattr(module, class_name)
        dao = {"name": gp_class.name, "ui_path": gp_class.ui_path, "id": gp_s, "class_name": class_name, "type": "OpenCV工具"}
        class_list.append(dao)

    for gp_s in gp_s_list:
        module_name, class_name = gp_s.rsplit('.', 1)
        module = gp_tool.load_or_reload_module(module_name)
        gp_class = getattr(module, class_name)
        dao = {"name": gp_class.name, "ui_path": gp_class.ui_path, "id": gp_s, "class_name": class_name, "type": "图色工具"}
        class_list.append(dao)

    try:
        gp_module_list = list(asR.get_screen_plugs())
        gp_plugs = json.loads(asR.get_screen_line_plugs())
        for gp_s in gp_module_list:
            module_name, class_name = gp_s.rsplit('.', 1)
            try:
                module = gp_tool.load_or_reload_module(module_name)
                gp_class = getattr(module, class_name)
                dao = {"name": gp_class.name, "ui_path": gp_class.ui_path, "id": gp_s, "class_name": class_name,
                       "type": "调试工程"}
                class_list.append(dao)
            except Exception as e:
                print(e)

        if len(gp_plugs) > 0:
            import airscript_frame

        for key, value in gp_plugs.items():
            print(key, value)
            plug.load(key)
            for gp_s in value:
                module_name, class_name = gp_s.rsplit('.', 1)
                module = gp_tool.load_or_reload_module(module_name)
                gp_class = getattr(module, class_name)
                dao = {"name": gp_class.name, "ui_path": gp_class.ui_path, "id": gp_s, "class_name": class_name,
                       "type": "云端插件", "nv": key}
                class_list.append(dao)
    except Exception as e:
        print(e)

    return class_list


def gp_list_json():
    """获取所有可用插件列表的 JSON 字符串

    Returns:
        str: 插件列表的 JSON 格式字符串。
    """
    return json.dumps(gp_list())