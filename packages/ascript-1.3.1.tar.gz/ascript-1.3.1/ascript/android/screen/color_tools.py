import json
import time
import numpy as np
from PIL import Image


class ColorPoint:
    """颜色点类

    表示屏幕上一个带有颜色信息的坐标点，用于多点找色等操作。
    """

    def __init__(self, x, y, rgb=None, diff=None):
        """初始化颜色点

        Args:
            x: 点的 X 坐标。
            y: 点的 Y 坐标。
            rgb: RGB 颜色值列表，格式为 [r, g, b]，默认为 None。
            diff: 颜色容差值列表，格式为 [r, g, b]，默认为 None。
        """
        self.x = x
        self.y = y
        self.rgb = rgb
        self.diff = diff

    def __repr__(self):
        """返回颜色点的字符串表示

        Returns:
            str: JSON 格式的字符串，包含坐标和颜色信息。
        """
        return json.dumps({
            "x": self.x,
            "y": self.y,
            "rgb": self.rgb,
        })

    def __sub__(self, other):
        """计算两个颜色点的坐标差值

        用于将绝对坐标转换为相对于第一个点的偏移坐标。

        Args:
            other: 另一个 ColorPoint 对象，通常为基准点。

        Returns:
            ColorPoint: 当前对象（坐标已修改为偏移值）。
        """
        self.x = self.x - other.x
        self.y = self.y - other.y
        return self


class Point:
    """坐标点类

    表示屏幕上的一个二维坐标点。
    """

    def __init__(self, x, y):
        """初始化坐标点

        Args:
            x: 点的 X 坐标。
            y: 点的 Y 坐标。
        """
        self.x = x
        self.y = y


def hex_to_rgb(hex_color):
    """将十六进制颜色字符串转换为 RGB 列表

    Args:
        hex_color: 十六进制颜色字符串，如 "#FF0000" 或 "FF0000"。

    Returns:
        list: RGB 颜色值列表，格式为 [r, g, b]，每个值范围为 0-255。

    Raises:
        ValueError: 当十六进制颜色字符串长度不为 6 时抛出。
    """
    hex_color = hex_color.lstrip('#')
    length = len(hex_color)
    if length != 6:
        raise ValueError("Invalid hex color code '{}'".format(hex_color))
    r = int(hex_color[:2], 16)
    g = int(hex_color[2:4], 16)
    b = int(hex_color[4:], 16)
    return [r, g, b]


def ana_colors_r(colors_str: str):
    """解析颜色字符串为相对坐标的颜色点列表

    解析格式为 "x,y,color|x,y,color|..." 的颜色字符串，
    其中第二个及之后的颜色点坐标会转换为相对于第一个点的偏移。

    Args:
        colors_str: 颜色描述字符串，格式为 "x,y,RRGGBB[-偏色]|x,y,RRGGBB[-偏色]|..."。

    Returns:
        list[ColorPoint]: 解析后的颜色点列表，首个为绝对坐标，其余为相对偏移。
    """
    # 拆分颜色
    colors = []
    index = 0
    for color_str in colors_str.split('|'):
        # 将 RGB 颜色值转换为整数数组
        c_s = color_str.split(',')

        color = c_s[2]
        diff = None
        if '-' in color:
            color, diff = color.split('-')
            if diff:
                diff = hex_to_rgb(diff)

        if index == 0:
            colors.append(ColorPoint(int(c_s[0]), int(c_s[1]), hex_to_rgb(color), diff))
        else:
            colors.append(ColorPoint(int(c_s[0]), int(c_s[1]), hex_to_rgb(color), diff) - colors[0])

        index = index + 1

    return colors


def ana_colors(colors_str: str):
    """解析颜色字符串为绝对坐标的颜色点列表

    解析格式为 "x,y,color|x,y,color|..." 的颜色字符串，所有点保持绝对坐标。

    Args:
        colors_str: 颜色描述字符串，格式为 "x,y,RRGGBB[-偏色]|x,y,RRGGBB[-偏色]|..."。

    Returns:
        list[ColorPoint]: 解析后的颜色点列表，所有点为绝对坐标。
    """
    # 拆分颜色
    colors = []
    index = 0
    for color_str in colors_str.split('|'):
        # 将 RGB 颜色值转换为整数数组
        c_s = color_str.split(',')

        color = c_s[2]
        diff = None
        if '-' in color:
            color, diff = color.split('-')
            if diff:
                diff = hex_to_rgb(diff)

        colors.append(ColorPoint(int(c_s[0]), int(c_s[1]), hex_to_rgb(color), diff))

        index = index + 1

    return colors


def compare_color(color1, color2, diff):
    """比较两个颜色值是否在容差范围内

    Args:
        color1: 第一个颜色值（numpy 数组格式）。
        color2: 第二个颜色值（列表格式）。
        diff: 各通道的最大允许差值列表。

    Returns:
        bool: 如果所有通道差值都在容差范围内则返回 True，否则返回 False。
    """
    for i in range(2):
        if abs(color1[i].astype(np.int32) - color2[i]) > diff[i]:
            return False
    return True


def check_color(colors, y, x, h, w, diff, image: np.ndarray):
    """检查指定坐标处的多点颜色是否全部匹配

    以第一个颜色点为基准，检查所有颜色点在图像中对应位置的颜色是否匹配。

    Args:
        colors: 颜色点列表，第一个为基准点，其余为相对偏移点。
        y: 基准点在图像中的 Y 坐标。
        x: 基准点在图像中的 X 坐标。
        h: 图像高度。
        w: 图像宽度。
        diff: 默认颜色容差值列表。
        image: numpy 数组格式的图像数据。

    Returns:
        bool: 所有颜色点都匹配则返回 True，否则返回 False。
    """
    color = colors[0]
    if compare_color(image[y, x], color.rgb, diff if color.diff is None else color.diff):
        for i in range(1, len(colors)):
            color = colors[i]
            ny = color.y + y
            nx = color.x + x
            if nx < 0 or ny < 0 or nx >= w or ny >= h:
                return False
            if not compare_color(image[ny, nx], color.rgb, diff if color.diff is None else color.diff):
                return False
        return True
    return False


def check_space(y, x, space_blocks):
    """检查坐标是否在已占用的空间块之外

    用于避免在已找到匹配的区域附近重复查找。

    Args:
        y: 待检查的 Y 坐标。
        x: 待检查的 X 坐标。
        space_blocks: 已占用的空间块列表，每个块为 (y_min, y_max, x_min, x_max)。

    Returns:
        bool: 如果坐标不在任何已占用空间块内则返回 True。
    """
    for block in space_blocks:
        if block[0] < y < block[1] and block[2] < x < block[3]:
            return False

    return True


def find_colors(colors: str, rect: tuple = None, space: int = 5, ori: int = 2, diff: list = (5, 5, 5), num=-1,
                image: Image.Image = None):
    """在图像中进行多点找色

    根据指定的颜色描述字符串，在图像中搜索匹配的颜色点组合。
    支持 8 个方向的扫描顺序和区域限定。

    Args:
        colors: 颜色描述字符串，格式为 "x,y,RRGGBB|x,y,RRGGBB|..."。
        rect: 搜索区域 [left, top, right, bottom]，默认为全图。
        space: 相邻匹配结果的最小间距（像素），默认 5。
        ori: 扫描方向（1-8），2 为从上到下从左到右，默认 2。
        diff: 各通道颜色容差值，默认 (5, 5, 5)。
        num: 最大返回结果数量，-1 表示不限制。
        image: PIL Image 图像对象。

    Returns:
        list[Point]: 匹配到的坐标点列表。
    """
    colors = ana_colors_r(colors)

    image = np.array(image)
    rows, cols, _ = image.shape
    if ori == 1:
        pass
    points = []
    points_block = []

    if rect is None:
        rect = [0, 0, cols, rows]
    print("start", time.time())

    if ori == 1:
        for x in range(rect[0], rect[2]):
            for y in range(rect[1], rect[3]):
                if check_space(y, x, points_block) and check_color(colors, y, x, rows, cols, diff, image):
                    points.append(Point(x, y))
                    if num != -1 and len(points) >= num:
                        return points
                    points_block.append((y - space, y + space, x - space, x + space))
    elif ori == 2:
        for y in range(rect[1], rect[3]):
            for x in range(rect[0], rect[2]):
                if check_space(y, x, points_block) and check_color(colors, y, x, rows, cols, diff, image):
                    points.append(Point(x, y))
                    if num != -1 and len(points) >= num:
                        return points
                    points_block.append((y - space, y + space, x - space, x + space))
    elif ori == 3:
        for y in range(rect[1], rect[3]):
            for x in range(rect[2] - 1, rect[0], -1):
                if check_space(y, x, points_block) and check_color(colors, y, x, rows, cols, diff, image):
                    points.append(Point(x, y))
                    if num != -1 and len(points) >= num:
                        return points
                    points_block.append((y - space, y + space, x - space, x + space))
    elif ori == 4:
        for x in range(rect[2] - 1, rect[0], -1):
            for y in range(rect[1], rect[3]):
                if check_space(y, x, points_block) and check_color(colors, y, x, rows, cols, diff, image):
                    points.append(Point(x, y))
                    if num != -1 and len(points) >= num:
                        return points
                    points_block.append((y - space, y + space, x - space, x + space))
    elif ori == 5:
        for x in range(rect[2] - 1, rect[0], -1):
            for y in range(rect[3] - 1, rect[1], -1):
                if check_space(y, x, points_block) and check_color(colors, y, x, rows, cols, diff, image):
                    points.append(Point(x, y))
                    if num != -1 and len(points) >= num:
                        return points
                    points_block.append((y - space, y + space, x - space, x + space))
    elif ori == 6:
        for y in range(rect[3] - 1, rect[1], -1):
            for x in range(rect[2] - 1, rect[0], -1):
                if check_space(y, x, points_block) and check_color(colors, y, x, rows, cols, diff, image):
                    points.append(Point(x, y))
                    if num != -1 and len(points) >= num:
                        return points
                    points_block.append((y - space, y + space, x - space, x + space))
    elif ori == 7:
        for y in range(rect[3] - 1, rect[1], -1):
            for x in range(rect[0], rect[2]):
                if check_space(y, x, points_block) and check_color(colors, y, x, rows, cols, diff, image):
                    points.append(Point(x, y))
                    if num != -1 and len(points) >= num:
                        return points
                    points_block.append((y - space, y + space, x - space, x + space))

    elif ori == 8:
        for x in range(rect[0], rect[2]):
            for y in range(rect[3] - 1, rect[1], -1):
                if check_space(y, x, points_block) and check_color(colors, y, x, rows, cols, diff, image):
                    points.append(Point(x, y))
                    if num != -1 and len(points) >= num:
                        return points
                    points_block.append((y - space, y + space, x - space, x + space))
    # if ori == 2:

    print("end", time.time())

    return points
