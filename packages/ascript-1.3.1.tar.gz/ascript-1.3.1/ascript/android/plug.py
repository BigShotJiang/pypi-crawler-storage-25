import importlib
import os
import sys
import time

from airscript.system import Plug as asPlug


def load(plug_and_version: str):
    """加载指定的插件模块。

    根据插件名称和版本号从服务端下载并动态加载插件。

    Args:
        plug_and_version: 插件名称和版本号，格式为 "插件名:版本号"，例如 "alimedia:1.0"。

    Returns:
        插件加载结果。
    """
    res = asPlug.load(plug_and_version)
    name = plug_and_version.split(':')[0]
    load_module_dynamically(name, asPlug.getLinePlugDir(), True)
    return res


def load_module_dynamically(module_name, download_dir, is_package=False, max_retries=5, retry_delay=0.5):
    """
    动态加载模块，处理潜在的下载和导入问题。

    Args:
        module_name (str): 要导入的模块名 (如果是包，则是包名)。
        download_dir (str): 模块文件或包所在的目录。
                           对于单个 .py 文件，这是包含 .py 文件的目录。
                           对于包，这是包含包文件夹的目录。
        is_package (bool): 下载的是否为一个包。
        max_retries (int): 检查文件是否存在的最大重试次数。
        retry_delay (float): 每次重试之间的延迟时间（秒）。
    Returns:
        module: 成功加载的模块对象，否则返回 None。
    """
    print(f"\n尝试加载模块: {module_name}")

    # 1. 确定模块的实际路径和需要检查的文件
    if is_package:
        # 如果是包，module_name 是包名，包在 download_dir/module_name/
        # sys.path 需要包含 download_dir
        # 检查文件是 download_dir/module_name/__init__.py
        module_path_to_check = os.path.join(download_dir, module_name, "__init__.pyc")
        path_to_add_to_sys = download_dir
    else:
        # 如果是单个模块文件，module_name.py 在 download_dir/
        # sys.path 需要包含 download_dir
        # 检查文件是 download_dir/module_name.py
        module_path_to_check = os.path.join(download_dir, f"{module_name}.py")
        path_to_add_to_sys = download_dir

    # 2. 等待文件完全可用 (轮询检查)
    for attempt in range(max_retries):
        if os.path.exists(module_path_to_check) and os.path.getsize(module_path_to_check) > 0:  # 确保文件存在且非空
            print(f"文件 {module_name} 已找到且非空。")
            break
        print(f"等待文件 {module_name} 可用... (尝试 {attempt + 1}/{max_retries})")
        time.sleep(retry_delay)
    else:
        print(f"错误: 文件 {module_name} 在 {max_retries * retry_delay} 秒后仍未准备好。")
        return None

    # 3. 将模块所在目录添加到 sys.path (如果尚未添加)
    #    对于包，是包的父目录；对于单个模块文件，是模块文件所在的目录。
    if path_to_add_to_sys not in sys.path:
        sys.path.insert(0, path_to_add_to_sys)  # 插入到开头，优先查找
        print(f"已将 '{module_name}' 添加到 sys.path")

    # 4. 清除导入缓存
    #    这非常重要，因为Python可能已经缓存了之前找不到该模块的信息
    importlib.invalidate_caches()
    print("Python 导入缓存已清除。")

    # 5. 尝试导入模块
    imported_module = None
    try:
        print(f"尝试导入模块 '{module_name}'...")
        imported_module = importlib.import_module(module_name)
        print(f"模块 '{module_name}' 成功导入！")
    except ImportError as e:
        print(f"导入模块 '{module_name}' 失败: {e}")
        # 如果添加了路径但导入失败，可以考虑将其从sys.path中移除
        # if path_to_add_to_sys in sys.path and sys.path[0] == path_to_add_to_sys:
        #     sys.path.pop(0)
    except Exception as e:
        print(f"加载模块 '{module_name}' 时发生未知错误: {e}")

    return imported_module


def load_apk(file_path: str):
    """加载外部 APK 文件作为插件。

    Args:
        file_path: APK 文件的绝对路径。

    Returns:
        加载结果。
    """
    return asPlug.load_apk(file_path)


def inject(file_path: str):
    """
    将外部包的 dex 注入到 App 主 ClassLoader。
    支持格式: .apk, .jar, .dex
    注入后可直接用 Chaquopy 的方式导入包中的类，例如：
        inject('/sdcard/xxx.apk')
        inject('/sdcard/libs/utils.jar')
        from com.thirdparty.sdk import SomeClass
        obj = SomeClass()
    已注入的文件重复调用无副作用。
    """
    asPlug.inject(file_path)


def load_apk_dir(file_path: str):
    """加载指定目录下的所有 APK 文件作为插件。

    Args:
        file_path: 包含 APK 文件的目录路径。

    Returns:
        加载结果。
    """
    return asPlug.load_apk_dir(file_path)
