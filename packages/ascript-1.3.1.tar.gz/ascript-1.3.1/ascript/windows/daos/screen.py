"""屏幕数据模型模块。

定义屏幕操作中使用的基础数据结构，包括坐标点、颜色、尺寸和 OCR 识别结果。
"""

import json


class Point:
    """屏幕坐标点。

    表示屏幕上的一个二维坐标点。
    """

    def __init__(self, x: int = 0, y: int = 0):
        """初始化坐标点。

        Args:
            x: 横坐标，默认为 0。
            y: 纵坐标，默认为 0。
        """
        self.x = x
        self.y = y

    def __str__(self):
        """返回坐标点的 JSON 字符串表示。

        Returns:
            str: 包含 x 和 y 的 JSON 字符串，例如 '{"x": 100, "y": 200}'。
        """
        return json.dumps({'x': self.x, 'y': self.y})

    def to_dict(self):
        """将坐标点转换为字典。

        Returns:
            dict: 包含 'x' 和 'y' 键的字典。
        """
        return {'x': self.x, 'y': self.y}


class Color:
    """颜色值。

    将十六进制颜色字符串解析为 RGB 分量。
    """

    def __init__(self, color: str):
        """初始化颜色对象。

        从十六进制颜色字符串（如 '#FF00AA'）中解析出 R、G、B 分量。

        Args:
            color: 十六进制颜色字符串，格式为 '#RRGGBB'。
        """
        self.r = int(color[1:3], 16)
        self.g = int(color[3:5], 16)
        self.b = int(color[5:], 16)

    def to_rgb(self):
        """将颜色转换为 RGB 列表。

        Returns:
            list: 包含 [R, G, B] 三个整数值的列表，每个值范围为 0-255。
        """
        return [self.r, self.g, self.b]


class Size:
    """尺寸大小。

    表示宽度和高度的二维尺寸。
    """

    def __init__(self, width, height):
        """初始化尺寸对象。

        Args:
            width: 宽度值。
            height: 高度值。
        """
        self.width = width
        self.height = height


class Point:
    """屏幕坐标点（重新定义）。

    表示屏幕上的一个二维坐标点，覆盖了之前定义的 Point 类。
    """

    def __init__(self, x: int = 0, y: int = 0):
        """初始化坐标点。

        Args:
            x: 横坐标，默认为 0。
            y: 纵坐标，默认为 0。
        """
        self.x = x
        self.y = y

    def __str__(self):
        """返回坐标点的 JSON 字符串表示。

        Returns:
            str: 包含 x 和 y 的 JSON 字符串。
        """
        return json.dumps({'x': self.x, 'y': self.y})

    def to_dict(self):
        """将坐标点转换为字典。

        Returns:
            dict: 包含 'x' 和 'y' 键的字典。
        """
        return {'x': self.x, 'y': self.y}


class OcrRes:
    """OCR 识别结果。

    封装单条 OCR 文字识别的结果，包括识别文本、置信度和区域位置信息。
    """

    def __init__(self, text: str = None, confidence: float = None, region_position: list = None):
        """初始化 OCR 识别结果。

        Args:
            text: 识别出的文本内容。
            confidence: 识别置信度，取值范围为 0.0 到 1.0。
            region_position: 文本区域的四个顶点坐标列表，
                格式为 [[x1,y1], [x2,y2], [x3,y3], [x4,y4]]。
        """
        self.text = text
        self.confidence = float(confidence)
        self.region_position = region_position
        if self.region_position:
            self.center_x = region_position[2][0] - region_position[0][0]
            self.center_y = region_position[2][1] - region_position[0][1]

    def to_dict(self):
        """将 OCR 结果转换为字典。

        Returns:
            dict: 包含 'text'、'confidence' 和 'region_position' 键的字典。
        """
        return {'text': self.text, 'confidence': self.confidence, 'region_position': self.region_position}

    def __str__(self):
        """返回 OCR 结果的字符串表示。

        Returns:
            str: OCR 结果字典的字符串形式。
        """
        return self.to_dict().__str__()

