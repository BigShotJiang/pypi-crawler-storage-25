"""窗口节点工具模块。

提供与 Windows 窗口枚举和节点操作相关的实用函数。
"""

import win32gui


def get_all_window(model: int):
    """获取所有窗口句柄。

    根据指定的模式枚举系统中所有顶层窗口。

    Args:
        model: 枚举模式，用于控制窗口枚举的方式。

    Returns:
        None: 当前实现未返回值（EnumWindows 缺少回调函数）。
    """
    win32gui.EnumWindows()
