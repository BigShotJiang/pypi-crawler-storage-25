"""屏幕颜色查找工具模块。

提供基于像素颜色的多点查找、颜色比较等屏幕图像分析功能。
支持多种扫描方向和相似度容差匹配。
"""

from PIL.Image import Image

from ascript.windows.daos.screen import Point, Color


def find_colors(colors: str, sim: float, max_points: int, ore: int, img: Image, space: int) -> list:
    """在图像中查找多点颜色匹配的位置。

    根据给定的多点颜色描述字符串，在图像中搜索匹配的位置。
    第一个点作为基准点，后续点的坐标相对于基准点计算偏移量。

    Args:
        colors: 多点颜色描述字符串，格式为 'x1,y1,#RRGGBB|x2,y2,#RRGGBB|...'，
            多个点之间用 '|' 分隔，每个点包含坐标和十六进制颜色值。
        sim: 颜色相似度，取值范围 0.0 到 1.0，1.0 表示完全匹配。
        max_points: 最大返回匹配点数，-1 表示不限制。
        ore: 扫描方向，取值 1-8，对应不同的扫描顺序。
        img: 待搜索的 PIL 图像对象。
        space: 找到匹配后的排除间距，避免重复匹配相邻区域。

    Returns:
        list: 匹配到的 Point 坐标点列表。
    """
    sim_space = 255 * (1 - sim)
    cs = colors.split('|')
    points = [None] * len(cs)
    for i in range(len(cs)):
        c = cs[i].split(',')
        if i == 0:
            points[i] = {'x': int(c[0]), 'y': int(c[1]), 'color': Color(c[2]).to_rgb()}
        else:
            points[i] = {'x': int(c[0]) - points[0]['x'], 'y': int(c[1]) - points[0]['y'],
                         'color': Color(c[2]).to_rgb()}

    return native_find_colors(sim_space, max_points, ore, img, points, space)


def compare_colors(colors: str, sim: float, img: Image):
    """比较图像中指定位置的颜色是否全部匹配。

    检查图像中多个指定坐标的像素颜色是否都在给定的相似度范围内。

    Args:
        colors: 多点颜色描述字符串，格式为 'x1,y1,#RRGGBB|x2,y2,#RRGGBB|...'。
        sim: 颜色相似度，取值范围 0.0 到 1.0。
        img: 待比较的 PIL 图像对象。

    Returns:
        bool: 所有点的颜色都匹配时返回 True，否则返回 False。
    """
    sim_space = 255 * (1 - sim)
    cs = colors.split('|')
    points = [None] * len(cs)
    for i in range(len(cs)):
        c = cs[i].split(',')
        points[i] = {'x': int(c[0]), 'y': int(c[1]), 'color': Color(c[2]).to_rgb()}

    for p in points:
        color = img.getpixel([p['x'], p['y']])
        if not compare_color(color, p['color'], sim_space):
            return False

    return True


def native_find_colors(sim: float, max_points: int, ore: int, img: Image, points: list, space: int) -> list:
    """原生多点颜色查找的核心实现。

    遍历图像像素，按照指定的扫描方向查找与多点颜色模式匹配的位置。
    支持 8 种不同的扫描方向（左上到右下、右下到左上等）。

    Args:
        sim: 颜色容差值（已转换为 0-255 范围），表示允许的最大颜色差异。
        max_points: 最大返回匹配点数，-1 表示不限制。
        ore: 扫描方向，取值 1-8：
            1 - 从左到右，从上到下；
            2 - 从上到下，从左到右；
            3 - 从上到下，从右到左；
            4 - 从右到左，从上到下；
            5 - 从右到左，从下到上；
            6 - 从下到上，从右到左；
            7 - 从下到上，从左到右；
            8 - 从左到右，从下到上。
        img: 待搜索的 PIL 图像对象。
        points: 多点颜色描述列表，每个元素为包含 'x'、'y'、'color' 的字典。
        space: 找到匹配后的排除间距。

    Returns:
        list: 匹配到的 Point 坐标点列表。
    """
    width = img.width
    height = img.height
    pixs = list(img.getdata())

    # print(len(pixs), width, height)

    fcs = []

    # print(ore)

    if ore == 1:
        for w in range(width):
            for h in range(height):
                if check_color(width, height, pixs, w, h, points, sim):
                    fcs.append(Point(w, h))
                    if len(fcs) >= max_points != -1:
                        return fcs
                    space_image(pixs, space, width, height, w, h)

    if ore == 2:
        for h in range(height):
            for w in range(width):
                if check_color(width, height, pixs, w, h, points, sim):
                    fcs.append(Point(w, h))
                    if len(fcs) >= max_points != -1:
                        return fcs
                    space_image(pixs, space, width, height, w, h)

    if ore == 3:
        for h in range(height):
            for w in reversed(range(width)):
                if check_color(width, height, pixs, w, h, points, sim):
                    fcs.append(Point(w, h))
                    if len(fcs) >= max_points != -1:
                        return fcs
                    space_image(pixs, space, width, height, w, h)

    if ore == 4:
        for w in reversed(range(width)):
            for h in range(height):
                if check_color(width, height, pixs, w, h, points, sim):
                    fcs.append(Point(w, h))
                    if len(fcs) >= max_points != -1:
                        return fcs
                    space_image(pixs, space, width, height, w, h)

    if ore == 5:
        for w in reversed(range(width)):
            for h in reversed(range(height)):
                if check_color(width, height, pixs, w, h, points, sim):
                    fcs.append(Point(w, h))
                    if len(fcs) >= max_points != -1:
                        return fcs
                    space_image(pixs, space, width, height, w, h)

    if ore == 6:
        for h in reversed(range(height)):
            for w in reversed(range(width)):
                if check_color(width, height, pixs, w, h, points, sim):
                    fcs.append(Point(w, h))
                    if len(fcs) >= max_points != -1:
                        return fcs
                    space_image(pixs, space, width, height, w, h)

    if ore == 7:
        for h in reversed(range(height)):
            for w in range(width):
                if check_color(width, height, pixs, w, h, points, sim):
                    fcs.append(Point(w, h))
                    if len(fcs) >= max_points != -1:
                        return fcs
                    space_image(pixs, space, width, height, w, h)

    if ore == 8:
        for w in range(width):
            for h in reversed(range(height)):
                if check_color(width, height, pixs, w, h, points, sim):
                    fcs.append(Point(w, h))
                    if len(fcs) >= max_points != -1:
                        return fcs
                    space_image(pixs, space, width, height, w, h)

    return fcs


def space_image(pixs, space, width, height, w, h):
    """将匹配点周围区域的像素标记为无效。

    在找到一个匹配点后，将其周围指定范围内的像素设置为 [-1, -1, -1]，
    防止在同一区域内重复匹配。

    Args:
        pixs: 图像像素数据列表，每个元素为 [R, G, B]。
        space: 排除的间距范围（像素数）。
        width: 图像宽度。
        height: 图像高度。
        w: 匹配点的横坐标。
        h: 匹配点的纵坐标。
    """
    x = w - space
    while x < w + space:
        x = x + 1
        if -1 < x < width:
            y = h - space
            while y < h + space:
                y = y + 1
                if x > -1 and y < height:
                    pixs[get_pix_forxy(width, x, y)] = [-1, -1, -1]


def check_color(width, height, pixs, x, y, points, sim):
    """检查指定位置是否满足多点颜色匹配条件。

    以 (x, y) 为基准点，检查该点及所有偏移点的颜色是否都在容差范围内。

    Args:
        width: 图像宽度。
        height: 图像高度。
        pixs: 图像像素数据列表。
        x: 基准点横坐标。
        y: 基准点纵坐标。
        points: 多点颜色描述列表，第一个为基准点，后续为偏移点。
        sim: 颜色容差值（0-255 范围）。

    Returns:
        bool: 所有点都匹配时返回 True，否则返回 False。
    """
    if compare_color(pixs[get_pix_forxy(width, x, y)], points[0]['color'], sim):

        i = 1
        while i < len(points):
            nx = points[i]['x'] + x
            ny = points[i]['y'] + y

            if nx < 0 or ny < 0 or nx >= width or ny >= height:
                return False

            if not (compare_color(pixs[get_pix_forxy(width, nx, ny)], points[i]['color'], sim)):
                return False

            i = i + 1

        return True

    return False


def get_pix_forxy(width, x, y):
    """根据二维坐标计算像素在一维数组中的索引。

    Args:
        width: 图像宽度。
        x: 横坐标。
        y: 纵坐标。

    Returns:
        int: 像素在一维像素数组中的索引位置。
    """
    return width * y + x


def compare_color(c1, c2, sim):
    """比较两个颜色是否在容差范围内相似。

    逐通道（R、G、B）比较两个颜色值的差异，判断是否在允许的容差范围内。
    如果 c1 已被标记为无效（[-1, -1, -1]），则直接返回 False。

    Args:
        c1: 第一个颜色值，格式为 [R, G, B]。
        c2: 第二个颜色值，格式为 [R, G, B]。
        sim: 颜色容差值（0-255 范围），每个通道允许的最大差异。

    Returns:
        bool: 两个颜色在容差范围内相似返回 True，否则返回 False。
    """
    if c1[0] == -1:
        return False

    # print(c1,c2)

    if abs(c1[0] - c2[0]) <= sim and abs(c1[1] - c2[1]) <= sim and abs(c1[2] - c2[2]) <= sim:
        return True

    return False
