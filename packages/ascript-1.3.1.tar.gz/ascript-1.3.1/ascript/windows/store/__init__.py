
def main():
    from ascript.windows.ui.app_store_window import AppStoreWindow
    import os

    def on_start(app_info, license_data):
        print(app_info)
        print(license_data)
        # package_name = "AScriptProject2"
        user_id = str(app_info["id"])
        file_md5 = app_info['fileMd5']

        is_ready = app_store.env_manager.smart_deploy(user_id, app_store.target_path, file_md5)
        if is_ready:
            app_store.env_manager.run_app(user_id)

    root_path = os.path.join(os.getcwd(), "apps")
    default_id = os.environ.get("ASCRIPT_APP_ID") or None
    app_store = AppStoreWindow(default_id=default_id, on_start=on_start, env_path=root_path)
    app_store.show()