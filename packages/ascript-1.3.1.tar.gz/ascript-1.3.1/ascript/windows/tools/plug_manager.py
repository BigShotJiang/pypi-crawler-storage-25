import eel
from ascript.windows.tools.gpplug.plug import GpPlug

class FindImagesPlug(GpPlug):
    """找图插件，用于在大图中定位小图的位置。"""
    name = "找图"
    description = "快速找到小图在大图中的位置"
    entry_html = "plugs/find_images.html"
    icon = "img/svg/find_images.svg"


class FindColorsPlug(GpPlug):
    """找色插件，用于通过颜色特征在图像中定位目标点位。"""
    name = "找色"
    description = "通过颜色特征,找到图像中的点位"
    entry_html = "plugs/find_colors.html"
    icon = "img/svg/find_colors.svg"


class RapidOCRPlug(GpPlug):
    """Rapid OCR 文字识别插件，用于识别图像中的文字内容。"""
    name = "Rapid文字识别"
    description = "传入图像,识别途中文字"
    entry_html = "plugs/rapidocr.html"
    icon = "img/svg/ocr.svg"


@eel.expose
def ascript_plug_list():
    """获取所有已注册的图形处理插件列表。

    实例化所有插件并将其转换为字典格式，供前端渲染插件菜单使用。

    Returns:
        list[dict]: 插件信息字典列表，每项包含 name、class_name、description、entry_html、icon 字段。
    """
    plugs = [FindImagesPlug(), FindColorsPlug(), RapidOCRPlug()]
    return [el.to_dict() for el in plugs]