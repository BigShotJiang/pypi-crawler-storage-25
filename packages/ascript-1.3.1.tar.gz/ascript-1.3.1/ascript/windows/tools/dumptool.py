import eel
import os
import sys
from ..window import  Window
from ..system import R

def start_vtree(hwnd: str = None, window_title: str = None):
    """启动 UI 元素树（VTree）查看器 Web 应用。

    初始化 Eel 框架并打开 VTree 页面，用于查看和分析目标窗口的 UI 元素层级结构。
    支持通过窗口句柄或窗口标题指定目标窗口。自动检测可用浏览器（Chrome/Edge）。

    Args:
        hwnd: 目标窗口句柄字符串。优先级高于 window_title。
        window_title: 目标窗口标题，用于自动查找窗口句柄。
    """
    # --- 核心修改：动态路径处理 ---
    web_folder =  R.internal("windows","tools","web") #paths.get_path("ascript/windows/tools/web/")

    if not os.path.exists(web_folder):
        print(f"错误：找不到 web 文件夹: {web_folder}")
        # 打印一下当前目录结构，方便在打包后的控制台排查
        # print(f"DEBUG: sys._MEIPASS = {getattr(sys, '_MEIPASS', 'N/A')}")
        # print(f"DEBUG: __file__ = {__file__}")
        return

    # --- 后续逻辑不变 ---
    if window_title:
        temp_window = Window.find(window_title)
        if temp_window:
            hwnd = temp_window.hwnd

    eel.init(web_folder)

    eel_kwargs_base = {
        'port': 0,
        'cmdline_args': ['--start-maximized', '--incognito']
    }

    url = f"vtree.html?hwnd={hwnd}" if hwnd else "vtree.html"

    try:
        for mode in ('chrome', 'edge', 'edgechromium'):
            try:
                eel.start(url, mode=mode, **eel_kwargs_base)
                break
            except OSError as e:
                if 'find' in str(e).lower() and 'installation' in str(e).lower():
                    continue
                raise
        else:
            print("错误：未检测到可用浏览器。请安装 Chrome 或 Edge 浏览器。")
    except (SystemExit, MemoryError, KeyboardInterrupt):
        pass