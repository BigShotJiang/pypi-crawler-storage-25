from abc import ABC, abstractmethod
class GpPlug(ABC):
    """图形处理插件基类（抽象类）。

    定义了所有图形处理插件必须实现的标准接口，包括名称、描述、
    入口页面和图标。子类必须实现所有抽象属性。
    """

    @property
    @abstractmethod
    def name(self):
        """插件显示名称。

        Returns:
            str: 插件的中文显示名称。
        """
        pass

    @property
    @abstractmethod
    def description(self):
        """插件功能描述。

        Returns:
            str: 插件功能的简要说明文本。
        """
        pass

    @property
    @abstractmethod
    def entry_html(self):
        """插件入口 HTML 文件的相对路径。

        Returns:
            str: 相对于 web 目录的 HTML 文件路径。
        """
        pass

    @property
    @abstractmethod
    def icon(self):
        """插件图标的相对路径。

        Returns:
            str: 相对于 web 目录的图标文件路径。
        """
        pass

    @property
    def class_name(self):
        """获取当前插件类的类名。

        Returns:
            str: 类名字符串，如 'FindImagesPlug'。
        """
        return self.__class__.__name__

    def to_dict(self):
        """将插件的所有属性转换为字典，方便序列化为 JSON。

        Returns:
            dict: 包含 name、class_name、description、entry_html、icon 字段的字典。
        """
        return {
            "name": self.name,
            "class_name": self.class_name,
            "description": self.description,
            "entry_html": self.entry_html,
            "icon": self.icon
        }