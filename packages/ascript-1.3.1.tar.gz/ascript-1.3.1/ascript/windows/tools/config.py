"""工具模块配置文件。

定义工具运行所需的临时目录路径（截图目录、临时数据目录），
并在模块加载时自动创建所需的目录结构。

模块属性:
    file_root_path (str): 临时文件根目录，位于系统临时目录下的 ascript 子目录。
    file_capture_dir (str): 截图保存目录。
    file_data_temp (str): 临时数据目录。
"""

import os
import tempfile

# 1. 定义路径
file_root_path = os.path.join(tempfile.gettempdir(), "ascript")
file_capture_dir = os.path.join(file_root_path, "capture")
file_data_temp = os.path.join(file_root_path, "temp")

# 2. 判断并创建文件夹
# 创建根目录及其子目录
# os.makedirs 会自动创建中间路径（递归创建）
os.makedirs(file_capture_dir, exist_ok=True)
os.makedirs(file_data_temp, exist_ok=True)

# print(f"路径已就绪: {file_capture_dir}")