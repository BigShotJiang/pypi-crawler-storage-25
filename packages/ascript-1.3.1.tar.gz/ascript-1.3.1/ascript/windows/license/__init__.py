"""许可证加密模块。

提供基于 AES 加密的许可证验证功能，包括加密通信和数据填充工具。

Exports:
    achttp: 加密 HTTP 通信模块。
    AES: AES 加密算法。
    pad: PKCS7 数据填充函数。
    unpad: PKCS7 数据去填充函数。
"""

from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from . import achttp

__all__ = ['achttp', "AES", "pad", "unpad"]