# sub_print_capture.py
from multiprocessing import Queue, current_process
import sys
import threading
import os

# 全局队列，用于进程间传递打印内容
_print_queue = None
# 标记是否为主进程
_is_main = False

class QueueStream:
    """重定向 stdout/stderr 的流对象，将输出内容写入进程间队列。

    用于子进程中替代标准输出/错误流，使子进程的 print 输出能够
    通过队列传递到主进程统一处理。

    Args:
        queue: multiprocessing.Queue 实例，用于进程间传递打印内容。
        stream_type: 流类型标识，可选 "stdout" 或 "stderr"，默认 "stdout"。
    """

    def __init__(self, queue, stream_type="stdout"):
        """初始化队列流对象。

        Args:
            queue: multiprocessing.Queue 实例，用于进程间传递打印内容。
            stream_type: 流类型标识，可选 "stdout" 或 "stderr"，默认 "stdout"。
        """
        self.queue = queue
        self.stream_type = stream_type
        self.origin_stream = sys.stdout if stream_type == "stdout" else sys.stderr

    def write(self, msg):
        """将非空消息写入队列。

        Args:
            msg: 要写入的消息字符串。
        """
        if msg.strip():  # 过滤空行
            # 传递：进程ID+进程名+输出类型+内容
            self.queue.put({
                "pid": os.getpid(),
                "pname": current_process().name,
                "type": self.stream_type,
                "msg": msg
            })

    def flush(self):
        """刷新流缓冲区（兼容 print 的 flush=True，无实际操作）。"""
        # 兼容print的flush=True，无实际操作
        pass

    def isatty(self):
        """判断是否为终端设备。

        Returns:
            bool: 返回原始流的 isatty() 结果，兼容终端判断。
        """
        # 兼容终端判断，避免部分库报错
        return self.origin_stream.isatty()

def init_main(listen_callback=None):
    """主进程初始化：创建进程间共享队列并启动监听线程。

    在主进程中调用一次即可。创建用于接收子进程输出的队列，
    并启动后台线程持续监听子进程的打印内容。

    Args:
        listen_callback: 自定义监听回调函数，默认为 None。
            若为 None，则使用内置的默认监听函数将子进程输出打印到主进程终端。
    """
    global _print_queue, _is_main
    if _is_main:
        return
    _print_queue = Queue()
    _is_main = True

    # 自定义监听回调，默认打印到主进程终端
    def default_listen():
        while True:
            try:
                data = _print_queue.get()
                if data is None:  # 结束标记
                    break
                # 格式化输出，可自定义
                prefix = f"[子进程{data['pid']}-{data['pname']}][{data['type']}]"
                print(f"{prefix} {data['msg']}", end="")
            except Exception:
                break

    # 启动监听线程
    listen_fun = listen_callback or default_listen
    t = threading.Thread(target=listen_fun, daemon=True)
    t.start()

def init_sub():
    """子进程初始化：将 stdout/stderr 重定向到共享队列。

    在子进程中自动执行（模块导入时触发），将标准输出和标准错误
    重定向为 QueueStream 对象，使子进程的所有 print 输出
    通过队列传递到主进程。主进程中调用无效。
    """
    global _print_queue
    if _print_queue is None:
        return  # 主进程未初始化，不处理
    if current_process().name == "MainProcess":
        return  # 跳过主进程

    # 重定向标准输出/错误
    sys.stdout = QueueStream(_print_queue, "stdout")
    sys.stderr = QueueStream(_print_queue, "stderr")

# 子进程引入模块时，自动执行重定向
init_sub()