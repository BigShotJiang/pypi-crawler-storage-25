import sys
import os
from pathlib import Path
import ascript  # 必须导入你的包以定位其物理位置
import sys
import ctypes

class R:
    """资源路径解析器。

    提供统一的资源文件路径解析能力，自动适配开发环境和打包环境
    （支持 PyInstaller 和 Nuitka）。分为两类接口：
    - 开发者接口（ui/img/res）：锚定工程根目录下的 res/ 文件夹。
    - 内部接口（internal）：锚定 ascript 包的安装目录。

    Attributes:
        _BASE_DIR: 缓存的工程根目录路径。
        _PKG_ROOT: ascript 包的物理安装根目录。
    """
    _BASE_DIR = None
    # 静态定位 ascript 包的物理根目录 (site-packages/ascript)
    _PKG_ROOT = Path(os.path.dirname(os.path.abspath(ascript.__file__))).resolve()

    @classmethod
    def get_root(cls) -> Path:
        """获取工程根目录或打包后的解压临时目录。

        自动检测运行环境：
        - Nuitka 打包：使用 NUITKA_ONEFILE_PARENT 环境变量。
        - PyInstaller 打包：使用 sys._MEIPASS。
        - 开发环境：使用 main.py 所在目录。

        Returns:
            Path: 工程根目录的绝对路径。
        """
        if cls._BASE_DIR is not None:
            return cls._BASE_DIR

        if getattr(sys, 'frozen', False):
            # Nuitka 优先环境变量
            nuitka_tmp = os.environ.get('NUITKA_ONEFILE_PARENT')
            if nuitka_tmp:
                cls._BASE_DIR = Path(nuitka_tmp).resolve()
            elif hasattr(sys, '_MEIPASS'):
                cls._BASE_DIR = Path(sys._MEIPASS).resolve()
            else:
                cls._BASE_DIR = Path(sys.executable).resolve().parent
        else:
            # 开发环境：锚定 main.py 所在目录
            main_file = sys.argv[0]
            if main_file:
                cls._BASE_DIR = Path(main_file).resolve().parent
            else:
                cls._BASE_DIR = Path.cwd().resolve()
        return cls._BASE_DIR

    @classmethod
    def _build_path(cls, base: Path, *sub_paths) -> str:
        """通用路径构建方法。

        拼接基准目录和子路径，路径不存在时输出警告。

        Args:
            base: 基准目录路径。
            *sub_paths: 子路径片段，依次拼接。

        Returns:
            str: 完整的文件路径字符串。
        """
        full_path = base.joinpath(*sub_paths)
        if not full_path.exists():
            # 这里的警告非常有意义，能帮开发者快速定位是缺文件还是路走错了
            print(f"⚠️ [R] 找不到路径: {full_path}")
            print(f"ℹ️ [R] 当前基准目录为: {base}")
        return str(full_path)

    # --- 1. 开发者使用的接口 (锚定工程根目录/res) ---

    @classmethod
    def ui(cls, path: str) -> str:
        """获取工程 res/ui/ 目录下的 UI 资源文件路径。

        Args:
            path: 相对于 res/ui/ 的文件路径。

        Returns:
            str: UI 资源文件的绝对路径。
        """
        return cls._build_path(cls.get_root(), "res", "ui", path)

    @classmethod
    def img(cls, path: str) -> str:
        """获取工程 res/img/ 目录下的图片资源文件路径。

        Args:
            path: 相对于 res/img/ 的文件路径。

        Returns:
            str: 图片资源文件的绝对路径。
        """
        return cls._build_path(cls.get_root(), "res", "img", path)

    @classmethod
    def res(cls, path: str) -> str:
        """获取工程 res/ 目录下的通用资源文件路径。

        Args:
            path: 相对于 res/ 的文件路径。

        Returns:
            str: 资源文件的绝对路径。
        """
        return cls._build_path(cls.get_root(), "res", path)

    # --- 2. ascript 内部使用的接口 (双重查找逻辑) ---

    @classmethod
    def internal(cls, *sub_paths) -> str:
        """查找 ascript 包内部资源文件路径。

        打包环境下优先在临时解压目录查找，未找到或开发环境下
        回退到包安装目录（site-packages）查找。

        Args:
            *sub_paths: 相对于 ascript 包根目录的子路径片段。

        Returns:
            str: 内部资源文件的绝对路径。
        """
        # A. 打包环境下的尝试 (寻找临时目录/ascript/xxx)
        if getattr(sys, 'frozen', False):
            # 注意：这里 sub_paths 前面通常要带上 "ascript"
            # 因为 Nuitka 会把整个包结构解压出来
            bundle_path = cls.get_root().joinpath("ascript", *sub_paths)
            if bundle_path.exists():
                return str(bundle_path)

        # B. 开发环境或兜底 (寻找 site-packages/ascript/xxx)
        return cls._build_path(cls._PKG_ROOT, *sub_paths)

    @classmethod
    def is_admin(cls):
        """判断当前进程是否拥有管理员权限。

        Returns:
            bool: 拥有管理员权限返回 True，否则返回 False。
        """
        try:
            return ctypes.windll.shell32.IsUserAnAdmin()
        except:
            return False

    @classmethod
    def run_as_admin(cls):
        """以管理员权限重新启动当前程序。

        如果当前进程不具有管理员权限，将通过 Windows UAC 弹窗
        请求提升权限并重新启动程序，当前进程随即退出。
        """
        if not cls.is_admin():
            # ShellExecuteEx 会触发系统 UAC 弹窗
            ctypes.windll.shell32.ShellExecuteW(
                None, "runas", sys.executable, " ".join(sys.argv), None, 1
            )
            sys.exit()