import os
import shutil
import threading
import subprocess
import sys
import ctypes
import psutil
import time
from pkginfo import Wheel  # 确保主环境已安装 pkginfo
import urllib


class EnvManager:
    """用户虚拟环境管理器。

    负责为每个用户创建独立的 Python 虚拟环境，支持 wheel 包的自动部署、
    应用启动与停止、运行状态监控等功能。每个用户通过 user_id 隔离环境。
    """

    def __init__(self, root_path=None):
        """初始化环境管理器。

        Args:
            root_path: 环境根目录路径，默认为当前工作目录下的 "user_envs" 文件夹。
                所有用户的虚拟环境和模块将存放在此目录下。
        """
        self.root_path = root_path or os.path.abspath(os.path.join(os.getcwd(), "user_envs"))
        self.module_dir = os.path.join(self.root_path, "module")
        if not os.path.exists(self.root_path):
            os.makedirs(self.root_path)

        if not os.path.exists(self.module_dir):
            os.makedirs(self.module_dir)

    def _get_pkg_name(self, wheel_path):
        """从 wheel 文件中提取 Python 包名。

        Args:
            wheel_path: .whl 文件的路径。

        Returns:
            str | None: 提取到的包名，失败时返回 None。
        """
        try:
            return Wheel(wheel_path).name
        except Exception as e:
            print(f"提取包名失败: {e}")
            return None

    def get_env_dir(self, user_id):
        """获取指定用户的虚拟环境目录路径。

        Args:
            user_id: 用户唯一标识。

        Returns:
            str: 虚拟环境目录的绝对路径。
        """
        return os.path.join(self.root_path, str(user_id))

    def get_model_dir(self, user_id):
        """获取指定用户的模块目录路径。

        Args:
            user_id: 用户唯一标识。

        Returns:
            str: 模块目录的绝对路径。
        """
        return os.path.join(self.module_dir, str(user_id))

    def get_python_exe(self, user_id):
        """获取指定用户虚拟环境中的 Python 可执行文件路径。

        Args:
            user_id: 用户唯一标识。

        Returns:
            str: Python 可执行文件的绝对路径。
        """
        base = self.get_env_dir(user_id)
        suffix = "Scripts\\python.exe" if sys.platform == "win32" else "bin/python"
        return os.path.join(base, suffix)

    def get_pip_exe(self, user_id):
        """获取指定用户虚拟环境中的 pip 可执行文件路径。

        Args:
            user_id: 用户唯一标识。

        Returns:
            str: pip 可执行文件的绝对路径。
        """
        base = self.get_env_dir(user_id)
        suffix = "Scripts\\pip.exe" if sys.platform == "win32" else "bin/pip"
        return os.path.join(base, suffix)

    def get_create_cmd(self, env_dir):
        """生成创建虚拟环境的命令字符串。

        Args:
            env_dir: 虚拟环境目标目录路径。

        Returns:
            str: 用于创建虚拟环境的 shell 命令。
        """
        return f'"{sys.executable}" -m virtualenv "{env_dir}"'

    def smart_deploy(self, user_id, wheel_path, file_md5, show_console=True):
        """智能部署用户环境。

        根据 MD5 校验判断环境是否已存在且完整，若匹配则跳过部署；
        否则清理旧环境并重新创建虚拟环境、安装 wheel 包。

        Args:
            user_id: 用户唯一标识。
            wheel_path: .whl 安装包的文件路径。
            file_md5: wheel 文件的 MD5 校验值，用于判断环境是否需要更新。
            show_console: 是否显示安装过程的控制台窗口，默认 True。

        Returns:
            bool: 部署成功返回 True，失败返回 False。
        """
        env_dir = self.get_env_dir(user_id)
        md5_file = os.path.join(env_dir, "env_identity.md5")
        name_info_file = os.path.join(env_dir, "pkg_name.info")  # 记录包名的文件
        python_exe = self.get_python_exe(user_id)

        # wheel_path = r"D:\workspace\python\ascript-windows\apps\module\1085\8bb2a42175a3d4f473f58333020aebda\ascriptproject2-0.1.0-py3-none-any.whl"

        is_ready = False
        # 增加对 pkg_name.info 的存在性检查
        if os.path.exists(md5_file) and os.path.exists(python_exe) and os.path.exists(name_info_file):
            try:
                with open(md5_file, "r", encoding="utf-8") as f:
                    saved_md5 = f.read().strip()
                if saved_md5 == file_md5:
                    is_ready = True
            except Exception:
                is_ready = False

        if is_ready:
            print(f"[{user_id}] 环境匹配且完整。")
            return True

        print(f"[{user_id}] 环境重建中...")

        # 提前提取包名
        current_pkg_name = self._get_pkg_name(wheel_path)
        if not current_pkg_name:
            self._show_error_box(f"无法从文件解析包名: {wheel_path}", "部署异常")
            return False

        try:
            if os.path.exists(env_dir):
                self.stop_app(user_id)
                time.sleep(0.8)

            if os.path.exists(env_dir):
                shutil.rmtree(env_dir, ignore_errors=True)

            os.makedirs(self.root_path, exist_ok=True)

            # 执行安装
            self._execute_combined_install(user_id, wheel_path, env_dir, show_console)

            # 写入校验信息
            with open(md5_file, "w", encoding="utf-8") as f:
                f.write(file_md5)
            # 关键修改：持久化包名，供 run_app 使用
            with open(name_info_file, "w", encoding="utf-8") as f:
                f.write(current_pkg_name)

            return True

        except RuntimeError as re:
            print(f"[{user_id}] 部署中断: {re}")
            if os.path.exists(env_dir):
                shutil.rmtree(env_dir, ignore_errors=True)
            return False
        except Exception as e:
            self._show_error_box(f"用户 {user_id} 部署失败！\n原因: {str(e)}", "环境部署中断")
            if os.path.exists(env_dir):
                shutil.rmtree(env_dir, ignore_errors=True)
            return False

    def _get_best_index(self):
        """测速选择最快的 PyPI 镜像源。

        对比官方源和清华源的响应时间，返回延迟最低的源地址。

        Returns:
            str: 最快的 PyPI 镜像源 URL。
        """
        sources = {
            "tsinghua": "https://pypi.tuna.tsinghua.edu.cn/simple",
            "pypi": "https://pypi.org/simple"
        }
        best_url = sources["pypi"]  # 默认官方兜底
        min_time = 999.0

        for name, url in sources.items():
            try:
                start = time.time()
                # timeout 设短一点，1秒内没反应就说明该源当前不佳
                with urllib.request.urlopen(url, timeout=1.0) as res:
                    if res.getcode() == 200:
                        duration = time.time() - start
                        if duration < min_time:
                            min_time = duration
                            best_url = url
            except:
                continue
        return best_url

    def _execute_combined_install(self, user_id, wheel_path, env_dir, show_console):
        """执行虚拟环境创建和 wheel 包安装的组合命令。

        通过一条 cmd 命令依次完成虚拟环境创建和包安装，失败时会在控制台显示错误信息。

        Args:
            user_id: 用户唯一标识，用于窗口标题显示。
            wheel_path: .whl 安装包的文件路径。
            env_dir: 虚拟环境目标目录路径。
            show_console: 是否显示控制台窗口。

        Raises:
            RuntimeError: 安装命令执行失败时抛出。
        """
        abs_env_dir = os.path.abspath(env_dir)
        abs_wheel_path = os.path.abspath(wheel_path)
        pip_path = self.get_pip_exe(user_id)

        # 1. 动态测速获取最优源
        index_url = self._get_best_index()
        print(f"[{user_id}] 自动择源完成，选用: {index_url}")

        # 2. 构造 pip 参数
        # 这里顺带保留了之前你 launcher 里的 timeout 逻辑（如果有的话）
        timeout = getattr(self, 'config', {}).get('timeout', 15)
        extra_args = f"-i {index_url} --default-timeout {timeout}"

        combined_payload = (
            f'title 正在初始化运行环境 - {user_id} && '
            f'"{sys.executable}" -m virtualenv "{abs_env_dir}" && '
            f'title 正在安装插件依赖 - {user_id} && '
            f'"{pip_path}" install --no-cache-dir {extra_args} "{abs_wheel_path}" '
            f'|| (echo. && echo ------------------------------------------------ && '
            f'echo [错误] 部署失败！请查看上方红字报错原因。 && '
            f'echo 解决后关闭此窗口，重新启动程序即可。 && '
            f'echo ------------------------------------------------ && pause && exit 1)'
        )

        full_cmd = f'cmd /s /c "{combined_payload}"'
        res = subprocess.run(full_cmd, creationflags=0x00000010 if show_console else 0, check=False)

        if res.returncode != 0:
            raise RuntimeError("Installation command failed.")

    def run_app(self, user_id, entry_module="main", cwd=None, show_console=False):
        """启动用户应用程序。

        在指定用户的虚拟环境中运行应用入口模块，自动从环境配置中
        读取包名。启动后会创建后台监控线程跟踪进程状态。

        Args:
            user_id: 用户唯一标识。
            entry_module: 入口模块名，默认 "main"。
            cwd: 工作目录，默认为用户环境目录。
            show_console: 是否显示控制台窗口，默认 False。

        Returns:
            int | None: 启动成功返回进程 PID，失败返回 None。
        """
        python_exe = self.get_python_exe(user_id)
        env_dir = self.get_env_dir(user_id)
        name_info_file = os.path.join(env_dir, "pkg_name.info")

        # 自动获取包名
        if not os.path.exists(name_info_file):
            self._show_error_box("找不到环境包名配置，请重新部署环境。", "启动失败")
            return None

        with open(name_info_file, "r", encoding="utf-8") as f:
            package_name = f.read().strip()

        work_dir = cwd or env_dir
        last_error_log = os.path.join(env_dir, "last_error.log")

        if os.path.exists(last_error_log):
            try:
                os.remove(last_error_log)
            except:
                pass

        target_module = f"{package_name}.{entry_module}"
        cmd = [python_exe, "-u", "-m", target_module]
        pid_file = os.path.join(env_dir, "app.pid")

        try:
            flags = 0 if show_console else 0x08000000
            with open(last_error_log, "w", encoding="utf-8") as f_err:
                process = subprocess.Popen(
                    cmd,
                    cwd=work_dir,
                    creationflags=flags,
                    stdout=subprocess.DEVNULL,
                    stderr=f_err,
                    text=True,
                    encoding='utf-8'
                )

            with open(pid_file, "w") as f:
                f.write(str(process.pid))

            monitor_thread = threading.Thread(
                target=self._wait_and_handle_error,
                args=(process, user_id, package_name, pid_file, show_console, last_error_log),
                daemon=True
            )
            monitor_thread.start()
            return process.pid
        except Exception as e:
            self._show_error_box(f"启动失败: {str(e)}", "致命错误")
            return None

    def _wait_and_handle_error(self, process, user_id, name, pid_file, show_console, log_path):
        """等待进程结束并处理异常退出。

        作为后台监控线程的目标函数运行，在进程异常退出时
        读取错误日志并弹出错误提示框。

        Args:
            process: subprocess.Popen 进程对象。
            user_id: 用户唯一标识。
            name: 包名称，用于错误提示。
            pid_file: PID 文件路径，用于判断是否为手动停止。
            show_console: 是否显示了控制台窗口。
            log_path: 错误日志文件路径。
        """
        try:
            process.wait()
            is_manual_stop = not os.path.exists(pid_file)
            if process.returncode != 0 and not show_console and not is_manual_stop:
                stderr_content = ""
                if os.path.exists(log_path):
                    with open(log_path, "r", encoding="utf-8") as f:
                        stderr_content = f.read()
                self._handle_runtime_error(name, stderr_content, process.returncode)
        finally:
            if os.path.exists(pid_file):
                try:
                    os.remove(pid_file)
                except:
                    pass

    def _handle_runtime_error(self, name, stderr, code):
        """处理运行时错误：记录崩溃日志并弹出错误提示。

        Args:
            name: 模块/包名称。
            stderr: 标准错误输出内容。
            code: 进程退出码。
        """
        if not stderr: stderr = f"进程异常退出，退出码: {code}"
        lines = [line.strip() for line in stderr.splitlines() if line.strip()]
        error_summary = "\n".join(lines[-10:])
        try:
            log_path = os.path.join(os.getcwd(), f"crash_{int(time.time())}.log")
            with open(log_path, "w", encoding="utf-8") as f:
                f.write(f"Time: {time.ctime()}\nModule: {name}\nCode: {code}\n{stderr}")
        except:
            pass
        self._show_error_box(f"【代码崩溃】核心摘要:\n{error_summary}", f"运行异常 - {name}")

    def _show_error_box(self, content, title):
        """在 Windows 上弹出错误消息框。

        Args:
            content: 消息框内容文本。
            title: 消息框标题。
        """
        if sys.platform == "win32":
            ctypes.windll.user32.MessageBoxW(0, content, title, 16)

    def is_running(self, user_id):
        """检查指定用户的应用是否正在运行。

        通过 PID 文件和进程信息双重验证运行状态。

        Args:
            user_id: 用户唯一标识。

        Returns:
            bool: 应用正在运行返回 True，否则返回 False。
        """
        env_dir = self.get_env_dir(user_id)
        pid_file = os.path.join(env_dir, "app.pid")
        if not os.path.exists(pid_file): return False
        try:
            with open(pid_file, "r") as f:
                saved_pid = int(f.read().strip())
            if not psutil.pid_exists(saved_pid):
                if os.path.exists(pid_file): os.remove(pid_file)
                return False
            proc = psutil.Process(saved_pid)
            expected_python = os.path.normcase(os.path.normpath(self.get_python_exe(user_id)))
            actual_python = os.path.normcase(os.path.normpath(proc.exe()))
            return expected_python == actual_python
        except Exception:
            return False

    def stop_app(self, user_id):
        """停止指定用户的应用进程。

        先删除 PID 文件（标记为手动停止），然后使用 taskkill 强制终止进程树。

        Args:
            user_id: 用户唯一标识。
        """
        pid_file = os.path.join(self.get_env_dir(user_id), "app.pid")
        if not os.path.exists(pid_file): return
        try:
            with open(pid_file, "r") as f:
                pid = int(f.read().strip())
            if os.path.exists(pid_file):
                try:
                    os.remove(pid_file)
                except:
                    pass
            if psutil.pid_exists(pid):
                subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)], creationflags=0x08000000,
                               capture_output=True)
        except:
            pass