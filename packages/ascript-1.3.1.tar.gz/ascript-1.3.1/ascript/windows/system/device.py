import psutil
import platform
import socket
import uuid
import ctypes
import os
import sys
import time
from datetime import datetime
from typing import Dict, Any, List


# --- 工具类：实现类属性的静态访问 ---
class classproperty(object):
    """类属性描述符，支持将方法作为类级别的只读属性访问。

    通过该描述符，可以像访问普通属性一样访问类方法，无需实例化。

    Args:
        fget: 被装饰的 getter 函数，接收类对象作为参数。
    """

    def __init__(self, fget):
        """初始化类属性描述符。

        Args:
            fget: 被装饰的 getter 函数。
        """
        self.fget = fget

    def __get__(self, owner_self, owner_cls):
        """获取属性值时调用 getter 函数。

        Args:
            owner_self: 实例对象（可能为 None）。
            owner_cls: 拥有该描述符的类对象。

        Returns:
            getter 函数的返回值。
        """
        return self.fget(owner_cls)


class Device:
    """AScript 设备环境全感知中心。

    提供对当前 Windows 设备各维度信息的静态访问能力，包括：
    身份识别、操作系统、运行环境、屏幕与缩放、核心硬件（CPU/内存/GPU）、
    磁盘管理、电源与外设、网络信息等。所有属性均可通过类直接访问，无需实例化。
    """

    # ================= 1. 身份识别 (ID) =================
    @classproperty
    def id(cls) -> str:
        """获取设备唯一标识符（基于硬件指纹，重装系统不变）。

        Returns:
            str: 大写的 UUID5 字符串，由网卡 MAC、处理器型号和主机名生成。
        """
        raw = f"{uuid.getnode()}-{platform.processor()}-{platform.node()}"
        return str(uuid.uuid5(uuid.NAMESPACE_DNS, raw)).upper()

    # ================= 2. 操作系统 (OS) =================
    class os:
        """操作系统信息。

        Attributes:
            type: 操作系统类型，如 "Windows"。
            release: 系统版本号，如 "10" 或 "11"。
            version: 内核版本号。
            hostname: 计算机主机名。
        """
        type = platform.system()  # Windows
        release = platform.release()  # 10 / 11
        version = platform.version()  # 内核版本
        hostname = socket.gethostname()  # 计算机名

        @classproperty
        def boot_time(cls) -> str:
            """获取系统启动时间。

            Returns:
                str: 格式为 "YYYY-MM-DD HH:MM:SS" 的启动时间字符串。
            """
            return datetime.fromtimestamp(psutil.boot_time()).strftime("%Y-%m-%d %H:%M:%S")

        @classproperty
        def uptime_seconds(cls) -> int:
            """获取系统已运行的秒数。

            Returns:
                int: 从系统启动到当前时刻的秒数。
            """
            return int(time.time() - psutil.boot_time())

    # ================= 3. 运行环境 (Env) =================
    class env:
        """运行环境信息，包括权限、Python 版本和工作目录。"""

        @classproperty
        def is_admin(cls) -> bool:
            """判断当前进程是否拥有管理员权限。

            Returns:
                bool: 拥有管理员权限返回 True，否则返回 False。
            """
            try:
                return ctypes.windll.shell32.IsUserAnAdmin() != 0
            except:
                return False

        @classproperty
        def python_ver(cls) -> str:
            """获取当前 Python 版本号。

            Returns:
                str: Python 版本字符串，如 "3.10.12"。
            """
            return platform.python_version()

        @classproperty
        def cwd(cls) -> str:
            """获取当前工作目录。

            Returns:
                str: 当前工作目录的绝对路径。
            """
            return os.getcwd()

    # ================= 4. 屏幕与缩放 (Screen) =================
    class screen:
        """屏幕与缩放信息，包括 DPI 缩放比例、逻辑分辨率和物理分辨率。"""

        @classproperty
        def scale(cls) -> float:
            """获取屏幕 DPI 缩放倍数。

            Returns:
                float: 缩放倍数，如 1.0、1.25、1.5 等。
            """
            try:
                hdc = ctypes.windll.user32.GetDC(0)
                dpi = ctypes.windll.gdi32.GetDeviceCaps(hdc, 88)
                ctypes.windll.user32.ReleaseDC(0, hdc)
                return round(dpi / 96.0, 2)
            except:
                return 1.0

        @classproperty
        def percent(cls) -> str:
            """获取屏幕缩放百分比字符串。

            Returns:
                str: 缩放百分比，如 "100%"、"125%"。
            """
            return f"{int(cls.scale * 100)}%"

        @classproperty
        def logical(cls) -> str:
            """获取逻辑分辨率（受 DPI 缩放影响）。

            Returns:
                str: 格式为 "宽x高" 的分辨率字符串，如 "1920x1080"。
            """
            u32 = ctypes.windll.user32
            return f"{u32.GetSystemMetrics(0)}x{u32.GetSystemMetrics(1)}"

        @classproperty
        def physical(cls) -> str:
            """获取物理真实分辨率。

            Returns:
                str: 格式为 "宽x高" 的物理分辨率字符串，如 "2560x1440"。
            """
            u32 = ctypes.windll.user32
            w = int(u32.GetSystemMetrics(0) * cls.scale)
            h = int(u32.GetSystemMetrics(1) * cls.scale)
            return f"{w}x{h}"

    # ================= 5. 核心硬件 (CPU/Mem/GPU) =================
    class cpu:
        """CPU 硬件信息。

        Attributes:
            brand: CPU 型号名称。
            cores: 物理核心数。
            threads: 逻辑线程数。
        """
        brand = platform.processor()
        cores = psutil.cpu_count(logical=False)
        threads = psutil.cpu_count(logical=True)

        @classproperty
        def usage(cls):
            """获取当前 CPU 使用率。

            Returns:
                float: CPU 使用百分比，如 23.5。
            """
            return psutil.cpu_percent(interval=0.1)

    class memory:
        """内存信息。

        Attributes:
            total_gb: 总内存大小（GB）。
        """
        total_gb = round(psutil.virtual_memory().total / (1024 ** 3), 2)

        @classproperty
        def free_gb(cls):
            """获取当前可用内存大小。

            Returns:
                float: 可用内存（GB），保留两位小数。
            """
            return round(psutil.virtual_memory().available / (1024 ** 3), 2)

        @classproperty
        def percent(cls):
            """获取当前内存使用率。

            Returns:
                float: 内存使用百分比，如 65.3。
            """
            return psutil.virtual_memory().percent

    class gpu:
        """GPU 显卡信息。"""

        @classproperty
        def list(cls) -> List[str]:
            """获取显卡型号列表。

            Returns:
                List[str]: 显卡名称列表，如 ["NVIDIA GeForce RTX 3080"]。
            """
            names = []
            try:
                import wmi
                for v in wmi.WMI().Win32_VideoController():
                    names.append(v.Name)
            except:
                names = ["Standard Display Adapter"]
            return names

    # ================= 6. 磁盘管理 (Disks) =================
    class disks:
        """磁盘管理信息，提供盘符列表、数量及详情查询。"""

        @classproperty
        def list(cls) -> List[str]:
            """获取所有有效磁盘盘符。

            Returns:
                List[str]: 排序后的盘符列表，如 ['C', 'D', 'E']。
            """
            d = []
            for p in psutil.disk_partitions():
                if 'cdrom' in p.opts or p.fstype == '': continue
                d.append(p.mountpoint.split(":")[0].upper())
            return sorted(list(set(d)))

        @classproperty
        def count(cls) -> int:
            """获取有效磁盘数量。

            Returns:
                int: 有效磁盘分区的数量。
            """
            return len(cls.list)

        @staticmethod
        def get_detail(drive: str) -> Dict[str, Any]:
            """获取指定盘符的磁盘详情。

            Args:
                drive: 盘符字母，如 'C' 或 'D'。

            Returns:
                Dict[str, Any]: 包含 total（总容量）、free（可用空间）、percent（使用率）的字典。
                    访问失败时返回 {"error": "Access Denied"}。
            """
            try:
                u = psutil.disk_usage(f"{drive.upper()}:\\")
                return {
                    "total": f"{u.total / (1024 ** 3):.1f}GB",
                    "free": f"{u.free / (1024 ** 3):.1f}GB",
                    "percent": f"{u.percent}%"
                }
            except:
                return {"error": "Access Denied"}

    # ================= 7. 电源与外设 (Power/Audio) =================
    class power:
        """电源与电池信息。"""

        @classproperty
        def is_plugged(cls) -> bool:
            """判断是否接通外部电源。

            Returns:
                bool: 已接通电源返回 True，使用电池供电返回 False。
                    无电池设备（台式机）始终返回 True。
            """
            batt = psutil.sensors_battery()
            return batt.power_plugged if batt else True

        @classproperty
        def percent(cls) -> int:
            """获取当前电池电量百分比。

            Returns:
                int: 电池电量百分比（0-100），无电池设备返回 100。
            """
            batt = psutil.sensors_battery()
            return batt.percent if batt else 100

    class audio:
        """音频设备信息。"""

        @classproperty
        def list(cls) -> List[str]:
            """获取音频输出设备名称列表。

            Returns:
                List[str]: 音频设备名称列表，获取失败时返回空列表。
            """
            try:
                import wmi
                return [s.Name for s in wmi.WMI().Win32_SoundDevice()]
            except:
                return []

    # ================= 8. 网络信息 (Network) =================
    class network:
        """网络信息，包括本机 IP 和 MAC 地址。"""

        @classproperty
        def ip(cls):
            """获取本机局域网 IP 地址。

            Returns:
                str: 本机 IPv4 地址，如 "192.168.1.100"。
            """
            return socket.gethostbyname(socket.gethostname())

        @classproperty
        def mac(cls):
            """获取本机 MAC 地址。

            Returns:
                str: 格式为 "xx:xx:xx:xx:xx:xx" 的 MAC 地址字符串。
            """
            return ':'.join(['{:02x}'.format((uuid.getnode() >> e) & 0xff) for e in range(0, 48, 8)][::-1])