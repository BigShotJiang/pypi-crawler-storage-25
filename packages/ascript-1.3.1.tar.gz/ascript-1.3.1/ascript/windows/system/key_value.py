import json
import os
import pathlib
import threading

class KeyValueMeta(type):
    """KeyValue 的元类，支持类级别的索引操作。

    通过该元类，可以直接使用 KeyValue["key"] 语法进行键值的
    读取、设置和删除操作。
    """

    def __getitem__(cls, key):
        """通过索引语法获取值。

        Args:
            key: 键名。

        Returns:
            对应键的值，不存在时返回 None。
        """
        return cls.get(key)

    def __setitem__(cls, key, value):
        """通过索引语法设置值。

        Args:
            key: 键名。
            value: 要保存的值。
        """
        cls.save(key, value)

    def __delitem__(cls, key):
        """通过索引语法删除键值对。

        Args:
            key: 要删除的键名。
        """
        cls.remove(key)


class KeyValue(metaclass=KeyValueMeta):
    """基于 JSON 文件的持久化键值存储。

    提供线程安全的键值对读写操作，数据自动持久化到 JSON 文件。
    支持类级别的索引操作（如 KeyValue["key"] = value）。

    Attributes:
        FILENAME: 存储文件名，默认为 "config.json"。
    """
    _data = None
    _file_path = None
    _lock = threading.Lock()  # 线程锁，防止并发写入冲突
    FILENAME = "config.json"

    @classmethod
    def _initialize(cls):
        """延迟初始化：确定存储路径并加载已有数据。

        首次访问时自动调用，确保数据文件路径和内存数据已就绪。
        """
        with cls._lock:
            if cls._data is None:
                cls._file_path = cls._determine_path()
                cls._data = cls._load_data()

    @classmethod
    def _determine_path(cls):
        """确定配置文件的存储路径。

        优先使用当前工作目录，若无写权限则回退到用户家目录下的隐藏文件夹。

        Returns:
            pathlib.Path: 配置文件的完整路径。
        """
        # 1. 尝试根目录
        root_path = pathlib.Path(os.getcwd())
        if os.access(root_path, os.W_OK):
            return root_path / cls.FILENAME

        # 2. 回退到用户家目录 (隐藏文件夹)
        home_dir = pathlib.Path.home() / ".app_data"
        home_dir.mkdir(parents=True, exist_ok=True)
        return home_dir / cls.FILENAME

    @classmethod
    def _load_data(cls):
        """从 JSON 文件加载数据到内存。

        Returns:
            dict: 解析后的键值数据字典，文件不存在或解析失败时返回空字典。
        """
        if cls._file_path.exists():
            try:
                return json.loads(cls._file_path.read_text(encoding='utf-8'))
            except:
                return {}
        return {}

    @classmethod
    def _commit(cls):
        """将内存数据持久化写入 JSON 文件（线程安全）。"""
        with cls._lock:
            cls._file_path.write_text(
                json.dumps(cls._data, indent=4, ensure_ascii=False),
                encoding='utf-8'
            )

    @classmethod
    def save(cls, key, value):
        """保存键值对并持久化到文件。

        Args:
            key: 键名。
            value: 要保存的值，需可 JSON 序列化。
        """
        cls._initialize()
        cls._data[key] = value
        cls._commit()

    @classmethod
    def get(cls, key, default=None):
        """获取指定键的值。

        Args:
            key: 键名。
            default: 键不存在时的默认返回值，默认 None。

        Returns:
            对应键的值，不存在时返回 default。
        """
        cls._initialize()
        return cls._data.get(key, default)

    @classmethod
    def remove(cls, key):
        """删除指定键值对并持久化更新。

        Args:
            key: 要删除的键名。若键不存在则不执行任何操作。
        """
        cls._initialize()
        if key in cls._data:
            del cls._data[key]
            cls._commit()