import threading
import signal
import sys


class Runtime:
    """程序运行时生命周期管理器。

    提供全局事件循环机制，使主线程保持运行状态直到收到停止信号。
    适用于需要主线程驻留的场景（如 GUI 应用、后台服务等）。

    Attributes:
        _stop_event: 线程事件对象，用于控制运行/停止状态。
    """
    # 静态变量，用于控制生命周期
    _stop_event = threading.Event()

    @staticmethod
    def wait():
        """启动全局事件循环，阻塞主线程直到收到停止信号。

        主线程会停留在此方法中，直到调用 Runtime.stop() 或
        接收到 SIGINT/SIGTERM 信号（如 Ctrl+C）才会继续向下运行。
        支持优雅的信号处理和键盘中断。
        """

        # 优雅处理 Ctrl+C 信号
        def _handle_signal(signum, frame):
            Runtime.stop()

        try:
            signal.signal(signal.SIGINT, _handle_signal)
            signal.signal(signal.SIGTERM, _handle_signal)
        except (ValueError, AttributeError):
            # 某些环境（如非主线程）不支持信号注册
            pass

        print("[System] Runtime 正在等待信号，程序不会退出...")

        # 核心逻辑：无限等待。
        # wait(timeout) 可以让主线程有机会处理系统中断，比 wait() 更推荐
        try:
            while not Runtime._stop_event.is_set():
                Runtime._stop_event.wait(timeout=0.1)
        except KeyboardInterrupt:
            pass

        print("[System] Runtime 已停止。")

    @staticmethod
    def stop():
        """停止全局事件循环，解除 Runtime.wait() 的阻塞状态。

        调用后主线程将从 wait() 方法返回并继续执行后续代码。
        """
        Runtime._stop_event.set()

# --- 调用示范 ---
# win = WebWindow("a.html")
# win.show(block=False)  # 窗口弹出，主线程不被 block
# ... 执行其他初始化 ...
# Runtime.wait()         # 这里才是真正的驻留逻辑