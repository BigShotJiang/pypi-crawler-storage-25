import os
import base64
import ctypes
from io import BytesIO
from typing import Literal, Union, Optional, List
import numpy as np
from PIL import Image
from mss import mss

# 解决 Windows 高分屏缩放导致的截图坐标偏差
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(1)
except Exception:
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

class Screen:
    """屏幕截图与显示器信息工具类。

    基于 mss 库实现高性能屏幕截图，支持 Windows 高分屏 DPI 自适应。
    提供多种输出格式（PIL、NumPy、OpenCV、Base64）及区域截取功能。
    """

    @staticmethod
    def size() -> List[int]:
        """获取主显示器的分辨率尺寸。

        Returns:
            List[int]: [宽度, 高度]，单位为像素。
        """
        with mss() as sct:
            monitor = sct.monitors[1]
            return [monitor["width"], monitor["height"]]



    @staticmethod
    def capture(
            rect: Optional[List[int]] = None,
            format: str = "pillow",
            save_path: Optional[str] = None
    ) -> Union[Image.Image, np.ndarray, str, None]:
        """截取屏幕图像。

        支持全屏或指定区域截图，可输出多种格式并可选保存到文件。
        已处理 Windows 高分屏 DPI 缩放问题。

        Args:
            rect: 截图区域 [left, top, right, bottom]，为 None 时截取整个主显示器。
            format: 输出格式，可选值：
                - 'pillow': 返回 PIL.Image 对象（默认）。
                - 'numpy': 返回 RGB 格式的 NumPy 数组。
                - 'opencv': 返回 BGR 格式的 NumPy 数组。
                - 'base64': 返回 JPEG 格式的 Base64 数据 URI 字符串。
                - 'base64:png': 返回 PNG 格式的 Base64 数据 URI 字符串。
            save_path: 文件保存路径，自动根据后缀名选择存储格式（支持 jpg/png），
                为 None 时不保存。

        Returns:
            Union[Image.Image, numpy.ndarray, str, None]: 根据 format 参数返回对应格式的截图，
                截图失败时返回 None。
        """
        with mss() as sct:
            try:
                # 1. 区域计算与合法性校验
                if rect and len(rect) == 4:
                    left, top, right, bottom = rect
                    # 确保 width 和 height 为正数
                    width, height = max(0, right - left), max(0, bottom - top)
                    if width == 0 or height == 0:
                        return None
                    monitor = {"left": left, "top": top, "width": width, "height": height}
                else:
                    monitor = sct.monitors[1]

                # 2. 执行截图
                sct_img = sct.grab(monitor)

                # 3. 构造 PIL 对象 (核心中转)
                img = Image.frombytes("RGB", sct_img.size, sct_img.bgra, "raw", "BGRX")

                # 4. 磁盘保存逻辑
                if save_path:
                    directory = os.path.dirname(save_path)
                    if directory and not os.path.exists(directory):
                        os.makedirs(directory, exist_ok=True)

                    _, ext = os.path.splitext(save_path)
                    ext = ext.lower().strip('.')
                    # 自动匹配存储格式
                    save_fmt = "JPEG" if ext in ["jpg", "jpeg"] else ("PNG" if ext == "png" else "PNG")

                    # 针对不同格式设置最优参数
                    save_args = {"format": save_fmt}
                    if save_fmt == "JPEG":
                        save_args["quality"] = 95
                        save_args["subsampling"] = 0  # 提升色彩保持度

                    img.save(save_path, **save_args)

                # 5. 返回格式化处理
                if format.startswith("base64"):
                    # 默认 jpeg，除非明确指定 base64:png
                    sub_format = "PNG" if (":" in format and format.split(":")[1].lower() == "png") else "JPEG"
                    buffered = BytesIO()
                    img.save(buffered, format=sub_format, quality=80 if sub_format == "JPEG" else None)
                    img_str = base64.b64encode(buffered.getvalue()).decode("utf-8")
                    return f"data:image/{sub_format.lower()};base64,{img_str}"

                elif format == "pillow":
                    return img

                elif format == "numpy":
                    return np.array(img)

                elif format == "opencv":
                    return np.array(img)[:, :, ::-1]

                return img

            except Exception as e:
                print(f"Screenshot Error: {e}")
                return None