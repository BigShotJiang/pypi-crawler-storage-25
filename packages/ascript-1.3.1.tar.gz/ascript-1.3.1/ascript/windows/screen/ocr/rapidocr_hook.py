import sys
import re
import importlib.abc
import importlib.util
import importlib
from dataclasses import dataclass, asdict
from typing import List, Optional, Tuple, Union, TYPE_CHECKING

# 假设你的硬件操作模块路径如下
from ...hardware.mouse import Mouse

# --- 1. 类型存根 (仅用于 PyCharm 等 IDE 的代码补全提示) ---
if TYPE_CHECKING:
    try:
        from rapidocr.utils.output import RapidOCROutput as BaseOutput
    except ImportError:
        class BaseOutput:
            pass


    class RapidOCROutput(BaseOutput):
        """RapidOCR 输出结果的类型存根（仅用于 IDE 代码补全提示）。

        声明 find 和 find_all 方法签名，使 IDE 能正确提示动态注入的方法。
        """

        def find(self, text_re: str = None, score: float = 0.85) -> 'OCRItem': ...

        def find_all(self, text_re: str = None, score: float = 0.85) -> List['OCRItem']: ...


# --- 2. 核心结果对象定义 ---

@dataclass
class OCRItem:
    """OCR 单条识别结果的数据封装类。

    封装一条文字识别结果的完整信息，支持直接点击识别到的文字位置。

    Attributes:
        txt: 识别出的文本内容。
        box: 文字区域的四个顶点坐标，格式为 [[x1,y1], [x2,y2], [x3,y3], [x4,y4]]。
        score: 识别置信度，范围 0.0 ~ 1.0。
        center: 文字区域的中心点坐标 (x, y)。
        rect: 文字区域的外接矩形 [left, top, right, bottom]。
    """

    txt: str
    box: List[List[float]]
    score: float
    center: Tuple[int, int]
    rect: List[int]

    def click(self, window=None):
        """点击该识别结果所在的位置。

        Args:
            window: 可选的 Window 对象。传入时调用 window.click() 进行窗口内相对坐标点击；
                不传时调用全局 Mouse.click() 进行屏幕绝对坐标点击。

        Returns:
            OCRItem: 返回自身，支持链式调用。
        """
        x, y = self.center
        if window:
            # 让窗口对象处理相对坐标点击
            window.click(x, y)
        else:
            # 全屏绝对点击
            Mouse.click(x, y)
        return self

    def to_dict(self) -> dict:
        """将识别结果转换为字典格式。

        Returns:
            dict: 包含 txt、box、score、center、rect 等字段的字典。
        """
        return asdict(self)

    def __bool__(self):
        """支持布尔判断，OCRItem 实例始终为 True。

        Returns:
            bool: 始终返回 True，表示存在有效识别结果。
        """
        return True

    def __repr__(self):
        """返回 OCRItem 的可读字符串表示。

        Returns:
            str: 包含文本、置信度和中心坐标的描述字符串。
        """
        return f"<OCRItem txt='{self.txt}' score={self.score:.2f} center={self.center}>"


class NullOCRItem:
    """空 OCR 结果对象（空对象模式）。

    当 find 方法未找到匹配结果时返回此对象，防止链式调用因 None 而报错。
    所有属性均为默认空值，布尔值为 False。
    """

    def __init__(self):
        """初始化空 OCR 结果，所有属性设为默认空值。"""
        self.txt, self.box, self.score = "", [], 0.0
        self.center, self.rect = (0, 0), [0, 0, 0, 0]

    def click(self, window=None):
        """静默处理点击操作，不执行任何动作。

        Args:
            window: 忽略此参数。

        Returns:
            NullOCRItem: 返回自身，支持链式调用。
        """
        return self

    def to_dict(self) -> dict:
        """转换为空字典。

        Returns:
            dict: 空字典。
        """
        return {}

    def __bool__(self):
        """支持布尔判断，NullOCRItem 始终为 False。

        Returns:
            bool: 始终返回 False，表示未找到结果。
        """
        return False

    def __repr__(self):
        """返回 NullOCRItem 的可读字符串表示。

        Returns:
            str: 空结果的描述字符串。
        """
        return "<NullOCRItem (Not Found)>"


# --- 3. 运行时 Hook 逻辑 ---

class RapidOCRHook(importlib.abc.MetaPathFinder):
    """RapidOCR 运行时 Hook，动态注入 find/find_all 扩展方法。

    通过 Python 的 MetaPathFinder 机制拦截 rapidocr.utils.output 模块的导入，
    在其 RapidOCROutput 类上注入 find() 和 find_all() 方法，
    使 OCR 结果对象直接支持文字搜索和定位功能。
    """

    def find_spec(self, fullname, path, target=None):
        """拦截模块导入，在目标模块加载时注入扩展方法。

        Args:
            fullname: 正在导入的模块全名。
            path: 模块搜索路径。
            target: 目标模块对象（可选）。

        Returns:
            ModuleSpec: 当拦截到目标模块时返回其 spec，否则返回 None。
        """
        # 监听 RapidOCR 的核心输出模块
        if fullname == "rapidocr.utils.output":
            importlib.invalidate_caches()  # 动态感知新安装的包
            try:
                spec = importlib.util.find_spec(fullname)
                if spec is None: return None

                if self in sys.meta_path:
                    sys.meta_path.remove(self)

                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                self._patch(module)
                sys.modules[fullname] = module
                return spec
            except Exception:
                return None
        return None

    def _patch(self, module):
        """向目标模块的 RapidOCROutput 类动态注入 find 和 find_all 方法。

        Args:
            module: 已加载的 rapidocr.utils.output 模块对象。
        """

        def _build_item(txt, box, score) -> OCRItem:
            """根据原始 OCR 数据构建 OCRItem 结果对象。

            Args:
                txt: 识别出的文本内容。
                box: 文字区域的四个顶点坐标数组。
                score: 识别置信度。

            Returns:
                OCRItem: 封装好的识别结果对象。
            """
            l, t = float(box[0][0]), float(box[0][1])
            r, b = float(box[2][0]), float(box[2][1])
            center = (int((l + r) / 2), int((t + b) / 2))
            rect = [int(l), int(t), int(r), int(b)]
            return OCRItem(
                txt=str(txt),
                box=box.tolist() if hasattr(box, 'tolist') else box,
                score=float(score),
                center=center,
                rect=rect
            )

        def find(self, text_re: str = None, score: float = 0.85) -> Union[OCRItem, NullOCRItem]:
            """在 OCR 识别结果中查找第一个匹配的文本。

            Args:
                text_re: 正则表达式模式，用于匹配文本内容。为 None 时匹配所有文本。
                score: 最低置信度阈值，默认为 0.85。

            Returns:
                Union[OCRItem, NullOCRItem]: 匹配到的结果对象，未找到时返回 NullOCRItem。
            """
            txts, boxes, scores = getattr(self, 'txts', None), getattr(self, 'boxes', None), getattr(self, 'scores',
                                                                                                     None)
            if txts is not None and boxes is not None:
                for i in range(len(txts)):
                    if scores[i] >= score:
                        if text_re is None or re.search(text_re, str(txts[i])):
                            return _build_item(txts[i], boxes[i], scores[i])
            return NullOCRItem()

        def find_all(self, text_re: str = None, score: float = 0.85) -> List[OCRItem]:
            """在 OCR 识别结果中查找所有匹配的文本，按从上到下、从左到右排序。

            Args:
                text_re: 正则表达式模式，用于匹配文本内容。为 None 时匹配所有文本。
                score: 最低置信度阈值，默认为 0.85。

            Returns:
                List[OCRItem]: 匹配结果列表，按坐标排序（从上到下、从左到右）。
            """
            results = []
            txts, boxes, scores = getattr(self, 'txts', None), getattr(self, 'boxes', None), getattr(self, 'scores',
                                                                                                     None)
            if txts is not None and boxes is not None:
                for i in range(len(txts)):
                    if scores[i] >= score:
                        if text_re is None or re.search(text_re, str(txts[i])):
                            results.append(_build_item(txts[i], boxes[i], scores[i]))

            # 按从上到下、从左到右排序
            results.sort(key=lambda x: (x.center[1], x.center[0]))
            return results

        # 将方法绑定到目标类
        target_class = "RapidOCROutput"
        if hasattr(module, target_class):
            cls = getattr(module, target_class)
            if not hasattr(cls, "find"):
                cls.find = find
                cls.find_all = find_all
                # print(f"✅ [RapidOCR-Hook] 成功注入 find/find_all 扩展")


def install():
    """注册 RapidOCR Hook 的入口函数。

    如果 rapidocr.utils.output 已加载，直接对其进行补丁；
    否则将 RapidOCRHook 注册到 sys.meta_path，等待模块导入时自动注入。
    """
    target_mod = "rapidocr.utils.output"
    if target_mod in sys.modules:
        RapidOCRHook()._patch(sys.modules[target_mod])
        return
    if not any(isinstance(h, RapidOCRHook) for h in sys.meta_path):
        sys.meta_path.insert(0, RapidOCRHook())