import numpy as np
from .as_cv import AsCv


class FindColors:
    """多点找色工具类。

    基于向量化位移过滤算法实现高性能多点颜色匹配。
    支持自定义搜索区域、容差阈值、排序方向等参数。
    """

    @staticmethod
    def _hex_to_bgr(hex_str):
        """将十六进制颜色字符串转换为 OpenCV BGR 格式元组。

        Args:
            hex_str: 十六进制颜色字符串，如 '#FF0000' 或 'FF0000'。

        Returns:
            tuple: BGR 格式颜色元组，如 (0, 0, 255) 表示红色。
        """
        hex_str = hex_str.lstrip('#')
        r, g, b = tuple(int(hex_str[i:i + 2], 16) for i in (0, 2, 4))
        return (b, g, r)

    @staticmethod
    def _parse_colors(colors_str):
        """解析多点找色的颜色描述字符串。

        将形如 "x,y,color|dx,dy,color" 的字符串解析为基准色和偏移点列表。
        第一个点作为基准点，后续点记录相对于基准点的偏移和目标颜色。

        Args:
            colors_str: 颜色描述字符串，格式为 "x,y,#RRGGBB|x,y,#RRGGBB|..."。

        Returns:
            tuple: (base_bgr, offsets)，其中：
                - base_bgr (numpy.ndarray): 基准点的 BGR 颜色数组。
                - offsets (list): 偏移点列表，每项为 (dy, dx, target_bgr) 元组。
        """
        parts = colors_str.split('|')
        points = []
        for p in parts:
            x, y, color = p.split(',')
            points.append((int(x), int(y), FindColors._hex_to_bgr(color)))

        base_x, base_y, base_bgr = points[0]
        offsets = []
        for i in range(1, len(points)):
            curr_x, curr_y, curr_bgr = points[i]
            # 计算相对于第一个点的偏移和对应的颜色数组
            offsets.append((curr_y - base_y, curr_x - base_x, np.array(curr_bgr, dtype=np.int16)))

        return np.array(base_bgr, dtype=np.int16), offsets

    @staticmethod
    def find(colors: str, rect=None, threshold: float = 0.95, ori: int = 2, exclusion_radius: int = 5, im_source=None,
             max_res: int = 1):
        """查找第一个匹配的颜色目标。

        对 find_all 的便捷封装，默认只返回第一个匹配结果。

        Args:
            colors: 多点颜色描述字符串，格式为 "x,y,#RRGGBB|x,y,#RRGGBB|..."。
            rect: 搜索区域 [left, top, right, bottom]，为 None 时搜索全屏。
            threshold: 颜色匹配精度，范围 0.0 ~ 1.0，默认为 0.95。值越高要求越精确。
            ori: 搜索方向（1-8），控制结果的排序优先级，默认为 2（从上到下、从左到右）。
            exclusion_radius: 排除半径（像素），同一区域内不重复返回，默认为 5。
            im_source: 自定义图像源，为 None 时自动截取当前屏幕。
            max_res: 最大返回结果数，默认为 1。

        Returns:
            tuple: 匹配位置坐标 (x, y)，未找到时返回 None。
        """
        res = FindColors.find_all(colors, rect, threshold, ori, exclusion_radius, im_source, max_res=max_res)
        return res[0] if res else None

    @staticmethod
    def find_all(colors: str, rect=None, threshold: float = 0.95, ori: int = 2, exclusion_radius: int = 5,
                 im_source=None, max_res: int = 0):
        """全量查找所有匹配的颜色目标。

        采用向量化位移过滤算法，通过 NumPy 整体矩阵运算实现高性能匹配，
        避免逐像素 Python 循环导致的性能瓶颈。内置熔断机制防止海量结果卡死。

        Args:
            colors: 多点颜色描述字符串，格式为 "x,y,#RRGGBB|x,y,#RRGGBB|..."。
            rect: 搜索区域 [left, top, right, bottom]，为 None 时搜索全屏。
            threshold: 颜色匹配精度，范围 0.0 ~ 1.0，默认为 0.95。
                容差计算公式：tol = 255 * (1.0 - threshold)。
            ori: 搜索方向（1-8），控制结果排序：
                1=左到右/上到下，2=上到下/左到右，3=上到下/右到左，
                4=右到左/上到下，5=右到左/下到上，6=下到上/右到左，
                7=下到上/左到右，8=左到右/下到上。默认为 2。
            exclusion_radius: 排除半径（像素），同一区域内不重复返回，默认为 5。
            im_source: 自定义图像源，为 None 时自动截取当前屏幕。
            max_res: 最大返回结果数，0 表示不限制。

        Returns:
            list: 匹配位置坐标列表，每项为 (x, y) 元组。
        """

        # 获取图像源
        if im_source is None:
            from .screen_core import Screen
            im_source = Screen.capture()

        img = AsCv.to_numpy(im_source)

        # 处理范围（ROI）
        if rect:
            l, t, r, b = rect
            img = img[t:b, l:r]
            offset_l, offset_t = l, t
        else:
            offset_l, offset_t = 0, 0

        h, w, _ = img.shape
        base_bgr, offsets = FindColors._parse_colors(colors)
        tol = int(255 * (1.0 - threshold))

        # 预转换图像类型，避免在循环中重复计算
        img_int16 = img.astype(np.int16)

        # --- 步骤 1: 生成主色掩码 ---
        diff = np.abs(img_int16 - base_bgr)
        final_mask = np.all(diff <= tol, axis=-1)

        # 如果没有匹配到主色，直接返回
        if not np.any(final_mask):
            return []

        # --- 步骤 2: 向量化位移过滤 (核心防卡死逻辑) ---
        for dy, dx, target_bgr in offsets:
            # 计算有效区域（防止偏移后越界）
            y_start, y_end = max(0, dy), min(h, h + dy)
            x_start, x_end = max(0, dx), min(w, w + dx)
            oy_start, oy_end = max(0, -dy), min(h, h - dy)
            ox_start, ox_end = max(0, -dx), min(w, w - dx)

            if oy_start >= oy_end or ox_start >= ox_end:
                continue

            # 核心：直接对整张掩码进行位移比对
            # 这一步在 NumPy 内部完成，比 Python 循环快几个量级
            shifted_pixels = img_int16[y_start:y_end, x_start:x_end]
            match_offset = np.all(np.abs(shifted_pixels - target_bgr) <= tol, axis=-1)

            # 对齐掩码并做逻辑“与”操作
            aligned_mask = np.zeros((h, w), dtype=bool)
            aligned_mask[oy_start:oy_end, ox_start:ox_end] = match_offset

            final_mask &= aligned_mask

            # 如果中间过程掩码已空，提前终止
            if not np.any(final_mask):
                return []

        # --- 步骤 3: 提取剩下的合格点 ---
        candidates = np.argwhere(final_mask)

        # 防护性熔断：即使过滤后还有海量点（如全屏纯色），限制处理上限
        if len(candidates) > 10000:
            candidates = candidates[:10000]

        # --- 步骤 4: 排序 (根据 ori 参数) ---
        if len(candidates) > 1:
            # 按照你原代码的 1-8 方向逻辑
            # lexsort 是从后往前作为优先级排序的
            order_map = {
                1: (candidates[:, 1], candidates[:, 0]),  # 从左到右, 从上到下
                2: (candidates[:, 0], candidates[:, 1]),  # 从上到下, 从左到右
                3: (candidates[:, 0], -candidates[:, 1]),  # 从上到下, 从右到左
                4: (-candidates[:, 1], candidates[:, 0]),  # 从右到左, 从上到下
                5: (-candidates[:, 1], -candidates[:, 0]),  # 从右到左, 从下到上
                6: (-candidates[:, 0], -candidates[:, 1]),  # 从下到上, 从右到左
                7: (-candidates[:, 0], candidates[:, 1]),  # 从下到上, 从左到右
                8: (candidates[:, 1], -candidates[:, 0]),  # 从左到右, 从下到上
            }
            candidates = candidates[np.lexsort(order_map.get(ori, order_map[2]))]

        # --- 步骤 5: 结果构建与排除半径处理 ---
        results = []
        if exclusion_radius > 0:
            excluded = np.zeros((h, w), dtype=bool)
            for y, x in candidates:
                if excluded[y, x]:
                    continue
                results.append((int(x + offset_l), int(y + offset_t)))
                if max_res > 0 and len(results) >= max_res:
                    break
                # 标记半径内的点为已排除
                y1, y2 = max(0, y - exclusion_radius), min(h, y + exclusion_radius + 1)
                x1, x2 = max(0, x - exclusion_radius), min(w, x + exclusion_radius + 1)
                excluded[y1:y2, x1:x2] = True
        else:
            for y, x in candidates:
                results.append((int(x + offset_l), int(y + offset_t)))
                if max_res > 0 and len(results) >= max_res:
                    break

        return results