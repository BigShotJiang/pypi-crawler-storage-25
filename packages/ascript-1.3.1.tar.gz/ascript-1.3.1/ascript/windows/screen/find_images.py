
from .screen_core import Screen
from .as_cv import AsCv
from ..window import Window

class FindImages:
    """图像查找工具类。

    提供统一的找图接口，支持多种图像来源（全屏截图、窗口句柄、文件路径、PIL/NumPy 对象），
    内部调用 AsCv 的模板匹配和特征匹配算法。
    """

    @staticmethod
    def _get_source_image(im_source):
        """处理多种来源的图像输入，统一转换为 NumPy 数组。

        支持以下输入类型：
        - None: 自动截取全屏图像。
        - Window 对象（含 hwnd 属性）: 截取该窗口画面。
        - int（窗口句柄）: 根据句柄截取窗口画面。
        - 其他（路径/PIL/NumPy）: 通过 AsCv.to_numpy 转换。

        Args:
            im_source: 图像来源，可以是 None、Window 对象、int 句柄、文件路径、PIL Image 或 NumPy 数组。

        Returns:
            numpy.ndarray: BGR 格式的图像数组。
        """
        # 1. 如果为空，全屏截图
        if im_source is None:
            return AsCv.to_numpy(Screen.capture())

        # 2. 如果是 Window 对象 (包含 hwnd)
        if hasattr(im_source, 'hwnd'):
            img = im_source.capture()
            if img is not None: return img
            return AsCv.to_numpy(img)

        # 3. 如果是 int (视为句柄)
        if isinstance(im_source, int):
            img = Window(hwnd=im_source).capture()
            if img is not None: return img
            return AsCv.to_numpy(img)

        # 4. 其余情况（路径、PIL、NumPy）交给 AirCV 处理
        return AsCv.to_numpy(im_source)

    @staticmethod
    def find_all_template(im_search, im_source=None, threshold=0.8, max_res=0, rgb=False):
        """统一模板找图入口，在源图像中查找所有匹配的模板位置。

        自动处理图像来源的格式转换，然后调用 AsCv 的模板匹配算法。

        Args:
            im_search: 模板图像（要查找的小图），支持路径、PIL Image 或 NumPy 数组。
            im_source: 源图像来源，支持路径、PIL Image、NumPy 数组、Window 对象、
                HWND 句柄（int）或 None（自动全屏截图）。
            threshold: 匹配置信度阈值，范围 0.0 ~ 1.0，默认为 0.8。
            max_res: 最大返回结果数，0 表示不限制。
            rgb: 是否启用 RGB 分通道加权匹配模式，默认为 False。

        Returns:
            List[MatchResult]: 匹配结果列表。
        """
        # 自动转换背景源
        source_img = FindImages._get_source_image(im_source)
        # 自动转换搜索图
        search_img = AsCv.to_numpy(im_search)

        # 调用 AirCV 的逻辑
        return AsCv.find_all_template(
            im_source=source_img,
            im_search=search_img,
            threshold=threshold,
            maxcnt=max_res,
            rgb=rgb
        )

    @staticmethod
    def find_template(self):
        """模板查找（预留接口，暂未实现）。"""
        pass

    @staticmethod
    def find_akaze(im_search, im_source=None, threshold=0.5, min_match=10):
        """使用 AKAZE 特征匹配算法在源图像中查找模板。

        适用于目标存在旋转、缩放或视角变化的场景。

        Args:
            im_search: 模板图像（要查找的小图），支持路径、PIL Image 或 NumPy 数组。
            im_source: 源图像来源，支持路径、PIL Image、NumPy 数组、Window 对象、
                HWND 句柄（int）或 None（自动全屏截图）。
            threshold: 内点比例阈值，默认为 0.5。
            min_match: 最少需要的特征匹配点数，默认为 10。

        Returns:
            List[MatchResult]: 匹配结果列表。
        """
        # 自动转换背景源
        source_img = FindImages._get_source_image(im_source)
        # 自动转换搜索图
        search_img = AsCv.to_numpy(im_search)

        # 调用 AirCV 的逻辑
        return AsCv.find_akaze(
            im_source=source_img,
            im_search=search_img,
            threshold=threshold,
            min_match=min_match
        )
