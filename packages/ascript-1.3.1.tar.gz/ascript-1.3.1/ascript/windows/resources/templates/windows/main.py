"""AScript Windows 应用模板的入口程序。

演示如何使用 FloatScriptWindow 创建带有启动/停止控制的自动化脚本应用。
"""
import multiprocessing
import time
import sys
from ascript.windows.system import R  # 程序上下文与资源路由
from ascript.windows.ui import LicenseWindow  # 安全验证组件
from ascript.windows.ui import FloatScriptWindow  # 脚本控制台组件

# 初始化控制台：支持自启动 (auto_start) 与 多进程隔离 (use_process)
app = FloatScriptWindow(R.img("logo.ico"), title="我的程序", auto_start=True)

@app.on('start')
def task_start():
    """业务逻辑入口函数。

    当用户点击启动按钮或触发自启动时，此函数将在独立的子进程中运行。
    在此函数中编写自动化任务的核心业务逻辑。
    """
    print(">>> [系统] 业务进程已建立，开始执行自动化任务...")
    i= 0

    # 模拟耗时逻辑操作
    while True:
        print(i)
        time.sleep(0.5)
        i += 1


@app.on('stop')
def task_stop():
    """任务停止时的善后处理回调。

    当用户手动停止或任务结束时触发。可在此执行资源释放操作，
    如关闭文件句柄、断开数据库连接等。注意约有 3 秒的执行时限，
    超时后系统会强制回收进程资源。
    """
    print(">>> [系统] 接收到停止信号，正在释放系统资源...")
    # 模拟保存数据逻辑
    time.sleep(1)
    print(">>> [系统] 资源释放完毕，安全退出。")




if __name__ == '__main__':
    # 解决打包后子进程重复启动问题
    app.show()