import time
import random
import pydirectinput
from ctypes import windll
from typing import Optional

# 启用 DPI 感知
try:
    windll.shcore.SetProcessDpiAwareness(1)
except:
    try:
        windll.user32.SetProcessDPIAware()
    except:
        pass


class Mouse:
    """鼠标自动化控制类。

    基于 PyDirectInput 封装，支持鼠标移动、点击、长按、滚动、拖拽等操作。
    已启用 DPI 感知，自动处理 Windows 高分屏缩放。
    所有方法均为类方法，返回类本身以支持链式调用。

    Attributes:
        LEFT: 左键标识符。
        MIDDLE: 中键标识符。
        RIGHT: 右键标识符。
        DEFAULT_MOVE_DURATION: 默认鼠标移动耗时（秒）。
    """

    # 基础按键定义
    LEFT = "left"
    MIDDLE = "middle"
    RIGHT = "right"

    # 全局配置
    pydirectinput.FAILSAFE = True
    DEFAULT_MOVE_DURATION = 0.1

    @classmethod
    def mouse_move(cls, x: int, y: int, move_duration: float = DEFAULT_MOVE_DURATION):
        """移动鼠标到屏幕上的指定坐标位置。

        Args:
            x: 目标位置的屏幕 X 坐标。
            y: 目标位置的屏幕 Y 坐标。
            move_duration: 鼠标移动过程的耗时（秒），默认为 0.1。

        Returns:
            Mouse 类本身，支持链式调用。
        """
        pydirectinput.moveTo(x=x, y=y, duration=move_duration)
        return cls

    @classmethod
    def mouse_down(cls, x: int = None, y: int = None, button: str = LEFT):
        """按下鼠标按键不松开。

        Args:
            x: 按下时的屏幕 X 坐标，为 None 时在当前位置按下。
            y: 按下时的屏幕 Y 坐标，为 None 时在当前位置按下。
            button: 鼠标按键，可选 'left'、'middle'、'right'，默认为左键。

        Returns:
            Mouse 类本身，支持链式调用。
        """
        pydirectinput.mouseDown(x=x, y=y, button=button)
        return cls

    @classmethod
    def mouse_up(cls, x: int = None, y: int = None, button: str = LEFT):
        """松开已按下的鼠标按键。

        Args:
            x: 松开时的屏幕 X 坐标，为 None 时在当前位置松开。
            y: 松开时的屏幕 Y 坐标，为 None 时在当前位置松开。
            button: 鼠标按键，可选 'left'、'middle'、'right'，默认为左键。

        Returns:
            Mouse 类本身，支持链式调用。
        """
        pydirectinput.mouseUp(x=x, y=y, button=button)
        return cls

    @classmethod
    def click(cls,
              x: Optional[int] = None,
              y: Optional[int] = None,
              clicks: int = 1,
              interval: float = 0.1,
              button: str = LEFT,
              move_duration: float = 0.0,
              duration: float = 0.05,
              offset: int = 0):
        """模拟鼠标点击操作。

        支持指定坐标、多次点击、随机偏移等功能。

        Args:
            x: 点击位置的屏幕 X 坐标，为 None 时在当前位置点击。
            y: 点击位置的屏幕 Y 坐标，为 None 时在当前位置点击。
            clicks: 点击次数，默认为 1。设为 2 可实现双击。
            interval: 多次点击之间的间隔时间（秒），默认为 0.1。
            button: 鼠标按键，可选 'left'、'middle'、'right'，默认为左键。
            move_duration: 移动到目标位置的耗时（秒），默认为 0.0（瞬移）。
            duration: 按下与弹起之间的物理间隔（秒），增大此值可提高点击成功率，默认为 0.05。
            offset: 随机偏移范围（像素），大于 0 时会在目标坐标附近随机偏移，用于模拟人类操作。

        Returns:
            Mouse 类本身，支持链式调用。
        """
        target_x, target_y = x, y

        if offset > 0 and x is not None and y is not None:
            target_x = max(0, x + random.randint(-offset, offset))
            target_y = max(0, y + random.randint(-offset, offset))

        if target_x is not None and target_y is not None:
            cls.mouse_move(target_x, target_y, move_duration=move_duration)

        for i in range(clicks):
            cls.mouse_down(button=button)
            time.sleep(max(0.01, duration))
            cls.mouse_up(button=button)
            if i < clicks - 1:
                time.sleep(interval)
        return cls

    @classmethod
    def long_press(cls, x: int = None, y: int = None, press_duration: float = 2.0, button: str = LEFT):
        """模拟鼠标长按操作。

        在指定位置按下鼠标并保持一段时间后松开。

        Args:
            x: 长按位置的屏幕 X 坐标，为 None 时在当前位置操作。
            y: 长按位置的屏幕 Y 坐标，为 None 时在当前位置操作。
            press_duration: 按住的持续时间（秒），默认为 2.0。
            button: 鼠标按键，可选 'left'、'middle'、'right'，默认为左键。

        Returns:
            Mouse 类本身，支持链式调用。
        """
        if x is not None and y is not None:
            cls.mouse_move(x, y, move_duration=0.0)

        cls.mouse_down(button=button)
        time.sleep(press_duration)
        cls.mouse_up(button=button)
        return cls

    @classmethod
    def scroll(cls, clicks: int, x: int = None, y: int = None):
        """模拟鼠标滚轮滚动。

        Args:
            clicks: 滚动量，正数向上滚动，负数向下滚动。
            x: 滚动时的屏幕 X 坐标，为 None 时在当前位置滚动。
            y: 滚动时的屏幕 Y 坐标，为 None 时在当前位置滚动。

        Returns:
            Mouse 类本身，支持链式调用。
        """
        if x is not None and y is not None:
            cls.mouse_move(x, y, move_duration=0.0)
        pydirectinput.scroll(clicks)
        return cls

    @classmethod
    def drag(cls, to_x: int, to_y: int, from_x: int = None, from_y: int = None, move_duration: float = 0.5):
        """从指定位置拖拽鼠标到目标位置。

        使用左键进行拖拽操作。如果不指定起始位置，则从当前鼠标位置开始拖拽。

        Args:
            to_x: 拖拽目标的屏幕 X 坐标。
            to_y: 拖拽目标的屏幕 Y 坐标。
            from_x: 拖拽起始的屏幕 X 坐标，为 None 时从当前位置开始。
            from_y: 拖拽起始的屏幕 Y 坐标，为 None 时从当前位置开始。
            move_duration: 拖拽移动过程的耗时（秒），默认为 0.5。

        Returns:
            Mouse 类本身，支持链式调用。
        """
        if from_x is not None and from_y is not None:
            cls.mouse_move(from_x, from_y, move_duration=0.0)

        pydirectinput.dragTo(to_x, to_y, duration=move_duration, button=cls.LEFT)
        return cls

    @classmethod
    def wait(cls, seconds: float):
        """在鼠标操作链中插入等待。

        Args:
            seconds: 等待的时长（秒）。

        Returns:
            Mouse 类本身，支持链式调用。
        """
        time.sleep(seconds)
        return cls