import ctypes
import time
import sys
import os
from ..system import R


class LogitechDriver:
    """罗技驱动级硬件操作类。

    通过加载罗技 G HUB SDK 的 DLL，实现驱动级别的鼠标点击和移动操作。
    需要系统已安装并运行罗技 G HUB 驱动程序。
    支持 x86 和 x64 架构自动适配。

    Attributes:
        DLL_NAME: 罗技 SDK DLL 文件名。
        _dll: 已加载的 DLL 对象实例。
        _initialized: 驱动是否已完成初始化。
    """

    DLL_NAME = "LogitechGkeyEnginesWrapper.dll"

    _dll = None
    _initialized = False

    @classmethod
    def _get_dll_path(cls):
        """根据当前 Python 解释器的位数定位对应架构的 DLL 文件路径。

        Returns:
            str: DLL 文件的完整路径。
        """
        arch = "x64" if sys.maxsize > 2 ** 32 else "x86"
        return R.internal("windows", "resources", "libs", "logitech", arch, cls.DLL_NAME)

    @classmethod
    def _is_ghub_running(cls) -> bool:
        """检测罗技 G HUB 进程是否正在运行。

        通过 tasklist 命令检查 lghub.exe、lghub_agent.exe、lghub_updater.exe
        等进程是否存在。

        Returns:
            bool: G HUB 正在运行返回 True，否则返回 False。
        """
        try:
            # 罗技 G HUB 可能存在于这三个进程中
            targets = {"lghub.exe", "lghub_agent.exe", "lghub_updater.exe"}
            with os.popen('tasklist /NH /FI "STATUS eq running"') as f:
                output = f.read().lower()
            return any(t in output for t in targets)
        except:
            return False

    @classmethod
    def init(cls) -> bool:
        """初始化罗技驱动。

        执行环境检查（G HUB 进程、DLL 文件），加载 DLL 并尝试调用
        SDK 初始化函数。初始化成功后会等待 0.5 秒确保驱动就绪。
        重复调用时若已初始化会直接返回 True。

        Returns:
            bool: 初始化成功返回 True，失败返回 False。
        """
        if cls._initialized:
            return True

        # 1. 环境检查
        if not cls._is_ghub_running():
            print("[LogitechDriver] 错误: 未检测到 G HUB 进程，请确保罗技驱动已启动。")
            return False

        dll_path = cls._get_dll_path()
        if not os.path.exists(dll_path):
            print(f"[LogitechDriver] 错误: 找不到 DLL -> {dll_path}")
            return False

        try:
            # 2. 加载 DLL 并强制使用 Windows 路径标准
            cls._dll = ctypes.CDLL(dll_path)

            # 3. 尝试所有可能的初始化导出函数
            # 罗技 SDK 随版本变化，函数名可能为以下其一
            init_functions = [
                "LogiGkeyInitWithoutContext",
                "LogiGkeyInit",
                "LogiGkeyInitWithoutScene"
            ]

            success = False
            for func_name in init_functions:
                if hasattr(cls._dll, func_name):
                    if getattr(cls._dll, func_name)():
                        success = True
                        break

            if success:
                # [关键] 驱动初始化后必须等待，否则紧随其后的指令会丢失
                time.sleep(0.5)
                cls._initialized = True
                return True

            return False
        except Exception as e:
            print(f"[LogitechDriver] 加载异常: {e}")
            return False

    @classmethod
    def advanced_click_guide(cls):
        """高级引导：检查运行权限与驱动环境。

        检查当前是否以管理员权限运行，并尝试激活驱动模式。
        在控制台输出检查结果供用户排查问题。

        Returns:
            bool: 驱动激活成功返回 True，失败返回 False。
        """
        print("--- [Logitech] 底层引擎自检 ---")

        # 管理员权限检查
        try:
            is_admin = ctypes.windll.shell32.IsUserAnAdmin() != 0
        except:
            is_admin = False

        if not is_admin:
            print("⚠️ 注意: 当前非管理员权限，这可能是点击无效的主因！")

        if cls.init():
            print("✅ 驱动模式已激活。")
            return True
        else:
            print("❌ 驱动激活失败，请检查 G HUB 是否正常运行。")
            return False

    @classmethod
    def click(cls, button: int = 1, duration: float = 0.05):
        """执行驱动级鼠标点击。

        通过罗技 SDK 直接发送鼠标按键事件，可绕过部分反作弊检测。

        Args:
            button: 鼠标按键编号，1=左键，2=中键，4=右键（SDK 定义）。
            duration: 按下与释放之间的间隔时间（秒），默认为 0.05。

        Returns:
            bool: 点击成功返回 True，失败（驱动未初始化或异常）返回 False。
        """
        if not cls.init():
            return False
        try:
            cls._dll.LogiMouseButtonPressed(button)
            time.sleep(duration)
            cls._dll.LogiMouseButtonReleased(button)
            return True
        except:
            return False

    @classmethod
    def move_rel(cls, x: int, y: int):
        """驱动级鼠标相对位移。

        通过罗技 SDK 发送鼠标相对移动事件。

        Args:
            x: 水平方向的相对位移量（像素）。
            y: 垂直方向的相对位移量（像素）。

        Returns:
            bool: 移动成功返回对应的 SDK 返回值，失败返回 False。
        """
        if not cls.init():
            return False
        try:
            # 罗技相对移动
            return cls._dll.LogiMouseRelativeMove(int(x), int(y))
        except:
            return False