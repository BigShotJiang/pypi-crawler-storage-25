import time
import pyautogui
import pyperclip
from typing import Union, List

class Keyboard:
    """键盘自动化操作类。

    基于 PyAutoGUI 封装，支持中英文智能输入、组合键操作及链式调用。
    中文输入通过剪贴板粘贴实现，英文输入通过模拟按键实现。
    所有方法均为类方法，返回类本身以支持链式调用。
    """

    @classmethod
    def input(cls, msg: str, interval: float = 0.0):
        """自动识别中英文并输入文本。

        如果文本包含非 ASCII 字符（如中文、全角符号），通过剪贴板粘贴实现；
        如果是纯英文，通过模拟键盘敲击实现。

        Args:
            msg: 要输入的字符串内容。
            interval: 仅对纯英文输入有效，每个字符之间敲击的间隔时间（秒），默认为 0.0。

        Returns:
            Keyboard 类本身，支持链式调用。
        """
        # 检查是否包含非 ASCII 字符（如中文、全角符号等）
        if any(ord(c) > 127 for c in msg):
            # 备份当前剪贴板（可选，如果需要更严谨可以记录后还原）
            pyperclip.copy(msg)
            time.sleep(0.1)  # 缓冲，确保系统剪贴板已更新
            pyautogui.hotkey('ctrl', 'v')
        else:
            # 纯英文使用 write，比 typewrite 更现代
            pyautogui.write(msg, interval=interval)
        return cls

    @classmethod
    def key(cls, keys: Union[str, List[str]], presses: int = 1, interval: float = 0.1):
        """按下并释放指定按键。

        Args:
            keys: 按键名称（如 'enter'、'esc'）或按键名称列表。
            presses: 连续按下的次数，默认为 1。
            interval: 连续按下之间的间隔时间（秒），默认为 0.1。

        Returns:
            Keyboard 类本身，支持链式调用。
        """
        pyautogui.press(keys, presses=presses, interval=interval)
        return cls

    @classmethod
    def key_hot(cls, *args, interval: float = 0.1):
        """执行组合键操作。

        例如 key_hot('ctrl', 'c') 执行复制操作。

        Args:
            *args: 按键序列，例如 'ctrl', 'alt', 'delete'。
            interval: 按键按下之间的间隔时间（秒），默认为 0.1。

        Returns:
            Keyboard 类本身，支持链式调用。
        """
        pyautogui.hotkey(*args, interval=interval)
        return cls

    @classmethod
    def key_down(cls, key_str: str):
        """按下指定按键不松开。

        Args:
            key_str: 按键名称，如 'shift'、'ctrl'。

        Returns:
            Keyboard 类本身，支持链式调用。
        """
        pyautogui.keyDown(key_str)
        return cls

    @classmethod
    def key_up(cls, key_str: str):
        """松开已按下的按键。

        Args:
            key_str: 按键名称，如 'shift'、'ctrl'。

        Returns:
            Keyboard 类本身，支持链式调用。
        """
        pyautogui.keyUp(key_str)
        return cls

    @classmethod
    def wait(cls, seconds: float):
        """在键盘操作链中插入等待。

        Args:
            seconds: 等待的时长（秒）。

        Returns:
            Keyboard 类本身，支持链式调用。
        """
        time.sleep(seconds)
        return cls