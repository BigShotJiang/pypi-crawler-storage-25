import os
import pathlib
import re
import subprocess
import winreg
from typing import Optional, Tuple
import win32com.client


class Launcher:
    """Windows 应用程序启动器。

    提供通过应用名称或路径查找、解析和启动 Windows 应用程序的能力。
    支持从注册表、快捷方式等多种途径自动定位可执行文件。
    """

    @staticmethod
    def get_info(name: Optional[str] = None, path: Optional[str] = None) -> Tuple[Optional[str], Optional[str]]:
        """根据应用名称或路径获取可执行文件的物理路径和进程名。

        按优先级依次尝试：直接路径 -> 注册表查找 -> 快捷方式解析。

        Args:
            name: 应用名称（支持正则表达式），用于注册表和快捷方式搜索
            path: 可执行文件的直接路径，若存在则优先使用

        Returns:
            (物理路径, 进程名) 的元组，未找到路径时路径为 None
        """
        if path and os.path.exists(path):
            return str(path), os.path.basename(path)

        if name:
            # 1. 尝试从注册表获取 (App Paths & Uninstall)
            reg_path, proc_name = Launcher._get_path_from_registry(name)
            if reg_path:
                return reg_path, proc_name

            # 2. 尝试搜索并解析快捷方式
            lnk_path = Launcher._find_shortcut(name)
            if lnk_path:
                real_path = Launcher._resolve_lnk(lnk_path)
                if real_path:
                    return real_path, os.path.basename(real_path)

        return None, (f"{name}.exe" if name and ".exe" not in name.lower() else name)

    @staticmethod
    def run(name: Optional[str] = None, path: Optional[str] = None) -> bool:
        """启动应用程序。

        支持通过物理路径启动、系统应用名称启动和 Shell 协议启动。
        优先使用 os.startfile（模拟双击），失败时回退到 subprocess。

        Args:
            name: 应用名称（如 'notepad'、'calc'），用于 Shell 启动
            path: 可执行文件的完整路径

        Returns:
            启动成功返回 True，失败返回 False
        """
        final_path, _ = Launcher.get_info(name, path)

        # 场景 1：有明确的物理路径（你自己安装的软件）
        if final_path and os.path.exists(final_path):
            try:
                # 这种方式最接近鼠标双击，能处理系统重定向和 UAC 权限
                os.startfile(final_path)
                return True
            except Exception as e:
                # 备选：强制使用 shell 执行
                subprocess.Popen(f'start "" "{final_path}"', shell=True)
                return True

        # 场景 2：系统应用保底（比如：电脑管家、计算器、记事本）
        # 如果通过路径找不到，我们直接尝试通过 Windows Shell 搜索启动
        if name:
            try:
                # 尝试通过 Windows 命令行 start 指令启动
                # 这种方式会自动处理环境变量中的程序（如 notepad, calc, cmd）
                # 也能尝试唤起已经注册在 Shell 里的名字
                subprocess.Popen(f'start {name}', shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return True
            except:
                pass

        return False

    @staticmethod
    def _get_path_from_registry(name_regex: str) -> Tuple[Optional[str], Optional[str]]:
        """从 Windows 注册表中查找应用程序的可执行文件路径。

        深度扫描 App Paths 和 Uninstall 注册表项（覆盖 32 位和 64 位），
        同时搜索 HKLM 和 HKCU 根键。支持通过键名和 DisplayName 两种方式匹配。

        Args:
            name_regex: 应用名称的正则表达式模式

        Returns:
            (可执行文件路径, 进程名) 的元组，未找到返回 (None, None)
        """
        reg_keys = [
            r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths",
            r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths",
            r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
            r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall",
        ]
        regex = re.compile(name_regex, re.IGNORECASE)

        # 遍历 HKLM 和 HKCU
        for root_key in [winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER]:
            for key_path in reg_keys:
                try:
                    with winreg.OpenKey(root_key, key_path) as key:
                        for i in range(winreg.QueryInfoKey(key)[0]):
                            try:
                                sub_key_name = winreg.EnumKey(key, i)
                                # 1. 先匹配键名（例如：QQPCMgr）
                                # 2. 如果键名没匹配上，进去看 DisplayName（例如：腾讯电脑管家）
                                match_found = False
                                if regex.search(sub_key_name):
                                    match_found = True

                                with winreg.OpenKey(key, sub_key_name) as sub_key:
                                    display_name = ""
                                    try:
                                        display_name, _ = winreg.QueryValueEx(sub_key, "DisplayName")
                                    except:
                                        pass

                                    if not match_found and display_name and regex.search(display_name):
                                        match_found = True

                                    if match_found:
                                        # 提取路径的优先级：Default > DisplayIcon > InstallLocation
                                        path = ""
                                        for val_name in ["", "DisplayIcon", "InstallLocation", "UninstallString"]:
                                            try:
                                                path, _ = winreg.QueryValueEx(sub_key, val_name)
                                                if path: break
                                            except:
                                                continue

                                        if path:
                                            # 清理路径：去掉引号，去掉末尾的参数（如 ,0 或 /uninstall）
                                            clean_path = path.split(',')[0].split(' /')[0].strip('"')
                                            # 如果是目录，尝试补全 exe (针对只有 InstallLocation 的情况)
                                            if os.path.isdir(clean_path):
                                                # 尝试在目录下找包含关键字的 exe
                                                for f in os.listdir(clean_path):
                                                    if f.lower().endswith(".exe") and regex.search(f):
                                                        full_exe = os.path.join(clean_path, f)
                                                        return full_exe, f

                                            if os.path.exists(clean_path) and clean_path.lower().endswith(".exe"):
                                                return clean_path, os.path.basename(clean_path)
                            except:
                                continue
                except:
                    continue
        return None, None

    @staticmethod
    def _find_shortcut(name_regex: str) -> Optional[pathlib.Path]:
        """在常见位置搜索匹配的快捷方式文件（.lnk）。

        扫描开始菜单程序目录、公共桌面和用户桌面等位置。

        Args:
            name_regex: 快捷方式名称的正则表达式模式

        Returns:
            匹配的第一个快捷方式路径，未找到返回 None
        """
        search_paths = [
            pathlib.Path(os.environ.get("ProgramData", "")) / "Microsoft/Windows/Start Menu/Programs",
            pathlib.Path(os.environ.get("AppData", "")) / "Microsoft/Windows/Start Menu/Programs",
            pathlib.Path(os.environ.get("Public", r"C:\Users\Public")) / "Desktop",
            pathlib.Path(os.path.expanduser("~")) / "Desktop"
        ]
        regex = re.compile(name_regex, re.IGNORECASE)
        for p in search_paths:
            if not p.exists(): continue
            try:
                for link in p.rglob("*.lnk"):
                    if regex.search(link.stem): return link
            except:
                continue
        return None

    @staticmethod
    def _resolve_lnk(lnk_path: pathlib.Path) -> Optional[str]:
        """解析 Windows 快捷方式（.lnk）文件的真实目标路径。

        使用 WScript.Shell COM 对象读取快捷方式的 TargetPath。

        Args:
            lnk_path: 快捷方式文件的路径

        Returns:
            快捷方式指向的目标路径字符串，解析失败返回 None
        """
        try:
            shell = win32com.client.Dispatch("WScript.Shell")
            return shell.CreateShortcut(str(lnk_path)).TargetPath
        except:
            return None

