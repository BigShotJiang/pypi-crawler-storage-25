
from typing import List, NamedTuple
import win32gui
import win32con
import win32ui
import win32process
import psutil
import time
from ctypes import windll, byref, sizeof, c_int
from ctypes.wintypes import RECT
from PIL import Image
import re
from enum import Enum, auto
from typing import Optional, Union,TYPE_CHECKING
import numpy as np
import cv2
import ctypes
from ..hardware import Mouse

# 启用 DPI 感知
try:
    windll.shcore.SetProcessDpiAwareness(1)
except:
    windll.user32.SetProcessDPIAware()

# 1. 定义独立的结构类
class WindowRect(NamedTuple):
    """窗口空间位置信息 (不占内存，支持补全)。

    Args:
        left: 窗口左边界的屏幕 X 坐标
        top: 窗口上边界的屏幕 Y 坐标
        right: 窗口右边界的屏幕 X 坐标
        bottom: 窗口下边界的屏幕 Y 坐标
        width: 窗口宽度（像素）
        height: 窗口高度（像素）
    """
    left: int
    top: int
    right: int
    bottom: int
    width: int
    height: int

class WindowCaptureFormat(Enum):
    """窗口截图输出格式枚举。

    定义了截图方法返回图像的格式选项，包括 PIL、NumPy 数组和 OpenCV BGR 格式。
    """
    PIL = auto()      # 返回 PIL.Image (默认，最常用)
    NUMPY = auto()    # 返回 numpy.ndarray (RGB)
    OPENCV = auto()   # 返回 numpy.ndarray (BGR，适合 cv2 使用)

    def convert(self, pil_image: Image.Image) -> Union[Image.Image, np.ndarray]:
        """将 PIL.Image 转换为当前枚举指定的格式。

        Args:
            pil_image: 原始的 PIL 图像对象

        Returns:
            根据枚举值返回对应格式的图像：PIL.Image、numpy RGB 数组或 numpy BGR 数组
        """
        if self is WindowCaptureFormat.PIL:
            return pil_image

        array = np.array(pil_image)  # RGB

        if self is WindowCaptureFormat.NUMPY:
            return array

        if self is WindowCaptureFormat.OPENCV:
            return cv2.cvtColor(array, cv2.COLOR_RGB2BGR)

        # 理论上不会走到这里，但为了安全
        raise ValueError(f"Unsupported format: {self}")

class Window:
    """Windows 窗口操作封装类。

    提供对 Windows 窗口的查找、激活、截图、点击、拖拽、输入等操作的统一接口。
    通过窗口句柄（hwnd）标识和操作目标窗口。
    """

    def __init__(self, hwnd):
        """初始化窗口对象。

        Args:
            hwnd: Windows 窗口句柄（HWND）
        """
        self.hwnd = hwnd
        self._pid = None  # 延迟加载缓存

    def __repr__(self):
        return f"<Window: {self.title[:15]} [{self.process_name[:15]}] (HWND:{self.hwnd})>"

    @classmethod
    def find_all(
            cls,
            title_re: str = None,
            process_name: str = None,
            class_name: str = None,
            visible_only: bool = True
    ) -> List["Window"]:
        """批量检索满足条件的所有窗口。

        遍历系统中的所有顶层窗口，根据标题正则、进程名、类名等条件进行筛选。

        Args:
            title_re: 窗口标题的正则表达式匹配模式，为 None 则不过滤标题
            process_name: 进程名关键字（不区分大小写的包含匹配），为 None 则不过滤进程
            class_name: 精确匹配的窗口类名，为 None 则不过滤类名
            visible_only: 是否只返回可见窗口，默认为 True

        Returns:
            符合条件的 Window 对象列表
        """
        results = []
        pattern = re.compile(title_re) if title_re else None

        def callback(hwnd, _):
            if visible_only and not win32gui.IsWindowVisible(hwnd):
                return True

            win = cls(hwnd)
            if class_name and class_name != win.class_name:
                return True
            if process_name and process_name.lower() not in win.process_name.lower():
                return True
            if pattern and not pattern.search(win.title):
                return True

            if win.title:
                results.append(win)
            return True

        win32gui.EnumWindows(callback, None)
        return results

    @classmethod
    def find(
            cls,
            title_re: str = None,
            process_name: str = None,
            class_name: str = None,
            visible_only: bool = True,
            timeout: int = 0
    ) -> Optional["Window"]:
        """快速检索满足条件的第一个窗口。

        与 find_all 相同的筛选逻辑，但只返回第一个匹配结果。支持超时等待机制。

        Args:
            title_re: 窗口标题的正则表达式匹配模式
            process_name: 进程名关键字（不区分大小写）
            class_name: 精确匹配的窗口类名
            visible_only: 是否只返回可见窗口，默认为 True
            timeout: 等待超时时间（秒），默认为 0 表示立即返回；大于 0 时会以 0.5 秒间隔轮询

        Returns:
            匹配的第一个 Window 对象，未找到则返回 None
        """
        start_time = time.time()

        while True:
            # 直接调用 find_all 获取当前所有匹配项
            results = cls.find_all(
                title_re=title_re,
                process_name=process_name,
                class_name=class_name,
                visible_only=visible_only
            )

            if results:
                return results[0]

            # 如果没有设置超时，或者已超时，则退出循环
            if timeout <= 0 or (time.time() - start_time) > timeout:
                break

            time.sleep(0.5)  # 轮询间隔，避免过度占用 CPU

        return None

    @classmethod
    def launch(
            cls,
            name: str = None,
            path: str = None,
            allow_multiple: bool = False,
            timeout: int = 15
    ) -> Optional["Window"]:
        """启动应用程序并返回其窗口对象。

        支持通过应用名称或可执行文件路径启动应用。若应用已运行且不允许多开，
        则直接激活已有窗口。启动后会轮询等待窗口出现。

        Args:
            name: 应用名称（用于注册表查找和窗口匹配）
            path: 可执行文件的完整路径，优先级高于 name 的自动查找
            allow_multiple: 是否允许多开，默认为 False（已有窗口时直接复用）
            timeout: 等待新窗口出现的超时时间（秒），默认 15 秒

        Returns:
            启动或找到的 Window 对象，超时未找到则返回 None 或已有窗口
        """
        from .launcher import Launcher

        # 1. 修正方法名：使用 get_info 自动关联进程名
        auto_path, proc_name = Launcher.get_info(name, path)
        final_path = path or auto_path

        # 2. 修正逻辑：使用 find_all 获取列表，确保判断多开时的基数准确
        pre_wins = cls.find_all(title_re=name, process_name=proc_name, visible_only=False)

        if not allow_multiple and pre_wins:
            win = pre_wins[0]
            # 唤醒逻辑：处理最小化和托盘
            win32gui.ShowWindow(win.hwnd, 9)  # SW_RESTORE
            win.activate()
            return win

        # 3. 启动
        Launcher.run(name=name, path=final_path)

        # 4. 轮询
        start_time = time.time()
        pre_hwnds = {w.hwnd for w in pre_wins}
        while time.time() - start_time < timeout:
            # 持续用 find_all 刷新当前窗口状态
            current_wins = cls.find_all(title_re=name, process_name=proc_name, visible_only=False)

            if allow_multiple:
                new_wins = [w for w in current_wins if w.hwnd not in pre_hwnds]
                if new_wins:
                    new_wins[0].activate()
                    return new_wins[0]
            else:
                if current_wins:
                    current_wins[0].activate()
                    return current_wins[0]

            time.sleep(0.5)

        return pre_wins[0] if pre_wins else None

    # --- 基础标识属性 ---
    @property
    def title(self):
        """窗口标题"""
        return win32gui.GetWindowText(self.hwnd)

    @property
    def class_name(self):
        """窗口类名 (用于区分应用类型)"""
        return win32gui.GetClassName(self.hwnd)

    # --- 进程相关属性 ---
    @property
    def pid(self):
        """进程 ID"""
        if self._pid is None:
            _, self._pid = win32process.GetWindowThreadProcessId(self.hwnd)
        return self._pid

    @property
    def process_path(self):
        """可执行文件完整路径"""
        try:
            return psutil.Process(self.pid).exe()
        except:
            return "Unknown"

    @property
    def process_name(self):
        """进程名 (如 chrome.exe)"""
        try:
            return psutil.Process(self.pid).name()
        except:
            return "Unknown"

    # --- 状态属性 ---
    @property
    def is_visible(self):
        """判断窗口是否真正可见。

        综合检查系统可见性标志、窗口面积、坐标合理性和标题有效性。

        Returns:
            如果窗口确实可见则返回 True，否则返回 False
        """
        # 1. 基础检查：系统必须认为它是可见的
        if not win32gui.IsWindowVisible(self.hwnd):
            return False

        # 2. 面积检查：宽高必须大于 0
        left, top, right, bottom = win32gui.GetWindowRect(self.hwnd)
        width = right - left
        height = bottom - top
        if width <= 0 or height <= 0:
            return False

        # 3. 坐标检查：不能在极远的“异次元”坐标（有些库会把隐藏窗口丢到 -32000）
        if left < -30000 or top < -30000:
            return False

        # 4. 标题检查（可选）：如果标题变空了，可能窗口正在销毁中
        if not win32gui.GetWindowText(self.hwnd):
            return False

        return True

    @property
    def is_minimized(self):
        """是否最小化"""
        return win32gui.IsIconic(self.hwnd) != 0

    @property
    def is_maximized(self):
        """是否最大化"""
        tup = win32gui.GetWindowPlacement(self.hwnd)
        return tup[1] == win32con.SW_SHOWMAXIMIZED

    @property
    def is_responding(self):
        """窗口是否响应（未卡死）"""
        # 显式获取函数对象，避免属性查找错误
        is_hung = getattr(windll.user32, "IsHungAppWindow", None)
        if is_hung:
            return is_hung(self.hwnd) == 0

        # 如果还是找不到，回退到方案二
        return self._check_responding_via_timeout()

    @property
    def _check_responding_via_timeout(self):
        """通过发送超时消息检测窗口是否仍在响应。

        作为 is_responding 的备选检测方案，通过 SendMessageTimeout 发送 WM_NULL 消息，
        如果窗口在 100 毫秒内无响应则判定为卡死。

        Returns:
            窗口响应返回 True，超时或异常返回 False
        """
        try:
            # SMTO_ABORTIFHUNG: 如果窗口已卡死，直接返回
            # 100 是超时时间（毫秒）
            res = win32gui.SendMessageTimeout(
                self.hwnd,
                win32con.WM_NULL,
                0, 0,
                win32con.SMTO_ABORTIFHUNG | win32con.SMTO_BLOCK,
                100
            )
            # 如果返回值为 0，通常表示超时或失败
            return res[0] != 0
        except:
            return False

    @property
    def is_always_on_top(self):
        """是否处于“总在最前”置顶状态"""
        style = win32gui.GetWindowLong(self.hwnd, win32con.GWL_EXSTYLE)
        return (style & win32con.WS_EX_TOPMOST) != 0

    @property
    def rect(self) -> WindowRect:
        """
        [属性] 获取窗口精准的视觉坐标和大小 (DPI感知)
        用法: win.rect.width, win.rect.top
        """
        r = RECT()
        # 底层 DWM 逻辑：获取真实的视觉边界
        windll.dwmapi.DwmGetWindowAttribute(self.hwnd, 9, byref(r), sizeof(r))

        w = r.right - r.left
        h = r.bottom - r.top

        return WindowRect(r.left, r.top, r.right, r.bottom, w, h)

    def set_rect(self, x: int = None, y: int = None, width: int = None, height: int = None):
        """统一调整窗口的位置和大小。

        可以同时或单独设置窗口的坐标和尺寸，未指定的参数保持当前值不变。

        Args:
            x: 目标 X 坐标（像素），None 则保持现状
            y: 目标 Y 坐标（像素），None 则保持现状
            width: 目标宽度（像素），None 则保持现状
            height: 目标高度（像素），None 则保持现状
        """
        # 1. 拿当前的 rect (利用我们定义好的 WindowRect 结构)
        curr = self.rect

        # 2. 确定最终参数：如果有传入则用传入值，否则用当前值
        new_x = x if x is not None else curr.left
        new_y = y if y is not None else curr.top
        new_w = width if width is not None else curr.width
        new_h = height if height is not None else curr.height

        # 3. 调用底层 API
        # SWP_NOZORDER: 保证窗口在移动时不会改变它在所有窗口中的层级顺序
        win32gui.SetWindowPos(
            self.hwnd,
            win32con.HWND_TOP,
            new_x, new_y, new_w, new_h,
            win32con.SWP_NOZORDER | win32con.SWP_SHOWWINDOW
        )

    def move(self, x: int, y: int):
        """移动窗口到指定位置，不改变窗口大小。

        Args:
            x: 目标屏幕 X 坐标（像素）
            y: 目标屏幕 Y 坐标（像素）
        """
        self.set_rect(x=x, y=y)

    def resize(self, width: int, height: int):
        """调整窗口大小，不改变窗口位置。

        Args:
            width: 目标宽度（像素）
            height: 目标高度（像素）
        """
        self.set_rect(width=width, height=height)

    # --- 核心操作方法 ---
    def activate(self):
        """激活窗口并将其带到前台显示。

        如果窗口处于最小化状态，会先恢复窗口再置前台。
        """
        if self.is_minimized:
            win32gui.ShowWindow(self.hwnd, win32con.SW_RESTORE)
        windll.user32.SetForegroundWindow(self.hwnd)

    def set_always_on_top(self, toggle=True):
        """设置或取消窗口置顶状态。

        Args:
            toggle: True 为置顶，False 为取消置顶
        """
        z_order = win32con.HWND_TOPMOST if toggle else win32con.HWND_NOTOPMOST
        win32gui.SetWindowPos(self.hwnd, z_order, 0, 0, 0, 0,
                              win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)

    def minimize(self):
        """将窗口最小化到任务栏。"""
        win32gui.ShowWindow(self.hwnd, win32con.SW_MINIMIZE)

    def close(self):
        """发送 WM_CLOSE 消息以标准方式关闭窗口。

        这是温和的关闭方式，应用可能会弹出保存确认对话框。
        """
        win32gui.PostMessage(self.hwnd, win32con.WM_CLOSE, 0, 0)

    def kill(self):
        """强行终止窗口所属的进程。

        Returns:
            终止成功返回 True，失败返回 False
        """
        try:
            psutil.Process(self.pid).kill()
            return True
        except:
            return False

    # --- 增强版截图 (解决黑屏+尺寸不对) ---
    def capture(
            self,
            save_path: Optional[str] = None,
            format: WindowCaptureFormat = WindowCaptureFormat.PIL,
            rect: Optional[WindowRect] = None,
            force_activate: bool = True
    ) -> Union[Image.Image, np.ndarray, None]:
        """对窗口进行截图，支持指定区域和多种输出格式。

        使用 PrintWindow API 截取窗口客户端区域（不含标题栏、边框和阴影），
        支持 DPI 感知，解决常见的黑屏和尺寸不对问题。

        Args:
            save_path: 图片保存路径，为 None 则不保存到文件
            format: 输出格式，支持 PIL、NUMPY（RGB）、OPENCV（BGR）
            rect: 指定截取的区域（WindowRect），为 None 则截取整个窗口
            force_activate: 是否先激活窗口再截图，默认为 True

        Returns:
            截图结果，格式由 format 参数决定；失败返回 None
        """
        prev_hwnd = None
        if force_activate:
            prev_hwnd = windll.user32.GetForegroundWindow()
            self.activate()
            # time.sleep(0.15)  # 给渲染一点缓冲   ← 保持原样，未动

        try:
            # ──────────────── 关键修改：使用客户端矩形 ────────────────
            client_rect = win32gui.GetClientRect(self.hwnd)  # 返回 (left, top, right, bottom) 相对坐标
            client_width = client_rect[2] - client_rect[0]
            client_height = client_rect[3] - client_rect[1]

            if client_width <= 0 or client_height <= 0:
                return None

            # 获取客户端区域在屏幕上的实际位置（用于和 rect 对齐）
            client_top_left = win32gui.ClientToScreen(self.hwnd, (client_rect[0], client_rect[1]))
            f_left, f_top = client_top_left
            f_right = f_left + client_width
            f_bot = f_top + client_height

            # 2. 确定实际要截取的区域（用户指定 or 整窗）
            target = rect if rect else self.rect

            # 计算偏移：现在基于客户端区域左上角
            offset_x = target.left - f_left
            offset_y = target.top - f_top
            w, h = target.width, target.height

            if w <= 0 or h <= 0:
                return None

            # 3. PrintWindow 核心截图流程（完全不变）
            hwndDC = win32gui.GetWindowDC(self.hwnd)
            mfcDC = win32ui.CreateDCFromHandle(hwndDC)
            saveDC = mfcDC.CreateCompatibleDC()
            saveBitMap = win32ui.CreateBitmap()

            # ★ 关键：bitmap 大小改为客户端区域大小（不包含阴影/边框）
            saveBitMap.CreateCompatibleBitmap(mfcDC, client_width, client_height)
            saveDC.SelectObject(saveBitMap)

            # PW_RENDERFULLCONTENT = 3 （保持不变）
            windll.user32.PrintWindow(self.hwnd, saveDC.GetSafeHdc(), 3)

            bmpinfo = saveBitMap.GetInfo()
            bmpstr = saveBitMap.GetBitmapBits(True)

            # 4. 转成 PIL.Image 并裁剪（坐标系已对齐到客户端）
            img = Image.frombuffer(
                'RGB',
                (bmpinfo['bmWidth'], bmpinfo['bmHeight']),
                bmpstr,
                'raw',
                'BGRX',
                0,
                1
            )
            img = img.crop((offset_x, offset_y, offset_x + w, offset_y + h))

            # 5. 格式转换（不变）
            result = format.convert(img)

            # 6. 保存（不变）
            if save_path:
                if format is WindowCaptureFormat.OPENCV:
                    cv2.imwrite(save_path, result)
                elif format is WindowCaptureFormat.PIL:
                    img.save(save_path)
                else:  # NUMPY
                    Image.fromarray(result).save(save_path)

            return result

        except Exception as e:
            print(f"窗口截图失败: {e}")
            return None

        finally:
            # 清理资源（不变）
            try:
                win32gui.DeleteObject(saveBitMap.GetHandle())
                saveDC.DeleteDC()
                mfcDC.DeleteDC()
                win32gui.ReleaseDC(self.hwnd, hwndDC)
            except:
                pass

            # 恢复前台窗口（不变）
            if force_activate and prev_hwnd and prev_hwnd != self.hwnd:
                try:
                    windll.user32.SetForegroundWindow(prev_hwnd)
                except:
                    pass

    # --- 交互操作方法 ---

    def _get_lparam(self, x: int, y: int, is_relative: bool):
        """将坐标转换为 Windows 消息的 lParam 参数。

        根据 is_relative 标志决定是否需要将屏幕绝对坐标转换为窗口相对坐标，
        然后按 MAKELONG 格式打包为 lParam。

        Args:
            x: X 坐标
            y: Y 坐标
            is_relative: True 表示已是窗口相对坐标，False 表示是屏幕绝对坐标

        Returns:
            编码后的 lParam 整数值（高16位为Y，低16位为X）
        """
        if not is_relative:
            r = self.rect
            x, y = x - r.left, y - r.top
        # MAKELONG 的逻辑：高16位是Y，低16位是X
        return (y << 16) | (x & 0xFFFF)

    import uiautomation as auto
    import win32gui

    def click(self,x: Optional[int] = None,
              y: Optional[int] = None,
              clicks: int = 1,
              interval: float = 0.1,
              button: str = "primary",
              move_duration: float = 0.0,
              duration: float = 0.0,
              offset: int = 0):
        """在窗口内指定的相对坐标位置执行鼠标点击。

        将窗口相对坐标转换为屏幕绝对坐标后，通过 Mouse 模块执行真实鼠标点击。

        Args:
            x: 相对于窗口左上角的 X 坐标（像素）
            y: 相对于窗口左上角的 Y 坐标（像素）
            clicks: 点击次数，默认 1 次
            interval: 多次点击之间的间隔（秒），默认 0.1
            button: 鼠标按键，"primary" 为左键，"secondary" 为右键
            move_duration: 鼠标移动到目标位置的耗时（秒），0 为瞬移
            duration: 按下与释放之间的持续时间（秒），0 为普通点击
            offset: 坐标随机偏移量（像素），用于模拟人工点击
        """
        x = self.rect.left + x
        y = self.rect.top + y
        Mouse.click(x, y,clicks=clicks,interval=interval,button=button,move_duration=move_duration,duration=duration,offset=offset)

    def long_click(self, x: int, y: int, duration: float = 1.0, is_relative: bool = True):
        """在指定坐标执行长按操作。

        通过 PostMessage 发送鼠标按下消息，等待指定时长后再发送释放消息。

        Args:
            x: X 坐标
            y: Y 坐标
            duration: 按住时长（秒），默认 1.0
            is_relative: True 表示相对窗口坐标，False 表示屏幕绝对坐标
        """
        lparam = self._get_lparam(x, y, is_relative)
        win32gui.PostMessage(self.hwnd, win32con.WM_LBUTTONDOWN, win32con.MK_LBUTTON, lparam)
        time.sleep(duration)
        win32gui.PostMessage(self.hwnd, win32con.WM_LBUTTONUP, 0, lparam)

    def drag(self, x1: int, y1: int, x2: int, y2: int, duration: float = 0.5, is_relative: bool = True):
        """从起点坐标拖拽到终点坐标。

        通过 PostMessage 模拟鼠标拖拽过程：按下 -> 分步平滑移动 -> 释放。

        Args:
            x1: 起点 X 坐标
            y1: 起点 Y 坐标
            x2: 终点 X 坐标
            y2: 终点 Y 坐标
            duration: 拖拽总耗时（秒），默认 0.5
            is_relative: True 表示相对窗口坐标，False 表示屏幕绝对坐标
        """
        p1 = self._get_lparam(x1, y1, is_relative)
        p2 = self._get_lparam(x2, y2, is_relative)

        # 1. 按下
        win32gui.PostMessage(self.hwnd, win32con.WM_LBUTTONDOWN, win32con.MK_LBUTTON, p1)

        # 2. 模拟滑动过程 (平滑移动)
        steps = 10
        for i in range(steps + 1):
            curr_x = int(x1 + (x2 - x1) * (i / steps))
            curr_y = int(y1 + (y2 - y1) * (i / steps))
            curr_p = self._get_lparam(curr_x, curr_y, is_relative)
            win32gui.PostMessage(self.hwnd, win32con.WM_MOUSEMOVE, win32con.MK_LBUTTON, curr_p)
            time.sleep(duration / steps)

        # 3. 抬起
        win32gui.PostMessage(self.hwnd, win32con.WM_LBUTTONUP, 0, p2)

    def type_text(self, text: str):
        """向窗口逐字符发送文本输入消息。

        通过 WM_CHAR 消息逐字发送，无需激活窗口即可输入。

        Args:
            text: 要输入的文本字符串
        """
        for char in text:
            # WM_CHAR 消息直接发送字符编码
            win32gui.PostMessage(self.hwnd, win32con.WM_CHAR, ord(char), 0)
            time.sleep(0.01)


