import os
import sys
import threading
import base64
import ctypes
import time
import multiprocessing
from typing import Optional, Callable, Dict
from PIL import Image
import pystray
from .web_window import WebWindow
from ..system import R


class QueueWriter:
    """队列写入器，将标准输出重定向到多进程队列。

    用于子进程中捕获 print 输出，通过队列传递给主进程进行显示。
    """

    def __init__(self, queue):
        """初始化队列写入器。

        Args:
            queue: multiprocessing.Queue 实例，用于接收输出消息。
        """
        self.queue = queue

    def write(self, message):
        """将非空消息写入队列。

        Args:
            message: 要写入的消息字符串。
        """
        if message.strip():
            self.queue.put(message)

    def flush(self):
        """刷新操作（无实际操作，仅为兼容标准输出接口）。"""
        pass


class FloatScriptWindow(WebWindow):
    """浮动脚本控制窗口。

    提供一个无边框置顶的迷你控制面板，支持脚本的启动/停止、
    日志实时输出、系统托盘集成，以及通过多进程隔离运行用户脚本。
    继承自 WebWindow。
    """

    def __init__(self, icon_path: str, title: str = "AScript", use_process: bool = True, auto_start: bool = False):
        """初始化浮动脚本控制窗口。

        Args:
            icon_path: 图标文件路径，用于窗口显示和系统托盘图标。
            title: 窗口标题，默认为 "AScript"。
            use_process: 是否使用独立进程运行脚本，默认为 True。
            auto_start: 是否在窗口就绪后自动启动脚本，默认为 False。
        """
        self.icon_path = os.path.abspath(icon_path)
        self.ui_title = title
        self._is_hidden = False
        self._callback = None

        self.use_process = use_process
        self.auto_start = auto_start
        self.active_worker = None
        self.events = {}
        self._is_ready = False
        self._is_switching = False

        self.stop_event = multiprocessing.Event()
        self.msg_queue = multiprocessing.Queue()

        # _root = paths.get_path("ascript/windows/tools/web/")
        # _filepath = paths.get_path("ascript/windows/tools/web/flot_control.html")

        _root = R.internal("windows", "tools", "web")  # paths.get_path("ascript/windows/tools/web/")
        _filepath = R.internal("windows", "tools", "web",
                               "flot_control.html")  # paths.get_path("ascript/windows/tools/web/license_window.html")
        super().__init__(_filepath, project_root=_root)

        self.expose(self.get_init_data)
        self.expose(self.on_toggle_click)
        self.expose(self.drag_window)
        self.expose(self.hide_window)
        self.expose(self.resize_ui)

        self._setup_logging()
        threading.Thread(target=self._queue_listener, daemon=True).start()

    def on(self, event_name: str):
        """注册事件监听的装饰器。

        支持的事件名: "start"（脚本启动）、"stop"（脚本停止）。

        Args:
            event_name: 事件名称。

        Returns:
            Callable: 装饰器函数。
        """
        def wrapper(func: Callable):
            self.events[event_name] = func
            return func

        return wrapper

    def _setup_logging(self):
        """设置日志重定向。

        将 sys.stdout 替换为当前实例，使 print 输出同时写入控制台和 WebView 界面。
        """
        self._original_stdout = sys.stdout
        sys.stdout = self

    def _queue_listener(self):
        """队列消息监听线程。

        持续从子进程消息队列中读取日志并打印到主进程标准输出（触发 WebView 显示）。
        """
        while True:
            try:
                msg = self.msg_queue.get()
                print(msg)
            except:
                pass

    def write(self, message):
        """写入消息到控制台和 WebView 界面。

        同时将消息输出到原始标准输出和 WebView 的日志面板。

        Args:
            message: 要写入的消息字符串。
        """
        # 1. 尝试写回原始控制台，增加出错捕获
        try:
            self._original_stdout.write(message)
        except:
            # 出错时不进行任何处理，直接跳过，防止程序崩溃
            pass

        # 2. 推送到 WebView UI
        if self._is_ready and message.strip() and self.webview_instance:
            try:
                # 保持你原始的字符替换逻辑
                safe_msg = message.replace("\\", "\\\\").replace("'", "\\'").replace('"', '\\"').replace("\n",
                                                                                                         "").replace(
                    "\r", "")
                self.webview_instance.evaluate_js(f"if(window.addLog){{window.addLog('{safe_msg}');}}")
            except:
                pass

    def flush(self):
        """刷新原始标准输出缓冲区。"""
        try:
            self._original_stdout.flush()
        except:
            pass

    @staticmethod
    def _worker_wrapper(start_func, stop_func, queue, stop_event):
        """子进程中的工作函数包装器。

        在独立进程中运行用户脚本，重定向输出到队列，并监听停止信号。

        Args:
            start_func: 用户注册的启动函数。
            stop_func: 用户注册的停止函数（可选，可为 None）。
            queue: multiprocessing.Queue，用于传递日志消息。
            stop_event: multiprocessing.Event，用于接收停止信号。
        """
        sys.stdout = QueueWriter(queue)
        sys.stderr = QueueWriter(queue)

        worker_thread = threading.Thread(target=start_func, daemon=True)
        worker_thread.start()

        def safe_cleanup():
            if stop_func:
                t = threading.Thread(target=stop_func, daemon=True)
                t.start()
                t.join(timeout=2.5)
                if t.is_alive():
                    pass

        while True:
            if stop_event.is_set():
                safe_cleanup()
                break

            if not worker_thread.is_alive():
                safe_cleanup()
                break

            time.sleep(0.1)

    def _monitor_worker(self, worker):
        """监控工作进程状态。

        等待工作进程结束后，更新 UI 状态为已停止。

        Args:
            worker: 要监控的 multiprocessing.Process 实例。
        """
        worker.join()
        if self.active_worker == worker:
            self.active_worker = None
            self.stop_event.clear()
            if self.webview_instance:
                self.webview_instance.evaluate_js("if(window.syncStatus){window.syncStatus(false);}")

    def on_toggle_click(self, status):
        """处理前端播放/停止按钮点击事件。

        根据状态启动或停止工作进程，防止重复操作。

        Args:
            status: True 表示启动，False 表示停止。

        Returns:
            dict: 操作结果，如 {"status": "success"} 或 {"status": "error", "msg": "BUSY"}。
        """
        if self._is_switching:
            return {"status": "error", "msg": "BUSY"}
        self._is_switching = True
        try:
            if status:
                if 'start' in self.events:
                    start_func = self.events['start']
                    stop_func = self.events.get('stop')
                    if self.use_process:
                        if self.active_worker and self.active_worker.is_alive():
                            self._force_stop_worker()
                        self.stop_event.clear()
                        self.active_worker = multiprocessing.Process(
                            target=self._worker_wrapper,
                            args=(start_func, stop_func, self.msg_queue, self.stop_event),
                            daemon=True
                        )
                        self.active_worker.start()
                        threading.Thread(target=self._monitor_worker, args=(self.active_worker,), daemon=True).start()
            else:
                self._force_stop_worker()
            return {"status": "success"}
        finally:
            self._is_switching = False

    def _force_stop_worker(self):
        """强制停止工作进程。

        依次尝试: 发送停止事件 -> 等待退出 -> terminate -> kill，确保进程被终止。
        """
        if self.active_worker:
            worker_to_stop = self.active_worker
            self.active_worker = None
            if self.use_process:
                if worker_to_stop.is_alive():
                    self.stop_event.set()
                    worker_to_stop.join(timeout=3.0)

                    if worker_to_stop.is_alive():
                        worker_to_stop.terminate()
                        worker_to_stop.join(timeout=1.0)
                        if worker_to_stop.is_alive():
                            worker_to_stop.kill()
                            worker_to_stop.join()
            self.stop_event.clear()

    def drag_window(self):
        """启动窗口拖拽操作，供前端鼠标拖拽事件调用。"""
        if self.webview_instance:
            try:
                self.webview_instance.start_drag()
            except:
                try:
                    self.webview_instance.move_window()
                except:
                    pass

    def hide_window(self):
        """隐藏或显示窗口，供前端隐藏按钮调用。"""
        self.toggle_visible()

    def resize_ui(self, expand):
        """调整窗口大小。

        Args:
            expand: True 展开为大窗口 (300x450)，False 收缩为小窗口 (240x76)。
        """
        if self.webview_instance:
            self.webview_instance.resize(300 if expand else 240, 450 if expand else 76)

    def get_init_data(self):
        """获取窗口初始化数据。

        标记窗口为就绪状态，并返回标题和图标的 Base64 数据。

        Returns:
            dict: 包含 title（窗口标题）和 icon_b64（图标 Base64 编码）的字典。
        """
        self._is_ready = True
        try:
            if not os.path.exists(self.icon_path):
                return {"title": self.ui_title, "icon_b64": ""}
            with open(self.icon_path, "rb") as f:
                b64 = base64.b64encode(f.read()).decode('utf-8')
            return {"title": self.ui_title, "icon_b64": b64}
        except:
            return {"title": self.ui_title, "icon_b64": ""}

    def _fix_window_once(self):
        """通过 Win32 API 修复窗口样式。

        移除标题栏、边框和系统菜单，设置为工具窗口样式以隐藏任务栏图标。
        """
        GWL_STYLE, GWL_EXSTYLE = -16, -20
        WS_CAPTION, WS_THICKFRAME, WS_SYSMENU = 0x00C00000, 0x00040000, 0x00080000
        WS_EX_TOOLWINDOW, WS_EX_APPWINDOW = 0x00000080, 0x00040000
        hwnd = ctypes.windll.user32.FindWindowW(None, 'AScriptControlPanel')
        if hwnd:
            style = ctypes.windll.user32.GetWindowLongW(hwnd, GWL_STYLE)
            ctypes.windll.user32.SetWindowLongW(hwnd, GWL_STYLE, style & ~WS_CAPTION & ~WS_THICKFRAME & ~WS_SYSMENU)
            ex_style = ctypes.windll.user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
            ctypes.windll.user32.SetWindowLongW(hwnd, GWL_EXSTYLE, (ex_style | WS_EX_TOOLWINDOW) & ~WS_EX_APPWINDOW)
            ctypes.windll.user32.SetWindowPos(hwnd, 0, 0, 0, 0, 0, 0x0020 | 0x0002 | 0x0001 | 0x0004)

    def toggle_visible(self, icon=None, item=None):
        """切换窗口的显示/隐藏状态。

        Args:
            icon: 系统托盘图标对象（由 pystray 回调传入，可选）。
            item: 菜单项对象（由 pystray 回调传入，可选）。
        """
        if self.webview_instance:
            if self._is_hidden:
                self.webview_instance.show()
                self._is_hidden = False
            else:
                self.webview_instance.hide()
                self._is_hidden = True

    def _setup_tray(self):
        """初始化并启动系统托盘图标。

        创建包含"显示/隐藏"和"彻底退出"菜单项的系统托盘图标。
        """
        try:
            img = Image.open(self.icon_path)
            menu = pystray.Menu(pystray.MenuItem("显示/隐藏", self.toggle_visible, default=True),
                                pystray.MenuItem("彻底退出", lambda: os._exit(0)))
            tray = pystray.Icon("AScriptTray", img, self.ui_title, menu)
            tray.run()
        except:
            pass

    def _auto_start_logic(self):
        """自动启动逻辑。

        等待 WebView 就绪后，自动触发脚本启动，用于 auto_start=True 的场景。
        """
        while not self._is_ready:
            time.sleep(0.1)
        if self.webview_instance:
            self.webview_instance.evaluate_js("if(window.syncStatus){window.syncStatus(true);}")
        self.on_toggle_click(True)

    def show(self, title: str = "AScriptControlPanel", debug=False, width: int = 240, height: int = 76, **kwargs):
        """显示浮动控制窗口并进入事件循环。

        启动系统托盘、窗口样式修复和可选的自动启动逻辑，然后调用父类 show 方法。
        仅在主进程中有效，子进程调用会直接返回。

        Args:
            title: 窗口标题，默认为 "AScriptControlPanel"。
            debug: 是否启用 WebView 调试模式，默认为 False。
            width: 窗口宽度（像素），默认为 240。
            height: 窗口高度（像素），默认为 76。
            **kwargs: 传递给 WebWindow.show 的额外参数。
        """
        if multiprocessing.current_process().name != 'MainProcess':
            return
        threading.Thread(target=self._setup_tray, daemon=True).start()
        threading.Timer(1.5, self._fix_window_once).start()
        if self.auto_start:
            threading.Thread(target=self._auto_start_logic, daemon=True).start()
        kwargs.update({'frameless': True, 'on_top': True, 'resizable': False, 'background_color': '#1a1a1a'})
        super().show(title=title, debug=debug, width=width, height=height, **kwargs)