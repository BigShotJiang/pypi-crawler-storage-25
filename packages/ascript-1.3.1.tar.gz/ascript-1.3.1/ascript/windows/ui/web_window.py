import threading
from pathlib import Path

import webview
import os
from typing import Optional, Callable, Dict

class WebWindow:
    """基于 pywebview 的 Web 窗口基类。

    封装了 HTML 页面加载、Python-JavaScript 双向通信桥接、窗口生命周期管理等功能。
    子类可通过 expose 方法向前端暴露 Python 函数。
    """

    def __init__(self, html_path: str, project_root: Optional[str] = None):
        """初始化 Web 窗口。

        Args:
            html_path: HTML 页面文件路径。
            project_root: 项目根目录路径，用于资源定位。默认为当前工作目录。
        """
        self.project_root = os.path.abspath(project_root) if project_root else os.getcwd()
        self.abs_path = os.path.abspath(html_path)
        self._exposed_functions: Dict[str, Callable] = {}
        self.webview_instance = None
        self._return_value = None  # 新增：用于存储返回结果

    def expose(self, func: Callable):
        """将 Python 函数暴露给前端 JavaScript 调用。

        暴露后，前端可通过 callPython('函数名', ...参数) 调用该函数。

        Args:
            func: 要暴露的 Python 函数。

        Returns:
            Callable: 传入的函数本身（可用作装饰器）。
        """
        self._exposed_functions[func.__name__] = func
        return func

    def show(self, title: str = "AScript Window", debug=False, block: bool = True, **kwargs):
        """创建并显示 Web 窗口。

        加载 HTML 页面，注入 callPython 桥接函数，启动 WebView 事件循环。

        Args:
            title: 窗口标题，默认为 "AScript Window"。
            debug: 是否启用 WebView 调试模式，默认为 False。
            block: 是否阻塞当前线程，默认为 True。设为 False 时在后台线程运行。
            **kwargs: 传递给 webview.create_window 的额外参数（如 width、height、frameless 等）。

        Returns:
            阻塞模式下返回 _return_value（由子类设置）；非阻塞模式无返回值。
        """
        class ApiBridge:
            """JavaScript 与 Python 之间的 API 桥接内部类。"""

            def __init__(self, funcs):
                """初始化 API 桥接。

                Args:
                    funcs: 已暴露的函数字典，键为函数名，值为可调用对象。
                """
                self._funcs = funcs

            def call_internal(self, func_name, args):
                """调用已注册的 Python 函数。

                Args:
                    func_name: 要调用的函数名称。
                    args: 传递给函数的参数列表。

                Returns:
                    函数的返回值；函数不存在或执行出错时返回 None。
                """
                f = self._funcs.get(func_name)
                # 包装一下执行，防止 Python 报错导致 JS 卡死
                try:
                    return f(*args) if f else None
                except Exception as e:
                    print(f"Error calling {func_name}: {e}")
                    return None

        file_url = Path(self.abs_path).as_uri()

        self.webview_instance = webview.create_window(
            title=title,
            url=file_url,
            js_api=ApiBridge(self._exposed_functions),
            **kwargs
        )

        # 动态注入 callPython 桥接，HTML 文件无需修改
        def on_loaded():
            injection_code = """
            window.callPython = async function(fnName, ...args) {
                return await window.pywebview.api.call_internal(fnName, args);
            };
            window.dispatchEvent(new CustomEvent('onPythonReady'));
            """
            self.webview_instance.evaluate_js(injection_code)

        if block:
            webview.start(on_loaded, debug=debug)
            return self._return_value
        else:
            def _run():
                webview.start(on_loaded, debug=debug)

            t = threading.Thread(target=_run, daemon=True)
            t.start()

    def close(self):
        """关闭并销毁 Web 窗口。"""
        if self.webview_instance:
            self.webview_instance.destroy()