
from .web_window import  WebWindow
from .. import  license
from ..system import KeyValue,R


class LicenseWindow(WebWindow):
    """授权验证窗口类。

    提供应用授权验证的 Web 窗口界面，支持查询应用信息、激活码验证和启动授权检查。
    继承自 WebWindow，窗口关闭后返回验证结果（True/False）。
    """

    def __init__(self, app_id: str):
        """初始化授权验证窗口。

        Args:
            app_id: 需要验证授权的应用唯一标识符。
        """
        self.app_id = app_id
        self.license_data = None
        self.app_info = None
        # 默认返回 False，确保任何非正常退出都视为失败
        self._return_value = False

        _root =  R.internal("windows","tools","web") #paths.get_path("ascript/windows/tools/web/")
        _filepath = R.internal("windows","tools","web","license_window.html") #paths.get_path("ascript/windows/tools/web/license_window.html")
        print(_filepath)
        super().__init__(_filepath, project_root=_root)

        self.expose(self.get_app_info)
        self.expose(self.get_cached_key)
        self.expose(self.activate_key)
        self.expose(self.start_app)

    def get_app_info(self):
        """获取当前应用的详细信息。

        Returns:
            dict: 应用信息字典；未找到时返回 {'name': '没有找到该程序'}。
        """
        res = license.achttp.get_apps(self.app_id)
        if res and len(res) > 0:
            self.app_info = res[0]
            return self.app_info
        return {'name': '没有找到该程序'}

    def activate_key(self, key: str):
        """使用激活码进行授权验证。

        验证成功后将激活码缓存到本地，失败则清空授权数据。

        Args:
            key: 用户输入的激活码字符串。

        Returns:
            dict: 服务端返回的验证结果，成功时 code 为 1 并包含 data 字段。
        """
        # 这里的 res 结构需包含 {code: 1, data: {status: 1...}}
        res = license.achttp.get_card(self.app_id, key)
        if res and res.get('code') == 1:
            self.license_data = res.get('data')
            KeyValue.save("license_cache_no", key)
        else:
            self.license_data = None  # 验证失败必须清空旧数据
        return res

    def start_app(self):
        """执行最终的授权校验并决定是否允许启动。

        依次检查应用信息加载状态、免费版直接放行、授权版验证 license 状态。
        验证通过后关闭窗口并设置返回值为 True。

        Returns:
            bool|dict: 验证通过返回 True；失败返回包含 error 信息的字典。
        """
        # print("Final security check before launch...")

        # 1. 验证 app_info
        if not self.app_info:
            print("Error: App info not loaded.")
            return {"error": "初始化未完成"}

        # 2. 免费版直接放行
        if self.app_info.get('is_free') == 1:
            # print("Mode: Free version. Access granted.")
            self._return_value = True
            self.close()
            return True

        # 3. 授权版严格校验
        # 核心：必须 status 存在且明确等于 1
        if self.license_data and self.license_data.get('status') == 1:
            # print("Mode: Professional. License verified.")
            self._return_value = True
            self.close()
            return True
        else:
            # 如果 status 是 2 (过期) 或其他，拦截并告知前端
            current_status = self.license_data.get('status') if self.license_data else "None"
            print(f"Access Denied: License status is {current_status}")
            self._return_value = False
            return {"error": "授权已过期或无效，请重新激活"}

    def get_cached_key(self):
        """获取本地缓存的激活码。

        Returns:
            str: 缓存的激活码字符串，若无缓存则返回空字符串。
        """
        return KeyValue.get("license_cache_no", "")