"""ascript.windows 模块 - Windows 平台自动化核心包。

负责初始化 Windows 平台相关的路径配置和 RapidOCR Hook 注入。
"""
import os
import sys

# 获取当前 windows 目录的路径
_current_dir = os.path.dirname(os.path.abspath(__file__))

# 关键：将 windows 目录加入搜索路径
# 这样其下的子模块 license 就能直接 import 旁边的 pyarmor_runtime_000000
if _current_dir not in sys.path:
    sys.path.insert(0, _current_dir)


try:
    from ascript.windows.screen.ocr import rapidocr_hook
    import rapidocr

    # 检查是否已经挂钩
    if not hasattr(rapidocr, 'find'):
        rapidocr_hook.install()
        # print("RapidOCR Hook 注入成功")
except Exception as e:
    # 捕获所有异常，确保主程序继续运行
    # 你可以选择静默失败，或者只在日志里记录一下
    # print(f"RapidOCR Hook 注入失败（非致命）: {e}")
    pass