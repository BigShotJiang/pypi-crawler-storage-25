import importlib
import json
import os
import sys
from abc import ABC, abstractmethod
from typing import Any
from PIL import Image

from ascript.ios.developer.api import utils
from ascript.ios.developer.api.dao import ImgInout

str_stack_name = "strack"


class Point:
    """坐标点，表示屏幕上的一个 (x, y) 位置。"""

    def __init__(self, x: int, y: int):
        """初始化坐标点。

        Args:
            x: 坐标点的 x 位置。
            y: 坐标点的 y 位置。
        """
        self.x = x
        self.y = y

    def __repr__(self):
        """返回坐标点的 JSON 字符串表示。

        Returns:
            str: 包含 x、y 的 JSON 字符串。
        """
        return json.dumps({
            "x": self.x,
            "y": self.y
        })


class GpInOut:
    """图色处理的输入输出容器，封装图像数据、区域、偏移量和处理结果。"""

    def __init__(self, image: Image.Image = None, offset_x: int = 0, offset_y: int = 0, data: Any = None,
                 image_file: str = None, rect=None, skip_cache: bool = False):
        """初始化图色处理输入输出对象。

        Args:
            image: 可选，PIL Image 对象。
            offset_x: x 轴坐标偏移量，默认 0。
            offset_y: y 轴坐标偏移量，默认 0。
            data: 可选，处理结果数据。
            image_file: 可选，图片文件路径或 URL。如果 image 和 image_file 均为 None，默认使用 WDA 截图 URL。
            rect: 可选，处理区域。
            skip_cache: 是否跳过缓存，默认 False。
        """
        self.image = image
        self.image_file = image_file
        self.offset_x = offset_x
        self.offset_y = offset_y
        self.data = data
        self.rect = rect
        self.skip_cache = skip_cache

        if image is None and image_file is None:
            self.image_file = "http://127.0.0.1:8100/screenshot"

    def img_inout(self) -> ImgInout:
        """将当前对象转换为 ImgInout 数据传输对象，支持缓存逻辑。

        Returns:
            ImgInout: 用于底层图像处理的输入输出对象。
        """
        # 缓存逻辑
        if not self.skip_cache and utils.is_cache:
            # print('使用缓存',utils.is_cache)
            return ImgInout(rect=self.rect)

        # print('使用图片',self.skip_cache,utils.is_cache)

        return ImgInout(image=self.image, image_file=self.image_file, rect=self.rect)

    def __repr__(self):
        """返回输入输出对象的 JSON 字符串表示。

        Returns:
            str: 包含 data 字段的 JSON 字符串。
        """
        return json.dumps({
            "data": self.data
        }, cls=PointEncoder)


class GP(ABC):
    """图色处理工具的抽象基类，所有图色工具（找色、找图、OCR 等）均需继承此类。"""

    name = ""
    ui_path = ""

    @abstractmethod
    def run(self, gp_inout: GpInOut) -> GpInOut:
        """执行图色处理任务（抽象方法，子类必须实现）。

        Args:
            gp_inout: 图色处理的输入输出对象。

        Returns:
            GpInOut: 包含处理结果的输入输出对象。
        """
        pass


def gptask_params(data):
    """从任务数据中提取参数字符串。

    Args:
        data: 任务数据字典。

    Returns:
        str: 参数字符串；如果不存在 params 字段则返回空字符串。
    """
    if "params" in data:
        return data["params"]
    else:
        return ""


def load_or_reload_module(module_name_str):
    """加载或重新加载指定名称的 Python 模块。

    如果模块已加载则重新加载，否则进行首次导入。

    Args:
        module_name_str: 模块的完整名称字符串（如 "ascript.ios.screen"）。

    Returns:
        module: 加载后的模块对象。
    """
    try:
        # 尝试从sys.modules中获取模块对象
        module = sys.modules[module_name_str]
        # 如果模块已经存在，则重新加载它
        # print(f"Module {module_name_str} already loaded. Reloading...")
        module = importlib.reload(module)
    except KeyError:
        # 如果模块不存在，则导入它
        # print(f"Module {module_name_str} not loaded. Importing...")
        module = importlib.import_module(module_name_str)
    return module


def create_gpcode_with_dict(gp):
    """根据图色任务字典生成对应的 Python 代码片段，追加到全局代码构建列表中。

    Args:
        gp: 图色任务字典，需包含 id（模块类路径）和 type（任务类型）字段，可选 data 字段。
    """
    jobid = gp["id"]
    jobtype = gp["type"]
    # jobnv = gp["nv"]
    jobdata = None
    if "data" in gp:
        jobdata = gp["data"]
    module_name, class_name = jobid.rsplit('.', 1)
    module = importlib.import_module(module_name)
    gp_class = getattr(module, class_name)
    if gp_class:
        # 存在这个类
        global str_header, str_body
        # if "云端" in jobtype:
        #     str_header.append(f"plugs.load('{jobnv}')")
        str_header.append(f"from {module_name} import {class_name}")
        str_body.append(f"  {str_stack_name}.append({class_name}({gptask_params(jobdata)}))")


def loadfrom_json(json_str, c_img, gp_name, gp_dir):
    """从 JSON 字符串加载图色任务流程，生成 Python 脚本文件并执行。

    Args:
        json_str: 包含图色任务列表的 JSON 字符串。
        c_img: 用于处理的图片文件路径。
        gp_name: 任务名称（当前未使用）。
        gp_dir: 生成的 Python 脚本文件保存目录。

    Returns:
        str: 执行结果的 JSON 字符串，包含 image、offset_x、offset_y、data 字段。
    """
    # print(c_img)
    job_data = json.loads(json_str)
    global str_header, str_body
    str_header = []
    str_body = []
    # cv_img = screen.bitmap_to_cvimage(c_img)

    str_header.append("from PIL import Image")
    str_header.append("from ascript.ios.system import R")
    str_header.append("from ascript.ios.screen import GpInOut, capture")

    str_body.append("def gp(image):")
    # str_body.append(f"  cv_img = cv2.imread('{c_img}')")
    str_body.append(f"  strack = []")

    # 组装job
    for gp in job_data:
        create_gpcode_with_dict(gp)

    str_body.append(f"  inout = GpInOut(image_file=image,skip_cache=True)")
    str_body.append(f"  for gp in strack:")
    str_body.append(f"      inout = gp.run(inout)")
    # str_body.append(f"      print(inout)")
    str_body.append(f"  return inout")

    str_body.append(f"# 如需运行,取消以下代码注释")
    str_body.append(f"# res = gp()")
    str_body.append(f"# print(res.data)")

    final_code = '\n'.join(str(item) for item in str_header + str_body)
    # print(final_code)
    #
    # print(gp_dir)

    # 创建 init 文件,并写入数据.
    init_py_file = os.path.join(gp_dir, "__init__.py")
    if not os.path.exists(os.path.dirname(init_py_file)):
        os.makedirs(os.path.dirname(init_py_file))
    with open(init_py_file, 'w', encoding='utf-8') as file:
        file.write(final_code)

    module_name = os.path.basename(gp_dir)
    if module_name in sys.modules:
        module = importlib.reload(sys.modules[module_name])
    else:
        module = importlib.import_module(module_name)
    # gp_result = module.gp(Image.open(c_img))
    gp_result = module.gp(c_img)

    # 这是直接执行
    # exec(final_code, globals())
    # pil_img = Image.open(c_img)
    # gp_result = gprun(pil_img)

    """
    # img_path = f"sdcard/airscript/screen/gp/{uuid.uuid4()}.jpg"
    img_path = os.path.join(gp_dir, "temp.png")
    # 提取目录部分
    directory = os.path.dirname(img_path)

    # 检查目录是否存在
    if not os.path.exists(directory):
        # 如果目录不存在，则创建它
        os.makedirs(directory)

    gp_result.image.save(img_path)
    # cv2.(img_path, gp_result.image)
    # print(gp_result)
    """

    img_path = gp_result.image_file

    res = {"image": img_path, "offset_x": gp_result.offset_x, "offset_y": gp_result.offset_y, "data": gp_result.data}
    return json.dumps(res, cls=PointEncoder)


class PointEncoder(json.JSONEncoder):
    """自定义 JSON 编码器，支持将 Point 对象序列化为 JSON。"""

    def default(self, obj):
        """将 Point 对象转换为可 JSON 序列化的字典。

        Args:
            obj: 要序列化的对象。

        Returns:
            dict: 如果是 Point 对象，返回包含 x、y 的字典；否则调用父类默认处理。
        """
        if isinstance(obj, Point):
            return {'x': obj.x, 'y': obj.y}
        # 让基本类处理不支持的类型
        return json.JSONEncoder.default(self, obj)
