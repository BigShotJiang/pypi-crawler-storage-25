import json
import time
import numpy as np
from PIL import Image
from ascript.ios.screen.gp import Point


class ColorPoint:
    """颜色坐标点，表示一个带有颜色信息和容差的坐标位置。"""

    def __init__(self, x, y, rgb=None, diff=None):
        """初始化颜色坐标点。

        Args:
            x: 坐标点的 x 位置。
            y: 坐标点的 y 位置。
            rgb: 可选，RGB 颜色值列表 [R, G, B]。
            diff: 可选，颜色容差列表 [R, G, B]。
        """
        self.x = x
        self.y = y
        self.rgb = rgb
        self.diff = diff

    def __repr__(self):
        """返回颜色坐标点的 JSON 字符串表示。

        Returns:
            str: 包含 x、y、rgb 的 JSON 字符串。
        """
        return json.dumps({
            "x": self.x,
            "y": self.y,
            "rgb": self.rgb,
        })

    def __sub__(self, other):
        """计算两个颜色坐标点的坐标差值，用于获取相对偏移。

        Args:
            other: 另一个 ColorPoint 对象，作为参考原点。

        Returns:
            ColorPoint: 修改后的自身对象，坐标已变为相对偏移量。
        """
        self.x = self.x - other.x
        self.y = self.y - other.y
        return self


def hex_to_rgb(hex_color):
    """将十六进制颜色字符串转换为 RGB 整数列表。

    Args:
        hex_color: 十六进制颜色字符串，如 "#FF0000" 或 "FF0000"。

    Returns:
        list: RGB 颜色值列表 [R, G, B]。

    Raises:
        ValueError: 当十六进制颜色格式无效（长度不为 6）时抛出。
    """
    hex_color = hex_color.lstrip('#')
    length = len(hex_color)
    if length != 6:
        raise ValueError("Invalid hex color code '{}'".format(hex_color))
    r = int(hex_color[:2], 16)
    g = int(hex_color[2:4], 16)
    b = int(hex_color[4:], 16)
    return [r, g, b]


def ana_colors_r(colors_str: str):
    """解析颜色规则字符串为 ColorPoint 列表（相对坐标模式）。

    第一个颜色点保持绝对坐标，后续颜色点的坐标转换为相对于第一个点的偏移量。

    Args:
        colors_str: 颜色规则字符串，格式为 "x,y,颜色hex[-容差hex]|x,y,颜色hex[-容差hex]|..."。

    Returns:
        list: ColorPoint 对象列表，第一个为绝对坐标，其余为相对偏移。
    """
    # 拆分颜色
    colors = []
    index = 0
    for color_str in colors_str.split('|'):
        # 将 RGB 颜色值转换为整数数组
        c_s = color_str.split(',')

        color = c_s[2]
        diff = None
        if '-' in color:
            color, diff = color.split('-')
            if diff:
                diff = hex_to_rgb(diff)

        if index == 0:
            colors.append(ColorPoint(int(c_s[0]), int(c_s[1]), hex_to_rgb(color), diff))
        else:
            colors.append(ColorPoint(int(c_s[0]), int(c_s[1]), hex_to_rgb(color), diff) - colors[0])

        index = index + 1

    return colors


def ana_colors(colors_str: str):
    """解析颜色规则字符串为 ColorPoint 列表（绝对坐标模式）。

    所有颜色点均保持绝对坐标。

    Args:
        colors_str: 颜色规则字符串，格式为 "x,y,颜色hex[-容差hex]|x,y,颜色hex[-容差hex]|..."。

    Returns:
        list: ColorPoint 对象列表，所有点均为绝对坐标。
    """
    # 拆分颜色
    colors = []
    index = 0
    for color_str in colors_str.split('|'):
        # 将 RGB 颜色值转换为整数数组
        c_s = color_str.split(',')

        color = c_s[2]
        diff = None
        if '-' in color:
            color, diff = color.split('-')
            if diff:
                diff = hex_to_rgb(diff)

        colors.append(ColorPoint(int(c_s[0]), int(c_s[1]), hex_to_rgb(color), diff))

        index = index + 1

    return colors


def ana_single_scolors(colors_str: str):
    """解析仅包含颜色值（不含坐标）的颜色规则字符串为 ColorPoint 列表。

    所有颜色点的坐标均设为 (0, 0)。

    Args:
        colors_str: 颜色规则字符串，格式为 "颜色hex[-容差hex]|颜色hex[-容差hex]|..."。

    Returns:
        list: ColorPoint 对象列表，所有点坐标为 (0, 0)。
    """
    colors = []
    index = 0
    for color_str in colors_str.split('|'):
        # 将 RGB 颜色值转换为整数数组
        color = color_str
        diff = None
        if '-' in color:
            color, diff = color.split('-')
            if diff:
                diff = hex_to_rgb(diff)

        colors.append(ColorPoint(0, 0, hex_to_rgb(color), diff))

        index = index + 1

    return colors


def compare_color(color1, color2, diff):
    """比较两个颜色值是否在容差范围内（numpy 数组版本）。

    Args:
        color1: 第一个颜色值（numpy 数组）。
        color2: 第二个颜色值（列表或数组）。
        diff: 各通道的容差列表。

    Returns:
        bool: 如果各通道差值均在容差范围内则返回 True。
    """
    for i in range(2):
        if abs(color1[i].astype(np.int32) - color2[i]) > diff[i]:
            return False
    return True


def compare_color_n(color1, color2, diff):
    """比较两个颜色值是否在容差范围内（普通数值版本）。

    Args:
        color1: 第一个颜色值（元组或列表）。
        color2: 第二个颜色值（元组或列表）。
        diff: 各通道的容差列表。

    Returns:
        bool: 如果各通道差值均在容差范围内则返回 True。
    """
    for i in range(2):
        if abs(color1[i] - color2[i]) > diff[i]:
            return False
    return True


def check_color(colors, y, x, h, w, diff, image: np.ndarray):
    """检查指定坐标位置的多点颜色是否全部匹配。

    Args:
        colors: ColorPoint 对象列表，第一个为基准点，其余为相对偏移点。
        y: 基准点的 y 坐标。
        x: 基准点的 x 坐标。
        h: 图像高度。
        w: 图像宽度。
        diff: 默认颜色容差列表。
        image: 图像的 numpy 数组。

    Returns:
        bool: 如果所有颜色点均匹配则返回 True，否则返回 False。
    """
    color = colors[0]
    if compare_color(image[y, x], color.rgb, diff if color.diff is None else color.diff):
        for i in range(1, len(colors)):
            color = colors[i]
            ny = color.y + y
            nx = color.x + x
            if nx < 0 or ny < 0 or nx >= w or ny >= h:
                return False
            if not compare_color(image[ny, nx], color.rgb, diff if color.diff is None else color.diff):
                return False
        return True
    return False


def check_space(y, x, space_blocks):
    """检查指定坐标是否在已找到结果的间距排除区域之外。

    Args:
        y: 要检查的 y 坐标。
        x: 要检查的 x 坐标。
        space_blocks: 已排除区域列表，每个元素为 (y_min, y_max, x_min, x_max)。

    Returns:
        bool: 如果坐标不在任何排除区域内则返回 True，否则返回 False。
    """
    for block in space_blocks:
        if block[0] < y < block[1] and block[2] < x < block[3]:
            return False

    return True


def find_colors(colors: str, rect: tuple = None, space: int = 5, ori: int = 2, diff: list = (5, 5, 5), num=-1,
                image: Image.Image = None):
    """在图像中按照指定方向和颜色规则查找所有匹配的坐标点。

    Args:
        colors: 颜色规则字符串，格式为 "x,y,颜色hex|x,y,颜色hex|..."。
        rect: 可选，搜索范围 [left, top, right, bottom]，默认为整个图像。
        space: 相邻结果之间的最小间距，默认 5 像素。
        ori: 搜索方向（1-8），分别对应不同的遍历顺序，默认 2（从上到下、从左到右）。
        diff: 颜色容差 (R, G, B)，默认 (5, 5, 5)。
        num: 最大返回结果数量，-1 表示返回所有匹配结果。
        image: 用于搜索的 PIL Image 对象。

    Returns:
        list: 匹配的 Point 坐标点列表。
    """
    colors = ana_colors_r(colors)

    image = np.array(image)
    rows, cols, _ = image.shape
    if ori == 1:
        pass
    points = []
    points_block = []

    if rect is None:
        rect = [0, 0, cols, rows]
    print("start", time.time())

    # 这里是根据不通的方向遍历图片 ,默认是2

    if ori == 1:
        for x in range(rect[0], rect[2]):
            for y in range(rect[1], rect[3]):
                if check_space(y, x, points_block) and check_color(colors, y, x, rows, cols, diff, image):
                    points.append(Point(x, y))
                    if num != -1 and len(points) >= num:
                        return points
                    points_block.append((y - space, y + space, x - space, x + space))
    elif ori == 2:
        # 双层循环,遍历图像的没一个像素
        for y in range(rect[1], rect[3]):
            for x in range(rect[0], rect[2]):
                # 检测当前 坐标 是否 在已存在点的范围之内. 如果存在放弃. 如果不存在继续
                # 检测 颜色当前点颜色规则是否符合.
                if check_space(y, x, points_block) and check_color(colors, y, x, rows, cols, diff, image):
                    points.append(Point(x, y))
                    if num != -1 and len(points) >= num:
                        return points
                    points_block.append((y - space, y + space, x - space, x + space))
    elif ori == 3:
        for y in range(rect[1], rect[3]):
            for x in range(rect[2] - 1, rect[0], -1):
                if check_space(y, x, points_block) and check_color(colors, y, x, rows, cols, diff, image):
                    points.append(Point(x, y))
                    if num != -1 and len(points) >= num:
                        return points
                    points_block.append((y - space, y + space, x - space, x + space))
    elif ori == 4:
        for x in range(rect[2] - 1, rect[0], -1):
            for y in range(rect[1], rect[3]):
                if check_space(y, x, points_block) and check_color(colors, y, x, rows, cols, diff, image):
                    points.append(Point(x, y))
                    if num != -1 and len(points) >= num:
                        return points
                    points_block.append((y - space, y + space, x - space, x + space))
    elif ori == 5:
        for x in range(rect[2] - 1, rect[0], -1):
            for y in range(rect[3] - 1, rect[1], -1):
                if check_space(y, x, points_block) and check_color(colors, y, x, rows, cols, diff, image):
                    points.append(Point(x, y))
                    if num != -1 and len(points) >= num:
                        return points
                    points_block.append((y - space, y + space, x - space, x + space))
    elif ori == 6:
        for y in range(rect[3] - 1, rect[1], -1):
            for x in range(rect[2] - 1, rect[0], -1):
                if check_space(y, x, points_block) and check_color(colors, y, x, rows, cols, diff, image):
                    points.append(Point(x, y))
                    if num != -1 and len(points) >= num:
                        return points
                    points_block.append((y - space, y + space, x - space, x + space))
    elif ori == 7:
        for y in range(rect[3] - 1, rect[1], -1):
            for x in range(rect[0], rect[2]):
                if check_space(y, x, points_block) and check_color(colors, y, x, rows, cols, diff, image):
                    points.append(Point(x, y))
                    if num != -1 and len(points) >= num:
                        return points
                    points_block.append((y - space, y + space, x - space, x + space))

    elif ori == 8:
        for x in range(rect[0], rect[2]):
            for y in range(rect[3] - 1, rect[1], -1):
                if check_space(y, x, points_block) and check_color(colors, y, x, rows, cols, diff, image):
                    points.append(Point(x, y))
                    if num != -1 and len(points) >= num:
                        return points
                    points_block.append((y - space, y + space, x - space, x + space))
    # if ori == 2:

    print("end", time.time())

    return points
