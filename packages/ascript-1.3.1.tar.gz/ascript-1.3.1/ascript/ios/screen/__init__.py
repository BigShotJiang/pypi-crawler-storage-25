import base64
import io
import threading
import time
import typing
from io import BytesIO
from typing import Union
from PIL import Image
from ascript.ios import system
from ascript.ios.developer.api import oc, oc_gp, utils, wda_gp
from ascript.ios.screen.color_tools import find_colors
from ascript.ios.screen.gp import GP, GpInOut
from ascript.ios.wdapy import Orientation

use_wda_gp = False


def is_cache():
    """检查当前是否启用了屏幕截图缓存。

    Returns:
        bool: 如果启用了缓存则返回 True，否则返回 False。
    """
    return utils.is_cache


def cache(_cache: bool, image: Image.Image = None, image_file: str = None):
    """设置屏幕截图缓存开关，可选指定缓存使用的图片。

    Args:
        _cache: 是否启用缓存，True 为启用，False 为关闭。
        image: 可选，用于缓存的 PIL Image 对象。
        image_file: 可选，用于缓存的图片文件路径。
    """
    utils.is_cache = _cache

    if image is None and image_file is None and use_wda_gp:
        return wda_gp.screen_cache(_cache)

    oc_gp.screen_cache(_cache, GpInOut(image=image, image_file=image_file, skip_cache=True).img_inout())
    if not _cache:
        CompareColors.cache_img = None


def capture(rect=None) -> Image.Image:
    """截取当前屏幕图像。

    Args:
        rect: 可选，裁剪区域元组 (left, top, right, bottom)。如果指定，则只返回该区域的截图。

    Returns:
        Image.Image: 截取的屏幕图像；如果客户端不可用则返回 None。
    """
    if system.client:
        image = system.client.screenshot()
        if rect:
            image = image.crop(rect)
        return image
    return None


def size() -> typing.Tuple[int, int]:
    """获取当前屏幕尺寸。

    Returns:
        typing.Tuple[int, int]: 屏幕宽高元组 (width, height)；如果客户端不可用则返回 (0, 0)。
    """
    if system.client:
        return system.client.window_size()
    return 0, 0


def ori() -> Orientation:
    """获取当前屏幕方向。

    Returns:
        Orientation: 屏幕方向枚举值；如果客户端不可用则返回 None。
    """
    if system.client:
        return system.client.get_orientation()
    return None


# 图片操作

def image_to_base64(image: Image.Image = None, image_file: str = None, image_format='PNG', decode: str = "utf-8"):
    """将图片转换为 Base64 编码的字符串。

    如果 image 和 image_file 均为 None，则自动截取当前屏幕。

    Args:
        image: 可选，PIL Image 对象。
        image_file: 可选，图片文件路径。
        image_format: 图片格式，默认 'PNG'。
        decode: Base64 编码后的字符串解码格式，默认 "utf-8"。

    Returns:
        str: 图片的 Base64 编码字符串。
    """

    if image is None and image_file is None:
        image = capture()

    if image_file:
        with Image.open(image_file) as img:
            image = img

    buffered = BytesIO()
    # 将Image对象保存到字节流中
    image.save(buffered, format=image_format)
    # 获取字节流的二进制数据
    image_byte_arr = buffered.getvalue()
    # 对二进制数据进行Base64编码
    base64_str = base64.b64encode(image_byte_arr)
    # 将字节类型的Base64编码转换为UTF-8字符串
    return base64_str.decode(decode)


def image_read(file_path: str):
    """从文件路径读取图片。

    Args:
        file_path: 图片文件的路径。

    Returns:
        Image.Image: 读取的 PIL Image 对象。
    """
    return Image.open(file_path)


def image_save(image: Image.Image, path: str):
    """将图片保存到指定路径。

    Args:
        image: 要保存的 PIL Image 对象。
        path: 保存的目标文件路径。
    """
    image.save(path)


def image_crop(image: Image.Image, rect: tuple):
    """裁剪图片到指定区域。

    Args:
        image: 要裁剪的 PIL Image 对象。
        rect: 裁剪区域元组 (left, top, right, bottom)。

    Returns:
        Image.Image: 裁剪后的图片。
    """
    return image.crop(rect)


def image_pixel(image: Image.Image, x: int, y: int):
    """获取图片指定坐标的像素值。

    Args:
        image: PIL Image 对象。
        x: 像素的 x 坐标。
        y: 像素的 y 坐标。

    Returns:
        tuple: 该坐标点的像素颜色值（如 RGB 元组）。
    """
    return image.getpixel((x, y))


def image_rotate(image: Image.Image, angle: int, expand: bool = True):
    """旋转图片指定角度。

    Args:
        image: 要旋转的 PIL Image 对象。
        angle: 旋转角度（逆时针，单位：度）。
        expand: 是否扩展图片尺寸以容纳旋转后的完整图像，默认 True。

    Returns:
        Image.Image: 旋转后的图片。
    """
    return image.rotate(angle, expand=expand)


def image_compress(image: Image.Image, quality=50, _format='PNG'):
    """压缩图片质量。

    Args:
        image: 要压缩的 PIL Image 对象。
        quality: 压缩质量，取值 1-100，数值越小压缩率越高，默认 50。
        _format: 图片格式，默认 'PNG'。

    Returns:
        Image.Image: 压缩后的图片对象。
    """
    output = io.BytesIO()
    image.save(output, format=_format, quality=quality)  # 设置JPEG质量为50%
    # 从BytesIO对象加载压缩后的图像
    compressed_image = Image.open(output)
    # 此时compressed_img是一个新的Image对象，包含了压缩后的图像数据
    # 注意：由于我们是从BytesIO对象加载的，所以原始指针在Image.open()后需要重置到开头
    output.seek(0)
    return compressed_image


class FindColors(GP):
    """多点找色工具，在屏幕或指定图片中根据颜色规则查找匹配的坐标点。"""

    name = "多点找色"
    ui_path = "/static/gp/find_colors"

    def __init__(self, colors: str, rect: list = None, space: int = 5, ori: int = 2, diff: list = (5, 5, 5), num=-1,
                 image: Image.Image = None, image_file=None):
        """初始化多点找色工具。

        Args:
            colors: 颜色规则字符串，格式为 "x,y,颜色hex|x,y,颜色hex|..."。
            rect: 可选，搜索范围 [left, top, right, bottom]。
            space: 相邻结果之间的最小间距，默认 5 像素。
            ori: 搜索方向，1-8 分别对应不同的遍历方向，默认 2（从上到下，从左到右）。
            diff: 颜色容差 (R, G, B)，默认 (5, 5, 5)。
            num: 最大返回结果数量，-1 表示返回所有匹配结果。
            image: 可选，用于搜索的 PIL Image 对象。
            image_file: 可选，用于搜索的图片文件路径。
        """
        self.colors = colors
        self.rect = rect
        self.space = space
        self.ori = ori
        self.diff = diff
        self.num = num
        self.image = image
        self.image_file = image_file
        self.gp = GpInOut(image=image, image_file=image_file, rect=rect)

    def thread_run(self, inout):
        """在子线程中执行找色操作。

        Args:
            inout: 图色处理的输入输出对象。
        """
        inout.data = oc_gp.find_colors(inout.img_inout(), self.colors, self.space, self.ori, self.diff, self.num)

    def run(self, inout: GpInOut) -> GpInOut:
        """执行多点找色任务。

        Args:
            inout: 图色处理的输入输出对象。

        Returns:
            GpInOut: 包含找色结果的输入输出对象，data 字段为匹配的坐标点列表。
        """
        inout.data = None
        inout.rect = self.rect

        if self.image is None and self.image_file is None and use_wda_gp:
            inout.data = wda_gp.find_colors(inout.img_inout(), self.colors, self.space, self.ori, self.diff, self.num)
            return inout

        threading.Thread(target=self.thread_run, args=(inout,)).start()
        while inout.data is None:
            time.sleep(0.001)
        # inout.data = oc_gp.find_colors(inout.img_inout(), self.colors, self.space, self.ori, self.diff, self.num)
        return inout

    def find_all(self):
        """查找所有匹配的颜色坐标点。

        Returns:
            list: 所有匹配的坐标点列表。
        """
        self.num = -1
        return self.run(self.gp).data

    def find(self):
        """查找第一个匹配的颜色坐标点。

        Returns:
            Point: 第一个匹配的坐标点；如果未找到则返回 None。
        """
        self.num = 1
        res = self.run(self.gp).data
        if len(res) > 0:
            return res[0]
        return None


class CompareColors(GP):
    """多点比色工具，检查屏幕或指定图片上的多个坐标点颜色是否与预期一致。"""

    name = "多点比色"
    ui_path = "/static/gp/compare_colors"
    cache_img = None

    def __init__(self, colors: str, diff: tuple = (5, 5, 5), image: Image.Image = None, image_file=None):
        """初始化多点比色工具。

        Args:
            colors: 颜色规则字符串，格式为 "x,y,颜色hex|x,y,颜色hex|..."。
            diff: 颜色容差 (R, G, B)，默认 (5, 5, 5)。
            image: 可选，用于比色的 PIL Image 对象。
            image_file: 可选，用于比色的图片文件路径。
        """
        self.colors = colors
        self.diff = diff
        self.image = image
        self.image_file = image_file
        self.gp = GpInOut(image=self.image, image_file=self.image_file)
        self.cache_img = None

    def run(self, gp_inout: GpInOut) -> GpInOut:
        """执行多点比色任务。

        Args:
            gp_inout: 图色处理的输入输出对象。

        Returns:
            GpInOut: 包含比色结果的输入输出对象，data 字段为 True（所有颜色匹配）或 False（存在不匹配）。
        """
        img_inout = gp_inout.img_inout()
        if img_inout.image is None and img_inout.image_file is None:
            if CompareColors.cache_img is None:
                CompareColors.cache_img = capture()
            a_image = CompareColors.cache_img
        else:
            if img_inout.image_file and not img_inout.image_file.startswith("http"):
                a_image = image_read(gp_inout.image_file)
            elif img_inout.image:
                a_image = img_inout.image
            else:
                a_image = capture()

        colors = color_tools.ana_colors(self.colors)
        for color in colors:
            color2 = a_image.getpixel((color.x, color.y))
            if not color_tools.compare_color_n(color2, color.rgb, self.diff if color.diff is None else color.diff):
                gp_inout.data = False
                return gp_inout
        gp_inout.data = True
        return gp_inout

    def compare(self):
        """执行比色并返回结果。

        Returns:
            bool: 如果所有颜色点均匹配则返回 True，否则返回 False。
        """
        return self.run(self.gp).data


class CountingColor(GP):
    """颜色数量统计工具，统计屏幕或指定图片中符合条件的颜色像素数量。"""

    name = "颜色数量"
    ui_path = "/static/gp/colors_num"

    def __init__(self, colors: str, rect: tuple = None, diff: tuple = (5, 5, 5), image: Image.Image = None,
                 image_file=None):
        """初始化颜色数量统计工具。

        Args:
            colors: 颜色规则字符串。
            rect: 可选，搜索范围元组 (left, top, right, bottom)。
            diff: 颜色容差 (R, G, B)，默认 (5, 5, 5)。
            image: 可选，用于统计的 PIL Image 对象。
            image_file: 可选，用于统计的图片文件路径。
        """
        self.colors = colors
        self.diff = diff
        self.rect = rect
        self.gp = GpInOut(image=image, image_file=image_file, rect=rect)

    def thread_run(self, inout: GpInOut):
        """在子线程中执行颜色计数操作。

        Args:
            inout: 图色处理的输入输出对象。
        """
        inout.data = oc_gp.counting_color(inout.img_inout(), colors=self.colors, diff=self.diff)

    def run(self, inout: GpInOut) -> GpInOut:
        """执行颜色数量统计任务。

        Args:
            inout: 图色处理的输入输出对象。

        Returns:
            GpInOut: 包含颜色计数结果的输入输出对象。
        """
        # gp_inout.data = oc_gp.counting_color(gp_inout.img_inout(), colors=self.colors, diff=self.diff)
        inout.rect = self.rect
        inout.data = None

        if inout.image_file == "http://127.0.0.1:8100/screenshot" and use_wda_gp:
            inout.data = wda_gp.counting_color(inout.img_inout(), self.colors, self.diff)
            return inout

        threading.Thread(target=self.thread_run, args=(inout,)).start()
        while inout.data is None:
            time.sleep(0.01)
        return inout

    def find(self):
        """执行颜色计数并返回结果。

        Returns:
            int: 符合条件的颜色像素数量。
        """
        return self.run(self.gp).data


class FindImages(GP):
    """找图工具，在屏幕或指定图片中查找目标小图的位置。

    支持模板匹配 (M_TEMPLATE)、SIFT 特征匹配 (M_SIFT) 和混合模式 (M_MIX)。
    """

    name = "找图"
    ui_path = "/static/gp/find_images"
    M_TEMPLATE = 0
    M_SIFT = 1
    M_MIX = 2

    @property
    def gp_inout(self):
        """获取图色处理输入输出对象。

        Returns:
            GpInOut: 当前的图色处理输入输出对象。
        """
        return self.gp

    def __init__(self, part_image: Union[str, list], rect: tuple = None, confidence=0.1, rgb: bool = True,
                 mode=M_TEMPLATE, num=0,
                 image: Image.Image = None, image_file: str = None):
        """初始化找图工具。

        Args:
            part_image: 要查找的目标小图，可以是图片文件路径字符串或路径列表。
            rect: 可选，搜索范围元组 (left, top, right, bottom)。
            confidence: 匹配置信度阈值，默认 0.1。
            rgb: 是否使用 RGB 模式匹配，默认 True。
            mode: 匹配模式，M_TEMPLATE(0)=模板匹配，M_SIFT(1)=SIFT特征匹配，M_MIX(2)=混合模式。
            num: 最大返回结果数量，0 表示不限。
            image: 可选，用于搜索的 PIL Image 对象。
            image_file: 可选，用于搜索的图片文件路径。
        """
        self.part_image = part_image
        self.rect = rect
        self.confidence = confidence
        self.mode = mode
        self.num = num
        self.rgb = rgb

        self.gp = GpInOut(image=image, image_file=image_file, rect=rect)

    def thread_run(self, inout):
        """在子线程中执行找图操作。

        Args:
            inout: 图色处理的输入输出对象。
        """
        if self.mode == FindImages.M_TEMPLATE or self.mode == FindImages.M_MIX:
            inout.data = oc_gp.find_all_template(inout.img_inout(), self.part_image, threshold=self.confidence,
                                                 rgb=self.rgb,
                                                 max_res=self.num)

        if self.mode == FindImages.M_SIFT or self.mode == FindImages.M_MIX:
            if inout.data is None or len(inout.data) < 1:
                inout.data = oc_gp.find_sift(inout.img_inout(), self.part_image, threshold=self.confidence,
                                             rgb=self.rgb, max_res=self.num)

    def run(self, inout: GpInOut) -> GpInOut:
        """执行找图任务。

        Args:
            inout: 图色处理的输入输出对象。

        Returns:
            GpInOut: 包含找图结果的输入输出对象，data 字段为匹配结果列表。
        """
        # image.show()
        if type(self.part_image) is str:
            self.part_image = [self.part_image]

        inout.rect = self.rect

        inout.data = None
        threading.Thread(target=self.thread_run, args=(inout,)).start()
        while inout.data is None:
            time.sleep(0.01)

        # data = None
        # if self.mode == FindImages.M_TEMPLATE or self.mode == FindImages.M_MIX:
        #     data = oc_gp.find_all_template(gp_inout.img_inout(), self.part_image, threshold=self.confidence,
        #                                    rgb=self.rgb,
        #                                    max_res=self.num)
        #
        # if self.mode == FindImages.M_SIFT or self.mode == FindImages.M_MIX:
        #     if data is None or len(data) < 1:
        #         data = oc_gp.find_sift(gp_inout.img_inout(), self.part_image, threshold=self.confidence,
        #                                rgb=self.rgb, max_res=self.num)

        return inout

    def find(self):
        """使用混合模式查找第一个匹配的图片位置，先模板匹配再 SIFT。

        Returns:
            dict: 匹配结果字典（包含 result、rect、confidence 等）；如果未找到则返回 None 或空列表。
        """
        data = self.find_template()
        if data is None or len(data) < 1:
            data = self.find_sift()

        return data

    def find_all(self):
        """使用模板匹配查找所有匹配的图片位置。

        Returns:
            list: 所有匹配结果的列表。
        """
        data = self.find_all_template()
        if data is None or len(data) < 1:
            data = self.find_all_template()

        return data

    def find_template(self):
        """使用模板匹配查找第一个匹配的图片位置。

        Returns:
            dict: 第一个匹配结果字典；如果未找到则返回 None 或空。
        """
        self.num = 1
        self.mode = FindImages.M_TEMPLATE
        data = self.run(self.gp).data
        if data and len(data) > 0:
            data = data[0]

        return data

    def find_all_template(self):
        """使用模板匹配查找所有匹配的图片位置。

        Returns:
            list: 所有模板匹配结果的列表。
        """
        self.num = -1
        self.mode = FindImages.M_TEMPLATE
        return self.run(self.gp).data

    def find_sift(self):
        """使用 SIFT 特征匹配查找第一个匹配的图片位置。

        Returns:
            dict: 第一个匹配结果字典；如果未找到则返回 None 或空。
        """
        self.num = 1
        self.mode = FindImages.M_SIFT
        data = self.run(self.gp).data
        if data and len(data) > 0:
            data = data[0]

        return data

    def find_all_sift(self):
        """使用 SIFT 特征匹配查找所有匹配的图片位置。

        Returns:
            list: 所有 SIFT 匹配结果的列表。
        """
        self.num = -1
        self.mode = FindImages.M_SIFT
        return self.run(self.gp).data


class Ocr(GP):
    """文字识别 (OCR) 工具，支持多种识别引擎对屏幕或指定图片进行文字提取。

    支持的识别模式：
        - MODE_MLK (1): MLKit 引擎
        - MODE_PADDLE_V2 (2): PaddleOCR v2 引擎
        - MODE_PADDLE_V3 (3): PaddleOCR v3 引擎
        - MODE_TESS (4): Tesseract 引擎
    """

    Tess_ENG = "eng"
    Tess_CHI = "chi"
    Tess_NUM = "num"
    RIL_AUTO = -1
    RIL_BLOCK = 0
    RIL_PARA = 1
    RIL_TEXTLINE = 2
    RIL_WORD = 3
    RIL_SYMBOL = 4
    lock = threading.Lock()
    name = "文字识别"
    ui_path = "/static/gp/ocr"

    MODE_MLK = 1
    MODE_PADDLE_V2 = 2
    MODE_PADDLE_V3 = 3
    MODE_TESS = 4

    def __init__(self, mode=MODE_MLK, rect=None, pattern: str = None, confidence: float = 0.1,
                 max_side_len: int = 1200, image: Image.Image = None, image_file: str = None):
        """初始化 OCR 文字识别工具。

        Args:
            mode: 识别引擎模式，默认 MODE_MLK(1)。
            rect: 可选，识别区域元组 (left, top, right, bottom)。
            pattern: 可选，正则表达式过滤模式，仅返回匹配的文字结果。
            confidence: 置信度阈值，低于此值的结果将被过滤，默认 0.1。
            max_side_len: 图片最大边长限制，默认 1200。
            image: 可选，用于识别的 PIL Image 对象。
            image_file: 可选，用于识别的图片文件路径。
        """
        self.mode = mode
        self.rect = rect
        self.pattern = pattern
        self.confidence = confidence
        self.max_side_len = 1200

        self.gp = GpInOut(image=image, image_file=image_file, rect=rect)

    def thread_run(self, inout: GpInOut):
        """在子线程中执行 OCR 识别操作。

        Args:
            inout: 图色处理的输入输出对象。
        """
        inout.data = oc_gp.ocr(self.mode, inout.img_inout(), threshold=self.confidence, pattern=self.pattern)

    def run(self, inout: GpInOut) -> GpInOut:
        """执行 OCR 文字识别任务。

        Args:
            inout: 图色处理的输入输出对象。

        Returns:
            GpInOut: 包含识别结果的输入输出对象，data 字段为识别到的文字列表。
        """
        inout.rect = self.rect
        # data = oc_gp.ocr(self.mode, img_inout, threshold=self.confidence, pattern=self.pattern)
        # gp_inout.data = data

        inout.data = None
        threading.Thread(target=self.thread_run, args=(inout,)).start()
        while inout.data is None:
            time.sleep(0.01)

        return inout

    def paddleocr_v3(self):
        """使用当前配置执行 OCR 识别并返回结果。

        Returns:
            list: 识别到的文字结果列表。
        """
        return self.run(self.gp).data


class CodeScanner(GP):
    """条码/二维码识别工具，支持扫描屏幕或指定图片中的条形码和二维码。"""

    name = "条码识别"
    ui_path = "/static/gp/codescanner/"

    def __init__(self, rect: tuple = None, image: Image = None, image_file: str = None):
        """初始化条码识别工具。

        Args:
            rect: 可选，扫描区域元组 (left, top, right, bottom)。
            image: 可选，用于扫描的 PIL Image 对象。
            image_file: 可选，用于扫描的图片文件路径。
        """
        self.rect = rect
        self.image = image
        self.image_file = image_file
        self.gp = GpInOut(image=image, image_file=image_file)

    def run(self, gp_inout: GpInOut) -> GpInOut:
        """执行条码识别任务。

        Args:
            gp_inout: 图色处理的输入输出对象。

        Returns:
            GpInOut: 包含识别结果的输入输出对象，data 字段为识别到的条码信息。
        """
        image = gp_inout.image
        if gp_inout.image_file:
            if gp_inout.image_file.startswith("http:"):
                image = capture()
            else:
                image = image_read(gp_inout.image_file)

        offset_x = 0
        offset_y = 0
        if self.rect:
            image = image.crop(self.rect)
            offset_x = self.rect[0]
            offset_y = self.rect[1]

        data = oc.code_scanner(image, offset_x=offset_x, offset_y=offset_y)

        gp_inout.data = data
        return gp_inout

    def scan(self):
        """执行条码扫描并返回结果。

        Returns:
            list: 识别到的条码/二维码信息列表。
        """
        return self.run(self.gp).data


def gp_list():
    """获取所有可用的图色工具类列表。

    Returns:
        list: 包含各图色工具信息字典的列表，每个字典包含 name、ui_path、id、class_name、type 字段。
    """
    gp_s_list = []
    gp_s_list.append("ascript.ios.screen.FindColors")
    gp_s_list.append("ascript.ios.screen.CompareColors")
    gp_s_list.append("ascript.ios.screen.CountingColor")
    gp_s_list.append("ascript.ios.screen.FindImages")
    gp_s_list.append("ascript.ios.screen.Ocr")
    gp_s_list.append("ascript.ios.screen.CodeScanner")
    class_list = []
    for gp_s in gp_s_list:
        module_name, class_name = gp_s.rsplit('.', 1)
        module = gp.load_or_reload_module(module_name)
        gp_class = getattr(module, class_name)
        dao = {"name": gp_class.name, "ui_path": gp_class.ui_path, "id": gp_s, "class_name": class_name,
               "type": "图色工具"}
        class_list.append(dao)
    # print(class_list)
    return class_list
