import json
import threading
import time
from typing import Union

from PIL.Image import Image

from ascript.ios.developer.api import oc_gp


def load(param_path: str, bin_path: str, nc: int, use_gpu: bool = False):
    """加载 YOLOv8 模型。

    在加载新模型前会先释放已有模型资源。

    Args:
        param_path: 模型参数文件路径。
        bin_path: 模型二进制文件路径。
        nc: 目标分类数量。
        use_gpu: 是否使用 GPU 加速，默认 False。

    Returns:
        模型加载结果。
    """
    free()
    return oc_gp.yolov8_load(param_path, bin_path, nc, use_gpu)


# def detect(img: Union[Image, str] = None, target_size: int = 640, threshold=0.4, nms_threshold=0.5):
#     if img is None:
#         img = "http://127.0.0.1:8100/screenshot"
#
#     res = oc_gp.yolov8_detect(img, target_size, threshold, nms_threshold)
#
#     return res

yolo_res = None


def detect(img: Union[Image, str] = None, target_size: int = 640, threshold=0.4, nms_threshold=0.5):
    """使用已加载的 YOLOv8 模型进行目标检测。

    在子线程中执行检测以避免阻塞。

    Args:
        img: 要检测的图片，可以是 PIL Image 对象或图片路径/URL 字符串。默认使用 WDA 截图。
        target_size: 检测目标尺寸，默认 640。
        threshold: 检测置信度阈值，默认 0.4。
        nms_threshold: 非极大值抑制阈值，默认 0.5。

    Returns:
        list: 检测结果列表。
    """
    if img is None:
        img = "http://127.0.0.1:8100/screenshot"

    global yolo_res
    yolo_res = None

    def thread_detech():
        global yolo_res
        yolo_res = oc_gp.yolov8_detect(img, target_size, threshold, nms_threshold)

    threading.Thread(target=thread_detech).start()

    while yolo_res is None:
        time.sleep(0.01)

    return yolo_res


def free():
    """释放已加载的 YOLOv8 模型资源。

    Returns:
        模型释放结果。
    """
    return oc_gp.yolov8_free()
