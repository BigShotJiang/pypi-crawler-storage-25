# coding: utf-8
#

import typing


class Wrapper:
    """包装器基类，提供请求超时管理功能。

    用于为客户端类提供可临时修改的请求超时时间。

    MetaClass ref:
        https://www.jianshu.com/p/224ffcb8e73e
    """

    def __init__(self):
        """初始化包装器，设置默认请求超时时间为 None。"""
        self._request_timeout = None


def timeout(seconds: typing.Union[float, int]):
    """超时装饰器工厂函数，用于临时修改方法执行时的请求超时时间。

    在被装饰方法执行期间临时设置超时时间，方法执行完毕后恢复原始超时设置。

    Args:
        seconds: 超时时间（秒），支持浮点数和整数。

    Returns:
        装饰器函数，可应用于需要临时修改超时时间的方法。
    """
    def _timeout_wrapper(fn):
        """内部装饰器，包装目标函数以实现超时控制。

        Args:
            fn: 被装饰的目标函数。

        Returns:
            包装后的函数。
        """
        def _inner(self, *args, **kwargs):
            """执行被装饰函数，确保超时设置在执行后恢复。

            Args:
                *args: 传递给被装饰函数的位置参数。
                **kwargs: 传递给被装饰函数的关键字参数。

            Returns:
                被装饰函数的返回值。
            """
            old_timeout = self._request_timeout
            try:
                return fn(self, *args, **kwargs)
            finally:
                self._request_timeout = old_timeout
        return _inner
    return _timeout_wrapper
