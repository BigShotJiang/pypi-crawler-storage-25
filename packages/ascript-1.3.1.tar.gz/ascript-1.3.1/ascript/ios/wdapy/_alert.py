#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Created on Tue Sep 14 2021 15:24:46 by codeskyblue
"""

import logging
import typing
from .exceptions import RequestError
from ._proto import *
from ._base import BaseClient

logger = logging.getLogger(__name__)

class Alert:
    """iOS 系统弹窗（Alert）操作类。

    提供对 iOS 系统弹窗的检测、读取和交互功能，包括获取弹窗文本、
    点击按钮、接受或拒绝弹窗等操作。
    """

    def __init__(self, client: BaseClient):
        """初始化弹窗操作实例。

        Args:
            client: WDA 基础客户端实例，用于发送 HTTP 请求。
        """
        self._client = client

    @property
    def exists(self) -> bool:
        """检查当前是否存在弹窗。

        Returns:
            如果存在弹窗返回 True，否则返回 False。
        """
        try:
            self.get_text()
            return True
        except RequestError:
            return False

    def buttons(self) -> typing.List[str]:
        """获取弹窗上所有按钮的文本列表。

        Returns:
            弹窗按钮文本的字符串列表。
        """
        return self._client.session_request(GET, "/wda/alert/buttons")["value"]

    def get_text(self) -> str:
        """获取弹窗的文本内容。

        Returns:
            弹窗显示的文本字符串。
        """
        return self._client.session_request(GET, "/alert/text")["value"]

    def accept(self):
        """接受（确认）弹窗。

        Returns:
            WDA 请求的响应结果。
        """
        return self._client.session_request(POST, "/alert/accept")

    def dismiss(self):
        """拒绝（取消）弹窗。

        Returns:
            WDA 请求的响应结果。
        """
        return self._client.session_request(POST, "/alert/dismiss")

    def click(self, button_name: typing.Union[str, list]):
        """点击弹窗上的指定按钮。

        支持传入单个按钮名称或按钮名称列表。当传入列表时，
        会按顺序匹配第一个存在的按钮并点击。

        Args:
            button_name: 按钮名称字符串，或按钮名称的优先级列表。
        """
        if isinstance(button_name, str):
            self._client.session_request(POST, "/alert/accept", {"name": button_name})
            return
        elif isinstance(button_name, list):
            expect_buttons = button_name
            buttons = self.buttons()
            for name in expect_buttons:
                if name in buttons:
                    return self.click(name)
            logger.debug("alert not clicked, buttons: %s, expect buttons: %s", buttons, expect_buttons)