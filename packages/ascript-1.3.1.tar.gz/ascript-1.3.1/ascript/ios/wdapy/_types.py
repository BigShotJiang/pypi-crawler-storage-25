# coding: utf-8
#
__all__ = ["Recover", "StatusInfo", "AppInfo", "DeviceInfo", "BatteryInfo", "SourceTree",
           "StatusBarSize", "AppList",
           "Gesture", "GestureOption", "GestureAction"]

import abc
import enum
import typing
from collections import namedtuple
from dataclasses import dataclass
from typing import Optional, Union

from ._proto import *
from ._utils import camel_to_snake


def smart_value_of(obj, data: dict):
    """将字典中的键值对批量设置为对象的属性。

    Args:
        obj: 目标对象。
        data: 属性名到属性值的映射字典。
    """
    for key, val in data.items():
        setattr(obj, key, val)


class Recover(abc.ABC):
    """WDA 恢复处理器抽象基类。

    定义 WDA 服务异常时的恢复接口，子类需实现具体的恢复逻辑。
    """

    @abc.abstractmethod
    def recover(self) -> bool:
        """执行恢复操作。

        Returns:
            恢复成功返回 True，失败返回 False。
        """
        pass


class _Base:
    """数据模型基类。

    提供自动初始化类型注解属性为 None、格式化输出以及
    从字典自动映射属性（驼峰转下划线）等通用功能。
    """

    def __init__(self):
        """初始化数据模型，将所有类型注解的属性设置为 None。"""
        # set default value
        for k, _ in typing.get_type_hints(self).items():
            if not hasattr(self, k):
                setattr(self, k, None)

    def __repr__(self):
        """返回包含所有属性的格式化字符串表示。

        Returns:
            格式化的对象描述字符串。
        """
        attrs = []
        for k, v in self.__dict__.items():
            attrs.append(f"{k}={v!r}")
        return f"<{self.__class__.__name__} " + ", ".join(attrs) + ">"

    @classmethod
    def value_of(cls, data: dict):
        """从字典创建数据模型实例，自动将驼峰命名的键转换为下划线命名。

        Args:
            data: 包含属性数据的字典，键名为驼峰命名。

        Returns:
            填充了对应属性的类实例。
        """
        instance = cls()
        for k, v in data.items():
            key = camel_to_snake(k)
            if hasattr(instance, key):
                setattr(instance, key, v)

        return instance


class AppInfo(_Base):
    """应用信息数据类。

    存储 iOS 应用的基本信息，包括名称、进程参数、PID 和 Bundle ID。
    """
    name: str
    process_arguments: dict
    pid: int
    bundle_id: str


class StatusInfo(_Base):
    """WDA 服务状态信息数据类。

    存储 WDA 服务的运行状态，包括 IP 地址、会话 ID 和状态消息。
    """
    ip: str
    session_id: str
    message: str

    @staticmethod
    def value_of(data: dict) -> "StatusInfo":
        """从 WDA 状态响应字典创建 StatusInfo 实例。

        Args:
            data: WDA /status 接口返回的完整 JSON 字典。

        Returns:
            填充了 IP、会话 ID 和消息的 StatusInfo 实例。
        """
        info = StatusInfo()
        value = data['value']
        info.session_id = data['sessionId']
        info.ip = value['ios']['ip']
        info.message = value['message']
        return info

class DeviceInfo(_Base):
    """设备信息数据类。

    存储 iOS 设备的详细信息，包括时区、语言、型号、UUID 等。
    """
    time_zone: str
    current_locale: str
    model: str
    uuid: str
    user_interface_idiom: int
    user_interface_style: str
    name: str
    is_simulator: bool


class BatteryInfo(_Base):
    """电池信息数据类。

    存储 iOS 设备的电池电量和充电状态。
    """
    level: float
    state: BatteryState

    @staticmethod
    def value_of(data: dict) -> "BatteryInfo":
        """从字典创建 BatteryInfo 实例。

        Args:
            data: 包含 level 和 state 键的字典。

        Returns:
            填充了电量和状态的 BatteryInfo 实例。
        """
        info = BatteryInfo()
        info.level = data['level']
        info.state = BatteryState(data['state'])
        return info


class SourceTree(_Base):
    """页面源码树数据类。

    存储 WDA 返回的页面 UI 层级源码及对应的会话 ID。
    """
    value: str
    sessionId: str

class StatusBarSize(_Base):
    """状态栏尺寸数据类。

    存储 iOS 设备状态栏的宽度和高度。
    """
    width: int
    height: int


class AppList(_Base):
    """应用列表项数据类。

    存储单个应用的进程 ID 和 Bundle ID。
    """
    pid: int
    bundle_id: str


@dataclass
class GestureOption:
    """手势动作选项数据类。

    定义手势动作中的可选参数，如目标元素、坐标位置、重复次数和等待时长。
    """
    element: Optional[str] = None
    x: Optional[int] = None
    y: Optional[int] = None
    count: Optional[int] = None
    ms: Optional[int] = None # action:wait duration


@dataclass
class Gesture:
    """手势动作数据类。

    表示一个完整的手势动作，包含动作类型和可选参数。
    """
    action: Union[str, GestureAction]
    options: Optional[Union[dict, GestureOption]] = None


@dataclass
class Rect(list):
    """矩形区域数据类。

    表示一个矩形区域，同时继承 list 以支持下标访问。
    提供中心点、原点及各边界的便捷属性。
    """

    def __init__(self, x, y, width, height):
        """初始化矩形区域。

        Args:
            x: 矩形左上角 x 坐标。
            y: 矩形左上角 y 坐标。
            width: 矩形宽度。
            height: 矩形高度。
        """
        super().__init__([x, y, width, height])
        self.__dict__.update({
            "x": x,
            "y": y,
            "width": width,
            "height": height
        })

    def __str__(self):
        """返回矩形的格式化字符串表示。

        Returns:
            包含 x、y、width、height 的格式化字符串。
        """
        return 'Rect(x={x}, y={y}, width={w}, height={h})'.format(
            x=self.x, y=self.y, w=self.width, h=self.height)

    def __repr__(self):
        """返回矩形的官方字符串表示。

        Returns:
            与 __str__ 相同的格式化字符串。
        """
        return str(self)

    @property
    def center(self):
        """获取矩形的中心点坐标。

        Returns:
            包含 x 和 y 属性的 Point 命名元组。
        """
        return namedtuple('Point', ['x', 'y'])(self.x + self.width // 2,
                                               self.y + self.height // 2)

    @property
    def origin(self):
        """获取矩形的原点（左上角）坐标。

        Returns:
            包含 x 和 y 属性的 Point 命名元组。
        """
        return namedtuple('Point', ['x', 'y'])(self.x, self.y)

    @property
    def left(self):
        """获取矩形的左边界 x 坐标。

        Returns:
            左边界的 x 坐标值。
        """
        return self.x

    @property
    def top(self):
        """获取矩形的上边界 y 坐标。

        Returns:
            上边界的 y 坐标值。
        """
        return self.y

    @property
    def right(self):
        """获取矩形的右边界 x 坐标。

        Returns:
            右边界的 x 坐标值（x + width）。
        """
        return self.x + self.width

    @property
    def bottom(self):
        """获取矩形的下边界 y 坐标。

        Returns:
            下边界的 y 坐标值（y + height）。
        """
        return self.y + self.height
