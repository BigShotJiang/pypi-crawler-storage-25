#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Created on Tue Sep 14 2021 15:26:27 by codeskyblue
"""

from http.client import HTTPConnection, HTTPSConnection
import logging
import typing

import json
from retry import retry
from urllib.parse import urlparse
from ._proto import *
from ._types import Recover, StatusInfo
from .exceptions import *

logger = logging.getLogger(__name__)


class HTTPResponseWrapper:
    """HTTP 响应包装类。

    封装 HTTP 响应的原始字节内容和状态码，提供 JSON 解析和文本解码功能。
    """

    def __init__(self, content: bytes, status_code: int):
        """初始化 HTTP 响应包装器。

        Args:
            content: 响应的原始字节内容。
            status_code: HTTP 响应状态码。
        """
        self.content = content
        self.status_code = status_code

    def json(self):
        """将响应内容解析为 JSON 对象。

        Returns:
            解析后的 Python 字典或列表。
        """
        return json.loads(self.content)

    @property
    def text(self) -> str:
        """获取响应内容的 UTF-8 文本。

        Returns:
            响应内容的字符串形式。
        """
        return self.content.decode("utf-8")

    def getcode(self) -> int:
        """获取 HTTP 状态码。

        Returns:
            HTTP 响应状态码。
        """
        return self.status_code


def http_create(url: str) -> typing.Union[HTTPConnection, HTTPSConnection]:
    """根据 URL 的协议创建对应的 HTTP 连接对象。

    Args:
        url: 目标 URL 地址，支持 http 和 https 协议。

    Returns:
        HTTPConnection 或 HTTPSConnection 实例。

    Raises:
        ValueError: 当 URL 使用不支持的协议时抛出。
    """
    u = urlparse(url)
    if u.scheme == "http":
        return HTTPConnection(u.netloc)
    elif u.scheme == "https":
        return HTTPSConnection(u.netloc)
    else:
        raise ValueError(f"unknown scheme: {u.scheme}")


class BaseClient:
    """WDA 基础客户端类。

    提供与 WebDriverAgent 通信的底层 HTTP 请求功能，
    包括会话管理、请求发送和错误恢复机制。
    """

    def __init__(self, wda_url: str):
        """初始化 WDA 基础客户端。

        Args:
            wda_url: WebDriverAgent 服务的 URL 地址，例如 "http://localhost:8100"。
        """
        self._wda_url = wda_url.rstrip("/") + "/"

        self._session_id: str = None
        self._recover: Recover = None

        self.__request_timeout = DEFAULT_HTTP_TIMEOUT

    @property
    def request_timeout(self) -> float:
        """获取当前 HTTP 请求超时时间（秒）。

        Returns:
            当前设置的请求超时时间。
        """
        return self.__request_timeout

    @request_timeout.setter
    def request_timeout(self, timeout: float):
        """设置 HTTP 请求超时时间。

        Args:
            timeout: 超时时间（秒）。
        """
        self.__request_timeout = timeout

    def status(self) -> StatusInfo:
        """获取 WDA 服务状态信息。

        Returns:
            包含 WDA 服务状态的 StatusInfo 对象。
        """
        data = self.request(GET, "/status")
        return StatusInfo.value_of(data)

    def session(self,
                bundle_id: str = None,
                arguments: list = None,
                environment: dict = None) -> str:
        """创建新的 WDA 会话并返回会话 ID。

        Args:
            bundle_id: 应用的 Bundle ID，如不指定则创建无应用绑定的会话。
            arguments: 启动应用时传递的命令行参数列表。
            environment: 启动应用时设置的环境变量字典。

        Returns:
            新创建的会话 ID 字符串。
        """
        capabilities = {}
        if bundle_id:
            always_match = {
                "bundleId": bundle_id,
                "arguments": arguments or [],
                "environment": environment or {},
                "shouldWaitForQuiescence": False,
            }
            capabilities['alwaysMatch'] = always_match
        payload = {
            "capabilities": capabilities,
            "desiredCapabilities": capabilities.get('alwaysMatch',
                                                    {}),  # 兼容旧版的wda
        }
        data = self.request(POST, "/session", payload)

        # update cached session_id
        self._session_id = data['sessionId']
        return self._session_id

    def set_recover_handler(self, recover: Recover):
        """设置错误恢复处理器。

        当请求失败时，会调用该处理器尝试恢复 WDA 服务。

        Args:
            recover: 实现了 Recover 接口的恢复处理器实例。
        """
        self._recover = recover

    def _get_valid_session_id(self) -> str:
        """获取有效的会话 ID。

        如果当前缓存的会话 ID 无效，则尝试从 WDA 状态中获取，
        或创建新的会话。

        Returns:
            有效的会话 ID 字符串。
        """
        if self._session_id:
            return self._session_id
        old_session_id = self.status().session_id
        if old_session_id:
            self._session_id = old_session_id
        else:
            self._session_id = self.session()
        return self._session_id

    def session_request(self, method: RequestMethod, urlpath: str, payload: dict = None) -> dict:
        """发送带会话 ID 的请求。

        自动在 URL 路径前添加会话 ID 前缀。如果会话失效会自动重新创建。

        Args:
            method: HTTP 请求方法（GET 或 POST）。
            urlpath: API 路径，不含会话 ID 前缀。
            payload: 请求体字典，可选。

        Returns:
            WDA 返回的 JSON 响应字典，请求异常时返回 None。
        """
        session_id = self._get_valid_session_id()
        # print("session_id:",session_id)
        session_urlpath = f"/session/{session_id}/" + urlpath.lstrip("/")
        try:
            try:
                return self.request(method, session_urlpath, payload)
            except WDASessionDoesNotExist:
                # In some condition, session_id exist in /status, but not working
                # The bellow code fix that case
                logger.info("session %r does not exist, generate new one", session_id)
                session_id = self._session_id = self.session()
                session_urlpath = f"/session/{session_id}/" + urlpath.lstrip("/")
                return self.request(method, session_urlpath, payload)
        except Exception as e:
            # print(e)
            logger.info("request: %s %s %s", method, urlpath, payload)
            return None

    def request(self, method: RequestMethod, urlpath: str, payload: dict = None) -> dict:
        """发送 HTTP 请求到 WDA 服务。

        Args:
            method: HTTP 请求方法（GET 或 POST）。
            urlpath: API 路径。
            payload: 请求体字典，可选。

        Returns:
            WDA 返回的 JSON 响应字典。

        Raises:
            RequestError: 当响应不是 JSON 格式时抛出。
            ApiError: 当 WDA 返回错误响应时抛出。
        """
        full_url = self._wda_url.rstrip("/") + "/" + urlpath.lstrip("/")
        payload_debug = payload or ""
        # logger.debug("$ %s", f"curl -X{method} --max-time {self.request_timeout:d} {full_url} -d {payload_debug!r}")

        resp = self._request_http(method, full_url, payload)
        try:
            short_json = resp.json().copy()
            # print(short_json)
        except json.JSONDecodeError:
            raise RequestError("response is not json format", resp.text)

        for k, v in short_json.items():
            if isinstance(v, str) and len(v) > 40:
                v = v[:20] + "... skip ..." + v[-10:]
            short_json[k] = v
        # logger.debug("==> Response <==\n%s", json.dumps(short_json, indent=4, ensure_ascii=False))

        value = resp.json().get("value")
        if value and isinstance(value, dict) and value.get("error"):
            raise ApiError(resp.status_code, value["error"], value.get("message"))

        return resp.json()

    # @retry(RequestError, tries=2, delay=0.2, jitter=0.1, logger=logging)
    def _request_http(self, method: RequestMethod, url: str, payload: dict, **kwargs) -> HTTPResponseWrapper:
        """执行底层 HTTP 请求。

        处理实际的 HTTP 连接建立、请求发送和响应读取。
        当请求失败且设置了恢复处理器时，会尝试调用恢复逻辑。

        Args:
            method: HTTP 请求方法（GET 或 POST）。
            url: 完整的请求 URL。
            payload: 请求体字典，可选。
            **kwargs: 额外参数，支持 timeout 指定请求超时时间。

        Returns:
            包含响应内容和状态码的 HTTPResponseWrapper 对象。
        """
        logger.info("request: %s %s %s", method, url, payload)
        try:
            conn = http_create(url)
            conn.timeout = kwargs.get("timeout", self.request_timeout)
            u = urlparse(url)
            urlpath = url[len(u.scheme) + len(u.netloc) + 3:]

            if not payload:
                conn.request(method.value, urlpath)
            else:
                # print(urlpath,payload)
                conn.request(method.value, urlpath, json.dumps(payload), headers={"Content-Type": "application/json"})
            response = conn.getresponse()
            content = bytearray()
            while chunk := response.read(4096):
                content.extend(chunk)
            resp = HTTPResponseWrapper(content, response.status)

            if response.getcode() == 200:
                return resp
            else:
                # handle unexpected response
                if "Session does not exist" in resp.text:
                    # raise WDASessionDoesNotExist(resp.text)
                    # print(WDASessionDoesNotExist(resp.text))
                    logger.info("request: %s %s %s %s", method, url, payload, resp.text)
                else:
                    # raise RequestError(f"response code: {response.getcode()}", resp.text)
                    # print(RequestError(f"response code: {response.getcode()}", resp.text))
                    logger.info("request: %s %s %s %s", method, url, payload, resp.text)
        except Exception as err:
            if self._recover:
                if not self._recover.recover():
                    print(WDAFatalError("recover failed"))
                    logger.info("request: %s %s %s %s", method, url, payload, "ecover failed")
                    # logger.info("request: %s %s %s %s", method, url, payload, str(err))
                    # raise WDAFatalError("recover failed")
            # raise RequestError("ConnectionBroken", err)
            # print(RequestError("ConnectionBroken", err))
            logger.info("request: %s %s %s %s", method, url, payload,str(err))
