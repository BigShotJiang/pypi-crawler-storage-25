import re
import time
from typing import Optional

import retry

from ascript.ios.wdapy import xcui_element_types, RequestMethod
from ascript.ios.wdapy._base import BaseClient
from ascript.ios.wdapy._types import Rect
from ascript.ios.wdapy._wdapy import CommonClient
from ascript.ios.wdapy.exceptions import WDAStaleElementReferenceError, WDAElementNotFoundError, \
    WDAElementNotDisappearError

DEBUG = False


class Selector(object):
    """iOS UI 元素选择器类。

    通过多种条件（名称、类型、XPath、谓词等）查找和定位 iOS 页面中的 UI 元素。
    支持链式查询和多种匹配方式，包括精确匹配、包含匹配和正则匹配。
    """

    def __init__(self,
                 client: CommonClient,
                 predicate=None,
                 id=None,
                 className=None,
                 type=None,
                 name=None,
                 nameContains=None,
                 nameMatches=None,
                 text=None,
                 textContains=None,
                 textMatches=None,
                 value=None,
                 valueContains=None,
                 label=None,
                 labelContains=None,
                 visible=None,
                 enabled=None,
                 classChain=None,
                 xpath=None,
                 parent_class_chains=[],
                 timeout=10.0,
                 index=0):
        '''初始化 UI 元素选择器。

        Args:
            predicate (str): predicate string
            id (str): raw identifier
            className (str): attr of className
            type (str): alias of className
            name (str): attr for name
            nameContains (str): attr of name contains
            nameMatches (str): regex string
            text (str): alias of name
            textContains (str): alias of nameContains
            textMatches (str): alias of nameMatches
            value (str): attr of value, not used in most times
            valueContains (str): attr of value contains
            label (str): attr for label
            labelContains (str): attr for label contains
            visible (bool): is visible
            enabled (bool): is enabled
            classChain (str): string of ios chain query, eg: **/XCUIElementTypeOther[`value BEGINSWITH 'blabla'`]
            xpath (str): xpath string, a little slow, but works fine
            timeout (float): maxium wait element time, default 10.0s
            index (int): index of founded elements

        WDA use two key to find elements "using", "value"
        Examples:
        "using" can be on of
            "partial link text", "link text"
            "name", "id", "accessibility id"
            "class name", "class chain", "xpath", "predicate string"

        predicate string support many keys
            UID,
            accessibilityContainer,
            accessible,
            enabled,
            frame,
            label,
            name,
            rect,
            type,
            value,
            visible,
            wdAccessibilityContainer,
            wdAccessible,
            wdEnabled,
            wdFrame,
            wdLabel,
            wdName,
            wdRect,
            wdType,
            wdUID,
            wdValue,
            wdVisible
        '''
        assert isinstance(client, CommonClient)
        self._client = client
        self._num = -1
        self._predicate = predicate
        self._id = id
        self._class_name = className or type
        self._name = name
        self._name_part = nameContains or textContains
        self._name_regex = nameMatches or textMatches
        self._value = value
        self._value_part = valueContains
        self._label = label
        self._label_part = labelContains
        self._enabled = enabled
        self._visible = visible
        self._index = index

        self._xpath = self._fix_xcui_type(xpath)
        self._class_chain = self._fix_xcui_type(classChain)
        self._timeout = timeout
        # some fixtures
        if self._class_name and not self._class_name.startswith(
                'XCUIElementType'):
            self._class_name = 'XCUIElementType' + self._class_name
        if self._name_regex:
            if not self._name_regex.startswith(
                    '^') and not self._name_regex.startswith('.*'):
                self._name_regex = '.*' + self._name_regex
            if not self._name_regex.endswith(
                    '$') and not self._name_regex.endswith('.*'):
                self._name_regex = self._name_regex + '.*'
        self._parent_class_chains = parent_class_chains

    def _fix_xcui_type(self, s):
        """修复 XCUI 元素类型名称，自动添加 XCUIElementType 前缀。

        Args:
            s: 包含元素类型的字符串（如 xpath 或 classChain），可为 None。

        Returns:
            修复后的字符串，如果输入为 None 则返回 None。
        """
        if s is None:
            return
        re_element = '|'.join(xcui_element_types.ELEMENTS)
        return re.sub(r'/(' + re_element + ')', '/XCUIElementType\g<1>', s)

    def _wdasearch(self, using, value):
        """
        Returns:
            element_ids (list(string)): example ['id1', 'id2']

        HTTP example response:
        [
            {"ELEMENT": "E2FF5B2A-DBDF-4E67-9179-91609480D80A"},
            {"ELEMENT": "597B1A1E-70B9-4CBE-ACAD-40943B0A6034"}
        ]
        """
        element_ids = []
        try:
            if self._num == 1:
                for k, v in self._client.session_request(RequestMethod.POST, "/element", {
                    "using": using,
                    "value": value
                })["value"].items():
                    # print(k, v)
                    if k == "ELEMENT":
                        element_ids.append(v)
            else:
                res = self._client.session_request(RequestMethod.POST, "/elements", {
                    "using": using,
                    "value": value
                })['value']
                for e in res:
                    element_ids.append(e['ELEMENT'])
        except Exception as e:
            pass
            # print(e)

        return element_ids

    # @retry.retry(WDAStaleElementReferenceError, tries=2, delay=.5, jitter=.2)
    def find_element_ids(self):
        """根据选择器条件查找匹配的元素 ID 列表。

        按优先级依次使用 id、predicate、xpath、classChain 或自动生成的
        class chain 进行查询。

        Returns:
            匹配元素的 ID 字符串列表。
        """
        elems = []
        if self._id:
            return self._wdasearch('id', self._id)
        if self._predicate:
            return self._wdasearch('predicate string', self._predicate)
        if self._xpath:
            # print('xpath', self._xpath)
            return self._wdasearch('xpath', self._xpath)
        if self._class_chain:
            return self._wdasearch('class chain', self._class_chain)

        chain = '**' + ''.join(
            self._parent_class_chains) + self._gen_class_chain()
        if DEBUG:
            print('CHAIN:', chain)
        return self._wdasearch('class chain', chain)

    def find_all(self, num: int = -1):
        """查找所有匹配的 UI 元素。

        Args:
            num: 查找数量限制。-1 表示查找所有，1 表示只查找第一个。

        Returns:
            匹配的 Element 对象列表。
        """
        self._num = num
        ids = self.find_element_ids()
        nodes = []
        for n_id in ids:
            nodes.append(Element(self._client, n_id))

        # print(ids)
        return nodes

    def _gen_class_chain(self):
        """根据选择器属性生成 WDA class chain 查询字符串。

        将选择器中设置的各种过滤条件（名称、标签、值、可见性等）
        组合为 WDA 可识别的 class chain 表达式。

        Returns:
            生成的 class chain 查询字符串。
        """
        # just return if aleady exists predicate
        if self._predicate:
            return '/XCUIElementTypeAny[`' + self._predicate + '`]'
        qs = []
        if self._name:
            qs.append("name == '%s'" % self._name)
        if self._name_part:
            qs.append("name CONTAINS %r" % self._name_part)
        if self._name_regex:
            qs.append("name MATCHES %r" % self._name_regex)
        if self._label:
            qs.append("label == '%s'" % self._label)
        if self._label_part:
            qs.append("label CONTAINS '%s'" % self._label_part)
        if self._value:
            qs.append("value == '%s'" % self._value)
        if self._value_part:
            qs.append("value CONTAINS '%s'" % self._value_part)
        if self._visible is not None:
            qs.append("visible == %s" % 'true' if self._visible else 'visible == false')
        if self._enabled is not None:
            qs.append("enabled == %s" % 'true' if self._enabled else 'enabled == false')
        predicate = ' AND '.join(qs)
        chain = '/' + (self._class_name or 'XCUIElementTypeAny')
        if predicate:
            chain = chain + '[`' + predicate + '`]'
        if self._index:
            chain = chain + '[%d]' % self._index

        return chain


class Element(object):
    """iOS UI 元素操作类。

    表示页面中的一个具体 UI 元素，提供属性读取（文本、标签、类名等）
    和交互操作（点击、滑动、输入文本等）功能。
    """

    def __init__(self, client: CommonClient, n_id: str):
        """初始化 UI 元素。

        Args:
            client: WDA 客户端实例，用于发送请求。
            n_id: 元素的唯一标识符 ID。
        """
        self._session = client
        self._id = n_id

    def __repr__(self):
        """返回元素的字符串表示。

        Returns:
            包含元素 ID 的格式化字符串。
        """
        return '<Node(id="{}")>'.format(self._id)

    def http(self, method, url, data=None):
        """发送 HTTP 请求到 WDA 会话。

        Args:
            method: HTTP 请求方法。
            url: API 路径。
            data: 请求体字典，可选。

        Returns:
            WDA 返回的 JSON 响应字典。
        """
        return self._session.session_request(method, url, data)

    def _req(self, method, url, data=None):
        """发送元素级别的请求。

        自动在 URL 前添加 /element/{element_id} 前缀。

        Args:
            method: HTTP 请求方法。
            url: 元素 API 路径后缀。
            data: 请求体字典，可选。

        Returns:
            WDA 返回的 JSON 响应字典。
        """
        return self.http(method, '/element/' + self._id + url, data)

    def _wda_req(self, method, url, data=None):
        """发送 WDA 扩展的元素级别请求。

        自动在 URL 前添加 /wda/element/{element_id} 前缀。

        Args:
            method: HTTP 请求方法。
            url: WDA 元素 API 路径后缀。
            data: 请求体字典，可选。

        Returns:
            WDA 返回的 JSON 响应字典。
        """
        return self.http(method, '/wda/element/' + self._id + url, data)

    def _prop(self, key):
        """获取元素的标准属性值。

        Args:
            key: 属性路径，如 'text'、'attribute/label' 等。

        Returns:
            属性值。
        """
        data = self._req(RequestMethod.GET, '/' + key.lstrip('/'))
        return data['value']

    def _wda_prop(self, key):
        """获取元素的 WDA 扩展属性值。

        Args:
            key: WDA 扩展属性名，如 'accessible'、'accessibilityContainer'。

        Returns:
            属性值。
        """
        ret = self.http(RequestMethod.GET, '/wda/element/%s/%s' % (self._id, key))['value']
        return ret

    @property
    def info(self):
        """获取元素的完整信息字典。

        Returns:
            包含 id、label、value、text、name、className、enabled、
            displayed、visible、accessible、accessibilityContainer 的字典。
        """
        return {
            "id": self._id,
            "label": self.label,
            "value": self.value,
            "text": self.text,
            "name": self.name,
            "className": self.className,
            "enabled": self.enabled,
            "displayed": self.displayed,
            "visible": self.visible,
            "accessible": self.accessible,
            "accessibilityContainer": self.accessibility_container
        }

    @property
    def id(self):
        """获取元素的唯一标识符。

        Returns:
            元素 ID 字符串。
        """
        return self._id

    @property
    def label(self):
        """获取元素的 label 属性。

        Returns:
            元素的 label 文本。
        """
        return self._prop('attribute/label')

    @property
    def className(self):
        """获取元素的类名（如 XCUIElementTypeButton）。

        Returns:
            元素类名字符串。
        """
        return self._prop('attribute/type')

    @property
    def type(self):
        """获取元素的类型，与 className 相同。

        Returns:
            元素类型字符串。
        """
        return self._prop('attribute/type')

    @property
    def index(self):
        """获取元素在同级中的索引位置。

        Returns:
            元素索引值。
        """
        return self._prop('attribute/index')

    @property
    def text(self):
        """获取元素的文本内容。

        Returns:
            元素文本字符串。
        """
        return self._prop('text')

    @property
    def name(self):
        """获取元素的 name 属性。

        Returns:
            元素的 name 文本。
        """
        return self._prop('attribute/name')

    @property
    def displayed(self):
        """获取元素是否在屏幕上显示。

        Returns:
            是否显示的布尔值。
        """
        return self._prop("displayed")

    @property
    def enabled(self):
        """获取元素是否可交互。

        Returns:
            是否可用的布尔值。
        """
        return self._prop('enabled')

    @property
    def accessible(self):
        """获取元素是否支持无障碍访问。

        Returns:
            是否支持无障碍的布尔值。
        """
        return self._wda_prop("accessible")

    @property
    def accessibility_container(self):
        """获取元素是否为无障碍容器。

        Returns:
            是否为无障碍容器的布尔值。
        """
        return self._wda_prop('accessibilityContainer')

    @property
    def value(self):
        """获取元素的 value 属性。

        Returns:
            元素的 value 值。
        """
        return self._prop('attribute/value')

    @property
    def visible(self):
        """获取元素是否可见。

        Returns:
            是否可见的布尔值。
        """
        return self._prop('attribute/visible')

    @property
    def bounds(self) -> Rect:
        """获取元素的边界矩形（逻辑坐标，不含缩放）。

        Returns:
            元素的矩形区域 Rect 对象。
        """
        value = self._prop('rect')
        # scale = self._session.scale
        x, y = value['x'], value['y']
        w, h = value['width'], value['height']
        return Rect(x, y, w, h)

    @property
    def rect(self) -> Rect:
        """获取元素的边界矩形（物理像素坐标，已乘以缩放比例）。

        Returns:
            经过缩放计算后的矩形区域 Rect 对象。
        """
        value = self._prop('rect')
        scale = self._session.scale
        x, y = value['x'], value['y']
        w, h = value['width'], value['height']
        return Rect(x * scale, y * scale, w * scale, h * scale)

    # @property
    def scale(self) -> int:
        """获取屏幕缩放比例。

        Returns:
            屏幕缩放倍数（如 Retina 屏为 2 或 3）。
        """
        return self._session.scale

    # operations
    def tap(self):
        """点击元素。

        Returns:
            WDA 请求的响应结果。
        """
        return self._req(RequestMethod.POST, '/click')

    def click(self, dur: int = 0.02):
        """通过获取元素中心坐标执行点击，比 tap 稍慢但更可靠。

        适用于不可见元素无法直接 tap 的场景。

        Args:
            dur: 点击持续时间（秒），默认 0.02。

        Returns:
            当前 Element 实例，支持链式调用。
        """
        # Some one reported, invisible element can not click
        # So here, git position and then do tap
        x, y = self.rect.center
        x = int(x / self._session.scale)
        y = int(y / self._session.scale)
        # print(x, y)
        self._session.tap(x, y, dur)
        # return self.tap()
        return self

    def tap_hold(self, duration=1000):
        """长按元素。

        Args:
            duration: 长按持续时间（毫秒），默认 1000ms。内部会自动转换为秒。

        Returns:
            当前 Element 实例，支持链式调用。
        """

        duration = duration / 1000

        self._wda_req(RequestMethod.POST, '/touchAndHold', {'duration': duration})
        return self

    def scroll(self, direction='visible', distance=1.0):
        """滚动元素。

        Args:
            direction: 滚动方向，可选值为 "visible"、"up"、"down"、"left"、"right"。
                设为 "visible" 时滚动直到元素可见。
            distance: 滚动距离倍数，仅在方向不为 "visible" 时生效。
                1.0 表示滚动元素自身宽度或高度的距离。

        Returns:
            当前 Element 实例，支持链式调用。

        Raises:
            ValueError: 当传入无效方向值时抛出。
        """
        if direction == 'visible':
            self._wda_req(RequestMethod.POST, '/scroll', {'toVisible': True})
        elif direction in ['up', 'down', 'left', 'right']:
            self._wda_req(RequestMethod.POST, '/scroll', {
                'direction': direction,
                'distance': distance
            })
        else:
            raise ValueError("Invalid direction")
        return self

    # TvOS
    # @property
    # def focused(self):
    #
    # def focuse(self):

    def pickerwheel_select(self):
        """通过滚轮选择器选择值（尚未实现）。

        Raises:
            NotImplementedError: 该方法尚未实现。
        """
        # Ref: https://github.com/appium/WebDriverAgent/blob/e5d46a85fbdb22e401d396cedf0b5a9bbc995084/WebDriverAgentLib/Commands/FBElementCommands.m#L88
        raise NotImplementedError()

    def pinch(self, scale, velocity):
        """在元素上执行捏合手势。

        Args:
            scale: 缩放比例，必须大于 0。小于 1 为缩小，大于 1 为放大。
            velocity: 缩放速度。缩小时必须为负值，放大时为正值。
                示例：缩小 -> scale=0.5, velocity=-1；放大 -> scale=2.0, velocity=1。

        Returns:
            WDA 请求的响应结果。
        """
        data = {'scale': scale, 'velocity': velocity}
        return self._wda_req('post', '/pinch', data)

    def set_text(self, value):
        """设置元素的文本内容。

        Args:
            value: 要输入的文本内容。

        Returns:
            WDA 请求的响应结果。
        """
        return self._req(RequestMethod.POST, '/value', {'value': value})

    def clear_text(self):
        """清除元素的文本内容。

        Returns:
            WDA 请求的响应结果。
        """
        return self._req(RequestMethod.POST, '/clear')

    # def child(self, **kwargs):
    #     return Selector(self.__base_url, self._id, **kwargs)

    # todo lot of other operations
    # tap_hold

    def selected(self):
        """获取元素是否处于选中状态。

        Returns:
            元素是否被选中的布尔值。
        """

        return self._req(RequestMethod.GET, '/selected').value
