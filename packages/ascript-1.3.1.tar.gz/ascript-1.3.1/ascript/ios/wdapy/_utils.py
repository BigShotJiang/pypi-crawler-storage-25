# coding: utf-8
#

from __future__ import annotations

import dataclasses
import json


def camel_to_snake(s: str) -> str:
    """将驼峰命名字符串转换为下划线命名。

    Args:
        s: 驼峰命名的字符串，例如 "sessionId"。

    Returns:
        转换后的下划线命名字符串，例如 "session_id"。
    """
    return ''.join(['_'+c.lower() if c.isupper() else c for c in s]).lstrip("_")


def omit_empty(d: list | dict | dataclasses.dataclass | None):
    """递归移除数据结构中值为 None 的项。

    支持对列表、字典和 dataclass 实例进行递归处理。

    Args:
        d: 需要处理的数据，可以是列表、字典、dataclass 实例或 None。

    Returns:
        移除了 None 值后的数据结构，类型与输入一致。
    """
    if isinstance(d, list):
        return [omit_empty(v) for v in d]
    elif isinstance(d, dict):
        return {k: omit_empty(v) for k, v in d.items() if v is not None}
    elif dataclasses.is_dataclass(d):
        return omit_empty(dataclasses.asdict(d))
    else:
        return d


def json_dumps_omit_empty(data: dict) -> str:
    """将字典转换为 JSON 字符串，自动忽略值为 None 的项。

    Args:
        data: 需要序列化的字典。

    Returns:
        移除了 None 值后的 JSON 字符串。
    """
    return json.dumps(omit_empty(data))