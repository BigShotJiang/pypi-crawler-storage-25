# coding: utf-8
#

import enum

NAME = "wdapy"
DEFAULT_WDA_URL = "http://localhost:8100"
DEFAULT_HTTP_TIMEOUT = 120


class RequestMethod(str, enum.Enum):
    """HTTP 请求方法枚举类。

    用于定义 WDA 通信中使用的 HTTP 请求方法。
    """
    GET = "GET"
    POST = "POST"


GET = RequestMethod.GET
POST = RequestMethod.POST


class AppState(enum.IntEnum):
    """应用运行状态枚举类。

    表示 iOS 应用的当前运行状态。
    """
    STOPPED = 1
    BACKGROUND = 2
    RUNNING = 4


class Orientation(str, enum.Enum):
    """设备屏幕方向枚举类。

    表示 iOS 设备的屏幕旋转方向。
    """
    LANDSCAPE = 'LANDSCAPE'
    PORTRAIT = 'PORTRAIT'
    LANDSCAPE_RIGHT = 'UIA_DEVICE_ORIENTATION_LANDSCAPERIGHT'
    PORTRAIT_UPSIDEDOWN = 'UIA_DEVICE_ORIENTATION_PORTRAIT_UPSIDEDOWN'


class Keycode(str, enum.Enum):
    """物理按键键码枚举类。

    表示 iOS 设备上的物理按键，部分按键仅支持 press_duration 操作。
    """
    HOME = "home"
    VOLUME_UP = "volumeUp"
    VOLUME_DOWN = "volumeDown"

    # allow only for press_duration
    POWER = "power"
    SNAPSHOT = "snapshot"
    POWER_PLUS_HOME = "power_plus_home"


class GestureAction(str, enum.Enum):
    """手势动作枚举类。

    定义触摸手势序列中可用的动作类型。
    """
    TAP = "tap"
    PRESS = "press"
    MOVE_TO = "moveTo"
    WAIT = "wait"
    RELEASE = "release"


class BatteryState(enum.IntEnum):
    """电池状态枚举类。

    表示 iOS 设备的电池充电状态。
    """
    Unknown = 0
    Unplugged = 1
    Charging = 2
    Full = 3
