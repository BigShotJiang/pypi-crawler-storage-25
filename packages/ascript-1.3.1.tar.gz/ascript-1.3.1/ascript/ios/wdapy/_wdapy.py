# coding: utf-8

from __future__ import annotations

import atexit
import base64
import io
import logging
import math
import queue
import subprocess
import sys
import threading
import time
import typing
from functools import cached_property
from urllib.parse import urlencode

from PIL import Image
from ._alert import Alert
from ._base import BaseClient
from ._proto import *
from ._types import *
from .exceptions import *
from ._utils import omit_empty

logger = logging.getLogger(__name__)


class CommonClient(BaseClient):
    """WDA 通用客户端类。

    继承 BaseClient，提供 iOS 设备的高级操作接口，包括应用管理、
    屏幕交互、截图、设备信息查询、手势操作等功能。
    """

    def __init__(self, wda_url: str):
        """初始化通用客户端。

        Args:
            wda_url: WebDriverAgent 服务的 URL 地址。
        """
        super().__init__(wda_url)
        self.__ui_size = None
        self.__debug = False

    @property
    def debug(self) -> bool:
        """获取调试模式状态。

        Returns:
            是否开启调试模式。
        """
        return self.__debug

    @debug.setter
    def debug(self, v: bool):
        """设置调试模式。

        Args:
            v: True 开启调试，False 关闭。
        """
        self.__debug = v

    def app_start(self, bundle_id: str, arguments: typing.List[str] = [], environment: typing.Dict[str, str] = {}):
        """启动指定应用。

        Args:
            bundle_id: 应用的 Bundle ID。
            arguments: 启动参数列表。
            environment: 环境变量字典。
        """
        self.session_request(POST, "/wda/apps/launch", {
            "bundleId": bundle_id,
            "arguments": arguments,
            "environment": environment,
        })

    def app_terminate(self, bundle_id: str):
        """终止指定应用。

        Args:
            bundle_id: 应用的 Bundle ID。
        """
        self.session_request(POST, "/wda/apps/terminate", {
            "bundleId": bundle_id
        })

    def app_state(self, bundle_id: str) -> AppState:
        """获取指定应用的运行状态。

        Args:
            bundle_id: 应用的 Bundle ID。

        Returns:
            应用当前的运行状态枚举值。
        """
        value = self.session_request(POST, "/wda/apps/state", {
            "bundleId": bundle_id
        })["value"]
        return AppState(value)

    def app_current(self) -> AppInfo:
        """获取当前前台应用的信息。

        会先解锁设备并确保会话存在。

        Returns:
            当前活跃应用的 AppInfo 对象。
        """
        self.unlock()
        st = self.status()
        if st.session_id is None:
            self.session()
        data = self.request(GET, "/wda/activeAppInfo")
        value = data['value']
        return AppInfo.value_of(value)

    def app_list(self) -> AppList:
        """获取设备上运行中的应用列表。

        Returns:
            应用列表的 AppList 对象。
        """
        value = self.session_request(GET, "/wda/apps/list")
        print(value)
        return AppList.value_of(value)

    def deactivate(self, duration: float):
        """将当前应用置于后台指定时间后恢复。

        Args:
            duration: 应用在后台停留的时间（秒）。
        """
        self.session_request(POST, "/wda/deactivateApp", {
            "duration": duration
        })

    @cached_property
    def alert(self) -> Alert:
        """获取弹窗操作实例（延迟创建，仅创建一次）。

        Returns:
            Alert 弹窗操作实例。
        """
        return Alert(self)

    def sourcetree(self, max_depth: int = 0) -> SourceTree:
        """获取页面 UI 层级源码树对象。

        Args:
            max_depth: 最大遍历深度，0 表示不限制。

        Returns:
            包含页面源码的 SourceTree 对象。
        """
        if max_depth > 0:
            data = self.request(GET, "/source", {
                "maxDepth": max_depth
            })
        else:
            data = self.request(GET, "/source")
        return SourceTree.value_of(data)

    def souce_config(self, excluded_attributes: str = None, other_type_filter: int = 1, timeout: int = 60):
        """配置页面源码获取的参数。

        Args:
            excluded_attributes: 要排除的属性名，多个用逗号分隔。
            other_type_filter: 类型过滤选项，1 为不过滤（默认），2 为过滤掉。
            timeout: 超时时间（秒），默认 60。

        Returns:
            WDA 请求的响应结果。
        """
        # otherTypefilter值：1:是不过滤默认, 2: 是过滤掉
        payload = {"otherTypefilter": other_type_filter, "timeout": timeout}
        if excluded_attributes is not None and len(excluded_attributes) > 0:
            payload["excludedAttributes"] = excluded_attributes

        query_string = urlencode(payload)

        print(query_string)

        data = self.request(GET, f"/setUpNodeParams?{query_string}")
        return data

    def get_souce_config(self):
        """获取当前页面源码获取的配置参数。

        Returns:
            当前配置参数字典。
        """
        data = self.request(GET, f"/getUpNodeParams")
        return data['value']

    def source(self, max_depth: int = 0) -> str:
        """获取页面 UI 层级的 XML 源码字符串。

        Args:
            max_depth: 最大遍历深度，0 表示使用默认深度 50。

        Returns:
            页面 UI 层级的 XML 字符串。
        """

        # print("source")

        if max_depth > 0:
            try:
                print("max", max_depth)
                data = self.request(GET, f"/source?maxDepth={max_depth}")
            except Exception as e:
                print(str(e))
        else:
            data = self.request(GET, "/source?maxDepth=50")

        return data['value']

    def open_url(self, url: str):
        """在设备上打开指定 URL。

        Args:
            url: 要打开的 URL 地址。
        """
        self.session_request(POST, "/url", {
            "url": url
        })

    def set_clipboard(self, content: str, content_type="plaintext"):
        """设置设备剪贴板内容。

        注意：仅在 WDA 应用处于前台时有效。

        Args:
            content: 要设置的剪贴板文本内容。
            content_type: 内容类型，默认为 "plaintext"。
        """
        self.session_request(POST, "/wda/setPasteboard", {
            "content": base64.b64encode(content.encode()).decode(),
            "contentType": content_type
        })

    def get_clipboard(self, content_type="plaintext") -> str:
        """获取设备剪贴板内容。

        Args:
            content_type: 内容类型，默认为 "plaintext"。

        Returns:
            剪贴板中的文本内容。
        """
        data = self.session_request(POST, "/wda/getPasteboard", {
            "contentType": content_type
        })
        return base64.b64decode(data['value']).decode('utf-8')

    def appium_settings(self, kwargs: dict = None) -> dict:
        """获取或设置 Appium 配置项。

        Args:
            kwargs: 要设置的配置字典。为 None 时返回当前配置。

        Returns:
            当前或更新后的 Appium 配置字典。
        """
        if kwargs is None:
            return self.session_request(GET, "/appium/settings")["value"]
        payload = {"settings": kwargs}
        return self.session_request(POST, "/appium/settings", payload)["value"]

    def is_locked(self) -> bool:
        """检查设备是否处于锁屏状态。

        Returns:
            锁屏状态返回 True，未锁屏返回 False。
        """
        return self.request(GET, "/wda/locked")["value"]

    def unlock(self):
        """解锁设备屏幕。"""
        self.request(POST, "/wda/unlock")

    def lock(self):
        """锁定设备屏幕。"""
        self.request(POST, "/wda/lock")

    def homescreen(self):
        """返回主屏幕。"""
        self.request(POST, "/wda/homescreen")

    def shutdown(self):
        """关闭 WDA 服务。"""
        self.request(GET, "/wda/shutdown")

    def get_orientation(self) -> Orientation:
        """获取设备当前的屏幕方向。

        Returns:
            当前屏幕方向的 Orientation 枚举值。
        """
        value = self.session_request(GET, '/orientation')['value']
        return Orientation(value)

    def window_size(self, node=False) -> typing.Tuple[int, int]:
        """获取屏幕窗口尺寸。

        Args:
            node: 为 True 时直接通过 WDA 接口获取逻辑尺寸；
                为 False 时通过截图获取物理像素尺寸（有缓存优化）。

        Returns:
            (宽度, 高度) 的元组。
        """

        if node:
            data = self.session_request(GET, "/window/size")
            return data['value']['width'], data['value']['height']
        else:
            # 代码暂时保留，下面的方法为通过截图获取屏幕大小
            # 这里做了一点速度优化，跟进图像大小获取屏幕尺寸
            orientation = self.get_orientation()
            if self.__ui_size is None:
                # 这里认为screenshot返回的屏幕转向时正确的
                pixel_width, pixel_height = self.screenshot().size
                w, h = pixel_width, pixel_height
                if orientation == Orientation.PORTRAIT:
                    self.__ui_size = (w, h)
                else:
                    self.__ui_size = (h, w)

            if orientation == Orientation.LANDSCAPE:
                return self.__ui_size[::-1]
            else:
                return self.__ui_size

    def send_keys(self, value: str):
        """向当前焦点元素输入文本。

        Args:
            value: 要输入的文本字符串。
        """
        self.session_request(POST, "/wda/keys", {"value": list(value)})

    def _percent2pos(self, x, y, window_size=None):
        """将百分比坐标转换为像素坐标。

        当 x 或 y 为浮点数时，视为百分比值（0.0~1.0），
        自动乘以窗口尺寸转换为像素坐标。

        Args:
            x: x 坐标，整数为像素值，浮点数为百分比。
            y: y 坐标，整数为像素值，浮点数为百分比。
            window_size: 窗口尺寸元组 (宽, 高)，为 None 时自动获取。

        Returns:
            转换后的 (x, y) 像素坐标元组。
        """
        if any(isinstance(v, float) for v in [x, y]):
            w, h = window_size or self.window_size()
            x = int(x * w) if isinstance(x, float) else x
            y = int(y * h) if isinstance(y, float) else y
            assert w >= x >= 0
            assert h >= y >= 0
        return (x, y)

    def tap(self, x: int, y: int, dur=0.02):
        """在指定坐标执行点击操作。

        Args:
            x: 点击位置的 x 坐标。
            y: 点击位置的 y 坐标。
            dur: 点击持续时间（秒），默认 0.02。
        """
        try:
            self.session_request(POST, "/wda/tap", {"x": x, "y": y, "duration": dur})
        except RequestError:
            self.session_request(POST, "/wda/tap/0", {"x": x, "y": y, "duration": dur})

    def click(self, x, y, duration: typing.Optional[float] = None):
        """在指定坐标执行点击或长按操作。

        整合了 tap 和 touch_and_hold 功能。

        Args:
            x: 点击位置的 x 坐标，支持整数（像素）或浮点数（百分比）。
            y: 点击位置的 y 坐标，支持整数（像素）或浮点数（百分比）。
            duration: 长按持续时间（秒），为 None 时执行普通点击。
        """
        # x, y = self._percent2pos(x, y)
        if duration:
            return self.touch_and_hold(x, y, duration)
        return self.touch_and_hold(x, y)

    def double_tap(self, x, y):
        """在指定坐标执行双击操作。

        Args:
            x: 双击位置的 x 坐标，支持整数（像素）或浮点数（百分比）。
            y: 双击位置的 y 坐标，支持整数（像素）或浮点数（百分比）。

        Returns:
            WDA 请求的响应结果。
        """
        # x, y = self._percent2pos(x, y)

        return self.session_request(POST, "/wda/doubleTap", {"x": x, "y": y})

    def calculate_distance(self, l, t, r, b):
        """计算两点之间的欧几里得距离。

        Args:
            l: 起点 x 坐标。
            t: 起点 y 坐标。
            r: 终点 x 坐标。
            b: 终点 y 坐标。

        Returns:
            两点之间的距离（浮点数）。
        """
        # 定义两个点
        x1, y1 = l, t
        x2, y2 = r, b

        # 计算距离
        distance = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)

        return distance

    def touch_and_swipe(self, from_x: int,
                        from_y: int,
                        to_x: int,
                        to_y: int,
                        touch_down_duration: int = 1,
                        touch_move_duration: int = 1,
                        touch_up_duration: int = 1):
        """执行按下并滑动手势，支持自定义各阶段时长。

        Args:
            from_x: 起始点 x 坐标。
            from_y: 起始点 y 坐标。
            to_x: 终点 x 坐标。
            to_y: 终点 y 坐标。
            touch_down_duration: 按下阶段持续时间（秒），默认 1。
            touch_move_duration: 滑动阶段持续时间（秒），默认 1。
            touch_up_duration: 抬起阶段持续时间（秒），默认 1。
        """

        speed = self.calculate_distance(from_x, from_y, to_x, to_y) / touch_move_duration

        pyload = {
            "fromX": from_x,
            "fromY": from_y,
            "toX": to_x,
            "toY": to_y,
            "pressDuration": touch_down_duration,
            "velocity": speed,
            "holdDuration": touch_up_duration}

        self.session_request(POST, "/wda/pressAndDragWithVelocity", pyload)

    def touch_and_hold(self, x: int, y: int, duration: float = 0.02):
        """在指定坐标执行长按操作。

        Args:
            x: 长按位置的 x 坐标。
            y: 长按位置的 y 坐标。
            duration: 长按持续时间（秒），默认 0.02。
        """
        self.session_request(POST, "/wda/touchAndHold", {"x": x, "y": y, "duration": duration})

    def swipe(self,
              from_x: int,
              from_y: int,
              to_x: int,
              to_y: int,
              duration: float = 0.05):
        """执行滑动手势。

        Args:
            from_x: 起始点 x 坐标。
            from_y: 起始点 y 坐标。
            to_x: 终点 x 坐标。
            to_y: 终点 y 坐标。
            duration: 滑动持续时间（秒），默认 0.05。
        """
        payload = {
            "fromX": from_x,
            "fromY": from_y,
            "toX": to_x,
            "toY": to_y,
            "duration": duration}
        self.session_request(POST, "/wda/dragfromtoforduration", payload)

    def press(self, name: Keycode):
        """按下物理按键。

        Args:
            name: 按键的 Keycode 枚举值。
        """
        payload = {
            "name": name
        }
        self.session_request(POST, "/wda/pressButton", payload)

    def press_duration(self, name: Keycode, duration: float):
        """长按物理按键指定时长。

        通过 HID 事件模拟长按操作，支持 home、volumeup、volumedown、
        power、snapshot、power_plus_home 等按键。

        Args:
            name: 按键的 Keycode 枚举值。
            duration: 长按持续时间（秒）。

        Returns:
            WDA 请求的响应结果。

        Raises:
            ValueError: 当传入无效的按键名称时抛出。
        """
        hid_usages = {
            "home": 0x40,
            "volumeup": 0xE9,
            "volumedown": 0xEA,
            "power": 0x30,
            "snapshot": 0x65,
            "power_plus_home": 0x65
        }
        name = name.lower()
        if name not in hid_usages:
            raise ValueError("Invalid name:", name)
        hid_usages = hid_usages[name]
        payload = {
            "page": 0x0C,
            "usage": hid_usages,
            "duration": duration
        }
        return self.session_request(POST, "/wda/performIoHidEvent", payload)

    def touch_perform(self, gestures: list[Gesture]):
        """执行一组连续的触摸手势动作。

        将多个手势动作（tap、press、moveTo、wait、release）组合为
        完整的触摸操作序列。

        Args:
            gestures: Gesture 手势动作列表。
        """
        payload = {
            "actions": omit_empty(gestures)
        }
        self.session_request(POST, "/wda/touch/perform", payload)

    def volume_up(self):
        """增大设备音量。"""
        self.press(Keycode.VOLUME_UP)

    def volume_down(self):
        """减小设备音量。"""
        self.press(Keycode.VOLUME_DOWN)

    @cached_property
    def scale(self) -> int:
        """获取屏幕缩放比例（延迟计算，仅计算一次）。

        Returns:
            屏幕缩放倍数（如 Retina 屏为 2 或 3）。
        """
        # Response example
        # {"statusBarSize": {'width': 320, 'height': 20}, 'scale': 2}
        value = self.session_request(GET, "/wda/screen")['value']
        return value['scale']

    def status_barsize(self) -> StatusBarSize:
        """获取状态栏尺寸。

        Returns:
            包含宽度和高度的 StatusBarSize 对象。
        """
        # Response example
        # {"statusBarSize": {'width': 320, 'height': 20}, 'scale': 2}
        value = self.session_request(GET, "/wda/screen")['value']
        return StatusBarSize.value_of(value['statusBarSize'])

    def screenshot(self) -> Image.Image:
        """截取设备屏幕截图。

        Returns:
            RGB 格式的 PIL Image 对象。
        """
        t1 = time.time()
        # print("screenshot-截图开始", t1)
        value = self.request(GET, "/screenshot")["value"]
        # print("screenshot-截图完毕", time.time()-t1)
        raw_value = base64.b64decode(value)
        # print("screenshot-转码结束", time.time() - t1)
        buf = io.BytesIO(raw_value)
        im = Image.open(buf)
        return im.convert("RGB")

    def battery_info(self) -> BatteryInfo:
        """获取设备电池信息。

        Returns:
            包含电量和充电状态的 BatteryInfo 对象。
        """
        data = self.session_request(GET, "/wda/batteryInfo")["value"]
        return BatteryInfo.value_of(data)

    @property
    def info(self) -> DeviceInfo:
        """获取设备信息的快捷属性。

        Returns:
            DeviceInfo 设备信息对象。
        """
        return self.device_info()

    def device_info(self) -> DeviceInfo:
        """获取设备详细信息。

        Returns:
            包含时区、语言、型号、UUID 等的 DeviceInfo 对象。
        """
        data = self.session_request(GET, "/wda/device/info")["value"]
        return DeviceInfo.value_of(data)

    def keyboard_dismiss(self, key_names: typing.List[str] = ["前往", "发送", "Send", "Done", "Return"]):
        """关闭屏幕键盘。

        通过点击键盘上的指定按钮来关闭键盘。

        Args:
            key_names: 用于关闭键盘的按钮名称列表，按顺序尝试匹配。
        """
        self.session_request(POST, "/wda/keyboard/dismiss", {"keyNames": key_names})


class XCUITestRecover(Recover):
    """基于 tidevice 的 XCUITest 恢复处理器。

    当 WDA 服务异常时，通过 tidevice 工具重新启动 XCUITest 来恢复服务。
    """

    def __init__(self, udid: str):
        """初始化 XCUITest 恢复处理器。

        Args:
            udid: iOS 设备的唯一标识符。
        """
        self._udid = udid

    def recover(self) -> bool:
        """通过 tidevice 重新启动 WDA 服务。

        Returns:
            恢复成功返回 True，超时或失败返回 False。
        """
        logger.info("WDA is starting using tidevice ...")
        args = [sys.executable, '-m', 'tidevice', '-u', self._udid, 'xctest']
        p = subprocess.Popen(args,
                             stdin=subprocess.DEVNULL,
                             stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT,
                             start_new_session=True,
                             close_fds=True, encoding="utf-8")

        que = queue.Queue()
        threading.Thread(target=self.drain_process_output, args=(p, que), daemon=True).start()
        try:
            success = que.get(timeout=20)
            return success
        except queue.Empty:
            logger.warning("WDA launch timeout 20s")
            p.kill()
            return False

    def drain_process_output(self, p: subprocess.Popen, msg_queue: queue.Queue):
        """读取并处理 tidevice 子进程的输出。

        在后台线程中运行，监控 WDA 启动状态，将成功/失败结果
        放入消息队列。

        Args:
            p: tidevice 子进程对象。
            msg_queue: 用于传递启动结果的队列，True 为成功，False 为失败。
        """
        deadline = time.time() + 10
        lines = []
        while time.time() < deadline:
            if p.poll() is not None:
                logger.warning("xctest exited, output --.\n %s", "\n".join(lines))  # p.stdout.read())
                msg_queue.put(False)
                return
            line = p.stdout.readline().strip()
            lines.append(line)
            # logger.info("%s", line)
            if "WebDriverAgent start successfully" in line:
                logger.info("WDA started")
                msg_queue.put(True)
                break

        atexit.register(p.terminate)
        while p.stdout.read() != "":
            pass


class AppiumClient(CommonClient):
    """Appium WebDriverAgent 客户端。

    针对 Appium 版 WebDriverAgent 的客户端实现，
    提供完整的 iOS 自动化操作接口。

    参考: https://github.com/appium/WebDriverAgent
    """

    def __init__(self, wda_url: str = DEFAULT_WDA_URL):
        """初始化 Appium 客户端。

        Args:
            wda_url: WDA 服务地址，默认为 http://localhost:8100。
        """
        super().__init__(wda_url)


# def get_single_device_udid() -> str:
#     devices = list_devices()
#     if len(devices) == 0:
#         raise WDAException("No device connected")
#     if len(devices) > 1:
#         raise WDAException("More than one device connected")
#     return devices[0].serial


# class AppiumUSBClient(AppiumClient):
#     def __init__(self, udid: str = None, port: int = 8100):
#         if udid is None:
#             udid = get_single_device_udid()
#         super().__init__(f"http+usbmux://{udid}:{port}")
#         self.set_recover_handler(XCUITestRecover(udid))


class NanoClient(AppiumClient):
    """Nanoscopic WebDriverAgent 客户端。

    针对 nanoscopic 版 WebDriverAgent 的客户端实现，
    提供比标准 Appium 更快的 tap 和 swipe 操作。

    参考: https://github.com/nanoscopic/WebDriverAgent
    """

    def tap(self, x: int, y: int):
        """快速点击指定坐标（无需会话）。

        Args:
            x: 点击位置的 x 坐标。
            y: 点击位置的 y 坐标。
        """
        self.request(POST, "/wda/tap", {
            "x": x,
            "y": y,
        })

    def fast_swipe(self,
                   from_x: int,
                   from_y: int,
                   to_x: int,
                   to_y: int,
                   duration: float = .5):
        """快速滑动操作（无需会话）。

        注意：此方法无法模拟从左向右滑动返回的手势。

        Args:
            from_x: 起始点 x 坐标。
            from_y: 起始点 y 坐标。
            to_x: 终点 x 坐标。
            to_y: 终点 y 坐标。
            duration: 滑动持续时间（秒），默认 0.5。
        """
        self.request(POST, "/wda/swipe", {
            "x1": from_x,
            "y1": from_y,
            "x2": to_x,
            "y2": to_y,
            "delay": duration})

# class NanoUSBClient(NanoClient):
#     def __init__(self, udid: str = None, port: int = 8100):
#         if udid is None:
#             udid = get_single_device_udid()
#         super().__init__(f"http+usbmux://{udid}:{port}")
#         self.set_recover_handler(XCUITestRecover(udid))
