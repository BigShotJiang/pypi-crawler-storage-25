# coding: utf-8
#

class WDAException(Exception):
    """WDA 基础异常类。

    所有 WDA 相关异常的顶层基类。
    """
    pass


class RequestError(WDAException):
    """请求错误异常。

    当 WDA HTTP 请求失败时抛出。
    """
    pass


class WDASessionDoesNotExist(WDAException):
    """会话不存在异常。

    当尝试使用的 WDA 会话已过期或不存在时抛出。
    """


class ApiError(RequestError):
    """API 错误异常。

    当 WDA 返回带有格式化错误信息的响应时抛出。
    """


class WDAFatalError(RequestError):
    """不可恢复的致命错误异常。

    当 WDA 遇到无法通过重试恢复的错误时抛出。
    """



class WDAError(Exception):
    """WDA 错误基类。

    另一组 WDA 异常的基类，用于更细粒度的错误分类。
    """


class WDABadGateway(WDAError):
    """网关错误异常。

    当 WDA 代理返回 502 错误时抛出。
    """


class WDAEmptyResponseError(WDAError):
    """空响应异常。

    当 WDA 返回空的响应体时抛出。
    """


class WDAElementNotFoundError(WDAError):
    """元素未找到异常。

    当在页面中找不到指定的 UI 元素时抛出。
    """


class WDAElementNotDisappearError(WDAError):
    """元素未消失异常。

    当等待某个 UI 元素消失但超时后仍然存在时抛出。
    """


class WDARequestError(WDAError):
    """WDA 请求错误异常，包含状态码和错误值。

    用于封装 WDA 返回的带有状态码的错误响应。
    """
    def __init__(self, status, value):
        """初始化 WDA 请求错误。

        Args:
            status: HTTP 状态码。
            value: 错误响应的详细内容。
        """
        self.status = status
        self.value = value

    def __str__(self):
        """返回格式化的错误信息字符串。

        Returns:
            包含状态码和错误值的格式化字符串。
        """
        return 'WDARequestError(status=%d, value=%s)' % (self.status,
                                                         self.value)


class WDAKeyboardNotPresentError(WDARequestError):
    """键盘未显示异常。

    当尝试输入文字但屏幕键盘未显示时抛出。
    """
    # {'error': 'invalid element state',
    #  'message': 'Error Domain=com.facebook.WebDriverAgent Code=1
    #     "The on-screen keyboard must be present to send keys"
    #     UserInfo={NSLocalizedDescription=The on-screen keyboard must be present to send keys}',
    #  'traceback': ''})

    @staticmethod
    def check(v: dict):
        """检查响应是否为键盘未显示错误。

        Args:
            v: WDA 返回的错误响应字典。

        Returns:
            如果是键盘未显示错误则返回 True，否则返回 False。
        """
        if v.get('error') == 'invalid element state' and \
                'keyboard must be present to send keys' in v.get('message', ''):
            return True
        return False


class WDAInvalidSessionIdError(WDARequestError):
    """无效会话 ID 异常。

    当使用的会话 ID 无效或已过期时抛出。
    """
    @staticmethod
    def check(v: dict):
        """检查响应是否为无效会话 ID 错误。

        Args:
            v: WDA 返回的错误响应字典。

        Returns:
            如果是无效会话 ID 错误则返回 True，否则返回 False。
        """
        if v.get('error') == 'invalid session id':
            return True
        return False


class WDAPossiblyCrashedError(WDARequestError):
    """应用可能崩溃异常。

    当 WDA 报告被测应用可能已崩溃时抛出。
    """
    @staticmethod
    def check(v: dict):
        """检查响应是否为应用可能崩溃错误。

        Args:
            v: WDA 返回的错误响应字典。

        Returns:
            如果是应用可能崩溃错误则返回 True，否则返回 False。
        """
        if "possibly crashed" in v.get('message', ''):
            return True
        return False


class WDAUnknownError(WDARequestError):
    """未知错误异常。

    当 WDA 返回未知类型的错误时抛出。
    """
    @staticmethod
    def check(v: dict):
        """检查响应是否为未知错误。

        Args:
            v: WDA 返回的错误响应字典。

        Returns:
            如果是未知错误则返回 True，否则返回 False。
        """
        return v.get("error") == "unknown error"


class WDAStaleElementReferenceError(WDARequestError):
    """过期元素引用异常。

    当引用的 UI 元素已失效（例如页面已刷新）时抛出。
    """
    @staticmethod
    def check(v: dict):
        """检查响应是否为过期元素引用错误。

        Args:
            v: WDA 返回的错误响应字典。

        Returns:
            如果是过期元素引用错误则返回 True，否则返回 False。
        """
        return v.get("error") == 'stale element reference'
