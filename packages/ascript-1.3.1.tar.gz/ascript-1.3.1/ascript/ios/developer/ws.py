import json

from datetime import datetime
import sys
from SimpleWebSocketServer import SimpleWebSocketServer, WebSocket
from ascript.ios.developer.api import utils, oc


def listener():
    """启动标准输出和标准错误流的监听器。

    将 sys.stdout 和 sys.stderr 替换为自定义流对象，
    以便捕获所有输出并通过 WebSocket 发送给客户端，同时记录日志。
    """
    class CustomStream:
        """自定义流对象，用于拦截标准输出/标准错误并转发到 WebSocket 客户端。"""

        def __init__(self, target, name):
            """初始化自定义流。

            Args:
                target: 原始的目标流对象（如 sys.stdout 或 sys.stderr）。
                name: 流的类型标识，'i' 表示标准输出，'e' 表示标准错误。
            """
            self.target = target
            self.name = name

        def write(self, data):
            """写入数据到流中，并触发数据处理。

            Args:
                data: 要写入的数据内容。
            """
            #        self.target.write(data)  # 首先写入原始的目标流
            self.process_data(data)  # 然后处理数据

        def flush(self):
            """刷新目标流的缓冲区。"""
            self.target.flush()

        def process_data(self, data):
            """处理捕获的流数据，通过 WebSocket 发送并记录日志。

            Args:
                data: 捕获到的流数据内容。
            """
            # 这里可以添加对stderr或stdout数据的特定处理
            # 例如，你可以将stderr数据写入到一个日志文件中
            # print(f"{self.name}: {data.strip()}", file=sys.__stdout__)  # 仅作为示例，打印到原始stdout
            # str_msg = str(data).rstrip()
            str_msg = str(data)
            # if str_msg.endswith('\n'):
            #     str_msg = str_msg+"+"
            # else:
            #     str_msg = str_msg+"-"
            if len(str_msg) > 0:
                msg = {"msg": str_msg, "type": self.name, "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
                send_messages(json.dumps(msg))
                utils.recode_loger(str_msg, self.name)
                oc.on_log(msg)

                # 保存原始的stdout和stderr

    original_stdout = sys.stdout
    original_stderr = sys.stderr

    # 替换sys.stdout和sys.stderr
    sys.stdout = CustomStream(original_stdout, 'i')
    sys.stderr = CustomStream(original_stderr, 'e')


# clients = []

class SimpleEcho(WebSocket):
    """WebSocket 回声服务器处理类，用于管理 WebSocket 连接。"""

    def handleMessage(self):
        """处理接收到的 WebSocket 消息。"""
        # 回声（echo）消息
        pass

    def handleConnected(self):
        """处理新的 WebSocket 客户端连接事件。"""
        pass

    #        print(self.address, 'connected')

    def handleClose(self):
        """处理 WebSocket 客户端断开连接事件。"""
        print(self.address, 'closed')


server = None


def start_server():
    """启动 WebSocket 服务器。

    在 0.0.0.0:10102 上启动一个 WebSocket 服务器，
    使用 SimpleEcho 作为连接处理类。
    """
    global server
    # print("ws://0.0.0.0:9098")
    server = SimpleWebSocketServer('0.0.0.0', 10102, SimpleEcho)
    server.serveforever()


# 在子线程中启动WebSocket服务器
import threading


def send_messages(msg):
    """向所有已连接的 WebSocket 客户端广播消息。

    Args:
        msg: 要发送的消息内容（字符串格式）。
    """
    global server
    if server:
        #        print("共连接:",len(server.connections.values()))
        try:
            for client in server.connections.values():
                client.sendMessage(msg)
        except Exception as e:
            print(e)


def run_server_in_thread():
    """在当前线程中运行 WebSocket 服务器（作为子线程的入口函数）。"""
    start_server()


def run():
    """启动 WebSocket 服务器和日志监听器。

    分别在两个守护线程中启动 WebSocket 服务器和标准输出/错误流监听器，
    并将线程 ID 注册到 utils.threads 中以便管理。
    """
    # 在子线程中启动WebSocket服务器
    thread = threading.Thread(target=run_server_in_thread, daemon=True)
    thread.start()
    utils.threads.append(thread.ident)

    thread = threading.Thread(target=listener, daemon=True)
    thread.start()
    utils.threads.append(thread.ident)
