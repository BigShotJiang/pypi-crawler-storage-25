import os.path

import io
import re
import threading
import time

from PIL.Image import Image
from typing import List
# from ascript.ios.developer.api import utils
from rubicon.objc import ObjCClass
import ctypes
from rubicon.objc import api

from ascript.ios.developer.api import utils, sp_utils
from ascript.ios.wdapy import AppiumClient


# temp_img_path = os.path.join(utils.cache, "find_image_temp.jpg")


def find_all_template(image_source: Image, image_search: List[str], threshold=0.5, offset_xy=(0, 0),
                      rgb: bool = False,
                      max_res=0):
    """
            模版匹配
            给一张大图, 再给一组小图. 循环查找所有小图在大图中的位置.并返回结果数组

            :param image_source: 大图 Python 的PIL Image ,通过这个对象可以存储,可以格式化为bytearray,可以格式化成jpeg等.
            :param image_search: 小图列表
            :param threshold: 相似度不得低于这个值
            :param rgb:是否彩色查找? 一般在opencv中,模版匹配都是对图片进行二值化后查找.所以不区分颜色. 但是我们可以分别匹配 rgb 三个通道模版,来达到彩色图查找的目的.
            :param max_res: 匹配的最多结果数量. 如果是1 就是找到1个匹配结果就可以了,如果是0 就是找到所有

            :return [{
                        result:(x,y), #中心点坐标
                        rect:(l,t,r,b), # 图片在大图中的矩形顶点坐标
                        center_x:x, # 中心点坐标x
                        center_y:y, # 中心点坐标y
                        confidence:相似度
                    },...]
    """
    # 将图像转换为字节流
    image_byte_array = io.BytesIO()
    image_source.save(image_byte_array, format='PNG')
    image_byte_array = image_byte_array.getvalue()
    # print("=============image_source=========================")
    # print(image_source)
    # print("=============image_search=========================")
    # print(image_search)
    # 如果实在ios无法转换 字节流 可存储图片后,将地址传递给oc
    # image_source.save(temp_img_path, format='JPEG')

    # print("子图片", image_search)

    ASOpencvUtils = ObjCClass("ASOpencvUtils")

    def convert_byte_array_to_nsdata(byte_array):
        """将 Python 字节数组转换为 NSData 对象。

        Args:
            byte_array: Python 字节数组。

        Returns:
            NSData: OC 的 NSData 对象。
        """
        buffer = (ctypes.c_ubyte * len(byte_array))(*byte_array)
        return ObjCClass('NSData').dataWithBytes_length_(buffer, len(byte_array))

    # print("=======processSmallImageLocationInLargeImage======")

    # 大图data
    large_byte_array = image_byte_array
    # 小图数组集合
    smallOCData_arrays = image_search

    largeOCData = convert_byte_array_to_nsdata(large_byte_array)

    result = ASOpencvUtils.processSmallImageLocationInLargeImage_smallByteArray_(largeOCData, smallOCData_arrays)

    """
        (
                {
                confidence = "0.9939208626747131";
                h = 247;
                w = 176;
                x = 908;
                y = 1738;
            },
                {
                confidence = "0.9939208626747131";
                h = 247;
                w = 176;
                x = 908;
                y = 1738;
            }
        )
        """

    # print("=======result======")
    # print('执行结果', result)

    # print(type(result))

    res = []

    for r in result:
        r = api.py_from_ns(r)
        x = r['x'] + offset_xy[0]
        y = r['y'] + offset_xy[1]
        w = r['w']
        h = r['h']
        c = r['confidence']
        center_x = x + w / 2
        center_y = y + h / 2
        if c >= threshold:
            res.append({
                "result": (center_x, center_y),
                "rect": (x, y, x + w, y + h),
                "center_x": center_x,
                "center_y": center_y,
                "confidence": c
            })

    return res

    # pass


def find_sift(image_source: Image, image_search: List[str], threshold=0.5, offset_xy=(0, 0), rgb: bool = False,
              max_res: int = 0):
    """
        sift 全分辨率匹配
        给一张大图, 再给一组小图. 循环查找所有小图在大图中的位置.并返回结果数组

        :param image_source: 大图 Python 的PIL Image ,通过这个对象可以存储,可以格式化为bytearray,可以格式化成jpeg等.
        :param image_search: 小图列表,列表里是小图的路径
        :param threshold: 相似度不得低于这个值
        :param rgb:是否彩色查找? 一般在opencv中,模版匹配都是对图片进行二值化后查找.所以不区分颜色. 但是我们可以分别匹配 rgb 三个通道模版,来达到彩色图查找的目的.
        :param max_res: 匹配的最多结果数量. 如果是1 就是找到1个匹配结果就可以了,如果是0 就是找到所有

        :return [{
                    result:(x,y), #中心点坐标
                    rect:(l,t,r,b), # 图片在大图中的矩形顶点坐标
                    center_x:x, # 中心点坐标x
                    center_y:y, # 中心点坐标y
                    confidence:相似度
                },...]
    """
    # 将图像转换为字节流
    image_byte_array = io.BytesIO()
    image_source.save(image_byte_array, format='PNG')
    image_byte_array = image_byte_array.getvalue()

    ASOpencvUtils = ObjCClass("ASOpencvUtils")

    def convert_byte_array_to_nsdata(byte_array):
        """将 Python 字节数组转换为 NSData 对象。

        Args:
            byte_array: Python 字节数组。

        Returns:
            NSData: OC 的 NSData 对象。
        """
        buffer = (ctypes.c_ubyte * len(byte_array))(*byte_array)
        return ObjCClass('NSData').dataWithBytes_length_(buffer, len(byte_array))

    # print("=======findSiftWithImageSource_imageSearch_threshold_rgb_maxcnt_======")

    # 大图data
    large_byte_array = image_byte_array
    # 小图数组集合
    smallOCData_arrays = image_search

    largeOCData = convert_byte_array_to_nsdata(large_byte_array)

    result = ASOpencvUtils.findSiftWithImageSource_imageSearch_threshold_rgb_maxcnt_(largeOCData, smallOCData_arrays,
                                                                                     threshold, rgb, max_res)

    # print("=======result======")
    # print('执行结果', result)

    # print(type(result))

    res = []

    for r in result:
        r = api.py_from_ns(r)
        x = r['x'] + offset_xy[0]
        y = r['y'] + offset_xy[1]
        w = r['w']
        h = r['h']
        c = r['confidence']
        center_x = x + w / 2
        center_y = y + h / 2
        if c >= threshold:
            res.append({
                "result": (center_x, center_y),
                "rect": (x, y, x + w, y + h),
                "center_x": center_x,
                "center_y": center_y,
                "confidence": c
            })

    return res


def on_run_state_changed(statue: bool, args=None):
    """通知原生端程序运行状态发生变化。

    当程序启动或停止时，通过 OC 桥接通知 iOS 原生端更新状态。

    Args:
        statue: 运行状态，True 表示程序已启动，False 表示程序已停止。
        args: 运行参数字典（可选），包含 'online'（是否线上）和 'args'（详细参数）。
    """
    if statue:
        # print("程序开启了")
        if args['online']:
            # print("线上程序", args['args']['id'])
            app_id = args['args']['id']
        else:
            # print("本地工程", args['args']['name'])
            # 工程名称
            name = args['args']['name']

    else:
        # print("程序停止了")
        PythonBridge = ObjCClass("PythonBridge")
        PythonBridge.stopProgramRunningFromPython_('')


def on_log(log):
    """将日志消息转发到 iOS 原生端。

    Args:
        log: 日志字典，包含 'msg'（日志内容）、'type'（'i' 或 'e'）和 'time'（时间戳）。
    """
    msg = log['msg']  # 日志信息
    msg_type = log['type']  # i:info e:error
    msg_time = log['time']  # 时间
    PythonBridge = ObjCClass("PythonBridge")
    PythonBridge.onProgramRunningLogFromPython_type_time_(msg, msg_type, msg_time)


def on_efile(file_path, app_id):
    """通过 OC 桥接调用原生端解密加密文件。

    Args:
        file_path: 要解密的文件路径。
        app_id: 应用 ID，用作解密密钥。
    """
    # print('解密', file_path, app_id)
    ASAESUtils = ObjCClass("ASAESUtils")
    ASAESUtils.eoutF_appId_(file_path, app_id)


def on_ws_started():
    """WebSocket 服务启动完成的回调函数。"""
    print('ws启动了')


def ocr(mode: int, image_source: Image, threshold=0.2, offset_x=0, offset_y=0, pattern=None):
    """对图像执行 OCR 文字识别。

    通过 OC 桥接调用原生端的 PaddleOCR 引擎进行文字识别。

    Args:
        mode: OCR 模式。
        image_source: PIL Image 图像对象。
        threshold: 置信度阈值，低于此值的结果将被过滤，默认为 0.2。
        offset_x: 结果坐标的 X 轴偏移量，默认为 0。
        offset_y: 结果坐标的 Y 轴偏移量，默认为 0。
        pattern: 正则表达式模式，用于过滤识别文本，默认为 None。

    Returns:
        list: OCR 识别结果列表，每项包含 result、rect、center_x、center_y、confidence、text。
    """
    image_byte_array = io.BytesIO()
    image_source.save(image_byte_array, format='PNG')
    image_byte_array = image_byte_array.getvalue()

    def convert_byte_array_to_nsdata(byte_array):
        """将 Python 字节数组转换为 NSData 对象。

        Args:
            byte_array: Python 字节数组。

        Returns:
            NSData: OC 的 NSData 对象。
        """
        buffer = (ctypes.c_ubyte * len(byte_array))(*byte_array)
        return ObjCClass('NSData').dataWithBytes_length_(buffer, len(byte_array))

    largeOCData = convert_byte_array_to_nsdata(image_byte_array)
    ASPPOcrUtils = ObjCClass("ASPPOcrUtils")
    result = ASPPOcrUtils.ocrUtilsWithPP_(largeOCData)
    print('执行结果', result)

    res = []

    # print(offset_x, offset_y)

    for r in result:
        r = api.py_from_ns(r)
        x = r['x'] + offset_x
        y = r['y'] + offset_y
        w = r['w']
        h = r['h']
        txt = r['txt']
        c = r['confidence']
        center_x = x + w / 2
        center_y = y + h / 2
        match = True
        if pattern:
            if not re.search(pattern, txt):
                match = False

        if c >= threshold and match:
            res.append({
                "result": (center_x, center_y),
                "rect": (x, y, x + w, y + h),
                "center_x": center_x,
                "center_y": center_y,
                "confidence": c,
                "text": txt
            })
    return res


def set_clipboard(content: str):
    """设置系统剪贴板内容。

    Args:
        content: 要设置到剪贴板的文本内容。
    """
    PythonBridge = ObjCClass("PythonBridge")
    PythonBridge.setPasteboardContent_(content)


def get_clipboard() -> str:
    """获取系统剪贴板的文本内容。

    Returns:
        str: 剪贴板中的文本内容。
    """
    PythonBridge = ObjCClass("PythonBridge")
    return PythonBridge.textFromPasteboard()


# web ui 相关

def show_webui(uid: str, ui_path: str):
    """显示 Web UI 界面。

    Args:
        uid: UI 实例的唯一标识符。
        ui_path: Web 页面的 URL 路径。
    """
    PythonBridge = ObjCClass("PythonBridge")
    PythonBridge.showWebui_url_(uid, ui_path)


def is_webui_show(uid: str):
    """检查指定的 Web UI 是否正在显示。

    Args:
        uid: UI 实例的唯一标识符。
    """
    PythonBridge = ObjCClass("PythonBridge")
    is_show = PythonBridge.isWebUiShow_(uid)

    # print("===========is_webui_show=================")
    # print(f"uid: {uid}; is_show: {is_show}")


def close_webui(uid: str):
    """关闭指定的 Web UI 界面。

    Args:
        uid: UI 实例的唯一标识符。
    """
    PythonBridge = ObjCClass("PythonBridge")
    PythonBridge.closeWebui_(uid)


def tunner_py_call_jsfun(uid: str, js_fun: str):
    """从 Python 端调用 Web UI 中的 JavaScript 函数。

    Args:
        uid: UI 实例的唯一标识符。
        js_fun: 要执行的 JavaScript 函数调用字符串。
    """
    # print("call js _fun", js_fun)
    PythonBridge = ObjCClass("PythonBridge")
    PythonBridge.tunnerPyCallJsfun_jsFun_(uid, js_fun)


def tunner_js_call_py(uid, key, value):
    """处理从 JavaScript 端调用 Python 端的回调。

    Args:
        uid: UI 实例的唯一标识符。
        key: 回调的键名。
        value: 回调传递的值。
    """
    # print("===========tunner_js_call_py=================")
    # print(f"uid:{uid}; key:{key}; value:{value};")

    if uid in utils.ui_instance:
        tunner_fun = utils.ui_instance[uid].tunner
        if tunner_fun:
            tunner_fun(key, value)


def js_save_data(uid: str, key: str, value: str):
    """从 JavaScript 端保存键值对数据。

    Args:
        uid: UI 实例的唯一标识符。
        key: 数据键名。
        value: 数据值。
    """
    print("===========js_save_data=================")
    print(f"uid:{uid}; key:{key}; value:{value};")
    sp_utils.save(key, value)


def js_get_data(uid: str, key: str, value: str):
    """从 JavaScript 端获取存储的键值对数据。

    Args:
        uid: UI 实例的唯一标识符。
        key: 数据键名。
        value: 默认值。

    Returns:
        获取到的数据值。
    """
    print("===========js_get_data=================")
    print(f"uid:{uid}; key:{key}; value:{value};")
    res = sp_utils.get(key, value)
    print("返回结果", res)
    return res


# 错误信息输出控制台
def js_error_info(uid: str, error: str, js_fun: str):
    """处理 JavaScript 端的错误信息，输出到控制台。

    Args:
        uid: UI 实例的唯一标识符。
        error: 错误信息内容。
        js_fun: 发生错误的 JavaScript 函数名。
    """
    print("===========js_error_info=================")
    print(f"uid: {uid};\n js_fun: {js_fun};\n error: {error}; ")


def code_scanner(image: Image, offset_x=0, offset_y=0):
    """扫描图像中的条形码和二维码。

    Args:
        image: PIL Image 图像对象，传入 None 时返回空列表。
        offset_x: 结果坐标的 X 轴偏移量，默认为 0。
        offset_y: 结果坐标的 Y 轴偏移量，默认为 0。

    Returns:
        list: 扫描结果列表，每项包含 result、rect、center_x、center_y、value、type、format。
    """
    if image:
        image_byte_array = io.BytesIO()
        image.save(image_byte_array, format='PNG')
        image_byte_array = image_byte_array.getvalue()

        def convert_byte_array_to_nsdata(byte_array):
            """将 Python 字节数组转换为 NSData 对象。

            Args:
                byte_array: Python 字节数组。

            Returns:
                NSData: OC 的 NSData 对象。
            """
            buffer = (ctypes.c_ubyte * len(byte_array))(*byte_array)
            return ObjCClass('NSData').dataWithBytes_length_(buffer, len(byte_array))

        largeOCData = convert_byte_array_to_nsdata(image_byte_array)
        ASBarcodeScanningUtils = ObjCClass("ASBarcodeScanningUtils")
        result = ASBarcodeScanningUtils.scanImage_(largeOCData)
    else:
        # ASBarcodeScanningUtils = ObjCClass("ASBarcodeScanningUtils")
        # result = ASBarcodeScanningUtils.scanImage()
        return []
    # print('执行结果', result)

    res = []

    for r in result:
        r = api.py_from_ns(r)
        x = r['x'] + offset_x
        y = r['y'] + offset_y
        w = r['w']
        h = r['h']
        txt = r['txt']
        type = r['type']
        format = r['format']
        center_x = x + w / 2
        center_y = y + h / 2

        res.append({
            "result": (center_x, center_y),
            "rect": (x, y, x + w, y + h),
            "center_x": center_x,
            "center_y": center_y,
            "value": txt,
            "type": type,
            "format": format
        })

    # print('执行结果res:', res)
    return res


def start_scheme(scheme: str):
    """通过 URL Scheme 启动其他应用。

    Args:
        scheme: URL Scheme 字符串。
    """
    PythonBridge = ObjCClass("PythonBridge")
    PythonBridge.startScheme_(scheme)


def notify(msg: str, title: str = None, _id: str = "9096"):
    """发送系统本地通知。

    Args:
        msg: 通知消息内容。
        title: 通知标题，默认为 None。
        _id: 通知 ID，默认为 "9096"。
    """
    PythonBridge = ObjCClass("PythonBridge")
    PythonBridge.sendNotificationWithTitle_content_notificationId_(title, msg, _id)


def media_audio_play(path: str, volume=-1.):
    """播放音频文件。

    Args:
        path: 音频文件路径。
        volume: 音量大小，-1 表示使用系统默认音量。

    Returns:
        str: 播放实例的 ID。
    """
    PythonBridge = ObjCClass("PythonBridge")
    _id = PythonBridge.playMusic_volume_(path, volume)
    return str(_id)


def media_audio_stop(_id: str):
    """停止指定的音频播放。

    Args:
        _id: 播放实例的 ID。
    """
    PythonBridge = ObjCClass("PythonBridge")
    _id = PythonBridge.mediaVideoStop_(_id)


def media_audio_complete(_id: str):
    """音频播放完成的回调处理。

    当音频播放完毕时触发对应的回调函数。

    Args:
        _id: 播放实例的 ID。
    """
    # print(f"media_audio_complete:{_id}")
    if _id in utils.audio_pool:
        utils.audio_pool[_id]()


client = AppiumClient()


def oc_click(x, y):
    """在屏幕指定坐标执行点击操作。

    坐标会根据屏幕缩放比例进行转换。

    Args:
        x: 点击的 X 坐标（像素坐标）。
        y: 点击的 Y 坐标（像素坐标）。
    """
    # print("click----event", x, y)
    x = int(x / client.scale)
    y = int(y / client.scale)
    client.tap(x, y)
    time.sleep(0.5)


def oc_swipe(action: str):
    """在屏幕上执行滑动操作。

    Args:
        action: 滑动方向，可选值为 "left"、"right"、"top"、"bottom"。
    """
    w, h = client.window_size(True)
    left = w * 0.2
    right = w * 0.8
    top = h * 0.2
    bottom = h * 0.8
    if action == "left":
        client.swipe(int(right), int(h * 0.5), int(left), int(h * 0.5))
    elif action == "right":
        client.swipe(int(left), int(h * 0.5), int(right), int(h * 0.5))
    elif action == "top":
        client.swipe(int(w * 0.5), int(bottom), int(w * 0.5), int(top))
    elif action == "bottom":
        client.swipe(int(w * 0.5), int(top), int(w * 0.5), int(bottom))

    time.sleep(0.5)


def oc_key(key: str):
    """模拟按键操作。

    Args:
        key: 按键名称，目前支持 "home"（返回主屏幕）。
    """
    if key == "home":
        client.homescreen()


def ws_data(key: dict):
    """通过 WebSocket 发送设备信息。

    Args:
        key: 设备信息字典。
    """
    ASWSClientManager = ObjCClass("ASWSClientManager")
    ASWSClientManager.sendDeviceInfoMsgFormPy_(key)


def input_text(text: str):
    """在当前输入框中输入文本。

    Args:
        text: 要输入的文本内容。
    """
    PythonBridge = ObjCClass("PythonBridge")
    PythonBridge.inputText_(text)


def input_clear():
    """清除当前输入框的内容。"""
    PythonBridge = ObjCClass("PythonBridge")
    PythonBridge.inputClear()


def input_return():
    """模拟按下回车键。"""
    PythonBridge = ObjCClass("PythonBridge")
    PythonBridge.inputReturn()


def save_pic2photo(address: str):
    """将图片保存到系统相册。

    Args:
        address: 图片文件路径。

    Returns:
        保存结果。
    """
    PythonBridge = ObjCClass("PythonBridge")
    successDec = PythonBridge.savePic(address)
    return api.py_from_ns(successDec)


def save_video2photo(address: str):
    """将视频保存到系统相册。

    Args:
        address: 视频文件路径。

    Returns:
        保存结果。
    """
    PythonBridge = ObjCClass("PythonBridge")
    successDec = PythonBridge.saveVideo(address)
    return api.py_from_ns(successDec)


def save_obj(key: str, value):
    """通过原生端持久化存储键值对数据。

    Args:
        key: 数据键名。
        value: 要保存的值。
    """
    PythonBridge = ObjCClass("PythonBridge")
    PythonBridge.saveData_value_(key, value)


def get_obj(key: str):
    """从原生端获取持久化存储的数据。

    Args:
        key: 数据键名。

    Returns:
        存储的数据值。
    """
    PythonBridge = ObjCClass("PythonBridge")
    valueObj = PythonBridge.getData_(key)
    return api.py_from_ns(valueObj)

def get_appBundleID():
    """获取当前应用的 Bundle ID。

    Returns:
        str: 应用的 Bundle ID。
    """
    PythonBridge = ObjCClass("PythonBridge")
    valueObj = PythonBridge.appBundleID()
    return api.py_from_ns(valueObj)

def vibrate(duration, intensity):
    """触发设备振动。

    Args:
        duration: 振动持续时间（毫秒）。
        intensity: 振动强度，范围 0~1 的小数。
    """
    PythonBridge = ObjCClass("PythonBridge")
    PythonBridge.vibrate_intensity_(duration, intensity)


def hiddenPictureInPicture():
    """隐藏画中画窗口。"""
    PythonBridge = ObjCClass("PythonBridge")
    PythonBridge.hiddenPictureInPicture()


def showPictureInPicture():
    """显示画中画窗口。"""
    PythonBridge = ObjCClass("PythonBridge")
    PythonBridge.showPictureInPicture()


def getDeviceId():
    """获取设备唯一标识符。

    Returns:
        str: 设备 ID。
    """
    PythonBridge = ObjCClass("PythonBridge")
    valueObj = PythonBridge.getDeviceId()
    return api.py_from_ns(valueObj)

def getSystemVersion():
    """获取设备的系统版本号。

    Returns:
        str: 系统版本号字符串。
    """
    PythonBridge = ObjCClass("PythonBridge")
    valueObj = PythonBridge.getSystemVersion()
    return api.py_from_ns(valueObj)
