import mimetypes

from ascript.ios.developer.api import label_utils, dao
from ascript.ios.developer.api.dao import api_result_for_oc


def label_add(args):
    """添加标注数据。

    Args:
        args: 请求参数字典，必须包含 'label' 键，表示标注数据的 JSON 字符串。

    Returns:
        dict: API 响应结果。
    """
    label = args["label"]
    label_utils.add_label(label)
    return dao.api_result_for_oc(data=dao.api_result_json())


def get_img_label(args):
    """获取指定图片的标注信息。

    Args:
        args: 请求参数字典，包含以下键：
            - name (str): 标注目录名称。
            - iname (str): 图片文件名。

    Returns:
        dict: 包含标注数据列表的 API 响应结果。
    """
    label_dir_name = args["name"]
    label_img_name = args["iname"]
    res = label_utils.get_img_lables(label_dir_name, label_img_name)
    return dao.api_result_for_oc(data=dao.api_result_json(data=res))


def get_label_names(args):
    """获取指定标注目录下所有标注类别名称。

    Args:
        args: 请求参数字典，必须包含 'name' 键，表示标注目录名称。

    Returns:
        dict: 包含标注类别名称列表的 API 响应结果。
    """
    label_dir_name = args["name"]
    res = label_utils.get_label_names(label_dir_name)
    return dao.api_result_for_oc(data=dao.api_result_json(data=res))

    # get_label_names


def export_cnp(args):
    """将标注数据导出为 CNP 格式的 ZIP 压缩包。

    Args:
        args: 请求参数字典，必须包含 'name' 键，表示标注目录名称。

    Returns:
        dict: 包含 ZIP 文件路径的 API 响应结果。
    """
    label_dir_name = args["name"]
    file_path = label_utils.export_cnp(label_dir_name)
    # mine_type, _ = mimetypes.guess_type(file_path)
    # if not mine_type:
    #     mine_type = "application/octet-stream"

    return api_result_for_oc(mimetype="application/zip", data=file_path)


def export_yolo_zip(args):
    """将标注数据导出为 YOLO 训练格式的 ZIP 压缩包。

    Args:
        args: 请求参数字典，必须包含 'name' 键，表示标注目录名称。

    Returns:
        dict: 包含 ZIP 文件路径的 API 响应结果。
    """
    label_dir_name = args["name"]
    file_path = label_utils.excport_yolo_zip(label_dir_name)
    # mine_type, _ = mimetypes.guess_type(file_path)
    # if not mine_type:
    #     mine_type = "application/octet-stream"

    return api_result_for_oc(mimetype="application/zip", data=file_path)
