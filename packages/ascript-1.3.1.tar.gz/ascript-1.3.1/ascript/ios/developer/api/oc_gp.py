import json
import os.path

import io
import re

from PIL.Image import Image
from typing import List, Union
from rubicon.objc import ObjCClass
import ctypes
from rubicon.objc import api
from ascript.ios.developer.api.dao import ImgInout
from ascript.ios.screen.gp import Point


def image_to_ocdata(image):
    """将 PIL Image 对象转换为 OC 端的 NSData 对象。

    Args:
        image: PIL Image 图像对象。

    Returns:
        NSData: 转换后的 OC NSData 对象。
    """
    image_byte_array = io.BytesIO()
    image.save(image_byte_array, format='PNG')
    image_byte_array = image_byte_array.getvalue()

    def convert_byte_array_to_nsdata(byte_array):
        """将 Python 字节数组转换为 NSData 对象。

        Args:
            byte_array: Python 字节数组。

        Returns:
            NSData: OC 的 NSData 对象。
        """
        buffer = (ctypes.c_ubyte * len(byte_array))(*byte_array)
        return ObjCClass('NSData').dataWithBytes_length_(buffer, len(byte_array))

    # 大图data
    large_byte_array = image_byte_array
    largeOCData = convert_byte_array_to_nsdata(large_byte_array)
    return largeOCData


def screen_cache(cache: bool, img_inout: ImgInout):
    """控制屏幕截图缓存的开启和关闭。

    开启时将图像数据缓存到原生端以提高后续操作性能；关闭时释放缓存。

    Args:
        cache: True 开启缓存，False 释放缓存。
        img_inout: 图像输入输出对象，包含图像数据或文件路径。
    """
    PythonBridge = ObjCClass("PythonBridge")
    if cache:
        if img_inout.image_file:
            result = PythonBridge.startPyImgCache_filePath_fileData_(True, img_inout.image_file, None)
            # print(f"result: {result}")
        elif img_inout.image:
            largeOCData = image_to_ocdata(img_inout.image)
            result = PythonBridge.startPyImgCache_filePath_fileData_(True, None, largeOCData)
    else:
        # print("释放缓存")
        result = PythonBridge.startPyImgCache_filePath_fileData_(False, None, None)


def find_all_template(img_inout: ImgInout, image_search: List[str], threshold=0.5, rgb: bool = False, max_res=-1):
    """使用模板匹配在大图中查找所有小图的位置。

    通过 OC 桥接调用原生端的 OpenCV 模板匹配功能。

    Args:
        img_inout: 图像输入输出对象，包含大图数据或文件路径。
        image_search: 小图文件路径列表。
        threshold: 相似度阈值，低于此值的结果将被过滤，默认为 0.5。
        rgb: 是否启用彩色匹配，默认为 False。
        max_res: 最大匹配结果数量，-1 表示不限制。

    Returns:
        list: 匹配结果列表，每项包含 result、rect、center_x、center_y、confidence。
    """
    rect_params = ""
    if img_inout.rect:
        rect_params = ','.join([str(num) for num in img_inout.rect])
    ASOpencvUtils = ObjCClass("ASOpencvUtils")
    if img_inout.image_file:
        result = ASOpencvUtils.processSmallImgLocationInLargeImgFile_smallByteArray_rect_rgb_threshold_maxCount_(
            img_inout.image_file, image_search, rect_params, rgb, threshold, max_res)
    elif img_inout.image:
        largeOCData = image_to_ocdata(img_inout.image)
        result = ASOpencvUtils.processSmallImageLocationInLargeImage_smallByteArray_rect_threshold_maxCount_(
            largeOCData, image_search, rect_params, threshold, max_res)

    else:
        result = ASOpencvUtils.processSmallImgLocationInLargeImgFile_smallByteArray_rect_rgb_threshold_maxCount_(None,
                                                                                                                 image_search,
                                                                                                                 rect_params,
                                                                                                                 rgb,
                                                                                                                 threshold,
                                                                                                                 max_res)
    res = []
    for r in result:
        r = api.py_from_ns(r)
        x = r['x']
        y = r['y']
        w = r['w']
        h = r['h']
        c = r['confidence']
        center_x = x + w / 2
        center_y = y + h / 2
        if c >= threshold:
            res.append({
                "result": (center_x, center_y),
                "rect": (x, y, x + w, y + h),
                "center_x": center_x,
                "center_y": center_y,
                "confidence": c
            })

    return res


def find_sift(img_inout: ImgInout, image_search: List[str], threshold=0.5, rgb: bool = False,
              max_res: int = 0):
    """使用 SIFT 特征匹配在大图中查找所有小图的位置。

    支持全分辨率匹配，通过 OC 桥接调用原生端的 OpenCV SIFT 功能。

    Args:
        img_inout: 图像输入输出对象，包含大图数据或文件路径。
        image_search: 小图文件路径列表。
        threshold: 相似度阈值，低于此值的结果将被过滤，默认为 0.5。
        rgb: 是否启用彩色匹配，默认为 False。
        max_res: 最大匹配结果数量，0 表示不限制。

    Returns:
        list: 匹配结果列表，每项包含 result、rect、center_x、center_y、confidence。
    """
    rect_params = ""
    if img_inout.rect:
        rect_params = ','.join([str(num) for num in img_inout.rect])

    ASOpencvUtils = ObjCClass("ASOpencvUtils")
    if img_inout.image_file:
        result = ASOpencvUtils.findSiftWithImgFile_imageSearch_threshold_rect_rgb_maxcnt_(img_inout.image_file,
                                                                                          image_search, threshold,
                                                                                          rect_params, rgb, max_res)
    elif img_inout.image:
        largeOCData = image_to_ocdata(img_inout.image)
        result = ASOpencvUtils.findSiftWithImageSource_imageSearch_threshold_rect_rgb_maxcnt_(largeOCData, image_search,
                                                                                              threshold, rect_params,
                                                                                              rgb, max_res)
    else:
        result = ASOpencvUtils.findSiftWithImgFile_imageSearch_threshold_rect_rgb_maxcnt_(None,
                                                                                          image_search, threshold,
                                                                                          rect_params, rgb, max_res)

    res = []
    for r in result:
        r = api.py_from_ns(r)
        x = r['x']
        y = r['y']
        w = r['w']
        h = r['h']
        c = r['confidence']
        center_x = x + w / 2
        center_y = y + h / 2
        if c >= threshold:
            res.append({
                "result": (center_x, center_y),
                "rect": (x, y, x + w, y + h),
                "center_x": center_x,
                "center_y": center_y,
                "confidence": c
            })

    return res


def ocr(mode: int, img_inout: ImgInout, threshold=0.2, pattern=None):
    """对图像执行 OCR 文字识别。

    通过 OC 桥接调用原生端的 PaddleOCR 引擎进行文字识别。

    Args:
        mode: OCR 模式。
        img_inout: 图像输入输出对象，包含图像数据或文件路径。
        threshold: 置信度阈值，低于此值的结果将被过滤，默认为 0.2。
        pattern: 正则表达式模式，用于过滤识别文本，默认为 None。

    Returns:
        list: OCR 识别结果列表，每项包含 result、rect、center_x、center_y、confidence、text。
    """
    rect_params = ""
    if img_inout.rect:
        rect_params = ','.join([str(num) for num in img_inout.rect])
    ASPPOcrUtils = ObjCClass("ASPPOcrUtils")
    if img_inout.image_file:
        result = ASPPOcrUtils.ocrUtilsWithPPath_rect_(img_inout.image_file, rect_params)
    elif img_inout.image:
        largeOCData = image_to_ocdata(img_inout.image)
        result = ASPPOcrUtils.ocrUtilsWithPP_rect_(largeOCData, rect_params)
    else:
        result = ASPPOcrUtils.ocrUtilsWithPPath_rect_(None, rect_params)

    res = []

    # print(offset_x, offset_y)

    for r in result:
        r = api.py_from_ns(r)
        x = r['x']
        y = r['y']
        w = r['w']
        h = r['h']
        txt = r['txt']
        c = r['confidence']
        center_x = x + w / 2
        center_y = y + h / 2
        match = True
        if pattern:
            if not re.search(pattern, txt):
                match = False

        if c >= threshold and match:
            res.append({
                "result": (center_x, center_y),
                "rect": (x, y, x + w, y + h),
                "center_x": center_x,
                "center_y": center_y,
                "confidence": c,
                "text": txt
            })
    return res


def code_scanner(image: Image, offset_x=0, offset_y=0):
    """扫描图像中的条形码和二维码。

    Args:
        image: PIL Image 图像对象，传入 None 时返回空列表。
        offset_x: 结果坐标的 X 轴偏移量，默认为 0。
        offset_y: 结果坐标的 Y 轴偏移量，默认为 0。

    Returns:
        list: 扫描结果列表，每项包含 result、rect、center_x、center_y、value、type、format。
    """
    print('code_scanner参数：', image)
    if image:
        image_byte_array = io.BytesIO()
        image.save(image_byte_array, format='PNG')
        image_byte_array = image_byte_array.getvalue()

        def convert_byte_array_to_nsdata(byte_array):
            """将 Python 字节数组转换为 NSData 对象。

            Args:
                byte_array: Python 字节数组。

            Returns:
                NSData: OC 的 NSData 对象。
            """
            buffer = (ctypes.c_ubyte * len(byte_array))(*byte_array)
            return ObjCClass('NSData').dataWithBytes_length_(buffer, len(byte_array))

        largeOCData = convert_byte_array_to_nsdata(image_byte_array)
        ASBarcodeScanningUtils = ObjCClass("ASBarcodeScanningUtils")
        result = ASBarcodeScanningUtils.scanImage_(largeOCData)
    else:
        # ASBarcodeScanningUtils = ObjCClass("ASBarcodeScanningUtils")
        # result = ASBarcodeScanningUtils.scanImage()
        return []
    # print('执行结果', result)

    res = []

    for r in result:
        r = api.py_from_ns(r)
        x = r['x'] + offset_x
        y = r['y'] + offset_y
        w = r['w']
        h = r['h']
        txt = r['txt']
        type = r['type']
        format = r['format']
        center_x = x + w / 2
        center_y = y + h / 2

        res.append({
            "result": (center_x, center_y),
            "rect": (x, y, x + w, y + h),
            "center_x": center_x,
            "center_y": center_y,
            "value": txt,
            "type": type,
            "format": format
        })
    return res


def find_colors(img_inout: ImgInout, colors, space, ori, diff, num):
    """在图像中查找匹配指定颜色特征的位置。

    通过 OC 桥接调用原生端的找色功能。

    Args:
        img_inout: 图像输入输出对象，包含图像数据或文件路径。
        colors: 颜色特征字符串，格式如 "801,726,#0968A9|850,682,#FFFFFF|893,726,#FFFFFF"。
        space: 最终结果中颜色点之间的间隔。
        ori: 找色方向。
        diff: RGB 三个通道的最大绝对值色差，格式为 (r_diff, g_diff, b_diff)。
        num: 最大匹配结果数量。

    Returns:
        list: 匹配到的 Point 坐标点列表。
    """

    # 范围参数
    rect_params = ""
    if img_inout.rect:
        rect_params = ','.join([str(num) for num in img_inout.rect])

    diff = (diff[0] << 16) | (diff[1] << 8) | diff[2]
    ASFindColorHelp = ObjCClass("ASFindColorHelp")
    # 图片参数
    if img_inout.image_file:
        result = ASFindColorHelp.findColor_filePath_colors_diff_ori_space_rect_(num, img_inout.image_file, colors, diff,
                                                                                ori, space, rect_params)
    elif img_inout.image:
        largeOCData = image_to_ocdata(img_inout.image)
        result = ASFindColorHelp.findColor_fileData_colors_diff_ori_space_rect_(num, largeOCData, colors, diff, ori,
                                                                                space, rect_params)
    else:
        result = ASFindColorHelp.findColor_filePath_colors_diff_ori_space_rect_(num, None, colors, diff,
                                                                                ori, space, rect_params)

    res = []

    for r in result:
        ri = api.py_from_ns(r)
        del r
        x = ri['x']
        y = ri['y']
        res.append(Point(x, y))

    del result
    return res


def counting_color(img_inout: ImgInout, colors, diff):
    """统计图像中匹配指定颜色的像素数量。

    Args:
        img_inout: 图像输入输出对象，包含图像数据或文件路径。
        colors: 颜色特征字符串。
        diff: RGB 三个通道的最大绝对值色差，格式为 (r_diff, g_diff, b_diff)。

    Returns:
        int: 匹配的像素数量。
    """
    rect_params = ""
    if img_inout.rect:
        rect_params = ','.join([str(num) for num in img_inout.rect])

    diff = (diff[0] << 16) | (diff[1] << 8) | diff[2]

    result = 0
    ASFindColorHelp = ObjCClass("ASFindColorHelp")
    if img_inout.image_file:
        result = ASFindColorHelp.countingColorWithPath_colors_rect_diff_(img_inout.image_file, colors, rect_params,
                                                                         diff)
    elif img_inout.image:
        largeOCData = image_to_ocdata(img_inout.image)
        result = ASFindColorHelp.countingColorWithData_colors_rect_diff_(largeOCData, colors, rect_params, diff)
    else:
        result = ASFindColorHelp.countingColorWithPath_colors_rect_diff_(None, colors, rect_params,
                                                                         diff)
    return result


def yolov8_load(param_path: str, bin_path: str, nc: int, use_gpu: bool = False):
    """加载 YOLOv8 NCNN 模型。

    Args:
        param_path: NCNN 模型的 .param 文件路径。
        bin_path: NCNN 模型的 .bin 文件路径。
        nc: 模型的类别数量。
        use_gpu: 是否使用 GPU 加速，默认为 False。

    Returns:
        加载结果。
    """
    ASNcnnUtils = ObjCClass("ASNcnnUtils")
    return ASNcnnUtils.yolov8Load_binPath_nc_useGpu_(param_path, bin_path, nc, use_gpu)


def yolov8_detect(img: Union[Image, str], target_size: int = 640, threshold=0.4, nms_threshold=0.5):
    """使用 YOLOv8 模型进行目标检测。

    Args:
        img: 输入图像，可以是 PIL Image 对象或图片文件路径字符串。
        target_size: 检测时的目标图像尺寸，默认为 640。
        threshold: 检测置信度阈值，默认为 0.4。
        nms_threshold: 非极大值抑制阈值，默认为 0.5。

    Returns:
        list: 检测结果列表（JSON 解析后的对象）。
    """
    result = None
    if isinstance(img, Image):
        largeOCData = image_to_ocdata(img)
        ASNcnnUtils = ObjCClass("ASNcnnUtils")
        result = ASNcnnUtils.yolov8DetectData_targetSize_threshold_nmsThreshold_(largeOCData, target_size, threshold,
                                                                                 nms_threshold)
    else:
        ASNcnnUtils = ObjCClass("ASNcnnUtils")
        result = ASNcnnUtils.yolov8DetectPath_targetSize_threshold_nmsThreshold_(img, target_size, threshold,
                                                                                 nms_threshold)
    # print(result, type(result))

    res = api.py_from_ns(result)

    return json.loads(res)


def yolov8_free():
    """释放已加载的 YOLOv8 模型资源。"""
    ASNcnnUtils = ObjCClass("ASNcnnUtils")
    ASNcnnUtils.yolov8Free()
