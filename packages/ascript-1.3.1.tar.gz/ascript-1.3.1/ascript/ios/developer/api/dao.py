import json
from PIL import Image


def api_result_error(e: Exception):
    """根据异常对象构造错误响应结果。

    Args:
        e: 异常对象。

    Returns:
        dict: 包含错误码 -1、异常消息和空数据的字典。
    """
    result = {
        "code": -1,
        "msg": str(e),
        "data": None
    }

    return result


def api_result(code: int = 1, msg: str = "success", data=None, mimetype="application/json"):
    """构造标准 API 响应结果字典。

    Args:
        code: 响应状态码，默认为 1（成功）。
        msg: 响应消息，默认为 "success"。
        data: 响应数据，默认为 None。
        mimetype: MIME 类型，默认为 "application/json"。

    Returns:
        dict: 包含 code、msg 和 data 的标准响应字典。
    """
    result = {
        "code": code,
        "msg": msg,
        "data": data,
    }

    return result


def api_result_json(code: int = 1, msg: str = "success", data=None):
    """构造标准 API 响应结果并序列化为 JSON 字符串。

    Args:
        code: 响应状态码，默认为 1（成功）。
        msg: 响应消息，默认为 "success"。
        data: 响应数据，默认为 None。

    Returns:
        str: JSON 格式的响应结果字符串。
    """
    result = {
        "code": code,
        "msg": msg,
        "data": data
    }

    return json.dumps(result)


def api_result_for_oc(code=200, mimetype="application/json", data=None):
    """构造适配 OC（Objective-C）端的 API 响应结果。

    Args:
        code: HTTP 状态码，默认为 200。
        mimetype: 响应的 MIME 类型，默认为 "application/json"。
        data: 响应数据，默认为 None（将自动生成默认的 JSON 响应）。

    Returns:
        dict: 包含 code、mimetype 和 data 的响应字典。
    """
    if data is None:
        data = api_result_json()

    return {
        "code": code,
        "mimetype": mimetype,
        "data": data
    }


class ImgInout:
    """图像输入输出封装类，用于统一管理图像数据的传递方式。"""

    def __init__(self, image: Image.Image = None,
                 image_file: str = None, rect=None):
        """初始化图像输入输出对象。

        Args:
            image: PIL Image 对象，直接传入的图像数据。
            image_file: 图像文件路径字符串。
            rect: 裁剪区域，格式为 (left, top, right, bottom)。
        """
        self.image = image
        self.image_file = image_file
        self.rect = rect




