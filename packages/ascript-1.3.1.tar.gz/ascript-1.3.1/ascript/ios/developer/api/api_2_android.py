from ascript.ios.developer.api import  api_module


def module_get(args):
    """获取指定模块的文件信息。

    Args:
        args: 请求参数字典，必须包含 'name' 键，表示模块名称。
    """
    name = args['name']
    api_module.api_module_files(args)
    pass