import logging
import zipfile
import inspect
import ctypes
import os
import shutil
import sys
from logging.handlers import RotatingFileHandler
from ascript.ios import system

home_dir, module_space = "", ""
module_line = ""
label_space = ""

label_yolo_space = ""
cache = ""
data_space = ""
log_space = ""
screen_shot_dir = ""
gp_home_dir = ""
threads = []
ui_instance = {}
r_name = ""
r_root = ""
assets_space = ""
is_cache = False
audio_pool = {}


# client = AppiumClient()


def init(path_home):
    """初始化所有工作空间目录路径。

    根据主目录路径创建模块空间、缓存、数据、截图、日志等子目录。
    缓存目录在每次初始化时会被清空重建。

    Args:
        path_home: 应用主目录的路径。
    """
    global home_dir, module_space, cache, data_space, screen_shot_dir, gp_home_dir, module_line, log_space, label_space,label_yolo_space,assets_space
    home_dir = path_home
    module_space = os.path.join(home_dir, 'modules')
    module_line = os.path.join(home_dir, 'mline')
    data_space = os.path.join(home_dir, 'data')
    assets_space = os.path.join(home_dir, 'assets')
    label_space = os.path.join(home_dir, "label")
    label_yolo_space = os.path.join(home_dir, "label_yolo")
    cache = os.path.join(data_space, "cache")
    screen_shot_dir = os.path.join(data_space, 'screenshot')
    gp_home_dir = os.path.join(data_space, 'gp')
    log_space = os.path.join(data_space, "log")

    if not os.path.exists(screen_shot_dir):
        os.makedirs(screen_shot_dir)

    if not os.path.exists(gp_home_dir):
        os.makedirs(gp_home_dir)
    sys.path.append(gp_home_dir)

    if not os.path.exists(log_space):
        os.makedirs(log_space)

    if not os.path.exists(module_space):
        os.makedirs(module_space)

    if not os.path.exists(label_space):
        os.makedirs(label_space)

    if not os.path.exists(label_yolo_space):
        os.makedirs(label_yolo_space)

    if not os.path.exists(module_line):
        os.makedirs(module_line)

    if not os.path.exists(assets_space):
        os.makedirs(assets_space)

    if not os.path.exists(cache):
        os.makedirs(cache)
    else:
        # 删除文件夹及其内容
        shutil.rmtree(cache, ignore_errors=True)
        # 重新创建文件夹
        os.makedirs(cache, exist_ok=True)


def path_home_filter(path):
    """将路径中的 ~/ 前缀替换为实际的主目录路径。

    Args:
        path: 可能包含 ~/ 或 /~/ 前缀的路径字符串。

    Returns:
        str: 替换后的绝对路径。
    """
    if path.startswith("~/"):
        path = os.path.join(home_dir, path.replace("~/", ""))
    elif path.startswith("/~/"):
        path = os.path.join(home_dir, path.replace("/~/", ""))

    return path


def zip_folder_contents(folder_path, output_zip_path):
    """将文件夹内容压缩为 ZIP 文件。

    压缩文件夹中的所有文件，ZIP 内不包含顶级目录名。

    Args:
        folder_path: 要压缩的文件夹路径。
        output_zip_path: 输出的 ZIP 文件路径。
    """
    folder_path = os.path.normpath(folder_path)

    with zipfile.ZipFile(output_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                # 构造文件的完整路径
                file_path = os.path.join(root, file)
                # 计算arcname，即zip文件中文件的相对路径（不包括顶级目录）
                arcname = os.path.relpath(file_path, folder_path)
                # 写入zip文件
                zipf.write(file_path, arcname)


def unzip_file(zip_path, extract_to):
    """解压 ZIP 文件到指定目录。

    如果目标目录不存在，会自动创建。

    Args:
        zip_path: ZIP 文件的路径。
        extract_to: 解压到的目标目录路径。
    """
    # 确保目标目录存在
    if not os.path.exists(extract_to):
        os.makedirs(extract_to)

        # 使用zipfile模块打开zip文件
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        # 解压所有文件到指定目录
        zip_ref.extractall(extract_to)


def _async_raise(tid, exctype):
    """在指定线程中异步抛出异常，用于强制终止线程。

    Args:
        tid: 目标线程的 ID。
        exctype: 要抛出的异常类型。

    Raises:
        SystemError: 当 PyThreadState_SetAsyncExc 调用失败时抛出。
    """
    tid = ctypes.c_long(tid)
    if not inspect.isclass(exctype):
        exctype = type(exctype)
    res = ctypes.pythonapi.PyThreadState_SetAsyncExc(tid, ctypes.py_object(exctype))
    if res == 0:
        pass
        # raise ValueError("invalid thread id")
    elif res != 1:
        # """if it returns a number greater than one, you're in trouble,
        # and you should call it again with exc=NULL to revert the effect"""
        ctypes.pythonapi.PyThreadState_SetAsyncExc(tid, None)
        raise SystemError("PyThreadState_SetAsyncExc failed")


def stop_thread(thread):
    """强制停止指定线程。

    通过在线程中异步抛出 SystemExit 异常来终止线程。

    Args:
        thread: 要停止的线程对象。
    """
    _async_raise(thread.ident, SystemExit)


logger = logging.getLogger()
logger.setLevel(logging.DEBUG)


def init_logging(log_file=None):
    """初始化日志系统。

    配置日志文件的轮转处理器，最大 1MB，保留 10 个备份文件。

    Args:
        log_file: 日志文件路径，默认为 None。
    """
    for handler in logger.handlers:
        logger.removeHandler(handler)

    handler = RotatingFileHandler(log_file, maxBytes=1024 * 1024, backupCount=10)  # 例如，设置最大1MB，保留5个备份
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    # handler.mode = 'a'
    # if handler in logger.handlers:
    #     logger.removeHandler(handler)
    logger.addHandler(handler)


def recode_loger(msg, t):
    """记录日志消息到日志文件。

    Args:
        msg: 日志消息内容。
        t: 日志类型，'i' 为 info 级别，其他为 error 级别。
    """
    if logger:
        if t == 'i':
            logger.info(msg.rstrip())
        else:
            logger.error(msg.rstrip())


def get_device_id():
    """获取设备的唯一标识符（UUID）。

    Returns:
        str: 设备的 UUID。
    """
    return system.client.info.uuid
