import io
import json
import mimetypes
import os
import shutil
import time
import zipfile

from PIL import Image
from ascript.ios.developer.api import dao, file_utils
from ascript.ios.developer.api.dao import api_result_for_oc, api_result_json
from ascript.ios.developer.api import utils


def api_file_get(args):
    """获取指定路径的文件内容。

    Args:
        args: 请求参数字典，必须包含 'path' 键，表示文件路径。

    Returns:
        dict: 包含文件 MIME 类型和文件路径的 API 响应结果。
    """
    file_path = utils.path_home_filter(args["path"])
    mine_type, _ = mimetypes.guess_type(file_path)
    if not mine_type:
        mine_type = "application/octet-stream"

    return api_result_for_oc(mimetype=mine_type, data=file_path)


def api_file_copy(args: dict = None):
    """复制文件到指定目标路径。

    Args:
        args: 请求参数字典，包含以下键：
            - source (str): 源文件路径。
            - target (str): 目标文件路径。

    Returns:
        dict: API 响应结果。
    """
    source_path = args["source"]
    target_path = args["target"]
    source_path = utils.path_home_filter(source_path)
    target_path = utils.path_home_filter(target_path)

    if not os.path.exists(os.path.dirname(target_path)):
        os.makedirs(os.path.dirname(target_path))
    shutil.copy(source_path, target_path)
    return api_result_for_oc()


def api_file_get_image(args):
    """获取指定路径的图片文件，支持按最大高度缩放。

    Args:
        args: 请求参数字典，包含以下键：
            - path (str): 图片相对路径。
            - maxheight (int, 可选): 最大高度限制，按比例缩放。

    Returns:
        dict: 包含 PNG 格式图片二进制数据的 API 响应结果；文件不存在时返回 404。
    """
    file_path = os.path.join(utils.module_space, args["path"])
    file_path = utils.path_home_filter(file_path)
    if not os.path.exists(file_path):
        return api_result_for_oc(404, data={})
    max_height = -1
    if "maxheight" in args:
        max_height = int(args['maxheight'])

    if max_height < 0:
        with Image.open(file_path) as img:
            byte_arr = io.BytesIO()
            img.save(byte_arr, format='PNG')
            byte_arr = byte_arr.getvalue()
            return api_result_for_oc(200, mimetype='image/png', data=byte_arr)
    else:
        with Image.open(file_path) as img:
            width, height = img.size
            target_width = int(width * (max_height / height))
            resized_img = img.resize((target_width, max_height))
            byte_arr = io.BytesIO()
            resized_img.save(byte_arr, format='PNG')
            byte_arr = byte_arr.getvalue()
            return api_result_for_oc(200, mimetype='image/png', data=byte_arr)


def api_file_save(args):
    """保存内容到指定文件。

    Args:
        args: 请求参数字典，包含以下键：
            - path (str): 文件路径。
            - content (str): 要写入的文件内容。

    Returns:
        dict: API 响应结果；文件不存在时返回 404 错误。
    """
    file_path = utils.path_home_filter(args["path"])
    content = args["content"]
    if not os.path.exists(file_path):
        return "File does not exist", 404

    with open(file_path, "w", newline='\n', encoding="utf-8") as f:
        f.write(content)

    return api_result_for_oc()


def api_file_create(args: dict = None):
    """创建新文件或目录。

    Args:
        args: 请求参数字典，包含以下键：
            - path (str): 父目录路径。
            - name (str): 文件或目录名称。
            - type (str): 类型，"file" 为文件，其他为目录。

    Returns:
        dict: API 响应结果；文件已存在或创建失败时返回错误信息。
    """
    try:
        file_path = utils.path_home_filter(args["path"])
        file_name = args["name"]
        file_type = args["type"]

        new_file = os.path.join(file_path, file_name)

        if os.path.exists(new_file):
            return dao.api_result_for_oc(data=dao.api_result_json(code=0, msg="文件已存在"))

        if file_type == "file":

            if not os.path.exists(os.path.dirname(new_file)):
                os.makedirs(os.path.dirname(new_file))

            with open(new_file, "w") as f:
                pass
        else:
            os.makedirs(new_file)

        # return api_result_for_oc()
        return dao.api_result_for_oc(data=dao.api_result_json())
    except Exception as e:
        return dao.api_result_for_oc(data=dao.api_result_json(code=0, msg=str(e)))


def api_dir_export_zip(args):
    """将指定目录导出为 ZIP 压缩文件。

    Args:
        args: 请求参数字典，包含以下键：
            - path (str): 要压缩的目录路径。
            - name (str): 输出的 ZIP 文件名。

    Returns:
        dict: 包含 ZIP 文件路径的 API 响应结果。

    Raises:
        FileNotFoundError: 指定的目录不存在时抛出。
    """
    label_root_dir = utils.path_home_filter(args["path"])
    zip_name = args["name"]
    output_zip_path = os.path.join(utils.cache, zip_name)
    # print(output_zip_path)

    """
        将文件夹压缩成ZIP文件

        :param folder_path: 文件夹路径
        :param output_zip_path: 输出的ZIP文件路径
        """
    # 检查文件夹是否存在
    if not os.path.isdir(label_root_dir):
        raise FileNotFoundError(f"The folder {label_root_dir} does not exist.")

    # 创建ZIP文件
    with zipfile.ZipFile(output_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        # 遍历文件夹中的所有文件和子文件夹
        for root, dirs, files in os.walk(label_root_dir):
            # 对于根目录下的文件，直接使用文件名作为arcname
            if root == label_root_dir:
                arcname_root = ''
            else:
                # 对于子目录中的文件，使用相对于根目录的路径（去掉根目录名本身）
                arcname_root = os.path.relpath(root, label_root_dir)
                if arcname_root.startswith(os.sep):  # 在Windows上可能是'\'，在Unix/Linux上可能是'/'
                    arcname_root = arcname_root[len(os.sep):]

            for file in files:
                # 创建ZIP文件内的完整路径
                if file.endswith('.cnp'):
                    continue
                file_path = os.path.join(root, file)
                arcname = os.path.join(arcname_root, file)
                # 将文件添加到ZIP文件中
                zipf.write(file_path, arcname)

    return api_result_for_oc(mimetype="application/zip", data=output_zip_path)



def api_file_remove(args):
    """删除指定的文件或目录。

    Args:
        args: 请求参数字典，必须包含 'path' 键，表示要删除的文件或目录路径。

    Returns:
        dict: API 响应结果；删除失败时返回错误信息。
    """
    try:
        file_path = args["path"]
        file_path = utils.path_home_filter(file_path)
        # print("删除", file_path)

        if os.path.exists(file_path):
            if os.path.isfile(file_path):
                os.remove(file_path)
            else:
                shutil.rmtree(file_path)
        return dao.api_result_for_oc(data=dao.api_result_json())
    except Exception as e:
        return dao.api_result_for_oc(data=dao.api_result_json(code=0, msg=str(e)))


def api_file_rename(args):
    """重命名指定文件或目录。

    Args:
        args: 请求参数字典，包含以下键：
            - path (str): 原文件或目录的路径。
            - name (str): 新的名称。

    Returns:
        dict: API 响应结果。
    """
    src_file = utils.path_home_filter(args["path"])
    file_rname = args["name"]
    new_file = os.path.join(os.path.dirname(src_file), file_rname)
    if src_file and file_rname:
        os.rename(src_file, new_file)
        return api_result_for_oc()


def api_file_image_crop(args):
    """裁剪图片并保存到指定路径。

    Args:
        args: 请求参数字典，包含以下键：
            - image (str): 源图片路径。
            - rect (str): 裁剪区域的 JSON 字符串，格式为 [left, top, right, bottom]。
            - target (str, 可选): 裁剪后图片的保存路径，不指定则保存到缓存目录。

    Returns:
        dict: 包含裁剪后图片路径的 API 响应结果。
    """
    img_path = utils.path_home_filter(args["image"])
    rect = json.loads(args["rect"])

    if "target" in args:
        target_path = utils.path_home_filter(args["target"])
    else:
        target_path = os.path.join(utils.cache, f"{time.time()}.png")

    # print(utils.cache,target_path)

    with Image.open(img_path) as img:
        cropped_img = img.crop(rect)
        # 保存裁剪后的图像

        if not os.path.exists(os.path.dirname(target_path)):
            os.makedirs(os.path.dirname(target_path))

        cropped_img.save(target_path)

    return api_result_for_oc(data=api_result_json(data=target_path))


def api_files(args):
    """获取指定目录的文件树结构。

    Args:
        args: 请求参数字典，必须包含 'path' 键，表示目录路径。

    Returns:
        dict: 包含目录文件树结构的 API 响应结果。
    """
    # print(args)
    path = utils.path_home_filter(args["path"])
    return api_result_for_oc(data=dao.api_result_json(data=file_utils.get_module_files({}, path)))
