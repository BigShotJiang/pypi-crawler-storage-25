import json
import os
import sys
import time

from ascript.ios.developer.api import dao
from ascript.ios.node import Selector, Node
from ascript.ios.system import client

current_dir = os.path.dirname(os.path.realpath(sys.argv[0]))


def api_node_dump_config(args):
    """配置节点树的 dump 参数。

    Args:
        args: 请求参数字典，包含以下键：
            - ex_attrs (可选): 额外的属性过滤条件。
            - other_filter (int, 可选): 其他过滤条件，默认为 1。
            - timeout (int, 可选): 超时时间（秒），默认为 60。

    Returns:
        dict: API 响应结果。
    """
    ex_attrs = None
    if "ex_attrs" in args:
        ex_attrs = args['ex_attrs']

    other_filter = 1
    if "other_filter" in args:
        other_filter = args['other_filter']

    timeout = 60
    if "timeout" in args:
        timeout = args['timeout']

    data = client.souce_config(ex_attrs, other_filter, timeout)

    return dao.api_result_for_oc(data=dao.api_result_json(data=True))


def api_get_node_dump_config(args):
    """获取当前节点树的 dump 配置信息。

    Args:
        args: 请求参数字典（当前未使用）。

    Returns:
        dict: 包含 dump 配置数据的 API 响应结果。
    """
    data = client.get_souce_config()
    print(data, type(data))
    return dao.api_result_for_oc(data=dao.api_result_json(data=data))


def api_node_dump(args):
    """获取设备的 UI 节点树信息。

    支持通过选择器查找特定节点，也支持按深度获取完整的 XML 节点树。

    Args:
        args: 请求参数字典，包含以下键：
            - selector (str, 可选): 节点选择器的 JSON 字符串。
            - depth (str, 可选): 节点树的深度限制。

    Returns:
        dict: 包含节点树 XML 或选择器匹配结果的 API 响应。
    """
    try:
        if 'selector' in args:
            selector = args["selector"]
            return dao.api_result_for_oc(data=dao.api_result_json(data=api_selector(client, selector)))

        depth = 0
        if 'depth' in args and len(args['depth']) > 0:
            depth = int(args['depth'])

        xml_info = client.source(depth)
        return dao.api_result_for_oc(200, mimetype="application/xml", data=xml_info)
    except Exception as e:
        print("错误" + str(e))
        return dao.api_result_for_oc(1, mimetype="application/xml", data="")


def api_node_package(args):
    """获取当前前台应用的包信息。

    Args:
        args: 请求参数字典（当前未使用）。

    Returns:
        dict: 包含应用名称、Bundle ID 和 PID 的 API 响应结果。
    """
    info = client.app_current()
    dict_info = {
        "name": info.name,
        "bundle_id": info.bundle_id,
        "pid": info.pid
    }
    return dao.api_result_for_oc(data=dao.api_result_json(data=dict_info))


def api_node_attr(args):
    """获取指定节点的详细属性信息。

    Args:
        args: 请求参数字典，必须包含 'node_id' 键，表示节点 ID。

    Returns:
        dict: 包含节点属性字典的 API 响应结果。
    """
    node_id = args["node_id"]
    return dao.api_result_for_oc(data=dao.api_result_json(data=element_to_dict(Node(client, node_id))))


def api_node_error(args):
    """测试用接口，故意触发除零错误。

    Args:
        args: 请求参数字典（当前未使用）。

    Returns:
        dict: API 响应结果（实际不会到达，因为会先抛出 ZeroDivisionError）。
    """
    i = 0 / 0
    return dao.api_result_for_oc(data=dao.api_result_json(data=True))


def api_selector(client, selector: str):
    """使用选择器在节点树中查找匹配的节点。

    Args:
        client: WDA 客户端实例。
        selector: 选择器的 JSON 字符串，包含 'sel'（选择条件）和 'find'（查找方式）。

    Returns:
        list: 匹配节点的字典列表。
    """
    # print(selector)
    sel = json.loads(selector)

    #    print("?-s", time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
    res = Selector().find_with_dict(client, sel["sel"], sel["find"])
    #    print("?-e", time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))

    return elements_to_dict(res)


def elements_to_dict(element):
    """将节点元素列表转换为字典列表。

    Args:
        element: 节点元素的可迭代对象。

    Returns:
        list: 包含每个节点 ID 和标签信息的字典列表。
    """
    res = []
    nid = 0
    for node in element:
        #        print(node)
        if node:
            res.append({
                "id": node._id,
                # "name": element.name,
                "tag": node._id,
                # "value": element.value,
                # "label": element.label,
                # "displayed": element.displayed,
                # "visible": element.visible,
                # "enabled": element.enabled,
                # "accessible": element.accessible,
                # "x": element.bounds.left,
                # "y": element.bounds.top,
                # "width": element.bounds.right - element.bounds.left,
                # "height": element.bounds.bottom - element.bounds.top,
                "nodeId": nid
            })
        nid = nid + 1

    return res


def element_to_dict(element: Node):
    """将单个节点元素转换为包含完整属性的字典。

    Args:
        element: Node 节点对象。

    Returns:
        dict: 包含节点 ID、类型、标签、值、位置、大小等属性的字典。
    """
    bounds = element.bounds
    return {
        "id": element.id,
        "type": element.className,
        "tag": element.id,
        "value": element.value,
        "label": element.label,
        "name": element.name,
        "displayed": element.displayed,
        "visible": element.visible,
        "enabled": element.enabled,
        "index": element.index,
        "accessible": element.accessible,
        "x": bounds.left,
        "y": bounds.top,
        "width": bounds.right - bounds.left,
        "height": bounds.bottom - bounds.top,
        "scale": element.scale(),
        "nodeId": 0
    }
