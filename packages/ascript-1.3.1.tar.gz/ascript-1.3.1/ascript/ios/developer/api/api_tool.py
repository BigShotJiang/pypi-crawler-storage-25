import json
import os

import jedi
from jedi import settings

from ascript.ios.developer.api import dao, utils
from ascript.ios.developer.api.dao import api_result_for_oc, api_result_json
from ascript.ios.system import KeyValue


def save_config(args):
    """保存工具配置信息。

    Args:
        args: 请求参数字典，必须包含 'config' 键，值为 JSON 格式的配置字符串。
    """
    KeyValue.save("config", json.loads(args["config"]), "sys")

    # print(KeyValue.get('config',"",'sys'))


def get_config(args):
    """获取工具配置信息。

    Args:
        args: 请求参数字典（当前未使用）。

    Returns:
        dict: 包含配置数据的 API 响应结果。
    """
    return api_result_for_oc(data=api_result_json(data=KeyValue.get("config", "", "sys")))
