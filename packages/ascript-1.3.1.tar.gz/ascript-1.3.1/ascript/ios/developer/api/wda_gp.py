import re

from ascript.ios.developer.api.dao import ImgInout
import requests
from ascript.ios.screen.gp import Point

host = "http://localhost:8100"
url_find_colors = f"{host}/screenshotFindColors"
url_counting_color = f"{host}/screenshotCountingColors"
url_screen_cache = f"{host}/screenshotCache"


def screen_cache(cache: bool):
    """通过 WDA HTTP 接口控制屏幕截图缓存的开启和关闭。

    Args:
        cache: True 开启缓存，False 关闭缓存。

    Returns:
        bool: 操作成功返回 True。
    """
    params = {
        'cache': cache,
    }
    response = requests.get(url_find_colors, params)
    response.raise_for_status()
    return True


def find_colors(img_inout: ImgInout, colors, space, ori, diff, num):
    """通过 WDA HTTP 接口在图像中查找匹配指定颜色特征的位置。

    Args:
        img_inout: 图像输入输出对象，包含裁剪区域信息。
        colors: 颜色特征字符串。
        space: 最终结果中颜色点之间的间隔。
        ori: 找色方向。
        diff: RGB 三个通道的最大绝对值色差，格式为 (r_diff, g_diff, b_diff)。
        num: 最大匹配结果数量。

    Returns:
        list: 匹配到的 Point 坐标点列表。
    """
    rect_params = ""
    diff = (diff[0] << 16) | (diff[1] << 8) | diff[2]
    if img_inout.rect:
        rect_params = ','.join([str(num) for num in img_inout.rect])
    params = {
        'maxPoints': num,
        'colors': colors,
        'diff': diff,
        'ori': ori,
        'space': space,
        'rect': rect_params,
    }
    response = requests.get(url_find_colors, params)
    response.raise_for_status()

    res = []

    for r in response.json()['value']:
        x = r['x']
        y = r['y']
        res.append(Point(x, y))

    return res


def counting_color(img_inout: ImgInout, colors, diff):
    """通过 WDA HTTP 接口统计图像中匹配指定颜色的像素数量。

    Args:
        img_inout: 图像输入输出对象，包含裁剪区域信息。
        colors: 颜色特征字符串。
        diff: RGB 三个通道的最大绝对值色差，格式为 (r_diff, g_diff, b_diff)。

    Returns:
        int: 匹配的像素数量。
    """
    rect_params = ""
    diff = (diff[0] << 16) | (diff[1] << 8) | diff[2]
    if img_inout.rect:
        rect_params = ','.join([str(num) for num in img_inout.rect])

    params = {
        'colors': colors,
        'diff': diff,
        'rect': rect_params,
    }

    # print(params)

    response = requests.get(url_counting_color, params)
    response.raise_for_status()
    # print(response.json())
    return response.json()['value']


def ocr(mode: int, img_inout: ImgInout, threshold=0.2, pattern=None):
    """通过 WDA HTTP 接口对图像执行 OCR 文字识别。

    Args:
        mode: OCR 模式。
        img_inout: 图像输入输出对象，包含裁剪区域信息。
        threshold: 置信度阈值，低于此值的结果将被过滤，默认为 0.2。
        pattern: 正则表达式模式，用于过滤识别文本，默认为 None。

    Returns:
        list: OCR 识别结果列表，每项包含 result、rect、center_x、center_y、confidence、text。
    """
    rect_params = ""
    if img_inout.rect:
        rect_params = ','.join([str(num) for num in img_inout.rect])

    params = {
        'rect': rect_params,
    }

    response = requests.get(url_counting_color, params)
    response.raise_for_status()
    result = response.json()['value']
    res = []

    for r in result:
        x = r['x']
        y = r['y']
        w = r['w']
        h = r['h']
        txt = r['txt']
        c = r['confidence']
        center_x = x + w / 2
        center_y = y + h / 2
        match = True
        if pattern:
            if not re.search(pattern, txt):
                match = False

        if c >= threshold and match:
            res.append({
                "result": (center_x, center_y),
                "rect": (x, y, x + w, y + h),
                "center_x": center_x,
                "center_y": center_y,
                "confidence": c,
                "text": txt
            })

    return res
