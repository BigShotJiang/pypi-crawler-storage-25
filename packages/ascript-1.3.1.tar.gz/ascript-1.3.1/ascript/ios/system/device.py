from ascript.ios import system
from ascript.ios.developer.api import oc


def get_device_id():
    """获取设备唯一标识符 (UUID)。

    Returns:
        str: 设备的 UUID。
    """
    return system.client.info.uuid


def get_device_name():
    """获取设备名称。

    Returns:
        str: 设备名称。
    """
    return system.client.info.name


def get_device_model():
    """获取设备型号。

    Returns:
        str: 设备型号字符串。
    """
    return system.client.info.model


def get_screen_size():
    """获取设备屏幕尺寸。

    Returns:
        tuple: 屏幕宽高元组 (width, height)。
    """
    return system.client.window_size()


def get_screen_scale():
    """获取设备屏幕缩放比例。

    Returns:
        float: 屏幕缩放比例（如 Retina 屏为 2.0 或 3.0）。
    """
    return system.client.scale


def get_orientation():
    """获取设备当前屏幕方向。

    Returns:
        Orientation: 屏幕方向枚举值。
    """
    return system.client.get_orientation()


def get_battery_info():
    """获取设备电池信息。

    Returns:
        dict: 电池信息字典，包含电量和充电状态等。
    """
    return system.client.battery_info()


def vibrate(duration, intensity=0.5):
    """触发设备振动。

    Args:
        duration: 振动持续时间（毫秒）。
        intensity: 振动强度，取值 0~1 的小数，默认 0.5。
    """
    oc.vibrate(duration, intensity)
