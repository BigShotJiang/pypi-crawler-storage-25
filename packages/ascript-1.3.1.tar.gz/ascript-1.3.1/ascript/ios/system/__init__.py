import json
import os.path
import time
import typing
import requests
from ascript.ios.developer.api import oc, utils, sp_utils
from ascript.ios.wdapy import AppiumClient

# client = AppiumClient()
client = AppiumClient()


class R:
    """资源路径管理类，提供项目资源文件路径的快捷访问方法。"""

    @staticmethod
    def home():
        """获取项目主目录路径。

        Returns:
            str: 项目主目录的绝对路径。
        """
        return utils.home_dir

    @staticmethod
    def root():
        """获取项目根目录路径。

        Returns:
            str: 项目根目录的绝对路径。
        """
        return utils.r_root

    @staticmethod
    def name():
        """获取项目名称。

        Returns:
            str: 项目名称。
        """
        return utils.r_name

    def __init__(self):
        """初始化资源路径管理器。"""
        pass

    @staticmethod
    def res(child: str = None):
        """获取 res 资源目录下指定子路径的完整路径。

        Args:
            child: 资源目录下的子路径。

        Returns:
            str: 完整的资源文件路径。
        """
        return os.path.join(R.root(), "res", child)

    @staticmethod
    def img(child: str = None):
        """获取 res/img 图片资源目录下指定子路径的完整路径。

        Args:
            child: 图片目录下的子路径。

        Returns:
            str: 完整的图片文件路径。
        """
        return os.path.join(R.root(), "res", "img", child)

    @staticmethod
    def ui(child: str = None):
        """获取 res/ui 界面资源目录下指定子路径的完整路径。

        Args:
            child: UI 资源目录下的子路径。

        Returns:
            str: 完整的 UI 资源文件路径。
        """
        return os.path.join(R.root(), "res", "ui", child)

    @staticmethod
    def rel(path: str = __file__, rel_path: str = None):
        """根据基准路径和相对路径计算绝对路径。

        Args:
            path: 基准路径，可以是文件路径或目录路径。如果是文件路径会自动取其所在目录。
            rel_path: 相对路径。

        Returns:
            str: 规范化后的绝对路径。
        """
        if not os.path.isdir(path):
            path = os.path.dirname(path)

        real_path = os.path.join(path, rel_path)
        real_path = os.path.normpath(real_path)

        return real_path

    @staticmethod
    def assets(file_name: str):
        """获取 assets 资源目录下指定文件的完整路径。

        Args:
            file_name: 资源文件名。

        Returns:
            str: 完整的资源文件路径。
        """
        return os.path.join(utils.assets_space, file_name)


def info():
    """获取当前连接设备的基本信息。

    Returns:
        DeviceInfo: 设备信息对象。
    """
    return client.info


def get_uuid():
    """获取当前设备的唯一标识符 (UUID)。

    Returns:
        str: 设备 UUID。
    """
    return oc.getDeviceId()


def get_ios_version():
    """获取当前设备的 iOS 系统版本号。

    Returns:
        str: iOS 系统版本号字符串。
    """
    return oc.getSystemVersion()


def exit():
    """停止当前运行的脚本模块。"""
    requests.get("http://127.0.0.1:9096/api/module/stop")
    # api_module_stop()


def reboot():
    """重启设备（当前未实现）。"""
    print("未实现")


def app_start(bundle_id: str, arguments: typing.List[str] = [],
              environment: typing.Dict[str, str] = {}):
    """启动指定的 iOS 应用。

    Args:
        bundle_id: 应用的 Bundle ID。
        arguments: 可选，启动参数列表。
        environment: 可选，环境变量字典。

    Returns:
        bool: 启动成功返回 True，失败返回 False。
    """
    try:
        client.app_start(bundle_id, arguments, environment)
        return True
    except Exception as e:
        print(str(e))
        return False


def scheme_start(scheme: str):
    """通过 URL Scheme 启动应用或触发功能。

    会先启动当前应用，然后通过 Scheme 触发对应操作。

    Args:
        scheme: URL Scheme 字符串（如 "aswda://"）。
    """
    app_start(oc.get_appBundleID())
    oc.start_scheme(scheme)


def app_stop(bundle_id: str):
    """停止指定的 iOS 应用。

    Args:
        bundle_id: 应用的 Bundle ID。

    Returns:
        bool: 停止结果；如果发生异常返回 None。
    """
    try:
        return client.app_terminate(bundle_id)
    except Exception as e:
        print(str(e))
        return None


def restart_wda(wda_package: str = "com.ascript.webdriveragentrunner.xctrunner"):
    """重启 WebDriverAgent 服务。

    依次执行：启动当前应用、停止 WDA、通过 Scheme 重新启动 WDA、重建客户端连接。

    Args:
        wda_package: WDA 的 Bundle ID，默认 "com.ascript.webdriveragentrunner.xctrunner"。
    """
    app_start(oc.get_appBundleID())
    app_stop(wda_package)
    scheme_start("aswda://")
    global client
    client = AppiumClient()


def app_state(bundle_id: str):
    """获取指定应用的运行状态。

    Args:
        bundle_id: 应用的 Bundle ID。

    Returns:
        int: 应用运行状态码；如果发生异常返回 None。
    """
    try:
        return client.app_state(bundle_id)
    except Exception as e:
        print(str(e))
        return None


def app_current():
    """获取当前前台运行的应用信息。

    Returns:
        dict: 当前前台应用信息；如果发生异常返回 None。
    """
    try:
        return client.app_current()
    except Exception as e:
        print(str(e))
        return None


def app_list():
    """获取设备上已安装的应用列表。

    Returns:
        list: 应用信息列表。
    """
    return client.app_list()


def deactivate(duration: float):
    """将当前应用暂时置于后台，指定时间后恢复。

    Args:
        duration: 后台持续时间（秒）。

    Returns:
        操作结果。
    """
    return client.deactivate(duration)


def open_url(url: str):
    """在设备上打开指定 URL。

    Args:
        url: 要打开的 URL 字符串。

    Returns:
        操作结果。
    """
    return client.open_url(url)


def is_locked():
    """检查设备是否处于锁屏状态。

    Returns:
        bool: 如果设备已锁屏返回 True，否则返回 False。
    """
    return client.is_locked()


def lock():
    """锁定设备屏幕。

    Returns:
        操作结果。
    """
    return client.lock()


def unlock():
    """解锁设备屏幕。

    Returns:
        操作结果。
    """
    return client.unlock()


def set_clipboard(content: str):
    """设置设备剪贴板内容。

    Args:
        content: 要设置的剪贴板文本内容。

    Returns:
        操作结果。
    """
    return oc.set_clipboard(content)


def get_clipboard() -> str:
    """获取设备剪贴板内容。

    会先启动当前应用以确保可以读取剪贴板。

    Returns:
        str: 剪贴板文本内容。
    """
    app_start(oc.get_appBundleID())
    return oc.get_clipboard()


def screen_size():
    """获取设备屏幕尺寸。

    Returns:
        tuple: 屏幕宽高元组 (width, height)。
    """
    return client.window_size()


def screen_orientation():
    """获取设备屏幕方向。

    Returns:
        Orientation: 屏幕方向枚举值。
    """
    return client.get_orientation()


def notify(msg: str, title: str = None, _id: str = "9096"):
    """发送系统通知消息。

    Args:
        msg: 通知消息内容。
        title: 可选，通知标题。默认使用项目名称。
        _id: 通知标识符，默认 "9096"。
    """
    if title is None:
        title = R.name()
    oc.notify(msg=msg, title=title, _id=_id)


class KeyValue:
    """键值对持久化存储工具，用于保存和读取简单的键值数据。"""

    @staticmethod
    def save(key: str, value, space=None):
        """保存键值对。

        Args:
            key: 键名。
            value: 要保存的值。
            space: 可选，命名空间（预留参数，当前未使用）。

        Returns:
            操作结果。
        """
        return oc.save_obj(f"{key}", value)

    @staticmethod
    def get(key: str, default=None, space=None):
        """获取指定键对应的值。

        Args:
            key: 键名。
            default: 可选，当键不存在时返回的默认值。
            space: 可选，命名空间（预留参数，当前未使用）。

        Returns:
            存储的值；如果键不存在则返回 default。
        """
        res = oc.get_obj(f"{key}")
        if res is None:
            return default
        return res


class Control:
    """流程控制工具，用于向客户端发送控制消息（带频率限制）。"""

    last_time = 0

    @staticmethod
    def send(msgs: dict):
        """发送控制消息。

        限制调用频率为至少 0.7 秒一次，过于频繁的调用将被忽略。

        Args:
            msgs: 要发送的消息字典。
        """
        t1 = time.time()
        print("time", t1 - Control.last_time)
        if time.time() - Control.last_time < 0.7:
            print("该函数不能频繁调用")
            return
        if msgs:
            Control.last_time = time.time()
            oc.ws_data(msgs)
