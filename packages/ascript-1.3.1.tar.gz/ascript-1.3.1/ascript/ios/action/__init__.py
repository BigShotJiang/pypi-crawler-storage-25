"""iOS 设备操作模块。

提供对 iOS 设备的触摸、滑动、按键等基本操作功能。
"""

from typing import Union
from ascript.ios import system
from ascript.ios.developer.api import oc
from ascript.ios.screen.gp import Point

KEY_HOME = "home"
KEY_VOLUMEUP = "volumeup"
KEY_volumedown = "volumedown"
KEY_POWER = "power"
KEY_SNAPSHOT = "snapshot"
KEY_POWER_AND_HOME = "power_plus_home"


def click(x, y: int = 0, duration: float = 20):
    """点击屏幕指定坐标位置。

    支持直接传入 Point 对象或分别传入 x、y 坐标。坐标值会根据
    设备缩放比例自动转换。

    Args:
        x: x 坐标值，也可以传入 Point 对象。
        y: y 坐标值。当 x 为 Point 对象时此参数被忽略。
        duration: 点击持续时间，单位为毫秒，默认 20ms。

    Returns:
        None
    """
    if isinstance(x, Point):
        y = x.y
        x = x.x

    x = int(x / system.client.scale)
    y = int(y / system.client.scale)

    system.client.tap(x, y, duration / 1000)




def double_tap(x: int, y: int):
    """双击屏幕指定坐标位置。

    坐标值会根据设备缩放比例自动转换。

    Args:
        x: x 坐标值。
        y: y 坐标值。

    Returns:
        None
    """
    x = int(x / system.client.scale)
    y = int(y / system.client.scale)
    system.client.double_tap(x, y)


def slide(x1: int, y1: int, x2: int, y2: int, duration: float = 200):
    """从起始坐标滑动到目标坐标。

    坐标值会根据设备缩放比例自动转换。

    Args:
        x1: 起始点 x 坐标。
        y1: 起始点 y 坐标。
        x2: 目标点 x 坐标。
        y2: 目标点 y 坐标。
        duration: 滑动持续时间，单位为毫秒，默认 200ms。

    Returns:
        None
    """
    x1 = int(x1 / system.client.scale)
    y1 = int(y1 / system.client.scale)
    x2 = int(x2 / system.client.scale)
    y2 = int(y2 / system.client.scale)
    system.client.swipe(x1, y1, x2, y2, duration / 1000)


def touch_and_slide(from_x: int,
                    from_y: int,
                    to_x: int,
                    to_y: int,
                    touch_down_duration: int = 500,
                    touch_move_duration: int = 1000,
                    touch_up_duration: int = 500):
    """按住并滑动操作，支持自定义按下、移动和抬起各阶段的持续时间。

    模拟手指按下、滑动、抬起的完整触摸过程。坐标值会根据设备缩放比例自动转换。

    Args:
        from_x: 起始点 x 坐标。
        from_y: 起始点 y 坐标。
        to_x: 目标点 x 坐标。
        to_y: 目标点 y 坐标。
        touch_down_duration: 按下阶段持续时间，单位为毫秒，默认 500ms。
        touch_move_duration: 移动阶段持续时间，单位为毫秒，默认 1000ms。
        touch_up_duration: 抬起阶段持续时间，单位为毫秒，默认 500ms。

    Returns:
        None
    """
    from_x = int(from_x / system.client.scale)
    from_y = int(from_y / system.client.scale)
    to_x = int(to_x / system.client.scale)
    to_y = int(to_y / system.client.scale)

    system.client.touch_and_swipe(from_x, from_y, to_x, to_y,
                                  touch_down_duration / 1000, touch_move_duration / 1000, touch_up_duration / 1000)


def slide_left():
    """向左滑动屏幕。

    Returns:
        None
    """
    system.client.swipe_left()


def slide_up():
    """向上滑动屏幕。

    Returns:
        None
    """
    system.client.swipe_up()


def slide_right():
    """向右滑动屏幕。

    Returns:
        None
    """
    system.client.swipe_right()


def slide_down():
    """向下滑动屏幕。

    Returns:
        None
    """
    system.client.swipe_down()


def input(value):
    """输入文本内容。

    内部调用 keys() 方法发送按键。

    Args:
        value: 要输入的文本内容。

    Returns:
        None
    """
    keys(value)


def home():
    """按下 Home 键，返回主屏幕。

    Returns:
        None
    """
    key_press(KEY_HOME)


def keys(value):
    """发送按键序列到设备。

    Args:
        value: 要发送的按键内容。

    Returns:
        None
    """
    system.client.send_keys(value)


def key_press(key):
    """按下指定的物理按键。

    Args:
        key: 按键名称，如 KEY_HOME、KEY_POWER 等常量。

    Returns:
        None
    """
    system.client.press(key)


def key_press_hid(key, duration: float = 20):
    """通过 HID 协议按下指定按键并持续指定时间。

    Args:
        key: 按键标识。
        duration: 按键持续时间，单位为毫秒，默认 20ms。

    Returns:
        None
    """
    system.client.press_duration(key, duration / 1000)
