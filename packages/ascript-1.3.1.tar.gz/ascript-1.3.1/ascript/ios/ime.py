"""iOS 输入法操作模块。

提供文本输入、清除和回车等输入法相关功能。
"""

from ascript.ios.developer.api import oc


def input_text(text: str):
    """通过输入法输入文本内容。

    Args:
        text: 要输入的文本字符串。

    Returns:
        None
    """
    oc.input_text(text)


def input_clear():
    """清除当前输入框中的文本内容。

    Returns:
        None
    """
    oc.input_clear()


def input_enter():
    """模拟按下输入法的回车键。

    Returns:
        None
    """
    oc.input_return()
