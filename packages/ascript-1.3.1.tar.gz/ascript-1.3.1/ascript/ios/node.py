"""iOS 节点查找与操作模块。

提供基于 XPath 的 UI 节点选择器，支持按属性、层级关系查找节点，
并对查找到的节点执行点击、滚动、输入等操作。
"""

from ascript.ios.wdapy._base import BaseClient
from ascript.ios.wdapy._node import Selector as wda_selector, Element
from ascript.ios import system
from ascript.ios.wdapy import _proto


class _Sel:
    """内部选择器条件单元，表示单个 XPath 查询条件。

    用于构建 XPath 查询表达式的基本组成部分，支持属性匹配和层级关系。

    Attributes:
        ATTR: 属性匹配模式常量。
        SHIP: 层级关系模式常量。
        ACTION: 操作模式常量。
        NODE: 节点模式常量。
    """

    ATTR = 0
    SHIP = 1
    ACTION = 2
    NODE = 4

    def __init__(self, mode: int, key: str, value: object, match: int = -1):
        """初始化选择器条件单元。

        Args:
            mode: 条件模式，ATTR 表示属性匹配，SHIP 表示层级关系。
            key: 条件键名，如属性名称或关系类型（parent/child/brother）。
            value: 条件值，根据模式不同含义不同。
            match: 匹配方式，-1 为默认精确匹配，可选 MODE_CONTAINS 等。
        """
        self.mode = mode
        self.key = key
        self.value = value
        self.match = match

    def _make(self):
        """根据条件生成对应的 XPath 片段。

        根据 mode 和 match 的组合，生成属性匹配或层级关系的 XPath 子表达式。

        Returns:
            str: 生成的 XPath 片段字符串。
        """
        xp = ""
        if self.mode == _Sel.ATTR:
            if self.match == Selector.MODE_CONTAINS:
                xp = f'[contains(@{self.key},"{self.value}")]'
            elif self.match == Selector.MODE_GREATER:
                xp = f'[@{self.key}>"{self.value}"]'
            elif self.match == Selector.MODE_LESS:
                xp = f'[@{self.key}<"{self.value}"]'
            else:
                xp = f'[@{self.key}="{self.value}"]'
        elif self.mode == _Sel.SHIP:
            if self.key == "parent":
                if self.value == 0:
                    xp = "/ancestor::*"
                else:
                    for i in range(self.value):
                        xp = xp + '/..'
            elif self.key == "child":
                print(self.value)
                if self.value == 0:
                    xp = xp + '/*'
                elif self.value < 0:
                    xp = f'/*[last() + {self.value + 1}]'
                elif self.value > 0:
                    xp = f'/*[{self.value}]'
            elif self.key == "brother":
                if self.value == 0:
                    xp = f"/../*"
                elif self.value >= 1:
                    xp = f"/../*[{self.value}]"
                elif self.value <= -1:
                    xp = f"/../*[last() + {self.value + 1}]"
                elif 0 < self.value < 1:
                    formatted_str = "{:.1f}".format(self.value)
                    integer_part, decimal_part = formatted_str.split('.')
                    xp = f"/preceding-sibling::*{decimal_part}"
                    pass
                elif -1 < self.value < 0:
                    formatted_str = "{:.1f}".format(self.value)
                    integer_part, decimal_part = formatted_str.split('.')
                    xp = f"/following-sibling::*{decimal_part}"
                    pass

        # print("xp")

        return xp


class Selector:
    """iOS UI 节点选择器，支持链式调用构建查询条件。

    通过链式调用设置各种筛选条件（属性、层级关系等），然后执行查找操作
    获取匹配的 UI 节点元素。支持对查找到的节点执行点击、滚动、输入等操作。

    Attributes:
        MODE_EQUAL: 精确匹配模式。
        MODE_CONTAINS: 包含匹配模式。
        MODE_MATCHES: 正则匹配模式。
        MODE_GREATER: 大于比较模式。
        MODE_LESS: 小于比较模式。
        MODE_CLICK_ACCESS: 无障碍点击模式。
        MODE_CLICK_XY: 坐标点击模式。
        MODE_SCROLL_VISIBLE: 滚动至可见模式。
        MODE_SCROLL_LEFT: 向左滚动模式。
        MODE_SCROLL_RIGHT: 向右滚动模式。
        MODE_SCROLL_UP: 向上滚动模式。
        MODE_SCROLL_DOWN: 向下滚动模式。
    """

    MODE_EQUAL = 0  # 相同
    MODE_CONTAINS = 1
    MODE_MATCHES = 2
    MODE_GREATER = 3  # 大于
    MODE_LESS = 4  # 小于

    MODE_CLICK_ACCESS = 0
    MODE_CLICK_XY = 1

    MODE_SCROLL_VISIBLE = "visible"
    MODE_SCROLL_LEFT = "left"
    MODE_SCROLL_RIGHT = "right"
    MODE_SCROLL_UP = "up"
    MODE_SCROLL_DOWN = "down"

    def __init__(self):
        """初始化选择器，设置所有筛选条件和操作为默认空状态。"""
        self.selector = {}
        self.click_action = None
        self.scroll_action = None
        self.set_text_action = None
        self.clear_text_action = None
        self._xpath = None
        self.package_name = None
        self.package_name_match = None
        self.sel = []

    def find_with_dict(self, client, kv: list, max_nums: int = 99999):
        """通过字典列表配置查询条件并执行查找。

        根据传入的键值对列表动态调用选择器方法设置条件，然后执行查找。

        Args:
            client: WDA 客户端实例。
            kv: 条件字典列表，每项包含 'key'（方法名）和 'params'（参数）。
            max_nums: 最大返回节点数量，默认 99999。

        Returns:
            list: 匹配的节点元素列表。
        """
        self.selector = {}
        print(kv)
        for sel in kv:
            method = getattr(self, sel['key'], None)
            v = sel["params"]
            if method is not None and callable(method):
                if isinstance(v, list):
                    method(*v)
                else:
                    method(v)

        if max_nums > 1:
            return self.find_all(client)[:max_nums]
        else:
            return [self.find(client)]

    def find(self, client=system.client, timeout: int = 120):
        """查找第一个匹配条件的节点元素。

        Args:
            client: WDA 客户端实例，默认使用 system.client。
            timeout: HTTP 请求超时时间，单位为秒，默认 120 秒。

        Returns:
            Element | None: 匹配的第一个节点元素，未找到则返回 None。
        """
        _proto.DEFAULT_HTTP_TIMEOUT = timeout
        elements = self.find_work(client=client, num=1)
        if elements and len(elements) > 0:
            self.append_action([elements[0]])
            return elements[0]

    def find_all(self, client=system.client, timeout: int = 120):
        """查找所有匹配条件的节点元素。

        Args:
            client: WDA 客户端实例，默认使用 system.client。
            timeout: HTTP 请求超时时间，单位为秒，默认 120 秒。

        Returns:
            list: 匹配的节点元素列表。
        """
        _proto.DEFAULT_HTTP_TIMEOUT = timeout
        elements = self.find_work(client)
        self.append_action(elements)
        return elements

    def find_work(self, client=system.client, num: int = -1):
        """执行实际的节点查找工作。

        内部方法，先检查包名条件，再根据 XPath 或选择器条件进行查找。

        Args:
            client: WDA 客户端实例，默认使用 system.client。
            num: 限制返回数量，-1 表示不限制，1 表示只返回第一个。

        Returns:
            list | None: 匹配的节点元素列表，包名不匹配时返回 None。
        """

        if self.package_name:
            if self.package_name_match == Selector.MODE_EQUAL:
                if client.app_current().bundle_id != self.package_name:
                    return None
            else:
                if self.package_name not in client.app_current().bundle_id:
                    return None

        if self._xpath:
            return wda_selector(client, xpath=self._xpath).find_all(num=num)

        if len(self.sel) < 1:
            if num == 1:
                return wda_selector(client, xpath="(//*)[1]").find_all(num=num)
            else:
                return wda_selector(client, xpath="//*").find_all(num=num)

        return wda_selector(client, xpath=self._make_xpath()).find_all(num=num)
        # self._make_xpath()
        # return []

    def _make_xpath(self):
        """根据已添加的选择器条件列表生成完整的 XPath 表达式。

        Returns:
            str: 组合后的 XPath 查询字符串。
        """
        xpath = ""
        for sel in self.sel:
            if xpath == "" and sel.mode == _Sel.ATTR:
                xpath = "//*"
            xpath = xpath + sel._make()
        # print("xpath组合:", xpath)
        return xpath

    def append_action(self, elements):
        """对查找到的节点元素执行已设置的操作。

        根据已设置的 click_action、scroll_action、clear_text_action、
        set_text_action 对每个元素依次执行相应操作。

        Args:
            elements: 要执行操作的节点元素列表。

        Returns:
            None
        """
        for element in elements:
            # print(self.click_action,type(self.click_action), Selector.MODE_CLICK_ACCESS, Selector.MODE_CLICK_XY)
            if self.click_action == Selector.MODE_CLICK_XY:
                element.tap()
            elif self.click_action == Selector.MODE_CLICK_ACCESS:
                element.tap()

            if self.scroll_action:
                # print(self.scroll_action)
                element.scroll(self.scroll_action["mode"], self.scroll_action["distance"])

            if self.clear_text_action:
                element.clear_text()

            if self.set_text_action is not None:
                if self.set_text_action == "":
                    element.clear_text()
                else:
                    element.set_text(self.set_text_action)

    @staticmethod
    def xml():
        """获取当前页面的 XML 源码。

        Returns:
            str: 当前页面的 UI 层级 XML 字符串。
        """
        return system.client.source()

    def node(self, value, mode=MODE_EQUAL):
        """按节点值筛选。

        Args:
            value: 节点值。
            mode: 匹配模式，默认精确匹配。

        Returns:
            Selector: 返回自身以支持链式调用。
        """
        if value is None:
            return self
        self.sel.append(_Sel(mode=_Sel.NODE, key="value", value=value, match=mode))
        return self

    def value(self, value, mode=MODE_EQUAL):
        """按 value 属性筛选节点。

        Args:
            value: 属性值。
            mode: 匹配模式，默认精确匹配。

        Returns:
            Selector: 返回自身以支持链式调用。
        """
        if value is None:
            return self
        self.sel.append(_Sel(mode=_Sel.ATTR, key="value", value=value, match=mode))
        return self

    def name(self, value: str, mode=MODE_EQUAL):
        """按 name 属性筛选节点。

        Args:
            value: 名称值。
            mode: 匹配模式，默认精确匹配。

        Returns:
            Selector: 返回自身以支持链式调用。
        """
        if value is None:
            return self
        self.sel.append(_Sel(mode=_Sel.ATTR, key="name", value=value, match=mode))
        return self

    def label(self, value: str, mode=MODE_EQUAL):
        """按 label 属性筛选节点。

        Args:
            value: 标签值。
            mode: 匹配模式，默认精确匹配。

        Returns:
            Selector: 返回自身以支持链式调用。
        """
        if value is None:
            return self
        self.sel.append(_Sel(mode=_Sel.ATTR, key="label", value=value, match=mode))
        return self

    def type(self, value, mode=MODE_EQUAL):
        """按 type 属性筛选节点。

        Args:
            value: 节点类型值。
            mode: 匹配模式，默认精确匹配。

        Returns:
            Selector: 返回自身以支持链式调用。
        """
        if value is None:
            return self
        self.sel.append(_Sel(mode=_Sel.ATTR, key="type", value=value, match=mode))
        return self

    def visible(self, value: bool):
        """按可见性筛选节点。

        Args:
            value: True 表示可见，False 表示不可见。

        Returns:
            Selector: 返回自身以支持链式调用。
        """
        if value is None:
            return self
        if value:
            p_value = "true"
        else:
            p_value = "false"

        self.sel.append(_Sel(mode=_Sel.ATTR, key="visible", value=p_value))
        return self

    def enabled(self, value: bool):
        """按是否启用状态筛选节点。

        Args:
            value: True 表示已启用，False 表示已禁用。

        Returns:
            Selector: 返回自身以支持链式调用。
        """
        if value is None:
            return self
        if value:
            value = "true"
        else:
            value = "false"
        self.sel.append(_Sel(mode=_Sel.ATTR, key="enabled", value=value))
        return self

    def accessible(self, value: bool):
        """按无障碍访问属性筛选节点。

        Args:
            value: True 表示支持无障碍访问，False 表示不支持。

        Returns:
            Selector: 返回自身以支持链式调用。
        """
        if value is None:
            return self
        if value:
            value = "true"
        else:
            value = "false"
        self.sel.append(_Sel(mode=_Sel.ATTR, key="accessible", value=value))
        return self

    def index(self, value: int, mode: int = MODE_EQUAL):
        """按索引位置筛选节点。

        Args:
            value: 索引值。
            mode: 匹配模式，默认精确匹配，可选大于/小于。

        Returns:
            Selector: 返回自身以支持链式调用。
        """
        if value is None:
            return self
        self.sel.append(_Sel(mode=_Sel.ATTR, key="index", value=value, match=mode))
        return self

    def x(self, value: int, mode: int = MODE_EQUAL):
        """按 x 坐标筛选节点。

        Args:
            value: x 坐标值。
            mode: 匹配模式，默认精确匹配。

        Returns:
            Selector: 返回自身以支持链式调用。
        """
        if value is None:
            return self
        self.sel.append(_Sel(mode=_Sel.ATTR, key="x", value=value, match=mode))
        return self

    def y(self, value: int, mode: int = MODE_EQUAL):
        """按 y 坐标筛选节点。

        Args:
            value: y 坐标值。
            mode: 匹配模式，默认精确匹配。

        Returns:
            Selector: 返回自身以支持链式调用。
        """
        if value is None:
            return self
        self.sel.append(_Sel(mode=_Sel.ATTR, key="y", value=value, match=mode))
        return self

    def width(self, value: int, mode: int = MODE_EQUAL):
        """按宽度筛选节点。

        Args:
            value: 宽度值。
            mode: 匹配模式，默认精确匹配。

        Returns:
            Selector: 返回自身以支持链式调用。
        """
        if value is None:
            return self
        self.sel.append(_Sel(mode=_Sel.ATTR, key="width", value=value, match=mode))
        return self

    def height(self, value: int, mode: int = MODE_EQUAL):
        """按高度筛选节点。

        Args:
            value: 高度值。
            mode: 匹配模式，默认精确匹配。

        Returns:
            Selector: 返回自身以支持链式调用。
        """
        if value is None:
            return self
        self.sel.append(_Sel(mode=_Sel.ATTR, key="height", value=value, match=mode))
        return self

    def child(self, value: float = 0):
        """按子节点关系筛选。

        Args:
            value: 子节点索引。0 表示所有子节点，正数表示第 N 个子节点，
                   负数表示倒数第 N 个子节点。

        Returns:
            Selector: 返回自身以支持链式调用。
        """
        if value is None:
            return self
        self.sel.append(_Sel(mode=_Sel.SHIP, key="child", value=value))
        return self

    def parent(self, value: int = 0):
        """按父节点关系筛选。

        Args:
            value: 向上追溯的层级数。0 表示所有祖先节点，正数表示向上 N 层。

        Returns:
            Selector: 返回自身以支持链式调用。
        """
        if value is None:
            return self
        self.sel.append(_Sel(mode=_Sel.SHIP, key="parent", value=value))
        return self

    def brother(self, value: float = 0):
        """按兄弟节点关系筛选。

        Args:
            value: 兄弟节点索引。0 表示所有兄弟节点，正整数表示第 N 个兄弟，
                   负整数表示倒数第 N 个，小数部分用于前后兄弟定位。

        Returns:
            Selector: 返回自身以支持链式调用。
        """
        if value is None:
            return self
        self.sel.append(_Sel(mode=_Sel.SHIP, key="brother", value=value))
        return self

    def xpath(self, value: str):
        """直接设置 XPath 表达式进行查找。

        设置后将忽略其他属性条件，直接使用此 XPath 查找。

        Args:
            value: XPath 表达式字符串。

        Returns:
            Selector: 返回自身以支持链式调用。
        """
        if value is None:
            return self
        self._xpath = value
        return self

    def predicate(self, value: str):
        """设置 NSPredicate 查询条件。

        Args:
            value: NSPredicate 格式的查询字符串。

        Returns:
            Selector: 返回自身以支持链式调用。
        """
        self.selector["predicate"] = value
        return self

    def click(self, mode=MODE_CLICK_XY):
        """设置查找到节点后执行点击操作。

        Args:
            mode: 点击模式，MODE_CLICK_XY 为坐标点击，MODE_CLICK_ACCESS 为无障碍点击。

        Returns:
            Selector: 返回自身以支持链式调用。
        """
        self.click_action = mode
        return self

    def scroll(self, mode=MODE_SCROLL_VISIBLE, distance: float = 1.0):
        """设置查找到节点后执行滚动操作。

        Args:
            mode: 滚动方向，可选 MODE_SCROLL_VISIBLE/LEFT/RIGHT/UP/DOWN。
            distance: 滚动距离，默认 1.0。

        Returns:
            Selector: 返回自身以支持链式调用。
        """
        self.scroll_action = {"mode": mode, "distance": distance}
        return self

    def input(self, value):
        """设置查找到节点后执行文本输入操作。

        Args:
            value: 要输入的文本内容。传入空字符串将清除文本。

        Returns:
            Selector: 返回自身以支持链式调用。
        """
        self.set_text_action = value
        return self

    def clear_text(self, *args):
        """设置查找到节点后清除文本内容。

        Args:
            *args: 保留参数，暂未使用。

        Returns:
            Selector: 返回自身以支持链式调用。
        """
        self.clear_text_action = 1
        return self

    def package(self, value, mode=MODE_EQUAL):
        """设置包名（Bundle ID）前置校验条件。

        查找前会先检查当前前台应用的 Bundle ID 是否满足条件。

        Args:
            value: 包名（Bundle ID）值。
            mode: 匹配模式，MODE_EQUAL 为精确匹配，其他为包含匹配。

        Returns:
            Selector: 返回自身以支持链式调用。
        """
        self.package_name = value
        self.package_name_match = mode
        return self


class Node(Element):
    """iOS UI 节点元素，继承自 Element。

    表示一个具体的 UI 节点，可通过 session 和元素 ID 进行操作。
    """

    # http://127.0.0.1:58817/session/A93BC308-3B79-42D0-B13C-240DA9D3D953/element/BF000000-0000-0000-2000-000000000000/attribute/rect
    def __init__(self, session: BaseClient, id: str):
        """初始化节点元素。

        Args:
            session: WDA 客户端会话实例。
            id: 元素的唯一标识符。
        """
        super().__init__(session, id)
