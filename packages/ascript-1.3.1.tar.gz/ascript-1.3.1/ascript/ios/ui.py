"""iOS UI 窗口模块。

提供 Web 窗口和悬浮窗口的创建与管理功能。
"""

import uuid

from ascript.ios import system
from ascript.ios.developer.api import oc, utils


class WebWindow:
    """Web 窗口组件，用于在 iOS 设备上展示 Web 页面界面。

    支持显示、关闭窗口以及与页面中的 JavaScript 进行交互。
    """

    def __init__(self, ui_path: str, tunner=None):
        """初始化 Web 窗口。

        Args:
            ui_path: Web 页面文件路径。
            tunner: 通道回调对象，用于 JS 与 Python 之间的通信，可选。
        """
        self.uid = str(uuid.uuid4())
        self.ui_path = ui_path
        self.tunner = tunner
        utils.ui_instance[self.uid] = self

    def show(self):
        """显示 Web 窗口并将应用切换到前台。

        Returns:
            None
        """
        oc.show_webui(uid=self.uid, ui_path=self.ui_path)
        system.app_start(oc.get_appBundleID())

    def call(self, js_fun: str):
        """调用 Web 页面中的 JavaScript 函数。

        Args:
            js_fun: 要调用的 JavaScript 函数字符串。

        Returns:
            None
        """
        oc.tunner_py_call_jsfun(self.uid, js_fun)

    def close(self):
        """关闭 Web 窗口。

        Returns:
            None
        """
        oc.close_webui(uid=self.uid)


class FloatWindow:
    """悬浮窗口（画中画）组件，用于控制 iOS 画中画悬浮窗的显示和隐藏。"""

    @staticmethod
    def hidden():
        """隐藏画中画悬浮窗口。

        Returns:
            None
        """
        oc.hiddenPictureInPicture()

    @staticmethod
    def hide():
        """隐藏画中画悬浮窗口。

        与 hidden() 功能相同，提供别名方法。

        Returns:
            None
        """
        oc.hiddenPictureInPicture()

    @staticmethod
    def show():
        """显示画中画悬浮窗口。

        Returns:
            None
        """
        oc.showPictureInPicture()
