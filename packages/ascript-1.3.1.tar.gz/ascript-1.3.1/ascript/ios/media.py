"""iOS 媒体操作模块。

提供音频播放、停止以及图片和视频保存到相册等功能。
"""

from ascript.ios.developer.api import oc, utils


def audio_play(path: str, callback=None, volume: float = -1):
    """播放音频文件。

    Args:
        path: 音频文件路径。
        callback: 播放完成后的回调函数，可选。
        volume: 播放音量，-1 表示使用系统默认音量。

    Returns:
        str: 音频播放实例的唯一标识 ID，可用于后续停止操作。
    """
    mid = oc.media_audio_play(path, volume=volume)
    if callback:
        utils.audio_pool[mid] = callback

    return mid


def audio_stop(a_id):
    """停止正在播放的音频。

    Args:
        a_id: 音频播放实例的唯一标识 ID，由 audio_play 返回。

    Returns:
        None
    """
    oc.media_audio_stop(a_id)


def save_pic2photo(address: str):
    """将图片保存到系统相册。

    Args:
        address: 图片文件路径或 URL 地址。

    Returns:
        保存操作的结果。
    """
    return oc.save_pic2photo(address)


def save_video2photo(address: str):
    """将视频保存到系统相册。

    Args:
        address: 视频文件路径或 URL 地址。

    Returns:
        保存操作的结果。
    """
    return oc.save_video2photo(address)
