from __future__ import annotations

import json
import logging
import os
import re
import shlex
import subprocess
import sys
from argparse import ArgumentParser
from contextlib import nullcontext
from functools import cached_property
from io import IOBase
from pathlib import Path
from shutil import which
from typing import IO, Literal, NamedTuple
from urllib.parse import urlparse

from tf_glue.tofu import Tofu
from tf_glue.utils import DetailedCalledProcessError, InvalidContent, get_proxy_url


class Incus:
    def __init__(
        self,
        *,
        remote: str | None = None,
        project: str | None = None,
        network: str | None = None,
        pool: str | None = None,
        cwd: str | os.PathLike | None = None,
    ):
        self._remote = remote
        self._project = project
        self._network = network
        self._pool = pool
        self._cwd = Path(cwd) if cwd else Path.cwd()

        self._tofu = Tofu(cwd=self._cwd)
        tfvars_path = self._tofu.get_tfvars_path()
        if tfvars_path.exists():
            self._load_tfvars(tfvars_path)

        self._logger = logging.getLogger(f"{self.__class__.__module__}.{self.__class__.__qualname__}")

    def _load_tfvars(self, path: str | os.PathLike | None = None):
        """
        Configure the Incus client instance from a tfvars file.

        :param path: Path to the tfvars file. If None, "variables.auto.tfvars" will be used.
        """
        data = self._tofu.read_tfvars(path)
        self._remote = data.get("incus_remote")
        self._project = data.get("incus_project")
        self._network = data.get("incus_network")
        self._pool = data.get("incus_pool")

    def load_inventory(self, path: str | os.PathLike | None = None):
        """
        Configure the Incus client from an Ansible inventory using the "community.general.incus" connection plugin.

        :param path: Path to the Ansible inventory file or directory. If None, the default inventory (typically configured in `ansible.cfg`) will be used.
        """
        args = ["ansible-inventory", "--list"]
        if path:
            args += ["-i", path]
        self._logger.debug("Run command: %s", args)
        output = subprocess.check_output(args, cwd=self._cwd, text=True)
        data = json.loads(output)
        remote = None
        project = None
        network = None
        pool = None
        for host, host_vars in data["_meta"]["hostvars"].items():
            if host_vars.get("ansible_connection") != "community.general.incus":
                raise ValueError("Host %r does not use the incus connection plugin" % (host,))

            host_remote = host_vars.get("ansible_incus_remote") or "local"
            if not remote:
                remote = host_remote
            elif remote != host_remote:
                raise ValueError("Host %r has a different 'ansible_incus_remote' value than previous hosts" % (host,))

            host_project = host_vars.get("ansible_incus_project") or "default"
            if not project:
                project = host_project
            elif project != host_project:
                raise ValueError("Host %r has a different 'ansible_incus_project' value than previous hosts" % (host,))

            host_network = host_vars.get("ansible_incus_network")
            if host_network:
                if not network:
                    network = host_network
                elif network != host_network:
                    raise ValueError(
                        "Host %r has a different 'ansible_incus_network' value than previous hosts" % (host,)
                    )

            host_pool = host_vars.get("ansible_incus_pool")
            if host_pool:
                if not pool:
                    pool = host_pool
                elif pool != host_pool:
                    raise ValueError("Host %r has a different 'ansible_incus_pool' value than previous hosts" % (host,))

        if not remote or not project:
            raise ValueError("No host in the Ansible inventory")

        self._remote = remote
        self._project = project
        self._network = network
        self._pool = pool

    @cached_property
    def exe(self) -> str:
        result = which("incus")
        if result is None:
            raise FileNotFoundError("No 'incus' executable found")
        return result

    @property
    def remote(self) -> str:
        if self._remote is None:
            args = ["remote", "list", "-f", "csv", "-c", "n"]
            results = self.run(args, capture=True, no_remote=True, no_project=True).stdout.splitlines()

            for result in results:
                if m := re.match(r"^(.+) \(current\)$", result):
                    self._remote = m[1]
                    break

            if self._remote is None:
                raise RuntimeError("Failed to determine the current Incus remote: %s" % results)
        return self._remote

    @property
    def project(self) -> str:
        if self._project is None:
            self._project = self.run(["project", "get-current"], capture=True, no_project=True).stdout.strip()
        return self._project

    @property
    def network(self) -> str:
        """Name of the default network to use for this client."""
        if self._network is None:
            try:
                cp = self.run(["network", "list", "--format", "json"], capture=True)
                networks = [data["name"] for data in json.loads(cp.stdout) if data["managed"]]
                networks.sort(key=lambda n: 0 if n.startswith("incus") else 1)
                if len(networks) == 0:
                    self._network = f"incusbr-{os.getuid()}"
                else:
                    self._network = networks[0]
            except subprocess.CalledProcessError:
                # No permission to view the list of networks
                self._network = f"incusbr-{os.getuid()}"
        return self._network

    @property
    def pool(self) -> str:
        """Name of the default storage pool to use for this client."""
        if self._pool is None:
            try:
                cp = self.run(["storage", "list", "--format", "json"], capture=True)
                pools = [data["name"] for data in json.loads(cp.stdout)]
                if len(pools) == 0:
                    self._pool = "default"
                else:
                    self._pool = pools[0]
            except subprocess.CalledProcessError:
                # No permission to view the list of storage pools
                self._pool = "default"
        return self._pool

    @cached_property
    def remote_url(self):
        """Remote URL (as returned by command `incus remote list`, "unix://" for local unix socket)."""
        data = json.loads(self.run(["remote", "list", "--format", "json"], capture=True).stdout)
        return data[self.remote]["Addr"]

    @cached_property
    def remote_host(self):
        """Remote host (e.g. "127.0.0.1" instead of "unix://")."""
        if self.remote_url == "unix://":
            return "127.0.0.1"
        else:
            return urlparse(self.remote_url).hostname

    @cached_property
    def s3_endpoint(self) -> str | None:
        cp = self.run(["config", "get", "core.storage_buckets_address"], capture=True)
        address = cp.stdout.strip()

        m = re.match(r"^(.*):(\d+)$", address)
        if not m:
            raise ValueError("Unexpected format for Incus setting %s: %r" % ("core.storage_buckets_address", address))
        host = m[1] or self.remote_host
        port = int(m[2])
        return f"https://{host}:{port}"

    def print(self, out: str | os.PathLike | IO = sys.stdout):
        """
        Print information about the Incus configuration used.

        :param out: Output stream.
        """
        with open(out, "a", encoding="utf-8") if not isinstance(out, (IOBase, IO)) else nullcontext(out) as f:
            print(f"Remote:         {self.remote}", file=f)
            print(f"Remote URL:     {self.remote_url}", file=f)
            print(f"Project:        {self.project}", file=f)
            print(f"Network:        {self.network}", file=f)
            print(f"Storage pool:   {self.pool}", file=f)
            print(f"S3 endpoint:    {self.s3_endpoint}", file=f)

    @staticmethod
    def _bucket_add_arguments(parser: ArgumentParser):
        param_helps = getattr(parser, "param_helps", {})
        parser.add_argument("name", help=param_helps.get("name"))

        group = parser.add_mutually_exclusive_group()
        group.add_argument("-c", "--create", action="store_true", help="Create the bucket if it does not exist.")
        group.add_argument(
            "--recreate",
            action="store_const",
            dest="create",
            const="recreate",
            help="Drop the bucket if it exists and (re)create it.",
        )

        group = parser.add_mutually_exclusive_group()
        group.add_argument(
            "--tfbackend",
            action="store_const",
            dest="out",
            const="tfbackend",
            help="Verify the associated tfbackend file if it exists, create it if not.",
        )
        group.add_argument(
            "--tfbackend-fix",
            action="store_const",
            dest="out",
            const="tfbackend-fix",
            help="Recreate the associated tfbackend file if it is invalid, create it if it does not exist.",
        )

    def bucket(
        self, name: str, *, create: bool | Literal["recreate"] = False, out: str | os.PathLike | IO | None = None
    ) -> BucketInfo:
        """
        Get information about an Incus S3 bucket, optionally create it if it does not exist.

        This returns the following data:
        - name: The actual name of the bucket.
        - s3_url: The S3 URL of the bucket.
        - access_key: The access key to use to administrate the bucket.
        - secret_key: The secret key to use to administrate the bucket.

        :param name: Name of the bucket.
        :param create: If true, create the bucket if it does not exist. If "recreate", drop the bucket if it exists and (re)create it.
        :param out: Output stream. If "tfbackend" or ends with ".tfbackend", verify the associated tfbackend file if it exists, create it if not. If "tfbackend-fix", recreate the associated tfbackend file if it is invalid.
        """
        output_data = None

        cp = self.run(["storage", "bucket", "show", self.pool, name], check=False, capture=True)
        if cp.returncode == 0:
            if create == "recreate":
                self._logger.info("Drop bucket %r", name)
                self.run(["storage", "bucket", "delete", self.pool, name], check=True)

                output_data = None
            else:
                # Retrieve existing bucket info
                output_data = parse_incus_output_keyvalues(cp.stdout)

                # Retrieve admin key info
                cp = self.run(["storage", "bucket", "key", "show", self.pool, name, "admin"], capture=True)
                key_data = parse_incus_output_keyvalues(cp.stdout)
                output_data["access_key"] = key_data.get("access-key")
                output_data["secret_key"] = key_data.get("secret-key")

        # Create the bucket
        if output_data is None:
            if create:
                self._logger.info("Create bucket %r", name)
                try:
                    cp = self.run(["storage", "bucket", "create", self.pool, name], capture=True)
                except subprocess.CalledProcessError as err:
                    if err.stderr:
                        # Incus relies on MinIO for bucket storage. Zabbly packages (cf. https://github.com/zabbly/incus) include it, but Debian packages does not so we have to install it manually.
                        instructions = []

                        if which("apt"):
                            if proxy_url := get_proxy_url():
                                instructions.append(f"export https_proxy={proxy_url}")
                            instructions.append("wget https://dl.min.io/server/minio/release/linux-amd64/minio.deb")
                            instructions.append("sudo apt install ./minio.deb")
                            instructions.append("rm ./minio.deb")
                            instructions.append("sudo ln -s /usr/local/bin/minio /usr/bin/minio")

                        if "Couldn't find the MinIO client tool" in err.stderr:
                            message = "Missing MinIO."
                            if instructions:
                                instructions.insert(0, "sudo apt install minio-client")
                                message += f" Please run: {' && '.join(instructions)}"
                            raise RuntimeError(message) from err

                        if '"minio": executable file not found in $PATH' in err.stderr:
                            message = "Missing MinIO executable."
                            if instructions:
                                message += f" Please run: {' && '.join(instructions)}"
                            raise RuntimeError(message) from err

                    raise

                key_data = parse_incus_output_keyvalues(cp.stdout)

                cp = self.run(["storage", "bucket", "show", self.pool, name], capture=True)
                output_data = parse_incus_output_keyvalues(cp.stdout)
                output_data["access_key"] = key_data.get("Admin access key")
                output_data["secret_key"] = key_data.get("Admin secret key")

            else:
                raise BucketNotFound("Bucket %r does not exist" % (name,))

        # Get bucket info
        actual_name = output_data.get("name")
        if not actual_name:
            raise RuntimeError("Failed to parse bucket show output: missing 'name'")

        s3_url = output_data.get("s3_url")
        if s3_url is None:
            raise RuntimeError("Failed to parse bucket show output: missing 's3_url'")
        if s3_url == "":
            raise RuntimeError(
                "Storage buckets address not configured. Please run: sudo incus config set core.storage_buckets_address :8555"
            )

        if s3_url.startswith("https://[::]:"):
            s3_url = "https://" + self.remote_host + ":" + s3_url[len("https://[::]:") :]

        access_key = output_data.get("access_key")
        secret_key = output_data.get("secret_key")
        if not access_key or not secret_key:
            raise RuntimeError("Failed to parse output: missing access key or secret key")

        result = BucketInfo(
            name=actual_name,
            s3_url=s3_url,
            access_key=access_key,
            secret_key=secret_key,
        )

        if out is not None:
            tfbackend_path = False
            tfbackend_verify = "fix" if create == "recreate" else True
            if out == "tfbackend":
                tfbackend_path = None
            elif out == "tfbackend-fix":
                tfbackend_path = None
                tfbackend_verify = "fix"
            elif not isinstance(out, (IOBase, IO)) and str(out).endswith(".tfbackend"):
                tfbackend_path = out

            if tfbackend_path is False:
                result.print(out)
            else:
                try:
                    self._tofu.write_tfbackend(result, tfbackend_path, verify=tfbackend_verify)
                except InvalidContent as err:
                    self._logger.error(err)

        return result

    setattr(bucket, "add_arguments", _bucket_add_arguments)

    def run(
        self, args: list[str] | str, *, check=True, capture=False, no_remote=False, no_project=False
    ) -> subprocess.CompletedProcess[str]:
        if isinstance(args, str):
            args = shlex.split(args)
        cmd = [self.exe] + args

        env = {**os.environ}
        if not no_remote:
            if self.remote:
                env["INCUS_REMOTE"] = self.remote
        if not no_project:
            if self.project:
                env["INCUS_PROJECT"] = self.project

        self._logger.debug("Run command: %s", cmd)
        cp = subprocess.run(
            cmd,
            env=env,
            cwd=self._cwd,
            text=True,
            check=False,
            stdout=subprocess.PIPE if capture else None,
            stderr=subprocess.PIPE if capture else None,
        )

        if check and cp.returncode != 0:
            raise DetailedCalledProcessError(cp.returncode, cmd, output=cp.stdout, stderr=cp.stderr)
        return cp


class BucketInfo(NamedTuple):
    name: str
    """ The actual name of the bucket. """

    s3_url: str
    """ The S3 URL of the bucket. """

    access_key: str
    """ The access key to use to administrate the bucket. """

    secret_key: str
    """ The secret key to use to administrate the bucket. """

    @property
    def s3_endpoint(self) -> str:
        return self.s3_url.removesuffix(f"/{self.name}")

    def print(self, out: str | os.PathLike | IO = sys.stdout):
        with open(out, "a", encoding="utf-8") if not isinstance(out, (IOBase, IO)) else nullcontext(out) as f:
            print(f"Bucket name:    {self.name}", file=f)
            print(f"S3 URL:         {self.s3_url}", file=f)
            print(f"Access key:     {self.access_key}", file=f)
            print(f"Secret key:     {self.secret_key}", file=f)


class BucketNotFound(RuntimeError):
    pass


def parse_incus_output_keyvalues(output: str) -> dict[str, str | None]:
    result = {}
    for line in output.splitlines():
        m = re.match(r"^([^:]+):(.*)$", line)
        if not m:
            continue
        key = m[1].strip()
        value = m[2].strip()
        if value == "none":
            value = None
        elif m := re.match(r'^"(.*)"$', value):
            value = m[1]
        result[key] = value
    return result
