from __future__ import annotations

import logging
import os
import re
import subprocess
from functools import cached_property
from pathlib import Path
from shutil import which
from typing import TYPE_CHECKING, Any, Literal

from tf_glue.utils import InvalidContent, get_proxy_url

if TYPE_CHECKING:
    from tf_glue.incus import BucketInfo, Incus

default_tfvars_filename = "variables.auto.tfvars"
default_tfbackend_filename = "backend.tfbackend"

_logger = logging.getLogger(__name__)
_lock_filename = ".terraform.lock.hcl"


class Tofu:
    def __init__(self, *, cwd: str | os.PathLike | None = None):
        self._cwd = Path(cwd) if cwd else Path.cwd()
        self._logger = logging.getLogger(f"{self.__class__.__module__}.{self.__class__.__qualname__}")

    def init(
        self,
        dir: str | os.PathLike | None = None,
        *,
        incus: "Incus | None" = None,
        bucket: "BucketInfo | str | bool | None" = None,
        fix=False,
    ) -> int:
        """
        Initialize OpenTofu.

        :param incus: Create "variables.auto.tfvars" (if it does not already exist) to configure access to the given Incus client.
        :param bucket: [-b] Create "backend.tfbackend" (if it does not already exist) to configure access to the given Incus S3 bucket. The bucket is created if it does not exist.
        :param fix: [-f] Fix tfvars and tfbackend file if they do not match the expected content.
        """
        if not dir:
            dir = self._cwd
        else:
            dir = Path(dir)

        if incus:
            tfvars = {
                "incus_remote": incus.remote,
                "incus_project": incus.project,
                "incus_network": incus.network,
                "incus_pool": incus.pool,
            }
            try:
                self.write_tfvars(tfvars, dir, verify="fix" if fix else True)
            except InvalidContent as err:
                self._logger.error(err)

        if bucket:
            from tf_glue.incus import BucketInfo

            if not incus:
                raise ValueError("Argument 'bucket' cannot be used without argument 'incus'")

            if bucket is True:
                bucket = dir.name
            if isinstance(bucket, BucketInfo):
                if bucket.s3_endpoint != incus.s3_endpoint:
                    raise ValueError(
                        "Invalid S3 endpoint for bucket: %s (expected Incus S3 endpoint: %s)"
                        % (bucket.s3_endpoint, incus.s3_endpoint)
                    )
                bucket = incus.bucket(bucket.name)
            else:
                bucket = incus.bucket(bucket, create=True)

            try:
                self.write_tfbackend(bucket, dir, verify="fix" if fix else True)
            except InvalidContent as err:
                self._logger.error(err)

        # Run tofu init if necessary
        if dir.joinpath(_lock_filename).exists():
            _logger.info("OpenTofu is already initialized")
            return 0

        if proxy_url := get_proxy_url():
            env = {**os.environ, "HTTPS_PROXY": proxy_url}
        else:
            env = os.environ

        _logger.info("Initialize OpenTofu")
        cmd = [self.exe, f"-chdir={dir}", "init", "-backend-config=backend.tfbackend"]
        _logger.debug("Run command: %s", cmd)
        cp = subprocess.run(cmd, env=env)
        return cp.returncode

    @cached_property
    def exe(self) -> str:
        result = which("tofu") or which("terraform")
        if result is None:
            raise FileNotFoundError("No 'tofu' or 'terraform' executable found")
        return result

    def get_tfvars_path(self, file: str | os.PathLike | None = None) -> Path:
        if not file:
            file = self._cwd.joinpath(default_tfvars_filename)
        else:
            file = Path(file)
            if file.is_dir():
                file = file.joinpath(default_tfvars_filename)
        return file

    def get_tfbackend_path(self, file: str | os.PathLike | None = None) -> Path:
        if not file:
            file = self._cwd.joinpath(default_tfbackend_filename)
        else:
            file = Path(file)
            if file.is_dir():
                file = file.joinpath(default_tfbackend_filename)
        return file

    def read_tfvars(self, file: str | os.PathLike | None = None) -> dict[str, Any]:
        file = self.get_tfvars_path(file)

        results = {}

        _logger.debug("Read tfvars file: %s", file)
        with open(file) as f:
            for line_num, line in enumerate(f, start=1):
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if not (m := re.match(r"^([^=]+)=(.*)$", line)):
                    _logger.warning(f"Ignore invalid line {line_num} in tfvars: {line}")
                    continue

                key = m[1].strip()
                value = m[2].strip()
                results[key] = parse_tfvar(value)

        return results

    def write_tfvars(
        self, tfvars: dict[str, Any], file: str | os.PathLike | None = None, *, verify: bool | Literal["fix"] = False
    ):
        file = self.get_tfvars_path(file)

        if file.exists():
            if not verify:
                raise FileExistsError("File already exists: %s" % file)

            existing_tfvars = self.read_tfvars(file)

            differences = ""
            for key, value in tfvars.items():
                existing_value = existing_tfvars.get(key)
                if existing_value != value:
                    differences += ("\n" if differences else "") + f"- {key}: {existing_value} (expected {value})"

            if not differences:
                _logger.debug("Verified tfvars file: %s", file)
                return

            if verify == "fix":
                _logger.info("Remove invalid tfvars file: %s", file)
                for key, value in existing_tfvars.items():
                    if not key in tfvars:
                        tfvars[key] = value
                file.unlink()
            else:
                raise InvalidContent(
                    "Existing tfvars file (%s) does not match expected content:\n%s" % (file, differences)
                )

        _logger.info("Create tfvars file: %s", file)
        file.parent.mkdir(parents=True, exist_ok=True)
        with open(file, "w") as f:
            for key, value in tfvars.items():
                print(f"{key} = {escape_tfvar(value)}", file=f)

    def write_tfbackend(
        self, bucket: BucketInfo, file: str | os.PathLike | None = None, *, verify: bool | Literal["fix"] = False
    ):
        file = self.get_tfbackend_path(file)

        content = ""
        content += f"bucket                      = {escape_tfvar(bucket.name)}\n"
        content += f"key                         = {escape_tfvar('tfstate')}\n"
        content += f'region                      = "local"\n'
        content += f"endpoints                   = {{ s3 = {escape_tfvar(bucket.s3_endpoint)} }}\n"
        content += f"\n"
        content += f"access_key                  = {escape_tfvar(bucket.access_key)}\n"
        content += f"secret_key                  = {escape_tfvar(bucket.secret_key)}\n"
        content += f"\n"
        content += f"insecure                    = true\n"
        content += f"skip_credentials_validation = true\n"
        content += f"skip_region_validation      = true\n"
        content += f"skip_metadata_api_check     = true\n"
        content += f"use_path_style              = true\n"

        if file.exists():
            if not verify:
                raise FileExistsError("File already exists: %s" % file)

            actual_content = file.read_text()
            if actual_content == content:
                _logger.debug("Verified tfbackend file: %s", file)
                return

            if verify == "fix":
                _logger.info("Remove invalid tfbackend file: %s", file)
                file.unlink()
            else:
                raise InvalidContent(
                    "Existing tfbackend file (%s) does not match expected content:\n%s" % (file, content)
                )

        _logger.info("Create tfbackend file: %s", file)
        file.parent.mkdir(parents=True, exist_ok=True)
        with open(file, "w") as f:
            f.write(content)


def parse_tfvar(value: str) -> Any:
    if value == "false":
        return False
    elif value == "true":
        return True
    elif re.match(r"^\d+$", value):
        return int(value)
    elif re.match(r"^\d+\.\d+$", value):
        return float(value)
    elif m := re.match(r'^"(.*)"$', value):
        return m[1].replace('\\"', '"').replace("\\n", "\n").replace("\\t", "\t").replace("\\\\", "\\")
    else:
        return value


def escape_tfvar(value: Any) -> str:
    if isinstance(value, bool):
        return str(value).lower()
    elif isinstance(value, (int, float)):
        return str(value)
    else:
        return (
            '"' + str(value).replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n").replace("\t", "\\t") + '"'
        )
