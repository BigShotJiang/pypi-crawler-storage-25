"""mcp-defense: Kernel-native runtime defense for AI agents."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("mcp-defense")
except PackageNotFoundError:
    # Source checkout without an install — fall back to hatch-vcs generated file.
    try:
        from mcp_defense._version import __version__  # type: ignore[no-redef]
    except ImportError:
        __version__ = "0.0.0+unknown"

__all__ = ["__version__"]
