"""Crown jewels — agent-specific sensitive paths.

Touching these from an AI agent context is an immediate high-severity event.
Sensitivity scores drive action: CROWN (10) = deny+kill, AUTH (7) = require
approval, CONFIG (3) = log (future: elevate on repeat access).

The list is intentionally agent-centric. It differs from traditional server
crown jewels (/etc/shadow) in that it emphasizes what a prompt-injected AI
agent would reach for: developer credentials, CI tamper surfaces, supply
chain files, and the agent's own instruction files (prompt injection
persistence).
"""

from __future__ import annotations

from enum import IntEnum

from mcp_defense.policy.matcher import path_matches


class Sensitivity(IntEnum):
    NORMAL = 0
    CONFIG = 3
    AUTH = 7
    CROWN = 10


# Glob patterns -> sensitivity. See policy.matcher for pattern semantics.
#
# Home directories are duplicated under both /home/* (Linux convention) and
# /Users/* (macOS convention) so the same dev workstation patterns match
# regardless of the host OS. Linux-only paths (/etc, /proc, /dev, /var/run)
# are left alone — they don't exist on macOS but the patterns are harmless.
CROWN_JEWELS: dict[str, Sensitivity] = {
    # ---- SENSITIVITY_CROWN (10) ----
    "/root/.ssh/**": Sensitivity.CROWN,
    # SSH private keys
    "/home/*/.ssh/id_*": Sensitivity.CROWN,
    "/Users/*/.ssh/id_*": Sensitivity.CROWN,
    "/home/*/.ssh/authorized_keys": Sensitivity.CROWN,
    "/Users/*/.ssh/authorized_keys": Sensitivity.CROWN,
    # AWS credentials
    "/home/*/.aws/credentials": Sensitivity.CROWN,
    "/Users/*/.aws/credentials": Sensitivity.CROWN,
    "/home/*/.aws/config": Sensitivity.CROWN,
    "/Users/*/.aws/config": Sensitivity.CROWN,
    # GCP application default credentials
    "/home/*/.config/gcloud/application_default_credentials.json": Sensitivity.CROWN,
    "/Users/*/.config/gcloud/application_default_credentials.json": Sensitivity.CROWN,
    # Kubernetes admin config
    "/home/*/.kube/config": Sensitivity.CROWN,
    "/Users/*/.kube/config": Sensitivity.CROWN,
    # Docker registry credentials
    "/home/*/.docker/config.json": Sensitivity.CROWN,
    "/Users/*/.docker/config.json": Sensitivity.CROWN,
    # Linux-only kernel / cluster paths
    "/etc/kubernetes/admin.conf": Sensitivity.CROWN,
    "/var/run/secrets/kubernetes.io/serviceaccount/**": Sensitivity.CROWN,
    "/proc/*/environ": Sensitivity.CROWN,
    "/proc/*/mem": Sensitivity.CROWN,
    "/dev/kmsg": Sensitivity.CROWN,
    "/dev/mem": Sensitivity.CROWN,
    "/dev/kcore": Sensitivity.CROWN,
    # ---- SENSITIVITY_AUTH (7) ----
    # Git credentials & signing
    "/home/*/.gitconfig": Sensitivity.AUTH,
    "/Users/*/.gitconfig": Sensitivity.AUTH,
    "/home/*/.git-credentials": Sensitivity.AUTH,
    "/Users/*/.git-credentials": Sensitivity.AUTH,
    "/home/*/.netrc": Sensitivity.AUTH,
    "/Users/*/.netrc": Sensitivity.AUTH,
    # Package manager publish tokens
    "/home/*/.npmrc": Sensitivity.AUTH,
    "/Users/*/.npmrc": Sensitivity.AUTH,
    "/home/*/.pypirc": Sensitivity.AUTH,
    "/Users/*/.pypirc": Sensitivity.AUTH,
    "/home/*/.cargo/credentials.toml": Sensitivity.AUTH,
    "/Users/*/.cargo/credentials.toml": Sensitivity.AUTH,
    # GitHub CLI / hub tokens
    "/home/*/.config/gh/hosts.yml": Sensitivity.AUTH,
    "/Users/*/.config/gh/hosts.yml": Sensitivity.AUTH,
    "/home/*/.config/hub": Sensitivity.AUTH,
    "/Users/*/.config/hub": Sensitivity.AUTH,
    # AI provider credentials
    "/home/*/.anthropic/**": Sensitivity.AUTH,
    "/Users/*/.anthropic/**": Sensitivity.AUTH,
    "/home/*/.config/claude/**": Sensitivity.AUTH,
    "/Users/*/.config/claude/**": Sensitivity.AUTH,
    "/Users/*/Library/Application Support/Claude/**": Sensitivity.AUTH,
    "/home/*/.config/openai/**": Sensitivity.AUTH,
    "/Users/*/.config/openai/**": Sensitivity.AUTH,
    # Project-level secret files (workspace-relative; OS-independent)
    "/workspace/.env": Sensitivity.AUTH,
    "/workspace/**/.env.local": Sensitivity.AUTH,
    "/workspace/**/.env.*": Sensitivity.AUTH,
    "/workspace/**/secrets.yaml": Sensitivity.AUTH,
    "/workspace/**/secrets.json": Sensitivity.AUTH,
    # Container daemon sockets
    "/var/run/docker.sock": Sensitivity.AUTH,
    "/var/run/containerd/containerd.sock": Sensitivity.AUTH,
    "/Users/*/.docker/run/docker.sock": Sensitivity.AUTH,
    # ---- SENSITIVITY_CONFIG (3) — supply chain / CI tamper surface ----
    "/workspace/**/.git/config": Sensitivity.CONFIG,
    "/workspace/**/.git/hooks/**": Sensitivity.CONFIG,
    "/workspace/**/package.json": Sensitivity.CONFIG,
    "/workspace/**/package-lock.json": Sensitivity.CONFIG,
    "/workspace/**/pyproject.toml": Sensitivity.CONFIG,
    "/workspace/**/setup.py": Sensitivity.CONFIG,
    "/workspace/**/Cargo.toml": Sensitivity.CONFIG,
    "/workspace/**/go.mod": Sensitivity.CONFIG,
    "/workspace/**/.github/workflows/**": Sensitivity.CONFIG,
    "/workspace/**/.gitlab-ci.yml": Sensitivity.CONFIG,
    "/workspace/**/Dockerfile": Sensitivity.CONFIG,
    "/workspace/**/docker-compose.yml": Sensitivity.CONFIG,
    # Prompt injection persistence — the agent's own instruction files.
    "/workspace/**/CLAUDE.md": Sensitivity.CONFIG,
    "/workspace/**/.cursorrules": Sensitivity.CONFIG,
    "/workspace/**/.claude/**": Sensitivity.CONFIG,
}


def classify_path(path: str) -> Sensitivity:
    """Return the highest sensitivity level matching the given path."""
    best = Sensitivity.NORMAL
    for pattern, sensitivity in CROWN_JEWELS.items():
        if path_matches(pattern, path) and sensitivity > best:
            best = sensitivity
    return best
