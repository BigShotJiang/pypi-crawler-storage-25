"""mcp-defense CLI entry point.

Usage:
  # Observe a single MCP stdio server with policy enforcement:
  mcp-defense stdio --archetype filesystem --agent-id <id> \\
      [--archetypes config/archetypes.yaml] [--observe] \\
      [--flow-source <jsonl-path>] -- <server-cmd> [args...]

  # Reverse-proxy an SSE MCP server:
  mcp-defense sse --archetype github --agent-id <id> --upstream <url> \\
      [--archetypes config/archetypes.yaml] [--observe] \\
      [--flow-source <jsonl-path>] --bind host:port

  # Run the scripted demo (no real MCP server, no kernel bridge):
  mcp-defense demo
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import sys
from pathlib import Path

from mcp_defense.correlation.flow_source import JsonLinesFlowSource
from mcp_defense.correlation.join import AgentActionSink, Correlator
from mcp_defense.policy.approval import InteractiveApprovalGate
from mcp_defense.policy.archetypes import load_archetypes
from mcp_defense.policy.engine import AllowAllPolicy, PolicyEngine, PolicyGate
from mcp_defense.proxy.sink import EventSink, LoggingSink
from mcp_defense.proxy.sse import SseProxy
from mcp_defense.proxy.stdio import StdioProxy
from mcp_defense.recorder.flight import FlightRecorder
from mcp_defense.siem import SplunkHecConnector, TeeActionSink, WebhookConnector

log = logging.getLogger(__name__)

_DEFAULT_ARCHETYPES = str(
    Path(__file__).resolve().parent / "config" / "archetypes.yaml"
)


def _setup_logging(verbose: bool) -> None:
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
        stream=sys.stderr,
    )


def _build_policy(args: argparse.Namespace) -> PolicyGate:
    if args.observe:
        log.info("running in observe mode — all tool calls allowed")
        return AllowAllPolicy()
    path = Path(args.archetypes)
    if not path.exists():
        log.warning("archetype file not found: %s — falling back to observe mode", path)
        return AllowAllPolicy()
    archetypes = load_archetypes(path)
    log.info("loaded %d archetype(s) from %s", len(archetypes), path)
    gate: PolicyGate = PolicyEngine(archetypes=archetypes)
    if getattr(args, "approval", False):
        log.info("interactive approval enabled — REQUIRE_APPROVAL prompts on /dev/tty")
        gate = InteractiveApprovalGate(gate)
    return gate


def _build_siem_connectors(args: argparse.Namespace) -> list[AgentActionSink]:
    sinks: list[AgentActionSink] = []
    for spec in getattr(args, "siem_splunk", None) or []:
        url, _, token = spec.partition(":")
        if not url or not token:
            log.error("--siem-splunk expects url:token, got %r", spec)
            continue
        sinks.append(SplunkHecConnector(url=url, token=token))
    for url in getattr(args, "siem_webhook", None) or []:
        sinks.append(WebhookConnector(url=url))
    return sinks


def _build_pipeline(
    args: argparse.Namespace,
) -> tuple[EventSink, Correlator | None, asyncio.Task[None] | None, list[AgentActionSink]]:
    """Return (sink, correlator, flow_pump_task, closables).

    If --flow-source is set, wire the correlator + flight recorder (plus any
    configured SIEM connectors). Otherwise return a plain LoggingSink.
    """
    siem_sinks = _build_siem_connectors(args)

    if not args.flow_source:
        if siem_sinks:
            log.warning(
                "SIEM connectors configured but --flow-source not set: "
                "no AgentActionEvents will be produced. Enable --flow-source "
                "or remove --siem-* flags."
            )
        return LoggingSink(), None, None, siem_sinks

    flow_path = Path(args.flow_source)
    recorder = FlightRecorder()
    action_sink: AgentActionSink = (
        TeeActionSink([recorder, *siem_sinks]) if siem_sinks else recorder
    )
    correlator = Correlator(action_sink=action_sink, window_seconds=args.window)
    flow_source = JsonLinesFlowSource(flow_path)

    async def pump() -> None:
        async for flow in flow_source.stream():
            await correlator.ingest_flow(flow)

    return correlator, correlator, asyncio.ensure_future(pump()), siem_sinks


async def _run_stdio(args: argparse.Namespace) -> int:
    cmd = list(args.command or [])
    if cmd and cmd[0] == "--":
        cmd = cmd[1:]
    if not cmd:
        print("stdio: must supply a server command after --", file=sys.stderr)
        return 2

    sink, correlator, flow_task, closables = _build_pipeline(args)
    if correlator is not None:
        await correlator.start()
    try:
        proxy = StdioProxy(
            command=cmd,
            archetype=args.archetype,
            agent_id=args.agent_id,
            sink=sink,
            policy=_build_policy(args),
        )
        return await proxy.run()
    finally:
        if flow_task is not None:
            flow_task.cancel()
            try:
                await flow_task
            except asyncio.CancelledError:
                pass
        if correlator is not None:
            await correlator.stop()
        for closable in closables:
            close = getattr(closable, "close", None)
            if close is not None:
                await close()


async def _run_sse(args: argparse.Namespace) -> int:
    host, _, port_str = args.bind.partition(":")
    port = int(port_str) if port_str else 0

    sink, correlator, flow_task, closables = _build_pipeline(args)
    if correlator is not None:
        await correlator.start()
    try:
        proxy = SseProxy(
            upstream_url=args.upstream,
            archetype=args.archetype,
            agent_id=args.agent_id,
            bind_host=host or "127.0.0.1",
            bind_port=port,
            sink=sink,
            policy=_build_policy(args),
        )
        try:
            await proxy.run()
        except KeyboardInterrupt:
            pass
        return 0
    finally:
        if flow_task is not None:
            flow_task.cancel()
            try:
                await flow_task
            except asyncio.CancelledError:
                pass
        if correlator is not None:
            await correlator.stop()
        for closable in closables:
            close = getattr(closable, "close", None)
            if close is not None:
                await close()


def _cmd_stdio(args: argparse.Namespace) -> int:
    return asyncio.run(_run_stdio(args))


def _cmd_sse(args: argparse.Namespace) -> int:
    return asyncio.run(_run_sse(args))


def _cmd_demo(args: argparse.Namespace) -> int:
    # Import lazily: keeps the demo out of the hot path for real subcommands.
    from mcp_defense.demo.run_demo import main as demo_main

    return demo_main()


def _cmd_bridge_tp(args: argparse.Namespace) -> int:
    from mcp_defense.bridges.ternaryphysics import run_bridge

    return run_bridge(args.fifo, args.interface, args.config)


def _add_common_policy_args(sp: argparse.ArgumentParser) -> None:
    sp.add_argument(
        "--archetypes",
        default=_DEFAULT_ARCHETYPES,
        help="path to archetypes YAML (default: packaged archetypes.yaml)",
    )
    sp.add_argument(
        "--observe",
        action="store_true",
        help="observation only — log every tool call but never block",
    )
    sp.add_argument(
        "--approval",
        action="store_true",
        help="prompt operator on /dev/tty for REQUIRE_APPROVAL decisions "
        "(instead of auto-denying)",
    )
    sp.add_argument(
        "--flow-source",
        default=None,
        help="path to a JSONL file/FIFO emitting kernel FlowEvents. "
        "Enables the correlator + flight recorder pipeline.",
    )
    sp.add_argument(
        "--window",
        type=float,
        default=5.0,
        help="correlation window in seconds (default: 5.0)",
    )
    sp.add_argument(
        "--siem-splunk",
        action="append",
        default=[],
        help="Splunk HEC endpoint as url:token (repeatable)",
    )
    sp.add_argument(
        "--siem-webhook",
        action="append",
        default=[],
        help="generic webhook URL that accepts JSON POSTs (repeatable)",
    )


def main() -> int:
    from mcp_defense import __version__

    parser = argparse.ArgumentParser(
        prog="mcp-defense",
        description="Kernel-native runtime defense for AI agents.",
    )
    parser.add_argument("--version", action="version", version=f"mcp-defense {__version__}")
    parser.add_argument("-v", "--verbose", action="store_true")
    sub = parser.add_subparsers(dest="subcommand", required=True)

    sp = sub.add_parser("stdio", help="intercept an MCP stdio server subprocess")
    sp.add_argument("--archetype", required=True,
                    help="MCP server archetype (filesystem, github, database, ...)")
    sp.add_argument("--agent-id", required=True,
                    help="ID of the AI agent connecting to the server")
    _add_common_policy_args(sp)
    sp.add_argument("command", nargs=argparse.REMAINDER,
                    help="server command (after --)")
    sp.set_defaults(func=_cmd_stdio)

    sp = sub.add_parser("sse", help="reverse-proxy an MCP SSE server")
    sp.add_argument("--archetype", required=True)
    sp.add_argument("--agent-id", required=True)
    sp.add_argument("--upstream", required=True,
                    help="upstream SSE URL, e.g. http://127.0.0.1:9001")
    sp.add_argument("--bind", default="127.0.0.1:0",
                    help="bind address host:port (0 for random port)")
    _add_common_policy_args(sp)
    sp.set_defaults(func=_cmd_sse)

    sp = sub.add_parser("demo", help="run the scripted demo scenario")
    sp.set_defaults(func=_cmd_demo)

    sp = sub.add_parser(
        "bridge-tp",
        help="bridge ternaryphysics-llm-security DetectionEvents -> JSONL FlowEvents",
    )
    sp.add_argument("--fifo", required=True, help="output FIFO or file path")
    sp.add_argument("--interface", default="eth0", help="network interface")
    sp.add_argument("--config", default=None, help="ternaryphysics config file (optional)")
    sp.set_defaults(func=_cmd_bridge_tp)

    args = parser.parse_args()
    _setup_logging(args.verbose)
    return int(args.func(args))


if __name__ == "__main__":
    sys.exit(main())
