"""Notebook helpers.

Most of the notebook integration lives on :class:`SofraTable._repr_html_`.
This module is reserved for future notebook-specific extensions (e.g.
ipywidgets-based controls).
"""
