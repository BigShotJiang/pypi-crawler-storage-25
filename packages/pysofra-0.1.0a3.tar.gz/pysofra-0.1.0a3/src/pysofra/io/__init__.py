"""I/O utilities — reserved for future readers (Stata/SAS/Excel)."""
