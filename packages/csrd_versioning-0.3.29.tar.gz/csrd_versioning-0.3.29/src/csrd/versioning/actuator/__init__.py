from .actuator import register_actuator_router

__all__ = ("register_actuator_router",)
