# Actuator Tools

This folder contains build-time tools that generate metadata consumed by
runtime actuator plugins.

Current tool:

- `generate_service_info_from_git.py`
  - Source: git repository metadata
  - Output: `ACTUATOR_INFO_OUTPUT_PATH` (defaults to `service_info.json`)
  - Runtime consumer: `InfoActuatorPlugin` (`/actuator/info`)

This script is Docker-build-only. It exits unless
`ACTUATOR_INFO_DOCKER_BUILD=1` is set.

Use this script during Docker build stages where `.git` is available, then copy
`service_info.json` into the runtime image.

## Docker Build Pattern

Expected usage is a multi-stage Docker build that generates `service_info.json`
while `.git` is still available, then copies that file into the runtime image.

The CI pipeline injects `BUILD_VERSION` as a Docker build-arg. Pass it through
to the script via `--build-version` so the release version is recorded in
`build.version` and `git.build.version`. The argument is optional — when
omitted the script falls back to `git describe --tags --always`.

Example (drop-in for a consuming repository):

```dockerfile
FROM python:3.13-slim AS service-info
ARG BUILD_VERSION=""
RUN apt-get update && apt-get install -y --no-install-recommends git && rm -rf /var/lib/apt/lists/*
WORKDIR /app

# Install runtime dependencies for the service, including api_versioning.
# Use the install flow your repository already uses.
COPY pyproject.toml poetry.lock* ./
RUN pip install --no-cache-dir poetry \
  && poetry config virtualenvs.create false \
  && poetry install --only main --no-interaction --no-ansi

COPY .git ./.git
RUN ACTUATOR_INFO_DOCKER_BUILD=1 \
  python -m api_versioning.fastapi.versioning.actuator.tools.generate_service_info_from_git \
  --build-version="${BUILD_VERSION}"

FROM base AS runtime
COPY --from=service-info /app/service_info.json ./
```

If you place the file somewhere else at runtime, set `ACTUATOR_INFO_PATH`
so `InfoActuatorPlugin` can resolve it.
