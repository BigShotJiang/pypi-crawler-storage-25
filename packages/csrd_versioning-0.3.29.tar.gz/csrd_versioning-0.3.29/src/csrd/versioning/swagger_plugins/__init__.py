"""Swagger UI plugin system for extending the custom docs rendering pipeline."""

from ._base import (
    SchemaContext,
    SwaggerPlugin,
    SwaggerPluginContribution,
    apply_schema_patchers,
)

__all__ = [
    "SchemaContext",
    "SwaggerPlugin",
    "SwaggerPluginContribution",
    "apply_schema_patchers",
]
