# Pinned Swagger UI version and SRI hashes for jsDelivr CDN assets.
#
# Auto-generated — do not edit manually.
# Regenerate with:
#   python scripts/update_swagger_ui.py <version>
#
# Example:
#   python scripts/update_swagger_ui.py 5.18.2

SWAGGER_UI_VERSION = "5.18.2"
SWAGGER_UI_CSS_SRI = "rcbEi6xgdPk0iWkAQzT2F3FeBJXdG+ydrawGlfHAFIZG7wU6aKbQaRewysYpmrlW"
SWAGGER_UI_JS_SRI = "NXtFPpN61oWCuN4D42K6Zd5Rt2+uxeIT36R7kpXBuY9tLnZorzrJ4ykpqwJfgjpZ"
