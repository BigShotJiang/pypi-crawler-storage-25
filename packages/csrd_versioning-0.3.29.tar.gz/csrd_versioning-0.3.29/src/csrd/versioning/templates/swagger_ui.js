function getQueryParam(name) {
  return new URLSearchParams(window.location.search).get(name);
}

function getLatest(select) {
  return Array.from(select.querySelectorAll('option')).map(option => option.value).pop()
}

const THEME_KEY = "swagger-ui-theme";

function getPreferredTheme() {
  const saved = localStorage.getItem(THEME_KEY);
  if (saved === "dark" || saved === "light") return saved;

  const prefersDark =
    window.matchMedia &&
    window.matchMedia("(prefers-color-scheme: dark)").matches;

  return prefersDark ? "dark" : "light";
}

const lightBulb = '<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" height="24"><path d="M12 2a7 7 0 0 0-7 7c0 2.38 1.19 4.47 3 5.74V17a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-2.26c1.81-1.27 3-3.36 3-5.74a7 7 0 0 0-7-7M9 21a1 1 0 0 0 1 1h4a1 1 0 0 0 1-1v-1H9z"></path></svg>';
const darkBulb  = '<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" height="24"><path d="M12 2C9.76 2 7.78 3.05 6.5 4.68l9.81 9.82C17.94 13.21 19 11.24 19 9a7 7 0 0 0-7-7M3.28 4 2 5.27 5.04 8.3C5 8.53 5 8.76 5 9c0 2.38 1.19 4.47 3 5.74V17a1 1 0 0 0 1 1h5.73l4 4L20 20.72zM9 20v1a1 1 0 0 0 1 1h4a1 1 0 0 0 1-1v-1z"></path></svg>';

function applyTheme(theme) {
  document.body.classList.toggle("dark", theme === "dark");
  localStorage.setItem(THEME_KEY, theme);

  const toggle = document.getElementById("dark-mode-toggle");
  if (!toggle) return;

  toggle.innerHTML = (theme === "dark") ? lightBulb : darkBulb;

  toggle.setAttribute("aria-pressed", String(theme === "dark"));
  toggle.setAttribute("aria-label", theme === "dark" ? "Switch to light mode" : "Switch to dark mode");
  toggle.title = theme === "dark" ? "Switch to light mode" : "Switch to dark mode";
}

function wireThemeToggle() {
  const toggle = document.getElementById("dark-mode-toggle");
  if (!toggle) return;

  applyTheme(getPreferredTheme());

  toggle.addEventListener("click", () => {
    const isDark = document.body.classList.contains("dark");
    applyTheme(isDark ? "light" : "dark");
  });
}

function getSwaggerConfig() {
  const configNode = document.getElementById("ds-swagger-config");
  if (!configNode || !configNode.textContent) {
    return {
      appName: "app",
      appIdHeader: "x-client-app-id",
      hitIdHeader: "x-client-hit-id",
      versionHeader: "x-api-version"
    };
  }

  try {
    return JSON.parse(configNode.textContent);
  } catch {
    return {
      appName: "app",
      appIdHeader: "x-client-app-id",
      hitIdHeader: "x-client-hit-id",
      versionHeader: "x-api-version"
    };
  }
}

function loadSwagger(select, version = null) {
  if (version) {
    select.value = version;
  }

  let value_ = select.value;
  const latest = getLatest(select);
  const config = getSwaggerConfig();
  const appName = config.appName;

  if (!value_) {
    value_ = latest;
    document.getElementById('api-version').value = latest;
  }

  const url = `/openapi/${value_}.json`;

  SwaggerUIBundle({
    url: url,
    dom_id: '#swagger-ui',
    deepLinking: true,
    presets: [SwaggerUIBundle.presets.apis],
    requestInterceptor: (req) => {
      const reqUrl = new URL(req.url, window.location.origin);
      if (reqUrl.pathname.startsWith('/openapi')) {
        return req;
      }

      req.headers[config.appIdHeader] = `swagger-ui-${appName}`;
      req.headers[config.hitIdHeader] = self.crypto.randomUUID();
      req.headers[config.versionHeader] = value_;

      return req;
    }
  });

  const hash = window?.location?.hash || '';
  if (value_ === 'latest' || value_ === latest) {
    const newUrl = `${window.location.pathname}${hash}`;
    window.history.replaceState(null, "", newUrl);
  } else {
    const newUrl = `${window.location.pathname}?version=${value_}${hash}`;
    window.history.replaceState(null, "", newUrl);
  }
}

const config_ = getSwaggerConfig();
const version = getQueryParam('version') || config_.defaultVersion || 'latest';
document.getElementById('api-version').value = version;
const select = document.getElementById('api-version');

wireThemeToggle();

loadSwagger(select, version);

select.addEventListener('change', (e) => {
  loadSwagger(select);
})
