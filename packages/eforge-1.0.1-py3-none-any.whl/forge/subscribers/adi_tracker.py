from forge.protocols.subscriber import SubscriberProtocol
from forge.events.schema import UniversalEvent


class ADITracker(SubscriberProtocol):
    """
    Subscribes to node_drifted and node_declared events.
    Emits adi_updated event when ADI changes.
    Does not store state — ADI is always recomputed.
    """
    subscribes_to = [
        "node_drifted",
        "node_declared",
        "node_implemented",
        "annotation_created",
        "annotation_resolved",
    ]
    version = "1.0.0"

    def on_event(
        self, event: UniversalEvent
    ) -> list[UniversalEvent]:
        # ADI is recomputed on demand, not cached here.
        # This subscriber exists to emit adi_updated
        # so downstream subscribers can react.
        return [UniversalEvent(
            kind="adi_updated",
            source_fqid="subscriber:ADITracker",
            project=event.project,
            payload={
                "triggered_by": event.kind,
                "node_id": event.payload.get(
                    "node_id", ""
                ),
            },
        )]
