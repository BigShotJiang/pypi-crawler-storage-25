from pathlib import Path
from forge.protocols.subscriber import SubscriberProtocol
from forge.events.schema import UniversalEvent

ADR_REFS = {
    "screen": (
        "# ADR-019: Screens are routers only.\n"
        "# Business logic belongs in the controller.\n"
        "# This file: navigation and UI composition only.\n"
    ),
    "controller": (
        "# Controller: owns business logic for one domain.\n"
        "# Does not import from other controllers directly.\n"
    ),
    "service": (
        "# Service: stateless operations on one resource.\n"
        "# Single responsibility.\n"
    ),
    "model": (
        "# Model: data structure only. No business logic.\n"
    ),
}


class ConventionInjector(SubscriberProtocol):
    """
    Injects ADR reference comment blocks into scaffolded files.
    Subscribes to scaffold_completed events.
    Idempotent — never double-injects.
    """

    subscribes_to = ["scaffold_completed"]
    version = "1.0.0"

    def on_event(self, event: UniversalEvent) -> list[UniversalEvent]:
        try:
            payload = event.payload or {}
            file_path = payload.get("file_path", "")
            node_kind = payload.get("node_kind", "")
            if not file_path or not node_kind:
                return []
            path = Path(file_path)
            if not path.exists():
                return []
            comment = ADR_REFS.get(node_kind, "")
            if not comment:
                return []
            content = path.read_text(encoding="utf-8")
            marker = comment.split("\n")[0]
            if marker in content:
                return []
            path.write_text(comment + "\n" + content, encoding="utf-8")
        except Exception:
            pass
        return []
