from __future__ import annotations

import ast
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml
from forge.core.errors import ForgeError, ERRORS
from forge.core.manifest import ManifestParser
from forge.engine.entity.schemas import NodeModel
from forge.core.manifest_path import resolve_manifest_path
from forge.core.path_utils import resolve_project_path
from forge.engine import ForgeEngine
from forge.tools.audit import runtime as audit_runtime
from forge.mcp.handlers.schemas import AnnotationCreateResult
from forge.mcp.mcp_workspace import current_forge_workspace


def resolve_thin_project_root_or_none_when_ambiguous(arguments: dict[str, Any]) -> Path | None:
    """Like ``resolve_thin_project_root`` but returns ``None`` when workspace is multi-project ambiguous."""
    pp = arguments.get("project_path")
    if pp is not None and str(pp).strip():
        return resolve_project_path(str(pp).strip())
    pr = arguments.get("project_root")
    if pr is not None and str(pr).strip():
        return resolve_project_path(str(pr).strip())
    fw = current_forge_workspace()
    if fw is None or not fw.projects:
        return resolve_project_path(None)
    if len(fw.projects) != 1:
        return None
    only = next(iter(fw.projects.values()))
    guessed = resolve_project_path(str(only.path))
    return guessed if guessed is not None else only.path.expanduser().resolve()


def resolve_thin_project_root(arguments: dict[str, Any]) -> Path:
    """Resolve project root — explicit ``project_path`` wins, then Forge workspace (exactly-one project).

    Matches Sprint 3: multi-project workspaces require explicit ``project_path``; registry empty falls
    back to ``resolve_project_path(None)`` (session roots manifest walk) then CWD.
    """
    pp = arguments.get("project_path")
    if pp is not None and str(pp).strip():
        return resolve_project_path(str(pp).strip())
    pr = arguments.get("project_root")
    if pr is not None and str(pr).strip():
        return resolve_project_path(str(pr).strip())
    fw = current_forge_workspace()
    if fw is not None and fw.projects:
        if len(fw.projects) == 1:
            only = next(iter(fw.projects.values()))
            guessed = resolve_project_path(str(only.path))
            return guessed if guessed is not None else only.path.expanduser().resolve()
        raise ValueError(
            "project_path is required — the active workspace/registry lists multiple Forge projects "
            f"({', '.join(sorted(fw.projects.keys()))}); pass project_path explicitly.",
        )
    fb = resolve_project_path(None)
    if fb is not None:
        return fb
    return Path.cwd().resolve()


def _workspace_context_for_execute_orient(arguments: dict[str, Any], root: Path) -> dict[str, Any]:
    """Hydrate MCP ``orient`` `_workspace` project metadata.

    **Sprint 9 Phase 1:** explicit ``project_path`` wins; never inherit the registry's
    default single-project paths when the caller passed a concrete path.

    Workspace defaults from :func:`~forge.mcp.elicitation.workspace_context_dict`
    apply only when ``project_path`` is omitted or blank.
    """
    pp_raw = arguments.get("project_path")
    explicit_pp = pp_raw is not None and bool(str(pp_raw).strip())

    try:
        rp = root.expanduser().resolve()
    except Exception:
        rp = root

    if not explicit_pp:
        from forge.mcp.elicitation import workspace_context_dict

        ctx = workspace_context_dict(None)
        return dict(ctx) if ctx else {}

    out: dict[str, Any] = {
        "project_path": str(rp),
        "project_name": rp.name,
    }
    fw = None
    try:
        fw = current_forge_workspace()
    except Exception:
        fw = None
    if fw is not None and getattr(fw, "projects", None):
        health_map = fw.health if isinstance(fw.health, dict) else {}
        out["health"] = str(health_map.get("status", "unknown"))
        out["project_count"] = len(fw.projects)

        matched: str | None = None
        for pid, pi in fw.projects.items():
            try:
                wi = getattr(pi, "path", pi)
                wpath = Path(wi).expanduser().resolve()
            except Exception:
                continue
            if wpath == rp:
                matched = pid
                break
        out["project_id"] = matched

    return out


def _session(arguments: dict[str, Any]) -> Any:
    from forge.engine.session import ForgeSession
    from forge.mcp.server import get_or_create_session

    root = resolve_thin_project_root(arguments)
    return get_or_create_session(str(root))


def _engine(arguments: dict[str, Any]) -> ForgeEngine:
    return _session(arguments).engine


def _engine_resolve_node_ref(engine: ForgeEngine, node_ref: str) -> str:
    """Prefer a loaded registry hit by canonical ``node_id`` before fuzzy CLI resolution."""
    ref = (node_ref or "").strip()
    if not ref:
        return ref
    if isinstance(engine.node(ref), NodeModel):
        return ref
    from forge.tools.manifest.graph import resolve_manifest_node

    resolved = resolve_manifest_node(engine.registry.graph, ref)
    return resolved.id if resolved is not None else ref


_L1_NODE_FIELDS = frozenset({
    "id",
    "kind",
    "domain",
    "tier",
    "status",
    "name",
    "path",
    "description",
})


def _apply_response_tier(
    nodes: list[dict[str, Any]],
    tier: str,
) -> dict[str, Any]:
    """Apply response_tier filtering to a list of node dicts."""
    t = str(tier or "L1").upper()
    if t == "L0":
        return {
            "count": len(nodes),
            "ids": [str(n.get("id") or "") for n in nodes],
            "response_tier": "L0",
        }
    if t == "L1":
        return {
            "count": len(nodes),
            "nodes": [
                {k: v for k, v in n.items() if k in _L1_NODE_FIELDS}
                for n in nodes
            ],
            "response_tier": "L1",
        }
    return {
        "count": len(nodes),
        "nodes": nodes,
        "response_tier": "L2",
    }


def run_query_payload(arguments: dict[str, Any]) -> dict[str, Any]:
    expand_dom = arguments.get("expand_domain")
    sort_raw = arguments.get("sort_by")
    sort_by = str(sort_raw).strip() if sort_raw is not None else ""
    tier_arg = str(arguments.get("tier") or "").strip() or None
    engine = _engine(arguments)
    payload = engine.query(
        kind=str(arguments.get("kind") or ""),
        domain=str(arguments.get("domain") or ""),
        name=str(arguments.get("name") or ""),
        depends_on=str(arguments.get("depends_on") or ""),
        via=str(arguments.get("via") or "") or None,
        limit=int(arguments.get("limit", 50)),
        depth=int(arguments.get("depth", 1)),
        direction=str(arguments.get("direction") or "both"),
        sort_by=sort_by or None,
        tier=tier_arg,
        expand_relevant=bool(arguments.get("expand_relevant")),
        expand_domain=str(expand_dom).strip() if expand_dom else None,
        expand_max_total=int(arguments.get("expand_max_total") or 30),
        project_id=str(arguments.get("project_id") or "").strip() or None,
    )
    payload_dict = payload.model_dump()

    response_tier = str(
        arguments.get("response_tier") or "L1"
    ).upper()
    nodes = payload_dict.get("nodes", [])
    if not isinstance(nodes, list):
        nodes = []

    if response_tier == "L0":
        return {
            "count": len(nodes),
            "ids": [n.get("id", "") for n in nodes if isinstance(n, dict)],
            "response_tier": "L0",
            "query": arguments.get("query", {}),
        }

    if response_tier == "L1":
        l1_fields = {"id", "kind", "domain", "tier", "status", "name"}
        payload_dict["nodes"] = [
            {k: v for k, v in n.items() if k in l1_fields}
            for n in nodes
            if isinstance(n, dict)
        ]

    payload_dict["response_tier"] = response_tier
    return payload_dict


def execute_blast_radius(arguments: dict[str, Any]) -> dict[str, Any]:
    node_ref = str(
        arguments.get("node")
        or arguments.get("node_id")
        or arguments.get("node_name")
        or ""
    ).strip()
    if not node_ref:
        raise ValueError("node (or node_id / node_name) is required")
    engine = _engine(arguments)
    node_id = _engine_resolve_node_ref(engine, node_ref)
    return engine.blast_radius(node_id)


def execute_impact_radius(arguments: dict[str, Any]) -> dict[str, Any]:
    """Unified impact analysis: blast_radius + doc propagation + tier violations.

    Resolves node from ``node`` / ``node_id`` / ``node_name`` in arguments first;
    if absent, falls back to first mappable path in ``changed_files``.
    Returns a flat dict with all ImpactRadiusResult fields plus ``_blast_raw``
    (the raw blast_radius_ring2 output) so handler layers can reconstruct their
    existing backward-compat response shapes without re-calling the engine.
    """
    from forge.tools.manifest.graph import find_node_id_for_path

    root = resolve_thin_project_root(arguments)
    engine = ForgeEngine(root)
    engine.load()

    node_ref = str(
        arguments.get("node")
        or arguments.get("node_id")
        or arguments.get("node_name")
        or ""
    ).strip()

    if not node_ref:
        changed_files = [
            str(f).strip()
            for f in (arguments.get("changed_files") or [])
            if str(f).strip()
        ]
        for cf in changed_files:
            nid = find_node_id_for_path(engine.registry.graph, cf)
            if nid:
                node_ref = nid
                break

    if not node_ref:
        raise ValueError(
            "node, node_id, node_name, or changed_files with a mappable path is required"
        )

    node_id = _engine_resolve_node_ref(engine, node_ref)

    result = engine.impact_radius(node_id)

    return {
        "node_id": node_id,
        "project_path": str(root),
        "project_name": root.name,
        "affected_nodes": [n.model_dump() for n in result.affected_nodes],
        "doc_updates_required": result.doc_updates_required,
        "contract_violations": result.contract_violations,
        "ring": result.ring,
        "rule_sources": result.rule_sources,
        "_blast_raw": result.blast_raw,
    }


def execute_impact_radius_unified(
    arguments: dict[str, Any],
) -> dict[str, Any]:
    """Unified impact_radius — full ImpactRadiusResult.

    Replaces execute_impact_radius (blast slice only) and the impact_check path.

    Returns ForgeImpactRadiusOutput-shaped dict.
    """
    session = _session(arguments)
    node_id = arguments.get("node_id", "")
    slice_mode = arguments.get("slice", "full")

    if not node_id:
        return {
            "ok": False,
            "project": str(session.path.name),
            "node_id": "",
            "ring": 0,
            "error": "node_id is required",
        }

    result = session.engine.impact_radius(node_id)

    from forge.mcp.handlers.mapping_tools import _node_to_forge_output

    affected = [
        _node_to_forge_output(n, session)
        for n in result.affected_nodes
    ]

    full = {
        "ok": True,
        "project": str(session.path.name),
        "node_id": node_id,
        "ring": result.ring,
        "affected_nodes": affected,
        "doc_updates_required": result.doc_updates_required,
        "contract_violations": result.contract_violations,
        "rule_sources": result.rule_sources,
        "slice": slice_mode,
        "metadata": {
            "blast_raw_keys": list(result.blast_raw.keys()),
        },
    }

    if slice_mode == "blast":
        return {k: full[k] for k in (
            "ok", "project", "node_id", "ring", "affected_nodes", "slice"
        )}
    if slice_mode == "docs":
        return {k: full[k] for k in (
            "ok", "project", "node_id", "doc_updates_required", "slice"
        )}
    if slice_mode == "contracts":
        return {k: full[k] for k in (
            "ok", "project", "node_id", "contract_violations", "slice"
        )}

    return full


def execute_health_vector(arguments: dict[str, Any]) -> dict[str, Any]:
    _ = arguments
    return _engine(arguments).health_vector().model_dump()


def execute_verify(arguments: dict[str, Any]) -> dict[str, Any]:
    """Run structural verify (same core as CLI / MCP ``forge_verify``)."""
    from forge.cli.verify import run_verify_cli_parity

    root = resolve_thin_project_root(arguments)
    target = str(arguments.get("target") or "staged").strip().lower()
    strict = bool(arguments.get("strict", False))
    result = run_verify_cli_parity(root, target, strict=strict)
    if int(result.get("exit_code") or 0) == 0:
        changed = [str(x).strip() for x in (result.get("changed_nodes") or []) if str(x).strip()]
        if changed:
            _session({"project_path": str(root)}).hooks.emit_verify_passed(
                changed,
                actor="forge_verify",
                detail={"target": target, "strict": strict},
            )
    return result


def execute_tree_view(arguments: dict[str, Any]) -> dict[str, Any]:
    _ = arguments
    return _engine(arguments).tree_view()


def execute_map(arguments: dict[str, Any]) -> dict[str, Any]:
    """Load declaration graph (with stack glove merge), return nodes and edges for MCP map.

    Supports ``map_scope`` ``project`` (default) and ``local`` (requires ``domain``).
    ``global`` and unsupported scopes raise ``ValueError`` — use CLI for those.
    """
    from forge.engine.projections.tool_call import node_list_to_forge_node_output
    from forge.tools.manifest.graph import merge_stack_glove_scan_into_graph, save_graph

    root = resolve_thin_project_root(arguments)
    scope = str(arguments.get("map_scope") or arguments.get("scope") or "project").strip().lower()

    if scope == "global":
        raise ValueError(
            "map_scope=global is not available on forge_map; use CLI `forge map --scope global`"
        )

    if scope == "sub-local":
        from forge.commands.map_cmd import _fmt_sub_local

        file_arg = arguments.get("file")
        if not file_arg or not str(file_arg).strip():
            raise ValueError("map_scope=sub-local requires file (repo-relative path)")
        markdown = _fmt_sub_local(str(file_arg).strip(), str(root))
        return {
            "ok": True,
            "project": root.name,
            "nodes": [],
            "edges": [],
            "sub_local_markdown": markdown,
        }

    if scope == "local":
        domain = str(arguments.get("domain") or "").strip()
        if not domain:
            raise ValueError("map_scope=local requires domain")
    else:
        domain = str(arguments.get("domain") or "").strip()

    engine = ForgeEngine(root)
    engine.load()
    merge_stack_glove_scan_into_graph(engine.registry.graph)
    save_graph(engine.registry.graph)

    nodes = engine.nodes(domain=domain) if domain else engine.nodes()
    node_ids = {n.id for n in nodes}
    graph = engine.registry.graph
    out_edges: list[dict[str, Any]] = []
    for e in graph.edges:
        if e.from_id not in node_ids or e.to_id not in node_ids:
            continue
        meta = dict(e.meta) if isinstance(e.meta, dict) else {}
        if e.derived:
            meta = {**meta, "derived": True}
        out_edges.append({
            "from_id": e.from_id,
            "to_id": e.to_id,
            "relation": e.relation,
            "metadata": meta,
        })

    out_nodes = [fn.model_dump() for fn in node_list_to_forge_node_output(nodes)]

    result: dict[str, Any] = {
        "ok": True,
        "project": root.name,
        "nodes": out_nodes,
        "edges": out_edges,
        "domains": sorted(
            {
                str(n.get("domain") or "")
                for n in out_nodes
                if n.get("domain")
            }
        ),
    }

    response_tier = str(
        arguments.get("response_tier") or "L1"
    ).upper()

    nodes_out = result.get("nodes", [])
    edges_out = result.get("edges", [])

    if response_tier == "L0":
        return {
            "ok": result.get("ok", True),
            "project": result.get("project"),
            "node_count": len(nodes_out),
            "edge_count": len(edges_out),
            "domains": result.get("domains", []),
            "response_tier": "L0",
        }
    if response_tier == "L1":
        l1_node = {"id", "kind", "domain", "tier", "status"}
        l1_edge = {"from_id", "to_id", "relation", "from", "to"}
        return {
            "ok": result.get("ok", True),
            "project": result.get("project"),
            "node_count": len(nodes_out),
            "edge_count": len(edges_out),
            "nodes": [
                {k: v for k, v in n.items() if k in l1_node}
                for n in nodes_out
            ],
            "edges": [
                {k: v for k, v in e.items() if k in l1_edge}
                for e in edges_out
            ],
            "domains": result.get("domains", []),
            "response_tier": "L1",
        }

    result["response_tier"] = "L2"
    return result


def execute_orient(arguments: dict[str, Any]) -> dict[str, Any]:
    from dataclasses import asdict

    node = arguments.get("node")
    bundle = _engine(arguments).orient(str(node).strip() if node else None)
    result = asdict(bundle)

    ws: dict[str, Any] = {}
    root = resolve_thin_project_root(arguments)

    try:
        wctx = _workspace_context_for_execute_orient(arguments, root)
        if wctx:
            ws.update(wctx)
    except Exception:
        pass

    # Sprint 6: compact intent / declared-vs-graph signals for dashboards (subset of coverage_rollup).
    try:
        compact = _intent_coverage_compact_summary(root)
        if compact:
            ws["intent_coverage_compact"] = compact
    except Exception:
        pass

    if ws:
        result["_workspace"] = ws

    return result


def execute_triangulate(arguments: dict[str, Any]) -> dict[str, Any]:
    node_ref = str(
        arguments.get("node")
        or arguments.get("node_id")
        or arguments.get("target")
        or ""
    ).strip()
    if not node_ref:
        raise ValueError("node (or node_id / target) is required")
    engine = _engine(arguments)
    node_id = _engine_resolve_node_ref(engine, node_ref)
    return {"results": engine.triangulate(node_id)}


def execute_session_log(arguments: dict[str, Any]) -> dict[str, Any]:
    root_raw = str(arguments.get("project_path") or "").strip()
    if root_raw:
        root = resolve_project_path(root_raw)
    else:
        root = resolve_thin_project_root_or_none_when_ambiguous(arguments)
    scratch = (root / ".forge" / "scratch.md") if root else (Path.home() / ".forge" / "scratch.md")
    scratch.parent.mkdir(parents=True, exist_ok=True)
    entry = str(arguments.get("entry") or "").strip()
    if not entry:
        raise ValueError("entry is required")
    ts = datetime.now(timezone.utc).isoformat()
    with scratch.open("a", encoding="utf-8") as f:
        f.write(f"- [{ts}] {entry}\n")
    return {"status": "ok", "path": str(scratch), "entry": entry}


def execute_audit_scan(arguments: dict[str, Any]) -> dict[str, Any]:
    mode = str(arguments.get("mode") or "repo").strip().lower()
    at_resolved = str(resolve_project_path(str(arguments.get("at_path") or ".")))
    project_resolved = str(resolve_thin_project_root(arguments))
    if mode == "meta":
        return audit_runtime.audit_meta(
            at_path=at_resolved,
            include_siblings=bool(arguments.get("include_siblings", True)),
            depth=int(arguments.get("depth", 3)),
            include_parent_context=bool(arguments.get("include_parent_context", True)),
            strict=bool(arguments.get("strict", False)),
            policy_mode=str(arguments.get("policy_mode") or "advisory"),
            changed_files_source=str(arguments.get("changed_files_source") or "git"),
            alignment_mode=str(arguments.get("alignment_mode") or "target_to_forge"),
            scope=list(arguments.get("scope") or []) or None,
            focus=list(arguments.get("focus") or []) or None,
        )
    return audit_runtime.audit_repo(
        project_path=project_resolved,
        strict=bool(arguments.get("strict", False)),
        policy_mode=str(arguments.get("policy_mode") or "advisory"),
        changed_files_source=str(arguments.get("changed_files_source") or "git"),
        alignment_mode=str(arguments.get("alignment_mode") or "target_to_forge"),
        scope=list(arguments.get("scope") or []) or None,
        focus=list(arguments.get("focus") or []) or None,
    )


def execute_annotation_create(arguments: dict[str, Any]) -> AnnotationCreateResult:
    from forge.mcp.elicitation import hydrate_arguments
    
    # Hydrate arguments before processing
    arguments = hydrate_arguments("forge_annotation_create", arguments)

    project_path = resolve_thin_project_root(arguments)
    kind = arguments.get("kind")
    marker = arguments.get("marker")
    title = arguments.get("title")
    content = arguments.get("content")
    severity = arguments.get("severity")
    horizon = arguments.get("horizon")
    session_id = arguments.get("session_id")
    
    # Import annotation functionality
    try:
        # Use the correct runtime module path
        from forge.tools.audit.runtime import create_annotation
        audit_runtime = create_annotation
    except ImportError as e:
        from forge.core.errors import ERRORS
        from forge.mcp.handlers.error_handlers import copy_forge_error
        error = copy_forge_error(
            ERRORS["dependency_unavailable"],
            source_tool="forge_annotation_create",
            context={"exception": str(e)},
        )
        return AnnotationCreateResult(ok=False, error=error.model_dump_json())
    
    # Create annotation
    try:
        result = audit_runtime.create_annotation(
            project_path=project_path,
            kind=kind,
            marker=marker,
            title=title,
            content=content,
            severity=severity,
            horizon=horizon,
            session_id=session_id,
        )

        # Wire into entity system via session
        try:
            from forge.mcp.server import get_or_create_session
            from forge.tools.audit.bundle import AuditAnnotation
            from forge.core.forge_project_system import AnnotationComponent

            session = get_or_create_session(str(project_path))
            annotation_dict = result.get("annotation", {})

            if annotation_dict:
                _ = session.project
                ann = AuditAnnotation.from_dict(annotation_dict)

                # Find the entity this annotation references (via affects or node_id)
                target_ids = ann.affects or []
                if not target_ids and ann.symbol:
                    target_ids = [ann.symbol]

                for node_id in target_ids:
                    entity = session.registry.get_entity(node_id)
                    if entity is None:
                        continue
                    comp = entity.get_component(AnnotationComponent)
                    if comp is None:
                        comp = AnnotationComponent()
                        entity.add_component(comp)
                    comp.add_annotation(ann)
        except Exception:
            pass  # never let entity wiring break annotation creation

        return AnnotationCreateResult(ok=True, annotation_id=result.get("annotation_id"), annotation=result.get("annotation"))
    except Exception as e:
        from forge.core.errors import ERRORS
        from forge.mcp.handlers.error_handlers import copy_forge_error
        error = copy_forge_error(
            ERRORS["unhandled"],
            source_tool="forge_annotation_create",
            context={"exception": str(e), "debug": str(e)},
        )
        return AnnotationCreateResult(ok=False, error=error.model_dump_json())


def execute_annotation_query_by_node(arguments: dict[str, Any]) -> dict[str, Any]:
    """Query annotations that reference a specific node via affects, blocks, or requires fields.

    Entry point for graph-linked annotation traversal — given a node_id, returns all
    annotations that declare a relationship to it.
    """
    project_path = resolve_thin_project_root(arguments)
    node_id = arguments.get("node_id", "")

    if not node_id:
        return {"ok": False, "error": "node_id required", "annotations": []}

    try:
        from forge.tools.audit.annotations import (
            _iter_annotation_files,
            _load_annotation_yaml,
            annotation_to_dict,
            audit_annotation_from_dict,
        )

        matching: list[dict[str, Any]] = []
        for ann_path in _iter_annotation_files(project_path):
            raw = _load_annotation_yaml(ann_path)
            ann_dict = annotation_to_dict(audit_annotation_from_dict(raw))
            affects = ann_dict.get("affects", [])
            blocks = ann_dict.get("blocks", [])
            requires = ann_dict.get("requires", [])
            all_refs = affects + blocks + requires
            if node_id in all_refs:
                matching.append(ann_dict)

        return {
            "ok": True,
            "node_id": node_id,
            "count": len(matching),
            "annotations": matching,
        }
    except Exception as e:
        return {"ok": False, "error": str(e), "annotations": []}


def execute_scaffold(arguments: dict[str, Any]) -> dict[str, Any]:
    """Execute scaffold via glove template discovery and instantiation."""
    from forge.tools.glove_templates.registry import (
        find_template_for_kind_stack,
        template_l1_row,
    )
    from forge.tools.scaffold.scaffolder import (
        ScaffoldError,
        instantiate_glove_template,
        parse_template_inputs,
    )

    def _with_response_tier(result: dict[str, Any]) -> dict[str, Any]:
        result["response_tier"] = arguments.get("response_tier", "L1")
        return result

    project_path = resolve_thin_project_root(arguments)
    node_type = str(
        arguments.get("node_type") or arguments.get("kind") or ""
    ).strip()
    stack = str(arguments.get("stack") or "web").strip()
    dry_run = bool(arguments.get("dry_run", False))
    template_inputs = dict(arguments.get("template_inputs") or {})
    for key in ("node_name", "domain", "path", "name"):
        if arguments.get(key) and key not in template_inputs:
            template_inputs[key] = arguments[key]
    raw_inputs = template_inputs or arguments.get("inputs") or []
    if isinstance(raw_inputs, dict):
        cli_inputs = {str(k): str(v) for k, v in raw_inputs.items()}
    elif isinstance(raw_inputs, list):
        cli_inputs = parse_template_inputs([str(x) for x in raw_inputs])
    else:
        cli_inputs = {}

    if not node_type:
        return _with_response_tier({"ok": False, "error": "node_type is required"})

    hit = find_template_for_kind_stack(node_type, stack)
    if hit is None:
        return _with_response_tier({
            "ok": False,
            "error": f"No template for kind={node_type!r} stack={stack!r}",
            "hint": "Call forge_template to see available kinds and stacks",
        })

    template_path, template = hit
    row = template_l1_row(template)

    if dry_run:
        return _with_response_tier({
            "ok": True,
            "dry_run": True,
            "node_type": node_type,
            "stack": stack,
            "template": row,
            "would_create": list(template.get("produces") or []),
            "template_inputs_received": cli_inputs,
        })

    try:
        out = instantiate_glove_template(
            template=template,
            template_path=template_path,
            project_path=project_path,
            cli_inputs=cli_inputs,
            interactive=False,
        )
        return _with_response_tier({
            "ok": True,
            "node_type": node_type,
            "stack": stack,
            "template": row,
            "created": out,
        })
    except ScaffoldError as e:
        return _with_response_tier({
            "ok": False,
            "error": str(e),
            "node_type": node_type,
            "stack": stack,
        })
    except Exception as e:
        return _with_response_tier({
            "ok": False,
            "error": str(e),
            "node_type": node_type,
            "stack": stack,
        })


def execute_discover(arguments: dict[str, Any]) -> dict[str, Any]:
    """Discover untracked source files vs manifest.

    Stack-agnostic: auto-detects from manifest or file heuristics.

    Returns untracked modules with suggested manifest entries — non-mutating.
    """
    project_path = resolve_thin_project_root(arguments)
    stack = arguments.get("stack", "auto")

    try:
        from forge.commands.discover_cmd import _detect_stack, _discover_web_modules
        from forge.core.manifest import resolve_manifest_path
        import yaml

        resolved_stack = stack if stack != "auto" else _detect_stack(project_path)

        manifest_path = resolve_manifest_path(project_path)
        existing_manifest: dict = {}
        if manifest_path and manifest_path.is_file():
            try:
                existing_manifest = yaml.safe_load(
                    manifest_path.read_text(encoding="utf-8")
                ) or {}
            except Exception:
                pass

        if resolved_stack in ("web", "astro", "react"):
            modules = _discover_web_modules(
                project_path,
                existing_manifest,
                resolved_stack,
            )
        else:
            from forge.core.module_discovery import ModuleDiscovery

            discovery = ModuleDiscovery(project_path)
            discovery.discover_python_modules()
            modules = discovery.find_untracked_modules(existing_manifest)

        suggestions = [m.to_manifest_entry() for m in modules]

        response_tier = str(arguments.get("response_tier") or "L1").upper()
        hint = (
            "Pass these to forge_manifest_append to declare them."
            if suggestions
            else "All files are declared."
        )
        base = {
            "ok": True,
            "stack": resolved_stack,
            "project": project_path.name,
            "untracked_count": len(suggestions),
            "hint": hint,
            "response_tier": response_tier,
        }
        if response_tier == "L0":
            base["untracked"] = []
            return base
        if response_tier == "L1":
            base["untracked"] = [
                {
                    k: v
                    for k, v in s.items()
                    if k in ("id", "kind", "path", "name", "domain")
                }
                for s in suggestions
                if isinstance(s, dict)
            ]
            return base
        base["untracked"] = suggestions
        return base

    except Exception as e:
        return {
            "ok": False,
            "error": str(e),
            "stack": stack,
            "untracked": [],
        }


def execute_inspect(arguments: dict[str, Any]) -> dict[str, Any]:
    """Progressive graph inspection."""
    from forge.engine.cursor import CursorRegistry

    session = _session(arguments)
    action = str(arguments.get("action") or "node")
    node_id = str(arguments.get("node_id") or "").strip()
    if not node_id and action == "search":
        node_id = str(arguments.get("query") or "").strip()
    handle = str(arguments.get("handle") or "").strip()
    response_tier = str(arguments.get("response_tier") or "L1")

    if action == "search":
        query = node_id or str(arguments.get("query") or "").strip()
        if not query:
            return {
                "ok": False,
                "error": "query or node_id required for action=search",
                "available_actions": [{
                    "action": "search",
                    "params": {
                        "query": "engine",
                        "project_path": "...",
                    },
                    "description": "Fuzzy search by partial name, id, or domain",
                }],
            }
        search_args = dict(arguments)
        search_args["query"] = query
        result = execute_search(search_args)
        result["action"] = "search"
        return result

    if action == "node":
        if not node_id:
            return {
                "ok": False,
                "error": "node_id required for action=node",
                "available_actions": [{
                    "action": "node",
                    "params": {
                        "node_id": "module/...",
                        "project_path": "...",
                    },
                    "description": "Inspect a node by ID or bare name",
                }],
            }

        resolved_id = _engine_resolve_node_ref(session.engine, node_id)

        from forge.engine.cursor import ContextFingerprint

        fp = None
        try:
            phase = None
            task = None
            active_intents: list[str] = []
            active_annotations: list[str] = []

            try:
                project = session.project
                if project:
                    phase = str(getattr(project, "phase", None) or "") or None
                    task = str(getattr(project, "current_task", None) or "") or None
            except Exception:
                pass

            try:
                from forge.tools.intent.runtime import load_intent_records

                records = load_intent_records(session.path)
                active_intents = [
                    str(r.id)
                    for r in records
                    if (r.target_id or "") == resolved_id
                    and (r.status or "") != "done"
                ]
            except Exception:
                pass

            try:
                from forge.tools.audit.annotations import load_annotation_index_entries

                entries = load_annotation_index_entries(session.path)
                active_annotations = [
                    str(e.get("id", ""))
                    for e in entries
                    if resolved_id in str(e.get("affects", "") or "")
                    and str(e.get("status", "")) == "open"
                ]
            except Exception:
                pass

            fp = ContextFingerprint(
                session_key=str(session.path),
                phase=phase,
                task=task,
                active_intents=active_intents,
                active_annotations=active_annotations,
            )
        except Exception:
            pass

        result = session.inspect(resolved_id, fingerprint=fp)

        node_dict = None
        if result.node and response_tier != "L0":
            node_dict = result.node.model_dump()

        return {
            "ok": True,
            "action": "node",
            "node_id": result.node_id,
            "node": node_dict,
            "handle": result.handle,
            "rings": {
                "1": {
                    "count": result.ring1_count,
                    "ids": result.ring1_ids if response_tier != "L0" else [],
                },
                "2": {
                    "count": result.ring2_count,
                    "ids": result.ring2_ids if response_tier != "L0" else [],
                },
                "3": {
                    "count": result.ring3_count,
                    "ids": result.ring3_ids if response_tier == "L2" else [],
                },
            },
            "imports": result.imports,
            "imported_by": result.imported_by,
            "counts": {
                "annotations": result.annotation_count,
                "intents": result.intent_count,
                "tier_violations": len(result.tier_violations),
                "drift_items": len(result.drift_items),
            },
            "available_actions": result.available_actions,
        }

    elif action == "expand":
        if not handle:
            return {"ok": False, "error": "handle required"}
        ring_num = int(arguments.get("ring") or 1)
        cursor = CursorRegistry.get(handle)
        if cursor is None:
            return {
                "ok": False,
                "error": f"Cursor {handle!r} not found or expired. Call action=node first.",
                "hint": "Cursors expire after process restart.",
            }

        ring_ids = cursor.get_ring(ring_num)
        if not ring_ids:
            return {
                "ok": True,
                "action": "expand",
                "ring": ring_num,
                "nodes": [],
                "message": f"Ring {ring_num} is empty",
            }

        from forge.mcp.handlers.mapping_tools import _node_to_forge_output

        nodes = []
        for nid in ring_ids:
            node = session.engine.registry.get_node(nid)
            if node:
                nodes.append(_node_to_forge_output(node.model_dump(), session))

        cursor.expanded[f"ring{ring_num}"] = nodes

        tier_payload = _apply_response_tier(nodes, response_tier)
        return {
            "ok": True,
            "action": "expand",
            "handle": handle,
            "ring": ring_num,
            **tier_payload,
            "available_actions": [
                {
                    "action": "select",
                    "params": {"handle": handle, "ids": "[choose from nodes]"},
                    "description": "Focus on specific nodes",
                },
                {
                    "action": "packet",
                    "params": {"handle": handle},
                    "description": "Save navigation as packet",
                },
            ],
        }

    elif action == "select":
        if not handle:
            return {"ok": False, "error": "handle required"}
        ids = list(arguments.get("ids") or [])
        cursor = CursorRegistry.get(handle)
        if cursor is None:
            return {"ok": False, "error": "Cursor not found"}

        cursor.select(ids)

        from forge.mcp.handlers.mapping_tools import _node_to_forge_output

        nodes = []
        for nid in ids:
            node = session.engine.registry.get_node(nid)
            if node:
                nodes.append(_node_to_forge_output(node.model_dump(), session))

        tier_payload = _apply_response_tier(nodes, response_tier)
        return {
            "ok": True,
            "action": "select",
            "handle": handle,
            "selected_count": tier_payload.get("count", len(nodes)),
            **tier_payload,
            "available_actions": [{
                "action": "packet",
                "params": {"handle": handle},
                "description": "Save this selection as a packet for handoff",
            }],
        }

    elif action == "diff":
        if not handle:
            return {"ok": False, "error": "handle required"}
        cursor = CursorRegistry.get(handle)
        if cursor is None:
            return {"ok": False, "error": "Cursor not found"}

        try:
            from forge.core.temporal_triangulation import triangulate_temporal_contracts

            result = triangulate_temporal_contracts(
                session.path,
                node_id=cursor.node_id,
                response_tier="L1",
            )
            drift = result.get("results", [])
        except Exception:
            drift = []

        return {
            "ok": True,
            "action": "diff",
            "handle": handle,
            "node_id": cursor.node_id,
            "drift_count": len(drift),
            "drift_items": drift,
            "context": {
                "phase": cursor.fingerprint.phase if cursor.fingerprint else None,
                "task": cursor.fingerprint.task if cursor.fingerprint else None,
            },
        }

    elif action == "packet":
        if not handle:
            return {"ok": False, "error": "handle required"}
        cursor = CursorRegistry.get(handle)
        if cursor is None:
            return {"ok": False, "error": "Cursor not found"}

        import json

        packet_data = cursor.to_packet_dict()
        packet_dir = session.path / ".forge" / "cursor_packets"
        packet_dir.mkdir(parents=True, exist_ok=True)
        safe_id = cursor.node_id.replace("/", "_").replace(".", "_")
        packet_path = packet_dir / f"cursor-{safe_id}.json"
        packet_path.write_text(json.dumps(packet_data, indent=2), encoding="utf-8")

        return {
            "ok": True,
            "action": "packet",
            "handle": handle,
            "node_id": cursor.node_id,
            "packet_path": str(packet_path),
            "message": (
                "Navigation state saved. Reload with action=node and the same "
                "node_id in a new session."
            ),
        }

    return {
        "ok": False,
        "error": f"Unknown action: {action!r}",
        "valid_actions": ["node", "expand", "select", "diff", "packet", "search"],
    }


def execute_search(arguments: dict[str, Any]) -> dict[str, Any]:
    """Fuzzy/partial name search across the manifest graph."""
    from forge.mcp.handlers.mapping_tools import _node_to_forge_output

    session = _session(arguments)
    query_raw = str(
        arguments.get("query")
        or arguments.get("node_id")
        or ""
    ).strip()
    query = query_raw.lower()
    kind_filter = arguments.get("kind")
    domain_filter = arguments.get("domain")
    limit = int(arguments.get("limit", 20))
    response_tier = str(arguments.get("response_tier") or "L1")

    if not query:
        return {
            "ok": False,
            "error": "query is required",
            "response_tier": response_tier.upper(),
        }

    matches: list[Any] = []
    for node in session.engine.nodes():
        node_id = str(getattr(node, "id", "") or "").lower()
        node_name = str(getattr(node, "name", "") or "").lower()
        node_domain = str(getattr(node, "domain", "") or "").lower()

        if query not in node_id and query not in node_name and query not in node_domain:
            continue
        if kind_filter and str(getattr(node, "kind", "") or "") != str(kind_filter):
            continue
        if domain_filter and node_domain != str(domain_filter).upper().lower():
            continue
        matches.append(node)
        if len(matches) >= limit:
            break

    node_dicts = [_node_to_forge_output(n, session) for n in matches]
    tier_payload = _apply_response_tier(node_dicts, response_tier)
    return {
        "ok": True,
        "query": query_raw,
        "hint": "Use node.id in forge_impact_radius, forge_query, or forge_trace",
        **tier_payload,
    }


def execute_trace(arguments: dict[str, Any]) -> dict[str, Any]:
    """Find dependency path between two nodes via declaration-graph edges."""
    session = _session(arguments)
    engine = session.engine

    from_id = str(
        arguments.get("from_id")
        or arguments.get("from_node")
        or arguments.get("node_id")
        or ""
    ).strip()
    to_id = str(
        arguments.get("to_id") or arguments.get("to_node") or ""
    ).strip()

    if not from_id or not to_id:
        return {
            "ok": False,
            "error": "from_id and to_id required",
            "from_id": from_id or None,
            "to_id": to_id or None,
            "path": None,
            "length": None,
            "connected": False,
        }

    from_id = _engine_resolve_node_ref(engine, from_id)
    to_id = _engine_resolve_node_ref(engine, to_id)

    path_ids = engine.resolver.trace(from_id, to_id)

    return {
        "ok": path_ids is not None,
        "from_id": from_id,
        "to_id": to_id,
        "path": path_ids,
        "length": len(path_ids) if path_ids else None,
        "connected": path_ids is not None,
    }


def execute_manifest_append(arguments: dict[str, Any]) -> dict[str, Any]:
    from forge.mcp.elicitation import hydrate_arguments
    
    # Hydrate arguments before processing
    arguments = hydrate_arguments("forge_manifest_append", arguments)

    project_path = resolve_thin_project_root(arguments)
    nodes = arguments.get("nodes")
    dry_run = bool(arguments.get("dry_run", False))

    from forge.schema.kinds import get_kind_registry

    if not isinstance(nodes, list) or not nodes:
        raise ValueError("nodes must be a non-empty list of objects")

    manifest_path = resolve_manifest_path(project_path, warn_on_root_fallback=False)
    if manifest_path is None:
        raise ValueError(f"manifest not found for project: {project_path}")

    parser = ManifestParser(manifest_path)
    parsed = parser.parse()
    if not parsed.ok or not isinstance(parsed.value, dict):
        raise ValueError(parsed.error or f"failed to parse manifest: {manifest_path}")
    manifest = parsed.value

    manifest_stack = str(
        manifest.get("stack") or manifest.get("type") or ""
    ).strip().lower()

    kind_registry = get_kind_registry()
    kind_warnings: list[str] = []
    for node in nodes:
        if not isinstance(node, dict):
            continue
        kind = str(node.get("kind") or "").strip()
        stack = str(
            arguments.get("stack") or manifest_stack or ""
        ).strip().lower()
        if kind:
            if stack and not kind_registry.valid_for_stack(kind, stack):
                valid_names = [k.id for k in kind_registry.for_stack(stack)][:8]
                kind_warnings.append(
                    f"kind={kind!r} not valid for stack={stack!r}. "
                    f"Valid kinds: {valid_names}"
                )
            elif not kind_registry.get(kind):
                kind_warnings.append(
                    f"kind={kind!r} not in KindRegistry"
                )

    modules = manifest.get("modules")
    if modules is None:
        modules = []
    if not isinstance(modules, list):
        raise ValueError("manifest modules section must be a list")

    existing_ids = {
        str(m.get("id") or "").strip()
        for m in modules
        if isinstance(m, dict) and str(m.get("id") or "").strip()
    }

    stack_schema: dict[str, Any] = {}
    stack_name = str(manifest.get("type") or "").strip().lower()
    if stack_name:
        schema_path = Path(__file__).resolve().parents[2] / "schemas" / "stacks" / f"{stack_name}.yaml"
        if schema_path.is_file():
            # C006-OK: non-manifest YAML (stack schema), direct load is correct.
            loaded = yaml.safe_load(schema_path.read_text(encoding="utf-8")) or {}
            if isinstance(loaded, dict):
                stack_schema = loaded

    allowed_fields = {
        str(x).strip()
        for x in (stack_schema.get("allowed_node_fields") or [])
        if str(x).strip()
    }

    node_schemas = manifest.get("node_schemas")
    module_schema = None
    if isinstance(node_schemas, list):
        module_schema = next(
            (s for s in node_schemas if isinstance(s, dict) and str(s.get("kind") or "").strip() == "module"),
            None,
        )
    required_fields = ["id"]
    if isinstance(module_schema, dict):
        req = [str(x).strip() for x in (module_schema.get("required_fields") or []) if str(x).strip()]
        if req:
            required_fields = req
        if not allowed_fields:
            allowed_fields = {
                str(x).strip()
                for x in (module_schema.get("allowed_fields") or [])
                if str(x).strip()
            }

    # Build NodeModel → canonical manifest dicts (Sprint 3 Phase 3)
    append_whitelist = NodeModel.append_input_field_names()

    validated: list[dict[str, Any]] = []
    seen_ids = set(existing_ids)
    for idx, node in enumerate(nodes):
        if not isinstance(node, dict):
            raise ValueError(f"nodes[{idx}] must be an object")

        unknown_top = sorted(str(k) for k in node.keys() if str(k) not in append_whitelist)
        if unknown_top:
            raise ValueError(
                f"nodes[{idx}] has unknown input fields (not in NodeModel append schema): "
                f"{', '.join(unknown_top)}"
            )

        try:
            nm = NodeModel.from_manifest_append_dict(
                dict(node),
                manifest_required_fields=tuple(required_fields),
            )
        except Exception as e:
            raise ValueError(f"nodes[{idx}] invalid: {e}") from e

        normalized = nm.to_manifest_dict()
        node_id = str(normalized["id"]).strip()

        if allowed_fields:
            unknown = sorted(k for k in normalized if str(k) not in allowed_fields)
            if unknown:
                scope = f"stack '{stack_name}'" if stack_name else "manifest node_schemas"
                raise ValueError(
                    f"nodes[{idx}] has fields not allowed by {scope} allowed_node_fields: "
                    f"{', '.join(unknown)}"
                )

        if node_id in seen_ids:
            raise ValueError(f"duplicate node id: {node_id}")
        seen_ids.add(node_id)
        validated.append(normalized)

    before_count = len(modules)
    if dry_run:
        out = {
            "ok": True,
            "dry_run": True,
            "manifest_path": str(manifest_path),
            "section": "modules",
            "validated_nodes": validated,
            "would_append_ids": [str(n.get("id")) for n in validated],
            "before_node_count": before_count,
            "after_node_count": before_count + len(validated),
        }
        if kind_warnings:
            out["kind_warnings"] = kind_warnings
        return out

    appended_ids: list[str] = []
    for node in validated:
        res = parser.append_node("modules", node)
        if not res.ok:
            raise ValueError(res.error or f"failed to append node {node.get('id')}")
        appended_ids.append(str(node.get("id")))

    reparsed = parser.parse()
    updated_count = before_count + len(validated)
    if reparsed.ok and isinstance(reparsed.value, dict):
        updated_modules = reparsed.value.get("modules")
        if isinstance(updated_modules, list):
            updated_count = len(updated_modules)

    out = {
        "ok": True,
        "dry_run": False,
        "manifest_path": str(manifest_path),
        "section": "modules",
        "appended_ids": appended_ids,
        "updated_node_count": updated_count,
    }
    if kind_warnings:
        out["kind_warnings"] = kind_warnings
    engine = _engine(arguments)
    engine.reload()
    for node_id in appended_ids:
        node = engine.node(node_id)
        if isinstance(node, NodeModel):
            engine.hooks.emit_node_declared(
                node,
                actor="forge_manifest_append",
                detail={"manifest_path": str(manifest_path)},
            )
    return out


def _intent_payload(
    action: str,
    *,
    record_id: str | None = None,
    records: list[dict[str, Any]] | None = None,
    elicitation_required: bool = False,
    confirmation_status: str | None = None,
) -> dict[str, Any]:
    return {
        "action": action,
        "record_id": record_id,
        "records": records or [],
        "elicitation_required": elicitation_required,
        "confirmation_status": confirmation_status,
    }


def _norm_rel_path_for_glove(p: str) -> str:
    return str(p or "").replace("\\", "/").lstrip("./")


def _python_glove_import_edge_count_to_engine_paths(
    project_root: Path,
    *,
    engine_node_ids: frozenset[str],
    cached_graph: Any,
) -> int | None:
    """Count ``parse_python`` project-local import edges whose target path matches an ENGINE graph node.

    Uses the same relative paths as :func:`forge.tools.scan.parsers.python_app.parse_python`.
    Independent of cached ``imports`` edges (glove scan is live; graph cache may omit edges).
    Returns ``None`` if the Python parser cannot run.
    """
    if not engine_node_ids:
        return 0
    engine_paths: set[str] = set()
    for n in cached_graph.nodes:
        if str(n.id).strip() not in engine_node_ids:
            continue
        raw = str(n.path or "").strip()
        if not raw:
            continue
        engine_paths.add(_norm_rel_path_for_glove(raw))
    if not engine_paths:
        return 0
    try:
        from forge.tools.scan.parsers.python_app import parse_python
    except Exception:
        return None
    try:
        parsed = parse_python(project_root)
    except Exception:
        return None
    n = 0
    seen: set[tuple[str, str]] = set()
    for dep in parsed.dependencies:
        tgt = _norm_rel_path_for_glove(str(dep.target))
        if tgt not in engine_paths:
            continue
        src = _norm_rel_path_for_glove(str(dep.source))
        key = (src, tgt)
        if key in seen:
            continue
        seen.add(key)
        n += 1
    return n


def _refs_for_manifest_module_row(row: Any) -> set[str]:
    """Reference tokens for a single ``modules[]`` row (id/name, with optional ``module/``)."""

    def _add_ref(refs: set[str], raw: str | None) -> None:
        token = str(raw or "").strip()
        if not token:
            return
        refs.add(token)
        if not token.startswith("module/"):
            refs.add(f"module/{token}")

    refs: set[str] = set()
    if isinstance(row, dict):
        _add_ref(refs, row.get("id"))
        _add_ref(refs, row.get("name"))
    return refs


def _manifest_module_reference_strings(modules: list[Any]) -> set[str]:
    """Strings by which an intent ``target_id`` may reference a manifest ``modules[]`` row."""

    refs: set[str] = set()
    for row in modules:
        refs |= _refs_for_manifest_module_row(row)
    return refs


def _manifest_module_rows_with_graph_node(
    mods_list: list[Any], graph_node_ids: frozenset[str]
) -> int:
    """Count manifest module rows whose ref tokens intersect cached graph node ids."""
    if not graph_node_ids:
        return 0
    n = 0
    for row in mods_list:
        if not isinstance(row, dict):
            continue
        if _refs_for_manifest_module_row(row) & graph_node_ids:
            n += 1
    return n


def _static_import_resolution_counts_from_tree(tree: ast.AST) -> tuple[int, int]:
    """Top-level absolute imports: count roots checked vs ``importlib.util.find_spec`` hits.

    Skips relative ``ImportFrom`` (``level > 0``). Each ``import a.b`` / ``from pkg import …``
    contributes one check for the first path segment only. Exceptions from ``find_spec``
    count as unresolved. Diagnostic only — not a full static resolver or runtime import test.
    """
    import importlib.util

    if not isinstance(tree, ast.Module):
        return 0, 0
    checked = 0
    matched = 0
    for node in tree.body:
        if isinstance(node, ast.Import):
            for alias in node.names:
                root_name = (alias.name or "").split(".")[0].strip()
                if not root_name:
                    continue
                checked += 1
                ok = False
                try:
                    ok = importlib.util.find_spec(root_name) is not None
                except (ImportError, ModuleNotFoundError, ValueError, AttributeError):
                    ok = False
                if ok:
                    matched += 1
        elif isinstance(node, ast.ImportFrom):
            if getattr(node, "level", 0):
                continue
            mod = node.module
            if not mod or not str(mod).strip():
                continue
            root_name = str(mod).split(".")[0].strip()
            if not root_name:
                continue
            checked += 1
            ok = False
            try:
                ok = importlib.util.find_spec(root_name) is not None
            except (ImportError, ModuleNotFoundError, ValueError, AttributeError):
                ok = False
            if ok:
                matched += 1
    return checked, matched


def _funcdef_has_any_parameter_or_return_annotation(node: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
    """True if any parameter or the return carries an ``ast`` annotation node (surface PEP 484-ish)."""
    if node.returns is not None:
        return True
    for coll in (node.args.posonlyargs, node.args.args, node.args.kwonlyargs):
        for a in coll:
            if a.annotation is not None:
                return True
    va = node.args.vararg
    if va is not None and va.annotation is not None:
        return True
    ka = node.args.kwarg
    if ka is not None and ka.annotation is not None:
        return True
    return False


def _top_level_funcdef_annotation_counts(tree: ast.AST) -> tuple[int, int]:
    """Module-level ``def`` / ``async def`` totals vs any annotated signature (return or params).

    Nested defs inside classes or other defs are ignored. This is **AST surface only** — not
    ``mypy`` or gradual typing soundness.
    """
    if not isinstance(tree, ast.Module):
        return 0, 0
    checked = 0
    annotated = 0
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            checked += 1
            if _funcdef_has_any_parameter_or_return_annotation(node):
                annotated += 1
    return checked, annotated


def _intent_query_coverage_rollup(project_root: Path) -> dict[str, Any]:
    """Mechanical counts: manifest modules, intent YAML records, annotation index.

    When ``.forge/manifest_graph.json`` exists (registry graph cache), counts
    ``kind=module`` nodes as ``implemented_module_estimate`` — a structural
    cardinality signal. ``implementation_coverage`` adds
    ``manifest_module_rows_resolved_in_graph`` / ``declared_module_graph_fulfillment_rate``
    (declared rows whose id/name tokens match a graph node id).
    ``intent_target_fulfillment`` covers intent ``target_id`` resolution, dual-catalog overlap,
    inferred intent edges in cache, and (when the target id exists in the graph) compares to the
    cached node's ``status`` for an implementation rate signal. When the graph node carries a
    non-empty ``path``, a coarse **workspace file exists** check compares ``project_root / path``
    (diagnostic only — not execution or test proof). For existing ``.py`` paths, ``ast.parse`` yields
    a syntax-valid share among those files. On syntax-valid modules, top-level **absolute** import
    roots are checked with ``importlib.util.find_spec`` (installer/stdlib discovery — not project
    graph wiring or runtime execution). For on-disk **``.py``** intent targets, **cache-only**
    **``relation=imports``** inbound edge counts (``to_id`` = target module) measure structural
    callers in ``.forge/manifest_graph.json`` — not runtime call graphs. On syntax-valid **``.py``**
    trees, module-level **``def``** / **``async def``** signatures are scanned for any parameter or
    return **``ast``** annotation node (PEP 484-ish surface — not static type checking), then
    ``compile(..., 'exec')`` measures compiler / bytecode-lowering acceptance (still not executing
    module top-level code).
    ``engine_graph_coverage`` (when graph cache loads) tallies ENGINE-domain nodes and
    inbound ``imports`` edges targeting them (cache snapshot), plus a live ``parse_python`` count of
    project-local import lines whose resolved target path matches an ENGINE module path.
    Annotation counts are read from ``.forge/annotations/index.yaml`` when present (no rebuild).
    """
    from forge.tools.audit.annotations import (
        annotation_rollups_from_index,
        load_annotation_index_entries,
    )
    from forge.tools.intent.runtime import load_intent_records
    from forge.tools.manifest.graph import load_graph

    declared = 0
    mods_list: list[Any] = []
    mf = resolve_manifest_path(project_root, warn_on_root_fallback=False)
    if mf is not None and mf.is_file():
        parsed = ManifestParser(mf).parse()
        if parsed.ok and isinstance(parsed.value, dict):
            mods = parsed.value.get("modules")
            if isinstance(mods, list):
                mods_list = mods
                declared = len(mods)
    recs = list(load_intent_records(project_root))
    with_target = sum(1 for r in recs if (r.target_id or "").strip())

    manifest_refs = _manifest_module_reference_strings(mods_list)

    ann_entries = load_annotation_index_entries(project_root, rebuild_if_missing=False)
    ann_roll = annotation_rollups_from_index(ann_entries)

    cached_graph, _ = load_graph(project_root)
    graph_cache_loaded = cached_graph is not None
    inbound_import_edge_count_by_to_id: dict[str, int] = {}
    if cached_graph is not None:
        for e in cached_graph.edges:
            if str(e.relation or "").strip().lower() != "imports":
                continue
            to_e = str(e.to_id or "").strip()
            if to_e:
                inbound_import_edge_count_by_to_id[to_e] = (
                    inbound_import_edge_count_by_to_id.get(to_e, 0) + 1
                )
    implemented_module_estimate: int | None = None
    graph_node_ids: frozenset[str] = frozenset()
    graph_node_status_by_id: dict[str, str] = {}
    graph_node_path_by_id: dict[str, str] = {}
    engine_node_ids: frozenset[str] = frozenset()
    if cached_graph is not None:
        id_list: list[str] = []
        mod_count = 0
        eng_list: list[str] = []
        for n in cached_graph.nodes:
            nid = str(n.id).strip()
            if not nid:
                continue
            id_list.append(nid)
            graph_node_status_by_id[nid] = str(n.status or "").strip().lower() or "declared"
            rp = str(n.path or "").strip()
            if rp:
                graph_node_path_by_id[nid] = _norm_rel_path_for_glove(rp)
            if str(n.kind or "").strip().lower() == "module":
                mod_count += 1
            if str(n.domain or "").strip().upper() == "ENGINE":
                eng_list.append(nid)
        graph_node_ids = frozenset(id_list)
        implemented_module_estimate = mod_count
        engine_node_ids = frozenset(eng_list)

    targets_manifest_match = 0
    targets_graph_only_match = 0
    targets_unresolved = 0
    targets_manifest_graph_match = 0
    for r in recs:
        tid = str(r.target_id or "").strip()
        if not tid:
            continue
        in_manifest = tid in manifest_refs
        in_graph = bool(graph_node_ids) and tid in graph_node_ids
        if in_manifest and in_graph:
            targets_manifest_graph_match += 1
        if in_manifest:
            targets_manifest_match += 1
        elif tid in graph_node_ids:
            targets_graph_only_match += 1
        else:
            targets_unresolved += 1

    inferred_intent_edges_in_cache: int | None = None
    intent_records_with_hint_edge_materializable: int | None = None
    if cached_graph is not None:
        inferred_intent_edges_in_cache = 0
        for e in cached_graph.edges:
            em = e.meta or {}
            if em.get("source") == "intent" and str(e.relation or "").strip().lower() == "inferred":
                inferred_intent_edges_in_cache += 1
        intent_records_with_hint_edge_materializable = 0
        if graph_node_ids:
            for r in recs:
                tid = str(r.target_id or "").strip()
                if not tid or tid not in graph_node_ids:
                    continue
                hints = [str(x) for x in r.extracted_nodes if str(x).strip()]
                if any(h in graph_node_ids for h in hints):
                    intent_records_with_hint_edge_materializable += 1

    targets_with_target_id_in_graph: int | None = None
    targets_implemented_in_graph: int | None = None
    intent_target_graph_implementation_rate: float | None = None
    if cached_graph is not None and graph_node_ids:
        tw = 0
        timpl = 0
        for r in recs:
            tid = str(r.target_id or "").strip()
            if not tid or tid not in graph_node_ids:
                continue
            tw += 1
            if graph_node_status_by_id.get(tid) == "implemented":
                timpl += 1
        targets_with_target_id_in_graph = tw
        targets_implemented_in_graph = timpl
        intent_target_graph_implementation_rate = (
            timpl / tw if tw else None
        )

    targets_graph_path_rows_checked: int | None = None
    targets_graph_path_file_present: int | None = None
    intent_target_graph_path_file_presence_rate: float | None = None
    if cached_graph is not None and graph_node_ids:
        path_checked = 0
        path_present = 0
        for r in recs:
            tid = str(r.target_id or "").strip()
            if not tid or tid not in graph_node_ids:
                continue
            rel = graph_node_path_by_id.get(tid)
            if not rel:
                continue
            path_checked += 1
            try:
                if (project_root / rel).is_file():
                    path_present += 1
            except OSError:
                pass
        targets_graph_path_rows_checked = path_checked
        targets_graph_path_file_present = path_present
        intent_target_graph_path_file_presence_rate = (
            path_present / path_checked if path_checked else None
        )

    targets_graph_path_python_syntax_checked: int | None = None
    targets_graph_path_python_syntax_valid: int | None = None
    intent_target_graph_path_python_syntax_rate: float | None = None
    targets_graph_path_import_resolve_checked: int | None = None
    targets_graph_path_import_resolve_matched: int | None = None
    intent_target_graph_path_import_resolve_rate: float | None = None
    targets_graph_path_python_funcdef_checked: int | None = None
    targets_graph_path_python_funcdef_annotated: int | None = None
    intent_target_graph_path_python_funcdef_annotation_rate: float | None = None
    targets_graph_path_python_compile_checked: int | None = None
    targets_graph_path_python_compile_ok: int | None = None
    intent_target_graph_path_python_compile_rate: float | None = None
    if cached_graph is not None and graph_node_ids:
        py_checked = 0
        py_valid = 0
        imp_checked = 0
        imp_matched = 0
        funcdef_checked = 0
        funcdef_annotated = 0
        bc_checked = 0
        bc_ok = 0
        for r in recs:
            tid = str(r.target_id or "").strip()
            if not tid or tid not in graph_node_ids:
                continue
            rel = graph_node_path_by_id.get(tid)
            if not rel:
                continue
            abs_path = project_root / rel
            try:
                if not abs_path.is_file():
                    continue
            except OSError:
                continue
            if not str(rel).lower().endswith(".py"):
                continue
            try:
                src = abs_path.read_text(encoding="utf-8")
            except OSError:
                continue
            py_checked += 1
            try:
                tree = ast.parse(src, filename=str(abs_path))
            except SyntaxError:
                continue
            py_valid += 1
            ic, im = _static_import_resolution_counts_from_tree(tree)
            imp_checked += ic
            imp_matched += im
            fc, fa = _top_level_funcdef_annotation_counts(tree)
            funcdef_checked += fc
            funcdef_annotated += fa
            bc_checked += 1
            try:
                compile(tree, str(abs_path), "exec")
                bc_ok += 1
            except (SyntaxError, TypeError, ValueError, RecursionError, MemoryError):
                pass
        targets_graph_path_python_syntax_checked = py_checked
        targets_graph_path_python_syntax_valid = py_valid
        intent_target_graph_path_python_syntax_rate = (
            py_valid / py_checked if py_checked else None
        )
        targets_graph_path_import_resolve_checked = imp_checked
        targets_graph_path_import_resolve_matched = imp_matched
        intent_target_graph_path_import_resolve_rate = (
            imp_matched / imp_checked if imp_checked else None
        )
        targets_graph_path_python_funcdef_checked = funcdef_checked
        targets_graph_path_python_funcdef_annotated = funcdef_annotated
        intent_target_graph_path_python_funcdef_annotation_rate = (
            funcdef_annotated / funcdef_checked if funcdef_checked else None
        )
        targets_graph_path_python_compile_checked = bc_checked
        targets_graph_path_python_compile_ok = bc_ok
        intent_target_graph_path_python_compile_rate = (
            bc_ok / bc_checked if bc_checked else None
        )

    targets_graph_path_imports_inbound_rows: int | None = None
    targets_graph_path_imports_inbound_ge1: int | None = None
    intent_target_graph_path_imports_inbound_rate: float | None = None
    if cached_graph is not None and graph_node_ids:
        ib_rows = 0
        ib_ge1 = 0
        for r in recs:
            tid = str(r.target_id or "").strip()
            if not tid or tid not in graph_node_ids:
                continue
            rel = graph_node_path_by_id.get(tid)
            if not rel or not str(rel).lower().endswith(".py"):
                continue
            try:
                if not (project_root / rel).is_file():
                    continue
            except OSError:
                continue
            ib_rows += 1
            if inbound_import_edge_count_by_to_id.get(tid, 0) >= 1:
                ib_ge1 += 1
        targets_graph_path_imports_inbound_rows = ib_rows
        targets_graph_path_imports_inbound_ge1 = ib_ge1
        intent_target_graph_path_imports_inbound_rate = (
            ib_ge1 / ib_rows if ib_rows else None
        )

    intent_target_fulfillment: dict[str, Any] = {
        "schema_version": 1,
        "status": "diagnostic",
        "intent_records_with_target_id": with_target,
        "targets_manifest_match": targets_manifest_match,
        "targets_graph_only_match": targets_graph_only_match,
        "targets_manifest_graph_match": targets_manifest_graph_match,
        "targets_unresolved": targets_unresolved,
        "targets_with_target_id_in_graph": targets_with_target_id_in_graph,
        "targets_implemented_in_graph": targets_implemented_in_graph,
        "intent_target_graph_implementation_rate": intent_target_graph_implementation_rate,
        "targets_graph_path_rows_checked": targets_graph_path_rows_checked,
        "targets_graph_path_file_present": targets_graph_path_file_present,
        "intent_target_graph_path_file_presence_rate": intent_target_graph_path_file_presence_rate,
        "targets_graph_path_python_syntax_checked": targets_graph_path_python_syntax_checked,
        "targets_graph_path_python_syntax_valid": targets_graph_path_python_syntax_valid,
        "intent_target_graph_path_python_syntax_rate": intent_target_graph_path_python_syntax_rate,
        "targets_graph_path_import_resolve_checked": targets_graph_path_import_resolve_checked,
        "targets_graph_path_import_resolve_matched": targets_graph_path_import_resolve_matched,
        "intent_target_graph_path_import_resolve_rate": intent_target_graph_path_import_resolve_rate,
        "targets_graph_path_imports_inbound_rows": targets_graph_path_imports_inbound_rows,
        "targets_graph_path_imports_inbound_ge1": targets_graph_path_imports_inbound_ge1,
        "intent_target_graph_path_imports_inbound_rate": intent_target_graph_path_imports_inbound_rate,
        "targets_graph_path_python_funcdef_checked": targets_graph_path_python_funcdef_checked,
        "targets_graph_path_python_funcdef_annotated": targets_graph_path_python_funcdef_annotated,
        "intent_target_graph_path_python_funcdef_annotation_rate": intent_target_graph_path_python_funcdef_annotation_rate,
        "targets_graph_path_python_compile_checked": targets_graph_path_python_compile_checked,
        "targets_graph_path_python_compile_ok": targets_graph_path_python_compile_ok,
        "intent_target_graph_path_python_compile_rate": intent_target_graph_path_python_compile_rate,
        "inferred_intent_edges_in_cache": inferred_intent_edges_in_cache,
        "intent_records_with_hint_edge_materializable": intent_records_with_hint_edge_materializable,
        "intent_hint_edge_materialization_rate": (
            intent_records_with_hint_edge_materializable / with_target
            if graph_cache_loaded
            and with_target
            and intent_records_with_hint_edge_materializable is not None
            else None
        ),
        "manifest_resolution_rate": (
            targets_manifest_match / with_target if with_target else None
        ),
        "any_resolution_rate": (
            (targets_manifest_match + targets_graph_only_match) / with_target if with_target else None
        ),
        "manifest_graph_dual_resolution_rate": (
            targets_manifest_graph_match / with_target if with_target else None
        ),
        "methodology": (
            "For each intent record with non-empty target_id, checks exact membership against "
            "(1) manifest modules[] id/name variants including module/ prefix, then "
            "(2) cached graph node ids when .forge/manifest_graph.json loads. "
            "targets_manifest_graph_match counts ids present in both catalogs (subset of manifest matches "
            "when graph is loaded). When the cache is loaded, inferred_intent_edges_in_cache counts "
            "edges with meta.source=intent and relation=inferred; "
            "intent_records_with_hint_edge_materializable counts records whose target_id and at least one "
            "extracted_nodes hint both resolve to graph node ids (same condition as graph materialization). "
            "When the cache is loaded, targets_with_target_id_in_graph / targets_implemented_in_graph / "
            "intent_target_graph_implementation_rate compare intent target_id to the cached node's status "
            "(implemented vs declared etc.) — structural graph signal only, not runtime proof. "
            "When the graph node has a non-empty path, targets_graph_path_rows_checked / "
            "targets_graph_path_file_present / intent_target_graph_path_file_presence_rate compare "
            "intent target_id to workspace file existence at that relative path — shallow behavioral "
            "hint only (symlinks, case-folding, and build artifacts not modeled). "
            "For existing .py paths, targets_graph_path_python_syntax_checked / "
            "targets_graph_path_python_syntax_valid / intent_target_graph_path_python_syntax_rate run "
            "``ast.parse`` on file contents. After a successful parse, "
            "targets_graph_path_import_resolve_checked / targets_graph_path_import_resolve_matched / "
            "intent_target_graph_path_import_resolve_rate tally top-level absolute import roots against "
            "``importlib.util.find_spec`` (stdlib / site-packages discovery — not project-relative "
            "resolution or runtime import side effects). "
            "targets_graph_path_imports_inbound_rows / targets_graph_path_imports_inbound_ge1 / "
            "intent_target_graph_path_imports_inbound_rate count intent targets whose on-disk **``.py``** "
            "graph paths exist and have at least one cached **imports** edge with **to_id** = that "
            "target's graph node id (cache snapshot only — stale graph omits glove edges until rebuild). "
            "targets_graph_path_python_funcdef_checked / targets_graph_path_python_funcdef_annotated / "
            "intent_target_graph_path_python_funcdef_annotation_rate aggregate module-level **def** / "
            "**async def** counts vs any return or parameter **ast** annotation (not ``mypy``). "
            "targets_graph_path_python_compile_checked / targets_graph_path_python_compile_ok / "
            "intent_target_graph_path_python_compile_rate run ``compile(..., 'exec')`` on the parsed "
            "module AST — bytecode lowering / compiler acceptance only (does not execute module body). "
            "Still not full behavioral fulfillment — deeper ENGINE / glove work is deferred."
        ),
    }

    mods_aligned: int | None = (
        _manifest_module_rows_with_graph_node(mods_list, graph_node_ids)
        if graph_cache_loaded
        else None
    )

    impl_cov: dict[str, Any] = {
        "schema_version": 1,
        "status": "diagnostic",
        "declared_manifest_module_rows": declared,
        "graph_cache_loaded": graph_cache_loaded,
        "graph_module_node_count": implemented_module_estimate,
        "manifest_module_rows_resolved_in_graph": mods_aligned,
        "declared_module_graph_fulfillment_rate": (
            mods_aligned / declared if graph_cache_loaded and declared > 0 and mods_aligned is not None else None
        ),
        "manifest_to_graph_module_ratio": None,
        "methodology": (
            "Structural comparison: manifest modules[] row count vs kind=module "
            "nodes in .forge/manifest_graph.json when loaded; ratio can exceed 1.0 when "
            "the graph includes glove-discovered modules. manifest_module_rows_resolved_in_graph "
            "counts rows whose id/name tokens (incl. module/ prefix variants) match a graph node id — "
            "a coarse declared-vs-structural-graph alignment rate, not shipped delivery %."
        ),
    }
    if graph_cache_loaded and declared > 0 and implemented_module_estimate is not None:
        impl_cov["manifest_to_graph_module_ratio"] = (
            implemented_module_estimate / declared
        )

    engine_graph_coverage: dict[str, Any] = {
        "schema_version": 1,
        "status": "diagnostic",
        "engine_domain_node_count": None,
        "imports_inbound_to_engine_total": None,
        "python_glove_imports_to_engine_total": None,
        "methodology": (
            "Reads cached .forge/manifest_graph.json: counts nodes whose domain is ENGINE, "
            "then counts relation=imports edges whose to_id is one of those node ids (inbound callers). "
            "python_glove_imports_to_engine_total runs a live ``parse_python`` scan: project-local import "
            "lines whose resolved target path matches an ENGINE graph node's path (deduped by source/target). "
            "Diff vs cache-only imports: ``forge map`` / MCP ``forge_map`` run "
            "``merge_stack_glove_scan_into_graph``, which can append ``meta.source=python_glove`` "
            "import edges on Python stacks; a stale ``manifest_graph.json`` snapshot may omit them "
            "until rebuild. "
            "Not a full static-analysis pass — heuristic parser only."
        ),
    }
    if cached_graph is not None:
        engine_graph_coverage["engine_domain_node_count"] = len(engine_node_ids)
        engine_graph_coverage["imports_inbound_to_engine_total"] = sum(
            1
            for e in cached_graph.edges
            if str(e.relation or "").strip().lower() == "imports"
            and str(e.to_id or "").strip() in engine_node_ids
        )
        engine_graph_coverage["python_glove_imports_to_engine_total"] = (
            _python_glove_import_edge_count_to_engine_paths(
                project_root,
                engine_node_ids=engine_node_ids,
                cached_graph=cached_graph,
            )
        )

    base: dict[str, Any] = {
        "schema_version": 1,
        "note": (
            "rollup: manifest modules[] + intent files + annotation index; "
            "optional implemented_module_estimate from graph cache (kind=module); "
            "implementation_coverage.manifest_module_rows_resolved_in_graph: declared rows "
            "matching graph node ids; intent_target_fulfillment: target_id linkage, dual-catalog overlap, "
            "and graph-cache intent inferred-edge / hint materialization previews; "
            "engine_graph_coverage: ENGINE-domain nodes + inbound imports edges in cache plus "
            "live python parse_python import edges whose targets land on ENGINE module paths; "
            "intent_target_fulfillment adds ast.parse syntax rates for on-disk .py graph paths; "
            "inbound-imports-to-target rates from cached imports edges; "
            "module-level def/async-def annotation surface; "
            "``compile(..., 'exec')`` acceptance on parsed modules; "
            "full behavioral fulfillment vs shipped code remains future scope."
        ),
        "declared_manifest_module_rows": declared,
        "graph_cache_loaded": graph_cache_loaded,
        "implemented_module_estimate": implemented_module_estimate,
        "intent_record_total": len(recs),
        "intent_records_with_target_id": with_target,
        "intent_target_fulfillment": intent_target_fulfillment,
        "implementation_coverage": impl_cov,
        "engine_graph_coverage": engine_graph_coverage,
        **ann_roll,
    }
    return base


# Keys always emitted by :func:`_intent_coverage_compact_summary` (board / project_status / orient).
INTENT_COVERAGE_COMPACT_PUBLIC_KEYS: frozenset[str] = frozenset(
    {
        "schema_version",
        "status",
        "intent_record_total",
        "intent_records_with_target_id",
        "intent_target_any_resolution_rate",
        "intent_target_manifest_resolution_rate",
        "intent_target_manifest_graph_dual_rate",
        "intent_inferred_edges_in_cache",
        "intent_hint_edge_materialization_rate",
        "intent_target_graph_implementation_rate",
        "intent_target_graph_path_file_presence_rate",
        "intent_target_graph_path_python_syntax_rate",
        "intent_target_graph_path_import_resolve_rate",
        "intent_target_graph_path_imports_inbound_rate",
        "intent_target_graph_path_python_funcdef_annotation_rate",
        "intent_target_graph_path_python_compile_rate",
        "declared_module_graph_fulfillment_rate",
        "engine_domain_node_count",
        "engine_imports_inbound_total",
        "engine_python_glove_imports_to_engine_total",
        "graph_cache_loaded",
        "note",
    }
)


def _intent_coverage_compact_summary(project_root: Path) -> dict[str, Any]:
    """High-signal subset of :func:`_intent_query_coverage_rollup` for orient / dashboards."""

    roll = _intent_query_coverage_rollup(project_root)
    ft = roll.get("intent_target_fulfillment")
    impl = roll.get("implementation_coverage")
    eng = roll.get("engine_graph_coverage")
    ft_d = ft if isinstance(ft, dict) else {}
    impl_d = impl if isinstance(impl, dict) else {}
    eng_d = eng if isinstance(eng, dict) else {}
    out: dict[str, Any] = {
        "schema_version": 1,
        "status": "diagnostic",
        "intent_record_total": roll.get("intent_record_total"),
        "intent_records_with_target_id": roll.get("intent_records_with_target_id"),
        "intent_target_any_resolution_rate": ft_d.get("any_resolution_rate"),
        "intent_target_manifest_resolution_rate": ft_d.get("manifest_resolution_rate"),
        "intent_target_manifest_graph_dual_rate": ft_d.get("manifest_graph_dual_resolution_rate"),
        "intent_inferred_edges_in_cache": ft_d.get("inferred_intent_edges_in_cache"),
        "intent_hint_edge_materialization_rate": ft_d.get("intent_hint_edge_materialization_rate"),
        "intent_target_graph_implementation_rate": ft_d.get("intent_target_graph_implementation_rate"),
        "intent_target_graph_path_file_presence_rate": ft_d.get("intent_target_graph_path_file_presence_rate"),
        "intent_target_graph_path_python_syntax_rate": ft_d.get("intent_target_graph_path_python_syntax_rate"),
        "intent_target_graph_path_import_resolve_rate": ft_d.get("intent_target_graph_path_import_resolve_rate"),
        "intent_target_graph_path_imports_inbound_rate": ft_d.get("intent_target_graph_path_imports_inbound_rate"),
        "intent_target_graph_path_python_funcdef_annotation_rate": ft_d.get(
            "intent_target_graph_path_python_funcdef_annotation_rate"
        ),
        "intent_target_graph_path_python_compile_rate": ft_d.get("intent_target_graph_path_python_compile_rate"),
        "declared_module_graph_fulfillment_rate": impl_d.get("declared_module_graph_fulfillment_rate"),
        "engine_domain_node_count": eng_d.get("engine_domain_node_count"),
        "engine_imports_inbound_total": eng_d.get("imports_inbound_to_engine_total"),
        "engine_python_glove_imports_to_engine_total": eng_d.get("python_glove_imports_to_engine_total"),
        "graph_cache_loaded": roll.get("graph_cache_loaded"),
        "note": (
            "Compact rollup — full intent coverage_rollup remains on forge_intent query / MCP."
        ),
    }
    assert frozenset(out.keys()) == INTENT_COVERAGE_COMPACT_PUBLIC_KEYS, (
        "INTENT_COVERAGE_COMPACT_PUBLIC_KEYS drift — update frozenset to match emitted compact keys"
    )
    return out


def execute_intent_add(arguments: dict[str, Any]) -> dict[str, Any]:
    from forge.tools.intent.runtime import add_intent_record, new_intent_record

    root = resolve_thin_project_root(arguments)
    scope = str(arguments.get("scope") or "feature").strip().lower()
    description = str(arguments.get("description") or arguments.get("raw_description") or "").strip()
    if not description:
        raise ValueError("description is required for intent add")
    target_id = arguments.get("target_id")
    target_s = str(target_id).strip() if target_id is not None and str(target_id).strip() else None
    rec = new_intent_record(
        scope=scope,
        description=description,
        target_id=target_s,
        source=str(arguments.get("source") or "forge_intent"),
        layer_id=arguments.get("layer_id"),
        domain=arguments.get("domain"),
    )
    add_intent_record(root, rec)
    return _intent_payload("add", record_id=rec.id, records=[rec.to_yaml_dict()], confirmation_status="approved")


def execute_intent_query(arguments: dict[str, Any]) -> dict[str, Any]:
    from datetime import datetime

    from forge.tools.intent.runtime import load_intent_records

    root = resolve_thin_project_root(arguments)
    target_id = str(arguments.get("target_id") or "").strip()
    status_filter = str(arguments.get("status") or "").strip().lower()
    scope_filter = str(arguments.get("scope") or "").strip().lower()
    since_filter = str(arguments.get("since") or "").strip()
    limit = int(arguments.get("limit") or 0)
    response_tier = str(arguments.get("response_tier") or "L1").upper()
    rows: list[dict[str, Any]] = []
    for rec in load_intent_records(root):
        if scope_filter and str(rec.scope.value) != scope_filter:
            continue
        if status_filter and str(rec.status.value) != status_filter:
            continue
        if target_id and str(rec.target_id or "") != target_id:
            continue
        if since_filter:
            try:
                since_dt = datetime.fromisoformat(since_filter.replace("Z", "+00:00"))
                rec_dt = datetime.fromisoformat(rec.created.replace("Z", "+00:00"))
                if rec_dt < since_dt:
                    continue
            except Exception:
                pass
        if response_tier == "L0":
            summary = (rec.raw_description or "").split(".")[0]
            if len(summary) > 80:
                summary = summary[:77] + "..."
            rows.append(
                {
                    "id": rec.id,
                    "status": rec.status.value,
                    "scope": rec.scope.value,
                    "created_at": rec.created,
                    "summary": summary,
                }
            )
        elif response_tier == "L2":
            row = rec.model_dump()
            row.pop("extracted_nodes", None)
            row.pop("extracted_entities", None)
            rows.append(row)
        else:
            rows.append(
                {
                    "id": rec.id,
                    "status": rec.status.value,
                    "scope": rec.scope.value,
                    "created_at": rec.created,
                    "raw_description": rec.raw_description,
                    "target_id": rec.target_id,
                }
            )
    if limit > 0:
        rows = rows[:limit]
    payload = _intent_payload("query", records=rows)
    payload["response_tier"] = response_tier
    payload["filters_applied"] = {
        "status": status_filter or None,
        "scope": scope_filter or None,
        "target_id": target_id or None,
        "since": since_filter or None,
        "limit": limit if limit > 0 else None,
    }
    payload["coverage_rollup"] = _intent_query_coverage_rollup(root)
    return payload


def execute_intent_show(arguments: dict[str, Any]) -> dict[str, Any]:
    from forge.tools.intent.runtime import load_intent_by_id

    root = resolve_thin_project_root(arguments)
    record_id = str(arguments.get("record_id") or "").strip()
    if not record_id:
        raise ValueError("record_id is required")
    rec = load_intent_by_id(root, record_id)
    if rec is None:
        return _intent_payload("show", record_id=record_id, confirmation_status="not_found")
    return _intent_payload("show", record_id=record_id, records=[rec.to_yaml_dict()])


def execute_intent_update(arguments: dict[str, Any]) -> dict[str, Any]:
    from forge.tools.intent.runtime import load_intent_by_id, save_intent_record
    from forge.tools.intent.runtime import intent_dir

    root = resolve_thin_project_root(arguments)
    record_id = str(arguments.get("record_id") or "").strip()
    if not record_id:
        raise ValueError("record_id is required")
    rec = load_intent_by_id(root, record_id)
    if rec is None:
        return _intent_payload("update", record_id=record_id, confirmation_status="not_found")
    updates: dict[str, Any] = {}
    for key in ("raw_description", "description", "scope", "target_id", "status", "domain"):
        if key in arguments and arguments[key] is not None:
            updates[key if key != "description" else "raw_description"] = arguments[key]
    if arguments.get("rationale") is not None:
        schema = dict(rec.elicitation_schema or {})
        schema["rationale"] = str(arguments["rationale"])
        updates["elicitation_schema"] = schema
    if "raw_description" in updates:
        updates["raw_description"] = str(updates["raw_description"])
    if "scope" in updates:
        updates["scope"] = str(updates["scope"]).strip().lower()
    if "status" in updates:
        updates["status"] = str(updates["status"]).strip().lower()
    rec = rec.model_copy(update=updates)
    path = intent_dir(root) / f"{rec.id}.yaml"
    save_intent_record(rec, path)
    return _intent_payload("update", record_id=record_id, records=[rec.to_yaml_dict()], confirmation_status="updated")


def execute_intent_specify(arguments: dict[str, Any]) -> dict[str, Any]:
    from datetime import datetime, timezone
    from uuid import uuid4

    import yaml

    from forge.core.manifest import ManifestParser
    from forge.core.schemas import FunctionalIntentRecord, IntentStatus, NodeTier

    root = resolve_thin_project_root(arguments)
    design_intent_id = str(arguments.get("design_intent_id") or arguments.get("record_id") or "").strip()
    if not design_intent_id:
        raise ValueError("design_intent_id is required for action=specify")
    try:
        proposed_tier = NodeTier(str(arguments.get("proposed_tier") or "worker"))
    except Exception:
        proposed_tier = NodeTier.WORKER
    rec = FunctionalIntentRecord(
        id=f"FINTENT-{uuid4().hex[:8].upper()}",
        design_intent_id=design_intent_id,
        target_node_id=str(arguments.get("target_node_id") or arguments.get("target_id") or "").strip() or None,
        proposed_depends_on=[str(x) for x in (arguments.get("proposed_depends_on") or []) if str(x).strip()],
        proposed_implements=[str(x) for x in (arguments.get("proposed_implements") or []) if str(x).strip()],
        proposed_tier=proposed_tier,
        acceptance_criteria=[str(x) for x in (arguments.get("acceptance_criteria") or []) if str(x).strip()],
        status=IntentStatus.ACTIVE,
        created=datetime.now(timezone.utc).isoformat(),
        source="forge_intent",
    )
    out_dir = root / ".forge" / "intent" / "functional"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{rec.id}.functional.intent.yaml"
    payload = rec.model_dump()
    if hasattr(payload.get("proposed_tier"), "value"):
        payload["proposed_tier"] = payload["proposed_tier"].value
    out_path.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")
    if rec.target_node_id:
        manifest_path = resolve_manifest_path(root, warn_on_root_fallback=False)
        if manifest_path is not None:
            parser = ManifestParser(manifest_path)
            parser.update_node(
                "modules",
                rec.target_node_id,
                {
                    "proposed_depends_on": list(rec.proposed_depends_on),
                    "proposed_implements": list(rec.proposed_implements),
                },
            )
    return _intent_payload(
        "specify",
        record_id=rec.id,
        records=[rec.model_dump()],
        elicitation_required=False,
        confirmation_status="approved",
    )


def _annotate_payload(action: str, ann_id: str | None, *, success: bool, affected: int = 0) -> dict[str, Any]:
    return {
        "action": action,
        "annotation_id": ann_id,
        "affected_count": affected,
        "success": success,
    }


def execute_annotation_show(arguments: dict[str, Any]) -> dict[str, Any]:
    from forge.tools.audit.annotations import annotation_to_dict, find_annotation_by_id

    project_path = resolve_thin_project_root(arguments)
    ann_id = str(arguments.get("annotation_id") or "").strip()
    found = find_annotation_by_id(project_path, ann_id)
    if not found:
        return _annotate_payload("show", ann_id, success=False)
    _, ann = found
    return {
        **_annotate_payload("show", ann_id, success=True),
        "annotation": annotation_to_dict(ann),
    }


def execute_annotation_update(arguments: dict[str, Any]) -> dict[str, Any]:
    from forge.tools.audit.annotations import apply_annotation_fields

    project_path = resolve_thin_project_root(arguments)
    ann_id = str(arguments.get("annotation_id") or "").strip()
    fields = {
        k: arguments.get(k)
        for k in ("assigned", "note", "expires_when", "git_issue", "horizon", "status")
        if arguments.get(k) is not None
    }
    apply_annotation_fields(project_path, ann_id, fields)
    return _annotate_payload("update", ann_id, success=True, affected=1)


def execute_annotation_resolve(arguments: dict[str, Any]) -> dict[str, Any]:
    from forge.tools.audit.annotations import resolve_annotation

    project_path = resolve_thin_project_root(arguments)
    ann_id = str(arguments.get("annotation_id") or "").strip()
    note = str(arguments.get("resolution_note") or arguments.get("note") or "").strip()
    resolve_annotation(project_path, ann_id, note)
    return _annotate_payload("resolve", ann_id, success=True, affected=1)


def execute_annotation_dismiss(arguments: dict[str, Any]) -> dict[str, Any]:
    from forge.tools.audit.annotations import review_annotation_status

    project_path = resolve_thin_project_root(arguments)
    ann_id = str(arguments.get("annotation_id") or "").strip()
    review_annotation_status(project_path, ann_id, action="dismiss")
    return _annotate_payload("dismiss", ann_id, success=True, affected=1)
