"""Central MCP project root resolution — workspace defaults + elicitation (Sprint 12)."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import mcp.types as types

from forge.mcp.elicitation import check_project_context
from forge.mcp.handlers.error_handlers import elicitation_tool_result, handle_validation_error
from forge.mcp.handlers.validation import validate_project_path


def explicit_project_path_from_arguments(arguments: dict[str, Any]) -> str | None:
    pp = arguments.get("project_path")
    if pp is not None and str(pp).strip():
        return str(pp).strip()
    proj_ctx = arguments.get("project_context")
    if isinstance(proj_ctx, dict):
        inner = proj_ctx.get("project_path")
        if inner is not None and str(inner).strip():
            return str(inner).strip()
    try:
        from forge.mcp.server import get_meta

        meta_pp = get_meta("project_path", None)
        if meta_pp is not None and str(meta_pp).strip():
            return str(meta_pp).strip()
        meta_ctx = get_meta("project_context", None)
        if isinstance(meta_ctx, dict):
            mpp = meta_ctx.get("project_path")
            if mpp is not None and str(mpp).strip():
                return str(mpp).strip()
    except Exception:
        pass
    return None


def resolve_validated_project_path_result(
    arguments: dict[str, Any],
) -> tuple[Path | None, types.CallToolResult | None]:
    """Return ``(path, None)`` when resolvable, otherwise ``(None, tool result)``.

    When ``project_path`` is omitted, workspace + MCP roots drive resolution; ambiguous
    routing returns a structured elicitation envelope with ``is_error=False``.
    """
    explicit = explicit_project_path_from_arguments(arguments)
    args = dict(arguments)
    if explicit:
        args["project_path"] = explicit
    else:
        args.pop("project_path", None)

    if explicit:
        try:
            return validate_project_path(explicit), None
        except (ValueError, FileNotFoundError, NotADirectoryError) as exc:
            return None, handle_validation_error(
                "project_path",
                str(exc),
                {"project_path": explicit},
            )

    elic = check_project_context(args)
    if elic is not None:
        return None, elicitation_tool_result(elic)

    try:
        from forge.mcp.thin_core import resolve_thin_project_root

        root = resolve_thin_project_root(args)
    except ValueError as exc:
        avail: list[dict[str, str]] = []
        try:
            from forge.mcp.mcp_workspace import current_forge_workspace

            fw = current_forge_workspace()
            if fw is not None and fw.projects:
                avail = [{"id": pid, "path": str(pi.path)} for pid, pi in fw.projects.items()]
        except Exception:
            pass
        return None, elicitation_tool_result(
            {
                "elicitation_required": True,
                "elicitation_kind": "project_selection",
                "message": str(exc),
                "available_projects": avail,
            }
        )

    try:
        return validate_project_path(str(root)), None
    except (ValueError, FileNotFoundError, NotADirectoryError) as exc:
        return None, handle_validation_error(
            "project_path",
            str(exc),
            {"project_path": str(root)},
        )


__all__ = [
    "explicit_project_path_from_arguments",
    "resolve_validated_project_path_result",
]
