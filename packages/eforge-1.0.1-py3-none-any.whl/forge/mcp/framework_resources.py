"""
Framework Mapping MCP Resources - Universal Framework Discovery

MCP resource handlers for framework mapping, discovery, tracing,
verification, and onboarding capabilities.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

from mcp.server.models import InitializationOptions
from mcp.server.stdio import stdio_server
from mcp.types import Resource

from forge.core.framework_mapper import FrameworkMapper, MappingStrategy, StackType
from forge.core.path_utils import resolve_project_path


def register_framework_resources(registry: Any) -> None:
    """Register framework mapping resources with MCP server."""
    
    async def handle_framework_discover(uri: str) -> str:
        """Handle framework discovery requests."""
        try:
            # Parse query parameters from URI
            parsed_uri = uri.split("?")
            base_uri = parsed_uri[0]
            query_params = {}
            if len(parsed_uri) > 1:
                for param in parsed_uri[1].split("&"):
                    if "=" in param:
                        key, value = param.split("=", 1)
                        query_params[key] = value
            
            project_path_str = query_params.get("project_path", ".")
            strategy = query_params.get("strategy", "hybrid")
            output_format = query_params.get("format", "json")
            
            # Resolve project path
            project_path = Path(project_path_str)
            if not project_path.is_absolute():
                project_path = resolve_project_path() or Path.cwd()
                project_path = project_path / project_path_str
            
            if not project_path.exists():
                return json.dumps({
                    "error": "Project path does not exist",
                    "path": str(project_path)
                })
            
            # Discover framework
            mapper = FrameworkMapper()
            mapping_strategy = MappingStrategy(strategy)
            framework_map = mapper.map_framework(project_path, mapping_strategy)
            
            # Convert to execution graph
            exec_graph = mapper.convert_to_execution_graph(framework_map)
            
            # Format response
            if output_format == "summary":
                response = {
                    "framework_info": {
                        "name": framework_map.framework_name,
                        "version": framework_map.framework_version,
                        "stack_type": framework_map.stack_type.value,
                        "strategy": framework_map.mapping_strategy.value
                    },
                    "discovery_summary": {
                        "nodes_found": len(framework_map.nodes),
                        "edges_found": len(framework_map.edges),
                        "entry_points": framework_map.entry_points,
                        "execution_graph_nodes": len(exec_graph.nodes),
                        "execution_graph_edges": len(exec_graph.edges)
                    },
                    "node_types": _summarize_node_types(framework_map.nodes),
                    "edge_types": _summarize_edge_types(framework_map.edges)
                }
            else:  # full
                response = {
                    "framework_map": {
                        "framework_name": framework_map.framework_name,
                        "framework_version": framework_map.framework_version,
                        "stack_type": framework_map.stack_type.value,
                        "mapping_strategy": framework_map.mapping_strategy.value,
                        "nodes": [
                            {
                                "id": node.id,
                                "name": node.name,
                                "type": node.type,
                                "file_path": node.file_path,
                                "line_start": node.line_start,
                                "line_end": node.line_end,
                                "stack_type": node.stack_type.value,
                                "metadata": node.metadata
                            }
                            for node in framework_map.nodes
                        ],
                        "edges": [
                            {
                                "id": edge.id,
                                "from_node": edge.from_node,
                                "to_node": edge.to_node,
                                "edge_type": edge.edge_type,
                                "strength": edge.strength,
                                "metadata": edge.metadata
                            }
                            for edge in framework_map.edges
                        ],
                        "entry_points": framework_map.entry_points,
                        "metadata": framework_map.metadata
                    },
                    "execution_graph": {
                        "nodes": [
                            {
                                "id": node.id,
                                "kind": node.kind,
                                "module": node.module,
                                "qualname": node.qualname,
                                "file": node.file,
                                "line": node.line,
                                "stack": node.stack,
                                "layer": node.layer
                            }
                            for node in exec_graph.nodes.values()
                        ],
                        "edges": [
                            {
                                "id": edge.id,
                                "from_id": edge.from_id,
                                "to_id": edge.to_id,
                                "edge_kind": edge.edge_kind,
                                "layer": edge.layer
                            }
                            for edge in exec_graph.edges.values()
                        ]
                    }
                }
            
            return json.dumps(response, indent=2)
        
        except Exception as e:
            return json.dumps({
                "error": str(e),
                "uri": uri
            })
    
    async def handle_framework_trace(uri: str) -> str:
        """Handle framework execution tracing requests."""
        try:
            # Parse query parameters
            parsed_uri = uri.split("?")
            query_params = {}
            if len(parsed_uri) > 1:
                for param in parsed_uri[1].split("&"):
                    if "=" in param:
                        key, value = param.split("=", 1)
                        query_params[key] = value
            
            project_path_str = query_params.get("project_path", ".")
            entry_point = query_params.get("entry_point")
            timeout = int(query_params.get("timeout", "60"))
            
            if not entry_point:
                return json.dumps({
                    "error": "entry_point parameter is required"
                })
            
            # Resolve project path
            project_path = Path(project_path_str)
            if not project_path.is_absolute():
                project_path = resolve_project_path() or Path.cwd()
                project_path = project_path / project_path_str
            
            if not project_path.exists():
                return json.dumps({
                    "error": "Project path does not exist",
                    "path": str(project_path)
                })
            
            # Trace execution
            mapper = FrameworkMapper()
            stack_type = mapper.detect_stack_type(project_path)
            stack_mapper = mapper.mappers.get(stack_type)
            
            if not stack_mapper:
                return json.dumps({
                    "error": f"No mapper available for stack: {stack_type.value}"
                })
            
            # Perform tracing
            framework_map = stack_mapper.trace_execution(entry_point, project_path)
            exec_graph = mapper.convert_to_execution_graph(framework_map)
            
            response = {
                "trace_info": {
                    "entry_point": entry_point,
                    "stack_type": stack_type.value,
                    "timeout": timeout
                },
                "trace_results": {
                    "nodes_traced": len(framework_map.nodes),
                    "edges_traced": len(framework_map.edges),
                    "execution_graph_nodes": len(exec_graph.nodes),
                    "execution_graph_edges": len(exec_graph.edges)
                },
                "execution_flow": _extract_execution_flow(framework_map),
                "performance_metrics": _calculate_performance_metrics(framework_map)
            }
            
            return json.dumps(response, indent=2)
        
        except Exception as e:
            return json.dumps({
                "error": str(e),
                "uri": uri
            })
    
    async def handle_framework_verify(uri: str) -> str:
        """Handle framework verification against intents."""
        try:
            # Parse query parameters
            parsed_uri = uri.split("?")
            query_params = {}
            if len(parsed_uri) > 1:
                for param in parsed_uri[1].split("&"):
                    if "=" in param:
                        key, value = param.split("=", 1)
                        query_params[key] = value
            
            project_path_str = query_params.get("project_path", ".")
            intents_file = query_params.get("intents_file")
            
            if not intents_file:
                return json.dumps({
                    "error": "intents_file parameter is required"
                })
            
            # Resolve paths
            project_path = Path(project_path_str)
            if not project_path.is_absolute():
                project_path = resolve_project_path() or Path.cwd()
                project_path = project_path / project_path_str
            
            intents_path = Path(intents_file)
            if not intents_path.is_absolute():
                intents_path = project_path / intents_path
            
            if not project_path.exists():
                return json.dumps({
                    "error": "Project path does not exist",
                    "path": str(project_path)
                })
            
            if not intents_path.exists():
                return json.dumps({
                    "error": "Intents file does not exist",
                    "path": str(intents_path)
                })
            
            # Load intents
            with open(intents_path, 'r') as f:
                intents = json.load(f)
            
            # Map framework
            mapper = FrameworkMapper()
            framework_map = mapper.map_framework(project_path, MappingStrategy.HYBRID)
            
            # Perform verification
            verification_results = []
            total_coverage = 0.0
            
            for intent in intents:
                intent_name = intent.get("name", "unnamed")
                intent_description = intent.get("description", "")
                
                # Calculate coverage
                coverage_score = _calculate_intent_coverage(intent, framework_map)
                total_coverage += coverage_score
                
                verification_results.append({
                    "intent": intent_name,
                    "description": intent_description,
                    "coverage_score": coverage_score,
                    "status": "covered" if coverage_score > 0.7 else "partial" if coverage_score > 0.3 else "uncovered",
                    "matched_nodes": _find_matching_nodes(intent, framework_map),
                    "recommendations": _generate_intent_recommendations(intent, framework_map, coverage_score)
                })
            
            # Calculate overall metrics
            avg_coverage = total_coverage / len(intents) if intents else 0.0
            covered_intents = len([r for r in verification_results if r["status"] == "covered"])
            partial_intents = len([r for r in verification_results if r["status"] == "partial"])
            
            response = {
                "verification_summary": {
                    "total_intents": len(intents),
                    "fully_covered": covered_intents,
                    "partially_covered": partial_intents,
                    "uncovered": len(intents) - covered_intents - partial_intents,
                    "average_coverage": avg_coverage,
                    "coverage_percentage": (covered_intents + 0.5 * partial_intents) / len(intents) * 100 if intents else 0
                },
                "framework_analysis": {
                    "nodes_found": len(framework_map.nodes),
                    "edges_found": len(framework_map.edges),
                    "entry_points": framework_map.entry_points,
                    "stack_type": framework_map.stack_type.value
                },
                "intent_verification": verification_results,
                "recommendations": _generate_overall_recommendations(verification_results, framework_map)
            }
            
            return json.dumps(response, indent=2)
        
        except Exception as e:
            return json.dumps({
                "error": str(e),
                "uri": uri
            })
    
    async def handle_framework_onboard(uri: str) -> str:
        """Handle framework onboarding package creation."""
        try:
            # Parse query parameters
            parsed_uri = uri.split("?")
            query_params = {}
            if len(parsed_uri) > 1:
                for param in parsed_uri[1].split("&"):
                    if "=" in param:
                        key, value = param.split("=", 1)
                        query_params[key] = value
            
            project_path_str = query_params.get("project_path", ".")
            output_dir = query_params.get("output_dir")
            
            # Resolve project path
            project_path = Path(project_path_str)
            if not project_path.is_absolute():
                project_path = resolve_project_path() or Path.cwd()
                project_path = project_path / project_path_str
            
            if not project_path.exists():
                return json.dumps({
                    "error": "Project path does not exist",
                    "path": str(project_path)
                })
            
            # Map framework
            mapper = FrameworkMapper()
            framework_map = mapper.map_framework(project_path, MappingStrategy.HYBRID)
            
            # Create onboarding package
            onboarding_package = {
                "framework_info": {
                    "name": framework_map.framework_name,
                    "version": framework_map.framework_version,
                    "stack_type": framework_map.stack_type.value,
                    "original_path": str(project_path),
                    "discovery_timestamp": framework_map.created_at
                },
                "discovered_structure": {
                    "nodes": [
                        {
                            "id": node.id,
                            "name": node.name,
                            "type": node.type,
                            "file_path": node.file_path,
                            "line_start": node.line_start,
                            "line_end": node.line_end,
                            "metadata": node.metadata,
                            "dependency_count": len(node.dependencies),
                            "caller_count": len(node.callers)
                        }
                        for node in framework_map.nodes
                    ],
                    "edges": [
                        {
                            "id": edge.id,
                            "from_node": edge.from_node,
                            "to_node": edge.to_node,
                            "edge_type": edge.edge_type,
                            "strength": edge.strength,
                            "metadata": edge.metadata
                        }
                        for edge in framework_map.edges
                    ],
                    "entry_points": framework_map.entry_points,
                    "complexity_metrics": _calculate_complexity_metrics(framework_map)
                },
                "forge_integration_plan": {
                    "suggested_manifest_nodes": _generate_suggested_manifest_nodes(framework_map),
                    "suggested_annotations": _generate_suggested_annotations(framework_map),
                    "migration_steps": _generate_migration_steps(framework_map),
                    "estimated_effort": _estimate_migration_effort(framework_map),
                    "risk_assessment": _assess_migration_risks(framework_map)
                },
                "onboarding_checklist": _create_onboarding_checklist(framework_map)
            }
            
            # Save to output directory if specified
            if output_dir:
                output_path = Path(output_dir)
                output_path.mkdir(parents=True, exist_ok=True)
                
                with open(output_path / "onboarding_package.json", 'w') as f:
                    json.dump(onboarding_package, f, indent=2)
                
                onboarding_package["saved_to"] = str(output_path)
            
            return json.dumps(onboarding_package, indent=2)
        
        except Exception as e:
            return json.dumps({
                "error": str(e),
                "uri": uri
            })


def _summarize_node_types(nodes: List[Any]) -> Dict[str, int]:
    """Summarize node types in framework."""
    node_types = {}
    for node in nodes:
        node_types[node.type] = node_types.get(node.type, 0) + 1
    return node_types


def _summarize_edge_types(edges: List[Any]) -> Dict[str, int]:
    """Summarize edge types in framework."""
    edge_types = {}
    for edge in edges:
        edge_types[edge.edge_type] = edge_types.get(edge.edge_type, 0) + 1
    return edge_types


def _extract_execution_flow(framework_map: Any) -> List[Dict[str, Any]]:
    """Extract execution flow from traced framework."""
    flow = []
    
    # Find entry points and trace their execution
    for entry_point in framework_map.entry_points:
        entry_flow = {
            "entry_point": entry_point,
            "execution_path": [],
            "critical_nodes": [],
            "bottlenecks": []
        }
        
        # Find nodes in execution path
        for node in framework_map.nodes:
            if entry_point in node.file_path or entry_point in node.metadata.values():
                entry_flow["execution_path"].append({
                    "node": node.name,
                    "type": node.type,
                    "file": node.file_path,
                    "line": node.line_start
                })
        
        flow.append(entry_flow)
    
    return flow


def _calculate_performance_metrics(framework_map: Any) -> Dict[str, Any]:
    """Calculate performance metrics for traced framework."""
    metrics = {
        "total_nodes": len(framework_map.nodes),
        "total_edges": len(framework_map.edges),
        "average_dependencies": 0.0,
        "max_depth": 0,
        "complexity_score": 0.0
    }
    
    if framework_map.nodes:
        total_deps = sum(len(node.dependencies) for node in framework_map.nodes)
        metrics["average_dependencies"] = total_deps / len(framework_map.nodes)
        metrics["max_depth"] = max(len(node.callers) for node in framework_map.nodes)
        metrics["complexity_score"] = (len(framework_map.nodes) + len(framework_map.edges)) / 100
    
    return metrics


def _calculate_intent_coverage(intent: Dict[str, Any], framework_map: Any) -> float:
    """Calculate how well an intent is covered by the framework."""
    intent_description = intent.get("description", "").lower()
    intent_name = intent.get("name", "").lower()
    
    coverage_score = 0.0
    keywords = set(intent_description.split()) | set(intent_name.split())
    
    for node in framework_map.nodes:
        node_text = f"{node.name} {node.type} {' '.join(str(v) for v in node.metadata.values())}".lower()
        keyword_matches = sum(1 for keyword in keywords if keyword in node_text)
        if keyword_matches > 0:
            coverage_score += keyword_matches / len(keywords)
    
    if len(framework_map.nodes) > 0:
        coverage_score = min(coverage_score / len(framework_map.nodes) * 10, 1.0)
    
    return coverage_score


def _find_matching_nodes(intent: Dict[str, Any], framework_map: Any) -> List[str]:
    """Find framework nodes that match an intent."""
    intent_description = intent.get("description", "").lower()
    intent_name = intent.get("name", "").lower()
    
    matching_nodes = []
    keywords = set(intent_description.split()) | set(intent_name.split())
    
    for node in framework_map.nodes:
        node_text = f"{node.name} {node.type}".lower()
        if any(keyword in node_text for keyword in keywords):
            matching_nodes.append(node.id)
    
    return matching_nodes


def _generate_intent_recommendations(intent: Dict[str, Any], framework_map: Any, coverage_score: float) -> List[str]:
    """Generate recommendations for intent coverage."""
    recommendations = []
    
    if coverage_score < 0.3:
        recommendations.append("Intent not covered - consider implementing missing components")
    elif coverage_score < 0.7:
        recommendations.append("Intent partially covered - enhance existing components")
    else:
        recommendations.append("Intent well covered - maintain current implementation")
    
    return recommendations


def _generate_overall_recommendations(verification_results: List[Dict[str, Any]], framework_map: Any) -> List[str]:
    """Generate overall recommendations for framework verification."""
    recommendations = []
    
    uncovered_count = len([r for r in verification_results if r["status"] == "uncovered"])
    if uncovered_count > 0:
        recommendations.append(f"Address {uncovered_count} uncovered intents")
    
    if len(framework_map.entry_points) == 0:
        recommendations.append("Define entry points for better tracing")
    
    if len(framework_map.nodes) < 10:
        recommendations.append("Framework appears small - verify discovery completeness")
    
    return recommendations


def _calculate_complexity_metrics(framework_map: Any) -> Dict[str, Any]:
    """Calculate complexity metrics for framework."""
    return {
        "cyclomatic_complexity": len(framework_map.edges) - len(framework_map.nodes) + 2,
        "coupling_factor": sum(len(node.dependencies) for node in framework_map.nodes) / len(framework_map.nodes) if framework_map.nodes else 0,
        "cohesion_score": len(framework_map.entry_points) / len(framework_map.nodes) if framework_map.nodes else 0,
        "maintainability_index": max(0, 100 - (len(framework_map.nodes) + len(framework_map.edges)) / 10)
    }


def _estimate_migration_effort(framework_map: Any) -> Dict[str, Any]:
    """Estimate migration effort for framework."""
    effort_score = 0
    
    # Base effort based on size
    effort_score += len(framework_map.nodes) * 0.5
    effort_score += len(framework_map.edges) * 0.3
    
    # Complexity adjustments
    if framework_map.stack_type == StackType.UNKNOWN:
        effort_score += 20  # Unknown stack requires more effort
    
    effort_score += len(framework_map.entry_points) * 2
    
    return {
        "effort_score": effort_score,
        "estimated_hours": max(1, effort_score / 10),
        "complexity": "low" if effort_score < 20 else "medium" if effort_score < 50 else "high",
        "recommended_team_size": max(1, effort_score // 40)
    }


def _assess_migration_risks(framework_map: Any) -> List[Dict[str, Any]]:
    """Assess migration risks for framework."""
    risks = []
    
    # Check for complex dependencies
    high_deps_nodes = [node for node in framework_map.nodes if len(node.dependencies) > 10]
    if high_deps_nodes:
        risks.append({
            "type": "complex_dependencies",
            "severity": "medium",
            "description": f"{len(high_deps_nodes)} nodes have >10 dependencies",
            "mitigation": "Consider refactoring high-dependency nodes"
        })
    
    # Check for missing entry points
    if len(framework_map.entry_points) == 0:
        risks.append({
            "type": "no_entry_points",
            "severity": "high",
            "description": "No entry points identified",
            "mitigation": "Manually identify and document entry points"
        })
    
    # Check stack compatibility
    if framework_map.stack_type == StackType.UNKNOWN:
        risks.append({
            "type": "unknown_stack",
            "severity": "high",
            "description": "Unknown programming stack",
            "mitigation": "Implement stack-specific mapper"
        })
    
    return risks


def _create_onboarding_checklist(framework_map: Any) -> List[Dict[str, Any]]:
    """Create onboarding checklist for framework."""
    checklist = [
        {
            "task": "Review discovered framework structure",
            "status": "ready",
            "priority": "high"
        },
        {
            "task": "Validate entry points and execution flow",
            "status": "ready",
            "priority": "high"
        },
        {
            "task": "Create initial manifest based on discovered nodes",
            "status": "ready",
            "priority": "medium"
        },
        {
            "task": "Add annotations for complex components",
            "status": "ready",
            "priority": "medium"
        },
        {
            "task": "Test framework integration with Forge",
            "status": "ready",
            "priority": "medium"
        },
        {
            "task": "Verify intent coverage and adjust",
            "status": "ready",
            "priority": "low"
        }
    ]
    
    return checklist
    
    # Register all resource handlers with the registry
    registry.register_resource("forge://framework/discover", handle_framework_discover)
    registry.register_resource("forge://framework/trace", handle_framework_trace)
    registry.register_resource("forge://framework/verify", handle_framework_verify)
    registry.register_resource("forge://framework/onboard", handle_framework_onboard)
