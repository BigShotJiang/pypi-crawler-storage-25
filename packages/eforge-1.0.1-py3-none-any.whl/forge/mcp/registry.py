from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

import mcp.types as types

# Extensibility: plugins call register_tool() at import time.
_TOOL_SCHEMAS: list[types.Tool] = []
_HANDLERS: dict[str, Callable[[dict[str, Any]], Awaitable[types.CallToolResult]]] = {}
_DEPRECATED_TOOL_SCHEMAS: list[types.Tool] = []

# Optional resource handlers: uri prefix -> async (uri str) -> str | bytes
_RESOURCE_HANDLERS: list[tuple[str, Callable[[str], Awaitable[str]]]] = []


def register_tool(
    name: str,
    handler: Callable[[dict[str, Any]], Awaitable[types.CallToolResult]],
    schema: types.Tool,
) -> None:
    """Register or replace an MCP tool (name must match schema.name)."""
    _HANDLERS[name] = handler
    for i, t in enumerate(_TOOL_SCHEMAS):
        if t.name == name:
            _TOOL_SCHEMAS[i] = schema
            return
    _TOOL_SCHEMAS.append(schema)


def register_deprecated_tool(
    name: str,
    handler: Callable[[dict[str, Any]], Awaitable[types.CallToolResult]],
    schema: types.Tool,
) -> None:
    """Register handler + schema for ``call_tool`` only (excluded from ``list_tools``)."""
    _HANDLERS[name] = handler
    for i, t in enumerate(_DEPRECATED_TOOL_SCHEMAS):
        if t.name == name:
            _DEPRECATED_TOOL_SCHEMAS[i] = schema
            return
    _DEPRECATED_TOOL_SCHEMAS.append(schema)


def all_tool_schemas() -> list[types.Tool]:
    return list(_TOOL_SCHEMAS)


def deprecated_tool_schemas() -> list[types.Tool]:
    return list(_DEPRECATED_TOOL_SCHEMAS)


# Import clean registry registration after function definitions
from .handlers.registry import register_clean_tools

# Auto-register clean tools on import
register_clean_tools()


def get_tool_handler(
    name: str,
) -> Callable[[dict[str, Any]], Awaitable[types.CallToolResult]] | None:
    return _HANDLERS.get(name)


def register_resource(prefix: str, handler: Callable[[str], Awaitable[str]]) -> None:
    """Register a resource reader for URIs starting with prefix (e.g. forge://custom/)."""
    _RESOURCE_HANDLERS.append((prefix, handler))


def resource_handlers() -> list[tuple[str, Callable[[str], Awaitable[str]]]]:
    return list(_RESOURCE_HANDLERS)
