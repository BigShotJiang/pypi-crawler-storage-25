from __future__ import annotations

from pathlib import Path
from typing import Any

from forge.core.manifest_path import resolve_manifest_path
from forge.tools.docs_audit.contracts.models import AuditFailure, TriggeredRule


def resolve_audit_paths(project_root: Path) -> tuple[Path, Path, Path | None, Path]:
    manifest_path = resolve_manifest_path(project_root) or (project_root / ".forge" / "manifest.yaml")
    # DEPRECATED: change-impact.yaml — use .forge/impact-rules.yaml via _load_rules()
    # Legacy paths preserved for audit bundle backward compat only.
    impact_path = project_root / ".forge" / "change-impact.yaml"
    if not impact_path.is_file():
        impact_path = project_root / "change-impact.yaml"
    if not impact_path.is_file():
        impact_path = project_root / "docs" / "change-impact.yaml"
    impact_local = project_root / "docs" / "change-impact.local.yaml"
    if not impact_local.is_file():
        impact_local = project_root / "change-impact.local.yaml"
    docs_root = project_root / "docs"
    il = impact_local if impact_local.is_file() else None
    return manifest_path, impact_path, il, docs_root


def audit_result_payload(result: Any) -> dict[str, Any]:
    failures: list[dict[str, Any]] = []
    for f in result.failures:
        if isinstance(f, AuditFailure):
            sev = f.severity.value if hasattr(f.severity, "value") else str(f.severity)
            failures.append(
                {
                    "rule_id": f.rule_id,
                    "severity": sev,
                    "file": f.file,
                    "message": f.message,
                    "rule_source": f.rule_source,
                    "suggested_updates": list(f.suggested_updates),
                }
            )
    triggered: list[dict[str, Any]] = []
    for tr in result.triggered_rules:
        if isinstance(tr, TriggeredRule):
            r = tr.rule
            sev = r.severity.value if hasattr(r.severity, "value") else str(r.severity)
            triggered.append(
                {
                    "rule_id": r.id,
                    "severity": sev,
                    "reasons": list(tr.reasons),
                }
            )
    return {
        "exit_code": result.exit_code,
        "failures": failures,
        "triggered_rules": triggered,
        "waiver_warnings": list(result.waiver_warnings),
        "graph_impact": dict(getattr(result, "graph_impact", {}) or {}),
    }
