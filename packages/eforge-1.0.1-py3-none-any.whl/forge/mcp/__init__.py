"""Forge MCP stdio server (thin wrappers over existing forge APIs)."""

from __future__ import annotations


def main():
    from forge.mcp.server import main as _main

    return _main()


def run_mcp_stdio(*args, **kwargs):
    from forge.mcp.server import run_mcp_stdio as _run

    return _run(*args, **kwargs)


__all__ = ["main", "run_mcp_stdio"]
