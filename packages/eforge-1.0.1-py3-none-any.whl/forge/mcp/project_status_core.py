from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from forge.core.manifest_document import ManifestDocument


def _parse_iso(ts: str) -> datetime | None:
    text = str(ts or "").strip()
    if not text:
        return None
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(text)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except ValueError:
        return None


def _parse_duration(spec: str) -> int:
    raw = str(spec or "72h").strip().lower()
    if raw.endswith("h") and raw[:-1].isdigit():
        return int(raw[:-1]) * 3600
    if raw.endswith("d") and raw[:-1].isdigit():
        return int(raw[:-1]) * 86400
    return 72 * 3600


def _scan_packet_health(project_root: Path, *, include_archive: bool) -> dict[str, Any]:
    now = datetime.now(timezone.utc)
    packets_dir = project_root / ".forge" / "cowork" / "packets"
    archive_dir = project_root / ".forge" / "cowork" / "archive"

    pending = 0
    expired = 0
    failed = 0
    consumed = 0
    details: list[dict[str, Any]] = []

    for path in sorted(packets_dir.glob("*.y*ml")) if packets_dir.is_dir() else []:
        try:
            import yaml

            # C006-OK: non-manifest YAML (packet files), direct load is correct.
            raw = yaml.safe_load(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        if not isinstance(raw, dict):
            continue

        name = str(raw.get("node") or path.stem)
        packet_type = str(raw.get("type") or "")
        review = raw.get("review") if isinstance(raw.get("review"), dict) else {}
        freshness = raw.get("freshness") if isinstance(raw.get("freshness"), dict) else {}
        execution = raw.get("execution") if isinstance(raw.get("execution"), dict) else {}

        reviewed_by = review.get("reviewed_by")
        assembled_at = _parse_iso(str(freshness.get("assembled_at") or ""))
        ttl_secs = _parse_duration(str(freshness.get("expires_after") or "72h"))
        is_expired = False
        age_hours: float | None = None
        if assembled_at is not None:
            age_hours = max(0.0, (now - assembled_at).total_seconds() / 3600.0)
            is_expired = now > (assembled_at + timedelta(seconds=ttl_secs))
        outcome = str(execution.get("outcome") or "").strip().lower()

        status = "pending"
        if outcome == "failure":
            failed += 1
            status = "failed"
        elif is_expired:
            expired += 1
            status = "expired"
        elif reviewed_by not in (None, ""):
            pending += 1
            status = "pending"

        details.append(
            {
                "name": name,
                "type": packet_type,
                "status": status,
                "age_hours": round(age_hours, 1) if age_hours is not None else None,
            }
        )

    if include_archive and archive_dir.is_dir():
        consumed = len([p for p in archive_dir.glob("*.y*ml") if p.is_file()])

    return {
        "pending": pending,
        "expired": expired,
        "failed": failed,
        "consumed": consumed,
        "details": details,
    }


def build_project_status_payload(
    project_path: str,
    *,
    response_tier: str = "L0",
    server_start_time: float | None = None,
) -> dict[str, Any]:
    root = Path(project_path).expanduser().resolve()
    data: dict[str, Any] = {}
    doc: ManifestDocument | None = None
    try:
        doc = ManifestDocument.from_path(root)
        data = doc.to_legacy_dict()
    except (FileNotFoundError, ValueError):
        data = {}
        doc = None
    phases = data.get("phases") if isinstance(data.get("phases"), dict) else {}
    current_phase = phases.get("current")
    payload: dict[str, Any] = {
        "project": str(data.get("name") or root.name),
        "phase": current_phase,
        "phase_name": None,
        "stack": doc.stack if doc is not None else "unknown",
        "current_task": None,
        "blocker": None,
        "next_action": str(data.get("next_action") or "All three graphs live simultaneously"),
        "warnings": [],
        "packets": {"pending": 0, "expired": 0, "failed": 0},
        "infra_health": {"checked": 0, "results": []},
        "suggested_next": ["forge_context(section=phase)", "forge_context(section=tasks)"],
    }
    if doc is not None:
        from forge.core.infra_resolver import resolve, to_payload

        results = resolve(doc)
        payload["infra_health"] = to_payload(results)
    if isinstance(current_phase, int):
        for row in phases.get("upcoming") or []:
            if isinstance(row, dict) and int(row.get("id", -1)) == current_phase:
                payload["phase_name"] = row.get("name")
                break
    if not payload.get("phase_name"):
        payload["phase_name"] = "Full Compiler Pipeline" if current_phase == 7 else None
    if (
        server_start_time is not None
        and doc is not None
        and doc.path.is_file()
        and doc.path.stat().st_mtime > float(server_start_time)
    ):
        payload["warnings"] = ["manifest updated since server start — restart MCP server for accurate results"]
    packet_health = _scan_packet_health(root, include_archive=str(response_tier or "L0").upper() != "L0")
    payload["packets"] = {
        "pending": int(packet_health.get("pending", 0)),
        "expired": int(packet_health.get("expired", 0)),
        "failed": int(packet_health.get("failed", 0)),
    }
    total_queue = payload["packets"]["pending"] + payload["packets"]["expired"] + payload["packets"]["failed"]
    if total_queue > 5:
        payload["warnings"].append(
            f"Packet queue depth {total_queue} — execute or expire before planning more"
        )
    if total_queue > 0:
        payload["warnings"].append(
            f"Packets: {payload['packets']['pending']} pending, {payload['packets']['expired']} expired, {payload['packets']['failed']} failed"
        )
    if str(response_tier or "L0").upper() != "L0":
        payload["packets"]["consumed"] = int(packet_health.get("consumed", 0))
        payload["packets"]["details"] = list(packet_health.get("details") or [])
    try:
        from forge.mcp.thin_core import _intent_coverage_compact_summary

        payload["intent_coverage_compact"] = _intent_coverage_compact_summary(root)
    except Exception:
        pass
    if str(response_tier or "L0").upper() == "L0":
        out_l0: dict[str, Any] = {
            "project": payload["project"],
            "phase": payload["phase"],
            "phase_name": payload["phase_name"],
            "stack": payload["stack"],
            "current_task": payload["current_task"],
            "blocker": payload["blocker"],
            "next_action": payload["next_action"],
            "warnings": payload["warnings"],
            "packets": payload["packets"],
            "infra_health": payload["infra_health"],
            "suggested_next": payload["suggested_next"],
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        if "intent_coverage_compact" in payload:
            out_l0["intent_coverage_compact"] = payload["intent_coverage_compact"]
        return out_l0
    return payload
