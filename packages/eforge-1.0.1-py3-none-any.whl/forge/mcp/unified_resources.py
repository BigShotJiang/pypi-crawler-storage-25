"""
Unified MCP Resources - World's Most Versatile & Functional MCP

Integrates ALL Phase D capabilities into a single, comprehensive MCP surface:
- Mathematical Pipeline (Dimstack/Comburiscope)
- Vector Memory Layer (Fuzzy semantic search)
- Auto-Triangulation (Cross-graph sync)
- MCP Tasks + Forge Apps (Enterprise task management)
- Semantic Extraction + Unification (Clean intent processing)
- Forge Snapshots (Persistent multi-device architecture)
- Framework Mapping (Universal discovery)
- Atomic Memory Mapping (Cross-language analysis)
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from mcp.server.models import InitializationOptions
from mcp.server.stdio import stdio_server
from mcp.types import Resource

# Import all Phase D systems
from forge.core.framework_mapper import FrameworkMapper, MappingStrategy
from forge.core.atomic_memory_mapper import AtomicMemoryMapper
# from forge.core.dimstack_integration import DimstackProcessor  # Not needed for unified resources
from forge.core.vector_memory import VectorMemoryStore
from forge.core.mcp_tasks import TaskManager
from forge.core.forge_apps import AppRegistry
from forge.core.semantic_extractor import SemanticExtractor
from forge.core.unified_intent_system import UnifiedIntentQuery
from forge.core.snapshots import get_snapshot_manager
from forge.core.path_utils import resolve_project_path


def register_unified_resources(registry: Any) -> None:
    """Register ALL unified resources for the world's most versatile MCP."""
    
    # ==================== UNIFIED DISCOVERY RESOURCES ====================
    
    async def handle_unified_discover(uri: str) -> str:
        """Unified framework + memory + semantic discovery."""
        try:
            # Parse query parameters
            parsed_uri = uri.split("?")
            query_params = {}
            if len(parsed_uri) > 1:
                for param in parsed_uri[1].split("&"):
                    if "=" in param:
                        key, value = param.split("=", 1)
                        query_params[key] = value
            
            project_path_str = query_params.get("project_path", ".")
            analysis_depth = query_params.get("depth", "comprehensive")
            
            # Resolve project path
            project_path = Path(project_path_str)
            if not project_path.is_absolute():
                project_path = resolve_project_path() or Path.cwd()
                project_path = project_path / project_path_str
            
            if not project_path.exists():
                return json.dumps({
                    "error": "Project path does not exist",
                    "path": str(project_path)
                })
            
            # Initialize all discovery systems
            framework_mapper = FrameworkMapper()
            memory_mapper = AtomicMemoryMapper()
            semantic_extractor = SemanticExtractor()
            
            results = {
                "discovery_timestamp": time.time(),
                "project_path": str(project_path),
                "analysis_depth": analysis_depth,
                "unified_analysis": {}
            }
            
            # 1. Framework Discovery
            try:
                framework_map = framework_mapper.map_framework(project_path, MappingStrategy.HYBRID)
                results["unified_analysis"]["framework"] = {
                    "nodes_discovered": len(framework_map.nodes),
                    "edges_discovered": len(framework_map.edges),
                    "entry_points": framework_map.entry_points,
                    "stack_type": framework_map.stack_type.value,
                    "complexity_score": len(framework_map.nodes) + len(framework_map.edges)
                }
            except Exception as e:
                results["unified_analysis"]["framework"] = {"error": str(e)}
            
            # 2. Memory Analysis
            try:
                memory_nodes = memory_mapper.map_memory_operations(project_path)
                memory_patterns = memory_mapper.analyze_cross_language_patterns(memory_nodes)
                total_memory_ops = sum(len(nodes) for nodes in memory_nodes.values())
                
                results["unified_analysis"]["memory"] = {
                    "total_memory_operations": total_memory_ops,
                    "patterns_detected": len(memory_patterns),
                    "languages_analyzed": len(set(n.language for nodes in memory_nodes.values() for n in nodes)),
                    "security_issues": len([p for p in memory_patterns if "security" in str(p.security_implications)])
                }
            except Exception as e:
                results["unified_analysis"]["memory"] = {"error": str(e)}
            
            # 3. Semantic Analysis
            try:
                # Extract semantic terms from project
                semantic_terms = semantic_extractor.extract_project_semantics(project_path)
                results["unified_analysis"]["semantic"] = {
                    "terms_extracted": len(semantic_terms),
                    "domain_vocabulary": len([t for t in semantic_terms if t.confidence > 0.8]),
                    "project_specific_terms": len([t for t in semantic_terms if t.is_project_specific]),
                    "semantic_coverage": len(set(t.term for t in semantic_terms))
                }
            except Exception as e:
                results["unified_analysis"]["semantic"] = {"error": str(e)}
            
            # 4. Cross-System Integration Analysis
            try:
                integration_score = calculate_integration_score(results["unified_analysis"])
                results["unified_analysis"]["integration"] = {
                    "integration_score": integration_score,
                    "system_compatibility": "high" if integration_score > 0.8 else "medium" if integration_score > 0.5 else "low",
                    "recommended_actions": generate_integration_recommendations(results["unified_analysis"])
                }
            except Exception as e:
                results["unified_analysis"]["integration"] = {"error": str(e)}
            
            return json.dumps(results, indent=2)
        
        except Exception as e:
            return json.dumps({
                "error": str(e),
                "uri": uri
            })
    
    async def handle_unified_analysis(uri: str) -> str:
        """Deep cross-system analysis and recommendations."""
        try:
            parsed_uri = uri.split("?")
            query_params = {}
            if len(parsed_uri) > 1:
                for param in parsed_uri[1].split("&"):
                    if "=" in param:
                        key, value = param.split("=", 1)
                        query_params[key] = value
            
            project_path_str = query_params.get("project_path", ".")
            analysis_type = query_params.get("type", "comprehensive")
            
            project_path = Path(project_path_str)
            if not project_path.is_absolute():
                project_path = resolve_project_path() or Path.cwd()
                project_path = project_path / project_path_str
            
            # Initialize all systems
            framework_mapper = FrameworkMapper()
            memory_mapper = AtomicMemoryMapper()
            vector_memory = VectorMemoryStore(project_path)
            task_manager = TaskManager()
            app_registry = AppRegistry()
            snapshot_manager = get_snapshot_manager()
            
            analysis = {
                "analysis_timestamp": time.time(),
                "project_path": str(project_path),
                "analysis_type": analysis_type,
                "cross_system_insights": {}
            }
            
            # Framework-Memory Integration
            try:
                framework_map = framework_mapper.map_framework(project_path, MappingStrategy.HYBRID)
                memory_nodes = memory_mapper.map_memory_operations(project_path)
                
                # Correlate framework nodes with memory patterns
                memory_intensive_nodes = []
                for fw_node in framework_map.nodes:
                    associated_memory = find_associated_memory(fw_node, memory_nodes)
                    if associated_memory:
                        memory_intensive_nodes.append({
                            "framework_node": fw_node.name,
                            "memory_operations": len(associated_memory),
                            "complexity_score": calculate_node_complexity(fw_node, associated_memory)
                        })
                
                analysis["cross_system_insights"]["framework_memory"] = {
                    "memory_intensive_nodes": memory_intensive_nodes[:10],
                    "total_correlations": len(memory_intensive_nodes),
                    "optimization_opportunities": len([n for n in memory_intensive_nodes if n["complexity_score"] > 0.8])
                }
            except Exception as e:
                analysis["cross_system_insights"]["framework_memory"] = {"error": str(e)}
            
            # Vector Memory Enhancement
            try:
                # Index framework nodes in vector memory
                vector_memory.clear_project(project_path)
                
                framework_map = framework_mapper.map_framework(project_path, MappingStrategy.STATIC_ANALYSIS)
                for node in framework_map.nodes[:1000]:  # Limit for performance
                    vector_memory.add_entity(
                        entity_id=node.id,
                        entity_type="framework_node",
                        content=f"{node.name} {node.type} {node.file_path}",
                        metadata={
                            "node_type": node.type,
                            "file_path": node.file_path,
                            "line": node.line_start
                        }
                    )
                
                analysis["cross_system_insights"]["vector_enhancement"] = {
                    "entities_indexed": min(1000, len(framework_map.nodes)),
                    "search_capability": "enabled",
                    "semantic_similarity": "available"
                }
            except Exception as e:
                analysis["cross_system_insights"]["vector_enhancement"] = {"error": str(e)}
            
            # Task Generation for Complex Components
            try:
                complex_components = identify_complex_components(project_path, framework_mapper)
                generated_tasks = []
                
                for component in complex_components[:5]:
                    task_id = task_manager.create_task(
                        task_type="component_analysis",
                        description=f"Analyze complex component: {component['name']}",
                        metadata={
                            "component": component,
                            "project_path": str(project_path)
                        }
                    )
                    generated_tasks.append(task_id)
                
                analysis["cross_system_insights"]["task_generation"] = {
                    "complex_components_identified": len(complex_components),
                    "tasks_generated": len(generated_tasks),
                    "task_ids": generated_tasks
                }
            except Exception as e:
                analysis["cross_system_insights"]["task_generation"] = {"error": str(e)}
            
            # App Recommendations
            try:
                app_recommendations = generate_app_recommendations(project_path, framework_mapper)
                analysis["cross_system_insights"]["app_recommendations"] = {
                    "recommended_apps": app_recommendations,
                    "total_recommendations": len(app_recommendations)
                }
            except Exception as e:
                analysis["cross_system_insights"]["app_recommendations"] = {"error": str(e)}
            
            # Snapshot Strategy
            try:
                snapshot_strategy = generate_snapshot_strategy(project_path, framework_mapper)
                analysis["cross_system_insights"]["snapshot_strategy"] = snapshot_strategy
            except Exception as e:
                analysis["cross_system_insights"]["snapshot_strategy"] = {"error": str(e)}
            
            return json.dumps(analysis, indent=2)
        
        except Exception as e:
            return json.dumps({
                "error": str(e),
                "uri": uri
            })
    
    async def handle_unified_migration(uri: str) -> str:
        """Complete project migration with all systems."""
        try:
            parsed_uri = uri.split("?")
            query_params = {}
            if len(parsed_uri) > 1:
                for param in parsed_uri[1].split("&"):
                    if "=" in param:
                        key, value = param.split("=", 1)
                        query_params[key] = value
            
            project_path_str = query_params.get("project_path", ".")
            migration_target = query_params.get("target", "forge_managed")
            
            project_path = Path(project_path_str)
            if not project_path.is_absolute():
                project_path = resolve_project_path() or Path.cwd()
                project_path = project_path / project_path_str
            
            migration_plan = {
                "migration_timestamp": time.time(),
                "project_path": str(project_path),
                "migration_target": migration_target,
                "migration_steps": []
            }
            
            # Initialize all systems
            framework_mapper = FrameworkMapper()
            memory_mapper = AtomicMemoryMapper()
            semantic_extractor = SemanticExtractor()
            vector_memory = VectorMemoryStore(project_path)
            snapshot_manager = get_snapshot_manager()
            
            # Step 1: Framework Discovery
            try:
                framework_map = framework_mapper.map_framework(project_path, MappingStrategy.HYBRID)
                migration_plan["migration_steps"].append({
                    "step": 1,
                    "name": "Framework Discovery",
                    "status": "completed",
                    "results": {
                        "nodes_discovered": len(framework_map.nodes),
                        "edges_discovered": len(framework_map.edges),
                        "entry_points": framework_map.entry_points
                    }
                })
            except Exception as e:
                migration_plan["migration_steps"].append({
                    "step": 1,
                    "name": "Framework Discovery",
                    "status": "failed",
                    "error": str(e)
                })
            
            # Step 2: Memory Analysis
            try:
                memory_nodes = memory_mapper.map_memory_operations(project_path)
                memory_patterns = memory_mapper.analyze_cross_language_patterns(memory_nodes)
                migration_plan["migration_steps"].append({
                    "step": 2,
                    "name": "Memory Analysis",
                    "status": "completed",
                    "results": {
                        "memory_operations": sum(len(nodes) for nodes in memory_nodes.values()),
                        "patterns_detected": len(memory_patterns),
                        "security_issues": len([p for p in memory_patterns if "security" in str(p.security_implications)])
                    }
                })
            except Exception as e:
                migration_plan["migration_steps"].append({
                    "step": 2,
                    "name": "Memory Analysis",
                    "status": "failed",
                    "error": str(e)
                })
            
            # Step 3: Semantic Extraction
            try:
                semantic_terms = semantic_extractor.extract_project_semantics(project_path)
                migration_plan["migration_steps"].append({
                    "step": 3,
                    "name": "Semantic Extraction",
                    "status": "completed",
                    "results": {
                        "terms_extracted": len(semantic_terms),
                        "domain_vocabulary": len([t for t in semantic_terms if t.confidence > 0.8])
                    }
                })
            except Exception as e:
                migration_plan["migration_steps"].append({
                    "step": 3,
                    "name": "Semantic Extraction",
                    "status": "failed",
                    "error": str(e)
                })
            
            # Step 4: Vector Memory Indexing
            try:
                vector_memory.clear_project(project_path)
                # Index key components
                for node in framework_map.nodes[:500]:
                    vector_memory.add_entity(
                        entity_id=node.id,
                        entity_type="framework_node",
                        content=f"{node.name} {node.type}",
                        metadata={"file": node.file_path}
                    )
                
                migration_plan["migration_steps"].append({
                    "step": 4,
                    "name": "Vector Memory Indexing",
                    "status": "completed",
                    "results": {
                        "entities_indexed": min(500, len(framework_map.nodes))
                    }
                })
            except Exception as e:
                migration_plan["migration_steps"].append({
                    "step": 4,
                    "name": "Vector Memory Indexing",
                    "status": "failed",
                    "error": str(e)
                })
            
            # Step 5: Snapshot Creation
            try:
                snapshot_id = snapshot_manager.create_snapshot(
                    project_path=project_path,
                    snapshot_type="full",
                    description=f"Migration snapshot for {project_path.name}"
                )
                
                migration_plan["migration_steps"].append({
                    "step": 5,
                    "name": "Snapshot Creation",
                    "status": "completed",
                    "results": {
                        "snapshot_id": snapshot_id,
                        "snapshot_type": "full"
                    }
                })
            except Exception as e:
                migration_plan["migration_steps"].append({
                    "step": 5,
                    "name": "Snapshot Creation",
                    "status": "failed",
                    "error": str(e)
                })
            
            # Calculate overall migration success
            completed_steps = len([s for s in migration_plan["migration_steps"] if s["status"] == "completed"])
            total_steps = len(migration_plan["migration_steps"])
            success_rate = completed_steps / total_steps if total_steps > 0 else 0
            
            migration_plan["migration_summary"] = {
                "total_steps": total_steps,
                "completed_steps": completed_steps,
                "success_rate": success_rate,
                "migration_status": "success" if success_rate > 0.8 else "partial" if success_rate > 0.5 else "failed"
            }
            
            return json.dumps(migration_plan, indent=2)
        
        except Exception as e:
            return json.dumps({
                "error": str(e),
                "uri": uri
            })
    
    async def handle_unified_status(uri: str) -> str:
        """Status of all unified systems."""
        try:
            # Initialize all systems
            task_manager = TaskManager()
            app_registry = AppRegistry()
            vector_memory = VectorMemoryStore(project_path)
            snapshot_manager = get_snapshot_manager()
            
            status = {
                "status_timestamp": time.time(),
                "unified_systems": {}
            }
            
            # Task Manager Status
            try:
                active_tasks = task_manager.get_active_tasks()
                status["unified_systems"]["task_manager"] = {
                    "status": "operational",
                    "active_tasks": len(active_tasks),
                    "total_tasks": len(task_manager.list_tasks()),
                    "task_types": list(set(task.task_type for task in task_manager.list_tasks()))
                }
            except Exception as e:
                status["unified_systems"]["task_manager"] = {"status": "error", "error": str(e)}
            
            # App Registry Status
            try:
                apps = app_registry.list_apps()
                status["unified_systems"]["app_registry"] = {
                    "status": "operational",
                    "total_apps": len(apps),
                    "app_types": list(set(app.app_type for app in apps))
                }
            except Exception as e:
                status["unified_systems"]["app_registry"] = {"status": "error", "error": str(e)}
            
            # Vector Memory Status
            try:
                projects = vector_memory.list_projects()
                total_entities = sum(len(vector_memory.search(project, "", limit=1000)) for project in projects)
                status["unified_systems"]["vector_memory"] = {
                    "status": "operational",
                    "indexed_projects": len(projects),
                    "total_entities": total_entities
                }
            except Exception as e:
                status["unified_systems"]["vector_memory"] = {"status": "error", "error": str(e)}
            
            # Snapshot Manager Status
            try:
                snapshots = snapshot_manager.list_snapshots()
                status["unified_systems"]["snapshot_manager"] = {
                    "status": "operational",
                    "total_snapshots": len(snapshots),
                    "snapshot_types": list(set(snap.snapshot_type for snap in snapshots))
                }
            except Exception as e:
                status["unified_systems"]["snapshot_manager"] = {"status": "error", "error": str(e)}
            
            # Overall System Status
            operational_count = len([s for s in status["unified_systems"].values() if s.get("status") == "operational"])
            total_systems = len(status["unified_systems"])
            
            status["overall_status"] = {
                "systems_operational": operational_count,
                "total_systems": total_systems,
                "health_score": operational_count / total_systems if total_systems > 0 else 0,
                "status": "healthy" if operational_count == total_systems else "degraded" if operational_count > 0 else "failed"
            }
            
            return json.dumps(status, indent=2)
        
        except Exception as e:
            return json.dumps({
                "error": str(e),
                "uri": uri
            })


# ==================== HELPER FUNCTIONS ====================

def calculate_integration_score(analysis: Dict[str, Any]) -> float:
    """Calculate cross-system integration score."""
    score = 0.0
    total_weight = 0.0
    
    # Framework analysis weight
    if "framework" in analysis and "nodes_discovered" in analysis["framework"]:
        nodes = analysis["framework"]["nodes_discovered"]
        score += min(nodes / 1000, 1.0) * 0.3
        total_weight += 0.3
    
    # Memory analysis weight
    if "memory" in analysis and "total_memory_operations" in analysis["memory"]:
        ops = analysis["memory"]["total_memory_operations"]
        score += min(ops / 100, 1.0) * 0.2
        total_weight += 0.2
    
    # Semantic analysis weight
    if "semantic" in analysis and "terms_extracted" in analysis["semantic"]:
        terms = analysis["semantic"]["terms_extracted"]
        score += min(terms / 100, 1.0) * 0.2
        total_weight += 0.2
    
    # Security analysis weight
    if "memory" in analysis and "security_issues" in analysis["memory"]:
        issues = analysis["memory"]["security_issues"]
        score += min(issues / 10, 1.0) * 0.3
        total_weight += 0.3
    
    return score / total_weight if total_weight > 0 else 0.0


def generate_integration_recommendations(analysis: Dict[str, Any]) -> List[str]:
    """Generate integration recommendations."""
    recommendations = []
    
    if "framework" in analysis and analysis["framework"].get("nodes_discovered", 0) > 1000:
        recommendations.append("Consider breaking down large framework into modules")
    
    if "memory" in analysis and analysis["memory"].get("security_issues", 0) > 0:
        recommendations.append("Address memory security issues before production")
    
    if "semantic" in analysis and analysis["semantic"].get("domain_vocabulary", 0) < 10:
        recommendations.append("Enhance domain vocabulary for better semantic understanding")
    
    return recommendations


def find_associated_memory(fw_node: Any, memory_nodes: Dict[str, List[Any]]) -> List[Any]:
    """Find memory operations associated with framework node."""
    associated = []
    node_file = Path(fw_node.file_path).name
    
    for file_path, nodes in memory_nodes.items():
        if Path(file_path).name == node_file:
            # Find memory operations near the same line
            for mem_node in nodes:
                if abs(mem_node.line_start - fw_node.line_start) <= 10:
                    associated.append(mem_node)
    
    return associated


def calculate_node_complexity(fw_node: Any, memory_ops: List[Any]) -> float:
    """Calculate complexity score for framework node."""
    complexity = 0.0
    
    # Base complexity from node type
    if fw_node.type == "class":
        complexity += 0.3
    elif fw_node.type == "function":
        complexity += 0.2
    
    # Memory operation complexity
    complexity += len(memory_ops) * 0.1
    
    # Large allocations increase complexity
    large_allocs = len([op for op in memory_ops if op.size_bytes and op.size_bytes > 1000])
    complexity += large_allocs * 0.2
    
    return min(complexity, 1.0)


def identify_complex_components(project_path: Path, framework_mapper: FrameworkMapper) -> List[Dict[str, Any]]:
    """Identify complex components for task generation."""
    framework_map = framework_mapper.map_framework(project_path, MappingStrategy.STATIC_ANALYSIS)
    
    complex_components = []
    
    for node in framework_map.nodes:
        complexity_score = 0.0
        
        # Large classes/functions
        if node.type == "class" and len(node.metadata) > 5:
            complexity_score += 0.5
        elif node.type == "function" and len(node.metadata) > 3:
            complexity_score += 0.3
        
        # Many dependencies
        if len(node.dependencies) > 5:
            complexity_score += 0.4
        
        if complexity_score > 0.5:
            complex_components.append({
                "name": node.name,
                "type": node.type,
                "file_path": node.file_path,
                "complexity_score": complexity_score,
                "dependencies": len(node.dependencies),
                "metadata_size": len(node.metadata)
            })
    
    # Sort by complexity
    complex_components.sort(key=lambda x: x["complexity_score"], reverse=True)
    
    return complex_components


def generate_app_recommendations(project_path: Path, framework_mapper: FrameworkMapper) -> List[str]:
    """Generate app recommendations based on project analysis."""
    framework_map = framework_mapper.map_framework(project_path, MappingStrategy.STATIC_ANALYSIS)
    
    recommendations = []
    
    # Web framework detection
    web_indicators = ["app", "server", "route", "http", "api"]
    web_nodes = [node for node in framework_map.nodes if any(indicator in node.name.lower() for indicator in web_indicators)]
    
    if web_nodes:
        recommendations.append("web_development")
    
    # Data processing detection
    data_indicators = ["process", "analyze", "transform", "compute", "algorithm"]
    data_nodes = [node for node in framework_map.nodes if any(indicator in node.name.lower() for indicator in data_indicators)]
    
    if data_nodes:
        recommendations.append("data_processing")
    
    # Testing detection
    test_indicators = ["test", "spec", "mock", "fixture"]
    test_nodes = [node for node in framework_map.nodes if any(indicator in node.name.lower() for indicator in test_indicators)]
    
    if test_nodes:
        recommendations.append("testing")
    
    return recommendations


def generate_snapshot_strategy(project_path: Path, framework_mapper: FrameworkMapper) -> Dict[str, Any]:
    """Generate snapshot strategy for project."""
    framework_map = framework_mapper.map_framework(project_path, MappingStrategy.STATIC_ANALYSIS)
    
    strategy = {
        "recommended_frequency": "daily",
        "snapshot_types": ["incremental", "full"],
        "retention_policy": "30_days",
        "storage_strategy": "local_plus_remote"
    }
    
    # Large projects need more frequent snapshots
    if len(framework_map.nodes) > 1000:
        strategy["recommended_frequency"] = "hourly"
    
    # Projects with many entry points need full snapshots
    if len(framework_map.entry_points) > 5:
        strategy["snapshot_types"].append("session")
    
    return strategy
    
    # Register all resource handlers with the registry
    registry.register_resource("forge://unified/discover", handle_unified_discover)
    registry.register_resource("forge://unified/analyze", handle_unified_analysis)
    registry.register_resource("forge://unified/migrate", handle_unified_migration)
    registry.register_resource("forge://unified/status", handle_unified_status)
