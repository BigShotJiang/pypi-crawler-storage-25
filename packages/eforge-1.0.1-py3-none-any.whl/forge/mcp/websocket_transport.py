"""WebSocket transport for INTENT-2BCA4AE9 - MCP WebSocket/Streamable HTTP migration.

Provides WebSocket transport layer for Forge MCP server with session isolation
and hot reloading capabilities.
"""

import asyncio
import json
import logging
import time
from contextlib import asynccontextmanager
from typing import Any, Dict, Optional, Set
from uuid import uuid4
from pathlib import Path

import websockets
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse

import mcp.types as types
from mcp.server import Server

from forge.mcp.server import _build_server
from forge.mcp.session_context import SessionContext, set_current_session, get_current_session, register_session, unregister_session

logger = logging.getLogger(__name__)


class WebSocketSession:
    """Represents a WebSocket session with isolated context."""
    
    def __init__(self, session_id: str, websocket: WebSocket, server: Server):
        self.session_id = session_id
        self.websocket = websocket
        self.server = server
        self.project_path: Optional[str] = None
        self.session_roots: list[str] = []
        self.created_at = time.time()
        self.last_activity = time.time()
    
    async def send_message(self, message: dict) -> None:
        """Send a message to the WebSocket client."""
        try:
            await self.websocket.send_text(json.dumps(message))
        except Exception as e:
            logger.error(f"Failed to send message to session {self.session_id}: {e}")
            raise
    
    async def receive_message(self) -> dict:
        """Receive a message from the WebSocket client."""
        try:
            message = await self.websocket.receive_text()
            return json.loads(message)
        except Exception as e:
            logger.error(f"Failed to receive message from session {self.session_id}: {e}")
            raise
    
    def update_activity(self) -> None:
        """Update the last activity timestamp."""
        self.last_activity = time.time()


class WebSocketTransport:
    """WebSocket transport for MCP server with hot reloading."""
    
    def __init__(self, host: str = "localhost", port: int = 7777, enable_hot_reload: bool = True):
        self.host = host
        self.port = port
        self.sessions: Dict[str, WebSocketSession] = {}
        self.enable_hot_reload = enable_hot_reload
        self._watched_files: Set[Path] = set()
        self._file_watcher_task: Optional[asyncio.Task] = None
        self._reload_callbacks: Set[asyncio.Queue] = set()
        self.app = self._create_app()
    
    def _create_app(self) -> FastAPI:
        """Create the FastAPI application with WebSocket endpoint."""
        app = FastAPI(title="Forge MCP WebSocket Server")
        
        @app.get("/")
        async def root():
            """Root endpoint with basic info."""
            return {
                "name": "Forge MCP WebSocket Server",
                "version": "1.0.0",
                "endpoints": {
                    "mcp": "/mcp",
                    "health": "/health"
                }
            }
        
        @app.get("/health")
        async def health():
            """Health check endpoint."""
            return {
                "status": "healthy",
                "sessions": len(self.sessions),
                "uptime": time.time() - getattr(self, 'start_time', time.time())
            }
        
        @app.websocket("/mcp")
        async def websocket_endpoint(websocket: WebSocket):
            """Main MCP WebSocket endpoint."""
            await websocket.accept()
            
            session_id = str(uuid4())
            server = _build_server()
            session = WebSocketSession(session_id, websocket, server)
            self.sessions[session_id] = session
            
            logger.info(f"WebSocket session connected: {session_id}")
            
            try:
                await self._handle_session(session)
            except WebSocketDisconnect:
                logger.info(f"WebSocket session disconnected: {session_id}")
            except Exception as e:
                logger.error(f"Error in WebSocket session {session_id}: {e}")
            finally:
                if session_id in self.sessions:
                    del self.sessions[session_id]
        
        return app
    
    async def _handle_session(self, session: WebSocketSession) -> None:
        """Handle a WebSocket session."""
        # Create session context for this connection
        session_ctx = SessionContext(session.session_id)
        register_session(session.session_id, session_ctx)
        
        try:
            # Send initialization
            init_options = session.server.create_initialization_options()
            await session.send_message({
                "jsonrpc": "2.0",
                "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": init_options,
                    "clientInfo": {
                        "name": "forge-websocket-client",
                        "version": "1.0.0"
                    }
                }
            })
            
            # Handle messages
            while True:
                try:
                    message = await session.receive_message()
                    session.update_activity()
                    
                    # Set session context for message processing
                    set_current_session(session_ctx)
                    
                    # Process MCP message
                    response = await self._process_mcp_message(session, message)
                    if response:
                        await session.send_message(response)
                        
                except WebSocketDisconnect:
                    break
                except Exception as e:
                    logger.error(f"Error processing message in session {session.session_id}: {e}")
                    await session.send_message({
                        "jsonrpc": "2.0",
                        "error": {
                            "code": -32603,
                            "message": "Internal error",
                            "data": str(e)
                        }
                    })
                    break
        finally:
            # Clean up session context
            unregister_session(session.session_id)
    
    async def _process_mcp_message(self, session: WebSocketSession, message: dict) -> Optional[dict]:
        """Process an MCP message."""
        method = message.get("method")
        params = message.get("params", {})
        message_id = message.get("id")
        
        if method == "initialize":
            # Handle initialization
            session.project_path = params.get("projectPath", ".")
            session.session_roots = params.get("roots", [])
            
            # Store in session context for INTENT-332931D8
            current_session = get_current_session()
            if current_session:
                current_session.set_roots(session.session_roots)
                current_session.set_project_path(session.project_path)
                current_session.set_client_info(params.get("clientInfo", {}))
            
            return {
                "jsonrpc": "2.0",
                "id": message_id,
                "result": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {
                        "tools": {},
                        "resources": {},
                        "prompts": {}
                    },
                    "serverInfo": {
                        "name": "forge",
                        "version": "1.0.0"
                    }
                }
            }
        
        elif method == "tools/list":
            # List available tools
            tools = session.server.list_tools()
            return {
                "jsonrpc": "2.0",
                "id": message_id,
                "result": {"tools": tools}
            }
        
        elif method == "tools/call":
            # Call a tool
            tool_name = params.get("name")
            arguments = params.get("arguments", {})
            
            try:
                result = await session.server.call_tool(tool_name, arguments)
                return {
                    "jsonrpc": "2.0",
                    "id": message_id,
                    "result": result
                }
            except Exception as e:
                return {
                    "jsonrpc": "2.0",
                    "id": message_id,
                    "error": {
                        "code": -32603,
                        "message": "Tool call failed",
                        "data": str(e)
                    }
                }
        
        elif method == "resources/list":
            # List resources
            resources = session.server.list_resources()
            return {
                "jsonrpc": "2.0",
                "id": message_id,
                "result": {"resources": resources}
            }
        
        elif method == "resources/read":
            # Read a resource
            uri = params.get("uri")
            try:
                result = await session.server.read_resource(uri)
                return {
                    "jsonrpc": "2.0",
                    "id": message_id,
                    "result": result
                }
            except Exception as e:
                return {
                    "jsonrpc": "2.0",
                    "id": message_id,
                    "error": {
                        "code": -32603,
                        "message": "Resource read failed",
                        "data": str(e)
                    }
                }
        
        elif method == "prompts/list":
            # List prompts
            prompts = session.server.list_prompts()
            return {
                "jsonrpc": "2.0",
                "id": message_id,
                "result": {"prompts": prompts}
            }
        
        elif method == "prompts/get":
            # Get a prompt
            name = params.get("name")
            arguments = params.get("arguments", {})
            try:
                result = await session.server.get_prompt(name, arguments)
                return {
                    "jsonrpc": "2.0",
                    "id": message_id,
                    "result": result
                }
            except Exception as e:
                return {
                    "jsonrpc": "2.0",
                    "id": message_id,
                    "error": {
                        "code": -32603,
                        "message": "Prompt get failed",
                        "data": str(e)
                    }
                }
        
        else:
            # Unknown method
            return {
                "jsonrpc": "2.0",
                "id": message_id,
                "error": {
                    "code": -32601,
                    "message": f"Method not found: {method}"
                }
            }

        logger.info(f"Starting WebSocket MCP server on {self.host}:{self.port}")
        await server.serve()
    
    def add_watch_file(self, file_path: Path) -> None:
        """Add a file to watch for hot reloading."""
        if self.enable_hot_reload:
            self._watched_files.add(file_path.resolve())
            logger.info(f"Added file to hot reload watch list: {file_path}")
    
    def remove_watch_file(self, file_path: Path) -> None:
        """Remove a file from hot reload watch list."""
        self._watched_files.discard(file_path.resolve())
        logger.info(f"Removed file from hot reload watch list: {file_path}")
    
    async def _watch_files(self) -> None:
        """Watch files for changes and trigger reloads."""
        if not self.enable_hot_reload or not self._watched_files:
            return
        
        logger.info(f"Starting file watcher for {len(self._watched_files)} files")
        
        last_mod_times = {f: f.stat().st_mtime for f in self._watched_files}
        
        while True:
            try:
                await asyncio.sleep(1)  # Check every second
                
                for file_path in list(self._watched_files):
                    if not file_path.exists():
                        continue
                    
                    current_mtime = file_path.stat().st_mtime
                    if current_mtime > last_mod_times[file_path]:
                        logger.info(f"File changed: {file_path}")
                        last_mod_times[file_path] = current_mtime
                        
                        # Notify all connected sessions about the reload
                        await self._notify_reload({
                            "type": "file_changed",
                            "file": str(file_path),
                            "timestamp": time.time()
                        })
                        
            except Exception as e:
                logger.error(f"Error in file watcher: {e}")
                await asyncio.sleep(5)  # Wait before retrying
    
    async def _notify_reload(self, reload_data: dict) -> None:
        """Notify all connected sessions about a reload event."""
        message = {
            "jsonrpc": "2.0",
            "method": "reload",
            "params": reload_data
        }
        
        for session_id, session in list(self.sessions.items()):
            try:
                await session.send_message(message)
                logger.debug(f"Notified session {session_id} about reload")
            except Exception as e:
                logger.warning(f"Failed to notify session {session_id} about reload: {e}")
    
    async def start_server(self) -> None:
        """Start the WebSocket server with hot reloading."""
        import uvicorn
        
        # Start file watcher if enabled
        if self.enable_hot_reload and self._watched_files:
            self._file_watcher_task = asyncio.create_task(self._watch_files())
            logger.info("Hot reloading enabled")
        
        try:
            config = uvicorn.Config(self.app, host=self.host, port=self.port, log_level="info")
            server = uvicorn.Server(config)
            await server.serve()
        finally:
            # Clean up file watcher
            if self._file_watcher_task:
                self._file_watcher_task.cancel()
                try:
                    await self._file_watcher_task
                except asyncio.CancelledError:
                    pass
    
    def get_session_info(self) -> Dict[str, Any]:
        """Get information about active sessions."""
        return {
            "total_sessions": len(self.sessions),
            "sessions": [
                {
                    "session_id": session.session_id,
                    "created_at": session.created_at,
                    "last_activity": session.last_activity,
                    "project_path": session.project_path,
                    "roots_count": len(session.session_roots)
                }
                for session in self.sessions.values()
            ]
        }


async def run_mcp_websocket(host: str = "localhost", port: int = 7777) -> None:
    """Run the MCP server over WebSocket transport."""
    transport = WebSocketTransport(host, port)
    await transport.start_server()


def run_mcp_websocket_sync(host: str = "localhost", port: int = 7777) -> None:
    """Run the MCP WebSocket server (synchronous entry point)."""
    asyncio.run(run_mcp_websocket(host, port))


__all__ = ["WebSocketTransport", "run_mcp_websocket", "run_mcp_websocket_sync"]
