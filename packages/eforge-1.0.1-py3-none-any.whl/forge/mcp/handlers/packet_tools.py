"""Packet tools for Forge MCP handlers."""

from __future__ import annotations

import asyncio
import json
from typing import Any

import mcp.types as types

from forge.commands.packet_cmd import run_packet_assemble
from forge.mcp.handlers.error_handlers import handle_unhandled_exception, make_tool_result
from forge.mcp.handlers.schemas import PacketAssembleOutput
from forge.mcp.project_resolution import resolve_validated_project_path_result


async def handle_forge_packet_assemble(arguments: dict[str, Any]) -> types.CallToolResult:
    """Assemble a context packet (Cowork-style) from manifest + glove contracts."""
    try:
        path, gate = resolve_validated_project_path_result(arguments)
        if gate is not None:
            return gate

        try:
            payload = await asyncio.to_thread(
                run_packet_assemble,
                node=str(arguments.get("node") or ""),
                node_type=str(arguments.get("type") or ""),
                domain=str(arguments.get("domain") or ""),
                task=str(arguments.get("task") or "generate"),
                deps=[str(x) for x in (arguments.get("deps") or [])],
                methods=[str(x) for x in (arguments.get("methods") or [])],
                project_path=str(path),
            )
        except Exception as exc:
            return types.CallToolResult(
                content=[types.TextContent(type="text", text=str(exc))],
                isError=True,
            )

        glove_domain = str(payload.get("domain") or "").strip().lower()
        nt = str(payload.get("type") or "").strip()
        glove_link = f"forge://glove/{nt}/{glove_domain}" if nt and glove_domain else None

        envelope: dict[str, Any] = {
            "ok": True,
            "packet_path": str(payload["packet_path"]),
            "node": str(payload["node"]),
            "node_id": str(payload["node"]),
            "type": payload["type"],
            "domain": payload["domain"],
            "contracts": payload["contracts"],
            "glove_link": glove_link,
            "deps_resolved": payload["deps_resolved"],
            "deps_planned": payload["deps_planned"],
            "files_to_generate": payload["files_to_generate"],
            "expires_at": payload["expires_at"],
            "slot_order": payload.get("slot_order") or [],
            "graph_hash": payload.get("graph_hash"),
        }

        return make_tool_result(
            json.dumps(envelope, indent=2),
            PacketAssembleOutput,
            structured_data=envelope,
        )
    except Exception as e:
        return handle_unhandled_exception(
            "forge_packet_assemble",
            e,
            {
                "project_path": arguments.get("project_path", ""),
                "operation": "packet_assemble_execution",
            },
        )


__all__ = ["handle_forge_packet_assemble"]
