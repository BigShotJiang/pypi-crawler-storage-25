"""Impact tools for Forge MCP handlers."""

from __future__ import annotations

import asyncio
import json
from typing import Any

import mcp.types as types
from forge.mcp.handlers.error_handlers import (
    forge_error_result,
    handle_unhandled_exception,
    handle_validation_error,
    make_tool_result,
)
from forge.mcp.handlers.schemas import ImpactCheckOutput
from forge.mcp.project_resolution import resolve_validated_project_path_result


async def handle_forge_impact_check(arguments: dict[str, Any]) -> types.CallToolResult:
    # Removed from tool surface 2026-05-17. Handler preserved for reference.
    # Use forge_impact_radius(slice='docs') instead.
    """Deprecated: use forge_impact_radius with slice='docs'. Preserved for compatibility.

    Doc-update + contract-violation slice of unified impact_radius.

    Thin wrapper: delegates to ``execute_impact_radius`` in thin_core and slices
    the doc_updates_required and contract_violations fields into the
    ``ImpactCheckOutput`` summary envelope.

    Accepts either a ``node`` / ``node_id`` argument or ``changed_files`` (list of
    repo-relative paths). At least one of these must resolve to a manifest node.
    ``project_path`` is optional; resolved by ``resolve_thin_project_root``.
    """
    try:
        node_ref = str(
            arguments.get("node") or arguments.get("node_id") or ""
        ).strip()
        changed_files = [
            str(f).strip()
            for f in (arguments.get("changed_files") or [])
            if str(f).strip()
        ]

        if not node_ref and not changed_files:
            return handle_validation_error(
                "node",
                "node, node_id, or changed_files with a mappable path is required",
                {"available_arguments": ["node", "node_id", "changed_files"]},
            )

        try:
            from forge.mcp.thin_core import execute_impact_radius
        except ImportError as e:
            from forge.core.errors import get_error
            error = get_error("dependency_unavailable")
            error.context.update({
                "missing_dependency": "forge.mcp.thin_core",
                "import_error": str(e),
            })
            return forge_error_result(error)

        path_res, gate = resolve_validated_project_path_result(dict(arguments))
        if gate is not None:
            return gate
        routed = {**dict(arguments), "project_path": str(path_res)}

        try:
            raw = await asyncio.to_thread(lambda: execute_impact_radius(routed))
        except ValueError as e:
            return handle_validation_error(
                "node",
                str(e),
                {"node": node_ref, "changed_files": changed_files},
            )

        result = {
            "ok": True,
            "project": raw.get("project_name", ""),
            "project_path": raw.get("project_path", str(arguments.get("project_path") or "")),
            "summary": {
                "node_id": raw.get("node_id", ""),
                "doc_updates_required": raw.get("doc_updates_required", []),
                "contract_violations": raw.get("contract_violations", []),
                "ring": raw.get("ring", 1),
                "affected_node_count": len(raw.get("affected_nodes", [])),
            },
        }

        return make_tool_result(
            json.dumps(result, indent=2),
            ImpactCheckOutput,
            structured_data=result,
        )

    except Exception as e:
        return handle_unhandled_exception(
            "forge_impact_check",
            e,
            {
                "project_path": arguments.get("project_path", ""),
                "operation": "impact_check_execution",
            },
        )


async def handle_forge_impact_radius(
    arguments: dict[str, Any],
) -> types.CallToolResult:
    """Unified impact analysis — blast radius, doc propagation, and contract violations.

    Supersedes forge_blast_radius and forge_impact_check.

    Use slice parameter to filter output:
      full (default) — everything
      blast — affected nodes + ring only
      docs — doc_updates_required only
      contracts — contract_violations only
    """
    try:
        path, gate = resolve_validated_project_path_result(arguments)
        if gate is not None:
            return gate

        node_id = arguments.get("node_id", "")
        if not node_id:
            return handle_validation_error(
                "node_id",
                "node_id is required",
                {"available_arguments": ["node_id", "project_path", "slice"]},
            )

        exec_args = dict(arguments)
        exec_args["project_path"] = str(path)

        from forge.mcp.thin_core import execute_impact_radius_unified

        raw = await asyncio.to_thread(
            lambda: execute_impact_radius_unified(exec_args)
        )

        from forge.core.schemas import ForgeImpactRadiusOutput

        return make_tool_result(
            json.dumps(raw, indent=2),
            ForgeImpactRadiusOutput,
            structured_data=raw,
        )

    except ValueError as e:
        msg = str(e)
        nid = str(arguments.get("node_id") or "").strip()
        if nid and ("not found" in msg.lower() or "unknown" in msg.lower()):
            from forge.mcp.handlers.error_handlers import graph_node_not_found_result

            return graph_node_not_found_result(
                nid,
                source_tool="forge_impact_radius",
                message=msg,
            )
        return handle_validation_error("node_id", msg, {"node_id": nid})
    except Exception as e:
        return handle_unhandled_exception(
            "forge_impact_radius",
            e,
            {
                "project_path": arguments.get("project_path", ""),
                "node_id": arguments.get("node_id", ""),
                "operation": "impact_radius_execution",
            },
        )
