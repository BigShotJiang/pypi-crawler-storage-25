"""Audit-related tool handlers for Forge MCP.

Includes annotation operations, audit scanning, and related functionality.
"""

from __future__ import annotations

import asyncio
import json
from typing import Any

import mcp.types as types
from forge.mcp.handlers.error_handlers import (
    make_tool_result,
    forge_error_result,
    handle_unhandled_exception,
    handle_validation_error,
)
from forge.mcp.handlers.validation import (
    validate_project_path,
    validate_annotation_id,
    validate_session_id,
)
from forge.mcp.project_resolution import resolve_validated_project_path_result
from forge.core.schemas import AnnotateResult


async def handle_forge_audit_scan(arguments: dict[str, Any]) -> types.CallToolResult:
    """
    Audit scan for a project.
    
    Priority: P4 - Audit functionality
    """
    try:
        path, gate = resolve_validated_project_path_result(arguments)
        if gate is not None:
            return gate

        # Import audit functionality with proper error handling
        try:
            from forge.mcp.thin_core import execute_audit_scan
        except ImportError as e:
            from forge.core.errors import ERRORS
            from forge.mcp.handlers.error_handlers import copy_forge_error
            error = copy_forge_error(
                ERRORS["dependency_unavailable"],
                context={
                    "missing_dependency": "forge.mcp.thin_core",
                    "import_error": str(e),
                }
            )
            return forge_error_result(error)
        
        # Execute audit scan off the event loop (can run git + graph work for seconds)
        try:
            result = await asyncio.to_thread(
                execute_audit_scan,
                {**arguments, "project_path": str(path)},
            )
        except Exception as e:
            return handle_unhandled_exception(
                "forge_audit_scan",
                e,
                {
                    "project_path": str(path),
                    "operation": "audit_scan_execution",
                }
            )
        
        from .schemas import AuditScanOutput
        envelope = {
            "ok": True,
            "project": path.name,
            "project_path": str(path),
            "scan_result": result if isinstance(result, dict) else {"result": result},
            "metadata": {
                "mode": arguments.get("mode"),
                "strict": arguments.get("strict"),
                "engine_based": True,
            },
        }
        return make_tool_result(
            json.dumps(envelope, indent=2),
            AuditScanOutput,
            structured_data=envelope,
        )
        
    except ValueError as e:
        return handle_validation_error(
            "project_path",
            str(e),
            {"project_path": arguments.get("project_path", "")}
        )
    except Exception as e:
        return handle_unhandled_exception(
            "forge_audit_scan",
            e,
            {
                "project_path": arguments.get("project_path", ""),
                "operation": "audit_scan_execution",
                "mode": arguments.get("mode"),
                "scope": arguments.get("scope"),
                "focus": arguments.get("focus"),
                "strict": arguments.get("strict"),
                "response_tier": arguments.get("response_tier"),
            }
        )


async def handle_forge_annotate(arguments: dict[str, Any]) -> types.CallToolResult:
    """
    Annotation operations for Forge projects.
    
    Priority: P4 - Audit functionality
    """
    try:
        # Validate input using typed model
        from .schemas import ForgeAnnotateInput, AnnotationResult
        try:
            path, gate = resolve_validated_project_path_result(arguments)
            if gate is not None:
                return gate
            merged = {**arguments, "project_path": str(path)}
            validated_input = ForgeAnnotateInput.model_validate(merged)
        except Exception as e:
            return handle_validation_error(
                "input_validation",
                f"Invalid input: {str(e)}",
                {"provided_arguments": arguments}
            )

        path = validate_project_path(str(validated_input.project_path))
        
        # Validate action parameter
        action = validated_input.action
        if not action:
            return handle_validation_error(
                "action",
                "action is required",
                {
                    "available_actions": [
                        "create",
                        "list",
                        "show",
                        "update",
                        "resolve",
                        "dismiss",
                        "query_by_node",
                    ]
                },
            )
        
        # Route to specific annotation operations
        if action == "create":
            return _handle_annotation_create(validated_input, path)
        elif action == "list":
            return await _handle_annotation_list(arguments, path)
        elif action == "show":
            return await _handle_annotation_show(arguments, path)
        elif action == "update":
            return await _handle_annotation_update(arguments, path)
        elif action == "resolve":
            return await _handle_annotation_resolve(arguments, path)
        elif action == "dismiss":
            return await _handle_annotation_dismiss(arguments, path)
        elif action == "query_by_node":
            from forge.mcp.thin_core import execute_annotation_query_by_node

            result = await asyncio.to_thread(
                lambda: execute_annotation_query_by_node(
                    {**arguments, "project_path": str(path)}
                )
            )
            return make_tool_result(
                json.dumps(result, indent=2),
                None,
                structured_data=result,
            )
        else:
            return handle_validation_error(
                "action",
                f"Invalid action: {action}",
                {
                    "available_actions": [
                        "create",
                        "list",
                        "show",
                        "update",
                        "resolve",
                        "dismiss",
                        "query_by_node",
                    ]
                },
            )
        
    except ValueError as e:
        return handle_validation_error(
            "action" if "action" in str(e) else "project_path",
            str(e),
            {
                "project_path": arguments.get("project_path", ""),
                "action": arguments.get("action"),
            }
        )
    except Exception as e:
        return handle_unhandled_exception(
            "forge_annotate",
            e,
            {
                "project_path": arguments.get("project_path", ""),
                "action": arguments.get("action"),
            }
        )


def _handle_annotation_create(arguments: dict[str, Any], project_path) -> types.CallToolResult:
    """Handle annotation creation."""
    try:
        # Import annotation functionality
        try:
            from forge.mcp.thin_core import execute_annotation_create
        except ImportError as e:
            from forge.core.errors import ERRORS
            from forge.mcp.handlers.error_handlers import copy_forge_error
            error = copy_forge_error(
                ERRORS["dependency_unavailable"],
                context={
                    "missing_dependency": "forge.mcp.thin_core",
                    "import_error": str(e),
                }
            )
            return forge_error_result(error)
        
        result = execute_annotation_create(arguments)
        return make_tool_result(
            json.dumps(result.model_dump(), indent=2),
            AnnotateResult,
            structured_data=result.model_dump()
        )
    except Exception as e:
        return handle_unhandled_exception(
            "annotation_create",
            e,
            {"project_path": str(project_path)}
        )


async def _handle_annotation_list(arguments: dict[str, Any], project_path) -> types.CallToolResult:
    """Handle annotation listing."""
    try:
        # Import annotation functionality for reading annotations
        try:
            from forge.tools.audit.annotations import query_annotations
            from .schemas import AnnotationResult
        except ImportError as e:
            from forge.core.errors import ERRORS
            from forge.mcp.handlers.error_handlers import copy_forge_error
            error = copy_forge_error(
                ERRORS["dependency_unavailable"],
                context={
                    "missing_dependency": "forge.tools.audit.annotations",
                    "import_error": str(e),
                }
            )
            return forge_error_result(error)
        
        result = query_annotations(
            project_path,
            kind=arguments.get("kind"),
            status=arguments.get("status"),
            origin=arguments.get("origin"),
            severity=arguments.get("severity"),
            assigned=arguments.get("assigned"),
            finding=arguments.get("finding"),
            file=arguments.get("file"),
        )
        return make_tool_result(
            json.dumps(result, indent=2),
            None,
            structured_data=result,
        )
    except Exception as e:
        return handle_unhandled_exception(
            "annotation_list",
            e,
            {"project_path": str(project_path)}
        )


async def _handle_annotation_show(arguments: dict[str, Any], project_path) -> types.CallToolResult:
    """Handle annotation show operation."""
    try:
        annotation_id = validate_annotation_id(arguments.get("annotation_id"))
        
        # Import annotation functionality
        try:
            from forge.mcp.thin_core import execute_annotation_show
        except ImportError as e:
            from forge.core.errors import ERRORS
            from forge.mcp.handlers.error_handlers import copy_forge_error
            error = copy_forge_error(
                ERRORS["dependency_unavailable"],
                context={
                    "missing_dependency": "forge.mcp.thin_core",
                    "import_error": str(e),
                }
            )
            return forge_error_result(error)
        
        result = execute_annotation_show({
            **arguments,
            "annotation_id": annotation_id,
        })
        return make_tool_result(
            json.dumps(result, indent=2),
            AnnotateResult,
            structured_data=result
        )
    except ValueError as e:
        return handle_validation_error(
            "annotation_id",
            str(e),
            {
                "project_path": str(project_path),
                "annotation_id": arguments.get("annotation_id"),
            }
        )
    except Exception as e:
        return handle_unhandled_exception(
            "annotation_show",
            e,
            {
                "project_path": str(project_path),
                "annotation_id": arguments.get("annotation_id"),
            }
        )


async def _handle_annotation_update(arguments: dict[str, Any], project_path) -> types.CallToolResult:
    """Handle annotation update operation."""
    try:
        annotation_id = validate_annotation_id(arguments.get("annotation_id"))
        
        # Import annotation functionality
        try:
            from forge.mcp.thin_core import execute_annotation_update
        except ImportError as e:
            from forge.core.errors import ERRORS
            from forge.mcp.handlers.error_handlers import copy_forge_error
            error = copy_forge_error(
                ERRORS["dependency_unavailable"],
                context={
                    "missing_dependency": "forge.mcp.thin_core",
                    "import_error": str(e),
                }
            )
            return forge_error_result(error)
        
        result = execute_annotation_update({
            **arguments,
            "annotation_id": annotation_id,
        })
        return make_tool_result(
            json.dumps(result, indent=2),
            AnnotateResult,
            structured_data=result
        )
    except ValueError as e:
        return handle_validation_error(
            "annotation_id",
            str(e),
            {
                "project_path": str(project_path),
                "annotation_id": arguments.get("annotation_id"),
            }
        )
    except Exception as e:
        return handle_unhandled_exception(
            "annotation_update",
            e,
            {
                "project_path": str(project_path),
                "annotation_id": arguments.get("annotation_id"),
            }
        )


async def _handle_annotation_resolve(arguments: dict[str, Any], project_path) -> types.CallToolResult:
    """Handle annotation resolve operation."""
    try:
        annotation_id = validate_annotation_id(arguments.get("annotation_id"))
        
        # Import annotation functionality
        try:
            from forge.mcp.thin_core import execute_annotation_resolve
        except ImportError as e:
            from forge.core.errors import ERRORS
            from forge.mcp.handlers.error_handlers import copy_forge_error
            error = copy_forge_error(
                ERRORS["dependency_unavailable"],
                context={
                    "missing_dependency": "forge.mcp.thin_core",
                    "import_error": str(e),
                }
            )
            return forge_error_result(error)
        
        result = execute_annotation_resolve({
            **arguments,
            "annotation_id": annotation_id,
        })
        return make_tool_result(
            json.dumps(result, indent=2),
            AnnotateResult,
            structured_data=result
        )
    except ValueError as e:
        return handle_validation_error(
            "annotation_id",
            str(e),
            {
                "project_path": str(project_path),
                "annotation_id": arguments.get("annotation_id"),
            }
        )
    except Exception as e:
        return handle_unhandled_exception(
            "annotation_resolve",
            e,
            {
                "project_path": str(project_path),
                "annotation_id": arguments.get("annotation_id"),
            }
        )


async def _handle_annotation_dismiss(arguments: dict[str, Any], project_path) -> types.CallToolResult:
    """Handle annotation dismiss operation."""
    try:
        annotation_id = validate_annotation_id(arguments.get("annotation_id"))
        
        # Import annotation functionality
        try:
            from forge.mcp.thin_core import execute_annotation_dismiss
        except ImportError as e:
            from forge.core.errors import ERRORS
            from forge.mcp.handlers.error_handlers import copy_forge_error
            error = copy_forge_error(
                ERRORS["dependency_unavailable"],
                context={
                    "missing_dependency": "forge.mcp.thin_core",
                    "import_error": str(e),
                }
            )
            return forge_error_result(error)
        
        result = execute_annotation_dismiss({
            **arguments,
            "annotation_id": annotation_id,
        })
        return make_tool_result(
            json.dumps(result, indent=2),
            AnnotateResult,
            structured_data=result
        )
    except ValueError as e:
        return handle_validation_error(
            "annotation_id",
            str(e),
            {
                "project_path": str(project_path),
                "annotation_id": arguments.get("annotation_id"),
            }
        )
    except Exception as e:
        return handle_unhandled_exception(
            "annotation_dismiss",
            e,
            {
                "project_path": str(project_path),
                "annotation_id": arguments.get("annotation_id"),
            }
        )
