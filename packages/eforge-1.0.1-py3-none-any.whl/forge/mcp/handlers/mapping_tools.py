"""Mapping tools for Forge MCP handlers."""

from __future__ import annotations

import asyncio
import json
from typing import TYPE_CHECKING, Any, Optional

import mcp.types as types
from forge.mcp.handlers.error_handlers import (
    make_tool_result,
    forge_error_result,
    handle_unhandled_exception,
    handle_validation_error,
)
from forge.mcp.handlers.schemas import MapOutput, BlastRadiusOutput, TraceOutput, ReportOutput
from forge.mcp.project_resolution import resolve_validated_project_path_result

if TYPE_CHECKING:
    from forge.engine.session import ForgeSession


def _to_forge_node_output(node: Any) -> dict[str, Any]:
    """Serialize any node representation to ForgeNodeOutput-compatible dict.

    Accepts: ManifestNode dataclass, NodeModel, or dict. Always produces ForgeNodeOutput shape:
    id, kind, tier, domain, status, name, properties.
    """
    if isinstance(node, dict):
        skip = frozenset({
            "id", "kind", "tier", "domain",
            "status", "name", "hop", "path",
        })
        return {
            "id": str(node.get("id") or ""),
            "kind": str(node.get("kind") or ""),
            "tier": node.get("tier"),
            "domain": str(node.get("domain") or ""),
            "status": node.get("status"),
            "name": (node.get("name") or node.get("id") or ""),
            "properties": {
                k: v for k, v in node.items()
                if k not in skip
            },
        }

    return {
        "id": getattr(node, "id", "") or "",
        "kind": getattr(node, "kind", "") or "",
        "tier": getattr(node, "tier", None),
        "domain": getattr(node, "domain", "") or "",
        "status": getattr(node, "status", None),
        "name": (getattr(node, "name", None) or getattr(node, "id", "") or ""),
        "properties": dict(getattr(node, "meta", {}) or {}),
    }


def _node_to_forge_output(
    node: Any,
    session: Optional["ForgeSession"] = None,
) -> dict[str, Any]:
    """Serialize node to ForgeNodeOutput dict.

    When session is provided, attempts entity hydration via EntityRegistry for richer output.
    Falls back to _to_forge_node_output() if entity not found or session unavailable.
    """
    if session is not None:
        node_id = (
            node.get("id")
            if isinstance(node, dict)
            else getattr(node, "id", None)
        )
        if node_id:
            entity = session.registry.get_entity(node_id)
            if entity is not None:
                return entity.to_dict()

    return _to_forge_node_output(node)


async def handle_forge_map(arguments: dict[str, Any]) -> types.CallToolResult:
    """Declaration graph topology — delegates to ``execute_map`` in thin_core (CLI parity)."""
    try:
        try:
            from forge.mcp.thin_core import _session, execute_map
        except ImportError as e:
            from forge.core.errors import get_error
            error = get_error("dependency_unavailable")
            error.context.update({
                "missing_dependency": "forge.mcp.thin_core",
                "detail": str(e),
            })
            return forge_error_result(error)

        path_res, gate = resolve_validated_project_path_result(dict(arguments))
        if gate is not None:
            return gate
        exec_args = {**dict(arguments), "project_path": str(path_res)}

        raw = await asyncio.to_thread(lambda: execute_map(exec_args))
        session = _session(exec_args)
        result_nodes = list(raw.get("nodes") or [])
        serialized_nodes = [
            _node_to_forge_output(n, session) for n in result_nodes
        ]
        text_payload = dict(raw)
        text_payload["nodes"] = serialized_nodes
        # Structured MapOutput must omit extension fields (e.g. sub_local_markdown).
        structured = {
            "ok": bool(raw.get("ok", True)),
            "project": str(raw.get("project", "")),
            "nodes": serialized_nodes,
            "edges": raw.get("edges") or [],
        }
        return make_tool_result(
            json.dumps(text_payload, indent=2),
            MapOutput,
            structured_data=structured,
        )

    except ValueError as e:
        return handle_validation_error(
            "arguments",
            str(e),
            {"available_arguments": [
                "project_path", "map_scope", "domain", "file",
            ]},
        )
    except Exception as e:
        return handle_unhandled_exception(
            "forge_map",
            e,
            {
                "project_path": arguments.get("project_path", ""),
                "operation": "map_execution",
            },
        )


async def handle_forge_blast_radius(arguments: dict[str, Any]) -> types.CallToolResult:
    # Removed from tool surface 2026-05-17. Handler preserved for reference.
    # Use forge_impact_radius(slice='blast') instead.
    """Deprecated: use forge_impact_radius with slice='blast'. Preserved for compatibility.

    Blast radius slice of unified impact_radius — affected nodes and graph rings.

    Thin wrapper: delegates to ``execute_impact_radius`` in thin_core and slices
    the blast_raw section to reconstruct the backward-compat response shape
    (watchers / dependents / siblings / domain_members / parity_reachable / reason).
    project_path is optional; resolved by resolve_thin_project_root.
    """
    try:
        node_ref = str(
            (arguments.get("node") or arguments.get("node_id") or arguments.get("node_name") or "")
            if isinstance(arguments, dict) else ""
        ).strip()
        if not node_ref:
            return handle_validation_error(
                "node",
                "node (or node_id / node_name) is required",
                {"available_arguments": ["node", "node_id", "node_name"]},
            )

        try:
            from forge.mcp.thin_core import _session, execute_impact_radius
        except ImportError as e:
            from forge.core.errors import get_error
            error = get_error("dependency_unavailable")
            error.context.update({
                "missing_dependency": "forge.mcp.thin_core",
                "import_error": str(e),
            })
            return forge_error_result(error)

        try:
            path_res, gate = resolve_validated_project_path_result(dict(arguments))
            if gate is not None:
                return gate
            exec_args = {**dict(arguments), "project_path": str(path_res)}
            raw = await asyncio.to_thread(lambda: execute_impact_radius(exec_args))
        except ValueError as e:
            msg = str(e)
            if "not found" in msg.lower() or "unknown node" in msg.lower():
                from forge.mcp.handlers.error_handlers import graph_node_not_found_result

                return graph_node_not_found_result(
                    node_ref,
                    source_tool="forge_blast_radius",
                    message=msg,
                )
            return handle_validation_error("node", msg, {"node": node_ref})

        blast = raw.get("_blast_raw") or {}
        resolved_node = raw.get("node_id", node_ref)
        project_name = raw.get("project_name", "")
        project_path_s = raw.get("project_path", str(arguments.get("project_path") or ""))
        session = _session(exec_args)

        structured_result = {
            "ok": True,
            "project": project_name,
            "node": resolved_node,
            "watchers": [
                _node_to_forge_output(n, session) for n in blast.get("watchers", [])
            ],
            "dependents": [
                _node_to_forge_output(n, session) for n in blast.get("dependents", [])
            ],
            "depth": 2,
        }

        full_output = {
            **structured_result,
            "project_path": project_path_s,
            "siblings": [
                _node_to_forge_output(n, session) for n in blast.get("siblings", [])
            ],
            "domain_members": [
                _node_to_forge_output(n, session)
                for n in blast.get("domain_members", [])
            ],
            "parity_reachable": blast.get("parity_reachable", {}),
            "reason": blast.get("reason", {}),
            "import_consumers": blast.get("import_consumers", []),
            "contracts": blast.get(
                "contracts",
                {"outbound": [], "inbound": [], "total": 0},
            ),
            "ring": raw.get("ring", 1),
        }

        return make_tool_result(
            json.dumps(full_output, indent=2),
            BlastRadiusOutput,
            structured_data=structured_result,
        )

    except Exception as e:
        return handle_unhandled_exception(
            "forge_blast_radius",
            e,
            {
                "project_path": arguments.get("project_path", "") if isinstance(arguments, dict) else "",
                "operation": "blast_radius_execution",
            },
        )


async def handle_forge_trace(arguments: dict[str, Any]) -> types.CallToolResult:
    """Find dependency path between two nodes. Returns shortest graph path from from_id to to_id."""
    try:
        path, gate = resolve_validated_project_path_result(dict(arguments))
        if gate is not None:
            return gate

        exec_args = dict(arguments)
        exec_args["project_path"] = str(path)

        from forge.mcp.thin_core import _session, execute_trace

        raw = await asyncio.to_thread(lambda: execute_trace(exec_args))
        session = _session(exec_args)

        path_ids = raw.get("path") if isinstance(raw.get("path"), list) else []
        path_nodes = []
        for nid in path_ids:
            node = session.engine.node(str(nid))
            if node is not None:
                path_nodes.append(_node_to_forge_output(node, session))

        from_node = str(raw.get("from_id") or "")
        to_node = str(raw.get("to_id") or "")
        structured_result = {
            "ok": bool(raw.get("ok")),
            "project": path.name,
            "path": path_nodes,
            "from_node": from_node,
            "to_node": to_node,
        }
        text_payload = {
            **structured_result,
            "project_path": str(path),
            "connected": raw.get("connected"),
            "length": raw.get("length"),
            "error": raw.get("error"),
        }

        return make_tool_result(
            json.dumps(text_payload, indent=2),
            TraceOutput,
            structured_data=structured_result,
        )

    except Exception as e:
        return handle_unhandled_exception(
            "forge_trace",
            e,
            {
                "project_path": arguments.get("project_path", ""),
                "operation": "trace_execution",
            },
        )


def build_project_report(
    session: ForgeSession,
    *,
    response_tier: str = "L1",
) -> dict[str, Any]:
    """Build structured project report from ForgeSession (forge_report handler)."""
    from collections import Counter

    from forge.core.impact import collect_tier_import_violations

    tier = str(response_tier or "L1").upper()
    nodes = list(session.engine.registry.get_all())
    edges = list(session.engine.registry.get_edges())
    hv = session.health_vector().model_dump()

    domain_counts = Counter(n.domain or "CORE" for n in nodes)
    tier_counts = Counter(n.tier.value for n in nodes)

    top_blast: list[dict[str, Any]] = []
    if tier != "L0":
        scored: list[tuple[int, str]] = []
        for n in nodes[:80]:
            try:
                impact = session.impact_radius(n.id)
                scored.append((len(impact.affected_nodes), n.id))
            except Exception:
                continue
        scored.sort(reverse=True)
        top_blast = [
            {"node_id": nid, "affected_count": cnt}
            for cnt, nid in scored[:5]
        ]

    drift_count = 0
    try:
        drift_count = len(
            collect_tier_import_violations(session.engine.registry.graph)
        )
    except Exception:
        drift_count = 0

    if tier == "L0":
        return {
            "ok": True,
            "project": session.path.name,
            "node_count": len(nodes),
            "edge_count": len(edges),
            "response_tier": tier,
        }

    summary = {
        "domains": dict(domain_counts.most_common()),
        "tiers": dict(sorted(tier_counts.items())),
        "health_vector": {
            "adi": hv.get("adi"),
            "brc": hv.get("brc"),
            "idr": hv.get("idr"),
        },
        "drift_tier_violations": drift_count,
    }

    if tier == "L1":
        return {
            "ok": True,
            "project": session.path.name,
            "summary": summary,
            "top_blast_radius": top_blast,
            "response_tier": tier,
        }

    return {
        "ok": True,
        "project": session.path.name,
        "summary": summary,
        "top_blast_radius": top_blast,
        "node_count": len(nodes),
        "edge_count": len(edges),
        "domains": dict(domain_counts),
        "tiers": dict(tier_counts),
        "health_vector": hv,
        "drift_tier_violations": drift_count,
        "response_tier": tier,
    }


async def handle_forge_report(arguments: dict[str, Any]) -> types.CallToolResult:
    """Project report — domain summary, health vector, tier distribution."""
    try:
        path, gate = resolve_validated_project_path_result(dict(arguments))
        if gate is not None:
            return gate

        from forge.engine.session import ForgeSession

        session = ForgeSession.open(path)
        response_tier = str(arguments.get("response_tier") or "L1")
        result = build_project_report(
            session, response_tier=response_tier
        )

        return make_tool_result(
            json.dumps(result, indent=2),
            ReportOutput,
            structured_data=result,
        )

    except Exception as e:
        return handle_unhandled_exception(
            "forge_report",
            e,
            {
                "project_path": arguments.get("project_path", ""),
                "operation": "report_execution",
            },
        )
