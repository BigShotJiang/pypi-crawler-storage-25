"""Core tool handlers for Forge MCP.

High-traffic, high-priority tools with proper error handling
and forge/core/errors.py integration.
"""

from __future__ import annotations

import asyncio
import json
from typing import Any

import mcp.types as types
from forge.mcp.handlers.error_handlers import (
    make_tool_result,
    forge_error_result,
    handle_unhandled_exception,
    handle_validation_error,
)
from forge.mcp.handlers.validation import (
    validate_project_path,
    validate_node_id,
    validate_response_tier,
)
from forge.mcp.project_resolution import resolve_validated_project_path_result

# ENTITY CLASS: project._entities yields ForgeEntity
# (forge/core/forge_project_system.py)
# Interface: .get(key, default) and .get_property(key, default)
# Do NOT use direct attribute access for domain/status/tier


def _apply_project_status_to_orientation(
    orientation: dict[str, Any],
    status: dict[str, Any],
) -> None:
    """Backfill orient fields from :func:`~forge.mcp.project_status_core.build_project_status_payload` when bundle is sparse."""

    def _empty(val: Any) -> bool:
        if val is None or val == "":
            return True
        if val == [] or val == {}:
            return True
        return False

    if not isinstance(status, dict):
        return

    for key in (
        "phase",
        "stack",
        "current_task",
        "blocker",
        "next_action",
        "phase_name",
    ):
        sk = status.get(key)
        if sk is not None and _empty(orientation.get(key)):
            orientation[key] = sk

    sw = status.get("warnings")
    if isinstance(sw, list) and sw and _empty(orientation.get("warnings")):
        orientation["warnings"] = list(sw)

    pk = status.get("packets")
    if isinstance(pk, dict) and pk and _empty(orientation.get("packets")):
        orientation["packets"] = dict(pk)

    sn = status.get("suggested_next")
    if isinstance(sn, list) and sn and _empty(orientation.get("suggested_workflow")):
        orientation["suggested_workflow"] = list(sn)

    ih = status.get("infra_health")
    if isinstance(ih, dict) and ih and _empty(orientation.get("infra_health")):
        orientation["infra_health"] = dict(ih)

    icc = status.get("intent_coverage_compact")
    if icc is not None:
        ws = orientation.get("_workspace")
        if isinstance(ws, dict) and "intent_coverage_compact" not in ws:
            ws["intent_coverage_compact"] = icc


def _orientation_from_bundle(
    bundle: dict[str, Any],
    *,
    node: str | None,
    response_tier: str | None,
) -> dict[str, Any]:
    """Map thin_core execute_orient (ContextBundle asdict) to OrientOutput fields."""
    pc = bundle.get("project_context")
    project_ctx = pc if isinstance(pc, dict) else {}
    project_section = bundle.get("project_section") if isinstance(bundle.get("project_section"), dict) else {}
    session_section = bundle.get("session_section") if isinstance(bundle.get("session_section"), dict) else {}
    graph_section = bundle.get("graph_section") if isinstance(bundle.get("graph_section"), dict) else {}

    warnings = bundle.get("warnings")
    if not isinstance(warnings, list):
        warnings = project_section.get("warnings") or session_section.get("warnings") or []
    packets = session_section.get("packets") or project_section.get("packets") or {}

    graph_domains = graph_section.get("domains") if isinstance(graph_section.get("domains"), list) else []
    project_domains = project_ctx.get("domains") or project_section.get("domains") or []
    domains = sorted(
        {str(d).upper() for d in list(graph_domains) + list(project_domains) if str(d).strip()}
    )
    health_score = graph_section.get("health_score") if isinstance(graph_section.get("health_score"), dict) else {}

    out: dict[str, Any] = {
        "phase": project_ctx.get("phase") or project_section.get("phase"),
        "stack": project_ctx.get("stack") or project_section.get("stack"),
        "domains": domains,
        "current_task": project_ctx.get("current_task")
        or project_section.get("current_task")
        or session_section.get("current_task"),
        "blocker": project_ctx.get("blocker")
        or project_section.get("blocker")
        or session_section.get("blocker"),
        "next_action": project_ctx.get("next_action")
        or project_section.get("next_action")
        or session_section.get("next_action"),
        "warnings": list(warnings),
        "packets": packets if isinstance(packets, dict) else {},
        "structural_health": graph_section.get("structural_health"),
        "health_score": health_score,
        "graph_node_count": graph_section.get("node_count"),
        "graph_edge_count": graph_section.get("edge_count"),
        "next_nodes": graph_section.get("next_nodes") or [],
        "suggested_workflow": session_section.get("suggested_workflow") or [],
        "verify_failures": graph_section.get("verify_failures")
        or session_section.get("verify_failures")
        or [],
        "verify_exit_code": graph_section.get("verify_exit_code")
        if graph_section.get("verify_exit_code") is not None
        else session_section.get("verify_exit_code"),
        "node": node,
        "response_tier": response_tier,
        "level": bundle.get("level"),
        "template_name": bundle.get("template_name"),
    }
    ws = bundle.get("_workspace")
    if isinstance(ws, dict) and ws:
        out["_workspace"] = ws
    return out


async def handle_forge_health_vector(arguments: dict[str, Any]) -> types.CallToolResult:
    """
    Unified health vector for a project.
    Returns all six health dimensions plus overall status.
    
    Priority: P2 - Example tool for error system integration
    """
    try:
        path, gate = resolve_validated_project_path_result(arguments)
        if gate is not None:
            return gate

        try:
            from forge.mcp.thin_core import execute_health_vector
        except ImportError as e:
            from forge.core.errors import ERRORS
            from forge.core.errors import get_error
            error = get_error("dependency_unavailable")
            error.context.update({
                "missing_dependency": "forge.mcp.thin_core",
                "import_error": str(e),
            })
            return forge_error_result(error)

        hv = await asyncio.to_thread(
            lambda: execute_health_vector({"project_path": str(path)})
        )

        idr_block: dict[str, Any] = {"score": hv.get("idr_score", 0)}
        idr_rat = hv.get("idr_rationale")
        if idr_rat:
            idr_block["rationale"] = idr_rat

        payload = {
            "ok": True,
            "project": path.name,
            "project_path": str(path),
            "health_vector": {
                "graph_health": hv.get("graph_health"),
                "sync_health": hv.get("sync_health"),
                "infra_health": hv.get("infra_health"),
                "adi_score": hv.get("adi_score"),
                "brc_score": hv.get("brc_score"),
                "idr_score": hv.get("idr_score"),
                "healthy": hv.get("healthy"),
            },
            "adi": {"score": hv.get("adi_score", 0)},
            "brc": {"score": hv.get("brc_score", 0)},
            "idr": idr_block,
            "pos": {},
            "metadata": {
                "computed_at": "success",
                "engine_based": True,
            },
        }

        from .schemas import HealthVectorOutput
        return make_tool_result(
            json.dumps(payload, indent=2),
            HealthVectorOutput,
            structured_data=payload
        )
        
    except ValueError as e:
        # Validation errors
        return handle_validation_error(
            "project_path",
            str(e),
            {"project_path": arguments.get("project_path", "")}
        )
    except FileNotFoundError as e:
        # File system errors
        from forge.core.errors import ERRORS
        from forge.mcp.handlers.error_handlers import copy_forge_error
        error = copy_forge_error(
            ERRORS["manifest_not_found"],
            context={
                "project_path": arguments.get("project_path", ""),
                "file_error": str(e),
            }
        )
        return forge_error_result(error)
    except ImportError as e:
        # Dependency errors
        from forge.core.errors import ERRORS
        from forge.mcp.handlers.error_handlers import copy_forge_error
        error = copy_forge_error(
            ERRORS["dependency_unavailable"],
            context={
                "missing_dependency": "forge.metrics or forge.tools.manifest.graph",
                "import_error": str(e),
                "project_path": arguments.get("project_path", ""),
            }
        )
        return forge_error_result(error)
    except Exception as e:
        # Unexpected errors
        return handle_unhandled_exception(
            "forge_health_vector",
            e,
            {
                "project_path": arguments.get("project_path", ""),
                "operation": "health_vector_computation",
            }
        )


async def handle_forge_project_status(arguments: dict[str, Any]) -> types.CallToolResult:
    # Removed from tool surface 2026-05-17. Handler preserved for reference.
    # Use forge_orient — embeds project_status via build_project_status_payload.
    """
    Get project status and health information.
    
    Priority: P3 - High traffic tool
    """
    try:
        path, gate = resolve_validated_project_path_result(arguments)
        if gate is not None:
            return gate

        # Build project status payload
        try:
            from forge.mcp.project_status_core import build_project_status_payload
            payload = build_project_status_payload(str(path))
        except ImportError as e:
            from forge.mcp.handlers.error_handlers import copy_forge_error
            from forge.core.errors import ERRORS
            error = copy_forge_error(
                ERRORS["dependency_unavailable"],
                context={
                    "missing_dependency": "forge.mcp.project_status_core",
                    "import_error": str(e),
                }
            )
            return forge_error_result(error)
        
        # Restructure to match ProjectStatusOutput schema
        structured_payload = {
            "ok": True,
            "project": path.name,
            "project_path": str(path),
            "status": payload,
            "metadata": {
                "generated_at": "success",
            }
        }

        from .schemas import ProjectStatusOutput
        return make_tool_result(
            json.dumps(structured_payload, indent=2),
            ProjectStatusOutput,
            structured_data=structured_payload
        )
        
    except ValueError as e:
        return handle_validation_error(
            "project_path",
            str(e),
            {"project_path": arguments.get("project_path", "")}
        )
    except FileNotFoundError as e:
        from forge.core.errors import ERRORS
        from forge.mcp.handlers.error_handlers import copy_forge_error
        error = copy_forge_error(
            ERRORS["manifest_not_found"],
            context={
                "project_path": arguments.get("project_path", ""),
                "file_error": str(e),
            }
        )
        return forge_error_result(error)
    except Exception as e:
        return handle_unhandled_exception(
            "forge_project_status",
            e,
            {
                "project_path": arguments.get("project_path", ""),
                "operation": "project_status_generation",
            }
        )


async def handle_forge_verify(arguments: dict[str, Any]) -> types.CallToolResult:
    """
    Verification operations for Forge projects.
    
    Priority: P4 - Critical tool
    """
    scope = str(arguments.get("scope", "") or "").strip().lower()
    target = str(
        arguments.get("target") or arguments.get("scope") or "staged"
    ).strip().lower()
    try:
        path, gate = resolve_validated_project_path_result(arguments)
        if gate is not None:
            return gate

        # Validate scope parameter
        valid_scopes = ["parity", "stack", "full", "staged", "unstaged"]
        if scope and scope not in valid_scopes:
            return handle_validation_error(
                "scope",
                f"scope must be one of: {', '.join(valid_scopes)}",
                {"provided_scope": scope, "valid_scopes": valid_scopes}
            )
        
        # Validate target parameter
        valid_targets = [
            "staged", "full", "unstaged", "parity", "stack", "stacks"
        ]
        if target not in valid_targets:
            return handle_validation_error(
                "target",
                f"target must be one of: {', '.join(valid_targets)}",
                {"provided_target": target, "valid_targets": valid_targets}
            )
        
        # Validate response tier
        response_tier = validate_response_tier(arguments.get("response_tier"))
        
        try:
            from forge.mcp.thin_core import execute_verify
        except ImportError as e:
            from forge.mcp.handlers.error_handlers import copy_forge_error
            from forge.core.errors import ERRORS
            error = copy_forge_error(
                ERRORS["dependency_unavailable"],
                context={
                    "missing_dependency": "forge.mcp.thin_core.execute_verify",
                    "import_error": str(e),
                },
            )
            return forge_error_result(error)

        try:
            result = await asyncio.to_thread(
                lambda: execute_verify(
                    {
                        "project_path": str(path),
                        "target": target,
                        "strict": arguments.get("strict", False),
                    }
                )
            )
        except Exception as e:
            return handle_unhandled_exception(
                "forge_verify",
                e,
                {
                    "project_path": str(path),
                    "operation": "verify_execution",
                    "scope": scope,
                    "target": target,
                }
            )
        
        # Add response tier to result
        result["response_tier"] = response_tier
        
        # Add entity-based contract validation from session project
        try:
            from forge.mcp.server import get_or_create_session
            project = get_or_create_session(str(path)).project
            entities = list(project._entities.values())
            real_entities = [e for e in entities if e.kind != 'domain']
            declared_only = [e for e in real_entities if e.get("status") == "declared"]
            missing_impl = [e.to_dict() for e in declared_only]

            # Merge into result
            result["entity_coverage"] = {
                "total": len(real_entities),
                "implemented": len(real_entities) - len(declared_only),
                "declared_only": len(declared_only),
                "missing_implementations": missing_impl[:10],  # top 10
            }
        except ImportError as e:
            import logging

            logging.getLogger("forge.mcp").debug(
                "forge_verify entity_coverage skipped: %s", e
            )
        except Exception as e:
            import logging

            logging.getLogger("forge.mcp").debug(
                "forge_verify entity_coverage failed: %s", e
            )
        
        verify_body = dict(result)
        tier_violations = [
            f
            for f in (verify_body.get("failures") or [])
            if isinstance(f, dict)
            and (
                f.get("kind") == "tier-import-violation"
                or "tier" in str(f.get("kind") or "").lower()
            )
        ]
        if tier_violations:
            from forge.core.errors import (
                build_tier_violation_chain,
                get_error,
            )
            from forge.mcp.thin_core import execute_inspect

            for violation in tier_violations[:3]:
                from_node = str(violation.get("from_node") or "").strip()
                to_node = str(violation.get("to_node") or "").strip()
                from_tier = str(violation.get("from_tier") or "").strip()
                to_tier = str(violation.get("to_tier") or "").strip()
                if not from_node:
                    from_node = str(
                        violation.get("node")
                        or violation.get("affected_node")
                        or ""
                    ).strip()
                node = to_node or from_node
                if node and not violation.get("causal_chain"):
                    try:
                        inspect_result = execute_inspect({
                            "project_path": str(path),
                            "node_id": node,
                            "action": "node",
                            "response_tier": "L0",
                        })
                        rings = inspect_result.get("rings") or {}
                        ring2 = rings.get("2") or rings.get(2) or {}
                        blast = int(ring2.get("count") or 0)
                        violation["blast_radius"] = blast
                        violation["affected_node"] = node
                    except Exception:
                        pass
                if from_node and to_node and not violation.get("causal_chain"):
                    chain = build_tier_violation_chain(
                        from_node,
                        to_node,
                        from_tier or "?",
                        to_tier or "?",
                    )
                    err = get_error("ring_boundary_violation")
                    err = err.with_causal_chain(chain)
                    err = err.with_graph_context(
                        from_node,
                        affected=[to_node],
                    )
                    violation["causal_chain"] = [
                        h.to_dict() for h in chain
                    ]
                    violation["error_detail"] = err.to_dict()
                    violation["error"] = err.to_dict()
        verify_body["tier_violations"] = tier_violations
        exit_code = int(verify_body.get("exit_code") or 0)
        full = {
            "ok": exit_code == 0,
            "project": path.name,
            "project_path": str(path),
            "verification_result": verify_body,
            "response_tier": response_tier,
            "metadata": {"engine_based": True},
            "exit_code": exit_code,
        }
        
        from .schemas import VerifyOutput
        return make_tool_result(
            json.dumps(full, indent=2),
            VerifyOutput,
            structured_data=full
        )
        
    except ValueError as e:
        return handle_validation_error(
            "project_path" if "project_path" in str(e) else "scope" if "scope" in str(e) else "target",
            str(e),
            {
                "project_path": arguments.get("project_path", ""),
                "scope": scope,
                "target": target,
            }
        )
    except FileNotFoundError as e:
        from forge.core.errors import ERRORS
        from forge.mcp.handlers.error_handlers import copy_forge_error
        error = copy_forge_error(
            ERRORS["manifest_not_found"],
            context={
                "project_path": arguments.get("project_path", ""),
                "file_error": str(e),
            }
        )
        return forge_error_result(error)
    except ImportError as e:
        from forge.mcp.handlers.error_handlers import copy_forge_error
        from forge.core.errors import ERRORS
        error = copy_forge_error(
            ERRORS["dependency_unavailable"],
            context={
                "missing_dependency": "forge.cli.verify",
                "import_error": str(e),
            }
        )
        return forge_error_result(error)
    except Exception as e:
        return handle_unhandled_exception(
            "forge_verify",
            e,
            {
                "project_path": arguments.get("project_path", ""),
                "operation": "verify_execution",
                "scope": scope,
                "target": target,
            }
        )


async def handle_forge_orient(arguments: dict[str, Any]) -> types.CallToolResult:
    """
    Orientation for Forge projects.
    
    Priority: P1 - Core tool
    """
    try:
        # Resolve project root first (workspace / roots / explicit path)
        path, gate = resolve_validated_project_path_result(arguments)
        if gate is not None:
            return gate

        merged_args = {**arguments, "project_path": str(path)}
        from .schemas import ForgeOrientInput

        try:
            from forge.core.forge_project_system import ForgeEntity

            entity = ForgeEntity.from_dict(merged_args, kind="orient")
            if not entity.get_property("project_path"):
                entity.set_property("project_path", str(path))
                merged_args = {**merged_args, "project_path": str(path)}
            validated_input = ForgeOrientInput.model_validate(merged_args)
        except Exception as e:
            return handle_validation_error(
                "input_validation",
                f"Invalid input: {str(e)}",
                {"provided_arguments": arguments},
            )

        node = validated_input.node
        response_tier = validate_response_tier(validated_input.response_tier)

        node_id: str | None = None
        if node:
            node_id = validate_node_id(node)

        try:
            from forge.mcp.thin_core import execute_orient
        except ImportError as e:
            from forge.core.errors import ERRORS
            from forge.mcp.handlers.error_handlers import copy_forge_error
            error = copy_forge_error(
                ERRORS["dependency_unavailable"],
                context={
                    "missing_dependency": "forge.mcp.thin_core",
                    "import_error": str(e),
                    "project_path": str(path),
                },
            )
            return forge_error_result(error)

        orient_args: dict[str, Any] = {
            "project_path": str(path),
            "response_tier": response_tier,
        }
        if node_id:
            orient_args["node"] = node_id

        try:
            bundle = await asyncio.to_thread(lambda: execute_orient(orient_args))
        except Exception as e:
            return handle_unhandled_exception(
                "forge_orient",
                e,
                {
                    "project_path": str(path),
                    "operation": "orient_execution",
                    "node": node,
                    "response_tier": response_tier,
                },
            )

        orientation_result = _orientation_from_bundle(
            bundle,
            node=node_id,
            response_tier=response_tier,
        )
        try:
            from forge.mcp.project_status_core import build_project_status_payload

            tier_u = str(response_tier or "L1").upper()
            status_payload = build_project_status_payload(str(path), response_tier=tier_u)
            orientation_result["project_status"] = status_payload
            _apply_project_status_to_orientation(
                orientation_result,
                status_payload,
            )
        except Exception as e:
            import logging

            logging.getLogger("forge.mcp").debug(
                "forge_orient project_status merge failed: %s", e
            )
        graph_section = bundle.get("graph_section") if isinstance(bundle.get("graph_section"), dict) else {}
        session_section = bundle.get("session_section")
        session_section = session_section if isinstance(session_section, dict) else {}

        structured_result = {
            "ok": True,
            "project": path.name,
            "project_path": str(path),
            "orientation_result": orientation_result,
            "metadata": {
                "generated_at": "success",
                "response_tier": response_tier or "L1",
            }
        }

        # Store project context in _meta for dynamic prompt hydration
        from forge.mcp.server import MetaChannel
        channel = MetaChannel()
        channel._data["project_context"] = {
            "project": path.name,
            "project_path": str(path),
            "node": node_id,
            "response_tier": response_tier,
            "phase": orientation_result.get("phase", "unknown"),
            "current_task": orientation_result.get("current_task"),
            "blocker": orientation_result.get("blocker"),
            "next_nodes": orientation_result.get("next_nodes", []),
            "health_score": graph_section.get("health_score"),
            "entity_count": graph_section.get("node_count", 0),
            "layer_count": graph_section.get("edge_count", 0),
            "session_id": session_section.get("session_id"),
            "timestamp": bundle.get("timestamp"),
        }

        from .schemas import OrientOutput
        tool_result = make_tool_result(
            json.dumps(structured_result, indent=2),
            OrientOutput,
            structured_data=structured_result
        )

        # Attach _meta with project context
        return channel.attach(tool_result)
        
    except ValueError as e:
        return handle_validation_error(
            "project_path" if "project_path" in str(e) else "node",
            str(e),
            {
                "project_path": arguments.get("project_path", ""),
                "node": arguments.get("node"),
            }
        )
    except FileNotFoundError as e:
        from forge.core.errors import ERRORS, ForgeError
        base_error = ERRORS["manifest_not_found"]
        error = ForgeError(
            code=base_error.code,
            layer=base_error.layer,
            message=base_error.message,
            hint=base_error.hint,
            recoverable=base_error.recoverable,
            context={
                "project_path": arguments.get("project_path", ""),
                "file_error": str(e),
            }
        )
        return forge_error_result(error)
    except ImportError as e:
        from forge.core.errors import ERRORS, ForgeError
        base_error = ERRORS["dependency_unavailable"]
        error = ForgeError(
            code=base_error.code,
            layer=base_error.layer,
            message=base_error.message,
            hint=base_error.hint,
            recoverable=base_error.recoverable,
            context={
                "missing_dependency": "forge.mcp.thin_core",
                "import_error": str(e),
                "project_path": arguments.get("project_path", ""),
            }
        )
        return forge_error_result(error)
    except Exception as e:
        return handle_unhandled_exception(
            "forge_orient",
            e,
            {
                "project_path": arguments.get("project_path", ""),
                "operation": "orient_execution",
                "node": arguments.get("node"),
                "response_tier": arguments.get("response_tier"),
            }
        )


async def handle_forge_pipeline(arguments: dict) -> types.CallToolResult:
    """Execute a named pipeline — sequence of MCP tool calls in dependency order."""
    try:
        import json
        from forge.core.schemas import PipelineStepKind
        from forge.core.pipelines.verify_gate import VERIFY_GATE_PIPELINE

        pipeline_id = arguments.get("pipeline_id", "")

        path, gate = resolve_validated_project_path_result(arguments)
        if gate is not None:
            return gate
        project_path = str(path)
        
        PIPELINES = {
            "pipeline/verify_gate": VERIFY_GATE_PIPELINE,
            "verify_gate": VERIFY_GATE_PIPELINE,
        }
        
        pipeline = PIPELINES.get(pipeline_id)
        if not pipeline:
            return make_tool_result(json.dumps({
                "error": f"Unknown pipeline: {pipeline_id}",
                "available": list(PIPELINES.keys()),
            }), None, is_error=True)
        
        # Execute pipeline steps
        results = []
        aborted = False
        
        for step in pipeline.steps:
            if aborted:
                results.append({"step": step.step, "status": "skipped"})
                continue
            
            if step.kind == PipelineStepKind.TOOL:
                from forge.mcp.handlers.registry import TOOL_MAPPING
                handler = TOOL_MAPPING.get(step.tool)
                if not handler:
                    results.append({"step": step.step, "status": "error", 
                                   "message": f"unknown tool: {step.tool}"})
                    aborted = True
                    continue
                
                # Parse params like "response_tier=L1" into dict
                args = {}
                for param in step.params:
                    if "=" in param:
                        key, value = param.split("=", 1)
                        args[key] = value
                
                args = {**args, "project_path": project_path}
                result = await handler(args)
                text = result.content[0].text if result.content else ""
                
                try:
                    data = json.loads(text)
                except Exception:
                    data = {"raw": text}
                
                results.append({
                    "step": step.step,
                    "tool": step.tool,
                    "status": "error" if result.isError else "ok",
                    "result": data,
                })
            
            elif step.kind == PipelineStepKind.CONDITION and step.gate:
                last = results[-1] if results else {}
                last_result = last.get("result", {})
                exit_code = last_result.get("exit_code", 0)
                passed = str(exit_code) == step.condition_value
                
                results.append({
                    "step": step.step,
                    "kind": "gate",
                    "condition": f"{step.condition_field} == {step.condition_value}",
                    "passed": passed,
                    "status": "ok" if passed else "blocked",
                })
                
                if not passed:
                    aborted = True
        
        return make_tool_result(json.dumps({
            "pipeline_id": pipeline_id,
            "steps_total": len(pipeline.steps),
            "steps_run": len([r for r in results if r.get("status") != "skipped"]),
            "aborted": aborted,
            "results": results,
        }, indent=2), None)
        
    except Exception as e:
        import traceback
        return forge_error_result({"message": str(e), "debug": traceback.format_exc()})


async def handle_forge_invoke(arguments: dict) -> types.CallToolResult:
    """Invoke a domain-specific glove method."""
    import json
    from forge.mcp.server import get_or_create_session
    from forge.core.forge_project_system import GloveComponent
    
    domain = arguments.get("domain", "").upper()
    method = arguments.get("method", "")
    kwargs = arguments.get("args", {})

    path, gate = resolve_validated_project_path_result(arguments)
    if gate is not None:
        return gate
    project_path = str(path)
    
    project = get_or_create_session(project_path).project
    
    # Find entity by domain with GloveComponent
    glove_entity = None
    for entity in project._entities.values():
        if entity.get("domain") == domain:
            gc = entity.get_component(GloveComponent)
            if gc and gc.can_invoke(method):
                glove_entity = entity
                break
    
    if not glove_entity:
        # List available gloves
        available = {}
        for entity in project._entities.values():
            gc = entity.get_component(GloveComponent)
            if gc and gc._loaded:
                available[entity.get("domain", "")] = gc.list_methods()
        
        return make_tool_result(json.dumps({
            "error": f"No glove found for domain={domain!r} method={method!r}",
            "available_gloves": available,
        }), None, is_error=True)
    
    gc = glove_entity.get_component(GloveComponent)
    result = gc.invoke(method, **kwargs)
    
    return make_tool_result(json.dumps({
        "domain": domain,
        "method": method,
        "result": result,
        "entity": glove_entity.id,
    }, indent=2), None)
