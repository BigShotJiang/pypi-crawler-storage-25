"""Config tools for Forge MCP handlers."""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any

import mcp.types as types
from forge.mcp.handlers.error_handlers import (
    make_tool_result,
    forge_error_result,
    handle_unhandled_exception,
    handle_validation_error,
    _text_result,
)
from forge.mcp.handlers.validation import validate_project_path
from forge.mcp.project_resolution import resolve_validated_project_path_result
from forge.mcp.handlers.schemas import ConfigGetOutput, ConfigSetOutput, ForgeConfigSetInput


async def handle_forge_config_set(arguments: dict[str, Any]) -> types.CallToolResult:
    """
    Set configuration value for Forge project.

    Priority: P2 - Core tool
    """
    try:
        path, gate = resolve_validated_project_path_result(arguments)
        if gate is not None:
            return gate

        path = validate_project_path(str(path))

        try:
            validated = ForgeConfigSetInput.model_validate(
                {**arguments, "project_path": str(path)}
            )
        except Exception as e:
            return handle_validation_error(
                "input_validation",
                f"Invalid input: {str(e)}",
                {"provided_arguments": arguments},
            )

        config_key = validated.key
        if not config_key:
            return handle_validation_error(
                "key",
                "key is required",
                {"available_arguments": ["key"]},
            )

        dry_run = bool(validated.dry_run)
        file_target = str(validated.file or "config").strip().lower()

        from forge.commands.config_cmd import (
            read_config,
            write_config,
            resolve_mcp_yaml_file,
            resolve_project_root,
            _set_key,
        )

        proj = str(path)
        root = resolve_project_root(proj)

        def _run() -> dict[str, Any]:
            cfg_path = resolve_mcp_yaml_file(Path(root), file_target)
            data = read_config(cfg_path)
            if not isinstance(data, dict):
                data = {}
            old, next_data = _set_key(data, config_key, validated.value)
            if dry_run:
                return {
                    "ok": True,
                    "key": config_key,
                    "value": validated.value,
                    "updated": False,
                    "dry_run": True,
                    "project": path.name,
                    "project_path": str(path),
                    "config_path": str(cfg_path),
                    "previous_value": old,
                }
            write_config(cfg_path, next_data)
            return {
                "ok": True,
                "key": config_key,
                "value": validated.value,
                "updated": True,
                "dry_run": False,
                "project": path.name,
                "project_path": str(path),
                "config_path": str(cfg_path),
                "previous_value": old,
            }

        try:
            out = await asyncio.to_thread(_run)
            return make_tool_result(
                json.dumps(out, indent=2),
                ConfigSetOutput,
                structured_data=out,
            )
        except FileNotFoundError as exc:
            return _text_result(
                json.dumps({
                    "error": "Configuration file not found",
                    "details": str(exc),
                    "hint": f"Create the target YAML for file='{file_target}' or choose another file= value",
                    "file_target": file_target,
                    "project_path": proj,
                }),
                is_error=True,
            )
        except ValueError as exc:
            return handle_validation_error(
                "file",
                str(exc),
                {"file": file_target},
            )

    except Exception as e:
        return handle_unhandled_exception(
            "forge_config_set",
            e,
            {
                "project_path": arguments.get("project_path", ""),
                "key": arguments.get("key", ""),
                "operation": "config_set_execution",
            },
        )


async def handle_forge_config_get(arguments: dict[str, Any]) -> types.CallToolResult:
    try:
        # Validate input using typed model
        from .schemas import ForgeConfigGetInput
        try:
            path, gate = resolve_validated_project_path_result(arguments)
            if gate is not None:
                return gate
            validated_input = ForgeConfigGetInput.model_validate({**arguments, "project_path": str(path)})
        except Exception as e:
            return handle_validation_error(
                "input_validation",
                f"Invalid input: {str(e)}",
                {"provided_arguments": arguments}
            )

        from forge.commands.config_cmd import _get_key, read_config, resolve_mcp_yaml_file, resolve_project_root, resolve_project_path

        resolved = resolve_project_path(validated_input.project_path)
        if not resolved:
            from forge.core.errors import ERRORS
            return forge_error_result(ERRORS["no_project_path"])
        proj = str(resolved)
        key = str(validated_input.key)
        file_target = str(validated_input.file or "config").strip().lower()

        def _run() -> dict[str, Any]:
            root = resolve_project_root(proj)
            cfg = resolve_mcp_yaml_file(root, file_target)
            data = read_config(cfg)
            ok, value = _get_key(data, key)
            if not ok:
                raise KeyError(f"Key not found: {key}")
            return {"key": key, "value": value}

        try:
            out = await asyncio.to_thread(_run)
            from .schemas import ConfigGetOutput
            return make_tool_result(
                json.dumps(out, indent=2),
                ConfigGetOutput,
                structured_data=out,
            )
        except FileNotFoundError as exc:
            return _text_result(
                json.dumps({
                    "error": "Configuration file not found",
                    "details": str(exc),
                    "hint": f"Create {file_target}.yaml in your project root or use file='manifest' to read .forge/manifest.yaml",
                    "file_target": file_target,
                    "project_root": proj
                }),
                is_error=True
            )
        except KeyError as exc:
            return _text_result(
                json.dumps({
                    "error": "Configuration key not found",
                    "details": str(exc),
                    "hint": f"Check available keys in {file_target}.yaml or use forge_config_get with key='' to see all keys",
                    "requested_key": key,
                    "file_target": file_target
                }),
                is_error=True
            )
        except Exception as exc:
            return _text_result(str(exc), is_error=True)

    except Exception as e:
        return handle_unhandled_exception(
            "forge_config_get",
            e,
            {
                "project_path": arguments.get("project_path", ""),
                "operation": "config_get_execution",
            }
        )

async def handle_forge_config_get_thin(arguments: dict[str, Any]) -> types.CallToolResult:
    res = await handle_forge_config_get(arguments)
    text = res.content[0].text if res.content and isinstance(res.content[0], types.TextContent) else ""
    return make_tool_result(text, None, is_error=bool(res.isError))
