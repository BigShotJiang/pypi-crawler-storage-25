"""Tool registry for Forge MCP handlers.

Cleaned up registry with no duplicates and proper tool mapping.
"""

from __future__ import annotations

from typing import Any, Callable

from mcp.types import ToolAnnotations

from mcp.types import ToolAnnotations

from .core_tools import (
    handle_forge_health_vector,
    handle_forge_verify,
    handle_forge_orient,
    handle_forge_pipeline,
    handle_forge_invoke,
)
from .audit_tools import (
    handle_forge_audit_scan,
    handle_forge_annotate,
)
from .manifest_tools import (
    handle_forge_manifest_append,
    handle_forge_query,
    handle_forge_discover,
    handle_forge_inspect,
    handle_forge_search,
)
from .query_tools import (
    handle_forge_intent,
)
from .system_tools import (
    handle_forge_workspace,
    handle_forge_session,
)
from .impact_tools import handle_forge_impact_radius
from .config_tools import handle_forge_config_get, handle_forge_config_set
from .scaffold_tools import handle_forge_scaffold, handle_forge_template
from .packet_tools import handle_forge_packet_assemble
from .mapping_tools import (
    handle_forge_map,
    handle_forge_trace,
)

# Tool annotations for MCP client hints
TOOL_ANNOTATIONS: dict[str, Any] = {
    "forge_orient": ToolAnnotations(
        readOnlyHint=True,
        title="Orient — start here; phase, stack, health, "
        "next action, and project status fields",
    ),
    "forge_query": ToolAnnotations(
        readOnlyHint=True,
        title="Query — find nodes by domain/kind/name; "
        "entry point for graph traversal",
    ),
    "forge_search": ToolAnnotations(
        readOnlyHint=True,
        title="Search — deprecated, use "
        "forge_inspect action=search instead",
    ),
    "forge_discover": ToolAnnotations(
        readOnlyHint=True,
        title="Discover — find source files not "
        "declared in manifest; stack-agnostic",
    ),
    "forge_inspect": ToolAnnotations(
        readOnlyHint=True,
        title="Inspect — progressive node navigation; "
        "action=node to start, use handle to expand/select/diff/packet",
    ),
    "forge_verify": ToolAnnotations(
        readOnlyHint=True,
        title="Verify — structural validation; checks "
        "staged changes against manifest",
    ),
    "forge_health_vector": ToolAnnotations(
        readOnlyHint=True,
        title="Health Vector — ADI/BRC/IDR scores; "
        "use after orient to assess coverage",
    ),
    "forge_audit_scan": ToolAnnotations(
        readOnlyHint=True,
        title="Audit Scan — annotation health check; "
        "surfaces expired or unresolved items",
    ),
    "forge_map": ToolAnnotations(
        readOnlyHint=True,
        title="Map — full edge topology; use forge_query "
        "for filtered node traversal",
    ),
    "forge_trace": ToolAnnotations(
        readOnlyHint=True,
        title="Trace — find dependency path between two "
        "specific nodes; confirms connection exists",
    ),
    "forge_impact_radius": ToolAnnotations(
        readOnlyHint=True,
        title="Impact Radius — unified: blast ring, "
        "doc consumers, contract violations",
    ),
    "forge_config_get": ToolAnnotations(
        readOnlyHint=True,
        title="Config Get — read app_config.yaml "
        "or manifest config values",
    ),
    "forge_session": ToolAnnotations(
        readOnlyHint=True,
        title="Session — manage session state, "
        "sprint log, and handoff packets",
    ),
    "forge_scaffold": ToolAnnotations(
        destructiveHint=True,
        title="Scaffold — generate code artifacts "
        "from manifest node templates",
    ),
    "forge_template": ToolAnnotations(
        readOnlyHint=True,
        title="Template — discover scaffold templates "
        "for a node kind and stack",
    ),
    "forge_manifest_append": ToolAnnotations(
        destructiveHint=True,
        title="Manifest Append — declare new nodes "
        "in manifest.yaml",
    ),
    "forge_intent": ToolAnnotations(
        destructiveHint=True,
        title="Intent — record design intent on a "
        "node; feeds IDR health score",
    ),
    "forge_annotate": ToolAnnotations(
        destructiveHint=True,
        title="Annotate — add audit annotation; "
        "creates evidence trail for changes",
    ),
    "forge_pipeline": ToolAnnotations(
        destructiveHint=True,
        title="Pipeline — execute named tool sequence; "
        "use for multi-step workflows",
    ),
    "forge_invoke": ToolAnnotations(
        destructiveHint=True,
        title="Invoke — call domain glove method; "
        "stack-specific analysis",
    ),
    "forge_config_set": ToolAnnotations(
        destructiveHint=True,
        title="Config Set — write config value; "
        "use dry_run=true to preview",
    ),
    "forge_workspace": ToolAnnotations(
        readOnlyHint=True,
        title="Workspace — list or resolve Forge "
        "projects in the workspace",
    ),
    "forge_packet_assemble": ToolAnnotations(
        readOnlyHint=True,
        title="Packet Assemble — build handoff "
        "packet from session and project state",
    ),
}

# Clean tool mapping - no duplicates
TOOL_MAPPING = {
    # ── Core Tools ──────────────────────────────────────────────────────
    "forge_health_vector": handle_forge_health_vector,
    "forge_verify": handle_forge_verify,
    "forge_orient": handle_forge_orient,
    "forge_pipeline": handle_forge_pipeline,
    "forge_invoke": handle_forge_invoke,
    
    # ── Audit Tools ───────────────────────────────────────────────────
    "forge_audit_scan": handle_forge_audit_scan,
    "forge_annotate": handle_forge_annotate,
    
    # ── Manifest Tools ─────────────────────────────────────────────────
    "forge_manifest_append": handle_forge_manifest_append,
    "forge_query": handle_forge_query,
    "forge_discover": handle_forge_discover,
    "forge_inspect": handle_forge_inspect,
    # Backward compat — delegates to forge_inspect action=search (deprecated)
    "forge_search": handle_forge_search,
    
    # ── Query Tools ───────────────────────────────────────────────────
    "forge_intent": handle_forge_intent,
    
    # ── System Tools ───────────────────────────────────────────────────
    "forge_workspace": handle_forge_workspace,
    "forge_session": handle_forge_session,
    
    # ── Impact Tools ───────────────────────────────────────────
    "forge_impact_radius": handle_forge_impact_radius,
    
    # ── Config Tools ────────────────────────────────────────────
    "forge_config_get": handle_forge_config_get,
    "forge_config_set": handle_forge_config_set,
    
    # ── Scaffold Tools ──────────────────────────────────────────
    "forge_scaffold": handle_forge_scaffold,
    "forge_template": handle_forge_template,
    
    # ── Packet Tools ────────────────────────────────────────────
    "forge_packet_assemble": handle_forge_packet_assemble,
    
    # ── Mapping Tools ──────────────────────────────────────────
    "forge_map": handle_forge_map,
    "forge_trace": handle_forge_trace,
}

# Import registry for registration
from forge.mcp import registry


def register_clean_tools() -> None:
    """
    Register cleaned up tool mapping with proper inputSchema from Pydantic models.
    Removes duplicates and consolidates multi-action tools.
    """
    from mcp.types import Tool
    from .schemas import get_input_schema
    
    for tool_name, handler in TOOL_MAPPING.items():
        from .error_handlers import _wrap_mcp_tool_handler
        wrapped_handler = _wrap_mcp_tool_handler(tool_name, handler)
        
        # Get proper input schema from Pydantic model
        input_schema_model = get_input_schema(tool_name)
        if input_schema_model:
            input_schema = input_schema_model.model_json_schema()
        else:
            # Fallback schema for tools without input models
            input_schema = {
                "type": "object",
                "properties": {
                    "project_path": {
                        "type": "string",
                        "description": "Path to Forge project"
                    }
                }
            }
        
        # Create tool with proper schema
        tool = Tool(
            name=tool_name,
            description=f"Cleaned up {tool_name} handler with typed schemas",
            inputSchema=input_schema,
            annotations=TOOL_ANNOTATIONS.get(tool_name)  # None if not in dict = no annotation
        )
        
        registry.register_tool(tool_name, wrapped_handler, tool)

    # Importing forge.mcp.registry triggers this; keep stdout quiet unless debugging MCP registration.
    import os
    if os.environ.get("FORGE_VERBOSE_TOOL_REGISTRATION", "").lower() in ("1", "true", "yes"):
        print(f"✅ Registered {len(TOOL_MAPPING)} cleaned tools with proper schemas:")
        for tool_name in TOOL_MAPPING.keys():
            input_schema_status = "✓" if get_input_schema(tool_name) else "○"
            print(f"   - {tool_name} (inputSchema: {input_schema_status})")




