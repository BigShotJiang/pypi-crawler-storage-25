"""Input validation functions for Forge MCP handlers.

Provides typed validation that integrates with forge/core/errors.py
to replace manual string checks and dict returns.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from forge.core.errors import ERRORS


def validate_project_path(project_path: str | None) -> Path:
    """
    Validate and resolve project path with proper error handling.
    Returns Path if valid, raises ValueError with structured error if invalid.
    """
    if not project_path or not str(project_path).strip():
        raise ValueError(ERRORS["no_project_path"])
    
    path = Path(project_path).expanduser().resolve()
    
    if not path.exists():
        raise FileNotFoundError(ERRORS["manifest_not_found"].message)
    
    if not path.is_dir():
        raise NotADirectoryError(f"Project path is not a directory: {path}")
    
    # Check if it's a Forge project
    forge_dir = path / ".forge"
    if not forge_dir.exists():
        raise FileNotFoundError(ERRORS["manifest_not_found"].message)
    
    # Check for manifest
    manifest_file = forge_dir / "manifest.yaml"
    if not manifest_file.exists():
        manifest_file = forge_dir / "manifest.yml"
        if not manifest_file.exists():
            raise FileNotFoundError(ERRORS["manifest_not_found"].message)
    
    return path


def validate_tool_arguments(arguments: dict[str, Any], required_fields: list[str]) -> dict[str, Any]:
    """
    Validate tool arguments with proper error handling.
    Returns validated arguments dict, raises ValueError for invalid input.
    """
    if not arguments:
        raise ValueError("Tool arguments cannot be None or empty")
    
    missing_fields = []
    for field in required_fields:
        if field not in arguments or arguments[field] is None:
            missing_fields.append(field)
    
    if missing_fields:
        raise ValueError(f"Missing required fields: {', '.join(missing_fields)}")
    
    return arguments


def validate_node_id(node_id: str | None) -> str:
    """
    Validate node ID parameter.
    Returns validated node_id string, raises ValueError if invalid.
    """
    if not node_id or not str(node_id).strip():
        raise ValueError("node_id is required and cannot be empty")
    
    return str(node_id).strip()


def validate_response_tier(response_tier: str | None) -> str:
    """
    Validate response_tier parameter.
    Returns validated response_tier, raises ValueError if invalid.
    """
    if not response_tier:
        return "L1"  # Default
    
    valid_tiers = ["L0", "L1", "L2"]
    if response_tier not in valid_tiers:
        raise ValueError(f"response_tier must be one of: {', '.join(valid_tiers)}")
    
    return response_tier


def validate_project_id(project_id: str | None) -> str:
    """
    Validate project_id parameter.
    Returns validated project_id string, raises ValueError if invalid.
    """
    if not project_id or not str(project_id).strip():
        raise ValueError("project_id is required and cannot be empty")
    
    return str(project_id).strip()


def validate_annotation_id(annotation_id: str | None) -> str:
    """
    Validate annotation_id parameter.
    Returns validated annotation_id string, raises ValueError if invalid.
    """
    if not annotation_id or not str(annotation_id).strip():
        raise ValueError("annotation_id is required and cannot be empty")
    
    return str(annotation_id).strip()


def validate_session_id(session_id: str | None) -> str:
    """
    Validate session_id parameter.
    Returns validated session_id string, raises ValueError if invalid.
    """
    if not session_id or not str(session_id).strip():
        raise ValueError("session_id is required and cannot be empty")
    
    return str(session_id).strip()
