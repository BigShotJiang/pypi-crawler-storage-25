"""
Error handling utilities for Forge MCP handlers.

This module provides centralized error handling that integrates
with forge/core/errors.py to replace raw string errors and dict returns.
"""

from __future__ import annotations

import json
import traceback
from typing import Any

import mcp.types as types
from forge.core.errors import ERRORS, ForgeError, get_error


def copy_forge_error(base_error: ForgeError, **updates) -> ForgeError:
    """Deep-copy a ForgeError and apply field updates."""
    import copy as _copy

    err = _copy.deepcopy(base_error)
    context = updates.pop("context", None)
    if context:
        err.context.update(context)
    source_tool = updates.pop("source_tool", None)
    if source_tool is not None:
        err.source_tool = source_tool
        err.context.setdefault("source_tool", source_tool)
    for key, value in updates.items():
        if hasattr(err, key):
            setattr(err, key, value)
    return err


def graph_node_not_found_result(
    node_id: str,
    *,
    source_tool: str | None = None,
    message: str | None = None,
) -> types.CallToolResult:
    """Structured node-not-found with graph context for MCP handlers."""
    err = get_error("node_not_found")
    if message:
        err.message = message
    err = err.with_graph_context(
        node_id,
        suggested_actions=[
            f"forge_search query={node_id}",
            "forge_discover to find undeclared nodes",
        ],
        suggested_commands=[
            f"forge inspect {node_id}",
            "forge discover",
        ],
    )
    if source_tool:
        err.source_tool = source_tool
    return forge_error_result(err)


def make_tool_result(
    text_output: str,
    structured_model: type | None = None,
    *,
    structured_data: dict[str, Any] | None = None,
    is_error: bool = False,
) -> types.CallToolResult:
    """
    Wrap CLI text output in CallToolResult with ForgeError integration.
    If structured_model provided and text_output is valid JSON, attach structuredContent.
    Degrades gracefully to text-only on JSON/validation failures.
    """
    content = [types.TextContent(type="text", text=text_output)]
    structured = None
    if structured_model is not None:
        try:
            data = structured_data if structured_data is not None else json.loads(text_output)
            structured = structured_model.model_validate(data).model_dump()
        except Exception as e:
            import logging
            logging.getLogger("forge.mcp.error_handlers").warning(
                "structuredContent validation failed for %s: %s",
                getattr(structured_model, "__name__", structured_model),
                e,
            )
    return types.CallToolResult(content=content, structuredContent=structured, isError=is_error)


def _text_result(text: str, *, is_error: bool = False) -> types.CallToolResult:
    """
    Return a basic text result. This should be used sparingly - prefer
    forge_error_result() for proper error handling.
    """
    return types.CallToolResult(
        content=[types.TextContent(type="text", text=text)],
        isError=is_error,
    )


def elicitation_tool_result(signal: dict[str, Any], *, structured_model: type | None = None) -> types.CallToolResult:
    """Return a recoverable MCP tool payload that asks for missing routing context (never ``is_error``).

    Mirrors ``check_project_context`` payloads under the same envelope keys consumers already expect.
    """
    envelope = dict(signal)
    envelope.setdefault("ok", False)
    envelope.setdefault("elicitation_required", True)
    return make_tool_result(
        json.dumps(envelope, indent=2),
        structured_model,
        structured_data=envelope if structured_model else None,
        is_error=False,
    )


def forge_error_result(error: "forge.core.errors.ForgeError") -> types.CallToolResult:
    """
    Return a structured MCP error result using ForgeError.
    This is the preferred way to return errors from handlers.
    """
    return _text_result(
        json.dumps(error.to_dict(), indent=2),
        is_error=True
    )


def handle_unhandled_exception(
    tool_name: str,
    exception: Exception,
    context: dict[str, Any] | None = None
) -> types.CallToolResult:
    """
    Handle unhandled exceptions with proper ForgeError integration.
    This replaces raw traceback returns with structured errors.
    """
    debug_trace = traceback.format_exc()
    if len(debug_trace) > 500:
        debug_trace = debug_trace[:500] + "...[truncated]"
    exception_msg = str(exception)
    if len(exception_msg) > 200:
        exception_msg = exception_msg[:200] + "...[truncated]"
    error = copy_forge_error(
        get_error("ERR-001"),
        source_tool=tool_name,
        debug=debug_trace,
        context={
            "exception": exception_msg,
            "debug": debug_trace,
        },
    )
    
    if context:
        # Also limit context size to prevent stalls
        limited_context = {}
        for k, v in (context or {}).items():
            v_str = str(v)
            if len(v_str) > 100:  # Limit each context field to 100 chars
                v_str = v_str[:100] + "...[truncated]"
            limited_context[k] = v_str
        error.context.update(limited_context)
    
    return forge_error_result(error)


def handle_validation_error(
    field_name: str,
    message: str,
    context: dict[str, Any] | None = None
) -> types.CallToolResult:
    """
    Handle input validation errors with structured responses.
    """
    error = get_error("ERR-002")
    if len(message) > 200:
        message = message[:200] + "...[truncated]"
    error.message = message
    error.context.update({
        "field": field_name,
        "validation_message": message,
    })
    
    if context:
        # Limit context size to prevent stalls
        limited_context = {}
        for k, v in (context or {}).items():
            v_str = str(v)
            if len(v_str) > 100:  # Limit each context field to 100 chars
                v_str = v_str[:100] + "...[truncated]"
            limited_context[k] = v_str
        error.context.update(limited_context)
    
    return forge_error_result(error)


def handle_dependency_error(
    dependency_name: str,
    context: dict[str, Any] | None = None
) -> types.CallToolResult:
    """
    Handle missing dependency errors with structured responses.
    """
    error = get_error("dependency_unavailable")
    error.context.update({
        "missing_dependency": dependency_name,
    })
    
    if context:
        error.context.update(context)
    
    return forge_error_result(error)


def _wrap_mcp_tool_handler(
    tool_name: str,
    handler: Callable[[dict[str, Any]], Awaitable[types.CallToolResult]],
) -> Callable[[dict[str, Any]], Awaitable[types.CallToolResult]]:
    """Normalize unhandled failures to ForgeError ERR-001 JSON (never bare traceback strings)."""

    async def _wrapped(arguments: dict[str, Any]) -> types.CallToolResult:
        # Event emission - emit tool_called before execution
        from forge.events.mcp_wrapper import get_emitter, extract_project
        
        emitter = get_emitter(arguments)
        project = extract_project(arguments)
        
        if emitter:
            emitter.emit_tool_event(
                tool_name=tool_name,
                project=project,
                kind="tool_called",
                payload={"arguments": {
                    k: v for k, v in arguments.items()
                    if k != "project_path"
                }},
            )
        
        # Execute the actual handler
        try:
            result = await handler(arguments)
            if emitter:
                emitter.emit_tool_event(
                    tool_name=tool_name,
                    project=project,
                    kind="tool_completed",
                    payload={"ok": True},
                )
            return result
        except Exception as e:
            if emitter:
                emitter.emit_tool_event(
                    tool_name=tool_name,
                    project=project,
                    kind="tool_failed",
                    payload={"error": str(e)[:200]},
                )
            raise

    return _wrapped