"""
Forge MCP Handlers Package

Split from monolithic handlers.py to enable:
- Modular development
- Isolated testing  
- Clear separation of concerns
- Progress tracking

Package structure:
- error_handlers.py: Error handling utilities
- validation.py: Input validation functions
- core_tools.py: High-traffic tool handlers
- audit_tools.py: Audit-related handlers
- manifest_tools.py: Manifest operations
- query_tools.py: Query and intent handlers
- system_tools.py: System/utility handlers
"""

import os
import sys
import importlib.util

from .error_handlers import make_tool_result, _text_result, forge_error_result
from .validation import validate_project_path, validate_tool_arguments

# Import tool handlers by category
from .core_tools import *
from .audit_tools import *
from .manifest_tools import *
from .query_tools import *
from .system_tools import *

# NOTE: Original handlers.py causes circular imports with server.py
# Using clean registry instead for Phase 4 completion
# Legacy handlers will be migrated to modular files

# Import register_builtin_tools for backward compatibility
def register_builtin_tools():
    """Legacy compatibility - delegates to clean registry"""
    from .registry import register_clean_tools
    register_clean_tools()

# Legacy placeholder handlers removed — all dispatch via forge/mcp/handlers/registry.py
# See TOOL_MAPPING in registry.py for the canonical handler list


# Legacy imports for backward compatibility
# TODO: Remove these after migration is complete
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

# Progress tracking
PHASE1_STATUS = {
    "package_structure_created": True,
    "imports_extracted": False,
    "modules_created": False,
    "testing_complete": False,
}

def mark_phase1_complete(task: str) -> None:
    """Track Phase 1 progress"""
    PHASE1_STATUS[task] = True
    _save_phase_status()

def get_phase1_progress() -> dict:
    """Get current Phase 1 progress"""
    return PHASE1_STATUS.copy()

def _save_phase_status() -> None:
    """Save phase progress to file"""
    import json
    from pathlib import Path
    
    status_file = Path(__file__).parent / "phase1_status.json"
    status_file.write_text(json.dumps(PHASE1_STATUS, indent=2))

def _load_phase_status() -> None:
    """Load phase progress from file"""
    import json
    from pathlib import Path
    
    status_file = Path(__file__).parent / "phase1_status.json"
    if status_file.exists():
        global PHASE1_STATUS
        PHASE1_STATUS = json.loads(status_file.read_text())

# Load existing status
_load_phase_status()
