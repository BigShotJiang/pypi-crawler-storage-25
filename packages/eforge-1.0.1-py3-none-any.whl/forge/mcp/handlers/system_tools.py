"""System and utility tool handlers for Forge MCP.

Includes workspace operations, system utilities, and other core functionality.
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any

import mcp.types as types
import yaml

from forge.mcp.handlers.error_handlers import (
    make_tool_result,
    forge_error_result,
    handle_unhandled_exception,
    handle_validation_error,
)
from forge.core.errors import get_error
from forge.mcp.handlers.validation import (
    validate_project_path,
    validate_project_id,
    validate_session_id,
)
from forge.mcp.project_resolution import resolve_validated_project_path_result
from forge.mcp.handlers.schemas import ForgeSessionInput, SessionOutput


def _session_events_dir(project_path: Path) -> Path:
    return project_path / ".forge" / "events"


def _resolve_session_state(project_path: Path, session_id: str | None) -> tuple[str, dict[str, Any]]:
    events_dir = _session_events_dir(project_path)
    sid_in = (session_id or "").strip() or None
    if sid_in:
        p = events_dir / f"{sid_in}.yaml"
        if not p.is_file():
            raise ValueError(f"session not found: {sid_in}")
        data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
        return sid_in, data if isinstance(data, dict) else {}
    if not events_dir.is_dir():
        return "none", {"detail": "no .forge/events directory", "events_dir": str(events_dir)}
    candidates: list[tuple[str, str, dict[str, Any]]] = []
    for p in events_dir.glob("*.yaml"):
        try:
            raw = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
        except Exception:
            continue
        if not isinstance(raw, dict) or raw.get("document_kind") != "session_state":
            continue
        candidates.append((str(raw.get("started_at") or ""), p.stem, raw))
    if not candidates:
        return "none", {"detail": "no session_state yaml under .forge/events"}
    candidates.sort(key=lambda x: x[0], reverse=True)
    return candidates[0][1], candidates[0][2]


async def handle_forge_workspace(arguments: dict[str, Any]) -> types.CallToolResult:
    """
    Workspace operations for Forge.
    
    Priority: P4 - System functionality
    """
    try:
        # Validate input using typed model
        from .schemas import ForgeWorkspaceInput
        try:
            path_res, gate = resolve_validated_project_path_result(arguments)
            if gate is not None:
                return gate
            merged = {**arguments, "project_path": str(path_res)}
            validated_input = ForgeWorkspaceInput.model_validate(merged)
        except Exception as e:
            return handle_validation_error(
                "input_validation",
                f"Invalid input: {str(e)}",
                {"provided_arguments": arguments}
            )

        path = validate_project_path(str(validated_input.project_path))

        # Validate action parameter
        action = validated_input.action
        if not action:
            return handle_validation_error(
                "action",
                "action is required",
                {"available_actions": ["add", "dependents", "dependencies", "get"]}
            )
        
        # Route to specific workspace operations
        if action == "add":
            return await _handle_workspace_add(validated_input, path)
        elif action == "dependents":
            return await _handle_workspace_dependents(validated_input, path)
        elif action == "dependencies":
            return await _handle_workspace_dependencies(validated_input, path)
        elif action == "get":
            return await _handle_workspace_get(validated_input, path)
        else:
            return handle_validation_error(
                "action",
                f"Invalid action: {action}",
                {"available_actions": ["add", "dependents", "dependencies", "get"]}
            )
        
    except ValueError as e:
        return handle_validation_error(
            "action" if "action" in str(e) else "project_path",
            str(e),
            {
                "project_path": arguments.get("project_path", ""),
                "action": arguments.get("action"),
            }
        )
    except Exception as e:
        return handle_unhandled_exception(
            "forge_workspace",
            e,
            {
                "project_path": arguments.get("project_path", ""),
                "operation": "workspace_operation",
                "action": arguments.get("action"),
            }
        )


async def _handle_workspace_get(arguments: dict[str, Any], project_path: Path) -> types.CallToolResult:
    """Handle workspace get operation."""
    try:
        from forge.mcp.workspace import list_intended_roots
        roots = list_intended_roots(project_path)
        
        from .schemas import WorkspaceOutput
        envelope = {
            "ok": True,
            "action": "get",
            "result": {"intended_roots": roots},
            "metadata": {},
        }
        return make_tool_result(
            json.dumps(envelope, indent=2),
            WorkspaceOutput,
            structured_data=envelope,
        )
        
    except Exception as e:
        return handle_unhandled_exception(
            "workspace_get",
            e,
            {"project_path": str(project_path)}
        )


async def _handle_workspace_add(arguments: dict[str, Any], project_path) -> types.CallToolResult:
    """Handle workspace project addition."""
    try:
        # Convert to Pydantic model for validation
        from .schemas import ForgeWorkspaceInput
        validated = ForgeWorkspaceInput(**arguments)
        
        project_id = validated.project_id
        if not project_id:
            return handle_validation_error(
                "project_id",
                "project_id is required for add operation",
                {"available_parameters": ["project_id", "depends_on"]}
            )
        
        depends_on = validated.depends_on or []
        
        # Import workspace functionality
        try:
            from forge.tools.workspace_store import add_project
        except ImportError as e:
            from forge.core.errors import ERRORS, ForgeError
            base_error = ERRORS["dependency_unavailable"]
            error = ForgeError(
                code=base_error.code,
                layer=base_error.layer,
                message=base_error.message,
                hint=base_error.hint,
                recoverable=base_error.recoverable,
                context={
                    "missing_dependency": "forge.tools.workspace_store",
                    "import_error": str(e),
                    "project_path": str(project_path),
                }
            )
            return forge_error_result(error)
        
        result = add_project(project_id, depends_on)
        
        return make_tool_result(
            json.dumps(result, indent=2),
            None,  # TODO: Add WorkspaceOutput schema
            structured_data=result
        )
        
    except Exception as e:
        return handle_unhandled_exception(
            "workspace_add",
            e,
            {"project_path": str(project_path)}
        )


async def _handle_workspace_dependents(validated_input: ForgeWorkspaceInput, project_path) -> types.CallToolResult:
    """Handle workspace dependents query."""
    try:
        project_id = validate_project_id(validated_input.project_id)
        
        # Import workspace functionality
        try:
            from forge.tools.workspace_store import get_dependents
        except ImportError as e:
            from forge.core.errors import ERRORS, ForgeError
            base_error = ERRORS["dependency_unavailable"]
            error = ForgeError(
                code=base_error.code,
                layer=base_error.layer,
                message=base_error.message,
                hint=base_error.hint,
                recoverable=base_error.recoverable,
                context={
                    "missing_dependency": "forge.tools.workspace_store",
                    "import_error": str(e),
                    "project_path": str(project_path),
                }
            )
            return forge_error_result(error)
        
        result = get_dependents(project_id)
        
        from .schemas import WorkspaceOutput
        envelope = {
            "ok": True,
            "action": "dependents",
            "result": result if isinstance(result, dict) else {"data": result},
            "metadata": {"project_id": project_id},
        }
        return make_tool_result(
            json.dumps(envelope, indent=2),
            WorkspaceOutput,
            structured_data=envelope,
        )
        
    except ValueError as e:
        return handle_validation_error(
            "project_id",
            str(e),
            {"project_id": validated_input.project_id}
        )
    except Exception as e:
        return handle_unhandled_exception(
            "workspace_dependents",
            e,
            {"project_path": str(project_path)}
        )


async def _handle_workspace_dependencies(validated_input: ForgeWorkspaceInput, project_path) -> types.CallToolResult:
    """Handle workspace dependencies query."""
    try:
        project_id = validate_project_id(validated_input.project_id)
        
        # Import workspace functionality
        # Note: get_dependencies is not available as a standalone function in workspace_store
        # This functionality is available as a method on ForgeEntity instances in forge.core.forge_entity_system
        # For workspace-level dependencies, use forge_query with the depends_on relation
        from forge.core.errors import ERRORS, ForgeError, ErrorCode, ErrorLayer
        error = ForgeError(
            code=ErrorCode.DEPENDENCY_UNAVAILABLE,
            layer=ErrorLayer.EXECUTION,
            message="Workspace dependencies are not available as a standalone function",
            hint="Use forge_query with depends_on relation instead",
            recoverable=True,
            context={
                "feature": "workspace_dependencies",
                "project_id": project_id,
            }
        )
        return forge_error_result(error)
        
        return make_tool_result(
            json.dumps(result, indent=2),
            structured_data=result
        )
        
    except ValueError as e:
        return handle_validation_error(
            "project_id",
            str(e),
            {"project_id": validated_input.project_id}
        )
    except Exception as e:
        return handle_unhandled_exception(
            "workspace_dependencies",
            e,
            {"project_id": validated_input.project_id}
        )


async def handle_forge_session(arguments: dict[str, Any]) -> types.CallToolResult:
    """
    Session operations for Forge.
    
    Priority: P4 - System functionality
    """
    try:
        # Validate input using typed model
        try:
            path_res, gate = resolve_validated_project_path_result(arguments)
            if gate is not None:
                return gate
            merged = {**arguments, "project_path": str(path_res)}
            validated_input = ForgeSessionInput.model_validate(merged)
        except Exception as e:
            return handle_validation_error(
                "input_validation",
                f"Invalid input: {str(e)}",
                {"provided_arguments": arguments}
            )

        path = validate_project_path(str(validated_input.project_path))

        # Validate action parameter
        action = validated_input.action
        if not action:
            return handle_validation_error(
                "action",
                "action is required",
                {
                    "available_actions": [
                        "start",
                        "status",
                        "handoff",
                        "pause",
                        "get",
                        "phase_upsert (stub — CLI only)",
                        "phase_status (stub — CLI only)",
                    ]
                },
            )

        # Route to specific session operations
        if action == "start":
            return await _handle_session_start(validated_input, path)
        elif action == "status":
            return await _handle_session_status(validated_input, path)
        elif action == "handoff":
            return await _handle_session_handoff(validated_input, path)
        elif action == "pause":
            return await _handle_session_pause(validated_input, path)
        elif action == "phase_upsert":
            return await _handle_session_phase_upsert(validated_input, path)
        elif action == "phase_status":
            return await _handle_session_phase_status(validated_input, path)
        elif action == "get":
            return await _handle_session_get(validated_input, path)
        else:
            return handle_validation_error(
                "action",
                f"Invalid action: {action}",
                {"available_actions": ["start", "status", "handoff", "pause", "phase_upsert", "phase_status", "get"]}
            )
        
    except ValueError as e:
        return handle_validation_error(
            "action" if "action" in str(e) else "project_path",
            str(e),
            {
                "project_path": arguments.get("project_path", ""),
                "action": arguments.get("action"),
            }
        )
    except Exception as e:
        return handle_unhandled_exception(
            "forge_session",
            e,
            {
                "project_path": arguments.get("project_path", ""),
                "operation": "session_operation",
                "action": arguments.get("action"),
            }
        )


async def _handle_session_get(validated_input: ForgeSessionInput, project_path: Path) -> types.CallToolResult:
    """Handle session get operation."""
    try:
        from forge.mcp.session_file import read_mcp_session_active_project

        ap = read_mcp_session_active_project(cwd=project_path)
        if not ap:
            envelope = {
                "ok": False,
                "action": "get",
                "result": {"error": "No active session found"},
                "metadata": {"project_path": str(project_path)},
            }
            return make_tool_result(
                json.dumps(envelope, indent=2),
                SessionOutput,
                structured_data=envelope,
            )

        envelope = {
            "ok": True,
            "action": "get",
            "result": {"active_project": ap},
            "metadata": {"project_path": str(project_path)},
        }
        return make_tool_result(
            json.dumps(envelope, indent=2),
            SessionOutput,
            structured_data=envelope,
        )

    except Exception as e:
        return handle_unhandled_exception(
            "session_get",
            e,
            {"project_path": str(project_path)}
        )


async def _handle_session_start(validated_input: ForgeSessionInput, project_path: Path) -> types.CallToolResult:
    """Handle session start operation."""
    try:
        try:
            from forge.tools.audit.runtime import session_start
        except ImportError as e:
            error = get_error("dependency_unavailable")
            error.context.update({
                "missing_dependency": "forge.tools.audit.runtime",
                "import_error": str(e),
            })
            return forge_error_result(error)

        result = await asyncio.to_thread(
            lambda: session_start(
                str(project_path),
                (validated_input.branch or None) or None,
                (validated_input.session_label or None) or None,
            )
        )
        envelope = {
            "ok": True,
            "action": "start",
            "result": result,
            "metadata": {"project_path": str(project_path)},
        }
        return make_tool_result(
            json.dumps(envelope, indent=2),
            SessionOutput,
            structured_data=envelope,
        )

    except Exception as e:
        return handle_unhandled_exception(
            "session_start",
            e,
            {
                "project_path": str(project_path),
                "session_label": validated_input.session_label,
                "branch": validated_input.branch,
            }
        )


async def _handle_session_status(validated_input: ForgeSessionInput, project_path: Path) -> types.CallToolResult:
    """Handle session status operation."""
    try:
        def _load() -> tuple[str, dict[str, Any]]:
            return _resolve_session_state(project_path, validated_input.session_id)

        sid, state = await asyncio.to_thread(_load)
        envelope = {
            "ok": True,
            "action": "status",
            "result": {"session_id": sid, "state": state},
            "metadata": {"project_path": str(project_path)},
        }
        return make_tool_result(
            json.dumps(envelope, indent=2),
            SessionOutput,
            structured_data=envelope,
        )

    except ValueError as e:
        return handle_validation_error(
            "session_id",
            str(e),
            {"session_id": validated_input.session_id}
        )
    except Exception as e:
        return handle_unhandled_exception(
            "session_status",
            e,
            {
                "project_path": str(project_path),
                "session_id": validated_input.session_id,
            }
        )


async def _handle_session_handoff(validated_input: ForgeSessionInput, project_path: Path) -> types.CallToolResult:
    """Handle session handoff operation."""
    try:
        session_id = validate_session_id(validated_input.session_id)
        stopped_at = validated_input.stopped_at or ""
        next_action = validated_input.next_action or ""

        p = _session_events_dir(project_path) / f"{session_id}.yaml"
        if not p.is_file():
            return handle_validation_error(
                "session_id",
                f"session not found: {session_id}",
                {"session_id": session_id},
            )

        def _write() -> dict[str, Any]:
            data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
            if not isinstance(data, dict):
                data = {}
            data["status"] = "handed_off"
            if stopped_at:
                data["stopped_at"] = stopped_at
            if next_action:
                data["next_action"] = next_action
            p.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")
            return data

        data = await asyncio.to_thread(_write)
        envelope = {
            "ok": True,
            "action": "handoff",
            "result": {"session_id": session_id, **data},
            "metadata": {"project_path": str(project_path)},
        }
        return make_tool_result(
            json.dumps(envelope, indent=2),
            SessionOutput,
            structured_data=envelope,
        )

    except ValueError as e:
        return handle_validation_error(
            "session_id",
            str(e),
            {"session_id": validated_input.session_id}
        )
    except Exception as e:
        return handle_unhandled_exception(
            "session_handoff",
            e,
            {
                "project_path": str(project_path),
                "session_id": validated_input.session_id,
            }
        )


async def _handle_session_pause(validated_input: ForgeSessionInput, project_path: Path) -> types.CallToolResult:
    """Mark session state as paused in ``.forge/events``."""
    try:
        session_id = validate_session_id(validated_input.session_id)
        p = _session_events_dir(project_path) / f"{session_id}.yaml"
        if not p.is_file():
            return handle_validation_error(
                "session_id",
                f"session not found: {session_id}",
                {"session_id": session_id},
            )

        def _write() -> dict[str, Any]:
            data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
            if not isinstance(data, dict):
                data = {}
            data["status"] = "paused"
            p.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")
            return data

        data = await asyncio.to_thread(_write)
        envelope = {
            "ok": True,
            "action": "pause",
            "result": {"session_id": session_id, **data},
            "metadata": {"project_path": str(project_path)},
        }
        return make_tool_result(
            json.dumps(envelope, indent=2),
            SessionOutput,
            structured_data=envelope,
        )

    except ValueError as e:
        return handle_validation_error(
            "session_id",
            str(e),
            {"session_id": validated_input.session_id},
        )
    except Exception as e:
        return handle_unhandled_exception(
            "session_pause",
            e,
            {"project_path": str(project_path), "session_id": validated_input.session_id},
        )


async def _handle_session_phase_upsert(validated_input: ForgeSessionInput, project_path: Path) -> types.CallToolResult:
    """Phase upsert stub — EGMP phase graph is not persisted via MCP yet."""
    try:
        session_id = validate_session_id(validated_input.session_id)
        envelope = {
            "ok": True,
            "action": "phase_upsert",
            "stub": True,
            "result": {
                "session_id": session_id,
                "phase_id": validated_input.phase_id or "",
                "task_id": validated_input.task_id or "",
                "status": validated_input.status or "",
                "detail": (
                    "Not implemented over MCP. Use "
                    "`forge audit` phase commands in the CLI for persisted phase graphs."
                ),
            },
            "metadata": {"project_path": str(project_path)},
        }
        return make_tool_result(
            json.dumps(envelope, indent=2),
            SessionOutput,
            structured_data=envelope,
        )

    except ValueError as e:
        return handle_validation_error(
            "session_id",
            str(e),
            {
                "project_path": str(project_path),
                "session_id": validated_input.session_id,
                "phase_id": validated_input.phase_id,
                "task_id": validated_input.task_id,
            }
        )
    except Exception as e:
        return handle_unhandled_exception(
            "session_phase_upsert",
            e,
            {
                "project_path": str(project_path),
                "session_id": validated_input.session_id,
                "phase_id": validated_input.phase_id,
                "task_id": validated_input.task_id,
            }
        )


async def _handle_session_phase_status(validated_input: ForgeSessionInput, project_path: Path) -> types.CallToolResult:
    """Phase status stub — audit runtime does not expose phase_status to MCP yet."""
    try:
        session_id = validate_session_id(validated_input.session_id)
        envelope = {
            "ok": True,
            "action": "phase_status",
            "stub": True,
            "result": {
                "session_id": session_id,
                "detail": (
                    "Not implemented over MCP. Use "
                    "`forge audit phase-status` in the CLI for live phase state."
                ),
            },
            "metadata": {"project_path": str(project_path)},
        }
        return make_tool_result(
            json.dumps(envelope, indent=2),
            SessionOutput,
            structured_data=envelope,
        )

    except ValueError as e:
        return handle_validation_error(
            "session_id",
            str(e),
            {"session_id": validated_input.session_id},
        )
    except Exception as e:
        return handle_unhandled_exception(
            "session_phase_status",
            e,
            {"project_path": str(project_path), "session_id": validated_input.session_id},
        )
