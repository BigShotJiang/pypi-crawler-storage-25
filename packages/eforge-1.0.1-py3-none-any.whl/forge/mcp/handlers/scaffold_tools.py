"""Scaffold tools for Forge MCP handlers."""

from __future__ import annotations

import asyncio
import json
from typing import Any

import mcp.types as types
from forge.mcp.handlers.error_handlers import (
    make_tool_result,
    forge_error_result,
    handle_unhandled_exception,
    handle_validation_error,
)
from forge.mcp.handlers.validation import validate_project_path
from forge.mcp.project_resolution import resolve_validated_project_path_result
from forge.mcp.handlers.schemas import ScaffoldOutput, TemplateOutput


async def handle_forge_template(arguments: dict[str, Any]) -> types.CallToolResult:
    """Discover scaffold templates for a node kind and stack."""
    try:
        path, gate = resolve_validated_project_path_result(arguments)
        if gate is not None:
            return gate

        kind = str(arguments.get("kind") or "").strip()
        stack = str(arguments.get("stack") or "").strip()
        action = str(arguments.get("action") or "list").strip().lower()
        template_id = str(arguments.get("template_id") or "").strip()
        tier_filter = str(arguments.get("tier") or "").strip() or None

        from forge.tools.glove_templates.registry import (
            discover_templates,
            filter_templates,
            find_template_for_kind_stack,
            template_l1_row,
            templates_l0_payload,
        )

        if action == "show" or (kind and stack):
            hit = find_template_for_kind_stack(kind, stack) if kind and stack else None
            if hit is None and template_id:
                for _path, _tier, data in discover_templates():
                    if data and str(data.get("id") or "") == template_id:
                        hit = (_path, data)
                        break
            path_str, data = hit if hit else (None, None)
            row = template_l1_row(data) if data else None
            result = {
                "ok": bool(data),
                "action": "show",
                "kind": kind or None,
                "stack": stack or None,
                "template_id": template_id or (str(data.get("id")) if data else None),
                "template": row,
                "path": str(path_str) if path_str else None,
            }
        else:
            rows: list[dict[str, Any]] = []
            for _path, _tier, data in discover_templates():
                if data:
                    rows.append(dict(data))
            rows = filter_templates(rows, stack=stack or None, kind=kind or None, tier=tier_filter)
            l1_rows = [template_l1_row(r) for r in rows]
            result = {
                "ok": True,
                "action": action,
                "templates": l1_rows,
                "summary": templates_l0_payload(l1_rows),
            }

        return make_tool_result(
            json.dumps(result, indent=2),
            TemplateOutput,
            structured_data=result,
        )
    except Exception as e:
        return handle_unhandled_exception(
            "forge_template",
            e,
            {
                "project_path": arguments.get("project_path", ""),
                "operation": "template_discovery",
            },
        )


async def handle_forge_scaffold(arguments: dict[str, Any]) -> types.CallToolResult:
    """Scaffold generation via glove template instantiation."""
    try:
        path, gate = resolve_validated_project_path_result(arguments)
        if gate is not None:
            return gate

        exec_args = dict(arguments)
        exec_args["project_path"] = str(path)

        from forge.mcp.thin_core import execute_scaffold

        result = await asyncio.to_thread(lambda: execute_scaffold(exec_args))

        return make_tool_result(
            json.dumps(result, indent=2),
            ScaffoldOutput,
            structured_data=result,
        )

    except Exception as e:
        return handle_unhandled_exception(
            "forge_scaffold",
            e,
            {
                "project_path": arguments.get("project_path", ""),
                "operation": "scaffold_execution",
            },
        )

async def handle_forge_scaffold_thin(arguments: dict[str, Any]) -> types.CallToolResult:
    # DEPRECATED: broken — missing _cli_tool_wrapper,
    # _text_result, MetaChannel from old server.py.
    # forge_scaffold now routes through execute_scaffold
    # in thin_core. Do not register or call this.
    # Candidate for archive after astro session confirms
    # execute_scaffold path is stable.
    # Filter arguments to only include valid parameters
    ALLOWED_ARGS = {"intent_id", "node_type", "project_path", "output_path", "emit_spec", "dry_run"}
    filtered_args = {k: v for k, v in arguments.items() if k in ALLOWED_ARGS}
    
    if str(arguments.get("describe") or "").strip():
        return _text_result(
            "not supported - author intent records via Claude chat and forge intent add",
            is_error=True,
        )
    intent_id = str(filtered_args.get("intent_id") or "").strip()
    node_type = str(filtered_args.get("node_type") or "").strip()
    project_path = str(filtered_args.get("project_path") or ".").strip()
    project_resolved = str(_resolve_path(project_path))

    if not node_type or not intent_id:
        missing = []
        if not node_type:
            missing.append("node_type")
        if not intent_id:
            missing.append("intent_id")
        return _text_result(
            json.dumps({
                "error": f"Missing required parameters: {', '.join(missing)}",
                "details": "Both node_type and intent_id are required for scaffolding",
                "hint": "Use forge_intent action=add to create an intent record first, then reference it with intent_id",
                "valid_node_types": ["screen", "controller", "service", "model", "variant", "module"],
                "example": "forge_scaffold node_type='screen' intent_id='INTENT-12345678'",
                "workflow": "1. Create intent with forge_intent action=add, 2. Scaffold with forge_scaffold"
            }),
            is_error=True
        )
    from forge.mcp.server import get_current_mcp_context

    dry_run = bool(arguments.get("dry_run", False))
    ctx = get_current_mcp_context()
    elicitation_message = (
        f"scaffold will emit files for '{intent_id}'. "
        f"dry_run={dry_run}. Confirm?"
    )
    meta_channel = MetaChannel()
    meta_channel.add_ui(
        [
            UIComponent(
                kind=UIComponentKind.CONFIRMATION,
                title="Confirm: forge_scaffold",
                data={"summary": elicitation_message, "node_id": intent_id},
                actions=["confirm", "cancel"],
                requires_response=True,
            )
        ],
        layout="inline",
    )
    outcome, data = await _maybe_elicit_confirmation(
        ctx,
        message=elicitation_message,
        schema_cls=ScaffoldConfirmation,
    )
    if outcome == ElicitOutcome.DECLINED:
        payload = {"status": "cancelled", "reason": "user_declined", "dry_run": True}
        payload["_meta"] = {"elicitation": {"outcome": outcome.value, "schema": "ScaffoldConfirmation", "note": ""}}
        payload = meta_channel.attach(payload)
        return make_tool_result(json.dumps(payload), ScaffoldResult)
    if outcome == ElicitOutcome.UNSUPPORTED:
        dry_run = True
    elif outcome == ElicitOutcome.ERROR:
        payload = {"status": "cancelled", "reason": "elicitation_error", "dry_run": True}
        payload["_meta"] = {
            "elicitation": {
                "outcome": outcome.value,
                "schema": "ScaffoldConfirmation",
                "note": str(data or ""),
            }
        }
        payload = meta_channel.attach(payload)
        return make_tool_result(json.dumps(payload), ScaffoldResult, is_error=True)

    args_cli: dict[str, Any] = {**arguments, "project_path": project_resolved, "dry_run": dry_run}
    op2 = arguments.get("output_path")
    if op2 is not None and str(op2).strip():
        args_cli["output_path"] = str(Path(str(op2)).expanduser().resolve())
    tier = _response_tier(arguments, _default_tier_for_tool("forge_scaffold"))
    res = await _cli_tool_wrapper(
        args_cli, "scaffold", positional=["pipeline", node_type], skip={"node_type", "response_tier", "describe"}
    )
    if tier != "L0" or res.isError or not res.content:
        return res
    body = _try_parse_json_text(res.content[0].text or "")
    if not isinstance(body, dict):
        return res
    slim = _apply_response_tier("forge_scaffold", tier, body)
    project_id = str(body.get("project_id") or Path(project_resolved).name)
    _attach_resource_link(slim, "manifest_link", f"forge://project/{project_id}/manifest")
    scaffolded_node_id = str(
        body.get("node_id")
        or body.get("node")
        or slim.get("node_id")
        or ""
    ).strip()
    if scaffolded_node_id:
        await _post_scaffold_intent_confirmation(
            project_root=Path(project_resolved),
            node_id=scaffolded_node_id,
        )
    meta = slim.get("_meta") if isinstance(slim.get("_meta"), dict) else {}
    note = ""
    if outcome == ElicitOutcome.UNSUPPORTED:
        note = "Client does not support elicitation. Proceeding with dry_run=True as safety default."
    meta["elicitation"] = {"outcome": outcome.value, "schema": "ScaffoldConfirmation", "note": note}
    slim["_meta"] = meta
    slim = meta_channel.attach(slim)
    return make_tool_result(json.dumps(slim, indent=2), ScaffoldResult)
