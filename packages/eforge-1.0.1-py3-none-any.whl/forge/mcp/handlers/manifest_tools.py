"""Manifest-related tool handlers for Forge MCP.

Includes manifest operations, node management, and related functionality.
"""

from __future__ import annotations

import asyncio
import dataclasses
import json
from typing import Any

import mcp.types as types
from forge.mcp.handlers.error_handlers import (
    make_tool_result,
    forge_error_result,
    handle_unhandled_exception,
    handle_validation_error,
)
from forge.mcp.handlers.validation import (
    validate_project_path,
    validate_node_id,
)
from forge.mcp.project_resolution import resolve_validated_project_path_result


async def handle_forge_manifest_append(arguments: dict[str, Any]) -> types.CallToolResult:
    """
    Append validated module nodes to .forge/manifest.yaml with manifest system awareness.
    
    Priority: P3 - Core manifest operation
    """
    nodes: list = []
    dry_run = False
    validation_results: dict = {}
    try:
        # Validate input using typed model
        from .schemas import ForgeManifestAppendInput
        try:
            path, gate = resolve_validated_project_path_result(arguments)
            if gate is not None:
                return gate
            merged = {**arguments, "project_path": str(path)}
            validated_input = ForgeManifestAppendInput.model_validate(merged)
        except Exception as e:
            return handle_validation_error(
                "input_validation",
                f"Invalid input: {str(e)}",
                {"provided_arguments": arguments}
            )
        
        path = validate_project_path(str(validated_input.project_path))
        
        # Validate nodes parameter
        nodes = validated_input.nodes
        dry_run = bool(validated_input.dry_run)
        if not nodes:
            if dry_run:
                from .schemas import ManifestAppendOutput
                envelope = {
                    "ok": True,
                    "project": path.name,
                    "project_path": str(path),
                    "append_result": {
                        "dry_run": True,
                        "message": "no nodes supplied — nothing to preview or apply",
                    },
                    "metadata": {
                        "nodes_count": 0,
                        "dry_run": True,
                        "validation_results": {},
                    },
                }
                return make_tool_result(
                    json.dumps(envelope, indent=2),
                    ManifestAppendOutput,
                    structured_data=envelope,
                )
            return handle_validation_error(
                "nodes",
                "nodes list is required",
                {"provided_nodes": nodes}
            )
        
        # Import manifest functionality with proper error handling
        try:
            from forge.mcp.thin_core import execute_manifest_append
        except ImportError as e:
            from forge.core.errors import ERRORS, ForgeError
            base_error = ERRORS["dependency_unavailable"]
            error = ForgeError(
                code=base_error.code,
                layer=base_error.layer,
                message=base_error.message,
                hint=base_error.hint,
                recoverable=base_error.recoverable,
                context={
                    "missing_dependency": "forge.tools.manifest.append",
                    "import_error": str(e),
                    "project_path": str(path),
                }
            )
            return forge_error_result(error)
        
        # Pre-append validation (lightweight by default)
        validation_results = {}
        if validated_input.validate_graph:
            try:
                # Lightweight graph validation only
                from forge.manifest import validate_manifest_graph
                graph_validation = await asyncio.to_thread(lambda: validate_manifest_graph(str(path)))
                validation_results["graph_validation"] = graph_validation
            except Exception as e:
                validation_results["graph_validation"] = {
                    "ok": False,
                    "error": str(e),
                    "message": "Lightweight graph validation failed"
                }
        
        if validated_input.check_dependencies:
            try:
                # Lightweight dependency check only
                from forge.manifest import check_node_dependencies
                dep_check = await asyncio.to_thread(lambda: check_node_dependencies(nodes, str(path)))
                validation_results["dependency_check"] = dep_check
            except Exception as e:
                validation_results["dependency_check"] = {
                    "ok": False,
                    "error": str(e),
                    "message": "Lightweight dependency check failed"
                }
        
        # Execute manifest append
        try:
            result = await asyncio.to_thread(lambda: execute_manifest_append({
                "project_path": str(path),
                "nodes": nodes,
                "dry_run": dry_run,
            }))
        except Exception as e:
            return handle_unhandled_exception(
                "forge_manifest_append",
                e,
                {
                    "project_path": str(path),
                    "operation": "manifest_append_execution",
                    "nodes_count": len(nodes),
                    "validation_results": validation_results,
                    "dry_run": dry_run,
                }
            )
        
        # Add validation results to output
        slim = {k: v for k, v in result.items() if k not in ("project", "project_path")}
        envelope = {
            "ok": bool(result.get("ok", True)),
            "project": path.name,
            "project_path": str(path),
            "append_result": slim,
            "metadata": {
                "nodes_count": len(nodes),
                "validation_results": validation_results,
                "dry_run": dry_run,
            },
        }
        from .schemas import ManifestAppendOutput
        return make_tool_result(
            json.dumps({**result, "project": path.name, "project_path": str(path)}, indent=2),
            ManifestAppendOutput,
            structured_data=envelope,
        )
        
    except ValueError as e:
        return handle_validation_error(
            "project_path",
            str(e),
            {"project_path": arguments.get("project_path", "")}
        )
    except FileNotFoundError as e:
        from forge.core.errors import ERRORS, ForgeError
        base_error = ERRORS["manifest_not_found"]
        error = ForgeError(
            code=base_error.code,
            layer=base_error.layer,
            message=base_error.message,
            hint=base_error.hint,
            recoverable=base_error.recoverable,
            context={
                "project_path": arguments.get("project_path", ""),
                "file_error": str(e),
            }
        )
        return forge_error_result(error)
    except ImportError as e:
        from forge.core.errors import ERRORS, ForgeError
        base_error = ERRORS["dependency_unavailable"]
        error = ForgeError(
            code=base_error.code,
            layer=base_error.layer,
            message=base_error.message,
            hint=base_error.hint,
            recoverable=base_error.recoverable,
            context={
                "missing_dependency": "forge.tools.manifest.append",
                "import_error": str(e),
                "project_path": arguments.get("project_path", ""),
            }
        )
        return forge_error_result(error)
    except Exception as e:
        return handle_unhandled_exception(
            "forge_manifest_append",
            e,
            {
                "project_path": arguments.get("project_path", ""),
                "operation": "manifest_append_execution",
                "nodes_count": len(nodes),
                "validation_results": validation_results,
                "dry_run": dry_run,
            }
        )


async def handle_forge_search(arguments: dict[str, Any]) -> types.CallToolResult:
    """Deprecated surface — delegates to forge_inspect action=search.

    Use forge_inspect directly instead.
    """
    mapped = dict(arguments)
    mapped["action"] = "search"
    if "query" in mapped and "node_id" not in mapped:
        mapped["node_id"] = mapped["query"]
    return await handle_forge_inspect(mapped)


async def handle_forge_query(arguments: dict[str, Any]) -> types.CallToolResult:
    """
    Query the manifest graph.
    
    Priority: P3 - Core query functionality
    """
    try:
        path, gate = resolve_validated_project_path_result(dict(arguments))
        if gate is not None:
            return gate

        try:
            from forge.mcp.thin_core import run_query_payload
        except ImportError as e:
            from forge.core.errors import ERRORS
            template = ERRORS["dependency_unavailable"]
            error = dataclasses.replace(template, context={
                "missing_dependency": "forge.mcp.thin_core",
                "import_error": str(e),
            })
            return forge_error_result(error)

        name = arguments.get("name") or ""
        node_id = arguments.get("node_id")
        if node_id and not name:
            name = str(node_id)

        query_payload = await asyncio.to_thread(
            lambda: run_query_payload(
                {
                    "project_path": str(path),
                    "kind": str(arguments.get("kind") or ""),
                    "domain": str(arguments.get("domain") or ""),
                    "name": str(name),
                    "depends_on": str(arguments.get("depends_on") or ""),
                    "via": arguments.get("via"),
                    "limit": int(arguments.get("limit", 50)),
                    "depth": int(arguments.get("depth", 1)),
                    "direction": str(arguments.get("direction") or "both"),
                    "sort_by": arguments.get("sort_by"),
                    "tier": arguments.get("tier"),
                    "expand_relevant": arguments.get("expand_relevant"),
                    "expand_domain": arguments.get("expand_domain"),
                    "expand_max_total": arguments.get("expand_max_total"),
                }
            )
        )

        raw_nodes = list(query_payload.get("nodes") or [])
        from forge.mcp.handlers.mapping_tools import _to_forge_node_output
        from .schemas import QueryOutput

        node_outputs = [_to_forge_node_output(n) for n in raw_nodes]
        filters_applied = {
            "tier": arguments.get("tier"),
            "domain": arguments.get("domain"),
            "name": name or None,
            "kind": arguments.get("kind"),
            "limit": arguments.get("limit", 50),
            "node_id": node_id,
            "status": arguments.get("status"),
            "depends_on": arguments.get("depends_on"),
            "via": arguments.get("via"),
        }

        result = {
            "ok": True,
            "project": path.name,
            "project_path": str(path),
            "query_result": query_payload,
            "nodes": node_outputs,
            "total": query_payload.get("count", len(node_outputs)),
            "filters_applied": filters_applied,
            "metadata": {
                "query_time": "success",
                "entity_count": len(node_outputs),
                "engine_based": True,
            },
        }
        
        return make_tool_result(
            json.dumps(result, indent=2),
            QueryOutput,  # Use structured validation with new schema
            structured_data=result
        )
        
    except ValueError as e:
        return handle_validation_error(
            "project_path",
            str(e),
            {"project_path": arguments.get("project_path", "")}
        )
    except FileNotFoundError as e:
        from forge.core.errors import ERRORS
        template = ERRORS["manifest_not_found"]
        error = dataclasses.replace(template, context={
            "project_path": arguments.get("project_path", ""),
            "file_error": str(e),
        })
        return forge_error_result(error)
    except ImportError as e:
        from forge.core.errors import ERRORS
        template = ERRORS["dependency_unavailable"]
        error = dataclasses.replace(template, context={
            "missing_dependency": "forge.mcp.thin_core",
            "import_error": str(e),
        })
        return forge_error_result(error)
    except Exception as e:
        return handle_unhandled_exception(
            "forge_query",
            e,
            {
                "project_path": arguments.get("project_path", ""),
                "operation": "graph_query",
            }
        )


async def handle_forge_discover(arguments: dict[str, Any]) -> types.CallToolResult:
    """Discover untracked source files not declared in manifest.yaml.

    Stack-agnostic — auto-detects python, web, astro, dart.

    Non-mutating: returns suggestions only. Pass results to forge_manifest_append
    to declare them.
    """
    try:
        path, gate = resolve_validated_project_path_result(arguments)
        if gate is not None:
            return gate
        exec_args = dict(arguments)
        exec_args["project_path"] = str(path)
        from forge.mcp.thin_core import execute_discover

        result = await asyncio.to_thread(lambda: execute_discover(exec_args))
        return make_tool_result(
            json.dumps(result, indent=2),
            None,
            structured_data=result,
        )
    except Exception as e:
        return handle_unhandled_exception(
            "forge_discover",
            e,
            {"project_path": arguments.get("project_path", "")},
        )


async def handle_forge_inspect(arguments: dict[str, Any]) -> types.CallToolResult:
    """Progressive graph inspection and navigation.

    Single tool, action-based: node, expand, select, diff, packet, search.
    Always returns available_actions — the tool teaches the agent what to do next.
    """
    try:
        path, gate = resolve_validated_project_path_result(arguments)
        if gate is not None:
            return gate
        exec_args = dict(arguments)
        exec_args["project_path"] = str(path)
        from forge.mcp.thin_core import execute_inspect

        result = await asyncio.to_thread(lambda: execute_inspect(exec_args))
        action = str(exec_args.get("action") or "node")
        node_id = str(exec_args.get("node_id") or "").strip()
        if (
            action in ("node", "search")
            and node_id
            and result.get("ok")
            and result.get("node") is None
        ):
            from forge.mcp.handlers.error_handlers import graph_node_not_found_result

            return graph_node_not_found_result(
                result.get("node_id") or node_id,
                source_tool="forge_inspect",
                message=f"Manifest node not found: {node_id!r}",
            )
        if result.get("error") and "node_id required" in str(result.get("error", "")):
            from forge.mcp.handlers.error_handlers import handle_validation_error

            return handle_validation_error("node_id", str(result["error"]))
        if (
            action == "expand"
            and not result.get("ok")
            and "Cursor" in str(result.get("error", ""))
        ):
            from forge.core.errors import get_error
            from forge.mcp.handlers.error_handlers import forge_error_result

            err = get_error("cursor_expired")
            err.context.update(result)
            return forge_error_result(err)
        return make_tool_result(
            json.dumps(result, indent=2),
            None,
            structured_data=result,
        )
    except Exception as e:
        return handle_unhandled_exception(
            "forge_inspect",
            e,
            {
                "project_path": str(arguments.get("project_path", "")),
                "action": arguments.get("action", "node"),
            },
        )
