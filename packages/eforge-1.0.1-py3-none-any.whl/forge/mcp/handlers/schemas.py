"""Output schemas for Forge MCP handlers.

Provides structured output schemas for stable tools to ensure
MCP compliance and proper response formatting.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, ConfigDict, Field

from forge.core.schemas import (
    ForgeAnnotateInput as ForgeAnnotateInput,
    ForgeAuditScanInput as ForgeAuditScanInput,
    ForgeBlastRadiusInput as ForgeBlastRadiusInput,
    ForgeConfigGetInput as ForgeConfigGetInput,
    ForgeConfigSetInput as ForgeConfigSetInput,
    ForgeImpactRadiusInput as ForgeImpactRadiusInput,
    ForgeImpactRadiusOutput as ForgeImpactRadiusOutput,
    ForgeNodeOutput as ForgeNodeOutput,
    ForgeManifestAppendInput as ForgeManifestAppendInput,
    ForgeOrientInput as ForgeOrientInput,
    ForgeQueryInput as ForgeQueryInput,
    ForgeScaffoldInput as ForgeScaffoldInput,
    ForgeSearchInput as ForgeSearchInput,
    ForgeDiscoverInput as ForgeDiscoverInput,
    ForgeInspectInput as ForgeInspectInput,
    ForgeTraceInput as ForgeTraceInput,
    ForgeTemplateInput as ForgeTemplateInput,
    ForgeSessionInput as ForgeSessionInput,
    ForgeWorkspaceInput as ForgeWorkspaceInput,
    IntentResult,
)


class HealthVectorOutput(BaseModel):
    """MCP wire wrapper for ForgeHealthVectorOutput. Adds ok flag and project metadata."""
    ok: bool = Field(description="Whether the health vector computation succeeded")
    project: str = Field(description="Project name")
    project_path: str = Field(description="Absolute path to project")
    health_vector: Dict[str, Any] = Field(description="Health vector data")
    adi: Dict[str, Any] = Field(description="ADI metrics")
    brc: Dict[str, Any] = Field(description="BRC metrics")
    idr: Dict[str, Any] = Field(description="IDR metrics")
    pos: Dict[str, Any] = Field(description="POS metrics")
    metadata: Dict[str, Any] = Field(description="Computation metadata")


class ProjectStatusOutput(BaseModel):
    """Output schema for forge_project_status."""
    ok: bool = Field(description="Whether project status computation succeeded")
    project: str = Field(description="Project name")
    project_path: str = Field(description="Absolute path to project")
    status: Dict[str, Any] = Field(description="Project status information")
    metadata: Dict[str, Any] = Field(description="Status computation metadata")


class VerifyOutput(BaseModel):
    """MCP wire wrapper for VerifyResult. Adds ok flag, project metadata, and response_tier."""
    ok: bool = Field(description="Whether verification succeeded")
    project: str = Field(description="Project name")
    project_path: str = Field(description="Absolute path to project")
    verification_result: Dict[str, Any] = Field(description="Verification results")
    response_tier: str = Field(description="Response tier used")
    metadata: Dict[str, Any] = Field(description="Verification metadata")
    exit_code: Optional[int] = Field(
        default=None,
        description="Structural verify exit code (0/1/2); duplicated at top level for JSON consumers",
    )


class OrientOutput(BaseModel):
    """MCP wire wrapper for OrientResult. Adds ok flag, project metadata, and orientation_result blob."""

    model_config = ConfigDict(extra="allow")

    ok: bool = Field(description="Whether orientation succeeded")
    project: str = Field(description="Project name")
    project_path: str = Field(description="Absolute path to project")
    orientation_result: Dict[str, Any] = Field(description="Orientation results")
    metadata: Dict[str, Any] = Field(description="Orientation metadata")


class AuditScanOutput(BaseModel):
    """MCP wire wrapper for AuditScanResult. Adds ok flag, project metadata, and scan_result blob."""
    ok: bool = Field(description="Whether audit scan succeeded")
    project: str = Field(description="Project name")
    project_path: str = Field(description="Absolute path to project")
    scan_result: Dict[str, Any] = Field(description="Audit scan results")
    metadata: Dict[str, Any] = Field(description="Scan metadata")


class ForgeBasicProjectInput(BaseModel):
    """Basic input schema for tools that only need project_path."""
    project_path: Optional[str] = Field(default=None, description="Path to Forge project")


class AnnotateOutput(BaseModel):
    """Output schema for forge_annotate."""
    ok: bool = Field(description="Whether annotation operation succeeded")
    project: str = Field(description="Project name")
    project_path: str = Field(description="Absolute path to project")
    action: str = Field(description="Annotation action performed")
    result: Dict[str, Any] = Field(description="Annotation operation result")
    metadata: Dict[str, Any] = Field(description="Operation metadata")


class ManifestAppendOutput(BaseModel):
    """Output schema for forge_manifest_append."""

    model_config = ConfigDict(extra="allow")

    ok: bool = Field(description="Whether manifest append succeeded")
    project: str = Field(description="Project name")
    project_path: str = Field(description="Absolute path to project")
    append_result: Dict[str, Any] = Field(
        default_factory=dict,
        description="Manifest append results",
    )
    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="Append metadata",
    )


class QueryOutput(BaseModel):
    """Output schema for forge_query."""

    ok: bool = Field(description="Whether query succeeded")
    project: str = Field(description="Project name")
    project_path: str = Field(description="Absolute path to project")
    query_result: Dict[str, Any] = Field(description="Graph query results")
    metadata: Dict[str, Any] = Field(description="Query metadata")
    nodes: Optional[List[Dict[str, Any]]] = Field(
        default=None,
        description="Optional typed node summaries (parallel to query_result.nodes)",
    )
    total: Optional[int] = Field(
        default=None,
        description="Result count (mirror of query_result.count when present)",
    )
    filters_applied: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Echo of filters applied for this MCP call",
    )


class AnnotationResult(BaseModel):
    """Result model for annotation operations."""
    ok: bool = Field(description="Whether the operation succeeded")
    result: Optional[Any] = Field(default=None, description="Operation result if successful")
    error: Optional[str] = Field(default=None, description="Error message if failed")
    meta: Dict[str, Any] = Field(default_factory=dict, description="Metadata")


class AnnotationCreateResult(BaseModel):
    """Result model for annotation create operations."""
    ok: bool = Field(description="Whether the operation succeeded")
    annotation_id: Optional[str] = Field(default=None, description="Created annotation ID")
    annotation: Optional[Dict[str, Any]] = Field(default=None, description="Created annotation data")
    meta: Dict[str, Any] = Field(default_factory=dict, description="Metadata")


class WorkspaceOutput(BaseModel):
    """Output schema for forge_workspace."""
    ok: bool = Field(description="Whether workspace operation succeeded")
    action: str = Field(description="Workspace action performed")
    result: Dict[str, Any] = Field(description="Workspace operation result")
    metadata: Dict[str, Any] = Field(description="Operation metadata")


class SessionOutput(BaseModel):
    """Output schema for forge_session."""
    ok: bool = Field(description="Whether session operation succeeded")
    action: str = Field(description="Session action performed")
    result: Dict[str, Any] = Field(description="Session operation result")
    metadata: Dict[str, Any] = Field(description="Operation metadata")


# ---------------------------------------------------------------------------
# Output models for tools not yet in OUTPUT_SCHEMAS
# ---------------------------------------------------------------------------

class ImpactCheckOutput(BaseModel):
    """MCP wire wrapper for ImpactCheckResult. Adds ok flag, project metadata, and summary blob."""

    ok: bool
    project: str
    project_path: str
    summary: Dict[str, Any] = Field(default_factory=dict)

class ConfigGetOutput(BaseModel):
    key: str
    value: Any = None

class ConfigSetOutput(BaseModel):
    model_config = ConfigDict(extra="allow")

    ok: bool = True
    key: str
    value: Any = None
    updated: bool = False
    dry_run: bool = False
    project: str = ""
    project_path: str = ""
    config_path: str = ""

class ScaffoldOutput(BaseModel):
    model_config = ConfigDict(extra="allow")

    ok: bool = True
    status: str = "ok"
    node: str = ""


class TemplateOutput(BaseModel):
    model_config = ConfigDict(extra="allow")

    ok: bool
    action: str = "list"
    templates: list[dict[str, Any]] = Field(default_factory=list)
    template: Optional[dict[str, Any]] = None
    kind: Optional[str] = None
    stack: Optional[str] = None


class SearchOutput(BaseModel):
    model_config = ConfigDict(extra="allow")

    ok: bool
    query: Optional[str] = None
    count: int = 0
    nodes: list[dict[str, Any]] = Field(default_factory=list)
    hint: Optional[str] = None

class PacketAssembleOutput(BaseModel):
    model_config = ConfigDict(extra="allow")

    ok: bool
    packet_path: str
    node: str = ""

class BlastRadiusOutput(BaseModel):
    """Blast radius uses ForgeNodeOutput for typed node lists."""
    ok: bool
    project: str
    node: str = Field(description="Target node analyzed")
    watchers: List[ForgeNodeOutput] = Field(default_factory=list)
    dependents: List[ForgeNodeOutput] = Field(default_factory=list)
    depth: int = 2

class MapOutput(BaseModel):
    ok: bool
    project: str
    nodes: List[ForgeNodeOutput] = Field(default_factory=list)
    edges: List[Dict[str, Any]] = Field(default_factory=list)

class TraceOutput(BaseModel):
    ok: bool
    project: str
    path: List[ForgeNodeOutput] = Field(default_factory=list)
    from_node: str = ""
    to_node: str = ""

class ReportOutput(BaseModel):
    ok: bool
    project: str
    summary: str = ""
    sections: List[Dict[str, Any]] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Corrected OUTPUT_SCHEMAS — single source of truth
# ---------------------------------------------------------------------------

OUTPUT_SCHEMAS = {
    "forge_health_vector":   HealthVectorOutput,
    "forge_verify":          VerifyOutput,
    "forge_orient":          OrientOutput,
    "forge_audit_scan":      AuditScanOutput,
    "forge_annotate":        AnnotateOutput,
    "forge_manifest_append": ManifestAppendOutput,
    "forge_query":           QueryOutput,
    "forge_search":          SearchOutput,
    "forge_intent":          IntentResult,
    "forge_workspace":       WorkspaceOutput,
    "forge_session":         SessionOutput,
    "forge_impact_radius":   ForgeImpactRadiusOutput,
    "forge_config_get":      ConfigGetOutput,
    "forge_config_set":      ConfigSetOutput,
    "forge_scaffold":        ScaffoldOutput,
    "forge_template":        TemplateOutput,
    "forge_packet_assemble": PacketAssembleOutput,
    "forge_map":             MapOutput,
    "forge_trace":           TraceOutput,
}


# ---------------------------------------------------------------------------
# Corrected INPUT_SCHEMAS — deduplicated, forge_pipeline/invoke added
# ---------------------------------------------------------------------------

INPUT_SCHEMAS = {
    "forge_orient":          ForgeOrientInput,
    "forge_audit_scan":      ForgeAuditScanInput,
    "forge_annotate":        ForgeAnnotateInput,
    "forge_manifest_append": ForgeManifestAppendInput,
    "forge_workspace":       ForgeWorkspaceInput,
    "forge_session":         ForgeSessionInput,
    "forge_health_vector":   ForgeBasicProjectInput,
    "forge_verify":          ForgeBasicProjectInput,
    "forge_query":           ForgeQueryInput,
    "forge_search":          ForgeSearchInput,
    "forge_discover":        ForgeDiscoverInput,
    "forge_inspect":         ForgeInspectInput,
    "forge_intent":          ForgeBasicProjectInput,
    "forge_impact_radius":   ForgeImpactRadiusInput,
    "forge_config_get":      ForgeConfigGetInput,
    "forge_config_set":      ForgeConfigSetInput,
    "forge_scaffold":        ForgeScaffoldInput,
    "forge_template":        ForgeTemplateInput,
    "forge_packet_assemble": ForgeBasicProjectInput,
    "forge_map":             ForgeBasicProjectInput,
    "forge_trace":           ForgeTraceInput,
    "forge_pipeline":        ForgeBasicProjectInput,
    "forge_invoke":          ForgeBasicProjectInput,
}


def get_output_schema(tool_name: str) -> Optional[type]:
    """Get output schema class for a tool name."""
    return OUTPUT_SCHEMAS.get(tool_name)


def get_input_schema(tool_name: str) -> Optional[type]:
    """Get input schema class for a tool name."""
    return INPUT_SCHEMAS.get(tool_name)


def validate_output(tool_name: str, data: Dict[str, Any]) -> Optional[BaseModel]:
    """Validate output data against tool schema. Bridge: dict → typed entity."""
    schema = get_output_schema(tool_name)
    if schema:
        try:
            return schema.model_validate(data)
        except Exception:
            return None
    return None
