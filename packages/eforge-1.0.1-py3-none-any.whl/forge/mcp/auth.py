"""API key authentication for INTENT-2F54177D Security model.

Provides API key authentication for MCP server with configurable keys,
rate limiting, and secure key storage.
"""

import hashlib
import hmac
import secrets
import time
from typing import Dict, Optional, List, Tuple
from dataclasses import dataclass, asdict
from pathlib import Path
import json
import os


@dataclass
class APIKey:
    """Represents an API key with metadata."""
    key_id: str
    key_hash: str  # SHA-256 hash of the actual key
    name: str
    created_at: float
    last_used: Optional[float] = None
    usage_count: int = 0
    rate_limit: int = 1000  # requests per hour
    rate_limit_reset: float = 0.0
    current_requests: int = 0


@dataclass
class AuthResult:
    """Result of an authentication attempt."""
    success: bool
    key_id: Optional[str] = None
    error: Optional[str] = None
    rate_limited: bool = False
    rate_limit_remaining: int = 0


class APIKeyAuth:
    """API key authentication system for MCP server."""
    
    def __init__(self, config_file: Optional[Path] = None):
        """
        Initialize API key authentication.
        
        Args:
            config_file: Path to API keys configuration file
        """
        self.config_file = config_file or Path.home() / ".forge" / "api_keys.json"
        self.keys: Dict[str, APIKey] = {}
        self._load_keys()
    
    def _load_keys(self) -> None:
        """Load API keys from configuration file."""
        if not self.config_file.exists():
            # Create default config file with a sample key
            self._create_default_config()
            return
        
        try:
            with open(self.config_file, 'r') as f:
                data = json.load(f)
            
            for key_data in data.get('keys', []):
                api_key = APIKey(**key_data)
                self.keys[api_key.key_id] = api_key
        
        except (json.JSONDecodeError, KeyError, TypeError):
            # If config is corrupted, create new default
            self._create_default_config()
    
    def _save_keys(self) -> None:
        """Save API keys to configuration file."""
        self.config_file.parent.mkdir(parents=True, exist_ok=True)
        
        data = {
            'keys': [asdict(key) for key in self.keys.values()]
        }
        
        with open(self.config_file, 'w') as f:
            json.dump(data, f, indent=2)
        
        # Set secure permissions
        os.chmod(self.config_file, 0o600)
    
    def _create_default_config(self) -> None:
        """Create default configuration with a sample API key."""
        sample_key = self.generate_key("sample-key", rate_limit=100)
        print(f"Generated sample API key: {sample_key}")
        print("Add this to your MCP client configuration to test authentication.")
    
    def _hash_key(self, key: str) -> str:
        """Hash an API key using SHA-256."""
        return hashlib.sha256(key.encode()).hexdigest()
    
    def generate_key(self, name: str, rate_limit: int = 1000) -> str:
        """
        Generate a new API key.
        
        Args:
            name: Human-readable name for the key
            rate_limit: Rate limit in requests per hour
            
        Returns:
            The generated API key
        """
        # Generate a cryptographically secure random key
        key = f"forge_{secrets.token_urlsafe(32)}"
        key_hash = self._hash_key(key)
        
        api_key = APIKey(
            key_id=f"key_{len(self.keys) + 1:04d}",
            key_hash=key_hash,
            name=name,
            created_at=time.time(),
            rate_limit=rate_limit
        )
        
        self.keys[api_key.key_id] = api_key
        self._save_keys()
        
        return key
    
    def authenticate(self, key: str) -> AuthResult:
        """
        Authenticate an API key.
        
        Args:
            key: The API key to authenticate
            
        Returns:
            Authentication result
        """
        if not key:
            return AuthResult(success=False, error="No API key provided")
        
        key_hash = self._hash_key(key)
        
        # Find matching key
        api_key = None
        for stored_key in self.keys.values():
            if hmac.compare_digest(stored_key.key_hash, key_hash):
                api_key = stored_key
                break
        
        if not api_key:
            return AuthResult(success=False, error="Invalid API key")
        
        # Check rate limiting
        current_time = time.time()
        
        # Reset rate limit if needed (hourly reset)
        if current_time - api_key.rate_limit_reset > 3600:
            api_key.rate_limit_reset = current_time
            api_key.current_requests = 0
        
        # Check if rate limited
        if api_key.current_requests >= api_key.rate_limit:
            return AuthResult(
                success=False,
                key_id=api_key.key_id,
                error="Rate limit exceeded",
                rate_limited=True,
                rate_limit_remaining=0
            )
        
        # Update usage statistics
        api_key.last_used = current_time
        api_key.usage_count += 1
        api_key.current_requests += 1
        
        # Save updated key data
        self._save_keys()
        
        return AuthResult(
            success=True,
            key_id=api_key.key_id,
            rate_limit_remaining=api_key.rate_limit - api_key.current_requests
        )
    
    def revoke_key(self, key_id: str) -> bool:
        """
        Revoke an API key.
        
        Args:
            key_id: The ID of the key to revoke
            
        Returns:
            True if key was revoked, False if not found
        """
        if key_id in self.keys:
            del self.keys[key_id]
            self._save_keys()
            return True
        return False
    
    def list_keys(self) -> List[Dict]:
        """
        List all API keys (without sensitive data).
        
        Returns:
            List of API key information
        """
        return [
            {
                'key_id': key.key_id,
                'name': key.name,
                'created_at': key.created_at,
                'last_used': key.last_used,
                'usage_count': key.usage_count,
                'rate_limit': key.rate_limit,
                'current_requests': key.current_requests
            }
            for key in self.keys.values()
        ]
    
    def get_key_info(self, key_id: str) -> Optional[Dict]:
        """
        Get information about a specific API key.
        
        Args:
            key_id: The ID of the key
            
        Returns:
            Key information or None if not found
        """
        if key_id not in self.keys:
            return None
        
        key = self.keys[key_id]
        return {
            'key_id': key.key_id,
            'name': key.name,
            'created_at': key.created_at,
            'last_used': key.last_used,
            'usage_count': key.usage_count,
            'rate_limit': key.rate_limit,
            'current_requests': key.current_requests
        }
    
    def validate_config(self) -> List[str]:
        """
        Validate the authentication configuration.
        
        Returns:
            List of validation errors (empty if valid)
        """
        errors = []
        
        # Check config file permissions
        if self.config_file.exists():
            stat = self.config_file.stat()
            if stat.st_mode & 0o077:  # Check if others have read/write permissions
                errors.append("API key file has insecure permissions")
        
        # Check if keys exist
        if not self.keys:
            errors.append("No API keys configured")
        
        # Check for keys with weak rate limits
        for key in self.keys.values():
            if key.rate_limit > 10000:
                errors.append(f"Key {key.key_id} has very high rate limit")
        
        return errors


# Global authentication instance
_auth_instance: Optional[APIKeyAuth] = None


def get_auth_instance() -> APIKeyAuth:
    """Get the global authentication instance."""
    global _auth_instance
    if _auth_instance is None:
        _auth_instance = APIKeyAuth()
    return _auth_instance


def authenticate_request(api_key: Optional[str]) -> AuthResult:
    """
    Authenticate a request with an API key.
    
    Args:
        api_key: The API key from the request
        
    Returns:
        Authentication result
    """
    auth = get_auth_instance()
    
    if not api_key:
        return AuthResult(success=False, error="API key required")
    
    return auth.authenticate(api_key)


def require_auth(func):
    """Decorator to require API key authentication for a function."""
    def wrapper(*args, **kwargs):
        # Extract API key from kwargs or headers
        api_key = kwargs.get('api_key') or kwargs.get('headers', {}).get('X-API-Key')
        
        result = authenticate_request(api_key)
        if not result.success:
            raise PermissionError(result.error or "Authentication failed")
        
        return func(*args, **kwargs)
    
    return wrapper
