"""MCP resource handlers for the event log system.

Provides forge://events resource surface for querying and accessing event data.
"""

import json
import logging
from typing import Any, Dict, List, Optional

from forge.core.event_log import get_event_log, EventType, EventEntry
from forge.core.path_utils import resolve_project_path

logger = logging.getLogger(__name__)


def read_event_log_resource(uri: str) -> str:
    """Read event log resource based on URI."""
    try:
        # Parse URI: forge://events/{query_type}?{params}
        if not uri.startswith("forge://events/"):
            raise ValueError(f"Invalid event log URI: {uri}")
        
        path_part = uri[15:]  # Remove "forge://events/"
        
        if "?" in path_part:
            query_type, params_str = path_part.split("?", 1)
            params = parse_query_params(params_str)
        else:
            query_type = path_part
            params = {}
        
        event_log = get_event_log()
        
        if query_type == "recent":
            limit = int(params.get("limit", 50))
            events = event_log.get_recent_events(limit)
            return format_events_response(events, "recent events")
        
        elif query_type == "query":
            event_type = params.get("type")
            session_id = params.get("session_id")
            project_path = params.get("project_path")
            limit = int(params.get("limit", 100))
            offset = int(params.get("offset", 0))
            
            # Convert event type string to enum
            event_type_enum = None
            if event_type:
                try:
                    event_type_enum = EventType(event_type)
                except ValueError:
                    raise ValueError(f"Invalid event type: {event_type}")
            
            # Resolve project path if provided
            resolved_project_path = None
            if project_path:
                resolved_project_path = str(resolve_project_path(project_path))
            
            events = event_log.query_events(
                event_type=event_type_enum,
                session_id=session_id,
                project_path=resolved_project_path,
                limit=limit,
                offset=offset
            )
            
            return format_events_response(events, f"query results for {query_type}")
        
        elif query_type == "stats":
            stats = event_log.get_event_stats()
            return json.dumps(stats, indent=2)
        
        elif query_type == "types":
            # List available event types
            types = [event_type.value for event_type in EventType]
            return json.dumps({
                "event_types": types,
                "description": "Available event types for querying"
            }, indent=2)
        
        else:
            raise ValueError(f"Unknown event log query type: {query_type}")
            
    except Exception as e:
        logger.error(f"Error reading event log resource {uri}: {e}")
        return json.dumps({
            "error": "Failed to read event log resource",
            "message": str(e),
            "uri": uri
        }, indent=2)


def parse_query_params(params_str: str) -> Dict[str, str]:
    """Parse query parameters from URI."""
    params = {}
    for param in params_str.split("&"):
        if "=" in param:
            key, value = param.split("=", 1)
            params[key] = value
    return params


def format_events_response(events: List[EventEntry], description: str) -> str:
    """Format events list as JSON response."""
    events_data = []
    for event in events:
        events_data.append(event.to_dict())
    
    return json.dumps({
        "description": description,
        "count": len(events_data),
        "events": events_data
    }, indent=2)


def list_event_resources() -> List[Dict[str, Any]]:
    """List available event log resources."""
    return [
        {
            "uri": "forge://events/recent",
            "name": "recent_events",
            "description": "Recent events across all types",
            "parameters": {
                "limit": "Maximum number of events (default: 50)"
            }
        },
        {
            "uri": "forge://events/query",
            "name": "event_query",
            "description": "Query events with filters",
            "parameters": {
                "type": "Event type filter",
                "session_id": "Session ID filter", 
                "project_path": "Project path filter",
                "limit": "Maximum results (default: 100)",
                "offset": "Result offset (default: 0)"
            }
        },
        {
            "uri": "forge://events/stats",
            "name": "event_stats",
            "description": "Event log statistics and summary",
            "parameters": {}
        },
        {
            "uri": "forge://events/types",
            "name": "event_types",
            "description": "Available event types",
            "parameters": {}
        }
    ]


def register_event_resources(registry: Any) -> None:
    """Register event log resources with MCP registry."""
    # Register the main event log resource handler
    registry.register_resource("forge://events/", read_event_log_resource)
    
    # Register specific resource patterns
    registry.register_resource("forge://events/recent", read_event_log_resource)
    registry.register_resource("forge://events/query", read_event_log_resource)
    registry.register_resource("forge://events/stats", read_event_log_resource)
    registry.register_resource("forge://events/types", read_event_log_resource)
    
    logger.info("Registered event log resources with MCP registry")


__all__ = [
    "read_event_log_resource",
    "list_event_resources", 
    "register_event_resources"
]
