# MCP renderer tests
