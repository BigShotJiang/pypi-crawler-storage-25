from __future__ import annotations

from pathlib import Path

import pytest

from forge.mcp.server import _build_server
from forge.mcp.workspace import resolve_project_path


def test_mcp_server_initializes() -> None:
    srv = _build_server()
    assert srv.name == "forge"


def test_resolve_project_path_from_workspace(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    proj = tmp_path / "Projects" / "myproj"
    proj.mkdir(parents=True)
    (proj / "pyproject.toml").write_text("[project]\nname='x'\n", encoding="utf-8")
    forge_dir = tmp_path / ".forge"
    forge_dir.mkdir(parents=True)
    (forge_dir / "registry.yaml").write_text(
        f"""document_kind: forge_project_registry
schema_version: 1
projects:
  myproj:
    path: {proj.resolve()}
    stack: python
""",
        encoding="utf-8",
    )
    assert resolve_project_path("myproj") == proj.resolve()


def test_resolve_project_path_fallback(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    proj = tmp_path / "Projects" / "foo"
    proj.mkdir(parents=True)
    forge_dir = tmp_path / ".forge"
    forge_dir.mkdir(parents=True)
    (forge_dir / "registry.yaml").write_text(
        f"""document_kind: forge_project_registry
schema_version: 1
projects:
  foo:
    path: {proj.resolve()}
    stack: python
""",
        encoding="utf-8",
    )
    (tmp_path / ".forge" / "workspace.yaml").write_text("projects: {}\n", encoding="utf-8")
    assert resolve_project_path("foo") == proj.resolve()
