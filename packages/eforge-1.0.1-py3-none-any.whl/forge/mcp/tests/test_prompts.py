from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

from forge.mcp.prompts import FORGE_PROMPTS, render_prompt_messages, resolve_prompt
from forge.mcp.elicitation import check_project_context, workspace_context_dict


def _prompt_all_text(r) -> str:
    parts: list[str] = []
    for m in r.messages:
        c = getattr(m, "content", None)
        if c is not None and hasattr(c, "text"):
            t = getattr(c, "text", None)
            if t:
                parts.append(str(t))
    return "\n".join(parts)


def _make_workspace(project_ids: list[str]) -> Any:
    """Build a minimal ForgeWorkspace mock for tests."""
    from forge.core.workspace_entity import ForgeWorkspace, ProjectInfo
    from pathlib import Path

    projects = {
        pid: ProjectInfo(id=pid, path=Path(f"/tmp/{pid}"), depends_on=[])
        for pid in project_ids
    }
    return ForgeWorkspace(
        id="test-ws",
        root_path=Path("/tmp"),
        projects=projects,
        relations={},
        health={"status": "healthy"},
        registry=None,
    )


EXPECTED_PROMPTS = frozenset({"forge/start", "forge/context", "forge/audit"})


def test_prompts_list_surface() -> None:
    names = {p.name for p in FORGE_PROMPTS}
    assert len(FORGE_PROMPTS) == 3
    assert names == EXPECTED_PROMPTS


def test_prompt_unknown() -> None:
    r = asyncio.run(resolve_prompt("forge/does_not_exist", {}))
    assert "Unknown prompt" in _prompt_all_text(r)


def test_prompt_start_contract_text() -> None:
    r = asyncio.run(
        resolve_prompt(
            "forge/start",
            {"project_path": "/tmp"},
        )
    )
    text = _prompt_all_text(r)
    assert "Session contract:" in text
    assert "forge://pipeline/{id}" in text
    assert "_meta channels" in text


def test_prompt_audit_contract_text() -> None:
    r = asyncio.run(
        resolve_prompt(
            "forge/audit",
            {"project_path": "/tmp"},
        )
    )
    text = _prompt_all_text(r)
    assert "forge://pipeline/audit_posture" in text
    assert "forge_annotate" in text
    assert "policy_mode" in text
    assert "advisory" in text


def test_prompt_context_default_template() -> None:
    """forge/context with no template renders the default field set."""
    r = asyncio.run(resolve_prompt("forge/context", {}))
    text = _prompt_all_text(r)
    # Default template contains these keys; no _meta context in tests → placeholders retained
    assert "Project:" in text
    assert "Phase:" in text
    assert "Current task:" in text
    assert "Health:" in text


def test_prompt_context_custom_template_passthrough() -> None:
    """forge/context passes a custom template through; placeholders retained when no _meta context."""
    r = asyncio.run(resolve_prompt("forge/context", {"template": "Status: {{health_score}} — task: {{current_task}}"}))
    text = _prompt_all_text(r)
    assert "Status:" in text
    assert "task:" in text


def test_prompt_context_in_list() -> None:
    """forge/context must appear in the FORGE_PROMPTS surface."""
    names = {p.name for p in FORGE_PROMPTS}
    assert "forge/context" in names


# ---------------------------------------------------------------------------
# Phase 4 — workspace hydration + elicitation tests
# ---------------------------------------------------------------------------


def test_prompt_start_single_project_workspace_hydration() -> None:
    """forge/start with no project_path but a single-project workspace should
    include workspace project name and health in behavior text."""
    ws = _make_workspace(["my-project"])
    with patch(
        "forge.mcp.prompts._workspace_context_for_prompt",
        return_value={
            "project_id": "my-project",
            "project_name": "my-project",
            "project_path": "/tmp/my-project",
            "health": "healthy",
            "project_count": 1,
        },
    ):
        messages = render_prompt_messages(
            prompt_name="forge/start",
            arguments={},
            resolve_project_id=lambda p: None,
        )
    texts = [
        b.get("text", "")
        for m in messages
        for b in (m.get("content") if isinstance(m.get("content"), list) else [])
        if isinstance(b, dict) and b.get("type") == "text"
    ]
    combined = "\n".join(texts)
    assert "my-project" in combined
    assert "healthy" in combined


def test_prompt_start_multi_project_workspace_elicitation() -> None:
    """forge/start with no project_path and multi-project workspace should emit
    an elicitation hint mentioning the available project names."""
    with patch(
        "forge.mcp.prompts._workspace_context_for_prompt",
        return_value={
            "project_id": None,
            "project_name": None,
            "project_path": None,
            "health": "healthy",
            "project_count": 2,
            "projects": [
                {"id": "alpha", "path": "/tmp/alpha"},
                {"id": "beta", "path": "/tmp/beta"},
            ],
        },
    ):
        messages = render_prompt_messages(
            prompt_name="forge/start",
            arguments={},
            resolve_project_id=lambda p: None,
        )
    texts = [
        b.get("text", "")
        for m in messages
        for b in (m.get("content") if isinstance(m.get("content"), list) else [])
        if isinstance(b, dict) and b.get("type") == "text"
    ]
    combined = "\n".join(texts)
    assert "alpha" in combined or "beta" in combined or "Multiple projects" in combined


def test_prompt_start_no_workspace_fallback() -> None:
    """forge/start with no project_path and no workspace → fallback message."""
    with patch(
        "forge.mcp.prompts._workspace_context_for_prompt",
        return_value={},
    ):
        messages = render_prompt_messages(
            prompt_name="forge/start",
            arguments={},
            resolve_project_id=lambda p: None,
        )
    texts = [
        b.get("text", "")
        for m in messages
        for b in (m.get("content") if isinstance(m.get("content"), list) else [])
        if isinstance(b, dict) and b.get("type") == "text"
    ]
    combined = "\n".join(texts)
    # Should still include the session contract
    assert "Session contract:" in combined
    assert "No Forge workspace" in combined or "project_path" in combined.lower()


def test_elicitation_check_no_workspace_no_fallback() -> None:
    """check_project_context with no project_path, no workspace, no CWD fallback
    should return an elicitation signal."""
    with (
        patch(
            "forge.mcp.mcp_workspace.current_forge_workspace",
            return_value=None,
        ),
        patch(
            "forge.core.path_utils.resolve_project_path",
            return_value=None,
        ),
    ):
        result = check_project_context({})
    assert result is not None
    assert result["elicitation_required"] is True
    assert result["elicitation_kind"] == "project_selection"
    assert result["available_projects"] == []


def test_elicitation_check_multi_project_workspace() -> None:
    """check_project_context with multi-project workspace and no project_path
    should return an elicitation signal listing available projects."""
    ws = _make_workspace(["proj-a", "proj-b"])
    with patch(
        "forge.mcp.mcp_workspace.current_forge_workspace",
        return_value=ws,
    ):
        result = check_project_context({})
    assert result is not None
    assert result["elicitation_required"] is True
    assert result["elicitation_kind"] == "project_selection"
    ids = [p["id"] for p in result["available_projects"]]
    assert "proj-a" in ids
    assert "proj-b" in ids


def test_elicitation_check_single_project_no_signal() -> None:
    """check_project_context with single-project workspace auto-resolves → None."""
    ws = _make_workspace(["only-project"])
    with patch(
        "forge.mcp.mcp_workspace.current_forge_workspace",
        return_value=ws,
    ):
        result = check_project_context({})
    assert result is None


def test_elicitation_check_explicit_project_path_no_signal() -> None:
    """check_project_context with an explicit project_path → always None."""
    result = check_project_context({"project_path": "/tmp/my-project"})
    assert result is None


def test_workspace_context_dict_single_project(tmp_path: Path) -> None:
    """workspace_context_dict reads manifest for phase + domains when possible."""
    from forge.core.workspace_entity import ForgeProject, ForgeWorkspace
    from forge.tools.registry.store import WorkspaceStore
    import yaml as _yaml

    root = tmp_path / "forge"
    forge_dir = root / ".forge"
    forge_dir.mkdir(parents=True)
    (forge_dir / "manifest.yaml").write_text(
        _yaml.safe_dump(
            {
                "schema_version": 1,
                "phase": "3",
                "name": "utest",
                "project": {"stack": "python"},
                "modules": [{"id": "module/x", "kind": "module", "domain": "MCP"}],
            },
            sort_keys=False,
        ),
        encoding="utf-8",
    )
    ws = ForgeWorkspace(
        id="test-ws",
        root_path=tmp_path,
        projects={"forge": ForgeProject(id="forge", path=root)},
        relations={},
        health={"status": "healthy"},
        registry=WorkspaceStore(),
        registry_path=None,
    )
    ctx = workspace_context_dict(ws)
    assert ctx["project_name"] == "forge"
    assert ctx["project_id"] == "forge"
    assert str(ctx["project_path"]) == str(root)
    assert ctx["health"] == "healthy"
    assert ctx["project_count"] == 1
    assert ctx.get("phase") == "3"
    assert "MCP" in (ctx.get("domains") or [])


def test_workspace_context_dict_multi_project() -> None:
    """workspace_context_dict with multi-project workspace returns project list."""
    ws = _make_workspace(["a", "b", "c"])
    ctx = workspace_context_dict(ws)
    assert ctx["project_count"] == 3
    assert ctx["project_name"] is None
    assert "projects" in ctx
    assert len(ctx["projects"]) == 3


def test_workspace_context_dict_empty_workspace() -> None:
    """workspace_context_dict with None workspace → empty dict."""
    with patch(
        "forge.mcp.mcp_workspace.current_forge_workspace",
        return_value=None,
    ):
        ctx = workspace_context_dict(None)
    assert ctx == {}
