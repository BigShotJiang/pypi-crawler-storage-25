from __future__ import annotations

import json
from pathlib import Path

import mcp.types as types
import yaml

from forge.mcp.session_file import (
    merge_active_project_warning,
    read_mcp_session_active_project,
    write_mcp_session_file,
)


def test_write_mcp_session_file_creates_session_yaml(tmp_path: Path, monkeypatch: object) -> None:
    monkeypatch.chdir(tmp_path)
    forge = tmp_path / ".forge"
    forge.mkdir()
    (forge / "manifest.yaml").write_text(
        yaml.safe_dump(
            {
                "schema_version": 1,
                "name": "sess-test",
                "type": "python",
                "version": "1.0.0",
                "modules": [],
            },
            sort_keys=False,
        ),
        encoding="utf-8",
    )
    p = write_mcp_session_file(cwd=tmp_path)
    assert p.name == "session.yaml"
    assert p.parent == forge
    data = yaml.safe_load(p.read_text(encoding="utf-8"))
    assert isinstance(data, dict)
    assert data["active_project"] == str(tmp_path.resolve())
    assert data.get("stack") == "python-cli"
    assert isinstance(data.get("started_at"), str) and data["started_at"]


def test_read_mcp_session_active_project_roundtrip(tmp_path: Path, monkeypatch: object) -> None:
    monkeypatch.chdir(tmp_path)
    write_mcp_session_file(cwd=tmp_path)
    ap = read_mcp_session_active_project(cwd=tmp_path)
    assert ap == str(tmp_path.resolve())


def test_write_mcp_session_file_preserves_existing_timestamp_when_context_unchanged(tmp_path: Path) -> None:
    p = tmp_path / ".forge" / "session.yaml"
    p.parent.mkdir(parents=True, exist_ok=True)
    existing = {
        "active_project": str(tmp_path.resolve()),
        "started_at": "2000-01-01T00:00:00+00:00",
        "stack": "unknown",
    }
    p.write_text(yaml.safe_dump(existing, sort_keys=False), encoding="utf-8")
    out = write_mcp_session_file(cwd=tmp_path)
    assert out == p
    data = yaml.safe_load(p.read_text(encoding="utf-8"))
    assert isinstance(data, dict)
    assert data["started_at"] == "2000-01-01T00:00:00+00:00"


def test_merge_active_project_warning_on_mismatch(tmp_path: Path) -> None:
    proj_a = tmp_path / "alpha"
    proj_b = tmp_path / "beta"
    proj_a.mkdir()
    proj_b.mkdir()
    result = types.CallToolResult(
        content=[types.TextContent(type="text", text=json.dumps({"x": 1}))],
        isError=False,
    )
    out = merge_active_project_warning(
        result,
        requested=str(proj_b.resolve()),
        active_project=str(proj_a.resolve()),
    )
    assert not out.isError
    body = json.loads(out.content[0].text)  # type: ignore[attr-defined]
    assert body["x"] == 1
    assert "mcp_session_warnings" in body
    assert any("differs from MCP session active_project" in w for w in body["mcp_session_warnings"])


def test_merge_active_project_warning_skips_when_same(tmp_path: Path) -> None:
    p = tmp_path / "same"
    p.mkdir()
    r = str(p.resolve())
    result = types.CallToolResult(
        content=[types.TextContent(type="text", text=json.dumps({"ok": True}))],
        isError=False,
    )
    out = merge_active_project_warning(result, requested=r, active_project=r)
    body = json.loads(out.content[0].text)  # type: ignore[attr-defined]
    assert "mcp_session_warnings" not in body
