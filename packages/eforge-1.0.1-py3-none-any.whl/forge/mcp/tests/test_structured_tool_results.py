"""MCP CallToolResult.structuredContent matches declared outputSchema models."""

from __future__ import annotations

import asyncio
from pathlib import Path
from unittest.mock import patch

import pytest

from forge.mcp.handlers.core_tools import handle_forge_verify
from forge.mcp.handlers.manifest_tools import handle_forge_manifest_append, handle_forge_query
from forge.mcp.handlers.mapping_tools import handle_forge_map
from forge.mcp.handlers.config_tools import handle_forge_config_set
from forge.mcp.handlers.system_tools import handle_forge_session


def test_forge_config_set_dry_run_structured_content(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    def _fake_resolve(args: dict):
        return tmp_path, None

    (tmp_path / ".forge").mkdir(parents=True)
    (tmp_path / ".forge" / "manifest.yaml").write_text("version: 1\nmodules: []\n", encoding="utf-8")
    (tmp_path / "app_config.yaml").write_text("features:\n  foo: false\n", encoding="utf-8")

    monkeypatch.setattr(
        "forge.mcp.handlers.config_tools.resolve_validated_project_path_result",
        _fake_resolve,
    )

    async def _call():
        return await handle_forge_config_set(
            {
                "project_path": str(tmp_path),
                "key": "features.foo",
                "value": True,
                "dry_run": True,
            }
        )

    res = asyncio.run(_call())
    assert res.structuredContent is not None
    assert res.structuredContent.get("updated") is False
    assert res.structuredContent.get("dry_run") is True
    assert (tmp_path / "app_config.yaml").read_text(encoding="utf-8").strip().endswith("false")


def test_forge_manifest_append_dry_run_empty_nodes_structured(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    def _fake_resolve(args: dict):
        return tmp_path, None

    (tmp_path / ".forge").mkdir(parents=True)
    (tmp_path / ".forge" / "manifest.yaml").write_text("version: 1\nmodules: []\n", encoding="utf-8")

    monkeypatch.setattr(
        "forge.mcp.handlers.manifest_tools.resolve_validated_project_path_result",
        _fake_resolve,
    )

    res = asyncio.run(
        handle_forge_manifest_append(
            {"project_path": str(tmp_path), "nodes": [], "dry_run": True}
        )
    )
    assert res.structuredContent is not None
    assert res.structuredContent.get("ok") is True
    assert res.structuredContent.get("append_result", {}).get("dry_run") is True


def test_forge_session_status_envelope_structured(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    def _fake_resolve(args: dict):
        return tmp_path, None

    (tmp_path / ".forge").mkdir(parents=True)
    (tmp_path / ".forge" / "manifest.yaml").write_text("version: 1\nmodules: []\n", encoding="utf-8")
    events = tmp_path / ".forge" / "events"
    events.mkdir(parents=True)
    (events / "session-abc.yaml").write_text(
        "document_kind: session_state\nstarted_at: '2026-01-02T00:00:00Z'\nstatus: active\n",
        encoding="utf-8",
    )

    monkeypatch.setattr(
        "forge.mcp.handlers.system_tools.resolve_validated_project_path_result",
        _fake_resolve,
    )

    res = asyncio.run(
        handle_forge_session(
            {"project_path": str(tmp_path), "action": "status"}
        )
    )
    assert res.structuredContent is not None
    assert res.structuredContent.get("action") == "status"
    body = res.structuredContent.get("result") or {}
    assert body.get("state", {}).get("status") == "active"


def test_forge_verify_returns_structured_content(tmp_path: Path) -> None:
    def _fake_resolve(args: dict):
        return tmp_path, None

    fake_payload = {
        "timestamp": "2026-01-01T00:00:00+00:00",
        "changed_nodes": [],
        "skipped_files": [],
        "impacts": [],
        "failures": [],
        "exit_code": 0,
        "impact_rules": {"matches": [], "unknown_pairs": []},
        "parity_check": {"broken": 0, "stale": 0, "clean": True, "failures": []},
    }

    async def _call():
        with (
            patch(
                "forge.mcp.handlers.core_tools.resolve_validated_project_path_result",
                _fake_resolve,
            ),
            patch("forge.mcp.thin_core.execute_verify", return_value=fake_payload),
        ):
            return await handle_forge_verify({"project_path": str(tmp_path), "target": "full"})

    res = asyncio.run(_call())
    assert res.structuredContent is not None
    assert res.structuredContent.get("exit_code") == 0
    assert "verification_result" in res.structuredContent


def test_forge_query_returns_structured_content(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    def _fake_resolve(args: dict):
        return tmp_path, None

    monkeypatch.setattr(
        "forge.mcp.handlers.manifest_tools.resolve_validated_project_path_result",
        _fake_resolve,
    )
    monkeypatch.setattr(
        "forge.mcp.thin_core.run_query_payload",
        lambda _d: {"count": 0, "nodes": [], "filters": {}},
    )

    res = asyncio.run(handle_forge_query({"project_path": str(tmp_path), "limit": 5}))
    assert res.structuredContent is not None
    assert res.structuredContent.get("ok") is True
    assert "query_result" in res.structuredContent


def test_forge_map_returns_structured_content(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    def _fake_resolve(args: dict):
        return tmp_path, None

    monkeypatch.setattr(
        "forge.mcp.handlers.mapping_tools.resolve_validated_project_path_result",
        _fake_resolve,
    )
    monkeypatch.setattr(
        "forge.mcp.thin_core.execute_map",
        lambda _a: {"ok": True, "project": "x", "nodes": [], "edges": []},
    )

    res = asyncio.run(handle_forge_map({"project_path": str(tmp_path)}))
    assert res.structuredContent is not None
    assert res.structuredContent.get("ok") is True
