from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any

import pytest
import yaml
import mcp.types as types

from forge.mcp import registry
from forge.commands.mcp_cmd import TOOL_HANDLERS as HARNESS_TOOL_HANDLERS
from forge.mcp.handlers.mapping_tools import handle_forge_map
from forge.mcp.handlers.scaffold_tools import handle_forge_template, handle_forge_scaffold
from forge.mcp.handlers.config_tools import handle_forge_config_get, handle_forge_config_set
from forge.mcp.handlers.audit_tools import handle_forge_annotate
from forge.mcp.handlers.impact_tools import handle_forge_impact_radius
from forge.mcp.workspace import read_project_context_bundle

# test_tools.py: <repo>/forge/mcp/tests/ → repo root is parents[3]
REPO_ROOT = Path(__file__).resolve().parents[3]


def test_forge_context_tool_returns_bundle() -> None:
    # Updated: forge_context → forge://project/{id}/context (2026-05-17)
    from forge.tools.context.agent_context_reader import load_agent_context_json

    payload = load_agent_context_json(REPO_ROOT)
    if payload is None:
        pytest.skip("agent context bundle not built — run forge context build")
    assert isinstance(payload, dict) and len(payload) > 0


def test_forge_template_list() -> None:
    # Updated: forge_template_thin → forge_template (2026-05-17)
    r = asyncio.run(
        handle_forge_template(
            {"project_path": str(REPO_ROOT), "response_tier": "L1"}
        )
    )
    assert not r.isError
    body = json.loads(r.content[0].text)  # type: ignore[attr-defined]
    assert body.get("ok") is True
    templates = body.get("templates") or []
    assert isinstance(templates, list)
    assert len(templates) > 0


def test_forge_scaffold_requires_node_type() -> None:
    # Updated: forge_scaffold_thin → forge_scaffold (2026-05-17)
    r = asyncio.run(
        handle_forge_scaffold({"project_path": str(REPO_ROOT)})
    )
    body = json.loads(r.content[0].text)  # type: ignore[attr-defined]
    assert body.get("ok") is False
    assert "node_type" in str(body.get("error", "")).lower()


def test_forge_scaffold_dry_run(tmp_path: Path) -> None:
    # Updated: forge_scaffold_thin → forge_scaffold via execute_scaffold (2026-05-17)
    (tmp_path / ".forge").mkdir(parents=True, exist_ok=True)
    (tmp_path / ".forge" / "manifest.yaml").write_text(
        yaml.safe_dump(
            {
                "schema_version": 1,
                "name": "scaffold-mcp-test",
                "type": "python",
                "stack": {"language": "python"},
                "version": "1.0.0",
                "modules": [],
            },
            sort_keys=False,
        ),
        encoding="utf-8",
    )
    r = asyncio.run(
        handle_forge_scaffold(
            {
                "project_path": str(tmp_path),
                "node_type": "controller",
                "stack": "flutter-app",
                "dry_run": True,
            }
        )
    )
    assert not r.isError
    body = json.loads(r.content[0].text)  # type: ignore[attr-defined]
    assert body.get("ok") is True
    assert body.get("dry_run") is True


def test_forge_map_returns_topology() -> None:
    r = asyncio.run(handle_forge_map({"project_path": str(REPO_ROOT)}))
    assert not r.isError
    body = json.loads(r.content[0].text)  # type: ignore[attr-defined]
    assert body.get("ok") is True
    assert body.get("project")
    assert isinstance(body.get("nodes"), list) and len(body["nodes"]) > 5
    assert isinstance(body.get("edges"), list)
    sample = body["nodes"][0]
    assert "id" in sample and "kind" in sample


def test_forge_impact_radius_returns_json() -> None:
    # Updated: forge_impact_check → forge_impact_radius (2026-05-17)
    r = asyncio.run(
        handle_forge_impact_radius(
            {
                "project_path": str(REPO_ROOT),
                "node_id": "module/engine.engine",
            }
        )
    )
    assert not r.isError
    body = json.loads(r.content[0].text)  # type: ignore[attr-defined]
    assert body.get("ok") is True
    assert "node_id" in body or "affected_nodes" in body


def test_forge_config_get_returns_value(tmp_path: Path) -> None:
    forge = tmp_path / ".forge"
    forge.mkdir(parents=True)
    (forge / "manifest.yaml").write_text(
        "schema_version: 1\nname: cfg\nversion: 1.0.0\n",
        encoding="utf-8",
    )
    (tmp_path / "app_config.yaml").write_text("ui:\n  theme: dark\n", encoding="utf-8")
    r = asyncio.run(
        handle_forge_config_get(
            {"project_path": str(tmp_path), "key": "ui.theme"}
        )
    )
    assert not r.isError
    out = json.loads(r.content[0].text)  # type: ignore[attr-defined]
    assert out == {"key": "ui.theme", "value": "dark"}


def test_forge_config_get_manifest_dot_notation_returns_int(tmp_path: Path) -> None:
    forge = tmp_path / ".forge"
    forge.mkdir(parents=True)
    (forge / "manifest.yaml").write_text(
        yaml.safe_dump(
            {
                "schema_version": 1,
                "name": "cfg-dot",
                "type": "python",
                "version": "1.0.0",
                "modules": [],
                "phases": {"current": 4},
            },
            sort_keys=False,
        ),
        encoding="utf-8",
    )
    r = asyncio.run(
        handle_forge_config_get(
            {
                "project_path": str(tmp_path),
                "key": "phases.current",
                "file": "manifest",
            }
        )
    )
    assert not r.isError
    out = json.loads(r.content[0].text)  # type: ignore[attr-defined]
    assert out["key"] == "phases.current"
    assert out["value"] == 4


def test_forge_config_set_dry_run_no_write(tmp_path: Path) -> None:
    forge = tmp_path / ".forge"
    forge.mkdir(parents=True)
    (forge / "manifest.yaml").write_text(
        "schema_version: 1\nname: cfg\nversion: 1.0.0\n",
        encoding="utf-8",
    )
    cfg = tmp_path / "app_config.yaml"
    cfg.write_text("x: 1\n", encoding="utf-8")
    r = asyncio.run(
        handle_forge_config_set(
            {
                "project_path": str(tmp_path),
                "key": "y",
                "value": "2",
                "dry_run": True,
            }
        )
    )
    assert not r.isError
    assert cfg.read_text(encoding="utf-8") == "x: 1\n"


def test_removed_tools_not_on_public_surface() -> None:
    """Deprecated / merged tools stay off the agent-visible tool list."""
    names = {t.name for t in registry.all_tool_schemas()}
    for removed in (
        "forge_blast_radius",
        "forge_impact_check",
        "forge_project_status",
        "forge_report",
        "forge_context",
        "forge_diff",
    ):
        assert removed not in names
    assert "forge_impact_radius" in names


def test_forge_session_and_annotate_on_public_surface() -> None:
    names = {t.name for t in registry.all_tool_schemas()}
    assert "forge_session" in names
    assert "forge_annotate" in names
    assert "forge_inspect" in names
    assert "forge_discover" in names
    assert "forge_audit" not in names


def test_forge_annotate_list_action_filters_and_tiers(tmp_path: Path) -> None:
    # Updated: forge_annotate_thin → forge_annotate (2026-05-17)
    forge = tmp_path / ".forge"
    forge.mkdir(parents=True, exist_ok=True)
    (forge / "manifest.yaml").write_text(
        "schema_version: 1\nname: ann-test\ntype: python\nversion: 1.0.0\n",
        encoding="utf-8",
    )
    ann_dir = forge / "annotations"
    ann_dir.mkdir(parents=True, exist_ok=True)
    (ann_dir / "ANNOT-900.yaml").write_text(
        yaml.safe_dump(
            {
                "id": "ANNOT-900",
                "title": "Open finding",
                "kind": "finding",
                "severity": "high",
                "status": "open",
                "file": "forge/x.py",
                "created": "2026-04-23",
                "note": "x",
                "origin": "human",
            },
            sort_keys=False,
        ),
        encoding="utf-8",
    )
    (ann_dir / "ANNOT-901.yaml").write_text(
        yaml.safe_dump(
            {
                "id": "ANNOT-901",
                "title": "Resolved gap",
                "kind": "gap",
                "severity": "low",
                "status": "resolved",
                "file": "forge/y.py",
                "created": "2026-04-23",
                "note": "y",
                "origin": "human",
            },
            sort_keys=False,
        ),
        encoding="utf-8",
    )

    r = asyncio.run(
        handle_forge_annotate(
            {
                "action": "list",
                "project_path": str(tmp_path),
                "status": "open",
                "response_tier": "L1",
            }
        )
    )
    assert not r.isError
    body = json.loads(r.content[0].text)  # type: ignore[attr-defined]
    rows: list[dict[str, Any]] = []
    if isinstance(body, list):
        rows = body
    elif isinstance(body.get("groups"), dict):
        for _origin, kinds in body["groups"].items():
            if isinstance(kinds, dict):
                for _kind, items in kinds.items():
                    if isinstance(items, list):
                        rows.extend(items)
    else:
        rows = body.get("annotations") or body.get("items") or []
    assert len(rows) >= 1
    ids = {row.get("id") for row in rows if isinstance(row, dict)}
    assert "ANNOT-900" in ids


def test_forge_annotate_show_action_returns_full_annotation(tmp_path: Path) -> None:
    forge = tmp_path / ".forge"
    forge.mkdir(parents=True, exist_ok=True)
    (forge / "manifest.yaml").write_text(
        "schema_version: 1\nname: ann-test\ntype: python\nversion: 1.0.0\n",
        encoding="utf-8",
    )
    ann_dir = forge / "annotations"
    ann_dir.mkdir(parents=True, exist_ok=True)
    (ann_dir / "ANNOT-910.yaml").write_text(
        yaml.safe_dump(
            {
                "id": "ANNOT-910",
                "title": "Show me",
                "kind": "gap",
                "severity": "medium",
                "status": "open",
                "file": "forge/z.py",
                "created": "2026-04-23",
                "note": "details",
                "body": "full content",
                "origin": "human",
            },
            sort_keys=False,
        ),
        encoding="utf-8",
    )
    r = asyncio.run(
        handle_forge_annotate(
            {
                "action": "show",
                "project_path": str(tmp_path),
                "annotation_id": "ANNOT-910",
                "response_tier": "L2",
            }
        )
    )
    assert not r.isError
    body = json.loads(r.content[0].text)  # type: ignore[attr-defined]
    if isinstance(body, dict) and "annotation" in body:
        body = body["annotation"]
    assert body.get("id") == "ANNOT-910"
    assert body.get("body") == "full content"


def test_tool_registry_extensible() -> None:
    async def _mock_tool(_: dict[str, Any]) -> types.CallToolResult:
        return types.CallToolResult(content=[types.TextContent(type="text", text="ok")])

    schema = types.Tool(
        name="forge_mock_ext",
        description="test",
        inputSchema={"type": "object", "properties": {}},
    )
    registry.register_tool("forge_mock_ext", _mock_tool, schema)
    names = {t.name for t in registry.all_tool_schemas()}
    assert "forge_mock_ext" in names
    h = registry.get_tool_handler("forge_mock_ext")
    assert h is not None
    out = asyncio.run(h({}))
    assert out.content[0].text == "ok"  # type: ignore[attr-defined,union-attr]


@pytest.mark.parametrize(
    "tool_name",
    [
        "forge_map",
        "forge_audit_scan",
        "forge_verify",
        "forge_trace",
        "forge_query",
        "forge_session",
        "forge_annotate",
        "forge_orient",
        "forge_packet_assemble",
        "forge_inspect",
        "forge_discover",
        "forge_impact_radius",
    ],
)
def test_tool_registered_and_harness_reachable(tool_name: str) -> None:
    assert registry.get_tool_handler(tool_name) is not None
    assert tool_name in HARNESS_TOOL_HANDLERS


def test_forge_impact_radius_on_sample_node(tmp_path: Path) -> None:
    # Updated: forge_blast_radius_full → forge_impact_radius (2026-05-17)
    (tmp_path / ".forge").mkdir(parents=True, exist_ok=True)
    (tmp_path / ".forge" / "manifest.yaml").write_text(
        yaml.safe_dump(
            {
                "schema_version": 1,
                "name": "impact-test",
                "type": "python",
                "version": "1.0.0",
                "modules": [
                    {
                        "id": "module/a",
                        "name": "a",
                        "kind": "module",
                        "path": "a.py",
                        "domain": "CORE",
                    }
                ],
            },
            sort_keys=False,
        ),
        encoding="utf-8",
    )
    r = asyncio.run(
        handle_forge_impact_radius(
            {"project_path": str(tmp_path), "node_id": "module/a"}
        )
    )
    assert not r.isError
    body = json.loads(r.content[0].text)  # type: ignore[attr-defined]
    assert body.get("ok") is True
