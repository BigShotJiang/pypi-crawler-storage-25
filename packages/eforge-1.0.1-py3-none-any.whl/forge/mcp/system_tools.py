"""
MCP System Tools with Response Tiers

Efficient MCP tool integration for system health and metrics
with response_tiers for optimized token usage.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional
import json
from pathlib import Path

from mcp.server.models import CallToolResult
from mcp.server.session import ServerSession

from forge.core.graph_health_metrics import analyze_project_graph_health
from forge.core.debug_output_interface import create_debug_session, OutputFormat
from forge.core.reality_validator import RealityValidator
from forge.commands.system import health, reality, doctor, recover, graph
import click


class MCPSystemTools:
    """MCP tools for system operations with response tier optimization."""
    
    def __init__(self, session: ServerSession):
        self.session = session
        self.project_root = Path.cwd()  # Default to current directory
    
    async def system_health_l0(self, project_path: Optional[str] = None) -> CallToolResult:
        """
        L0: Basic health status (minimal tokens).
        
        Returns only overall health percentage and status.
        """
        try:
            if project_path:
                self.project_root = Path(project_path)
            
            # Quick health check
            health_result = analyze_project_graph_health(self.project_root)
            
            return CallToolResult(
                content=[
                    {
                        "type": "text",
                        "text": json.dumps({
                            "health_percentage": round(health_result.overall_health * 100, 1),
                            "status": health_result.status,
                            "project_path": str(self.project_root)
                        })
                    }
                ]
            )
        except Exception as e:
            return CallToolResult(
                content=[{"type": "text", "text": json.dumps({"error": str(e)})}],
                isError=True
            )
    
    async def system_health_l1(self, project_path: Optional[str] = None) -> CallToolResult:
        """
        L1: Health with metric breakdown (moderate tokens).
        
        Returns individual metric scores and basic recommendations.
        """
        try:
            if project_path:
                self.project_root = Path(project_path)
            
            health_result = analyze_project_graph_health(self.project_root)
            
            # Format metrics for L1 response
            metrics = {}
            for metric in health_result.metrics:
                metrics[metric.metric_type.value] = {
                    "score": round(metric.success_rate * 100, 1),
                    "status": "healthy" if metric.is_healthy else "unhealthy"
                }
            
            return CallToolResult(
                content=[
                    {
                        "type": "text", 
                        "text": json.dumps({
                            "overall_health": round(health_result.overall_health * 100, 1),
                            "status": health_result.status,
                            "metrics": metrics,
                            "recommendations": health_result.recommendations[:3],  # Top 3
                            "project_path": str(self.project_root)
                        })
                    }
                ]
            )
        except Exception as e:
            return CallToolResult(
                content=[{"type": "text", "text": json.dumps({"error": str(e)})}],
                isError=True
            )
    
    async def system_health_l2(self, project_path: Optional[str] = None) -> CallToolResult:
        """
        L2: Full health analysis (comprehensive tokens).
        
        Returns complete analysis with all details and recommendations.
        """
        try:
            if project_path:
                self.project_root = Path(project_path)
            
            # Create debug session for structured output
            debug_session = create_debug_session(str(self.project_root))
            
            # Analyze health
            health_result = analyze_project_graph_health(self.project_root)
            
            # Add results to debug session
            for metric in health_result.metrics:
                severity = "success" if metric.is_healthy else "warning"
                debug_session.add_result(
                    component=type("Component", (), {"value": "health"})(),
                    operation=metric.metric_type.value,
                    severity=type("Severity", (), {"value": severity})(),
                    message=f"{metric.metric_type.value}: {metric.success_rate:.1%}",
                    details=metric.details,
                    recommendations=metric.recommendations if not metric.is_healthy else []
                )
            
            debug_session.finalize()
            
            # Get dashboard format for comprehensive output
            dashboard_output = debug_session.get_output(OutputFormat.DASHBOARD)
            
            return CallToolResult(
                content=[
                    {
                        "type": "text",
                        "text": json.dumps({
                            "health_analysis": dashboard_output,
                            "project_path": str(self.project_root),
                            "response_tier": "L2"
                        })
                    }
                ]
            )
        except Exception as e:
            return CallToolResult(
                content=[{"type": "text", "text": json.dumps({"error": str(e)})}],
                isError=True
            )
    
    async def system_reality_l0(self, project_path: Optional[str] = None) -> CallToolResult:
        """
        L0: Basic reality validation status.
        
        Returns validation status and discrepancy count.
        """
        try:
            if project_path:
                self.project_root = Path(project_path)
            
            validator = RealityValidator(self.project_root)
            result = validator.validate_project()
            
            return CallToolResult(
                content=[
                    {
                        "type": "text",
                        "text": json.dumps({
                            "health_score": round(result.health_score * 100, 1),
                            "discrepancy_count": len(result.discrepancies),
                            "validation_status": "passed" if result.health_score > 0.7 else "failed",
                            "project_path": str(self.project_root)
                        })
                    }
                ]
            )
        except Exception as e:
            return CallToolResult(
                content=[{"type": "text", "text": json.dumps({"error": str(e)})}],
                isError=True
            )
    
    async def system_reality_l1(self, project_path: Optional[str] = None) -> CallToolResult:
        """
        L1: Reality validation with discrepancy breakdown.
        
        Returns discrepancy categories and severity distribution.
        """
        try:
            if project_path:
                self.project_root = Path(project_path)
            
            validator = RealityValidator(self.project_root)
            result = validator.validate_project()
            
            # Analyze discrepancies
            severity_counts = {}
            category_counts = {}
            for disc in result.discrepancies:
                severity_counts[disc.severity] = severity_counts.get(disc.severity, 0) + 1
                category = getattr(disc, 'category', 'unknown')
                category_counts[category] = category_counts.get(category, 0) + 1
            
            return CallToolResult(
                content=[
                    {
                        "type": "text",
                        "text": json.dumps({
                            "health_score": round(result.health_score * 100, 1),
                            "discrepancy_count": len(result.discrepancies),
                            "severity_breakdown": severity_counts,
                            "category_breakdown": category_counts,
                            "validation_status": "passed" if result.health_score > 0.7 else "failed",
                            "project_path": str(self.project_root)
                        })
                    }
                ]
            )
        except Exception as e:
            return CallToolResult(
                content=[{"type": "text", "text": json.dumps({"error": str(e)})}],
                isError=True
            )
    
    async def system_doctor_l0(self, project_path: Optional[str] = None) -> CallToolResult:
        """
        L0: Basic doctor check status.
        
        Returns Forge installation and basic project status.
        """
        try:
            if project_path:
                self.project_root = Path(project_path)
            
            # Run basic doctor checks
            from forge.commands.doctor import check_forge_install, check_all_manifests
            
            forge_check = check_forge_install()
            manifest_checks = check_all_manifests()
            
            project_status = "healthy"
            issues = []
            
            if not forge_check.ok:
                project_status = "unhealthy"
                issues.append(f"Forge installation: {forge_check.error}")
            
            failed_manifests = [name for name, check in manifest_checks.items() if not check.ok]
            if failed_manifests:
                project_status = "unhealthy"
                issues.append(f"Failed manifests: {', '.join(failed_manifests)}")
            
            return CallToolResult(
                content=[
                    {
                        "type": "text",
                        "text": json.dumps({
                            "overall_status": project_status,
                            "forge_installation": "healthy" if forge_check.ok else "unhealthy",
                            "manifest_count": len(manifest_checks),
                            "failed_manifests": len(failed_manifests),
                            "issues": issues,
                            "project_path": str(self.project_root)
                        })
                    }
                ]
            )
        except Exception as e:
            return CallToolResult(
                content=[{"type": "text", "text": json.dumps({"error": str(e)})}],
                isError=True
            )
    
    async def system_summary_l0(self, project_path: Optional[str] = None) -> CallToolResult:
        """
        L0: Complete system overview (minimal tokens).
        
        Returns consolidated status across all system components.
        """
        try:
            if project_path:
                self.project_root = Path(project_path)
            
            # Quick checks across all components
            results = {}
            
            # Health check
            try:
                health_result = analyze_project_graph_health(self.project_root)
                results["health"] = {
                    "status": health_result.status,
                    "score": round(health_result.overall_health * 100, 1)
                }
            except Exception:
                results["health"] = {"status": "error", "score": 0}
            
            # Reality check
            try:
                validator = RealityValidator(self.project_root)
                reality_result = validator.validate_project()
                results["reality"] = {
                    "status": "passed" if reality_result.health_score > 0.7 else "failed",
                    "discrepancies": len(reality_result.discrepancies)
                }
            except Exception:
                results["reality"] = {"status": "error", "discrepancies": 0}
            
            # Doctor check
            try:
                from forge.commands.doctor import check_forge_install
                forge_check = check_forge_install()
                results["doctor"] = {
                    "status": "healthy" if forge_check.ok else "unhealthy"
                }
            except Exception:
                results["doctor"] = {"status": "error"}
            
            # Overall assessment
            healthy_components = sum(1 for r in results.values() if r.get("status") in ["healthy", "passed"])
            total_components = len(results)
            overall_status = "healthy" if healthy_components == total_components else "degraded" if healthy_components > 0 else "unhealthy"
            
            return CallToolResult(
                content=[
                    {
                        "type": "text",
                        "text": json.dumps({
                            "overall_status": overall_status,
                            "healthy_components": healthy_components,
                            "total_components": total_components,
                            "components": results,
                            "project_path": str(self.project_root)
                        })
                    }
                ]
            )
        except Exception as e:
            return CallToolResult(
                content=[{"type": "text", "text": json.dumps({"error": str(e)})}],
                isError=True
            )


# Tool registration for MCP server
def register_system_tools(session: ServerSession) -> Dict[str, Any]:
    """Register system tools with response tier optimization."""
    
    system_tools = MCPSystemTools(session)
    
    return {
        "system_health_l0": {
            "description": "Get basic system health status (L0 - minimal tokens)",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "project_path": {
                        "type": "string",
                        "description": "Optional project path (defaults to current directory)"
                    }
                }
            },
            "handler": system_tools.system_health_l0
        },
        "system_health_l1": {
            "description": "Get system health with metric breakdown (L1 - moderate tokens)",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "project_path": {
                        "type": "string",
                        "description": "Optional project path (defaults to current directory)"
                    }
                }
            },
            "handler": system_tools.system_health_l1
        },
        "system_health_l2": {
            "description": "Get comprehensive system health analysis (L2 - full tokens)",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "project_path": {
                        "type": "string",
                        "description": "Optional project path (defaults to current directory)"
                    }
                }
            },
            "handler": system_tools.system_health_l2
        },
        "system_reality_l0": {
            "description": "Get basic reality validation status (L0 - minimal tokens)",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "project_path": {
                        "type": "string",
                        "description": "Optional project path (defaults to current directory)"
                    }
                }
            },
            "handler": system_tools.system_reality_l0
        },
        "system_reality_l1": {
            "description": "Get reality validation with discrepancy breakdown (L1 - moderate tokens)",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "project_path": {
                        "type": "string",
                        "description": "Optional project path (defaults to current directory)"
                    }
                }
            },
            "handler": system_tools.system_reality_l1
        },
        "system_doctor_l0": {
            "description": "Get basic doctor check status (L0 - minimal tokens)",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "project_path": {
                        "type": "string",
                        "description": "Optional project path (defaults to current directory)"
                    }
                }
            },
            "handler": system_tools.system_doctor_l0
        },
        "system_summary_l0": {
            "description": "Get complete system overview (L0 - minimal tokens)",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "project_path": {
                        "type": "string",
                        "description": "Optional project path (defaults to current directory)"
                    }
                }
            },
            "handler": system_tools.system_summary_l0
        }
    }
