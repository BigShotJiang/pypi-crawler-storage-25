from __future__ import annotations

import asyncio
import json
import time
from contextvars import ContextVar
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import mcp.types as types
from mcp.server import Server
from mcp.server.stdio import stdio_server
from pydantic import AnyUrl

from forge.core.schemas import MetaUI, OutputResolutionPolicy, UIComponent
from forge.mcp import registry
from forge.mcp import prompts as forge_prompts
from forge.mcp.workspace import list_intended_roots, register_workspace_graph_resources
from forge.mcp.session_file import (
    extract_requested_project_path,
    merge_active_project_warning,
    read_mcp_session_active_project,
    write_mcp_session_file,
)

_SESSIONS: dict[str, Any] = {}


def get_or_create_session(project_path: str) -> Any:
    if project_path not in _SESSIONS:
        from forge.engine.session import ForgeSession

        _SESSIONS[project_path] = ForgeSession.open(project_path)
    return _SESSIONS[project_path]


def get_or_create_session_project(project_path: str) -> Any:
    """Backward-compat shim — callers expecting ForgeProject get session.project."""
    return get_or_create_session(project_path).project

def resolve_project_from_roots(arguments: dict) -> str | None:
    project_path = arguments.get("project_path")
    if not project_path:
        roots = get_meta("roots", [])
        if roots:
            root = roots[0]
            project_path = root if isinstance(root, str) else str(root).replace("file://", "")
    return project_path
from forge.mcp.resource_hygiene import classify_startup_resources
from forge.mcp.event_resources import register_event_resources
from forge.mcp.memory_resources import register_memory_resources
from forge.mcp.tasks_resources import register_tasks_resources, register_apps_resources

SERVER_START_TIME = time.time()
HIDDEN_TOOLS = {
    "forge_context",
    "forge_diff"
}


def _check_subscription_support() -> bool:
    """Probe SDK resource subscription capability."""
    import mcp.server as _mcp_server

    return (
        hasattr(_mcp_server.Server, "subscribe_resource")
        or hasattr(_mcp_server.Server, "on_resource_change")
        or hasattr(_mcp_server, "NotificationOptions")
    )


SUBSCRIPTION_SUPPORTED = _check_subscription_support()
MCP_RESOURCE_GUIDE_TEXT = """Use forge://schema/* BEFORE validating any manifest or annotation
YAML. Do not guess schema — fetch it.

Use forge://glove/{kind}/{stack} BEFORE scaffolding any node.
Conventions are in the glove, not in your training data.

Use forge://project/{id}/context to get assembled agent context for a
project — replaces forge_context tool when .forge/agent_context.json exists.

Use forge://project/{id}/annotations to get open annotation records.
Filter with ?status=open, ?kind=bug, ?node_id=module/engine.engine.

Use forge://project/{id}/intent to get intent graph records for a project.
Filter with ?node_id=module/engine.engine, ?status=open.

Use forge://inspect/{handle} to read active cursor state after
forge_inspect action=node. Filter with ?ring=1 or ?ring=2.

Use forge://schema/stacks/{stack} for live BuiltinStackProfile YAML (exp form)
— includes impact_rules, node kinds, glove keys. astro/web/python/dart supported.
Use forge://schema/stack-registry to list all registered profiles before scaffold.

Use forge://schema/manifest/v2/fields/{name} for field-level schema access
(e.g. forge://schema/manifest/v2/fields/contracts).

Use forge://docs/adr/{id} when an architectural decision is
referenced. Do not paraphrase ADRs from memory.

Use forge://pipeline/{pipelineId} to fetch a typed pipeline descriptor
(JSON ``PipelineDescriptor`` from ``.forge/pipelines/{pipelineId}.pipeline.yaml``).

Use forge://schema/errors to get the full canonical error registry with taxonomy.
Every Forge error has: code (MCP-NNN), layer, hint (agent-actionable), graph_nodes
(affected node IDs), suggested_commands, suggested_actions. Agents should use code
and hint fields, not message. message is for humans.
The registry merges ``forge/core/errors.py`` ERRORS with legacy
``register_error`` templates in ``forge/core/schemas.py``.

Use forge://schema/taxonomy for full NodeTier hierarchy with descriptions,
import rules, inference defaults, and examples. This replaces reading
forge/core/schemas.py to understand primitive taxonomy.

forge_query supports filter by tier (NodeTier enum).
Tier hierarchy: worker⊃glove,gate — schema⊃registry.
Examples:
  tier=worker → all internal pipeline helpers
  tier=schema → all typed contracts + registries
  tier=glove  → all stack adapters (specific subtype)
  tier=surface → all MCP-visible tools/resources/prompts
Type-first search: no prior knowledge of internals required.

Use forge://glove/filesystem/local — local filesystem read/write glove, allowed within ~/Projects,
used in pipeline emit steps (see ``forge/mcp/fs_glove.py``).

Fetch resources lazily — only when your reasoning requires the
data. Do not prefetch at session start.

MCP exposes two prompts only: forge/start (session entry, contract, pipelines) and
forge/audit (audit posture, forge_annotate contract). Scaffold, pre-change brief,
error registry, and similar flows use forge://pipeline/{pipelineId} and
forge://schema/errors — not separate prompts.

Do NOT call forge_project_status — use forge_orient(L0) instead.
Do NOT call forge_context — use forge://project/{id}/context
instead when context bundle exists.
"""

DEFAULT_META_POLICY = OutputResolutionPolicy()
_CURRENT_MCP_CONTEXT: ContextVar[Any | None] = ContextVar("forge_current_mcp_context", default=None)

# Placeholder for get_meta closure - set inside _build_server
def get_meta(key: str, default: Any = None) -> Any:
    return default


class MetaChannel:
    def __init__(self) -> None:
        self._data: dict[str, Any] = {}

    def add_hints(self, hints: list[str]) -> None:
        if hints:
            self._data["hints"] = hints

    def add_annotations(self, annotations: list[dict[str, Any]]) -> None:
        if annotations:
            self._data["annotations"] = annotations

    def add_logging(self, lines: list[str]) -> None:
        if not lines:
            return
        existing = self._data.get("logging")
        if isinstance(existing, list):
            existing.extend(lines)
            self._data["logging"] = existing
        else:
            self._data["logging"] = list(lines)

    def add_resource_link(self, key: str, uri: str) -> None:
        links = self._data.get("resource_links")
        if not isinstance(links, dict):
            links = {}
        links[key] = uri
        self._data["resource_links"] = links

    def add_ui(self, components: list[UIComponent], layout: str = "inline") -> None:
        self._data["ui"] = MetaUI(
            components=components,
            layout=layout,
        ).model_dump()

    def add_elicitation_result(
        self,
        outcome: str,
        schema_name: str,
        note: str = "",
    ) -> None:
        self._data["elicitation"] = {
            "outcome": outcome,
            "schema": schema_name,
            "note": note,
        }

    def attach(self, result: Any) -> Any:
        if not self._data:
            return result

        # CallToolResult path: best-effort _meta injection into JSON text payload.
        if hasattr(result, "content"):
            try:
                content = getattr(result, "content", None)
                if isinstance(content, list) and content:
                    first = content[0]
                    if isinstance(first, types.TextContent):
                        text = first.text or ""
                        parsed = json.loads(text)
                        if isinstance(parsed, dict):
                            parsed["_meta"] = self._data
                            first.text = json.dumps(parsed, indent=2)
                            return result
            except Exception as e:
                import logging

                logging.getLogger("forge.mcp").error(
                    "MetaChannel.attach failed: %s",
                    e,
                )
                # Safe degradation: _meta is optional transport.
                return result
            return result

        # Raw dict path.
        if isinstance(result, dict):
            result["_meta"] = self._data
        return result

    @property
    def is_empty(self) -> bool:
        return not self._data


def get_current_mcp_context() -> Any | None:
    return _CURRENT_MCP_CONTEXT.get()


async def notify_resource_updated(uri: str) -> None:
    """Best-effort notifications/resources/updated emit."""
    if not SUBSCRIPTION_SUPPORTED:
        return
    try:
        ctx = get_current_mcp_context()
        if ctx is None:
            return
        session = getattr(ctx, "session", None)
        if session is not None:
            send_res = getattr(session, "send_resource_updated", None)
            if callable(send_res):
                out = send_res(uri)
                if asyncio.iscoroutine(out):
                    await out
                return
            send_notif = getattr(session, "send_notification", None)
            if callable(send_notif):
                out = send_notif("notifications/resources/updated", {"uri": uri})
                if asyncio.iscoroutine(out):
                    await out
                return
        send_notif_ctx = getattr(ctx, "send_notification", None)
        if callable(send_notif_ctx):
            out = send_notif_ctx("notifications/resources/updated", {"uri": uri})
            if asyncio.iscoroutine(out):
                await out
    except Exception:
        return


def _resolve_project_id_for_prompt(project_path: str | None) -> str | None:
    if project_path is None or not str(project_path).strip():
        return None
    from forge.tools.workspace_store import load_workspace_root, projects_map, workspace_yaml_path

    try:
        p = Path(str(project_path)).expanduser().resolve()
    except Exception:
        return None
    ws = workspace_yaml_path()
    if ws.is_file():
        try:
            root = load_workspace_root(ws)
            pmap = projects_map(root)
            for pid, entry in pmap.items():
                if not isinstance(entry, dict):
                    continue
                ep = entry.get("path")
                if not ep:
                    continue
                if Path(str(ep)).expanduser().resolve() == p:
                    return str(pid)
        except Exception:
            pass
    return p.name


def _resolve_stack_for_prompt(project_path: str | None) -> str | None:
    if project_path is None or not str(project_path).strip():
        return None
    from forge.core.manifest_document import ManifestDocument

    try:
        doc = ManifestDocument.from_path(Path(str(project_path)).expanduser().resolve())
        return str(doc.stack or "python")
    except Exception:
        return None


def _coerce_meta_bool(value: Any, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        v = value.strip().lower()
        if v in {"1", "true", "yes", "on"}:
            return True
        if v in {"0", "false", "no", "off"}:
            return False
    return default


# Module-level helper functions for MCP server
# These were moved from nested scope to fix NameError issues

_server_instance: Server | None = None

def get_meta(key: str, default: Any = None) -> Any:
    """Get metadata from current MCP request context."""
    global _server_instance
    if _server_instance is None:
        return default
    try:
        ctx = _server_instance.request_context
        meta = getattr(ctx, "meta", None)
    except LookupError:
        return default
    except Exception:
        return default
    if not meta:
        return default

    # ``response_tier`` (L0/L1/L2) must never be read from the generic ``tier`` meta
    # key when that key holds forge_query's NodeTier filter (e.g. "schema").
    if key == "response_tier":
        val = None
        if isinstance(meta, dict):
            val = meta.get("response_tier")
            if val is None:
                raw = meta.get("tier")
                rt = str(raw).strip().upper() if raw is not None else ""
                if rt in {"L0", "L1", "L2"}:
                    val = rt
        else:
            val = getattr(meta, "response_tier", None)
            if val is None:
                raw = getattr(meta, "tier", None)
                rt = str(raw).strip().upper() if raw is not None else ""
                if rt in {"L0", "L1", "L2"}:
                    val = rt
        if val is None:
            val = default
        tier = str(val if val is not None else default or DEFAULT_META_POLICY.tier.value).upper()
        return tier if tier in {"L0", "L1", "L2"} else DEFAULT_META_POLICY.tier.value

    val = None
    if isinstance(meta, dict):
        val = meta.get(key, None)
    else:
        val = getattr(meta, key, None)
    if key in {"strict", "dry_run", "debug"}:
        return _coerce_meta_bool(val, bool(default))
    return val if val is not None else default


def _content_text(result: types.CallToolResult) -> str | None:
    """Extract text content from CallToolResult."""
    if not result.content:
        return None
    c0 = result.content[0]
    if isinstance(c0, types.TextContent):
        return c0.text
    return None


def _set_content_text(result: types.CallToolResult, text: str) -> types.CallToolResult:
    """Set text content in CallToolResult."""
    if result.content and isinstance(result.content[0], types.TextContent):
        result.content[0] = types.TextContent(type="text", text=text)
        return result
    result.content = [types.TextContent(type="text", text=text)]
    return result


def _merge_meta_logging_payload(payload: dict[str, Any], lines: list[str]) -> dict[str, Any]:
    """Merge meta logging payload with channel data."""
    channel = MetaChannel()
    existing_meta = payload.get("_meta")
    if isinstance(existing_meta, dict):
        hints = existing_meta.get("hints")
        if isinstance(hints, list):
            channel.add_hints([str(x) for x in hints])
        annotations = existing_meta.get("annotations")
        if isinstance(annotations, list):
            channel.add_annotations([x for x in annotations if isinstance(x, dict)])
        logging_lines = existing_meta.get("logging")
        if isinstance(logging_lines, list):
            channel.add_logging([str(x) for x in logging_lines])
        resource_links = existing_meta.get("resource_links")
        if isinstance(resource_links, dict):
            for k, v in resource_links.items():
                if k is not None and v is not None:
                    channel.add_resource_link(str(k), str(v))
        elicitation = existing_meta.get("elicitation")
        if isinstance(elicitation, dict):
            channel.add_elicitation_result(
                outcome=str(elicitation.get("outcome") or ""),
                schema_name=str(elicitation.get("schema") or ""),
                note=str(elicitation.get("note") or ""),
            )
    channel.add_logging(lines)
    payload.pop("_meta", None)
    return channel.attach(payload)


# Export get_meta at module level for handler imports
import sys
sys.modules[__name__].get_meta = get_meta

TOOL_DESCRIPTIONS = {
    "forge_orient":         "Orient — initialize session context, load project state, phase, blockers and suggested workflow",
    "forge_project_status": "Project Status — return current phase, stack, health, warnings and next action",
    "forge_health_vector":  "Health Vector — compute entity coverage, implementation rate, domain breakdown and health score",
    "forge_verify":         "Verify — run structural validation against manifest, report violations",
    "forge_query":          "Query — filter and return graph nodes by kind, domain, status, tier or name",
    "forge_blast_radius":   "Blast Radius — find all nodes directly and transitively affected by changes to a target node",
    "forge_map":            "Map — generate full project topology from manifest graph",
    "forge_trace":          "Trace — trace dependency path between two nodes in the graph",
    "forge_report":         "Report — generate structured project report from graph state",
    "forge_annotate":       "Annotate — create, list, show, update, resolve or dismiss audit annotations",
    "forge_audit_scan":     "Audit Scan — scan project graph for health issues, drift and missing implementations",
    "forge_impact_check":   "Impact Check — assess impact score and affected areas for a proposed change",
    "forge_manifest_append":"Manifest Append — declare new nodes into .forge/manifest.yaml with validation",
    "forge_intent":         "Intent — add, query, show, update or list design intent records for graph nodes",
    "forge_session":        "Session — start, get status or hand off the current forge working session",
    "forge_workspace":      "Workspace — list roots, add projects, query dependents or dependencies",
    "forge_config_get":     "Config Get — read a key from forge project config or app_config.yaml",
    "forge_config_set":     "Config Set — write a key to forge project config or app_config.yaml",
    "forge_scaffold":       "Scaffold — generate code artifacts from glove templates for a node",
    "forge_pipeline":       "Pipeline — execute a named sequence of MCP tool calls in dependency order",
    "forge_invoke":         "Invoke — call a domain-specific glove method by domain and method name",
    "forge_packet_assemble":"Packet Assemble — assemble a context packet from graph state for handoff",
}


def _build_server(project_root: Path | None = None) -> Server:
    global _server_instance
    # Import handlers for side-effect: registers builtin tools in registry.
    from forge.mcp.handlers.registry import TOOL_MAPPING  # noqa: F401

    server = Server("forge", version="1.0.0", instructions="Forge MCP — thin wrappers over forge CLI libraries.")
    server_root = (project_root or Path.cwd()).expanduser().resolve()
    _server_instance = server

    @server.list_tools()
    async def _list_tools() -> list[types.Tool]:
        # Use new registry TOOL_MAPPING for tool schemas
        from .handlers.schemas import get_input_schema, get_output_schema
        from .handlers.registry import TOOL_ANNOTATIONS
        from mcp.types import Tool

        tools = []
        for tool_name in TOOL_MAPPING.keys():
            if tool_name in HIDDEN_TOOLS:
                continue

            # Get proper input schema from Pydantic model
            input_schema_model = get_input_schema(tool_name)
            if input_schema_model:
                input_schema = input_schema_model.model_json_schema()
            else:
                # Fallback schema for tools without input models
                input_schema = {
                    "type": "object",
                    "properties": {
                        "project_path": {
                            "type": "string",
                            "description": "Path to Forge project"
                        }
                    }
                }

            # Get output schema for read-only tools
            output_schema_model = get_output_schema(tool_name)
            output_schema = output_schema_model.model_json_schema() if output_schema_model else None

            tools.append(Tool(
                name=tool_name,
                description=TOOL_DESCRIPTIONS.get(tool_name, f"{tool_name} — Forge MCP tool"),
                inputSchema=input_schema,
                outputSchema=output_schema,
                annotations=TOOL_ANNOTATIONS.get(tool_name),
            ))

        return tools

    @server.call_tool()
    async def _call_tool(name: str, arguments: dict | None) -> types.CallToolResult:
        # Use new registry TOOL_MAPPING for tool dispatch
        from forge.mcp.handlers.error_handlers import _wrap_mcp_tool_handler

        handler = TOOL_MAPPING.get(name)
        if handler is None:
            return types.CallToolResult(
                content=[types.TextContent(type="text", text=f"Unknown tool: {name}")],
                isError=True,
            )
        wrapped = _wrap_mcp_tool_handler(name, handler)
        from forge.mcp.mcp_workspace import bind_mcp_session_context
        from forge.mcp.session_context import reset_session_context_token

        _session_ctx_token = bind_mcp_session_context()
        merged_args = dict(arguments or {})
        t0 = time.time()
        policy = OutputResolutionPolicy.from_meta(
            lambda key, default=None: get_meta(key, default)
        )
        policy_payload = {
            "policy_mode": policy.policy_mode,
            "response_tier": policy.tier.value,
            "strict": policy.strict,
            "dry_run": policy.dry_run,
            "changed_files_source": policy.changed_files_source,
            "debug": policy.debug,
        }
        for mk, dv in policy_payload.items():
            if mk not in merged_args or merged_args.get(mk) is None:
                merged_args[mk] = dv
        if "project_path" not in merged_args or merged_args.get("project_path") is None:
            project_path = get_meta("project_path", None)
            if project_path is not None:
                merged_args["project_path"] = project_path

        # Process any queued ECS events before tool runs
        try:
            _active_session = get_or_create_session(
                merged_args.get("project_path", ""))
            if _active_session:
                _active_session.process_pending_events()
        except Exception:
            pass

        # Inject project_context from _meta if available
        project_context = get_meta("project_context", None)
        if project_context and isinstance(project_context, dict):
            # Only inject project_context if not explicitly provided
            if "project_context" not in merged_args:
                merged_args["project_context"] = project_context

        # Hydrate tool arguments before handler
        try:
            from forge.mcp.elicitation import hydrate_arguments
            merged_args = hydrate_arguments(name, merged_args)
        except Exception:
            pass

        token = _CURRENT_MCP_CONTEXT.set(getattr(server, "request_context", None))
        try:
            result = await wrapped(merged_args)
        except Exception as e:
            import logging
            import traceback

            logging.getLogger("forge.mcp").error(
                "TOOL CRASH [%s]: %s\n%s",
                name,
                e,
                traceback.format_exc(),
            )
            from forge.core.schemas import make_error
            from forge.mcp.handlers.registry import get_handlers

            err = make_error(
                "ERR-001",
                source_tool=name,
                context={
                    "exception": str(e),
                    "debug": traceback.format_exc(),
                },
            )
            return make_tool_result(err.model_dump_json(), None, is_error=True)
        finally:
            _CURRENT_MCP_CONTEXT.reset(token)
            reset_session_context_token(_session_ctx_token)
        dur_ms = int((time.time() - t0) * 1000)
        txt = _content_text(result)
        if txt:
            try:
                parsed = json.loads(txt)
            except Exception:
                parsed = None
            if isinstance(parsed, dict):
                channel = MetaChannel()
                existing_meta = parsed.get("_meta")
                if isinstance(existing_meta, dict):
                    hints = existing_meta.get("hints")
                    if isinstance(hints, list):
                        channel.add_hints([str(x) for x in hints])
                    annotations = existing_meta.get("annotations")
                    if isinstance(annotations, list):
                        channel.add_annotations([x for x in annotations if isinstance(x, dict)])
                    logging_lines = existing_meta.get("logging")
                    if isinstance(logging_lines, list):
                        channel.add_logging([str(x) for x in logging_lines])
                    resource_links = existing_meta.get("resource_links")
                    if isinstance(resource_links, dict):
                        for k, v in resource_links.items():
                            if k is not None and v is not None:
                                channel.add_resource_link(str(k), str(v))
                    elicitation = existing_meta.get("elicitation")
                    if isinstance(elicitation, dict):
                        channel.add_elicitation_result(
                            outcome=str(elicitation.get("outcome") or ""),
                            schema_name=str(elicitation.get("schema") or ""),
                            note=str(elicitation.get("note") or ""),
                        )
                if get_meta("debug", False):
                    proj = str(merged_args.get("project_path") or "")
                    exit_code = str(parsed.get("exit_code")) if parsed.get("exit_code") is not None else ""
                    channel.add_logging(
                        [
                            f"[MCP.server] tool_call L0: {name} {proj}",
                            f"[MCP.server] tool_result L0: exit_code={exit_code} duration={dur_ms}ms",
                        ]
                    )
                parsed.pop("_meta", None)
                parsed = channel.attach(parsed)
                result = _set_content_text(result, json.dumps(parsed, indent=2))
        return result

    @server.list_resources()
    async def _list_resources() -> list[types.Resource]:
        # All available resources (for on-demand loading)
        all_resources = [
            types.Resource(
                uri=AnyUrl("forge://workspace"),
                name="workspace",
                description=(
                    "Workspace-backed project inventory from ~/.forge/workspace.yaml."
                ),
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://graph/tree"),
                name="graph_tree",
                description=(
                    "Domain-grouped declaration graph for ForgeStructuralBrowser "
                    "(ForgeEngine.tree_view). Optional ?project_path= query param."
                ),
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://schema/manifest/v1"),
                name="schema_manifest_v1",
                description="Forge manifest schema v1",
                mimeType="text/yaml",
            ),
            types.Resource(
                uri=AnyUrl("forge://schema/manifest/v2"),
                name="schema_manifest_v2",
                description="Forge manifest schema v2",
                mimeType="text/yaml",
            ),
            types.Resource(
                uri=AnyUrl("forge://schema/annotations"),
                name="schema_annotations",
                description="Forge annotations schema",
                mimeType="text/yaml",
            ),
            types.Resource(
                uri=AnyUrl("forge://schema/command-contract"),
                name="schema_command_contract",
                description="Forge command contract schema",
                mimeType="text/yaml",
            ),
            types.Resource(
                uri=AnyUrl("forge://schema/registry"),
                name="schema_registry",
                description="Forge project registry schema",
                mimeType="text/yaml",
            ),
            types.Resource(
                uri=AnyUrl("forge://schema/errors"),
                name="schema_errors",
                description="ForgeError registry — registered_codes, total, schema_version",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://schema/taxonomy"),
                name="forge-schema-taxonomy",
                description=(
                    "NodeTier hierarchy, import rules, inference defaults, and query behavior. "
                    "Fetch this to understand forge's full primitive taxonomy without reading source."
                ),
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://schema/stacks/dart"),
                name="schema_stack_dart",
                description="Dart stack schema",
                mimeType="text/yaml",
            ),
            types.Resource(
                uri=AnyUrl("forge://schema/stacks/python"),
                name="schema_stack_python",
                description="Python stack schema",
                mimeType="text/yaml",
            ),
            types.Resource(
                uri=AnyUrl("forge://cowork/skill/forge-start"),
                name="cowork_skill_forge_start",
                description="Cowork forge-start skill markdown",
                mimeType="text/markdown",
            ),
            types.Resource(
                uri=AnyUrl("forge://glove/filesystem/local"),
                name="glove_filesystem_local",
                description="Filesystem glove descriptor — fs_write_file, fs_read_file, fs_list_dir within ~/Projects",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://docs/adr"),
                name="docs_adr_index",
                description="List of available ADR files",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://mcp/surface"),
                name="mcp_surface",
                description="Live MCP capability inventory — tools, resources, templates, and 2 prompts (forge/start, forge/audit)",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://mcp/roots"),
                name="mcp_roots",
                description="Intended MCP roots derived from server path + workspace.yaml projects",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://mcp/resource_guide"),
                name="mcp_resource_guide",
                description="When to use resources vs tools — fetch rules for the resource layer",
                mimeType="text/plain",
            ),
            types.Resource(
                uri=AnyUrl("forge://events/recent"),
                name="events_recent",
                description="Recent events from auto-append event log",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://events/query"),
                name="events_query",
                description="Query events from auto-append event log with filters",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://events/stats"),
                name="events_stats",
                description="Event log statistics and summary",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://events/types"),
                name="events_types",
                description="Available event types for querying",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://memory/search"),
                name="memory_search",
                description="Search vector memory for semantic similarity",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://memory/recent"),
                name="memory_recent",
                description="Recent entries from vector memory",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://memory/stats"),
                name="memory_stats",
                description="Vector memory statistics and summary",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://memory/entry"),
                name="memory_entry",
                description="Individual vector memory entry by ID",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://tasks/list"),
                name="tasks_list",
                description="List MCP tasks with optional filtering",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://tasks/get"),
                name="tasks_get",
                description="Get individual MCP task by ID",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://tasks/cancel"),
                name="tasks_cancel",
                description="Cancel MCP task by ID",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://tasks/stats"),
                name="tasks_stats",
                description="MCP tasks statistics and summary",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://apps/list"),
                name="apps_list",
                description="List Forge Apps with optional filtering",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://apps/get"),
                name="apps_get",
                description="Get individual Forge App by ID",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://apps/search"),
                name="apps_search",
                description="Search Forge App capabilities",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://framework/discover"),
                name="framework_discover",
                description="Discover framework structure and create execution graph",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://framework/trace"),
                name="framework_trace",
                description="Trace framework execution from entry point",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://framework/verify"),
                name="framework_verify",
                description="Verify framework against user intents",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://framework/onboard"),
                name="framework_onboard",
                description="Create onboarding package for existing framework",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://unified/discover"),
                name="unified_discover",
                description="Unified framework + memory + semantic discovery",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://unified/analyze"),
                name="unified_analyze",
                description="Deep cross-system analysis and recommendations",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://unified/migrate"),
                name="unified_migrate",
                description="Complete project migration with all systems",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://unified/status"),
                name="unified_status",
                description="Status of all unified systems",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://apps/capabilities"),
                name="apps_capabilities",
                description="Get capabilities for a specific Forge App",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://apps/stats"),
                name="apps_stats",
                description="Forge Apps registry statistics",
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://project/{id}/context"),
                name="Project Context Bundle",
                description=(
                    "Assembled agent context for a project. "
                    "Use instead of forge_context tool. "
                    "Replace {id} with project name."
                ),
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://project/{id}/annotations"),
                name="Project Annotations",
                description=(
                    "Open annotation records for a project. "
                    "Replace {id} with project name."
                ),
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://project/{id}/intent"),
                name="Project Intent Records",
                description=(
                    "Intent graph records for a project. "
                    "Replace {id} with project name."
                ),
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://inspect/{handle}"),
                name="Cursor Inspection State",
                description=(
                    "Active GraphCursor state for a handle. "
                    "Use after forge_inspect action=node. "
                    "Replace {handle} with cursor handle."
                ),
                mimeType="application/json",
            ),
            types.Resource(
                uri=AnyUrl("forge://schema/stacks/web"),
                name="Web/Astro Stack Schema",
                description=(
                    "Stack schema for web/astro projects. "
                    "Valid node kinds and fields."
                ),
                mimeType="application/x-yaml",
            ),
            types.Resource(
                uri=AnyUrl("forge://schema/stacks/astro"),
                name="Astro Stack Schema",
                description="Live Astro BuiltinStackProfile (exp form via bridge)",
                mimeType="application/x-yaml",
            ),
            types.Resource(
                uri=AnyUrl("forge://schema/stack-registry"),
                name="Stack Profile Registry",
                description=(
                    "All registered stack profiles with impact rules, node kinds, "
                    "glove keys. Use to discover valid stacks before "
                    "forge_manifest_append or forge_scaffold."
                ),
                mimeType="application/json",
            ),
        ]
        
        # Apply resource hygiene filtering - only meta-resources at startup
        # On-demand resources will be loaded when requested via read_resource
        return classify_startup_resources(all_resources)

    @server.list_resource_templates()
    async def _list_templates() -> list[types.ResourceTemplate]:
        return [
            types.ResourceTemplate(
                name="project_manifest",
                uriTemplate="forge://project/{projectId}/manifest",
                description="Raw canonical manifest YAML for a registry project id",
                mimeType="text/yaml",
            ),
            types.ResourceTemplate(
                name="project_annotations",
                uriTemplate="forge://project/{projectId}/annotations",
                description="Raw forge/annotations/index.yaml for a project",
                mimeType="text/yaml",
            ),
            types.ResourceTemplate(
                name="project_context",
                uriTemplate="forge://project/{projectId}/context",
                description="JSON context bundle from .forge/agent_context.json",
                mimeType="application/json",
            ),
            types.ResourceTemplate(
                name="project_memory_search",
                uriTemplate="forge://project/{projectId}/memory/search",
                description="Search project's vector memory for semantic similarity",
                mimeType="application/json",
            ),
            types.ResourceTemplate(
                name="project_tasks_list",
                uriTemplate="forge://project/{projectId}/tasks/list",
                description="List project's MCP tasks with filtering",
                mimeType="application/json",
            ),
            types.ResourceTemplate(
                name="project_apps_list",
                uriTemplate="forge://project/{projectId}/apps/list",
                description="List project's Forge Apps with filtering",
                mimeType="application/json",
            ),
            types.ResourceTemplate(
                name="project_intent",
                uriTemplate="forge://project/{projectId}/intent",
                description="Intent records from .forge/intent/project.intent.yaml",
                mimeType="application/json",
            ),
            types.ResourceTemplate(
                name="glove_family",
                uriTemplate="forge://glove/{gloveId}",
                description="List all templates for a glove family",
                mimeType="application/json",
            ),
            types.ResourceTemplate(
                name="glove_template",
                uriTemplate="forge://glove/{gloveId}/{stack}",
                description="Show template payload for glove kind and stack",
                mimeType="application/json",
            ),
            types.ResourceTemplate(
                name="glove_filesystem_local",
                uriTemplate="forge://glove/filesystem/local",
                description="Local filesystem glove — fs_glove MCP tools under ~/Projects (emit / pipeline fs_write steps)",
                mimeType="application/json",
            ),
            types.ResourceTemplate(
                name="docs_adr_entry",
                uriTemplate="forge://docs/adr/{adrId}",
                description="Read one ADR markdown by ADR id match",
                mimeType="text/markdown",
            ),
            types.ResourceTemplate(
                name="pipeline_descriptor",
                uriTemplate="forge://pipeline/{pipelineId}",
                description="Pipeline compositor descriptor (PipelineDescriptor JSON from .forge/pipelines/)",
                mimeType="application/json",
            ),
        ]

    @server.read_resource()
    async def _read_resource(uri: AnyUrl) -> str:
        from forge.mcp.workspace import (
            build_workspace_registry_payload,
            list_adrs,
            list_glove_family,
            read_adr_by_id,
            read_cowork_skill,
            read_project_annotations,
            read_project_intent,
            read_project_context_bundle,
            read_pipeline_descriptor_json,
            read_mcp_roots,
            read_glove_filesystem_local_json,
            read_taxonomy_json,
            read_schema_resource,
            resolve_manifest_file,
            resolve_project_path,
            show_glove_template,
            list_intended_roots,
        )

        u = str(uri)
        for prefix, handler in registry.resource_handlers():
            if u.startswith(prefix):
                return await handler(u)

        if u.rstrip("/") == "forge://workspace":
            payload = build_workspace_registry_payload()
            return json.dumps(payload, indent=2)

        if u.rstrip("/") == "forge://mcp/roots":
            return read_mcp_roots(server_root)

        if u.rstrip("/") == "forge://mcp/surface":
            all_tool_names = sorted(TOOL_MAPPING.keys())
            tool_names = [n for n in all_tool_names if n not in HIDDEN_TOOLS]
            resources = await _list_resources()
            templates = await _list_templates()
            payload = {
                "tools": tool_names,
                "hidden_tools": sorted(HIDDEN_TOOLS),
                "resources": [str(r.uri) for r in resources],
                "templates": [t.uriTemplate for t in templates],
                "prompts": [p.name for p in forge_prompts.FORGE_PROMPTS],
                "roots": list_intended_roots(server_root),
                "generated_at": datetime.now(timezone.utc).isoformat(),
            }
            return json.dumps(payload, indent=2)

        if u.rstrip("/") == "forge://mcp/resource_guide":
            return MCP_RESOURCE_GUIDE_TEXT

        if u.rstrip("/") == "forge://schema/taxonomy":
            return read_taxonomy_json()

        if u.rstrip("/") == "forge://schema/stack-registry":
            from forge.core.stack_profiles import get_stack_profile_registry

            reg = get_stack_profile_registry()
            return json.dumps(reg.to_summary_dict(), indent=2)

        if u.startswith("forge://schema/stacks/"):
            stack_id = u.replace("forge://schema/stacks/", "", 1).strip("/").split("?")[0]
            try:
                import yaml
                from forge.core.stack_profiles import (
                    BuiltinStackProfile,
                    get_stack_profile,
                    stack_profile_to_yaml_dict,
                )

                prof = get_stack_profile(stack_id)
                if isinstance(prof, BuiltinStackProfile) and prof.id != "unknown":
                    return yaml.safe_dump(
                        stack_profile_to_yaml_dict(prof),
                        sort_keys=False,
                        allow_unicode=True,
                    )
            except Exception:
                pass
            schema_text = read_schema_resource(
                f"forge://schema/stacks/{stack_id}".rstrip("/"),
                server_root,
            )
            if schema_text:
                return schema_text
            return f"error: stack schema {stack_id!r} not found"

        if u.startswith("forge://schema/manifest/v2/"):
            field_path = u.replace("forge://schema/manifest/v2/", "", 1).strip("/")
            if field_path.startswith("fields/"):
                field_name = field_path.replace("fields/", "", 1)
                schema_text = read_schema_resource(
                    "forge://schema/manifest/v2",
                    server_root,
                )
                if schema_text:
                    import yaml

                    try:
                        schema = yaml.safe_load(schema_text)
                        fields = (
                            schema.get("properties", {})
                            or schema.get("fields", {})
                            or schema.get("allowed_node_fields", {})
                        )
                        if field_name in fields:
                            return json.dumps(
                                {
                                    "field": field_name,
                                    "definition": fields[field_name],
                                },
                                indent=2,
                            )
                        return json.dumps(
                            {
                                "error": f"field {field_name!r} not found",
                                "available": list(fields.keys())[:20],
                            },
                            indent=2,
                        )
                    except Exception as e:
                        return f"error: {e}"

        if u.startswith("forge://schema/"):
            base_uri, _, _qs = u.partition("?")
            schema_text = read_schema_resource(base_uri.rstrip("/"), server_root)
            if schema_text is not None:
                return schema_text

        if u.startswith("forge://pipeline/"):
            rest = u.replace("forge://pipeline/", "", 1).strip("/").split("/")
            pipeline_id = rest[0] if rest else ""
            pip_text = read_pipeline_descriptor_json(server_root, pipeline_id)
            if pip_text is not None:
                return pip_text
            return f"error: pipeline '{pipeline_id}' not found under .forge/pipelines/"

        if u.rstrip("/") == "forge://cowork/skill/forge-start":
            return read_cowork_skill(server_root)

        if u.rstrip("/") == "forge://docs/adr":
            return list_adrs(server_root)

        if u.startswith("forge://docs/adr/"):
            adr_id = u.replace("forge://docs/adr/", "", 1).strip("/")
            if adr_id:
                return read_adr_by_id(server_root, adr_id)

        if u.rstrip("/") == "forge://glove/filesystem/local":
            return read_glove_filesystem_local_json()

        if u.startswith("forge://glove/"):
            parts = u.replace("forge://", "").strip("/").split("/")
            if len(parts) == 2 and parts[0] == "glove":
                glove_id = parts[1]
                return list_glove_family(glove_id)
            if len(parts) == 3 and parts[0] == "glove":
                glove_id = parts[1]
                stack = parts[2]
                return show_glove_template(glove_id, stack)

        if u.startswith("forge://project/") and u.endswith("/manifest"):
            parts = u.replace("forge://", "").strip("/").split("/")
            if len(parts) >= 3 and parts[0] == "project":
                project_id = parts[1]
                root = resolve_project_path(project_id)
                if root is None:
                    return f"error: project '{project_id}' not found"
                mf = resolve_manifest_file(root)
                if not mf.is_file():
                    return f"error: manifest not found at {mf}"
                return mf.read_text(encoding="utf-8")

        if u.startswith("forge://project/") and "/annotations" in u:
            base, _, qs = u.partition("?")
            params: dict[str, str] = {}
            for pair in qs.split("&") if qs else []:
                k, _, v = pair.partition("=")
                if k:
                    params[k.strip()] = v.strip()
            parts = base.replace("forge://", "").strip("/").split("/")
            if len(parts) >= 3 and parts[0] == "project":
                project_id = parts[1]
                raw = read_project_annotations(project_id)
                if params:
                    try:
                        data = json.loads(raw)
                        ann_list = (
                            data
                            if isinstance(data, list)
                            else data.get("annotations", [])
                        )
                        if params.get("status"):
                            ann_list = [
                                a
                                for a in ann_list
                                if a.get("status") == params["status"]
                            ]
                        if params.get("kind"):
                            ann_list = [
                                a
                                for a in ann_list
                                if a.get("kind") == params["kind"]
                            ]
                        if params.get("node_id"):
                            nid = params["node_id"]
                            ann_list = [
                                a
                                for a in ann_list
                                if nid in (a.get("affects", "") or "")
                            ]
                        return json.dumps(
                            {
                                "annotations": ann_list,
                                "count": len(ann_list),
                                "filters": params,
                            },
                            indent=2,
                        )
                    except Exception:
                        pass
                return raw

        if u.startswith("forge://project/") and "/context" in u:
            base, _, _qs = u.partition("?")
            parts = base.replace("forge://", "").strip("/").split("/")
            if len(parts) >= 3 and parts[0] == "project":
                return read_project_context_bundle(parts[1])

        if u.startswith("forge://project/") and "/intent" in u:
            base, _, qs = u.partition("?")
            params = {}
            for pair in qs.split("&") if qs else []:
                k, _, v = pair.partition("=")
                if k:
                    params[k.strip()] = v.strip()
            parts = base.replace("forge://", "").strip("/").split("/")
            if len(parts) >= 3 and parts[0] == "project":
                project_id = parts[1]
                raw = read_project_intent(project_id)
                if params:
                    try:
                        data = json.loads(raw)
                        records = data.get("records", [])
                        if params.get("node_id"):
                            nid = params["node_id"]
                            records = [
                                r
                                for r in records
                                if r.get("target_id", "") == nid
                            ]
                        if params.get("status"):
                            records = [
                                r
                                for r in records
                                if r.get("status", "") == params["status"]
                            ]
                        return json.dumps(
                            {
                                "records": records,
                                "count": len(records),
                                "filters": params,
                            },
                            indent=2,
                        )
                    except Exception:
                        pass
                return raw

        if u.startswith("forge://inspect/"):
            base, _, qs = u.partition("?")
            params = {}
            for pair in qs.split("&") if qs else []:
                k, _, v = pair.partition("=")
                if k:
                    params[k.strip()] = v.strip()
            handle = base.replace("forge://inspect/", "", 1).strip("/")
            if handle:
                from forge.engine.cursor import CursorRegistry

                cursor = CursorRegistry.get(handle)
                if cursor is None:
                    return json.dumps(
                        {
                            "error": f"Cursor {handle!r} not found or expired",
                            "hint": "Call forge_inspect action=node to create a new cursor",
                        }
                    )
                if params.get("ring"):
                    ring_num = int(params["ring"])
                    ring_ids = cursor.get_ring(ring_num)
                    return json.dumps(
                        {
                            "handle": handle,
                            "ring": ring_num,
                            "count": len(ring_ids),
                            "ids": ring_ids,
                        },
                        indent=2,
                    )
                return json.dumps(cursor.to_packet_dict(), indent=2)

        return f"Unsupported resource URI: {u}"

    @server.list_prompts()
    async def _list_prompts() -> list[types.Prompt]:
        return forge_prompts.FORGE_PROMPTS

    @server.get_prompt()
    async def _get_prompt(name: str, arguments: dict[str, str] | None) -> types.GetPromptResult:
        from forge.mcp.mcp_workspace import bind_mcp_session_context
        from forge.mcp.session_context import reset_session_context_token

        _prompt_sess_tok = bind_mcp_session_context()
        try:
            messages = forge_prompts.render_prompt_messages(
                prompt_name=name,
                arguments=arguments or {},
                resolve_project_id=_resolve_project_id_for_prompt,
            )
            return forge_prompts.prompt_result_from_messages(messages)
        finally:
            reset_session_context_token(_prompt_sess_tok)

    # Register event log resources
    register_event_resources(registry)

    # Register workspace graph tree (ForgeStructuralBrowser)
    register_workspace_graph_resources(registry)

    # Register vector memory resources
    register_memory_resources(registry)

    # Register tasks resources
    register_tasks_resources(registry)

    # Register apps resources
    register_apps_resources(registry)

    # Register framework mapping resources
    from forge.mcp.framework_resources import register_framework_resources
    register_framework_resources(registry)

    # Register unified resources (world's most versatile MCP)
    from forge.mcp.unified_resources import register_unified_resources
    register_unified_resources(registry)

    return server


async def run_mcp_server() -> None:
    import logging

    logging.basicConfig(
        level=logging.DEBUG,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
        stream=__import__("sys").stderr,
    )
    logging.getLogger("forge.mcp").info(
        "resource subscriptions: %s",
        "supported" if SUBSCRIPTION_SUPPORTED else "pending SDK support",
    )
    write_mcp_session_file(
        active_project=str(Path.cwd()),
        session_id=f"mcp-session-{int(time.time())}"
    )
    server = _build_server(project_root=Path.cwd())
    init = server.create_initialization_options()
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, init)


def run_mcp_stdio() -> None:
    try:
        asyncio.run(run_mcp_server())
    except KeyboardInterrupt:
        pass


def main() -> None:
    run_mcp_stdio()


__all__ = ["main", "run_mcp_stdio", "run_mcp_server", "_build_server"]
