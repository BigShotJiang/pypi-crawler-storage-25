"""WebSocket client management for Forge MCP server.

Provides client connection management, reconnection logic, and connection pooling
for WebSocket transport clients.
"""

import asyncio
import json
import logging
import time
from typing import Any, Dict, Optional, Set, Callable
from dataclasses import dataclass, field
from enum import Enum
from uuid import uuid4

import websockets
from websockets.client import WebSocketClientProtocol

logger = logging.getLogger(__name__)


class ConnectionState(Enum):
    """WebSocket connection states."""
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    RECONNECTING = "reconnecting"
    FAILED = "failed"


@dataclass
class WebSocketClientConfig:
    """Configuration for WebSocket client."""
    url: str
    max_reconnect_attempts: int = 5
    reconnect_delay: float = 1.0
    reconnect_backoff_factor: float = 2.0
    max_reconnect_delay: float = 30.0
    ping_interval: float = 20.0
    ping_timeout: float = 10.0
    close_timeout: float = 10.0
    compression: Optional[str] = None
    request_timeout: float = 120.0  # Configurable request timeout
    
    @classmethod
    def from_environment(cls, url: str) -> "WebSocketClientConfig":
        """Create configuration from environment variables."""
        import os
        
        # Get timeout from environment, default to 120 seconds for production
        request_timeout = float(os.environ.get("FORGE_MCP_REQUEST_TIMEOUT", "120.0"))
        
        # Ensure reasonable bounds (30s minimum, 300s maximum)
        request_timeout = max(30.0, min(300.0, request_timeout))
        
        return cls(
            url=url,
            request_timeout=request_timeout,
            # Also make other timeouts configurable
            ping_interval=float(os.environ.get("FORGE_MCP_PING_INTERVAL", "20.0")),
            ping_timeout=float(os.environ.get("FORGE_MCP_PING_TIMEOUT", "10.0")),
            close_timeout=float(os.environ.get("FORGE_MCP_CLOSE_TIMEOUT", "10.0")),
            max_reconnect_attempts=int(os.environ.get("FORGE_MCP_MAX_RECONNECT_ATTEMPTS", "5")),
        )


@dataclass
class ClientMetrics:
    """Metrics for WebSocket client connections."""
    connection_count: int = 0
    total_messages_sent: int = 0
    total_messages_received: int = 0
    last_connection_time: Optional[float] = None
    last_message_time: Optional[float] = None
    reconnection_count: int = 0
    failed_connections: int = 0


class WebSocketClient:
    """Managed WebSocket client with reconnection and metrics."""
    
    def __init__(self, config: WebSocketClientConfig, client_id: Optional[str] = None):
        self.config = config
        self.client_id = client_id or str(uuid4())
        self.state = ConnectionState.DISCONNECTED
        self.websocket: Optional[WebSocketClientProtocol] = None
        self.metrics = ClientMetrics()
        self._reconnect_attempts = 0
        self._message_handlers: Dict[str, Set[Callable]] = {}
        self._connection_callbacks: Set[Callable] = set()
        self._disconnection_callbacks: Set[Callable] = set()
        self._error_callbacks: Set[Callable] = set()
        self._running = False
        self._connection_task: Optional[asyncio.Task] = None
    
    def add_message_handler(self, method: str, handler: Callable) -> None:
        """Add a handler for specific message methods."""
        if method not in self._message_handlers:
            self._message_handlers[method] = set()
        self._message_handlers[method].add(handler)
    
    def remove_message_handler(self, method: str, handler: Callable) -> None:
        """Remove a message handler."""
        if method in self._message_handlers:
            self._message_handlers[method].discard(handler)
    
    def add_connection_callback(self, callback: Callable) -> None:
        """Add callback for connection events."""
        self._connection_callbacks.add(callback)
    
    def add_disconnection_callback(self, callback: Callable) -> None:
        """Add callback for disconnection events."""
        self._disconnection_callbacks.add(callback)
    
    def add_error_callback(self, callback: Callable) -> None:
        """Add callback for error events."""
        self._error_callbacks.add(callback)
    
    async def connect(self) -> bool:
        """Connect to WebSocket server."""
        if self.state in (ConnectionState.CONNECTING, ConnectionState.CONNECTED):
            return True
        
        self.state = ConnectionState.CONNECTING
        self.metrics.connection_count += 1
        
        try:
            logger.info(f"Connecting to WebSocket server: {self.config.url}")
            
            # Set connection options
            extra_headers = {
                "User-Agent": f"forge-ws-client/{self.client_id}"
            }
            
            self.websocket = await websockets.connect(
                self.config.url,
                ping_interval=self.config.ping_interval,
                ping_timeout=self.config.ping_timeout,
                close_timeout=self.config.close_timeout,
                compression=self.config.compression,
                extra_headers=extra_headers
            )
            
            self.state = ConnectionState.CONNECTED
            self.metrics.last_connection_time = time.time()
            self._reconnect_attempts = 0
            
            logger.info(f"Connected to WebSocket server: {self.client_id}")
            
            # Notify connection callbacks
            for callback in self._connection_callbacks:
                try:
                    await callback(self)
                except Exception as e:
                    logger.error(f"Error in connection callback: {e}")
            
            return True
            
        except Exception as e:
            self.state = ConnectionState.FAILED
            self.metrics.failed_connections += 1
            logger.error(f"Failed to connect to WebSocket server: {e}")
            
            # Notify error callbacks
            for callback in self._error_callbacks:
                try:
                    await callback(self, e)
                except Exception as callback_error:
                    logger.error(f"Error in error callback: {callback_error}")
            
            return False
    
    async def disconnect(self) -> None:
        """Disconnect from WebSocket server."""
        self._running = False
        
        if self.websocket:
            try:
                await self.websocket.close()
            except Exception as e:
                logger.warning(f"Error closing WebSocket connection: {e}")
            finally:
                self.websocket = None
        
        self.state = ConnectionState.DISCONNECTED
        
        # Notify disconnection callbacks
        for callback in self._disconnection_callbacks:
            try:
                await callback(self)
            except Exception as e:
                logger.error(f"Error in disconnection callback: {e}")
    
    async def send_message(self, message: Dict[str, Any]) -> None:
        """Send a message to the WebSocket server."""
        if not self.websocket or self.state != ConnectionState.CONNECTED:
            raise ConnectionError("Not connected to WebSocket server")
        
        try:
            await self.websocket.send(json.dumps(message))
            self.metrics.total_messages_sent += 1
            self.metrics.last_message_time = time.time()
        except Exception as e:
            logger.error(f"Failed to send message: {e}")
            self.state = ConnectionState.FAILED
            raise
    
    async def send_request(self, method: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Send a JSON-RPC request and wait for response."""
        message_id = str(uuid4())
        request = {
            "jsonrpc": "2.0",
            "id": message_id,
            "method": method,
            "params": params or {}
        }
        
        # Create a future to wait for response
        response_future = asyncio.Future()
        
        # Add temporary handler for this response
        def handle_response(response: Dict[str, Any]) -> None:
            if response.get("id") == message_id:
                if not response_future.done():
                    response_future.set_result(response)
                # Remove handler after receiving response
                self.remove_message_handler("response", handle_response)
        
        self.add_message_handler("response", handle_response)
        
        try:
            await self.send_message(request)
            response = await asyncio.wait_for(response_future, timeout=self.config.request_timeout)
            return response
        except asyncio.TimeoutError:
            self.remove_message_handler("response", handle_response)
            raise TimeoutError(f"Request timeout for method: {method} after {self.config.request_timeout}s")
    
    async def _handle_message(self, message: str) -> None:
        """Handle incoming message from WebSocket server."""
        try:
            data = json.loads(message)
            self.metrics.total_messages_received += 1
            self.metrics.last_message_time = time.time()
            
            # Route message to appropriate handlers
            method = data.get("method", "response")
            if method in self._message_handlers:
                for handler in self._message_handlers[method]:
                    try:
                        if asyncio.iscoroutinefunction(handler):
                            await handler(data)
                        else:
                            handler(data)
                    except Exception as e:
                        logger.error(f"Error in message handler for {method}: {e}")
            
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse message: {e}")
        except Exception as e:
            logger.error(f"Error handling message: {e}")
    
    async def _listen(self) -> None:
        """Listen for messages from WebSocket server."""
        while self._running and self.websocket:
            try:
                message = await self.websocket.recv()
                await self._handle_message(message)
            except websockets.exceptions.ConnectionClosed:
                logger.info("WebSocket connection closed")
                break
            except Exception as e:
                logger.error(f"Error receiving message: {e}")
                break
    
    async def start(self) -> None:
        """Start the WebSocket client with automatic reconnection."""
        self._running = True
        
        while self._running:
            if await self.connect():
                try:
                    await self._listen()
                except Exception as e:
                    logger.error(f"Error in message listener: {e}")
            
            # Handle reconnection if still running
            if self._running and self._reconnect_attempts < self.config.max_reconnect_attempts:
                self.state = ConnectionState.RECONNECTING
                self._reconnect_attempts += 1
                self.metrics.reconnection_count += 1
                
                # Calculate reconnection delay with exponential backoff
                delay = min(
                    self.config.reconnect_delay * (self.config.reconnect_backoff_factor ** (self._reconnect_attempts - 1)),
                    self.config.max_reconnect_delay
                )
                
                logger.info(f"Reconnecting in {delay:.1f} seconds (attempt {self._reconnect_attempts}/{self.config.max_reconnect_attempts})")
                await asyncio.sleep(delay)
            else:
                self.state = ConnectionState.FAILED
                break
    
    async def stop(self) -> None:
        """Stop the WebSocket client."""
        await self.disconnect()
    
    def get_metrics(self) -> ClientMetrics:
        """Get client connection metrics."""
        return self.metrics
    
    def is_connected(self) -> bool:
        """Check if client is connected."""
        return self.state == ConnectionState.CONNECTED and self.websocket is not None


class WebSocketClientManager:
    """Manages multiple WebSocket client connections."""
    
    def __init__(self):
        self._clients: Dict[str, WebSocketClient] = {}
        self._default_config = WebSocketClientConfig(url="ws://localhost:7777/mcp")
    
    def create_client(self, url: str, client_id: Optional[str] = None, **kwargs) -> WebSocketClient:
        """Create a new WebSocket client."""
        # Use environment-aware configuration by default
        config = WebSocketClientConfig.from_environment(url)
        # Allow override via kwargs
        for key, value in kwargs.items():
            if hasattr(config, key):
                setattr(config, key, value)
        client = WebSocketClient(config, client_id)
        self._clients[client.client_id] = client
        return client
    
    def get_client(self, client_id: str) -> Optional[WebSocketClient]:
        """Get a client by ID."""
        return self._clients.get(client_id)
    
    def remove_client(self, client_id: str) -> Optional[WebSocketClient]:
        """Remove a client."""
        return self._clients.pop(client_id, None)
    
    async def connect_all(self) -> None:
        """Connect all clients."""
        tasks = [client.start() for client in self._clients.values()]
        await asyncio.gather(*tasks, return_exceptions=True)
    
    async def disconnect_all(self) -> None:
        """Disconnect all clients."""
        tasks = [client.stop() for client in self._clients.values()]
        await asyncio.gather(*tasks, return_exceptions=True)
    
    def get_all_metrics(self) -> Dict[str, ClientMetrics]:
        """Get metrics for all clients."""
        return {client_id: client.get_metrics() for client_id, client in self._clients.items()}
    
    def get_connected_clients(self) -> list[WebSocketClient]:
        """Get list of connected clients."""
        return [client for client in self._clients.values() if client.is_connected()]


# Global client manager instance
_client_manager = WebSocketClientManager()


def get_client_manager() -> WebSocketClientManager:
    """Get the global WebSocket client manager."""
    return _client_manager


async def create_default_client(url: str = "ws://localhost:7777/mcp", **kwargs) -> WebSocketClient:
    """Create a default WebSocket client."""
    return _client_manager.create_client(url, **kwargs)


__all__ = [
    "ConnectionState",
    "WebSocketClientConfig", 
    "ClientMetrics",
    "WebSocketClient",
    "WebSocketClientManager",
    "get_client_manager",
    "create_default_client"
]
