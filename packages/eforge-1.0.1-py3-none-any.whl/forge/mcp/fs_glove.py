"""
Standalone FastMCP server — local filesystem read/write within ~/Projects.
ForgeError codes are registered in forge.core.schemas (FS-001..FS-003).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from fastmcp import FastMCP
from mcp.types import ToolAnnotations
from pydantic import BaseModel, Field

from forge.core.schemas import make_error

ALLOWED_ROOT = (Path.home() / "Projects").expanduser().resolve()

mcp = FastMCP("forge-fs-glove")


class WriteResult(BaseModel):
    written: str
    bytes_written: int


class ReadResult(BaseModel):
    content: str
    path: str


class ListResult(BaseModel):
    entries: list[dict[str, Any]] = Field(default_factory=list)
    path: str


def _safe_path(relative: str) -> Path:
    """Resolve path under ALLOWED_ROOT; raises ValueError if outside."""
    rel = (relative or "").strip().lstrip("/")
    target = (ALLOWED_ROOT / rel).resolve()
    try:
        target.relative_to(ALLOWED_ROOT)
    except ValueError as exc:
        raise ValueError("FS-001") from exc
    return target


@mcp.tool(
    annotations=ToolAnnotations(destructiveHint=True),
)
def fs_write_file(path: str, content: str) -> dict[str, Any]:
    """Write content to a file within ~/Projects."""
    try:
        target = _safe_path(path)
    except ValueError:
        return make_error(
            "FS-001",
            source_tool="fs_write_file",
            context={"path": path},
        ).model_dump(mode="json")
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return WriteResult(
            written=str(target),
            bytes_written=len(content.encode("utf-8")),
        ).model_dump(mode="json")
    except Exception as e:
        return make_error(
            "FS-003",
            source_tool="fs_write_file",
            context={"exception": str(e), "path": str(target)},
        ).model_dump(mode="json")


@mcp.tool(
    annotations=ToolAnnotations(readOnlyHint=True, idempotentHint=True),
)
def fs_read_file(path: str) -> dict[str, Any]:
    """Read a file within ~/Projects."""
    try:
        target = _safe_path(path)
    except ValueError:
        return make_error(
            "FS-001",
            source_tool="fs_read_file",
            context={"path": path},
        ).model_dump(mode="json")
    if not target.is_file():
        return make_error(
            "FS-002",
            source_tool="fs_read_file",
            context={"path": path},
        ).model_dump(mode="json")
    try:
        body = target.read_text(encoding="utf-8")
        return ReadResult(content=body, path=str(target)).model_dump(mode="json")
    except Exception as e:
        return make_error(
            "FS-003",
            source_tool="fs_read_file",
            context={"exception": str(e), "path": str(target)},
        ).model_dump(mode="json")


@mcp.tool(
    annotations=ToolAnnotations(readOnlyHint=True, idempotentHint=True),
)
def fs_list_dir(path: str = "") -> dict[str, Any]:
    """List directory contents within ~/Projects."""
    try:
        target = _safe_path(path) if path.strip() else ALLOWED_ROOT
    except ValueError:
        return make_error(
            "FS-001",
            source_tool="fs_list_dir",
            context={"path": path},
        ).model_dump(mode="json")
    try:
        entries = [
            {"name": e.name, "kind": "dir" if e.is_dir() else "file"}
            for e in sorted(target.iterdir())
        ]
        return ListResult(entries=entries, path=str(target)).model_dump(mode="json")
    except Exception as e:
        return make_error(
            "FS-003",
            source_tool="fs_list_dir",
            context={"exception": str(e), "path": str(target)},
        ).model_dump(mode="json")


if __name__ == "__main__":
    mcp.run()
