"""MCP resource handlers for Tasks and Apps (INTENT-344E846B).

Provides forge://tasks/* and forge://apps/* resource surfaces for
querying and managing long-running operations and structured capabilities.
"""

import json
import logging
from typing import Any, Dict, List, Optional

from forge.core.mcp_tasks import get_task_manager, TaskStatus
from forge.core.forge_apps import get_app_registry, AppType
from forge.core.path_utils import resolve_project_path

logger = logging.getLogger(__name__)


def read_tasks_resource(uri: str) -> str:
    """Read tasks resource based on URI."""
    try:
        # Parse URI: forge://tasks/{query_type}?{params}
        if not uri.startswith("forge://tasks/"):
            raise ValueError(f"Invalid tasks resource URI: {uri}")
        
        path_part = uri[13:]  # Remove "forge://tasks/"
        
        if "?" in path_part:
            query_type, params_str = path_part.split("?", 1)
            params = parse_query_params(params_str)
        else:
            query_type = path_part
            params = {}
        
        project_path = params.get("project_path")
        if not project_path:
            project_path = str(resolve_project_path())
        
        task_manager = get_task_manager(resolve_project_path(project_path))
        
        if query_type == "list":
            return handle_tasks_list(params, task_manager)
        
        elif query_type == "get":
            return handle_task_get(params, task_manager)
        
        elif query_type == "cancel":
            return handle_task_cancel(params, task_manager)
        
        elif query_type == "stats":
            return handle_tasks_stats(params, task_manager)
        
        else:
            raise ValueError(f"Unknown tasks resource type: {query_type}")
            
    except Exception as e:
        logger.error(f"Error reading tasks resource {uri}: {e}")
        return json.dumps({"error": str(e), "uri": uri})


def read_apps_resource(uri: str) -> str:
    """Read apps resource based on URI."""
    try:
        # Parse URI: forge://apps/{query_type}?{params}
        if not uri.startswith("forge://apps/"):
            raise ValueError(f"Invalid apps resource URI: {uri}")
        
        path_part = uri[12:]  # Remove "forge://apps/"
        
        if "?" in path_part:
            query_type, params_str = path_part.split("?", 1)
            params = parse_query_params(params_str)
        else:
            query_type = path_part
            params = {}
        
        project_path = params.get("project_path")
        if not project_path:
            project_path = str(resolve_project_path())
        
        app_registry = get_app_registry(resolve_project_path(project_path))
        
        if query_type == "list":
            return handle_apps_list(params, app_registry)
        
        elif query_type == "get":
            return handle_app_get(params, app_registry)
        
        elif query_type == "search":
            return handle_apps_search(params, app_registry)
        
        elif query_type == "capabilities":
            return handle_apps_capabilities(params, app_registry)
        
        elif query_type == "stats":
            return handle_apps_stats(params, app_registry)
        
        else:
            raise ValueError(f"Unknown apps resource type: {query_type}")
            
    except Exception as e:
        logger.error(f"Error reading apps resource {uri}: {e}")
        return json.dumps({"error": str(e), "uri": uri})


def parse_query_params(params_str: str) -> Dict[str, str]:
    """Parse query parameters from URL string."""
    params = {}
    for pair in params_str.split("&"):
        if "=" in pair:
            key, value = pair.split("=", 1)
            params[key] = value
    return params


# Tasks resource handlers
def handle_tasks_list(params: Dict[str, str], task_manager) -> str:
    """Handle tasks list queries."""
    try:
        status_filter = params.get("status")
        caller_filter = params.get("caller_id")
        limit = int(params.get("limit", 100))
        
        # Convert status filter to enum
        status_enum = None
        if status_filter:
            try:
                status_enum = TaskStatus(status_filter)
            except ValueError:
                pass
        
        tasks = task_manager.list_tasks(status_enum, caller_filter, limit)
        
        # Format tasks
        formatted_tasks = []
        for task in tasks:
            formatted_tasks.append(task.to_dict())
        
        return json.dumps({
            "query": "list",
            "status_filter": status_filter,
            "caller_filter": caller_filter,
            "limit": limit,
            "total_tasks": len(formatted_tasks),
            "tasks": formatted_tasks
        }, indent=2)
        
    except Exception as e:
        logger.error(f"Error handling tasks list: {e}")
        return json.dumps({"error": str(e), "query_params": params})


def handle_task_get(params: Dict[str, str], task_manager) -> str:
    """Handle individual task queries."""
    try:
        task_id = params.get("id")
        if not task_id:
            return json.dumps({
                "error": "Task ID parameter 'id' is required",
                "params": params
            })
        
        task = task_manager.get_task(task_id)
        if not task:
            return json.dumps({
                "error": f"Task not found: {task_id}",
                "task_id": task_id
            })
        
        return json.dumps({
            "query": "get",
            "task": task.to_dict()
        }, indent=2)
        
    except Exception as e:
        logger.error(f"Error handling task get: {e}")
        return json.dumps({"error": str(e), "query_params": params})


def handle_task_cancel(params: Dict[str, str], task_manager) -> str:
    """Handle task cancellation."""
    try:
        task_id = params.get("id")
        if not task_id:
            return json.dumps({
                "error": "Task ID parameter 'id' is required",
                "params": params
            })
        
        success = task_manager.cancel_task(task_id)
        
        return json.dumps({
            "query": "cancel",
            "task_id": task_id,
            "success": success
        }, indent=2)
        
    except Exception as e:
        logger.error(f"Error handling task cancel: {e}")
        return json.dumps({"error": str(e), "query_params": params})


def handle_tasks_stats(params: Dict[str, str], task_manager) -> str:
    """Handle task statistics queries."""
    try:
        stats = task_manager.get_task_stats()
        
        return json.dumps({
            "query": "stats",
            "stats": stats
        }, indent=2)
        
    except Exception as e:
        logger.error(f"Error handling tasks stats: {e}")
        return json.dumps({"error": str(e), "query_params": params})


# Apps resource handlers
def handle_apps_list(params: Dict[str, str], app_registry) -> str:
    """Handle apps list queries."""
    try:
        app_type_filter = params.get("type")
        domain_filter = params.get("domain")
        
        # Convert type filter to enum
        type_enum = None
        if app_type_filter:
            try:
                type_enum = AppType(app_type_filter)
            except ValueError:
                pass
        
        apps = app_registry.list_apps(type_enum, domain_filter)
        
        # Format apps
        formatted_apps = []
        for app in apps:
            formatted_apps.append(app.to_dict())
        
        return json.dumps({
            "query": "list",
            "type_filter": app_type_filter,
            "domain_filter": domain_filter,
            "total_apps": len(formatted_apps),
            "apps": formatted_apps
        }, indent=2)
        
    except Exception as e:
        logger.error(f"Error handling apps list: {e}")
        return json.dumps({"error": str(e), "query_params": params})


def handle_app_get(params: Dict[str, str], app_registry) -> str:
    """Handle individual app queries."""
    try:
        app_id = params.get("id")
        if not app_id:
            return json.dumps({
                "error": "App ID parameter 'id' is required",
                "params": params
            })
        
        app = app_registry.get_app(app_id)
        if not app:
            return json.dumps({
                "error": f"App not found: {app_id}",
                "app_id": app_id
            })
        
        return json.dumps({
            "query": "get",
            "app": app.to_dict()
        }, indent=2)
        
    except Exception as e:
        logger.error(f"Error handling app get: {e}")
        return json.dumps({"error": str(e), "query_params": params})


def handle_apps_search(params: Dict[str, str], app_registry) -> str:
    """Handle app capability searches."""
    try:
        query = params.get("q")
        capability_type = params.get("type")
        
        if not query:
            return json.dumps({
                "error": "Query parameter 'q' is required",
                "params": params
            })
        
        results = app_registry.search_capabilities(query, capability_type)
        
        return json.dumps({
            "query": "search",
            "search_query": query,
            "capability_type": capability_type,
            "total_results": len(results),
            "results": results
        }, indent=2)
        
    except Exception as e:
        logger.error(f"Error handling apps search: {e}")
        return json.dumps({"error": str(e), "query_params": params})


def handle_apps_capabilities(params: Dict[str, str], app_registry) -> str:
    """Handle app capabilities queries."""
    try:
        app_id = params.get("id")
        if not app_id:
            return json.dumps({
                "error": "App ID parameter 'id' is required",
                "params": params
            })
        
        capabilities = app_registry.get_app_capabilities(app_id)
        if not capabilities:
            return json.dumps({
                "error": f"App not found: {app_id}",
                "app_id": app_id
            })
        
        return json.dumps({
            "query": "capabilities",
            "app_id": app_id,
            "capabilities": {
                "tools": [c.__dict__ for c in capabilities["tools"]],
                "resources": [c.__dict__ for c in capabilities["resources"]],
                "prompts": [c.__dict__ for c in capabilities["prompts"]]
            }
        }, indent=2)
        
    except Exception as e:
        logger.error(f"Error handling apps capabilities: {e}")
        return json.dumps({"error": str(e), "query_params": params})


def handle_apps_stats(params: Dict[str, str], app_registry) -> str:
    """Handle app registry statistics queries."""
    try:
        stats = app_registry.get_registry_stats()
        
        return json.dumps({
            "query": "stats",
            "stats": stats
        }, indent=2)
        
    except Exception as e:
        logger.error(f"Error handling apps stats: {e}")
        return json.dumps({"error": str(e), "query_params": params})


def register_tasks_resources(registry) -> None:
    """Register tasks resource handlers with the MCP registry."""
    registry.register_resource("forge://tasks/", read_tasks_resource)


def register_apps_resources(registry) -> None:
    """Register apps resource handlers with the MCP registry."""
    registry.register_resource("forge://apps/", read_apps_resource)


__all__ = [
    "read_tasks_resource",
    "read_apps_resource",
    "register_tasks_resources",
    "register_apps_resources"
]
