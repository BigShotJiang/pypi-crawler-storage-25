"""Resource hygiene system for INTENT-36C163D4.

Classifies MCP resources into meta-resources (keep at startup), 
on-demand (remove from startup), or unnecessary (remove entirely).
"""

import logging
from enum import Enum
from typing import Dict, List, Optional, Set
from dataclasses import dataclass

import mcp.types as types

logger = logging.getLogger(__name__)


class ResourceCategory(Enum):
    """Resource classification categories."""
    META = "meta"          # Keep at startup - essential for MCP protocol
    ON_DEMAND = "on_demand"  # Remove from startup - load when requested
    UNNECESSARY = "unnecessary"  # Remove entirely - not needed


@dataclass
class ResourceClassification:
    """Classification result for a resource."""
    uri: str
    name: str
    category: ResourceCategory
    reason: str
    priority: int  # Lower number = higher priority for loading


class ResourceHygieneManager:
    """Manages resource hygiene and classification."""
    
    def __init__(self):
        self._classifications: Dict[str, ResourceClassification] = {}
        self._meta_resources: Set[str] = set()
        self._on_demand_resources: Set[str] = set()
        self._unnecessary_resources: Set[str] = set()
        
        # Initialize default classifications
        self._initialize_classifications()
    
    def _initialize_classifications(self) -> None:
        """Initialize default resource classifications."""
        
        # META resources - essential for MCP protocol startup
        meta_classifications = [
            ("forge://workspace", "workspace", 
             "Essential for project context - required for most operations", 1),
            ("forge://schema/taxonomy", "forge-schema-taxonomy",
             "Core taxonomy - needed for understanding forge primitives", 2),
            ("forge://schema/errors", "schema_errors",
             "Error registry - essential for error handling", 3),
        ]
        
        # ON_DEMAND resources - remove from startup, load when requested
        on_demand_classifications = [
            # Schema files - only needed when working with specific features
            ("forge://schema/manifest/v1", "schema_manifest_v1",
             "Legacy schema - only needed for v1 manifest compatibility", 20),
            ("forge://schema/manifest/v2", "schema_manifest_v2",
             "Current schema - only needed when validating manifests", 21),
            ("forge://schema/annotations", "schema_annotations",
             "Annotations schema - only needed for annotation operations", 22),
            ("forge://schema/command-contract", "schema_command_contract",
             "Command contract schema - only needed for command validation", 23),
            ("forge://schema/registry", "schema_registry",
             "Registry schema - only needed for registry operations", 24),
            ("forge://schema/stacks/dart", "schema_stack_dart",
             "Dart stack schema - only needed for Dart projects", 25),
            ("forge://schema/stacks/python", "schema_stack_python",
             "Python stack schema - only needed for Python projects", 26),
            
            # Dynamic resources - expensive to compute at startup
            ("forge://mcp/surface", "mcp_surface",
             "Live capability inventory - expensive to compute, load on demand", 30),
            ("forge://mcp/roots", "mcp_roots",
             "MCP roots - only needed when working with multiple projects", 31),
            ("forge://glove/filesystem/local", "glove_filesystem_local",
             "Filesystem glove - only needed when working with local files", 32),
            
            # Documentation and guides
            ("forge://docs/adr", "docs_adr_index",
             "ADR index - only needed when consulting architecture decisions", 40),
            ("forge://mcp/resource_guide", "mcp_resource_guide",
             "Resource guide - only needed for learning about resources", 41),
            ("forge://cowork/skill/forge-start", "cowork_skill_forge_start",
             "Cowork skill - only needed when using cowork features", 42),
        ]
        
        # UNNECESSARY resources - remove entirely (deprecated or redundant)
        unnecessary_classifications = [
            # Add any resources that should be completely removed
            # Currently none, but this structure allows for easy cleanup
        ]
        
        # Apply classifications
        for uri, name, reason, priority in meta_classifications:
            self._classify_resource(uri, name, ResourceCategory.META, reason, priority)
        
        for uri, name, reason, priority in on_demand_classifications:
            self._classify_resource(uri, name, ResourceCategory.ON_DEMAND, reason, priority)
        
        for uri, name, reason, priority in unnecessary_classifications:
            self._classify_resource(uri, name, ResourceCategory.UNNECESSARY, reason, priority)
    
    def _classify_resource(self, uri: str, name: str, category: ResourceCategory, 
                          reason: str, priority: int) -> None:
        """Classify a resource."""
        classification = ResourceClassification(uri, name, category, reason, priority)
        self._classifications[uri] = classification
        
        # Update category sets
        if category == ResourceCategory.META:
            self._meta_resources.add(uri)
        elif category == ResourceCategory.ON_DEMAND:
            self._on_demand_resources.add(uri)
        elif category == ResourceCategory.UNNECESSARY:
            self._unnecessary_resources.add(uri)
        
        logger.debug(f"Classified resource {name} ({uri}) as {category.value}: {reason}")
    
    def classify_resource(self, uri: str, name: str, category: ResourceCategory, 
                          reason: str, priority: int = 50) -> None:
        """Classify a new resource (for dynamic additions)."""
        self._classify_resource(uri, name, category, reason, priority)
    
    def get_classification(self, uri: str) -> Optional[ResourceClassification]:
        """Get classification for a specific resource."""
        return self._classifications.get(uri)
    
    def get_meta_resources(self) -> List[ResourceClassification]:
        """Get all meta-resources (keep at startup)."""
        return sorted(
            [self._classifications[uri] for uri in self._meta_resources],
            key=lambda x: x.priority
        )
    
    def get_on_demand_resources(self) -> List[ResourceClassification]:
        """Get all on-demand resources (remove from startup)."""
        return sorted(
            [self._classifications[uri] for uri in self._on_demand_resources],
            key=lambda x: x.priority
        )
    
    def get_unnecessary_resources(self) -> List[ResourceClassification]:
        """Get all unnecessary resources (remove entirely)."""
        return sorted(
            [self._classifications[uri] for uri in self._unnecessary_resources],
            key=lambda x: x.priority
        )
    
    def filter_startup_resources(self, resources: List[types.Resource]) -> List[types.Resource]:
        """Filter resources to only include meta-resources for startup."""
        meta_uris = self._meta_resources
        return [resource for resource in resources if str(resource.uri) in meta_uris]
    
    def get_resource_summary(self) -> Dict[str, int]:
        """Get summary of resource classifications."""
        return {
            "total": len(self._classifications),
            "meta": len(self._meta_resources),
            "on_demand": len(self._on_demand_resources),
            "unnecessary": len(self._unnecessary_resources)
        }
    
    def audit_resources(self, resources: List[types.Resource]) -> Dict[str, List[str]]:
        """Audit a list of resources and return classification results."""
        results = {
            "meta": [],
            "on_demand": [],
            "unnecessary": [],
            "unclassified": []
        }
        
        for resource in resources:
            uri = str(resource.uri)
            classification = self.get_classification(uri)
            
            if classification:
                if classification.category == ResourceCategory.META:
                    results["meta"].append(uri)
                elif classification.category == ResourceCategory.ON_DEMAND:
                    results["on_demand"].append(uri)
                elif classification.category == ResourceCategory.UNNECESSARY:
                    results["unnecessary"].append(uri)
            else:
                results["unclassified"].append(uri)
                logger.warning(f"Unclassified resource: {resource.name} ({uri})")
        
        return results


# Global instance
_resource_hygiene_manager = ResourceHygieneManager()


def get_resource_hygiene_manager() -> ResourceHygieneManager:
    """Get the global resource hygiene manager."""
    return _resource_hygiene_manager


def classify_startup_resources(resources: List[types.Resource]) -> List[types.Resource]:
    """Filter resources for startup (meta-resources only)."""
    return _resource_hygiene_manager.filter_startup_resources(resources)


def audit_resource_list(resources: List[types.Resource]) -> Dict[str, List[str]]:
    """Audit a resource list and return classification breakdown."""
    return _resource_hygiene_manager.audit_resources(resources)


__all__ = [
    "ResourceCategory",
    "ResourceClassification", 
    "ResourceHygieneManager",
    "get_resource_hygiene_manager",
    "classify_startup_resources",
    "audit_resource_list"
]
